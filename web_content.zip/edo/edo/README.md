# EDO

Standalone programming and JEE/MPC reasoning engine. Device features (voice, location, Android bridge, web) are optional and are not imported by the numeric core.

Open `index.html` in a browser, or copy `index.html`, `core/`, `knowledge/`, `memory/`, `tools/`, `bridge/`, `voice/`, `ui/`, and `media/` to `app/src/main/assets/edo/` and host them with `android/EdoBridge.kt`.

## Pipeline

```
index.html (black/gold chat UI, mode sheet, launch overlay)
        |
        v
core/orchestrator.js          single entry: EDO.handle(text, {mode})
        |
        +-- core/intent.js            classify
        +-- core/reasoning.js         formula retrieval, solve, substitute-back
        |       ^
        |       +-- core/solver.js    sentence templates; wraps Reasoner.matches/run
        +-- core/programming.js       code explain / generate / analyse
        +-- knowledge/index.js        chapter notes (math, physics, chemistry, programming)
        +-- memory/memory.js
        +-- tools/code-analyzer.js
        +-- tools/file-analyzer.js
        +-- tools/location.js         device only
        +-- tools/web-search.js       planner only; does not invent snippets
        +-- core/verify.js            citation and calculator re-check
```

`core/calc.js` is the only expression evaluator. `reasoning.js` and `solver.js` both use it. There is one formula table (`knowledge/formulas.js`) and one sentence solver.

## Modes and mode animations

EDO starts in **EDO Basic** (everyday tasks). Every mode change goes through `switchMode()` in `index.html`, which plays an animation from `ui/mode-fx.js` and applies the new mode at the climax of the clip.

| Switch into | Animation | Mode applies at |
|---|---|---|
| EDO Pro | `media/mode-pro.mp4` (gold orb, lightning, shockwave, with sound) | 4.4 s |
| Programming | `media/mode-programming.mp4` (code lattice collapsing into a core) | 3.0 s |
| Any other mode, and any clip that cannot play | built-in gold ring with the mode name | mid-ring |

Only the Skip button or Escape ends a clip early; a stray tap does not. The clip always plays to its last frame, waiting for it to buffer on slow connections. Calm mode and reduced motion switch instantly. "Sound in mode animations" is a checkbox in the panel. To change which clip a mode uses, edit `CLIPS` in `ui/mode-fx.js`.

**EDO Basic** does: calculator, time and date (device clock), notes, open apps and calls (always with a tap), location, search planning, friendly chat. For coding questions or step-by-step MPC solving it says so and offers a button to switch to Programming or EDO Pro. It never guesses an answer.

Each mode also has its own look: Basic is calm, Pro has the rotating gold ring on the mode button and a stronger glow, Programming adds a code grid and a monospace composer.

## Launch animation and theme

`media/` holds the official opening animation and the art shared by the launch screen and the chat:

| File | Purpose |
|---|---|
| `edo-intro.mp4` | H.264 Main, 720x1280, 30 fps, no audio, about 2 MB, `faststart` (hardware decoded on phones) |
| `edo-intro-poster.jpg` | first frame, shown instantly while the video buffers |
| `edo-hero.webp` | dragon backdrop of the chat, cut from the video; dimmed to a faint texture once a conversation starts |

Flow: `index.html` renders the whole app behind a black `#intro` overlay, so startup never waits on the video. `ui/dragon-intro.js` plays the muted, inline video (`preload="none"`, so nothing downloads when the intro is skipped) and begins a 0.9 s crossfade 0.8 s before the last frame; the final "EDO" dissolves while the chat fades in and settles. The video is released and the overlay removed after the fade. If the video errors, is blocked from autoplaying, has not started within 4 s, or Data Saver is on, the original gold-particle canvas plays instead. Tap, the Skip button, Enter or Escape ends the intro at any point. Reduced-motion and the low-performance setting skip it entirely. A failsafe reveals the app after 14-16 s no matter what.

To swap the video, re-encode a 9:16 clip and replace the poster:

```
ffmpeg -i new.mp4 -an -vf "scale=720:1280,fps=30" -c:v libx264 -profile:v main -level 4.0 -pix_fmt yuv420p -crf 27 -movflags +faststart media/edo-intro.mp4
ffmpeg -i new.mp4 -ss 0.4 -frames:v 1 -vf scale=360:-1 media/edo-intro-poster.jpg
```

Theme: black background, metallic gold gradient wordmark, gold-rimmed glass panels, glowing gold composer. The colours are CSS variables at the top of `index.html` (`--gold`, `--gold2`, `--line`, ...). The status orb beside the wordmark shows the core state (idle, listening, thinking, searching, processing, speaking, error).

Chat modes: the sheet maps to the engine's mode names (EDO Pro = Assistant, MPC Genius = JEE, Web Search = Search; Programming, Reasoning and Study unchanged; Friend Chat is new). Voice Mode toggles spoken replies, File Analysis pre-fills `analyze file:`, and the last row opens settings. There is no image-analysis mode because no image engine exists in this project; it is not shown rather than faked.

## Maths input, friend chat, apps and calls

**Maths.** `core/normalize.js` rewrites everyday phrasing into the expression the calculator already understands, so `100×100`, `100 x 100`, `12,34,567 - 1`, `15% of 200`, `25 squared`, `100 divided by 4`, `square root of 144` and `2 to the power of 10` all work in every mode. Anything it cannot fully understand is left alone (never half-guessed), and results are rounded to 12 significant digits (`0.1+0.2` gives `0.3`). Large results also show Indian digit grouping.

**Friend Chat** (`core/companion.js`). A warm, plain-spoken on-device companion for greetings, check-ins (stress, worry, tiredness, low motivation, good news, bad results) and a step-by-step decision helper: say "help me decide", "should I learn Rust or Go?" or "should I quit my job?". It collects the options, asks what matters and how much (1 to 10), has you score each option, then returns a weighted result with the factor that drove it and a gut-check when it is close. It is rule-based, not a language model, and says so. In Friend Chat with an AI proxy set, open-ended messages go to the proxy with `persona: "friend"` in the request body; without one, EDO asks instead of guessing. Safety messages (self-harm language) always stay local, interrupt any flow, and point to a real person and helplines. Say "my name is X" and it remembers your name on the device.

**Open apps and call** (`tools/device.js`). "open WhatsApp", "call mom", "call 98765 43210", "enable calling". Calls always show a confirmation card with the number and need one tap; emergency numbers only open the dialer.

| | Native Android build | Browser / web wrapper |
|---|---|---|
| Open an app | Any installed app by name (exact, prefix, substring or package) | Known apps only (WhatsApp, YouTube, Instagram, Telegram, Maps, Chrome, PhonePe, Paytm, Google Pay and a few more) through app links; Android decides whether it opens |
| Call a number | Direct call once Phone permission is granted, otherwise the dialer | Opens the dialer with the number; you tap call |
| Call a contact by name | Searches your contacts (Contacts permission) and offers up to three matches | Not possible; EDO asks for the number |
| Permissions | Panel, **Enable device access** (or say "enable calling") asks for Phone, Contacts, Microphone, Location and Notifications, one Android prompt each | Not applicable; the panel explains what works |

Wrapper note: a web-to-APK wrapper has no `EDOAndroid` bridge, so it gets the right-hand column. For the left column, build the Android project: copy `index.html` and the `core/`, `knowledge/`, `memory/`, `tools/`, `bridge/`, `voice/`, `ui/` and `media/` folders into `app/src/main/assets/edo/`, add `android/EdoBridge.kt`, and add the permissions and `<queries>` listed at the top of that file (now including `CALL_PHONE`). The Kotlin file has not been compiled in this environment; the JS side is tested against a simulated bridge that follows the same protocol.


## Try

- `2+3*sqrt(16)`
- `u=0 a=2 t=5 find v`
- `A car moving at 36 km/h accelerates at 2 m/s² for 5 s. Find the distance.`
- `Find the pH of 0.1 M acetic acid. Ka = 1.8 × 10^-5`
- `formula optics`
- `write a python factorial function`
- `remember: revise kinematics on Friday`

## v3: Brain, layered memory, project-aware coding, voice, typed Android bridge

**Flow for every message** (`core/brain.js`): normalize → classify → entities → retrieve memory → choose engine → reason → verify → follow-up → respond → update memory/state.
The Brain handles conversational acts itself (personal updates, recall, "continue", "later", "I changed my mind", planning, "make it better") and hands everything
else to the existing router unchanged (calculator, solver, programming, knowledge, device, search, crisis safety). The reply carries `engine`, `act` and a `trace`
(shown on long-press of the tool chip). It is rule-based: nothing here is a neural model, and the code says so.

| Area | Files | What it really does |
|---|---|---|
| Orchestration | `core/brain.js`, `core/friend.js`, `core/planner.js` | pattern + entity classification, reference resolution to the last output/plan, response variety (no repeats within a slot), study plans built from the chapter notes, numbers in replies checked against what the user/memory/plan said |
| Memory | `memory/layers.js`, `core/semantic.js`, `memory/memory.js` | working (RAM), turns, extractive summaries, events (dated), plans, interaction state, explicit long-term notes. ON/OFF, inspect, delete one, forget a topic, clear history/all, retention, "saved" indicator, corrupted-storage recovery. Retrieval = stemming + synonym table + IDF + trigram typo tolerance (not embeddings) |
| Proactive | `core/proactive.js` | opt-in suggestions at app open (upcoming exam, unfinished plan, open question, "remember this"), cooldown, per-kind switches. No background polling |
| Programming brain | `core/project.js`, `core/codebrain.js`, `core/validation.js`, `workers/project-worker.js`, `knowledge/unity.js` | workspace index (JS/TS, Python, C#, Java, Kotlin, C/C++, Go, Rust; Unity scenes/prefabs via GUIDs), symbols, references, dependency graph, impact, cycles, security/perf/architecture/Unity review, patches (rename, exact edits, lifecycle-name fix, cached GetComponent) validated on a copy before they can be applied, test skeletons |
| Validation | `core/validation.js` | static + project checks always; **"Not executed here."** unless you configure an isolated HTTPS/localhost runner and confirm each run; the report is exactly what the runner returned or an error |
| Voice | `voice/voice-engine.js` | continuous STT with interim results, silence endpointing, restart/back-off, per-error recovery, en-IN / hi-IN / Hinglish (maps to en-IN); wake-word *state machine* (threshold, refractory, self-trigger and busy protection, command timeout, phrase validation); session idle→wake→listening→processing→speaking with barge-in; TTS voice/rate/pitch, on-device voice preference, Android TTS via the bridge |
| Android | `android/.../EdoBridge.kt`, `VoiceService.kt`, `VoiceHub.kt`, `EdoTts.kt`, `WakeWordEngine.kt`, `ReminderReceiver.kt`, `MainActivity.kt`; `bridge/android-client.js` | typed errors, request ids, cancellation, progress and push events, session-change cancellation, capability detection, 31 methods (apps, contacts, call with confirmation, notifications, battery/network, clipboard, share, settings screens, calendar read/insert-screen, file/project picker, media keys, reminders, TTS, voice service) |
| MPC/JEE | `core/mpc-layer.js`, `knowledge/retrieval.js` | wraps the unchanged verified pipeline: chapter, concept, alternate method, physical sanity flags, "what I need" when ambiguous. Never changes or invents a number |

**Honest limits**

- **Wake word.** A real wake word needs a native acoustic engine. This repo ships the Android service, the state machine and the engine interface, but **no engine**
  (see `android/.../WakeWordEngine.kt`). Without one, `voice.configureWake` reports `engineAvailable:false` and the UI says so. The browser has no wake word; use the mic button.
- **Android has not been compiled or run** (no SDK/Gradle/Kotlin here). The Kotlin is checked by reading it (balanced syntax, every JS method implemented, permissions declared,
  safety rules present) and every file is marked UNVERIFIED. Expect compile fixes on first build.
- **Workers.** The project review worker runs from `http(s)`. From `file://` (the Android WebView origin) the browser refuses it; EDO then indexes on the main thread in time-boxed chunks.
- **Project analysis is lexical**, not a compiler: no type resolution, so same-named symbols are reported as ambiguous; reflection/dynamic access is invisible. It never runs your code.
- **Reminders** use inexact alarms (can be late, lost on reboot). The runner endpoint must be https or `localhost` (the CSP enforces it).
- **Summaries** are extractive (sentence selection), not generated.

## Tests

Run all unit checks: `node tests/run-tests.js`. Browser smoke (needs Python + Playwright + Chromium): `python3 tests/browser-smoke.py`.
Unit suites: engine/launch (original), `modes.js`, `brain.js` (conversation, memory layers, planner, proactive, retrieval, MPC), `project.js` (index, graph, CodeBrain, patches, validation, runner contract),
`voice.js` (STT, wake state machine, session, TTS), `bridge2.js` (typed bridge against a simulated native side + Kotlin/manifest static checks), `security.js` (CSP, no dynamic code, escaping, asset wiring).
The browser smoke drives the real page over `http://` and `file://`: boot, CSP, chat, quick replies, memory panel, XSS payload, project load, worker responsiveness, a fake-microphone voice session, back button.

Original note: `node tests/run-tests.js` also runs the launch checks (video path, error fallback, autoplay block, stall timeout, skip, reduced motion, asset wiring, HTML escaping).


`node tests/run-tests.js` runs the engine checks plus launch checks (video path, error fallback, autoplay block, stall timeout, skip, reduced motion, asset wiring, HTML escaping).

## What was not merged

The other workspace was a React/TypeScript app. Its UI shell, `.grok`, and `.vercel` output were not copied. Useful engines were ported to plain scripts so this project still opens without a bundler.

## Upgrade notes (v2)

Run: open `index.html` in a browser (no build step). Tests: `node tests/run-tests.js` (the original 35 checks are unchanged; see Tests above for the current count).

New modules: `core/pipeline.js` (staged reasoning with verification status + confidence), `core/units.js`, `core/entities.js`
(given validation), `core/derive.js` (multi-step chains), `core/verify.js`, `core/patch.js` (diffs), `core/programming.js`
(static programming engine), `knowledge/jee-*.js` (about 60 chapter notes), `knowledge/code-templates.js`, `ui/render.js`,
`memory/memory.js` (v2, auto-migrates old notes), `tools/web-search.js` (provider interface), `android/` (Gradle project, UNBUILT).

Honesty rules: EDO never runs user code or its own generated code. Retrieval and symbol matching are heuristic, not a neural model.
Search needs `WebSearch.setProvider(...)`; without one it says no search happened. The Android project has not been compiled.
