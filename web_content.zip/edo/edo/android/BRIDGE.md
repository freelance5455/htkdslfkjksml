# EDO.AndroidBridge — architecture, API, security, limits

**Status: UNVERIFIED on Android.** The JavaScript layer and its browser fallbacks are tested (Node + Chromium). The Kotlin was written and
statically checked but **never compiled or run** (no Android SDK, Gradle or Kotlin compiler was available). See `TEST-PLAN.md`.

## Architecture (what actually exists)

```
EDO page (file:///android_asset/edo/index.html)
  EDO.AndroidBridge          bridge/edo-android-bridge.js   public promise API, validation, errors, browser fallbacks
        │ uses
  Bridge                     bridge/android-client.js       wire protocol: ids, timeouts, cancel, progress, session resync (unchanged contract)
        │ window.EDOAndroid.invoke(id, method, json)  →  window.__edoBridgeResult(id, ok, json)
  EdoBridge.kt  (@JavascriptInterface)  validate → bounded pool → dispatch allowlist
        ├─ ContentRefs.kt    opaque "ref_…" tokens for user-picked files/images (page never sees paths or URIs)
        ├─ DocReader.kt + DocCore.kt   SAF reading, sniffing, strict decoding, DOCX text (pure logic in DocCore)
        ├─ ImageIntake.kt    gallery (document picker), camera (system camera + FileProvider), bounded decode
        ├─ OcrEngine.kt      ML Kit on-device text recognition; PDF pages via PdfRenderer
        ├─ SpeechSession.kt  SpeechRecognizer, one session, cancelled on pause
        ├─ DeviceActions.kt  PermissionGate, SafeIntents (allowlist), SaveAs (system "save as")
        └─ existing: EdoTts, VoiceHub, reminders, calendar, contacts, calls …
```
Existing methods (v2) are unchanged and still work. Protocol is now **v3**; the page sends `_v:3` in every request and native refuses a newer `_v`.

## Public API (`EDO.AndroidBridge`)
All methods return a Promise. Long operations return a promise with `.cancel()` and `.requestId`, and accept `{timeoutMs, signal, onProgress}`.
User closing a picker rejects with `CANCELLED` (use `AndroidBridge.isCancel(e)`).

| Method | Options → result (summary) | Native method | Browser fallback |
|---|---|---|---|
| `isAvailable()` | → boolean (sync) | – | `false` |
| `init()` | idempotent; subscribes to native events once | capabilities | capability probe |
| `getCapabilities(force?)` | → `{environment, protocol, session, capabilities{name:{state,detail}}, permissions}` | capabilities | browser probes |
| `getPlatformInfo()` / `getAppInfo()` | OS/SDK/model/language; app package/version (no identifiers) | deviceInfo | language/online; name only |
| `requestPermission(name)` | `microphone\|notifications\|contacts\|calls\|location\|calendar` → `{granted, hint?}` | requestPermission | microphone, notifications only |
| `pickFile({multiple,maxFiles,mimeTypes})` | → `{files:[{ref,name,size,mime,kind}]}` | pickFile | `<input type=file>` (needs a tap) |
| `readFile({ref,maxBytes,offset,length,allowUnknownText})` | → `{text,encoding,encodingGuessed,size,offset,bytesRead,nextOffset,eof,partial,truncated,…}` | readFile | text only |
| `pickImage({multiple,maxImages})` / `captureImage()` | → `{images:[{ref,name,size,mime,width,height,orientation}]}` / `{image}` | pickImage / captureImage | file input (+capture hint) |
| `getImageData({ref,maxDimension,quality})` | → `{mime:'image/jpeg',base64,width,height}` | image.data | canvas resize |
| `extractTextFromImage({ref\|refs,detail,maxDimension,maxPages})` | → `{engine,status,text,results[{ref,imageId,page?,status,text,width,height,blocks,durationMs,error?}],durationMs,confidenceAvailable:false}` | ocr.extract | `TextDetector` if present |
| `startSpeechRecognition({lang,partial,maxMs,preferOffline})` | → `{text,alternatives,confidence\|null}`; partials via `onProgress` and `on('speech.partial')` | speech.start | SpeechRecognition |
| `stopSpeechRecognition()` | finish and deliver; to discard use `.cancel()` | speech.stop | stop() |
| `speak({text,lang,rate,pitch,voice})` / `stopSpeaking()` | → `{spoken:true}` | tts.speak / tts.stop | speechSynthesis |
| `share({text,title,ref})` | → `{shown}` (chooser only; nothing sent until the user picks) | share | Web Share |
| `copyToClipboard(text)` | ≤ 100 000 chars, never truncated | clipboardWrite | Clipboard API (secure context) |
| `openSupportedApp({action,…})` | `app\|maps\|web(https)\|email(compose)\|dial` → `{launched, verified:false}` | openSupported / openApp | web links only |
| `openSettings({section})` | `wifi\|bluetooth\|notifications\|app\|battery\|location\|display` | openSettings | unsupported |
| `downloadFile({filename,mime,text\|base64})` | ≤ 10 MB; user picks the place → `{saved,name,bytes}` | download.save | Blob download → `{saved:null, initiated:true}` |
| `releaseRef(ref)` | frees a ref (and deletes a temp camera file) | ref.release | forgets the File |
| `on(event, fn)` / `reset()` | events: `speech.partial`, `speech.state`, `lifecycle.resume`, `permissions.changed` | – | – |

Notes: `downloadFile` saves content the page already has; it does **not** download remote URLs (the page can `fetch` then pass the content).
There is no `readClipboard` in this API; the older `clipboardRead` native method remains for the EDO tool layer and is user-confirmed there.

## Errors
`AndroidBridgeError {code, message, method, nativeCode, retryable, details?}`. Codes: `PERMISSION_DENIED, UNSUPPORTED_CAPABILITY, INVALID_ARGUMENT, TIMEOUT,
CANCELLED, FILE_TOO_LARGE, UNSUPPORTED_FILE_TYPE, NATIVE_BRIDGE_UNAVAILABLE, OCR_FAILED, SPEECH_RECOGNITION_FAILED, INTERNAL_ERROR` plus `NOT_FOUND` and `BUSY`.
Messages are cut to 240 chars and stripped of `content://`/`file://` URIs, `/data/…` paths and stack frames. Native replies carry only a short message and the exception *class name*.

## Capability states
`SUPPORTED | UNAVAILABLE | PERMISSION_REQUIRED | NOT_INITIALIZED | UNSUPPORTED_ENVIRONMENT`. Before the first `getCapabilities()` every capability is `NOT_INITIALIZED`.
Text-to-speech reports `NOT_INITIALIZED` natively until first use. A native build that lacks a method reports `UNAVAILABLE` for that capability.

## Protocol rules (what is enforced)
- JS: strict option validation (unknown keys, types, ranges, enums, control characters) **before** sending; refs must match `ref_[A-Za-z0-9]{8,64}`.
- JS: one interactive operation at a time (`pickFile, pickImage, captureImage, speech.start, download.save, requestPermission`) → `BUSY` without reaching native;
  identical read-only calls (`getPlatformInfo/getAppInfo`) share one native call.
- Native: method allowlist, `id>0`, args ≤ 14 M chars, duplicate-id rejection, one exclusive operation at a time, bounded pool (2–6 threads, queue 32 → `busy`).
- Native: every page load increments a *generation*; replies from an older generation are dropped, pending work is cancelled, speech and permission waits end,
  and all refs (and temp photos) are cleared, so a reloaded page can never receive an old answer.
- Native restart (new session) is detected by `Bridge.resync()` → in-flight calls reject `CANCELLED`.

## Security model
- **Transport:** `addJavascriptInterface` (existing). I did **not** switch to `WebViewCompat.addWebMessageListener`: it needs `androidx.webkit` and a
  tested rewrite of the transport, which could not be compiled or run here. Risks of `addJavascriptInterface`: the object is visible to every frame of the WebView.
  Mitigations in place: the bridge answers only while the top-level URL starts with the bundled-asset prefix; all subframe navigations are refused and CSP has
  `frame-src 'none'`; only the allowlisted `@JavascriptInterface invoke/…` is exposed; no reflection or arbitrary method execution; arguments are validated.
  Recommended follow-up: migrate to `addWebMessageListener` with an `allowedOriginRules` of the asset origin.
- **Origin:** local app, loaded from `file:///android_asset/edo/` (`trustedPrefix`). `allowFileAccess`, `allowContentAccess`, file→file and universal file access are all off.
  A `file://` origin is not a strong boundary by itself; the real controls are the prefix check, the CSP, and that the page loads no remote script.
- **External navigation:** main-frame only, schemes `https, intent, mailto, tel, geo`; `intent:` links are parsed with component/selector cleared and BROWSABLE added.
- **No path or URI input:** natives accept refs only; refs are random (96-bit) and map to URIs the user chose in a system dialog.
- **Files:** Storage Access Framework, no storage permission. **Images:** document picker; camera through the system camera app (no CAMERA permission).
  **FileProvider** exposes only `cache/edo-capture/`.
- **Permissions requested at the moment of use only**; none added to the manifest in this change (all six used were already declared).
- **Logging:** the bridge logs nothing of file contents, OCR text, keys or tokens.
- **Privacy:** OCR is on-device. Android's SpeechRecognizer may use a network service (EDO cannot tell); `preferOffline` is a request, not a guarantee. Nothing is sent
  anywhere by this layer; `getImageData` returns base64 to the page, so the caller must obtain the user's consent before sending it to an AI provider.
- **Not provided, on purpose:** call recording, background listening, screen capture, accessibility use, reading other apps, silent saves/overwrites, shell access.

## Files, OCR, camera, speech — behaviour and limits
- **Text types:** txt md json csv xml html htm css js ts py java kt c cpp h hpp cs sql log yml yaml. Content is sniffed; an extension never decides alone.
  Default read limit 1 MB, hard 5 MB. Larger → `FILE_TOO_LARGE` with a hint; read in pieces with `offset`/`length` (`nextOffset` never splits a UTF-8 character).
  Strict UTF-8; invalid UTF-8 is read as windows-1252 and flagged `encodingGuessed`; BOMs handled; UTF-16 only with a BOM and whole-file reads; binary content refused; empty files return `empty:true`.
- **DOCX:** plain text via a bounded scanner (≤ 30 MB inflated, ≤ 2000 entries, ≤ 2 M chars with explicit `truncated`). Tables, images, headers, footnotes are not extracted.
- **PDF:** **no text extraction** (no PDF library is bundled). `extractTextFromImage` renders up to `maxPages` (default 5, max 20) pages with `PdfRenderer` and OCRs them: this is OCR, quality varies, password-protected PDFs fail.
- **OCR:** ML Kit `text-recognition` (bundled, Latin script only: no Devanagari/CJK). Blocks→lines→elements with boxes in the processed image's coordinates. **No confidence scores** (the API used does not give them). An in-flight recognition can't be interrupted; cancel applies between images/pages. Images ≤ 50 MP, decoded at ≤ `maxDimension` (default 2048).
- **Speech:** one session; needs RECORD_AUDIO (requested via the existing `need()`); refused while the wake-word service holds the mic; cancelled on activity pause; no background recording.
- **Camera:** the photo is a cache file, deleted on `releaseRef`, page reload, activity destroy, and (older than 1 h) on the next capture.

## Integration
Already wired in `index.html` (script after `bridge/android-client.js`) and the Gradle copy task (`bridge/**`). Dependencies added in `app/build.gradle.kts`:
`androidx.core:core-ktx:1.12.0`, `com.google.mlkit:text-recognition:16.0.0` (**confirm the version at the first Gradle sync**), `junit` (test).
```
const A = EDO.AndroidBridge; await A.init();
const {files} = await A.pickFile({mimeTypes:['text/*']});
const doc = await A.readFile({ref: files[0].ref});            // or loop with offset/length
const {image} = await A.captureImage(); const ocr = await A.extractTextFromImage({ref: image.ref});
```

## Measurements (JavaScript only — `node tests/bench-bridge.js`)
Environment: Node v22.22.2, Intel Xeon @ 2.80 GHz, 1 core, simulated host (**not an Android device**).
Rejecting an invalid call: ~0.010 ms. Simulated native round trip (setTimeout-0 reply): ~1.2 ms. Browser-fallback reader, 5 MB Unicode text in 64 KB chunks: ~40 ms (≈126 MB/s).
No Android latency, memory or battery figures exist.

## Known limitations
Kotlin never compiled; ML Kit version unconfirmed; `addJavascriptInterface` transport; Latin-only OCR; no PDF text; no DOCX tables; speech may use the network;
TTS init failures only show on first `speak()`; sharing a picked file to other apps depends on the source provider allowing re-grant; `clipboardRead` has no native
user-gesture proof; no migration of `pickProject` to refs; instrumented and device tests are unwritten.
