# EDO Android project (UNBUILT)

Structure is complete (Gradle Kotlin DSL, manifest, `MainActivity` + `EdoBridge` in `app/src/main/java/com/edo/app/`),
but **it has not been compiled** in the environment where it was written (no Android SDK, JDK or network).
Treat it as a starting point until you have run a build.

Build (needs Android Studio or JDK 17 + Android SDK 34):

1. Open `android/` in Android Studio, let it sync (it will create the Gradle wrapper), or run `gradle wrapper` once.
2. `./gradlew :app:assembleDebug`
3. The `copyEdoAssets` task copies `index.html`, `core/`, `workers/`, `knowledge/`, `memory/`, `tools/`, `bridge/`, `voice/`, `ui/`, `media/` into the APK's `assets/edo/`.
4. Wake word: add a keyword-spotting engine (for example Picovoice Porcupine, which needs its own access key) and register it in `EdoApp.kt`; see `WakeWordEngine.kt`. Until then the wake-word switch reports that no engine is installed.

Checked here (by tests): the manifest is well-formed and declares every permission the Kotlin uses; Kotlin brackets balance; every JS bridge method has a Kotlin branch and the lists match; the bridge only answers the bundled page; calls need `confirmed:true` and emergency numbers never auto-dial; the voice service is private, non-sticky and refuses to start without the mic permission and an engine; the JS bridge (typed errors, timeouts, cancellation, progress, events, session change) is tested against a simulated native side.
Not checked: Kotlin compilation, Gradle sync, runtime permissions on a real device, the document-tree project picker, contact lookup, calling, notifications, calendar access, TTS, the foreground service, alarms, WebView lifecycle recovery, and behaviour of the page's CSP and Web Worker inside the real WebView (in Chromium the worker is refused from `file://` and EDO falls back to main-thread indexing).
