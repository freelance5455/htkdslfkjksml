plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.edo.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.edo.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1-unverified"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    sourceSets["main"].assets.srcDir(layout.buildDirectory.dir("generated/edo-assets"))
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")                  // FileProvider for camera output
    implementation("com.google.mlkit:text-recognition:16.0.0")       // on-device OCR (bundled Latin model). Version to be confirmed at the first Gradle sync
    testImplementation("junit:junit:4.13.2")                         // JVM unit tests (DocCoreTest)
}

// Copies the web app (one level above android/) into assets/edo/ so the WebView can load file:///android_asset/edo/index.html.
val copyEdoAssets by tasks.registering(Copy::class) {
    val web = rootProject.projectDir.parentFile
    into(layout.buildDirectory.dir("generated/edo-assets/edo"))
    from(web) {
        include("index.html", "workers/**", "core/**", "knowledge/**", "memory/**", "tools/**", "bridge/**", "voice/**", "ui/**", "media/**")
    }
}
tasks.matching { it.name.startsWith("merge") && it.name.endsWith("Assets") }.configureEach { dependsOn(copyEdoAssets) }
