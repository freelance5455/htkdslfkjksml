package com.edo.app

// Explicit, allowlisted device actions: one-permission requests, safe intents (maps, https links, email compose, dialer) and "save as".
// Nothing here calls anyone, sends anything, changes a setting, reads another app, or overwrites a file without the user choosing it.
// UNVERIFIED: not compiled or run in the environment where it was written.

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.util.Base64
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.CompletableFuture
import java.util.concurrent.FutureTask
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

/** Asks for ONE named permission when JavaScript explicitly calls requestPermission, and waits for the user's answer. */
class PermissionGate(private val act: Activity) {
    private val pending = HashMap<Int, CompletableFuture<Boolean>>()
    private var nextCode = 200

    companion object {
        val MAP: Map<String, String?> = mapOf(
            "microphone" to Manifest.permission.RECORD_AUDIO,
            "contacts" to Manifest.permission.READ_CONTACTS,
            "calls" to Manifest.permission.CALL_PHONE,
            "calendar" to Manifest.permission.READ_CALENDAR,
            "location" to Manifest.permission.ACCESS_FINE_LOCATION,
            "notifications" to (if (Build.VERSION.SDK_INT >= 33) Manifest.permission.POST_NOTIFICATIONS else null),
        )
    }

    fun granted(name: String): Boolean {
        val p = MAP[name] ?: return name == "notifications" // before Android 13 notifications need no runtime permission
        return act.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    }

    fun request(name: String, req: EdoBridge.Request): JSONObject {
        if (!MAP.containsKey(name)) throw IllegalArgumentException("unknown permission")
        if (granted(name)) return JSONObject().put("permission", name).put("granted", true).put("alreadyGranted", true)
        val p = MAP[name]!!
        val f = CompletableFuture<Boolean>()
        val code = synchronized(pending) { val c = nextCode; nextCode = if (nextCode >= 299) 200 else nextCode + 1; pending[c] = f; c }
        act.runOnUiThread { act.requestPermissions(arrayOf(p), code) }
        val deadline = System.currentTimeMillis() + 60_000
        try {
            while (true) {
                if (req.cancelled) throw BridgeException("cancelled", "Cancelled.")
                if (System.currentTimeMillis() > deadline) throw BridgeException("timeout", "The permission dialog was not answered in time.")
                try { return JSONObject().put("permission", name).put("granted", f.get(200, TimeUnit.MILLISECONDS)) } catch (_: TimeoutException) { }
            }
        } finally { synchronized(pending) { pending.remove(code) } }
    }

    fun onResult(code: Int, results: IntArray) {
        val f = synchronized(pending) { pending[code] } ?: return
        f.complete(results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED)
    }

    fun cancelAll() { synchronized(pending) { pending.values.forEach { it.complete(false) }; pending.clear() } }
}

/** Builds only these intents. Every one is checked with resolveActivity first, and none carries a component or selector from JavaScript. */
class SafeIntents(private val act: Activity, private val openApp: (String) -> JSONObject) {
    fun open(a: JSONObject): JSONObject {
        val action = a.optString("action", "")
        if (action == "app") return openApp(a.getString("name"))
        val i: Intent = when (action) {
            "maps" -> Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(a.getString("query").take(200))))
            "web" -> {
                val u = Uri.parse(a.getString("url"))
                val host = u.host ?: ""
                if (u.scheme != "https" || host.isEmpty() || !host.contains('.') || u.userInfo != null || (u.port != -1 && u.port != 443)) throw IllegalArgumentException("only plain https links are allowed")
                Intent(Intent.ACTION_VIEW, u).addCategory(Intent.CATEGORY_BROWSABLE)
            }
            "email" -> {
                val to = a.getString("to").trim()
                if (!Regex("^[^\\s@<>\"]+@[^\\s@<>\"]+\\.[^\\s@<>\"]+$").matches(to)) throw IllegalArgumentException("that is not an email address")
                Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + Uri.encode(to))).putExtra(Intent.EXTRA_SUBJECT, a.optString("subject", "").take(200)).putExtra(Intent.EXTRA_TEXT, a.optString("body", "").take(2000))
            }
            "dial" -> {
                val n = a.getString("number").filter { it.isDigit() || it == '+' }
                if (n.length !in 3..15) throw IllegalArgumentException("that is not a phone number")
                Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", n, null)) // opens the dialer only; the user presses call
            }
            else -> throw BridgeException("unsupported", "That action is not on the allowlist.")
        }
        i.component = null
        i.selector = null
        if (i.resolveActivity(act.packageManager) == null) throw BridgeException("not_found", "No app on this device can handle that.")
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val task = FutureTask<Unit> {
            try { act.startActivity(i) } catch (e: ActivityNotFoundException) { throw BridgeException("not_found", "No app on this device can handle that.") } catch (e: SecurityException) { throw BridgeException("permission_denied", "Android refused to open that.") }
        }
        act.runOnUiThread(task)
        try { task.get(5, TimeUnit.SECONDS) } catch (e: java.util.concurrent.ExecutionException) { throw e.cause ?: e } catch (e: TimeoutException) { throw BridgeException("timeout", "Android did not respond.") }
        return JSONObject().put("launched", true).put("action", action)
    }
}

/** "Save as": the system file dialog lets the user pick the place and name, so nothing is written or overwritten silently. */
class SaveAs(private val act: Activity, private val launch: (EdoBridge.Request, Int, Intent) -> Intent?) {
    companion object { const val MAX_BYTES = 10 * 1024 * 1024 }

    fun save(req: EdoBridge.Request, a: JSONObject): JSONObject {
        val name = DocCore.sanitizeFilename(a.getString("filename")) ?: throw IllegalArgumentException("that file name is not allowed")
        val mime = a.getString("mime")
        if (mime !in DocCore.SAVE_MIME) throw BridgeException("unsupported_file_type", "That file type cannot be saved.")
        val bytes: ByteArray = if (a.has("text") && !a.isNull("text")) a.getString("text").toByteArray(Charsets.UTF_8) else try {
            Base64.decode(a.getString("base64"), Base64.DEFAULT)
        } catch (e: IllegalArgumentException) { throw IllegalArgumentException("base64 content is not valid") }
        if (bytes.isEmpty()) throw IllegalArgumentException("there is nothing to save")
        if (bytes.size > MAX_BYTES) throw BridgeException("file_too_large", "Content is ${bytes.size} bytes; the limit is $MAX_BYTES.")
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType(mime).putExtra(Intent.EXTRA_TITLE, name)
        val uri = launch(req, EdoBridge.RC_SAVE, i)?.data ?: throw BridgeException("cancelled", "Saving was cancelled.")
        try {
            act.contentResolver.openOutputStream(uri, "wt")?.use { it.write(bytes) } ?: throw BridgeException("native_error", "The chosen location could not be opened for writing.")
        } catch (e: IOException) {
            throw BridgeException("native_error", "The file was created but could not be written completely.")
        }
        return JSONObject().put("saved", true).put("name", name).put("bytes", bytes.size)
    }
}
