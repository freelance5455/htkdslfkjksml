package com.edo.app

import android.content.Context

// A wake-word engine listens to the microphone continuously ON DEVICE and calls onWake when it hears the phrase.
// EDO does not ship one. Reliable always-on keyword spotting needs a dedicated acoustic model (for example Picovoice
// Porcupine, which also needs an access key, or an open-source keyword spotter). Repeatedly running full speech
// recognition is NOT a wake-word engine and is deliberately not offered here.
//
// To add one: implement WakeWordEngine, add its dependency to app/build.gradle.kts, and register a factory once at startup:
//     WakeWordEngines.register { ctx -> MyEngine(ctx) }      // return null if it cannot run on this device
// Until a factory is registered, voice.configureWake reports engineAvailable=false and the UI says so.
// UNVERIFIED: not compiled or run in the environment where it was written.
interface WakeWordEngine {
    val name: String
    val supportsCustomPhrase: Boolean

    // threshold is 0..1: a detection with lower confidence must not be reported. Called off the main thread.
    fun start(phrase: String, threshold: Double, onWake: (confidence: Double) -> Unit)
    fun stop()
}

object WakeWordEngines {
    private val factories = ArrayList<(Context) -> WakeWordEngine?>()

    fun register(factory: (Context) -> WakeWordEngine?) { synchronized(factories) { factories.add(factory) } }

    fun create(ctx: Context): WakeWordEngine? {
        synchronized(factories) {
            for (f in factories) {
                val e = try { f(ctx) } catch (_: Exception) { null }
                if (e != null) return e
            }
        }
        return null
    }

    fun available(ctx: Context): Boolean = create(ctx) != null
}
