package com.edo.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import org.json.JSONObject

// Foreground service that hosts the native wake-word engine so EDO can listen while the screen is off or the app is in
// the background. It runs ONLY after the user switched the wake word on and granted the microphone permission, shows a
// persistent notification while it listens, and stops when the user switches it off. It is never started at boot and
// never restarts itself. It detects the wake word; it does not record or send audio anywhere. When the app is not on
// screen, a detection posts a "tap to continue" notification, because Android does not let a background service open an app.
// If no WakeWordEngine is registered the service refuses to start (see WakeWordEngine.kt).
// UNVERIFIED: not compiled or run in the environment where it was written.
class VoiceService : Service() {
    private var engine: WakeWordEngine? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { shutdown(); return START_NOT_STICKY }
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            VoiceHub.fail("microphone permission is not granted"); shutdown(); return START_NOT_STICKY
        }
        val e = WakeWordEngines.create(this)
        if (e == null) { VoiceHub.fail("no wake-word engine is installed in this build"); shutdown(); return START_NOT_STICKY }
        startInForeground()
        engine?.stop()
        engine = e
        val phrase = prefs.getString("phrase", "Hey EDO") ?: "Hey EDO"
        val threshold = prefs.getFloat("threshold", 0.7f).toDouble()
        VoiceHub.serviceRunning = true
        VoiceHub.wakeWordEnabled = true
        VoiceHub.wakeEngine = e.name
        VoiceHub.setListening(true)
        Thread {
            try {
                e.start(phrase, threshold) { confidence -> onWake(phrase, confidence) }
            } catch (ex: Exception) {
                VoiceHub.fail(ex.message ?: "wake-word engine failed")
                shutdown()
            }
        }.start()
        return START_NOT_STICKY
    }

    private fun onWake(phrase: String, confidence: Double) {
        VoiceHub.emit("voice.wake", JSONObject().put("phrase", phrase).put("confidence", confidence).put("source", "native"))
        if (!VoiceHub.isAttached()) notifyHeard()
    }

    private fun channel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "EDO voice", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CHANNEL_HEARD, "EDO heard you", NotificationManager.IMPORTANCE_HIGH))
    }

    private fun openIntent(): PendingIntent = PendingIntent.getActivity(
        this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun startInForeground() {
        channel()
        val stop = PendingIntent.getService(this, 1, Intent(this, VoiceService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("EDO is listening for its wake word")
            .setContentText("Audio stays on this device. Tap to open EDO.")
            .setContentIntent(openIntent())
            .addAction(Notification.Action.Builder(null, "Turn off", stop).build())
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTE_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(NOTE_ID, n)
    }

    private fun notifyHeard() {
        val n = Notification.Builder(this, CHANNEL_HEARD)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("EDO heard you")
            .setContentText("Tap to continue.")
            .setContentIntent(openIntent()).setAutoCancel(true).build()
        getSystemService(NotificationManager::class.java).notify(NOTE_HEARD_ID, n)
    }

    private fun shutdown() {
        try { engine?.stop() } catch (_: Exception) { }
        engine = null
        VoiceHub.serviceRunning = false
        VoiceHub.wakeWordEnabled = false
        VoiceHub.wakeEngine = null
        VoiceHub.setListening(false)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() { try { engine?.stop() } catch (_: Exception) { }; VoiceHub.serviceRunning = false; super.onDestroy() }

    companion object {
        const val ACTION_STOP = "com.edo.app.STOP_VOICE"
        const val PREFS = "edo_voice"
        private const val CHANNEL = "edo_voice"
        private const val CHANNEL_HEARD = "edo_heard"
        private const val NOTE_ID = 4101
        private const val NOTE_HEARD_ID = 4102

        fun start(ctx: Context) { ctx.startForegroundService(Intent(ctx, VoiceService::class.java)) }
        fun stop(ctx: Context) { ctx.startService(Intent(ctx, VoiceService::class.java).setAction(ACTION_STOP)) }
    }
}
