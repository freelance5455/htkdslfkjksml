package com.edo.app

import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.util.ArrayDeque

// Process-wide hub between the native voice pieces (VoiceService, EdoTts) and whichever EdoBridge is currently attached.
// The WebView page may be absent (activity paused, WebView recreated) while the service keeps running, so events are
// buffered (bounded) and delivered on attach. Nothing here touches the network or exposes a method to web content.
// UNVERIFIED: not compiled or run in the environment where it was written.
object VoiceHub {
    fun interface Sink { fun deliver(name: String, payload: JSONObject) }

    private val main = Handler(Looper.getMainLooper())
    private val buffer = ArrayDeque<Pair<String, JSONObject>>()
    private const val MAX_BUFFER = 20
    @Volatile private var sink: Sink? = null

    // state exposed to JavaScript through voice.status
    @Volatile var serviceRunning = false
    @Volatile var wakeWordEnabled = false
    @Volatile var wakeEngine: String? = null
    @Volatile var listening = false
    @Volatile var speaking = false
    @Volatile var voiceError: String? = null

    fun attach(s: Sink) {
        sink = s
        val drained = ArrayList<Pair<String, JSONObject>>()
        synchronized(buffer) { while (buffer.isNotEmpty()) drained.add(buffer.poll()!!) }
        drained.forEach { dispatch(it.first, it.second) }
    }

    fun detach() { sink = null }
    fun isAttached(): Boolean = sink != null

    fun emit(name: String, payload: JSONObject = JSONObject()) {
        payload.put("t", System.currentTimeMillis())
        if (sink != null) { dispatch(name, payload); return }
        synchronized(buffer) {
            if (buffer.size >= MAX_BUFFER) buffer.poll()
            buffer.add(Pair(name, payload))
        }
    }

    private fun dispatch(name: String, payload: JSONObject) {
        val s = sink ?: return
        main.post { try { s.deliver(name, payload) } catch (_: Exception) { } }
    }

    fun setListening(v: Boolean) { listening = v; emit("voice.state", snapshot()) }
    fun setSpeaking(v: Boolean) { speaking = v; emit("voice.state", snapshot()) }
    fun fail(message: String?) { voiceError = message; emit("voice.error", JSONObject().put("message", message ?: "")) }

    fun snapshot(): JSONObject = JSONObject()
        .put("nativeVoiceAvailable", true)
        .put("wakeWordEnabled", wakeWordEnabled)
        .put("wakeWordEngine", wakeEngine ?: JSONObject.NULL)
        .put("listening", listening)
        .put("speaking", speaking)
        .put("serviceRunning", serviceRunning)
        .put("voiceError", voiceError ?: JSONObject.NULL)
}
