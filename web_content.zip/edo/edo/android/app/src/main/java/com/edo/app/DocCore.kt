package com.edo.app

// Pure file-handling logic with NO Android imports, so it can be unit-tested on a plain JVM (see app/src/test/.../DocCoreTest.kt).
// Rules: an extension never proves a type (content is sniffed); text is decoded strictly and a guess is flagged; binary data is refused;
// DOCX text is extracted with a bounded scanner (no XML parser, so no entity-expansion attacks); nothing is silently truncated.
// UNVERIFIED: not compiled or run in the environment where it was written.

import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.CharBuffer
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction
import java.util.zip.ZipInputStream

object DocCore {
    val TEXT_EXT = setOf("txt", "md", "json", "csv", "xml", "html", "htm", "css", "js", "ts", "py", "java", "kt", "c", "cpp", "h", "hpp", "cs", "sql", "log", "yml", "yaml")
    private val TEXT_MIME = Regex("^(text/.*|application/(json|xml|javascript|x-javascript|sql|x-sh|x-yaml|yaml|csv))", RegexOption.IGNORE_CASE)
    val SAVE_MIME = setOf("text/plain", "text/markdown", "text/csv", "application/json", "text/html", "application/pdf", "image/png", "image/jpeg")
    val IMAGE_MIME = setOf("image/jpeg", "image/png", "image/webp", "image/gif")
    const val MAX_DOCX_UNCOMPRESSED = 30L * 1024 * 1024
    const val MAX_ZIP_ENTRIES = 2000

    enum class Kind { TEXT, PDF, DOCX, ZIP, MISMATCH, UNKNOWN }

    fun extOf(name: String): String {
        val i = name.lastIndexOf('.')
        return if (i < 0 || i == name.length - 1 || name.length - i > 9) "" else name.substring(i + 1).lowercase()
    }

    fun isPdf(head: ByteArray, n: Int) = n >= 5 && head[0] == '%'.code.toByte() && head[1] == 'P'.code.toByte() && head[2] == 'D'.code.toByte() && head[3] == 'F'.code.toByte() && head[4] == '-'.code.toByte()
    fun isZip(head: ByteArray, n: Int) = n >= 4 && head[0] == 0x50.toByte() && head[1] == 0x4b.toByte() && head[2] == 3.toByte() && head[3] == 4.toByte()

    fun sniff(name: String, mime: String, head: ByteArray, n: Int, allowUnknown: Boolean): Kind {
        val ext = extOf(name)
        if (isPdf(head, n)) return Kind.PDF
        if (isZip(head, n)) return if (ext == "docx" || mime.contains("wordprocessingml")) Kind.DOCX else Kind.ZIP
        if (ext == "pdf" || ext == "docx") return Kind.MISMATCH
        if (ext in TEXT_EXT || TEXT_MIME.containsMatchIn(mime)) return Kind.TEXT
        return if (allowUnknown) Kind.TEXT else Kind.UNKNOWN
    }

    /** Cheap hint for pickers (name and MIME only; readFile does the real sniffing). */
    fun kindHint(name: String, mime: String): String {
        val ext = extOf(name)
        return when { ext == "pdf" -> "pdf"; ext == "docx" -> "docx"; ext in TEXT_EXT || TEXT_MIME.containsMatchIn(mime) -> "text"; else -> "unknown" }
    }

    fun looksBinary(b: ByteArray, n: Int): Boolean {
        val m = minOf(n, 8192)
        if (m == 0) return false
        var bad = 0
        for (i in 0 until m) { val v = b[i].toInt() and 0xff; if (v == 0 || v < 9 || (v in 14..31 && v != 27)) bad++ }
        return bad.toDouble() / m > 0.01
    }

    class Decoded(val text: String, val encoding: String, val guessed: Boolean, val used: Int)

    /** Decodes bytes[0 until n]. Returns null when the content looks binary. With final=false an incomplete UTF-8 sequence at the end is left unconsumed (used < n). */
    fun decode(bytes: ByteArray, n: Int, final: Boolean): Decoded? {
        if (n >= 2 && (bytes[0].toInt() and 0xff) == 0xff && (bytes[1].toInt() and 0xff) == 0xfe) return Decoded(String(bytes, 2, n - 2, Charsets.UTF_16LE), "utf-16le", false, n)
        if (n >= 2 && (bytes[0].toInt() and 0xff) == 0xfe && (bytes[1].toInt() and 0xff) == 0xff) return Decoded(String(bytes, 2, n - 2, Charsets.UTF_16BE), "utf-16be", false, n)
        if (looksBinary(bytes, n)) return null
        val start = if (n >= 3 && (bytes[0].toInt() and 0xff) == 0xef && (bytes[1].toInt() and 0xff) == 0xbb && (bytes[2].toInt() and 0xff) == 0xbf) 3 else 0
        val dec = Charsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT)
        val input = ByteBuffer.wrap(bytes, start, n - start)
        val out = CharBuffer.allocate(n - start + 1)
        val res = dec.decode(input, out, final)
        if (!res.isError) {
            if (final) dec.flush(out)
            out.flip()
            return Decoded(out.toString(), "utf-8", false, input.position())
        }
        // Not valid UTF-8: read it as windows-1252 and SAY it was a guess, never pretend the bytes were UTF-8.
        val latin = Charset.forName("windows-1252")
        return Decoded(String(bytes, start, n - start, latin), "windows-1252", true, n)
    }

    class DocxResult(val text: String, val truncated: Boolean)

    class DocxException(val code: String, message: String) : Exception(message)

    fun extractDocx(input: InputStream, maxChars: Int): DocxResult {
        val zip = ZipInputStream(input)
        var entries = 0
        while (true) {
            val e = zip.nextEntry ?: throw DocxException("unsupported_file_type", "This is not a readable DOCX document (no word/document.xml).")
            if (++entries > MAX_ZIP_ENTRIES) throw DocxException("unsupported_file_type", "The document has too many parts to be a normal DOCX.")
            if (e.name != "word/document.xml") continue
            val buf = ByteArrayOutputStream()
            val chunk = ByteArray(16 * 1024)
            var total = 0L
            while (true) {
                val r = zip.read(chunk)
                if (r < 0) break
                total += r
                if (total > MAX_DOCX_UNCOMPRESSED) throw DocxException("file_too_large", "The document expands to more than ${MAX_DOCX_UNCOMPRESSED / 1024 / 1024} MB and was not read.")
                buf.write(chunk, 0, r)
            }
            return docxText(buf.toString("UTF-8"), maxChars)
        }
    }

    fun docxText(xml: String, maxChars: Int): DocxResult {
        val sb = StringBuilder()
        var i = 0
        var truncated = false
        while (i < xml.length) {
            val lt = xml.indexOf('<', i)
            if (lt < 0) break
            val gt = xml.indexOf('>', lt)
            if (gt < 0) break
            val tag = xml.substring(lt + 1, gt)
            i = gt + 1
            if (tag.startsWith("w:t") && (tag.length == 3 || tag[3] == ' ') && !tag.endsWith("/")) {
                val end = xml.indexOf("</w:t>", i)
                if (end < 0) break
                sb.append(unescape(xml.substring(i, end)))
                i = end + 6
            } else if (tag == "w:tab/" || tag == "w:tab" || tag.startsWith("w:tab ")) sb.append('\t')
            else if (tag == "w:br/" || tag == "w:br" || tag.startsWith("w:br ") || tag == "w:cr/" || tag == "w:cr") sb.append('\n')
            else if (tag == "/w:p") sb.append('\n')
            if (sb.length > maxChars) { truncated = true; sb.setLength(maxChars); break }
        }
        return DocxResult(sb.toString(), truncated)
    }

    fun unescape(s: String): String {
        if (s.indexOf('&') < 0) return s
        val out = StringBuilder(s.length)
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c != '&') { out.append(c); i++; continue }
            val semi = s.indexOf(';', i)
            if (semi < 0 || semi - i > 10) { out.append(c); i++; continue }
            val ent = s.substring(i + 1, semi)
            val rep: String? = when {
                ent == "lt" -> "<"; ent == "gt" -> ">"; ent == "amp" -> "&"; ent == "quot" -> "\""; ent == "apos" -> "'"
                ent.startsWith("#x") || ent.startsWith("#X") -> ent.substring(2).toIntOrNull(16)?.takeIf { it in 1..0x10FFFF }?.let { String(Character.toChars(it)) }
                ent.startsWith("#") -> ent.substring(1).toIntOrNull()?.takeIf { it in 1..0x10FFFF }?.let { String(Character.toChars(it)) }
                else -> null
            }
            if (rep == null) { out.append(c); i++ } else { out.append(rep); i = semi + 1 }
        }
        return out.toString()
    }

    /** Null when the name is not acceptable for a user-visible file. */
    fun sanitizeFilename(n: String): String? {
        val s = n.filter { it.code >= 32 }.trim()
        if (s.isEmpty() || s.length > 100 || s == "." || s == ".." || s.startsWith(".")) return null
        if (s.any { it in "\\/:*?\"<>|" }) return null
        return s
    }

    fun validMimeFilter(m: String): Boolean = Regex("^[\\w.+-]+/[\\w.+*-]+$").matches(m)
}
