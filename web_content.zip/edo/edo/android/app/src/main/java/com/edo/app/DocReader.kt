package com.edo.app

// Reads user-chosen documents through ContentResolver (Storage Access Framework URIs held in ContentRefs). Bounded memory: a request never
// reads more than maxBytes (hard cap HARD_MAX); a bigger file is refused with file_too_large unless the caller reads it in pieces with
// offset/length, so nothing is silently cut off. PDF text extraction is NOT included (see ocr.extract for page OCR). Nothing is executed.
// UNVERIFIED: not compiled or run in the environment where it was written.

import android.content.ContentResolver
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream

class DocReader(private val cr: ContentResolver) {
    class Meta(val name: String, val size: Long, val mime: String)

    companion object {
        const val HARD_MAX = 5_000_000L
        const val DOCX_MAX_FILE = 20_000_000L
        const val DOCX_MAX_CHARS = 2_000_000
    }

    fun inspect(uri: Uri): Meta {
        var name = "file"
        var size = -1L
        try {
            cr.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    name = c.getString(0) ?: name
                    size = if (c.isNull(1)) -1L else c.getLong(1)
                }
            }
        } catch (_: Exception) { /* some providers refuse the query; the name stays generic */ }
        return Meta(name.take(120), size, cr.getType(uri) ?: "")
    }

    private fun open(uri: Uri): InputStream = try {
        cr.openInputStream(uri) ?: throw BridgeException("native_error", "The file could not be opened.")
    } catch (e: SecurityException) {
        throw BridgeException("permission_denied", "Access to that file is no longer granted. Pick it again.")
    } catch (e: IOException) {
        throw BridgeException("native_error", "The file could not be opened.")
    }

    fun read(e: ContentRefs.Entry, maxBytesIn: Long, offset: Long, length: Long?, allowUnknown: Boolean, cancelled: () -> Boolean): JSONObject {
        val maxBytes = maxBytesIn.coerceIn(1L, HARD_MAX)
        val size = e.size
        val head = ByteArray(16)
        var hn = 0
        open(e.uri).use { s -> hn = readFully(s, head, 16) }
        if (hn == 0) return emptyResult(e)
        return when (DocCore.sniff(e.name, e.mime, head, hn, allowUnknown)) {
            DocCore.Kind.PDF -> throw BridgeException("unsupported_file_type", "PDF text extraction needs a PDF library this build does not include. Use ocr.extract to read pages as images.")
            DocCore.Kind.DOCX -> readDocx(e, size, cancelled)
            DocCore.Kind.ZIP -> throw BridgeException("unsupported_file_type", "Archives are not read.")
            DocCore.Kind.MISMATCH -> throw BridgeException("unsupported_file_type", "The file name says one type but the content is another, so it was not read.")
            DocCore.Kind.UNKNOWN -> throw BridgeException("unsupported_file_type", "Unrecognised file type. Pass allowUnknownText only if you know it is text.")
            DocCore.Kind.TEXT -> readText(e, size, maxBytes, offset, length, cancelled)
        }
    }

    private fun emptyResult(e: ContentRefs.Entry): JSONObject = JSONObject().put("name", e.name).put("kind", "text").put("mime", e.mime).put("encoding", "utf-8")
        .put("text", "").put("empty", true).put("size", 0).put("offset", 0).put("bytesRead", 0).put("nextOffset", 0).put("eof", true).put("partial", false).put("truncated", false)

    private fun readDocx(e: ContentRefs.Entry, size: Long, cancelled: () -> Boolean): JSONObject {
        if (size > DOCX_MAX_FILE) throw BridgeException("file_too_large", "The document is $size bytes; the DOCX limit is $DOCX_MAX_FILE.")
        if (cancelled()) throw BridgeException("cancelled", "Cancelled.")
        val r = try {
            open(e.uri).use { DocCore.extractDocx(it, DOCX_MAX_CHARS) }
        } catch (x: DocCore.DocxException) {
            throw BridgeException(x.code, x.message ?: "The document could not be read.")
        } catch (x: IOException) {
            throw BridgeException("unsupported_file_type", "The document is damaged or not a real DOCX.")
        }
        return JSONObject().put("name", e.name).put("kind", "docx").put("mime", e.mime).put("encoding", "utf-8").put("text", r.text).put("size", size)
            .put("offset", 0).put("bytesRead", size).put("nextOffset", size).put("eof", true).put("partial", false).put("truncated", r.truncated)
            .put("note", if (r.truncated) "Text was cut at ${DOCX_MAX_CHARS} characters. Tables, images and headers are not extracted." else "Plain text only; tables, images, headers and footnotes are not extracted.")
    }

    private fun readText(e: ContentRefs.Entry, size: Long, maxBytes: Long, offset: Long, length: Long?, cancelled: () -> Boolean): JSONObject {
        val ranged = length != null
        if (size >= 0 && offset > size) throw IllegalArgumentException("offset is beyond the end of the file")
        if (!ranged && size >= 0 && size - offset > maxBytes) {
            throw BridgeException("file_too_large", "The file is $size bytes and the limit is $maxBytes. Read it in pieces with offset and length.")
        }
        val want = if (ranged) minOf(length!!, maxBytes) else maxBytes + 1
        val buf = ByteArrayOutputStream()
        var hitEof = false
        open(e.uri).use { s ->
            skipFully(s, offset)
            val chunk = ByteArray(64 * 1024)
            var total = 0L
            while (total < want) {
                if (cancelled()) throw BridgeException("cancelled", "Cancelled.")
                val r = s.read(chunk, 0, minOf(chunk.size.toLong(), want - total).toInt())
                if (r < 0) { hitEof = true; break }
                buf.write(chunk, 0, r)
                total += r
            }
        }
        val bytes = buf.toByteArray()
        if (!ranged && bytes.size > maxBytes) throw BridgeException("file_too_large", "The file is larger than the limit of $maxBytes bytes. Read it in pieces with offset and length.")
        if (bytes.isEmpty()) return emptyResult(e).put("offset", offset).put("nextOffset", offset)
        val final = hitEof || (size >= 0 && offset + bytes.size >= size)
        val d = DocCore.decode(bytes, bytes.size, final) ?: throw BridgeException("unsupported_file_type", "The content looks binary, not text.")
        val next = offset + d.used
        val eof = if (size >= 0) next >= size else (hitEof && d.used == bytes.size)
        return JSONObject().put("name", e.name).put("kind", "text").put("mime", e.mime).put("encoding", d.encoding).put("encodingGuessed", d.guessed)
            .put("text", d.text).put("size", size).put("offset", offset).put("bytesRead", d.used).put("nextOffset", next).put("eof", eof)
            .put("partial", !eof).put("truncated", false)
    }

    private fun readFully(s: InputStream, b: ByteArray, n: Int): Int {
        var t = 0
        while (t < n) { val r = s.read(b, t, n - t); if (r < 0) break; t += r }
        return t
    }

    private fun skipFully(s: InputStream, n: Long) {
        var left = n
        while (left > 0) {
            val k = s.skip(left)
            if (k <= 0) { if (s.read() < 0) throw IOException("offset beyond end"); left-- } else left -= k
        }
    }
}
