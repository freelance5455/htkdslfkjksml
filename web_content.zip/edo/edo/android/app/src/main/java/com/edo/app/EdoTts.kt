package com.edo.app

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

// Android TextToSpeech wrapper: picks an installed voice for the requested language (preferring on-device voices),
// supports rate and pitch, reports progress to VoiceHub, and can be interrupted. speak() blocks the calling worker
// thread until the utterance ends, fails or is stopped, which is what the bridge's request/response model needs.
// UNVERIFIED: not compiled or run in the environment where it was written.
class EdoTts private constructor(ctx: Context) {
    private val appCtx = ctx.applicationContext
    private var tts: TextToSpeech? = null
    @Volatile private var ready = false
    @Volatile private var failed = false
    private val initLatch = CountDownLatch(1)
    @Volatile private var current: CountDownLatch? = null
    @Volatile private var currentError: String? = null

    init {
        tts = TextToSpeech(appCtx) { status ->
            ready = status == TextToSpeech.SUCCESS
            failed = !ready
            if (ready) {
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { VoiceHub.setSpeaking(true) }
                    override fun onDone(utteranceId: String?) { finish(null) }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { finish("tts_error") }
                    override fun onStop(utteranceId: String?, interrupted: Boolean) { finish(if (interrupted) "interrupted" else null) }
                })
            }
            initLatch.countDown()
        }
    }

    private fun finish(err: String?) {
        currentError = err
        VoiceHub.setSpeaking(false)
        current?.countDown()
    }

    private fun awaitReady() {
        if (!initLatch.await(5, TimeUnit.SECONDS) || !ready) throw BridgeException("unavailable", "Text-to-speech is not available on this device")
    }

    fun voices(): JSONArray {
        awaitReady()
        val out = JSONArray()
        (tts?.voices ?: emptySet<Voice>()).take(120).forEach { v ->
            out.put(JSONObject().put("name", v.name).put("lang", v.locale.toLanguageTag())
                .put("local", !v.isNetworkConnectionRequired).put("quality", v.quality))
        }
        return out
    }

    private fun chooseVoice(lang: String, wanted: String?): Voice? {
        val all = tts?.voices ?: return null
        if (!wanted.isNullOrBlank()) all.firstOrNull { it.name == wanted }?.let { return it }
        val tag = lang.replace('_', '-')
        val base = tag.substringBefore('-').lowercase(Locale.ROOT)
        return all.sortedByDescending { v ->
            val l = v.locale.toLanguageTag()
            (if (l.equals(tag, true)) 4 else if (l.substringBefore('-').equals(base, true)) 2 else 0) +
                (if (!v.isNetworkConnectionRequired) 2 else 0) + (v.quality / 100)
        }.firstOrNull()
    }

    fun speak(text: String, lang: String, rate: Double, pitch: Double, voiceName: String?): JSONObject {
        awaitReady()
        val t = tts ?: throw BridgeException("unavailable", "Text-to-speech is not available")
        if (text.isBlank()) throw IllegalArgumentException("text is empty")
        stop()
        val voice = chooseVoice(lang, voiceName)
        if (voice != null) t.voice = voice else t.language = Locale.forLanguageTag(lang)
        t.setSpeechRate(rate.coerceIn(0.4, 2.5).toFloat())
        t.setPitch(pitch.coerceIn(0.5, 2.0).toFloat())
        val latch = CountDownLatch(1)
        current = latch
        currentError = null
        val id = "edo-" + System.nanoTime()
        if (t.speak(text.take(3900), TextToSpeech.QUEUE_FLUSH, null, id) != TextToSpeech.SUCCESS) {
            current = null
            throw BridgeException("native_error", "TextToSpeech refused the request")
        }
        latch.await(2, TimeUnit.MINUTES)
        val err = currentError
        current = null
        if (err == "interrupted") throw BridgeException("cancelled", "speech was stopped")
        if (err != null) throw BridgeException("native_error", "speech failed")
        return JSONObject().put("spoken", true).put("voice", voice?.name ?: JSONObject.NULL)
    }

    fun stop() { tts?.stop() }

    fun shutdown() { tts?.shutdown(); tts = null }

    companion object {
        @Volatile private var instance: EdoTts? = null
        fun get(ctx: Context): EdoTts = instance ?: synchronized(this) { instance ?: EdoTts(ctx).also { instance = it } }
    }
}
