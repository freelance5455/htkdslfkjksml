package com.edo.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

// Shows a reminder the user scheduled through scheduleReminder. Not exported: only EDO's own PendingIntents reach it.
// Reminders use inexact alarms (no special permission), so they can fire a little late, and they are NOT restored after a reboot.
// UNVERIFIED: not compiled or run in the environment where it was written.
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("edo_reminder", "EDO reminders", NotificationManager.IMPORTANCE_DEFAULT))
        val n = Notification.Builder(ctx, "edo_reminder")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(intent.getStringExtra("title") ?: "EDO reminder")
            .setContentText(intent.getStringExtra("text") ?: "")
            .setAutoCancel(true).build()
        nm.notify(intent.getIntExtra("rid", 0) + 5000, n)
    }
}
