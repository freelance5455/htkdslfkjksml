package com.edo.app

// Native capability bridge (protocol v2). Copy this zip's index.html and the core/, knowledge/, memory/, tools/, bridge/, voice/,
// ui/, workers/ and media/ folders into app/src/main/assets/edo/ (the copyEdoAssets Gradle task does it). minSdk 26.
// UNVERIFIED: this file has not been compiled or run on a device or emulator in the environment where it was written.
//
// Protocol: JS calls EDOAndroid.invoke(id, method, jsonArgs). The native side answers with __edoBridgeResult(id, ok, payload):
//   ok=true  → payload is a JSON object string (the result)
//   ok=false → payload is {"code": <typed code>, "message": "..."}  with code one of
//              unavailable | permission_denied | unsupported | invalid_arguments | not_found | timeout | native_error | cancelled
// Long operations may call __edoBridgeProgress(id, json) first; unsolicited events go through __edoBridgeEvent(name, json).
// A request answered after the page was replaced is dropped (session check on the JS side, destroyed flag here).
//
// Safety rules enforced here:
//  * Only the bundled page (file:///android_asset/edo/) may call the bridge; any other URL gets permission_denied.
//  * A phone call needs {"confirmed": true} (sent only after the user taps the confirmation card). Emergency numbers
//    (EMERGENCY set below) never use ACTION_CALL: they open the dialer only.
//  * Permissions are requested only through requestPermissions, which the UI calls from an explicit button.
//  * Nothing destructive is offered: no delete, no silent install, no SMS, no settings writes.
//
// Manifest permissions used (see AndroidManifest.xml): INTERNET, ACCESS_FINE_LOCATION, RECORD_AUDIO, READ_CONTACTS, CALL_PHONE,
// POST_NOTIFICATIONS, READ_CALENDAR, ACCESS_NETWORK_STATE, FOREGROUND_SERVICE, FOREGROUND_SERVICE_MICROPHONE.
// CALL_PHONE is a runtime permission. EDO never asks for it silently: the user taps "Enable device access" in the panel
// (requestPermissions below), and without it call() falls back to the dialer so a call is never blocked.

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.provider.Settings
import android.media.AudioManager
import android.view.KeyEvent
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.FutureTask
import java.util.concurrent.TimeUnit

class BridgeException(val code: String, message: String) : Exception(message)

class EdoBridge(private val act: Activity, private val web: WebView, private val isTrusted: () -> Boolean) {

    class Request(val id: Int, val method: String) { @Volatile var cancelled = false; @Volatile var gen = 0 }

    companion object {
        const val VERSION = 3 // v3 adds refs, readFile, images, OCR, speech recognition, save-as, allowlisted app actions; v2 clients still work
        // changes whenever the process restarts; JS compares it to detect a new native session and cancels in-flight calls
        val SESSION: Long = System.currentTimeMillis()
        const val RC_PICK_FILE = 7001
        const val RC_PICK_TREE = 7002
        const val RC_PICK_IMAGE = 7003
        const val RC_CAPTURE = 7004
        const val RC_SAVE = 7005
        private const val MAX_ARGS_CHARS = 14_000_000
        // operations that open a system UI or the microphone: only one at a time
        private val EXCLUSIVE = setOf("pickFile", "pickProject", "pickImage", "captureImage", "speech.start", "download.save", "requestPermission", "requestPermissions")
        private const val MAX_FILE_BYTES = 400_000
        private const val MAX_FILES = 3000
        private const val MAX_TOTAL_BYTES = 25_000_000L
        private const val BATCH_BYTES = 350_000
    }

    private val pending = ConcurrentHashMap<Int, Request>()
    @Volatile private var destroyed = false
    private val picks = ConcurrentHashMap<Int, java.util.concurrent.CompletableFuture<Intent?>>()
    private val emergency = setOf("100", "101", "102", "108", "112", "911", "999", "000")
    private val generation = java.util.concurrent.atomic.AtomicInteger(0) // bumped on every page load; replies for older generations are dropped
    private val exclusiveHolder = java.util.concurrent.atomic.AtomicInteger(0)
    private val executor = java.util.concurrent.ThreadPoolExecutor(2, 6, 30L, java.util.concurrent.TimeUnit.SECONDS, java.util.concurrent.LinkedBlockingQueue<Runnable>(32)).apply { allowCoreThreadTimeOut(true) }
    private val refs = ContentRefs()
    private val docs = DocReader(act.contentResolver)
    private val images = ImageIntake(act, refs) { r, c, i -> launchPicker(r, c, i) }
    private val ocr = OcrEngine(act, refs) { id, j -> progress(id, j) }
    private val speech = SpeechSession(act) { n, p -> emitEvent(n, p) }
    private val gate = PermissionGate(act)
    private val saveAs = SaveAs(act) { r, c, i -> launchPicker(r, c, i) }
    private val safeIntents = SafeIntents(act) { n -> openApp(n) }

    val methods = listOf(
        "ping", "capabilities", "deviceInfo", "openApp", "notify", "findContact", "call", "permissions", "requestPermissions",
        "cancel", "appList", "batteryStatus", "networkStatus", "clipboardRead", "clipboardWrite", "share", "openSettings",
        "calendarEvents", "calendarInsert", "pickFile", "pickProject", "mediaControl", "scheduleReminder", "cancelReminder",
        "mic.state", "voice.status", "voice.configureWake", "voice.service", "tts.speak", "tts.stop", "tts.voices",
        "requestPermission", "readFile", "pickImage", "captureImage", "image.data", "ocr.extract", "speech.start", "speech.stop", "download.save", "openSupported", "ref.release"
    )
    private val methodSet = methods.toSet()

    fun destroy() {
        destroyed = true
        pending.values.forEach { it.cancelled = true }
        picks.values.forEach { it.complete(null) }
        speech.cancel()
        gate.cancelAll()
        ocr.close()
        refs.clear() // also deletes temporary camera files
        executor.shutdownNow()
        VoiceHub.detach()
    }

    // The page (re)loaded: its JavaScript state is gone, so nothing started by the old page may answer the new one.
    fun pageChanged() {
        generation.incrementAndGet()
        pending.values.forEach { it.cancelled = true }
        picks.values.forEach { it.complete(null) }
        speech.cancel()
        gate.cancelAll()
        refs.clear()
    }

    // The activity left the screen: nothing may keep listening. System pickers also pause the activity, so they are NOT cancelled here.
    fun onHostPause() { speech.cancel() }

    // Called by MainActivity.onResume so voice events (wake word, state) reach the page.
    fun attachEvents() {
        VoiceHub.attach(VoiceHub.Sink { name, payload -> emitEvent(name, payload) })
        emitEvent("lifecycle.resume", JSONObject().put("session", SESSION))
    }
    fun detachEvents() { VoiceHub.detach() }

    fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        picks.remove(requestCode)?.complete(if (resultCode == Activity.RESULT_OK) (data ?: Intent()) else null) // camera apps return OK with no data
    }

    fun onPermissionResult() { emitEvent("permissions.changed", permissionStatus()) }
    fun onPermissionResult(requestCode: Int, results: IntArray) { gate.onResult(requestCode, results); onPermissionResult() }

    // ---- entry point -------------------------------------------------------------------------------------------------
    @JavascriptInterface
    fun invoke(id: Int, method: String, args: String) {
        if (destroyed) return
        if (!isTrusted()) { replyError(id, "permission_denied", "The bridge only answers the bundled EDO page."); return }
        if (id <= 0 || method.length > 40 || method !in methodSet) { replyError(id, "unsupported", "Unknown method."); return }
        if (args.length > MAX_ARGS_CHARS) { replyError(id, "invalid_arguments", "The request is too large."); return }
        val req = Request(id, method)
        req.gen = generation.get()
        if (pending.putIfAbsent(id, req) != null) { replyError(id, "invalid_arguments", "Duplicate request id."); return }
        val exclusive = method in EXCLUSIVE
        if (exclusive && !exclusiveHolder.compareAndSet(0, id)) { pending.remove(id); replyError(id, "busy", "Another interactive operation is still running."); return }
        try {
            executor.execute { runRequest(req, args) }
        } catch (e: java.util.concurrent.RejectedExecutionException) {
            pending.remove(id)
            if (exclusive) exclusiveHolder.compareAndSet(id, 0)
            replyError(id, "busy", "EDO is handling too many requests. Try again.")
        }
    }

    private fun runRequest(req: Request, args: String) {
        val id = req.id
        // A reply belongs to the page that asked. If the page reloaded meanwhile (generation changed) it is dropped, never delivered to a new request with the same id.
        fun send(ok: Boolean, payload: String) { if (req.gen == generation.get()) reply(id, ok, payload) }
        fun fail(code: String, message: String) = send(false, JSONObject().put("code", code).put("message", message).toString())
        try {
            val a = if (args.isBlank()) JSONObject() else JSONObject(args)
            if (a.optInt("_v", VERSION) > VERSION) throw BridgeException("unsupported", "This app speaks protocol $VERSION; the page asked for a newer one.")
            val out = dispatch(req, a)
            if (!req.cancelled) send(true, out.toString()) else fail("cancelled", "Cancelled: ${req.method}")
        } catch (e: BridgeException) {
            fail(e.code, e.message ?: e.code)
        } catch (e: SecurityException) {
            fail("permission_denied", "Android denied that action.")
        } catch (e: JSONException) {
            fail("invalid_arguments", "Bad arguments for ${req.method}.")
        } catch (e: IllegalArgumentException) {
            fail("invalid_arguments", e.message ?: "invalid arguments")
        } catch (e: Exception) {
            fail("native_error", "Internal error (${e.javaClass.simpleName}).") // class name only: no stack trace, path or content leaves native code
        } finally {
            pending.remove(id)
            exclusiveHolder.compareAndSet(id, 0)
        }
    }

    private fun dispatch(req: Request, a: JSONObject): JSONObject = when (req.method) {
        "capabilities" -> capabilities()
        "ping" -> JSONObject().put("ok", true).put("engine", "edo").put("version", VERSION)
        "cancel" -> cancel(a.getInt("target"))
        "deviceInfo" -> deviceInfo()
        "openApp" -> openApp(a.getString("name"))
        "notify" -> notify(a.optString("title", "EDO"), a.getString("text"))
        "findContact" -> findContact(a.getString("query"))
        "call" -> call(a.getString("number"), a.optBoolean("confirmed", false))
        "permissions" -> permissionStatus()
        "requestPermissions" -> requestGroup(a.optString("group", "core"))
        "appList" -> appList()
        "batteryStatus" -> batteryStatus()
        "networkStatus" -> networkStatus()
        "clipboardRead" -> clipboardRead()
        "clipboardWrite" -> clipboardWrite(a.getString("text"))
        "share" -> share(a.optString("text", ""), a.optString("title", "Share"), a.optString("ref", "").ifBlank { null })
        "openSettings" -> openSettings(a.getString("section"))
        "calendarEvents" -> calendarEvents(a.getLong("from"), a.getLong("to"), a.optInt("limit", 30))
        "calendarInsert" -> calendarInsert(a.getString("title"), a.getLong("begin"), a.optLong("end", a.getLong("begin") + 3_600_000L), a.optString("description", ""))
        "pickFile" -> pickFile(req, a)
        "pickProject" -> pickProject(req)
        "mediaControl" -> mediaControl(a.getString("action"))
        "scheduleReminder" -> scheduleReminder(a.getInt("id"), a.optString("title", "EDO reminder"), a.optString("text", ""), a.getLong("at"))
        "cancelReminder" -> cancelReminder(a.getInt("id"))
        "mic.state" -> micState()
        "voice.status" -> VoiceHub.snapshot().put("microphonePermission", has(Manifest.permission.RECORD_AUDIO))
        "voice.configureWake" -> configureWake(a)
        "voice.service" -> voiceService(a.getString("action"))
        "tts.speak" -> EdoTts.get(act).speak(a.getString("text"), a.optString("lang", "en-IN"), a.optDouble("rate", 1.0), a.optDouble("pitch", 1.0), a.optString("voice", "").ifBlank { null })
        "tts.stop" -> { EdoTts.get(act).stop(); JSONObject().put("stopped", true) }
        "tts.voices" -> JSONObject().put("voices", EdoTts.get(act).voices())
        "requestPermission" -> gate.request(a.getString("permission"), req)
        "readFile" -> readFile(req, a)
        "pickImage" -> images.pick(req, a.optBoolean("multiple", false), a.optInt("maxImages", 4).coerceIn(1, 10))
        "captureImage" -> images.capture(req)
        "image.data" -> images.data(a.getString("ref"), a.optInt("maxDimension", 1024).coerceIn(64, 2048), a.optInt("quality", 80).coerceIn(30, 95))
        "ocr.extract" -> ocrExtract(req, a)
        "speech.start" -> speechStart(req, a)
        "speech.stop" -> speech.stop()
        "download.save" -> saveAs.save(req, a)
        "openSupported" -> safeIntents.open(a)
        "ref.release" -> JSONObject().put("released", refs.release(a.getString("ref")))
        else -> throw BridgeException("unsupported", "Unknown method: ${req.method}")
    }

    @Suppress("DEPRECATION")
    private fun deviceInfo(): JSONObject {
        val o = JSONObject().put("model", Build.MODEL).put("manufacturer", Build.MANUFACTURER).put("android", Build.VERSION.RELEASE).put("sdk", Build.VERSION.SDK_INT)
            .put("language", java.util.Locale.getDefault().toLanguageTag()).put("package", act.packageName) // no serials, IMEI, advertising or Android IDs
        try {
            val pi = act.packageManager.getPackageInfo(act.packageName, 0)
            o.put("versionName", pi.versionName ?: JSONObject.NULL)
            o.put("versionCode", if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else pi.versionCode.toLong())
        } catch (_: Exception) { }
        return o
    }

    private fun readFile(req: Request, a: JSONObject): JSONObject {
        val e = refs.get(a.getString("ref")) ?: throw BridgeException("not_found", "That file reference is unknown or was released.")
        val length = if (a.has("length") && !a.isNull("length")) a.getLong("length").coerceIn(1L, DocReader.HARD_MAX) else null
        return docs.read(e, a.optLong("maxBytes", 1_048_576L), a.optLong("offset", 0L).coerceAtLeast(0L), length, a.optBoolean("allowUnknownText", false)) { req.cancelled }
    }

    private fun ocrExtract(req: Request, a: JSONObject): JSONObject {
        val arr = a.optJSONArray("refs") ?: throw IllegalArgumentException("refs is required")
        val list = (0 until arr.length()).map { arr.getString(it) }.take(10)
        if (list.isEmpty()) throw IllegalArgumentException("refs is empty")
        val d = a.optString("detail", "lines")
        val detail = if (d == "text" || d == "lines" || d == "full") d else "lines"
        return ocr.extract(req.id, list, detail, a.optInt("maxDimension", 2048).coerceIn(512, 4096), a.optInt("maxPages", 5).coerceIn(1, 20)) { req.cancelled }
    }

    private fun speechStart(req: Request, a: JSONObject): JSONObject {
        need(Manifest.permission.RECORD_AUDIO, "Microphone")
        return speech.start(req, a.optString("lang", "en-IN").take(16), a.optBoolean("partial", true), a.optLong("maxMs", 30_000L).coerceIn(2_000L, 120_000L), a.optBoolean("preferOffline", false))
    }

    private fun st(state: String, detail: String = "") = JSONObject().put("state", state).put("detail", detail)

    // Honest per-capability states for the page (SUPPORTED | UNAVAILABLE | PERMISSION_REQUIRED | NOT_INITIALIZED | UNSUPPORTED_ENVIRONMENT).
    private fun capStates(): JSONObject {
        val camera = act.packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY) && Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE).resolveActivity(act.packageManager) != null
        val sr = speech.available()
        return JSONObject()
            .put("fileRead", st("SUPPORTED", "System file picker. Text files and DOCX; PDF only through OCR."))
            .put("imagePick", st("SUPPORTED", "System document picker."))
            .put("imageCapture", if (camera) st("SUPPORTED", "Uses the system camera app.") else st("UNAVAILABLE", "No camera or camera app on this device."))
            .put("ocr", st("SUPPORTED", "ML Kit on-device, Latin script only, no confidence scores."))
            .put("speechRecognition", if (!sr) st("UNAVAILABLE", "No speech recognition service is enabled.") else if (!has(Manifest.permission.RECORD_AUDIO)) st("PERMISSION_REQUIRED", "Microphone permission is needed.") else st("SUPPORTED", "Android may use a network recognition service."))
            .put("textToSpeech", st("NOT_INITIALIZED", "Starts on first use; speak() reports any failure."))
            .put("share", st("SUPPORTED", "Android share sheet."))
            .put("clipboardWrite", st("SUPPORTED"))
            .put("clipboardRead", st("SUPPORTED", "Only when the page asks after a user action; Android 10+ also limits background reads."))
            .put("appLaunch", st("SUPPORTED", "Allowlisted: app by name, maps, https links, email compose, dialer."))
            .put("settings", st("SUPPORTED", "Opens a Settings screen; changes nothing."))
            .put("download", st("SUPPORTED", "Save-as dialog; the user picks the place."))
            .put("permissions", st("SUPPORTED"))
    }

    // ---- replies -----------------------------------------------------------------------------------------------------
    private fun reply(id: Int, ok: Boolean, payload: String) {
        if (destroyed) return
        act.runOnUiThread {
            if (!destroyed) web.evaluateJavascript("__edoBridgeResult($id,$ok,${JSONObject.quote(payload)})", null)
        }
    }
    private fun replyError(id: Int, code: String, message: String) = reply(id, false, JSONObject().put("code", code).put("message", message).toString())
    private fun progress(id: Int, json: JSONObject) {
        if (destroyed) return
        act.runOnUiThread { if (!destroyed) web.evaluateJavascript("__edoBridgeProgress($id,${JSONObject.quote(json.toString())})", null) }
    }
    fun emitEvent(name: String, payload: JSONObject) {
        if (destroyed) return
        act.runOnUiThread { if (!destroyed) web.evaluateJavascript("__edoBridgeEvent(${JSONObject.quote(name)},${JSONObject.quote(payload.toString())})", null) }
    }

    private fun cancel(target: Int): JSONObject {
        val r = pending[target]
        r?.cancelled = true
        if (r != null && r.method in setOf("pickFile", "pickProject", "pickImage", "captureImage", "download.save")) { picks.values.forEach { it.complete(null) } }
        if (r != null && r.method == "speech.start") speech.cancel()
        if (r != null && r.method == "tts.speak") EdoTts.get(act).stop()
        return JSONObject().put("cancelRequested", r != null)
    }

    // ---- capabilities and permissions ----------------------------------------------------------------------------------
    private fun capabilities(): JSONObject {
        val engine = WakeWordEngines.create(act)
        return JSONObject()
            .put("methods", JSONArray(methods))
            .put("version", VERSION)
            .put("session", SESSION)
            .put("permissions", permissionStatus())
            .put("features", JSONObject()
                .put("nativeVoice", true)
                .put("wakeWordEngine", engine?.name ?: JSONObject.NULL)
                .put("customWakePhrase", engine?.supportsCustomPhrase ?: false)
                .put("tts", true)
                .put("pickProject", true)
                .put("calendarRead", has(Manifest.permission.READ_CALENDAR))
                .put("sdk", Build.VERSION.SDK_INT)
                .put("caps", capStates()))
    }

    private fun has(p: String) = act.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun permissionStatus(): JSONObject = JSONObject()
        .put("calls", has(Manifest.permission.CALL_PHONE))
        .put("contacts", has(Manifest.permission.READ_CONTACTS))
        .put("microphone", has(Manifest.permission.RECORD_AUDIO))
        .put("location", has(Manifest.permission.ACCESS_FINE_LOCATION))
        .put("calendar", has(Manifest.permission.READ_CALENDAR))
        .put("notifications", Build.VERSION.SDK_INT < 33 || has(Manifest.permission.POST_NOTIFICATIONS))

    private fun groupPerms(group: String): List<String> = when (group) {
        "core" -> mutableListOf(Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS, Manifest.permission.RECORD_AUDIO, Manifest.permission.ACCESS_FINE_LOCATION)
            .also { if (Build.VERSION.SDK_INT >= 33) it.add(Manifest.permission.POST_NOTIFICATIONS) }
        "calendar" -> listOf(Manifest.permission.READ_CALENDAR)
        "voice" -> mutableListOf(Manifest.permission.RECORD_AUDIO).also { if (Build.VERSION.SDK_INT >= 33) it.add(Manifest.permission.POST_NOTIFICATIONS) }
        else -> throw IllegalArgumentException("unknown permission group: $group")
    }

    // One system prompt per missing permission, shown only because the user tapped a button that calls this.
    private fun requestGroup(group: String): JSONObject {
        val missing = groupPerms(group).filter { !has(it) }
        if (missing.isNotEmpty()) act.runOnUiThread { act.requestPermissions(missing.toTypedArray(), 10) }
        return permissionStatus().put("requested", JSONArray(missing.map { it.substringAfterLast('.') }))
    }

    private fun need(perm: String, what: String) {
        if (!has(perm)) {
            act.runOnUiThread { act.requestPermissions(arrayOf(perm), 1) }
            throw SecurityException("$what permission not granted yet. I asked you; approve it and retry.")
        }
    }

    private fun <T> onUi(block: () -> T): T {
        val task = FutureTask<T> { block() }
        act.runOnUiThread(task)
        return task.get(5, TimeUnit.SECONDS)
    }

    // ---- apps, contacts, calls, notifications -----------------------------------------------------------------------------
    private fun launchables() = act.packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)

    private fun appList(): JSONObject {
        val pm = act.packageManager
        val arr = JSONArray()
        launchables().map { Pair(it.loadLabel(pm).toString(), it.activityInfo.packageName) }.sortedBy { it.first.lowercase() }.take(300)
            .forEach { arr.put(JSONObject().put("label", it.first).put("package", it.second)) }
        return JSONObject().put("apps", arr)
    }

    private fun openApp(name: String): JSONObject {
        val pm = act.packageManager
        val q = name.trim()
        if (q.isEmpty()) throw IllegalArgumentException("app name is empty")
        val apps = launchables()
        // exact label, then label prefix, then substring, then package name ("whatsapp" finds "WhatsApp Business" last)
        val match = apps.firstOrNull { it.loadLabel(pm).toString().equals(q, true) }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().startsWith(q, true) }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().contains(q, true) }
            ?: apps.firstOrNull { it.activityInfo.packageName.equals(q, true) }
            ?: throw BridgeException("not_found", "No launchable app named \"$name\" found")
        val intent = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: throw BridgeException("not_found", "App has no launch intent")
        act.runOnUiThread { act.startActivity(intent) }
        return JSONObject().put("opened", match.loadLabel(pm).toString())
    }

    private fun notify(title: String, text: String): JSONObject {
        if (Build.VERSION.SDK_INT >= 33) need(Manifest.permission.POST_NOTIFICATIONS, "Notification")
        val nm = act.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("edo", "EDO", NotificationManager.IMPORTANCE_DEFAULT))
        nm.notify(System.currentTimeMillis().toInt(), Notification.Builder(act, "edo")
            .setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title.take(80)).setContentText(text.take(300)).build())
        return JSONObject().put("shown", true)
    }

    private fun findContact(q: String): JSONObject {
        need(Manifest.permission.READ_CONTACTS, "Contacts")
        val res = JSONArray()
        act.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$q%"), null)?.use { c ->
            while (c.moveToNext() && res.length() < 5) res.put(JSONObject().put("name", c.getString(0)).put("number", c.getString(1)))
        }
        return JSONObject().put("matches", res)
    }

    // Direct call only when CALL_PHONE is granted AND the page says the user confirmed; otherwise the dialer with the number
    // filled in (no permission needed). Emergency numbers always go through the dialer; Android does not allow ACTION_CALL for them.
    private fun call(raw: String, confirmed: Boolean): JSONObject {
        val number = raw.filter { it.isDigit() || it == '+' }
        if (number.length < 3 || number.length > 15) throw IllegalArgumentException("That doesn't look like a phone number")
        val granted = has(Manifest.permission.CALL_PHONE)
        val direct = granted && confirmed && number !in emergency
        val intent = Intent(if (direct) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.fromParts("tel", number, null))
        act.runOnUiThread { act.startActivity(intent) }
        return JSONObject().put("mode", if (direct) "call" else "dial").put("number", number)
            .put("permissionNeeded", !granted && number !in emergency)
    }

    // ---- device status, clipboard, share, settings, media ---------------------------------------------------------------------
    private fun batteryStatus(): JSONObject {
        val i = act.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: throw BridgeException("unavailable", "battery state unavailable")
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        return JSONObject().put("percent", if (level >= 0 && scale > 0) level * 100 / scale else JSONObject.NULL)
            .put("charging", status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL)
    }

    private fun networkStatus(): JSONObject {
        val cm = act.getSystemService(ConnectivityManager::class.java)
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        return JSONObject().put("online", caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET))
            .put("wifi", caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ?: false)
            .put("cellular", caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ?: false)
            .put("metered", cm.isActiveNetworkMetered)
    }

    // Clipboard reads are privacy-sensitive: the JS side only calls this from an explicit "paste" action by the user.
    // Android also limits background reads, so this works only while EDO is on screen.
    private fun clipboardRead(): JSONObject = onUi {
        val cm = act.getSystemService(ClipboardManager::class.java)
        val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(act)?.toString()
        JSONObject().put("text", (t ?: "").take(20000)).put("empty", t.isNullOrEmpty())
    }

    private fun clipboardWrite(text: String): JSONObject = onUi {
        if (text.length > 100000) throw IllegalArgumentException("text is too long to copy (max 100000 characters)") // never truncate silently
        act.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("EDO", text))
        JSONObject().put("copied", true)
    }

    private fun share(text: String, title: String, ref: String?): JSONObject {
        if (text.length > 100000) throw IllegalArgumentException("text is too long to share (max 100000 characters)")
        if (text.isEmpty() && ref == null) throw IllegalArgumentException("nothing to share")
        val send = Intent(Intent.ACTION_SEND)
        val e = if (ref != null) (refs.get(ref) ?: throw BridgeException("not_found", "Unknown file reference.")) else null
        if (e != null) {
            send.setType(e.mime.ifBlank { "application/octet-stream" }).putExtra(Intent.EXTRA_STREAM, e.uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            send.clipData = android.content.ClipData.newRawUri("", e.uri)
            if (text.isNotEmpty()) send.putExtra(Intent.EXTRA_TEXT, text)
        } else send.setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
        val chooser = Intent.createChooser(send, title.take(60))
        if (e != null) chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        act.runOnUiThread { act.startActivity(chooser) } // the user picks the target and confirms there
        return JSONObject().put("chooserShown", true)
    }

    private fun openSettings(section: String): JSONObject {
        val i = when (section) {
            "wifi" -> Intent(Settings.ACTION_WIFI_SETTINGS)
            "bluetooth" -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            "notifications" -> Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, act.packageName)
            "app" -> Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", act.packageName, null))
            "battery" -> Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)
            "location" -> Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
            "display" -> Intent(Settings.ACTION_DISPLAY_SETTINGS)
            else -> throw IllegalArgumentException("unknown settings section: $section")
        }
        act.runOnUiThread { act.startActivity(i) } // opens a Settings screen only; EDO changes nothing
        return JSONObject().put("opened", section)
    }

    private fun mediaControl(action: String): JSONObject {
        val key = when (action) {
            "play_pause" -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            "stop" -> KeyEvent.KEYCODE_MEDIA_STOP
            else -> throw IllegalArgumentException("unknown media action: $action")
        }
        val am = act.getSystemService(AudioManager::class.java)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, key))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, key))
        return JSONObject().put("sent", action)
    }

    // ---- calendar and reminders --------------------------------------------------------------------------------------------
    private fun calendarEvents(from: Long, to: Long, limit: Int): JSONObject {
        need(Manifest.permission.READ_CALENDAR, "Calendar")
        if (to < from || to - from > 366L * 86_400_000L) throw IllegalArgumentException("range must be positive and at most one year")
        val uri = CalendarContract.Instances.CONTENT_URI.buildUpon().also { ContentUris_append(it, from); ContentUris_append(it, to) }.build()
        val out = JSONArray()
        act.contentResolver.query(uri, arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN, CalendarContract.Instances.END, CalendarContract.Instances.ALL_DAY),
            null, null, "${CalendarContract.Instances.BEGIN} ASC")?.use { c ->
            while (c.moveToNext() && out.length() < limit.coerceIn(1, 100))
                out.put(JSONObject().put("title", c.getString(0) ?: "").put("begin", c.getLong(1)).put("end", c.getLong(2)).put("allDay", c.getInt(3) == 1))
        }
        return JSONObject().put("events", out)
    }
    private fun ContentUris_append(b: Uri.Builder, v: Long) { android.content.ContentUris.appendId(b, v) }

    // Opens the calendar's own "new event" screen pre-filled. The user reviews and saves it there; EDO needs no write permission.
    private fun calendarInsert(title: String, begin: Long, end: Long, description: String): JSONObject {
        val i = Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
            .putExtra(CalendarContract.Events.TITLE, title.take(120)).putExtra(CalendarContract.Events.DESCRIPTION, description.take(500))
            .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, begin).putExtra(CalendarContract.EXTRA_EVENT_END_TIME, end)
        act.runOnUiThread { act.startActivity(i) }
        return JSONObject().put("editorShown", true)
    }

    private fun reminderIntent(id: Int, title: String, text: String): PendingIntent = PendingIntent.getBroadcast(
        act, id, Intent(act, ReminderReceiver::class.java).putExtra("title", title).putExtra("text", text).putExtra("rid", id),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    // Inexact alarm: may fire minutes late, and is lost if the phone restarts. Needs notification permission to be visible.
    private fun scheduleReminder(id: Int, title: String, text: String, at: Long): JSONObject {
        if (Build.VERSION.SDK_INT >= 33) need(Manifest.permission.POST_NOTIFICATIONS, "Notification")
        if (at < System.currentTimeMillis() + 5_000L) throw IllegalArgumentException("reminder time is in the past")
        act.getSystemService(AlarmManager::class.java).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, reminderIntent(id, title, text))
        return JSONObject().put("scheduledFor", at).put("exact", false).put("survivesReboot", false)
    }

    private fun cancelReminder(id: Int): JSONObject {
        act.getSystemService(AlarmManager::class.java).cancel(reminderIntent(id, "", ""))
        return JSONObject().put("cancelled", true)
    }

    // ---- voice -------------------------------------------------------------------------------------------------------------
    private fun micState() = JSONObject().put("permission", has(Manifest.permission.RECORD_AUDIO))
        .put("serviceRunning", VoiceHub.serviceRunning).put("listening", VoiceHub.listening)

    private fun configureWake(a: JSONObject): JSONObject {
        val prefs = act.getSharedPreferences(VoiceService.PREFS, Context.MODE_PRIVATE)
        val phrase = a.optString("phrase", "Hey EDO").trim()
        if (phrase.length < 4 || phrase.length > 40) throw IllegalArgumentException("wake phrase must be 4 to 40 characters")
        prefs.edit().putString("phrase", phrase).putFloat("threshold", a.optDouble("threshold", 0.7).coerceIn(0.3, 0.99).toFloat()).apply()
        if (!a.optBoolean("enabled", false)) { VoiceService.stop(act); return JSONObject().put("engineAvailable", WakeWordEngines.available(act)).put("running", false) }
        need(Manifest.permission.RECORD_AUDIO, "Microphone")
        val engine = WakeWordEngines.create(act)
            ?: return JSONObject().put("engineAvailable", false).put("running", false)
                .put("reason", "This build has no wake-word engine. See WakeWordEngine.kt to add one.")
        act.runOnUiThread { VoiceService.start(act) }
        return JSONObject().put("engineAvailable", true).put("engine", engine.name).put("running", true).put("customPhrase", engine.supportsCustomPhrase)
    }

    private fun voiceService(action: String): JSONObject {
        when (action) {
            "stop" -> VoiceService.stop(act)
            "start" -> { need(Manifest.permission.RECORD_AUDIO, "Microphone"); if (WakeWordEngines.available(act)) act.runOnUiThread { VoiceService.start(act) } else throw BridgeException("unsupported", "no wake-word engine in this build") }
            else -> throw IllegalArgumentException("action must be start or stop")
        }
        return VoiceHub.snapshot()
    }

    // ---- file and project pickers ---------------------------------------------------------------------------------------------
    private fun launchPicker(req: Request, code: Int, intent: Intent): Intent? {
        val f = java.util.concurrent.CompletableFuture<Intent?>()
        picks[code] = f
        act.runOnUiThread { act.startActivityForResult(intent, code) }
        val deadline = System.currentTimeMillis() + 5 * 60_000L
        while (!f.isDone) {
            if (req.cancelled || System.currentTimeMillis() > deadline) { picks.remove(code); throw BridgeException(if (req.cancelled) "cancelled" else "timeout", "file picker closed") }
            Thread.sleep(150)
        }
        return f.get()
    }

    private fun looksLikeText(name: String): Boolean = Regex(".*\\.(js|mjs|cjs|jsx|ts|tsx|py|cs|java|kt|kts|c|h|cc|cpp|hpp|go|rs|json|html|css|xml|gradle|yml|yaml|md|txt|csproj|sln|shader|cginc|meta|unity|prefab|asset|gitignore)$", RegexOption.IGNORE_CASE).matches(name) ||
        name.equals("Dockerfile", true) || name.equals("Makefile", true) || name.equals(".gitignore", true)

    // System file picker (Storage Access Framework). Returns opaque refs; the legacy v2 fields (name/size/mime/text of the first file) are kept.
    private fun pickFile(req: Request, a: JSONObject): JSONObject {
        val multiple = a.optBoolean("multiple", false)
        val max = a.optInt("maxFiles", 5).coerceIn(1, 20)
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*").putExtra(Intent.EXTRA_ALLOW_MULTIPLE, multiple)
        val types = a.optJSONArray("mimeTypes")
        if (types != null) {
            val list = (0 until minOf(types.length(), 10)).map { types.optString(it, "") }.filter { DocCore.validMimeFilter(it) }
            if (list.isNotEmpty()) intent.putExtra(Intent.EXTRA_MIME_TYPES, list.toTypedArray())
        }
        val data = launchPicker(req, RC_PICK_FILE, intent)
        val chosen = ArrayList<Uri>()
        val clip = data?.clipData
        if (clip != null) for (k in 0 until clip.itemCount) clip.getItemAt(k).uri?.let { chosen.add(it) }
        if (chosen.isEmpty()) data?.data?.let { chosen.add(it) }
        if (chosen.isEmpty()) throw BridgeException("cancelled", "no file was chosen")
        val files = JSONArray()
        var first: ContentRefs.Entry? = null
        for (uri in chosen.take(max)) {
            val m = docs.inspect(uri)
            val e = ContentRefs.Entry(uri, m.name, m.mime, m.size, null)
            if (first == null) first = e
            files.put(JSONObject().put("ref", refs.add(e)).put("name", m.name).put("size", m.size).put("mime", m.mime).put("kind", DocCore.kindHint(m.name, m.mime)))
        }
        val f0 = files.getJSONObject(0)
        val out = JSONObject().put("files", files).put("ref", f0.getString("ref")).put("name", f0.getString("name")).put("size", f0.getLong("size")).put("mime", f0.getString("mime"))
        if (a.optBoolean("readText", false) && first != null) {
            try { out.put("text", docs.read(first, MAX_FILE_BYTES.toLong(), 0L, null, false) { req.cancelled }.optString("text", "")) } catch (_: BridgeException) { /* too big or not text: the ref is still returned */ }
        }
        return out
    }

    private val skipDirs = setOf("node_modules", ".git", "build", "dist", "out", "bin", "obj", "library", "temp", "logs", "usersettings", ".gradle", ".idea", ".vs", "__pycache__", "venv", ".venv", "target", "pods")

    // Lets the user choose a folder, walks it (bounded), and streams source files to the page in batches through
    // "project.files" events. EDO reads text files only and never writes to the folder.
    private fun pickProject(req: Request): JSONObject {
        val data = launchPicker(req, RC_PICK_TREE, Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        val tree = data?.data ?: throw BridgeException("cancelled", "no folder was chosen")
        val rootId = DocumentsContract.getTreeDocumentId(tree)
        var files = 0; var bytes = 0L; var skipped = 0
        val batch = JSONArray(); var batchBytes = 0
        fun flush() {
            if (batch.length() == 0) return
            emitEvent("project.files", JSONObject().put("request", req.id).put("files", JSONArray(batch.toString())))
            while (batch.length() > 0) batch.remove(0)
            batchBytes = 0
        }
        fun walk(docId: String, prefix: String) {
            if (req.cancelled) return
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
            val rows = ArrayList<Array<String>>()
            act.contentResolver.query(children, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE, DocumentsContract.Document.COLUMN_SIZE), null, null, null)?.use { c ->
                while (c.moveToNext()) rows.add(arrayOf(c.getString(0), c.getString(1) ?: "", c.getString(2) ?: "", if (c.isNull(3)) "-1" else c.getLong(3).toString()))
            }
            for (r in rows) {
                if (req.cancelled || files >= MAX_FILES || bytes >= MAX_TOTAL_BYTES) return
                val isDir = r[2] == DocumentsContract.Document.MIME_TYPE_DIR
                val path = if (prefix.isEmpty()) r[1] else prefix + "/" + r[1]
                if (isDir) { if (r[1].lowercase() in skipDirs) { skipped++; continue }; walk(r[0], path); continue }
                val size = r[3].toLong()
                if (!looksLikeText(r[1]) || size > MAX_FILE_BYTES) { skipped++; continue }
                val uri = DocumentsContract.buildDocumentUriUsingTree(tree, r[0])
                val text = try { act.contentResolver.openInputStream(uri)?.use { String(it.readBytes(), Charsets.UTF_8) } } catch (_: Exception) { null }
                if (text == null) { skipped++; continue }
                batch.put(JSONObject().put("path", path).put("content", text))
                files++; bytes += text.length; batchBytes += text.length
                if (batchBytes >= BATCH_BYTES) { flush(); progress(req.id, JSONObject().put("files", files).put("bytes", bytes)) }
            }
        }
        walk(rootId, "")
        flush()
        if (req.cancelled) throw BridgeException("cancelled", "project loading cancelled")
        return JSONObject().put("files", files).put("bytes", bytes).put("skipped", skipped)
            .put("truncated", files >= MAX_FILES || bytes >= MAX_TOTAL_BYTES)
            .put("name", DocumentsContract.getTreeDocumentId(tree).substringAfterLast(':'))
    }
}
