package com.edo.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient

// Hosts the WebView. Hardening: only the bundled page may use the bridge (isTrusted checks the current URL), file and content
// access are off, in-WebView navigation to anything else is refused and handed to the system browser, and a crashed
// renderer recreates the activity instead of leaving a dead page with a live bridge.
// UNVERIFIED: not compiled or run in the environment where it was written.
class MainActivity : Activity() {
    private lateinit var web: WebView
    private var bridge: EdoBridge? = null
    @Volatile private var currentUrl: String = ""

    private val trustedPrefix = "file:///android_asset/edo/"

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this)
        setContentView(web)
        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false              // android_asset URLs do not need it
            allowContentAccess = false
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
            mediaPlaybackRequiresUserGesture = false  // lets the muted intro video autoplay
            setSupportMultipleWindows(false)
            javaScriptCanOpenWindowsAutomatically = false
        }
        WebView.setWebContentsDebuggingEnabled(false)
        bridge = EdoBridge(this, web) { currentUrl.startsWith(trustedPrefix) }
        // The bridge is exposed to whatever page loads, so only ever load the bundled asset (and see isTrusted above).
        web.addJavascriptInterface(bridge!!, "EDOAndroid")
        web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(v: WebView, url: String, favicon: android.graphics.Bitmap?) {
                currentUrl = url
                if (url.startsWith(trustedPrefix)) bridge?.pageChanged() // a (re)load wipes the page's JS state: stale native work must not answer the new page
            }
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                // External links leave the app. intent: links (used for app deep links) are parsed, hardened,
                // and fall back to their browser_fallback_url (usually the Play Store page) if the app is missing.
                if (!r.isForMainFrame) return true // the page uses no frames (CSP frame-src none); never launch or load anything for a subframe
                val url = r.url
                if (url.toString().startsWith(trustedPrefix)) return false
                if ((url.scheme ?: "") !in setOf("https", "intent", "mailto", "tel", "geo")) return true // file:, content:, javascript:, data: and the rest are refused
                try {
                    val i = if (url.scheme == "intent") Intent.parseUri(url.toString(), Intent.URI_INTENT_SCHEME)
                            else Intent(Intent.ACTION_VIEW, url)
                    i.addCategory(Intent.CATEGORY_BROWSABLE)
                    i.component = null
                    i.selector = null
                    startActivity(i)
                } catch (e: Exception) {
                    val fb = if (url.scheme == "intent")
                        Regex("S\\.browser_fallback_url=([^;]+)").find(url.toString())?.groupValues?.get(1) else null
                    if (fb != null) try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(Uri.decode(fb)))) } catch (_: Exception) {}
                }
                return true
            }
            override fun onRenderProcessGone(v: WebView, d: RenderProcessGoneDetail): Boolean {
                // The WebView process died: drop the dead bridge and rebuild the whole activity.
                bridge?.destroy()
                runOnUiThread { recreate() }
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(o: String, cb: GeolocationPermissions.Callback) {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) cb.invoke(o, true, false)
                else { requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 2); cb.invoke(o, false, false) }
            }
            override fun onPermissionRequest(r: PermissionRequest) {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) r.grant(r.resources)
                else { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 3); r.deny() }
            }
        }
        if (b == null) web.loadUrl(trustedPrefix + "index.html") else web.restoreState(b)
    }

    override fun onSaveInstanceState(out: Bundle) { super.onSaveInstanceState(out); web.saveState(out) }
    override fun onResume() { super.onResume(); bridge?.attachEvents() }
    override fun onPause() { bridge?.onHostPause(); bridge?.detachEvents(); super.onPause() }
    override fun onDestroy() { bridge?.destroy(); web.removeJavascriptInterface("EDOAndroid"); web.destroy(); super.onDestroy() }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        bridge?.onActivityResult(requestCode, resultCode, data)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        bridge?.onPermissionResult(requestCode, grantResults)
    }

    // Back first goes to the page (it closes sheets and panels, returns from a project view); only when the page has nothing to close does the app leave.
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.__edoBack ? window.__edoBack() : false)") { r ->
            if (r != "true") { @Suppress("DEPRECATION") super.onBackPressed() }
        }
    }
}
