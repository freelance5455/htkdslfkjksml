package com.edo.app

// Opaque references to user-chosen files and images. JavaScript only ever sees "ref_..." tokens; it can never pass a path or a
// content:// URI to native code, so a hostile page cannot ask EDO to read anything the user did not pick in a system dialog.
// Entries live in memory only (bounded), are dropped when the page reloads or the activity is destroyed, and temporary camera files
// are deleted with them. UNVERIFIED: not compiled or run in the environment where it was written.

import android.net.Uri
import java.io.File
import java.security.SecureRandom

class ContentRefs {
    class Entry(val uri: Uri, val name: String, val mime: String, val size: Long, val tempFile: File?)

    private val rnd = SecureRandom()
    private val map = LinkedHashMap<String, Entry>()

    fun add(e: Entry): String {
        val bytes = ByteArray(12)
        rnd.nextBytes(bytes)
        val ref = "ref_" + bytes.joinToString("") { "%02x".format(it) }
        synchronized(map) {
            map[ref] = e
            while (map.size > MAX) {
                val oldest = map.keys.iterator().next()
                map.remove(oldest)?.tempFile?.delete()
            }
        }
        return ref
    }

    fun get(ref: String): Entry? = if (PATTERN.matches(ref)) synchronized(map) { map[ref] } else null

    fun release(ref: String): Boolean {
        val e = synchronized(map) { map.remove(ref) } ?: return false
        e.tempFile?.delete()
        return true
    }

    fun clear() {
        val all = synchronized(map) { val c = map.values.toList(); map.clear(); c }
        all.forEach { it.tempFile?.delete() }
    }

    companion object {
        const val MAX = 50
        val PATTERN = Regex("^ref_[A-Za-z0-9]{8,64}$")
    }
}
