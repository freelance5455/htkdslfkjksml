package com.edo.app

// One-shot speech recognition with Android's SpeechRecognizer. It only listens while a request is open and the activity is on screen:
// pausing the activity cancels it, and nothing records in the background. Android may send the audio to a recognition service (often
// Google's); EDO cannot tell whether a given recognizer works offline, so callers should say so. The RECORD_AUDIO permission is
// requested by EdoBridge.need() before start() is reached. All SpeechRecognizer calls run on the main thread, as the API requires.
// UNVERIFIED: not compiled or run in the environment where it was written.

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CompletableFuture
import java.util.concurrent.ExecutionException
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

class SpeechSession(private val act: Activity, private val emit: (String, JSONObject) -> Unit) {
    @Volatile private var active = false
    @Volatile private var future: CompletableFuture<JSONObject>? = null
    private var recognizer: SpeechRecognizer? = null // touched only on the main thread

    fun available(): Boolean = SpeechRecognizer.isRecognitionAvailable(act)
    fun isActive(): Boolean = active

    fun start(req: EdoBridge.Request, lang: String, partial: Boolean, maxMs: Long, preferOffline: Boolean): JSONObject {
        if (!available()) throw BridgeException("unavailable", "No speech recognition service is installed or enabled on this device.")
        if (VoiceHub.serviceRunning) throw BridgeException("busy", "The wake-word service is using the microphone. Turn it off first.")
        synchronized(this) {
            if (active) throw BridgeException("busy", "Speech recognition is already running.")
            active = true
        }
        val f = CompletableFuture<JSONObject>()
        future = f
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang.replace('_', '-'))
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, partial)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, preferOffline)
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, act.packageName)
        act.runOnUiThread {
            try {
                val r = SpeechRecognizer.createSpeechRecognizer(act)
                recognizer = r
                r.setRecognitionListener(listener(req.id, f))
                r.startListening(intent)
            } catch (e: Exception) {
                f.completeExceptionally(BridgeException("speech_failed", "Speech recognition could not start."))
            }
        }
        val deadline = System.currentTimeMillis() + maxMs + 5000
        try {
            while (true) {
                if (req.cancelled) { cancelNow(); throw BridgeException("cancelled", "Cancelled.") }
                if (System.currentTimeMillis() > deadline) { cancelNow(); throw BridgeException("timeout", "Speech recognition did not finish in time.") }
                try { return f.get(100, TimeUnit.MILLISECONDS) } catch (_: TimeoutException) { /* keep waiting */ }
            }
        } catch (e: ExecutionException) {
            val c = e.cause
            throw if (c is BridgeException) c else BridgeException("speech_failed", "Speech recognition failed.")
        } finally {
            teardown()
            active = false
            future = null
            emit("speech.state", JSONObject().put("state", "idle").put("request", req.id))
        }
    }

    private fun listener(id: Int, f: CompletableFuture<JSONObject>) = object : RecognitionListener {
        override fun onReadyForSpeech(p: Bundle?) { emit("speech.state", JSONObject().put("state", "listening").put("request", id)) }
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() { emit("speech.state", JSONObject().put("state", "processing").put("request", id)) }
        override fun onEvent(t: Int, p: Bundle?) {}
        override fun onPartialResults(b: Bundle?) {
            val l = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            if (!l.isNullOrEmpty()) emit("speech.partial", JSONObject().put("request", id).put("text", l[0]))
        }
        override fun onResults(b: Bundle?) {
            val l = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            if (l.isNullOrEmpty()) { f.completeExceptionally(BridgeException("speech_failed", "No speech was recognised.")); return }
            val r = JSONObject().put("text", l[0]).put("alternatives", JSONArray(l.drop(1).take(4)))
            val c = b?.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES)
            if (c != null && c.isNotEmpty() && c[0] >= 0f) r.put("confidence", c[0].toDouble()) // only when the recognizer really supplies one
            f.complete(r)
        }
        override fun onError(code: Int) {
            f.completeExceptionally(when (code) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> BridgeException("permission_denied", "Microphone permission is required.")
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> BridgeException("busy", "The recognition service is busy.")
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> BridgeException("speech_failed", "No speech was detected.")
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER -> BridgeException("speech_failed", "The recognition service needs a network connection or is unavailable.")
                else -> BridgeException("speech_failed", "Speech recognition failed (code $code).")
            })
        }
    }

    /** Ask the recogniser to finish and deliver what it has. Safe to call at any time. */
    fun stop(): JSONObject {
        val was = active
        act.runOnUiThread { try { recognizer?.stopListening() } catch (_: Exception) { } }
        return JSONObject().put("stopped", true).put("wasListening", was)
    }

    /** Discard the session (host paused, page reloaded, activity destroyed). */
    fun cancel() {
        future?.completeExceptionally(BridgeException("cancelled", "Speech recognition stopped."))
        cancelNow()
    }

    private fun cancelNow() { act.runOnUiThread { try { recognizer?.cancel() } catch (_: Exception) { } } }

    private fun teardown() {
        act.runOnUiThread {
            try { recognizer?.destroy() } catch (_: Exception) { }
            recognizer = null
        }
    }
}
