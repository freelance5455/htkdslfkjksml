package com.edo.app

// Image selection and capture. Gallery images come from the system document picker (no storage permission); photos use the system camera
// app through ACTION_IMAGE_CAPTURE, so EDO needs no CAMERA permission and records nothing itself. Camera output goes to a private cache
// file shared through FileProvider and is deleted when its ref is released, the page reloads, or the activity is destroyed (stale files
// are purged on the next capture). Images are decoded with bounded size, EXIF orientation applied, and bitmaps recycled.
// UNVERIFIED: not compiled or run in the environment where it was written.

import android.app.Activity
import android.content.ContentResolver
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.provider.MediaStore
import android.util.Base64
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException

object ImageDecode {
    const val MAX_PIXELS = 50_000_000L

    fun orientation(cr: ContentResolver, uri: Uri): Int = try {
        cr.openInputStream(uri)?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL) } ?: ExifInterface.ORIENTATION_NORMAL
    } catch (_: Exception) { ExifInterface.ORIENTATION_NORMAL }

    fun bounds(cr: ContentResolver, uri: Uri): IntArray {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        try { cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) } } catch (_: IOException) { }
        return intArrayOf(o.outWidth, o.outHeight)
    }

    /** Decodes at no more than about maxDim on the long edge and returns an upright bitmap. The caller must recycle it. */
    fun decode(cr: ContentResolver, uri: Uri, maxDim: Int): Bitmap {
        val b = bounds(cr, uri)
        val w = b[0]
        val h = b[1]
        if (w <= 0 || h <= 0) throw BridgeException("unsupported_file_type", "That is not an image Android can decode.")
        if (w.toLong() * h > ImageDecode.MAX_PIXELS) throw BridgeException("file_too_large", "The image is larger than ${ImageDecode.MAX_PIXELS / 1_000_000} megapixels.")
        var sample = 1
        while (maxOf(w, h) / (sample * 2) >= maxDim) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888 }
        var bmp: Bitmap = try {
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: throw BridgeException("native_error", "The image could not be opened.")
        } catch (e: OutOfMemoryError) {
            throw BridgeException("file_too_large", "Not enough memory to decode this image.")
        }
        val longEdge = maxOf(bmp.width, bmp.height)
        val matrix = Matrix()
        var changed = false
        if (longEdge > maxDim) { val k = maxDim.toFloat() / longEdge; matrix.postScale(k, k); changed = true }
        when (orientation(cr, uri)) {
            ExifInterface.ORIENTATION_ROTATE_90 -> { matrix.postRotate(90f); changed = true }
            ExifInterface.ORIENTATION_ROTATE_180 -> { matrix.postRotate(180f); changed = true }
            ExifInterface.ORIENTATION_ROTATE_270 -> { matrix.postRotate(270f); changed = true }
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> { matrix.postScale(-1f, 1f); changed = true }
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> { matrix.postScale(1f, -1f); changed = true }
        }
        if (changed) {
            val out = try { Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, matrix, true) } catch (e: OutOfMemoryError) { bmp.recycle(); throw BridgeException("file_too_large", "Not enough memory to process this image.") }
            if (out !== bmp) bmp.recycle()
            bmp = out
        }
        return bmp
    }
}

class ImageIntake(private val act: Activity, private val refs: ContentRefs, private val launch: (EdoBridge.Request, Int, Intent) -> Intent?) {
    private val cr: ContentResolver get() = act.contentResolver

    private fun uris(data: Intent?): List<Uri> {
        val out = ArrayList<Uri>()
        val clip = data?.clipData
        if (clip != null) for (i in 0 until clip.itemCount) clip.getItemAt(i).uri?.let { out.add(it) }
        if (out.isEmpty()) data?.data?.let { out.add(it) }
        return out
    }

    private fun describe(ref: String, e: ContentRefs.Entry): JSONObject {
        val b = ImageDecode.bounds(cr, e.uri)
        return JSONObject().put("ref", ref).put("name", e.name).put("size", e.size).put("mime", e.mime)
            .put("width", b[0]).put("height", b[1]).put("orientation", ImageDecode.orientation(cr, e.uri))
    }

    fun pick(req: EdoBridge.Request, multiple: Boolean, max: Int): JSONObject {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
            .putExtra(Intent.EXTRA_MIME_TYPES, DocCore.IMAGE_MIME.toTypedArray()).putExtra(Intent.EXTRA_ALLOW_MULTIPLE, multiple)
        val data = launch(req, EdoBridge.RC_PICK_IMAGE, i)
        val chosen = uris(data).take(max)
        if (chosen.isEmpty()) throw BridgeException("cancelled", "No image was chosen.")
        val reader = DocReader(cr)
        val arr = JSONArray()
        for (u in chosen) {
            val m = reader.inspect(u)
            if (m.mime !in DocCore.IMAGE_MIME) continue // the picker filter is advisory; the real type is checked here
            val e = ContentRefs.Entry(u, m.name, m.mime, m.size, null)
            arr.put(describe(refs.add(e), e))
        }
        if (arr.length() == 0) throw BridgeException("unsupported_file_type", "Only JPEG, PNG, WebP and GIF images are supported.")
        return JSONObject().put("images", arr)
    }

    fun capture(req: EdoBridge.Request): JSONObject {
        if (!act.packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY)) throw BridgeException("unavailable", "This device has no camera.")
        val dir = File(act.cacheDir, "edo-capture").apply { mkdirs() }
        purgeStale(dir)
        val file = File.createTempFile("cap_", ".jpg", dir)
        val uri = FileProvider.getUriForFile(act, act.packageName + ".edofiles", file)
        val i = Intent(MediaStore.ACTION_IMAGE_CAPTURE).putExtra(MediaStore.EXTRA_OUTPUT, uri)
            .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        if (i.resolveActivity(act.packageManager) == null) { file.delete(); throw BridgeException("unavailable", "No camera app is available.") }
        try {
            launch(req, EdoBridge.RC_CAPTURE, i)
        } catch (e: BridgeException) { file.delete(); throw e }
        if (file.length() <= 0L) { file.delete(); throw BridgeException("cancelled", "No photo was taken.") }
        val e = ContentRefs.Entry(uri, "photo.jpg", "image/jpeg", file.length(), file)
        return JSONObject().put("images", JSONArray().put(describe(refs.add(e), e)))
    }

    fun data(ref: String, maxDim: Int, quality: Int): JSONObject {
        val e = refs.get(ref) ?: throw BridgeException("not_found", "That image reference is unknown or was released.")
        val bmp = ImageDecode.decode(cr, e.uri, maxDim)
        try {
            val out = ByteArrayOutputStream()
            if (!bmp.compress(Bitmap.CompressFormat.JPEG, quality, out)) throw BridgeException("native_error", "The image could not be encoded.")
            if (out.size() > 6_000_000) throw BridgeException("file_too_large", "The encoded image is too large; lower maxDimension.")
            return JSONObject().put("base64", Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)).put("width", bmp.width).put("height", bmp.height)
        } finally { bmp.recycle() }
    }

    private fun purgeStale(dir: File) {
        val cutoff = System.currentTimeMillis() - 60 * 60 * 1000L
        dir.listFiles()?.forEach { if (it.isFile && it.lastModified() < cutoff) it.delete() }
    }
}
