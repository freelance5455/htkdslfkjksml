package com.edo.app

import android.app.Application

// Register a wake-word engine here when you add one (see WakeWordEngine.kt):
//     WakeWordEngines.register { ctx -> PorcupineEngine(ctx) }
class EdoApp : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
