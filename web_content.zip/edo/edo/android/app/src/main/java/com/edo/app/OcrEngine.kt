package com.edo.app

// On-device text recognition with Google ML Kit (com.google.mlkit:text-recognition, bundled Latin-script model; no network, nothing leaves
// the phone). It returns blocks/lines/elements with bounding boxes in the coordinates of the processed (upright, possibly downscaled)
// image and reports image size so boxes can be mapped back. ML Kit's API used here gives NO confidence scores, so none are reported.
// PDFs are rendered page by page with PdfRenderer (a platform API) and each page is recognised as an image: this is OCR of rendered pages,
// not extraction of embedded text, and is limited to maxPages. A recognition already running cannot be interrupted; cancellation takes
// effect between images and pages.
// UNVERIFIED: not compiled or run in the environment where it was written.

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.ExecutionException
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

class OcrEngine(private val act: Activity, private val refs: ContentRefs, private val progress: (Int, JSONObject) -> Unit) {
    private val lazyRecognizer = lazy<TextRecognizer> { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    companion object { const val MAX_BLOCKS = 500; const val ENGINE = "mlkit-text-recognition (on-device, Latin script)" }

    fun close() { if (lazyRecognizer.isInitialized()) lazyRecognizer.value.close() }

    fun extract(reqId: Int, refList: List<String>, detail: String, maxDim: Int, maxPages: Int, cancelled: () -> Boolean): JSONObject {
        val t0 = System.currentTimeMillis()
        val results = JSONArray()
        var index = 0
        for (ref in refList) {
            if (cancelled()) throw BridgeException("cancelled", "Cancelled.")
            progress(reqId, JSONObject().put("index", index).put("total", refList.size).put("stage", "reading"))
            val e = refs.get(ref)
            if (e == null) { results.put(failed(ref, index, null, "not_found", "That reference is unknown or was released.")); index++; continue }
            try {
                if (e.mime == "application/pdf" || DocCore.extOf(e.name) == "pdf") pdf(reqId, ref, e, index, refList.size, detail, maxDim, maxPages, cancelled, results)
                else results.put(image(ref, e, index, null, detail, maxDim))
            } catch (x: BridgeException) {
                if (x.code == "cancelled") throw x
                results.put(failed(ref, index, null, if (x.code == "native_error") "ocr_failed" else x.code, x.message ?: "failed"))
            }
            index++
        }
        return JSONObject().put("engine", ENGINE).put("results", results).put("durationMs", System.currentTimeMillis() - t0)
    }

    private fun image(ref: String, e: ContentRefs.Entry, index: Int, page: Int?, detail: String, maxDim: Int): JSONObject {
        val t = System.currentTimeMillis()
        val bmp = ImageDecode.decode(act.contentResolver, e.uri, maxDim)
        try { return recognize(ref, index, page, bmp, detail, t) } finally { bmp.recycle() }
    }

    private fun pdf(reqId: Int, ref: String, e: ContentRefs.Entry, index: Int, total: Int, detail: String, maxDim: Int, maxPages: Int, cancelled: () -> Boolean, out: JSONArray) {
        var pfd: ParcelFileDescriptor? = null
        var renderer: PdfRenderer? = null
        try {
            pfd = act.contentResolver.openFileDescriptor(e.uri, "r") ?: throw BridgeException("ocr_failed", "The PDF could not be opened.")
            renderer = try { PdfRenderer(pfd) } catch (x: SecurityException) { throw BridgeException("ocr_failed", "This PDF is password-protected or not allowed to be read.") } catch (x: IOException) { throw BridgeException("ocr_failed", "This PDF is damaged or the file provider does not allow random access.") }
            val pages = minOf(renderer.pageCount, maxPages)
            for (p in 0 until pages) {
                if (cancelled()) throw BridgeException("cancelled", "Cancelled.")
                progress(reqId, JSONObject().put("index", index).put("total", total).put("stage", "page ${p + 1} of $pages"))
                val t = System.currentTimeMillis()
                val page = renderer.openPage(p)
                var bmp: Bitmap? = null
                try {
                    val scale = minOf(3f, maxDim.toFloat() / maxOf(page.width, page.height))
                    val w = maxOf(1, (page.width * scale).toInt())
                    val h = maxOf(1, (page.height * scale).toInt())
                    bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(Color.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    out.put(recognize(ref, index, p + 1, bmp, detail, t))
                } catch (x: OutOfMemoryError) {
                    out.put(failed(ref, index, p + 1, "file_too_large", "Not enough memory to render this page."))
                } finally { page.close(); bmp?.recycle() }
            }
            if (renderer.pageCount > pages) out.put(JSONObject().put("ref", ref).put("imageId", index).put("page", pages + 1).put("status", "empty").put("text", "").put("blocks", JSONArray())
                .put("error", JSONObject().put("code", "ocr_failed").put("message", "Only the first $pages of ${renderer.pageCount} pages were read.")))
        } finally { renderer?.close(); pfd?.close() }
    }

    private fun recognize(ref: String, index: Int, page: Int?, bmp: Bitmap, detail: String, t0: Long): JSONObject {
        val text = try {
            Tasks.await(lazyRecognizer.value.process(InputImage.fromBitmap(bmp, 0)), 60, TimeUnit.SECONDS)
        } catch (x: ExecutionException) { throw BridgeException("ocr_failed", "Text recognition failed.") }
        catch (x: TimeoutException) { throw BridgeException("ocr_failed", "Text recognition took too long.") }
        catch (x: InterruptedException) { Thread.currentThread().interrupt(); throw BridgeException("cancelled", "Cancelled.") }
        val blocks = JSONArray()
        if (detail != "text") {
            for (b in text.textBlocks.take(MAX_BLOCKS)) {
                val bo = JSONObject().put("text", b.text).put("box", box(b.boundingBox))
                val lines = JSONArray()
                for (l in b.lines) {
                    val lo = JSONObject().put("text", l.text).put("box", box(l.boundingBox))
                    if (detail == "full") {
                        val els = JSONArray()
                        for (el in l.elements) els.put(JSONObject().put("text", el.text).put("box", box(el.boundingBox)))
                        lo.put("elements", els)
                    }
                    lines.put(lo)
                }
                bo.put("lines", lines)
                blocks.put(bo)
            }
        }
        val r = JSONObject().put("ref", ref).put("imageId", index).put("status", if (text.text.isBlank()) "empty" else "ok").put("text", text.text)
            .put("width", bmp.width).put("height", bmp.height).put("blocks", blocks).put("durationMs", System.currentTimeMillis() - t0)
        if (page != null) r.put("page", page)
        return r
    }

    private fun box(r: Rect?): Any = if (r == null) JSONObject.NULL else JSONObject().put("left", r.left).put("top", r.top).put("right", r.right).put("bottom", r.bottom)

    private fun failed(ref: String, index: Int, page: Int?, code: String, msg: String): JSONObject {
        val r = JSONObject().put("ref", ref).put("imageId", index).put("status", "failed").put("text", "").put("blocks", JSONArray())
            .put("error", JSONObject().put("code", code).put("message", msg))
        if (page != null) r.put("page", page)
        return r
    }
}
