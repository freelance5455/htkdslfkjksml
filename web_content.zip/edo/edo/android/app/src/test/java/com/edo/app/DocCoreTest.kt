package com.edo.app

// JVM unit tests for the pure file-handling logic (no Android classes). Run with: ./gradlew :app:testDebugUnitTest
// STATUS: NOT RUN. These were written without a Kotlin compiler or Gradle available, so they have never been compiled or executed.

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class DocCoreTest {
    private fun bytes(vararg v: Int) = ByteArray(v.size) { v[it].toByte() }
    private fun zip(entries: Map<String, String>): ByteArray {
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { z -> entries.forEach { (n, c) -> z.putNextEntry(ZipEntry(n)); z.write(c.toByteArray(Charsets.UTF_8)); z.closeEntry() } }
        return out.toByteArray()
    }

    @Test fun extensionNeverProvesType() {
        val pdf = "%PDF-1.7".toByteArray()
        assertEquals(DocCore.Kind.PDF, DocCore.sniff("notes.txt", "text/plain", pdf, pdf.size, false))
        val text = "just words".toByteArray()
        assertEquals(DocCore.Kind.MISMATCH, DocCore.sniff("fake.pdf", "application/pdf", text, text.size, false))
        assertEquals(DocCore.Kind.MISMATCH, DocCore.sniff("fake.docx", "", text, text.size, false))
        assertEquals(DocCore.Kind.UNKNOWN, DocCore.sniff("data.bin", "application/octet-stream", text, text.size, false))
        assertEquals(DocCore.Kind.TEXT, DocCore.sniff("data.bin", "application/octet-stream", text, text.size, true))
        val z = bytes(0x50, 0x4b, 3, 4, 0)
        assertEquals(DocCore.Kind.DOCX, DocCore.sniff("a.docx", "", z, z.size, false))
        assertEquals(DocCore.Kind.ZIP, DocCore.sniff("a.txt", "text/plain", z, z.size, false))
    }

    @Test fun decodesUnicodeAndKeepsIt() {
        val s = "héllo 世界 \uD83D\uDE00 नमस्ते\r\nx"
        val b = s.toByteArray(Charsets.UTF_8)
        val d = DocCore.decode(b, b.size, true)!!
        assertEquals(s, d.text); assertEquals("utf-8", d.encoding); assertFalse(d.guessed); assertEquals(b.size, d.used)
    }

    @Test fun skipsUtf8BomAndReadsUtf16() {
        val bom = bytes(0xef, 0xbb, 0xbf, 0x68, 0x69)
        assertEquals("hi", DocCore.decode(bom, bom.size, true)!!.text)
        val u16 = bytes(0xff, 0xfe, 0x68, 0x00, 0x69, 0x00)
        val d = DocCore.decode(u16, u16.size, true)!!
        assertEquals("hi", d.text); assertEquals("utf-16le", d.encoding)
    }

    @Test fun incompleteSequenceAtChunkEndIsLeftForTheNextRead() {
        val full = "a\uD83D\uDE00b".toByteArray(Charsets.UTF_8) // 'a' + 4-byte emoji + 'b' = 6 bytes
        val cut = full.copyOf(3) // 'a' + first 2 bytes of the emoji
        val d = DocCore.decode(cut, cut.size, false)!!
        assertEquals("a", d.text); assertEquals(1, d.used)
        val rest = DocCore.decode(full.copyOfRange(d.used, full.size), full.size - d.used, true)!!
        assertEquals("\uD83D\uDE00b", rest.text)
    }

    @Test fun malformedUtf8IsFlaggedAsAGuess() {
        val b = bytes(0x68, 0xff, 0x69)
        val d = DocCore.decode(b, b.size, true)!!
        assertEquals("windows-1252", d.encoding); assertTrue(d.guessed); assertEquals("h\u00ffi", d.text)
    }

    @Test fun binaryContentIsRefused() {
        assertNull(DocCore.decode(ByteArray(300), 300, true))
        assertFalse(DocCore.looksBinary("plain text\n".toByteArray(), 11))
    }

    @Test fun emptyInputDecodesToEmptyText() {
        assertEquals("", DocCore.decode(ByteArray(0), 0, true)!!.text)
    }

    @Test fun docxTextIsExtractedWithParagraphsAndEntities() {
        val xml = "<w:document><w:body><w:p><w:r><w:t>Hello &amp; </w:t></w:r><w:r><w:t xml:space=\"preserve\">world</w:t></w:r></w:p>" +
            "<w:p><w:r><w:t>caf\u00e9 &#x4E16;</w:t></w:r><w:r><w:tab/></w:r><w:r><w:t>x</w:t></w:r></w:p><w:tbl><w:tr/></w:tbl></w:body></w:document>"
        val r = DocCore.extractDocx(ByteArrayInputStream(zip(mapOf("[Content_Types].xml" to "<x/>", "word/document.xml" to xml))), 1000)
        assertEquals("Hello & world\ncaf\u00e9 \u4e16\tx\n", r.text); assertFalse(r.truncated)
    }

    @Test fun docxTruncationIsReportedNotSilent() {
        val xml = "<w:p><w:t>" + "a".repeat(500) + "</w:t></w:p>"
        val r = DocCore.extractDocx(ByteArrayInputStream(zip(mapOf("word/document.xml" to xml))), 100)
        assertTrue(r.truncated); assertEquals(100, r.text.length)
    }

    @Test fun zipWithoutDocumentXmlIsRejected() {
        try { DocCore.extractDocx(ByteArrayInputStream(zip(mapOf("other.xml" to "<x/>"))), 100); fail("expected DocxException") }
        catch (e: DocCore.DocxException) { assertEquals("unsupported_file_type", e.code) }
    }

    @Test fun oversizedDocxIsRefused() {
        val xml = "<w:p><w:t>" + "a".repeat((DocCore.MAX_DOCX_UNCOMPRESSED + 1024).toInt()) + "</w:t></w:p>"
        try { DocCore.extractDocx(ByteArrayInputStream(zip(mapOf("word/document.xml" to xml))), 10); fail("expected DocxException") }
        catch (e: DocCore.DocxException) { assertEquals("file_too_large", e.code) }
    }

    @Test fun corruptedZipIsAnIoErrorNotACrash() {
        try { DocCore.extractDocx(ByteArrayInputStream(bytes(0x50, 0x4b, 3, 4, 9, 9, 9, 9, 9)), 100); fail("expected an exception") }
        catch (e: DocCore.DocxException) { /* acceptable */ } catch (e: java.io.IOException) { /* acceptable */ }
    }

    @Test fun entitiesAreUnescapedSafely() {
        assertEquals("<&>\"'", DocCore.unescape("&lt;&amp;&gt;&quot;&apos;"))
        assertEquals("A\uD83D\uDE00", DocCore.unescape("&#65;&#x1F600;"))
        assertEquals("&bogus; &#0; &#99999999;", DocCore.unescape("&bogus; &#0; &#99999999;"))
    }

    @Test fun fileNamesAreSanitised() {
        assertEquals("notes.txt", DocCore.sanitizeFilename(" notes.txt "))
        for (bad in listOf("", "..", ".hidden", "a/b.txt", "a\\b", "c:x", "a*b", "x".repeat(101), "q?.txt")) assertNull(bad, DocCore.sanitizeFilename(bad))
        assertNotNull(DocCore.sanitizeFilename("r\u00e9sum\u00e9 \u4e16.md"))
    }

    @Test fun mimeFiltersAreChecked() {
        assertTrue(DocCore.validMimeFilter("text/*")); assertTrue(DocCore.validMimeFilter("application/vnd.ms-excel"))
        assertFalse(DocCore.validMimeFilter("not a mime")); assertFalse(DocCore.validMimeFilter("*/*; rm -rf"))
    }

    @Test fun kindHintsComeFromNameAndMimeOnly() {
        assertEquals("pdf", DocCore.kindHint("a.PDF", "")); assertEquals("docx", DocCore.kindHint("a.docx", "")); assertEquals("text", DocCore.kindHint("a.kt", ""))
        assertEquals("text", DocCore.kindHint("noext", "text/plain")); assertEquals("unknown", DocCore.kindHint("a.exe", "application/x-msdownload"))
    }
}
