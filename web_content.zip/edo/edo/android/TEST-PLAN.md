# EDO Android bridge — test plan and status

Honest status: **only the JavaScript unit tests and the static source checks have been run.** Nothing in `android/` has been compiled or executed,
because the environment that produced it had no Android SDK, Gradle or Kotlin compiler. Every row marked **NOT RUN** is a test somebody still has to run.

## Tier 1 — JavaScript unit tests (simulated native host) — RUN
`node tests/run-tests.js` (file `tests/androidbridge.js` plus the older `tests/bridge2.js`). Fake handlers stand in for Kotlin; they prove the JS
contract only. Covers: option validation, version field, concurrent correlation, timeouts, cancellation (promise and AbortSignal), exclusive
operations, malformed replies, missing native bridge, duplicate init/listeners, native-restart recovery, error mapping and sanitising, file
decoding (Unicode, BOM, UTF-16, malformed, binary, empty, large, chunked, disguised PDF/DOCX), OCR/speech normalisation, browser fallbacks.

## Tier 2 — static source checks — RUN
Same command. Reads the Kotlin/manifest/Gradle text: method-list parity with JS, permissions declared, exported components, request validation
steps present, no path/URI accepted from the page, bounded reads, bitmap recycling, FileProvider scope, no CAMERA/storage permissions, WebView flags.
These prove structure and rules, **not behaviour**.

## Tier 3 — Kotlin JVM unit tests — NOT RUN
`./gradlew :app:testDebugUnitTest` → `app/src/test/java/com/edo/app/DocCoreTest.kt` (17 tests: sniffing, Unicode, BOM/UTF-16, chunk boundary,
malformed text, binary, empty, DOCX extraction/truncation/bomb/corruption, entities, file names, MIME filters).

## Tier 4 — emulator tests (instrumented) — NOT RUN, NOT WRITTEN
These need an emulator image with Google Play services (ML Kit, SpeechRecognizer). To be written as `androidTest` once a device is available.

| Area | Case |
|---|---|
| Permissions | microphone grant, deny, deny twice (no dialog), revoke while running |
| File picker | cancel; single; multiple; revoked URI; provider that returns size -1 |
| Files | empty; 0-byte DOCX; 6 MB text (must refuse); 1 MB boundary; Unicode; corrupted ZIP; PDF named .txt |
| Images | cancel; 40 MP image (must refuse); EXIF rotation 90/180/270/flip; GIF; non-image named .jpg |
| OCR | printed text; blank page; rotated photo; 3-page PDF with maxPages 2; cancel between pages; ML Kit failure |
| Camera | cancel; no camera app (emulator without camera); temp file deleted after releaseRef and after reload |
| Speech | no recognition service; permission denied; partial results; stop; cancel; pause during listening; second start (busy) |
| TTS | init failure; unsupported language; stop during speech |
| Lifecycle | rotate (configChanges), background/foreground, WebView reload while a picker is open (stale reply dropped), process death |
| Hostile payloads | 15 MB args; duplicate ids; unknown method; non-JSON; `ref` with path; `_v`:99 |
| Integration | JS call → Kotlin → correct promise, 10 simultaneous calls, native error propagation, offline OCR and file reading |

## Tier 5 — physical device tests — NOT RUN
Camera capture with a real camera app; share to a real target; notification permission on Android 13+; Android 14 photo picker behaviour; SpeechRecognizer
on-device vs network behaviour (record which); battery/memory observations during OCR of 5 PDF pages.

## Performance
No on-device measurement exists. The only measurements are JavaScript timings in Node (see `BRIDGE.md`, "Measurements").

## Build commands (unverified)
```
cd android
gradle wrapper            # once, if there is no gradlew
./gradlew :app:assembleDebug
./gradlew :app:testDebugUnitTest
./gradlew :app:connectedDebugAndroidTest   # after instrumented tests exist
```
