/* EDO message renderer. Pure string → HTML, no DOM access, so it is unit-tested in Node.
   Markdown subset: **bold**, *italic*, `code`, ``` fenced blocks (language label, copy button, diff colouring),
   | tables |, ":::working" collapsible sections, [[G:query]] search links. Everything is HTML-escaped FIRST. */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  const ESC = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };
  const UNESC = { amp: "&", lt: "<", gt: ">", quot: '"', "#39": "'" };
  const LIMIT = 12000; // characters rendered immediately; the rest waits behind a button (keeps long answers smooth on phones)
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ESC[c]);
  const unesc = (s) => String(s).replace(/&(amp|lt|gt|quot|#39);/g, (m, e) => UNESC[e]);

  function codeBlock(lang, body) {
    const label = lang || "code";
    let inner = body.replace(/\n$/, "");
    if (lang === "diff") inner = inner.split("\n").map((l) => (/^\+(?!\+\+)/.test(l) ? '<span class="da">' + l + "</span>" : /^-(?!--)/.test(l) ? '<span class="dd">' + l + "</span>" : l)).join("\n");
    return '<div class="code"><div class="ch"><span>' + label + '</span><button class="cp" type="button" aria-label="Copy ' + label + ' code">Copy</button></div><pre tabindex="0">' + inner + "</pre></div>";
  }
  function inline(h) {
    return h.replace(/\*\*(.+?)\*\*/g, "<b>$1</b>").replace(/(^|[^*])\*([^*\n]+)\*(?!\*)/g, "$1<i>$2</i>").replace(/`([^`\n]+)`/g, "<code>$1</code>")
      .replace(/\[\[G:(.+?)\]\]/g, (m, q) => '<a target="_blank" rel="noopener noreferrer" href="https://www.google.com/search?q=' + encodeURIComponent(unesc(q)) + '">Open this search in Google ↗</a>');
  }
  function tables(h) {
    return h.replace(/(?:^\|.*\|[ \t]*\n?)+/gm, (blk) => {
      const rows = blk.trim().split("\n").map((r) => r.trim().replace(/^\||\|$/g, "").split("|").map((c) => c.trim()));
      if (rows.length < 2 || !rows[1].every((c) => /^:?-{2,}:?$/.test(c))) return blk;
      const head = "<tr>" + rows[0].map((c) => "<th>" + c + "</th>").join("") + "</tr>";
      const body = rows.slice(2).map((r) => "<tr>" + r.map((c) => "<td>" + c + "</td>").join("") + "</tr>").join("");
      return '<div class="tw"><table>' + head + body + "</table></div>";
    });
  }
  function md(s, opts) {
    const full = String(s == null ? "" : s);
    const limit = (opts && opts.limit) || LIMIT;
    const cut = !(opts && opts.full) && full.length > limit;
    let src = cut ? full.slice(0, limit) : full;
    if (cut && (src.match(/```/g) || []).length % 2) src += "\n```"; // never leave a code fence open
    const blocks = [];
    let h = esc(src).replace(/```([\w+#.\-]*)[ \t]*\n?([\s\S]*?)```/g, (m, l, c) => { blocks.push(codeBlock(l, c)); return "\u0000" + (blocks.length - 1) + "\u0000"; });
    h = h.replace(/:::working\n([\s\S]*?)\n:::/g, (m, w) => '<details class="work"><summary>Show working</summary><div class="wk">' + inline(w) + "</div></details>");
    h = inline(tables(h));
    h = h.replace(/\u0000(\d+)\u0000\n?/g, (m, i) => blocks[i]);
    if (cut) h += '<button type="button" class="more" aria-label="Show the rest of this answer">Show remaining ' + (full.length - limit) + " characters</button>";
    return h;
  }
  root.Render = { md, esc, unesc, LIMIT };
})();
