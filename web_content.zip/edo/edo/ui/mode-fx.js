/* EDO mode-switch animations.
   Switching INTO EDO Pro plays media/mode-pro.mp4 (gold orb, lightning, shockwave; has sound).
   Switching INTO Programming plays media/mode-programming.mp4 (code lattice collapsing into a core).
   Every other switch uses a short built-in gold ring so no mode ever changes silently.
   The mode itself changes at the climax of the clip (swapAt), hidden behind the overlay, so the new
   theme is already in place when the overlay fades. Only the Skip button or Escape ends a clip early (a stray tap never does)
   and the mode is still applied. The clip always plays to its last frame, however long it takes to load. If a clip cannot load or play, the built-in ring runs instead.
   Calm mode and reduced motion switch instantly. */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;

  const FADE_IN_MS = 220;
  const FADE_OUT_MS = 650; // keep in sync with #mfx transition in index.html
  const LOAD_TIMEOUT_MS = 20000; // how long a slow connection may take to buffer a clip before the ring is used
  const STALL_MS = 9000; // playback frozen this long (no progress at all) ends the clip
  const END_GRACE_MS = 2500; // safety net if the browser never fires "ended"
  const RING_MS = 1100;

  /* Which clip belongs to which target mode. swapAt is the second at which the mode is applied. */
  const CLIPS = {
    Assistant: { video: "mfx-pro", swapAt: 4.4, caption: "EDO PRO", sub: "Full power. All local tools." },
    Programming: { video: "mfx-prog", swapAt: 3.0, caption: "PROGRAMMING", sub: "Explain, generate, analyse code." },
  };

  let busy = false;
  let skipNow = null;

  function els() {
    const d = root.document;
    return {
      overlay: d.getElementById("mfx"),
      pro: d.getElementById("mfx-pro"),
      prog: d.getElementById("mfx-prog"),
      cap: d.getElementById("mfx-cap"),
      sub: d.getElementById("mfx-sub"),
      skip: d.getElementById("mfx-skip"),
    };
  }

  /* Start downloading both clips in the background so a switch never waits on the network. */
  let warmed = false;
  function warm() {
    if (warmed) return;
    warmed = true;
    const e = els();
    [e.pro, e.prog].forEach((v) => {
      if (!v) return;
      try { v.preload = "auto"; v.load(); } catch (err) {}
    });
  }

  function isBusy() { return busy; }
  function clipFor(target) { return CLIPS[target] || null; }

  /* run(target, { onSwap, reduced, label, sub, sound }) -> Promise that resolves when the overlay is gone.
     onSwap() is called exactly once, always, even if the animation fails or is skipped. */
  function run(target, opts) {
    opts = opts || {};
    return new Promise((resolve) => {
      let swapped = false;
      const swap = () => {
        if (swapped) return;
        swapped = true;
        try { opts.onSwap && opts.onSwap(); } catch (err) { if (root.console) root.console.error(err); }
      };
      const e = els();
      if (busy) { swap(); return resolve("busy"); }
      if (opts.reduced || !e.overlay) { swap(); return resolve("instant"); }

      busy = true;
      const clip = clipFor(target);
      const video = clip && e[clip.video === "mfx-pro" ? "pro" : "prog"];
      const timers = [];
      const later = (fn, ms) => { const t = setTimeout(fn, ms); timers.push(t); return t; };
      let finished = false;
      let raf = 0;

      e.cap.textContent = opts.label || (clip && clip.caption) || "";
      e.sub.textContent = opts.sub || (clip && clip.sub) || "";
      e.overlay.dataset.kind = clip ? "clip" : "ring";
      e.overlay.dataset.target = target;
      e.pro.hidden = true;
      e.prog.hidden = true;

      function finish(reason) {
        if (finished) return;
        finished = true;
        cancelAnimationFrame(raf);
        timers.forEach(clearTimeout);
        swap();
        skipNow = null;
        e.overlay.classList.remove("cap", "wait");
        e.overlay.classList.remove("show");
        later(() => {
          if (video) { try { video.pause(); video.currentTime = 0; } catch (err) {} video.hidden = true; }
          e.overlay.hidden = true;
          e.overlay.classList.remove("ring");
          busy = false;
          resolve(reason);
        }, FADE_OUT_MS + 40);
      }
      skipNow = () => finish("skip");

      function ring() {
        if (video) { try { video.pause(); } catch (err) {} video.hidden = true; }
        e.overlay.dataset.kind = "ring";
        e.overlay.classList.remove("wait");
        e.overlay.classList.add("ring", "cap");
        later(swap, RING_MS * 0.45);
        later(() => finish("ring"), RING_MS);
      }

      e.overlay.hidden = false;
      void e.overlay.offsetWidth; // let the browser see hidden=false before the fade starts
      e.overlay.classList.add("show");

      if (!video || typeof video.play !== "function") {
        later(ring, FADE_IN_MS * 0.4);
        return;
      }

      let playing = false;
      let lastT = -1;
      let lastMove = Date.now();
      let endTimer = 0;
      video.hidden = false;
      try { video.currentTime = 0; } catch (err) {}
      video.muted = opts.sound === false;

      function watch() {
        if (finished) return;
        const t = video.currentTime;
        if (t !== lastT) { lastT = t; lastMove = Date.now(); }
        if (!swapped && t >= clip.swapAt) swap();
        if (!e.overlay.classList.contains("cap") && t >= Math.max(0.4, clip.swapAt - 1.4)) e.overlay.classList.add("cap");
        // stall guard: only when the video is not simply buffering
        if (!video.paused && Date.now() - lastMove > STALL_MS && video.readyState >= 3) return finish("stalled");
        raf = requestAnimationFrame(watch);
      }
      function started() {
        if (playing || finished) return;
        playing = true;
        e.overlay.classList.remove("wait");
        // Safety nets only: the clip's own "ended" event is what normally finishes it.
        const d = isFinite(video.duration) && video.duration > 0 ? video.duration : 10;
        endTimer = later(() => finish("ended-timer"), (d + 2) * 1000 + END_GRACE_MS);
        later(() => { if (!swapped) swap(); }, (clip.swapAt + 6) * 1000);
        raf = requestAnimationFrame(watch);
      }
      function play() {
        if (finished) return;
        const attempt = video.play();
        if (attempt && typeof attempt.catch === "function") {
          attempt.catch(() => {
            // Autoplay with sound refused: retry silently rather than lose the animation.
            if (finished) return;
            video.muted = true;
            const again = video.play();
            if (again && typeof again.catch === "function") again.catch(() => { if (!playing) ring(); });
          });
        }
      }

      video.onended = () => finish("ended");
      video.onerror = () => { if (!playing) ring(); else finish("error"); };
      video.onplaying = started;

      // Wait for enough data to play without hiccups; show the poster and a soft pulse meanwhile.
      if (video.readyState >= 3) play();
      else {
        e.overlay.classList.add("wait");
        const ready = () => { video.removeEventListener("canplay", ready); play(); };
        video.addEventListener("canplay", ready);
        try { video.preload = "auto"; video.load(); } catch (err) {}
        later(() => { if (!playing) ring(); }, LOAD_TIMEOUT_MS);
      }
    });
  }

  function bind() {
    const e = els();
    if (!e.overlay || e.overlay.dataset.bound) return;
    e.overlay.dataset.bound = "1";
    if (e.skip) e.skip.addEventListener("click", (ev) => { ev.stopPropagation(); if (skipNow) skipNow(); });
    root.addEventListener("keydown", (ev) => {
      if (skipNow && ev.key === "Escape") { ev.preventDefault(); skipNow(); }
    });
  }
  if (root.document) {
    if (root.document.readyState === "loading") root.document.addEventListener("DOMContentLoaded", bind);
    else bind();
  }

  root.ModeFX = { run, warm, isBusy, clipFor, CLIPS };
})();
