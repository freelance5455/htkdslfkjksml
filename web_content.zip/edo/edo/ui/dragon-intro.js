/* EDO launch animation.
   Plays media/edo-intro.mp4 (muted, inline). If the video cannot load, cannot autoplay,
   or the user is on data-saver, the original gold-particle animation runs instead.
   Tap, Skip, Enter or Escape ends it at any time. Reduced motion skips it entirely.
   The app is already rendered underneath, so the intro never blocks startup. */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;

  const START_TIMEOUT_MS = 4000; // video must be playing by then, else use the fallback
  const HARD_TIMEOUT_MS = 14000; // nothing may hold the overlay longer than this
  const FADE_MS = 900; // keep in sync with #intro transition in index.html
  const REVEAL_LEAD_S = 0.8; // begin fading out this long before the video ends

  function start(opts) {
    const overlay = opts.overlay;
    const video = opts.video;
    const cv = opts.canvas;
    let finished = false;
    const timers = [];
    const later = (fn, ms) => {
      const t = setTimeout(fn, ms);
      timers.push(t);
      return t;
    };

    function releaseVideo() {
      if (!video) return;
      try {
        video.pause();
        video.removeAttribute("src");
        while (video.firstChild) video.removeChild(video.firstChild);
        video.load(); // aborts any pending download and frees the decoder
      } catch (e) {}
    }

    function done(reason) {
      if (finished) return;
      finished = true;
      timers.forEach(clearTimeout);
      if (overlay) {
        overlay.classList.add("out"); // CSS fades it while the app fades in
        setTimeout(() => {
          releaseVideo();
          overlay.remove();
        }, FADE_MS + 50);
      }
      if (opts.onDone) opts.onDone(reason);
    }

    if (!overlay || opts.reduced) {
      done("skipped");
      return;
    }

    overlay.addEventListener("click", () => done("tap"));
    const skip = overlay.querySelector("#skip");
    if (skip) skip.addEventListener("click", (e) => { e.stopPropagation(); done("skip"); });
    root.addEventListener("keydown", function onKey(e) {
      if (finished) return root.removeEventListener("keydown", onKey);
      if (e.key === "Escape" || e.key === "Enter") done("key");
    });
    later(() => done("timeout"), HARD_TIMEOUT_MS);

    const conn = root.navigator && root.navigator.connection;
    const saveData = !!(conn && conn.saveData);

    if (!video || saveData || typeof video.play !== "function") {
      particles();
      return;
    }

    let playing = false;
    function videoFailed() {
      if (finished) return;
      if (playing) return done("video-error"); // already shown part of it: just continue to the app
      particles();
    }
    // <source> errors do not bubble, but they do pass through the capture phase.
    video.addEventListener("error", videoFailed, true);
    video.addEventListener("playing", () => {
      playing = true;
      overlay.classList.add("live");
    });
    video.addEventListener("ended", () => done("ended"));
    // Start the crossfade just before the last frame so the final wordmark dissolves into the app.
    video.addEventListener("timeupdate", () => {
      if (video.duration && video.duration - video.currentTime < REVEAL_LEAD_S) done("ended");
    });
    later(() => { if (!playing) videoFailed(); }, START_TIMEOUT_MS);
    try {
      const p = video.play();
      if (p && p.catch) p.catch(videoFailed); // autoplay blocked
    } catch (e) {
      videoFailed();
    }

    /* ---------- fallback: gold particles follow a serpentine path, then form EDO ---------- */
    function particles() {
      if (finished || !cv || !cv.getContext) return done("no-fallback");
      releaseVideo();
      overlay.classList.add("canvas", "live");
      cv.hidden = false;
      const x = cv.getContext("2d");
      const W = (cv.width = opts.width || root.innerWidth || 800);
      const H = (cv.height = opts.height || root.innerHeight || 600);
      const N = W < 500 ? 160 : 260;
      const T0 = root.performance ? root.performance.now() : Date.now();
      const P = [];
      const path = (u) => ({ x: W * (0.08 + 0.84 * u), y: H * 0.5 + Math.sin(u * 9) * H * 0.1 * (1 - u * 0.3) - Math.sin(u * 3) * H * 0.08 });
      for (let i = 0; i < N; i++) P.push({ r: Math.random() });
      const o = document.createElement("canvas");
      o.width = W;
      o.height = H;
      const c = o.getContext("2d");
      c.font = "800 " + Math.min(W * 0.3, 200) + "px system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif";
      c.textAlign = "center";
      c.textBaseline = "middle";
      c.fillStyle = "#e0a82e";
      c.fillText("EDO", W / 2, H * 0.5);
      const d = c.getImageData(0, 0, W, H).data;
      const pts = [];
      for (let yy = 0; yy < H; yy += 6) for (let xx = 0; xx < W; xx += 6) if (d[(yy * W + xx) * 4 + 3] > 128) pts.push([xx, yy]);
      const raf = root.requestAnimationFrame || function (fn) { return setTimeout(() => fn(Date.now()), 16); };
      (function f(now) {
        if (finished) return;
        const t = (now - T0) / 1000;
        x.fillStyle = "rgba(0,0,0,.25)";
        x.fillRect(0, 0, W, H);
        for (let i = 0; i < N; i++) {
          const p = P[i];
          let X;
          let Y;
          const head = Math.min(1, Math.max(0, (t - 2) / 4));
          if (t < 2) {
            X = W * p.r;
            Y = H * ((p.r * 7 + i) % 1);
            x.globalAlpha = Math.min(1, t / 2) * 0.6;
          } else if (t < 6.5) {
            const q = path(Math.min(1, Math.max(0, head * 1.3 - (i / N) * 0.35)));
            X = q.x;
            Y = q.y + Math.sin(i * 0.7 + t * 3) * 8 * (1 - i / N);
            x.globalAlpha = 0.9;
          } else {
            const tp = pts[(i * Math.floor(pts.length / N)) % pts.length] || [W / 2, H / 2];
            const k = Math.min(1, (t - 6.5) / 1.2);
            const q = path(1 - (i / N) * 0.4);
            X = q.x + (tp[0] - q.x) * k;
            Y = q.y + (tp[1] - q.y) * k;
            x.globalAlpha = 1;
          }
          x.fillStyle = i % 7 ? "#e0a82e" : "#fff3b0";
          x.beginPath();
          x.arc(X, Y, i % 7 ? 1.6 : 2.4, 0, 6.3);
          x.fill();
          if (i === 0 && t > 3.5 && t < 7) {
            x.fillStyle = "#ffe58a";
            x.shadowColor = "#ffd24a";
            x.shadowBlur = 14;
            x.beginPath();
            x.arc(X - 5, Y - 3, 3, 0, 6.3);
            x.arc(X + 5, Y - 3, 3, 0, 6.3);
            x.fill();
            x.shadowBlur = 0;
          }
        }
        x.globalAlpha = 1;
        if (t > 9.5) return done("ended");
        raf(f);
      })(T0);
    }
  }

  root.DragonIntro = { start };
})();
