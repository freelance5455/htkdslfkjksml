/* EDO UI extras. Loaded after the main inline script, so it can use its globals (send, add, cfg, mode, $, Store, Bridge, Voice...).
   Adds: status strip (memory / project / task / tool), memory panel with inspect, delete, forget and retention, project loader
   with progress and cancel, voice session with a listening orb and wake-word settings, proactive nudges, suggestion chips,
   and back-button handling. Everything is optional: if a module is missing, its part of the UI simply does not appear. */
(function () {
  "use strict";
  const g = window;
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const say = (m) => { const l = $("live"); if (l) { l.textContent = ""; setTimeout(() => { l.textContent = m; }, 30); } };
  const X = {};
  const saveCfg = () => { try { Store.set("cfg", cfg); } catch (e) {} };

  /* ---------- status strip ---------- */
  let memTimer = null;
  function strip() {
    const ML = g.MemoryLayers, st = ML ? ML.status() : null, el = $("memchip");
    if (el && st) { el.textContent = st.enabled ? "Memory on" : "Memory off"; el.dataset.on = st.enabled ? "1" : "0"; el.title = st.enabled ? st.turns + " turns, " + st.summaries + " summaries, " + st.events + " events, " + st.plans + " plans saved on this device" : "Nothing is being saved"; }
    const pc = $("projchip"), P = g.CodeBrain && g.CodeBrain.project();
    if (pc) { if (P && g.CodeBrain.hasProject()) { const s = P.stats(); pc.hidden = false; pc.textContent = "Project: " + s.name + " · " + s.files + " files"; } else pc.hidden = true; }
    const tc = $("taskchip");
    if (tc) { const t = ML && ML.isEnabled() ? ML.activePlan() : null; if (t) { const i = t.steps.findIndex((x) => !x.done); tc.hidden = false; tc.textContent = "Plan: step " + (i < 0 ? t.steps.length : i + 1) + "/" + t.steps.length; } else if (g.MemoryLayers && g.MemoryLayers.working.task && g.MemoryLayers.working.task.kind) { tc.hidden = false; tc.textContent = "Task: " + g.MemoryLayers.working.task.kind; } else tc.hidden = true; }
  }
  X.strip = strip;
  X.afterReply = function (r) {
    const t = $("toolchip");
    if (t && r && r.engine) { t.hidden = false; t.textContent = ({ calculator: "Calculator", solver: "Solver", knowledge: "Notes", programming: "Code", "code-brain": "Project brain", planner: "Planner", friend: "Companion", "memory-recall": "Memory", search: "Search", device: "Device", legacy: "EDO" }[r.engine] || r.engine); t.title = r.trace ? r.trace.map((s) => s.stage + ": " + s.info).join("\n") : ""; }
    strip();
    if (r && r.verification && !r.verification.ok) say("Note: this reply contains numbers I could not trace to your message or saved context.");
  };
  if (g.MemoryLayers) g.MemoryLayers.onSave((kind) => {
    const el = $("memchip"); if (!el) return;
    if (kind === "turn") return; // every message is saved while memory is on; only durable items flash
    el.classList.add("saving"); el.textContent = "Saved " + kind; clearTimeout(memTimer); memTimer = setTimeout(() => { el.classList.remove("saving"); strip(); }, 1800); say("Saved a " + kind + " to memory");
  });

  /* ---------- suggestions (quick replies) ---------- */
  g.suggest = function (s) {
    if (/^load project$/i.test(s)) { openSheet("sheet"); setTimeout(() => { const p = $("projpanel"); if (p) p.scrollIntoView({ block: "start" }); }, 80); return; }
    if (/^apply the change$/i.test(s)) return X.applyChange();
    if (/^not now$/i.test(s)) return add("a", "Okay. I'm here when you want me.", null, true);
    return send(s);
  };
  X.applyChange = function () {
    const list = g.__lastChanges || [];
    if (!list.length) return add("a", "There's no prepared change to apply.", null, true);
    const results = list.map((c) => g.CodeBrain.change(c.req, { commit: true }));
    const ok = results.filter((r) => r.ok && r.committed), bad = results.filter((r) => !r.ok);
    const diff = ok.flatMap((r) => r.patches.map((p) => p.diff)).join("\n").slice(0, 6000);
    add("a", (ok.length ? "Applied to the in-memory project: " + ok.map((r) => r.summary).join("; ") + ".\nFiles on your device are unchanged. Copy this diff into your editor.\n\n```diff\n" + diff + "\n```" : "") + (bad.length ? "\nI did not apply " + bad.length + " change(s): " + bad.map((r) => (r.introduced || []).map((x) => x.message).join("; ") || r.reason || "checks failed").join(" | ") + "." : ""), g.CodeBrain.CAVEAT, false);
    g.__lastChanges = null; strip();
  };

  /* ---------- project panel ---------- */
  let projAbort = null;
  const SKIP = g.Project ? g.Project.IGNORE_DIRS : new Set();
  const TEXTY = /\.(js|mjs|cjs|jsx|ts|tsx|py|cs|java|kt|kts|c|h|cc|cpp|hpp|go|rs|json|html|css|xml|gradle|yml|yaml|md|txt|csproj|sln|shader|cginc|meta|unity|prefab|asset)$/i;
  function wantFile(path, size) {
    const parts = path.toLowerCase().split("/");
    if (parts.slice(0, -1).some((p) => SKIP.has(p))) return false;
    return (TEXTY.test(path) || /(^|\/)(dockerfile|makefile|\.gitignore)$/i.test(path)) && size <= (g.Project ? g.Project.LIMITS.fileBytes : 400000);
  }
  async function loadFromFileList(list, name) {
    const files = Array.from(list), picked = files.filter((f) => wantFile(f.webkitRelativePath || f.name, f.size)).slice(0, g.Project.LIMITS.files);
    if (!picked.length) return status("No readable source files were found in that selection.");
    const first = picked[0].webkitRelativePath || "";
    const prefix = first.includes("/") ? first.split("/")[0] + "/" : "";
    const out = [];
    projAbort = new AbortController();
    for (let i = 0; i < picked.length; i++) {
      if (projAbort.signal.aborted) return finishLoad(null, "cancelled");
      const f = picked[i];
      out.push({ path: (f.webkitRelativePath || f.name).slice(prefix.length), content: await f.text() });
      if (i % 25 === 0) { status("Reading files… " + (i + 1) + "/" + picked.length); await new Promise((r) => setTimeout(r, 0)); }
    }
    return indexFiles(out, name || prefix.replace(/\/$/, "") || "project");
  }
  async function indexFiles(files, name) {
    const p = g.Project.create({ name });
    projAbort = projAbort || new AbortController();
    try {
      await p.indexAsync(files, { signal: projAbort.signal, onProgress: (x) => status("Indexing… " + x.done + "/" + x.total) });
      g.CodeBrain.setProject(p);
      finishLoad(p);
    } catch (e) { finishLoad(null, e.code === "cancelled" ? "cancelled" : e.message); }
  }
  function status(t) { const el = $("projstat"); if (el) el.textContent = t; }
  function finishLoad(p, err) {
    projAbort = null;
    if (!p) { status(err === "cancelled" ? "Loading cancelled; nothing was kept." : "Could not load the project: " + err); renderProject(); return; }
    const s = p.stats(); status("Loaded " + s.files + " files (" + Object.entries(s.languages).filter(([k]) => !/meta|other|text|markdown/.test(k)).map(([k, v]) => v + " " + k).join(", ") + ").");
    renderProject(); strip();
    add("a", "Project **" + s.name + "** is loaded: " + s.files + " files, " + s.symbols + " symbols, " + s.edges + " dependency links" + (s.unity ? " (Unity project)" : "") + ". It stays in this tab's memory only; nothing was uploaded. Try: \"project overview\", \"where is <function> defined\", \"what uses <class>\", \"what will break if I change <file>\", \"review the project\".", g.CodeBrain.CAVEAT, false);
    if (s.files > 300 && g.ProjectClient) g.ProjectClient.review(p.snapshot(), { name: s.name }).then((r) => { X.lastReview = r; add("a", "Background review finished: " + r.counts.error + " error(s), " + r.counts.warning + " warning(s). Ask \"review the project\" for details.", null, true); }, () => {});
  }
  function renderProject() {
    const box = $("projpanel"); if (!box) return;
    const P = g.CodeBrain && g.CodeBrain.project(), has = P && g.CodeBrain.hasProject();
    let list = "";
    if (has) { const live = P.live(); list = '<div class="row"><span>Active file</span><span>' + esc(live.activeFile || "none") + '</span></div><div id="filelist" role="list">' + P.paths().filter((p) => /\.(cs|js|ts|tsx|jsx|py|java|kt|go|rs|cpp|c|h)$/i.test(p)).slice(0, 40).map((p) => '<button type="button" class="btn sm" data-file="' + esc(p) + '">' + esc(p.split("/").pop()) + "</button>").join("") + "</div>"; }
    box.innerHTML = '<p><small>Pick a folder or files. EDO reads text source only, keeps them in memory for this tab, never uploads or runs them, and skips dependencies, build output and binaries.</small></p>' +
      '<div class="row2"><button class="btn" id="pjfolder">Load folder</button><button class="btn" id="pjfiles">Load files</button>' + (has ? '<button class="btn" id="pjclear">Unload</button>' : "") + (projAbort ? '<button class="btn" id="pjcancel">Cancel</button>' : "") + '</div>' +
      '<input type="file" id="pjin1" webkitdirectory multiple hidden><input type="file" id="pjin2" multiple hidden><p id="projstat" role="status"></p>' + list;
    $("pjfolder").onclick = () => (g.Bridge && Bridge.available() && Bridge.supportsSync("pickProject") ? nativeFolder() : $("pjin1").click());
    $("pjfiles").onclick = () => $("pjin2").click();
    $("pjin1").onchange = (e) => loadFromFileList(e.target.files);
    $("pjin2").onchange = (e) => loadFromFileList(e.target.files, "files");
    if ($("pjclear")) $("pjclear").onclick = () => { g.CodeBrain.setProject(null); renderProject(); strip(); };
    if ($("pjcancel")) $("pjcancel").onclick = () => { if (projAbort) projAbort.abort(); };
    box.querySelectorAll("[data-file]").forEach((b) => { b.onclick = () => { P.setActive(b.dataset.file); renderProject(); say("Active file " + b.dataset.file); }; });
  }
  async function nativeFolder() {
    const acc = []; projAbort = new AbortController();
    const off = Bridge.on("project.files", (e) => { (e.files || []).forEach((f) => acc.push(f)); status("Receiving files… " + acc.length); });
    try { const h = Bridge.callCancelable("pickProject", {}, { timeoutMs: 300000, signal: projAbort.signal }); const j = JSON.parse(await h.promise); off(); await indexFiles(acc, j.name || "project"); }
    catch (e) { off(); finishLoad(null, e.code === "cancelled" ? "cancelled" : e.message); }
  }

  /* ---------- memory panel ---------- */
  function renderMemory() {
    const box = $("mempanel"), ML = g.MemoryLayers; if (!box || !ML) return;
    const st = ML.status(), cfgm = st.cfg;
    const opt = (v, cur, label) => '<option value="' + v + '"' + (+cur === v ? " selected" : "") + ">" + label + "</option>";
    box.innerHTML = '<p><small>' + (st.enabled ? "Saved on this device only: " + st.turns + " turns, " + st.summaries + " summaries, " + st.events + " events, " + st.plans + " plans." : "Memory is off: nothing is saved or read.") + (st.lastError ? " Storage: " + esc(st.lastError) : "") + '</small></p>' +
      '<label class="row"><span>Keep conversation turns</span><select id="ret1">' + [1, 7, 14, 30, 90].map((d) => opt(d, cfgm.turnDays, d + " day" + (d > 1 ? "s" : ""))).join("") + opt(0, cfgm.turnDays, "forever") + '</select></label>' +
      '<label class="row"><span>Keep summaries</span><select id="ret2">' + [30, 90, 180, 365].map((d) => opt(d, cfgm.summaryDays, d + " days")).join("") + opt(0, cfgm.summaryDays, "forever") + '</select></label>' +
      '<div class="row2"><button class="btn" id="memins">Inspect</button><button class="btn" id="memsum">Summarise now</button><button class="btn" id="memhist">Clear history</button></div>' +
      '<div class="row2"><input type="text" id="forgetq" placeholder="Forget a topic, e.g. physics" aria-label="Topic to forget"><button class="btn" id="forgetgo">Forget</button></div><div id="meminspect"></div>';
    $("ret1").onchange = (e) => { ML.setRetention({ turnDays: +e.target.value }); renderMemory(); };
    $("ret2").onchange = (e) => { ML.setRetention({ summaryDays: +e.target.value }); renderMemory(); };
    $("memins").onclick = inspectMemory;
    $("memsum").onclick = () => { say(ML.summarizeNow() ? "Older conversation summarised" : "Nothing old enough to summarise yet"); renderMemory(); };
    $("memhist").onclick = () => { if (confirm("Delete saved conversation turns and summaries? Notes, events and plans stay.")) { ML.clearHistory(); renderMemory(); strip(); } };
    $("forgetgo").onclick = () => { const q = $("forgetq").value.trim(); if (!q) return; const n = ML.forgetTopic(q); say("Removed " + n + " item(s) about " + q); $("forgetq").value = ""; renderMemory(); (typeof panel === "function") && panel(); strip(); };
  }
  function inspectMemory() {
    const r = g.MemoryLayers.inspect(), box = $("meminspect");
    if (!r.enabled) { box.innerHTML = "<small>Memory is off.</small>"; return; }
    box.innerHTML = r.items.slice(0, 80).map((i) => '<div class="row"><span><small>' + esc(i.layer) + "</small><br>" + esc(i.text.slice(0, 140)) + '</span><button class="btn sm" data-del="' + esc(i.id) + '" aria-label="Delete this item">Delete</button></div>').join("") || "<small>Nothing saved.</small>";
    box.querySelectorAll("[data-del]").forEach((b) => { b.onclick = () => { g.MemoryLayers.deleteItem(b.dataset.del); renderMemory(); inspectMemory(); strip(); }; });
  }

  /* ---------- voice ---------- */
  let session = null, stt = null, tts = null, wake = null, orbT = null;
  const vcfg = () => (cfg.voice = Object.assign({ lang: "en-IN", wake: false, phrase: "Hey EDO", sens: "medium", rate: 1, pitch: 1, voice: "", handsFree: false, bargeIn: true }, cfg.voice || {}));
  function buildVoice() {
    if (!g.VoiceEngine || session) return;
    const v = vcfg(), bridge = g.Bridge && Bridge.typed;
    stt = VoiceEngine.createStt({}, { lang: v.lang });
    tts = VoiceEngine.createTts({ bridge }, { lang: v.lang, rate: v.rate, pitch: v.pitch, voiceName: v.voice || null });
    wake = VoiceEngine.createWake({ bridge, timers: { setTimeout: setTimeout.bind(g), clearTimeout: clearTimeout.bind(g) } }, { phrase: v.phrase, sensitivity: v.sens, enabled: false });
    session = VoiceEngine.createSession({ stt, tts, wake }, { handsFree: v.handsFree, bargeIn: v.bargeIn, onCommand: async (text) => { speakOn = false; const r = await send(text); return r && r.text ? { text: r.text } : null; } });
    session.subscribe(orb);
    stt.on({ interim: (t) => { const o = $("vtext"); if (o) o.textContent = t; } });
    if (g.Bridge) { Bridge.on("voice.wake", (ev) => session.onWakeEvent(ev)); Bridge.on("voice.state", () => renderVoice()); Bridge.on("voice.error", (e) => { const o = $("vtext"); if (o) o.textContent = e.message || "voice error"; }); }
  }
  function orb(s) {
    const o = $("vorb"); if (!o) return;
    const labels = { idle: "", wake_detected: "Heard you", listening: "Listening", processing: "Thinking", speaking: "Speaking", error: "Voice problem" };
    o.dataset.s = s.state; o.hidden = s.state === "idle";
    $("vlabel").textContent = labels[s.state] || "";
    const mic = $("mic"); if (mic) { mic.classList.toggle("on", s.state === "listening"); mic.dataset.vs = s.state; mic.setAttribute("aria-pressed", s.state !== "idle" ? "true" : "false"); }
    if (s.state === "idle") $("vtext").textContent = "";
    if (s.error) $("vtext").textContent = s.error;
    if (typeof setS === "function") setS(s.state === "listening" ? "listening" : s.state === "processing" ? "thinking" : s.state === "speaking" ? "speaking" : s.state === "error" ? "error" : "idle");
    say(labels[s.state] || "");
  }
  function onMic() {
    buildVoice();
    if (!session) return (typeof startListen === "function") && startListen();
    if (!stt.available() && !(g.Bridge && Bridge.available())) return add("a", "Speech recognition is not supported in this browser. Try Chrome on Android.", null, true);
    if (session.state !== "idle" && session.state !== "error") return session.stop();
    session.pushToTalk();
  }
  async function renderVoice() {
    const box = $("voicepanel"); if (!box) return;
    buildVoice();
    const v = vcfg(), w = wake ? wake.status() : null, native = g.Bridge && Bridge.available();
    const voices = tts ? tts.voices() : [];
    box.innerHTML = '<label class="row"><span>Recognition language</span><select id="vlang">' + Object.entries(VoiceEngine.LANGS).map(([k, n]) => '<option value="' + k + '"' + (v.lang === k ? " selected" : "") + ">" + esc(n) + "</option>").join("") + "</select></label>" +
      '<label class="row"><span>Voice</span><select id="vvoice"><option value="">Automatic (best installed voice)</option>' + voices.slice(0, 80).map((x) => '<option value="' + esc(x.name) + '"' + (v.voice === x.name ? " selected" : "") + ">" + esc(x.name + " · " + x.lang + (x.localService ? " · on device" : "")) + "</option>").join("") + "</select></label>" +
      '<label class="row"><span>Speed ' + v.rate + '</span><input type="range" id="vrate" min="0.6" max="1.6" step="0.1" value="' + v.rate + '" aria-label="Speech speed"></label>' +
      '<label class="row"><span>Pitch ' + v.pitch + '</span><input type="range" id="vpitch" min="0.6" max="1.6" step="0.1" value="' + v.pitch + '" aria-label="Speech pitch"></label>' +
      '<label><input type="checkbox" id="vhands"' + (v.handsFree ? " checked" : "") + '> Keep listening after each answer</label>' +
      '<label><input type="checkbox" id="vbarge"' + (v.bargeIn ? " checked" : "") + '> Stop speaking when I start talking</label>' +
      '<h4>Wake word</h4><label><input type="checkbox" id="vwake"' + (v.wake ? " checked" : "") + (native ? "" : " disabled") + '> Listen for the wake phrase (Android app only)</label>' +
      '<div class="row2"><input type="text" id="vphrase" value="' + esc(v.phrase) + '" aria-label="Wake phrase" maxlength="40"><select id="vsens" aria-label="Wake sensitivity">' + ["low", "medium", "high"].map((x) => '<option' + (v.sens === x ? " selected" : "") + ">" + x + "</option>").join("") + '</select></div>' +
      '<p id="wakenote"><small>' + esc(w ? w.honest : "") + (native ? "" : " In a plain browser use the mic button: wake word needs the native Android build and a wake-word engine.") + "</small></p>";
    $("vlang").onchange = (e) => { v.lang = e.target.value; stt.configure({ lang: v.lang }); tts.configure({ lang: v.lang }); saveCfg(); };
    $("vvoice").onchange = (e) => { v.voice = e.target.value; tts.configure({ voiceName: v.voice || null }); saveCfg(); };
    $("vrate").oninput = (e) => { v.rate = +e.target.value; tts.configure({ rate: v.rate }); saveCfg(); };
    $("vpitch").oninput = (e) => { v.pitch = +e.target.value; tts.configure({ pitch: v.pitch }); saveCfg(); };
    $("vhands").onchange = (e) => { v.handsFree = e.target.checked; session.configure({ handsFree: v.handsFree }); saveCfg(); };
    $("vbarge").onchange = (e) => { v.bargeIn = e.target.checked; session.configure({ bargeIn: v.bargeIn }); saveCfg(); };
    const applyWake = async () => { const r = await wake.configure({ phrase: $("vphrase").value, sensitivity: $("vsens").value, enabled: $("vwake").checked }); if (r.ok === false && r.wakeWord === undefined) { $("wakenote").textContent = r.reason; return; } v.wake = $("vwake").checked && r.ok; v.phrase = wake.config().phrase; v.sens = $("vsens").value; $("vwake").checked = v.wake; $("wakenote").textContent = (r.note || wake.status().honest); saveCfg(); };
    $("vwake").onchange = applyWake; $("vphrase").onchange = applyWake; $("vsens").onchange = applyWake;
    if (tts && g.speechSynthesis) g.speechSynthesis.onvoiceschanged = () => { if ($("vvoice") && voices.length === 0) renderVoice(); };
  }

  /* ---------- proactive ---------- */
  function renderProactive() {
    const box = $("proactpanel"); if (!box || !g.Proactive) return;
    const c = Proactive.config();
    const row = (id, label, on, dis) => '<label><input type="checkbox" id="' + id + '"' + (on ? " checked" : "") + (dis ? " disabled" : "") + "> " + label + "</label>";
    box.innerHTML = '<p><small>EDO can bring up things you told it when the app opens. It never acts on its own.</small></p>' + row("pa-on", "Suggestions when I open EDO", c.enabled) + row("pa-event", "Upcoming exams and deadlines", c.event) + row("pa-plan", "Unfinished plans", c.plan) + row("pa-pend", "Questions left open", c.pending) + row("pa-rem", "Things I asked to remember", c.remembered) + row("pa-native", "Phone reminders for exams (Android app only)", c.nativeNotify, !(g.Bridge && Bridge.available()));
    [["pa-on", "enabled"], ["pa-event", "event"], ["pa-plan", "plan"], ["pa-pend", "pending"], ["pa-rem", "remembered"], ["pa-native", "nativeNotify"]].forEach(([id, k]) => { $(id).onchange = (e) => Proactive.setConfig({ [k]: e.target.checked }); });
  }
  X.nudge = function () { const n = g.Proactive && Proactive.suggest(); if (n) { add("a", n.text, "Suggestion. Turn these off in the panel.", true, (n.suggestions || []).map((s) => ({ label: s, run: () => suggest(s) }))); } };
  const _greet = g.greet; if (typeof _greet === "function") g.greet = function () { _greet(); X.nudge(); strip(); };

  /* ---------- back button ---------- */
  const _open = g.openSheet;
  if (typeof _open === "function") g.openSheet = function (id) { _open(id); try { history.pushState({ edoSheet: id }, ""); } catch (e) {} if (id === "sheet") { renderProject(); renderMemory(); renderVoice(); renderProactive(); } };
  addEventListener("popstate", () => { if (document.querySelector(".sheet.open")) closeSheets(); });
  g.__edoBack = function () {
    if (document.querySelector(".sheet.open")) { closeSheets(); return true; }
    if (session && session.state !== "idle") { session.stop(); return true; }
    if (projAbort) { projAbort.abort(); return true; }
    return false;
  };
  addEventListener("keydown", (e) => { if (e.key === "Escape" && session && session.state !== "idle") session.stop(); });

  /* ---------- native lifecycle ---------- */
  if (g.Bridge && Bridge.available()) {
    Bridge.capabilities().then(() => renderVoice(), () => {});
    document.addEventListener("visibilitychange", () => { if (!document.hidden) Bridge.resync().catch(() => {}); });
  }

  /* the existing memory switch drives the chip and panel too */
  const mo = $("memon"); if (mo) mo.addEventListener("click", () => { setTimeout(() => { strip(); renderMemory(); }, 0); });

  /* ---------- boot ---------- */
  const mic = $("mic"); if (mic) mic.onclick = onMic;
  strip();
  g.EDOX = X;
})();
