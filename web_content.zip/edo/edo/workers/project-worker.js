/* Background worker for heavy project work so the UI thread never stalls. It loads the same modules the page uses, builds its own
   index from a snapshot the page sends, and answers review requests. It cannot touch the DOM, storage or the Android bridge,
   and it never evaluates project code. Messages: {id, type:"review", files:[{path,content}]} → {id, ok, result|error}. */
/* global importScripts */
importScripts("../core/semantic.js", "../core/project.js", "../core/validation.js", "../tools/code-analyzer.js", "../core/patch.js", "../knowledge/unity.js", "../core/codebrain.js");
self.onmessage = function (e) {
  const m = e.data || {};
  try {
    if (m.type === "review") {
      const p = self.Project.create({ name: m.name || "project" });
      p.addFiles(m.files || []);
      self.CodeBrain.setProject(p);
      const stats = p.stats();
      const r = self.CodeBrain.reviewProject();
      self.postMessage({ id: m.id, ok: true, result: { stats, counts: r.counts, worst: r.worst, scanned: r.scanned, findings: r.findings.slice(0, 300) } });
    } else if (m.type === "ping") self.postMessage({ id: m.id, ok: true, result: "pong" });
    else self.postMessage({ id: m.id, ok: false, error: "unknown message type" });
  } catch (err) { self.postMessage({ id: m.id, ok: false, error: String(err && err.message || err) }); }
};
