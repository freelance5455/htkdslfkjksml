/* EDO CodeBrain. The project-aware layer of the programming engine. It sits on core/project.js (the workspace index) and
   reuses the existing Programming / CodeAnalyzer / Patch modules.

   What it does, with real inputs and outputs:
     answers     where is X defined, what uses X, what depends on this file, what breaks if I change X, project overview
     reviews     architecture (cycles, hotspots, orphans, oversized files), security patterns, performance patterns, Unity rules
     unity       lifecycle-name mistakes, per-frame lookups and allocations, physics in Update, missing Time.deltaTime, Rigidbody
                 conflicts, ?. on Unity objects, and scene/prefab serialized values that override code defaults
     changes     rename a symbol across files, apply exact edits, fix lifecycle names, cache GetComponent: each as a patch, checked
                 on a sandbox copy by Validation, committed only when you ask and the checks pass
     tests       skeletons for the functions in a file

   What it does not do: it does not write arbitrary new features (that needs a language model), type-check, compile or run code.
   Every answer is from lexical analysis and says so; execution is only ever reported by an explicitly configured runner.
   Globals: window.CodeBrain */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  const CAVEAT = "Lexical project index and rule-based checks. Nothing was compiled or run (Not executed here).";
  let current = null;

  const project = () => current;
  function setProject(p) { current = p || null; return current; }
  const hasProject = () => !!current && current.stats().files > 0;
  const lineOfIdx = (text, idx) => { let n = 1; for (let i = 0; i < idx && i < text.length; i++) if (text.charCodeAt(i) === 10) n++; return n; };
  const snippet = (path, line) => { const c = current && current.read(path); return c ? (c.split("\n")[line - 1] || "").trim().slice(0, 140) : ""; };
  const loc = (path, line) => path + (line ? ":" + line : "");

  /* ---------- method bodies ---------- */
  function bodies(path) {
    const content = current.read(path), lang = root.Project.langOf(path);
    if (content == null) return [];
    const text = root.Project.blank(content, lang), starts = [0];
    for (let i = 0; i < text.length; i++) if (text.charCodeAt(i) === 10) starts.push(i + 1);
    const out = [];
    current.symbolsIn(path).filter((s) => s.kind === "method" || s.kind === "function").forEach((s) => {
      const from = starts[s.line - 1];
      if (from == null) return;
      const open = text.indexOf("{", from + Math.max(0, text.slice(from).search(new RegExp("\\b" + s.name.replace(/[$]/g, "\\$&") + "\\b"))));
      if (open < 0) return;
      let d = 0, end = text.length;
      for (let i = open; i < text.length; i++) { const ch = text.charCodeAt(i); if (ch === 123) d++; else if (ch === 125) { d--; if (d === 0) { end = i; break; } } }
      out.push({ name: s.name, container: s.container, startLine: s.line, bodyFrom: open, bodyTo: end, text: text.slice(open, end + 1), raw: content.slice(open, end + 1), lineOf: (i) => lineOfIdx(text, open + i) });
    });
    return out;
  }

  /* ---------- Unity rules ---------- */
  const LIFECYCLE = ["Awake", "Start", "Update", "FixedUpdate", "LateUpdate", "OnEnable", "OnDisable", "OnDestroy", "OnTriggerEnter", "OnTriggerExit", "OnTriggerStay", "OnCollisionEnter", "OnCollisionExit", "OnCollisionStay", "OnTriggerEnter2D", "OnTriggerExit2D", "OnCollisionEnter2D", "OnCollisionExit2D", "OnMouseDown", "OnGUI", "OnValidate", "OnApplicationPause", "OnBecameVisible", "OnBecameInvisible"];
  const LIFE_LC = new Map(LIFECYCLE.map((n) => [n.toLowerCase(), n]));
  const HOT = new Set(["Update", "FixedUpdate", "LateUpdate", "OnGUI"]);
  const UNITY_OBJ = /^(GameObject|Transform|Rigidbody2?D?|Collider2?D?|BoxCollider|SphereCollider|CapsuleCollider|AudioSource|Camera|Animator|Renderer|SpriteRenderer|MeshRenderer|NavMeshAgent|Canvas|Image|Text|TMP_Text|TextMeshProUGUI|Button|Light|ParticleSystem|CharacterController|Component|MonoBehaviour|ScriptableObject)$/;
  const HOT_RULES = [
    [/\bGameObject\.Find(?:WithTag|GameObjectsWithTag)?\s*\(/, "warning", "find-in-hot-path", "GameObject.Find* searches the whole scene every frame. Cache the result in Awake/Start."],
    [/\bFindObject(?:s)?Of(?:Type|Any)\s*[<(]|\bFindFirstObjectByType\s*[<(]|\bFindAnyObjectByType\s*[<(]/, "warning", "find-in-hot-path", "FindObjectOfType-style search every frame is slow. Cache it once."],
    [/\bGetComponent(?:InChildren|InParent)?\s*[<(]/, "warning", "getcomponent-in-hot-path", "GetComponent every frame costs time on phones. Cache it in Awake."],
    [/\bnew\s+(?:List|Dictionary|HashSet|Queue|Stack)\s*</, "warning", "alloc-in-hot-path", "Allocating a collection every frame creates garbage and GC stutter. Reuse a field."],
    [/\.(?:ToList|ToArray|Select|Where|OrderBy|Any|First|Count)\s*\(/, "info", "linq-in-hot-path", "LINQ in a per-frame method allocates. Use a loop on a cached collection."],
    [/\bDebug\.Log(?:Warning|Error)?\s*\(/, "info", "log-in-hot-path", "Debug.Log every frame is slow and floods the console; remove or guard it."],
    [/\bInstantiate\s*\(/, "warning", "instantiate-in-hot-path", "Instantiate in a per-frame method: pool the objects (ObjectPool<T> or a stack) instead."],
    [/\bDestroy\s*\(/, "info", "destroy-in-hot-path", "Destroy during play creates garbage; consider pooling and SetActive(false)."],
    [/\bCamera\.main\b/, "info", "camera-main", "Camera.main does a lookup on older Unity versions (before 2020.2); cache it if you target those."],
  ];

  function unityReview(path) {
    const rec = current.read(path); if (rec == null) return [];
    const findings = [], add = (severity, line, rule, message, extra) => findings.push(Object.assign({ severity, path, line, rule, message }, extra || {}));
    const classes = (current.classInfo ? [] : []);
    const info = current.symbolsIn(path);
    const content = rec, stripped = root.Project.strip(content, "csharp");
    const clsDefs = info.filter((s) => s.kind === "class");
    const isMB = (name) => { const ci = current.classInfo(name); return ci && /MonoBehaviour|NetworkBehaviour/.test(ci.bases.join(",")); };
    clsDefs.forEach((c) => {
      if (!isMB(c.name)) return;
      const ci = current.classInfo(c.name);
      info.filter((s) => s.kind === "method" && s.container === c.name).forEach((m) => {
        const canon = LIFE_LC.get(m.name.toLowerCase());
        if (canon && canon !== m.name) add("error", m.line, "lifecycle-case", "`" + m.name + "` is not called by Unity. The exact name is `" + canon + "` (case matters), so this method never runs.", { fix: "lifecycle-case", symbol: m.name });
      });
      const unityFields = ci.fields.filter((f) => UNITY_OBJ.test(f.type.replace(/\[\]|<.*>/g, "")));
      const hasRb = ci.fields.some((f) => /^Rigidbody/.test(f.type)) || /RequireComponent\s*\(\s*typeof\s*\(\s*Rigidbody/.test(content);
      const meths = bodies(path).filter((b) => b.container === c.name);
      meths.forEach((b) => {
        if (HOT.has(b.name)) {
          HOT_RULES.forEach(([re, sev, rule, msg]) => { const m = re.exec(b.text); if (m) add(sev, b.lineOf(m.index), rule, msg + " (in " + b.name + ")"); });
          const cat = new RegExp("\\u0001[^\\u0002]*\\u0002\\s*\\+|\\+\\s*\\u0001").exec(stripped.slice(b.bodyFrom, b.bodyTo));
          if (cat) add("info", lineOfIdx(stripped, b.bodyFrom + cat.index), "string-concat-in-hot-path", "String concatenation each frame allocates; build strings only when the value changes.");
          if (b.name !== "FixedUpdate") {
            const mv = /\btransform\s*\.\s*(?:position\s*\+=|localPosition\s*\+=|Translate\s*\()[^;]*;/.exec(b.text);
            if (mv && !/Time\s*\.\s*(?:deltaTime|smoothDeltaTime|fixedDeltaTime)/.test(mv[0])) add("warning", b.lineOf(mv.index), "no-delta-time", "Movement in " + b.name + " without Time.deltaTime runs faster on faster devices. Multiply by Time.deltaTime.");
            const ph = /\.(?:AddForce|AddTorque|MovePosition|MoveRotation)\s*\(|\.(?:linearVelocity|velocity)\s*=[^=]/.exec(b.text);
            if (ph) add("warning", b.lineOf(ph.index), "physics-in-update", "Physics calls belong in FixedUpdate so they run at the physics step.");
          }
          if (hasRb) { const tp = /\btransform\s*\.\s*(?:position|localPosition)\s*(?:=[^=]|\+=|-=)/.exec(b.text); if (tp) add("warning", b.lineOf(tp.index), "transform-vs-rigidbody", "This object has a Rigidbody, but its transform is written directly. That fights the physics engine and causes jitter or ignored movement; use the Rigidbody."); }
        }
        unityFields.forEach((f) => { const re = new RegExp("\\b" + f.name + "\\s*(?:\\?\\.|\\?\\?)"); const m = re.exec(b.text); if (m) add("warning", b.lineOf(m.index), "null-conditional-on-unity-object", "`" + f.name + "` is a Unity object; `?.` and `??` skip Unity's destroyed-object check and can hide or cause errors. Use `if (" + f.name + " != null)`."); });
        if (/\bInput\.(?:GetKey|GetAxis|GetButton|GetMouseButton|touchCount|GetTouch)/.test(b.text) && inputSystemOnly()) add("warning", b.lineOf(b.text.search(/\bInput\./)), "legacy-input-with-input-system", "This uses the legacy Input class but the project lists the Input System package. If Active Input Handling is set to the new system only, this throws at runtime.");
      });
      if (/\bNavMeshAgent\b/.test(content) && !/\.(?:SetDestination|SetPath|Move|destination\s*=)/.test(content)) add("warning", c.line, "agent-no-destination", "A NavMeshAgent is used but no destination is ever set (SetDestination / destination), so the agent will not move.");
      if (/\bNavMeshAgent\b/.test(content) && /\btransform\s*\.\s*(?:position\s*\+=|Translate\s*\()/.test(content)) add("warning", c.line, "agent-and-transform", "Both a NavMeshAgent and direct transform movement are used; they fight each other. Let the agent move the object.");
      sceneValues(path).forEach((sv) => {
        ci.fields.filter((f) => !f.attrs.includes("HideInInspector") && (f.access === "public" || /SerializeField/.test(f.attrs))).forEach((f) => {
          const v = sv.values[f.name];
          if (v == null) return;
          if (UNITY_OBJ.test(f.type.replace(/\[\]/g, "")) && /fileID:\s*0\b/.test(v)) add("warning", f.line, "unassigned-reference", "`" + f.name + "` (" + f.type + ") is not assigned in " + sv.asset + ", so it is null at runtime unless code sets it.", { asset: sv.asset });
          else if (/^(float|int|double)$/.test(f.type) && /^-?0(\.0+)?$/.test(String(v).trim())) {
            const def = new RegExp("\\b" + f.name + "\\s*=\\s*([-\\d.]+)f?\\s*;").exec(content);
            if (def && !/^-?0(\.0+)?$/.test(def[1])) add("warning", f.line, "serialized-overrides-code", "`" + f.name + "` is " + def[1] + " in code but " + v.trim() + " in " + sv.asset + ". The saved scene/prefab value wins over the code default.", { asset: sv.asset });
          }
        });
      });
    });
    return findings;
  }
  function inputSystemOnly() { const d = current.dependencies(); return Object.keys(d).some((k) => d[k].dependencies.some((x) => /com\.unity\.inputsystem/.test(x))); }
  /* serialized field values written in scenes/prefabs for a script, via its .meta GUID */
  function sceneValues(scriptPath) {
    const meta = current.read(scriptPath + ".meta"), g = meta && /guid:\s*([0-9a-f]{32})/.exec(meta);
    if (!g) return [];
    const out = [];
    current.assetUsage(scriptPath).forEach((a) => {
      const text = current.read(a.path) || "";
      text.split(/^--- !u!/m).forEach((doc) => {
        if (doc.indexOf(g[1]) < 0 || !/m_Script:/.test(doc)) return;
        const values = {};
        doc.split("\n").forEach((l) => { const m = /^  ([A-Za-z_]\w*):\s*(.*)$/.exec(l); if (m && !/^m_/.test(m[1])) values[m[1]] = m[2]; });
        out.push({ asset: a.path, kind: a.kind, values });
      });
    });
    return out;
  }

  /* ---------- general review: security, performance, architecture ---------- */
  const SEC = [
    ["javascript typescript", /\beval\s*\(|new\s+Function\s*\(/, "high", "eval-like execution of strings can run attacker-controlled code", "js-eval"],
    ["javascript typescript", /\.innerHTML\s*=|\.outerHTML\s*=|document\.write\s*\(|insertAdjacentHTML\s*\(/, "high", "writes HTML from a string; if any part is user data this is an XSS risk. Use textContent or sanitise.", "js-xss"],
    ["javascript typescript", /child_process|\bexec(?:Sync)?\s*\(\s*[^)'"`]/, "high", "runs a shell command built from variables; validate input or use an argument array", "js-command-injection"],
    ["javascript typescript", /\bMath\.random\s*\(/, "info", "Math.random is not secure; use crypto.getRandomValues for tokens", "js-weak-random"],
    ["python", /\bos\.system\s*\(|subprocess\.[A-Za-z_]+\([^)]*shell\s*=\s*True/, "high", "shell command execution; user input here is command injection", "py-shell"],
    ["python", /\bpickle\.loads?\s*\(|\byaml\.load\s*\((?![^)]*Loader\s*=\s*yaml\.SafeLoader)|\bmarshal\.loads?\s*\(/, "high", "unsafe deserialisation can execute code; use json or yaml.safe_load", "py-deserialise"],
    ["python", /\bverify\s*=\s*False/, "high", "TLS certificate verification is switched off", "py-no-tls-verify"],
    ["python javascript typescript java kotlin csharp", /\b(?:SELECT|INSERT|UPDATE|DELETE)\b[^;\n]*\u0001[^\u0002]*\u0002\s*\+|\bexecute\w*\s*\(\s*f?\u0001[^\u0002]*(?:\{|%s|\+)/i, "high", "SQL text built with string concatenation; use parameterised queries", "sql-concat"],
    ["csharp", /\bBinaryFormatter\b/, "high", "BinaryFormatter is insecure to deserialise and is obsolete", "cs-binaryformatter"],
    ["java kotlin", /\bRuntime\.getRuntime\(\)\.exec\s*\(|\bObjectInputStream\b/, "high", "command execution or Java deserialisation of untrusted data", "java-exec"],
    ["javascript typescript python java kotlin csharp go rust", /(?:api[_-]?key|secret|passw(?:or)?d|token|private[_-]?key)\w*\s*[:=]\s*\u0001[A-Za-z0-9_\-/+=]{12,}\u0002/i, "high", "looks like a hard-coded credential; move it out of source (and rotate it if it was committed)", "hardcoded-secret"],
    ["javascript typescript python java kotlin csharp go", /\bmd5\b|\bsha-?1\b/i, "warning", "MD5/SHA-1 are broken for security use; use SHA-256 or better (and bcrypt/argon2 for passwords)", "weak-hash"],
    ["javascript typescript python java kotlin csharp", /\u0001http:\/\/(?!localhost|127\.0\.0\.1|10\.|192\.168\.)[^\u0002]+\u0002/, "warning", "plain http:// URL; use https", "plain-http"],
  ];
  const PERF = [
    ["javascript typescript", /JSON\.parse\s*\(\s*JSON\.stringify\s*\(/, "warning", "JSON round-trip deep copy is slow and drops types; use structuredClone", "js-deepcopy"],
    ["javascript typescript", /for\s*\([^)]*\)\s*\{[^{}]*\.(?:includes|indexOf)\s*\(/, "warning", "array search inside a loop is O(n²); use a Set or Map", "js-search-in-loop"],
    ["javascript typescript", /\b(?:readFileSync|writeFileSync|execSync)\b/, "info", "synchronous I/O blocks the event loop if it runs per request", "js-sync-io"],
    ["python", /for\s+\w+\s+in\s+[^:\n]+:\s*\n\s+[^\n]*\b\w+\s*\+=\s*\u0001/, "info", "building a string with += in a loop is quadratic; collect parts and join", "py-str-concat"],
    ["java kotlin csharp", /for\s*\([^)]*\)\s*\{[^{}]*\bnew\s+(?:Regex|Pattern)|Pattern\.compile\s*\([^)]*\)[^;]*;[^}]*for\s*\(/, "info", "compiling a regex inside a loop; compile once", "regex-in-loop"],
  ];
  function ruleScan(path, rules) {
    const content = current.read(path), lang = root.Project.langOf(path);
    if (content == null) return [];
    const text = root.Project.strip(content, lang), out = [];
    rules.forEach(([langs, re, sev, msg, id]) => {
      if (!langs.split(" ").includes(lang)) return;
      const g = new RegExp(re.source, re.flags.includes("g") ? re.flags : re.flags + "g");
      let m, n = 0;
      while ((m = g.exec(text)) && n < 5) { n++; out.push({ severity: sev === "high" ? "error" : sev, path, line: lineOfIdx(text, m.index), rule: id, message: msg }); if (m[0].length === 0) g.lastIndex++; }
    });
    return out;
  }
  const securityReview = (path) => ruleScan(path, SEC);
  const perfReview = (path) => ruleScan(path, PERF).concat(current.isUnity() && root.Project.langOf(path) === "csharp" ? unityReview(path).filter((f) => /hot-path|physics|delta|alloc/.test(f.rule)) : []);

  function architectureReview() {
    const P = current, out = [];
    P.cycles().forEach((c) => out.push({ severity: "warning", rule: "dependency-cycle", path: c[0], message: "dependency cycle between " + c.length + " files: " + c.join(" → ") }));
    P.hotspots().filter((h) => h.fanIn >= 5).forEach((h) => out.push({ severity: "info", rule: "high-fan-in", path: h.path, message: h.fanIn + " files depend on this one; changes here ripple widely (fan-out " + h.fanOut + ")" }));
    P.paths().forEach((p) => { const syms = P.symbolsIn(p); const lines = (P.read(p) || "").split("\n").length; if (lines > 800 || syms.length > 60) out.push({ severity: "info", rule: "oversized-file", path: p, message: lines + " lines and " + syms.length + " symbols in one file; consider splitting by responsibility" }); });
    P.orphans().slice(0, 8).forEach((p) => out.push({ severity: "info", rule: "unreferenced-file", path: p, message: "no other file references this one (and it is not an entry point)" }));
    P.unresolved().slice(0, 15).forEach((u) => out.push({ severity: "warning", rule: "unresolved-import", path: u.file, line: u.line, message: "import \"" + u.spec + "\" does not resolve to a file in the indexed project" }));
    return out;
  }

  function reviewFile(path, opts) {
    opts = opts || {};
    const P = current, findings = [];
    const src = P.read(path);
    if (src == null) return { path, found: false, findings: [] };
    if (root.CodeAnalyzer) { const a = root.CodeAnalyzer.analyze(src, path); a.errors.forEach((m) => findings.push({ severity: "error", path, rule: "static", message: m })); a.warnings.forEach((m) => findings.push({ severity: "warning", path, rule: "static", message: m })); }
    findings.push.apply(findings, securityReview(path));
    findings.push.apply(findings, ruleScan(path, PERF));
    if (P.isUnity() && root.Project.langOf(path) === "csharp") findings.push.apply(findings, unityReview(path));
    const seen = new Set();
    return { path, found: true, findings: findings.filter((f) => { const k = f.rule + f.path + f.line + f.message; if (seen.has(k)) return false; seen.add(k); return true; }) };
  }
  function reviewProject(opts) {
    opts = opts || {};
    const P = current, files = P.paths().filter((p) => /^(javascript|typescript|python|csharp|java|kotlin|go|rust|c|cpp)$/.test(root.Project.langOf(p)));
    let all = [];
    files.slice(0, 600).forEach((p) => { all = all.concat(reviewFile(p).findings); });
    all = all.concat(architectureReview());
    if (P.isUnity()) { const u = root.Validation ? root.Validation.validate(P, [], {}).findings.filter((f) => f.check === "unity-links") : []; all = all.concat(u.map((f) => Object.assign({ rule: "unity-link" }, f))); }
    const by = { error: 0, warning: 0, info: 0 };
    all.forEach((f) => { by[f.severity] = (by[f.severity] || 0) + 1; });
    const perFile = {}; all.forEach((f) => { if (f.path) perFile[f.path] = (perFile[f.path] || 0) + (f.severity === "error" ? 3 : f.severity === "warning" ? 1 : 0.2); });
    const worst = Object.entries(perFile).sort((a, b) => b[1] - a[1]).slice(0, 5).map((e) => e[0]);
    return { counts: by, worst, findings: all.sort((a, b) => ({ error: 0, warning: 1, info: 2 }[a.severity] - { error: 0, warning: 1, info: 2 }[b.severity])), scanned: files.length };
  }

  /* ---------- patches ---------- */
  const mkPatch = (path, before, after) => ({ path, before, after, diff: root.Patch ? root.Patch.unified(before, after, path) : "" });
  function identPositions(content, lang, name) {
    const text = root.Project.blank(content, lang), re = new RegExp("(?<![A-Za-z0-9_$])" + name.replace(/[$]/g, "\\$&") + "(?![A-Za-z0-9_$])", "g"), out = [];
    let m; while ((m = re.exec(text))) out.push(m.index);
    return out;
  }
  function renameSymbol(from, to, opts) {
    opts = opts || {};
    const P = current;
    if (!/^[A-Za-z_$][\w$]*$/.test(String(to))) return { ok: false, reason: "\"" + to + "\" is not a valid identifier" };
    const d = P.whereDefined(from);
    if (!d.definitions.length) return { ok: false, reason: "\"" + from + "\" is not defined in the indexed files" };
    if (d.ambiguous && !opts.path) return { ok: false, reason: "\"" + from + "\" is defined in several places (" + d.definitions.map((x) => x.path).join(", ") + "); say which file, because a lexical rename cannot tell them apart", ambiguous: d.definitions };
    const collide = P.whereDefined(to).definitions.length ? "a symbol named \"" + to + "\" already exists (" + P.whereDefined(to).definitions[0].path + ")" : null;
    if (collide && !opts.force) return { ok: false, reason: "renaming would collide: " + collide };
    const files = opts.path ? [opts.path] : P.references(from).references.map((r) => r.path);
    const patches = [];
    [...new Set(files)].forEach((path) => {
      const content = P.read(path), lang = root.Project.langOf(path), pos = identPositions(content, lang, from);
      if (!pos.length) return;
      let out = content;
      pos.slice().reverse().forEach((i) => { out = out.slice(0, i) + to + out.slice(i + from.length); });
      patches.push(mkPatch(path, content, out));
    });
    const unity = P.isUnity() && d.definitions.some((x) => /\.cs$/.test(x.path) && x.kind === "class");
    return { ok: true, patches, notes: ["Strings and comments are left untouched; a name used only in a string (reflection, serialized data) will not be renamed.", "This is a lexical rename: member accesses (x.name) and object keys with the same name are renamed too, which keeps exports and their callers consistent but would also rename an unrelated member that shares the name."].concat(unity ? ["Unity: renaming a MonoBehaviour class also requires renaming its file (and keeping its .meta), or the scene will show Missing (Script)."] : []), changedFiles: patches.map((p) => p.path) };
  }
  function applyEdits(edits) {
    const patches = [], errors = [], byPath = new Map();
    (edits || []).forEach((e, i) => {
      const path = root.Project.norm(e.path), cur = byPath.has(path) ? byPath.get(path) : current.read(path);
      if (cur == null) { errors.push({ index: i, path, reason: "file is not in the project" }); return; }
      const n = e.find ? cur.split(e.find).length - 1 : 0;
      if (!e.find || n === 0) { errors.push({ index: i, path, reason: "the text to replace was not found" }); return; }
      if (n > 1 && !e.all) { errors.push({ index: i, path, reason: "the text to replace appears " + n + " times; make it unique or set all:true" }); return; }
      byPath.set(path, e.all ? cur.split(e.find).join(e.replace) : cur.replace(e.find, () => e.replace));
    });
    byPath.forEach((after, path) => patches.push(mkPatch(path, current.read(path), after)));
    return { ok: errors.length === 0, patches, errors, changedFiles: patches.map((p) => p.path) };
  }
  function fixLifecycleCase(path) {
    const src = current.read(path); if (src == null) return { ok: false, reason: "file not found" };
    const f = unityReview(path).filter((x) => x.rule === "lifecycle-case");
    if (!f.length) return { ok: false, reason: "no mistyped lifecycle methods found in " + path };
    let out = src;
    f.forEach((x) => { out = out.replace(new RegExp("(?<![A-Za-z0-9_])" + x.symbol + "(?=\\s*\\()", "g"), LIFE_LC.get(x.symbol.toLowerCase())); });
    return { ok: true, patches: [mkPatch(path, src, out)], notes: f.map((x) => "line " + x.line + ": " + x.symbol + " → " + LIFE_LC.get(x.symbol.toLowerCase())), changedFiles: [path] };
  }
  /* GetComponent<T>() inside Update-like methods → cached field assigned in Awake */
  function cacheGetComponent(path) {
    const src = current.read(path); if (src == null) return { ok: false, reason: "file not found" };
    const cls = current.symbolsIn(path).find((s) => s.kind === "class"); if (!cls) return { ok: false, reason: "no class found" };
    const hot = bodies(path).filter((b) => HOT.has(b.name)), want = new Map();
    hot.forEach((b) => { const re = /\bGetComponent\s*<\s*([A-Za-z_][\w.]*)\s*>\s*\(\s*\)/g; let m; while ((m = re.exec(b.raw))) want.set(m[1], "_" + m[1].replace(/^[A-Z]/, (c) => c.toLowerCase()) + "Cached"); });
    if (!want.size) return { ok: false, reason: "no GetComponent<T>() calls in Update/FixedUpdate/LateUpdate" };
    let out = src;
    hot.slice().sort((a, b) => b.bodyFrom - a.bodyFrom).forEach((b) => { let body = b.raw; want.forEach((field, t) => { body = body.replace(new RegExp("\\bGetComponent\\s*<\\s*" + t.replace(/\./g, "\\.") + "\\s*>\\s*\\(\\s*\\)", "g"), field); }); out = out.slice(0, b.bodyFrom) + body + out.slice(b.bodyTo + 1); });
    const fields = [...want].map(([t, f]) => "    private " + t + " " + f + ";").join("\n");
    const assigns = [...want].map(([t, f]) => "        " + f + " = GetComponent<" + t + ">();").join("\n");
    const awake = bodies(path).find((b) => b.name === "Awake");
    const reBodies = () => { const tmp = current.clone(); tmp.updateFile(path, out); const saved = current; current = tmp; const a = bodies(path).find((b) => b.name === "Awake"); current = saved; return a; };
    const classOpen = out.indexOf("{", out.indexOf("class " + cls.name));
    if (awake) { const a = reBodies(); out = out.slice(0, a.bodyFrom + 1) + "\n" + assigns + out.slice(a.bodyFrom + 1); out = out.slice(0, classOpen + 1) + "\n" + fields + out.slice(classOpen + 1); }
    else out = out.slice(0, classOpen + 1) + "\n" + fields + "\n\n    private void Awake()\n    {\n" + assigns + "\n    }\n" + out.slice(classOpen + 1);
    return { ok: true, patches: [mkPatch(path, src, out)], notes: [...want].map(([t, f]) => "GetComponent<" + t + ">() is now cached in " + f + " and assigned in Awake"), changedFiles: [path] };
  }

  /* ---------- the change loop ---------- */
  function change(req, opts) {
    opts = opts || {};
    const steps = [], step = (name, status, detail) => steps.push({ name, status, detail });
    if (!hasProject()) return { ok: false, steps: [{ name: "inspect project", status: "failed", detail: "no project is loaded" }], committed: false };
    step("understand request", "done", req.kind + (req.from ? ": " + req.from + " → " + req.to : req.path ? ": " + req.path : ""));
    let gen;
    try {
      gen = req.kind === "rename" ? renameSymbol(req.from, req.to, req) : req.kind === "edits" ? applyEdits(req.edits) : req.kind === "lifecycle" ? fixLifecycleCase(req.path) : req.kind === "cache-getcomponent" ? cacheGetComponent(req.path) : { ok: false, reason: "unknown change kind: " + req.kind };
    } catch (e) { gen = { ok: false, reason: "error while generating the change: " + e.message }; }
    if (!gen.ok) { step("generate patch", "failed", gen.reason || (gen.errors || []).map((e) => e.reason).join("; ")); return { ok: false, steps, patches: [], committed: false, reason: gen.reason, errors: gen.errors }; }
    const impact = gen.changedFiles.map((p) => ({ path: p, dependents: current.dependents(p, { transitive: true }).map((x) => x.path) }));
    step("inspect project", "done", "affected files: " + gen.changedFiles.join(", "));
    step("generate patch", "done", gen.patches.length + " file(s) changed");
    step("review dependencies", "done", impact.map((i) => i.path + " is used by " + i.dependents.length + " file(s)").join("; "));
    const sandbox = current.clone();
    gen.patches.forEach((p) => sandbox.updateFile(p.path, p.after));
    const baseline = root.Validation ? root.Validation.validate(current, gen.changedFiles, {}) : null;
    const after = root.Validation ? root.Validation.validate(sandbox, gen.changedFiles, { baseline: current }) : null;
    const baseKeys = new Set((baseline ? baseline.findings : []).map((f) => f.check + f.path + f.message));
    const introduced = after ? after.findings.filter((f) => f.severity === "error" && !baseKeys.has(f.check + f.path + f.message)) : [];
    step("validate on a copy", introduced.length ? "failed" : "done", introduced.length ? introduced.length + " new problem(s): " + introduced.slice(0, 3).map((f) => f.message).join("; ") : "no new static or project-level problems. " + (root.Validation ? root.Validation.NOT_EXECUTED : ""));
    let committed = false;
    if (introduced.length) step("fix issues", "needs-user", "I did not apply the change. " + (req.kind === "rename" ? "Resolve the listed problem (often a collision or an import) and try again." : "Adjust the edit and retry."));
    else if (opts.commit) { gen.patches.forEach((p) => current.updateFile(p.path, p.after)); committed = true; step("apply", "done", "applied to the in-memory project; files on disk are unchanged until you save them"); }
    else step("apply", "waiting", "ready to apply; nothing has been changed yet");
    return { ok: !introduced.length, req, steps, patches: gen.patches, notes: gen.notes || [], validation: after, introduced, committed, summary: (gen.patches.length + " file(s): " + gen.changedFiles.join(", ")) };
  }

  /* ---------- tests ---------- */
  function genTests(path) {
    const src = current.read(path); if (src == null) return { ok: false, reason: "file not found" };
    const lang = root.Project.langOf(path);
    if (lang === "csharp") {
      const syms = current.symbolsIn(path), classes = syms.filter((s) => s.kind === "class" && !current.classInfo(s.name).bases.some((b) => /MonoBehaviour|ScriptableObject/.test(b)));
      if (!classes.length) return { ok: false, reason: "every class in " + path + " is a MonoBehaviour/ScriptableObject; EditMode tests need logic extracted into plain C# classes first" };
      const c = classes[0], ms = syms.filter((s) => s.container === c.name && s.kind === "method" && s.exported);
      const body = ms.map((m) => "    [Test]\n    public void " + m.name + "_Works()\n    {\n        var sut = new " + c.name + "();\n        // TODO: choose real inputs and the expected value for " + m.name + "\n        // Assert.AreEqual(expected, sut." + m.name + "(...));\n        Assert.Pass(\"skeleton: add real assertions\");\n    }").join("\n\n");
      return { ok: true, language: "csharp", path: "Assets/Tests/EditMode/" + c.name + "Tests.cs", text: "using NUnit.Framework;\n\npublic class " + c.name + "Tests\n{\n" + body + "\n}\n", note: "Skeleton only: EDO cannot know your expected values. Not executed here." };
    }
    if (root.Programming && root.Programming.genTests) { const r = root.Programming.genTests(src, lang); return { ok: true, language: lang, text: r.text || String(r), note: "Generated from the functions found in " + path + ". Not executed here." }; }
    return { ok: false, reason: "no test generator for " + lang };
  }

  /* ---------- Unity diagnosis ---------- */
  const SCENARIOS = [
    ["enemy-not-moving", /(enem|npc|zombie|monster|\bai\b|agent|foe|boss).{0,40}(not|n't|won't|doesn't|stuck|still|freez|stand|move|moving|chase|follow)|(not|n't|won't).{0,20}mov.{0,20}(enem|npc)/i, "Enemy not moving", "prog-unity-ai"],
    ["null-ref", /null ?ref|nullreference|object reference not set|missingreference/i, "NullReferenceException", "prog-unity-data"],
    ["ui-click", /button.{0,30}(not|n't|doesn't)|(not|n't).{0,30}click|ui.{0,20}(not|n't)|eventsystem|canvas/i, "UI not responding", "prog-unity-ui"],
    ["physics", /fall.{0,20}through|through the (floor|ground)|trigger.{0,20}(not|n't)|collision.{0,20}(not|n't)|ontrigger|oncollision|rigidbody/i, "Physics or collision problem", "prog-unity-physics"],
    ["input", /joystick|touch.{0,20}(not|n't)|input.{0,20}(not|n't)|controls?.{0,20}(not|n't)|input system/i, "Input not working", "prog-unity-input"],
    ["performance", /lag|stutter|slow|low fps|frame ?rate|drops?|performance|freez|heat/i, "Performance", "prog-unity-perf"],
    ["missing-script", /missing ?\(?script|script.{0,20}missing/i, "Missing script", "prog-unity-data"],
  ];
  function scenarioOf(text) { for (const s of SCENARIOS) if (s[1].test(text)) return s; return null; }
  const isUnityQuestion = (t) => /\bunity\b|monobehaviour|gameobject|navmesh|rigidbody|scriptableobject|\bprefab\b|c#.*(game|enemy|player)/i.test(t);

  function candidateFiles(sc) {
    if (!hasProject()) return [];
    const P = current, pat = sc === "enemy-not-moving" ? /enem|zombie|monster|npc|\bai\b|boss|chaser|foe/i : sc === "ui-click" ? /ui|button|menu|canvas|hud/i : sc === "input" ? /input|control|joystick|player|move/i : sc === "physics" ? /player|rigid|physics|collid|character/i : null;
    const names = new Set();
    P.allSymbols(["class"]).forEach((c) => { if (!pat || pat.test(c.name) || pat.test(c.path)) names.add(c.path); });
    return [...names].filter((p) => /\.cs$/.test(p)).slice(0, 6);
  }
  function unityDiagnose(text) {
    const sc = scenarioOf(text) || ["general", null, "Unity problem", "prog-unity-core"];
    const lines = [], evidence = [];
    const files = candidateFiles(sc[0]);
    files.forEach((p) => {
      const fs = unityReview(p);
      const wanted = sc[0] === "enemy-not-moving" ? /lifecycle-case|serialized-overrides|unassigned|agent|transform-vs|physics-in|no-delta/ : sc[0] === "performance" ? /hot-path|alloc|linq|instantiate/ : sc[0] === "null-ref" ? /unassigned|null-conditional/ : sc[0] === "physics" ? /transform-vs|physics-in|lifecycle-case/ : sc[0] === "input" ? /legacy-input|lifecycle/ : /./;
      fs.filter((f) => wanted.test(f.rule)).forEach((f) => evidence.push({ f, line: "• " + loc(f.path, f.line) + " — " + f.message }));
      if (sc[0] === "enemy-not-moving") {
        const ms = bodies(p).filter((b) => HOT.has(b.name) || b.name.toLowerCase() === "update");
        const hasMove = ms.some((b) => /\.(?:SetDestination|MoveTowards|Translate|AddForce|MovePosition|Move)\s*\(|\.velocity\s*=|\.linearVelocity\s*=|transform\.position\s*[+=]/.test(b.text));
        const cls = current.symbolsIn(p).find((s) => s.kind === "class");
        if (cls && !hasMove) evidence.push({ line: "• " + loc(p, cls.line) + " — no movement call (SetDestination, MoveTowards, Translate, AddForce, velocity…) appears in Update/FixedUpdate in " + cls.name + ". Movement may be missing, or driven from another script." });
      }
    });
    if (hasProject() && !files.length && sc[0] !== "general") lines.push("I looked through your project and found no script matching this problem by name, so the points below are general.");
    const intro = "**" + sc[2] + " (Unity)**" + (hasProject() ? " — checked against your loaded project" : "");
    const doc = (root.EDO_DOCS || []).find((d) => d.id === sc[3]);
    const ev = evidence.slice(0, 8).map((e) => e.line);
    const checklist = doc ? doc.debug.slice(0, 6).map((d) => "• " + d) : [];
    const out = [intro];
    if (ev.length) out.push("\n**Found in your code or scenes:**\n" + ev.join("\n"));
    else if (hasProject()) out.push("\nThe code and scene values I can read show none of the common causes for this, so check the editor-side items below.");
    out.push(lines.join("\n"));
    if (checklist.length) out.push("\n**Common causes to check" + (hasProject() ? " (things I cannot see from files: runtime state, Inspector changes not yet saved, project settings)" : "") + ":**\n" + checklist.join("\n"));
    if (!hasProject()) out.push("\nLoad your project folder (Project panel) and I will check your actual scripts and scenes instead of giving a general list. Or paste the script here.");
    return { kind: "programming", text: out.filter(Boolean).join("\n").replace(/\n{3,}/g, "\n\n"), meta: CAVEAT + (doc ? " Knowledge: " + doc.title + "." : ""), suggestions: files.length ? ["Fix mistakes automatically", "Review " + files[0].split("/").pop()] : ["Load project"], evidence: evidence.map((e) => e.f).filter(Boolean), scenario: sc[0] };
  }

  /* ---------- question answering ---------- */
  const SYM = "([A-Za-z_$][\\w$.]*(?:\\(\\))?)";
  const Q = [
    ["defined", new RegExp("(?:where(?:'s| is| are)|find|locate|show)\\s+(?:the\\s+)?(?:definition of\\s+)?`?" + SYM + "`?\\s*(?:defined|declared|located)?", "i"), /where|definition|locate|defined/i],
    ["uses", new RegExp("(?:what|which files?|who)\\s+(?:uses?|calls?|references?|touches)\\s+(?:the\\s+)?(?:function |class |method )?`?" + SYM, "i")],
    ["refs", new RegExp("(?:find|list|show)\\s+(?:all\\s+)?(?:the\\s+)?references?\\s+(?:to|of|for)\\s+`?" + SYM, "i")],
    ["depends", new RegExp("(?:what|which)\\s+files?\\s+depend(?:s)?\\s+on\\s+`?([\\w./-]+)", "i")],
    ["impact", new RegExp("what\\s+(?:will|would|could|might)\\s+break\\s+(?:if|when)\\s+i\\s+(?:change|rename|delete|remove|modify|edit)\\s+`?([\\w./$-]+)", "i")],
    ["rename", new RegExp("rename\\s+`?([A-Za-z_$][\\w$]*)`?\\s+to\\s+`?([A-Za-z_$][\\w$]*)", "i")],
    ["tests", new RegExp("(?:generate|write|add|create)\\s+(?:unit\\s+)?tests?\\s+for\\s+`?([\\w./-]+)", "i")],
    ["fixall", /\b(?:fix|repair)\b.{0,25}\b(?:lifecycle|update typo|mistakes?|getcomponent)|fix mistakes automatically/i],
    ["architecture", /architecture|dependency cycles?|circular|coupling|hotspots?/i],
    ["security", /security (?:review|audit|check|issues?)|vulnerab/i],
    ["perf", /performance (?:review|check|issues?)|why is .{0,40} slow/i],
    ["review", /(?:review|analy[sz]e|audit|check)\s+(?:the\s+|my\s+)?(?:whole\s+)?(?:project|codebase|repo|code)\b|project health/i],
    ["overview", /(?:project|codebase|repo)\s+(?:overview|summary|structure)|what(?:'s| is) (?:in )?(?:this|the|my) (?:project|codebase)|entry ?points?|which files? (?:are|is) (?:the )?main/i],
    ["reviewfile", /(?:review|check|analy[sz]e)\s+`?([\w./-]+\.\w{1,5})`?/i],
  ];
  function match(text) {
    for (const [kind, re] of Q) { const m = re.exec(text); if (m) { if (kind === "defined" && !/where|definition|locate|defined/i.test(text)) continue; return { kind, m }; } }
    return null;
  }
  function canAnswer(text, ctx) {
    const t = String(text || "");
    if (isUnityQuestion(t) || (scenarioOf(t) && /\b(unity|enemy|npc|navmesh|rigidbody|prefab|canvas)\b/i.test(t))) return true;
    if (!hasProject()) return false;
    if (match(t)) return true;
    return /\b(my|this|the)\s+(project|codebase)\b/i.test(t) || /crash|keeps? (?:crashing|failing)/i.test(t);
  }
  function fmtRefs(refs, max) { return refs.slice(0, max).map((r) => "• " + loc(r.path, r.line) + (r.definition ? " (definition)" : "") + (r.text ? "  " + r.text : "")).join("\n") + (refs.length > max ? "\n… and " + (refs.length - max) + " more" : ""); }
  function notFound(name) {
    const sug = current.search(name, 4).map((s) => s.name + " (" + s.path + ")");
    return { kind: "programming", text: "I could not find `" + name + "` in the " + current.stats().files + " indexed files." + (sug.length ? " Did you mean: " + sug.join(", ") + "?" : ""), meta: CAVEAT };
  }
  function pretty(f) { return "• " + (f.severity === "error" ? "✖ " : f.severity === "warning" ? "▲ " : "· ") + loc(f.path, f.line) + " — " + f.message; }
  function overview() {
    const s = current.stats(), eps = current.entryPoints(), deps = current.dependencies(), ext = current.externalModules();
    const langs = Object.entries(s.languages).filter(([k]) => !["meta", "other", "text", "markdown"].includes(k)).sort((a, b) => b[1] - a[1]).map(([k, v]) => v + " " + k).join(", ");
    const hot = current.hotspots().slice(0, 4).map((h) => h.path + " (used by " + h.fanIn + ")").join(", ");
    const extTop = Object.entries(ext).sort((a, b) => b[1] - a[1]).slice(0, 6).map((e) => e[0]).join(", ");
    return "**" + s.name + "**: " + s.files + " files (" + langs + "), " + s.symbols + " symbols, " + s.edges + " dependency links" + (s.unity ? ", a Unity project" : "") + "." +
      (eps.length ? "\n**Entry points:** " + eps.slice(0, 5).map((e) => e.path + " (" + e.why + ")").join("; ") : "") +
      (hot ? "\n**Most depended-on:** " + hot : "") + (extTop ? "\n**External modules used:** " + extTop : "") +
      (Object.keys(deps).length ? "\n**Declared dependencies:** " + Object.values(deps).flatMap((d) => d.dependencies).slice(0, 8).join(", ") : "") +
      (s.ignored ? "\n(" + s.ignored + " files skipped: dependencies, build output, binaries.)" : "") + (s.truncated ? "\nIndex truncated: " + s.truncated + "." : "");
  }

  function answer(text, ctx) {
    const t = String(text || "");
    const q = hasProject() ? match(t) : null;
    if (!q) return isUnityQuestion(t) || scenarioOf(t) ? unityDiagnose(t) : null;
    const P = current, m = q.m, meta = CAVEAT;
    const res = (txt, extra) => Object.assign({ kind: "programming", text: txt, meta, suggestions: [] }, extra || {});
    switch (q.kind) {
      case "defined": { const d = P.whereDefined(m[1]); if (!d.definitions.length) return notFound(m[1].replace(/\(\)$/, "")); return res("`" + d.name + "` is defined " + (d.ambiguous ? "in " + d.definitions.length + " places (same name, so I cannot tell which you mean):" : "at:") + "\n" + d.definitions.map((x) => "• " + loc(x.path, x.line) + " — " + x.kind + (x.container ? " in " + x.container : "") + (x.signature ? ": " + x.signature : "")).join("\n"), { suggestions: ["What uses " + d.name + "?"] }); }
      case "uses": case "refs": { const r = P.references(m[1]); if (!r.total) return notFound(m[1].replace(/\(\)$/, "")); return res("`" + r.name + "`: " + r.uses + " use(s) in " + new Set(r.references.filter((x) => !x.definition).map((x) => x.path)).size + " file(s)." + (r.caveat ? " " + r.caveat : "") + "\n" + fmtRefs(r.references, 15), { suggestions: ["What breaks if I change " + r.name + "?"] }); }
      case "depends": { const p = P.hasFile(m[1]) ? m[1] : (P.paths().find((x) => x.endsWith("/" + m[1]) || x.endsWith(m[1])) || m[1]); if (!P.hasFile(p)) return notFound(m[1]); const d = P.dependents(p, { transitive: true }); return res(d.length ? d.length + " file(s) depend on `" + p + "` (directly or through others):\n" + d.slice(0, 20).map((x) => "• " + x.path + (x.depth > 1 ? " (via " + (x.depth - 1) + " other file" + (x.depth > 2 ? "s" : "") + ")" : "")).join("\n") : "No other file imports `" + p + "`. It may be an entry point or unused."); }
      case "impact": { const key = P.hasFile(m[1]) ? m[1] : (P.paths().find((x) => x.endsWith("/" + m[1])) || m[1]); const i = P.impact(key); if (i.found === false) return notFound(m[1]); const body = i.kind === "file" ? "Changing `" + i.path + "`: " + i.directDependents.length + " direct and " + i.transitiveDependents.length + " total dependent file(s). Risk: **" + i.risk + "**." + (i.symbolsInUse.length ? "\nSymbols others use: " + i.symbolsInUse.slice(0, 6).map((u) => u.symbol + " (" + u.usedIn.length + " file" + (u.usedIn.length > 1 ? "s" : "") + ")").join(", ") : "") + (i.assets.length ? "\nAttached in Unity assets: " + i.assets.map((a) => a.path).join(", ") : "") : "Changing `" + i.symbol + "`: used in " + i.usedIn.length + " file(s): " + i.usedIn.slice(0, 8).join(", ") + ". Risk: **" + i.risk + "**." + (i.ambiguous ? " (Several symbols share this name.)" : ""); return res(body + "\n" + i.caveat, { impact: i }); }
      case "rename": { const r = change({ kind: "rename", from: m[1], to: m[2] }, { commit: false }); const head = r.ok ? "Rename `" + m[1] + "` → `" + m[2] + "` is ready, not applied yet:" : "I did not prepare the rename: " + (r.reason || (r.introduced || []).map((x) => x.message).join("; ")); return res(head + "\n" + r.steps.map((s) => "• " + s.name + ": " + s.detail).join("\n") + (r.ok ? "\n\n" + r.patches.map((p) => p.diff).join("\n").slice(0, 2500) : ""), { change: r, suggestions: r.ok ? ["Apply the change"] : [] }); }
      case "tests": { const p = P.hasFile(m[1]) ? m[1] : (P.paths().find((x) => x.endsWith("/" + m[1])) || m[1]); const r = genTests(p); return res(r.ok ? "```" + (r.language === "csharp" ? "csharp" : r.language) + "\n" + r.text.trim() + "\n```\n" + r.note : "Cannot generate tests: " + r.reason); }
      case "fixall": { const files = P.paths().filter((p) => /\.cs$/.test(p)); const done = []; for (const f of files) { const r = change({ kind: "lifecycle", path: f }, { commit: false }); if (r.ok) done.push(r); } return res(done.length ? "Prepared lifecycle-name fixes for " + done.length + " file(s):\n" + done.map((r) => r.patches.map((p) => p.diff).join("\n")).join("\n").slice(0, 2500) : "No mistyped lifecycle methods found in the C# files.", { change: done[0] || null, changes: done, suggestions: done.length ? ["Apply the change"] : [] }); }
      case "architecture": { const f = architectureReview(); return res(f.length ? "**Architecture review** (" + f.length + " observations):\n" + f.slice(0, 14).map(pretty).join("\n") : "No cycles, oversized files or unresolved imports found."); }
      case "security": { let all = []; P.paths().forEach((p) => { all = all.concat(securityReview(p)); }); return res(all.length ? "**Security review** (pattern-based, " + all.length + " finding(s)):\n" + all.slice(0, 15).map(pretty).join("\n") + "\nThese are patterns, not proof of an exploit; confirm each in context." : "No known risky patterns found in the indexed source files. This is a pattern check, not a full audit."); }
      case "perf": { let all = []; P.paths().forEach((p) => { all = all.concat(perfReview(p)); }); return res(all.length ? "**Performance review** (" + all.length + " finding(s)):\n" + all.slice(0, 15).map(pretty).join("\n") + "\nMeasure with a profiler before optimising." : "No known slow patterns found."); }
      case "review": { const r = reviewProject(); return res("**Project review** of " + r.scanned + " source files: " + r.counts.error + " error(s), " + r.counts.warning + " warning(s), " + r.counts.info + " note(s)." + (r.worst.length ? "\nMost findings: " + r.worst.join(", ") : "") + "\n" + r.findings.slice(0, 12).map(pretty).join("\n"), { review: r, suggestions: r.worst.length ? ["Review " + r.worst[0].split("/").pop()] : [] }); }
      case "reviewfile": { const p = P.hasFile(m[1]) ? m[1] : (P.paths().find((x) => x.endsWith("/" + m[1])) || m[1]); const r = reviewFile(p); if (!r.found) return notFound(m[1]); return res(r.findings.length ? "**" + p + "** — " + r.findings.length + " finding(s):\n" + r.findings.slice(0, 15).map(pretty).join("\n") : "**" + p + "**: no findings from the static, security, performance and framework rules."); }
      case "overview": return res(overview(), { suggestions: ["Review the project", "Show dependency cycles"] });
    }
    return null;
  }

  /* crash triage: errors the user pasted → files and lines in the project; otherwise the riskiest places */
  function triage() {
    if (!hasProject()) return null;
    const P = current, live = P.live(), lines = [];
    if (live.recentErrors.length) {
      const e = live.recentErrors[0], locs = root.Project.parseErrorLocations(e.text);
      lines.push("The latest error you gave me: `" + e.text.split("\n")[0].slice(0, 140) + "`");
      locs.forEach((l) => { const path = P.paths().find((p) => p === l.file || p.endsWith("/" + l.file.split("/").pop())); if (path) lines.push("• " + loc(path, l.line) + (snippet(path, l.line) ? " — `" + snippet(path, l.line) + "`" : "")); });
    }
    const r = reviewProject(), top = r.findings.filter((f) => f.severity === "error").slice(0, 4);
    if (top.length) lines.push("Likely crash risks I can see in the code:\n" + top.map(pretty).join("\n"));
    return lines;
  }
  function frustrated(text, ctx, ent) {
    const lead = ["That sounds frustrating, and a crashing project is a hard thing to debug while annoyed.", "I get it, a crash that keeps coming back wears you down.", "Okay. Let's make it smaller and find it."][(text.length + 1) % 3];
    const body = hasProject() ? triage() : null;
    let t;
    if (body && body.length) t = lead + " I checked your loaded project:\n\n" + body.join("\n") + "\n\nPaste the exact error or stack trace and I'll match it to a line.";
    else if (hasProject()) t = lead + " I checked your project and found no obvious crash patterns in the code, so I need the actual error. Paste the error message or stack trace (or the Unity Console text) and I'll tie it to a file and line.";
    else t = lead + " To find it, I need something concrete: paste the error message or stack trace, or load your project folder in the Project panel and I'll look through the files for crash risks.";
    return { kind: "programming", text: t, meta: hasProject() ? CAVEAT : "Rule-based. Nothing was run.", suggestions: hasProject() ? ["Review the project", "Fix mistakes automatically"] : ["Load project"], engine: "code-brain" };
  }

  root.CodeBrain = { setProject, project, hasProject, canAnswer, answer, frustrated, triage, unityDiagnose, unityReview, reviewFile, reviewProject, securityReview, perfReview, architectureReview, renameSymbol, applyEdits, fixLifecycleCase, cacheGetComponent, change, genTests, sceneValues, bodies, CAVEAT };
})();
