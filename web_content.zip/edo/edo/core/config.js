/* EDO configuration layer. One validated store for AI provider, key, model, voice, wake phrase, permissions, memory, search,
   vision, live mode, privacy and proactive behaviour. Pure logic; storage is injected so it runs in Node tests.
   API keys live under their own storage key (one per provider), is never part of export() or any log line, and is returned only by getSecret().
   Globals: window.EdoConfig */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  const PROVIDERS = ["none", "gemini", "openai", "claude", "local", "proxy"];
  const DEFAULTS = {
    ai: { provider: "none", models: { gemini: "", openai: "", claude: "" }, endpoint: "", fallback: [], temperature: 0.4, timeoutMs: 30000, retries: 2, maxHistory: 12 },
    voice: { lang: "en-IN", wakePhrase: "hey edo", wakeEnabled: false, speakReplies: false, rate: 1, pitch: 1, vad: true, bargeIn: true },
    permissions: { confirmSensitive: true, allowClipboardRead: false, allowCalls: true, allowMessages: true },
    memory: { enabled: true, retentionDays: 90, localOnly: true },
    search: { provider: "none", endpoint: "", maxResults: 5, fetchPages: false },
    vision: { enabled: false, provider: "ai" },
    live: { enabled: false, camera: false, screen: false },
    privacy: { logContent: false, sendMemoryToProvider: false, sendDeviceContextToProvider: false },
    proactive: { enabled: false, cooldownMin: 120, kinds: { reminders: true, unfinished: true, routines: false } },
  };
  /* path -> validator returning the cleaned value or throwing */
  const str = (max, re) => (v) => { v = String(v == null ? "" : v).trim(); if (v.length > max) throw Error("too long (max " + max + ")"); if (re && v && !re.test(v)) throw Error("invalid format"); return v; };
  const bool = (v) => { if (typeof v !== "boolean") throw Error("must be true or false"); return v; };
  const num = (lo, hi) => (v) => { v = Number(v); if (!isFinite(v) || v < lo || v > hi) throw Error("must be between " + lo + " and " + hi); return v; };
  const httpsOrLocal = (v) => {
    v = String(v || "").trim(); if (!v) return "";
    let u; try { u = new URL(v); } catch (e) { throw Error("not a valid URL"); }
    const local = /^(localhost|127\.0\.0\.1)$/.test(u.hostname);
    if (u.protocol !== "https:" && !(u.protocol === "http:" && local)) throw Error("must be https:// (http:// only for localhost)");
    if (u.username || u.password) throw Error("URL must not contain credentials");
    return u.href;
  };
  const RULES = {
    "ai.provider": (v) => { v = String(v).toLowerCase(); if (!PROVIDERS.includes(v)) throw Error("unknown provider (" + PROVIDERS.join(", ") + ")"); return v; },
    "ai.models.gemini": str(100, /^[\w.\-:\/]*$/), "ai.models.openai": str(100, /^[\w.\-:\/]*$/), "ai.models.claude": str(100, /^[\w.\-:\/]*$/), "ai.endpoint": httpsOrLocal, "ai.temperature": num(0, 2), "ai.timeoutMs": num(1000, 120000), "ai.retries": num(0, 5), "ai.maxHistory": num(0, 50),
    "ai.fallback": (v) => { if (!Array.isArray(v) || v.length > 4) throw Error("fallback must be a list of up to 4 providers"); return v.map((x) => RULES["ai.provider"](x)); },
    "voice.lang": str(12, /^[a-z]{2,3}(-[A-Za-z]{2,4})?$/), "voice.wakePhrase": (v) => { v = String(v).trim().toLowerCase(); if (v.length < 4 || v.length > 40 || !/^[a-z\u0900-\u097f' ]+$/.test(v) || v.split(/\s+/).length < 2) throw Error("wake phrase needs 2-6 words of letters (min 4 chars)"); return v; },
    "voice.wakeEnabled": bool, "voice.speakReplies": bool, "voice.rate": num(0.5, 2), "voice.pitch": num(0.5, 2), "voice.vad": bool, "voice.bargeIn": bool,
    "permissions.confirmSensitive": (v) => { if (v !== true) throw Error("confirmation for sensitive actions cannot be turned off"); return true; },
    "permissions.allowClipboardRead": bool, "permissions.allowCalls": bool, "permissions.allowMessages": bool,
    "memory.enabled": bool, "memory.retentionDays": num(1, 3650), "memory.localOnly": bool,
    "search.provider": str(20, /^[a-z]+$/), "search.endpoint": httpsOrLocal, "search.maxResults": num(1, 10), "search.fetchPages": bool,
    "vision.enabled": bool, "vision.provider": str(20, /^[a-z]+$/),
    "live.enabled": bool, "live.camera": bool, "live.screen": bool,
    "privacy.logContent": bool, "privacy.sendMemoryToProvider": bool, "privacy.sendDeviceContextToProvider": bool,
    "proactive.enabled": bool, "proactive.cooldownMin": num(5, 1440), "proactive.kinds.reminders": bool, "proactive.kinds.unfinished": bool, "proactive.kinds.routines": bool,
  };
  const clone = (o) => JSON.parse(JSON.stringify(o));
  function create(storage, key) {
    key = key || "edo_config_v1";
    let data = clone(DEFAULTS), secrets = {}, subs = [];
    const mem = {};
    const store = storage || { getItem: (k) => (k in mem ? mem[k] : null), setItem: (k, v) => { mem[k] = String(v); }, removeItem: (k) => { delete mem[k]; } };
    function walk(path, create) { const p = path.split("."); let o = data; for (let i = 0; i < p.length - 1; i++) { if (o[p[i]] == null || typeof o[p[i]] !== "object") return null; o = o[p[i]]; } return { o, k: p[p.length - 1] }; }
    const api = {
      PROVIDERS, DEFAULTS: clone(DEFAULTS),
      get(path) { const w = walk(path); return w && w.k in w.o ? clone({ v: w.o[w.k] }).v : undefined; },
      /* set returns {ok, error?}; it never throws and never stores an invalid value. Unknown paths are refused. */
      set(path, value) {
        const rule = RULES[path]; if (!rule) return { ok: false, error: "unknown setting: " + path };
        let v; try { v = rule(value); } catch (e) { return { ok: false, error: path + ": " + e.message }; }
        const w = walk(path); w.o[w.k] = v; api._save(); subs.slice().forEach((f) => { try { f(path, path === "ai.apiKey" ? undefined : v); } catch (e) {} });
        return { ok: true };
      },
      /* One key per provider (a Gemini key is useless to OpenAI). provider defaults to the chosen one. */
      setSecret(k, provider) { provider = provider || data.ai.provider; k = String(k || "").trim(); if (!["gemini", "openai", "claude"].includes(provider)) return { ok: false, error: "keys are stored for gemini, openai or claude" }; if (k.length > 400 || /[\s\u0000-\u001f]/.test(k)) return { ok: false, error: "API key has invalid characters or is too long" }; secrets[provider] = k; api._saveSecrets(); subs.slice().forEach((f) => { try { f("ai.apiKey", undefined); } catch (e) {} }); return { ok: true }; },
      getSecret(provider) { return secrets[provider || data.ai.provider] || ""; },
      hasSecret(provider) { return !!api.getSecret(provider); },
      modelFor(provider) { return (data.ai.models && data.ai.models[provider || data.ai.provider]) || ""; },
      clearSecret(provider) { if (provider) delete secrets[provider]; else secrets = {}; api._saveSecrets(); },
      _saveSecrets() { try { if (Object.keys(secrets).length) store.setItem(key + ":secret", JSON.stringify(secrets)); else store.removeItem(key + ":secret"); } catch (e) {} },
      /* Settings with the key removed: safe to show, export or log. */
      export() { const o = clone(data); o.ai.keysSet = Object.keys(secrets).filter((k) => secrets[k]); return o; },
      subscribe(fn) { subs.push(fn); return () => { subs = subs.filter((f) => f !== fn); }; },
      reset() { data = clone(DEFAULTS); secrets = {}; try { store.removeItem(key); store.removeItem(key + ":secret"); } catch (e) {} },
      _save() { try { store.setItem(key, JSON.stringify(data)); } catch (e) {} },
      /* Corrupt or hostile stored values fall back to defaults field by field. */
      load() {
        let j = null; try { j = JSON.parse(store.getItem(key) || "null"); } catch (e) { j = null; }
        data = clone(DEFAULTS); let skipped = 0;
        const apply = (o, pre) => { if (!o || typeof o !== "object" || Array.isArray(o)) return; Object.keys(o).forEach((k) => { const p = pre + k; if (RULES[p]) { try { const w = walk(p); w.o[w.k] = RULES[p](o[k]); } catch (e) { skipped++; } } else if (o[k] && typeof o[k] === "object" && !Array.isArray(o[k])) apply(o[k], p + "."); else skipped++; }); };
        apply(j, "");
        secrets = {}; try { const j2 = JSON.parse(store.getItem(key + ":secret") || "{}"); if (j2 && typeof j2 === "object") ["gemini", "openai", "claude"].forEach((k) => { if (typeof j2[k] === "string" && j2[k].length <= 400) secrets[k] = j2[k]; }); } catch (e) { secrets = {}; }
        return { skipped };
      },
      /* True when a remote provider could actually be called: provider chosen, model set, key present (proxy/local need no key). */
      providerReady(name) {
        name = name || data.ai.provider;
        if (name === "none") return false; if (name === "local") return true;
        if (name === "proxy") return !!data.ai.endpoint;
        return !!(secrets[name] && data.ai.models[name]);
      },
    };
    api.load();
    return api;
  }
  root.EdoConfig = Object.assign(create(typeof localStorage !== "undefined" ? (function () { try { return localStorage; } catch (e) { return null; } })() : null), { create });
})();
