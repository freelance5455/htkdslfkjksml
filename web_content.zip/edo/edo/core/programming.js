/* EDO programming engine. Modular, language-aware, static only: EDO never executes user code or its own output.
   Capabilities: explain code, generate (reviewed templates), debug/fix with diffs, refactor/optimize hints,
   explain compiler/runtime errors, generate tests, complexity reasoning, algorithm comparison, requirement tracking.
   Depends on CodeAnalyzer, Patch, EDO_CODE, EDO_ALGO (all optional; degrades honestly). No UI/voice/device/network. */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  const LANGS = { javascript: /\b(javascript|js|node(?:\.?js)?)\b/i, typescript: /\b(typescript|ts)\b/i, python: /\bpython3?\b|\bpy\b/i, cpp: /\bc\+\+|\bcpp\b/i, csharp: /\bc#|\bcsharp\b|\bunity\b/i, java: /\bjava\b(?!\s*script)/i, kotlin: /\bkotlin\b/i, c: /(?:\bin c\b|\bc language\b|\bc program\b|\bplain c\b)/i, html: /\bhtml\b/i, css: /\bcss\b/i, sql: /\bsql\b/i, bash: /\b(bash|shell script|shell)\b/i };
  const NAMES = { javascript: "JavaScript", typescript: "TypeScript", python: "Python", c: "C", cpp: "C++", java: "Java", kotlin: "Kotlin", csharp: "C#", html: "HTML", css: "CSS", sql: "SQL", bash: "Bash" };
  const FENCE = /```([A-Za-z0-9+#.\-]*)[ \t]*\n?([\s\S]*?)```/;

  function langFromText(t) { for (const k of Object.keys(LANGS)) if (LANGS[k].test(t)) return k; return null; }
  const out = (text, meta, extra) => Object.assign({ kind: "programming", text, meta: meta || "Static analysis only. EDO did not run any code." }, extra || {});
  const block = (lang, code) => "```" + lang + "\n" + String(code).replace(/\n$/, "") + "\n```";

  /* ---------- error explainer ---------- */
  const ERRORS = [
    [/Cannot read propert(?:y|ies) of (undefined|null)|TypeError: (?:undefined|null) is not (?:an object|a function)/i, "JavaScript: you used a property or called a function on a value that is undefined/null.", ["Print the value one step earlier to see where it becomes undefined.", "Guard it: `obj?.prop` or `if (obj == null) return`.", "Check async timing: the data may not have loaded yet."]],
    [/(\w+) is not defined/i, "JavaScript ReferenceError: a name is used that was never declared in scope.", ["Check spelling and case.", "Declare it with const/let before use, or import it.", "In a browser, make sure the script that defines it loads earlier."]],
    [/(\w+) is not a function/i, "JavaScript TypeError: the value you called is not a function.", ["Check that you didn't overwrite the name, or call a property that doesn't exist.", "Log `typeof name`."]],
    [/Unexpected token|SyntaxError: (?:Unexpected|Invalid|missing)/i, "Syntax error: the parser hit a symbol where it did not expect one.", ["Look at the line reported AND the line before it (a missing ) } ] or comma is usually earlier).", "Check quotes and brackets are balanced."]],
    [/Maximum call stack size exceeded|RecursionError|StackOverflowError|stack overflow/i, "Infinite or too-deep recursion exhausted the call stack.", ["Check the base case is reachable.", "Convert deep recursion to a loop or explicit stack."]],
    [/IndentationError|TabError|unexpected indent|expected an indented block/i, "Python indentation problem.", ["Use 4 spaces consistently; do not mix tabs and spaces.", "After a line ending with ':' the next line must be indented."]],
    [/NameError: name '?(\w+)'? is not defined/i, "Python NameError: variable or function used before it was defined.", ["Check spelling, definition order and scope.", "Did you forget an import?"]],
    [/ModuleNotFoundError|ImportError|No module named/i, "Python cannot find that module.", ["Install it (pip install <name>) in the same environment you run.", "Check the file isn't shadowing a stdlib module name."]],
    [/KeyError/i, "Python KeyError: dictionary key does not exist.", ["Use `d.get(key)` or check `key in d`."]],
    [/IndexError|ArrayIndexOutOfBounds|IndexOutOfRange|out of range/i, "Index outside the valid range 0..length-1.", ["Check loop bounds (< length, not <=).", "Check the collection is not empty before reading [0]."]],
    [/ZeroDivisionError|division by zero|divide by zero|ArithmeticException: \/ by zero/i, "Division by zero.", ["Validate the divisor before dividing.", "Check for an uninitialised counter or empty input."]],
    [/NullPointerException|NullReferenceException|Object reference not set/i, "Null dereference: you used an object that is null.", ["Find which reference is null from the stack trace line.", "Initialise it, or check for null (Kotlin: use ?. and ?:).", "Unity: assign the field in the Inspector or via GetComponent in Awake."]],
    [/segmentation fault|SIGSEGV|core dumped/i, "Segmentation fault: invalid memory access (C/C++).", ["Check pointers for NULL and for use after free.", "Check array bounds and buffer sizes.", "Compile with -g -fsanitize=address,undefined and run again to find the exact line."]],
    [/undefined reference to|unresolved external symbol|ld returned 1 exit status/i, "Linker error: the function is declared but its definition was not linked.", ["Add the missing .c/.cpp file or library (-l...) to the build.", "Check the function signature matches exactly (extern \"C\" for C from C++)."]],
    [/expected ['"`]?;|expected ';'|error: expected/i, "Compiler error: missing or misplaced symbol (often ';' ')' or '}').", ["Read the FIRST error only; later ones usually cascade from it.", "Check the line above the reported line."]],
    [/incompatible types|cannot convert|cannot be converted|type mismatch|Type '.*' is not assignable/i, "Type mismatch between what you provide and what is expected.", ["Add an explicit conversion, or fix the declared type.", "TypeScript: narrow the type with a check before use."]],
    [/cannot find symbol|does not exist in the current context|Unresolved reference|undeclared identifier/i, "The compiler cannot find that name.", ["Check spelling, imports/using, and that the member exists on that type."]],
    [/ConcurrentModificationException|collection was modified/i, "A collection was changed while iterating over it.", ["Iterate over a copy, or collect changes and apply them after the loop."]],
    [/CORS|Cross-Origin Request Blocked|blocked by CORS/i, "Browser blocked a cross-origin request: the server did not allow your origin.", ["The fix is on the server: send Access-Control-Allow-Origin (and handle OPTIONS).", "A frontend change alone cannot bypass CORS."]],
    [/Failed to fetch|NetworkError|ERR_CONNECTION|ECONNREFUSED/i, "The request never reached a server (offline, wrong URL/port, server down or blocked).", ["Check the URL, that the server is running, and https/http mixed content."]],
    [/syntax error near unexpected token|command not found|Permission denied/i, "Shell error.", ["'command not found': check PATH or spelling.", "'Permission denied': chmod +x file, or check ownership.", "Quote variables and check for stray characters or Windows line endings (\\r)."]],
    [/no such table|no such column|syntax error at or near|Unknown column|SQLSyntaxError|ORA-\d+/i, "SQL error: the query refers to something that doesn't exist or is malformed.", ["Check table/column names and quoting.", "Run the query piece by piece."]],
    [/Uncaught \(in promise\)|UnhandledPromiseRejection/i, "A rejected Promise had no catch handler.", ["Add .catch(...) or try/catch around await."]],
  ];
  function explainError(text) {
    for (const [re, what, fixes] of ERRORS) {
      const m = re.exec(text);
      if (m) return out("**What this error means**\n" + what + "\n\n**What to try**\n" + fixes.map((f) => "- " + f).join("\n") +
        "\n\nI matched this against a fixed table of common errors. Paste the code and the exact line number for a specific diagnosis.", "Error table match. No code was run.", { matched: true });
    }
    return null;
  }

  /* ---------- mechanical fixes (only transformations that preserve meaning) ---------- */
  function mapOutsideStrings(line, fn) {
    const parts = line.split(/("(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|`(?:\\.|[^`\\])*`)/);
    return parts.map((p, i) => (i % 2 ? p : fn(p))).join("");
  }
  const FIXES = {
    javascript: [
      ["Use strict equality (== → ===, != → !==)", (l) => mapOutsideStrings(l, (p) => p.replace(/([^=!<>])==(?!=)/g, "$1===").replace(/!=(?!=)/g, "!=="))],
      ["parseInt with an explicit radix", (l) => mapOutsideStrings(l, (p) => p.replace(/\bparseInt\(\s*([^(),]+?)\s*\)/g, "parseInt($1, 10)"))],
    ],
    python: [
      ["Compare with None using 'is'", (l) => l.replace(/\s==\s*None\b/g, " is None").replace(/\s!=\s*None\b/g, " is not None")],
      ["Catch Exception instead of a bare except", (l) => l.replace(/^(\s*)except\s*:/, "$1except Exception:")],
    ],
    java: [["Compare strings with equals()", (l) => l.replace(/(\b\w+(?:\.\w+)*)\s*==\s*("(?:\\.|[^"\\])*")/g, "$2.equals($1)")]],
  };
  FIXES.typescript = FIXES.javascript;
  function pyMutableDefault(code) {
    const lines = code.split("\n"), res = [], changed = [];
    for (let i = 0; i < lines.length; i++) {
      const m = /^(\s*)def\s+(\w+)\((.*)\)\s*:\s*$/.exec(lines[i]);
      if (!m) { res.push(lines[i]); continue; }
      const inits = [];
      const args = m[3].replace(/(\w+)\s*=\s*(\[\]|\{\}|set\(\))/g, (x, name, val) => { inits.push([name, val]); return name + "=None"; });
      if (!inits.length) { res.push(lines[i]); continue; }
      res.push(m[1] + "def " + m[2] + "(" + args + "):");
      const body = (/^(\s+)\S/.exec(lines[i + 1] || "") || [])[1] || m[1] + "    ";
      inits.forEach(([n, v]) => res.push(body + "if " + n + " is None:\n" + body + "    " + n + " = " + v));
      changed.push(m[2]);
    }
    return { code: res.join("\n"), changed };
  }
  function autoFix(code, lang) {
    let cur = String(code); const applied = [];
    (FIXES[lang] || []).forEach(([name, fn]) => {
      const next = cur.split("\n").map(fn).join("\n");
      if (next !== cur) { applied.push(name); cur = next; }
    });
    if (lang === "python") { const r = pyMutableDefault(cur); if (r.changed.length) { applied.push("Replace mutable default argument(s) in " + r.changed.join(", ") + " with None"); cur = r.code; } }
    return { code: cur, applied };
  }

  /* ---------- helpers ---------- */
  function functionsIn(code, lang) {
    const names = [];
    const res = lang === "python" ? [/^\s*def\s+(\w+)\s*\(([^)]*)\)/gm] : lang === "kotlin" ? [/\bfun\s+(\w+)\s*\(([^)]*)\)/g]
      : [/\bfunction\s*\*?\s*(\w+)\s*\(([^)]*)\)/g, /\b(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s*)?\(([^)]*)\)\s*=>/g, /\b(?:public|private|protected|static|final)[\w\s<>\[\],.]*?\s(\w+)\s*\(([^)]*)\)\s*\{/g, /^\s*(?:[\w:<>*&]+\s+)+(\w+)\s*\(([^)]*)\)\s*\{/gm];
    res.forEach((re) => { let m; while ((m = re.exec(code))) if (!/^(if|for|while|switch|catch|return|else)$/.test(m[1]) && !names.some((n) => n.name === m[1])) names.push({ name: m[1], params: m[2].split(",").map((s) => s.trim()).filter(Boolean) }); });
    return names;
  }
  function describe(code, lang) {
    const an = root.CodeAnalyzer ? root.CodeAnalyzer.analyze(code, lang) : null;
    const fns = functionsIn(code, an ? an.language : lang);
    const facts = [];
    if (an && an.language !== "unknown") facts.push("Language looks like " + (NAMES[an.language] || an.language) + " (" + an.lines + " lines).");
    if (fns.length) facts.push("Defines: " + fns.slice(0, 8).map((f) => f.name + "(" + f.params.join(", ") + ")").join(", ") + (fns.length > 8 ? ", …" : "") + ".");
    const imp = (code.match(/^\s*(?:import|from|using|#include|require\()[^\n]*/gm) || []).slice(0, 5);
    if (imp.length) facts.push("Imports/dependencies: " + imp.map((s) => s.trim()).join(" | "));
    const loops = (code.match(/\b(for|while|foreach)\b/g) || []).length, conds = (code.match(/\b(if|switch|when|elif)\b/g) || []).length, tries = (code.match(/\b(try|catch|except)\b/g) || []).length;
    facts.push("Control flow: " + loops + " loop(s), " + conds + " conditional(s)" + (tries ? ", error handling present" : ", no error handling") + ".");
    if (/\b(fetch|XMLHttpRequest|requests\.|HttpClient|axios|socket)\b/.test(code)) facts.push("Performs network I/O.");
    if (/\b(fs\.|open\(|File\.|readFile|writeFile|Files\.)/.test(code)) facts.push("Touches files.");
    if (/\b(local|session)Storage\b|\bindexedDB\b/.test(code)) facts.push("Uses browser storage.");
    if (an && an.complexity) facts.push("Time complexity estimate (heuristic): " + an.complexity.estimate + (an.complexity.note ? ". " + an.complexity.note : ""));
    return { facts, an, fns };
  }

  /* ---------- actions ---------- */
  function explain(code, lang) {
    const d = describe(code, lang);
    if (d.an && (d.an.empty || d.an.oversized || d.an.binary)) return out(d.an.notes.join("\n"), "Nothing analysed.");
    const issues = d.an ? d.an.errors.concat(d.an.warnings) : [];
    return out("**What this code does (structural reading, not execution)**\n" + d.facts.map((f) => "- " + f).join("\n") +
      (issues.length ? "\n\n**Things to look at**\n" + issues.map((f) => "- " + f).join("\n") : "") +
      (d.an && d.an.notes.length ? "\n\n" + d.an.notes.join("\n") : "") +
      "\n\nI read the text; I cannot tell you its runtime behaviour without running it. Run your own tests to confirm.", "Static reading. EDO did not run this code.");
  }
  function analyze(code, name) {
    const report = root.CodeAnalyzer ? root.CodeAnalyzer.check(code, name || "snippet") : "Code analyzer not loaded.";
    return out("**Code analysis** (not executed)\n" + report, "Syntax and structure only. EDO did not run this code.");
  }
  function debug(code, lang, verbs) {
    const an = root.CodeAnalyzer ? root.CodeAnalyzer.analyze(code, lang) : null;
    if (!an || an.empty || an.oversized || an.binary) return out((an && an.notes.join("\n")) || "Nothing to analyse.", "Nothing analysed.");
    const fx = autoFix(code, an.language);
    const patch = fx.applied.length && root.Patch ? root.Patch.unified(code, fx.code, "snippet." + (an.language === "python" ? "py" : "txt")) : "";
    const found = an.errors.concat(an.warnings);
    let t = "**Bug review** (" + (NAMES[an.language] || an.language) + ", static, not executed)\n";
    t += found.length ? found.map((f) => "- " + f).join("\n") : "- No syntax problems or known risky patterns found by my checks. That does not prove the code is correct.";
    if (an.parse) t += "\n- " + an.parse;
    if (fx.applied.length) t += "\n\n**Mechanical fixes applied** (meaning-preserving; review before using)\n" + fx.applied.map((a) => "- " + a).join("\n") + (patch ? "\n\n" + block("diff", patch) : "") + "\n\n**Patched code**\n" + block(an.language, fx.code);
    else if (found.length) t += "\n\nThese need a judgement call from you, so I did not rewrite the code automatically.";
    if (an.notes.length) t += "\n\n" + an.notes.join("\n");
    return out(t, "Static analysis and rule-based fixes. The patched code was not run or compiled by EDO.", { patch: patch || null, fixed: fx.applied.length ? fx.code : null });
  }
  function refactor(code, lang, optimize) {
    const an = root.CodeAnalyzer ? root.CodeAnalyzer.analyze(code, lang) : null;
    if (!an || an.empty || an.oversized || an.binary) return out((an && an.notes.join("\n")) || "Nothing to analyse.", "Nothing analysed.");
    const tips = [];
    const L = code.split("\n");
    if (L.length > 60) tips.push("The snippet is " + L.length + " lines; split it into functions with one job each.");
    if (/\bfor\b[\s\S]{0,200}\bfor\b/.test(code) && an.complexity && an.complexity.loopDepth >= 2) tips.push("Nested loops (" + an.complexity.estimate + "). If the inner loop only looks values up, put them in a Set/Map/dict first to get about O(n).");
    if (an.complexity && an.complexity.recursiveCalls >= 2) tips.push("Several recursive calls per body: memoise (cache results by argument) or switch to a loop.");
    if (/(\w+)\s*\.\s*(?:indexOf|includes)\([^)]*\)[\s\S]{0,80}\bfor\b|\bfor\b[\s\S]{0,120}\.(?:indexOf|includes)\(/.test(code)) tips.push("Array search inside a loop is O(n) each time; use a Set for membership.");
    if (/\+=\s*["'`]/.test(code) && /\b(for|while)\b/.test(code)) tips.push("String concatenation in a loop: collect parts in an array/StringBuilder and join once.");
    if (/\b(\d{2,})\b/.test(code.replace(/\/\/.*|#.*/g, ""))) tips.push("Magic numbers: name them as constants.");
    if (!/\b(try|catch|except)\b/.test(code) && /\b(fetch|open\(|readFile|JSON\.parse|parseInt|int\()/.test(code)) tips.push("I/O or parsing without error handling: validate input and handle failure.");
    if (/\bfunction\b[^{]*\{[\s\S]{0,40}\bvar\b|\bvar\s/.test(code) && /javascript|typescript/.test(an.language)) tips.push("Replace var with const (or let if reassigned) after checking nothing relies on hoisting.");
    if (/(.{25,})\n[\s\S]*\1/.test(code.replace(/[ \t]+/g, " ")) && L.length > 12) tips.push("Repeated blocks detected; extract a shared helper.");
    const fx = autoFix(code, an.language), patch = fx.applied.length && root.Patch ? root.Patch.unified(code, fx.code, "snippet") : "";
    let t = "**" + (optimize ? "Optimisation" : "Refactoring") + " review** (" + (NAMES[an.language] || an.language) + ", static)\n";
    t += tips.length ? tips.map((x) => "- " + x).join("\n") : "- No structural problems stood out in my checks.";
    if (an.complexity) t += "\n\nTime complexity (heuristic): " + an.complexity.estimate;
    if (an.warnings.length || an.errors.length) t += "\n\n**Also flagged**\n" + an.errors.concat(an.warnings).map((x) => "- " + x).join("\n");
    if (fx.applied.length) t += "\n\n**Safe mechanical changes**\n" + fx.applied.map((a) => "- " + a).join("\n") + (patch ? "\n\n" + block("diff", patch) : "");
    t += "\n\nI did not rewrite your logic: behaviour-preserving refactors need your tests. Write tests first, then change the code.";
    return out(t, "Static review and rule-based patch. Nothing was run.", { patch: patch || null });
  }

  /* ---------- generation ---------- */
  function findTemplate(l) {
    const T = root.EDO_CODE || {};
    let best = null, bl = 0;
    Object.keys(T).forEach((k) => T[k].aliases.forEach((a) => { if (new RegExp("\\b" + a.replace(/[+*?.^$()|[\]\\]/g, "\\$&") + "\\b", "i").test(l) && a.length > bl) { best = k; bl = a.length; } }));
    return best;
  }
  function requirements(text) {
    const reqs = [];
    const re = /\b(without|using|must|should|no|avoid|only|don't use|do not use|in O\([^)]*\)|with)\s+([^.,;\n]{2,60})/gi;
    let m; while ((m = re.exec(text)) && reqs.length < 8) reqs.push(m[0].trim());
    return reqs;
  }
  function testSource(name, lang, fnName, cases) {
    const lit = (v) => JSON.stringify(v);
    if (lang === "javascript" || lang === "typescript") return "const assert = require('node:assert');\n" + cases.map(([a, e]) => "assert.deepStrictEqual(" + fnName + "(" + a.map(lit).join(", ") + "), " + lit(e) + ");").join("\n") + "\nconsole.log('all " + cases.length + " checks passed');\n";
    if (lang === "python") return cases.map(([a, e]) => "assert " + fnName + "(" + a.map((x) => lit(x).replace(/\btrue\b/g, "True").replace(/\bfalse\b/g, "False")).join(", ") + ") == " + lit(e).replace(/\btrue\b/g, "True").replace(/\bfalse\b/g, "False")).join("\n") + "\nprint('all " + cases.length + " checks passed')\n";
    return null;
  }
  const UNSUPPORTED = /\b(rust|golang|go lang|in go|php|ruby|swift|perl|scala|dart|lua|haskell|matlab|r language|objective-c|assembly|fortran|cobol|elixir|julia)\b/i;
  function generate(text) {
    const l = text.toLowerCase();
    const un = UNSUPPORTED.exec(text);
    if (un) return out("I don't have reviewed templates for " + un[1] + ", and I won't pass off a guess as checked code. I can write it in JavaScript, TypeScript, Python, C, C++, Java, Kotlin or C# (where a template exists), or review a " + un[1] + " version you paste (generic checks only).", "Unsupported language. Nothing generated.", { generated: false });
    const key = findTemplate(l);
    const lang = langFromText(text) || "javascript";
    const T = root.EDO_CODE || {};
    const wantTests = /\btests?\b|unit test|test cases?/.test(l);
    if (!key) return null;
    const tpl = T[key];
    if (!tpl.code[lang]) {
      const have = Object.keys(tpl.code).map((k) => NAMES[k]).join(", ");
      return out("I have a reviewed " + tpl.title + " template for " + have + ", but not for " + (NAMES[lang] || lang) + ". I will not improvise one and present it as checked. Ask for one of those languages, or paste your own version and I will review it.", "No template for that language. Nothing generated.", { generated: false });
    }
    const reqs = requirements(text), warn = [];
    if (/\brecurs/i.test(text) && !/without recurs|no recurs|avoid recurs|non-?recursive/i.test(text)) warn.push("You asked for recursion; my reviewed " + tpl.title + " template is iterative (" + tpl.complexity + "), which avoids stack-depth limits. Tell me if you specifically need the recursive form.");
    if (/without (a )?(loop|loops)|no loops?/i.test(text)) warn.push("You asked for no loops; this template uses a loop. I do not have a loop-free reviewed version.");
    let t = "**" + (NAMES[lang]) + " — " + tpl.title + "** (reviewed template, not executed)\n" + block(lang, tpl.code[lang]) + "\n" + tpl.complexity + ". " + tpl.notes;
    const sample = tpl.cases[Math.min(2, tpl.cases.length - 1)];
    t += "\nCheck: " + tpl.fn[lang] + "(" + sample[0].map((x) => JSON.stringify(x)).join(", ") + ") should give " + JSON.stringify(sample[1]) + ".";
    if (reqs.length) t += "\n\nRequirements I noted: " + reqs.join("; ") + ". I can only check them against what the template does (see notes below).";
    if (warn.length) t += "\n\n**Requirement mismatch**\n" + warn.map((w) => "- " + w).join("\n");
    if (wantTests) {
      const ts = testSource(key, lang, tpl.fn[lang], tpl.cases);
      t += "\n\n**Tests** (not run by EDO)\n" + (ts ? block(lang === "typescript" ? "javascript" : lang, ts) : "Expected values for the test table:\n" + tpl.cases.map(([a, e]) => "- " + tpl.fn[lang] + "(" + a.map((x) => JSON.stringify(x)).join(", ") + ") → " + JSON.stringify(e)).join("\n"));
    }
    return out(t, "Reviewed template. Not run by EDO. The project test suite runs the JavaScript and Python versions against these cases.", { generated: true, template: key, language: lang, code: tpl.code[lang] });
  }
  function genTests(code, lang) {
    const an = root.CodeAnalyzer ? root.CodeAnalyzer.analyze(code, lang) : null;
    if (!an || an.empty || an.oversized || an.binary) return out((an && an.notes.join("\n")) || "Nothing to test.", "Nothing analysed.");
    const fns = functionsIn(code, an.language);
    if (!fns.length) return out("I could not find a function to write tests for. Paste a function definition.", "No tests generated.");
    const f = fns[0], py = an.language === "python";
    const edge = f.params.map((p) => p.replace(/[:=].*$/, "").trim());
    const probes = ["0", "1", "-1", py ? "None" : "null", py ? "''" : "''", py ? "[]" : "[]"];
    let src;
    if (py) src = "import pytest\n\n# Skeleton: EDO cannot know the right answers. Replace <expected> with values you have worked out by hand.\n" +
      probes.slice(0, 5).map((p, i) => "def test_" + f.name + "_edge_" + (i + 1) + "():\n    # input: " + edge.map(() => p).join(", ") + "\n    result = " + f.name + "(" + edge.map(() => p).join(", ") + ")\n    assert result == <expected>").join("\n\n") + "\n";
    else src = "// Skeleton: EDO cannot know the right answers. Replace EXPECTED with values you have worked out by hand.\nconst assert = require('node:assert');\n" +
      probes.slice(0, 5).map((p, i) => "// edge case " + (i + 1) + ": every parameter = " + p + "\ntry { assert.deepStrictEqual(" + f.name + "(" + edge.map(() => p).join(", ") + "), EXPECTED); } catch (e) { console.error('edge " + (i + 1) + ':\', e.message); }').join("\n") + "\n";
    return out("**Test skeleton for `" + f.name + "`** (not run)\n" + block(py ? "python" : "javascript", src) +
      "\nThese cover empty/zero/negative/null inputs. The expected values are placeholders on purpose: I will not invent correct outputs for code I did not write. Add 2–3 normal cases and one large input.", "Skeleton only. Not run by EDO.", { skeleton: true });
  }
  function compare(text) {
    const A = root.EDO_ALGO || {};
    const names = Object.keys(A).filter((k) => new RegExp("\\b" + k.replace(/ /g, "[ -]?") + "s?\\b", "i").test(text));
    if (names.length < 2) {
      if (names.length === 1) { const a = A[names[0]]; return out("**" + names[0] + "**: best " + a.best + ", average " + a.avg + ", worst " + a.worst + ", space " + a.space + (a.stable != null ? ", " + (a.stable ? "stable" : "not stable") : "") + ". " + a.note, "Standard textbook complexities."); }
      return null;
    }
    const rows = names.map((n) => { const a = A[n]; return "| " + n + " | " + a.best + " | " + a.avg + " | " + a.worst + " | " + a.space + " | " + (a.stable == null ? "–" : a.stable ? "yes" : "no") + " |"; });
    return out("**Comparison** (standard textbook values)\n\n| algorithm | best | average | worst | space | stable |\n|---|---|---|---|---|---|\n" + rows.join("\n") + "\n\n" + names.map((n) => "- " + n + ": " + A[n].note).join("\n") + "\n\nReal speed also depends on input size, memory layout and the language runtime; measure with your own data.", "Standard algorithm facts, no benchmark run.");
  }

  /* ---------- router ---------- */
  function answer(text) {
    const raw = String(text || "");
    if (raw.length > 250000) return out("That input is " + raw.length + " characters. I handle up to about 200,000 at once; paste a smaller section.", "Oversized input rejected.");
    const fence = FENCE.exec(raw);
    const l = raw.toLowerCase();
    const prose = fence ? raw.replace(FENCE, " ") : raw;
    const pl = prose.toLowerCase();
    const lang = (fence && fence[1] && fence[1].toLowerCase()) || langFromText(prose);
    const verbs = {
      fix: /\b(debug|fix|bug|bugs|wrong|broken|not working|doesn'?t work|why does|why is|error)\b/.test(pl),
      refactor: /\b(refactor|clean ?up|improve|rewrite|simplify|restructure|readab)/.test(pl),
      optimize: /\b(optimi[sz]e|faster|speed up|performance|efficient|slow)\b/.test(pl),
      explain: /\b(explain|what does|walk me through|how does|understand|describe)\b/.test(pl),
      tests: /\b(test|tests|unit test|test cases?)\b/.test(pl),
      complexity: /\b(complexity|big[- ]?o|time complexity|space complexity)\b/.test(pl),
      review: /\b(analy[sz]e|review|check|lint|inspect)\b/.test(pl),
    };
    if (fence) {
      const code = fence[2], lg = lang && lang !== "text" ? lang : null;
      if (!code.trim()) return out("The code block is empty, so there is nothing to analyse.", "Nothing analysed.");
      if (verbs.tests) return genTests(code, lg);
      if (verbs.optimize) return refactor(code, lg, true);
      if (verbs.refactor) return refactor(code, lg, false);
      if (verbs.fix) { const e = explainError(prose); const d = debug(code, lg); return e ? out(e.text + "\n\n" + d.text, d.meta, { patch: d.patch }) : d; }
      if (verbs.complexity) { const a = root.CodeAnalyzer && root.CodeAnalyzer.analyze(code, lg); if (a && a.complexity) return out("**Complexity (heuristic estimate)**\nTime: " + a.complexity.estimate + " (loop nesting depth " + a.complexity.loopDepth + ", recursive calls " + a.complexity.recursiveCalls + ")" + (a.complexity.note ? "\n" + a.complexity.note : "") + "\n\nThis is read from loop structure and cannot see data-dependent behaviour. Confirm by reasoning about your input sizes.", "Heuristic estimate. Nothing was run."); }
      if (verbs.explain) return explain(code, lg);
      return analyze(code, lg || "pasted");
    }
    const errAns = explainError(raw);
    if (errAns && (/(error|exception|traceback|undefined|fault|failed|cannot|not defined|not found|denied|overflow|blocked|refused|policy|exceeded|unexpected)/i.test(raw))) return errAns;
    if (/\b(compare|vs\.?|versus|difference between|which is faster|better)\b/.test(l) || /\b(complexity|big[- ]?o)\b/.test(l)) { const c = compare(raw); if (c) return c; }
    if (/\b(analy[sz]e|review|check|debug|explain)\b/i.test(raw) && /[{};]|\bdef |\bfunction\b|\bclass\b|=>|\bSELECT\b|#include/.test(raw) && raw.split("\n").length > 1) {
      const code = raw.replace(/^[^\n]*\b(analy[sz]e|review|check|debug|explain)\b[^\n]*\n/i, "");
      return verbs.fix ? debug(code, lang) : verbs.explain ? explain(code, lang) : analyze(code, "pasted");
    }
    const gen = /\b(write|generate|code|implement|function|create|make|give me|show me|program)\b/.test(l) ? generate(raw) : null;
    if (gen) return gen;
    const hits = root.EDOKnowledge ? root.EDOKnowledge.search(raw, "programming").slice(0, 3) : [];
    if (!hits.length) {
      const T = Object.keys(root.EDO_CODE || {}).map((k) => root.EDO_CODE[k].title).join(", ");
      return out("I can analyse, explain, debug, refactor and write tests for pasted code (put it in a ``` block), explain compiler/runtime errors, compare algorithms, and write reviewed templates for: " + T + ". Languages: JavaScript, TypeScript, Python, C, C++, Java, Kotlin, C#, HTML/CSS, SQL, Bash. For anything outside that I will say so instead of guessing.", "Local programming module. No code was executed.");
    }
    const body = hits.map((h) => { const d = h.doc; const pits = (d.pitfalls || []).map((p) => "- " + p).join("\n"); return "**" + d.title + "** (" + d.chapter + ")\n" + d.content + (pits ? "\nPitfalls:\n" + pits : ""); }).join("\n\n");
    return out(body + "\n\nI did not run any code for this answer.", "Local programming notes. Not a substitute for tests.");
  }
  root.Programming = { answer, analyze, generate, explain, debug, refactor, genTests, explainError, compare, autoFix, functionsIn, langFromText };
})();
