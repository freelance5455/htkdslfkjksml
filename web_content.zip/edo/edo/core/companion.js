/* EDO companion. Warm, plain-spoken conversation and a step-by-step decision helper.
   It is rule-based and runs on the device. It is not a language model and says so when asked.
   Anything it does not understand returns null (or an honest "tell me more"), never an invented answer.
   Globals: window.Companion */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;

  let flow = null; // active decision flow, or null
  let turn = 0; // rotates between phrasings so replies do not repeat word for word
  const pick = (arr) => arr[turn++ % arr.length];

  function nameOf() {
    try {
      const notes = root.Memory ? root.Memory.list().map((i) => i.content) : [];
      for (let i = notes.length - 1; i >= 0; i--) {
        const m = /\bmy name is\s+([A-Za-z][\w'-]{0,20})/i.exec(notes[i]);
        if (m) return m[1];
      }
    } catch (e) {}
    return "";
  }
  const hey = () => { const n = nameOf(); return n ? ", " + n : ""; };

  /* ---------- detection ---------- */
  const CRISIS = /\b(kill myself|killing myself|suicid\w*|end my life|want to die|wanna die|self[- ]?harm|hurt myself|cut myself|no reason to live|better off dead)\b/i;
  const DECIDE = /\b(help me (?:to )?(?:decide|choose|pick)|can'?t decide|cannot decide|torn between|confused between|decide between|choose between|pros and cons|what should i do|which (?:one )?should i|help me make a decision|i need to decide|make a decision)\b/i;
  const SHOULD = /^\s*(?:should i|do you think i should|is it (?:better|worth it) (?:to|if i)|would it be (?:better|good) (?:to|if i))\b/i;
  const OR_Q = /^\s*(?:which is better|which one is better|what is better|what's better)\b/i;
  const CANCEL = /^\s*(?:cancel|stop|never ?mind|forget it|skip it|quit|exit|leave it|reset)\s*[.!]*\s*$/i;

  const GREET = /^\s*(?:hi+|hello+|hey+|heya|hii+|yo|sup|namaste|hola|good (?:morning|afternoon|evening|night))(?:\s+(?:there|edo|buddy|friend|bro|man))?\s*[.!?]*\s*$/i;
  const HOWRU = /\b(how are you|how r u|how('?s| is) it going|how have you been|what'?s up|wassup|how do you do)\b/i;
const short = (t, n) => t.trim().split(/\s+/).length <= n;
  const THANKS = /^\s*(?:thanks?|thank you|thx|ty|thanks a lot|thank you so much|appreciate it)\b/i;
  const BYE = /^\s*(?:bye+|goodbye|good night|see you|see ya|cya|talk later|ttyl|gn)\b/i;
  const WHO = /\b(who are you|what are you|are you (?:a )?(?:real|human|ai|bot|robot|chatgpt|alive)|your name|about yourself|what can you do)\b/i;
  const JOKE = /\b(tell me a joke|make me laugh|say something funny|crack a joke)\b/i;
  const MOTIVATE = /\b(motivate me|need (?:some )?motivation|give me (?:some )?motivation|inspire me|pump me up|cheer me up|encourage me)\b/i;
  const NAME = /^\s*(?:my name is|i am called|i'?m called|call me)\s+([A-Za-z][\w'-]{1,20})\b/i;
  const MOODS = [
    ["failed", /\b(failed|flunked|bad (?:marks|score|result|rank)|low (?:marks|score|rank)|didn'?t (?:pass|clear|qualify)|rejected|messed up)\b/i],
    ["stressed", /\b(stress(?:ed|ful)?|overwhelm(?:ed|ing)?|too much|burn(?:ed|t)? ?out|pressure|tension|can'?t cope)\b/i],
    ["anxious", /\b(anxious|anxiety|nervous|worried|worry|scared|afraid|panic(?:king)?|fear|dread)\b/i],
    ["sad", /\b(sad|depress(?:ed|ing)|cry(?:ing)?|heartbroken|upset|miserable|feel(?:ing)? (?:low|down))\b/i],
    ["lonely", /\b(lonely|alone|no friends|nobody (?:cares|talks)|isolated|left out)\b/i],
    ["tired", /\b(tired|exhausted|sleepy|drained|no energy|fatigued|can'?t sleep|sleepless)\b/i],
    ["angry", /\b(angry|furious|mad at|pissed|annoyed|irritated|frustrated|fed up)\b/i],
    ["unmotivated", /\b(unmotivated|demotivated|no motivation|lazy|procrastinat\w*|can'?t focus|can'?t study|don'?t feel like|not in the mood|giving up|want to give up)\b/i],
    ["bored", /\b(bored|boring|nothing to do)\b/i],
    ["happy", /\b(happy|excited|great news|good news|celebrat\w*|proud of (?:myself|me)|so glad|feeling (?:good|great|amazing)|got selected)\b/i],
  ];
  const FEELING_CTX = /\b(i(?:'m| am| feel|'ve been| have been| was)|im|feeling|feel|my (?:day|week|life|exam|mind)|so |really |very |today|lately|these days|nothing|everything)\b/i;

  function mood(text) {
    for (const [name, re] of MOODS) if (re.test(text) && (FEELING_CTX.test(text) || text.split(/\s+/).length <= 4)) return name;
    return null;
  }

  /* what kind of conversation is this? null means "not for me" */
  function detect(text) {
    const t = String(text || "").trim();
    if (!t) return null;
    if (CRISIS.test(t)) return "crisis";
    if (flow) return "decision";
    if (DECIDE.test(t) || SHOULD.test(t) || OR_Q.test(t)) return "decision";
    if (NAME.test(t) || GREET.test(t) || (HOWRU.test(t) && short(t, 7)) || THANKS.test(t) || BYE.test(t) || WHO.test(t) || JOKE.test(t) || MOTIVATE.test(t)) return "chat";
    if (mood(t)) return "chat";
    return null;
  }

  /* ---------- plain conversation ---------- */
  const R = {
    greet: [
      (n) => "Hey" + n + "! Good to see you. What's going on today?",
      (n) => "Hi" + n + "! How's your day treating you?",
      (n) => "Hello" + n + "! I'm here. Want to chat, work something out, or decide something?",
    ],
    howru: [
      (n) => "I'm doing well, thanks for asking" + n + ". Ready when you are. How are *you* actually doing?",
      (n) => "All good on my side. Honestly I'm more curious about you. How's it going?",
    ],
    thanks: [() => "Anytime. That's what I'm here for.", () => "You're welcome! Shout if anything else comes up.", () => "Happy to help. You did the hard part."],
    bye: [(n) => "Take care" + n + "! I'll be here whenever you want to talk.", (n) => "Bye for now" + n + ". Go easy on yourself today."],
    who: [() => "I'm EDO, a small assistant that lives on your device. I can do maths and JEE-style problems, explain and write code, remember notes, open apps and help you think through decisions. I'm not a human, and I'm a simple on-device program rather than a big language model, so I'll tell you when I'm out of my depth instead of faking it."],
    joke: [
      () => "Why do programmers prefer dark mode? Because light attracts bugs.",
      () => "I told my calculator a joke. It didn't see the point, so I added one.",
      () => "Physics student's favourite party trick: it's all relative.",
    ],
    motivate: [
      () => "Small steps still move you forward. Pick the tiniest next thing, like one problem or one page, and do just that. Momentum does the rest. What's the first small thing?",
      () => "You don't need to feel ready, you just need to start for ten minutes. Most of the time the hard part is the first minute. Want to pick a ten-minute task together?",
      () => "Consistency beats intensity. A decent day repeated 100 times beats one heroic day. What would a decent day look like for you today?",
    ],
  };

  const MOOD_REPLY = {
    stressed: [
      "That sounds like a lot to carry. Let's make it smaller: what's the one thing that's weighing on you the most right now? We can just deal with that first.",
      "I'm sorry it's piling up. When everything feels urgent, writing down the 3 things that actually have to happen this week usually helps. Want to list them with me?",
    ],
    anxious: [
      "That knot-in-the-stomach feeling is rough. One thing that often helps: breathe in for 4, hold for 4, out for 6, a few times. Then tell me what's worrying you the most, and let's look at it properly.",
      "Worrying is your mind trying to protect you, but it can run wild. What's the specific thing you're afraid might happen? Sometimes saying it out loud shrinks it.",
    ],
    sad: [
      "I'm sorry you're feeling low. You don't have to dress it up for me. Do you want to talk about what happened, or would a distraction be better right now?",
      "That sounds heavy. I'm here, and I'm listening. What's been on your mind?",
    ],
    lonely: [
      "That feeling is real and it hurts, but it doesn't mean something's wrong with you. I'm happy to talk, though I'm just an app on your phone, so is there one person you could message today, even just a 'hey, how are you?'",
    ],
    tired: [
      "Sounds like your body is asking for a break. If you can, step away for 15 minutes: water, a stretch, no screens. If it's been going on for days, sleep is the first thing to fix. What's been keeping you up?",
    ],
    angry: [
      "That sounds really frustrating. Let it out if you want. What happened? Sometimes it helps to vent first and think after.",
    ],
    unmotivated: [
      "That happens to everyone, even people who look super disciplined. Let's cut the task down to something almost silly, like opening the book and doing 5 minutes. Which task is it?",
      "Low motivation usually means the task feels too big, or you're running on empty. Which is it for you right now?",
    ],
    bored: [
      "Let's fix that. I can quiz you on a JEE topic, throw a logic puzzle your way, tell a joke, or help you decide something you've been putting off. What sounds fun?",
    ],
    happy: [
      "That's great to hear! Tell me everything. What happened?",
      "Love that for you! You've earned it. What's the story?",
    ],
    failed: [
      "I'm sorry, that stings. One result doesn't define you or your ability. Give yourself today to be annoyed about it. When you're ready, we can look at what went wrong and what to change, step by step. What happened?",
    ],
  };

  const CRISIS_REPLY =
    "I'm really glad you told me, and I'm taking it seriously. I'm only an app, so I can't be there with you the way a person can, and you deserve a real person right now.\n\n" +
    "Please reach out to someone today: a family member, a close friend, a teacher, or a doctor. If you might act on these thoughts or you're in danger, call your local emergency number right now. " +
    "If you're in India, Tele-MANAS (14416 or 1-800-891-4416) is free and open 24/7. If you're elsewhere, findahelpline.com lists lines by country.\n\n" +
    "Please don't stay alone with this tonight. Is there someone near you that you can go to or call?";

  function chat(text) {
    const t = text.trim();
    const n = hey();
    const nm = NAME.exec(t);
    if (nm) {
      const name = nm[1].charAt(0).toUpperCase() + nm[1].slice(1);
      let saved = null;
      try { if (root.Memory) saved = root.Memory.remember("My name is " + name, "profile"); } catch (e) {}
      return saved
        ? { kind: "chat", text: "Nice to meet you, " + name + "! I'll remember that on this device. What's on your mind?", meta: "Saved your name locally. Say \"forget my name\" to remove it." }
        : { kind: "chat", text: "Nice to meet you, " + name + "! Memory is off, so I won't keep your name after this chat. What's on your mind?", meta: "Nothing was stored (memory off)." };
    }
    if (GREET.test(t)) return { kind: "chat", text: pick(R.greet)(n), meta: "Friend chat · on-device" };
    if (HOWRU.test(t) && short(t, 7)) return { kind: "chat", text: pick(R.howru)(n), meta: "Friend chat · on-device" };
    if (THANKS.test(t)) return { kind: "chat", text: pick(R.thanks)(n), meta: "Friend chat · on-device" };
    if (BYE.test(t)) return { kind: "chat", text: pick(R.bye)(n), meta: "Friend chat · on-device" };
    if (WHO.test(t)) return { kind: "chat", text: pick(R.who)(n), meta: "Friend chat · on-device" };
    if (JOKE.test(t)) return { kind: "chat", text: pick(R.joke)(n), meta: "Friend chat · on-device" };
    if (MOTIVATE.test(t)) return { kind: "chat", text: pick(R.motivate)(n), meta: "Friend chat · on-device" };
    const m = mood(t);
    if (m) {
      const pool = MOOD_REPLY[m];
      const prefix = n && m !== "happy" ? n.slice(2) + ", " : "";
      return { kind: "chat", text: prefix + pool[turn++ % pool.length].replace(/^./, (c) => (prefix ? c.toLowerCase() : c)), meta: "Friend chat · on-device. Not a substitute for professional help." };
    }
    return null;
  }

  /* shown in Friend mode when nothing else matched and no AI proxy is set */
  function fallback(text) {
    const words = String(text).trim().split(/\s+/).length;
    if (words <= 3) return { kind: "chat", text: pick([
      "I'm listening. Tell me a bit more?",
      "Go on, I'm with you. What do you mean?",
    ]), meta: "Friend chat · on-device" };
    return { kind: "chat", text: pick([
      "I want to be honest: I'm a simple on-device helper, so I can't follow every kind of conversation. I can calculate, solve JEE-style problems, write and explain code, open your apps, and help you decide between options. Which of those is closest to what you need, or do you just want to vent? I'm good at listening.",
      "I didn't fully catch that, and I'd rather ask than guess. Is this something you want to talk through, or a decision you're stuck on? If it's a choice, just say 'help me decide'.",
    ]), meta: "Friend chat · on-device. For open-ended conversation, add an AI proxy in the panel." };
  }

  /* ---------- decision helper ---------- */
  function clean(s) {
    return String(s).replace(/^[\s,.:;'"-]+|[\s,.:;'"?!-]+$/g, "").replace(/\s+/g, " ");
  }
  function parseOptions(text) {
    let t = String(text)
      .replace(/^\s*(?:hey\s+edo[,]?\s*)?(?:help me (?:to )?(?:decide|choose|pick)|i (?:need|want) to (?:decide|choose)|can'?t decide|torn between|confused between|decide between|choose between|which (?:one )?(?:is better|should i (?:pick|choose|take|go for|buy))|should i|do you think i should|what is better|what'?s better)\s*:?\s*(?:between\s+)?/i, "")
      ;
    t = clean(t);
    if (!t) return [];
    const parts = t.split(/\s+(?:or|vs\.?|versus)\s+|\s*\/\s*|\s*\|\s*/i).map(clean).filter(Boolean);
    if (parts.length === 2 && /^not$/i.test(parts[1])) return [];
    if (parts.length >= 2) return parts.slice(0, 5);
    const between = /\bbetween\s+(.+?)\s+and\s+(.+)$/i.exec(t);
    if (between) return [clean(between[1]), clean(between[2])];
    const and2 = /^(.+?)\s+and\s+(.+)$/i.exec(t);
    if (and2 && /\b(?:choose|pick|between|which)\b/i.test(text)) return [clean(and2[1]), clean(and2[2])];
    return [];
  }
  function yesNo(text) {
    const m = /^\s*(?:should i|do you think i should|is it (?:better|worth it) (?:to|if i)|would it be (?:better|good) (?:to|if i))\s+(.+)$/i.exec(text);
    if (!m) return null;
    const thing = clean(m[1].replace(/\s+or\s+not\s*\??$/i, ""));
    if (!thing || thing.split(/\s+/).length > 14) return null;
    return ["Yes: " + thing, "No / not now"];
  }
  function parseCriteria(text) {
    const items = String(text)
      .split(/[,\n;]+|\s+and\s+/i)
      .map(clean)
      .filter(Boolean)
      .slice(0, 6);
    const out = [];
    for (const it of items) {
      const m = /^(.*?)[\s:=-]*(\d{1,2})$/.exec(it);
      const name = clean(m ? m[1] : it);
      let w = m ? parseInt(m[2], 10) : 3;
      if (!name) continue;
      if (w < 1) w = 1;
      if (w > 10) w = 10;
      out.push({ name, w });
    }
    return out;
  }
  function parseScores(text, n) {
    const nums = (String(text).match(/-?\d+(?:\.\d+)?/g) || []).map(Number);
    if (nums.length !== n) return null;
    if (nums.some((x) => x < 0 || x > 10)) return null;
    return nums;
  }

  const ask = {
    options: "Sure, let's work it out together. What are the options you're choosing between? Put them in one line separated by 'or', like: *MacBook or ThinkPad*.",
    criteria(opts) {
      return "Okay, **" + opts.join("** vs **") + "**.\n\nWhat matters to you in this choice? List 2 to 5 things and rate how much each matters from 1 (a little) to 10 (a lot), for example:\n`cost 8, time 5, stress 7`\n(If you skip the numbers I'll treat them all as equally important.)";
    },
    scores(f) {
      const names = f.criteria.map((c) => c.name).join(", ");
      const opt = f.options[f.scoreIdx];
      return "Now score **" + opt + "** from 0 (terrible) to 10 (great) on each, in this order:\n" + names + "\nExample: `" + f.criteria.map((_, i) => 4 + ((i * 3) % 6)).join(" ") + "`";
    },
  };

  function result(f) {
    const totalW = f.criteria.reduce((a, c) => a + c.w, 0);
    const rows = f.options.map((o, i) => {
      const sc = f.scores[i];
      const total = f.criteria.reduce((a, c, k) => a + sc[k] * c.w, 0) / totalW;
      return { o, total, sc };
    }).sort((a, b) => b.total - a.total);
    const best = rows[0];
    const second = rows[1];
    const gap = best.total - second.total;
    // which criterion pushed the winner ahead of the runner-up the most
    let driver = "";
    let top = -Infinity;
    f.criteria.forEach((c, k) => {
      const d = (best.sc[k] - second.sc[k]) * c.w;
      if (d > top) { top = d; driver = c.name; }
    });
    const board = rows.map((r) => "- **" + r.o + "**: " + r.total.toFixed(1) + " / 10").join("\n");
    let verdict;
    if (gap < 0.5) {
      verdict = "That's practically a tie. When the numbers are this close, either choice is probably fine, so the tiebreaker should be your gut. Try this: imagine the coin lands on **" + best.o + "**. Do you feel relief or disappointment? That reaction is information.";
    } else if (gap < 1.5) {
      verdict = "**" + best.o + "** is ahead, mostly because of **" + driver + "**. It's a modest lead, so if something important is missing from your list, add it and rerun.";
    } else {
      verdict = "**" + best.o + "** comes out clearly ahead, mostly because of **" + driver + "**. If that still feels wrong to you, it usually means a criterion is missing from the list. What is it?";
    }
    return "Here's how it came out, weighted by what you said matters:\n" + board + "\n\n" + verdict + "\n\nThis only reflects the numbers you gave me, so treat it as a thinking aid. The decision is yours. Want to rerun with a different weight or add another factor? Just say *help me decide* again.";
  }

  function decision(text) {
    const t = String(text).trim();
    if (CANCEL.test(t)) {
      flow = null;
      return { kind: "decision", text: "No problem, dropped it. We can pick it up whenever you want.", meta: "Decision helper · cancelled" };
    }
    if (!flow) {
      flow = { step: "options", options: [], criteria: [], scores: [], scoreIdx: 0 };
      let opts = parseOptions(t);
      if (opts.length < 2) opts = yesNo(t) || [];
      if (opts.length >= 2) {
        flow.options = opts;
        flow.step = "criteria";
        return { kind: "decision", text: ask.criteria(opts), meta: "Decision helper · step 2 of 3 · say 'cancel' to stop" };
      }
      return { kind: "decision", text: ask.options, meta: "Decision helper · step 1 of 3 · say 'cancel' to stop" };
    }
    if (flow.step === "options") {
      let opts = parseOptions(t);
      if (opts.length < 2) opts = yesNo(t) || [];
      if (opts.length < 2) {
        return { kind: "decision", text: "I need at least two options. Separate them with 'or', for example: *stay in my city or move*. Or say 'cancel'.", meta: "Decision helper · step 1 of 3" };
      }
      flow.options = opts;
      flow.step = "criteria";
      return { kind: "decision", text: ask.criteria(opts), meta: "Decision helper · step 2 of 3 · say 'cancel' to stop" };
    }
    if (flow.step === "criteria") {
      const crit = parseCriteria(t);
      if (crit.length < 2) {
        return { kind: "decision", text: "Give me at least two things that matter, separated by commas. For example: `cost 8, time 5`.", meta: "Decision helper · step 2 of 3" };
      }
      flow.criteria = crit;
      flow.step = "scores";
      flow.scoreIdx = 0;
      return { kind: "decision", text: ask.scores(flow), meta: "Decision helper · step 3 of 3 · option 1 of " + flow.options.length };
    }
    if (flow.step === "scores") {
      const sc = parseScores(t, flow.criteria.length);
      if (!sc) {
        return { kind: "decision", text: "I need exactly " + flow.criteria.length + " numbers between 0 and 10, one for each of: " + flow.criteria.map((c) => c.name).join(", ") + ".", meta: "Decision helper · step 3 of 3" };
      }
      flow.scores[flow.scoreIdx] = sc;
      flow.scoreIdx += 1;
      if (flow.scoreIdx < flow.options.length) {
        return { kind: "decision", text: ask.scores(flow), meta: "Decision helper · step 3 of 3 · option " + (flow.scoreIdx + 1) + " of " + flow.options.length };
      }
      const out = result(flow);
      flow = null;
      return { kind: "decision", text: out, meta: "Decision helper · weighted from your own numbers" };
    }
    flow = null;
    return null;
  }

  /* ---------- public ---------- */
  function handle(text, ctx) {
    ctx = ctx || {};
    const what = detect(text);
    if (what === "crisis") return { kind: "chat", text: CRISIS_REPLY, meta: "Friend chat · on-device. Please reach a real person." , crisis: true };
    if (what === "decision") return decision(text);
    if (what === "chat") return chat(text);
    if (ctx.mode && /^friend$/i.test(ctx.mode) && !ctx.hasProxy) return fallback(text);
    return null;
  }
  function reset() { flow = null; }
  function active() { return !!flow; }

  root.Companion = { detect, handle, reset, active };
})();
