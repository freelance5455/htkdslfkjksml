/* EDO proactive suggestions. EDO can start a useful sentence instead of waiting, but only when the user allows it, only about
   things the user told it (an exam date, an unfinished plan, a question left open, something they asked to remember), and never
   twice in a short time. It runs when the app opens or a new chat starts; it does not poll in the background.
   Native Android notifications are off by default, need the user's switch and notification permission, and use the
   scheduleReminder bridge method (inexact alarm, lost on reboot). Nothing here can act on the device by itself.
   Globals: window.Proactive */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  const KEY = "edo_proactive";
  const DEFAULTS = { enabled: true, plan: true, event: true, pending: true, remembered: true, nativeNotify: false, cooldownHours: 12, eventWithinDays: 3 };
  let cfg = Object.assign({}, DEFAULTS), adapter = null, clock = () => Date.now();

  const store = () => { if (adapter) return adapter; try { return typeof localStorage !== "undefined" ? localStorage : null; } catch (e) { return null; } };
  function load() { try { const s = store(); const j = s && JSON.parse(s.getItem(KEY) || "null"); if (j && typeof j === "object") cfg = Object.assign({}, DEFAULTS, pick(j)); } catch (e) {} return cfg; }
  function pick(j) { const o = {}; Object.keys(DEFAULTS).forEach((k) => { if (typeof j[k] === typeof DEFAULTS[k]) o[k] = j[k]; }); if (o.cooldownHours != null) o.cooldownHours = Math.min(168, Math.max(1, o.cooldownHours)); if (o.eventWithinDays != null) o.eventWithinDays = Math.min(30, Math.max(1, o.eventWithinDays)); return o; }
  function setConfig(c) { cfg = Object.assign({}, cfg, pick(c || {})); try { const s = store(); if (s) s.setItem(KEY, JSON.stringify(cfg)); } catch (e) {} return Object.assign({}, cfg); }

  const dayDiff = (iso) => { const a = new Date(clock()); a.setHours(0, 0, 0, 0); return Math.round((new Date(iso + "T00:00:00").getTime() - a.getTime()) / 86400000); };
  function recently(L, key) { const n = (L.getState().nudged || {})[key]; return n && clock() - n < cfg.cooldownHours * 3600000; }
  function mark(L, key) { const st = L.getState(), nudged = Object.assign({}, st.nudged || {}); nudged[key] = clock(); const keys = Object.keys(nudged); if (keys.length > 40) keys.sort((a, b) => nudged[a] - nudged[b]).slice(0, keys.length - 40).forEach((k) => delete nudged[k]); L.setState({ nudged }); }

  /* suggest() → {kind, text, suggestions} | null. Marks the nudge as shown. */
  function suggest() {
    const L = root.MemoryLayers;
    if (!cfg.enabled || !L || !L.isEnabled()) return null;
    const now = clock();
    if (cfg.event) {
      const ev = L.upcomingEvents(cfg.eventWithinDays).find((e) => !recently(L, "event:" + e.id));
      if (ev) { const d = dayDiff(ev.date); mark(L, "event:" + ev.id); return { kind: "event", text: "Heads-up: your " + ev.title.toLowerCase() + " is " + (d === 0 ? "today" : d === 1 ? "tomorrow" : "in " + d + " days") + ". Want to use some of today for a focused session?", suggestions: ["Plan a study session", "Not now"] }; }
    }
    if (cfg.plan) {
      const p = L.latestUnfinishedPlan();
      if (p && now - p.updatedAt > 30 * 60000 && !recently(L, "plan:" + p.id)) { const i = p.steps.findIndex((s) => !s.done); if (i >= 0) { mark(L, "plan:" + p.id); return { kind: "plan", text: "You have an unfinished plan: \"" + p.title + "\", at step " + (i + 1) + " of " + p.steps.length + ". Want to continue?", suggestions: ["Continue the plan", "Do this later"] }; } }
    }
    if (cfg.pending) {
      const st = L.getState(), pq = st.pending;
      if (pq && pq.text && now - pq.askedAt > 3600000 && now - pq.askedAt < 24 * 3600000 && !recently(L, "pending:" + pq.kind)) { mark(L, "pending:" + pq.kind); return { kind: "pending", text: "Earlier I asked you something and we never got back to it: " + pq.text + ". Want to pick it up?", suggestions: ["Yes", "Not now"] }; }
    }
    if (cfg.remembered && root.Memory) {
      const today = new Date(now); today.setHours(0, 0, 0, 0);
      const note = root.Memory.list().find((m) => m.updatedAt >= today.getTime() - 86400000 && m.updatedAt < today.getTime() && !recently(L, "note:" + m.id));
      if (note) { mark(L, "note:" + note.id); return { kind: "remembered", text: "You asked me to remember this yesterday: \"" + note.content.slice(0, 120) + "\".", suggestions: [] }; }
    }
    return null;
  }

  /* Ask the phone to show a reminder for an event (needs the Android build, the user's switch, and notification permission). */
  async function scheduleNative(ev, hour) {
    if (!cfg.nativeNotify) return { ok: false, reason: "Native reminders are switched off in your settings." };
    const B = root.Bridge;
    if (!B || !B.available() || !B.supportsSync("scheduleReminder")) return { ok: false, reason: "Reminders need the Android app." };
    const d = new Date(ev.date + "T00:00:00"); d.setDate(d.getDate() - 1); d.setHours(hour == null ? 18 : hour, 0, 0, 0);
    if (d.getTime() < clock() + 60000) return { ok: false, reason: "That reminder time has already passed." };
    try { const r = JSON.parse(await B.call("scheduleReminder", { id: Math.abs(hash(ev.id)) % 100000, title: "EDO: " + ev.title, text: "Coming up " + (ev.whenText || ev.date), at: d.getTime() })); return { ok: true, at: r.scheduledFor, exact: r.exact === true, note: "Inexact alarm; may be a few minutes late and is lost if the phone restarts." }; }
    catch (e) { return { ok: false, reason: e.code ? e.code + ": " + e.message : e.message }; }
  }
  function hash(s) { let h = 0; for (let i = 0; i < s.length; i++) h = (Math.imul(31, h) + s.charCodeAt(i)) | 0; return h; }

  load();
  root.Proactive = { suggest, setConfig, config: () => Object.assign({}, cfg), scheduleNative, load, DEFAULTS, useStorage: (a) => { adapter = a; cfg = Object.assign({}, DEFAULTS); load(); }, setClock: (f) => { clock = f || (() => Date.now()); } };
})();
