/* EDO Brain. A staged pipeline that sits above the existing engines (calculator, solver, programming, knowledge,
   device, memory, search) and decides what a message is before any of them runs:

     normalize → classify → entities → retrieve memory → choose engine → reason → verify → follow-up → respond → update memory/state

   It handles the conversational acts itself (personal updates, recall, continue, later, change of mind, planning, "make it better")
   and delegates everything else to the existing router passed in as `legacy`, so no working behaviour is replaced.
   Context across turns lives in MemoryLayers (working memory in RAM, the rest only when Memory is ON). With Memory OFF the
   Brain keeps nothing between turns and says so when a message depends on an earlier one.
   Heuristic and rule-based; it is not a language model. Globals: window.Brain */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  const ML = () => root.MemoryLayers;

  /* ---------- 1. normalize ---------- */
  function normalize(text) {
    const raw = String(text == null ? "" : text).replace(/\s+/g, " ").trim();
    return { raw, lower: raw.toLowerCase().replace(/[’‘]/g, "'"), words: raw ? raw.split(/\s+/).length : 0 };
  }

  /* ---------- patterns ---------- */
  const P = {
    recall: [
      /\bwhat (?:did|have|do) (?:we|i) (?:talk|talked|discuss|discussed|say|said|chat|chatted|do|done|work|worked|plan|planned)\b/,
      /\bwhat were we (?:doing|working on|talking about|discussing|up to)\b/,
      /\bremind me (?:what|about what) (?:i|we) (?:planned|said|decided|wanted|discussed)\b/,
      /\b(?:do you )?remember (?:when|what) (?:we|i) (?:discussed|talked|spoke|said|did)\b/,
      /\byou remember (?:when|what|that)\b/,
      /\bwhat (?:do i have|is) (?:coming up|planned|on my (?:list|plate))\b/,
      /\bwhat did i (?:tell|ask) you\b/,
    ],
    cont: [/^(?:ok(?:ay)?,? )?(?:please )?(?:continue|resume|carry on|keep going|go on|proceed|next(?: step)?|go ahead)\b/, /\bwhere (?:were|did) we (?:stop|stopped|leave|left)\b/, /\bcontinue where we left off\b/, /^(?:next|and then|what next|what now)\??$/],
    later: [/\b(?:let'?s|can we|i'?ll|i will|we can) (?:do|continue|finish|talk about|look at|pick)(?: that| this| it)?(?: up)? (?:later|tomorrow|tonight|another time)\b/, /^(?:later|not now|maybe later|some other time|remind me later)\b/],
    change: [/\bi (?:have )?changed my mind\b/, /\bon second thought\b/, /^actually,? (?:let'?s|i want|i'?d rather|make it|can we)\b/, /\bnever ?mind (?:that|this)\b/],
    plan: [/\b(?:plan|schedule|organi[sz]e|map out|set up)\b.{0,30}\b(?:study|revision|session|practice|prep|preparation|day|week|exam)\b/, /\bhelp me (?:plan|prepare|revise)\b/, /\bmake (?:me )?a (?:study |revision |recovery )?(?:plan|timetable|routine|schedule)\b/, /\bplan a (?:study |revision )?session\b/],
    refine: [/^(?:make|do|turn) (?:it|that|this|them) (?:a bit |much |way )?(?:better|shorter|longer|simpler|clearer|faster|cleaner|easier|harder|more detailed)\b/, /^(?:improve|fix|shorten|simplify|expand|rewrite|redo|optimi[sz]e|polish|clean up) (?:it|that|this|them)\b/, /^(?:try again|one more(?: time)?|another(?: one)?|again)\b/, /^(?:explain|say|show) (?:it|that|this) (?:again|simpler|differently|slower|more)\b/, /^(?:why|how) (?:is|does|did) (?:it|that|this)\b/],
    done: /\b(?:i )?(?:just )?(?:finished|completed|done with|wrapped up|am done with|i'?m done with)\b/,
    exam: /\b(exam|test|quiz|interview|deadline|submission|presentation|viva|practical|assignment|mock)s?\b/,
    firstPerson: /^(?:i|i'?m|im|i am|i'?ve|i have|i just|my|we|so i|well,? i|today i|yesterday i|guess what)\b/,
    request: /\b(?:can you|could you|please|how (?:do|can|to)|find|calculate|compute|solve|explain|search|google|look up|what is|what'?s|who is|show me|tell me|write|generate|open|call)\b/,
    searchVerb: /\b(?:search|google|look up|latest news|news about|find (?:me )?(?:info|information|articles?))\b/,
    help: /\b(?:help|fix|improve|recover|sort (?:it|this) out|what (?:should|can) i do|any advice)\b/,
    yesNo: /^(?:yes|yeah|yep|yup|sure|ok(?:ay)?|please|do it|go ahead|no|nope|nah|not now|later|maybe)\b/,
  };
  const MOODS = [
    ["failed", /\b(failed|flunked|bad (?:marks|score|result|rank)|low (?:marks|score|rank)|didn'?t (?:pass|clear|qualify)|messed up|bombed)\b/],
    ["stressed", /\b(stress(?:ed|ful)?|overwhelm(?:ed|ing)?|too much|burn(?:ed|t)? ?out|pressure|can'?t cope|panick?(?:ing)?)\b/],
    ["frustrated", /\b(frustrat\w*|annoyed|irritated|fed up|angry|furious|sick of)\b/],
    ["anxious", /\b(anxious|nervous|worried|scared|afraid)\b/],
    ["sad", /\b(sad|depress(?:ed|ing)|upset|miserable|feel(?:ing)? (?:low|down))\b/],
    ["tired", /\b(tired|exhausted|drained|sleepy)\b/],
    ["happy", /\b(happy|excited|proud|thrilled|great news|good news)\b/],
  ];
  const moodOf = (t) => { for (const [n, re] of MOODS) if (re.test(t)) return n; return null; };
  const CODEWORDS = /\b(code|bug|crash(?:es|ing)?|error|compile|compiler|build|project|repo|function|class|unity|script|app|game|exception|null|undefined|stack ?trace|debug|refactor)\b/;

  /* ---------- 2/3. classify + entities ---------- */
  function entities(n, now) {
    const t = n.lower, e = { subject: null, score: null, event: null, when: null, mood: moodOf(t), minutes: null, doneWhat: null, files: [], symbols: [] };
    let m;
    if ((m = t.match(/(\d{1,3}(?:\.\d+)?)\s*(?:\/|out of)\s*(\d{1,3})\b/))) e.score = { value: +m[1], outOf: +m[2] };
    else if ((m = t.match(/\b(?:got|scored|secured|score of|received|earned|made)\s+(?:a\s+)?(\d{1,3}(?:\.\d+)?)\s*(?:%|percent|marks?|points?)?(?!\s*(?:minutes?|hours?|days?))/))) e.score = { value: +m[1], outOf: null };
    else if ((m = t.match(/\b(\d{1,3}(?:\.\d+)?)\s*(?:%|percent|marks?)\b/))) e.score = { value: +m[1], outOf: /%|percent/.test(m[0]) ? 100 : null };
    if (e.score && e.score.outOf && (e.score.value > e.score.outOf || e.score.outOf === 0)) e.score = null; // impossible score: do not guess
    e.subject = root.Planner ? root.Planner.subjectOf(t) : null;
    if (!e.subject && /\b(java|python|javascript|c#|unity|code|coding|programming)\b/.test(t)) e.subject = "programming";
    const ev = t.match(P.exam);
    // "I got 90 today and my exam is next Friday": the date belongs to the event, not to the marks, so read the words after the event noun first
    const evAt = ev ? t.indexOf(ev[0]) : -1;
    const w = root.MemoryLayers ? ((evAt >= 0 && root.MemoryLayers.parseWhen(t.slice(evAt), now)) || root.MemoryLayers.parseWhen(t, now)) : null;
    if (w) e.when = w;
    if (ev) {
      const title = (e.subject && e.subject !== "programming" ? cap(e.subject) + " " : "") + ev[1];
      e.event = { title, date: w ? w.date : null, whenText: w ? w.label : "", days: w ? daysBetween(now, w.date) : null };
    }
    if ((m = t.match(/\b(\d+(?:\.\d+)?)\s*(hours?|hrs?|hr|h)\b/))) e.minutes = Math.round(+m[1] * 60);
    else if ((m = t.match(/\b(\d{2,3})\s*(minutes?|mins?|min)\b/))) e.minutes = +m[1];
    if ((m = t.match(P.done)) ) { const rest = t.slice(t.search(P.done)).replace(P.done, "").replace(/^\s*(?:with|my|the)?\s*/, "").replace(/[.!]+$/, "").trim(); if (rest) e.doneWhat = rest.split(/\s+(?:and|but|so|now)\s+/)[0].slice(0, 60); }
    (n.raw.match(/[\w./-]+\.(?:js|ts|tsx|jsx|py|cs|java|kt|cpp|c|h|go|rs|json|gradle|kts|html|css)\b/g) || []).forEach((f) => e.files.push(f));
    (n.raw.match(/\b[A-Za-z_]\w*(?=\(\))/g) || []).forEach((s) => e.symbols.push(s));
    (n.raw.match(/\b[A-Z][a-z]+[A-Z]\w*\b/g) || []).forEach((s) => { if (!e.symbols.includes(s)) e.symbols.push(s); });
    return e;
  }
  const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);
  function daysBetween(now, iso) {
    if (!iso) return null;
    const a = new Date(now == null ? Date.now() : now); a.setHours(0, 0, 0, 0);
    const b = new Date(iso + "T00:00:00");
    return Math.round((b.getTime() - a.getTime()) / 86400000);
  }

  function classify(n, ent, ctx, st) {
    const t = n.lower, why = [];
    const any = (arr) => arr.some((re) => re.test(t));
    if (!n.raw) return { act: "empty", why: ["empty"] };
    const legacy = root.Intent ? root.Intent.detect(n.raw, ctx.mode || "Assistant") : { kind: "conversation" };
    if (/```/.test(n.orig || n.raw) || n.raw.length > 600) return { act: "delegate", why: ["code or long pasted text goes to the existing engines"], legacy };
    if (legacy.kind === "crisis" || (root.Companion && root.Companion.detect(n.raw) === "crisis")) return { act: "delegate", why: ["safety first: handled by the companion"], legacy };
    if (root.Companion && root.Companion.active && root.Companion.active()) return { act: "delegate", why: ["decision flow active"], legacy };
    if (legacy.kind === "memory" && any(P.recall)) return { act: "recall", why: ["asks about earlier conversation (not a request to store a note)"], legacy };
    if (["device", "calculation", "memory", "file", "location", "weather"].includes(legacy.kind) && !(legacy.kind === "calculation" && ent.score)) return { act: "delegate", why: ["explicit command: " + legacy.kind], legacy };
    const pending = st && st.pending;
    if (any(P.recall)) return { act: "recall", why: ["asks about earlier conversation"], legacy };
    if (any(P.later)) return { act: "later", why: ["defers a topic"], legacy };
    if (any(P.change)) return { act: "change_mind", why: ["changes direction"], legacy };
    if (any(P.cont) && n.words <= 8) return { act: "continue", why: ["asks to resume"], legacy };
    if (any(P.plan) && !P.searchVerb.test(t)) return { act: "plan", why: ["asks for a plan"], legacy };
    if (ent.mood === "failed" && ent.subject && P.help.test(t)) return { act: "setback_help", why: ["setback plus request for help"], legacy };
    if (ent.mood && ent.mood !== "happy" && CODEWORDS.test(t) && (ctx.mode === "Programming" || /\b(code|bug|crash|project|build|unity|compile)\b/.test(t))) return { act: "frustrated_code", why: ["emotion plus coding task"], legacy };
    if (any(P.refine) && n.words <= 8) return { act: "refine", why: ["refers to the previous output"], legacy };
    if (pending && (P.yesNo.test(t) || n.words <= 4) && !P.request.test(t)) return { act: "answer_pending", why: ["answers EDO's open question: " + pending.kind], legacy };
    const personal = (P.firstPerson.test(t) || (ent.event && /\bmy\b/.test(t))) && !P.request.test(t) && !/\?\s*$/.test(n.raw);
    if (personal && ent.score) return { act: "score_update", why: ["personal result"], legacy };
    if (personal && ent.done_ !== true && ent.doneWhat) return { act: "progress_done", why: ["progress report"], legacy };
    if (personal && ent.event && ent.when) return { act: "event_update", why: ["dated event"], legacy };
    if (ent.mood && ent.mood !== "happy" && ent.mood !== "failed" && personal && st && (ML() && ML().upcomingEvents(14).length)) return { act: "mood_context", why: ["mood with something relevant in memory"], legacy };
    return { act: "delegate", why: ["no conversational act matched; existing router decides"], legacy };
  }

  /* ---------- 4. retrieve ---------- */
  function retrieve(n, ctx) {
    const L = ML();
    if (!L || !L.isEnabled()) return { memoryOn: false, events: [], plan: null, recent: [], related: [] };
    const recent = L.recentTurns(8);
    const related = n.words >= 3 ? L.recall(n.raw, { limit: 3 }).hits : [];
    return { memoryOn: true, events: L.upcomingEvents(21), plan: L.activePlan(), later: L.latestUnfinishedPlan(), recent, related, state: L.getState() };
  }

  /* ---------- helpers for replies ---------- */
  function ago(ms, now) { const d = Math.round((now - ms) / 86400000); return d <= 0 ? "earlier today" : d === 1 ? "yesterday" : d + " days ago"; }
  function fmtDay(ms) { try { return new Date(ms).toLocaleDateString([], { weekday: "long", day: "numeric", month: "short" }); } catch (e) { return new Date(ms).toDateString(); } }
  function recentTopic(mem) {
    const subs = (mem.recent || []).filter((x) => x.role === "user").map((x) => root.Planner && root.Planner.subjectOf(x.text)).filter(Boolean);
    return subs.length ? subs[subs.length - 1] : (mem.state && mem.state.subject) || null;
  }
  function allowedNumbers(parts) { const s = new Set(); parts.forEach((p) => (String(p).match(/\d+(?:\.\d+)?/g) || []).forEach((x) => s.add(String(+x)))); return s; }
  function verifyReply(text, sources) {
    const ok = allowedNumbers(sources), extra = [];
    // list ordinals, "step N of M" and "(N min)" are plan structure, not claims about the user
    text = String(text).replace(/^\s*\d+\.\s/gm, "").replace(/\bsteps? \d+(?: of \d+)?/gi, "").replace(/\(\d+ min\)/g, "").replace(/\b\d+-minute\b/g, "");
    (String(text).match(/\d+(?:\.\d+)?/g) || []).forEach((x) => { const v = String(+x); if (!ok.has(v) && !extra.includes(v)) extra.push(v); });
    return { ok: extra.length === 0, extra };
  }

  /* ---------- 5/6. engines for conversational acts ---------- */
  function actReply(act, n, ent, mem, ctx, now) {
    const L = ML(), on = mem.memoryOn;
    const base = { name: nameOf(), subject: ent.subject, score: ent.score, event: ent.event, doneWhat: ent.doneWhat, recentTopic: recentTopic(mem) };
    const env = { seed: n.lower, askedLast: !!(on && mem.state && mem.state.pending), memoryOn: on };
    let r;
    if (act === "score_update") { r = root.Friend.respond("score_update", Object.assign(base, { event: ent.event || upcomingFirst(mem) }), env); if (ent.event && on) saveEvent(ent, n); return r; }
    if (act === "event_update") { if (on) { const ev = saveEvent(ent, n); if (ev) env.saved = true; } return root.Friend.respond("event_update", base, env); }
    if (act === "progress_done") { if (on && L) L.setState({ goal: null }); return root.Friend.respond("progress_done", base, env); }
    if (act === "setback_help") { if (on && L) L.setState({ subject: ent.subject, goal: "recover " + ent.subject + " result" }); working().task = { kind: "recovery", subject: ent.subject }; return root.Friend.respond("setback_help", base, env); }
    if (act === "mood_context") return root.Friend.respond("mood_context", Object.assign(base, { event: upcomingFirst(mem) }), env);
    if (act === "later") { const plan = mem.plan; if (on && plan) L.updatePlan(plan.id, { status: "later" }); return root.Friend.respond("later", { thing: plan ? plan.title : (working().refs.lastOutput ? "the last thing we were on" : "") }, env); }
    if (act === "change_mind") { if (on) L.setState({ pending: null }); working().pendingQuestion = null; return root.Friend.respond("change_mind", {}, env); }
    return null;
  }
  const working = () => ML().working;
  function nameOf() {
    try { const m = root.Memory ? root.Memory.list().map((i) => i.content) : []; for (let i = m.length - 1; i >= 0; i--) { const x = /\bmy name is\s+([A-Za-z][\w'-]{0,20})/i.exec(m[i]); if (x) return x[1]; } } catch (e) {}
    return "";
  }
  function upcomingFirst(mem) { const e = (mem.events || [])[0]; if (!e) return null; return { title: e.title, date: e.date, whenText: e.whenText, days: daysBetween(null, e.date) }; }
  function saveEvent(ent, n) {
    if (!ent.event || !ML()) return null;
    return ML().addEvent(ent.event.title, ent.when ? ent.when.label + " " + n.lower : n.lower);
  }

  function recallReply(n, mem, now) {
    const L = ML();
    if (!L.isEnabled()) return { text: "Memory is switched off, so I haven't kept our earlier conversations and can't look anything up. Turn memory on in the panel and I'll remember from then on.", engine: "memory-recall", suggestions: [] };
    if (/\bcoming up|what do i have|planned\b/.test(n.lower) && !/\b(yesterday|last week|earlier)\b/.test(n.lower) && /\b(coming up|what do i have|on my)\b/.test(n.lower)) {
      const ev = L.upcomingEvents(30), plan = L.latestUnfinishedPlan();
      const lines = ev.map((e) => "• " + e.title + (e.whenText ? " — " + e.whenText : "")).concat(plan ? ["• Plan: " + plan.title + " (" + plan.status + ")"] : []);
      return { text: lines.length ? "Here's what I have for you:\n" + lines.join("\n") : "I don't have anything coming up saved for you yet. Tell me about an exam or deadline and I'll keep track.", engine: "memory-recall", suggestions: lines.length ? [] : ["Plan a study session"] };
    }
    if (/\bwhat (?:were we|are we)\b|\bwhere (?:were|did) we\b/.test(n.lower)) {
      const plan = L.latestUnfinishedPlan(), st = L.getState(), turns = L.recentTurns(6).filter((x) => x.role === "user");
      const bits = [];
      if (plan) { const next = plan.steps.findIndex((s) => !s.done); bits.push("we were on the plan \"" + plan.title + "\"" + (next >= 0 ? ", at step " + (next + 1) + " of " + plan.steps.length : ", all steps done")); }
      if (st.goal) bits.push("your goal was: " + st.goal);
      if (!bits.length && turns.length) bits.push("the last thing you told me was: \"" + turns[turns.length - 1].text.slice(0, 100) + "\"");
      if (!bits.length) return { text: "I don't have anything saved from before, so I can't say where we were. What would you like to do?", engine: "memory-recall", suggestions: [] };
      return { text: cap(bits.join(". Also, ")) + ".", engine: "memory-recall", suggestions: plan ? ["Continue the plan"] : [] };
    }
    const res = L.recall(n.raw, { limit: 5 });
    if (!res.hits.length) {
      const where = res.window ? res.window.label : "before";
      return { text: "I don't have anything saved from " + where + ". Either we didn't talk about it, or memory was off at the time" + (res.window && res.window.label === "yesterday" ? "." : ", or it has expired."), engine: "memory-recall", suggestions: [] };
    }
    const lead = res.window ? cap(res.window.label) + " we covered:" : "This is what I have:";
    const lines = res.hits.map((h) => {
      const when = ago(h.when, now);
      if (h.kind === "summary") { const s = h.src; return "• " + (res.window ? "" : when + " — ") + s.topic + (s.points.length ? ": " + s.points.slice(0, 2).join(" / ") : "") + (s.unresolved.length ? " (unresolved: " + s.unresolved[0] + ")" : ""); }
      if (h.kind === "event") return "• " + (res.window ? "" : when + " — ") + "you mentioned: " + h.text;
      return "• " + (res.window ? "" : when + " — ") + "you said: \"" + h.text.slice(0, 110) + "\"";
    });
    return { text: lead + "\n" + lines.join("\n") + "\n\n(From saved summaries and recent turns on this device; summaries are extractive, not a transcript.)", engine: "memory-recall", suggestions: [] };
  }

  function planReply(n, ent, mem, ctx) {
    const L = ML(), st = mem.state || {};
    let subject = ent.subject || (working().task && working().task.subject) || st.subject || (mem.events[0] && root.Planner.subjectOf(mem.events[0].title)) || null;
    if (subject === "programming") subject = null;
    const flavor = (working().task && working().task.kind === "recovery") || /\brecover|fix my|after (?:the )?(?:fail|bad)/.test(n.lower) ? "recovery" : "new";
    const minutes = ent.minutes || (working().task && working().task.minutes) || null;
    if (!subject || !minutes) {
      const ask = !subject ? "Happy to. Which subject, and how long do you have?" : "Happy to. How long do you have for " + subject + " today?";
      working().task = { kind: flavor === "recovery" ? "recovery" : "plan", subject, minutes, awaiting: !subject ? "subject_minutes" : "minutes" };
      if (mem.memoryOn) L.setState({ pending: { kind: "plan_details", askedAt: Date.now(), text: ask }, subject: subject || st.subject });
      working().pendingQuestion = { kind: "plan_details", text: ask };
      return { text: ask, engine: "planner", suggestions: subject ? ["30 minutes", "1 hour", "2 hours"] : ["Physics, 1 hour", "Chemistry, 1 hour", "Maths, 1 hour"], ask: { kind: "plan_details" } };
    }
    return buildPlan(subject, minutes, flavor, ent, mem, n);
  }
  function buildPlan(subject, minutes, flavor, ent, mem, n) {
    const L = ML();
    const ev = (mem.events || []).find((e) => root.Planner.subjectOf(e.title) === subject) || (mem.events || [])[0];
    const studied = (mem.state && mem.state.studied) || [];
    // only search for a chapter if the user named one beyond the bare subject, time and "plan" words; otherwise let the planner rotate through unstudied chapters
    const hint = n.lower.replace(/\b(physics|chemistry|maths?|mathematics|phy|chem|\d+|minutes?|mins?|hours?|hrs?|half|an|plan|study|session|revision|recovery|make|me|a|with|for|i|have|do|want|to|and|please|today|now|of|the|my)\b/g, " ").replace(/[^a-z ]/g, " ").trim();
    const plan = root.Planner.studyPlan({ subject, minutes, topic: ent.chapterHint || (hint.length > 3 ? hint : null), flavor, studied });
    let stored = null;
    if (mem.memoryOn) { stored = L.addPlan(plan.title, plan.steps.map((s) => s.text + " (" + s.minutes + " min)"), { subject }); L.setState({ subject, pending: { kind: "start_plan", askedAt: Date.now(), text: "Start step 1?" }, goal: plan.title }); }
    working().task = { kind: "plan", subject, minutes, planId: stored && stored.id, plan };
    working().pendingQuestion = { kind: "start_plan", text: "Start step 1?" };
    const evLine = ev && ev.date ? "\nYour " + ev.title.toLowerCase() + " is " + (ev.whenText || ev.date) + ", so I've kept this focused." : "";
    return { text: "Here's a " + minutes + "-minute " + (flavor === "recovery" ? "recovery plan" : "plan") + ":\n\n" + root.Planner.render(plan) + "\n\n" + plan.note + evLine + "\n\nShall we start with step 1?", engine: "planner", suggestions: ["Start step 1", "Make it shorter", "Do this later"], ask: { kind: "start_plan" } };
  }

  function continueReply(n, mem) {
    const L = ML();
    if (!mem.memoryOn) return { text: "Memory is off, so I don't keep track of what we were doing. Tell me what to continue with, or turn memory on in the panel.", engine: "memory-recall", suggestions: [] };
    const t = working().task, plan = (t && t.plan && mem.plan) ? mem.plan : (mem.plan || mem.later);
    if (!plan) {
      const lastUser = [...(mem.recent || [])].reverse().find((x) => x.role === "user");
      return { text: lastUser ? "I don't have an open plan. The last thing you told me was: \"" + lastUser.text.slice(0, 100) + "\". Want to continue with that, or start a plan?" : "There's nothing open to continue. Want to start a study plan?", engine: "memory-recall", suggestions: ["Plan a study session"] };
    }
    if (plan.status !== "active") L.updatePlan(plan.id, { status: "active" });
    const i = plan.steps.findIndex((s) => !s.done);
    if (i < 0) { L.updatePlan(plan.id, { status: "done" }); return { text: "That plan is already finished: \"" + plan.title + "\". Nice work. Want to start another?", engine: "planner", suggestions: ["Plan a study session"] }; }
    L.setState({ pending: { kind: "step_done", askedAt: Date.now(), text: "Done with this step?" } });
    working().pendingQuestion = { kind: "step_done", text: "Done with this step?" };
    return { text: "Picking up \"" + plan.title + "\" at step " + (i + 1) + " of " + plan.steps.length + ":\n\n" + plan.steps[i].text + "\n\nTell me when you're done with it and I'll move us on.", engine: "planner", suggestions: ["Done", "Skip this step", "Do this later"], ask: { kind: "step_done" } };
  }

  function answerPending(n, ent, mem, ctx) {
    const L = ML(), st = mem.state, p = st && st.pending, t = n.lower;
    const yes = /^(?:yes|yeah|yep|yup|sure|ok(?:ay)?|please|do it|go ahead|start|start step 1|done|harder questions)\b/.test(t), no = /^(?:no|nope|nah|not now|i'?m done for today|skip)\b/.test(t);
    const clear = () => { if (mem.memoryOn) L.setState({ pending: null }); working().pendingQuestion = null; };
    if (!p) return null;
    if (p.kind === "plan_details") {
      const tk = working().task || {};
      const subject = ent.subject || (root.Planner && root.Planner.subjectOf(t)) || tk.subject;
      let minutes = ent.minutes; const m = t.match(/\b(\d{2,3})\b/); if (!minutes && m) minutes = +m[1];
      if (!minutes && /\bhalf an hour\b/.test(t)) minutes = 30;
      minutes = minutes || tk.minutes;
      if (!subject || !minutes) return { text: !subject ? "Which subject: physics, chemistry or maths?" : "And how long do you have, in minutes or hours?", engine: "planner", suggestions: [], ask: { kind: "plan_details" } };
      working().task = Object.assign(tk, { subject, minutes });
      clear();
      return buildPlan(subject, minutes, tk.kind === "recovery" ? "recovery" : "new", ent, mem, n);
    }
    if (p.kind === "start_plan" || p.kind === "step_done") {
      const plan = mem.plan || mem.later;
      if (yes && plan) {
        const idx = p.kind === "step_done" ? plan.steps.findIndex((s) => !s.done) : -1;
        if (p.kind === "step_done" && idx >= 0) L.updatePlan(plan.id, { completeStep: idx });
        const fresh = L.activePlan() || plan, i = fresh.steps.findIndex((s) => !s.done);
        if (p.kind === "start_plan") { L.setState({ pending: { kind: "step_done", askedAt: Date.now(), text: "Done?" } }); return { text: "Step 1: " + fresh.steps[0].text + "\n\nTell me when you're done.", engine: "planner", suggestions: ["Done", "Do this later"] }; }
        if (i < 0) { L.updatePlan(fresh.id, { status: "done" }); clear(); return { text: "That was the last step. Plan finished: \"" + fresh.title + "\". Nice work.", engine: "planner", suggestions: [] }; }
        L.setState({ pending: { kind: "step_done", askedAt: Date.now(), text: "Done?" } });
        return { text: "Good. Step " + (i + 1) + " of " + fresh.steps.length + ": " + fresh.steps[i].text + "\n\nSay \"done\" when you're through.", engine: "planner", suggestions: ["Done", "Do this later"] };
      }
      if (no || /^skip/.test(t)) { clear(); if (plan && /^skip/.test(t)) { const idx = plan.steps.findIndex((s) => !s.done); if (idx >= 0) L.updatePlan(plan.id, { completeStep: idx }); } return { text: no ? "Okay. The plan is saved; say \"continue\" whenever you want it." : "Skipped it. Say \"continue\" for the next step.", engine: "planner", suggestions: ["Continue the plan"] }; }
    }
    if (p.kind === "offer_plan" && yes) { clear(); return planReply({ lower: "plan a study session " + t, raw: n.raw, words: n.words }, ent, mem, ctx); }
    if (p.kind === "offer_plan" && no) { clear(); return { text: "No problem. I'm here if you want one later.", engine: "friend", suggestions: [] }; }
    if (p.kind === "recovery_choice") {
      clear();
      if (/plan|recover|fix/.test(t)) { working().task = Object.assign(working().task || {}, { kind: "recovery" }); return planReply({ lower: "recovery plan", raw: n.raw, words: n.words }, ent, mem, ctx); }
      if (yes) { return planReply({ lower: "recovery plan", raw: n.raw, words: n.words }, ent, mem, ctx); }
    }
    if (p.kind === "next_round") {
      clear();
      if (yes || /harder/.test(t)) return { text: "Okay. Give me a topic and I'll point you to the relevant notes, or send a numeric problem like `u=0 a=2 t=5 find v` and I'll solve it step by step. EDO Pro is the mode for solving.", engine: "friend", suggestions: ["Show physics chapters"] };
      return { text: "Good call. Rest up, and say hi when you're back.", engine: "friend", suggestions: [] };
    }
    if (p.kind === "low_score") { clear(); if (yes || /plan|recover|fix/.test(t)) return planReply({ lower: "recovery plan", raw: n.raw, words: n.words }, ent, mem, ctx); return { text: "Okay. Whenever you want to look at it, I'm here.", engine: "friend", suggestions: ["Make a recovery plan"] }; }
    clear();
    return null;
  }

  function refineReply(n, ent, mem, ctx) {
    const L = ML();
    if (!L.isEnabled()) return { text: "Memory is off, so I don't keep track of what \"it\" was. Paste or tell me what to improve and I'll work on it.", engine: "friend", suggestions: [] };
    const last = working().refs.lastOutput;
    const t = n.lower;
    if (!last) return { text: "I'm not sure what \"it\" refers to yet; we haven't made anything this session. What should I work on?", engine: "friend", suggestions: [] };
    if (last.kind === "plan" || /plan/.test(last.engine || "")) {
      const plan = working().task && working().task.plan;
      if (/shorter|less|quick/.test(t) && plan) { const min = Math.max(20, Math.round((plan.minutes * 0.6) / 5) * 5); return buildPlan(plan.subject, min, working().task.kind === "recovery" ? "recovery" : "new", ent, retrieve(n, ctx), n); }
      if (/longer|more|detail/.test(t) && plan) return buildPlan(plan.subject, Math.min(240, plan.minutes + 30), working().task.kind === "recovery" ? "recovery" : "new", ent, retrieve(n, ctx), n);
      return { text: "I can make the plan shorter, longer, or switch the chapter. Which would you like?", engine: "planner", suggestions: ["Make it shorter", "Make it longer"] };
    }
    if (last.code && root.Programming) {
      const fn = /faster|optimi[sz]e|perform/.test(t) ? "refactor" : "refactor";
      try { const r = root.Programming[fn](last.code); r.engine = "programming"; r.kind = r.kind || "programming"; r.referenced = "your last code"; return r; } catch (e) {}
    }
    return { text: "I can rework my last answer if you tell me how: shorter, simpler, or with more detail. A bare \"make it better\" isn't specific enough for me to improve it honestly.", engine: "friend", suggestions: ["Shorter", "Simpler", "More detail"] };
  }

  /* ---------- run ---------- */
  function run(text, ctx, legacy) {
    ctx = ctx || {};
    const trace = [];
    const T = (stage, info) => { if (trace.length < 14) trace.push({ stage, info: String(info).slice(0, 160) }); };
    const now = ctx.now != null ? ctx.now : Date.now();
    const n = normalize(text); n.orig = String(text == null ? "" : text); T("normalize", n.words + " words");
    if (!n.raw || !ML() || !root.Friend) return legacy(text, ctx);
    if (ctx.memoryOn === false || (typeof ctx.memoryOn === "boolean")) ML().setEnabled(ctx.memoryOn !== false);
    const on = ML().isEnabled();
    const w = working(); w.mode = ctx.mode || w.mode; w.turn++;
    const st = on ? ML().getState() : {};
    const pendingExpired = st.pending && now - st.pending.askedAt > 24 * 3600000;
    if (pendingExpired) { ML().setState({ pending: null }); st.pending = null; }
    const ent = entities(n, now); T("entities", JSON.stringify({ s: ent.subject, sc: ent.score && ent.score.value, ev: ent.event && ent.event.title, m: ent.mood }));
    const cls = classify(n, ent, ctx, st); T("classify", cls.act + " — " + cls.why.join("; "));
    const mem = retrieve(n, ctx); T("retrieve", mem.memoryOn ? mem.events.length + " events, plan " + (mem.plan ? "yes" : "no") + ", " + mem.recent.length + " recent turns" : "memory off");
    let r = null, engine = "legacy";

    if (cls.act === "recall") r = recallReply(n, mem, now);
    else if (cls.act === "plan") r = planReply(n, ent, mem, ctx);
    else if (cls.act === "continue") r = continueReply(n, mem);
    else if (cls.act === "answer_pending") r = answerPending(n, ent, mem, ctx);
    else if (cls.act === "refine") r = refineReply(n, ent, mem, ctx);
    else if (cls.act === "frustrated_code") r = root.CodeBrain ? root.CodeBrain.frustrated(n.raw, ctx, ent) : null;
    else if (["score_update", "event_update", "progress_done", "setback_help", "mood_context", "later", "change_mind"].includes(cls.act)) { r = actReply(cls.act, n, ent, mem, ctx, now); if (r) r.engine = "friend"; }

    if (r) {
      engine = r.engine || "friend";
      T("choose engine", engine);
      r.kind = r.kind || (engine === "memory-recall" ? "memory" : engine === "planner" ? "plan" : "conversation");
      r.meta = r.meta || engineMeta(engine, on);
      r.intent = cls.legacy || { kind: "conversation" };
      const v = verifyReply(r.text, [n.raw, JSON.stringify(mem.events), JSON.stringify(mem.plan || ""), JSON.stringify(mem.recent), JSON.stringify(mem.related), JSON.stringify(mem.state || {}), (working().task && working().task.plan) ? JSON.stringify(working().task.plan) : "", String(ent.event && ent.event.days)]);
      T("verify", v.ok ? "every number in the reply comes from your message, memory, or the plan" : "numbers not traceable: " + v.extra.join(","));
      r.verification = v;
    } else {
      // programming brain first when a project is loaded or the question is Unity/coding specific
      const wantsCode = (ctx.mode === "Programming" || (cls.legacy && cls.legacy.kind === "programming")) && root.CodeBrain && root.CodeBrain.canAnswer && root.CodeBrain.canAnswer(n.raw, ctx);
      if (wantsCode) { r = root.CodeBrain.answer(n.raw, ctx); engine = "code-brain"; T("choose engine", "code-brain (project-aware)"); }
      if (!r) {
        T("choose engine", "existing router");
        r = legacy(text, ctx); // original text: code blocks keep their newlines
        engine = engineFromKind(r && r.kind);
      }
      // mood in a conversational chat that Companion handled: add memory-backed context only when it changes the reply
      if (r && r.kind === "chat" && cls.legacy && cls.legacy.kind !== "crisis" && on) r.text = enrichCompanion(r.text, n, ent, mem);
      r = r || { kind: "conversation", text: "I'm not sure what to do with that.", meta: "No engine matched." };
      T("verify", r.kind === "calculation" || r.kind === "reason" ? "verified by the engine's own double-check" : "n/a");
    }
    // follow-up
    if (!r.suggestions || !r.suggestions.length) r.suggestions = followups(r, ent, cls, engine);
    if (r.suggestions.length) T("follow-up", r.suggestions.join(" | "));
    r.engine = engine; r.act = cls.act; r.trace = trace;
    update(n, r, ent, cls, mem, ctx, now);
    return r;
  }
  function engineMeta(engine, on) {
    return engine === "memory-recall" ? "Recalled from saved summaries and recent turns on this device." : engine === "planner" ? "Template planner using the local chapter notes; not a model." : "Rule-based companion; not a language model." + (on ? "" : " Memory is off.");
  }
  function engineFromKind(k) {
    return { calculation: "calculator", reason: "solver", jee: "knowledge", programming: "programming", search: "search", device: "device", memory: "memory", clock: "calculator", chat: "friend", crisis: "friend", decision: "friend", upgrade: "mode-gate" }[k] || "legacy";
  }
  function enrichCompanion(text, n, ent, mem) {
    const ev = upcomingFirst(mem);
    if (ent.mood && ent.mood !== "happy" && ev && ev.days != null && ev.days <= 7 && ev.days >= 0 && !/exam|test/.test(text.toLowerCase())) return text + "\n\nI also have your " + ev.title.toLowerCase() + " " + root.Friend.daysPhrase(ev.days) + ". If it helps, we can plan around that.";
    return text;
  }
  function followups(r, ent, cls, engine) {
    if (r.upgradeTo || r.actions || r.kind === "device" || r.kind === "system" || r.kind === "crisis") return [];
    if (engine === "solver" && r.kind === "reason") return ["Explain step by step", "Common mistakes"];
    if (engine === "programming" && /```/.test(r.text || "")) return ["Write tests", "Explain this code"];
    return [];
  }
  /* ---------- 10. update ---------- */
  function update(n, r, ent, cls, mem, ctx, now) {
    const L = ML(), w = working();
    w.lastUser = n.raw.slice(0, 300);
    if (!L.isEnabled()) return;
    const topic = ent.subject || (mem.state && mem.state.subject) || null;
    L.addTurn("user", n.raw, { topic });
    if (r.text) L.addTurn("edo", String(r.text).replace(/\*\*/g, "").slice(0, 300));
    const code = (String(r.text || "").match(/```[\w]*\n([\s\S]*?)```/) || [])[1];
    w.refs.lastOutput = { kind: r.engine === "planner" ? "plan" : r.kind, engine: r.engine, text: String(r.text || "").slice(0, 600), code: code || null, t: now };
    const patch = {};
    if (ent.subject) patch.subject = ent.subject;
    if (ent.mood) patch.mood = ent.mood;
    patch.wants = /explain|why|how/.test(n.lower) ? "explanation" : /plan|do|make|write|open|call|solve/.test(n.lower) ? "action" : /idea|brainstorm|options|maybe/.test(n.lower) ? "brainstorm" : (n.words <= 6 ? "casual" : (mem.state && mem.state.wants) || "casual");
    const asked = r.ask && r.ask.kind;
    if (asked && !(mem.state && mem.state.pending && mem.state.pending.kind === asked && r.engine === "planner")) {
      if (!["plan_details", "start_plan", "step_done"].includes(asked)) patch.pending = { kind: asked, askedAt: now, text: r.ask.text || "" };
    }
    if (cls.act === "answer_pending" && !r.ask && !(L.getState().pending)) patch.pending = null;
    L.setState(patch);
    if (ctx.project) w.project = ctx.project;
  }
  function reset() { if (root.MemoryLayers) root.MemoryLayers.resetWorking(); if (root.Friend) root.Friend.reset(); }
  root.Brain = { run, normalize, entities, classify, retrieve, verifyReply, reset, STAGES: ["normalize", "classify", "entities", "retrieve", "choose engine", "reason", "verify", "follow-up", "respond", "update"] };
})();
