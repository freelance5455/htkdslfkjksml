/* EDO Friend response engine. Writes the conversational side of EDO from structured facts (what the user said, what
   memory holds, what is pending). It is a template system with slots and a variety controller, not a language model:
   each reply is assembled from small phrase sets, and a phrase used recently for the same slot is skipped, so
   consecutive replies do not repeat word for word. It never states a fact that is not in `f` (the facts object),
   never claims to be human, and does not ask a question in every reply.
   Globals: window.Friend */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  const used = {}; // slot key → recent variant indexes
  let counter = 0;

  function hash(s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
  /* pick(slot, variants, seedText): deterministic for a given history, avoids the last two variants used for this slot */
  function pick(slot, variants, seed) {
    if (!variants.length) return "";
    const recent = used[slot] || (used[slot] = []);
    let start = (hash(String(seed || "") + slot) + counter++) % variants.length;
    for (let i = 0; i < variants.length; i++) {
      const idx = (start + i) % variants.length;
      if (!recent.includes(idx) || variants.length <= 2) { recent.push(idx); if (recent.length > 2) recent.shift(); return variants[idx]; }
    }
    return variants[start];
  }
  const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);
  const plural = (n, w) => n + " " + w + (n === 1 ? "" : "s");
  const nm = (f) => (f.name ? ", " + f.name : "");
  function daysPhrase(d) { return d === 0 ? "today" : d === 1 ? "tomorrow" : "in " + d + " days"; }
  function eventLine(f, seed) {
    const e = f.event; if (!e) return "";
    const when = e.days != null ? daysPhrase(e.days) : e.whenText || "";
    const what = e.title.toLowerCase();
    return pick("evt", [
      "Your " + what + (when ? " is " + when : "") + ".",
      "And your " + what + (when ? " is " + when : "") + ", so there is a real target.",
      "I have your " + what + (when ? " down for " + (e.days != null ? when : e.whenText) : "") + ".",
    ], seed);
  }
  function tier(f) {
    const s = f.score; if (!s) return null;
    const pct = s.outOf ? (s.value / s.outOf) * 100 : s.value;
    return pct >= 75 ? "high" : pct >= 40 ? "mid" : "low";
  }
  const scoreText = (s) => s.value + (s.outOf ? " out of " + s.outOf : "");

  /* respond(act, f, env) → {text, suggestions, ask}. env: {seed, askedLast, memoryOn, saved} */
  function respond(act, f, env) {
    f = f || {}; env = env || {};
    const seed = env.seed || "", quiet = !!env.askedLast; // after a question, prefer a statement
    const out = { text: "", suggestions: [], ask: null };
    const subj = f.subject ? " in " + f.subject : "";
    const keep = env.memoryOn === false ? " Memory is off, so I won't keep this." : "";

    if (act === "score_update") {
      const t = tier(f), sc = scoreText(f.score);
      let main;
      if (t === "high") main = pick("scoreH", ["Nice, " + sc + " is a strong result" + subj + ".", "That's a solid " + sc + subj + ". You earned it" + nm(f) + ".", sc + "? Good going" + nm(f) + ".", "Strong work. " + cap(sc) + subj + " is something to be pleased with."], seed);
      else if (t === "mid") main = pick("scoreM", ["Okay, " + sc + subj + ". A decent base to build on.", "Thanks for telling me. " + cap(sc) + subj + " is workable.", "So " + sc + subj + ". Not the end of the road at all."], seed);
      else main = pick("scoreL", ["That's lower than you wanted, I can tell. One result doesn't decide where you end up.", "Hm, " + sc + subj + " is tough to see. It still tells us exactly what to work on.", "That stings, and it's okay to say so. It's also fixable."], seed);
      const ev = eventLine(f, seed);
      let tail = "";
      if (t === "low") { tail = " Want to go through where the marks went, or jump straight to a fix?"; out.suggestions = ["Make a recovery plan", "Where did I lose marks?"]; out.ask = { kind: "low_score", text: "go through where the marks went" }; }
      else if (ev && f.event) { tail = quiet ? "" : pick("planOffer", [" Want a study plan that fits the time you have left?", " Shall I sketch a plan for the days until then?", ""], seed); if (tail.trim()) { out.suggestions = ["Plan a study session"]; out.ask = { kind: "offer_plan", text: "offer a study plan" }; } }
      else if (!quiet && t === "high") { tail = pick("highAsk", [" What went best this time?", "", " Was it the paper you'd been preparing for?"], seed); if (tail.trim()) out.ask = { kind: "what_went_best", text: tail.trim() }; }
      out.text = main + (ev ? " " + ev : "") + tail + keep;
      return out;
    }
    if (act === "event_update") {
      const e = f.event;
      const lead = pick("evtLead", ["Got it.", "Okay, noted.", "Thanks for telling me.", "Understood."], seed);
      const days = e.days != null ? " That's " + (e.days === 0 ? "today" : e.days === 1 ? "tomorrow" : plural(e.days, "day") + " away") + "." : "";
      const sub = f.subject ? " Is it " + f.subject + "?" : "";
      let tail = "";
      if (!quiet) { tail = pick("evtTail", [" Want a plan that fits the time left?", " Shall we work out how to use those days?", ""], seed); if (tail.trim()) { out.suggestions = ["Plan a study session"]; out.ask = { kind: "offer_plan", text: "offer a study plan" }; } }
      out.text = lead + " Your " + e.title.toLowerCase() + (e.whenText ? " is " + e.whenText : "") + "." + days + tail + keep;
      if (!tail.trim() && !f.subject) out.text += "";
      return out;
    }
    if (act === "progress_done") {
      const what = f.doneWhat || "that";
      const lead = pick("done", ["Nice work finishing " + what + ".", "Good, " + what + " is done" + nm(f) + ".", "That's a solid session: " + what + " finished."], seed);
      const ctx = f.recentTopic && !String(what).toLowerCase().includes(f.recentTopic) ? " You were working through " + f.recentTopic + " recently." : "";
      let tail = "";
      if (quiet) tail = pick("doneQuiet", [" Give your brain a break; you've earned it.", " That's real progress."], seed);
      else { tail = pick("doneAsk", [" Want to test yourself with a couple of harder questions, or are you done for today?", " Want a quick self-test while it's fresh, or call it a day?", " Rest a little, or one more round?"], seed); out.ask = { kind: "next_round", text: "offer a harder round or stop" }; out.suggestions = ["Harder questions", "I'm done for today"]; }
      out.text = lead + ctx + tail;
      return out;
    }
    if (act === "setback_help") {
      const lead = pick("setback", ["I'm sorry, that's a hard one to take" + subj + ".", "That sounds rough" + subj + ", and it's fixable.", "Thanks for telling me. A bad result" + subj + " hurts, and it also shows exactly what to fix."], seed);
      const how = " A good first step is to find out where the marks actually went: concept gaps, calculation slips, or time. I can build a short recovery session, or we can go through the paper question by question.";
      out.suggestions = ["Make a recovery plan", subj ? "Show " + f.subject + " chapters" : "Where did I lose marks?"];
      out.ask = { kind: "recovery_choice", text: "recovery plan or go through the paper" };
      out.text = lead + how + keep;
      return out;
    }
    if (act === "mood_context") {
      const ev = f.event ? " especially with your " + f.event.title.toLowerCase() + " " + (f.event.days != null ? daysPhrase(f.event.days) : f.event.whenText) : "";
      const lead = pick("moodC", ["That sounds like a lot" + ev + ".", "I hear you" + ev + ".", "Okay. That's heavy" + ev + "."], seed);
      const tail = quiet ? "" : pick("moodT", [" Want to break it into small steps together?", " We could shrink it to the next one thing. Want to try?", ""], seed);
      if (tail.trim()) { out.suggestions = ["Plan a study session"]; out.ask = { kind: "offer_plan", text: "shrink the load" }; }
      out.text = lead + tail;
      return out;
    }
    if (act === "later") {
      out.text = pick("later", ["Okay, parked for later.", "Sure, we'll come back to it.", "No rush. It'll be here when you're ready."], seed) + (f.thing ? " (" + f.thing + ")" : "") + (env.memoryOn === false ? "" : " Say \"continue\" whenever you want to pick it up.");
      return out;
    }
    if (act === "change_mind") {
      out.text = pick("mind", ["No problem, plans change. What would you like to do instead?", "Fair enough. What are we doing instead?", "Okay, dropping that. What now?"], seed);
      out.ask = { kind: "new_direction", text: "ask what to do instead" };
      return out;
    }
    if (act === "greet_context") {
      out.text = f.line || "";
      return out;
    }
    out.text = "";
    return out;
  }
  function reset() { Object.keys(used).forEach((k) => delete used[k]); counter = 0; }
  root.Friend = { respond, pick, reset, tier, daysPhrase };
})();
