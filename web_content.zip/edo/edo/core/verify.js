/* EDO verification. Checks drafted answers; never invents a second solver for the same problem.
   Status vocabulary (honest): "verified" | "partially verified" | "not verified" | "unable to verify". */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;

  function inventedSource(text) {
    return /\b(according to a source|a recent article said|I found a page)\b/i.test(text) && !/https?:\/\//i.test(text);
  }
  function audit(text, opts) {
    const notes = [];
    const src = String(text || "");
    if (inventedSource(src)) notes.push("Answer mentions a source but contains no URL. Treat that citation as unverified.");
    if (opts && opts.calcMismatch) notes.push("Calculator re-check disagreed with the drafted number. Prefer the calculator value.");
    if (opts && opts.residual != null && opts.residual > 1e-4) notes.push("Substitution residual is large; answer withheld or flagged.");
    return { ok: notes.length === 0, notes, suffix: notes.length ? "\nVerification note: " + notes.join(" ") : "", meta: notes.length ? " Verification flagged the draft." : "" };
  }
  /* Evaluate twice through different routes: the expression itself and a bracketed/offset form. */
  function recompute(expr) {
    if (!root.Calc) throw Error("Calc missing");
    const a = root.Calc.run(expr);
    const b = root.Calc.run("(" + expr + ")+0");
    return { value: a, agree: a === b || Math.abs(a - b) <= 1e-9 * Math.max(1, Math.abs(a)) };
  }
  const close = (a, b, r) => Math.abs(a - b) <= (r || 1e-9) * Math.max(1, Math.abs(a), Math.abs(b));

  /* Each check: {name, ok:true|false|null, detail}. ok === null means the check could not be run. */
  const checks = {
    finite: (v) => ({ name: "finite value", ok: typeof v === "number" && isFinite(v), detail: String(v) }),
    agree: (a, b, name, tol) => ({ name: name || "independent route agrees", ok: close(a, b, tol), detail: a + " vs " + b }),
    substitute: (f, x, tol) => { let r; try { r = f(x); } catch (e) { return { name: "substitute back", ok: null, detail: e.message }; } return { name: "substitute back", ok: Math.abs(r) <= (tol || 1e-8) * Math.max(1, Math.abs(x)), detail: "residual " + r }; },
    dimension: (got, want, label) => {
      if (!got || !want) return { name: "dimension check", ok: null, detail: "no expected dimension" };
      const ok = root.Units.sameDim(got, want);
      return { name: "dimension check", ok, detail: (label || "result") + ": " + root.Units.dimStr(got) + (ok ? "" : " but expected " + root.Units.dimStr(want)) };
    },
    /* Physical sanity rules by quantity name. HEURISTIC: only fires for well-known quantities. */
    range: (kind, v, unit) => {
      const k = String(kind).toLowerCase();
      const R = [
        [/probability/, 0, 1], [/speed|velocity/, -3e8, 3e8, "speed above c"], [/^mass|molar mass|^moles?$/, 0, Infinity, "negative amount"],
        [/temperature/, 0, Infinity, "below absolute zero (K)"], [/\bph\b/, -2, 16, "pH far outside 0–14 (check the data)"], [/time|period|half-life/, 0, Infinity, "negative duration"],
        [/resistance|capacitance|energy.*kinetic|kinetic energy|focal length magnitude/, 0, Infinity, "negative where only ≥ 0 is physical"], [/efficiency/, 0, 1, "efficiency outside 0–1"],
      ];
      for (const [re, lo, hi, msg] of R) if (re.test(k)) {
        if (/temperature/.test(k) && unit && unit !== "K") return { name: "range sanity", ok: null, detail: "non-Kelvin temperature not range-checked" };
        const ok = v >= lo && v <= hi;
        return { name: "range sanity", ok, detail: ok ? "within expected range" : (msg || "outside expected range") + " (" + v + ")" };
      }
      return { name: "range sanity", ok: null, detail: "no rule for '" + kind + "'" };
    },
  };
  /* Combine checks → status. A single failed check is "not verified"; zero runnable checks is "unable to verify". */
  function status(list) {
    const run = list.filter((c) => c.ok !== null && c.ok !== undefined);
    if (!run.length) return { status: "unable to verify", checks: list };
    if (run.some((c) => c.ok === false)) return { status: "not verified", checks: list };
    if (run.length < list.length) return { status: "partially verified", checks: list };
    return { status: run.length >= 2 ? "verified" : "partially verified", checks: list };
  }
  function describe(st) {
    return st.status + " (" + st.checks.map((c) => (c.ok === true ? "✓ " : c.ok === false ? "✗ " : "– ") + c.name + (c.detail ? ": " + c.detail : "")).join("; ") + ")";
  }
  root.Verify = { audit, recompute, inventedSource, checks, status, describe, close };
})();
