/* EDO intent engine. UI-independent classifier.
   Ported from the TypeScript intent engine and aligned with the base modes. */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  const SEARCH = /\b(search|look up|google|latest|current|news|docs|documentation|today|this year|website|url|cite|source)\b/i;
  const LOCATION = /\b(where am i|near me|nearby|my location|find places|around me|this area)\b/i;
  const WEATHER = /\b(weather|temperature|forecast|rain|humidity|wind)\b/i;
  const CALC_FN = /\b(sqrt|sin|cos|tan|log|ln|abs|exp|min|max)\s*\(/i;
  function isCalculation(text) {
    const t = text.trim();
    if (root.Normalize && root.Normalize.math(t)) return true; // 100×100, 15% of 200, 25 squared, ...
    if (/^\s*(calculate|compute|evaluate|what is|what's)\s+[0-9(]/i.test(t)) return true;
    if (!/^[\s0-9+\-*/^().,eEπ√a-z]+$/i.test(t)) return false;
    if (!/\d/.test(t)) return false;
    if (!/[+\-*/^]/.test(t) && !CALC_FN.test(t)) return false;
    if (/\b(find|formula|the|and|for|write|code)\b/i.test(t)) return false;
    return true;
  }
  const PROG = /\b(code|debug|refactor|typescript|javascript|python|html|css|java|kotlin|sql|git|api|function|class|compile|syntax|unity|android|program|bug|bugs|compiler|traceback|exception|segfault|segmentation fault|refactor|regex|algorithm|complexity|big-?o|json|c\+\+|c#|bash|stack overflow|null ?pointer)\b/i;
  const JEE = /\b(jee|kinematics|newton|thermodynamics|electrostatics|organic|inorganic|mole|integration|differentiation|matrix|conic|shm|optics|equilibrium|projectile|molarity|quadratic)\b/i;
  const CONCISE = /\b(only the answer|just the answer|short answer|no explanation)\b/i;
  const EXPLAIN = /\b(step by step|explain|show working|why|how did you)\b/i;
  const MEMORY = /\b(remember|forget|note that|my preference|save this|what do you remember)\b/i;
  const FILE = /\b(analy[sz]e (this )?file|file contents|attached file)\b/i;

  function subjectFrom(text) {
    if (/\b(physics|force|velocity|current|magnetic|optics|wave|gravitation|projectile|kinematic)\b/i.test(text)) return "physics";
    if (/\b(chemistry|organic|inorganic|mole|equilibrium|acid|ph|molar)\b/i.test(text)) return "chemistry";
    if (/\b(math|algebra|integral|derivative|matrix|probability|quadratic|trigonometry)\b/i.test(text)) return "mathematics";
    return undefined;
  }

  function kindFromMode(mode) {
    const m = String(mode || "assistant").toLowerCase();
    if (m === "programming") return "programming";
    if (m === "jee" || m === "study") return "jee";
    if (m === "search") return "search";
    return "conversation";
  }

  function detect(input, mode) {
    const text = String(input || "").trim();
    const notes = [];
    let kind = kindFromMode(mode);
    let confidence = 0.55;
    let wantsSearch = String(mode || "").toLowerCase() === "search";
    let wantsLocation = false;
    let wantsWeather = false;
    if (!text) {
      return { kind: "system", confidence: 1, wantsSearch: false, wantsLocation: false, wantsWeather: false, concise: false, explain: false, notes: ["empty"] };
    }
    const comp = root.Companion ? root.Companion.detect(text) : null;
    if (comp === "crisis" || (comp === "decision" && root.Companion.active())) {
      kind = comp; // safety message first; an open decision flow keeps its own answers
      confidence = 1;
    } else if (LOCATION.test(text)) {
      kind = "location";
      wantsLocation = true;
      confidence = 0.92;
      notes.push("location");
    } else if (WEATHER.test(text)) {
      kind = "weather";
      wantsWeather = true;
      wantsLocation = true;
      confidence = 0.88;
      notes.push("weather needs a location fix; no forecast API is bundled");
    } else if (MEMORY.test(text)) {
      kind = "memory";
      confidence = 0.9;
    } else if (FILE.test(text)) {
      kind = "file";
      confidence = 0.8;
    } else if (root.Device && root.Device.parse(text)) {
      kind = "device";
      confidence = 0.9;
    } else if (isCalculation(text)) {
      kind = "calculation";
      confidence = 0.86;
    } else if (comp) {
      kind = comp; // "decision" or "chat"
      confidence = 0.8;
    } else if (PROG.test(text) && kind !== "jee") {
      kind = "programming";
      confidence = 0.8;
    } else if (JEE.test(text) || kind === "jee") {
      kind = "jee";
      confidence = Math.max(confidence, 0.72);
    } else if (SEARCH.test(text)) {
      kind = "search";
      wantsSearch = true;
      confidence = 0.8;
    }
    if (SEARCH.test(text)) wantsSearch = true;
    return {
      kind,
      confidence,
      subject: subjectFrom(text),
      wantsSearch,
      wantsLocation,
      wantsWeather,
      concise: CONCISE.test(text),
      explain: EXPLAIN.test(text),
      notes,
    };
  }

  root.Intent = { detect };
})();
