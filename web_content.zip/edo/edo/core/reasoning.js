/* EDO reasoning engine. Pipeline: intent → givens/target extraction → formula retrieval →
   solve (direct or secant) → substitute-back verification → concise report.
   Needs global Calc (expression evaluator), EDO_FORMULAS, EDO_CONSTS. */
(function(){
const FN=new Set(['sqrt','sin','cos','tan','sind','cosd','tand','ln','log','exp','abs','pi']);
const sig=x=>{const v=+(+x).toPrecision(6),a=Math.abs(v);return(a>=1e6||(a>0&&a<1e-3))?v.toExponential().replace(/\.?0+e/,'e'):v};
const idsAll=e=>[...new Set((e.match(/[A-Za-z_][A-Za-z_0-9]*/g)||[]).filter(w=>!FN.has(w)))];
function ev(e,v){const d=Math.PI/180;Calc.fn.sind=x=>Math.sin(x*d);Calc.fn.cosd=x=>Math.cos(x*d);Calc.fn.tand=x=>Math.tan(x*d);
  let s=e;Object.keys(v).sort((a,b)=>b.length-a.length).forEach(k=>{s=s.replace(new RegExp('\\b'+k+'\\b','g'),'('+v[k]+')')});
  try{return Calc.run(s)}catch(_){return NaN}}
function secant(f){for(const s of [1,2,.5,10,.1,100,-1]){let x0=s,x1=s*1.1+.01,f0=f(x0),f1=f(x1);
  for(let i=0;i<80&&isFinite(f1);i++){if(f1===f0)break;const x2=x1-f1*(x1-x0)/(f1-f0);x0=x1;f0=f1;x1=x2;f1=f(x1);
    if(Math.abs(f1)<1e-12||Math.abs(x1-x0)<1e-13*Math.max(1,Math.abs(x1)))break}
  if(isFinite(x1)&&Math.abs(f1)<1e-9*Math.max(1,Math.abs(x1)))return x1}return NaN}
function solveFor(F,T,given){const [L,R]=F.e.split('='),all=idsAll(F.e);
  const vars=all.filter(w=>!(w in EDO_CONSTS)),cs=all.filter(w=>(w in EDO_CONSTS)&&!(w in given));
  if(!vars.includes(T)||vars.some(w=>w!==T&&!(w in given)))return null;
  const base=Object.assign({},EDO_CONSTS,given);delete base[T];let val;
  if(L.trim()===T)val=ev(R,base);else if(R.trim()===T)val=ev(L,base);
  else val=secant(x=>{const b=Object.assign({},base,{[T]:x});return ev(L,b)-ev(R,b)});
  if(!isFinite(val))return null;
  const b=Object.assign({},base,{[T]:val}),l=ev(L,b),r=ev(R,b),res=Math.abs(l-r);   // verification: substitute back
  if(!(res<=1e-6*Math.max(1,Math.abs(l),Math.abs(r))))return null;
  return{F,val,res,cs}}
function parse(t){const g={};let n=0;
  t.replace(/\b([A-Za-z_]\w*)\s*=\s*(-?\d*\.?\d+(?:e[+-]?\d+)?)/gi,(m,k,v)=>{g[k]=+v;n++;return m});
  const m=t.match(/\b(?:find|calculate|compute|determine|solve for|get)\s+(?:the\s+)?([A-Za-z_]\w*)\b/i);return{g,n,T:m&&m[1]}}
window.Reasoner={ev,solveFor,idsAll,sig,
  matches(t){if(!window.EDO_FORMULAS)return false;if(/^\s*formulas?\b/i.test(t))return true;const p=parse(t);return p.n>0&&!!p.T},
  run(t){const D=EDO_FORMULAS;
    if(/^\s*formulas?\b/i.test(t)){
      const q=t.replace(/^\s*formulas?\s*(for|of|on)?/i,'').toLowerCase().split(/\W+/).filter(w=>w.length>2);
      if(!q.length)return{text:'Formula table: '+D.length+' entries. Try "formula kinetic energy" or "formula optics".',meta:''};
      const sc=D.map(f=>({f,s:q.filter(w=>(f.n+' '+f.c+' '+f.k+' '+f.s).toLowerCase().includes(w)).length})).filter(x=>x.s).sort((a,b)=>b.s-a.s).slice(0,6);
      return sc.length?{text:sc.map(x=>'• '+x.f.n+': '+x.f.e.replace(/^~/,'')+'  ('+x.f.s+' · '+x.f.c+')').join('\n'),meta:'Local formula table. SI units; sind/cosd take degrees.'}
        :{text:'No formula in the local table matches "'+q.join(' ')+'". I will not guess one.',meta:'Nothing retrieved.'}}
    const p=parse(t),T=p.T,keys=Object.keys(p.g);
    const hits=D.filter(f=>!f.e.startsWith('~')).map(f=>solveFor(f,T,p.g)).filter(Boolean);
   if(!hits.length){
      let extra='';
      if(window.EDOKnowledge){
        const kn=EDOKnowledge.search(t).slice(0,2);
        if(kn.length)extra='\nRelated notes: '+kn.map(h=>h.doc.title+' ('+h.doc.chapter+')').join('; ')+'. These are explanations, not a computed value.';
      }
      return{text:'No formula in the local table links '+T+' to exactly these givens ('+keys.join(', ')+').\nCheck variable names with "formula <topic>", or supply the missing quantity.'+extra,meta:'Nothing was computed.'};
    }
    const u=[];hits.forEach(h=>{if(!u.some(x=>Math.abs(x.val-h.val)<=1e-9*Math.max(1,Math.abs(h.val))))u.push(h)});
    const given='Givens: '+keys.map(k=>k+'='+p.g[k]).join(', ');
    if(u.length>1)return{text:'**Several formulas fit and give different values. Choose by chapter:**\n'+u.map(x=>'• '+x.F.n+' ('+x.F.c+'): '+T+' = '+sig(x.val)+'   ['+x.F.e+']').join('\n')+'\n'+given,meta:'Each value was verified by substitution; which one applies depends on the problem.'};
    const h=u[0],used=h.cs.map(c=>c+'='+EDO_CONSTS[c]).join(', ');
    return{text:'**'+T+' = '+sig(h.val)+'**\nMethod: '+h.F.n+' ('+h.F.s+' · '+h.F.c+'): '+h.F.e+'\n'+given+'\nCheck: substituted back, residual '+h.res.toExponential(1)+(hits.length>1?'; '+hits.length+' formulas agreed':'')+(used?'\nConstants assumed: '+used:''),
      meta:'Computed locally from the formula table. Units are not checked (assumes SI).'}}
};
})();
