/* EDO planner. Builds short study / revision plans from the local chapter notes (EDO_DOCS) and the time the user has.
   It is a template planner: chapter choice, formulas, traps and mistakes come from the reviewed notes, and the time split is a
   fixed ratio. It does not know the user's syllabus coverage unless told, and says so. Pure functions, no UI, no storage.
   Globals: window.Planner */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  const SUBJECTS = { physics: "physics", phy: "physics", chemistry: "chemistry", chem: "chemistry", maths: "mathematics", math: "mathematics", mathematics: "mathematics" };

  function subjectOf(text) {
    const m = String(text || "").toLowerCase().match(/\b(physics|phy|chemistry|chem|maths|math|mathematics)\b/);
    return m ? SUBJECTS[m[1]] : null;
  }
  function docsFor(subject) { return ((root.EDO_DOCS || []).filter((d) => d.domain === subject)); }
  function pickChapter(subject, topicText, studied) {
    const docs = docsFor(subject);
    if (!docs.length) return null;
    if (topicText && root.EDOKnowledge) {
      const hit = root.EDOKnowledge.search(topicText, subject)[0];
      if (hit && hit.score >= 2) return hit.doc;
    }
    const done = new Set((studied || []).map((s) => String(s).toLowerCase()));
    return docs.find((d) => !done.has(String(d.chapter).toLowerCase())) || docs[0];
  }
  const clampMin = (m) => Math.max(20, Math.min(240, Math.round((+m || 60) / 5) * 5));
  const names = (arr, n) => (arr || []).slice(0, n).map((f) => (f.name ? f.name : String(f))).join("; ");

  /* studyPlan({subject, minutes, topic, flavor:"recovery"|"revision"|"new", studied:[chapter names]}) */
  function studyPlan(o) {
    o = o || {};
    const subject = o.subject || subjectOf(o.topic) || null;
    const total = clampMin(o.minutes);
    const doc = subject ? pickChapter(subject, o.topic, o.studied) : null;
    const title = (o.flavor === "recovery" ? "Recovery session" : "Study session") + (subject ? ": " + subject : "") + (doc ? " · " + doc.chapter : "") + " (" + total + " min)";
    const steps = [];
    const add = (frac, text) => steps.push({ text, minutes: Math.max(5, Math.round((total * frac) / 5) * 5) });
    if (o.flavor === "recovery") {
      add(0.2, "List every question you lost marks on and tag each one: concept gap, calculation slip, silly mistake, or ran out of time.");
      add(0.35, doc ? "Re-learn the weakest idea from " + doc.chapter + ". Key relations: " + (names(doc.formulas, 3) || "your own formula sheet") + "." : "Re-learn the weakest idea from your tagged list using your notes.");
      add(0.3, "Re-solve three of the questions you lost, without looking at the solution first." + (doc && doc.mistakes && doc.mistakes[0] ? " Watch for: " + doc.mistakes[0] : ""));
      add(0.15, "Write one line per mistake type: what you will do differently next time.");
    } else {
      add(0.1, doc ? "Warm-up: write " + (names(doc.formulas, 3) || "the key formulas") + " from memory, then check." : "Warm-up: write the key formulas you remember, then check against your notes.");
      add(0.3, doc ? "Concept pass on " + doc.chapter + ": " + (doc.summary || "read your notes") + (doc.prereqs && doc.prereqs.length ? " (needs: " + doc.prereqs.slice(0, 3).join(", ") + ")" : "") : "Concept pass: read one topic slowly and explain it aloud in your own words.");
      add(0.4, doc && doc.methods && doc.methods.length ? "Practice: solve problems using this method: " + doc.methods[0] : "Practice: solve problems on this topic, easiest first, and mark each as clean, shaky or wrong.");
      add(0.15, doc && (doc.mistakes || doc.traps || []).length ? "Review traps: " + (doc.mistakes || doc.traps)[0] : "Review everything you marked shaky or wrong.");
      add(0.05, "Wrap-up: write three lines on what you learned and what to do next.");
    }
    if (total >= 90) steps.splice(Math.ceil(steps.length / 2), 0, { text: "Short break: water, stretch, no phone.", minutes: 10 });
    const note = doc ? "Built from the local notes for " + doc.chapter + ". EDO does not know which chapters you have already covered unless you tell it." : "No chapter notes matched, so this is a general structure.";
    return { title, subject, chapter: doc ? doc.chapter : null, minutes: total, steps, note };
  }
  function render(plan, doneIdx) {
    return plan.steps.map((s, i) => (i < (doneIdx || 0) ? "✓ " : (i + 1) + ". ") + s.text + " (" + s.minutes + " min)").join("\n");
  }
  function nextStep(plan) {
    const i = plan.steps.findIndex((s) => !s.done);
    return i < 0 ? null : { index: i, step: plan.steps[i], remaining: plan.steps.length - i };
  }
  root.Planner = { studyPlan, render, nextStep, subjectOf, clampMin };
})();
