/* EDO problem solver. Pipeline: text → quantities (units→SI) → topic template → solve → independent
   verification → worked answer. Needs global Calc. Hooks into Reasoner.matches/run (core/reasoning.js). */
(function(){
'use strict';
const PI=Math.PI,LN2=Math.LN2;
const DU={L:'m',M:'kg',T:'s',V:'m/s',A:'m/s²',F:'N',E:'J',P:'W',p:'Pa',Vo:'V',I:'A',Q:'C',R:'Ω',Cap:'F',B:'T',K:'K',n:'mol',Vol:'m³',Conc:'mol/m³',ang:'rad',k:'N/m'};
const U={m:[1,'L'],cm:[.01,'L'],mm:[.001,'L'],km:[1e3,'L'],kg:[1,'M'],g:[.001,'M'],mg:[1e-6,'M'],s:[1,'T'],ms:[.001,'T'],min:[60,'T'],h:[3600,'T'],day:[86400,'T'],yr:[3.156e7,'T'],
'm/s':[1,'V'],'km/h':[1/3.6,'V'],'cm/s':[.01,'V'],'m/s2':[1,'A'],'m/s^2':[1,'A'],'m/s²':[1,'A'],N:[1,'F'],kN:[1e3,'F'],J:[1,'E'],kJ:[1e3,'E'],eV:[1.602e-19,'E'],
W:[1,'P'],kW:[1e3,'P'],Pa:[1,'p'],kPa:[1e3,'p'],atm:[101325,'p'],bar:[1e5,'p'],V:[1,'Vo'],mV:[.001,'Vo'],kV:[1e3,'Vo'],A:[1,'I'],mA:[.001,'I'],
C:[1,'Q'],pC:[1e-12,'Q'],pF:[1e-12,'Cap'],nF:[1e-9,'Cap'],mC:[.001,'Q'],uC:[1e-6,'Q'],'µC':[1e-6,'Q'],'μC':[1e-6,'Q'],nC:[1e-9,'Q'],'Ω':[1,'R'],ohm:[1,'R'],'kΩ':[1e3,'R'],F:[1,'Cap'],uF:[1e-6,'Cap'],'µF':[1e-6,'Cap'],'μF':[1e-6,'Cap'],mF:[.001,'Cap'],
T:[1,'B'],mT:[.001,'B'],K:[1,'K'],'°C':[1,'degC'],mol:[1,'n'],mmol:[.001,'n'],L:[.001,'Vol'],mL:[1e-6,'Vol'],M:[1e3,'Conc'],mM:[1,'Conc'],'mol/L':[1e3,'Conc'],'°':[PI/180,'ang'],deg:[PI/180,'ang'],rad:[1,'ang'],'N/m':[1,'k']};
const AL={meter:'m',meters:'m',metre:'m',metres:'m',second:'s',seconds:'s',sec:'s',secs:'s',minute:'min',minutes:'min',mins:'min',hour:'h',hours:'h',hr:'h',hrs:'h',kilogram:'kg',kilograms:'kg',gram:'g',grams:'g',
degree:'deg',degrees:'deg',litre:'L',litres:'L',liter:'L',liters:'L',l:'L',ml:'mL',ohms:'ohm',volt:'V',volts:'V',amp:'A',amps:'A',ampere:'A',amperes:'A',newton:'N',newtons:'N',joule:'J',joules:'J',watt:'W',watts:'W',
coulomb:'C',coulombs:'C',mole:'mol',moles:'mol',kelvin:'K',tesla:'T',farad:'F',farads:'F',radian:'rad',radians:'rad',kmph:'km/h',day:'day',days:'day',year:'yr',years:'yr',yr:'yr','km/hr':'km/h',molar:'M','mol/l':'mol/L'};
/* "2 micro coulomb" / "30 centimetre" -> "2 µC" / "30 cm". Only combinations present in the unit table are rewritten. */
const SPELL_P={micro:'µ',milli:'m',nano:'n',pico:'p',kilo:'k',centi:'c'},SPELL_B={'coulombs?':'C','farads?':'F','amperes?':'A','amps?':'A','volts?':'V','ohms?':'Ω','metres?':'m','meters?':'m','grams?':'g','seconds?':'s','teslas?':'T'};
function spell(t){return t.replace(/\b(micro|milli|nano|pico|kilo|centi)[\s-]*(coulombs?|farads?|amperes?|amps?|volts?|ohms?|metres?|meters?|grams?|seconds?|teslas?)\b/gi,(m,p,b)=>{const bk=Object.keys(SPELL_B).find(k=>new RegExp('^'+k+'$','i').test(b)),sym=SPELL_P[p.toLowerCase()]+SPELL_B[bk];return U[sym]?sym:m})}
const uk=u=>U[u]?u:(AL[u.toLowerCase()]&&U[AL[u.toLowerCase()]]?AL[u.toLowerCase()]:null);
const NUM='(?<![\\w.])(-?\\d+(?:\\.\\d+)?|-?\\.\\d+)(?:\\s*[eE]\\s*([+-]?\\d+)(?![a-zA-Z])|\\s*[x×*]\\s*10\\s*\\^?\\s*\\(?([+-]?\\d+)\\)?)?';
const sg=(x,n=4)=>{if(!isFinite(x))return String(x);if(x===0)return'0';const a=Math.abs(x);return a>=1e5||a<1e-3?x.toExponential(n-1).replace(/\.?0+e/,'e'):String(+x.toPrecision(n))};
const close=(a,b,r=1e-6)=>Math.abs(a-b)<=r*Math.max(1,Math.abs(a),Math.abs(b));
const gcd=(a,b)=>b?gcd(b,a%b):a;
const Cb=(n,r)=>{if(r<0||r>n)return 0;let c=1;for(let i=1;i<=r;i++)c=c*(n-r+i)/i;return Math.round(c)};
const AM={H:1,He:4,Li:7,C:12,N:14,O:16,F:19,Na:23,Mg:24,Al:27,Si:28,P:31,S:32,Cl:35.5,K:39,Ca:40,Cr:52,Mn:55,Fe:56,Ni:58.7,Cu:63.5,Zn:65.4,Br:80,Ag:108,I:127,Ba:137,Hg:201,Pb:207};
function mm(s){let i=0;const N=()=>{const m=/^\d+/.exec(s.slice(i));if(!m)return 1;i+=m[0].length;return+m[0]};
 const P=()=>{let t=0;while(i<s.length&&s[i]!==')'){if(s[i]==='('){i++;const x=P();i++;t+=x*N()}else{const m=/^[A-Z][a-z]?/.exec(s.slice(i));if(!m||!(m[0] in AM))return NaN;i+=m[0].length;t+=AM[m[0]]*N()}}return t};return P()}
const formulas=t=>[...new Set((t.match(/(?<![A-Za-z])(?:[A-Z][a-z]?\d*|\((?:[A-Z][a-z]?\d*)+\)\d*)+(?![a-z])/g)||[]).filter(f=>((f.match(/[A-Z]/g)||[]).length>=2||/\d/.test(f))&&mm(f)>0))];
function parseQ(t){const out=[],re=new RegExp(NUM+'\\s*(°C|°|[A-Za-zµμΩ]+(?:\\/[A-Za-zµμ]+\\^?[²23]?)?)?','g');let m;
 while((m=re.exec(t))){const num=+m[1]*10**+(m[2]||m[3]||0),k=uk(m[4]||'');let v=num,d='',f=1;
  if(k){[f,d]=U[k];v=num*f;if(d==='degC'){v=num+273.15;d='K';f=0}}
  out.push({v,d,u:k||m[4]||'',num,fac:f,ctx:t.slice(Math.max(0,m.index-70),m.index).toLowerCase(),aft:t.slice(re.lastIndex,re.lastIndex+20).toLowerCase()})}
 return out}
function mkq(t){const l=t.toLowerCase().replace(/²/g,'^2'),Q=parseQ(t),am=l.match(/(?:find|calculate|determine|what|how|compute|estimate|obtain|evaluate|solve|show)[^.?]*/g)||[l],ask=am[am.length-1];
 const q={t,l,Q,ask,fm:formulas(t),
  g(d,h){const c=Q.filter(x=>x.d==d);if(h){const m=c.filter(x=>h.test(x.ctx)||h.test(x.aft));if(m.length)return m[0].v}return c.length==1?c[0].v:undefined},
  all:d=>Q.filter(x=>x.d==d).map(x=>x.v),a:re=>re.test(ask),
  pick(o){let b,bi=1e9;for(const k in o){const m=o[k].exec(ask);if(m&&m.index<bi){bi=m.index;b=k}}return b},
  w:re=>mkq(t.replace(re,' '))};return q}
/* ---------- math helpers ---------- */
function norm(e){e=e.toLowerCase().replace(/π/g,'pi').replace(/[×·]/g,'*').replace(/²/g,'^2').replace(/³/g,'^3').replace(/−/g,'-').replace(/√\s*\(?([^)\s]+)\)?/g,'sqrt($1)')
 .replace(/(\d+(?:\.\d+)?)\s*(?:°|degrees?)/g,'($1*pi/180)').replace(/\be\^\(([^()]*)\)/g,'exp($1)').replace(/\be\^([a-z0-9.]+)/g,'exp($1)');
 const F='sind|cosd|tand|sin|cos|tan|ln|log|exp|sqrt|abs';
 e=e.replace(new RegExp('\\b('+F+')\\^(\\d)\\s*(\\([^()]*\\)|[a-z0-9.]+)','g'),'($1($3))^$2').replace(new RegExp('\\b('+F+')\\s+(\\([^()]*\\)|[a-z0-9.]+(?:\\^[\\d.]+)?)','g'),'$1($2)')
 .replace(/\be\b/g,'2.718281828459045').replace(/\s+/g,'').replace(/(\d|\))(?=[a-z(])/g,'$1*').replace(/(?<![a-z])x(?=\(|[a-z])/g,'x*').replace(/\)(?=\d)/g,')*');return e}
function fnInit(){const d=PI/180;Calc.fn.sind=x=>Math.sin(x*d);Calc.fn.cosd=x=>Math.cos(x*d);Calc.fn.tand=x=>Math.tan(x*d)}
function fx(e,x){fnInit();try{return Calc.run(e.replace(/(?<![a-z])x(?![a-z(])/g,'('+x+')'))}catch(_){return NaN}}
const num=s=>{fnInit();try{return Calc.run(norm(s))}catch(_){return NaN}};
function pp(s){s=s.toLowerCase().replace(/\s+/g,'').replace(/²/g,'^2').replace(/³/g,'^3').replace(/[−–]/g,'-');if(!/^[-+\d.x^*]+$/.test(s))return null;const c={};
 for(const tm of s.replace(/-/g,'+-').split('+').filter(Boolean)){const m=/^(-?)(\d*\.?\d*)\*?(x)?(?:\^(\d+))?$/.exec(tm);if(!m||(m[2]===''&&!m[3]))return null;c[m[3]?(m[4]?+m[4]:1):0]=(c[m[3]?(m[4]?+m[4]:1):0]||0)+(m[2]===''?1:+m[2])*(m[1]?-1:1)}return Object.keys(c).length?c:null}
const pv=(c,x)=>Object.keys(c).reduce((s,p)=>s+c[p]*x**+p,0);
const dp=c=>{const D={};for(const p in c)if(+p>0)D[p-1]=(D[p-1]||0)+p*c[p];return D};
const ps=c=>Object.keys(c).map(Number).sort((a,b)=>b-a).filter(p=>Math.abs(c[p])>1e-12).map((p,i)=>{const v=c[p],a=Math.abs(v),b=p==0?sg(a,6):(a==1?'':sg(a,6))+'x'+(p==1?'':'^'+p);return(v<0?(i?' - ':'-'):(i?' + ':''))+b}).join('')||'0';
const simpson=(f,a,b,n)=>{const h=(b-a)/n;let s=f(a)+f(b);for(let i=1;i<n;i++)s+=f(a+i*h)*(i%2?4:2);return s*h/3};
function mono(s){s=s.replace(/\s+/g,'');const m=/^([+-]?)(\d*\.?\d*)(?:\*?(x)(?:\^\(?(-?\d+)\)?)?)?(?:\/(\d+\.?\d*|x(?:\^(\d+))?))?$/.exec(s);if(!m)return null;
 let c=m[2]===''?((m[3]||/\/x/.test(s))?1:NaN):+m[2];if(isNaN(c))return null;let p=m[3]?(m[4]!==undefined?+m[4]:1):0;if(m[1]=='-')c=-c;if(m[5]){if(m[5][0]=='x')p-=m[6]?+m[6]:1;else c/=+m[5]}return{c,p}}
const piFrac=x=>{const r=x/PI;for(let d=1;d<=12;d++){const n=Math.round(r*d);if(Math.abs(r-n/d)<1e-9)return n==0?'0':(n==1&&d==1?'π':(n==1?'π/'+d:(d==1?n+'π':n+'π/'+d)))}return null};
/* ---------- templates ---------- */
const TPL=[],T=(n,re,fn)=>TPL.push([n,re,fn]),miss=m=>{throw{miss:m}},bad=m=>{throw{bad:m}},skip=()=>{throw{skip:1}},R=(a,s,c,n,g)=>({a,s,c,n,g});
T('calculus',/derivative|differentiate|d\/dx|integral|integrate|∫|\blimit\b|\blim\b/,q=>{
 const l=q.l,kind=/limit|\blim\b/.test(l)?'lim':/integra|∫/.test(l)?'int':'der';
 let ex=q.t.replace(/^.*?(?:derivative|differentiate|integrate|integral|\blimit\b|\blim\b|∫|d\/dx)(?:\s+of)?\s*/i,'').split(/\s+(?:at|from|between|as|when|with respect|wrt|w\.r\.t|where)\b|,|\?|\bdx\b|\.\s|\.$/i)[0].replace(/^f\(x\)\s*=\s*/i,'').trim();{let d=0,w=ex[0]=='('&&ex.endsWith(')');for(let i=0;i<ex.length-1&&w;i++){d+=ex[i]=='('?1:ex[i]==')'?-1:0;if(d==0)w=false}if(w)ex=ex.slice(1,-1)}
 if(!ex)miss('the function');const e=norm(ex),f=x=>fx(e,x),P=pp(ex);
 if(kind=='der'){const pm=q.t.match(/x\s*=\s*(-?[\dπ.\/pi*]+)/i),pt=pm?num(pm[1]):undefined;let sym,dx;
  if(P){const D=dp(P);sym=ps(D);dx=x=>pv(D,x)}else{const tb={'sin(x)':['cos(x)',Math.cos],'cos(x)':['-sin(x)',x=>-Math.sin(x)],'tan(x)':['sec²(x)',x=>1/Math.cos(x)**2],'exp(x)':['exp(x)',Math.exp],'ln(x)':['1/x',x=>1/x]};if(tb[e]){sym=tb[e][0];dx=tb[e][1]}}
  if(pt===undefined&&!sym)miss('a point x = a (no closed form in my rule table)');
  const nd=x=>{const D=h=>(f(x+h)-f(x-h))/(2*h);return(4*D(5e-4)-D(1e-3))/3},x0=pt===undefined?.7:pt,a=dx?dx(x0):nd(x0);
  const st=['f(x) = '+ex.trim()];if(sym)st.push("f'(x) = "+sym);if(pt!==undefined)st.push("Evaluate at x = "+sg(pt)+": f'("+sg(pt)+") = "+sg(a));
  return R(pt!==undefined?[["f'("+sg(pt)+")",a,'']]:[["f'(x)",sym,'']],st,[a,nd(x0),'symbolic derivative vs numeric (Richardson) derivative'],'',0)}
 if(kind=='int'){const bm=q.t.match(/from\s+(.+?)\s+to\s+(.+?)\s*(?:\.|\?|$|\bdx\b)/i)||q.t.match(/between\s+(.+?)\s+and\s+(.+?)\s*(?:\.|\?|$)/i);
  if(!bm){if(!P)miss('limits (from a to b) or a polynomial integrand');const A={};for(const p in P)A[+p+1]=P[p]/(+p+1);return R([['∫ f dx',ps(A)+' + C','']],['Power rule: ∫xⁿ dx = xⁿ⁺¹/(n+1)'],[pv(dp(A),.7),pv(P,.7),'differentiating the result returns f(x)'])}
  const a=num(bm[1]),b=num(bm[2]);if(!isFinite(a)||!isFinite(b))bad('could not read the limits');const v=simpson(f,a,b,2000);if(!isFinite(v))bad('the function is not finite on the interval');
  let alt=simpson(f,a,b,6000),st=['∫ '+ex.trim()+' dx from '+sg(a)+' to '+sg(b)+' (adaptive Simpson, 2000 panels)'];
  if(P){const A={};for(const p in P)A[+p+1]=P[p]/(+p+1);alt=pv(A,b)-pv(A,a);st=['Antiderivative F(x) = '+ps(A),'F('+sg(b)+') − F('+sg(a)+') = '+sg(alt)]}
  return R([['integral',P?alt:v,'']],st,[v,alt,P?'exact antiderivative vs numeric Simpson':'Simpson with 2000 vs 6000 panels'],'',0)}
 const tm=q.t.match(/(?:→|->|tends?\s+to|approaches|towards|\bto\b)\s*(-?[\dπ.\/pi*]+|-?∞|-?infinity|-?inf)/i);if(!tm)miss('the limit point (x → a)');
 let L,Rr,L2,R2,inf=/∞|inf/i.test(tm[1]);if(inf){const s=/^-/.test(tm[1])?-1:1;L=Rr=f(s*1e6);L2=R2=f(s*1e7)}else{const a=num(tm[1]);L=f(a-1e-6);Rr=f(a+1e-6);L2=f(a-1e-7);R2=f(a+1e-7)}
 if(![L,Rr,L2,R2].every(isFinite)||Math.abs(Rr)>1e7)bad('the expression is undefined or diverges (→ ±∞) at that point');
 if(!close(L,Rr,1e-4)||!close(L2,R2,1e-4))bad('left-hand limit ('+sg(L)+') and right-hand limit ('+sg(Rr)+') differ, so the limit does not exist');
 const v=Math.abs((L+Rr)/2-Math.round((L+Rr)/2))<1e-5?Math.round((L+Rr)/2):(L+Rr)/2;return R([['limit',v,'']],['Evaluate f(x) just left and right of the point (±1e-6)','Left = '+sg(L,6)+', right = '+sg(Rr,6)],[L,Rr,'left and right limits agree',1e-4],'',0)});
T('polynomial equation',/=/,q=>{
 if(!/solve|roots?|zeros?|equation|quadratic|find (?:the )?values? of x/.test(q.l))skip();
 if(/sin|cos|tan|\blog|\bln|exp|sqrt/.test(q.l))skip();const m=q.t.match(/([-+\dx^².*\s\/]+?)=([-+\dx^².*\s\/]+)/);if(!m||!/x/i.test(m[1]+m[2]))skip();
 const A=pp(m[1]),B=pp(m[2]);if(!A||!B)skip();const c={};for(const p in A)c[p]=(c[p]||0)+A[p];for(const p in B)c[p]=(c[p]||0)-B[p];
 const deg=Math.max(...Object.keys(c).filter(p=>Math.abs(c[p])>1e-12).map(Number));if(deg<1)bad('the equation reduces to a constant');
 const a=c[deg],st=['Rearranged: '+ps(c)+' = 0 (degree '+deg+')'];let roots=[],chk;
 if(deg==1){roots=[-(c[0]||0)/a];chk=[pv(c,roots[0]),0,'substituting x back gives 0']}
 else if(deg==2){const b=c[1]||0,k=c[0]||0,D=b*b-4*a*k;st.push('Discriminant D = b² − 4ac = '+sg(D));
  if(D<0){const re=-b/(2*a),im=Math.sqrt(-D)/(2*a);return R([['x',sg(re)+' ± '+sg(Math.abs(im))+'i','']],st.concat('D < 0 → complex conjugate roots'),[re*2,-b/a,'sum of roots = −b/a'])}
  roots=[(-b-Math.sqrt(D))/(2*a),(-b+Math.sqrt(D))/(2*a)].sort((x,y)=>x-y);st.push('x = (−b ± √D)/2a');
  if(q.a(/sum/))st.push('Sum of roots = −b/a = '+sg(-b/a));if(q.a(/product/))st.push('Product of roots = c/a = '+sg(k/a));
  chk=[roots[0]+roots[1],-b/a,'Vieta: sum of roots = −b/a; product = '+sg(roots[0]*roots[1])+' vs c/a = '+sg(k/a)];if(!close(roots[0]*roots[1],k/a,1e-9))bad('Vieta product check failed')}
 else{for(let x=-60,y=pv(c,x);x<60;x+=.01){const x2=x+.01,y2=pv(c,x2);if(y===0)roots.push(x);else if(y*y2<0){let lo=x,hi=x2;for(let i=0;i<80;i++){const md=(lo+hi)/2;pv(c,lo)*pv(c,md)<=0?hi=md:lo=md}roots.push((lo+hi)/2)}y=y2}
  if(!roots.length)bad('no real roots found in [−60, 60]');roots=roots.map(r=>+r.toFixed(9));chk=[Math.max(...roots.map(r=>Math.abs(pv(c,r)))),0,'p(root) ≈ 0 for every real root found',1e-6]}
 return R(roots.map((r,i)=>['x'+(roots.length>1?'₁₂₃₄₅'[i]:''),+r.toFixed(10),'']),st,chk)});
T('equation solving',/solve|find (?:all )?(?:the )?(?:solutions?|values? of x)/,q=>{
 let eq=q.t.replace(/^.*?solve\s*(?:the equation)?\s*/i,'').split(/\s+(?:for|in|on|where|when|if|between)\b|,|\?/)[0];if(!/=/.test(eq)||!/x/.test(eq))skip();
 const [L,Rh]=eq.split('=').map(norm),deg=/°|degree/.test(q.t),trig=/sin|cos|tan/.test(L+Rh);let lo=-20,hi=20;if(trig)[lo,hi]=deg?[0,360]:[0,2*PI];
 const im=q.t.match(/(-?[\dπ.\/*pi]+)\s*°?\s*(?:≤|<=|<)\s*x\s*(?:≤|<=|<)\s*(-?[\dπ.\/*pi]+)/)||q.t.match(/\[\s*([^,\]]+?)\s*,\s*([^\]]+?)\s*\]/);if(im){lo=num(im[1]);hi=num(im[2])}
 const f=x=>{const v=deg?x*PI/180:x;return fx(L,v)-fx(Rh,v)},rs=[],N=6000,h=(hi-lo)/N;
 for(let i=0;i<N;i++){const a=lo+i*h,b=a+h,fa=f(a),fb=f(b);if(!isFinite(fa)||!isFinite(fb))continue;if(fa*fb<0){let x0=a,x1=b;for(let k=0;k<70;k++){const m=(x0+x1)/2;f(x0)*f(m)<=0?x1=m:x0=m}const r=(x0+x1)/2;if(Math.abs(f(r))<1e-6&&!rs.some(y=>Math.abs(y-r)<1e-6))rs.push(r)}}
 if(!rs.length)bad('no solution found in ['+sg(lo)+', '+sg(hi)+']');const un=deg?'°':'rad';
 return R(rs.map((r,i)=>['x'+(rs.length>1?(i+1):''),+r.toFixed(8),un]),['Equation: '+eq.trim()+'  on ['+sg(lo)+', '+sg(hi)+'] '+un,'Scan for sign changes, refine each root by bisection'].concat(deg?[]:rs.map(r=>piFrac(r)?'x = '+piFrac(r):'').filter(Boolean)),[Math.max(...rs.map(r=>Math.abs(f(r)))),0,'LHS − RHS ≈ 0 at every root',1e-6])});
T('trigonometric value',/\b(?:sin|cos|tan)\b/,q=>{
 if(!/°|degree/.test(q.t)||/x/.test(q.t.replace(/\bexp\b/g,'')))skip();let b=q.t.replace(/^.*?(?:evaluate|calculate|compute|find the value of|value of|simplify|find)\s*/i,'').replace(/[.?]\s*$/,'');
 const v1=num(b),b2=b.replace(/\s*(?:°|degrees?)/g,'').replace(/\b(sin|cos|tan)\b/g,'$1d');fnInit();let v2;try{v2=Calc.run(norm(b2))}catch(_){v2=NaN}
 if(!isFinite(v1))skip();return R([['value',Math.abs(v1-Math.round(v1))<1e-12?Math.round(v1):v1,'']],['Expression: '+b.trim(),'Degrees converted to radians (×π/180)'],[v1,v2,'radian route vs degree-function route'],'',0)});
T('binomial / counting',/binomial|expansion|coefficient of x|general term|independent of x|constant term|\bn\s?c\s?r\b|\bncr\b|\bnpr\b|combination|permutation|ways|choose|chosen|arrange/,q=>{
 const bm=q.t.match(/\(([^()]+)\)\s*\^\s*(\d+)/);
 if(bm&&/coefficient|term|expansion/.test(q.l)){const inner=bm[1].replace(/\s+/g,''),n=+bm[2];let i=1;for(;i<inner.length;i++)if((inner[i]=='+'||inner[i]=='-')&&inner[i-1]!='^'&&inner[i-1]!='(')break;
  const A=mono(inner.slice(0,i)),B=mono(inner.slice(i));if(!A||!B)miss('a two-term bracket such as (x^2 + 1/x)^6');
  const km=q.l.match(/coefficient of x\^?\(?(-?\d+)\)?/),k=/independent of x|constant term/.test(q.l)?0:km?+km[1]:/coefficient of x/.test(q.l)?1:undefined;if(k===undefined)miss('which power of x (e.g. "coefficient of x^3")');
  if(A.p==B.p)bad('both terms have the same power of x');const r=(k-A.p*n)/(B.p-A.p),st=['General term T(r+1) = C('+n+',r)·A^('+n+'−r)·B^r with A = '+sg(A.c)+(A.p?'x^'+A.p:'')+', B = '+sg(B.c)+(B.p?'x^'+B.p:'')];
  let co=0;if(Number.isInteger(r)&&r>=0&&r<=n){co=Cb(n,r)*A.c**(n-r)*B.c**r;st.push('Power of x: '+A.p+'('+n+'−r) + '+B.p+'r = '+k+' → r = '+r,'Coefficient = C('+n+','+r+')·'+sg(A.c)+'^'+(n-r)+'·'+sg(B.c)+'^'+r+' = '+sg(co,8))}else st.push('r = '+sg(r)+' is not an integer in [0,'+n+'], so x^'+k+' does not occur');
  let M={0:{}};M={};M[A.p]=A.c;M[B.p]=(M[B.p]||0)+B.c;let E={0:1};for(let j=0;j<n;j++){const N2={};for(const e in E)for(const p in M)N2[+e+ +p]=(N2[+e+ +p]||0)+E[e]*M[p];E=N2}
  return R([['coefficient of x^'+k,co,'']],st,[co,E[k]||0,'full expansion by repeated multiplication'])}
 if(!/choose|chosen|select|combination|permutation|ways|arrange|\bn?c\s?r\b|\bn?p\s?r\b|\d\s*[cp]\s*\d/.test(q.l))skip();const ns=(q.l.match(/\d+/g)||[]).map(Number);if(/\bn?c\s?\d/.test(q.l)){}
 const cm=q.l.match(/(\d+)\s*c\s*(\d+)/),pm=q.l.match(/(\d+)\s*p\s*(\d+)/);let n,r,perm=/permutation|arrange|npr|\bp\b/.test(q.l)&&!/choose|select|combination|ncr/.test(q.l);
 if(cm){n=+cm[1];r=+cm[2];perm=false}else if(pm){n=+pm[1];r=+pm[2];perm=true}else if(ns.length>=2){n=Math.max(ns[0],ns[1]);r=Math.min(ns[0],ns[1])}else if(ns.length==1&&perm){n=ns[0];r=n}else miss('the two numbers n and r');
 if(r>n)bad('r cannot exceed n');let v=1;for(let i=0;i<r;i++)v*=n-i;if(!perm){for(let i=2;i<=r;i++)v/=i;v=Math.round(v)}
 let alt;if(perm){alt=1;for(let i=n-r+1;i<=n;i++)alt*=i}else{const row=[1];for(let i=1;i<=n;i++)for(let j=i;j>=1;j--)row[j]=(row[j]||0)+row[j-1];alt=row[r]}
 return R([[perm?'P('+n+','+r+')':'C('+n+','+r+')',v,'']],[perm?'P(n,r) = n!/(n−r)!':'C(n,r) = n!/(r!(n−r)!)'],[v,alt,perm?'falling factorial vs direct product':'formula vs Pascal triangle'])});
T('probability',/probab|chance|likel/,q=>{
 const W=['one','two','three','four','five','six','seven','eight','nine','ten'],l=q.l.replace(/\b(one|two|three|four|five|six|seven|eight|nine|ten)\b/g,w=>W.indexOf(w)+1),fr=(p,n)=>{const g=gcd(p,n);return p/g+'/'+n/g};
 let dm=l.match(/(\d+)\s+dice/)||(/\bdie\b|\bdice\b/.test(l)?[0,1]:null);
 if(dm){const nd=+dm[1],sm=l.match(/sum\s*(?:is|of|equals|=)?\s*(?:at least|at most)?\s*(\d+)/);if(!sm)miss('the required sum');const s=+sm[1],mode=/at least/.test(l)?1:/at most/.test(l)?-1:0;let ok=0,tot=0;
  const rec=(k,sum)=>{if(k==0){tot++;if(mode==0?sum==s:mode>0?sum>=s:sum<=s)ok++;return}for(let f=1;f<=6;f++)rec(k-1,sum+f)};rec(nd,0);
  let dp={0:1};for(let i=0;i<nd;i++){const N2={};for(const a in dp)for(let f=1;f<=6;f++)N2[+a+f]=(N2[+a+f]||0)+dp[a];dp=N2}let ok2=0;for(const a in dp)if(mode==0?+a==s:mode>0?+a>=s:+a<=s)ok2+=dp[a];
  return R([['probability ('+fr(ok,tot)+')',ok/tot,'']],['Total outcomes = 6^'+nd+' = '+tot,'Favourable outcomes = '+ok],[ok/tot,ok2/tot,'enumeration vs convolution of dice distributions'])}
 if(/coin|toss|flip/.test(l)){const nm=l.match(/(\d+)\s*(?:times|tosses|coins?|flips)|(?:tossed|flipped)\s+(\d+)/),n=nm?+(nm[1]||nm[2]):undefined;if(n===undefined)miss('the number of tosses');
  const jm=l.match(/(?:exactly\s+)?(\d+)\s+heads?/);if(!jm)miss('the required number of heads');const j=+jm[1],al=/at least/.test(l),am=/at most/.test(l);let p=0;for(let i=0;i<=n;i++)if(al?i>=j:am?i<=j:i==j)p+=Cb(n,i);p/=2**n;
  const memo={},pr=(n,j)=>n==0?(j==0?1:0):j<0?0:.5*pr(n-1,j-1)+.5*pr(n-1,j);let p2=0;for(let i=0;i<=n;i++)if(al?i>=j:am?i<=j:i==j)p2+=pr(n,i);
  return R([['probability ('+fr(Math.round(p*2**n),2**n)+')',p,'']],['Binomial: P = C('+n+',k)/2^'+n+' summed over the required k'],[p,p2,'binomial formula vs recursive coin model'])}
 const sent=l.split(/\.\s/)[0],pairs=[...sent.matchAll(/(\d+)\s+([a-z]+)/g)].filter(x=>!/^(balls?|marbles?|cards?|are|is|of|in|from|drawn|and|identical)$/.test(x[2])),cnt={};pairs.forEach(x=>cnt[x[2]]=+x[1]);
 const col=Object.keys(cnt).find(c=>q.ask.includes(c));if(!pairs.length||!col)miss('the contents (e.g. "3 red and 5 blue balls") and the colour asked');
 const km=l.match(/(\d+)\s+(?:balls?|marbles?|cards?)\s+(?:are\s+)?(?:drawn|selected|picked|taken|chosen)|(?:draw|drawn|select|pick)\s+(\d+)/);if(!km)miss('how many are drawn');const k=+(km[1]||km[2]),N=Object.values(cnt).reduce((a,b)=>a+b,0),c=cnt[col],rep=/with replacement|replaced|put back/.test(l)&&!/without/.test(l);
 if(k>N&&!rep)bad('cannot draw more items than the bag holds');const em=l.match(/exactly\s+(\d+)/),atl=l.match(/at least\s+(\d+|one)/),j=em?+em[1]:atl?(atl[1]=='one'?1:+atl[1]):k;let p=0;
 for(let i=0;i<=k;i++)if(em?i==j:atl?i>=j:i==j)p+=rep?Cb(k,i)*(c/N)**i*(1-c/N)**(k-i):Cb(c,i)*Cb(N-c,k-i)/Cb(N,k);
 const dfs=(ct,n,left,got)=>left==0?got:(ct/n)*dfs(rep?ct:ct-1,rep?n:n-1,left-1,got+1)+((n-ct)/n)*dfs(ct,rep?n:n-1,left-1,got);
 let p2=0;const dd=(ct,n,left,got)=>{if(left==0)return(em?got==j:atl?got>=j:got==j)?1:0;return(ct/n)*dd(rep?ct:ct-1,rep?n:n-1,left-1,got+1)+((n-ct)/n)*dd(ct,rep?n:n-1,left-1,got)};p2=dd(c,N,k,0);
 return R([['probability'+(!rep&&Number.isInteger(p*Cb(N,k))?' ('+fr(Math.round(p*Cb(N,k)),Cb(N,k))+')':''),p,'']],['Bag: '+Object.entries(cnt).map(x=>x[1]+' '+x[0]).join(', ')+' (N = '+N+'); draw '+k+(rep?' with':' without')+' replacement','Hypergeometric/binomial count of favourable draws'],[p,p2,'counting formula vs sequential-draw tree'])});
T('vectors',/vector|\d[ijk]\b|dot product|cross product/,q=>{
 const vs=[],re=/(?<![A-Za-z])(?:[+-]?\s*\d*\.?\d*\s*[ijk]\b)(?:\s*[+-]\s*\d*\.?\d*\s*[ijk]\b)*/g;let m;
 while((m=re.exec(q.t))){const v=[0,0,0];m[0].replace(/([+-]?)\s*(\d*\.?\d*)\s*([ijk])/g,(a,s,c,ax)=>{v['ijk'.indexOf(ax)]+=(s=='-'?-1:1)*(c===''?1:+c)});vs.push(v)}
 if(!vs.length){const r2=/[(<\[]\s*(-?[\d.]+)\s*,\s*(-?[\d.]+)(?:\s*,\s*(-?[\d.]+))?\s*[)>\]]/g;while((m=r2.exec(q.t)))vs.push([+m[1],+m[2],+(m[3]||0)])}
 if(!vs.length)skip();const X=q.pick({ang:/angle/,dot:/dot|scalar/,cr:/cross|vector product|area/,pr:/projection|component/,mg:/magnitude|length|modulus|unit/}),two=X&&X!='mg';
 if(two&&vs.length<2)miss('two vectors');const[a,b]=vs,dot=(x,y)=>x[0]*y[0]+x[1]*y[1]+x[2]*y[2],mg=x=>Math.sqrt(dot(x,x)),cr=(x,y)=>[x[1]*y[2]-x[2]*y[1],x[2]*y[0]-x[0]*y[2],x[0]*y[1]-x[1]*y[0]];
 const fv=v=>'('+v.map(x=>sg(x)).join(', ')+')',st=['a = '+fv(a)+(b?', b = '+fv(b):'')];
 if(!X)miss('what to find (angle, dot product, cross product, magnitude…)');
 if(X=='mg'){st.push('|a| = √(a·a)');return R([['|a|',mg(a),'']],st,[mg(a)**2,dot(a,a),'|a|² equals a·a'])}
 const d=dot(a,b),c=cr(a,b),ma=mg(a),mb=mg(b),lag=close(mg(c)**2+d*d,ma*ma*mb*mb,1e-9);if(!lag)bad('Lagrange identity check failed');
 if(X=='dot'){st.push('a·b = Σ aᵢbᵢ');return R([['a·b',d,'']],st,[mg(c)**2+d*d,ma*ma*mb*mb,'Lagrange identity |a×b|² + (a·b)² = |a|²|b|²'])}
 if(X=='cr'){st.push('a×b = '+fv(c),'Parallelogram area = |a×b| = '+sg(mg(c)));return R([['a×b',fv(c),''],['|a×b|',mg(c),'']],st,[mg(c)**2+d*d,ma*ma*mb*mb,'Lagrange identity'])}
 if(X=='pr'){const p=d/mb;st.push('Scalar projection of a on b = a·b/|b|');return R([['projection',p,'']],st,[p*mb,d,'projection × |b| returns a·b'])}
 const th=Math.acos(Math.max(-1,Math.min(1,d/(ma*mb))))*180/PI,th2=Math.atan2(mg(c),d)*180/PI;st.push('cosθ = a·b/(|a||b|) = '+sg(d)+'/('+sg(ma)+'×'+sg(mb)+') = '+sg(d/(ma*mb),5));
 return R([['angle',th,'°']],st,[th,th2,'arccos route vs arctan(|a×b|, a·b) route'])});
T('sequences',/\bap\b|a\.p|\bgp\b|g\.p|arithmetic|geometric|progression|series/,q=>{
 const lm=q.t.match(/-?\d+(?:\.\d+)?(?:\s*,\s*-?\d+(?:\.\d+)?){2,}/);if(!lm)miss('the first few terms, e.g. "3, 7, 11, …"');
 const s=lm[0].split(',').map(Number),d=s[1]-s[0],r=s[1]/s[0],ap=s.every((x,i)=>i==0||close(x-s[i-1],d,1e-9)),gp=s[0]!=0&&s.every((x,i)=>i==0||close(x/s[i-1],r,1e-9));
 if(!ap&&!gp)bad('the terms are neither an AP nor a GP');const isG=/geometric|\bgp\b|g\.p/.test(q.l)?true:/arithmetic|\bap\b|a\.p/.test(q.l)?false:(!ap&&gp);
 if(isG&&!gp)bad('the terms are not a GP');if(!isG&&!ap)bad('the terms are not an AP');
 const nm=q.l.match(/first\s+(\d+)\s+terms?|(\d+)\s+terms?|\bn\s*=\s*(\d+)/),tm=q.l.match(/(\d+)(?:st|nd|rd|th)\s+term/),a=s[0];
 if(/infinit/.test(q.l)){if(!isG||Math.abs(r)>=1)bad('an infinite sum needs a GP with |r| < 1');const v=a/(1-r);return R([['S∞',v,'']],['S∞ = a/(1−r), a = '+a+', r = '+sg(r)],[v,s.length?a*(1-r**200)/(1-r):0,'closed form vs 200-term partial sum'])}
 const askN=q.a(/sum/)||!tm,n=askN?(nm?+(nm[1]||nm[2]||nm[3]):undefined):+tm[1];if(n===undefined)miss('the number of terms n');
 if(askN&&q.a(/sum|series/)||(!tm&&!q.a(/term/))){let v,it=0,t0=a;for(let i=0;i<n;i++){it+=t0;t0=isG?t0*r:t0+d}v=isG?(close(r,1)?a*n:a*(r**n-1)/(r-1)):n/2*(2*a+(n-1)*d);
  return R([['S'+n,v,'']],[(isG?'GP':'AP')+': a = '+sg(a)+', '+(isG?'r = '+sg(r):'d = '+sg(d)),isG?'Sₙ = a(rⁿ−1)/(r−1)':'Sₙ = n/2·[2a + (n−1)d]'],[v,it,'formula vs adding the terms one by one'])}
 const v=isG?a*r**(n-1):a+(n-1)*d;let t0=a;for(let i=1;i<n;i++)t0=isG?t0*r:t0+d;return R([['T'+n,v,'']],[(isG?'GP':'AP')+' nth term: '+(isG?'aʳⁿ⁻¹':'a + (n−1)d')],[v,t0,'formula vs iterating the sequence'])});
/* ---------- physics ---------- */
T('free fall',/free(?:ly)? fall|dropped|drop(?:s|ped)? from|falls? from|released from rest|thrown (?:vertically )?up|projected (?:vertically )?up|vertically upward/,q=>{
 const g=q.gv;if(/thrown|projected|upward/.test(q.l)){const u=q.g('V');if(u===undefined)miss('the launch speed');const H=u*u/(2*g),tf=2*u/g,X=q.pick({T:/time|duration|how long/,H:/height|highest|maximum/})||'H';
  return R(X=='T'?[['time of flight',tf,'s']]:[['maximum height',H,'m']],['Rising to rest: v² = u² − 2gh → h = u²/2g','Time of flight = 2u/g'],[H,u*(tf/2)-.5*g*(tf/2)**2,'height from v²=u²−2gh vs from s = ut − ½gt²'],'',1)}
 const h=q.g('L');if(h===undefined)miss('the height');const t=Math.sqrt(2*h/g),v=g*t,X=q.pick({T:/time|how long/,V:/speed|velocity|how fast/})||'T';
 return R(X=='T'?[['time',t,'s']]:[['speed on landing',Math.sqrt(2*g*h),'m/s']],['From rest: h = ½gt² → t = √(2h/g)','v = gt = √(2gh)'],[v,Math.sqrt(2*g*h),'v = gt vs v = √(2gh)'],'',1)});
T('projectile motion',/projectile|launched|angle of projection|at an angle|thrown at|fired at|projected at/,q=>{
 const u=q.g('V'),th=q.g('ang'),g=q.gv;if(u===undefined)miss('the launch speed');if(th===undefined)miss('the launch angle');
 const Rn=u*u*Math.sin(2*th)/g,H=Math.pow(u*Math.sin(th),2)/(2*g),Tf=2*u*Math.sin(th)/g,X=q.pick({R:/range|how far|horizontal distance/,H:/height|highest/,T:/time|duration|flight/})||'R';
 return R(X=='R'?[['range',Rn,'m']]:X=='H'?[['maximum height',H,'m']]:[['time of flight',Tf,'s']],['R = u²sin2θ/g, H = u²sin²θ/2g, T = 2u sinθ/g','θ = '+sg(th*180/PI)+'°'],[Rn,u*Math.cos(th)*Tf,'range from formula vs horizontal speed × time of flight'],'',1)});
T('inclined plane',/incline|slope|inclined plane|rough plane|smooth plane/,q=>{
 const th=q.g('ang');if(th===undefined)miss('the incline angle');const mu=+((q.l.match(/(?:coefficient of (?:kinetic |static )?friction|μ|mu)\s*(?:=|is|of)?\s*(\d*\.?\d+)/)||[0,0])[1]),g=q.gv,a=g*(Math.sin(th)-mu*Math.cos(th));
 const st=['Along the plane: ma = mg sinθ − μ mg cosθ → a = g(sinθ − μ cosθ)'];if(a<=0)return R([['acceleration',0,'m/s²']],st.concat('μ ≥ tanθ, so friction holds the block: it does not slide'),[0,0,'static equilibrium'],'',1);
 const L=q.g('L'),X=q.pick({T:/time/,V:/speed|velocity/});if(L!==undefined&&X=='T')return R([['time',Math.sqrt(2*L/a),'s']],st,[L,.5*a*(2*L/a),'s = ½at²'],'',1);
 return R([['acceleration',a,'m/s²']],st,[a*1,(g*Math.sin(th)*1)-mu*g*Math.cos(th),'net force per unit mass'],'',1)});
T('oscillations',/time period|period of|oscillat|simple pendulum|spring/,q=>{
 const m=q.g('M'),k=q.g('k'),L=q.g('L'),g=q.gv;let Tp,st;
 if(/pendulum/.test(q.l)){if(L===undefined)miss('the pendulum length');Tp=2*PI*Math.sqrt(L/g);st=['T = 2π√(l/g)']}else{if(m===undefined||k===undefined)miss('mass and spring constant');Tp=2*PI*Math.sqrt(m/k);st=['T = 2π√(m/k)']}
 const f=q.a(/frequency/);return R(f?[['frequency',1/Tp,'Hz']]:[['time period',Tp,'s']],st,[Tp,2*PI/(/pendulum/.test(q.l)?Math.sqrt(g/L):Math.sqrt(k/m)),'T = 2π/ω'],'',/pendulum/.test(q.l))});
T('magnetic force',/magnetic|tesla|cyclotron|lorentz/,q=>{
 const P={proton:[1.6726e-27,1.602e-19],electron:[9.109e-31,1.602e-19],alpha:[6.645e-27,3.204e-19]},pn=Object.keys(P).find(x=>q.l.includes(x));
 let m=pn?P[pn][0]:q.g('M'),qq=pn?P[pn][1]:q.g('Q');const v=q.g('V'),B=q.g('B');if(v===undefined||B===undefined||m===undefined||qq===undefined)miss('particle (proton/electron/α or mass & charge), speed and B');qq=Math.abs(qq);
 const th=/perpendicular|circular/.test(q.l)?PI/2:(q.g('ang')??PI/2),F=qq*v*B*Math.sin(th),r=m*v*Math.sin(th)/(qq*B),Tp=2*PI*m/(qq*B),X=q.pick({r:/radius|circular|path/,T:/period/,F:/force/})||'F';
 return R(X=='r'?[['radius',r,'m']]:X=='T'?[['time period',Tp,'s']]:[['force',F,'N']],['F = qvB sinθ (θ = '+sg(th*180/PI)+'°)','Circular motion: mv²/r = qvB → r = mv/(qB)'+(pn?'  ('+pn+': m = '+m+' kg, q = '+qq+' C)':'')],[Tp,2*PI*r/(v*Math.sin(th)),'T = 2πm/qB vs T = 2πr/v⊥'],'',0)});
T('Coulomb force',/coulomb|point charges?|electrostatic|charges? of|force between/,q=>{
 const Qs=q.all('Q'),r=q.g('L');if(Qs.length<2)miss('two charges');if(r===undefined)miss('the separation');const F=8.9875e9*Math.abs(Qs[0]*Qs[1])/(r*r),e0=8.854e-12,F2=Math.abs(Qs[0]*Qs[1])/(4*PI*e0*r*r);
 return R([['force',F,'N']],['F = kq₁q₂/r², k = 8.99×10⁹ N·m²/C²',Qs[0]*Qs[1]<0?'Opposite charges → attractive':'Like charges → repulsive'],[F,F2,'k·q₁q₂/r² vs q₁q₂/(4πε₀r²)',2e-3])});
T('capacitor',/capacitor|capacitance/,q=>{
 const C=q.g('Cap'),V=q.g('Vo'),Qc=q.g('Q'),X=q.pick({U:/energy/,Q:/charge/,C:/capacitance/,V:/voltage|potential/})||'U';let c=C,v=V,qq=Qc;
 if(c!==undefined&&v!==undefined)qq=c*v;else if(c!==undefined&&qq!==undefined)v=qq/c;else if(v!==undefined&&qq!==undefined)c=qq/v;else miss('two of C, V, Q');
 const Ue=.5*c*v*v;return R(X=='U'?[['energy',Ue,'J']]:X=='Q'?[['charge',qq,'C']]:X=='C'?[['capacitance',c,'F']]:[['voltage',v,'V']],['Q = CV, U = ½CV² = ½QV = Q²/2C'],[Ue,qq*qq/(2*c),'½CV² vs Q²/2C'])});
T('circuits',/resistor|resistance|ohm|ω|circuit|battery|current|voltage|potential difference/,q=>{
 const Rs=q.all('R'),V=q.g('Vo'),I=q.g('I');
 if(Rs.length>=2&&/series|parallel/.test(q.l)){const par=/parallel/.test(q.l)&&!/series/.test(q.l),Rt=par?1/Rs.reduce((a,b)=>a+1/b,0):Rs.reduce((a,b)=>a+b,0),alt=par?(Rs.length==2?Rs[0]*Rs[1]/(Rs[0]+Rs[1]):1/Rs.reduce((a,b)=>a+1/b,0)):Rs.reduceRight((a,b)=>a+b,0);
  const st=[par?'1/R = Σ 1/Rᵢ':'R = Σ Rᵢ'],ans=[['equivalent resistance',Rt,'Ω']];if(V!==undefined&&q.a(/current/)){ans.splice(0,1,['current',V/Rt,'A']);st.push('I = V/R = '+sg(V)+'/'+sg(Rt))}
  return R(ans,st,[Rt,alt,par?'reciprocal sum vs product/sum':'two summation orders'])}
 const R1=Rs.length==1?Rs[0]:undefined,X=q.pick({I:/current/,R:/resistance/,V:/voltage|potential|emf/,P:/power|heat/});if(!X)skip();
 if(R1!==undefined&&V!==undefined&&I!==undefined&&!close(V,I*R1,1e-3))bad('V, I and R are inconsistent: I·R = '+sg(I*R1)+' V but V = '+sg(V)+' V');
 let v=V,i=I,r=R1;if(X=='I'){if(v===undefined||r===undefined)miss('V and R');i=v/r}else if(X=='R'){if(v===undefined||i===undefined)miss('V and I');r=v/i}else if(X=='V'){if(i===undefined||r===undefined)miss('I and R');v=i*r}
 else{if(v!==undefined&&i===undefined&&r!==undefined)i=v/r;if(v===undefined&&i!==undefined&&r!==undefined)v=i*r;if(v===undefined||i===undefined)miss('two of V, I, R')}
 const P2=v*i;return R(X=='I'?[['current',i,'A']]:X=='R'?[['resistance',r,'Ω']]:X=='V'?[['voltage',v,'V']]:[['power',P2,'W']],['Ohm\'s law V = IR; P = VI'],[P2,r!==undefined?i*i*r:P2,'P = VI vs P = I²R'])});
T('circular motion',/circular|centripetal|revolv|whirled/,q=>{const m=q.g('M'),v=q.g('V'),r=q.g('L');if(m===undefined||v===undefined||r===undefined)miss('mass, speed and radius');const F=m*v*v/r;
 return R(q.a(/acceleration/)?[['centripetal acceleration',v*v/r,'m/s²']]:[['centripetal force',F,'N']],['F = mv²/r, a = v²/r'],[F,m*(v/r)**2*r,'mv²/r vs mω²r with ω = v/r'])});
T('work & energy',/kinetic energy|potential energy|work done|\bwork\b|\bpower\b/,q=>{
 const X=q.pick({KE:/kinetic/,PE:/potential/,W:/\bwork\b/,Pw:/\bpower\b/});if(!X)skip();const m=q.g('M'),v=q.g('V'),g=q.gv;
 if(X=='KE'){if(m===undefined||v===undefined)miss('mass and speed');const K=.5*m*v*v;return R([['kinetic energy',K,'J']],['KE = ½mv²'],[K,m*v*v/2,'½mv² vs p²/2m with p = mv'.length?(m*v)**2/(2*m):0])}
 if(X=='PE'){const h=q.g('L');if(m===undefined||h===undefined)miss('mass and height');return R([['potential energy',m*g*h,'J']],['PE = mgh'],[m*g*h,m*h*g,'mgh'],'',1)}
 if(X=='W'){const F=q.g('F'),d=q.g('L'),th=q.g('ang')??0;if(F===undefined||d===undefined)miss('force and displacement');const W=F*d*Math.cos(th);return R([['work',W,'J']],['W = Fd cosθ'+(th?', θ = '+sg(th*180/PI)+'°':'')],[W,F*Math.cos(th)*d,'F cosθ × d'])}
 const W=q.g('E'),t=q.g('T'),F=q.g('F'),d=q.g('L');if(W!==undefined&&t!==undefined)return R([['power',W/t,'W']],['P = W/t'],[W/t,W*(1/t),'W/t']);if(F!==undefined&&v!==undefined)return R([['power',F*v,'W']],['P = Fv'],[F*v,v*F,'Fv']);miss('work and time, or force and speed')});
T('Newton\'s second law',/force|accelerat|mass|newton/,q=>{
 const X=q.pick({F:/force/,a:/accelerat/,m:/\bmass\b/});if(!X)skip();let m=q.g('M'),F=q.g('F'),a=q.g('A');if(m===undefined&&F===undefined)skip();
 if(a===undefined&&q.all('T').length==1&&q.all('V').length){const u=/from rest/.test(q.l)?0:q.all('V')[0],v=/from rest/.test(q.l)?q.all('V')[0]:q.all('V')[1];if(v!==undefined)a=(v-u)/q.all('T')[0]}
 if(X=='F'){if(m===undefined||a===undefined)miss('mass and acceleration');F=m*a}else if(X=='a'){if(m===undefined||F===undefined)miss('mass and force');a=F/m}else{if(F===undefined||a===undefined)miss('force and acceleration');m=F/a}
 return R(X=='F'?[['force',F,'N']]:X=='a'?[['acceleration',a,'m/s²']]:[['mass',m,'kg']],['F = ma'],[F,m*a,'F = ma recomputed'])});
/* ---------- chemistry ---------- */
const kv=(l,n)=>{let m=l.match(new RegExp('\\b'+n+'\\s*(?:=|of|is|value)?\\s*(\\d+\\.?\\d*)(?:\\s*(?:e\\s*([+-]?\\d+)|[x×*]\\s*10\\s*\\^?\\s*\\(?([+-]?\\d+)\\)?))?'));if(m)return+m[1]*10**+(m[2]||m[3]||0);m=l.match(new RegExp('\\bp'+n+'\\s*(?:=|of|is)?\\s*(\\d+\\.?\\d*)'));return m?10**-m[1]:undefined};
const SA={HCl:1,HBr:1,HI:1,HNO3:1,HClO4:1,H2SO4:2},SB={NaOH:1,KOH:1,LiOH:1,'Ca(OH)2':2,'Ba(OH)2':2,'Mg(OH)2':2};
T('ionic equilibrium (pH)',/\bph\b|poh|\[h\+?\]|hydroxide ion|hydrogen ion/,q=>{
 const l=q.l,gm=l.match(/\bph\s*(?:=|is|of|value of)?\s*(\d+\.?\d*)(?![\d.])(?!\s*(?:m\b|mol))/);
 if(gm&&q.a(/\[h|concentration|hydrogen ion/)){const h=10**-gm[1];return R([['[H⁺]',h,'mol/L']],['[H⁺] = 10^(−pH)'],[-Math.log10(h),+gm[1],'pH recovered from [H⁺]'])}
 let c=q.g('Conc');if(c!==undefined)c/=1000;const ka=kv(l,'ka'),kb=kv(l,'kb'),sp=q.fm.find(f=>f in SA||f in SB),st=[];if(c===undefined)miss('the concentration (e.g. 0.01 M)');
 if(ka!==undefined||kb!==undefined){const K=ka??kb,x=(-K+Math.sqrt(K*K+4*K*c))/2,pH=ka!==undefined?-Math.log10(x):14+Math.log10(x);st.push((ka!==undefined?'Weak acid':'Weak base')+': x² + Kx − Kc = 0 (exact quadratic, no approximation)','x = '+sg(x,4)+' mol/L,  degree of dissociation α = '+sg(x/c,3));
  return R([['pH',pH,'']],st,[K,x*x/(c-x),'K recomputed from x²/(c−x)',1e-6])}
 if(!sp)miss('the acid/base (e.g. HCl, NaOH, Ca(OH)2) or its Ka/Kb');const acid=sp in SA,n=acid?SA[sp]:SB[sp],cc=c*n;let x=cc;if(cc<1e-6){x=(cc+Math.sqrt(cc*cc+4e-14))/2;st.push('Very dilute: water\'s own ions matter, so x = (c + √(c²+4Kw))/2')}
 st.push(sp+' is a strong '+(acid?'acid':'base')+' giving '+n+' '+(acid?'H⁺':'OH⁻')+' per formula unit → ['+(acid?'H⁺':'OH⁻')+'] = '+sg(x));const pH=acid?-Math.log10(x):14+Math.log10(x);
 return R([['pH',pH,'']],st.concat('pH + pOH = 14 (25 °C)'),[acid?-Math.log10(x):14-(-Math.log10(x)),pH,'pH via pOH = 14 − pH'])});
T('buffer',/buffer|henderson/,q=>{
 const pk=(()=>{const a=kv(q.l,'ka');if(a)return-Math.log10(a);const m=q.l.match(/pka\s*(?:=|of|is)?\s*(\d+\.?\d*)/);return m?+m[1]:undefined})();if(pk===undefined)miss('pKa or Ka');
 let cs=q.Q.filter(x=>x.d=='Conc'||x.d=='n').map(x=>({v:x.v,c:x.ctx}));if(cs.length<2)miss('concentrations of the acid and its salt');let[acid,salt]=cs;if(/salt|acetate|conjugate|base/.test(acid.c)&&!/salt|acetate|conjugate|base/.test(salt.c))[acid,salt]=[salt,acid];
 const pH=pk+Math.log10(salt.v/acid.v);return R([['pH',pH,'']],['Henderson–Hasselbalch: pH = pKa + log([salt]/[acid])','pKa = '+sg(pk)],[Math.pow(10,pH-pk),salt.v/acid.v,'10^(pH−pKa) equals the salt/acid ratio'])});
const KRE=/(?:rate constant[^0-9]{0,45}?|\bk\s*(?:=|is)\s*)(\d+\.?\d*)(?:\s*(?:e\s*([+-]?\d+)|[x×*]\s*10\s*\^?\s*\(?([+-]?\d+)\)?))?\s*(?:(s|sec|min|h|hr)\s*\^?\s*(?:-1|⁻¹)|per\s*(s|sec|min|h|hr)\b|\/\s*(s|sec|min|h|hr)\b)/;
T('chemical kinetics',/half[- ]?life|first[- ]order|rate constant|radioactiv|decay|t\s*1\/2/,q=>{
 const km=q.l.match(KRE),TU={s:1,sec:1,min:60,h:3600,hr:3600};let k,q2=q;if(km){k=+km[1]*10**+(km[2]||km[3]||0)/TU[km[4]||km[5]||km[6]];q2=mkq(q.t.replace(new RegExp(KRE.source,'i'),' '));q2.gv=q.gv}
 const th=q2.g('T',/half/),el=q2.all('T').find(x=>x!==th);if(k===undefined&&th!==undefined)k=LN2/th;const X=q.pick({k:/rate constant/,h:/half[- ]?life/,t:/how long|time|how many/,N:/remain|left|amount|concentration|how much|mass|fraction|percent/});
 if(k===undefined)miss('the half-life or the rate constant');const half=LN2/k,cm=q.l.match(/(\d+\.?\d*)\s*%\s*(?:of\s*\w+\s*)?(?:is\s*)?(?:complete|reacted|decomposed|consumed|decayed|converted)/),rm=q.l.match(/(?:reduced?|falls?|drops?|decay(?:s|ed)?|becomes?|goes down) to (?:1\/(\d+)|(\d+\.?\d*)\s*%)/);
 const frac=cm?1-cm[1]/100:rm?(rm[1]?1/rm[1]:rm[2]/100):undefined;
 if(X=='k')return R([['rate constant k',k,'s⁻¹']],['k = ln2/t½ = 0.693/t½'],[k*half,LN2,'k·t½ = ln 2']);
 if(X=='h')return R([['half-life',half,'s']],['t½ = ln2/k',half>=120?'= '+sg(half/60)+' min':''].filter(Boolean),[k*half,LN2,'k·t½ = ln 2']);
 if(X=='t'){if(frac===undefined)miss('the fraction remaining (e.g. "reduced to 1/8" or "99% complete")');const t=Math.log(1/frac)/k;return R([['time',t,'s']],['t = (1/k)·ln(N₀/N), N/N₀ = '+sg(frac)],[Math.exp(-k*t),frac,'N/N₀ = e^(−kt)'])}
 if(el===undefined)miss('the elapsed time');const f1=Math.exp(-k*el),f2=Math.pow(2,-el/half),n0=q2.Q.find(x=>['Conc','M','n'].includes(x.d));
 return R(n0?[['amount remaining',n0.num*f1,n0.u],['fraction remaining',f1,'']]:[['fraction remaining',f1,'']],['N = N₀e^(−kt) = N₀·2^(−t/t½)','t/t½ = '+sg(el/half)+' half-lives'],[f1,f2,'e^(−kt) vs 2^(−t/t½)'])});
T('ideal gas',/\bgas\b|ideal gas|\bstp\b|pv\s*=\s*nrt/,q=>{
 let P_=q.g('p'),V=q.g('Vol'),n=q.g('n'),Tk=q.g('K');if(/\bstp\b|standard temperature/.test(q.l)){Tk??=273.15;P_??=101325}
 const fm=q.fm[0],mass=q.g('M');if(n===undefined&&mass!==undefined&&fm)n=mass*1000/mm(fm);const Rg=8.314;
 let X=q.pick({V:/volume/,P:/pressure/,T:/temperature/,n:/moles|number of mol|amount/});if(!X){const ms=[['V',V],['P',P_],['T',Tk],['n',n]].filter(x=>x[1]===undefined);if(ms.length==1)X=ms[0][0]}
 if(!X)miss('which quantity to find');if(X=='V'){if(n===undefined||Tk===undefined||P_===undefined)miss('n, T and P');V=n*Rg*Tk/P_}
 else if(X=='P'){if(n===undefined||Tk===undefined||V===undefined)miss('n, T and V');P_=n*Rg*Tk/V}else if(X=='T'){if(n===undefined||P_===undefined||V===undefined)miss('n, P and V');Tk=P_*V/(n*Rg)}else{if(P_===undefined||V===undefined||Tk===undefined)miss('P, V and T');n=P_*V/(Rg*Tk)}
 return R(X=='V'?[['volume',V*1000,'L']]:X=='P'?[['pressure',P_/101325,'atm']]:X=='T'?[['temperature',Tk,'K']]:[['moles',n,'mol']],['PV = nRT with SI units (Pa, m³, K, R = 8.314 J/mol·K)','P = '+sg(P_)+' Pa, V = '+sg(V)+' m³, n = '+sg(n)+' mol, T = '+sg(Tk)+' K'],[P_*V,n*Rg*Tk,'PV = nRT balances']);
});
T('thermodynamics (ΔG)',/gibbs|spontan|δg|delta g|free energy/,q=>{
 const g=(c)=>{const m=q.l.match(new RegExp('(?:δ|delta\\s*)'+c+'\\s*(?:=|is|of)?\\s*([-+]?\\d+\\.?\\d*)\\s*(kj|j)'));return m?+m[1]*(m[2]=='kj'?1000:1):undefined},H=g('h'),S=g('s'),Tk=q.g('K');
 if(H===undefined||S===undefined)miss('ΔH and ΔS');if(q.a(/temperature/)){const Tc=H/S;return R([['crossover T = ΔH/ΔS',Tc,'K']],['ΔG = 0 at T = ΔH/ΔS'],[H-Tc*S,0,'ΔG = 0 at that temperature',1e-6])}
 if(Tk===undefined)miss('the temperature');const G=H-Tk*S;return R([['ΔG',G/1000,'kJ']],['ΔG = ΔH − TΔS = '+sg(H/1000)+' − '+sg(Tk)+' × '+sg(S/1000)+' kJ','ΔG '+(G<0?'< 0 → spontaneous':'> 0 → non-spontaneous')+' at this T'],[G,H-Tk*S,'recomputed in J'])});
T('moles & molarity',/mole|molarity|molar mass|molar\b|dissolved|solution|grams? of|mass of|molecules/,q=>{
 const fm=q.fm[0];if(!fm)skip();const Mm=mm(fm),mass=q.g('M'),V=q.g('Vol'),nn=q.g('n'),c=q.g('Conc'),X=q.pick({n:/how many moles|number of moles|moles/,M:/molarity|concentration|molar\b/,m:/\bmass|how many grams|grams/,N:/molecules|particles|atoms/});
 let n=nn;if(n===undefined&&mass!==undefined)n=mass*1000/Mm;if(n===undefined&&c!==undefined&&V!==undefined)n=c/1000*(V*1000);if(X=='m'&&n===undefined)miss('moles, or molarity and volume');
 const st=['Molar mass of '+fm+' = '+sg(Mm)+' g/mol'];if(X=='M'){if(n===undefined||V===undefined)miss('moles (or mass) and volume');const Mo=n/(V*1000);return R([['molarity',Mo,'mol/L']],st.concat('n = m/M = '+sg(n)+' mol','Molarity = n/V(L) = '+sg(Mo)),[Mo*V*1000*Mm,mass!==undefined?mass*1000:n*Mm,'mass recovered from molarity × volume × molar mass'])}
 if(X=='m'){const gm=n*Mm;return R([['mass',gm,'g']],st.concat('n = '+sg(n)+' mol → m = nM'),[gm/Mm,n,'n recovered from mass'])}
 if(X=='N'){if(n===undefined)miss('amount in moles or grams');return R([['particles',n*6.022e23,'']],st.concat('N = n × 6.022×10²³'),[n*6.022e23/6.022e23,n,'N/N_A recovers n'])}
 if(n===undefined)miss('mass, or molarity and volume');return R([['moles',n,'mol']],st.concat('n = m/M'),[n*Mm,mass!==undefined?mass*1000:n*Mm,'n × M returns the mass'])});
/* ---------- uniform acceleration (kinematics) ---------- */
T('uniform acceleration',/accelerat|retard|decelerat|brak|from rest|uniform|stops?\b|travel|speed|velocity/,q=>{
 const l=q.l,Vs=q.all('V');let u,v;const rest0=/from rest|starts? (?:from )?rest|initially at rest|released from rest|\bat rest\b/.test(l),stop=/(?:comes?|brought|coming) to (?:a )?(?:rest|halt|stop)|\bstops?\b|stopped/.test(l);
 if(rest0){u=0;if(Vs.length)v=Vs[0]}else if(stop){v=0;if(Vs.length)u=Vs[0]}else if(Vs.length>=2){u=Vs[0];v=Vs[1]}else if(Vs.length==1){if(/final|reaches|attains|acquires|gains/.test(l)&&!/initial/.test(l))v=Vs[0];else u=Vs[0]}
 let a=q.g('A');const t=q.g('T'),s=q.g('L');if(a!==undefined&&/retard|decelerat|brak/.test(l)&&a>0)a=-a;
 const K={u,v,a,t,s},D=x=>x!==undefined,have=Object.keys(K).filter(k=>D(K[k]));if(have.length<3)miss('at least three of: initial speed, final speed, acceleration, time, distance (found '+(have.length?have.join(', '):'none')+')');
 const E=[['v = u + at',K=>K.v-K.u-K.a*K.t,'vuat'],['s = ut + ½at²',K=>K.s-K.u*K.t-.5*K.a*K.t*K.t,'sutа'.replace('а','a')],['v² = u² + 2as',K=>K.v*K.v-K.u*K.u-2*K.a*K.s,'vuas'],['s = (u+v)t/2',K=>K.s-(K.u+K.v)*K.t/2,'suvt']];
 const res=K=>{const sc=1+Object.values(K).filter(D).reduce((z,x)=>z+x*x,0);return E.filter(e=>[...e[2]].every(x=>D(K[x]))).map(e=>[e[0],Math.abs(e[1](K))/sc])};
 const badEq=res(K).find(r=>r[1]>1e-3);if(badEq)bad('the data are inconsistent: '+badEq[0]+' is violated by the given values');
 const sol=(X,K)=>{const{u,v,a,t,s}=K;let r;
  if(X=='s'){if(D(u)&&D(a)&&D(t))return[u*t+.5*a*t*t,'s = ut + ½at²'];if(D(u)&&D(v)&&D(t))return[(u+v)*t/2,'s = (u+v)t/2'];if(D(u)&&D(v)&&D(a)&&a!=0)return[(v*v-u*u)/(2*a),'s = (v²−u²)/2a']}
  if(X=='v'){if(D(u)&&D(a)&&D(t))return[u+a*t,'v = u + at'];if(D(u)&&D(a)&&D(s)){const d=u*u+2*a*s;if(d<0)bad('no real final speed: u² + 2as < 0');return[Math.sqrt(d),'v = √(u²+2as)']}if(D(u)&&D(s)&&D(t))return[2*s/t-u,'v = 2s/t − u']}
  if(X=='t'){if(D(u)&&D(v)&&D(a)&&a!=0)return[(v-u)/a,'t = (v−u)/a'];if(D(u)&&D(v)&&D(s)&&u+v!=0)return[2*s/(u+v),'t = 2s/(u+v)'];if(D(u)&&D(a)&&D(s)){if(a==0)return[s/u,'t = s/u'];const d=u*u+2*a*s;if(d<0)bad('no real time: u² + 2as < 0');const rs=[(-u+Math.sqrt(d))/a,(-u-Math.sqrt(d))/a].filter(x=>x>=0).sort((x,y)=>x-y);if(!rs.length)bad('no positive time satisfies the data');return[rs[0],'t from ½at² + ut − s = 0']}}
  if(X=='a'){if(D(u)&&D(v)&&D(t)&&t!=0)return[(v-u)/t,'a = (v−u)/t'];if(D(u)&&D(v)&&D(s)&&s!=0)return[(v*v-u*u)/(2*s),'a = (v²−u²)/2s'];if(D(u)&&D(s)&&D(t)&&t!=0)return[2*(s-u*t)/(t*t),'a = 2(s−ut)/t²']}
  if(X=='u'){if(D(v)&&D(a)&&D(t))return[v-a*t,'u = v − at'];if(D(v)&&D(a)&&D(s)){const d=v*v-2*a*s;if(d<0)bad('no real initial speed');return[Math.sqrt(d),'u = √(v²−2as)']}if(D(v)&&D(s)&&D(t))return[2*s/t-v,'u = 2s/t − v']}
  return null};
 let X=q.pick({u:/initial/,s:/distance|how far|displacement|travell?ed|covered/,t:/\btime|how long|seconds/,a:/accelerat|retard|decelerat/,v:/speed|velocity|how fast/});const mis=['u','v','a','t','s'].filter(k=>!D(K[k]));if(!X||D(K[X])){if(mis.length==1)X=mis[0];else if(!X)miss('which quantity to find')}
 const st=['Knowns: '+have.map(k=>k+' = '+sg(K[k])).join(', ')];let val=K[X],nm;if(!D(val)){const r=sol(X,K);if(!r)miss('a different combination of data (cannot isolate '+X+' from '+have.join(', ')+')');[val,nm]=r;K[X]=val;st.push(nm+' → '+X+' = '+sg(val))}
 for(const y of ['u','v','a','t','s'])if(!D(K[y])){const r=sol(y,K);if(r)K[y]=r[0]}const rr=res(K);if(rr.some(r=>r[1]>1e-6))bad('internal check failed: '+rr.filter(r=>r[1]>1e-6)[0][0]);
 const lab={u:['initial speed','m/s'],v:['final speed','m/s'],a:['acceleration','m/s²'],t:['time','s'],s:['distance','m']}[X];let ans=[[lab[0],K[X],lab[1]]];if(X=='a'&&q.a(/retard|decelerat/))ans=[['retardation',-K[X],'m/s²']];
 return R(ans,st,[rr.length?Math.max(...rr.map(r=>r[1])):0,0,rr.length+' kinematic equations are all satisfied by the full set (u,v,a,t,s)',1e-6])});
/* ---------- driver ---------- */
function solve(text){let t0=text.replace(/−/g,'-'),t=spell(t0),gv=9.8,ga=true;const gm=t.match(/\bg\s*=\s*(\d+\.?\d*)\s*(?:m\s*\/\s*s\s*\^?\s*2|m\/s²|ms\^?-2)?/i);if(gm){gv=+gm[1];ga=false;t=t.replace(gm[0],' ')}
 const q=mkq(t);q.l=t0.toLowerCase().replace(/²/g,'^2');q.gv=gv;let fm=null;
 for(const[name,re,fn]of TPL){if(!re.test(q.l))continue;let r;try{r=fn(q)}catch(e){if(e&&e.skip)continue;if(e&&e.miss){fm=fm||{kind:'miss',text:'**Not enough information.** This looks like a '+name+' problem, but I still need: '+e.miss+'. I will not guess missing values.',meta:'Nothing was computed.'};continue}
  if(e&&e.bad)return{kind:'bad',text:'**I cannot give a reliable answer.** ('+name+') '+e.bad+'.',meta:'Check the problem statement; nothing was computed.'};console.error(name,e);continue}
  const c=r.c;if(c&&!close(c[0],c[1],c[3]||1e-6))return{kind:'bad',text:'**Verification failed** ('+name+'): '+c[2]+' gave '+sg(c[0],6)+' vs '+sg(c[1],6)+'. I am withholding the answer rather than risk a wrong one.',meta:'Internal check mismatch.'};
  const A=r.a.map(x=>x[0]+' = '+(typeof x[1]=='number'?sg(x[1]):x[1])+(x[2]?' '+x[2]:'')).join(';   '),conv=q.Q.filter(x=>x.d&&x.fac!==1).map(x=>sg(x.num)+' '+x.u+' = '+sg(x.v)+' '+DU[x.d]).join('; ');
  return{kind:'ok',name,answers:r.a.map(x=>({l:x[0],v:x[1],u:x[2]})),text:'**'+A+'**\nTopic: '+name+'\nWorking:\n'+r.s.map((s,i)=>(i+1)+'. '+s).join('\n')+(conv?'\nUnit conversions: '+conv:'')+(r.g&&ga?'\nAssumed g = '+gv+' m/s²':'')+(c?'\nCheck ✓ '+c[2]+' ('+sg(c[0],6)+' vs '+sg(c[1],6)+')':''),
   meta:'Solved locally by template reasoning (no AI model) and cross-checked by an independent method. Unusual phrasing may not be recognised.'}}
 return fm||{kind:'skip'}}
window.Solver={solve};
if(window.Reasoner){const oM=Reasoner.matches,oR=Reasoner.run;let cache=null;
 Reasoner.matches=t=>{cache=null;if(/^\s*formulas?\b/i.test(t))return oM(t);let r;try{r=solve(t)}catch(e){console.error(e);r={kind:'skip'}}
  if(r.kind=='ok'||r.kind=='bad'){cache={t,r};return true}if(oM(t))return true;if(r.kind=='miss'){cache={t,r};return true}return false};
 Reasoner.run=t=>cache&&cache.t==t?{text:cache.r.text,meta:cache.r.meta}:oR(t)}
})();
