/* EDO model router. Decides WHICH engine should handle a message; it never answers anything itself.
   Routes: vision | multi | planner | device | math | jee | project | programming | search | followup | memory | clarify | chat.
   Deterministic engines (math, jee, project, programming, device) are trusted tools; "chat" is the only route that belongs to the AI model.
   Pure function of (text, ctx); uses Intent/Device/Reasoner when loaded. Globals: window.ModelRouter */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  const CURRENT = /\b(latest|current(?:ly)?|today|tonight|right now|news|score|scores|price of|prices?|stock|weather|forecast|trending|released?|release date|who is the (?:current|new)|who won|this (?:week|month|year)|just (?:happened|announced)|202[5-9])\b/i;
  const FOLLOWUP = /^\s*(?:continue|go on|keep going|carry on|again|do (?:that|it) again|repeat (?:that|it)|change (?:it|that)|make (?:it|that) (?:better|shorter|longer|simpler)|try again|undo that|never ?mind|that one|this one|the (?:first|second|third|last|next) one|what about (?:that|it|the)\b.*|why (?:is that|did you)|and then|more)\s*[.!?]*\s*$/i;
  const MEMORYQ = /\b(remember (?:this|that)|forget (?:this|that)|note that|what do you remember|my preferences?)\b/i;
  const REMIND = /\b(remind me|set (?:a )?(?:reminder|timer|alarm)|timer for|wake me)\b/i;
  const PROJECT = /\b(project|codebase|repo(?:sitory)?|workspace|dependency graph|circular dependenc|impact of|who calls|find usages?|references? to|review (?:my )?(?:code|project)|refactor (?:the )?project)\b/i;
  const PRONOUN_ONLY = /^\s*(?:it|this|that|those|these|them|him|her|there|do (?:it|that|this)|fix (?:it|that)|open (?:it|that)|send (?:it|that)|yes|no|ok(?:ay)?)\s*[.!?]*\s*$/i;
  const ACTION_VERB = /\b(open|launch|call|dial|search|find|look up|play|remind|set|send|share|show|turn|check|read|copy)\b/i;
  const SPLIT = /\s*(?:,\s*and then|\band then\b|\bthen\b|\band also\b|\band\b)\s+/i;

  function needsCurrentInfo(text) { return CURRENT.test(String(text || "")); }
  /* Split "open YouTube and find a video about kinematics" into action parts. Only splits when each part starts with (or contains) an action verb. */
  function splitActions(text) {
    const parts = String(text || "").split(SPLIT).map((s) => s.trim()).filter(Boolean);
    if (parts.length < 2 || parts.length > 5) return [String(text || "").trim()];
    const actionable = parts.filter((p) => ACTION_VERB.test(p.split(/\s+/).slice(0, 3).join(" ")));
    return actionable.length >= 2 && actionable.length === parts.length ? parts : [String(text || "").trim()];
  }
  function route(text, ctx) {
    ctx = ctx || {};
    const raw = String(text == null ? "" : text).trim();
    const R = (r, reason, conf, extra) => Object.assign({ route: r, reason, confidence: conf }, extra || {});
    if (!raw && !(ctx.attachments && ctx.attachments.length)) return R("clarify", "empty input", 1, { question: "I didn't get anything. What would you like to do?" });
    const att = ctx.attachments || [];
    if (att.some((a) => a && /^(image|camera|screen)/.test(a.kind || a.type || ""))) return R("vision", "image, camera or screen input attached", 0.95);
    if (FOLLOWUP.test(raw)) return ctx.hasHistory ? R("followup", "refers to the previous turn", 0.85) : R("clarify", "follow-up with no earlier turn", 0.9, { question: "I don't have an earlier request to continue from. What should I do?" });
    if (PRONOUN_ONLY.test(raw) && !ctx.hasHistory && !ctx.pending) return R("clarify", "pronoun with no referent", 0.9, { question: "What do you mean by that? Tell me the app, person or item and I'll do it." });
    if (MEMORYQ.test(raw)) return R("memory", "memory request", 0.9);
    const parts = splitActions(raw);
    if (parts.length >= 2) return R("multi", "several actions in one request", 0.85, { parts });
    if (REMIND.test(raw)) return R("planner", "reminder, timer or alarm needs time parsing", 0.9);
    const intent = root.Intent ? root.Intent.detect(raw, ctx.mode || "Assistant") : { kind: "conversation", confidence: 0.5 };
    if (intent.kind === "crisis") return R("chat", "safety message stays on the local companion", 1, { local: true });
    if (intent.kind === "device") return R("device", "phone action", intent.confidence);
    if (intent.kind === "calculation") return R("math", "arithmetic goes to the strict calculator", intent.confidence);
    if (PROJECT.test(raw) && (ctx.projectLoaded || /\b(code|codebase|repo|repository|dependenc|source files?)\b/i.test(raw))) return R("project", ctx.projectLoaded ? "project question: CodeBrain index first" : "code-project question (CodeBrain will say if none is loaded)", 0.85);
    if (root.Reasoner && root.Reasoner.matches && root.Reasoner.matches(raw)) return R("jee", "numeric JEE/MPC problem: deterministic solver first, AI explains", 0.9);
    if (intent.kind === "jee") return R("jee", "JEE/MPC topic", intent.confidence);
    if (ctx.projectLoaded && PROJECT.test(raw)) return R("project", "project question: CodeBrain index first", 0.85);
    if (intent.kind === "programming") return R(ctx.projectLoaded && PROJECT.test(raw) ? "project" : "programming", "code question: programming engine first, AI explains", intent.confidence);
    if (intent.wantsLocation || intent.wantsWeather) return R("search", "needs location or live data", 0.8, { current: true });
    if (intent.kind === "search" || intent.wantsSearch || needsCurrentInfo(raw)) return R("search", "needs current information: search, never guess", 0.8, { current: needsCurrentInfo(raw) });
    if (intent.kind === "file" || intent.kind === "memory") return R("memory", "local note or file engine", intent.confidence);
    if (intent.kind === "decision" || intent.kind === "chat") return R("chat", "conversation", intent.confidence, { companion: true });
    return R("chat", "open conversation", 0.55);
  }
  root.ModelRouter = { route, needsCurrentInfo, splitActions };
})();
