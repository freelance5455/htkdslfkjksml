/* EDO semantic-style retrieval. Local, deterministic, mobile-cheap. This is NOT a neural embedding model.
   It combines: light stemming, a synonym/concept table (so "test" finds "exam"), inverse-document-frequency
   weighting, and character-trigram overlap (so typos like "recieve" still match). Everything is computed on
   the fly from the items passed in, so there is no index to keep in sync and nothing to persist.
   Globals: window.Semantic */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;

  const STOP = new Set(("a an the and or but if so of to in on at by for with from as is are was were be been am do does did have has had i me my mine we us our you your it its this that these those " +
    "will would can could should shall may might just about into over than then there here what which who whom how when where why not no yes also very really some any all up out off too more most").split(" "));

  /* concept groups: every word in a group maps to the group's first word. Extend with Semantic.addConcepts(). */
  const CONCEPTS = [
    ["exam", "test", "paper", "quiz", "assessment", "boards", "mock", "jee", "neet", "finals"],
    ["mark", "score", "grade", "result", "rank", "percentage", "percent"],
    ["study", "revise", "revision", "learn", "prepare", "preparation", "practise", "practice", "homework"],
    ["plan", "schedule", "timetable", "routine", "agenda", "roadmap", "strategy"],
    ["bug", "error", "crash", "issue", "problem", "fault", "exception", "fail", "broken", "freeze", "hang"],
    ["project", "app", "application", "game", "software", "repo", "codebase", "workspace"],
    ["enemy", "npc", "monster", "opponent", "zombie", "foe"],
    ["move", "walk", "run", "chase", "patrol", "navigate", "motion"],
    ["task", "todo", "chore", "assignment", "job", "reminder"],
    ["remember", "memorize", "recall", "memory", "note", "save"],
    ["happy", "glad", "excited", "proud", "joy", "great"],
    ["sad", "upset", "down", "low", "unhappy", "miserable"],
    ["stress", "pressure", "anxious", "anxiety", "worry", "nervous", "tension", "overwhelm"],
    ["physics", "mechanics", "kinematics", "electrostatics", "optics", "thermodynamics"],
    ["chemistry", "organic", "inorganic", "mole", "equilibrium", "stoichiometry"],
    ["math", "maths", "mathematics", "algebra", "calculus", "trigonometry", "integration", "differentiation"],
    ["code", "program", "script", "function", "method", "class", "module"],
    ["slow", "lag", "performance", "fps", "stutter", "optimize", "optimise", "speed"],
    ["finish", "complete", "done", "finished", "completed"],
    ["start", "begin", "begun", "kick"],
    ["yesterday", "previous", "earlier", "before", "last"],
    ["enemy", "ai", "agent"],
    ["force", "charge", "coulomb"],
  ];
  const concept = new Map();
  function addConcepts(groups) {
    (groups || []).forEach((g) => { if (g && g.length) g.forEach((w) => { const k = String(w).toLowerCase(); if (!concept.has(k)) concept.set(k, String(g[0]).toLowerCase()); }); });
  }
  addConcepts(CONCEPTS);

  function stem(w) {
    if (w.length <= 3) return w;
    return w.replace(/(ations?|ation|ments?|ness|ingly|edly|ing|ies|ied|ed|es|ly|s)$/, (m) => (m === "ies" || m === "ied" ? "y" : "")) || w;
  }
  function tokens(text) {
    return String(text || "").toLowerCase().replace(/[^a-z0-9\u0900-\u097f+#.]+/g, " ").split(/\s+/)
      .map((w) => w.replace(/^[.+#]+|[.+#]+$/g, "")).filter((w) => w && !STOP.has(w));
  }
  function canon(w) {
    const direct = concept.get(w); if (direct) return direct;
    const s = stem(w);
    return concept.get(s) || s;
  }
  function terms(text) { return tokens(text).map(canon); }
  function trigrams(text) {
    const s = " " + String(text || "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim() + " ";
    const set = new Set();
    for (let i = 0; i + 3 <= s.length; i++) set.add(s.slice(i, i + 3));
    return set;
  }
  function trigramSim(a, b) {
    if (!a.size || !b.size) return 0;
    let inter = 0;
    a.forEach((g) => { if (b.has(g)) inter++; });
    return inter / Math.min(a.size, b.size);
  }

  /* rank(query, items, textOf, {limit, min}) → [{item, score}] best first. Pass `boost(item)` to add recency or priority. */
  function rank(query, items, textOf, opts) {
    opts = opts || {};
    const get = textOf || ((x) => String(x));
    const qTerms = terms(query);
    if (!qTerms.length || !items || !items.length) return [];
    const docs = items.map((it) => { const text = get(it); return { it, text, terms: terms(text), tri: null }; });
    const df = new Map();
    docs.forEach((d) => new Set(d.terms).forEach((t) => df.set(t, (df.get(t) || 0) + 1)));
    const N = docs.length;
    const idf = (t) => Math.log(1 + (N + 1) / ((df.get(t) || 0) + 0.5));
    const qSet = new Set(qTerms), qLit = new Set(tokens(query));
    const qTri = trigrams(query);
    const out = [];
    docs.forEach((d) => {
      if (!d.terms.length) return;
      const dSet = new Set(d.terms), dLit = new Set(tokens(d.text));
      let num = 0, den = 0;
      qSet.forEach((t) => {
        const w = idf(t);
        den += w;
        if (dSet.has(t)) num += w * ([...qLit].some((l) => dLit.has(l) && canon(l) === t) ? 1 : 0.8); // literal match beats synonym match
      });
      const lexical = den ? num / den : 0;
      if (!d.tri) d.tri = trigrams(d.text);
      const fuzzy = lexical === 0 ? trigramSim(qTri, d.tri) * 0.35 : trigramSim(qTri, d.tri) * 0.1;
      let score = lexical + fuzzy;
      if (opts.boost) score += opts.boost(d.it) || 0;
      if (score >= (opts.min == null ? 0.18 : opts.min)) out.push({ item: d.it, score: Math.round(score * 1000) / 1000 });
    });
    out.sort((a, b) => b.score - a.score);
    return opts.limit ? out.slice(0, opts.limit) : out;
  }
  function similarity(a, b) {
    const r = rank(a, [b], (x) => x, { min: 0 });
    return r.length ? r[0].score : 0;
  }
  root.Semantic = { rank, similarity, terms, tokens, addConcepts, canon, heuristic: true };
})();
