/* EDO units. Dimension vectors [L, M, T, I, K, N] (length, mass, time, current, temperature, amount).
   Parses compound units (m/s^2, kg*m/s², N·m), converts, and checks dimensions. UI-independent. */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  const D = (L, M, T, I, K, N) => [L || 0, M || 0, T || 0, I || 0, K || 0, N || 0];
  const base = {
    m: [1, D(1)], g: [1e-3, D(0, 1)], s: [1, D(0, 0, 1)], A: [1, D(0, 0, 0, 1)], K: [1, D(0, 0, 0, 0, 1)], mol: [1, D(0, 0, 0, 0, 0, 1)],
    N: [1, D(1, 1, -2)], J: [1, D(2, 1, -2)], W: [1, D(2, 1, -3)], Pa: [1, D(-1, 1, -2)], Hz: [1, D(0, 0, -1)],
    C: [1, D(0, 0, 1, 1)], V: [1, D(2, 1, -3, -1)], ohm: [1, D(2, 1, -3, -2)], F: [1, D(-2, -1, 4, 2)], T: [1, D(0, 1, -2, -1)],
    H: [1, D(2, 1, -2, -2)], Wb: [1, D(2, 1, -2, -1)], S: [1, D(-2, -1, 3, 2)],
    L: [1e-3, D(3)], l: [1e-3, D(3)], min: [60, D(0, 0, 1)], h: [3600, D(0, 0, 1)], hr: [3600, D(0, 0, 1)], day: [86400, D(0, 0, 1)], yr: [3.15576e7, D(0, 0, 1)],
    deg: [Math.PI / 180, D()], rad: [1, D()], eV: [1.602176634e-19, D(2, 1, -2)], atm: [101325, D(-1, 1, -2)], bar: [1e5, D(-1, 1, -2)],
    Wh: [3600, D(2, 1, -2)], cal: [4.184, D(2, 1, -2)], kcal: [4184, D(2, 1, -2)], amu: [1.66054e-27, D(0, 1)], u: [1.66054e-27, D(0, 1)],
    inch: [0.0254, D(1)], ft: [0.3048, D(1)], yd: [0.9144, D(1)], mile: [1609.344, D(1)], mi: [1609.344, D(1)], lb: [0.45359237, D(0, 1)], kmph: [1 / 3.6, D(1, 0, -1)],
    mmHg: [133.322, D(-1, 1, -2)], torr: [133.322, D(-1, 1, -2)], M: [1000, D(-3, 0, 0, 0, 0, 1)], angstrom: [1e-10, D(1)], Å: [1e-10, D(1)],
  };
  const PRE = { Y: 1e24, Z: 1e21, E: 1e18, P: 1e15, T: 1e12, G: 1e9, M: 1e6, k: 1e3, h: 1e2, c: 1e-2, m: 1e-3, u: 1e-6, "µ": 1e-6, "μ": 1e-6, n: 1e-9, p: 1e-12, f: 1e-15 };
  const NOPREFIX = new Set(["min", "mol", "mi", "cal", "kcal", "eV", "atm", "bar", "day", "yr", "hr", "h", "deg", "rad", "inch", "ft", "yd", "mile", "lb", "kmph", "mmHg", "torr", "amu", "u", "M", "L", "l", "Å", "angstrom", "T", "H", "S", "ohm"]);
  const ALIAS = { meter: "m", meters: "m", metre: "m", metres: "m", second: "s", seconds: "s", sec: "s", secs: "s", minute: "min", minutes: "min", mins: "min", hour: "h", hours: "h", hrs: "h",
    gram: "g", grams: "g", kilogram: "kg", kilograms: "kg", newton: "N", newtons: "N", joule: "J", joules: "J", watt: "W", watts: "W", volt: "V", volts: "V", amp: "A", amps: "A", ampere: "A", amperes: "A",
    ohms: "ohm", "Ω": "ohm", "kΩ": "kohm", coulomb: "C", coulombs: "C", farad: "F", farads: "F", tesla: "T", kelvin: "K", mole: "mol", moles: "mol", litre: "L", litres: "L", liter: "L", liters: "L",
    degree: "deg", degrees: "deg", "°": "deg", radian: "rad", radians: "rad", pascal: "Pa", hertz: "Hz", inches: "inch", feet: "ft", foot: "ft", miles: "mile", pounds: "lb", days: "day", years: "yr", year: "yr", molar: "M" };
  function atom(u) {
    u = ALIAS[u] || ALIAS[u.toLowerCase()] || u;
    if (u === "kohm") return { f: 1e3, d: base.ohm[1] };
    if (base[u]) return { f: base[u][0], d: base[u][1].slice() };
    if (u.length > 1 && PRE[u[0]] && base[u.slice(1)] && !NOPREFIX.has(u.slice(1))) {
      const b = base[u.slice(1)];
      return { f: PRE[u[0]] * b[0], d: b[1].slice() };
    }
    return null;
  }
  const SUP = { "⁰": 0, "¹": 1, "²": 2, "³": 3, "⁴": 4, "⁻": "-" };
  /* "m/s^2", "kg m s^-2", "N·m", "mol/L". Returns {f, d} or null if any piece is unknown. */
  function parse(str) {
    let s = String(str || "").trim().replace(/[·⋅*]/g, " ").replace(/\^\s*\(?\s*(-?\d+)\s*\)?/g, "^$1");
    s = s.replace(/([⁻]?[⁰¹²³⁴]+)/g, (m) => "^" + (m[0] === "⁻" ? "-" : "") + [...m].filter((c) => c !== "⁻").map((c) => SUP[c]).join(""));
    if (!s) return { f: 1, d: D() };
    const out = { f: 1, d: D() };
    const [num, ...den] = s.split("/");
    const parts = [[num, 1]].concat(den.map((x) => [x, -1]));
    for (const [seg, sign] of parts) {
      for (const tok of seg.split(/\s+/).filter(Boolean)) {
        const m = /^([A-Za-zµμΩÅ°]+?)(?:\^?(-?\d+))?$/.exec(tok);
        if (!m) return null;
        const a = atom(m[1]);
        if (!a) return null;
        const p = (m[2] ? +m[2] : 1) * sign;
        out.f *= Math.pow(a.f, p);
        for (let i = 0; i < 6; i++) out.d[i] += a.d[i] * p;
      }
    }
    return out;
  }
  const sameDim = (a, b) => a.every((x, i) => x === b[i]);
  const NAMES = ["m", "kg", "s", "A", "K", "mol"];
  function dimStr(d) {
    const p = d.map((e, i) => (e ? NAMES[i] + (e === 1 ? "" : "^" + e) : "")).filter(Boolean);
    return p.length ? p.join(" ") : "dimensionless";
  }
  const SCALE = { c: "C", "°c": "C", celsius: "C", f: "F", "°f": "F", fahrenheit: "F", k: "K", kelvin: "K" };
  const toK = (v, sc) => (sc === "C" ? v + 273.15 : sc === "F" ? ((v + 459.67) * 5) / 9 : v);
  const fromK = (k, sc) => (sc === "C" ? k - 273.15 : sc === "F" ? (k * 9) / 5 - 459.67 : k);
  /* Convert value between units. Temperature scales are affine; everything else is multiplicative. */
  function convert(value, from, to) {
    if (!isFinite(value)) return { ok: false, error: "value is not finite" };
    const sf = SCALE[String(from).trim().toLowerCase().replace(/^deg\s*/, "")], st = SCALE[String(to).trim().toLowerCase().replace(/^deg\s*/, "")];
    if (sf && st) {
      const k = toK(value, sf);
      if (k < 0) return { ok: false, error: "below absolute zero" };
      return { ok: true, value: fromK(k, st) };
    }
    const a = parse(from), b = parse(to);
    if (!a) return { ok: false, error: "unknown unit '" + from + "'" };
    if (!b) return { ok: false, error: "unknown unit '" + to + "'" };
    if (!sameDim(a.d, b.d)) return { ok: false, error: "cannot convert " + from + " (" + dimStr(a.d) + ") to " + to + " (" + dimStr(b.d) + "): different dimensions" };
    return { ok: true, value: (value * a.f) / b.f, factor: a.f / b.f };
  }
  /* "convert 5 km/h to m/s", "36 km/h in m/s", "2.5 atm to Pa" → {value, from, to} or null */
  function parseConversion(text) {
    const m = /^\s*(?:please\s+)?(?:convert\s+)?(-?\d+(?:\.\d+)?(?:e[+-]?\d+)?)\s*(°?[A-Za-zµμΩÅ][\w°µμΩ\/\^\-·⁻¹²³ ]*?)\s+(?:to|into|in)\s+(°?[A-Za-zµμΩÅ][\w°µμΩ\/\^\-·⁻¹²³ ]*?)\s*[?.!]*\s*$/i.exec(String(text || "").slice(0, 200));
    if (!m) return null;
    const hasWord = /^\s*convert\b/i.test(text);
    if (!hasWord && !(parse(m[2]) && parse(m[3])) && !(SCALE[m[2].toLowerCase()] && SCALE[m[3].toLowerCase()])) return null;
    return { value: parseFloat(m[1]), from: m[2].trim(), to: m[3].trim() };
  }
  /* Expected dimension of common symbols, used to catch "t = 5 m" or "m = 3 s" style wrong-unit givens. HEURISTIC. */
  const SYMBOL_DIM = { t: D(0, 0, 1), m: D(0, 1), M: D(0, 1), v: D(1, 0, -1), u: D(1, 0, -1), a: D(1, 0, -2), s: D(1), d: D(1), h: D(1), r: D(1), x: D(1), F: D(1, 1, -2), E: D(2, 1, -2), W: D(2, 1, -2), P: D(2, 1, -3), T: null, V: D(2, 1, -3, -1), I: D(0, 0, 0, 1), R: D(2, 1, -3, -2), q: D(0, 0, 1, 1), Q: null, B: D(0, 1, -2, -1) };
  function checkSymbolUnit(symbol, unitStr) {
    const exp = SYMBOL_DIM[symbol];
    if (!exp) return { ok: true, checked: false };
    const u = parse(unitStr);
    if (!u) return { ok: false, error: "unknown unit '" + unitStr + "'" };
    if (!sameDim(u.d, exp)) return { ok: false, error: "'" + symbol + "' is normally " + dimStr(exp) + " but '" + unitStr + "' is " + dimStr(u.d) };
    return { ok: true, checked: true };
  }
  root.Units = { parse, convert, parseConversion, sameDim, dimStr, checkSymbolUnit, D };
})();
