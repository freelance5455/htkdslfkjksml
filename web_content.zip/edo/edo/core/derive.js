/* EDO derivation engine. Forward-chains over the formula table to solve for a target through intermediate
   quantities (e.g. v = u+at, then KE = ½mv²). Tracks which formula produced each quantity, verifies every step by
   substituting back, and compares independent chains. Symbols are matched by NAME inside one chapter group, so this
   is HEURISTIC: it is labelled that way in the output and never invents a formula that is not in EDO_FORMULAS. */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  const sig = (x) => +(+x).toPrecision(6);

  function chainIn(rows, givens, target, maxSteps) {
    const known = Object.assign({}, givens), steps = [], origin = {};
    Object.keys(known).forEach((k) => (origin[k] = "given"));
    let nonFinite = false;
    for (let round = 0; round < (maxSteps || 6) && !(target in known); round++) {
      let progressed = false;
      for (const F of rows) {
        const vars = root.Reasoner.idsAll(F.e).filter((w) => !(w in root.EDO_CONSTS));
        const unknown = vars.filter((w) => !(w in known));
        if (unknown.length !== 1) continue;
        const T = unknown[0];
        const r = root.Reasoner.solveFor(F, T, known);
        if (!r) { nonFinite = nonFinite || !!F; continue; }
        known[T] = r.val;
        origin[T] = F.n;
        steps.push({ formula: F, target: T, value: r.val, residual: r.res, uses: vars.filter((w) => w !== T) });
        progressed = true;
        if (T === target) break;
      }
      if (!progressed) break;
    }
    // keep only the steps the target actually depends on
    const need = new Set([target]), kept = [];
    for (let i = steps.length - 1; i >= 0; i--) if (need.has(steps[i].target)) { kept.unshift(steps[i]); steps[i].uses.forEach((u) => need.add(u)); }
    return { ok: target in known, value: known[target], steps: kept, known, nonFinite };
  }
  /* Try each chapter group separately; return all distinct successful chains (shortest first). */
  function solve(givens, target, opts) {
    opts = opts || {};
    if (!root.Reasoner || !root.EDO_FORMULAS) return { ok: false, reason: "formula table not loaded", chains: [] };
    const rows = root.EDO_FORMULAS.filter((f) => !f.e.startsWith("~"));
    const groups = {};
    rows.forEach((f) => { (groups[f.c] = groups[f.c] || []).push(f); });
    const chains = [];
    Object.keys(groups).forEach((c) => {
      if (opts.chapter && opts.chapter !== c) return;
      const ch = chainIn(groups[c], givens, target, opts.maxSteps);
      if (ch.ok && ch.steps.length) chains.push(Object.assign(ch, { chapter: c }));
    });
    if (!chains.length && !opts.chapter) { // no single chapter is enough: allow chaining across chapters of one subject
      const subj = {};
      rows.forEach((f) => { (subj[f.s] = subj[f.s] || []).push(f); });
      Object.keys(subj).forEach((s) => {
        const ch = chainIn(subj[s], givens, target, opts.maxSteps);
        if (ch.ok && ch.steps.length) chains.push(Object.assign(ch, { chapter: s + " (cross-chapter)", crossChapter: true }));
      });
    }
    chains.sort((a, b) => a.steps.length - b.steps.length);
    const distinct = [];
    chains.forEach((ch) => { if (!distinct.some((d) => Math.abs(d.value - ch.value) <= 1e-9 * Math.max(1, Math.abs(ch.value)))) distinct.push(ch); });
    return { ok: chains.length > 0, chains, distinct, ambiguous: distinct.length > 1 };
  }
  function explain(ch, target) {
    return ch.steps.map((s, i) => (i + 1) + ". " + s.formula.n + " (" + s.formula.e + "): " + s.target + " = " + sig(s.value) + "  [uses " + s.uses.join(", ") + "]").join("\n");
  }
  function symbols() { const o = {}; (root.EDO_FORMULAS || []).forEach((f) => root.Reasoner.idsAll(f.e).forEach((w) => { if (!(w in root.EDO_CONSTS)) o[w] = 1; })); return o; }
  root.Derive = { solve, chainIn, explain, symbols };
})();
