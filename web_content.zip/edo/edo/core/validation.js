/* EDO validation. A plug-in registry for checking a change to a project, ordered from cheap to expensive:

     1. static     lexical / bracket / known-risk checks per changed file      (CodeAnalyzer, always available)
     2. project    cross-file checks on an indexed copy: unresolved imports, removed symbols still used,
                   new dependency cycles, duplicate definitions, broken Unity script links
     3. execute    a real compiler or test run, ONLY through an explicitly configured isolated runner

   EDO never compiles or runs project code itself, in the UI or the Android process. If no runner is configured the report
   says "Not executed here." and nothing is presented as having run. When a runner is configured and the user confirms,
   the report contains exactly what the runner returned (command, environment, exit status, stdout, stderr, tests).
   A malformed runner response is reported as an error; it is never repaired or filled in.
   Globals: window.Validation */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  const NOT_EXECUTED = "Not executed here.";
  const plugins = new Map();
  let runnerCfg = null;

  function register(id, plugin) {
    if (!id || !plugin || typeof plugin.run !== "function") throw new TypeError("validator needs an id and a run(project, files, ctx) function");
    plugins.set(id, Object.assign({ id, label: id, level: "static", appliesTo: () => true }, plugin));
  }
  const list = () => [...plugins.values()].map((p) => ({ id: p.id, label: p.label, level: p.level }));

  /* validate(project, changedPaths, ctx) → {ok, executed:false, findings[], results[], note} */
  function validate(project, files, ctx) {
    ctx = ctx || {};
    const results = [];
    plugins.forEach((p) => {
      let applies = false;
      try { applies = p.appliesTo(project, files, ctx); } catch (e) { applies = false; }
      if (!applies) { results.push({ id: p.id, label: p.label, level: p.level, skipped: true, findings: [] }); return; }
      try {
        const r = p.run(project, files, ctx) || {};
        results.push({ id: p.id, label: p.label, level: p.level, skipped: false, findings: (r.findings || []).slice(0, 100) });
      } catch (e) { results.push({ id: p.id, label: p.label, level: p.level, skipped: false, error: String(e.message).slice(0, 160), findings: [] }); }
    });
    const findings = results.flatMap((r) => r.findings.map((f) => Object.assign({ check: r.id }, f)));
    const errors = findings.filter((f) => f.severity === "error");
    return { ok: errors.length === 0 && !results.some((r) => r.error), executed: false, note: NOT_EXECUTED, errors: errors.length, warnings: findings.filter((f) => f.severity === "warning").length, findings, results };
  }

  /* ---------- external runner ---------- */
  function trustedEndpoint(u) {
    try { const x = new URL(u); return x.protocol === "https:" || (x.protocol === "http:" && /^(localhost|127\.0\.0\.1|\[::1\])$/.test(x.hostname)); } catch (e) { return false; }
  }
  function configureRunner(cfg) {
    if (!cfg) { runnerCfg = null; return { configured: false }; }
    if (!trustedEndpoint(cfg.endpoint)) throw new Error("Runner endpoint must be https, or http on localhost.");
    runnerCfg = { endpoint: cfg.endpoint, environment: String(cfg.environment || "unspecified").slice(0, 80), timeoutMs: Math.min(300000, Math.max(1000, cfg.timeoutMs || 60000)), token: cfg.token || null, fetch: cfg.fetch || null, maxBytes: cfg.maxBytes || 2000000, commands: Array.isArray(cfg.commands) ? cfg.commands.slice(0, 20) : null };
    return runner();
  }
  function runner() { return runnerCfg ? { configured: true, endpoint: runnerCfg.endpoint, environment: runnerCfg.environment, timeoutMs: runnerCfg.timeoutMs, commands: runnerCfg.commands } : { configured: false, note: NOT_EXECUTED }; }

  function checkReport(j, requested) {
    const bad = (m) => { throw Object.assign(new Error("runner returned an invalid report: " + m), { code: "invalid_report" }); };
    if (!j || typeof j !== "object") bad("not an object");
    if (!Number.isInteger(j.exitCode)) bad("exitCode must be an integer");
    if (typeof j.stdout !== "string" || typeof j.stderr !== "string") bad("stdout and stderr must be strings");
    if (typeof j.command !== "string" || !j.command) bad("command is missing, so what ran is unknown");
    if (typeof j.environment !== "string" || !j.environment) bad("environment is missing");
    let tests = null;
    if (j.tests != null) {
      const t = j.tests;
      if (!t || !Number.isInteger(t.passed) || !Number.isInteger(t.failed) || t.passed < 0 || t.failed < 0) bad("tests must have non-negative integer passed and failed");
      tests = { passed: t.passed, failed: t.failed, skipped: Number.isInteger(t.skipped) ? t.skipped : 0, failures: Array.isArray(t.failures) ? t.failures.slice(0, 50).map((x) => String(x).slice(0, 300)) : [] };
    }
    return {
      executed: true, ranBy: "external runner", requestedCommand: requested, command: j.command, commandMatchesRequest: j.command === requested, environment: j.environment,
      exitCode: j.exitCode, ok: j.exitCode === 0 && (!tests || tests.failed === 0), stdout: j.stdout.slice(0, 20000), stderr: j.stderr.slice(0, 20000), durationMs: Number.isFinite(j.durationMs) ? j.durationMs : null, tests,
    };
  }
  /* execute({command, files, confirmed}) → report. Never throws: failure is {executed:false, error, note}. */
  async function execute(spec) {
    spec = spec || {};
    if (!runnerCfg) return { executed: false, note: NOT_EXECUTED, error: null, reason: "no isolated execution environment is configured" };
    if (spec.confirmed !== true) return { executed: false, note: NOT_EXECUTED, reason: "running a command needs your explicit confirmation" };
    const command = String(spec.command || "").trim();
    if (!command || command.length > 400) return { executed: false, note: NOT_EXECUTED, reason: "no command given" };
    if (runnerCfg.commands && !runnerCfg.commands.includes(command)) return { executed: false, note: NOT_EXECUTED, reason: "this command is not on the runner's allow-list" };
    const files = (spec.files || []).map((f) => ({ path: String(f.path), content: String(f.content) }));
    const bytes = files.reduce((n, f) => n + f.content.length, 0);
    if (bytes > runnerCfg.maxBytes) return { executed: false, note: NOT_EXECUTED, reason: "project is " + bytes + " bytes; the limit for sending to the runner is " + runnerCfg.maxBytes };
    const f = runnerCfg.fetch || (typeof root.fetch === "function" ? root.fetch.bind(root) : null);
    if (!f) return { executed: false, note: NOT_EXECUTED, reason: "fetch is not available" };
    let timer = null;
    try {
      const ctl = typeof AbortController !== "undefined" ? new AbortController() : null;
      const timeout = new Promise((_, rej) => { timer = setTimeout(() => { if (ctl) ctl.abort(); rej(Object.assign(new Error("runner timed out after " + runnerCfg.timeoutMs + " ms"), { code: "timeout" })); }, runnerCfg.timeoutMs); });
      const headers = { "Content-Type": "application/json" };
      if (runnerCfg.token) headers.Authorization = "Bearer " + runnerCfg.token;
      const call = f(runnerCfg.endpoint, { method: "POST", headers, body: JSON.stringify({ environment: runnerCfg.environment, command, files, timeoutMs: runnerCfg.timeoutMs }), signal: ctl ? ctl.signal : undefined, redirect: "error" });
      const res = await Promise.race([call, timeout]);
      if (!res || !res.ok) throw Object.assign(new Error("runner answered HTTP " + (res && res.status)), { code: "http" });
      const j = await Promise.race([res.json(), timeout]);
      return checkReport(j, command);
    } catch (e) {
      return { executed: false, note: NOT_EXECUTED, error: e.message, code: e.code || "runner_error", reason: "the runner did not return a usable result, so nothing is reported as run" };
    } finally { if (timer) clearTimeout(timer); }
  }

  /* ---------- built-in validators ---------- */
  register("static", {
    label: "Static checks (lexical, brackets, known risks)", level: "static",
    appliesTo: (p, files) => !!(files && files.length),
    run(project, files) {
      const findings = [];
      files.forEach((path) => {
        const src = project.read(path);
        if (src == null || !root.CodeAnalyzer) return;
        const a = root.CodeAnalyzer.analyze(src, path);
        a.errors.forEach((m) => findings.push({ severity: "error", path, message: m }));
        a.warnings.forEach((m) => findings.push({ severity: "warning", path, message: m }));
      });
      return { findings };
    },
  });
  register("project", {
    label: "Project consistency (imports, removed symbols, cycles, duplicates)", level: "project",
    appliesTo: (p, files, ctx) => !!ctx.baseline || !!(files && files.length),
    run(project, files, ctx) {
      const findings = [], base = ctx.baseline;
      const baseUnres = new Set((base ? base.unresolved() : []).map((u) => u.file + "|" + u.spec));
      project.unresolved().filter((u) => !baseUnres.has(u.file + "|" + u.spec)).forEach((u) => findings.push({ severity: "error", path: u.file, line: u.line, message: "import \"" + u.spec + "\" no longer resolves to a file in the project" }));
      if (base) {
        const was = new Set(base.allSymbols(["function", "class", "method", "interface", "enum"]).map((s) => s.name + "@" + s.path));
        const now = new Set(project.allSymbols(["function", "class", "method", "interface", "enum"]).map((s) => s.name + "@" + s.path));
        was.forEach((k) => {
          if (now.has(k)) return;
          const [name, path] = k.split("@");
          if (project.whereDefined(name).definitions.length) return; // moved or renamed within the project
          const uses = project.references(name).references.filter((r) => !r.definition && r.path !== path);
          if (uses.length) findings.push({ severity: "error", path: uses[0].path, line: uses[0].line, message: "\"" + name + "\" was removed from " + path + " but is still used in " + new Set(uses.map((u) => u.path)).size + " other file(s)" });
        });
        const cyc = new Set(base.cycles().map((c) => c.join(">")));
        project.cycles().filter((c) => !cyc.has(c.join(">"))).forEach((c) => findings.push({ severity: "warning", path: c[0], message: "new dependency cycle: " + c.join(" → ") }));
      }
      const seen = new Map();
      project.allSymbols(["class", "interface", "enum"]).forEach((s) => { const k = s.name; if (seen.has(k) && seen.get(k) !== s.path) findings.push({ severity: "warning", path: s.path, line: s.line, message: "type \"" + s.name + "\" is also defined in " + seen.get(k) + "; same-named types can conflict" }); else seen.set(k, s.path); });
      return { findings };
    },
  });
  register("unity-links", {
    label: "Unity script links (Missing Script causes)", level: "project",
    appliesTo: (p) => p.isUnity(),
    run(project) {
      const u = project.unityLinks(), findings = [];
      u.broken.forEach((b) => findings.push({ severity: "error", path: b.asset, message: "refers to script " + b.expectedPath + " (GUID " + b.guid.slice(0, 8) + "…) but that file is not in the project: this shows as Missing (Script) in Unity" }));
      u.mismatches.forEach((m) => findings.push({ severity: "error", path: m.path, line: m.line, message: "class " + m.cls + " does not match its file name; Unity cannot attach it to a GameObject" }));
      return { findings };
    },
  });

  root.Validation = { register, list, validate, configureRunner, runner, execute, NOT_EXECUTED, trustedEndpoint };
})();
