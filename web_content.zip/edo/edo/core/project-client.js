/* Page-side helper for workers/project-worker.js. review(files) runs in a worker when one can be created, otherwise on the page
   in time-boxed chunks via the caller's own index. The worker gets a copy of the files once and is terminated afterwards. */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  let seq = 0;
  function review(files, opts) {
    opts = opts || {};
    return new Promise((resolve, reject) => {
      if (typeof root.Worker !== "function") return reject(Object.assign(new Error("Web Workers are not available"), { code: "unsupported" }));
      let w;
      try { w = new root.Worker(opts.url || "workers/project-worker.js"); } catch (e) { return reject(Object.assign(new Error("worker could not start: " + e.message), { code: "unsupported" })); }
      const id = ++seq;
      const timer = setTimeout(() => { w.terminate(); reject(Object.assign(new Error("review timed out"), { code: "timeout" })); }, opts.timeoutMs || 60000);
      w.onmessage = (ev) => { if (!ev.data || ev.data.id !== id) return; clearTimeout(timer); w.terminate(); ev.data.ok ? resolve(ev.data.result) : reject(new Error(ev.data.error)); };
      w.onerror = (ev) => { clearTimeout(timer); w.terminate(); reject(Object.assign(new Error(ev.message || "worker failed"), { code: "worker_error" })); };
      if (opts.signal) opts.signal.addEventListener && opts.signal.addEventListener("abort", () => { clearTimeout(timer); w.terminate(); reject(Object.assign(new Error("cancelled"), { code: "cancelled" })); });
      w.postMessage({ id, type: "review", name: opts.name, files });
    });
  }
  root.ProjectClient = { review };
})();
