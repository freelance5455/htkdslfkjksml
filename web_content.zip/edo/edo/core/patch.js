/* EDO patch utility: line-based unified diff (LCS) and apply. Pure functions, no I/O. */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  function lcs(a, b) {
    const n = a.length, m = b.length, t = Array.from({ length: n + 1 }, () => new Uint32Array(m + 1));
    for (let i = n - 1; i >= 0; i--) for (let j = m - 1; j >= 0; j--) t[i][j] = a[i] === b[j] ? t[i + 1][j + 1] + 1 : Math.max(t[i + 1][j], t[i][j + 1]);
    return t;
  }
  function diffLines(oldText, newText) {
    const a = String(oldText).split("\n"), b = String(newText).split("\n");
    if (a.length * b.length > 4e6) return null; // too large for the O(nm) table on a phone
    const t = lcs(a, b), ops = [];
    let i = 0, j = 0;
    while (i < a.length && j < b.length) {
      if (a[i] === b[j]) { ops.push([" ", a[i]]); i++; j++; }
      else if (t[i + 1][j] >= t[i][j + 1]) { ops.push(["-", a[i]]); i++; }
      else { ops.push(["+", b[j]]); j++; }
    }
    while (i < a.length) ops.push(["-", a[i++]]);
    while (j < b.length) ops.push(["+", b[j++]]);
    return ops;
  }
  /* Unified diff with 2 lines of context. Returns "" when nothing changed. */
  function unified(oldText, newText, name) {
    const ops = diffLines(oldText, newText);
    if (!ops) return null;
    if (!ops.some((o) => o[0] !== " ")) return "";
    const C = 2, hunks = [];
    let k = 0;
    while (k < ops.length) {
      if (ops[k][0] === " ") { k++; continue; }
      let s = Math.max(0, k - C), e = k;
      while (e < ops.length) {
        if (ops[e][0] !== " ") { e++; continue; }
        let gap = 0; while (e + gap < ops.length && ops[e + gap][0] === " ") gap++;
        if (e + gap >= ops.length || gap > 2 * C) { e = Math.min(ops.length, e + C); break; }
        e += gap;
      }
      hunks.push([s, e]); k = e;
    }
    let oldLine = 1, newLine = 1; const pos = []; // line numbers at each op index
    ops.forEach((o) => { pos.push([oldLine, newLine]); if (o[0] !== "+") oldLine++; if (o[0] !== "-") newLine++; });
    const out = ["--- a/" + (name || "code"), "+++ b/" + (name || "code")];
    hunks.forEach(([s, e]) => {
      const seg = ops.slice(s, e), oc = seg.filter((o) => o[0] !== "+").length, nc = seg.filter((o) => o[0] !== "-").length;
      out.push("@@ -" + pos[s][0] + "," + oc + " +" + pos[s][1] + "," + nc + " @@");
      seg.forEach((o) => out.push(o[0] + o[1]));
    });
    return out.join("\n");
  }
  /* Apply a diff made by unified() to oldText. Returns {ok, text} and refuses when context does not match. */
  function apply(oldText, diff) {
    const src = String(oldText).split("\n"), out = [];
    let idx = 0;
    const lines = String(diff).split("\n");
    for (let k = 0; k < lines.length; k++) {
      const h = /^@@ -(\d+),(\d+) \+(\d+),(\d+) @@/.exec(lines[k]);
      if (!h) continue;
      const start = +h[1] - 1;
      while (idx < start) out.push(src[idx++]);
      for (k++; k < lines.length && !/^@@ /.test(lines[k]); k++) {
        const c = lines[k][0], body = lines[k].slice(1);
        if (c === " ") { if (src[idx] !== body) return { ok: false, error: "context mismatch at line " + (idx + 1) }; out.push(src[idx++]); }
        else if (c === "-") { if (src[idx] !== body) return { ok: false, error: "removed line mismatch at line " + (idx + 1) }; idx++; }
        else if (c === "+") out.push(body);
      }
      k--;
    }
    while (idx < src.length) out.push(src[idx++]);
    return { ok: true, text: out.join("\n") };
  }
  root.Patch = { unified, apply, diffLines };
})();
