/* EDO entity extraction + given validation. Finds symbol assignments (m = 2 kg) and unit-bearing quantities,
   normalises to SI, and reports impossible values, wrong units and contradictory givens BEFORE any solving.
   Symbol→dimension rules are HEURISTIC (conventional JEE symbols). UI-independent. */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  const NUMRE = "(-?\\d+(?:\\.\\d+)?(?:\\s*[eE][+-]?\\d+|\\s*[x×*]\\s*10\\s*\\^\\s*\\(?[+-]?\\d+\\)?)?)";
  const num = (s) => {
    const m = /^(-?\d+(?:\.\d+)?)(?:\s*[eE]([+-]?\d+)|\s*[x×*]\s*10\s*\^\s*\(?([+-]?\d+)\)?)?$/.exec(String(s).trim());
    return m ? parseFloat(m[1]) * Math.pow(10, +(m[2] || m[3] || 0)) : NaN;
  };
  /* Only symbols that must be non-negative in a plain JEE problem. */
  const NONNEG = { m: "mass", M: "mass", t: "time", r: "radius", R: null, l: "length", L: "length", n: null };

  function assignments(text) {
    const out = [];
    const re = new RegExp("(?<![A-Za-z0-9_])([A-Za-z][A-Za-z0-9_]{0,3})\\s*=\\s*" + NUMRE + "(?:\\s*(°C|°|[A-Za-zµμΩ][A-Za-zµμΩ\\/\\^\\-·²³0-9]*)(?![\\w]*\\s*=))?", "g");
    let m;
    while ((m = re.exec(String(text)))) {
      const unitRaw = m[3] || "";
      // a trailing word that is not a unit ("a=2 find") is not a unit
      const unitOk = unitRaw && root.Units && root.Units.parse(unitRaw);
      out.push({ symbol: m[1], value: num(m[2]), unit: unitOk ? unitRaw : "", raw: m[0].trim() });
    }
    return out;
  }
  function validate(text) {
    const as = assignments(text), errors = [], warnings = [], si = {};
    const seen = {};
    for (const a of as) {
      if (!isFinite(a.value)) { errors.push("'" + a.raw + "' is not a finite number."); continue; }
      if (a.unit) {
        const chk = root.Units.checkSymbolUnit(a.symbol, a.unit);
        if (!chk.ok) { errors.push("Wrong or unknown unit: " + chk.error + "."); continue; }
      }
      if (seen[a.symbol] !== undefined && Math.abs(seen[a.symbol] - a.value) > 1e-12 * Math.max(1, Math.abs(a.value))) {
        errors.push("Contradictory givens: " + a.symbol + " is given as both " + seen[a.symbol] + " and " + a.value + ".");
        continue;
      }
      seen[a.symbol] = a.value;
      const nn = NONNEG[a.symbol];
      if (nn && a.value < 0) errors.push("Impossible value: " + nn + " (" + a.symbol + ") cannot be negative (got " + a.value + ").");
      if ((a.symbol === "m" || a.symbol === "M") && a.value === 0 && !a.unit) warnings.push("Mass is zero; most formulas will divide by zero.");
      let v = a.value;
      if (a.unit) { const p = root.Units.parse(a.unit); if (p) v = a.value * p.f; }
      si[a.symbol] = v;
    }
    // natural-language impossible values
    const t = String(text).toLowerCase();
    const k = /temperature[^.\d-]{0,20}(-\d+(?:\.\d+)?)\s*(?:°\s*c|celsius|k\b|kelvin)/.exec(t);
    if (k) {
      const v = parseFloat(k[1]), kelvin = /k\b|kelvin/.test(k[0]);
      if (kelvin ? v < 0 : v < -273.15) errors.push("Impossible value: temperature " + v + (kelvin ? " K" : " °C") + " is below absolute zero.");
    }
    const pr = /probability[^.\d-]{0,20}(-?\d*\.?\d+)/.exec(t);
    if (pr && (+pr[1] > 1 || +pr[1] < 0)) errors.push("Impossible value: a probability must be between 0 and 1 (got " + pr[1] + ").");
    const neg = /\b(mass|time|radius|length|distance|height)\b[^.\d-]{0,15}(-\d+(?:\.\d+)?)\s*(?:kg|g|s|min|h|m|cm|km|mm)\b/.exec(t);
    if (neg) errors.push("Impossible value: " + neg[1] + " cannot be negative (got " + neg[2] + ").");
    return { assignments: as, si, errors, warnings, ok: errors.length === 0 };
  }
  /* Sentence quantities → canonical symbols BY DIMENSION (HEURISTIC). A dimension with two candidates is left unmapped
     rather than guessed. "from rest" gives u=0. Returns {givens, notes, ambiguous}. */
  const DIMSYM = [["a", [1, 0, -2, 0, 0, 0]], ["v", [1, 0, -1, 0, 0, 0]], ["t", [0, 0, 1, 0, 0, 0]], ["m", [0, 1, 0, 0, 0, 0]], ["s", [1, 0, 0, 0, 0, 0]], ["F", [1, 1, -2, 0, 0, 0]]];
  function sentenceGivens(text) {
    const t = String(text), notes = [], givens = {}, groups = {};
    const re = new RegExp(NUMRE + "\\s*(°C|[A-Za-zµμΩ][A-Za-zµμΩ\\/\\^\\-·²³0-9]*)", "g");
    let m;
    while ((m = re.exec(t))) {
      const p = root.Units && root.Units.parse(m[2]);
      if (!p) continue;
      const sym = (DIMSYM.find((d) => root.Units.sameDim(d[1], p.d)) || [])[0];
      if (!sym) continue;
      (groups[sym] = groups[sym] || []).push({ v: num(m[1]) * p.f, ctx: t.slice(Math.max(0, m.index - 30), m.index).toLowerCase() });
    }
    const ambiguous = [];
    Object.keys(groups).forEach((k) => {
      if (groups[k].length === 1) { givens[k] = groups[k][0].v; return; }
      if (k === "v" && groups[k].length === 2) {
        const [x, y] = groups[k];
        if (/initial|start|begin/.test(x.ctx) || /final|reach|attain/.test(y.ctx)) { givens.u = x.v; givens.v = y.v; notes.push("two speeds read as initial then final"); return; }
      }
      ambiguous.push(k);
    });
    if (/\b(?:from rest|starts? from rest|at rest initially|released from rest)\b/i.test(t) && !("u" in givens)) { givens.u = 0; notes.push("'from rest' read as u = 0"); }
    if (givens.v !== undefined && givens.u === undefined && !/\b(?:final|reaches|attains|after)\b/i.test(t) && /\b(?:moving|travelling|traveling|initial)\b/i.test(t)) { givens.u = givens.v; delete givens.v; }
    return { givens, notes, ambiguous };
  }
  const TARGETS = [[/kinetic energy/i, "KE"], [/potential energy/i, "PE"], [/\bwork\b/i, "W"], [/\bpower\b/i, "Pw"], [/momentum/i, "p"], [/(?:final )?(?:velocity|speed)/i, "v"], [/distance|displacement|how far/i, "s"], [/acceleration/i, "a"], [/\btime\b|how long/i, "t"], [/\bforce\b/i, "F"]];
  function targetOf(text) {
    const ask = (String(text).match(/(?:find|calculate|compute|determine|what is|how much|how far|how long)[^.?]*/gi) || [String(text)]).pop();
    let best = null;
    TARGETS.forEach(([re, sym]) => { const m = re.exec(ask); if (m && (!best || m.index < best.i)) best = { sym, i: m.index }; });
    return best ? best.sym : null;
  }
  root.Entities = { assignments, validate, num, sentenceGivens, targetOf };
})();
