/* EDO tool registry. Every capability the planner or an AI model may use is a registered tool with a declared contract:
   name, description, args schema, permissions, risk level, timeout, supportsCancellation, result schema.
   execute() never throws and never reports success unless the tool itself returned {ok:true,...} that fits its result schema.
   Statuses: success | unverified (request made, outcome cannot be confirmed) | failed | invalid_arguments | permission_denied |
             needs_confirmation | declined | unavailable | cancelled | timeout | unknown_tool.
   Globals: window.Tools (default registry), window.Tools.create() for isolated registries (tests). */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  const RISK = ["low", "medium", "high"];
  const TYPES = ["string", "number", "integer", "boolean", "object", "array"];

  function typeOk(t, v) { return t === "integer" ? Number.isInteger(v) : t === "array" ? Array.isArray(v) : t === "object" ? v !== null && typeof v === "object" && !Array.isArray(v) : typeof v === t; }
  /* Strict validation: unknown keys, wrong types, missing required, bounds, enums and patterns are all rejected. Nothing is coerced. */
  function validate(schema, input, label) {
    const errors = [], out = {};
    if (input == null) input = {};
    if (typeof input !== "object" || Array.isArray(input)) return { ok: false, errors: [(label || "arguments") + " must be an object"] };
    Object.keys(input).forEach((k) => { if (!Object.prototype.hasOwnProperty.call(schema, k)) errors.push("unknown argument: " + k); });
    Object.keys(schema).forEach((k) => {
      const s = schema[k], v = input[k];
      if (v === undefined || v === null) { if (s.required) errors.push("missing required argument: " + k); else if (s.default !== undefined) out[k] = s.default; return; }
      if (!typeOk(s.type, v)) return void errors.push(k + " must be " + s.type);
      if (s.type === "string") {
        if (/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(v)) return void errors.push(k + " contains control characters");
        if (v.length > (s.max || 2000)) return void errors.push(k + " is too long (max " + (s.max || 2000) + ")");
        if (s.min && v.length < s.min) return void errors.push(k + " is too short");
        if (s.pattern && !s.pattern.test(v)) return void errors.push(k + " has an invalid format");
      }
      if ((s.type === "number" || s.type === "integer") && (!isFinite(v) || (s.min != null && v < s.min) || (s.max != null && v > s.max))) return void errors.push(k + " is out of range");
      if (s.enum && !s.enum.includes(v)) return void errors.push(k + " must be one of " + s.enum.join(", "));
      if (s.type === "array" && v.length > (s.max || 50)) return void errors.push(k + " has too many items");
      out[k] = v;
    });
    return errors.length ? { ok: false, errors } : { ok: true, args: out };
  }
  function checkResult(schema, data) {
    if (!schema) return true;
    if (data == null || typeof data !== "object") return false;
    return Object.keys(schema).every((k) => data[k] === undefined ? !schema[k].required : typeOk(schema[k].type, data[k]));
  }

  function create(opts) {
    opts = opts || {};
    const tools = new Map(), runs = new Map();
    let seq = 0;
    const now = opts.now || (() => Date.now());
    const log = opts.log || (() => {});
    const MAX_RUNS = 100;

    const reg = {
      RISK, validate,
      register(def) {
        const bad = (m) => { throw Error("tool registration: " + m); };
        if (!def || typeof def !== "object") bad("definition required");
        if (!/^[a-z][a-z0-9_]{1,40}$/.test(def.name || "")) bad("name must be snake_case");
        if (tools.has(def.name)) bad("duplicate tool " + def.name);
        if (typeof def.description !== "string" || def.description.length < 8) bad("description required");
        if (!def.args || typeof def.args !== "object") bad("args schema required (use {} for none)");
        Object.keys(def.args).forEach((k) => { if (!TYPES.includes(def.args[k].type)) bad("arg " + k + " needs a valid type"); });
        if (!Array.isArray(def.permissions)) bad("permissions list required (use [] for none)");
        if (!RISK.includes(def.risk)) bad("risk must be low, medium or high");
        if (!(def.timeoutMs > 0 && def.timeoutMs <= 600000)) bad("timeoutMs required");
        if (typeof def.supportsCancellation !== "boolean") bad("supportsCancellation required");
        if (typeof def.run !== "function") bad("run() required");
        tools.set(def.name, Object.freeze(Object.assign({ result: null, available: null, confirmText: null, tags: [] }, def)));
        return def.name;
      },
      unregister(name) { return tools.delete(name); },
      has(name) { return tools.has(name); },
      /* Validate arguments for a tool without running it. */
      check(name, args) { const t = tools.get(name); if (!t) return { ok: false, errors: ["unknown tool"] }; return validate(t.args, args); },
      /* The contract without run(): safe to hand to an AI planner. Unavailable tools are marked, not hidden. */
      describe(name) {
        const one = (t) => { const a = t.available ? safe(() => t.available()) : { ok: true }; return { name: t.name, description: t.description, args: Object.keys(t.args).reduce((o, k) => { const s = t.args[k]; o[k] = { type: s.type, required: !!s.required, enum: s.enum, max: s.max }; return o; }, {}), permissions: t.permissions.slice(), risk: t.risk, timeoutMs: t.timeoutMs, supportsCancellation: t.supportsCancellation, result: t.result, available: a.ok !== false, unavailableReason: a.ok === false ? a.reason : undefined }; };
        if (name) { const t = tools.get(name); return t ? one(t) : null; }
        return Array.from(tools.values()).map(one);
      },
      /* execute(name, args, ctx) -> Promise<run record>. ctx: {permissions:{has(p)} | string[] | fn, confirm(info)->bool|Promise<bool>, tainted:boolean, signal, onProgress}. */
      async execute(name, args, ctx) {
        ctx = ctx || {};
        const id = "t" + ++seq;
        const rec = { id, tool: name, status: "running", ok: false, startedAt: now(), progress: [], data: null, error: null, verified: false };
        runs.set(id, rec); while (runs.size > MAX_RUNS) runs.delete(runs.keys().next().value);
        const fin = (status, error, data, extra) => { rec.status = status; rec.ok = status === "success" || status === "unverified"; rec.verified = status === "success"; rec.error = error || null; rec.data = data === undefined ? null : data; rec.endedAt = now(); Object.assign(rec, extra || {}); log("tool", { id, tool: name, status }); return rec; }; // content is never logged
        const t = tools.get(name);
        if (!t) return fin("unknown_tool", { code: "unknown_tool", message: "No tool named " + String(name).slice(0, 40) });
        const v = validate(t.args, args, "arguments for " + name);
        if (!v.ok) return fin("invalid_arguments", { code: "invalid_arguments", message: v.errors.join("; ") });
        rec.args = v.args;
        if (t.available) { const a = safe(() => t.available()); if (a.ok === false) return fin("unavailable", { code: "unavailable", message: a.reason || "capability unavailable" }); }
        const missing = t.permissions.filter((p) => !hasPermission(ctx.permissions, p));
        if (missing.length) return fin("permission_denied", { code: "permission_denied", message: "Missing permission: " + missing.join(", "), missing });
        /* Sensitive actions: medium/high always confirm; when the request came from untrusted content (tainted), every non-low tool confirms. */
        const needConfirm = t.risk === "high" || t.risk === "medium" || (ctx.tainted && t.risk !== "low");
        if (needConfirm) {
          if (typeof ctx.confirm !== "function") return fin("needs_confirmation", { code: "needs_confirmation", message: "This action needs your confirmation." }, null, { confirmText: confirmText(t, v.args) });
          let yes = false; try { yes = await ctx.confirm({ tool: name, risk: t.risk, args: v.args, text: confirmText(t, v.args), tainted: !!ctx.tainted }); } catch (e) { yes = false; }
          if (yes !== true) return fin("declined", { code: "declined", message: "You did not confirm, so nothing was done." });
        }
        const ac = typeof AbortController !== "undefined" ? new AbortController() : { signal: { aborted: false }, abort() { this.signal.aborted = true; } };
        rec._abort = () => ac.abort();
        if (ctx.signal) { if (ctx.signal.aborted) ac.abort(); else if (ctx.signal.addEventListener) ctx.signal.addEventListener("abort", () => ac.abort()); }
        let timer, timedOut = false;
        const guard = new Promise((res) => {
          timer = setTimeout(() => { timedOut = true; ac.abort(); res({ __to: true }); }, t.timeoutMs);
          if (ac.signal.addEventListener) ac.signal.addEventListener("abort", () => res(timedOut ? { __to: true } : { __cancel: true }));
        });
        const progress = (p) => { rec.progress.push({ t: now(), p }); if (rec.progress.length > 50) rec.progress.shift(); if (ctx.onProgress) safe(() => ctx.onProgress(p, rec)); };
        let out;
        if (ac.signal.aborted) out = { __cancel: true };
        else out = await Promise.race([Promise.resolve().then(() => t.run(v.args, { signal: ac.signal, progress })).catch((e) => ({ __err: e })), guard]);
        clearTimeout(timer);
        if (rec.status === "cancelled") return rec; // cancel() already settled it
        if (out && out.__to) return fin("timeout", { code: "timeout", message: name + " did not finish within " + t.timeoutMs + " ms. Its outcome is unknown." });
        if (out && out.__cancel) return fin("cancelled", { code: "cancelled", message: "Cancelled. A request already handed to the phone may still have happened." });
        if (out && out.__err) { const e = out.__err; return fin("failed", { code: (e && e.code) || "tool_error", message: String((e && e.message) || e).slice(0, 300), retryable: !!(e && (e.code === "timeout" || e.retryable)) }); }
        /* A tool succeeds only by saying so, with data that fits its declared result schema. */
        if (!out || typeof out !== "object" || out.ok !== true) return fin("failed", { code: (out && out.code) || "tool_failed", message: String((out && out.message) || "The tool did not report success.").slice(0, 300), retryable: !!(out && out.retryable) });
        if (!checkResult(t.result, out.data)) return fin("failed", { code: "bad_result", message: "The tool's result did not match its declared schema, so it is not treated as success." });
        return fin(out.verified === false ? "unverified" : "success", null, out.data == null ? {} : out.data, { note: out.note ? String(out.note).slice(0, 200) : undefined });
      },
      cancel(id) {
        const r = runs.get(id); if (!r || r.status !== "running") return { ok: false, reason: r ? "already " + r.status : "unknown run" };
        const t = tools.get(r.tool);
        if (!t.supportsCancellation) return { ok: false, reason: t.name + " cannot be cancelled once started" };
        r.status = "cancelled"; r.ok = false; r.error = { code: "cancelled", message: "Cancelled by the user." }; r.endedAt = now();
        if (r._abort) r._abort();
        return { ok: true };
      },
      progress(id) { const r = runs.get(id); return r ? r.progress.slice() : null; },
      result(id) { const r = runs.get(id); if (!r) return null; const c = Object.assign({}, r); delete c._abort; return c; },
      runs() { return Array.from(runs.values()).map((r) => ({ id: r.id, tool: r.tool, status: r.status })); },
    };
    return reg;
  }
  function safe(fn) { try { return fn() || { ok: true }; } catch (e) { return { ok: false, reason: e.message }; } }
  function hasPermission(p, name) {
    if (!p) return false;
    if (typeof p === "function") return !!safe2(() => p(name));
    if (Array.isArray(p)) return p.includes(name);
    if (typeof p.has === "function") return !!safe2(() => p.has(name));
    return p[name] === true;
  }
  function safe2(fn) { try { return fn(); } catch (e) { return false; } }
  function confirmText(t, args) { try { return t.confirmText ? t.confirmText(args) : "Run " + t.name + "?"; } catch (e) { return "Run " + t.name + "?"; } }
  root.Tools = Object.assign(create(), { create });
})();
