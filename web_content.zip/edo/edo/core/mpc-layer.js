/* EDO MPC/JEE reasoning layer. Wraps the existing, verified solving pipeline (Entities → Reasoner/Solver → Verify) and adds what
   a student needs around the number, WITHOUT changing the number: the chapter detected, a conceptual note, an alternate method from
   the reviewed notes, physical sanity checks on the printed answer, and a clarifying question when the problem is ambiguous.
   It never computes or guesses a value; if the pipeline did not produce a verified answer, this layer says what is missing.
   Globals: window.MPC */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  const C = 299792458;

  /* sanity rules over "symbol = number unit" fragments in the answer text */
  const RULES = [
    [/\b(?:v|speed|velocity)\s*=\s*(-?[\d.]+(?:e[+-]?\d+)?)\s*(?:m\/s|m s)/i, (x) => Math.abs(x) > C, "this speed is faster than light (3×10⁸ m/s), which is impossible for a massive object"],
    [/\b(?:t|time)\s*=\s*(-[\d.]+(?:e[+-]?\d+)?)\s*(?:s|seconds)/i, () => true, "a negative time means the event happened before t = 0; check the sign convention or which root you took"],
    [/\b(?:m|mass)\s*=\s*(-[\d.]+)\s*(?:kg|g)\b/i, () => true, "mass cannot be negative"],
    [/\b(?:T|temperature)\s*=\s*(-[\d.]+)\s*K\b/i, () => true, "a temperature below 0 K is impossible"],
    [/\b(?:efficiency|η)\s*=\s*([\d.]+)\s*%/i, (x) => x > 100, "efficiency above 100% would violate energy conservation"],
    [/\b(?:probability|P)\s*=\s*(-?[\d.]+)(?!\s*[a-zA-Z/%])/i, (x) => x < 0 || x > 1, "a probability must lie between 0 and 1"],
    [/\b(?:r|radius|d|distance|length)\s*=\s*(-[\d.]+)\s*(?:m|cm|mm|km)\b/i, () => true, "a length or distance cannot be negative; you may need its magnitude"],
  ];
  function sanity(text) {
    const flags = [], body = String(text).replace(/:::working[\s\S]*?:::/g, "");
    RULES.forEach(([re, bad, msg]) => { const m = re.exec(body); if (m && bad(parseFloat(m[1]))) flags.push(msg); });
    return flags;
  }
  function topic(raw) {
    if (!root.EDOKnowledge || !root.EDOKnowledge.rank) return null;
    const r = root.EDOKnowledge.rank(raw, { limit: 1 });
    return r.length && r[0].score >= 6 ? r[0].doc : null;
  }
  /* augment(result, raw) → same result with .mpc = {chapter, concept, alternate, sanity[], confidence} and a short appended note */
  function augment(res, raw) {
    if (!res || res.kind !== "reason") return res;
    const doc = topic(raw), st = res.state || {};
    const verified = /verified|checked/i.test(st.status || "") && !/not verified/i.test(st.status || "");
    const flags = verified ? sanity(res.text) : [];
    const out = { chapter: doc ? doc.chapter : null, domain: doc ? doc.domain : null, concept: doc && doc.summary ? doc.summary : null, alternate: doc && doc.methods && doc.methods[1] ? doc.methods[1] : null, sanity: flags, confidence: typeof st.confidence === "number" ? st.confidence : null, status: st.status || null };
    const lines = [];
    if (flags.length) lines.push("**Sanity check:** " + flags.join("; ") + ".");
    if (verified && out.concept) lines.push("**Concept:** " + out.concept);
    if (verified && out.alternate) lines.push("**Another way:** " + out.alternate);
    if (!verified && /need|missing|which|cannot|won't/i.test(res.text)) lines.push("**To go further I need:** the missing quantity or a clear target (what exactly should I find, and in which units?). I will not guess a value.");
    res.mpc = out;
    if (lines.length) res.text = res.text + "\n\n" + lines.join("\n");
    return res;
  }
  root.MPC = { augment, sanity, topic };
})();
