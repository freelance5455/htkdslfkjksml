/* EDO project workspace. Builds a connected model of a code project from files the user provides (a picked folder or
   files; nothing is read from disk by this module):

     files → imports → resolved dependencies → symbols (definitions) → usages (references)

   plus entry points, manifests/dependencies, ignore rules, generated-file detection, and Unity assets (scene/prefab → script
   links through .meta GUIDs). It answers "where is X defined", "what uses X", "what depends on this file", "what could break
   if I change it", across files.

   How it works and how far to trust it: it is a lexical index (comments and strings are blanked, then per-language patterns
   extract imports and definitions, and identifier occurrences are matched to definitions by name). It is not a compiler. There is
   no type resolution, so two symbols with the same name are reported as ambiguous instead of guessed, and dynamic imports,
   reflection and string-built names are invisible. Results carry that caveat.

   Performance: indexAsync() works in time-boxed chunks and yields to the event loop so the UI stays responsive; updateFile()
   re-indexes one file and relinks only what changed. The same module runs inside a Web Worker (workers/project-worker.js).
   It never executes project code. Globals: window.Project (or self.Project inside a worker) */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;

  const LIMITS = { files: 3000, fileBytes: 400000, totalBytes: 25000000, lineLen: 2000, recentEdits: 20, recentErrors: 20 };
  const IGNORE_DIRS = new Set(["node_modules", ".git", ".svn", ".hg", "dist", "build", "out", "bin", "obj", "library", "temp", "logs", "usersettings", ".gradle", ".idea", ".vs", ".vscode", "__pycache__", "venv", ".venv", "env", "coverage", ".next", ".nuxt", "target", "pods", "deriveddata", ".dart_tool", "packages/cache"]);
  const BINARY_EXT = /\.(png|jpe?g|gif|webp|bmp|ico|psd|tga|tif|tiff|mp3|wav|ogg|mp4|mov|avi|zip|gz|tar|7z|rar|jar|aar|apk|aab|so|dll|exe|pdb|class|dex|fbx|obj|blend|ttf|otf|woff2?|eot|pdf|bin|dat|unitypackage|lock)$/i;
  const GENERATED_NAMES = /(^|\/)(package-lock\.json|yarn\.lock|pnpm-lock\.yaml|composer\.lock|gradle\.lockfile)$|\.min\.(js|css)$|\.designer\.cs$|\.g\.cs$|\.generated\.\w+$|\.pb\.\w+$/i;
  const LANG_BY_EXT = { js: "javascript", mjs: "javascript", cjs: "javascript", jsx: "javascript", ts: "typescript", tsx: "typescript", py: "python", cs: "csharp", java: "java", kt: "kotlin", kts: "kotlin", c: "c", h: "c", cc: "cpp", cpp: "cpp", hpp: "cpp", go: "go", rs: "rust", json: "json", html: "html", css: "css", xml: "xml", gradle: "gradle", yml: "yaml", yaml: "yaml", md: "markdown", unity: "unity-yaml", prefab: "unity-yaml", asset: "unity-yaml", meta: "meta", csproj: "xml", sln: "text", txt: "text", shader: "shader", cginc: "shader" };
  const SOURCE_LANGS = new Set(["javascript", "typescript", "python", "csharp", "java", "kotlin", "c", "cpp", "go", "rust"]);
  const norm = (p) => String(p || "").replace(/\\/g, "/").replace(/^\.?\//, "").replace(/\/{2,}/g, "/");
  const extOf = (p) => { const m = /\.([A-Za-z0-9]+)$/.exec(p); return m ? m[1].toLowerCase() : ""; };
  const dirOf = (p) => { const i = p.lastIndexOf("/"); return i < 0 ? "" : p.slice(0, i); };
  const baseOf = (p) => p.slice(p.lastIndexOf("/") + 1);
  function hash(s) { let h = 5381; for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0; return (h >>> 0).toString(36) + ":" + s.length; }
  function langOf(path) { return LANG_BY_EXT[extOf(path)] || (/(^|\/)(dockerfile|makefile)$/i.test(path) ? "text" : "other"); }

  /* blank out comments and string contents but keep line structure, so offsets and line numbers still match */
  function strip(src, lang) {
    const hashComment = lang === "python" || lang === "yaml" || lang === "gradle" && false;
    const out = [];
    const n = src.length;
    let i = 0;
    const blank = (s) => s.replace(/[^\n]/g, " ");
    while (i < n) {
      const c = src[i], d = src[i + 1];
      if (hashComment && c === "#") { let j = i; while (j < n && src[j] !== "\n") j++; out.push(blank(src.slice(i, j))); i = j; continue; }
      if (lang === "python" && (src.startsWith('"""', i) || src.startsWith("'''", i))) {
        const q = src.substr(i, 3); let j = src.indexOf(q, i + 3); j = j < 0 ? n : j + 3; out.push(blank(src.slice(i, j))); i = j; continue;
      }
      if (lang !== "python" && c === "/" && d === "/") { let j = i; while (j < n && src[j] !== "\n") j++; out.push(blank(src.slice(i, j))); i = j; continue; }
      if (lang !== "python" && c === "/" && d === "*") { let j = src.indexOf("*/", i + 2); j = j < 0 ? n : j + 2; out.push(blank(src.slice(i, j))); i = j; continue; }
      if (c === '"' || c === "'" || (c === "`" && (lang === "javascript" || lang === "typescript" || lang === "go"))) {
        if (lang === "csharp" && c === '"' && src[i - 1] === "@") { // verbatim string
          let j = i + 1; while (j < n) { if (src[j] === '"' && src[j + 1] === '"') j += 2; else if (src[j] === '"') break; else j++; }
          out.push('"' + blank(src.slice(i + 1, j)) + '"'); i = j + 1; continue;
        }
        let j = i + 1;
        while (j < n && src[j] !== c) { if (src[j] === "\\") j++; else if (src[j] === "\n" && c !== "`") break; j++; }
        // keep the quotes and the raw text of short module-like strings so import specifiers survive
        const inner = src.slice(i + 1, Math.min(j, n));
        out.push(inner.length <= 200 && !/\n/.test(inner) ? "\u0001" + inner + "\u0002" : c + blank(inner) + (src[j] === c ? c : "")); i = j + 1; continue;
      }
      out.push(c); i++;
    }
    return out.join("");
  }
  /* version used for identifier scanning: string contents removed completely */
  const noStr = (s) => s.replace(/\u0001[^\u0002]*\u0002/g, (m) => " ".repeat(m.length)); // same length, so offsets and line numbers stay valid
  const keepStr = (s) => s.replace(/[\u0001\u0002]/g, "");

  const KEYWORDS = new Set("if else for while do switch case break continue return new delete typeof instanceof void this super null true false undefined var let const function class interface enum extends implements import export from as default try catch finally throw throws async await yield static public private protected internal abstract final override virtual readonly sealed partial namespace using package int long short byte char float double bool boolean string object in is not and or def lambda pass None True False self fn mut pub impl struct trait use mod where fun val when object companion data open lateinit".split(" "));

  /* ---------- per-language extraction ---------- */
  function lineOf(text, idx) { let n = 1; for (let i = 0; i < idx; i++) if (text.charCodeAt(i) === 10) n++; return n; }
  function lineIndex(text) { const starts = [0]; for (let i = 0; i < text.length; i++) if (text.charCodeAt(i) === 10) starts.push(i + 1); return starts; }
  function lineAt(starts, idx) { let lo = 0, hi = starts.length - 1; while (lo < hi) { const mid = (lo + hi + 1) >> 1; if (starts[mid] <= idx) lo = mid; else hi = mid - 1; } return lo + 1; }

  const EXTRACT = {
    javascript(text, starts) { return jsLike(text, starts, false); },
    typescript(text, starts) { return jsLike(text, starts, true); },
    python(text, starts) {
      const imports = [], symbols = [];
      let m;
      const imp = /^[ \t]*import[ \t]+([\w.]+(?:[ \t]*,[ \t]*[\w.]+)*)/gm;
      while ((m = imp.exec(text))) m[1].split(",").forEach((x) => imports.push({ spec: x.trim().split(/\s+as\s+/)[0], line: lineAt(starts, m.index), kind: "import" }));
      const frm = /^[ \t]*from[ \t]+(\.*[\w.]*)[ \t]+import[ \t]+([^\n]+)/gm;
      while ((m = frm.exec(text))) imports.push({ spec: m[1], names: m[2].replace(/[()]/g, "").split(",").map((s) => s.trim().split(/\s+as\s+/)[0]).filter(Boolean), line: lineAt(starts, m.index), kind: "from" });
      const defs = /^([ \t]*)(async[ \t]+def|def|class)[ \t]+([A-Za-z_]\w*)/gm;
      const stack = [];
      while ((m = defs.exec(text))) {
        const ind = m[1].replace(/\t/g, "    ").length, line = lineAt(starts, m.index);
        while (stack.length && stack[stack.length - 1].ind >= ind) stack.pop();
        const container = stack.length ? stack[stack.length - 1].name : null;
        const isClass = m[2] === "class";
        symbols.push({ name: m[3], kind: isClass ? "class" : container && stack[stack.length - 1].kind === "class" ? "method" : "function", line, container, exported: !m[3].startsWith("_") && !container });
        stack.push({ ind, name: m[3], kind: isClass ? "class" : "function" });
      }
      return { imports, symbols };
    },
    csharp(text, starts) {
      const imports = [], symbols = [];
      let m;
      const us = /^[ \t]*using[ \t]+(?:static[ \t]+)?([\w.]+)[ \t]*;/gm;
      while ((m = us.exec(text))) imports.push({ spec: m[1], line: lineAt(starts, m.index), kind: "using" });
      const ns = /\bnamespace[ \t]+([\w.]+)/g;
      const namespaces = [];
      while ((m = ns.exec(text))) namespaces.push(m[1]);
      const closeOf = (open) => { let d = 0; for (let i = open; i < text.length; i++) { const ch = text.charCodeAt(i); if (ch === 123) d++; else if (ch === 125) { d--; if (d === 0) return i; } } return text.length; };
      const depthAt = (idx) => { let d = 0; for (let i = 0; i < idx; i++) { const ch = text.charCodeAt(i); if (ch === 123) d++; else if (ch === 125) d--; } return d; };
      const cls = /\b(?:(?:public|internal|private|protected|static|abstract|sealed|partial|readonly)\s+)*(class|struct|interface|enum|record)\s+([A-Za-z_]\w*)(?:\s*<[^>{]*>)?(?:\s*:\s*([^{]+?))?\s*(?:where[^{]*)?\{/g;
      const classes = [];
      while ((m = cls.exec(text))) {
        const bases = m[3] ? m[3].split(",").map((s) => s.trim().replace(/<.*$/, "")).filter(Boolean) : [];
        const open = text.indexOf("{", m.index + m[0].length - 1);
        classes.push({ name: m[2], kind: m[1], index: m.index, open, end: closeOf(open), depth: depthAt(open), line: lineAt(starts, m.index), bases });
        symbols.push({ name: m[2], kind: m[1] === "interface" ? "interface" : m[1] === "enum" ? "enum" : "class", line: lineAt(starts, m.index), container: null, exported: /\bpublic\b/.test(text.slice(Math.max(0, m.index - 0), m.index + 40)) || true, bases });
      }
      // methods: brace-depth aware, attach to the nearest preceding class
      const meth = /(?:^|[;{}\n])[ \t]*(?:\[[^\]\n]*\][ \t]*\n?[ \t]*)*((?:(?:public|private|protected|internal|static|override|virtual|abstract|async|sealed|extern|new|unsafe)\s+)*)([A-Za-z_][\w<>\[\],.? ]*?)\s+([A-Za-z_]\w*)\s*(?:<[^>()]*>)?\s*\(([^)]*)\)\s*(?:where[^{;]*)?(\{|=>|;)/g;
      while ((m = meth.exec(text))) {
        const name = m[3], ret = m[2].trim();
        if (KEYWORDS.has(name) || /^(if|for|foreach|while|switch|using|lock|return|new|catch|else|typeof|nameof|sizeof)$/.test(name) || /^(return|new|else|throw|await|var|case)$/.test(ret.split(/\s+/)[0])) continue;
        if (m[5] === ";" && !/\babstract\b|\binterface\b/.test(m[1])) continue; // a call statement, not a declaration
        const idx = m.index + m[0].indexOf(name);
        const owner = classes.filter((c) => c.open < idx && idx < c.end).pop();
        if (!owner || depthAt(idx) !== owner.depth + 1) continue; // calls and locals inside method bodies are not declarations
        symbols.push({ name, kind: "method", line: lineAt(starts, idx), container: owner ? owner.name : null, exported: /\bpublic\b/.test(m[1]), signature: ret + " " + name + "(" + m[4].replace(/\s+/g, " ").trim() + ")" });
      }
      const ctor = null;
      // fields with attributes (Unity): [SerializeField] private Type name;  public Type name;
      const fld = /((?:\[[^\]\n]+\]\s*)*)\b(public|private|protected|internal)?\s*(?:static\s+|readonly\s+)*([A-Za-z][\w<>\[\],.?]*)\s+([a-zA-Z_]\w*)\s*(?:=[^;]*)?;/g;
      const fields = [];
      while ((m = fld.exec(text))) {
        const idx = m.index + m[0].lastIndexOf(m[4]);
        const owner = classes.filter((c) => c.open < idx && idx < c.end).pop();
        if (!owner || depthAt(idx) !== owner.depth + 1 || /\b(return|new|throw|using)\b/.test(m[3])) continue;
        fields.push({ name: m[4], type: m[3], access: m[2] || "private", attrs: m[1].trim(), line: lineAt(starts, idx), container: owner.name });
        symbols.push({ name: m[4], kind: "field", line: lineAt(starts, idx), container: owner.name, exported: m[2] === "public" });
      }
      return { imports, symbols, namespaces, classes, fields };
    },
    java(text, starts) { return javaLike(text, starts, false); },
    kotlin(text, starts) { return javaLike(text, starts, true); },
    c(text, starts) { return cLike(text, starts); },
    cpp(text, starts) { return cLike(text, starts); },
    go(text, starts) {
      const imports = [], symbols = [];
      let m;
      const blk = /\bimport\s*\(([\s\S]*?)\)/g;
      while ((m = blk.exec(text))) (m[1].match(/\u0001[^\u0002]+\u0002/g) || []).forEach((s) => imports.push({ spec: s.slice(1, -1), line: lineAt(starts, m.index), kind: "import" }));
      const one = /^\s*import\s+(?:\w+\s+)?\u0001([^\u0002]+)\u0002/gm;
      while ((m = one.exec(text))) imports.push({ spec: m[1], line: lineAt(starts, m.index), kind: "import" });
      const fn = /^func\s+(?:\(\s*\w+\s+\*?(\w+)\s*\)\s*)?([A-Za-z_]\w*)/gm;
      while ((m = fn.exec(text))) symbols.push({ name: m[2], kind: m[1] ? "method" : "function", line: lineAt(starts, m.index), container: m[1] || null, exported: /^[A-Z]/.test(m[2]) });
      const ty = /^type\s+([A-Za-z_]\w*)\s+(struct|interface)/gm;
      while ((m = ty.exec(text))) symbols.push({ name: m[1], kind: m[2] === "interface" ? "interface" : "class", line: lineAt(starts, m.index), container: null, exported: /^[A-Z]/.test(m[1]) });
      return { imports, symbols };
    },
    rust(text, starts) {
      const imports = [], symbols = [];
      let m;
      const use = /^\s*(?:pub\s+)?use\s+([\w:]+)/gm;
      while ((m = use.exec(text))) imports.push({ spec: m[1], line: lineAt(starts, m.index), kind: "use" });
      const mod = /^\s*(?:pub\s+)?mod\s+(\w+)\s*;/gm;
      while ((m = mod.exec(text))) imports.push({ spec: "./" + m[1], line: lineAt(starts, m.index), kind: "mod" });
      const def = /^\s*(pub\s+)?(fn|struct|enum|trait)\s+([A-Za-z_]\w*)/gm;
      while ((m = def.exec(text))) symbols.push({ name: m[3], kind: m[2] === "fn" ? "function" : m[2] === "trait" ? "interface" : "class", line: lineAt(starts, m.index), container: null, exported: !!m[1] });
      return { imports, symbols };
    },
  };

  function jsLike(text, starts, ts) {
    const imports = [], symbols = [];
    let m;
    const add = (spec, idx, kind) => imports.push({ spec, line: lineAt(starts, idx), kind });
    const s1 = /\bimport\s+(?:type\s+)?(?:[\w*${}\s,]+?\s+from\s+)?\u0001([^\u0002]+)\u0002/g;
    while ((m = s1.exec(text))) add(m[1], m.index, "import");
    const s2 = /\bexport\s+(?:type\s+)?(?:\*|\{[^}]*\})\s*(?:as\s+\w+\s*)?from\s+\u0001([^\u0002]+)\u0002/g;
    while ((m = s2.exec(text))) add(m[1], m.index, "reexport");
    const s3 = /\brequire\s*\(\s*\u0001([^\u0002]+)\u0002\s*\)/g;
    while ((m = s3.exec(text))) add(m[1], m.index, "require");
    const s4 = /\bimport\s*\(\s*\u0001([^\u0002]+)\u0002\s*\)/g;
    while ((m = s4.exec(text))) add(m[1], m.index, "dynamic");
    const body = noStr(text);
    const fn = /(^|[\s;}])(export\s+(?:default\s+)?)?(?:async\s+)?function\s*\*?\s*([A-Za-z_$][\w$]*)/g;
    while ((m = fn.exec(body))) symbols.push({ name: m[3], kind: "function", line: lineAt(starts, m.index + m[1].length), container: null, exported: !!m[2] });
    const cls = /(^|[\s;}])(export\s+(?:default\s+)?)?(?:abstract\s+)?class\s+([A-Za-z_$][\w$]*)(?:\s+extends\s+([\w$.]+))?/g;
    const classes = [];
    while ((m = cls.exec(body))) { const line = lineAt(starts, m.index + m[1].length); classes.push({ name: m[3], index: m.index, line, bases: m[4] ? [m[4]] : [] }); symbols.push({ name: m[3], kind: "class", line, container: null, exported: !!m[2], bases: m[4] ? [m[4]] : [] }); }
    const arrow = /(^|[\s;}])(export\s+)?(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*(?::[^=]+)?=\s*(?:async\s*)?(?:function\b|\([^)]*\)\s*(?::[^=]+)?=>|[A-Za-z_$][\w$]*\s*=>)/g;
    while ((m = arrow.exec(body))) symbols.push({ name: m[3], kind: "function", line: lineAt(starts, m.index + m[1].length), container: null, exported: !!m[2] });
    const konst = /(^|[\s;}])(export\s+)?const\s+([A-Z][A-Z0-9_]{2,})\s*=/g;
    while ((m = konst.exec(body))) symbols.push({ name: m[3], kind: "constant", line: lineAt(starts, m.index + m[1].length), container: null, exported: !!m[2] });
    if (ts) {
      const ty = /(^|[\s;}])(export\s+)?(interface|type|enum)\s+([A-Za-z_$][\w$]*)/g;
      while ((m = ty.exec(body))) symbols.push({ name: m[4], kind: m[3] === "enum" ? "enum" : "interface", line: lineAt(starts, m.index + m[1].length), container: null, exported: !!m[2] });
    }
    // class methods: `name(args) {` at a depth inside a class body
    classes.forEach((c, ci) => {
      const open = body.indexOf("{", c.index);
      if (open < 0) return;
      let depth = 0, end = body.length;
      for (let i = open; i < body.length; i++) { const ch = body[i]; if (ch === "{") depth++; else if (ch === "}") { depth--; if (depth === 0) { end = i; break; } } }
      const seg = body.slice(open + 1, end), base = open + 1;
      let d = 0, k = 0;
      const mm = /(^|\n)[ \t]*(?:(?:public|private|protected|static|async|get|set|readonly|override|abstract)\s+)*([A-Za-z_$#][\w$#]*)\s*(?:<[^>]*>)?\s*\(([^)]*)\)\s*(?::\s*[^{;]+)?\{/g;
      let x;
      while ((x = mm.exec(seg))) {
        let depthAt = 0; for (let i = 0; i < x.index + x[1].length; i++) { if (seg[i] === "{") depthAt++; else if (seg[i] === "}") depthAt--; }
        if (depthAt !== 0 || /^(if|for|while|switch|catch|function|return)$/.test(x[2])) continue;
        symbols.push({ name: x[2], kind: "method", line: lineAt(starts, base + x.index + x[1].length), container: c.name, exported: !x[2].startsWith("#") && !x[2].startsWith("_") });
      }
    });
    return { imports, symbols, classes };
  }
  function javaLike(text, starts, kotlin) {
    const imports = [], symbols = [];
    let m;
    const imp = /^[ \t]*import[ \t]+(?:static[ \t]+)?([\w.]+(?:\.\*)?)/gm;
    while ((m = imp.exec(text))) imports.push({ spec: m[1], line: lineAt(starts, m.index), kind: "import" });
    const pk = /^[ \t]*package[ \t]+([\w.]+)/m.exec(text);
    const cls = kotlin
      ? /\b(?:(?:public|private|protected|internal|abstract|open|final|sealed|data|enum|annotation|inline)\s+)*(class|interface|object)\s+([A-Za-z_]\w*)(?:\s*<[^>]*>)?(?:\s*\([^)]*\))?(?:\s*:\s*([^{\n]+?))?\s*(?:\{|\n)/g
      : /\b(?:(?:public|private|protected|abstract|final|static|sealed)\s+)*(class|interface|enum|record)\s+([A-Za-z_]\w*)(?:\s*<[^>]*>)?(?:\s+extends\s+([\w.<>]+))?(?:\s+implements\s+([\w.,<> ]+))?\s*\{/g;
    const classes = [];
    while ((m = cls.exec(text))) {
      const bases = (m[3] || "").concat(",", m[4] || "").split(",").map((s) => s.trim().replace(/<.*$/, "").replace(/\(.*$/, "")).filter(Boolean);
      classes.push({ name: m[2], index: m.index, line: lineAt(starts, m.index), bases });
      symbols.push({ name: m[2], kind: m[1] === "interface" ? "interface" : m[1] === "enum" ? "enum" : "class", line: lineAt(starts, m.index), container: null, exported: !/\bprivate\b/.test(m[0]), bases });
    }
    const meth = kotlin
      ? /\bfun\s+(?:<[^>]*>\s*)?(?:[\w.]+\.)?([A-Za-z_]\w*)\s*\(/g
      : /(?:^|[;{}\n])[ \t]*(?:@\w+(?:\([^)]*\))?\s*)*(?:(?:public|private|protected|static|final|abstract|synchronized|native|default)\s+)*(?:<[^>]*>\s*)?[\w<>\[\],.? ]+?\s+([A-Za-z_]\w*)\s*\(([^)]*)\)\s*(?:throws\s+[\w., ]+)?\s*\{/g;
    while ((m = meth.exec(text))) {
      const name = m[1];
      if (KEYWORDS.has(name) || /^(if|for|while|switch|catch|synchronized|return|new)$/.test(name)) continue;
      const idx = m.index + m[0].lastIndexOf(name);
      const owner = classes.filter((c) => c.index < idx).pop();
      symbols.push({ name, kind: "method", line: lineAt(starts, idx), container: owner ? owner.name : null, exported: !/\bprivate\b/.test(m[0]) });
    }
    return { imports, symbols, package: pk ? pk[1] : null, classes };
  }
  function cLike(text, starts) {
    const imports = [], symbols = [];
    let m;
    const inc = /^[ \t]*#[ \t]*include[ \t]*(?:\u0001([^\u0002]+)\u0002|<([^>]+)>)/gm;
    const raw = text.replace(/[\u0001\u0002]/g, "");
    while ((m = inc.exec(text))) imports.push({ spec: m[1] || m[2], line: lineAt(starts, m.index), kind: m[1] ? "include" : "system" });
    const fn = /^[ \t]*(?:[\w:*&<>]+[ \t]+)+\**([A-Za-z_]\w*)\s*\(([^;{)]*)\)\s*(?:const\s*)?\{/gm;
    while ((m = fn.exec(raw))) { if (!KEYWORDS.has(m[1]) && !/^(if|for|while|switch|return)$/.test(m[1])) symbols.push({ name: m[1], kind: "function", line: lineAt(starts, m.index + m[0].indexOf(m[1])), container: null, exported: !/\bstatic\b/.test(m[0]) }); }
    const ty = /\b(class|struct)\s+([A-Za-z_]\w*)\s*(?::[^{]+)?\{/g;
    while ((m = ty.exec(raw))) symbols.push({ name: m[2], kind: "class", line: lineAt(starts, m.index), container: null, exported: true });
    return { imports, symbols };
  }

  /* ---------- the workspace ---------- */
  function create(opts) {
    opts = opts || {};
    const ws = {
      name: opts.name || "project",
      files: new Map(),      // path → record
      ignored: [],            // {path, reason}
      guidToPath: new Map(),  // Unity asset GUID → path
      edges: new Map(),       // path → Set(paths) it depends on
      reverse: new Map(),     // path → Set(paths) that depend on it
      external: new Map(),    // path → [bare module names]
      unresolved: [],         // {file, spec, line}
      symbolTable: new Map(), // name → [{path, ...symbol}]
      namespaceMap: new Map(),// csharp/java namespace or package → [paths]
      classMap: new Map(),    // java/kotlin "pkg.Class" → path
      assetLinks: new Map(),  // script path → [{path, kind}] scenes/prefabs that attach it
      manifests: {},
      live: { activeFile: null, selection: null, task: null, recentEdits: [], recentErrors: [] },
      truncated: null, totalBytes: 0, version: 0,
    };
    const api = {};
    let dirty = true;

    /* ---- ignore handling ---- */
    let gitignore = [];
    function parseGitignore(text) {
      gitignore = String(text || "").split("\n").map((l) => l.trim()).filter((l) => l && !l.startsWith("#") && !l.startsWith("!")).map((l) => {
        const dir = l.endsWith("/"), pat = l.replace(/^\//, "").replace(/\/$/, "");
        const re = new RegExp("(^|/)" + pat.replace(/[.+^${}()|[\]\\]/g, "\\$&").replace(/\*\*/g, "\u0003").replace(/\*/g, "[^/]*").replace(/\u0003/g, ".*").replace(/\?/g, "[^/]") + (dir ? "(/|$)" : "(/|$)"));
        return re;
      });
    }
    function ignoreReason(path) {
      const parts = path.toLowerCase().split("/");
      for (let i = 0; i < parts.length - 1; i++) if (IGNORE_DIRS.has(parts[i])) return "ignored folder: " + parts[i];
      if (BINARY_EXT.test(path) && !/\.meta$/.test(path)) return "binary or lock file";
      if (gitignore.some((re) => re.test(path))) return "matches .gitignore";
      return null;
    }

    function parseManifest(path, text) {
      const b = baseOf(path).toLowerCase();
      try {
        if (b === "package.json") { const j = JSON.parse(text); ws.manifests[path] = { kind: "npm", name: j.name, main: j.main, bin: j.bin, scripts: j.scripts || {}, dependencies: Object.keys(j.dependencies || {}), devDependencies: Object.keys(j.devDependencies || {}) }; }
        else if (b === "manifest.json" && /packages\//i.test(path)) { const j = JSON.parse(text); ws.manifests[path] = { kind: "unity-packages", dependencies: Object.keys(j.dependencies || {}) }; }
        else if (b === "requirements.txt") ws.manifests[path] = { kind: "pip", dependencies: text.split("\n").map((l) => l.trim().split(/[=<>~! ]/)[0]).filter((l) => l && !l.startsWith("#")) };
        else if (/\.csproj$/i.test(b)) ws.manifests[path] = { kind: "csproj", dependencies: (text.match(/PackageReference\s+Include="([^"]+)"/g) || []).map((s) => s.replace(/.*Include="/, "").replace(/"$/, "")) };
        else if (/^build\.gradle(\.kts)?$/.test(b)) ws.manifests[path] = { kind: "gradle", dependencies: (text.match(/(?:implementation|api|testImplementation|kapt|ksp)\s*\(?\s*["']([^"']+)["']/g) || []).map((s) => s.replace(/.*["']([^"']+)["']/, "$1")) };
        else if (b === "projectversion.txt") ws.manifests[path] = { kind: "unity-version", version: (/m_EditorVersion:\s*(\S+)/.exec(text) || [])[1] || null };
        else if (b === "androidmanifest.xml") ws.manifests[path] = { kind: "android-manifest", activities: (text.match(/<activity[^>]*android:name="([^"]+)"/g) || []).map((s) => s.replace(/.*name="/, "").replace(/"$/, "")) };
      } catch (e) { ws.manifests[path] = { kind: "unreadable", error: String(e.message).slice(0, 80) }; }
    }

    /* ---- indexing one file ---- */
    function indexOne(path, content) {
      path = norm(path);
      content = String(content == null ? "" : content);
      if (path === ".gitignore") parseGitignore(content);
      const why = ignoreReason(path);
      if (why) { ws.ignored.push({ path, reason: why }); return null; }
      const lang = langOf(path);
      const old = ws.files.get(path);
      const h = hash(content);
      if (old && old.hash === h) return old;
      if (content.length > LIMITS.fileBytes) { ws.ignored.push({ path, reason: "larger than " + LIMITS.fileBytes + " bytes" }); return null; }
      if (!old && ws.files.size >= LIMITS.files) { ws.truncated = "stopped at " + LIMITS.files + " files"; ws.ignored.push({ path, reason: "file limit" }); return null; }
      if (!old && ws.totalBytes + content.length > LIMITS.totalBytes) { ws.truncated = "stopped at " + LIMITS.totalBytes + " bytes"; ws.ignored.push({ path, reason: "size limit" }); return null; }
      if (old) ws.totalBytes -= old.size;
      ws.totalBytes += content.length;
      const rec = { path, lang, hash: h, size: content.length, lines: 0, generated: false, imports: [], symbols: [], idents: null, content, mainLike: false, extra: {} };
      rec.lines = content.split("\n").length;
      rec.generated = GENERATED_NAMES.test(path) || /@generated|<auto-generated|DO NOT EDIT|Code generated by/i.test(content.slice(0, 400)) || (content.length > 20000 && content.split("\n").length < 6);
      if (/\.meta$/.test(path)) {
        const g = /guid:\s*([0-9a-f]{32})/.exec(content);
        if (g) { ws.guidToPath.set(g[1], path.replace(/\.meta$/, "")); rec.extra.guid = g[1]; }
        rec.lang = "meta";
      } else if (/\.(unity|prefab|asset)$/.test(path)) {
        rec.extra.scriptGuids = [...new Set((content.match(/m_Script:\s*\{[^}]*guid:\s*([0-9a-f]{32})/g) || []).map((s) => /guid:\s*([0-9a-f]{32})/.exec(s)[1]))];
        rec.extra.objects = (content.match(/^--- !u!\d+ &\d+/gm) || []).length;
      } else if (SOURCE_LANGS.has(lang) && !rec.generated) {
        const text = strip(content, lang);
        const starts = lineIndex(text);
        const ex = EXTRACT[lang] ? EXTRACT[lang](text, starts) : { imports: [], symbols: [] };
        rec.imports = ex.imports; rec.symbols = ex.symbols; rec.extra = { namespaces: ex.namespaces, package: ex.package, classes: ex.classes && ex.classes.map((c) => ({ name: c.name, line: c.line, bases: c.bases })), fields: ex.fields };
        // identifier occurrences (strings and comments are already blanked)
        const idents = Object.create(null), body = noStr(text);
        const re = /[A-Za-z_$][\w$]*/g;
        let m;
        while ((m = re.exec(body))) { const w = m[0]; if (w.length < 2 || KEYWORDS.has(w)) continue; const ln = lineAt(starts, m.index); (idents[w] || (idents[w] = [])).push(ln); }
        rec.idents = idents;
        rec.mainLike = isEntry(path, lang, body);
      } else if (lang === "json" || lang === "xml" || lang === "gradle" || /\.txt$/.test(path)) {
        parseManifest(path, content);
      }
      if (/(^|\/)projectsettings\/projectversion\.txt$/i.test(path) || /androidmanifest\.xml$/i.test(path)) parseManifest(path, content);
      ws.files.set(path, rec);
      dirty = true;
      return rec;
    }
    function isEntry(path, lang, body) {
      const b = baseOf(path).toLowerCase();
      if (lang === "python") return /if\s+__name__\s*==\s*["']__main__["']/.test(body) || /^(main|manage|app|wsgi|run)\.py$/.test(b);
      if (lang === "csharp") return /static\s+(?:async\s+)?(?:void|int|Task)\s+Main\s*\(/.test(body);
      if (lang === "java") return /public\s+static\s+void\s+main\s*\(/.test(body);
      if (lang === "kotlin") return /\bfun\s+main\s*\(/.test(body);
      if (lang === "go") return /^package\s+main\b/m.test(body) && /\bfunc\s+main\s*\(/.test(body);
      if (lang === "rust") return /\bfn\s+main\s*\(/.test(body);
      if (lang === "c" || lang === "cpp") return /\bint\s+main\s*\(/.test(body);
      return /^(index|main|app|server|cli)\.(js|mjs|cjs|ts|tsx|jsx)$/.test(b);
    }

    /* ---- linking: resolve imports, build symbol table and edges ---- */
    function link() {
      ws.edges = new Map(); ws.reverse = new Map(); ws.external = new Map(); ws.unresolved = []; ws.symbolTable = new Map(); ws.namespaceMap = new Map(); ws.classMap = new Map(); ws.assetLinks = new Map();
      const paths = [...ws.files.keys()];
      const set = new Set(paths);
      const byBase = new Map();
      paths.forEach((p) => { const b = baseOf(p); (byBase.get(b) || byBase.set(b, []).get(b)).push(p); });
      ws.files.forEach((rec, p) => {
        rec.symbols.forEach((s) => (ws.symbolTable.get(s.name) || ws.symbolTable.set(s.name, []).get(s.name)).push(Object.assign({ path: p, lang: rec.lang }, s)));
        (rec.extra.namespaces || []).forEach((n) => (ws.namespaceMap.get(n) || ws.namespaceMap.set(n, []).get(n)).push(p));
        if (rec.extra.package) rec.symbols.filter((s) => !s.container && (s.kind === "class" || s.kind === "interface" || s.kind === "enum")).forEach((s) => ws.classMap.set(rec.extra.package + "." + s.name, p));
      });
      const addEdge = (a, b) => { if (a === b) return; (ws.edges.get(a) || ws.edges.set(a, new Set()).get(a)).add(b); (ws.reverse.get(b) || ws.reverse.set(b, new Set()).get(b)).add(a); };
      const JS_EXT = ["", ".js", ".mjs", ".cjs", ".jsx", ".ts", ".tsx", ".json", "/index.js", "/index.ts", "/index.tsx", "/index.jsx"];
      ws.files.forEach((rec, p) => {
        rec.imports.forEach((im) => {
          let target = null;
          const spec = im.spec;
          if (rec.lang === "javascript" || rec.lang === "typescript") {
            if (spec.startsWith(".") || spec.startsWith("/")) {
              const base = spec.startsWith("/") ? norm(spec) : resolvePath(dirOf(p), spec);
              target = JS_EXT.map((e) => base + e).find((c) => set.has(c)) || (base.endsWith(".js") ? [".ts", ".tsx"].map((e) => base.slice(0, -3) + e).find((c) => set.has(c)) : null);
            } else { (ws.external.get(p) || ws.external.set(p, []).get(p)).push(spec.startsWith("@") ? spec.split("/").slice(0, 2).join("/") : spec.split("/")[0]); return; }
          } else if (rec.lang === "python") {
            const dots = (/^\.+/.exec(spec) || [""])[0].length, mod = spec.slice(dots).replace(/\./g, "/");
            const baseDir = dots ? upDir(dirOf(p), dots - 1) : "";
            const cands = dots ? [join(baseDir, mod) + ".py", join(baseDir, mod, "__init__.py")] : [mod + ".py", mod + "/__init__.py", join(dirOf(p), mod) + ".py"];
            target = cands.find((c) => set.has(c));
            if (!target && im.names && dots) target = im.names.map((n) => join(baseDir, mod, n) + ".py").find((c) => set.has(c));
            if (!target && !dots) { (ws.external.get(p) || ws.external.set(p, []).get(p)).push(spec.split(".")[0]); return; }
          } else if (rec.lang === "csharp") {
            const files = ws.namespaceMap.get(spec);
            if (files) { files.forEach((f) => addEdge(p, f)); return; }
            (ws.external.get(p) || ws.external.set(p, []).get(p)).push(spec); return;
          } else if (rec.lang === "java" || rec.lang === "kotlin") {
            target = ws.classMap.get(spec) || null;
            if (!target && spec.endsWith(".*")) { const pk = spec.slice(0, -2); ws.files.forEach((r, q) => { if (r.extra.package === pk) addEdge(p, q); }); return; }
            if (!target) { (ws.external.get(p) || ws.external.set(p, []).get(p)).push(spec.split(".").slice(0, 2).join(".")); return; }
          } else if (rec.lang === "c" || rec.lang === "cpp") {
            if (im.kind === "system") return;
            target = [join(dirOf(p), spec), norm(spec)].find((c) => set.has(c)) || (byBase.get(baseOf(spec)) || [])[0] || null;
          } else if (rec.lang === "go") { (ws.external.get(p) || ws.external.set(p, []).get(p)).push(spec); return; }
          else if (rec.lang === "rust") { if (im.kind === "mod") { target = [resolvePath(dirOf(p), spec) + ".rs", resolvePath(dirOf(p), spec) + "/mod.rs"].find((c) => set.has(c)); } else return; }
          if (target) addEdge(p, target);
          else ws.unresolved.push({ file: p, spec, line: im.line, kind: im.kind });
        });
        // Unity: scene/prefab → script via GUID
        if (rec.extra.scriptGuids) rec.extra.scriptGuids.forEach((g) => { const sp = ws.guidToPath.get(g); if (sp && set.has(sp)) { addEdge(p, sp); (ws.assetLinks.get(sp) || ws.assetLinks.set(sp, []).get(sp)).push({ path: p, kind: /\.unity$/.test(p) ? "scene" : /\.prefab$/.test(p) ? "prefab" : "asset" }); } });
        // class inheritance across files (C#, Java, Kotlin, JS, TS, Python)
        rec.symbols.forEach((s) => (s.bases || []).forEach((bn) => { const defs = ws.symbolTable.get(bn); if (defs && defs.length === 1 && defs[0].path !== p) addEdge(p, defs[0].path); }));
      });
      // namespace-less C# / same-package Java: usage of a class defined elsewhere is also a dependency; found through references
      ws.files.forEach((rec, p) => {
        if (!rec.idents || (rec.lang !== "csharp" && rec.lang !== "java" && rec.lang !== "kotlin")) return;
        Object.keys(rec.idents).forEach((w) => { const defs = ws.symbolTable.get(w); if (defs && defs.length === 1 && defs[0].path !== p && (defs[0].kind === "class" || defs[0].kind === "interface" || defs[0].kind === "enum")) addEdge(p, defs[0].path); });
      });
      dirty = false; ws.version++;
    }
    function join(a, b, c) { return norm([a, b, c].filter(Boolean).join("/")); }
    function upDir(d, n) { let x = d; for (let i = 0; i < n; i++) x = dirOf(x); return x; }
    function resolvePath(dir, rel) {
      const parts = (dir ? dir.split("/") : []);
      rel.split("/").forEach((seg) => { if (seg === "..") parts.pop(); else if (seg && seg !== ".") parts.push(seg); });
      return parts.join("/");
    }
    const ensure = () => { if (dirty) link(); };

    /* ---- public: loading ---- */
    api.name = ws.name;
    api.addFiles = function (files) { (files || []).forEach((f) => { if (f && f.path != null) indexOne(f.path, f.content); }); dirty = true; return api.stats(); };
    /* chunked, cancellable, time-boxed; resolves with stats. onProgress({done,total,path}) */
    api.indexAsync = function (files, o) {
      o = o || {};
      const list = (files || []).filter((f) => f && f.path != null), budget = o.budgetMs || 12;
      // .gitignore and manifests first so ignore rules apply to everything else
      list.sort((a, b) => (norm(a.path) === ".gitignore" ? -1 : 0) - (norm(b.path) === ".gitignore" ? -1 : 0));
      return new Promise((resolve, reject) => {
        let i = 0;
        const now = () => (root.performance && root.performance.now ? root.performance.now() : Date.now());
        const step = () => {
          if (o.signal && o.signal.aborted) return reject(Object.assign(new Error("indexing cancelled"), { code: "cancelled", done: i }));
          const t0 = now();
          while (i < list.length && now() - t0 < budget) { indexOne(list[i].path, list[i].content); i++; }
          if (o.onProgress) o.onProgress({ done: i, total: list.length, path: i ? norm(list[i - 1].path) : "" });
          if (i < list.length) return void setTimeout(step, 0);
          setTimeout(() => { try { link(); resolve(api.stats()); } catch (e) { reject(e); } }, 0);
        };
        step();
      });
    };
    api.updateFile = function (path, content) {
      path = norm(path);
      const had = ws.files.has(path);
      const rec = indexOne(path, content);
      if (!rec) return { ok: false, reason: (ws.ignored[ws.ignored.length - 1] || {}).reason || "not indexed" };
      ws.live.recentEdits.unshift({ path, t: Date.now() }); ws.live.recentEdits.length = Math.min(ws.live.recentEdits.length, LIMITS.recentEdits);
      return { ok: true, created: !had };
    };
    api.removeFile = function (path) { path = norm(path); const r = ws.files.get(path); if (!r) return false; ws.totalBytes -= r.size; ws.files.delete(path); dirty = true; return true; };
    api.hasFile = (p) => ws.files.has(norm(p));
    api.read = (p) => { const r = ws.files.get(norm(p)); return r ? r.content : null; };
    api.paths = () => [...ws.files.keys()].sort();

    /* ---- public: queries (all return plain JSON) ---- */
    api.stats = function () {
      ensure();
      const langs = {};
      ws.files.forEach((r) => { langs[r.lang] = (langs[r.lang] || 0) + 1; });
      let edges = 0; ws.edges.forEach((s) => { edges += s.size; });
      return { name: ws.name, files: ws.files.size, bytes: ws.totalBytes, languages: langs, symbols: [...ws.symbolTable.values()].reduce((n, a) => n + a.length, 0), edges, ignored: ws.ignored.length, unresolvedImports: ws.unresolved.length, truncated: ws.truncated, unity: api.isUnity(), version: ws.version };
    };
    api.isUnity = () => [...ws.files.keys()].some((p) => /(^|\/)projectsettings\/projectversion\.txt$/i.test(p)) || [...ws.files.keys()].some((p) => /(^|\/)assets\/.+\.cs$/i.test(p));
    api.ignoredList = () => ws.ignored.slice(0, 200);
    api.tree = function () { const t = {}; ws.files.forEach((r, p) => { let n = t; p.split("/").forEach((seg, i, a) => { n = n[seg] = i === a.length - 1 ? { __file: r.lang } : n[seg] || {}; }); }); return t; };
    api.entryPoints = function () {
      ensure();
      const out = [];
      ws.files.forEach((r, p) => { if (r.mainLike) out.push({ path: p, why: "defines a main/entry" }); });
      Object.keys(ws.manifests).forEach((m) => { const mf = ws.manifests[m]; if (mf.kind === "npm") { if (mf.main && ws.files.has(resolvePath(dirOf(m), mf.main))) out.push({ path: resolvePath(dirOf(m), mf.main), why: "package.json main" }); if (mf.scripts.start) out.push({ path: m, why: "npm start: " + mf.scripts.start }); } if (mf.kind === "android-manifest") mf.activities.forEach((a) => out.push({ path: m, why: "Android activity " + a })); });
      ws.files.forEach((r, p) => { if (r.lang === "html") (r.content.match(/<script[^>]+src="([^"]+)"/g) || []).forEach((s) => { const src = /src="([^"]+)"/.exec(s)[1]; if (!/^https?:/.test(src)) { const t = resolvePath(dirOf(p), src.replace(/^\.\//, "")); if (ws.files.has(t)) out.push({ path: t, why: "loaded by " + p }); } }); });
      ws.files.forEach((r, p) => { if (/\.unity$/.test(p)) out.push({ path: p, why: "Unity scene" }); });
      const seen = new Set();
      return out.filter((e) => { const k = e.path + e.why; if (seen.has(k)) return false; seen.add(k); return true; }).slice(0, 40);
    };
    api.dependencies = function () { const d = {}; Object.keys(ws.manifests).forEach((m) => { const mf = ws.manifests[m]; if (mf.dependencies) d[m] = { kind: mf.kind, dependencies: mf.dependencies, dev: mf.devDependencies || [] }; }); return d; };
    api.externalModules = function () { ensure(); const c = {}; ws.external.forEach((arr) => arr.forEach((m) => { c[m] = (c[m] || 0) + 1; })); return c; };
    api.unresolved = function () { ensure(); return ws.unresolved.slice(0, 200); };
    api.symbolsIn = (p) => { const r = ws.files.get(norm(p)); return r ? r.symbols.map((s) => ({ name: s.name, kind: s.kind, line: s.line, container: s.container, exported: s.exported })) : []; };
    api.allSymbols = function (kinds) { ensure(); const out = []; ws.symbolTable.forEach((defs) => defs.forEach((d) => { if (!kinds || kinds.includes(d.kind)) out.push({ name: d.name, kind: d.kind, path: d.path, line: d.line, container: d.container }); })); return out; };
    api.whereDefined = function (name) {
      ensure();
      const q = String(name || "").replace(/\(\)$/, "");
      const dotted = q.split(".");
      const nm = dotted[dotted.length - 1], owner = dotted.length > 1 ? dotted[dotted.length - 2] : null;
      let defs = (ws.symbolTable.get(nm) || []).filter((d) => !owner || d.container === owner);
      return { name: nm, ambiguous: defs.length > 1, definitions: defs.map((d) => ({ path: d.path, line: d.line, kind: d.kind, container: d.container, signature: d.signature || null, exported: d.exported })) };
    };
    /* every identifier occurrence of `name` outside comments and strings. Occurrences on a definition line are flagged. */
    api.references = function (name, opts) {
      ensure(); opts = opts || {};
      const q = String(name || "").replace(/\(\)$/, "").split(".").pop();
      const defs = ws.symbolTable.get(q) || [];
      const defKey = new Set(defs.map((d) => d.path + ":" + d.line));
      const out = [];
      ws.files.forEach((r, p) => {
        const lines = r.idents && r.idents[q];
        if (!lines) return;
        [...new Set(lines)].forEach((ln) => out.push({ path: p, line: ln, definition: defKey.has(p + ":" + ln), text: (r.content.split("\n")[ln - 1] || "").trim().slice(0, 160) }));
      });
      out.sort((a, b) => (a.path < b.path ? -1 : a.path > b.path ? 1 : a.line - b.line));
      return { name: q, defined: defs.length, ambiguous: defs.length > 1, total: out.length, uses: out.filter((o) => !o.definition).length, references: opts.limit ? out.slice(0, opts.limit) : out, caveat: defs.length > 1 ? "Several symbols share this name, so some references may belong to a different one." : (defs.length === 0 ? "No definition found in the indexed files; these are plain name matches." : null) };
    };
    api.dependenciesOf = function (path) { ensure(); return [...(ws.edges.get(norm(path)) || [])].sort(); };
    api.dependents = function (path, o) {
      ensure(); o = o || {};
      const start = norm(path);
      if (!o.transitive) return [...(ws.reverse.get(start) || [])].sort();
      const seen = new Map([[start, 0]]), q = [start];
      while (q.length) { const x = q.shift(), d = seen.get(x); if (o.maxDepth && d >= o.maxDepth) continue; (ws.reverse.get(x) || []).forEach((y) => { if (!seen.has(y)) { seen.set(y, d + 1); q.push(y); } }); }
      seen.delete(start);
      return [...seen.entries()].map(([p, depth]) => ({ path: p, depth })).sort((a, b) => a.depth - b.depth || (a.path < b.path ? -1 : 1));
    };
    /* what could break if this file (or symbol) changes */
    api.impact = function (target) {
      ensure();
      const t = norm(target);
      if (ws.files.has(t)) {
        const rec = ws.files.get(t), direct = api.dependents(t), trans = api.dependents(t, { transitive: true });
        const exported = rec.symbols.filter((s) => s.exported || !s.container);
        const used = exported.map((s) => { const refs = api.references(s.name); const files = [...new Set(refs.references.filter((r) => !r.definition && r.path !== t).map((r) => r.path))]; return { symbol: s.name, kind: s.kind, usedIn: files, ambiguous: refs.ambiguous }; }).filter((u) => u.usedIn.length);
        return { kind: "file", path: t, directDependents: direct, transitiveDependents: trans.map((x) => x.path), symbolsInUse: used, assets: ws.assetLinks.get(t) || [], risk: trans.length >= 10 ? "high" : trans.length >= 3 ? "medium" : "low", caveat: "Lexical analysis: dynamic imports, reflection and string-built names are not seen." };
      }
      const defs = api.whereDefined(t), refs = api.references(t);
      if (!defs.definitions.length && !refs.total) return { kind: "unknown", target: t, found: false };
      const files = [...new Set(refs.references.filter((r) => !r.definition).map((r) => r.path))];
      const pathsOfDefs = defs.definitions.map((d) => d.path);
      const trans = new Set(); pathsOfDefs.forEach((p) => api.dependents(p, { transitive: true }).forEach((x) => trans.add(x.path)));
      return { kind: "symbol", symbol: refs.name, definitions: defs.definitions, ambiguous: defs.ambiguous, usedIn: files, uses: refs.uses, transitiveFilesViaImports: [...trans], risk: files.length >= 8 ? "high" : files.length >= 3 ? "medium" : "low", caveat: refs.caveat || "Lexical analysis: dynamic access and reflection are not seen." };
    };
    api.cycles = function () {
      ensure();
      const idx = new Map(), low = new Map(), on = new Set(), stack = [], out = []; let i = 0;
      const dfs = (v) => { idx.set(v, i); low.set(v, i); i++; stack.push(v); on.add(v); (ws.edges.get(v) || []).forEach((w) => { if (!idx.has(w)) { dfs(w); low.set(v, Math.min(low.get(v), low.get(w))); } else if (on.has(w)) low.set(v, Math.min(low.get(v), idx.get(w))); }); if (low.get(v) === idx.get(v)) { const comp = []; let w; do { w = stack.pop(); on.delete(w); comp.push(w); } while (w !== v); if (comp.length > 1) out.push(comp.sort()); } };
      [...ws.files.keys()].forEach((v) => { if (!idx.has(v)) dfs(v); });
      return out;
    };
    api.hotspots = function () {
      ensure();
      return [...ws.files.keys()].map((p) => ({ path: p, fanIn: (ws.reverse.get(p) || new Set()).size, fanOut: (ws.edges.get(p) || new Set()).size, lines: ws.files.get(p).lines, symbols: ws.files.get(p).symbols.length })).filter((x) => x.fanIn || x.fanOut).sort((a, b) => b.fanIn + b.fanOut - (a.fanIn + a.fanOut)).slice(0, 15);
    };
    api.orphans = function () { ensure(); return [...ws.files.entries()].filter(([p, r]) => SOURCE_LANGS.has(r.lang) && !r.mainLike && !(ws.reverse.get(p) || new Set()).size && r.symbols.length).map(([p]) => p).slice(0, 50); };
    /* Unity link problems that cause "Missing (Script)": a scene/prefab points at a GUID whose script file is gone, or a MonoBehaviour's class name differs from its file name */
    api.unityLinks = function () {
      ensure();
      const broken = [], mismatches = [];
      ws.files.forEach((r, p) => {
        (r.extra.scriptGuids || []).forEach((g) => { const sp = ws.guidToPath.get(g); if (sp && !ws.files.has(sp) && /\.cs$/.test(sp)) broken.push({ asset: p, guid: g, expectedPath: sp }); });
        if (r.lang === "csharp") (r.extra.classes || []).forEach((c) => { if (/^(MonoBehaviour|ScriptableObject|StateMachineBehaviour|NetworkBehaviour)$/.test((c.bases || [])[0] || "") && c.name + ".cs" !== baseOf(p) && !(r.extra.classes || []).some((o) => o.name + ".cs" === baseOf(p))) mismatches.push({ path: p, cls: c.name, line: c.line }); });
      });
      return { broken, mismatches };
    };
    api.assetUsage = (p) => { ensure(); return (ws.assetLinks.get(norm(p)) || []).slice(); };
    api.search = function (query, limit) {
      ensure();
      const items = [];
      ws.symbolTable.forEach((defs) => defs.forEach((d) => items.push(d)));
      const r = root.Semantic ? root.Semantic.rank(query, items, (d) => d.name.replace(/([a-z])([A-Z])/g, "$1 $2").replace(/_/g, " ") + " " + (d.container || "") + " " + d.path.replace(/[\\/._-]/g, " "), { limit: limit || 10, min: 0.45 }) : [];
      return r.map((x) => ({ name: x.item.name, kind: x.item.kind, path: x.item.path, line: x.item.line, container: x.item.container, score: x.score }));
    };
    api.filesOfClass = function (baseName) { ensure(); const out = []; ws.symbolTable.forEach((defs) => defs.forEach((d) => { if ((d.bases || []).includes(baseName)) out.push({ name: d.name, path: d.path, line: d.line }); })); return out; };
    api.classInfo = function (name) { ensure(); const d = (ws.symbolTable.get(name) || []).find((x) => x.kind === "class"); if (!d) return null; const rec = ws.files.get(d.path); return { name, path: d.path, line: d.line, bases: d.bases || [], methods: rec.symbols.filter((s) => s.container === name && s.kind === "method").map((s) => s.name), fields: (rec.extra.fields || []).filter((f) => f.container === name) }; };

    /* ---- live context ---- */
    api.setActive = function (path, selection) { ws.live.activeFile = path ? norm(path) : null; ws.live.selection = selection ? { text: String(selection.text || "").slice(0, 2000), startLine: selection.startLine || null, endLine: selection.endLine || null } : null; };
    api.setTask = (t) => { ws.live.task = t ? String(t).slice(0, 300) : null; };
    api.recordError = function (text, file, line) { ws.live.recentErrors.unshift({ text: String(text).slice(0, 600), file: file ? norm(file) : null, line: line || null, t: Date.now() }); ws.live.recentErrors.length = Math.min(ws.live.recentErrors.length, LIMITS.recentErrors); };
    api.live = () => JSON.parse(JSON.stringify(ws.live));
    api.clone = function () { const c = create({ name: ws.name + " (sandbox copy)" }); c.addFiles([...ws.files.values()].map((r) => ({ path: r.path, content: r.content }))); return c; };
    api.snapshot = () => [...ws.files.values()].map((r) => ({ path: r.path, content: r.content }));
    api.version = () => ws.version;
    api.LIMITS = LIMITS;
    return api;
  }

  /* parse a text/stack trace for file:line references so the live context can track them */
  function parseErrorLocations(text) {
    const out = [];
    const re = /([\w./\\-]+\.(?:js|ts|tsx|jsx|py|cs|java|kt|cpp|c|h|go|rs)):(\d+)(?::(\d+))?|File "([^"]+)", line (\d+)|\bat [\w.<>$]+ \(([^)]+?\.cs):(\d+)\)|\(([\w.]+\.(?:java|kt)):(\d+)\)/g;
    let m;
    while ((m = re.exec(String(text || "")))) out.push({ file: m[1] || m[4] || m[6] || m[8], line: +(m[2] || m[5] || m[7] || m[9]) });
    return out.slice(0, 20);
  }

  root.Project = { create, parseErrorLocations, langOf, strip, blank: (src, lang) => noStr(strip(src, lang)), LIMITS, IGNORE_DIRS, norm };
})();
