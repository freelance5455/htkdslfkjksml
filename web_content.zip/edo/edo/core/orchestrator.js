/* Single routing facade. Numeric work stays in Reasoner + Solver. */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;

  function exprOf(text) {
    const n = root.Normalize ? root.Normalize.math(text) : null;
    if (n) return n.expr;
    return String(text).replace(/^\s*(calculate|compute|evaluate|what is|what's)\s+/i, "").trim();
  }
  function showOf(text, expr) {
    const n = root.Normalize ? root.Normalize.math(text) : null;
    return n ? n.shown : expr;
  }
  function numberText(v) {
    if (!isFinite(v)) return String(v);
    const plain = root.Normalize ? root.Normalize.format(v) : String(v);
    const g = root.Normalize ? root.Normalize.grouped(v) : "";
    return g && g !== plain ? plain + " (" + g + ")" : plain;
  }

  function knowledgeReply(text, subject) {
    const hits = root.EDOKnowledge ? root.EDOKnowledge.search(text, subject).slice(0, 3) : [];
    if (!hits.length) {
      return {
        kind: "jee",
        text: "No local chapter note matched that. Try a formula query such as `formula optics`, or a numeric problem such as `u=0 a=2 t=5 find v`. I will not invent a chapter.",
        meta: "Knowledge index miss.",
      };
    }
    const list = (t, a) => (a && a.length ? "\n" + t + ":\n" + a.map((x) => "- " + x).join("\n") : "");
    const body = hits.map((h) => {
      const d = h.doc;
      const fs = (d.formulas || []).map((f) => "- " + f.name + ": " + f.latex).join("\n");
      return "**" + d.title + "** (" + d.domain + " · " + d.chapter + ")\n" + d.summary + (d.content ? "\n" + d.content : "") + (fs ? "\nRelations:\n" + fs : "") +
        list("Exceptions", d.exceptions) + list("Common traps", d.traps) + list("Solved-method pattern", d.methods) + list("Common JEE mistakes", d.mistakes) +
        list("Units", d.units) + list("Approximation rules", d.approx) + (d.prereqs && d.prereqs.length ? "\nPrerequisites: " + d.prereqs.join(", ") : "") + list("Pitfalls", d.pitfalls);
    }).join("\n\n");
    return {
      kind: "jee",
      text: body + "\n\nFor a number, give givens like `u=0 a=2 t=5 find v`, or a full sentence the solver recognises.",
      meta: "Local knowledge notes, ranked by a heuristic weighted keyword scorer (not a neural model). Not a scored exam solution unless a solver ran.",
    };
  }

  function calcReply(raw, intent) {
    const expr = exprOf(raw);
    try {
      const check = root.Verify.recompute(expr);
      if (!isFinite(check.value)) {
        return { kind: "calculation", text: "**" + showOf(raw, expr) + "** has no finite answer (it divides by zero or overflows).", meta: "Local calculator. Nothing to report.", intent };
      }
      const audit = root.Verify.audit(String(check.value), { calcMismatch: !check.agree });
      return {
        kind: "calculation",
        text: "**" + showOf(raw, expr) + " = " + numberText(check.value) + "**" + audit.suffix,
        meta: "Local calculator, evaluated twice. No eval()." + audit.meta,
        intent,
      };
    } catch (e) {
      return { kind: "calculation", text: "Calculator rejected that input: " + e.message + ". Nothing was computed.", meta: "Strict parser: invalid or leftover characters are never ignored.", intent };
    }
  }

  /* ---------- EDO Basic: everyday tasks only ----------
     Basic keeps the calculator, clock, notes, phone actions, location, search planning and friendly chat.
     The step-by-step solver, MPC notes and the programming engine belong to EDO Pro / Programming, so
     Basic says so and offers the switch instead of half-answering. It never guesses. */
  const CLOCK = /^\s*(?:please\s+)?(?:tell me\s+)?(?:what(?:'s|\s+is)?\s+(?:the\s+)?(?:current\s+)?(?:time|date|day)(?:\s+(?:now|today|right now|is it))?|what\s+time\s+is\s+it(?:\s+now|\s+right now)?|what\s+day\s+is\s+(?:it|today)|(?:what\s+is\s+)?today'?s\s+date|current\s+(?:time|date)|the time(?:\s+please)?)\s*[?.!]*\s*$/i; // anchored: "what is the time period of a pendulum" is physics, not the clock
  const BASIC_META = "EDO Basic: calculator, time and date, notes, calls and apps, location, search, friendly chat.";
  function upgrade(to, why, intent) {
    const name = to === "Programming" ? "Programming mode" : "EDO Pro";
    return {
      kind: "upgrade",
      upgradeTo: to,
      text: why + " " + name + " does that. Switch now?",
      meta: BASIC_META + " Nothing was guessed.",
      intent,
    };
  }
  function clockReply(raw, intent) {
    const d = new Date();
    const wantsDate = /\b(date|day)\b/i.test(raw) && !/\btime\b/i.test(raw);
    let time, date;
    try {
      time = d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
      date = d.toLocaleDateString([], { weekday: "long", day: "numeric", month: "long", year: "numeric" });
    } catch (e) { time = d.toTimeString().slice(0, 5); date = d.toDateString(); }
    return {
      kind: "clock",
      text: wantsDate ? "Today is **" + date + "**." : "It is **" + time + "** on " + date + ".",
      meta: "Read from this device's clock.",
      intent,
    };
  }
  function basicRoute(raw, intent) {
    if (CLOCK.test(raw)) return clockReply(raw, intent);
    if (intent.kind === "calculation") return calcReply(raw, intent);
    if (intent.kind === "programming") return upgrade("Programming", "That is a coding question.", intent);
    if (intent.kind === "jee" || (root.Reasoner && root.Reasoner.matches(raw))) return upgrade("Assistant", "That needs the step-by-step solver and MPC notes.", intent);
    const hits = root.EDOKnowledge ? root.EDOKnowledge.search(raw).slice(0, 1) : [];
    if (hits.length && hits[0].score >= 2) return upgrade("Assistant", "I have chapter notes on that, but they live in EDO Pro.", intent);
    return null;
  }

  function route(text, ctx) {
    if (CLOCK.test(String(text || ""))) return clockReply(String(text), { kind: "conversation" }); // the clock works in every mode
    ctx = ctx || {};
    const raw = String(text || "").trim();
    if (root.Memory && typeof ctx.memoryOn === "boolean") root.Memory.setEnabled(ctx.memoryOn);
    const intent = root.Intent.detect(raw, ctx.mode || "Assistant");
    if (!raw) return { kind: "system", text: "Empty input.", meta: "Nothing sent.", intent };

    if ((intent.kind === "crisis" || intent.kind === "decision" || intent.kind === "chat") && root.Companion) {
      const r = root.Companion.handle(raw, ctx);
      if (r) { r.intent = intent; return r; }
    }
    if (intent.kind === "device" && root.Device) {
      const cmd = root.Device.parse(raw);
      return { kind: "device", device: cmd, text: null, meta: "Device action.", intent };
    }
    if (intent.kind === "memory" && root.Memory) {
      const r = root.Memory.handle(raw, ctx);
      r.intent = intent;
      return r;
    }
    if (intent.kind === "file" && root.FileAnalyzer) {
      const r = root.FileAnalyzer.analyzeText(raw);
      r.intent = intent;
      return r;
    }
    if (String(ctx.mode || "").toLowerCase() === "basic") {
      const b = basicRoute(raw, intent);
      if (b) return b;
    }
    if (root.Pipeline) {
      const p = root.Pipeline.run(raw, ctx);
      if (p) {
        const audit = root.Verify.audit(p.text, { kind: "reason" });
        const out = Object.assign(p, { text: p.text + audit.suffix, meta: (p.meta || "") + audit.meta, intent });
        return root.MPC ? root.MPC.augment(out, raw) : out;
      }
    } else if (root.Reasoner && root.Reasoner.matches(raw)) {
      const r = root.Reasoner.run(raw);
      const audit = root.Verify.audit(r.text, { kind: "reason" });
      return { kind: "reason", text: r.text + audit.suffix, meta: (r.meta || "") + audit.meta, intent };
    }
    if (intent.kind === "calculation") return calcReply(raw, intent);
    if (intent.kind === "programming" || String(ctx.mode || "").toLowerCase() === "programming") {
      const r = root.Programming.answer(raw);
      r.intent = intent;
      return r;
    }
    if (intent.wantsLocation || intent.wantsWeather) {
      return {
        kind: intent.wantsWeather ? "weather" : "location",
        needsLocation: true,
        wantsWeather: !!intent.wantsWeather,
        text: null,
        meta: "Location is a device capability, not part of the reasoning core.",
        intent,
      };
    }
    if (intent.kind === "search" || intent.wantsSearch) {
      const r = root.WebSearch.plan(raw);
      r.intent = intent;
      return r;
    }
    if (intent.kind === "jee" || /^(jee|study|reasoning)$/i.test(ctx.mode || "")) {
      const r = knowledgeReply(raw, intent.subject);
      r.intent = intent;
      return r;
    }
    const hits = root.EDOKnowledge ? root.EDOKnowledge.search(raw).slice(0, 1) : [];
    if (hits.length && hits[0].score >= 2) {
      const r = knowledgeReply(raw, intent.subject);
      r.kind = "conversation";
      r.intent = intent;
      return r;
    }
    if (/^friend$/i.test(String(ctx.mode || "")) && root.Companion && !ctx.hasProxy) {
      const r = root.Companion.handle(raw, ctx);
      if (r) { r.intent = intent; return r; }
    }
    if (String(ctx.mode || "").toLowerCase() === "basic") {
      return {
        kind: "conversation",
        text: "EDO Basic is online. I can calculate, tell you the time and date, keep notes, open apps, help you call someone, plan a web search, and talk things through. For open-ended chat add an AI proxy URL in the panel. I have not guessed an answer.",
        meta: BASIC_META + " No model call was made.",
        intent,
      };
    }
    return {
      kind: "conversation",
      text: "EDO is online in local mode. I can calculate, solve formula and JEE-style numeric problems, explain local MPC notes, analyse code, and store notes on this device. Open-ended chat needs the AI proxy in the panel. I have not guessed an answer.",
      meta: "No local solver matched. No model call was made.",
      intent,
    };
  }

  /* The Brain (core/brain.js) runs first: it recognises conversational acts and context, and hands everything else to route(). */
  function handle(text, ctx) {
    if (root.Brain && !(ctx && ctx.brain === false)) return root.Brain.run(text, ctx || {}, route);
    return route(text, ctx);
  }
  /* Public entry. Wraps the router so conversation context is recorded only when memory is on. */
  function handleTracked(text, ctx) {
    const r = handle(text, ctx);
    try {
      if (root.Memory && root.Memory.isEnabled() && r && r.kind !== "system" && r.kind !== "memory" && r.kind !== "crisis") {
        root.Memory.pushContext("user", String(text).slice(0, 300));
        if (r.text) root.Memory.pushContext("edo", String(r.text).slice(0, 300));
      }
    } catch (e) {}
    return r;
  }
  /* Async variant: resolves a configured search provider's run() so callers need no search knowledge. */
  async function handleAsync(text, ctx) {
    const r = handleTracked(text, ctx);
    if (r && typeof r.run === "function") {
      try { const x = await r.run(); return Object.assign({}, r, x, { run: undefined }); }
      catch (e) { return Object.assign({}, r, { text: "The search provider failed: " + e.message + ". No results to show.", meta: "Search error.", run: undefined }); }
    }
    return r;
  }
  root.EDO = Object.assign(root.EDO || {}, { handle: handleTracked, handleAsync }); // keep namespaces already attached (EDO.AndroidBridge)
})();
