/* EDO agent: conversation context -> router -> planner -> trusted engines / tools -> verified response.
   The deterministic engines (calculator, JEE solver, CodeBrain, device parser) are trusted tools. The AI model is used for open conversation,
   explanation (numbers it adds are rejected) and plan proposals (validated against the tool registry). Replies about actions are built from tool
   statuses only, so the model cannot claim success. Without a provider everything still works through the local engines.
   Globals: window.Agent (default instance) and window.Agent.create(deps) */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  const MAX_STEPS = 6;

  /* ---- time parsing for reminders: returns {at,label} | {ask} | null. Never guesses a missing time of day. ---- */
  function parseWhen(text, now) {
    const t = String(text || "").toLowerCase(); const base = new Date(now == null ? Date.now() : now);
    let m = t.match(/\bin\s+(\d{1,3})\s*(minutes?|mins?|hours?|hrs?|days?)\b/);
    if (m) { const n = +m[1], u = m[2][0]; const ms = u === "m" ? n * 60000 : u === "h" ? n * 3600000 : n * 86400000; return { at: base.getTime() + ms, label: "in " + n + " " + m[2] }; }
    const tm = t.match(/\b(?:at\s+)?(\d{1,2})(?::(\d{2}))?\s*(am|pm)\b/) || t.match(/\bat\s+(\d{1,2})(?::(\d{2}))?\b/);
    let h = null, mi = 0;
    if (tm) { h = +tm[1]; mi = tm[2] ? +tm[2] : 0; if (tm[3] === "pm" && h < 12) h += 12; if (tm[3] === "am" && h === 12) h = 0; if (h > 23 || mi > 59) return { ask: "That time doesn't look valid. What time do you mean?" }; }
    const day = /\btomorrow\b/.test(t) ? 1 : /\b(today|tonight)\b/.test(t) ? 0 : null;
    if (day === null && h === null) return null;
    if (h === null) return { ask: "What time " + (day === 1 ? "tomorrow" : "today") + " should I remind you?" };
    const d = new Date(base); d.setSeconds(0, 0); d.setHours(h, mi, 0, 0);
    if (day === 1) d.setDate(d.getDate() + 1);
    else if (d.getTime() <= base.getTime() + 5000) { if (day === 0) return { ask: "That time has already passed today. Did you mean tomorrow?" }; d.setDate(d.getDate() + 1); }
    return { at: d.getTime(), label: d.toLocaleString() };
  }
  const stripWhen = (s) => s.replace(/\b(?:tomorrow|today|tonight)\b/gi, "").replace(/\bin\s+\d{1,3}\s*(?:minutes?|mins?|hours?|hrs?|days?)\b/gi, "").replace(/\b(?:at\s+)?\d{1,2}(?::\d{2})?\s*(?:am|pm)\b/gi, "").replace(/\bat\s+\d{1,2}(?::\d{2})?\b/gi, "").replace(/\s{2,}/g, " ").replace(/^\W+|\W+$/g, "").trim();

  const SEARCH_SITES = { youtube: (q) => "https://www.youtube.com/results?search_query=" + encodeURIComponent(q), google: (q) => "https://www.google.com/search?q=" + encodeURIComponent(q), maps: (q) => "https://www.google.com/maps/search/" + encodeURIComponent(q) };

  /* ---- rule-based decomposition. Returns {steps} | {ask} | null ---- */
  function decompose(text, now) {
    const raw = String(text || "").trim(); const steps = []; const push = (tool, args, why, extra) => steps.push(Object.assign({ id: "s" + (steps.length + 1), tool, args, why }, extra || {}));
    const rem = raw.match(/\b(?:remind me|set (?:a )?reminder)\b(.*)$/i);
    if (rem) {
      const w = parseWhen(raw, now); if (!w) return { ask: "When should I remind you? Give me a day and a time, like \"tomorrow at 6 pm\"." }; if (w.ask) return { ask: w.ask };
      const title = stripWhen(rem[1]).replace(/^(?:me\s+)?(?:to|about|that)\s+/i, "").replace(/\s+(?:to|about)$/i, "").trim(); if (!title) return { ask: "What should I remind you about?" };
      push("create_reminder", { title: title[0].toUpperCase() + title.slice(1), at: w.at }, "Remind you " + w.label + ": " + title); return { steps };
    }
    const tim = raw.match(/\b(?:set (?:a )?)?timer for (\d{1,3})\s*(minutes?|mins?|hours?|hrs?)\b/i);
    if (tim) { const n = +tim[1] * (/^h/i.test(tim[2]) ? 3600000 : 60000); push("create_reminder", { title: "Timer finished", at: Date.now() + n }, "Notify you in " + tim[1] + " " + tim[2] + " (a notification, not a clock-app timer)"); return { steps }; }
    const parts = root.ModelRouter ? root.ModelRouter.splitActions(raw) : [raw];
    let app = null;
    for (const p of parts) {
      let m;
      if ((m = p.match(/^(?:please\s+)?(?:open|launch)\s+(?:the\s+)?(.+?)(?:\s+app)?$/i))) { app = m[1].trim(); if (app.split(/\s+/).length > 3 || /\b(?:and|then)\b/i.test(app)) return null; push("open_app", { name: app }, "Open " + app); continue; }
      if ((m = p.match(/^(?:please\s+)?(?:find|search(?:\s+for)?|look\s+for|play|show me)\s+(?:a |an |some |the )?(.+)$/i))) {
        const site = app && SEARCH_SITES[app.toLowerCase()] ? app.toLowerCase() : null;
        const q = m[1].trim().replace(/^(?:video|videos|clip|clips)\s+(?:about|on|of)\s+/i, "");
        if (site) push("open_url", { url: SEARCH_SITES[site](q) }, "Search " + app + " for \"" + q + "\"", { optionalNote: "I can open the results page but cannot press anything inside the app." });
        else push("web_search", { query: m[1].trim() }, "Search the web for \"" + m[1].trim() + "\"");
        continue;
      }
      if ((m = p.match(/^(?:what(?:'s| is) )?(?:my |the )?battery(?: level| status)?\??$/i))) { push("battery_status", {}, "Check the battery"); continue; }
      return null; // a part we do not understand: refuse to guess a partial plan
    }
    return steps.length ? { steps } : null;
  }

  function extractJson(s) { const a = String(s).indexOf("{"), b = String(s).lastIndexOf("}"); if (a < 0 || b <= a) return null; try { return JSON.parse(String(s).slice(a, b + 1)); } catch (e) { return null; } }
  const nums = (s) => (String(s).replace(/,/g, "").match(/\d+(?:\.\d+)?/g) || []).filter((x) => !(Number.isInteger(+x) && +x <= 10)).map((x) => String(+x));

  function create(deps) {
    deps = deps || {};
    const cfg = deps.config || root.EdoConfig;
    const reg = deps.tools || root.Tools;
    const mgr = deps.providers || (root.AIProviders && root.AIProviders.manager(cfg, deps.providerDeps || {}));
    const handler = deps.handler || ((t, c) => (root.EDO.handleAsync ? root.EDO.handleAsync(t, c) : root.EDO.handle(t, c)));
    const S = root.Safety;
    const state = { history: [], lastRoute: null, lastPlan: null, pending: null, seq: 0, ctl: null, tainted: false };
    const logger = deps.logger || S.logger(null);

    const emit = (c, st) => { try { c && c.onState && c.onState(st); } catch (e) {} };
    const aiReady = () => mgr && mgr.remoteReady();
    const sys = () => "You are EDO, a personal assistant on an Android phone. Be concise and honest. Never say an action was done unless the system reports it. Do not invent search results, numbers, or tool output. " + S.UNTRUSTED_RULE;
    function messages(extra, c) { const n = cfg.get("ai.maxHistory"); return [{ role: "system", text: sys() + (extra || "") }].concat(state.history.slice(-n)); }
    function remember(role, text) { state.history.push({ role, text: String(text).slice(0, 2000) }); if (state.history.length > 60) state.history.shift(); }
    function permissionsFor(c) { return c.permissions || deps.permissions || (() => false); }

    /* Ask the model for a plan; every step is validated against the registry before it can run. */
    async function planWithAI(text, c) {
      if (!aiReady()) return { ok: false, reason: "no AI provider configured" };
      const tools = reg.describe().filter((d) => d.available).map((d) => ({ name: d.name, description: d.description, args: d.args, risk: d.risk }));
      const prompt = "Break the user's request into at most " + MAX_STEPS + " tool calls. Reply with JSON only: {\"steps\":[{\"tool\":string,\"args\":object,\"why\":string}],\"ask\":string|null}. Use only these tools: " + JSON.stringify(tools) + ". If a detail is missing, set \"ask\" to one question and no steps. Later steps may reference earlier results as \"{{s1.field}}\".\nRequest: " + text.slice(0, 1000);
      const r = await mgr.chat([{ role: "system", text: sys() }, { role: "user", text: prompt }], { signal: c.signal, noLocal: true, temperature: 0 });
      if (!r.ok) return { ok: false, reason: r.error.message };
      const j = extractJson(r.text); if (!j) return { ok: false, reason: "the model did not return a usable plan" };
      if (j.ask && (!j.steps || !j.steps.length)) return { ok: true, ask: String(j.ask).slice(0, 200) };
      if (!Array.isArray(j.steps) || !j.steps.length || j.steps.length > MAX_STEPS) return { ok: false, reason: "the plan had no steps or too many" };
      const steps = [];
      for (let i = 0; i < j.steps.length; i++) {
        const s = j.steps[i]; const d = s && reg.describe(s.tool);
        if (!d) return { ok: false, reason: "the plan used an unknown tool" };
        const hasRef = JSON.stringify(s.args || {}).includes("{{");
        if (!hasRef) { const v = reg.check(s.tool, s.args); if (!v.ok) return { ok: false, reason: "the plan had invalid arguments for " + s.tool + ": " + v.errors[0] }; }
        steps.push({ id: "s" + (i + 1), tool: s.tool, args: s.args && typeof s.args === "object" ? s.args : {}, why: String(s.why || s.tool).slice(0, 160) });
      }
      return { ok: true, steps, source: "ai", provider: r.provider };
    }
    const resolve = (args, done) => { const o = {}; Object.keys(args || {}).forEach((k) => { const v = args[k]; const m = typeof v === "string" && v.match(/^\{\{(s\d+)\.([\w.]+)\}\}$/); if (m) { const r = done[m[1]]; let x = r && r.data; m[2].split(".").forEach((p) => { x = x == null ? x : x[p]; }); o[k] = x; } else o[k] = v; }); return o; };

    /* Run a plan. Stops at the first step that is not success/unverified. Summary text comes only from statuses. */
    async function run(plan, c) {
      c = c || {}; const done = {}; const out = []; const lines = []; let stopped = null;
      for (const st of plan.steps.slice(0, MAX_STEPS)) {
        emit(c, "using_tool");
        const args = resolve(st.args, done);
        let rec = await reg.execute(st.tool, args, { permissions: permissionsFor(c), confirm: c.confirm, tainted: c.tainted || state.tainted, signal: c.signal, onProgress: c.onProgress });
        const risk = (reg.describe(st.tool) || {}).risk;
        if (!rec.ok && rec.error && rec.error.retryable && risk === "low" && !(c.signal && c.signal.aborted)) rec = await reg.execute(st.tool, args, { permissions: permissionsFor(c), confirm: c.confirm, tainted: c.tainted || state.tainted, signal: c.signal }); // one retry, low-risk only
        done[st.id] = rec; out.push({ id: st.id, tool: st.tool, why: st.why, status: rec.status, error: rec.error, verified: rec.verified, data: rec.data, runId: rec.id, note: rec.note });
        if (rec.status === "success") lines.push("✓ " + st.why + (rec.note ? " (" + rec.note + ")" : ""));
        else if (rec.status === "unverified") lines.push("↗ Requested: " + st.why + ". " + (rec.note || "I cannot confirm it happened.") + (st.optionalNote ? " " + st.optionalNote : ""));
        else { lines.push("✗ " + st.why + " — " + (rec.status === "needs_confirmation" ? "waiting for your confirmation" : rec.error ? rec.error.message : rec.status)); stopped = st.id; break; }
      }
      const skipped = plan.steps.length - out.length; if (stopped && skipped > 0) lines.push("Stopped; " + skipped + " later step" + (skipped > 1 ? "s were" : " was") + " not run.");
      state.lastPlan = { steps: plan.steps, results: out };
      const okAll = !stopped; logger.log("plan", { steps: out.length, ok: okAll });
      return { ok: okAll, steps: out, text: lines.join("\n"), stoppedAt: stopped };
    }

    async function aiExplain(question, localText, kind, c) {
      if (!aiReady() || c.noAI) return null;
      emit(c, "thinking");
      const r = await mgr.chat([{ role: "system", text: sys() + " The VERIFIED RESULT below came from EDO's deterministic engine. Explain it clearly. Use only numbers that appear in the question or the verified result; do not compute new ones." }, { role: "user", text: "Question: " + question.slice(0, 1500) + "\n\nVERIFIED RESULT (" + kind + "):\n" + localText.slice(0, 4000) }], { signal: c.signal, noLocal: true });
      if (!r.ok) return { failed: r.error.message };
      const allowed = new Set(nums(question + " " + localText)); const extra = nums(r.text).filter((n) => !allowed.has(n));
      return extra.length ? { rejected: true, extra: extra.slice(0, 5) } : { text: r.text, provider: r.provider };
    }

    async function doSearch(text, c, current) {
      const ws = root.WebSearch;
      if (!ws || !ws.configured()) return { kind: "search", route: "search", text: (current ? "That needs current information, and web search isn't configured on this device, so I won't guess. " : "Web search isn't configured, so nothing was searched. ") + "Add a search provider in settings.", meta: "No search performed.", performed: false };
      emit(c, "searching");
      const rec = await reg.execute("web_search", { query: text.replace(/^\s*(search|look up|google)\s*(for)?\s*/i, "").slice(0, 300) || text.slice(0, 300) }, { permissions: permissionsFor(c), signal: c.signal });
      if (!rec.ok) return { kind: "search", route: "search", text: "The search failed (" + (rec.error ? rec.error.message : rec.status) + "). I have no results to show or cite.", meta: "Search error.", performed: true };
      const results = rec.data.results.slice(0, cfg.get("search.maxResults")), cites = rec.data.citations.slice(0, results.length);
      const wrapped = S.wrapUntrusted(results.map((r, i) => "[" + (i + 1) + "] " + r.title + " — " + r.snippet + " (" + r.url + ")").join("\n"), "search:" + rec.data.provider);
      if (wrapped.suspicious) state.tainted = true;
      const sources = cites.map((x) => ({ index: x.index, title: x.title, url: x.url }));
      const plain = root.WebSearch.format({ ok: true, performed: true, query: text, provider: rec.data.provider, retrievedAt: cites[0] ? cites[0].retrievedAt : "", results, citations: cites });
      if (aiReady() && !c.noAI) {
        emit(c, "thinking");
        const r = await mgr.chat([{ role: "system", text: sys() + " Answer the question using ONLY the search results given. Cite with [n]. If they do not answer it, say so." }, { role: "user", text: "Question: " + text.slice(0, 500) + "\n\n" + wrapped.text }], { signal: c.signal, noLocal: true });
        if (r.ok) { const used = (r.text.match(/\[(\d+)\]/g) || []).map((x) => +x.slice(1, -1)); if (used.every((n) => n >= 1 && n <= sources.length)) return { kind: "search", route: "search", text: r.text, sources, meta: "Summarised by " + r.provider + " from " + rec.data.provider + " results. Check the sources.", provider: r.provider, performed: true, suspicious: wrapped.suspicious }; }
      }
      return { kind: "search", route: "search", text: plain, sources, meta: "Results come from " + rec.data.provider + ". Not verified by EDO.", performed: true, suspicious: wrapped.suspicious };
    }

    async function handle(text, c) {
      c = Object.assign({}, c || {});
      if (state.ctl) { try { state.ctl.abort(); } catch (e) {} } // a newer request makes the old one obsolete
      const ctl = typeof AbortController !== "undefined" ? new AbortController() : null; state.ctl = ctl; if (ctl) c.signal = ctl.signal;
      const my = ++state.seq; const raw = String(text == null ? "" : text).trim();
      const stale = () => my !== state.seq;
      const finish = (r) => { if (stale()) return { kind: "system", route: "cancelled", text: "", meta: "Superseded by a newer request.", cancelled: true }; emit(c, "idle"); if (r.text) remember("assistant", r.text); state.lastRoute = r.route || null; return r; };
      if (raw) remember("user", raw);
      emit(c, "thinking");
      const lctx = { mode: c.mode || "Assistant", memoryOn: c.memoryOn, hasProxy: false };
      const decision = state.pending && !/^\s*(?:cancel|never ?mind|stop)\b/i.test(raw) && state.pending.kind === "plan-ask" ? { route: "planner", reason: "answering my question", pending: true } : root.ModelRouter.route(raw, { mode: c.mode, hasHistory: state.history.length > 1, pending: !!state.pending, attachments: c.attachments, projectLoaded: c.projectLoaded });
      if (state.pending && /^\s*(?:cancel|never ?mind|stop)\b/i.test(raw)) { state.pending = null; return finish({ kind: "system", route: "followup", text: "Okay, dropped that.", meta: "Pending question cleared." }); }
      logger.log("route", { route: decision.route, ai: aiReady() });
      const base = (r, extra) => Object.assign({ route: decision.route }, r, extra || {});
      try {
        switch (decision.route) {
          case "clarify": return finish({ kind: "clarify", route: "clarify", text: decision.question, meta: "Needed more detail before acting." });
          case "vision": {
            if (!root.Vision) return finish({ kind: "vision", route: "vision", text: "Image analysis isn't available in this build, so I haven't looked at the image.", meta: "No vision engine loaded." });
            const v = await root.Vision.analyze((c.attachments || [])[0], { question: raw, signal: c.signal }); return finish({ kind: "vision", route: "vision", text: v.ok ? v.text : "I couldn't analyse that image: " + v.error.message, meta: v.ok ? "Vision: " + v.provider + ". Not verified by EDO." : "No analysis was produced." });
          }
          case "planner": case "multi": {
            let src = raw; if (state.pending && state.pending.kind === "plan-ask") { src = state.pending.original + " " + raw; }
            let d = decompose(src, c.now);
            if (!d && aiReady()) { emit(c, "thinking"); const p = await planWithAI(src, c); if (p.ok && p.ask) d = { ask: p.ask }; else if (p.ok) d = { steps: p.steps }; else if (decision.route === "planner") d = { ask: "I couldn't turn that into a plan (" + p.reason + "). Can you rephrase it?" }; }
            if (!d) return finish({ kind: "plan", route: decision.route, text: "I couldn't turn that into safe steps, so I haven't done anything. Try one action at a time, e.g. \"open YouTube\".", meta: "Planner: no safe decomposition." });
            if (d.ask) { state.pending = { kind: "plan-ask", original: state.pending ? state.pending.original : raw }; return finish({ kind: "clarify", route: decision.route, text: d.ask, meta: "Planner needs one detail." }); }
            state.pending = null; if (stale()) return finish({});
            const r = await run(d, c); return finish({ kind: "plan", route: decision.route, text: r.text, steps: r.steps, ok: r.ok, meta: "Each step reports what the device actually returned." });
          }
          case "search": return finish(await doSearch(raw, c, decision.current));
          case "chat": {
            if (!decision.local && aiReady()) {
              emit(c, "thinking"); const r = await mgr.chat(messages("", c), { signal: c.signal, noLocal: true });
              if (stale()) return finish({});
              if (r.ok) { try { if (root.Memory && root.Memory.isEnabled() && c.memoryOn !== false) { root.Memory.pushContext("user", raw.slice(0, 300)); root.Memory.pushContext("edo", r.text.slice(0, 300)); } } catch (e) {} return finish({ kind: "conversation", route: "chat", text: r.text, provider: r.provider, degraded: r.degraded, meta: "Source: " + r.provider + (r.degraded ? " (after a fallback)" : "") + ". Not independently verified by EDO." }); }
              const l = await handler(raw, lctx); return finish(base(l, { degraded: true, meta: (l.meta || "") + " AI unavailable (" + r.error.message + "); answered by local engines." }));
            }
            return finish(base(await handler(raw, lctx)));
          }
          case "jee": case "programming": case "project": {
            const l = await handler(raw, Object.assign({}, lctx, { mode: decision.route === "jee" && !/^(jee|study|reasoning|assistant)$/i.test(lctx.mode) ? "Assistant" : lctx.mode })); if (stale()) return finish({});
            if (l.kind === "upgrade" || !l.text) return finish(base(l));
            const x = await aiExplain(raw, l.text, decision.route, c);
            if (x && x.text) return finish(base(l, { text: l.text + "\n\n**Explanation (" + x.provider + ")**\n" + x.text, meta: (l.meta || "") + " Numbers and code results come from EDO's engines; the explanation is from " + x.provider + "." }));
            return finish(base(l, x && x.rejected ? { meta: (l.meta || "") + " An AI explanation was discarded because it introduced numbers EDO did not compute." } : {}));
          }
          default: return finish(base(await handler(raw, lctx))); // device, math, followup, memory: trusted local engines
        }
      } catch (e) { logger.log("error", { route: decision.route }); return finish({ kind: "system", route: decision.route, text: "Something went wrong (" + String(e.message).slice(0, 120) + "). Nothing was done.", meta: "Agent error." }); }
    }
    return { handle, run, decompose, planWithAI, state, parseWhen, cancel() { if (state.ctl) state.ctl.abort(); state.seq++; }, reset() { state.history = []; state.pending = null; state.lastPlan = null; state.tainted = false; } };
  }
  root.Agent = Object.assign({ create, parseWhen, decompose: (t, n) => decompose(t, n), numbersIn: nums }, {});
})();
