/* EDO AI provider abstraction. AIProvider base + GeminiProvider, OpenAIProvider, ClaudeProvider, ProxyProvider, LocalProvider.
   Providers only build requests and parse replies; fetch is injected, so tests never touch a network. Keys go in headers, never in URLs or logs.
   ProviderManager adds retry of transient failures, fallback to other configured providers, and a last-resort LocalProvider (EDO's deterministic engines).
   Not done here: streaming (SSE) and native function-calling; the planner asks for JSON text instead. Request shapes follow each vendor's public
   REST docs but have NOT been exercised against the live services in this repository. Globals: window.AIProviders */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  const HOSTS = { gemini: "https://generativelanguage.googleapis.com", openai: "https://api.openai.com", claude: "https://api.anthropic.com" };

  function fail(code, message, extra) { return Object.assign({ ok: false, text: "", error: { code, message, retryable: code === "transient" || code === "timeout" || code === "rate_limited" } }, extra || {}); }
  function classifyHttp(status) { return status === 401 || status === 403 ? "auth" : status === 429 ? "rate_limited" : status === 408 ? "timeout" : status >= 500 ? "transient" : status === 400 || status === 404 || status === 422 ? "bad_request" : "failed"; }
  const imgs = (m) => (m.images || []).filter((i) => i && /^image\/(png|jpe?g|webp|gif)$/.test(i.mime) && typeof i.data === "string" && /^[A-Za-z0-9+/=]+$/.test(i.data));

  class AIProvider {
    constructor(name, cfg) { this.name = name; this.cfg = cfg || {}; this.supportsImages = false; }
    configured() { return false; }
    /* build(messages, opts) -> {url, headers, body}; parse(json) -> text. Messages: [{role:"system"|"user"|"assistant", text, images?:[{mime,data}]}] */
    build() { throw Error("build() not implemented"); }
    parse() { throw Error("parse() not implemented"); }
    async chat(messages, opts) {
      opts = opts || {};
      if (!this.configured()) return fail("not_configured", this.name + " is not configured (provider, model and key are all required).");
      const f = this.cfg.fetch || (typeof fetch !== "undefined" ? fetch.bind(root) : null);
      if (!f) return fail("unavailable", "fetch is unavailable here.");
      let req; try { req = this.build(messages, opts); } catch (e) { return fail("bad_request", e.message); }
      const ac = typeof AbortController !== "undefined" ? new AbortController() : null;
      let to; const ms = opts.timeoutMs || this.cfg.timeoutMs || 30000;
      if (opts.signal) { if (opts.signal.aborted) return fail("cancelled", "Cancelled."); opts.signal.addEventListener && opts.signal.addEventListener("abort", () => ac && ac.abort()); }
      try {
        const run = f(req.url, { method: "POST", headers: req.headers, body: JSON.stringify(req.body), signal: ac ? ac.signal : undefined, credentials: "omit", referrerPolicy: "no-referrer" });
        const timeout = new Promise((_, rej) => { to = setTimeout(() => { if (ac) ac.abort(); rej(Object.assign(Error("timeout"), { code: "timeout" })); }, ms); });
        const res = await Promise.race([run, timeout]);
        if (!res.ok) return fail(classifyHttp(res.status), this.name + " returned HTTP " + res.status + ".", { status: res.status });
        let j; try { j = await res.json(); } catch (e) { return fail("bad_response", this.name + " returned something that is not JSON."); }
        const text = this.parse(j);
        if (typeof text !== "string" || !text.trim()) return fail("empty", this.name + " returned no text.");
        return { ok: true, text: text.slice(0, 20000), provider: this.name };
      } catch (e) {
        if (opts.signal && opts.signal.aborted) return fail("cancelled", "Cancelled.");
        return fail(e && e.code === "timeout" ? "timeout" : "transient", this.name + " request failed: " + String((e && e.message) || e).slice(0, 120));
      } finally { clearTimeout(to); }
    }
  }
  function endpointOk(url) { try { const u = new URL(url); return u.protocol === "https:" || (u.protocol === "http:" && /^(localhost|127\.0\.0\.1)$/.test(u.hostname)); } catch (e) { return false; } }
  const sysOf = (ms) => ms.filter((m) => m.role === "system").map((m) => m.text).join("\n\n");
  const turns = (ms) => ms.filter((m) => m.role !== "system");

  class GeminiProvider extends AIProvider {
    constructor(cfg) { super("gemini", cfg); this.supportsImages = true; }
    configured() { return !!(this.cfg.key && this.cfg.model); }
    build(ms, o) {
      const base = this.cfg.endpoint || HOSTS.gemini; if (!endpointOk(base)) throw Error("endpoint must be https");
      const sys = sysOf(ms);
      return { url: base.replace(/\/$/, "") + "/v1beta/models/" + encodeURIComponent(this.cfg.model) + ":generateContent", headers: { "Content-Type": "application/json", "x-goog-api-key": this.cfg.key },
        body: Object.assign({ contents: turns(ms).map((m) => ({ role: m.role === "assistant" ? "model" : "user", parts: [{ text: m.text }].concat(imgs(m).map((i) => ({ inline_data: { mime_type: i.mime, data: i.data } }))) })), generationConfig: { temperature: o.temperature != null ? o.temperature : 0.4 } }, sys ? { systemInstruction: { parts: [{ text: sys }] } } : {}) };
    }
    parse(j) { const c = j && j.candidates && j.candidates[0]; return c && c.content && c.content.parts ? c.content.parts.map((p) => p.text || "").join("") : ""; }
  }
  class OpenAIProvider extends AIProvider {
    constructor(cfg) { super("openai", cfg); this.supportsImages = true; }
    configured() { return !!(this.cfg.key && this.cfg.model); }
    build(ms, o) {
      const base = this.cfg.endpoint || HOSTS.openai; if (!endpointOk(base)) throw Error("endpoint must be https");
      return { url: base.replace(/\/$/, "") + "/v1/chat/completions", headers: { "Content-Type": "application/json", Authorization: "Bearer " + this.cfg.key },
        body: { model: this.cfg.model, temperature: o.temperature != null ? o.temperature : 0.4, messages: ms.map((m) => { const im = imgs(m); return { role: m.role, content: im.length ? [{ type: "text", text: m.text }].concat(im.map((i) => ({ type: "image_url", image_url: { url: "data:" + i.mime + ";base64," + i.data } }))) : m.text }; }) } };
    }
    parse(j) { const c = j && j.choices && j.choices[0]; return c && c.message && typeof c.message.content === "string" ? c.message.content : ""; }
  }
  class ClaudeProvider extends AIProvider {
    constructor(cfg) { super("claude", cfg); this.supportsImages = true; }
    configured() { return !!(this.cfg.key && this.cfg.model); }
    build(ms, o) {
      const base = this.cfg.endpoint || HOSTS.claude; if (!endpointOk(base)) throw Error("endpoint must be https");
      const sys = sysOf(ms);
      return { url: base.replace(/\/$/, "") + "/v1/messages", headers: { "Content-Type": "application/json", "x-api-key": this.cfg.key, "anthropic-version": "2023-06-01", "anthropic-dangerous-direct-browser-access": "true" },
        body: Object.assign({ model: this.cfg.model, max_tokens: o.maxTokens || 1024, temperature: o.temperature != null ? o.temperature : 0.4, messages: turns(ms).map((m) => ({ role: m.role === "assistant" ? "assistant" : "user", content: [{ type: "text", text: m.text }].concat(imgs(m).map((i) => ({ type: "image", source: { type: "base64", media_type: i.mime, data: i.data } }))) })) }, sys ? { system: sys } : {}) };
    }
    parse(j) { return j && Array.isArray(j.content) ? j.content.filter((b) => b && b.type === "text").map((b) => b.text).join("") : ""; }
  }
  /* The user's own server (POST {messages} -> {reply}); keeps keys off the device. */
  class ProxyProvider extends AIProvider {
    constructor(cfg) { super("proxy", cfg); }
    configured() { return !!this.cfg.endpoint; }
    build(ms, o) { if (!endpointOk(this.cfg.endpoint)) throw Error("endpoint must be https"); return { url: this.cfg.endpoint, headers: { "Content-Type": "application/json" }, body: { messages: ms.map((m) => ({ role: m.role, text: m.text })), temperature: o.temperature } }; }
    parse(j) { return j && typeof j.reply === "string" ? j.reply : ""; }
  }
  /* Always available. Wraps a deterministic handler (EDO.handle). It never pretends to be a language model. */
  class LocalProvider extends AIProvider {
    constructor(cfg) { super("local", cfg); }
    configured() { return true; }
    async chat(messages) {
      const h = this.cfg.handler || (root.EDO && root.EDO.handle);
      if (!h) return fail("unavailable", "No local engine is loaded.");
      const last = messages.slice().reverse().find((m) => m.role === "user");
      try { const r = await h(last ? last.text : "", this.cfg.ctx || {}); return r && r.text ? { ok: true, text: String(r.text), provider: "local", reply: r } : fail("empty", "The local engines had no answer."); }
      catch (e) { return fail("failed", "Local engine error: " + e.message); }
    }
  }

  const CLASSES = { gemini: GeminiProvider, openai: OpenAIProvider, claude: ClaudeProvider, proxy: ProxyProvider, local: LocalProvider };
  /* chat(messages, {noLocal}) -> {ok, text, provider, attempts:[{provider, ok, code}], degraded}. Order: chosen, fallbacks, then local (unless noLocal).
     Auth/bad-request errors skip retries (they will not fix themselves); transient ones are retried with backoff. */
  function manager(config, deps) {
    deps = deps || {};
    const sleep = deps.sleep || ((ms) => new Promise((r) => setTimeout(r, ms)));
    function instance(name) {
      const C = CLASSES[name]; if (!C) return null;
      const p = { key: config.getSecret(name), model: config.modelFor(name), endpoint: config.get("ai.endpoint"), timeoutMs: config.get("ai.timeoutMs"), fetch: deps.fetch, handler: deps.localHandler };
      if (name === "gemini" || name === "openai" || name === "claude") { if (!config.get("ai.endpoint") || config.get("ai.provider") !== name) p.endpoint = ""; } // a custom endpoint belongs to the chosen provider only
      return new C(p);
    }
    const mgr = {
      CLASSES, instance,
      chain() { const first = config.get("ai.provider"); const names = [first].concat(config.get("ai.fallback") || []).filter((n, i, a) => n && n !== "none" && n !== "local" && a.indexOf(n) === i); return names.map(instance).filter((p) => p && p.configured()); },
      remoteReady() { return mgr.chain().length > 0; },
      async chat(messages, opts) {
        opts = opts || {};
        const attempts = []; const retries = config.get("ai.retries");
        for (const p of mgr.chain()) {
          if (opts.needImages && !p.supportsImages) { attempts.push({ provider: p.name, ok: false, code: "no_images" }); continue; }
          for (let i = 0; i <= retries; i++) {
            if (opts.signal && opts.signal.aborted) return Object.assign(fail("cancelled", "Cancelled."), { attempts });
            const r = await p.chat(messages, opts);
            attempts.push({ provider: p.name, ok: r.ok, code: r.ok ? "ok" : r.error.code });
            if (r.ok) return Object.assign(r, { attempts, degraded: attempts.length > 1 });
            if (r.error.code === "cancelled") return Object.assign(r, { attempts });
            if (!r.error.retryable) break; // auth / bad request: go straight to the next provider
            if (i < retries) await sleep(300 * Math.pow(2, i));
          }
        }
        if (opts.noLocal) return Object.assign(fail("no_provider", attempts.length ? "Every configured AI provider failed." : "No AI provider is configured."), { attempts });
        const l = await instance("local").chat(messages, opts);
        attempts.push({ provider: "local", ok: l.ok, code: l.ok ? "ok" : l.error.code });
        return Object.assign(l, { attempts, degraded: true, local: true });
      },
    };
    return mgr;
  }
  root.AIProviders = { AIProvider, GeminiProvider, OpenAIProvider, ClaudeProvider, ProxyProvider, LocalProvider, manager, CLASSES, fail };
})();
