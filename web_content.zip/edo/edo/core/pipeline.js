/* EDO reasoning pipeline. Stages:
   intent → topic → entities/units → given validation → method selection → solve → independent verification → format.
   It wraps the existing template solver and formula table, adds a multi-step derivation fallback, and attaches an honest
   verification status + confidence. Returns null when the text is not a quantitative science question, so the
   orchestrator can fall through. No UI / voice / device / network dependency. */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  const sig = (x) => { const v = +(+x).toPrecision(6), a = Math.abs(v); return a >= 1e6 || (a > 0 && a < 1e-3) ? v.toExponential().replace(/\.?0+e/, "e") : String(v); };
  const CONF = { "verified": 0.9, "partially verified": 0.65, "not verified": 0.2, "unable to verify": 0 };

  function newState(text) { return { input: text, stages: [], status: "unable to verify", confidence: 0, error: null }; }
  const stage = (st, name, status, detail) => st.stages.push({ name, status, detail: detail || "" });

  function topicOf(text) {
    if (!root.EDOKnowledge || !root.EDOKnowledge.rank) return null;
    const r = root.EDOKnowledge.rank(text, { limit: 1 });
    return r.length && r[0].score >= 6 ? { id: r[0].doc.id, chapter: r[0].doc.chapter, domain: r[0].doc.domain, score: +r[0].score.toFixed(2) } : null;
  }
  function render(st, body, extra) {
    const trace = st.stages.map((s) => (s.status === "ok" ? "✓" : s.status === "skip" ? "–" : "✗") + " " + s.name + (s.detail ? ": " + s.detail : "")).join("\n");
    return body + (extra ? "\n" + extra : "") + "\n**Verification: " + st.status + "**  ·  confidence " + Math.round(st.confidence * 100) + "%\n:::working\n" + trace + "\n:::";
  }
  function finish(st, status, text, meta, kind) {
    st.status = status; st.confidence = CONF[status] || 0;
    return { kind: "reason", text: render(st, text), meta: meta, state: st, errorState: st.error };
  }

  function convertUnits(text) {
    const c = root.Units && root.Units.parseConversion(text);
    if (!c) return null;
    const st = newState(text);
    stage(st, "intent", "ok", "unit conversion");
    const r = root.Units.convert(c.value, c.from, c.to);
    if (!r.ok) { st.error = r.error; stage(st, "unit check", "fail", r.error); return finish(st, "not verified", "**Cannot convert:** " + r.error + ".", "Nothing was computed.", "convert"); }
    const back = root.Units.convert(r.value, c.to, c.from);
    const checks = [root.Verify.checks.finite(r.value), root.Verify.checks.agree(back.value, c.value, "round-trip back to " + c.from, 1e-9)];
    const v = root.Verify.status(checks);
    stage(st, "unit check", "ok", "same dimension");
    stage(st, "verify", v.status === "not verified" ? "fail" : "ok", root.Verify.describe(v));
    const shown = root.Normalize ? root.Normalize.format(r.value) : String(sig(r.value));
    st.status = v.status; st.confidence = CONF[v.status];
    return { kind: "reason", text: render(st, "**" + c.value + " " + c.from + " = " + shown + " " + c.to + "**"), meta: "Converted with the local unit table (SI factors). Round-trip checked.", state: st };
  }

  function statusFromSolverText(t) {
    if (/Verification failed|cannot give a reliable answer/i.test(t)) return "not verified";
    if (/Not enough information|Nothing was computed|No formula in the local table/i.test(t)) return "unable to verify";
    if (/Check ✓/.test(t)) return "verified"; // an independent second route agreed
    if (/Check: substituted back/.test(t)) return "partially verified"; // substitution only; units assumed SI
    return "partially verified";
  }


  /* Multi-step derivation route. Returns a finished result or null when no chain exists. */
  function deriveRoute(st, raw, val, sentence, tgt) {
    let T = (/\b(?:find|calculate|compute|determine|get)\s+(?:the\s+)?([A-Za-z_]\w*)/i.exec(raw) || [])[1];
    let g = Object.assign({}, val.si);
    if (!Object.keys(g).length || !(T in root.Derive.symbols())) {
      if (tgt && Object.keys(sentence.givens).length) {
        T = tgt; g = Object.assign({}, sentence.givens);
        stage(st, "sentence givens", "ok", Object.keys(g).map((k) => k + "=" + sig(g[k])).join(", ") + " (mapped by unit dimension, heuristic)" + (sentence.ambiguous.length ? "; ambiguous, not used: " + sentence.ambiguous.join(",") : ""));
      }
    }
    if (!T || !Object.keys(g).length) return null;
    const d = root.Derive.solve(g, T);
    if (!d.ok) return null;
    stage(st, "method", "ok", d.distinct.length + " derivation chain(s), symbol-matching heuristic");
    if (d.ambiguous) {
      stage(st, "verify", "fail", "chains disagree");
      return finish(st, "not verified", "**More than one derivation fits and they disagree:**\n" + d.distinct.map((c) => "• " + c.chapter + ": " + T + " = " + sig(c.value) + "\n" + root.Derive.explain(c)).join("\n") + "\nSpecify the chapter or give more data.", "Ambiguous: no single answer chosen.");
    }
    const c = d.chains[0];
    const resOk = c.steps.every((s) => s.residual <= 1e-6 * Math.max(1, Math.abs(s.value)));
    stage(st, "solve", "ok", c.steps.length + " step(s)");
    const checks = [root.Verify.checks.finite(c.value), { name: "each step substituted back", ok: resOk, detail: "max residual " + Math.max.apply(null, c.steps.map((s) => s.residual)).toExponential(1) }];
    const rg = root.Verify.checks.range(T, c.value);
    if (rg.ok !== null) checks.push(rg);
    const v = root.Verify.status(checks);
    stage(st, "verify", v.status === "not verified" ? "fail" : "ok", root.Verify.describe(v));
    const status = c.crossChapter && v.status === "verified" ? "partially verified" : v.status;
    st.status = status; st.confidence = CONF[status];
    const body = "**" + T + " = " + sig(c.value) + "**\nMethod: multi-step derivation (" + c.chapter + ")\nWorking:\n" + root.Derive.explain(c) +
      "\nGivens (SI): " + Object.keys(g).map((k) => k + "=" + sig(g[k])).join(", ") + (c.crossChapter ? "\nNote: this chains formulas from different chapters by matching symbol names; confirm the symbols mean the same thing in your problem." : "") +
      "\nUnits: formulas assume SI; givens were converted to SI first.";
    return { kind: "reason", text: render(st, body), meta: "Derived locally from the formula table. Heuristic symbol matching. Not an AI model.", state: st };
  }

  function run(text, ctx) {
    const raw = String(text || "").trim();
    if (!raw || raw.length > 5000) return null;
    const unitRes = convertUnits(raw);
    if (unitRes) return unitRes;
    if (!root.Reasoner || !root.Reasoner.matches(raw)) return null;

    const st = newState(raw);
    const intent = root.Intent ? root.Intent.detect(raw, (ctx && ctx.mode) || "Assistant") : { kind: "jee" };
    stage(st, "intent", "ok", intent.kind);
    const tp = topicOf(raw);
    stage(st, "topic", tp ? "ok" : "skip", tp ? tp.chapter + " (" + tp.domain + ", heuristic score " + tp.score + ")" : "no chapter matched");

    const val = root.Entities.validate(raw);
    stage(st, "entities", "ok", val.assignments.length ? val.assignments.map((a) => a.symbol + "=" + a.value + (a.unit ? " " + a.unit : "")).join(", ") : "from sentence");
    if (!val.ok) {
      st.error = val.errors[0];
      stage(st, "given validation", "fail", val.errors.join(" "));
      return finish(st, "not verified", "**I won't solve this as written.**\n" + val.errors.map((e) => "- " + e).join("\n") + "\nFix the givens and ask again.", "Rejected before solving. Nothing was computed.");
    }
    stage(st, "given validation", "ok", val.warnings.length ? val.warnings.join(" ") : "no contradictions, units consistent");

    const sentence = root.Entities.sentenceGivens(raw), tgt = root.Entities.targetOf(raw);
    // A template that reads "a speed" would silently use the INITIAL speed when acceleration and time are also given.
    // Those problems need a chain (v = u + at, then the energy/momentum formula), so the chain runs first.
    const chainFirst = !val.assignments.length && tgt && /^(KE|p|Pw)$/.test(tgt) && "a" in sentence.givens && "t" in sentence.givens;
    if (chainFirst) {
      const r = deriveRoute(st, raw, val, sentence, tgt);
      if (r) return r;
    }
    // method 1: sentence templates + one-step formula table (existing engine)
    const base = root.Reasoner.run(raw);
    const fallthrough = /No formula in the local table links|Not enough information/.test(base.text);
    if (!fallthrough) {
      const status = statusFromSolverText(base.text);
      stage(st, "method", "ok", /Check ✓|Topic:/.test(base.text) ? "topic template" : "formula table (single step)");
      stage(st, "solve", status === "not verified" ? "fail" : "ok");
      stage(st, "verify", status === "unable to verify" || status === "not verified" ? "fail" : "ok", status);
      if (status === "unable to verify") st.error = "insufficient or unmatched data";
      st.status = status; st.confidence = CONF[status];
      return { kind: "reason", text: render(st, base.text), meta: base.meta, state: st, errorState: st.error };
    }
    // method 2: multi-step derivation over the formula table
    if (!chainFirst) {
      const r = deriveRoute(st, raw, val, sentence, tgt);
      if (r) return r;
    }
    stage(st, "method", "fail", "no direct formula and no derivation chain");
    st.error = "no method found";
    return finish(st, "unable to verify", base.text, base.meta);
  }
  root.Pipeline = { run, convertUnits, statusFromSolverText };
})();
