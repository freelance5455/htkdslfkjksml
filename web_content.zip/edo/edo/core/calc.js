/* EDO calculator. Strict tokenizer + recursive-descent evaluator. No eval(), no Function().
   Every character must belong to a known token; anything else throws instead of being ignored.
   Supports: + - * / ^ ** % (postfix), ! (factorial), brackets, implicit multiplication (2(3+1), 2pi, (1+2)(3+4)),
   scientific notation (1.2e-3, 3×10^5), Unicode operators/superscripts, constants, degree/radian trig.
   Globals: window.Calc */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  const MAX_LEN = 2000, MAX_DEPTH = 60;
  const CONST = { pi: Math.PI, e: Math.E, tau: 2 * Math.PI };
  const SUP = { "⁰": "0", "¹": "1", "²": "2", "³": "3", "⁴": "4", "⁵": "5", "⁶": "6", "⁷": "7", "⁸": "8", "⁹": "9", "⁻": "-" };
  const fact = (n) => {
    if (!Number.isInteger(n) || n < 0) throw Error("factorial needs a non-negative integer");
    if (n > 170) return Infinity;
    let r = 1;
    for (let i = 2; i <= n; i++) r *= i;
    return r;
  };
  const Calc = {
    angle: "rad", // "rad" | "deg" for sin/cos/tan/asin/acos/atan
    fn: {
      sin: (x) => Math.sin(Calc.angle === "deg" ? (x * Math.PI) / 180 : x),
      cos: (x) => Math.cos(Calc.angle === "deg" ? (x * Math.PI) / 180 : x),
      tan: (x) => Math.tan(Calc.angle === "deg" ? (x * Math.PI) / 180 : x),
      asin: (x) => (Calc.angle === "deg" ? (Math.asin(x) * 180) / Math.PI : Math.asin(x)),
      acos: (x) => (Calc.angle === "deg" ? (Math.acos(x) * 180) / Math.PI : Math.acos(x)),
      atan: (x) => (Calc.angle === "deg" ? (Math.atan(x) * 180) / Math.PI : Math.atan(x)),
      sind: (x) => Math.sin((x * Math.PI) / 180),
      cosd: (x) => Math.cos((x * Math.PI) / 180),
      tand: (x) => Math.tan((x * Math.PI) / 180),
      sinh: Math.sinh, cosh: Math.cosh, tanh: Math.tanh,
      sqrt: Math.sqrt, cbrt: Math.cbrt, ln: Math.log, log: Math.log10, log2: Math.log2,
      abs: Math.abs, exp: Math.exp, floor: Math.floor, ceil: Math.ceil, round: Math.round,
      min: Math.min, max: Math.max, pow: Math.pow, fact: fact,
    },
    /* Convert unicode / spacing noise to the ASCII the tokenizer knows. Rewrites only; never guesses. */
    clean(src) {
      let s = String(src);
      if (s.length > MAX_LEN) throw Error("input too long");
      // superscripts first: NFKC would flatten "²" into a plain "2" and change the meaning
      s = s.replace(/[⁰¹²³⁴⁵⁶⁷⁸⁹⁻]+/g, (m) => "^(" + [...m].map((c) => SUP[c]).join("") + ")");
      s = s.normalize("NFKC");
      s = s.replace(/[−–—]/g, "-").replace(/[×✕✖⋅·∙]/g, "*").replace(/÷/g, "/").replace(/π/g, "pi").replace(/τ/g, "tau");
      s = s.replace(/√\s*(\d+(?:\.\d+)?|pi|\()/g, (m, a) => (a === "(" ? "sqrt(" : "sqrt(" + a + ")"));
      s = s.replace(/\s+/g, " ").trim();
      return s;
    },
    tokenize(src) {
      const s = Calc.clean(src);
      const toks = [];
      let i = 0;
      while (i < s.length) {
        const c = s[i];
        if (c === " ") { i++; continue; }
        let m;
        if ((m = /^(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?/.exec(s.slice(i)))) {
          // a lone "e" followed by a letter is a name (2e), not an exponent
          let t = m[0];
          if (/[eE]$/.test(t) && !/\d$/.test(t)) t = t.slice(0, -1);
          toks.push({ t: "num", v: parseFloat(t) });
          i += t.length;
        } else if ((m = /^[A-Za-z_][A-Za-z_0-9]*/.exec(s.slice(i)))) {
          toks.push({ t: "id", v: m[0].toLowerCase() });
          i += m[0].length;
        } else if (s.startsWith("**", i)) { toks.push({ t: "op", v: "^" }); i += 2; }
        else if ("+-*/^%!(),".includes(c)) { toks.push({ t: c === "(" || c === ")" || c === "," ? c : "op", v: c }); i++; }
        else throw Error("invalid character '" + c + "'");
      }
      return toks;
    },
    run(src, scope) {
      const t = Calc.tokenize(src);
      if (!t.length) throw Error("empty");
      let i = 0, depth = 0;
      const pk = () => t[i];
      const isOp = (v) => t[i] && t[i].t === "op" && t[i].v === v;
      // implicit multiplication only before a name or "(" : 2pi, 2(3), (1)(2). Never number-number ("2 3" is an error).
      const startsAtom = () => t[i] && (t[i].t === "id" || t[i].t === "(");
      const expr = () => {
        let v = term();
        while (isOp("+") || isOp("-")) { const o = t[i++].v; const r = term(); v = o === "+" ? v + r : v - r; }
        return v;
      };
      const term = () => {
        let v = unary();
        for (;;) {
          if (isOp("*") || isOp("/")) { const o = t[i++].v; const r = unary(); v = o === "*" ? v * r : v / r; }
          else if (startsAtom()) v = v * unary(); // implicit multiplication: 2pi, 2(3), (1)(2), 3 sqrt(4)
          else break;
        }
        return v;
      };
      const unary = () => {
        if (isOp("-")) { i++; return -unary(); }
        if (isOp("+")) { i++; return unary(); }
        return power();
      };
      const power = () => {
        const b = postfix();
        if (isOp("^")) { i++; return Math.pow(b, unary()); } // right-assoc, allows 2^-3
        return b;
      };
      const postfix = () => {
        let v = atom();
        for (;;) {
          if (isOp("!")) { i++; v = fact(v); }
          else if (isOp("%") && !(t[i + 1] && (t[i + 1].t === "num" || t[i + 1].t === "id" || t[i + 1].t === "("))) { i++; v = v / 100; }
          else break;
        }
        return v;
      };
      const atom = () => {
        const x = t[i++];
        if (!x) throw Error("unexpected end");
        if (x.t === "num") return x.v;
        if (x.t === "(") {
          if (++depth > MAX_DEPTH) throw Error("nesting too deep");
          const v = expr();
          if (!t[i] || t[i].t !== ")") throw Error("missing )");
          i++; depth--;
          return v;
        }
        if (x.t === "id") {
          if (scope && Object.prototype.hasOwnProperty.call(scope, x.v) && !(t[i] && t[i].t === "(")) return scope[x.v];
          if (Object.prototype.hasOwnProperty.call(CONST, x.v) && !(t[i] && t[i].t === "(")) return CONST[x.v];
          const f = Object.prototype.hasOwnProperty.call(Calc.fn, x.v) ? Calc.fn[x.v] : null;
          if (!f) throw Error("unknown name " + x.v);
          if (!t[i] || t[i].t !== "(") throw Error("expected ( after " + x.v);
          i++;
          if (++depth > MAX_DEPTH) throw Error("nesting too deep");
          const args = [expr()];
          while (t[i] && t[i].t === ",") { i++; args.push(expr()); }
          if (!t[i] || t[i].t !== ")") throw Error("missing )");
          i++; depth--;
          return f.apply(null, args);
        }
        throw Error("unexpected " + (x.v || x.t));
      };
      const v = expr();
      if (i < t.length) throw Error("unexpected '" + (t[i].v) + "' after the expression");
      return v;
    },
    /* Safe wrapper: {ok, value} or {ok:false, error}. Rejects NaN; flags Infinity. */
    tryRun(src, scope) {
      try {
        const value = Calc.run(src, scope);
        if (Number.isNaN(value)) return { ok: false, error: "result is not a number" };
        return { ok: true, value, finite: Number.isFinite(value) };
      } catch (e) { return { ok: false, error: e.message }; }
    },
  };
  root.Calc = Calc;
})();
