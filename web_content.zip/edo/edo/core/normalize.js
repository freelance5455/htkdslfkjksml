/* EDO math normalizer. Turns everyday arithmetic phrasing into the plain expression Calc.run() understands.
   "100×100", "100 x 100", "15% of 200", "25 squared", "100 divided by 4", "square root of 144", "2 to the power of 10".
   It only rewrites. Calc stays the single evaluator, and anything it cannot fully understand returns null. */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;

  const NUM = "(\\d+(?:\\.\\d+)?|\\.\\d+)";
  const LEAD = /^\s*(?:please\s+|hey\s+edo[,:]?\s*|can you\s+|could you\s+)?(?:(?:calculate|compute|evaluate|solve|work out|find|simplify|what\s*(?:is|'s|s)|how much is|tell me)\s+)*(?:the\s+(?:value|answer)\s+of\s+)?/i;
  const FUNCS = ["sin", "cos", "tan", "sqrt", "ln", "log", "abs", "exp", "min", "max", "pi"];

  function rewrite(src) {
    let s = String(src);
    s = s.replace(LEAD, "");
    s = s.replace(/[?=!.\s]+$/g, "");
    s = s.replace(/[−–—]/g, "-").replace(/÷/g, "/").replace(/[×✕✖⋅·∙]/g, "*");
    // thousands separators: 1,000 or 12,34,567 (Indian grouping), but not function arguments like max(1,234)
    if (!/[a-z]\s*\(/i.test(s)) s = s.replace(/\d{1,3}(?:,\d{2,3})+(?!\d)/g, (m) => m.replace(/,/g, ""));
    // currency and spacing noise
    s = s.replace(/[₹$€£]/g, "");
    // "x" as a times sign only between numbers/brackets (keeps 2x+3 and 0x1F alone)
    if (!/\b0x[0-9a-f]+\b/i.test(s)) s = s.replace(/(\d|\))\s*x\s*(?=\d|\(|\.)/gi, "$1*");
    // powers and roots
    s = s.replace(/√\s*\(/g, "sqrt(").replace(new RegExp("√\\s*" + NUM, "g"), "sqrt($1)");
    s = s.replace(/²/g, "^2").replace(/³/g, "^3");
    s = s.replace(new RegExp("cube\\s*root\\s*(?:of\\s*)?" + NUM, "gi"), "($1)^(1/3)");
    s = s.replace(new RegExp("(?:square\\s*root|sqrt|root)\\s*(?:of\\s*)?" + NUM, "gi"), "sqrt($1)");
    s = s.replace(new RegExp(NUM + "\\s*squared", "gi"), "($1)^2");
    s = s.replace(new RegExp(NUM + "\\s*cubed", "gi"), "($1)^3");
    s = s.replace(new RegExp(NUM + "\\s*(?:to\\s+the\\s+power(?:\\s+of)?|raised\\s+to(?:\\s+the\\s+power(?:\\s+of)?)?|power)\\s*" + NUM, "gi"), "($1)^($2)");
    // percentages
    s = s.replace(new RegExp(NUM + "\\s*(?:%|per\\s*cent|percent)\\s*of\\s*", "gi"), "($1/100)*");
    s = s.replace(new RegExp(NUM + "\\s*(?:%|per\\s*cent|percent)", "gi"), "($1/100)");
    // word operators
    s = s.replace(/\b(?:multiplied\s+by|times|multiply\s+by)\b/gi, "*")
      .replace(/\b(?:divided\s+by|over)\b/gi, "/")
      .replace(/\b(?:plus|add(?:ed)?(?:\s+to)?)\b/gi, "+")
      .replace(/\b(?:minus|subtract(?:ed)?(?:\s+by)?|less)\b/gi, "-");
    return s.replace(/\s+/g, " ").trim();
  }

  /* Returns {expr, shown} when the whole input is arithmetic, otherwise null. */
  function math(text) {
    const raw = String(text || "").trim();
    if (!raw || raw.length > 200) return null;
    const expr = rewrite(raw);
    if (!expr || !/\d/.test(expr)) return null;
    // everything left must be digits, operators, brackets, commas, or a known function name
    const stripped = expr.replace(/\d+(?:\.\d+)?e[+-]?\d+/gi, "0").replace(new RegExp("\\b(?:" + FUNCS.join("|") + ")\\b", "gi"), "");
    if (/[a-z]/i.test(stripped)) return null;
    if (!/^[\s0-9+\-*/^().,%π]+$/.test(stripped)) return null;
    // needs an operator or a function to count as a calculation, so "42" or "(7)" alone is not one
    if (!/[+\-*/^%]|\b(?:sin|cos|tan|sqrt|ln|log|abs|exp|min|max)\s*\(/i.test(expr.replace(/^-/, ""))) return null;
    // a lone sign in front of a number ("-5") is not a question
    if (/^[-+]?\s*\d+(?:\.\d+)?$/.test(expr)) return null;
    // phone numbers, dates, ranges: "98765-43210" or "2024-10-03" are not subtraction questions
    if (/^\d{4}-\d{1,2}-\d{1,2}$/.test(expr.replace(/\s/g, "")) || /^\+?\d[\d\s-]{8,}$/.test(raw)) return null;
    return { expr, shown: raw.replace(LEAD, "").replace(/[?=!.\s]+$/g, "") };
  }

  /* 12 significant digits removes 0.1+0.2 style noise; big integers get digit grouping. */
  function format(v) {
    if (!isFinite(v)) return String(v);
    const r = parseFloat(Number(v).toPrecision(12));
    const t = String(r);
    return t;
  }
  function grouped(v) {
    const r = parseFloat(Number(v).toPrecision(12));
    if (!isFinite(r) || Math.abs(r) < 10000 || /e/i.test(String(r))) return "";
    return r.toLocaleString("en-IN", { maximumFractionDigits: 6 });
  }

  root.Normalize = { math, format, grouped, rewrite };
})();
