/* Voice engine tests: recognition lifecycle and recovery, wake-word state machine, session flow, barge-in, TTS. Fakes only. */
module.exports = function ({ check, assert, window }) {
  const W = window, VE = () => W.VoiceEngine;
  let q = Promise.resolve();
  const seq = (name, fn) => check(name, () => { const p = q.then(fn); q = p.catch(() => {}); p.catch(() => {}); return p; });

  function makeTimers() {
    let now = 0, id = 0; const jobs = new Map();
    return { now: () => now, setTimeout: (fn, ms) => { jobs.set(++id, { at: now + ms, fn }); return id; }, clearTimeout: (i) => jobs.delete(i),
      advance(ms) { const end = now + ms; for (;;) { const next = [...jobs.entries()].filter(([, j]) => j.at <= end).sort((a, b) => a[1].at - b[1].at)[0]; if (!next) break; jobs.delete(next[0]); now = next[1].at; next[1].fn(); } now = end; }, pending: () => jobs.size };
  }
  function makeRec() {
    const inst = [];
    class Rec { constructor() { this.started = false; this.stopped = false; inst.push(this); } start() { this.started = true; this.onstart && this.onstart(); } stop() { this.stopped = true; } abort() { this.stopped = true; }
      say(text, final, conf) { const res = [{ transcript: text, confidence: conf == null ? 0.9 : conf }]; res.isFinal = !!final; this.onresult({ resultIndex: 0, results: [res] }); }
      fail(code) { this.onerror({ error: code }); } finish() { this.onend && this.onend(); } }
    return { Rec, inst, last: () => inst[inst.length - 1] };
  }
  function makeSynth(voices) {
    const spoken = []; const s = { speaking: false, pending: false, spoken, cancelled: 0, getVoices: () => voices || [], speak(u) { spoken.push(u); s.speaking = true; }, cancel() { s.cancelled++; s.speaking = false; } };
    class Utt { constructor(t) { this.text = t; } }
    return { s, Utt };
  }
  const stt = (o) => { const t = makeTimers(), r = makeRec(); const e = VE().createStt({ SpeechRecognition: r.Rec, timers: t }, o); return { e, t, r }; };

  check("stt: continuous recognition shows interim text, commits one final transcript after silence", () => {
    const { e, t, r } = stt({ silenceMs: 1000 }); const log = [];
    assert(e.start({ interim: (x) => x && log.push("i:" + x), final: (x, why) => log.push("f:" + x + ":" + why) }) === true);
    assert(r.last().continuous === true && r.last().interimResults === true && e.state === "listening");
    r.last().say("open the", false); t.advance(300); r.last().say("open the camera", false); t.advance(300); r.last().say("open the camera", true);
    assert(!log.some((x) => x.startsWith("f:")), "committed before silence");
    t.advance(1100);
    assert(log.includes("i:open the") && log.includes("f:open the camera:silence"), JSON.stringify(log));
    r.last().say("what time is it", true); t.advance(1100);
    assert(log.filter((x) => x.startsWith("f:")).length === 2, "second utterance in the same session missed: " + log);
  });
  check("stt: browser auto-end restarts with back-off, and gives up with a clear error after repeated failure", () => {
    const { e, t, r } = stt({ maxRestarts: 3, backoffMs: 100 }); const errs = [];
    e.start({ error: (x) => errs.push(x), final: () => {} });
    r.last().finish(); assert(e.state === "restarting"); t.advance(100); assert(r.inst.length === 2 && e.state === "listening", "no restart");
    r.last().finish(); t.advance(200); r.last().finish(); t.advance(400); r.last().finish(); t.advance(800);
    assert(errs.some((x) => x.code === "too_many_restarts") && e.state === "stopped", JSON.stringify(errs));
  });
  check("stt: pending text is committed when the browser ends the session, not lost", () => {
    const { e, t, r } = stt({}); const fin = []; e.start({ final: (x) => fin.push(x) });
    r.last().say("remind me to study", false); r.last().finish();
    assert(fin[0] === "remind me to study", JSON.stringify(fin));
  });
  check("stt: error recovery is specific: no-speech is silent, permission is fatal, network is not, repeated errors stop", () => {
    let { e, r } = stt({}); let errs = []; e.start({ error: (x) => errs.push(x) });
    r.last().fail("no-speech"); assert(errs.length === 0 && e.state !== "stopped", "no-speech must be silent");
    r.last().fail("network"); assert(errs[0].code === "network" && errs[0].fatal === false && /network/i.test(errs[0].message));
    ({ e, r } = stt({})); errs = []; e.start({ error: (x) => errs.push(x) }); r.last().fail("not-allowed");
    assert(errs[0].fatal === true && /permission/i.test(errs[0].message) && e.state === "stopped", JSON.stringify(errs));
    ({ e, r } = stt({})); errs = []; e.start({ error: (x) => errs.push(x) }); for (let i = 0; i < 4; i++) r.last().fail("bad-grammar");
    assert(errs.some((x) => x.code === "too_many_errors") && e.state === "stopped");
    ({ e, r } = stt({})); errs = []; e.start({ error: (x) => errs.push(x) }); r.last().fail("language-not-supported"); assert(/not supported/.test(errs[0].message));
  });
  check("stt: language configuration (English India, Hindi, Hinglish→Latin-script locale) and unsupported browsers", () => {
    let { e, r } = stt({ lang: "hi-IN" }); e.start({}); assert(r.last().lang === "hi-IN");
    ({ e, r } = stt({ lang: "hinglish" })); e.start({}); assert(r.last().lang === "en-IN", "hinglish must map to en-IN");
    e.stop(); e.configure({ lang: "en-US" }); e.start({}); assert(r.last().lang === "en-US");
    const none = VE().createStt({ SpeechRecognition: null, timers: makeTimers() }, {}); const errs = [];
    assert(none.available() === false && none.start({ error: (x) => errs.push(x) }) === false && errs[0].code === "unsupported");
  });
  check("stt: session timeout stops recognition, and stop() is clean and idempotent", () => {
    const { e, t, r } = stt({ maxSessionMs: 5000 }); const stopped = []; e.start({ stopped: (w) => stopped.push(w) });
    t.advance(5100); assert(e.state === "stopped" && stopped[0] === "timeout", JSON.stringify(stopped));
    e.stop(); e.stop(); assert(t.pending() === 0, "timers leaked");
  });

  const mkWake = (cfg, bridge) => { const t = makeTimers(); const w = VE().createWake({ now: t.now, timers: t, bridge }, Object.assign({ enabled: true }, cfg)); return { w, t }; };
  check("wake: accepts a confident wake once, rejects low confidence, wrong phrase, disabled state and rapid repeats", () => {
    const { w, t } = mkWake({}); const got = []; w.on("wake", (e) => got.push(e));
    assert(w.onWake({ phrase: "Hey EDO", confidence: 0.4 }).accepted === false);
    assert(w.onWake({ phrase: "hey siri", confidence: 0.99 }).accepted === false);
    assert(w.onWake({ phrase: "hey edo!", confidence: 0.9 }).accepted === true && got.length === 1, "case/punctuation must not matter");
    t.advance(1000); const r = w.onWake({ phrase: "Hey EDO", confidence: 0.99 }); assert(r.accepted === false && /too soon/.test(r.reason));
    t.advance(2000); assert(w.onWake({ phrase: "Hey EDO", confidence: 0.99 }).accepted === true, "refractory never ends");
    const s = w.status().stats; assert(s.accepted === 2 && s.rejected.lowConfidence === 1 && s.rejected.wrongPhrase === 1 && s.rejected.refractory === 1, JSON.stringify(s));
    const off = mkWake({ enabled: false }).w; assert(off.onWake({ confidence: 1 }).accepted === false && off.status().stats.rejected.disabled === 1);
  });
  check("wake: sensitivity changes the threshold; EDO ignores wake events caused by its own speech unless very confident", () => {
    const hi = mkWake({ sensitivity: "high" }).w, lo = mkWake({ sensitivity: "low" }).w;
    assert(hi.onWake({ confidence: 0.6 }).accepted === true && lo.onWake({ confidence: 0.6 }).accepted === false, "sensitivity has no effect");
    const { w } = mkWake({}); w.setSpeaking(true);
    assert(w.onWake({ confidence: 0.75 }).accepted === false && /speaking/.test(w.status().stats.rejected.speaking ? "speaking" : ""), "self-trigger accepted");
    assert(w.onWake({ confidence: 0.96 }).accepted === true, "a very confident wake must interrupt speech");
    const b = mkWake({}); b.w.setBusy(true); assert(b.w.onWake({ confidence: 0.99 }).accepted === false, "accepted while handling a request");
  });
  check("wake: a wake with no command times out back to idle", () => {
    const { w, t } = mkWake({ commandTimeoutMs: 3000 }); let to = 0; w.on("timeout", () => to++);
    w.onWake({ confidence: 0.9 }); assert(w.awaiting === true); t.advance(3100); assert(to === 1 && w.awaiting === false);
    w.onWake({ confidence: 0.9 }); t.advance(2900); w.commandReceived(); t.advance(5000); assert(to === 1, "timeout fired after a command arrived (" + to + ")");
  });
  check("wake: custom phrases are validated (length, characters, syllables, other assistants' names)", () => {
    const v = VE().validPhrase;
    assert(v("Hey EDO").ok && v("Jarvis wake up").ok && v("ok edo please").ok);
    assert(!v("hi").ok && !v("a".repeat(41)).ok && !v("<script>").ok && !v("go").ok && !v("OK Google").ok && !v("hey Siri").ok);
    const { w } = mkWake({}); return w.configure({ phrase: "no" }).then((r) => assert(r.ok === false && /characters|syllables/.test(r.reason), JSON.stringify(r)));
  });
  seq("wake: in a plain browser there is no detector and it says so; it never pretends to listen", async () => {
    const { w } = mkWake({ enabled: false }); const r = await w.configure({ enabled: true });
    assert(r.ok === false && /browser|no native/i.test(r.note), JSON.stringify(r));
    const s = w.status(); assert(s.native.available === false && /Android/.test(s.honest), JSON.stringify(s));
  });
  seq("wake: with a native bridge it configures the engine and reports what the device actually did", async () => {
    const calls = []; const mk = (reply) => ({ available: () => true, call: async (m, a) => { calls.push([m, a]); return reply; } });
    let { w } = mkWake({ enabled: false }, mk({ engineAvailable: true, engine: "porcupine", running: true }));
    let r = await w.configure({ enabled: true, phrase: "Hey EDO", sensitivity: "high" });
    assert(r.ok && w.status().native.running && w.status().native.engine === "porcupine" && calls[0][0] === "voice.configureWake" && calls[0][1].threshold === 0.55 && calls[0][1].phrase === "Hey EDO", JSON.stringify(calls));
    ({ w } = mkWake({ enabled: false }, mk({ engineAvailable: false, running: false, reason: "This build has no wake-word engine." })));
    r = await w.configure({ enabled: true }); assert(r.ok === false && /no wake-word engine/.test(r.note) && w.status().native.available === false);
    ({ w } = mkWake({ enabled: false }, { available: () => true, call: async () => { const e = new Error("Microphone permission not granted"); e.code = "permission_denied"; throw e; } }));
    r = await w.configure({ enabled: true }); assert(r.ok === false && /permission_denied/.test(r.note), JSON.stringify(r));
  });

  function session(opts) {
    opts = opts || {};
    const t = makeTimers(), rec = makeRec(), sy = makeSynth(opts.voices);
    const s = VE().createStt({ SpeechRecognition: rec.Rec, timers: t }, { silenceMs: 800 });
    const tts = VE().createTts({ speechSynthesis: sy.s, SpeechSynthesisUtterance: sy.Utt }, {});
    const wake = VE().createWake({ now: t.now, timers: t }, { enabled: true });
    const seen = []; const sess = VE().createSession({ stt: s, tts, wake }, Object.assign({ onCommand: async (x) => { seen.push(x); return { text: "You said " + x }; } }, opts));
    return { sess, t, rec, sy, tts, wake, s, seen };
  }
  const flush = () => new Promise((r) => setTimeout(r, 0));
  seq("session: wake → listening → transcript → thinking → speaking → idle, in that order", async () => {
    const { sess, t, rec, sy, seen } = session();
    sess.onWakeEvent({ phrase: "Hey EDO", confidence: 0.9 });
    assert(sess.state === "listening" && rec.last().started, "wake did not start listening: " + sess.state);
    rec.last().say("what time is it", true); t.advance(900); await flush();
    assert(seen[0] === "what time is it" && sess.state === "speaking" && /You said what time is it/.test(sy.s.spoken[0].text), sess.state + " " + JSON.stringify(seen));
    sy.s.spoken[0].onstart(); sy.s.spoken[0].onend(); await flush();
    assert(sess.state === "idle");
    const path = sess.log().map((x) => x.to).join(">"); assert(path === "wake_detected>listening>processing>speaking>idle", path);
  });
  seq("session: barge-in. User speech stops EDO talking and returns to listening", async () => {
    const { sess, t, rec, sy, tts } = session();
    sess.pushToTalk(); rec.last().say("tell me a story", true); t.advance(900); await flush();
    assert(sess.state === "speaking"); sy.s.spoken[0].onstart(); assert(tts.state === "speaking");
    sess.interrupt("user spoke");
    assert(sy.s.cancelled >= 1 && sess.state === "listening" && tts.state === "idle", sess.state + " cancelled " + sy.s.cancelled);
  });
  seq("session: speech detected by recognition while EDO speaks interrupts it (hands-free)", async () => {
    const { sess, t, rec, sy, tts } = session({ handsFree: true });
    sess.pushToTalk(); rec.last().say("hello", true); t.advance(900); await flush();
    sy.s.spoken[0].onstart(); sy.s.spoken[0].onend(); await flush();
    assert(sess.state === "listening", "hands-free should return to listening, got " + sess.state);
    sess.configure({ bargeIn: true }); assert(rec.last().started);
  });
  seq("session: a confident wake during speech interrupts it; a wake with no command goes back to idle", async () => {
    const { sess, t, rec, sy, wake } = session();
    sess.pushToTalk(); rec.last().say("hi", true); t.advance(900); await flush(); sy.s.spoken[0].onstart(); wake.setSpeaking(true);
    const r = sess.onWakeEvent({ phrase: "Hey EDO", confidence: 0.97 }); assert(r.accepted && sess.state === "listening", sess.state);
    t.advance(9000); assert(sess.state === "idle", "no command after wake must return to idle: " + sess.state);
  });
  seq("session: fatal recognition errors and handler failures move to 'error' and can recover", async () => {
    let c = session(); c.sess.pushToTalk(); c.rec.last().fail("not-allowed");
    assert(c.sess.state === "error" && /permission/i.test(c.sess.snapshot().error), c.sess.state);
    c.sess.pushToTalk(); assert(c.sess.state === "listening", "cannot retry after an error");
    c = session({ onCommand: async () => { throw new Error("engine broke"); } }); c.sess.pushToTalk(); c.rec.last().say("x", true); c.t.advance(900); await flush();
    assert(c.sess.state === "error" && /engine broke/.test(c.sess.snapshot().error), c.sess.state);
    c.sess.stop(); assert(c.sess.state === "idle");
  });
  seq("session: tap while listening ends the utterance now; stop() silences everything", async () => {
    const { sess, rec, seen, sy } = session(); sess.pushToTalk(); rec.last().say("quick one", false); sess.pushToTalk(); await flush();
    assert(seen[0] === "quick one", "tap did not commit: " + JSON.stringify(seen));
    sess.stop(); assert(sess.state === "idle" && sy.s.cancelled >= 1);
  });

  const V = (name, lang, local, def) => ({ name, lang, localService: local, default: !!def });
  check("tts: picks an installed on-device voice for the language, honours an explicit voice, applies rate and pitch", () => {
    const voices = [V("Net Hindi", "hi-IN", false), V("Local en-US", "en-US", true), V("Net en-IN", "en-IN", false), V("Local en-IN", "en-IN", true), V("Local Hindi", "hi-IN", true)];
    const { s, Utt } = makeSynth(voices); const tts = VE().createTts({ speechSynthesis: s, SpeechSynthesisUtterance: Utt }, { lang: "en-IN", rate: 1.2, pitch: 0.9 });
    assert(tts.pickVoice().name === "Local en-IN", tts.pickVoice().name);
    tts.configure({ lang: "hi-IN" }); assert(tts.pickVoice().name === "Local Hindi");
    tts.configure({ lang: "hinglish" }); assert(tts.pickVoice().name === "Local en-IN", "hinglish speech should use en-IN");
    tts.configure({ voiceName: "Net Hindi" }); assert(tts.pickVoice().name === "Net Hindi");
    tts.configure({ voiceName: null, lang: "en-IN" }); tts.speak("hello there"); const u = s.spoken[0];
    assert(u.rate === 1.2 && u.pitch === 0.9 && u.voice.name === "Local en-IN" && u.lang === "en-IN", JSON.stringify([u.rate, u.pitch, u.lang]));
  });
  check("tts: state transitions, interruption, and spoken text is cleaned of code and links", () => {
    const { s, Utt } = makeSynth([]); const tts = VE().createTts({ speechSynthesis: s, SpeechSynthesisUtterance: Utt }, {}); const ev = [];
    tts.speak("**Hello** see https://x.y/z\n```js\nconsole.log(1)\n```", { start: () => ev.push("start"), end: (e) => ev.push("end:" + e.reason) });
    assert(tts.state === "speaking" && !/https|console|\*\*|```/.test(s.spoken[0].text) && /code block omitted/.test(s.spoken[0].text) && /link/.test(s.spoken[0].text), s.spoken[0].text);
    s.spoken[0].onstart(); tts.cancel(); assert(tts.state === "idle" && s.cancelled === 1);
    tts.speak("again", { end: (e) => ev.push("end:" + e.reason) }); s.spoken[1].onstart(); s.spoken[1].onend(); assert(tts.state === "idle" && ev.includes("end:done"), JSON.stringify(ev));
    assert(tts.speak("   ") === null, "empty speech should not start");
    const none = VE().createTts({ speechSynthesis: null, SpeechSynthesisUtterance: null }, {}); let err; none.speak("x", { error: (e) => { err = e; } }); assert(err && err.code === "unsupported");
  });
  seq("tts: uses the Android TTS engine through the bridge when it is available, and falls back otherwise", async () => {
    const calls = []; const bridge = { available: () => true, supports: (m) => m === "tts.speak", call: async (m, a) => { calls.push([m, a]); return { spoken: true }; } };
    const { s, Utt } = makeSynth([]); const tts = VE().createTts({ bridge, speechSynthesis: s, SpeechSynthesisUtterance: Utt }, { lang: "hi-IN", rate: 1.1 }); let ended = false;
    tts.speak("namaste", { end: () => { ended = true; } }); assert(tts.state === "speaking"); await flush(); await flush();
    assert(ended && tts.state === "idle" && calls[0][0] === "tts.speak" && calls[0][1].lang === "hi-IN" && calls[0][1].rate === 1.1 && s.spoken.length === 0, JSON.stringify(calls));
    const nb = { available: () => true, supports: () => false, call: async () => ({}) }; const t2 = VE().createTts({ bridge: nb, speechSynthesis: s, SpeechSynthesisUtterance: Utt }, {}); t2.speak("hi"); assert(s.spoken.length === 1, "should fall back to the browser voice");
  });
};
