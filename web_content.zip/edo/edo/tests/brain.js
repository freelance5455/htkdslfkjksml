/* Brain, layered memory, friend conversation, planner, retrieval, proactive and MPC-layer tests. Real behaviour, fresh state per test. */
module.exports = function ({ check, assert, window }) {
  const W = window, ML = () => W.MemoryLayers;
  const DAY = 86400000;
  const T0 = new Date(2026, 9, 6, 10, 0, 0).getTime(); // Tue 6 Oct 2026 10:00 local
  const memStore = () => { const d = {}; return { d, failWrites: false, getItem(k) { return k in d ? d[k] : null; }, setItem(k, v) { if (this.failWrites) throw new Error("quota"); d[k] = String(v); }, removeItem(k) { delete d[k]; } }; };
  let T = T0;
  function fresh(opts) {
    opts = opts || {};
    T = opts.t || T0;
    const st = opts.store || memStore();
    ML().useStorage(st); ML().setClock(() => T); ML().setEnabled(true); ML().resetWorking();
    W.Memory.clear(); W.Memory.setEnabled(true); W.Friend.reset(); W.Brain.reset();
    W.Proactive.useStorage(memStore()); W.Proactive.setClock(() => T);
    ML().clearAll();
    return st;
  }
  const say = (text, mode) => { const r = W.EDO.handle(text, { mode: mode || "Friend", now: T }); T += 20000; return r; };
  const evNums = (r) => r.verification && r.verification.ok;

  check("brain: 'I got 90 marks today' is a personal update, never a web search", () => {
    fresh();
    const r = say("I got 90 marks today");
    assert(r.act === "score_update" && r.engine === "friend", r.act + " " + r.engine);
    assert(r.kind !== "search" && /90/.test(r.text), r.text);
    assert(!/search|look(ing)? up/i.test(r.text));
  });
  check("brain: 'my exam is next Friday' becomes a dated, remembered event", () => {
    fresh();
    const r = say("My exam is next Friday");
    assert(r.act === "event_update", r.act);
    const ev = ML().upcomingEvents(14);
    assert(ev.length === 1 && ev[0].date === "2026-10-09", JSON.stringify(ev));
    assert(/3 days away/.test(r.text), r.text);
  });
  check("brain: marks and exam in one sentence connect and save the event", () => {
    fresh();
    const r = say("I got 90 marks today and my exam is next Friday");
    assert(r.act === "score_update" && /90/.test(r.text) && /exam/i.test(r.text) && /3 days/.test(r.text), r.text);
    assert(ML().upcomingEvents(14).some((e) => /exam/i.test(e.title)), "event not saved");
    assert(evNums(r), "unexplained numbers: " + JSON.stringify(r.verification));
  });
  check("brain: a low score gets support, not congratulations, and an offer that leads somewhere", () => {
    fresh();
    const r = say("I scored 12/100 in my maths test today");
    assert(r.act === "score_update" && !/strong|solid|good going/i.test(r.text), r.text);
    assert(/recovery|marks went/i.test(r.text) && r.suggestions.includes("Make a recovery plan"), r.text);
  });
  check("brain: after a low score, tapping 'Make a recovery plan' starts the plan flow for that subject", () => {
    fresh(); say("I scored 12/100 in my maths test today");
    const a = say("Make a recovery plan");
    assert(a.act === "answer_pending" || a.act === "plan", a.act);
    assert(/how long/i.test(a.text) && /mathematics/i.test(a.text), a.text);
    const b = say("45 minutes"); assert(/45-minute recovery plan/.test(b.text) && /lost marks/i.test(b.text), b.text.slice(0, 200));
  });
  check("brain: an impossible score is not accepted", () => {
    fresh();
    const e = W.Brain.entities(W.Brain.normalize("I got 150/100 in physics"), T);
    assert(e.score === null, JSON.stringify(e.score));
  });
  check("brain: recall 'what did we talk about yesterday' uses saved conversation", () => {
    fresh();
    say("I have a physics test and I am revising electrostatics"); say("I will finish the Coulomb law problems tonight");
    T += DAY;
    const r = say("what did we talk about yesterday");
    assert(r.act === "recall" && r.engine === "memory-recall", r.act);
    assert(/yesterday/i.test(r.text) && /(physics|electrostatics|coulomb)/i.test(r.text), r.text);
  });
  check("brain: recall with nothing saved says so honestly instead of inventing", () => {
    fresh();
    const r = say("what did we talk about yesterday");
    assert(r.act === "recall" && /don't have anything saved/i.test(r.text), r.text);
  });
  check("brain: recall with memory OFF says memory is off and reveals nothing", () => {
    fresh(); say("I got 90 marks today"); ML().setEnabled(false);
    const r = W.EDO.handle("what did we talk about yesterday", { mode: "Friend", now: T + DAY, memoryOn: false });
    assert(/memory is switched off/i.test(r.text) && !/90/.test(r.text), r.text);
  });
  check("brain: 'you remember when we discussed ...' finds the topic by meaning", () => {
    fresh(); say("I am worried about my chemistry equilibrium chapter"); say("let me think about dinner");
    T += 3 * DAY;
    const r = say("do you remember when we discussed chemistry");
    assert(r.act === "recall" && /chemistry/i.test(r.text), r.text);
  });
  check("memory: extractive summaries capture topic, decisions and unresolved items, and trim raw turns", () => {
    fresh();
    for (let i = 0; i < 12; i++) { ML().addTurn("user", i % 3 === 0 ? "I will finish chapter " + (i + 1) + " of physics tomorrow." : "Revising kinematics problem " + i + " today.", {}); ML().addTurn("edo", "Okay."); T += 60000; }
    T += 3600000 * 3; // session gap
    for (let i = 0; i < 20; i++) { ML().addTurn("user", "Different topic now: cooking pasta number " + i + "?"); T += 60000; }
    ML().summarizeNow();
    const st = ML().inspect(), sums = st.items.filter((x) => x.layer === "summary");
    assert(sums.length >= 1, "no summary created");
    const raw = ML().recentTurns(200);
    assert(raw.length < 44, "raw turns not trimmed: " + raw.length);
    const db = JSON.parse(ML().status().persistent ? "{}" : "{}");
    const found = ML().recall("physics chapter", { window: { from: 0, to: T + 1, label: "earlier" }, limit: 3 }).hits;
    assert(found.some((h) => h.kind === "summary" && h.src.method === "extractive" && h.src.decisions.length >= 1), JSON.stringify(found.map((h) => h.text)));
  });
  check("memory: retention expires turns but keeps summaries until their own limit", () => {
    fresh();
    ML().addTurn("user", "old message about physics"); ML().addTurn("edo", "ok");
    ML().setRetention({ turnDays: 1, summaryDays: 180 });
    T += 3 * DAY;
    assert(ML().prune() === true, "prune did nothing");
    assert(ML().recentTurns(10).length === 0, "turn survived retention");
  });
  check("memory: inspect, delete one item, forget a topic, clear history, clear all", () => {
    fresh();
    say("my physics exam is next Friday"); say("I like chemistry"); ML().addPlan("Chemistry session", ["a", "b"]);
    const before = ML().inspect();
    assert(before.items.some((i) => i.layer === "event") && before.counts.plans === 1, JSON.stringify(before.counts));
    const ev = before.items.find((i) => i.layer === "event");
    assert(ML().deleteItem(ev.id) === true && !ML().inspect().items.some((i) => i.id === ev.id), "delete failed");
    const n = ML().forgetTopic("chemistry");
    assert(n >= 2, "forgot " + n);
    assert(!ML().inspect().items.some((i) => /chemistry/i.test(i.text)), "chemistry remained");
    ML().clearHistory(); assert(ML().inspect().counts.turns === 0);
    ML().clearAll(); assert(ML().inspect().items.length === 0, "clearAll left items");
  });
  check("memory: memory OFF stores and reads nothing, and turning it on starts clean", () => {
    const st = fresh(); ML().setEnabled(false);
    W.EDO.handle("I got 90 marks today", { mode: "Friend", now: T, memoryOn: false });
    assert(ML().addTurn("user", "x") === null && ML().addEvent("exam", "tomorrow") === null && ML().recentTurns(5).length === 0);
    assert(ML().inspect().enabled === false && ML().upcomingEvents(30).length === 0);
    ML().setEnabled(true);
    assert(ML().inspect().counts.turns === 0, "something was saved while off");
    assert(!/90/.test(st.d.edo_layers_v1 || ""), "data reached storage while off");
  });
  check("memory: corrupted storage recovers to empty, keeps a bounded backup, and keeps working", () => {
    const st = memStore(); st.d.edo_layers_v1 = "{not json ::: " + "x".repeat(30000);
    fresh({ store: st }); st.d.edo_layers_v1 = "{not json ::: " + "x".repeat(30000);
    const s = ML().status();
    assert(/reset/.test(s.lastError || ""), "no error reported: " + s.lastError);
    assert(st.d.edo_layers_v1_corrupt && st.d.edo_layers_v1_corrupt.length <= 20000, "backup missing or unbounded");
    assert(ML().addTurn("user", "works after recovery") && ML().recentTurns(5).length === 1);
    st.d.edo_layers_v1 = JSON.stringify({ v: 1, turns: "oops", summaries: [], events: [], plans: [] });
    assert(ML().recentTurns(5).length === 0 && /reset/.test(ML().status().lastError), "wrong-shape JSON was trusted");
  });
  check("memory: a failing storage write never throws and is reported", () => {
    const st = memStore(); fresh({ store: st }); st.failWrites = true;
    const t = ML().addTurn("user", "still works in RAM");
    assert(t && ML().recentTurns(5).length >= 0);
    assert(/write failed/.test(ML().status().lastError || ""), ML().status().lastError);
  });
  check("memory: the save hook fires for durable items so the UI can show 'saved'", () => {
    fresh(); const seen = []; ML().onSave((k) => seen.push(k));
    say("my chemistry test is tomorrow"); ML().addPlan("p", ["s"]);
    assert(seen.includes("event") && seen.includes("plan") && seen.includes("turn"), seen.join());
  });
  check("memory: explicit long-term notes appear in inspect and are removed by forgetTopic", () => {
    fresh(); W.EDO.handle("remember that my locker code hint is blue", { mode: "Friend", now: T });
    assert(ML().inspect().items.some((i) => /^long-term/.test(i.layer) && /locker/.test(i.text)), "long-term note not listed");
    assert(ML().forgetTopic("locker") >= 1 && !ML().inspect().items.some((i) => /locker/.test(i.text)));
  });
  check("semantic: synonyms and typos retrieve the right item; unrelated items stay out", () => {
    const S = W.Semantic;
    const r = S.rank("my test is coming", ["exam on Friday", "buy milk and eggs", "football match"], (x) => x, { limit: 3 });
    assert(r.length >= 1 && r[0].item === "exam on Friday", JSON.stringify(r));
    const r2 = S.rank("pysics revison plan", ["physics revision timetable", "cooking pasta"], (x) => x, {});
    assert(r2[0] && r2[0].item === "physics revision timetable", JSON.stringify(r2));
    assert(S.rank("enemy not moving", ["NPC chase patrol script", "shopping list"], (x) => x, {})[0].item === "NPC chase patrol script");
  });
  check("friend: study planning is interactive: asks, builds from the chapter notes, stores the plan", () => {
    fresh();
    const a = say("plan a study session with me");
    assert(a.act === "plan" && /which subject|how long/i.test(a.text) && a.engine === "planner", a.text);
    const b = say("physics 2 hours");
    assert(/plan/i.test(b.text) && /Warm-up/.test(b.text) && /120-minute/.test(b.text), b.text.slice(0, 300));
    assert(ML().activePlan() && ML().activePlan().subject === "physics", "plan not stored");
    assert(/shall we start/i.test(b.text));
  });
  check("friend: 'continue the plan', 'done', 'let's do that later' keep the active plan straight", () => {
    fresh(); say("plan a study session with me"); say("chemistry 60 minutes");
    const p = ML().activePlan(); assert(p && p.steps.length >= 4, "no plan");
    const c1 = say("continue the plan");
    assert(c1.act === "continue" && /step 1 of/i.test(c1.text), c1.text);
    const c2 = say("done");
    assert(c2.act === "answer_pending" && /step 2 of/i.test(c2.text), c2.text);
    const later = say("let's do that later");
    assert(later.act === "later" && ML().latestUnfinishedPlan().status === "later", "plan not parked");
    const c3 = say("continue the plan");
    assert(/step 2 of|step 3 of/i.test(c3.text) && ML().activePlan().status === "active", c3.text);
  });
  check("friend: 'continue' with nothing open is honest", () => {
    fresh();
    const r = say("continue the plan");
    assert(r.act === "continue" && /nothing open|don't have an open plan/i.test(r.text), r.text);
  });
  check("friend: 'make it better' resolves 'it' to the last plan; with no referent or memory off it says so", () => {
    fresh(); say("plan a study session with me"); say("physics 120 minutes");
    const s = say("make it shorter");
    assert(s.act === "refine" && /72|70|75|-minute plan/.test(s.text) && /plan/i.test(s.text), s.text.slice(0, 200));
    fresh();
    assert(/haven't made anything|not sure what/i.test(say("make it better").text));
    fresh(); ML().setEnabled(false);
    assert(/memory is off/i.test(W.EDO.handle("make it better", { mode: "Friend", now: T, memoryOn: false }).text));
  });
  check("friend: progress report uses recent context and offers a next step without always asking", () => {
    fresh(); say("I'm revising physics kinematics today");
    const r = say("I finished my physics revision");
    assert(r.act === "progress_done" && /physics/i.test(r.text) && /(harder|self-test|call it a day|round|rest)/i.test(r.text), r.text);
    const r2 = say("I completed my chemistry notes");
    assert(r2.act === "progress_done", r2.act);
  });
  check("friend: replies vary, no word-for-word repeats across consecutive similar updates", () => {
    fresh(); const seen = [];
    ["I finished my physics revision", "I completed my chemistry revision", "I finished my maths revision", "I completed my physics notes", "I finished my chemistry homework"].forEach((t) => seen.push(say(t).text.split(/(?<=[.!?])\s/)[0]));
    assert(new Set(seen).size >= 3, JSON.stringify(seen));
    for (let i = 1; i < seen.length; i++) assert(seen[i] !== seen[i - 1], "consecutive repeat: " + seen[i]);
  });
  check("friend: a setback with a request for help gets empathy then a concrete study path", () => {
    fresh();
    const r = say("I failed my physics test. Can you help me fix it?");
    assert(r.act === "setback_help" && /sorry|rough|hard/i.test(r.text) && /recovery|marks went/i.test(r.text), r.text);
    const p = say("Make a recovery plan");
    assert(/how long|which subject/i.test(p.text), p.text);
    const q = say("1 hour");
    assert(/recovery plan/.test(q.text) && /lost marks/i.test(q.text), q.text.slice(0, 300));
    assert(/Recovery session/.test(ML().activePlan().title), "stored plan is not the recovery plan");
  });
  check("friend: 'I changed my mind' drops the open question and asks what instead", () => {
    fresh(); say("plan a study session with me");
    const r = say("I changed my mind");
    assert(r.act === "change_mind" && /instead|what now/i.test(r.text), r.text);
    const pend = ML().getState().pending;
    assert(!pend || pend.kind === "new_direction", "the old question was kept: " + JSON.stringify(pend));
  });
  check("friend: mood plus an upcoming exam mentions the exam; mood alone defers to the companion", () => {
    fresh(); say("my physics exam is next Friday");
    const r = say("I'm so stressed about everything");
    assert(/exam/i.test(r.text), r.text);
    fresh();
    const r2 = say("I'm so stressed about everything");
    assert(r2.kind === "chat" && !/exam/i.test(r2.text), r2.kind + " " + r2.text);
  });
  check("brain: explicit commands are not hijacked (search, calculator, device, crisis safety)", () => {
    fresh();
    assert(say("search latest news today").kind === "search", "search hijacked");
    assert(/10000/.test(say("100×100").text), "calculator hijacked");
    assert(say("open whatsapp").kind === "device", "device hijacked");
    assert(say("I want to end my life").kind === "crisis" || /988|helpline|crisis|someone/i.test(say("I want to end my life").text), "crisis path lost");
  });
  check("brain: modes stay meaningful; Basic still gates solving but allows conversation and planning", () => {
    fresh();
    assert(say("u=0 a=2 t=5 find v", "Basic").kind === "upgrade", "Basic must still gate solving");
    assert(say("I got 90 marks today", "Basic").act === "score_update");
    assert(say("plan a study session with me", "Basic").act === "plan");
    fresh();
    assert(/10/.test(say("u=0 a=2 t=5 find v", "Assistant").text), "Pro solver changed");
  });
  check("brain: trace lists the pipeline stages in order for a conversational turn", () => {
    fresh(); const r = say("I got 90 marks today");
    const st = r.trace.map((x) => x.stage);
    ["normalize", "entities", "classify", "retrieve", "choose engine", "verify"].forEach((s) => assert(st.includes(s), "missing stage " + s + ": " + st));
    assert(st.indexOf("classify") < st.indexOf("choose engine") && st.indexOf("choose engine") < st.indexOf("verify"));
  });
  check("brain: every number in a generated reply traces to the user's words, memory or the plan", () => {
    fresh(); const rs = [say("I got 90 marks today and my exam is next Friday"), say("plan a study session with me"), say("physics 90 minutes"), say("continue the plan"), say("what were we doing")];
    rs.forEach((r) => assert(!r.verification || r.verification.ok, r.act + " extra numbers " + JSON.stringify(r.verification)));
  });
  check("proactive: upcoming exam nudge appears once, respects cooldown, settings and memory OFF", () => {
    fresh(); say("my physics exam is on friday");
    const n = W.Proactive.suggest();
    assert(n && n.kind === "event" && /3 days|in 3|exam/i.test(n.text), JSON.stringify(n));
    assert(W.Proactive.suggest() === null, "repeated within cooldown");
    T += 13 * 3600000; assert(W.Proactive.suggest() !== null, "cooldown never expires");
    W.Proactive.setConfig({ enabled: false }); T += 13 * 3600000; assert(W.Proactive.suggest() === null, "disabled still nudges");
    W.Proactive.setConfig({ enabled: true }); ML().setEnabled(false); assert(W.Proactive.suggest() === null, "nudged with memory off");
  });
  check("proactive: unfinished plan is raised after a pause, and native reminders refuse without the Android build", () => {
    fresh(); say("plan a study session with me"); say("physics 60 minutes");
    T += 40 * 60000;
    const n = W.Proactive.suggest();
    assert(n && n.kind === "plan" && /unfinished plan/i.test(n.text), JSON.stringify(n));
    return W.Proactive.scheduleNative({ id: "e1", title: "Exam", date: "2026-10-09" }).then((r) => assert(r.ok === false && /switched off|Android/i.test(r.reason), JSON.stringify(r)));
  });
  check("retrieval: Unity context outranks generic notes; prerequisites and learning path are real", () => {
    const R = W.Retrieval;
    const hits = R.search("why is my enemy not moving", { mode: "Programming", unity: true, languages: ["csharp"] });
    assert(hits.length && hits[0].doc.id === "prog-unity-ai", hits.map((h) => h.doc.id).join());
    assert(hits[0].why.some((w) => /Unity|Programming/.test(w)), JSON.stringify(hits[0].why));
    const path = R.path("prog-unity-ai").map((d) => d.id);
    assert(path.indexOf("prog-unity-core") < path.indexOf("prog-unity-ai") && path.indexOf("prog-unity-physics") < path.indexOf("prog-unity-ai"), path.join());
    assert(R.related("prog-unity-core").next.length >= 3, "next-topics graph empty");
    assert(R.search("falls through the floor", { unity: true })[0].doc.id === "prog-unity-physics");
  });
  check("mpc: the Coulomb problem in natural language is solved, verified, and enriched without changing the number", () => {
    const base = W.EDO.handle("Two charges 2 uC and 3 uC are 30 cm apart. Find the force between them", { mode: "Assistant", brain: false });
    const r = W.EDO.handle("I have a 2 microcoulomb charge here and a 3 microcoulomb charge 30 cm away. Find the force.", { mode: "Assistant" });
    assert(r.kind === "reason" && /0\.6|0\.60|6\.0\d*e-1|0\.599/.test(r.text), r.text.slice(0, 300));
    assert(r.mpc && /electro/i.test(r.mpc.chapter || r.mpc.domain || "physics") || r.mpc, "no mpc layer data");
    const num = (t) => (t.match(/0\.\d+/) || [])[0];
    assert(num(base.text) === num(r.text), "enrichment changed the number: " + num(base.text) + " vs " + num(r.text));
  });
  check("mpc: sanity checks flag impossible answers and never invent one", () => {
    const f = W.MPC.sanity("**v = 4e9 m/s**"); assert(f.length === 1 && /light/.test(f[0]), JSON.stringify(f));
    assert(W.MPC.sanity("**t = -3 s**").length === 1);
    assert(W.MPC.sanity("**efficiency = 130 %**").length === 1);
    assert(W.MPC.sanity("**v = 12 m/s**").length === 0);
  });
};
