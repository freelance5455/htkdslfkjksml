/* Typed Android bridge (JS client) behaviour against a simulated native side, plus static checks of the Kotlin sources and manifest.
   Honest scope: the Kotlin is checked by reading it (structure, permissions, safety rules). It has NOT been compiled or run. */
module.exports = function ({ check, assert, fs, path, root, vm }) {
  const read = (rel) => fs.readFileSync(path.join(root, rel), "utf8");
  const clientSrc = read("bridge/android-client.js");
  let q = Promise.resolve();
  const seq = (name, fn) => check(name, () => { const p = q.then(fn); q = p.catch(() => {}); p.catch(() => {}); return p; });
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  /* a fresh page + a scriptable native side; reply(ok, payload) answers later */
  function mk(handler) {
    const sb = { console, setTimeout, clearTimeout, JSON, Math, Date, Promise, Error, Object, Array, String, Number, RegExp, Set, Map, Symbol };
    sb.window = sb; sb.globalThis = sb; const ctx = vm.createContext(sb);
    const calls = [];
    sb.EDOAndroid = { invoke(id, method, args) { const a = JSON.parse(args); calls.push({ id, method, args: a }); const reply = (ok, payload) => setTimeout(() => sb.__edoBridgeResult(id, ok, typeof payload === "string" ? payload : JSON.stringify(payload)), 0); try { handler({ id, method, args: a, reply, sb }); } catch (e) { reply(false, { code: "native_error", message: e.message }); } } };
    vm.runInContext(clientSrc, ctx);
    return { B: sb.Bridge, sb, calls };
  }
  const caps = (extra) => Object.assign({ methods: ["ping", "capabilities", "appList", "openApp", "pickFile", "pickProject", "tts.speak", "voice.status", "voice.configureWake", "notify", "cancel"], version: 2, session: 111, features: { nativeVoice: true }, permissions: { calls: false } }, extra || {});

  seq("bridge: capabilities are discovered, cached, and gate what EDO attempts", async () => {
    const { B, calls } = mk((r) => r.reply(true, caps()));
    const c = await B.capabilities();
    assert(c.available && c.methods.includes("appList") && c.version === 2 && c.session === 111 && c.features.nativeVoice === true && c.permissions.calls === false, JSON.stringify(c));
    assert(B.supportsSync("appList") && !B.supportsSync("calendarEvents"), "support must come from the device's own list");
    await B.capabilities(); assert(calls.filter((x) => x.method === "capabilities").length === 1, "capabilities not cached");
    assert(B.methods.includes("scheduleReminder") && B.ERROR_CODES.length === 8);
  });
  seq("bridge: every typed error code survives the round trip, and plain legacy errors are still classified", async () => {
    for (const code of ["unavailable", "permission_denied", "unsupported", "invalid_arguments", "not_found", "timeout", "native_error", "cancelled"]) {
      const { B } = mk((r) => r.reply(false, { code, message: "m-" + code })); let e; try { await B.call("openApp", { name: "x" }); } catch (x) { e = x; }
      assert(e && e.code === code && e.message === "m-" + code, code + " → " + (e && e.code));
    }
    const { B } = mk((r) => r.reply(false, "Contacts permission not granted")); let e; try { await B.call("findContact", { query: "a" }); } catch (x) { e = x; }
    assert(e && e.code === "permission_denied", e && e.code);
  });
  seq("bridge: unsupported capability is reported by the native side as unsupported, not as a crash", async () => {
    const { B } = mk((r) => r.reply(false, { code: "unsupported", message: "Unknown method: calendarEvents" })); let e; try { await B.call("calendarEvents", { from: 1, to: 2 }); } catch (x) { e = x; }
    assert(e && e.code === "unsupported" && e.method === "calendarEvents", JSON.stringify(e && e.code));
  });
  seq("bridge: no native side means 'unavailable' immediately (plain browser)", async () => {
    const sb = { console, setTimeout, clearTimeout, JSON, Math, Date, Promise, Error, Object, Array, String, Number, RegExp, Set, Map }; sb.window = sb; vm.runInContext(clientSrc, vm.createContext(sb));
    let e; try { await sb.Bridge.call("ping"); } catch (x) { e = x; }
    assert(e && e.code === "unavailable" && sb.Bridge.available() === false && (await sb.Bridge.capabilities()).available === false);
  });
  seq("bridge: timeout rejects with 'timeout', and a late native answer is ignored harmlessly", async () => {
    let late; const { B, sb } = mk((r) => { late = r; });
    let e; try { await B.call("notify", { text: "x" }, { timeoutMs: 30 }); } catch (x) { e = x; }
    assert(e && e.code === "timeout" && Object.keys(B._p).length === 0, e && e.code);
    late.reply(true, { shown: true }); await sleep(10);
    sb.__edoBridgeResult(99999, true, "{}"); sb.__edoBridgeResult(late.id, true, "{}"); // unknown and duplicate ids
    assert(Object.keys(B._p).length === 0, "late reply left state behind");
  });
  seq("bridge: cancellation rejects at once, tells the phone to stop, and late replies are dropped", async () => {
    let first; const { B, calls } = mk((r) => { if (r.method === "pickFile") first = r; else r.reply(true, { cancelRequested: true }); });
    const h = B.callCancelable("pickFile", {}, { timeoutMs: 5000 }); await sleep(5);
    assert(h.id > 0 && h.cancel() === true, "cancel refused");
    let e; try { await h.promise; } catch (x) { e = x; } assert(e && e.code === "cancelled", e && e.code);
    const c = calls.find((x) => x.method === "cancel"); assert(c && c.args.target === h.id, "native was not told to cancel: " + JSON.stringify(calls));
    first.reply(true, { name: "late.txt" }); await sleep(10); assert(h.cancel() === false, "second cancel must be a no-op");
    const h2 = B.callCancelable("ping", {}, {}); await h2.promise.catch(() => {}); assert(h2.cancel() === false, "cancelling a finished call must be a no-op");
  });
  seq("bridge: an AbortSignal cancels a long operation", async () => {
    const { B } = mk(() => {}); const ac = new AbortController(); const h = B.callCancelable("pickProject", {}, { timeoutMs: 5000, signal: ac.signal });
    setTimeout(() => ac.abort(), 10); let e; try { await h.promise; } catch (x) { e = x; } assert(e && e.code === "cancelled");
    const pre = new AbortController(); pre.abort(); const h3 = B.callCancelable("pickFile", {}, { signal: pre.signal }); let e3; try { await h3.promise; } catch (x) { e3 = x; } assert(e3 && e3.code === "cancelled", "pre-aborted signal ignored");
  });
  seq("bridge: long operations report progress without settling, and progress after completion is ignored", async () => {
    const got = []; const { B, sb } = mk((r) => { sb.__edoBridgeProgress(r.id, JSON.stringify({ files: 10 })); sb.__edoBridgeProgress(r.id, JSON.stringify({ files: 20 })); setTimeout(() => r.reply(true, { files: 20 }), 15); });
    const h = B.callCancelable("pickProject", {}, { timeoutMs: 1000, onProgress: (p) => got.push(p.files) }); const res = JSON.parse(await h.promise);
    sb.__edoBridgeProgress(h.id, JSON.stringify({ files: 99 })); assert(got.join() === "10,20" && res.files === 20, got.join());
  });
  seq("bridge: native events reach subscribers, unsubscribe works, bad events are ignored", async () => {
    const { B, sb } = mk(() => {}); const seen = [], all = []; const off = B.on("voice.wake", (e) => seen.push(e)); B.on("*", (e, n) => all.push(n));
    sb.__edoBridgeEvent("voice.wake", JSON.stringify({ phrase: "Hey EDO", confidence: 0.9 })); sb.__edoBridgeEvent("voice.state", "{bad json"); sb.__edoBridgeEvent("x".repeat(80), "{}"); sb.__edoBridgeEvent(5, "{}");
    assert(seen.length === 1 && seen[0].confidence === 0.9 && all.join() === "voice.wake,voice.state", seen.length + " " + all.join());
    off(); sb.__edoBridgeEvent("voice.wake", "{}"); assert(seen.length === 1, "unsubscribed handler still called");
  });
  seq("bridge: lifecycle. A new native session cancels in-flight calls; the same session leaves them alone", async () => {
    let session = 1, held; const { B } = mk((r) => { if (r.method === "capabilities") r.reply(true, caps({ session })); else held = r; });
    await B.resync(); const pending = B.call("openApp", { name: "x" }, { timeoutMs: 2000 }).then(() => "done", (e) => e.code);
    await B.resync(); assert(Object.keys(B._p).length === 1, "same session must not cancel");
    session = 2; await B.resync(); assert(await pending === "cancelled", "activity/process recreation must cancel pending calls");
    held.reply(true, {}); await sleep(5);
  });
  seq("bridge: device-changing methods are never retried automatically", async () => {
    const { B, calls } = mk((r) => r.reply(false, { code: "native_error", message: "transient" }));
    await B.call("notify", { text: "x" }).catch(() => {}); await B.call("call", { number: "123" }).catch(() => {}); await B.call("openApp", { name: "x" }).catch(() => {});
    assert(calls.filter((c) => c.method === "notify").length === 1 && calls.filter((c) => c.method === "call").length === 1 && calls.filter((c) => c.method === "openApp").length === 1, JSON.stringify(calls.map((c) => c.method)));
  });
  seq("bridge: voice service communication round-trips structured state and settings", async () => {
    const { B, calls } = mk((r) => { if (r.method === "voice.status") r.reply(true, { nativeVoiceAvailable: true, wakeWordEnabled: false, listening: false, speaking: false, serviceRunning: false, microphonePermission: true, voiceError: null }); else r.reply(true, { engineAvailable: false, running: false, reason: "no engine" }); });
    const s = await B.typed.call("voice.status"); ["nativeVoiceAvailable", "wakeWordEnabled", "listening", "speaking", "serviceRunning", "microphonePermission", "voiceError"].forEach((k) => assert(k in s, "missing " + k));
    const c = await B.typed.call("voice.configureWake", { phrase: "Hey EDO", sensitivity: "medium", threshold: 0.7, enabled: true }); assert(c.engineAvailable === false && /no engine/.test(c.reason));
    assert(calls[1].args.phrase === "Hey EDO" && calls[1].args.threshold === 0.7 && calls[1].args.enabled === true, JSON.stringify(calls[1]));
  });
  seq("bridge: app launch, contacts, notifications and call go through typed calls with the user's confirmation flag", async () => {
    const { B, calls } = mk((r) => { if (r.method === "findContact") r.reply(true, { matches: [{ name: "Asha", number: "98765 43210" }] }); else if (r.method === "call") r.reply(true, { mode: r.args.confirmed ? "call" : "dial", number: r.args.number }); else r.reply(true, { ok: true }); });
    assert(JSON.parse(await B.call("findContact", { query: "asha" })).matches[0].name === "Asha");
    assert(JSON.parse(await B.call("call", { number: "9876543210" })).mode === "dial", "an unconfirmed call must only dial");
    assert(JSON.parse(await B.call("call", { number: "9876543210", confirmed: true })).mode === "call");
    await B.call("openApp", { name: "WhatsApp" }); await B.call("notify", { title: "EDO", text: "hi" }); assert(calls.map((c) => c.method).join() === "findContact,call,call,openApp,notify");
    const dev = read("tools/device.js"); assert(/Bridge\.call\("call", \{ number: n, confirmed: true \}\)/.test(dev), "confirmed:true must only be sent from the confirmed-call path");
  });

  /* ---------- Kotlin / manifest static checks ---------- */
  const kdir = "android/app/src/main/java/com/edo/app/";
  const ktFiles = () => fs.readdirSync(path.join(root, kdir)).filter((f) => f.endsWith(".kt"));
  // One left-to-right pass, so a string literal holding a slash-star sequence is not mistaken for a comment, and a comment's apostrophe is not a char literal.
  const stripKt = (s) => s.replace(/"""[\s\S]*?"""|"(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])'|\/\*[\s\S]*?\*\/|\/\/[^\n]*/g, (m) => (m[0] === '"' ? '""' : m[0] === "'" ? "' '" : ""));
  check("android: every Kotlin file has balanced braces, parentheses and brackets", () => {
    ktFiles().forEach((f) => { const s = stripKt(read(kdir + f)); [["{", "}"], ["(", ")"], ["[", "]"]].forEach(([o, c]) => { const a = s.split(o).length - 1, b = s.split(c).length - 1; assert(a === b, f + ": " + o + c + " " + a + " vs " + b); }); });
  });
  check("android: every JS bridge method is implemented in Kotlin, listed in capabilities, and nothing extra is silently exposed", () => {
    const kt = read(kdir + "EdoBridge.kt"), js = clientSrc.match(/const METHODS = \[([\s\S]*?)\];/)[1].match(/"[^"]+"/g).map((x) => x.slice(1, -1));
    const listed = kt.match(/val methods = listOf\(([\s\S]*?)\n    \)/)[1].match(/"[^"]+"/g).map((x) => x.slice(1, -1));
    const dispatched = [...kt.matchAll(/^\s+"([\w.]+)" ->/gm)].map((m) => m[1]);
    js.forEach((m) => { assert(listed.includes(m), m + " missing from Kotlin capabilities list"); assert(dispatched.includes(m), m + " has no dispatch branch"); });
    listed.forEach((m) => assert(js.includes(m), "Kotlin exposes " + m + " but the JS contract does not know it"));
  });
  check("android: every permission the Kotlin uses is declared in the manifest, and risky components are not exported", () => {
    const man = read("android/app/src/main/AndroidManifest.xml"), used = new Set();
    ktFiles().forEach((f) => (read(kdir + f).match(/Manifest\.permission\.([A-Z_]+)/g) || []).forEach((m) => used.add(m.split(".").pop())));
    used.forEach((p) => assert(new RegExp('uses-permission android:name="android\\.permission\\.' + p + '"').test(man), "manifest lacks " + p));
    assert(/<service android:name="\.VoiceService"[^>]*android:exported="false"[^>]*foregroundServiceType="microphone"/.test(man), "voice service must be private and typed");
    assert(/<receiver android:name="\.ReminderReceiver"[^>]*android:exported="false"/.test(man), "reminder receiver must be private");
    assert(!/BOOT_COMPLETED/.test(man), "nothing may start itself at boot");
    assert((man.match(/android:exported="true"/g) || []).length === 1, "only the launcher activity may be exported");
    ["WRITE_CONTACTS", "SEND_SMS", "READ_SMS", "WRITE_EXTERNAL_STORAGE", "READ_CALL_LOG", "SYSTEM_ALERT_WINDOW", "REQUEST_INSTALL_PACKAGES"].forEach((p) => assert(!man.includes(p), "manifest asks for " + p));
  });
  check("android: the WebView is hardened and the bridge only answers the bundled page", () => {
    const main = read(kdir + "MainActivity.kt"), br = read(kdir + "EdoBridge.kt");
    ["allowFileAccess = false", "allowContentAccess = false", "allowFileAccessFromFileURLs = false", "allowUniversalAccessFromFileURLs = false", "setWebContentsDebuggingEnabled(false)"].forEach((x) => assert(main.includes(x), "missing " + x));
    assert(/file:\/\/\/android_asset\/edo\//.test(main) && !/loadUrl\("http/.test(main), "must load only the bundled page");
    assert((main.match(/addJavascriptInterface/g) || []).length === 1 && ktFiles().filter((f) => f !== "MainActivity.kt").every((f) => !/addJavascriptInterface/.test(read(kdir + f))), "bridge exposed more than once");
    assert(/fun invoke\(id: Int, method: String, args: String\) \{\s*if \(destroyed\) return\s*if \(!isTrusted\(\)\)/.test(br), "invoke must check destroyed and trust before anything else");
    assert(/onRenderProcessGone/.test(main) && /bridge\?\.destroy\(\)/.test(main) && /onDestroy[\s\S]*removeJavascriptInterface/.test(main), "WebView lifecycle not handled");
    assert(/override fun onBackPressed[\s\S]*__edoBack/.test(main), "back button must go to the page first");
  });
  check("android: calls need confirmation, emergency numbers never auto-dial, permissions are never requested silently", () => {
    const br = read(kdir + "EdoBridge.kt");
    assert(/val direct = granted && confirmed && number !in emergency/.test(br), "call safety rule changed");
    assert(/"112"/.test(br) && /ACTION_DIAL/.test(br) && /ACTION_CALL/.test(br));
    assert(!/requestPermissions\(/.test(br.replace(/private fun need[\s\S]*?\n    }\n/, "").replace(/private fun requestGroup[\s\S]*?\n    }\n/, "")), "a permission prompt exists outside need()/requestGroup()");
    assert(/"requestPermissions" -> requestGroup/.test(br));
    ["deleteFile", ".delete()", "SmsManager", "installPackage", "Settings.System.put", "setComponentEnabledSetting"].forEach((x) => assert(!br.includes(x), "destructive or silent API present: " + x));
  });
  check("android: the voice service needs the user's switch, the mic permission and an engine, and never restarts itself", () => {
    const vs = read(kdir + "VoiceService.kt"), we = read(kdir + "WakeWordEngine.kt");
    assert(/RECORD_AUDIO/.test(vs) && /WakeWordEngines\.create\(this\)/.test(vs) && /no wake-word engine/.test(vs), "service must refuse without permission and engine");
    assert(/START_NOT_STICKY/.test(vs) && !/START_STICKY/.test(vs.replace(/START_NOT_STICKY/g, "")), "service must not be sticky");
    assert(/FOREGROUND_SERVICE_TYPE_MICROPHONE/.test(vs) && /setOngoing\(true\)/.test(vs), "must show a persistent notification while listening");
    assert(/Repeatedly running full speech\s*\/\/ recognition is NOT a wake-word engine/.test(we) || /NOT a wake-word engine/.test(we), "engine contract must state the honest limit");
    assert(/need\(Manifest\.permission\.RECORD_AUDIO/.test(read(kdir + "EdoBridge.kt")), "configureWake must check the mic permission");
  });
  check("android: sources state clearly that they were not compiled here, and the Gradle build ships the new folders", () => {
    ["EdoBridge.kt", "MainActivity.kt", "VoiceService.kt", "VoiceHub.kt", "EdoTts.kt", "WakeWordEngine.kt", "ReminderReceiver.kt"].forEach((f) => assert(/UNVERIFIED/.test(read(kdir + f)), f + " must carry the UNVERIFIED note"));
    const g = read("android/app/build.gradle.kts"); ["workers/**", "voice/**", "ui/**", "media/**", "knowledge/**"].forEach((x) => assert(g.includes(x), "gradle does not copy " + x));
  });
};
