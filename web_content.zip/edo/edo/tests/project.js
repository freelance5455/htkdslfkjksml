/* Project workspace, CodeBrain, validation and runner-contract tests. Real indexing, real patches, real checks. */
module.exports = function ({ check, assert, window }) {
  const W = window;
  let q = Promise.resolve();
  const seq = (name, fn) => check(name, () => { const p = q.then(fn); q = p.catch(() => {}); p.catch(() => {}); return p; });
  const F = (path, content) => ({ path, content });

  const UNITY = () => [
    F("Assets/Scripts/Enemy.cs", "using UnityEngine;\npublic class Enemy : MonoBehaviour {\n  [SerializeField] private float speed = 2f;\n  public Transform target;\n  private Rigidbody rb;\n  void Awake() { rb = GetComponent<Rigidbody>(); }\n  void update() { transform.position += Vector3.forward * speed; }\n  void Update() {\n    var p = FindObjectOfType<Player>();\n    GetComponent<Rigidbody>().AddForce(Vector3.up);\n    transform.position += Vector3.forward * speed;\n    Debug.Log(\"x\" + speed);\n    if (target?.position.x > 1) { }\n  }\n  public void TakeDamage(int n) { }\n}\n"),
    F("Assets/Scripts/Enemy.cs.meta", "fileFormatVersion: 2\nguid: aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n"),
    F("Assets/Scripts/Player.cs", "using UnityEngine;\npublic class Player : MonoBehaviour { void Start(){ var e = FindObjectOfType<Enemy>(); e.TakeDamage(1);} }\n"),
    F("Assets/Scenes/Main.unity", "--- !u!114 &1\nMonoBehaviour:\n  m_Script: {fileID: 11500000, guid: aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa, type: 3}\n  speed: 0\n  target: {fileID: 0}\n"),
    F("ProjectSettings/ProjectVersion.txt", "m_EditorVersion: 2022.3.10f1\n"),
  ];
  const WEB = () => [
    F("package.json", '{"name":"demo","main":"src/index.js","dependencies":{"lodash":"1"}}'),
    F(".gitignore", "dist/\n*.log\n"),
    F("src/index.js", "import { add } from './math';\nconst u = require('./util/helpers');\nimport _ from 'lodash';\n// add(1) in a comment\nconst s = 'add';\nconsole.log(add(1,2), u.fmt('x'));\n"),
    F("src/math.js", "export function add(a,b){ return a+b }\nexport const PI2 = 6.28;\nexport class Calc { sum(a){ return add(a,1) } }\n"),
    F("src/util/helpers.js", "const { add } = require('../math');\nfunction fmt(s){ return add(1,1)+s }\nmodule.exports={fmt};\n"),
    F("dist/bundle.js", "var add=1"), F("node_modules/x/index.js", "x"), F("debug.log", "noise"),
    F("app/main.py", "from .models import User\nimport os\nclass App:\n    def run(self):\n        return User()\n"),
    F("app/models.py", "class User:\n    def __init__(self): pass\n"), F("app/__init__.py", ""),
  ];
  const mk = (files, name) => { const p = W.Project.create({ name: name || "t" }); p.addFiles(files); return p; };

  check("project: multi-file index resolves imports across JS and Python, skips ignored paths, and finds entry points", () => {
    const p = mk(WEB()), s = p.stats();
    assert(s.languages.javascript === 3 && s.languages.python === 3, JSON.stringify(s.languages));
    ["dist/bundle.js", "node_modules/x/index.js", "debug.log"].forEach((x) => assert(!p.hasFile(x), x + " should be ignored"));
    assert(p.dependenciesOf("src/index.js").join() === "src/math.js,src/util/helpers.js", p.dependenciesOf("src/index.js").join());
    assert(p.dependenciesOf("app/main.py").join() === "app/models.py", p.dependenciesOf("app/main.py").join());
    assert(p.externalModules().lodash === 1, JSON.stringify(p.externalModules()));
    assert(p.entryPoints().some((e) => e.path === "src/index.js" && /package.json main/.test(e.why)), JSON.stringify(p.entryPoints()));
    assert(p.dependencies()["package.json"].dependencies.includes("lodash"));
  });
  check("project: symbol search finds definitions with kind, line and container; ambiguity is reported, not guessed", () => {
    const p = mk(WEB());
    const d = p.whereDefined("add"); assert(d.definitions.length === 1 && d.definitions[0].path === "src/math.js" && d.definitions[0].line === 1, JSON.stringify(d));
    assert(p.whereDefined("Calc.sum").definitions[0].container === "Calc", "method owner");
    p.addFiles([F("src/other.js", "export function add(x){ return x }\n")]);
    assert(p.whereDefined("add").ambiguous === true, "two definitions must be flagged ambiguous");
    assert(p.search("sum calc", 3).some((r) => r.name === "sum"));
  });
  check("project: references ignore comments and strings and give correct line numbers", () => {
    const p = mk(WEB()), r = p.references("add");
    const idx = r.references.filter((x) => x.path === "src/index.js");
    assert(idx.length === 2 && idx.every((x) => x.line === 1 || x.line === 6), JSON.stringify(idx));
    assert(!r.references.some((x) => x.path === "src/index.js" && x.line === 4), "comment counted");
    assert(!r.references.some((x) => x.path === "src/index.js" && x.line === 5), "string counted");
    assert(r.references.find((x) => x.path === "src/math.js" && x.line === 1).definition === true);
  });
  check("project: dependents, transitive impact and risk levels follow the real graph", () => {
    const p = mk(WEB());
    assert(p.dependents("src/math.js").join() === "src/index.js,src/util/helpers.js", p.dependents("src/math.js").join());
    const t = p.dependents("src/math.js", { transitive: true }).map((x) => x.path); assert(t.includes("src/index.js"));
    const i = p.impact("src/math.js"); assert(i.kind === "file" && i.directDependents.length === 2 && i.symbolsInUse.some((s) => s.symbol === "add"), JSON.stringify(i).slice(0, 300));
    assert(p.impact("add").usedIn.includes("src/index.js"));
    assert(p.impact("nothingHere").found === false);
  });
  check("project: dependency cycles are detected", () => {
    const p = mk([F("a.js", "import './b'\nexport const a=1"), F("b.js", "import './c'\nexport const b=1"), F("c.js", "import './a'\nexport const c=1"), F("d.js", "import './a'")]);
    const cyc = p.cycles(); assert(cyc.length === 1 && cyc[0].join() === "a.js,b.js,c.js", JSON.stringify(cyc));
  });
  check("project: C# and Unity: classes, bases, serialized fields, GUID links from scenes, project version", () => {
    const p = mk(UNITY()), c = p.classInfo("Enemy");
    assert(c.bases[0] === "MonoBehaviour" && c.methods.includes("Update") && c.methods.includes("TakeDamage"), JSON.stringify(c));
    assert(c.fields.some((f) => f.name === "speed" && /SerializeField/.test(f.attrs)) && c.fields.some((f) => f.name === "target" && f.access === "public"));
    assert(p.isUnity() === true && p.assetUsage("Assets/Scripts/Enemy.cs")[0].kind === "scene");
    assert(p.dependenciesOf("Assets/Scripts/Player.cs").includes("Assets/Scripts/Enemy.cs"), "usage-based dependency missing");
    assert(p.dependencies, "deps");
  });
  check("project: incremental update re-links only what changed and ignores identical content", () => {
    const p = mk(WEB()); p.stats(); const v = p.version();
    p.updateFile("src/math.js", p.read("src/math.js")); p.stats(); assert(p.version() === v, "identical content must not relink");
    p.updateFile("src/util/helpers.js", "function fmt(s){ return s }\nmodule.exports={fmt};\n");
    assert(p.dependenciesOf("src/util/helpers.js").length === 0 && p.dependents("src/math.js").join() === "src/index.js", "edges not updated");
    assert(p.live().recentEdits[0].path === "src/util/helpers.js");
  });
  seq("project: async indexing yields to the event loop, reports progress, and can be cancelled", async () => {
    const files = []; for (let i = 0; i < 900; i++) files.push(F("src/m" + i + ".js", "import './m" + ((i + 1) % 900) + "';\nexport function f" + i + "(a){ return a + " + i + "; }\n".repeat(30)));
    const p = W.Project.create({ name: "big" }); let ticks = 0; const timer = setInterval(() => ticks++, 0); let progress = 0;
    const s = await p.indexAsync(files, { budgetMs: 4, onProgress: () => progress++ }); clearInterval(timer);
    assert(s.files === 900 && progress >= 3, "files " + s.files + " progress calls " + progress);
    assert(ticks >= 3, "the event loop never got control during indexing (" + ticks + ")");
    const ac = new AbortController(), p2 = W.Project.create({ name: "c" }); setTimeout(() => ac.abort(), 1);
    let err; try { await p2.indexAsync(files, { budgetMs: 1, signal: ac.signal }); } catch (e) { err = e; }
    assert(err && err.code === "cancelled", "cancellation not honoured");
  });
  check("project: size and count limits are enforced and reported, oversized files skipped", () => {
    const p = mk([F("big.js", "x".repeat(W.Project.LIMITS.fileBytes + 1)), F("ok.js", "export const A = 1")]);
    assert(!p.hasFile("big.js") && p.hasFile("ok.js") && p.ignoredList().some((x) => /larger than/.test(x.reason)));
    const many = []; for (let i = 0; i < W.Project.LIMITS.files + 5; i++) many.push(F("f" + i + ".js", "export const a" + i + "=1"));
    const q2 = mk(many); assert(q2.stats().files === W.Project.LIMITS.files && /stopped at/.test(q2.stats().truncated), JSON.stringify(q2.stats().truncated));
  });
  check("codebrain: Unity review finds real mistakes with lines, including scene values that override code", () => {
    const p = mk(UNITY()); W.CodeBrain.setProject(p);
    const f = W.CodeBrain.unityReview("Assets/Scripts/Enemy.cs"), rules = f.map((x) => x.rule);
    ["lifecycle-case", "find-in-hot-path", "getcomponent-in-hot-path", "no-delta-time", "physics-in-update", "log-in-hot-path", "null-conditional-on-unity-object", "transform-vs-rigidbody", "serialized-overrides-code", "unassigned-reference"].forEach((r) => assert(rules.includes(r), "missing rule " + r + " in " + rules));
    const lc = f.find((x) => x.rule === "lifecycle-case"); assert(lc.line === 7 && /Update/.test(lc.message), JSON.stringify(lc));
    assert(/speed.*2.*0.*Main\.unity/.test(f.find((x) => x.rule === "serialized-overrides-code").message), "override message");
  });
  check("codebrain: 'Why is my Unity enemy not moving?' uses the project, the scene and the notes together", () => {
    W.CodeBrain.setProject(mk(UNITY()));
    const r = W.EDO.handle("Why is my Unity enemy not moving?", { mode: "Programming" });
    assert(r.engine === "code-brain" && /Enemy\.cs:7/.test(r.text) && /Main\.unity/.test(r.text) && /baked|NavMesh/i.test(r.text), r.text.slice(0, 500));
    W.CodeBrain.setProject(null);
    const g = W.EDO.handle("Why is my Unity enemy not moving?", { mode: "Programming" });
    assert(g.engine === "code-brain" && /Load your project/i.test(g.text) && /NavMesh/i.test(g.text), g.text.slice(0, 300));
  });
  check("codebrain: project questions are answered from the index (where defined, what uses, impact, overview)", () => {
    W.CodeBrain.setProject(mk(WEB()));
    const a = W.CodeBrain.answer("where is add defined", {}); assert(/src\/math\.js:1/.test(a.text), a.text);
    const u = W.CodeBrain.answer("what uses add", {}); assert(/src\/index\.js:6/.test(u.text) && /src\/util\/helpers\.js/.test(u.text), u.text);
    const i = W.CodeBrain.answer("what will break if I change src/math.js", {}); assert(/2 direct/.test(i.text) && /Risk/.test(i.text), i.text);
    const o = W.CodeBrain.answer("project overview", {}); assert(/Entry points/.test(o.text) && /lodash/.test(o.text), o.text);
    assert(/could not find/.test(W.CodeBrain.answer("where is nothingAtAll defined", {}).text));
    assert(/Not executed|Nothing was compiled/.test(a.meta), "must state nothing was executed");
  });
  check("codebrain: security, performance and architecture reviews report real findings with lines", () => {
    W.CodeBrain.setProject(mk([F("a.js", "function r(x){ document.body.innerHTML = x; eval(x); const api_key = 'abcdefghijklmnop12345'; }\nfor (let i=0;i<9;i++){ if (list.includes(i)) {} }\nconst c = JSON.parse(JSON.stringify(o));\n"), F("x.js", "import './y'"), F("y.js", "import './x'"), F("q.py", "import os\nos.system('rm ' + p)\nimport pickle\npickle.loads(d)\nq = \"SELECT * FROM t WHERE id=\" + i\n")]));
    const sec = W.CodeBrain.securityReview("a.js").map((f) => f.rule); ["js-xss", "js-eval", "hardcoded-secret"].forEach((r) => assert(sec.includes(r), "missing " + r + " in " + sec));
    const py = W.CodeBrain.securityReview("q.py").map((f) => f.rule); assert(py.includes("py-shell") && py.includes("py-deserialise"), py.join());
    assert(W.CodeBrain.perfReview("a.js").some((f) => f.rule === "js-deepcopy"));
    assert(W.CodeBrain.architectureReview().some((f) => f.rule === "dependency-cycle"));
    assert(/Security review/.test(W.CodeBrain.answer("security review", {}).text));
  });
  check("codebrain: rename across files is word-bounded, leaves strings, refuses collisions and ambiguity, and diffs apply cleanly", () => {
    const p = mk(WEB()); W.CodeBrain.setProject(p);
    const r = W.CodeBrain.renameSymbol("add", "plus");
    assert(r.ok && r.changedFiles.length === 3, JSON.stringify(r.changedFiles));
    const idx = r.patches.find((x) => x.path === "src/index.js").after;
    assert(/plus\(1,2\)/.test(idx) && /\/\/ add\(1\)/.test(idx) && /const s = 'add'/.test(idx) && /import \{ plus \}/.test(idx), idx);
    r.patches.forEach((x) => { const back = W.Patch.apply(x.before, x.diff); assert(back.ok && back.text === x.after, "diff does not reproduce the change for " + x.path); });
    assert(W.CodeBrain.renameSymbol("add", "fmt").ok === false, "collision allowed");
    assert(W.CodeBrain.renameSymbol("add", "1bad").ok === false);
    p.addFiles([F("src/other.js", "export function add(x){ return x }\n")]);
    assert(/several places/.test(W.CodeBrain.renameSymbol("add", "plus").reason), "ambiguity guessed");
  });
  check("codebrain: change loop validates on a copy, refuses harmful edits, commits only on request", () => {
    const p = mk(WEB()); W.CodeBrain.setProject(p);
    const ok = W.CodeBrain.change({ kind: "rename", from: "fmt", to: "format" }, { commit: false });
    assert(ok.ok && !ok.committed && p.read("src/util/helpers.js").includes("function fmt"), "must not apply without commit");
    assert(ok.steps.map((s) => s.name).join() === "understand request,inspect project,generate patch,review dependencies,validate on a copy,apply", ok.steps.map((s) => s.name).join());
    const bad = W.CodeBrain.change({ kind: "edits", edits: [{ path: "src/math.js", find: "export function add(a,b){ return a+b }\n", replace: "" }] }, { commit: true });
    assert(bad.ok === false && bad.committed === false && bad.introduced.some((x) => /add.*removed|still used/.test(x.message)), JSON.stringify(bad.introduced));
    assert(p.read("src/math.js").includes("function add"), "harmful edit was applied");
    const brk = W.CodeBrain.change({ kind: "edits", edits: [{ path: "src/math.js", find: "export const PI2 = 6.28;", replace: "export const PI2 = (6.28;" }] }, { commit: true });
    assert(brk.ok === false && brk.introduced.some((x) => x.check === "static"), "syntax break not caught: " + JSON.stringify(brk.introduced));
    const done = W.CodeBrain.change({ kind: "rename", from: "fmt", to: "format" }, { commit: true });
    assert(done.committed && p.read("src/util/helpers.js").includes("function format") && p.read("src/index.js").includes("u.format('x')") && p.read("src/util/helpers.js").includes("module.exports={format}"), "commit failed or left the export and its caller inconsistent");
    assert(done.notes.some((n) => /member access|object key|same name/i.test(n)), "the rename must warn that same-named members are renamed too");
  });
  check("codebrain: failure paths are explicit (no project, unknown kind, non-unique edit, missing file)", () => {
    W.CodeBrain.setProject(null);
    assert(W.CodeBrain.change({ kind: "rename", from: "a", to: "b" }).ok === false);
    W.CodeBrain.setProject(mk(WEB()));
    assert(/unknown change kind/.test(W.CodeBrain.change({ kind: "magic" }).reason));
    const e = W.CodeBrain.applyEdits([{ path: "src/math.js", find: "a", replace: "b" }, { path: "nope.js", find: "x", replace: "y" }, { path: "src/math.js", find: "zzz", replace: "y" }]);
    assert(e.ok === false && e.errors.length === 3 && /appears \d+ times/.test(e.errors[0].reason) && /not in the project/.test(e.errors[1].reason) && /not found/.test(e.errors[2].reason), JSON.stringify(e.errors));
  });
  check("codebrain: Unity fixes produce real patches (lifecycle case, cached GetComponent) that pass validation", () => {
    const p = mk(UNITY()); W.CodeBrain.setProject(p);
    const lc = W.CodeBrain.change({ kind: "lifecycle", path: "Assets/Scripts/Enemy.cs" }, { commit: true });
    assert(lc.ok && lc.committed && /void Update\(\)[\s\S]*void Update\(\)/.test(p.read("Assets/Scripts/Enemy.cs")), "lifecycle not fixed");
    const g = W.CodeBrain.change({ kind: "cache-getcomponent", path: "Assets/Scripts/Enemy.cs" }, { commit: false });
    assert(g.ok, JSON.stringify(g.steps));
    const after = g.patches[0].after;
    assert(/private Rigidbody _rigidbodyCached;/.test(after) && /_rigidbodyCached = GetComponent<Rigidbody>\(\);/.test(after), after.slice(0, 600));
    const upd = after.slice(after.indexOf("void Update()")); assert(!/GetComponent<Rigidbody>\(\)\.AddForce/.test(upd) && /_rigidbodyCached\.AddForce/.test(upd), "Update still calls GetComponent");
  });
  check("codebrain: Unity script link validation catches Missing (Script) causes", () => {
    const p = mk([F("Assets/Scripts/Boss.cs", "public class Foo : MonoBehaviour { }"), F("Assets/Scenes/S.unity", "--- !u!114 &1\nMonoBehaviour:\n  m_Script: {fileID: 1, guid: bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb, type: 3}\n"), F("Assets/Scripts/Gone.cs.meta", "guid: bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\n"), F("ProjectSettings/ProjectVersion.txt", "m_EditorVersion: 2022.3.1f1")]);
    const v = W.Validation.validate(p, [], {}).findings.filter((f) => f.check === "unity-links");
    assert(v.some((x) => /Gone\.cs/.test(x.message)) && v.some((x) => /does not match its file name/.test(x.message)), JSON.stringify(v));
  });
  check("codebrain: tests are generated per language, honestly labelled, and refuse where impossible", () => {
    W.CodeBrain.setProject(mk([F("Assets/Logic/Calc.cs", "public class Calc { public int Add(int a, int b){ return a+b; } }"), F("Assets/Scripts/Mover.cs", "public class Mover : MonoBehaviour { public void Go(){} }"), F("lib.js", "function add(a,b){ return a+b }\nmodule.exports={add};")]));
    const c = W.CodeBrain.genTests("Assets/Logic/Calc.cs"); assert(c.ok && /\[Test\]/.test(c.text) && /Add_Works/.test(c.text) && /skeleton/i.test(c.note) && /Not executed/.test(c.note), JSON.stringify(c));
    const m = W.CodeBrain.genTests("Assets/Scripts/Mover.cs"); assert(m.ok === false && /MonoBehaviour/.test(m.reason), JSON.stringify(m));
    const j = W.CodeBrain.genTests("lib.js"); assert(j.ok && /add/.test(j.text) && /Not executed/i.test(j.note));
  });
  check("codebrain: live context and crash triage tie a pasted stack trace to project files", () => {
    const p = mk(UNITY()); W.CodeBrain.setProject(p);
    const trace = "NullReferenceException: Object reference not set\nEnemy.Update () (at Assets/Scripts/Enemy.cs:11)";
    assert(W.Project.parseErrorLocations(trace)[0].line === 11, JSON.stringify(W.Project.parseErrorLocations(trace)));
    p.recordError(trace); p.setActive("Assets/Scripts/Enemy.cs", { text: "x", startLine: 3, endLine: 4 }); p.setTask("fix enemy crash");
    const live = p.live(); assert(live.activeFile === "Assets/Scripts/Enemy.cs" && live.task === "fix enemy crash" && live.recentErrors.length === 1);
    const r = W.EDO.handle("I'm frustrated because this project keeps crashing", { mode: "Programming" });
    assert(r.act === "frustrated_code" && /frustrat|get it|sounds/i.test(r.text) && /Enemy\.cs:11/.test(r.text), r.text.slice(0, 400));
    W.CodeBrain.setProject(null);
    const n = W.EDO.handle("I'm frustrated because this project keeps crashing", { mode: "Programming" });
    assert(/stack trace|error message/i.test(n.text), n.text);
  });
  check("codebrain: existing Programming behaviour is untouched when no project is loaded", () => {
    W.CodeBrain.setProject(null);
    const r = W.EDO.handle("write a python factorial function", { mode: "Programming" });
    assert(/def factorial/.test(r.text) && /not executed/i.test(r.text + r.meta), r.text.slice(0, 100));
  });

  /* ---------- validation + runner contract ---------- */
  const okReport = (cmd) => ({ exitCode: 0, stdout: "Build succeeded", stderr: "", command: cmd, environment: "docker:dotnet-8", durationMs: 1234, tests: { passed: 12, failed: 0, skipped: 1, failures: [] } });
  const fakeFetch = (handler) => async (url, init) => { const body = JSON.parse(init.body); const out = await handler(body, init, url); return { ok: out.status ? out.status < 400 : true, status: out.status || 200, json: async () => out.json }; };
  seq("validation: with no runner, nothing is claimed as executed", async () => {
    W.Validation.configureRunner(null);
    const r = await W.Validation.execute({ command: "dotnet test", confirmed: true, files: [] });
    assert(r.executed === false && r.note === "Not executed here." && /no isolated execution environment/.test(r.reason), JSON.stringify(r));
    const v = W.Validation.validate(mk(WEB()), ["src/math.js"], {}); assert(v.executed === false && v.note === "Not executed here.");
    assert(W.Validation.runner().configured === false);
  });
  seq("validation: a configured runner reports exactly what it returned, only after confirmation", async () => {
    const seen = []; W.Validation.configureRunner({ endpoint: "https://runner.example/run", environment: "docker:dotnet-8", fetch: fakeFetch((b, init) => { seen.push({ b, init }); return { json: okReport(b.command) }; }), token: "tok" });
    const un = await W.Validation.execute({ command: "dotnet test", files: [{ path: "a.cs", content: "x" }] });
    assert(un.executed === false && /explicit confirmation/.test(un.reason) && seen.length === 0, "ran without confirmation");
    const r = await W.Validation.execute({ command: "dotnet test", confirmed: true, files: [{ path: "a.cs", content: "x" }] });
    assert(r.executed === true && r.exitCode === 0 && r.command === "dotnet test" && r.commandMatchesRequest && r.environment === "docker:dotnet-8" && r.stdout === "Build succeeded" && r.tests.passed === 12 && r.tests.failed === 0 && r.ok === true, JSON.stringify(r));
    assert(seen[0].init.headers.Authorization === "Bearer tok" && seen[0].b.files[0].path === "a.cs" && seen[0].init.redirect === "error");
  });
  seq("validation: failing tests and non-zero exit are reported as failures, with stderr kept", async () => {
    W.Validation.configureRunner({ endpoint: "http://localhost:9000/run", environment: "podman", fetch: fakeFetch((b) => ({ json: { exitCode: 1, stdout: "", stderr: "CS1002: ; expected", command: b.command, environment: "podman", tests: { passed: 3, failed: 2, failures: ["A.Works", "B.Works"] } } })) });
    const r = await W.Validation.execute({ command: "dotnet test", confirmed: true, files: [] });
    assert(r.executed && r.ok === false && r.exitCode === 1 && /CS1002/.test(r.stderr) && r.tests.failed === 2 && r.tests.failures.length === 2, JSON.stringify(r));
  });
  seq("validation: malformed or dishonest runner output is rejected, never repaired or invented", async () => {
    const cases = [{ exitCode: "0", stdout: "", stderr: "", command: "c", environment: "e" }, { exitCode: 0, stdout: "x", stderr: "", environment: "e" }, { exitCode: 0, stdout: "x", stderr: "", command: "c" }, { exitCode: 0, stdout: 5, stderr: "", command: "c", environment: "e" }, { exitCode: 0, stdout: "", stderr: "", command: "c", environment: "e", tests: { passed: -1, failed: 0 } }, null];
    for (const j of cases) {
      W.Validation.configureRunner({ endpoint: "https://r.example/x", fetch: fakeFetch(() => ({ json: j })) });
      const r = await W.Validation.execute({ command: "c", confirmed: true, files: [] });
      assert(r.executed === false && /invalid report/.test(r.error) && r.note === "Not executed here.", JSON.stringify(j) + " → " + JSON.stringify(r));
    }
  });
  seq("validation: timeouts, HTTP errors, allow-lists, size limits and untrusted endpoints are handled", async () => {
    W.Validation.configureRunner({ endpoint: "https://r.example/x", timeoutMs: 1000, fetch: () => new Promise(() => {}) });
    const t = await W.Validation.execute({ command: "c", confirmed: true, files: [] }); assert(t.executed === false && t.code === "timeout", JSON.stringify(t));
    W.Validation.configureRunner({ endpoint: "https://r.example/x", fetch: fakeFetch(() => ({ status: 500, json: {} })) });
    assert((await W.Validation.execute({ command: "c", confirmed: true, files: [] })).code === "http");
    W.Validation.configureRunner({ endpoint: "https://r.example/x", commands: ["dotnet test"], fetch: fakeFetch(() => ({ json: okReport("x") })) });
    assert(/allow-list/.test((await W.Validation.execute({ command: "rm -rf /", confirmed: true, files: [] })).reason));
    W.Validation.configureRunner({ endpoint: "https://r.example/x", maxBytes: 10, fetch: fakeFetch(() => ({ json: okReport("c") })) });
    assert(/limit/.test((await W.Validation.execute({ command: "c", confirmed: true, files: [{ path: "a", content: "x".repeat(50) }] })).reason));
    let threw = false; try { W.Validation.configureRunner({ endpoint: "http://192.168.1.5/run" }); } catch (e) { threw = true; } assert(threw, "plain http to a public or LAN host must be refused");
    W.Validation.configureRunner(null);
  });
  check("validation: plug-in registry accepts new validators, isolates their failures, and orders results", () => {
    W.Validation.register("custom-rule", { label: "Custom", level: "project", appliesTo: () => true, run: () => ({ findings: [{ severity: "warning", path: "x", message: "custom finding" }] }) });
    W.Validation.register("boom", { label: "Broken plug-in", appliesTo: () => true, run: () => { throw new Error("plug-in crashed"); } });
    const v = W.Validation.validate(mk(WEB()), ["src/math.js"], {});
    assert(v.findings.some((f) => f.check === "custom-rule") && v.results.find((r) => r.id === "boom").error === "plug-in crashed" && v.ok === false, "a crashing validator must not look like success");
    assert(W.Validation.list().length >= 5);
  });
};
