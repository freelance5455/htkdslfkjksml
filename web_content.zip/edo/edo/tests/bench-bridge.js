/* JavaScript-only timings for the bridge layer, run in Node against a simulated host. NOT device measurements: nothing here says anything about
   Android latency, memory or battery. Run: node tests/bench-bridge.js */
const fs = require("fs"), vm = require("vm"), path = require("path"), os = require("os");
const root = path.join(__dirname, "..");
function make(withNative) {
const sb = { console, setTimeout, clearTimeout, JSON, Math, Date, Promise, Error, Object, Array, String, Number, RegExp, Set, Map, Symbol, Uint8Array, TextDecoder, TextEncoder, URL, AbortController, atob, btoa, Blob, File, crypto: require("crypto").webcrypto, performance };
sb.window = sb; sb.globalThis = sb; const ctx = vm.createContext(sb);
const el = () => ({ l: {}, style: {}, attrs: {}, addEventListener(t, f) { (this.l[t] = this.l[t] || []).push(f); }, setAttribute() {}, remove() {}, click() { setTimeout(() => { this.files = sb.__files; (this.l.change || []).forEach((f) => f()); }, 0); } });
sb.document = { body: { appendChild() {} }, createElement: el }; sb.navigator = {};
if (withNative) sb.EDOAndroid = { invoke(id, m, a) { setTimeout(() => sb.__edoBridgeResult(id, true, m === "capabilities" ? JSON.stringify({ methods: ["readFile", "pickFile"], version: 3, session: 1 }) : JSON.stringify({ text: "x", name: "n", size: 1, eof: true, nextOffset: 1, bytesRead: 1 })), 0); } };
["bridge/android-client.js", "bridge/edo-android-bridge.js"].forEach((f) => vm.runInContext(fs.readFileSync(path.join(root, f), "utf8"), ctx));
return sb;
}
const sbN = make(true), sb = make(false), A = sbN.EDO.AndroidBridge, AB = sb.EDO.AndroidBridge;
(async () => {
  let t = performance.now(); const N = 100000; let bad = 0;
  for (let i = 0; i < N; i++) { try { await A.pickFile({ bogus: i }); } catch (e) { bad++; } }
  const validate = (performance.now() - t) / N;
  t = performance.now(); const M = 2000; for (let i = 0; i < M; i++) await A.readFile({ ref: "ref_aaaaaaaaaaaa" });
  const roundTrip = (performance.now() - t) / M;
  const unit = "a😀é世b\n"; const content = unit.repeat(Math.ceil(5 * 1024 * 1024 / new TextEncoder().encode(unit).length)); const file = new File([content], "big.txt", { type: "text/plain" });
  sb.__files = [file]; const p = await AB.pickFile(); let off = 0, chars = 0, chunks = 0, eof = false; t = performance.now();
  while (!eof) { const r = await AB.readFile({ ref: p.files[0].ref, offset: off, length: 65536 }); off = r.nextOffset; chars += r.text.length; eof = r.eof; chunks++; }
  const read = performance.now() - t;
  const cpu = (os.cpus()[0] || {}).model || "unknown";
  console.log(JSON.stringify({ env: { node: process.version, cpu, cores: os.cpus().length, note: "simulated host in Node; not an Android device" },
    rejectInvalidOption_ms_per_call: +validate.toFixed(4), simulatedNativeRoundTrip_ms_per_call: +roundTrip.toFixed(3), browserFallbackRead: { bytes: file.size, chunks, ms: +read.toFixed(1), MBperSec: +(file.size / 1048576 / (read / 1000)).toFixed(1), chars } }, null, 1));
})();
