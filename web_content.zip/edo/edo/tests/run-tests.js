/* Node checks for the merged EDO engines. No browser required. */
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const root = path.join(__dirname, "..");
const window = { console, setTimeout, clearTimeout, AbortController, Math, Date, JSON, Object, Array, String, Number, Error, Promise, RegExp, URL };
window.window = window;
window.globalThis = window;
const context = vm.createContext(window);

function load(rel) {
  const code = fs.readFileSync(path.join(root, rel), "utf8");
  vm.runInContext(code, context, { filename: rel });
}

[
  "knowledge/formulas.js",
  "knowledge/schema.js",
  "knowledge/programming.js",
  "knowledge/mathematics.js",
  "knowledge/physics.js",
  "knowledge/chemistry.js",
  "knowledge/jee-math.js",
  "knowledge/jee-physics.js",
  "knowledge/jee-chem.js",
  "knowledge/code-templates.js",
  "knowledge/general.js",
  "knowledge/unity.js",
  "knowledge/index.js",
  "knowledge/retrieval.js",
  "core/calc.js",
  "core/units.js",
  "core/normalize.js",
  "core/companion.js",
  "tools/device.js",
  "core/intent.js",
  "core/verify.js",
  "core/reasoning.js",
  "core/solver.js",
  "core/entities.js",
  "core/derive.js",
  "core/pipeline.js",
  "core/mpc-layer.js",
  "core/patch.js",
  "core/project.js",
  "core/validation.js",
  "core/programming.js",
  "memory/memory.js",
  "core/semantic.js",
  "memory/layers.js",
  "core/planner.js",
  "core/friend.js",
  "core/proactive.js",
  "core/brain.js",
  "tools/code-analyzer.js",
  "core/codebrain.js",
  "tools/file-analyzer.js",
  "tools/location.js",
  "tools/web-search.js",
  "bridge/android-client.js",
  "bridge/edo-android-bridge.js",
  "voice/voice.js",
  "voice/voice-engine.js",
  "core/orchestrator.js",
  "core/config.js",
  "core/tools.js",
  "core/safety.js",
  "core/providers.js",
  "core/router.js",
  "core/vision.js",
  "tools/device-tools.js",
  "core/agent.js",
  "ui/render.js",
  "ui/dragon-intro.js",
].forEach(load);

const results = [];
function check(name, fn) {
  try {
    const detail = fn();
    results.push({ name, ok: true, detail: detail || "ok" });
  } catch (e) {
    results.push({ name, ok: false, detail: e.message });
  }
}
function assert(cond, msg) {
  if (!cond) throw Error(msg || "assertion failed");
}

check("basic conversation", () => {
  const r = window.EDO.handle("hello", { mode: "Assistant" });
  assert(r.kind === "chat" && /hey|hi|hello/i.test(r.text), r.text);
  assert(r.meta && /on-device/i.test(r.meta), r.meta);
  return r.kind;
});

check("unmatched question stays honest", () => {
  const r = window.EDO.handle("explain the causes of the french revolution in detail", { mode: "Assistant" });
  assert(/local mode/i.test(r.text) && /no model/i.test(r.meta), r.text);
  assert(/not guessed|have not guessed/i.test(r.text), "must say it did not guess");
  return r.kind;
});

check("programming question", () => {
  const r = window.EDO.handle("explain javascript html pitfalls", { mode: "Programming" });
  assert(/HTML|unsanitized|Pitfall/i.test(r.text), r.text.slice(0, 180));
  return r.kind;
});

check("code generation", () => {
  const r = window.EDO.handle("write a python factorial function", { mode: "Programming" });
  assert(/def factorial/.test(r.text), "missing python function");
  assert(/not executed/i.test(r.text + r.meta), "missing not-executed note");
  return "factorial template";
});

check("code analysis", () => {
  const r = window.EDO.handle("analyze this code\n```js\nfunction f(x){ return x; }\n```", { mode: "Programming" });
  assert(/parses OK/.test(r.text), r.text);
  assert(/not executed|did not run/i.test(r.text + r.meta), "missing not-executed note");
  return "syntax ok";
});

check("code analysis mismatch", () => {
  const bad = window.CodeAnalyzer.check("function f( { return 1; }");
  assert(/syntax error|Mismatched|Unclosed/i.test(bad), bad);
  return "flagged";
});

check("mathematics formula", () => {
  const r = window.EDO.handle("a=1 b=-3 c=2 find x", { mode: "JEE" });
  assert(/x = /.test(r.text), r.text);
  return r.text.split("\n")[0];
});

check("physics formula", () => {
  const r = window.EDO.handle("u=0 a=2 t=5 find v", { mode: "JEE" });
  assert(/v = 10/.test(r.text), r.text);
  assert(/residual|Check/.test(r.text), "missing substitution check");
  return r.text.split("\n")[0];
});

check("physics sentence solver", () => {
  const r = window.EDO.handle("A car moving at 36 km/h accelerates at 2 m/s² for 5 s. Find the distance.", { mode: "JEE" });
  assert(r.kind === "reason", r.kind);
  assert(/distance|s =|50/.test(r.text), r.text.slice(0, 240));
  assert(/Check/.test(r.text), "solver verification missing");
  return r.text.split("\n")[0];
});

check("chemistry pH", () => {
  const r = window.EDO.handle("Find the pH of 0.1 M acetic acid. Ka = 1.8 × 10^-5", { mode: "JEE" });
  assert(/pH/.test(r.text), r.text.slice(0, 200));
  return r.text.split("\n")[0];
});

check("jee chapter retrieval", () => {
  const r = window.EDO.handle("explain kinematics equations", { mode: "Study" });
  assert(/Kinematics|ut/.test(r.text), r.text.slice(0, 180));
  return "notes";
});

check("formula listing", () => {
  const r = window.EDO.handle("formula optics", { mode: "JEE" });
  assert(/optics|lens|mirror|No formula/i.test(r.text), r.text.slice(0, 180));
  return "listed";
});

check("multi-step reasoning", () => {
  const r = window.EDO.handle("A car moving at 36 km/h accelerates at 2 m/s² for 5 s. Find the distance.", { mode: "Reasoning" });
  assert(/Working:/.test(r.text) || /1\./.test(r.text), "steps missing");
  return "steps present";
});

check("verification invented source", () => {
  const a = window.Verify.audit("According to a source, the value is 3.");
  assert(!a.ok && /unverif/i.test(a.suffix), a.suffix);
  return "flagged";
});

check("calculator", () => {
  const r = window.EDO.handle("2+3*sqrt(16)", { mode: "Assistant" });
  assert(/=\s*14\b/.test(r.text), r.text);
  assert(/twice/i.test(r.meta), r.meta);
  return r.text;
});

check("memory", () => {
  const a = window.EDO.handle("remember: revise kinematics on Friday", { mode: "Assistant" });
  assert(/Saved locally/.test(a.text), a.text);
  const b = window.EDO.handle("what do you remember", { mode: "Assistant" });
  assert(/kinematics/.test(b.text), b.text);
  window.Memory.forget("kinematics");
  return "saved and listed";
});

check("location mock", async () => {
  const pos = await window.Location.request({
    getCurrentPosition(ok) {
      ok({ coords: { latitude: 17.385, longitude: 78.4867, accuracy: 20 } });
    },
  });
  const rep = window.Location.report(pos, true);
  assert(/17\.38500/.test(rep.text), rep.text);
  assert(/not fetched/i.test(rep.text), "weather must not be invented");
  return window.Location.format(pos);
});

check("web search", () => {
  const r = window.EDO.handle("search kinematics notes", { mode: "Search" });
  assert(r.configured === false, "search must stay unconfigured");
  assert(/not configured/i.test(r.text), r.text);
  assert(/\[\[G:/.test(r.text), "missing search link");
  return r.query;
});

check("android bridge contract", () => {
  const kt = fs.readFileSync(path.join(root, "android/app/src/main/java/com/edo/app/EdoBridge.kt"), "utf8");
  window.Bridge.methods.forEach((m) => {
    if (!kt.includes('"' + m + '"')) throw Error("Kotlin missing method " + m);
  });
  assert(typeof window.__edoBridgeResult === "function", "result hook missing");
  assert(window.Bridge.available() === false, "bridge should be absent in node");
  return window.Bridge.methods.join(",");
});

check("programming prime template", () => {
  const r = window.EDO.handle("write a python function to calculate prime numbers up to n", { mode: "Programming" });
  assert(/def primes_up_to/.test(r.text), "missing python primes function");
  const js = window.EDO.handle("write a javascript function for primes up to n", { mode: "Programming" });
  assert(/function primesUpTo/.test(js.text), "missing js primes function");
  return "primes template";
});

check("launch media present", () => {
  const html = fs.readFileSync(path.join(root, "index.html"), "utf8");
  ["media/edo-intro.mp4", "media/edo-intro-poster.jpg", "media/edo-hero.webp"].forEach((f) => {
    if (!html.includes(f)) throw Error("index does not reference " + f);
    if (!fs.existsSync(path.join(root, f))) throw Error("missing file " + f);
  });
  assert(fs.statSync(path.join(root, "media/edo-intro.mp4")).size < 3 * 1024 * 1024, "intro video over 3 MB");
  return "video, poster, hero wired";
});

function ev(expr) { return window.Calc.run(window.Normalize.math(expr).expr); }
check("natural maths input", () => {
  const cases = [
    ["100×100", 10000], ["100x100", 10000], ["100 x 100", 10000], ["100 X 100", 10000], ["12 × 12", 144], ["81 ÷ 9", 9],
    ["100 times 100", 10000], ["100 multiplied by 4", 400], ["100 divided by 4", 25], ["10 plus 5", 15], ["10 minus 4", 6],
    ["what is 15% of 200", 30], ["15 percent of 200", 30], ["25 squared", 625], ["5 cubed", 125], ["square root of 144", 12],
    ["sqrt of 81", 9], ["√49", 7], ["2 to the power of 10", 1024], ["2^10", 1024], ["1,000 + 2,500", 3500], ["12,34,567 - 1", 1234566],
    ["₹500 x 3", 1500], ["what's 7 × 8?", 56], ["calculate 2+3*sqrt(16)", 14], ["10²", 100], ["cube root of 27", 3], ["(2+3)x4", 20], ["50% of 80 + 10", 50],
  ];
  cases.forEach(([q, want]) => {
    const n = window.Normalize.math(q);
    assert(n, "not understood: " + q);
    const got = window.Calc.run(n.expr);
    assert(Math.abs(got - want) < 1e-9, q + " -> " + n.expr + " = " + got + ", wanted " + want);
  });
  return cases.length + " phrasings";
});

check("maths input not over-matched", () => {
  ["42", "hello", "98765-43210", "2024-10-03", "+91 98765 43210", "call mom", "i have 3 apples", "x", "2x+3=7", "open whatsapp", "-5", "write a python function", "the 3 best ways to study"].forEach((q) => {
    assert(window.Normalize.math(q) === null, "wrongly treated as maths: " + q);
  });
  return "ok";
});

check("100×100 solves in every mode", () => {
  ["Assistant", "JEE", "Study", "Programming", "Friend", "Reasoning"].forEach((m) => {
    const r = window.EDO.handle("100×100", { mode: m });
    assert(r.kind === "calculation" && /10000/.test(r.text), m + ": " + r.text);
  });
  const g = window.EDO.handle("what is 250000 times 4", { mode: "Assistant" });
  assert(/1000000 \(10,00,000\)/.test(g.text), g.text);
  const z = window.EDO.handle("5 / 0", { mode: "Assistant" });
  assert(/no finite answer/.test(z.text), z.text);
  const f = window.EDO.handle("0.1 + 0.2", { mode: "Assistant" });
  assert(/= 0\.3\*\*/.test(f.text), f.text);
  return "ok";
});

check("companion: chat, moods, safety", () => {
  const g = window.EDO.handle("hi", { mode: "Assistant" });
  assert(g.kind === "chat", "greeting kind " + g.kind);
  const s = window.EDO.handle("I'm so stressed about my JEE exam", { mode: "JEE" });
  assert(s.kind === "chat" && /lot|smaller|weigh/i.test(s.text), "stress reply: " + s.text);
  const tired = window.EDO.handle("I feel really tired today", { mode: "Assistant" });
  assert(tired.kind === "chat", "tired " + tired.kind);
  const c = window.EDO.handle("i want to die", { mode: "Assistant" });
  assert(c.crisis === true && /14416/.test(c.text) && /someone/i.test(c.text), "crisis reply");
  const c2 = window.EDO.handle("2+2", { mode: "Assistant" });
  assert(c2.kind === "calculation", "maths must still win");
  const w = window.EDO.handle("who are you", { mode: "Assistant" });
  assert(/not a human/i.test(w.text) && /not a language model|rather than a big language model/i.test(w.text), "must be honest about being simple");
  return "ok";
});

check("companion: no false triggers on technical text", () => {
  ["what's up with this error in my code", "write a motivation letter in python", "the top of the stack is empty", "explain how a joke class works in java", "low level programming in C"].forEach((q) => {
    const k = window.Intent.detect(q, "Assistant").kind;
    assert(k !== "chat" && k !== "crisis", q + " -> " + k);
  });
  return "ok";
});

check("companion: name memory", () => {
  const r = window.EDO.handle("my name is Uchiha", { mode: "Assistant" });
  assert(/Uchiha/.test(r.text), r.text);
  const h = window.EDO.handle("hello", { mode: "Assistant" });
  assert(/Uchiha/.test(h.text), "greeting should use the name: " + h.text);
  window.Memory.forget("name");
  return "ok";
});

check("decision helper: full flow and maths", () => {
  const H = (t) => window.EDO.handle(t, { mode: "Assistant" });
  let r = H("help me decide");
  assert(r.kind === "decision" && /options/i.test(r.text), "asks for options");
  r = H("Delhi or Bangalore");
  assert(/Delhi.*vs.*Bangalore/s.test(r.text), "criteria prompt");
  r = H("cost 8, weather 2");
  assert(/Delhi/.test(r.text), "asks for first option scores");
  r = H("9 3");
  assert(/Bangalore/.test(r.text), "asks for second option scores");
  r = H("5 8");
  // Delhi = (9*8+3*2)/10 = 7.8 ; Bangalore = (5*8+8*2)/10 = 5.6
  assert(/\*\*Delhi\*\*: 7\.8/.test(r.text) && /\*\*Bangalore\*\*: 5\.6/.test(r.text), r.text);
  assert(/clearly ahead/.test(r.text) && /cost/.test(r.text), "verdict names the driver");
  assert(!window.Companion.active(), "flow should end");
  return "7.8 vs 5.6";
});

check("decision helper: tie, bad input, cancel, yes/no", () => {
  const H = (t) => window.EDO.handle(t, { mode: "Assistant" });
  let r = H("should I learn Rust or Go?");
  assert(/Rust.*vs.*Go/s.test(r.text), "options parsed from a question");
  r = H("speed 5");
  assert(/at least two/i.test(r.text), "needs 2 criteria");
  r = H("speed 5, jobs 5");
  r = H("7 7");
  r = H("7 7");
  assert(/practically a tie/.test(r.text), "tie detected: " + r.text);
  r = H("should I quit my job or not");
  assert(/Yes: quit my job/.test(r.text), "yes/no form: " + r.text);
  r = H("cost 3, time 3");
  r = H("11 4");
  assert(/exactly 2 numbers/.test(r.text), "out-of-range score rejected");
  r = H("cancel");
  assert(/dropped/i.test(r.text) && !window.Companion.active(), "cancel works");
  return "ok";
});

check("decision flow does not swallow safety", () => {
  window.EDO.handle("help me decide", { mode: "Assistant" });
  const r = window.EDO.handle("i want to kill myself", { mode: "Assistant" });
  assert(r.crisis === true, "crisis message must interrupt a flow");
  window.Companion.reset();
  return "ok";
});

check("device command parsing", () => {
  const D = window.Device;
  const eq = (q, want) => { const g = D.parse(q); assert(JSON.stringify(g) === JSON.stringify(want), q + " -> " + JSON.stringify(g)); };
  eq("call 9876543210", { type: "call", number: "9876543210", label: "9876543210", emergency: false });
  eq("Call +91 98765 43210", { type: "call", number: "+919876543210", label: "+919876543210", emergency: false });
  eq("please dial 112", { type: "call", number: "112", label: "112", emergency: true });
  eq("call mom", { type: "call", name: "mom" });
  eq("Call my brother now", { type: "call", name: "brother" });
  eq("can you phone Rahul Sharma please", { type: "call", name: "Rahul Sharma" });
  eq("open WhatsApp", { type: "open", name: "WhatsApp" });
  eq("launch the youtube app", { type: "open", name: "youtube" });
  eq("open my camera", { type: "open", name: "camera" });
  eq("enable calling permission", { type: "enable" });
  eq("allow contacts access", { type: "enable" });
  ["call a function in python", "call it a day", "call 5*7", "open source licenses explained", "open the door", "open a file", "open ended questions are hard", "start learning python", "how do I call an API", "what does open mean", "I called him yesterday", "run the tests", "go to sleep"].forEach((q) => {
    assert(D.parse(q) === null, "wrongly a device command: " + q);
  });
  return "ok";
});

check("device routing and app table", () => {
  const r = window.EDO.handle("open whatsapp", { mode: "Assistant" });
  assert(r.kind === "device" && r.device.type === "open", JSON.stringify(r));
  assert(window.EDO.handle("call 9876543210", { mode: "JEE" }).kind === "device", "call in JEE mode");
  assert(window.EDO.handle("98765 x 43210", { mode: "Assistant" }).kind === "calculation", "number x number is maths");
  assert(window.Device.appFor("insta")[4] === "Instagram" && window.Device.appFor("google pay")[4] === "Google Pay", "aliases");
  const kt = fs.readFileSync(path.join(root, "android/app/src/main/java/com/edo/app/EdoBridge.kt"), "utf8");
  assert(/CALL_PHONE/.test(kt) && /ACTION_CALL/.test(kt) && /ACTION_DIAL/.test(kt), "Kotlin call support");
  assert(/EMERGENCY|emergency/.test(kt), "Kotlin must route emergency numbers to the dialer");
  assert(/requestPermissions/.test(kt) && /permissionStatus/.test(kt), "Kotlin permission methods");
  return "ok";
});

check("knowledge search ignores filler words", () => {
  assert(window.EDOKnowledge.search("the and of explain in detail").length === 0, "stopwords alone must not match");
  assert(window.EDOKnowledge.search("kinematics").length > 0, "real topic still matches");
  return "ok";
});

check("ui startup files", () => {
  const html = fs.readFileSync(path.join(root, "index.html"), "utf8");
  ["core/orchestrator.js", "ui/dragon-intro.js", "core/solver.js", "knowledge/formulas.js"].forEach((s) => {
    if (!html.includes(s)) throw Error("index missing " + s);
  });
  assert(html.includes("DragonIntro.start"), "dragon not started");
  assert(/max-width:640px/.test(html), "mobile layout rule missing");
  assert(html.includes('viewport'), "viewport missing");
  return "html wired";
});

check("dragon intro skip", () => {
  let called = 0;
  window.DragonIntro.start({ reduced: true, onDone() { called++; } });
  assert(called === 1, "onDone not called");
  return "reduced-motion skip";
});

require("./extended")({ check, assert, window, root, load, fs, path, vm, context });
require("./modes")({ check, assert, window, root, load, fs, path, vm, context });
require("./brain")({ check, assert, window, root, load, fs, path, vm, context });
require("./project")({ check, assert, window, root, load, fs, path, vm, context });
require("./voice")({ check, assert, window, root, load, fs, path, vm, context });
require("./bridge2")({ check, assert, window, root, load, fs, path, vm, context });
require("./agent")({ check, assert, window, root, load, fs, path, vm, context });
require("./androidbridge")({ check, assert, fs, path, root, vm });
require("./security")({ check, assert, window, root, load, fs, path, vm, context });

Promise.resolve()
  .then(() => Promise.all(results.map((r) => r)))
  .then(async () => {
    // location check is async and already stored as promise detail if we didn't await
  });

(async () => {
  for (const r of results) {
    if (r.detail && typeof r.detail.then === "function") {
      try {
        r.detail = await r.detail;
      } catch (e) {
        r.ok = false;
        r.detail = e.message;
      }
    }
  }
  const failed = results.filter((r) => !r.ok);
  results.forEach((r) => console.log((r.ok ? "PASS" : "FAIL") + "  " + r.name + " — " + r.detail));
  console.log(results.length - failed.length + "/" + results.length + " passed");
  if (failed.length) process.exit(1);
})();
