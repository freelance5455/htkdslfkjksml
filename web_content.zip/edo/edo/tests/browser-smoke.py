"""Browser smoke test (Chromium via Playwright). Run: python3 tests/browser-smoke.py
Drives the real page: boot, CSP, conversation, memory panel, XSS, project loading, worker responsiveness, voice session with a
fake microphone, back button, and loading from file://. H.264 video cannot be decoded by this Chromium build, so mode clips use the ring fallback here."""
import http.server, socketserver, threading, functools, os, sys, json, time
from playwright.sync_api import sync_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
fails, passes = [], []
def ok(name, cond, extra=""):
    (passes if cond else fails).append(name); print(("PASS  " if cond else "FAIL  ") + name + ("" if cond else "  :: " + str(extra)[:400]))

class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
socketserver.TCPServer.allow_reuse_address = True
srv = socketserver.ThreadingTCPServer(("127.0.0.1", 8771), functools.partial(Q, directory=ROOT)); threading.Thread(target=srv.serve_forever, daemon=True).start()

FAKES = """
window.__recs = [];
class FakeRec { constructor(){ window.__recs.push(this); this.started=false; }
  start(){ this.started=true; setTimeout(()=>this.onstart&&this.onstart(),0); } stop(){ this.started=false; } abort(){ this.started=false; }
  say(t,final){ const r=[{transcript:t,confidence:.9}]; r.isFinal=!!final; this.onresult({resultIndex:0,results:[r]}); } }
window.SpeechRecognition = FakeRec; window.webkitSpeechRecognition = FakeRec;
const fakeSynth = { speaking:false, pending:false, getVoices(){ return []; },
  speak(u){ fakeSynth.speaking=true; window.__spoken=(window.__spoken||[]); window.__spoken.push(u.text); setTimeout(()=>{ u.onstart&&u.onstart(); setTimeout(()=>{ fakeSynth.speaking=false; u.onend&&u.onend(); },120); },20); },
  cancel(){ fakeSynth.speaking=false; } };
Object.defineProperty(window,'speechSynthesis',{value:fakeSynth,configurable:true});
"""

def boot(p, url, errors):
    b = p.chromium.launch(args=["--autoplay-policy=no-user-gesture-required"])
    ctx = b.new_context(viewport={"width": 390, "height": 844}, permissions=["microphone"])
    ctx.add_init_script(FAKES)
    pg = ctx.new_page()
    pg.on("pageerror", lambda e: errors.append("pageerror: " + str(e)))
    pg.on("console", lambda m: errors.append("console." + m.type + ": " + m.text) if m.type == "error" or "Content Security Policy" in m.text else None)
    pg.goto(url); pg.wait_for_timeout(700)
    pg.click("#skip"); pg.wait_for_timeout(1400)
    return b, pg

def last_reply(pg):
    return pg.evaluate("(()=>{const m=[...document.querySelectorAll('#chat .m.a')];return m.length?m[m.length-1].innerText:''})()")
def ask(pg, text, wait=700):
    pg.fill("#in", text); pg.keyboard.press("Enter"); pg.wait_for_timeout(wait); return last_reply(pg)

with sync_playwright() as p:
    errors = []
    b, pg = boot(p, "http://127.0.0.1:8771/index.html", errors)
    ok("boot: page loads over http with no script errors and no CSP violations", not errors, errors)
    ok("boot: all new modules are present", pg.evaluate("['Brain','MemoryLayers','Friend','Planner','Project','CodeBrain','Validation','VoiceEngine','Proactive','Retrieval','MPC','Semantic','ProjectClient','EDOX'].every(k=>!!window[k])"))
    pg.evaluate("applyMode('Assistant', true)")

    # --- conversation ---
    r = ask(pg, "I got 90 marks today and my exam is next Friday")
    ok("chat: a personal update is answered as conversation, mentions the score and the exam", "90" in r and "xam" in r and "search" not in r.lower(), r)
    ok("chat: indicators show the companion engine and a saved event", pg.inner_text("#toolchip").strip() == "Companion" and "xam" in json.dumps(pg.evaluate("MemoryLayers.inspect().items.map(i=>i.text)")), pg.inner_text("#strip"))
    r = ask(pg, "I scored 12/100 in my maths test today")
    chips = pg.evaluate("[...document.querySelectorAll('#chat .m.a:last-child button')].map(b=>b.innerText)")
    ok("chat: quick-reply buttons are rendered for suggestions", any("recovery" in c.lower() for c in chips), chips)
    for btn in pg.query_selector_all("#chat .m.a:last-child button"):
        if "recovery" in btn.inner_text().lower(): btn.click(); break
    pg.wait_for_timeout(700)
    ok("chat: tapping a quick reply continues the conversation (the planner asks what it needs)", "how long" in last_reply(pg).lower(), last_reply(pg))
    r = ask(pg, "90 minutes"); ok("chat: the plan is built from the notes", "Warm-up" in r or "lost marks" in r, r[:200])
    ok("chat: the task chip shows the active plan", "Plan" in pg.inner_text("#taskchip"), pg.inner_text("#strip"))
    r = ask(pg, "100×100"); ok("chat: calculator still works through the brain", "10000" in r, r)
    r = ask(pg, "what were we doing"); ok("chat: 'what were we doing' recalls the plan", "plan" in r.lower(), r)

    # --- memory panel, XSS ---
    pg.evaluate("MemoryLayers.addEvent('<img src=x onerror=window.__xss=1>', 'tomorrow')")
    pg.click("#menu") if pg.query_selector("#menu") else pg.evaluate("openSheet('sheet')")
    pg.wait_for_timeout(300)
    pg.click("#memins"); pg.wait_for_timeout(300)
    ok("memory panel: inspect lists saved items with delete buttons", pg.evaluate("document.querySelectorAll('#meminspect [data-del]').length") >= 3)
    ok("security: hostile text in memory is shown as text, not executed", pg.evaluate("window.__xss") is None and pg.evaluate("!document.querySelector('#meminspect img')"))
    n = pg.evaluate("document.querySelectorAll('#meminspect [data-del]').length"); pg.click("#meminspect [data-del]"); pg.wait_for_timeout(200)
    ok("memory panel: deleting one item removes exactly that item", pg.evaluate("document.querySelectorAll('#meminspect [data-del]').length") == n - 1)
    pg.fill("#forgetq", "physics"); pg.click("#forgetgo"); pg.wait_for_timeout(200)
    ok("memory panel: 'forget a topic' removes it everywhere", pg.evaluate("!MemoryLayers.inspect().items.some(i=>/physics/i.test(i.text))"))
    ok("back: the Android back hook closes the open panel first, then declines", pg.evaluate("__edoBack()") is True and pg.evaluate("!document.querySelector('.sheet.open')") and pg.evaluate("__edoBack()") is False)
    pg.evaluate("openSheet('sheet')"); pg.select_option("#ret1", "1"); ok("memory panel: retention setting is stored", pg.evaluate("MemoryLayers.status().cfg.turnDays") == 1); pg.evaluate("closeSheets()")

    # --- memory OFF ---
    pg.evaluate("openSheet('sheet')"); pg.click("#memon"); pg.wait_for_timeout(200); pg.evaluate("closeSheets()")
    before = pg.evaluate("localStorage.getItem('edo_layers_v1')")
    ok("memory OFF: the chip says memory is off", "off" in pg.inner_text("#memchip").lower(), pg.inner_text("#memchip"))
    r = ask(pg, "I got 55 marks today"); after = pg.evaluate("localStorage.getItem('edo_layers_v1')")
    ok("memory OFF: replies still work and nothing new is written", "55" in r and before == after, (r, before == after))
    pg.evaluate("openSheet('sheet')"); pg.click("#memon"); pg.wait_for_timeout(200); pg.evaluate("closeSheets()")

    # --- project loading, queries, worker ---
    files = {
        "Enemy.cs": "using UnityEngine;\npublic class Enemy : MonoBehaviour {\n  [SerializeField] private float speed = 2f;\n  void update() { transform.position += Vector3.forward * speed; }\n  void Update() { var p = FindObjectOfType<Player>(); }\n  public void TakeDamage(int n) { }\n}\n",
        "Player.cs": "using UnityEngine;\npublic class Player : MonoBehaviour { void Start(){ var e = FindObjectOfType<Enemy>(); e.TakeDamage(1);} }\n",
        "Enemy.cs.meta": "guid: aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n",
        "Main.unity": "--- !u!114 &1\nMonoBehaviour:\n  m_Script: {fileID: 11500000, guid: aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa, type: 3}\n  speed: 0\n",
    }
    pg.evaluate("openSheet('sheet')")
    pg.set_input_files("#pjin2", [{"name": k, "mimeType": "text/plain", "buffer": v.encode()} for k, v in files.items()] if pg.query_selector("#pjin2") else [])
    pg.wait_for_timeout(1200)
    ok("project: loading files builds an index and shows the project chip", "4 files" in pg.inner_text("#projchip") or "files" in pg.inner_text("#projchip"), pg.inner_text("#strip"))
    pg.evaluate("closeSheets(); applyMode('Programming', true)")
    r = ask(pg, "where is TakeDamage defined"); ok("project: 'where is X defined' answers from the index", "Enemy.cs" in r, r)
    r = ask(pg, "Why is my Unity enemy not moving?", 900); ok("project: Unity diagnosis uses code and scene values", "Enemy.cs" in r and "Main.unity" in r, r[:300])
    ok("project: the tool chip says the project brain answered", "Project brain" in pg.inner_text("#toolchip"), pg.inner_text("#toolchip"))
    r = ask(pg, "I'm frustrated because this project keeps crashing", 900); ok("project: frustration gets empathy plus a project-specific triage", ("frustrat" in r.lower() or "get it" in r.lower() or "sounds" in r.lower()) and ("Enemy.cs" in r or "stack trace" in r.lower()), r[:300])

    big = [{"path": "src/m%d.js" % i, "content": ("import './m%d';\nexport function f%d(a){ return a + %d; }\n" % ((i + 1) % 700, i, i)) * 25} for i in range(700)]
    res = pg.evaluate("""async (files) => {
      let max = 0, last = performance.now(), run = true;
      const tick = () => { const n = performance.now(); max = Math.max(max, n - last); last = n; if (run) requestAnimationFrame(tick); }; requestAnimationFrame(tick);
      const t0 = performance.now(); const r = await ProjectClient.review(files, {name:'big', url:'workers/project-worker.js'}); run = false;
      return { ms: Math.round(performance.now() - t0), maxGap: Math.round(max), scanned: r.scanned, files: r.stats.files };
    }""", big)
    ok("worker: a 700-file review runs off the main thread (longest frame gap stays small)", res["scanned"] == 700 and res["maxGap"] < 250, res)
    res2 = pg.evaluate("""async (files) => {
      const p = Project.create({name:'big'}); let max = 0, last = performance.now(), run = true;
      const tick = () => { const n = performance.now(); max = Math.max(max, n - last); last = n; if (run) requestAnimationFrame(tick); }; requestAnimationFrame(tick);
      await p.indexAsync(files, {budgetMs: 8}); run = false; return { maxGap: Math.round(max), files: p.stats().files };
    }""", big)
    ok("indexing: chunked main-thread indexing keeps the UI responsive", res2["files"] == 700 and res2["maxGap"] < 250, res2)

    # --- voice session with a fake microphone ---
    pg.evaluate("applyMode('Assistant', true)")
    pg.click("#mic"); pg.wait_for_timeout(300)
    ok("voice: tapping the mic shows the listening orb with an accessible label", pg.evaluate("document.getElementById('vorb').dataset.s") == "listening" and "listening" in pg.inner_text("#vlabel").lower(), pg.evaluate("document.getElementById('vorb').outerHTML"))
    pg.evaluate("__recs[__recs.length-1].say('what time is it', false)"); pg.wait_for_timeout(100)
    ok("voice: interim transcript is shown while speaking", "what time" in pg.inner_text("#vtext"))
    pg.evaluate("__recs[__recs.length-1].say('what time is it', true)"); pg.wait_for_timeout(2600)
    ok("voice: the transcript goes through the same brain and the answer is spoken", "It is" in last_reply(pg) and any("It is" in s for s in (pg.evaluate("window.__spoken") or [])), (last_reply(pg), pg.evaluate("window.__spoken")))
    ok("voice: the session returns to idle and the orb hides", pg.evaluate("document.getElementById('vorb').hidden") is True, pg.evaluate("document.getElementById('vorb').dataset.s"))
    pg.click("#mic"); pg.wait_for_timeout(200); pg.keyboard.press("Escape"); pg.wait_for_timeout(200)
    ok("voice: Escape stops listening", pg.evaluate("document.getElementById('vorb').hidden") is True)
    pg.evaluate("openSheet('sheet')"); pg.wait_for_timeout(200)
    ok("voice: the wake-word control is honest in a plain browser (disabled, explains why)", pg.evaluate("document.getElementById('vwake').disabled") is True and "Android" in pg.inner_text("#wakenote"), pg.inner_text("#wakenote"))
    pg.evaluate("closeSheets()")
    ok("proactive: the suggestion settings render and persist", pg.evaluate("(()=>{openSheet('sheet');document.getElementById('pa-event').click();return Proactive.config().event})()") is False)

    # --- modes still work ---
    pg.evaluate("applyMode('Basic', true)")
    r = ask(pg, "u=0 a=2 t=5 find v"); ok("modes: Basic still gates the solver and offers the switch", "EDO Pro" in r and ("Switch" in r or "switch" in r.lower()), r[:200])

    # --- assistant layer: provider settings, agent routing, honest planner (mock AI endpoint, no real service) ---
    state = {"fail": False, "bodies": []}
    def anth(route):
        req = route.request
        h = {"access-control-allow-origin": "*", "access-control-allow-headers": "*", "access-control-allow-methods": "POST, OPTIONS"}
        if req.method == "OPTIONS": route.fulfill(status=204, headers=h); return
        state["bodies"].append(req.post_data or "")
        if state["fail"]: route.fulfill(status=500, headers=h, body="{}"); return
        route.fulfill(status=200, headers=dict(h, **{"content-type": "application/json"}), body=json.dumps({"content": [{"type": "text", "text": "Mocked Claude reply about monads."}]}))
    pg.route("https://api.anthropic.com/**", anth)
    pg.evaluate("applyMode('Assistant', true)")
    ok("ai: the provider block exists in settings and starts on 'none'", pg.evaluate("panel(), $('aiprov').value") == "none" and "built-in" in pg.inner_text("#aistat").lower(), pg.inner_text("#aistat"))
    errors[:] = [e for e in errors if "status of 500" not in e]  # the deliberate mock-provider failure above logs these; anything else still fails the run
    pg.evaluate("$('aiprov').value='claude';$('aiprov').onchange();$('aimodel').value='model-x';$('aikey').value='sk-test-key-12345'")
    pg.evaluate("$('aisave').onclick()"); pg.wait_for_timeout(600)
    st = pg.inner_text("#aistat")
    ok("ai: save-and-test reaches the (mock) provider and reports the real result", "Connected to claude" in st, st)
    ok("ai: the key is cleared from the field and never rendered or stored in the plain settings", pg.evaluate("$('aikey').value") == "" and "sk-test-key-12345" not in pg.inner_text("body") and "sk-test-key-12345" not in (pg.evaluate("localStorage.getItem('edo_config_v1')") or ""), "")
    ok("ai: the request went to the provider with the key in a header only", state["bodies"] and "sk-test-key" not in state["bodies"][0], state["bodies"][:1])
    r = ask(pg, "explain what a monad is in simple words", 1200)
    ok("ai: open conversation is answered by the provider and labelled as unverified", "Mocked Claude reply" in r and "Not independently verified" in pg.evaluate("[...document.querySelectorAll('#chat .m.a')].pop().innerHTML"), r)
    r = ask(pg, "100×100"); ok("ai: arithmetic still comes from the strict calculator, not the AI", "10000" in r and "Mocked" not in r, r)
    r = ask(pg, "remind me in 5 minutes to stretch", 1200)
    ok("ai: the planner reports the reminder as unavailable in a browser instead of claiming success", ("Android app" in r or "unavailable" in r.lower()) and "✓" not in r, r)
    state["fail"] = True
    r = ask(pg, "hello there", 1500)
    ok("ai: when the provider fails EDO still answers locally and says so", len(r) > 3 and "AI unavailable" in pg.evaluate("[...document.querySelectorAll('#chat .m.a')].pop().innerHTML"), r)
    pg.evaluate("$('aiprov').value='none';$('aisave').onclick()")
    ok("ai: switching the provider off returns to built-in engines", "built-in" in pg.inner_text("#aistat").lower(), pg.inner_text("#aistat"))
    errors[:] = [e for e in errors if "status of 500" not in e]  # the deliberate mock-provider failure above logs these; anything else still fails the run

    # --- EDO.AndroidBridge in a real browser: fallbacks must work and must not pretend to be native ---
    caps = pg.evaluate("EDO.AndroidBridge.getCapabilities().then(c=>({env:c.environment,s:Object.fromEntries(Object.entries(c.capabilities).map(([k,v])=>[k,v.state]))}))")
    ok("androidbridge: a plain browser is reported as a browser, with settings and clipboard-read unsupported", caps["env"] == "browser" and caps["s"]["settings"] == "UNSUPPORTED_ENVIRONMENT" and caps["s"]["clipboardRead"] == "UNSUPPORTED_ENVIRONMENT" and not pg.evaluate("EDO.AndroidBridge.isAvailable()"), caps)
    pg.set_content("<button id=pick onclick=\"window.__r=EDO.AndroidBridge.pickFile().then(p=>EDO.AndroidBridge.readFile({ref:p.files[0].ref})).then(r=>({t:r.text,k:r.encoding,e:r.eof}),e=>({code:e.code}))\">pick</button>") if False else None
    pg.evaluate("document.getElementById('sheet').classList.remove('open')")
    pg.evaluate("(()=>{const b=document.createElement('button');b.id='abpick';b.textContent='pick';b.style.cssText='position:fixed;top:0;left:0;z-index:99999';document.body.appendChild(b);b.onclick=()=>{window.__ab=EDO.AndroidBridge.pickFile().then(p=>EDO.AndroidBridge.readFile({ref:p.files[0].ref})).then(r=>({t:r.text,enc:r.encoding,eof:r.eof,kind:r.kind}),e=>({code:e.code,msg:e.message}))}})()")
    with pg.expect_file_chooser() as fc:
        pg.click("#abpick")
    fc.value.set_files({"name": "uni.txt", "mimeType": "text/plain", "buffer": "héllo 世界 \U0001F600".encode("utf-8")})
    res = pg.evaluate("window.__ab")
    ok("androidbridge: a real file chooser + the fallback reader keep Unicode intact", res.get("t") == "héllo 世界 \U0001F600" and res.get("enc") == "utf-8" and res.get("eof") is True, res)
    pg.evaluate("document.getElementById('abpick').onclick=()=>{window.__ab=EDO.AndroidBridge.pickFile().then(p=>EDO.AndroidBridge.readFile({ref:p.files[0].ref})).then(r=>({t:r.text}),e=>({code:e.code,msg:e.message}))}")
    with pg.expect_file_chooser() as fc:
        pg.click("#abpick")
    fc.value.set_files({"name": "fake.pdf", "mimeType": "application/pdf", "buffer": b"just some words, not a PDF"})
    res = pg.evaluate("window.__ab")
    ok("androidbridge: a file named .pdf whose content is not a PDF is refused, not read", res.get("code") == "UNSUPPORTED_FILE_TYPE", res)
    e = pg.evaluate("EDO.AndroidBridge.requestPermission('calls').then(()=>null,e=>e.code)")
    ok("androidbridge: native-only permissions are refused in a browser instead of faked", e == "UNSUPPORTED_CAPABILITY", e)
    e = pg.evaluate("EDO.AndroidBridge.readFile({ref:'content://media/external/1'}).then(()=>null,e=>e.code)")
    ok("androidbridge: a content:// URI is not accepted where a ref is required", e == "INVALID_ARGUMENT", e)
    b.close()
    ok("boot: no script errors or CSP violations during the whole run", not errors, errors)

    # --- file:// (the Android WebView origin) ---
    errs2 = []
    b2, pg2 = boot(p, "file://" + ROOT + "/index.html", errs2)
    pg2.evaluate("applyMode('Assistant', true)")
    r = ask(pg2, "100×100"); ok("file://: the page boots and answers under the CSP (as in the Android WebView)", "10000" in r, r)
    r = ask(pg2, "I got 90 marks today"); ok("file://: the brain, memory and friend modules work from file://", "90" in r, r)
    w = pg2.evaluate("""async () => { const t0 = performance.now(); try { const r = await ProjectClient.review([{path:'a.js',content:'export const a=1'}], {timeoutMs: 4000}); return {ok:true, scanned:r.scanned, ms: Math.round(performance.now()-t0)}; } catch (e) { return {ok:false, code:e.code||'error', msg:String(e.message).slice(0,80), ms: Math.round(performance.now()-t0)}; } }""")
    ok("file://: the background worker either works or fails cleanly and quickly (main-thread indexing remains)", (w.get("ok") and w["scanned"] == 1) or (not w.get("ok") and w["ms"] < 4500), w)
    print("      (worker over file:// →", w, ")")
    pg2.evaluate("applyMode('Programming', true)")
    pg2.evaluate("""async () => { const p = Project.create({name:'t'}); await p.indexAsync([{path:'a.cs',content:'public class A : MonoBehaviour { void update(){} }'}]); CodeBrain.setProject(p); }""")
    r = ask(pg2, "review the project"); ok("file://: project review works on the main thread without a worker", "Project review" in r, r[:200])
    ok("file://: no CSP violations or script errors", not errs2, errs2)
    b2.close()

print("\n%d passed, %d failed" % (len(passes), len(fails)))
sys.exit(1 if fails else 0)
