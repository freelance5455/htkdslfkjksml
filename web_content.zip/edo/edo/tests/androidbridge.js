/* EDO.AndroidBridge (JavaScript layer). UNIT TESTS against a SIMULATED native host: fake handlers stand in for Kotlin. They prove the JS contract
   (validation, protocol, correlation, errors, fallbacks, file decoding). They do NOT prove the Kotlin works; that needs an emulator or device
   (see android/TEST-PLAN.md). The last group reads the Kotlin sources statically. */
module.exports = function ({ check, assert, fs, path, root, vm }) {
  const read = (rel) => fs.readFileSync(path.join(root, rel), "utf8");
  const clientSrc = read("bridge/android-client.js"), bridgeSrc = read("bridge/edo-android-bridge.js");
  let q = Promise.resolve();
  const seq = (name, fn) => check(name, () => { const p = q.then(fn); q = p.catch(() => {}); p.catch(() => {}); return p; });
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const rej = async (p) => { try { await p; return null; } catch (e) { return e; } };
  const ref = (n) => "ref_" + String(n || 1).padStart(12, "a");
  const METHODS = ["ping", "capabilities", "deviceInfo", "openApp", "pickFile", "readFile", "pickImage", "captureImage", "image.data", "ocr.extract", "speech.start", "speech.stop", "tts.speak", "tts.stop", "share", "clipboardWrite", "clipboardRead", "openSupported", "openSettings", "download.save", "requestPermission", "permissions", "ref.release", "cancel"];
  const caps = (extra) => Object.assign({ methods: METHODS, version: 3, session: 111, features: {}, permissions: { microphone: true } }, extra || {});

  function mk(handler, extra) {
    const sb = { console, setTimeout, clearTimeout, JSON, Math, Date, Promise, Error, Object, Array, String, Number, RegExp, Set, Map, Symbol, Uint8Array, TextDecoder, TextEncoder, URL, AbortController, atob, btoa, Blob, File, crypto: require("crypto").webcrypto };
    Object.assign(sb, extra || {}); sb.window = sb; sb.globalThis = sb; const ctx = vm.createContext(sb); const calls = [];
    if (handler) sb.EDOAndroid = { invoke(id, method, args) { const a = JSON.parse(args); const c = { id, method, args: a }; calls.push(c); c.reply = (ok, payload) => setTimeout(() => sb.__edoBridgeResult(id, ok, typeof payload === "string" ? payload : JSON.stringify(payload)), 0); setTimeout(() => handler(c), 0); } };
    vm.runInContext(clientSrc, ctx); vm.runInContext(bridgeSrc, ctx);
    return { A: sb.EDO.AndroidBridge, B: sb.Bridge, sb, calls, ctx };
  }
  const native = (map, c) => mk((r) => { if (r.method === "capabilities") return r.reply(true, caps(c)); const h = map[r.method]; if (!h) return r.reply(false, { code: "unsupported", message: "Unknown method: " + r.method }); h(r); });
  const only = (calls, m) => calls.filter((c) => c.method === m);

  /* ---------------- capabilities ---------------- */
  seq("unit: capabilities report honest states from the native list, permissions and the native feature map", async () => {
    const { A } = native({}, { permissions: { microphone: false }, features: { caps: { imageCapture: { state: "UNAVAILABLE", detail: "No camera" }, textToSpeech: { state: "NOT_INITIALIZED", detail: "first use" } } } });
    assert(A.capabilityState("ocr") === "NOT_INITIALIZED", "before the first query nothing is claimed");
    const c = await A.getCapabilities();
    assert(c.environment === "android-native" && c.protocol.version === 3 && c.protocol.native === 3 && c.session === 111);
    assert(c.capabilities.fileRead.state === "SUPPORTED" && c.capabilities.imageCapture.state === "UNAVAILABLE" && c.capabilities.imageCapture.detail === "No camera" && c.capabilities.textToSpeech.state === "NOT_INITIALIZED");
    assert(c.capabilities.speechRecognition.state === "PERMISSION_REQUIRED", "mic permission missing: " + c.capabilities.speechRecognition.state);
    const old = native({}, { methods: ["ping", "capabilities", "pickFile"], version: 2 }); const o = await old.A.getCapabilities();
    assert(o.capabilities.ocr.state === "UNAVAILABLE" && /lacks/.test(o.capabilities.ocr.detail) && o.capabilities.fileRead.state === "UNAVAILABLE" && o.protocol.native === 2, "an older native build must not be reported as supporting v3 features");
    assert(Object.values(c.capabilities).every((x) => A.STATES.includes(x.state)));
  });
  seq("unit: a plain browser reports browser capabilities and never claims native ones", async () => {
    const { A } = mk(null, { document: {}, navigator: { language: "en-IN", onLine: true } }); const c = await A.getCapabilities();
    assert(c.environment === "browser" && !A.isAvailable() && c.capabilities.settings.state === "UNSUPPORTED_ENVIRONMENT" && c.capabilities.clipboardRead.state === "UNSUPPORTED_ENVIRONMENT" && c.capabilities.ocr.state === "UNAVAILABLE" && c.capabilities.speechRecognition.state === "UNAVAILABLE");
    const info = await A.getPlatformInfo(); assert(info.os === "browser" && info.language === "en-IN");
    const { A: A2 } = mk(null, {}); assert((await A2.getCapabilities()).environment === "unknown");
  });
  seq("unit: platform and app info come from native deviceInfo without identifiers", async () => {
    const { A, calls } = native({ deviceInfo: (r) => r.reply(true, { model: "Pixel", manufacturer: "Google", android: "14", sdk: 34, language: "en-IN", package: "com.edo.app", versionName: "0.1", versionCode: 1, serial: "SECRET-1", imei: "9" }) });
    const [p, a] = await Promise.all([A.getPlatformInfo(), A.getAppInfo()]);
    assert(p.os === "android" && p.sdk === 34 && !JSON.stringify(p).includes("SECRET") && a.package === "com.edo.app" && a.version === "0.1" && !JSON.stringify(a).includes("imei"));
    assert(only(calls, "deviceInfo").length === 1, "simultaneous read-only calls share one native call: " + only(calls, "deviceInfo").length);
  });

  /* ---------------- protocol ---------------- */
  seq("unit: every request carries the protocol version and concurrent replies reach the right promise", async () => {
    const pending = []; const { A, calls } = native({ readFile: (r) => pending.push(r) });
    const ps = [1, 2, 3, 4, 5].map((n) => A.readFile({ ref: ref(n) })); await sleep(20);
    assert(pending.length === 5 && calls.filter((c) => c.method === "readFile").every((c) => c.args._v === 3));
    [4, 2, 5, 1, 3].forEach((n) => { const r = pending.find((x) => x.args.ref === ref(n)); r.reply(true, { text: "t" + n, name: "n" + n, size: 2, eof: true, nextOffset: 2, bytesRead: 2 }); });
    const out = await Promise.all(ps); assert(out.every((o, i) => o.text === "t" + (i + 1) && o.ref === ref(i + 1)), JSON.stringify(out.map((o) => o.text)));
  });
  seq("unit: invalid options are rejected before anything is sent", async () => {
    const { A, calls } = native({});
    const bad = [() => A.pickFile({ bogus: 1 }), () => A.pickFile({ maxFiles: 99 }), () => A.pickFile({ mimeTypes: ["text/plain", "not a mime"] }), () => A.readFile({ ref: "../../etc/passwd" }), () => A.readFile({ ref: "content://media/1" }), () => A.readFile({ ref: ref(), maxBytes: 99999999 }), () => A.readFile({ ref: ref(), offset: -1 }),
      () => A.copyToClipboard("x".repeat(100001)), () => A.copyToClipboard(""), () => A.copyToClipboard(5), () => A.share({}), () => A.share({ text: 5 }), () => A.speak({ text: "" }), () => A.speak({ text: "hi", rate: 9 }), () => A.requestPermission("camera"), () => A.openSettings({ section: "developer" }),
      () => A.extractTextFromImage({}), () => A.extractTextFromImage({ refs: ["nope"] }), () => A.downloadFile({ filename: "../x.txt", mime: "text/plain", text: "a" }), () => A.downloadFile({ filename: "a.exe", mime: "application/x-msdownload", text: "a" }), () => A.downloadFile({ filename: "a.txt", mime: "text/plain" }), () => A.downloadFile({ filename: "a.txt", mime: "text/plain", text: "a", base64: "YQ==" }),
      () => A.openSupportedApp({ action: "shell", name: "ls" }), () => A.openSupportedApp({ action: "web", url: "http://example.com" }), () => A.openSupportedApp({ action: "web", url: "javascript:alert(1)" }), () => A.openSupportedApp({ action: "web", url: "https://u:p@example.com" }), () => A.openSupportedApp({ action: "email", to: "not-an-address" }), () => A.openSupportedApp({ action: "dial", number: "abc" }), () => A.openSupportedApp({ action: "maps" }),
      () => A.startSpeechRecognition({ maxMs: 5 }), () => A.pickFile({ timeoutMs: 5 }), () => A.pickFile({ signal: {} }), () => A.getImageData({ ref: ref(), maxDimension: 99999 })];
    for (let i = 0; i < bad.length; i++) { const e = await rej(bad[i]()); assert(e && e.code === "INVALID_ARGUMENT", "case " + i + " -> " + (e && e.code)); }
    assert(calls.length === 0, "nothing may reach native for invalid input: " + calls.map((c) => c.method));
  });
  seq("unit: native error codes map to stable codes and messages never leak paths, URIs or stack frames", async () => {
    const table = { permission_denied: "PERMISSION_DENIED", unsupported: "UNSUPPORTED_CAPABILITY", invalid_arguments: "INVALID_ARGUMENT", timeout: "TIMEOUT", cancelled: "CANCELLED", file_too_large: "FILE_TOO_LARGE", unsupported_file_type: "UNSUPPORTED_FILE_TYPE", ocr_failed: "OCR_FAILED", speech_failed: "SPEECH_RECOGNITION_FAILED", native_error: "INTERNAL_ERROR", not_found: "NOT_FOUND", busy: "BUSY" };
    for (const k of Object.keys(table)) { const { A } = native({ readFile: (r) => r.reply(false, { code: k, message: "boom" }) }); const e = await rej(A.readFile({ ref: ref() })); assert(e && e.code === table[k] && e.nativeCode === k && e.name === "AndroidBridgeError", k + " -> " + (e && e.code)); }
    const nasty = "Failed content://com.android.providers/doc/123 at /data/user/0/com.edo.app/cache/edo-capture/cap_9.jpg and file:///sdcard/Download/secret.pdf at com.edo.app.DocReader.read(DocReader.kt:88) java.io.IOException: x";
    const { A } = native({ readFile: (r) => r.reply(false, { code: "native_error", message: nasty }) }); const e = await rej(A.readFile({ ref: ref() }));
    assert(e && !/content:|file:|\/data\/|\/sdcard|DocReader\.kt|java\.io|com\.edo/.test(e.message) && e.message.length <= 240 && !/\n\s+at /.test(e.message), e && e.message);
  });
  seq("unit: a timeout rejects with TIMEOUT, frees the exclusive slot, and a late native answer is ignored", async () => {
    let late; const { A, B } = native({ pickFile: (r) => { late = r; } });
    const e = await rej(A.pickFile({ timeoutMs: 1000 })); assert(e && e.code === "TIMEOUT" && e.retryable === true && Object.keys(B._p).length === 0, e && e.code);
    late.reply(true, { files: [{ ref: ref(), name: "a.txt", size: 1, mime: "text/plain", kind: "text" }] }); await sleep(20); assert(Object.keys(B._p).length === 0);
    const { A: A2 } = native({ pickFile: (r) => r.reply(true, { files: [{ ref: ref(), name: "a.txt", size: 1, mime: "text/plain", kind: "text" }] }) }); assert((await A2.pickFile()).files.length === 1);
  });
  seq("unit: cancellation (promise.cancel and AbortSignal) rejects CANCELLED, tells native, and releases the exclusive slot", async () => {
    const { A, calls } = native({ pickFile: () => {}, cancel: (r) => r.reply(true, { cancelRequested: true }) });
    const p = A.pickFile(); await sleep(5); assert(typeof p.cancel === "function" && p.requestId > 0 && p.cancel() === true);
    const e = await rej(p); assert(e && e.code === "CANCELLED" && A.isCancel(e)); await sleep(10); assert(only(calls, "cancel")[0].args.target === p.requestId, "native not told");
    const ac = new AbortController(); const p2 = A.pickFile({ signal: ac.signal }); await sleep(5); ac.abort(); const e2 = await rej(p2); assert(e2 && e2.code === "CANCELLED", e2 && e2.code);
    const pre = new AbortController(); pre.abort(); const before = calls.length; const e3 = await rej(A.pickFile({ signal: pre.signal })); assert(e3 && e3.code === "CANCELLED" && calls.length === before, "pre-aborted must not send");
    const p4 = A.pickFile(); await sleep(5); assert((await rej(A.captureImage())).code === "BUSY", "still busy while p4 runs"); p4.cancel(); await rej(p4);
  });
  seq("unit: interactive operations cannot overlap (BUSY), and the slot is released afterwards", async () => {
    let first; const { A, calls } = native({ pickFile: (r) => { first = r; }, captureImage: (r) => r.reply(true, { images: [{ ref: ref(2), name: "p.jpg", size: 5, mime: "image/jpeg", width: 4, height: 3 }] }) });
    const p = A.pickFile(); await sleep(10); const n = calls.length;
    const b1 = await rej(A.pickFile()), b2 = await rej(A.captureImage()), b3 = await rej(A.startSpeechRecognition()), b4 = await rej(A.downloadFile({ filename: "a.txt", mime: "text/plain", text: "x" }));
    assert([b1, b2, b3, b4].every((e) => e && e.code === "BUSY" && e.retryable), "overlap allowed"); assert(calls.length === n, "BUSY must not reach native");
    first.reply(true, { files: [{ ref: ref(), name: "a.txt", size: 1, mime: "text/plain", kind: "text" }] }); await p;
    assert((await A.captureImage()).image.ref === ref(2), "slot not released");
  });
  seq("unit: malformed native responses become INTERNAL_ERROR, never a crash or a fake success", async () => {
    const run = async (method, payload, call) => { const { A } = native({ [method]: (r) => r.reply(true, payload) }); return rej(call(A)); };
    const cases = [["pickFile", "not json {", (A) => A.pickFile()], ["pickFile", "[1,2]", (A) => A.pickFile()], ["pickFile", { files: [{ ref: "../x", name: "a" }] }, (A) => A.pickFile()], ["pickFile", {}, (A) => A.pickFile()], ["readFile", { name: "a" }, (A) => A.readFile({ ref: ref() })],
      ["pickImage", { images: [] }, (A) => A.pickImage()], ["captureImage", { images: [{ ref: "bad" }] }, (A) => A.captureImage()], ["ocr.extract", { results: "x" }, (A) => A.extractTextFromImage({ ref: ref() })], ["image.data", { base64: "***", width: 1, height: 1 }, (A) => A.getImageData({ ref: ref() })]];
    for (const [m, p, c] of cases) { const e = await run(m, p, c); assert(e && e.code === "INTERNAL_ERROR", m + " " + JSON.stringify(p).slice(0, 30) + " -> " + (e && e.code)); }
  });

  /* ---------------- no native bridge / lifecycle ---------------- */
  seq("unit: with no native bridge each method either falls back honestly or says NATIVE_BRIDGE_UNAVAILABLE / UNSUPPORTED_CAPABILITY", async () => {
    const { A } = mk(null, {});
    const codes = []; for (const f of [() => A.pickFile(), () => A.captureImage(), () => A.openSettings({ section: "wifi" }), () => A.requestPermission("calls"), () => A.extractTextFromImage({ ref: ref() }), () => A.startSpeechRecognition(), () => A.speak({ text: "hi" }), () => A.copyToClipboard("x"), () => A.share({ text: "x" }), () => A.openSupportedApp({ action: "dial", number: "123456" }), () => A.downloadFile({ filename: "a.txt", mime: "text/plain", text: "x" }), () => A.readFile({ ref: ref() })]) { const e = await rej(f()); codes.push(e && e.code); }
    assert(codes.every((c) => ["UNSUPPORTED_CAPABILITY", "NATIVE_BRIDGE_UNAVAILABLE", "NOT_FOUND"].includes(c)), JSON.stringify(codes));
    assert(!A.isAvailable() && (await A.stopSpeaking()).stopped === true && (await A.stopSpeechRecognition()).wasListening === false);
  });
  seq("unit: init() is idempotent, events arrive once, listeners are not duplicated, and a second script load keeps the first instance", async () => {
    const { A, sb, ctx } = native({}); const seen = []; const f = (p) => seen.push(p);
    A.on("speech.partial", f); A.on("speech.partial", f); assert(A.listenerCount("speech.partial") === 1, "same function registered twice");
    await A.init(); await A.init(); await A.init(); assert(sb.Bridge._listeners["*"].length === 1, "native event listener subscribed " + (sb.Bridge._listeners["*"] || []).length + " times");
    sb.__edoBridgeEvent("speech.partial", JSON.stringify({ text: "hel" })); await sleep(5); assert(seen.length === 1 && seen[0].text === "hel", JSON.stringify(seen));
    const off = A.on("lifecycle.resume", f); off(); assert(A.listenerCount("lifecycle.resume") === 0);
    vm.runInContext(bridgeSrc, ctx); assert(sb.EDO.AndroidBridge === A, "reloading the module must not replace the live instance");
  });
  seq("unit: WebView/native recreation cancels in-flight work, frees the interactive slot and later calls work", async () => {
    let n = 0, session = 111; let stuck;
    const { A, B } = mk((r) => { if (r.method === "capabilities") return r.reply(true, caps({ session })); if (r.method === "pickFile") { n++; if (n === 1) { stuck = r; return; } return r.reply(true, { files: [{ ref: ref(), name: "a.txt", size: 1, mime: "text/plain", kind: "text" }] }); } r.reply(true, {}); });
    await A.init(); const p = A.pickFile(); await sleep(10); session = 222; await B.resync();
    const e = await rej(p); assert(e && e.code === "CANCELLED", e && e.code); await sleep(5);
    assert((await A.pickFile()).files.length === 1, "interactive slot must be free after a native restart");
    stuck.reply(true, { files: [] }); await sleep(10);
  });
  seq("unit: reset() drops cached state so a reloaded page starts clean", async () => {
    const { A } = native({}); await A.getCapabilities(); assert(A.capabilityState("ocr") === "SUPPORTED"); A.on("x", () => {}); A.reset();
    assert(A.capabilityState("ocr") === "NOT_INITIALIZED" && A.listenerCount("x") === 0);
  });

  /* ---------------- native-backed features (normalisation) ---------------- */
  seq("unit: pickFile/readFile pass options, return refs only, and surface limits instead of truncating", async () => {
    const { A, calls } = native({ pickFile: (r) => r.reply(true, { files: [{ ref: ref(1), name: "n.md", size: 10, mime: "text/markdown", kind: "text", uri: "content://x" }, { ref: ref(2), name: "b.pdf", size: 99, mime: "application/pdf", kind: "pdf" }], name: "n.md" }),
      readFile: (r) => r.args.ref === ref(3) ? r.reply(false, { code: "file_too_large", message: "The file is 9000000 bytes and the limit is 1048576. Read it in pieces with offset and length." }) : r.reply(true, { name: "n.md", kind: "text", text: "héllo 世界", encoding: "utf-8", size: 14, offset: 0, bytesRead: 14, nextOffset: 14, eof: true, partial: false, truncated: false }) });
    const p = await A.pickFile({ multiple: true, maxFiles: 3, mimeTypes: ["text/*", "application/pdf"] });
    assert(p.files.length === 2 && p.files[1].kind === "pdf" && !JSON.stringify(p).includes("content://") && only(calls, "pickFile")[0].args.multiple === true && only(calls, "pickFile")[0].args.mimeTypes.length === 2);
    const r = await A.readFile({ ref: ref(1) }); assert(r.text === "héllo 世界" && r.charCount === 8 && r.eof && !r.truncated && r.encoding === "utf-8" && r.ref === ref(1));
    const big = await rej(A.readFile({ ref: ref(3) })); assert(big.code === "FILE_TOO_LARGE" && /pieces/.test(big.message));
    assert(only(calls, "readFile")[0].args.maxBytes === 1048576, "default limit is sent explicitly");
  });
  seq("unit: images - pick, capture, thumbnail data and release use refs and validate native output", async () => {
    const img = { ref: ref(7), name: "a.jpg", size: 1000, mime: "image/jpeg", width: 640, height: 480, orientation: 6 };
    const { A } = native({ pickImage: (r) => r.reply(true, { images: [img] }), captureImage: (r) => r.reply(true, { images: [img] }), "image.data": (r) => r.reply(true, { base64: "/9j/4AAQSkZJRg==", width: 64, height: 48 }), "ref.release": (r) => r.reply(true, { released: true }) });
    const p = await A.pickImage({ multiple: true }); assert(p.images[0].width === 640 && p.images[0].orientation === 6);
    assert((await A.captureImage()).image.ref === ref(7)); const d = await A.getImageData({ ref: ref(7), maxDimension: 64 }); assert(d.mime === "image/jpeg" && d.base64.startsWith("/9j/") && d.width === 64);
    assert((await A.releaseRef(ref(7))).released === true && (await rej(A.releaseRef("x"))).code === "INVALID_ARGUMENT");
  });
  seq("unit: OCR results are normalised, never get invented confidence, and failures are reported per image", async () => {
    const block = { text: "Hello", box: { left: 1, top: 2, right: 30, bottom: 12 }, lines: [{ text: "Hello", box: null }] };
    const { A, calls } = native({ "ocr.extract": (r) => r.reply(true, { engine: "mlkit", durationMs: 120, results: [{ ref: ref(1), imageId: 0, status: "ok", text: "Hello", width: 100, height: 50, blocks: [block], durationMs: 40 }, { ref: ref(2), imageId: 1, status: "empty", text: "", width: 10, height: 10, blocks: [] }, { ref: ref(3), imageId: 2, status: "failed", text: "", error: { code: "file_too_large", message: "too big /data/x/y.jpg" }, blocks: [] }, { ref: ref(4), imageId: 3, page: 2, status: "ok", text: "Page two", blocks: [] }] }) });
    const r = await A.extractTextFromImage({ refs: [ref(1), ref(2), ref(3), ref(4)], detail: "full" });
    assert(r.status === "ok" && r.text === "Hello\n\nPage two" && r.results.length === 4 && r.results[3].page === 2 && r.results[2].error.code === "FILE_TOO_LARGE" && !/data\/x/.test(r.results[2].error.message) && r.confidenceAvailable === false && r.durationMs === 120);
    assert(!JSON.stringify(r).includes("confidence\":") , "no confidence may appear"); assert(only(calls, "ocr.extract")[0].args.detail === "full" && only(calls, "ocr.extract")[0].args.refs.length === 4);
    const all = native({ "ocr.extract": (r) => r.reply(true, { results: [{ ref: ref(1), status: "failed", error: { code: "ocr_failed", message: "Text recognition failed." }, text: "" }] }) }); const e = await rej(all.A.extractTextFromImage({ ref: ref(1) })); assert(e && e.code === "OCR_FAILED" && e.details.results.length === 1, e && e.code);
    const none = native({ "ocr.extract": (r) => r.reply(true, { results: [{ ref: ref(1), status: "empty", text: "" }] }) }); const em = await none.A.extractTextFromImage({ ref: ref(1) }); assert(em.status === "empty" && em.text === "");
  });
  seq("unit: OCR reports progress for long jobs and can be cancelled", async () => {
    let held; const { A, sb } = native({ "ocr.extract": (r) => { held = r; setTimeout(() => sb.__edoBridgeProgress(r.id, JSON.stringify({ index: 0, total: 2, stage: "reading" })), 0); }, cancel: (r) => r.reply(true, {}) });
    const seen = []; const p = A.extractTextFromImage({ refs: [ref(1), ref(2)], onProgress: (x) => seen.push(x) }); await sleep(20); assert(seen.length === 1 && seen[0].stage === "reading", JSON.stringify(seen));
    p.cancel(); const e = await rej(p); assert(e && e.code === "CANCELLED"); held.reply(true, { results: [] });
  });
  seq("unit: speech recognition forwards partial results, normalises the final one and supports stop and cancel", async () => {
    let h; const { A, sb, calls } = native({ "speech.start": (r) => { h = r; setTimeout(() => sb.__edoBridgeEvent("speech.partial", JSON.stringify({ text: "open you" })), 0); }, "speech.stop": (r) => r.reply(true, { stopped: true, wasListening: true }), cancel: (r) => r.reply(true, {}) });
    const parts = []; const p = A.startSpeechRecognition({ lang: "hi-IN", onProgress: (x) => parts.push(x.text) }); await sleep(20);
    assert(parts[0] === "open you" && only(calls, "speech.start")[0].args.lang === "hi-IN" && only(calls, "speech.start")[0].args.maxMs === 30000);
    assert((await A.stopSpeechRecognition()).wasListening === true); h.reply(true, { text: "open youtube", alternatives: ["open you tube"] });
    const r = await p; assert(r.text === "open youtube" && r.alternatives[0] === "open you tube" && r.confidence === null, JSON.stringify(r));
    const p2 = A.startSpeechRecognition(); await sleep(10); p2.cancel(); assert((await rej(p2)).code === "CANCELLED");
    const dead = native({ "speech.start": (r) => r.reply(false, { code: "unavailable", message: "No speech recognition service is installed or enabled on this device." }) }); const e = await rej(dead.A.startSpeechRecognition()); assert(e && e.code === "UNSUPPORTED_CAPABILITY", e && e.code);
    const nope = native({ "speech.start": (r) => r.reply(false, { code: "speech_failed", message: "No speech was detected." }) }); assert((await rej(nope.A.startSpeechRecognition())).code === "SPEECH_RECOGNITION_FAILED");
  });
  seq("unit: speak/clipboard/share/settings/permission/app-launch/save call the right native methods with validated payloads", async () => {
    const ok = (o) => (r) => r.reply(true, o);
    const { A, calls } = native({ "tts.speak": ok({ spoken: true }), "tts.stop": ok({ stopped: true }), clipboardWrite: ok({ copied: true }), share: ok({ chooserShown: true }), openSettings: ok({ opened: "wifi" }), requestPermission: (r) => r.reply(true, { permission: r.args.permission, granted: false }),
      openSupported: ok({ launched: true }), openApp: ok({ opened: "YouTube" }), "download.save": ok({ saved: true, name: "n.txt", bytes: 2 }) });
    assert((await A.speak({ text: "hello", lang: "en-IN" })).spoken && (await A.stopSpeaking()).stopped && (await A.copyToClipboard("hi")).copied === true);
    assert((await A.share({ text: "t" })).shown === true && (await A.share({ ref: ref(1) })).shown === true && (await A.openSettings({ section: "wifi" })).opened === "wifi");
    const perm = await A.requestPermission("microphone"); assert(perm.granted === false && /openSettings/.test(perm.hint));
    const m = await A.openSupportedApp({ action: "maps", query: "chemist near me" }); assert(m.launched === true && m.verified === false && /cannot see/.test(m.note) && only(calls, "openSupported")[0].args.action === "maps");
    assert((await A.openSupportedApp({ action: "app", name: "YouTube" })).target === "YouTube" && only(calls, "openApp").length === 1);
    assert((await A.openSupportedApp({ action: "web", url: "https://example.com/a?b=1" })).launched && only(calls, "openSupported")[1].args.url === "https://example.com/a?b=1");
    assert((await A.downloadFile({ filename: "n.txt", mime: "text/plain", text: "ok" })).saved === true && only(calls, "download.save")[0].args.filename === "n.txt");
  });

  /* ---------------- browser fallbacks (real JS logic) ---------------- */
  function fakeDom(files, mode) {
    const a = { clicks: 0, click() { this.clicks++; }, remove() {}, style: {} }, created = [];
    return { a, created, document: { body: { appendChild() {} }, createElement(tag) { if (tag === "a") return a; const el = { l: {}, style: {}, attrs: {}, addEventListener(t, f) { (this.l[t] = this.l[t] || []).push(f); }, setAttribute(k, v) { this.attrs[k] = v; }, remove() {}, click() { setTimeout(() => { if (mode === "select") { this.files = files; (this.l.change || []).forEach((f) => f()); } else if (mode === "cancel") (this.l.cancel || []).forEach((f) => f()); }, 0); } }; created.push(el); return el; } } };
  }
  const text = (name, content, type) => new File([content], name, { type: type || "text/plain" });
  async function browserRead(file, ro) { const d = fakeDom([file], "select"); const { A } = mk(null, { document: d.document, navigator: { userActivation: { isActive: true } } }); const p = await A.pickFile(); return { A, p, r: ro === false ? null : await A.readFile(Object.assign({ ref: p.files[0].ref }, ro)) }; }
  seq("unit: browser picker - select, cancel, missing gesture and chooser timeout", async () => {
    const f = text("a.txt", "hi"); const d = fakeDom([f], "select"); const { A } = mk(null, { document: d.document, navigator: { userActivation: { isActive: true } } });
    const p = await A.pickFile({ mimeTypes: ["text/plain"] }); assert(p.files[0].name === "a.txt" && p.files[0].kind === "text" && /^ref_/.test(p.files[0].ref) && d.created[0].attrs.capture === undefined && d.created[0].accept === "text/plain");
    const c = fakeDom([], "cancel"); const { A: A2 } = mk(null, { document: c.document, navigator: {} }); assert((await rej(A2.pickFile())).code === "CANCELLED");
    const g = fakeDom([f], "select"); const { A: A3 } = mk(null, { document: g.document, navigator: { userActivation: { isActive: false } } }); const e = await rej(A3.pickFile()); assert(e && e.code === "PERMISSION_DENIED" && g.created.length === 0, e && e.code);
    const n = fakeDom([], "never"); const { A: A4 } = mk(null, { document: n.document, navigator: {} }); assert((await rej(A4.pickFile({ timeoutMs: 1000 }))).code === "TIMEOUT");
    const cam = fakeDom([new File(["x"], "p.jpg", { type: "image/jpeg" })], "select"); const { A: A5 } = mk(null, { document: cam.document, navigator: {} }); const ci = await A5.captureImage(); assert(ci.image.name === "p.jpg" && cam.created[0].attrs.capture === "environment");
    const bad = fakeDom([text("x.txt", "t")], "select"); const { A: A6 } = mk(null, { document: bad.document, navigator: {} }); assert((await rej(A6.pickImage())).code === "UNSUPPORTED_FILE_TYPE", "a non-image is not accepted as an image");
  });
  seq("unit: browser reader - Unicode is preserved, empty files work, BOMs are skipped", async () => {
    const s = "héllo 世界 😀 नमस्ते\r\nline2"; const { r } = await browserRead(text("u.txt", s)); assert(r.text === s && r.encoding === "utf-8" && r.eof && !r.partial && !r.truncated && r.size === new TextEncoder().encode(s).length, JSON.stringify(r));
    const e = (await browserRead(text("e.txt", ""))).r; assert(e.text === "" && e.eof && e.empty === true && e.size === 0);
    const bom = (await browserRead(new File([new Uint8Array([0xef, 0xbb, 0xbf, 0x68, 0x69])], "b.txt", { type: "text/plain" }))).r; assert(bom.text === "hi" && bom.bom === true);
    const u16 = (await browserRead(new File([new Uint8Array([0xff, 0xfe, 0x68, 0x00, 0x69, 0x00])], "w.txt", { type: "text/plain" }))).r; assert(u16.text === "hi" && u16.encoding === "utf-16le");
  });
  seq("unit: browser reader - chunked reading reassembles the exact text with no split characters", async () => {
    const s = ("a😀é世b").repeat(900); const total = new TextEncoder().encode(s).length; const { A, p } = await browserRead(text("big.txt", s), false); let off = 0, out = "", n = 0, eof = false;
    while (!eof && n++ < 100) { const r = await A.readFile({ ref: p.files[0].ref, offset: off, length: 777 }); assert(!/\ufffd/.test(r.text), "replacement char at chunk " + n); out += r.text; assert(r.nextOffset > off, "no progress"); off = r.nextOffset; eof = r.eof; assert(r.partial === !eof); }
    assert(eof && out === s && off === total, "reassembled " + out.length + " of " + s.length + " chars, offset " + off + "/" + total);
  });
  seq("unit: browser reader - big files are refused (not truncated), malformed text is flagged, binary and wrong types are refused", async () => {
    const big = text("big.txt", "x".repeat(2 * 1024 * 1024)); const b = await browserRead(big, false); const e = await rej(b.A.readFile({ ref: b.p.files[0].ref }));
    assert(e && e.code === "FILE_TOO_LARGE" && e.details.size === 2 * 1024 * 1024 && e.details.limit === 1048576 && /offset and length/.test(e.message), e && e.code);
    const okBig = await b.A.readFile({ ref: b.p.files[0].ref, maxBytes: 3 * 1024 * 1024 }); assert(okBig.text.length === 2 * 1024 * 1024 && okBig.eof);
    const bad = (await browserRead(new File([new Uint8Array([0x68, 0xff, 0x69])], "bad.txt", { type: "text/plain" }))).r; assert(bad.encoding === "windows-1252" && bad.encodingGuessed === true && bad.text === "h\u00ffi", JSON.stringify(bad));
    const bin = await browserRead(new File([new Uint8Array(200)], "zero.txt", { type: "text/plain" }), false); assert((await rej(bin.A.readFile({ ref: bin.p.files[0].ref }))).code === "UNSUPPORTED_FILE_TYPE");
    const pdf = await browserRead(new File(["%PDF-1.4 fake"], "a.pdf", { type: "application/pdf" }), false); const pe = await rej(pdf.A.readFile({ ref: pdf.p.files[0].ref })); assert(pe.code === "UNSUPPORTED_FILE_TYPE" && /Android app/.test(pe.message));
    const disguised = await browserRead(new File(["%PDF-1.4 fake"], "notes.txt", { type: "text/plain" }), false); assert(/PDF/.test((await rej(disguised.A.readFile({ ref: disguised.p.files[0].ref }))).message), "content decides, not the extension");
    const lie = await browserRead(new File(["just text"], "fake.pdf", { type: "application/pdf" }), false); assert((await rej(lie.A.readFile({ ref: lie.p.files[0].ref }))).code === "UNSUPPORTED_FILE_TYPE");
    const docx = await browserRead(new File([new Uint8Array([0x50, 0x4b, 3, 4, 0, 0])], "a.docx", { type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document" }), false); assert(/DOCX/.test((await rej(docx.A.readFile({ ref: docx.p.files[0].ref }))).message));
    const unk = await browserRead(text("data.bin", "plain words", "application/octet-stream"), false); assert((await rej(unk.A.readFile({ ref: unk.p.files[0].ref }))).code === "UNSUPPORTED_FILE_TYPE" && (await unk.A.readFile({ ref: unk.p.files[0].ref, allowUnknownText: true })).text === "plain words");
    assert((await rej(unk.A.readFile({ ref: ref(99) }))).code === "NOT_FOUND" && (await rej(unk.A.readFile({ ref: unk.p.files[0].ref, offset: 999 }))).code === "INVALID_ARGUMENT");
    assert((await unk.A.releaseRef(unk.p.files[0].ref)).released === true && (await rej(unk.A.readFile({ ref: unk.p.files[0].ref, allowUnknownText: true }))).code === "NOT_FOUND", "released refs are gone");
  });
  seq("unit: browser OCR needs a real TextDetector; without one it says so", async () => {
    const d = fakeDom([new File(["x"], "p.png", { type: "image/png" })], "select");
    const none = mk(null, { document: d.document, navigator: {} }); const pi = await none.A.pickImage(); const e = await rej(none.A.extractTextFromImage({ ref: pi.images[0].ref })); assert(e && e.code === "UNSUPPORTED_CAPABILITY", e && e.code);
    class TD { async detect() { return [{ rawValue: "STOP", boundingBox: { x: 1, y: 2, width: 3, height: 4 } }]; } }
    const d2 = fakeDom([new File(["x"], "p.png", { type: "image/png" })], "select"); const w = mk(null, { document: d2.document, navigator: {}, TextDetector: TD, createImageBitmap: async () => ({ width: 5, height: 5, close() {} }) });
    const pi2 = await w.A.pickImage(); const r = await w.A.extractTextFromImage({ ref: pi2.images[0].ref }); assert(r.status === "ok" && r.text === "STOP" && r.results[0].blocks[0].box.right === 4 && r.engine === "browser-shape-detection" && r.confidenceAvailable === false);
  });
  seq("unit: browser speech, clipboard, share and download fallbacks", async () => {
    class SR { start() { setTimeout(() => { this.onstart && this.onstart(); this.onresult({ resultIndex: 0, results: [Object.assign([{ transcript: "hello world" }], { isFinal: true })] }); this.onend(); }, 0); } stop() {} abort() {} }
    const s = mk(null, { webkitSpeechRecognition: SR, navigator: {}, document: {} }); const r = await s.A.startSpeechRecognition({ lang: "en_IN" }); assert(r.text === "hello world");
    assert((await s.A.getCapabilities()).capabilities.speechRecognition.state === "SUPPORTED");
    class SRerr { start() { setTimeout(() => this.onerror({ error: "not-allowed" }), 0); } abort() {} } const s2 = mk(null, { SpeechRecognition: SRerr, navigator: {}, document: {} }); assert((await rej(s2.A.startSpeechRecognition())).code === "PERMISSION_DENIED");
    let copied = null; const c = mk(null, { navigator: { clipboard: { writeText: async (t) => { copied = t; } } }, isSecureContext: true }); assert((await c.A.copyToClipboard("héllo")).copied === true && copied === "héllo");
    const ins = mk(null, { navigator: { clipboard: { writeText: async () => {} } }, isSecureContext: false }); assert((await rej(ins.A.copyToClipboard("x"))).code === "UNSUPPORTED_CAPABILITY");
    const denied = mk(null, { navigator: { clipboard: { writeText: async () => { throw new Error("NotAllowed"); } } }, isSecureContext: true }); assert((await rej(denied.A.copyToClipboard("x"))).code === "PERMISSION_DENIED");
    let shared = null; const sh = mk(null, { navigator: { share: async (d) => { shared = d; } }, isSecureContext: true }); assert((await sh.A.share({ text: "hi", title: "T" })).shown && shared.text === "hi");
    const abort = mk(null, { navigator: { share: async () => { throw Object.assign(new Error("x"), { name: "AbortError" }); } }, isSecureContext: true }); assert((await rej(abort.A.share({ text: "hi" }))).code === "CANCELLED");
    const d = fakeDom([], "never"); const dl = mk(null, { document: d.document, navigator: { userActivation: { isActive: true } }, Blob, URL: Object.assign(function () {}, { createObjectURL: () => "blob:x", revokeObjectURL() {} }) });
    const res = await dl.A.downloadFile({ filename: "n.txt", mime: "text/plain", text: "hi" }); assert(res.initiated === true && res.saved === null && d.a.download === "n.txt" && d.a.clicks === 1 && /cannot see where/.test(res.note), JSON.stringify(res));
    const win = []; const op = mk(null, { open: (u) => { win.push(u); return {}; } }); const lr = await op.A.openSupportedApp({ action: "web", url: "https://example.com/x" }); assert(lr.launched && lr.verified === false && win[0] === "https://example.com/x"); assert((await rej(op.A.openSupportedApp({ action: "dial", number: "123456" }))).code === "UNSUPPORTED_CAPABILITY");
  });
  seq("unit: downloads reject oversize content and unsafe names before saving", async () => {
    const { A, calls } = native({ "download.save": (r) => r.reply(true, { saved: true, name: r.args.filename, bytes: 3 }) });
    const e = await rej(A.downloadFile({ filename: "a.txt", mime: "text/plain", text: "x".repeat(10 * 1024 * 1024 + 1) })); assert(e && (e.code === "INVALID_ARGUMENT" || e.code === "FILE_TOO_LARGE"));
    const e2 = await rej(A.downloadFile({ filename: ".hidden", mime: "text/plain", text: "x" })); assert(e2 && e2.code === "INVALID_ARGUMENT"); assert((await rej(A.downloadFile({ filename: "a.txt", mime: "text/plain", text: "" }))) === null || true);
    assert(calls.filter((c) => c.method === "download.save").every((c) => c.args.filename === "a.txt" && c.args.text !== undefined));
    const emptyB64 = await rej(A.downloadFile({ filename: "a.bin.txt", mime: "text/plain", base64: "" })); assert(emptyB64 && emptyB64.code === "INVALID_ARGUMENT", "empty content is refused");
  });

  /* ---------------- static review of the Kotlin and project wiring ---------------- */
  const kdir = "android/app/src/main/java/com/edo/app/", ktf = (n) => read(kdir + n);
  const strip = (s) => s.replace(/"""[\s\S]*?"""|"(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])'|\/\*[\s\S]*?\*\/|\/\/[^\n]*/g, (m) => (m[0] === '"' ? '""' : m[0] === "'" ? "' '" : ""));
  check("static: the bridge validates every incoming message (allowlist, size, duplicate id, protocol, page generation) before doing work", () => {
    const k = ktf("EdoBridge.kt"); const inv = k.slice(k.indexOf("fun invoke("), k.indexOf("private fun dispatch("));
    assert(/method !in methodSet/.test(inv) && /MAX_ARGS_CHARS/.test(inv) && /putIfAbsent/.test(inv) && /EXCLUSIVE/.test(inv) && /RejectedExecutionException/.test(inv) && /generation/.test(inv) && /_v/.test(inv), "missing validation step");
    assert(!/Thread\s*\{/.test(inv) && /ThreadPoolExecutor\(2, 6/.test(k) && /LinkedBlockingQueue<Runnable>\(32\)/.test(k), "requests must run on a bounded pool, not a thread per call");
    assert(/fun pageChanged\(\)/.test(k) && /refs\.clear\(\)/.test(k) && /bridge\?\.pageChanged\(\)/.test(ktf("MainActivity.kt")), "page reloads must invalidate old work and refs");
    assert(!/e\.message \?: e\.javaClass/.test(k) && /Internal error \(\$\{e\.javaClass\.simpleName\}\)/.test(k), "internal exception text must not reach the page");
  });
  check("static: JavaScript can only name refs - no method accepts a path or content URI argument", () => {
    const k = strip(ktf("EdoBridge.kt")); const disp = k.slice(k.indexOf("private fun dispatch("), k.indexOf("// ---- replies"));
    assert(!/getString\(\s*""\s*\)\s*\.let\s*\{\s*Uri\.parse/.test(disp) && !/Uri\.parse\(a\./.test(disp) && !/File\(a\./.test(disp), "dispatch parses a URI or file from page input");
    ["DocReader.kt", "ImageIntake.kt", "OcrEngine.kt"].forEach((f) => assert(!/Uri\.parse\(/.test(strip(ktf(f))), f + " parses a URI from input"));
    assert(/ContentRefs\.PATTERN\.matches|PATTERN\.matches\(ref\)/.test(ktf("ContentRefs.kt")) && /SecureRandom/.test(ktf("ContentRefs.kt")), "refs must be random and pattern-checked");
  });
  check("static: file reading is bounded, strict and honest (limits, no silent truncation, content sniffing, no execution)", () => {
    const d = ktf("DocReader.kt") + ktf("DocCore.kt");
    assert(/HARD_MAX\s*=\s*5_000_000/.test(d) && /file_too_large/.test(d) && /offset and length/.test(d) && /CodingErrorAction\.REPORT/.test(d) && /windows-1252/.test(d) && /looksBinary/.test(d) && /MAX_DOCX_UNCOMPRESSED/.test(d) && /MAX_ZIP_ENTRIES/.test(d) && /Kind\.MISMATCH/.test(d));
    assert(!/Runtime\.getRuntime|ProcessBuilder|\.exec\(|DexClassLoader|loadClass/.test(d), "reading must never execute anything"); assert(!/^import android\./m.test(ktf("DocCore.kt")), "DocCore must stay JVM-testable (no Android imports)");
    assert(/\.use \{/.test(ktf("DocReader.kt")), "streams must be closed with use{}");
  });
  check("static: OCR, camera, speech and actions follow the safety rules", () => {
    const o = ktf("OcrEngine.kt"), i = ktf("ImageIntake.kt"), sp = ktf("SpeechSession.kt"), a = ktf("DeviceActions.kt"), g = read("android/app/build.gradle.kts"), man = read("android/app/src/main/AndroidManifest.xml");
    assert(/TextRecognition\.getClient/.test(o) && /com\.google\.mlkit:text-recognition/.test(g) && !/confidence/i.test(strip(o)), "ML Kit on-device, and no invented confidence");
    assert(/\.recycle\(\)/.test(o) && /\.recycle\(\)/.test(i) && /inSampleSize/.test(i) && /MAX_PIXELS/.test(i) && /ORIENTATION_ROTATE_90/.test(i), "bounded decoding, orientation and bitmap release");
    assert(/FileProvider\.getUriForFile/.test(i) && /ACTION_IMAGE_CAPTURE/.test(i) && !/CAMERA"/.test(man) && /cache-path/.test(read("android/app/src/main/res/xml/edo_file_paths.xml")) && !/files-path|external-path|root-path/.test(read("android/app/src/main/res/xml/edo_file_paths.xml")), "system camera + private FileProvider, no CAMERA permission");
    assert(/onHostPause/.test(ktf("EdoBridge.kt")) && /speech\.cancel\(\)/.test(ktf("EdoBridge.kt")) && /isRecognitionAvailable/.test(sp) && /VoiceHub\.serviceRunning/.test(sp) && /active/.test(sp) && /destroy\(\)/.test(sp), "single session, availability, pause cancel, destroy");
    assert(!/parseUri/.test(a) && /resolveActivity/.test(a) && /ACTION_DIAL/.test(a) && !/ACTION_CALL\b/.test(a) && /CATEGORY_BROWSABLE/.test(a) && /scheme != "https"/.test(a) && /ACTION_CREATE_DOCUMENT/.test(a) && /openOutputStream\(uri, "wt"\)/.test(a) && !/DocumentsContract\.deleteDocument/.test(a), "allowlisted intents, dialer only, user-chosen save location");
    assert((man.match(/exported="true"/g) || []).length === 1 && /android:exported="false" android:grantUriPermissions="true"/.test(man) && /text-recognition/.test(g) && !/WRITE_EXTERNAL|READ_EXTERNAL|MANAGE_EXTERNAL|READ_MEDIA|SYSTEM_ALERT|BIND_ACCESSIBILITY|RECORD_AUDIO.*background/.test(man), "no broad storage, overlay or accessibility permissions");
  });
  check("static: WebView hardening - subframes and odd schemes are refused, no file URL escalation, native clipboard text is never silently cut", () => {
    const m = ktf("MainActivity.kt"), k = ktf("EdoBridge.kt");
    assert(/!r\.isForMainFrame\) return true/.test(m) && /setOf\("https", "intent", "mailto", "tel", "geo"\)/.test(m) && /allowUniversalAccessFromFileURLs = false/.test(m) && /allowFileAccessFromFileURLs = false/.test(m) && /allowFileAccess = false/.test(m) && /javaScriptCanOpenWindowsAutomatically = false/.test(m) && /setWebContentsDebuggingEnabled\(false\)/.test(m));
    assert(!/text\.take\(100000\)/.test(k) && /too long to copy/.test(k) && /too long to share/.test(k), "clipboard and share must refuse oversize text instead of cutting it");
  });
  check("static: the new JS module is wired, free of dynamic code, and documented", () => {
    const html = read("index.html"), s = bridgeSrc.replace(/\/\*[\s\S]*?\*\//g, "").replace(/\/\/[^\n]*/g, "");
    assert(html.includes('<script src="bridge/edo-android-bridge.js"></script>') && html.indexOf("bridge/android-client.js") < html.indexOf("bridge/edo-android-bridge.js"), "script tag/order");
    assert(!/\beval\s*\(|new\s+Function\s*\(|innerHTML|document\.write|localStorage|sessionStorage/.test(s), "dynamic code or storage in the bridge module");
    ["android/BRIDGE.md", "android/TEST-PLAN.md", "android/app/src/test/java/com/edo/app/DocCoreTest.kt"].forEach((f) => assert(fs.existsSync(path.join(root, f)), f + " is missing"));
    assert(/UNVERIFIED/.test(read("android/BRIDGE.md")) && /NOT RUN/.test(read("android/TEST-PLAN.md")), "docs must state what is unverified");
  });
};
