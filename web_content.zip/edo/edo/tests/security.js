/* Static security and asset checks: CSP, no dynamic code in new modules, safe HTML construction, every script/media file referenced exists
   and parses, ids are unique, and the "EDO never runs user code" property still holds. */
module.exports = function ({ check, assert, fs, path, root, vm }) {
  const read = (rel) => fs.readFileSync(path.join(root, rel), "utf8");
  const html = read("index.html");
  const walk = (d, out) => { fs.readdirSync(path.join(root, d)).forEach((f) => { const rel = d ? d + "/" + f : f; if (/node_modules|^android\/app\/build/.test(rel)) return; fs.statSync(path.join(root, rel)).isDirectory() ? walk(rel, out) : out.push(rel); }); return out; };
  const all = walk("", []);
  const jsFiles = all.filter((f) => f.endsWith(".js"));

  check("security: the page ships a Content-Security-Policy that blocks frames, plugins, base tags and form posts", () => {
    const m = html.match(/http-equiv="Content-Security-Policy" content="([^"]+)"/); assert(m, "no CSP meta tag");
    const csp = m[1];
    ["default-src 'none'", "frame-src 'none'", "object-src 'none'", "base-uri 'none'", "form-action 'none'"].forEach((d) => assert(csp.includes(d), "CSP lacks " + d));
    assert(!/unsafe-eval/.test(csp), "CSP must not allow eval");
    assert(!/connect-src[^;]*\*(?![.:])/.test(csp.replace(/:\*/g, "").replace(/\.\*/g, "")), "connect-src must not be a bare wildcard");
    assert(/script-src 'self' file:/.test(csp) && /worker-src 'self' file: blob:/.test(csp));
  });
  check("security: no dynamic code evaluation anywhere new, and the one existing compile-only check is unchanged", () => {
    const fresh = ["core/brain.js", "core/friend.js", "core/planner.js", "core/project.js", "core/codebrain.js", "core/validation.js", "core/proactive.js", "core/semantic.js", "core/project-client.js", "core/mpc-layer.js", "memory/layers.js", "voice/voice-engine.js", "knowledge/retrieval.js", "ui/app-extras.js", "workers/project-worker.js", "bridge/android-client.js"];
    fresh.forEach((f) => { const s = read(f).replace(/\/\*[\s\S]*?\*\//g, "").replace(/\/\/[^\n]*/g, ""); assert(!/\beval\s*\(/.test(s) && !/new\s+Function\s*\(/.test(s) && !/setTimeout\s*\(\s*["'`]/.test(s) && !(f === "core/codebrain.js" ? /require\(|vm\.run/ : /child_process|require\(|vm\.run/).test(s), f + " contains dynamic code execution"); }); // codebrain.js names child_process only inside a rule that DETECTS it in analysed code
    const hits = jsFiles.filter((f) => !/^tests\//.test(f)).filter((f) => /new\s+Function\s*\(/.test(read(f).replace(/\/\*[\s\S]*?\*\//g, "").replace(/\/\/[^\n]*/g, "")));
    assert(hits.join() === "tools/code-analyzer.js", "only the existing compile-only syntax check may use Function: " + hits.join());
    assert(/compiled but never run/.test(read("tools/code-analyzer.js")), "the compile-only note must stay");
    assert(!/importScripts/.test(read("ui/app-extras.js")) && /importScripts/.test(read("workers/project-worker.js")));
  });
  check("security: the project worker loads only bundled files and touches no DOM, storage or bridge", () => {
    const w = read("workers/project-worker.js"), imports = (w.match(/importScripts\(([^)]*)\)/)[1].match(/"[^"]+"/g) || []).map((x) => x.slice(1, -1));
    imports.forEach((i) => { assert(/^\.\.\/(core|tools|knowledge)\//.test(i) && !/^https?:|^\/\//.test(i), "worker imports " + i); assert(fs.existsSync(path.join(root, "workers", i)), "worker import missing: " + i); });
    assert(!/document\.|localStorage|EDOAndroid|fetch\(|XMLHttpRequest/.test(w.replace(/\/\*[\s\S]*?\*\//g, "")));
  });
  check("security: user-derived text is escaped before it is put into innerHTML in the new UI code", () => {
    const lines = read("ui/app-extras.js").split("\n").filter((l) => /innerHTML\s*=/.test(l));
    assert(lines.length >= 5, "expected innerHTML builders");
    lines.forEach((l) => { const rest = l.replace(/esc\((?:[^()]|\([^()]*\))*\)/g, "ESC"); const bad = rest.match(/\+\s*[A-Za-z_][\w.]*\.(?:text|name|title|message|content|path|label|phrase|layer|reason)\b(?!\s*\()/); assert(!bad, "unescaped interpolation in: " + l.trim().slice(0, 140) + " → " + (bad && bad[0])); });
    const t = read("ui/app-extras.js"); assert(/const esc = /.test(t) && /&amp;/.test(t) && /&#39;/.test(t), "esc() must escape & < > \" '");
  });
  check("security: storage holds no credentials; runner tokens and endpoints are not persisted by the UI", () => {
    const ui = read("ui/app-extras.js") + read("core/validation.js");
    assert(!/localStorage\.setItem\([^)]*token/i.test(ui) && !/Store\.set\([^)]*(token|secret|key)/i.test(ui));
    jsFiles.filter((f) => !/^tests\//.test(f)).forEach((f) => { const s = read(f); assert(!/AKIA[0-9A-Z]{12,}|sk-[A-Za-z0-9]{20,}|-----BEGIN [A-Z ]*PRIVATE KEY-----/.test(s), "secret-looking string in " + f); });
  });
  check("assets: every JavaScript file parses (syntax only, nothing is run)", () => {
    jsFiles.forEach((f) => { try { new vm.Script(read(f), { filename: f }); } catch (e) { assert(false, f + ": " + e.message); } });
    const inline = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map((m) => m[1]); assert(inline.length >= 1);
    inline.forEach((s, i) => { try { new vm.Script(s, { filename: "inline-" + i }); } catch (e) { assert(false, "inline script " + i + ": " + e.message); } });
  });
  check("assets: every script, video, poster and image referenced by index.html exists; ids are unique", () => {
    const refs = [...html.matchAll(/(?:src|poster)="([^"#?]+)"/g)].map((m) => m[1]).filter((x) => !/^(https?:|data:|blob:)/.test(x));
    assert(refs.length >= 20, "found only " + refs.length + " references");
    refs.forEach((r) => assert(fs.existsSync(path.join(root, r)), "missing file: " + r));
    const order = [...html.matchAll(/<script src="([^"]+)"/g)].map((m) => m[1]);
    const before = (a, b) => assert(order.indexOf(a) >= 0 && order.indexOf(b) >= 0 && order.indexOf(a) < order.indexOf(b), a + " must load before " + b);
    before("core/semantic.js", "memory/layers.js"); before("memory/memory.js", "memory/layers.js"); before("knowledge/unity.js", "knowledge/index.js"); before("core/project.js", "core/codebrain.js"); before("core/validation.js", "core/codebrain.js"); before("core/brain.js", "core/orchestrator.js"); before("voice/voice.js", "voice/voice-engine.js");
    assert(order[order.length - 1] === "ui/app-extras.js", "app-extras must load last");
    const ids = [...html.matchAll(/\sid="([^"]+)"/g)].map((m) => m[1]), dup = ids.filter((x, i) => ids.indexOf(x) !== i); assert(!dup.length, "duplicate ids: " + dup.join());
  });
  check("assets: every element id the new UI code looks up exists in the page or is created by that code", () => {
    const ex = read("ui/app-extras.js"), ids = new Set([...html.matchAll(/\sid="([^"]+)"/g)].map((m) => m[1]));
    const made = new Set([...ex.matchAll(/id="([^"]+)"/g)].map((m) => m[1]));
    const used = new Set([...ex.matchAll(/\$\("([\w-]+)"\)/g)].map((m) => m[1]));
    used.forEach((u) => assert(ids.has(u) || made.has(u), "ui/app-extras.js uses #" + u + " which does not exist"));
    ["memchip", "projchip", "taskchip", "toolchip", "vorb", "vlabel", "vtext", "live", "projpanel", "voicepanel", "proactpanel", "mempanel"].forEach((i) => assert(ids.has(i), "page lacks #" + i));
  });
  check("assets: required accessibility hooks exist (live region, labelled controls, reduced-motion handling, aria on the voice orb)", () => {
    assert(/id="live"[^>]*aria-live="polite"/.test(html) && /id="vorb"[^>]*role="status"/.test(html));
    assert(/prefers-reduced-motion/.test(html) && /body\.calm #vorb/.test(html));
    const ex = read("ui/app-extras.js"); assert(/aria-label="Delete this item"/.test(ex) && /aria-label="Wake phrase"/.test(ex) && /aria-pressed/.test(ex));
    assert(/__edoBack/.test(ex) && /popstate/.test(ex), "back-button handling missing");
  });
  check("safety: EDO still never executes user or generated code (no runner is configured by default)", () => {
    const v = read("core/validation.js"); assert(/EDO never compiles or runs project code itself/.test(v) && /let runnerCfg = null/.test(v));
    assert(!/runnerCfg\s*=\s*\{/.test(v.split("function configureRunner")[0]), "a runner must not be configured at load time");
    assert(/Not executed here\./.test(v) && /confirmed !== true/.test(v));
  });
};
