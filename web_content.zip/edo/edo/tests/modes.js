/* EDO Basic + mode animation checks. Loaded by run-tests.js. */
module.exports = function ({ check, assert, window, root, fs, path }) {
  const B = (t) => window.EDO.handle(t, { mode: "Basic" });
  const read = (rel) => fs.readFileSync(path.join(root, rel), "utf8");

  check("basic: calculator works", () => {
    const r = B("100×100");
    assert(r.kind === "calculation" && /10000/.test(r.text), r.text);
    assert(/15% of 200|30/.test(B("15% of 200").text));
  });
  check("basic: time and date come from the device clock", () => {
    const r = B("what time is it");
    assert(r.kind === "clock" && /device's clock/.test(r.meta), JSON.stringify(r));
    assert(B("what's the date today").kind === "clock");
  });
  check("basic: coding and MPC solving offer an honest switch, never a guess", () => {
    const c = B("write a python function to reverse a string");
    assert(c.kind === "upgrade" && c.upgradeTo === "Programming", JSON.stringify(c));
    const p = B("u=0 a=2 t=5 find v");
    assert(p.kind === "upgrade" && p.upgradeTo === "Assistant", JSON.stringify(p));
    assert(!/\b10\b/.test(p.text), "Basic must not solve it");
  });
  check("basic: device actions and notes still work", () => {
    assert(B("open whatsapp").kind === "device");
    assert(B("call 98765 43210").kind === "device");
    assert(B("remember that my locker is 42").kind === "memory");
  });
  check("regression: Pro and Programming are unchanged by Basic", () => {
    const pro = window.EDO.handle("u=0 a=2 t=5 find v", { mode: "Assistant" });
    assert(pro.kind !== "upgrade" && /10/.test(pro.text), pro.text);
    const code = window.EDO.handle("write a python function to reverse a string", { mode: "Programming" });
    assert(code.kind !== "upgrade");
  });
  check("basic: fallback text is honest and mode-specific", () => {
    const r = B("qwertyuiop asdf");
    assert(/EDO Basic/.test(r.text) && /not guessed|have not guessed/.test(r.text), r.text);
  });
  check("modes (static): both clips, posters and the player ship, and index wires them", () => {
    ["media/mode-pro.mp4", "media/mode-programming.mp4", "media/mode-pro-poster.jpg", "media/mode-programming-poster.jpg", "ui/mode-fx.js"].forEach((f) => assert(fs.existsSync(path.join(root, f)), f));
    const h = read("index.html");
    assert(/ui\/mode-fx\.js/.test(h) && /id="mfx"/.test(h) && /mode-pro\.mp4/.test(h) && /mode-programming\.mp4/.test(h));
    assert(/id:'Basic'/.test(h) && /mode='Basic'/.test(h), "Basic must exist and be the starting mode");
    assert(!/setMode\(/.test(h), "every mode change must go through switchMode so it animates");
  });
  check("modes (static): clips map to the right target modes", () => {
    const src = read("ui/mode-fx.js");
    assert(/Assistant:\s*\{\s*video:\s*"mfx-pro"/.test(src) && /Programming:\s*\{\s*video:\s*"mfx-prog"/.test(src));
    assert(/onSwap/.test(src) && /skipNow/.test(src) && /reduced/.test(src));
  });
  check("regression: a mode clip plays to its end (no early cut-off)", () => {
    const src = read("ui/mode-fx.js");
    assert(!/START_TIMEOUT_MS/.test(src), "a 3 s start timeout used to swap in the short ring");
    assert(!/END_LEAD_S/.test(src), "clips must not fade out before their last frame");
    assert(/LOAD_TIMEOUT_MS\s*=\s*20000/.test(src) && /canplay/.test(src), "slow connections must wait for the clip to buffer");
    assert(!/overlay\.addEventListener\("click"/.test(src), "a stray tap must not end a clip");
    assert(!/"Enter"/.test(src), "held Enter must not end a clip");
  });
};
