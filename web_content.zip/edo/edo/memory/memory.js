/* EDO memory v2. Persistent structured store: categories, timestamps, stable unique IDs, duplicate protection,
   search, update, delete by id / index / content, short conversation context, preferences, tasks.
   Memory ON/OFF is enforced here: when off, nothing is written AND nothing is read (notes() returns []).
   Storage failures never throw: the store falls back to memory for the session and reports the state via status(). */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  const KEY = "edo_mem2", OLD_NOTES = "edo_notes", OLD_ITEMS = "edo_memory", CFG = "edo_memcfg";
  const CATEGORIES = ["notes", "preference", "task", "profile", "fact"];
  const MAX_ITEMS = 500, MAX_LEN = 2000, CTX_MAX = 12;
  let enabled = true, lastError = null, volatile = null, ctxBuf = [];
  const fallback = { v: 2, seq: 0, items: [] };

  function storage() {
    try {
      if (typeof localStorage === "undefined") return null;
      localStorage.setItem("edo_probe", "1");
      localStorage.removeItem("edo_probe");
      return localStorage;
    } catch (e) { lastError = "storage unavailable: " + e.message; return null; }
  }
  const norm = (s) => String(s || "").toLowerCase().replace(/\s+/g, " ").trim();
  function emptyDB() { return { v: 2, seq: 0, items: [] }; }

  function migrate(s) {
    // v1 stored parallel arrays (edo_notes strings, edo_memory objects) that could drift apart. Rebuild from the strings.
    let notes = [];
    try { notes = JSON.parse(s.getItem(OLD_NOTES) || "[]"); } catch (e) {}
    if (!Array.isArray(notes) || !notes.length) return null;
    const db = emptyDB();
    notes.forEach((n) => {
      if (typeof n !== "string" || !n.trim()) return;
      db.seq++;
      db.items.push({ id: mkId(db), category: "notes", content: n.trim().slice(0, MAX_LEN), createdAt: Date.now(), updatedAt: Date.now() });
    });
    return db;
  }
  function mkId(db) { return "m" + (++db.seq).toString(36) + "_" + Date.now().toString(36); }

  function load() {
    const s = storage();
    if (!s) return volatile || fallback;
    try {
      const raw = s.getItem(KEY);
      if (raw) {
        const db = JSON.parse(raw);
        if (db && db.v === 2 && Array.isArray(db.items)) {
          db.seq = Math.max(+db.seq || 0, db.items.length);
          return db;
        }
      }
      const mig = migrate(s);
      if (mig) { persist(mig); try { s.removeItem(OLD_NOTES); s.removeItem(OLD_ITEMS); } catch (e) {} return mig; }
      return emptyDB();
    } catch (e) { lastError = "stored memory unreadable: " + e.message; return emptyDB(); }
  }
  function persist(db) {
    const s = storage();
    if (!s) { volatile = db; return { ok: false, error: lastError || "no storage" }; }
    try { s.setItem(KEY, JSON.stringify(db)); lastError = null; return { ok: true }; }
    catch (e) { volatile = db; lastError = "write failed: " + e.message; return { ok: false, error: lastError }; }
  }

  function setEnabled(on) {
    enabled = !!on;
    const s = storage();
    try { if (s) s.setItem(CFG, JSON.stringify({ enabled })); } catch (e) {}
    if (!enabled) ctxBuf = [];
    return enabled;
  }
  function isEnabled() { return enabled; }
  (function restore() { const s = storage(); try { if (s) { const c = JSON.parse(s.getItem(CFG) || "null"); if (c && c.enabled === false) enabled = false; } } catch (e) {} })();

  function all() { return enabled ? load().items.slice() : []; }
  function notes() { return all().filter((i) => i.category === "notes").map((i) => i.content); }
  function list(category) { return all().filter((i) => !category || i.category === category); }

  /* Returns the stored item, {duplicate:true} existing item, or null when memory is off / input empty. */
  function remember(text, category) {
    if (!enabled) return null;
    const content = String(text == null ? "" : text).replace(/\s+/g, " ").trim().slice(0, MAX_LEN);
    if (!content) return null;
    const cat = CATEGORIES.includes(category) ? category : "notes";
    const db = load();
    const dup = db.items.find((i) => i.category === cat && norm(i.content) === norm(content));
    if (dup) return Object.assign({}, dup, { duplicate: true });
    if (db.items.length >= MAX_ITEMS) return null;
    const item = { id: mkId(db), category: cat, content, createdAt: Date.now(), updatedAt: Date.now() };
    db.items.push(item);
    const w = persist(db);
    return w.ok ? item : Object.assign({}, item, { storageError: w.error });
  }
  function update(id, text) {
    if (!enabled) return null;
    const content = String(text || "").replace(/\s+/g, " ").trim().slice(0, MAX_LEN);
    if (!content) return null;
    const db = load(), it = db.items.find((i) => i.id === id);
    if (!it) return null;
    if (db.items.some((i) => i !== it && i.category === it.category && norm(i.content) === norm(content))) return null;
    it.content = content; it.updatedAt = Date.now();
    persist(db);
    return Object.assign({}, it);
  }
  /* which: undefined|"last" → newest; "#2"/number-like → index within the notes list shown to the user;
     an existing id → that item; otherwise case-insensitive substring. Returns the list of removed items. */
  function forget(which) {
    if (!enabled) return [];
    const db = load();
    const shown = db.items.filter((i) => i.category === "notes");
    let victims = [];
    if (which == null || which === "last") victims = db.items.length ? [db.items[db.items.length - 1]] : [];
    else if (/^#?\d+$/.test(String(which).trim())) { const it = shown[+String(which).replace("#", "")]; victims = it ? [it] : []; }
    else if (db.items.some((i) => i.id === String(which))) victims = db.items.filter((i) => i.id === String(which));
    else { const q = norm(which); victims = q ? db.items.filter((i) => norm(i.content).includes(q)) : []; }
    if (victims.length) { const ids = new Set(victims.map((v) => v.id)); db.items = db.items.filter((i) => !ids.has(i.id)); persist(db); }
    return victims;
  }
  function clear() { const db = emptyDB(); persist(db); ctxBuf = []; return true; }
  function search(query, category) {
    const q = norm(query).split(" ").filter((w) => w.length > 1);
    if (!q.length) return [];
    return list(category).map((i) => ({ item: i, score: q.filter((w) => norm(i.content).includes(w)).length }))
      .filter((x) => x.score).sort((a, b) => b.score - a.score || b.item.createdAt - a.item.createdAt).map((x) => x.item);
  }
  /* preferences and tasks */
  function setPref(key, value) {
    if (!enabled) return null;
    const k = norm(key), db = load();
    const ex = db.items.find((i) => i.category === "preference" && norm(i.content).startsWith(k + ":"));
    if (ex) { ex.content = k + ": " + String(value); ex.updatedAt = Date.now(); persist(db); return Object.assign({}, ex); }
    return remember(k + ": " + String(value), "preference");
  }
  function getPref(key) {
    const k = norm(key), it = list("preference").find((i) => norm(i.content).startsWith(k + ":"));
    return it ? it.content.slice(k.length + 1).trim() : undefined;
  }
  function addTask(text) { return remember(text, "task"); }
  function doneTask(id) { return forget(id).length > 0; }
  /* conversation context: short rolling window, never persisted */
  function pushContext(role, text) { if (!enabled) return false; ctxBuf.push({ role, text: String(text).slice(0, 500), t: Date.now() }); if (ctxBuf.length > CTX_MAX) ctxBuf.shift(); return true; }
  function context() { return enabled ? ctxBuf.slice() : []; }
  function status() { return { enabled, persistent: !!storage() && !volatile, lastError, count: all().length }; }

  function handle(text, ctx) {
    if (ctx && typeof ctx.memoryOn === "boolean") setEnabled(ctx.memoryOn);
    if (!enabled) return { kind: "memory", text: "Memory is switched off, so I have not saved or read anything. Turn it on in the panel to use notes.", meta: "Memory OFF. Nothing stored." };
    const m = text.match(/^\s*(remember|note that|save this)\s*:?\s*(.+)$/i);
    if (m) {
      const item = remember(m[2].trim(), "notes");
      if (!item) return { kind: "memory", text: "I could not save that note (empty or memory is full).", meta: "Nothing stored." };
      if (item.duplicate) return { kind: "memory", text: "Already saved: " + item.content, meta: "Duplicate ignored. ID " + item.id };
      return { kind: "memory", text: "Saved locally: " + item.content + (item.storageError ? "\nWarning: device storage failed (" + item.storageError + "). It is kept only until you close EDO." : ""), meta: "Device memory only. Not sent anywhere. ID " + item.id };
    }
    const f = text.match(/^\s*forget\b\s*(.*)$/i);
    if (f) {
      const arg = f[1].trim().replace(/^(?:note|item)\s+/i, "");
      const gone = forget(arg || "last");
      return { kind: "memory", text: gone.length ? "Forgot " + gone.length + " item" + (gone.length > 1 ? "s" : "") + ": " + gone.map((g) => g.content).join("; ") + "\nRemaining: " + all().length : "Nothing matched \"" + arg + "\". Nothing was deleted.", meta: "Local delete." };
    }
    const s = text.match(/^\s*(?:search|find)\s+(?:memory|notes)\s+(?:for\s+)?(.+)$/i);
    if (s) { const hits = search(s[1]); return { kind: "memory", text: hits.length ? hits.map((h) => "• " + h.content + " [" + h.id + "]").join("\n") : "No stored note matches that.", meta: "Local memory search." }; }
    const l = all();
    return { kind: "memory", text: l.length ? "I remember:\n" + l.map((n, i) => i + ". [" + n.category + "] " + n.content).join("\n") : "No notes stored on this device.", meta: "Local memory." };
  }
  root.Memory = { handle, remember, update, forget, clear, search, list, notes, load, setEnabled, isEnabled, setPref, getPref, addTask, doneTask, pushContext, context, status, CATEGORIES };
})();
