/* EDO static code analyzer. Pure text analysis: nothing here ever RUNS user code.
   - language detection (fence tag, file name, content heuristics)
   - lexical check: brackets / strings / comments with line numbers (C-like languages)
   - JavaScript: syntax parse only (compiled via the Function constructor, never called)
   - per-language lint rules (heuristic, regex based), complexity estimate, instruction-like text flagged as data
   CodeAnalyzer.check() keeps the old string API; CodeAnalyzer.analyze() returns structured findings. */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  const MAX = 200000;
  const EXT = { js: "javascript", mjs: "javascript", jsx: "javascript", ts: "typescript", tsx: "typescript", py: "python", c: "c", h: "c", cpp: "cpp", cc: "cpp", hpp: "cpp", java: "java", kt: "kotlin", kts: "kotlin", cs: "csharp", html: "html", htm: "html", css: "css", sql: "sql", sh: "bash", bash: "bash" };
  const TAGS = { js: "javascript", javascript: "javascript", node: "javascript", ts: "typescript", typescript: "typescript", py: "python", python: "python", c: "c", cpp: "cpp", "c++": "cpp", java: "java", kotlin: "kotlin", kt: "kotlin", cs: "csharp", csharp: "csharp", "c#": "csharp", html: "html", css: "css", sql: "sql", bash: "bash", sh: "bash", shell: "bash", unity: "csharp" };

  function detect(code, hint) {
    const h = String(hint || "").toLowerCase();
    if (TAGS[h]) return TAGS[h];
    const ext = (/\.([a-z0-9+#]+)$/i.exec(h) || [])[1];
    if (ext && EXT[ext.toLowerCase()]) return EXT[ext.toLowerCase()];
    const s = String(code);
    if (/^\s*<!doctype html|<html[\s>]|<\/(div|body|head|p|span)>/i.test(s)) return "html";
    if (/^\s*#!.*\b(bash|sh)\b|\bfi\b\s*$|\becho\s+["$]|\$\(|\bdone\b\s*$/m.test(s) && !/[;{]\s*$/m.test(s.split("\n")[0])) return "bash";
    if (/\b(SELECT|INSERT INTO|UPDATE|DELETE FROM|CREATE TABLE)\b[\s\S]*\b(FROM|VALUES|SET|\()/i.test(s) && !/[{};]\s*$/m.test(s.replace(/;\s*$/, ""))) return "sql";
    if (/\busing\s+UnityEngine|MonoBehaviour|\bvoid\s+(Update|Start|Awake)\s*\(/.test(s)) return "csharp";
    if (/^\s*#include\s*[<"]/m.test(s)) return /\b(std::|cout|cin|class\s+\w+\s*\{|template\s*<|vector<)/.test(s) ? "cpp" : "c";
    if (/\bfun\s+\w+\s*\(|\bval\s+\w+\s*[:=]|(?<![.\w])println\(/.test(s) && !/\bfunction\b|System\.out/.test(s)) return "kotlin";
    if (/\bpublic\s+(static\s+)?(class|void|int|String)\b|System\.out\.print/.test(s)) return "java";
    if (/\bnamespace\s+\w+|\bConsole\.Write|\bpublic\s+(static\s+)?(async\s+)?(class|void|int|string|Task)\b/.test(s)) return "csharp";
    if (/^\s*(def |class \w+(\(.*\))?:|import \w+|from \w+ import|print\()/m.test(s) && !/[;{}]\s*$/m.test(s)) return "python";
    if (/:\s*(string|number|boolean|void|any)\b|\binterface\s+\w+\s*\{|\btype\s+\w+\s*=/.test(s)) return "typescript";
    if (/\b(function|const|let|var)\b|=>|console\.log/.test(s)) return "javascript";
    if (/^[\s\S]*\{[\s\S]*:[\s\S]*;[\s\S]*\}/.test(s) && /[.#]?[a-z-]+\s*\{/.test(s)) return "css";
    return "unknown";
  }

  /* Lexical balance check for C-like languages. Understands // /* # comments, ', ", ` strings (python: ''' """). */
  function lexical(code, lang) {
    const out = [], st = [], pr = { ")": "(", "]": "[", "}": "{" };
    const hashComment = lang === "python" || lang === "bash";
    const slashComment = !hashComment && lang !== "sql" && lang !== "html";
    let line = 1, i = 0;
    const n = code.length;
    while (i < n) {
      const c = code[i], d = code[i + 1];
      if (c === "\n") { line++; i++; continue; }
      if (hashComment && c === "#") { while (i < n && code[i] !== "\n") i++; continue; }
      if (lang === "sql" && c === "-" && d === "-") { while (i < n && code[i] !== "\n") i++; continue; }
      if (slashComment && c === "/" && d === "/") { while (i < n && code[i] !== "\n") i++; continue; }
      if ((slashComment || lang === "css") && c === "/" && d === "*") {
        const start = line; i += 2;
        while (i < n && !(code[i] === "*" && code[i + 1] === "/")) { if (code[i] === "\n") line++; i++; }
        if (i >= n) out.push("Unterminated block comment starting at line " + start);
        i += 2; continue;
      }
      if (c === '"' || c === "'" || (c === "`" && lang !== "python" && lang !== "c" && lang !== "cpp")) {
        const triple = lang === "python" && code.substr(i, 3) === c.repeat(3);
        const q = triple ? c.repeat(3) : c, start = line;
        i += q.length;
        let closed = false;
        while (i < n) {
          if (code[i] === "\\" && c !== "`" ) { i += 2; continue; }
          if (code[i] === "\\") { i += 2; continue; }
          if (code.substr(i, q.length) === q) { closed = true; i += q.length; break; }
          if (code[i] === "\n") { if (!triple && c !== "`") break; line++; }
          i++;
        }
        if (!closed) out.push("Unterminated string starting at line " + start);
        continue;
      }
      if (lang !== "html" && "([{".includes(c)) st.push({ c, line });
      else if (lang !== "html" && pr[c]) {
        const top = st.pop();
        if (!top) out.push('Unmatched "' + c + '" at line ' + line);
        else if (top.c !== pr[c]) out.push('Mismatched "' + c + '" at line ' + line + ' (opened "' + top.c + '" at line ' + top.line + ")");
      }
      i++;
    }
    st.forEach((t) => out.push('Unclosed "' + t.c + '" opened at line ' + t.line));
    return out;
  }
  function jsParse(code) {
    if (code.length > MAX) return null;
    try { new Function(code); return "JavaScript syntax: parses OK (syntax only; compiled but never run, no runtime testing)."; }
    catch (e) { return "JavaScript syntax error: " + e.message; }
  }
  function pyIndent(code) {
    const out = [], lines = code.split("\n");
    let tabs = 0, spaces = 0;
    lines.forEach((l, k) => {
      if (/^\t+\S/.test(l)) tabs++;
      if (/^ +\S/.test(l)) spaces++;
      if (/^\s*(def|class|if|elif|else|for|while|try|except|finally|with)\b[^#]*[^:\s#,(\\]\s*(#.*)?$/.test(l) && !/:\s*(#.*)?$/.test(l) && !/[\[({,\\]\s*$/.test(l) && /^\s*(def|class|if|elif|for|while|with|except)\b/.test(l)) out.push("Line " + (k + 1) + ": block statement may be missing a trailing ':'");
    });
    if (tabs && spaces) out.push("Mixed tabs and spaces for indentation (Python raises TabError / IndentationError).");
    return out;
  }
  function htmlTags(code) {
    const out = [], st = [], VOID = new Set(["br", "img", "hr", "input", "meta", "link", "area", "base", "col", "embed", "source", "track", "wbr"]);
    const re = /<(\/?)([a-zA-Z][a-zA-Z0-9-]*)([^>]*?)(\/?)>/g;
    let m;
    const body = code.replace(/<!--[\s\S]*?-->/g, "").replace(/<(script|style)[\s\S]*?<\/\1>/gi, (x) => x.slice(0, x.indexOf(">") + 1) + "</" + /^<(\w+)/.exec(x)[1] + ">");
    while ((m = re.exec(body))) {
      const tag = m[2].toLowerCase();
      if (VOID.has(tag) || m[4]) { if (tag === "img" && !/\balt\s*=/.test(m[3])) out.push("<img> without alt text (accessibility)."); continue; }
      if (m[1]) { const top = st.pop(); if (top !== tag) out.push("</" + tag + "> does not match open <" + (top || "nothing") + ">."); }
      else st.push(tag);
    }
    st.forEach((t) => out.push("<" + t + "> is never closed."));
    return out;
  }
  /* rule table: [language(s), regex, message, severity] */
  const RULES = [
    ["javascript typescript", /[^=!<>]==[^=]/, "Loose equality (==): prefer === unless you intend type coercion.", "warn"],
    ["javascript typescript", /\bvar\s+\w/, "var is function-scoped; prefer let/const.", "info"],
    ["javascript typescript", /\beval\s*\(/, "eval() found: avoid; it executes arbitrary strings.", "high"],
    ["javascript typescript", /innerHTML\s*=/, "innerHTML assignment: sanitize or use textContent for user input.", "warn"],
    ["javascript typescript", /\bdocument\.write\s*\(/, "document.write is unsafe and blocks parsing.", "warn"],
    ["javascript typescript", /\bparseInt\s*\([^,)]*\)/, "parseInt without a radix; pass 10 explicitly.", "info"],
    ["javascript typescript", /catch\s*\([^)]*\)\s*\{\s*\}/, "Empty catch block silently swallows errors.", "warn"],
    ["javascript typescript", /\bif\s*\([^=!<>)]*[^=!<>]=[^=][^)]*\)/, "Assignment (=) inside an if condition; did you mean ==/===?", "warn"],
    ["javascript typescript", /\bfor\s*\(\s*(?:var|let)?\s*\w+\s+in\s+\w+\s*\)/, "for...in iterates keys (and inherited props); use for...of for arrays.", "info"],
    ["javascript typescript", /\.then\([^)]*\)(?![\s\S]*\.catch)/, "Promise chain without .catch: rejections go unhandled.", "info"],
    ["typescript", /:\s*any\b/, "Explicit 'any' disables type checking.", "info"],
    ["python", /def\s+\w+\([^)]*=\s*(\[\]|\{\}|set\(\))/, "Mutable default argument is shared across calls; use None and create inside.", "high"],
    ["python", /except\s*:/, "Bare except catches KeyboardInterrupt/SystemExit; catch specific exceptions.", "warn"],
    ["python", /[=!]=\s*None\b/, "Compare to None with 'is' / 'is not'.", "info"],
    ["python", /\b(eval|exec)\s*\(/, "eval/exec on dynamic strings is dangerous.", "high"],
    ["python", /\bos\.system\s*\(|subprocess\.[a-z]+\([^)]*shell\s*=\s*True/, "Shell command execution: validate input; avoid shell=True.", "high"],
    ["python", /\bopen\([^)]*\)(?![\s\S]*\.close\(\))(?<!with\s)/, "open() without 'with' may leak the file handle.", "info"],
    ["c cpp", /\bgets\s*\(/, "gets() is unsafe (no bounds); use fgets().", "high"],
    ["c cpp", /\b(strcpy|strcat|sprintf)\s*\(/, "Unbounded string function; use snprintf/strncpy-style bounded calls.", "warn"],
    ["c cpp", /scanf\s*\(\s*"[^"]*%s/, "scanf %s without a width can overflow the buffer.", "high"],
    ["c cpp", /\bmalloc\s*\(/, "malloc: check for NULL and make sure every path calls free().", "info"],
    ["c cpp", /\bif\s*\([^=!<>)]*[^=!<>]=[^=][^)]*\)/, "Assignment inside if condition.", "warn"],
    ["cpp", /using\s+namespace\s+std\s*;/, "'using namespace std' in headers pollutes the global namespace.", "info"],
    ["cpp", /\bnew\s+\w+(?![\s\S]*\bdelete\b)/, "Raw new without delete: prefer std::unique_ptr / make_unique.", "warn"],
    ["java", /\w+\s*==\s*"/, "String compared with ==; use .equals().", "high"],
    ["java kotlin csharp", /catch\s*\([^)]*\)\s*\{\s*\}/, "Empty catch block hides failures.", "warn"],
    ["java", /System\.exit\s*\(/, "System.exit in library code kills the whole JVM.", "info"],
    ["kotlin", /!!/, "!! throws NullPointerException; prefer safe calls (?.) or ?:.", "warn"],
    ["kotlin", /\bGlobalScope\b/, "GlobalScope leaks coroutines; use a lifecycle-bound scope.", "warn"],
    ["csharp", /async\s+void\s+(?!On|Handle)/, "async void: exceptions cannot be awaited; return Task.", "warn"],
    ["csharp", /\.Result\b|\.Wait\(\)/, "Blocking on a Task can deadlock; use await.", "warn"],
    ["csharp", /void\s+Update\s*\([\s\S]*?(GetComponent\s*<|GameObject\.Find|FindObjectOfType|Camera\.main)/, "Unity: expensive lookup inside Update(); cache the reference in Awake/Start.", "warn"],
    ["csharp", /void\s+Update\s*\([\s\S]*?\bnew\s+\w+/, "Unity: allocating in Update() creates GC pressure.", "info"],
    ["sql", /(SELECT|WHERE)[^;]*['"]\s*\+\s*\w+|\$\{[^}]+\}|"\s*&\s*\w+/i, "SQL built by string concatenation: use parameterised queries.", "high"],
    ["sql", /\b(DELETE\s+FROM|UPDATE)\s+\w+(?![\s\S]*\bWHERE\b)[^;]*;/i, "DELETE/UPDATE without WHERE affects every row.", "high"],
    ["sql", /SELECT\s+\*/i, "SELECT * fetches unneeded columns; list the columns.", "info"],
    ["bash", /\brm\s+-rf?\s+\$/, "rm -r on an unquoted variable can delete the wrong path.", "high"],
    ["bash", /\beval\b/, "eval on strings is dangerous.", "high"],
    ["bash", /(?<!")\$[A-Za-z_]\w*(?!")(?=\s|$)/, "Unquoted variable expansion; quote as \"$var\" to avoid word splitting.", "info"],
    ["html", /\son\w+\s*=/i, "Inline event handler attribute; prefer addEventListener (and a strict CSP).", "info"],
    ["css", /!important/, "!important makes overrides hard; fix specificity instead.", "info"],
  ];
  /* Loop-nesting depth and recursion count → rough complexity. HEURISTIC, shown as an estimate only. */
  function complexity(code, lang) {
    const lines = code.split("\n");
    let depth = 0, maxDepth = 0;
    const stack = [];
    lines.forEach((l) => {
      const opens = /\b(for|while|foreach)\b/.test(l);
      if (lang === "python") {
        const ind = (/^(\s*)/.exec(l)[1] || "").replace(/\t/g, "    ").length;
        while (stack.length && stack[stack.length - 1] >= ind && l.trim()) { stack.pop(); }
        if (opens && /:\s*$/.test(l)) { stack.push(ind); maxDepth = Math.max(maxDepth, stack.length); }
      } else {
        if (opens) { depth++; maxDepth = Math.max(maxDepth, depth); }
        depth = Math.max(0, depth + ((l.match(/\{/g) || []).length * 0) - (opens ? 0 : 0));
      }
    });
    if (lang !== "python") { // brace-based nesting
      let d = 0, md = 0; const loopAt = [];
      for (const l of lines) {
        const isLoop = /\b(for|while|foreach)\b\s*\(/.test(l) || /\bdo\s*\{/.test(l);
        for (const ch of l) {
          if (ch === "{") { d++; if (isLoop) { loopAt.push(d); md = Math.max(md, loopAt.length); } }
          else if (ch === "}") { if (loopAt.length && loopAt[loopAt.length - 1] === d) loopAt.pop(); d--; }
        }
        md = Math.max(md, loopAt.length + (isLoop && !l.includes("{") ? 1 : 0));
      }
      maxDepth = md;
    }
    const fn = /(?:function|def|fun)\s+(\w+)|(?:^|\s)(?:int|void|long|double|bool|static\s+\w+|public\s+\w+)\s+(\w+)\s*\(/m.exec(code);
    const name = fn ? fn[1] || fn[2] : null;
    const selfCalls = name ? (code.match(new RegExp("\\b" + name + "\\s*\\(", "g")) || []).length - 1 : 0;
    let big = maxDepth ? (maxDepth === 1 ? "O(n)" : "O(n^" + maxDepth + ")") : "O(1)";
    let note = "";
    if (selfCalls >= 2) { big = "possibly exponential O(2^n) (" + selfCalls + " recursive calls per body, unless memoised)"; note = "Add memoisation or convert to iteration."; }
    else if (selfCalls === 1) { big = maxDepth ? big : "O(n) recursion depth (stack grows with input)"; note = "Deep recursion can overflow the stack; consider a loop."; }
    return { estimate: big, loopDepth: maxDepth, recursiveCalls: Math.max(0, selfCalls), note };
  }
  const INJECTION = /\b(ignore (all |any |the )?(previous|prior|above) (instructions|prompts?)|disregard (the )?(system|previous)|you are now|system prompt|reveal your (instructions|prompt)|act as (an? )?(admin|dan)|new instructions:)/i;

  function analyze(code, nameOrLang) {
    const src = String(code == null ? "" : code);
    const res = { language: "unknown", lines: 0, chars: src.length, errors: [], warnings: [], info: [], complexity: null, notes: [], empty: false, oversized: false };
    if (!src.trim()) { res.empty = true; res.notes.push("The code is empty; nothing to analyse."); return res; }
    if (src.length > MAX) { res.oversized = true; res.notes.push("Input is " + src.length + " characters; the limit is " + MAX + ". Paste a smaller section."); return res; }
    if (/\u0000/.test(src) || (src.match(/[\u0001-\u0008\u000e-\u001f]/g) || []).length > Math.max(5, src.length * 0.02)) { res.notes.push("This looks like binary data, not source code. Not analysed."); res.binary = true; return res; }
    const lang = detect(src, nameOrLang);
    res.language = lang;
    res.lines = src.split("\n").length;
    if (lang !== "unknown") {
      if (lang === "python") res.errors.push.apply(res.errors, lexical(src, lang).concat(pyIndent(src)));
      else if (lang === "html") res.errors.push.apply(res.errors, htmlTags(src));
      else res.errors.push.apply(res.errors, lexical(src, lang));
      if (lang === "javascript" && !res.errors.length) { const p = jsParse(src); if (p) res.parse = p; if (p && /error/.test(p)) res.errors.push(p); }
      RULES.forEach(([langs, re, msg, sev]) => {
        if (!langs.split(" ").includes(lang)) return;
        let probe = src;
        if (lang !== "python" && lang !== "bash") probe = src.replace(/\/\/[^\n]*|\/\*[\s\S]*?\*\//g, "");
        if (re.test(probe)) (sev === "high" ? res.errors : sev === "warn" ? res.warnings : res.info).push((sev === "high" ? "Risk: " : "") + msg);
      });
      if (!["html", "css", "sql", "bash", "unknown"].includes(lang)) res.complexity = complexity(src, lang);
    } else res.notes.push("Language not recognised; only generic checks ran.");
    if (INJECTION.test(src)) res.notes.push("The code contains text addressed to an AI (e.g. 'ignore previous instructions'). EDO treats code and comments as data and does not follow it.");
    return res;
  }
  /* Old string API (tests and UI): readable report. */
  function check(code, name) {
    const r = analyze(code, name);
    const out = ["File/snippet: " + (name || "snippet"), "Language: " + r.language, "Lines: " + r.lines, "Characters: " + r.chars];
    r.notes.forEach((n) => out.push(n));
    r.errors.forEach((e) => out.push(e));
    if (r.parse && !r.errors.includes(r.parse)) out.push(r.parse);
    else if (!r.parse && !r.empty && !r.oversized && !r.binary && r.language !== "unknown") out.push("No syntax parser available for " + r.language + " in the browser: lexical checks only (brackets, strings, comments). Not compiled, not executed.");
    r.warnings.forEach((w) => out.push("Warning: " + w));
    r.info.forEach((w) => out.push("Note: " + w));
    if (r.complexity) out.push("Complexity estimate (heuristic): " + r.complexity.estimate + (r.complexity.note ? ". " + r.complexity.note : ""));
    return out.join("\n");
  }
  function brackets(code) { return lexical(String(code), "javascript"); }
  root.CodeAnalyzer = { check, analyze, detect, brackets, complexity, lexical, MAX };
})();
