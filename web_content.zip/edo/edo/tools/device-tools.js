/* Registers EDO's device and web capabilities as tools in the registry. Each tool declares its contract and reports success only when the
   native layer (or the search provider) actually says so. When the bridge is absent the tool is "unavailable" or, for links, "unverified". 
   Nothing here bypasses Android: permissions are checked first and sensitive actions are gated by the registry's confirmation rule.
   Not exercised on a real device in this repository: the bridge is simulated in tests. Globals: window.DeviceTools */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;

  function install(reg, deps) {
    deps = deps || {};
    const B = () => deps.bridge || root.Bridge;
    const hasBridge = () => !!(B() && B().available());
    const needBridge = () => (hasBridge() ? { ok: true } : { ok: false, reason: "needs the Android app (no native bridge in this browser)" });
    const call = async (m, a, o) => { const raw = await B().call(m, a, o); try { return typeof raw === "string" ? JSON.parse(raw) : raw; } catch (e) { return {}; } };
    const err = (e) => ({ ok: false, code: (e && e.code) || "failed", message: (e && e.message) || String(e), retryable: !!(e && e.code === "timeout") });
    const open = deps.openWindow || ((u) => { if (typeof root.open !== "function") throw Error("no browser window available"); const w = root.open(u, "_blank", "noopener,noreferrer"); return !!w; });
    const NAME = /^[\w .&+\-']{1,40}$/;

    reg.register({ name: "open_app", description: "Open an installed app by name (e.g. YouTube, WhatsApp).", args: { name: { type: "string", required: true, max: 40, pattern: NAME } },
      permissions: [], risk: "low", timeoutMs: 10000, supportsCancellation: false, result: { opened: { type: "string", required: true } },
      run: async (a) => {
        if (hasBridge()) { try { const j = await call("openApp", { name: a.name }); return j && j.opened ? { ok: true, data: { opened: String(j.opened) } } : { ok: false, code: "not_found", message: "No installed app matched \"" + a.name + "\"." }; } catch (e) { return err(e); } }
        const app = root.Device && root.Device.appFor(a.name);
        if (!app) return { ok: false, code: "unavailable", message: "Without the Android app I only know a few web links, and \"" + a.name + "\" is not one of them." };
        try { return open(app[5] || "https://play.google.com/store/apps/details?id=" + app[1]) ? { ok: true, verified: false, data: { opened: app[4] }, note: "Opened a web link; Android decides whether the app takes it over." } : { ok: false, code: "blocked", message: "The browser blocked the link." }; } catch (e) { return err(e); }
      } });

    reg.register({ name: "open_url", description: "Open an https web page (for example a YouTube or Google search results page).", args: { url: { type: "string", required: true, max: 1800 } },
      permissions: [], risk: "low", timeoutMs: 8000, supportsCancellation: false, result: { url: { type: "string", required: true } },
      run: async (a) => {
        const s = root.Safety.safeUrl(a.url); if (!s.ok) return { ok: false, code: "invalid_arguments", message: "Refused URL: " + s.reason };
        try { return open(s.url) ? { ok: true, verified: false, data: { url: s.url }, note: "Link opened; I cannot see what the page shows." } : { ok: false, code: "blocked", message: "The browser blocked the link." }; } catch (e) { return err(e); }
      } });

    reg.register({ name: "create_reminder", description: "Schedule a local notification reminder at an exact future time.", args: { title: { type: "string", required: true, max: 120, min: 1 }, at: { type: "integer", required: true, min: 1 } },
      permissions: ["notifications"], risk: "low", timeoutMs: 8000, supportsCancellation: false, available: needBridge, result: { scheduledFor: { type: "number", required: true } },
      confirmText: (a) => "Set reminder \"" + a.title + "\" for " + new Date(a.at).toLocaleString() + "?",
      run: async (a) => {
        if (a.at < Date.now() + 5000) return { ok: false, code: "invalid_arguments", message: "That time is already in the past." };
        try { const j = await call("scheduleReminder", { id: (a.at % 2000000000) | 0 || 1, title: "EDO reminder", text: a.title, at: a.at }); return j && j.scheduledFor === a.at ? { ok: true, data: { scheduledFor: j.scheduledFor }, note: "Inexact alarm: it can fire a little late and is lost if the phone restarts." } : { ok: false, code: "native_error", message: "The phone did not confirm the reminder." }; } catch (e) { return err(e); }
      } });

    reg.register({ name: "call_number", description: "Call a phone number. Always needs the user's confirmation; emergency numbers only open the dialer.", args: { number: { type: "string", required: true, max: 20, pattern: /^\+?[\d\s().-]{3,20}$/ } },
      permissions: [], risk: "high", timeoutMs: 15000, supportsCancellation: false, available: needBridge, result: { mode: { type: "string", required: true } },
      confirmText: (a) => "Call " + a.number + "?",
      run: async (a) => { const n = root.Device && root.Device.asNumber(a.number); if (!n) return { ok: false, code: "invalid_arguments", message: "That is not a phone number." }; try { const j = await call("call", { number: n, confirmed: true }); return j && (j.mode === "call" || j.mode === "dial") ? { ok: true, verified: j.mode === "call", data: { mode: j.mode }, note: j.mode === "dial" ? "Dialer opened; you still need to press call." : undefined } : { ok: false, code: "native_error", message: "The phone did not start the call." }; } catch (e) { return err(e); } } });

    reg.register({ name: "battery_status", description: "Read the battery level and whether it is charging.", args: {}, permissions: [], risk: "low", timeoutMs: 4000, supportsCancellation: false, available: needBridge, result: { percent: { type: "number" }, charging: { type: "boolean", required: true } },
      run: async () => { try { const j = await call("batteryStatus", {}); return typeof j.charging === "boolean" ? { ok: true, data: { percent: typeof j.percent === "number" ? j.percent : undefined, charging: j.charging } } : { ok: false, code: "native_error", message: "No battery data returned." }; } catch (e) { return err(e); } } });

    reg.register({ name: "network_status", description: "Read whether the phone is online and the connection type.", args: {}, permissions: [], risk: "low", timeoutMs: 4000, supportsCancellation: false, available: needBridge, result: { online: { type: "boolean", required: true } },
      run: async () => { try { const j = await call("networkStatus", {}); return typeof j.online === "boolean" ? { ok: true, data: Object.assign({ online: j.online }, typeof j.type === "string" ? { type: j.type } : {}) } : { ok: false, code: "native_error", message: "No network data returned." }; } catch (e) { return err(e); } } });

    reg.register({ name: "clipboard_write", description: "Put text on the clipboard.", args: { text: { type: "string", required: true, max: 5000 } }, permissions: [], risk: "medium", timeoutMs: 4000, supportsCancellation: false, available: needBridge, result: { written: { type: "boolean", required: true } },
      confirmText: () => "Copy this text to the clipboard?",
      run: async (a) => { try { await call("clipboardWrite", { text: a.text }); return { ok: true, data: { written: true } }; } catch (e) { return err(e); } } });

    reg.register({ name: "clipboard_read", description: "Read the clipboard text. Disabled unless the user allowed it in settings.", args: {}, permissions: ["clipboard_read"], risk: "medium", timeoutMs: 4000, supportsCancellation: false, available: needBridge, result: { text: { type: "string", required: true } },
      confirmText: () => "Let EDO read your clipboard once?",
      run: async () => { try { const j = await call("clipboardRead", {}); return typeof j.text === "string" ? { ok: true, data: { text: j.text.slice(0, 5000) } } : { ok: false, code: "native_error", message: "Clipboard returned nothing." }; } catch (e) { return err(e); } } });

    reg.register({ name: "share_text", description: "Open the Android share sheet with some text; the user picks where it goes.", args: { text: { type: "string", required: true, max: 5000 } }, permissions: [], risk: "low", timeoutMs: 8000, supportsCancellation: false, available: needBridge, result: { shown: { type: "boolean", required: true } },
      run: async (a) => { try { await call("share", { text: a.text, title: "Share" }); return { ok: true, verified: false, data: { shown: true }, note: "Share sheet shown; nothing is sent until you choose an app." }; } catch (e) { return err(e); } } });

    reg.register({ name: "web_search", description: "Search the web through the configured search provider. Returns titled results with source URLs.", args: { query: { type: "string", required: true, max: 300, min: 2 } }, permissions: [], risk: "low", timeoutMs: 20000, supportsCancellation: true,
      available: () => (root.WebSearch && root.WebSearch.configured() ? { ok: true } : { ok: false, reason: "no search provider configured" }), result: { results: { type: "array", required: true }, citations: { type: "array", required: true } },
      run: async (a) => { const r = await root.WebSearch.search(a.query); return r.ok ? { ok: true, data: { results: r.results, citations: r.citations, provider: r.provider } } : { ok: false, code: "search_failed", message: r.error || "search failed", retryable: r.performed === true }; } });
    return reg.describe().map((d) => d.name);
  }
  root.DeviceTools = { install };
})();
