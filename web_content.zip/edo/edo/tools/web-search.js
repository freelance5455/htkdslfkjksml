/* EDO web search behind a provider interface. The reasoning core never talks to a network.
   Classes: SearchResult, Citation, SearchCache, WebSearchProvider (base). Register a real provider with
   WebSearch.setProvider(new MyProvider(...)). With no provider EDO says no search was performed and invents nothing. */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;

  function safeUrl(u) {
    try { const x = new URL(String(u)); return /^https?:$/.test(x.protocol) ? x.href : null; } catch (e) { return null; }
  }
  class SearchResult {
    constructor(o) { o = o || {}; this.title = String(o.title || "").slice(0, 300); this.url = safeUrl(o.url); this.snippet = String(o.snippet || "").slice(0, 1000); this.rank = o.rank | 0; }
    valid() { return !!this.url && !!this.title; }
  }
  class Citation {
    constructor(result, index, provider, retrievedAt) { this.index = index; this.title = result.title; this.url = result.url; this.provider = provider; this.retrievedAt = retrievedAt; }
    toString() { return "[" + this.index + "] " + this.title + " — " + this.url; }
  }
  class SearchCache {
    constructor(opts) { opts = opts || {}; this.ttl = opts.ttlMs || 300000; this.max = opts.max || 50; this.now = opts.now || (() => Date.now()); this.m = new Map(); }
    key(q) { return String(q).toLowerCase().replace(/\s+/g, " ").trim(); }
    get(q) { const k = this.key(q), e = this.m.get(k); if (!e) return null; if (this.now() - e.t > this.ttl) { this.m.delete(k); return null; } return e.v; }
    set(q, v) { const k = this.key(q); this.m.delete(k); this.m.set(k, { t: this.now(), v }); while (this.m.size > this.max) this.m.delete(this.m.keys().next().value); }
    clear() { this.m.clear(); }
    get size() { return this.m.size; }
  }
  /* Subclass and implement search(query, opts) → Promise<Array<{title,url,snippet}>>. */
  class WebSearchProvider {
    constructor(name) { this.name = name || "provider"; }
    async search() { throw Error("WebSearchProvider.search() is not implemented"); }
  }
  /* Convenience: provider backed by an https endpoint that returns {results:[{title,url,snippet}]}. */
  class HttpSearchProvider extends WebSearchProvider {
    constructor(endpoint, fetchImpl) { super("http:" + endpoint); this.endpoint = endpoint; this.f = fetchImpl || (typeof fetch !== "undefined" ? fetch.bind(root) : null); }
    async search(q) {
      if (!this.f) throw Error("fetch is unavailable");
      const r = await this.f(this.endpoint + (this.endpoint.includes("?") ? "&" : "?") + "q=" + encodeURIComponent(q));
      if (!r.ok) throw Error("search endpoint returned HTTP " + r.status);
      const j = await r.json();
      return Array.isArray(j.results) ? j.results : [];
    }
  }

  let provider = null;
  const cache = new SearchCache();
  const clean = (text) => String(text).replace(/^\s*(search|look up|google)\s*(for)?\s*/i, "").trim() || String(text).trim();

  function setProvider(p) { if (p && typeof p.search !== "function") throw Error("provider needs a search() method"); provider = p || null; cache.clear(); }
  function configured() { return !!provider; }

  async function search(query, opts) {
    const q = String(query || "").trim();
    if (!q) return { ok: false, performed: false, error: "empty query", results: [], citations: [] };
    if (!provider) return { ok: false, performed: false, error: "no search provider configured", results: [], citations: [] };
    const hit = cache.get(q);
    if (hit) return Object.assign({}, hit, { cached: true });
    try {
      const raw = await provider.search(q, opts || {});
      const when = new Date().toISOString();
      const results = (Array.isArray(raw) ? raw : []).map((x, i) => new SearchResult(Object.assign({ rank: i + 1 }, x))).filter((r) => r.valid()).slice(0, 10);
      const citations = results.map((r, i) => new Citation(r, i + 1, provider.name, when));
      const out = { ok: true, performed: true, query: q, provider: provider.name, retrievedAt: when, results, citations };
      cache.set(q, out);
      return out;
    } catch (e) { return { ok: false, performed: true, error: e.message, results: [], citations: [] }; }
  }
  function format(res) {
    if (!res.performed) return "No search was performed: " + res.error + ".";
    if (!res.ok) return "The search failed (" + res.error + "). I have no results to show or cite.";
    if (!res.results.length) return "The provider returned no usable results for \"" + res.query + "\". Nothing is cited.";
    return "**Searched information** (from " + res.provider + ", retrieved " + res.retrievedAt + "):\n" +
      res.results.map((r, i) => (i + 1) + ". " + r.title + (r.snippet ? " — " + r.snippet : "") + " [" + res.citations[i].index + "]").join("\n") +
      "\n\n**Sources**\n" + res.citations.map((c) => c.toString()).join("\n") +
      "\n\n_Everything above is quoted from the provider. Any conclusion I draw from it is my own reasoning and is not verified by the sources._";
  }
  /* Synchronous planner kept for EDO.handle(). With a provider it hands back run() so the UI can await it. */
  function plan(text) {
    const q = clean(text);
    if (!provider) {
      return { kind: "search", text: "No search was performed: web search is not configured on this device, so I have no snippets or citations to show.\nQuery: " + q + "\n[[G:" + q + "]]",
        meta: "No network search was performed by EDO.", query: q, configured: false };
    }
    return { kind: "search", text: "Searching with " + provider.name + " for: " + q, meta: "Provider search pending.", query: q, configured: true,
      run: async () => { const r = await search(q); return { text: format(r), meta: r.ok ? "Results come from " + provider.name + ". Not verified by EDO." : "Search did not return results.", results: r.results, citations: r.citations }; } };
  }
  root.WebSearch = { plan, search, format, setProvider, configured, cache, SearchResult, Citation, SearchCache, WebSearchProvider, HttpSearchProvider };
})();
