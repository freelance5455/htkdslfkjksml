/* EDO device actions: open apps, place calls, enable permissions.
   Two paths, chosen at run time:
   - native: window.EDOAndroid bridge (android/EdoBridge.kt). Lists real installed apps, reads contacts,
     places calls directly once CALL_PHONE is granted.
   - web: tel: links and app deep links. Works in a plain browser or a web wrapper only as far as the host
     allows it, and cannot be confirmed from inside the page.
   Parsing is pure and tested in Node. Calls always need an explicit tap on a confirmation card.
   Globals: window.Device */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;

  const PLAY = (pkg) => "https://play.google.com/store/apps/details?id=" + pkg;
  /* [aliases..., package, kind, host/path or scheme, label, website]. kind "https" = app link, "scheme" = custom scheme */
  const APPS = [
    [["whatsapp", "whats app", "wa"], "com.whatsapp", "https", "wa.me/", "WhatsApp", "https://web.whatsapp.com"],
    [["youtube", "yt", "you tube"], "com.google.android.youtube", "https", "www.youtube.com/", "YouTube", "https://www.youtube.com"],
    [["instagram", "insta", "ig"], "com.instagram.android", "https", "www.instagram.com/", "Instagram", "https://www.instagram.com"],
    [["telegram"], "org.telegram.messenger", "https", "t.me/", "Telegram", "https://web.telegram.org"],
    [["facebook", "fb"], "com.facebook.katana", "https", "www.facebook.com/", "Facebook", "https://www.facebook.com"],
    [["x", "twitter"], "com.twitter.android", "https", "x.com/", "X", "https://x.com"],
    [["spotify"], "com.spotify.music", "https", "open.spotify.com/", "Spotify", "https://open.spotify.com"],
    [["reddit"], "com.reddit.frontpage", "https", "www.reddit.com/", "Reddit", "https://www.reddit.com"],
    [["linkedin"], "com.linkedin.android", "https", "www.linkedin.com/", "LinkedIn", "https://www.linkedin.com"],
    [["maps", "google maps", "map"], "com.google.android.apps.maps", "https", "www.google.com/maps", "Google Maps", "https://maps.google.com"],
    [["chrome", "browser"], "com.android.chrome", "https", "www.google.com/", "Chrome", "https://www.google.com"],
    [["play store", "playstore", "google play"], "com.android.vending", "https", "play.google.com/store", "Play Store", "https://play.google.com/store"],
    [["phonepe", "phone pe"], "com.phonepe.app", "scheme", "phonepe", "PhonePe", PLAY("com.phonepe.app")],
    [["paytm"], "net.one97.paytm", "scheme", "paytmmp", "Paytm", PLAY("net.one97.paytm")],
    [["gpay", "google pay", "g pay"], "com.google.android.apps.nbu.paisa.user", "scheme", "tez", "Google Pay", PLAY("com.google.android.apps.nbu.paisa.user")],
    [["gmail", "mail", "email"], null, "uri", "mailto:", "Email", null],
  ];
  const EMERGENCY = /^(100|101|102|108|112|911|999|000)$/;

  const PREFIX = "(?:please\\s+|hey\\s+edo[,:]?\\s*|can you\\s+|could you\\s+|would you\\s+|go ahead and\\s+|i want you to\\s+|i want to\\s+|i need to\\s+)*";
  const CALL = new RegExp("^\\s*" + PREFIX + "(?:call|dial|phone|ring)\\s+(?:up\\s+)?(.+?)\\s*(?:now|please|for me)?\\s*[.!?]*\\s*$", "i");
  const OPEN = new RegExp("^\\s*" + PREFIX + "(?:open|launch|start up)\\s+(?:the\\s+)?(?:my\\s+)?(?:app\\s+)?(.+?)(?:\\s+app)?\\s*(?:now|please|for me)?\\s*[.!?]*\\s*$", "i");
  const ENABLE = /\b(enable|allow|grant|turn on|activate|set ?up)\b[^.?!]*\b(permissions?|calling|calls|phone access|device access|contacts|app access|everything)\b/i;
  const NOT_APP = /\b(is|are|was|were|am|be|been|how|why|what|when|where|who|which|a|an|the|this|that|it|file|source|ended|question|issue|ticket|account|mind|loop|door)\b/i;
const NOT_PERSON = /^(?:a|an|it|its|this|that|these|those)\b|\b(?:function|method|api|class|endpoint|callback|recursively|variable|library|constructor|script|module|handler)\b/i;

  function digitsOnly(s) {
    return String(s).replace(/[\s().-]/g, "");
  }
  function asNumber(target) {
    const d = digitsOnly(target);
    return /^\+?\d{3,15}$/.test(d) ? d : null;
  }
  function appFor(name) {
    const q = String(name).toLowerCase().replace(/\s+/g, " ").trim();
    return APPS.find((a) => a[0].includes(q)) || null;
  }

  /* text -> command or null. Never touches the device. */
  function parse(text) {
    const t = String(text || "").trim();
    if (!t || t.length > 120) return null;
    if (ENABLE.test(t) && t.split(/\s+/).length <= 14) return { type: "enable" };
    const c = CALL.exec(t);
    if (c) {
      let target = c[1].replace(/^my\s+/i, "").replace(/\s+on\s+(?:phone|mobile)$/i, "").trim();
      if (!target || target.split(/\s+/).length > 4) return null;
      const num = asNumber(target);
      if (num) return { type: "call", number: num, label: num, emergency: EMERGENCY.test(num) };
      if (/\d/.test(target)) return null; // looks like maths or junk, not a contact
      if (/^(?:me|you|it|that|this|back|out|off|on)$/i.test(target) || NOT_PERSON.test(target)) return null;
      return { type: "call", name: target };
    }
    const o = OPEN.exec(t);
    if (o) {
      const name = o[1].trim();
      if (!name || name.split(/\s+/).length > 3 || NOT_APP.test(name)) return null;
      return { type: "open", name };
    }
    return null;
  }

  /* ---------- web fallbacks ---------- */
  function intentUrl(app) {
    const [, pkg, kind, where, , web] = app;
    const fb = ";S.browser_fallback_url=" + encodeURIComponent(web || PLAY(pkg));
    if (kind === "https") return "intent://" + where + "#Intent;scheme=https;package=" + pkg + fb + ";end";
    if (kind === "scheme") return "intent://#Intent;scheme=" + where + ";package=" + pkg + fb + ";end";
    return where;
  }
  function navigate(url) {
    if (typeof root.location === "undefined") throw Error("No browser to navigate");
    root.location.href = url;
  }

  /* ---------- execution (browser only; each returns {text, meta}) ---------- */
  async function openApp(name) {
    const bridge = root.Bridge && root.Bridge.available();
    if (bridge) {
      try {
        const raw = await root.Bridge.call("openApp", { name });
        const j = JSON.parse(raw);
        return { text: "Opening **" + (j.opened || name) + "**.", meta: "Native bridge · launched an installed app." };
      } catch (e) {
        const known = appFor(name);
        if (!known) return { text: "I couldn't find an installed app called \"" + name + "\". " + e.message.replace(/^Error:\s*/, ""), meta: "Native bridge · nothing launched." };
      }
    }
    const app = appFor(name);
    if (!app) {
      return {
        text: bridge
          ? "I couldn't launch \"" + name + "\"."
          : "I can't open \"" + name + "\" from here: this build has no native bridge, and I only know web links for a few popular apps (WhatsApp, YouTube, Instagram, Telegram, Maps, Chrome, PhonePe and similar). To open any installed app by name, use the native Android build (see README).",
        meta: bridge ? "Native bridge · nothing launched." : "Web fallback · app not in the known list.",
      };
    }
    try {
      navigate(intentUrl(app));
    } catch (e) {
      return { text: "I couldn't start that: " + e.message, meta: "Web fallback" };
    }
    return {
      text: "Trying to open **" + app[4] + "**. If nothing happens, your browser or wrapper may be blocking app links; the native build opens apps reliably.",
      meta: "Web fallback · app link. Android decides whether it opens, so I can't confirm it did.",
    };
  }

  async function findContacts(name) {
    if (!(root.Bridge && root.Bridge.available())) return { unavailable: true, matches: [] };
    const raw = await root.Bridge.call("findContact", { query: name });
    const j = JSON.parse(raw);
    return { matches: (j.matches || []).filter((m) => m.number) };
  }

  async function placeCall(number) {
    const n = asNumber(number);
    if (!n) throw Error("That doesn't look like a phone number.");
    if (root.Bridge && root.Bridge.available()) {
      const j = JSON.parse(await root.Bridge.call("call", { number: n, confirmed: true }));
      if (j.mode === "call") return { text: "Calling " + n + " now.", meta: "Native bridge · direct call (permission granted)." };
      return {
        text: "Opened the dialer with " + n + ". Tap the green button to call." + (j.permissionNeeded ? "\n\nTo let me place calls directly, tap **Enable device access** in the panel." : ""),
        meta: "Native bridge · " + (EMERGENCY.test(n) ? "emergency numbers always open the dialer." : "dialer opened."),
      };
    }
    navigate("tel:" + n);
    return { text: "Opened your dialer with " + n + ". Tap the green button to call.", meta: "Web fallback · tel: link. Browsers can't place a call without your tap." };
  }

  async function enable() {
    if (!(root.Bridge && root.Bridge.available())) {
      return {
        text: "This version of EDO is running as a web page or inside a wrapper, so I can't switch on Android permissions from here. Here's what works anyway:\n- **Calling**: I open your dialer with the number filled in; you tap call.\n- **Popular apps**: I try their app links.\n\nFor direct calls, contact lookup and launching any installed app, build the native Android project (see README). Then **Enable device access** will ask for Phone, Contacts, Microphone, Location and Notifications permissions.",
        meta: "No native bridge detected.",
      };
    }
    const j = JSON.parse(await root.Bridge.call("requestPermissions", {}));
    const asked = (j.requested || []).length;
    return {
      text: asked
        ? "I've asked Android for " + asked + " permission" + (asked > 1 ? "s" : "") + ". Approve the prompts, then check the panel to see what's enabled. You can change any of them later in Android Settings."
        : "All device permissions are already granted. Calling, contacts, microphone, location and notifications are ready.",
      meta: "Native bridge · permissions are always your choice.",
      status: j,
    };
  }

  async function permissions() {
    if (!(root.Bridge && root.Bridge.available())) return null;
    return JSON.parse(await root.Bridge.call("permissions", {}));
  }

  /* Turn a bridge failure into a message that says what happened and what the user can do. Never claims success. */
  function describeError(e) {
    const code = e && e.code, msg = String((e && e.message) || e || "unknown error").replace(/^Error:\s*/, "");
    if (code === "unavailable") return "The native Android layer is not present, so I can't do that here. In a browser I can only open the dialer or app links.";
    if (code === "timeout") return "The phone did not answer in time (" + msg + "). Nothing was done. You can try again.";
    if (code === "permission_denied") return "Android has not given EDO that permission yet (" + msg + "). Tap Enable device access in the panel, approve the prompt, then ask again.";
    if (code === "unsupported") return "This build of the native layer doesn't support that action (" + msg + ").";
    if (code === "not_found") return "Nothing matched (" + msg + ").";
    return "The device action failed: " + msg + ". Nothing was done.";
  }
  root.Device = { describeError, parse, appFor, asNumber, openApp, findContacts, placeCall, enable, permissions, APPS };
})();
