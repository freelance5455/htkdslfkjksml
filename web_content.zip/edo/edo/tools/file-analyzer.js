/* File analyzer. Inspects pasted text; does not read the device filesystem. */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  function analyzeText(text) {
    const body = String(text).replace(/^[\s\S]*?analy[sz]e (this )?file[:\s]*/i, "");
    const lines = body.split(/\n/);
    const bytes = body.length;
    const empty = lines.filter((l) => !l.trim()).length;
    const long = lines.filter((l) => l.length > 120).length;
    return {
      kind: "file",
      text: "**File analysis** (pasted text only)\nLines: " + lines.length + "\nCharacters: " + bytes + "\nBlank lines: " + empty + "\nLong lines (>120): " + long + "\nNo filesystem was opened.",
      meta: "Local inspection of the message. Not a virus scan.",
    };
  }
  root.FileAnalyzer = { analyzeText };
})();
