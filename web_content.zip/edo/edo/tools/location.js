/* Location capability. Core reasoning does not import this. */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  function format(pos) {
    if (!pos) return "location: unavailable";
    const acc = pos.accuracy != null ? " ±" + Math.round(pos.accuracy) + " m" : "";
    return pos.latitude.toFixed(5) + ", " + pos.longitude.toFixed(5) + acc;
  }
  function request(geo) {
    const g = geo || (typeof navigator !== "undefined" ? navigator.geolocation : null);
    if (!g) return Promise.reject(Error("Geolocation API is not available in this environment."));
    return new Promise((res, rej) => {
      g.getCurrentPosition(
        (p) => res({ latitude: p.coords.latitude, longitude: p.coords.longitude, accuracy: p.coords.accuracy, source: "browser", capturedAt: Date.now() }),
        (e) => rej(Error(e.message || "location denied")),
        { enableHighAccuracy: false, timeout: 8000 }
      );
    });
  }
  function report(pos, weather) {
    const where = "Location fix: " + format(pos) + " (source: " + (pos.source || "browser") + ").";
    if (!weather) return { text: where, meta: "Device location. Not guessed." };
    return {
      text: where + "\nWeather was not fetched. No forecast service is configured. You can search [[G:weather " + pos.latitude.toFixed(2) + "," + pos.longitude.toFixed(2) + "]].",
      meta: "Coordinates only. No weather API call.",
    };
  }
  root.Location = { request, format, report };
})();
