/* EDO voice engine. Three parts, each testable without a browser or a phone:

   1. Stt       continuous speech recognition with interim results, committed final transcripts, silence endpointing,
                automatic restart with back-off, and per-error recovery. Language is configurable (en-IN, hi-IN, en-US...).
                "Hinglish" has no dedicated browser model; it maps to the configured Latin-script locale (en-IN) and is
                labelled that way, with hi-IN available for Devanagari.
   2. WakeWord  a state machine that ACCEPTS wake events from a real detector and protects against false triggers
                (confidence threshold from sensitivity, refractory period, ignores its own speech, requires a command within
                a timeout). The detector itself is native: it runs in the Android voice service and reaches JavaScript as
                "voice.wake" events through the bridge. In a plain browser there is no wake-word detector, and this module
                reports that honestly instead of simulating one with a timer or by re-running full recognition.
   3. Session   idle → wake_detected → listening → processing → speaking → idle/listening, with barge-in (the user speaking
                stops EDO's speech) and a TTS controller (voice, rate, pitch, language, installed-voice preference).

   All browser APIs are injected (env), so tests drive it with fakes. Globals: window.VoiceEngine */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  const LANGS = { "en-IN": "English (India)", "en-US": "English (US)", "en-GB": "English (UK)", "hi-IN": "Hindi", hinglish: "Hinglish (Latin script, uses en-IN)" };
  const recLang = (l) => (l === "hinglish" ? "en-IN" : l || "en-IN");

  /* ================= STT ================= */
  function createStt(env, cfg) {
    env = env || {};
    cfg = Object.assign({ lang: "en-IN", continuous: true, interim: true, silenceMs: 1400, maxSessionMs: 120000, maxRestarts: 6, backoffMs: 250 }, cfg || {});
    const Rec = env.SpeechRecognition || root.SpeechRecognition || root.webkitSpeechRecognition;
    const timers = env.timers || { setTimeout: root.setTimeout.bind(root), clearTimeout: root.clearTimeout.bind(root), now: () => Date.now() };
    let rec = null, state = "stopped", on = {}, wanted = false, restarts = 0, committed = [], interimText = "", silenceT = null, maxT = null, lastResultAt = 0, errorCount = 0, stopReason = null;

    const emit = (name, a, b) => { try { if (on[name]) on[name](a, b); } catch (e) { if (root.console) root.console.error(e); } };
    const setState = (s) => { if (state !== s) { state = s; emit("state", s); } };
    function available() { return typeof Rec === "function"; }
    function clearTimers() { if (silenceT) timers.clearTimeout(silenceT); if (maxT) timers.clearTimeout(maxT); silenceT = maxT = null; }
    function armSilence() {
      if (silenceT) timers.clearTimeout(silenceT);
      silenceT = timers.setTimeout(() => { if (wanted) endpoint("silence"); }, cfg.silenceMs);
    }
    function endpoint(why) {
      const text = (committed.join(" ") + " " + interimText).replace(/\s+/g, " ").trim();
      committed = []; interimText = "";
      if (silenceT) { timers.clearTimeout(silenceT); silenceT = null; }
      if (text) emit("final", text, why);
      if (!cfg.continuous) stop("done");
      else emit("interim", "");
    }
    function build() {
      const r = new Rec();
      r.lang = recLang(cfg.lang); r.continuous = !!cfg.continuous; r.interimResults = !!cfg.interim; r.maxAlternatives = 1;
      r.onstart = () => { setState("listening"); restarts = restarts; };
      r.onaudiostart = () => emit("audio", true);
      r.onspeechstart = () => { lastResultAt = timers.now(); emit("speechstart"); };
      r.onspeechend = () => emit("speechend");
      r.onresult = (ev) => {
        lastResultAt = timers.now(); errorCount = 0;
        let interim = "";
        for (let i = ev.resultIndex; i < ev.results.length; i++) {
          const res = ev.results[i], alt = res[0] || { transcript: "" };
          if (res.isFinal) { const t = String(alt.transcript || "").trim(); if (t) { committed.push(t); emit("segment", t, alt.confidence); } }
          else interim += alt.transcript;
        }
        interimText = interim.trim();
        emit("interim", (committed.join(" ") + " " + interimText).trim());
        armSilence();
      };
      r.onerror = (ev) => handleError(ev && ev.error ? ev.error : "unknown");
      r.onend = () => {
        if (!wanted) { setState("stopped"); return; }
        // browsers end recognition on their own after silence; restart unless we are done or failing
        if (committed.length || interimText) endpoint("recognition ended");
        restart("ended");
      };
      return r;
    }
    function restart(why) {
      if (!wanted) return;
      if (restarts >= cfg.maxRestarts) { emit("error", { code: "too_many_restarts", message: "Speech recognition kept stopping (" + why + "). Tap the mic to try again." }); stop("failed"); return; }
      restarts++; setState("restarting");
      timers.setTimeout(() => { if (!wanted) return; try { rec = build(); rec.start(); } catch (e) { handleError("start-failed:" + e.message); } }, cfg.backoffMs * Math.pow(2, Math.min(restarts - 1, 4)));
    }
    function handleError(code) {
      errorCount++;
      const fatal = ["not-allowed", "service-not-allowed", "audio-capture", "language-not-supported"];
      if (code === "no-speech") { emit("nospeech"); return; } // normal: onend follows and restarts
      if (code === "aborted") return;
      if (fatal.includes(code)) {
        const msg = code === "not-allowed" || code === "service-not-allowed" ? "Microphone permission was denied." : code === "audio-capture" ? "No microphone was found or it is in use by another app." : "That recognition language is not supported on this device.";
        emit("error", { code, message: msg, fatal: true }); stop("error"); return;
      }
      if (code === "network") emit("error", { code, message: "Speech recognition needs a network connection in this browser.", fatal: false });
      else emit("error", { code, message: "Speech recognition error: " + code, fatal: false });
      if (errorCount >= 4) { stop("failed"); emit("error", { code: "too_many_errors", message: "Too many recognition errors in a row; stopped.", fatal: true }); }
    }
    function start(handlers) {
      on = Object.assign({}, on, handlers || {}); // register first, so even the "unsupported" error reaches the caller
      if (!available()) { emit("error", { code: "unsupported", message: "Speech recognition is not supported in this browser.", fatal: true }); return false; }
      if (wanted) return true;
      wanted = true; restarts = 0; errorCount = 0; committed = []; interimText = ""; stopReason = null;
      try { rec = build(); rec.start(); } catch (e) { wanted = false; emit("error", { code: "start-failed", message: e.message, fatal: true }); return false; }
      maxT = timers.setTimeout(() => { if (wanted) { endpoint("max session"); stop("timeout"); } }, cfg.maxSessionMs);
      return true;
    }
    function stop(reason) {
      wanted = false; stopReason = reason || "stopped"; clearTimers();
      try { if (rec) { rec.onend = null; rec.stop(); } } catch (e) {}
      rec = null; setState("stopped"); emit("stopped", stopReason);
    }
    function abort() { wanted = false; clearTimers(); try { if (rec) { rec.onend = null; rec.abort(); } } catch (e) {} rec = null; setState("stopped"); }
    return { start, stop, abort, available, configure: (c) => Object.assign(cfg, c || {}), get state() { return state; }, get config() { return Object.assign({}, cfg); }, on: (h) => { on = Object.assign(on, h); }, _endpoint: endpoint };
  }

  /* ================= wake word ================= */
  const SENS = { low: 0.85, medium: 0.7, high: 0.55 };
  function validPhrase(p) {
    const s = String(p || "").trim().replace(/\s+/g, " ");
    if (s.length < 4 || s.length > 40) return { ok: false, reason: "Use 4 to 40 characters." };
    if (!/^[\p{L}\p{N} '-]+$/u.test(s)) return { ok: false, reason: "Use letters and numbers only." };
    const words = s.split(" ").length, syll = (s.toLowerCase().match(/[aeiouy]+/g) || []).length;
    if (words < 2 && syll < 3) return { ok: false, reason: "Use at least two words or three syllables: short, common words trigger by accident." };
    if (/^(ok|okay|hey|hi|hello) (google|siri|alexa|bixby)$/i.test(s)) return { ok: false, reason: "That phrase belongs to another assistant." };
    return { ok: true, phrase: s };
  }
  function createWake(env, cfg) {
    env = env || {};
    cfg = Object.assign({ phrase: "Hey EDO", enabled: false, sensitivity: "medium", refractoryMs: 2500, commandTimeoutMs: 8000, ignoreWhileSpeaking: true }, cfg || {});
    const now = env.now || (() => Date.now());
    const bridge = env.bridge || null;
    let awaiting = false, lastWakeAt = -1e9, awaitT = null, stats = { accepted: 0, rejected: { lowConfidence: 0, refractory: 0, wrongPhrase: 0, disabled: 0, speaking: 0, busy: 0 } }, listeners = {}, speaking = false, busy = false;
    let native = { available: false, engine: null, reason: "No native wake-word engine is connected (this is a plain browser).", running: false };
    const emit = (n, a) => { try { if (listeners[n]) listeners[n](a); } catch (e) {} };
    const threshold = () => SENS[cfg.sensitivity] || SENS.medium;
    const norm = (s) => String(s || "").toLowerCase().replace(/[^\p{L}\p{N} ]/gu, "").replace(/\s+/g, " ").trim();

    /* wake events come from the native detector: {phrase, confidence 0..1, source} */
    function onWake(ev) {
      ev = ev || {};
      if (!cfg.enabled) { stats.rejected.disabled++; return { accepted: false, reason: "disabled" }; }
      if (ev.phrase && norm(ev.phrase) !== norm(cfg.phrase)) { stats.rejected.wrongPhrase++; return { accepted: false, reason: "wrong phrase" }; }
      const c = typeof ev.confidence === "number" ? ev.confidence : 0;
      if (c < threshold()) { stats.rejected.lowConfidence++; return { accepted: false, reason: "confidence " + c.toFixed(2) + " is below " + threshold() }; }
      const t = now();
      if (t - lastWakeAt < cfg.refractoryMs) { stats.rejected.refractory++; return { accepted: false, reason: "too soon after the previous wake" }; }
      if (speaking && cfg.ignoreWhileSpeaking && c < Math.min(0.95, threshold() + 0.2)) { stats.rejected.speaking++; return { accepted: false, reason: "EDO is speaking; only a very confident wake interrupts" }; }
      if (busy) { stats.rejected.busy++; return { accepted: false, reason: "already handling a request" }; }
      lastWakeAt = t; stats.accepted++; awaiting = true;
      if (awaitT && env.timers) env.timers.clearTimeout(awaitT);
      if (env.timers) awaitT = env.timers.setTimeout(() => { if (awaiting) { awaiting = false; emit("timeout"); } }, cfg.commandTimeoutMs);
      emit("wake", { phrase: cfg.phrase, confidence: c, interrupt: speaking });
      return { accepted: true };
    }
    function commandReceived() { awaiting = false; if (awaitT && env.timers) env.timers.clearTimeout(awaitT); }
    function setSpeaking(v) { speaking = !!v; }
    function setBusy(v) { busy = !!v; }

    async function configure(c) {
      c = c || {};
      if (c.phrase != null) { const v = validPhrase(c.phrase); if (!v.ok) return { ok: false, reason: v.reason }; cfg.phrase = v.phrase; }
      if (c.sensitivity) { if (!SENS[c.sensitivity]) return { ok: false, reason: "sensitivity must be low, medium or high" }; cfg.sensitivity = c.sensitivity; }
      if (c.commandTimeoutMs) cfg.commandTimeoutMs = Math.min(30000, Math.max(2000, c.commandTimeoutMs));
      if (c.refractoryMs != null) cfg.refractoryMs = Math.min(10000, Math.max(500, c.refractoryMs));
      if (c.enabled != null) cfg.enabled = !!c.enabled;
      return syncNative();
    }
    /* tell the native side to (re)configure and start/stop its detector. Resolves with what the device actually did. */
    async function syncNative() {
      if (!bridge || !bridge.available || !bridge.available()) { native = { available: false, engine: null, running: false, reason: "No native wake-word engine is connected (this is a plain browser)." }; return { ok: !cfg.enabled, wakeWord: status(), note: cfg.enabled ? native.reason : null }; }
      try {
        const r = await bridge.call("voice.configureWake", { phrase: cfg.phrase, sensitivity: cfg.sensitivity, threshold: threshold(), enabled: cfg.enabled }, { timeoutMs: 8000 });
        native = { available: !!r.engineAvailable, engine: r.engine || null, running: !!r.running, reason: r.engineAvailable ? null : (r.reason || "The Android build has no wake-word engine installed.") };
        return { ok: !cfg.enabled || native.available, wakeWord: status(), note: native.reason };
      } catch (e) { native = { available: false, engine: null, running: false, reason: e.code ? e.code + ": " + e.message : e.message }; return { ok: false, wakeWord: status(), note: native.reason }; }
    }
    function status() { return { enabled: cfg.enabled, phrase: cfg.phrase, sensitivity: cfg.sensitivity, threshold: threshold(), awaitingCommand: awaiting, native, stats: JSON.parse(JSON.stringify(stats)), honest: native.available ? "Detection runs in the Android voice service." : "No wake-word detector is running. Wake word needs the Android build with a native engine." }; }
    return { onWake, commandReceived, configure, syncNative, status, setSpeaking, setBusy, on: (n, f) => { listeners[n] = f; }, get awaiting() { return awaiting; }, validPhrase, config: () => Object.assign({}, cfg) };
  }

  /* ================= TTS ================= */
  function createTts(env, cfg) {
    env = env || {};
    cfg = Object.assign({ lang: "en-IN", rate: 1, pitch: 1, volume: 1, voiceName: null, preferLocal: true, native: "auto" }, cfg || {});
    const synth = env.speechSynthesis || root.speechSynthesis || null;
    const Utt = env.SpeechSynthesisUtterance || root.SpeechSynthesisUtterance || null;
    const bridge = env.bridge || null;
    let state = "idle", handlers = {}, current = null, id = 0;
    const emit = (n, a) => { try { if (handlers[n]) handlers[n](a); } catch (e) {} };
    const set = (s) => { if (state !== s) { state = s; emit("state", s); } };
    function voices() { try { return synth && synth.getVoices ? synth.getVoices() : []; } catch (e) { return []; } }
    function pickVoice() {
      const vs = voices(); if (!vs.length) return null;
      if (cfg.voiceName) { const v = vs.find((x) => x.name === cfg.voiceName); if (v) return v; }
      const want = recLang(cfg.lang).toLowerCase(), base = want.split("-")[0];
      const score = (v) => { const l = String(v.lang || "").toLowerCase().replace("_", "-"); return (l === want ? 4 : l.split("-")[0] === base ? 2 : 0) + (cfg.preferLocal && v.localService ? 1.5 : 0) + (v.default ? 0.2 : 0); };
      return vs.slice().sort((a, b) => score(b) - score(a))[0];
    }
    function clean(t) { return String(t || "").replace(/```[\s\S]*?```/g, " code block omitted. ").replace(/\[\[.*?\]\]/g, "").replace(/[*_`#>]/g, "").replace(/https?:\/\/\S+/g, "link").replace(/\s+/g, " ").trim().slice(0, 3000); }
    function useNative() { return cfg.native !== false && bridge && bridge.available && bridge.available() && bridge.supports && bridge.supports("tts.speak"); }
    function speak(text, h) {
      const t = clean(text); handlers = Object.assign({}, h || {});
      if (!t) { emit("end", { reason: "empty" }); return null; }
      cancel(true);
      const myId = ++id;
      if (useNative()) {
        set("speaking"); emit("start", { engine: "android" });
        bridge.call("tts.speak", { text: t, lang: recLang(cfg.lang), rate: cfg.rate, pitch: cfg.pitch, voice: cfg.voiceName }, { timeoutMs: 120000 }).then(() => { if (myId === id) { set("idle"); emit("end", { reason: "done" }); } }, (e) => { if (myId === id) { set("idle"); emit("error", e); } });
        current = { native: true, id: myId }; return myId;
      }
      if (!synth || !Utt) { set("idle"); emit("error", { code: "unsupported", message: "Text-to-speech is not available here." }); return null; }
      const u = new Utt(t); const v = pickVoice();
      u.lang = recLang(cfg.lang); u.rate = cfg.rate; u.pitch = cfg.pitch; u.volume = cfg.volume; if (v) { try { u.voice = v; u.lang = v.lang || u.lang; } catch (e) { /* a voice object the engine refuses: keep the language and speak with the default voice */ } }
      u.onstart = () => { if (myId === id) { set("speaking"); emit("start", { engine: "browser", voice: v && v.name }); } };
      u.onend = () => { if (myId === id) { set("idle"); emit("end", { reason: "done" }); } };
      u.onerror = (e) => { if (myId === id) { set("idle"); if (!e || (e.error !== "interrupted" && e.error !== "canceled")) emit("error", { code: (e && e.error) || "tts", message: "Speech playback failed." }); else emit("end", { reason: "interrupted" }); } };
      current = { u, id: myId }; set("speaking"); synth.speak(u); return myId;
    }
    function cancel(silent) {
      if (current && current.native && bridge) { try { bridge.call("tts.stop", {}, { timeoutMs: 3000 }).catch(() => {}); } catch (e) {} }
      try { if (synth && (synth.speaking || synth.pending)) synth.cancel(); } catch (e) {}
      const was = state === "speaking"; current = null; id++;
      if (was) { set("idle"); if (!silent) emit("end", { reason: "interrupted" }); }
    }
    return { speak, cancel, voices, pickVoice, configure: (c) => Object.assign(cfg, c || {}), get state() { return state; }, get config() { return Object.assign({}, cfg); }, clean, available: () => !!(synth && Utt) || useNative() };
  }

  /* ================= session ================= */
  function createSession(parts, opts) {
    opts = opts || {};
    const { stt, tts, wake } = parts;
    const listeners = [];
    let state = "idle", cfg = Object.assign({ returnTo: "idle", handsFree: false, bargeIn: true }, opts), onCommand = opts.onCommand || null, errorMsg = null;
    const log = [];
    const emit = () => listeners.forEach((f) => { try { f(snapshot()); } catch (e) {} });
    function set(s, why) { if (state === s) return; log.push({ from: state, to: s, why: why || "" }); if (log.length > 60) log.shift(); state = s; if (s !== "error") errorMsg = null; emit(); }
    const snapshot = () => ({ state, error: errorMsg, wake: wake ? wake.status() : null, stt: stt ? stt.state : null, tts: tts ? tts.state : null });

    function beginListening(why) {
      set("listening", why);
      if (wake) wake.setBusy(false);
      stt.start({
        final: (text) => handleTranscript(text),
        error: (e) => { errorMsg = e.message; if (e.fatal) set("error", e.code); },
        speechstart: () => { if (cfg.bargeIn && tts && tts.state === "speaking") interrupt("user spoke"); },
      });
    }
    function handleTranscript(text) {
      if (state !== "listening") return;
      stt.stop("final");
      if (wake) wake.commandReceived();
      set("processing", "transcript");
      if (wake) wake.setBusy(true);
      Promise.resolve(onCommand ? onCommand(text) : null).then((reply) => respond(reply), (e) => { errorMsg = e && e.message ? e.message : "request failed"; set("error", "handler failed"); if (wake) wake.setBusy(false); });
    }
    function respond(reply) {
      if (reply && reply.speak !== false && reply.text && tts && tts.available()) {
        set("speaking", "reply");
        if (wake) { wake.setBusy(false); wake.setSpeaking(true); } // the request is handled; a confident wake may now interrupt the answer
        tts.speak(reply.text, { end: () => doneSpeaking(), error: () => doneSpeaking() });
      } else doneSpeaking();
    }
    function doneSpeaking() {
      if (state !== "speaking" && state !== "processing") return;
      if (wake) { wake.setSpeaking(false); wake.setBusy(false); }
      if (cfg.handsFree) beginListening("hands-free continues"); else set("idle", "reply done");
    }
    function interrupt(why) {
      if (tts) tts.cancel(true);
      if (wake) wake.setSpeaking(false);
      if (state === "speaking") { set("listening", "barge-in: " + (why || "")); if (!stt.state || stt.state === "stopped") beginListening("barge-in"); }
    }
    /* entry points */
    function pushToTalk() { if (state === "speaking") interrupt("tap"); else if (state === "idle" || state === "error") beginListening("tap"); else if (state === "listening") { stt._endpoint("tap"); } }
    function stop() { if (stt) stt.stop("user"); if (tts) tts.cancel(true); if (wake) { wake.commandReceived(); wake.setSpeaking(false); wake.setBusy(false); } set("idle", "stopped"); }
    if (wake) {
      wake.on("wake", (ev) => {
        if (ev.interrupt) { if (tts) tts.cancel(true); wake.setSpeaking(false); }
        if (state === "idle" || state === "speaking" || state === "error") { set("wake_detected", "wake word"); beginListening("after wake"); }
      });
      wake.on("timeout", () => { if (state === "listening") { stt.stop("no command"); set("idle", "no command after wake"); } });
    }
    return { pushToTalk, stop, interrupt, onWakeEvent: (ev) => (wake ? wake.onWake(ev) : { accepted: false }), subscribe: (f) => { listeners.push(f); return () => listeners.splice(listeners.indexOf(f), 1); }, get state() { return state; }, snapshot, log: () => log.slice(), configure: (c) => Object.assign(cfg, c || {}), setHandler: (f) => { onCommand = f; } };
  }

  root.VoiceEngine = { createStt, createWake, createTts, createSession, validPhrase, LANGS, SENS, recLang };
})();
