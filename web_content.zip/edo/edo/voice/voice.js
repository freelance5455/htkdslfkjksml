/* Voice input/output. Optional. Reasoning does not import this. */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  function sttCtor() {
    return root.SpeechRecognition || root.webkitSpeechRecognition || null;
  }
  const Voice = {
    ttsAvailable() {
      return typeof root.speechSynthesis !== "undefined";
    },
    sttAvailable() {
      return !!sttCtor();
    },
    speak(text, hooks) {
      if (!Voice.ttsAvailable()) return null;
      root.speechSynthesis.cancel();
      const u = new root.SpeechSynthesisUtterance(String(text).slice(0, 4000));
      u.rate = 1.02;
      u.lang = "en-IN";
      if (hooks && hooks.onstart) u.onstart = hooks.onstart;
      if (hooks && hooks.onend) u.onend = hooks.onend;
      root.speechSynthesis.speak(u);
      return u;
    },
    stop() {
      if (Voice.ttsAvailable()) root.speechSynthesis.cancel();
    },
    listen(hooks) {
      const C = sttCtor();
      if (!C) return null;
      const rec = new C();
      rec.lang = "en-IN";
      rec.interimResults = false;
      rec.continuous = false;
      rec.onresult = (e) => hooks.onFinal && hooks.onFinal(e.results[0][0].transcript);
      rec.onerror = (e) => hooks.onError && hooks.onError(e.error || "speech error");
      rec.onend = () => hooks.onEnd && hooks.onEnd();
      rec.onstart = () => hooks.onStart && hooks.onStart();
      rec.start();
      return rec;
    },
  };
  root.Voice = Voice;
})();
