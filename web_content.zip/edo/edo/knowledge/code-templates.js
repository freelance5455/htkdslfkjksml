/* Reviewed code templates: window.EDO_CODE[name] = {title, aliases, complexity, notes, code:{lang:src}, cases:[[args, expected]], fn:{lang:name}}.
   These are fixed text, not model output. The test suite RUNS the JavaScript and Python ones (when python3 exists) against `cases`;
   EDO itself never executes anything at runtime. Other languages are reviewed text only. */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  const T = (root.EDO_CODE = root.EDO_CODE || {});
  T.factorial = { title: "factorial", aliases: ["factorial", "n!"], complexity: "O(n) time, O(1) space", notes: "Loop form avoids recursion limits. Results above 20! exceed exact 64-bit integers; use BigInt / big integers beyond that.",
    fn: { javascript: "factorial", python: "factorial", typescript: "factorial", c: "factorial", cpp: "factorial", java: "factorial", kotlin: "factorial", csharp: "Factorial" },
    cases: [[[0], 1], [[1], 1], [[5], 120], [[10], 3628800]],
    code: {
      javascript: "function factorial(n) {\n  if (!Number.isInteger(n) || n < 0) throw new Error('n must be a non-negative integer');\n  let out = 1;\n  for (let i = 2; i <= n; i++) out *= i;\n  return out;\n}\n",
      typescript: "function factorial(n: number): number {\n  if (!Number.isInteger(n) || n < 0) throw new Error('n must be a non-negative integer');\n  let out = 1;\n  for (let i = 2; i <= n; i++) out *= i;\n  return out;\n}\n",
      python: "def factorial(n):\n    if n < 0:\n        raise ValueError('n must be >= 0')\n    out = 1\n    for i in range(2, n + 1):\n        out *= i\n    return out\n",
      c: "#include <stdio.h>\n\nunsigned long long factorial(unsigned int n) {\n    unsigned long long out = 1;\n    for (unsigned int i = 2; i <= n; i++) out *= i; /* overflows above 20! */\n    return out;\n}\n",
      cpp: "#include <stdexcept>\n\nunsigned long long factorial(int n) {\n    if (n < 0) throw std::invalid_argument(\"n must be >= 0\");\n    unsigned long long out = 1;\n    for (int i = 2; i <= n; ++i) out *= i; // overflows above 20!\n    return out;\n}\n",
      java: "public static long factorial(int n) {\n    if (n < 0) throw new IllegalArgumentException(\"n must be >= 0\");\n    long out = 1;\n    for (int i = 2; i <= n; i++) out *= i; // overflows above 20!\n    return out;\n}\n",
      kotlin: "fun factorial(n: Int): Long {\n    require(n >= 0) { \"n must be >= 0\" }\n    var out = 1L\n    for (i in 2..n) out *= i // overflows above 20!\n    return out\n}\n",
      csharp: "public static long Factorial(int n)\n{\n    if (n < 0) throw new ArgumentOutOfRangeException(nameof(n));\n    long out_ = 1;\n    for (int i = 2; i <= n; i++) out_ *= i; // overflows above 20!\n    return out_;\n}\n" } };
  T.primes = { title: "primes up to n (Sieve of Eratosthenes)", aliases: ["prime", "primes", "sieve"], complexity: "O(n log log n) time, O(n) space", notes: "Sieve beats trial division when you need all primes up to n.",
    fn: { javascript: "primesUpTo", python: "primes_up_to", typescript: "primesUpTo", java: "primesUpTo", kotlin: "primesUpTo", csharp: "PrimesUpTo", cpp: "primesUpTo", c: "primes_up_to" },
    cases: [[[0], []], [[1], []], [[2], [2]], [[10], [2, 3, 5, 7]], [[30], [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]]],
    code: {
      javascript: "function primesUpTo(n) {\n  if (n < 2) return [];\n  const sieve = new Array(n + 1).fill(true);\n  sieve[0] = sieve[1] = false;\n  for (let i = 2; i * i <= n; i++) {\n    if (sieve[i]) for (let j = i * i; j <= n; j += i) sieve[j] = false;\n  }\n  return sieve.flatMap((p, i) => (p ? [i] : []));\n}\n",
      typescript: "function primesUpTo(n: number): number[] {\n  if (n < 2) return [];\n  const sieve: boolean[] = new Array(n + 1).fill(true);\n  sieve[0] = sieve[1] = false;\n  for (let i = 2; i * i <= n; i++) {\n    if (sieve[i]) for (let j = i * i; j <= n; j += i) sieve[j] = false;\n  }\n  return sieve.flatMap((p, i) => (p ? [i] : []));\n}\n",
      python: "def primes_up_to(n):\n    if n < 2:\n        return []\n    sieve = [True] * (n + 1)\n    sieve[0] = sieve[1] = False\n    for i in range(2, int(n ** 0.5) + 1):\n        if sieve[i]:\n            for j in range(i * i, n + 1, i):\n                sieve[j] = False\n    return [i for i, is_prime in enumerate(sieve) if is_prime]\n",
      java: "public static java.util.List<Integer> primesUpTo(int n) {\n    java.util.List<Integer> out = new java.util.ArrayList<>();\n    if (n < 2) return out;\n    boolean[] composite = new boolean[n + 1];\n    for (int i = 2; (long) i * i <= n; i++)\n        if (!composite[i]) for (int j = i * i; j <= n; j += i) composite[j] = true;\n    for (int i = 2; i <= n; i++) if (!composite[i]) out.add(i);\n    return out;\n}\n",
      kotlin: "fun primesUpTo(n: Int): List<Int> {\n    if (n < 2) return emptyList()\n    val composite = BooleanArray(n + 1)\n    var i = 2\n    while (i.toLong() * i <= n) {\n        if (!composite[i]) { var j = i * i; while (j <= n) { composite[j] = true; j += i } }\n        i++\n    }\n    return (2..n).filter { !composite[it] }\n}\n",
      csharp: "public static List<int> PrimesUpTo(int n)\n{\n    var result = new List<int>();\n    if (n < 2) return result;\n    var composite = new bool[n + 1];\n    for (long i = 2; i * i <= n; i++)\n        if (!composite[i]) for (long j = i * i; j <= n; j += i) composite[j] = true;\n    for (int i = 2; i <= n; i++) if (!composite[i]) result.Add(i);\n    return result;\n}\n",
      cpp: "#include <vector>\n\nstd::vector<int> primesUpTo(int n) {\n    std::vector<int> out;\n    if (n < 2) return out;\n    std::vector<bool> composite(n + 1, false);\n    for (long long i = 2; i * i <= n; ++i)\n        if (!composite[i]) for (long long j = i * i; j <= n; j += i) composite[j] = true;\n    for (int i = 2; i <= n; ++i) if (!composite[i]) out.push_back(i);\n    return out;\n}\n" } };
  T.binarysearch = { title: "binary search", aliases: ["binary search", "bisect"], complexity: "O(log n) time, O(1) space", notes: "Requires a sorted array. Returns the index, or -1. mid is computed without overflow.",
    fn: { javascript: "binarySearch", python: "binary_search", typescript: "binarySearch", java: "binarySearch", kotlin: "binarySearch", csharp: "BinarySearch", cpp: "binarySearch", c: "binary_search" },
    cases: [[[[1, 3, 5, 7, 9], 7], 3], [[[1, 3, 5, 7, 9], 1], 0], [[[1, 3, 5, 7, 9], 4], -1], [[[], 1], -1], [[[2], 2], 0]],
    code: {
      javascript: "function binarySearch(a, target) {\n  let lo = 0, hi = a.length - 1;\n  while (lo <= hi) {\n    const mid = lo + ((hi - lo) >> 1);\n    if (a[mid] === target) return mid;\n    if (a[mid] < target) lo = mid + 1;\n    else hi = mid - 1;\n  }\n  return -1;\n}\n",
      typescript: "function binarySearch(a: number[], target: number): number {\n  let lo = 0, hi = a.length - 1;\n  while (lo <= hi) {\n    const mid = lo + ((hi - lo) >> 1);\n    if (a[mid] === target) return mid;\n    if (a[mid] < target) lo = mid + 1;\n    else hi = mid - 1;\n  }\n  return -1;\n}\n",
      python: "def binary_search(a, target):\n    lo, hi = 0, len(a) - 1\n    while lo <= hi:\n        mid = (lo + hi) // 2\n        if a[mid] == target:\n            return mid\n        if a[mid] < target:\n            lo = mid + 1\n        else:\n            hi = mid - 1\n    return -1\n",
      c: "int binary_search(const int *a, int n, int target) {\n    int lo = 0, hi = n - 1;\n    while (lo <= hi) {\n        int mid = lo + (hi - lo) / 2;\n        if (a[mid] == target) return mid;\n        if (a[mid] < target) lo = mid + 1;\n        else hi = mid - 1;\n    }\n    return -1;\n}\n",
      cpp: "#include <vector>\n\nint binarySearch(const std::vector<int>& a, int target) {\n    int lo = 0, hi = static_cast<int>(a.size()) - 1;\n    while (lo <= hi) {\n        int mid = lo + (hi - lo) / 2;\n        if (a[mid] == target) return mid;\n        if (a[mid] < target) lo = mid + 1;\n        else hi = mid - 1;\n    }\n    return -1;\n}\n",
      java: "public static int binarySearch(int[] a, int target) {\n    int lo = 0, hi = a.length - 1;\n    while (lo <= hi) {\n        int mid = lo + (hi - lo) / 2;\n        if (a[mid] == target) return mid;\n        if (a[mid] < target) lo = mid + 1;\n        else hi = mid - 1;\n    }\n    return -1;\n}\n",
      kotlin: "fun binarySearch(a: IntArray, target: Int): Int {\n    var lo = 0\n    var hi = a.size - 1\n    while (lo <= hi) {\n        val mid = lo + (hi - lo) / 2\n        when {\n            a[mid] == target -> return mid\n            a[mid] < target -> lo = mid + 1\n            else -> hi = mid - 1\n        }\n    }\n    return -1\n}\n",
      csharp: "public static int BinarySearch(int[] a, int target)\n{\n    int lo = 0, hi = a.Length - 1;\n    while (lo <= hi)\n    {\n        int mid = lo + (hi - lo) / 2;\n        if (a[mid] == target) return mid;\n        if (a[mid] < target) lo = mid + 1; else hi = mid - 1;\n    }\n    return -1;\n}\n" } };
  T.fibonacci = { title: "Fibonacci number", aliases: ["fibonacci", "fib"], complexity: "O(n) time, O(1) space", notes: "Iterative form; the naive recursive version is O(2^n).",
    fn: { javascript: "fib", python: "fib", typescript: "fib", java: "fib", kotlin: "fib", csharp: "Fib", cpp: "fib", c: "fib" },
    cases: [[[0], 0], [[1], 1], [[2], 1], [[10], 55], [[20], 6765]],
    code: {
      javascript: "function fib(n) {\n  if (!Number.isInteger(n) || n < 0) throw new Error('n must be a non-negative integer');\n  let a = 0, b = 1;\n  for (let i = 0; i < n; i++) [a, b] = [b, a + b];\n  return a;\n}\n",
      typescript: "function fib(n: number): number {\n  if (!Number.isInteger(n) || n < 0) throw new Error('n must be a non-negative integer');\n  let a = 0, b = 1;\n  for (let i = 0; i < n; i++) [a, b] = [b, a + b];\n  return a;\n}\n",
      python: "def fib(n):\n    if n < 0:\n        raise ValueError('n must be >= 0')\n    a, b = 0, 1\n    for _ in range(n):\n        a, b = b, a + b\n    return a\n",
      c: "unsigned long long fib(unsigned int n) {\n    unsigned long long a = 0, b = 1;\n    for (unsigned int i = 0; i < n; i++) { unsigned long long t = a + b; a = b; b = t; } /* overflows above fib(93) */\n    return a;\n}\n",
      cpp: "unsigned long long fib(unsigned int n) {\n    unsigned long long a = 0, b = 1;\n    for (unsigned int i = 0; i < n; ++i) { auto t = a + b; a = b; b = t; } // overflows above fib(93)\n    return a;\n}\n",
      java: "public static long fib(int n) {\n    if (n < 0) throw new IllegalArgumentException(\"n must be >= 0\");\n    long a = 0, b = 1;\n    for (int i = 0; i < n; i++) { long t = a + b; a = b; b = t; } // overflows above fib(92)\n    return a;\n}\n",
      kotlin: "fun fib(n: Int): Long {\n    require(n >= 0)\n    var a = 0L; var b = 1L\n    repeat(n) { val t = a + b; a = b; b = t } // overflows above fib(92)\n    return a\n}\n",
      csharp: "public static long Fib(int n)\n{\n    if (n < 0) throw new ArgumentOutOfRangeException(nameof(n));\n    long a = 0, b = 1;\n    for (int i = 0; i < n; i++) { long t = a + b; a = b; b = t; }\n    return a;\n}\n" } };
  T.gcd = { title: "greatest common divisor (Euclid)", aliases: ["gcd", "hcf", "greatest common divisor"], complexity: "O(log min(a,b)) time", notes: "Euclid's algorithm. gcd(0,0) is defined here as 0.",
    fn: { javascript: "gcd", python: "gcd", typescript: "gcd", java: "gcd", kotlin: "gcd", csharp: "Gcd", cpp: "gcd", c: "gcd" },
    cases: [[[12, 18], 6], [[17, 5], 1], [[0, 9], 9], [[0, 0], 0], [[-12, 18], 6]],
    code: {
      javascript: "function gcd(a, b) {\n  a = Math.abs(a); b = Math.abs(b);\n  while (b) [a, b] = [b, a % b];\n  return a;\n}\n",
      typescript: "function gcd(a: number, b: number): number {\n  a = Math.abs(a); b = Math.abs(b);\n  while (b) [a, b] = [b, a % b];\n  return a;\n}\n",
      python: "def gcd(a, b):\n    a, b = abs(a), abs(b)\n    while b:\n        a, b = b, a % b\n    return a\n",
      c: "int gcd(int a, int b) {\n    if (a < 0) a = -a;\n    if (b < 0) b = -b;\n    while (b) { int t = a % b; a = b; b = t; }\n    return a;\n}\n",
      cpp: "#include <cstdlib>\n\nint gcd(int a, int b) {\n    a = std::abs(a); b = std::abs(b);\n    while (b) { int t = a % b; a = b; b = t; }\n    return a;\n}\n",
      java: "public static int gcd(int a, int b) {\n    a = Math.abs(a); b = Math.abs(b);\n    while (b != 0) { int t = a % b; a = b; b = t; }\n    return a;\n}\n",
      kotlin: "fun gcd(a: Int, b: Int): Int {\n    var x = kotlin.math.abs(a); var y = kotlin.math.abs(b)\n    while (y != 0) { val t = x % y; x = y; y = t }\n    return x\n}\n",
      csharp: "public static int Gcd(int a, int b)\n{\n    a = Math.Abs(a); b = Math.Abs(b);\n    while (b != 0) { int t = a % b; a = b; b = t; }\n    return a;\n}\n" } };
  T.reverse = { title: "reverse a string", aliases: ["reverse string", "reverse a string", "string reverse"], complexity: "O(n) time", notes: "JavaScript/Python index by UTF-16 units / code points; combining characters and emoji sequences may reorder visually.",
    fn: { javascript: "reverseString", python: "reverse_string", typescript: "reverseString", java: "reverseString", kotlin: "reverseString", csharp: "ReverseString", cpp: "reverseString", c: "reverse_string" },
    cases: [[["abc"], "cba"], [[""], ""], [["a"], "a"], [["racecar"], "racecar"]],
    code: {
      javascript: "function reverseString(s) {\n  return Array.from(String(s)).reverse().join('');\n}\n",
      typescript: "function reverseString(s: string): string {\n  return Array.from(s).reverse().join('');\n}\n",
      python: "def reverse_string(s):\n    return s[::-1]\n",
      java: "public static String reverseString(String s) {\n    return new StringBuilder(s).reverse().toString();\n}\n",
      kotlin: "fun reverseString(s: String): String = s.reversed()\n",
      csharp: "public static string ReverseString(string s)\n{\n    var chars = s.ToCharArray();\n    Array.Reverse(chars);\n    return new string(chars);\n}\n",
      cpp: "#include <algorithm>\n#include <string>\n\nstd::string reverseString(std::string s) {\n    std::reverse(s.begin(), s.end());\n    return s;\n}\n",
      c: "#include <string.h>\n\nvoid reverse_string(char *s) {\n    size_t n = strlen(s);\n    for (size_t i = 0; i < n / 2; i++) { char t = s[i]; s[i] = s[n - 1 - i]; s[n - 1 - i] = t; }\n}\n" } };
  T.palindrome = { title: "palindrome check", aliases: ["palindrome"], complexity: "O(n) time", notes: "Ignores case and non-alphanumeric characters.",
    fn: { javascript: "isPalindrome", python: "is_palindrome", typescript: "isPalindrome", java: "isPalindrome", kotlin: "isPalindrome", csharp: "IsPalindrome", cpp: "isPalindrome", c: "is_palindrome" },
    cases: [[["racecar"], true], [["A man, a plan, a canal: Panama"], true], [["hello"], false], [[""], true]],
    code: {
      javascript: "function isPalindrome(s) {\n  const t = String(s).toLowerCase().replace(/[^a-z0-9]/g, '');\n  for (let i = 0, j = t.length - 1; i < j; i++, j--) if (t[i] !== t[j]) return false;\n  return true;\n}\n",
      typescript: "function isPalindrome(s: string): boolean {\n  const t = s.toLowerCase().replace(/[^a-z0-9]/g, '');\n  for (let i = 0, j = t.length - 1; i < j; i++, j--) if (t[i] !== t[j]) return false;\n  return true;\n}\n",
      python: "def is_palindrome(s):\n    t = [c.lower() for c in s if c.isalnum()]\n    return t == t[::-1]\n",
      java: "public static boolean isPalindrome(String s) {\n    String t = s.toLowerCase().replaceAll(\"[^a-z0-9]\", \"\");\n    return new StringBuilder(t).reverse().toString().equals(t);\n}\n",
      kotlin: "fun isPalindrome(s: String): Boolean {\n    val t = s.lowercase().filter { it.isLetterOrDigit() }\n    return t == t.reversed()\n}\n",
      csharp: "public static bool IsPalindrome(string s)\n{\n    var t = new string(s.Where(char.IsLetterOrDigit).Select(char.ToLower).ToArray());\n    return t.SequenceEqual(t.Reverse());\n}\n" } };
  T.mergesort = { title: "merge sort", aliases: ["merge sort", "mergesort", "sort", "sorting"], complexity: "O(n log n) time, O(n) space, stable", notes: "Returns a new sorted array; the input is not modified.",
    fn: { javascript: "mergeSort", python: "merge_sort", typescript: "mergeSort" },
    cases: [[[[3, 1, 2]], [1, 2, 3]], [[[]], []], [[[5]], [5]], [[[2, 2, 1]], [1, 2, 2]], [[[9, -1, 0, 4]], [-1, 0, 4, 9]]],
    code: {
      javascript: "function mergeSort(a) {\n  if (a.length <= 1) return a.slice();\n  const mid = a.length >> 1;\n  const l = mergeSort(a.slice(0, mid)), r = mergeSort(a.slice(mid));\n  const out = [];\n  let i = 0, j = 0;\n  while (i < l.length && j < r.length) out.push(l[i] <= r[j] ? l[i++] : r[j++]);\n  while (i < l.length) out.push(l[i++]);\n  while (j < r.length) out.push(r[j++]);\n  return out;\n}\n",
      typescript: "function mergeSort(a: number[]): number[] {\n  if (a.length <= 1) return a.slice();\n  const mid = a.length >> 1;\n  const l = mergeSort(a.slice(0, mid)), r = mergeSort(a.slice(mid));\n  const out: number[] = [];\n  let i = 0, j = 0;\n  while (i < l.length && j < r.length) out.push(l[i] <= r[j] ? l[i++] : r[j++]);\n  while (i < l.length) out.push(l[i++]);\n  while (j < r.length) out.push(r[j++]);\n  return out;\n}\n",
      python: "def merge_sort(a):\n    if len(a) <= 1:\n        return list(a)\n    mid = len(a) // 2\n    l, r = merge_sort(a[:mid]), merge_sort(a[mid:])\n    out, i, j = [], 0, 0\n    while i < len(l) and j < len(r):\n        if l[i] <= r[j]:\n            out.append(l[i]); i += 1\n        else:\n            out.append(r[j]); j += 1\n    out.extend(l[i:])\n    out.extend(r[j:])\n    return out\n" } };
  /* Algorithm facts used by compare/complexity answers. Standard textbook values. */
  root.EDO_ALGO = {
    "bubble sort": { best: "O(n)", avg: "O(n²)", worst: "O(n²)", space: "O(1)", stable: true, note: "Only useful for tiny or nearly sorted inputs." },
    "insertion sort": { best: "O(n)", avg: "O(n²)", worst: "O(n²)", space: "O(1)", stable: true, note: "Fast for small or nearly sorted arrays." },
    "selection sort": { best: "O(n²)", avg: "O(n²)", worst: "O(n²)", space: "O(1)", stable: false, note: "Minimises the number of swaps." },
    "merge sort": { best: "O(n log n)", avg: "O(n log n)", worst: "O(n log n)", space: "O(n)", stable: true, note: "Predictable; good for linked lists and external sorting." },
    "quick sort": { best: "O(n log n)", avg: "O(n log n)", worst: "O(n²)", space: "O(log n)", stable: false, note: "Fast in practice; worst case on bad pivots (randomise the pivot)." },
    "heap sort": { best: "O(n log n)", avg: "O(n log n)", worst: "O(n log n)", space: "O(1)", stable: false, note: "In place with a guaranteed bound, but poor cache behaviour." },
    "linear search": { best: "O(1)", avg: "O(n)", worst: "O(n)", space: "O(1)", note: "Works on unsorted data." },
    "binary search": { best: "O(1)", avg: "O(log n)", worst: "O(log n)", space: "O(1)", note: "Needs sorted random-access data." },
    "bfs": { best: "O(V+E)", avg: "O(V+E)", worst: "O(V+E)", space: "O(V)", note: "Shortest path in unweighted graphs." },
    "dfs": { best: "O(V+E)", avg: "O(V+E)", worst: "O(V+E)", space: "O(V)", note: "Cycle detection, topological order, components." },
    "dijkstra": { best: "O((V+E) log V)", avg: "O((V+E) log V)", worst: "O((V+E) log V)", space: "O(V)", note: "Non-negative edge weights only (binary heap)." },
    "hash table": { best: "O(1)", avg: "O(1)", worst: "O(n)", space: "O(n)", note: "Lookup/insert; worst case with many collisions." },
  };
})();
