/* Unity and C# knowledge notes (programming domain). Hand-written, reviewed summaries of well-known Unity behaviour. They are
   retrieved by EDOKnowledge/Retrieval with the same heuristic scorer as every other chapter. Not a substitute for the Unity manual
   for your exact Unity version: check the version in ProjectSettings/ProjectVersion.txt. */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  root.EDO_DOCS = root.EDO_DOCS || [];
  root.EDO_DOCS.push.apply(root.EDO_DOCS, [
 {
  "id": "prog-unity-core",
  "domain": "programming",
  "chapter": "Unity core",
  "title": "Unity: MonoBehaviour lifecycle and scripting",
  "tags": [
   "unity",
   "csharp",
   "monobehaviour",
   "lifecycle",
   "gameobject"
  ],
  "aliases": [
   "unity scripting",
   "monobehaviour",
   "awake start update",
   "unity basics"
  ],
  "summary": "A MonoBehaviour is a component on a GameObject. Unity calls its lifecycle methods by exact name; a typo means the method is silently never called.",
  "apis": [
   "Awake",
   "OnEnable",
   "Start",
   "Update",
   "FixedUpdate",
   "LateUpdate",
   "OnDisable",
   "OnDestroy",
   "Time.deltaTime",
   "Time.fixedDeltaTime",
   "GetComponent<T>()",
   "TryGetComponent",
   "Instantiate",
   "Destroy",
   "SerializeField",
   "RequireComponent"
  ],
  "patterns": [
   "Cache GetComponent results in Awake.",
   "Use Awake for self-setup and Start for things that need other objects.",
   "Multiply per-frame movement by Time.deltaTime.",
   "Put physics in FixedUpdate and input reads in Update."
  ],
  "debug": [
   "If a method never runs, check its exact spelling and casing (update is not Update).",
   "Check the component is enabled and the GameObject is active in the hierarchy.",
   "Check Time.timeScale is not 0.",
   "NullReferenceException: a serialized field was never assigned in the Inspector, or the object was destroyed."
  ],
  "perf": [
   "Do not call Find, FindObjectOfType or GetComponent every frame.",
   "Avoid allocations in Update."
  ],
  "mistakes": [
   "Typos in lifecycle method names.",
   "Forgetting Time.deltaTime so speed depends on frame rate.",
   "Reading a field in Awake that another script sets in Awake (order is not guaranteed)."
  ],
  "prereqs": [
   "C# basics"
  ],
  "difficulty": "beginner",
  "content": "Unity runs Awake, OnEnable, Start once in that order for each component, then Update every frame, FixedUpdate at the physics step, LateUpdate after all Updates. Fields that are public or marked [SerializeField] are saved with the scene or prefab, so their Inspector value overrides the default written in code."
 },
 {
  "id": "prog-unity-input",
  "domain": "programming",
  "chapter": "Unity input",
  "title": "Unity input: Input System, legacy Input, mobile touch controls",
  "tags": [
   "unity",
   "input",
   "touch",
   "joystick",
   "mobile",
   "inputsystem"
  ],
  "aliases": [
   "unity input system",
   "new input system",
   "touch controls",
   "virtual joystick",
   "on screen stick"
  ],
  "summary": "Unity has the legacy Input class and the newer Input System package. They are different APIs and the project must have the matching one enabled.",
  "apis": [
   "Input.GetAxis",
   "Input.GetKey",
   "Input.touches",
   "Input.GetTouch",
   "InputAction",
   "PlayerInput",
   "OnScreenStick",
   "OnScreenButton",
   "InputAction.ReadValue<Vector2>()",
   "Touchscreen.current"
  ],
  "patterns": [
   "Read input in Update, apply forces in FixedUpdate.",
   "Use OnScreenStick for virtual joysticks with the Input System.",
   "Use the EventSystem and an Input module that matches your active input handling."
  ],
  "debug": [
   "Nothing responds: Project Settings > Player > Active Input Handling may be set to the other system.",
   "UI does not react: the scene needs an EventSystem with the right input module.",
   "Touch works in editor with mouse but not on device: test with Touchscreen, not Mouse."
  ],
  "perf": [
   "Do not poll all touches with allocations each frame."
  ],
  "mistakes": [
   "Mixing legacy Input calls with a project set to Input System only (throws InvalidOperationException).",
   "Reading input in FixedUpdate and missing key presses."
  ],
  "prereqs": [
   "Unity core"
  ],
  "difficulty": "intermediate",
  "content": "With the Input System package, define an Input Actions asset, generate or reference it, and read values from actions. For mobile, add on-screen controls bound to the same actions as the gamepad so one code path serves both."
 },
 {
  "id": "prog-unity-physics",
  "domain": "programming",
  "chapter": "Unity physics",
  "title": "Unity physics: Rigidbody, colliders, layers",
  "tags": [
   "unity",
   "physics",
   "rigidbody",
   "collider",
   "layers",
   "trigger"
  ],
  "aliases": [
   "rigidbody",
   "collision",
   "oncollisionenter",
   "ontriggerenter",
   "kinematic",
   "falls through floor"
  ],
  "summary": "Physics objects need a Collider; moving ones need a Rigidbody. Trigger and collision callbacks only fire when specific component combinations exist.",
  "apis": [
   "Rigidbody.velocity",
   "Rigidbody.linearVelocity",
   "Rigidbody.AddForce",
   "Rigidbody.MovePosition",
   "isKinematic",
   "Collider.isTrigger",
   "OnCollisionEnter",
   "OnTriggerEnter",
   "Physics.Raycast",
   "LayerMask",
   "Physics.IgnoreLayerCollision",
   "CharacterController.Move"
  ],
  "patterns": [
   "Move Rigidbodies with forces or MovePosition in FixedUpdate.",
   "Use layers and the collision matrix to cut work.",
   "Use CharacterController or a kinematic Rigidbody for controlled characters."
  ],
  "debug": [
   "Falls through the floor: missing Collider on either object, a very thin collider, tunnelling at high speed (use continuous detection), or the floor is on a layer that ignores the player.",
   "OnTriggerEnter never fires: at least one object needs a Rigidbody and one collider must have isTrigger on.",
   "Rigidbody ignores your code: isKinematic is on, or the position is also written through transform.",
   "Jitter: moving the transform directly while a Rigidbody exists."
  ],
  "perf": [
   "Avoid per-frame Physics.OverlapSphere allocations; use the NonAlloc versions."
  ],
  "mistakes": [
   "Setting transform.position on a Rigidbody object.",
   "Expecting collision callbacks between two static colliders.",
   "Using Update for physics forces."
  ],
  "prereqs": [
   "Unity core"
  ],
  "difficulty": "intermediate",
  "content": "Collision callbacks require a Rigidbody on at least one of the two objects. A kinematic Rigidbody is moved by script and still produces trigger events. Set Collision Detection to Continuous or Continuous Dynamic for fast small objects."
 },
 {
  "id": "prog-unity-ui",
  "domain": "programming",
  "chapter": "Unity UI",
  "title": "Unity UI: Canvas, EventSystem, TextMeshPro, layouts",
  "tags": [
   "unity",
   "ui",
   "canvas",
   "eventsystem",
   "textmeshpro",
   "layout"
  ],
  "aliases": [
   "ugui",
   "canvas scaler",
   "button not clicking",
   "tmp",
   "ui toolkit"
  ],
  "summary": "uGUI needs a Canvas, a Graphic Raycaster and a scene EventSystem. Many 'button does nothing' bugs are one of those missing.",
  "apis": [
   "Canvas",
   "CanvasScaler",
   "GraphicRaycaster",
   "EventSystem",
   "Button.onClick",
   "TMP_Text",
   "LayoutGroup",
   "RectTransform",
   "SafeArea"
  ],
  "patterns": [
   "Use Canvas Scaler with Scale With Screen Size for phones.",
   "Respect Screen.safeArea for notches.",
   "Keep one Canvas per update frequency to avoid rebuilding everything."
  ],
  "debug": [
   "Button not clickable: no EventSystem, a transparent Image above it blocking raycasts, or Raycast Target off.",
   "Text blurry on phones: use TextMeshPro, not legacy Text.",
   "Layout wrong between devices: anchors not set, or Canvas Scaler reference resolution mismatched."
  ],
  "perf": [
   "Changing any element dirties its whole Canvas; split static and dynamic UI."
  ],
  "mistakes": [
   "Deleting the EventSystem.",
   "Stretching UI with absolute positions instead of anchors."
  ],
  "prereqs": [
   "Unity core"
  ],
  "difficulty": "beginner",
  "content": "Layout groups recompute when children change, so do not put one on a huge scrolling list; use a recycling list. For notch devices, apply Screen.safeArea to a container RectTransform."
 },
 {
  "id": "prog-unity-data",
  "domain": "programming",
  "chapter": "Unity data",
  "title": "Unity serialization: prefabs, ScriptableObject, scene references",
  "tags": [
   "unity",
   "serialization",
   "prefab",
   "scriptableobject",
   "inspector",
   "references"
  ],
  "aliases": [
   "serializefield",
   "scriptable object",
   "missing reference",
   "prefab variant",
   "inspector value overrides"
  ],
  "summary": "Serialized fields are stored in the scene or prefab, so the Inspector value wins over the default in code. Missing references are a top source of NullReferenceException.",
  "apis": [
   "SerializeField",
   "HideInInspector",
   "ScriptableObject",
   "CreateAssetMenu",
   "PrefabUtility",
   "Resources.Load",
   "Addressables",
   "AssetDatabase"
  ],
  "patterns": [
   "Put shared tunable data (enemy stats) in ScriptableObjects.",
   "Reference prefabs by serialized field, not Resources.Load strings.",
   "Validate required references in OnValidate or Awake and log a clear error."
  ],
  "debug": [
   "A speed or health value 'ignores' the code: the scene or prefab stores a different serialized value (often 0).",
   "Missing (Script): the script file was renamed or its class name no longer matches the filename.",
   "Reference becomes null at runtime: the target was in another scene or destroyed."
  ],
  "mistakes": [
   "Class name different from file name for a MonoBehaviour.",
   "Changing a field's name loses its serialized value (use FormerlySerializedAs)."
  ],
  "prereqs": [
   "Unity core"
  ],
  "difficulty": "intermediate",
  "content": "A MonoBehaviour's class name must match its file name. Renaming a serialized field drops saved data unless [FormerlySerializedAs] is added. Private fields need [SerializeField] to appear in the Inspector."
 },
 {
  "id": "prog-unity-perf",
  "domain": "programming",
  "chapter": "Unity performance",
  "title": "Unity performance: pooling, allocations, profiling for mobile",
  "tags": [
   "unity",
   "performance",
   "pooling",
   "gc",
   "profiler",
   "mobile",
   "allocation"
  ],
  "aliases": [
   "object pooling",
   "garbage collection spikes",
   "frame rate",
   "optimise unity",
   "batching"
  ],
  "summary": "On phones, frame drops usually come from garbage-collector spikes, per-frame lookups, too many draw calls, or instantiating and destroying in gameplay.",
  "apis": [
   "ObjectPool<T>",
   "Instantiate",
   "Destroy",
   "SetActive",
   "Profiler",
   "Application.targetFrameRate",
   "QualitySettings",
   "StaticBatching",
   "NonAlloc"
  ],
  "patterns": [
   "Pool bullets, enemies and effects with ObjectPool or a simple stack.",
   "Cache components and avoid string concatenation, LINQ and new in Update.",
   "Profile on the device first; measure before optimising."
  ],
  "debug": [
   "Periodic stutter: GC.Collect spikes in the Profiler timeline.",
   "High CPU in Update: look for Find or GetComponent in hot paths.",
   "GPU bound: reduce overdraw, transparency, real-time lights and draw calls."
  ],
  "perf": [
   "Use Instantiate rarely during play.",
   "Prefer struct and non-allocating APIs in hot loops.",
   "Disable what is off-screen."
  ],
  "mistakes": [
   "Calling Camera.main or FindObjectOfType in Update on old Unity versions.",
   "Instantiate and Destroy for every bullet.",
   "Debug.Log inside Update in release builds."
  ],
  "prereqs": [
   "Unity core"
  ],
  "difficulty": "advanced",
  "content": "Object pooling keeps inactive instances and reuses them with SetActive, avoiding allocation and Destroy cost. Use the Unity Profiler connected to a development build on the real device, not the editor, for numbers you can trust."
 },
 {
  "id": "prog-unity-ai",
  "domain": "programming",
  "chapter": "Unity AI",
  "title": "Unity AI: NavMesh, steering, state machines",
  "tags": [
   "unity",
   "ai",
   "navmesh",
   "navmeshagent",
   "enemy",
   "pathfinding",
   "statemachine"
  ],
  "aliases": [
   "enemy ai",
   "navmesh agent",
   "enemy not moving",
   "npc movement",
   "chase player",
   "patrol"
  ],
  "summary": "NavMeshAgent moves along a baked NavMesh. An agent without a baked mesh, without a destination, or stopped will not move.",
  "apis": [
   "NavMeshAgent.SetDestination",
   "NavMeshAgent.isStopped",
   "NavMeshAgent.speed",
   "NavMeshAgent.remainingDistance",
   "NavMeshAgent.isOnNavMesh",
   "NavMesh.SamplePosition",
   "NavMeshObstacle",
   "Vector3.MoveTowards",
   "Animator"
  ],
  "patterns": [
   "Use a small state machine (Idle, Patrol, Chase, Attack) with explicit transitions.",
   "Update destinations at an interval, not every frame.",
   "Use a LayerMask-limited line-of-sight check."
  ],
  "debug": [
   "Enemy does not move: the NavMesh is not baked, the agent is off the mesh (isOnNavMesh false), isStopped is true, speed is 0 in the Inspector, no destination is set, the target reference is null, or the script is disabled.",
   "Agent slides or jitters: both a Rigidbody and an agent drive the same transform; make the Rigidbody kinematic.",
   "Agent stops early: stoppingDistance is larger than expected."
  ],
  "perf": [
   "Calling SetDestination every frame for many agents is expensive; throttle it."
  ],
  "mistakes": [
   "Moving the transform of a NavMeshAgent object by hand.",
   "Forgetting to bake the NavMesh after changing the level."
  ],
  "prereqs": [
   "Unity core",
   "Unity physics"
  ],
  "difficulty": "intermediate",
  "content": "Without NavMesh, simple chase can use Vector3.MoveTowards or a Rigidbody toward the target inside FixedUpdate. Always null-check the target and guard against zero speed."
 },
 {
  "id": "prog-csharp",
  "domain": "programming",
  "chapter": "C# language",
  "title": "C# rules that matter in Unity and apps",
  "tags": [
   "csharp",
   "dotnet",
   "language",
   "async",
   "nullable",
   "linq",
   "coroutine"
  ],
  "aliases": [
   "c sharp",
   "c#",
   "coroutines vs async",
   "nullreferenceexception",
   "properties"
  ],
  "summary": "C# is statically typed and garbage collected. Most runtime bugs in Unity code are NullReferenceException and misuse of coroutines or async.",
  "apis": [
   "IEnumerator",
   "StartCoroutine",
   "yield return",
   "async Task",
   "Awaitable",
   "?. operator",
   "?? operator",
   "List<T>",
   "Dictionary<K,V>",
   "LINQ",
   "readonly",
   "const"
  ],
  "patterns": [
   "Prefer properties over public fields for logic.",
   "Use the ?. operator carefully: Unity objects overload == null, and ?. bypasses that check.",
   "Use TryGetValue for dictionaries."
  ],
  "debug": [
   "NullReferenceException: find which reference is null from the line in the stack trace; check Inspector assignment first.",
   "Coroutine stops: the GameObject was disabled or destroyed, or StopAllCoroutines was called.",
   "KeyNotFoundException: use TryGetValue."
  ],
  "security": [
   "Never build SQL by string concatenation.",
   "Do not deserialize untrusted data with BinaryFormatter.",
   "Do not store secrets in the client build."
  ],
  "mistakes": [
   "Using ?. on UnityEngine.Object (bypasses destroyed-object check).",
   "Modifying a collection while iterating it.",
   "Blocking the main thread with .Result."
  ],
  "prereqs": [],
  "difficulty": "beginner",
  "content": "Coroutines are tied to a MonoBehaviour and stop when it is disabled. async/await runs on the main thread in Unity unless you switch contexts, and does not stop when the object is destroyed unless you check."
 }
]);
})();
