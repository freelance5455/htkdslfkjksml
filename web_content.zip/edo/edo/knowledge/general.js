/* General identity and study notes. */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  root.EDO_DOCS = root.EDO_DOCS || [];
  root.EDO_DOCS.push({
    id: "gen-edo",
    domain: "general",
    chapter: "Identity",
    title: "What EDO is",
    tags: ["edo", "assistant", "identity"],
    summary: "EDO is a local programming and JEE/MPC reasoning engine with optional device capabilities.",
    content: "Pipeline: intent, retrieval, solution, verification, response. Device tools (location, voice, Android bridge, web) are optional and never required for formula or code reasoning. EDO does not invent sources, locations, or test results.",
  });
})();
