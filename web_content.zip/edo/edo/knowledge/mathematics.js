/* Mathematics chapter notes for JEE/MPC retrieval. Executable equations stay in formulas.js. */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  root.EDO_DOCS = root.EDO_DOCS || [];
  root.EDO_DOCS.push(
    {
      id: "math-quad",
      domain: "mathematics",
      chapter: "Quadratic equations",
      title: "Roots and discriminant",
      tags: ["quadratic", "discriminant", "algebra"],
      summary: "A quadratic ax^2+bx+c=0 has discriminant D=b^2-4ac.",
      formulas: [{ name: "roots", latex: "x = (-b ± sqrt(D)) / (2a)" }, { name: "discriminant", latex: "D = b^2 - 4ac" }],
      content: "D>0 two real roots, D=0 one repeated root, D<0 no real root. Ask `a=1 b=-3 c=2 find x` to use the formula engine.",
    },
    {
      id: "math-series",
      domain: "mathematics",
      chapter: "Sequences",
      title: "AP and GP",
      tags: ["arithmetic", "geometric", "series"],
      summary: "AP has constant difference; GP has constant ratio.",
      formulas: [{ name: "AP term", latex: "a_n = a + (n-1)d" }, { name: "GP sum", latex: "S_n = a(r^n-1)/(r-1)" }],
      content: "State first term, difference or ratio, and n before substituting. The formula table can solve an, Sn when the other symbols are given.",
    },
    {
      id: "math-trig",
      domain: "mathematics",
      chapter: "Trigonometry",
      title: "Identities and equations",
      tags: ["sin", "trigonometry", "identity"],
      summary: "sin^2 x + cos^2 x = 1. Degree and radian modes must not be mixed.",
      formulas: [{ name: "identity", latex: "sin^2 x + cos^2 x = 1" }],
      content: "For sin x = 1/2 on an interval, the sentence solver uses the general solution and filters the interval. The formula engine's sind/cosd take degrees.",
    }
  );
})();
