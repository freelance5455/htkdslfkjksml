/* Programming knowledge notes. Retrieved by EDOKnowledge; not tied to UI. */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  root.EDO_DOCS = root.EDO_DOCS || [];
  root.EDO_DOCS.push(
    {
      id: "prog-web",
      domain: "programming",
      chapter: "Web",
      title: "HTML, CSS, JavaScript",
      tags: ["html", "css", "javascript", "typescript", "react"],
      summary: "Structure, presentation, and behavior stay separate.",
      pitfalls: ["Do not insert unsanitized HTML.", "TypeScript types disappear at runtime.", "Abort in-flight work when a view goes away."],
      content: "HTML describes structure, CSS presentation, JavaScript behavior. Prefer flex or grid over absolute positioning. Keep functions small and handle loading and error states.",
    },
    {
      id: "prog-backend",
      domain: "programming",
      chapter: "Backend",
      title: "APIs, SQL, and architecture",
      tags: ["api", "sql", "git", "architecture"],
      summary: "Isolate I/O and validate at the trust boundary.",
      pitfalls: ["Never concatenate SQL with user input.", "Do not put secrets in a frontend bundle."],
      content: "REST uses nouns and proper status codes. Parameterized queries only. Small commits. The reasoning core of EDO does not import UI, voice, or the Android bridge.",
    },
    {
      id: "prog-languages",
      domain: "programming",
      chapter: "Languages",
      title: "Python, C, Java, Kotlin",
      tags: ["python", "c", "java", "kotlin", "bash"],
      summary: "Language-specific safety rules.",
      pitfalls: ["Python mutable default arguments.", "C buffer overruns.", "Bash unquoted variables."],
      content: "Python: virtual environments and context managers. C: own every allocation. Kotlin: null safety and no blocking work on the Android main thread.",
    }
  );
})();
