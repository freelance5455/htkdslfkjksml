/* Physics chapter notes. Numeric templates remain in solver.js. */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  root.EDO_DOCS = root.EDO_DOCS || [];
  root.EDO_DOCS.push(
    {
      id: "phy-kin",
      domain: "physics",
      chapter: "Kinematics",
      title: "Constant acceleration",
      tags: ["kinematics", "velocity", "projectile"],
      summary: "Five symbols u, v, a, t, s; three independent equations.",
      formulas: [{ name: "v", latex: "v = u + at" }, { name: "s", latex: "s = ut + (1/2)at^2" }, { name: "v2", latex: "v^2 = u^2 + 2as" }],
      content: "Convert km/h to m/s before substituting. The sentence solver does that and checks the unused kinematic equation.",
    },
    {
      id: "phy-grav",
      domain: "physics",
      chapter: "Gravitation",
      title: "Newton gravity and orbits",
      tags: ["gravitation", "escape", "orbit"],
      summary: "Inverse-square force. Escape and orbit speeds follow from energy and centripetal balance.",
      formulas: [{ name: "force", latex: "F = G m1 m2 / r^2" }, { name: "escape", latex: "v_e = sqrt(2GM/R)" }],
      content: "G is in the constant table. Give M and R in SI if you ask the formula engine for ve.",
    },
    {
      id: "phy-electro",
      domain: "physics",
      chapter: "Electrostatics",
      title: "Coulomb and potential",
      tags: ["electrostatics", "coulomb", "current"],
      summary: "Coulomb force uses ke. Ohm's law is a separate circuit relation.",
      formulas: [{ name: "coulomb", latex: "F = ke q1 q2 / r^2" }],
      content: "Do not mix electrostatic force with magnetic force. State the medium if it is not vacuum.",
    }
  );
})();
