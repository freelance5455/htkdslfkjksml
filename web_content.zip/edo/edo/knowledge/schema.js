/* Compact chapter-note builder. EDOK.add(domain, chapter, spec) pushes a doc into EDO_DOCS.
   spec: al aliases[], sum summary, f ["name: expr"], ex exceptions[], tr traps[], me solved-method patterns[],
   mi common JEE mistakes[], pre prerequisite chapters[], un units/conversions[], ap approximation rules[], tags[]. Load before chapter files. */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  root.EDO_DOCS = root.EDO_DOCS || [];
  const slug = (s) => String(s).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
  function add(domain, chapter, o) {
    o = o || {};
    const doc = {
      id: (domain.slice(0, 4) + "-" + slug(chapter)).slice(0, 48), domain, chapter, title: o.t || chapter,
      tags: o.tags || [], aliases: o.al || [], summary: o.sum || "",
      formulas: (o.f || []).map((x) => { const i = x.indexOf(":"); return { name: x.slice(0, i).trim(), latex: x.slice(i + 1).trim() }; }),
      exceptions: o.ex || [], traps: o.tr || [], methods: o.me || [], mistakes: o.mi || [], prereqs: o.pre || [], units: o.un || [], approx: o.ap || [],
      content: o.c || (o.me || []).join(" "),
    };
    root.EDO_DOCS.push(doc);
    return doc;
  }
  root.EDOK = { add };
})();
