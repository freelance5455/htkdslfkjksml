/* Chemistry chapter notes. pH templates remain in solver.js. */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  root.EDO_DOCS = root.EDO_DOCS || [];
  root.EDO_DOCS.push(
    {
      id: "chem-mole",
      domain: "chemistry",
      chapter: "Mole concept",
      title: "Mass, moles, molarity",
      tags: ["mole", "molarity", "stoichiometry"],
      summary: "n = w/M and molarity = n/V, with V in litres for mol/L.",
      formulas: [{ name: "moles", latex: "n = w/M" }, { name: "molarity", latex: "M = n/V" }],
      content: "The formula table uses Mol for molarity so it does not clash with mass M. Watch litre versus cubic metre.",
    },
    {
      id: "chem-eq",
      domain: "chemistry",
      chapter: "Equilibrium",
      title: "Acids and pH",
      tags: ["ph", "acid", "equilibrium", "ka"],
      summary: "For a weak acid, [H+] is about sqrt(Ka*C) when x << C.",
      formulas: [{ name: "pH", latex: "pH = -log[H+]" }],
      content: "The sentence solver handles acetic-acid style problems and checks the approximation. It withholds the answer if the check fails.",
    },
    {
      id: "chem-thermo",
      domain: "chemistry",
      chapter: "Thermodynamics",
      title: "Gibbs energy",
      tags: ["gibbs", "enthalpy", "entropy"],
      summary: "dG = dH - T dS. Sign of dG indicates spontaneity at that T.",
      formulas: [{ name: "gibbs", latex: "ΔG = ΔH - TΔS" }],
      content: "Keep T in kelvin. Do not treat a negative dG as a rate.",
    }
  );
})();
