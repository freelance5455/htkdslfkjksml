/* EDO formula knowledge. Add rows with f(subject, chapter, name, equation, keywords).
   Equation syntax: LHS=RHS using * / ^ and sqrt sin cos tan sind cosd tand ln log exp abs pi.
   sind/cosd/tand take degrees. A leading "~" marks a reference-only entry (shown, never solved). */
(function(){
const S={P:'Physics',C:'Chemistry',M:'Maths'},F=[];
const f=(s,c,n,e,k)=>F.push({s:S[s],c,n,e,k:k||''});
window.EDO_CONSTS={g:9.8,Rgas:8.314,G:6.674e-11,c0:3e8,h:6.626e-34,NA:6.022e23,ke:8.99e9,qe:1.6e-19};
// Physics
f('P','Kinematics','Final velocity','v=u+a*t','velocity acceleration time uniform');
f('P','Kinematics','Displacement','s=u*t+0.5*a*t^2','distance displacement');
f('P','Kinematics','Velocity-displacement','v^2=u^2+2*a*s','velocity displacement');
f('P','Kinematics','Projectile range','Rn=u^2*sind(2*th)/g','projectile range angle');
f('P','Kinematics','Projectile max height','H=u^2*sind(th)^2/(2*g)','projectile height');
f('P','Laws of Motion','Newton second law','F=m*a','force mass acceleration');
f('P','Laws of Motion','Friction','ff=mu*N','friction coefficient normal');
f('P','Laws of Motion','Momentum','p=m*v','momentum');
f('P','Work Energy Power','Work','W=F*d*cosd(th)','work force displacement');
f('P','Work Energy Power','Kinetic energy','KE=0.5*m*v^2','kinetic energy');
f('P','Work Energy Power','Potential energy','PE=m*g*h','potential energy height');
f('P','Work Energy Power','Power','Pw=W/t','power work time');
f('P','Rotational Motion','Torque','tau=I*alpha','torque moment inertia');
f('P','Rotational Motion','Angular momentum','L=I*w','angular momentum');
f('P','Rotational Motion','Rotational KE','KE=0.5*I*w^2','rotational kinetic energy');
f('P','Rotational Motion','Centripetal acceleration','ac=v^2/r','circular centripetal');
f('P','Gravitation','Newton gravitation','F=G*m1*m2/r^2','gravitation force masses');
f('P','Gravitation','Escape velocity','ve=sqrt(2*G*M/r)','escape velocity');
f('P','Properties of Matter','Pressure at depth','P=P0+rho*g*h','pressure fluid depth density');
f('P','Thermodynamics','Heat','Q=m*c*dT','heat specific capacity');
f('P','Thermodynamics','Ideal gas','P*V=n*Rgas*T','ideal gas pressure volume');
f('P','Thermodynamics','Carnot efficiency','eta=1-Tc/Th','carnot efficiency engine');
f('P','SHM','Spring period','T=2*pi*sqrt(m/k)','spring oscillation period');
f('P','SHM','Pendulum period','T=2*pi*sqrt(l/g)','simple pendulum period');
f('P','SHM','Angular frequency','w=2*pi/T','angular frequency');
f('P','Waves','Wave speed','v=fr*lam','wave frequency wavelength');
f('P','Electrostatics','Coulomb force','F=ke*q1*q2/r^2','coulomb charge force');
f('P','Electrostatics','Field of point charge','E=ke*q/r^2','electric field');
f('P','Electrostatics','Potential of point charge','V=ke*q/r','electric potential');
f('P','Electrostatics','Capacitor','Q=C*V','capacitance charge');
f('P','Current Electricity','Ohm law','V=I*Rr','ohm resistance current');
f('P','Current Electricity','Electric power','Pw=V*I','power voltage current');
f('P','Magnetism','Magnetic force on charge','F=q*v*B*sind(th)','magnetic force lorentz');
f('P','EMI','Motional emf','emf=B*l*v','induced emf motional');
f('P','Ray Optics','Lens formula (Cartesian)','1/f=1/v-1/u','lens focal image object');
f('P','Ray Optics','Mirror formula (Cartesian)','1/f=1/v+1/u','mirror focal image object');
f('P','Ray Optics','Snell law','n1*sind(i)=n2*sind(r)','refraction snell');
f('P','Modern Physics','Photon energy','E=h*fr','photon energy planck');
f('P','Modern Physics','de Broglie','lam=h/p','de broglie wavelength');
f('P','Modern Physics','Photoelectric effect','KEmax=h*fr-phi','photoelectric work function');
f('P','Modern Physics','Bohr energy (eV)','En=-13.6*Z^2/n^2','bohr hydrogen atom energy level');
// Chemistry
f('C','Mole Concept','Moles from mass','n=w/Mm','mole mass molar');
f('C','Solutions','Molarity','Mol=n/V','molarity concentration');
f('C','Solutions','Raoult law','P=x*P0','raoult vapour pressure');
f('C','Solutions','Boiling point elevation','dTb=Kb*m','colligative boiling elevation');
f('C','Ionic Equilibrium','pH','pH=-log(H)','ph acid hydrogen ion');
f('C','Electrochemistry','Nernst (298 K)','E=E0-0.0592/n*log(Q)','nernst cell potential');
f('C','Chemical Kinetics','First-order rate constant','k=2.303/t*log(A0/A)','first order rate');
f('C','Chemical Kinetics','First-order half-life','thalf=0.693/k','half life');
f('C','Thermodynamics','Gibbs energy','dG=dH-T*dS','gibbs enthalpy entropy spontaneity');
f('C','Chemical Equilibrium','Gibbs and K','dG=-Rgas*T*ln(K)','equilibrium constant gibbs');
// Mathematics
f('M','Quadratic Equations','Quadratic root (+)','x=(-b+sqrt(b^2-4*a*c))/(2*a)','quadratic root');
f('M','Quadratic Equations','Discriminant','D=b^2-4*a*c','discriminant');
f('M','Sequences and Series','AP nth term','an=a+(n-1)*d','arithmetic progression term');
f('M','Sequences and Series','AP sum','Sn=n/2*(2*a+(n-1)*d)','arithmetic progression sum');
f('M','Sequences and Series','GP sum','Sn=a*(r^n-1)/(r-1)','geometric progression sum');
f('M','Straight Lines','Distance between points','d=sqrt((x2-x1)^2+(y2-y1)^2)','distance points coordinate');
f('M','Straight Lines','Point-line distance','dl=abs(A*x1+B*y1+C)/sqrt(A^2+B^2)','distance point line');
f('M','Circles','Circle area','Ar=pi*r^2','circle area');
f('M','Trigonometry','Identity','~sin(x)^2+cos(x)^2=1','trigonometry identity');
f('M','Differentiation','Power rule','~d/dx(x^n)=n*x^(n-1)','derivative power');
f('M','Differentiation','Product rule','~d/dx(u*v)=u*dv/dx+v*du/dx','derivative product');
f('M','Differentiation','Trig derivatives','~d/dx(sin x)=cos x ; d/dx(cos x)=-sin x','derivative trig');
f('M','Integration','Power rule','~integral x^n dx = x^(n+1)/(n+1) + C, n != -1','integral power');
f('M','Binomial Theorem','General term','~T(r+1)=nCr*a^(n-r)*b^r','binomial term');
f('M','Probability','Addition rule','~P(A or B)=P(A)+P(B)-P(A and B)','probability union');
f('M','Vectors','Dot product','~a.b=|a||b|cos(theta)','vector dot product');
// Merged executable relations from the workspace knowledge notes.
f('P','Gravitation','Escape speed','ve=sqrt(2*G*M/R)','escape velocity gravitation');
f('P','Gravitation','Orbital speed','vo=sqrt(G*M/r)','orbital velocity circular');
f('P','Oscillations','Spring period','Ts=2*pi*sqrt(m/k)','shm spring period');
f('P','Oscillations','Pendulum period','Tp=2*pi*sqrt(l/g)','simple pendulum period');
f('P','Laws of Motion','Centripetal force','Fc=m*v^2/r','centripetal force circular');
f('P','Current Electricity','Ohm law','Vohm=I*R','ohm voltage current resistance');
f('P','Thermodynamics','Carnot efficiency','eta=1-Tc/Th','carnot efficiency heat engine');
f('C','Ionic Equilibrium','Weak acid hydrogen','H=sqrt(Ka*C)','weak acid approximation ka');
window.EDO_FORMULAS=F;
})();
