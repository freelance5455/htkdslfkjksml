/* EDO context-aware retrieval. A layer over EDOKnowledge.rank (the existing field-weighted scorer) that adds:
   semantic fallback (a note whose words are only synonyms of the query is still found), context boosts (mode, subject, language,
   Unity project, active file), a prerequisite graph (what to know first, what comes next) and difficulty ordering.
   Heuristic ranking, not a neural embedding model; every hit says why it ranked. Globals: window.Retrieval */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  const docs = () => root.EDO_DOCS || [];
  const LEVEL = { beginner: 1, intermediate: 2, advanced: 3 };
  const LANG_TAGS = { csharp: ["csharp", "c#", "unity"], javascript: ["javascript", "js"], python: ["python"], java: ["java"], kotlin: ["kotlin"], cpp: ["cpp", "c++"], c: ["c"] };
  const byChapter = (name) => docs().filter((d) => String(d.chapter).toLowerCase() === String(name).toLowerCase());

  /* search(query, {mode, subject, languages, unity, limit}) → [{doc, score, why[]}] */
  function search(query, ctx) {
    ctx = ctx || {};
    const limit = ctx.limit || 5, by = new Map();
    const put = (doc, score, why) => { const e = by.get(doc.id) || { doc, score: 0, why: [] }; e.score += score; if (why) e.why.push(why); by.set(doc.id, e); };
    if (root.EDOKnowledge && root.EDOKnowledge.rank) root.EDOKnowledge.rank(query, { limit: 30 }).forEach((r) => put(r.doc, r.score, "keyword match"));
    if (root.Semantic) root.Semantic.rank(query, docs(), (d) => [d.title, (d.aliases || []).join(" "), (d.tags || []).join(" "), d.summary].join(" "), { limit: 12, min: 0.5 }).forEach((r) => { const e = by.get(r.item.id); if (!e) put(r.item, r.score * 5, "similar meaning"); else if (e.score < 6) e.score += r.score; });
    const q = String(query).toLowerCase();
    by.forEach((e) => {
      const d = e.doc, tags = (d.tags || []).map((t) => String(t).toLowerCase());
      if ((ctx.unity || /\bunity\b/.test(q)) && tags.includes("unity")) { e.score += 4; e.why.push("Unity context"); }
      if (ctx.subject && d.domain === ctx.subject) { e.score += 3; e.why.push("your subject: " + ctx.subject); }
      if (/^programming$/i.test(ctx.mode || "")) { if (d.domain === "programming") { e.score += 2; e.why.push("Programming mode"); } else e.score -= 2; }
      (ctx.languages || []).forEach((l) => { if ((LANG_TAGS[l] || [l]).some((t) => tags.includes(t))) { e.score += 2; e.why.push("project language: " + l); } });
    });
    return [...by.values()].filter((e) => e.score > 0).sort((a, b) => b.score - a.score).slice(0, limit).map((e) => ({ doc: e.doc, score: Math.round(e.score * 100) / 100, why: [...new Set(e.why)] }));
  }
  const prereqDocs = (d) => (d.prereqs || []).flatMap((p) => byChapter(p));
  const nextDocs = (d) => docs().filter((x) => (x.prereqs || []).some((p) => String(p).toLowerCase() === String(d.chapter).toLowerCase()));
  function related(id) {
    const d = docs().find((x) => x.id === id);
    if (!d) return null;
    return { prerequisites: prereqDocs(d), next: nextDocs(d), sameChapter: docs().filter((x) => x.chapter === d.chapter && x.id !== d.id), sameDomain: docs().filter((x) => x.domain === d.domain && x.id !== d.id && (x.tags || []).some((t) => (d.tags || []).includes(t))).slice(0, 5) };
  }
  /* learning order: prerequisites first (depth-first, no cycles), then the note itself */
  function path(id) {
    const d = docs().find((x) => x.id === id);
    if (!d) return [];
    const out = [], seen = new Set();
    (function visit(x) { if (seen.has(x.id)) return; seen.add(x.id); prereqDocs(x).sort((a, b) => (LEVEL[a.difficulty] || 2) - (LEVEL[b.difficulty] || 2)).forEach(visit); out.push(x); })(d);
    return out;
  }
  function addAliases(map) {
    Object.keys(map || {}).forEach((canon) => { const group = [canon].concat(map[canon]); if (root.Semantic) root.Semantic.addConcepts([group]); docs().forEach((d) => { if (String(d.title).toLowerCase().includes(canon.toLowerCase()) || (d.aliases || []).some((a) => a.toLowerCase() === canon.toLowerCase())) d.aliases = [...new Set((d.aliases || []).concat(map[canon]))]; }); });
  }
  root.Retrieval = { search, related, path, addAliases, LEVEL };
})();
