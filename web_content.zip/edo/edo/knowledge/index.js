/* Knowledge retriever over EDO_DOCS. HEURISTIC weighted lexical ranking (not a neural model):
   per-field weights (title, aliases, chapter, tags > summary > body), IDF weighting, light stemming, stopwords,
   alias/synonym query expansion, and a small prerequisite lookup. search() keeps the old {doc, score} shape. */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  const STOP = new Set(("the and for are but not you your with from that this these those what when where which who whom whose why how " +
    "can could would should will shall may might must was were been being have has had does did done doing about into onto over under " +
    "than then them they their there here some any all each every more most much many very just also only like such own same other " +
    "explain tell give show please need want make find get let use using used causes cause detail details sentences sentence word words").split(/\s+/));
  /* query expansion: a short token maps to extra tokens that appear in chapter text */
  const SYN = {
    shm: "simple harmonic oscillation oscillations", emi: "electromagnetic induction faraday lenz", ac: "alternating current", dc: "direct current",
    com: "centre mass", nlm: "newton laws motion", lom: "laws motion", ke: "kinetic energy", pe: "potential energy", gpe: "gravitational potential energy",
    ap: "arithmetic progression", gp: "geometric progression", hp: "harmonic progression", pnc: "permutations combinations", ncr: "combination", npr: "permutation",
    ph: "acid base hydrogen ionic equilibrium", poh: "hydroxide ionic equilibrium", ka: "weak acid ionic equilibrium", kb: "weak base ionic equilibrium", ksp: "solubility product ionic equilibrium",
    emf: "electromotive cell potential induced", ohm: "current electricity resistance", sn1: "haloalkane substitution", sn2: "haloalkane substitution", vsepr: "bonding shape geometry",
    "e/z": "isomerism", iupac: "nomenclature organic", jee: "", mpc: "", integral: "integration", integrate: "integration", derivative: "differentiation", differentiate: "differentiation",
    limit: "limits continuity", lim: "limits continuity", det: "determinant matrices", dot: "vectors scalar product", cross: "vectors vector product", torque: "rotation rotational",
    sho: "simple harmonic", doppler: "waves sound", snell: "refraction optics", lens: "optics ray", mirror: "optics ray", photoelectric: "modern physics photon", bohr: "atomic hydrogen modern",
    rate: "kinetics chemical", halflife: "kinetics half life", electrolysis: "electrochemistry faraday", nernst: "electrochemistry", molarity: "solutions mole concentration", molality: "solutions colligative",
    entropy: "thermodynamics", enthalpy: "thermodynamics thermochemistry", gibbs: "thermodynamics spontaneity", binomial: "binomial theorem expansion", quadratic: "quadratic equations roots discriminant",
    complex: "complex numbers argand", ellipse: "conic sections", parabola: "conic sections", hyperbola: "conic sections", tangent: "circle line slope", variance: "statistics", mean: "statistics",
  };
  const cache = new WeakMap();
  const tokens = (text) => String(text || "").toLowerCase().replace(/[’']/g, "").split(/[^a-z0-9]+/).filter(Boolean);
  const SUFFIX = /(ations|ation|ings|ing|ions|ion|ated|ates|ate|ally|als|al|ed|es|s|e)$/;
  const stem = (w) => { if (w.length < 5) return w; const r = w.replace(SUFFIX, ""); return r.length >= 4 ? r : w; };
  const FIELDS = [["title", 4], ["aliases", 3.5], ["chapter", 3], ["tags", 2.5], ["summary", 1.5], ["formulaText", 1.2], ["exceptions", 1], ["traps", 1], ["mistakes", 1], ["apis", 1.4], ["patterns", 1.2], ["debug", 1.3], ["perf", 1], ["security", 1], ["examples", 0.8], ["content", 1]];
  function fieldText(doc, f) {
    if (f === "aliases" || f === "tags" || f === "apis" || f === "patterns" || f === "debug" || f === "perf" || f === "security" || f === "examples") return (doc[f] || []).join(" ");
    if (f === "formulaText") return (doc.formulas || []).map((x) => x.name + " " + x.latex).join(" ");
    if (f === "exceptions" || f === "traps" || f === "mistakes") return (doc[f] || []).concat(doc.pitfalls || []).join(" ");
    return String(doc[f] || "") + (f === "content" ? " " + (doc.domain || "") : "");
  }
  function index(doc) {
    let ix = cache.get(doc);
    if (!ix) {
      ix = FIELDS.map(([f, w]) => { const arr = tokens(fieldText(doc, f)); return { w, set: new Set(arr.map(stem)), raw: new Set(arr) }; });
      cache.set(doc, ix);
    }
    return ix;
  }
  let idfCache = null, idfN = -1;
  function idf() {
    const docs = root.EDO_DOCS || [];
    if (idfCache && idfN === docs.length) return idfCache;
    const df = new Map();
    docs.forEach((d) => { const seen = new Set(); index(d).forEach((f) => f.set.forEach((t) => seen.add(t))); seen.forEach((t) => df.set(t, (df.get(t) || 0) + 1)); });
    idfCache = { df, N: docs.length }; idfN = docs.length;
    return idfCache;
  }
  function expand(query) {
    const base = tokens(query).filter((w) => !STOP.has(w) && (w.length > 2 || SYN[w]));
    const extra = [];
    base.forEach((w) => { if (SYN[w]) extra.push.apply(extra, tokens(SYN[w])); });
    return { base, extra: extra.filter((w) => !STOP.has(w) && !base.includes(w)), text: tokens(query).join(" ") };
  }
  function scoreDoc(doc, q, I) {
    const ix = index(doc);
    let s = 0;
    const add = (w, mult) => {
      const st = stem(w), df = I.df.get(st) || 0, idfW = Math.log(1 + (I.N - df + 0.5) / (df + 0.5));
      let best = 0;
      for (const f of ix) {
        if (f.set.has(st) || f.raw.has(w)) best = Math.max(best, f.w);
        else if (w.length >= 5) { for (const t of f.set) if (t.length >= 5 && (t.startsWith(st) || st.startsWith(t))) { best = Math.max(best, f.w * 0.6); break; } }
      }
      s += best * idfW * mult;
    };
    q.base.forEach((w) => add(w, 1));
    // exact multi-word phrase in the query (e.g. "kinetic energy", "simple pendulum") is a strong signal
    const low = " " + q.text + " ";
    [doc.title, doc.chapter].concat(doc.aliases || []).forEach((ph) => { const p = String(ph).toLowerCase(); if (p.includes(" ") && low.includes(" " + p + " ")) s += 6; });
    q.extra.forEach((w) => add(w, 0.5));
    return s;
  }
  function rank(query, opts) {
    opts = opts || {};
    const q = expand(query);
    if (!q.base.length) return [];
    const I = idf(), docs = root.EDO_DOCS || [];
    return docs.filter((d) => !opts.domain || d.domain === opts.domain)
      .map((doc) => ({ doc, score: scoreDoc(doc, q, I) })).filter((h) => h.score > 0)
      .sort((a, b) => b.score - a.score).slice(0, opts.limit || 20);
  }
  /* Back-compat: old callers read h.score as a small integer and compare to 2. Keep that scale. */
  function search(query, domain) {
    const r = rank(query, { domain, limit: 20 });
    if (!r.length) return r;
    const top = r[0].score;
    return r.filter((h) => h.score >= top * 0.25).map((h) => ({ doc: h.doc, score: Math.round(h.score * 10) / 10, weighted: h.score }));
  }
  function prerequisites(chapterOrId) {
    const docs = root.EDO_DOCS || [];
    const d = docs.find((x) => x.id === chapterOrId || String(x.chapter).toLowerCase() === String(chapterOrId).toLowerCase());
    if (!d) return [];
    return (d.prereqs || []).map((p) => docs.find((x) => String(x.chapter).toLowerCase() === String(p).toLowerCase())).filter(Boolean);
  }
  root.EDOKnowledge = { search, rank, expand, prerequisites, docs: () => root.EDO_DOCS || [], heuristic: true };
})();
