MIS TARJETAS Y MIS CRÉDITOS
Versión corregida: septiembre de 2026

Archivos incluidos:
- index.html: aplicación completa.
- manifest.json: configuración para instalar como aplicación web.
- sw.js: soporte de caché/offline básico.
- readme.txt: información de la versión.

CORRECCIÓN PRINCIPAL
- El saldo inicial de cada tarjeta entra en el pago del período.
- Las compras del ciclo anterior al corte entran en el pago del período actual.
- Las compras realizadas después del corte aparecen como "Gastos después del corte" y no se incluyen en el pago actual.
- Esos gastos quedan acumulados para el siguiente período.
- Los MSI muestran la mensualidad correspondiente sin sumar nuevamente el total de la compra.
- Cada tarjeta muestra su propio pago del período.
- Los créditos permanecen separados de las tarjetas.
- El resumen conserva total de tarjetas, total de créditos y total general.
- Los movimientos y cuentas continúan siendo editables.

IMPORTANTE
Los datos se guardan en el almacenamiento local del teléfono. Se recomienda usar Exportar datos antes de cambiar de dispositivo o borrar los datos del navegador/app.
