MY FAMILY TREE - FIXED DISPLAY VERSION

1. Extract the ZIP file.
2. Open index.html in Chrome or another modern browser.
3. The family tree is stored in that browser on this device.
4. Use Export regularly to back up your data and Import to restore it.

This version fixes the blank tree panel by using responsive generation rows. The relationships and member records in the demo should be checked against your source PDF before treating them as fully verified.
