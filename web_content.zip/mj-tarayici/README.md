# MJ Tarayıcı

Sekmeli, koyu modlu, odak modlu ve indirme yöneticili basit bir tarayıcı (Electron).

## Çalıştırma
1. Node.js kur: https://nodejs.org (LTS sürümü)
2. Bu klasörde terminal aç:
   npm install
   npm start
   (Windows'ta sadece `baslat.bat` dosyasına çift tıklaman yeterli.)

## Özellikler
- Sekmeler, geri / ileri / yenile / ana sayfa, adres çubuğundan arama
- Koyu mod (hem arayüz hem web siteleri)
- Odak modu: arayüz gizlenir, sadece sayfa ve küçük bir sayaç kalır
- İndirme butonu: ilerleme, "Aç" ve "Klasörde göster"; dosyalar İndirilenler klasörüne gider

## Kısayollar
Ctrl+T yeni sekme · Ctrl+W sekmeyi kapat · Ctrl+L adres çubuğu
Ctrl+Shift+F odak modu · Ctrl+Shift+D koyu mod · Ctrl+J indirilenler

## .exe yapmak istersen
npm run dist
