const { app, BrowserWindow, ipcMain, shell, session } = require('electron');
const path = require('path');
const fs = require('fs');
let win;

const KEYS = { 'shift+f': 'focus', 'shift+d': 'dark', t: 'newtab', w: 'close', l: 'url', j: 'downloads' };

function uniquePath(dir, name) {
  const ext = path.extname(name), base = path.basename(name, ext);
  let p = path.join(dir, name), i = 1;
  while (fs.existsSync(p)) p = path.join(dir, `${base} (${i++})${ext}`);
  return p;
}

function createWindow() {
  win = new BrowserWindow({
    width: 1280, height: 800, minWidth: 700, minHeight: 450,
    title: 'MJ Tarayıcı', backgroundColor: '#14151a',
    webPreferences: { preload: path.join(__dirname, 'preload.js'), webviewTag: true, contextIsolation: true }
  });
  win.removeMenu();
  win.loadFile('index.html');
}

app.on('web-contents-created', (_, c) => {
  c.on('before-input-event', (e, i) => {
    if (i.type !== 'keyDown' || !(i.control || i.meta)) return;
    const k = (i.shift ? 'shift+' : '') + i.key.toLowerCase();
    if (KEYS[k] && win) { e.preventDefault(); win.webContents.send('cmd', KEYS[k]); }
  });
  if (c.getType() === 'webview') {
    c.setWindowOpenHandler(({ url }) => { win && win.webContents.send('open-tab', url); return { action: 'deny' }; });
  }
});

app.whenReady().then(() => {
  session.fromPartition('persist:mj').on('will-download', (_, item) => {
    const id = Date.now() + Math.random();
    const savePath = uniquePath(app.getPath('downloads'), item.getFilename());
    item.setSavePath(savePath);
    const send = (state) => win && win.webContents.send('dl', {
      id, state, name: path.basename(savePath), path: savePath,
      received: item.getReceivedBytes(), total: item.getTotalBytes()
    });
    send('start');
    item.on('updated', (__, s) => send(s === 'interrupted' ? 'interrupted' : 'progress'));
    item.once('done', (__, s) => send(s));
  });
  createWindow();
});

ipcMain.on('open', (_, p) => shell.openPath(p));
ipcMain.on('show', (_, p) => shell.showItemInFolder(p));
app.on('window-all-closed', () => app.quit());
