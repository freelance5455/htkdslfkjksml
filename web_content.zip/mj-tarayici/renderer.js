const $ = (s) => document.querySelector(s);
const HOME = 'https://www.google.com';
const DARK_CSS = 'html{filter:invert(1) hue-rotate(180deg)!important;background:#fff}img,video,picture,canvas,svg image{filter:invert(1) hue-rotate(180deg)!important}';
let tabs = [], active = null, count = 0, dark, timerId, secs = 0;

function norm(v) {
  v = v.trim();
  if (!v) return HOME;
  if (/^[a-z][a-z0-9+.-]*:\/\//i.test(v)) return v;
  if (!/\s/.test(v) && (/^localhost(:\d+)?(\/.*)?$/.test(v) || /^[\w-]+(\.[\w-]+)+(:\d+)?(\/.*)?$/.test(v)))
    return (v.startsWith('localhost') ? 'http://' : 'https://') + v;
  return 'https://www.google.com/search?q=' + encodeURIComponent(v);
}

function newTab(url) {
  const wv = document.createElement('webview');
  wv.setAttribute('partition', 'persist:mj');
  wv.setAttribute('allowpopups', '');
  wv.src = norm(url || HOME);
  const el = document.createElement('div');
  el.className = 'tab';
  el.innerHTML = '<span class="t">Yeni sekme</span><b title="Kapat">×</b>';
  const tab = { id: ++count, wv, el, key: null };
  el.onclick = () => select(tab);
  el.querySelector('b').onclick = (e) => { e.stopPropagation(); closeTab(tab); };
  const sync = () => { if (tab === active) $('#url').value = wv.getURL ? safeUrl(wv) : ''; };
  wv.addEventListener('page-title-updated', (e) => { el.querySelector('.t').textContent = e.title; });
  wv.addEventListener('did-navigate', sync);
  wv.addEventListener('did-navigate-in-page', sync);
  wv.addEventListener('dom-ready', () => { tab.key = null; if (dark) applyDark(tab); });
  $('#views').appendChild(wv);
  $('#tablist').appendChild(el);
  tabs.push(tab);
  select(tab);
  if (!url) $('#url').focus();
}

function safeUrl(wv) { try { return wv.getURL(); } catch { return ''; } }

function select(tab) {
  active = tab;
  tabs.forEach((t) => { t.el.classList.toggle('on', t === tab); t.wv.classList.toggle('on', t === tab); });
  $('#url').value = safeUrl(tab.wv);
}

function closeTab(tab) {
  const i = tabs.indexOf(tab);
  tabs.splice(i, 1);
  tab.wv.remove(); tab.el.remove();
  if (!tabs.length) return newTab();
  if (tab === active) select(tabs[Math.max(0, i - 1)]);
}

async function applyDark(tab) {
  try {
    if (tab.key) { await tab.wv.removeInsertedCSS(tab.key); tab.key = null; }
    if (dark) tab.key = await tab.wv.insertCSS(DARK_CSS);
  } catch {}
}

function setDark(on) {
  dark = on;
  document.body.classList.toggle('dark', on);
  $('#dark').textContent = on ? 'Açık' : 'Koyu';
  try { localStorage.setItem('mj-dark', on ? '1' : '0'); } catch {}
  tabs.forEach(applyDark);
}

function setFocus(on) {
  document.body.classList.toggle('focus', on);
  $('#pill').hidden = !on;
  clearInterval(timerId);
  if (on) {
    secs = 0; $('#timer').textContent = '00:00';
    timerId = setInterval(() => {
      secs++;
      $('#timer').textContent = String(Math.floor(secs / 60)).padStart(2, '0') + ':' + String(secs % 60).padStart(2, '0');
    }, 1000);
  }
}

// İndirmeler
const dls = {};
const mb = (b) => (b / 1048576).toFixed(1) + ' MB';
function renderDl(d) {
  dls[d.id] = d;
  const list = $('#dllist');
  list.querySelector('.empty')?.remove();
  let el = list.querySelector(`[data-id="${d.id}"]`);
  if (!el) { el = document.createElement('div'); el.className = 'item'; el.dataset.id = d.id; list.prepend(el); }
  const done = d.state === 'completed';
  const status = done ? 'Tamamlandı · ' + mb(d.total || d.received)
    : d.state === 'cancelled' || d.state === 'interrupted' ? 'İndirme başarısız'
    : mb(d.received) + (d.total ? ' / ' + mb(d.total) : '');
  el.innerHTML = `<div class="n"></div><div class="s">${status}</div>` +
    (done ? '<button data-a="open">Aç</button><button data-a="show">Klasörde göster</button>'
          : d.state === 'progress' || d.state === 'start' ? `<progress max="${d.total || 1}" value="${d.received}"></progress>` : '');
  el.querySelector('.n').textContent = d.name;
  el.querySelectorAll('button').forEach((b) => b.onclick = () => mj[b.dataset.a](d.path));
}

mj.on('dl', (d) => {
  renderDl(d);
  if (d.state === 'start') { $('#panel').hidden = false; }
  $('#badge').hidden = d.state === 'completed' ? false : $('#badge').hidden;
});
mj.on('open-tab', (url) => newTab(url));
mj.on('cmd', (c) => ({
  focus: () => setFocus(!document.body.classList.contains('focus')),
  dark: () => setDark(!dark),
  newtab: () => newTab(),
  close: () => active && closeTab(active),
  url: () => { $('#url').focus(); $('#url').select(); },
  downloads: toggleDl
}[c]?.()));

function toggleDl() { $('#panel').hidden = !$('#panel').hidden; $('#badge').hidden = true; }

// Düğmeler
$('#newtab').onclick = () => newTab();
$('#back').onclick = () => active.wv.canGoBack() && active.wv.goBack();
$('#fwd').onclick = () => active.wv.canGoForward() && active.wv.goForward();
$('#reload').onclick = () => active.wv.reload();
$('#home').onclick = () => active.wv.loadURL(HOME);
$('#focus').onclick = () => setFocus(true);
$('#exit').onclick = () => setFocus(false);
$('#dark').onclick = () => setDark(!dark);
$('#dl').onclick = toggleDl;
$('#url').onkeydown = (e) => { if (e.key === 'Enter') { active.wv.loadURL(norm($('#url').value)); active.wv.focus(); } };
$('#url').onfocus = (e) => e.target.select();

let saved = null;
try { saved = localStorage.getItem('mj-dark'); } catch {}
setDark(saved === null ? matchMedia('(prefers-color-scheme: dark)').matches : saved === '1');
newTab(HOME);
