const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('mj', {
  on: (ch, fn) => ipcRenderer.on(ch, (_, d) => fn(d)),
  open: (p) => ipcRenderer.send('open', p),
  show: (p) => ipcRenderer.send('show', p)
});
