Abbreviation Finder — Android APK তৈরির জন্য প্রস্তুত ফাইল

এই ZIP-এর index.html হলো আপনার দেওয়া অ্যাপের প্রস্তুত করা সংস্করণ।
APK Builder-এ Single HTML অথবা ZIP হিসেবে আপলোড করুন।
App name: Abbreviation Finder
Package name উদাহরণ: com.taher.abbreviationfinder

নোট: অ্যাপের মূল কোড ও abbreviation data একই HTML ফাইলে আছে। Google Fonts লোডের জন্য ইন্টারনেট লাগতে পারে; ইন্টারনেট না থাকলে ফোনের fallback font ব্যবহৃত হবে।
