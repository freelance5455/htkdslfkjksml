# Mis Cuentas – versión nativa (iPhone y Android)

Este proyecto convierte la app **Mis Cuentas** en una aplicación instalable en iPhone y Android, usando **Capacitor**.

## ¿Qué significa "nativa" aquí?

- La app se instala como cualquier otra (icono propio, pantalla de inicio, sin barras de navegador, se puede publicar en App Store y Google Play).
- Usa funciones **nativas** del teléfono: huella y Face ID del sistema, almacenamiento del teléfono, voz del sistema y botón "atrás" de Android.
- Las **pantallas** se siguen dibujando con HTML, CSS y JavaScript dentro de un visor interno (WebView). No es una reescritura en Swift/Kotlin. Si algún día se necesita una interfaz 100 % nativa, habría que reescribirla (SwiftUI + Kotlin, Flutter o React Native).

## Novedades de esta versión

**Huella y Face ID (corregido)**
- Ya no se lanza el aviso de huella dos veces a la vez (era la causa de que fallara al tocar el botón 👆).
- En el celular, la app pide la huella sola un instante después de abrir; en la versión web hay que tocar el botón 👆, porque los navegadores no permiten pedirla sin un toque.
- Si algo falla, el aviso ahora dice la causa: sin huella registrada en el teléfono, no compatible, confirmación cancelada o bloqueada por el visor.

**Lector de voz (corregido)**
- Elige una voz en español del teléfono (Colombia, México, EE. UU. o España, en ese orden) en lugar de usar la voz por defecto.
- Corrige el silencio que ocurría al cancelar y hablar en el mismo instante.
- En iPhone ahora suena aunque el interruptor de silencio esté activado.
- Ya no lee símbolos como «✔». Hay un botón «Probar la voz» en Ajustes y un aviso si el teléfono no tiene voz en español.

**Animación de desbloqueo (nueva)**
- Al desbloquear con clave o huella aparece un círculo con una marca que se dibuja y el mensaje «¡Bienvenido!»; luego la pantalla principal entra suavemente.
- Dura cerca de 1 segundo y se omite si el teléfono tiene activado «Reducir movimiento».

**Optimización**
- Los montos se formatean con un único formateador (más rápido al escribir).
- La lista de movimientos muestra 60 a la vez, con un botón «Ver más movimientos».
- Las filas fuera de pantalla no se dibujan hasta que hacen falta.
- Efecto cristal más ligero (menos desenfoque, y sin desenfoque en botones pequeños).
- La letra «Muy legible» solo se carga si la eliges (en el celular ya viene incluida).
- Al cambiar de pestaña, el lector de pantalla se coloca en el título de la nueva pantalla.

## Lo que necesitas

| Para... | Necesitas |
|---|---|
| Todo | Un computador con **Node.js 22 o superior** (https://nodejs.org) |
| Android | **Android Studio** (Windows, Mac o Linux). Cuenta de Google Play: pago único de US$25 |
| iPhone | Un **Mac** con **Xcode 26 o superior**. Para probar en tu propio iPhone basta un Apple ID gratuito; para la App Store, el Apple Developer Program (US$99 al año) |

Las versiones mínimas cambian con cada versión de Capacitor: revisa https://capacitorjs.com/docs/main/reference/support-policy

## Pasos

Abre una terminal dentro de esta carpeta y ejecuta:

1. **Instalar dependencias**
   ```
   npm install
   ```
2. **Generar iconos y pantalla de inicio** (usa las imágenes de la carpeta `assets`)
   ```
   npm run assets
   ```
3. **Crear los proyectos nativos** (solo la primera vez)
   ```
   npx cap add android
   npx cap add ios        (solo en Mac)
   ```
4. **iPhone: permiso de Face ID.** Abre `ios/App/App/Info.plist` y agrega, dentro de `<dict>`:
   ```
   <key>NSFaceIDUsageDescription</key>
   <string>Mis Cuentas usa Face ID para abrir la aplicación de forma segura.</string>
   ```
   Sin esto, iOS cierra la app al pedir Face ID.
5. **Android:** si Android Studio avisa de un permiso de biometría, sigue las instrucciones del plugin: https://www.npmjs.com/package/@aparajita/capacitor-biometric-auth
6. **Compilar y abrir**
   ```
   npm run android        (abre Android Studio)
   npm run ios            (abre Xcode)
   ```
   Conecta el teléfono, elige tu dispositivo arriba y pulsa el botón de "Run / ▶".
7. **Cada vez que cambies algo** en `src/` o `index.html`, vuelve a ejecutar el mismo comando (`npm run android` o `npm run ios`).

## Para publicar

- Cambia `appId` en `capacitor.config.json` (por ejemplo `com.tunombre.miscuentas`). Debe ser único y no se puede cambiar después de publicar.
- Android: en Android Studio, menú *Build > Generate Signed Bundle*, y sube el archivo `.aab` a Google Play Console.
- iPhone: en Xcode, menú *Product > Archive*, y sube con *Distribute App* a App Store Connect.

## Qué cambió respecto a la versión web

| Tema | Versión web | Versión nativa |
|---|---|---|
| Datos | localStorage del navegador | Almacenamiento del teléfono (Preferences) además de localStorage |
| Huella / Face ID | WebAuthn (depende del navegador) | Plugin nativo de biometría |
| Voz | speechSynthesis del navegador | Voz del sistema (plugin Text-to-Speech) |
| Letra «Muy legible» | Se descargaba de internet | Incluida dentro de la app (funciona sin internet) |
| Barra de estado y zonas seguras | Etiquetas meta de Safari | Plugin System Bars de Capacitor (`--safe-area-inset-*`) |
| Bloqueo al salir | Al ocultar la página | Al volver a la app tras más de 15 segundos fuera |
| Botón «atrás» de Android | No existía | Cierra ventanas, vuelve a Inicio y luego minimiza |
| Tarjeta «Usar en iPhone» | Visible | Oculta |

## Lista de comprobación en un teléfono real

Esta versión **no se ha podido probar en un dispositivo** durante su preparación. Antes de entregarla, prueba en un iPhone y en un Android:

- [ ] La app abre, muestra el tutorial y guarda un gasto.
- [ ] Cierra la app por completo, ábrela de nuevo: los movimientos siguen ahí.
- [ ] Crear clave de 4 números; cerrar y reabrir pide la clave.
- [ ] Activar huella / Face ID en Ajustes; se pide confirmación y luego desbloquea.
- [ ] «Voz para personas ciegas» lee los avisos y el resumen.
- [ ] Modo claro, oscuro y automático; el texto de la barra de estado se ve bien en ambos.
- [ ] El menú inferior no queda tapado por la barra de gestos (iPhone y Android).
- [ ] Con VoiceOver (iPhone) y TalkBack (Android) activados se puede anotar un gasto de principio a fin.
- [ ] Botón «atrás» de Android.

## Límites que conviene conocer

- La clave se guarda como hash en el almacenamiento de la app, **sin cifrar los datos**. Protege contra miradas casuales, no contra alguien con acceso técnico al teléfono. Mejora recomendada antes de publicar: cifrar los movimientos con una clave guardada en el Keychain (iOS) / Keystore (Android).
- No hay copia de respaldo: si se desinstala la app o se cambia de teléfono, los datos se pierden. Mejora sugerida: exportar e importar un archivo.
- Los plugins comunitarios (biometría y voz) están instalados como `latest`. Si `npm install` avisa de incompatibilidad con tu versión de Capacitor, ejecuta `npx cap ls` y ajusta la versión del plugin.

## Problemas frecuentes

| Síntoma | Qué revisar |
|---|---|
| `npm install` falla | Versión de Node (debe ser 22 o superior): `node -v` |
| Pantalla en blanco al abrir | Ejecuta de nuevo `npm run sync` y revisa que exista la carpeta `dist` |
| La app se cierra al pedir Face ID | Falta `NSFaceIDUsageDescription` en Info.plist (paso 4) |
| El menú inferior queda tapado en Android | Revisa que la versión de Capacitor sea 8.3 o superior (mejora de zonas seguras) |
| La huella no aparece | El teléfono debe tener una huella o rostro registrados en sus ajustes |

## Estructura del proyecto

```
index.html              Contenedores de la app
src/main.js             Todo el JavaScript (incluye las funciones nativas)
src/styles.css          Todos los estilos
assets/                 Iconos y pantalla de inicio (se convierten con npm run assets)
capacitor.config.json   Nombre, identificador y ajustes de Capacitor
vite.config.js          Empaquetado (npm run build crea la carpeta dist)
```
Para entender cada parte del código, consulta el PDF «Guía del código» (describe la versión web; las funciones nativas nuevas están al final de `src/main.js`, bajo el comentario «Versión nativa»).
