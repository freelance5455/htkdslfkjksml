import './styles.css';
import '@fontsource/atkinson-hyperlegible/400.css';
import '@fontsource/atkinson-hyperlegible/700.css';
import {Capacitor, SystemBars, SystemBarsStyle} from '@capacitor/core';
import {Preferences} from '@capacitor/preferences';
import {App as CapApp} from '@capacitor/app';
import {SplashScreen} from '@capacitor/splash-screen';
import {BiometricAuth} from '@aparajita/capacitor-biometric-auth';
import {TextToSpeech} from '@capacitor-community/text-to-speech';

const NATIVE=Capacitor.isNativePlatform();
let sbStyle='';
const $=s=>document.querySelector(s);
let S={tx:[],big:100000,fs:18,seen:false,pin:'',bio:'',cb:'n',hc:false,voice:false,theme:'auto',ac:'az',fn:'sys',gl:true,bd:false},tab='home',filt='all',tstep=0,sel='',pend='',lim=60;
try{const r=localStorage.getItem('mc1');if(r)S=Object.assign(S,JSON.parse(r))}catch(e){}
const save=()=>{try{const j=JSON.stringify(S);localStorage.setItem('mc1',j);if(NATIVE)Preferences.set({key:'mc1',value:j}).catch(()=>{})}catch(e){}};
const NF=new Intl.NumberFormat('es-CO'),fm=n=>'$'+NF.format(Math.round(n));
const E={g:[['🛒','Mercado'],['🍽️','Comida'],['🚌','Transporte'],['💡','Servicios'],['💊','Salud'],['🏠','Hogar'],['🎁','Regalos'],['🎉','Ocio'],['📦','Otros']],
i:[['🏦','Pensión'],['💼','Sueldo'],['🎁','Regalo'],['💵','Otro ingreso']]};
const today=()=>{const d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')};
const esc=s=>s.replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const fd=d=>new Date(d+'T12:00:00').toLocaleDateString('es',{day:'numeric',month:'short'});
const mt=t=>{const k=today().slice(0,7);return S.tx.filter(x=>x.type===t&&x.date.slice(0,7)===k)};
const sum=a=>a.reduce((s,x)=>s+x.amt,0);
const cmp=(a,b)=>b.date.localeCompare(a.date)||b.id-a.id;
const num=v=>parseInt(String(v).replace(/\D/g,''))||0;
function toast(m){say(m);const t=$('#toast');t.textContent=m;t.style.display='block';setTimeout(()=>t.style.display='none',2000)}
function row(x,del){const c=E[x.type].find(c=>c[1]===x.cat)||['📦',x.cat];const big=x.type==='g'&&x.amt>=S.big;
return `<div class="row"><div class="ic">${c[0]}</div><div class="rm"><b>${x.cat}</b><small>${esc(x.note||'')} ${fd(x.date)}</small>${big?'<span class="tag">Gasto grande</span>':''}</div><div class="am ${x.type}"><span aria-hidden="true">${x.type==='g'?'−':'+'}${fm(x.amt)}</span><span class="sr">${x.type==='g'?'Gasto':'Ingreso'} de ${fm(x.amt)}</span></div>${del?`<button class="del" data-a="del" data-v="${x.id}" aria-label="Borrar ${x.cat} ${fm(x.amt)}">🗑️</button>`:''}</div>`}
function list(a,del){return a.length?`<div class="card">${a.map(x=>row(x,del)).join('')}</div>`:'<div class="card"><p>Todavía no hay movimientos aquí. Toca un botón de Inicio para anotar el primero.</p></div>'}
function render(){
document.documentElement.style.setProperty('--fs',S.fs+'px');document.documentElement.setAttribute('data-cb',S.cb||'n');document.documentElement.setAttribute('data-hc',S.hc?'1':'0');applyTheme();
const bal=sum(S.tx.filter(x=>x.type==='i'))-sum(S.tx.filter(x=>x.type==='g'));
let h='';
if(tab==='home'){h=`<h1>Hola 👋</h1><p class="mut">Así van tus cuentas</p>
<div class="card hero"><small>Dinero disponible</small><div class="big">${fm(bal)}</div></div>
<div class="two"><div class="card mini"><small>Entró este mes</small><b class="i">${fm(sum(mt('i')))}</b></div><div class="card mini"><small>Salió este mes</small><b class="g">${fm(sum(mt('g')))}</b></div></div>
${S.voice?'<button class="btn s" data-a="speak">🔊 Escuchar mi resumen</button><div class="gap"></div>':''}<button class="btn g" data-a="add" data-v="g"><span aria-hidden="true">➖</span> Anotar un gasto</button><div class="gap"></div>
<button class="btn i" data-a="add" data-v="i"><span aria-hidden="true">➕</span> Anotar un ingreso</button>
<h2>Últimos movimientos</h2>${list(S.tx.slice().sort(cmp).slice(0,5),false)}`}
else if(tab==='mov'){const f=[['all','Todos'],['g','Gastos'],['i','Ingresos'],['big','Grandes'],['peq','Pequeños']];
let a=S.tx.slice().sort(cmp);if(filt==='g'||filt==='i')a=a.filter(x=>x.type===filt);if(filt==='big')a=a.filter(x=>x.type==='g'&&x.amt>=S.big);if(filt==='peq')a=a.filter(x=>x.type==='g'&&x.amt<S.big);
h=`<h1>Movimientos</h1><div class="chips">${f.map(c=>`<button class="chip ${filt===c[0]?'on':''}" data-a="filt" data-v="${c[0]}">${c[1]}</button>`).join('')}</div>${list(a.slice(0,lim),true)}${a.length>lim?`<button class="btn s" data-a="more">Ver más movimientos (${a.length-lim})</button>`:''}`}
else if(tab==='res'){const gm=mt('g'),gr=sum(gm.filter(x=>x.amt>=S.big)),pq=sum(gm.filter(x=>x.amt<S.big)),by={};
gm.forEach(x=>by[x.cat]=(by[x.cat]||0)+x.amt);const en=Object.entries(by).sort((a,b)=>b[1]-a[1]),mx=en.length?en[0][1]:1;
h=`<h1>Resumen del mes</h1><div class="two" style="margin-top:18px"><div class="card mini"><small>Gastos grandes</small><b class="g">${fm(gr)}</b></div><div class="card mini"><small>Gastos pequeños</small><b class="g">${fm(pq)}</b></div></div>
<h2>¿En qué se fue el dinero?</h2><div class="card">${en.length?en.map(([c,v])=>{const ic=(E.g.find(x=>x[1]===c)||['📦'])[0];return `<div class="bl"><span>${ic} ${c}</span><span>${fm(v)}</span></div><div class="bar"><i style="width:${Math.max(4,v/mx*100)}%"></i></div>`}).join(''):'<p>Aún no hay gastos este mes.</p>'}</div>`}
else{h=`<h1>Ajustes</h1><div class="card" style="margin-top:18px"><b>Tamaño de letra</b><div class="fsr" style="margin-top:12px"><button class="btn s" data-a="fs" data-v="-1">A−</button><b>${S.fs}</b><button class="btn s" data-a="fs" data-v="1">A+</button></div></div>
<div class="card"><b>Un gasto es “grande” desde:</b><input id="bg" class="in big" inputmode="numeric" value="${NF.format(S.big)}" style="margin-top:12px"></div>
<h2>Apariencia</h2><div class="card"><b id="th">Tema</b><div class="chips w" role="group" aria-labelledby="th">${[['auto','Automático'],['light','Claro'],['dark','Oscuro']].map(c=>chip('theme',c[0],S.theme||'auto',c[1])).join('')}</div><b id="acl">Color</b><div class="chips w" role="group" aria-labelledby="acl">${[['az','<span aria-hidden="true">🔵</span> Azul'],['mo','<span aria-hidden="true">🟣</span> Morado'],['ve','<span aria-hidden="true">🟢</span> Turquesa'],['ro','<span aria-hidden="true">🌸</span> Rosa']].map(c=>chip('ac',c[0],S.ac||'az',c[1])).join('')}</div><b id="fnh">Estilo de letra</b><div class="chips w" role="group" aria-labelledby="fnh">${[['sys','Del sistema'],['rd','Redondeada'],['sf','Clásica'],['at','Muy legible']].map(c=>chip('fn',c[0],S.fn||'sys',c[1])).join('')}</div><button class="btn s" role="switch" aria-checked="${!!S.bd}" data-a="bd">${S.bd?'✅':'⬜'} Letra en negrita</button><div class="gap"></div><button class="btn s" role="switch" aria-checked="${!!S.gl}" data-a="gl">${S.gl?'✅':'⬜'} Cristal translúcido (estilo iPhone)</button><p class="mut">El cristal se apaga solo si activas el alto contraste.</p></div><h2>Seguridad</h2><div class="card"><button class="btn" data-a="pin">🔒 ${S.pin?'Cambiar mi clave':'Crear una clave'}</button>${S.pin?`<div class="gap"></div><button class="btn s" data-a="bio">👆 Huella o Face ID: ${S.bio?'activada (tocar para quitar)':'activar'}</button><div class="gap"></div><button class="btn s" data-a="pinoff">Quitar la clave</button>`:'<p class="mut">Con una clave de 4 números, nadie más podrá ver tus cuentas.</p>'}</div><h2>Accesibilidad</h2><div class="card"><b id="cbh">Colores para daltonismo</b><div class="chips" role="group" aria-labelledby="cbh">${[['n','Normal'],['rv','Rojo y verde'],['tr','Azul y amarillo']].map(c=>`<button class="chip ${S.cb===c[0]?'on':''}" aria-pressed="${S.cb===c[0]}" data-a="cb" data-v="${c[0]}">${c[1]}</button>`).join('')}</div><button class="btn s" role="switch" aria-checked="${!!S.hc}" data-a="hc">${S.hc?'✅':'⬜'} Alto contraste</button><div class="gap"></div><button class="btn s" role="switch" aria-checked="${!!S.voice}" data-a="voice">${S.voice?'✅':'⬜'} Voz para personas ciegas</button>${S.voice?'<div class="gap"></div><button class="btn s" data-a="vtest">🔊 Probar la voz</button>':''}<p class="mut">Funciona con TalkBack y VoiceOver. Con la voz activada, la app lee en voz alta lo que haces y puedes escuchar tu resumen. Los gastos e ingresos siempre llevan signo y nombre, no solo color.</p></div><button class="btn" data-a="tut">❓ Ver el tutorial otra vez</button><div class="gap"></div>
<div class="card webonly" style="margin-top:16px"><b>📱 Usar en iPhone</b><p class="mut">Abre esta página en Safari, toca Compartir ⬆️ y elige “Agregar a pantalla de inicio”. Así se abre como una app, sin barras del navegador, y ayuda a que tus datos no se pierdan. Hazlo antes de anotar movimientos: lo que anotes en Safari no pasa a la app de la pantalla de inicio.</p></div><button class="btn s" data-a="resetq">Borrar todos mis datos</button>
<p class="mut" style="text-align:center;margin-top:20px">Tus datos se guardan solo en este teléfono.<br>Los colores cambian solos con el modo claro u oscuro.</p>`}
$('#app').innerHTML=h;
const T=[['home','🏠','Inicio'],['mov','🧾','Movimientos'],['res','📊','Resumen'],['aju','⚙️','Ajustes']];
$('#nav').innerHTML=T.map(t=>`<button class="${tab===t[0]?'on':''}" ${tab===t[0]?'aria-current="page"':''} data-a="tab" data-v="${t[0]}"><span aria-hidden="true">${t[1]}</span>${t[2]}</button>`).join('')}
function addSheet(t){sel=E[t][0][1];$('#sheet').innerHTML=`<div class="ov"><div class="sh" role="dialog" aria-modal="true" aria-labelledby="dh"><h2 id="dh">${t==='g'?'Anotar un gasto':'Anotar un ingreso'}</h2>
<label for="amt">¿Cuánto fue?</label><input id="amt" class="in big" inputmode="numeric" placeholder="$ 0" autocomplete="off">
<label id="ch">${t==='g'?'¿En qué?':'¿De dónde?'}</label><div class="grid" role="group" aria-labelledby="ch">${E[t].map((c,i)=>`<button class="cat ${i?'':'on'}" aria-pressed="${!i}" data-a="cat" data-v="${c[1]}"><span aria-hidden="true">${c[0]}</span>${c[1]}</button>`).join('')}</div>
<label for="nt">Nota (opcional)</label><input id="nt" class="in" maxlength="40" placeholder="Ej: pan y leche">
<label for="dt">¿Qué día?</label><input id="dt" type="date" class="in" value="${today()}">
<p id="er" class="er" role="alert"></p><button class="btn ${t}" data-a="save" data-v="${t}">Guardar</button><div class="gap"></div><button class="btn s" data-a="close">Cancelar</button></div></div>`;setTimeout(()=>$('#amt').focus(),60)}
function conf(msg,act){pend=act;$('#sheet').innerHTML=`<div class="ov mid"><div class="sh" role="alertdialog" aria-modal="true" aria-label="${msg}"><h2>${msg}</h2><p class="mut">Esto no se puede deshacer.</p><button class="btn g" data-a="yes">Sí, borrar</button><div class="gap"></div><button class="btn s" data-a="close">No, conservar</button></div></div>`}
const TS=[['👋','¡Bienvenido!','Esta aplicación te ayuda a anotar lo que ganas y lo que gastas, de forma fácil y sin complicaciones.'],
['➖','Anotar un gasto','En Inicio toca el botón de gasto, escribe cuánto fue y elige en qué. Para el dinero que recibes, usa el botón verde de ingreso.'],
['🧾','Grandes y pequeños',()=>`Los gastos desde ${fm(S.big)} se marcan como “grandes”. Puedes cambiar ese monto en Ajustes. En Resumen verás cuánto gastaste de cada tipo.`],
['⚙️','Hecha a tu medida','En Ajustes puedes agrandar las letras. Los colores se adaptan solos al modo claro u oscuro de tu celular.']];
function tutShow(){const s=TS[tstep],last=tstep===TS.length-1;$('#tut').innerHTML=`<div class="ov mid"><div class="sh tut" role="dialog" aria-modal="true" aria-label="Tutorial"><div class="em" aria-hidden="true">${s[0]}</div><h2>${s[1]}</h2><p>${typeof s[2]==='function'?s[2]():s[2]}</p><div class="dots">${TS.map((_,i)=>`<i class="${i===tstep?'on':''}"></i>`).join('')}</div>
<button class="btn" data-a="${last?'tend':'next'}">${last?'¡Empezar!':'Siguiente'}</button>${tstep?'<div class="gap"></div><button class="btn s" data-a="prev">Atrás</button>':'<div class="gap"></div><button class="btn s" data-a="tend">Saltar</button>'}</div></div>`}
function tutEnd(){$('#tut').innerHTML='';S.seen=true;save()}
document.addEventListener('click',e=>{
if(e.target.classList.contains('ov')&&$('#sheet').contains(e.target)){$('#sheet').innerHTML='';return}
const b=e.target.closest('[data-a]');if(!b)return;const a=b.dataset.a,v=b.dataset.v;
if(a==='tab'){tab=v;lim=60;render();scrollTo(0,0);focusTitle()}
else if(a==='filt'){filt=v;lim=60;render()}
else if(a==='add')addSheet(v);
else if(a==='cat'){sel=v;document.querySelectorAll('.cat').forEach(c=>{c.classList.toggle('on',c.dataset.v===v);c.setAttribute('aria-pressed',c.dataset.v===v)})}
else if(a==='close')$('#sheet').innerHTML='';
else if(a==='save'){const n=num($('#amt').value);if(!n){$('#er').textContent='Escribe cuánto fue, por ejemplo 15.000';return}
S.tx.push({id:Date.now(),type:v,amt:n,cat:sel,note:$('#nt').value.trim(),date:$('#dt').value||today()});save();$('#sheet').innerHTML='';render();toast('Guardado ✔')}
else if(a==='del')conf('¿Borrar este movimiento?','d'+v);
else if(a==='resetq')conf('¿Borrar todos tus datos?','all');
else if(a==='yes'){if(pend==='pin'){S.pin='';S.bio=''}else if(pend==='forgot'){S.tx=[];S.pin='';S.bio='';$('#lock').innerHTML=''}else if(pend==='all')S.tx=[];else S.tx=S.tx.filter(x=>'d'+x.id!==pend);save();$('#sheet').innerHTML='';render();toast('Listo ✔')}
else if(a==='fs'){S.fs=Math.min(26,Math.max(16,S.fs+ +v));save();render()}
else if(a==='tut'){tstep=0;tutShow()}
else if(a==='next'){tstep++;tutShow()}else if(a==='prev'){tstep--;tutShow()}else if(a==='tend'){tutEnd();if(!S.pin)setupPin()}else if(a==='cb'){S.cb=v;save();render()}else if(a==='hc'){S.hc=!S.hc;save();render()}else if(a==='voice'){S.voice=!S.voice;save();render();say(S.voice?'Voz activada':'Voz desactivada')}else if(a==='speak')speakSummary();else if(a==='pin')setupPin();else if(a==='pinoff')conf('¿Quitar la clave?','pin');else if(a==='bio')toggleBio();else if(a==='pk')padKey(v);else if(a==='bioGo')bioUnlock();else if(a==='forgot')conf('¿Olvidaste tu clave? Para entrar se borrarán todos tus datos.','forgot');else if(a==='later')$('#lock').innerHTML='';else if(a==='theme'||a==='ac'||a==='fn'){S[a]=v;save();render()}else if(a==='gl'||a==='bd'){S[a]=!S[a];save();render()}else if(a==='more'){lim+=60;render()}else if(a==='vtest')voiceTest()});
document.addEventListener('input',e=>{if(e.target.id==='amt'||e.target.id==='bg'){const n=num(e.target.value);e.target.value=n?NF.format(n):''}});
document.addEventListener('change',e=>{if(e.target.id==='bg'){S.big=num(e.target.value)||100000;save();render();toast('Guardado ✔')}});
const clean=t=>String(t).replace(/[^\p{L}\p{N}\s.,:;¿?¡!%-]/gu,'').replace(/\s+/g,' ').trim();
let ttsLang=null;
async function pickLang(){for(const l of ['es-CO','es-MX','es-US','es-ES','es']){try{const r=await TextToSpeech.isLanguageSupported({lang:l});if(r&&r.supported)return l}catch(e){}}return null}
function say(t){if(!S.voice)return;t=clean(t);if(!t)return;
(async()=>{try{if(!ttsLang)ttsLang=(await pickLang())||'es-ES';await TextToSpeech.stop().catch(()=>{});await new Promise(r=>setTimeout(r,80));await TextToSpeech.speak({text:t,lang:ttsLang,rate:0.92,pitch:1,volume:1,category:'playback'})}catch(e){}})()}
async function voiceTest(){const l=await pickLang();if(!l){toast('No hay una voz en español en este teléfono. Instálala en los ajustes de voz del teléfono.');return}ttsLang=l;say('Hola. Así suena la voz de Mis Cuentas.')}
function loadAtk(){}
function focusTitle(){const t=$('#app h1');if(t){t.setAttribute('tabindex','-1');t.focus({preventScroll:true})}}
function speakSummary(){const n=v=>NF.format(Math.round(v));say('Tienes disponible '+n(sum(S.tx.filter(x=>x.type==='i'))-sum(S.tx.filter(x=>x.type==='g')))+'. Este mes entraron '+n(sum(mt('i')))+' y salieron '+n(sum(mt('g')))+'.')}
async function hp(p){try{const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode('mc|'+p));return [...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('')}catch(e){return 'x'+btoa(p)}}
let P={m:'in',b:'',f:''},fails=0,until=0;
function draw(msg){const T={new:['Crea tu clave','Escribe 4 números que recuerdes'],conf:['Repite tu clave','Escríbela otra vez'],in:['Escribe tu clave',(S.bio?'Escribe tu clave o toca el botón de huella':'Son 4 números')]}[P.m];
$('#lock').innerHTML=`<div role="dialog" aria-modal="true" aria-labelledby="lt" style="max-width:360px;width:100%"><div style="font-size:3.2rem" aria-hidden="true">🔒</div><h1 id="lt" style="font-size:1.6rem">${T[0]}</h1><p class="mut" role="status">${msg||T[1]}</p><div class="pd" aria-hidden="true">${[0,1,2,3].map(i=>`<i class="${i<P.b.length?'f':''}"></i>`).join('')}</div><div class="pad">${[1,2,3,4,5,6,7,8,9].map(n=>`<button data-a="pk" data-v="${n}">${n}</button>`).join('')}${P.m==='in'&&S.bio?'<button data-a="bioGo" aria-label="Usar mi huella o Face ID">👆</button>':'<span></span>'}<button data-a="pk" data-v="0">0</button><button data-a="pk" data-v="x" aria-label="Borrar un número">⌫</button></div>${P.m==='in'?'<button class="btn s" data-a="forgot">Olvidé mi clave</button>':`<button class="btn s" data-a="later">${S.pin?'Cancelar':'Más tarde'}</button>`}</div>`}
function showLock(){P={m:'in',b:'',f:''};draw();if(S.bio&&AUTOBIO)setTimeout(bioUnlock,400)}
function setupPin(){P={m:'new',b:'',f:''};draw()}
async function padKey(v){
if(P.m==='in'&&Date.now()<until){draw('Espera un momento e intenta otra vez');return}
if(v==='x')P.b=P.b.slice(0,-1);else if(P.b.length<4)P.b+=v;
if(P.b.length<4){draw();return}
const h=await hp(P.b);
if(P.m==='new'){P.f=h;P.m='conf';P.b='';draw();return}
if(P.m==='conf'){if(h===P.f){S.pin=h;save();P.b='';$('#lock').innerHTML='';render();toast('Clave guardada ✔')}else{P.m='new';P.b='';P.f='';draw('No coinciden. Intenta otra vez')}return}
if(h===S.pin){fails=0;P.b='';unlockOk()}else{fails++;P.b='';if(fails>=5){until=Date.now()+30000;fails=0;draw('Demasiados intentos. Espera 30 segundos')}else draw('Clave incorrecta')}}
const b64=b=>btoa(String.fromCharCode(...new Uint8Array(b)));
const ub=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0));
const AUTOBIO=true;
let bioBusy=false;
const inFrame=(()=>{try{return window.self!==window.top}catch(e){return true}})();
function bioMsg(e,fast){const n=(e&&e.name)||'';
if(n==='NoBiometry')return 'Este teléfono no tiene huella ni Face ID configurados. Actívalos en los ajustes del teléfono.';
if(e==='nosup'||n==='NotSupportedError')return 'Este teléfono o navegador no permite usar la huella aquí. Usa tu clave.';
if(fast&&inFrame)return 'La huella no funciona dentro de este visor. Abre la app en su propia pantalla, o instálala, e inténtalo de nuevo.';
if(n==='NotAllowedError')return 'No se pudo confirmar la huella. Intenta otra vez y apoya el dedo cuando el teléfono lo pida.';
if(n==='SecurityError')return 'El navegador no permite la huella en esta página.';
return 'No se pudo activar la huella. Usa tu clave.'}
async function toggleBio(){
if(S.bio){S.bio='';save();render();toast('Huella quitada');return}
if(bioBusy)return;bioBusy=true;const t0=Date.now();
try{const id=await bioEnable();S.bio=id;save();render();toast('Huella o Face ID activado ✔')}
catch(e){toast(bioMsg(e,Date.now()-t0<600))}
finally{bioBusy=false}}
async function bioUnlock(){
if(bioBusy||!S.bio)return;bioBusy=true;
try{await bioAuth();fails=0;unlockOk()}catch(e){}
finally{bioBusy=false}}
async function bioEnable(){
const r=await BiometricAuth.checkBiometry();
if(!r.isAvailable){const e=new Error('sin biometría');e.name='NoBiometry';throw e}
await BiometricAuth.authenticate({reason:'Confirma para activar el desbloqueo con huella o rostro',cancelTitle:'Cancelar',allowDeviceCredential:false,androidTitle:'Mis Cuentas',androidSubtitle:'Confirma tu huella o rostro'});
return 'native'}
async function bioAuth(){
await BiometricAuth.authenticate({reason:'Desbloquea Mis Cuentas',cancelTitle:'Usar mi clave',allowDeviceCredential:false,iosFallbackTitle:'Usar mi clave',androidTitle:'Mis Cuentas',androidSubtitle:'Usa tu huella o rostro'})}
function unlockOk(){
const L=$('#lock');if(!L.innerHTML||L.classList.contains('out'))return;
if(matchMedia('(prefers-reduced-motion: reduce)').matches){L.innerHTML='';return}
L.innerHTML='<div class="uo" role="status"><svg class="ur" viewBox="0 0 52 52" width="124" height="124" aria-hidden="true"><circle class="uc" cx="26" cy="26" r="24" fill="none" stroke="currentColor" stroke-width="3"/><path class="ut" fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" d="M14 27l8 8 16-17"/></svg><h1>¡Bienvenido!</h1></div>';
L.classList.add('out');say('Desbloqueado');
setTimeout(()=>{L.classList.remove('out');L.innerHTML='';const a=$('#app'),n=document.querySelector('nav');a.classList.add('in');n.classList.add('in');setTimeout(()=>{a.classList.remove('in');n.classList.remove('in')},700)},1050)}
document.addEventListener('visibilitychange',()=>{if(!NATIVE&&document.hidden&&S.pin&&!bioBusy&&!$('#lock').innerHTML)showLock()});
['#sheet','#tut'].forEach(s=>new MutationObserver(()=>{const b=$(s+' .btn');if(b&&!$(s+' input'))b.focus()}).observe($(s),{childList:true}));
const mq=matchMedia('(prefers-color-scheme: dark)');
function applyTheme(){const R=document.documentElement,t=S.theme||'auto';if(t==='auto')R.removeAttribute('data-theme');else R.setAttribute('data-theme',t);R.setAttribute('data-m',t==='dark'||(t==='auto'&&mq.matches)?'d':'l');R.setAttribute('data-gl',S.gl&&!S.hc?'1':'0');R.setAttribute('data-ac',S.ac||'az');R.setAttribute('data-fn',S.fn||'sys');R.setAttribute('data-bd',S.bd?'1':'0');loadAtk();
if(NATIVE){const st=(t==='dark'||(t==='auto'&&mq.matches))?'d':'l';if(st!==sbStyle){sbStyle=st;try{SystemBars.setStyle({style:st==='d'?SystemBarsStyle.Dark:SystemBarsStyle.Light}).catch(()=>{})}catch(e){}}}}
if(mq.addEventListener)mq.addEventListener('change',applyTheme);
const chip=(a,v,cur,l)=>`<button class="chip ${cur===v?'on':''}" aria-pressed="${cur===v}" data-a="${a}" data-v="${v}">${l}</button>`;
// ======== Versión nativa: almacenamiento, eventos del sistema y arranque ========
async function loadNative(){
try{const {value}=await Preferences.get({key:'mc1'});if(value)S=Object.assign(S,JSON.parse(value))}catch(e){}}
function setupNativeEvents(){
let away=0;
CapApp.addListener('appStateChange',({isActive})=>{
if(!isActive){away=Date.now();return}
if(S.pin&&away&&Date.now()-away>15000&&!$('#lock').innerHTML)showLock();
away=0});
CapApp.addListener('backButton',()=>{
if($('#sheet').innerHTML){$('#sheet').innerHTML=''}
else if($('#tut').innerHTML){tutEnd()}
else if($('#lock').innerHTML){CapApp.minimizeApp()}
else if(tab!=='home'){tab='home';lim=60;render()}
else CapApp.minimizeApp()})}
async function boot(){
if(NATIVE){document.documentElement.setAttribute('data-native','1');await loadNative();setupNativeEvents()}
render();if(S.pin)showLock();else if(!S.seen)tutShow();
if(NATIVE){try{await SplashScreen.hide()}catch(e){}}}
boot().catch(()=>{try{render()}catch(e){}});

