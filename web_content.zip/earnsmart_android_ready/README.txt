EarnSmart — Android-friendly installable web app

IMPORTANT: This is an installable web app/PWA package, not a signed APK and not yet a Google Play Store release.

Try it on your Android phone:
1. Extract this ZIP file.
2. To install it as an app, the files must be hosted over HTTPS. You can use a static hosting service such as GitHub Pages or another HTTPS host.
3. Open the hosted app URL in Chrome.
4. Open Chrome's menu (⋮) and choose "Install app" or "Add to Home screen" (wording varies).
5. Launch EarnSmart from your home screen.

Opening index.html directly from your Files app may let you test the prototype, but service workers and installation generally require HTTPS or localhost.

Included features:
- Quizzes, virtual points, activity history, profile nickname
- PWA manifest, offline cache, app icons

No real cash payouts, ad network, backend, or cloud account system is included. Points have no cash value. A Play Store release requires a proper Android package/build, testing, policy review, and developer account eligibility.
