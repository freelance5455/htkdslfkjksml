# Socle 2.4 — Messagerie, presse et offres commerciales entrantes

## Fonctionnalités intégrées

### Messagerie et relations
- Boîte de réception persistante, avec messages idempotents et réponses historisées.
- Interlocuteurs pris en charge : damistes, supporters, direction et presse.
- Les réponses appliquent des effets réels et plafonnés sur la confiance de la direction, la satisfaction des supporters, la réputation médiatique et le moral individuel des damistes.
- Après un match du club dirigé, le moteur crée une demande de réaction médiatique. Une défaite ou un nul peut aussi provoquer un message des supporters ; une défaite déclenche un message de la direction. Le moral du titulaire est actualisé ; une préoccupation du damiste est générée lorsqu'il atteint le seuil de 45/100.
- Les réponses de presse et les réactions du manager sont conservées dans l'historique.

### Offres commerciales
- Le moteur n'expose aucune fonction de démarchage sortant : une offre doit être reçue depuis une structure existante du catalogue historique (sponsor, partenaire, promoteur, banque ou firme).
- Une offre entrante contient les conditions initiales et les limites de négociation communiquées par la structure.
- Le manager peut accepter, refuser ou proposer d'autres conditions. Une contre-proposition n'est acceptée que si elle respecte les limites transmises par le partenaire.
- Le contrat n'est signé qu'après accord des deux parties. Les fonds sont ajoutés au budget du club uniquement à la signature ; la signature est idempotente.
- Les offres et contrats sont persistants et migrés sans perte depuis les anciennes sauvegardes.

## Limites restantes de cette première tranche
- Le déclenchement automatique des nouvelles offres entrantes selon la réputation, les résultats et la division reste à intégrer. Le moteur et l'interface savent traiter les propositions entrantes, mais ne fabriquent pas de montants ni de conditions commerciales non calibrés.
- La négociation complète des contrats des damistes (attentes salariales, primes, durée, statut, clauses et réponses du joueur) reste à développer dans la tranche suivante. Aucun barème salarial fictif n'a été introduit.
- La presse est actuellement liée aux réactions d'après-match ; les conférences de presse pré-match et les demandes liées aux transferts restent à construire.
- Le test visuel complet dans un navigateur n'a pas été validé.

## Préservation
Les huit compétitions et les catalogues historiques sont conservés. Les modifications du socle 2.4 ajoutent les données de gestion relationnelle et les panneaux correspondants sans modifier les règles sportives ou les calendriers des compétitions.

## Vérifications
- 145 tests automatisés réussis.
- Vérification syntaxique JavaScript réussie.
- Tests dédiés : messages des quatre catégories, effets relationnels, idempotence des événements, offres commerciales entrantes, limites de négociation, refus, signature unique, effet budgétaire à la signature et migration des sauvegardes.
