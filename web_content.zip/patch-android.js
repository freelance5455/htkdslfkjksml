// AndroidManifest me permissions jodta hai
const fs = require('fs');
const p = 'android/app/src/main/AndroidManifest.xml';
let x = fs.readFileSync(p, 'utf8');
const perms = ['RECORD_AUDIO', 'READ_CONTACTS', 'CAMERA', 'USE_BIOMETRIC', 'MODIFY_AUDIO_SETTINGS'];
let add = perms.filter(n => !x.includes('android.permission.' + n))
  .map(n => '    <uses-permission android:name="android.permission.' + n + '" />\n').join('');
add += '    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="28" />\n';
add += '    <queries><intent><action android:name="android.speech.RecognitionService" /></intent></queries>\n';
x = x.replace('<application', add + '\n    <application');
x = x.replace('<application', '<application android:requestLegacyExternalStorage="true"');
fs.writeFileSync(p, x);
console.log('Manifest patched');
