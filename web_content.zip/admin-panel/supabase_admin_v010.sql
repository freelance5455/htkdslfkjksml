-- =====================================================
--  PISTOL DUEL — Panel Admin (Global v0.10)
--  Jalankan SEKALI di: Supabase → SQL Editor → New query → Run
--  Aman dijalankan ulang.
-- =====================================================

-- 1) Daftar admin (akun yang boleh memakai panel admin)
create table if not exists public.admins (
    id uuid primary key references auth.users(id) on delete cascade
);
alter table public.admins enable row level security;

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public as $$
    select exists (select 1 from public.admins where id = auth.uid());
$$;

create or replace function public.my_uid()
returns text language sql stable security definer set search_path = public as $$
    select data->>'uid' from public.profiles where id = auth.uid();
$$;

drop policy if exists "admins select self" on public.admins;
create policy "admins select self" on public.admins
    for select using (id = auth.uid());

-- Jadikan akun game bernama "admin" sebagai admin panel.
-- PENTING: username 'admin' dicadangkan game (akun lokal offline), jadi TIDAK bisa dipakai online.
-- Sudah diisi: akun online 'RapzAdmin' (ditulis huruf kecil).
insert into public.admins (id)
select id from public.profiles where lower(username) = 'rapzadmin'
on conflict do nothing;

-- Admin boleh melihat semua profil pemain (untuk cari pemain & lihat koin)
drop policy if exists "profiles admin select" on public.profiles;
create policy "profiles admin select" on public.profiles
    for select using (public.is_admin());

-- 2) Pengaturan aplikasi (maintenance, pengumuman, info top up)
create table if not exists public.app_config (
    key        text primary key,
    value      jsonb not null default '{}'::jsonb,
    updated_at timestamptz not null default now()
);
alter table public.app_config enable row level security;

drop policy if exists "config read all"    on public.app_config;
drop policy if exists "config admin write" on public.app_config;
create policy "config read all" on public.app_config
    for select using (true);
create policy "config admin write" on public.app_config
    for all using (public.is_admin()) with check (public.is_admin());

insert into public.app_config (key, value) values
    ('status', '{"maintenance":false,"message":"","announce":"","announce_id":""}'),
    ('topup',  '{"text":""}')
on conflict (key) do nothing;

-- 3) Hadiah dari admin ke pemain (koin / gems) — masuk ke Inbox pemain
create table if not exists public.admin_gifts (
    id         uuid primary key default gen_random_uuid(),
    uid        text not null,
    title      text not null check (char_length(title) between 1 and 60),
    body       text not null check (char_length(body) between 1 and 300),
    coins      int  not null default 0 check (coins between 0 and 1000000),
    gems       int  not null default 0 check (gems  between 0 and 100000),
    created_at timestamptz not null default now()
);
create index if not exists admin_gifts_uid on public.admin_gifts (uid, created_at);
alter table public.admin_gifts enable row level security;

drop policy if exists "gifts read own or admin" on public.admin_gifts;
drop policy if exists "gifts admin insert"      on public.admin_gifts;
drop policy if exists "gifts admin delete"      on public.admin_gifts;
create policy "gifts read own or admin" on public.admin_gifts
    for select using (public.is_admin() or uid = public.my_uid());
create policy "gifts admin insert" on public.admin_gifts
    for insert with check (public.is_admin());
create policy "gifts admin delete" on public.admin_gifts
    for delete using (public.is_admin());

-- 4) Pesan pemain <-> admin (DM, termasuk permintaan top up)
create table if not exists public.messages (
    id         bigint generated always as identity primary key,
    uid        text    not null,
    username   text    not null,
    from_admin boolean not null default false,
    kind       text    not null default 'chat' check (kind in ('chat','topup')),
    body       text    not null check (char_length(body) between 1 and 500),
    read_admin boolean not null default false,
    created_at timestamptz not null default now()
);
create index if not exists messages_uid on public.messages (uid, created_at);
alter table public.messages enable row level security;

drop policy if exists "msg read own or admin" on public.messages;
drop policy if exists "msg insert"            on public.messages;
drop policy if exists "msg admin update"      on public.messages;
drop policy if exists "msg admin delete"      on public.messages;
create policy "msg read own or admin" on public.messages
    for select using (public.is_admin() or uid = public.my_uid());
create policy "msg insert" on public.messages
    for insert with check (
        (public.is_admin() and from_admin)
        or (not from_admin and uid = public.my_uid()
            and lower(username) = (select lower(p.username) from public.profiles p where p.id = auth.uid()))
    );
create policy "msg admin update" on public.messages
    for update using (public.is_admin()) with check (public.is_admin());
create policy "msg admin delete" on public.messages
    for delete using (public.is_admin());

-- Batas anti-spam: pemain maksimal 10 pesan per 10 menit
create or replace function public.messages_rate()
returns trigger language plpgsql as $$
begin
    if not new.from_admin then
        if (select count(*) from public.messages
             where uid = new.uid and not from_admin
               and created_at > now() - interval '10 minutes') >= 10 then
            raise exception 'Terlalu banyak pesan. Coba lagi beberapa menit.';
        end if;
    end if;
    return new;
end $$;

drop trigger if exists messages_rate_t on public.messages;
create trigger messages_rate_t before insert on public.messages
    for each row execute function public.messages_rate();
