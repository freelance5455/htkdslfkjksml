# Kotak Lifestyle Survey - Native Android WebView Project

This project wraps the existing offline Lifestyle Survey HTML in a native Android WebView.

## Why this version fixes the problem
The previous APKForge wrapper treated `tel:` as a web URL and showed `appassets.androidplatform.net/web/tel...`.
This project installs a native WebViewClient that intercepts:

- `tel:` -> Android dialer
- `https://wa.me/...` -> WhatsApp/external app
- Android `intent://contacts/insert...` -> Android Contacts create-contact screen
- normal local survey URLs -> remain inside the WebView

Android's WebView documentation recommends overriding URL loading and launching an Android Intent for URLs that should be handled outside the WebView.

## Build
Open this folder in Android Studio, allow Gradle sync, then use:
Build > Build APK(s)

The generated debug APK will normally be under:
`app/build/outputs/apk/debug/app-debug.apk`

## Important
The survey remains offline for its stored data (localStorage). Internet permission is present so WhatsApp HTTPS links can be handed to external apps, but the survey data is not uploaded by this wrapper.
