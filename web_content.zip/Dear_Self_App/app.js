'use strict';
const $ = id => document.getElementById(id);
const milestones = [3,5,7,10,14,20,25,31,45,60,75,90];
const rewards = ['⭐','❤️','👑','💎','🎁','🏆','🌟','💎','🎁','🔥','👑','🏆'];
const duas = [
 'اللہ تعالیٰ مجھے نیک نکاح کی توفیق عطا فرما۔','میرے دل کو حلال محبت میں ثابت رکھ۔','میری شرمگاہ کو ہمیشہ محفوظ فرما۔','مجھے گناہوں سے توبہ اور نیکی کی توفیق دے۔','میرے رشتے کو خوشیوں سے بھر دے۔','میرے دل میں ایمان اور صبر پیدا فرما۔','میری زندگی میں سکون اور رحمت عطا فرما۔','مجھے حرام تعلقات سے دور رکھ۔','میری شادی کو کامیاب اور مبارک فرما۔','ہمیشہ اپنے فضل و کرم سے مجھے سنبھالتا رہ۔'
];
const KEY = 'dearSelf.v2';
const OLD_KEY = 'dearSelf.v1';
let storageAvailable = true;
let memoryState = null;
function readSavedState(){
 try {
  const raw = localStorage.getItem(KEY) || localStorage.getItem(OLD_KEY);
  if (raw) return JSON.parse(raw);
 } catch (e) { storageAvailable = false; }
 return null;
}
function makeInitialState(){ return {start:Date.now(),relapses:0,history:[],longest:0,theme:'dark',unlocked:[]}; }
let state = readSavedState() || makeInitialState();
if (!Array.isArray(state.history)) state.history=[];
if (!Array.isArray(state.unlocked)) state.unlocked=[];
if (!Number.isFinite(Number(state.start))) state.start=Date.now();
state.start=Number(state.start);
state.relapses=Math.max(0,Number(state.relapses)||0);
state.longest=Math.max(0,Number(state.longest)||0);
state.theme=state.theme==='light'?'light':'dark';
function save(){
 const serialized=JSON.stringify(state);
 try { localStorage.setItem(KEY,serialized); storageAvailable=true; }
 catch(e) { storageAvailable=false; memoryState=serialized; }
}
function elapsed(){return Math.max(0,Date.now()-state.start)}
function days(){return Math.floor(elapsed()/86400000)}
function fmt(n){return String(n).padStart(2,'0')}
function toast(msg){const t=$('toast');t.textContent=msg;t.style.display='block';if(window.toastTimer)clearTimeout(window.toastTimer);window.toastTimer=setTimeout(()=>t.style.display='none',2600)}
function update(){
 const ms=elapsed(),d=Math.floor(ms/86400000),h=Math.floor(ms%86400000/3600000),m=Math.floor(ms%3600000/60000),s=Math.floor(ms%60000/1000);
 $('days').textContent=d;$('hours').textContent=fmt(h);$('minutes').textContent=fmt(m);$('seconds').textContent=fmt(s);
 const pct=Math.min(100,Math.floor(d/90*100));
 ['homeFill','journeyFill'].forEach(id=>$(id).style.width=pct+'%');$('homePercent').textContent=pct+'%';$('journeyPercent').textContent=pct+'%';$('homeProgress').textContent=`${d} / 90 Days`;$('journeyCaption').textContent=`${d} / 90 Days`;
 $('streak').textContent=d+' Days';$('relapses').textContent=state.relapses+' Times';$('bestStreak').textContent=Math.max(d,state.longest)+' Days';$('totalDays').textContent=d+' Days';$('journeyRelapses').textContent=state.relapses+' Times';
 $('pStreak').textContent=d;$('pDays').textContent=d;$('pRelapses').textContent=state.relapses;$('pBest').textContent=Math.max(d,state.longest)+' Days';$('pTotal').textContent=d+' Days';
 renderMilestones(d);drawChart(d);renderHistory();
}
function renderMilestones(currentDays=days()){
 // Keep rewards earned in earlier streaks; newly earned rewards are saved once.
 let changed=false;
 milestones.forEach(day=>{if(currentDays>=day&&!state.unlocked.includes(day)){state.unlocked.push(day);changed=true;}});
 if(changed)save();
 const list=$('milestoneList');list.innerHTML='';
 milestones.forEach((day,i)=>{
  const unlocked=state.unlocked.includes(day);const row=document.createElement('div');row.className='milestone'+(unlocked?' milestone-earned':'');
  const icon=document.createElement('span');icon.className='reward-icon';icon.textContent=rewards[i];
  const info=document.createElement('div');const title=document.createElement('strong');title.textContent=day+' Days';const desc=document.createElement('small');desc.textContent=unlocked?'Unlocked! Keep going!':(i===0?'Keep Going!':'Your effort inspires!');info.append(title,desc);
  const lock=document.createElement('span');lock.className='lock'+(unlocked?' unlocked':'');lock.textContent=unlocked?'✓ Unlocked':'🔒 Locked';row.append(icon,info,lock);list.append(row);
 });
 const next=milestones.find(x=>!state.unlocked.includes(x));$('nextMilestone').textContent=next?next+' Days':'All Rewards Unlocked! 🎉';
}
function renderDuas(){const list=$('duaList');list.innerHTML='';duas.forEach((dua,i)=>{const row=document.createElement('div');row.className='dua-row';const num=document.createElement('span');num.className='dua-num';num.textContent=i+1;const txt=document.createElement('span');txt.className='dua-text';txt.dir='rtl';txt.textContent=dua;const btn=document.createElement('button');btn.className='copy-btn';btn.textContent='▢';btn.setAttribute('aria-label','Copy dua');btn.onclick=async()=>{try{if(navigator.clipboard&&window.isSecureContext){await navigator.clipboard.writeText(dua);toast('Dua copied');}else{throw new Error('Clipboard unavailable');}}catch(e){toast(dua)}};row.append(num,txt,btn);list.append(row)})}
function drawChart(d){const c=$('chart');if(!c||!c.getContext)return;const ctx=c.getContext('2d'),w=c.width,h=c.height;ctx.clearRect(0,0,w,h);ctx.strokeStyle='#482126';ctx.lineWidth=1;for(let i=0;i<=4;i++){let y=15+(h-40)*i/4;ctx.beginPath();ctx.moveTo(35,y);ctx.lineTo(w-15,y);ctx.stroke();ctx.fillStyle='#f0d9da';ctx.font='13px sans-serif';ctx.fillText(String(100-i*25),3,y+4)}ctx.strokeStyle='#ff3548';ctx.lineWidth=4;ctx.beginPath();let points=[];for(let i=0;i<=6;i++){let day=Math.min(d,Math.round(90*i/6));let x=35+(w-50)*i/6,y=h-25-(h-45)*Math.min(100,day/90*100)/100;points.push([x,y]);if(i===0)ctx.moveTo(x,y);else ctx.lineTo(x,y)}ctx.stroke();points.forEach(([x,y])=>{ctx.fillStyle='#ff5963';ctx.beginPath();ctx.arc(x,y,5,0,Math.PI*2);ctx.fill()});ctx.fillStyle='#fff';ctx.font='13px sans-serif';[0,15,30,45,60,75,90].forEach((n,i)=>ctx.fillText(n,30+(w-50)*i/6,h-5))}
function renderHistory(){const box=$('historyList');box.innerHTML='';state.history.slice().reverse().forEach(item=>{const p=document.createElement('p');p.className='setting-row';p.textContent=new Date(item).toLocaleString();box.append(p)})}
function showPage(page){document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.id===page));document.querySelectorAll('.nav-btn').forEach(b=>b.classList.toggle('active',b.dataset.page===page));$('backBtn').classList.toggle('hidden',['home','milestones','duas','progress'].includes(page));if(page==='settings')$('themeSelect').value=state.theme;window.scrollTo({top:0,behavior:'auto'});}
document.querySelectorAll('.nav-btn').forEach(b=>b.onclick=()=>showPage(b.dataset.page));
$('settingsBtn').onclick=()=>showPage('settings');$('backBtn').onclick=()=>showPage('home');
function openConfirm(title,message,confirmLabel,onConfirm){$('confirmTitle').textContent=title;$('confirmMessage').textContent=message;$('confirmAction').textContent=confirmLabel;$('confirmOverlay').classList.remove('hidden');$('confirmOverlay').setAttribute('aria-hidden','false');$('confirmAction').onclick=()=>{closeConfirm();onConfirm();};}
function closeConfirm(){$('confirmOverlay').classList.add('hidden');$('confirmOverlay').setAttribute('aria-hidden','true');$('confirmAction').onclick=null;}
$('confirmCancel').onclick=closeConfirm;$('confirmOverlay').addEventListener('click',e=>{if(e.target===$('confirmOverlay'))closeConfirm()});document.addEventListener('keydown',e=>{if(e.key==='Escape')closeConfirm()});
$('relapseBtn').onclick=()=>openConfirm('Reset your streak?','Your current streak will return to zero. Your relapse count and history will be saved. Rewards already earned will stay unlocked.','Reset streak',()=>{const previous=days();state.longest=Math.max(state.longest,previous);state.history.push(Date.now());state.relapses++;state.start=Date.now();save();update();toast('Streak reset. A fresh start ❤️')});
$('themeSelect').onchange=e=>{state.theme=e.target.value==='light'?'light':'dark';document.body.classList.toggle('light',state.theme==='light');save()};
$('resetAllBtn').onclick=()=>openConfirm('Reset all app data?','This permanently clears your streak, relapse history and unlocked rewards on this browser.','Reset all data',()=>{const theme=state.theme;state={...makeInitialState(),theme};save();update();showPage('home');toast('All progress reset')});
$('exportBtn').onclick=()=>{try{const blob=new Blob([JSON.stringify(state,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='dear-self-progress.json';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);}catch(e){toast('Export is not supported in this app view')}};
$('historyBtn').onclick=()=>{$('historyList').classList.toggle('hidden')};
renderDuas();document.body.classList.toggle('light',state.theme==='light');update();save();setInterval(update,1000);
if(!storageAvailable)toast('Storage is restricted: progress may not persist after closing the app.');
