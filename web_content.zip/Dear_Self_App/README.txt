Dear Self — Offline web app

OFFLINE USE
1. Extract the entire ZIP into one folder. Do not separate index.html, style.css, app.js, or romantic-background.png.
2. Open index.html in a modern browser, or load this folder's index.html as the local asset in your Android WebView.
3. No internet connection is required: the stylesheet, JavaScript, and background image are local files.

PROGRESS / RELAPSE / MILESTONES
- The timer starts on the first launch and continues using the saved start timestamp.
- The relapse button opens an in-app confirmation dialog (not the browser confirm popup), records the relapse time, saves the previous streak as a best streak, and resets the current streak to zero.
- Milestones unlock when their day count is reached: 3, 5, 7, 10, 14, 20, 25, 31, 45, 60, 75, and 90. Earned milestones stay unlocked after a relapse.
- Progress is saved in localStorage for the same browser/WebView origin. If the app/browser clears site data or uses a restricted WebView configuration, progress may not persist.
- Reset All App Data clears the saved progress and earned rewards after confirmation.

IMPORTANT ANDROID WEBVIEW NOTE
If the app itself displays an appassets.androidplatform.net error before index.html appears, that is an Android wrapper/WebView loading-path or asset-configuration issue, not an HTML page error. The Android wrapper must load the bundled index.html and allow local asset access. Keep all files in the same app asset folder.
