# STYLEHUB Firestore Security Specification

## 1. Data Invariants

1. **Admin Authority**: Only verified administrators (`/admins/{uid}` or verified primary admin email) may create, update, or delete `products`, `categories`, `settings`, and `admins`, or update `orders` status/paymentStatus.
2. **Customer PII Isolation**: A customer can only read and update their own `/users/{userId}` document and cannot escalate `role` beyond `"customer"`.
3. **Order Ownership & Immutability**: A customer can only create `/orders/{orderId}` and `/orders/{orderId}/items/{itemId}` with `userId == request.auth.uid`, `status == "Pending"`, and `paymentStatus == "Pending"`, and can only read their own orders. Customers cannot modify order status, payment status, or totals after creation.
4. **Server-Enforced Price, Quantity & Stock Integrity**: Every `/orders/{orderId}/items/{itemId}` write is cross-checked in Firestore Rules against `/products/{productId}` to enforce exact catalog pricing (`discountPrice` if active, else `price`), `quantity >= 1 && quantity <= product.stock`, and `lineTotal == unitPrice * quantity`. The parent `/orders/{orderId}` write verifies `subtotal`, `shippingFee`, `totalQuantity`, and `totalAmount` against the atomic line items via `getAfter`.
5. **Atomicity & Path Hardening**: All document IDs are strictly bounded (`^[a-zA-Z0-9_-]+$`, <= 128 chars), timestamps use `request.time`, and shadow/ghost fields are blocked via `keys().hasOnly()` and `affectedKeys().hasOnly()`.

## 2. The "Dirty Dozen" Adversarial Payloads

1. **Self-Admin Escalation**: Customer writes `/users/{uid}` with `role: "admin"` -> **DENIED**.
2. **Shadow Field Injection on User**: Customer writes `/users/{uid}` with extra field `isVip: true` -> **DENIED**.
3. **Cross-User PII Read**: Customer A requests `get` on `/users/{customerB}` or `list` on `/users` -> **DENIED**.
4. **Unverified Email Spoofing**: Sign-in token claims admin email with `email_verified: false` -> **DENIED**.
5. **Non-Admin Product Tampering**: Customer attempts to create/update `/products/{productId}` price to `0.01` -> **DENIED**.
6. **Price Forgery in Order Item**: Customer submits `/orders/{orderId}/items/item_0` with `unitPrice: 1` when catalog price is `129` -> **DENIED**.
7. **Order Total Mismatch**: Customer submits `/orders/{orderId}` with `totalAmount: 1` while `item_0.lineTotal` is `129` -> **DENIED**.
8. **Out-of-Stock Quantity Attack**: Customer submits order item with `quantity: 999` exceeding `product.stock` -> **DENIED**.
9. **Orphan Order Item Attack**: Customer submits `/orders/{orderId}/items/item_0` without creating parent `/orders/{orderId}` -> **DENIED**.
10. **Customer Order Status Escalation**: Customer attempts `update` on `/orders/{orderId}` setting `status: "Delivered"` or `paymentStatus: "Paid"` -> **DENIED**.
11. **Order Query Scraping**: Customer executes `list` on `/orders` without `where('userId', '==', auth.uid)` -> **DENIED**.
12. **ID Poisoning / Payload Exhaustion**: Attacker writes `/orders/{1500_char_id}` or `customerName` > 100 chars -> **DENIED**.
