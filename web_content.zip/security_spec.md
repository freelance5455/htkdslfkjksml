# RAJU AI — Firestore Security Specification (Phase 0 TDD)

## 1. Data Invariants
1. **Global Default-Deny**: Any path not explicitly matched is denied (`allow read, write: if false;`).
2. **Verified Identity**: All writes require `request.auth != null` and `request.auth.token.email_verified == true`.
3. **Strict Ownership Isolation**:
   - `/users/{userId}` can only be read, created, updated, or deleted when `request.auth.uid == userId` and `incoming().uid == request.auth.uid`.
   - `/conversations/{messageId}`, `/memories/{memoryId}`, `/tasks/{taskId}`, and `/study_progress/{progressId}` require `ownerId == request.auth.uid` on both read (`get`/`list`) and write (`create`/`update`/`delete`), plus `exists(/databases/$(database)/documents/users/$(request.auth.uid))` on creation to prevent orphaned records.
4. **Explicit Consent Invariant**: A `PersonalMemory` document cannot be created or updated unless `incoming().userConsented == true`.
5. **Temporal Integrity**: `createdAt` and `updatedAt` must equal `request.time` on creation, `createdAt` is immutable on update, and `updatedAt == request.time` on update.
6. **Path Variable Hardening**: Every document ID (`userId`, `messageId`, `memoryId`, `taskId`, `progressId`) on single-document operations (`get`, `create`, `update`, `delete`) must satisfy `isValidId(id)` (`<= 128` chars, `^[a-zA-Z0-9_\-]+$`).

## 2. The "Dirty Dozen" Payloads (All Must Return `PERMISSION_DENIED`)
1. **Identity Spoofing on Profile**: Authenticated user `user_A` attempts `create` on `/users/user_B` with `{"uid": "user_B", ...}`.
2. **Unverified Email Write**: Authenticated user with `email_verified == false` attempts to create a memory at `/memories/mem_1`.
3. **Shadow Field Injection on Create**: User sends a valid `PersonalMemory` payload plus extra ghost key `{"isAdmin": true}`.
4. **Update-Gap Type Poisoning**: User updates `/tasks/task_1` with `{"title": 99999, "updatedAt": request.time}` bypassing schema checks if `isValidUserTask` were omitted.
5. **Immutable Field Tampering**: User updates `/memories/mem_1` changing `ownerId` or `createdAt`.
6. **Client Timestamp Forgery**: User creates `/conversations/msg_1` with a forged past or future `createdAt` instead of `request.time`.
7. **Consent Bypass on Memory**: User attempts to create `/memories/mem_2` with `{"userConsented": false}`.
8. **ID Poisoning Attack**: User attempts `create` at `/tasks/invalid$id!with*special*chars` or a 1,500-byte ID.
9. **Denial-of-Wallet Oversized String**: User attempts `create` on `/conversations/msg_2` with a 100,000-character `content` string (exceeding `maxLength: 20000`).
10. **Cross-Tenant List Scraping**: Authenticated user `user_A` executes an unfiltered `list` query on `/memories` or `/conversations` without `where('ownerId', '==', 'user_A')`.
11. **Orphaned Sub-Entity Creation**: Authenticated user attempts to create `/tasks/task_1` before their parent `/users/$(request.auth.uid)` profile exists.
12. **Unauthorized Action Keys on Update**: User updates `/conversations/msg_1` attempting to modify message `content` or `role` (conversations are append-only/delete-only; updates are forbidden).
