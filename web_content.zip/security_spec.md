# Security Specification for Ilm-e-Sarf & Ilm-e-Nahw Academy

## 1. Data Invariants
1. **User Isolation**: A user can only access and modify their own `/users/{userId}` document and nested subcollections (`bookmarks`, `notes`, `progress`, `quizRecords`).
2. **Path & Token Matching**: `request.auth.uid == userId` must be strictly enforced on all reads and writes.
3. **No Cross-User Leakage**: List queries are strictly restricted to the user's own path.
4. **Field Validation**: Strings must have length constraints and correct data types. User ID must match auth UID.
5. **No Blind Admin Claims**: Auth tokens do not contain unverified roles. Access is strictly scoped to the owner UID.

## 2. The "Dirty Dozen" Threat Payloads
1. **Ghost Field Injection**: Attempt to write `{ "isAdmin": true, "extra": "exploit" }` to `/users/{userId}` -> Denied.
2. **User ID Impersonation**: Authenticated user `userA` writing to `/users/userB` -> Denied.
3. **Unauthenticated Read**: Reading any user document without authentication -> Denied.
4. **Unauthenticated Write**: Creating a bookmark without auth -> Denied.
5. **Path Traversal / Malicious ID**: Creating doc with ID containing `/` or 2000 chars -> Denied.
6. **Cross-User Bookmark Steal**: Reading `/users/userB/bookmarks` as `userA` -> Denied.
7. **Type Poisoning**: Sending `score: "not_a_number"` to `quizRecords` -> Denied.
8. **Oversized Note Payload**: Sending 2MB string in `noteText` exceeding 5000 chars -> Denied.
9. **Invalid Enum in Progress**: Sending `status: "hacked"` instead of valid enum -> Denied.
10. **Tampering with Note Owner**: Changing `userId` to someone else during update -> Denied.
11. **List Scraping**: Querying the root without path scoping -> Denied by global deny.
12. **Malformed Timestamp Format**: Sending non-date string to timestamp fields -> Denied.
