# Security Specification (Kitap Atölyesi)

## 1. Data Invariants
- Every `Book` document under `/users/{userId}/books/{bookId}` must belong exclusively to `request.auth.uid == userId` and carry `data.userId == request.auth.uid`.
- `creationMethod` must be strictly `'ai'` or `'manual'` and is immutable after creation.
- `coverTheme` must be one of `['crimson', 'midnight', 'emerald', 'parchment', 'obsidian']`.
- Every `Chapter` document under `/users/{userId}/books/{bookId}/chapters/{chapterId}` must belong to `request.auth.uid == userId`, have `data.userId == request.auth.uid`, and `data.bookId == bookId`.
- `createdAt` and `userId` (and `bookId` on chapters) are immutable on updates.
- All timestamps (`createdAt`, `updatedAt`) must be valid Firestore `timestamp` objects `<= request.time`.

## 2. The "Dirty Dozen" Payloads
1. **Unauthenticated Read/Write**: Reading or writing `/users/alice_123/books/book_1` with `auth == null`.
2. **Cross-User Read**: User `bob_456` reading `/users/alice_123/books/book_1`.
3. **Identity Spoofing on Create**: User `alice_123` creating `/users/alice_123/books/book_1` with `userId: "bob_456"`.
4. **Ghost Field Injection (Shadow Create/Update)**: Including `isAdmin: true` or `verified: true` in a `Book` or `Chapter` payload.
5. **Immutable Field Mutation**: Updating `createdAt`, `userId`, or `creationMethod` on an existing `Book`.
6. **Invalid Enum Value**: Creating a `Book` with `creationMethod: "hacked"` or `coverTheme: "neon"`.
7. **Empty or Oversized Title**: Creating a `Book` or `Chapter` with `title: ""` or `title` > 200 characters.
8. **Negative Counts**: Setting `chapterCount: -1` or `totalWordCount: -50` on a `Book`.
9. **Future Timestamp Injection**: Setting `createdAt` or `updatedAt` in the future (`> request.time`).
10. **Path/Body BookId Mismatch on Chapter**: Creating `/users/alice_123/books/book_1/chapters/ch_1` with `bookId: "book_2"`.
11. **Malformed Document ID**: Using invalid characters or >128 chars in `{bookId}` or `{chapterId}`.
12. **Blanket Unfiltered List Query**: Attempting to list books or chapters across another user's path.
