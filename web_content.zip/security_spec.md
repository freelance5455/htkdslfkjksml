# FormulaX Pro — Security Specification

## 1. Data Invariants
1. Formulas & Categories are publicly readable, but write/update/delete operations are strictly restricted to authenticated administrators.
2. User Profiles (`users/{userId}`) can only be created by the authenticated owner with role `user`. Role escalation to `admin` is forbidden unless performed by an existing admin.
3. User Favorites and Calculation History can only be read, created, or deleted by the document's authenticated owner (`resource.data.userId == request.auth.uid`).
4. Feedback submissions are write-only for clients; feedback listing, updates, and resolution are strictly admin-only.
5. Bootstrapped admin email `jmmadhusudhuoncz@gmail.com` is granted administrative access.

## 2. The "Dirty Dozen" Threat Payloads & Mitigations
1. **Unauthenticated Formula Modification**: Anonymous user attempts to update a physics formula -> REJECTED (`isAdmin()` check fails).
2. **Standard User Privilege Escalation**: User sends `{ role: "admin" }` to `/users/{userId}` -> REJECTED (non-admin cannot alter role).
3. **Ghost Identity Favorite Insertion**: User A sends `userId: "user_B"` to `/favorites` -> REJECTED (`request.resource.data.userId == request.auth.uid` check).
4. **Foreign History Snooping**: User A queries `/history/{userB_history}` -> REJECTED (`resource.data.userId == request.auth.uid`).
5. **Cross-Tenant History Erasure**: User A issues delete on User B's history record -> REJECTED (`resource.data.userId == request.auth.uid`).
6. **Feedback Sniffing**: Non-admin attempts `get` or `list` on `/feedback` collection -> REJECTED (only admins can read feedback).
7. **Malicious Config Alteration**: Normal user tries to set `maintenanceMode: true` in `/appConfig/general` -> REJECTED (admin-only).
8. **Negative / Null String Injection in Feedback**: Empty payload `{ message: "" }` -> REJECTED (requires `message.size() > 0`).
9. **Formula Poisoning via Shadow Fields**: Non-admin sends malicious formula expression -> REJECTED (`isAdmin()` required).
10. **Admin List Hijacking**: Standard user tries to add self to `/admins` -> REJECTED (`isAdmin()` required).
11. **Impersonated Deletion of Formula**: Authenticated non-admin attempts `deleteDoc(formulas/newtons-second-law)` -> REJECTED.
12. **Blanket Query Scraping**: Malicious client requests `/history` without user scoping -> REJECTED (`resource.data.userId == request.auth.uid` enforces per-user boundary).
