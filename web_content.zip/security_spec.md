# Security Specification — سجل الدوام (Attendance & Rest Tracker)

## 1. Data Invariants
1. A user workspace document `/users/{userId}` can only be created, read, or updated by the authenticated, email-verified user whose `request.auth.uid == userId`.
2. An attendance record `/users/{userId}/records/{recordId}` cannot exist without its parent `/users/{userId}` document (`exists(/databases/$(database)/documents/users/$(userId))`).
3. Every `AttendanceRecord` must bind `userId == request.auth.uid == userId` path segment, `date == recordId` matching `^[0-9]{4}-[0-9]{2}-[0-9]{2}$`, and `monthKey` matching the `YYYY-MM` prefix of `date`.
4. `status` is strictly restricted to `'work'` or `'annual'`, and `note` is a string bounded to `<= 200` characters.
5. `createdAt` and `updatedAt` are strictly server timestamps (`request.time`), and `createdAt`, `userId`, `date`, and `monthKey` are immutable after creation.
6. No blanket `allow list` or `allow read` rules exist; `list` on `/users/{userId}/records` strictly enforces `resource.data.userId == request.auth.uid`.

## 2. Dirty Dozen Adversarial Payloads (Expected: PERMISSION_DENIED)
1. **Unauthenticated Write**: Creating `/users/u1/records/2026-11-26` with `auth = null`.
2. **Unverified Email Write**: Creating `/users/u1/records/2026-11-26` with `email_verified = false`.
3. **Cross-User Spoofing (Path vs Auth)**: User `u2` attempting to write `/users/u1/records/2026-11-26`.
4. **Cross-User Spoofing (Payload `userId`)**: User `u1` attempting to write `{ userId: "u2", ... }` to `/users/u1/records/2026-11-26`.
5. **Shadow / Ghost Field Injection**: Adding `{ isAdmin: true }` or `{ role: "admin" }` to `AttendanceRecord` on create.
6. **Oversized `note` Resource Poisoning**: Sending `note` with 500 characters (`> 200`).
7. **Invalid `status` Enum**: Sending `status: "vacation"` or `status: 123`.
8. **Malformed `recordId` / `date` Mismatch**: Writing `date: "2026-11-25"` under document ID `2026-11-26`, or `recordId: "bad!!id"`.
9. **MonthKey Desync**: Writing `date: "2026-11-26"` with `monthKey: "2026-10"`.
10. **Client Timestamp Forgery**: Providing a client `Date` for `createdAt` or `updatedAt` instead of `request.time`.
11. **Immutable Field Mutation on Update**: Updating `createdAt` or `date` on an existing `AttendanceRecord`.
12. **Orphaned Record Creation**: Creating `/users/u1/records/2026-11-26` before `/users/u1` exists.
