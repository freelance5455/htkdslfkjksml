# Security Specification — نذاكر (Nuzakir)

## 1. Data Invariants
1. **Admin-Only Publishing**: Only the verified admin account (`weeq143900@gmail.com`, `email_verified == true`) may create, update, or delete documents in `/whatsNew/{itemId}`.
2. **Public Student Read**: Students may read (`get` and `list`) `/whatsNew/{itemId}` without authentication so the student hub works immediately when online.
3. **Strict Schema & Bounds**: Every `/whatsNew/{itemId}` document must contain exact required keys (`title`, `description`, `category`, `textKind`, `subjectName`, `mediaType`, `fileUrl`, `fileName`, `fileSize`, `newsDate`, `quizQuestion`, `quizOptions`, `quizCorrectIndex`, `authorUid`, `createdAt`, `updatedAt`), valid `itemId` format, bounded string sizes, `authorUid == request.auth.uid`, and server timestamps (`request.time`).
4. **Quiz Integrity**: `quizOptions` must be a list of size 0 (non-quiz) or 4 (quiz), and `quizCorrectIndex` must be an integer between -1 and 3.
5. **Immutable Provenance**: `authorUid` and `createdAt` cannot change after creation.

## 2. Dirty Dozen Attack Payloads (Expected: PERMISSION_DENIED)
1. Unauthenticated `create` on `/whatsNew/item1`.
2. Non-admin authenticated user (`student@gmail.com`) attempting `create` on `/whatsNew/item2`.
3. Unverified email spoofing (`weeq143900@gmail.com` with `email_verified: false`) attempting `create`.
4. Shadow field injection (`isFeatured: true`) in `create` payload.
5. Missing required field (`updatedAt` omitted) in `create` payload.
6. Oversized `title` (> 180 chars) attempting resource exhaustion.
7. Invalid `itemId` (`../../etc/passwd` or > 128 chars) on `create`/`get`/`delete`.
8. Spoofed `authorUid` (`other-admin-uid != request.auth.uid`) in `create` payload.
9. Client-forged `createdAt` timestamp (`!= request.time`) in `create` payload.
10. Unauthenticated `delete` on `/whatsNew/item1`.
11. Modifying immutable `createdAt` or `authorUid` during `update`.
12. Accessing an undeclared collection (`/users/123` or `/admins/123`) caught by the global deny rule.
