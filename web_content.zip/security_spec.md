# Firestore Security & Architecture Specification — OmniPrompt Studio

## 1. Authentication Method
- **Google Sign-In via Credential Manager (`GetSignInWithGoogleOption`)** is the primary authentication method.
- **Guest Preview Mode** is strictly a UI preview mode with zero Firestore reads or writes (`flowOf(emptyList())`). Any feature action prompts the user to authenticate with Google.
- Anonymous auth (`signInAnonymously()`) and email/password auth are prohibited.

## 2. Collections & Access Control

### `/studio_projects/{projectId}`
- **Entity**: `StudioProject` (stores generated Android Jetpack Compose applications and responsive HTML5/CSS3/JS Websites).
- **Access Rules**:
  - `get`, `list`: Allowed only if `request.auth != null && resource.data.userId == request.auth.uid`.
  - `create`: Allowed only if `request.auth != null && request.resource.data.userId == request.auth.uid` and all fields pass strict schema & length validation.
  - `update`: Allowed only by owner (`resource.data.userId == request.auth.uid`), enforcing immutability of `userId` and `createdAt`.
  - `delete`: Allowed only by owner (`resource.data.userId == request.auth.uid`).

### `/user_subscriptions/{userId}`
- **Entity**: `UserSubscription` (stores direct Stripe Billing subscription status, Checkout Session / Subscription IDs, and monthly generation quota usage).
- **Access Rules**:
  - `get`, `list`: Allowed only if `request.auth != null && request.auth.uid == userId`.
  - `create`: Allowed only if `request.auth != null && request.auth.uid == userId && request.resource.data.userId == request.auth.uid` and all fields pass strict schema & enum validation (`planId` in `['FREE', 'PRO_MONTHLY', 'ENTERPRISE_ANNUAL']`, `status` in `['FREE_TIER', 'CHECKOUT_PENDING', 'ACTIVE', 'TRIALING', 'CANCELED', 'PAST_DUE']`).
  - `update`: Allowed only if `request.auth != null && request.auth.uid == userId && resource.data.userId == request.auth.uid`, enforcing immutability of `userId`.
  - `delete`: Denied (`false`) — subscription records are retained for auditability.
