# Firestore Security Specification (`security_spec.md`)

## 1. Data Invariants
1. **Strict Ownership Isolation**: A `/userTrackers/{userId}` document can only be read, created, updated, or deleted by the authenticated user whose `request.auth.uid == userId` and whose email is verified (`request.auth.token.email_verified == true`).
2. **Identity Integrity**: `incoming().ownerId` must strictly match `request.auth.uid` and `userId` on creation, and `ownerId` is immutable on update (`incoming().ownerId == existing().ownerId`).
3. **Strict Schema & No Shadow Fields**: Every document in `/userTrackers/{userId}` must contain all 9 required keys (`ownerId`, `statusStore`, `subItemStore`, `startedStore`, `streak`, `testStore`, `targetDate`, `createdAt`, `updatedAt`) and no other keys (`hasAll` and `hasOnly`).
4. **Native Firestore Maps**: `statusStore`, `subItemStore`, `startedStore`, `streak`, and `testStore` must be native Firestore `map` objects with bounded key counts (no `JSON.stringify` blobs).
5. **Temporal Integrity**: `createdAt` must equal `request.time` on creation and remain immutable on update. `updatedAt` must equal `request.time` on both creation and update.
6. **No Blanket List Scraping**: Collection-wide `list` operations on `/userTrackers` are denied (`allow list: if false;`); clients access their own document directly via `/userTrackers/{userId}`.

## 2. The "Dirty Dozen" Payloads
1. **Unauthenticated Write**: Writing to `/userTrackers/user_1` with `auth == null`.
2. **Unverified Email Spoof**: Writing to `/userTrackers/user_1` with `auth.uid == 'user_1'` but `email_verified == false`.
3. **Cross-Tenant Read/Write**: Authenticated `user_2` attempting `get` or `update` on `/userTrackers/user_1`.
4. **OwnerId Spoofing on Create**: Authenticated `user_1` creating `/userTrackers/user_1` with `ownerId: 'user_2'`.
5. **OwnerId Mutation on Update**: Authenticated `user_1` updating `/userTrackers/user_1` to change `ownerId` to `'user_2'`.
6. **Shadow Field Injection**: Sending extra field `isAdmin: true` in `/userTrackers/user_1`.
7. **JSON String Blob Injection**: Sending `statusStore: "{\"phy|...\":\"done\"}"` (string instead of native map).
8. **Malformed Target Date**: Sending `targetDate: "2027/05/04"` or a 10KB string in `targetDate`.
9. **Client Timestamp Forgery on Create**: Setting `createdAt` to a past timestamp instead of `request.time`.
10. **CreatedAt Mutation on Update**: Modifying `createdAt` during an update operation.
11. **Path ID Poisoning**: Using a document ID longer than 128 characters or containing special characters outside `^[a-zA-Z0-9_\-]+$`.
12. **Unbounded Map Exhaustion**: Sending a `statusStore` map with more than 1000 keys or `streak` missing required keys `n` and `d`.

## 3. Red Team Audit Summary
- **Shadow Update Test**: Rejected via `data.keys().hasOnly(...)` in `isValidUserTracker` and `affectedKeys().hasOnly(...)` in `allow update`.
- **Email Spoofing Test**: Rejected via `isVerified()` requiring `request.auth.token.email_verified == true`.
- **PII Blanket Test**: No PII is stored in `/userTrackers/{userId}`, and `get` is strictly restricted to `isOwner(userId)`.
- **Query Trust Test**: `allow list: if false;` prevents any collection-level enumeration.
- **Value Poisoning Test**: `isValidUserTracker(incoming())` wraps both `allow create` and `allow update`, validating types, regex patterns, and sizes on every write.
