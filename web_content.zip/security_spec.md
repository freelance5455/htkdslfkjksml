# StyleAI Firestore Security Specification (Phase 0 TDD)

## 1. Data Invariants
1. **Strict Multi-Tenant Isolation**: Every document in `/users/{userId}` and its subcollections (`saved_outfits`, `tryon_sessions`, `recently_viewed`) belongs exclusively to `userId` (`request.auth.uid == userId` and `incoming().userId == request.auth.uid`).
2. **No Unauthenticated Access**: Zero reads or writes are permitted when `request.auth == null`.
3. **Immutable Identity & Creation Timestamps**: `userId` and `createdAt` can never be mutated during an `update` (`incoming().userId == existing().userId && incoming().createdAt == existing().createdAt`).
4. **Server Timestamp Bounds**: `createdAt` and `updatedAt` must be valid Firestore `timestamp` objects with `<= request.time`.
5. **Strict Key & Size Enforcement**: Every string is bounded by `.size()` and every `create`/`update` enforces `hasAll` / `hasOnly` / `affectedKeys().hasOnly()`.

## 2. The "Dirty Dozen" Adversarial Payloads
1. **Unauthenticated Profile Read**: `unauthDb.collection("users").doc("alice_123").get()` -> Reject
2. **Cross-User Profile Read**: `bobDb.collection("users").doc("alice_123").get()` -> Reject
3. **Identity Spoofing on Create**: `aliceDb` creates `/users/alice_123/saved_outfits/outfit1` with `userId: "bob_456"` -> Reject
4. **Ghost Field Injection (Shadow Write)**: `aliceDb` creates `/users/alice_123` with extra field `isAdmin: true` -> Reject
5. **Immutable Field Mutation**: `aliceDb` updates `/users/alice_123` changing `createdAt` -> Reject
6. **Invalid Enum Value**: `aliceDb` sets `membershipTier: "SUPER_VIP"` (not in `['FREE', 'PREMIUM']`) -> Reject
7. **Negative Budget / Price Poisoning**: `aliceDb` sets `priceInr: -500` on a `saved_outfits` doc -> Reject
8. **String Overflow (Denial of Wallet)**: `aliceDb` writes a 2000-char string to `displayName` -> Reject
9. **Path ID Poisoning**: `aliceDb` writes a doc ID with invalid characters or > 128 chars -> Reject
10. **Cross-User Subcollection List**: `bobDb` queries `/users/alice_123/saved_outfits` -> Reject
11. **Cross-User Try-On Deletion**: `bobDb` deletes `/users/alice_123/tryon_sessions/s1` -> Reject
12. **Future Timestamp Spoofing**: `aliceDb` writes `createdAt` far in the future (`> request.time`) -> Reject
