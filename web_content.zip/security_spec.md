# Security Specification: Manhwa Hart

## 1. System Invariants
- Only verified publishers or platform owner (17noranimations17@gmail.com) can publish or modify Manhwas and Chapters.
- Anyone can read published Manhwa series and Chapters (public reading platform).
- Users can only read, create, and delete their own bookmarks (`userId == request.auth.uid`).
- Readers can post comments on chapters with their authenticated identity (`userId == request.auth.uid`).
- Hart Host storage metadata is strictly bounded to prevent abuse and injection.

## 2. The Dirty Dozen Payloads & Guard Assertions
1. **Unauthenticated Manhwa Creation**: Attempt to add a Manhwa without signing in. -> **DENIED**
2. **Publisher Identity Spoofing**: Signed-in user 'UserA' attempts to create a Manhwa with `publisherId: 'UserB'`. -> **DENIED**
3. **Non-Publisher Content Publication**: Standard reader attempts to publish a new Manhwa without publisher role. -> **DENIED**
4. **Chapter Hijacking**: Publisher B attempts to delete or overwrite Publisher A's chapter. -> **DENIED**
5. **Private Bookmark Snooping**: User A attempts to list or query User B's bookmarks. -> **DENIED**
6. **Bookmark Forgery**: User A attempts to create a bookmark in User B's name. -> **DENIED**
7. **Comment Impersonation**: User A posts a comment with `userId: 'Admin'`. -> **DENIED**
8. **Malicious Giant Payload**: An attacker tries to write a chapter with a 5MB payload or oversized title. -> **DENIED** (enforced by `isValidChapter` schema checks).
9. **Role Self-Escalation**: Regular user attempts to write `{ role: 'owner' }` in `publishers/{uid}`. -> **DENIED** (only owner email or existing admin can grant roles).
10. **Immutable Field Modification**: A publisher attempts to change the original `publisherId` or `createdAt` of a Manhwa. -> **DENIED**
11. **Catch-All Denial**: Any unmapped collection or invalid document ID access. -> **DENIED**
12. **Blanket Read Exposure**: Attempting to query bookmarks without filtering by `userId == auth.uid`. -> **DENIED**
