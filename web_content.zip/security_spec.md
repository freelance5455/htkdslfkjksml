# EduToon Education Firestore Security Specification

## 1. Data Invariants

1. **Identity Integrity**: Every user-scoped document (`/users/{userId}` and subcollections) requires `uid == request.auth.uid` on create and immutable `uid` on update.
2. **Academic Class Lock**: A student may set `selectedClass` (1–10) and `classLocked = true` only once when `existing.classLocked == false`. Once locked, no non-admin client can modify `selectedClass`, `classLocked`, or `academicSession`.
3. **Class Change Authority**: Students may create `classChangeReports` only with `status == 'pending'`, `studentId == request.auth.uid`, `currentClass != requestedClass`, and empty `adminNote`/`reviewedBy`. Only an authorized admin (`isAdmin()`) may transition `status` to `'approved'` or `'rejected'`.
4. **PII Isolation**: Email and phone number are stored in `/users/{userId}/private/{docId}` and `/users/{userId}` reads are strictly restricted to `isOwner(userId) || isAdmin()`.
5. **Verified Users**: All writes require verified Google email (`email_verified == true`) or verified Firebase Phone Auth (`phone_number` present).
6. **Zero Auto-Admin & Server-Verified Roles**: No user (including any Google Sign-In account) receives automatic admin privileges. Admin privileges require either Firebase Auth Custom Claims (`admin == true` or `role == 'admin'`) or an existing `/admins/{uid}` registry record created by a backend admin/Firebase Console. Client writes to `/admins/{adminId}` are strictly denied (`allow write: if false;`).
7. **Admin-Only Content Publishing & Storage Uploads**: Only `isAdmin()` may create, edit, or delete `/lessons/{lessonId}`, `/subjects/{subjectId}`, `/quizzes/{quizId}`, and `/announcements/{announcementId}`, or upload PDFs/videos to Firebase Storage.
8. **Quiz Attempt Ownership**: Students can only read and record `/quizAttempts/{attemptId}` for their own `studentId == request.auth.uid` against an existing `/quizzes/{quizId}`. Admins can read all quiz attempts for student progress monitoring.
9. **Temporal Integrity**: All `createdAt`, `updatedAt`, `savedAt`, `downloadedAt`, `openedAt` timestamps must match `request.time`.

## 2. The "Dirty Dozen" Adversarial Payloads

1. **Shadow Role Injection on Registration**: Creating `/users/{uid}` with an extra `role: "admin"` or `isAdmin: true` field. -> *Rejected by `hasOnly(...)`.*
2. **Class Lock Bypass**: Updating `/users/{uid}` when `classLocked == true` to change `selectedClass` from `5` to `8`. -> *Rejected by immutable lock guard.*
3. **Spoofed User Creation**: Creating `/users/other_uid` while signed in as `uid_1`. -> *Rejected by `isOwner(userId)`.*
4. **Ghost Field in Saved Notes**: Creating `/users/{uid}/savedNotes/{noteId}` with extra `verified: true`. -> *Rejected by `hasOnly(...)`.*
5. **Self-Approved Class Change Report**: Creating `/classChangeReports/{id}` with `status: "approved"`. -> *Rejected by `status == 'pending'` create check.*
6. **Student Approving Own Report**: Updating `/classChangeReports/{id}` as the student to set `status: "approved"`. -> *Rejected by `isAdmin()` update gate.*
7. **Student Self-Granting Admin in `/admins/{uid}`**: Attempting to write `/admins/{uid}` from a client session. -> *Rejected by `allow create, update, delete: if false;`.*
8. **Blanket User List Scraping**: Querying `/users` or `/quizAttempts` of other users as a non-admin student. -> *Rejected by `allow list: if isAdmin();` and `resource.data.studentId == request.auth.uid`.*
9. **Student Publishing Quizzes or Lessons**: Attempting to write `/quizzes/{id}` or `/lessons/{id}` as a student. -> *Rejected by `isAdmin()` check.*
10. **ID Poisoning**: Creating `/users/{uid}/savedNotes/../../admins/bad` or 1.5KB ID string. -> *Rejected by `isValidId()` regex and 128-char limit.*
11. **Oversized String Exhaustion**: Creating `/classChangeReports/{id}` with a 50KB `reason` string or `/quizzes/{id}` with >20 questions. -> *Rejected by `.size()` bounds.*
12. **Client Timestamp Forgery**: Creating `/announcements/{id}`, `/quizzes/{id}`, or `/subjects/{id}` with a backdated `createdAt` timestamp. -> *Rejected by `createdAt == request.time`.*
