# TMN Security Specification (Phase 0: Payload-First Security TDD)

## 1. Data Invariants
1. **Default-Deny Read-Only Site Protection**: No client can write to any collection outside their own `/users/{userId}` document and `/users/{userId}/srsCards/{cardId}` subcollection. Shared site content (vocabulary, sentences, branding) is static and immutable to users.
2. **Strict Owner PII Isolation**: `/users/{userId}` contains private PII (`email`). Only the authenticated, email-verified user whose `request.auth.uid == userId` may `get`, `create`, or `update` their own profile. `allow list` on `/users` is strictly denied (`false`).
3. **No Privilege Escalation / Shadow Fields**: Neither `UserProfile` nor `SrsCard` permits arbitrary extra fields (e.g., `role`, `isAdmin`, `isVerified`). `keys().hasAll(...) && keys().hasOnly(...)` is enforced on every write.
4. **Master Gate Relational Integrity**: Every `SrsCard` under `/users/{userId}/srsCards/{cardId}` requires the parent `/users/{userId}` document to exist and belong to `request.auth.uid` on single-document operations (`get`, `create`, `update`, `delete`). `list` queries on `srsCards` enforce `resource.data.userId == request.auth.uid` without `get()`/`exists()` calls.
5. **Immutable Identity & Server Timestamps**: `uid`, `email`, `userId`, `wordId`, and `createdAt` are immutable once created. `createdAt == request.time` on create and `updatedAt == request.time` on create/update.
6. **Bounded Resource Sizes**: Every string, ID, map, and array has strict upper bounds to prevent Denial-of-Wallet attacks.

## 2. The "Dirty Dozen" Attack Payloads (All MUST Return PERMISSION_DENIED)
1. **Unauthenticated Profile Read**: `GET /users/userA` with `auth = null`.
2. **Cross-User PII Leak**: `GET /users/userA` authenticated as `userB`.
3. **User Directory Scraping**: `LIST /users` authenticated as `userA`.
4. **Unverified Email Write**: `CREATE /users/userA` with `auth.token.email_verified = false`.
5. **Identity Spoofing on Create**: `CREATE /users/userA` as `userB` with `{ uid: "userA", ... }`.
6. **Privilege Escalation Shadow Field**: `CREATE /users/userA` as `userA` with extra field `{ isAdmin: true, role: "admin" }`.
7. **Timestamp Forgery**: `CREATE /users/userA` with client-supplied `createdAt: "2020-01-01T00:00:00Z"` instead of `request.time`.
8. **Immutable Field Tampering**: `UPDATE /users/userA` attempting to change `email` or `createdAt` or `uid`.
9. **Value Poisoning / Type Mismatch**: `UPDATE /users/userA` setting `xp: "999999"` (string) or `theme: "hacked"`.
10. **Array Exhaustion (Denial of Wallet)**: `UPDATE /users/userA` setting `mistakes` to an array of 501 items or non-integer first element.
11. **Orphaned / Cross-User SRS Card**: `CREATE /users/userA/srsCards/word_1` as `userA` when parent `/users/userA` does not exist OR with `userId: "userB"`.
12. **Site Tampering / Unauthorized Collection Write**: `CREATE /siteConfig/branding` or `CREATE /vocab/custom` by any authenticated user.
