# Security Specification: Qwen Chat Firestore Rules

## 1. Data Invariants
- Every resource is strictly scoped to the authenticated owner (`request.auth.uid == userId`).
- Anonymous or unauthenticated access is strictly forbidden for all collections.
- Email verification requirement is checked for writes (`request.auth.token.email_verified == true`).
- A user can never read, modify, list, or delete another user's profile, chat history, scripts, or SEO kits.
- Document IDs must conform to `isValidId()` regex (`^[a-zA-Z0-9_\-]+$`) with a maximum length of 128 characters.
- Required fields are strictly validated on creation, and unexpected ghost/shadow fields are rejected with `hasOnly()`.
- String lengths are strictly constrained to avoid denial-of-wallet payload attacks.

## 2. The Dirty Dozen Payloads (Designed to Fail)
1. **Unauthenticated Read of User Profile**: Reading `/users/user123` with `request.auth = null`. (Expected: PERMISSION_DENIED)
2. **Cross-User Profile Hijack**: Authenticated user `attacker_99` attempting to read `/users/victim_100`. (Expected: PERMISSION_DENIED)
3. **Shadow Update on User Profile**: Writing unauthorized administrative privilege field `{ "isAdmin": true, "role": "superuser" }`. (Expected: PERMISSION_DENIED)
4. **Path ID Injection Attack**: Target ID `../../../etc/passwd` or 5,000 character string. (Expected: PERMISSION_DENIED)
5. **Orphaned Chat Message Creation**: Writing a message with `userId: 'victim_100'` while signed in as `attacker_99`. (Expected: PERMISSION_DENIED)
6. **Cross-User Chat History Snooping**: User attempting to run `list` query on `/users/victim_100/chats`. (Expected: PERMISSION_DENIED)
7. **Unverified Email Mutation**: User attempting to create profile with `email_verified: false` or forged email claim. (Expected: PERMISSION_DENIED)
8. **Script Content Size Bomb**: Sending a 5MB text payload in `content` field exceeding `maxLength: 30000`. (Expected: PERMISSION_DENIED)
9. **Timestamp Forgery**: Attempting to set `createdAt` into the future or tampering with timestamps instead of `request.time`. (Expected: PERMISSION_DENIED)
10. **Blanket Query Scraping**: Attempting a collectionGroup query across all chats without `userId` constraint. (Expected: PERMISSION_DENIED)
11. **Chat Session ID Mismatch**: Session doc at `/users/u1/chats/c1` with payload containing `id: 'c2'`. (Expected: PERMISSION_DENIED)
12. **Malicious Script Deletion**: User `u2` attempting to delete `/users/u1/scripts/s1`. (Expected: PERMISSION_DENIED)
