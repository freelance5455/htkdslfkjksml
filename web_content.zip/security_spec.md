# Security Specification: Tiga Rekan ID Operations

## 1. Data Invariants & RBAC
1. **Bootstrapped Primary Administrator**: Only `request.auth.token.email == 'lulnazi12@gmail.com' && request.auth.token.email_verified == true` holds `isAdmin()` privileges. No client-side claim or self-assigned role can grant admin access.
2. **Closed Public Registration (Invite-Only Employee Onboarding)**: Non-admin users can only create `users/{request.auth.uid}` with `role == 'employee'` and `active == true` if they hold a matching `pending` document in `invites/{inviteId}` where `email == request.auth.token.email` and `division` matches the invite. Uninvited Google accounts are rejected at the Firestore rule layer.
3. **Immutable Role & Division for Employees**: Employees cannot escalate their `role`, mutate `active`, or change their `division` after onboarding. Only `isAdmin()` can edit employee profiles, divisions, active status, or issue/revoke invitations.
4. **Administrator Full Access & Limited Employee Access**:
   - `isAdmin()` has full read, list, create, update, and delete permissions across `users`, `invites`, `employees`, `attendanceLogs`, `complaints`, and `inventory`.
   - Approved employees (`isActiveEmployee()`) can create/read their own `attendanceLogs`, view/create/update handling notes on `complaints` shared with their email, and adjust stock if assigned to `Gudang & Packing`, while Admin retains exclusive edit/delete authority on existing attendance logs and employee directory records.
5. **Terminal State Locking**: Once a `complaints/{complaintId}` document reaches `status == 'Selesai'`, non-admin updates are locked (`existing().status != 'Selesai' || isAdmin()`).
6. **Zero-Cost List Queries & Bounded Arrays**: Every `allow list` strictly evaluates `resource.data` against `isAdmin()` or `request.auth.uid` / `request.auth.token.email` without `get()` or `exists()` lookups. Shared email arrays (`assignedEmails`, `teamEmails`) are bounded to `<= 20` entries with index-0 type/length checks.

## 2. Adversarial Payloads Covered
1. Unauthenticated read/write -> `PERMISSION_DENIED`.
2. Unverified email write -> `PERMISSION_DENIED`.
3. Self-signup by uninvited Google account without valid `invites/{inviteId}` -> `PERMISSION_DENIED`.
4. Employee attempting `role: 'admin'` self-assignment on `users/{uid}` -> `PERMISSION_DENIED`.
5. Employee attempting to change own `division` or `active` flag -> `PERMISSION_DENIED`.
6. Employee attempting to issue or revoke `invites` -> `PERMISSION_DENIED`.
7. Employee attempting to edit or delete another employee's `attendanceLogs` -> `PERMISSION_DENIED`.
8. Non-Gudang employee or uninvited user modifying `inventory` -> `PERMISSION_DENIED`.
9. Mutation of a `complaints` document after `status == 'Selesai'` by non-admin -> `PERMISSION_DENIED`.
10. Document ID poisoning (`../bad$id`) or string overflow -> `PERMISSION_DENIED`.
11. Timestamp forgery (`createdAt != request.time`) -> `PERMISSION_DENIED`.
12. Ghost/shadow fields injected into any create or update payload -> `PERMISSION_DENIED`.
