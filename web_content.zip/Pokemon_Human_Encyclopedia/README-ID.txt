POKÉMON HUMAN ENCYCLOPEDIA — OFFLINE STARTER EDITION
===================================================

What is included
- index.html: a self-contained offline character catalogue.
- 55 notable human characters from the Pokémon anime and games.
- Search by name, region, role, or description.
- Category filters: Anime, Games, Gym Leader, Elite Four, Champion,
  Professor, Rival, Villain, and Protagonist.
- Character profile pop-ups.
- No network calls; all data and UI are stored locally.

IMPORTANT
This is a starter edition, not a complete encyclopedia of every named
human character. Portrait circles are offline initials/placeholders,
not official Pokémon artwork. I have not included scraped/copyrighted
artwork or claimed that every character is covered.

HOW TO USE ON ANDROID (no computer required)
1. Extract this ZIP using your phone's file manager.
2. Open index.html in Chrome or another browser. It works offline.
3. To package as an APK, use an Android HTML-to-APK builder that supports
   loading a local index.html and bundling local assets. Choose this folder
   as the website/app source, set app name to "Pokémon Human Encyclopedia",
   and package it as an offline app.
4. If the builder offers an option such as "Internet permission", turn it
   off. The app does not need internet.

The ZIP is the source package, not an APK installer. An APK has not been
compiled in this environment.
