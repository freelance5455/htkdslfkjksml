// Unit-Test Prüfziffer (node test/evn.test.mjs)
import assert from 'node:assert/strict';
const { validateWagonNumber, onlyDigits } = await import('../www/js/wagon.js');

assert.equal(onlyDigits('33 85 7837 152-2'), '338578371522');
assert.equal(validateWagonNumber('33 85 7837 152-2'), 'ok', '33 85 7837 152-2 muss gültig sein');
const base = '338578371522';
for (let i = 0; i < 12; i++) {
  const d = [...base];
  d[i] = String((Number(d[i]) + 1) % 10);
  assert.equal(validateWagonNumber(d.join('')), 'invalid', `geänderte Ziffer an Stelle ${i + 1} muss fehlschlagen`);
}
assert.equal(validateWagonNumber('33 85 7837 152'), 'incomplete');
assert.equal(validateWagonNumber(''), 'empty');
console.log('EVN-Tests bestanden');
