import { createRequire } from 'module';
import fs from 'fs';
const require = createRequire(import.meta.url);
globalThis.PDFLib = require(process.env.PDFLIB || 'pdf-lib');
const OUT = process.env.OUT_DIR || new URL('./', import.meta.url).pathname;
const { fillProtocol } = await import('../www/js/pdf/fillProtocol.js');
const { validateWagonNumber, formatWagonNumber } = await import('../www/js/wagon.js');
const db = (await import('../www/data/schadcodes.js')).default;
const byCode = new Map(db.codes.map(c => [c.code, c]));
console.log('UIC 218124712173:', validateWagonNumber('218124712173'), formatWagonNumber('218124712173','-'));
const report = {
  reportId: 'B13H09/316', consignmentNumber: '', trainNumber: '', detectionPlace: 'Burghausen', detectionDate: '2026-09-14',
  origin: 'Burghausen', destination: 'Stendell', departureDate: '2026-09-14', loadingStatus: 'leer',
  wagonNumber: '338078194841', keeperVkm: '4093', keeperName: 'Aretz GmbH & Co. KG', keeperAddress: 'Luisenplatz 9, 47799 Krefeld, Germany, DNebendahl@aretzwaggon.de',
  damages: [
    { code: '5.2.3.1', remark: 'Pufferteller aus Metal aber nicht geschmiert (Schaden bereits behoben)', old: false },
    { code: '1.3.3.2', remark: '', old: true },
    { code: '4.10.2.2', remark: '' },
  ],
  takeover: 'siding', takeoverName: 'Burghausen Wackerwerk OMV (DB Cargo AG Burghausen)',
  contactName: 'Dispo-Tf Rail GmbH', contactEmail: 'Schadwagen@dispotf.de', attachments: true,
  existingLabels:{}, newLabels:{K:true}, wagonDetached:true, workshop:'after', cause:'third', perpetrator:'Max Muster, Musterweg 1'
};
const settings = { evuNr: '3840', evuName: 'Dispo Tf - Rail GmbH' };
const templateBytes = fs.readFileSync(new URL('../www/assets/GCU_Schadprotokoll_Grunddatei.pdf', import.meta.url));
for (const flatten of [false, true]) {
  const out = await fillProtocol(report, settings, { templateBytes, lookup: c => byCode.get(c), flatten, photos: [] });
  fs.writeFileSync(`${OUT}/out_${flatten ? 'flat' : 'form'}.pdf`, out);
  console.log('ok', flatten, out.length);
}
