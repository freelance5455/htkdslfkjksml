package main

import (
	"net/http"
	"net/http/httptest"
	"os"
	"strings"
	"testing"
)

func TestSecretRoundTrip(t *testing.T) {
	dir := t.TempDir()
	os.Setenv("LOCALAPPDATA", dir)
	set := httptest.NewRequest(http.MethodPost, "/__secret?op=set&name=apiToken", strings.NewReader("geheim-123"))
	rec := httptest.NewRecorder()
	handleSecret(rec, set)
	if rec.Code != http.StatusNoContent {
		t.Fatalf("set: %d", rec.Code)
	}
	get := httptest.NewRequest(http.MethodPost, "/__secret?op=get&name=apiToken", nil)
	rec = httptest.NewRecorder()
	handleSecret(rec, get)
	if !strings.Contains(rec.Body.String(), "geheim-123") {
		t.Fatalf("get: %s", rec.Body.String())
	}
	bad := httptest.NewRequest(http.MethodPost, "/__secret?op=get&name=../x", nil)
	rec = httptest.NewRecorder()
	handleSecret(rec, bad)
	if rec.Code != http.StatusBadRequest {
		t.Fatalf("ungültiger Name: %d", rec.Code)
	}
	// Leerer Wert löscht
	rec = httptest.NewRecorder()
	handleSecret(rec, httptest.NewRequest(http.MethodPost, "/__secret?op=set&name=apiToken", strings.NewReader("")))
	rec = httptest.NewRecorder()
	handleSecret(rec, httptest.NewRequest(http.MethodPost, "/__secret?op=get&name=apiToken", nil))
	if strings.Contains(rec.Body.String(), "geheim") {
		t.Fatal("Wert nicht gelöscht")
	}
}
