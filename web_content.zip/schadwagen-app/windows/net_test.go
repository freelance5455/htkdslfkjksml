package main

import (
	"net"
	"net/http"
	"net/http/httptest"
	"strconv"
	"strings"
	"testing"
	"time"
)

func pingServer(tls bool) *httptest.Server {
	h := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("X-Api-Key") != "geheim" {
			w.WriteHeader(401)
			_, _ = w.Write([]byte(`{"error":"invalid_token"}`))
			return
		}
		_, _ = w.Write([]byte(`{"ok":true,"service":"schadwagen-backend"}`))
	})
	if tls {
		return httptest.NewTLSServer(h)
	}
	return httptest.NewServer(h)
}

func TestProxyPinning(t *testing.T) {
	ts := pingServer(true)
	defer ts.Close()
	fp := fingerprint(ts.Certificate())
	hdr := map[string]string{"X-Api-Key": "geheim", "Cookie": "darf-nicht-mit"}

	// ohne gemerkten Fingerabdruck: selbst ausgestellt -> nicht vertrauenswürdig, Zertifikat wird mitgeliefert
	r := doProxy(proxyReq{URL: ts.URL + "/api/ping", Headers: hdr, TimeoutMs: 3000})
	if r.Error != "cert_untrusted" || r.Cert == nil || r.Cert.Fingerprint != fp {
		t.Fatalf("cert_untrusted mit Fingerabdruck erwartet: %+v", r)
	}
	// richtiger Fingerabdruck (auch mit Doppelpunkten/Großbuchstaben) -> verbunden
	pretty := strings.ToUpper(fp[:2] + ":" + fp[2:])
	r = doProxy(proxyReq{URL: ts.URL + "/api/ping", Headers: hdr, Pin: pretty, TimeoutMs: 3000})
	if r.Error != "" || r.Status != 200 || !strings.Contains(r.Body, "schadwagen-backend") {
		t.Fatalf("Verbindung mit Pin erwartet: %+v", r)
	}
	// falscher Fingerabdruck -> gesperrt
	r = doProxy(proxyReq{URL: ts.URL + "/api/ping", Headers: hdr, Pin: strings.Repeat("ab", 32), TimeoutMs: 3000})
	if r.Error != "cert_changed" || r.Cert == nil || r.Cert.Fingerprint != fp {
		t.Fatalf("cert_changed erwartet: %+v", r)
	}
	// Token falsch -> HTTP-Status wird durchgereicht
	r = doProxy(proxyReq{URL: ts.URL + "/api/ping", Pin: fp, TimeoutMs: 3000})
	if r.Status != 401 {
		t.Fatalf("401 erwartet: %+v", r)
	}
	// Zertifikat abrufen
	host, port, _ := net.SplitHostPort(strings.TrimPrefix(ts.URL, "https://"))
	p, _ := strconv.Atoi(port)
	c := probeCert(host, p)
	if c["fingerprint"] != fp || c["trusted"] != false {
		t.Fatalf("probe: %v", c)
	}
}

func TestProxyErrorsAndLimits(t *testing.T) {
	plain := pingServer(false)
	defer plain.Close()
	// http zu 127.0.0.1 (lokal) erlaubt
	if r := doProxy(proxyReq{URL: plain.URL + "/api/ping", Headers: map[string]string{"X-Api-Key": "geheim"}}); r.Status != 200 {
		t.Fatalf("http lokal: %+v", r)
	}
	// https gegen http-Server -> tls
	if r := doProxy(proxyReq{URL: strings.Replace(plain.URL, "http://", "https://", 1) + "/api/ping", TimeoutMs: 3000}); r.Error != "tls" {
		t.Fatalf("tls erwartet: %+v", r)
	}
	// http zu öffentlicher IP -> gesperrt (ohne Verbindungsversuch)
	if r := doProxy(proxyReq{URL: "http://8.8.8.8/api/ping"}); r.Error != "blocked" {
		t.Fatalf("blocked erwartet: %+v", r)
	}
	// nur /api/
	if r := doProxy(proxyReq{URL: plain.URL + "/etc/passwd"}); r.Error != "blocked" {
		t.Fatalf("Pfad blocked erwartet: %+v", r)
	}
	// Port geschlossen -> refused
	l, _ := net.Listen("tcp", "127.0.0.1:0")
	addr := l.Addr().String()
	l.Close()
	if r := doProxy(proxyReq{URL: "http://" + addr + "/api/ping", TimeoutMs: 2000}); r.Error != "refused" {
		t.Fatalf("refused erwartet: %+v", r)
	}
	// keine Antwort -> timeout
	l2, _ := net.Listen("tcp", "127.0.0.1:0")
	defer l2.Close()
	go func() {
		for {
			c, err := l2.Accept()
			if err != nil {
				return
			}
			go func() { time.Sleep(3 * time.Second); c.Close() }()
		}
	}()
	if r := doProxy(proxyReq{URL: "http://" + l2.Addr().String() + "/api/ping", TimeoutMs: 300}); r.Error != "timeout" {
		t.Fatalf("timeout erwartet: %+v", r)
	}
	for h, want := range map[string]bool{"192.168.1.2": true, "10.0.0.1": true, "172.20.0.1": true, "[fd00::5]": true, "fe80::1": true, "8.8.8.8": false, "2001:db8::1": false, "localhost": true} {
		if privateHost(h) != want {
			t.Errorf("privateHost(%s) = %v", h, !want)
		}
	}
}

func TestParseNetstatPID(t *testing.T) {
	out := "\r\nAktive Verbindungen\r\n\r\n  Proto  Lokale Adresse         Remoteadresse          Status           PID\r\n" +
		"  TCP    0.0.0.0:135            0.0.0.0:0              ABHÖREN         1100\r\n" +
		"  TCP    127.0.0.1:47831        0.0.0.0:0              ABHÖREN         7788\r\n" +
		"  TCP    127.0.0.1:47831        127.0.0.1:51234        HERGESTELLT     7788\r\n" +
		"  TCP    127.0.0.1:51234        127.0.0.1:47831        HERGESTELLT     9999\r\n"
	if pid := parseNetstatPID(out, 47831); pid != 7788 {
		t.Fatalf("PID 7788 erwartet, %d", pid)
	}
	if pid := parseNetstatPID(out, 1234); pid != 0 {
		t.Fatalf("kein Treffer erwartet, %d", pid)
	}
}
