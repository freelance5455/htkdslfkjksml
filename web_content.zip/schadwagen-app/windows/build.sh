#!/bin/sh
# Baut windows/Schadensprotokoll.exe (benötigt Go >= 1.22; läuft unter Linux, macOS oder Windows/Git-Bash)
set -e
cd "$(dirname "$0")"
rm -rf www && cp -r ../www www
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -ldflags "-H windowsgui -s -w" -o Schadensprotokoll.exe .
echo "fertig: windows/Schadensprotokoll.exe"
