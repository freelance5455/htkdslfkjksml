//go:build !windows

package main

import (
	"log"
	"os"
)

func fatal(msg string) {
	log.Print(msg)
	os.Exit(1)
}
