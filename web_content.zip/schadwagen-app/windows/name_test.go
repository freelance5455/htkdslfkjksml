package main

import "testing"

func TestCleanPDFName(t *testing.T) {
	for in, want := range map[string]string{
		"23.10.2026 Nürnberg Hafen 21 81 2471 217-3.pdf": "23.10.2026 Nürnberg Hafen 21 81 2471 217-3.pdf",
		`a/b:c*?.pdf`:   "a b c .pdf",
		"":              "Schadensprotokoll.pdf",
		"..\\..\\x.pdf": ".. .. x.pdf",
	} {
		if got := cleanPDFName(in); got != want {
			t.Errorf("%q -> %q, want %q", in, got, want)
		}
	}
}
