module schadensprotokoll

go 1.22
