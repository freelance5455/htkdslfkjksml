//go:build windows

package main

import (
	"errors"
	"fmt"
	"os/exec"
	"runtime"
	"strings"
	"syscall"
	"time"
	"unsafe"
)

// E-Mail mit PDF-Anhang über Simple MAPI (Outlook klassisch, Thunderbird u. a.).
// Mailprogramme ohne MAPI (z. B. neues Outlook, Windows Mail) liefern sofort einen Fehler –
// dann wird auf mailto ausgewichen und die PDF im Explorer markiert.

type mapiRecipDesc struct {
	reserved   uint32
	recipClass uint32
	name       *uint16
	address    *uint16
	eidSize    uint32
	entryID    uintptr
}

type mapiFileDesc struct {
	reserved uint32
	flags    uint32
	position uint32
	pathName *uint16
	fileName *uint16
	fileType uintptr
}

type mapiMessage struct {
	reserved       uint32
	subject        *uint16
	noteText       *uint16
	messageType    *uint16
	dateReceived   *uint16
	conversationID *uint16
	flags          uint32
	originator     *mapiRecipDesc
	recipCount     uint32
	recips         *mapiRecipDesc
	fileCount      uint32
	files          *mapiFileDesc
}

const (
	mapiLogonUI   = 0x1
	mapiDialog    = 0x8
	mapiTo        = 1
	mapiUserAbort = 1
)

var (
	mapi32       = syscall.NewLazyDLL("mapi32.dll")
	procSendMail = mapi32.NewProc("MAPISendMailW")
	ole32        = syscall.NewLazyDLL("ole32.dll")
	procCoInit   = ole32.NewProc("CoInitializeEx")
	procCoUninit = ole32.NewProc("CoUninitialize")
	errNoMAPI    = errors.New("kein MAPI-fähiges Mailprogramm")
)

func u16(s string) *uint16 {
	if s == "" {
		return nil
	}
	p, _ := syscall.UTF16PtrFromString(s)
	return p
}

func mapiSend(to, subject, body, path, fileName string) error {
	if err := procSendMail.Find(); err != nil {
		return errNoMAPI
	}
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()
	procCoInit.Call(0, 0x2) // COINIT_APARTMENTTHREADED
	defer procCoUninit.Call()
	file := mapiFileDesc{position: 0xFFFFFFFF, pathName: u16(path), fileName: u16(fileName)}
	msg := mapiMessage{subject: u16(subject), noteText: u16(body), fileCount: 1, files: &file}
	var recip mapiRecipDesc
	if to != "" {
		recip = mapiRecipDesc{recipClass: mapiTo, name: u16(to), address: u16("SMTP:" + to)}
		msg.recipCount, msg.recips = 1, &recip
	}
	r, _, _ := procSendMail.Call(0, 0, uintptr(unsafe.Pointer(&msg)), mapiDialog|mapiLogonUI, 0)
	runtime.KeepAlive(&file)
	runtime.KeepAlive(&recip)
	if r == 0 || r == mapiUserAbort {
		return nil
	}
	return fmt.Errorf("MAPI-Fehler %d", r)
}

// sendMailWithAttachment wartet kurz: Kommt in 4 s kein Fehler, ist das Mailfenster offen
// (manche Programme kehren erst nach dem Senden zurück).
func sendMailWithAttachment(to, subject, body, path, fileName string) error {
	res := make(chan error, 1)
	go func() { res <- mapiSend(to, subject, body, path, fileName) }()
	select {
	case err := <-res:
		return err
	case <-time.After(4 * time.Second):
		return nil
	}
}

func runHidden(name string, args ...string) error {
	cmd := exec.Command(name, args...)
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: 0x08000000}
	return cmd.Run()
}

func openURL(u string) {
	_ = exec.Command("rundll32.exe", "url.dll,FileProtocolHandler", u).Start()
}

// WhatsApp Desktop registriert das Protokoll whatsapp:
func whatsAppInstalled() bool {
	for _, k := range []string{`HKCU\Software\Classes\whatsapp`, `HKCR\whatsapp`} {
		if runHidden("reg", "query", k) == nil {
			return true
		}
	}
	return strings.Contains(strings.ToLower(lookPathSafe("WhatsApp.exe")), "whatsapp")
}

func lookPathSafe(n string) string {
	p, err := exec.LookPath(n)
	if err != nil {
		return ""
	}
	return p
}
