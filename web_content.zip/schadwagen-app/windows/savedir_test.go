package main

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestSaveDir(t *testing.T) {
	tmp := t.TempDir()
	t.Setenv("LOCALAPPDATA", filepath.Join(tmp, "lad"))
	t.Setenv("HOME", filepath.Join(tmp, "home"))
	t.Setenv("OneDrive", "")
	os.MkdirAll(filepath.Join(tmp, "home", "Documents"), 0o755)
	if saveDir() != defaultSaveDir() {
		t.Fatal("Standard erwartet")
	}
	if _, err := setSaveDir("relativ/pfad"); err == nil {
		t.Fatal("relativer Pfad muss abgelehnt werden")
	}
	want := filepath.Join(tmp, "Ablage", "PDF")
	p, err := setSaveDir(`"` + want + `"`) // mit Anführungszeichen eingefügt
	if err != nil || p != want || saveDir() != want {
		t.Fatalf("setzen: %v %s", err, p)
	}
	path, err := savePDF([]byte("%PDF-1.7 test"), "a.pdf")
	if err != nil || !strings.HasPrefix(path, want) || !underAllowed(path) {
		t.Fatalf("speichern: %v %s", err, path)
	}
	// Ordner nicht mehr erreichbar (Pfad ist jetzt eine Datei) -> Ersatz im Standardordner
	os.RemoveAll(want)
	os.WriteFile(want, []byte("x"), 0o644)
	dir, fb, wanted := targetDir()
	if !fb || dir != defaultSaveDir() || wanted != want {
		t.Fatalf("Ersatzordner erwartet: %s %v", dir, fb)
	}
	// zurück zum Standard
	if p, _ := setSaveDir(""); p != defaultSaveDir() || configuredSaveDir() != "" {
		t.Fatal("Standard nicht wiederhergestellt")
	}
	if underAllowed(filepath.Join(tmp, "woanders", "x.pdf")) {
		t.Fatal("fremder Ordner darf nicht erlaubt sein")
	}
}
