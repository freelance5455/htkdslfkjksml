//go:build !windows

package main

import (
	"errors"
	"os/exec"
)

// Nur für Test-Builds außerhalb von Windows.
var errNoMAPI = errors.New("kein MAPI-fähiges Mailprogramm")

func sendMailWithAttachment(to, subject, body, path, fileName string) error { return errNoMAPI }
func whatsAppInstalled() bool                                               { return false }
func openURL(u string)                                                      { _ = exec.Command("xdg-open", u).Start() }
