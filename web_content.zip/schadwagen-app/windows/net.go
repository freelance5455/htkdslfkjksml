package main

// Netzwerkzugriff für die App (IP-Verbindungen, eigene Zertifikate):
//
//	POST /__proxy      { url, method, headers, body, pin, timeoutMs, allowHttp }
//	                   -> { status, body } oder { error, detail, cert }
//	POST /__certprobe  { host, port } -> { fingerprint, subject, issuer, notBefore, notAfter, selfSigned, trusted, sans }
//
// Der Browser im App-Fenster kann selbst ausgestellte Zertifikate weder prüfen noch annehmen.
// Hier wird das Zertifikat über seinen SHA-256-Fingerabdruck festgehalten (Pinning): stimmt er,
// wird verbunden; weicht er ab, wird die Verbindung gesperrt (cert_changed).
// Schutz: nur mit dem Sitzungs-Token des Fensters (X-Token), nur Pfade unter /api/,
// unverschlüsselt (http) nur zu privaten bzw. lokalen Adressen, keine Weiterleitungen.
// Anfragen und Kopfzeilen (API-Token, Sitzung) werden nie protokolliert.

import (
	"context"
	"crypto/sha256"
	"crypto/tls"
	"crypto/x509"
	"encoding/hex"
	"encoding/json"
	"errors"
	"io"
	"net"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"syscall"
	"time"
)

const maxProxyBody = 64 << 20

type proxyReq struct {
	URL       string            `json:"url"`
	Method    string            `json:"method"`
	Headers   map[string]string `json:"headers"`
	Body      *string           `json:"body"`
	Pin       string            `json:"pin"`
	TimeoutMs int               `json:"timeoutMs"`
}

type certInfo struct {
	Fingerprint string   `json:"fingerprint"`
	Subject     string   `json:"subject"`
	Issuer      string   `json:"issuer"`
	NotBefore   string   `json:"notBefore"`
	NotAfter    string   `json:"notAfter"`
	SelfSigned  bool     `json:"selfSigned"`
	Trusted     bool     `json:"trusted"`
	SANs        []string `json:"sans"`
}

type proxyResp struct {
	Status int       `json:"status,omitempty"`
	Body   string    `json:"body,omitempty"`
	Error  string    `json:"error,omitempty"`
	Detail string    `json:"detail,omitempty"`
	Cert   *certInfo `json:"cert,omitempty"`
}

var allowedHeaders = map[string]bool{"content-type": true, "x-api-key": true, "authorization": true, "accept": true}

func normFP(s string) string {
	var b strings.Builder
	for _, r := range strings.ToLower(s) {
		if (r >= '0' && r <= '9') || (r >= 'a' && r <= 'f') {
			b.WriteRune(r)
		}
	}
	return b.String()
}

func fingerprint(c *x509.Certificate) string {
	sum := sha256.Sum256(c.Raw)
	return hex.EncodeToString(sum[:])
}

func describe(c *x509.Certificate, host string) *certInfo {
	ci := &certInfo{
		Fingerprint: fingerprint(c),
		Subject:     c.Subject.String(),
		Issuer:      c.Issuer.String(),
		NotBefore:   c.NotBefore.UTC().Format(time.RFC3339),
		NotAfter:    c.NotAfter.UTC().Format(time.RFC3339),
		SelfSigned:  string(c.RawIssuer) == string(c.RawSubject),
	}
	ci.SANs = append(ci.SANs, c.DNSNames...)
	for _, ip := range c.IPAddresses {
		ci.SANs = append(ci.SANs, ip.String())
	}
	if host != "" {
		_, err := c.Verify(x509.VerifyOptions{DNSName: host})
		ci.Trusted = err == nil
	}
	return ci
}

// privateHost: localhost, Loopback, private (RFC 1918 / ULA) oder link-local.
func privateHost(h string) bool {
	h = strings.Trim(h, "[]")
	if strings.EqualFold(h, "localhost") {
		return true
	}
	ip := net.ParseIP(h)
	return ip != nil && (ip.IsLoopback() || ip.IsPrivate() || ip.IsLinkLocalUnicast())
}

type pinError struct{ cert *x509.Certificate }

func (e *pinError) Error() string { return "Fingerabdruck stimmt nicht überein" }

// classify übersetzt Netzwerkfehler in feste Codes für die Oberfläche.
func classify(err error, host string) proxyResp {
	var pe *pinError
	if errors.As(err, &pe) {
		return proxyResp{Error: "cert_changed", Detail: err.Error(), Cert: describe(pe.cert, "")}
	}
	var cve *tls.CertificateVerificationError
	if errors.As(err, &cve) {
		r := proxyResp{Error: "cert_untrusted", Detail: cve.Err.Error()}
		if len(cve.UnverifiedCertificates) > 0 {
			r.Cert = describe(cve.UnverifiedCertificates[0], "")
		}
		return r
	}
	var ua x509.UnknownAuthorityError
	var hn x509.HostnameError
	var ci x509.CertificateInvalidError
	if errors.As(err, &ua) || errors.As(err, &hn) || errors.As(err, &ci) {
		return proxyResp{Error: "cert_untrusted", Detail: err.Error()}
	}
	var rh tls.RecordHeaderError
	if errors.As(err, &rh) {
		return proxyResp{Error: "tls", Detail: "der Server antwortet unverschlüsselt (http statt https?)"}
	}
	var dns *net.DNSError
	if errors.As(err, &dns) {
		return proxyResp{Error: "dns", Detail: dns.Err}
	}
	var ne net.Error
	if errors.As(err, &ne) && ne.Timeout() || errors.Is(err, context.DeadlineExceeded) {
		return proxyResp{Error: "timeout"}
	}
	msg := strings.ToLower(err.Error())
	switch {
	case errors.Is(err, syscall.ECONNREFUSED) || strings.Contains(msg, "refused"):
		return proxyResp{Error: "refused"}
	case errors.Is(err, syscall.EHOSTUNREACH) || errors.Is(err, syscall.ENETUNREACH) || strings.Contains(msg, "unreachable"):
		return proxyResp{Error: "unreachable"}
	case strings.Contains(msg, "http response to https client"):
		return proxyResp{Error: "tls", Detail: "der Server antwortet unverschlüsselt (http statt https?)"}
	case strings.Contains(msg, "tls:") || strings.Contains(msg, "handshake"):
		return proxyResp{Error: "tls", Detail: err.Error()}
	}
	return proxyResp{Error: "network", Detail: err.Error()}
}

func tlsConfig(host, pin string) *tls.Config {
	cfg := &tls.Config{MinVersion: tls.VersionTLS12, ServerName: strings.Trim(host, "[]")}
	if pin = normFP(pin); pin != "" {
		// Eigenes Zertifikat: Kette nicht prüfen, sondern genau dieses Zertifikat verlangen.
		cfg.InsecureSkipVerify = true
		cfg.VerifyConnection = func(cs tls.ConnectionState) error {
			if len(cs.PeerCertificates) == 0 {
				return errors.New("kein Zertifikat")
			}
			if fingerprint(cs.PeerCertificates[0]) != pin {
				return &pinError{cs.PeerCertificates[0]}
			}
			return nil
		}
	}
	return cfg
}

func doProxy(req proxyReq) proxyResp {
	u, err := url.Parse(req.URL)
	if err != nil || (u.Scheme != "http" && u.Scheme != "https") || u.Host == "" || u.User != nil {
		return proxyResp{Error: "blocked", Detail: "Adresse ungültig."}
	}
	if !strings.HasPrefix(u.EscapedPath(), "/api/") {
		return proxyResp{Error: "blocked", Detail: "Nur TrainTrace-Schnittstellen (/api/…) sind erlaubt."}
	}
	host := u.Hostname()
	if u.Scheme == "http" && !privateHost(host) {
		return proxyResp{Error: "blocked", Detail: "Unverschlüsselt (http) nur im lokalen Netz erlaubt."}
	}
	method := strings.ToUpper(req.Method)
	if method == "" {
		method = http.MethodGet
	}
	switch method {
	case http.MethodGet, http.MethodPost, http.MethodPut, http.MethodDelete:
	default:
		return proxyResp{Error: "blocked", Detail: "Methode nicht erlaubt."}
	}
	timeout := time.Duration(req.TimeoutMs) * time.Millisecond
	if timeout <= 0 || timeout > 2*time.Minute {
		timeout = 10 * time.Second
	}
	tr := &http.Transport{
		Proxy:                 nil, // Server im eigenen Netz: nie über einen System-Proxy
		DialContext:           (&net.Dialer{Timeout: timeout}).DialContext,
		TLSClientConfig:       tlsConfig(host, req.Pin),
		TLSHandshakeTimeout:   timeout,
		ResponseHeaderTimeout: timeout,
		DisableKeepAlives:     true,
	}
	defer tr.CloseIdleConnections()
	client := &http.Client{Transport: tr, Timeout: timeout + 50*time.Second, CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }}
	var body io.Reader
	if req.Body != nil {
		body = strings.NewReader(*req.Body)
	}
	hr, err := http.NewRequest(method, u.String(), body)
	if err != nil {
		return proxyResp{Error: "blocked", Detail: "Anfrage ungültig."}
	}
	for k, v := range req.Headers {
		if allowedHeaders[strings.ToLower(k)] {
			hr.Header.Set(k, v)
		}
	}
	res, err := client.Do(hr)
	if err != nil {
		return classify(err, host)
	}
	defer res.Body.Close()
	data, err := io.ReadAll(io.LimitReader(res.Body, maxProxyBody))
	if err != nil {
		return classify(err, host)
	}
	return proxyResp{Status: res.StatusCode, Body: string(data)}
}

func probeCert(host string, port int) (resp map[string]any) {
	if port < 1 || port > 65535 || strings.TrimSpace(host) == "" {
		return map[string]any{"error": "blocked", "detail": "Adresse ungültig."}
	}
	h := strings.Trim(host, "[]")
	d := &net.Dialer{Timeout: 8 * time.Second}
	conn, err := tls.DialWithDialer(d, "tcp", net.JoinHostPort(h, strconv.Itoa(port)), &tls.Config{InsecureSkipVerify: true, ServerName: h, MinVersion: tls.VersionTLS12})
	if err != nil {
		r := classify(err, h)
		return map[string]any{"error": r.Error, "detail": r.Detail}
	}
	defer conn.Close()
	certs := conn.ConnectionState().PeerCertificates
	if len(certs) == 0 {
		return map[string]any{"error": "tls", "detail": "Der Server liefert kein Zertifikat."}
	}
	ci := describe(certs[0], h)
	if !ci.Trusted && len(certs) > 1 { // Zwischenzertifikate mitprüfen
		pool := x509.NewCertPool()
		for _, c := range certs[1:] {
			pool.AddCert(c)
		}
		_, err := certs[0].Verify(x509.VerifyOptions{DNSName: h, Intermediates: pool})
		ci.Trusted = err == nil
	}
	b, _ := json.Marshal(ci)
	_ = json.Unmarshal(b, &resp)
	return resp
}

func handleProxy(w http.ResponseWriter, r *http.Request) {
	var req proxyReq
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, maxProxyBody)).Decode(&req); err != nil {
		http.Error(w, "bad request", http.StatusBadRequest)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	_ = json.NewEncoder(w).Encode(doProxy(req))
}

func handleCertProbe(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Host string `json:"host"`
		Port int    `json:"port"`
	}
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 4096)).Decode(&req); err != nil {
		http.Error(w, "bad request", http.StatusBadRequest)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	_ = json.NewEncoder(w).Encode(probeCert(req.Host, req.Port))
}

// parseNetstatPID: PID des Prozesses, der laut „netstat -ano“ auf :port lauscht (sprachunabhängig:
// Zustand „LISTENING“/„ABHÖREN“ wird nicht ausgewertet, sondern die Gegenstelle 0.0.0.0:0).
func parseNetstatPID(out string, port int) int {
	want := ":" + strconv.Itoa(port)
	for _, line := range strings.Split(out, "\n") {
		f := strings.Fields(line)
		if len(f) < 5 || !strings.EqualFold(f[0], "TCP") {
			continue
		}
		if strings.HasSuffix(f[1], want) && (f[2] == "0.0.0.0:0" || f[2] == "[::]:0") {
			if pid, err := strconv.Atoi(f[len(f)-1]); err == nil {
				return pid
			}
		}
	}
	return 0
}
