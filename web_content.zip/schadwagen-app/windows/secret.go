package main

import (
	"encoding/json"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"sync"
)

var (
	secretMu   sync.Mutex
	secretName = regexp.MustCompile(`^[a-zA-Z][a-zA-Z0-9]{0,31}$`)
)

func secretsPath() string { return filepath.Join(dataDir(), "geheim.bin") }

func loadSecrets() map[string]string {
	m := map[string]string{}
	enc, err := os.ReadFile(secretsPath())
	if err != nil {
		return m
	}
	plain, err := unprotectSecret(enc)
	if err != nil {
		return m
	}
	_ = json.Unmarshal(plain, &m)
	return m
}

func storeSecrets(m map[string]string) error {
	plain, err := json.Marshal(m)
	if err != nil {
		return err
	}
	enc, err := protectSecret(plain)
	if err != nil {
		return err
	}
	tmp := secretsPath() + ".tmp"
	if err := os.WriteFile(tmp, enc, 0o600); err != nil {
		return err
	}
	return os.Rename(tmp, secretsPath())
}

// POST /__secret?op=get|set&name=apiToken  (set: Body = Wert, leer = löschen)
// Werte werden nie protokolliert.
func handleSecret(w http.ResponseWriter, r *http.Request) {
	name := r.URL.Query().Get("name")
	if !secretName.MatchString(name) {
		http.Error(w, "name", http.StatusBadRequest)
		return
	}
	secretMu.Lock()
	defer secretMu.Unlock()
	m := loadSecrets()
	switch r.URL.Query().Get("op") {
	case "get":
		w.Header().Set("Content-Type", "application/json")
		w.Header().Set("Cache-Control", "no-store")
		_ = json.NewEncoder(w).Encode(map[string]string{"value": m[name]})
	case "set":
		v, err := io.ReadAll(io.LimitReader(r.Body, 16<<10))
		if err != nil {
			http.Error(w, "body", http.StatusBadRequest)
			return
		}
		if len(v) == 0 {
			delete(m, name)
		} else {
			m[name] = string(v)
		}
		if err := storeSecrets(m); err != nil {
			http.Error(w, "speichern fehlgeschlagen", http.StatusInternalServerError)
			return
		}
		w.WriteHeader(http.StatusNoContent)
	default:
		http.Error(w, "op", http.StatusBadRequest)
	}
}
