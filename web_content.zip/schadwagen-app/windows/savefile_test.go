package main

import (
	"os"
	"path/filepath"
	"testing"
)

func TestCleanExportName(t *testing.T) {
	zip := []byte("PK\x03\x04rest")
	js := []byte("  {\"a\":1}")
	cases := []struct {
		name string
		data []byte
		want string
		ok   bool
	}{
		{"TrainTrace-Vorlagen 25.10.2026.zip", zip, "TrainTrace-Vorlagen 25.10.2026.zip", true},
		{"vorlagen.json", js, "vorlagen.json", true},
		{"falsch.pdf", zip, "falsch.zip", true},
		{"a/b:c.zip", zip, "a b c.zip", true},
		{"x.exe", []byte("MZ\x90\x00"), "", false},
		{"", zip, "Export.zip", true},
	}
	for _, c := range cases {
		got, ok := cleanExportName(c.name, c.data)
		if ok != c.ok || got != c.want {
			t.Errorf("cleanExportName(%q) = %q,%v; want %q,%v", c.name, got, ok, c.want, c.ok)
		}
	}
}

func TestSaveFileInNoOverwrite(t *testing.T) {
	dir := t.TempDir()
	p1, err := saveFileIn(dir, []byte("PK\x03\x04a"), "Vorlagen.zip")
	if err != nil {
		t.Fatal(err)
	}
	p2, _ := saveFileIn(dir, []byte("PK\x03\x04b"), "Vorlagen.zip")
	if filepath.Base(p1) != "Vorlagen.zip" || filepath.Base(p2) != "Vorlagen_2.zip" {
		t.Fatalf("Namen: %s %s", p1, p2)
	}
	b, _ := os.ReadFile(p1)
	if string(b) != "PK\x03\x04a" {
		t.Fatal("überschrieben")
	}
}
