package main

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"strings"
	"testing"
)

func TestShareFallbacks(t *testing.T) {
	home := t.TempDir()
	t.Setenv("HOME", home)
	t.Setenv("OneDrive", "")
	_ = os.MkdirAll(home+"/Documents", 0o755)
	for via, want := range map[string]string{"mail": "mailto", "whatsapp": "web"} {
		req := httptest.NewRequest(http.MethodPost, "/__share?via="+via+"&name=24.10.2026%20Fulda%2033%2085%207837%20152-2.pdf&to=a%40b.de&subject=Test", strings.NewReader("%PDF-1.7 test"))
		rec := httptest.NewRecorder()
		handleShare(rec, req)
		var res map[string]string
		_ = json.Unmarshal(rec.Body.Bytes(), &res)
		if rec.Code != 200 || res["result"] != want || !strings.HasSuffix(res["path"], ".pdf") {
			t.Fatalf("%s: %d %v", via, rec.Code, res)
		}
	}
	rec := httptest.NewRecorder()
	handleShare(rec, httptest.NewRequest(http.MethodPost, "/__share?via=mail", strings.NewReader("keine pdf")))
	if rec.Code != 400 {
		t.Fatalf("keine PDF: %d", rec.Code)
	}
	if qesc("Schadensprotokoll B13H09/316") != "Schadensprotokoll%20B13H09%2F316" {
		t.Fatal(qesc("Schadensprotokoll B13H09/316"))
	}
}
