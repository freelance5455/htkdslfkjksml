//go:build windows

package main

import (
	"errors"
	"os/exec"
	"runtime"
	"syscall"
	"unsafe"
)

// Windows-Ordnerauswahl (SHBrowseForFolderW, neuer Dialogstil mit „Neuer Ordner“ und Eingabefeld).
var (
	shell32         = syscall.NewLazyDLL("shell32.dll")
	procBrowse      = shell32.NewProc("SHBrowseForFolderW")
	procPathFromIDL = shell32.NewProc("SHGetPathFromIDListW")
	procTaskMemFree = ole32.NewProc("CoTaskMemFree")
	user32dll       = syscall.NewLazyDLL("user32.dll")
	procForeground  = user32dll.NewProc("GetForegroundWindow")
	procSendMessage = user32dll.NewProc("SendMessageW")
	browseCallback  = syscall.NewCallback(func(hwnd, msg, lp, data uintptr) uintptr {
		if msg == 1 && data != 0 { // BFFM_INITIALIZED -> Startordner markieren
			procSendMessage.Call(hwnd, 0x400+103, 1, data) // BFFM_SETSELECTIONW
		}
		return 0
	})
)

type browseInfo struct {
	Owner       uintptr
	Root        uintptr
	DisplayName *uint16
	Title       *uint16
	Flags       uint32
	Callback    uintptr
	LParam      uintptr
	Image       int32
}

// pickFolder zeigt die Ordnerauswahl; "" bei Abbruch.
func pickFolder(title, start string) (string, error) {
	type res struct {
		p   string
		err error
	}
	ch := make(chan res, 1)
	go func() {
		runtime.LockOSThread()
		defer runtime.UnlockOSThread()
		procCoInit.Call(0, 0x2) // COINIT_APARTMENTTHREADED
		defer procCoUninit.Call()
		owner, _, _ := procForeground.Call()
		name := make([]uint16, 520)
		startW := u16(start)
		bi := browseInfo{
			Owner: owner, DisplayName: &name[0], Title: u16(title),
			Flags:    0x0001 | 0x0010 | 0x0040, // BIF_RETURNONLYFSDIRS | BIF_EDITBOX | BIF_NEWDIALOGSTYLE
			Callback: browseCallback, LParam: uintptr(unsafe.Pointer(startW)),
		}
		pidl, _, _ := procBrowse.Call(uintptr(unsafe.Pointer(&bi)))
		runtime.KeepAlive(startW)
		if pidl == 0 {
			ch <- res{}
			return
		}
		defer procTaskMemFree.Call(pidl)
		buf := make([]uint16, 32768)
		ok, _, _ := procPathFromIDL.Call(pidl, uintptr(unsafe.Pointer(&buf[0])))
		if ok == 0 {
			ch <- res{err: errors.New("Dieser Ort ist kein Ordner im Dateisystem (z. B. „Dieser PC“) – bitte einen Ordner wählen.")}
			return
		}
		ch <- res{p: syscall.UTF16ToString(buf)}
	}()
	r := <-ch
	return r.p, r.err
}

func openFolder(dir string) { _ = exec.Command("explorer.exe", dir).Start() }
