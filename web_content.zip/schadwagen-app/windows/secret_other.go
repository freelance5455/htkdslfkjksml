//go:build !windows

package main

// Nur für Test-Builds außerhalb von Windows: keine Betriebssystem-Verschlüsselung verfügbar,
// die Datei wird lediglich mit Rechten 0600 abgelegt.
func protectSecret(plain []byte) ([]byte, error) { return append([]byte(nil), plain...), nil }
func unprotectSecret(enc []byte) ([]byte, error) { return append([]byte(nil), enc...), nil }
