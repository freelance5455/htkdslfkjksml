package main

// Speicherort für PDFs (Einstellungen → „Speicherort für PDFs“).
// Standard: Dokumente\Schadensprotokolle. Ein gewählter Ordner wird in speicherort.json im
// Programmprofil gemerkt. Ist er beim Speichern nicht erreichbar (z. B. USB-Stick abgezogen,
// Netzlaufwerk getrennt), wird ersatzweise im Standardordner gespeichert und darauf hingewiesen.

import (
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync"
)

var saveDirMu sync.Mutex

func defaultSaveDir() string { return filepath.Join(documentsDir(), "Schadensprotokolle") }
func saveDirFile() string    { return filepath.Join(dataDir(), "speicherort.json") }

// configuredSaveDir: gewählter Ordner oder "" (= Standard).
func configuredSaveDir() string {
	saveDirMu.Lock()
	defer saveDirMu.Unlock()
	data, err := os.ReadFile(saveDirFile())
	if err != nil {
		return ""
	}
	var c struct{ Path string }
	if json.Unmarshal(data, &c) != nil || !filepath.IsAbs(c.Path) {
		return ""
	}
	return filepath.Clean(c.Path)
}

func saveDir() string {
	if p := configuredSaveDir(); p != "" {
		return p
	}
	return defaultSaveDir()
}

// checkDir legt den Ordner bei Bedarf an und prüft, ob hineingeschrieben werden kann.
func checkDir(p string) error {
	if !filepath.IsAbs(p) {
		return errors.New("Bitte einen vollständigen Pfad angeben, z. B. D:\\Schadensprotokolle")
	}
	if err := os.MkdirAll(p, 0o755); err != nil {
		return fmt.Errorf("Ordner kann nicht angelegt werden: %v", err)
	}
	f, err := os.CreateTemp(p, ".schreibtest-*")
	if err != nil {
		return fmt.Errorf("In diesen Ordner kann nicht geschrieben werden: %v", err)
	}
	name := f.Name()
	f.Close()
	_ = os.Remove(name)
	return nil
}

// setSaveDir: "" = zurück zum Standard.
func setSaveDir(p string) (string, error) {
	p = strings.TrimSpace(strings.Trim(strings.TrimSpace(p), `"`))
	saveDirMu.Lock()
	defer saveDirMu.Unlock()
	if p == "" || strings.EqualFold(filepath.Clean(p), filepath.Clean(defaultSaveDir())) {
		_ = os.Remove(saveDirFile())
		return defaultSaveDir(), nil
	}
	p = filepath.Clean(p)
	if err := checkDir(p); err != nil {
		return "", err
	}
	data, _ := json.Marshal(map[string]string{"path": p})
	if err := os.WriteFile(saveDirFile(), data, 0o644); err != nil {
		return "", err
	}
	return p, nil
}

// targetDir: Ordner für die nächste Datei; fallback = gewählter Ordner nicht erreichbar.
func targetDir() (dir string, fallback bool, wanted string) {
	if p := configuredSaveDir(); p != "" {
		if checkDir(p) == nil {
			return p, false, p
		}
		log.Printf("Speicherort nicht erreichbar: %s – nutze Standardordner", p)
		return defaultSaveDir(), true, p
	}
	return defaultSaveDir(), false, ""
}

// underAllowed: Datei liegt im gewählten Ordner oder im Standardordner (für „im Explorer zeigen“).
func underAllowed(p string) bool {
	lp := strings.ToLower(filepath.Clean(p))
	for _, root := range []string{saveDir(), defaultSaveDir()} {
		r := strings.ToLower(filepath.Clean(root))
		if lp == r || strings.HasPrefix(lp, r+string(os.PathSeparator)) {
			return true
		}
	}
	return false
}

// POST /__savedir?action=get|set|default&path=…   POST /__pickdir   POST /__opendir
func handleSaveDir(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query()
	resp := map[string]any{}
	switch q.Get("action") {
	case "set":
		p, err := setSaveDir(q.Get("path"))
		if err != nil {
			resp["error"] = err.Error()
		} else {
			log.Printf("Speicherort: %s", p)
		}
	case "default":
		_, _ = setSaveDir("")
	}
	resp["path"] = saveDir()
	resp["default"] = defaultSaveDir()
	resp["isDefault"] = configuredSaveDir() == ""
	if p := configuredSaveDir(); p != "" && checkDir(p) != nil {
		resp["unavailable"] = true
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(resp)
}

func handlePickDir(w http.ResponseWriter, r *http.Request) {
	p, err := pickFolder("Ordner für die Schadensprotokolle (PDF) wählen", saveDir())
	resp := map[string]any{}
	switch {
	case err != nil:
		resp["error"] = err.Error()
	case p == "":
		resp["cancelled"] = true
	default:
		resp["path"] = p
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(resp)
}

func handleOpenDir(w http.ResponseWriter, r *http.Request) {
	d := saveDir()
	if err := os.MkdirAll(d, 0o755); err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	openFolder(d)
	w.WriteHeader(http.StatusNoContent)
}
