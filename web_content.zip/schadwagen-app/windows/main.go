// Schadensprotokoll für Windows: startet die eingebettete Web-App über einen lokalen
// Server (nur 127.0.0.1) und öffnet sie als eigenes App-Fenster in Microsoft Edge.
package main

import (
	"crypto/rand"
	"embed"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"io/fs"
	"log"
	"net"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strings"
	"sync"
	"time"
)

//go:embed all:www
var webFiles embed.FS

const (
	port = 47831 // fester Port -> gleicher Ursprung, gespeicherte Protokolle bleiben erhalten
	// Wartezeit nach dem Schließen des letzten Fensters (deckt ein Neuladen der Seite ab)
	closeGrace = 2500 * time.Millisecond
	// Beenden, falls sich nach dem Start nie ein Fenster verbindet
	startTimeout = 90 * time.Second
)

var (
	addr     = fmt.Sprintf("127.0.0.1:%d", port)
	appURL   = "http://" + addr + "/index.html"
	token    = newToken()
	safeName = regexp.MustCompile(`[\\/:*?"<>|\x00-\x1f]+`)

	stateMu     sync.Mutex
	conns       int       // offene Fenster-Verbindungen (/__events)
	everConn    bool      // mindestens ein Fenster war verbunden
	closedAt    time.Time // Zeitpunkt, an dem die letzte Verbindung endete
	browserCmd  *exec.Cmd // von uns gestarteter Edge/Chrome-Prozess
	browserDone bool      // dieser Prozess ist bereits beendet
	srv         *http.Server
	shutdownOne sync.Once
	done        = make(chan struct{})
)

func newToken() string {
	b := make([]byte, 16)
	_, _ = rand.Read(b)
	return hex.EncodeToString(b)
}

func dataDir() string {
	base := os.Getenv("LOCALAPPDATA")
	if base == "" {
		base, _ = os.UserConfigDir()
	}
	d := filepath.Join(base, "Schadensprotokoll")
	_ = os.MkdirAll(d, 0o755)
	return d
}

func documentsDir() string {
	home, _ := os.UserHomeDir()
	for _, c := range []string{
		filepath.Join(os.Getenv("OneDrive"), "Dokumente"),
		filepath.Join(os.Getenv("OneDrive"), "Documents"),
		filepath.Join(home, "Documents"),
	} {
		if filepath.IsAbs(c) {
			if st, err := os.Stat(c); err == nil && st.IsDir() {
				return c
			}
		}
	}
	return home
}

func main() {
	logFile, err := os.OpenFile(filepath.Join(dataDir(), "log.txt"), os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o644)
	if err == nil {
		log.SetOutput(logFile)
		defer logFile.Close()
	}

	ln, err := net.Listen("tcp", addr)
	if err != nil {
		// Läuft bereits -> nur ein weiteres Fenster öffnen
		log.Printf("Port belegt, öffne nur Fenster: %v", err)
		if !openWindow(false) {
			fatal("Schadensprotokoll läuft bereits, das Fenster konnte aber nicht geöffnet werden.\n\n" + appURL)
		}
		return
	}

	sub, _ := fs.Sub(webFiles, "www")
	mux := http.NewServeMux()
	files := http.FileServer(http.FS(sub))
	mux.HandleFunc("/__desktop.json", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.Header().Set("Cache-Control", "no-store")
		_ = json.NewEncoder(w).Encode(map[string]string{"token": token, "documents": filepath.Join(documentsDir(), "Schadensprotokolle")})
	})
	mux.HandleFunc("/__ping", func(w http.ResponseWriter, r *http.Request) { w.WriteHeader(http.StatusNoContent) })
	mux.HandleFunc("/__events", handleEvents)
	mux.HandleFunc("/__settings", handleSettings)
	mux.HandleFunc("/__save", protected(handleSave))
	mux.HandleFunc("/__reveal", protected(handleReveal))
	mux.HandleFunc("/__mail", protected(handleMail))
	mux.HandleFunc("/__secret", protected(handleSecret))
	mux.HandleFunc("/__share", protected(handleShare))
	mux.Handle("/", http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/sw.js" {
			http.NotFound(w, r) // kein Service Worker im Desktop-Betrieb
			return
		}
		w.Header().Set("Cache-Control", "no-cache")
		files.ServeHTTP(w, r)
	}))

	srv = &http.Server{Handler: hostGuard(mux), ReadHeaderTimeout: 10 * time.Second}
	go func() {
		if err := srv.Serve(ln); err != nil && !errors.Is(err, http.ErrServerClosed) {
			log.Printf("Server: %v", err)
		}
	}()

	go openWindow(true)
	go watchdog()
	<-done
}

// Lebenszeichen über eine dauerhaft offene Verbindung (Server-Sent Events): Wird das Fenster
// geschlossen, bricht die Verbindung sofort ab – unabhängig von Zeitgebern im Browser.
func handleEvents(w http.ResponseWriter, r *http.Request) {
	fl, ok := w.(http.Flusher)
	if !ok {
		http.Error(w, "streaming nicht möglich", 500)
		return
	}
	w.Header().Set("Content-Type", "text/event-stream")
	w.Header().Set("Cache-Control", "no-store")
	stateMu.Lock()
	conns++
	everConn = true
	stateMu.Unlock()
	defer func() {
		stateMu.Lock()
		conns--
		if conns == 0 {
			closedAt = time.Now()
		}
		stateMu.Unlock()
	}()
	fmt.Fprint(w, "retry: 1000\n: verbunden\n\n")
	fl.Flush()
	t := time.NewTicker(15 * time.Second)
	defer t.Stop()
	for {
		select {
		case <-r.Context().Done():
			return
		case <-done:
			return
		case <-t.C:
			if _, err := fmt.Fprint(w, ": ping\n\n"); err != nil {
				return
			}
			fl.Flush()
		}
	}
}

// Prüft laufend, ob noch ein Fenster offen ist, und beendet sonst alles.
func watchdog() {
	started := time.Now()
	for {
		time.Sleep(500 * time.Millisecond)
		stateMu.Lock()
		n, ever, since := conns, everConn, time.Since(closedAt)
		stateMu.Unlock()
		switch {
		case ever && n == 0 && since > closeGrace:
			log.Printf("Fenster geschlossen – beende.")
			shutdown()
			return
		case !ever && time.Since(started) > startTimeout:
			log.Printf("Kein Fenster verbunden – beende.")
			shutdown()
			return
		}
	}
}

// Beendet Server und den von uns gestarteten Browser samt Unterprozessen.
// Der Browser bekommt zuerst Zeit, sich selbst zu beenden und seine Daten (gespeicherte
// Protokolle) auf die Festplatte zu schreiben; erst danach wird er hart beendet.
func shutdown() {
	shutdownOne.Do(func() {
		for i := 0; i < 40; i++ { // bis zu 10 Sekunden
			stateMu.Lock()
			cmd, exited := browserCmd, browserDone
			stateMu.Unlock()
			if cmd == nil || exited {
				break
			}
			time.Sleep(250 * time.Millisecond)
		}
		stateMu.Lock()
		cmd, exited := browserCmd, browserDone
		stateMu.Unlock()
		if cmd != nil && cmd.Process != nil && !exited {
			log.Printf("Browser beendet sich nicht selbst – erzwinge Beenden")
			killTree(cmd.Process.Pid)
		}
		if srv != nil {
			_ = srv.Close()
		}
		close(done)
	})
}

// Nur Anfragen an 127.0.0.1:Port zulassen (Schutz gegen DNS-Rebinding).
func hostGuard(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Host != addr && r.Host != fmt.Sprintf("localhost:%d", port) {
			http.Error(w, "forbidden", http.StatusForbidden)
			return
		}
		next.ServeHTTP(w, r)
	})
}

func protected(h http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost || r.Header.Get("X-Token") != token {
			http.Error(w, "forbidden", http.StatusForbidden)
			return
		}
		h(w, r)
	}
}

func cleanPDFName(n string) string {
	n = strings.TrimSpace(safeName.ReplaceAllString(n, " "))
	n = strings.TrimRight(n, ". ")
	if n == "" || strings.EqualFold(n, ".pdf") {
		n = "Schadensprotokoll"
	}
	if !strings.HasSuffix(strings.ToLower(n), ".pdf") {
		n += ".pdf"
	}
	return n
}

// GET/POST /__settings -> Einstellungen (inkl. laufender Nummer) als Datei sichern
func handleSettings(w http.ResponseWriter, r *http.Request) {
	path := filepath.Join(dataDir(), "einstellungen.json")
	switch r.Method {
	case http.MethodGet:
		w.Header().Set("Content-Type", "application/json")
		w.Header().Set("Cache-Control", "no-store")
		data, err := os.ReadFile(path)
		if err != nil || !json.Valid(data) {
			_, _ = w.Write([]byte("{}"))
			return
		}
		_, _ = w.Write(data)
	case http.MethodPost:
		if r.Header.Get("X-Token") != token {
			http.Error(w, "forbidden", http.StatusForbidden)
			return
		}
		data, err := io.ReadAll(io.LimitReader(r.Body, 1<<20))
		if err != nil || !json.Valid(data) {
			http.Error(w, "ungültig", http.StatusBadRequest)
			return
		}
		tmp := path + ".tmp"
		if err := os.WriteFile(tmp, data, 0o644); err == nil {
			err = os.Rename(tmp, path)
			if err != nil {
				http.Error(w, err.Error(), 500)
				return
			}
		}
		w.WriteHeader(http.StatusNoContent)
	default:
		http.Error(w, "method", http.StatusMethodNotAllowed)
	}
}

// POST /__save?name=datei.pdf  (Body = PDF) -> speichert in Dokumente\Schadensprotokolle
func handleSave(w http.ResponseWriter, r *http.Request) {
	data, err := io.ReadAll(io.LimitReader(r.Body, 200<<20))
	if err != nil || len(data) < 5 || string(data[:5]) != "%PDF-" {
		http.Error(w, "ungültige PDF", http.StatusBadRequest)
		return
	}
	path, err := savePDF(data, r.URL.Query().Get("name"))
	if err != nil {
		http.Error(w, err.Error(), 500)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]string{"path": path})
}

// savePDF legt die Datei in Dokumente\Schadensprotokolle ab, ohne Vorhandenes zu überschreiben.
func savePDF(data []byte, rawName string) (string, error) {
	dir := filepath.Join(documentsDir(), "Schadensprotokolle")
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return "", err
	}
	name := cleanPDFName(rawName)
	path := filepath.Join(dir, name)
	base := strings.TrimSuffix(name, ".pdf")
	for i := 2; ; i++ {
		if _, err := os.Stat(path); errors.Is(err, os.ErrNotExist) {
			break
		}
		path = filepath.Join(dir, fmt.Sprintf("%s_%d.pdf", base, i))
	}
	if err := os.WriteFile(path, data, 0o644); err != nil {
		return "", err
	}
	log.Printf("gespeichert: %s", path)
	return path, nil
}

// mailto-/URL-Parameter: Leerzeichen als %20 (nicht +), damit Mailprogramme sie richtig anzeigen
func qesc(s string) string { return strings.ReplaceAll(url.QueryEscape(s), "+", "%20") }

// POST /__share?via=mail|whatsapp&name=…&to=…&subject=…&text=…  (Body = PDF)
// mail: Mailprogramm mit PDF-Anhang (MAPI); sonst mailto + PDF im Explorer markiert.
// whatsapp: PDF im Explorer markieren und WhatsApp Desktop (oder WhatsApp Web) öffnen.
func handleShare(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query()
	data, err := io.ReadAll(io.LimitReader(r.Body, 200<<20))
	if err != nil || len(data) < 5 || string(data[:5]) != "%PDF-" {
		http.Error(w, "ungültige PDF", http.StatusBadRequest)
		return
	}
	path, err := savePDF(data, q.Get("name"))
	if err != nil {
		http.Error(w, err.Error(), 500)
		return
	}
	to := strings.TrimSpace(q.Get("to"))
	if strings.ContainsAny(to, "\r\n,;") {
		to = ""
	}
	res := map[string]string{"path": path}
	switch q.Get("via") {
	case "mail":
		if err := sendMailWithAttachment(to, q.Get("subject"), q.Get("text"), path, filepath.Base(path)); err == nil {
			res["result"] = "attached"
		} else {
			log.Printf("Mail mit Anhang nicht möglich (%v) – mailto", err)
			_ = exec.Command("explorer.exe", "/select,"+path).Start()
			openURL("mailto:" + qesc(to) + "?subject=" + qesc(q.Get("subject")) + "&body=" + qesc(q.Get("text")))
			res["result"] = "mailto"
		}
	case "whatsapp":
		_ = exec.Command("explorer.exe", "/select,"+path).Start()
		if whatsAppInstalled() {
			openURL("whatsapp://send?text=" + qesc(q.Get("text")))
			res["result"] = "desktop"
		} else {
			openURL("https://web.whatsapp.com/send?text=" + qesc(q.Get("text")))
			res["result"] = "web"
		}
	default:
		http.Error(w, "via", http.StatusBadRequest)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(res)
}

// POST /__reveal?path=... -> Datei im Explorer markieren
func handleReveal(w http.ResponseWriter, r *http.Request) {
	p := filepath.Clean(r.URL.Query().Get("path"))
	root := filepath.Join(documentsDir(), "Schadensprotokolle")
	if !strings.HasPrefix(strings.ToLower(p), strings.ToLower(root)) {
		http.Error(w, "forbidden", http.StatusForbidden)
		return
	}
	_ = exec.Command("explorer.exe", "/select,"+p).Start()
	w.WriteHeader(http.StatusNoContent)
}

// POST /__mail?subject=...  -> öffnet das Standard-Mailprogramm (Anhang wird manuell eingefügt)
func handleMail(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query()
	u := "mailto:" + qesc(q.Get("to")) + "?subject=" + qesc(q.Get("subject")) + "&body=" + qesc(q.Get("body"))
	_ = exec.Command("rundll32.exe", "url.dll,FileProtocolHandler", u).Start()
	w.WriteHeader(http.StatusNoContent)
}

func findBrowser() string {
	var cands []string
	for _, env := range []string{"ProgramFiles(x86)", "ProgramFiles", "LOCALAPPDATA"} {
		b := os.Getenv(env)
		if b == "" {
			continue
		}
		cands = append(cands,
			filepath.Join(b, "Microsoft", "Edge", "Application", "msedge.exe"),
			filepath.Join(b, "Google", "Chrome", "Application", "chrome.exe"))
	}
	for _, c := range cands {
		if _, err := os.Stat(c); err == nil {
			return c
		}
	}
	return ""
}

// Öffnet das App-Fenster. own=true: eigener Prozess, wird beim Beenden mit geschlossen.
func openWindow(own bool) bool {
	exe := findBrowser()
	if exe == "" {
		log.Printf("Edge/Chrome nicht gefunden – Standardbrowser")
		return exec.Command("rundll32.exe", "url.dll,FileProtocolHandler", appURL).Start() == nil
	}
	profile := filepath.Join(dataDir(), "Browserprofil")
	cmd := exec.Command(exe,
		"--app="+appURL,
		"--user-data-dir="+profile,
		"--no-first-run",
		"--no-default-browser-check",
		"--disable-background-mode", // nach dem Schließen nicht im Hintergrund weiterlaufen
		"--disable-extensions",
		"--disable-features=Translate,msEdgeStartupBoost,msImplicitSignin",
		"--window-size=520,960",
		"--lang=de")
	if err := cmd.Start(); err != nil {
		log.Printf("Browserstart fehlgeschlagen: %v", err)
		return exec.Command("rundll32.exe", "url.dll,FileProtocolHandler", appURL).Start() == nil
	}
	if !own {
		go func() { _ = cmd.Wait() }()
		return true
	}
	stateMu.Lock()
	browserCmd = cmd
	stateMu.Unlock()
	_ = cmd.Wait()
	stateMu.Lock()
	browserDone = true
	stateMu.Unlock()
	log.Printf("Browserprozess beendet")
	return true
}
