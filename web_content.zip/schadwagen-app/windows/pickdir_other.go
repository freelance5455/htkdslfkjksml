//go:build !windows

package main

import (
	"errors"
	"os/exec"
)

// Nur für Test-Builds außerhalb von Windows.
func pickFolder(title, start string) (string, error) {
	return "", errors.New("Ordnerauswahl nur unter Windows")
}
func openFolder(dir string) { _ = exec.Command("xdg-open", dir).Start() }
