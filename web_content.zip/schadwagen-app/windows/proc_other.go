//go:build !windows

package main

import "syscall"

func killTree(pid int) { _ = syscall.Kill(pid, syscall.SIGTERM) }
