//go:build windows

package main

import (
	"os/exec"
	"strconv"
	"syscall"
)

// killTree beendet einen Prozess samt aller Unterprozesse, ohne Konsolenfenster.
func killTree(pid int) {
	cmd := exec.Command("taskkill", "/PID", strconv.Itoa(pid), "/T", "/F")
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: 0x08000000} // CREATE_NO_WINDOW
	_ = cmd.Run()
}
