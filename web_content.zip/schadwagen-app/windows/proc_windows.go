//go:build windows

package main

import (
	"os/exec"
	"strconv"
	"syscall"
)

// killTree beendet einen Prozess samt aller Unterprozesse, ohne Konsolenfenster.
func killTree(pid int) {
	cmd := exec.Command("taskkill", "/PID", strconv.Itoa(pid), "/T", "/F")
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: 0x08000000} // CREATE_NO_WINDOW
	_ = cmd.Run()
}

// pidOnPort: Prozess, der auf 127.0.0.1:port lauscht (über netstat, sprachunabhängig ausgewertet).
func pidOnPort(port int) int {
	cmd := exec.Command("netstat", "-ano", "-p", "TCP")
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: 0x08000000}
	out, err := cmd.Output()
	if err != nil {
		return 0
	}
	return parseNetstatPID(string(out), port)
}
