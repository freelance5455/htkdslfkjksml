//go:build windows

package main

import (
	"log"
	"os"
	"syscall"
	"unsafe"
)

func fatal(msg string) {
	log.Print(msg)
	user32 := syscall.NewLazyDLL("user32.dll")
	box := user32.NewProc("MessageBoxW")
	t, _ := syscall.UTF16PtrFromString("Schadensprotokoll")
	m, _ := syscall.UTF16PtrFromString(msg)
	_, _, _ = box.Call(0, uintptr(unsafe.Pointer(m)), uintptr(unsafe.Pointer(t)), 0x30)
	os.Exit(1)
}
