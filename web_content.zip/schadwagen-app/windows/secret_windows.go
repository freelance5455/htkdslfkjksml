//go:build windows

package main

import (
	"errors"
	"syscall"
	"unsafe"
)

// Schutz der Geheimnisse (API-Token, Sitzung) mit der Windows-DPAPI: nur der angemeldete
// Windows-Benutzer auf diesem Rechner kann die Datei wieder entschlüsseln.

type dataBlob struct {
	cbData uint32
	pbData *byte
}

var (
	crypt32       = syscall.NewLazyDLL("crypt32.dll")
	kernel32      = syscall.NewLazyDLL("kernel32.dll")
	procProtect   = crypt32.NewProc("CryptProtectData")
	procUnprotect = crypt32.NewProc("CryptUnprotectData")
	procLocalFree = kernel32.NewProc("LocalFree")
	secretEntropy = []byte("Schadwagen-Management/secrets/v1")
	errDPAPI      = errors.New("DPAPI-Fehler")
)

const cryptprotectUIForbidden = 0x1

func blob(b []byte) *dataBlob {
	if len(b) == 0 {
		return &dataBlob{}
	}
	return &dataBlob{cbData: uint32(len(b)), pbData: &b[0]}
}

func (b *dataBlob) bytes() []byte {
	if b.cbData == 0 {
		return nil
	}
	out := make([]byte, b.cbData)
	copy(out, unsafe.Slice(b.pbData, b.cbData))
	return out
}

func protectSecret(plain []byte) ([]byte, error) {
	var out dataBlob
	r, _, _ := procProtect.Call(uintptr(unsafe.Pointer(blob(plain))), 0, uintptr(unsafe.Pointer(blob(secretEntropy))), 0, 0,
		cryptprotectUIForbidden, uintptr(unsafe.Pointer(&out)))
	if r == 0 {
		return nil, errDPAPI
	}
	defer procLocalFree.Call(uintptr(unsafe.Pointer(out.pbData)))
	return out.bytes(), nil
}

func unprotectSecret(enc []byte) ([]byte, error) {
	var out dataBlob
	r, _, _ := procUnprotect.Call(uintptr(unsafe.Pointer(blob(enc))), 0, uintptr(unsafe.Pointer(blob(secretEntropy))), 0, 0,
		cryptprotectUIForbidden, uintptr(unsafe.Pointer(&out)))
	if r == 0 {
		return nil, errDPAPI
	}
	defer procLocalFree.Call(uintptr(unsafe.Pointer(out.pbData)))
	return out.bytes(), nil
}
