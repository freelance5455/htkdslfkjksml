// Offline-Cache für die PWA-Variante (im nativen Container nicht aktiv)
const CACHE = 'schadwagen-v25';
const ASSETS = [
  './', 'index.html', 'manifest.webmanifest', 'css/app.css', 'css/dashboard.css', 'css/team.css', 'js/ui/dashboard.js', 'js/ui/views.js', 'js/server.js', 'js/secrets.js', 'js/sync.js', 'js/employees.js', 'js/folders.js', 'js/viewstate.js', 'js/logo.js', 'js/templates.js', 'js/ui/templatesView.js', 'js/zip.js', 'data/halter.js', 'js/endpoint.js', 'js/ui/serverPanel.js', 'js/importer.js', 'js/presence.js',
  'vendor/pdf-lib.min.js', 'data/schadcodes.js', 'data/betriebsstellen.js', 'js/stations.js', 'js/keeper.js', 'assets/GCU_Schadprotokoll_Grunddatei.pdf',
  'js/main.js', 'js/state.js', 'js/storage.js', 'js/codes.js', 'js/platform.js', 'js/wagon.js',
  'js/pdf/fillProtocol.js', 'js/ui/dom.js', 'js/ui/form.js', 'js/ui/codePicker.js', 'js/ui/screens.js',
  'icons/icon-192.png', 'icons/icon-maskable-192.png', 'icons/icon-maskable-512.png', 'icons/apple-touch-icon.png', 'icons/favicon-32.png', 'icons/brand-logo.png', 'favicon.ico', 'fonts/inter-400.woff?v=i3', 'fonts/inter-500.woff?v=i3', 'fonts/inter-600.woff?v=i3', 'fonts/inter-display-600.woff', 'fonts/inter-display-700.woff', 'icons/icon-512.png',
];
self.addEventListener('install', (e) => e.waitUntil(caches.open(CACHE).then((c) => c.addAll(ASSETS)).then(() => self.skipWaiting())));
self.addEventListener('activate', (e) => e.waitUntil(
  caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim())));
self.addEventListener('fetch', (e) => {
  if (e.request.method !== 'GET') return;
  // Immer beim Server nachfragen (kein heuristischer HTTP-Cache) – sonst könnten Module zweier Versionen gemischt werden
  const req = e.request.mode === 'navigate' ? e.request : new Request(e.request, { cache: 'no-cache' });
  e.respondWith(fetch(req).then((res) => {
    const copy = res.clone();
    caches.open(CACHE).then((c) => c.put(e.request, copy)).catch(() => {});
    return res;
  }).catch(() => caches.match(e.request)));
});
