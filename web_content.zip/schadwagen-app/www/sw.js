// Offline-Cache für die PWA-Variante (im nativen Container nicht aktiv)
const CACHE = 'schadwagen-v10';
const ASSETS = [
  './', 'index.html', 'manifest.webmanifest', 'css/app.css', 'css/dashboard.css', 'css/team.css', 'js/ui/dashboard.js', 'js/ui/views.js', 'js/server.js', 'js/secrets.js', 'js/sync.js', 'js/employees.js', 'js/folders.js', 'js/importer.js', 'js/presence.js',
  'vendor/pdf-lib.min.js', 'data/schadcodes.js', 'data/betriebsstellen.js', 'js/stations.js', 'js/keeper.js', 'assets/GCU_Schadprotokoll_Grunddatei.pdf',
  'js/main.js', 'js/state.js', 'js/storage.js', 'js/codes.js', 'js/platform.js', 'js/wagon.js',
  'js/pdf/fillProtocol.js', 'js/ui/dom.js', 'js/ui/form.js', 'js/ui/codePicker.js', 'js/ui/screens.js',
  'icons/icon-192.png', 'fonts/inter-400.woff', 'fonts/inter-500.woff', 'fonts/inter-600.woff', 'fonts/inter-display-600.woff', 'fonts/inter-display-700.woff', 'icons/icon-512.png',
];
self.addEventListener('install', (e) => e.waitUntil(caches.open(CACHE).then((c) => c.addAll(ASSETS)).then(() => self.skipWaiting())));
self.addEventListener('activate', (e) => e.waitUntil(
  caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim())));
self.addEventListener('fetch', (e) => {
  if (e.request.method !== 'GET') return;
  e.respondWith(fetch(e.request).then((res) => {
    const copy = res.clone();
    caches.open(CACHE).then((c) => c.put(e.request, copy)).catch(() => {});
    return res;
  }).catch(() => caches.match(e.request)));
});
