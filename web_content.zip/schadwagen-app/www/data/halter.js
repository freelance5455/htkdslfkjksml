// Bekannte Wagenhalter (RICS-/Halternummer, Name, Adresse, E-Mail) – Grundbestand aus den
// Vorlagen-PDFs des Nutzers (25.10.2026, „RICS_<Nr>_<Name>.pdf“). Dient dazu, beim Import von
// Vorlagen die Halternummer anhand des Halternamens (oder umgekehrt) zu erkennen und fehlende
// Adressen/E-Mails zu ergänzen. Eigene Vorlagen ergänzen diesen Bestand automatisch.
export const HALTER = [
  {
   "code": "2180",
   "name": "DB Cargo AG",
   "address": "Rheinstraße 2, 55116 Mainz Germany",
   "email": "L-AVV@deutschebahn.com"
  },
  {
   "code": "2181",
   "name": "Rail Cargo Austria AG",
   "address": "Am Hauptbahnhof 21100 WienAustria",
   "email": ""
  },
  {
   "code": "3237",
   "name": "ERMEWA SA - FR",
   "address": "CS 60199, 4-10 avenue André Malraux 92309 LEVALLOIS-PERRET Cedex FR",
   "email": "wagons@ermewa.com"
  },
  {
   "code": "3816",
   "name": "Budamar Innovations a.s.",
   "address": "Horarska 12, 82109 Bratislava Slovakia",
   "email": "agony-bin@budamar.sk"
  },
  {
   "code": "4006",
   "name": "GATX Rail Austria GmbH",
   "address": "Am Europlatz 5, Gebäude C 1120 Wien Austria",
   "email": "fsc-gra@gatx.eu"
  },
  {
   "code": "4054",
   "name": "VTG Schweiz GmbH",
   "address": "Bodenfeldstrasse 10, 5643 Sins Switzerland",
   "email": "service@vtg.com"
  },
  {
   "code": "4055",
   "name": "Wascosa AG",
   "address": "Wascosa AG Werftestrasse 4, 6005 Luzern Switzerland",
   "email": "ops@wascosa.com"
  },
  {
   "code": "4093",
   "name": "Aretz GmbH & Co. KG",
   "address": "Luisenplatz 947799 KrefeldGermany",
   "email": "DNebendahl@aretzwaggon.de"
  },
  {
   "code": "4094",
   "name": "ARS Altmann AG",
   "address": "Feierabendmuehle 285283 Wolnzach Germany",
   "email": "waggon@ars-altmann.de"
  },
  {
   "code": "4132",
   "name": "ERMEWA SA - D",
   "address": "Tauentzienstr. 7A, 10789 Berlin Germany",
   "email": "wagons@ermewa.com"
  },
  {
   "code": "4133",
   "name": "ERR European Rail Rent GmbH",
   "address": "Schifferstr. 196, 47059 Duisburg Germany",
   "email": "michael.prahm@railrent.com"
  },
  {
   "code": "4139",
   "name": "GATX Rail Germany GmbH",
   "address": "Emporio-Tower, 9. Etage Valentinskamp 70, 20355 Hamburg DE",
   "email": "fsc-grg@gatx.eu"
  },
  {
   "code": "4186",
   "name": "On Rail - Gesellschaft für Eisenbahnausrüstung und Zubehör mbH",
   "address": "Steinesweg 10, 40822 Mettmann Germany",
   "email": "mwm@on-rail.com"
  },
  {
   "code": "4187",
   "name": "On Rail Gesellschaft für Vermietung und Verwaltung von Eisenbahnwaggons mbH",
   "address": "Eurotec-Ring 10, 47445 Moers Germany",
   "email": "Rainer.Segeth@orv-moers.de"
  },
  {
   "code": "4216",
   "name": "VTG Rail Europe GmbH",
   "address": "VTG Rail Europe GmbH Nagelsweg 34, 20097 Hamburg DE",
   "email": "service@vtg.com"
  },
  {
   "code": "4236",
   "name": "ATIR-RAIL GESTION",
   "address": "56 rue de Londres 75008 Paris France",
   "email": "wagons@atir-rail.com"
  },
  {
   "code": "5125",
   "name": "Greenbrier leasing Europe B.V.",
   "address": "Keizersgracht 534, 1017EK Amsterdam Netherlands",
   "email": "ecm@gbrx.com"
  }
];
