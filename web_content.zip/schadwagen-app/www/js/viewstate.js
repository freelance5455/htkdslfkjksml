// Gemeinsamer Ansichtszustand von Dashboard und „Gespeichert“ (pro Gerät gemerkt):
// Mitarbeiterfilter und geöffneter Ordner. Gleiche Auswahl = gleiche Zählung in beiden Ansichten.
import { ownerOf } from './employees.js';
import { detectionParts } from './folders.js';

const OWNER_KEY = 'sw.ownerFilter.v1';
const PATH_KEY = 'sw.savedPath.v1';
const read = (k, d) => { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch { return d; } };
const write = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* privat/voll */ } };

/** '' = alle (inkl. nicht zugeordnete), '__none__' = nicht zugeordnet, sonst Mitarbeiter-ID */
export const getOwnerFilter = () => { const v = read(OWNER_KEY, ''); return typeof v === 'string' ? v : ''; };
export const setOwnerFilter = (v) => write(OWNER_KEY, v || '');

/** Gehört das Protokoll zur aktuellen Auswahl? „Alle“ zeigt immer auch nicht zugeordnete. */
export function matchesOwner(r, settings, f = getOwnerFilter()) {
  if (!f) return true;
  const { employee } = ownerOf(r, settings);
  return f === '__none__' ? !employee : !!employee && employee.id === f;
}

/** Ordnerpfad in „Gespeichert“ */
export const getSavedPath = () => read(PATH_KEY, null) || { kind: 'root' };
export const setSavedPath = (p) => write(PATH_KEY, p || { kind: 'root' });
/** Datumsordner eines Protokolls öffnen und den Eintrag hervorheben. */
export function savedPathFor(r) {
  const p = detectionParts(r);
  return p ? { kind: 'day', y: p.y, m: p.m, iso: p.iso, focus: r.id } : { kind: 'none', focus: r.id };
}
/** Kalendertag eines Protokolls (= „Schaden festgestellt am“) oder null */
export const calendarDayOf = (r) => detectionParts(r)?.iso || null;
