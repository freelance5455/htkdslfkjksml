// Gemeinsame Server-Verbindung: Adresse + API-Token, Anmeldung mit Passwortschlüssel,
// Latenzmessung alle 15 Sekunden. Genutzt von Halter-Abfrage, Protokoll- und Mitarbeiterabgleich.
// Verbindungsart „HTTPS-Adresse (Domain)“ oder „IP-Verbindung“ (endpoint.js). IP-Verbindungen und
// Server mit gemerktem Zertifikat-Fingerabdruck laufen in der Windows-App über das lokale Programm
// (/__proxy) und in der Android-App über den nativen Netzwerkzugriff – nur dort lassen sich
// selbst ausgestellte Zertifikate prüfen (Pinning) und Fehler genau unterscheiden.
import { getSecret, setSecret } from './secrets.js';
import { resolveEndpoint, checkDomainUrl, fmtFp } from './endpoint.js';
import { nativeNet, hasNativeNet } from './platform.js';

const PING_MS = 15000;
const TIMEOUT_MS = 10000;

let getSettings = () => ({});
const listeners = new Set();
let timer = null;

export const conn = {
  status: 'none', // none | checking | ok | insecure | bad_url | bad_ip | bad_port | http_public | http_confirm |
  //                 bad_token | refused | timeout | dns | cert_untrusted | cert_changed | tls | network | not_schadwagen | unreachable
  message: '',
  latency: null,
  history: [], // letzte Messungen in ms
  lastCheck: null,
  loginRequired: false,
  loggedIn: false,
  expiresAt: null,
  features: [],
  version: '',
  endpoint: null, // { label, url, scheme, pin, transport }
  cert: null, // bei cert_untrusted/cert_changed: { fingerprint, subject, issuer, notBefore, notAfter, selfSigned }
};

export function configureServer(fn) { getSettings = fn; }
export function onConnChange(fn) { listeners.add(fn); return () => listeners.delete(fn); }
const emit = () => listeners.forEach((fn) => { try { fn(conn); } catch (e) { console.error(e); } });

/** Prüft eine Domain-Adresse (frühere Schnittstelle): nur https:// (Ausnahme: localhost). */
export function checkUrl(raw) {
  const c = checkDomainUrl(raw);
  return c.ok ? { ok: true, url: c.url } : c;
}

export const currentEndpoint = (s = getSettings()) => resolveEndpoint(s);
export const serverBase = () => { const e = currentEndpoint(); return e.ok ? e.url : ''; };
export const configured = () => !!serverBase();
export const canSync = () => conn.status === 'ok' && (conn.loggedIn || !conn.loginRequired) && conn.features.includes('protocols');

/** IP-Verbindung oder gemerkter Fingerabdruck -> über das Windows-Programm bzw. die Android-App. */
const wantsNative = (ep) => ep && (ep.mode === 'ip' || !!ep.pin);
export const transportOf = (ep) => (wantsNative(ep) && hasNativeNet() ? 'native' : 'direct');

export class NetError extends Error {
  constructor(code, detail, extra = {}) { super(detail || code); this.code = code; this.detail = detail || ''; Object.assign(this, extra); }
}

/**
 * fetch-ähnliche Anfrage an den Server über den passenden Weg. Liefert { ok, status, json(), text() }
 * oder wirft NetError (code: timeout | refused | dns | cert_untrusted | cert_changed | tls | network | blocked).
 */
export async function serverFetch(url, { method = 'GET', headers = {}, body, timeout = TIMEOUT_MS, keepalive = false, ep = currentEndpoint() } = {}) {
  if (transportOf(ep) === 'native') {
    let r;
    try {
      r = await nativeNet('request', { url, method, headers, body: body ?? null, pin: ep.pin || '', timeoutMs: timeout,
        allowHttp: ep.scheme === 'http' && ep.private });
    } catch (e) { throw new NetError('network', String(e && e.message || e)); }
    if (r.error) throw new NetError(r.error, r.detail, { cert: r.cert || null });
    const text = r.body || '';
    return { ok: r.status >= 200 && r.status < 300, status: r.status, text: async () => text, json: async () => JSON.parse(text) };
  }
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeout);
  try {
    const res = await fetch(url, { method, headers, body, cache: 'no-store', signal: ctrl.signal, keepalive });
    return res;
  } catch (e) {
    if (e && e.name === 'AbortError') throw new NetError('timeout');
    throw new NetError('network', String(e && e.message || e));
  } finally { clearTimeout(t); }
}

/** Fehlermeldung zu einem NetError für Menschen. */
export function netMessage(err, ep = currentEndpoint()) {
  const port = ep && ep.port;
  switch (err && err.code) {
    case 'timeout': return 'Zeitüberschreitung – keine Antwort vom Server. Adresse, Netz und Firewall prüfen.';
    case 'refused': return `Port ${port || ''} nicht erreichbar – der Server lehnt ab (läuft das Programm, stimmt der Port, ist er in der Firewall freigegeben?).`.replace('Port  ', 'Port ');
    case 'unreachable': return 'Netz bzw. Rechner nicht erreichbar (kein Weg zur Adresse).';
    case 'dns': return 'Adresse nicht gefunden (Name unbekannt).';
    case 'cert_untrusted': return 'Zertifikat nicht vertrauenswürdig (z. B. selbst ausgestellt). Fingerabdruck prüfen und bestätigen.';
    case 'cert_changed': return 'Achtung: Das Zertifikat des Servers hat sich geändert – Verbindung gesperrt.';
    case 'tls': return /unverschlüsselt/.test(err.detail || '')
      ? 'Der Server antwortet unverschlüsselt (http). Entweder „Unverschlüsselt (http, nur lokales Netz)“ wählen oder den Server mit https starten (TLS_SELF_SIGNED=1).'
      : `Verschlüsselte Verbindung fehlgeschlagen${err.detail ? ` (${err.detail})` : ''}. Spricht der Server dort https?`;
    case 'blocked': return err.detail || 'Verbindung nicht erlaubt.';
    default:
      if (typeof navigator !== 'undefined' && navigator.onLine === false) return 'Gerät ist offline.';
      if (ep && ep.ip && ep.scheme === 'https' && !hasNativeNet()) return 'Server nicht erreichbar oder Zertifikat nicht vertrauenswürdig. Im Browser lässt sich ein selbst ausgestelltes Zertifikat nicht bestätigen – bitte die Windows- oder Android-App nutzen oder das Zertifikat im System installieren.';
      if (ep && ep.scheme === 'http' && location.protocol === 'https:' && !hasNativeNet()) return 'Der Browser blockiert unverschlüsselte Verbindungen aus einer https-Seite – bitte die Windows- oder Android-App nutzen.';
      return 'Server nicht erreichbar.';
  }
}

export function authHeaders(extra = {}) {
  const h = { ...extra };
  const key = getSecret('apiToken');
  const ses = getSecret('sessionToken');
  if (key) h['X-Api-Key'] = key;
  if (ses) h.Authorization = `Bearer ${ses}`;
  return h;
}

/** Anfrage an den Server. Ergebnis: { ok, status, data, error, network } */
export async function api(path, { method = 'GET', body, timeout = TIMEOUT_MS, keepalive = false } = {}) {
  const ep = currentEndpoint();
  if (!ep.ok) return { ok: false, status: 0, error: 'not_configured', network: false };
  let res;
  try {
    res = await serverFetch(ep.url + path, {
      method, timeout, keepalive, ep,
      headers: authHeaders(body !== undefined ? { 'Content-Type': 'application/json' } : {}),
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
  } catch (e) {
    return { ok: false, status: 0, error: e.code || 'network', network: true, message: netMessage(e, ep) };
  }
  let data = null;
  try { data = await res.json(); } catch { data = null; }
  if (res.status === 401 && data && data.error === 'login_required' && getSecret('sessionToken')) {
    // Sitzung abgelaufen
    await setSecret('sessionToken', '');
    conn.loggedIn = false; emit();
  }
  return { ok: res.ok, status: res.status, data, error: data && data.error, network: false };
}

/**
 * Verbindung prüfen (Knopf „Verbindung prüfen“ und Latenzmessung).
 * settings: zu prüfende (noch ungespeicherte) Einstellungen, sonst die gespeicherten. Rückgabe: conn
 */
export async function checkConnection({ settings, url: rawUrl, token, quiet = false } = {}) {
  const src = settings || (rawUrl !== undefined ? { ...getSettings(), serverMode: 'https', serverUrl: rawUrl } : getSettings());
  const ep = resolveEndpoint(src);
  conn.endpoint = ep.ok ? { label: ep.label, url: ep.url, scheme: ep.scheme, pin: ep.pin ? fmtFp(ep.pin) : '', transport: transportOf(ep), mode: ep.mode } : null;
  if (!ep.ok) {
    Object.assign(conn, { status: ep.reason === 'empty' ? 'none' : ep.reason, message: ep.message, latency: null, loggedIn: false, cert: null });
    emit();
    return conn;
  }
  if (!quiet) { conn.status = 'checking'; conn.message = 'Verbindung wird geprüft …'; emit(); }
  const headers = authHeaders();
  if (token !== undefined) { if (token) headers['X-Api-Key'] = token; else delete headers['X-Api-Key']; }
  const t0 = performance.now();
  let res, data = null;
  try {
    res = await serverFetch(`${ep.url}/api/ping`, { headers, ep });
    try { data = await res.json(); } catch { data = null; }
  } catch (e) {
    Object.assign(conn, { status: e.code === 'network' ? 'unreachable' : e.code, message: netMessage(e, ep), latency: null, lastCheck: new Date(), cert: e.cert || null });
    emit();
    return conn;
  }
  const ms = Math.round(performance.now() - t0);
  conn.lastCheck = new Date();
  conn.cert = null;
  if (res.status === 401 && data && data.error === 'invalid_token') {
    Object.assign(conn, { status: 'bad_token', message: 'API-Token ungültig.', latency: ms });
  } else if (res.ok && data && data.service === 'schadwagen-backend') {
    Object.assign(conn, {
      status: 'ok', message: 'Verbunden', latency: ms,
      loginRequired: !!data.loginRequired, loggedIn: !data.loginRequired || !!data.loggedIn,
      features: data.features || [], version: data.version || '',
    });
    if (data.loginRequired && !data.loggedIn && getSecret('sessionToken')) await setSecret('sessionToken', '');
    conn.history = [...conn.history, ms].slice(-20);
  } else if (res.status >= 500) {
    Object.assign(conn, { status: 'unreachable', message: `Server meldet Fehler ${res.status}.`, latency: null });
  } else {
    Object.assign(conn, { status: 'not_schadwagen', message: `Dort antwortet kein TrainTrace-Server${res.status ? ` (Antwort ${res.status})` : ''} – Adresse und Port prüfen.`, latency: null });
  }
  emit();
  return conn;
}

/** Zertifikat eines https-Servers abrufen (nur Windows-/Android-App). */
export async function probeCertificate(ep) {
  if (!hasNativeNet()) return { error: 'unsupported' };
  try { return await nativeNet('probe', { host: ep.host, port: ep.port }); } catch (e) { return { error: 'network', detail: String(e && e.message || e) }; }
}

export async function login(password) {
  const r = await api('/api/login', { method: 'POST', body: { password } });
  if (r.ok && r.data && r.data.token) {
    await setSecret('sessionToken', r.data.token);
    Object.assign(conn, { loggedIn: true, expiresAt: r.data.expiresAt || null });
    emit();
    return { ok: true };
  }
  if (r.ok && r.data && r.data.loginRequired === false) { conn.loggedIn = true; emit(); return { ok: true }; }
  if (r.error === 'wrong_password') return { ok: false, message: 'Passwortschlüssel ist falsch.' };
  if (r.error === 'rate_limited') return { ok: false, message: 'Zu viele Fehlversuche – bitte später erneut versuchen.' };
  if (r.error === 'invalid_token') return { ok: false, message: 'API-Token ungültig.' };
  if (r.network) return { ok: false, message: r.message || 'Server nicht erreichbar.' };
  return { ok: false, message: (r.data && r.data.message) || `Anmeldung fehlgeschlagen (${r.status}).` };
}

export async function logout() {
  if (getSecret('sessionToken')) await api('/api/logout', { method: 'POST' });
  await setSecret('sessionToken', '');
  Object.assign(conn, { loggedIn: !conn.loginRequired, expiresAt: null });
  emit();
}

export async function refreshSession() {
  const r = await api('/api/session');
  if (r.ok && r.data) { conn.loggedIn = !!r.data.loggedIn; conn.expiresAt = r.data.expiresAt || null; emit(); }
}

/** Latenzmessung alle 15 Sekunden (pausiert, solange die App im Hintergrund ist). */
export function startMonitor(onTick) {
  stopMonitor();
  const tick = async () => {
    if (!configured()) { if (conn.status !== 'none') { Object.assign(conn, { status: 'none', latency: null }); emit(); } return; }
    if (document.visibilityState === 'hidden') return;
    await checkConnection({ quiet: conn.status === 'ok' || conn.status === 'unreachable' });
    onTick && onTick(conn);
  };
  timer = setInterval(tick, PING_MS);
  if (!startMonitor.bound) {
    startMonitor.bound = true;
    document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible' && timer) tick(); });
    window.addEventListener('online', () => timer && tick());
  }
  return tick();
}
export function stopMonitor() { if (timer) clearInterval(timer); timer = null; }

export const latencyLevel = (c = conn) => (c.status !== 'ok' || c.latency == null ? 'off' : c.latency < 150 ? 'good' : c.latency <= 500 ? 'mid' : 'bad');
