// Gemeinsame Server-Verbindung: Adresse + API-Token, Anmeldung mit Passwortschlüssel,
// Latenzmessung alle 15 Sekunden. Genutzt von Halter-Abfrage, Protokoll- und Mitarbeiterabgleich.
import { getSecret, setSecret } from './secrets.js';

const PING_MS = 15000;
const TIMEOUT_MS = 10000;

let getSettings = () => ({});
const listeners = new Set();
let timer = null;

export const conn = {
  status: 'none', // none | checking | ok | insecure | bad_url | bad_token | unreachable
  message: '',
  latency: null,
  history: [], // letzte Messungen in ms
  lastCheck: null,
  loginRequired: false,
  loggedIn: false,
  expiresAt: null,
  features: [],
  version: '',
};

export function configureServer(fn) { getSettings = fn; }
export function onConnChange(fn) { listeners.add(fn); return () => listeners.delete(fn); }
const emit = () => listeners.forEach((fn) => { try { fn(conn); } catch (e) { console.error(e); } });

/** Prüft die Adresse: nur https:// (Ausnahme: localhost/127.0.0.1 auf demselben Rechner). */
export function checkUrl(raw) {
  const v = String(raw || '').trim();
  if (!v) return { ok: false, reason: 'empty', message: '' };
  let u;
  try { u = new URL(v); } catch { return { ok: false, reason: 'bad_url', message: 'Adresse ist ungültig, z. B. https://server.example.de' }; }
  const local = ['localhost', '127.0.0.1', '[::1]'].includes(u.hostname);
  if (u.protocol !== 'https:' && !(u.protocol === 'http:' && local)) {
    return { ok: false, reason: 'insecure', message: 'Nur https:// ist erlaubt.' };
  }
  if (u.username || u.password || u.search || u.hash) return { ok: false, reason: 'bad_url', message: 'Adresse ohne Zugangsdaten, ? oder # eingeben.' };
  return { ok: true, url: `${u.origin}${u.pathname}`.replace(/\/+$/, '') };
}

export const serverBase = () => { const c = checkUrl(getSettings().serverUrl); return c.ok ? c.url : ''; };
export const configured = () => !!serverBase();
export const canSync = () => conn.status === 'ok' && (conn.loggedIn || !conn.loginRequired) && conn.features.includes('protocols');

export function authHeaders(extra = {}) {
  const h = { ...extra };
  const key = getSecret('apiToken');
  const ses = getSecret('sessionToken');
  if (key) h['X-Api-Key'] = key;
  if (ses) h.Authorization = `Bearer ${ses}`;
  return h;
}

/** Anfrage an den Server. Ergebnis: { ok, status, data, error, network } */
export async function api(path, { method = 'GET', body, timeout = TIMEOUT_MS, base, keepalive = false } = {}) {
  const url = base || serverBase();
  if (!url) return { ok: false, status: 0, error: 'not_configured', network: false };
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeout);
  let res;
  try {
    res = await fetch(url + path, {
      method, cache: 'no-store', signal: ctrl.signal, keepalive,
      headers: authHeaders(body !== undefined ? { 'Content-Type': 'application/json' } : {}),
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
  } catch (e) {
    clearTimeout(t);
    return { ok: false, status: 0, error: e && e.name === 'AbortError' ? 'timeout' : 'network', network: true };
  }
  clearTimeout(t);
  let data = null;
  try { data = await res.json(); } catch { data = null; }
  if (res.status === 401 && data && data.error === 'login_required' && getSecret('sessionToken')) {
    // Sitzung abgelaufen
    await setSecret('sessionToken', '');
    conn.loggedIn = false; emit();
  }
  return { ok: res.ok, status: res.status, data, error: data && data.error, network: false };
}

/** Verbindung prüfen (Knopf „Verbindung prüfen“ und Latenzmessung). */
export async function checkConnection({ url: rawUrl, token, quiet = false } = {}) {
  const c = checkUrl(rawUrl ?? getSettings().serverUrl);
  if (!c.ok) {
    Object.assign(conn, { status: c.reason === 'empty' ? 'none' : c.reason, message: c.message, latency: null, loggedIn: false });
    emit();
    return conn;
  }
  if (!quiet) { conn.status = 'checking'; conn.message = 'Verbindung wird geprüft …'; emit(); }
  const headers = authHeaders();
  if (token !== undefined) { if (token) headers['X-Api-Key'] = token; else delete headers['X-Api-Key']; }
  const ctrl = new AbortController();
  const tm = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
  const t0 = performance.now();
  let res, data = null;
  try {
    res = await fetch(`${c.url}/api/ping`, { cache: 'no-store', headers, signal: ctrl.signal });
    try { data = await res.json(); } catch { data = null; }
  } catch {
    clearTimeout(tm);
    Object.assign(conn, { status: 'unreachable', message: navigator.onLine === false ? 'Gerät ist offline.' : 'Server nicht erreichbar.', latency: null, lastCheck: new Date() });
    emit();
    return conn;
  }
  clearTimeout(tm);
  const ms = Math.round(performance.now() - t0);
  conn.lastCheck = new Date();
  if (res.status === 401 && data && data.error === 'invalid_token') {
    Object.assign(conn, { status: 'bad_token', message: 'API-Token ungültig.', latency: ms });
  } else if (res.ok && data && data.service === 'schadwagen-backend') {
    Object.assign(conn, {
      status: 'ok', message: 'Verbunden', latency: ms,
      loginRequired: !!data.loginRequired, loggedIn: !data.loginRequired || !!data.loggedIn,
      features: data.features || [], version: data.version || '',
    });
    if (data.loginRequired && !data.loggedIn && getSecret('sessionToken')) await setSecret('sessionToken', '');
    conn.history = [...conn.history, ms].slice(-20);
  } else if (res.status >= 500) {
    Object.assign(conn, { status: 'unreachable', message: `Server meldet Fehler ${res.status}.`, latency: null });
  } else {
    Object.assign(conn, { status: 'bad_url', message: 'Adresse falsch – dort antwortet kein Schadwagen-Server.', latency: null });
  }
  emit();
  return conn;
}

export async function login(password) {
  const r = await api('/api/login', { method: 'POST', body: { password } });
  if (r.ok && r.data && r.data.token) {
    await setSecret('sessionToken', r.data.token);
    Object.assign(conn, { loggedIn: true, expiresAt: r.data.expiresAt || null });
    emit();
    return { ok: true };
  }
  if (r.ok && r.data && r.data.loginRequired === false) { conn.loggedIn = true; emit(); return { ok: true }; }
  if (r.error === 'wrong_password') return { ok: false, message: 'Passwortschlüssel ist falsch.' };
  if (r.error === 'rate_limited') return { ok: false, message: 'Zu viele Fehlversuche – bitte später erneut versuchen.' };
  if (r.error === 'invalid_token') return { ok: false, message: 'API-Token ungültig.' };
  if (r.network) return { ok: false, message: 'Server nicht erreichbar.' };
  return { ok: false, message: (r.data && r.data.message) || `Anmeldung fehlgeschlagen (${r.status}).` };
}

export async function logout() {
  if (getSecret('sessionToken')) await api('/api/logout', { method: 'POST' });
  await setSecret('sessionToken', '');
  Object.assign(conn, { loggedIn: !conn.loginRequired, expiresAt: null });
  emit();
}

export async function refreshSession() {
  const r = await api('/api/session');
  if (r.ok && r.data) { conn.loggedIn = !!r.data.loggedIn; conn.expiresAt = r.data.expiresAt || null; emit(); }
}

/** Latenzmessung alle 15 Sekunden (pausiert, solange die App im Hintergrund ist). */
export function startMonitor(onTick) {
  stopMonitor();
  const tick = async () => {
    if (!configured()) { if (conn.status !== 'none') { Object.assign(conn, { status: 'none', latency: null }); emit(); } return; }
    if (document.visibilityState === 'hidden') return;
    await checkConnection({ quiet: conn.status === 'ok' || conn.status === 'unreachable' });
    onTick && onTick(conn);
  };
  timer = setInterval(tick, PING_MS);
  if (!startMonitor.bound) {
    startMonitor.bound = true;
    document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible' && timer) tick(); });
    window.addEventListener('online', () => timer && tick());
  }
  return tick();
}
export function stopMonitor() { if (timer) clearInterval(timer); timer = null; }

export const latencyLevel = (c = conn) => (c.status !== 'ok' || c.latency == null ? 'off' : c.latency < 150 ? 'good' : c.latency <= 500 ? 'mid' : 'bad');
