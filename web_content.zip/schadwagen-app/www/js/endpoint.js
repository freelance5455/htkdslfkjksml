// Server-Adresse: Verbindungsart „HTTPS-Adresse (Domain)“ oder „IP-Verbindung“ (IPv4/IPv6 + Port,
// verschlüsselt per https oder – nur im lokalen Netz und nach Bestätigung – unverschlüsselt per http).
// Reine Logik ohne Netzwerkzugriff, damit sie überall gleich prüft (App, Tests).

/** IPv4 prüfen; liefert die vier Zahlen oder null. */
function v4(s) {
  const m = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(s);
  if (!m) return null;
  const n = m.slice(1).map(Number);
  if (n.some((x, i) => x > 255 || (m[i + 1].length > 1 && m[i + 1][0] === '0'))) return null;
  return n;
}

/** IPv6 prüfen und in 8 Gruppen (Zahlen) auflösen; null bei ungültig. Zonen-ID (%eth0) wird abgelehnt. */
function v6(s) {
  if (!s || /[^0-9a-f:.]/i.test(s) || s.split('::').length > 2) return null;
  let tail4 = null;
  let str = s;
  const lastColon = s.lastIndexOf(':');
  if (s.includes('.')) { // eingebettete IPv4 (::ffff:192.168.1.2)
    tail4 = v4(s.slice(lastColon + 1));
    if (!tail4) return null;
    str = `${s.slice(0, lastColon + 1)}${((tail4[0] << 8) | tail4[1]).toString(16)}:${((tail4[2] << 8) | tail4[3]).toString(16)}`;
  }
  const [a, b] = str.split('::');
  const pa = a ? a.split(':') : [];
  const pb = b !== undefined ? (b ? b.split(':') : []) : null;
  const all = pb === null ? pa : [...pa, ...Array(8 - pa.length - pb.length).fill('0'), ...pb];
  if (all.length !== 8 || (pb !== null && pa.length + pb.length > 7)) return null;
  if (all.some((g) => !/^[0-9a-f]{1,4}$/i.test(g))) return null;
  return all.map((g) => parseInt(g, 16));
}

/**
 * IP-Adresse lesen. Erlaubt: 192.168.1.20, fd00::5, [fd00::5], auch mit Port (192.168.1.20:8080, [fd00::5]:8443)
 * und mit vorangestelltem http:// oder https://. Ergebnis: { ok, kind:'v4'|'v6', host, port?, scheme?, message }
 */
export function parseIp(raw) {
  let s = String(raw || '').trim();
  if (!s) return { ok: false, reason: 'empty', message: 'Bitte eine IP-Adresse eingeben.' };
  let scheme;
  const sm = /^(https?):\/\//i.exec(s);
  if (sm) { scheme = sm[1].toLowerCase(); s = s.slice(sm[0].length); }
  s = s.replace(/\/+$/, '');
  if (s.includes('/')) return { ok: false, reason: 'bad_ip', message: 'Bitte nur die IP-Adresse eingeben (ohne Pfad).' };
  let port;
  let host = s;
  const br = /^\[([^\]]+)\](?::(\d+))?$/.exec(s);
  if (br) { host = br[1]; port = br[2]; } else if (/^[\d.]+:\d+$/.test(s)) { [host, port] = s.split(':'); }
  if (v4(host)) return { ok: true, kind: 'v4', host, port: port ? Number(port) : undefined, scheme };
  const g = v6(host);
  if (g) return { ok: true, kind: 'v6', host: compress6(g), port: port ? Number(port) : undefined, scheme };
  if (/^[a-z0-9.-]+$/i.test(host) && /[a-z]/i.test(host)) {
    return { ok: false, reason: 'is_domain', message: 'Das ist ein Name, keine IP-Adresse – dafür „HTTPS-Adresse (Domain)“ wählen.' };
  }
  return { ok: false, reason: 'bad_ip', message: 'IP-Adresse ist ungültig (z. B. 192.168.1.20 oder fd00::5).' };
}

/** IPv6 in Kurzform (RFC 5952) */
function compress6(g) {
  let best = [-1, 0], cur = [-1, 0];
  g.forEach((x, i) => {
    if (x === 0) { if (cur[0] < 0) cur = [i, 1]; else cur[1]++; if (cur[1] > best[1]) best = [...cur]; } else cur = [-1, 0];
  });
  const hex = g.map((x) => x.toString(16));
  if (best[1] < 2) return hex.join(':');
  const left = hex.slice(0, best[0]).join(':');
  const right = hex.slice(best[0] + best[1]).join(':');
  return `${left}::${right}`;
}

/**
 * Privates bzw. lokales Netz? 10/8, 172.16/12, 192.168/16, 127/8, 169.254/16 (link-local),
 * ::1, fc00::/7 (ULA, enthält fd00::/8), fe80::/10, sowie „localhost“.
 */
export function isPrivateHost(host) {
  const h = String(host || '').replace(/^\[|\]$/g, '').toLowerCase();
  if (h === 'localhost') return true;
  const a = v4(h);
  if (a) {
    return a[0] === 10 || a[0] === 127 || (a[0] === 172 && a[1] >= 16 && a[1] <= 31)
      || (a[0] === 192 && a[1] === 168) || (a[0] === 169 && a[1] === 254);
  }
  const g = v6(h);
  if (g) {
    if (g.every((x, i) => (i < 7 ? x === 0 : x === 1))) return true; // ::1
    if (g.slice(0, 5).every((x) => x === 0) && g[5] === 0xffff) { // ::ffff:a.b.c.d
      return isPrivateHost(`${g[6] >> 8}.${g[6] & 255}.${g[7] >> 8}.${g[7] & 255}`);
    }
    return (g[0] & 0xfe00) === 0xfc00 || (g[0] & 0xffc0) === 0xfe80;
  }
  return false;
}
export const isIpHost = (host) => !!(v4(String(host || '')) || v6(String(host || '').replace(/^\[|\]$/g, '')));

const fmtHost = (host) => (v6(host) ? `[${host}]` : host);
/** Schlüssel für gemerkte Fingerabdrücke und http-Freigaben: host:port (IPv6 in Klammern). */
export const hostPort = (host, port) => `${fmtHost(host)}:${port}`;

/** Fingerabdruck normalisieren (Hex ohne Trennzeichen, klein) bzw. lesbar formatieren (AB:CD:…). */
export const normFp = (fp) => String(fp || '').replace(/[^0-9a-f]/gi, '').toLowerCase();
export const fmtFp = (fp) => (normFp(fp).match(/../g) || []).join(':').toUpperCase();

/** Domain-Adresse prüfen; fehlt das Schema, wird https:// ergänzt. */
export function checkDomainUrl(raw) {
  let v = String(raw || '').trim();
  if (!v) return { ok: false, reason: 'empty', message: '' };
  let added = false;
  if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(v)) { v = `https://${v}`; added = true; }
  let u;
  try { u = new URL(v); } catch { return { ok: false, reason: 'bad_url', message: 'Adresse ist ungültig, z. B. https://server.firma.de' }; }
  const host = u.hostname.replace(/^\[|\]$/g, '');
  const local = ['localhost', '127.0.0.1', '::1'].includes(host);
  if (u.protocol !== 'https:' && !(u.protocol === 'http:' && local)) {
    return { ok: false, reason: 'insecure', message: isIpHost(host)
      ? 'Unverschlüsselt (http) mit IP-Adresse: bitte „IP-Verbindung“ wählen – nur im lokalen Netz möglich.'
      : 'Nur https:// ist erlaubt.' };
  }
  if (u.username || u.password || u.search || u.hash) return { ok: false, reason: 'bad_url', message: 'Adresse ohne Zugangsdaten, ? oder # eingeben.' };
  const port = Number(u.port) || (u.protocol === 'https:' ? 443 : 80);
  return { ok: true, url: `${u.origin}${u.pathname}`.replace(/\/+$/, ''), host, port, scheme: u.protocol.slice(0, -1), added };
}

/**
 * Verwendeten Server aus den Einstellungen bestimmen.
 * Ergebnis: { ok, mode, url, scheme, host, port, hp, ip, private, pin, label, reason, message }
 *   reason bei !ok: empty | bad_url | insecure | bad_ip | is_domain | bad_port | http_public | http_confirm
 */
export function resolveEndpoint(s = {}) {
  const pins = s.serverPins || {};
  if ((s.serverMode || 'https') !== 'ip') {
    const c = checkDomainUrl(s.serverUrl);
    if (!c.ok) return { ...c, mode: 'https' };
    const hp = hostPort(c.host, c.port);
    return { ok: true, mode: 'https', url: c.url, scheme: c.scheme, host: c.host, port: c.port, hp, ip: isIpHost(c.host),
      private: isPrivateHost(c.host), pin: c.scheme === 'https' ? normFp(pins[hp]) : '', label: 'HTTPS-Adresse (Domain)', added: c.added };
  }
  const ip = s.serverIp || {};
  const p = parseIp(ip.host);
  if (!p.ok) return { ...p, mode: 'ip' };
  const scheme = (ip.scheme === 'http' ? 'http' : 'https');
  const portRaw = String(ip.port ?? '').trim();
  const port = portRaw === '' ? (p.port || (scheme === 'https' ? 443 : 80)) : Number(portRaw);
  if (!Number.isInteger(port) || port < 1 || port > 65535) return { ok: false, mode: 'ip', reason: 'bad_port', message: 'Port muss zwischen 1 und 65535 liegen.' };
  const hp = hostPort(p.host, port);
  const priv = isPrivateHost(p.host);
  const base = { mode: 'ip', scheme, host: p.host, port, hp, ip: true, private: priv,
    url: `${scheme}://${fmtHost(p.host)}${(scheme === 'https' && port === 443) || (scheme === 'http' && port === 80) ? '' : `:${port}`}`,
    label: `IP-Verbindung (${scheme === 'https' ? 'verschlüsselt' : 'unverschlüsselt'})` };
  if (scheme === 'http') {
    if (!priv) return { ...base, ok: false, reason: 'http_public', message: 'Unverschlüsselt (http) nur im lokalen Netz (10.x, 172.16–31.x, 192.168.x, fd00::/8). Für öffentliche IP-Adressen bitte „Verschlüsselt (https)“ wählen.' };
    if (ip.httpConfirmed !== hp) return { ...base, ok: false, reason: 'http_confirm', message: 'Unverschlüsselte Verbindung muss erst bestätigt werden.' };
    return { ...base, ok: true, pin: '' };
  }
  return { ...base, ok: true, pin: normFp(pins[hp]) };
}
