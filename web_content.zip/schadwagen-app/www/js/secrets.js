// Sichere Ablage für API-Token und Sitzung – nie in den Einstellungen, PDFs oder Logdateien.
// Android: Android-Schlüsselspeicher (AES-GCM) · Windows: DPAPI des angemeldeten Benutzers ·
// Browser/PWA: nur Browser-Speicher (kein Betriebssystemschutz verfügbar).
import { isAndroidApp, isDesktop, desktopPost } from './platform.js';

const NAMES = ['apiToken', 'sessionToken'];
const cache = {};
const android = window.AndroidBridge;
const hasAndroidStore = isAndroidApp && typeof android.secretGet === 'function';
const LS = 'sw.secret.';

export function secretStorageKind() {
  if (hasAndroidStore) return 'Android-Schlüsselspeicher';
  if (isDesktop) return 'Windows-Datenschutz (DPAPI)';
  return 'Browser-Speicher dieses Geräts';
}

export async function loadSecrets() {
  for (const n of NAMES) {
    try {
      if (hasAndroidStore) cache[n] = android.secretGet(n) || '';
      else if (isDesktop) cache[n] = (await desktopPost('/__secret', { op: 'get', name: n }))?.value || '';
      else cache[n] = localStorage.getItem(LS + n) || '';
    } catch { cache[n] = cache[n] || ''; }
  }
  return cache;
}

export const getSecret = (n) => cache[n] || '';

export async function setSecret(n, value) {
  const v = String(value || '');
  cache[n] = v;
  if (hasAndroidStore) { android.secretSet(n, v); return; }
  if (isDesktop) { await desktopPost('/__secret', { op: 'set', name: n }, v); return; }
  try { if (v) localStorage.setItem(LS + n, v); else localStorage.removeItem(LS + n); } catch { /* Speicher gesperrt */ }
}
