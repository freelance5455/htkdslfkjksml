// Mitarbeiter, Berechtigungen, PIN und Zuordnung der Protokolle.
// Ohne Anmeldung am Server sind die Berechtigungen eine Bedienhilfe; die PIN schützt das
// Umschalten auf einen anderen Mitarbeiter (gespeichert wird nur ein gesalzener Hash).

export const PERMS = [
  ['create', 'Protokolle erstellen'],
  ['edit', 'Protokolle bearbeiten'],
  ['delete', 'Protokolle löschen'],
  ['share', 'PDFs teilen und speichern'],
  ['folders', 'Ordner verwalten'],
  ['trash', 'Papierkorb leeren'],
  ['settings', 'Einstellungen ändern'],
  ['server', 'Server-Verbindung verwalten'],
  ['employees', 'Mitarbeiter verwalten'],
];
const all = (v) => Object.fromEntries(PERMS.map(([k]) => [k, v]));
export const TEMPLATES = {
  admin: { label: 'Administrator', perms: all(true) },
  editor: { label: 'Bearbeiter', perms: { ...all(false), create: true, edit: true, delete: true, share: true, folders: true } },
  reader: { label: 'Nur Lesen', perms: all(false) },
};
export const TITLES = ['Wagenmeister', 'Wagenprüfer', 'Disponent', 'Triebfahrzeugführer', 'Rangierbegleiter', 'Teamleiter', 'Betriebsleiter'];

export const fullName = (e) => (e ? `${e.firstName || ''} ${e.lastName || ''}`.trim() || 'Ohne Namen' : '');
export const initials = (e) => {
  const s = `${(e.firstName || '').trim()[0] || ''}${(e.lastName || '').trim()[0] || ''}`.toUpperCase();
  return s || '?';
};
export const normPrefix = (p) => String(p || '').trim().replace(/\/+$/, '').replace(/\s+/g, '').toUpperCase();
/** Recht lesen; „Ordner verwalten“ gab es früher nicht -> wie „Protokolle bearbeiten“. */
export const hasPerm = (perms, k) => (k === 'folders' && perms && !('folders' in perms) ? !!perms.edit : !!(perms && perms[k]));
export const roleOf = (perms) => Object.entries(TEMPLATES).find(([, t]) => PERMS.every(([k]) => !!t.perms[k] === hasPerm(perms, k)))?.[0] || 'custom';
export const roleLabel = (e) => (TEMPLATES[roleOf(e.perms || {})]?.label || 'Eigene Rechte');

export const listEmployees = (s) => (s.employees || []).filter((e) => !e.deleted);
export const activeList = (s) => listEmployees(s).filter((e) => e.active !== false);
export const findEmployee = (s, id) => listEmployees(s).find((e) => e.id === id) || null;

// Beim Programmstart mit PIN: entsperrt ist nur, wer in dieser Sitzung die PIN eingegeben hat.
let unlockedId = null;
export function markUnlocked(id) { unlockedId = id; }

export function activeEmployee(s) {
  const e = findEmployee(s, s.activeEmployeeId);
  if (!e || e.active === false) return null;
  if (s.pinOnStart !== false && unlockedId !== e.id) return null;
  return e;
}
export const hasEmployees = (s) => listEmployees(s).length > 0;

/** Darf der aktive Mitarbeiter das? Ohne angelegte Mitarbeiter ist alles erlaubt (wie bisher). */
export function can(s, perm) {
  if (!hasEmployees(s)) return true;
  const e = activeEmployee(s);
  return !!(e && hasPerm(e.perms, perm));
}
/** Erstellen oder bearbeiten – je nachdem, ob das Protokoll schon eine Nummer hat. */
export const canEditReport = (s, r) => can(s, r && r.numberUsed ? 'edit' : 'create');

export function prefixTaken(s, prefix, exceptId) {
  const p = normPrefix(prefix);
  return !!p && listEmployees(s).some((e) => e.id !== exceptId && normPrefix(e.prefix) === p);
}

/** Verwaltungsrecht bleibt erhalten: mindestens ein aktiver Mitarbeiter mit „Mitarbeiter verwalten“. */
export function wouldLoseAdmin(s, changed) {
  const list = listEmployees(s).map((e) => (e.id === changed.id ? changed : e)).filter((e) => !e.deleted);
  return !list.some((e) => e.active !== false && e.perms && e.perms.employees);
}

/* ---------- PIN ---------- */

export const validPin = (p) => /^\d{4,8}$/.test(String(p || ''));
const toHex = (buf) => [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');

export function newSalt() {
  const a = new Uint8Array(16);
  crypto.getRandomValues(a);
  return toHex(a);
}
export async function hashPin(pin, salt) {
  const data = new TextEncoder().encode(`${salt}:${pin}`);
  if (crypto.subtle) {
    // 20 000 Runden PBKDF2 – erschwert Durchprobieren, bleibt auf dem Handy schnell
    const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(String(pin)), 'PBKDF2', false, ['deriveBits']);
    const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt: new TextEncoder().encode(salt), iterations: 20000 }, key, 256);
    return `p2:${toHex(bits)}`;
  }
  return `s1:${sha256Hex(data)}`;
}
export async function verifyPin(e, pin) {
  if (!e || !e.pinHash || !e.pinSalt) return false;
  const h = await hashPin(pin, e.pinSalt);
  if (h.slice(0, 3) !== e.pinHash.slice(0, 3)) {
    // Hash wurde auf einem Gerät mit anderer Verfahrensunterstützung erzeugt
    if (e.pinHash.startsWith('s1:')) return `s1:${sha256Hex(new TextEncoder().encode(`${e.pinSalt}:${pin}`))}` === e.pinHash;
    return false;
  }
  return h === e.pinHash;
}

// Fehlversuche: nach 5 falschen PINs 30 Sekunden Sperre
const fails = new Map();
export function pinLockedFor(id) {
  const f = fails.get(id);
  if (!f || f.n < 5) return 0;
  const left = 30000 - (Date.now() - f.at);
  if (left <= 0) { fails.delete(id); return 0; }
  return Math.ceil(left / 1000);
}
export function pinFailed(id) { const f = fails.get(id) || { n: 0, at: 0 }; f.n++; f.at = Date.now(); fails.set(id, f); }
export function pinOk(id) { fails.delete(id); }

/* ---------- Zuordnung ---------- */

/** Präfix aus der Protokollnummer: „B13H09/316“ -> „B13H09“, „B13H09-316“ -> „B13H09“ */
export function prefixOfReportId(reportId) {
  const s = String(reportId || '').trim();
  if (!s) return '';
  if (s.includes('/')) return normPrefix(s.slice(0, s.lastIndexOf('/')));
  return normPrefix(s.replace(/[-_ ]?\d+$/, ''));
}
export function numberOfReportId(reportId) {
  const m = /(\d+)\s*$/.exec(String(reportId || ''));
  return m ? parseInt(m[1], 10) : 0;
}
const normName = (n) => String(n || '').toLowerCase().replace(/\s+/g, ' ').trim();

/**
 * Wer hat das Protokoll erstellt? Reihenfolge: gespeicherte Zuordnung, Präfix der
 * Protokollnummer, Name (Ersteller bzw. Kontakt). Ergebnis: { employee, via } oder { employee: null }.
 */
export function ownerOf(report, s) {
  const list = listEmployees(s);
  if (!report) return { employee: null };
  const cb = report.createdBy;
  if (cb && cb.id) {
    const e = list.find((x) => x.id === cb.id);
    if (e) return { employee: e, via: 'id' };
  }
  const p = prefixOfReportId(report.numberUsed || report.status === 'erstellt' ? report.reportId : '');
  if (p) {
    const e = list.find((x) => normPrefix(x.prefix) === p);
    if (e) return { employee: e, via: 'prefix' };
  }
  for (const n of [cb && cb.name, report.contactName]) {
    const nn = normName(n);
    if (!nn) continue;
    const e = list.find((x) => normName(fullName(x)) === nn || normName(`${x.lastName} ${x.firstName}`) === nn);
    if (e) return { employee: e, via: 'name' };
  }
  return { employee: null, name: cb && cb.name };
}
export function ownerLabel(report, s) {
  const { employee, name } = ownerOf(report, s);
  if (employee) return `Erstellt von ${fullName(employee)}${employee.prefix ? ` (${normPrefix(employee.prefix)})` : ''}`;
  if (name) return `Erstellt von ${name} (nicht zugeordnet)`;
  return 'Nicht zugeordnet';
}
export const createdByOf = (e) => ({ id: e.id, name: fullName(e), prefix: normPrefix(e.prefix), at: new Date().toISOString() });

/** Höchste schon vergebene Nummer zu einem Präfix in den vorhandenen Protokollen. */
export function maxUsedNumber(prefix, reports) {
  const p = normPrefix(prefix);
  let max = 0;
  for (const r of reports) {
    if (!r || !r.reportId || !(r.numberUsed || r.status === 'erstellt')) continue;
    if (prefixOfReportId(r.reportId) === p) max = Math.max(max, numberOfReportId(r.reportId));
  }
  return max;
}

/** Abgleich zweier Listen: je ID gewinnt der neueste Stand, die laufende Nummer sinkt nie. */
export function mergeEmployees(a = [], b = []) {
  const map = new Map();
  for (const e of [...a, ...b]) {
    if (!e || !e.id) continue;
    const old = map.get(e.id);
    if (!old) { map.set(e.id, { ...e }); continue; }
    const win = (e.updatedAt || '') > (old.updatedAt || '') ? { ...e } : old;
    win.nextNumber = Math.max(Number(old.nextNumber) || 1, Number(e.nextNumber) || 1);
    map.set(e.id, win);
  }
  return [...map.values()];
}

/* ---------- SHA-256 (Rückfallebene ohne WebCrypto) ---------- */
function sha256Hex(bytes) {
  const K = [0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2];
  const H = [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19];
  const l = bytes.length;
  const n = ((l + 9 + 63) >> 6) << 6;
  const m = new Uint8Array(n);
  m.set(bytes); m[l] = 0x80;
  const dv = new DataView(m.buffer);
  dv.setUint32(n - 4, l * 8); dv.setUint32(n - 8, Math.floor(l / 0x20000000));
  const w = new Uint32Array(64);
  const r = (x, k) => (x >>> k) | (x << (32 - k));
  for (let o = 0; o < n; o += 64) {
    for (let i = 0; i < 16; i++) w[i] = dv.getUint32(o + i * 4);
    for (let i = 16; i < 64; i++) {
      const s0 = r(w[i - 15], 7) ^ r(w[i - 15], 18) ^ (w[i - 15] >>> 3);
      const s1 = r(w[i - 2], 17) ^ r(w[i - 2], 19) ^ (w[i - 2] >>> 10);
      w[i] = (w[i - 16] + s0 + w[i - 7] + s1) | 0;
    }
    let [a, b, c, d, e, f, g, hh] = H;
    for (let i = 0; i < 64; i++) {
      const t1 = (hh + (r(e, 6) ^ r(e, 11) ^ r(e, 25)) + ((e & f) ^ (~e & g)) + K[i] + w[i]) | 0;
      const t2 = ((r(a, 2) ^ r(a, 13) ^ r(a, 22)) + ((a & b) ^ (a & c) ^ (b & c))) | 0;
      hh = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b; b = a; a = (t1 + t2) | 0;
    }
    H[0] = (H[0] + a) | 0; H[1] = (H[1] + b) | 0; H[2] = (H[2] + c) | 0; H[3] = (H[3] + d) | 0;
    H[4] = (H[4] + e) | 0; H[5] = (H[5] + f) | 0; H[6] = (H[6] + g) | 0; H[7] = (H[7] + hh) | 0;
  }
  return H.map((x) => (x >>> 0).toString(16).padStart(8, '0')).join('');
}
export const _sha256Hex = sha256Hex; // für Tests
