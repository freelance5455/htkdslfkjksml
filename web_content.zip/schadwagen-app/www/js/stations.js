// Betriebsstellen (Ril 100): Suche nach Abkürzung oder Name
import DATA from '../data/betriebsstellen.js';

const norm = (s) => String(s || '').toLowerCase()
  .replace(/ä/g, 'ae').replace(/ö/g, 'oe').replace(/ü/g, 'ue').replace(/ß/g, 'ss');
const compact = (s) => String(s || '').toUpperCase().replace(/\s+/g, '');

export const stations = DATA.map(([code, name, typ, zustand]) => ({
  code, name, typ, zustand,
  key: compact(code),
  n: norm(name),
  active: zustand === 'Betrieb' || zustand === '',
}));
const exact = new Map(stations.map((s) => [s.code.toUpperCase(), s]));
const single = new Map(stations.map((s) => [s.code.toUpperCase().replace(/\s+/g, ' '), s]));
const compactMap = new Map();
for (const s of stations) { const l = compactMap.get(s.key) || []; l.push(s); compactMap.set(s.key, l); }
const TYPE_RANK = { Bf: 0, Bft: 1, 'NE-Bf': 2, Hp: 3, 'NE-Hp': 4 };
const typeRank = (t) => TYPE_RANK[t] ?? 5;

/** Abkürzung -> Betriebsstelle ("mbuh", "AA  G", "AA G"); ohne Leerzeichen nur, wenn eindeutig */
export function byCode(q) {
  const u = String(q || '').trim().toUpperCase();
  if (!u) return null;
  const hit = exact.get(u) || single.get(u.replace(/\s+/g, ' '));
  if (hit) return hit;
  const l = compactMap.get(compact(u));
  return l && l.length === 1 ? l[0] : null;
}

export function searchStations(query, limit = 30) {
  const q = String(query || '').trim();
  if (q.length < 2) {
    const exact = q ? byCode(q) : null;
    return exact ? [exact] : [];
  }
  const k = compact(q);
  const n = norm(q);
  const words = n.split(/[\s,()-]+/).filter(Boolean);
  let scored = [];
  for (const s of stations) {
    let score = -1;
    if (s.key === k || s.code.toUpperCase() === q.toUpperCase()) score = 0;
    else if (s.n === n) score = 1;
    else if (s.n.startsWith(n)) score = 2;
    else if (k.length <= 5 && s.key.startsWith(k)) score = 3;
    else if (words.every((w) => s.n.includes(w))) score = 4;
    if (score < 0) continue;
    if (!s.active) score += 10;
    scored.push([score, s]);
  }
  // Bei eindeutiger Abkürzung keine Zufallstreffer im Namen (z. B. NNEH -> "WanNEHain")
  if (scored.some(([sc]) => sc === 0)) scored = scored.filter(([sc]) => sc % 10 !== 4);
  scored.sort((a, b) => a[0] - b[0] || typeRank(a[1].typ) - typeRank(b[1].typ) || a[1].name.length - b[1].name.length || a[1].name.localeCompare(b[1].name, 'de'));
  return scored.slice(0, limit).map((x) => x[1]);
}
