// Zugriff auf die Schadcode-Datenbank (AVV Anlage 9, Anhang 1)
import DB from '../data/schadcodes.js';

export const db = DB;
export const categories = DB.kategorien;
export const byCode = new Map(DB.codes.map((c) => [c.code, c]));
export const selectable = DB.codes.filter((c) => c.auswaehlbar);

const norm = (s) => String(s || '').toLowerCase()
  .replace(/ä/g, 'ae').replace(/ö/g, 'oe').replace(/ü/g, 'ue').replace(/ß/g, 'ss');
const haystack = new Map(selectable.map((c) => [c.code, norm(`${c.titel} ${c.komponente} ${c.pfad.join(' ')} ${c.kriterien.join(' ')}`)]));

export const lookup = (code) => byCode.get(code);
export const isSelectable = (code) => !!byCode.get(code)?.auswaehlbar;

const dotless = (c) => c.replace(/\./g, '');
const byDotless = new Map();
for (const c of selectable) { const k = dotless(c.code); byDotless.set(k, [...(byDotless.get(k) || []), c]); }

/** Eingabe -> gültiger Code: "5.2.3.1", "5,2,3,1" oder ohne Punkte "5231" (wenn eindeutig). */
export function resolveCode(input) {
  const q = String(input || '').trim().replace(/,/g, '.').replace(/\.+$/, '');
  if (!q) return '';
  if (isSelectable(q)) return q;
  if (/^\d+$/.test(q)) {
    const hits = byDotless.get(q) || [];
    if (hits.length === 1) return hits[0].code;
  }
  return '';
}
export const categoryName = (nr) => categories.find((k) => String(k.nr) === String(nr))?.name || '';

/** Suche: Ziffern/Punkte -> Präfix auf den Code, sonst Volltext (alle Wörter müssen vorkommen). */
export function search(query, { category = null, limit = 40 } = {}) {
  const q = String(query || '').trim();
  let list = category ? selectable.filter((c) => String(c.kategorie) === String(category)) : selectable;
  if (!q) return list.slice(0, limit);
  if (/^\d+$/.test(q)) {
    // Ziffern ohne Punkte: "5231" findet 5.2.3.1, "52" alle Codes 5.2.x
    const hits = list.filter((c) => dotless(c.code).startsWith(q) || c.code === q || c.code.startsWith(q + '.'));
    hits.sort((a, b) => (dotless(b.code) === q) - (dotless(a.code) === q));
    return hits.slice(0, limit);
  }
  if (/^[\d.]+$/.test(q)) {
    const p = q.replace(/\.+$/, '');
    list = list.filter((c) => c.code === p || c.code.startsWith(p + '.') || (q.endsWith('.') ? false : c.code.startsWith(q)));
    return list.slice(0, limit);
  }
  const words = norm(q).split(/\s+/).filter(Boolean);
  return list.filter((c) => words.every((w) => haystack.get(c.code).includes(w))).slice(0, limit);
}

/** Alle Einträge einer Kategorie in Katalogreihenfolge (inkl. Überschriften). */
export const categoryEntries = (nr) => DB.codes.filter((c) => String(c.kategorie) === String(nr) && c.ebene > 1);

/** Unterkategorien (2. Gliederungsebene) für "kein passender Schadcode". */
export const subCategories = (nr) => DB.codes.filter((c) => String(c.kategorie) === String(nr) && c.ebene === 2);

export function klassChip(k) {
  return k ? { cls: `chip k${k}`, text: `Fehlerklasse ${k}` } : null;
}
