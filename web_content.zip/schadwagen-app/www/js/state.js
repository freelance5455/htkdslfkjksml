// Datenmodell, Standardwerte und Einstellungen
import { isDesktop, desktopLoadSettings, desktopSaveSettings } from './platform.js';
import { activeEmployee, normPrefix, mergeEmployees } from './employees.js';
import { mergeFolders } from './folders.js';

/** Stand der Oberfläche – wird in den Einstellungen angezeigt (hilft beim Erkennen alter Versionen). */
export const APP_VERSION = '2026.10.25-14';

export const LABELS = ['K', 'M', 'I', 'R1', 'U'];

export const DEFAULT_SETTINGS = {
  evuNr: '3840',
  evuName: 'Dispo Tf - Rail GmbH',
  contactName: 'Dispo-Tf Rail GmbH',
  contactEmail: 'schadwagen@dispotf.de',
  contactPhone: '',
  reportPrefix: '',
  nextNumber: 1,
  flatten: true,
  design: 'hell', // 'hell' | 'dunkel' | 'system'
  extendedMode: false, // Erweiterter Modus (Dashboard)
  serverUrl: '', // gemeinsame Server-Verbindung (https://…); API-Token liegt in der sicheren Ablage
  employees: [], // Mitarbeiter (siehe employees.js)
  activeEmployeeId: '',
  pinOnStart: true, // PIN beim Programmstart abfragen
};

const SETTINGS_KEY = 'sw.settings.v1';

export function loadSettings() {
  try {
    const s = JSON.parse(localStorage.getItem(SETTINGS_KEY) || 'null');
    return { ...DEFAULT_SETTINGS, ...(s || {}) };
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}
export function saveSettings(s) {
  s.savedAt = Date.now();
  try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(s)); } catch { /* Speicher nicht verfügbar */ }
  // Windows-Programm: zusätzlich als Datei sichern (übersteht auch ein hartes Beenden des Browsers)
  if (isDesktop) desktopSaveSettings(s).catch(() => {});
}

/** Windows-Programm: Einstellungen mit der Datei abgleichen; laufende Nummer nie zurücksetzen. */
export async function syncSettings(local) {
  if (!isDesktop) return local;
  try {
    const remote = await desktopLoadSettings();
    const base = remote && (remote.savedAt || 0) > (local.savedAt || 0) ? { ...local, ...remote } : { ...local };
    base.nextNumber = Math.max(Number(local.nextNumber) || 1, Number(remote?.nextNumber) || 1);
    base.employees = mergeEmployees(local.employees || [], remote?.employees || []);
    base.folders = mergeFolders(local.folders || [], remote?.folders || []);
    saveSettings(base);
    return base;
  } catch {
    return local;
  }
}

// Darstellung: hell (Tageslicht), dunkel (Nachtschicht) oder wie das System
const darkQuery = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;
export function applyDesign(mode) {
  const dark = mode === 'dunkel' || mode === 'nacht' || (mode === 'system' && darkQuery && darkQuery.matches);
  const root = document.documentElement;
  root.dataset.design = dark ? 'nacht' : 'tag';
  const meta = document.querySelector('meta[name=theme-color]');
  if (meta) meta.content = dark ? '#13171c' : '#eceff2';
}
let currentMode = 'hell';
export function setDesign(mode) { currentMode = mode || 'hell'; applyDesign(currentMode); }
if (darkQuery && darkQuery.addEventListener) darkQuery.addEventListener('change', () => { if (currentMode === 'system') applyDesign('system'); });

export function today() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

/** Protokoll-Nr.: Präfix + laufende Nummer des aktiven Mitarbeiters, sonst aus den Einstellungen. */
export function formatReportId(settings) {
  const e = activeEmployee(settings);
  if (e) return `${normPrefix(e.prefix)}${normPrefix(e.prefix) ? '/' : ''}${Number(e.nextNumber) || 1}`;
  const n = String(settings.nextNumber || 1);
  const p = String(settings.reportPrefix || '').trim();
  if (!p) return n;
  return p.endsWith('/') ? `${p}${n}` : `${p}/${n}`;
}

export const newDamage = () => ({ code: '', remark: '', old: false, noCode: false, customCategory: '', customSub: '', customText: '' });

export function newReport(settings) {
  const now = new Date().toISOString();
  return {
    id: (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random().toString(16).slice(2)),
    createdAt: now, updatedAt: now, status: 'entwurf', numberUsed: false,
    reportId: formatReportId(settings),
    wagonNumber: '', trainNumber: '', consignmentNumber: '',
    detectionPlace: '', detectionPlaceCode: '', detectionDate: today(),
    origin: '', originCode: '', destination: '', destinationCode: '', departureDate: today(),
    loadingStatus: '',
    keeperVkm: '', keeperName: '', keeperAddress: '', keeperEmail: '',
    damages: [newDamage()],
    existingLabels: {}, existingDate: '', existingRuNr: '', existingRuName: '',
    newLabels: {}, wagonDetached: false, workshop: '',
    takeover: '', takeoverNr: '', takeoverName: '',
    cause: '', perpetrator: '',
    contactName: settings.contactName, contactEmail: settings.contactEmail, contactPhone: settings.contactPhone,
    remarks: '',
    attachments: false,
    photos: [],
  };
}
