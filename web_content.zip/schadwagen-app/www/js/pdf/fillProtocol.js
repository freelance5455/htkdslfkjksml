// Befüllt die GCU-Grunddatei (AcroForm) mit den Protokolldaten.
// Erwartet pdf-lib als globales Objekt `PDFLib` (www/vendor/pdf-lib.min.js).

import { formatWagonNumber } from '../wagon.js';

const LABELS = ['K', 'M', 'I', 'R1', 'U'];
export const EMBED_KEY = 'SchadwagenProtokoll';

const CAUSE = { third: 'ThirdParty', wear: 'Wear', own: 'ImpactDamage', unknown: 'NotAscertainable' };
const TAKEOVER = { avv: 'GCUsignatoryRU', nonavv: 'NonGCUsignatoryRU', siding: 'NonRU' };
const WORKSHOP = { before: 'BeforeUnloading', after: 'AfterUnloading' };

export function formatDate(iso) {
  if (!iso) return '';
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso);
  return m ? `${m[3]}.${m[2]}.${m[1]}` : iso;
}

/** Ziffernfelder für einen Schadcode, z. B. "6.5.2.10" -> ["6","5","2","10"] */
export function codeDigits(code) {
  const s = String(code || '').split('.').filter(Boolean);
  return [s[0] || '', s[1] || '', s[2] || '', s[3] || ''];
}

export function damageDescription(d, codeInfo) {
  const remark = (d.remark || '').trim();
  if (d.noCode) {
    const base = (d.customText || '').trim();
    return remark ? `${base} (${remark})` : base;
  }
  if (remark) return remark;
  return codeInfo ? codeInfo.kurztext : '';
}

function contactBlock(r) {
  return [r.contactName, r.contactEmail, r.contactPhone ? `Tel. ${r.contactPhone}` : '']
    .map((s) => (s || '').trim()).filter(Boolean).join('\n');
}

/**
 * @param {object} report    Protokolldaten (siehe state.js)
 * @param {object} settings  Einstellungen (EVU-Nr., Name …)
 * @param {object} opts      { templateBytes, lookup(code)->codeInfo, photos:[{bytes,type,name}], flatten }
 * @returns {Promise<Uint8Array>}
 */
export async function fillProtocol(report, settings, opts) {
  const { PDFDocument, StandardFonts, PDFName } = globalThis.PDFLib;
  const doc = await PDFDocument.load(opts.templateBytes);
  const form = doc.getForm();
  const font = await doc.embedFont(StandardFonts.Helvetica);
  const charset = new Set(font.getCharacterSet());

  const clean = (v) => {
    let s = String(v ?? '')
      .replace(/\r\n?/g, '\n')
      .replace(/⚫/g, '•').replace(/≤/g, '<=').replace(/≥/g, '>=').replace(/≠/g, '<>')
      .replace(/[⁰¹²³⁴⁵⁶⁷⁸⁹]+⁾/g, '');
    return [...s].map((ch) => (ch === '\n' || charset.has(ch.codePointAt(0)) ? ch : '?')).join('');
  };

  const text = (name, value, { fontSize } = {}) => {
    const f = form.getTextField(name);
    let v = clean(value);
    const max = f.getMaxLength();
    if (max !== undefined && v.length > max) {
      if (max <= 2) f.setMaxLength(undefined); else v = v.slice(0, max);
    }
    f.setText(v || undefined);
    if (fontSize) f.setFontSize(fontSize);
  };
  // Optionsgruppen sind in der Vorlage teils als Radio-, teils als Checkbox-Gruppen angelegt:
  // Zustand daher direkt über /V und /AS der Widgets setzen.
  const radio = (name, value) => {
    if (!value) return;
    const acro = form.getField(name).acroField;
    const on = PDFName.of(value);
    let found = false;
    for (const w of acro.getWidgets()) {
      const states = w.getOnValue && w.getOnValue();
      const match = states && states.toString() === on.toString();
      w.setAppearanceState(match ? on : PDFName.of('Off'));
      found = found || match;
    }
    if (!found) throw new Error(`Option ${value} in ${name} nicht vorhanden`);
    acro.dict.set(PDFName.of('V'), on);
  };
  const check = (name, on) => { if (on) form.getCheckBox(name).check(); };

  // 1. Allgemeine Informationen
  text('UserRU', settings.evuNr);
  text('UserRU_Name', settings.evuName);
  text('ReportID', report.reportId);
  text('ConsignmentNumber', report.consignmentNumber || 'Unbekannt');
  text('OperationalTrainNumber', report.trainNumber);
  text('DamageDetection_Location_PrimaryLocationName', report.detectionPlace);
  text('DetectionDate', formatDate(report.detectionDate));
  text('Origin_PrimaryLocationName', report.origin);
  text('DepartureDate', formatDate(report.departureDate));
  text('Destination_PrimaryLocationName', report.destination);
  radio('LoadingStatus', report.loadingStatus === 'beladen' ? '1' : report.loadingStatus === 'leer' ? '0' : '');
  text('WagonNumberFreight', formatWagonNumber(report.wagonNumber, '-'));
  text('Keeper', report.keeperVkm);
  text('Keeper_Name_or_VKM', report.keeperName);
  text('Keeper_Address_or_Email', [report.keeperAddress, report.keeperEmail].map((x) => (x || '').trim().replace(/\s*\n\s*/g, ', ')).filter(Boolean).join(', '));

  // 2. Beschreibung des Schadens (max. 3)
  (report.damages || []).slice(0, 3).forEach((d, i) => {
    const n = i + 1;
    const code = d.noCode ? [d.customCategory, d.customSub].filter(Boolean).join('.') : d.code;
    if (!code) return;
    const info = d.noCode ? null : opts.lookup(d.code);
    codeDigits(code).forEach((digit, k) => text(`Damage${n}_CodeDigit${k + 1}`, digit));
    radio(`Damage${n}_OldDamage`, d.old ? '1' : '0');
    text(`Damage${n}_Description`, damageDescription(d, info), { fontSize: 8 });
  });
  text('Remarks', report.remarks);

  // 3. Vorgefundene Bezettelung
  LABELS.forEach((l) => check(`ExistingLabels_DamageLabel_${l}`, report.existingLabels?.[l]));
  text('Date', formatDate(report.existingDate));
  text('ReportingRU_Company', report.existingRuNr);
  text('ReportingRU_CompanyName', report.existingRuName);

  // 4. Erfolgte Bezettelung
  LABELS.forEach((l) => check(`NewLabels_DamageLabel_${l}`, report.newLabels?.[l]));
  check('WagonDetached', report.wagonDetached);
  radio('DispatchedToWorkshop', WORKSHOP[report.workshop]);

  // 5. Schadensfeststellung bei der Übernahme
  radio('CompanyType', TAKEOVER[report.takeover]);
  text('HandingOverCompany_Company', report.takeoverNr);
  text('HandingOverCompany_CompanyName', report.takeoverName);

  // 6. Ursache / Verursacher
  radio('DamageCategory', CAUSE[report.cause]);
  if (report.cause === 'third') text('Perpetrator', report.perpetrator);
  text('Signature_PlaceDate', [report.detectionPlace, formatDate(report.detectionDate)].filter(Boolean).join(', '));
  check('Attachments', report.attachments || (opts.photos && opts.photos.length > 0));
  text('ContactUserRU', contactBlock(report));

  form.updateFieldAppearances(font);

  // Anlagen (Fotos) als zusätzliche Seiten
  if (opts.photos && opts.photos.length) {
    const [w, h] = [595.32, 841.92];
    for (let i = 0; i < opts.photos.length; i++) {
      const ph = opts.photos[i];
      const img = /png/i.test(ph.type) ? await doc.embedPng(ph.bytes) : await doc.embedJpg(ph.bytes);
      const page = doc.addPage([w, h]);
      const title = clean(`Anlage ${i + 1} zum Schadensprotokoll ${report.reportId || ''} – Wagen ${formatWagonNumber(report.wagonNumber, ' ')}`);
      page.drawText(title, { x: 50, y: h - 60, size: 12, font });
      if (ph.caption) page.drawText(clean(ph.caption).slice(0, 110), { x: 50, y: h - 78, size: 9, font });
      const maxW = w - 100, maxH = h - 160;
      const s = Math.min(maxW / img.width, maxH / img.height, 1);
      const iw = img.width * s, ih = img.height * s;
      page.drawImage(img, { x: (w - iw) / 2, y: h - 100 - ih, width: iw, height: ih });
    }
  }

  const result = doc;
  if (opts.flatten) {
    form.flatten();
    // Verweise auf entfernte Widgets aus /Annots tilgen
    const { PDFArray } = globalThis.PDFLib;
    for (const page of doc.getPages()) {
      const annots = page.node.Annots();
      if (!annots) continue;
      const keep = annots.asArray().filter((ref) => doc.context.lookup(ref) !== undefined);
      if (keep.length) page.node.set(PDFName.of('Annots'), doc.context.obj(keep));
      else page.node.delete(PDFName.of('Annots'));
    }
    const acro = doc.catalog.lookup(PDFName.of('AcroForm'));
    if (acro) doc.catalog.delete(PDFName.of('AcroForm'));
  }
  result.setTitle(`Schadensprotokoll ${report.reportId || ''} ${formatWagonNumber(report.wagonNumber, ' ')}`.trim());
  result.setCreator('Schadwagen Management');
  const createdAt = new Date(opts.createdAt || report.pdfCreatedAt || Date.now());
  if (!Number.isNaN(createdAt.getTime())) { result.setCreationDate(createdAt); result.setModificationDate(createdAt); }
  result.setProducer('Schadwagen Management');
  // Protokolldaten unsichtbar im Dokument hinterlegen (ohne Fotos), damit die Datei in der App
  // wieder eingelesen und dem Ersteller zugeordnet werden kann. Sichtbarer Inhalt bleibt unverändert.
  if (opts.embedData !== false) {
    const { PDFHexString } = globalThis.PDFLib;
    const data = JSON.parse(JSON.stringify(report));
    delete data.photos; delete data.keeperLookup; delete data.keeperAuto;
    data.pdfCreatedAt = opts.createdAt || data.pdfCreatedAt || new Date().toISOString();
    data.status = 'erstellt';
    if (data.reportId) data.numberUsed = true;
    const info = doc.context.lookup(doc.context.trailerInfo.Info);
    if (info) info.set(PDFName.of(EMBED_KEY), PDFHexString.fromText(JSON.stringify({ format: 'schadwagen-protokoll', version: 1, report: data })));
  }
  return result.save();
}
