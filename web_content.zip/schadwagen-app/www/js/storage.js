// Protokolle (inkl. Fotos) und erstellte PDF-Dateien in IndexedDB;
// Fallback: In-Memory, falls IndexedDB nicht verfügbar ist.

const DB_NAME = 'schadwagen';
const STORE = 'reports';
const PDF_STORE = 'pdfs'; // Archiv der erstellten PDFs (für den Erweiterten Modus)
const CURRENT_KEY = '__current__';
let dbPromise = null;
const memory = { [STORE]: new Map(), [PDF_STORE]: new Map() };

function open() {
  if (!('indexedDB' in window)) return Promise.resolve(null);
  if (!dbPromise) {
    dbPromise = new Promise((resolve) => {
      try {
        const req = indexedDB.open(DB_NAME, 2);
        req.onupgradeneeded = () => {
          const db = req.result;
          if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
          if (!db.objectStoreNames.contains(PDF_STORE)) db.createObjectStore(PDF_STORE);
        };
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => resolve(null);
        req.onblocked = () => resolve(null);
      } catch { resolve(null); }
    });
  }
  return dbPromise;
}

async function tx(store, mode, fn) {
  const db = await open();
  if (!db) return fn(null, memory[store]);
  return new Promise((resolve, reject) => {
    const t = db.transaction(store, mode);
    const s = t.objectStore(store);
    let result;
    Promise.resolve(fn(s)).then((r) => { result = r; });
    t.oncomplete = () => resolve(result);
    t.onerror = () => reject(t.error);
    t.onabort = () => reject(t.error);
  });
}
const reqP = (r) => new Promise((res, rej) => { r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });

async function entries(store) {
  return tx(store, 'readonly', async (s, mem) => {
    if (!s) return [...mem.entries()].map(([k, v]) => ({ k, v }));
    const [keys, vals] = await Promise.all([reqP(s.getAllKeys()), reqP(s.getAll())]);
    return keys.map((k, i) => ({ k, v: vals[i] }));
  });
}

/* ---------- Protokolle ---------- */

export async function putReport(report, key = report.id) {
  const copy = JSON.parse(JSON.stringify(report));
  return tx(STORE, 'readwrite', (s, mem) => (s ? reqP(s.put(copy, key)) : mem.set(key, copy)));
}
export async function getReport(key) {
  return tx(STORE, 'readonly', (s, mem) => (s ? reqP(s.get(key)) : mem.get(key)));
}
export async function deleteReport(key) {
  return tx(STORE, 'readwrite', (s, mem) => (s ? reqP(s.delete(key)) : mem.delete(key)));
}
async function allReports() {
  return (await entries(STORE)).filter((e) => e.k !== CURRENT_KEY).map((e) => e.v).filter(Boolean);
}
export async function listReports() {
  return (await allReports()).filter((r) => !r.deletedAt)
    .sort((a, b) => (b.updatedAt || '').localeCompare(a.updatedAt || ''));
}
export const saveCurrent = (r) => putReport(r, CURRENT_KEY);
export const loadCurrent = () => getReport(CURRENT_KEY);

/* ---------- PDF-Archiv ---------- */

/** Lokales Datum (JJJJ-MM-TT) eines ISO-Zeitstempels */
export function localDay(iso) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

/**
 * Legt eine erstellte PDF ab. Wird dasselbe Protokoll am selben Tag erneut erstellt,
 * ersetzt die neue Datei die vorherige.
 * entry: { createdAt, filename, bytes: Uint8Array, report }
 */
export async function putPdf(entry) {
  const report = JSON.parse(JSON.stringify(entry.report));
  const key = `${report.id}|${localDay(entry.createdAt)}`;
  const rec = {
    key,
    reportUuid: report.id,
    createdAt: entry.createdAt,
    filename: entry.filename,
    reportId: report.reportId || '',
    wagonNumber: report.wagonNumber || '',
    bytes: entry.bytes,
    report,
  };
  return tx(PDF_STORE, 'readwrite', (s, mem) => (s ? reqP(s.put(rec, key)) : mem.set(key, rec)));
}
export async function listPdfs() {
  return (await entries(PDF_STORE)).map((e) => e.v).filter((p) => p && !p.deletedAt)
    .sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
}
export async function deletePdf(key) {
  return tx(PDF_STORE, 'readwrite', (s, mem) => (s ? reqP(s.delete(key)) : mem.delete(key)));
}

/* ---------- Papierkorb ---------- */

export const TRASH_DAYS = 30;
const TOMBSTONES = 'sw.destroyed.v1'; // endgültig gelöschte IDs (nicht erneut vom Server holen)

export function destroyedIds() {
  try { return new Set(JSON.parse(localStorage.getItem(TOMBSTONES) || '[]')); } catch { return new Set(); }
}
function addTombstone(id) {
  const s = destroyedIds(); s.add(id);
  try { localStorage.setItem(TOMBSTONES, JSON.stringify([...s].slice(-2000))); } catch { /* voll */ }
}

async function markPdfs(reportUuid, deletedAt) {
  const pdfs = (await entries(PDF_STORE)).map((e) => e.v).filter((p) => p && p.reportUuid === reportUuid);
  for (const p of pdfs) {
    if (deletedAt) p.deletedAt = deletedAt; else delete p.deletedAt;
    await tx(PDF_STORE, 'readwrite', (st, mem) => (st ? reqP(st.put(p, p.key)) : mem.set(p.key, p)));
  }
}

/** In den Papierkorb verschieben (inkl. der erstellten PDFs). */
export async function trashReport(id, by = '') {
  const r = await getReport(id);
  if (!r) return;
  r.deletedAt = new Date().toISOString();
  if (by) r.deletedBy = by;
  await putReport(r);
  await markPdfs(id, r.deletedAt);
}
export async function restoreReport(id) {
  const r = await getReport(id);
  if (!r) return;
  delete r.deletedAt; delete r.deletedBy;
  await putReport(r);
  await markPdfs(id, null);
}
/** Endgültig löschen. */
export async function destroyReport(id) {
  await deleteReport(id);
  const pdfs = (await entries(PDF_STORE)).map((e) => e.v).filter((p) => p && p.reportUuid === id);
  for (const p of pdfs) await deletePdf(p.key);
  addTombstone(id);
}
export async function listTrash() {
  return (await allReports()).filter((r) => r.deletedAt).sort((a, b) => b.deletedAt.localeCompare(a.deletedAt));
}
/** Einträge älter als 30 Tage automatisch entfernen. */
export async function purgeTrash(days = TRASH_DAYS) {
  const limit = Date.now() - days * 86400000;
  let n = 0;
  for (const r of await listTrash()) {
    if (new Date(r.deletedAt).getTime() < limit) { await destroyReport(r.id); n++; }
  }
  return n;
}
export async function getAnyReport(id) { return getReport(id); }

/**
 * Reparatur früherer Importe: Protokolle, die mit dem Erstelldatum der Vorlage (2018) oder ohne
 * Status „erstellt“ eingelesen wurden, erscheinen sonst nicht im Kalender. Neues Datum:
 * Tag der Schadensfeststellung (12 Uhr), sonst Importzeitpunkt. Liefert die Anzahl.
 */
export async function repairImportDates() {
  const limit = Date.UTC(2021, 0, 1);
  const bad = (iso) => { const t = new Date(iso || NaN).getTime(); return !Number.isFinite(t) || t < limit || t > Date.now() + 86400000; };
  const better = (r) => {
    const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(r.detectionDate || ''));
    if (m) { const d = new Date(+m[1], +m[2] - 1, +m[3], 12); if (!bad(d.toISOString())) return d.toISOString(); }
    return !bad(r.importedAt) ? r.importedAt : new Date().toISOString();
  };
  let n = 0;
  const fixed = new Map();
  for (const r of await allReports()) {
    if (!(r.source === 'import' || r.importedAt)) continue;
    const wrongDate = bad(r.pdfCreatedAt);
    const wrongState = r.status !== 'erstellt' || (!!r.reportId && !r.numberUsed);
    if (!wrongDate && !wrongState) continue;
    if (wrongDate) r.pdfCreatedAt = better(r);
    r.status = 'erstellt';
    r.numberUsed = !!r.reportId;
    await putReport(r);
    fixed.set(r.id, r);
    n++;
  }
  for (const p of (await entries(PDF_STORE)).map((e) => e.v).filter(Boolean)) {
    const rep = fixed.get(p.reportUuid);
    if (!rep && !bad(p.createdAt)) continue;
    if (!rep && !(p.report && (p.report.source === 'import' || p.report.importedAt))) continue;
    const at = rep ? rep.pdfCreatedAt : better(p.report || {});
    if (p.createdAt === at && p.report?.status === 'erstellt') continue;
    p.createdAt = at;
    if (p.report) { p.report.pdfCreatedAt = at; p.report.status = 'erstellt'; p.report.numberUsed = !!p.report.reportId; }
    await tx(PDF_STORE, 'readwrite', (st, mem) => (st ? reqP(st.put(p, p.key)) : mem.set(p.key, p)));
  }
  return n;
}
