// Protokolle (inkl. Fotos) und erstellte PDF-Dateien in IndexedDB; Fallback: In-Memory.
//
// Leistung (25.10.2026): Listen, Kalender und Ordner lesen nur noch eine schlanke Übersicht
// (Store „meta“ bzw. „pdfmeta“, ohne Fotos und PDF-Inhalt), die zusätzlich im Speicher gehalten und
// bei jeder Änderung gezielt aktualisiert wird. Vollständige Protokolle (getReport) und PDF-Inhalte
// (getPdf) werden erst geladen, wenn sie gebraucht werden. Vorschaubilder der Fotos liegen im Store
// „thumbs“. Bestehende Daten werden beim ersten Start einmalig in die Übersicht übernommen.

const DB_NAME = 'schadwagen';
const DB_VERSION = 4;
const STORE = 'reports';     // vollständige Protokolle (mit Fotos)
const PDF_STORE = 'pdfs';    // erstellte PDFs (mit Inhalt)
const META = 'meta';         // Übersicht je Protokoll (ohne Fotos)
const PDF_META = 'pdfmeta';  // Übersicht je PDF (ohne Inhalt)
const THUMBS = 'thumbs';     // Vorschaubilder der Fotos je Protokoll
const TPL = 'templates';     // Vorlagen (Halter usw., ohne PDF)
const TPL_PDF = 'tplpdfs';   // Original-PDF einer importierten Vorlage
const CURRENT_KEY = '__current__';
let dbPromise = null;
const memory = { [STORE]: new Map(), [PDF_STORE]: new Map(), [META]: new Map(), [PDF_META]: new Map(), [THUMBS]: new Map(), [TPL]: new Map(), [TPL_PDF]: new Map() };

function open() {
  if (!('indexedDB' in window)) return Promise.resolve(null);
  if (!dbPromise) {
    dbPromise = new Promise((resolve) => {
      try {
        const req = indexedDB.open(DB_NAME, DB_VERSION);
        req.onupgradeneeded = () => {
          const db = req.result;
          for (const s of [STORE, PDF_STORE, META, PDF_META, THUMBS, TPL, TPL_PDF]) if (!db.objectStoreNames.contains(s)) db.createObjectStore(s);
        };
        req.onsuccess = () => {
          const db = req.result;
          db.onversionchange = () => db.close();
          resolve(db);
        };
        req.onerror = () => resolve(null);
        req.onblocked = () => resolve(null);
      } catch { resolve(null); }
    });
  }
  return dbPromise;
}

const reqP = (r) => new Promise((res, rej) => { r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });

/** Transaktion über einen oder mehrere Stores; fn(stores | null, memoryMaps) */
async function tx(stores, mode, fn) {
  const names = Array.isArray(stores) ? stores : [stores];
  const db = await open();
  if (!db) return fn(null, names.length === 1 ? memory[names[0]] : names.map((n) => memory[n]));
  return new Promise((resolve, reject) => {
    const t = db.transaction(names, mode);
    const s = names.length === 1 ? t.objectStore(names[0]) : names.map((n) => t.objectStore(n));
    let result;
    Promise.resolve(fn(s)).then((r) => { result = r; }, (e) => { try { t.abort(); } catch { /* schon beendet */ } reject(e); });
    t.oncomplete = () => resolve(result);
    t.onerror = () => reject(t.error);
    t.onabort = () => reject(t.error);
  });
}
const getAllValues = (store) => tx(store, 'readonly', (s, mem) => (s ? reqP(s.getAll()) : [...mem.values()]));
const getOne = (store, key) => tx(store, 'readonly', (s, mem) => (s ? reqP(s.get(key)) : mem.get(key)));
const countOf = (store) => tx(store, 'readonly', (s, mem) => (s ? reqP(s.count()) : mem.size));

/* ---------- Änderungsmeldung ----------
 * Jede Änderung an Protokollen, PDFs oder Ordnern meldet sich hier; Dashboard und „Gespeichert“
 * aktualisieren sich daraufhin (gebündelt). Andere Fenster desselben Programms werden über einen
 * BroadcastChannel informiert und verwerfen ihre Zwischenspeicher. */
const changeListeners = new Set();
let changeTimer = null;
const channel = typeof BroadcastChannel === 'function' ? new BroadcastChannel('schadwagen-daten') : null;
export function onDataChange(fn) { changeListeners.add(fn); return () => changeListeners.delete(fn); }
function fireListeners() {
  clearTimeout(changeTimer);
  changeTimer = setTimeout(() => changeListeners.forEach((fn) => { try { fn(); } catch (e) { console.warn(e); } }), 120);
}
export function notifyDataChange() {
  fireListeners();
  try { channel && channel.postMessage('changed'); } catch { /* egal */ }
}
if (channel) channel.onmessage = () => { metaCache = null; pdfMetaCache = null; fireListeners(); };

/* ---------- Übersicht ---------- */

/** Schlanke Übersicht eines Protokolls: alles, was Listen, Kalender, Ordner, Suche und Zuordnung brauchen. */
export function summarize(r) {
  return {
    _summary: true,
    id: r.id, reportId: r.reportId || '', numberUsed: !!r.numberUsed, status: r.status || 'entwurf',
    wagonNumber: r.wagonNumber || '', detectionDate: r.detectionDate || '', detectionPlace: r.detectionPlace || '',
    origin: r.origin || '', destination: r.destination || '', trainNumber: r.trainNumber || '',
    keeperName: r.keeperName || '', keeperVkm: r.keeperVkm || '', keeperEmail: r.keeperEmail || '', contactName: r.contactName || '',
    templateId: r.templateId || '', templateName: r.templateName || '',
    createdBy: r.createdBy || null, source: r.source || '', partial: !!r.partial, choicesImported: !!r.choicesImported,
    createdAt: r.createdAt || '', updatedAt: r.updatedAt || '', pdfCreatedAt: r.pdfCreatedAt || '', importedAt: r.importedAt || '',
    receivedAt: r.receivedAt || '', deletedAt: r.deletedAt || '', deletedBy: r.deletedBy || '',
    damages: (r.damages || []).map((d) => ({ code: d.code || '', noCode: !!d.noCode, customCategory: d.customCategory || '', customSub: d.customSub || '', old: !!d.old })),
    photoCount: (r.photos || []).length,
    photoSig: (r.photos || []).map((p) => (p.dataUrl || '').length).join('-'),
  };
}
/** PDF-Übersicht: ohne Inhalt und ohne Protokollkopie. */
function pdfMetaOf(rec) {
  const { bytes, report, ...m } = rec;
  return { ...m, size: bytes ? bytes.length || bytes.byteLength || 0 : 0 };
}

let metaCache = null;    // Map id -> Übersicht (auch Papierkorb)
let pdfMetaCache = null; // Map key -> PDF-Übersicht
let migrating = null;

/** Einmalige Übernahme bestehender Daten in die Übersicht (Datensatz für Datensatz per Cursor). */
async function ensureMigrated() {
  if (migrating) return migrating;
  migrating = (async () => {
    const db = await open();
    if (!db) return;
    const [nr, nm, np, npm] = await Promise.all([countOf(STORE), countOf(META), countOf(PDF_STORE), countOf(PDF_META)]);
    const hasCurrent = !!(await tx(STORE, 'readonly', (s) => reqP(s.getKey(CURRENT_KEY))));
    if (nr - (hasCurrent ? 1 : 0) === nm && np === npm) return;
    const t0 = performance.now();
    const migrateStore = (src, dst, conv, skip) => new Promise((resolve, reject) => {
      const t = db.transaction([src, dst], 'readwrite');
      const out = t.objectStore(dst);
      const cur = t.objectStore(src).openCursor();
      cur.onsuccess = () => {
        const c = cur.result;
        if (!c) return;
        if (!(skip && skip(c.key)) && c.value) out.put(conv(c.value), c.key);
        c.continue();
      };
      t.oncomplete = resolve;
      t.onerror = () => reject(t.error);
    });
    if (nr - (hasCurrent ? 1 : 0) !== nm) await migrateStore(STORE, META, summarize, (k) => k === CURRENT_KEY);
    if (np !== npm) await migrateStore(PDF_STORE, PDF_META, pdfMetaOf);
    console.info(`Übersicht aufgebaut in ${Math.round(performance.now() - t0)} ms`);
  })().finally(() => { migrating = null; });
  return migrating;
}

async function metaMap() {
  if (!metaCache) {
    await ensureMigrated();
    const vals = await getAllValues(META);
    const m = new Map();
    for (const v of vals) if (v && v.id) m.set(v.id, v);
    metaCache = m;
  }
  return metaCache;
}
async function pdfMetaMap() {
  if (!pdfMetaCache) {
    await ensureMigrated();
    const vals = await getAllValues(PDF_META);
    const m = new Map();
    for (const v of vals) if (v && v.key) m.set(v.key, v);
    pdfMetaCache = m;
  }
  return pdfMetaCache;
}

/** Zwischenspeicher sofort füllen (beim Start, damit die erste Ansicht ohne Wartezeit erscheint). */
export async function warmUp() { await Promise.all([metaMap(), pdfMetaMap()]); }

/* ---------- Protokolle ---------- */

export async function putReport(report, key = report.id) {
  if (report && report._summary) throw new Error('Übersicht kann nicht als Protokoll gespeichert werden');
  const copy = JSON.parse(JSON.stringify(report));
  if (key === CURRENT_KEY) return tx(STORE, 'readwrite', (s, mem) => (s ? reqP(s.put(copy, key)) : mem.set(key, copy)));
  const sum = summarize(copy);
  await tx([STORE, META], 'readwrite', (s, mem) => {
    if (!s) { mem[0].set(key, copy); mem[1].set(key, sum); return null; }
    s[0].put(copy, key);
    return reqP(s[1].put(sum, key));
  });
  if (metaCache) metaCache.set(key, sum);
  notifyDataChange();
  scheduleThumbs(copy);
  return key;
}
export async function getReport(key) { return getOne(STORE, key); }
export async function deleteReport(key) {
  if (key === CURRENT_KEY) return tx(STORE, 'readwrite', (s, mem) => (s ? reqP(s.delete(key)) : mem.delete(key)));
  await tx([STORE, META, THUMBS], 'readwrite', (s, mem) => {
    if (!s) { mem.forEach((m) => m.delete(key)); return null; }
    s[0].delete(key); s[2].delete(key);
    return reqP(s[1].delete(key));
  });
  if (metaCache) metaCache.delete(key);
  notifyDataChange();
}
/** Übersicht aller Protokolle (ohne Papierkorb), zuletzt geändert zuerst. Für Details getReport(id). */
export async function listReports() {
  return [...(await metaMap()).values()].filter((r) => !r.deletedAt)
    .sort((a, b) => (b.updatedAt || '').localeCompare(a.updatedAt || ''));
}
export async function getSummary(id) { return (await metaMap()).get(id) || null; }
export const saveCurrent = (r) => putReport(r, CURRENT_KEY);
export const loadCurrent = () => getReport(CURRENT_KEY);

/* ---------- Vorschaubilder ---------- */

// Warteschlange nur mit IDs (keine Protokollkopien im Speicher – wichtig beim Import vieler Protokolle)
const thumbQueue = new Set();
let thumbTimer = null;
function scheduleThumbs(r) {
  if (!r || !(r.photos || []).length || typeof document === 'undefined') return;
  thumbQueue.add(r.id);
  clearTimeout(thumbTimer);
  thumbTimer = setTimeout(async () => {
    const ids = [...thumbQueue]; thumbQueue.clear();
    for (const id of ids) {
      try {
        const sum = (await metaMap()).get(id);
        const rec = await getOne(THUMBS, id);
        if (sum && rec && rec.sig === sum.photoSig) continue;
        const full = await getReport(id);
        if (full) await buildThumbs(full);
      } catch (e) { console.warn('Vorschaubild', e); }
      await new Promise((res) => setTimeout(res, 0)); // Oberfläche zwischendurch atmen lassen
    }
  }, 1500);
}
async function shrink(dataUrl, max = 360) {
  const img = new Image();
  img.decoding = 'async';
  img.src = dataUrl;
  await img.decode();
  const s = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight));
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.round(img.naturalWidth * s)); c.height = Math.max(1, Math.round(img.naturalHeight * s));
  c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
  return c.toDataURL('image/jpeg', 0.72);
}
async function buildThumbs(r) {
  const sig = (r.photos || []).map((p) => (p.dataUrl || '').length).join('-');
  const list = [];
  for (const p of r.photos || []) list.push(await shrink(p.dataUrl));
  const rec = { sig, list };
  await tx(THUMBS, 'readwrite', (s, mem) => (s ? reqP(s.put(rec, r.id)) : mem.set(r.id, rec)));
  return rec;
}
/** Vorschaubilder eines Protokolls (fehlende werden einmalig erzeugt). */
export async function getThumbs(id) {
  const sum = (await metaMap()).get(id);
  if (!sum || !sum.photoCount) return [];
  const rec = await getOne(THUMBS, id);
  if (rec && rec.sig === sum.photoSig) return rec.list;
  const full = await getReport(id);
  if (!full) return [];
  return (await buildThumbs(full)).list;
}

/* ---------- PDF-Archiv ---------- */

/** Lokales Datum (JJJJ-MM-TT) eines ISO-Zeitstempels */
export function localDay(iso) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

/**
 * Legt eine erstellte PDF ab. Wird dasselbe Protokoll am selben Tag erneut erstellt, ersetzt die neue
 * Datei die vorherige. entry: { createdAt, filename, bytes: Uint8Array, report }
 * Die mitgespeicherte Protokollkopie enthält keine Fotos (die stehen im Protokoll selbst).
 */
export async function putPdf(entry) {
  const report = JSON.parse(JSON.stringify(entry.report));
  delete report.photos;
  const key = `${report.id}|${localDay(entry.createdAt)}`;
  const rec = {
    key, reportUuid: report.id, createdAt: entry.createdAt, filename: entry.filename,
    reportId: report.reportId || '', wagonNumber: report.wagonNumber || '', bytes: entry.bytes, report,
  };
  if (entry.deletedAt) rec.deletedAt = entry.deletedAt;
  await writePdf(rec);
  notifyDataChange();
  return key;
}
async function writePdf(rec) {
  const meta = pdfMetaOf(rec);
  await tx([PDF_STORE, PDF_META], 'readwrite', (s, mem) => {
    if (!s) { mem[0].set(rec.key, rec); mem[1].set(rec.key, meta); return null; }
    s[0].put(rec, rec.key);
    return reqP(s[1].put(meta, rec.key));
  });
  if (pdfMetaCache) pdfMetaCache.set(rec.key, meta);
}
/** Übersicht der PDFs (ohne Inhalt), neueste zuerst. Inhalt: getPdf(key). */
export async function listPdfs() {
  return [...(await pdfMetaMap()).values()].filter((p) => p && !p.deletedAt)
    .sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
}
/** Vollständiger PDF-Eintrag mit Inhalt (bytes). */
export async function getPdf(key) { return getOne(PDF_STORE, key); }
export async function deletePdf(key) {
  await tx([PDF_STORE, PDF_META], 'readwrite', (s, mem) => {
    if (!s) { mem[0].delete(key); mem[1].delete(key); return null; }
    s[0].delete(key);
    return reqP(s[1].delete(key));
  });
  if (pdfMetaCache) pdfMetaCache.delete(key);
  notifyDataChange();
}
/** Neueste archivierte PDF eines Protokolls – mit Inhalt – oder null. */
export async function latestPdfOf(reportUuid) {
  const m = (await listPdfs()).find((p) => p.reportUuid === reportUuid);
  return m ? getPdf(m.key) : null;
}

/* ---------- Papierkorb ---------- */

export const TRASH_DAYS = 30;
const TOMBSTONES = 'sw.destroyed.v1'; // endgültig gelöschte IDs (nicht erneut vom Server holen)

export function destroyedIds() {
  try { return new Set(JSON.parse(localStorage.getItem(TOMBSTONES) || '[]')); } catch { return new Set(); }
}
function addTombstone(id) {
  const s = destroyedIds(); s.add(id);
  try { localStorage.setItem(TOMBSTONES, JSON.stringify([...s].slice(-2000))); } catch { /* voll */ }
}

async function pdfKeysOf(reportUuid) {
  return [...(await pdfMetaMap()).values()].filter((p) => p.reportUuid === reportUuid).map((p) => p.key);
}
async function markPdfs(reportUuid, deletedAt) {
  for (const key of await pdfKeysOf(reportUuid)) {
    const p = await getPdf(key);
    if (!p) continue;
    if (deletedAt) p.deletedAt = deletedAt; else delete p.deletedAt;
    await writePdf(p);
  }
}

/** In den Papierkorb verschieben (inkl. der erstellten PDFs). */
export async function trashReport(id, by = '') {
  const r = await getReport(id);
  if (!r) return;
  r.deletedAt = new Date().toISOString();
  if (by) r.deletedBy = by;
  await markPdfs(id, r.deletedAt);
  await putReport(r);
}
export async function restoreReport(id) {
  const r = await getReport(id);
  if (!r) return;
  delete r.deletedAt; delete r.deletedBy;
  await markPdfs(id, null);
  await putReport(r);
}
/** Endgültig löschen. */
export async function destroyReport(id) {
  await deleteReport(id);
  for (const key of await pdfKeysOf(id)) await deletePdf(key);
  addTombstone(id);
}
/** Übersicht der Protokolle im Papierkorb, zuletzt gelöscht zuerst. */
export async function listTrash() {
  return [...(await metaMap()).values()].filter((r) => r.deletedAt).sort((a, b) => b.deletedAt.localeCompare(a.deletedAt));
}
/** Einträge älter als 30 Tage automatisch entfernen. */
export async function purgeTrash(days = TRASH_DAYS) {
  const limit = Date.now() - days * 86400000;
  let n = 0;
  for (const r of await listTrash()) {
    if (new Date(r.deletedAt).getTime() < limit) { await destroyReport(r.id); n++; }
  }
  return n;
}
export async function getAnyReport(id) { return getReport(id); }

/**
 * Reparatur früherer Importe: Protokolle, die mit dem Erstelldatum der Vorlage (2018) oder ohne
 * Status „erstellt“ eingelesen wurden, erscheinen sonst nicht im Kalender. Neues Datum:
 * Tag der Schadensfeststellung (12 Uhr), sonst Importzeitpunkt. Liefert die Anzahl.
 * Arbeitet auf der Übersicht und lädt nur betroffene Einträge vollständig.
 */
export async function repairImportDates() {
  const limit = Date.UTC(2021, 0, 1);
  const bad = (iso) => { const t = new Date(iso || NaN).getTime(); return !Number.isFinite(t) || t < limit || t > Date.now() + 86400000; };
  const better = (r) => {
    const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(r.detectionDate || ''));
    if (m) { const d = new Date(+m[1], +m[2] - 1, +m[3], 12); if (!bad(d.toISOString())) return d.toISOString(); }
    return !bad(r.importedAt) ? r.importedAt : new Date().toISOString();
  };
  let n = 0;
  const fixed = new Map();
  for (const sum of [...(await metaMap()).values()]) {
    if (!(sum.source === 'import' || sum.importedAt)) continue;
    const wrongDate = bad(sum.pdfCreatedAt);
    const wrongState = sum.status !== 'erstellt' || (!!sum.reportId && !sum.numberUsed);
    if (!wrongDate && !wrongState) continue;
    const r = await getReport(sum.id);
    if (!r) continue;
    if (wrongDate) r.pdfCreatedAt = better(r);
    r.status = 'erstellt';
    r.numberUsed = !!r.reportId;
    await putReport(r);
    fixed.set(r.id, r);
    n++;
  }
  for (const pm of [...(await pdfMetaMap()).values()]) {
    const rep = fixed.get(pm.reportUuid);
    if (!rep && !bad(pm.createdAt)) continue;
    const p = await getPdf(pm.key);
    if (!p) continue;
    if (!rep && !(p.report && (p.report.source === 'import' || p.report.importedAt))) continue;
    const at = rep ? rep.pdfCreatedAt : better(p.report || {});
    if (p.createdAt === at && p.report?.status === 'erstellt') continue;
    p.createdAt = at;
    if (p.report) { p.report.pdfCreatedAt = at; p.report.status = 'erstellt'; p.report.numberUsed = !!p.report.reportId; delete p.report.photos; }
    await writePdf(p);
  }
  if (n) notifyDataChange();
  return n;
}

/* ---------- Vorlagen ----------
 * { id, name, data: {Formularfelder}, source: 'import'|'manual', fileName, hasPdf, pdfCurrent,
 *   createdAt, updatedAt }  – Original-PDF (nur bei Import) getrennt im Store „tplpdfs“. */
export async function listTemplates() { return (await getAllValues(TPL)) || []; }
export async function getTemplate(id) { return getOne(TPL, id); }
export async function putTemplate(t, pdfBytes) {
  const rec = JSON.parse(JSON.stringify({ ...t, updatedAt: t.updatedAt || new Date().toISOString() }));
  await tx([TPL, TPL_PDF], 'readwrite', (st, mem) => {
    const [ts, ps] = st || [];
    if (st) {
      ts.put(rec, rec.id);
      if (pdfBytes) ps.put({ id: rec.id, bytes: pdfBytes }, rec.id);
    } else {
      mem[0].set(rec.id, rec);
      if (pdfBytes) mem[1].set(rec.id, { id: rec.id, bytes: pdfBytes });
    }
  });
  notifyDataChange();
  return rec;
}
export async function getTemplatePdf(id) { const p = await getOne(TPL_PDF, id); return p ? p.bytes : null; }
export async function deleteTemplate(id) {
  await tx([TPL, TPL_PDF], 'readwrite', (st, mem) => {
    if (st) { st[0].delete(id); st[1].delete(id); } else { mem[0].delete(id); mem[1].delete(id); }
  });
  notifyDataChange();
}
