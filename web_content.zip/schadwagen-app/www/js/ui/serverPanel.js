// Einstellungen → Server-Verbindung: Verbindungsart „HTTPS-Adresse (Domain)“ oder „IP-Verbindung“.
// IP-Verbindung: IP-Adresse (IPv4/IPv6), Port, verschlüsselt (https) oder unverschlüsselt (http, nur lokales Netz).
// Eigene Zertifikate: Fingerabdruck (SHA-256) anzeigen, bestätigen lassen, fest merken (Pinning).
import { h, icon, modal, toast } from './dom.js';
import { resolveEndpoint, parseIp, fmtFp, normFp, isPrivateHost } from '../endpoint.js';
import { checkConnection, probeCertificate, transportOf } from '../server.js';
import { hasNativeNet, isDesktop, isAndroidApp } from '../platform.js';

const STATUS_TEXT = {
  ok: 'Verbunden', checking: 'Verbindung wird geprüft …', none: '',
};

/**
 * s: Einstellungs-Kopie (wird direkt geändert), getToken(): aktueller API-Token aus dem Feld,
 * initial: bisheriger Verbindungsstatus. Liefert die Elemente der Karte (ohne API-Token-Feld).
 */
export function serverPanel(s, getToken, initial) {
  s.serverMode = s.serverMode === 'ip' ? 'ip' : 'https';
  s.serverIp = { host: '', port: '', scheme: 'https', ...(s.serverIp || {}) };
  s.serverPins = { ...(s.serverPins || {}) };

  const connMsg = h('div', { class: 'conn-msg', role: 'status', 'aria-live': 'polite' });
  const used = h('div', { class: 'srv-used' });
  const pinLine = h('div', { class: 'srv-pin' });
  const warn = h('div', { class: 'srv-warn', role: 'note' });

  const showConn = (c) => {
    connMsg.className = `conn-msg c-${c.status}`;
    connMsg.textContent = c.status === 'ok'
      ? `Verbunden · ${c.latency} ms${c.loginRequired ? (c.loggedIn ? ' · angemeldet' : ' · Anmeldung erforderlich (Reiter „Anmeldung“)') : ''}`
      : (c.message || STATUS_TEXT[c.status] || '');
  };

  /* --- Verbindungsart --- */
  const modeSeg = h('div', { class: 'seg srv-seg', role: 'radiogroup', 'aria-label': 'Verbindungsart' });
  const drawModeSeg = () => {
    modeSeg.replaceChildren(...[['https', 'HTTPS-Adresse (Domain)'], ['ip', 'IP-Verbindung']].map(([v, label]) => h('button', {
      type: 'button', role: 'radio', 'aria-checked': String(s.serverMode === v), class: s.serverMode === v ? 'on' : '',
      onclick: () => { s.serverMode = v; drawModeSeg(); update(); },
    }, label)));
  };

  /* --- HTTPS-Adresse --- */
  const urlInput = h('input', { id: 's-serverUrl', type: 'url', autocomplete: 'off', placeholder: 'https://server.firma.de', value: s.serverUrl || '',
    oninput: (e) => { s.serverUrl = e.target.value; update(); } });
  const domainBox = h('div', { class: 'srv-box' },
    h('div', { class: 'field' }, h('label', { class: 'label', for: 's-serverUrl' }, 'Server-Adresse'), urlInput,
      h('div', { class: 'msg small' }, 'Domain mit https://, z. B. https://server.firma.de. Fehlt https://, wird es ergänzt.')));

  /* --- IP-Verbindung --- */
  const ipInput = h('input', { id: 's-serverIp', type: 'text', inputmode: 'decimal', autocomplete: 'off', spellcheck: 'false', placeholder: '192.168.1.20 oder fd00::5',
    value: s.serverIp.host || '', oninput: (e) => { s.serverIp.host = e.target.value.trim(); update(); },
    onblur: () => { // „192.168.1.20:8080“ oder „https://…“ eingefügt -> aufteilen
      const p = parseIp(ipInput.value);
      if (!p.ok) return;
      let changed = false;
      if (p.port && String(p.port) !== s.serverIp.port) { s.serverIp.port = String(p.port); portInput.value = s.serverIp.port; changed = true; }
      if (p.scheme && p.scheme !== s.serverIp.scheme) { s.serverIp.scheme = p.scheme; drawSchemeSeg(); changed = true; }
      if (ipInput.value !== p.host) { ipInput.value = p.host; s.serverIp.host = p.host; changed = true; }
      if (changed) update();
    } });
  const portInput = h('input', { id: 's-serverPort', type: 'text', inputmode: 'numeric', autocomplete: 'off', maxlength: 5, placeholder: '443',
    value: s.serverIp.port || '', oninput: (e) => { e.target.value = e.target.value.replace(/\D/g, '').slice(0, 5); s.serverIp.port = e.target.value; update(); } });
  const schemeSeg = h('div', { class: 'seg srv-seg', role: 'radiogroup', 'aria-label': 'Verschlüsselung' });
  const drawSchemeSeg = () => {
    schemeSeg.replaceChildren(...[['https', 'Verschlüsselt (https)'], ['http', 'Unverschlüsselt (http, nur lokales Netz)']].map(([v, label]) => h('button', {
      type: 'button', role: 'radio', 'aria-checked': String(s.serverIp.scheme === v), class: s.serverIp.scheme === v ? 'on' : '',
      onclick: () => { s.serverIp.scheme = v; drawSchemeSeg(); update(); },
    }, label)));
  };
  const ipBox = h('div', { class: 'srv-box' },
    h('div', { class: 'srv-ip-row' },
      h('div', { class: 'field srv-ip' }, h('label', { class: 'label', for: 's-serverIp' }, 'IP-Adresse'), ipInput),
      h('div', { class: 'field srv-port' }, h('label', { class: 'label', for: 's-serverPort' }, 'Port'), portInput)),
    h('div', { class: 'field' }, h('span', { class: 'label' }, 'Verschlüsselung'), schemeSeg));

  function update() {
    domainBox.hidden = s.serverMode !== 'https';
    ipBox.hidden = s.serverMode !== 'ip';
    portInput.placeholder = s.serverIp.scheme === 'http' ? '80' : '443';
    const ep = resolveEndpoint(s);
    // Verwendete Adresse
    if (ep.ok || ep.reason === 'http_confirm') {
      used.replaceChildren(...[h('span', null, 'Verwendet: '), h('code', null, ep.url), ep.added && h('span', { class: 'small' }, ' (https:// ergänzt)')].filter(Boolean));
      used.className = 'srv-used';
    } else {
      used.replaceChildren(ep.reason === 'empty' ? '' : ep.message || '');
      used.className = 'srv-used bad';
    }
    // Warnung für http
    const http = s.serverMode === 'ip' && s.serverIp.scheme === 'http';
    warn.hidden = !http;
    if (http) {
      const p = parseIp(s.serverIp.host);
      const priv = p.ok && isPrivateHost(p.host);
      warn.className = `srv-warn ${p.ok && !priv ? 'bad' : ''}`;
      warn.replaceChildren(icon('lock'), h('span', null, p.ok && !priv
        ? 'Öffentliche IP-Adresse: unverschlüsselt nicht erlaubt. Bitte „Verschlüsselt (https)“ wählen.'
        : 'Unverschlüsselt: API-Token, Anmeldung und Protokolle gehen lesbar durchs Netz. Nur im eigenen, vertrauenswürdigen Netz verwenden (10.x, 172.16–31.x, 192.168.x, fd00::/8). Wird vor dem ersten Verbinden ausdrücklich bestätigt.'));
    }
    // Gemerkter Fingerabdruck
    const pin = ep.ok && ep.scheme === 'https' ? ep.pin : '';
    pinLine.hidden = !pin;
    if (pin) {
      pinLine.replaceChildren(icon('key'), h('span', null, 'Eigenes Zertifikat bestätigt: ', h('code', null, shortFp(pin))),
        h('button', { type: 'button', class: 'pill-btn sm', onclick: () => { delete s.serverPins[ep.hp]; update(); toast('Fingerabdruck entfernt – beim nächsten Prüfen neu bestätigen'); } }, 'Vergessen'));
    }
    if (!pin && ep.ok && ep.scheme === 'https' && ep.ip && !hasNativeNet()) {
      pinLine.hidden = false;
      pinLine.replaceChildren(icon('lock'), h('span', { class: 'small' }, 'Hinweis: Im Browser kann ein selbst ausgestelltes Zertifikat nicht bestätigt werden – dafür die Windows- oder Android-App nutzen oder das Zertifikat im System installieren.'));
    }
  }

  /* --- Prüfen --- */
  const checkBtn = h('button', { type: 'button', class: 'btn', onclick: () => runCheck() }, 'Verbindung prüfen');
  async function runCheck() {
    let ep = resolveEndpoint(s);
    if (!ep.ok && ep.reason === 'http_confirm') {
      if (!(await confirmHttp(ep))) { showConn({ status: 'http_confirm', message: 'Unverschlüsselte Verbindung nicht bestätigt.' }); return; }
      s.serverIp.httpConfirmed = ep.hp;
      update();
      ep = resolveEndpoint(s);
    }
    if (!ep.ok) { showConn({ status: ep.reason === 'empty' ? 'bad_url' : ep.reason, message: ep.message || 'Bitte eine Server-Adresse eingeben.' }); return; }
    checkBtn.disabled = true;
    showConn({ status: 'checking' });
    try {
      let c = await checkConnection({ settings: s, token: getToken() });
      // Domain mit eigenem Zertifikat (direkter Weg meldet nur „nicht erreichbar“): Zertifikat ansehen
      if (c.status === 'unreachable' && ep.scheme === 'https' && !ep.pin && hasNativeNet() && transportOf(ep) === 'direct') {
        const probe = await probeCertificate(ep);
        if (probe && probe.fingerprint && !probe.trusted) c = { ...c, status: 'cert_untrusted', cert: probe };
      }
      if (c.status === 'cert_untrusted' || c.status === 'cert_changed') {
        let cert = c.cert;
        if (!cert || !cert.fingerprint) cert = await probeCertificate(ep);
        if (!cert || !cert.fingerprint) {
          showConn({ status: c.status, message: cert && cert.error === 'unsupported'
            ? 'Zertifikat nicht vertrauenswürdig. Im Browser kann ein eigenes Zertifikat nicht bestätigt werden – Windows- oder Android-App nutzen.'
            : c.message });
          return;
        }
        const ok = await certDialog(cert, ep, c.status === 'cert_changed' ? ep.pin : '');
        if (!ok) { showConn({ status: c.status, message: c.status === 'cert_changed' ? 'Zertifikat geändert – Verbindung bleibt gesperrt.' : 'Zertifikat nicht bestätigt – keine Verbindung.' }); return; }
        s.serverPins[ep.hp] = normFp(cert.fingerprint);
        update();
        showConn({ status: 'checking' });
        c = await checkConnection({ settings: s, token: getToken() });
      }
      showConn(c);
    } finally { checkBtn.disabled = false; }
  }

  drawModeSeg();
  drawSchemeSeg();
  update();
  if (initial && initial.status && initial.status !== 'none') showConn(initial);

  return {
    nodes: [
      h('div', { class: 'field' }, h('span', { class: 'label' }, 'Verbindungsart'), modeSeg),
      domainBox, ipBox, used, warn, pinLine,
    ],
    checkRow: h('div', { class: 'conn-row' }, checkBtn, connMsg),
    runCheck,
  };
}

const shortFp = (fp) => { const f = fmtFp(fp); return f.length > 23 ? `${f.slice(0, 11)} … ${f.slice(-11)}` : f; };
const fmtDay = (iso) => { const d = new Date(iso); return Number.isNaN(d.getTime()) ? '—' : d.toLocaleDateString('de-DE'); };
const cn = (dn) => (/CN=([^,]+)/.exec(String(dn || '')) || [])[1] || dn || '—';

function confirmHttp(ep) {
  return modal({
    title: 'Unverschlüsselt verbinden?',
    text: `Die Verbindung zu ${ep.url} ist NICHT verschlüsselt. API-Token, Anmeldung und alle Protokolldaten können im Netz mitgelesen werden. Nur verwenden, wenn der Server in Ihrem eigenen, vertrauenswürdigen lokalen Netz steht.`,
    list: ['Öffentliche IP-Adressen sind gesperrt.', 'Die Bestätigung gilt nur für genau diese Adresse und diesen Port.', 'Besser: Server mit https betreiben (eigenes Zertifikat genügt).'],
    buttons: [{ label: 'Abbrechen', value: false }, { label: 'Ja, unverschlüsselt im lokalen Netz', value: true }],
  });
}

/** Zertifikat zeigen; oldPin gesetzt = Zertifikat hat sich geändert (deutliche Warnung, zweite Bestätigung). */
async function certDialog(cert, ep, oldPin) {
  const changed = !!oldPin;
  const v = await new Promise((resolve) => {
    const close = (x) => { bg.remove(); resolve(x); };
    const row = (k, val, cls = '') => h('div', { class: `kv ${cls}` }, h('dt', null, k), h('dd', null, val));
    const bg = h('div', { class: 'modal-bg', onclick: (e) => { if (e.target === bg) close(false); } },
      h('div', { class: `modal cert-modal${changed ? ' danger' : ''}`, role: 'dialog', 'aria-modal': 'true' },
        h('h3', null, changed ? 'Achtung: Zertifikat hat sich geändert' : 'Zertifikat bestätigen'),
        h('p', null, changed
          ? `Der Server ${ep.url} zeigt ein anderes Zertifikat als beim letzten Mal. Das kann ein erneuertes Zertifikat sein – oder ein Angriff, bei dem jemand die Verbindung abfängt. Die Verbindung ist gesperrt.`
          : `Der Server ${ep.url} nutzt ein Zertifikat, das nicht von einer bekannten Stelle beglaubigt ist (z. B. selbst ausgestellt). Vergleichen Sie den Fingerabdruck mit dem, den der Server beim Start anzeigt bzw. den Ihnen der Betreiber nennt.`),
        h('dl', { class: 'kvs one' },
          changed && row('Bisher bestätigt', h('code', { class: 'fp' }, fmtFp(oldPin))),
          row(changed ? 'Neuer Fingerabdruck (SHA-256)' : 'Fingerabdruck (SHA-256)', h('code', { class: 'fp' }, fmtFp(cert.fingerprint)), 'wide'),
          row('Ausgestellt für', cn(cert.subject)),
          row('Aussteller', `${cn(cert.issuer)}${cert.selfSigned ? ' (selbst ausgestellt)' : ''}`),
          row('Gültig', `${fmtDay(cert.notBefore)} – ${fmtDay(cert.notAfter)}`),
          cert.sans && cert.sans.length > 0 && row('Namen/Adressen', cert.sans.join(', '))),
        h('div', { class: 'actions' },
          h('button', { class: 'btn', onclick: () => close(false) }, changed ? 'Gesperrt lassen' : 'Abbrechen'),
          h('button', { class: `btn${changed ? ' danger' : ''}`, onclick: () => close(true) }, changed ? 'Neues Zertifikat vertrauen' : 'Fingerabdruck stimmt – vertrauen'))));
    document.body.appendChild(bg);
  });
  if (!v || !changed) return v;
  return modal({
    title: 'Wirklich dem neuen Zertifikat vertrauen?',
    text: 'Nur bestätigen, wenn der Betreiber den neuen Fingerabdruck bestätigt hat.',
    buttons: [{ label: 'Abbrechen', value: false }, { label: 'Ja, vertrauen', value: true }],
  });
}

export const platformNetNote = () => (isDesktop ? 'Windows-App: IP-Verbindungen und eigene Zertifikate werden vom Programm geprüft.'
  : isAndroidApp ? 'Android-App: IP-Verbindungen und eigene Zertifikate werden von der App geprüft.'
    : 'Browser: eigene Zertifikate nur, wenn sie im System installiert sind.');
