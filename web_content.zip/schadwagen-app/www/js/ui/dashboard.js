// Erweiterter Modus: Dashboard mit Kalender, PDF-Dateien des Tages, Fotos und Wagendaten.
import { h, icon, copyButton } from './dom.js';
import { formatWagonNumber } from '../wagon.js';
import { formatDate } from '../pdf/fillProtocol.js';
import { lookup, categoryName, klassChip } from '../codes.js';
import { localDay } from '../storage.js';
import { LABELS } from '../state.js';

const MONTHS = ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'];
const WEEKDAYS = ['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'];
const WEEKDAYS_LONG = ['Sonntag', 'Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag'];
const CAUSE = { wear: 'Verschleiß', own: 'Durch eigenes EVU', third: 'Durch Dritten', unknown: 'Nicht ermittelbar' };
const WORKSHOP = { before: 'Vor Entladung', after: 'Nach Entladung' };

// Auswahl bleibt erhalten, wenn zwischen Dashboard und Formular gewechselt wird
const state = { month: null, day: null, key: null, scope: 'report', owner: '' };

/** Nach dem Erstellen einer PDF: heute und das neueste Protokoll anzeigen. */
export function resetDashboardSelection() { state.day = null; state.key = null; state.month = null; }
/** Nach einem Import: Kalender auf den Tag des importierten Protokolls stellen und es auswählen. */
export function focusDashboard(day, key) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(day || ''))) { resetDashboardSelection(); return; }
  const [y, m] = day.split('-').map(Number);
  state.day = day; state.key = key || null; state.month = { y, m: m - 1 }; state.owner = '';
}

const pad = (n) => String(n).padStart(2, '0');
const dayKey = (y, m, d) => `${y}-${pad(m + 1)}-${pad(d)}`;
const todayKey = () => localDay(new Date().toISOString());
const time = (iso) => { const d = new Date(iso); return `${pad(d.getHours())}:${pad(d.getMinutes())}`; };
const longDate = (key) => {
  const [y, m, d] = key.split('-').map(Number);
  const dt = new Date(y, m - 1, d);
  return `${WEEKDAYS_LONG[dt.getDay()]}, ${d}. ${MONTHS[m - 1]} ${y}`;
};
const plural = (n, one, many) => `${n} ${n === 1 ? one : many}`;
const dash = (v) => (v && String(v).trim()) || '—';

/**
 * @param {object} o
 *  load(): Promise<entry[]>   entry = { key, createdAt, filename, reportId, wagonNumber, report }
 *  onOpen/onShare/onSave(entry), onEdit(entry), onDelete?(entry)
 *  employees: [{id, label}]  ownerId(entry) -> id|null  ownerLabel(entry) -> Text  canShare: bool
 */
export function createDashboard(o) {
  const el = h('div', { class: 'dash' });
  let entries = [];
  let byDay = new Map();

  const ownerSel = o.employees && o.employees.length > 0 && h('select', {
    class: 'v-select', 'aria-label': 'Nach Mitarbeiter filtern',
    onchange: (ev) => { state.owner = ev.target.value; state.key = null; refresh(); },
  }, h('option', { value: '' }, 'Alle Mitarbeiter'), o.employees.map((e) => h('option', { value: e.id }, e.label)), h('option', { value: '__none__' }, 'Nicht zugeordnet'));
  if (ownerSel) ownerSel.value = state.owner;
  // PDFs direkt hier hochladen: sie erscheinen sofort im Kalender
  const fileIn = o.onImport && h('input', { type: 'file', accept: '.pdf,.json,application/pdf,application/json', multiple: true, hidden: true,
    onchange: async (ev) => { const files = [...ev.target.files]; ev.target.value = ''; if (files.length) await o.onImport(files); } });
  const importBtn = o.onImport && h('button', { class: 'pill-btn dash-import', type: 'button', title: 'Schadensprotokolle (PDF) hochladen – erscheinen im Kalender', onclick: () => fileIn.click() }, icon('upload'), 'PDFs hochladen');
  const head = h('div', { class: 'dash-head' },
    h('div', null,
      h('div', { class: 'dash-eyebrow' }, longDate(todayKey())),
      h('h1', null, 'Dashboard')),
    h('div', { class: 'dash-tools' }, importBtn, fileIn, ownerSel));
  const grid = h('div', { class: 'dash-grid' });
  const cCal = h('section', { class: 'dcard d-cal', 'aria-label': 'Kalender' });
  const cFiles = h('section', { class: 'dcard d-files', 'aria-label': 'PDF-Dateien' });
  const cPhotos = h('section', { class: 'dcard d-photos', 'aria-label': 'Fotos' });
  const cWagon = h('section', { class: 'dcard d-wagon', 'aria-label': 'Wagendaten' });
  grid.append(cCal, cFiles, cPhotos, cWagon);
  el.append(head, grid);

  const dayEntries = () => byDay.get(state.day) || [];
  const selected = () => dayEntries().find((e) => e.key === state.key) || dayEntries()[0] || null;

  function selectDay(key) {
    state.day = key;
    state.key = (byDay.get(key) || [])[0]?.key || null;
    const [y, m] = key.split('-').map(Number);
    state.month = { y, m: m - 1 };
    draw();
  }

  /* ---------- Kalender ---------- */
  function drawCalendar() {
    const { y, m } = state.month;
    const first = new Date(y, m, 1);
    const offset = (first.getDay() + 6) % 7;
    const days = new Date(y, m + 1, 0).getDate();
    const today = todayKey();
    let monthCount = 0, monthDays = 0;
    const cells = [];
    for (let i = 0; i < offset; i++) cells.push(h('span', { class: 'cal-pad' }));
    for (let d = 1; d <= days; d++) {
      const k = dayKey(y, m, d);
      const n = (byDay.get(k) || []).length;
      if (n) { monthCount += n; monthDays++; }
      const cls = ['cal-day', n && 'has', k === state.day && 'sel', k === today && 'today'].filter(Boolean).join(' ');
      cells.push(h('button', {
        type: 'button', class: cls,
        'aria-label': `${d}. ${MONTHS[m]}${n ? `, ${plural(n, 'Protokoll', 'Protokolle')}` : ''}`,
        'aria-pressed': String(k === state.day),
        onclick: () => selectDay(k),
      }, h('span', { class: 'n' }, String(d)), n > 0 && h('span', { class: 'cnt' }, String(n))));
    }
    const shift = (delta) => {
      const dt = new Date(y, m + delta, 1);
      state.month = { y: dt.getFullYear(), m: dt.getMonth() };
      drawCalendar();
    };
    cCal.replaceChildren(
      h('div', { class: 'dcard-head' },
        h('div', null, h('h2', null, `${MONTHS[m]} ${y}`),
          h('div', { class: 'dsub' }, monthCount ? `${plural(monthCount, 'Protokoll', 'Protokolle')} an ${plural(monthDays, 'Tag', 'Tagen')}` : 'Keine Protokolle in diesem Monat')),
        h('div', { class: 'cal-nav' },
          h('button', { class: 'icon-btn sm', 'aria-label': 'Vorheriger Monat', onclick: () => shift(-1) }, icon('left')),
          h('button', { class: 'pill-btn', onclick: () => selectDay(today) }, 'Heute'),
          h('button', { class: 'icon-btn sm', 'aria-label': 'Nächster Monat', onclick: () => shift(1) }, icon('right')))),
      h('div', { class: 'cal-grid cal-wd' }, WEEKDAYS.map((w) => h('span', null, w))),
      h('div', { class: 'cal-grid' }, cells));
  }

  /* ---------- PDF-Dateien des Tages ---------- */
  function drawFiles() {
    const list = dayEntries();
    const sel = selected();
    const rows = list.map((e) => {
      const act = (name, label, fn) => h('button', {
        type: 'button', class: 'f-act', title: label, 'aria-label': `${label}: ${e.filename}`,
        onclick: (ev) => { ev.stopPropagation(); fn(e, ev.currentTarget); },
      }, icon(name), h('span', null, label));
      return h('div', {
        class: 'frow' + (sel && sel.key === e.key ? ' sel' : ''), role: 'button', tabindex: '0',
        onclick: () => { state.key = e.key; draw(); },
        onkeydown: (ev) => { if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); state.key = e.key; draw(); } },
      },
        h('div', { class: 'f-tile' }, icon('doc'), h('span', null, 'PDF')),
        h('div', { class: 'f-main' },
          h('div', { class: 'f-t1' }, formatWagonNumber(e.wagonNumber) || 'Ohne Wagennummer'),
          h('div', { class: 'f-t2' }, [e.reportId ? `Nr. ${e.reportId}` : 'Ohne Protokoll-Nr.', `${time(e.createdAt)} Uhr`].join(' · ')),
          o.ownerLabel && h('div', { class: 'f-t3' + (o.ownerId(e) ? '' : ' none') }, o.ownerLabel(e))),
        h('div', { class: 'f-acts' + (o.canShare === false ? ' one' : '') },
          act('eye', 'Öffnen', o.onOpen),
          o.canShare !== false && act('share', 'Teilen', o.onShare),
          o.canShare !== false && act('download', 'Speichern', o.onSave)));
    });
    cFiles.replaceChildren(
      h('div', { class: 'dcard-head' },
        h('div', null, h('h2', null, 'PDF-Dateien'), h('div', { class: 'dsub' }, `${longDate(state.day)} · ${plural(list.length, 'Datei', 'Dateien')}`))),
      list.length
        ? h('div', { class: 'flist' }, rows)
        : h('div', { class: 'd-empty' }, icon('doc'), h('p', null, 'An diesem Tag wurden keine Schadensprotokolle erstellt.')));
  }

  /* ---------- Fotos ---------- */
  function drawPhotos() {
    const sel = selected();
    const src = state.scope === 'day' ? dayEntries() : sel ? [sel] : [];
    const photos = src.flatMap((e) => (e.report.photos || []).map((p, i) => ({
      src: p.dataUrl, caption: `${formatWagonNumber(e.wagonNumber) || 'Ohne Wagennummer'} · Foto ${i + 1}`,
    })));
    const seg = h('div', { class: 'seg mini', role: 'radiogroup', 'aria-label': 'Fotos anzeigen' },
      [['report', 'Protokoll'], ['day', 'Ganzer Tag']].map(([v, label]) => h('button', {
        type: 'button', role: 'radio', 'aria-checked': String(state.scope === v), class: state.scope === v ? 'on' : '',
        onclick: () => { state.scope = v; drawPhotos(); },
      }, label)));
    cPhotos.replaceChildren(
      h('div', { class: 'dcard-head' },
        h('div', null, h('h2', null, 'Fotos'), h('div', { class: 'dsub' }, plural(photos.length, 'Bild', 'Bilder'))),
        seg),
      photos.length
        ? h('div', { class: 'gallery' }, photos.map((p, i) => h('button', {
          type: 'button', class: 'g-item', 'aria-label': `${p.caption} vergrößern`, onclick: () => lightbox(photos, i),
        }, h('img', { src: p.src, alt: p.caption, loading: 'lazy' }))))
        : h('div', { class: 'd-empty' }, icon('image'), h('p', null, sel ? 'Zu diesem Protokoll gibt es keine Fotos.' : 'Kein Protokoll ausgewählt.')));
  }

  /* ---------- Wagendaten ---------- */
  function drawWagon() {
    const sel = selected();
    if (!sel) {
      cWagon.replaceChildren(
        h('div', { class: 'dcard-head' }, h('div', null, h('h2', null, 'Wagendaten'))),
        h('div', { class: 'd-empty' }, icon('train'), h('p', null, 'Wähle einen Tag mit Protokollen im Kalender.')));
      return;
    }
    const r = sel.report;
    const kv = (label, value, cls = '') => h('div', { class: 'kv ' + cls }, h('dt', null, label), h('dd', null, value instanceof Node ? value : dash(value)));
    const place = (name, code) => (name ? h('span', null, name, code && h('span', { class: 'abbr' }, code)) : '');
    const labels = (map) => {
      const on = LABELS.filter((l) => map && map[l]);
      return on.length ? h('span', { class: 'lbls' }, on.map((l) => h('span', { class: 'lbl' }, l))) : 'Keine';
    };
    const damages = (r.damages || []).filter((d) => d.code || d.noCode).map((d) => {
      if (d.noCode) {
        const sub = lookup(`${d.customCategory}.${d.customSub}`);
        return h('li', { class: 'dmg' },
          h('div', { class: 'dmg-top' }, h('span', { class: 'code' }, [d.customCategory, d.customSub].filter(Boolean).join('.') || '—'),
            h('span', { class: 'chip' + (d.old ? '' : ' new') }, d.old ? 'Alt' : 'Neu')),
          h('div', { class: 'dmg-t' }, `Kein passender Schadcode – ${categoryName(d.customCategory)}${sub ? ` › ${sub.kurztext}` : ''}`),
          d.customText && h('div', { class: 'dmg-r' }, d.customText),
          d.remark && h('div', { class: 'dmg-r' }, d.remark));
      }
      const c = lookup(d.code);
      const k = c && klassChip(c.fehlerklasse);
      return h('li', { class: 'dmg' },
        h('div', { class: 'dmg-top' }, h('span', { class: 'code' }, d.code),
          k && h('span', { class: k.cls }, k.text),
          h('span', { class: 'chip' + (d.old ? '' : ' new') }, d.old ? 'Alt' : 'Neu')),
        h('div', { class: 'dmg-t' }, c ? c.titel : 'Unbekannter Schadcode'),
        h('div', { class: 'dmg-m' }, h('b', null, 'Maßnahme: '), (c && c.massnahme) || '—'),
        d.remark && h('div', { class: 'dmg-r' }, d.remark));
    });
    const cause = r.cause === 'third' && r.perpetrator ? `${CAUSE.third}: ${r.perpetrator}` : CAUSE[r.cause];
    const existingBy = [r.existingRuNr, r.existingRuName].filter(Boolean).join(' · ');
    cWagon.replaceChildren(
      h('div', { class: 'dcard-head' },
        h('div', null, h('h2', null, 'Wagendaten'), h('div', { class: 'dsub' }, sel.reportId ? `Protokoll-Nr. ${sel.reportId}` : 'Ohne Protokoll-Nr.'),
          o.ownerLabel && h('div', { class: 'owner-line' + (o.ownerId(sel) ? '' : ' none') }, o.ownerLabel(sel))),
        h('div', { class: 'wagon-acts' },
          h('button', { class: 'pill-btn', onclick: () => o.onEdit(sel) }, icon('edit'), 'Im Formular öffnen'),
          o.onDelete && h('button', { class: 'icon-btn sm', 'aria-label': 'In den Papierkorb', title: 'In den Papierkorb', onclick: () => o.onDelete(sel) }, icon('trash')))),
      h('div', { class: 'plate' }, h('span', { class: 'plate-l' }, 'Wagennummer'), h('span', { class: 'plate-n' }, formatWagonNumber(r.wagonNumber) || '—')),
      h('dl', { class: 'kvs' },
        kv('Ort der Schadensfeststellung', place(r.detectionPlace, r.detectionPlaceCode), 'wide'),
        kv('Festgestellt am', formatDate(r.detectionDate)),
        kv('Ladezustand', r.loadingStatus === 'beladen' ? 'Beladen' : r.loadingStatus === 'leer' ? 'Leer' : ''),
        kv('Versandbahnhof', place(r.origin, r.originCode)),
        kv('Empfangsbahnhof', place(r.destination, r.destinationCode))),
      r.partial && h('p', { class: 'perm-note' }, icon('doc'), 'Aus einer fixierten PDF importiert: nur Kopfdaten übernommen – alle Angaben stehen in der PDF (Öffnen).'),
      h('h3', { class: 'd-sec' }, 'Schäden'),
      damages.length ? h('ul', { class: 'dmgs' }, damages) : h('p', { class: 'd-none' }, 'Keine Schäden erfasst.'),
      h('h3', { class: 'd-sec' }, 'Wagenhalter'),
      h('dl', { class: 'kvs' },
        kv('Halternummer', r.keeperVkm),
        kv('Name / VKM', r.keeperName),
        kv('Adresse', r.keeperAddress, 'wide pre'),
        kv('E-Mail', r.keeperEmail ? h('span', { class: 'with-copy' }, h('span', null, r.keeperEmail), copyButton(() => r.keeperEmail)) : '', 'wide')),
      h('h3', { class: 'd-sec' }, 'Bezettelung'),
      h('dl', { class: 'kvs' },
        h('div', { class: 'kv' }, h('dt', null, 'Vorgefunden'), h('dd', null, labels(r.existingLabels))),
        h('div', { class: 'kv' }, h('dt', null, 'Erfolgt'), h('dd', null, labels(r.newLabels))),
        (r.existingDate || existingBy) && kv('Vorgefunden am / durch', [formatDate(r.existingDate), existingBy].filter(Boolean).join(' · '), 'wide'),
        (r.wagonDetached || r.workshop) && kv('Aussetzen', [r.wagonDetached ? 'Ja' : 'Nein', WORKSHOP[r.workshop] && `Werkstatt ${WORKSHOP[r.workshop].toLowerCase()}`].filter(Boolean).join(' · '), 'wide')),
      h('h3', { class: 'd-sec' }, 'Ursache'),
      h('p', { class: 'd-cause' }, dash(cause)));
  }

  function draw() {
    drawCalendar();
    drawFiles();
    drawPhotos();
    drawWagon();
  }

  async function refresh() {
    try { entries = await o.load(); } catch { entries = []; }
    if (state.owner && o.ownerId) entries = entries.filter((e) => (state.owner === '__none__' ? !o.ownerId(e) : o.ownerId(e) === state.owner));
    byDay = new Map();
    for (const e of entries) {
      const k = localDay(e.createdAt);
      if (!k) continue;
      if (!byDay.has(k)) byDay.set(k, []);
      byDay.get(k).push(e);
    }
    for (const list of byDay.values()) list.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    if (!state.day) {
      // Start: heute, sonst der letzte Tag mit Protokollen
      const today = todayKey();
      const last = [...byDay.keys()].sort().pop();
      state.day = byDay.has(today) || !last ? today : last;
      state.key = null;
    }
    if (!state.month) { const [y, m] = state.day.split('-').map(Number); state.month = { y, m: m - 1 }; }
    draw();
  }

  el.refresh = refresh;
  refresh();
  return el;
}

/* ---------- Vergrößerte Ansicht ---------- */
export function lightbox(photos, start = 0) {
  let i = start;
  const img = h('img', { alt: '' });
  const cap = h('div', { class: 'lb-cap' });
  const show = () => { img.src = photos[i].src; img.alt = photos[i].caption; cap.textContent = `${photos[i].caption}  ·  ${i + 1} / ${photos.length}`; };
  const go = (d) => { i = (i + d + photos.length) % photos.length; show(); };
  const close = () => { bg.remove(); document.removeEventListener('keydown', onKey); };
  const onKey = (e) => {
    if (e.key === 'Escape') close();
    else if (e.key === 'ArrowRight') go(1);
    else if (e.key === 'ArrowLeft') go(-1);
  };
  let x0 = null;
  const bg = h('div', {
    class: 'lightbox', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Foto',
    onclick: (e) => { if (e.target === bg || e.target.classList.contains('lb-stage')) close(); },
    ontouchstart: (e) => { x0 = e.touches[0].clientX; },
    ontouchend: (e) => { if (x0 === null) return; const dx = e.changedTouches[0].clientX - x0; if (Math.abs(dx) > 50) go(dx < 0 ? 1 : -1); x0 = null; },
  },
    h('div', { class: 'lb-stage' }, img),
    h('button', { class: 'lb-btn lb-close', 'aria-label': 'Schließen', onclick: close }, icon('close')),
    photos.length > 1 && h('button', { class: 'lb-btn lb-prev', 'aria-label': 'Vorheriges Foto', onclick: () => go(-1) }, icon('left')),
    photos.length > 1 && h('button', { class: 'lb-btn lb-next', 'aria-label': 'Nächstes Foto', onclick: () => go(1) }, icon('right')),
    cap);
  bg.close = close;
  document.addEventListener('keydown', onKey);
  document.body.appendChild(bg);
  show();
  return close;
}
