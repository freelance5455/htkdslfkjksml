import { h } from './dom.js';
import { categories, categoryEntries, subCategories, lookup, search, klassChip } from '../codes.js';

/**
 * Vollbild-Dialog zur Schadcode-Auswahl (Kategorie -> Code) bzw. "kein passender Schadcode".
 * onApply erhält { code, noCode, customCategory, customSub, customText }.
 */
export function openCodePicker(damage, nr, onApply) {
  const cur = damage.noCode ? null : lookup(damage.code);
  const st = {
    cat: damage.noCode ? damage.customCategory : (cur ? String(cur.kategorie) : ''),
    code: cur && cur.auswaehlbar ? cur.code : '',
    noCode: !!damage.noCode,
    sub: damage.customSub || '',
    text: damage.customText || '',
    filter: '',
  };

  const sheet = h('div', { class: 'sheet', role: 'dialog', 'aria-modal': 'true', 'aria-label': `Schadcode für Schaden ${nr}` });
  const close = () => { sheet.remove(); document.body.style.overflow = ''; };
  document.body.style.overflow = 'hidden';

  const valid = () => (st.noCode ? !!(st.cat && st.sub && st.text.trim()) : !!st.code);

  function listView() {
    if (st.noCode) return null;
    if (!st.cat && !st.filter.trim()) return h('div', { class: 'hint-text' }, 'Kategorie wählen oder Suchbegriff/Code eingeben.');
    let rows;
    if (st.filter.trim()) {
      rows = search(st.filter, { category: st.cat || null, limit: 200 }).map(item);
      if (!rows.length) rows = [h('div', { class: 'hint-text' }, 'Kein Schadcode gefunden.')];
    } else {
      rows = categoryEntries(st.cat).map((c) => {
        if (c.auswaehlbar) return item(c);
        if (c.frei) return null;
        return h('div', { class: 'grp' + (c.ebene > 2 ? ' l3' : '') }, `${c.code}  ${c.ebene === 2 ? c.titel : c.kurztext}`);
      });
    }
    return h('div', { class: 'codelist', role: 'listbox' }, rows);
  }
  function item(c) {
    const k = klassChip(c.fehlerklasse);
    return h('button', {
      type: 'button', role: 'option', 'aria-selected': String(st.code === c.code),
      class: 'item' + (st.code === c.code ? ' sel' : ''),
      onclick: () => { st.code = c.code; st.cat = String(c.kategorie); render(); },
    }, h('span', { class: 'c' }, c.code), h('span', { class: 't' }, c.kurztext), k && h('span', { class: `k ${k.cls}` }, `K${c.fehlerklasse}`));
  }

  function render() {
    const scrollEl = sheet.querySelector('.body');
    const scroll = scrollEl ? scrollEl.scrollTop : 0;
    sheet.innerHTML = '';
    const catSel = h('select', {
      id: 'pk-cat',
      onchange: (e) => { st.cat = e.target.value; st.sub = ''; if (st.code && !st.code.startsWith(st.cat + '.')) st.code = ''; render(); },
    }, h('option', { value: '' }, 'Auswählen'), categories.map((k) => h('option', { value: String(k.nr), selected: String(k.nr) === st.cat }, `${k.nr}. ${k.name}`)));
    catSel.value = st.cat;

    const sel = st.code ? lookup(st.code) : null;
    const filterInput = h('input', {
      type: 'search', placeholder: 'Code oder Begriff suchen …', autocomplete: 'off', value: st.filter,
      oninput: (e) => {
        st.filter = e.target.value;
        const pos = e.target.selectionStart;
        render();
        const f = sheet.querySelector('input[type=search]');
        f.focus(); f.setSelectionRange(pos, pos);
      },
    });

    const toggle = h('label', { class: 'toggle-row' },
      h('span', { class: 'switch' }, h('input', { type: 'checkbox', checked: st.noCode, onchange: (e) => { st.noCode = e.target.checked; render(); } }), h('span')),
      'Kein passender Schadcode vorhanden');

    const custom = st.noCode && h('div', { class: 'block' },
      h('div', { class: 'field' }, h('label', { class: 'label', for: 'pk-sub' }, 'Unterkategorie (2. Gliederungsebene)'),
        h('select', { id: 'pk-sub', disabled: !st.cat, onchange: (e) => { st.sub = e.target.value; render(); } },
          h('option', { value: '' }, st.cat ? 'Auswählen' : 'Zuerst Kategorie wählen'),
          st.cat && subCategories(st.cat).map((c) => h('option', { value: c.code.split('.')[1], selected: c.code.split('.')[1] === st.sub }, `${c.code} ${c.titel}`)))),
      h('div', { class: 'field' }, h('label', { class: 'label', for: 'pk-text' }, 'Beschreibung des Schadens'),
        h('textarea', { id: 'pk-text', rows: 3, placeholder: 'Eingeben', value: st.text, oninput: (e) => { st.text = e.target.value; applyBtn.disabled = !valid(); } })),
      h('p', { class: 'small' }, 'Gemäß Anlage 9, Ziff. 2.2.4: Dokumentation mit dem übergeordneten Code, mindestens 2. Gliederungsebene.'));

    const applyBtn = h('button', {
      type: 'button', class: 'btn', disabled: !valid(),
      onclick: () => {
        close();
        onApply(st.noCode
          ? { code: '', noCode: true, customCategory: st.cat, customSub: st.sub, customText: st.text.trim() }
          : { code: st.code, noCode: false, customCategory: '', customSub: '', customText: '' });
      },
    }, 'Übernehmen');

    sheet.append(
      h('div', { class: 'head' }),
      h('div', { class: 'body' },
        h('div', { class: 'block' }, h('div', { class: 'field' }, h('label', { class: 'label', for: 'pk-cat' }, `Schaden-Kategorie ${nr}`), catSel)),
        !st.noCode && h('div', { class: 'block' },
          h('div', { class: 'field' }, h('span', { class: 'label' }, 'Schadcode'),
            sel ? h('div', null, h('b', null, sel.code), ' ', sel.titel) : h('div', { class: 'small' }, 'Noch kein Code gewählt')),
          h('div', { class: 'field' }, filterInput)),
        h('div', { class: 'block' }, toggle),
        custom,
        listView()),
      h('div', { class: 'actions' }, h('button', { type: 'button', class: 'btn', onclick: close }, 'Abbrechen'), applyBtn));
    const b = sheet.querySelector('.body');
    if (b) b.scrollTop = scroll;
  }

  render();
  document.body.appendChild(sheet);
  if (st.code) {
    const el = sheet.querySelector('.item.sel');
    if (el) el.scrollIntoView({ block: 'center' });
  }
}
