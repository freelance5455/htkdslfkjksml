// Ansichten: Gespeichert, Papierkorb, Mitarbeiter, Anmeldung, Mitarbeiterwechsel mit PIN, Latenz-Anzeige.
import { h, icon, toast, modal, confirmDialog, alertDialog, copyButton, popMenu } from './dom.js';
import {
  dateTree, datePathLabel, yearName, monthName, dayName, NO_DATE, listFolders, findFolder, folderOf,
  folderNameError, addFolder, renameFolder, removeFolder, moveToFolder,
} from '../folders.js';
import { getOwnerFilter, setOwnerFilter, matchesOwner, getSavedPath, setSavedPath } from '../viewstate.js';
import { formatWagonNumber } from '../wagon.js';
import { formatDate } from '../pdf/fillProtocol.js';
import { listReports, listTrash, trashReport, restoreReport, destroyReport, putReport, TRASH_DAYS, onDataChange } from '../storage.js';
import {
  PERMS, TEMPLATES, TITLES, hasPerm, fullName, initials, normPrefix, roleOf, roleLabel, listEmployees, activeList,
  activeEmployee, findEmployee, prefixTaken, wouldLoseAdmin, validPin, newSalt, hashPin, verifyPin,
  pinLockedFor, pinFailed, pinOk, markUnlocked, ownerOf, ownerLabel, createdByOf, maxUsedNumber, hasEmployees,
} from '../employees.js';
import { conn, onConnChange, checkConnection, login, logout, latencyLevel, serverBase, canSync } from '../server.js';
import { presenceFor, onPresenceChange, refreshPresence } from '../presence.js';
import { getReport } from '../storage.js';

/* ---------- Aktuelle Bearbeitung ---------- */

const hhmm = (iso) => { const d = new Date(iso); return Number.isNaN(d.getTime()) ? '' : d.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' }); };
function ago(iso) {
  const ms = Date.now() - new Date(iso).getTime();
  if (!Number.isFinite(ms) || ms < 0) return 'gerade eben';
  const m = Math.floor(ms / 60000);
  if (m < 1) return 'gerade eben';
  if (m < 60) return `vor ${m} Min.`;
  return `vor ${Math.floor(m / 60)} Std.`;
}

/** Karte „Aktuelle Bearbeitung“: an welchem Protokoll der Mitarbeiter gerade arbeitet (live). */
function presenceCard(app, e) {
  const list = presenceFor(e.id);
  const head = h('div', { class: 'dcard-head' },
    h('div', null, h('h2', null, 'Aktuelle Bearbeitung'),
      h('div', { class: 'dsub' }, list.length ? `${list.length === 1 ? 'Ein Protokoll' : `${list.length} Protokolle`} gerade geöffnet` : (canSync() ? 'Live – alle Geräte' : 'Live – dieses Gerät (für andere Geräte Server-Verbindung nötig)'))),
    h('span', { class: 'live-badge' + (list.length ? ' on' : '') }, h('span', { class: 'live-dot' }), list.length ? 'Live' : 'Inaktiv'));
  if (!list.length) {
    return h('section', { class: 'dcard presence-card' }, head,
      h('div', { class: 'd-empty' }, icon('doc'), h('p', null, `${e.firstName || fullName(e)} arbeitet gerade an keinem Protokoll.`)));
  }
  return h('section', { class: 'dcard presence-card' }, head,
    h('div', { class: 'live-list' }, list.map((p) => {
      const busy = Date.now() - new Date(p.lastActivity).getTime() < 2 * 60000;
      const openBtn = h('button', { class: 'pill-btn sm', type: 'button' }, icon(p.self ? 'doc' : 'eye'), p.self ? 'Zum Formular' : 'Protokoll öffnen');
      if (p.self) openBtn.onclick = () => app.showForm();
      else if (!p.stored) { openBtn.disabled = true; openBtn.title = 'Wurde noch nicht gespeichert'; }
      else {
        openBtn.disabled = true;
        getReport(p.reportUuid).then((r) => {
          if (r && !r.deletedAt) { openBtn.disabled = false; openBtn.onclick = () => app.openReport(r.id, r); }
          else openBtn.title = 'Noch nicht auf diesem Gerät – erscheint nach dem Abgleich mit dem Server';
        }).catch(() => {});
      }
      return h('div', { class: 'live-item' + (busy ? ' is-busy' : '') },
        h('div', { class: 'li-status' }, h('span', { class: 'live-dot' }),
          busy ? 'Bearbeitet gerade' : `Geöffnet · letzte Änderung ${ago(p.lastActivity)}`,
          p.inForm === false && h('span', { class: 'li-tag' }, 'im Hintergrund'),
          p.dirty && h('span', { class: 'li-tag warn' }, 'ungespeicherte Änderungen'),
          !p.stored && h('span', { class: 'li-tag' }, 'noch nicht gespeichert')),
        h('div', { class: 'li-main' },
          h('div', null,
            h('div', { class: 'mr-n' }, formatWagonNumber(p.wagonNumber) || 'Ohne Wagennummer'),
            h('div', { class: 'mr-s' }, [p.reportId ? `Nr. ${p.reportId}` : 'Neues Protokoll – noch ohne Nummer', p.place].filter(Boolean).join(' · '))),
          openBtn),
        h('div', { class: 'li-meta' }, [`${p.device || 'Gerät'}${p.self ? ' (dieses Gerät)' : ''}`, p.openedAt && `geöffnet ${hhmm(p.openedAt)} Uhr`].filter(Boolean).join(' · ')));
    })));
}

const fmtDateTime = (iso) => {
  if (!iso) return '';
  const d = new Date(iso);
  const p = (n) => String(n).padStart(2, '0');
  return `${p(d.getDate())}.${p(d.getMonth() + 1)}.${d.getFullYear()}, ${p(d.getHours())}:${p(d.getMinutes())} Uhr`;
};
const codesOf = (r) => (r.damages || []).map((d) => (d.noCode ? `${d.customCategory}.${d.customSub}` : d.code)).filter(Boolean).join(', ');

export function avatar(e, cls = '') {
  return h('span', { class: `avatar ${cls}`, 'aria-hidden': 'true' }, e ? initials(e) : icon('lock'));
}

function viewShell(title, sub, actions, ...content) {
  return h('div', { class: 'view' },
    h('div', { class: 'view-head' },
      h('div', null, sub && h('div', { class: 'dash-eyebrow' }, sub), h('h1', null, title)),
      actions && h('div', { class: 'view-actions' }, actions)),
    ...content);
}

/* ================= Gespeichert ================= */

/**
 * app: { settings, can(p), canEdit(r), openReport(id, r), viewReport(r), showInCalendar(r), extended,
 *        onTrashed(r), importFiles(files), pull(), saveFolders(list) }
 * Ordneransicht: Datumsordner nach „Schaden festgestellt am“ (Jahr › Monat › Tag), „Ohne Datum“,
 * eigene Ordner als Kacheln dahinter. Suche durchsucht alle Ordner. Filter und Ordner teilt sich die
 * Ansicht mit dem Dashboard (viewstate.js) – gleiche Auswahl, gleiche Zählung.
 */
const readPath = getSavedPath;
const writePath = (p) => { const { focus, ...rest } = p || {}; setSavedPath(rest); };
const countText = (n) => `${n} Protokoll${n === 1 ? '' : 'e'}`;
const newestFirst = (a, b) => (b.detectionDate || '').localeCompare(a.detectionDate || '')
  || (b.pdfCreatedAt || b.updatedAt || '').localeCompare(a.pdfCreatedAt || a.updatedAt || '')
  || (b.reportId || '').localeCompare(a.reportId || '', 'de', { numeric: true });

export function renderSaved(app) {
  const body = h('div', { class: 'sv-body' });
  const crumbs = h('nav', { class: 'sv-crumbs', 'aria-label': 'Ordnerpfad' });
  const filterSel = employeeFilter(app, () => { setOwnerFilter(filterSel.value); draw(); });
  filterSel.value = getOwnerFilter();
  if (filterSel.value !== getOwnerFilter()) { setOwnerFilter(''); filterSel.value = ''; }
  const search = h('input', { type: 'search', class: 'v-search', placeholder: 'Alle Ordner durchsuchen (Wagennummer, Nr., Ort, Datum …)', oninput: () => draw(), 'aria-label': 'Suchen' });
  const fileIn = h('input', { type: 'file', accept: '.pdf,.json,application/pdf,application/json', multiple: true, hidden: true,
    onchange: async (e) => { const files = [...e.target.files]; e.target.value = ''; if (files.length) { await app.importFiles(files); await load(); } } });
  const actions = [
    app.can('folders') && h('button', { class: 'pill-btn', onclick: () => createFolder() }, icon('plus'), 'Neuer Ordner'),
    app.can('create') && h('button', { class: 'pill-btn', onclick: () => fileIn.click() }, icon('upload'), 'Importieren'),
    canSync() && h('button', { class: 'pill-btn', onclick: async () => { await app.pull(true); await load(); } }, icon('cloud'), 'Vom Server abrufen'),
  ];
  let reports = [];
  let path = readPath();
  let focusId = path.focus || null;
  const el = viewShell('Gespeicherte Protokolle', null, [...actions, fileIn],
    h('div', { class: 'v-filters' }, search, filterSel),
    crumbs, body);

  const go = (p) => { path = p; writePath(p); draw(); body.scrollIntoView?.({ block: 'nearest' }); };

  const byEmployee = (r) => matchesOwner(r, app.settings, filterSel.hidden ? '' : filterSel.value);
  function matchesSearch(r, q) {
    const qd = q.replace(/\D/g, '');
    if (qd.length >= 3 && String(r.wagonNumber || '').includes(qd)) return true;
    const hay = reportHaystack(r);
    return q.split(/\s+/).filter(Boolean).every((w) => hay.includes(w) || hay.replace(/\s+/g, '').includes(w));
  }

  /* ----- eigene Ordner ----- */
  async function createFolder(thenMove) {
    const name = await nameDialog('Neuer Ordner', '', (n) => folderNameError(app.settings, n));
    if (!name) return null;
    const { folders, folder } = addFolder(app.settings, name);
    app.saveFolders(folders);
    if (thenMove) { app.saveFolders(moveToFolder(app.settings, thenMove.id, folder.id)); toast(`In „${folder.name}“ verschoben`); }
    else toast(`Ordner „${folder.name}“ angelegt`);
    draw();
    return folder;
  }
  async function renameIt(f) {
    const name = await nameDialog('Ordner umbenennen', f.name, (n) => folderNameError(app.settings, n, f.id));
    if (!name || name === f.name) return;
    app.saveFolders(renameFolder(app.settings, f.id, name));
    toast('Ordner umbenannt'); draw();
  }
  async function deleteIt(f) {
    if (!(await confirmDialog(`Ordner „${f.name}“ löschen?`, 'Die Protokolle bleiben erhalten und sind weiter in ihren Datumsordnern zu finden.', 'Ordner löschen'))) return;
    app.saveFolders(removeFolder(app.settings, f.id));
    toast('Ordner gelöscht');
    if (path.kind === 'custom' && path.id === f.id) go({ kind: 'root' }); else draw();
  }
  function moveReport(r, folderId) {
    const before = folderOf(app.settings, r.id);
    if ((before && before.id) === (folderId || undefined) || (!before && !folderId)) return;
    app.saveFolders(moveToFolder(app.settings, r.id, folderId));
    const f = folderId && findFolder(app.settings, folderId);
    toast(f ? `In „${f.name}“ verschoben` : `Aus „${before.name}“ entfernt`);
    draw();
  }
  function moveMenu(anchor, r) {
    const cur = folderOf(app.settings, r.id);
    popMenu(anchor, [
      ...listFolders(app.settings).map((f) => ({ icon: 'folder', label: f.name, sub: f.id === cur?.id ? 'aktueller Ordner' : countText(liveItems(f).length), onClick: () => moveReport(r, f.id) })),
      { icon: 'plus', label: 'Neuer Ordner …', onClick: () => createFolder(r) },
      cur && { icon: 'close', label: `Aus „${cur.name}“ entfernen`, sub: 'bleibt im Datumsordner', onClick: () => moveReport(r, null) },
    ], { title: 'Verschieben nach …' });
  }
  const liveItems = (f) => { const ids = new Set(f.items || []); return reports.filter((r) => ids.has(r.id) && byEmployee(r)); };

  /** Ablageziel für Ziehen & Ablegen */
  function dropTarget(node, folderId) {
    if (!app.can('folders')) return node;
    node.addEventListener('dragover', (e) => { if (e.dataTransfer.types.includes('text/x-report-id')) { e.preventDefault(); node.classList.add('drop'); } });
    node.addEventListener('dragleave', () => node.classList.remove('drop'));
    node.addEventListener('drop', (e) => {
      e.preventDefault(); node.classList.remove('drop');
      const r = reports.find((x) => x.id === e.dataTransfer.getData('text/x-report-id'));
      if (r) moveReport(r, folderId);
    });
    return node;
  }

  /* ----- Bausteine ----- */
  const tile = (name, n, sub, onClick, { custom, folderId } = {}) => {
    const t = h('button', { type: 'button', class: `sv-folder${custom ? ' custom' : ''}`, onclick: onClick },
      h('span', { class: 'sv-ico' }, icon('folder')),
      h('span', { class: 'sv-txt' }, h('b', null, name), h('span', null, [countText(n), sub].filter(Boolean).join(' · '))));
    return custom ? dropTarget(t, folderId) : t;
  };
  const grid = (...tiles) => h('div', { class: 'sv-grid' }, ...tiles);
  const listOf = (rs, opts = {}) => {
    const box = h('div', { class: 'vlist' });
    const sorted = rs.slice().sort(newestFirst);
    // Lange Listen schrittweise aufbauen (erst sichtbare Einträge, Rest beim Scrollen) – der Eintrag aus
    // „In Gespeichert zeigen“ wird sofort mit aufgebaut
    const need = focusId ? sorted.findIndex((r) => r.id === focusId) + 1 : 0;
    progressive(box, sorted, (r) => savedItem(app, r, { onChange: load, folder: folderOf(app.settings, r.id), onMove: (a) => moveMenu(a, r), showPath: opts.showPath }), Math.max(40, need));
    // Sprung aus dem Dashboard („In Gespeichert zeigen“): Eintrag hervorheben
    if (focusId) {
      const it = box.querySelector(`[data-rid="${CSS.escape(focusId)}"]`);
      if (it) { it.classList.add('flash'); setTimeout(() => it.scrollIntoView({ block: 'center', behavior: 'smooth' }), 50); focusId = null; }
    }
    return box;
  };
  const empty = (txt) => h('div', { class: 'empty-state' }, txt);

  function drawCrumbs(parts) {
    crumbs.innerHTML = '';
    parts.forEach(([label, p], i) => {
      if (i) crumbs.appendChild(h('span', { class: 'sv-sep', 'aria-hidden': 'true' }, '›'));
      const last = i === parts.length - 1;
      crumbs.appendChild(last ? h('span', { class: 'sv-crumb cur', 'aria-current': 'page' }, label)
        : h('button', { type: 'button', class: 'sv-crumb', onclick: () => go(p) }, label));
    });
  }
  function draw() {
    body.innerHTML = '';
    const all = reports.filter(byEmployee);
    const q = search.value.trim().toLowerCase();
    const root = ['Gespeichert', { kind: 'root' }];
    // Suche über alle Ordner
    if (q) {
      const hits = all.filter((r) => matchesSearch(r, q));
      drawCrumbs([root, [`Suche: ${hits.length} Treffer`, null]]);
      body.appendChild(hits.length ? listOf(hits, { showPath: true }) : empty('Keine Protokolle gefunden.'));
      return;
    }
    const { years, noDate } = dateTree(all);
    const fs = listFolders(app.settings);
    // Pfad prüfen: verschwundene Ordner -> nächsthöherer vorhandener
    if (path.kind === 'custom' && !findFolder(app.settings, path.id)) path = { kind: 'root' };
    if (path.kind === 'none' && !noDate.length) path = { kind: 'root' };
    if (['year', 'month', 'day'].includes(path.kind) && !years.has(path.y)) path = { kind: 'root' };
    if (['month', 'day'].includes(path.kind) && path.kind !== 'root' && !years.get(path.y)?.has(path.m)) path = { kind: 'year', y: path.y };
    if (path.kind === 'day' && !years.get(path.y)?.get(path.m)?.has(path.iso)) path = { kind: 'month', y: path.y, m: path.m };
    writePath(path);
    const yP = (y) => [yearName(y), { kind: 'year', y }];
    const mP = (y, m) => [monthName(y, m), { kind: 'month', y, m }];
    const sum = (map) => [...map.values()].reduce((n, v) => n + (v instanceof Map ? sum(v) : v.length), 0);

    if (path.kind === 'root') {
      drawCrumbs([root]);
      if (!reports.length) { body.appendChild(empty('Noch keine gespeicherten Protokolle.')); }
      else if (!all.length) body.appendChild(empty('Keine Protokolle für diese Auswahl.'));
      // Jahresordner, „Ohne Datum“, dahinter die eigenen Ordner – ohne Überschriften
      const tiles = [...years.keys()].sort((a, b) => b - a).map((y) => tile(yearName(y), sum(years.get(y)), `${years.get(y).size} Monat${years.get(y).size === 1 ? '' : 'e'}`, () => go({ kind: 'year', y })));
      if (noDate.length) tiles.push(tile(NO_DATE, noDate.length, 'kein Feststellungsdatum', () => go({ kind: 'none' })));
      fs.forEach((f) => tiles.push(tile(f.name, liveItems(f).length, 'eigener Ordner', () => go({ kind: 'custom', id: f.id }), { custom: true, folderId: f.id })));
      if (tiles.length) body.appendChild(grid(...tiles));
      return;
    }
    if (path.kind === 'year') {
      const months = years.get(path.y);
      drawCrumbs([root, yP(path.y)]);
      body.appendChild(grid(...[...months.keys()].sort((a, b) => b - a).map((m) =>
        tile(monthName(path.y, m), sum(months.get(m)), `${months.get(m).size} Tag${months.get(m).size === 1 ? '' : 'e'}`, () => go({ kind: 'month', y: path.y, m })))));
    } else if (path.kind === 'month') {
      const days = years.get(path.y).get(path.m);
      drawCrumbs([root, yP(path.y), mP(path.y, path.m)]);
      body.appendChild(grid(...[...days.keys()].sort().reverse().map((iso) =>
        tile(dayName(iso), days.get(iso).length, '', () => go({ kind: 'day', y: path.y, m: path.m, iso })))));
    } else if (path.kind === 'day') {
      drawCrumbs([root, yP(path.y), mP(path.y, path.m), [dayName(path.iso), path]]);
      body.appendChild(listOf(years.get(path.y).get(path.m).get(path.iso)));
    } else if (path.kind === 'none') {
      drawCrumbs([root, [NO_DATE, path]]);
      body.appendChild(h('p', { class: 'small sv-hint' }, 'Bei diesen Protokollen fehlt „Schaden festgestellt am“. Sobald das Datum eingetragen ist, wandern sie automatisch in den passenden Datumsordner.'));
      body.appendChild(listOf(noDate));
    } else if (path.kind === 'custom') {
      const f = findFolder(app.settings, path.id);
      drawCrumbs([root, [f.name, path]]);
      const items = liveItems(f);
      body.appendChild(h('div', { class: 'sv-folder-head' },
        h('span', { class: 'small' }, countText(items.length)),
        app.can('folders') && h('div', { class: 'sv-folder-actions' },
          h('button', { class: 'pill-btn sm', onclick: () => renameIt(f) }, icon('edit'), 'Umbenennen'),
          h('button', { class: 'pill-btn sm', onclick: () => deleteIt(f) }, icon('trash'), 'Ordner löschen'))));
      body.appendChild(items.length ? listOf(items, { showPath: true }) : empty('Dieser Ordner ist leer. Protokolle über „⋯ › Verschieben nach …“ oder per Ziehen auf die Ordnerkachel ablegen.'));
    }
  }
  async function load() { reports = await listReports(); draw(); }
  el.refresh = load;
  load();
  return el;
}

/** Eingabedialog für einen Ordnernamen; liefert den Namen oder null. */
function nameDialog(title, initial, validate) {
  return new Promise((resolve) => {
    const close = (v) => { bg.remove(); resolve(v); };
    const err = h('div', { class: 'sv-err', role: 'alert' });
    const ok = () => { const v = input.value.trim(); const e = validate(v); if (e) { err.textContent = e; input.focus(); return; } close(v); };
    const input = h('input', { type: 'text', class: 'sv-name', value: initial, maxlength: 60, 'aria-label': 'Ordnername',
      onkeydown: (e) => { if (e.key === 'Enter') ok(); if (e.key === 'Escape') close(null); }, oninput: () => { err.textContent = ''; } });
    const bg = h('div', { class: 'modal-bg', onclick: (e) => { if (e.target === bg) close(null); } },
      h('div', { class: 'modal', role: 'dialog', 'aria-modal': 'true' },
        h('h3', null, title), input, err,
        h('div', { class: 'actions' },
          h('button', { class: 'btn', onclick: () => close(null) }, 'Abbrechen'),
          h('button', { class: 'btn', onclick: ok }, 'OK'))));
    document.body.appendChild(bg);
    setTimeout(() => { input.focus(); input.select(); }, 0);
  });
}

function employeeFilter(app, onChange) {
  const sel = h('select', { class: 'v-select', 'aria-label': 'Nach Mitarbeiter filtern', onchange: onChange },
    h('option', { value: '' }, 'Alle Mitarbeiter'),
    listEmployees(app.settings).map((e) => h('option', { value: e.id }, `${fullName(e)}${e.prefix ? ` (${normPrefix(e.prefix)})` : ''}`)),
    h('option', { value: '__none__' }, 'Nicht zugeordnet'));
  if (!hasEmployees(app.settings)) sel.hidden = true;
  return sel;
}

function savedItem(app, r, { onChange, folder, onMove, showPath }) {
  const { employee } = ownerOf(r, app.settings);
  const codes = codesOf(r);
  const drag = !!onMove && app.can('folders');
  const canEdit = app.canEdit ? app.canEdit(r) : app.can('edit');
  const act = (name, label, fn, cls = '') => h('button', {
    type: 'button', class: `icon-btn sv-act ${cls}`, 'aria-label': label, title: label,
    onclick: (e) => { e.stopPropagation(); fn(e.currentTarget); },
  }, icon(name));
  const view = () => (app.viewReport ? app.viewReport(r) : app.openReport(r.id, r));
  return h('div', { class: 'list-item sv-item', 'data-rid': r.id, draggable: drag ? 'true' : null,
    ondragstart: drag ? (e) => { e.dataTransfer.setData('text/x-report-id', r.id); e.dataTransfer.effectAllowed = 'move'; e.currentTarget.classList.add('dragging'); } : null,
    ondragend: drag ? (e) => e.currentTarget.classList.remove('dragging') : null },
    // Klick auf den Eintrag = Ansehen (PDF), nicht das Formular
    h('div', { class: 'main', role: 'button', tabindex: '0', title: 'Ansehen', onclick: view,
      onkeydown: (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); view(); } }, style: { cursor: 'pointer' } },
      h('div', { class: 't1' }, formatWagonNumber(r.wagonNumber) || 'Ohne Wagennummer',
        h('span', { class: 'badge' + (r.status === 'erstellt' ? '' : ' draft') }, r.status === 'erstellt' ? 'PDF erstellt' : 'Entwurf'),
        r.source === 'server' && h('span', { class: 'badge in' }, 'Eingegangen')),
      h('div', { class: 't2' }, [formatDate(r.detectionDate), r.detectionPlace, r.reportId && `Nr. ${r.reportId}`].filter(Boolean).join(' · ')),
      codes && h('div', { class: 't2' }, `Schadcodes: ${codes}`),
      (showPath || folder) && h('div', { class: 'sv-where' }, icon('folder'),
        [showPath && datePathLabel(r).join(' › '), folder && `Eigener Ordner: ${folder.name}`].filter(Boolean).join(' · ')),
      hasEmployees(app.settings) && h('div', { class: 'owner' + (employee ? '' : ' none') }, employee && avatar(employee, 'xs'), ownerLabel(r, app.settings))),
    h('div', { class: 'sv-acts' },
      act('eye', 'Ansehen', view, 'look'),
      canEdit && act('edit', 'Bearbeiten', () => app.openReport(r.id, r), 'edit'),
      app.extended && app.showInCalendar && r.detectionDate && act('calendar', 'Im Kalender zeigen', () => app.showInCalendar(r)),
      drag && act('more', 'Verschieben nach …', (b) => onMove(b)),
      !employee && hasEmployees(app.settings) && app.can('edit') && h('button', {
        class: 'pill-btn sm', onclick: async (e) => { e.stopPropagation(); if (await assignDialog(app, r)) onChange(); },
      }, 'Zuweisen'),
      app.can('delete') && act('trash', 'In den Papierkorb', async () => {
        if (await confirmDialog('In den Papierkorb?', 'Das Protokoll wird in den Papierkorb verschoben und nach 30 Tagen automatisch gelöscht.', 'In den Papierkorb')) {
          await trashReport(r.id, fullName(activeEmployee(app.settings)));
          app.onTrashed && app.onTrashed(r);
          toast('In den Papierkorb verschoben');
          onChange();
        }
      })));
}

/** Liste in Portionen aufbauen: first Einträge sofort, weitere, sobald das Listenende sichtbar wird. */
function progressive(box, items, render, first = 40, step = 60) {
  let i = 0;
  const more = (n) => {
    const frag = document.createDocumentFragment();
    for (const end = Math.min(items.length, i + n); i < end; i++) frag.appendChild(render(items[i]));
    box.insertBefore(frag, sentinel);
    if (i >= items.length) { sentinel.remove(); io && io.disconnect(); }
  };
  const sentinel = h('div', { class: 'list-more', 'aria-hidden': 'true' });
  box.appendChild(sentinel);
  const io = 'IntersectionObserver' in window
    ? new IntersectionObserver((es) => { if (es.some((x) => x.isIntersecting)) more(step); }, { rootMargin: '600px 0px' }) : null;
  more(first);
  if (i < items.length) { if (io) io.observe(sentinel); else more(items.length); }
}

/**
 * Mitarbeiter auswählen (Zuweisen): alphabetisch nach Nachname mit Buchstaben-Überschriften, Suche,
 * Avatar, Funktion und Präfix; aktuelle Zuordnung markiert; Pfeiltasten/Enter/Esc. Liefert die ID oder null.
 */
function pickEmployee(app, { title, subtitle, currentId }) {
  return new Promise((resolve) => {
    const emps = activeList(app.settings).slice().sort(byLastName);
    const close = (v) => { document.removeEventListener('keydown', onKey, true); bg.remove(); resolve(v); };
    const search = h('input', { type: 'search', class: 'v-search ep-search', placeholder: 'Name, Funktion oder Präfix suchen …', 'aria-label': 'Mitarbeiter suchen', oninput: () => draw() });
    const list = h('div', { class: 'ep-list', role: 'listbox', 'aria-label': 'Mitarbeiter' });
    const count = h('span', { class: 'ep-count' });
    function draw() {
      const q = search.value.trim().toLowerCase();
      const hits = emps.filter((e) => !q || [fullName(e), `${e.lastName} ${e.firstName}`, e.title, normPrefix(e.prefix)].join(' ').toLowerCase().includes(q));
      count.textContent = `${hits.length} von ${emps.length}`;
      list.replaceChildren();
      let letter = '';
      for (const e of hits) {
        const L = letterOf(e);
        if (L !== letter && !q) { letter = L; list.appendChild(h('div', { class: 'ep-letter', 'aria-hidden': 'true' }, L)); }
        const cur = e.id === currentId;
        list.appendChild(h('button', {
          type: 'button', class: 'ep-row' + (cur ? ' cur' : ''), role: 'option', 'aria-selected': String(cur), 'data-id': e.id,
          onclick: () => (cur ? close(null) : close(e.id)),
        }, avatar(e, 'sm'),
        h('span', { class: 'ep-txt' }, h('b', null, fullName(e)), h('span', null, [e.title, roleLabel(e)].filter(Boolean).join(' · '))),
        e.prefix && h('span', { class: 'ep-prefix' }, normPrefix(e.prefix)),
        cur && h('span', { class: 'ep-cur' }, 'aktuell')));
      }
      if (!hits.length) list.appendChild(h('div', { class: 'd-empty' }, h('p', null, 'Kein Mitarbeiter gefunden.')));
    }
    function onKey(ev) {
      const rows = [...list.querySelectorAll('.ep-row')];
      const i = rows.indexOf(document.activeElement);
      if (ev.key === 'Escape') { ev.preventDefault(); close(null); }
      else if (ev.key === 'ArrowDown') { ev.preventDefault(); (rows[i + 1] || rows[0])?.focus(); }
      else if (ev.key === 'ArrowUp') { ev.preventDefault(); if (i <= 0) search.focus(); else rows[i - 1].focus(); }
      else if (ev.key === 'Enter' && document.activeElement === search) { ev.preventDefault(); rows.find((r) => !r.classList.contains('cur'))?.click(); }
    }
    const bg = h('div', { class: 'modal-bg', onclick: (ev) => { if (ev.target === bg) close(null); } },
      h('div', { class: 'modal ep-modal', role: 'dialog', 'aria-modal': 'true', 'aria-label': title },
        h('div', { class: 'ep-head' }, h('h3', null, title), subtitle && h('p', { class: 'ep-sub' }, subtitle)),
        h('div', { class: 'ep-tools' }, search, count),
        list,
        h('div', { class: 'actions' }, h('button', { class: 'btn', onclick: () => close(null) }, 'Abbrechen'))));
    document.body.appendChild(bg);
    document.addEventListener('keydown', onKey, true);
    draw();
    setTimeout(() => {
      search.focus();
      const cur = list.querySelector('.ep-row.cur');
      if (cur) cur.scrollIntoView({ block: 'center' });
    }, 0);
  });
}

/** Protokoll von Hand einem Mitarbeiter zuweisen (auch neu zuweisen). */
export async function assignDialog(app, r) {
  const { employee } = ownerOf(r, app.settings);
  const v = await pickEmployee(app, {
    title: employee ? 'Anderem Mitarbeiter zuweisen' : 'Protokoll zuweisen',
    subtitle: [formatWagonNumber(r.wagonNumber) || 'Ohne Wagennummer', r.reportId && `Nr. ${r.reportId}`, formatDate(r.detectionDate),
      employee ? `bisher: ${fullName(employee)}` : 'bisher: nicht zugeordnet'].filter(Boolean).join(' · '),
    currentId: employee?.id,
  });
  if (!v) return false;
  const e = findEmployee(app.settings, v);
  // Übersicht -> vollständiges Protokoll laden, damit nichts (Fotos, Schäden …) verloren geht
  const full = r._summary ? await getReport(r.id) : r;
  if (!full) return false;
  full.createdBy = { ...createdByOf(e), manual: true };
  full.updatedAt = new Date().toISOString();
  await putReport(full);
  toast(`Zugewiesen: ${fullName(e)}`);
  return true;
}

/* ================= Papierkorb ================= */

export function renderTrash(app) {
  const list = h('div', { class: 'vlist' });
  const emptyBtn = app.can('trash') && h('button', {
    class: 'pill-btn danger', onclick: async () => {
      const items = await listTrash();
      if (!items.length) return;
      if (await confirmDialog('Papierkorb leeren?', `${items.length} Protokoll(e) werden endgültig gelöscht. Das kann nicht rückgängig gemacht werden.`, 'Endgültig löschen')) {
        for (const r of items) await destroyReport(r.id);
        toast('Papierkorb geleert'); load();
      }
    },
  }, icon('trash'), 'Papierkorb leeren');
  const el = viewShell('Papierkorb', null, emptyBtn,
    h('p', { class: 'v-note' }, `Gelöschte Protokolle bleiben ${TRASH_DAYS} Tage im Papierkorb und werden danach automatisch entfernt.`),
    list);
  async function load() {
    const items = await listTrash();
    list.innerHTML = '';
    if (!items.length) { list.appendChild(h('div', { class: 'empty-state' }, 'Der Papierkorb ist leer.')); return; }
    for (const r of items) {
      const left = Math.max(0, TRASH_DAYS - Math.floor((Date.now() - new Date(r.deletedAt).getTime()) / 86400000));
      list.appendChild(h('div', { class: 'list-item trash' },
        h('div', { class: 'main' },
          h('div', { class: 't1' }, formatWagonNumber(r.wagonNumber) || 'Ohne Wagennummer', r.reportId && h('span', { class: 'badge draft' }, `Nr. ${r.reportId}`)),
          h('div', { class: 't2' }, `Gelöscht am ${fmtDateTime(r.deletedAt)}${r.deletedBy ? ` von ${r.deletedBy}` : ''}`),
          h('div', { class: 't2 warn' }, left === 1 ? 'Wird morgen endgültig entfernt' : `Wird in ${left} Tagen endgültig entfernt`)),
        h('div', { class: 'trash-acts' },
          app.can('delete') && h('button', { class: 'pill-btn sm', onclick: async () => { await restoreReport(r.id); toast('Wiederhergestellt'); load(); app.onRestored && app.onRestored(r); } }, icon('restore'), 'Wiederherstellen'),
          app.can('trash') && h('button', {
            class: 'pill-btn sm danger', onclick: async () => {
              if (await confirmDialog('Endgültig löschen?', 'Das Protokoll und seine PDF werden unwiderruflich gelöscht.', 'Endgültig löschen')) { await destroyReport(r.id); toast('Endgültig gelöscht'); load(); }
            },
          }, 'Endgültig löschen'))));
    }
  }
  el.refresh = load;
  load();
  return el;
}

/* ================= Mitarbeiter ================= */

/* ---------- Mitarbeiterliste mit Buchstabenleiste A–Z ---------- */

const LETTERS = [...'ABCDEFGHIJKLMNOPQRSTUVWXYZ', '#'];
const letterOf = (e) => {
  const c = String(e.lastName || e.firstName || '').trim().charAt(0).toUpperCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
  return /^[A-Z]$/.test(c) ? c : '#';
};
const byLastName = (a, b) => (a.lastName || '').localeCompare(b.lastName || '', 'de', { sensitivity: 'base' })
  || (a.firstName || '').localeCompare(b.firstName || '', 'de', { sensitivity: 'base' });
const reduceMotion = () => window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

/* ---------- Karte „Protokolle“ mit Suchleiste ---------- */

const reportDay = (r) => r.detectionDate || (r.pdfCreatedAt || r.updatedAt || '').slice(0, 10);
const SORTS = {
  new: ['Neueste zuerst', (a, b) => reportDay(b).localeCompare(reportDay(a)) || (b.reportId || '').localeCompare(a.reportId || '', 'de', { numeric: true })],
};

/** Suchtext eines Protokolls: Wagennummer (mit/ohne Leerzeichen), Nr., Datum, Orte, Schadcodes, Halter. */
function reportHaystack(r) {
  const wagon = String(r.wagonNumber || '');
  return [
    wagon, formatWagonNumber(wagon), r.reportId, formatDate(r.detectionDate), r.detectionDate,
    r.detectionPlace, r.origin, r.destination, r.trainNumber, r.keeperName, codesOf(r),
  ].filter(Boolean).join(' ').toLowerCase();
}

/**
 * Karte „Protokolle“ im Mitarbeiterprofil. Jede Zeile hat dieselbe Symbolzeile wie „Gespeichert“:
 * Auge (Ansehen), Stift (Bearbeiten), Kalender, „⋯“ (Verschieben, Zuweisen, Teilen, Speichern), Papierkorb.
 * Klick auf die Zeile = Ansehen. Die Liste aktualisiert sich bei jeder Datenänderung selbst.
 */
function reportsCard(app, e, initialReports) {
  let reports = initialReports;
  const st = empState(e.id); // gemerkter Bildlaufstand und Suchbegriff dieses Mitarbeiters
  let restoring = true; // bis der gemerkte Stand wiederhergestellt ist, nichts überschreiben
  const sub = h('div', { class: 'dsub' });
  const list = h('div', { class: 'vlist compact rep-scroll', role: 'list' });
  const search = h('input', {
    type: 'search', class: 'v-search rep-search', placeholder: 'Wagennummer, Nr., Datum, Ort, Schadcode …',
    'aria-label': 'Protokolle dieses Mitarbeiters durchsuchen',
    oninput: () => { st.q = search.value; st.list = 0; saveEmpView(); draw(); list.scrollTop = 0; updateTop(); },
  });
  search.value = st.q || '';
  // Kleiner Knopf links neben der Suche: Liste wieder ganz nach oben
  const topBtn = h('button', {
    type: 'button', class: 'icon-btn rep-top', 'aria-label': 'Liste ganz nach oben', title: 'Ganz nach oben', disabled: true,
    onclick: () => list.scrollTo({ top: 0, behavior: reduceMotion() ? 'auto' : 'smooth' }),
  }, icon('arrowUp'));
  const updateTop = () => { topBtn.disabled = list.scrollTop < 4; };
  list.addEventListener('scroll', () => {
    updateTop();
    if (restoring || !list.isConnected) return;
    st.list = list.scrollTop; saveEmpView();
  }, { passive: true });
  const tools = h('div', { class: 'rep-tools' }, topBtn, search);
  const mark = (text, q) => {
    if (!q || !text) return text;
    const i = text.toLowerCase().indexOf(q);
    return i < 0 ? text : [text.slice(0, i), h('mark', null, text.slice(i, i + q.length)), text.slice(i + q.length)];
  };
  // Protokoll(e), an denen dieser Mitarbeiter gerade arbeitet (wie „Aktuelle Bearbeitung“) -> grüner Rahmen
  const liveIds = () => new Set(presenceFor(e.id).map((p) => p.reportUuid).filter(Boolean));
  const markLive = () => {
    const ids = liveIds();
    list.querySelectorAll('.rep-row').forEach((el) => {
      const on = ids.has(el.dataset.rid);
      el.classList.toggle('live', on);
      el.title = on ? 'Wird gerade bearbeitet (siehe „Aktuelle Bearbeitung“)' : '';
    });
  };
  const sig = (list) => list.map((r) => `${r.id}:${r.updatedAt}:${folderOf(app.settings, r.id)?.id || ''}`).join('|');
  let lastSig = sig(reports);
  let pendingReload = false;
  const reload = async () => {
    // Nicht neu zeichnen, solange ein Menü oder Dialog offen ist (sonst schließt es sich) – danach nachholen
    if (document.querySelector('.popmenu, .modal-bg')) {
      if (!pendingReload) { pendingReload = true; const t = setInterval(() => { if (!card.isConnected) { clearInterval(t); return; } if (!document.querySelector('.popmenu, .modal-bg')) { clearInterval(t); pendingReload = false; reload(); } }, 300); }
      return;
    }
    const next = (await listReports()).filter((r) => ownerOf(r, app.settings).employee?.id === e.id);
    const s2 = sig(next);
    if (s2 === lastSig) return; // nichts geändert -> Liste bleibt, wie sie ist
    reports = next; lastSig = s2;
    const top = list.scrollTop;
    draw();
    list.scrollTop = top;
  };
  function row(r, raw) {
    const canEdit = app.canEdit ? app.canEdit(r) : app.can('edit');
    const act = (name, label, fn, cls = '') => h('button', {
      type: 'button', class: `icon-btn sv-act ${cls}`, 'aria-label': label, title: label,
      onclick: (ev) => { ev.stopPropagation(); fn(ev.currentTarget); },
    }, icon(name));
    const view = () => (app.viewReport ? app.viewReport(r) : app.openReport(r.id, r));
    const folder = folderOf(app.settings, r.id);
    const isLive = liveIds().has(r.id);
    return h('div', { class: 'mini-row rep-row' + (isLive ? ' live' : ''), role: 'listitem', 'data-rid': r.id, title: isLive ? 'Wird gerade bearbeitet (siehe „Aktuelle Bearbeitung“)' : null },
      h('div', { class: 'rep-main', role: 'button', tabindex: '0', title: 'Ansehen', onclick: view,
        onkeydown: (ev) => { if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); view(); } } },
        h('span', { class: 'mr-n' }, mark(formatWagonNumber(r.wagonNumber) || 'Ohne Wagennummer', raw),
          r.status !== 'erstellt' && h('span', { class: 'badge draft' }, 'Entwurf'),
          h('span', { class: 'live-tag' }, h('span', { class: 'live-dot' }), 'Bearbeitet gerade')),
        h('span', { class: 'mr-s' }, mark([r.reportId && `Nr. ${r.reportId}`, formatDate(r.detectionDate), r.detectionPlace].filter(Boolean).join(' · '), raw)),
        folder && h('span', { class: 'sv-where' }, icon('folder'), `Eigener Ordner: ${folder.name}`)),
      h('div', { class: 'sv-acts' },
        act('eye', 'Ansehen', view, 'look'),
        canEdit && act('edit', 'Bearbeiten', () => app.openReport(r.id, r), 'edit'),
        app.extended && app.showInCalendar && r.detectionDate && act('calendar', 'Im Kalender zeigen', () => app.showInCalendar(r)),
        act('more', 'Weitere Aktionen', (b) => reportMenu(app, b, r, reload)),
        app.can('delete') && act('trash', 'In den Papierkorb', async () => {
          if (await confirmDialog('In den Papierkorb?', 'Das Protokoll wird in den Papierkorb verschoben und nach 30 Tagen automatisch gelöscht.', 'In den Papierkorb')) {
            await trashReport(r.id, fullName(activeEmployee(app.settings)));
            app.onTrashed && app.onTrashed(r);
            toast('In den Papierkorb verschoben');
            reload();
          }
        })));
  }
  function draw(minRows = 0) {
    const total = reports.length;
    tools.hidden = total === 0;
    const raw = search.value.trim().toLowerCase();
    const digits = raw.replace(/[\s-]/g, '');
    const words = raw.split(/\s+/).filter(Boolean);
    const hits = reports.filter((r) => {
      if (!raw) return true;
      const hay = reportHaystack(r);
      if (/^\d{3,}$/.test(digits) && String(r.wagonNumber || '').includes(digits)) return true;
      return words.every((w) => hay.includes(w));
    }).sort(SORTS.new[1]); // immer neueste zuerst
    sub.textContent = raw ? `${hits.length} von ${total} ${total === 1 ? 'Protokoll' : 'Protokollen'} von ${e.firstName || fullName(e)}` : `${total} ${total === 1 ? 'Protokoll' : 'Protokolle'} von ${e.firstName || fullName(e)}`;
    list.replaceChildren();
    if (hits.length) progressive(list, hits, (r) => row(r, raw), Math.max(30, minRows), 40);
    else list.appendChild(h('div', { class: 'd-empty' }, icon('doc'), h('p', null, total ? 'Kein Protokoll passt zur Suche.' : 'Diesem Mitarbeiter sind noch keine Protokolle zugeordnet.')));
  }
  // so viele Zeilen sofort aufbauen, dass der gemerkte Bildlaufstand erreichbar ist
  draw(st.list ? Math.ceil((st.list + 1200) / 50) : 0);
  const card = h('section', { class: 'dcard rep-card' },
    h('div', { class: 'dcard-head rep-head' }, h('div', null, h('h2', null, 'Protokolle'), sub), tools),
    list);
  // Bei jeder Datenänderung (Löschen, Zuweisen, Verschieben, Import …) neu einlesen, solange sichtbar
  const off = onDataChange(() => { if (!card.isConnected) { off(); return; } reload(); });
  const offLive = onPresenceChange(() => { if (!card.isConnected) { offLive(); return; } markLive(); });
  // Suchleiste rechts bündig mit den Kästen: Breite der Bildlaufleiste der Liste ausgleichen
  const align = () => { if (card.isConnected) card.style.setProperty('--sbw', `${list.offsetWidth - list.clientWidth}px`); };
  requestAnimationFrame(align);
  setTimeout(align, 300);
  /** Gemerkten Stand der Liste wiederherstellen (nach dem Einhängen aufrufen). */
  card.restoreScroll = () => { list.scrollTop = st.list || 0; updateTop(); };
  card.doneRestoring = () => { restoring = false; };
  return card;
}

// Bildlaufstand im Reiter „Mitarbeiter“: je Mitarbeiter Liste „Protokolle“ (list), Detailspalte (detail)
// und Suchbegriff (q), dazu die Seite (_win, schmale Fenster). Bleibt beim Wechsel zu Dashboard,
// Formular usw. erhalten (Sitzung, sessionStorage).
const EMP_VIEW_KEY = 'sw.empView.v1';
const empView = (() => { try { return JSON.parse(sessionStorage.getItem(EMP_VIEW_KEY)) || {}; } catch { return {}; } })();
let empViewTimer = 0;
function saveEmpView() {
  clearTimeout(empViewTimer);
  empViewTimer = setTimeout(() => { try { sessionStorage.setItem(EMP_VIEW_KEY, JSON.stringify(empView)); } catch { /* egal */ } }, 250);
}
function empState(id) {
  if (!empView[id] || typeof empView[id] !== 'object') empView[id] = {};
  return empView[id];
}

/** „⋯“-Menü eines Protokolls: Verschieben in eigene Ordner, Zuweisen, Teilen, Speichern. */
function reportMenu(app, anchor, r, onChange) {
  const cur = folderOf(app.settings, r.id);
  const move = async (folderId) => {
    app.saveFolders(moveToFolder(app.settings, r.id, folderId));
    const f = folderId && findFolder(app.settings, folderId);
    toast(f ? `In „${f.name}“ verschoben` : `Aus „${cur.name}“ entfernt`);
    onChange && onChange();
  };
  const items = [];
  if (app.can('folders')) {
    listFolders(app.settings).filter((f) => f.id !== cur?.id)
      .forEach((f) => items.push({ icon: 'folder', label: `Verschieben nach „${f.name}“`, sub: 'eigener Ordner', onClick: () => move(f.id) }));
    items.push({ icon: 'plus', label: 'In neuen Ordner …', onClick: async () => {
      const name = await nameDialog('Neuer Ordner', '', (n) => folderNameError(app.settings, n));
      if (!name) return;
      const { folders, folder } = addFolder(app.settings, name);
      app.saveFolders(folders);
      move(folder.id);
    } });
    if (cur) items.push({ icon: 'close', label: `Aus „${cur.name}“ entfernen`, sub: 'bleibt im Datumsordner', onClick: () => move(null) });
  }
  if (hasEmployees(app.settings) && app.can('edit')) {
    items.push({ icon: 'people', label: 'Zuweisen …', sub: 'anderem Mitarbeiter zuordnen', onClick: async () => { if (await assignDialog(app, r)) onChange && onChange(); } });
  }
  if (app.can('share')) {
    if (app.shareReport) items.push({ icon: 'share', label: 'Teilen', sub: 'E-Mail, WhatsApp …', onClick: () => app.shareReport(r, anchor) });
    if (app.saveReport) items.push({ icon: 'download', label: 'Speichern', sub: 'PDF herunterladen', onClick: () => app.saveReport(r) });
  }
  if (!items.length) { toast('Keine weiteren Aktionen erlaubt'); return; }
  popMenu(anchor, items, { title: 'Aktionen' });
}

/** app: { settings, can, openReport, openEditor, selectedEmployee } */
export function renderEmployees(app) {
  const s = app.settings;
  const emps = [...listEmployees(s)].sort(byLastName);
  const me = activeEmployee(s);
  const mayManage = app.can('employees');
  let selectedId = app.selectedEmployee || (me && me.id) || emps[0]?.id || null;

  const addBtn = (mayManage || !emps.length) && h('button', { class: 'btn primary add-emp', onclick: () => app.openEditor(null) }, icon('personAdd'), h('span', null, 'Mitarbeiter hinzufügen'));
  const fileIn = h('input', { type: 'file', accept: '.json,application/json', hidden: true,
    onchange: async (ev) => { const f = ev.target.files[0]; ev.target.value = ''; if (f) await app.importEmployees(f); } });
  const tools = mayManage && emps.length > 0 && [
    h('button', { class: 'pill-btn', onclick: () => fileIn.click(), title: 'Mitarbeiterliste (JSON) einlesen' }, icon('upload'), 'Importieren'),
    h('button', { class: 'pill-btn', onclick: () => app.exportEmployees(), title: 'Mitarbeiterliste ohne PINs als JSON speichern' }, icon('download'), 'Exportieren'),
    fileIn,
  ];
  const actions = [tools, addBtn].filter(Boolean);
  if (!emps.length) {
    return viewShell('Mitarbeiter', null, addBtn, h('div', { class: 'dcard emp-intro' },
      h('div', { class: 'd-empty' }, icon('people'),
        h('p', null, 'Noch keine Mitarbeiter angelegt. Der erste Mitarbeiter wird Administrator und übernimmt das bisherige Präfix und die laufende Nummer aus den Einstellungen.'))));
  }

  const detail = h('div', { class: 'emp-detail' });
  const scroller = h('div', { class: 'emp-scroll', role: 'list', 'aria-label': 'Mitarbeiter' });
  const bubble = h('div', { class: 'az-bubble', 'aria-hidden': 'true' });
  const rail = h('nav', { class: 'az-rail', 'aria-label': 'Mitarbeiter nach Anfangsbuchstabe' });
  const search = h('input', { type: 'search', class: 'v-search emp-search', placeholder: 'Mitarbeiter suchen', 'aria-label': 'Mitarbeiter suchen', oninput: () => filter() });
  const count = h('div', { class: 'emp-count' });
  const listCol = h('div', { class: 'emp-listcol' }, search, count, h('div', { class: 'emp-scrollwrap' }, scroller, rail, bubble));
  const layout = h('div', { class: 'emp-layout' }, listCol, detail);
  const el = viewShell('Mitarbeiter', `${emps.length} ${emps.length === 1 ? 'Person' : 'Personen'}`, actions, layout);

  // Zeilen nach Anfangsbuchstabe des Nachnamens gruppiert
  const rows = new Map();
  const groups = new Map();
  for (const e of emps) {
    const L = letterOf(e);
    if (!groups.has(L)) {
      const g = h('div', { class: 'az-group', 'data-letter': L }, h('div', { class: 'az-head', 'aria-hidden': 'true' }, L));
      groups.set(L, g);
      scroller.appendChild(g);
    }
    const row = h('button', {
      type: 'button', role: 'listitem', class: 'emp-row' + (e.active === false ? ' off' : ''), 'data-id': e.id,
      onclick: () => select(e.id, true),
    },
      avatar(e),
      h('span', { class: 'emp-txt' },
        h('span', { class: 'er-name' }, `${e.firstName || ''} `, h('b', null, e.lastName || ''), me && me.id === e.id && h('span', { class: 'me' }, 'Aktiv')),
        h('span', null, [e.title, e.active === false ? 'Deaktiviert' : roleLabel(e)].filter(Boolean).join(' · '))),
      e.prefix && h('span', { class: 'chip pre' }, normPrefix(e.prefix)));
    row._search = `${fullName(e)} ${e.lastName} ${e.title || ''} ${normPrefix(e.prefix)} ${e.email || ''}`.toLowerCase();
    rows.set(e.id, row);
    groups.get(L).appendChild(row);
  }

  // Abstand am Ende, damit auch die letzten Buchstaben ganz nach oben rollen
  const spacer = h('div', { class: 'emp-spacer', 'aria-hidden': 'true' });
  scroller.appendChild(spacer);
  function sizeSpacer() {
    const vis = [...groups.values()].filter((g) => !g.hidden);
    const last = vis[vis.length - 1];
    spacer.style.height = last ? `${Math.max(0, scroller.clientHeight - last.offsetHeight - 12)}px` : '0px';
  }

  // Buchstabenleiste
  const letterEls = new Map();
  for (const L of LETTERS) {
    const b = h('button', { type: 'button', class: 'az-l', 'data-letter': L, tabindex: '-1', 'aria-label': `Buchstabe ${L}` }, L);
    letterEls.set(L, b);
    rail.appendChild(b);
  }
  const available = () => LETTERS.filter((L) => groups.has(L) && !groups.get(L).hidden);
  function updateRail() {
    const av = new Set(available());
    letterEls.forEach((b, L) => { b.classList.toggle('dis', !av.has(L)); b.setAttribute('aria-disabled', String(!av.has(L))); b.tabIndex = av.has(L) ? 0 : -1; });
  }
  function jumpTo(L, smooth) {
    let target = groups.get(L);
    if (!target || target.hidden) {
      // wie im Telefonbuch: nächster vorhandener Buchstabe
      const av = available();
      const next = av.find((x) => LETTERS.indexOf(x) >= LETTERS.indexOf(L)) || av[av.length - 1];
      target = next && groups.get(next);
    }
    if (!target) return;
    scroller.scrollTo({ top: target.offsetTop - 4, behavior: smooth && !reduceMotion() ? 'smooth' : 'auto' });
  }
  function showBubble(L) {
    bubble.textContent = L;
    bubble.classList.add('show');
    const b = letterEls.get(L);
    const wrap = (bubble.offsetParent || scroller.parentElement).getBoundingClientRect();
    const r = b.getBoundingClientRect();
    bubble.style.top = `${r.top - wrap.top + r.height / 2}px`;
    clearTimeout(showBubble.t);
    showBubble.t = setTimeout(() => bubble.classList.remove('show'), 700);
  }
  // Vergrößerung wie beim Dock: Buchstaben in Zeigernähe werden größer
  function magnify(y) {
    const dir = rail.getBoundingClientRect().left > scroller.getBoundingClientRect().left + 40 ? -1 : 1;
    letterEls.forEach((b) => {
      const r = b.getBoundingClientRect();
      const d = Math.abs(r.top + r.height / 2 - y);
      const k = Math.max(0, 1 - d / 46);
      const sc = 1 + 0.75 * k;
      b.style.transform = k > 0 ? `translateX(${dir * k * 9}px) scale(${sc})` : '';
      b.style.zIndex = k > 0 ? String(Math.round(k * 10)) : '';
    });
  }
  const unmagnify = () => letterEls.forEach((b) => { b.style.transform = ''; b.style.zIndex = ''; });
  const letterAt = (x, y) => {
    const t = document.elementFromPoint(x, y);
    const b = t && t.closest && t.closest('.az-l');
    if (b) return b.dataset.letter;
    // außerhalb: nächster Buchstabe nach Höhe
    let best = null, bd = Infinity;
    letterEls.forEach((el2, L) => { const r = el2.getBoundingClientRect(); const d = Math.abs(r.top + r.height / 2 - y); if (d < bd) { bd = d; best = L; } });
    return best;
  };
  let drag = null;
  rail.addEventListener('pointerdown', (ev) => {
    const L = letterAt(ev.clientX, ev.clientY);
    if (!L) return;
    ev.preventDefault();
    rail.setPointerCapture(ev.pointerId);
    drag = { start: L, cur: L, moved: false };
    magnify(ev.clientY);
    showBubble(L);
  });
  rail.addEventListener('pointermove', (ev) => {
    magnify(ev.clientY);
    if (!drag) return;
    const L = letterAt(rail.getBoundingClientRect().left + rail.offsetWidth / 2, ev.clientY);
    if (L && L !== drag.cur) { drag.cur = L; drag.moved = true; jumpTo(L, false); showBubble(L); }
  });
  const endDrag = () => {
    if (drag && !drag.moved && !letterEls.get(drag.start).classList.contains('dis')) jumpTo(drag.start, true);
    drag = null;
  };
  rail.addEventListener('pointerup', (ev) => { endDrag(); if (ev.pointerType !== 'mouse') unmagnify(); });
  rail.addEventListener('pointercancel', () => { drag = null; unmagnify(); });
  rail.addEventListener('pointerleave', () => { if (!drag) unmagnify(); });
  rail.addEventListener('keydown', (ev) => {
    const b = ev.target.closest('.az-l');
    if (b && (ev.key === 'Enter' || ev.key === ' ')) { ev.preventDefault(); jumpTo(b.dataset.letter, true); }
  });

  // Heranzoomen: die Zeile in der Mitte der Liste wird etwas größer
  let raf = 0;
  function zoom() {
    raf = 0;
    const box = scroller.getBoundingClientRect();
    const mid = box.top + box.height / 2;
    const scrollable = scroller.scrollHeight > scroller.clientHeight + 4;
    let cur = null;
    rows.forEach((row) => {
      if (row.offsetParent === null) return;
      const r = row.getBoundingClientRect();
      const k = scrollable ? Math.max(0, 1 - Math.abs(r.top + r.height / 2 - mid) / (r.height * 1.6)) : 0;
      row.style.transform = k > 0.01 ? `scale(${(1 + 0.06 * k).toFixed(4)})` : '';
      row.classList.toggle('focus', k > 0.6);
    });
    for (const [L, g] of groups) {
      if (g.hidden) continue;
      if (g.offsetTop + g.offsetHeight > scroller.scrollTop + 8) { cur = L; break; }
    }
    letterEls.forEach((b, L) => b.classList.toggle('cur', L === cur));
  }
  const queueZoom = () => { if (!raf) raf = requestAnimationFrame(zoom); };
  scroller.addEventListener('scroll', queueZoom, { passive: true });
  const onResize = () => { if (!el.isConnected) { window.removeEventListener('resize', onResize); return; } sizeSpacer(); queueZoom(); };
  window.addEventListener('resize', onResize);

  function filter() {
    const q = search.value.trim().toLowerCase();
    let n = 0;
    rows.forEach((row) => { const on = !q || row._search.includes(q); row.hidden = !on; if (on) n++; });
    groups.forEach((g) => { g.hidden = ![...g.querySelectorAll('.emp-row')].some((r) => !r.hidden); });
    count.textContent = q ? `${n} von ${emps.length} Mitarbeitern` : '';
    if (!n) { if (!scroller.querySelector('.emp-none')) scroller.appendChild(h('div', { class: 'emp-none' }, 'Kein Mitarbeiter gefunden.')); }
    else scroller.querySelector('.emp-none')?.remove();
    updateRail();
    sizeSpacer();
    queueZoom();
  }

  function select(id, user) {
    selectedId = id; app.selectedEmployee = id;
    rows.forEach((row, rid) => row.classList.toggle('sel', rid === id));
    drawDetail();
    if (user && window.matchMedia('(max-width: 999px)').matches) setTimeout(() => detail.scrollIntoView({ behavior: reduceMotion() ? 'auto' : 'smooth', block: 'start' }), 30);
  }

  async function drawDetail() {
    const e = findEmployee(s, selectedId);
    if (!e) { detail.innerHTML = ''; return; }
    const reports = (await listReports()).filter((r) => ownerOf(r, s).employee?.id === e.id);
    if (!el.isConnected && drawn) return;
    const st = empState(e.id);
    const first = !drawn; drawn = true;
    detailRestoring = true;
    const kv = (label, value, extra) => h('div', { class: 'kv' }, h('dt', null, label), h('dd', { class: extra ? 'with-btn' : '' }, value || '—', extra));
    detail.replaceChildren(
      h('section', { class: 'dcard' },
        h('div', { class: 'dcard-head' },
          h('div', { class: 'emp-head' }, avatar(e, 'lg'),
            h('div', null, h('h2', null, fullName(e)), h('div', { class: 'dsub' }, [e.title, e.active === false ? 'Deaktiviert' : roleLabel(e)].filter(Boolean).join(' · ')))),
          mayManage && h('button', { class: 'pill-btn', onclick: () => app.openEditor(e) }, icon('edit'), 'Bearbeiten')),
        h('dl', { class: 'kvs' },
          kv('Protokoll-Präfix', normPrefix(e.prefix)),
          kv('Nächste laufende Nummer', String(e.nextNumber || 1)),
          kv('E-Mail', e.email, e.email && copyButton(() => e.email)),
          kv('Telefon', e.phone),
          kv('PIN', e.pinHash ? 'festgelegt' : 'noch nicht festgelegt – wird bei der ersten Anmeldung vergeben')),
        h('h3', { class: 'd-sec' }, 'Berechtigungen'),
        h('ul', { class: 'perm-view' }, PERMS.map(([k, label]) => h('li', { class: hasPerm(e.perms, k) ? 'yes' : 'no' }, h('span', { class: 'pv-dot' }), label)))),
      presenceSlot,
      repCard = reportsCard(app, e, reports));
    drawPresence();
    // gemerkten Bildlaufstand wiederherstellen: Liste, Detailspalte und (beim Zurückkommen) die Seite
    const card = repCard;
    requestAnimationFrame(() => {
      card.restoreScroll();
      detail.scrollTop = st.detail || 0;
      if (first && empView._win) window.scrollTo(0, empView._win);
      requestAnimationFrame(() => { detailRestoring = false; card.doneRestoring(); });
    });
  }
  let drawn = false;
  let detailRestoring = true;
  let repCard = null;
  detail.addEventListener('scroll', () => {
    if (detailRestoring || !detail.isConnected || !selectedId) return;
    empState(selectedId).detail = detail.scrollTop; saveEmpView();
  }, { passive: true });
  const onWinScroll = () => {
    if (!el.isConnected) { window.removeEventListener('scroll', onWinScroll); return; }
    if (detailRestoring) return;
    empView._win = window.scrollY; saveEmpView();
  };
  window.addEventListener('scroll', onWinScroll, { passive: true });

  // Live-Anzeige: bei jeder Meldung und alle 20 Sekunden (relative Zeiten, Abruf vom Server)
  const presenceSlot = h('div', { class: 'presence-slot' });
  function drawPresence() {
    const e = findEmployee(s, selectedId);
    if (e) presenceSlot.replaceChildren(presenceCard(app, e));
    rows.forEach((row, id) => row.classList.toggle('working', presenceFor(id).length > 0));
  }
  const offPresence = onPresenceChange(() => { if (!el.isConnected) { offPresence(); return; } drawPresence(); });
  const presenceTick = setInterval(() => {
    if (!el.isConnected) { clearInterval(presenceTick); offPresence(); return; }
    refreshPresence().finally(drawPresence);
  }, 20000);
  refreshPresence().finally(drawPresence);

  updateRail();
  select(selectedId, false);
  // nach dem Einhängen: gewählten Mitarbeiter in die Mitte holen und Zoom berechnen
  requestAnimationFrame(() => {
    sizeSpacer();
    const row = rows.get(selectedId);
    if (row && scroller.scrollHeight > scroller.clientHeight) scroller.scrollTop = Math.max(0, row.offsetTop - scroller.clientHeight / 2 + row.offsetHeight / 2);
    zoom();
  });
  return el;
}

/** Mitarbeiter anlegen oder bearbeiten. onSave(employee) wird nach erfolgreicher Prüfung aufgerufen. */
export function openEmployeeEditor(app, existing, { sheetShell, onSave, onDelete }) {
  const s = app.settings;
  const first = !listEmployees(s).length;
  const e = existing ? JSON.parse(JSON.stringify(existing)) : {
    id: crypto.randomUUID ? crypto.randomUUID() : `e${Date.now()}`,
    firstName: '', lastName: '', title: '', email: '', phone: '',
    prefix: first ? normPrefix(s.reportPrefix) : '',
    nextNumber: first ? Number(s.nextNumber) || 1 : 1,
    perms: { ...(first ? TEMPLATES.admin : TEMPLATES.editor).perms },
    active: true, createdAt: new Date().toISOString(),
  };
  let pin = '', pin2 = '';
  const errBox = h('div', { class: 'form-err', role: 'alert' });
  const inp = (key, label, opts = {}) => {
    const id = `emp-${key}`;
    const input = h('input', {
      id, type: opts.type || 'text', inputmode: opts.inputmode, autocomplete: 'off', placeholder: opts.placeholder || 'Eingeben',
      list: opts.list, maxlength: opts.maxlength,
      oninput: (ev) => { e[key] = opts.number ? Math.max(1, parseInt(ev.target.value.replace(/\D/g, '') || '1', 10)) : ev.target.value; },
    });
    input.value = e[key] ?? '';
    return h('div', { class: 'field' }, h('label', { class: 'label', for: id }, label),
      h('div', { class: 'row' }, input, opts.trailing), opts.help && h('div', { class: 'msg small' }, opts.help));
  };
  const titles = h('datalist', { id: 'emp-titles' }, TITLES.map((t) => h('option', { value: t })));

  // Vorlagen + Schalter
  const permBox = h('div', { class: 'perm-edit' });
  const seg = h('div', { class: 'seg seg-wide', role: 'radiogroup', 'aria-label': 'Vorlage' });
  const drawPerms = () => {
    const role = roleOf(e.perms);
    seg.innerHTML = '';
    Object.entries(TEMPLATES).forEach(([k, t]) => seg.appendChild(h('button', {
      type: 'button', role: 'radio', 'aria-checked': String(role === k), class: role === k ? 'on' : '',
      disabled: first && k !== 'admin',
      onclick: () => { e.perms = { ...t.perms }; drawPerms(); },
    }, t.label)));
    permBox.innerHTML = '';
    PERMS.forEach(([k, label]) => {
      const cb = h('input', { type: 'checkbox', checked: hasPerm(e.perms, k), disabled: first, onchange: (ev) => { e.perms[k] = ev.target.checked; drawPerms(); } });
      permBox.appendChild(h('label', { class: 'toggle-row' }, h('span', { class: 'switch' }, cb, h('span')), label));
    });
    roleNote.textContent = role === 'custom' ? 'Eigene Zusammenstellung' : first ? 'Der erste Mitarbeiter ist immer Administrator.' : '';
  };
  const roleNote = h('p', { class: 'small', style: { margin: '8px 2px 0' } });
  const activeCb = h('input', { type: 'checkbox', checked: e.active !== false, onchange: (ev) => { e.active = ev.target.checked; } });
  const pinField = (label, setter, id) => h('div', { class: 'field' }, h('label', { class: 'label', for: id }, label),
    h('input', { id, type: 'password', inputmode: 'numeric', autocomplete: 'new-password', maxlength: 8, placeholder: '4–8 Ziffern',
      oninput: (ev) => { ev.target.value = ev.target.value.replace(/\D/g, ''); setter(ev.target.value); } }));

  async function save() {
    const errs = [];
    e.firstName = String(e.firstName || '').trim(); e.lastName = String(e.lastName || '').trim();
    e.email = String(e.email || '').trim(); e.prefix = normPrefix(e.prefix);
    if (!e.firstName || !e.lastName) errs.push('Vor- und Nachname angeben.');
    if (e.email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e.email)) errs.push('E-Mail-Adresse ist ungültig.');
    if (!e.prefix) errs.push('Protokoll-Präfix angeben, z. B. B13H09.');
    else if (!/^[A-Z0-9][A-Z0-9-]{0,19}$/.test(e.prefix)) errs.push('Präfix: nur Buchstaben, Ziffern und Bindestrich.');
    else if (prefixTaken(s, e.prefix, e.id)) errs.push(`Das Präfix ${e.prefix} ist bereits vergeben.`);
    if (!existing || pin || pin2) {
      if (!validPin(pin)) errs.push('PIN mit 4 bis 8 Ziffern festlegen.');
      else if (pin !== pin2) errs.push('Die beiden PIN-Eingaben stimmen nicht überein.');
    }
    if (existing && wouldLoseAdmin(s, e)) errs.push('Mindestens ein aktiver Mitarbeiter muss „Mitarbeiter verwalten“ behalten.');
    if (errs.length) { errBox.replaceChildren(h('ul', null, errs.map((x) => h('li', null, x)))); errBox.scrollIntoView({ block: 'nearest' }); return; }
    // Keine Nummer doppelt vergeben: höchste vorhandene Nummer mit diesem Präfix berücksichtigen
    const used = maxUsedNumber(e.prefix, await listReports());
    if (used >= (Number(e.nextNumber) || 1)) e.nextNumber = used + 1;
    if (pin) { e.pinSalt = newSalt(); e.pinHash = await hashPin(pin, e.pinSalt); }
    e.updatedAt = new Date().toISOString();
    await onSave(e, { first });
    close();
  }

  const close = sheetShell(existing ? 'Mitarbeiter bearbeiten' : 'Mitarbeiter hinzufügen', () => close(),
    titles,
    h('section', { class: 'card' }, h('h2', null, 'Person'),
      inp('firstName', 'Vorname'), inp('lastName', 'Nachname'),
      inp('title', 'Positionstitel', { list: 'emp-titles', placeholder: 'z. B. Wagenmeister, Disponent' }),
      inp('email', 'E-Mail', { type: 'email', trailing: copyButton(() => e.email) }),
      inp('phone', 'Telefon', { type: 'tel' })),
    h('section', { class: 'card' }, h('h2', null, 'Protokollnummer'),
      inp('prefix', 'Protokoll-Präfix', { placeholder: 'z. B. B13H09', maxlength: 20, help: 'Nummer = Präfix/laufende Nummer, z. B. B13H09/316. Jedes Präfix nur einmal.' }),
      inp('nextNumber', 'Nächste laufende Nummer', { inputmode: 'numeric', number: true })),
    h('section', { class: 'card' }, h('h2', null, existing ? 'PIN ändern' : 'PIN'),
      existing && h('p', { class: 'small', style: { margin: '0 2px 6px' } }, 'Leer lassen, um die bisherige PIN zu behalten.'),
      pinField(existing ? 'Neue PIN' : 'PIN', (v) => { pin = v; }, 'emp-pin'),
      pinField('PIN wiederholen', (v) => { pin2 = v; }, 'emp-pin2')),
    h('section', { class: 'card' }, h('h2', null, 'Berechtigungen'), seg, roleNote, permBox),
    !first && h('section', { class: 'card' }, h('h2', null, 'Status'),
      h('label', { class: 'toggle-row' }, h('span', { class: 'switch' }, activeCb, h('span')), 'Aktiv (kann ausgewählt werden)')),
    errBox,
    h('div', { class: 'editor-actions' },
      existing && onDelete && h('button', {
        class: 'btn danger', onclick: async () => {
          const gone = { ...e, deleted: true };
          if (wouldLoseAdmin(s, gone)) { alertDialog('Löschen nicht möglich', 'Mindestens ein aktiver Mitarbeiter muss „Mitarbeiter verwalten“ behalten.'); return; }
          if (await confirmDialog('Mitarbeiter löschen?', `${fullName(e)} wird entfernt. Seine Protokolle bleiben erhalten und werden als „nicht zugeordnet“ angezeigt.`, 'Löschen')) {
            await onDelete(e); close();
          }
        },
      }, 'Löschen'),
      h('button', { class: 'btn', onclick: () => close() }, 'Abbrechen'),
      h('button', { class: 'btn primary', onclick: save }, 'Speichern')));
  drawPerms();
}

/* ================= Mitarbeiterwechsel mit PIN ================= */

/** Liefert den gewählten Mitarbeiter nach richtiger PIN (oder null). onLock() sperrt. */
export function openSwitcher(app, { preselect, onPick, onLock, onSetPin, force = false } = {}) {
  const s = app.settings;
  const emps = activeList(s);
  const me = activeEmployee(s);
  const bg = h('div', { class: 'modal-bg' });
  const close = () => { bg.remove(); document.removeEventListener('keydown', esc); };
  const esc = (ev) => { if (ev.key === 'Escape' && !force) close(); };
  document.addEventListener('keydown', esc);
  const box = h('div', { class: 'modal switcher', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Mitarbeiter wählen' });
  bg.appendChild(box);
  bg.addEventListener('click', (ev) => { if (ev.target === bg && !force) close(); });

  function drawList() {
    box.replaceChildren(
      h('h3', null, 'Mitarbeiter wählen'),
      h('p', null, force ? 'Bitte anmelden, um Protokolle zu erstellen oder zu bearbeiten.' : 'Wechsel nur mit der PIN des Mitarbeiters.'),
      h('div', { class: 'sw-list' }, emps.map((e) => h('button', {
        type: 'button', class: 'sw-item' + (me && me.id === e.id ? ' on' : ''), onclick: () => drawPin(e),
      }, avatar(e), h('span', { class: 'emp-txt' }, h('b', null, fullName(e)), h('span', null, [e.title, normPrefix(e.prefix)].filter(Boolean).join(' · '))),
        !e.pinHash && h('span', { class: 'chip new-pin' }, 'PIN festlegen'), icon('right')))),
      h('div', { class: 'actions' },
        me && h('button', { class: 'btn', onclick: () => { close(); onLock && onLock(); } }, icon('lock'), ' Sperren'),
        h('button', { class: 'btn', onclick: () => close() }, force ? 'Nur ansehen' : 'Abbrechen')));
  }
  // Erste Anmeldung: Mitarbeiter ohne PIN (z. B. importiert) legen ihre PIN selbst fest
  function drawNewPin(e) {
    const msg = h('div', { class: 'pin-msg', role: 'alert' });
    const mk = (label) => h('input', { type: 'password', inputmode: 'numeric', autocomplete: 'new-password', maxlength: 8, class: 'pin-input', 'aria-label': label,
      oninput: (ev) => { ev.target.value = ev.target.value.replace(/\D/g, ''); }, onkeydown: (ev) => { if (ev.key === 'Enter') go(); } });
    const p1 = mk('Neue PIN'), p2 = mk('PIN wiederholen');
    const go = async () => {
      if (!validPin(p1.value)) { msg.textContent = 'Die PIN braucht 4 bis 8 Ziffern.'; return; }
      if (p1.value !== p2.value) { msg.textContent = 'Die beiden Eingaben stimmen nicht überein.'; p2.value = ''; p2.focus(); return; }
      const salt = newSalt();
      const hash = await hashPin(p1.value, salt);
      if (onSetPin) await onSetPin(e, { pinSalt: salt, pinHash: hash });
      markUnlocked(e.id); close(); onPick && onPick(e);
    };
    box.replaceChildren(
      h('div', { class: 'pin-head' }, avatar(e, 'lg'), h('div', null, h('h3', null, fullName(e)), h('p', null, 'Erste Anmeldung – bitte eine eigene PIN festlegen.'))),
      h('label', { class: 'label' }, 'Neue PIN (4–8 Ziffern)'), p1,
      h('label', { class: 'label', style: { marginTop: '10px' } }, 'PIN wiederholen'), p2, msg,
      h('div', { class: 'actions' },
        h('button', { class: 'btn', onclick: drawList }, 'Zurück'),
        h('button', { class: 'btn', onclick: go }, 'PIN speichern')));
    setTimeout(() => p1.focus(), 30);
  }
  function drawPin(e) {
    if (!e.pinHash) { drawNewPin(e); return; }
    const msg = h('div', { class: 'pin-msg', role: 'alert' });
    const input = h('input', { type: 'password', inputmode: 'numeric', autocomplete: 'off', maxlength: 8, class: 'pin-input', 'aria-label': `PIN für ${fullName(e)}`,
      oninput: (ev) => { ev.target.value = ev.target.value.replace(/\D/g, ''); },
      onkeydown: (ev) => { if (ev.key === 'Enter') go(); } });
    const go = async () => {
      const wait = pinLockedFor(e.id);
      if (wait) { msg.textContent = `Zu viele Fehlversuche – bitte ${wait} s warten.`; return; }
      if (await verifyPin(e, input.value)) {
        pinOk(e.id); markUnlocked(e.id); close(); onPick && onPick(e);
      } else {
        pinFailed(e.id); input.value = ''; input.focus();
        const w = pinLockedFor(e.id);
        msg.textContent = w ? `Zu viele Fehlversuche – bitte ${w} s warten.` : 'PIN ist falsch.';
        box.classList.remove('shake'); void box.offsetWidth; box.classList.add('shake');
      }
    };
    box.replaceChildren(
      h('div', { class: 'pin-head' }, avatar(e, 'lg'), h('div', null, h('h3', null, fullName(e)), h('p', null, e.title || ''))),
      h('label', { class: 'label' }, 'PIN eingeben'), input, msg,
      h('div', { class: 'actions' },
        emps.length > 1 || !force ? h('button', { class: 'btn', onclick: drawList }, 'Zurück') : null,
        h('button', { class: 'btn', onclick: go }, 'Anmelden')));
    setTimeout(() => input.focus(), 30);
  }
  const pre = preselect && emps.find((e) => e.id === preselect);
  if (pre) drawPin(pre); else drawList();
  document.body.appendChild(bg);
  return close;
}

/* ================= Anmeldung am Server ================= */

export function renderLogin(app) {
  const body = h('div', { class: 'login-body' });
  const el = viewShell('Anmeldung', serverBase(), null, h('section', { class: 'dcard login-card' }, body));
  let pwVisible = false;
  function draw() {
    if (conn.status !== 'ok') {
      body.replaceChildren(h('div', { class: 'd-empty' }, icon('cloud'), h('p', null, conn.message || 'Keine Verbindung zum Server.')),
        h('button', { class: 'btn', onclick: async () => { await checkConnection(); draw(); } }, 'Verbindung prüfen'));
      return;
    }
    if (!conn.loginRequired) {
      body.replaceChildren(h('div', { class: 'login-state ok' }, icon('key'), h('div', null, h('b', null, 'Verbunden'), h('p', null, 'Dieser Server verlangt keine Anmeldung.'))));
      return;
    }
    if (conn.loggedIn) {
      body.replaceChildren(
        h('div', { class: 'login-state ok' }, icon('key'), h('div', null, h('b', null, 'Angemeldet'),
          h('p', null, conn.expiresAt ? `Gültig bis ${fmtDateTime(conn.expiresAt)}` : 'Die Anmeldung bleibt auf diesem Gerät gespeichert.'))),
        h('button', { class: 'btn', onclick: async () => { await logout(); toast('Abgemeldet'); draw(); app.onLoginChange && app.onLoginChange(); } }, 'Abmelden'));
      return;
    }
    const msg = h('div', { class: 'form-err', role: 'alert' });
    const pw = h('input', { id: 'login-pw', type: 'password', autocomplete: 'current-password', placeholder: 'Passwortschlüssel',
      onkeydown: (ev) => { if (ev.key === 'Enter') go(); } });
    const eye = h('button', { type: 'button', class: 'square-btn', 'aria-label': 'Passwortschlüssel anzeigen', 'data-keep': '',
      onclick: () => { pwVisible = !pwVisible; pw.type = pwVisible ? 'text' : 'password'; eye.replaceChildren(icon(pwVisible ? 'eyeOff' : 'eye')); } }, icon('eye'));
    const btn = h('button', { class: 'btn primary', onclick: () => go() }, 'Anmelden');
    async function go() {
      if (!pw.value) { msg.textContent = 'Bitte den Passwortschlüssel eingeben.'; return; }
      btn.disabled = true; msg.textContent = '';
      const r = await login(pw.value);
      pw.value = ''; btn.disabled = false;
      if (r.ok) { toast('Angemeldet'); draw(); app.onLoginChange && app.onLoginChange(); } else msg.textContent = r.message;
    }
    body.replaceChildren(
      h('div', { class: 'login-state' }, icon('lock'), h('div', null, h('b', null, 'Nicht angemeldet'), h('p', null, 'Der Server verlangt einen Passwortschlüssel. Er wird nicht gespeichert – nur die Anmeldung.'))),
      h('div', { class: 'field' }, h('label', { class: 'label', for: 'login-pw' }, 'Passwortschlüssel'), h('div', { class: 'row' }, pw, eye)),
      msg, btn);
    setTimeout(() => pw.focus(), 30);
  }
  draw();
  const off = onConnChange(() => { if (!el.isConnected) { off(); return; } if (!body.querySelector('#login-pw:focus')) draw(); });
  return el;
}

/* ================= Latenz-Anzeige ================= */

const STATUS_TEXT = {
  ok: 'Verbunden', checking: 'Wird geprüft …', insecure: 'Nur https:// erlaubt', bad_url: 'Adresse ungültig', bad_ip: 'IP-Adresse ungültig',
  bad_port: 'Port ungültig', http_public: 'http nur im lokalen Netz', http_confirm: 'http nicht bestätigt',
  bad_token: 'API-Token ungültig', unreachable: 'Nicht erreichbar', refused: 'Port nicht erreichbar', timeout: 'Zeitüberschreitung',
  dns: 'Adresse unbekannt', cert_untrusted: 'Zertifikat nicht vertrauenswürdig', cert_changed: 'Zertifikat geändert – gesperrt',
  tls: 'TLS-Fehler', not_schadwagen: 'Kein TrainTrace-Server', none: 'Kein Server eingetragen',
};

export function latencyBadge() {
  const el = h('button', { type: 'button', class: 'lat', 'aria-live': 'polite', onclick: () => latencyDetails() });
  const draw = () => {
    el.hidden = conn.status === 'none';
    const lvl = latencyLevel();
    el.className = `lat lat-${lvl}`;
    const label = lvl === 'off' ? (conn.status === 'checking' ? '…' : 'getrennt') : `${conn.latency} ms`;
    el.replaceChildren(h('span', { class: 'lat-dot' }), h('span', null, label));
    el.setAttribute('aria-label', `Server-Latenz: ${label}. Details anzeigen`);
  };
  draw();
  onConnChange(draw);
  return el;
}

export function latencyDetails() {
  const hist = conn.history.filter((x) => x != null);
  const avg = hist.length ? Math.round(hist.reduce((a, b) => a + b, 0) / hist.length) : null;
  const row = (k, v) => h('div', { class: 'kv' }, h('dt', null, k), h('dd', null, v ?? '—'));
  const bg = h('div', { class: 'modal-bg', onclick: (e) => { if (e.target === bg) bg.remove(); } },
    h('div', { class: 'modal', role: 'dialog', 'aria-modal': 'true' },
      h('h3', null, 'Server-Verbindung'),
      h('dl', { class: 'kvs one' },
        row('Verbindungsart', conn.endpoint ? conn.endpoint.label : '—'),
        row('Adresse', serverBase() || '—'),
        row('Zertifikat', !conn.endpoint ? '—' : conn.endpoint.scheme === 'http' ? 'unverschlüsselt (nur lokales Netz, bestätigt)'
          : conn.endpoint.pin ? `eigenes Zertifikat bestätigt (${conn.endpoint.pin.slice(0, 11)} … ${conn.endpoint.pin.slice(-11)})` : 'vom System geprüft'),
        conn.endpoint && row('Weg', conn.endpoint.transport === 'native' ? 'über die App (Pinning/IP)' : 'direkt'),
        row('Status', `${STATUS_TEXT[conn.status] || conn.status}${conn.message && conn.status !== 'ok' ? ` – ${conn.message}` : ''}`),
        row('Latenz aktuell', conn.latency != null && conn.status === 'ok' ? `${conn.latency} ms` : 'getrennt'),
        row('Durchschnitt / Min / Max', hist.length ? `${avg} / ${Math.min(...hist)} / ${Math.max(...hist)} ms (${hist.length} Messungen)` : '—'),
        row('Letzte Messung', conn.lastCheck ? conn.lastCheck.toLocaleTimeString('de-DE') : '—'),
        row('Anmeldung', !conn.loginRequired ? 'nicht erforderlich' : conn.loggedIn ? `angemeldet${conn.expiresAt ? ` bis ${fmtDateTime(conn.expiresAt)}` : ''}` : 'nicht angemeldet'),
        row('Server-Version', conn.version || '—')),
      hist.length > 1 && sparkline(hist),
      h('p', { class: 'small' }, 'Gemessen alle 15 Sekunden · grün unter 150 ms, gelb bis 500 ms, rot darüber.'),
      h('div', { class: 'actions' },
        h('button', { class: 'btn', onclick: async () => { await checkConnection(); bg.remove(); latencyDetails(); } }, 'Jetzt messen'),
        h('button', { class: 'btn', onclick: () => bg.remove() }, 'Schließen'))));
  document.body.appendChild(bg);
}

function sparkline(vals) {
  const w = 300, hgt = 46, max = Math.max(200, ...vals);
  const pts = vals.map((v, i) => `${(i / (vals.length - 1)) * w},${hgt - (v / max) * (hgt - 6) - 3}`).join(' ');
  const ns = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(ns, 'svg');
  svg.setAttribute('viewBox', `0 0 ${w} ${hgt}`); svg.setAttribute('class', 'spark'); svg.setAttribute('aria-hidden', 'true');
  const pl = document.createElementNS(ns, 'polyline');
  pl.setAttribute('points', pts);
  svg.appendChild(pl);
  return svg;
}
