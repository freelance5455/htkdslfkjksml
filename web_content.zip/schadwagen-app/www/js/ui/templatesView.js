// Ansicht „Vorlagen“ (Seitenleiste zwischen „Gespeichert“ und „Papierkorb“): aufgebaut wie „Gespeichert“,
// aber ohne Datumsordner – eine durchsuchbare Liste. Je Vorlage: Auge (Ansehen), Stift (neues Protokoll
// aus der Vorlage), „⋯“ (Vorlage bearbeiten, Duplizieren, PDF speichern) und Löschen – ohne Kalender
// (Wunsch des Nutzers, 25.10.2026). Oben: „Neue Vorlage“ und „Importieren“ (PDF, auch mehrere oder per Ziehen).
import { h, icon, toast, busy, confirmDialog, alertDialog, popMenu, modal } from './dom.js';
import { sheetShell } from './screens.js';
import { listTemplates, deleteTemplate, putTemplate, listReports, onDataChange } from '../storage.js';
import { importTemplateFiles, templateHaystack, byName, filledCount, suggestName, buildExportZip } from '../templates.js';

const countText = (n) => `${n} Vorlage${n === 1 ? '' : 'n'}`;

/** Bezeichnungen der Felder (für Hinweise, welche weiteren Angaben eine Vorlage enthält). */
const LABELS = {
  wagonNumber: 'Wagennummer', trainNumber: 'Zugnummer', consignmentNumber: 'Sendungsnummer',
  detectionPlace: 'Ort der Feststellung', detectionDate: 'Feststellungsdatum', origin: 'Versandbahnhof',
  destination: 'Bestimmungsbahnhof', departureDate: 'Abfahrtsdatum', loadingStatus: 'Beladezustand',
  keeperVkm: 'Halternummer', keeperName: 'Haltername', keeperAddress: 'Halteradresse', keeperEmail: 'Halter-E-Mail',
  damages: 'Schäden', existingLabels: 'Vorhandene Bezettelung', existingDate: 'Datum Bezettelung', existingRuNr: 'EVU-Nr. Bezettelung',
  existingRuName: 'EVU Bezettelung', newLabels: 'Neue Bezettelung', wagonDetached: 'Wagen ausgesetzt', workshop: 'Werkstattzuführung',
  takeover: 'Übernahme', takeoverNr: 'Übergebendes EVU (Nr.)', takeoverName: 'Übergebendes EVU', cause: 'Schadensursache',
  perpetrator: 'Verursacher', contactName: 'Kontakt', contactEmail: 'Kontakt-E-Mail', contactPhone: 'Kontakt-Telefon',
  remarks: 'Bemerkungen', attachments: 'Anlagen', detectionPlaceCode: 'Ort (Code)', originCode: 'Versandbahnhof (Code)', destinationCode: 'Bestimmungsbahnhof (Code)',
};
/** Im Bearbeiten-Dialog direkt änderbare Felder */
const EDIT_FIELDS = [
  ['Wagenhalter', [['keeperVkm', 'Halternummer (RICS/VKM)', { digits: 4, inputmode: 'numeric', placeholder: 'z. B. 4132' }], ['keeperName', 'Name / VKM'], ['keeperAddress', 'Adresse', { area: true }], ['keeperEmail', 'E-Mail', { type: 'email' }]]],
  ['Weitere Angaben', [['consignmentNumber', 'Sendungsnummer', { placeholder: 'leer = „Unbekannt“' }], ['remarks', 'Bemerkungen', { area: true }], ['attachments', 'Anlagen beigefügt', { check: true }]]],
  ['Kontakt des EVU', [['contactName', 'Name'], ['contactEmail', 'E-Mail', { type: 'email' }], ['contactPhone', 'Telefon', { type: 'tel' }]]],
];
const EDIT_KEYS = new Set(EDIT_FIELDS.flatMap(([, fs]) => fs.map(([k]) => k)));

export function renderTemplates(app) {
  const mayManage = app.can('templates');
  const body = h('div', { class: 'sv-body' });
  const info = h('div', { class: 'sv-crumbs tp-info' });
  const search = h('input', { type: 'search', class: 'v-search', placeholder: 'Vorlagen durchsuchen (Halter, Halternummer, Adresse, E-Mail …)', 'aria-label': 'Vorlagen durchsuchen', oninput: () => draw() });
  const fileIn = h('input', { type: 'file', accept: '.pdf,.json,.zip,application/pdf,application/json,application/zip', multiple: true, hidden: true,
    onchange: async (e) => { const files = [...e.target.files]; e.target.value = ''; if (files.length) await doImport(files); } });
  // Gesamten Bestand exportieren: ZIP mit je einer PDF pro Vorlage und „vorlagen.json“ (über „Importieren“ wieder einlesbar)
  const exportBtn = (mayManage || app.can('share')) && h('button', { class: 'pill-btn', onclick: () => doExport() }, icon('download'), 'Exportieren');
  const actions = mayManage ? [
    h('button', { class: 'pill-btn', onclick: () => editTemplate(null) }, icon('plus'), 'Neue Vorlage'),
    h('button', { class: 'pill-btn', onclick: () => fileIn.click() }, icon('upload'), 'Importieren'),
    exportBtn,
    fileIn,
  ] : (exportBtn ? [exportBtn] : null);
  const el = h('div', { class: 'view tp-view' },
    h('div', { class: 'view-head' }, h('div', null, h('h1', null, 'Vorlagen')), actions && h('div', { class: 'view-actions' }, actions)),
    h('div', { class: 'v-filters' }, search),
    info, body);

  let templates = [];
  let usage = new Map(); // templateId -> { count } (Anzeige „N Protokolle erstellt“)

  async function doExport() {
    if (!templates.length) { toast('Keine Vorlagen zum Exportieren'); return; }
    const stop = busy(`${countText(templates.length)} werden exportiert …`);
    try {
      const { bytes, count } = await buildExportZip((t) => app.templatePdfBytes(t));
      const d = new Date(); const p = (n) => String(n).padStart(2, '0');
      const name = `TrainTrace-Vorlagen ${p(d.getDate())}.${p(d.getMonth() + 1)}.${d.getFullYear()}.zip`;
      stop();
      const where = await app.saveFile(bytes, name, 'application/zip');
      toast(where ? `${countText(count)} exportiert: ${where}` : `${countText(count)} exportiert (Download gestartet)`, 5000);
    } catch (e) {
      stop();
      alertDialog('Export fehlgeschlagen', String((e && e.message) || e));
    }
  }

  async function doImport(files) {
    const pdfs = files.filter((f) => /\.(pdf|json|zip)$/i.test(f.name || '') || /pdf|json|zip/.test(f.type || ''));
    if (!pdfs.length) { toast('Bitte PDF-Dateien wählen'); return; }
    const stop = busy(`${pdfs.length} Datei${pdfs.length === 1 ? '' : 'en'} werden ausgelesen …`);
    let res;
    try { res = await importTemplateFiles(pdfs); } finally { stop(); }
    await load();
    const parts = [res.added.length && `${res.added.length} neu`, res.updated.length && `${res.updated.length} aktualisiert`,
      res.byName && `${res.byName}× RICS anhand des Halternamens erkannt`, res.byFile && `${res.byFile}× Halter aus dem Dateinamen`].filter(Boolean);
    if (res.failed.length) {
      alertDialog(parts.length ? `Vorlagen: ${parts.join(', ')}` : 'Keine Vorlage eingelesen',
        `${res.failed.length} Datei${res.failed.length === 1 ? '' : 'en'} konnte${res.failed.length === 1 ? '' : 'n'} nicht ausgelesen werden:`,
        res.failed.map((f) => `${f.name}: ${f.message}`));
    } else toast(`Vorlagen: ${parts.join(', ')}`, 3500);
    const first = res.added[0] || res.updated[0];
    if (first) flash(first.id);
  }

  function flash(id) {
    requestAnimationFrame(() => {
      const it = body.querySelector(`[data-tid="${CSS.escape(id)}"]`);
      if (it) { it.classList.add('flash'); it.scrollIntoView({ block: 'center', behavior: 'smooth' }); }
    });
  }

  // PDFs auf die Ansicht ziehen = importieren
  if (mayManage) {
    el.addEventListener('dragover', (e) => { if ([...e.dataTransfer.types].includes('Files')) { e.preventDefault(); el.classList.add('drop'); } });
    el.addEventListener('dragleave', (e) => { if (e.target === el) el.classList.remove('drop'); });
    el.addEventListener('drop', (e) => { if (!e.dataTransfer.files.length) return; e.preventDefault(); el.classList.remove('drop'); doImport([...e.dataTransfer.files]); });
  }

  function item(t) {
    const d = t.data || {};
    const u = usage.get(t.id);
    const act = (name, label, fn, cls = '', disabled = false) => h('button', {
      type: 'button', class: `icon-btn sv-act ${cls}`, 'aria-label': label, title: label, disabled,
      onclick: (e) => { e.stopPropagation(); fn(e.currentTarget); },
    }, icon(name));
    const view = () => app.viewTemplate(t);
    const more = filledCount(d) - [...EDIT_KEYS].filter((k) => k in d).length;
    return h('div', { class: 'list-item sv-item tp-item', 'data-tid': t.id },
      h('div', { class: 'main', role: 'button', tabindex: '0', title: 'Ansehen', onclick: view, style: { cursor: 'pointer' },
        onkeydown: (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); view(); } } },
        h('div', { class: 't1' }, t.name || 'Ohne Namen',
          d.keeperVkm && h('span', { class: 'badge tp-rics' }, `RICS ${d.keeperVkm}`)),
        // Haltername (Kunde) immer sichtbar, wenn die Vorlage anders heißt
        h('div', { class: 't2' }, [d.keeperName && d.keeperName.trim() !== String(t.name || '').trim() && d.keeperName, d.keeperAddress, d.keeperEmail].filter(Boolean).join(' · ') || 'Ohne Halteradresse'),
        h('div', { class: 'sv-where' }, icon('doc'), [
          t.source === 'import' ? `Importiert${t.fileName ? ` aus ${t.fileName}` : ''}` : 'Eigene Vorlage',
          t.keeperFrom === 'name' && 'RICS anhand des Halternamens erkannt',
          t.keeperFrom === 'datei' && 'Halter aus dem Dateinamen erkannt',
          more > 0 && `${more} weitere Angabe${more === 1 ? '' : 'n'}`,
          u && `${u.count} Protokoll${u.count === 1 ? '' : 'e'} erstellt`,
        ].filter(Boolean).join(' · '))),
      h('div', { class: 'sv-acts' },
        act('eye', 'Ansehen', view, 'look'),
        app.can('create') && act('edit', 'Neues Protokoll aus dieser Vorlage', () => app.newFromTemplate(t), 'edit'),
        (app.can('create') || mayManage || app.can('share')) && act('more', 'Weitere Aktionen', (b) => menu(b, t)),
        mayManage && act('trash', 'Vorlage löschen', async () => {
          if (!(await confirmDialog(`Vorlage „${t.name}“ löschen?`, 'Die Vorlage wird endgültig gelöscht. Bereits daraus erstellte Protokolle bleiben unverändert.', 'Löschen'))) return;
          await deleteTemplate(t.id);
          toast('Vorlage gelöscht');
          load();
        })));
  }

  function menu(anchor, t) {
    popMenu(anchor, [
      app.can('create') && { icon: 'doc', label: 'Neues Protokoll aus Vorlage', sub: 'wie der Stift', onClick: () => app.newFromTemplate(t) },
      mayManage && { icon: 'edit', label: 'Vorlage bearbeiten …', sub: 'Name, Halter, Kontakt', onClick: () => editTemplate(t) },
      mayManage && { icon: 'copy', label: 'Duplizieren', onClick: async () => {
        const now = new Date().toISOString();
        const copy = { ...JSON.parse(JSON.stringify(t)), id: crypto.randomUUID ? crypto.randomUUID() : `t${Date.now()}`, name: `${t.name} (Kopie)`, source: 'manual', hasPdf: false, pdfCurrent: false, createdAt: now, updatedAt: now };
        await putTemplate(copy); toast('Vorlage dupliziert'); await load(); flash(copy.id);
      } },
      app.can('share') && { icon: 'download', label: 'PDF speichern', sub: t.hasPdf && t.pdfCurrent ? 'Original-PDF' : 'aus den Angaben erzeugt', onClick: () => app.saveTemplatePdf(t) },
    ], { title: t.name });
  }

  /** Vorlage anlegen (t = null) oder bearbeiten */
  function editTemplate(t) {
    const isNew = !t;
    const work = t ? JSON.parse(JSON.stringify(t)) : { id: crypto.randomUUID ? crypto.randomUUID() : `t${Date.now()}`, name: '', data: {}, source: 'manual', hasPdf: false, pdfCurrent: false };
    const d = work.data;
    let changed = false;
    const err = h('div', { class: 'msg err' });
    const nameIn = h('input', { type: 'text', maxlength: 80, placeholder: 'z. B. ERMEWA SA - D', value: work.name || '',
      oninput: () => { work.name = nameIn.value; changed = true; err.textContent = ''; } });
    const field = (k, label, o = {}) => {
      const id = `tp-${k}`;
      if (o.check) {
        const cb = h('input', { id, type: 'checkbox', checked: !!d[k], onchange: () => { if (cb.checked) d[k] = true; else delete d[k]; changed = true; } });
        return h('label', { class: 'toggle-row' }, h('span', { class: 'switch' }, cb, h('span')), label);
      }
      const input = h(o.area ? 'textarea' : 'input', {
        id, type: o.area ? undefined : (o.type || 'text'), inputmode: o.inputmode, placeholder: o.placeholder || '', rows: o.area ? 2 : undefined, autocomplete: 'off',
        oninput: (e) => {
          let v = e.target.value;
          if (o.digits) { v = v.replace(/\D/g, '').slice(0, o.digits); e.target.value = v; }
          if (v.trim()) d[k] = v; else delete d[k];
          changed = true;
          // Name der Vorlage folgt dem Haltername, solange er nicht selbst vergeben wurde
          if (k === 'keeperName' && !nameTouched) { work.name = v.trim(); nameIn.value = work.name; }
        },
      });
      input.value = d[k] || '';
      return h('div', { class: 'field' }, h('label', { class: 'label', for: id }, label), input);
    };
    // Eigener Vorlagenname (weicht vom Haltername ab) bleibt beim Ändern des Halternamens erhalten
    let nameTouched = !isNew && !!(work.name || '').trim() && (work.name || '').trim() !== String(d.keeperName || '').trim();
    nameIn.addEventListener('input', () => { nameTouched = true; });
    const others = Object.keys(d).filter((k) => !EDIT_KEYS.has(k) && LABELS[k]).map((k) => LABELS[k]);
    const save = async () => {
      work.name = (work.name || '').trim() || suggestName(d);
      if (!filledCount(d)) { err.textContent = 'Bitte mindestens eine Angabe eintragen (z. B. Halter).'; return false; }
      const now = new Date().toISOString();
      if (changed && work.hasPdf) work.pdfCurrent = false; // Ansehen zeigt dann die geänderten Angaben statt der Original-PDF
      work.updatedAt = now; work.createdAt = work.createdAt || now;
      await putTemplate(work);
      close();
      toast(isNew ? 'Vorlage angelegt' : 'Vorlage gespeichert');
      await load(); flash(work.id);
      return true;
    };
    const back = async () => {
      if (!changed) { close(); return; }
      const v = await modal({ title: 'Änderungen speichern?', buttons: [{ label: 'Abbrechen', value: null }, { label: 'Verwerfen', value: 'discard' }, { label: 'Speichern', value: 'save' }] });
      if (v === 'discard') close(); else if (v === 'save') save();
    };
    const close = sheetShell(isNew ? 'Neue Vorlage' : 'Vorlage bearbeiten', back,
      h('section', { class: 'card' }, h('h2', null, 'Vorlage'),
        h('div', { class: 'field' }, h('label', { class: 'label' }, 'Name der Vorlage'), nameIn, err),
        h('p', { class: 'small', style: { margin: '6px 2px 0' } }, 'Mit dem Stift in der Liste wird ein neues Protokoll angelegt, in dem alle Angaben dieser Vorlage bereits eingetragen sind.')),
      ...EDIT_FIELDS.map(([title, fs]) => h('section', { class: 'card' }, h('h2', null, title), ...fs.map(([k, label, o]) => field(k, label, o)))),
      others.length > 0 && h('section', { class: 'card' }, h('h2', null, 'Ebenfalls enthalten'),
        h('p', { class: 'small', style: { margin: '0 2px' } }, `Aus der PDF übernommen und ebenfalls ins Protokoll eingetragen: ${others.join(', ')}.`)),
      h('div', { style: { display: 'flex', justifyContent: 'center', gap: '10px' } },
        h('button', { class: 'btn', onclick: back }, 'Abbrechen'),
        h('button', { class: 'btn primary', onclick: save }, 'Speichern')));
    setTimeout(() => (isNew ? nameIn : null)?.focus(), 50);
  }

  function draw() {
    body.innerHTML = '';
    const q = search.value.trim().toLowerCase();
    const list = (q ? templates.filter((t) => { const hay = templateHaystack(t); return q.split(/\s+/).every((w) => hay.includes(w)); }) : templates).slice().sort(byName);
    info.replaceChildren(h('span', { class: 'sv-crumb cur' }, q ? `Suche: ${list.length} von ${countText(templates.length)}` : countText(templates.length)));
    if (!templates.length) {
      body.appendChild(h('div', { class: 'empty-state tp-empty' },
        h('p', null, 'Noch keine Vorlagen.'),
        h('p', { class: 'small' }, mayManage ? 'Über „Importieren“ PDF-Vorlagen einlesen (z. B. je Wagenhalter mit Halternummer, Name, Adresse und E-Mail – eine Protokoll-Nr. ist nicht nötig), auch mehrere auf einmal, als ZIP oder per Ziehen in dieses Fenster. Oder mit „Neue Vorlage“ selbst anlegen.' : 'Vorlagen anlegen dürfen nur Mitarbeiter mit dem Recht „Vorlagen verwalten“.')));
      return;
    }
    if (!list.length) { body.appendChild(h('div', { class: 'empty-state' }, 'Keine Vorlage gefunden.')); return; }
    body.appendChild(h('div', { class: 'vlist' }, list.map(item)));
  }

  async function load() {
    const [ts, rs] = await Promise.all([listTemplates(), listReports().catch(() => [])]);
    templates = ts;
    usage = new Map();
    for (const r of rs) {
      if (!r.templateId) continue;
      const u = usage.get(r.templateId) || { count: 0 };
      u.count++;
      usage.set(r.templateId, u);
    }
    draw();
  }
  const off = onDataChange(() => { if (!el.isConnected) { off(); return; } if (!document.querySelector('.popmenu, .modal-bg, .sheet')) load(); });
  el.refresh = load;
  load();
  return el;
}
