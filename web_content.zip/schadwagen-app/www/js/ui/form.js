import { h, icon, alertDialog, toast, copyButton } from './dom.js';
import { LABELS, newDamage, formatReportId } from '../state.js';
import { onlyDigits, formatWagonNumber, validateWagonNumber } from '../wagon.js';
import { search, lookup, isSelectable, resolveCode, categoryName, klassChip } from '../codes.js';
import { openCodePicker } from './codePicker.js';
import { compressImage } from '../platform.js';
import { searchStations, byCode } from '../stations.js';
import { lookupKeeper } from '../keeper.js';
import { serverBase } from '../server.js';
import { getSecret } from '../secrets.js';

let uid = 0;
const nextId = () => `f${++uid}`;

/* ---------- Feldbausteine ---------- */

function field(label, control, { trailing, msg, invalid } = {}) {
  const id = control.id || (control.id = nextId());
  return h('div', { class: 'field' + (invalid ? ' invalid' : '') },
    h('label', { class: 'label', for: id }, label),
    h('div', { class: 'row' }, control, trailing),
    msg);
}

function textInput(ctx, obj, key, { type = 'text', placeholder = 'Eingeben', multiline, rows = 1, inputmode, maxlength, onInput, autocap } = {}) {
  const el = h(multiline ? 'textarea' : 'input', {
    type: multiline ? undefined : type, placeholder, inputmode, maxlength, rows: multiline ? rows : undefined,
    autocomplete: 'off', autocapitalize: autocap || 'sentences', spellcheck: multiline ? 'true' : 'false',
    'data-bind': key,
    oninput: (e) => {
      obj[key] = e.target.value;
      if (multiline) autoGrow(e.target);
      onInput && onInput(e);
      ctx.changed();
    },
  });
  el.value = obj[key] ?? '';
  if (multiline) requestAnimationFrame(() => autoGrow(el));
  return el;
}
function autoGrow(t) { t.style.height = 'auto'; t.style.height = Math.min(t.scrollHeight + 2, 260) + 'px'; }

const text = (ctx, obj, key, label, opts = {}) => field(label, textInput(ctx, obj, key, opts), { trailing: opts.trailing });

/** Betriebsstelle: Eingabe von Abkürzung (Ril 100) oder Name mit Vorschlagsliste; übernommen wird der Name. */
function station(ctx, obj, key, label) {
  let ac = null; let results = []; let active = -1;
  const hint = h('div', { class: 'msg small' });
  const showHint = () => {
    const s = obj[key + 'Code'] ? byCode(obj[key + 'Code']) : null;
    hint.textContent = s && s.name === obj[key] ? s.code.replace(/\s+/g, ' ') : '';
  };
  const close = () => { if (ac) { ac.remove(); ac = null; } active = -1; };
  const pick = (s) => {
    obj[key] = s.name; obj[key + 'Code'] = s.code;
    input.value = s.name; close(); showHint(); ctx.changed();
  };
  const show = () => {
    close();
    results = searchStations(input.value, 30);
    if (!results.length) return;
    ac = h('div', { class: 'ac', role: 'listbox' }, results.map((s, i) => h('button', {
      type: 'button', role: 'option', class: i === active ? 'active' : '',
      onmousedown: (e) => e.preventDefault(), onclick: () => pick(s),
    }, h('span', { class: 'code' }, s.code.replace(/\s+/g, ' ')), s.name)));
    wrap.appendChild(ac);
  };
  const input = h('input', {
    type: 'text', placeholder: 'Abkürzung oder Betriebsstelle', autocomplete: 'off', autocapitalize: 'words', spellcheck: 'false',
    oninput: () => { obj[key] = input.value; obj[key + 'Code'] = ''; showHint(); ctx.changed(); show(); },
    onblur: () => setTimeout(() => {
      close();
      const s = !obj[key + 'Code'] && byCode(input.value); // exakt eingegebene Abkürzung -> Name
      if (s) pick(s);
    }, 150),
    onkeydown: (e) => {
      if (!ac || !results.length) return;
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        active = (active + (e.key === 'ArrowDown' ? 1 : -1) + results.length) % results.length;
        [...ac.children].forEach((b, i) => b.classList.toggle('active', i === active));
      } else if (e.key === 'Enter') { e.preventDefault(); pick(results[Math.max(0, active)]); }
      else if (e.key === 'Escape') close();
    },
  });
  input.value = obj[key] || '';
  showHint();
  const wrap = field(label, input, { msg: hint });
  return wrap;
}
// Datumsfeld als normales Textfeld (TT.MM.JJJJ wird nie als Platzhalter angezeigt).
// Eingabe nur Ziffern, Punkte werden automatisch gesetzt; gespeichert wird JJJJ-MM-TT.
const isoToDe = (iso) => { const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso || ''); return m ? `${m[3]}.${m[2]}.${m[1]}` : ''; };
function deToIso(txt) {
  let d = String(txt || '').replace(/\D/g, '');
  if (d.length === 6) d = d.slice(0, 4) + '20' + d.slice(4); // 201026 -> 20.10.2026
  if (d.length !== 8) return '';
  const [dd, mm, yy] = [+d.slice(0, 2), +d.slice(2, 4), +d.slice(4)];
  const dt = new Date(yy, mm - 1, dd);
  if (dt.getFullYear() !== yy || dt.getMonth() !== mm - 1 || dt.getDate() !== dd) return '';
  return `${yy}-${String(mm).padStart(2, '0')}-${String(dd).padStart(2, '0')}`;
}
function date(ctx, obj, key, label) {
  const msg = h('div', { class: 'msg' });
  const input = h('input', {
    type: 'text', inputmode: 'numeric', autocomplete: 'off', placeholder: '', maxlength: 10,
    oninput: (e) => {
      const d = e.target.value.replace(/\D/g, '').slice(0, 8);
      e.target.value = d.length > 4 ? `${d.slice(0, 2)}.${d.slice(2, 4)}.${d.slice(4)}` : d.length > 2 ? `${d.slice(0, 2)}.${d.slice(2)}` : d;
      obj[key] = deToIso(e.target.value);
      msg.textContent = ''; msg.className = 'msg';
      ctx.changed();
    },
    onblur: (e) => {
      const iso = deToIso(e.target.value);
      if (iso) { obj[key] = iso; e.target.value = isoToDe(iso); msg.textContent = ''; }
      else if (e.target.value) { msg.textContent = 'Ungültiges Datum'; msg.className = 'msg err'; obj[key] = ''; }
      ctx.changed();
    },
  });
  input.value = isoToDe(obj[key]);
  // Kalender über verstecktes Datumsfeld (nur der Auswahldialog wird angezeigt)
  const picker = h('input', {
    type: 'date', tabindex: '-1', 'aria-hidden': 'true', class: 'hidden-picker',
    onchange: (e) => { if (e.target.value) { obj[key] = e.target.value; input.value = isoToDe(e.target.value); msg.textContent = ''; ctx.changed(); } },
  });
  const calBtn = h('button', {
    type: 'button', class: 'icon-btn cal-btn', 'aria-label': `${label}: Kalender öffnen`,
    onclick: () => { picker.value = obj[key] || ''; try { picker.showPicker(); } catch { picker.focus(); picker.click(); } },
  }, icon('calendar'));
  return field(label, input, { trailing: h('span', { style: { position: 'relative', display: 'inline-flex' } }, calBtn, picker), msg });
}
const digits = (ctx, obj, key, label, len) => field(label, textInput(ctx, obj, key, {
  inputmode: 'numeric', maxlength: len, placeholder: `${len}-stellig`,
  onInput: (e) => { e.target.value = e.target.value.replace(/\D/g, '').slice(0, len); obj[key] = e.target.value; },
}));

function checkbox(label, checked, onChange) {
  const input = h('input', { type: 'checkbox', checked: !!checked, onchange: (e) => onChange(e.target.checked) });
  return h('label', { class: 'chk' }, input, h('span', { class: 'box' }), label);
}

/** Exklusive Auswahl in Checkbox-Optik (erneutes Antippen hebt die Auswahl auf). */
function choice(ctx, obj, key, options, { layout = '', rerender = false } = {}) {
  return h('div', { class: `checks ${layout}` }, options.map(([value, label]) =>
    checkbox(label, obj[key] === value, (on) => {
      obj[key] = on ? value : '';
      ctx.changed();
      ctx.rerender();
    })));
}

function labelChecks(ctx, map, { rerender } = {}) {
  return h('div', { class: 'checks' }, LABELS.map((l) =>
    checkbox(l, map[l], (on) => { map[l] = on; ctx.changed(); if (rerender) ctx.rerender(); })));
}

const card = (title, ...children) => h('section', { class: 'card' }, title && h('h2', null, title), ...children);

/* ---------- Schaden ---------- */

function codeSummary(d) {
  if (d.noCode) {
    return h('div', null,
      h('div', { class: 'code-title' }, 'Kein passender Schadcode – ', h('b', null, `${categoryName(d.customCategory)} › ${lookup(`${d.customCategory}.${d.customSub}`)?.kurztext || ''}`)),
      d.customText && h('div', { class: 'small' }, d.customText));
  }
  const c = lookup(d.code);
  if (!c) return null;
  const k = klassChip(c.fehlerklasse);
  return h('div', null,
    h('div', { class: 'code-title' }, c.titel),
    h('div', { class: 'code-meta' },
      c.komponente && h('span', { class: 'chip' }, c.komponente),
      k && h('span', { class: k.cls }, k.text),
      c.massnahme && h('span', { class: 'chip' }, `Maßnahme: ${c.massnahme}`)),
    (c.kriterien.length + c.hinweise.length + c.fussnoten.length > 0) ? h('details', { class: 'more' },
      h('summary', null, 'Kriterien & Hinweise'),
      c.kriterien.length > 0 && h('div', null, 'Kriterien:', h('ul', null, c.kriterien.map((x) => h('li', null, x)))),
      c.hinweise.length > 0 && h('div', null, 'Hinweise:', h('ul', null, c.hinweise.map((x) => h('li', null, x)))),
      c.fussnoten.length > 0 && h('div', null, h('ul', null, c.fussnoten.map((x) => h('li', null, x)))),
      h('div', { class: 'small' }, `AVV Anlage 9, Anhang 1, Seite ${c.seite}`))
      : h('div', { class: 'more-spacer', 'aria-hidden': 'true' }));
}

function damageBlock(ctx, d, i) {
  const r = ctx.report;
  const wrap = h('div', { class: 'field', style: { padding: 0 } });
  let ac = null; let active = -1; let results = [];

  const closeAc = () => { if (ac) { ac.remove(); ac = null; } active = -1; };
  const choose = (code) => {
    d.code = code; d.noCode = false;
    closeAc(); ctx.changed(); ctx.rerender();
  };
  const showAc = (q) => {
    closeAc();
    if (!q.trim()) return;
    results = search(q, { limit: 40 });
    ac = h('div', { class: 'ac', role: 'listbox' },
      results.length ? results.map((c, idx) => h('button', {
        type: 'button', role: 'option',
        onmousedown: (e) => e.preventDefault(),
        onclick: () => choose(c.code),
        class: idx === active ? 'active' : '',
      }, h('span', { class: 'code' }, c.code), c.kurztext, h('span', { class: 'comp' }, c.pfad.join(' › '))))
        : h('div', { class: 'empty' }, 'Kein Schadcode gefunden'));
    wrap.appendChild(ac);
  };

  const input = h('input', {
    type: 'text', class: 'code-input', placeholder: 'Schadcode', inputmode: 'decimal',
    autocomplete: 'off', 'aria-label': `Schadcode Schaden ${i + 1}`,
    oninput: (e) => {
      const v = e.target.value.replace(/,/g, '.');
      e.target.value = v;
      d.code = v.trim(); d.noCode = false;
      ctx.changed();
      showAc(v);
    },
    onfocus: (e) => { if (e.target.value && !isSelectable(d.code)) showAc(e.target.value); },
    onblur: () => setTimeout(() => {
      closeAc();
      const resolved = d.noCode ? '' : resolveCode(d.code);
      if (resolved && resolved !== d.code) { d.code = resolved; ctx.changed(); }
      if (d.code && isSelectable(d.code)) ctx.rerender();
    }, 150),
    onkeydown: (e) => {
      if (!ac || !results.length) return;
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        active = (active + (e.key === 'ArrowDown' ? 1 : -1) + results.length) % results.length;
        [...ac.children].forEach((b, idx) => b.classList.toggle('active', idx === active));
      } else if (e.key === 'Enter') {
        e.preventDefault();
        choose(results[Math.max(0, active)].code);
      } else if (e.key === 'Escape') closeAc();
    },
  });
  input.value = d.noCode ? [d.customCategory, d.customSub].filter(Boolean).join('.') : d.code;
  if (d.noCode) input.readOnly = true;

  const moreBtn = h('button', {
    type: 'button', class: 'square-btn', 'aria-label': 'Schadcode auswählen',
    onclick: () => openCodePicker(d, i + 1, (res) => { Object.assign(d, res); ctx.changed(); ctx.rerender(); }),
  }, icon('more'));
  const hasContent = d.code || d.noCode || d.remark;
  const delBtn = (hasContent || r.damages.length > 1) && h('button', {
    type: 'button', class: 'square-btn', 'aria-label': `Schaden ${i + 1} entfernen`,
    onclick: () => {
      if (r.damages.length > 1) r.damages.splice(i, 1); else r.damages[0] = newDamage();
      ctx.changed(); ctx.rerender();
    },
  }, icon('trash'));

  const invalidCode = d.code && !d.noCode && !isSelectable(d.code) && document.activeElement !== input;
  wrap.appendChild(h('div', { class: 'code-row' }, input, moreBtn, h('span', { class: 'spacer' }), delBtn));

  return h('div', { class: 'damage' },
    h('h3', null, `Schaden ${i + 1}`),
    wrap,
    invalidCode && h('div', { class: 'field' }, h('div', { class: 'msg err' }, 'Unbekannter oder nicht auswählbarer Schadcode')),
    codeSummary(d),
    (d.code || d.noCode) && h('div', { class: 'field' },
      h('span', { class: 'label' }, 'Schadenszustand'),
      h('div', { class: 'seg', role: 'group' },
        h('button', { type: 'button', class: d.old ? '' : 'on', onclick: () => { d.old = false; ctx.changed(); ctx.rerender(); } }, 'Neu'),
        h('button', { type: 'button', class: d.old ? 'on' : '', onclick: () => { d.old = true; ctx.changed(); ctx.rerender(); } }, 'Alt'))),
    text(ctx, d, 'remark', 'Zusätzliche Bemerkungen', { multiline: true }),
  );
}

/* ---------- Fotos / Anlagen ---------- */

function photosBlock(ctx) {
  const r = ctx.report;
  const file = h('input', {
    type: 'file', accept: 'image/*', multiple: true, style: { display: 'none' },
    onchange: async (e) => {
      const files = [...e.target.files];
      for (const f of files) {
        try { r.photos.push({ name: f.name, dataUrl: await compressImage(f) }); }
        catch { toast(`Bild ${f.name} konnte nicht gelesen werden`); }
      }
      e.target.value = '';
      ctx.changed(); ctx.rerender();
    },
  });
  return card('Anlagen',
    r.photos.length ? h('div', { class: 'photos' }, r.photos.map((p, idx) => h('div', { class: 'photo' },
      h('img', { src: p.dataUrl, alt: `Foto ${idx + 1}` }),
      h('button', { type: 'button', 'aria-label': 'Foto entfernen', onclick: () => { r.photos.splice(idx, 1); ctx.changed(); ctx.rerender(); } }, '×'))))
      : h('p', { class: 'small' }, 'Fotos werden dem PDF als Anlagenseiten angehängt.'),
    file,
    h('button', { type: 'button', class: 'add-btn', onclick: () => file.click() }, '+ Foto hinzufügen'),
    h('div', { class: 'checks' }, checkbox('Weitere Anlagen beigefügt', r.attachments, (on) => { r.attachments = on; ctx.changed(); })));
}

/* ---------- Halterdaten übernehmen ---------- */

// Füllt die Halterfelder. Von Hand geänderte Felder werden nicht überschrieben:
// ersetzt wird nur, was leer ist oder noch dem zuletzt automatisch eingetragenen Wert entspricht.
const KEEPER_FIELDS = [['keeperVkm', 'code'], ['keeperName', 'name'], ['keeperAddress', 'address'], ['keeperEmail', 'email']];
function applyKeeper(r, k) {
  const prev = r.keeperAuto || {};
  const next = {};
  for (const [field, src] of KEEPER_FIELDS) {
    const val = String(k[src] || '').trim();
    const cur = String(r[field] || '').trim();
    if (val && (!cur || cur === prev[field])) {
      r[field] = field === 'keeperVkm' ? val.replace(/\D/g, '').slice(0, 4) : val;
      const el = document.querySelector(`[data-bind="${field}"]`);
      if (el) { el.value = r[field]; if (el.tagName === 'TEXTAREA') autoGrow(el); }
    }
    next[field] = r[field];
  }
  r.keeperAuto = next;
}

/* ---------- Gesamtformular ---------- */

export function renderForm(ctx) {
  const r = ctx.report;
  const s = ctx.settings;

  // Wagennummer mit Formatierung, Prüfziffernkontrolle und automatischer Halter-Abfrage
  const wagonMsg = h('div', { class: 'msg' });
  const keeperMsg = h('div', { class: 'msg keeper-msg', role: 'status', 'aria-live': 'polite' });
  const updateWagonMsg = () => {
    const st = validateWagonNumber(r.wagonNumber);
    wagonMsg.className = 'msg ' + ({ ok: 'ok', invalid: 'err', incomplete: '' }[st] || '');
    wagonMsg.textContent = { ok: 'Prüfziffer korrekt', invalid: 'Ungültige Wagennummer: Die Prüfziffer stimmt nicht.', incomplete: `${onlyDigits(r.wagonNumber).length}/12 Ziffern` }[st] || '';
    const ks = r.keeperLookup && r.keeperLookup.evn === r.wagonNumber && st === 'ok' ? r.keeperLookup : null;
    keeperMsg.className = 'msg keeper-msg' + (ks ? ` k-${ks.status}` : '');
    keeperMsg.textContent = ks ? ks.message : '';
  };
  const runLookup = async () => {
    const evnNow = r.wagonNumber;
    if (validateWagonNumber(evnNow) !== 'ok' || ctx.readOnly) return;
    // Bereits erledigt (Treffer / nicht gefunden) oder läuft gerade -> nicht erneut fragen
    if (r.keeperLookup && r.keeperLookup.evn === evnNow && ['ok', 'not_found', 'loading'].includes(r.keeperLookup.status)) return;
    r.keeperLookup = { evn: evnNow, status: 'loading', message: 'Halter wird abgefragt …' };
    updateWagonMsg();
    const res = await lookupKeeper(evnNow, { baseUrl: serverBase(), apiKey: getSecret('apiToken'), session: getSecret('sessionToken') });
    if (r.wagonNumber !== evnNow) return; // inzwischen andere Nummer eingegeben
    if (res.status === 'ok') {
      applyKeeper(r, res.keeper);
      res.message = `${res.message}${res.source ? ` · Quelle: ${res.source}` : ''}`;
    }
    r.keeperLookup = { evn: evnNow, status: res.status, message: res.message };
    updateWagonMsg();
    ctx.changed();
  };
  const wagonInput = h('input', {
    type: 'text', inputmode: 'numeric', placeholder: '00 00 0000 000-0', autocomplete: 'off', class: 'wagon-input',
    oninput: (e) => {
      r.wagonNumber = onlyDigits(e.target.value);
      e.target.value = formatWagonNumber(r.wagonNumber);
      updateWagonMsg(); ctx.changed();
      runLookup();
    },
  });
  wagonInput.value = formatWagonNumber(r.wagonNumber);
  updateWagonMsg();
  // Noch nicht abgefragte (oder nach Änderung der Einstellungen zurückgesetzte) gültige Nummer
  if (validateWagonNumber(r.wagonNumber) === 'ok' && !(r.keeperLookup && r.keeperLookup.evn === r.wagonNumber)) setTimeout(runLookup, 0);
  const scanBtn = h('button', {
    type: 'button', class: 'square-btn', 'aria-label': 'Wagennummer scannen',
    onclick: () => alertDialog('Wagennummer scannen', 'Die Texterkennung per Kamera ist in dieser Version noch nicht angebunden. Bitte die 12-stellige Wagennummer manuell eingeben.'),
  }, icon('scan'));

  const out = h('div', null,
    ctx.readOnly && h('div', { class: 'ro-banner', role: 'note' }, icon('lock'), h('span', null, ctx.readOnly)),
    h('section', { class: 'card evu', onclick: () => ctx.openSettings(), style: { cursor: 'pointer' } },
      h('div', { class: 'field' }, h('span', { class: 'label' }, 'Verwendendes EVU'),
        h('div', { class: 'value' }, `${s.evuName} (${s.evuNr})`))),

    card('Allgemein',
      field('Wagennummer', wagonInput, { trailing: scanBtn, msg: h('div', null, wagonMsg, keeperMsg) }),
      text(ctx, r, 'trainNumber', 'Zugnummer', { maxlength: 8, inputmode: 'numeric' }),
      text(ctx, r, 'consignmentNumber', 'Sendungsnummer', {}),
      station(ctx, r, 'detectionPlace', 'Ort der Schadensfeststellung'),
      date(ctx, r, 'detectionDate', 'Schaden festgestellt am'),
      station(ctx, r, 'origin', 'Versandbahnhof'),
      station(ctx, r, 'destination', 'Empfangsbahnhof'),
      date(ctx, r, 'departureDate', 'Versanddatum'),
      h('div', { class: 'field' }, h('span', { class: 'label' }, 'Ladezustand'),
        choice(ctx, r, 'loadingStatus', [['leer', 'Leer'], ['beladen', 'Beladen']], { layout: 'cols2' })),
      h('div', { class: 'field' }, h('span', { class: 'label' }, 'Protokoll-Nr.'),
        r.numberUsed
          ? h('div', { class: 'value-text' }, r.reportId)
          : h('div', null, h('div', { class: 'value-text' }, formatReportId(s)), h('div', { class: 'msg small' }, 'Wird beim Erstellen der PDF vergeben')))),

    card('Wagenhalter',
      digits(ctx, r, 'keeperVkm', 'Halternummer', 4),
      text(ctx, r, 'keeperName', 'Name VKM'),
      text(ctx, r, 'keeperAddress', 'Adresse', { multiline: true }),
      text(ctx, r, 'keeperEmail', 'E-Mail', { type: 'email', autocap: 'none', trailing: copyButton(() => r.keeperEmail) })),

    card('Beschreibung des Schadens',
      r.damages.map((d, i) => damageBlock(ctx, d, i)),
      r.damages.length < 3 && h('button', {
        type: 'button', class: 'add-btn',
        onclick: () => { r.damages.push(newDamage()); ctx.changed(); ctx.rerender(); },
      }, '+ Weiteren Schaden hinzufügen')),

    card('Vorgefundene Bezettelung',
      h('div', { class: 'field' }, h('span', { class: 'label' }, 'Muster'), labelChecks(ctx, r.existingLabels, { rerender: true })),
      LABELS.some((l) => r.existingLabels[l]) && h('div', { class: 'sub' },
        date(ctx, r, 'existingDate', 'Datum der Bezettelung'),
        digits(ctx, r, 'existingRuNr', 'EVU-Nr., das bezettelt hat', 4),
        text(ctx, r, 'existingRuName', 'EVU-Name'))),

    card('Erfolgte Bezettelung',
      h('div', { class: 'field' }, h('span', { class: 'label' }, 'Muster'), labelChecks(ctx, r.newLabels)),
      h('div', { class: 'checks' }, checkbox('Aussetzen', r.wagonDetached, (on) => { r.wagonDetached = on; ctx.changed(); })),
      h('div', { class: 'field' }, h('span', { class: 'label' }, 'Werkstattzuführung'),
        choice(ctx, r, 'workshop', [['before', 'Vor Entladung'], ['after', 'Nach Entladung']], { layout: 'cols2' }))),

    card('Schadensfestst. bei Übernahme',
      choice(ctx, r, 'takeover', [['avv', 'AVV-EVU'], ['nonavv', 'Nicht-AVV-EVU'], ['siding', 'Anschlussbahn']], { layout: 'cols2', rerender: true }),
      r.takeover && h('div', { class: 'sub' },
        digits(ctx, r, 'takeoverNr', 'Unternehmen (Nr.)', 4),
        text(ctx, r, 'takeoverName', 'Unternehmen (Name)'))),

    card('Ursache/Verursacher',
      choice(ctx, r, 'cause', [['wear', 'Verschleiß'], ['own', 'Durch eigenes EVU'], ['third', 'Durch Dritten'], ['unknown', 'Nicht ermittelbar']], { layout: 'stack', rerender: true }),
      r.cause === 'third' && h('div', { class: 'sub' },
        text(ctx, r, 'perpetrator', 'Name, Adresse und Kontakt des Dritten', { multiline: true, rows: 2 }))),

    photosBlock(ctx),

    card('Kontaktinformationen',
      text(ctx, r, 'contactName', 'Name'),
      text(ctx, r, 'contactEmail', 'E-Mail', { type: 'email', autocap: 'none', trailing: copyButton(() => r.contactEmail) }),
      text(ctx, r, 'contactPhone', 'Telefon-Nr.', { type: 'tel', inputmode: 'tel' }),
      text(ctx, r, 'remarks', 'Anmerkungen', { multiline: true })),
  );
  // Nur Ansicht: alle Eingaben sperren (Kopieren-Knöpfe bleiben nutzbar)
  if (ctx.readOnly) {
    out.querySelectorAll('input, textarea, select, button').forEach((el) => { if (!el.hasAttribute('data-keep')) el.disabled = true; });
    out.classList.add('readonly');
  }
  return out;
}

/* ---------- Prüfung vor dem Erstellen ---------- */

export function validate(r) {
  const errors = [];
  const warnings = [];
  const w = validateWagonNumber(r.wagonNumber);
  if (w === 'empty') errors.push('Wagennummer fehlt');
  else if (w === 'incomplete') errors.push('Wagennummer unvollständig (12 Ziffern)');
  else if (w === 'invalid') warnings.push('Prüfziffer der Wagennummer stimmt nicht');
  if (!r.detectionPlace.trim()) errors.push('Ort der Schadensfeststellung fehlt');
  if (!r.detectionDate) errors.push('Datum der Schadensfeststellung fehlt');
  if (!r.loadingStatus) errors.push('Ladezustand nicht gewählt');
  const filled = r.damages.filter((d) => d.code || d.noCode);
  if (!filled.length) errors.push('Mindestens ein Schaden mit Schadcode erforderlich');
  r.damages.forEach((d, i) => {
    if (d.noCode && (!d.customCategory || !d.customSub || !d.customText.trim())) errors.push(`Schaden ${i + 1}: Kategorie und Beschreibung angeben`);
    else if (!d.noCode && d.code && !isSelectable(d.code)) errors.push(`Schaden ${i + 1}: Schadcode „${d.code}“ ist ungültig`);
  });
  if (r.cause === 'third' && !r.perpetrator.trim()) warnings.push('Angaben zum Dritten fehlen');
  if (r.takeover && !r.takeoverName.trim()) warnings.push('Übergebendes Unternehmen nicht angegeben');
  return { errors, warnings };
}
