import { h, icon, confirmDialog, copyButton } from './dom.js';
import { db } from '../codes.js';
import { formatWagonNumber } from '../wagon.js';
import { formatDate } from '../pdf/fillProtocol.js';
import { isNative, isDesktop, desktopBuild, isAndroidApp, desktopSaveDir, desktopPickDir, desktopOpenDir } from '../platform.js';
import { setDesign, APP_VERSION } from '../state.js';
import { serverPanel, platformNetNote } from './serverPanel.js';
import { secretStorageKind } from '../secrets.js';
import { hasEmployees, activeEmployee, fullName, normPrefix } from '../employees.js';
import { makeEvuLogo } from '../logo.js';

/**
 * Einstellungen → Verwendendes EVU → Firmenlogo (PNG oder ICO). Wird verkleinert als rundes Bild
 * gespeichert und unten in der Seitenleiste neben dem EVU-Namen als kleiner Kreis gezeigt.
 * Übernommen wird es wie die anderen Einstellungen mit „Speichern“.
 */
function evuLogoPanel(s) {
  const preview = h('span', { class: 'evu-logo lg', 'aria-hidden': 'true' });
  const msg = h('div', { class: 'msg small' }, 'Erscheint unten links in der Seitenleiste neben dem EVU-Namen als kleiner Kreis. Am besten quadratisch, mindestens 64 × 64 Pixel.');
  const removeBtn = h('button', { type: 'button', class: 'pill-btn', onclick: () => { s.evuLogo = ''; draw(); msg.textContent = 'Logo entfernt – wird mit „Speichern“ übernommen.'; } }, icon('trash'), 'Entfernen');
  const draw = () => {
    preview.replaceChildren(s.evuLogo ? h('img', { src: s.evuLogo, alt: '' }) : icon('train'));
    preview.classList.toggle('empty', !s.evuLogo);
    removeBtn.hidden = !s.evuLogo;
    pick.lastChild.textContent = s.evuLogo ? 'Anderes Logo wählen' : 'Logo hochladen';
  };
  const fileIn = h('input', {
    type: 'file', hidden: true, accept: '.png,.ico,image/png,image/x-icon,image/vnd.microsoft.icon',
    onchange: async (ev) => {
      const f = ev.target.files[0]; ev.target.value = '';
      if (!f) return;
      msg.classList.remove('err');
      try {
        s.evuLogo = await makeEvuLogo(f);
        draw();
        msg.textContent = `„${f.name}“ übernommen – wird mit „Speichern“ gespeichert.`;
      } catch (e) {
        msg.classList.add('err');
        msg.textContent = e.message || 'Das Bild ließ sich nicht lesen.';
      }
    },
  });
  const pick = h('button', { type: 'button', class: 'pill-btn', onclick: () => fileIn.click() }, icon('upload'), h('span', null, 'Logo hochladen'));
  draw();
  return h('div', { class: 'field evu-logo-field' },
    h('span', { class: 'label' }, 'Firmenlogo (PNG oder ICO)'),
    h('div', { class: 'evu-logo-row' }, preview, h('div', { class: 'evu-logo-btns' }, pick, removeBtn), fileIn),
    msg);
}

/**
 * Einstellungen → Speicherort für PDFs. Windows-Programm: Ordner wählen (Windows-Ordnerauswahl) oder Pfad
 * eintippen; gilt für alle „Speichern“-Knöpfe (Dashboard, Protokoll, Mitarbeiter) und für Teilen per
 * E-Mail/WhatsApp. Wird sofort übernommen. Andere Plattformen: Hinweis, wohin gespeichert wird.
 */
function saveDirPanel() {
  if (!isDesktop) {
    return [h('p', { class: 'small', style: { margin: '0 2px' } }, isAndroidApp
      ? 'Android: PDFs werden unter „Download/Schadensprotokolle“ gespeichert.'
      : 'Browser: PDFs landen im Download-Ordner des Browsers (einstellbar in den Browser-Einstellungen). Den Speicherort frei wählen können Sie im Windows-Programm.')];
  }
  const cur = h('code', { class: 'sd-path' }, '…');
  const badge = h('span', { class: 'sd-badge' });
  const msg = h('div', { class: 'sd-msg small', role: 'status', 'aria-live': 'polite' });
  const input = h('input', { id: 's-saveDir', type: 'text', autocomplete: 'off', spellcheck: 'false', placeholder: 'z. B. D:\\Schadensprotokolle oder \\\\server\\freigabe\\Schadwagen',
    onkeydown: (e) => { if (e.key === 'Enter') { e.preventDefault(); apply(input.value); } } });
  const show = (r, note) => {
    cur.textContent = r.path || '—';
    badge.textContent = r.isDefault ? 'Standard' : 'eigener Ordner';
    badge.className = `sd-badge${r.isDefault ? '' : ' own'}`;
    input.value = r.isDefault ? '' : r.path;
    msg.className = `sd-msg small${r.error || r.unavailable ? ' bad' : note ? ' ok' : ''}`;
    msg.textContent = r.error || (r.unavailable ? 'Ordner ist gerade nicht erreichbar – PDFs werden bis dahin im Standardordner gespeichert.' : note || '');
  };
  const run = async (fn, note) => {
    try { const r = await fn(); show(r, r.error ? '' : note); return r; } catch (e) { show({ path: cur.textContent, error: String(e.message || e) }); return null; }
  };
  const apply = (p) => run(() => desktopSaveDir('set', p), 'Übernommen – neue PDFs werden hier gespeichert.');
  const pick = h('button', { type: 'button', class: 'btn', onclick: async () => {
    msg.className = 'sd-msg small'; msg.textContent = 'Ordnerauswahl ist geöffnet …';
    try {
      const r = await desktopPickDir();
      if (r.error) { msg.className = 'sd-msg small bad'; msg.textContent = r.error; return; }
      if (r.cancelled) { msg.textContent = ''; return; }
      await apply(r.path);
    } catch (e) { msg.className = 'sd-msg small bad'; msg.textContent = String(e.message || e); }
  } }, icon('folder'), 'Ordner wählen …');
  const setBtn = h('button', { type: 'button', class: 'btn', onclick: () => apply(input.value) }, 'Übernehmen');
  const open = h('button', { type: 'button', class: 'btn', 'data-keep': '', onclick: () => desktopOpenDir().catch(() => {}) }, 'Im Explorer öffnen');
  const reset = h('button', { type: 'button', class: 'btn', onclick: () => run(() => desktopSaveDir('default'), 'Zurück auf den Standardordner gestellt.') }, 'Standard');
  run(() => desktopSaveDir('get'));
  return [
    h('div', { class: 'sd-cur' }, h('span', { class: 'label' }, 'Aktuell'), h('div', { class: 'sd-line' }, cur, badge)),
    h('div', { class: 'sd-actions' }, pick, open, reset),
    h('div', { class: 'field', style: { marginTop: '10px' } }, h('label', { class: 'label', for: 's-saveDir' }, 'Oder Pfad eingeben'),
      h('div', { class: 'row' }, input, setBtn)),
    msg,
    h('p', { class: 'small', style: { margin: '6px 2px 0' } }, 'Gilt für alle „Speichern“-Knöpfe in Dashboard, Protokoll und Mitarbeiter sowie für „Per E-Mail/WhatsApp senden“. Vorhandene Dateien werden nie überschrieben. Auch Netzlaufwerke und USB-Sticks sind möglich – sind sie nicht erreichbar, wird im Standardordner gespeichert.'),
  ];
}

export function sheetShell(title, onBack, ...content) {
  const sheet = h('div', { class: 'sheet', role: 'dialog', 'aria-modal': 'true' },
    h('header', { class: 'appbar' },
      h('button', { class: 'icon-btn', 'aria-label': 'Zurück', onclick: () => onBack() }, icon('back')),
      h('h1', null, title)),
    h('div', { class: 'body' }, h('main', { style: { paddingBottom: '30px' } }, ...content)));
  document.body.appendChild(sheet);
  document.body.style.overflow = 'hidden';
  return () => { sheet.remove(); document.body.style.overflow = ''; };
}

function sField(settings, key, label, opts = {}) {
  const id = `s-${key}`;
  const input = h('input', {
    id, type: opts.type || 'text', inputmode: opts.inputmode, maxlength: opts.maxlength, placeholder: opts.placeholder || 'Eingeben',
    autocomplete: 'off',
    oninput: (e) => {
      let v = e.target.value;
      if (opts.digits) { v = v.replace(/\D/g, '').slice(0, opts.maxlength || 99); e.target.value = v; }
      settings[key] = opts.number ? Math.max(1, parseInt(v || '1', 10)) : v;
    },
  });
  input.value = settings[key] ?? '';
  return h('div', { class: 'field' }, h('label', { class: 'label', for: id }, label),
    opts.trailing ? h('div', { class: 'row' }, input, opts.trailing) : input, opts.help && h('div', { class: 'msg small' }, opts.help));
}


/**
 * Einstellungen. opts: { can(perm), apiToken, extras: [Elemente] }
 * onSave(s, { apiToken }) – apiToken wird getrennt in der sicheren Ablage gespeichert.
 */
export function openSettings(settings, onSave, opts = {}) {
  const s = { ...settings };
  const can = opts.can || (() => true);
  let apiToken = opts.apiToken || '';
  const flatten = h('input', { type: 'checkbox', checked: !!s.flatten, onchange: (e) => { s.flatten = e.target.checked; } });
  const extended = h('input', { type: 'checkbox', checked: !!s.extendedMode, onchange: (e) => { s.extendedMode = e.target.checked; } });
  const pinStart = h('input', { type: 'checkbox', checked: s.pinOnStart !== false, onchange: (e) => { s.pinOnStart = e.target.checked; } });
  // Darstellung mit Sofortvorschau (für jeden Mitarbeiter erlaubt)
  const modes = [['hell', 'Hell'], ['dunkel', 'Dunkel'], ['system', 'System']];
  const seg = h('div', { class: 'seg seg-wide', role: 'radiogroup', 'aria-label': 'Darstellung' });
  const drawSeg = () => {
    seg.innerHTML = '';
    modes.forEach(([v, label]) => seg.appendChild(h('button', {
      type: 'button', role: 'radio', 'aria-checked': String((s.design || 'hell') === v), class: (s.design || 'hell') === v ? 'on' : '',
      onclick: () => { s.design = v; setDesign(v); drawSeg(); },
    }, label)));
  };
  drawSeg();

  // Server-Verbindung (Verbindungsart Domain/IP, Prüfen, Zertifikat bestätigen)
  const tokenInput = h('input', { id: 's-apiToken', type: 'password', autocomplete: 'off', placeholder: 'Vom Server-Betreiber', oninput: (e) => { apiToken = e.target.value.trim(); } });
  tokenInput.value = apiToken;
  let tokenVisible = false;
  const eye = h('button', { type: 'button', class: 'square-btn', 'aria-label': 'API-Token anzeigen', 'data-keep': '',
    onclick: () => { tokenVisible = !tokenVisible; tokenInput.type = tokenVisible ? 'text' : 'password'; eye.replaceChildren(icon(tokenVisible ? 'eyeOff' : 'eye')); eye.setAttribute('aria-label', tokenVisible ? 'API-Token verbergen' : 'API-Token anzeigen'); } }, icon('eye'));
  const srv = serverPanel(s, () => apiToken, opts.conn);

  const me = activeEmployee(settings);
  const lockedNote = (txt) => h('p', { class: 'perm-note' }, icon('lock'), txt);
  const section = (perm, ...children) => {
    const sec = h('section', { class: 'card' }, ...children);
    if (perm && !can(perm)) {
      sec.querySelectorAll('input, textarea, select, button').forEach((el) => { if (!el.hasAttribute('data-keep')) el.disabled = true; });
      sec.appendChild(lockedNote('Keine Berechtigung zum Ändern.'));
    }
    return sec;
  };

  const versionLine = h('p', { class: 'small app-version' }, `Version ${APP_VERSION}`);
  const close = sheetShell('Einstellungen', () => { onSave(s, { apiToken }); close(); },
    h('section', { class: 'card' }, h('h2', null, 'Darstellung'), seg,
      h('p', { class: 'small', style: { margin: '10px 2px 0' } }, 'Dunkel ist blendarm bei Nacht, hell gut lesbar bei Tageslicht. „System“ folgt der Einstellung von Windows bzw. dem Handy.')),
    section('settings', h('h2', null, 'Ansicht'),
      h('label', { class: 'toggle-row' }, h('span', { class: 'switch' }, extended, h('span')), 'Erweiterter Modus (Dashboard)'),
      h('p', { class: 'small', style: { margin: '4px 2px 6px' } }, 'Kalender, PDF-Dateien des Tages, Fotos, Wagendaten, Mitarbeiter und Papierkorb. Das Formular und der PDF-Export bleiben unverändert.'),
      hasEmployees(settings) && h('label', { class: 'toggle-row' }, h('span', { class: 'switch' }, pinStart, h('span')), 'PIN beim Programmstart abfragen')),
    section('server', h('h2', null, 'Server-Verbindung'),
      ...srv.nodes,
      h('div', { class: 'field' }, h('label', { class: 'label', for: 's-apiToken' }, 'API-Token'), h('div', { class: 'row' }, tokenInput, eye),
        h('div', { class: 'msg small' }, `Wird verschlüsselt abgelegt (${secretStorageKind()}), nie in PDFs oder Logdateien.`)),
      srv.checkRow,
      h('p', { class: 'small', style: { margin: '8px 2px 0' } }, `Genutzt für Halter-Abfrage, Anmeldung und den Abgleich der Protokolle. ${platformNetNote()}`)),
    section('settings', h('h2', null, 'Verwendendes EVU'),
      sField(s, 'evuNr', 'EVU-Nummer (UIC/VKM-Code)', { digits: true, maxlength: 4, inputmode: 'numeric' }),
      sField(s, 'evuName', 'EVU-Name'),
      evuLogoPanel(s)),
    section('settings', h('h2', null, 'Standard-Kontakt'),
      sField(s, 'contactName', 'Name'),
      sField(s, 'contactEmail', 'E-Mail', { type: 'email', trailing: copyButton(() => s.contactEmail) }),
      sField(s, 'contactPhone', 'Telefon-Nr.', { type: 'tel' })),
    hasEmployees(settings)
      ? h('section', { class: 'card' }, h('h2', null, 'Protokollnummer'),
        h('p', { class: 'small', style: { margin: '0 2px' } }, me
          ? `Präfix und laufende Nummer stehen im Mitarbeiterprofil. Nächste Nummer für ${fullName(me)}: ${normPrefix(me.prefix)}/${me.nextNumber || 1}`
          : 'Präfix und laufende Nummer stehen im Mitarbeiterprofil (Seitenleiste → Mitarbeiter).'))
      : section('settings', h('h2', null, 'Protokollnummer'),
        sField(s, 'reportPrefix', 'Präfix', { help: 'Nummer = Präfix/laufende Nummer, z. B. B13H09/316' }),
        sField(s, 'nextNumber', 'Nächste laufende Nummer', { digits: true, number: true, inputmode: 'numeric' })),
    section('settings', h('h2', null, 'PDF'),
      h('label', { class: 'toggle-row' }, h('span', { class: 'switch' }, flatten, h('span')), 'Formularfelder fixieren (nicht mehr editierbar)')),
    section('settings', h('h2', null, 'Speicherort für PDFs'), ...saveDirPanel()),
    h('section', { class: 'card' }, h('h2', null, 'Schadcode-Datenbank'),
      h('p', { class: 'small' }, db.quelle),
      h('p', { class: 'small' }, `${db.codes.length} Einträge, davon ${db.codes.filter((c) => c.auswaehlbar).length} auswählbare Schadcodes in ${db.kategorien.length} Kategorien.`)),
    h('div', { style: { display: 'flex', justifyContent: 'center' } },
      h('button', { class: 'btn primary', 'data-keep': '', onclick: () => { onSave(s, { apiToken }); close(); } }, 'Speichern')),
    versionLine);
  desktopBuild().then((b) => { if (b) versionLine.textContent += ` · Windows-Programm ${b}`; });
}

export function openResult({ filename, onShare, onSave, onPreview, onNew, onDashboard, canShare = true }) {
  let close;
  close = sheetShell('PDF erstellt', () => close(),
    h('div', { class: 'result' },
      h('div', { class: 'result-icon' }, '✓'),
      h('h2', null, 'Schadensprotokoll erstellt'),
      h('p', null, filename),
      h('div', { class: 'stack' },
        canShare && h('button', { class: 'btn primary', onclick: (ev) => onShare(ev.currentTarget) }, isDesktop ? 'Teilen (E-Mail, WhatsApp) …' : 'Senden / Teilen'),
        canShare && h('button', { class: 'btn', onclick: onSave }, isNative ? 'PDF speichern' : 'Herunterladen'),
        !canShare && h('p', { class: 'perm-note' }, icon('lock'), 'Teilen und Speichern ist für dich nicht freigegeben.'),
        (!isNative || isDesktop) && h('button', { class: 'btn', onclick: onPreview }, 'Vorschau'),
        h('button', { class: 'btn', onclick: () => { close(); onNew(); } }, 'Neues Protokoll'),
        onDashboard && h('button', { class: 'btn', onclick: () => { close(); onDashboard(); } }, 'Zum Dashboard'),
        h('button', { class: 'btn', onclick: () => close() }, 'Zurück zum Protokoll'))));
  return close;
}
