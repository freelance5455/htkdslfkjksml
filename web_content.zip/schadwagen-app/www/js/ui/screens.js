import { h, icon, confirmDialog, copyButton } from './dom.js';
import { db } from '../codes.js';
import { formatWagonNumber } from '../wagon.js';
import { formatDate } from '../pdf/fillProtocol.js';
import { isNative, isDesktop } from '../platform.js';
import { setDesign } from '../state.js';
import { checkUrl, checkConnection } from '../server.js';
import { secretStorageKind } from '../secrets.js';
import { hasEmployees, activeEmployee, fullName, normPrefix } from '../employees.js';

export function sheetShell(title, onBack, ...content) {
  const sheet = h('div', { class: 'sheet', role: 'dialog', 'aria-modal': 'true' },
    h('header', { class: 'appbar' },
      h('button', { class: 'icon-btn', 'aria-label': 'Zurück', onclick: () => onBack() }, icon('back')),
      h('h1', null, title)),
    h('div', { class: 'body' }, h('main', { style: { paddingBottom: '30px' } }, ...content)));
  document.body.appendChild(sheet);
  document.body.style.overflow = 'hidden';
  return () => { sheet.remove(); document.body.style.overflow = ''; };
}

function sField(settings, key, label, opts = {}) {
  const id = `s-${key}`;
  const input = h('input', {
    id, type: opts.type || 'text', inputmode: opts.inputmode, maxlength: opts.maxlength, placeholder: opts.placeholder || 'Eingeben',
    autocomplete: 'off',
    oninput: (e) => {
      let v = e.target.value;
      if (opts.digits) { v = v.replace(/\D/g, '').slice(0, opts.maxlength || 99); e.target.value = v; }
      settings[key] = opts.number ? Math.max(1, parseInt(v || '1', 10)) : v;
    },
  });
  input.value = settings[key] ?? '';
  return h('div', { class: 'field' }, h('label', { class: 'label', for: id }, label),
    opts.trailing ? h('div', { class: 'row' }, input, opts.trailing) : input, opts.help && h('div', { class: 'msg small' }, opts.help));
}

const CONN_TEXT = {
  ok: 'Verbunden', checking: 'Verbindung wird geprüft …', insecure: 'Nur https:// ist erlaubt.', bad_url: 'Adresse falsch.',
  bad_token: 'API-Token ungültig.', unreachable: 'Server nicht erreichbar.', none: '',
};

/**
 * Einstellungen. opts: { can(perm), apiToken, extras: [Elemente] }
 * onSave(s, { apiToken }) – apiToken wird getrennt in der sicheren Ablage gespeichert.
 */
export function openSettings(settings, onSave, opts = {}) {
  const s = { ...settings };
  const can = opts.can || (() => true);
  let apiToken = opts.apiToken || '';
  const flatten = h('input', { type: 'checkbox', checked: !!s.flatten, onchange: (e) => { s.flatten = e.target.checked; } });
  const extended = h('input', { type: 'checkbox', checked: !!s.extendedMode, onchange: (e) => { s.extendedMode = e.target.checked; } });
  const pinStart = h('input', { type: 'checkbox', checked: s.pinOnStart !== false, onchange: (e) => { s.pinOnStart = e.target.checked; } });
  // Darstellung mit Sofortvorschau (für jeden Mitarbeiter erlaubt)
  const modes = [['hell', 'Hell'], ['dunkel', 'Dunkel'], ['system', 'System']];
  const seg = h('div', { class: 'seg seg-wide', role: 'radiogroup', 'aria-label': 'Darstellung' });
  const drawSeg = () => {
    seg.innerHTML = '';
    modes.forEach(([v, label]) => seg.appendChild(h('button', {
      type: 'button', role: 'radio', 'aria-checked': String((s.design || 'hell') === v), class: (s.design || 'hell') === v ? 'on' : '',
      onclick: () => { s.design = v; setDesign(v); drawSeg(); },
    }, label)));
  };
  drawSeg();

  // Server-Verbindung
  const connMsg = h('div', { class: 'conn-msg', role: 'status', 'aria-live': 'polite' });
  const showConn = (c) => {
    connMsg.className = `conn-msg c-${c.status}`;
    connMsg.textContent = c.status === 'ok'
      ? `Verbunden · ${c.latency} ms${c.loginRequired ? (c.loggedIn ? ' · angemeldet' : ' · Anmeldung erforderlich (Reiter „Anmeldung“)') : ''}`
      : (c.message || CONN_TEXT[c.status] || '');
  };
  const tokenInput = h('input', { id: 's-apiToken', type: 'password', autocomplete: 'off', placeholder: 'Vom Server-Betreiber', oninput: (e) => { apiToken = e.target.value.trim(); } });
  tokenInput.value = apiToken;
  let tokenVisible = false;
  const eye = h('button', { type: 'button', class: 'square-btn', 'aria-label': 'API-Token anzeigen', 'data-keep': '',
    onclick: () => { tokenVisible = !tokenVisible; tokenInput.type = tokenVisible ? 'text' : 'password'; eye.replaceChildren(icon(tokenVisible ? 'eyeOff' : 'eye')); eye.setAttribute('aria-label', tokenVisible ? 'API-Token verbergen' : 'API-Token anzeigen'); } }, icon('eye'));
  const checkBtn = h('button', {
    type: 'button', class: 'btn', onclick: async () => {
      const u = checkUrl(s.serverUrl);
      if (!u.ok) { showConn({ status: u.reason === 'empty' ? 'bad_url' : u.reason, message: u.message || 'Bitte eine Server-Adresse eingeben.' }); return; }
      checkBtn.disabled = true;
      showConn({ status: 'checking' });
      const c = await checkConnection({ url: s.serverUrl, token: apiToken });
      checkBtn.disabled = false;
      showConn(c);
    },
  }, 'Verbindung prüfen');
  if (opts.conn && opts.conn.status !== 'none') showConn(opts.conn);

  const me = activeEmployee(settings);
  const lockedNote = (txt) => h('p', { class: 'perm-note' }, icon('lock'), txt);
  const section = (perm, ...children) => {
    const sec = h('section', { class: 'card' }, ...children);
    if (perm && !can(perm)) {
      sec.querySelectorAll('input, textarea, select, button').forEach((el) => { if (!el.hasAttribute('data-keep')) el.disabled = true; });
      sec.appendChild(lockedNote('Keine Berechtigung zum Ändern.'));
    }
    return sec;
  };

  const close = sheetShell('Einstellungen', () => { onSave(s, { apiToken }); close(); },
    h('section', { class: 'card' }, h('h2', null, 'Darstellung'), seg,
      h('p', { class: 'small', style: { margin: '10px 2px 0' } }, 'Dunkel ist blendarm bei Nacht, hell gut lesbar bei Tageslicht. „System“ folgt der Einstellung von Windows bzw. dem Handy.')),
    section('settings', h('h2', null, 'Ansicht'),
      h('label', { class: 'toggle-row' }, h('span', { class: 'switch' }, extended, h('span')), 'Erweiterter Modus (Dashboard)'),
      h('p', { class: 'small', style: { margin: '4px 2px 6px' } }, 'Kalender, PDF-Dateien des Tages, Fotos, Wagendaten, Mitarbeiter und Papierkorb. Das Formular und der PDF-Export bleiben unverändert.'),
      hasEmployees(settings) && h('label', { class: 'toggle-row' }, h('span', { class: 'switch' }, pinStart, h('span')), 'PIN beim Programmstart abfragen')),
    section('server', h('h2', null, 'Server-Verbindung'),
      sField(s, 'serverUrl', 'Server-Adresse', { type: 'url', placeholder: 'https://server.example.de', help: 'Nur https:// ist erlaubt. Genutzt für Halter-Abfrage, Anmeldung und den Abgleich der Protokolle.' }),
      h('div', { class: 'field' }, h('label', { class: 'label', for: 's-apiToken' }, 'API-Token'), h('div', { class: 'row' }, tokenInput, eye),
        h('div', { class: 'msg small' }, `Wird verschlüsselt abgelegt (${secretStorageKind()}), nie in PDFs oder Logdateien.`)),
      h('div', { class: 'conn-row' }, checkBtn, connMsg)),
    section('settings', h('h2', null, 'Verwendendes EVU'),
      sField(s, 'evuNr', 'EVU-Nummer (UIC/VKM-Code)', { digits: true, maxlength: 4, inputmode: 'numeric' }),
      sField(s, 'evuName', 'EVU-Name')),
    section('settings', h('h2', null, 'Standard-Kontakt'),
      sField(s, 'contactName', 'Name'),
      sField(s, 'contactEmail', 'E-Mail', { type: 'email', trailing: copyButton(() => s.contactEmail) }),
      sField(s, 'contactPhone', 'Telefon-Nr.', { type: 'tel' })),
    hasEmployees(settings)
      ? h('section', { class: 'card' }, h('h2', null, 'Protokollnummer'),
        h('p', { class: 'small', style: { margin: '0 2px' } }, me
          ? `Präfix und laufende Nummer stehen im Mitarbeiterprofil. Nächste Nummer für ${fullName(me)}: ${normPrefix(me.prefix)}/${me.nextNumber || 1}`
          : 'Präfix und laufende Nummer stehen im Mitarbeiterprofil (Seitenleiste → Mitarbeiter).'))
      : section('settings', h('h2', null, 'Protokollnummer'),
        sField(s, 'reportPrefix', 'Präfix', { help: 'Nummer = Präfix/laufende Nummer, z. B. B13H09/316' }),
        sField(s, 'nextNumber', 'Nächste laufende Nummer', { digits: true, number: true, inputmode: 'numeric' })),
    section('settings', h('h2', null, 'PDF'),
      h('label', { class: 'toggle-row' }, h('span', { class: 'switch' }, flatten, h('span')), 'Formularfelder fixieren (nicht mehr editierbar)')),
    h('section', { class: 'card' }, h('h2', null, 'Schadcode-Datenbank'),
      h('p', { class: 'small' }, db.quelle),
      h('p', { class: 'small' }, `${db.codes.length} Einträge, davon ${db.codes.filter((c) => c.auswaehlbar).length} auswählbare Schadcodes in ${db.kategorien.length} Kategorien.`)),
    h('div', { style: { display: 'flex', justifyContent: 'center' } },
      h('button', { class: 'btn primary', 'data-keep': '', onclick: () => { onSave(s, { apiToken }); close(); } }, 'Speichern')));
}

export function openResult({ filename, onShare, onSave, onPreview, onNew, onDashboard, canShare = true }) {
  let close;
  close = sheetShell('PDF erstellt', () => close(),
    h('div', { class: 'result' },
      h('div', { class: 'result-icon' }, '✓'),
      h('h2', null, 'Schadensprotokoll erstellt'),
      h('p', null, filename),
      h('div', { class: 'stack' },
        canShare && h('button', { class: 'btn primary', onclick: (ev) => onShare(ev.currentTarget) }, isDesktop ? 'Teilen (E-Mail, WhatsApp) …' : 'Senden / Teilen'),
        canShare && h('button', { class: 'btn', onclick: onSave }, isNative ? 'PDF speichern' : 'Herunterladen'),
        !canShare && h('p', { class: 'perm-note' }, icon('lock'), 'Teilen und Speichern ist für dich nicht freigegeben.'),
        (!isNative || isDesktop) && h('button', { class: 'btn', onclick: onPreview }, 'Vorschau'),
        h('button', { class: 'btn', onclick: () => { close(); onNew(); } }, 'Neues Protokoll'),
        onDashboard && h('button', { class: 'btn', onclick: () => { close(); onDashboard(); } }, 'Zum Dashboard'),
        h('button', { class: 'btn', onclick: () => close() }, 'Zurück zum Protokoll'))));
  return close;
}
