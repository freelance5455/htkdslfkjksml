// Abgleich mit dem Server: erstellte Protokolle hochladen, eingehende Protokolle abrufen,
// Mitarbeiterliste abgleichen. Läuft nur bei bestehender Verbindung und Anmeldung.
import { api, canSync, conn } from './server.js';
import { getReport, putReport, destroyedIds } from './storage.js';
import { ownerOf, createdByOf, mergeEmployees } from './employees.js';
import { mergeFolders } from './folders.js';

const PENDING = 'sw.syncPending.v1';
const LAST_PULL = 'sw.lastPull.v1';

const readPending = () => { try { return new Set(JSON.parse(localStorage.getItem(PENDING) || '[]')); } catch { return new Set(); } };
const writePending = (s) => { try { localStorage.setItem(PENDING, JSON.stringify([...s])); } catch { /* voll */ } };
export const pendingCount = () => readPending().size;

/** Protokoll hochladen; ohne Verbindung für später vormerken. */
export async function pushProtocol(report) {
  const pend = readPending();
  if (!canSync()) { pend.add(report.id); writePending(pend); return { ok: false, queued: true }; }
  const copy = JSON.parse(JSON.stringify(report));
  delete copy.keeperLookup; delete copy.keeperAuto;
  const r = await api(`/api/protocols/${encodeURIComponent(report.id)}`, { method: 'PUT', body: { report: copy }, timeout: 60000 });
  if (r.ok || r.status === 409) { pend.delete(report.id); writePending(pend); return { ok: r.ok }; }
  pend.add(report.id); writePending(pend);
  return { ok: false, queued: true };
}

export async function pushPending() {
  if (!canSync()) return 0;
  let n = 0;
  for (const id of readPending()) {
    const r = await getReport(id);
    if (!r || r.deletedAt) { const p = readPending(); p.delete(id); writePending(p); continue; }
    if ((await pushProtocol(r)).ok) n++;
  }
  return n;
}

/**
 * Eingehende Protokolle abrufen. Unbekannte werden angelegt und über Präfix/Name einem
 * Mitarbeiter zugeordnet; vorhandene nur aktualisiert, wenn der Server einen neueren Stand hat.
 * Ergebnis: { added, updated }
 */
export async function pullProtocols(settings, { full = false } = {}) {
  if (!canSync()) return { added: 0, updated: 0, skipped: true };
  const since = full ? '' : (localStorage.getItem(LAST_PULL) || '');
  const r = await api(`/api/protocols${since ? `?since=${encodeURIComponent(since)}` : ''}`);
  if (!r.ok || !r.data) return { added: 0, updated: 0, error: r.error || 'network' };
  const gone = destroyedIds();
  let added = 0, updated = 0;
  for (const meta of r.data.protocols || []) {
    if (!meta.id || gone.has(meta.id)) continue;
    const local = await getReport(meta.id);
    if (local && (local.deletedAt || (local.updatedAt || '') >= (meta.updatedAt || ''))) continue;
    const one = await api(`/api/protocols/${encodeURIComponent(meta.id)}`, { timeout: 60000 });
    if (!one.ok || !one.data || !one.data.report) continue;
    const rep = one.data.report;
    if (!rep.id || rep.id !== meta.id) continue;
    rep.source = rep.source || 'server';
    rep.receivedAt = meta.receivedAt || new Date().toISOString();
    if (!rep.createdBy || !rep.createdBy.id) {
      const { employee } = ownerOf(rep, settings);
      if (employee) rep.createdBy = { ...createdByOf(employee), at: rep.createdBy?.at || rep.pdfCreatedAt || rep.updatedAt, auto: true };
    }
    await putReport(rep);
    if (local) updated++; else added++;
  }
  if (r.data.serverTime) try { localStorage.setItem(LAST_PULL, r.data.serverTime); } catch { /* voll */ }
  return { added, updated };
}

/** Mitarbeiterliste mit dem Server abgleichen. Liefert die zusammengeführte Liste oder null. */
export async function syncEmployees(settings) {
  if (!canSync() || !conn.features.includes('employees')) return null;
  const r = await api('/api/employees', { method: 'PUT', body: { employees: settings.employees || [] } });
  if (!r.ok || !r.data || !Array.isArray(r.data.employees)) return null;
  return mergeEmployees(settings.employees || [], r.data.employees);
}

/** Eigene Ordner mit dem Server abgleichen (je Ordner gewinnt der neueste Stand). */
export async function syncFolders(settings) {
  if (!canSync() || !conn.features.includes('folders')) return null;
  const r = await api('/api/folders', { method: 'PUT', body: { folders: settings.folders || [] } });
  if (!r.ok || !r.data || !Array.isArray(r.data.folders)) return null;
  return mergeFolders(settings.folders || [], r.data.folders);
}
