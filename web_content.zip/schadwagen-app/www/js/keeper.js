// Halter-Abfrage per Wagennummer über das eigene Backend (GET /api/keeper/{evn}).
// Ergebnisse werden 30 Tage lokal gespeichert.
import { onlyDigits, validateWagonNumber } from './wagon.js';

const CACHE_KEY = 'sw.keeperCache.v1';
const TTL_MS = 30 * 24 * 60 * 60 * 1000;
const TIMEOUT_MS = 10000;

function readCache() {
  try { return JSON.parse(localStorage.getItem(CACHE_KEY) || '{}') || {}; } catch { return {}; }
}
function writeCache(c) {
  try { localStorage.setItem(CACHE_KEY, JSON.stringify(c)); } catch { /* Speicher voll oder gesperrt */ }
}
export function cachedKeeper(evn) {
  const c = readCache();
  const e = c[evn];
  if (!e) return null;
  if (Date.now() - e.savedAt > TTL_MS) { delete c[evn]; writeCache(c); return null; }
  return e;
}
function storeKeeper(evn, keeper, source) {
  const c = readCache();
  const now = Date.now();
  for (const k of Object.keys(c)) if (now - c[k].savedAt > TTL_MS) delete c[k]; // Abgelaufenes aufräumen
  c[evn] = { keeper, source, savedAt: now };
  writeCache(c);
}

/**
 * Ergebnis: { status, keeper?, source?, cached?, message }
 * status: ok | invalid | not_found | unavailable | not_configured | offline | disabled
 */
export async function lookupKeeper(raw, { baseUrl, apiKey, session } = {}) {
  const evn = onlyDigits(raw);
  const v = validateWagonNumber(evn);
  if (v !== 'ok') {
    return { status: 'invalid', message: v === 'invalid' ? 'Ungültige Wagennummer: Die Prüfziffer stimmt nicht.' : 'Ungültige Wagennummer: Es werden genau 12 Ziffern benötigt.' };
  }
  const hit = cachedKeeper(evn);
  if (hit) return { status: 'ok', keeper: hit.keeper, source: hit.source, cached: true, message: 'Halter übernommen (gespeichert)' };

  const url = String(baseUrl || '').trim().replace(/\/+$/, '');
  if (!url) return { status: 'disabled', message: 'Halter-Abfrage: Server-Verbindung in den Einstellungen eintragen.' };
  if (typeof navigator !== 'undefined' && navigator.onLine === false) {
    return { status: 'offline', message: 'Offline – nur die Prüfziffer wurde geprüft.' };
  }

  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
  let res;
  try {
    res = await fetch(`${url}/api/keeper/${evn}`, {
      headers: { ...(apiKey ? { 'X-Api-Key': apiKey } : {}), ...(session ? { Authorization: `Bearer ${session}` } : {}) },
      signal: ctrl.signal, cache: 'no-store',
    });
  } catch {
    clearTimeout(timer);
    return navigator.onLine === false
      ? { status: 'offline', message: 'Offline – nur die Prüfziffer wurde geprüft.' }
      : { status: 'unavailable', message: 'Halter-Abfrage nicht erreichbar. Bitte Halterdaten von Hand eintragen.' };
  }
  clearTimeout(timer);
  let body = {};
  try { body = await res.json(); } catch { /* keine JSON-Antwort */ }
  if (res.ok && body.keeper) {
    storeKeeper(evn, body.keeper, body.source || '');
    return { status: 'ok', keeper: body.keeper, source: body.source || '', cached: false, message: 'Halter übernommen' };
  }
  if (res.status === 400 || body.error === 'invalid_evn') return { status: 'invalid', message: body.message || 'Ungültige Wagennummer.' };
  if (res.status === 404 || body.error === 'not_found') return { status: 'not_found', message: 'Wagen nicht gefunden – Halterdaten bitte von Hand eintragen.' };
  if (body.error === 'not_configured') return { status: 'not_configured', message: 'Halter-Abfrage ist noch nicht freigeschaltet (Datenquelle fehlt).' };
  if (res.status === 401 && body.error === 'login_required') return { status: 'unavailable', message: 'Halter-Abfrage: bitte zuerst beim Server anmelden (Reiter „Anmeldung“).' };
  if (res.status === 401) return { status: 'unavailable', message: 'Halter-Abfrage: API-Token fehlt oder ist falsch.' };
  if (res.status === 429) return { status: 'unavailable', message: 'Halter-Abfrage: zu viele Abfragen – bitte kurz warten.' };
  return { status: 'unavailable', message: 'Halter-Abfrage nicht erreichbar. Bitte Halterdaten von Hand eintragen.' };
}
