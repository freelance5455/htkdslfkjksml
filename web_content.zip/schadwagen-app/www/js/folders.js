// Ordner in „Gespeichert“.
// 1. Datumsordner werden allein aus „Schaden festgestellt am“ (detectionDate) gebildet:
//    „Schadprotokoll 2026“ › „Schadprotokoll 01.26“ › „17.01.2026“, ohne Datum „Ohne Datum“.
//    Sie werden nicht gespeichert, sondern bei jeder Anzeige berechnet – dadurch entstehen sie
//    automatisch beim Hochladen/Erstellen, wandern bei Datumsänderung mit und verschwinden, wenn leer.
// 2. Eigene Ordner (settings.folders): { id, name, items: [Protokoll-IDs], createdAt, updatedAt, deleted? }
//    Ein Protokoll liegt höchstens in einem eigenen Ordner und bleibt zusätzlich im Datumsordner.

const p2 = (n) => String(n).padStart(2, '0');

/** Datum der Schadensfeststellung als { y, m, d, iso } oder null. */
export function detectionParts(r) {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String((r && r.detectionDate) || ''));
  if (!m) return null;
  const y = +m[1], mo = +m[2], d = +m[3];
  if (y < 1990 || y > 2100 || mo < 1 || mo > 12 || d < 1 || d > 31) return null;
  return { y, m: mo, d, iso: `${m[1]}-${m[2]}-${m[3]}` };
}

export const yearName = (y) => `Schadprotokoll ${y}`;
export const monthName = (y, m) => `Schadprotokoll ${p2(m)}.${String(y).slice(-2)}`;
export const dayName = (iso) => { const [y, m, d] = iso.split('-'); return `${d}.${m}.${y}`; };
export const NO_DATE = 'Ohne Datum';

/**
 * Datumsbaum aus Protokollen: Map Jahr -> Map Monat -> Map Tag(ISO) -> [Protokolle]; dazu noDate.
 */
export function dateTree(reports) {
  const years = new Map();
  const noDate = [];
  for (const r of reports) {
    const p = detectionParts(r);
    if (!p) { noDate.push(r); continue; }
    if (!years.has(p.y)) years.set(p.y, new Map());
    const months = years.get(p.y);
    if (!months.has(p.m)) months.set(p.m, new Map());
    const days = months.get(p.m);
    if (!days.has(p.iso)) days.set(p.iso, []);
    days.get(p.iso).push(r);
  }
  return { years, noDate };
}

/** Ordnerpfad eines Protokolls als Text, z. B. für Suchergebnisse. */
export function datePathLabel(r) {
  const p = detectionParts(r);
  return p ? [yearName(p.y), monthName(p.y, p.m), dayName(p.iso)] : [NO_DATE];
}

/* ---------- Eigene Ordner ---------- */

const newId = () => (crypto.randomUUID ? crypto.randomUUID() : `f${Date.now().toString(36)}${Math.random().toString(36).slice(2, 10)}`);
const now = () => new Date().toISOString();
const clone = (s) => (s.folders || []).map((f) => ({ ...f, items: [...(f.items || [])] }));

export const listFolders = (s) => (s.folders || []).filter((f) => f && !f.deleted)
  .sort((a, b) => a.name.localeCompare(b.name, 'de', { sensitivity: 'base', numeric: true }));
export const findFolder = (s, id) => listFolders(s).find((f) => f.id === id) || null;
export const folderOf = (s, reportId) => listFolders(s).find((f) => (f.items || []).includes(reportId)) || null;

/** Name prüfen; liefert Fehlermeldung oder ''. */
export function folderNameError(s, name, exceptId) {
  const n = String(name || '').trim();
  if (!n) return 'Bitte einen Namen eingeben.';
  if (n.length > 60) return 'Höchstens 60 Zeichen.';
  if (/[\\/]/.test(n)) return 'Der Name darf kein „/“ oder „\\“ enthalten.';
  if (listFolders(s).some((f) => f.id !== exceptId && f.name.trim().toLowerCase() === n.toLowerCase())) return 'Ein Ordner mit diesem Namen existiert bereits.';
  if (/^(schadprotokoll\s|ohne datum$)/i.test(n)) return 'Dieser Name ist für die automatischen Datumsordner reserviert.';
  return '';
}

/** Neue Ordnerliste mit zusätzlichem Ordner. Liefert { folders, folder }. */
export function addFolder(s, name) {
  const t = now();
  const folder = { id: newId(), name: String(name).trim(), items: [], createdAt: t, updatedAt: t };
  return { folders: [...clone(s), folder], folder };
}
export function renameFolder(s, id, name) {
  return clone(s).map((f) => (f.id === id ? { ...f, name: String(name).trim(), updatedAt: now() } : f));
}
/** Löschen: als gelöscht markiert (für den Abgleich), Inhalt bleibt in den Datumsordnern. */
export function removeFolder(s, id) {
  return clone(s).map((f) => (f.id === id ? { ...f, items: [], deleted: true, updatedAt: now() } : f));
}
/** Protokoll in einen eigenen Ordner legen (aus anderen eigenen Ordnern entfernt); folderId null = herausnehmen. */
export function moveToFolder(s, reportId, folderId) {
  return clone(s).map((f) => {
    if (f.deleted) return f;
    const has = f.items.includes(reportId);
    if (f.id === folderId && !has) return { ...f, items: [...f.items, reportId], updatedAt: now() };
    if (f.id !== folderId && has) return { ...f, items: f.items.filter((x) => x !== reportId), updatedAt: now() };
    return f;
  });
}

/** Abgleich zweier Listen: je ID gewinnt der neueste Stand. */
export function mergeFolders(a = [], b = []) {
  const map = new Map();
  for (const f of [...a, ...b]) {
    if (!f || !f.id) continue;
    const old = map.get(f.id);
    if (!old || (f.updatedAt || '') > (old.updatedAt || '')) map.set(f.id, { ...f, items: [...(f.items || [])] });
  }
  return [...map.values()];
}
