// Protokolle einlesen: PDF aus dieser App (hinterlegte Daten), fremde GCU-PDF mit Formularfeldern
// oder JSON-Datei. Ergebnis: { report, pdfBytes?, via: 'embedded'|'fields'|'json' }
import { newReport, newDamage, loadSettings } from './state.js';
import { EMBED_KEY } from './pdf/fillProtocol.js';
import { onlyDigits } from './wagon.js';
import { lookup } from './codes.js';

// Ankreuzfelder der GCU-Vorlage: Exportwerte in Widget-Reihenfolge -> Wert in der App
const CHOICES = {
  LoadingStatus: { values: { 1: 'beladen', 0: 'leer' }, order: ['beladen', 'leer'] },
  DispatchedToWorkshop: { values: { BeforeUnloading: 'before', AfterUnloading: 'after' }, order: ['before', 'after'] },
  CompanyType: { values: { GCUsignatoryRU: 'avv', NonGCUsignatoryRU: 'nonavv', NonRU: 'siding' }, order: ['avv', 'nonavv', 'siding'] },
  DamageCategory: { values: { ThirdParty: 'third', Wear: 'wear', ImpactDamage: 'own', NotAscertainable: 'unknown' }, order: ['third', 'wear', 'own', 'unknown'] },
};
const OLD_DAMAGE = { values: { 0: false, 1: true }, order: [false, true] };
const LABELS = ['K', 'M', 'I', 'R1', 'U'];
const EMAIL_RE = /[^\s,;<>]+@[^\s,;<>]+\.[^\s,;<>]+/;

/** Name eines PDF-Namensobjekts lesbar machen (/Before#20Unloading -> Before Unloading). */
const nameText = (n) => {
  if (!n) return '';
  const raw = typeof n.decodeText === 'function' ? n.decodeText() : String(n).replace(/^\//, '');
  return raw.replace(/#([0-9a-fA-F]{2})/g, (_, h) => String.fromCharCode(parseInt(h, 16)));
};

/**
 * Zustand eines Ankreuzfelds bzw. einer Optionsgruppe lesen – unabhängig davon, ob die Vorlage
 * es als Radio- oder Checkbox-Gruppe angelegt hat. Liefert { value, index } oder null.
 */
function readChoice(form, name, spec) {
  let field;
  try { field = form.getField(name); } catch { field = null; }
  if (!field) return spec ? readByExportValue(form, spec) : null;
  const { PDFName } = globalThis.PDFLib;
  const acro = field.acroField;
  const widgets = acro.getWidgets();
  // 1. eingeschaltetes Widget (Darstellungszustand /AS)
  for (let i = 0; i < widgets.length; i++) {
    const as = nameText(widgets[i].getAppearanceState && widgets[i].getAppearanceState());
    if (as && as !== 'Off') return { value: as, index: i };
  }
  // 2. Feldwert /V
  const v = nameText(acro.dict.lookup(PDFName.of('V')));
  if (v && v !== 'Off') {
    const idx = widgets.findIndex((w) => { try { return nameText(w.getOnValue()) === v; } catch { return false; } });
    return { value: v, index: idx };
  }
  return null;
}
const mapChoice = (c, spec) => {
  if (!c) return undefined;
  if (Object.prototype.hasOwnProperty.call(spec.values, c.value)) return spec.values[c.value];
  return c.index >= 0 && c.index < spec.order.length ? spec.order[c.index] : undefined;
};
const isChecked = (form, name) => !!readChoice(form, name);

/**
 * Ersatzweg für umbenannte Felder (andere Programme/Vorlagenstände): alle Formular-Widgets nach
 * einem eingeschalteten Zustand mit eindeutigem Exportwert durchsuchen (z. B. /BeforeUnloading).
 */
function readByExportValue(form, spec) {
  const { PDFName, PDFDict } = globalThis.PDFLib;
  const doc = form && form.doc;
  if (!doc) return null;
  for (const page of doc.getPages()) {
    const annots = page.node.Annots && page.node.Annots();
    if (!annots) continue;
    for (let i = 0; i < annots.size(); i++) {
      const a = annots.lookup(i);
      if (!(a instanceof PDFDict)) continue;
      const as = nameText(a.lookup(PDFName.of('AS')));
      if (as && as !== 'Off' && Object.prototype.hasOwnProperty.call(spec.values, as)) return { value: as, index: -1 };
    }
  }
  return null;
}

/** Zustand aller Ankreuzfelder der GCU-Vorlage, so wie sie in der PDF sichtbar sind. */
function readChoices(form) {
  return {
    loadingStatus: mapChoice(readChoice(form, 'LoadingStatus'), CHOICES.LoadingStatus) || '',
    workshop: mapChoice(readChoice(form, 'DispatchedToWorkshop', CHOICES.DispatchedToWorkshop), CHOICES.DispatchedToWorkshop) || '',
    takeover: mapChoice(readChoice(form, 'CompanyType', CHOICES.CompanyType), CHOICES.CompanyType) || '',
    cause: mapChoice(readChoice(form, 'DamageCategory', CHOICES.DamageCategory), CHOICES.DamageCategory) || '',
    existingLabels: Object.fromEntries(LABELS.map((l) => [l, isChecked(form, `ExistingLabels_DamageLabel_${l}`)]).filter(([, on]) => on)),
    newLabels: Object.fromEntries(LABELS.map((l) => [l, isChecked(form, `NewLabels_DamageLabel_${l}`)]).filter(([, on]) => on)),
    wagonDetached: isChecked(form, 'WagonDetached'),
    attachments: isChecked(form, 'Attachments'),
    old: [1, 2, 3].map((n) => mapChoice(readChoice(form, `Damage${n}_OldDamage`), OLD_DAMAGE) === true),
  };
}

/** Hat die PDF noch ausfüllbare Felder der GCU-Vorlage (nicht fixiert)? */
function hasGcuFields(form) {
  if (!form) return false;
  try { return ['ReportID', 'WagonNumberFreight', 'LoadingStatus'].some((n) => { try { return !!form.getField(n); } catch { return false; } }); }
  catch { return false; }
}

/**
 * PDF aus dieser App, die danach in einem PDF-Programm geändert wurde (z. B. Werkstattzuführung
 * nachträglich angekreuzt): die sichtbaren Ankreuzfelder haben Vorrang vor den hinterlegten Daten.
 */
function applyVisibleChoices(report, doc) {
  let form;
  try { form = doc.getForm(); } catch { return; }
  if (!hasGcuFields(form)) return; // fixiert -> hinterlegte Daten gelten
  const c = readChoices(form);
  const changed = [];
  const set = (key, value) => {
    if (JSON.stringify(report[key] ?? '') !== JSON.stringify(value)) changed.push(key);
    report[key] = value;
  };
  ['loadingStatus', 'workshop', 'takeover', 'cause', 'existingLabels', 'newLabels', 'wagonDetached'].forEach((k) => set(k, c[k]));
  // „Weitere Anlagen“ wird bei Fotos automatisch angekreuzt – nur übernehmen, wenn keine Fotoseiten folgen
  if (c.attachments !== !!report.attachments && !(c.attachments && doc.getPageCount() > 1)) set('attachments', c.attachments);
  (report.damages || []).slice(0, 3).forEach((d, i) => { if (!!d.old !== c.old[i]) { d.old = c.old[i]; changed.push(`damage${i + 1}.old`); } });
  // Texte, die nur mit dem Ankreuzfeld Sinn ergeben, aus der PDF ergänzen
  const val = (n) => { try { const f = form.getField(n); return f && f.getText ? (f.getText() || '').trim() : ''; } catch { return ''; } };
  if (report.cause === 'third' && !report.perpetrator) report.perpetrator = val('Perpetrator');
  if (report.takeover && !report.takeoverName) {
    report.takeoverNr = val('HandingOverCompany_Company').replace(/\D/g, '').slice(0, 4);
    report.takeoverName = val('HandingOverCompany_CompanyName');
  }
  if (Object.keys(report.existingLabels || {}).length && !report.existingDate) {
    report.existingDate = deToIso(val('Date'));
    report.existingRuNr = val('ReportingRU_Company').replace(/\D/g, '').slice(0, 4);
    report.existingRuName = val('ReportingRU_CompanyName');
  }
  if (changed.length) report.changedInPdf = changed;
}

const deToIso = (s) => {
  const m = /(\d{1,2})\.(\d{1,2})\.(\d{4})/.exec(String(s || ''));
  return m ? `${m[3]}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}` : '';
};

/** Datum nur übernehmen, wenn es plausibel ist (nicht aus der Vorlage von 2018, nicht in der Zukunft). */
export function credibleDate(d) {
  const t = d instanceof Date ? d.getTime() : new Date(d || NaN).getTime();
  if (!Number.isFinite(t)) return null;
  if (t < Date.UTC(2021, 0, 1) || t > Date.now() + 86400000) return null;
  return new Date(t).toISOString();
}
/** Tag der Schadensfeststellung als Zeitpunkt (12 Uhr Ortszeit), falls kein anderes Datum vorliegt. */
const dayToIso = (iso) => {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(iso || ''));
  return m ? credibleDate(new Date(+m[1], +m[2] - 1, +m[3], 12, 0, 0)) : null;
};
/** Datum für den Kalender: Erstellung der PDF, sonst Schadensfeststellung, sonst jetzt. */
export function calendarDate(report, doc) {
  return credibleDate(report && report.pdfCreatedAt)
    || (doc && (credibleDate(doc.getModificationDate()) || credibleDate(doc.getCreationDate())))
    || dayToIso(report && report.detectionDate)
    || new Date().toISOString();
}

export async function readProtocolFile(file) {
  const bytes = new Uint8Array(await file.arrayBuffer());
  const name = file.name || '';
  if (/\.json$/i.test(name) || bytes[0] === 0x7b) {
    const data = JSON.parse(new TextDecoder().decode(bytes));
    const report = data && data.format === 'schadwagen-protokoll' ? data.report : data;
    if (!report || !report.id) throw new Error('Die Datei enthält kein Schadensprotokoll.');
    report.pdfCreatedAt = calendarDate(report, null);
    return { report, via: 'json' };
  }
  const { PDFDocument, PDFName } = globalThis.PDFLib;
  let doc;
  try { doc = await PDFDocument.load(bytes, { ignoreEncryption: true, updateMetadata: false }); }
  catch { throw new Error('Die Datei ist keine lesbare PDF.'); }
  // 1. In dieser App erstellte PDF: hinterlegte Protokolldaten
  const info = doc.context.lookup(doc.context.trailerInfo.Info);
  const raw = info && info.lookup ? info.lookup(PDFName.of(EMBED_KEY)) : null;
  if (raw && raw.decodeText) {
    try {
      const data = JSON.parse(raw.decodeText());
      if (data && data.report && data.report.id) {
        const report = data.report;
        report.pdfCreatedAt = calendarDate(report, doc);
        if (report.reportId) report.numberUsed = true;
        report.status = 'erstellt';
        delete report.changedInPdf;
        applyVisibleChoices(report, doc);
        report.choicesImported = true;
        return { report, pdfBytes: bytes, via: 'embedded' };
      }
    } catch { /* weiter mit Formularfeldern */ }
  }
  // 2. GCU-Formular mit ausgefüllten Feldern
  let form;
  try { form = doc.getForm(); } catch { form = null; }
  const val = (n) => {
    try { const f = form.getField(n); return f && f.getText ? (f.getText() || '').trim() : ''; } catch { return ''; }
  };
  const reportId = form ? val('ReportID') : '';
  const wagon = form ? onlyDigits(val('WagonNumberFreight')) : '';
  if (!reportId && !wagon) return fromTitle(doc, bytes, name);
  const r = newReport(loadSettings());
  Object.assign(r, {
    status: 'erstellt', numberUsed: true, reportId, wagonNumber: wagon,
    trainNumber: val('OperationalTrainNumber'), consignmentNumber: val('ConsignmentNumber') === 'Unbekannt' ? '' : val('ConsignmentNumber'),
    detectionPlace: val('DamageDetection_Location_PrimaryLocationName'), detectionDate: deToIso(val('DetectionDate')),
    origin: val('Origin_PrimaryLocationName'), destination: val('Destination_PrimaryLocationName'), departureDate: deToIso(val('DepartureDate')),
    keeperVkm: val('Keeper'), keeperName: val('Keeper_Name_or_VKM'), keeperAddress: val('Keeper_Address_or_Email'),
    remarks: val('Remarks'), contactName: (val('ContactUserRU').split('\n')[0] || '').trim(), contactEmail: '', contactPhone: '',
    pdfCreatedAt: '',
  });
  // Halter: Adresse und E-Mail stehen in einem Feld
  const keeperAll = val('Keeper_Address_or_Email');
  const keeperMail = (EMAIL_RE.exec(keeperAll) || [''])[0];
  r.keeperEmail = keeperMail;
  r.keeperAddress = keeperMail ? keeperAll.replace(keeperMail, '').replace(/[\s,;]+$/, '').replace(/^[\s,;]+/, '').replace(/,\s*,/g, ',').trim() : keeperAll;
  // Kontakt: Name, E-Mail, „Tel. …“ zeilenweise
  const contact = val('ContactUserRU').split(/\n/).map((x) => x.trim()).filter(Boolean);
  r.contactEmail = contact.find((x) => EMAIL_RE.test(x)) || '';
  r.contactPhone = (contact.find((x) => /^tel/i.test(x)) || '').replace(/^tel\.?\s*/i, '');
  r.contactName = contact.find((x) => x !== r.contactEmail && !/^tel/i.test(x)) || '';
  // Ankreuzfelder 1:1
  const c = readChoices(form);
  Object.assign(r, { loadingStatus: c.loadingStatus, workshop: c.workshop, takeover: c.takeover, cause: c.cause,
    existingLabels: c.existingLabels, newLabels: c.newLabels, wagonDetached: c.wagonDetached, attachments: c.attachments });
  r.existingDate = deToIso(val('Date'));
  r.existingRuNr = val('ReportingRU_Company').replace(/\D/g, '').slice(0, 4);
  r.existingRuName = val('ReportingRU_CompanyName');
  r.takeoverNr = val('HandingOverCompany_Company').replace(/\D/g, '').slice(0, 4);
  r.takeoverName = val('HandingOverCompany_CompanyName');
  r.perpetrator = val('Perpetrator');
  const damages = [];
  for (let n = 1; n <= 3; n++) {
    const parts = [1, 2, 3, 4].map((k) => val(`Damage${n}_CodeDigit${k}`)).filter(Boolean);
    if (!parts.length) continue;
    const code = parts.join('.');
    const desc = val(`Damage${n}_Description`);
    const info = lookup(code);
    const d = { ...newDamage(), code, old: c.old[n - 1] };
    if (info && info.auswaehlbar) {
      // Beschreibung = Katalogtext -> keine eigene Bemerkung
      d.remark = desc && desc !== info.kurztext ? desc : '';
    } else {
      // kein auswählbarer Schadcode: „kein passender Schadcode“ mit Kategorie und 2. Ebene
      d.noCode = true; d.code = ''; d.customCategory = parts[0] || ''; d.customSub = parts[1] || ''; d.customText = desc;
    }
    damages.push(d);
  }
  if (damages.length) r.damages = damages;
  r.choicesImported = true;
  if (reportId || wagon) r.id = stableId(reportId, wagon);
  r.source = 'import';
  r.numberUsed = !!reportId;
  r.pdfCreatedAt = calendarDate(r, doc);
  return { report: r, pdfBytes: bytes, via: 'fields' };
}

// Gleiche Datei erneut eingelesen -> gleiche ID (keine Doppelten)
function stableId(reportId, wagon) {
  const slug = String(reportId || '').replace(/[^A-Za-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 30);
  return `imp-${slug || 'ohne'}-${onlyDigits(wagon) || 'x'}`.slice(0, 64);
}

/**
 * 3. Fixierte PDF aus einer älteren Version dieser App (ohne hinterlegte Daten):
 * Titel „Schadensprotokoll <Nr.> <Wagennummer>“ und Dateiname „<TT.MM.JJJJ> <Versandbahnhof> <Wagennummer>.pdf“.
 */
function fromTitle(doc, bytes, name) {
  const title = String(doc.getTitle() || '').trim();
  const m = /^Schadensprotokoll\s*(.*?)\s*(\d{2}[ -]?\d{2}[ -]?\d{4}[ -]?\d{3}-?\d)?$/.exec(title);
  if (!m || (!m[1] && !m[2])) throw new Error('In der PDF wurden keine Protokolldaten gefunden (fremdes Format oder Formular fixiert).');
  const reportId = (m[1] || '').trim();
  const wagon = onlyDigits(m[2] || '');
  const f = /^(\d{2}\.\d{2}\.\d{4})\s+(.*?)\s*\d{2} \d{2} \d{4} \d{3}-\d/.exec(String(name || '').replace(/\.pdf$/i, ''));
  const r = newReport(loadSettings());
  Object.assign(r, {
    id: stableId(reportId, wagon), status: 'erstellt', numberUsed: !!reportId, reportId, wagonNumber: wagon,
    detectionDate: f ? deToIso(f[1]) : '', origin: f ? f[2].replace(/_\d+$/, '').trim() : '',
    contactName: '', contactEmail: '', contactPhone: '', source: 'import', partial: true,
  });
  r.damages = [];
  r.pdfCreatedAt = calendarDate(r, doc);
  return { report: r, pdfBytes: bytes, via: 'title' };
}
