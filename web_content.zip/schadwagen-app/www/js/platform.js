// Plattform-Funktionen: Android-App (window.AndroidBridge aus MainActivity.java),
// Capacitor (iOS) über Plugins, im Browser/PWA über Web-Share bzw. Download.

const cap = window.Capacitor;
const android = window.AndroidBridge;
const isCapacitor = !!(cap && typeof cap.isNativePlatform === 'function' && cap.isNativePlatform());
export const isAndroidApp = !!android;
export const isDesktop = (location.hostname === '127.0.0.1' || location.hostname === 'localhost') && location.port === '47831';
export const isNative = isAndroidApp || isCapacitor || isDesktop;

// Windows-Programm (windows/main.go): lokaler Server mit Speichern in Dokumente\Schadensprotokolle
let desktopInfo = null;
async function desktop() {
  if (!desktopInfo) desktopInfo = await (await fetch('/__desktop.json', { cache: 'no-store' })).json();
  return desktopInfo;
}
export async function desktopPost(path, params, body) {
  const { token } = await desktop();
  const res = await fetch(`${path}?${new URLSearchParams(params)}`, { method: 'POST', headers: { 'X-Token': token }, body });
  if (!res.ok) throw new Error(await res.text());
  return res.status === 204 ? null : res.json();
}
export async function desktopLoadSettings() {
  const res = await fetch('/__settings', { cache: 'no-store' });
  if (!res.ok) return null;
  const s = await res.json();
  return s && typeof s === 'object' && Object.keys(s).length ? s : null;
}
export async function desktopSaveSettings(s) {
  const { token } = await desktop();
  const res = await fetch('/__settings', { method: 'POST', headers: { 'X-Token': token, 'Content-Type': 'application/json' }, body: JSON.stringify(s), keepalive: true });
  if (!res.ok) throw new Error(await res.text());
}
if (isDesktop && 'EventSource' in window) {
  // Offene Verbindung = Fenster offen. Beim Schließen beendet sich das Windows-Programm sofort.
  new EventSource('/__events');
}

/** Text in die Zwischenablage (Android über die App, sonst Clipboard-API mit Rückfallebene). */
export async function copyText(text) {
  const value = String(text || '');
  if (!value) return false;
  if (isAndroidApp && typeof android.copyText === 'function') { android.copyText(value); return true; }
  try {
    if (navigator.clipboard && window.isSecureContext) { await navigator.clipboard.writeText(value); return true; }
  } catch { /* Rückfallebene unten */ }
  const ta = document.createElement('textarea');
  ta.value = value; ta.setAttribute('readonly', ''); ta.style.position = 'fixed'; ta.style.opacity = '0';
  document.body.appendChild(ta); ta.select();
  let ok = false;
  try { ok = document.execCommand('copy'); } catch { ok = false; }
  ta.remove();
  return ok;
}

function toBase64(bytes) {
  let s = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) s += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
  return btoa(s);
}

async function writeNative(bytes, path, directory) {
  const { Filesystem } = cap.Plugins;
  const res = await Filesystem.writeFile({ path, data: toBase64(bytes), directory, recursive: true });
  return res.uri;
}

/** Öffnet das Teilen-Menü (E-Mail, Messenger, Dateien …) mit der PDF. */
export async function sharePdf(bytes, filename, title) {
  if (isAndroidApp) { android.sharePdf(toBase64(bytes), filename, title || filename); return 'shared'; }
  if (isDesktop) {
    // Windows: Datei ablegen und im Explorer markieren -> per Drag & Drop in E-Mail/Teams einfügen
    const { path } = await desktopPost('/__save', { name: filename }, bytes);
    await desktopPost('/__reveal', { path });
    return path;
  }
  if (isCapacitor) {
    const uri = await writeNative(bytes, filename, 'CACHE');
    await cap.Plugins.Share.share({ title, dialogTitle: title, url: uri });
    return 'shared';
  }
  const file = new File([bytes], filename, { type: 'application/pdf' });
  if (navigator.canShare && navigator.canShare({ files: [file] })) {
    try { await navigator.share({ files: [file], title }); return 'shared'; }
    catch (e) { if (e && e.name === 'AbortError') return 'aborted'; }
  }
  download(bytes, filename);
  return 'downloaded';
}

/** Windows: PDF speichern und per E-Mail (mit Anhang, sonst mailto) oder WhatsApp weitergeben. */
export async function desktopShare(bytes, filename, { via, to = '', subject = '', text = '' }) {
  return desktopPost('/__share', { via, name: filename, to, subject, text }, bytes);
}
export async function desktopReveal(path) { return desktopPost('/__reveal', { path }); }

/** Speichert die PDF dauerhaft (App: Dokumente/Schadensprotokolle, Browser: Download). */
export async function savePdf(bytes, filename) {
  if (isAndroidApp) {
    const path = android.savePdf(toBase64(bytes), filename);
    if (!path) throw new Error('Datei konnte nicht gespeichert werden');
    return path;
  }
  if (isDesktop) return (await desktopPost('/__save', { name: filename }, bytes)).path;
  if (isCapacitor) return writeNative(bytes, `Schadensprotokolle/${filename}`, 'DOCUMENTS');
  download(bytes, filename);
  return null;
}

export function download(bytes, filename) {
  const url = URL.createObjectURL(new Blob([bytes], { type: 'application/pdf' }));
  const a = document.createElement('a');
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60000);
}

export function previewPdf(bytes) {
  const url = URL.createObjectURL(new Blob([bytes], { type: 'application/pdf' }));
  window.open(url, '_blank');
  setTimeout(() => URL.revokeObjectURL(url), 120000);
}

/** PDF ansehen: Android mit einem PDF-Betrachter, sonst im Browser-Fenster. */
export async function openPdf(bytes, filename, title) {
  if (isAndroidApp) {
    if (typeof android.openPdf === 'function') { android.openPdf(toBase64(bytes), filename); return; }
    return sharePdf(bytes, filename, title);
  }
  if (isCapacitor) return sharePdf(bytes, filename, title);
  previewPdf(bytes);
}

export async function loadAsset(path) {
  const res = await fetch(path);
  if (!res.ok) throw new Error(`${path}: ${res.status}`);
  return new Uint8Array(await res.arrayBuffer());
}

/** Bild verkleinern (max. Kantenlänge) und als JPEG-DataURL liefern. */
export function compressImage(file, max = 1600, quality = 0.8) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const s = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement('canvas');
      c.width = Math.round(img.width * s); c.height = Math.round(img.height * s);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      resolve(c.toDataURL('image/jpeg', quality));
    };
    img.onerror = (e) => { URL.revokeObjectURL(url); reject(e); };
    img.src = url;
  });
}

export function dataUrlToBytes(dataUrl) {
  const b64 = dataUrl.split(',')[1];
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
