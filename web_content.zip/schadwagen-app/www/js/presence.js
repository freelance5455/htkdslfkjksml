// Wer arbeitet gerade an welchem Protokoll? Dieses Gerät meldet den aktiven Mitarbeiter und das
// geöffnete Protokoll; über den Server (falls verbunden) kommen die Meldungen der anderen Geräte dazu.
import { api, canSync, conn } from './server.js';
import { isDesktop, isAndroidApp } from './platform.js';

const HEARTBEAT_MS = 30000;
const listeners = new Set();
let local = null; // { employeeId, employeeName, reportUuid, reportId, wagonNumber, place, stored, openedAt, lastActivity }
let remote = [];
let timer = null;
let pushTimer = null;

export const deviceId = (() => {
  try {
    let id = localStorage.getItem('sw.deviceId');
    if (!id) { id = (crypto.randomUUID ? crypto.randomUUID() : String(Date.now())).slice(0, 18); localStorage.setItem('sw.deviceId', id); }
    return id;
  } catch { return 'gerät'; }
})();
export const deviceLabel = isDesktop ? 'Windows-PC' : isAndroidApp ? 'Android' : (/iPhone|iPad/.test(navigator.userAgent) ? 'iPhone/iPad' : 'Browser');

export function onPresenceChange(fn) { listeners.add(fn); return () => listeners.delete(fn); }
const emit = () => listeners.forEach((fn) => { try { fn(); } catch (e) { console.error(e); } });

const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);

/** Lokalen Stand setzen (null = arbeitet an keinem Protokoll). */
export function setLocalPresence(p) {
  const next = p ? { ...p, openedAt: local && local.reportUuid === p.reportUuid && local.employeeId === p.employeeId ? local.openedAt : (p.openedAt || new Date().toISOString()) } : null;
  const changed = !same({ ...next, lastActivity: 0 }, { ...local, lastActivity: 0 });
  local = next;
  emit();
  if (changed) { clearTimeout(pushTimer); pushTimer = setTimeout(pushPresence, 800); }
}
/** Nur „letzte Änderung“ aktualisieren (beim Tippen). */
export function touchPresence(fields = {}) {
  if (!local) return;
  const moved = Object.keys(fields).some((k) => fields[k] !== local[k]);
  Object.assign(local, fields, { lastActivity: new Date().toISOString() });
  emit();
  if (moved) { clearTimeout(pushTimer); pushTimer = setTimeout(pushPresence, 1500); }
}

/** Alle Meldungen zu einem Mitarbeiter: dieses Gerät zuerst, dann andere Geräte. */
export function presenceFor(employeeId) {
  const out = [];
  if (local && local.employeeId === employeeId) out.push({ ...local, deviceId, device: deviceLabel, self: true });
  for (const r of remote) if (r.employeeId === employeeId && r.deviceId !== deviceId) out.push({ ...r, self: false });
  return out;
}
export const isWorking = (employeeId) => presenceFor(employeeId).length > 0;

export async function pushPresence(opts = {}) {
  if (!canSync() || !conn.features.includes('presence')) return;
  const body = local
    ? { ...local, deviceId, device: deviceLabel, active: true }
    : { deviceId, device: deviceLabel, active: false };
  await api('/api/presence', { method: 'POST', body, keepalive: !!opts.keepalive }).catch(() => {});
}
export async function pullPresence() {
  if (!canSync() || !conn.features.includes('presence')) { if (remote.length) { remote = []; emit(); } return; }
  const r = await api('/api/presence');
  if (r.ok && r.data && Array.isArray(r.data.presence)) {
    if (!same(r.data.presence, remote)) { remote = r.data.presence; emit(); }
  }
}

export function startPresence() {
  if (timer) return;
  const beat = async () => { await pushPresence(); await pullPresence(); };
  timer = setInterval(beat, HEARTBEAT_MS);
  // Beim Schließen sofort abmelden (sonst verfällt der Eintrag nach 2 Minuten)
  window.addEventListener('pagehide', () => { local = null; pushPresence({ keepalive: true }); });
  beat();
}
export const refreshPresence = () => pullPresence();
