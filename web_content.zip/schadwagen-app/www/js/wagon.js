// UIC-Wagennummer (12 Ziffern): Formatierung und Prüfziffer

export const onlyDigits = (s) => String(s || '').replace(/\D/g, '').slice(0, 12);

/** "338078194841" -> "33 80 7819 484-1" (sep=' ') bzw. "33-80-7819-484-1" (sep='-') */
export function formatWagonNumber(raw, sep = ' ') {
  const d = onlyDigits(raw);
  if (!d) return '';
  const parts = [d.slice(0, 2), d.slice(2, 4), d.slice(4, 8), d.slice(8, 11)].filter(Boolean);
  let out = parts.join(sep);
  if (d.length > 11) out += '-' + d.slice(11);
  return out;
}

/** Prüfziffer nach UIC 438 (Luhn-Verfahren auf die ersten 11 Ziffern) */
export function checkDigit(first11) {
  let sum = 0;
  for (let i = 0; i < 11; i++) {
    const p = Number(first11[i]) * (i % 2 === 0 ? 2 : 1);
    sum += p > 9 ? p - 9 : p;
  }
  return (10 - (sum % 10)) % 10;
}

/** 'empty' | 'incomplete' | 'invalid' | 'ok' */
export function validateWagonNumber(raw) {
  const d = onlyDigits(raw);
  if (!d) return 'empty';
  if (d.length < 12) return 'incomplete';
  return checkDigit(d) === Number(d[11]) ? 'ok' : 'invalid';
}
