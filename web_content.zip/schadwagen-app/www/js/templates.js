// Vorlagen: wiederkehrende Angaben (v. a. Wagenhalter mit Halternummer/RICS, Name, Adresse, E-Mail, dazu
// Sendungsnummer, Kontakt, Anlagen …), die per „Stift“ in ein neues Protokoll übernommen werden.
//
// Import (25.10.2026, überarbeitet): Eine Vorlage braucht weder Protokoll-Nr. (Präfix) noch Wagennummer.
//  1. In dieser App erstellte PDF -> hinterlegte Daten.
//  2. GCU-PDF mit Formularfeldern -> alle ausgefüllten Felder (Halter, Adresse/E-Mail, Kontakt, Anlagen …).
//  3. Halter erkennen: Halternummer aus der PDF, sonst aus dem Dateinamen („RICS_4132_ERMEWA_SA_-_D.pdf“),
//     sonst anhand des Halternamens im Halterverzeichnis (Grundbestand data/halter.js + eigene Vorlagen).
//     Fehlende Adresse/E-Mail werden aus dem Verzeichnis ergänzt.
//  4. Fixierte PDF ohne Felder: Halter aus dem Dateinamen + Verzeichnis.
// Export: ZIP mit je einer PDF pro Vorlage und „vorlagen.json“ (vollständig, wieder importierbar).
import { newReport } from './state.js';
import { EMBED_KEY } from './pdf/fillProtocol.js';
import { reportFromGcuForm, hasGcuFields } from './importer.js';
import { listTemplates, putTemplate, getTemplatePdf } from './storage.js';
import { HALTER } from '../data/halter.js';
import { createZip, readZip, isZip } from './zip.js';

export const BUNDLE_FORMAT = 'traintrace-vorlagen';

/** Felder eines Protokolls, die eine Vorlage tragen kann (alles außer Kennung, Nummer, Status, Fotos). */
const NOT_TEMPLATE = new Set(['id', 'createdAt', 'updatedAt', 'status', 'numberUsed', 'reportId', 'photos']);
export function templateKeys() {
  return Object.keys(newReport({})).filter((k) => !NOT_TEMPLATE.has(k));
}

/** Ist ein Wert „leer“ (wird dann nicht übernommen)? */
function isEmpty(k, v) {
  if (v === undefined || v === null || v === '' || v === false) return true;
  if (typeof v === 'string' && !v.trim()) return true;
  if (Array.isArray(v)) {
    if (k === 'damages') return !v.some((d) => d && (d.code || d.noCode || d.customText || d.remark));
    return v.length === 0;
  }
  if (typeof v === 'object') return !Object.values(v).some(Boolean);
  return false;
}

/** Nur die ausgefüllten Vorlagenfelder aus einem Protokoll. */
export function dataFromReport(r) {
  const out = {};
  for (const k of templateKeys()) if (!isEmpty(k, r[k])) out[k] = JSON.parse(JSON.stringify(r[k]));
  return out;
}

/** Anzahl der ausgefüllten Angaben (für die Anzeige). */
export const filledCount = (data) => Object.keys(data || {}).filter((k) => !isEmpty(k, data[k])).length;

/**
 * Vorlage in ein (neues) Protokoll übertragen: jede ausgefüllte Angabe der Vorlage wird eingetragen;
 * Protokollnummer, Kennung und Status des Protokolls bleiben.
 */
export function applyTemplate(report, t) {
  const data = (t && t.data) || {};
  for (const k of templateKeys()) {
    if (isEmpty(k, data[k])) continue;
    report[k] = JSON.parse(JSON.stringify(data[k]));
  }
  delete report.keeperAuto; // Halter aus der Vorlage gilt als „von Hand“ – die Halter-Abfrage überschreibt ihn nicht
  report.templateId = t.id;
  report.templateName = t.name;
  return report;
}

/* ---------- Halterverzeichnis und Dateinamen ---------- */

/** Vergleichsschlüssel: nur a–z und Ziffern (Umlaute fallen weg – wie in Dateinamen, wo „ü“ oft zu „_“ wird). */
const nkey = (s) => String(s || '').toLowerCase().replace(/[^a-z0-9]/g, '');

/** Verzeichnis aus Grundbestand und eigenen Vorlagen (eigene Angaben haben Vorrang). */
export function keeperDirectory(templates = []) {
  const map = new Map(HALTER.map((e) => [e.code, { ...e }]));
  for (const t of templates) {
    const d = t.data || {};
    if (!/^\d{4}$/.test(d.keeperVkm || '') || !d.keeperName) continue;
    const prev = map.get(d.keeperVkm) || {};
    map.set(d.keeperVkm, { code: d.keeperVkm, name: d.keeperName, address: d.keeperAddress || prev.address || '', email: d.keeperEmail || prev.email || '' });
  }
  return [...map.values()];
}

/** Halter suchen: zuerst nach Nummer, dann nach Name (genau, sonst enthalten – längster Treffer gewinnt). */
export function findKeeper(dir, { code, name }) {
  if (code) { const e = dir.find((x) => x.code === code); if (e) return e; }
  const k = nkey(name);
  if (k.length < 3) return null;
  const exact = dir.find((x) => nkey(x.name) === k);
  if (exact) return exact;
  const hits = dir.filter((x) => { const xk = nkey(x.name); return xk.length >= 5 && (k.includes(xk) || (k.length >= 5 && xk.includes(k))); });
  hits.sort((a, b) => nkey(b.name).length - nkey(a.name).length);
  return hits[0] || null;
}

/**
 * Dateiname lesen: „RICS_4132_ERMEWA_SA_-_D.pdf“, „4132 ERMEWA SA - D.pdf“, „ERMEWA SA - D 4132.pdf“
 * oder nur „ERMEWA SA - D.pdf“. Liefert { code, name }.
 */
export function parseFileName(fileName) {
  let base = String(fileName || '').replace(/\.[^.]+$/, '').replace(/^[0-9a-f]{8}-(?=RICS|\d{4}|[A-Za-z])/i, '');
  base = base.replace(/\s*\(\d+\)$/, '').replace(/[_\s-]*(kopie|copy)$/i, '').trim();
  const clean = (s) => s.replace(/_/g, ' ').replace(/\s+/g, ' ').replace(/^[\s-]+|[\s-]+$/g, '').trim();
  let m = /^(?:RICS|VKM|Halter)?[\s_-]*(\d{4})(?:[\s_-]+(.*))?$/i.exec(base);
  if (m) return { code: m[1], name: clean(m[2] || '') };
  m = /^(.*?)[\s_-]+(?:RICS|VKM)?[\s_-]*(\d{4})$/i.exec(base);
  if (m) return { code: m[2], name: clean(m[1]) };
  return { code: '', name: clean(base.replace(/^(RICS|VKM|Vorlage)[\s_-]+/i, '')) };
}

/** Name einer Vorlage: Haltername, sonst Dateiname ohne Endung. */
export function suggestName(data, fileName = '') {
  if (data.keeperName) return data.keeperName.trim();
  return parseFileName(fileName).name || 'Neue Vorlage';
}

export const templateHaystack = (t) => [t.name, t.fileName, t.data?.keeperVkm, t.data?.keeperName, t.data?.keeperAddress, t.data?.keeperEmail,
  t.data?.consignmentNumber, t.data?.contactName, t.data?.contactEmail, t.data?.remarks].filter(Boolean).join(' ').toLowerCase();

const sameKeeper = (a, b) => {
  const n = (s) => nkey(s);
  return !!(a.keeperVkm || a.keeperName) && n(a.keeperVkm) === n(b.keeperVkm) && n(a.keeperName) === n(b.keeperName);
};
const newId = () => (crypto.randomUUID ? crypto.randomUUID() : `t${Date.now()}${Math.random().toString(16).slice(2)}`);

/* ---------- Einlesen ---------- */

/**
 * Eine Datei als Vorlage auslesen. Liefert { data, pdfBytes, how } – how beschreibt, woher der Halter
 * stammt: 'pdf' (Formularfelder), 'name' (Haltername -> Verzeichnis), 'datei' (Dateiname).
 */
export async function readTemplateFile(file, dir) {
  const bytes = new Uint8Array(await file.arrayBuffer());
  const name = file.name || '';
  let data = {};
  let pdfBytes = null;
  if (/\.json$/i.test(name) || bytes[0] === 0x7b) {
    const j = JSON.parse(new TextDecoder().decode(bytes));
    const report = j && j.format === 'schadwagen-protokoll' ? j.report : j;
    if (!report || typeof report !== 'object') throw new Error('Die Datei enthält keine Vorlage.');
    data = dataFromReport(report);
  } else {
    const { PDFDocument, PDFName } = globalThis.PDFLib;
    let doc;
    try { doc = await PDFDocument.load(bytes, { ignoreEncryption: true, updateMetadata: false }); }
    catch { throw new Error('Die Datei ist keine lesbare PDF.'); }
    pdfBytes = bytes;
    // 1. In dieser App erstellte PDF
    try {
      const info = doc.context.lookup(doc.context.trailerInfo.Info);
      const raw = info && info.lookup ? info.lookup(PDFName.of(EMBED_KEY)) : null;
      if (raw && raw.decodeText) { const j = JSON.parse(raw.decodeText()); if (j && j.report) data = dataFromReport(j.report); }
    } catch { /* weiter mit Formularfeldern */ }
    // 2. GCU-Formularfelder – auch ohne Protokoll-Nr. und ohne Wagennummer
    if (!filledCount(data)) {
      let form = null;
      try { form = doc.getForm(); } catch { form = null; }
      if (hasGcuFields(form)) data = dataFromReport(reportFromGcuForm(form));
    }
  }
  // 3. Halter vervollständigen: Nummer/Name aus Dateiname und Verzeichnis
  const fromFile = parseFileName(name);
  const hadCode = /^\d{4}$/.test(data.keeperVkm || '');
  const hit = findKeeper(dir, { code: hadCode ? data.keeperVkm : '', name: data.keeperName })
    || findKeeper(dir, { code: fromFile.code, name: fromFile.name });
  let how = hadCode ? 'pdf' : '';
  if (hit && (!data.keeperName || findKeeper([hit], { name: data.keeperName }) || data.keeperVkm === hit.code)) {
    if (!hadCode) how = data.keeperName ? 'name' : 'datei';
    if (!hadCode) data.keeperVkm = hit.code;
    data.keeperName = data.keeperName || hit.name;
    if (!data.keeperAddress && hit.address) data.keeperAddress = hit.address;
    if (!data.keeperEmail && hit.email) data.keeperEmail = hit.email;
  } else {
    if (!data.keeperVkm && fromFile.code) { data.keeperVkm = fromFile.code; how = 'datei'; }
    if (!data.keeperName && fromFile.name && fromFile.code) { data.keeperName = fromFile.name; how = how || 'datei'; }
  }
  if (!filledCount(data)) {
    throw new Error('Keine Angaben gefunden: Die PDF hat keine ausfüllbaren Felder und der Halter ist am Dateinamen nicht erkennbar. '
      + 'Tipp: Datei „RICS_<Halternummer>_<Name>.pdf“ nennen oder die Vorlage mit „Neue Vorlage“ anlegen.');
  }
  return { data, pdfBytes, how: how || 'pdf' };
}

/**
 * Dateien als Vorlagen einlesen: PDFs, JSON, eine Export-Datei (ZIP oder JSON aus „Exportieren“) oder ein
 * beliebiges ZIP mit PDFs. Gleicher Halter (Nummer + Name) bzw. gleiche Datei -> vorhandene Vorlage wird
 * aktualisiert statt doppelt angelegt.
 * Ergebnis: { added: [], updated: [], failed: [{ name, message }], byName: n, byFile: n }
 */
export async function importTemplateFiles(files) {
  const existing = await listTemplates();
  const res = { added: [], updated: [], failed: [], byName: 0, byFile: 0 };
  const queue = [...files];
  while (queue.length) {
    const file = queue.shift();
    try {
      const head = new Uint8Array(await file.slice(0, 4).arrayBuffer());
      if (isZip(head)) {
        const entries = await readZip(new Uint8Array(await file.arrayBuffer()));
        const bundle = entries.find((e) => /(^|\/)vorlagen\.json$/i.test(e.name));
        if (bundle) await restoreBundle(JSON.parse(new TextDecoder().decode(bundle.bytes)), entries, existing, res);
        else entries.filter((e) => /\.(pdf|json)$/i.test(e.name)).forEach((e) => queue.push(new File([e.bytes], e.name.split('/').pop())));
        continue;
      }
      if (/\.json$/i.test(file.name || '') || head[0] === 0x7b) {
        const j = JSON.parse(await file.text());
        if (j && j.format === BUNDLE_FORMAT) { await restoreBundle(j, [], existing, res); continue; }
      }
      const { data, pdfBytes, how } = await readTemplateFile(file, keeperDirectory(existing));
      if (how === 'name') res.byName++;
      if (how === 'datei') res.byFile++;
      const cleanName = String(file.name || '').replace(/^[0-9a-f]{8}-(?=RICS|\d{4}|[A-Za-z])/i, '');
      const prev = existing.find((t) => sameKeeper(t.data || {}, data)) || existing.find((t) => t.fileName && t.fileName === cleanName);
      const now = new Date().toISOString();
      const t = {
        id: prev ? prev.id : newId(),
        name: prev ? prev.name : suggestName(data, cleanName),
        data, source: 'import', fileName: cleanName, keeperFrom: how,
        hasPdf: !!pdfBytes, pdfCurrent: !!pdfBytes,
        createdAt: prev ? prev.createdAt : now, updatedAt: now,
      };
      await putTemplate(t, pdfBytes || null);
      if (prev) { res.updated.push(t); Object.assign(prev, t); } else { res.added.push(t); existing.push(t); }
    } catch (e) {
      res.failed.push({ name: file.name, message: (e && e.message) || String(e) });
    }
  }
  return res;
}

/** Export-Datei zurückspielen (vorlagen.json + PDFs aus dem ZIP). */
async function restoreBundle(j, entries, existing, res) {
  if (!j || j.format !== BUNDLE_FORMAT || !Array.isArray(j.templates)) throw new Error('Unbekanntes Exportformat.');
  for (const rec of j.templates) {
    try {
      if (!rec || !rec.data) throw new Error('Eintrag ohne Angaben');
      const prev = existing.find((t) => t.id === rec.id) || existing.find((t) => sameKeeper(t.data || {}, rec.data));
      const pdf = rec.pdfFile && rec.hasPdf && rec.pdfCurrent ? entries.find((e) => e.name.split('/').pop() === rec.pdfFile) : null;
      const now = new Date().toISOString();
      const { pdfFile, ...clean } = rec;
      const t = { ...clean, id: prev ? prev.id : (rec.id || newId()), hasPdf: !!pdf, pdfCurrent: !!pdf, createdAt: rec.createdAt || now, updatedAt: now };
      await putTemplate(t, pdf ? pdf.bytes : null);
      if (prev) { res.updated.push(t); Object.assign(prev, t); } else { res.added.push(t); existing.push(t); }
    } catch (e) {
      res.failed.push({ name: rec && rec.name ? rec.name : 'Eintrag', message: (e && e.message) || String(e) });
    }
  }
}

/* ---------- Export ---------- */

const safePart = (s) => String(s || '').replace(/[\\/:*?"<>|]+/g, ' ').trim().replace(/\s+/g, '_');
/** Dateiname einer Vorlage im Export: „RICS_4132_ERMEWA_SA_-_D.pdf“ (ohne Nummer: „ERMEWA_SA_-_D.pdf“). */
export const exportFileName = (t) => `${/^\d{4}$/.test(t.data?.keeperVkm || '') ? `RICS_${t.data.keeperVkm}_` : ''}${safePart(t.name) || 'Vorlage'}.pdf`;

/**
 * Gesamten Vorlagenbestand als ZIP: je Vorlage eine PDF (Original bzw. aus den Angaben erzeugt) und
 * „vorlagen.json“ mit allen Angaben. pdfOf(t) liefert die PDF-Bytes. Ergebnis: { bytes, count }.
 */
export async function buildExportZip(pdfOf) {
  const ts = (await listTemplates()).slice().sort(byName);
  const used = new Set();
  const entries = [];
  const recs = [];
  for (const t of ts) {
    let fname = exportFileName(t);
    for (let i = 2; used.has(fname.toLowerCase()); i++) fname = exportFileName(t).replace(/\.pdf$/, `_${i}.pdf`);
    used.add(fname.toLowerCase());
    const original = t.hasPdf && t.pdfCurrent ? await getTemplatePdf(t.id).catch(() => null) : null;
    const bytes = original || await pdfOf(t);
    entries.push({ name: fname, bytes });
    recs.push({ ...t, pdfFile: fname });
  }
  const json = { format: BUNDLE_FORMAT, version: 1, exportedAt: new Date().toISOString(), count: recs.length, templates: recs };
  entries.push({ name: 'vorlagen.json', bytes: new TextEncoder().encode(JSON.stringify(json, null, 2)) });
  return { bytes: createZip(entries), count: recs.length };
}

/** Vorlagen alphabetisch (deutsche Sortierung, Zahlen natürlich). */
export const byName = (a, b) => String(a.name || '').localeCompare(String(b.name || ''), 'de', { numeric: true, sensitivity: 'base' });
