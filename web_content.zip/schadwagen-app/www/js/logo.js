// Firmenlogo des EVU: PNG oder ICO einlesen und als kleines rundes Bild (PNG, 160 × 160) aufbereiten.
// Gespeichert wird nur das verkleinerte Bild als data:-URL in den Einstellungen (evuLogo).

const SIZE = 160;
const MAX_BYTES = 5 * 1024 * 1024;

const isIco = (file, bytes) => /\.ico$/i.test(file.name || '') || /icon/i.test(file.type || '')
  || (bytes.length > 6 && bytes[0] === 0 && bytes[1] === 0 && bytes[2] === 1 && bytes[3] === 0);
const isPng = (file, bytes) => /\.png$/i.test(file.name || '') || file.type === 'image/png'
  || (bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4e && bytes[3] === 0x47);

/**
 * ICO enthält oft mehrere Größen. Die größte heraussuchen: Ist sie als PNG gespeichert, direkt nehmen,
 * sonst eine ICO-Datei mit nur diesem Bild bauen (der Browser dekodiert dann genau dieses).
 */
export function largestIcoImage(bytes) {
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  if (bytes.length < 6 || dv.getUint16(0, true) !== 0 || dv.getUint16(2, true) !== 1) return null;
  const n = dv.getUint16(4, true);
  let best = null;
  for (let i = 0; i < n; i++) {
    const o = 6 + i * 16;
    if (o + 16 > bytes.length) break;
    const w = bytes[o] || 256, hgt = bytes[o + 1] || 256;
    const bpp = dv.getUint16(o + 6, true);
    const size = dv.getUint32(o + 8, true), off = dv.getUint32(o + 12, true);
    if (!size || off + size > bytes.length) continue;
    const score = w * hgt * 64 + bpp;
    if (!best || score > best.score) best = { score, o, size, off };
  }
  if (!best) return null;
  const data = bytes.subarray(best.off, best.off + best.size);
  if (data[0] === 0x89 && data[1] === 0x50) return new Blob([data], { type: 'image/png' });
  const out = new Uint8Array(22 + data.length);
  out.set([0, 0, 1, 0, 1, 0]);
  out.set(bytes.subarray(best.o, best.o + 12), 6);
  new DataView(out.buffer).setUint32(18, 22, true);
  out.set(data, 22);
  return new Blob([out], { type: 'image/x-icon' });
}

function loadImage(blob) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(blob);
    const img = new Image();
    img.onload = () => { URL.revokeObjectURL(url); resolve(img); };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('decode')); };
    img.src = url;
  });
}

/** Datei prüfen und in ein rundes Logo umwandeln. Liefert eine data:-URL (PNG) oder wirft einen Fehler mit deutscher Meldung. */
export async function makeEvuLogo(file) {
  if (!file) throw new Error('Keine Datei gewählt.');
  if (file.size > MAX_BYTES) throw new Error('Die Datei ist zu groß (höchstens 5 MB).');
  const bytes = new Uint8Array(await file.arrayBuffer());
  const ico = isIco(file, bytes);
  if (!ico && !isPng(file, bytes)) throw new Error('Bitte eine PNG- oder ICO-Datei wählen.');
  let img;
  try {
    img = await loadImage(ico ? (largestIcoImage(bytes) || new Blob([bytes], { type: 'image/x-icon' })) : new Blob([bytes], { type: 'image/png' }));
  } catch {
    throw new Error('Das Bild ließ sich nicht lesen – ist die Datei beschädigt?');
  }
  const w = img.naturalWidth, hgt = img.naturalHeight;
  if (!w || !hgt) throw new Error('Das Bild ist leer.');

  // Ecken prüfen: quadratisches, randlos gefülltes Bild -> Kreis ganz ausfüllen, sonst eingepasst auf Hintergrund
  const probe = document.createElement('canvas');
  probe.width = 32; probe.height = 32;
  const pc = probe.getContext('2d', { willReadFrequently: true });
  pc.drawImage(img, 0, 0, 32, 32);
  const px = (x, y) => pc.getImageData(x, y, 1, 1).data;
  const corners = [px(1, 1), px(30, 1), px(1, 30), px(30, 30)];
  const opaque = corners.every((c) => c[3] > 200);
  const ratio = w / hgt;
  const fill = opaque && ratio > 0.85 && ratio < 1.18;

  const c = document.createElement('canvas');
  c.width = SIZE; c.height = SIZE;
  const ctx = c.getContext('2d');
  ctx.imageSmoothingQuality = 'high';
  ctx.beginPath(); ctx.arc(SIZE / 2, SIZE / 2, SIZE / 2, 0, Math.PI * 2); ctx.closePath(); ctx.clip();
  if (fill) {
    const s = Math.max(SIZE / w, SIZE / hgt);
    ctx.drawImage(img, (SIZE - w * s) / 2, (SIZE - hgt * s) / 2, w * s, hgt * s);
  } else {
    // Hintergrund: bei gefüllten Bildern die Eckfarbe, bei freigestellten Logos weiß
    const bg = opaque ? corners[0] : [255, 255, 255, 255];
    ctx.fillStyle = `rgb(${bg[0]}, ${bg[1]}, ${bg[2]})`;
    ctx.fillRect(0, 0, SIZE, SIZE);
    // größtes Rechteck im Seitenverhältnis, das in den Kreis passt, mit etwas Rand
    const d = SIZE * 0.86;
    const bh = d / Math.sqrt(1 + ratio * ratio), bw = bh * ratio;
    ctx.drawImage(img, (SIZE - bw) / 2, (SIZE - bh) / 2, bw, bh);
  }
  return c.toDataURL('image/png');
}
