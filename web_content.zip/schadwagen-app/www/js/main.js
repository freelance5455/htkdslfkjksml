import { h, icon, toast, busy, modal, alertDialog, confirmDialog, popMenu } from './ui/dom.js';
import { loadSettings, saveSettings, syncSettings, newReport, formatReportId, setDesign } from './state.js';
import {
  putReport, getReport, listReports, saveCurrent, loadCurrent, putPdf, listPdfs, trashReport, listTrash, purgeTrash,
  localDay, repairImportDates, onDataChange, notifyDataChange, latestPdfOf, getPdf, getThumbs, warmUp, getTemplatePdf,
} from './storage.js';
import { calendarDayOf, savedPathFor, setSavedPath } from './viewstate.js';
import { renderForm, validate } from './ui/form.js';
import { openSettings, openResult, sheetShell } from './ui/screens.js';
import { fillProtocol, formatDate } from './pdf/fillProtocol.js';
import { lookup, isSelectable, resolveCode } from './codes.js';
import { loadAsset, sharePdf, savePdf, saveFile, openPdf, previewPdf, dataUrlToBytes, isDesktop, desktopShare, desktopReveal } from './platform.js';
import { createDashboard, resetDashboardSelection, focusDashboard } from './ui/dashboard.js';
import { onlyDigits, formatWagonNumber } from './wagon.js';
import { loadSecrets, getSecret, setSecret } from './secrets.js';
import { configureServer, conn, onConnChange, startMonitor, canSync, checkConnection } from './server.js';
import { setLocalPresence, startPresence } from './presence.js';
import { pushProtocol, pushPending, pullProtocols, syncEmployees, syncFolders } from './sync.js';
import {
  can, canEditReport, activeEmployee, hasEmployees, listEmployees, fullName, normPrefix, ownerOf, ownerLabel,
  createdByOf, maxUsedNumber, markUnlocked, activeList, PERMS, TEMPLATES, roleOf,
} from './employees.js';
import {
  renderSaved, renderTrash, renderEmployees, renderLogin, openEmployeeEditor, openSwitcher, latencyBadge, avatar,
} from './ui/views.js';
import { readProtocolFile } from './importer.js';
import { renderTemplates } from './ui/templatesView.js';
import { applyTemplate } from './templates.js';

const TEMPLATE = 'assets/GCU_Schadprotokoll_Grunddatei.pdf';

let settings = loadSettings();
let report = null;
let savedSheet = null; // „Gespeichert“ als Vollbild in der normalen Ansicht
let dirty = false;
let saveTimer = null;
let presenceTimer = null;
let templateBytes = null;
// Erweiterter Modus: dashboard | form | employees | saved | trash | login
let view = 'dashboard';
let viewEl = null;
const extended = () => !!settings.extendedMode;
const root = document.getElementById('app');

/* ---------- Berechtigungen ---------- */

function readOnlyReason() {
  if (canEditReport(settings, report)) return '';
  if (hasEmployees(settings) && !activeEmployee(settings)) return 'Nur Ansicht – bitte zuerst einen Mitarbeiter wählen.';
  return `Nur Ansicht – keine Berechtigung zum ${report && report.numberUsed ? 'Bearbeiten' : 'Erstellen'} von Protokollen.`;
}
function denied(what) {
  if (hasEmployees(settings) && !activeEmployee(settings)) {
    toast('Bitte zuerst einen Mitarbeiter wählen');
    showSwitcher();
  } else toast(`Keine Berechtigung: ${what}`);
}

const ctx = {
  get report() { return report; },
  get settings() { return settings; },
  get readOnly() { return readOnlyReason(); },
  changed() {
    dirty = true;
    clearTimeout(presenceTimer);
    presenceTimer = setTimeout(updatePresence, 800);
    report.updatedAt = new Date().toISOString();
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => saveCurrent(report).catch(() => {}), 400);
  },
  rerender: () => renderMain(),
  openSettings: () => showSettings(),
};

// Schnittstelle für die Ansichten (views.js)
const app = {
  get settings() { return settings; },
  can: (p) => can(settings, p),
  openReport: (id, r) => openReport(id, r),
  importFiles: (files) => importFiles(files, { from: 'saved' }),
  importEmployees: (file) => importEmployees(file),
  showForm: () => switchView('form'),
  exportEmployees: () => exportEmployees(),
  pull: (full) => runSync({ full, manual: true }),
  onTrashed: (r) => onTrashed(r),
  onLoginChange: () => { refreshChrome(); runSync({}); },
  openEditor: (e) => editEmployee(e),
  selectedEmployee: null,
  saveFolders: (folders) => {
    settings = { ...settings, folders };
    saveSettings(settings);
    notifyDataChange();
    scheduleEmployeeSync(); // gleicht Mitarbeiter und Ordner ab
  },
  /** Protokoll nur ansehen (PDF), ohne Formular und ohne Änderungen */
  viewReport: (r) => viewReport(r),
  /** Teilen/Speichern aus Listen (Mitarbeiter-Reiter) – PDF-Inhalt erst beim Klick */
  shareReport: async (r, anchor) => { const e = await entryFor(r); sharePdfFlow({ report: r, filename: e.filename, anchor, getBytes: () => ensureBytes(e) }); },
  saveReport: async (r) => {
    if (!can(settings, 'share')) { denied('PDFs teilen und speichern'); return; }
    const e = await entryFor(r);
    await withPdf(e, async (b) => {
      const uri = await savePdf(b, e.filename);
      toast(uri ? `Gespeichert: ${String(uri).replace(/^file:\/\//, '')}` : 'Download gestartet');
    });
  },
  canEdit: (r) => canEditReport(settings, r),
  /* Vorlagen */
  viewTemplate: (t) => viewTemplate(t),
  templatePdfBytes: (t) => templatePdfBytes(t),
  saveFile: (bytes, name, mime) => saveFile(bytes, name, mime),
  newFromTemplate: (t) => newFromTemplate(t),
  saveTemplatePdf: async (t) => {
    if (!can(settings, 'share')) { denied('PDFs teilen und speichern'); return; }
    await withTemplatePdf(t, async (b, name) => {
      const uri = await savePdf(b, name);
      toast(uri ? `Gespeichert: ${String(uri).replace(/^file:\/\//, '')}` : 'Download gestartet');
    });
  },
  get extended() { return extended(); },
  /** „Im Kalender zeigen“: Dashboard auf den Tag der Schadensfeststellung */
  showInCalendar: (r) => {
    const day = calendarDayOf(r);
    if (!day) { toast('Kein „Schaden festgestellt am“ – das Protokoll steht nicht im Kalender'); return; }
    focusDashboard(day, `r|${r.id}`);
    closeSheets();
    switchView('dashboard');
  },
};

/* ---------- Kopf- und Aktionsleisten ---------- */

function userChip() {
  if (!hasEmployees(settings)) return null;
  const me = activeEmployee(settings);
  return h('button', { class: 'user-chip', 'aria-label': me ? `Angemeldet: ${fullName(me)} – Mitarbeiter wechseln` : 'Mitarbeiter wählen', onclick: showSwitcher },
    avatar(me, 'sm'));
}

function appbar() {
  return h('header', { class: 'appbar' },
    h('h1', null, 'Schadensprotokoll'),
    userChip(),
    conn.status === 'ok' && conn.loginRequired && h('button', { class: 'icon-btn' + (conn.loggedIn ? ' on' : ' attn'), 'aria-label': 'Anmeldung', onclick: showLoginSheet }, icon('key')),
    h('button', { class: 'icon-btn', 'aria-label': 'Gespeicherte Protokolle', onclick: showSaved }, icon('list')),
    h('button', { class: 'icon-btn', 'aria-label': 'Einstellungen', onclick: showSettings }, icon('gear')));
}

function bottombar() {
  const mayEdit = canEditReport(settings, report);
  return h('nav', { class: 'bottombar' },
    h('button', { class: 'bb-secondary', onclick: actionNew, disabled: !can(settings, 'create') }, 'Neu'),
    h('button', { class: 'bb-secondary', onclick: actionSave, disabled: !mayEdit }, 'Speichern'),
    h('button', { class: 'bb-primary', onclick: actionSend, disabled: !mayEdit }, 'Senden'));
}

let mainEl;
function renderMain() {
  if (extended() && view !== 'form') { viewEl?.refresh?.(); return; }
  const y = window.scrollY;
  const fresh = h('main', { id: 'main' }, renderForm(ctx));
  if (mainEl) mainEl.replaceWith(fresh); else root.appendChild(fresh);
  mainEl = fresh;
  // Aktionsleiste an Berechtigung anpassen (z. B. nach dem Vergeben der Nummer)
  const bb = root.querySelector('.bottombar');
  if (bb) bb.replaceWith(bottombar());
  window.scrollTo(0, y);
}

function renderApp() {
  root.innerHTML = '';
  mainEl = null;
  viewEl = null;
  document.documentElement.classList.toggle('ext', extended());
  if (extended()) renderExtended();
  else {
    root.appendChild(appbar());
    renderMain();
    root.appendChild(bottombar());
  }
  document.body.classList.toggle('has-dock', !!root.querySelector('.bottombar'));
  updatePresence();
}

/** Seitenleiste bzw. Kopfleiste neu zeichnen (Anmeldung, aktiver Mitarbeiter). */
function refreshChrome() {
  const side = root.querySelector('.ext-side');
  if (side) side.replaceWith(sidebar());
  const bar = root.querySelector(':scope > .appbar');
  if (bar) bar.replaceWith(appbar());
}

/* ---------- Erweiterter Modus ---------- */

function sidebar() {
  const item = (id, label, ic, onclick, extra = '') => h('button', {
    type: 'button', class: `side-item${view === id ? ' on' : ''}${extra}`, 'aria-current': view === id ? 'page' : null, onclick,
  }, icon(ic), h('span', null, label));
  const me = activeEmployee(settings);
  const showLogin = conn.status === 'ok' && conn.loginRequired;
  return h('aside', { class: 'ext-side' },
    h('div', { class: 'side-brand' },
      h('img', { class: 'side-logo', src: 'icons/brand-logo.png', alt: 'TrainTrace', width: 44, height: 44, draggable: 'false' }),
      h('span', { class: 'side-name' }, h('b', null, 'TrainTrace'), h('span', null, 'Management'))),
    hasEmployees(settings) && h('button', { type: 'button', class: 'side-user' + (me ? '' : ' locked'), onclick: showSwitcher, 'aria-label': me ? `Aktiv: ${fullName(me)} – wechseln` : 'Mitarbeiter wählen' },
      avatar(me, 'sm'),
      h('span', { class: 'su-txt' }, h('b', null, me ? fullName(me) : 'Gesperrt'), h('span', null, me ? [me.title, normPrefix(me.prefix)].filter(Boolean).join(' · ') : 'Mitarbeiter wählen')),
      icon('swap')),
    h('button', { type: 'button', class: 'side-cta', onclick: actionNew, disabled: !can(settings, 'create') }, icon('plus'), h('span', null, 'Neues Protokoll')),
    h('nav', { class: 'side-nav', 'aria-label': 'Navigation' },
      item('dashboard', 'Dashboard', 'dashboard', () => switchView('dashboard')),
      item('form', 'Protokoll', 'doc', () => switchView('form')),
      item('employees', 'Mitarbeiter', 'people', () => switchView('employees')),
      item('saved', 'Gespeichert', 'folder', () => switchView('saved')),
      item('templates', 'Vorlagen', 'template', () => switchView('templates')),
      item('trash', 'Papierkorb', 'trash', () => switchView('trash')),
      item('settings', 'Einstellungen', 'gear', showSettings),
      showLogin && item('login', 'Anmeldung', 'key', () => switchView('login'), conn.loggedIn ? ' ok' : ' attn')),
    h('div', { class: 'side-foot' },
      h('div', { class: 'side-evu' + (settings.evuLogo ? ' has-logo' : '') },
        h('span', { class: 'se-txt' }, h('b', null, settings.evuName || 'EVU'), h('span', null, settings.evuNr ? `EVU-Nr. ${settings.evuNr}` : '')),
        settings.evuLogo && h('img', { class: 'evu-logo', src: settings.evuLogo, alt: `Logo ${settings.evuName || 'EVU'}` }))));
}

function dashboardOptions() {
  const emps = listEmployees(settings);
  return {
    load: dashboardEntries,
    employees: emps.map((e) => ({ id: e.id, label: `${fullName(e)}${e.prefix ? ` (${normPrefix(e.prefix)})` : ''}` })),
    ownerId: (e) => ownerOf(e.ownerReport || e.report, settings).employee?.id || null,
    ownerLabel: emps.length ? (e) => ownerLabel(e.ownerReport || e.report, settings) : null,
    canShare: can(settings, 'share'),
    onImport: can(settings, 'create') ? (files) => importFiles(files, { from: 'dashboard' }) : null,
    onOpen: (e) => withPdf(e, (b) => openPdf(b, e.filename, `Schadensprotokoll ${e.reportId || ''}`.trim())),
    onShare: (e, anchor) => sharePdfFlow({ report: e.ownerReport || e.report, filename: e.filename, anchor, getBytes: () => pdfBytesOf(e) }),
    onSave: (e) => withPdf(e, async (b) => {
      const uri = await savePdf(b, e.filename);
      toast(uri ? `Gespeichert: ${String(uri).replace(/^file:\/\//, '')}` : 'Download gestartet');
    }),
    onEdit: (e) => openReport(e.reportUuid),
    loadReport: (e) => fullReport(e.reportUuid, e.report),
    loadThumbs: (e) => getThumbs(e.reportUuid),
    loadPhotos: async (e) => ((await fullReport(e.reportUuid, e.report)) || {}).photos || [],
    onShowInSaved: (e) => { setSavedPath(savedPathFor(e.report)); switchView('saved'); },
    onShowNoDate: () => { setSavedPath({ kind: 'none' }); switchView('saved'); },
    onDelete: can(settings, 'delete') ? async (e) => {
      if (!(await confirmDialog('In den Papierkorb?', 'Das Protokoll und seine PDF werden in den Papierkorb verschoben und nach 30 Tagen automatisch gelöscht.', 'In den Papierkorb'))) return;
      await trashReport(e.reportUuid, fullName(activeEmployee(settings)));
      onTrashed({ id: e.reportUuid });
      toast('In den Papierkorb verschoben');
      viewEl?.refresh();
    } : null,
  };
}

function renderExtended() {
  const content = h('div', { class: 'ext-content' });
  root.append(h('div', { class: 'ext-shell' }, sidebar(), content));
  if (view === 'form') {
    content.appendChild(h('div', { class: 'ext-title' },
      h('div', { class: 'dash-eyebrow' }, 'GCU-Schadensprotokoll erfassen'),
      h('h1', null, 'Schadensprotokoll')));
    mainEl = h('main', { id: 'main' }, renderForm(ctx));
    content.appendChild(mainEl);
    root.appendChild(bottombar());
    return;
  }
  if (view === 'dashboard') viewEl = createDashboard(dashboardOptions());
  else if (view === 'employees') viewEl = renderEmployees(app);
  else if (view === 'saved') viewEl = renderSaved(app);
  else if (view === 'templates') viewEl = renderTemplates(app);
  else if (view === 'trash') viewEl = renderTrash(app);
  else if (view === 'login') viewEl = renderLogin(app);
  content.appendChild(viewEl);
}

function switchView(v) {
  if (view === v && v !== 'form') { viewEl?.refresh?.(); return; }
  if (view === 'form') flush();
  view = v;
  renderApp();
  window.scrollTo(0, 0);
  if (v === 'dashboard' || v === 'saved') runSync({});
}

// Dieselbe Datenquelle wie „Gespeichert“: ein Eintrag je Protokoll (auch Entwürfe, nicht zugeordnete,
// importierte und vom Server geholte), Kalendertag = „Schaden festgestellt am“. Nur Übersichtsdaten –
// PDF-Inhalt, Fotos und Einzelheiten werden erst geladen, wenn sie gebraucht werden.
async function dashboardEntries() {
  const [pdfs, reports] = await Promise.all([listPdfs(), listReports()]);
  const latest = new Map();
  for (const p of pdfs) if (p.reportUuid && !latest.has(p.reportUuid)) latest.set(p.reportUuid, p); // listPdfs: neueste zuerst
  return reports.map((r) => {
    const p = latest.get(r.id);
    return {
      key: `r|${r.id}`, reportUuid: r.id, day: calendarDayOf(r), draft: r.status !== 'erstellt', hasPdf: !!p, pdfKey: p ? p.key : null,
      createdAt: (p && p.createdAt) || r.pdfCreatedAt || r.updatedAt || '',
      filename: fileName(r), reportId: r.reportId || '', wagonNumber: r.wagonNumber || '',
      bytes: null, report: r, ownerReport: r, photoCount: r.photoCount || 0,
    };
  });
}

/** Vollständiges Protokoll (mit Fotos) – kleiner Zwischenspeicher für die zuletzt angesehenen. */
const fullCache = new Map();
async function fullReport(id, sum) {
  const hit = fullCache.get(id);
  if (hit && (!sum || hit.updatedAt === sum.updatedAt)) return hit;
  const r = await getReport(id);
  if (r) { fullCache.set(id, r); if (fullCache.size > 12) fullCache.delete(fullCache.keys().next().value); }
  return r;
}
onDataChange(() => fullCache.clear());

/** PDF-Inhalt eines Eintrags: Archiv-PDF laden, sonst aus dem vollständigen Protokoll erzeugen. */
async function ensureBytes(entry) {
  if (entry.bytes) return entry.bytes;
  if (entry.pdfKey) {
    const p = await getPdf(entry.pdfKey);
    if (p && p.bytes) return (entry.bytes = p.bytes instanceof Uint8Array ? p.bytes : new Uint8Array(p.bytes));
  }
  const full = (entry.report && !entry.report._summary) ? entry.report : await fullReport(entry.reportUuid || entry.report.id);
  if (!full) throw new Error('Protokoll nicht gefunden');
  const done = busy('PDF wird erstellt …');
  try { return (entry.bytes = await buildPdf(full, full.pdfCreatedAt || new Date().toISOString())); } finally { done(); }
}

/** Eintrag für PDF-Aktionen: neueste Archiv-PDF (nur Schlüssel, Inhalt später), sonst Neuerzeugung. */
async function entryFor(r) {
  const p = (await listPdfs()).find((x) => x.reportUuid === r.id);
  return { report: r, reportUuid: r.id, pdfKey: p ? p.key : null, bytes: null, filename: fileName(r), reportId: r.reportId || '' };
}

/** Ansehen: neueste Archiv-PDF, sonst neu erzeugen (Entwurf: Vorschau, nichts wird gespeichert). */
async function viewReport(r) {
  const p = await latestPdfOf(r.id).catch(() => null);
  const entry = { report: r, reportUuid: r.id, bytes: p ? p.bytes : null, filename: fileName(r), reportId: r.reportId || '' };
  await withPdf(entry, (b) => openPdf(b, entry.filename, `Schadensprotokoll ${entry.reportId}`.trim()));
}

const pdfBytesOf = (entry) => ensureBytes(entry);

/* ---------- Vorlagen ---------- */

const templateFileName = (t) => `Vorlage ${String(t.name || 'ohne Namen').replace(/[\\/:*?"<>|]+/g, ' ').trim()}.pdf`;
/** PDF einer Vorlage: importierte Original-PDF (solange unverändert), sonst aus den Angaben erzeugt. */
/** PDF aus den Angaben einer Vorlage erzeugen (ohne Nummer und Datum). */
function templatePdfBytes(t) {
  const blank = { ...newReport(settings), reportId: '', detectionDate: '', departureDate: '' };
  return buildPdf(applyTemplate(blank, t), new Date().toISOString());
}
async function withTemplatePdf(t, fn) {
  try {
    let bytes = t.hasPdf && t.pdfCurrent ? await getTemplatePdf(t.id).catch(() => null) : null;
    if (!bytes) bytes = await templatePdfBytes(t);
    await fn(bytes, templateFileName(t));
  } catch (e) {
    console.error(e);
    alertDialog('Aktion fehlgeschlagen', String(e && e.message || e));
  }
}
function viewTemplate(t) {
  return withTemplatePdf(t, (b, name) => openPdf(b, name, `Vorlage ${t.name || ''}`.trim()));
}
/** Stift in „Vorlagen“: neues Protokoll, in dem alle Angaben der Vorlage schon eingetragen sind. */
async function newFromTemplate(t) {
  if (!can(settings, 'create')) { denied('Protokolle erstellen'); return; }
  if (dirty && report && canEditReport(settings, report)) {
    const v = await modal({
      title: 'Neues Protokoll aus Vorlage',
      text: 'Das aktuelle Protokoll hat ungespeicherte Änderungen.',
      buttons: [{ label: 'Abbrechen', value: null }, { label: 'Verwerfen', value: 'discard' }, { label: 'Speichern', value: 'save' }],
    });
    if (!v) return;
    if (v === 'save') await putReport(report);
  }
  view = 'form';
  report = applyTemplate(newReport(settings), t);
  dirty = true;
  await saveCurrent(report).catch(() => {});
  closeSheets();
  renderApp();
  window.scrollTo(0, 0);
  updatePresence();
  toast(`Vorlage „${t.name}“ übernommen – Wagennummer und Schaden ergänzen`, 4000);
}

/* ---------- Teilen ---------- */

const validEmail = (v) => /^[^@\s,;]+@[^@\s,;]+\.[^@\s,;]+$/.test(String(v || '').trim());

function shareTexts(r) {
  const wagon = formatWagonNumber(r.wagonNumber);
  const me = activeEmployee(settings);
  const subject = ['Schadensprotokoll', r.reportId, wagon].filter(Boolean).join(' ');
  const where = [r.detectionDate && `am ${formatDate(r.detectionDate)}`, r.detectionPlace && `in ${r.detectionPlace}`].filter(Boolean).join(' ');
  const mail = [
    'Guten Tag,', '',
    `anbei das Schadensprotokoll${r.reportId ? ` ${r.reportId}` : ''}${wagon ? ` zum Wagen ${wagon}` : ''}${where ? ` (festgestellt ${where})` : ''}.`, '',
    'Mit freundlichen Grüßen',
    me ? fullName(me) : (r.contactName || settings.contactName || ''),
    settings.evuName || '',
  ].join('\n').trim();
  const chat = `${subject}${where ? ` – festgestellt ${where}` : ''} (PDF folgt als Datei)`;
  return { subject, mail, chat, to: validEmail(r.keeperEmail) ? r.keeperEmail.trim() : '' };
}

/**
 * Teilen. Windows: Menü mit E-Mail (PDF als Anhang), WhatsApp und Speichern.
 * Handy/Browser: Teilen-Menü des Systems (enthält E-Mail, WhatsApp usw.).
 */
async function sharePdfFlow({ report: r, filename, anchor, getBytes, title }) {
  if (!can(settings, 'share')) { denied('PDFs teilen und speichern'); return; }
  const fail = (e) => { console.error(e); alertDialog('Teilen fehlgeschlagen', String(e && e.message || e)); };
  if (!isDesktop) {
    try { await sharePdf(await getBytes(), filename, title || `Schadensprotokoll ${r.reportId || ''}`.trim()); } catch (e) { fail(e); }
    return;
  }
  const t = shareTexts(r);
  popMenu(anchor, [
    {
      icon: 'mail', label: 'Per E-Mail senden', sub: t.to ? `An ${t.to} · PDF als Anhang` : 'Mailprogramm mit PDF als Anhang',
      onClick: async () => {
        try {
          const res = await desktopShare(await getBytes(), filename, { via: 'mail', to: t.to, subject: t.subject, text: t.mail });
          if (res.result === 'attached') toast('E-Mail mit PDF-Anhang geöffnet', 4000);
          else alertDialog('E-Mail geöffnet', 'Dein Mailprogramm kann Anhänge nicht automatisch übernehmen (z. B. das neue Outlook). Die PDF ist gespeichert und im Explorer markiert – bitte in die E-Mail ziehen.', [res.path]);
        } catch (e) { fail(e); }
      },
    },
    {
      icon: 'chat', label: 'Per WhatsApp senden', sub: 'WhatsApp öffnen, PDF hineinziehen',
      onClick: async () => {
        try {
          const res = await desktopShare(await getBytes(), filename, { via: 'whatsapp', text: t.chat });
          alertDialog(res.result === 'desktop' ? 'WhatsApp geöffnet' : 'WhatsApp Web geöffnet',
            `${res.result === 'desktop' ? 'WhatsApp Desktop wurde geöffnet' : 'WhatsApp Desktop ist nicht installiert – WhatsApp Web wurde im Browser geöffnet'}. Unter Windows lässt sich die Datei nicht automatisch anhängen: Chat wählen und die im Explorer markierte PDF in den Chat ziehen.`, [res.path]);
        } catch (e) { fail(e); }
      },
    },
    {
      icon: 'download', label: 'Speichern & im Explorer zeigen', sub: 'Dokumente\\Schadensprotokolle',
      onClick: async () => {
        try {
          const path = await savePdf(await getBytes(), filename);
          await desktopReveal(path).catch(() => {});
          toast(`Gespeichert: ${path}`, 5000);
        } catch (e) { fail(e); }
      },
    },
  ], { title: 'Teilen' });
}

async function withPdf(entry, fn) {
  try {
    const bytes = await ensureBytes(entry);
    await fn(bytes);
  } catch (e) {
    console.error(e);
    alertDialog('Aktion fehlgeschlagen', String(e && e.message || e));
  }
}

async function buildPdf(r, createdAt) {
  templateBytes = templateBytes || await loadAsset(TEMPLATE);
  const photos = (r.photos || []).map((p) => ({ bytes: dataUrlToBytes(p.dataUrl), type: 'image/jpeg', name: p.name }));
  return fillProtocol(r, settings, { templateBytes, lookup, photos, flatten: settings.flatten, createdAt });
}

async function openReport(id, fallback) {
  const r = (id && await getReport(id).catch(() => null)) || fallback;
  if (!r) return;
  if (dirty && report && r.id !== report.id && canEditReport(settings, report)) await putReport(report).catch(() => {});
  report = JSON.parse(JSON.stringify(r));
  delete report.deletedAt;
  dirty = false;
  await saveCurrent(report).catch(() => {});
  view = 'form';
  closeSheets();
  renderApp();
  window.scrollTo(0, 0);
}

function closeSheets() {
  document.querySelectorAll('.sheet').forEach((s) => s.remove());
  document.body.style.overflow = '';
}

function onTrashed(r) {
  if (report && r.id === report.id) {
    report = newReport(settings); dirty = false;
    saveCurrent(report).catch(() => {});
  }
}

/* ---------- Aktionen ---------- */

async function startNew() {
  view = 'form';
  report = newReport(settings);
  dirty = false;
  await saveCurrent(report).catch(() => {});
  renderApp();
  window.scrollTo(0, 0);
}

async function actionNew() {
  if (!can(settings, 'create')) { denied('Protokolle erstellen'); return; }
  if (dirty && canEditReport(settings, report)) {
    const v = await modal({
      title: 'Neues Protokoll',
      text: 'Das aktuelle Protokoll hat ungespeicherte Änderungen.',
      buttons: [{ label: 'Abbrechen', value: null }, { label: 'Verwerfen', value: 'discard' }, { label: 'Speichern', value: 'save' }],
    });
    if (!v) return;
    if (v === 'save') await putReport(report);
  }
  await startNew();
  toast('Neues Protokoll angelegt');
}

async function actionSave() {
  if (!canEditReport(settings, report)) { denied(report.numberUsed ? 'Protokolle bearbeiten' : 'Protokolle erstellen'); return; }
  try {
    const me = activeEmployee(settings);
    if (me && !(report.createdBy && report.createdBy.id)) report.createdBy = createdByOf(me);
    await putReport(report);
    await saveCurrent(report);
    dirty = false;
    updatePresence();
    toast('Protokoll gespeichert');
  } catch (e) {
    alertDialog('Speichern fehlgeschlagen', String(e && e.message || e));
  }
}

// Dateiname: <Schaden festgestellt am> <Versandbahnhof> <Wagennummer>.pdf
/**
 * Dateiname beim Speichern/Teilen (Wunsch des Nutzers, 25.10.2026):
 * „Schadprotokoll <Wagennummer> <Versandbahnhof> <Schaden festgestellt am>.pdf“,
 * z. B. „Schadprotokoll 37 84 7933 560 - 6 Vohburg 16.09.2026.pdf“. Fehlende Teile entfallen.
 */
function fileName(r) {
  const wagon = formatWagonNumber(r.wagonNumber).replace(/-(\d)$/, ' - $1');
  const parts = ['Schadprotokoll', wagon, r.origin, formatDate(r.detectionDate)]
    .map((p) => String(p || '').replace(/[\\/:*?"<>|\u0000-\u001f]+/g, ' ').replace(/\s+/g, ' ').trim())
    .filter(Boolean);
  return `${parts.join(' ')}.pdf`;
}

/** Laufende Nummer weiterzählen (aktiver Mitarbeiter oder Einstellungen). */
function bumpNumber() {
  const me = activeEmployee(settings);
  if (me) {
    const e = settings.employees.find((x) => x.id === me.id);
    e.nextNumber = (Number(e.nextNumber) || 1) + 1;
    e.updatedAt = new Date().toISOString();
  } else settings.nextNumber = (Number(settings.nextNumber) || 1) + 1;
}

/** Freie Protokoll-Nr.: bereits vergebene Nummern (auch im Papierkorb) überspringen. */
async function freeReportId() {
  const all = [...await listReports(), ...await listTrash()].filter((r) => r.id !== report.id && (r.numberUsed || r.status === 'erstellt'));
  const used = new Set(all.map((r) => String(r.reportId || '').replace(/\s+/g, '').toUpperCase()));
  let id = formatReportId(settings);
  for (let i = 0; i < 10000 && used.has(id.replace(/\s+/g, '').toUpperCase()); i++) { bumpNumber(); id = formatReportId(settings); }
  return id;
}

async function actionSend() {
  // Formular nach dem Erstellen für einen anderen Wagen weiterverwendet -> neues Protokoll mit neuer Nummer
  const reuse = report.numberUsed && report.numberedWagon && report.numberedWagon !== onlyDigits(report.wagonNumber);
  if (!can(settings, report.numberUsed && !reuse ? 'edit' : 'create')) { denied(report.numberUsed && !reuse ? 'Protokolle bearbeiten' : 'Protokolle erstellen'); return; }
  // Schadcodes ohne Punkte (z. B. "5231") vor der Prüfung auflösen
  report.damages.forEach((d) => { if (!d.noCode && d.code && !isSelectable(d.code)) d.code = resolveCode(d.code) || d.code; });
  const { errors, warnings } = validate(report);
  if (errors.length) { await alertDialog('Angaben unvollständig', 'Bitte ergänzen:', errors); return; }
  if (warnings.length) {
    const go = await modal({ title: 'Hinweis', list: warnings, buttons: [{ label: 'Prüfen', value: false }, { label: 'Trotzdem erstellen', value: true }] });
    if (!go) return;
  }
  if (reuse) {
    report.numberUsed = false;
    report.id = crypto.randomUUID ? crypto.randomUUID() : String(Date.now());
    report.status = 'entwurf';
    delete report.createdBy;
  }
  const prev = { reportId: report.reportId, createdBy: report.createdBy, settings: JSON.stringify(settings) };
  const me = activeEmployee(settings);
  if (!report.numberUsed) {
    report.reportId = await freeReportId();
    // Beim Senden dem aktiven Mitarbeiter zuweisen (Name und Zeitpunkt)
    if (me) report.createdBy = createdByOf(me);
  } else if (me && !(report.createdBy && report.createdBy.id)) report.createdBy = createdByOf(me);
  const createdAt = new Date().toISOString();
  const done = busy('PDF wird erstellt …');
  let bytes;
  try {
    bytes = await buildPdf(report, createdAt);
  } catch (e) {
    done();
    report.reportId = prev.reportId; report.createdBy = prev.createdBy;
    settings = { ...settings, ...JSON.parse(prev.settings) };
    console.error(e);
    await alertDialog('PDF konnte nicht erstellt werden', String(e && e.message || e));
    return;
  }
  done();

  if (!report.numberUsed) {
    bumpNumber();
    report.numberedWagon = onlyDigits(report.wagonNumber);
  }
  saveSettings(settings);
  report.numberUsed = true;
  report.status = 'erstellt';
  report.pdfCreatedAt = createdAt;
  report.updatedAt = report.pdfCreatedAt;
  const filename = fileName(report);
  await putReport(report).catch(() => {});
  await saveCurrent(report).catch(() => {});
  // Für das Dashboard archivieren und an den Server übertragen
  await putPdf({ createdAt: report.pdfCreatedAt, filename, bytes, report }).catch((e) => console.warn('PDF-Archiv', e));
  if (calendarDayOf(report)) focusDashboard(calendarDayOf(report), `r|${report.id}`); else resetDashboardSelection();
  updatePresence();
  pushProtocol(report).catch(() => {});
  scheduleEmployeeSync();
  dirty = false;
  if (extended()) refreshChrome();
  renderMain();

  const title = `Schadensprotokoll ${report.reportId || ''}`.trim();
  openResult({
    filename,
    canShare: can(settings, 'share'),
    onShare: (anchor) => sharePdfFlow({ report, filename, anchor, getBytes: async () => bytes, title }),
    onSave: async () => {
      try { const uri = await savePdf(bytes, filename); toast(uri ? `Gespeichert: ${String(uri).replace(/^file:\/\//, '')}` : 'Download gestartet'); }
      catch (e) { alertDialog('Speichern fehlgeschlagen', String(e && e.message || e)); }
    },
    onPreview: () => previewPdf(bytes),
    onNew: () => startNew(),
    onDashboard: extended() ? () => switchView('dashboard') : null,
  });
}

/* ---------- Einstellungen ---------- */

function showSettings() {
  openSettings(settings, async (s, { apiToken }) => {
    const modeChanged = !!s.extendedMode !== extended();
    const mayServer = can(settings, 'server');
    const SRV = ['serverMode', 'serverUrl', 'serverIp', 'serverPins'];
    const srvKey = (o) => JSON.stringify(SRV.map((k) => o[k] ?? null));
    const serverChanged = mayServer && (srvKey(s) !== srvKey(settings) || apiToken !== getSecret('apiToken'));
    if (!mayServer) SRV.forEach((k) => { s[k] = settings[k]; });
    settings = { ...settings, ...s, employees: settings.employees, activeEmployeeId: settings.activeEmployeeId };
    saveSettings(settings);
    setDesign(settings.design);
    if (serverChanged) {
      // Neue Adresse oder neuer Token: bisherige Anmeldung verwerfen und neu prüfen
      await setSecret('apiToken', apiToken);
      await setSecret('sessionToken', '');
      checkConnection().then(() => { refreshChrome(); runSync({}); });
    }
    // Halter-Abfrage mit neuer Server-Adresse erneut versuchen
    if (report.keeperLookup && !['ok', 'not_found', 'invalid'].includes(report.keeperLookup.status)) delete report.keeperLookup;
    if (!report.numberUsed) report.reportId = formatReportId(settings);
    if (modeChanged) view = extended() ? 'dashboard' : 'form';
    renderApp();
    if (modeChanged) window.scrollTo(0, 0);
  }, { can: (p) => can(settings, p), apiToken: getSecret('apiToken'), conn });
}

/* ---------- Gespeichert / Papierkorb / Anmeldung als Vollbild (normale Ansicht) ---------- */

function showSaved() {
  if (extended()) { switchView('saved'); return; }
  const v = renderSaved(app);
  savedSheet = v;
  const close = sheetShell('Gespeicherte Protokolle', () => close(), v,
    h('div', { class: 'sheet-links' }, h('button', { class: 'pill-btn', onclick: () => { close(); showTrashSheet(); } }, icon('trash'), 'Papierkorb')));
}
function showTrashSheet() {
  const close = sheetShell('Papierkorb', () => close(), renderTrash(app));
}
function showLoginSheet() {
  if (extended()) { switchView('login'); return; }
  const close = sheetShell('Anmeldung', () => close(), renderLogin(app));
}

/* ---------- Mitarbeiter ---------- */

function persistEmployees() {
  saveSettings(settings);
  scheduleEmployeeSync();
}

function editEmployee(e) {
  if (hasEmployees(settings) && !can(settings, 'employees')) { denied('Mitarbeiter verwalten'); return; }
  openEmployeeEditor(app, e, {
    sheetShell,
    onSave: async (emp, { first }) => {
      const list = [...(settings.employees || [])];
      const i = list.findIndex((x) => x.id === emp.id);
      if (i >= 0) list[i] = emp; else list.push(emp);
      settings = { ...settings, employees: list };
      if (first) {
        // Umstieg: der erste Mitarbeiter übernimmt Präfix und laufende Nummer und wird aktiv
        settings.activeEmployeeId = emp.id;
        markUnlocked(emp.id);
      }
      if (settings.activeEmployeeId === emp.id && emp.active === false) settings.activeEmployeeId = '';
      persistEmployees();
      if (report && !report.numberUsed) report.reportId = formatReportId(settings);
      app.selectedEmployee = emp.id;
      toast(i >= 0 ? 'Mitarbeiter gespeichert' : `${fullName(emp)} angelegt`);
      renderApp();
    },
    onDelete: async (emp) => {
      const list = (settings.employees || []).map((x) => (x.id === emp.id
        ? { id: x.id, firstName: x.firstName, lastName: x.lastName, prefix: x.prefix, nextNumber: x.nextNumber, deleted: true, updatedAt: new Date().toISOString() }
        : x));
      settings = { ...settings, employees: list };
      if (settings.activeEmployeeId === emp.id) settings.activeEmployeeId = '';
      app.selectedEmployee = null;
      persistEmployees();
      toast('Mitarbeiter gelöscht');
      renderApp();
    },
  });
}

function showSwitcher(opts = {}) {
  if (!activeList(settings).length) { if (extended()) switchView('employees'); return; }
  openSwitcher(app, {
    ...opts,
    onSetPin: async (e, pin) => {
      settings = { ...settings, employees: settings.employees.map((x) => (x.id === e.id ? { ...x, ...pin, updatedAt: new Date().toISOString() } : x)) };
      persistEmployees();
      toast('PIN gespeichert');
    },
    onPick: (e) => {
      settings = { ...settings, activeEmployeeId: e.id };
      saveSettings(settings);
      if (report && !report.numberUsed) report.reportId = formatReportId(settings);
      toast(`Angemeldet: ${fullName(e)}`);
      renderApp();
    },
    onLock: () => {
      markUnlocked(null);
      settings = { ...settings, activeEmployeeId: '' };
      saveSettings(settings);
      toast('Gesperrt');
      renderApp();
    },
  });
}

/* ---------- Mitarbeiterliste importieren / exportieren ---------- */

const normName = (v) => String(v || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim();

/** Freies Präfix: bei Belegung die letzte Zahl hochzählen (K42U17 -> K42U18 …). */
function freePrefix(prefix, taken) {
  let p = normPrefix(prefix);
  const m = /^(.*?)(\d+)$/.exec(p);
  for (let i = 0; taken.has(p) && i < 200; i++) {
    p = m ? `${m[1]}${String((parseInt(m[2], 10) + i + 1) % 100).padStart(m[2].length, '0')}` : `${normPrefix(prefix)}${i + 2}`;
  }
  return p;
}

/**
 * Mitarbeiterliste (JSON) einlesen. Vorhandene Mitarbeiter (gleicher Vor- und Nachname) bleiben
 * unverändert; belegte Präfixe werden auf das nächste freie umgestellt. Ohne PIN angelegte
 * Mitarbeiter legen ihre PIN bei der ersten Anmeldung selbst fest.
 */
async function importEmployees(file) {
  if (!can(settings, 'employees')) { denied('Mitarbeiter verwalten'); return; }
  let data;
  try { data = JSON.parse(await file.text()); } catch { alertDialog('Import nicht möglich', 'Die Datei ist keine gültige JSON-Datei.'); return; }
  const items = Array.isArray(data) ? data : data && Array.isArray(data.employees) ? data.employees : null;
  if (!items) { alertDialog('Import nicht möglich', 'In der Datei wurde keine Mitarbeiterliste gefunden.'); return; }
  const existing = listEmployees(settings);
  const byName = new Set(existing.map((e) => normName(`${e.firstName} ${e.lastName}`)));
  const taken = new Set(existing.map((e) => normPrefix(e.prefix)).filter(Boolean));
  const reports = [...await listReports(), ...await listTrash()];
  const added = [], skipped = [], changed = [], invalid = [];
  const now = new Date().toISOString();
  for (const it of items) {
    const firstName = String(it.firstName || '').trim(), lastName = String(it.lastName || '').trim();
    if (!firstName || !lastName) { invalid.push(JSON.stringify(it).slice(0, 60)); continue; }
    const key = normName(`${firstName} ${lastName}`);
    if (byName.has(key)) { skipped.push(`${firstName} ${lastName}`); continue; }
    const wanted = normPrefix(it.prefix);
    if (!/^[A-Z0-9][A-Z0-9-]{0,19}$/.test(wanted)) { invalid.push(`${firstName} ${lastName}: Präfix fehlt oder ungültig`); continue; }
    const prefix = freePrefix(wanted, taken);
    if (prefix !== wanted) changed.push(`${firstName} ${lastName}: ${wanted} → ${prefix}`);
    const tpl = TEMPLATES[it.role] || TEMPLATES.editor;
    const perms = it.perms && typeof it.perms === 'object' ? Object.fromEntries(PERMS.map(([k]) => [k, !!it.perms[k]])) : { ...tpl.perms };
    const email = String(it.email || '').trim();
    added.push({
      id: crypto.randomUUID ? crypto.randomUUID() : `e${Date.now()}${added.length}`,
      firstName, lastName, title: String(it.title || '').trim(),
      email: /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email) ? email : '',
      phone: String(it.phone || '').trim(), prefix,
      nextNumber: Math.max(Number(it.nextNumber) || 1, maxUsedNumber(prefix, reports) + 1),
      perms, active: it.active !== false, createdAt: now, updatedAt: now,
    });
    byName.add(key); taken.add(prefix);
  }
  if (added.length) {
    settings = { ...settings, employees: [...(settings.employees || []), ...added] };
    persistEmployees();
    renderApp();
  }
  const list = [
    ...skipped.map((n) => `Bereits vorhanden, unverändert: ${n}`),
    ...changed.map((c) => `Präfix belegt, geändert: ${c}`),
    ...invalid.map((c) => `Übersprungen: ${c}`),
  ];
  alertDialog(`${added.length} Mitarbeiter angelegt`, added.length ? 'Die PIN legt jeder bei der ersten Anmeldung selbst fest.' : 'Es wurde niemand neu angelegt.', list);
}

function exportEmployees() {
  const out = listEmployees(settings).map(({ firstName, lastName, title, email, phone, prefix, nextNumber, perms, active }) =>
    ({ firstName, lastName, title, email, phone, prefix, nextNumber, role: roleOf(perms || {}), perms, active: active !== false }));
  const blob = new Blob([JSON.stringify({ format: 'schadwagen-mitarbeiter', version: 1, exportedAt: new Date().toISOString(), employees: out }, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = 'mitarbeiter.json';
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 30000);
  toast('Mitarbeiterliste ohne PINs exportiert');
}

/* ---------- Import ---------- */

async function importFiles(files, { from } = {}) {
  if (!can(settings, 'create')) { denied('Protokolle erstellen'); return; }
  let added = 0, assigned = 0, unassigned = 0, updated = 0;
  const errs = [];
  const imported = [];
  for (const f of files) {
    try {
      const { report: r, pdfBytes } = await readProtocolFile(f);
      const existing = await getReport(r.id);
      // Schon importiert und seitdem nicht bearbeitet: mit der neuen Auswertung aktualisieren
      const untouched = existing && (existing.source === 'import') && !existing.deletedAt && !editedAfterImport(existing);
      let replace = untouched;
      if (existing && !existing.deletedAt && !untouched) {
        // Bereits vorhanden: nur nachfragen, wenn die Ankreuzfelder der PDF vom gespeicherten Stand abweichen
        const diff = choiceDiff(existing, r);
        replace = diff.length > 0 && await confirmDialog('Protokoll bereits vorhanden',
          `${r.reportId || f.name}: Die PDF weicht vom gespeicherten Protokoll ab (${diff.join(', ')}). Stand der PDF übernehmen? Änderungen, die nur im Formular gemacht wurden, werden dabei überschrieben.`,
          'PDF übernehmen');
        if (!replace) { errs.push(`${f.name}: bereits vorhanden${diff.length ? ' (nicht übernommen)' : ''}`); continue; }
      }
      if (replace) {
        r.createdBy = existing.createdBy || r.createdBy;
        r.pdfCreatedAt = existing.pdfCreatedAt || r.pdfCreatedAt;
        if (existing.source && existing.source !== 'import') r.source = existing.source;
        if (!(r.photos && r.photos.length) && existing.photos) r.photos = existing.photos;
        updated++;
      }
      delete r.deletedAt;
      delete r.changedInPdf;
      r.source = r.source || 'import';
      r.importedAt = new Date().toISOString();
      r.status = 'erstellt';
      r.numberUsed = !!r.reportId;
      r.pdfCreatedAt = r.pdfCreatedAt || r.importedAt;
      r.photos = r.photos || [];
      // Zuordnung über Präfix der Protokollnummer, ersatzweise über den Namen
      if (!(r.createdBy && r.createdBy.id && listEmployees(settings).some((e) => e.id === r.createdBy.id))) {
        const { employee } = ownerOf(r, settings);
        if (employee) r.createdBy = { ...createdByOf(employee), at: r.createdBy?.at || r.pdfCreatedAt, auto: true };
      }
      if (ownerOf(r, settings).employee) assigned++; else unassigned++;
      await putReport(r);
      if (pdfBytes) await putPdf({ createdAt: r.pdfCreatedAt, filename: f.name, bytes: pdfBytes, report: r });
      added++;
      imported.push({ day: calendarDayOf(r), key: `r|${r.id}`, at: r.detectionDate || '' });
    } catch (e) {
      errs.push(`${f.name}: ${e.message || e}`);
    }
  }
  await bumpNumbersFromReports();
  // Kalender: zum Tag des neuesten importierten Protokolls springen
  // Kalender/Ordner: Tag der Schadensfeststellung des neuesten importierten Protokolls
  const dated = imported.filter((i) => i.day);
  const days = [...new Set(dated.map((i) => i.day))].sort();
  const noDay = imported.length - dated.length;
  const newest = dated.sort((a, b) => b.day.localeCompare(a.day))[0];
  const where = (newest ? ` · festgestellt am ${formatDate(newest.day)}${days.length > 1 ? ` (und an ${days.length - 1} weiteren Tag${days.length > 2 ? 'en' : ''})` : ''}` : '')
    + (noDay ? ` · ${noDay} ohne Feststellungsdatum („Ohne Datum“)` : '');
  const summary = added ? `${added - updated ? `${added - updated} importiert` : ''}${added - updated && updated ? ' · ' : ''}${updated ? `${updated} aktualisiert` : ''}${hasEmployees(settings) ? ` · ${assigned} zugeordnet · ${unassigned} nicht zugeordnet` : ''}${where}` : 'Nichts importiert';
  if (errs.length) alertDialog(summary, 'Hinweise:', errs); else toast(summary, 6000);
  if (newest) focusDashboard(newest.day, newest.key); else resetDashboardSelection();
  // Aus „Gespeichert“ heraus: dort bleiben und den Datumsordner öffnen; sonst Kalender zeigen
  const fromSaved = from === 'saved' || (view === 'saved' && extended());
  if (fromSaved) {
    const pick = newest || imported[0];
    const r0 = pick ? await getReport(pick.key.slice(2)) : null;
    if (r0) setSavedPath(savedPathFor(r0));
    if (savedSheet && savedSheet.isConnected) savedSheet.refresh(); else viewEl?.refresh?.();
  } else if (newest && extended() && view !== 'dashboard') switchView('dashboard');
  else viewEl?.refresh?.();
}

/** Welche Ankreuzfelder unterscheiden sich zwischen gespeichertem Protokoll und eingelesener PDF? */
const CHOICE_NAMES = { loadingStatus: 'Leer/Beladen', workshop: 'Werkstattzuführung', takeover: 'Übernahme', cause: 'Verursacher',
  existingLabels: 'vorgefundene Bezettelung', newLabels: 'erfolgte Bezettelung', wagonDetached: 'Aussetzen', attachments: 'Anlagen' };
function choiceDiff(a, b) {
  const norm = (v) => (v && typeof v === 'object' ? JSON.stringify(Object.keys(v).filter((k) => v[k]).sort()) : String(v || ''));
  const out = Object.keys(CHOICE_NAMES).filter((k) => norm(a[k]) !== norm(b[k])).map((k) => CHOICE_NAMES[k]);
  const oa = (a.damages || []).map((d) => !!d.old), ob = (b.damages || []).map((d) => !!d.old);
  if (ob.some((o, i) => i < oa.length && o !== oa[i])) out.push('Neu/Alt');
  return out;
}

/** Wurde ein importiertes Protokoll danach im Formular geändert? (Dann nie automatisch überschreiben.) */
function editedAfterImport(r) {
  const imp = new Date(r.importedAt || 0).getTime();
  const upd = new Date(r.updatedAt || 0).getTime();
  return !!r.importedAt && upd - imp > 60000;
}

/**
 * Früher importierte Protokolle ohne Ankreuzfelder (Neu/Alt, Ladezustand, Bezettelung …) aus der
 * gespeicherten Original-PDF erneut auswerten – nur, wenn sie seit dem Import nicht bearbeitet wurden.
 */
async function reparseImports() {
  // Nur Kandidaten aus der Übersicht; PDF-Inhalt nur für diese laden
  const cands = (await listReports()).filter((r) => r.source === 'import' && !r.choicesImported && !r.partial && !editedAfterImport(r));
  if (!cands.length) return 0;
  const pdfs = await listPdfs();
  let n = 0;
  for (const c of cands) {
    const pm = pdfs.find((p) => p.reportUuid === c.id);
    if (!pm) continue;
    const p = await getPdf(pm.key);
    const old = await getReport(c.id);
    if (!p || !p.bytes || !old) continue;
    try {
      const bytes = p.bytes instanceof Uint8Array ? p.bytes : new Uint8Array(p.bytes);
      const { report: fresh, via } = await readProtocolFile({ name: p.filename || '', arrayBuffer: async () => bytes.slice().buffer });
      if (via !== 'fields' && via !== 'embedded') continue;
      const merged = { ...old, ...fresh, id: old.id, createdBy: old.createdBy || fresh.createdBy, pdfCreatedAt: old.pdfCreatedAt,
        importedAt: old.importedAt, source: 'import', status: 'erstellt', choicesImported: true, photos: old.photos || [] };
      merged.updatedAt = old.updatedAt;
      await putReport(merged);
      await putPdf({ createdAt: p.createdAt, filename: p.filename, bytes, report: merged });
      n++;
    } catch (e) { console.warn('Import neu auswerten', p.filename, e); }
  }
  return n;
}

/** Keine Nummer doppelt vergeben: laufende Nummern an vorhandene Protokolle anpassen. */
async function bumpNumbersFromReports() {
  const all = [...await listReports(), ...await listTrash()];
  let changed = false;
  for (const e of settings.employees || []) {
    if (e.deleted || !e.prefix) continue;
    const used = maxUsedNumber(e.prefix, all);
    if (used >= (Number(e.nextNumber) || 1)) { e.nextNumber = used + 1; e.updatedAt = new Date().toISOString(); changed = true; }
  }
  if (!hasEmployees(settings) && settings.reportPrefix) {
    const used = maxUsedNumber(settings.reportPrefix, all);
    if (used >= (Number(settings.nextNumber) || 1)) { settings.nextNumber = used + 1; changed = true; }
  }
  if (changed) { saveSettings(settings); scheduleEmployeeSync(); }
}

/* ---------- Abgleich mit dem Server ---------- */

let syncing = false;
let empSyncTimer = null;
function scheduleEmployeeSync() {
  clearTimeout(empSyncTimer);
  empSyncTimer = setTimeout(() => runSync({ employeesOnly: true }), 1500);
}

async function runSync({ full = false, manual = false, employeesOnly = false } = {}) {
  if (!canSync()) { if (manual) toast('Keine Verbindung zum Server oder nicht angemeldet'); return; }
  if (syncing) return;
  syncing = true;
  try {
    const merged = await syncEmployees(settings);
    if (merged && JSON.stringify(merged) !== JSON.stringify(settings.employees || [])) {
      settings = { ...settings, employees: merged };
      saveSettings(settings);
      refreshChrome();
    }
    const folders = await syncFolders(settings);
    if (folders && JSON.stringify(folders) !== JSON.stringify(settings.folders || [])) {
      settings = { ...settings, folders };
      saveSettings(settings);
      if (view === 'saved' || document.querySelector('.sv-body')) viewEl?.refresh?.();
    }
    if (employeesOnly) return;
    await pushPending();
    // Keine Protokolle auf dem Gerät (z. B. neu eingerichtet): alles vom Server holen
    if (!full && !(await listReports()).length) full = true;
    const res = await pullProtocols(settings, { full });
    if (res.added || res.updated) {
      await bumpNumbersFromReports();
      resetDashboardSelection();
      viewEl?.refresh?.();
      toast(`${res.added + res.updated} Protokoll(e) vom Server übernommen`);
    } else if (manual) toast('Keine neuen Protokolle auf dem Server');
  } catch (e) {
    console.warn('Abgleich', e);
  } finally { syncing = false; }
}

/* ---------- Zurück-Taste (Android) ---------- */

// Schließt den obersten Dialog; liefert true, wenn etwas geschlossen wurde.
window.__handleBack = () => {
  const pm = document.querySelector('.popmenu');
  if (pm) { pm.close(); return true; }
  const lb = document.querySelector('.lightbox');
  if (lb) { lb.close(); return true; }
  const modalEl = [...document.querySelectorAll('.modal-bg')].pop();
  if (modalEl) {
    const btn = [...modalEl.querySelectorAll('.actions .btn')].find((b) => /Abbrechen|Zurück|Schließen|Nur ansehen/.test(b.textContent)) || modalEl.querySelector('.actions .btn');
    if (btn) btn.click(); else modalEl.remove();
    return true;
  }
  const sheet = [...document.querySelectorAll('.sheet')].pop();
  if (sheet) {
    const btn = sheet.querySelector('[aria-label="Zurück"]') || [...sheet.querySelectorAll('.actions .btn')].find((b) => b.textContent === 'Abbrechen');
    if (btn) btn.click(); else sheet.remove();
    document.body.style.overflow = '';
    return true;
  }
  if (document.querySelector('.ac')) { document.activeElement?.blur(); return true; }
  if (extended() && view !== 'dashboard') { switchView('dashboard'); return true; }
  return false;
};

// Beim Verlassen/Minimieren sofort speichern
/* ---------- Aktuelle Bearbeitung (Anwesenheit) ---------- */

// Gemeldet wird, solange der aktive Mitarbeiter ein Protokoll im Formular offen hat
// (mit Wagennummer oder Protokoll-Nr.), daran arbeitet (ungespeicherte Änderungen oder letzte
// Änderung vor weniger als 15 Minuten) und die App sichtbar ist.
const PRESENCE_IDLE_MS = 15 * 60000;
async function updatePresence() {
  const me = activeEmployee(settings);
  const formVisible = !extended() || view === 'form';
  const recent = report && Date.now() - new Date(report.updatedAt || 0).getTime() < PRESENCE_IDLE_MS;
  const empty = !report || (!onlyDigits(report.wagonNumber) && !report.numberUsed);
  if (!me || empty || !(dirty || recent) || document.visibilityState === 'hidden') { setLocalPresence(null); return; }
  const stored = !!(await getReport(report.id).catch(() => null));
  setLocalPresence({
    employeeId: me.id, employeeName: fullName(me),
    reportUuid: report.id, reportId: report.numberUsed ? report.reportId : '',
    wagonNumber: report.wagonNumber || '', place: report.detectionPlace || '',
    stored, inForm: formVisible, dirty, lastActivity: report.updatedAt || new Date().toISOString(),
  });
}

function flush() { if (report) { clearTimeout(saveTimer); saveCurrent(report).catch(() => {}); } }
window.addEventListener('pagehide', flush);
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') flush(); updatePresence(); });

/* ---------- Start ---------- */

function applyDesign() {
  const q = new URLSearchParams(location.search).get('design'); // nur für Vorschauen
  setDesign(q || settings.design || 'hell');
}

// Frühere Einstellung der Halter-Abfrage in die gemeinsame Server-Verbindung übernehmen
async function migrateSettings() {
  let changed = false;
  if (settings.keeperApiUrl && !settings.serverUrl) { settings.serverUrl = settings.keeperApiUrl; changed = true; }
  if (settings.keeperApiKey) {
    if (!getSecret('apiToken')) await setSecret('apiToken', settings.keeperApiKey);
    changed = true;
  }
  if ('keeperApiUrl' in settings || 'keeperApiKey' in settings) { delete settings.keeperApiUrl; delete settings.keeperApiKey; changed = true; }
  if (changed) saveSettings(settings);
}

const perfMark = (n) => { try { performance.mark(`sw:${n}`); } catch { /* alt */ } };
(async function init() {
  perfMark('init');
  settings = await syncSettings(settings);
  await loadSecrets();
  await migrateSettings();
  configureServer(() => settings);
  // Übersicht (ohne Fotos/PDF-Inhalt) in den Speicher – beim ersten Start einmalige Umstellung
  const slow = setTimeout(() => { const t = document.getElementById('boot-note'); if (t) t.hidden = false; }, 600);
  await warmUp().catch((e) => console.warn('Übersicht', e));
  clearTimeout(slow);
  document.getElementById('boot-note')?.remove();
  perfMark('repairs');
  try { report = await loadCurrent(); } catch { report = null; }
  if (report && report.deletedAt) report = null;
  // Ohne PIN-Abfrage beim Start gilt der zuletzt aktive Mitarbeiter
  if (settings.pinOnStart === false && settings.activeEmployeeId) markUnlocked(settings.activeEmployeeId);
  // Noch nicht erstelltes Protokoll: Nummer immer aus den aktuellen Einstellungen
  if (report && !report.numberUsed) report.reportId = formatReportId(settings);
  if (!report) report = newReport(settings);
  applyDesign();
  if (!extended()) view = 'form';
  // Jede Datenänderung (Import, Senden, Löschen, Wiederherstellen, Ordner, Server-Abruf …) sofort anzeigen
  onDataChange(() => {
    if ((view === 'dashboard' || view === 'saved') && viewEl && viewEl.isConnected) viewEl.refresh?.();
    if (savedSheet && savedSheet.isConnected) savedSheet.refresh?.();
  });
  renderApp();
  perfMark('render');
  // Wartungsaufgaben erst nach dem ersten Anzeigen und gebündelt im Hintergrund
  setTimeout(async () => {
    await purgeTrash().catch(() => {});
    await repairImportDates().catch((e) => console.warn('Importdaten', e));
    await reparseImports().catch((e) => console.warn('Import neu auswerten', e));
    perfMark('wartung');
  }, 400);
  document.body.appendChild(latencyBadge());
  // Sidebar/Kopfleiste zeigen den Reiter „Anmeldung“, sobald die Verbindung steht
  let last = '';
  onConnChange((c) => {
    const sig = `${c.status === 'ok'}|${c.loginRequired}|${c.loggedIn}`;
    if (sig !== last) {
      last = sig;
      refreshChrome();
      if (canSync()) runSync({});
    }
  });
  let ticks = 0;
  startMonitor(() => { if (++ticks % 8 === 0) runSync({}); });
  startPresence();
  setInterval(updatePresence, 60000);
  if (hasEmployees(settings) && settings.pinOnStart !== false && activeList(settings).length) {
    showSwitcher({ preselect: settings.activeEmployeeId, force: true });
  }
  if ('serviceWorker' in navigator && location.protocol.startsWith('http') && !window.Capacitor && !window.AndroidBridge && location.port !== '47831') {
    navigator.serviceWorker.register('sw.js').catch(() => {});
  } else if ('serviceWorker' in navigator && location.port === '47831') {
    // Windows-Programm: nie einen Service Worker verwenden – ein früher registrierter würde alte Dateien liefern
    navigator.serviceWorker.getRegistrations().then(async (regs) => {
      if (!regs.length) return;
      await Promise.all(regs.map((r) => r.unregister()));
      try { for (const k of await caches.keys()) await caches.delete(k); } catch { /* egal */ }
      if (navigator.serviceWorker.controller && !sessionStorage.getItem('sw.killed')) { sessionStorage.setItem('sw.killed', '1'); location.reload(); }
    }).catch(() => {});
  }
})();
