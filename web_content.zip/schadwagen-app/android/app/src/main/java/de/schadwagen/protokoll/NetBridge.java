package de.schadwagen.protokoll;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NoRouteToHostException;
import java.net.Proxy;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLHandshakeException;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

/**
 * Netzwerkzugriff für IP-Verbindungen und eigene Zertifikate (die WebView kann selbst ausgestellte
 * Zertifikate nicht annehmen und blockiert http aus der https-App-Seite).
 *
 * request: { url, method, headers, body, pin, timeoutMs, allowHttp } -> { status, body } | { error, detail, cert }
 * probe:   { host, port } -> { fingerprint, subject, issuer, notBefore, notAfter, selfSigned, trusted, sans }
 *
 * Pinning: Ist ein Fingerabdruck (SHA-256 über das Zertifikat) gemerkt, wird genau dieses Zertifikat
 * verlangt – sonst Fehler „cert_changed“. Ohne Fingerabdruck gilt die normale Prüfung des Systems.
 * http nur zu privaten/lokalen Adressen, nur Pfade unter /api/, keine Weiterleitungen.
 * Kopfzeilen (API-Token, Sitzung) werden nie protokolliert.
 */
final class NetBridge {
    private static final int MAX_BODY = 64 << 20;
    private static final String[] ALLOWED_HEADERS = {"content-type", "x-api-key", "authorization", "accept"};

    private NetBridge() {}

    static String request(String json) {
        try {
            return doRequest(new JSONObject(json)).toString();
        } catch (JSONException e) {
            return err("blocked", "Anfrage ungültig", null);
        }
    }

    static String probe(String json) {
        try {
            JSONObject in = new JSONObject(json);
            return doProbe(in.optString("host"), in.optInt("port")).toString();
        } catch (JSONException e) {
            return err("blocked", "Anfrage ungültig", null);
        }
    }

    /* ---------- Anfrage ---------- */

    private static JSONObject doRequest(JSONObject in) throws JSONException {
        URL url;
        try {
            url = new URL(in.optString("url"));
        } catch (IOException e) {
            return obj(err("blocked", "Adresse ungültig.", null));
        }
        String scheme = url.getProtocol().toLowerCase(Locale.ROOT);
        if (!scheme.equals("http") && !scheme.equals("https") || url.getUserInfo() != null) {
            return obj(err("blocked", "Adresse ungültig.", null));
        }
        if (url.getPath() == null || !url.getPath().startsWith("/api/")) {
            return obj(err("blocked", "Nur Schadwagen-Schnittstellen (/api/…) sind erlaubt.", null));
        }
        String host = stripBrackets(url.getHost());
        if (scheme.equals("http") && !isPrivate(host)) {
            return obj(err("blocked", "Unverschlüsselt (http) nur im lokalen Netz erlaubt.", null));
        }
        String method = in.optString("method", "GET").toUpperCase(Locale.ROOT);
        if (!(method.equals("GET") || method.equals("POST") || method.equals("PUT") || method.equals("DELETE"))) {
            return obj(err("blocked", "Methode nicht erlaubt.", null));
        }
        int timeout = in.optInt("timeoutMs", 10000);
        if (timeout <= 0 || timeout > 120000) timeout = 10000;
        String pin = normFp(in.optString("pin", ""));
        final X509Certificate[] seen = new X509Certificate[1];

        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) url.openConnection(Proxy.NO_PROXY);
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(timeout);
            c.setReadTimeout(timeout);
            c.setUseCaches(false);
            c.setRequestMethod(method);
            if (c instanceof HttpsURLConnection) {
                HttpsURLConnection hc = (HttpsURLConnection) c;
                X509TrustManager tm = trustManager(pin, seen);
                SSLContext ctx = SSLContext.getInstance("TLS");
                ctx.init(null, new TrustManager[]{tm}, null);
                hc.setSSLSocketFactory(ctx.getSocketFactory());
                if (!pin.isEmpty()) {
                    // Das gemerkte Zertifikat ist eindeutig – Name/IP im Zertifikat spielt dann keine Rolle.
                    hc.setHostnameVerifier(ALLOW_PINNED);
                }
            }
            JSONObject headers = in.optJSONObject("headers");
            if (headers != null) {
                Iterator<String> it = headers.keys();
                while (it.hasNext()) {
                    String k = it.next();
                    if (allowedHeader(k)) c.setRequestProperty(k, headers.optString(k));
                }
            }
            if (!in.isNull("body") && in.has("body")) {
                byte[] b = in.optString("body").getBytes(StandardCharsets.UTF_8);
                c.setDoOutput(true);
                c.setFixedLengthStreamingMode(b.length);
                try (OutputStream os = c.getOutputStream()) { os.write(b); }
            }
            int status = c.getResponseCode();
            InputStream is = status >= 400 ? c.getErrorStream() : c.getInputStream();
            String body = is == null ? "" : readAll(is);
            JSONObject out = new JSONObject();
            out.put("status", status);
            out.put("body", body);
            return out;
        } catch (Exception e) {
            return classify(e, seen[0]);
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private static final HostnameVerifier ALLOW_PINNED = (hostname, session) -> true;

    /** Gemerkter Fingerabdruck: genau dieses Zertifikat; sonst Prüfung durch das System. */
    private static X509TrustManager trustManager(final String pin, final X509Certificate[] seen) throws Exception {
        TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        tmf.init((java.security.KeyStore) null);
        X509TrustManager sys = null;
        for (TrustManager t : tmf.getTrustManagers()) if (t instanceof X509TrustManager) sys = (X509TrustManager) t;
        final X509TrustManager system = sys;
        return new X509TrustManager() {
            @Override public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
                throw new CertificateException("nicht unterstützt");
            }
            @Override public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
                if (chain == null || chain.length == 0) throw new CertificateException("kein Zertifikat");
                seen[0] = chain[0];
                if (!pin.isEmpty()) {
                    if (!fingerprint(chain[0]).equals(pin)) throw new PinMismatch();
                    return;
                }
                if (system == null) throw new CertificateException("keine Vertrauensstellen");
                system.checkServerTrusted(chain, authType);
            }
            @Override public X509Certificate[] getAcceptedIssuers() {
                return system != null ? system.getAcceptedIssuers() : new X509Certificate[0];
            }
        };
    }

    static final class PinMismatch extends CertificateException {
        PinMismatch() { super("Fingerabdruck stimmt nicht überein"); }
    }

    private static JSONObject classify(Exception e, X509Certificate cert) {
        try {
            Throwable t = e;
            while (t != null) {
                if (t instanceof PinMismatch) return obj(err("cert_changed", t.getMessage(), cert));
                t = t.getCause();
            }
            if (e instanceof SSLHandshakeException) {
                String m = String.valueOf(e.getMessage()).toLowerCase(Locale.ROOT);
                if (m.contains("certpath") || m.contains("trust anchor") || m.contains("certificate") || m.contains("hostname")) {
                    return obj(err("cert_untrusted", e.getMessage(), cert));
                }
                return obj(err("tls", e.getMessage(), cert));
            }
            if (e instanceof javax.net.ssl.SSLException) {
                String m = String.valueOf(e.getMessage()).toLowerCase(Locale.ROOT);
                if (m.contains("unrecognized ssl message") || m.contains("plaintext")) {
                    return obj(err("tls", "der Server antwortet unverschlüsselt (http statt https?)", null));
                }
                return obj(err("tls", e.getMessage(), cert));
            }
            if (e instanceof SocketTimeoutException) return obj(err("timeout", null, null));
            if (e instanceof UnknownHostException) return obj(err("dns", e.getMessage(), null));
            if (e instanceof NoRouteToHostException) return obj(err("unreachable", e.getMessage(), null));
            if (e instanceof ConnectException) {
                String m = String.valueOf(e.getMessage()).toLowerCase(Locale.ROOT);
                if (m.contains("unreachable")) return obj(err("unreachable", e.getMessage(), null));
                if (m.contains("timed out")) return obj(err("timeout", null, null));
                return obj(err("refused", e.getMessage(), null));
            }
            return obj(err("network", e.getClass().getSimpleName() + ": " + e.getMessage(), null));
        } catch (JSONException je) {
            return new JSONObject();
        }
    }

    /* ---------- Zertifikat abrufen ---------- */

    private static JSONObject doProbe(String host, int port) throws JSONException {
        host = stripBrackets(host);
        if (host.isEmpty() || port < 1 || port > 65535) return obj(err("blocked", "Adresse ungültig.", null));
        final X509Certificate[] seen = new X509Certificate[1];
        try {
            X509TrustManager capture = new X509TrustManager() {
                @Override public void checkClientTrusted(X509Certificate[] chain, String a) throws CertificateException {
                    throw new CertificateException("nicht unterstützt");
                }
                @Override public void checkServerTrusted(X509Certificate[] chain, String a) {
                    if (chain != null && chain.length > 0) seen[0] = chain[0];
                }
                @Override public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
            };
            SSLContext ctx = SSLContext.getInstance("TLS");
            ctx.init(null, new TrustManager[]{capture}, null);
            SSLSocketFactory f = ctx.getSocketFactory();
            try (java.net.Socket raw = new java.net.Socket(Proxy.NO_PROXY)) {
                raw.connect(new InetSocketAddress(host, port), 8000);
                raw.setSoTimeout(8000);
                try (SSLSocket s = (SSLSocket) f.createSocket(raw, host, port, true)) {
                    s.startHandshake();
                }
            }
            if (seen[0] == null) return obj(err("tls", "Der Server liefert kein Zertifikat.", null));
            JSONObject info = describe(seen[0]);
            info.put("trusted", systemTrusts(seen[0], host));
            return info;
        } catch (Exception e) {
            return classify(e, null);
        }
    }

    private static boolean systemTrusts(X509Certificate c, String host) {
        try {
            X509TrustManager tm = trustManager("", new X509Certificate[1]);
            tm.checkServerTrusted(new X509Certificate[]{c}, "ECDHE_RSA");
            return matchesHost(c, host);
        } catch (Exception e) {
            return false;
        }
    }

    private static boolean matchesHost(X509Certificate c, String host) {
        try {
            Collection<List<?>> sans = c.getSubjectAlternativeNames();
            if (sans == null) return false;
            for (List<?> san : sans) {
                if (san.size() > 1 && host.equalsIgnoreCase(String.valueOf(san.get(1)))) return true;
            }
        } catch (Exception ignored) { }
        return false;
    }

    /* ---------- Hilfen ---------- */

    static JSONObject describe(X509Certificate c) throws JSONException {
        JSONObject o = new JSONObject();
        try {
            o.put("fingerprint", fingerprint(c));
        } catch (CertificateException e) {
            o.put("fingerprint", "");
        }
        o.put("subject", c.getSubjectX500Principal().getName());
        o.put("issuer", c.getIssuerX500Principal().getName());
        o.put("notBefore", iso(c.getNotBefore().getTime()));
        o.put("notAfter", iso(c.getNotAfter().getTime()));
        o.put("selfSigned", c.getSubjectX500Principal().equals(c.getIssuerX500Principal()));
        JSONArray sans = new JSONArray();
        try {
            Collection<List<?>> list = c.getSubjectAlternativeNames();
            if (list != null) for (List<?> san : list) if (san.size() > 1) sans.put(String.valueOf(san.get(1)));
        } catch (Exception ignored) { }
        o.put("sans", sans);
        return o;
    }

    private static String iso(long ms) {
        java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.ROOT);
        f.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
        return f.format(new java.util.Date(ms));
    }

    static String fingerprint(X509Certificate c) throws CertificateException {
        try {
            byte[] d = MessageDigest.getInstance("SHA-256").digest(c.getEncoded());
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format(Locale.ROOT, "%02x", b));
            return sb.toString();
        } catch (java.security.NoSuchAlgorithmException e) {
            throw new CertificateException(e);
        }
    }

    static String normFp(String s) {
        StringBuilder sb = new StringBuilder();
        for (char ch : s.toLowerCase(Locale.ROOT).toCharArray()) {
            if ((ch >= '0' && ch <= '9') || (ch >= 'a' && ch <= 'f')) sb.append(ch);
        }
        return sb.toString();
    }

    private static String stripBrackets(String h) {
        if (h == null) return "";
        h = h.trim();
        if (h.startsWith("[") && h.endsWith("]")) h = h.substring(1, h.length() - 1);
        return h;
    }

    /** localhost, Loopback, private Netze (10/8, 172.16/12, 192.168/16, fc00::/7) und link-local. Nur IP-Literale, keine Namensauflösung. */
    static boolean isPrivate(String host) {
        if (host.equalsIgnoreCase("localhost")) return true;
        if (!host.matches("[0-9.]+") && !host.contains(":")) return false; // Namen nie als „lokal“ werten
        try {
            InetAddress a = InetAddress.getByName(host);
            byte[] b = a.getAddress();
            if (a.isLoopbackAddress() || a.isSiteLocalAddress() || a.isLinkLocalAddress()) return true;
            return b.length == 16 && (b[0] & 0xfe) == 0xfc; // fc00::/7 (ULA, enthält fd00::/8)
        } catch (Exception e) {
            return false;
        }
    }

    private static boolean allowedHeader(String k) {
        for (String a : ALLOWED_HEADERS) if (a.equalsIgnoreCase(k)) return true;
        return false;
    }

    private static String readAll(InputStream is) throws IOException {
        try (InputStream in = is; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[16384];
            int n, total = 0;
            while ((n = in.read(buf)) > 0) {
                total += n;
                if (total > MAX_BODY) throw new IOException("Antwort zu groß");
                out.write(buf, 0, n);
            }
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    private static String err(String code, String detail, X509Certificate cert) {
        try {
            JSONObject o = new JSONObject();
            o.put("error", code);
            if (detail != null) o.put("detail", detail);
            if (cert != null) o.put("cert", describe(cert));
            return o.toString();
        } catch (JSONException e) {
            return "{\"error\":\"" + code + "\"}";
        }
    }

    private static JSONObject obj(String json) throws JSONException { return new JSONObject(json); }
}
