package de.schadwagen.protokoll;

import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.json.JSONObject;

/**
 * Lädt die Web-App (assets/www) in einer WebView und stellt ihr native Funktionen bereit:
 * PDF teilen, PDF speichern, Fotos aus Kamera/Galerie wählen.
 */
public class MainActivity extends AppCompatActivity {

    private static final String START_URL = "https://appassets.androidplatform.net/assets/www/index.html";

    private WebView webView;
    /** Netzwerkzugriff für IP-Verbindungen/eigene Zertifikate (NetBridge) – nie auf dem UI-Thread */
    private final ExecutorService net = Executors.newFixedThreadPool(3);
    private ValueCallback<Uri[]> fileCallback;
    private Uri cameraUri;

    private final ActivityResultLauncher<Intent> fileChooser =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (fileCallback == null) return;
                Uri[] uris = null;
                Intent data = result.getData();
                if (result.getResultCode() == RESULT_OK) {
                    List<Uri> list = new ArrayList<>();
                    if (data != null && data.getClipData() != null) {
                        for (int i = 0; i < data.getClipData().getItemCount(); i++) {
                            list.add(data.getClipData().getItemAt(i).getUri());
                        }
                    } else if (data != null && data.getData() != null) {
                        list.add(data.getData());
                    } else if (cameraUri != null) {
                        list.add(cameraUri);
                    }
                    if (!list.isEmpty()) uris = list.toArray(new Uri[0]);
                }
                fileCallback.onReceiveValue(uris);
                fileCallback = null;
                cameraUri = null;
            });

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.setBackgroundColor(0xFF121212);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(true);

        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        webView.setWebViewClient(new WebViewClientCompat() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri url = request.getUrl();
                if ("appassets.androidplatform.net".equals(url.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, url));
                } catch (Exception ignored) {
                }
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
                    pick.addCategory(Intent.CATEGORY_OPENABLE);
                    pick.setType("image/*");
                    pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);

                    Intent chooser = Intent.createChooser(pick, "Foto hinzufügen");
                    Intent camera = cameraIntent();
                    if (camera != null) chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{camera});
                    fileChooser.launch(chooser);
                    return true;
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
            }
        });

        webView.addJavascriptInterface(new Bridge(), "AndroidBridge");

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                webView.evaluateJavascript("window.__handleBack ? window.__handleBack() : false", value -> {
                    if (!"true".equals(value)) {
                        setEnabled(false);
                        getOnBackPressedDispatcher().onBackPressed();
                        setEnabled(true);
                    }
                });
            }
        });

        if (savedInstanceState != null) webView.restoreState(savedInstanceState);
        else webView.loadUrl(START_URL);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        webView.saveState(outState);
    }

    private Intent cameraIntent() {
        Intent capture = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        try {
            File dir = new File(getCacheDir(), "camera");
            if (!dir.exists() && !dir.mkdirs()) return null;
            File photo = new File(dir, "foto_" + System.currentTimeMillis() + ".jpg");
            cameraUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", photo);
            capture.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
            capture.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            return capture;
        } catch (Exception e) {
            cameraUri = null;
            return null;
        }
    }

    /** Dateiname ohne Endungszwang (für ZIP/JSON-Exporte). */
    private static String safeFileName(String name) {
        String n = name == null ? "" : name.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]+", " ").trim();
        return n.isEmpty() ? "Export.zip" : n;
    }

    private static String safeName(String name) {
        String n = name == null ? "Schadensprotokoll.pdf" : name.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]+", " ").trim();
        if (n.isEmpty()) n = "Schadensprotokoll.pdf";
        return n.toLowerCase().endsWith(".pdf") ? n : n + ".pdf";
    }

    /** Von JavaScript aus erreichbar als window.AndroidBridge */
    private class Bridge {

        @JavascriptInterface
        public boolean isAvailable() {
            return true;
        }

        /** PDF über das Android-Teilen-Menü senden (E-Mail, Messenger, Drive …). */
        @JavascriptInterface
        public void sharePdf(String base64, String filename, String title) {
            try {
                File dir = new File(getCacheDir(), "pdf");
                if (!dir.exists() && !dir.mkdirs()) throw new IOException("Cache nicht beschreibbar");
                File file = new File(dir, safeName(filename));
                try (FileOutputStream out = new FileOutputStream(file)) {
                    out.write(Base64.decode(base64, Base64.DEFAULT));
                }
                Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", file);
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("application/pdf");
                send.putExtra(Intent.EXTRA_STREAM, uri);
                send.putExtra(Intent.EXTRA_SUBJECT, title);
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                runOnUiThread(() -> startActivity(Intent.createChooser(send, title)));
            } catch (Exception e) {
                toast("Teilen fehlgeschlagen: " + e.getMessage());
            }
        }

        /** Server-Anfrage über die App (IP-Verbindung, eigenes Zertifikat mit Fingerabdruck). Antwort per window.__nativeNet(id, json). */
        @JavascriptInterface
        public void httpRequest(String id, String json) {
            net.execute(() -> deliver(id, NetBridge.request(json)));
        }

        /** Zertifikat eines https-Servers abrufen (Fingerabdruck zum Bestätigen). */
        @JavascriptInterface
        public void certProbe(String id, String json) {
            net.execute(() -> deliver(id, NetBridge.probe(json)));
        }

        /** Geheimnisse (API-Token, Sitzung) aus dem Android-Schlüsselspeicher. */
        @JavascriptInterface
        public String secretGet(String name) {
            return secrets().get(name);
        }

        @JavascriptInterface
        public void secretSet(String name, String value) {
            if (!secrets().set(name, value)) toast("Sichere Ablage nicht verfügbar");
        }

        /** Text in die Zwischenablage (z. B. E-Mail-Adresse). */
        @JavascriptInterface
        public void copyText(String text) {
            runOnUiThread(() -> {
                android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(android.content.ClipData.newPlainText("E-Mail", text));
            });
        }

        /** PDF mit einem installierten Betrachter öffnen (ohne Betrachter: Teilen-Menü). */
        @JavascriptInterface
        public void openPdf(String base64, String filename) {
            try {
                File dir = new File(getCacheDir(), "pdf");
                if (!dir.exists() && !dir.mkdirs()) throw new IOException("Cache nicht beschreibbar");
                File file = new File(dir, safeName(filename));
                try (FileOutputStream out = new FileOutputStream(file)) {
                    out.write(Base64.decode(base64, Base64.DEFAULT));
                }
                Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", file);
                Intent view = new Intent(Intent.ACTION_VIEW);
                view.setDataAndType(uri, "application/pdf");
                view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                runOnUiThread(() -> {
                    try {
                        startActivity(view);
                    } catch (android.content.ActivityNotFoundException e) {
                        startActivity(Intent.createChooser(view, file.getName()));
                    }
                });
            } catch (Exception e) {
                toast("Öffnen fehlgeschlagen: " + e.getMessage());
            }
        }

        /** PDF dauerhaft speichern: Android 10+ in Download/Schadensprotokolle, sonst im App-Dokumentenordner. */
        /** Beliebige Datei (z. B. ZIP-Export der Vorlagen) unter Download/Schadensprotokolle ablegen. */
        @JavascriptInterface
        public String saveFile(String base64, String filename, String mime) {
            byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
            String name = safeFileName(filename);
            String type = (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime;
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ContentResolver resolver = getContentResolver();
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                    values.put(MediaStore.MediaColumns.MIME_TYPE, type);
                    values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Schadensprotokolle");
                    Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new IOException("Datei konnte nicht angelegt werden");
                    try (OutputStream out = resolver.openOutputStream(uri)) {
                        if (out == null) throw new IOException("Datei konnte nicht geöffnet werden");
                        out.write(bytes);
                    }
                    return "Download/Schadensprotokolle/" + name;
                } else {
                    File dir = new File(getExternalFilesDir(null), "Documents");
                    if (!dir.exists() && !dir.mkdirs()) throw new IOException("Ordner nicht beschreibbar");
                    File file = new File(dir, name);
                    try (FileOutputStream out = new FileOutputStream(file)) {
                        out.write(bytes);
                    }
                    return file.getAbsolutePath();
                }
            } catch (Exception e) {
                toast("Speichern fehlgeschlagen: " + e.getMessage());
                return "";
            }
        }

        @JavascriptInterface
        public String savePdf(String base64, String filename) {
            byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
            String name = safeName(filename);
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ContentResolver resolver = getContentResolver();
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                    values.put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf");
                    values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Schadensprotokolle");
                    Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new IOException("Datei konnte nicht angelegt werden");
                    try (OutputStream out = resolver.openOutputStream(uri)) {
                        if (out == null) throw new IOException("Datei konnte nicht geöffnet werden");
                        out.write(bytes);
                    }
                    return "Download/Schadensprotokolle/" + name;
                } else {
                    File dir = new File(getExternalFilesDir(null), "Documents");
                    if (!dir.exists() && !dir.mkdirs()) throw new IOException("Ordner nicht beschreibbar");
                    File file = new File(dir, name);
                    try (FileOutputStream out = new FileOutputStream(file)) {
                        out.write(bytes);
                    }
                    return file.getAbsolutePath();
                }
            } catch (Exception e) {
                toast("Speichern fehlgeschlagen: " + e.getMessage());
                return "";
            }
        }
    }

    private SecretStore secretStore;

    private synchronized SecretStore secrets() {
        if (secretStore == null) secretStore = new SecretStore(getApplicationContext());
        return secretStore;
    }

    @Override
    protected void onDestroy() {
        net.shutdownNow();
        super.onDestroy();
    }

    private void deliver(String id, String json) {
        String js = "window.__nativeNet && window.__nativeNet(" + JSONObject.quote(id) + "," + JSONObject.quote(json) + ")";
        runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript(js, null); });
    }

    private void toast(String msg) {
        runOnUiThread(() -> Toast.makeText(this, msg, Toast.LENGTH_LONG).show());
    }
}
