// Package tlsutil: https für den Betrieb per IP-Adresse – eigenes Zertifikat laden oder ein
// selbst ausgestelltes erzeugen (und dauerhaft wiederverwenden, damit der Fingerabdruck gleich bleibt).
package tlsutil

import (
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/sha256"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/hex"
	"encoding/pem"
	"fmt"
	"math/big"
	"net"
	"os"
	"path/filepath"
	"strings"
	"time"
)

// Fingerprint: SHA-256 über das DER-kodierte Zertifikat, als AB:CD:… (so zeigt es auch die App).
func Fingerprint(der []byte) string {
	sum := sha256.Sum256(der)
	h := strings.ToUpper(hex.EncodeToString(sum[:]))
	parts := make([]string, 0, len(h)/2)
	for i := 0; i < len(h); i += 2 {
		parts = append(parts, h[i:i+2])
	}
	return strings.Join(parts, ":")
}

// Load lädt Zertifikat und Schlüssel (PEM) und liefert den Fingerabdruck des ersten Zertifikats.
func Load(certFile, keyFile string) (tls.Certificate, string, error) {
	c, err := tls.LoadX509KeyPair(certFile, keyFile)
	if err != nil {
		return c, "", err
	}
	return c, Fingerprint(c.Certificate[0]), nil
}

// LocalAddresses: alle Adressen dieses Rechners (für die Namen im Zertifikat).
func LocalAddresses() []string {
	out := []string{"localhost", "127.0.0.1", "::1"}
	ifs, _ := net.InterfaceAddrs()
	for _, a := range ifs {
		if ipn, ok := a.(*net.IPNet); ok && !ipn.IP.IsLoopback() && !ipn.IP.IsLinkLocalUnicast() {
			out = append(out, ipn.IP.String())
		}
	}
	return out
}

// SelfSigned lädt dir/tls-cert.pem + tls-key.pem oder erzeugt sie (ECDSA P-256, 10 Jahre) für die
// angegebenen Namen/IP-Adressen. Fehlt eine gewünschte Adresse im vorhandenen Zertifikat, wird neu erzeugt.
func SelfSigned(dir string, hosts []string) (tls.Certificate, string, bool, error) {
	certFile, keyFile := filepath.Join(dir, "tls-cert.pem"), filepath.Join(dir, "tls-key.pem")
	if c, fp, err := Load(certFile, keyFile); err == nil {
		if leaf, err := x509.ParseCertificate(c.Certificate[0]); err == nil && covers(leaf, hosts) && time.Until(leaf.NotAfter) > 30*24*time.Hour {
			return c, fp, false, nil
		}
	}
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return tls.Certificate{}, "", false, err
	}
	key, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		return tls.Certificate{}, "", false, err
	}
	serial, _ := rand.Int(rand.Reader, new(big.Int).Lsh(big.NewInt(1), 120))
	tpl := &x509.Certificate{
		SerialNumber:          serial,
		Subject:               pkix.Name{CommonName: "TrainTrace-Server", Organization: []string{"TrainTrace Management"}},
		NotBefore:             time.Now().Add(-time.Hour),
		NotAfter:              time.Now().AddDate(10, 0, 0),
		KeyUsage:              x509.KeyUsageDigitalSignature,
		ExtKeyUsage:           []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth},
		BasicConstraintsValid: true,
	}
	for _, h := range hosts {
		h = strings.Trim(strings.TrimSpace(h), "[]")
		if h == "" {
			continue
		}
		if ip := net.ParseIP(h); ip != nil {
			tpl.IPAddresses = append(tpl.IPAddresses, ip)
		} else {
			tpl.DNSNames = append(tpl.DNSNames, h)
		}
	}
	der, err := x509.CreateCertificate(rand.Reader, tpl, tpl, &key.PublicKey, key)
	if err != nil {
		return tls.Certificate{}, "", false, err
	}
	kb, err := x509.MarshalECPrivateKey(key)
	if err != nil {
		return tls.Certificate{}, "", false, err
	}
	if err := os.WriteFile(keyFile, pem.EncodeToMemory(&pem.Block{Type: "EC PRIVATE KEY", Bytes: kb}), 0o600); err != nil {
		return tls.Certificate{}, "", false, err
	}
	if err := os.WriteFile(certFile, pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: der}), 0o644); err != nil {
		return tls.Certificate{}, "", false, err
	}
	c, fp, err := Load(certFile, keyFile)
	return c, fp, true, err
}

func covers(c *x509.Certificate, hosts []string) bool {
	for _, h := range hosts {
		h = strings.Trim(strings.TrimSpace(h), "[]")
		if h == "" {
			continue
		}
		if c.VerifyHostname(h) != nil {
			return false
		}
	}
	return true
}

// Names: Namen/Adressen eines Zertifikats für die Startmeldung.
func Names(c tls.Certificate) string {
	leaf, err := x509.ParseCertificate(c.Certificate[0])
	if err != nil {
		return ""
	}
	n := append([]string{}, leaf.DNSNames...)
	for _, ip := range leaf.IPAddresses {
		n = append(n, ip.String())
	}
	return strings.Join(n, ", ")
}

// Describe: kurze Startmeldung.
func Describe(c tls.Certificate, fp string) string {
	return fmt.Sprintf("Zertifikat-Fingerabdruck (SHA-256): %s\nGültig für: %s", fp, Names(c))
}
