package tlsutil

import (
	"crypto/sha256"
	"crypto/x509"
	"encoding/hex"
	"strings"
	"testing"
)

func TestSelfSignedReuse(t *testing.T) {
	dir := t.TempDir()
	c1, fp1, created, err := SelfSigned(dir, []string{"192.168.1.20", "fd00::5", "server.lan"})
	if err != nil || !created {
		t.Fatalf("erzeugen: %v %v", err, created)
	}
	leaf, _ := x509.ParseCertificate(c1.Certificate[0])
	for _, h := range []string{"192.168.1.20", "fd00::5", "server.lan"} {
		if leaf.VerifyHostname(h) != nil {
			t.Fatalf("%s fehlt im Zertifikat", h)
		}
	}
	sum := sha256.Sum256(c1.Certificate[0])
	if strings.ReplaceAll(fp1, ":", "") != strings.ToUpper(hex.EncodeToString(sum[:])) {
		t.Fatal("Fingerabdruck falsch")
	}
	// zweiter Start: gleiches Zertifikat, gleicher Fingerabdruck
	_, fp2, created2, err := SelfSigned(dir, []string{"192.168.1.20"})
	if err != nil || created2 || fp2 != fp1 {
		t.Fatalf("wiederverwenden: %v %v %s/%s", err, created2, fp1, fp2)
	}
	// neue Adresse -> neues Zertifikat
	_, fp3, created3, _ := SelfSigned(dir, []string{"10.0.0.9"})
	if !created3 || fp3 == fp1 {
		t.Fatal("neue Adresse sollte neues Zertifikat erzeugen")
	}
}
