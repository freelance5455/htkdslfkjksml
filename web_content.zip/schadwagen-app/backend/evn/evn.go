// Package evn prüft europäische Fahrzeugnummern (EVN, 12 Ziffern) nach dem Luhn-Verfahren.
package evn

import (
	"errors"
	"strings"
)

var (
	ErrLength     = errors.New("die Wagennummer muss genau 12 Ziffern haben")
	ErrCharacters = errors.New("die Wagennummer darf nur Ziffern, Leerzeichen und Bindestriche enthalten")
	ErrCheckDigit = errors.New("die Prüfziffer (12. Stelle) stimmt nicht")
)

// Normalize entfernt Leerzeichen und Bindestriche.
func Normalize(s string) string {
	r := strings.NewReplacer(" ", "", "-", "", " ", "", "\t", "")
	return r.Replace(strings.TrimSpace(s))
}

// CheckDigit berechnet die Prüfziffer aus den Ziffern 1–11:
// abwechselnd ×2 und ×1 (beginnend mit 2), Quersummen addieren, Differenz zum nächsten Zehner.
func CheckDigit(first11 string) int {
	sum := 0
	for i := 0; i < 11; i++ {
		d := int(first11[i] - '0')
		if i%2 == 0 {
			d *= 2
		}
		sum += d/10 + d%10
	}
	return (10 - sum%10) % 10
}

// Validate normalisiert die Eingabe und liefert die 12 Ziffern oder einen Fehler.
func Validate(input string) (string, error) {
	n := Normalize(input)
	for _, c := range n {
		if c < '0' || c > '9' {
			return "", ErrCharacters
		}
	}
	if len(n) != 12 {
		return "", ErrLength
	}
	if CheckDigit(n[:11]) != int(n[11]-'0') {
		return "", ErrCheckDigit
	}
	return n, nil
}

// Format liefert die übliche Schreibweise "33 85 7837 152-2".
func Format(n string) string {
	if len(n) != 12 {
		return n
	}
	return n[0:2] + " " + n[2:4] + " " + n[4:8] + " " + n[8:11] + "-" + n[11:]
}
