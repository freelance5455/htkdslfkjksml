package evn

import "testing"

func TestValidExample(t *testing.T) {
	n, err := Validate("33 85 7837 152-2")
	if err != nil {
		t.Fatalf("33 85 7837 152-2 muss gültig sein: %v", err)
	}
	if n != "338578371522" {
		t.Fatalf("Normalisierung falsch: %s", n)
	}
	if Format(n) != "33 85 7837 152-2" {
		t.Fatalf("Format falsch: %s", Format(n))
	}
}

func TestChangedDigitFails(t *testing.T) {
	base := "338578371522"
	for i := 0; i < 12; i++ {
		b := []byte(base)
		b[i] = '0' + (b[i]-'0'+1)%10 // jede einzelne Ziffer um 1 verändern
		if _, err := Validate(string(b)); err != ErrCheckDigit {
			t.Errorf("geänderte Ziffer an Stelle %d (%s) muss fehlschlagen, Ergebnis: %v", i+1, b, err)
		}
	}
}

func TestFormatErrors(t *testing.T) {
	cases := map[string]error{
		"33 85 7837 152":     ErrLength,
		"33 85 7837 152-22":  ErrLength,
		"33 85 7837 15A-2":   ErrCharacters,
		"":                   ErrLength,
		"21-81-2471-217-3":   nil,
		" 21 81 2471 217 3 ": nil,
	}
	for in, want := range cases {
		if _, err := Validate(in); err != want {
			t.Errorf("%q: erwartet %v, erhalten %v", in, want, err)
		}
	}
}
