package keeper

import "context"

// GCUBrokerSource ist der Platzhalter für die Halterabfrage über den GCU Broker
// (prod.gcubroker.org, Zugang nur für AVV-Vertragsparteien).
//
// Noch nicht umgesetzt, weil die Schnittstelle nicht öffentlich beschrieben ist. Benötigt vom GCU Bureau
// (gcu@gcubureau.org): Maschinenzugang (API) für die Halterabfrage per EVN, Schnittstellenbeschreibung,
// Anmeldeverfahren (z. B. Client-Zertifikat oder Token) und zulässige Abfragehäufigkeit.
// Sobald das vorliegt, wird nur Lookup hier ausgefüllt – die App bleibt unverändert.
type GCUBrokerSource struct {
	BaseURL string
	Token   string
}

func (s *GCUBrokerSource) Name() string { return "gcu-broker" }

func (s *GCUBrokerSource) Lookup(ctx context.Context, evn string) (*Keeper, error) {
	// TODO: nach Freigabe durch das GCU Bureau implementieren (Anfrage, Antwort -> Keeper).
	return nil, ErrNotConfigured
}

// GCUWagonSearchSource ist der Platzhalter für die öffentliche Wagensuche auf gcubureau.org.
//
// Bewusst nicht implementiert: Nutzungsbedingungen, die eine automatisierte Abfrage erlauben, sind nicht
// veröffentlicht. Nur mit schriftlicher Erlaubnis des GCU Bureau umsetzen; keine Captchas, Logins oder
// Abfragegrenzen umgehen.
type GCUWagonSearchSource struct{}

func (s *GCUWagonSearchSource) Name() string { return "gcu-wagon-search" }

func (s *GCUWagonSearchSource) Lookup(ctx context.Context, evn string) (*Keeper, error) {
	return nil, ErrNotConfigured
}
