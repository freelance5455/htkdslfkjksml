package keeper

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"time"
)

// FileSource liest Halterdaten aus einer JSON-Datei {"<12 Ziffern>": {Keeper}, …}.
// Gedacht für Tests, Vorführung und eine eigene Liste regelmäßig genutzter Wagen.
type FileSource struct {
	data map[string]Keeper
}

func NewFileSource(path string) (*FileSource, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	m := map[string]Keeper{}
	if err := json.Unmarshal(raw, &m); err != nil {
		return nil, fmt.Errorf("%s: %w", path, err)
	}
	return &FileSource{data: m}, nil
}

func (s *FileSource) Name() string { return "datei" }

func (s *FileSource) Lookup(ctx context.Context, evn string) (*Keeper, error) {
	k, ok := s.data[evn]
	if !ok {
		return nil, ErrNotFound
	}
	k.Source = s.Name()
	k.RetrievedAt = time.Now().UTC()
	return &k, nil
}
