// Package keeper ermittelt den Halter eines Güterwagens über austauschbare Datenquellen.
package keeper

import (
	"context"
	"errors"
	"strings"
	"time"
)

// Keeper entspricht KeeperInformation aus vehicleinfo_2.0.xsd (ERA).
type Keeper struct {
	Code        string    `json:"code"`        // OrganisationCode (4-stelliger Unternehmenscode / VKM-Nummer)
	Name        string    `json:"name"`        // OrganisationName
	Street      string    `json:"street"`      // StreetAndNumber
	ZipCode     string    `json:"zipCode"`     // ZipCode
	Town        string    `json:"town"`        // Town
	CountryCode string    `json:"countryCode"` // CountryCode (ISO 3166-1 alpha-2)
	Email       string    `json:"email"`       // Email
	Source      string    `json:"source"`
	RetrievedAt time.Time `json:"retrievedAt"`
}

// Address liefert "Straße, PLZ Ort, Land" für das Feld "Adresse".
func (k Keeper) Address() string {
	town := strings.TrimSpace(strings.TrimSpace(k.ZipCode) + " " + strings.TrimSpace(k.Town))
	parts := []string{}
	for _, p := range []string{k.Street, town, countryName(k.CountryCode)} {
		if p = strings.TrimSpace(p); p != "" {
			parts = append(parts, p)
		}
	}
	return strings.Join(parts, ", ")
}

// Fehlerfälle, die die App unterscheidet.
var (
	ErrNotFound      = errors.New("wagen nicht gefunden")
	ErrUnavailable   = errors.New("datenquelle nicht erreichbar")
	ErrNotConfigured = errors.New("datenquelle nicht eingerichtet")
)

// Source ist der austauschbare Adapter (GCU Broker, ERA-Register, Datei …).
type Source interface {
	Name() string
	Lookup(ctx context.Context, evn string) (*Keeper, error)
}

var countries = map[string]string{
	"DE": "Deutschland", "AT": "Österreich", "CH": "Schweiz", "FR": "Frankreich", "IT": "Italien",
	"NL": "Niederlande", "BE": "Belgien", "LU": "Luxemburg", "PL": "Polen", "CZ": "Tschechien",
	"SK": "Slowakei", "HU": "Ungarn", "DK": "Dänemark", "SE": "Schweden", "NO": "Norwegen",
	"FI": "Finnland", "ES": "Spanien", "PT": "Portugal", "SI": "Slowenien", "HR": "Kroatien",
	"RO": "Rumänien", "BG": "Bulgarien", "GB": "Vereinigtes Königreich", "IE": "Irland",
	"LT": "Litauen", "LV": "Lettland", "EE": "Estland", "GR": "Griechenland", "RS": "Serbien",
}

func countryName(code string) string {
	c := strings.ToUpper(strings.TrimSpace(code))
	if n, ok := countries[c]; ok {
		return n
	}
	return c
}
