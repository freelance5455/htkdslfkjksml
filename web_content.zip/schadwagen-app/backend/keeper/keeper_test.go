package keeper

import (
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"os"
	"testing"
)

func TestParseKeeperXML(t *testing.T) {
	data, err := os.ReadFile("../testdata/vehicleinfo_sample.xml")
	if err != nil {
		t.Fatal(err)
	}
	k, err := ParseKeeperXML(data)
	if err != nil {
		t.Fatal(err)
	}
	if k.Code != "9999" || k.Name != "Beispiel Wagenvermietung AG" || k.Email != "schadwagen@example.org" {
		t.Fatalf("falsch gelesen: %+v", k)
	}
	if got := k.Address(); got != "Musterstrasse 1, 8000 Zürich, Schweiz" {
		t.Fatalf("Adresse: %q", got)
	}
}

func TestERASourceStatusCodes(t *testing.T) {
	sample, _ := os.ReadFile("../testdata/vehicleinfo_sample.xml")
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/v/338578371522":
			if r.Header.Get("Authorization") != "Bearer x" {
				w.WriteHeader(401)
				return
			}
			_, _ = w.Write(sample)
		case "/v/218124712173":
			w.WriteHeader(404)
		default:
			w.WriteHeader(500)
		}
	}))
	defer ts.Close()
	s := &ERASource{URLTemplate: ts.URL + "/v/{evn}", Header: map[string]string{"Authorization": "Bearer x"}}
	if k, err := s.Lookup(context.Background(), "338578371522"); err != nil || k.Code != "9999" || k.Source != "era-register" {
		t.Fatalf("Treffer erwartet: %+v %v", k, err)
	}
	if _, err := s.Lookup(context.Background(), "218124712173"); !errors.Is(err, ErrNotFound) {
		t.Fatalf("nicht gefunden erwartet: %v", err)
	}
	if _, err := s.Lookup(context.Background(), "111111111116"); !errors.Is(err, ErrUnavailable) {
		t.Fatalf("nicht erreichbar erwartet: %v", err)
	}
	ts.Close()
	if _, err := s.Lookup(context.Background(), "338578371522"); !errors.Is(err, ErrUnavailable) {
		t.Fatalf("Server weg -> nicht erreichbar erwartet: %v", err)
	}
	if _, err := (&ERASource{}).Lookup(context.Background(), "338578371522"); !errors.Is(err, ErrNotConfigured) {
		t.Fatalf("ohne URL -> nicht eingerichtet erwartet: %v", err)
	}
}

func TestChainAndPlaceholders(t *testing.T) {
	fs, err := NewFileSource("../testdata/keepers.example.json")
	if err != nil {
		t.Fatal(err)
	}
	c := Chain{&GCUBrokerSource{}, fs}
	if k, err := c.Lookup(context.Background(), "338578371522"); err != nil || k.Source != "datei" {
		t.Fatalf("Datei-Treffer erwartet: %+v %v", k, err)
	}
	if _, err := c.Lookup(context.Background(), "218124712173"); !errors.Is(err, ErrNotFound) {
		t.Fatalf("nicht gefunden erwartet: %v", err)
	}
	if _, err := (Chain{&GCUBrokerSource{}, &GCUWagonSearchSource{}}).Lookup(context.Background(), "338578371522"); !errors.Is(err, ErrNotConfigured) {
		t.Fatalf("nur Platzhalter -> nicht eingerichtet erwartet: %v", err)
	}
}
