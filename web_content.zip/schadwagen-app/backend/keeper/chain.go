package keeper

import (
	"context"
	"errors"
	"sync"
	"time"
)

// Chain fragt mehrere Quellen nacheinander ab (z. B. erst eigene Datei, dann Register).
type Chain []Source

func (c Chain) Name() string { return "kette" }

func (c Chain) Lookup(ctx context.Context, evn string) (*Keeper, error) {
	var last error = ErrNotConfigured
	notFound := false
	for _, s := range c {
		k, err := s.Lookup(ctx, evn)
		if err == nil {
			return k, nil
		}
		if errors.Is(err, ErrNotFound) {
			notFound = true
		} else if !errors.Is(err, ErrNotConfigured) {
			last = err
		}
	}
	if notFound && !errors.Is(last, ErrUnavailable) {
		return nil, ErrNotFound
	}
	return nil, last
}

// Cached speichert Treffer serverseitig zwischen, um die Quelle zu schonen.
type Cached struct {
	Source Source
	TTL    time.Duration
	mu     sync.Mutex
	items  map[string]cacheItem
}

type cacheItem struct {
	k   *Keeper
	exp time.Time
}

func (c *Cached) Name() string { return c.Source.Name() }

func (c *Cached) Lookup(ctx context.Context, evn string) (*Keeper, error) {
	c.mu.Lock()
	if it, ok := c.items[evn]; ok && time.Now().Before(it.exp) {
		c.mu.Unlock()
		k := *it.k
		return &k, nil
	}
	c.mu.Unlock()
	k, err := c.Source.Lookup(ctx, evn)
	if err != nil {
		return nil, err
	}
	c.mu.Lock()
	if c.items == nil {
		c.items = map[string]cacheItem{}
	}
	c.items[evn] = cacheItem{k: k, exp: time.Now().Add(c.TTL)}
	c.mu.Unlock()
	return k, nil
}
