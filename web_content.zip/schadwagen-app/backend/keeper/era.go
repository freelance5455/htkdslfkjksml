package keeper

import (
	"context"
	"encoding/xml"
	"fmt"
	"io"
	"net/http"
	"strings"
	"time"
)

// ERASource fragt ein Fahrzeugregister ab, das Antworten nach vehicleinfo_2.0.xsd liefert
// (KeeperInformation: OrganisationCode, OrganisationName, StreetAndNumber, ZipCode, Town,
// CountryCode, Email). Adresse und Anmeldung kommen aus der Konfiguration, sobald der Zugang besteht.
type ERASource struct {
	URLTemplate string            // z. B. https://register.example/vehicles/{evn} – {evn} wird ersetzt
	Header      map[string]string // z. B. Authorization: Bearer …
	Client      *http.Client
}

func (s *ERASource) Name() string { return "era-register" }

func (s *ERASource) Lookup(ctx context.Context, evn string) (*Keeper, error) {
	if s.URLTemplate == "" {
		return nil, ErrNotConfigured
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, strings.ReplaceAll(s.URLTemplate, "{evn}", evn), nil)
	if err != nil {
		return nil, fmt.Errorf("%w: %v", ErrNotConfigured, err)
	}
	req.Header.Set("Accept", "application/xml")
	for k, v := range s.Header {
		req.Header.Set(k, v)
	}
	client := s.Client
	if client == nil {
		client = &http.Client{Timeout: 10 * time.Second}
	}
	res, err := client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("%w: %v", ErrUnavailable, err)
	}
	defer res.Body.Close()
	switch {
	case res.StatusCode == http.StatusNotFound:
		return nil, ErrNotFound
	case res.StatusCode >= 300:
		return nil, fmt.Errorf("%w: HTTP %d", ErrUnavailable, res.StatusCode)
	}
	body, err := io.ReadAll(io.LimitReader(res.Body, 2<<20))
	if err != nil {
		return nil, fmt.Errorf("%w: %v", ErrUnavailable, err)
	}
	k, err := ParseKeeperXML(body)
	if err != nil {
		return nil, err
	}
	k.Source = s.Name()
	k.RetrievedAt = time.Now().UTC()
	return k, nil
}

// ParseKeeperXML sucht das erste Element KeeperInformation (unabhängig vom Namensraum).
func ParseKeeperXML(data []byte) (*Keeper, error) {
	dec := xml.NewDecoder(strings.NewReader(string(data)))
	for {
		tok, err := dec.Token()
		if err == io.EOF {
			return nil, ErrNotFound
		}
		if err != nil {
			return nil, fmt.Errorf("%w: ungültige XML-Antwort: %v", ErrUnavailable, err)
		}
		se, ok := tok.(xml.StartElement)
		if !ok || se.Name.Local != "KeeperInformation" {
			continue
		}
		var ki struct {
			OrganisationCode string `xml:"OrganisationCode"`
			OrganisationName string `xml:"OrganisationName"`
			StreetAndNumber  string `xml:"StreetAndNumber"`
			ZipCode          string `xml:"ZipCode"`
			Town             string `xml:"Town"`
			CountryCode      string `xml:"CountryCode"`
			Email            string `xml:"Email"`
		}
		if err := dec.DecodeElement(&ki, &se); err != nil {
			return nil, fmt.Errorf("%w: %v", ErrUnavailable, err)
		}
		k := &Keeper{
			Code: strings.TrimSpace(ki.OrganisationCode), Name: strings.TrimSpace(ki.OrganisationName),
			Street: strings.TrimSpace(ki.StreetAndNumber), ZipCode: strings.TrimSpace(ki.ZipCode),
			Town: strings.TrimSpace(ki.Town), CountryCode: strings.TrimSpace(ki.CountryCode),
			Email: strings.TrimSpace(ki.Email),
		}
		if k.Code == "" && k.Name == "" {
			return nil, ErrNotFound
		}
		return k, nil
	}
}
