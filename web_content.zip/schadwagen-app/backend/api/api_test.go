package api

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"

	"schadwagen/backend/keeper"
)

func get(t *testing.T, h http.Handler, path string, hdr map[string]string) (int, response) {
	req := httptest.NewRequest(http.MethodGet, path, nil)
	for k, v := range hdr {
		req.Header.Set(k, v)
	}
	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, req)
	var r response
	_ = json.Unmarshal(rec.Body.Bytes(), &r)
	return rec.Code, r
}

func TestEndpoint(t *testing.T) {
	fs, err := keeper.NewFileSource("../testdata/keepers.example.json")
	if err != nil {
		t.Fatal(err)
	}
	h := (&Server{Source: keeper.Chain{fs}, AllowedOrigins: []string{"https://appassets.androidplatform.net"}}).Handler()

	code, r := get(t, h, "/api/keeper/33%2085%207837%20152-2", nil)
	if code != 200 || r.Keeper == nil || r.Keeper.Code != "9999" || r.Keeper.Address != "Musterstrasse 1, 8000 Zürich, Schweiz" || r.Formatted != "33 85 7837 152-2" {
		t.Fatalf("Treffer erwartet: %d %+v", code, r)
	}
	if code, r = get(t, h, "/api/keeper/338578371523", nil); code != 400 || r.Error != "invalid_evn" {
		t.Fatalf("ungültige Nummer erwartet: %d %+v", code, r)
	}
	if code, r = get(t, h, "/api/keeper/218124712173", nil); code != 404 || r.Error != "not_found" {
		t.Fatalf("nicht gefunden erwartet: %d %+v", code, r)
	}
	h2 := (&Server{Source: keeper.Chain{&keeper.GCUBrokerSource{}}}).Handler()
	if code, r = get(t, h2, "/api/keeper/338578371522", nil); code != 503 || r.Error != "not_configured" {
		t.Fatalf("nicht eingerichtet erwartet: %d %+v", code, r)
	}
	h3 := (&Server{Source: keeper.Chain{&keeper.ERASource{URLTemplate: "http://127.0.0.1:1/{evn}"}}}).Handler()
	if code, r = get(t, h3, "/api/keeper/338578371522", nil); code != 502 || r.Error != "source_unavailable" {
		t.Fatalf("nicht erreichbar erwartet: %d %+v", code, r)
	}
	h4 := (&Server{Source: keeper.Chain{fs}, APIKey: "geheim"}).Handler()
	if code, _ = get(t, h4, "/api/keeper/338578371522", nil); code != 401 {
		t.Fatalf("ohne Schlüssel 401 erwartet: %d", code)
	}
	if code, _ = get(t, h4, "/api/keeper/338578371522", map[string]string{"X-Api-Key": "geheim"}); code != 200 {
		t.Fatalf("mit Schlüssel 200 erwartet: %d", code)
	}
	// CORS für die Android-App
	req := httptest.NewRequest(http.MethodOptions, "/api/keeper/338578371522", nil)
	req.Header.Set("Origin", "https://appassets.androidplatform.net")
	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, req)
	if rec.Header().Get("Access-Control-Allow-Origin") != "https://appassets.androidplatform.net" {
		t.Fatal("CORS-Header fehlt")
	}
}

func TestRateLimit(t *testing.T) {
	fs, _ := keeper.NewFileSource("../testdata/keepers.example.json")
	h := (&Server{Source: keeper.Chain{fs}, RatePerMinute: 2}).Handler()
	get(t, h, "/api/keeper/338578371522", nil)
	get(t, h, "/api/keeper/338578371522", nil)
	if code, r := get(t, h, "/api/keeper/338578371522", nil); code != 429 || r.Error != "rate_limited" {
		t.Fatalf("429 erwartet: %d", code)
	}
}
