package api

import (
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"sync"
	"time"
)

// FileStore legt Protokolle, Mitarbeiter und Sitzungen als JSON-Dateien in einem Ordner ab.
type FileStore struct {
	Dir string
	mu  sync.Mutex
}

// ProtocolMeta: Kopfdaten eines Protokolls für Listen und Zuordnung.
type ProtocolMeta struct {
	ID           string          `json:"id"`
	ReportID     string          `json:"reportId"`
	WagonNumber  string          `json:"wagonNumber"`
	PdfCreatedAt string          `json:"pdfCreatedAt,omitempty"`
	UpdatedAt    string          `json:"updatedAt"`
	ReceivedAt   string          `json:"receivedAt"`
	CreatedBy    json.RawMessage `json:"createdBy,omitempty"`
}

type storedProtocol struct {
	Meta   ProtocolMeta    `json:"meta"`
	Report json.RawMessage `json:"report"`
}

var (
	idPattern   = regexp.MustCompile(`^[A-Za-z0-9_-]{1,64}$`)
	ErrBadID    = errors.New("ungültige ID")
	ErrNotFound = errors.New("nicht gefunden")
	ErrOutdated = errors.New("veraltet")
)

func NewFileStore(dir string) (*FileStore, error) {
	if err := os.MkdirAll(filepath.Join(dir, "protocols"), 0o700); err != nil {
		return nil, err
	}
	return &FileStore{Dir: dir}, nil
}

func writeFileAtomic(path string, data []byte) error {
	tmp := path + ".tmp"
	if err := os.WriteFile(tmp, data, 0o600); err != nil {
		return err
	}
	return os.Rename(tmp, path)
}

func (f *FileStore) protocolPath(id string) (string, error) {
	if !idPattern.MatchString(id) {
		return "", ErrBadID
	}
	return filepath.Join(f.Dir, "protocols", id+".json"), nil
}

// PutProtocol speichert ein Protokoll. Ein älterer Stand (updatedAt) als der vorhandene wird abgelehnt.
func (f *FileStore) PutProtocol(meta ProtocolMeta, report json.RawMessage) (ProtocolMeta, error) {
	path, err := f.protocolPath(meta.ID)
	if err != nil {
		return meta, err
	}
	f.mu.Lock()
	defer f.mu.Unlock()
	if old, err := os.ReadFile(path); err == nil {
		var prev storedProtocol
		if json.Unmarshal(old, &prev) == nil && newer(prev.Meta.UpdatedAt, meta.UpdatedAt) {
			return prev.Meta, ErrOutdated
		}
	}
	meta.ReceivedAt = time.Now().UTC().Format(time.RFC3339Nano)
	data, err := json.Marshal(storedProtocol{Meta: meta, Report: report})
	if err != nil {
		return meta, err
	}
	return meta, writeFileAtomic(path, data)
}

// newer: a ist echt neuer als b (RFC3339-Zeitstempel).
func newer(a, b string) bool {
	ta, ea := time.Parse(time.RFC3339Nano, a)
	tb, eb := time.Parse(time.RFC3339Nano, b)
	if ea != nil || eb != nil {
		return a > b
	}
	return ta.After(tb)
}

func (f *FileStore) GetProtocol(id string) (storedProtocol, error) {
	var p storedProtocol
	path, err := f.protocolPath(id)
	if err != nil {
		return p, err
	}
	data, err := os.ReadFile(path)
	if errors.Is(err, os.ErrNotExist) {
		return p, ErrNotFound
	}
	if err != nil {
		return p, err
	}
	return p, json.Unmarshal(data, &p)
}

// ListProtocols liefert die Kopfdaten, optional nur seit einem Zeitpunkt empfangene.
func (f *FileStore) ListProtocols(since time.Time) ([]ProtocolMeta, error) {
	entries, err := os.ReadDir(filepath.Join(f.Dir, "protocols"))
	if err != nil {
		return nil, err
	}
	out := []ProtocolMeta{}
	for _, e := range entries {
		if e.IsDir() || filepath.Ext(e.Name()) != ".json" {
			continue
		}
		data, err := os.ReadFile(filepath.Join(f.Dir, "protocols", e.Name()))
		if err != nil {
			continue
		}
		var p struct {
			Meta ProtocolMeta `json:"meta"`
		}
		if json.Unmarshal(data, &p) != nil {
			continue
		}
		if !since.IsZero() {
			if t, err := time.Parse(time.RFC3339Nano, p.Meta.ReceivedAt); err == nil && !t.After(since) {
				continue
			}
		}
		out = append(out, p.Meta)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].ReceivedAt > out[j].ReceivedAt })
	return out, nil
}

/* ---------- Mitarbeiter ---------- */

type employeeList struct {
	Employees []map[string]any `json:"employees"`
	UpdatedAt string           `json:"updatedAt"`
}

func (f *FileStore) employeesPath() string { return filepath.Join(f.Dir, "employees.json") }

func (f *FileStore) loadEmployees() (employeeList, error) {
	var l employeeList
	data, err := os.ReadFile(f.employeesPath())
	if errors.Is(err, os.ErrNotExist) {
		return employeeList{Employees: []map[string]any{}}, nil
	}
	if err != nil {
		return l, err
	}
	err = json.Unmarshal(data, &l)
	if l.Employees == nil {
		l.Employees = []map[string]any{}
	}
	return l, err
}

func (f *FileStore) Employees() (employeeList, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	return f.loadEmployees()
}

// MergeEmployees gleicht die Liste ab: je ID gewinnt der neueste Stand (updatedAt),
// die laufende Nummer (nextNumber) wird nie verringert. Gelöschte Einträge bleiben als
// Markierung (deleted) erhalten, damit das Löschen auf allen Geräten ankommt.
func (f *FileStore) MergeEmployees(in []map[string]any) (employeeList, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	cur, err := f.loadEmployees()
	if err != nil {
		return cur, err
	}
	byID := map[string]map[string]any{}
	order := []string{}
	for _, e := range cur.Employees {
		id, _ := e["id"].(string)
		if id == "" {
			continue
		}
		byID[id] = e
		order = append(order, id)
	}
	for _, e := range in {
		id, _ := e["id"].(string)
		if !idPattern.MatchString(id) {
			continue
		}
		old, ok := byID[id]
		if !ok {
			byID[id] = e
			order = append(order, id)
			continue
		}
		ou, _ := old["updatedAt"].(string)
		nu, _ := e["updatedAt"].(string)
		winner := old
		if newer(nu, ou) {
			winner = e
		}
		on, _ := old["nextNumber"].(float64)
		nn, _ := e["nextNumber"].(float64)
		if nn > on {
			on = nn
		}
		if on > 0 {
			winner["nextNumber"] = on
		}
		byID[id] = winner
	}
	out := employeeList{Employees: make([]map[string]any, 0, len(order)), UpdatedAt: time.Now().UTC().Format(time.RFC3339Nano)}
	for _, id := range order {
		out.Employees = append(out.Employees, byID[id])
	}
	data, err := json.Marshal(out)
	if err != nil {
		return out, err
	}
	return out, writeFileAtomic(f.employeesPath(), data)
}

/* ---------- Sitzungen (nur Hashes) ---------- */

func (f *FileStore) SaveSessions(m map[string]time.Time) error {
	data, err := json.Marshal(m)
	if err != nil {
		return err
	}
	f.mu.Lock()
	defer f.mu.Unlock()
	return writeFileAtomic(filepath.Join(f.Dir, "sessions.json"), data)
}

func (f *FileStore) LoadSessions() map[string]time.Time {
	m := map[string]time.Time{}
	data, err := os.ReadFile(filepath.Join(f.Dir, "sessions.json"))
	if err == nil {
		_ = json.Unmarshal(data, &m)
	}
	now := time.Now()
	for k, e := range m {
		if now.After(e) {
			delete(m, k)
		}
	}
	return m
}
