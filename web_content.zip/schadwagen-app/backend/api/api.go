// Package api: Backend der App „Schadwagen Management“.
//
//	GET  /api/ping               Verbindung und Latenz prüfen (nur API-Token)
//	POST /api/login              Anmeldung mit dem Passwortschlüssel -> Sitzungstoken
//	POST /api/logout             Sitzung beenden
//	GET  /api/session            Status der Sitzung
//	GET  /api/keeper/{evn}       Halter-Abfrage
//	GET  /api/protocols          Liste der Protokolle (?since=RFC3339)
//	GET  /api/protocols/{id}     ein Protokoll
//	PUT  /api/protocols/{id}     Protokoll ablegen (neuester Stand gewinnt)
//	GET  /api/employees          Mitarbeiterliste
//	PUT  /api/employees          Mitarbeiterliste abgleichen (je Eintrag gewinnt der neueste Stand)
//	GET/PUT /api/folders         eigene Ordner der Ansicht „Gespeichert“ abgleichen
//	GET/POST /api/presence       wer arbeitet gerade an welchem Protokoll (nur im Speicher)
package api

import (
	"context"
	"encoding/json"
	"errors"
	"log"
	"net"
	"net/http"
	"strings"
	"sync"
	"time"

	"schadwagen/backend/evn"
	"schadwagen/backend/keeper"
)

type Server struct {
	Source         keeper.Source
	APIKey         string   // optional: Pflicht-Header X-Api-Key
	AllowedOrigins []string // CORS; "*" erlaubt alle
	Timeout        time.Duration
	RatePerMinute  int // Anfragen je Client-IP und Minute (0 = unbegrenzt)

	// Anmeldung: ist einer der beiden Werte gesetzt, brauchen alle Endpunkte außer
	// /api/ping und /api/login eine gültige Sitzung (Authorization: Bearer …).
	LoginPassword       string // Passwortschlüssel im Klartext (Umgebungsvariable)
	LoginPasswordSHA256 string // alternativ: SHA-256 des Passwortschlüssels (hex)
	SessionTTL          time.Duration
	LoginPerWindow      int           // Fehlversuche je IP und Zeitfenster (Standard 10)
	LoginWindow         time.Duration // Standard 15 Minuten

	Store       *FileStore    // Ablage für Protokolle und Mitarbeiter (nil = nicht eingerichtet)
	PresenceTTL time.Duration // Anwesenheit verfällt ohne Meldung (Standard 2 Minuten)
	Version     string

	mu       sync.Mutex
	counts   map[string]*window
	sessions map[string]time.Time
	failed   map[string]*window
	presence map[string]presenceEntry
}

type window struct {
	start time.Time
	n     int
}

type keeperDTO struct {
	Code        string `json:"code"`
	Name        string `json:"name"`
	Street      string `json:"street"`
	ZipCode     string `json:"zipCode"`
	Town        string `json:"town"`
	CountryCode string `json:"countryCode"`
	Address     string `json:"address"`
	Email       string `json:"email"`
}

type response struct {
	EVN         string     `json:"evn"`
	Formatted   string     `json:"formatted,omitempty"`
	Keeper      *keeperDTO `json:"keeper,omitempty"`
	Source      string     `json:"source,omitempty"`
	RetrievedAt *time.Time `json:"retrievedAt,omitempty"`
	Error       string     `json:"error,omitempty"`   // invalid_evn | not_found | source_unavailable | not_configured | ...
	Message     string     `json:"message,omitempty"` // Klartext für die Anzeige
}

func (s *Server) Handler() http.Handler {
	if s.Store != nil && s.sessions == nil {
		s.sessions = s.Store.LoadSessions()
	}
	mux := http.NewServeMux()
	mux.HandleFunc("/api/keeper/", s.handleKeeper)
	mux.HandleFunc("/api/ping", s.handlePing)
	mux.HandleFunc("/api/login", s.handleLogin)
	mux.HandleFunc("/api/logout", s.handleLogout)
	mux.HandleFunc("/api/session", s.handleSession)
	mux.HandleFunc("/api/protocols", s.handleProtocols)
	mux.HandleFunc("/api/protocols/", s.handleProtocol)
	mux.HandleFunc("/api/employees", s.handleEmployees)
	mux.HandleFunc("/api/folders", s.handleFolders)
	mux.HandleFunc("/api/presence", s.handlePresence)
	mux.HandleFunc("/healthz", func(w http.ResponseWriter, r *http.Request) {
		name := "keine"
		if s.Source != nil {
			name = s.Source.Name()
		}
		writeJSON(w, http.StatusOK, map[string]string{"status": "ok", "source": name})
	})
	return s.cors(mux)
}

func (s *Server) cors(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		origin := r.Header.Get("Origin")
		if origin != "" && s.originAllowed(origin) {
			w.Header().Set("Access-Control-Allow-Origin", origin)
			w.Header().Set("Vary", "Origin")
			w.Header().Set("Access-Control-Allow-Methods", "GET, POST, PUT, OPTIONS")
			w.Header().Set("Access-Control-Allow-Headers", "X-Api-Key, Authorization, Content-Type")
			w.Header().Set("Access-Control-Max-Age", "86400")
		}
		if r.Method == http.MethodOptions {
			w.WriteHeader(http.StatusNoContent)
			return
		}
		next.ServeHTTP(w, r)
	})
}

func (s *Server) originAllowed(o string) bool {
	for _, a := range s.AllowedOrigins {
		if a == "*" || strings.EqualFold(a, o) {
			return true
		}
	}
	return false
}

func (s *Server) handleKeeper(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		writeJSON(w, http.StatusMethodNotAllowed, response{Error: "method_not_allowed", Message: "Nur GET ist erlaubt."})
		return
	}
	if !s.authorize(w, r, true) {
		return
	}
	if s.Source == nil {
		writeJSON(w, http.StatusServiceUnavailable, response{Error: "not_configured", Message: "Die Halter-Datenquelle ist noch nicht freigeschaltet."})
		return
	}
	if !s.allow(clientIP(r)) {
		writeJSON(w, http.StatusTooManyRequests, response{Error: "rate_limited", Message: "Zu viele Abfragen – bitte kurz warten."})
		return
	}
	raw := strings.TrimPrefix(r.URL.Path, "/api/keeper/")
	n, err := evn.Validate(raw)
	if err != nil {
		writeJSON(w, http.StatusBadRequest, response{EVN: raw, Error: "invalid_evn", Message: "Ungültige Wagennummer: " + err.Error() + "."})
		return
	}
	timeout := s.Timeout
	if timeout == 0 {
		timeout = 12 * time.Second
	}
	ctx, cancel := context.WithTimeout(r.Context(), timeout)
	defer cancel()
	k, err := s.Source.Lookup(ctx, n)
	resp := response{EVN: n, Formatted: evn.Format(n)}
	switch {
	case err == nil:
		resp.Keeper = &keeperDTO{Code: k.Code, Name: k.Name, Street: k.Street, ZipCode: k.ZipCode, Town: k.Town,
			CountryCode: k.CountryCode, Address: k.Address(), Email: k.Email}
		resp.Source = k.Source
		t := k.RetrievedAt
		resp.RetrievedAt = &t
		writeJSON(w, http.StatusOK, resp)
	case errors.Is(err, keeper.ErrNotFound):
		resp.Error, resp.Message = "not_found", "Zu dieser Wagennummer wurde kein Halter gefunden."
		writeJSON(w, http.StatusNotFound, resp)
	case errors.Is(err, keeper.ErrNotConfigured):
		resp.Error, resp.Message = "not_configured", "Die Halter-Datenquelle ist noch nicht freigeschaltet."
		writeJSON(w, http.StatusServiceUnavailable, resp)
	default:
		log.Printf("Quelle %s, EVN %s: %v", s.Source.Name(), n, err)
		resp.Error, resp.Message = "source_unavailable", "Die Halter-Datenquelle ist nicht erreichbar."
		writeJSON(w, http.StatusBadGateway, resp)
	}
}

func (s *Server) allow(ip string) bool {
	if s.RatePerMinute <= 0 {
		return true
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.counts == nil {
		s.counts = map[string]*window{}
	}
	now := time.Now()
	wnd := s.counts[ip]
	if wnd == nil || now.Sub(wnd.start) > time.Minute {
		wnd = &window{start: now}
		s.counts[ip] = wnd
	}
	wnd.n++
	return wnd.n <= s.RatePerMinute
}

func clientIP(r *http.Request) string {
	if f := r.Header.Get("X-Forwarded-For"); f != "" {
		return strings.TrimSpace(strings.Split(f, ",")[0])
	}
	h, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		return r.RemoteAddr
	}
	return h
}

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}
