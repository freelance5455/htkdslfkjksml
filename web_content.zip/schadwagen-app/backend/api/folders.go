package api

import (
	"encoding/json"
	"errors"
	"net/http"
	"os"
	"path/filepath"
	"time"
)

// Eigene Ordner der Ansicht „Gespeichert“. Die Datumsordner (Jahr › Monat › Tag nach
// „Schaden festgestellt am“) berechnet die App selbst; hier liegen nur die selbst angelegten
// Ordner samt Protokoll-IDs. Je Ordner gewinnt der neueste Stand (updatedAt); gelöschte Ordner
// bleiben als Markierung (deleted), damit das Löschen auf allen Geräten ankommt.

type folderList struct {
	Folders   []map[string]any `json:"folders"`
	UpdatedAt string           `json:"updatedAt"`
}

func (f *FileStore) foldersPath() string { return filepath.Join(f.Dir, "folders.json") }

func (f *FileStore) loadFolders() (folderList, error) {
	var l folderList
	data, err := os.ReadFile(f.foldersPath())
	if errors.Is(err, os.ErrNotExist) {
		return folderList{Folders: []map[string]any{}}, nil
	}
	if err != nil {
		return l, err
	}
	err = json.Unmarshal(data, &l)
	if l.Folders == nil {
		l.Folders = []map[string]any{}
	}
	return l, err
}

// Folders liefert die gespeicherte Ordnerliste.
func (f *FileStore) Folders() (folderList, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	return f.loadFolders()
}

// MergeFolders gleicht die Liste ab und speichert sie.
func (f *FileStore) MergeFolders(in []map[string]any) (folderList, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	cur, err := f.loadFolders()
	if err != nil {
		return cur, err
	}
	byID := map[string]map[string]any{}
	order := []string{}
	for _, e := range cur.Folders {
		if id, _ := e["id"].(string); id != "" {
			byID[id] = e
			order = append(order, id)
		}
	}
	for _, e := range in {
		id, _ := e["id"].(string)
		if !idPattern.MatchString(id) {
			continue
		}
		if name, _ := e["name"].(string); len([]rune(name)) > 60 {
			continue
		}
		old, ok := byID[id]
		if !ok {
			byID[id] = e
			order = append(order, id)
			continue
		}
		ou, _ := old["updatedAt"].(string)
		nu, _ := e["updatedAt"].(string)
		if newer(nu, ou) {
			byID[id] = e
		}
	}
	out := folderList{Folders: make([]map[string]any, 0, len(order)), UpdatedAt: time.Now().UTC().Format(time.RFC3339Nano)}
	for _, id := range order {
		out.Folders = append(out.Folders, byID[id])
	}
	data, err := json.Marshal(out)
	if err != nil {
		return out, err
	}
	return out, writeFileAtomic(f.foldersPath(), data)
}

// GET/PUT /api/folders
func (s *Server) handleFolders(w http.ResponseWriter, r *http.Request) {
	if !s.authorize(w, r, true) || !s.needStore(w) {
		return
	}
	switch r.Method {
	case http.MethodGet:
		l, err := s.Store.Folders()
		if err != nil {
			writeJSON(w, http.StatusInternalServerError, apiError{"internal", "Ablage nicht lesbar."})
			return
		}
		writeJSON(w, http.StatusOK, l)
	case http.MethodPut:
		var body struct {
			Folders []map[string]any `json:"folders"`
		}
		if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 4<<20)).Decode(&body); err != nil {
			writeJSON(w, http.StatusBadRequest, apiError{"bad_request", "Ungültige Ordnerliste."})
			return
		}
		l, err := s.Store.MergeFolders(body.Folders)
		if err != nil {
			writeJSON(w, http.StatusInternalServerError, apiError{"internal", "Ordner konnten nicht gespeichert werden."})
			return
		}
		writeJSON(w, http.StatusOK, l)
	default:
		writeJSON(w, http.StatusMethodNotAllowed, apiError{"method_not_allowed", "Nur GET und PUT sind erlaubt."})
	}
}
