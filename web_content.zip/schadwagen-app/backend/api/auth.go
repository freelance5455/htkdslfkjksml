package api

import (
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/hex"
	"encoding/json"
	"net/http"
	"strings"
	"time"
)

type apiError struct {
	Error   string `json:"error"`
	Message string `json:"message"`
}

func (s *Server) loginRequired() bool {
	return s.LoginPassword != "" || s.LoginPasswordSHA256 != ""
}

func equalConst(a, b string) bool {
	return subtle.ConstantTimeCompare([]byte(a), []byte(b)) == 1
}

func bearer(r *http.Request) string {
	h := r.Header.Get("Authorization")
	if len(h) > 7 && strings.EqualFold(h[:7], "bearer ") {
		return strings.TrimSpace(h[7:])
	}
	return ""
}

// authorize prüft API-Token und – falls eingerichtet und verlangt – die Sitzung.
// Bei Fehlern wird die Antwort geschrieben und false geliefert.
func (s *Server) authorize(w http.ResponseWriter, r *http.Request, needSession bool) bool {
	if s.APIKey != "" && !equalConst(r.Header.Get("X-Api-Key"), s.APIKey) {
		writeJSON(w, http.StatusUnauthorized, apiError{"invalid_token", "API-Token fehlt oder ist falsch."})
		return false
	}
	if needSession && s.loginRequired() && !s.sessionValid(bearer(r)) {
		writeJSON(w, http.StatusUnauthorized, apiError{"login_required", "Bitte mit dem Passwortschlüssel anmelden."})
		return false
	}
	return true
}

func (s *Server) sessionValid(tok string) bool {
	if tok == "" {
		return false
	}
	key := hashToken(tok)
	s.mu.Lock()
	defer s.mu.Unlock()
	exp, ok := s.sessions[key]
	if !ok {
		return false
	}
	if time.Now().After(exp) {
		delete(s.sessions, key)
		return false
	}
	return true
}

// Sitzungen werden nur als Hash gehalten.
func hashToken(t string) string {
	h := sha256.Sum256([]byte(t))
	return hex.EncodeToString(h[:])
}

func (s *Server) passwordOK(pw string) bool {
	if s.LoginPassword != "" {
		return equalConst(pw, s.LoginPassword)
	}
	h := sha256.Sum256([]byte(pw))
	return equalConst(hex.EncodeToString(h[:]), strings.ToLower(strings.TrimSpace(s.LoginPasswordSHA256)))
}

// Fehlversuche je IP begrenzen (Schutz gegen Durchprobieren).
func (s *Server) loginBlocked(ip string) bool {
	limit, wnd := s.LoginPerWindow, s.LoginWindow
	if limit <= 0 {
		limit = 10
	}
	if wnd <= 0 {
		wnd = 15 * time.Minute
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	f := s.failed[ip]
	if f == nil {
		return false
	}
	if time.Since(f.start) > wnd {
		delete(s.failed, ip)
		return false
	}
	return f.n >= limit
}

func (s *Server) loginFailed(ip string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.failed == nil {
		s.failed = map[string]*window{}
	}
	f := s.failed[ip]
	if f == nil {
		f = &window{start: time.Now()}
		s.failed[ip] = f
	}
	f.n++
}

func (s *Server) handlePing(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		writeJSON(w, http.StatusMethodNotAllowed, apiError{"method_not_allowed", "Nur GET ist erlaubt."})
		return
	}
	if !s.authorize(w, r, false) {
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{
		"ok":            true,
		"service":       "schadwagen-backend",
		"version":       s.Version,
		"time":          time.Now().UTC().Format(time.RFC3339Nano),
		"loginRequired": s.loginRequired(),
		"loggedIn":      s.sessionValid(bearer(r)),
		"features":      s.features(),
	})
}

func (s *Server) features() []string {
	f := []string{"presence"}
	if s.Source != nil {
		f = append(f, "keeper")
	}
	if s.Store != nil {
		f = append(f, "protocols", "employees", "folders")
	}
	return f
}

func (s *Server) handleLogin(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeJSON(w, http.StatusMethodNotAllowed, apiError{"method_not_allowed", "Nur POST ist erlaubt."})
		return
	}
	if !s.authorize(w, r, false) {
		return
	}
	if !s.loginRequired() {
		writeJSON(w, http.StatusOK, map[string]any{"ok": true, "loginRequired": false})
		return
	}
	ip := clientIP(r)
	if s.loginBlocked(ip) {
		writeJSON(w, http.StatusTooManyRequests, apiError{"rate_limited", "Zu viele Fehlversuche – bitte später erneut versuchen."})
		return
	}
	var body struct {
		Password string `json:"password"`
	}
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 4096)).Decode(&body); err != nil {
		writeJSON(w, http.StatusBadRequest, apiError{"bad_request", "Ungültige Anfrage."})
		return
	}
	if body.Password == "" || !s.passwordOK(body.Password) {
		s.loginFailed(ip)
		time.Sleep(300 * time.Millisecond)
		writeJSON(w, http.StatusUnauthorized, apiError{"wrong_password", "Passwortschlüssel ist falsch."})
		return
	}
	buf := make([]byte, 32)
	if _, err := rand.Read(buf); err != nil {
		writeJSON(w, http.StatusInternalServerError, apiError{"internal", "Sitzung konnte nicht angelegt werden."})
		return
	}
	tok := hex.EncodeToString(buf)
	ttl := s.SessionTTL
	if ttl <= 0 {
		ttl = 30 * 24 * time.Hour
	}
	exp := time.Now().Add(ttl)
	s.mu.Lock()
	if s.sessions == nil {
		s.sessions = map[string]time.Time{}
	}
	for k, e := range s.sessions { // Abgelaufene aufräumen
		if time.Now().After(e) {
			delete(s.sessions, k)
		}
	}
	s.sessions[hashToken(tok)] = exp
	delete(s.failed, ip)
	s.mu.Unlock()
	s.persistSessions()
	writeJSON(w, http.StatusOK, map[string]any{"ok": true, "token": tok, "expiresAt": exp.UTC().Format(time.RFC3339)})
}

func (s *Server) handleLogout(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeJSON(w, http.StatusMethodNotAllowed, apiError{"method_not_allowed", "Nur POST ist erlaubt."})
		return
	}
	if !s.authorize(w, r, false) {
		return
	}
	if t := bearer(r); t != "" {
		s.mu.Lock()
		delete(s.sessions, hashToken(t))
		s.mu.Unlock()
		s.persistSessions()
	}
	writeJSON(w, http.StatusOK, map[string]any{"ok": true})
}

func (s *Server) handleSession(w http.ResponseWriter, r *http.Request) {
	if !s.authorize(w, r, false) {
		return
	}
	resp := map[string]any{"loginRequired": s.loginRequired(), "loggedIn": !s.loginRequired() || s.sessionValid(bearer(r))}
	if t := bearer(r); t != "" && s.sessionValid(t) {
		s.mu.Lock()
		resp["expiresAt"] = s.sessions[hashToken(t)].UTC().Format(time.RFC3339)
		s.mu.Unlock()
	}
	writeJSON(w, http.StatusOK, resp)
}

// Sitzungen überstehen einen Neustart des Servers (nur Hashes, Datei mit Rechten 0600).
func (s *Server) persistSessions() {
	if s.Store == nil {
		return
	}
	s.mu.Lock()
	cp := make(map[string]time.Time, len(s.sessions))
	for k, v := range s.sessions {
		cp[k] = v
	}
	s.mu.Unlock()
	_ = s.Store.SaveSessions(cp)
}
