package api

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"
)

func do(t *testing.T, h http.Handler, method, path string, body any, hdr map[string]string) (int, map[string]any) {
	t.Helper()
	var rd *bytes.Reader
	if body != nil {
		b, _ := json.Marshal(body)
		rd = bytes.NewReader(b)
	} else {
		rd = bytes.NewReader(nil)
	}
	req := httptest.NewRequest(method, path, rd)
	for k, v := range hdr {
		req.Header.Set(k, v)
	}
	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, req)
	var m map[string]any
	_ = json.Unmarshal(rec.Body.Bytes(), &m)
	return rec.Code, m
}

func newTestServer(t *testing.T, dir string) *Server {
	st, err := NewFileStore(dir)
	if err != nil {
		t.Fatal(err)
	}
	return &Server{APIKey: "api-token", LoginPassword: "Weiche-42", Store: st, Version: "test",
		LoginPerWindow: 3, LoginWindow: time.Minute}
}

func TestPingLoginAndSession(t *testing.T) {
	srv := newTestServer(t, t.TempDir())
	h := srv.Handler()
	key := map[string]string{"X-Api-Key": "api-token"}

	if code, m := do(t, h, "GET", "/api/ping", nil, nil); code != 401 || m["error"] != "invalid_token" {
		t.Fatalf("ping ohne Token: %d %v", code, m)
	}
	code, m := do(t, h, "GET", "/api/ping", nil, key)
	if code != 200 || m["service"] != "schadwagen-backend" || m["loginRequired"] != true || m["loggedIn"] != false {
		t.Fatalf("ping: %d %v", code, m)
	}
	if code, m = do(t, h, "GET", "/api/protocols", nil, key); code != 401 || m["error"] != "login_required" {
		t.Fatalf("ohne Sitzung: %d %v", code, m)
	}
	if code, m = do(t, h, "POST", "/api/login", map[string]string{"password": "falsch"}, key); code != 401 || m["error"] != "wrong_password" {
		t.Fatalf("falsches Passwort: %d %v", code, m)
	}
	code, m = do(t, h, "POST", "/api/login", map[string]string{"password": "Weiche-42"}, key)
	tok, _ := m["token"].(string)
	if code != 200 || len(tok) != 64 {
		t.Fatalf("Anmeldung: %d %v", code, m)
	}
	auth := map[string]string{"X-Api-Key": "api-token", "Authorization": "Bearer " + tok}
	if code, m = do(t, h, "GET", "/api/session", nil, auth); code != 200 || m["loggedIn"] != true {
		t.Fatalf("Sitzung: %d %v", code, m)
	}
	if code, _ = do(t, h, "GET", "/api/protocols", nil, auth); code != 200 {
		t.Fatalf("mit Sitzung: %d", code)
	}
	// Sitzung übersteht Neustart
	h2 := newTestServer(t, srv.Store.Dir).Handler()
	if code, _ = do(t, h2, "GET", "/api/protocols", nil, auth); code != 200 {
		t.Fatalf("nach Neustart: %d", code)
	}
	if code, _ = do(t, h2, "POST", "/api/logout", nil, auth); code != 200 {
		t.Fatalf("Abmelden: %d", code)
	}
	if code, _ = do(t, h2, "GET", "/api/protocols", nil, auth); code != 401 {
		t.Fatalf("nach Abmelden 401 erwartet: %d", code)
	}
	// Fehlversuche begrenzt
	for i := 0; i < 3; i++ {
		do(t, h2, "POST", "/api/login", map[string]string{"password": "x"}, key)
	}
	if code, m = do(t, h2, "POST", "/api/login", map[string]string{"password": "Weiche-42"}, key); code != 429 {
		t.Fatalf("Sperre nach Fehlversuchen erwartet: %d %v", code, m)
	}
}

func TestPasswordHash(t *testing.T) {
	// sha256("Weiche-42")
	s := &Server{LoginPasswordSHA256: "8d1b2bbd3c30ff5f2ce8b59cd3c8c6f3e1a4ad5b1df4f4f8bdbd29a2b8f5f1a0"}
	if s.passwordOK("Weiche-42") {
		t.Fatal("falscher Hash darf nicht passen")
	}
	s.LoginPasswordSHA256 = hashToken("Weiche-42")
	if !s.passwordOK("Weiche-42") || s.passwordOK("weiche-42") {
		t.Fatal("Hash-Vergleich falsch")
	}
}

func TestNoLoginConfigured(t *testing.T) {
	st, _ := NewFileStore(t.TempDir())
	h := (&Server{Store: st}).Handler()
	if code, m := do(t, h, "GET", "/api/ping", nil, nil); code != 200 || m["loginRequired"] != false {
		t.Fatalf("ping: %d %v", code, m)
	}
	if code, _ := do(t, h, "GET", "/api/protocols", nil, nil); code != 200 {
		t.Fatalf("ohne Anmeldung offen: %d", code)
	}
	if code, m := do(t, (&Server{}).Handler(), "GET", "/api/protocols", nil, nil); code != 503 || m["error"] != "not_configured" {
		t.Fatalf("ohne Ablage: %d %v", code, m)
	}
}

func TestProtocols(t *testing.T) {
	st, _ := NewFileStore(t.TempDir())
	h := (&Server{Store: st}).Handler()
	rep := map[string]any{"id": "abc-1", "reportId": "B13H09/316", "wagonNumber": "338578371522",
		"updatedAt": "2026-10-23T10:00:00Z", "createdBy": map[string]any{"id": "e1", "name": "Benjamin Holley", "prefix": "B13H09"}}
	if code, m := do(t, h, "PUT", "/api/protocols/abc-1", map[string]any{"report": rep}, nil); code != 200 {
		t.Fatalf("PUT: %d %v", code, m)
	}
	if code, _ := do(t, h, "PUT", "/api/protocols/anders", map[string]any{"report": rep}, nil); code != 400 {
		t.Fatalf("ID-Abweichung 400 erwartet: %d", code)
	}
	if code, _ := do(t, h, "PUT", "/api/protocols/..%2Fx", map[string]any{"report": rep}, nil); code != 400 {
		t.Fatalf("ungültige ID 400 erwartet: %d", code)
	}
	old := map[string]any{"id": "abc-1", "updatedAt": "2026-10-22T10:00:00Z"}
	if code, _ := do(t, h, "PUT", "/api/protocols/abc-1", map[string]any{"report": old}, nil); code != 409 {
		t.Fatalf("älterer Stand 409 erwartet: %d", code)
	}
	code, m := do(t, h, "GET", "/api/protocols", nil, nil)
	list, _ := m["protocols"].([]any)
	if code != 200 || len(list) != 1 {
		t.Fatalf("Liste: %d %v", code, m)
	}
	first := list[0].(map[string]any)
	if first["reportId"] != "B13H09/316" || first["createdBy"].(map[string]any)["prefix"] != "B13H09" {
		t.Fatalf("Kopfdaten: %v", first)
	}
	if code, m = do(t, h, "GET", "/api/protocols?since=2999-01-01T00:00:00Z", nil, nil); len(m["protocols"].([]any)) != 0 {
		t.Fatalf("since-Filter: %d %v", code, m)
	}
	code, m = do(t, h, "GET", "/api/protocols/abc-1", nil, nil)
	if code != 200 || m["report"].(map[string]any)["wagonNumber"] != "338578371522" {
		t.Fatalf("GET einzeln: %d %v", code, m)
	}
	if code, _ = do(t, h, "GET", "/api/protocols/fehlt", nil, nil); code != 404 {
		t.Fatalf("404 erwartet: %d", code)
	}
}

func TestEmployeesMerge(t *testing.T) {
	st, _ := NewFileStore(t.TempDir())
	h := (&Server{Store: st}).Handler()
	a := map[string]any{"id": "e1", "firstName": "Benjamin", "prefix": "B13H09", "nextNumber": 320, "updatedAt": "2026-10-23T10:00:00Z"}
	do(t, h, "PUT", "/api/employees", map[string]any{"employees": []any{a}}, nil)
	// anderes Gerät: älterer Stand mit niedrigerer Nummer, aber neuer Mitarbeiter e2
	b := map[string]any{"id": "e1", "firstName": "Benni", "prefix": "B13H09", "nextNumber": 317, "updatedAt": "2026-10-22T10:00:00Z"}
	c := map[string]any{"id": "e2", "firstName": "Anna", "prefix": "A01", "nextNumber": 1, "updatedAt": "2026-10-23T11:00:00Z"}
	code, m := do(t, h, "PUT", "/api/employees", map[string]any{"employees": []any{b, c}}, nil)
	list, _ := m["employees"].([]any)
	if code != 200 || len(list) != 2 {
		t.Fatalf("Abgleich: %d %v", code, m)
	}
	e1 := list[0].(map[string]any)
	if e1["firstName"] != "Benjamin" || e1["nextNumber"].(float64) != 320 {
		t.Fatalf("neuester Stand und höchste Nummer erwartet: %v", e1)
	}
	// neuerer Stand mit niedrigerer Nummer: Daten übernehmen, Nummer nicht verringern
	d := map[string]any{"id": "e1", "firstName": "Benjamin", "title": "Wagenmeister", "nextNumber": 300, "updatedAt": "2026-10-24T10:00:00Z"}
	_, m = do(t, h, "PUT", "/api/employees", map[string]any{"employees": []any{d}}, nil)
	e1 = m["employees"].([]any)[0].(map[string]any)
	if e1["title"] != "Wagenmeister" || e1["nextNumber"].(float64) != 320 {
		t.Fatalf("Nummer darf nicht sinken: %v", e1)
	}
}

func TestPresence(t *testing.T) {
	srv := &Server{PresenceTTL: 50 * time.Millisecond}
	h := srv.Handler()
	in := map[string]any{"deviceId": "dev-1", "device": "Windows-PC", "active": true, "employeeId": "e1", "employeeName": "Benjamin Holley",
		"reportUuid": "r1", "reportId": "B13H09/2", "wagonNumber": "338078378605", "stored": true}
	if code, _ := do(t, h, "POST", "/api/presence", in, nil); code != 200 {
		t.Fatalf("POST: %d", code)
	}
	_, m := do(t, h, "GET", "/api/presence", nil, nil)
	list := m["presence"].([]any)
	if len(list) != 1 || list[0].(map[string]any)["reportId"] != "B13H09/2" {
		t.Fatalf("Anwesenheit: %v", m)
	}
	if code, _ := do(t, h, "POST", "/api/presence", map[string]any{"deviceId": "../x", "active": true}, nil); code != 400 {
		t.Fatalf("ungültige Geräte-ID: %d", code)
	}
	// abmelden
	do(t, h, "POST", "/api/presence", map[string]any{"deviceId": "dev-1", "active": false}, nil)
	if _, m = do(t, h, "GET", "/api/presence", nil, nil); len(m["presence"].([]any)) != 0 {
		t.Fatalf("nach active=false leer erwartet: %v", m)
	}
	// verfällt
	do(t, h, "POST", "/api/presence", in, nil)
	time.Sleep(80 * time.Millisecond)
	if _, m = do(t, h, "GET", "/api/presence", nil, nil); len(m["presence"].([]any)) != 0 {
		t.Fatalf("abgelaufen erwartet: %v", m)
	}
}

func TestFoldersMerge(t *testing.T) {
	st, _ := NewFileStore(t.TempDir())
	h := (&Server{Store: st}).Handler()
	a := map[string]any{"id": "f-1", "name": "Reklamationen", "items": []any{"r1"}, "updatedAt": "2026-10-24T10:00:00Z"}
	do(t, h, "PUT", "/api/folders", map[string]any{"folders": []any{a}}, nil)
	// anderes Gerät: älterer Stand verliert, neuer Ordner kommt dazu
	old := map[string]any{"id": "f-1", "name": "Alt", "items": []any{}, "updatedAt": "2026-10-23T10:00:00Z"}
	b := map[string]any{"id": "f-2", "name": "Werkstatt", "items": []any{"r2"}, "updatedAt": "2026-10-24T11:00:00Z"}
	code, m := do(t, h, "PUT", "/api/folders", map[string]any{"folders": []any{old, b}}, nil)
	list, _ := m["folders"].([]any)
	if code != 200 || len(list) != 2 || list[0].(map[string]any)["name"] != "Reklamationen" {
		t.Fatalf("Abgleich: %d %v", code, m)
	}
	// Löschen (neuer Stand mit deleted) kommt an
	del := map[string]any{"id": "f-2", "name": "Werkstatt", "items": []any{}, "deleted": true, "updatedAt": "2026-10-24T12:00:00Z"}
	_, m = do(t, h, "PUT", "/api/folders", map[string]any{"folders": []any{del}}, nil)
	if m["folders"].([]any)[1].(map[string]any)["deleted"] != true {
		t.Fatalf("Löschmarkierung erwartet: %v", m)
	}
	if code, m = do(t, h, "GET", "/api/folders", nil, nil); code != 200 || len(m["folders"].([]any)) != 2 {
		t.Fatalf("GET: %d %v", code, m)
	}
}
