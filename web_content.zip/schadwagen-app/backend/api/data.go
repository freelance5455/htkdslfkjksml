package api

import (
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"strings"
	"time"
)

const maxProtocolBytes = 40 << 20 // Protokoll inkl. Fotos

func (s *Server) needStore(w http.ResponseWriter) bool {
	if s.Store == nil {
		writeJSON(w, http.StatusServiceUnavailable, apiError{"not_configured", "Auf dem Server ist keine Ablage eingerichtet (DATA_DIR)."})
		return false
	}
	return true
}

// GET /api/protocols?since=RFC3339
func (s *Server) handleProtocols(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		writeJSON(w, http.StatusMethodNotAllowed, apiError{"method_not_allowed", "Nur GET ist erlaubt."})
		return
	}
	if !s.authorize(w, r, true) || !s.needStore(w) {
		return
	}
	var since time.Time
	if v := r.URL.Query().Get("since"); v != "" {
		t, err := time.Parse(time.RFC3339Nano, v)
		if err != nil {
			writeJSON(w, http.StatusBadRequest, apiError{"bad_request", "since muss ein RFC3339-Zeitstempel sein."})
			return
		}
		since = t
	}
	list, err := s.Store.ListProtocols(since)
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, apiError{"internal", "Ablage nicht lesbar."})
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"protocols": list, "serverTime": time.Now().UTC().Format(time.RFC3339Nano)})
}

// GET/PUT /api/protocols/{id}
func (s *Server) handleProtocol(w http.ResponseWriter, r *http.Request) {
	if !s.authorize(w, r, true) || !s.needStore(w) {
		return
	}
	id := strings.TrimPrefix(r.URL.Path, "/api/protocols/")
	switch r.Method {
	case http.MethodGet:
		p, err := s.Store.GetProtocol(id)
		switch {
		case errors.Is(err, ErrBadID):
			writeJSON(w, http.StatusBadRequest, apiError{"bad_request", "Ungültige Protokoll-ID."})
		case errors.Is(err, ErrNotFound):
			writeJSON(w, http.StatusNotFound, apiError{"not_found", "Protokoll nicht gefunden."})
		case err != nil:
			writeJSON(w, http.StatusInternalServerError, apiError{"internal", "Ablage nicht lesbar."})
		default:
			writeJSON(w, http.StatusOK, p)
		}
	case http.MethodPut:
		raw, err := io.ReadAll(http.MaxBytesReader(w, r.Body, maxProtocolBytes))
		if err != nil {
			writeJSON(w, http.StatusRequestEntityTooLarge, apiError{"too_large", "Protokoll ist zu groß."})
			return
		}
		var body struct {
			Report json.RawMessage `json:"report"`
		}
		var head struct {
			ID           string          `json:"id"`
			ReportID     string          `json:"reportId"`
			WagonNumber  string          `json:"wagonNumber"`
			PdfCreatedAt string          `json:"pdfCreatedAt"`
			UpdatedAt    string          `json:"updatedAt"`
			CreatedBy    json.RawMessage `json:"createdBy"`
		}
		if json.Unmarshal(raw, &body) != nil || len(body.Report) == 0 || json.Unmarshal(body.Report, &head) != nil {
			writeJSON(w, http.StatusBadRequest, apiError{"bad_request", "Ungültige Protokolldaten."})
			return
		}
		if head.ID != id {
			writeJSON(w, http.StatusBadRequest, apiError{"bad_request", "ID im Pfad und im Protokoll stimmen nicht überein."})
			return
		}
		if head.UpdatedAt == "" {
			head.UpdatedAt = time.Now().UTC().Format(time.RFC3339Nano)
		}
		createdBy := head.CreatedBy
		if string(createdBy) == "null" {
			createdBy = nil
		}
		meta, err := s.Store.PutProtocol(ProtocolMeta{ID: id, ReportID: head.ReportID, WagonNumber: head.WagonNumber,
			PdfCreatedAt: head.PdfCreatedAt, UpdatedAt: head.UpdatedAt, CreatedBy: createdBy}, body.Report)
		switch {
		case errors.Is(err, ErrBadID):
			writeJSON(w, http.StatusBadRequest, apiError{"bad_request", "Ungültige Protokoll-ID."})
		case errors.Is(err, ErrOutdated):
			writeJSON(w, http.StatusConflict, map[string]any{"error": "outdated", "message": "Auf dem Server liegt ein neuerer Stand.", "meta": meta})
		case err != nil:
			writeJSON(w, http.StatusInternalServerError, apiError{"internal", "Protokoll konnte nicht gespeichert werden."})
		default:
			writeJSON(w, http.StatusOK, map[string]any{"ok": true, "meta": meta})
		}
	default:
		writeJSON(w, http.StatusMethodNotAllowed, apiError{"method_not_allowed", "Nur GET und PUT sind erlaubt."})
	}
}

// GET/PUT /api/employees
func (s *Server) handleEmployees(w http.ResponseWriter, r *http.Request) {
	if !s.authorize(w, r, true) || !s.needStore(w) {
		return
	}
	switch r.Method {
	case http.MethodGet:
		l, err := s.Store.Employees()
		if err != nil {
			writeJSON(w, http.StatusInternalServerError, apiError{"internal", "Ablage nicht lesbar."})
			return
		}
		writeJSON(w, http.StatusOK, l)
	case http.MethodPut:
		var body struct {
			Employees []map[string]any `json:"employees"`
		}
		if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 2<<20)).Decode(&body); err != nil {
			writeJSON(w, http.StatusBadRequest, apiError{"bad_request", "Ungültige Mitarbeiterliste."})
			return
		}
		l, err := s.Store.MergeEmployees(body.Employees)
		if err != nil {
			writeJSON(w, http.StatusInternalServerError, apiError{"internal", "Mitarbeiterliste konnte nicht gespeichert werden."})
			return
		}
		writeJSON(w, http.StatusOK, l)
	default:
		writeJSON(w, http.StatusMethodNotAllowed, apiError{"method_not_allowed", "Nur GET und PUT sind erlaubt."})
	}
}
