package api

import (
	"encoding/json"
	"net/http"
	"sort"
	"time"
)

// Anwesenheit: welches Gerät / welcher Mitarbeiter arbeitet gerade an welchem Protokoll.
// Nur im Speicher; ein Eintrag verfällt ohne neue Meldung nach PresenceTTL (Standard 2 Minuten).

type presenceEntry struct {
	DeviceID     string `json:"deviceId"`
	Device       string `json:"device"`
	EmployeeID   string `json:"employeeId"`
	EmployeeName string `json:"employeeName"`
	ReportUUID   string `json:"reportUuid"`
	ReportID     string `json:"reportId"`
	WagonNumber  string `json:"wagonNumber"`
	Place        string `json:"place"`
	Stored       bool   `json:"stored"`
	InForm       bool   `json:"inForm"`
	Dirty        bool   `json:"dirty"`
	OpenedAt     string `json:"openedAt"`
	LastActivity string `json:"lastActivity"`
	SeenAt       string `json:"seenAt"`
	seen         time.Time
}

func clip(s string, n int) string {
	r := []rune(s)
	if len(r) > n {
		return string(r[:n])
	}
	return s
}

func (s *Server) presenceTTL() time.Duration {
	if s.PresenceTTL > 0 {
		return s.PresenceTTL
	}
	return 2 * time.Minute
}

// GET /api/presence, POST /api/presence {deviceId, active, …}
func (s *Server) handlePresence(w http.ResponseWriter, r *http.Request) {
	if !s.authorize(w, r, true) {
		return
	}
	switch r.Method {
	case http.MethodGet:
		now := time.Now()
		s.mu.Lock()
		out := []presenceEntry{}
		for k, e := range s.presence {
			if now.Sub(e.seen) > s.presenceTTL() {
				delete(s.presence, k)
				continue
			}
			out = append(out, e)
		}
		s.mu.Unlock()
		sort.Slice(out, func(i, j int) bool { return out[i].EmployeeName < out[j].EmployeeName })
		writeJSON(w, http.StatusOK, map[string]any{"presence": out, "serverTime": now.UTC().Format(time.RFC3339)})
	case http.MethodPost:
		var in struct {
			presenceEntry
			Active bool `json:"active"`
		}
		if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 8<<10)).Decode(&in); err != nil || !idPattern.MatchString(in.DeviceID) {
			writeJSON(w, http.StatusBadRequest, apiError{"bad_request", "Ungültige Meldung."})
			return
		}
		s.mu.Lock()
		if s.presence == nil {
			s.presence = map[string]presenceEntry{}
		}
		if !in.Active || in.EmployeeID == "" {
			delete(s.presence, in.DeviceID)
		} else {
			e := in.presenceEntry
			e.Device, e.EmployeeID, e.EmployeeName = clip(e.Device, 40), clip(e.EmployeeID, 64), clip(e.EmployeeName, 80)
			e.ReportUUID, e.ReportID, e.WagonNumber, e.Place = clip(e.ReportUUID, 64), clip(e.ReportID, 40), clip(e.WagonNumber, 20), clip(e.Place, 80)
			e.OpenedAt, e.LastActivity = clip(e.OpenedAt, 40), clip(e.LastActivity, 40)
			e.seen = time.Now()
			e.SeenAt = e.seen.UTC().Format(time.RFC3339)
			s.presence[in.DeviceID] = e
		}
		s.mu.Unlock()
		writeJSON(w, http.StatusOK, map[string]any{"ok": true})
	default:
		writeJSON(w, http.StatusMethodNotAllowed, apiError{"method_not_allowed", "Nur GET und POST sind erlaubt."})
	}
}
