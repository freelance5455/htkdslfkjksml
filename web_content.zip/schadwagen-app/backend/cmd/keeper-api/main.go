// keeper-api: Backend der App "TrainTrace Management" (Halter-Abfrage, Anmeldung, Protokolle, Mitarbeiter).
//
// Konfiguration über Umgebungsvariablen:
//
//	PORT              Port (Standard 8080)
//	KEEPER_SOURCES    Reihenfolge der Quellen, kommagetrennt: file, era, gcu-broker, gcu-wagon-search
//	                  (Standard: gcu-broker – liefert "nicht eingerichtet", bis die Freigabe vorliegt)
//	KEEPER_FILE       JSON-Datei für die Quelle "file"
//	ERA_URL           URL-Vorlage der Registerabfrage mit {evn}, z. B. https://…/vehicles/{evn}
//	ERA_AUTH          Wert für den Authorization-Header der Registerabfrage (optional)
//	GCU_BROKER_URL / GCU_BROKER_TOKEN   für den GCU-Broker-Adapter (nach Freigabe)
//	API_KEY           API-Token: wenn gesetzt, muss die App den Header X-Api-Key mitsenden
//	LOGIN_PASSWORD    Passwortschlüssel für die Anmeldung (alternativ LOGIN_PASSWORD_SHA256 als Hex-Hash)
//	SESSION_DAYS      Gültigkeit einer Anmeldung in Tagen (Standard 30)
//	DATA_DIR          Ordner für Protokolle, Mitarbeiter und Sitzungen (Standard ./data; "-" = aus)
//	ALLOWED_ORIGINS   CORS-Ursprünge, kommagetrennt (Standard: App-Ursprünge Android/iOS/Windows)
//	RATE_PER_MINUTE   Abfragen je Client und Minute (Standard 60)
//	CACHE_HOURS       serverseitiger Zwischenspeicher für Treffer (Standard 24)
//	TLS_CERT/TLS_KEY  https mit eigenem Zertifikat (PEM-Dateien)
//	TLS_SELF_SIGNED   "1": https mit selbst erzeugtem Zertifikat (in DATA_DIR bzw. TLS_DIR, wird wiederverwendet)
//	TLS_HOSTS         zusätzliche Namen/IP-Adressen für das erzeugte Zertifikat, kommagetrennt
//	                  (alle Adressen dieses Rechners sind automatisch enthalten)
//	                  Beim Start wird der Fingerabdruck (SHA-256) ausgegeben – in der App beim ersten Verbinden vergleichen.
package main

import (
	"log"
	"net/http"
	"os"
	"strconv"
	"strings"
	"time"

	"crypto/tls"

	"schadwagen/backend/api"
	"schadwagen/backend/keeper"
	"schadwagen/backend/tlsutil"
)

const version = "1.4.1"

func env(k, def string) string {
	if v := strings.TrimSpace(os.Getenv(k)); v != "" {
		return v
	}
	return def
}

func main() {
	var chain keeper.Chain
	for _, name := range strings.Split(env("KEEPER_SOURCES", "gcu-broker"), ",") {
		switch strings.TrimSpace(name) {
		case "file":
			fs, err := keeper.NewFileSource(env("KEEPER_FILE", "keepers.json"))
			if err != nil {
				log.Fatalf("Quelle file: %v", err)
			}
			chain = append(chain, fs)
		case "era":
			h := map[string]string{}
			if a := os.Getenv("ERA_AUTH"); a != "" {
				h["Authorization"] = a
			}
			chain = append(chain, &keeper.ERASource{URLTemplate: os.Getenv("ERA_URL"), Header: h})
		case "gcu-broker":
			chain = append(chain, &keeper.GCUBrokerSource{BaseURL: os.Getenv("GCU_BROKER_URL"), Token: os.Getenv("GCU_BROKER_TOKEN")})
		case "gcu-wagon-search":
			chain = append(chain, &keeper.GCUWagonSearchSource{})
		case "":
		default:
			log.Fatalf("unbekannte Quelle %q", name)
		}
	}
	hours, _ := strconv.Atoi(env("CACHE_HOURS", "24"))
	rate, _ := strconv.Atoi(env("RATE_PER_MINUTE", "60"))
	var src keeper.Source = chain
	if hours > 0 {
		src = &keeper.Cached{Source: chain, TTL: time.Duration(hours) * time.Hour}
	}
	sessionDays, _ := strconv.Atoi(env("SESSION_DAYS", "30"))
	var store *api.FileStore
	if dir := env("DATA_DIR", "data"); dir != "-" {
		st, err := api.NewFileStore(dir)
		if err != nil {
			log.Fatalf("DATA_DIR %s: %v", dir, err)
		}
		store = st
	}
	srv := &api.Server{
		Source:              src,
		LoginPassword:       os.Getenv("LOGIN_PASSWORD"),
		LoginPasswordSHA256: os.Getenv("LOGIN_PASSWORD_SHA256"),
		SessionTTL:          time.Duration(sessionDays) * 24 * time.Hour,
		Store:               store,
		Version:             version,
		APIKey:              os.Getenv("API_KEY"),
		AllowedOrigins:      strings.Split(env("ALLOWED_ORIGINS", "https://appassets.androidplatform.net,capacitor://localhost,http://localhost,http://127.0.0.1:47831,http://localhost:47831"), ","),
		RatePerMinute:       rate,
	}
	addr := ":" + env("PORT", "8080")
	log.Printf("keeper-api %s auf %s, Quellen: %s, Anmeldung: %v, Ablage: %v", version, addr, env("KEEPER_SOURCES", "gcu-broker"), srv.LoginPassword != "" || srv.LoginPasswordSHA256 != "", store != nil)
	if srv.APIKey == "" {
		log.Printf("Hinweis: API_KEY ist nicht gesetzt – jeder kann den Server ansprechen.")
	}
	s := &http.Server{Addr: addr, Handler: srv.Handler(), ReadHeaderTimeout: 10 * time.Second}
	cert, ok := tlsSetup()
	if !ok {
		log.Printf("Hinweis: ohne TLS (http). Für den Betrieb per IP-Adresse TLS_SELF_SIGNED=1 oder TLS_CERT/TLS_KEY setzen.")
		log.Fatal(s.ListenAndServe())
	}
	s.TLSConfig = &tls.Config{MinVersion: tls.VersionTLS12, Certificates: []tls.Certificate{cert}}
	log.Fatal(s.ListenAndServeTLS("", ""))
}

// tlsSetup: eigenes Zertifikat (TLS_CERT/TLS_KEY) oder selbst erzeugtes (TLS_SELF_SIGNED=1).
func tlsSetup() (tls.Certificate, bool) {
	if cf, kf := os.Getenv("TLS_CERT"), os.Getenv("TLS_KEY"); cf != "" || kf != "" {
		c, fp, err := tlsutil.Load(cf, kf)
		if err != nil {
			log.Fatalf("TLS_CERT/TLS_KEY: %v", err)
		}
		log.Printf("https mit eigenem Zertifikat. %s", tlsutil.Describe(c, fp))
		return c, true
	}
	if v := strings.ToLower(os.Getenv("TLS_SELF_SIGNED")); v == "1" || v == "true" || v == "ja" {
		dir := env("TLS_DIR", env("DATA_DIR", "data"))
		if dir == "-" {
			dir = "."
		}
		hosts := tlsutil.LocalAddresses()
		for _, h := range strings.Split(os.Getenv("TLS_HOSTS"), ",") {
			if h = strings.TrimSpace(h); h != "" {
				hosts = append(hosts, h)
			}
		}
		c, fp, created, err := tlsutil.SelfSigned(dir, hosts)
		if err != nil {
			log.Fatalf("Zertifikat erzeugen: %v", err)
		}
		state := "vorhandenem"
		if created {
			state = "neu erzeugtem"
		}
		log.Printf("https mit %s, selbst ausgestelltem Zertifikat (%s). %s", state, dir, tlsutil.Describe(c, fp))
		return c, true
	}
	return tls.Certificate{}, false
}
