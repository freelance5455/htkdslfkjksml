# keeper-api – Backend der App „Schadwagen Management“

Halter-Abfrage, Anmeldung mit Passwortschlüssel, Latenzmessung sowie Abgleich von Protokollen und Mitarbeitern.

| Methode | Pfad | Zweck | Sitzung nötig* |
|---|---|---|---|
| GET | `/api/ping` | Verbindung prüfen, Latenz messen (`service`, `version`, `loginRequired`, `loggedIn`, `features`) | nein |
| POST | `/api/login` | `{"password": "…"}` → `{"token", "expiresAt"}` | nein |
| POST | `/api/logout` | Sitzung beenden | – |
| GET | `/api/session` | Status der Sitzung | – |
| GET | `/api/keeper/{evn}` | Halter-Abfrage | ja |
| GET | `/api/protocols?since=…` | Kopfdaten der Protokolle (inkl. `createdBy`) | ja |
| GET / PUT | `/api/protocols/{id}` | ein Protokoll lesen / ablegen (`{"report": {…}}`, neuester `updatedAt` gewinnt, sonst 409) | ja |
| GET / PUT | `/api/employees` | Mitarbeiterliste lesen / abgleichen (je Eintrag gewinnt der neueste Stand, `nextNumber` sinkt nie) | ja |
| GET / PUT | `/api/folders` | Eigene Ordner der Ansicht „Gespeichert“ lesen / abgleichen (je Ordner gewinnt der neueste Stand, Löschen als Markierung `deleted`; Datumsordner berechnet die App selbst) | ja |
| GET / POST | `/api/presence` | wer arbeitet gerade an welchem Protokoll (nur im Speicher, verfällt nach 2 Minuten ohne Meldung) | ja |

\* nur wenn `LOGIN_PASSWORD` bzw. `LOGIN_PASSWORD_SHA256` gesetzt ist. Alle Endpunkte verlangen den API-Token
(`X-Api-Key`), sofern `API_KEY` gesetzt ist; die Sitzung wird als `Authorization: Bearer <token>` gesendet.
Fehlerantworten: `invalid_token` (API-Token falsch), `login_required`, `wrong_password`, `rate_limited`
(10 Fehlversuche je IP in 15 Minuten), `not_configured` (keine Ablage).

Sicherheit: Passwortschlüssel und Tokens werden nie protokolliert; Sitzungen liegen nur als SHA-256-Hash in
`DATA_DIR/sessions.json` (Rechte 0600) und überstehen so einen Neustart. Für den Betrieb immer HTTPS
(z. B. hinter Caddy/nginx) verwenden.

### Halter-Abfrage

```
GET /api/keeper/{evn}        z. B. /api/keeper/338578371522 oder /api/keeper/33%2085%207837%20152-2
```

| Status | `error` | Bedeutung |
|---|---|---|
| 200 | – | Treffer: `keeper.code`, `name`, `street`, `zipCode`, `town`, `countryCode`, `address`, `email` |
| 400 | `invalid_evn` | keine 12 Ziffern oder Prüfziffer falsch |
| 404 | `not_found` | Wagen nicht gefunden |
| 502 | `source_unavailable` | Datenquelle nicht erreichbar |
| 503 | `not_configured` | Datenquelle noch nicht freigeschaltet |
| 401 / 429 | `unauthorized` / `rate_limited` | Schlüssel falsch / zu viele Abfragen |

## Datenquellen (Adapter `keeper.Source`)
Die Quelle wird nur hier im Backend gewählt (`KEEPER_SOURCES`, kommagetrennt, nacheinander abgefragt) –
ein Wechsel braucht kein App-Update.

| Name | Stand |
|---|---|
| `gcu-broker` | **Platzhalter.** Wird nach Freigabe des GCU Bureau umgesetzt (`keeper/gcu.go`). Antwortet bis dahin mit `not_configured`. |
| `gcu-wagon-search` | **Platzhalter, bewusst nicht implementiert.** Automatisierte Abfrage von gcubureau.org nur mit schriftlicher Erlaubnis. |
| `era` | Fertig: Registerabfrage mit Antwort nach `vehicleinfo_2.0.xsd` (KeeperInformation). URL-Vorlage `ERA_URL` mit `{evn}`, optional `ERA_AUTH`. |
| `file` | Fertig: eigene JSON-Liste (`KEEPER_FILE`, Aufbau siehe `testdata/keepers.example.json`). |

## Start
```bash
go test ./...
KEEPER_SOURCES=file KEEPER_FILE=testdata/keepers.example.json go run ./cmd/keeper-api   # Test mit Beispieldaten
docker build -t keeper-api . && docker run -p 8080:8080 -e KEEPER_SOURCES=gcu-broker keeper-api
```
Weitere Variablen: `PORT`, `API_KEY` (API-Token, App sendet `X-Api-Key`), `LOGIN_PASSWORD` oder `LOGIN_PASSWORD_SHA256`
(Passwortschlüssel für den Reiter „Anmeldung“), `SESSION_DAYS` (30), `DATA_DIR` (`data`, `-` = keine Ablage),
`ALLOWED_ORIGINS`, `RATE_PER_MINUTE` (60, nur Halter-Abfrage), `CACHE_HOURS` (24),
`TLS_SELF_SIGNED`, `TLS_CERT`/`TLS_KEY`, `TLS_HOSTS`, `TLS_DIR` (https, siehe „Betrieb per IP-Adresse“).

Beispiel mit Anmeldung und Ablage:
```bash
API_KEY=$(openssl rand -hex 24) LOGIN_PASSWORD='…' DATA_DIR=/var/lib/schadwagen \
KEEPER_SOURCES=gcu-broker ./keeper-api
```
Für die Handy-Apps muss der Server per **HTTPS** erreichbar sein (Ausnahme: unverschlüsselt im eigenen lokalen Netz, siehe unten).

In der App: Einstellungen → Server-Verbindung → **Verbindungsart** wählen, API-Token eintragen, dann „Verbindung prüfen“.
Verlangt der Server eine Anmeldung, erscheint der Reiter „Anmeldung“ für den Passwortschlüssel.

## Betrieb per IP-Adresse

Die App kennt zwei Verbindungsarten:

* **HTTPS-Adresse (Domain)** – z. B. `https://schadwagen.firma.de` mit einem offiziellen Zertifikat (z. B. Let's Encrypt).
* **IP-Verbindung** – IP-Adresse (IPv4 oder IPv6) und Port, wahlweise
  * **verschlüsselt (https)** – auch mit selbst ausgestelltem Zertifikat. Beim ersten Verbinden zeigt die App den
    **Fingerabdruck (SHA-256)**; stimmt er mit dem überein, den der Server beim Start ausgibt, wird er bestätigt und
    fest gemerkt (Pinning). Zeigt der Server später ein anderes Zertifikat, sperrt die App die Verbindung und warnt.
  * **unverschlüsselt (http)** – nur zu privaten Adressen (10.x, 172.16–31.x, 192.168.x, fd00::/8, localhost) und erst
    nach ausdrücklicher Bestätigung. API-Token und Daten gehen dabei lesbar durchs Netz – nur im eigenen, vertrauenswürdigen Netz.

### https mit selbst erzeugtem Zertifikat (empfohlen für IP-Betrieb)
```bash
TLS_SELF_SIGNED=1 PORT=8443 API_KEY=$(openssl rand -hex 24) DATA_DIR=/var/lib/schadwagen ./keeper-api
# Ausgabe beim Start, z. B.:
#   https mit neu erzeugtem, selbst ausgestelltem Zertifikat (/var/lib/schadwagen).
#   Zertifikat-Fingerabdruck (SHA-256): A1:5D:CB:F0:…:7E:5F:8B:37
#   Gültig für: localhost, 127.0.0.1, ::1, 192.168.1.20
```
* Das Zertifikat (ECDSA P-256, 10 Jahre) liegt als `tls-cert.pem`/`tls-key.pem` in `DATA_DIR` (oder `TLS_DIR`) und wird
  bei jedem Start wiederverwendet – der Fingerabdruck bleibt gleich. Alle Adressen des Rechners sind enthalten;
  weitere Namen/IP-Adressen (z. B. die öffentliche Adresse hinter einer Portweiterleitung) mit `TLS_HOSTS=203.0.113.7,server.lan`.
* Kommt eine Adresse hinzu, die noch nicht im Zertifikat steht, wird ein neues erzeugt → neuer Fingerabdruck, die App fragt erneut.
* In der App: Verbindungsart „IP-Verbindung“, IP-Adresse und Port (z. B. `192.168.1.20` / `8443`), „Verschlüsselt (https)“,
  „Verbindung prüfen“ → Fingerabdruck vergleichen → „Fingerabdruck stimmt – vertrauen“.

### https mit eigenem Zertifikat
```bash
TLS_CERT=/etc/schadwagen/server.crt TLS_KEY=/etc/schadwagen/server.key PORT=8443 ./keeper-api
```
Der Fingerabdruck wird ebenfalls beim Start ausgegeben. Stammt das Zertifikat von einer Stelle, der die Geräte
vertrauen (z. B. firmeneigene Zertifizierungsstelle, auf den Geräten installiert), ist keine Bestätigung nötig.

### Unverschlüsselt im lokalen Netz
```bash
PORT=8080 API_KEY=… ./keeper-api        # ohne TLS_* → http
```
App: „IP-Verbindung“, „Unverschlüsselt (http, nur lokales Netz)“, Port 8080 – die Rückfrage bestätigen.

### Was wo funktioniert
| | Windows-App | Android-App | Browser/PWA |
|---|---|---|---|
| https mit offiziellem Zertifikat (Domain oder IP) | ja | ja | ja |
| https mit selbst ausgestelltem Zertifikat (Fingerabdruck bestätigen) | ja (über das lokale Programm) | ja (nativ) | nur, wenn das Zertifikat im Betriebssystem installiert ist |
| http im lokalen Netz | ja | ja | nur, wenn die App selbst per http geöffnet wird (Browser blockiert http aus https-Seiten) |
| genaue Fehlermeldungen (Port zu, Zeitüberschreitung, Zertifikat) | ja | ja | eingeschränkt („nicht erreichbar“) |

Firewall: den gewählten Port (z. B. 8443) auf dem Server freigeben. CORS (`ALLOWED_ORIGINS`) betrifft nur den Browser;
Windows- und Android-App verbinden sich bei IP-Verbindungen über das Programm bzw. die App selbst.
