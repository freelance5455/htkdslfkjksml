# keeper-api – Backend der App „Schadwagen Management“

Halter-Abfrage, Anmeldung mit Passwortschlüssel, Latenzmessung sowie Abgleich von Protokollen und Mitarbeitern.

| Methode | Pfad | Zweck | Sitzung nötig* |
|---|---|---|---|
| GET | `/api/ping` | Verbindung prüfen, Latenz messen (`service`, `version`, `loginRequired`, `loggedIn`, `features`) | nein |
| POST | `/api/login` | `{"password": "…"}` → `{"token", "expiresAt"}` | nein |
| POST | `/api/logout` | Sitzung beenden | – |
| GET | `/api/session` | Status der Sitzung | – |
| GET | `/api/keeper/{evn}` | Halter-Abfrage | ja |
| GET | `/api/protocols?since=…` | Kopfdaten der Protokolle (inkl. `createdBy`) | ja |
| GET / PUT | `/api/protocols/{id}` | ein Protokoll lesen / ablegen (`{"report": {…}}`, neuester `updatedAt` gewinnt, sonst 409) | ja |
| GET / PUT | `/api/employees` | Mitarbeiterliste lesen / abgleichen (je Eintrag gewinnt der neueste Stand, `nextNumber` sinkt nie) | ja |
| GET / PUT | `/api/folders` | Eigene Ordner der Ansicht „Gespeichert“ lesen / abgleichen (je Ordner gewinnt der neueste Stand, Löschen als Markierung `deleted`; Datumsordner berechnet die App selbst) | ja |
| GET / POST | `/api/presence` | wer arbeitet gerade an welchem Protokoll (nur im Speicher, verfällt nach 2 Minuten ohne Meldung) | ja |

\* nur wenn `LOGIN_PASSWORD` bzw. `LOGIN_PASSWORD_SHA256` gesetzt ist. Alle Endpunkte verlangen den API-Token
(`X-Api-Key`), sofern `API_KEY` gesetzt ist; die Sitzung wird als `Authorization: Bearer <token>` gesendet.
Fehlerantworten: `invalid_token` (API-Token falsch), `login_required`, `wrong_password`, `rate_limited`
(10 Fehlversuche je IP in 15 Minuten), `not_configured` (keine Ablage).

Sicherheit: Passwortschlüssel und Tokens werden nie protokolliert; Sitzungen liegen nur als SHA-256-Hash in
`DATA_DIR/sessions.json` (Rechte 0600) und überstehen so einen Neustart. Für den Betrieb immer HTTPS
(z. B. hinter Caddy/nginx) verwenden.

### Halter-Abfrage

```
GET /api/keeper/{evn}        z. B. /api/keeper/338578371522 oder /api/keeper/33%2085%207837%20152-2
```

| Status | `error` | Bedeutung |
|---|---|---|
| 200 | – | Treffer: `keeper.code`, `name`, `street`, `zipCode`, `town`, `countryCode`, `address`, `email` |
| 400 | `invalid_evn` | keine 12 Ziffern oder Prüfziffer falsch |
| 404 | `not_found` | Wagen nicht gefunden |
| 502 | `source_unavailable` | Datenquelle nicht erreichbar |
| 503 | `not_configured` | Datenquelle noch nicht freigeschaltet |
| 401 / 429 | `unauthorized` / `rate_limited` | Schlüssel falsch / zu viele Abfragen |

## Datenquellen (Adapter `keeper.Source`)
Die Quelle wird nur hier im Backend gewählt (`KEEPER_SOURCES`, kommagetrennt, nacheinander abgefragt) –
ein Wechsel braucht kein App-Update.

| Name | Stand |
|---|---|
| `gcu-broker` | **Platzhalter.** Wird nach Freigabe des GCU Bureau umgesetzt (`keeper/gcu.go`). Antwortet bis dahin mit `not_configured`. |
| `gcu-wagon-search` | **Platzhalter, bewusst nicht implementiert.** Automatisierte Abfrage von gcubureau.org nur mit schriftlicher Erlaubnis. |
| `era` | Fertig: Registerabfrage mit Antwort nach `vehicleinfo_2.0.xsd` (KeeperInformation). URL-Vorlage `ERA_URL` mit `{evn}`, optional `ERA_AUTH`. |
| `file` | Fertig: eigene JSON-Liste (`KEEPER_FILE`, Aufbau siehe `testdata/keepers.example.json`). |

## Start
```bash
go test ./...
KEEPER_SOURCES=file KEEPER_FILE=testdata/keepers.example.json go run ./cmd/keeper-api   # Test mit Beispieldaten
docker build -t keeper-api . && docker run -p 8080:8080 -e KEEPER_SOURCES=gcu-broker keeper-api
```
Weitere Variablen: `PORT`, `API_KEY` (API-Token, App sendet `X-Api-Key`), `LOGIN_PASSWORD` oder `LOGIN_PASSWORD_SHA256`
(Passwortschlüssel für den Reiter „Anmeldung“), `SESSION_DAYS` (30), `DATA_DIR` (`data`, `-` = keine Ablage),
`ALLOWED_ORIGINS`, `RATE_PER_MINUTE` (60, nur Halter-Abfrage), `CACHE_HOURS` (24).

Beispiel mit Anmeldung und Ablage:
```bash
API_KEY=$(openssl rand -hex 24) LOGIN_PASSWORD='…' DATA_DIR=/var/lib/schadwagen \
KEEPER_SOURCES=gcu-broker ./keeper-api
```
Für die Handy-Apps muss der Server per **HTTPS** erreichbar sein.

In der App: Einstellungen → Server-Verbindung → Server-Adresse (`https://…`) und API-Token, dann „Verbindung prüfen“.
Verlangt der Server eine Anmeldung, erscheint der Reiter „Anmeldung“ für den Passwortschlüssel.
