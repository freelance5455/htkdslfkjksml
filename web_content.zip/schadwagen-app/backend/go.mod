module schadwagen/backend

go 1.22
