# Schadwagen Management – Schadensprotokoll

App zur Erstellung von Schadensprotokollen für Güterwagen (AVV Anlage 4, Schadcodes nach AVV Anlage 9, Ausgabe 01.01.2026).
Eine Codebasis für **Android, iOS** (über Capacitor) und als **PWA** im Browser – offline lauffähig.

## Funktionen
- Formular entsprechend der GCU-Grunddatei (Allgemein, Wagenhalter, bis zu 3 Schäden, Bezettelung, Übernahme, Ursache, Kontakt)
- Schadcode-Eingabe mit Autovervollständigung (Code oder Suchbegriff) und Auswahl-Dialog nach Kategorie
- „Kein passender Schadcode“: Dokumentation über Kategorie + 2. Gliederungsebene (Anlage 9, Ziff. 2.2.4)
- Versand-/Empfangsbahnhof: Eingabe als Betriebsstellen-Abkürzung (Ril 100, z. B. `MBUH`) oder Name mit Vorschlagsliste (24.276 Betriebsstellen)
- Halter-Abfrage per Wagennummer über das eigene Backend (`backend/`, GET /api/keeper/{evn}), 30 Tage Zwischenspeicher
- Prüfung der UIC-Wagennummer (Prüfziffer), Pflichtfeldprüfung vor dem Erstellen
- **SENDEN** befüllt `GCU_Schadprotokoll_Grunddatei.pdf` automatisch und stellt die PDF zum Teilen/Download bereit; Fotos werden als Anlagenseiten angehängt
- Speichern von Entwürfen (lokal, IndexedDB), Einstellungen für EVU, Kontakt und Protokollnummer
- Server-Verbindung (Einstellungen): Adresse (nur https://) und API-Token (verschlüsselt: Android-Schlüsselspeicher bzw. Windows-DPAPI), „Verbindung prüfen“, Reiter „Anmeldung“ für den Passwortschlüssel, Latenz-Anzeige unten rechts (alle 15 s)
- Erweiterter Modus: Dashboard, Mitarbeiter (Positionstitel, Präfix mit eigener laufender Nummer, Berechtigungen mit Vorlagen, PIN-Wechsel), Gespeichert mit Filter und Import, Papierkorb (30 Tage)
- Automatische Zuordnung: beim Senden zum aktiven Mitarbeiter; importierte/eingehende Protokolle über das Präfix der Protokollnummer, ersatzweise über den Namen; Abgleich von Protokollen und Mitarbeitern mit dem Server
- Kopieren-Knopf neben allen E-Mail-Feldern
- Windows: Teilen-Menü mit „Per E-Mail senden“ (PDF als Anhang über MAPI, sonst mailto + PDF im Explorer markiert), „Per WhatsApp senden“ (WhatsApp Desktop bzw. WhatsApp Web, PDF im Explorer markiert) und „Speichern & im Explorer zeigen“
- Mitarbeiterliste nach Nachname mit Buchstabenleiste A–Z (Klick, Ziehen, Vergrößerung unter dem Mauszeiger), Suchfeld und Heranzoomen des Eintrags in der Listenmitte
- Mitarbeiter-Import/Export (JSON), PIN bei der ersten Anmeldung selbst festlegen
- „Aktuelle Bearbeitung“ im Mitarbeiterprofil: live, an welchem Protokoll der Mitarbeiter gerade arbeitet (dieses Gerät sofort, andere Geräte über `/api/presence` des Servers)

## Struktur
```
backend/                 Halter-Abfrage (Go, GET /api/keeper/{evn}, austauschbare Datenquellen)
windows/                 Windows-Programm (Go, eingebettete Web-App)
android/                 Android-Studio-Projekt (WebView + native Teilen/Speichern/Kamera)
www/                     Web-App (ohne Build-Schritt)
  assets/                GCU-Grunddatei (Formular, ohne Passwortschutz/Feldskripte)
  data/schadcodes.js     Schadcode-Datenbank für die App
  js/pdf/fillProtocol.js Feldzuordnung App -> PDF
database/                schadcodes.db (SQLite: Schadcodes + Betriebsstellen), schadcodes.json/.csv, betriebsstellen.json
tools/                   Extraktion der Schadcodes aus AVV Anlage 9
test/                    PDF-Test (Node)
```

## Starten
```bash
npm install
npm run serve            # Browser: http://localhost:8080
npm test                 # erzeugt test/out_form.pdf und test/out_flat.pdf
node test/evn.test.mjs   # Prüfziffer-Test
(cd backend && go test ./...)
```

## Android (Android Studio)
1. ZIP entpacken (nicht im ZIP öffnen).
2. Android Studio → **File › Open** → den Ordner **`schadwagen-app/android`** wählen (nicht den Hauptordner).
3. Gradle-Sync abwarten (lädt beim ersten Mal Gradle 8.14.3 und die Android-Bibliotheken), dann ▶ **Run** auf Gerät oder Emulator.

Die Web-App aus `www/` wird beim Build automatisch in die App kopiert – Änderungen an `www/` sind nach erneutem Run in der App. Kein `npm install` nötig.
Die Ordnerstruktur `android/` neben `www/` muss erhalten bleiben.

## Windows
`windows/Schadensprotokoll.exe` ist ein eigenständiges Programm (keine Installation): Es startet die App lokal und öffnet sie in einem eigenen Fenster über Microsoft Edge (vorinstalliert ab Windows 10).
- Protokolle bleiben gespeichert (Profil unter `%LOCALAPPDATA%\Schadensprotokoll`).
- PDFs werden in `Dokumente\Schadensprotokolle` abgelegt und im Explorer markiert.
- Neu bauen: `windows/build.sh` (Go ≥ 1.22). Programmsymbol: `python3 tools/make_syso.py`.

## iOS
```bash
npm install
npx cap add ios          # einmalig (macOS + Xcode)
npm run ios              # öffnet Xcode
```
iOS: in `ios/App/App/Info.plist` ergänzen:
`NSCameraUsageDescription` und `NSPhotoLibraryUsageDescription` (Fotos als Anlagen).

## Schadcode-Datenbank neu erzeugen
```bash
pip install pdfplumber
ANLAGE9=/pfad/GCU_AVV_2026_ANLAGE_9.pdf npm run db:build
```

## Feldzuordnung (Auszug)
| App | PDF-Feld |
|---|---|
| EVU-Nr./Name (Einstellungen) | UserRU, UserRU_Name |
| Protokoll-Nr. | ReportID |
| Wagennummer | WagonNumberFreight (Format 33-80-7819-484-1) |
| Ladezustand | LoadingStatus (1 = Beladen, 0 = Leer) |
| Schadcode | DamageN_CodeDigit1–4 |
| Zusätzliche Bemerkungen (je Schaden) | DamageN_Description (leer = Katalogtext) |
| Neu/Alt | DamageN_OldDamage (0 = Neu, 1 = Alt) |
| Anmerkungen | Remarks |
| Ursache: Verschleiß / eigenes EVU / Dritter / nicht ermittelbar | DamageCategory: Wear / ImpactDamage / ThirdParty / NotAscertainable |
| Ort + Datum der Feststellung | Signature_PlaceDate |
| Kontakt Name/E-Mail/Telefon | ContactUserRU |

Lizenzen: pdf-lib (MIT, `www/vendor`).
