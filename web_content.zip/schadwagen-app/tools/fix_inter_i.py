#!/usr/bin/env python3
"""Inter (Fließtext 400/500/600): i- und j-Punkt etwas kleiner und mit mehr Abstand zum Strich.

Grund: In Inter ist die Lücke zwischen i-Punkt und Strich sehr klein (171/2048 em ≈ 1,25 px bei
15 px Schrift). Unter Windows verschwimmt sie auf dunklem Hintergrund, das „i“ wirkt dann wie ein
großes „I“ bzw. „l“ (z. B. „Mitarbeiter“, „Gespeichert“, „Papierkorb“ in der Seitenleiste).
Hier wird der Punkt um 14 % verkleinert und so angehoben, dass die Lücke 235/2048 em beträgt
(≈ 1,7 px bei 15 px, ≈ 2,2 px bei 125 % Windows-Skalierung). Breiten, Abstände und alle anderen
Zeichen bleiben unverändert. Mehrfaches Ausführen ändert nichts mehr (Prüfung über die Lücke).
Inter steht unter der SIL Open Font License 1.1 – Änderungen sind erlaubt (siehe fonts/Inter-LICENSE.txt).

Aufruf: python3 tools/fix_inter_i.py   (bearbeitet www/fonts/inter-400/500/600.woff)
"""
import os, sys
from fontTools.ttLib import TTFont
from fontTools.pens.recordingPen import RecordingPen

HERE = os.path.dirname(os.path.abspath(__file__))
FONTS = os.path.join(HERE, '..', 'www', 'fonts')
FILES = ['inter-400.woff', 'inter-500.woff', 'inter-600.woff']
GAP = 235      # Ziel-Lücke Strich -> Punkt (Einheiten, UPM 2048)
SCALE = 0.86   # Punktgröße


def contours(rec):
    out, cur = [], []
    for op, args in rec.value:
        cur.append((op, args))
        if op in ('closePath', 'endPath'):
            out.append(cur); cur = []
    if cur: out.append(cur)
    return out


def bbox(c):
    pts = [p for _, a in c for p in a]
    xs, ys = [p[0] for p in pts], [p[1] for p in pts]
    return min(xs), min(ys), max(xs), max(ys)


def fix(path):
    # Kopf- und hhea-Werte unverändert lassen (nur i und j werden geändert)
    f = TTFont(path, recalcBBoxes=False, recalcTimestamp=False)
    top = f['CFF '].cff.topDictIndex[0]
    cs = top.CharStrings
    gs = f.getGlyphSet()
    cmap = f.getBestCmap()
    xh = f['OS/2'].sxHeight
    changed = []
    for ch in 'ij':
        name = cmap[ord(ch)]
        rec = RecordingPen(); gs[name].draw(rec)
        cons = contours(rec)
        dots = [c for c in cons if bbox(c)[1] > xh]
        stems = [c for c in cons if bbox(c)[1] <= xh]
        if len(dots) != 1 or not stems:
            sys.exit(f'{os.path.basename(path)} {ch}: unerwarteter Aufbau')
        x0, y0, x1, y1 = bbox(dots[0])
        stem_top = max(bbox(c)[3] for c in stems)
        if y0 - stem_top >= GAP - 2:
            print(f'{os.path.basename(path)} {ch}: schon angepasst'); continue
        cx = (x0 + x1) / 2
        ny0 = stem_top + GAP
        nh = round((y1 - y0) * SCALE)
        nw = round((x1 - x0) * SCALE)
        nx0 = round(cx - nw / 2)

        # Original-Programm übernehmen und nur die Zahlen für den Punkt ändern – Breite, Hinting
        # (hstemhm/hintmask) und der Strich bleiben exakt erhalten.
        c = cs[name]; c.decompile()
        prog = list(c.program)
        ih = prog.index('hstemhm')
        args = prog[:ih]
        lead = 1 if len(args) % 2 else 0          # erste Zahl = Breite (relativ zu nominalWidthX)
        st = args[lead:]
        edges, pos = [], 0
        for k in range(0, len(st), 2):
            pos += st[k]; edges.append([pos, st[k + 1]]); pos += st[k + 1]
        for e in edges:                            # waagerechter Hint des Punkts (falls vorhanden)
            if e[0] > stem_top + 20 and e[1] > 0:
                e[0], e[1] = ny0, nh
        st2, pos = [], 0
        for b0, w in edges:
            st2 += [b0 - pos, w]; pos = b0 + w
        im = prog.index('hintmask')
        vargs = prog[ih + 1:im]
        vedges, pos = [], 0
        for k in range(0, len(vargs), 2):
            pos += vargs[k]; vedges.append([pos, vargs[k + 1]]); pos += vargs[k + 1]
        hit = [e for e in vedges if abs(e[0] - x0) <= 2 and abs(e[0] + e[1] - x1) <= 2]
        if len(hit) != 1:
            sys.exit(f'{os.path.basename(path)} {ch}: senkrechter Hint des Punkts nicht gefunden {vedges} {x0, x1}')
        # Hints müssen aufsteigend sortiert bleiben: Punkt-Hint ggf. um 1–2 Einheiten verbreitern
        k = vedges.index(hit[0])
        hx0, hx1 = nx0, nx0 + nw
        if k + 1 < len(vedges): hx0 = min(hx0, vedges[k + 1][0])
        if k > 0: hx0 = max(hx0, vedges[k - 1][0])
        hit[0][0], hit[0][1] = hx0, max(hx1, nx0 + nw) - hx0
        if [e[0] for e in vedges] != sorted(e[0] for e in vedges):
            sys.exit(f'{os.path.basename(path)} {ch}: Hints nicht aufsteigend {vedges}')
        va2, pos = [], 0
        for b0, w in vedges:
            va2 += [b0 - pos, w]; pos = b0 + w
        # Punkt-Kontur: rmoveto nach dem zweiten hintmask, danach vier rrcurveto
        im2 = [i for i, x in enumerate(prog) if x == 'hintmask'][1]
        rm = prog.index('rmoveto', im2)
        dx, dy = prog[rm - 2], prog[rm - 1]
        curves, i = [], rm + 1
        while prog[i] != 'endchar':
            if isinstance(prog[i], str) and prog[i] != 'rrcurveto':
                sys.exit(f'{os.path.basename(path)} {ch}: unerwarteter Befehl im Punkt: {prog[i]}')
            i += 1
        segs = prog[rm + 1:i]
        nums = [x for x in segs if not isinstance(x, str)]
        if len(nums) != 24:
            sys.exit(f'{os.path.basename(path)} {ch}: Punkt hat {len(nums)} Werte statt 24')
        sn = [round(v * SCALE) for v in nums]
        # Kontur exakt schließen (Summe aller Verschiebungen = 0)
        sn[22] -= sum(sn[0::2]); sn[23] -= sum(sn[1::2])
        newdot = []
        for k in range(4):
            newdot += sn[k * 6:(k + 1) * 6] + ['rrcurveto']
        new = args[:lead] + st2 + ['hstemhm'] + va2 + prog[im:rm - 2] + [dx, dy + (ny0 - y0), 'rmoveto'] + newdot + ['endchar']
        c.program = new
        c.bytecode = None
        cs[name] = c
        # Kontrolle: neue Kontur nachmessen
        rec2 = RecordingPen(); c.draw(rec2)
        d2 = [k for k in contours(rec2) if bbox(k)[1] > xh]
        bx = bbox(d2[0])
        if abs(bx[1] - ny0) > 1 or abs((bx[3] - bx[1]) - nh) > 3 or abs((bx[0] + bx[2]) / 2 - cx) > 2:
            sys.exit(f'{os.path.basename(path)} {ch}: Kontrolle fehlgeschlagen {bx}')
        changed.append(f'{ch}: Lücke {y0 - stem_top} -> {GAP}, Punkt {y1 - y0} -> {nh}')
    if changed:
        f.flavor = 'woff'
        f.save(path)
    check(path)
    print(os.path.basename(path), '·', '; '.join(changed) or 'unverändert')


def check(path):
    """Sicherheitsprüfung: Laufweite jedes Zeichens im CFF muss der hmtx-Tabelle entsprechen."""
    from fontTools.pens.basePen import NullPen
    f = TTFont(path)
    cs = f['CFF '].cff.topDictIndex[0].CharStrings
    bad = []
    for g in f.getGlyphOrder():
        c = cs[g]; c.decompile(); c.draw(NullPen())
        if c.width != f['hmtx'][g][0]:
            bad.append((g, c.width, f['hmtx'][g][0]))
    if bad:
        sys.exit(f'FEHLER {os.path.basename(path)}: abweichende Laufweiten {bad[:5]}')


if __name__ == '__main__':
    for fn in FILES:
        fix(os.path.join(FONTS, fn))
