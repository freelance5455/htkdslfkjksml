"""Erzeugt alle App-Symbole aus resources/icon-source.png (1024 px, abgerundetes Quadrat auf weißem Grund,
Logo und Schrift bereits entfernt). Aufruf: python3 tools/make_icons.py

Ergebnis:
  resources/icon.png              1024 vollflächig (ohne Rundung) – Vorlage für iOS/Capacitor und Stores
  resources/icon-rounded.png      1024 mit transparenten, abgerundeten Ecken – Windows-Programmsymbol (make_syso.py)
  www/icons/…                     PWA/Browser: 192/512 (any), 512 maskable, Favicon (ICO 16/32/48, PNG 32), Apple-Touch 180,
                                  brand-logo.png 132 (Logo oben links in der Seitenleiste)
  android/…/mipmap-*/…            Launcher-Symbole aller Dichten, rundes Symbol, adaptives Symbol (Vordergrund + Verlauf)
"""
import io, pathlib, struct
import numpy as np
from PIL import Image, ImageDraw, ImageFilter
import cv2

root = pathlib.Path(__file__).resolve().parent.parent
src = cv2.imread(str(root / 'resources/icon-source.png'))  # BGR, 1024
N = src.shape[0]
RADIUS = 164  # Eckradius der Vorlage (gemessen)

def rounded_mask(size, radius, ss=4):
    m = Image.new('L', (size * ss, size * ss), 0)
    ImageDraw.Draw(m).rounded_rectangle((0, 0, size * ss - 1, size * ss - 1), radius * ss, fill=255)
    return m.resize((size, size), Image.LANCZOS)

def circle_mask(size, ss=4):
    m = Image.new('L', (size * ss, size * ss), 0)
    ImageDraw.Draw(m).ellipse((0, 0, size * ss - 1, size * ss - 1), fill=255)
    return m.resize((size, size), Image.LANCZOS)

# ---------- vollflächige Fassung: weiße Ecken und hellen Rand oben durch Hintergrund ersetzen ----------
b, g, r = [src[:, :, i].astype(int) for i in range(3)]
white = (b > 235) & (g > 235) & (r > 235)
inside = ~white
dist = cv2.distanceTransform(np.pad(inside.astype(np.uint8), 1), cv2.DIST_L2, 5)[1:-1, 1:-1]  # Bildrand zählt als Kante
lum = 0.299 * r + 0.587 * g + 0.114 * b
yy = np.mgrid[0:N, 0:N][0]
rim = inside & (dist < 18) & (yy < N * 0.5) & (lum > 112) & (np.abs(r - b) < 25)
fill = (white | rim).astype(np.uint8) * 255
fill = cv2.dilate(fill, np.ones((5, 5), np.uint8))
full = cv2.inpaint(src, fill, 25, cv2.INPAINT_TELEA)
full_rgb = Image.fromarray(cv2.cvtColor(full, cv2.COLOR_BGR2RGB))

# Hintergrundverlauf (oben/unten) für adaptive und maskierbare Symbole
top = full[40:80, 380:640].reshape(-1, 3).mean(0)[::-1]
bot = full[980:1015, 380:640].reshape(-1, 3).mean(0)[::-1]
hexc = lambda c: '#%02X%02X%02X' % tuple(int(round(x)) for x in c)
print('Hintergrund oben/unten:', hexc(top), hexc(bot))

def gradient(size):
    t = np.linspace(0, 1, size)[:, None, None]
    arr = (top[None, None, :] * (1 - t) + bot[None, None, :] * t).repeat(size, 1)
    return Image.fromarray(arr.astype(np.uint8), 'RGB')

def feathered(img, size, feather):
    """Bild auf size skalieren, Ränder weich ausblenden (fügt sich in den Verlauf ein)."""
    im = img.resize((size, size), Image.LANCZOS).convert('RGBA')
    f = max(1, int(feather))
    ramp = np.clip(np.arange(size) / f, 0, 1)
    ramp = np.minimum(ramp, ramp[::-1])
    ramp = ramp * ramp * (3 - 2 * ramp)  # smoothstep
    a = np.minimum(ramp[None, :], ramp[:, None])
    im.putalpha(Image.fromarray((a * 255).astype(np.uint8)))
    return im

def composed(size, content=0.8, feather=0.06, bg=True):
    """Verlauf + Motiv mittig (für maskierbare/adaptive Symbole)."""
    canvas = gradient(size).convert('RGBA') if bg else Image.new('RGBA', (size, size), (0, 0, 0, 0))
    s = int(round(size * content))
    fg = feathered(full_rgb, s, s * feather)
    canvas.alpha_composite(fg, ((size - s) // 2, (size - s) // 2))
    return canvas

def sharpen_small(im, size):
    if size <= 24: return im.filter(ImageFilter.UnsharpMask(radius=0.6, percent=140, threshold=1))
    if size <= 48: return im.filter(ImageFilter.UnsharpMask(radius=0.7, percent=110, threshold=1))
    if size <= 96: return im.filter(ImageFilter.UnsharpMask(radius=0.8, percent=60, threshold=2))
    return im

rounded = full_rgb.convert('RGBA')
rounded.putalpha(rounded_mask(N, RADIUS))

def rounded_at(size):
    im = full_rgb.resize((size, size), Image.LANCZOS).convert('RGBA')
    im = sharpen_small(im, size)
    im.putalpha(rounded_mask(size, RADIUS * size / N))
    return im

def full_at(size):
    return sharpen_small(full_rgb.resize((size, size), Image.LANCZOS), size)

def save(im, path):
    p = root / path
    p.parent.mkdir(parents=True, exist_ok=True)
    im.save(p, optimize=True)
    return p

# ---------- Vorlagen ----------
save(full_rgb, 'resources/icon.png')
save(rounded, 'resources/icon-rounded.png')
save(composed(1024, 0.72, 0.06, bg=False), 'resources/icon-foreground.png')
save(gradient(1024), 'resources/icon-background.png')

# ---------- PWA / Browser ----------
save(rounded_at(192), 'www/icons/icon-192.png')
save(rounded_at(512), 'www/icons/icon-512.png')
save(composed(512, 0.8, 0.05).convert('RGB'), 'www/icons/icon-maskable-512.png')
save(composed(192, 0.8, 0.05).convert('RGB'), 'www/icons/icon-maskable-192.png')
save(full_at(180), 'www/icons/apple-touch-icon.png')
save(rounded_at(32), 'www/icons/favicon-32.png')
save(rounded_at(132), 'www/icons/brand-logo.png')  # Programmlogo oben links in der Seitenleiste (44 px, 3-fach)
ico_imgs = [rounded_at(s) for s in (16, 32, 48)]
ico_imgs[-1].save(root / 'www/favicon.ico', sizes=[(16, 16), (32, 32), (48, 48)], append_images=ico_imgs[:-1])

# ---------- Android ----------
res = 'android/app/src/main/res'
dens = {'mdpi': 1, 'hdpi': 1.5, 'xhdpi': 2, 'xxhdpi': 3, 'xxxhdpi': 4}
for d, f in dens.items():
    s = int(48 * f)
    save(rounded_at(s), f'{res}/mipmap-{d}/ic_launcher.png')
    rnd = composed(s * 4, 0.9, 0.05).resize((s, s), Image.LANCZOS)
    rnd = sharpen_small(rnd, s)
    rnd.putalpha(circle_mask(s))
    save(rnd, f'{res}/mipmap-{d}/ic_launcher_round.png')
    a = int(108 * f)
    save(composed(a, 0.72, 0.06, bg=False), f'{res}/mipmap-{d}/ic_launcher_foreground.png')
(root / f'{res}/mipmap-anydpi-v26').mkdir(parents=True, exist_ok=True)
adaptive = '''<?xml version="1.0" encoding="utf-8"?>
<!-- Adaptives Symbol: Vordergrund = Kesselwagen (mit weichem Rand), Hintergrund = dunkelgrauer Verlauf -->
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@drawable/ic_launcher_background" />
    <foreground android:drawable="@mipmap/ic_launcher_foreground" />
</adaptive-icon>
'''
for name in ('ic_launcher', 'ic_launcher_round'):
    (root / f'{res}/mipmap-anydpi-v26/{name}.xml').write_text(adaptive, encoding='utf-8')
(root / f'{res}/drawable').mkdir(parents=True, exist_ok=True)
(root / f'{res}/drawable/ic_launcher_background.xml').write_text(f'''<?xml version="1.0" encoding="utf-8"?>
<!-- Hintergrund des adaptiven Symbols: Verlauf wie im Symbol (oben {hexc(top)}, unten {hexc(bot)}) -->
<shape xmlns:android="http://schemas.android.com/apk/res/android" android:shape="rectangle">
    <gradient android:angle="270" android:startColor="{hexc(top)}" android:endColor="{hexc(bot)}" />
</shape>
''', encoding='utf-8')
(root / f'{res}/values/ic_launcher_background.xml').write_text(f'''<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="ic_launcher_background">{hexc(bot)}</color>
</resources>
''', encoding='utf-8')
print('fertig')
