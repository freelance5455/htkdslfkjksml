# Erzeugt www/data/schadcodes.js aus database/schadcodes.json
import json, pathlib
root = pathlib.Path(__file__).resolve().parent.parent
d = json.loads((root / 'database/schadcodes.json').read_text(encoding='utf-8'))
(root / 'www/data/schadcodes.js').write_text('export default ' + json.dumps(d, ensure_ascii=False) + ';\n', encoding='utf-8')
print(len(d['codes']), 'Codes exportiert')
