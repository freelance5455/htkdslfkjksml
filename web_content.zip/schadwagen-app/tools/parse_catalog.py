import pdfplumber, re, json, sys
from pdfplumber.utils import extract_text
SRC=sys.argv[1]; OUT=sys.argv[2]
pdf=pdfplumber.open(SRC)
CODE_RE=re.compile(r'^\d+(\.\d+)*\.?$')
SUP=str.maketrans('0123456789)','⁰¹²³⁴⁵⁶⁷⁸⁹⁾')
PUA={chr(0xF030+i):str(i) for i in range(10)}
PUA[chr(0xF029)]=')'

def prep(chs,keep_sup=True):
    out=[]
    for ch in chs:
        ch=dict(ch)
        t=ch['text']
        if t in PUA: t=PUA[t]; ch['_pua']=True
        if (ch['size']<7.5 or ch.get('_pua')) and t in '0123456789)':
            t=t.translate(SUP) if keep_sup else ''
        ch['text']=t
        if not t: continue
        out.append(ch)
    return out

def lines_text(chs,keep_sup=True):
    chs=prep(chs,keep_sup)
    if not chs: return ''
    normal=[c for c in chs if c['size']>=9]
    small=[c for c in chs if c['size']<9]
    normal.sort(key=lambda c:c['top'])
    clusters=[]
    for c in normal:
        if clusters and c['top']-clusters[-1]['t']<=3.0:
            clusters[-1]['c'].append(c); clusters[-1]['t']=sum(x['top'] for x in clusters[-1]['c'])/len(clusters[-1]['c'])
        else: clusters.append({'t':c['top'],'c':[c]})
    if not clusters:
        clusters=[{'t':small[0]['top'],'c':[]}]
    for s in small:
        # nearest line by vertical centre
        sc=(s['top']+s['bottom'])/2
        best=min(clusters,key=lambda k:abs(sc-(k['t']+5)))
        if abs(sc-(best['t']+5))<=9: best['c'].append(s)
        else: clusters.append({'t':s['top'],'c':[s]})
    clusters.sort(key=lambda k:k['t'])
    res=[]
    for k in clusters:
        k['c'].sort(key=lambda c:c['x0'])
        res.append(extract_text(k['c'],x_tolerance=2.5,y_tolerance=30))
    return '\n'.join(r for r in res if r and r.strip())

entries=[]; footn={}
MARK=('-','−','–','•')
def cluster_lines(chars):
    """-> list of dict(top,text,first) sorted"""
    chars=prep(chars,True)
    normal=sorted([c for c in chars if c['size']>=9],key=lambda c:c['top'])
    small=[c for c in chars if c['size']<9]
    cl=[]
    for c in normal:
        if cl and c['top']-cl[-1]['t']<=3.0:
            cl[-1]['c'].append(c); cl[-1]['t']=sum(x['top'] for x in cl[-1]['c'])/len(cl[-1]['c'])
        else: cl.append({'t':c['top'],'c':[c]})
    if not cl and small: cl=[{'t':small[0]['top'],'c':[]}]
    for sm in small:
        sc=(sm['top']+sm['bottom'])/2
        best=min(cl,key=lambda k:abs(sc-(k['t']+5)))
        if abs(sc-(best['t']+5))<=9: best['c'].append(sm)
        else: cl.append({'t':sm['top'],'c':[sm]})
    cl.sort(key=lambda k:k['t'])
    out=[]
    for k in cl:
        k['c'].sort(key=lambda c:c['x0'])
        t=extract_text(k['c'],x_tolerance=2.5,y_tolerance=30)
        if t and t.strip(): out.append({'top':k['t'],'text':t.strip()})
    return out
def blocks(lines,gap=13.5):
    bl=[]
    for l in lines:
        if bl and l['top']-bl[-1][-1]['top']<=gap: bl[-1].append(l)
        else: bl.append([l])
    return bl
for pn in range(9,59):
    pg=pdf.pages[pn-1]
    ws=pg.extract_words(extra_attrs=['size'])
    hw={w['text']:w for w in ws if w['top']<130 and w['size']>=9.5 and w['text'] in ('Code','klasse')}
    if 'Code' not in hw or 'klasse' not in hw:
        print('no header',pn); continue
    xs=sorted(set(round(r['x0']) for r in pg.rects if r['width']<3 and r['height']>=20))
    cl_=[]
    for x in xs:
        if cl_ and x-cl_[-1][-1]<=3: cl_[-1].append(x)
        else: cl_.append([x])
    b=[sum(c)/len(c) for c in cl_]
    if len(b)!=6: print('borders',pn,b)
    b0,b1,b2,b3,b4,b5=b[:6]
    body_top=hw['klasse']['bottom']+1
    vr=[r for r in pg.rects if r['width']<3 and r['height']>=20]
    table_bottom=max(r['bottom'] for r in pg.rects if r['width']<3)
    body_chars=[c for c in pg.chars if body_top<=c['top'] and c['bottom']<=table_bottom+0.5]
    code_chars=[c for c in body_chars if b1<=c['x0']<b2 and c['size']>=9.5 and c['text'] not in PUA]
    code_chars.sort(key=lambda c:c['top'])
    lines=[]
    for c in code_chars:
        if lines and abs(c['top']-lines[-1][0]['top'])<=2.5: lines[-1].append(c)
        else: lines.append([c])
    anc=[]
    for l in lines:
        s_=''.join(c['text'] for c in sorted(l,key=lambda c:c['x0'])).strip()
        if CODE_RE.match(s_): anc.append((l[0]['top'],s_.rstrip('.')))
    def col(x0,x1): return [c for c in body_chars if x0<=c['x0']<x1]
    tl=cluster_lines(col(b2,b3)); ml=cluster_lines(col(b3,b4)); kl=cluster_lines([c for c in col(b4,b5) if c['text'].strip()])
    # part groups via stream contiguity
    groups=[]; cur=None
    for c in pg.chars:
        if not (body_top<=c['top'] and c['bottom']<=table_bottom+0.5): continue
        if b0<=c['x0']<b1 and c['text'].strip():
            if cur is None: cur=[]; groups.append(cur)
            cur.append(c)
        elif c['text'].strip() and cur is not None: cur=None
    E_=[dict(code=s_,page=pn,top=t,part=[],text=[],preface=[],measure=[],cls=[]) for t,s_ in anc]
    cont=dict(code=None,page=pn,part=[],text=[],preface=[],measure=[],cls=[])
    tops=[e['top']-3 for e in E_]
    def seg_index(y):
        idx=-1
        for i_,t in enumerate(tops):
            if y>=t: idx=i_
        return idx
    merged=[]
    for g in groups:
        if merged:
            prevt=lines_text(merged[-1]).rstrip()
            gap=min(c['top'] for c in g)-max(c['top'] for c in merged[-1])
            if prevt.endswith((',','-')) and gap<=20:
                merged[-1]=merged[-1]+g; continue
        merged.append(list(g))
    for g in merged:
        gt=min(c['top'] for c in g); i_=seg_index(gt)
        (E_[i_] if i_>=0 else cont)['part'].append(lines_text(g))
    # text lines by segment
    segl={}
    for l in tl: segl.setdefault(seg_index(l['top']),[]).append(l)
    for i_,ls in segl.items():
        tgt=E_[i_] if i_>=0 else cont
        tgt['text']=ls
    # preface logic
    for i_ in range(len(E_)-1):
        ls=E_[i_]['text']
        if not ls: continue
        bls=blocks(ls)
        nxt=E_[i_+1]['text']
        if len(bls)>=2 and nxt and nxt[0]['text'][0] in MARK and bls[-1][0]['text'][0] not in ('•','-','−','–') and not bls[-1][0]['text'][0].islower():
            E_[i_+1]['preface']=bls[-1]
            E_[i_]['text']=[l for bl in bls[:-1] for l in bl]
    # class: nearest anchor
    for l in kl:
        if not E_: break
        j=min(range(len(E_)),key=lambda i_:abs(E_[i_]['top']-l['top']))
        E_[j]['cls'].append(l['text'])
    # measure: split into blocks (gap or anchor-aligned start), assign to nearest anchor
    mb=[]
    claimed=set()
    for l in ml:
        near=[j for j in range(len(E_)) if abs(E_[j]['top']-l['top'])<=3.5 and j not in claimed]
        start = (not mb) or (l['top']-mb[-1][-1]['top']>13.5) or bool(near and l['top']-mb[-1][-1]['top']>9)
        if start:
            mb.append([l])
        else: mb[-1].append(l)
        if near and start: claimed.add(near[0])
    for bl in mb:
        if not E_: cont['measure']+=bl; continue
        y=bl[0]['top']
        if y<E_[0]['top']-14:
            cont['measure']+=bl; continue
        j=min(range(len(E_)),key=lambda i_:abs(E_[i_]['top']-y))
        E_[j]['measure']+=bl
    ftxt=''
    fchars=[c for c in pg.chars if c['top']>table_bottom+2 and c['bottom']<770]
    if fchars: ftxt=extract_text(prep(fchars,True),x_tolerance=2.5,y_tolerance=3)
    footn[pn]=ftxt
    for e in ([cont] if (cont['text'] or cont['measure'] or cont['part']) else [])+E_:
        e['textstr']='\n'.join(l['text'] for l in e['text'])
        e['prefacestr']='\n'.join(l['text'] for l in e['preface'])
        e['measurestr']='\n'.join(l['text'] for l in e['measure'])
        e['clsstr']=' '.join(e['cls'])
        e['partstr']=' '.join(e['part'])
        for k in ('text','preface','measure','cls','part'): e.pop(k)
        e.pop('top',None)
        entries.append(e)
json.dump({'entries':entries,'footnotes':footn},open(OUT,'w'),ensure_ascii=False,indent=1)
print(len(entries))
