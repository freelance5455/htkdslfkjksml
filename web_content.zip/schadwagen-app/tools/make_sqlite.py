#!/usr/bin/env python3
"""Erzeugt database/schadcodes.db (SQLite: Schadcodes + Betriebsstellen) aus den JSON-Dateien neu.

Die .db liegt nicht im verkleinerten Projekt-ZIP (sie ist vollständig aus database/schadcodes.json und
database/betriebsstellen.json ableitbar). Aufruf:  python3 tools/make_sqlite.py
Prüfen gegen eine vorhandene Datei:               python3 tools/make_sqlite.py --check alt.db
"""
import json, os, sqlite3, sys

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
DBDIR = os.path.join(ROOT, 'database')
SCHEMA = '''
CREATE TABLE kategorien(nr INTEGER PRIMARY KEY, name TEXT NOT NULL);
CREATE TABLE fehlerklassen(klasse INTEGER PRIMARY KEY, bezeichnung TEXT, definition TEXT, wert REAL);
CREATE TABLE aussetzen(kuerzel TEXT PRIMARY KEY, bedeutung TEXT);
CREATE TABLE schadcodes(
 code TEXT PRIMARY KEY, ebene INTEGER, kategorie INTEGER REFERENCES kategorien(nr), eltern TEXT,
 titel TEXT, kurztext TEXT, anzeige TEXT, komponente TEXT, bauteil TEXT, pfad TEXT,
 beschreibung TEXT, kriterien TEXT, hinweise TEXT, kontext TEXT, massnahme TEXT,
 fehlerklasse INTEGER, auswaehlbar INTEGER, frei INTEGER, fussnoten TEXT, seite INTEGER,
 stelle1 TEXT, stelle2 TEXT, stelle3 TEXT, stelle4 TEXT);
CREATE INDEX idx_kat ON schadcodes(kategorie); CREATE INDEX idx_eltern ON schadcodes(eltern);
CREATE TABLE betriebsstellen(code TEXT PRIMARY KEY, name TEXT NOT NULL, typ TEXT, zustand TEXT);
CREATE INDEX idx_bs_name ON betriebsstellen(name);
'''


def build(path):
    s = json.load(open(os.path.join(DBDIR, 'schadcodes.json'), encoding='utf-8'))
    b = json.load(open(os.path.join(DBDIR, 'betriebsstellen.json'), encoding='utf-8'))
    if os.path.exists(path):
        os.remove(path)
    con = sqlite3.connect(path)
    cu = con.cursor()
    cu.executescript(SCHEMA)
    cu.executemany('INSERT INTO kategorien VALUES(?,?)', [(k['nr'], k['name']) for k in s['kategorien']])
    cu.executemany('INSERT INTO fehlerklassen VALUES(?,?,?,?)', [(f['klasse'], f['bezeichnung'], f['definition'], f['wert']) for f in s['fehlerklassen']])
    cu.executemany('INSERT INTO aussetzen VALUES(?,?)', list(s['aussetzen'].items()))
    for o in s['codes']:
        sg = (o['code'].split('.') + ['', '', '', ''])[:4]
        cu.execute('INSERT INTO schadcodes VALUES(' + ','.join('?' * 24) + ')', (
            o['code'], o['ebene'], o['kategorie'], o['eltern'], o['titel'], o['kurztext'], o['anzeige'], o['komponente'], o['bauteil'],
            ' › '.join(o['pfad']), o['beschreibung'], ' | '.join(o['kriterien']), ' | '.join(o['hinweise']), o['kontext'], o['massnahme'],
            o['fehlerklasse'], int(o['auswaehlbar']), int(o['frei']), ' | '.join(o['fussnoten']), o['seite'], *sg))
    cols = b['spalten']
    cu.executemany('INSERT INTO betriebsstellen VALUES(?,?,?,?)', [tuple(r[cols.index(c)] for c in ('code', 'name', 'typ', 'zustand')) for r in b['daten']])
    con.commit()
    con.close()


def dump(path):
    con = sqlite3.connect(path)
    out = {}
    for (t,) in con.execute("select name from sqlite_master where type='table' order by name"):
        out[t] = sorted(con.execute(f'select * from {t}').fetchall(), key=repr)
    con.close()
    return out


if __name__ == '__main__':
    if len(sys.argv) == 3 and sys.argv[1] == '--check':
        tmp = os.path.join(DBDIR, '_neu.db')
        build(tmp)
        a, n = dump(sys.argv[2]), dump(tmp)
        os.remove(tmp)
        same = a == n
        print('identisch' if same else 'UNTERSCHIED', {t: len(v) for t, v in n.items()})
        sys.exit(0 if same else 1)
    target = os.path.join(DBDIR, 'schadcodes.db')
    build(target)
    print('erzeugt:', target, {t: len(v) for t, v in dump(target).items()})
