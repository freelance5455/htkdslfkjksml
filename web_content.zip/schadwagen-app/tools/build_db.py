import json, re, sqlite3, csv, collections, sys
RAW=sys.argv[1]; OUTDIR=sys.argv[2]
d=json.load(open(RAW))
SUPMAP={c:str(i) for i,c in enumerate('⁰¹²³⁴⁵⁶⁷⁸⁹')}
SUPRE=re.compile(r'([⁰¹²³⁴⁵⁶⁷⁸⁹]+)⁾')
def supnum(m): return ''.join(SUPMAP[c] for c in m)
MARK=('-','−','–')
def dehy(t):
    t=re.sub(r'-\n(?=(und|oder|bzw\.)\b)','- ',t)
    t=re.sub(r'(?<=[a-zäöüß])-\n(?=[a-zäöüß])','',t)          # Wa-\ngen
    t=re.sub(r'(?<=[A-Za-zÄÖÜäöüß])-\n(?=[A-ZÄÖÜ])','-',t)       # Radsatz-\nLager -> keep hyphen
    return t
def one(t):
    t=re.sub(r'[….]{4,}',' ',t)
    return re.sub(r'\s+',' ',t).strip()
def strip_sup(t):
    t=SUPRE.sub('',t)
    t=re.sub(r'(?<=[A-Za-zäöüÄÖÜß])\d{1,2}\)','',t)
    return re.sub(r'\s+',' ',t).strip()

# --- merge conts, prefaces ---
entries=[]
pending_cont=None
for e in d['entries']:
    if e['code'] is None:
        if e['page']==36: continue
        pending_cont=e; continue
    if pending_cont is not None and pending_cont['page']==e['page']:
        txt=pending_cont['textstr'].strip()
        if txt and not e['prefacestr']:
            e['prefacestr']=txt
        pending_cont=None
    entries.append(e)
byc={e['code']:e for e in entries}
children=collections.defaultdict(list)
for e in entries:
    p=e['code'].rsplit('.',1)[0] if '.' in e['code'] else None
    e['parent']=p if p in byc else None
    if e['parent']: children[e['parent']].append(e['code'])

def parse_text(t):
    t=dehy(t)
    lead=[];crit=[];hint=[]
    cur=None
    for ln in t.split('\n'):
        ln=ln.strip()
        if not ln: continue
        if ln[0] in MARK:
            crit.append(ln[1:].strip()); cur=crit
        elif ln[0]=='•':
            hint.append(ln[1:].strip()); cur=hint
        elif cur is None:
            lead.append(ln)
        else:
            cur[-1]+=' '+ln
    return one(' '.join(lead)), [one(x) for x in crit], [one(x) for x in hint]

for e in entries:
    e['lead'],e['crit'],e['hint']=parse_text(e['textstr'])
    e['pref']=one(dehy(e['prefacestr']))
    e['raw_all']=e['textstr']+' '+e['prefacestr']+' '+e['measurestr']+' '+e['partstr']
    pt=dehy(e['partstr']).replace('\n',' ')
    e['part']=one(pt)

# inherit measure for merged cells (brace) + preface from marker-led siblings
for p,kids in children.items():
    prev=None; prefctx=None
    for c in kids:
        e=byc[c]
        if c in children: prev=None; prefctx=None; continue
        markerled = (not e['lead']) and bool(e['crit'])
        if markerled:
            if e['pref']: prefctx=e['pref']
            else: e['pref_inherited']=prefctx
        else: prefctx=None
        if e['clsstr'].strip() and not e['measurestr'].strip() and prev is not None and prev['measurestr'].strip():
            e['measurestr']=prev['measurestr']; e['massnahme_geerbt']=True
        if e['clsstr'].strip(): prev=e if e['measurestr'].strip() else prev
    # continuation of a braced measure split over two rows
    lk=[byc[c] for c in kids if c not in children]
    for a,b2 in zip(lk,lk[1:]):
        ma=a['measurestr'].strip(); mb=b2['measurestr'].strip()
        if ma and mb and mb[0].islower() and ma.rstrip().endswith(',') and not b2.get('massnahme_geerbt'):
            comb=ma+'\n'+mb
            a['measurestr']=comb; b2['measurestr']=comb; a['massnahme_geerbt']=True if False else a.get('massnahme_geerbt'); b2['massnahme_geerbt']=True

def clean_measure(m):
    m=dehy(m)
    m=re.sub(r'(?<=[a-zäöüß])-\n(?=[a-zäöüß])','',m)
    m=re.sub(r'\s*\n\s*',' ',m)
    m=re.sub(r'(?<=[a-zA-Z])\(([ABCD])\)',r' (\1)',m)
    m=re.sub(r'\)\(',') (',m)
    return one(m)

def ctxtitle(e):
    ctx=e.get('pref') or e.get('pref_inherited')
    if not ctx and e['parent']:
        par=byc[e['parent']]
        ctx=par['title'] if par.get('title') else (par['lead'] or par['part'])
    return ctx

# titles in code order (parents first)
def sortkey(c): return [int(x) for x in c.split('.')]
entries.sort(key=lambda e:sortkey(e['code']))
for e in entries:
    if e['lead']:
        e['title']=strip_sup(e['lead'])
        if e['crit']:
            alln='; '.join(strip_sup(x) for x in e['crit'])
            cand=e['title'].rstrip(':')+': '+alln
            e['title']=cand if len(cand)<=200 else e['title']
    elif e['crit']:
        ctx=ctxtitle(e)
        own=strip_sup(e['crit'][0])
        if len(e['crit'])>1:
            alln='; '.join(strip_sup(x) for x in e['crit'])
            if len(alln)<=170: own=alln
        e['title']=(strip_sup(ctx).rstrip(':')+' – '+own) if ctx else own
    else:
        e['title']=''
# fallback title for headings w/o text: use part name or parent
for e in entries:
    if not e['title']:
        e['title']=e['part'] if e['part'] else ''
        if not e['title'] and e['parent']: e['title']=byc[e['parent']]['title']

# footnotes
foot={}
for pn,txt in d['footnotes'].items():
    m={}
    txt=txt.replace('\n',' ')
    parts=re.split(r'(?=[⁰¹²³⁴⁵⁶⁷⁸⁹]+⁾)',txt)
    for p in parts:
        mm=re.match(r'([⁰¹²³⁴⁵⁶⁷⁸⁹]+)⁾\s*(.*)',p)
        if mm:
            m[supnum(mm.group(1))]=one(mm.group(2))
    foot[int(pn)]=m

def short(t,n=120):
    t=one(t)
    if len(t)<=n: return t
    cut=t[:n].rsplit(' ',1)[0]
    return cut.rstrip(' ,;:–-')+' …'
CAT={ '1':'Laufwerk','2':'Federung','3':'Bremse','4':'Wagenuntergestell und Drehgestellrahmen','5':'Zug- und Stoßeinrichtungen','6':'Wagenkasten','7':'Ladungen und intermodale Ladeeinheiten (ILU, Intermodal Loading Unit)','8':'Besondere Ereignisse'}
out=[]
for e in entries:
    c=e['code']; segs=c.split('.')
    # footnotes referenced
    refs=set()
    for fld in (e['textstr'],e['measurestr'],e['prefacestr'],e['partstr']):
        for m in SUPRE.finditer(fld): refs.add(supnum(m.group(1)))
    fn=[f'{r}) {foot.get(e["page"],{}).get(r,"")}'.strip() for r in sorted(refs,key=int) if foot.get(e['page'],{}).get(r)]
    leaf=c not in children
    cls=e['clsstr'].strip()
    meas=clean_measure(strip_sup(e['measurestr']) if False else e['measurestr'])
    meas=SUPRE.sub('',meas)
    freie='bleibt frei' in e['textstr'].lower().replace('–','-')
    # path of part names
    path=[]; x=c
    while x:
        ee=byc.get(x)
        if ee and ee['part'] and len(x.split('.'))<=3: path.append(CAT[x] if '.' not in x else strip_sup(ee['part']))
        x=ee['parent'] if ee else None
    path=path[::-1]
    if len(segs)==1: name=CAT.get(c,e['part'])
    out.append(dict(
        code=c, ebene=len(segs), kategorie=int(segs[0]), eltern=e['parent'],
        titel=(CAT[c] if len(segs)==1 else strip_sup(e['title'])),
        kurztext=short(CAT[c] if len(segs)==1 else strip_sup(e['title'])),
        bauteil=strip_sup(e['part']) if e['part'] else '',
        pfad=path, 
        beschreibung=strip_sup(e['lead']),
        kriterien=[strip_sup(x) for x in e['crit']],
        hinweise=[strip_sup(x) for x in e['hint']],
        kontext=strip_sup(e.get('pref') or e.get('pref_inherited') or ''),
        massnahme=meas,
        fehlerklasse=int(cls) if cls.isdigit() else None,
        auswaehlbar=(leaf and not freie),
        frei=freie,
        fussnoten=fn,
        seite=e['page'],
        massnahme_geerbt=bool(e.get('massnahme_geerbt'))
    ))
OVR={
 '6.5.2.2':'Tank scharfkantig verbeult ohne Ladegutaustritt',
 '6.5.2.3':'Tankfrist überschritten, Ladung RID-Güter ohne Anschrift „L“ – Tank gefüllt, ≤ 1 Monat abgelaufen',
 '6.5.2.4':'Tankfrist überschritten, Ladung RID-Güter ohne Anschrift „L“ – Tank gefüllt, > 1 Monat abgelaufen',
 '6.5.2.5':'Tankfrist überschritten, Ladung RID-Güter ohne Anschrift „L“ – Tank leer, ungereinigt; RID-Eintrag „BEFÖRDERUNG NACH ABSATZ 4.3.2.4.4“ IST im Beförderungspapier enthalten',
 '6.5.2.8':'Tankfrist überschritten, Ladung RID-Güter ohne Anschrift „L“ – Tank leer, ungereinigt; RID-Eintrag „BEFÖRDERUNG NACH ABSATZ 4.3.2.4.4“ IST NICHT im Beförderungspapier enthalten',
 '6.5.2.9':'Tankfrist überschritten, Ladung RID-Güter mit Anschrift „L“ – Tank gefüllt, ≤ 3 Monate abgelaufen',
 '6.5.2.10':'Tankfrist überschritten, Ladung RID-Güter mit Anschrift „L“ – Tank gefüllt, > 3 Monate abgelaufen',
 '6.5.2.11':'Tankfrist überschritten, Ladung RID-Güter mit Anschrift „L“ – Tank leer, ungereinigt; RID-Eintrag „BEFÖRDERUNG NACH ABSATZ 4.3.2.4.4“ IST im Beförderungspapier enthalten',
 '6.5.2.12':'Tankfrist überschritten, Ladung RID-Güter mit Anschrift „L“ – Tank leer, ungereinigt; RID-Eintrag „BEFÖRDERUNG NACH ABSATZ 4.3.2.4.4“ IST NICHT im Beförderungspapier enthalten',
}
for o in out:
    if o['code'] in OVR:
        o['titel']=OVR[o['code']]; o['kurztext']=short(o['titel'])
    p=o['pfad']
    o['komponente']=strip_sup(p[-1]) if len(p)>1 else (p[0] if p else '')
    kt=o['kurztext']
    o['anzeige']=kt
kat=[dict(nr=int(k),name=v) for k,v in CAT.items()]
import os
os.makedirs(OUTDIR,exist_ok=True)
FK=[
 dict(klasse=1,bezeichnung='Belanglose Fehler',definition='Belanglose Fehler ohne Auswirkung auf die Verkehrstauglichkeit und Betriebssicherheit. Finden im QMS-System keine Berücksichtigung.',wert=0.002),
 dict(klasse=2,bezeichnung='Geringfügige Fehler',definition='Fehler mit geringen Auswirkungen auf die Verkehrstauglichkeit. Finden im QMS-System keine Berücksichtigung.',wert=0.05),
 dict(klasse=3,bezeichnung='Nebenfehler',definition='Fehler mit erheblichen Auswirkungen auf die Verkehrstauglichkeit sowie Fehler mit Auswirkungen auf die Betriebsabwicklung (fehlende oder fehlerhafte Bezettelung).',wert=0.125),
 dict(klasse=4,bezeichnung='Hauptfehler',definition='Fehler, bei denen die Verkehrstauglichkeit nicht gewahrt ist oder die zur Betriebsgefährdung führen können, sowie Fehler, die zu Personenschäden führen können (Bedienungspersonal Güterwagen).',wert=0.4),
 dict(klasse=5,bezeichnung='Kritische Fehler',definition='Fehler mit erheblichen Auswirkungen auf die Betriebssicherheit und Fehler, die eine akute Transportgefährdung zur Folge haben können.',wert=1.0),
]
AUSS={'A':'Lauffähigkeit wiederherstellen','B':'Ladungskorrektur','C':'Halteranfrage','D':'RID-Prozess'}
FKX=FK
db=dict(quelle='GCU/AVV Anlage 9, Anhang 1 – Katalog der Mängel und Schäden (Ausgabe 1. Januar 2026)',kategorien=kat,fehlerklassen=FK,aussetzen=AUSS,codes=out)
json.dump(db,open(os.path.join(OUTDIR,'schadcodes.json'),'w'),ensure_ascii=False,indent=1)
db_sqlite=os.path.join(OUTDIR,'schadcodes.db')
if os.path.exists(db_sqlite): os.remove(db_sqlite)
con=sqlite3.connect(db_sqlite); cu=con.cursor()
cu.executescript('''
CREATE TABLE kategorien(nr INTEGER PRIMARY KEY, name TEXT NOT NULL);
CREATE TABLE fehlerklassen(klasse INTEGER PRIMARY KEY, bezeichnung TEXT, definition TEXT, wert REAL);
CREATE TABLE aussetzen(kuerzel TEXT PRIMARY KEY, bedeutung TEXT);
CREATE TABLE schadcodes(
 code TEXT PRIMARY KEY, ebene INTEGER, kategorie INTEGER REFERENCES kategorien(nr), eltern TEXT,
 titel TEXT, kurztext TEXT, anzeige TEXT, komponente TEXT, bauteil TEXT, pfad TEXT,
 beschreibung TEXT, kriterien TEXT, hinweise TEXT, kontext TEXT, massnahme TEXT,
 fehlerklasse INTEGER, auswaehlbar INTEGER, frei INTEGER, fussnoten TEXT, seite INTEGER,
 stelle1 TEXT, stelle2 TEXT, stelle3 TEXT, stelle4 TEXT);
CREATE INDEX idx_kat ON schadcodes(kategorie); CREATE INDEX idx_eltern ON schadcodes(eltern);
''')
cu.executemany('INSERT INTO kategorien VALUES(?,?)',[(k['nr'],k['name']) for k in kat])
cu.executemany('INSERT INTO fehlerklassen VALUES(?,?,?,?)',[(f['klasse'],f['bezeichnung'],f['definition'],f['wert']) for f in FK])
cu.executemany('INSERT INTO aussetzen VALUES(?,?)',list(AUSS.items()))
for o in out:
    sg=(o['code'].split('.')+['','','',''])[:4]
    cu.execute('INSERT INTO schadcodes VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(o['code'],o['ebene'],o['kategorie'],o['eltern'],o['titel'],o['kurztext'],o['anzeige'],o['komponente'],o['bauteil'],' › '.join(o['pfad']),o['beschreibung'],' | '.join(o['kriterien']),' | '.join(o['hinweise']),o['kontext'],o['massnahme'],o['fehlerklasse'],int(o['auswaehlbar']),int(o['frei']),' | '.join(o['fussnoten']),o['seite'],*sg))
con.commit(); con.close()
with open(os.path.join(OUTDIR,'schadcodes.csv'),'w',newline='',encoding='utf-8-sig') as fh:
    w=csv.writer(fh,delimiter=';'); w.writerow(['Code','Kategorie','Pfad','Titel','Kriterien','Hinweise','Maßnahme','Fehlerklasse','Auswählbar','Fußnoten'])
    for o in out: w.writerow([o['code'],CAT[str(o['kategorie'])],' › '.join(o['pfad']),o['titel'],' | '.join(o['kriterien']),' | '.join(o['hinweise']),o['massnahme'],o['fehlerklasse'] or '',int(o['auswaehlbar']),' | '.join(o['fussnoten'])])
print(len(out),'codes;',sum(1 for o in out if o['auswaehlbar']),'auswählbar')
