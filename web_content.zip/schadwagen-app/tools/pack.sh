#!/usr/bin/env bash
# Baut das verkleinerte Projekt-ZIP (ohne erzeugbare Dateien, siehe README „Projekt-ZIP“).
# Aufruf aus dem Ordner über schadwagen-app:  bash schadwagen-app/tools/pack.sh [ziel.zip]
set -euo pipefail
cd "$(dirname "$0")/../.."
out="${1:-schadwagen-app.zip}"
rm -f "$out"
zip -q -r -9 "$out" schadwagen-app \
  -x '*/node_modules/*' '*/build/*' '*/.gradle/*' '*.exe' \
     'schadwagen-app/windows/www/*' \
     'schadwagen-app/database/schadcodes.db' 'schadwagen-app/database/_neu.db' \
     'schadwagen-app/resources/icon.png' 'schadwagen-app/resources/icon-rounded.png' \
     'schadwagen-app/resources/icon-foreground.png' 'schadwagen-app/resources/icon-background.png' \
     'schadwagen-app/test/out_*.pdf' '*/__pycache__/*' '*.DS_Store'
ls -l "$out"
