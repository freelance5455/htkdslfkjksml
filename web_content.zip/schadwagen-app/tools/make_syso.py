"""Erzeugt windows/rsrc_windows_amd64.syso (Programmsymbol) aus resources/icon-rounded.png – ohne Fremdwerkzeuge."""
import io, struct, sys, pathlib
from PIL import Image

root = pathlib.Path(__file__).resolve().parent.parent
src = Image.open(root / 'resources/icon-rounded.png').convert('RGBA')
sizes = [16, 24, 32, 48, 64, 128, 256]
pngs = []
for s in sizes:
    b = io.BytesIO(); src.resize((s, s), Image.LANCZOS).save(b, 'PNG'); pngs.append(b.getvalue())

# Gruppen-Icon
grp = struct.pack('<HHH', 0, 1, len(sizes))
for i, (s, data) in enumerate(zip(sizes, pngs)):
    grp += struct.pack('<BBBBHHIH', s % 256, s % 256, 0, 0, 1, 32, len(data), i + 1)

LANG = 0x0407  # Deutsch
# Baum: Typ -> [(id, daten)]
tree = [(3, [(i + 1, d) for i, d in enumerate(pngs)]), (14, [(1, grp)])]

def dir_hdr(n_id): return struct.pack('<IIHHHH', 0, 0, 0, 0, 0, n_id)

# Layout berechnen: Ebene1-Verzeichnis, Ebene2-Verzeichnisse, Ebene3-Verzeichnisse, Data-Entries, Daten
l1_size = 16 + 8 * len(tree)
l2_sizes = [16 + 8 * len(items) for _, items in tree]
leaves = [(t, i, d) for t, items in tree for i, d in items]
off = l1_size
l2_off = []
for sz in l2_sizes: l2_off.append(off); off += sz
l3_off = []
for _ in leaves: l3_off.append(off); off += 16 + 8
de_off = []
for _ in leaves: de_off.append(off); off += 16
data_off = []
for _, _, d in leaves:
    off = (off + 7) & ~7; data_off.append(off); off += len(d)
total = (off + 7) & ~7

buf = bytearray(total)
buf[0:16] = dir_hdr(len(tree))
for k, (t, items) in enumerate(tree):
    struct.pack_into('<II', buf, 16 + 8 * k, t, 0x80000000 | l2_off[k])
relocs = []
li = 0
for k, (t, items) in enumerate(tree):
    o = l2_off[k]
    buf[o:o + 16] = dir_hdr(len(items))
    for j, (rid, d) in enumerate(items):
        struct.pack_into('<II', buf, o + 16 + 8 * j, rid, 0x80000000 | l3_off[li])
        lo = l3_off[li]
        buf[lo:lo + 16] = dir_hdr(1)
        struct.pack_into('<II', buf, lo + 16, LANG, de_off[li])
        struct.pack_into('<IIII', buf, de_off[li], data_off[li], len(d), 0, 0)
        relocs.append(de_off[li])  # OffsetToData ist eine RVA -> Relokation
        buf[data_off[li]:data_off[li] + len(d)] = d
        li += 1

hdr_size = 20 + 40
raw_ptr = hdr_size
reloc_ptr = raw_ptr + total
sym_ptr = reloc_ptr + 10 * len(relocs)
out = bytearray()
out += struct.pack('<HHIIIHH', 0x8664, 1, 0, sym_ptr, 1, 0, 0)
out += struct.pack('<8sIIIIIIHHI', b'.rsrc', 0, 0, total, raw_ptr, reloc_ptr, 0, len(relocs), 0, 0x40000040)
out += buf
for r in relocs: out += struct.pack('<IIH', r, 0, 3)  # IMAGE_REL_AMD64_ADDR32NB
out += struct.pack('<8sIhHBB', b'.rsrc', 0, 1, 0, 3, 0)
out += struct.pack('<I', 4)
dst = root / 'windows/rsrc_windows_amd64.syso'
dst.write_bytes(out)
print(dst, len(out))
