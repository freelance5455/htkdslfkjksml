# Flappy 50 Android Studio Project

App name: Flappy 50
Package: com.nostalgia.flappy50

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync/download the Android Gradle Plugin and dependencies.
3. Select the `app` configuration.
4. Build > Build APK(s).
5. Install the generated APK on your Android phone.

The game is bundled as `app/src/main/assets/index.html` and runs inside an Android WebView.

Note: the current HTML uses the BBS image URL already present in the game, so internet permission is included for that asset.
