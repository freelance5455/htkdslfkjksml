# Firebase দিয়ে APK অনলাইন করা (লগইন + অ্যাডমিন + ক্লাউড সেভ)

APK তে এটা কাজ করে: ইমেইল লগইন, ক্লাউডে অগ্রগতি সেভ, মালিকের অ্যাডমিন প্যানেল (ছড়া/গল্প/শব্দ/ঘোষণা)।
Firebase এর ফ্রি প্ল্যান (Spark) ছোট অ্যাপের জন্য যথেষ্ট।

## ধাপ ১ — প্রজেক্ট বানান
1. https://console.firebase.google.com এ আপনার Google অ্যাকাউন্টে ঢুকে **Add project** চাপুন, নাম দিন `shourov-kids`।
2. **Build > Authentication > Get started > Email/Password** চালু করুন।
3. **Build > Firestore Database > Create database** (Production mode, কাছের অঞ্চল বেছে নিন)।

## ধাপ ২ — অ্যাপের কনফিগ নিন
1. Project settings (⚙️) > **Your apps** > Web (`</>`) বাটন > অ্যাপের নাম দিন > Register।
2. যে `firebaseConfig` দেখাবে, তার `apiKey`, `authDomain`, `projectId`, `appId` কপি করুন।
3. `www/firebase-config.js` খুলে ওই মানগুলো বসান।

## ধাপ ৩ — নিজের UID নিন
1. APK/ওয়েবে নিজের ইমেইলে একবার অ্যাকাউন্ট খুলুন (অ্যাপের লগইন পাতায় "নতুন অ্যাকাউন্ট")।
2. Console > Authentication > Users এ আপনার ইমেইলের পাশে **User UID** কপি করুন।
3. `www/firebase-config.js` এ `adminUid:"..."` এ বসান।

## ধাপ ৪ — নিরাপত্তার নিয়ম (সবচেয়ে জরুরি)
1. Firestore > **Rules** ট্যাবে `firestore.rules` ফাইলের লেখা বসান।
2. ফাইলের `আপনার_UID_এখানে` জায়গায় ধাপ ৩ এর UID বসিয়ে **Publish** চাপুন।
এই নিয়মের কারণেই শুধু আপনি content বদলাতে পারেন। অ্যাপের বাটন লুকানো এর বিকল্প নয়।

## ধাপ ৫ — APK বানান
`GUIDE.md` এর ধাপ অনুযায়ী `npx cap copy android` করে Android Studio থেকে বানান।

## জেনে রাখুন
- আঁকা ছবি ক্লাউডে যায় না, শুধু ফোনে থাকে।
- বাচ্চারা ইমেইলে অ্যাকাউন্ট খুললে অভিভাবকের ইমেইল ব্যবহার করাই ভালো।
- Play Store এ দিতে গোপনীয়তা নীতি (privacy policy) লাগবে।
- এটা আমি আসল Firebase এ চালাইনি (আমার এখানে সংযোগ নেই); নকল Firebase দিয়ে লগইন ও ডাটা পড়া-লেখার ধাপ পরীক্ষা করেছি। প্রথমবার চালিয়ে ত্রুটি পেলে আমাকে জানান।
