# Read Zone: Android APK, Firebase ও নিরাপদ AI গাইড

## এই ফোল্ডারে কী আছে
- `www/` : অ্যাপ (index.html, আইকন, অফলাইন ফাইল)
- `android-icons/res/` : Android ফোনের হোম স্ক্রিনের আইকন (আপনার দেওয়া ছবি থেকে বানানো)
- `package.json`, `capacitor.config.json` : APK বানানোর কনফিগারেশন
- `ai-proxy/` : নিরাপদ AI সার্ভারের কোড (API কী এখানে থাকে, অ্যাপে নয়)

---
## ১. APK বানানো (আপনার কম্পিউটারে, Windows/Mac/Linux)

### যা লাগবে (একবারই)
1. Node.js (LTS): https://nodejs.org
2. Android Studio: https://developer.android.com/studio (এর সঙ্গেই Android SDK ও JDK আসে)
   প্রথমবার খুললে "SDK Platform" ও "Build Tools" ইনস্টল করতে দিন।

### ধাপ
ZIP আনজিপ করে ফোল্ডারে টার্মিনাল খুলুন:

```
npm install
npx cap add android
```

**অ্যাপের আইকন বসানো:** `npx cap add android` এর পর এই ফোল্ডারের `android-icons/res` এর ভেতরের সবকিছু কপি করে `android/app/src/main/res/` এ পেস্ট করুন। ফাইল বদলাতে চাইলে "Replace" দিন। তারপর:

```
npx cap sync android
npx cap open android
```

(কপি করা না গেলে বিকল্প: Android Studio-তে `app` ডানবোতামে ক্লিক → New → Image Asset → `www/icon-512.png` বেছে নিন।)

Android Studio খুলবে। নিচের ডানে Gradle sync শেষ হওয়ার জন্য অপেক্ষা করুন। তারপর:

**Build → Build Bundle(s) / APK(s) → Build APK(s)**

শেষ হলে নিচে "locate" লিংক আসবে। ফাইলটি এখানে থাকে:
`android/app/build/outputs/apk/debug/app-debug.apk`

### ফোনে ইনস্টল
1. APK ফাইলটি USB, Google Drive বা WhatsApp দিয়ে ফোনে পাঠান।
2. ফোনে ফাইলটি ছুঁলে "Install unknown apps" অনুমতি চাইবে। অনুমতি দিন।
3. Install চাপুন। অ্যাপের নাম "Read Zone"।

USB দিয়ে সরাসরি চালাতে: ফোনে Settings → About phone → Build number ৭ বার ছুঁয়ে Developer options চালু করুন, USB debugging অন করুন, তারপর Android Studio-তে ▶ Run চাপুন।

### Play Store-এর জন্য
- Android Studio: Build → Generate Signed App Bundle (AAB)। কী (keystore) বানিয়ে নিরাপদ জায়গায় রাখুন। হারালে আপডেট দেওয়া যাবে না।
- Google Play Console অ্যাকাউন্ট লাগবে (এককালীন ২৫ ডলার)।
- শিশুদের অ্যাপের জন্য Play-এর "Families" নীতি, Privacy Policy পাতা এবং Data safety ফর্ম পূরণ করতে হয়।

### APK-তে যা অন্যরকম হবে
- **বাংলা ভয়েস:** ফোনে "Speech Services by Google" ইনস্টল করে বাংলা ভয়েস নামানো থাকতে হবে।
- **মাইক (বলে প্রশ্ন করা):** Android WebView-তে এই সুবিধা সাধারণত চলে না। অ্যাপ তখন বার্তা দেখিয়ে লেখার ঘরে ফেরত যায়। এটা চালু করতে Capacitor-এর speech-recognition প্লাগিন লাগবে, যা আলাদা কাজ।
- **ফন্ট:** এখন Google Fonts ইন্টারনেট থেকে আসে। পুরোপুরি অফলাইন চাইলে Baloo Da 2 ও Hind Siliguri ফন্টের ফাইল `www/` এ নামিয়ে `@font-face` দিয়ে লোড করুন।
- **অগ্রগতি:** ফোনেই জমা থাকে। অ্যাপ মুছলে মুছে যাবে। ক্লাউডে রাখতে নিচের Firebase অংশ দেখুন।

---
## ২. নিরাপদ AI শিক্ষক (API কী অ্যাপে রাখা যাবে না)

অ্যাপে API কী রাখলে APK খুলে যে কেউ সেটি বের করে নিতে পারে। তাই মাঝখানে একটি ছোট সার্ভার (proxy) থাকে। কী থাকে সেখানে, অ্যাপ শুধু সেই সার্ভারকে প্রশ্ন পাঠায়।

### Cloudflare Workers দিয়ে (বিনামূল্যে শুরু করা যায়)
1. https://dash.cloudflare.com এ অ্যাকাউন্ট খুলুন।
2. Anthropic API কী নিন: https://console.anthropic.com
3. টার্মিনালে `ai-proxy` ফোল্ডারে গিয়ে:
```
npx wrangler login
npx wrangler secret put ANTHROPIC_API_KEY     # কী পেস্ট করুন
npx wrangler deploy
```
4. শেষে একটি ঠিকানা পাবেন, যেমন `https://shourov-ai.আপনার-নাম.workers.dev`
5. `www/index.html` খুলে এই লাইনটি খুঁজুন এবং ঠিকানা বসান:
```
window.SHOUROV_AI_ENDPOINT="https://shourov-ai.আপনার-নাম.workers.dev";
```
6. `npx cap sync android` চালিয়ে আবার APK বানান।

### সুরক্ষা
- শিশুদের জন্য নিয়ম (`SYSTEM`) সার্ভারে আছে, অ্যাপ থেকে বদলানো যায় না।
- অ্যাপেও অনুচিত শব্দ আটকানো আছে। অভিভাবক-অংশে সন্তানের প্রশ্নের তালিকা দেখা যায়।
- খরচ ঠেকাতে Cloudflare-এ Rate limiting নিয়ম দিন, Anthropic Console-এ মাসিক খরচের সীমা ঠিক করুন।
- `worker.js` এর `access-control-allow-origin: "*"` পরীক্ষার পর আপনার অ্যাপের ঠিকানায় সীমিত করুন।
- প্রকৃত ব্যবহারকারী হলে Firebase লগইন ছাড়া অনামা কেউ যেন সার্ভার ব্যবহার না করতে পারে, সেজন্য ধাপ ৩-এর টোকেন যাচাই যোগ করুন।

---
## ৩. Firebase (লগইন, ডেটাবেস, ক্লাউড ফাইল)

বর্তমান অ্যাপে Firebase যুক্ত **নেই**। নিচের ধাপে যোগ করা যায়।

1. https://console.firebase.google.com এ প্রজেক্ট বানান। Android অ্যাপ যোগ করুন, প্যাকেজ নাম `com.readzone.app`।
2. **Authentication:** অভিভাবকের জন্য Email/Password বা Google সাইন-ইন চালু করুন। শিশুর নিজের অ্যাকাউন্ট খুলবেন না। অভিভাবকের অ্যাকাউন্টের নিচে শিশুর প্রোফাইল রাখুন।
3. **Firestore:** গঠন: `parents/{uid}/children/{childId}`। এর ভেতরে `learned`, `quizzes`, `stars`, `settings`। বর্তমান অ্যাপের `loadState()` ও `useStored()` ফাংশনে স্থানীয় সংরক্ষণের পাশে Firestore-এ লেখা যোগ করতে হবে।
4. **নিরাপত্তা নিয়ম (Firestore Rules):**
```
rules_version = '2';
service cloud.firestore {
  match /databases/{db}/documents {
    match /parents/{uid}/{document=**} {
      allow read, write: if request.auth != null && request.auth.uid == uid;
    }
  }
}
```
5. **Storage:** রেকর্ড করা অডিও রাখুন `audio/bn/অ.mp3`, `audio/en/A.mp3` এভাবে। পড়ার অনুমতি সবার, লেখার অনুমতি শুধু আপনার।
6. Android-এ Capacitor: `npm i @capacitor-firebase/authentication firebase` এবং `google-services.json` ফাইল `android/app/` এ রাখুন।
7. পুরনো স্থানীয় অগ্রগতি প্রথম লগইনে ক্লাউডে তুলে দেওয়ার ব্যবস্থা রাখুন।

### শিশুদের তথ্য
শিশুদের অ্যাপে ব্যক্তিগত তথ্য কম রাখুন (শুধু নাম বা ডাকনাম)। বিজ্ঞাপন ও ট্র্যাকিং রাখবেন না। বাংলাদেশ ও Google Play-এর নিয়ম মিলিয়ে একটি Privacy Policy লিখুন।

---
## ৪. রেকর্ড করা অডিও যোগ করা (ঐচ্ছিক)
এখন উচ্চারণ ফোনের বিল্ট-ইন কণ্ঠস্বর দিয়ে হয়। মানুষের কণ্ঠ চাইলে:
1. প্রতিটি অক্ষর ও ছড়ার MP3 রেকর্ড করুন, `www/audio/` এ রাখুন।
2. অ্যাপের `speakText()` ফাংশনের আগে ফাইল আছে কি না দেখে `new Audio('audio/bn/অ.mp3').play()` চালান, না থাকলে আগের কণ্ঠস্বরে ফিরুন।

## নিজের রেকর্ড করা অডিও (ঐচ্ছিক)
1. `audio-list.csv` খুলুন: প্রথম কলাম ফাইলের নাম, দ্বিতীয় কলাম যা বলতে হবে।
2. প্রতিটি mp3 রেকর্ড করে `www/audio/` এ রাখুন।
3. `www/index.html` এ `window.SHOUROV_AUDIO=false;` কে `true` করুন।
4. যে ফাইল নেই সেখানে স্বয়ংক্রিয়ভাবে ফোনের TTS চলবে।
5. `sw.js` এর cache সংস্করণ (v6) বাড়িয়ে `npx cap copy android` চালান।

## অনলাইন ও অ্যাডমিন (গুরুত্বপূর্ণ)
- এখন অ্যাপ শুধু ইন্টারনেট থাকলে চলে (offline cache বন্ধ)।
- মালিকের অ্যাডমিন প্যানেল শুধু Claude আর্টিফ্যাক্ট সংস্করণে কাজ করে (সেখানকার ডাটাবেস ব্যবহার করে)।
- এই APK তে অ্যাডমিন প্যানেল ও ক্লাউড সেভ **কাজ করবে না**। APK তে এটা চাইলে Firebase (Auth + Firestore) লাগবে, আমাকে বলুন।

## শব্দকোষ (Dictionary)
- শব্দ ইন্টারনেট থেকে আসে। APK তে `window.SHOUROV_AI_ENDPOINT` (ai-proxy) বসালে বাংলা+ইংরেজি সহজ মানে ও উদাহরণ আসে।
- proxy না বসালে ফ্রি পাবলিক API (dictionaryapi.dev ও MyMemory) ব্যবহার হয়: ইংরেজি মানে আসে, বাংলা শুধু শব্দের অনুবাদ।

## শ্রেণি ১–১০ MCQ পরীক্ষা
- অ্যাডমিন প্যানেল > "MCQ ব্যাংক" এ শ্রেণি ও বিষয় বেছে অধ্যায়ের তালিকা বসান (AI খসড়া দিতে পারে, বইয়ের সঙ্গে মিলিয়ে নিন)।
- AI দিয়ে প্রশ্ন বানিয়ে যাচাই করে ব্যাংকে যোগ করুন। পরীক্ষার সময় ব্যাংকে ৩০টির কম থাকলে বাকি প্রশ্ন AI সঙ্গে সঙ্গে বানায় (🤖 চিহ্নসহ)।
- APK তে AI প্রশ্ন আনতে `ai-proxy/worker.js` এর নতুন সংস্করণ Cloudflare এ আবার deploy করতে হবে (task mode যোগ হয়েছে)।
- `firestore.rules` এ নতুন `mcq` নিয়ম আছে, আবার Publish করুন।

## বন্ধু, বার্তা ও র‍্যাংকিং
- অভিভাবক অংশ থেকে "বন্ধু ও র‍্যাংকিং" চালু করতে হয় (ডিফল্ট বন্ধ)। শিশু ডাকনাম ও ছবি বাছে, আসল নাম নয়।
- বন্ধু খোঁজা কোড বা ডাকনাম দিয়ে। দুজনেই যোগ করলে তবে বন্ধু। বার্তা ডিফল্টে শুধু তৈরি করা বাক্য। ব্লক ও রিপোর্ট বাটন আছে।
- এটা Firebase লাগে; `firestore.rules` এ profiles, friends, msgs, reports এর নিয়ম যোগ হয়েছে, আবার Publish করুন।

## নোটিফিকেশন, প্রোফাইল ও রিপোর্ট (v15)
- `npm install` এর পর `npx cap sync android` চালান (local-notifications প্লাগইন যোগ হয়েছে)।
- Android 13+ এ প্রথমবার অনুমতি চাইবে। অ্যাপ খুললে পরবর্তী ক্লাসগুলোর ১০ মিনিট আগের রিমাইন্ডার সেট হয়; নতুন ক্লাস যোগ হলে অ্যাপ একবার খুলতে হবে। অ্যাপ না খুলেও আপডেট চাইলে FCM সার্ভার-পুশ লাগবে (এখনো করা হয়নি)।
- সাপ্তাহিক রিপোর্ট: অভিভাবক এলাকায় ইমেইল দিন, বাটনে চাপলে ইমেইল অ্যাপ খোলে। স্বয়ংক্রিয় সার্ভার-ইমেইল নেই; রবিবার ৬টায় শুধু মনে করানো হয়।
- একাধিক শিশুর ক্লাউড-সিঙ্ক আলাদা `progress_<id>` ডকুমেন্টে যায়; বন্ধু/র‍্যাংকিং শুধু প্রথম প্রোফাইলে।

## v16 নতুন
- প্রথমবার চালুতে সেটআপ (নাম, ভাষা, অভিভাবকের PIN)। সহজ PIN (1234, 0000 ইত্যাদি) গ্রহণ করা হয় না।
- অ্যাডমিন প্যানেলে "রিপোর্ট ও নিষিদ্ধ করা"। নিষিদ্ধ তালিকা `content/main.banned` এ থাকে। `firestore.rules` আপডেট করে আবার Firebase এ প্রকাশ করুন, তাহলে নিষিদ্ধ ব্যবহারকারী সার্ভার পর্যায়েও লিখতে পারবে না।
- `www/firebase-shim.js` এ `delete`/`update` যোগ হয়েছে।
- প্রকৃতি ও জানা (প্রাণী, ঋতু, গ্রহ, শরীর), ভুল প্রশ্নের অনুশীলন।
- Play Store: PRIVACY_POLICY.md, STORE_LISTING.md, PLAYSTORE_CHECKLIST.md দেখুন।

## v18 নতুন
- **AI স্বয়ংক্রিয় আপডেট:** অ্যাডমিন প্যানেলে চালু করুন। মালিক অ্যাপ খুললে নির্ধারিত সময় পরপর AI নতুন গল্প/ছড়া/শব্দ/ধাঁধা বানিয়ে `content/main` এ রাখে (🤖 চিহ্নসহ)। এর জন্য AI প্রক্সি (`SHOUROV_AI_ENDPOINT`) চালু থাকতে হবে। মালিক অ্যাপ না খুললে চলে না; সত্যিকারের ব্যাকগ্রাউন্ড চালাতে সার্ভারে নির্ধারিত সময়ের কাজ (cron) লাগবে।
- হোমওয়ার্ক (অ্যাডমিন থেকে দিন; শিশুর "করেছি" ফোনেই থাকে, শিক্ষক দেখতে পান না)।
- জোরে পড়ো খেলায় ফোনের Speech Recognition লাগে (বাংলা সব ফোনে নাও চলতে পারে; না চললে "বলেছি" বাটন আসে)।
- সঙ্গী প্রাণী, যুক্তির খেলা, ভালো অভ্যাস, নতুন ব্যাজ, সাপ্তাহিক পরিকল্পনা।

## v19: অনলাইন করা
- **ONLINE_SETUP.md** দেখুন (AI Worker, Firebase, ভয়েস)। অ্যাপে অভিভাবক এলাকায় নতুন "অনলাইন অবস্থা" পাতা আছে।
- `www/app-config.js` এ AI ঠিকানা। `npm install` এর পর `npx cap sync android` (text-to-speech প্লাগইন যোগ হয়েছে)।

## v20 নতুন
- সাপ্তাহিক তারার লক্ষ্য (হোম পাতা), নতুন ৪টি ব্যাজ, স্পষ্ট রং মোড (⚙ থেকে)।
- দোয়া ও শুভেচ্ছা: অভিভাবক এলাকা থেকে চালু করলে "প্রকৃতি ও জানা" তে আসে। প্রকাশের আগে লেখাগুলো নিজে বা কোনো আলেম/শিক্ষককে দিয়ে যাচাই করুন।
- মা-বাবার কণ্ঠে ছড়া/গল্প রেকর্ড (PIN লাগে, ফোনেই থাকে)। Android এ মাইকের অনুমতির জন্য `android/app/src/main/AndroidManifest.xml` এ আছে কিনা দেখুন:
  `<uses-permission android:name="android.permission.RECORD_AUDIO" />` এবং `<uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />`

## v21 নতুন
- **অনলাইন আপডেট:** `ONLINE_SETUP.md` ধাপ ৪। `node tools/release.js "বার্তা"` → `update-site` আপলোড।
- **অ্যাডমিনে ব্যবহারকারী তালিকা:** `ONLINE_SETUP.md` ধাপ ৫; অভিভাবক সেটিংসে বন্ধ করতে পারেন।

## v25: নতুন নাম "Read Zone"
- অ্যাপের নাম Read Zone, `appId` এখন `com.readzone.app`। এটা নতুন আলাদা অ্যাপ হিসেবে ইনস্টল হয়; আগের `com.shourov.kids` APK-র তথ্য নতুনটায় আসে না, আগেরটা ফোন থেকে মুছে দিতে পারেন। একবার Play Store এ দিলে appId আর বদলানো যায় না।
- ইন্টারনেট না থাকলেও পুরো অ্যাপ চলে। হেডারে 🟢 অনলাইন / 🔴 অফলাইন সূচক আছে। অফলাইনে AI চাইলে লেখা আসে: "AI ব্যবহার করতে ইন্টারনেট সংযোগ চালু করুন।"
