এই ফোল্ডারে আপনার রেকর্ড করা mp3 ফাইল রাখুন (নাম audio-list.csv অনুযায়ী, যেমন bn-v-0.mp3)।
তারপর www/index.html এ window.SHOUROV_AUDIO=false; কে true করুন।
যে ফাইল নেই সেখানে ফোনের নিজস্ব উচ্চারণ (TTS) চলবে।
