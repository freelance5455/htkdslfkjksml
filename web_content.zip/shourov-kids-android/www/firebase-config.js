/* Firebase সেটিং — FIREBASE.md অনুযায়ী নিজের মান বসান।
   apiKey ফাঁকা থাকলে অ্যাপ Firebase ছাড়াই চলবে (অ্যাডমিন/ক্লাউড সেভ বন্ধ)। */
window.SHOUROV_FB={
  config:{apiKey:"",authDomain:"",projectId:"",appId:""},
  adminUid:""   // আপনার নিজের ইউজার UID (Firebase Console > Authentication)
};
