/* Firebase -> অ্যাপের ডাটাবেস/ইউজার ইন্টারফেস। অ্যাপ কোড বদলাতে হয় না। */
(function(){
  var C=window.SHOUROV_FB;
  if(!C||!C.config||!C.config.apiKey||!window.firebase)return;
  firebase.initializeApp(C.config);
  var auth=firebase.auth(),fs=firebase.firestore();
  var ov=null,resolveReady,ready=new Promise(function(r){resolveReady=r});
  var T={bn:{title:'শৌরভ কিডস',email:'ইমেইল',pass:'পাসওয়ার্ড (কমপক্ষে ৬ অক্ষর)',login:'ঢুকুন',signup:'নতুন অ্যাকাউন্ট',err:'ইমেইল বা পাসওয়ার্ড ঠিক নেই।',net:'ইন্টারনেট সমস্যা।',used:'এই ইমেইল আগেই আছে।',weak:'পাসওয়ার্ড খুব ছোট।'}};
  function show(){
    if(!document.body){document.addEventListener('DOMContentLoaded',show);return}
    if(ov)return;ov=document.createElement('div');
    ov.style.cssText='position:fixed;inset:0;z-index:99999;background:#EAF5FF;display:grid;place-items:center;padding:24px;font-family:system-ui,sans-serif';
    ov.innerHTML='<form style="width:100%;max-width:340px;display:flex;flex-direction:column;gap:12px;text-align:center;color:#1B2559"><div style="font-size:56px">🦉</div><h1 style="margin:0">'+T.bn.title+'</h1>'+
      '<input name="e" type="email" autocomplete="email" placeholder="'+T.bn.email+'" required style="font-size:18px;padding:12px;border-radius:14px;border:2px solid #D3E3F6">'+
      '<input name="p" type="password" autocomplete="current-password" minlength="6" placeholder="'+T.bn.pass+'" required style="font-size:18px;padding:12px;border-radius:14px;border:2px solid #D3E3F6">'+
      '<button type="submit" style="font-size:20px;font-weight:700;padding:14px;border-radius:18px;background:#FFC933;color:#1B2559;border:0">'+T.bn.login+'</button>'+
      '<button type="button" data-su style="font-size:16px;font-weight:700;padding:12px;border-radius:18px;background:#fff;color:#1B2559;border:2px solid #D3E3F6">'+T.bn.signup+'</button>'+
      '<p data-m role="alert" style="min-height:22px;margin:0;color:#B3261E;font-weight:700"></p></form>';
    document.body.appendChild(ov);
    var f=ov.querySelector('form'),m=ov.querySelector('[data-m]');
    function fail(e){var c=e&&e.code||'';m.textContent=c.indexOf('email-already')>=0?T.bn.used:c.indexOf('weak')>=0?T.bn.weak:c.indexOf('network')>=0?T.bn.net:T.bn.err}
    f.addEventListener('submit',function(ev){ev.preventDefault();m.textContent='';auth.signInWithEmailAndPassword(f.e.value.trim(),f.p.value).catch(fail)});
    ov.querySelector('[data-su]').addEventListener('click',function(){m.textContent='';if(!f.reportValidity())return;auth.createUserWithEmailAndPassword(f.e.value.trim(),f.p.value).catch(fail)});
  }
  function hide(){if(ov){ov.remove();ov=null}}
  auth.onAuthStateChanged(function(u){if(u){hide();resolveReady(u)}else show()});
  var clean=function(d){return JSON.parse(JSON.stringify(d))};
  window.claude={use:async function(n){
    if(n==='user'){var u=await ready;return{isOwner:async function(){return !!C.adminUid&&u.uid===C.adminUid},id:async function(){return u.uid}}}
    if(n==='db'){await ready;return{collection:function(p){function wrap(q){return{where:function(f,o,v){return wrap(q.where(f,o,v))},orderBy:function(f,d){return wrap(q.orderBy(f,d||'asc'))},limit:function(n2){return wrap(q.limit(n2))},get:async function(){var s=await q.get();return{docs:s.docs.map(function(d){return{id:d.id,exists:true,data:function(){return d.data()}}})}}}}return wrap(fs.collection(p))},doc:function(p){var r=fs.doc(p);return{
      get:async function(){var s=await r.get();return{exists:s.exists,data:function(){return s.data()}}},
      set:function(d){return r.set(clean(d))},
      delete:function(){return r.delete()},
      update:function(d){return r.update(clean(d))},
      onSnapshot:function(nx,er){return r.onSnapshot(function(s){nx({exists:s.exists,data:function(){return s.data()}})},er)}}}}}
    return null}};
  window.SHOUROV_SIGNOUT=function(){return auth.signOut()};
})();
