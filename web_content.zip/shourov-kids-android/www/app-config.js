/* অ্যাপের অনলাইন সেটিং — এখানে একবার বসালেই হবে।
   AI_ENDPOINT: Cloudflare Worker এর ঠিকানা (ONLINE_SETUP.md ধাপ ১)। ফাঁকা থাকলেও চলবে:
   তখন অভিভাবক এলাকা › "অনলাইন অবস্থা" এ অ্যাপের ভেতরেই ঠিকানা বসানো যায়। */
window.SHOUROV_AI_ENDPOINT="";
window.SHOUROV_AUDIO=false;   // রেকর্ড করা mp3 থাকলে true (audio/ ফোল্ডার, audio-list.csv দেখুন)

/* অনলাইন আপডেটের ঠিকানা (Cloudflare Pages এর ঠিকানা, ONLINE_SETUP.md ধাপ ৪)। যেমন "https://shourov-kids.pages.dev"
   ফাঁকা থাকলে অনলাইন আপডেট বন্ধ থাকে। এটি বসিয়ে APK একবার নতুন করে বানাতে হবে। */
window.SHOUROV_UPDATE_URL="";
window.SHOUROV_BUNDLED_VERSION=1793962340;
