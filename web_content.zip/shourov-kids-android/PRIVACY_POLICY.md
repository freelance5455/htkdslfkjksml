# গোপনীয়তা নীতি / Privacy Policy — Read Zone

> **গুরুত্বপূর্ণ:** এটি একটি খসড়া। [ ] চিহ্নিত জায়গাগুলো আপনার তথ্য দিয়ে পূরণ করুন, প্রয়োজনে আইনজীবীর পরামর্শ নিন, তারপর একটি পাবলিক ওয়েব ঠিকানায় (যেমন GitHub Pages) প্রকাশ করুন। Play Store-এ সেই ঠিকানা দিতে হবে।

শেষ হালনাগাদ: [তারিখ]  ·  প্রকাশক: [আপনার নাম]  ·  যোগাযোগ: [আপনার ইমেইল]

## বাংলা

**এই অ্যাপ কাদের জন্য:** শিশুদের শেখার অ্যাপ। অভিভাবকের এলাকা PIN দিয়ে সুরক্ষিত।

**আমরা কী তথ্য রাখি**
- শিশুর নাম (যা অভিভাবক লেখেন), শেখার অগ্রগতি, তারা, আঁকা ছবি, সেটিংস: এগুলো ডিভাইসে সেভ থাকে।
- অনলাইন ফিচার চালু থাকলে অগ্রগতির একটি কপি ক্লাউড ডাটাবেসে (Firebase) একটি বেনামী অ্যাকাউন্ট আইডির নিচে রাখা হয়।
- "বন্ধু ও র‍্যাংকিং" শুধু অভিভাবক চালু করলে: ডাকনাম, ছবি-প্রতীক, পয়েন্ট, তারা ও ধারা অন্যদের দেখানো হয়। বার্তা শুধু আগে থেকে তৈরি বাক্য (অভিভাবক চাইলে নিজের লেখাও) এবং বন্ধু হওয়া ব্যবহারকারীদের মধ্যেই।
- অনলাইন থাকলে অ্যাপের মালিক দেখতে পান: অভিভাবকের দেওয়া শিশুর নাম, তারা, ধারা, শেষ ব্যবহারের সময়, অ্যাপের সংস্করণ। সেটিংসে "ব্যবহারের তথ্য পাঠানো" বন্ধ করলে এগুলো আর যায় না।
- আমরা ছবি, ঠিকানা, ফোন নম্বর, লোকেশন বা বিজ্ঞাপনের আইডি সংগ্রহ করি না। অ্যাপে কোনো বিজ্ঞাপন বা ট্র্যাকিং নেই।

**AI শিক্ষক ও ডিকশনারি:** শিশুর লেখা প্রশ্ন উত্তর তৈরির জন্য AI সেবায় পাঠানো হয়। প্রশ্নে ব্যক্তিগত তথ্য লিখতে নিষেধ করা আছে এবং অনিরাপদ প্রশ্ন আটকানো হয়, তবে AI-এর উত্তর ১০০% নির্ভুল নাও হতে পারে।

**মাইক্রোফোন:** শুধু শিশু নিজে চাপ দিলে বলা শব্দ চেনার জন্য ব্যবহৃত হয়। অভিভাবক এলাকা থেকে বন্ধ করা যায়। রেকর্ডিং সংরক্ষণ করা হয় না। [আপনার বাস্তবায়ন অনুযায়ী যাচাই করুন]

**অভিভাবকের নিয়ন্ত্রণ:** PIN, সময়সীমা, বন্ধু ফিচার চালু/বন্ধ, রিমাইন্ডার, তথ্য মুছে ফেলা ("সব মুছে নতুন করে শুরু")।

**তথ্য মুছতে চাইলে:** অ্যাপ থেকে মুছুন, অথবা [আপনার ইমেইল] এ লিখুন; আমরা ক্লাউডের তথ্য মুছে দেব।

**তৃতীয় পক্ষ:** Google Firebase (ডাটাবেস ও লগইন), [AI সেবা, যেমন Anthropic ইত্যাদি], Google Fonts।

## English

Read Zone is a learning app for children. The parent area is protected by a PIN.

**Data:** (With online features on, the app owner can see the child's name entered by the parent, stars, streak, last-used time and app version; parents can switch this off in Settings.) Child's name (entered by the parent), progress, stars, drawings and settings stay on the device. With online features on, a copy of progress is stored in a cloud database (Firebase) under an anonymous account ID. If a parent turns on Friends & ranking, a nickname, avatar symbol, points, stars and streak are visible to other users; messages are preset phrases (or typed ones if the parent allows) and only between connected friends.

**Not collected:** real names, photos, addresses, phone numbers, location, advertising IDs. No ads, no tracking.

**AI teacher/dictionary:** Questions typed by the child are sent to an AI service to produce answers. Unsafe questions are blocked, but answers may not always be perfectly accurate.

**Microphone:** used only when the child taps the button, to recognise a spoken word; can be turned off by the parent; recordings are not stored. [verify against your build]

**Parent controls:** PIN, time limit, Friends on/off, reminders, data erase.

**Deletion:** erase in the app, or email [your email] to have cloud data deleted.

**Third parties:** Google Firebase, [AI provider], Google Fonts.
