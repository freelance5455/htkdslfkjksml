// নতুন সংস্করণ প্রকাশের টুল:  node tools/release.js "ছোট বার্তা"
// www/index.html থেকে update-site/ বানায় (index.html + version.json + _headers)।
// তারপর update-site ফোল্ডারটি Cloudflare Pages এ আপলোড করলেই সবার ফোন আপডেট নেবে।
const fs = require("fs"), path = require("path"), crypto = require("crypto");
const root = path.join(__dirname, "..");
const www = path.join(root, "www"), out = path.join(root, "update-site");
const note = process.argv[2] || "";
const html = fs.readFileSync(path.join(www, "index.html"));
if (html.length < 100000) { console.error("www/index.html অস্বাভাবিক ছোট — থামানো হলো"); process.exit(1); }
const v = Math.floor(Date.now() / 1000);
const sha = crypto.createHash("sha256").update(html).digest("hex");
fs.mkdirSync(out, { recursive: true });
fs.writeFileSync(path.join(out, "index.html"), html);
fs.writeFileSync(path.join(out, "version.json"), JSON.stringify({ v, sha, file: "index.html", note }, null, 2));
fs.writeFileSync(path.join(out, "_headers"), "/*\n  Access-Control-Allow-Origin: *\n  Cache-Control: no-cache\n");
// APK-র ভেতরের সংস্করণ নম্বরও একই করে রাখি (নতুন APK বানালে আর অকারণে আপডেট নামাবে না)
const cfgP = path.join(www, "app-config.js");
let cfg = fs.readFileSync(cfgP, "utf8");
cfg = /SHOUROV_BUNDLED_VERSION\s*=/.test(cfg) ? cfg.replace(/SHOUROV_BUNDLED_VERSION\s*=\s*\d+/, "SHOUROV_BUNDLED_VERSION=" + v) : cfg + "\nwindow.SHOUROV_BUNDLED_VERSION=" + v + ";\n";
fs.writeFileSync(cfgP, cfg);
console.log("তৈরি: update-site/  সংস্করণ", v, " sha256", sha.slice(0, 12) + "…");
console.log("এখন update-site ফোল্ডারটি Cloudflare Pages এ আপলোড করুন।");
