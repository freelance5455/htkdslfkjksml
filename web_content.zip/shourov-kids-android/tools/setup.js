// অনলাইন সেটিং বসানোর সহজ টুল:  node tools/setup.js
// আপনি শুধু ঠিকানা/মান পেস্ট করবেন; ফাইল নিজে নিজে বদলে যাবে। না জানলে Enter চাপুন (আগের মান থাকবে)।
const fs = require("fs"), path = require("path"), rl = require("readline").createInterface({ input: process.stdin }), it = rl[Symbol.asyncIterator]();
const www = path.join(__dirname, "..", "www");
const ask = async q => { process.stdout.write(q); const { value } = await it.next(); return (value || "").trim(); };
const get = (f, re) => { const m = re.exec(fs.readFileSync(path.join(www, f), "utf8")); return m ? m[1] : ""; };
const setVal = (f, re, val) => { const p = path.join(www, f); const t = fs.readFileSync(p, "utf8"); if (!re.test(t)) throw new Error(f + " এ জায়গা পাওয়া যায়নি"); fs.writeFileSync(p, t.replace(re, (_, a, b, c) => a + val.replace(/"/g, "") + c)); };
(async () => {
  console.log("\n— অনলাইন সেটআপ (ফাঁকা রাখলে আগের মান থাকে) —\n");
  const ai = await ask("১) AI Worker এর ঠিকানা (https://…workers.dev) [ONLINE_SETUP.md ধাপ ১]: ");
  if (ai) { if (!/^https:\/\//.test(ai)) throw new Error("ঠিকানা https:// দিয়ে শুরু হতে হবে"); setVal("app-config.js", /(SHOUROV_AI_ENDPOINT=")([^"]*)(")/, ai); }
  const up = await ask("২) আপডেট সাইটের ঠিকানা (https://…pages.dev) [ধাপ ৪]: ");
  if (up) { if (!/^https:\/\//.test(up)) throw new Error("ঠিকানা https:// দিয়ে শুরু হতে হবে"); setVal("app-config.js", /(SHOUROV_UPDATE_URL=")([^"]*)(")/, up); }
  console.log("\nFirebase (ধাপ ২): Project settings › Your apps › Web app এর config থেকে");
  const fb = { apiKey: "", authDomain: "", projectId: "", appId: "" };
  let any = false;
  for (const k of Object.keys(fb)) { fb[k] = await ask("   " + k + ": "); if (fb[k]) any = true; }
  const uid = await ask("   আপনার Admin UID (Authentication › Users): ");
  if (any || uid) {
    const p = path.join(www, "firebase-config.js"); let t = fs.readFileSync(p, "utf8");
    for (const k of Object.keys(fb)) if (fb[k]) t = t.replace(new RegExp("(" + k + ':")([^"]*)(")'), (_, a, b, c) => a + fb[k].replace(/"/g, "") + c);
    if (uid) t = t.replace(/(adminUid:")([^"]*)(")/, (_, a, b, c) => a + uid.replace(/"/g, "") + c);
    fs.writeFileSync(p, t);
  }
  rl.close();
  console.log("\nহয়েছে। এখন চালান:\n  node tools/release.js \"অনলাইন চালু\"   (আপডেট সাইট তৈরি)\n  npx cap sync android              (তারপর Android Studio/gradle এ APK বানান)\n");
})().catch(e => { console.error("ভুল:", e.message); process.exit(1); });
