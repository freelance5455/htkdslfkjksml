'use strict';
/* ============================================================
   Telas — parte 1: base, topo, aba Treino, exercícios, sessão e resumo
   ============================================================ */
const h = U.el;
const VIEW_IDS = ['train','history','stats','settings'];

function applyLanguage(){
  setLang(S().language);
  document.title = APP_NAME;
  applyStaticI18n();
  const bt = $('#brandTxt'); if(bt) bt.textContent = APP_NAME;
}
function renderAll(){ renderTopbar(); RENDERERS[State.currentView](); if(typeof syncOnboarding === "function") syncOnboarding(); }
function switchView(name){
  State.currentView = name;
  VIEW_IDS.forEach(k=>$('#view-' + k).classList.toggle('active', k === name));
  document.querySelectorAll('.nav-btn').forEach(b=>{ const on = b.dataset.view === name; b.classList.toggle('active', on); if(on) b.setAttribute('aria-current','page'); else b.removeAttribute('aria-current'); });
  window.scrollTo(0,0);
  renderTopbar(); RENDERERS[name]();
}
function renderTopbar(){
  const btn = $('#streakBtn'), on = gamOn() && State.data.profile.onboarded;
  btn.hidden = !on;
  if(on){ const st = State.data.gamification.streak; U.clear(btn); btn.appendChild(h('span', { class:'flame', 'aria-hidden':'true', text:'🔥' })); btn.appendChild(h('b', { text:String(st.current) })); btn.setAttribute('aria-label', t('streak.aria', { n:st.current })); }
}

/* ---------- Aba TREINO ---------- */
function renderTrainView(){
  renderBanners(); renderRankCard(); renderHero(); renderQuests(); renderDayTabs(); renderDayExercises();
  $('#routineTitle').textContent = t('train.routine'); $('#editDayBtn').textContent = t('train.editDay'); $('#addExerciseBtn').textContent = t('train.addExercise');
  $('#editDayBtn').hidden = !currentDay();
}
function renderBanners(){
  const wrap = $('#bannerContainer'); U.clear(wrap);
  if(!backupDue()) return;
  const b = h('div', { class:'banner', role:'status' });
  b.appendChild(h('div', { class:'banner-tx', text:t('banner.backup') }));
  const row = h('div', { class:'banner-actions' });
  row.appendChild(h('button', { class:'btn btn-primary btn-sm', type:'button', text:t('banner.backupNow'), onclick:()=>exportBackup() }));
  row.appendChild(h('button', { class:'btn btn-ghost btn-sm', type:'button', text:t('banner.later'), onclick:()=>{ S().lastBackupRemindAt = Date.now(); persistData(); renderBanners(); } }));
  b.appendChild(row); wrap.appendChild(b);
}
function renderRankCard(){
  const wrap = $('#rankContainer'); U.clear(wrap);
  if(!gamOn()) return;
  const G = State.data.gamification, lp = levelProgress(G.xpTotal);
  const card = h('button', { class:'rank-card', type:'button', 'aria-label':t('rank.open'), onclick:openRanksScreen });
  card.appendChild(insigniaEl(lp.rank.id, 58));
  const mid = h('div', { class:'rank-mid' });
  mid.appendChild(h('div', { class:'rank-name', text:t('rank.' + lp.rank.id) }));
  mid.appendChild(h('div', { class:'rank-sub', text:t('lbl.level', { n:lp.level }) + ' • ' + fmtInt(G.xpTotal) + ' ' + t('lbl.xp') }));
  const track = h('div', { class:'progress-track slim', role:'progressbar', 'aria-valuemin':'0', 'aria-valuemax':String(lp.xpNeeded), 'aria-valuenow':String(Math.round(lp.xpInLevel)), 'aria-label':t('rank.levelProgress') });
  track.appendChild(h('div', { class:'progress-fill', style:{ width:lp.pct + '%' } }));
  mid.appendChild(track);
  mid.appendChild(h('div', { class:'rank-next', text: lp.nextRank ? t('rank.toNext', { xp:fmtInt(lp.xpToNextRank), rank:t('rank.' + lp.nextRank.id) }) : t('rank.max') }));
  card.appendChild(mid);
  wrap.appendChild(card);
}
function renderHero(){
  const wrap = $('#heroContainer'); U.clear(wrap);
  const day = currentDay(), tday = todayDay();
  const isToday = !!(day && tday && tday.id === day.id);
  const total = day ? day.exercises.length : 0;
  const isActive = !!(State.active && day && State.active.dayId === day.id);
  const done = isActive ? day.exercises.filter(exerciseDone).length : 0;
  const pct = total > 0 ? Math.round(done/total*100) : 0;
  const doneToday = !!(day && State.history.some(s=>s.dayId === day.id && U.dayKey(s.completedAt) === U.dayKey(Date.now())));
  const hero = h('div', { class:'hero' });
  const top = h('div', { class:'hero-top' });
  top.appendChild(h('div', {}, [
    h('div', { class:'hero-date', text:fmtDateLong(Date.now()) }),
    h('div', { class:'hero-day', text: isToday ? t('lbl.today') : (day ? day.name : '—') }),
    h('div', { class:'hero-title', text: day ? (day.title || t('lbl.untitled')) : t('train.noDay') })
  ]));
  let badge = t('hero.planned'), cls = 'hero-badge';
  if(isActive){ badge = t('hero.live'); cls += ' live'; } else if(doneToday){ badge = t('hero.done'); cls += ' done'; }
  top.appendChild(h('div', { class:cls, text:badge })); hero.appendChild(top);
  if(total > 0){
    const pw = h('div', { class:'progress-wrap' });
    pw.appendChild(h('div', { class:'progress-labels' }, [ h('span', {}, [t('hero.progress') + ' ', h('strong', { text:done + ' / ' + total })]), h('strong', { text:pct + '%' }) ]));
    const track = h('div', { class:'progress-track' }); track.appendChild(h('div', { class:'progress-fill', style:{ width:pct + '%' } })); pw.appendChild(track); hero.appendChild(pw);
  }
  const cells = [ [t('lbl.week'), weekDaysCount(Date.now()) + '/' + S().weeklyGoal], [t('lbl.sessions'), String(State.history.length)] ];
  if(gamOn() && State.game) cells.push([t('lbl.weeksInGoal'), String(State.game.weekStreak.current)]);
  const pr = h('div', { class:'profile-row', style:{ 'grid-template-columns':'repeat(' + cells.length + ',1fr)' } });
  cells.forEach(c=>{ const cell = h('div', { class:'profile-cell' }); cell.appendChild(h('div', { class:'lbl', text:c[0] })); cell.appendChild(h('div', { class:'val', text:c[1] })); pr.appendChild(cell); });
  hero.appendChild(pr);
  if(day && day.note) hero.appendChild(h('div', { class:'hero-note', text:day.note }));
  const aw = h('div', { style:{ marginTop:'16px' } });
  if(isActive){ const b = h('button', { class:'btn btn-primary btn-block', type:'button', onclick:finishSession }); b.appendChild(icon('check')); b.appendChild(document.createTextNode(t('hero.finish'))); aw.appendChild(b); }
  else if(total > 0){ const b = h('button', { class:'btn btn-primary btn-block', type:'button', onclick:()=>startSession() }); b.appendChild(icon('play')); b.appendChild(document.createTextNode(doneToday ? t('hero.again') : t('hero.start'))); aw.appendChild(b); }
  hero.appendChild(aw); wrap.appendChild(hero);
}
function questName(def){
  const n = def.metric === 'volume' ? fmtInt(kgToDisp(String(def.target))) + ' ' + unitLabel() : fmtInt(def.target);
  return t('quest.' + def.id, { n });
}
function renderQuests(){
  const wrap = $('#questContainer'); U.clear(wrap);
  if(!gamOn() || !State.data.days.length) return;
  const qb = questBoard(State.history, State.data);
  const card = h('div', { class:'quest-card' });
  const group = (title, list)=>{
    card.appendChild(h('div', { class:'quest-head', text:title }));
    list.forEach(q=>{
      const row = h('div', { class:'quest' + (q.done ? ' done' : '') });
      const tx = h('div', { class:'quest-tx' });
      tx.appendChild(h('div', { class:'quest-name', text:questName(q.def) }));
      const track = h('div', { class:'progress-track slim' }); track.appendChild(h('div', { class:'progress-fill', style:{ width:(q.cur / q.target * 100) + '%' } })); tx.appendChild(track);
      row.appendChild(tx);
      row.appendChild(h('div', { class:'quest-xp', text: q.done ? '✓' : '+' + q.def.xp + ' ' + t('lbl.xp') }));
      if(q.done) row.setAttribute('aria-label', t('quest.doneAria'));
      card.appendChild(row);
    });
  };
  group(t('quest.daily'), qb.day); group(t('quest.weekly'), qb.week);
  wrap.appendChild(card);
}
function renderDayTabs(){
  const wrap = $('#dayTabs'); U.clear(wrap);
  const tday = todayDay(); let activeTab = null;
  State.data.days.forEach(day=>{
    const isCur = day.id === State.currentDayId;
    const tab = h('button', { class:'day-tab' + (isCur ? ' active' : '') + (tday && tday.id === day.id ? ' today' : ''), style:{ '--tab-color':day.color }, type:'button', 'aria-label':day.name + ' ' + day.title, 'aria-pressed':String(isCur), onclick:()=>selectDay(day.id) });
    tab.appendChild(h('div', { text:day.name })); tab.appendChild(h('small', { text: day.title ? day.title.split('/')[0].trim() : '—' }));
    if(State.active && State.active.dayId === day.id) tab.appendChild(h('div', { class:'dot' }));
    wrap.appendChild(tab); if(isCur) activeTab = tab;
  });
  const add = h('button', { class:'day-tab add', type:'button', 'aria-label':t('train.addDay'), onclick:()=>openDayModal(true) }); add.appendChild(icon('plus')); wrap.appendChild(add);
  if(activeTab) wrap.scrollLeft = activeTab.offsetLeft - wrap.clientWidth/2 + activeTab.clientWidth/2;
}
function selectDay(id){ if(id === State.currentDayId) return; State.currentDayId = id; renderTrainView(); }

function renderDayExercises(){
  const wrap = $('#exList'), label = $('#dayExercisesLabel'); U.clear(wrap);
  const day = currentDay();
  if(!day){
    label.textContent = t('train.exercises', { n:0 });
    const empty = h('div', { class:'empty' }); empty.appendChild(h('div', { text:t('train.noDays') }));
    const b = h('button', { class:'btn btn-ghost btn-sm', type:'button', style:{ marginTop:'12px' }, onclick:()=>openDayModal(true) }); b.appendChild(icon('plus')); b.appendChild(document.createTextNode(t('train.addDay'))); empty.appendChild(b); wrap.appendChild(empty); return;
  }
  const n = day.exercises.length; label.textContent = t('train.exercises', { n });
  if(n === 0){
    const empty = h('div', { class:'empty' }); empty.appendChild(h('div', { text:t('train.noExercises') }));
    const b = h('button', { class:'btn btn-ghost btn-sm', type:'button', style:{ marginTop:'12px' }, onclick:()=>openExerciseModal(null) }); b.appendChild(icon('plus')); b.appendChild(document.createTextNode(t('train.addExercise'))); empty.appendChild(b); wrap.appendChild(empty); return;
  }
  const sessionActive = !!(State.active && State.active.dayId === day.id);
  day.exercises.forEach((ex, idx)=>wrap.appendChild(renderExerciseCard(ex, idx, day, sessionActive)));
}
function renderExerciseCard(ex, idx, day, sessionActive){
  const card = h('div', { class:'ex-card' });
  if(sessionActive && exerciseDone(ex)) card.classList.add('checked');
  const check = h('button', { class:'ex-check', type:'button', 'aria-label':t('ex.markDone', { name:ex.name }) }); check.appendChild(icon('check'));
  check.addEventListener('click', ()=>toggleExerciseDone(ex)); card.appendChild(check);
  const body = h('div', { class:'ex-body' });
  body.appendChild(h('div', { class:'ex-name', text:ex.name }));
  const meta = h('div', { class:'ex-meta' });
  if(ex.muscle) meta.appendChild(h('span', { class:'chip', text:t('muscle.' + ex.muscle) }));
  if(isCardio(ex)){ const m = U.splitList(ex.reps)[0]; if(m) meta.appendChild(h('span', { class:'chip', text:m + ' ' + t('unit.min') })); }
  else {
    if(ex.sets && ex.reps) meta.appendChild(h('span', { class:'chip', text:ex.sets + ' × ' + U.splitList(ex.reps).join('/') }));
    else if(ex.sets) meta.appendChild(h('span', { class:'chip', text:t('ex.setsN', { n:ex.sets }) }));
    if(ex.load) meta.appendChild(h('span', { class:'chip load', text:U.splitList(ex.load).map(l=>fmtLoad(l)).join('/') + ' ' + unitLabel() }));
    if(ex.rest) meta.appendChild(h('span', { class:'chip', text:t('ex.restChip', { n:ex.rest }) }));
  }
  if(meta.children.length) body.appendChild(meta);
  if(ex.notes) body.appendChild(h('div', { class:'ex-notes', text:ex.notes }));
  if(sessionActive) body.appendChild(renderSetLogger(ex, card));
  card.appendChild(body);
  const menu = h('button', { class:'ex-menu', type:'button', 'aria-label':t('ex.moreFor', { name:ex.name }), onclick:()=>openExerciseActions(ex.id) });
  menu.appendChild(icon('dots')); card.appendChild(menu);
  return card;
}
ICONS.dots = '<circle cx="12" cy="5" r="1.2"/><circle cx="12" cy="12" r="1.2"/><circle cx="12" cy="19" r="1.2"/>';

function renderSetLogger(ex, card){
  const cardio = isCardio(ex), wrap = h('div', { class:'set-logger' });
  const head = h('div', { class:'set-logger-head' });
  head.appendChild(h('span', { class:'set-head-lbl', text:cardio ? t('set.duration') : t('set.sets') }));
  if(!cardio && ex.rest !== 0){ const rb = h('button', { class:'btn btn-ghost btn-sm', type:'button', onclick:()=>startRest(ex.rest || S().defaultRest) }); rb.appendChild(icon('timer')); rb.appendChild(document.createTextNode(t('rest.title'))); head.appendChild(rb); }
  wrap.appendChild(head);
  const last = lastPerformance(ex.key);
  if(last){
    const hint = h('div', { class:'last-hint' });
    hint.appendChild(document.createTextNode(t('set.lastTime', { date:fmtDateShort(last.date) }) + ' '));
    hint.appendChild(h('b', { text:last.sets.map(s=>setSummary(s, last.cardio)).join(' · ') })); wrap.appendChild(hint);
  }
  const sets = ensureSets(ex);
  const cols = h('div', { class:'set-cols' + (cardio ? ' cardio' : '') });
  cols.appendChild(h('span', { text:'#' }));
  if(cardio) cols.appendChild(h('span', { text:t('set.minutes') })); else { cols.appendChild(h('span', { text:t('set.load', { u:unitLabel() }) })); cols.appendChild(h('span', { text:t('set.reps') })); }
  cols.appendChild(h('span', { text:t('set.ok') })); wrap.appendChild(cols);
  sets.forEach((set, i)=>{
    const row = h('div', { class:'set-row' + (cardio ? ' cardio' : '') + (set.done ? ' done' : '') });
    row.appendChild(h('div', { class:'set-num', text:String(i+1) }));
    if(cardio){
      const inMin = h('input', { type:'text', inputmode:'decimal', placeholder:t('unit.min'), value:set.minutes || '', 'aria-label':t('set.minutes') });
      inMin.addEventListener('input', ()=>{ const n = U.parseNum(inMin.value); set.minutes = n == null ? '' : String(n); persistActive(); }); row.appendChild(inMin);
    } else {
      const inLoad = h('input', { type:'text', inputmode:'decimal', placeholder:unitLabel(), value:loadInputValue(set.load), 'aria-label':t('set.loadAria', { n:i+1 }) });
      inLoad.addEventListener('input', ()=>{ set.load = dispToKg(inLoad.value); persistActive(); });
      const inReps = h('input', { type:'text', inputmode:'numeric', placeholder:t('lbl.repsShort'), value:set.reps || '', 'aria-label':t('set.repsAria', { n:i+1 }) });
      inReps.addEventListener('input', ()=>{ set.reps = inReps.value.replace(/[^\d]/g,''); persistActive(); });
      row.appendChild(inLoad); row.appendChild(inReps);
    }
    const tg = h('button', { class:'set-toggle', type:'button', 'aria-pressed':String(!!set.done), 'aria-label':t('set.finishAria', { n:i+1 }) }); tg.appendChild(icon('check'));
    tg.addEventListener('click', ()=>{
      unlockAudio(); set.done = !set.done; row.classList.toggle('done', set.done); tg.setAttribute('aria-pressed', String(set.done)); persistActive();
      card.classList.toggle('checked', sets.every(s=>s.done)); renderHero();
      if(set.done){ vibrate(25); if(S().autoStartRest && !cardio && ex.rest > 0) startRest(ex.rest); }
    });
    row.appendChild(tg); wrap.appendChild(row);
  });
  if(!cardio){
    const tools = h('div', { class:'set-tools' });
    const add = h('button', { class:'btn btn-ghost btn-sm', type:'button', onclick:()=>{ const prev = sets[sets.length-1] || {}; sets.push({ load:prev.load || '', reps:prev.reps || '', done:false }); persistActive(); renderDayExercises(); renderHero(); } });
    add.appendChild(icon('plus')); add.appendChild(document.createTextNode(t('set.addSet')));
    const rem = h('button', { class:'btn btn-ghost btn-sm', type:'button', onclick:()=>{ if(sets.length <= 1) return; sets.pop(); persistActive(); renderDayExercises(); renderHero(); } });
    rem.appendChild(icon('minus')); rem.appendChild(document.createTextNode(t('set.removeSet')));
    tools.appendChild(add); tools.appendChild(rem); wrap.appendChild(tools);
  }
  return wrap;
}
function toggleExerciseDone(ex){
  const day = currentDay(); if(!day) return;
  if(!State.active) doStartSession(day, true);
  else if(State.active.dayId !== day.id){ showToast(t('toast.otherSession'), 'warn'); return; }
  unlockAudio();
  const sets = ensureSets(ex), target = !sets.every(s=>s.done);
  sets.forEach(s=>{ s.done = target; }); persistActive(); if(target) vibrate(25); renderTrainView();
}

/* ---------- Ações do exercício ---------- */
function openExerciseActions(exId){
  const day = currentDay(); if(!day) return;
  const idx = day.exercises.findIndex(e=>e.id === exId); if(idx < 0) return;
  const ex = day.exercises[idx];
  actionSheet(ex.name, [
    { label:t('btn.edit'), icon:'edit', opens:true, onClick:()=>openExerciseModal(exId) },
    { label:t('btn.duplicate'), icon:'copy', onClick:()=>{ const c = Object.assign(U.clone(ex), { id:U.uid('ex'), key:newExKey(), name:ex.name + ' ' + t('ex.copySuffix') }); day.exercises.splice(idx+1, 0, c); persistData(); renderTrainView(); showToast(t('toast.duplicated'), 'success'); } },
    { label:t('btn.moveUp'), icon:'up', disabled:idx === 0, onClick:()=>moveExercise(day, idx, -1) },
    { label:t('btn.moveDown'), icon:'down', disabled:idx === day.exercises.length-1, onClick:()=>moveExercise(day, idx, 1) },
    { label:t('btn.delete'), icon:'trash', danger:true, opens:true, onClick:()=>deleteExercise(exId) }
  ]);
}
function moveExercise(day, idx, dir){ const j = idx + dir; if(j < 0 || j >= day.exercises.length) return; [day.exercises[idx], day.exercises[j]] = [day.exercises[j], day.exercises[idx]]; persistData(); renderDayExercises(); }
async function deleteExercise(exId){
  const day = currentDay(); if(!day) return; const ex = day.exercises.find(e=>e.id === exId); if(!ex) return;
  const ok = await confirmDialog({ title:t('ex.deleteTitle'), message:t('ex.deleteMsg', { name:ex.name }), confirmText:t('btn.delete') });
  if(!ok) return;
  day.exercises = day.exercises.filter(e=>e.id !== exId); if(State.active && State.active.sets) delete State.active.sets[exId];
  persistData(); persistActive(); renderTrainView(); showToast(t('toast.deleted'), 'success');
}

/* ---------- Modal: exercício ---------- */
function selectEl(id, options, value, placeholder){
  const sel = h('select', { id });
  if(placeholder !== undefined) sel.appendChild(h('option', { value:'', text:placeholder }));
  options.forEach(o=>sel.appendChild(h('option', { value:o[0], text:o[1] })));
  sel.value = value || ''; return sel;
}
function fieldEl(labelText, input, opts){
  opts = opts || {}; const f = h('div', { class:'field' });
  f.appendChild(h('label', { for:input.id, text:labelText })); f.appendChild(input);
  if(opts.hint) f.appendChild(h('span', { class:'field-hint', text:opts.hint }));
  if(opts.error){ const e = h('span', { class:'field-error', role:'alert', text:opts.error }); f.appendChild(e); }
  return f;
}
function openExerciseModal(exId){
  const day = currentDay(); if(!day) return;
  const ex = exId ? day.exercises.find(e=>e.id === exId) : null;
  Modals.open({ title: ex ? t('ex.edit') : t('ex.new'), tall:true, build(body, foot){
    const iName = h('input', { id:'i-name', type:'text', maxlength:'80', autocomplete:'off', value:ex ? ex.name : '', placeholder:t('ex.namePh'), enterkeyhint:'next' });
    const fName = fieldEl(t('ex.name'), iName, { error:t('ex.nameErr') });
    const sMuscle = selectEl('i-muscle', MUSCLES.map(m=>[m, t('muscle.' + m)]), ex ? ex.muscle : '', '—');
    const sEquip = selectEl('i-equip', EQUIPS.map(m=>[m, t('equip.' + m)]), ex ? ex.equipment : '', '—');
    body.appendChild(fName);
    body.appendChild(h('div', { class:'field-row' }, [ fieldEl(t('ex.muscle'), sMuscle), fieldEl(t('ex.equipment'), sEquip) ]));
    const iSets = h('input', { id:'i-sets', type:'number', inputmode:'numeric', min:'1', max:'20', value:ex && ex.sets ? String(ex.sets) : '', placeholder:'3' });
    const iRest = h('input', { id:'i-rest', type:'number', inputmode:'numeric', min:'0', max:'900', value:ex ? String(ex.rest) : String(S().defaultRest), placeholder:'90' });
    const rowSets = h('div', { class:'field-row' }, [ fieldEl(t('ex.sets'), iSets), fieldEl(t('ex.rest'), iRest) ]);
    body.appendChild(rowSets);
    const iReps = h('input', { id:'i-reps', type:'text', inputmode:'text', maxlength:'60', autocomplete:'off', value:ex ? U.splitList(ex.reps).join('; ') : '', placeholder:'12; 10; 8' });
    const lReps = h('label', { for:'i-reps', text:t('ex.reps') }); const hReps = h('span', { class:'field-hint', text:t('ex.repsHint') });
    const fReps = h('div', { class:'field' }, [lReps, iReps, hReps]); body.appendChild(fReps);
    const iLoad = h('input', { id:'i-load', type:'text', inputmode:'text', maxlength:'60', autocomplete:'off', value:ex ? U.splitList(ex.load).map(l=>loadInputValue(l)).join('; ') : '', placeholder:'20; 25; 30' });
    const fLoadL = h('label', { for:'i-load', id:'l-load' });
    const fLoad = h('div', { class:'field' }, [fLoadL, iLoad, h('span', { class:'field-hint', text:t('ex.loadHint') })]); body.appendChild(fLoad);
    const iNotes = h('textarea', { id:'i-notes', maxlength:'300', placeholder:t('ex.notesPh') }); iNotes.value = ex ? ex.notes : '';
    body.appendChild(fieldEl(t('ex.notes'), iNotes));
    const sync = ()=>{
      const cardio = isCardioKey(sMuscle.value);
      rowSets.style.display = cardio ? 'none' : ''; fLoad.style.display = cardio ? 'none' : '';
      lReps.textContent = cardio ? t('ex.minutes') : t('ex.reps'); hReps.textContent = cardio ? t('ex.minutesHint') : t('ex.repsHint');
      fLoadL.textContent = t('ex.load', { u:unitLabel() });
    };
    sMuscle.addEventListener('change', sync); sync();
    foot.appendChild(h('button', { class:'btn btn-ghost', type:'button', text:t('btn.cancel'), onclick:()=>Modals.close() }));
    foot.appendChild(h('button', { class:'btn btn-primary', type:'button', text:t('btn.save'), onclick:()=>{
      const name = iName.value.trim();
      if(!name){ fName.classList.add('invalid'); iName.focus(); return; }
      const cardio = isCardioKey(sMuscle.value);
      const reps = cardio ? (U.parseNum(iReps.value) != null ? [String(U.parseNum(iReps.value))] : []) : parseRepsList(iReps.value);
      const loads = cardio ? [] : parseLoadList(iLoad.value).map(dispToKg).filter(x=>x !== '');
      const data = { name, muscle:sMuscle.value, equipment:sEquip.value, sets: cardio ? 1 : (U.parseNum(iSets.value) ? Math.min(20, Math.round(U.parseNum(iSets.value))) : null),
        reps:reps.join(','), load:loads.join(','), rest: cardio ? 0 : Math.min(900, Math.max(0, Math.round(U.parseNum(iRest.value) ?? S().defaultRest))), notes:iNotes.value.trim() };
      if(ex){ Object.assign(ex, data); reconcileSets(ex); } else day.exercises.push(Object.assign({ id:U.uid('ex'), key:newExKey() }, data));
      persistData(); Modals.close(); renderTrainView(); showToast(t('toast.saved'), 'success');
    } }));
  }});
}

/* ---------- Modal: dia ---------- */
const DAY_COLORS = ['#00E5FF','#8B5CF6','#22C55E','#F59E0B','#EF4444','#FFD700','#EC4899','#94A3B8'];
function openDayModal(isNew){
  const day = isNew ? null : currentDay(); if(!isNew && !day) return;
  Modals.open({ title: isNew ? t('day.new') : t('day.edit'), build(body, foot){
    let color = day ? day.color : DAY_COLORS[State.data.days.length % DAY_COLORS.length];
    const iName = h('input', { id:'d-name', type:'text', maxlength:'6', autocomplete:'off', value:day ? day.name : '', placeholder:fmtWeekdayShort(1).slice(0,6) });
    const dows = [1,2,3,4,5,6,0].map(d=>[String(d), fmtWeekdayLong(d)]);
    const sDow = selectEl('d-dow', dows, day && day.dow !== null ? String(day.dow) : '', t('day.noDow'));
    body.appendChild(h('div', { class:'field-row' }, [ fieldEl(t('day.tab'), iName), fieldEl(t('day.dow'), sDow, { hint:t('day.dowHint') }) ]));
    const iTitle = h('input', { id:'d-title', type:'text', maxlength:'40', autocomplete:'off', value:day ? day.title : '', placeholder:t('day.titlePh') });
    body.appendChild(fieldEl(t('day.title'), iTitle));
    const cf = h('div', { class:'field' }); cf.appendChild(h('label', { id:'l-color', text:t('day.color') }));
    const row = h('div', { class:'color-row', role:'radiogroup', 'aria-labelledby':'l-color' });
    const paint = ()=>row.querySelectorAll('.color-dot').forEach(b=>{ const on = b.dataset.c === color; b.style.borderColor = on ? '#fff' : 'transparent'; b.setAttribute('aria-checked', String(on)); });
    DAY_COLORS.forEach(c=>row.appendChild(h('button', { class:'color-dot', type:'button', role:'radio', 'data-c':c, style:{ background:c }, 'aria-label':c, onclick:()=>{ color = c; paint(); } })));
    cf.appendChild(row); body.appendChild(cf); paint();
    const iNote = h('textarea', { id:'d-note', maxlength:'200', placeholder:t('day.notePh') }); iNote.value = day ? day.note : '';
    body.appendChild(fieldEl(t('day.note'), iNote));
    if(day) body.appendChild(h('button', { class:'btn btn-danger btn-block', type:'button', text:t('day.delete'), onclick:async ()=>{
      const ok = await confirmDialog({ title:t('day.deleteTitle'), message:t('day.deleteMsg'), confirmText:t('btn.delete') });
      if(!ok) return;
      State.data.days = State.data.days.filter(d=>d.id !== day.id);
      if(State.active && State.active.dayId === day.id){ State.active = null; persistActive(); closeRestTimer(); syncWakeLock(); }
      pickInitialDay(); persistData(); rebuildGamification(); renderTrainView(); showToast(t('toast.deleted'), 'success');
    } }));
    foot.appendChild(h('button', { class:'btn btn-ghost', type:'button', text:t('btn.cancel'), onclick:()=>Modals.close() }));
    foot.appendChild(h('button', { class:'btn btn-primary', type:'button', text:t('btn.save'), onclick:()=>{
      const dow = sDow.value === '' ? null : Number(sDow.value);
      const name = iName.value.trim() || (dow !== null ? fmtWeekdayShort(dow).slice(0,6) : t('day.generic', { n:State.data.days.length + 1 }).slice(0,6));
      const vals = { name:name.slice(0,6), dow, title:iTitle.value.trim(), color, note:iNote.value.trim() };
      if(day) Object.assign(day, vals); else { const nd = Object.assign({ id:U.uid('day'), exercises:[] }, vals); State.data.days.push(nd); State.currentDayId = nd.id; }
      persistData(); rebuildGamification(); Modals.close(); renderTrainView(); showToast(t('toast.saved'), 'success');
    } }));
  }});
}

/* ---------- Sessão: iniciar / finalizar ---------- */
function startSession(){
  const day = currentDay(); if(!day) return;
  if(State.active && State.active.dayId !== day.id){
    confirmDialog({ title:t('sess.activeTitle'), message:t('sess.activeMsg'), confirmText:t('sess.discardStart') }).then(ok=>{ if(ok) doStartSession(day); });
    return;
  }
  doStartSession(day);
}
function doStartSession(day, silent){
  State.active = { id:U.uid('session'), dayId:day.id, dayTitle:day.title, startedAt:Date.now(), sets:{} };
  day.exercises.forEach(ex=>{ State.active.sets[ex.id] = buildSets(ex); });
  persistActive(); closeRestTimer(); syncWakeLock(); renderTrainView(); if(!silent) showToast(t('toast.sessionStarted'), 'success');
}
async function finishSession(){
  if(!State.active) return;
  const day = State.data.days.find(d=>d.id === State.active.dayId);
  if(!day){ State.active = null; persistActive(); renderTrainView(); return; }
  const exercises = day.exercises.map(ex=>({
    id:ex.id, key:ex.key, name:ex.name, cardio:isCardio(ex), muscle:ex.muscle,
    sets:(State.active.sets[ex.id] || []).map(s=> 'minutes' in s ? { minutes:s.minutes, done:!!s.done } : { load:s.load, reps:s.reps, done:!!s.done })
  }));
  const anyDone = exercises.some(ex=>ex.sets.some(s=>s.done)), anyPending = exercises.some(ex=>ex.sets.some(s=>!s.done));
  if(!anyDone){
    const ok = await confirmDialog({ title:t('sess.endEmptyTitle'), message:t('sess.endEmptyMsg'), confirmText:t('sess.endEmptyOk') });
    if(!ok) return; State.active = null; persistActive(); closeRestTimer(); syncWakeLock(); renderTrainView(); return;
  }
  if(anyPending){
    const ok = await confirmDialog({ title:t('sess.finishTitle'), message:t('sess.finishMsg'), confirmText:t('sess.finishOk'), danger:false });
    if(!ok) return;
  }
  const completedAt = Date.now(), startedAt = Math.max(State.active.startedAt, completedAt - MAX_SESSION_MS);
  const session = { id:State.active.id, dayId:day.id, dayTitle:day.title, startedAt, completedAt, note:'', exercises };
  if(!State.history.some(s=>s.id === session.id)) State.history.push(session);
  persistHistory(); State.active = null; persistActive(); closeRestTimer(); syncWakeLock();
  const { prev, next } = rebuildGamification(), diff = gameDiff(prev, next);
  renderTopbar(); renderTrainView();
  const report = State.game.reports[session.id] || { qualified:false, xp:null, prs:[], questDone:[], questXp:0 };
  const show = ()=>openSummary(session, report, diff);
  if(gamOn() && diff.promoted) openPromotion(diff.promoted, show); else show();
  if(gamOn()) diff.newAch.forEach(toastAchievement);
}

/* ---------- Resumo da sessão ---------- */
function xpRow(label, value){ return h('div', { class:'xp-row' }, [ h('span', { text:label }), h('b', { text:value }) ]); }
function sessionTotals(session){
  const info = sessionInfo(session); let reps = 0;
  session.exercises.forEach(ex=>(ex.sets||[]).filter(s=>s.done && !ex.cardio && !('minutes' in s)).forEach(s=>{ reps += U.parseNum(s.reps) || 0; }));
  return { info, reps };
}
function openSummary(session, report, diff){
  Modals.open({ title:t('summary.title'), tall:true, build(body, foot){
    const { info, reps } = sessionTotals(session);
    body.appendChild(h('div', { class:'sum-title', text:session.dayTitle || t('lbl.workout') }));
    body.appendChild(h('div', { class:'sum-sub', text:fmtDateLong(session.completedAt) }));
    if(gamOn() && report && report.qualified && report.xp){
      const x = report.xp, total = x.total + report.questXp;
      body.appendChild(h('div', { class:'xp-hero', 'aria-live':'polite' }, [ h('div', { class:'xp-big', text:'+' + fmtInt(total) }), h('div', { class:'xp-unit', text:t('lbl.xp') }) ]));
      const rows = h('div', { class:'xp-rows' });
      if(x.sets) rows.appendChild(xpRow(t('summary.xpSets', { n:info.sets }), '+' + x.sets));
      if(x.ex) rows.appendChild(xpRow(t('summary.xpEx', { n:info.exAll }), '+' + x.ex));
      rows.appendChild(xpRow(t('summary.xpSession'), '+' + x.session));
      if(x.cardio) rows.appendChild(xpRow(t('summary.xpCardio', { n:fmtInt(info.cardioMin) }), '+' + x.cardio));
      if(x.pr) rows.appendChild(xpRow(t('summary.xpPr', { n:report.prs.length }), '+' + x.pr));
      if(report.questXp) rows.appendChild(xpRow(t('summary.xpQuests'), '+' + report.questXp));
      if(x.capped) rows.appendChild(h('div', { class:'xp-cap', text:t('summary.capped', { n:XP_RULES.dailyCap }) }));
      body.appendChild(rows);
      const lp = levelProgress(State.data.gamification.xpTotal);
      const lv = h('div', { class:'lvl-box' });
      lv.appendChild(insigniaEl(lp.rank.id, 52));
      const mid = h('div', { class:'rank-mid' });
      mid.appendChild(h('div', { class:'rank-name', text:t('rank.' + lp.rank.id) + ' • ' + t('lbl.level', { n:lp.level }) }));
      const track = h('div', { class:'progress-track slim' }); const fill = h('div', { class:'progress-fill', style:{ width:'0%' } }); track.appendChild(fill); mid.appendChild(track);
      mid.appendChild(h('div', { class:'rank-next', text: lp.nextRank ? t('rank.toNext', { xp:fmtInt(lp.xpToNextRank), rank:t('rank.' + lp.nextRank.id) }) : t('rank.max') }));
      lv.appendChild(mid); body.appendChild(lv);
      requestAnimationFrame(()=>requestAnimationFrame(()=>{ fill.style.width = lp.pct + '%'; }));
      if(diff && diff.levelUp) body.appendChild(h('div', { class:'sum-flag up', role:'status', text:t('summary.levelUp', { n:diff.levelUp.to }) }));
      if(diff && diff.promoted) body.appendChild(h('div', { class:'sum-flag up', role:'status', text:t('summary.promoted', { rank:t('rank.' + diff.promoted.to) }) }));
      if(report.questDone.length) body.appendChild(h('div', { class:'sum-flag', text:t('summary.questsDone') + ' ' + report.questDone.map(id=>questName(QUEST_POOL.day.concat(QUEST_POOL.week).find(q=>q.id === id))).join(' · ') }));
    } else if(gamOn()){
      body.appendChild(h('div', { class:'sum-flag', text:t('summary.notQualified', { s:XP_RULES.minSets, m:XP_RULES.minMinutes }) }));
    }
    const grid = h('div', { class:'stat-grid', style:{ marginBottom:'0' } });
    grid.appendChild(statCard(t('lbl.duration'), fmtDuration(session.completedAt - session.startedAt), ''));
    grid.appendChild(statCard(t('lbl.sets'), String(info.sets), t('lbl.completed')));
    grid.appendChild(statCard(t('lbl.reps'), fmtInt(reps), t('lbl.total')));
    grid.appendChild(info.volume > 0 ? statCard(t('lbl.volume'), fmtInt(kgToDisp(info.volume)), unitLabel() + ' × ' + t('lbl.repsShort')) : statCard(t('lbl.cardio'), fmtInt(info.cardioMin), t('unit.minutes')));
    body.appendChild(grid);
    if(gamOn() && report && report.prs && report.prs.length){
      const box = h('div', { class:'sum-block' }); box.appendChild(h('div', { class:'sum-h', text:t('summary.prs') }));
      report.prs.forEach(p=>box.appendChild(h('div', { class:'sum-line' }, [ h('span', { class:'pr', text:t('lbl.pr') }), ' ' + p.name + ' — ' + fmtLoad(String(p.load), true) + ' × ' + p.reps ])));
      body.appendChild(box);
    }
    const cmp = compareWithPrev(session);
    if(cmp.length){
      const box = h('div', { class:'sum-block' }); box.appendChild(h('div', { class:'sum-h', text:t('summary.vsPrev') }));
      cmp.forEach(c=>{
        const up = c.delta > 0, sign = up ? '+' : '−';
        const txt = c.kind === 'load' ? sign + fmtNum(Math.abs(kgToDisp(String(Math.abs(c.delta)))), 1) + ' ' + unitLabel() + ' ' + t('summary.inEx', { name:c.name }) : sign + fmtInt(Math.abs(c.delta)) + ' ' + t('lbl.repsShort') + ' ' + t('summary.inEx', { name:c.name });
        box.appendChild(h('div', { class:'sum-line ' + (up ? 'up' : 'down'), text:txt }));
      });
      body.appendChild(box);
    }
    if(gamOn() && diff && diff.newAch.length){
      const box = h('div', { class:'sum-block' }); box.appendChild(h('div', { class:'sum-h', text:t('summary.newAch') }));
      diff.newAch.forEach(id=>{ const def = ACHIEVEMENTS.find(a=>a.id === id); box.appendChild(h('div', { class:'sum-line ach' }, [ h('span', { class:'ach-mini', html:achIconSVG(def.icon, '#FFD76A', 22) }), ' ' + t('ach.' + id + '.n') ])); });
      body.appendChild(box);
    }
    const wk = weekDaysCount(Date.now()), g = S().weeklyGoal;
    body.appendChild(h('div', { class:'note-text', text: wk >= g ? t('summary.weekGoalHit', { a:wk, b:g }) : t('summary.weekProgress', { a:wk, b:g }) }));
    if(gamOn() && State.data.gamification.streak.current > 0) body.appendChild(h('div', { class:'note-text', text:'🔥 ' + t('card.streak', { n:State.data.gamification.streak.current }) }));
    foot.appendChild(h('button', { class:'btn btn-ghost', type:'button', onclick:()=>openShareCard({ kind:'session', session, report }) }, [ icon('share'), t('btn.shareCard') ]));
    foot.appendChild(h('button', { class:'btn btn-primary', type:'button', text:t('btn.close'), onclick:()=>Modals.close() }));
  }});
}
function statCard(label, val, sub){
  const c = h('div', { class:'stat-card' });
  c.appendChild(h('div', { class:'lbl', text:label })); c.appendChild(h('div', { class:'val', text:String(val) }));
  if(sub) c.appendChild(h('div', { class:'sub', text:sub })); return c;
}

/* ---------- Promoção de patente (celebração curta) ---------- */
function openPromotion(promo, then){
  Modals.open({ title:t('promo.title'), cls:'celebrate', onDismiss:()=>{ if(then) then(); }, build(body, foot){
    body.classList.add('promo-body');
    body.appendChild(h('div', { class:'promo-glow', 'aria-hidden':'true' }));
    body.appendChild(h('div', { class:'promo-insignia' }, [ insigniaEl(promo.to, 148) ]));
    body.appendChild(h('div', { class:'promo-rank', text:t('rank.' + promo.to) }));
    body.appendChild(h('div', { class:'promo-sub', text:t('promo.sub', { from:t('rank.' + promo.from) }) }));
    if(promo.at) body.appendChild(h('div', { class:'promo-date', text:fmtDateFull(promo.at) }));
    vibrate([80,50,80,50,160]);
    foot.appendChild(h('button', { class:'btn btn-primary btn-block', type:'button', text:t('btn.continue'), onclick:()=>Modals.close() }));
  }});
  srAnnounce(t('promo.title') + ' ' + t('rank.' + promo.to));
}

/* ---------- Cartão compartilhável (pré-visualização + compartilhar) ---------- */
async function openShareCard(spec){
  let blob = null;
  Modals.open({ title:t('share.title'), tall:true, build(body, foot){
    body.appendChild(h('div', { class:'share-wait', id:'shareWait', text:t('share.generating') }));
    foot.appendChild(h('button', { class:'btn btn-ghost', type:'button', text:t('btn.close'), onclick:()=>Modals.close() }));
    const go = h('button', { class:'btn btn-primary', id:'shareGo', type:'button', disabled:true, onclick:async ()=>{
      if(!blob) return;
      const file = new File([blob], 'protracker_' + (spec.kind === 'session' ? 'session' : spec.id) + '_' + U.dayKey(Date.now()) + '.png', { type:'image/png' });
      const r = await shareOrDownloadFile(file, APP_NAME);
      if(r === 'downloaded') showToast(t('toast.cardSaved'), 'success');
    } }, [ icon('share'), t('btn.share') ]);
    foot.appendChild(go);
    renderShareCard(spec).then(async canvas=>{
      blob = await canvasToBlob(canvas);
      const wait = $('#shareWait'); if(!wait) return;
      canvas.className = 'share-canvas'; canvas.setAttribute('role','img'); canvas.setAttribute('aria-label', t('share.alt'));
      wait.replaceWith(canvas); const g = $('#shareGo'); if(g) g.disabled = false;
    }).catch(()=>{ const wait = $('#shareWait'); if(wait) wait.textContent = t('toast.error'); });
  }});
}
