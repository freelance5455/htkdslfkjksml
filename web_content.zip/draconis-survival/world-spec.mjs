export const VARIANTS=['#ffffff','#81c9ac','#91bcec','#f4d391','#8c8395','#b3d6e7','#e6a39c','#a2c77e'];
export const MAPS=[
 {name:'Arquipélago',tag:'ILHAS DO VENTO',desc:'Enseadas, ilhas e ventos costeiros.',kind:'islands',sky:0xadd0dc,fog:0xb9cfce,water:0x269ab0,land:0x698c52,sand:0xd2be87},
 {name:'Floresta',tag:'VALE ANCESTRAL',desc:'Pinheiros, lagos e montanhas antigas.',kind:'forest',sky:0xa5bbca,fog:0xb4c7b5,water:0x36827d,land:0x497242,sand:0x9f9975},
 {name:'Vulcão',tag:'TERRAS DAS CINZAS',desc:'Cratera ativa e campos de lava.',kind:'volcano',sky:0x8f7870,fog:0xa48e7b,water:0x4a7777,land:0x55504b,sand:0x887b68},
 {name:'Cordilheira',tag:'CUMES DA TEMPESTADE',desc:'Cristas altas, vales glaciais e lagos de altitude.',kind:'alpine',sky:0xb6d1dc,fog:0xd5dce0,water:0x427f92,land:0x818981,sand:0xbabdb4},
 {name:'Tundra',tag:'HORIZONTE BRANCO',desc:'Planícies nevadas, pedras e águas geladas.',kind:'tundra',sky:0xc3d2d8,fog:0xd4dce0,water:0x648e9b,land:0xc7d2ce,sand:0xe5e8df},
 {name:'Deserto',tag:'MAR DE DUNAS',desc:'Dunas onduladas, oásis e escarpas de arenito.',kind:'desert',sky:0xd4c6a7,fog:0xdaceb5,water:0x398e86,land:0xc9a26c,sand:0xe0c292},
 {name:'Pântano',tag:'ÁGUAS ESQUECIDAS',desc:'Terreno alagado e ilhotas entre névoa e vegetação.',kind:'swamp',sky:0x9fafa8,fog:0xa6b6a6,water:0x4c6853,land:0x5e7350,sand:0x8a8464},
 {name:'Savana',tag:'PLANÍCIES DOURADAS',desc:'Pastagens secas, colinas e grandes manadas.',kind:'savanna',sky:0xc0c8a8,fog:0xd3c9ab,water:0x538b87,land:0xb09f58,sand:0xc7b17a},
 {name:'Selva',tag:'CORAÇÃO ESMERALDA',desc:'Vegetação densa, vales úmidos e cursos d’água.',kind:'jungle',sky:0xa7c7be,fog:0xa4b7a0,water:0x328780,land:0x3c6a3f,sand:0x929560},
 {name:'Cânion',tag:'FENDAS DO SOL',desc:'Ravinas profundas e mesas de pedra vermelha.',kind:'canyon',sky:0xc7c5b1,fog:0xcbb7a1,water:0x47887e,land:0xa06c49,sand:0xd3a676},
 {name:'Costa',tag:'FALÉSIAS DO NORTE',desc:'Falésias, praias extensas e mar aberto.',kind:'coast',sky:0xa9c9d4,fog:0xb4cbd0,water:0x347e98,land:0x788662,sand:0xd8ceb0},
 {name:'Taiga',tag:'FLORESTA BOREAL',desc:'Coníferas, rochas de granito e vales frios.',kind:'taiga',sky:0xaebfc9,fog:0xbbcac4,water:0x4b7c82,land:0x647961,sand:0xadb2a0},
 {name:'Charneca',tag:'COLINAS DA BRUMA',desc:'Colinas verdes, afloramentos e lagos sombrios.',kind:'moor',sky:0xa9b7bc,fog:0xb5bfb6,water:0x507d84,land:0x7c8b62,sand:0xa8a88c},
 {name:'Pangeia',tag:'TODOS OS BIOMAS',desc:'Um continente com os 13 territórios conectados.',kind:'all',sky:0xadc6cf,fog:0xb9cdc4,water:0x398997,land:0x688257,sand:0xc5b78d}
];
const smooth=(a,b,t)=>{t=Math.max(0,Math.min(1,(t-a)/(b-a)));return t*t*(3-2*t)};
const hash=(x,z)=>{let n=Math.sin(x*127.1+z*311.7)*43758.5453;return n-Math.floor(n)};
function noise(x,z){const a=Math.floor(x),b=Math.floor(z),u=smooth(0,1,x-a),v=smooth(0,1,z-b);return (hash(a,b)*(1-u)+hash(a+1,b)*u)*(1-v)+(hash(a,b+1)*(1-u)+hash(a+1,b+1)*u)*v}
function fbm(x,z){let n=0,a=1,k=0;for(let i=0;i<5;i++){n+=noise(x,z)*a;k+=a;a*=.5;x*=2.03;z*=2.03}return n/k}
export function biomeAt(map,x,z){if(map!==13)return map;const ang=(Math.atan2(z,x)+Math.PI)/(Math.PI*2);return Math.min(12,Math.floor(ang*13))}
function raw(kind,x,z){const n=fbm(x*.006,z*.006),f=fbm(x*.027+18,z*.027-7),ridge=1-Math.abs(n*2-1);let h=8+n*35+f*6;
 if(kind==='islands')h=24+n*45-Math.hypot(x,z)*.062;
 if(kind==='forest')h=9+n*52+f*8;
 if(kind==='taiga')h=11+n*46+ridge**3*18+f*5;
 if(kind==='volcano'){const r=Math.hypot(x+330,z+370);h=12+n*35+Math.max(0,170-r*.55)-Math.max(0,75-r)*1.5}
 if(kind==='alpine')h=18+ridge**3*125+f*14;
 if(kind==='tundra')h=8+n*23+f*3;
 if(kind==='desert')h=13+n*27+Math.sin(x*.023+Math.sin(z*.007)*3)*7;
 if(kind==='swamp')h=n*12-2+f*3;
 if(kind==='savanna')h=9+n*31+f*4;
 if(kind==='jungle')h=8+ridge**2*57+f*9;
 if(kind==='canyon')h=15+smooth(.25,.65,n)*68-Math.max(0,1-Math.abs(Math.sin(z*.008+x*.003))*8)*55;
 if(kind==='coast')h=22+n*47-x*.075;
 if(kind==='moor')h=12+ridge**2*43+f*5;
 // Every biome has natural river channels and a safe freshwater nesting pool.
 const river=Math.abs(z-Math.sin(x*.004)*100-240);h-=Math.max(0,1-river/32)*h*.99;
 return h;
}
export function terrain(map,x,z){map=Number.isInteger(map)&&MAPS[map]?map:0;let h;
 if(map===13){const sector=(Math.atan2(z,x)+Math.PI)/(2*Math.PI)*13,k=Math.floor(sector),t=sector-k;const a=raw(MAPS[k%13].kind,x,z),b=raw(MAPS[(k+1)%13].kind,x,z);h=a+(b-a)*smooth(.70,1,t)}else h=raw(MAPS[map].kind,x,z);
 const nest=1-smooth(0,80,Math.hypot(x,z));h=h*(1-nest)+9*nest;
 const pool=Math.hypot(x-38,z+42);h=h*smooth(12,31,pool)+.1*(1-smooth(12,31,pool));return h;
}
export const growth=age=>age<90?.42+age/90*.16:age<300?.58+(age-90)/210*.32:.9;
export const randomColor=()=>Math.random()<.28?VARIANTS[1+Math.floor(Math.random()*(VARIANTS.length-1))]:VARIANTS[0];