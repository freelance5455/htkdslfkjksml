// Run with the actual server active: bun tests/live-online.mjs
import assert from 'node:assert/strict';
const origin=process.env.SERVER_URL||'ws://localhost:3000';
const room='VERIFY_'+Date.now();
async function client(name){const ws=new WebSocket(`${origin}/ws?room=${room}&map=0&name=${name}`);const c={ws,id:null,world:null,waiters:[]};ws.addEventListener('message',event=>{const m=JSON.parse(event.data);if(m.type==='welcome')c.id=m.id;if(m.type==='world'){c.world=m;for(const waiter of [...c.waiters])if(waiter.fn(m)){clearTimeout(waiter.timeout);c.waiters.splice(c.waiters.indexOf(waiter),1);waiter.resolve(m)}}});c.wait=fn=>{if(c.world&&fn(c.world))return Promise.resolve(c.world);return new Promise((resolve,reject)=>{const w={fn,resolve,timeout:setTimeout(()=>reject(Error('Timed out waiting for server snapshot')),12000)};c.waiters.push(w)})};c.send=m=>ws.send(JSON.stringify(m));await c.wait(()=>!!c.id);return c}
const a=await client('A'),b=await client('B');
try{
 await a.wait(w=>w.players.length===2);a.send({type:'hatch'});b.send({type:'hatch'});await b.wait(w=>w.players.every(p=>!p.egg));
 a.send({type:'input',x:0,z:-1,yaw:0});await a.wait(w=>w.players.find(p=>p.id===a.id).z<-4);a.send({type:'input',x:0,z:0,yaw:Math.PI});a.send({type:'bite'});
 const damaged=await b.wait(w=>w.players.find(p=>p.id===b.id).hp<90);assert(damaged.players.find(p=>p.id===b.id).hp<90);
 for(let i=0;i<5;i++){const t=a.world.time;await a.wait(w=>w.time>t+.85);a.send({type:'bite'});if(b.world.players.find(p=>p.id===b.id).egg)break}
 const dead=await b.wait(w=>w.corpses.length>0&&w.players.find(p=>p.id===b.id).egg);assert(dead.corpses.some(c=>c.kind==='dragon'));console.log(JSON.stringify({onlinePlayers:2,pvpDamage:true,sharedCarcass:true,respawnEgg:true,map:dead.map},null,2));
}finally{a.ws.close();b.ws.close()}