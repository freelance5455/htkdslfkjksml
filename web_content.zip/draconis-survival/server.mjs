import { Room } from './simulation.mjs';
import { resolve, extname } from 'node:path';
const root=import.meta.dir;
const rooms=new Map();
const port=Number(process.env.PORT)||3000;
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript','.mjs':'text/javascript','.css':'text/css','.png':'image/png','.json':'application/json'};
function send(ws,data){try{ws.send(JSON.stringify(data))}catch{}}
const server=Bun.serve({port,hostname:'0.0.0.0',
 async fetch(req,server){const url=new URL(req.url);
  if(url.pathname==='/ws'){const code=(url.searchParams.get('room')||'PUBLICA').toUpperCase().replace(/[^A-Z0-9_-]/g,'').slice(0,24)||'PUBLICA';const map=Math.max(0,Math.min(13,Number(url.searchParams.get('map'))||0));let room=rooms.get(code);if(!room){room={sim:new Room(map),clients:new Map};rooms.set(code,room)}if(room.clients.size>=12)return new Response('Sala cheia',{status:409});const id=crypto.randomUUID();if(server.upgrade(req,{data:{id,code,name:url.searchParams.get('name')||'Dragão',lastMessage:0,messages:0}}))return;return new Response('Upgrade WebSocket obrigatório',{status:400})}
  if(url.pathname==='/health')return Response.json({ok:true,rooms:rooms.size,players:[...rooms.values()].reduce((n,r)=>n+r.clients.size,0)});
  if(req.method!=='GET'&&req.method!=='HEAD')return new Response('Método não permitido',{status:405});
  const path=url.pathname==='/'?'index.html':decodeURIComponent(url.pathname.slice(1));const abs=resolve(root,path);if(!abs.startsWith(root+'/')||path.startsWith('.')||!['index.html','game.js','world-spec.mjs','simulation.mjs','survival.css'].includes(path))return new Response('Não encontrado',{status:404});const file=Bun.file(abs);if(!await file.exists())return new Response('Não encontrado',{status:404});return new Response(file,{headers:{'Content-Type':mime[extname(path)]||'application/octet-stream','Cache-Control':'no-cache','X-Content-Type-Options':'nosniff'}});
 },websocket:{maxPayloadLength:2048,
  open(ws){const r=rooms.get(ws.data.code);r.clients.set(ws.data.id,ws);r.sim.addPlayer(ws.data.id,ws.data.name);send(ws,{type:'welcome',id:ws.data.id,room:ws.data.code,map:r.sim.map});send(ws,{type:'world',...r.sim.snapshot()})},
  message(ws,msg){const now=Date.now();if(now-ws.data.lastMessage>1000){ws.data.lastMessage=now;ws.data.messages=0}if(++ws.data.messages>80){ws.close(1008,'Limite de mensagens');return}let m;try{m=JSON.parse(String(msg))}catch{return}if(!m||typeof m!=='object'||Array.isArray(m))return;const room=rooms.get(ws.data.code);if(!room)return;const sim=room.sim,id=ws.data.id;
   if(m.type==='input')sim.input(id,m);else if(m.type==='hatch')sim.hatch(id);else if(m.type==='flight')sim.flight(id);else if(m.type==='bite')sim.bite(id);else if(m.type==='interact')send(ws,{type:'notice',text:sim.drinkEat(id)});
  },close(ws){const r=rooms.get(ws.data.code);if(!r)return;const p=r.sim.players.get(ws.data.id);if(p&&!p.egg)r.sim.corpse(p);r.sim.players.delete(ws.data.id);r.clients.delete(ws.data.id);if(!r.clients.size)rooms.delete(ws.data.code)}
 }});
setInterval(()=>{for(const r of rooms.values())r.sim.step(.05)},50);
setInterval(()=>{for(const r of rooms.values()){const json=JSON.stringify({type:'world',...r.sim.snapshot()});for(const ws of r.clients.values())try{ws.send(json)}catch{}}},100);
console.log(`Draconis: http://localhost:${server.port} · WebSocket /ws · até 12 jogadores por sala`);