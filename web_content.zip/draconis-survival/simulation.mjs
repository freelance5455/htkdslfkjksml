import {terrain,growth,randomColor,VARIANTS} from './world-spec.mjs';
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z);
const yawTo=(a,b)=>Math.atan2(-(b.x-a.x),-(b.z-a.z));
const facing=(a,b)=>Math.cos(yawTo(a,b)-a.yaw)>.55;
const uid=()=>globalThis.crypto.randomUUID();
export class Room {
 constructor(map=0){this.map=map;this.authoritativeDeaths=true;this.players=new Map;this.npcs=[];this.corpses=[];this.time=0;this.serial=0;for(let i=0;i<12;i++)this.spawn('dragon',i);for(let i=0;i<24;i++)this.spawn('deer',i)}
 ground(x,z){return Math.max(2,terrain(this.map,x,z))}
 spawn(kind,i){const angle=i*2.39996,r=kind==='deer'?80+i*19:210+i*39,x=Math.sin(angle)*r,z=Math.cos(angle)*r;const age=kind==='dragon'?[20,55,120,220,340,480][i%6]:300;this.npcs.push({id:'npc-'+this.serial++,kind,x,y:this.ground(x,z),z,yaw:angle,age,color:VARIANTS[i%VARIANTS.length],hp:kind==='dragon'?100:32,hunger:45+Math.random()*55,thirst:30+Math.random()*70,stamina:100,flying:kind==='dragon'&&age>=90&&i%2===0,alive:true,mode:'vagar',target:null,cooldown:0})}
 addPlayer(id,name){const p={id,name:String(name||'Dragão').slice(0,20),kind:'dragon',x:0,y:9,z:0,yaw:0,age:0,color:'#ffffff',hp:100,hunger:100,thirst:100,stamina:100,egg:true,flying:false,alive:true,fire:false,input:{x:0,z:0,vertical:0,sprint:false,fire:false},cooldown:0};this.players.set(id,p);return p}
 hatch(id){const p=this.players.get(id);if(!p||!p.egg)return;p.egg=false;p.color=randomColor()}
 corpse(e){if(!e.alive)return null;e.alive=false;const c={id:uid(),kind:e.kind,x:e.x,z:e.z,y:this.ground(e.x,e.z),yaw:e.yaw,age:e.age,color:e.color,amount:e.kind==='deer'?55:100,ttl:300};this.corpses.push(c);if(this.corpses.length>55)this.corpses.shift();return c}
 diePlayer(p){this.corpse(p);Object.assign(p,{x:0,y:9,z:0,age:0,hp:100,hunger:100,thirst:100,stamina:100,egg:true,flying:false,fire:false,alive:true,color:'#ffffff',input:{x:0,z:0,vertical:0}})}
 attack(a,type='bite',dt=1){if(a.egg||!a.alive||a.stamina<(type==='fire'?2:5)||type==='fire'&&a.age<90)return;
  const reach=type==='fire'?52:9+growth(a.age)*5,damage=type==='fire'?30*dt:12+growth(a.age)*12;
  for(const b of [...this.players.values(),...this.npcs])if(b!==a&&b.alive&&!b.egg&&dist(a,b)<reach&&facing(a,b)){b.hp-=damage;if(b.hp<=0){if(this.players.has(b.id)){if(this.authoritativeDeaths)this.diePlayer(b)}else this.corpse(b)}}
 }
 bite(id){const a=this.players.get(id);if(!a||a.cooldown>0||a.egg)return;this.attack(a);a.stamina=Math.max(0,a.stamina-6);a.cooldown=.8}
 drinkEat(id){const p=this.players.get(id);if(!p||p.egg||p.flying)return;const c=this.corpses.find(c=>c.amount>0&&dist(c,p)<14);if(c){const n=Math.min(35,c.amount,100-p.hunger);p.hunger+=n;c.amount-=n;p.hp=Math.min(100,p.hp+n*.15);return 'Carcaça consumida'}if(terrain(this.map,p.x,p.z)<3.8){p.thirst=Math.min(100,p.thirst+50);return 'Água recuperada'}return 'Aproxime-se da água ou de uma carcaça'}
 input(id,input){const p=this.players.get(id);if(!p)return;p.input={x:clamp(Number(input.x)||0,-1,1),z:clamp(Number(input.z)||0,-1,1),vertical:clamp(Number(input.vertical)||0,-1,1),sprint:!!input.sprint,fire:!!input.fire};if(Number.isFinite(input.yaw))p.yaw=input.yaw}
 flight(id){const p=this.players.get(id);if(!p||p.egg||p.age<90||!p.flying&&p.stamina<16)return;p.flying=!p.flying;if(!p.flying)p.y=this.ground(p.x,p.z)}
 step(dt,players=true){this.time+=dt;
  for(const p of this.players.values()){p.cooldown=Math.max(0,p.cooldown-dt);if(!players||p.egg)continue;const inp=p.input||{},m=Math.max(1,Math.hypot(inp.x||0,inp.z||0)),moving=m>1||Math.hypot(inp.x||0,inp.z||0)>.1,speed=p.flying?(inp.sprint?45:32):p.age<90?8:13;p.age+=dt;p.x=clamp(p.x+(inp.x||0)/m*speed*dt,-1040,1040);p.z=clamp(p.z+(inp.z||0)/m*speed*dt,-1040,1040);const ground=this.ground(p.x,p.z);
   if(p.flying){p.y=clamp(p.y+(inp.vertical||0)*20*dt,ground+9,360);p.stamina-=dt*(inp.sprint?6:3.5);if(p.stamina<=1){p.y-=20*dt;if(p.y<=ground+10){p.y=ground;p.flying=false}}}else{p.y=ground;p.stamina=Math.min(100,p.stamina+dt*6)}
   p.fire=!!inp.fire&&p.age>=90&&p.stamina>2;if(p.fire){p.stamina-=14*dt;this.attack(p,'fire',dt)}p.stamina=clamp(p.stamina,0,100);p.hunger=Math.max(0,p.hunger-dt*(moving?.11:.065));p.thirst=Math.max(0,p.thirst-dt*(p.flying?.15:.09));if(p.hunger<1||p.thirst<1)p.hp-=3*dt;else if(p.hunger>65&&p.thirst>65)p.hp=Math.min(100,p.hp+dt*.28);if(p.hp<=0)this.diePlayer(p);
  }
  const living=[...this.players.values(),...this.npcs].filter(e=>e.alive&&!e.egg);
  for(const n of this.npcs){if(!n.alive)continue;n.age+=dt;n.hunger=Math.max(0,n.hunger-dt*.16);n.thirst=Math.max(0,n.thirst-dt*.22);n.cooldown=Math.max(0,n.cooldown-dt);let target,mode='vagar';
   const threat=living.filter(e=>e!==n&&e.kind==='dragon'&&dist(e,n)<65).sort((a,b)=>dist(a,n)-dist(b,n))[0];
   if(n.kind==='deer'&&threat){target={x:n.x+(n.x-threat.x)*2,z:n.z+(n.z-threat.z)*2};mode='fugir'}
   else if(n.thirst<38){target={x:38,z:-42};mode='beber'}
   else if(n.hunger<55&&n.kind==='dragon'){const c=this.corpses.filter(c=>c.amount>0).sort((a,b)=>dist(a,n)-dist(b,n))[0];if(c&&dist(c,n)<350){target=c;mode='comer'}else {target=living.filter(e=>e!==n&&e.kind==='deer').sort((a,b)=>dist(a,n)-dist(b,n))[0];mode='caçar'}}
   else if(n.kind==='dragon'&&n.age>100&&threat&&threat.kind==='dragon'&&threat.age<n.age*.75&&dist(threat,n)<38){target=threat;mode='defender'}
   if(!target){if(!n.target||Math.hypot(n.x-n.target.x,n.z-n.target.z)<14)n.target={x:clamp(n.x+Math.sin(this.time*.03+Number(n.id.slice(4)))*180,-1000,1000),z:clamp(n.z+Math.cos(this.time*.023+Number(n.id.slice(4)))*180,-1000,1000)};target=n.target}
   const dx=target.x-n.x,dz=target.z-n.z,d=Math.hypot(dx,dz);n.mode=mode;
   const wantsFlight=n.kind==='dragon'&&n.age>=90&&n.stamina>12&&d>80&&mode!=='fugir';n.flying=wantsFlight;n.stamina=clamp(n.stamina+dt*(wantsFlight?-2:5),0,100);
   if(d>7){const old=n.yaw;n.yaw=yawTo(n,target);n.turn=Math.atan2(Math.sin(n.yaw-old),Math.cos(n.yaw-old))/dt;const speed=n.flying?20:mode==='fugir'?15:mode==='caçar'?13:n.kind==='deer'?4:7;n.x=clamp(n.x+dx/d*speed*dt,-1035,1035);n.z=clamp(n.z+dz/d*speed*dt,-1035,1035)}
   n.y=this.ground(n.x,n.z)+(n.flying?22+Math.sin(this.time+n.age)*3:0);
   if(d<15&&mode==='beber'){n.flying=false;n.y=this.ground(n.x,n.z);n.thirst=Math.min(100,n.thirst+dt*25)}
   if(d<14&&mode==='comer'&&target.amount>0){const food=Math.min(target.amount,dt*14);target.amount-=food;n.hunger=Math.min(100,n.hunger+food)}
   if(d<13&&(mode==='caçar'||mode==='defender')&&n.cooldown<=0){n.flying=false;this.attack(n);n.cooldown=1.2}
   if(n.kind==='deer')n.hunger=Math.min(100,n.hunger+dt*.25);if(n.hunger<1||n.thirst<1)n.hp-=dt*2;if(n.hp<=0)this.corpse(n);
  }
  this.corpses=this.corpses.filter(c=>(c.ttl-=dt)>0&&c.amount>0);this.npcs=this.npcs.filter(n=>n.alive);if(this.time-this.lastSpawn>18||this.lastSpawn===undefined){this.lastSpawn=this.time;if(this.npcs.filter(n=>n.kind==='deer').length<24)this.spawn('deer',this.serial);if(this.npcs.filter(n=>n.kind==='dragon').length<12)this.spawn('dragon',this.serial)}
 }
 snapshot(){return {map:this.map,time:this.time,players:[...this.players.values()].map(({input,target,...p})=>p),npcs:this.npcs.map(({target,...n})=>n),corpses:this.corpses}}
}