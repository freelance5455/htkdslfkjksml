"""Rebuild the provided exported HTML without changing its original framework."""
from pathlib import Path
from bs4 import BeautifulSoup
import json
ROOT=Path(__file__).resolve().parent
source=ROOT/'source'/'original.html'
model_path=ROOT/'source'/'meleys.bbmodel'
soup=BeautifulSoup(source.read_text(),'html.parser')
module=soup.find('script',type='module')
original=module.string
original=original.replace('g=t===1?1100:t===0?470:120','g=[0,1,6,8,11,12,13].includes(t)?(t===8?1300:t===1?1100:650):[4,5,9].includes(t)?0:180')
extension=(ROOT/'extension.js').read_text()
anchor='const lv=[{name:"Meleys"'
assert anchor in original, 'Wrong original export: engine anchor missing'
imports="import {MAPS,terrain,biomeAt,growth,randomColor} from './world-spec.mjs';\nimport {Room} from './simulation.mjs';\n"
(ROOT/'game.js').write_text(imports+original.replace(anchor,extension+'\n'+anchor,1))
module.clear();module['src']='./game.js'
model=json.loads(model_path.read_text())
texture=model['textures'][0]['source']
assert texture.startswith('data:image/'), 'Missing model texture'
data={k:model[k] for k in ['resolution','elements','groups','outliner','animations']}
asset=soup.find('script')
asset.string='window.DRACONIS_MODEL='+json.dumps(data,separators=(',',':'))+';window.DRACONIS_TEXTURE='+json.dumps(texture)+';'
link=soup.new_tag('link',rel='stylesheet',href='./survival.css');soup.head.append(link)
soup.title.string='Draconis — Sobrevivência & PvP'
(ROOT/'index.html').write_text(str(soup))
print('Built index.html + game.js; original React/Three.js and Meleys assets preserved.')