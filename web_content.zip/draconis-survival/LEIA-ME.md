# Draconis — Sobrevivência & PvP

Atualização do `index.html` fornecido, mantendo o jogo em React + Three.js e o modelo Meleys do Blockbench. O pacote contém o jogo pronto e o servidor multiplayer; não é necessário recompilar para jogar.

## Rodar o jogo

1. Instale o runtime **Bun** pelo site oficial: https://bun.sh.
2. Extraia o ZIP e abra um terminal na pasta `draconis-survival`.
3. Execute:

```sh
bun start
```

4. Abra **http://localhost:3000** no navegador. Chrome/Firefox com aceleração gráfica são recomendados.

**Não abra `index.html` com duplo clique.** Os módulos e o multiplayer precisam ser servidos por HTTP. Não basta enviar apenas o HTML: mantenha os arquivos do pacote juntos.

## Jogar com outras pessoas

- Abra **Jogar online**.
- Informe seu nome, o endereço do servidor e um código de sala.
- Todos devem usar **o mesmo endereço e código**.
- A primeira pessoa a criar a sala define o mapa escolhido no menu. As próximas entram nesse mapa.
- Até **12 jogadores por sala**. Os dragões selvagens, cervos e carcaças são compartilhados no online.
- O servidor calcula posição, crescimento, vida, necessidades, energia e combate. O cliente envia controles, não valores de vida ou dano.

### Mesma rede Wi-Fi

Execute o servidor em um computador. Descubra o IP local dele e abra, por exemplo, `http://192.168.1.20:3000` nos outros dispositivos. Libere a porta TCP 3000 no firewall se necessário. Use esse mesmo endereço no formulário de conexão.

### Pela internet

Hospede este servidor Bun em uma máquina/serviço que aceite processos contínuos e **WebSocket**. Configure HTTPS/WSS e encaminhe `/ws` ao servidor. O pacote **não inclui hospedagem, domínio ou servidor público**. Um site servido por HTTPS não pode conectar a um servidor `ws://` inseguro.

A porta pode ser configurada pela variável `PORT` (padrão: 3000).

## O que mudou

- Nascimento no ovo; filhote → juvenil → adulto, com escala contínua.
- **28% de chance** de cor variante ao chocar. A aparência base continua Meleys; a variação é uma tonalização da textura, não uma nova espécie.
- Juvenil aos **90 segundos de jogo**, adulto aos **5 minutos**. Voo e Dracarys só a partir da fase juvenil.
- Vida, sede, fome e energia. Voo consome energia inclusive parado; fogo também. Sem energia, o dragão pousa. Descansar no chão recupera energia.
- HUD pequeno no canto superior esquerdo: sete segmentos por barra, verde/azul/laranja/branco; sem porcentagens visíveis. Apenas estágio/idade abaixo.
- 12 dragões selvagens e 24 cervos por mundo, com reposição gradual. Dragões possuem diferentes idades e cores; voam, pousam, descansam, bebem, caçam e comem. Filhotes selvagens não voam.
- Mordida para caçar desde filhote; fogo ao crescer. Combate PvE e PvP online.
- Mortos deixam o modelo deitado no chão, comestível. Isso inclui dragões, cervos e jogadores. Carcaças desaparecem quando consumidas ou após cinco minutos.
- Cauda articulada com mola/amortecimento: os segmentos seguem a curva com atraso, em vez de girarem todos instantaneamente.
- Relevo suave com ruído em várias escalas, rios, lagoa junto ao ninho, texturização procedural do solo, névoa e vegetação por região.

## 14 mapas

**Preservados e retrabalhados:** Arquipélago, Floresta, Vulcão.

**10 novos:** Cordilheira, Tundra, Deserto, Pântano, Savana, Selva, Cânion, Costa, Taiga, Charneca.

**Integrado:** Pangeia — os 13 territórios conectados em setores de um único continente, com transições de relevo.

Os terrenos são **procedurais/naturalistas**, não mapas fotorrealistas feitos com fotogrametria. O visual do dragão permanece o do modelo Blockbench fornecido. Não há novos assets fotorrealistas licenciados neste pacote.

## Controles

| Tecla | Ação |
|---|---|
| WASD | Mover |
| Arrastar a tela | Girar câmera |
| Espaço | Decolar / pousar |
| R / C | Subir / descer |
| Shift | Acelerar no voo |
| F | Dracarys |
| Q | Morder |
| E | Chocar, beber ou comer |
| Esc | Menu |
| H | Ajuda |

No celular: analógico, botões de ação, subida/descida e **Morder**. Arraste a área livre para olhar. Os controles de toque ficam ocultos em dispositivos que usam ponteiro preciso (mouse).

Procure água na lagoa perto do ninho ou nos rios; aproxime-se e use **E**. Para comer, aproxime-se de uma carcaça no chão. Comer também recupera um pouco de vida.

## Limitações desta versão

- Multiplayer funcional de pequena escala, **experimental**: não foi testado sob carga de 12 jogadores nem em redes de alta latência. Não inclui contas, matchmaking, persistência online nem proteção anticheat completa.
- Salas ficam em memória; reiniciar o servidor apaga as sessões. Uma sala é removida quando fica vazia. O save local do jogo continua disponível no modo offline.
- **Pausar no online não pausa o mundo**: o personagem para de se mover, mas continua sujeito à fome, sede e ataques.
- Geometria ambiental não possui colisão física detalhada; a colisão principal é contra o relevo. A cauda tem física secundária de mola, não colisão rígida com cada árvore/pedra.
- O PvP usa alcance e cone de ataque, não colisão individual de cada partícula de fogo.
- Recomenda-se aceleração gráfica. Dragões articulados e vegetação podem pesar em celulares antigos.

## Arquivos

- `index.html`, `game.js`: jogo atualizado, já pronto.
- `survival.css`: HUD e interface adicional.
- `world-spec.mjs`: biomas, terreno e regras de crescimento/cor.
- `simulation.mjs`: IA, combate, necessidades e carcaças compartilhados entre offline e servidor.
- `server.mjs`: HTTP/WebSocket, salas e validações de controles.
- `extension.js`: alterações legíveis aplicadas ao motor original exportado.
- `source/original.html`, `source/meleys.bbmodel`: originais preservados para reconstrução.
- `tests/`: testes de regras e teste online com dois clientes.

### Testar / reconstruir

```sh
bun test tests
# Com o servidor ativo:
bun tests/live-online.mjs
```

Para reconstruir após editar a extensão: instale Python 3 e `beautifulsoup4`, depois execute `bun run build`. Os arquivos prontos já estão no pacote; isto é opcional.

## Verificação realizada

- Compilação do frontend e servidor sem erros.
- **7 testes automatizados aprovados, 75 verificações**.
- Dois clientes reais de WebSocket: dano PvP, carcaça compartilhada e renascimento no ovo confirmados.
- Dois navegadores na mesma sala: mapa compartilhado e entidades remotas confirmados.
- Navegador: 14 opções de mapa, voo juvenil, gasto de energia parado, recuperação de sede e modelo de carcaça deitado confirmados; nenhum erro JavaScript capturado nessa execução.