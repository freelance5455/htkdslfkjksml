# CPLS V2 — Stage 1135

## Futures Sample Continuity Hardened
- Rejects invalid or out-of-order native price timestamps.
- Clamps future-dated samples to the current time.
- Replaces a duplicate timestamp with the newest price instead of creating duplicate samples.
- Keeps the existing 7-day sample retention and 12,000-sample cap.
- Builds on Stage 1134 without changing the LBank transport.

Source ZIP stage only; APK build not performed.
