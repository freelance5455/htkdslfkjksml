# Validação do arquivo de estaqueamento existente

Foi localizado no material do projeto o arquivo `estaqueamento_20m_atualizado.txt`. Apesar da extensão `.txt`, seu conteúdo é KML e contém 10.042 pontos identificados como estacas de 20 em 20 metros, indo de KM 0+000 a KM 200+820.

Uma verificação geodésica das coordenadas consecutivas encontrou:
- Intervalo informado nas descrições: 20,0 m.
- Intervalo mediano calculado entre coordenadas: aproximadamente 10,40 m.
- Comprimento acumulado pelas coordenadas: aproximadamente 104,63 km.
- Progressiva final declarada no arquivo: 200,82 km.

Há uma divergência próxima de 48% entre a progressiva descrita e a geometria. Por segurança, o importador MAPEANDO agora compara a distância declarada com a distância calculada e rejeita o arquivo quando a diferença ultrapassa 15%. Isso evita produzir marcações de campo com quilometragem incorreta.

O arquivo deve ser corrigido ou substituído por um eixo georreferenciado confiável antes de ser usado como referência operacional.
