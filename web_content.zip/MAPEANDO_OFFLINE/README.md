# MAPEANDO — base offline-first (PWA + Android)

Este repositório contém a primeira base de implementação da arquitetura escolhida. **Ainda não é um APK compilado nem uma versão homologada para campo.** A interface é compartilhada entre PWA e APK via Capacitor.

## O que já está preparado
- PWA com manifest e Service Worker para armazenar a aplicação.
- MapLibre GL JS como motor cartográfico.
- Importação de arquivo `.pmtiles` para armazenamento local no IndexedDB.
- Importação de eixo rodoviário GeoJSON `LineString` em WGS84 e leitura de KML com validação de distância declarada versus distância calculada.
- Projeção do GPS sobre o eixo importado para calcular a progressiva ao longo da geometria, com sentido crescente/decrescente.
- Geração da referência de estaca configurável (20 m por padrão).
- Registros de serviços, patologias e fotos em banco local IndexedDB.
- Fila de sincronização preparada para Supabase.
- Estrutura Capacitor para gerar o projeto Android.
- Versão HTML anterior preservada em `legacy/`.

## Limitações desta entrega
1. O pacote cartográfico real `.pmtiles` e seu estilo MapLibre ainda precisam ser fornecidos/gerados para o trecho de rodovia escolhido. Não existe mapa offline regional embutido nesta entrega. O estilo incluído é um modelo para arquivos compatíveis com o esquema OpenMapTiles.
2. A sincronização exige criar um projeto Supabase, executar `sql/001_field_records.sql` e preencher `.env` com URL e chave pública. O botão Configurações já inicia o login por link enviado ao e-mail; o projeto Supabase ainda precisa ser criado e configurado.
3. A câmera desta base usa `getUserMedia` (PWA/WebView). A integração de câmera nativa Android e armazenamento SQLite nativo é etapa de endurecimento antes de uso comercial contínuo.
4. O algoritmo de projeção é uma base de navegação sobre o eixo GeoJSON, não substitui levantamento topográfico nem validação de engenharia. A calibração quilométrica e os marcos oficiais precisam ser associados ao eixo antes de uso operacional.
5. O mapa precisa de um arquivo de estilo JSON compatível com as camadas do arquivo PMTiles. Importe o `.pmtiles` e depois o `style.json` correspondente.

## Instalação e execução
Requer Node.js 20 ou superior e Android Studio para APK.

```bash
npm install
cp .env.example .env
npm run dev
```

Build PWA:

```bash
npm run build
npm run preview
```

Android:

```bash
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

No Android Studio, configure o SDK, permissões de localização/câmera, compile e assine o APK.

## Preparar mapa offline
- Gere/obtenha um arquivo PMTiles da área autorizada para uso offline.
- Gere ou obtenha um estilo MapLibre JSON que use a fonte vetorial do arquivo e os nomes corretos de `source-layer`.
- O app armazena o arquivo PMTiles no IndexedDB do dispositivo. Em áreas grandes, confirme o espaço disponível antes de importar.
- Não use os servidores públicos padrão de tiles do OpenStreetMap para baixar regiões em massa. Use arquivo próprio ou fornecedor que permita expressamente download/offline.

## Dados e privacidade
Os registros e fotografias ficam localmente no dispositivo. A sincronização só acontece depois de configurar o Supabase e autenticar um usuário. A chave `anon` é pública e deve ser protegida por RLS; nunca coloque `service_role` no aplicativo.

## Licenças de terceiros
Consulte `LICENSES/TERCEIROS.md`. O licenciamento do código próprio, nome e identidade visual do MAPEANDO ainda precisa ser definido pelo titular. Preserve as licenças completas e avisos das versões efetivamente instaladas antes de redistribuir o APK.

O estilo de demonstração incluído evita fontes externas para manter o mapa base sem dependência de rede; nomes de ruas e localidades podem ser adicionados posteriormente com arquivos de fontes/glyphs locais licenciados e empacotados no pacote offline.
