# Avisos de componentes de terceiros

O código próprio do MAPEANDO ainda não recebeu uma licença de distribuição definida pelo titular do projeto. Não interprete as licenças de terceiros como licença do nome, marca, identidade visual ou código próprio do MAPEANDO.

Componentes planejados:
- MapLibre GL JS — BSD-3-Clause.
- PMTiles JavaScript — BSD-3-Clause.
- Capacitor — MIT.
- Supabase JavaScript client — MIT.
- Dados OpenStreetMap, quando usados — ODbL, com atribuição © OpenStreetMap contributors.

As licenças completas e avisos das versões efetivamente instaladas devem ser mantidos no pacote de distribuição final. A licença Apache 2.0 não é presumida para o projeto inteiro apenas por ter sido discutida anteriormente.
