create table if not exists public.field_records (
  id uuid primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  road text not null,
  km numeric not null default 0,
  chainage_m integer not null,
  station text not null,
  direction smallint not null check (direction in (-1,1)),
  lane smallint not null check (lane between 0 and 3),
  record_type text not null,
  description text not null,
  gps jsonb,
  photo_path text,
  created_at timestamptz not null,
  updated_at timestamptz not null default now()
);
create index if not exists field_records_user_created_idx on public.field_records(user_id, created_at desc);
alter table public.field_records enable row level security;
drop policy if exists "users manage own field records" on public.field_records;
create policy "users manage own field records" on public.field_records for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('mapeando-fotos','mapeando-fotos',false,15728640,array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;
drop policy if exists "users upload own photos" on storage.objects;
create policy "users upload own photos" on storage.objects for insert to authenticated with check (bucket_id='mapeando-fotos' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists "users read own photos" on storage.objects;
create policy "users read own photos" on storage.objects for select to authenticated using (bucket_id='mapeando-fotos' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists "users update own photos" on storage.objects;
create policy "users update own photos" on storage.objects for update to authenticated using (bucket_id='mapeando-fotos' and (storage.foldername(name))[1]=auth.uid()::text);
