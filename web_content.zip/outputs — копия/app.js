const STORAGE_KEY = 'my-metrics-v1';
let metrics = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
let activeMetricId = null;
const $ = selector => document.querySelector(selector);
const labels = { date:'Дата', day:'днях', hour:'часах', minute:'минутах', second:'секундах' };
const units = { day:'дн.', hour:'ч.', minute:'мин.', second:'сек.' };
const nowLocal = () => { const d = new Date(); return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 19); };

// Старые записи с календарными датами остаются доступными на шкале «Дата».
metrics.forEach(metric => { if (!metric.entries.some(entry => entry.relativeUnit)) metric.interval = 'date'; });

function save() { localStorage.setItem(STORAGE_KEY, JSON.stringify(metrics)); }
function declension(n, forms) { return `${n} ${forms[n % 10 === 1 && n % 100 !== 11 ? 0 : n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 10 || n % 100 >= 20) ? 1 : 2]}`; }
function format(value) { return String(Number(value).toFixed(5)).replace(/\.?(0+)$/, '').replace('.', ','); }
function entryTime(entry) { return entry.timestamp || entry.date; }
function dateLabel(time, includeTime = false) {
  const normal = time.includes('T') ? time : `${time}T12:00:00`;
  return new Intl.DateTimeFormat('ru-RU', includeTime ? { day:'numeric', month:'short', hour:'2-digit', minute:'2-digit', second:'2-digit' } : { day:'numeric', month:'short' }).format(new Date(normal));
}

function dateSeries(entries) {
  return entries.filter(entry => entryTime(entry)).sort((a, b) => entryTime(a).localeCompare(entryTime(b))).map(entry => ({
    value:Number(entry.value), x:new Date(entryTime(entry).includes('T') ? entryTime(entry) : `${entryTime(entry)}T12:00:00`).getTime(), label:dateLabel(entryTime(entry), entryTime(entry).includes('T'))
  }));
}
function relativeSeries(entries, interval) {
  const groups = new Map();
  entries.filter(entry => entry.relativeUnit === interval).forEach(entry => {
    const x = Number(entry.relative);
    const group = groups.get(x) || []; group.push(Number(entry.value)); groups.set(x, group);
  });
  return [...groups].sort(([a], [b]) => a - b).map(([x, values]) => ({ value:values.reduce((sum, value) => sum + value, 0) / values.length, x, label:`${format(x)} ${units[interval]}` }));
}
function seriesFor(metric) { return metric.interval === 'date' ? dateSeries(metric.entries) : relativeSeries(metric.entries, metric.interval); }

function chart(series) {
  if (!series.length) return '<text x="165" y="76" class="chart-empty">Добавьте первое значение</text>';
  const values = series.map(point => point.value), minY = Math.min(...values), maxY = Math.max(...values), spreadY = maxY - minY || Math.max(Math.abs(maxY) * .12, 1);
  const minX = Math.min(...series.map(point => point.x)), maxX = Math.max(...series.map(point => point.x)), spreadX = maxX - minX || 1;
  const x = point => series.length === 1 ? 165 : 14 + ((point.x - minX) / spreadX) * 302;
  const y = point => 116 - ((point.value - minY + spreadY * .08) / (spreadY * 1.16)) * 88;
  const points = series.map(point => `${x(point)},${y(point)}`).join(' ');
  const fill = `${x(series[0])},130 ${points} ${x(series.at(-1))},130`;
  const xAxisLabels = `<text x="14" y="142" class="x-label">${series[0].label}</text><text x="316" y="142" text-anchor="end" class="x-label">${series.at(-1).label}</text>`;
  return `<defs><linearGradient id="gradient" x1="0" x2="0" y1="0" y2="1"><stop stop-color="#aeb5ff" stop-opacity=".55"/><stop offset="1" stop-color="#eef0ff" stop-opacity=".05"/></linearGradient></defs><path class="grid" d="M14 34H316M14 75H316M14 116H316"/><polygon class="area" points="${fill}"/><polyline class="graph" points="${points}"/>${series.map(point => `<circle class="point" cx="${x(point)}" cy="${y(point)}" r="4"/>`).join('')}${xAxisLabels}`;
}
function graphRange(series, interval) {
  if (!series.length) return `Ось X: ${labels[interval]}`;
  return interval === 'date' ? `Ось X: даты · ${series[0].label} — ${series.at(-1).label}` : `Ось X: время от начала в ${labels[interval]}`;
}
function render() {
  const container = $('#metrics'); container.replaceChildren();
  $('#emptyState').hidden = metrics.length !== 0;
  metrics.forEach(metric => {
    const node = $('#metricTemplate').content.cloneNode(true);
    const interval = metric.interval || 'date';
    const series = seriesFor(metric);
    const last = series.at(-1);
    node.querySelector('.metric-name').textContent = metric.name;
    node.querySelector('.latest').textContent = last ? `Последнее: ${format(last.value)}${metric.unit ? ` ${metric.unit}` : ''} · ${last.label}` : 'Нет записей в этом интервале';
    node.querySelector('.count').textContent = declension(metric.entries.length, ['запись', 'записи', 'записей']);
    node.querySelector('.chart').innerHTML = chart(series);
    node.querySelector('.chart-range').textContent = graphRange(series, interval);
    node.querySelectorAll('[data-interval]').forEach(button => {
      button.classList.toggle('active', button.dataset.interval === interval);
      button.onclick = () => { metric.interval = button.dataset.interval; save(); render(); };
    });
    node.querySelector('.add-entry').onclick = () => openEntry(metric.id);
    node.querySelector('.more').onclick = () => { if (confirm(`Удалить показатель «${metric.name}»?`)) { metrics = metrics.filter(item => item.id !== metric.id); save(); render(); } };
    container.append(node);
  });
}
function setTimeInput(interval) {
  const input = $('#entryDate'), relative = interval !== 'date';
  input.type = relative ? 'number' : 'date';
  input.step = 'any'; input.min = relative ? '0' : '';
  input.placeholder = relative ? `Например, ${interval === 'second' ? '1' : '0,5'}` : '';
  input.value = relative ? '' : nowLocal().slice(0, 10);
  $('#entryTimeLabel').firstChild.nodeValue = relative ? `Время от начала, в ${labels[interval]} ` : 'Дата ';
}
function openEntry(id) {
  activeMetricId = id; const metric = metrics.find(item => item.id === id);
  $('#entryTitle').textContent = `Значение: ${metric.name}`; $('#entryValue').value = '';
  $('#timePrecision').value = metric.interval || 'date'; setTimeInput(metric.interval || 'date');
  $('#entryDialog').showModal(); setTimeout(() => $('#entryValue').focus(), 100);
}

$('#addMetricButton').onclick = () => { $('#metricForm').reset(); $('#metricDialog').showModal(); setTimeout(() => $('#metricName').focus(), 100); };
$('#metricForm').onsubmit = event => { event.preventDefault(); metrics.unshift({ id:crypto.randomUUID(), name:$('#metricName').value.trim(), unit:$('#metricUnit').value.trim(), interval:'date', entries:[] }); save(); $('#metricDialog').close(); render(); };
$('#timePrecision').onchange = event => setTimeInput(event.target.value);
$('#entryForm').onsubmit = event => {
  event.preventDefault(); const metric = metrics.find(item => item.id === activeMetricId); const interval = $('#timePrecision').value, time = $('#entryDate').value;
  metric.interval = interval;
  if (interval === 'date') {
    metric.entries = metric.entries.filter(entry => entryTime(entry) !== time);
    metric.entries.push({ value:$('#entryValue').value, timestamp:time });
  } else {
    metric.entries = metric.entries.filter(entry => !(entry.relativeUnit === interval && Number(entry.relative) === Number(time)));
    metric.entries.push({ value:$('#entryValue').value, relative:Number(time), relativeUnit:interval });
  }
  save(); $('#entryDialog').close(); render();
};
document.querySelectorAll('[data-close]').forEach(button => button.onclick = () => button.closest('dialog').close());
render();
