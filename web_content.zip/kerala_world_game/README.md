# Kerala World — Wayanad Map Update

A lightweight browser-based 3D social exploration prototype inspired by a colourful Kerala/Wayanad world.

## New in this update
- Festival stage with a microphone and speakers; use the map menu to travel there and start performance/dance mode.
- Chaya kada with a roof, counter and stools.
- Small market lane with three stalls and produce props.
- Map menu destinations let you visit the new locations.
- Performance tuning for lower-end phones: reduced tree/rock count, disabled real-time shadows, capped pixel ratio and throttled rendering to about 33 FPS.

## Run it
1. Extract the ZIP.
2. Open `index.html` in a browser with internet access (Three.js is loaded from a CDN).
3. On mobile, use the left joystick to move and the arrow button to jump. Tap the map icon to visit the stage, chaya kada, market or forest.

## Controls
- Mobile: joystick, jump button, map button, dance/emote buttons.
- Desktop: WASD or arrow keys.
- Stage: open the map and choose **Festival stage** to enter performance mode.

## Notes
This is a local prototype, not an online multiplayer game. Stage performance is represented by avatar dance/performance mode; it does not play licensed songs. The prototype is a browser project, not an APK.


## Small v0.2 patch
- Added drag-to-rotate third-person camera on the open game view.
- Added one small pond with water and lily pads.
- Everything else stays based on the v0.2 Stage + Chaya Kada + Market build.

On mobile, drag horizontally on an open part of the world to rotate the camera. Use the existing joystick to move the character. The Three.js engine still loads from a CDN, so internet is needed.


## Combined Social Update (no vehicles)
- Chaya Kada: added benches and local NPCs; use the map to visit and order demo tea/snacks or sit.
- Market: expanded with two extra produce stalls and vendor NPCs; try the demo purchase and vendor interaction buttons.
- Stage: added decorative lights; use the map to visit the stage and interact with the microphone, festival music toggle, or dance.
- Retains the v0.2 Wayanad map, pond, drag camera, movement, day/night, emotes, and wardrobe.
- No scooter or vehicle features are included. All orders/purchases are visual demos and do not process real payments.
- Three.js is loaded from a CDN, so an internet connection is needed when opening the game.


## Living Village Update
- NPC Life: additional villagers wander around the village.
- Player Customization: wardrobe now offers pink, mint, yellow, blue and purple outfit colours.
- Kerala House Interior: use the map to enter the traditional home and leave it again.
- Fishing: use the map to visit the pond and tap the fishing interaction for a demo catch.
- Weather: tap 🌧️ in the top bar to toggle animated rain; the sun button still toggles day/night.
- Existing pond, drag camera, Chaya Kada, Market, Stage and their interactions are retained.
- No vehicle or scooter features are included.
- This is a local browser prototype; catches and orders are demo interactions, not saved online. Three.js loads from a CDN, so an internet connection is needed.


## No-NPC Update
- Removed roaming villagers and decorative shop/market NPC characters.
- Retains the Wayanad map, pond, drag camera, Chaya Kada, Market stalls, Stage, house interior, fishing demo, outfit colours and rain/day-night controls.
- No vehicle features are included.


## Realistic Walking & Trees Update
- Added a smoother walking cycle with alternating legs and opposite arm swings, subtle body bounce, and easing back to idle.
- Improved tree shapes with more natural broadleaf crowns, visible branches, richer greens, and fuller coconut-palm fronds.
- Keeps the no-NPC setup, existing Wayanad map, pond, drag camera, Chaya Kada, Market, Stage, house interior, fishing, outfit colours and weather.
- No vehicles included.


## Scenic Open World Graphics Update
- Replaced the sandy trail with a winding asphalt village road, road shoulders, white edge lines and dashed lane markings.
- Added a blue river valley and a small rail-sided bridge aligned with the road. No vehicles were added.
- Improved daylight, fog distance and shadows, deepened the foliage palette, and added meadow grass tufts.
- Retains the no-NPC setup, character walking animation, Wayanad map, pond, drag camera, Chaya Kada, Market, Stage, house interior, fishing, wardrobe and rain/day-night controls.
- Three.js loads from a CDN, so an internet connection is required.


## Startup Bug Fix
- Fixed a JavaScript initialization-order bug: the random helper is now declared before grass/road environment generation uses it. This was causing the loading screen to remain visible with a blank sky.


## Smooth Performance Update (no object removals)
- Kept the existing scene and visible objects; grass blades are batched into instanced meshes to reduce draw calls.
- Reduced rendering resolution on high-density phone screens, disabled costly antialiasing, and lowered shadow-map resolution for smoother mobile play.
- Foliage and tiny road details no longer cast expensive shadows; their visible shapes remain in the world.
- If the phone still struggles, close other browser tabs and use Chrome with Battery Saver turned off while playing.


## Kerala Districts, UI Fix & Graphics Settings Update
- Fixed the missing weather button reference that could stop UI event handlers from being attached.
- Added a Kerala travel directory covering all 14 districts from Thiruvananthapuram to Kasaragod, with popular attractions such as Kovalam, Jatayu Earth Center, Alappuzha backwaters, Munnar, Fort Kochi, Thrissur Pooram, Silent Valley, Kozhikode Beach, Edakkal Caves, Muzhappilangad Beach and Bekal Fort.
- Added Low / Medium / High graphics presets, 30 / 60 / 90 / 120 FPS target options, and 50–100% render scale.
- All existing world objects are retained. The district directory currently uses travel points in the existing scenic map; unique terrain/maps for each destination are not yet modeled.
- Browser/device refresh rate and GPU may limit actual FPS.


## Reference-Inspired Festival Grounds Update
- Added a broad circular festival plaza with a tiled approach, public benches and lamp posts around the existing red-roof stage.
- Added extra coconut palms, a waterside promenade and simple village signboards for a low-poly Kerala open-world look.
- No existing objects were removed. No vehicles or NPCs were added.
- The current district menu and graphics settings remain included.


## Kerala Coastal Town Expansion
- Added a separate explorable coastal-town area inspired by the supplied reference: twin lighthouses, seaside plaza, beach and blue sea, coastal road, red-roof pavilion, pastel shops, benches, promenade lamps and coconut palms.
- Open the map and choose “Coastal Town — Lighthouses & Beach Plaza”.
- Existing Wayanad map, festival plaza, Chaya Kada, Market, stage, pond, house interior, fishing, weather, district directory and graphics settings are retained.
- No vehicles or NPCs were added. No existing scene objects were removed.
- This is a stylized prototype expansion, not a fully realistic 1:1 recreation.


## Kerala Buildings Expansion
- Added an open-front teal-and-white roadside tea/snack shop with red floor, counter, stools and a signboard, based on the first supplied screenshot.
- Added a traditional red-roof Kerala community/home building with raised veranda, broad steps, wooden posts, benches and signboard, based on the second supplied screenshot.
- Both are placed in the Coastal Town area and can be visited from the Coastal Town map interaction menu.
- Existing coastal town, lighthouses, Wayanad world, district directory, graphics settings and all existing objects are retained. No NPCs or vehicles added.


## Chayakada Restaurant & Food Menu Update
- Added a tiled restaurant-style interior to the teal roadside shop, with service counter, food display, menu board, tables and benches.
- The Coastal Town “Visit the new roadside tea shop” interaction now opens a Kerala food menu with demo order buttons and rupee prices.
- Orders are simulated only; no real payment or backend transaction occurs.
- All existing buildings, coastal landmarks, Wayanad features, district directory and graphics settings are retained.


## Lil Kerala Launcher & Performance Update
- Added a startup launcher: “Welcome to Lil Kerala — Developed by ARSHAD” with a Play Now button.
- The game scene and all existing map objects/features are retained; the launcher is an entry screen, not a replacement map.
- Reduced default startup load: low graphics, 30 FPS target, 65% render scale, disabled real-time shadows, and capped initial pixel ratio.
- Rendering begins after Play Now is pressed to avoid wasting GPU resources on the launcher screen.
- Higher graphics/FPS/render scale can still be selected in the in-game Graphics & Performance settings. Actual FPS depends on the device.
