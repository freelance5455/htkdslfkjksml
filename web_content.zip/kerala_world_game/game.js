(() => {
  const root = document.getElementById('game');
  const scene = new THREE.Scene(); scene.background = new THREE.Color(0x75c9ef); scene.fog = new THREE.Fog(0x75c9ef, 42, 150);
  const camera = new THREE.PerspectiveCamera(60, innerWidth/innerHeight, .1, 180);
  const renderer = new THREE.WebGLRenderer({antialias:false, alpha:false, powerPreference:'high-performance'}); renderer.setPixelRatio(Math.min(devicePixelRatio||1,0.8)); renderer.setSize(innerWidth,innerHeight); renderer.shadowMap.enabled=false; renderer.shadowMap.type=THREE.PCFShadowMap; renderer.outputColorSpace=THREE.SRGBColorSpace; root.appendChild(renderer.domElement);
  scene.add(new THREE.HemisphereLight(0xd8f4ff,0x526b37,1.7));
  const sun=new THREE.DirectionalLight(0xfff1cf,2.4);sun.position.set(-24,42,18);sun.castShadow=false;
  sun.shadow.mapSize.set(512,512);sun.shadow.camera.left=-65;sun.shadow.camera.right=65;sun.shadow.camera.top=65;sun.shadow.camera.bottom=-65;sun.shadow.bias=-0.00025;scene.add(sun);
  const rand=(a,b)=>a+Math.random()*(b-a);
  const mat=(color,roughness=1)=>new THREE.MeshStandardMaterial({color,roughness});
  const grassMat=mat(0x3c9a45), pathMat=mat(0x343b40), trunkMat=mat(0x795033), leafMats=[mat(0x176b35),mat(0x267a3b),mat(0x398746),mat(0x1b5d32)];
  const ground=new THREE.Mesh(new THREE.PlaneGeometry(220,220),grassMat);ground.rotation.x=-Math.PI/2;ground.receiveShadow=true;scene.add(ground);
  // Winding village road with shoulders, asphalt surface and dashed centre line.
  const pathPoints=[];for(let i=0;i<18;i++){const z=-48+i*5;pathPoints.push(new THREE.Vector3(Math.sin(i*.42)*7,.035,z));}
  const pathCurve=new THREE.CatmullRomCurve3(pathPoints);
  function roadRibbon(curve,width,material,yOffset=0){
    const vertices=[],indices=[],segments=220;
    for(let i=0;i<=segments;i++){
      const t=i/segments,p=curve.getPointAt(t),tan=curve.getTangentAt(t).normalize();
      const side=new THREE.Vector3(-tan.z,0,tan.x).normalize();
      vertices.push(p.x+side.x*width/2,yOffset,p.z+side.z*width/2,p.x-side.x*width/2,yOffset,p.z-side.z*width/2);
      if(i<segments){const a=i*2,b=a+1,c=a+2,d=a+3;indices.push(a,c,b,b,c,d);}
    }
    const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));geo.setIndex(indices);geo.computeVertexNormals();
    const mesh=new THREE.Mesh(geo,material);mesh.receiveShadow=true;scene.add(mesh);return mesh;
  }
  roadRibbon(pathCurve,6.4,mat(0x9a9a87),.035);
  roadRibbon(pathCurve,5.7,pathMat,.055);
  const edgeMat=mat(0xf1e9d0),dashMat=mat(0xf5edce);
  for(let i=0;i<70;i++){
    const t=(i+.5)/70;if(i%2===1)continue;
    const p=pathCurve.getPointAt(t),tan=pathCurve.getTangentAt(t);
    const dash=new THREE.Mesh(new THREE.BoxGeometry(.12,.025,.72),dashMat);
    dash.position.set(p.x,.085,p.z);dash.rotation.y=Math.atan2(tan.x,tan.z);dash.castShadow=false;scene.add(dash);
  }
  for(const sideSign of [-1,1]){
    for(let i=0;i<44;i++){
      const t=i/43,p=pathCurve.getPointAt(t),tan=pathCurve.getTangentAt(t),side=new THREE.Vector3(-tan.z,0,tan.x).normalize();
      const line=new THREE.Mesh(new THREE.BoxGeometry(.07,.02,.85),edgeMat);
      line.position.set(p.x+side.x*2.72,.082,p.z+side.z*2.72);line.rotation.y=Math.atan2(tan.x,tan.z);line.castShadow=false;scene.add(line);
    }
  }
  // Calm blue river running across the valley under a small road bridge.
  const riverMat=new THREE.MeshStandardMaterial({color:0x168fce,roughness:.2,metalness:.12,transparent:true,opacity:.94});
  const river=new THREE.Mesh(new THREE.PlaneGeometry(210,11),riverMat);river.rotation.x=-Math.PI/2;river.position.set(0,.012,-8);scene.add(river);
  const bankMat=mat(0x7c9b55);
  for(const z of [-13.8,-2.2]){
    const bank=new THREE.Mesh(new THREE.BoxGeometry(210,.16,.75),bankMat);bank.position.set(0,.02,z);scene.add(bank);
  }
  // Bridge aligned to the road, with pale concrete sides and repeated rail posts.
  const bridgeT=8/17,bridgePoint=pathCurve.getPointAt(bridgeT),bridgeTan=pathCurve.getTangentAt(bridgeT);
  const bridgeAngle=Math.atan2(bridgeTan.x,bridgeTan.z);
  const bridge=new THREE.Group();bridge.position.set(bridgePoint.x,.17,-8);bridge.rotation.y=bridgeAngle;scene.add(bridge);
  const bridgeDeck=new THREE.Mesh(new THREE.BoxGeometry(6.35,.34,14.2),mat(0x41474b));bridgeDeck.position.y=.05;bridgeDeck.receiveShadow=true;bridge.add(bridgeDeck);
  const bridgeSideMat=mat(0xd7c5b0),bridgeRailMat=mat(0xb9a999);
  for(const sx of [-1,1]){
    const wall=new THREE.Mesh(new THREE.BoxGeometry(.3,.78,14.2),bridgeSideMat);wall.position.set(sx*3.08,.42,0);wall.castShadow=true;bridge.add(wall);
    const rail=new THREE.Mesh(new THREE.BoxGeometry(.13,.16,14.2),bridgeRailMat);rail.position.set(sx*3.08,.88,0);bridge.add(rail);
    for(let z=-6.2;z<=6.3;z+=1.8){const post=new THREE.Mesh(new THREE.BoxGeometry(.14,.65,.14),bridgeRailMat);post.position.set(sx*3.08,.75,z);bridge.add(post);}
  }
  for(let z=-5.5;z<=5.5;z+=2.4){const stripe=new THREE.Mesh(new THREE.BoxGeometry(.12,.025,1.05),dashMat);stripe.position.set(0,.235,z);bridge.add(stripe);}
  // Grass tufts add texture to open meadows without creating heavy geometry.
  const grassTuftMat=[mat(0x66a84b),mat(0x2f823d),mat(0x91b85b)];
  // Same grass detail, batched into instanced meshes to reduce mobile GPU draw calls.
  const grassBladeGeo=new THREE.ConeGeometry(.045,.32,4);
  const grassInstances=grassTuftMat.map(material=>new THREE.InstancedMesh(grassBladeGeo,material,960));
  const grassCounts=[0,0,0],grassDummy=new THREE.Object3D();
  for(let i=0;i<320;i++){
    const x=rand(-54,54),z=rand(-60,38);
    if(Math.abs(x-Math.sin((z+48)/5*.42)*7)<4.5 || (Math.abs(z+8)<7 && Math.abs(x)<70))continue;
    for(let k=0;k<3;k++){
      const mi=(i+k)%3;grassDummy.position.set(x+(k-1)*.08,.18,z);
      grassDummy.rotation.set(0,0,(k-1)*.24);grassDummy.scale.set(1,1,1);grassDummy.updateMatrix();
      grassInstances[mi].setMatrixAt(grassCounts[mi]++,grassDummy.matrix);
    }
  }
  grassInstances.forEach((mesh,i)=>{mesh.count=grassCounts[i];mesh.instanceMatrix.needsUpdate=true;mesh.castShadow=false;mesh.receiveShadow=false;scene.add(mesh);});
  // low-poly tropical forest
  function makeTree(x,z,scale=1,palm=false){
    const g=new THREE.Group();
    const trunkHeight=(palm?3.8:2.8)*scale;
    const trunk=new THREE.Mesh(new THREE.CylinderGeometry(.12*scale,.31*scale,trunkHeight,9,3),trunkMat);
    trunk.position.y=trunkHeight/2;trunk.castShadow=true;trunk.receiveShadow=true;g.add(trunk);
    if(palm){
      // More natural coconut-palm crown with long, tapered fronds.
      const crownY=trunkHeight+.08*scale;
      const crownCore=new THREE.Mesh(new THREE.SphereGeometry(.22*scale,9,7),leafMats[1]);
      crownCore.position.y=crownY;g.add(crownCore);
      for(let i=0;i<10;i++){
        const a=i*Math.PI*2/10+rand(-.12,.12);
        const length=rand(2.2,3.1)*scale;
        const frond=new THREE.Group();
        frond.position.set(0,crownY,0);frond.rotation.y=a;frond.rotation.z=rand(.45,.82);
        const stem=new THREE.Mesh(new THREE.CylinderGeometry(.025*scale,.065*scale,length,6),mat(0x8c9b4b));
        stem.rotation.z=-Math.PI/2;stem.position.set(length*.42,0,0);frond.add(stem);
        for(let j=1;j<=9;j++){
          const t=j/10, px=length*t*.82, drop=(t*t)*.8*scale;
          for(const side of [-1,1]){
            const leaflet=new THREE.Mesh(new THREE.ConeGeometry(.09*scale,.7*scale,4),leafMats[(i+j)%leafMats.length]);
            leaflet.position.set(px,-drop,side*.22*scale);
            leaflet.rotation.z=-side*.48;leaflet.rotation.x=side*.45;
            leaflet.castShadow=true;frond.add(leaflet);
          }
        }
        frond.traverse(o=>{if(o.isMesh){o.castShadow=false;o.receiveShadow=false;}});
        g.add(frond);
      }
    }else{
      // Natural broadleaf canopy: irregular overlapping leaf clusters, branches and varied greens.
      for(let b=0;b<5;b++){
        const angle=b*Math.PI*2/5+rand(-.18,.18);
        const branch=new THREE.Mesh(new THREE.CylinderGeometry(.035*scale,.095*scale,1.15*scale,6),trunkMat);
        branch.position.set(Math.cos(angle)*.48*scale,2.15*scale,Math.sin(angle)*.48*scale);
        branch.rotation.z=Math.cos(angle)*-.62;branch.rotation.x=Math.sin(angle)*.62;
        branch.castShadow=true;g.add(branch);
      }
      const greens=[0x2e6f3b,0x3e8746,0x4f984d,0x28623a,0x68a954];
      for(let i=0;i<12;i++){
        const radius=rand(.52,1.0)*scale;
        const crown=new THREE.Mesh(new THREE.SphereGeometry(radius,10,8),mat(greens[Math.floor(Math.random()*greens.length)],0,.92));
        const angle=rand(0,Math.PI*2), ring=rand(0,.92)*scale;
        crown.position.set(Math.cos(angle)*ring,(2.65+rand(-.5,.9))*scale,Math.sin(angle)*ring);
        crown.scale.set(rand(.82,1.25),rand(.72,1.12),rand(.82,1.25));
        crown.castShadow=false;crown.receiveShadow=false;g.add(crown);
      }
    }
    g.position.set(x,0,z);scene.add(g);return g;
  }
  for(let i=0;i<92;i++){let x=rand(-48,48),z=rand(-62,35);if(Math.abs(x-Math.sin((z+48)/5*.42)*7)<3.7)continue;makeTree(x,z,rand(.7,1.5),Math.random()<.42)}
  const rockMats=[mat(0x898f78),mat(0x9b9d88),mat(0x747d6b)];for(let i=0;i<14;i++){const rock=new THREE.Mesh(new THREE.DodecahedronGeometry(rand(.25,.7),0),rockMats[i%3]);rock.position.set(rand(-35,35),.25,rand(-42,25));rock.scale.y=.65;rock.rotation.set(rand(0,1),rand(0,3),rand(0,1));rock.castShadow=true;scene.add(rock)}
  // Small pond landmark (the only map addition in this update)
  const pondGroup = new THREE.Group(); pondGroup.position.set(28, 0, 12); scene.add(pondGroup);
  const pondBank = new THREE.Mesh(new THREE.CylinderGeometry(4.4, 4.4, .18, 16), mat(0x9a9c70));
  pondBank.position.y = .02; pondGroup.add(pondBank);
  const pondWater = new THREE.Mesh(new THREE.CircleGeometry(3.95, 16), new THREE.MeshStandardMaterial({color:0x42b9d4, roughness:.3, metalness:.05}));
  pondWater.rotation.x = -Math.PI / 2; pondWater.position.y = .12; pondGroup.add(pondWater);
  for (let i = 0; i < 5; i++) {
    const lily = new THREE.Mesh(new THREE.CircleGeometry(.28, 8), mat(0x3b9e51));
    lily.rotation.x = -Math.PI / 2; lily.position.set(Math.cos(i * 1.2) * (1 + (i % 2)), .14, Math.sin(i * 1.2) * (1 + (i % 2))); pondGroup.add(lily);
  }

  // Kerala social landmarks: festival stage, chaya kada, and market.
  const woodMat=mat(0x86512c), roofMat=mat(0xb83b2d), creamMat=mat(0xf3dfb3), tealMat=mat(0x176b59), stallMat=mat(0xe8b84a), stageTopMat=mat(0x7b4a31), darkPropMat=mat(0x282d30), fruitMats=[mat(0xf05b43),mat(0x70c84b),mat(0xe8b84a)];
  function box(parent,w,h,d,material,x,y,z){const mesh=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),material);mesh.position.set(x,y,z);parent.add(mesh);return mesh;}
  function labelSprite(text,color='#fff4ce',bg='#174f3c'){
    const c=document.createElement('canvas');c.width=512;c.height=128;const ctx=c.getContext('2d');ctx.fillStyle=bg;ctx.fillRect(0,0,512,128);ctx.strokeStyle='#ffffff88';ctx.lineWidth=6;ctx.strokeRect(5,5,502,118);ctx.fillStyle=color;ctx.font='bold 42px system-ui';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(text,256,64);const tex=new THREE.CanvasTexture(c);tex.colorSpace=THREE.SRGBColorSpace;const sprite=new THREE.Sprite(new THREE.SpriteMaterial({map:tex,transparent:false}));sprite.scale.set(6.2,1.55,1);return sprite;
  }
  // Stage on the left side of the main trail
  const stage=new THREE.Group();stage.position.set(-13,0,-16);scene.add(stage);
  box(stage,8,.45,4,stageTopMat,0,.25,0);box(stage,8,.25,4,woodMat,0,-.1,0);
  for(const x of [-3.5,3.5]){box(stage,.22,3,.22,woodMat,x,1.7,-1.45);box(stage,.22,3,.22,woodMat,x,1.7,1.45)}
  box(stage,8,.28,4.2,roofMat,0,3.15,0);box(stage,7.2,.12,.18,stallMat,0,2.55,1.95);
  const stageSign=labelSprite('WAYANAD UTSAVAM');stageSign.position.set(0,2.5,2.05);stage.add(stageSign);
  // Microphone stand and speakers
  const micPole=new THREE.Mesh(new THREE.CylinderGeometry(.035,.05,1.2,6),darkPropMat);micPole.position.set(0,1,1.05);stage.add(micPole);const micHead=new THREE.Mesh(new THREE.SphereGeometry(.1,8,6),darkPropMat);micHead.position.set(0,1.62,1.05);stage.add(micHead);
  for(const x of [-2.9,2.9]){const speaker=box(stage,.65,1,.45,darkPropMat,x,.9,1.15);}
  // Festival bunting and decorative stage lights
  for(let i=0;i<7;i++){
    const bulb=new THREE.Mesh(new THREE.SphereGeometry(.12,8,6),mat([0xffcf5b,0x68e0d1,0xff7b7b][i%3],.4));
    bulb.position.set(-2.8+i*.93,2.75,1.8);stage.add(bulb);
  }

  // Reference-inspired festival grounds: circular plaza, paths, benches and palms.
  // These are additions only; the original stage and other landmarks stay intact.
  const plazaGroup=new THREE.Group();plazaGroup.position.set(-13,.045,-16);scene.add(plazaGroup);
  const plazaBase=new THREE.Mesh(new THREE.CylinderGeometry(13.2,13.2,.12,48),mat(0xe9b4b5));
  plazaBase.position.y=.01;plazaBase.receiveShadow=true;plazaGroup.add(plazaBase);
  const innerRing=new THREE.Mesh(new THREE.CylinderGeometry(8.9,8.9,.035,48),mat(0xf4d5b8));
  innerRing.position.y=.09;plazaGroup.add(innerRing);
  // Short tiled approach from the village path to the stage.
  const approach=new THREE.Mesh(new THREE.BoxGeometry(4.5,.08,8.5),mat(0xd8c5a3));
  approach.position.set(0,.12,6.1);plazaGroup.add(approach);
  for(let i=0;i<5;i++){
    const seam=new THREE.Mesh(new THREE.BoxGeometry(4.45,.012,.035),mat(0xb7a184));
    seam.position.set(0,.17,2.8+i*1.45);plazaGroup.add(seam);
  }
  // Public benches around the plaza.
  for(const a of [-2.35,-.8,.8,2.35]){
    const x=Math.sin(a)*10.6,z=Math.cos(a)*10.6;
    const bench=new THREE.Group();bench.position.set(x,.12,z);bench.rotation.y=a;
    box(bench,2,.14,.48,woodMat,0,.45,0);
    box(bench,2,.5,.12,woodMat,0,.7,-.2);
    for(const lx of [-.78,.78])box(bench,.12,.42,.12,darkPropMat,lx,.22,0);
    plazaGroup.add(bench);
  }
  // Warm low-poly lamp posts around the festival ground.
  for(const a of [0,Math.PI/2,Math.PI,Math.PI*1.5]){
    const x=Math.sin(a)*12.1,z=Math.cos(a)*12.1;
    const post=new THREE.Mesh(new THREE.CylinderGeometry(.07,.11,2.6,7),woodMat);
    post.position.set(x,1.38,z);plazaGroup.add(post);
    const lamp=new THREE.Mesh(new THREE.SphereGeometry(.25,8,6),mat(0xffe4a0,.1));
    lamp.position.set(x,2.78,z);plazaGroup.add(lamp);
  }
  // A few extra coconut palms frame the stage like a tropical village festival.
  for(const p of [[-28,-28,1.25],[2,-28,1.15],[-30,-7,1.05],[4,-8,1.1],[-24,1,.95],[-2,2,1.0]]){
    makeTree(p[0],p[1],p[2],true);
  }
  // Waterside promenade and simple wooden rail along the existing river.
  const promenadeMat=mat(0xd4bd96),railMat=mat(0x775239);
  const promenade=new THREE.Mesh(new THREE.BoxGeometry(13,.12,2.8),promenadeMat);
  promenade.position.set(13,.08,-8);scene.add(promenade);
  for(const side of [-1,1]){
    const rail=new THREE.Mesh(new THREE.BoxGeometry(13,.12,.12),railMat);
    rail.position.set(13,.62,-8+side*1.25);scene.add(rail);
    for(let i=0;i<8;i++){
      const post=new THREE.Mesh(new THREE.BoxGeometry(.12,.72,.12),railMat);
      post.position.set(7+i*1.7,.38,-8+side*1.25);scene.add(post);
    }
  }
  // Small colourful roadside information boards, matching a social open-world map.
  for(const p of [[-3,-29,'WAYANAD'],[3,-31,'FESTIVAL']]){
    const sign=new THREE.Group();sign.position.set(p[0],0,p[1]);
    const board=box(sign,1.8,.72,.12,mat(0x176b59),0,1.75,0);
    const text=labelSprite(p[2],'#fff4ce','#176b59');text.scale.set(1.7,.42,1);text.position.set(0,1.75,.08);sign.add(text);
    for(const x of [-.65,.65])box(sign,.09,1.3,.09,woodMat,x,.65,0);
    scene.add(sign);
  }


  // Coastal-town expansion inspired by the user's reference image.
  // Built as a separate explorable area; existing landmarks are untouched.
  const coastTown=new THREE.Group();coastTown.position.set(76,0,-18);scene.add(coastTown);
  const coastGrass=mat(0x63ad55),sandMat=mat(0xe6c99a),seaMat=new THREE.MeshStandardMaterial({color:0x168fc4,roughness:.28,metalness:.08});
  const coastLand=new THREE.Mesh(new THREE.CircleGeometry(48,48),coastGrass);coastLand.rotation.x=-Math.PI/2;coastLand.position.y=-.06;coastTown.add(coastLand);
  const sea=new THREE.Mesh(new THREE.PlaneGeometry(95,38),seaMat);sea.rotation.x=-Math.PI/2;sea.position.set(0,.015,-39);coastTown.add(sea);
  const beach=new THREE.Mesh(new THREE.PlaneGeometry(78,12),sandMat);beach.rotation.x=-Math.PI/2;beach.position.set(0,.025,-17);coastTown.add(beach);
  // Broad pale-pink seaside plaza.
  const coastPlaza=new THREE.Mesh(new THREE.CylinderGeometry(17,17,.18,48),mat(0xe9b7b4));coastPlaza.position.set(-13,.08,5);coastTown.add(coastPlaza);
  // Main coastal road and connecting branch.
  const coastRoadMat=mat(0x444b50),coastRoad=new THREE.Mesh(new THREE.BoxGeometry(9,.12,72),coastRoadMat);
  coastRoad.position.set(23,.04,0);coastTown.add(coastRoad);
  const branchRoad=new THREE.Mesh(new THREE.BoxGeometry(54,.12,7),coastRoadMat);branchRoad.position.set(0,.04,19);coastTown.add(branchRoad);
  const roadLineMat=mat(0xf5edce);
  for(let z=-33;z<34;z+=5){const d=new THREE.Mesh(new THREE.BoxGeometry(.14,.025,2.2),roadLineMat);d.position.set(23,.12,z);coastTown.add(d);}
  for(let x=-24;x<25;x+=5){const d=new THREE.Mesh(new THREE.BoxGeometry(2.2,.025,.14),roadLineMat);d.position.set(x,.12,19);coastTown.add(d);}
  // Two striped lighthouse landmarks with red roofs and viewing decks.
  function makeLighthouse(x,z,height,striped){
    const tower=new THREE.Group();tower.position.set(x,0,z);coastTown.add(tower);
    const base=new THREE.Mesh(new THREE.CylinderGeometry(2.05,2.5,height,12),mat(0xf1d5bd));base.position.y=height/2;base.castShadow=true;tower.add(base);
    if(striped){
      for(let y=height*.27;y<height*.9;y+=height*.32){const band=new THREE.Mesh(new THREE.CylinderGeometry(2.02-(y/height)*.38,2.05-(y/height)*.38,.72,12),mat(0xc84c43));band.position.y=y;tower.add(band);}
    }else{
      const band=new THREE.Mesh(new THREE.CylinderGeometry(2.08,2.2,.7,12),mat(0xc84c43));band.position.y=height*.23;tower.add(band);
    }
    const deck=new THREE.Mesh(new THREE.CylinderGeometry(2.8,2.8,.3,12),woodMat);deck.position.y=height*.91;tower.add(deck);
    const room=new THREE.Mesh(new THREE.CylinderGeometry(1.65,1.85,1.8,10),mat(0xf6e7cb));room.position.y=height+0.8;tower.add(room);
    const roof=new THREE.Mesh(new THREE.ConeGeometry(2.3,1.25,4),mat(0xc94343));roof.position.y=height+2.3;roof.rotation.y=Math.PI/4;tower.add(roof);
    const glow=new THREE.Mesh(new THREE.SphereGeometry(.38,8,6),mat(0xffefb0,.2));glow.position.y=height+1;tower.add(glow);
    return tower;
  }
  makeLighthouse(-34,2,17,false);makeLighthouse(-25,1,11,true);
  // Red-roof coastal pavilion and small pastel shop fronts.
  const seaPavilion=new THREE.Group();seaPavilion.position.set(-5,0,6);coastTown.add(seaPavilion);
  box(seaPavilion,9,.35,6,woodMat,0,2.6,0);
  for(const x of [-3.7,3.7])for(const z of [-2.3,2.3])box(seaPavilion,.25,2.5,.25,woodMat,x,1.25,z);
  const pavilionRoof=new THREE.Mesh(new THREE.ConeGeometry(6.3,2.2,4),mat(0xc94343));pavilionRoof.position.y=4.0;pavilionRoof.rotation.y=Math.PI/4;seaPavilion.add(pavilionRoof);
  for(let i=0;i<3;i++){
    const shop=new THREE.Group();shop.position.set(32+i*9,0,(-12+i*12));coastTown.add(shop);
    box(shop,7,3.2,6,mat([0xf0d7b5,0xe4c6ae,0xd8dfc2][i]),0,1.6,0);
    box(shop,7.5,.25,6.5,mat(0x8e5544),0,3.25,0);
    box(shop,7.7,.22,1.0,mat([0xb74e45,0x4f778c,0x71905d][i]),0,2.8,3.0);
    const sign=labelSprite(["COAST CAFE","SEA VIEW SHOP","KERALA CRAFTS"][i]);sign.scale.set(3.8,.8,1);sign.position.set(0,2.2,3.12);shop.add(sign);
  }
  // Promenade benches, lamps, signboards and palms.
  for(const x of [-8,2,12]){
    const bench=new THREE.Group();bench.position.set(x,.12,-8);coastTown.add(bench);
    box(bench,2,.16,.55,woodMat,0,.48,0);box(bench,2,.55,.12,woodMat,0,.76,-.2);
    for(const lx of [-.78,.78])box(bench,.12,.4,.12,darkPropMat,lx,.22,0);
  }
  for(const x of [-20,-8,5,17,31]){
    const pole=new THREE.Mesh(new THREE.CylinderGeometry(.07,.1,3,7),woodMat);pole.position.set(x,1.5,-11);coastTown.add(pole);
    const bulb=new THREE.Mesh(new THREE.SphereGeometry(.22,8,6),mat(0xffe6a5));bulb.position.set(x,3.1,-11);coastTown.add(bulb);
  }
  for(const p of [[-43,-17,1.1],[-40,24,1.15],[-20,-27,1.0],[5,-29,1.1],[39,24,1.05],[44,-22,1.0],[5,34,1.0]]){
    makeTree(p[0]+76,p[1]-18,p[2],true);
  }
  const coastBoard=labelSprite('KERALA COAST');coastBoard.scale.set(5,1,1);coastBoard.position.set(76,3,8);scene.add(coastBoard);


  // Two new Kerala-style buildings based on the user's screenshots.
  // 1) Open-front roadside shop: teal-and-white walls, red floor and signboard.
  const roadsideShop=new THREE.Group();roadsideShop.position.set(-41,0,-22);coastTown.add(roadsideShop);
  const shopFloor=new THREE.Mesh(new THREE.BoxGeometry(12,.22,9),mat(0xb84b45));shopFloor.position.set(0,.14,0);roadsideShop.add(shopFloor);
  // Side and rear walls leave a wide opening facing the promenade.
  box(roadsideShop, .35,3.1,9,mat(0xf0e7d8),-5.8,1.7,0);
  box(roadsideShop, .35,3.1,9,mat(0xf0e7d8),5.8,1.7,0);
  box(roadsideShop, 12,3.1,.35,mat(0xf0e7d8),0,1.7,-4.3);
  box(roadsideShop,12,.85,.38,mat(0x247b78),0,.52,4.25);
  box(roadsideShop,12,.22,.42,mat(0xe9e4d8),0,1.08,4.25);
  box(roadsideShop,12,.22,9,mat(0x247b78),0,3.25,0);
  // Red tiled roof with a shallow front canopy.
  const shopRoof=new THREE.Mesh(new THREE.BoxGeometry(13,.3,10),mat(0xb83e3c));shopRoof.position.set(0,3.55,0);roadsideShop.add(shopRoof);
  for(const x of [-5.2,5.2])for(const z of [-3.7,3.7])box(roadsideShop,.22,3.4,.22,woodMat,x,1.7,z);
  // Counter, stools and shop sign.
  box(roadsideShop,5,.95,.9,woodMat,0,.75,-1.3);
  for(const x of [-3.4,-1.8,1.8,3.4])box(roadsideShop,.65,.55,.65,woodMat,x,.45,1.1);
  const shopBoard=labelSprite('KERALA TEA & SNACKS');shopBoard.scale.set(5.2,.9,1);shopBoard.position.set(0,2.55,4.55);roadsideShop.add(shopBoard);

  // Restaurant-style Chayakada interior inspired by the supplied food-menu screenshot.
  // Orange floor tiles, service counter, food display, menu board and dining tables.
  const shopTileMat=mat(0xd96b35);
  for(let x=-4.8;x<=4.8;x+=1.6)for(let z=-3.2;z<=3.2;z+=1.6){
    const tile=new THREE.Mesh(new THREE.BoxGeometry(1.52,.025,1.52),shopTileMat);
    tile.position.set(x,.27,z);roadsideShop.add(tile);
  }
  box(roadsideShop,10,.12,.9,mat(0x543328),0,1.25,-3.55);
  box(roadsideShop,10,.12,.12,mat(0x7b4b34),0,1.55,-3.55);
  // Food display and back shelves.
  box(roadsideShop,2.4,1.1,1.2,mat(0x244b59),-3.4,1.0,-2.2);
  for(let i=0;i<5;i++){
    const plate=new THREE.Mesh(new THREE.CylinderGeometry(.28,.28,.07,12),mat(0xe9dfc9));
    plate.position.set(-4.2+i*1.05,1.62,-3.2);roadsideShop.add(plate);
    const food=new THREE.Mesh(new THREE.SphereGeometry(.2,8,6),mat([0xc77b32,0xd6a14b,0x9b4a2c][i%3]));
    food.position.set(-4.2+i*1.05,1.8,-3.2);roadsideShop.add(food);
  }
  for(const x of [-3.5,-1.2,1.2,3.5]){
    box(roadsideShop,.22,1.2,.22,woodMat,x,.9,-3.95);
  }
  // Two dining tables with paired benches.
  for(const z of [-.7,2.3]){
    box(roadsideShop,2.1,.16,1.25,mat(0xb9874c),-1.9,.9,z);
    for(const x of [-3.15,-.65]){
      box(roadsideShop,.16,.55,1.35,woodMat,x,.52,z);
    }
    for(const x of [-2.8,-1.0])box(roadsideShop,.12,.75,.12,woodMat,x,.4,z);
  }
  const menuBoard=labelSprite('CHAYA • POROTTA • MEALS');menuBoard.scale.set(5.5,.85,1);menuBoard.position.set(0,2.75,-4.05);roadsideShop.add(menuBoard);

  // 2) Traditional red-roof Kerala community/home building with a raised veranda.
  const redRoofHome=new THREE.Group();redRoofHome.position.set(-4,0,28);coastTown.add(redRoofHome);
  box(redRoofHome,13,2.9,8,mat(0xe8d6bf),0,1.55,-1.1);
  box(redRoofHome,14,.22,9,woodMat,0,3.05,-1.1);
  const homeRoof=new THREE.Mesh(new THREE.ConeGeometry(10,3.1,4),mat(0xc9423e));homeRoof.rotation.y=Math.PI/4;homeRoof.position.set(0,4.55,-1.1);homeRoof.scale.set(1,.65,.78);redRoofHome.add(homeRoof);
  // Raised veranda and broad entrance steps.
  box(redRoofHome,13,.42,4,mat(0x9c6344),0,.55,5.0);
  for(let i=0;i<3;i++)box(redRoofHome,8-i*1.1,.22,1.0,mat(0xb87950),0,.18+i*.18,8.0+i*.85);
  for(const x of [-5.6,-2.8,0,2.8,5.6])box(redRoofHome,.2,2.7,.2,woodMat,x,1.65,3.4);
  // Long veranda benches and a front signboard.
  for(const x of [-3.8,0,3.8]){
    box(redRoofHome,2.8,.18,.65,woodMat,x,.95,4.5);
    box(redRoofHome,2.8,.55,.14,woodMat,x,1.25,4.78);
  }
  const homeBoard=labelSprite('KERALA COMMUNITY HOUSE');homeBoard.scale.set(5.5,.85,1);homeBoard.position.set(0,2.65,3.65);redRoofHome.add(homeBoard);

  // Tea shop, with counter, roof and stools
  const tea=new THREE.Group();tea.position.set(13,0,-25);scene.add(tea);
  box(tea,6,2.6,3,creamMat,0,1.3,0);box(tea,6.5,.25,3.5,roofMat,0,2.75,0);box(tea,6.2,.18,.22,woodMat,0,2.55,1.7);
  const teaSign=labelSprite('CHAYA KADA');teaSign.scale.set(4.5,1.1,1);teaSign.position.set(0,2.2,1.62);tea.add(teaSign);
  box(tea,5.2,.9,.55,woodMat,0,.75,1.75);for(const x of [-1.8,0,1.8]){const stool=new THREE.Mesh(new THREE.CylinderGeometry(.28,.28,.12,8),stallMat);stool.position.set(x,.35,2.55);tea.add(stool);const leg=new THREE.Mesh(new THREE.CylinderGeometry(.05,.05,.35,6),woodMat);leg.position.set(x,.17,2.55);tea.add(leg)}
  // Chaya kada seating benches
  for(const x of [-2.2,2.2]){
    box(tea,1.5,.16,.42,woodMat,x,.42,3.15);
    for(const dx of [-.55,.55]) box(tea,.12,.42,.12,woodMat,x+dx,.21,3.15);
  }
  // Market lane with colourful produce stalls and crates
  const market=new THREE.Group();market.position.set(-13,0,-37);scene.add(market);
  for(let i=0;i<3;i++){const x=(i-1)*4;box(market,3.3,1.8,2.5,creamMat,x,.9,0);box(market,3.7,.22,2.9,[roofMat,tealMat,stallMat][i],x,2,0);box(market,3.1,.7,.35,woodMat,x,.55,1.3);
    for(let j=0;j<4;j++){const fruit=new THREE.Mesh(new THREE.SphereGeometry(.16,7,5),fruitMats[j%3]);fruit.position.set(x-1.05+j*.7,1.08,1.35);market.add(fruit)}
  }
  // Extra produce corner and vendors for the combined market update
  for(let i=0;i<2;i++){
    const x=(i===0?-8:8);
    box(market,2.8,1.5,2.3,creamMat,x,.75,-4);
    box(market,3.1,.2,2.6,[tealMat,roofMat][i],x,1.65,-4);
    box(market,2.6,.55,.3,woodMat,x,.45,-2.8);
    for(let j=0;j<5;j++){
      const produce=new THREE.Mesh(new THREE.SphereGeometry(.18,7,5),fruitMats[(i+j)%3]);
      produce.position.set(x-1+j*.5,.91,-2.75);market.add(produce);
    }
  }
  const marketSign=labelSprite('WAYANAD MARKET');marketSign.scale.set(6.3,1.3,1);marketSign.position.set(0,3,0);market.add(marketSign);

  // Traditional Kerala house exterior and explorable interior room.
  const house = new THREE.Group(); house.position.set(25,0,-13); scene.add(house);
  box(house,6,2.8,5,creamMat,0,1.4,0);
  box(house,6.8,.28,5.8,woodMat,0,2.85,0);
  const houseRoof = new THREE.Mesh(new THREE.ConeGeometry(4.5,1.8,4), roofMat);
  houseRoof.rotation.y=Math.PI/4; houseRoof.position.set(0,3.8,0); houseRoof.scale.set(1,1,.82); house.add(houseRoof);
  box(house,1.1,2,.12,woodMat,0,1,2.56);
  for(const x of [-1.8,1.8]) box(house,.9,.9,.12,tealMat,x,1.5,2.56);
  const houseSign=labelSprite('NAALUKETTU HOME'); houseSign.scale.set(4.8,1,1); houseSign.position.set(0,2.25,2.62); house.add(houseSign);
  // Interior is placed in a separate nearby room; hidden until the player enters.
  const interior = new THREE.Group(); interior.position.set(37,0,-13); scene.add(interior); interior.visible=false;
  box(interior,8,.2,8,woodMat,0,.1,0);
  box(interior,8,2.8,.18,creamMat,0,1.5,-4);
  box(interior,8,2.8,.18,creamMat,0,1.5,4);
  box(interior,.18,2.8,8,creamMat,-4,1.5,0);
  box(interior,.18,2.8,8,creamMat,4,1.5,0);
  // open doorway on the front wall, two wall segments instead of a closed front
  interior.children = interior.children.filter(()=>true);
  box(interior,1.6,.5,1.6,woodMat,-1.8,.45,-1.5);
  box(interior,1.2,.55,1.2,stallMat,-1.8,.98,-1.5);
  box(interior,1.5,.18,1.5,woodMat,1.6,.6,1.4);
  for(const x of [-2.6,2.6]) box(interior,.12,.9,.12,woodMat,x,.5,1.4);
  box(interior,1.8,.12,.8,tealMat,1.4,1.45,-2.6);
  const homeLabel=labelSprite('KERALA HOME'); homeLabel.scale.set(3.2,.8,1); homeLabel.position.set(0,2.45,-3.7); interior.add(homeLabel);
  let insideHouse=false;
  const rainDropsCount=320;
  const rainPositions=new Float32Array(rainDropsCount*3);
  for(let i=0;i<rainDropsCount;i++){rainPositions[i*3]=rand(-42,42);rainPositions[i*3+1]=rand(2,26);rainPositions[i*3+2]=rand(-48,38);}
  const rainGeometry=new THREE.BufferGeometry(); rainGeometry.setAttribute('position',new THREE.BufferAttribute(rainPositions,3));
  const rainMaterial=new THREE.PointsMaterial({color:0xcdefff,size:.09,transparent:true,opacity:.78});
  const rain=new THREE.Points(rainGeometry,rainMaterial);scene.add(rain);rain.visible=false;let rainyWeather=false;


  // cute cartoon player built from simple meshes
  const player=new THREE.Group();scene.add(player);player.position.set(0,0,4);
  const skin=mat(0xf3c59a), hair=mat(0x35251d), pink=mat(0xe91e78), white=mat(0xf6f4ed), black=mat(0x30251f), eyeWhite=new THREE.MeshStandardMaterial({color:0xffffff,roughness:.4}), iris=mat(0x542c1c);
  function ball(parent,geo,material,pos,scale){const m=new THREE.Mesh(geo,material);m.position.set(...pos);if(scale)m.scale.set(...scale);m.castShadow=true;parent.add(m);return m;}
  // legs and shoes
  const legL=ball(player,new THREE.CapsuleGeometry(.12,.38,3,6),white,[-.16,.42,0]);const legR=ball(player,new THREE.CapsuleGeometry(.12,.38,3,6),white,[.16,.42,0]);
  ball(player,new THREE.SphereGeometry(.16,8,6),white,[-.16,.16,.08],[1.15,.55,1.5]);ball(player,new THREE.SphereGeometry(.16,8,6),white,[.16,.16,.08],[1.15,.55,1.5]);
  ball(player,new THREE.CapsuleGeometry(.3,.43,4,8),pink,[0,1.05,0],[1,1, .72]);
  const armL=ball(player,new THREE.CapsuleGeometry(.085,.34,3,6),pink,[-.34,.95,0]);const armR=ball(player,new THREE.CapsuleGeometry(.085,.34,3,6),pink,[.34,.95,0]);
  const handL=ball(player,new THREE.SphereGeometry(.11,8,6),skin,[-.35,.72,.015]);const handR=ball(player,new THREE.SphereGeometry(.11,8,6),skin,[.35,.72,.015]);
  ball(player,new THREE.SphereGeometry(.39,12,10),skin,[0,1.85,0],[.95,1.05,.88]);ball(player,new THREE.SphereGeometry(.4,10,8),hair,[0,2.06,-.04],[1.02,.72,.92]);
  // hair fringe and braids
  ball(player,new THREE.SphereGeometry(.23,8,6),hair,[-.33,1.83,.1],[.45,.65,.55]);ball(player,new THREE.SphereGeometry(.23,8,6),hair,[.33,1.83,.1],[.45,.65,.55]);
  for(const x of [-.15,.15]){ball(player,new THREE.SphereGeometry(.105,10,8),eyeWhite,[x,1.88,.333],[1,1.15,.5]);ball(player,new THREE.SphereGeometry(.062,8,6),iris,[x,1.87,.382]);ball(player,new THREE.SphereGeometry(.023,6,4),eyeWhite,[x-.015,1.9,.405]);}
  ball(player,new THREE.SphereGeometry(.05,8,6),mat(0xd96b64),[0,1.68,.365],[1,.6,.5]);
  // Camera follow
  let cameraYaw=0, isNight=false, dancing=false, photoMode=false, moveX=0,moveY=0,velY=0,grounded=true;const keys={};
  function updateCamera(){const offset=new THREE.Vector3(Math.sin(cameraYaw)*7,4.6,Math.cos(cameraYaw)*7);camera.position.copy(player.position).add(offset);camera.lookAt(player.position.x,player.position.y+1.2,player.position.z);}
  updateCamera();
  // Drag on open world to rotate the third-person camera (does not replace v0.2 controls).
  let cameraDrag = false, cameraPointerId = null, cameraLastX = 0, cameraDragDistance = 0;
  const gameCanvas = renderer.domElement;
  gameCanvas.addEventListener('pointerdown', e => {
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    cameraDrag = true; cameraPointerId = e.pointerId; cameraLastX = e.clientX; cameraDragDistance = 0;
    try { gameCanvas.setPointerCapture(e.pointerId); } catch (_) {}
  });
  gameCanvas.addEventListener('pointermove', e => {
    if (!cameraDrag || e.pointerId !== cameraPointerId) return;
    const dx = e.clientX - cameraLastX;
    cameraLastX = e.clientX; cameraDragDistance += Math.abs(dx);
    cameraYaw -= dx * 0.008;
  });
  function endCameraDrag(e) {
    if (cameraPointerId !== null && e.pointerId !== cameraPointerId) return;
    cameraDrag = false; cameraPointerId = null;
  }
  gameCanvas.addEventListener('pointerup', endCameraDrag);
  gameCanvas.addEventListener('pointercancel', endCameraDrag);

  // controls: touch joystick and keyboard
  const joy=document.getElementById('joystick'),knob=document.querySelector('.joy-knob');let joyActive=false,joyId=null;
  function joyMove(e){const r=joy.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2;let dx=e.clientX-cx,dy=e.clientY-cy;const max=43,len=Math.hypot(dx,dy);if(len>max){dx=dx/len*max;dy=dy/len*max}knob.style.transform=`translate(${dx}px,${dy}px)`;moveX=dx/max;moveY=dy/max;}
  joy.addEventListener('pointerdown',e=>{joyActive=true;joyId=e.pointerId;joy.setPointerCapture(e.pointerId);joyMove(e)});joy.addEventListener('pointermove',e=>{if(joyActive&&e.pointerId===joyId)joyMove(e)});function joyEnd(){joyActive=false;joyId=null;moveX=moveY=0;knob.style.transform='translate(0,0)'}joy.addEventListener('pointerup',joyEnd);joy.addEventListener('pointercancel',joyEnd);
  addEventListener('keydown',e=>{keys[e.key.toLowerCase()]=true;if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight',' '].includes(e.key))e.preventDefault()});addEventListener('keyup',e=>keys[e.key.toLowerCase()]=false);
  document.getElementById('jumpBtn').addEventListener('pointerdown',()=>{if(grounded){velY=5.4;grounded=false}});
  let gameStarted=false;let last=performance.now(),lastRender=0;function animate(now){requestAnimationFrame(animate);if(!gameStarted)return;const dt=Math.min((now-last)/1000,.04);last=now;
    let mx=moveX+(keys.a?-1:0)+(keys.d?1:0), my=moveY+(keys.w?-1:0)+(keys.s?1:0);if(keys.arrowleft)mx=-1;if(keys.arrowright)mx=1;if(keys.arrowup)my=-1;if(keys.arrowdown)my=1;
    const len=Math.hypot(mx,my);if(len>1){mx/=len;my/=len}const speed=5.2;const forward=new THREE.Vector3(-Math.sin(cameraYaw),0,-Math.cos(cameraYaw));const right=new THREE.Vector3(Math.cos(cameraYaw),0,-Math.sin(cameraYaw));const dir=forward.multiplyScalar(-my).add(right.multiplyScalar(mx));const isWalking=dir.lengthSq()>.01;if(isWalking){player.position.addScaledVector(dir,speed*dt);player.rotation.y=Math.atan2(dir.x,dir.z);}
    player.position.x=THREE.MathUtils.clamp(player.position.x,-52,52);player.position.z=THREE.MathUtils.clamp(player.position.z,-66,40);velY-=12*dt;player.position.y+=velY*dt;if(player.position.y<0){player.position.y=0;velY=0;grounded=true}
    if(rainyWeather){const pos=rainGeometry.attributes.position;for(let i=0;i<rainDropsCount;i++){let y=pos.getY(i)-dt*17;if(y<0){y=rand(10,26);pos.setX(i,rand(-42,42));pos.setZ(i,rand(-48,38));}pos.setY(i,y);}pos.needsUpdate=true;}
    const t=now/1000;
    // Walk cycle: alternating leg swing, opposite arm swing, gentle torso bounce and head/shoulder sway.
    const walkPhase=t*10.5;
    if(isWalking && grounded && !dancing){
      legL.rotation.x=Math.sin(walkPhase)*.62;legR.rotation.x=-Math.sin(walkPhase)*.62;
      armL.rotation.x=-Math.sin(walkPhase)*.42;armR.rotation.x=Math.sin(walkPhase)*.42;
      armL.rotation.z=-.12;armR.rotation.z=.12;
      player.rotation.z=Math.sin(walkPhase)*.025;
    }else if(!dancing){
      legL.rotation.x=THREE.MathUtils.damp(legL.rotation.x,0,12,dt);legR.rotation.x=THREE.MathUtils.damp(legR.rotation.x,0,12,dt);
      armL.rotation.x=THREE.MathUtils.damp(armL.rotation.x,0,12,dt);armR.rotation.x=THREE.MathUtils.damp(armR.rotation.x,0,12,dt);
      armL.rotation.z=THREE.MathUtils.damp(armL.rotation.z,0,12,dt);armR.rotation.z=THREE.MathUtils.damp(armR.rotation.z,0,12,dt);
      player.rotation.z=THREE.MathUtils.damp(player.rotation.z,0,12,dt);
    }
    if(dancing){player.rotation.z=Math.sin(t*9)*.12;player.position.y=Math.max(0,player.position.y)+Math.abs(Math.sin(t*9))*.025}else if(!isWalking){player.rotation.z=THREE.MathUtils.damp(player.rotation.z,0,12,dt);}
    updateCamera();if(now-lastRender>=1000/targetFPS){renderer.render(scene,camera);lastRender=now;}
  }requestAnimationFrame(animate);
  addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);});

  // Kerala travel directory: all 14 districts with selected well-known places.
  const keralaDistricts = {
    "Thiruvananthapuram":["Kovalam Beach","Sree Padmanabhaswamy Temple","Napier Museum","Varkala Cliff","Ponmudi Hills"],
    "Kollam":["Jatayu Earth's Center","Ashtamudi Lake","Thangassery Lighthouse","Palaruvi Waterfalls"],
    "Pathanamthitta":["Sabarimala","Gavi","Aranmula Parthasarathy Temple","Perunthenaruvi Waterfalls"],
    "Alappuzha":["Alappuzha Beach","Alappuzha Backwaters","Kuttanad","Marari Beach"],
    "Kottayam":["Kumarakom Bird Sanctuary","Vembanad Lake","Illikkal Kallu","Ettumanoor Mahadeva Temple"],
    "Idukki":["Munnar","Eravikulam National Park","Thekkady & Periyar","Mattupetty Dam","Vagamon"],
    "Ernakulam":["Fort Kochi","Mattancherry Palace","Marine Drive Kochi","Cherai Beach","Hill Palace Museum"],
    "Thrissur":["Thrissur Pooram Ground","Vadakkunnathan Temple","Athirappilly Waterfalls","Guruvayur Temple","Kerala Kalamandalam"],
    "Palakkad":["Palakkad Fort","Malampuzha Dam","Silent Valley National Park","Nelliyampathy Hills"],
    "Malappuram":["Kottakkunnu","Nilambur Teak Museum","Adyanpara Waterfalls","Thirunavaya"],
    "Kozhikode":["Kozhikode Beach","Kappad Beach","Beypore Harbour","Mananchira Square","Thusharagiri Waterfalls"],
    "Wayanad":["Edakkal Caves","Banasura Sagar Dam","Pookode Lake","Chembra Peak","Soochipara Waterfalls"],
    "Kannur":["Muzhappilangad Drive-in Beach","St. Angelo Fort","Payyambalam Beach","Aralam Wildlife Sanctuary","Theyyam venues"],
    "Kasaragod":["Bekal Fort","Bekal Beach","Ranipuram Hills","Ananthapura Lake Temple","Valiyaparamba Backwaters"]
  };
  function showDistrictMenu(){
    const buttons=Object.keys(keralaDistricts).map(d=>`<button class="option" data-district="${d}">📍 ${d}</button>`).join('');
    showModal('Kerala Explorer — 14 districts',`<p>Choose a district from Thiruvananthapuram to Kasaragod.</p>${buttons}<p class="small-note">Travel directory includes popular spots; this prototype uses the current scenic world for travel previews.</p><button class="option" data-destination="home">🏡 Kerala house interior</button><button class="option" data-destination="pond">🎣 Village pond</button><button class="option" data-destination="stage">🎤 Wayanad festival stage</button><button class="option" data-destination="tea">☕ Chaya Kada</button><button class="option" data-destination="market">🥭 Market</button><button class="option" data-destination="forest">🌲 Forest trail</button><button class="option" data-destination="coast">🏖️ Coastal Town — Lighthouses & Beach Plaza</button>`);
  }
  function showDistrictSpots(district){
    const spots=keralaDistricts[district]||[];
    const buttons=spots.map((s,i)=>`<button class="option" data-spot="${s}" data-district="${district}" data-spot-index="${i}">🗺️ ${s}</button>`).join('');
    showModal(district,`<button class="option" data-backdistricts="1">← All Kerala districts</button><p>Popular places in ${district}:</p>${buttons}<p class="small-note">Place names are a travel directory; detailed unique maps for every destination can be added in later updates.</p>`);
  }
  function showSettings(){
    showModal('Graphics & Performance',`<p>Choose a preset, frame-rate target and render scale.</p>
      <label class="setting-label" for="graphicsPreset">Graphics quality</label>
      <select id="graphicsPreset" class="setting-control"><option value="low" selected>Low — smoother on phones</option><option value="medium">Medium — balanced</option><option value="high">High — more detail</option></select>
      <label class="setting-label" for="fpsTarget">FPS target</label>
      <select id="fpsTarget" class="setting-control"><option value="30" selected>30 FPS</option><option value="60">60 FPS</option><option value="90">90 FPS</option><option value="120">120 FPS</option></select>
      <label class="setting-label" for="renderScale">Render scale <span id="renderScaleLabel">80%</span></label>
      <input id="renderScale" class="setting-control" type="range" min="50" max="100" step="5" value="65">
      <p class="small-note">Actual FPS depends on your phone, browser and display refresh rate. 90/120 FPS may not be available on every device.</p>
      <button class="option" data-apply-settings="1">✓ Apply settings</button>`);
    document.getElementById('graphicsPreset').value=graphicsPreset;
    document.getElementById('fpsTarget').value=String(targetFPS);
    document.getElementById('renderScale').value=String(Math.round(renderScale*100));
    document.getElementById('renderScaleLabel').textContent=Math.round(renderScale*100)+'%';
  }
  let graphicsPreset='low',targetFPS=30,renderScale=.65;
  function applyGraphicsSettings(){
    const preset=document.getElementById('graphicsPreset'),fps=document.getElementById('fpsTarget'),scale=document.getElementById('renderScale');
    if(preset)graphicsPreset=preset.value;
    if(fps)targetFPS=Math.max(30,Math.min(120,Number(fps.value)||60));
    if(scale)renderScale=Math.max(.5,Math.min(1,Number(scale.value)/100||.8));
    const pixelRatio=Math.min(window.devicePixelRatio||1,graphicsPreset==='low'?0.75:graphicsPreset==='medium'?1.0:1.35)*renderScale/.8;
    renderer.setPixelRatio(Math.max(.5,Math.min(1.5,pixelRatio)));
    renderer.setSize(window.innerWidth,window.innerHeight,false);
    sun.castShadow=graphicsPreset!=='low';
    sun.shadow.mapSize.setScalar(graphicsPreset==='low'?256:graphicsPreset==='medium'?512:1024);
    sun.shadow.needsUpdate=true;
    toast(`Graphics: ${graphicsPreset.toUpperCase()} · ${targetFPS} FPS · ${Math.round(renderScale*100)}% render`);
  }

  // UI helpers
  const modal=document.getElementById('modal'),title=document.getElementById('modalTitle'),body=document.getElementById('modalBody');function showModal(t,html){title.textContent=t;body.innerHTML=html;modal.classList.remove('hidden')}function hideModal(){modal.classList.add('hidden')}document.getElementById('closeModal').onclick=hideModal;modal.addEventListener('click',e=>{if(e.target===modal)hideModal()});let toastTimer;function toast(s){const el=document.getElementById('toast');el.textContent=s;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),1900)}
  body.addEventListener('input',e=>{if(e.target&&e.target.id==='renderScale'){const l=document.getElementById('renderScaleLabel');if(l)l.textContent=e.target.value+'%';}});

  document.getElementById('sunBtn').onclick=()=>{isNight=!isNight;scene.background.set(isNight?0x172b4a:0x86d9e9);scene.fog.color.set(isNight?0x172b4a:0x86d9e9);sun.intensity=isNight?.35:2.2;toast(isNight?'🌙 Evening mode':'☀ Daylight mode')};if(document.getElementById('weatherBtn'))document.getElementById('weatherBtn').onclick=()=>{rainyWeather=!rainyWeather;rain.visible=rainyWeather;scene.background.set(rainyWeather?0x6e8b9d:(isNight?0x172b4a:0x75c9ef));scene.fog.color.set(rainyWeather?0x6e8b9d:(isNight?0x172b4a:0x75c9ef));toast(rainyWeather?'🌧️ Monsoon rain started':'🌤️ Rain stopped')};document.getElementById('soundBtn').onclick=e=>{e.currentTarget.textContent=e.currentTarget.textContent==='🔊'?'🔇':'🔊';toast('Sound setting changed')};document.getElementById('fullscreenBtn').onclick=()=>{if(!document.fullscreenElement)document.documentElement.requestFullscreen?.();else document.exitFullscreen?.()};document.getElementById('helpBtn').onclick=()=>showModal('How to play',`<p>Move with the left joystick. On a computer, use <b>WASD</b> or arrow keys. Tap ↑ to jump.</p><p>Use the right-side buttons for emotes and camera options. Explore the forest and enjoy the Wayanad-inspired world.</p><p class="small-note">Prototype build: online multiplayer and real account systems are not included.</p>`);
  document.getElementById('diceBtn').onclick=()=>{const emotes=['🎉 Happy dance!','💖 Heart emote!','👋 Hello, friend!','✨ Sparkles!'];toast(emotes[Math.floor(Math.random()*emotes.length)])};document.getElementById('danceBtn').onclick=()=>{dancing=!dancing;toast(dancing?'💃 Dance mode on':'Dance mode off')};document.getElementById('cameraBtn').onclick=()=>{cameraYaw+=Math.PI/2;toast('Camera angle changed')};document.getElementById('photoBtn').onclick=()=>{photoMode=!photoMode;document.querySelector('.right-tools').style.opacity=photoMode?'.35':'1';document.querySelector('.topbar').style.opacity=photoMode?'.35':'1';toast(photoMode?'📸 Photo mode — tap again to exit':'Photo mode off')};document.getElementById('smileBtn').onclick=()=>showModal('Emotes',`<button class="option" data-emote="👋 Waving hello">👋 Waving hello</button><button class="option" data-emote="💃 Dancing">💃 Dancing</button><button class="option" data-emote="💖 Heart hands">💖 Heart hands</button><button class="option" data-emote="🙌 Celebration">🙌 Celebration</button>`);document.getElementById('avatarBtn').onclick=()=>showModal('Avatar wardrobe',`<div class="avatar-preview">👧🏻</div><p>Choose a starter look for your explorer.</p><button class="option" data-avatar="pink">💗 Pink hoodie</button><button class="option" data-avatar="mint">🌿 Forest explorer</button><button class="option" data-avatar="gold">🌞 Sunny yellow</button><button class="option" data-avatar="blue">🌊 Ocean blue</button><button class="option" data-avatar="purple">💜 Purple dusk</button><p class="small-note">Choose an outfit colour. Changes are temporary and reset when the page reloads.</p>`);
  document.getElementById('mapBtn').onclick=()=>showDistrictMenu();
  document.getElementById('settingsBtn').onclick=()=>showSettings();document.getElementById('featureBtn').onclick=()=>showModal('Request a feature',`<p>What should be added next to Kerala World?</p><button class="option" data-feature="More outfits">👕 More outfits</button><button class="option" data-feature="Multiplayer rooms">👥 Multiplayer rooms</button><button class="option" data-feature="Malayalam chat">💬 Malayalam chat</button>`);
  document.getElementById('friendsBtn').onclick=()=>showModal('Friends',`<p>👤 You are exploring solo.</p><p class="small-note">This is a local prototype. Online friend invites need a multiplayer server.</p>`);document.getElementById('chatBtn').onclick=()=>showModal('World chat',`<p>💬 Welcome to Wayanad!</p><p class="small-note">Local demo chat only. No messages are sent to a server.</p><button class="option" id="sayHi">👋 Say hello</button>`);document.getElementById('shopBtn').onclick=()=>document.getElementById('avatarBtn').click();document.getElementById('profileBtn').onclick=()=>showModal('Explorer profile',`<div class="avatar-preview">👧🏻</div><p><b>Wayanad Explorer</b></p><p>🏆 120 points · 🌴 Forest explorer</p><p class="small-note">Profile is stored for this demo session only.</p>`);document.getElementById('homeBtn').onclick=()=>{player.position.set(0,0,4);cameraYaw=0;toast('Back to Wayanad spawn')};
  body.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;
    if(b.dataset.backdistricts){showDistrictMenu();return;}
    if(b.dataset.district && !b.dataset.spot){showDistrictSpots(b.dataset.district);return;}
    if(b.dataset.spot){
      const district=b.dataset.district,spot=b.dataset.spot,idx=Number(b.dataset.spotIndex)||0;
      // Use a stable scenic travel point in the existing map for this directory entry.
      const allDistricts=Object.keys(keralaDistricts),di=Math.max(0,allDistricts.indexOf(district));
      const px=-38+((di*13+idx*7)%77),pz=-52+((di*17+idx*11)%88);
      player.position.set(px,0,pz);cameraYaw=0;dancing=false;insideHouse=false;interior.visible=false;
      document.querySelector('.location strong').textContent=spot;
      document.querySelector('.location small').textContent=district+' · Kerala';
      document.getElementById('statusText').textContent='Visiting '+spot;
      hideModal();toast('📍 '+spot+', '+district);return;
    }
    if(b.dataset.food){
      const food=b.dataset.food,price=Number(b.dataset.price)||0;
      toast('🍽️ Order placed: '+food+' · ₹'+price+' (demo only)');
      showModal('✅ Order received',`<p>Your order for <b>${food}</b> has been sent to the Chayakada counter.</p><p>Demo total: ₹${price}</p><p class="small-note">No real payment was taken.</p><button class="option" data-action="coastShop">Order something else</button><button class="option" data-action="coastShopExit">Finish</button>`);
      return;
    }
    if(b.dataset.applySettings){applyGraphicsSettings();hideModal();return;}
    if(b.dataset.destination){
      const spots={stage:[-13,0,-10],tea:[13,0,-19],market:[-13,0,-31],forest:[0,0,4],pond:[28,0,7],home:[37,0,-13],coast:[76,0,1]};
      player.position.set(...spots[b.dataset.destination]);cameraYaw=0;dancing=false;
      if(b.dataset.destination==='coast'){
        insideHouse=false;interior.visible=false;
        document.getElementById('statusText').textContent='Exploring Kerala Coast';
        showModal('🏖️ Kerala Coastal Town',`<p>Welcome to the seaside town!</p><p>Explore the twin lighthouses, beach, pavilion, shops and promenade.</p><button class="option" data-action="coastShop">🏪 Visit the new roadside tea shop</button><button class="option" data-action="coastHouse">🏡 Visit the red-roof community house</button><button class="option" data-action="coastExplore">🌊 Explore the beach promenade</button><button class="option" data-action="coastBack">↩ Return to Wayanad</button>`);return;
      }
      if(b.dataset.destination==='home'){
        insideHouse=true;interior.visible=true;document.getElementById('statusText').textContent='Inside a Kerala home';
        showModal('🏡 Kerala Home',`<p>Welcome inside a traditional Kerala-style home.</p><button class="option" data-action="homeExplore">🪑 Explore the living room</button><button class="option" data-action="homeExit">🚪 Leave the house</button>`);return;
      }
      if(b.dataset.destination==='pond'){
        insideHouse=false;interior.visible=false;document.getElementById('statusText').textContent='At the village pond';
        showModal('🎣 Village Pond',`<p>Cast your line and see what you catch!</p><button class="option" data-action="fish">🎣 Go fishing</button><button class="option" data-action="homeExit">🚶 Return to village</button>`);return;
      }
      if(b.dataset.destination==='stage'){
        showModal('🎤 Wayanad Utsavam',`<p>Welcome to the festival stage!</p><button class="option" data-action="mic">🎙️ Use microphone</button><button class="option" data-action="music">🎵 Start / stop festival music</button><button class="option" data-action="stageDance">💃 Dance on stage</button>`);
      } else if(b.dataset.destination==='tea'){
        showModal('☕ Chaya Kada',`<p>Welcome! What would you like?</p><button class="option" data-action="tea">☕ Order a chaya — ₹10 (demo)</button><button class="option" data-action="snack">🍌 Order a pazham pori — ₹15 (demo)</button><button class="option" data-action="sit">🪑 Sit on the bench</button>`);
      } else if(b.dataset.destination==='market'){
        showModal('🥭 Wayanad Market',`<p>Explore the colourful local stalls.</p><button class="option" data-action="mango">🥭 Buy mango — ₹20 (demo)</button><button class="option" data-action="banana">🍌 Buy bananas — ₹15 (demo)</button><button class="option" data-action="veg">🥬 Buy vegetables — ₹25 (demo)</button>`);
      } else {
        toast('🌲 Back to the forest trail and pond');hideModal();
      }
    }
    if(b.dataset.action){
      const action=b.dataset.action;
      if(action==='mic')toast('🎙️ Microphone on — you are the star of Wayanad!');
      if(action==='fish'){const catches=['🐟 You caught a small fish!','🐠 You caught a colourful fish!','🦐 You found a tiny shrimp!','🌿 No catch this time — try again!'];toast(catches[Math.floor(Math.random()*catches.length)]);}
      if(action==='homeExplore')toast('🏡 You explored the living room of the Kerala home.');
      if(action==='coastExplore'){player.position.set(76,0,-34);toast('🌊 Enjoy the Kerala coast and lighthouse view!');}
      if(action==='coastShop'){
        player.position.set(35,0,-40);
        document.getElementById('statusText').textContent='At Kerala Chayakada';
        showModal('🍛 Rafi Rambo’s Chayakada',`<p>Welcome! Choose something from the Kerala menu.</p>
          <div class="food-menu">
            <button class="option" data-food="Chaya" data-price="15">☕ Chaya <span>₹15</span></button>
            <button class="option" data-food="Pazham pori" data-price="20">🍌 Pazham pori <span>₹20</span></button>
            <button class="option" data-food="Porotta" data-price="15">🫓 Porotta <span>₹15</span></button>
            <button class="option" data-food="Porotta & beef curry" data-price="100">🍛 Porotta & beef curry <span>₹100</span></button>
            <button class="option" data-food="Meals" data-price="90">🍚 Kerala meals <span>₹90</span></button>
            <button class="option" data-food="Puttu & kadala" data-price="60">🥥 Puttu & kadala <span>₹60</span></button>
          </div><p class="small-note">Demo ordering only — no real payment.</p>
          <button class="option" data-action="coastShopExit">↩ Back outside</button>`);
        return;
      }
      if(action==='coastHouse'){player.position.set(72,0,10);toast('🏡 Welcome to the red-roof Kerala community house!');}
      if(action==='coastShopExit'){player.position.set(35,0,-31);document.getElementById('statusText').textContent='Exploring Kerala Coast';toast('🚪 Back outside the Chayakada');}
      if(action==='coastBack'){player.position.set(0,0,0);document.getElementById('statusText').textContent='Exploring Wayanad';toast('↩ Back to Wayanad');}
      if(action==='homeExit'){insideHouse=false;interior.visible=false;player.position.set(25,0,-7);document.getElementById('statusText').textContent='Exploring Wayanad';toast('🚪 Back outside in Wayanad.');}

      if(action==='music')toast('🎵 Festival music toggled (visual demo; no audio track)');
      if(action==='stageDance'){dancing=!dancing;toast(dancing?'💃 Performing on stage!':'Dance performance stopped')}
      if(action==='tea')toast('☕ Chaya served! Demo order — no real payment');
      if(action==='snack')toast('🍌 Pazham pori served! Demo order — no real payment');
      if(action==='sit'){player.position.set(13,0,-21.7);toast('🪑 Taking a seat at the chaya kada!')}
      if(['mango','banana','veg'].includes(action))toast(({mango:'🥭 Mango added to your demo basket!',banana:'🍌 Bananas added to your demo basket!',veg:'🥬 Vegetables added to your demo basket!'})[action]+' No real payment.');
      hideModal();
    }
    if(b.dataset.emote){toast(b.dataset.emote);hideModal()}
    if(b.dataset.feature){toast('Thanks! Feature idea: '+b.dataset.feature);hideModal()}
    if(b.dataset.avatar){const colors={pink:0xe91e78,mint:0x2fbd9b,gold:0xf2bb36,blue:0x287cc7,purple:0x8a4eb8};player.children.find(c=>c.material===pink)?.material.color.setHex(colors[b.dataset.avatar]);toast('Outfit changed!');hideModal()}
    if(b.id==='sayHi'){toast('👋 Hello, Wayanad!');hideModal()}
  });
  const playBtn=document.getElementById('launchPlay');
  if(playBtn)playBtn.addEventListener('click',()=>{
    gameStarted=true;last=performance.now();
    document.getElementById('launcher').classList.add('launcher-hide');
    document.body.classList.add('game-active');
    renderer.setSize(window.innerWidth,window.innerHeight,false);
    toast('🌴 Welcome to Lil Kerala!');
  });
  document.getElementById('friendCount').textContent='1';document.getElementById('loading').style.opacity='0';setTimeout(()=>document.getElementById('loading').remove(),500);
})();
