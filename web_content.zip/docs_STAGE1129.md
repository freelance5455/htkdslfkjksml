# CPLS V2 — Stage 1129

## Live chart continuity
- Keeps the chart pinned to the newest candle when live samples append a new candle.
- Preserves user zoom/pan position when the user is viewing historical candles.
- Prevents live updates from resetting the chart viewport.
- Timeframe reload maintains a sensible viewport.

Source ZIP stage only; APK build not performed in this environment.
