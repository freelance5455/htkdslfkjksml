/* ========================= CURRICULUM JAVASCRIPT (adapté du bootcamp original) ========================= */
const CURRICULUM_JS = [
  {week:"Semaine 1 — Fondations",days:[
    {d:1,title:"Les fondations",sub:"Variables, types, console",level:"easy",
     theory:`<div class="theory-block"><h3>🌱 1.1 — Qu'est-ce que JavaScript, et où il vit</h3><p>JavaScript (JS) est né en 1995 pour rendre les pages web interactives : cliquer, animer, valider un formulaire sans recharger la page. C'est aujourd'hui bien plus que ça — avec Node.js, le même langage tourne aussi côté serveur, écrit des scripts, pilote des bases de données. C'est le <b>seul langage natif du navigateur</b> : aucun autre langage ne s'exécute directement dans Chrome, Firefox ou Safari sans passer par une compilation vers JS. Comprendre JS, c'est donc comprendre la moitié du web moderne — l'autre moitié étant le serveur qui lui parle.</p></div>

<div class="theory-block"><h3>📦 1.2 — Trois façons de déclarer une variable (et pourquoi une seule compte vraiment)</h3><p>JS propose trois mots-clés, hérités de trois époques différentes du langage :</p>
<p><code style="color:#f7c948">var</code> — le tout premier, datant de 1995. Il a un comportement étrange (portée de fonction plutôt que de bloc, ré-déclaration silencieuse autorisée) qui a causé d'innombrables bugs. On ne l'utilise plus dans du code moderne, mais tu le croiseras dans du vieux code.</p>
<p><code style="color:#f7c948">let</code> — introduit en 2015, une variable normale qui peut être réassignée plus tard. Portée de bloc propre (elle n'existe que dans les <code>{ }</code> où elle est créée).</p>
<p><code style="color:#f7c948">const</code> — une constante : une fois assignée, elle ne peut plus être réassignée. C'est le choix par défaut recommandé, car il rend ton code plus prévisible — si tu vois <code>const</code>, tu sais que cette valeur ne changera jamais.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="cmt">// Déclaration de variables</span>
<span class="kw">let</span> <span class="var">prenom</span> = <span class="str">"Nerija"</span>;
<span class="kw">const</span> <span class="var">age</span> = <span class="num">18</span>;
<span class="kw">let</span> <span class="var">estEtudiant</span> = <span class="kw">true</span>;

<span class="fn">console</span>.<span class="fn">log</span>(prenom); <span class="cmt">// "Nerija"</span>
<span class="fn">console</span>.<span class="fn">log</span>(age);    <span class="cmt">// 18</span>
<span class="fn">console</span>.<span class="fn">log</span>(<span class="kw">typeof</span> prenom); <span class="cmt">// "string"</span>

<span class="var">prenom</span> = <span class="str">"Awa"</span>;   <span class="cmt">// OK, let peut être réassigné</span>
<span class="cmt">// age = 19;         → TypeError : Assignment to constant variable</span></div></div>
<div class="tip-box"><strong>💡 Astuce pro :</strong> Utilise toujours <code>const</code> par défaut. Ne passe à <code>let</code> que si tu sais déjà que la variable devra changer (un compteur, par exemple). N'utilise jamais <code>var</code>.</div>
</div>

<div class="theory-block"><h3>🔢 1.3 — Les types primitifs, un par un</h3><p><b>string</b> — du texte, entre guillemets simples, doubles ou backticks : <code>"Nerija"</code>. <b>number</b> — tous les nombres, entiers ou décimaux, un seul type pour les deux (contrairement à Python qui distingue <code>int</code> et <code>float</code>) : <code>18</code> comme <code>3.14</code>. <b>boolean</b> — <code>true</code> ou <code>false</code>, toujours en minuscules. <b>undefined</b> — une variable déclarée mais jamais assignée ; c'est JS qui te le donne automatiquement. <b>null</b> — l'absence de valeur, mais assignée volontairement par toi pour dire "ici, il n'y a rien exprès".</p>
<p>L'opérateur <code>typeof</code> te dit à tout moment le type réel d'une valeur — un réflexe de débogage à garder sous la main.</p></div>

<div class="theory-block"><h3>🖥️ 1.4 — La console : ta fenêtre sur ce qui se passe</h3><p><code>console.log()</code> est ta commande la plus utilisée en JS : elle affiche n'importe quelle valeur dans la console pour l'inspecter. Elle a des cousines utiles : <code>console.warn()</code> (avertissement, en jaune), <code>console.error()</code> (erreur, en rouge), et <code>console.table()</code> (affiche un tableau ou objet sous forme de... tableau lisible). Prends l'habitude de logguer généreusement pendant que tu apprends — c'est le meilleur moyen de comprendre ce que fait réellement chaque ligne.</p>
<div class="tip-box"><strong>⚠️ Piège fréquent :</strong> <code>typeof null</code> renvoie <code>"object"</code> — un bug historique du langage conservé pour ne pas casser d'anciens sites. Ne t'y fie pas pour tester si une valeur est <code>null</code> ; utilise plutôt <code>maVariable === null</code>.</div>
</div>`,
     starter:`// Jour 1 — Tes premières variables !
// Écris du code ci-dessous et clique Run

let nom = "Nerija";
const annee = 2007;
let langage = "JavaScript";

console.log("Bonjour, je m'appelle " + nom);
console.log("J'apprends le " + langage);
console.log("Je suis né en " + annee);`,
     quiz:[{q:"Lequel utilises-tu pour une variable qui ne change pas ?",opts:["var","let","const","def"],ans:2},
           {q:"Quel est le type de : typeof 'Bonjour' ?",opts:["number","string","boolean","object"],ans:1},
           {q:"console.log() sert à...",opts:["Déclarer une variable","Afficher dans la console","Faire un calcul","Créer une fonction"],ans:1}]},

    {d:2,title:"Opérations & Strings",sub:"Arithmétique, concaténation, template literals",level:"easy",
     theory:`<div class="theory-block"><h3>➕ 2.1 — Les opérateurs arithmétiques, un par un</h3><p>JavaScript propose six opérateurs arithmétiques : <code style="color:#f7c948">+</code> (addition), <code style="color:#f7c948">-</code> (soustraction), <code style="color:#f7c948">*</code> (multiplication), <code style="color:#f7c948">/</code> (division), <code style="color:#f7c948">%</code> (modulo — le <i>reste</i> d'une division) et <code style="color:#f7c948">**</code> (puissance). Contrairement à Python, JS ne distingue pas les entiers des décimaux : un seul type <code>number</code> gère les deux, donc <code>10 / 3</code> te renverra directement <code>3.3333333333333335</code> sans conversion à demander.</p>
<p>Le modulo mérite un peu d'attention car il surprend les débutants : il ne "divise" pas, il te dit ce qu'il <i>reste</i> une fois la division entière faite. C'est l'outil numéro un pour tester la parité d'un nombre (<code>n % 2 === 0</code> pour un nombre pair), ou pour faire boucler un compteur sur une plage fixe — tu le recroiseras énormément dans les jours à venir.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">a</span> = <span class="num">10</span>;
<span class="kw">const</span> <span class="var">b</span> = <span class="num">3</span>;

<span class="fn">console</span>.<span class="fn">log</span>(a + b);  <span class="cmt">// 13</span>
<span class="fn">console</span>.<span class="fn">log</span>(a - b);  <span class="cmt">// 7</span>
<span class="fn">console</span>.<span class="fn">log</span>(a * b);  <span class="cmt">// 30</span>
<span class="fn">console</span>.<span class="fn">log</span>(a / b);  <span class="cmt">// 3.3333333333333335</span>
<span class="fn">console</span>.<span class="fn">log</span>(a % b);  <span class="cmt">// 1 (reste de 10 ÷ 3)</span>
<span class="fn">console</span>.<span class="fn">log</span>(a ** b); <span class="cmt">// 1000 (10³, 10 x 10 x 10)</span>

<span class="cmt">// Le modulo pour tester la parité</span>
<span class="fn">console</span>.<span class="fn">log</span>(a % <span class="num">2</span> === <span class="num">0</span>); <span class="cmt">// true, 10 est pair</span></div></div></div>

<div class="theory-block"><h3>⚠️ 2.2 — Le piège du + entre nombre et texte</h3><p>Dans la plupart des langages, additionner un nombre et du texte provoque une erreur. Pas en JavaScript : l'opérateur <code style="color:#f7c948">+</code> est aussi utilisé pour <b>concaténer</b> des chaînes, et dès qu'une des deux valeurs est une string, JS convertit silencieusement l'autre en texte plutôt que de calculer. C'est une source de bugs classique chez les débutants — et même chez les développeurs expérimentés fatigués.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="fn">console</span>.<span class="fn">log</span>(<span class="num">5</span> + <span class="num">3</span>);      <span class="cmt">// 8 → deux nombres, addition normale</span>
<span class="fn">console</span>.<span class="fn">log</span>(<span class="str">"5"</span> + <span class="num">3</span>);    <span class="cmt">// "53" → concaténation ! le 3 devient texte</span>
<span class="fn">console</span>.<span class="fn">log</span>(<span class="num">5</span> + <span class="str">"3"</span>);    <span class="cmt">// "53" → même résultat, l'ordre ne change rien</span>
<span class="fn">console</span>.<span class="fn">log</span>(<span class="str">"5"</span> - <span class="num">3</span>);    <span class="cmt">// 2 → surprise : "-" ne concatène jamais, il convertit "5" en nombre</span>

<span class="cmt">// Solution : convertir explicitement AVANT de calculer</span>
<span class="kw">const</span> <span class="var">saisie</span> = <span class="str">"42"</span>; <span class="cmt">// une valeur venue d'un formulaire est toujours une string</span>
<span class="kw">const</span> <span class="var">nombre</span> = <span class="fn">Number</span>(saisie);
<span class="fn">console</span>.<span class="fn">log</span>(nombre + <span class="num">8</span>); <span class="cmt">// 50, un vrai calcul cette fois</span></div></div>
<div class="tip-box"><strong>💡 Astuce :</strong> Retiens la règle : <code>+</code> concatène dès qu'une string est impliquée, mais <code>-</code>, <code>*</code>, <code>/</code>, <code>%</code> et <code>**</code> forcent toujours une conversion en nombre. Pour convertir une string en nombre volontairement, utilise <code>Number("42")</code> ou le raccourci <code>+"42"</code>.</div></div>

<div class="theory-block"><h3>✍️ 2.3 — Template literals : la fin de la concaténation</h3><p>Avant 2015, construire une phrase avec des variables obligeait à enchaîner des <code>+</code> partout — illisible dès que la phrase s'allonge. Les <b>template literals</b> résolvent ce problème : on ouvre et ferme la chaîne avec des <b>backticks</b> (le caractère au-dessus de la touche Tab sur un clavier AZERTY) au lieu de guillemets, et on insère directement des variables avec la syntaxe <code style="color:#f7c948">\${ }</code> (le symbole dollar suivi d'accolades).</p>
<p>Deux avantages immédiats par rapport aux guillemets classiques : plus besoin de sortir de la chaîne pour coller une variable avec <code>+</code>, et les retours à la ligne sont acceptés tels quels à l'intérieur des backticks (essaie de faire ça avec des guillemets simples, tu auras une erreur de syntaxe).</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">nom</span> = <span class="str">"Nerija"</span>;
<span class="kw">const</span> <span class="var">note</span> = <span class="num">18</span>;

<span class="cmt">// Ancienne méthode (fonctionne, mais lourde à lire)</span>
<span class="fn">console</span>.<span class="fn">log</span>(<span class="str">"Bonjour "</span> + nom + <span class="str">", ta note : "</span> + note + <span class="str">"/20"</span>);

<span class="cmt">// Template literal (moderne ✅, à utiliser systématiquement)</span>
<span class="fn">console</span>.<span class="fn">log</span>(<span class="str">\`Bonjour \${nom}, ta note : \${note}/20\`</span>);</div></div></div>

<div class="theory-block"><h3>🧮 2.4 — Des expressions vivantes à l'intérieur de \${ }</h3><p>Le point qui surprend beaucoup de débutants : à l'intérieur des accolades de <code style="color:#f7c948">\${ }</code>, tu ne peux pas seulement mettre une variable — tu peux y glisser <b>n'importe quelle expression JavaScript valide</b> : un calcul, un appel de fonction, un ternaire, un accès à une propriété. JS évalue l'expression, puis convertit le résultat en texte pour l'insérer à la place.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">score</span> = <span class="num">85</span>;
<span class="kw">const</span> <span class="var">bonus</span> = <span class="num">15</span>;

<span class="cmt">// Un calcul directement dans les accolades</span>
<span class="fn">console</span>.<span class="fn">log</span>(<span class="str">\`Score total : \${score + bonus}/100\`</span>);

<span class="cmt">// Un ternaire, pour du texte conditionnel en une ligne</span>
<span class="fn">console</span>.<span class="fn">log</span>(<span class="str">\`Bilan : \${score >= <span class="num">50</span> ? <span class="str">"réussite"</span> : <span class="str">"échec"</span>}\`</span>);</div></div>
<div class="tip-box"><strong>⚠️ Piège fréquent :</strong> Le backtick est un caractère bien précis, différent des guillemets simples (<code>'</code>) et doubles (<code>"</code>). Si tu utilises des guillemets simples ou doubles autour de ton texte, <code>\${ }</code> ne sera jamais interprété — il s'affichera tel quel, comme du texte brut.</div></div>

<div class="theory-block"><h3>🔡 2.5 — Les méthodes de string incontournables</h3><p>Une string en JS n'est pas juste du texte figé : c'est un objet qui embarque des dizaines de méthodes prêtes à l'emploi. Voici les plus utilisées, celles que tu écriras tous les jours :</p>
<p><code>.length</code> — pas une méthode (pas de parenthèses), une propriété qui donne le nombre de caractères. <code>.toUpperCase()</code> et <code>.toLowerCase()</code> — changent la casse. <code>.includes("mot")</code> — renvoie <code>true</code>/<code>false</code> selon qu'un fragment est présent. <code>.replace("a","b")</code> — remplace la première occurrence d'un fragment par un autre. <code>.trim()</code> — retire les espaces inutiles au début et à la fin. <code>.split(",")</code> — découpe une string en tableau selon un séparateur.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">langue</span> = <span class="str">"  JavaScript  "</span>;

<span class="fn">console</span>.<span class="fn">log</span>(langue.<span class="fn">length</span>);          <span class="cmt">// 14 (espaces compris !)</span>
<span class="fn">console</span>.<span class="fn">log</span>(langue.<span class="fn">trim</span>().<span class="fn">length</span>); <span class="cmt">// 10, sans les espaces</span>
<span class="fn">console</span>.<span class="fn">log</span>(langue.<span class="fn">trim</span>().<span class="fn">toUpperCase</span>()); <span class="cmt">// "JAVASCRIPT"</span>
<span class="fn">console</span>.<span class="fn">log</span>(langue.<span class="fn">includes</span>(<span class="str">"Script"</span>)); <span class="cmt">// true</span></div></div>
<div class="tip-box"><strong>💡 Astuce pro :</strong> Toutes ces méthodes renvoient une <b>nouvelle</b> string — elles ne modifient jamais l'originale. C'est pour ça qu'on peut les enchaîner comme dans <code>langue.trim().toUpperCase()</code> : chaque méthode passe son résultat à la suivante.</div></div>`,
     starter:`// Jour 2 — Opérations et Strings
const prenom = "Nerija";
const langue = "JavaScript";
const joursRestants = 28;

// 1. Affiche une phrase avec template literal
console.log(\`\${prenom} apprend le \${langue} !\`);

// 2. Calculs
const score = 85;
const bonus = 15;
console.log(\`Score total : \${score + bonus}/100\`);

// 3. Méthodes de string
console.log(prenom.toUpperCase());
console.log(langue.length);`,
     quiz:[{q:"Quelle syntaxe est correcte pour un template literal ?",opts:['"Bonjour ${nom}"',"'Bonjour ${nom}'",'`Bonjour ${nom}`',"(Bonjour nom)"],ans:2},
           {q:"Que retourne 10 % 3 ?",opts:["3","1","0","33"],ans:1},
           {q:"'hello'.toUpperCase() retourne ?",opts:["Hello","HELLO","hello","HeLLo"],ans:1}]},

    {d:3,title:"Conditions",sub:"if, else, opérateurs de comparaison",level:"easy",
     theory:`<div class="theory-block"><h3>🔀 3.1 — if / else : faire prendre des décisions à ton code</h3><p>Jusqu'ici, ton code s'exécutait ligne par ligne, sans jamais dévier. Avec <code style="color:#f7c948">if</code> (littéralement "si"), tu peux enfin lui faire choisir un chemin selon une condition. La condition, placée entre parenthèses, est évaluée : si elle vaut <code>true</code>, le bloc <code>{ }</code> qui suit s'exécute ; sinon, il est ignoré. C'est le mécanisme le plus fondamental de toute programmation — sans lui, un programme ne serait qu'une liste figée d'instructions incapable de réagir aux données.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">note</span> = <span class="num">14</span>;

<span class="kw">if</span> (note >= <span class="num">10</span>) {
  <span class="fn">console</span>.<span class="fn">log</span>(<span class="str">"Admis"</span>);
}
<span class="cmt">// Rien ne s'affiche si la condition est fausse — le bloc est juste ignoré</span></div></div></div>

<div class="theory-block"><h3>🪜 3.2 — else if et else : couvrir tous les cas</h3><p>Un simple <code>if</code> ne gère qu'un seul cas. Pour enchaîner plusieurs possibilités, on ajoute des <code style="color:#f7c948">else if</code> (autant que nécessaire), puis un <code style="color:#f7c948">else</code> final qui attrape tout ce qui n'a matché aucune condition précédente. JS évalue les conditions <b>dans l'ordre</b>, du haut vers le bas, et s'arrête à la première qui est vraie — les suivantes ne sont même pas testées.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">note</span> = <span class="num">14</span>;

<span class="kw">if</span> (note >= <span class="num">16</span>) {
  <span class="fn">console</span>.<span class="fn">log</span>(<span class="str">"Très bien ! 🏆"</span>);
} <span class="kw">else if</span> (note >= <span class="num">12</span>) {
  <span class="fn">console</span>.<span class="fn">log</span>(<span class="str">"Bien ! 👍"</span>); <span class="cmt">// c'est cette branche qui s'exécute pour note=14</span>
} <span class="kw">else if</span> (note >= <span class="num">10</span>) {
  <span class="fn">console</span>.<span class="fn">log</span>(<span class="str">"Passable"</span>);
} <span class="kw">else</span> {
  <span class="fn">console</span>.<span class="fn">log</span>(<span class="str">"Peut mieux faire 📚"</span>);
}</div></div>
<div class="tip-box"><strong>⚠️ Piège fréquent :</strong> Écrire les conditions dans le mauvais ordre. Si tu avais testé <code>note >= 10</code> en premier, la branche "Très bien" ne serait <b>jamais</b> atteinte, même pour une note de 20. Range toujours tes conditions de la plus stricte à la plus large.</div></div>

<div class="theory-block"><h3>⚖️ 3.3 — Les opérateurs de comparaison, et le piège du double égal</h3><p>JS propose deux familles de comparaison : d'un côté <code style="color:#f7c948">></code>, <code style="color:#f7c948"><</code>, <code style="color:#f7c948">>=</code>, <code style="color:#f7c948"><=</code> pour l'ordre ; de l'autre, <code style="color:#f7c948">==</code> / <code style="color:#f7c948">!=</code> (égalité "souple") contre <code style="color:#f7c948">===</code> / <code style="color:#f7c948">!==</code> (égalité "stricte"). La différence est cruciale : <code>==</code> convertit les types avant de comparer, ce qui produit des résultats parfois absurdes ; <code>===</code> compare la valeur <b>et</b> le type, sans aucune conversion cachée.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="fn">console</span>.<span class="fn">log</span>(<span class="num">5</span> > <span class="num">3</span>);      <span class="cmt">// true</span>
<span class="fn">console</span>.<span class="fn">log</span>(<span class="str">"5"</span> == <span class="num">5</span>);   <span class="cmt">// true  → == convertit "5" en nombre avant de comparer</span>
<span class="fn">console</span>.<span class="fn">log</span>(<span class="str">"5"</span> === <span class="num">5</span>);  <span class="cmt">// false → types différents, === ne convertit jamais</span>
<span class="fn">console</span>.<span class="fn">log</span>(<span class="num">0</span> == <span class="kw">false</span>); <span class="cmt">// true  → encore une conversion surprenante</span></div></div>
<div class="tip-box"><strong>💡 Règle d'or :</strong> N'utilise jamais <code>==</code> ou <code>!=</code> dans du code moderne. Utilise systématiquement <code>===</code> et <code>!==</code> — ils évitent une classe entière de bugs difficiles à repérer.</div></div>

<div class="theory-block"><h3>❓ 3.4 — L'opérateur ternaire : un if/else en une ligne</h3><p>Quand tu veux juste choisir entre <b>deux</b> valeurs selon une condition, le ternaire <code style="color:#f7c948">condition ? siVrai : siFaux</code> fait le travail en une seule expression. Il se lit : "si condition, alors la valeur avant les deux-points, sinon la valeur après".</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">note</span> = <span class="num">14</span>;
<span class="kw">const</span> <span class="var">statut</span> = note >= <span class="num">10</span> ? <span class="str">"Admis"</span> : <span class="str">"Refusé"</span>;
<span class="fn">console</span>.<span class="fn">log</span>(statut); <span class="cmt">// "Admis"</span>

<span class="kw">const</span> <span class="var">age</span> = <span class="num">16</span>;
<span class="kw">const</span> <span class="var">categorie</span> = age >= <span class="num">18</span> ? <span class="str">"adulte"</span> : <span class="str">"mineur"</span>;
<span class="fn">console</span>.<span class="fn">log</span>(categorie); <span class="cmt">// "mineur", car 16 >= 18 est faux</span></div></div></div>

<div class="theory-block"><h3>🔗 3.5 — Combiner des conditions : &&, || et !</h3><p>Souvent, une décision dépend de <b>plusieurs</b> critères à la fois. Trois opérateurs logiques permettent de les combiner : <code style="color:#f7c948">&&</code> (ET — les deux côtés doivent être vrais), <code style="color:#f7c948">||</code> (OU — au moins un côté doit être vrai), et <code style="color:#f7c948">!</code> (NON — inverse un booléen).</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">age</span> = <span class="num">20</span>;
<span class="kw">const</span> <span class="var">pays</span> = <span class="str">"CI"</span>;

<span class="kw">if</span> (age >= <span class="num">18</span> && pays === <span class="str">"CI"</span>) {
  <span class="fn">console</span>.<span class="fn">log</span>(<span class="str">"Majeur en Côte d'Ivoire"</span>);
}

<span class="kw">const</span> <span class="var">weekend</span> = <span class="kw">false</span>;
<span class="kw">const</span> <span class="var">ferie</span> = <span class="kw">true</span>;
<span class="kw">if</span> (weekend || ferie) {
  <span class="fn">console</span>.<span class="fn">log</span>(<span class="str">"Pas cours aujourd'hui !"</span>);
}

<span class="fn">console</span>.<span class="fn">log</span>(!weekend); <span class="cmt">// true, puisque weekend vaut false</span></div></div>
<div class="tip-box"><strong>💡 Astuce :</strong> Pense à <code>&&</code> comme une porte à deux verrous — il faut ouvrir les deux pour passer — et à <code>||</code> comme deux portes en parallèle, où une seule suffit.</div></div>`,
     starter:`// Jour 3 — Conditions
const heure = 14; // 14h

if (heure < 12) {
  console.log("Bonjour !");
} else if (heure < 18) {
  console.log("Bon après-midi !");
} else {
  console.log("Bonsoir !");
}

// Exerce-toi : crée une variable note et affiche la mention
const note = 15;
// Écris ta logique ici...`,
     quiz:[{q:"=== compare quoi ?",opts:["Valeur seulement","Type seulement","Valeur ET type","Ni l'un ni l'autre"],ans:2},
           {q:"Que retourne : 5 > 3 ?",opts:["5","3","true","false"],ans:2},
           {q:"Ternaire : age >= 18 ? 'adulte' : 'mineur' — si age=16 ?",opts:["adulte","mineur","undefined","erreur"],ans:1}]},

    {d:4,title:"Boucles",sub:"for, while, forEach",level:"easy",
     theory:`<div class="theory-block"><h3>🔁 4.1 — Pourquoi les boucles existent</h3><p>Imagine devoir afficher les nombres de 1 à 1000 en copiant-collant <code>console.log()</code> mille fois. Ridicule, non ? Les boucles résolvent exactement ce problème : elles répètent un même bloc de code autant de fois que nécessaire, en changeant à chaque tour une ou plusieurs valeurs. Dès que tu copies-colles une ligne de code plus de deux fois en changeant juste un chiffre, c'est le signal qu'une boucle devrait prendre le relais.</p></div>

<div class="theory-block"><h3>🔢 4.2 — La boucle for, anatomie complète</h3><p>La boucle <code style="color:#f7c948">for</code> regroupe tout ce dont une répétition a besoin sur une seule ligne, en trois parties séparées par des points-virgules : <b>l'initialisation</b> (une variable de départ, en général <code>i</code>), <b>la condition</b> (tant qu'elle est vraie, la boucle continue), et <b>l'incrément</b> (ce qui change à chaque tour).</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="cmt">// initialisation ; condition ; incrément</span>
<span class="kw">for</span> (<span class="kw">let</span> <span class="var">i</span> = <span class="num">1</span>; i <= <span class="num">5</span>; i++) {
  <span class="fn">console</span>.<span class="fn">log</span>(<span class="str">\`Jour \${i} du bootcamp\`</span>);
}
<span class="cmt">// Affiche : Jour 1, Jour 2, Jour 3, Jour 4, Jour 5 du bootcamp</span>

<span class="cmt">// On peut aussi compter à rebours, avec un pas différent</span>
<span class="kw">for</span> (<span class="kw">let</span> <span class="var">i</span> = <span class="num">10</span>; i > <span class="num">0</span>; i -= <span class="num">2</span>) {
  <span class="fn">console</span>.<span class="fn">log</span>(i); <span class="cmt">// 10, 8, 6, 4, 2</span>
}</div></div>
<div class="tip-box"><strong>⚠️ Piège fréquent :</strong> Utiliser <code><=</code> au lieu de <code><</code> (ou l'inverse) change le nombre total de tours. <code>for (let i=0; i<5; i++)</code> tourne exactement 5 fois (i vaut 0, 1, 2, 3, 4), alors que <code>i<=5</code> en ferait 6.</div></div>

<div class="theory-block"><h3>⏳ 4.3 — La boucle while : quand tu ne connais pas le nombre de tours à l'avance</h3><p>La boucle <code style="color:#f7c948">while</code> ("tant que") continue tant que sa condition reste vraie. Contrairement au <code>for</code>, rien ne t'oblige à faire évoluer une variable — c'est entièrement à toi de le faire <b>à l'intérieur</b> du bloc. Si tu oublies, la condition reste vraie pour toujours : c'est une <b>boucle infinie</b>, qui plante ou fige ton programme.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">let</span> <span class="var">compteur</span> = <span class="num">0</span>;

<span class="kw">while</span> (compteur < <span class="num">3</span>) {
  <span class="fn">console</span>.<span class="fn">log</span>(<span class="str">\`Compteur : \${compteur}\`</span>);
  compteur++; <span class="cmt">// indispensable ! sinon boucle infinie</span>
}
<span class="cmt">// Affiche : Compteur : 0, Compteur : 1, Compteur : 2</span></div></div>
<div class="tip-box"><strong>💡 Astuce :</strong> Si ta console se fige, tu as probablement écrit une boucle infinie. Vérifie toujours que la variable testée dans la condition change bien à l'intérieur du bloc.</div></div>

<div class="theory-block"><h3>⏭️ 4.4 — Contrôler le flux avec break et continue</h3><p><code style="color:#f7c948">break</code> arrête <b>immédiatement et complètement</b> la boucle, même s'il restait des tours à faire. <code style="color:#f7c948">continue</code> est plus subtil : il n'arrête pas la boucle, il saute juste le <b>reste du bloc pour ce tour précis</b> et passe directement au tour suivant.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="cmt">// break : on arrête dès qu'on trouve le premier multiple de 7</span>
<span class="kw">for</span> (<span class="kw">let</span> <span class="var">i</span> = <span class="num">1</span>; i <= <span class="num">100</span>; i++) {
  <span class="kw">if</span> (i % <span class="num">7</span> === <span class="num">0</span>) {
    <span class="fn">console</span>.<span class="fn">log</span>(<span class="str">\`Trouvé : \${i}\`</span>);
    <span class="kw">break</span>;
  }
}

<span class="cmt">// continue : on saute les nombres pairs, on n'affiche que les impairs</span>
<span class="kw">for</span> (<span class="kw">let</span> <span class="var">i</span> = <span class="num">1</span>; i <= <span class="num">10</span>; i++) {
  <span class="kw">if</span> (i % <span class="num">2</span> === <span class="num">0</span>) <span class="kw">continue</span>;
  <span class="fn">console</span>.<span class="fn">log</span>(i); <span class="cmt">// 1, 3, 5, 7, 9</span>
}</div></div></div>

<div class="theory-block"><h3>👀 4.5 — Un aperçu de forEach, la boucle des tableaux</h3><p>Tu croiseras aussi <code style="color:#f7c948">forEach</code>, une méthode réservée aux tableaux qui exécute une fonction pour chaque élément, sans avoir besoin de gérer un index manuellement — détaillée au Jour 6.</p>
<div class="tip-box"><strong>💡 Quand utiliser quoi :</strong> <code>for</code> classique pour un contrôle total ; <code>while</code> quand le nombre de tours est inconnu à l'avance ; <code>forEach</code> plus tard pour parcourir un tableau simplement.</div></div>`,
     starter:`// Jour 4 — Boucles
// Table de multiplication du 7
for (let i = 1; i <= 10; i++) {
  console.log(\`7 x \${i} = \${7 * i}\`);
}

// Compte à rebours
for (let i = 10; i >= 0; i--) {
  if (i === 0) {
    console.log("Décollage ! 🚀");
  } else {
    console.log(i);
  }
}`,
     quiz:[{q:"Combien de fois s'exécute : for(let i=0; i<5; i++) ?",opts:["4","5","6","infini"],ans:1},
           {q:"i++ équivaut à ?",opts:["i = i - 1","i = i + 1","i = 0","i * i"],ans:1},
           {q:"break dans une boucle...",opts:["Continue la boucle","Recommence la boucle","Stoppe la boucle","Affiche un résultat"],ans:2}]},

    {d:5,title:"Fonctions",sub:"function, arrow functions, paramètres",level:"easy",
     theory:`<div class="theory-block"><h3>🛠️ 5.1 — Pourquoi des fonctions</h3><p>Une fonction est un bloc de code réutilisable : tu l'écris une fois, tu l'appelles autant de fois que tu veux, avec des valeurs différentes à chaque fois. Pense-la comme une recette de cuisine — elle décrit une suite d'étapes générique, et à chaque fois que tu l'exécutes avec des ingrédients différents (les <b>paramètres</b>), tu obtiens un plat différent.</p></div>

<div class="theory-block"><h3>📐 5.2 — La déclaration classique : function</h3><p>La syntaxe historique utilise le mot-clé <code style="color:#f7c948">function</code>, suivi d'un nom, de parenthèses contenant les paramètres, puis d'un bloc <code>{ }</code>. À l'intérieur, <code style="color:#f7c948">return</code> renvoie une valeur à l'endroit où la fonction a été appelée — et arrête immédiatement l'exécution de la fonction.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">function</span> <span class="fn">saluer</span>(<span class="var">prenom</span>) {
  <span class="kw">return</span> <span class="str">\`Salut \${prenom} !\`</span>;
}

<span class="fn">console</span>.<span class="fn">log</span>(<span class="fn">saluer</span>(<span class="str">"Nerija"</span>)); <span class="cmt">// "Salut Nerija !"</span>

<span class="cmt">// Une fonction sans return renvoie undefined, pas une erreur</span>
<span class="kw">function</span> <span class="fn">direBonjour</span>() {
  <span class="fn">console</span>.<span class="fn">log</span>(<span class="str">"Bonjour !"</span>);
}
<span class="kw">const</span> <span class="var">resultat</span> = <span class="fn">direBonjour</span>();
<span class="fn">console</span>.<span class="fn">log</span>(resultat); <span class="cmt">// undefined, car aucun "return" n'a été écrit</span></div></div>
<div class="tip-box"><strong>💡 À retenir :</strong> <code>console.log()</code> à l'intérieur d'une fonction <b>affiche</b> une valeur, mais ne la <b>renvoie</b> pas à l'extérieur. Seul <code>return</code> permet de récupérer une valeur pour l'utiliser ensuite.</div></div>

<div class="theory-block"><h3>🏹 5.3 — Les arrow functions, la syntaxe moderne</h3><p>Depuis 2015, une syntaxe plus courte existe : les <b>arrow functions</b>, écrites avec <code style="color:#f7c948">=></code>. Deux formes : <b>corps expression</b> (une seule ligne, sans accolades) où le résultat est <b>automatiquement</b> renvoyé, sans écrire <code>return</code> ; et <b>corps bloc</b> (avec accolades) où il faut alors écrire <code>return</code> explicitement.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="cmt">// Corps expression : return implicite, pas d'accolades</span>
<span class="kw">const</span> <span class="fn">additionner</span> = (<span class="var">a</span>, <span class="var">b</span>) => a + b;
<span class="fn">console</span>.<span class="fn">log</span>(<span class="fn">additionner</span>(<span class="num">5</span>, <span class="num">3</span>)); <span class="cmt">// 8</span>

<span class="cmt">// Un seul paramètre : les parenthèses sont facultatives</span>
<span class="kw">const</span> <span class="fn">doubler</span> = <span class="var">x</span> => x * <span class="num">2</span>;
<span class="fn">console</span>.<span class="fn">log</span>(<span class="fn">doubler</span>(<span class="num">21</span>)); <span class="cmt">// 42</span>

<span class="cmt">// Corps bloc : return devient obligatoire</span>
<span class="kw">const</span> <span class="fn">saluer</span> = (<span class="var">prenom</span>) => {
  <span class="kw">const</span> <span class="var">message</span> = <span class="str">\`Salut \${prenom} !\`</span>;
  <span class="kw">return</span> message;
};</div></div>
<div class="tip-box"><strong>⚠️ Piège fréquent :</strong> Dès que tu ouvres des accolades après la flèche, JS ne renvoie plus rien automatiquement — il faut écrire <code>return</code>.</div></div>

<div class="theory-block"><h3>⚙️ 5.4 — Valeurs par défaut : des paramètres qui savent se débrouiller seuls</h3><p>Tu peux donner une valeur de secours à un paramètre, utilisée uniquement si aucun argument n'est fourni à l'appel : <code style="color:#f7c948">nomDuParametre = valeurParDefaut</code> directement dans la liste des paramètres.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="fn">saluer</span> = (<span class="var">prenom</span>, <span class="var">langue</span> = <span class="str">"JS"</span>) => {
  <span class="kw">return</span> <span class="str">\`Bonjour \${prenom}, tu apprends \${langue} !\`</span>;
};

<span class="fn">console</span>.<span class="fn">log</span>(<span class="fn">saluer</span>(<span class="str">"Nerija"</span>));            <span class="cmt">// "...tu apprends JS !" (valeur par défaut)</span>
<span class="fn">console</span>.<span class="fn">log</span>(<span class="fn">saluer</span>(<span class="str">"Flora"</span>, <span class="str">"Python"</span>)); <span class="cmt">// "...tu apprends Python !" (écrase le défaut)</span></div></div></div>

<div class="theory-block"><h3>🎯 5.5 — function ou arrow function, comment choisir</h3><p>En pratique, les arrow functions sont devenues le choix par défaut pour leur concision. La déclaration <code>function</code> classique garde un avantage à connaître : elle est "hissée" (<i>hoisted</i>), donc tu peux l'appeler avant sa définition dans le code — et elle gère différemment le mot-clé <code>this</code>, un sujet approfondi au Jour 7.</p>
<div class="tip-box"><strong>💡 Astuce :</strong> Une fonction peut aussi être passée comme argument à une autre fonction — une idée que tu utiliseras énormément avec <code>map</code> ou <code>filter</code> dès la Semaine 2.</div></div>`,
     starter:`// Jour 5 — Fonctions
const saluer = (prenom, langue = "JS") => {
  return \`Bonjour \${prenom}, tu apprends \${langue} !\`;
};

console.log(saluer("Nerija"));
console.log(saluer("Flora", "Python"));

// Crée une fonction qui calcule le carré d'un nombre
const carre = (n) => n ** 2;
console.log(\`Le carré de 5 est \${carre(5)}\`);`,
     quiz:[{q:"Que retourne une fonction sans return ?",opts:["0","null","undefined","erreur"],ans:2},
           {q:"Syntaxe arrow function correcte ?",opts:["function => x { }","const f = x => x * 2","(x) function { }","def f(x):"],ans:1},
           {q:"Paramètre par défaut : function f(x=10) — si appelé f() ?",opts:["Erreur","undefined","null","10"],ans:3}]},

    {d:6,title:"Arrays (Tableaux)",sub:"Créer, accéder, manipuler des tableaux",level:"easy",
     theory:`<div class="theory-block"><h3>📚 6.1 — Qu'est-ce qu'un tableau</h3><p>Un tableau (<i>array</i>) est une liste ordonnée de valeurs, rangées les unes après les autres. Imagine une étagère numérotée : chaque case a une position fixe, et tu peux y ranger n'importe quoi. Un tableau se crée avec des crochets <code style="color:#f7c948">[ ]</code>, les valeurs séparées par des virgules.</p></div>

<div class="theory-block"><h3>🔢 6.2 — L'index : la règle qui surprend tout le monde au début</h3><p>Chaque élément a une position, appelée <b>index</b>. Règle absolue : <b>l'index commence à 0</b>, pas à 1. La propriété <code style="color:#f7c948">.length</code> (pas une méthode, pas de parenthèses) donne le nombre d'éléments — et comme l'index commence à 0, le <b>dernier</b> élément est toujours à l'index <code>length - 1</code>.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">cours</span> = [<span class="str">"JS"</span>, <span class="str">"React"</span>, <span class="str">"Node.js"</span>];

<span class="fn">console</span>.<span class="fn">log</span>(cours[<span class="num">0</span>]); <span class="cmt">// "JS"      → premier élément</span>
<span class="fn">console</span>.<span class="fn">log</span>(cours[<span class="num">3</span>]); <span class="cmt">// undefined → il n'y a pas de 4ᵉ élément !</span>

<span class="fn">console</span>.<span class="fn">log</span>(cours.<span class="fn">length</span>); <span class="cmt">// 3</span>
<span class="fn">console</span>.<span class="fn">log</span>(cours[cours.length - <span class="num">1</span>]); <span class="cmt">// "Node.js" → toujours le dernier élément</span></div></div>
<div class="tip-box"><strong>⚠️ Piège fréquent :</strong> Demander <code>cours[cours.length]</code> (sans le <code>-1</code>) renvoie toujours <code>undefined</code>, jamais une erreur — un silence traître.</div></div>

<div class="theory-block"><h3>➕ 6.3 — Ajouter et retirer des éléments</h3><p>Contrairement aux strings, un tableau créé avec <code>const</code> reste <b>modifiable</b> — <code>const</code> empêche seulement de réassigner la variable à un tableau différent, pas de changer son contenu. <code style="color:#f7c948">.push()</code> ajoute <b>à la fin</b> ; <code style="color:#f7c948">.pop()</code> retire le <b>dernier</b> élément ; <code style="color:#f7c948">.unshift()</code> ajoute <b>au début</b> ; <code style="color:#f7c948">.shift()</code> retire le <b>premier</b>.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">cours</span> = [<span class="str">"JS"</span>, <span class="str">"React"</span>, <span class="str">"Node.js"</span>];

cours.<span class="fn">push</span>(<span class="str">"TypeScript"</span>); <span class="cmt">// ["JS","React","Node.js","TypeScript"]</span>
cours.<span class="fn">pop</span>();                     <span class="cmt">// retire "TypeScript"</span>
cours.<span class="fn">unshift</span>(<span class="str">"HTML"</span>);      <span class="cmt">// ["HTML","JS","React","Node.js"]</span>
<span class="kw">const</span> <span class="var">retire</span> = cours.<span class="fn">shift</span>();      <span class="cmt">// retire "HTML", et le renvoie</span>

<span class="fn">console</span>.<span class="fn">log</span>(retire); <span class="cmt">// "HTML"</span>
<span class="fn">console</span>.<span class="fn">log</span>(cours);  <span class="cmt">// ["JS","React","Node.js"]</span></div></div></div>

<div class="theory-block"><h3>🔄 6.4 — Parcourir un tableau avec forEach</h3><p><code style="color:#f7c948">.forEach()</code> exécute directement une fonction pour <b>chaque</b> élément du tableau. Cette fonction reçoit l'élément courant en premier paramètre, et son index en second paramètre.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">cours</span> = [<span class="str">"JS"</span>, <span class="str">"React"</span>, <span class="str">"Node.js"</span>];

cours.<span class="fn">forEach</span>((<span class="var">c</span>, <span class="var">index</span>) => {
  <span class="fn">console</span>.<span class="fn">log</span>(<span class="str">\`\${index + 1}. \${c}\`</span>);
});
<span class="cmt">// Affiche : 1. JS   2. React   3. Node.js</span></div></div>
<div class="tip-box"><strong>💡 Astuce :</strong> <code>forEach</code> ne peut pas être interrompu avec <code>break</code> — il parcourt <b>toujours</b> tout le tableau.</div></div>

<div class="theory-block"><h3>🧰 6.5 — La boîte à outils des méthodes de tableau</h3><p><code>.indexOf(valeur)</code> renvoie la position d'une valeur (ou <code>-1</code> si absente) ; <code>.includes(valeur)</code> renvoie directement <code>true</code>/<code>false</code> ; <code>.join(", ")</code> transforme le tableau en string ; <code>.reverse()</code> inverse l'ordre en place ; <code>.splice(index, nombre)</code> retire des éléments à une position précise. Tu approfondiras <code>map</code>, <code>filter</code>, <code>reduce</code> dès la Semaine 2.</p></div>`,
     starter:`// Jour 6 — Tableaux
const langages = ["JavaScript", "Python", "Java", "C++"];

console.log("Nombre de langages :", langages.length);
console.log("Premier :", langages[0]);
console.log("Dernier :", langages[langages.length - 1]);

langages.push("TypeScript");
console.log("Après ajout :", langages);

langages.forEach((lang, index) => {
  console.log(\`\${index + 1}. \${lang}\`);
});`,
     quiz:[{q:"Quel index a le premier élément d'un tableau ?",opts:["-1","0","1","null"],ans:1},
           {q:"push() fait quoi ?",opts:["Supprime le premier","Ajoute à la fin","Supprime à la fin","Ajoute au début"],ans:1},
           {q:"['a','b','c'].length vaut ?",opts:["2","3","4","0"],ans:1}]},

    {d:7,title:"Objets",sub:"Créer et utiliser des objets JS",level:"easy",
     theory:`<div class="theory-block"><h3>🏗️ 7.1 — Qu'est-ce qu'un objet</h3><p>Un tableau range des valeurs par position. Un objet range des valeurs par <b>nom</b>, sous forme de paires <b>clé : valeur</b>. Pense à une fiche d'identité — "nom", "âge", "pays" sont des clés, chacune associée à une valeur. Un objet se crée avec des accolades <code style="color:#f7c948">{ }</code>, chaque paire séparée par une virgule.</p></div>

<div class="theory-block"><h3>🔑 7.2 — Créer un objet et accéder à ses propriétés</h3><p>Deux syntaxes : la <b>notation pointée</b> <code style="color:#f7c948">objet.propriete</code> (la plus courante), et la <b>notation par crochets</b> <code style="color:#f7c948">objet["propriete"]</code>, obligatoire quand le nom de la clé vient d'une variable évaluée dynamiquement.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">etudiant</span> = {
  nom: <span class="str">"Nerija"</span>,
  age: <span class="num">18</span>,
  pays: <span class="str">"Côte d'Ivoire"</span>
};

<span class="fn">console</span>.<span class="fn">log</span>(etudiant.nom);       <span class="cmt">// "Nerija"      → notation pointée</span>
<span class="fn">console</span>.<span class="fn">log</span>(etudiant[<span class="str">"pays"</span>]);  <span class="cmt">// "Côte d'Ivoire" → notation par crochets</span>

<span class="cmt">// Utile quand la clé vient d'une variable</span>
<span class="kw">const</span> <span class="var">cle</span> = <span class="str">"age"</span>;
<span class="fn">console</span>.<span class="fn">log</span>(etudiant[cle]); <span class="cmt">// 18 → etudiant.cle donnerait undefined !</span>

<span class="cmt">// Ajouter ou modifier une propriété après coup</span>
etudiant.ville = <span class="str">"Abidjan"</span>; <span class="cmt">// nouvelle propriété</span>
etudiant.age = <span class="num">19</span>;          <span class="cmt">// modification, même avec const !</span></div></div>
<div class="tip-box"><strong>⚠️ Piège fréquent :</strong> <code>etudiant.cle</code> et <code>etudiant[cle]</code> ne sont pas équivalents. Les crochets évaluent ce qu'il y a dedans ; le point le prend au pied de la lettre.</div></div>

<div class="theory-block"><h3>🧩 7.3 — Des objets qui contiennent des tableaux, et vice-versa</h3><p>Une propriété peut être n'importe quel type de valeur — y compris un tableau, ou un autre objet. C'est ce qui rend les objets si puissants pour modéliser des structures riches.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">profil</span> = {
  nom: <span class="str">"Nerija"</span>,
  skills: [<span class="str">"HTML"</span>, <span class="str">"CSS"</span>, <span class="str">"JS"</span>],
  adresse: { ville: <span class="str">"Abidjan"</span>, pays: <span class="str">"CI"</span> }
};

<span class="fn">console</span>.<span class="fn">log</span>(profil.skills[<span class="num">0</span>]);      <span class="cmt">// "HTML" → propriété puis index</span>
<span class="fn">console</span>.<span class="fn">log</span>(profil.adresse.ville);   <span class="cmt">// "Abidjan" → deux propriétés chaînées</span></div></div></div>

<div class="theory-block"><h3>⚡ 7.4 — Des méthodes dans un objet, et le mot-clé this</h3><p>Une propriété dont la valeur est une fonction s'appelle une <b>méthode</b>. À l'intérieur, le mot-clé <code style="color:#f7c948">this</code> fait référence à <b>l'objet lui-même</b> — ce qui permet à une méthode de lire les autres propriétés du même objet.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">etudiant</span> = {
  nom: <span class="str">"Nerija"</span>,
  pays: <span class="str">"Côte d'Ivoire"</span>,
  <span class="fn">sePresenter</span>() {
    <span class="kw">return</span> <span class="str">\`Je suis \${this.nom} de \${this.pays}\`</span>; <span class="cmt">// this = etudiant</span>
  }
};

<span class="fn">console</span>.<span class="fn">log</span>(etudiant.<span class="fn">sePresenter</span>()); <span class="cmt">// "Je suis Nerija de Côte d'Ivoire"</span></div></div>
<div class="tip-box"><strong>💡 À retenir :</strong> Une arrow function utilisée comme méthode d'objet ne capture <b>pas</b> le <code>this</code> attendu — utilise la syntaxe de méthode ci-dessus dès que tu as besoin de <code>this</code>.</div></div>

<div class="theory-block"><h3>📤 7.5 — La destructuration : extraire plusieurs propriétés d'un coup</h3><p>La <b>destructuration</b> extrait plusieurs propriétés en une seule instruction, avec une syntaxe qui imite la forme de l'objet.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">profil</span> = { nom: <span class="str">"Nerija"</span>, universite: <span class="str">"Licence Info"</span>, annee: <span class="num">1</span> };

<span class="cmt">// Avec destructuration : une seule ligne</span>
<span class="kw">const</span> { nom, universite } = profil;
<span class="fn">console</span>.<span class="fn">log</span>(<span class="str">\`\${nom} — \${universite}\`</span>); <span class="cmt">// "Nerija — Licence Info"</span>

<span class="cmt">// Une clé absente donne undefined, pas d'erreur</span>
<span class="kw">const</span> { a } = { a: <span class="num">1</span>, b: <span class="num">2</span> };
<span class="fn">console</span>.<span class="fn">log</span>(a); <span class="cmt">// 1</span></div></div>
<div class="tip-box"><strong>💡 Astuce :</strong> La destructuration fonctionne aussi directement dans les paramètres d'une fonction — <code>function afficher({ nom, age }) { ... }</code>. Tu la retrouveras énormément avec React plus tard.</div></div>`,
     starter:`// Jour 7 — Objets
const profil = {
  nom: "Nerija",
  universite: "Licence Informatique",
  annee: 1,
  skills: ["HTML", "CSS", "JS en cours..."],
  progression: 7/30,
};

console.log(\`Étudiant : \${profil.nom}\`);
console.log(\`Filière : \${profil.universite}\`);
console.log(\`Skills : \${profil.skills.join(", ")}\`);

const { nom, universite } = profil; // Destructuration
console.log(\`\${nom} — \${universite}\`);`,
     quiz:[{q:"Comment accéder à obj.prenom ?",opts:["obj[prenom]","obj->prenom","obj.prenom","obj::prenom"],ans:2},
           {q:"this dans une méthode d'objet désigne ?",opts:["window","null","L'objet lui-même","undefined"],ans:2},
           {q:"Destructuration : const {a} = {a:1,b:2} — a vaut ?",opts:["undefined","0","1","2"],ans:2}]}
  ]},
  {week:"Semaine 2 — Intermédiaire",days:[
    {d:8,title:"Méthodes d'Arrays avancées",sub:"map, filter, reduce, find",level:"med",
     theory:`<div class="theory-block"><h3>🧠 8.1 — Penser "transformation" plutôt que "boucle"</h3><p>Jusqu'ici, pour manipuler un tableau, tu écrivais sans doute une boucle <code>for</code>. Ça fonctionne, mais tu gères toute la mécanique de la boucle en plus de la vraie question métier. Les méthodes fonctionnelles — <b>map</b>, <b>filter</b>, <b>reduce</b>, <b>find</b> — inversent la logique : tu ne décris plus <i>comment</i> parcourir le tableau, tu décris <i>ce que tu veux obtenir</i>. Aucune de ces méthodes ne modifie le tableau d'origine — elles retournent toujours un <b>nouveau</b> résultat. C'est le principe d'<b>immutabilité</b>, central en JS moderne et omniprésent en React.</p></div>

<div class="theory-block"><h3>🔁 8.2 — map() : transformer chaque élément, un par un</h3><p><code>map()</code> parcourt le tableau et applique une fonction à <b>chaque</b> élément, en construisant un nouveau tableau de la <b>même longueur</b>.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">etudiants</span> = [
  { nom: <span class="str">"Nerija"</span>, note: <span class="num">17</span> },
  { nom: <span class="str">"Flora"</span>, note: <span class="num">14</span> },
  { nom: <span class="str">"Kofi"</span>, note: <span class="num">9</span> }
];

<span class="kw">const</span> <span class="var">noms</span> = etudiants.<span class="fn">map</span>(<span class="var">e</span> => e.nom);
<span class="fn">console</span>.<span class="fn">log</span>(noms); <span class="cmt">// ["Nerija", "Flora", "Kofi"] — toujours 3 éléments</span></div></div></div>

<div class="theory-block"><h3>🧹 8.3 — filter() : garder seulement ce qui passe le test</h3><p><code>filter()</code> pose une question booléenne à chaque élément, et construit un nouveau tableau avec uniquement les éléments pour lesquels la fonction renvoie <code>true</code>.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">admis</span> = etudiants.<span class="fn">filter</span>(<span class="var">e</span> => e.note >= <span class="num">10</span>);
<span class="fn">console</span>.<span class="fn">log</span>(admis.length); <span class="cmt">// 2 — Nerija et Flora seulement</span></div></div>
<div class="tip-box"><strong>💡 Piège fréquent :</strong> la fonction passée à filter() doit renvoyer un booléen, pas juste une valeur quelconque.</div></div>

<div class="theory-block"><h3>⚙️ 8.4 — reduce() : la méthode la plus puissante</h3><p>reduce() renvoie <b>une seule valeur</b>, obtenue en combinant tous les éléments via un accumulateur.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">notes</span> = [<span class="num">17</span>, <span class="num">14</span>, <span class="num">9</span>, <span class="num">12</span>];
<span class="kw">const</span> <span class="var">total</span> = notes.<span class="fn">reduce</span>((<span class="var">acc</span>, <span class="var">n</span>) => acc + n, <span class="num">0</span>);
<span class="kw">const</span> <span class="var">moyenne</span> = total / notes.length;
<span class="fn">console</span>.<span class="fn">log</span>(moyenne); <span class="cmt">// 13</span></div></div>
<div class="tip-box"><strong>💡 Piège classique :</strong> oublier la valeur initiale — sans elle, reduce() plante sur un tableau vide.</div></div>

<div class="theory-block"><h3>🔎 8.5 — find(), some() et every()</h3><p><code>find()</code> renvoie le <b>premier</b> élément qui passe le test. <code>some()</code>/<code>every()</code> renvoient un booléen : "au moins un ?" / "tous ?"</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">redoublant</span> = etudiants.<span class="fn">find</span>(<span class="var">e</span> => e.note < <span class="num">10</span>);
<span class="fn">console</span>.<span class="fn">log</span>(redoublant.nom); <span class="cmt">// "Kofi"</span></div></div></div>

<div class="theory-block"><h3>🔗 8.6 — Chaîner les méthodes : construire un pipeline</h3><p>Comme chaque méthode retourne un nouveau tableau, tu peux les enchaîner directement.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">resultat</span> = etudiants
  .<span class="fn">filter</span>(<span class="var">e</span> => e.note >= <span class="num">10</span>)
  .<span class="fn">map</span>(<span class="var">e</span> => e.nom.<span class="fn">toUpperCase</span>());
<span class="fn">console</span>.<span class="fn">log</span>(resultat);</div></div>
<div class="tip-box"><strong>💡 L'ordre compte :</strong> filtre d'abord, transforme ensuite — sinon tu transformes des éléments que tu vas jeter juste après.</div></div>`,
     starter:`// Jour 8 — map, filter, reduce
const etudiants = [
  { nom: "Nerija", note: 17 },
  { nom: "Flora", note: 14 },
  { nom: "Kofi", note: 9 },
  { nom: "Amara", note: 12 },
];

// 1. Noms de tous les étudiants
const noms = etudiants.map(e => e.nom);
console.log("Noms :", noms);

// 2. Étudiants admis (note >= 10)
const admis = etudiants.filter(e => e.note >= 10);
console.log("Admis :", admis.map(e => e.nom));

// 3. Moyenne de la classe
const moyenne = etudiants.reduce((acc, e) => acc + e.note, 0) / etudiants.length;
console.log(\`Moyenne : \${moyenne}/20\`);`,
     quiz:[{q:"map() retourne ?",opts:["La même taille de tableau","Un tableau plus petit","undefined","Un nombre"],ans:0},
           {q:"filter() retourne ?",opts:["Toujours le même tableau","Un sous-tableau","Une valeur unique","null"],ans:1},
           {q:"reduce() est utile pour ?",opts:["Ajouter des éléments","Trier un tableau","Calculer une valeur unique","Trouver un index"],ans:2}]},
    {d:9,title:"DOM — Manipuler la page",sub:"getElementById, querySelector, events",level:"med",
     theory:`<div class="theory-block"><h3>🌐 9.1 — Le DOM : la page vue par JavaScript</h3><p>Quand un navigateur charge une page HTML, il construit un arbre d'objets en mémoire — le <b>DOM</b> (Document Object Model). C'est la porte d'entrée qui permet à JavaScript de lire et modifier une page <b>déjà affichée</b> : changer un texte, ajouter une classe CSS, réagir à un clic — sans jamais recharger la page.</p>
<p>Ici, l'environnement simule le DOM avec un simple objet JS pour que tu voies le résultat dans la console. Mais la syntaxe que tu apprends est exactement celle d'un vrai navigateur.</p></div>

<div class="theory-block"><h3>🎯 9.2 — Sélectionner un élément</h3><p><code>document.getElementById("id")</code> cible l'élément unique portant cet id. <code>document.querySelector("...")</code> accepte n'importe quel <b>sélecteur CSS</b> et renvoie le <b>premier</b> élément trouvé. <code>document.querySelectorAll("...")</code> renvoie <b>tous</b> les éléments correspondants.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">titre</span> = document.<span class="fn">getElementById</span>(<span class="str">"titre"</span>);
<span class="kw">const</span> <span class="var">bouton</span> = document.<span class="fn">querySelector</span>(<span class="str">".mon-bouton"</span>);
<span class="kw">const</span> <span class="var">cartes</span> = document.<span class="fn">querySelectorAll</span>(<span class="str">".carte"</span>);

cartes.<span class="fn">forEach</span>(<span class="var">carte</span> => {
  <span class="fn">console</span>.<span class="fn">log</span>(carte.textContent);
});</div></div></div>

<div class="theory-block"><h3>✏️ 9.3 — Modifier ce qui est affiché</h3><p><code>textContent</code> lit ou écrit le texte brut. <code>innerHTML</code> interprète le contenu comme du HTML — pratique, mais dangereux avec une saisie utilisateur non filtrée (risque XSS). La propriété <code>style</code> modifie le CSS en ligne.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content">titre.textContent = <span class="str">"Nouveau titre !"</span>;
titre.style.color = <span class="str">"#f7c948"</span>;
titre.classList.<span class="fn">add</span>(<span class="str">"actif"</span>);</div></div>
<div class="tip-box"><strong>💡 Règle de sécurité :</strong> préfère toujours <code>textContent</code> à <code>innerHTML</code> pour du texte simple.</div></div>

<div class="theory-block"><h3>👂 9.4 — Écouter les événements</h3><p><code>addEventListener("evenement", fonction)</code> attache un écouteur : quand l'événement se produit, la fonction s'exécute automatiquement.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content">bouton.<span class="fn">addEventListener</span>(<span class="str">"click"</span>, () => {
  <span class="fn">console</span>.<span class="fn">log</span>(<span class="str">"Bouton cliqué !"</span>);
});</div></div>
<p>Événements courants : <code>click</code>, <code>input</code>, <code>submit</code>, <code>keydown</code>, <code>mouseover</code>, <code>load</code>.</p>
<div class="tip-box"><strong>💡 Piège classique :</strong> pour un formulaire, écouter <code>submit</code> et appeler <code>event.preventDefault()</code> — sinon le navigateur recharge la page.</div></div>`,
     starter:`// Jour 9 — DOM (simulation)
// En vrai navigateur tu écrirais :
// document.getElementById("titre").textContent = "Hello";

// Ici, simulation avec un objet
const fakeDom = {
  elements: {},
  getElementById(id) {
    if (!this.elements[id]) this.elements[id] = { text: "", style: {} };
    return {
      set textContent(val) { fakeDom.elements[id].text = val; console.log(\`DOM [\${id}]: "\${val}"\`); },
      style: { set color(v) { console.log(\`DOM [\${id}] color: \${v}\`); } }
    };
  }
};

const titre = fakeDom.getElementById("titre");
titre.textContent = "Bienvenue Nerija !";
titre.style.color = "#f7c948";

console.log("--- Exercice DOM terminé ---");`,
     quiz:[{q:"querySelector('#id') sélectionne par ?",opts:["classe","nom de tag","ID","attribut data"],ans:2},
           {q:"Pour écouter un clic sur un élément ?",opts:["element.onClick()","element.addEventListener('click', fn)","element.click = fn","element.on('click', fn)"],ans:1},
           {q:"textContent modifie quoi ?",opts:["Le style CSS","Le texte affiché","L'attribut id","La position"],ans:1}]},
    {d:10,title:"Scope & Closures",sub:"Portée des variables, closures",level:"med",
     theory:`<div class="theory-block"><h3>🗺️ 10.1 — Le scope : qui peut voir quelle variable</h3><p>Le <b>scope</b> d'une variable est la zone du code où elle existe. JS a trois niveaux : le <b>scope global</b> (accessible partout), le <b>scope de fonction</b>, et le <b>scope de bloc</b> (accolades <code>{ }</code>).</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">pays</span> = <span class="str">"Côte d'Ivoire"</span>; <span class="cmt">// scope global</span>

<span class="kw">function</span> <span class="fn">presenter</span>() {
  <span class="kw">const</span> <span class="var">ville</span> = <span class="str">"Abidjan"</span>; <span class="cmt">// scope de fonction</span>
  <span class="fn">console</span>.<span class="fn">log</span>(pays, ville); <span class="cmt">// ✅ les deux visibles ici</span>
}
<span class="fn">presenter</span>();
<span class="fn">console</span>.<span class="fn">log</span>(ville); <span class="cmt">// ❌ ReferenceError</span></div></div></div>

<div class="theory-block"><h3>⚠️ 10.2 — var, let, const : trois portées différentes</h3><p><code>var</code> ignore les blocs <code>{ }</code> et n'a qu'une portée de <b>fonction</b> — une variable var déclarée dans un if "fuit" en dehors du bloc.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">if</span> (<span class="kw">true</span>) {
  <span class="kw">var</span> <span class="var">fuite</span> = <span class="str">"je m'échappe"</span>;
  <span class="kw">let</span> <span class="var">contenu</span> = <span class="str">"je reste ici"</span>;
}
<span class="fn">console</span>.<span class="fn">log</span>(fuite);   <span class="cmt">// ⚠️ "je m'échappe"</span>
<span class="fn">console</span>.<span class="fn">log</span>(contenu); <span class="cmt">// ❌ ReferenceError</span></div></div></div>

<div class="theory-block"><h3>🎁 10.3 — Les closures : une fonction qui se souvient de son environnement</h3><p>Une <b>closure</b> se produit quand une fonction interne capture les variables du scope où elle a été créée, et continue d'y avoir accès même après.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">function</span> <span class="fn">compteur</span>() {
  <span class="kw">let</span> <span class="var">count</span> = <span class="num">0</span>;
  <span class="kw">return</span> () => ++count;
}
<span class="kw">const</span> <span class="var">inc</span> = <span class="fn">compteur</span>();
<span class="fn">console</span>.<span class="fn">log</span>(<span class="fn">inc</span>()); <span class="cmt">// 1</span>
<span class="fn">console</span>.<span class="fn">log</span>(<span class="fn">inc</span>()); <span class="cmt">// 2 — se souvient entre les appels</span></div></div>
<p>Chaque appel de compteur() crée un <b>nouveau</b> count indépendant — c'est exactement le mécanisme de l'exercice du jour.</p></div>

<div class="theory-block"><h3>🔒 10.4 — À quoi servent vraiment les closures</h3><p>Elles résolvent un vrai problème : créer des <b>variables privées</b> en JS. Elles sont la base de nombreux patterns : gestion d'état, memoization, debounce.</p>
<div class="tip-box"><strong>💡 Piège à connaître :</strong> une closure garde la variable vivante en mémoire tant qu'une fonction peut encore y accéder.</div></div>`,
     starter:`// Jour 10 — Scope & Closures
function creerCompteur(start = 0) {
  let count = start;
  return {
    incrementer: () => ++count,
    decrementer: () => --count,
    valeur: () => count
  };
}

const c = creerCompteur(10);
console.log(c.valeur());      // 10
console.log(c.incrementer()); // 11
console.log(c.incrementer()); // 12
console.log(c.decrementer()); // 11
console.log(c.valeur());      // 11`,
     quiz:[{q:"Une variable let dans une fonction est accessible ?",opts:["Partout","Dans la fonction seulement","Dans le bloc seulement","Nulle part"],ans:1},
           {q:"Une closure...",opts:["Ferme le programme","Mémorise son scope parent","Supprime une variable","Est une boucle"],ans:1},
           {q:"const dans un bloc {} ?",opts:["Accessible partout","Accessible seulement dans ce bloc","Erreur de syntaxe","Devient global"],ans:1}]},
    {d:11,title:"Spread, Rest & Destructuration",sub:"... operator, décomposition",level:"med",
     theory:`<div class="theory-block"><h3>✨ 11.1 — L'opérateur spread : "étaler" un tableau ou un objet</h3><p>Les trois points <code style="color:#f7c948">...</code> "déballent" le contenu d'un tableau ou d'un objet, élément par élément. C'est l'outil numéro un pour copier ou fusionner des données sans modifier les originales — omniprésent en React.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">fruits</span> = [<span class="str">"mangue"</span>, <span class="str">"banane"</span>];
<span class="kw">const</span> <span class="var">legumes</span> = [<span class="str">"igname"</span>, <span class="str">"gombo"</span>];
<span class="kw">const</span> <span class="var">courses</span> = [...fruits, ...legumes];
<span class="fn">console</span>.<span class="fn">log</span>(courses); <span class="cmt">// ["mangue","banane","igname","gombo"]</span>

<span class="cmt">// Copier un tableau (copie réelle, pas une référence)</span>
<span class="kw">const</span> <span class="var">copie</span> = [...fruits];
copie.<span class="fn">push</span>(<span class="str">"avocat"</span>);
<span class="fn">console</span>.<span class="fn">log</span>(fruits.length); <span class="cmt">// 2 — l'original n'a pas bougé</span></div></div></div>

<div class="theory-block"><h3>🧩 11.2 — Spread sur les objets : fusionner et écraser des propriétés</h3><p>Même opérateur, avec des accolades. Si deux propriétés portent le même nom, <b>la dernière l'emporte</b>.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">produit</span> = { marque: <span class="str">"iPhone"</span>, prix: <span class="num">600</span> };
<span class="kw">const</span> <span class="var">promo</span> = { ...produit, prix: <span class="num">500</span>, reduction: <span class="kw">true</span> };
<span class="fn">console</span>.<span class="fn">log</span>(promo); <span class="cmt">// { marque:"iPhone", prix:500, reduction:true }</span>
<span class="fn">console</span>.<span class="fn">log</span>(produit.prix); <span class="cmt">// 600 — inchangé</span></div></div>
<div class="tip-box"><strong>💡 Attention :</strong> le spread ne copie qu'un seul niveau — un objet ou tableau imbriqué reste partagé entre l'original et la copie.</div></div>

<div class="theory-block"><h3>📥 11.3 — Rest parameter : collecter des arguments en trop</h3><p>Dans la <b>déclaration</b> d'une fonction, <code>...</code> prend le sens inverse : il <b>rassemble</b> tous les arguments restants dans un vrai tableau.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">function</span> <span class="fn">total</span>(...<span class="var">prix</span>) {
  <span class="kw">return</span> prix.<span class="fn">reduce</span>((a, b) => a + b, <span class="num">0</span>);
}
<span class="fn">console</span>.<span class="fn">log</span>(<span class="fn">total</span>(<span class="num">1000</span>, <span class="num">2500</span>, <span class="num">750</span>)); <span class="cmt">// 4250</span></div></div>
<p>Ne confonds pas rest et spread : dans une <b>déclaration</b>, <code>...</code> collecte. Dans un <b>appel</b> ou un littéral, <code>...</code> déballe.</p></div>

<div class="theory-block"><h3>📤 11.4 — Destructuration de tableau : extraire par position</h3><p>La destructuration extrait plusieurs valeurs en une ligne. Pour un tableau, l'extraction se fait <b>par position</b>.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">courses</span> = [<span class="str">"mangue"</span>, <span class="str">"banane"</span>, <span class="str">"igname"</span>, <span class="str">"gombo"</span>];

<span class="kw">const</span> [<span class="var">premier</span>, <span class="var">deuxieme</span>, ...<span class="var">reste</span>] = courses;
<span class="fn">console</span>.<span class="fn">log</span>(premier);  <span class="cmt">// "mangue"</span>
<span class="fn">console</span>.<span class="fn">log</span>(reste);    <span class="cmt">// ["igname","gombo"]</span></div></div></div>

<div class="theory-block"><h3>🎯 11.5 — Destructuration d'objet : extraire par nom</h3><p>Pour un objet, l'extraction fonctionne <b>par nom de propriété</b>. Tu peux renommer, donner une valeur par défaut, et combiner avec un rest.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">produit</span> = { marque: <span class="str">"iPhone"</span>, prix: <span class="num">600</span>, stock: <span class="num">12</span> };

<span class="kw">const</span> { marque: <span class="var">nomMarque</span>, ...<span class="var">reste</span> } = produit;
<span class="fn">console</span>.<span class="fn">log</span>(nomMarque); <span class="cmt">// "iPhone" — renommé au passage</span>

<span class="kw">const</span> { couleur = <span class="str">"noir"</span> } = produit;
<span class="fn">console</span>.<span class="fn">log</span>(couleur); <span class="cmt">// "noir" — valeur par défaut</span></div></div>
<div class="tip-box"><strong>💡 Très courant :</strong> destructurer directement un paramètre objet — <code>function afficher({ marque, prix }) { ... }</code> — dominant en React pour les props.</div></div>`,
     starter:`// Jour 11 — Spread & Destructuration
const fruits = ["mangue", "banane", "avocat"];
const legumes = ["igname", "gombo"];
const courses = [...fruits, ...legumes];
console.log("Courses :", courses);

// Destructuration de tableau
const [premier, deuxieme, ...reste] = courses;
console.log("Premier :", premier);
console.log("Deuxième :", deuxieme);
console.log("Reste :", reste);

// Spread d'objet
const base = { marque: "iPhone", prix: 600 };
const promo = { ...base, prix: 500, reduction: true };
console.log(promo);`,
     quiz:[{q:"[...a, ...b] fait quoi ?",opts:["Multiplie les tableaux","Fusionne deux tableaux","Filtre les doublons","Trie le tableau"],ans:1},
           {q:"Rest parameter ...nums collecte ?",opts:["Le premier argument","Tous les arguments dans un tableau","Le dernier argument","undefined"],ans:1},
           {q:"const { a, ...reste } = { a:1, b:2, c:3 } — reste vaut ?",opts:["{ }","{ b:2, c:3 }","{ a:1 }","[2,3]"],ans:1}]},
    {d:12,title:"Classes & POO",sub:"class, constructor, héritage",level:"med",
     theory:`<div class="theory-block"><h3>🏛️ 12.1 — Une classe, c'est un moule à objets</h3><p>Depuis le Jour 7, tu sais créer un objet avec <code>{ }</code>. Mais que faire quand tu dois créer des dizaines d'objets qui se ressemblent, chacun avec les mêmes propriétés et comportements ? Une <b>classe</b> est un moule (un plan) à partir duquel tu fabriques autant d'<b>instances</b> que nécessaire.</p></div>

<div class="theory-block"><h3>🔨 12.2 — constructor() : le plan de fabrication</h3><p>Le <code>constructor()</code> est appelé automatiquement à chaque <code>new</code>. C'est là que tu reçois les valeurs de départ et les stockes sur <code>this</code>.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">class</span> <span class="fn">Etudiant</span> {
  <span class="fn">constructor</span>(<span class="var">nom</span>, <span class="var">filiere</span>) {
    <span class="kw">this</span>.nom = nom;
    <span class="kw">this</span>.filiere = filiere;
    <span class="kw">this</span>.notes = [];
  }
  <span class="fn">ajouterNote</span>(<span class="var">note</span>) { <span class="kw">this</span>.notes.<span class="fn">push</span>(note); }
  <span class="fn">moyenne</span>() {
    <span class="kw">return</span> <span class="kw">this</span>.notes.<span class="fn">reduce</span>((a,b)=>a+b,<span class="num">0</span>) / <span class="kw">this</span>.notes.length;
  }
}

<span class="kw">const</span> <span class="var">e1</span> = <span class="kw">new</span> <span class="fn">Etudiant</span>(<span class="str">"Nerija"</span>, <span class="str">"Dev"</span>);
<span class="kw">const</span> <span class="var">e2</span> = <span class="kw">new</span> <span class="fn">Etudiant</span>(<span class="str">"Kofi"</span>, <span class="str">"Design"</span>);
e1.<span class="fn">ajouterNote</span>(<span class="num">16</span>);
<span class="fn">console</span>.<span class="fn">log</span>(e1.moyenne(), e2.notes.length); <span class="cmt">// 16, 0 — chaque instance a SES notes</span></div></div></div>

<div class="theory-block"><h3>🧬 12.3 — extends : hériter d'une classe existante</h3><p><code>extends</code> crée une classe "enfant" qui récupère automatiquement tout ce que possède une classe "parente".</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">class</span> <span class="fn">Animal</span> {
  <span class="fn">constructor</span>(<span class="var">nom</span>, <span class="var">son</span>) {
    <span class="kw">this</span>.nom = nom;
    <span class="kw">this</span>.son = son;
  }
  <span class="fn">parler</span>() {
    <span class="kw">return</span> <span class="kw">this</span>.nom + <span class="str">" fait "</span> + <span class="kw">this</span>.son;
  }
}

<span class="kw">class</span> <span class="fn">Chien</span> <span class="kw">extends</span> <span class="fn">Animal</span> {
  <span class="fn">constructor</span>(<span class="var">nom</span>) {
    <span class="kw">super</span>(nom, <span class="str">"Wouf !"</span>);
    <span class="kw">this</span>.tricks = [];
  }
  <span class="fn">apprendreTrick</span>(<span class="var">trick</span>) {
    <span class="kw">this</span>.tricks.<span class="fn">push</span>(trick);
  }
}

<span class="kw">const</span> <span class="var">rex</span> = <span class="kw">new</span> <span class="fn">Chien</span>(<span class="str">"Rex"</span>);
<span class="fn">console</span>.<span class="fn">log</span>(rex.parler()); <span class="cmt">// hérité tel quel d'Animal</span></div></div></div>

<div class="theory-block"><h3>⚡ 12.4 — super() : appeler le constructeur du parent</h3><p>Dès qu'une classe utilise <code>extends</code>, son constructor doit appeler <code>super(...)</code> <b>avant</b> toute utilisation de <code>this</code>. <code>super(nom, son)</code> exécute le constructor parent avec ces arguments.</p>
<div class="tip-box"><strong>💡 Piège fréquent :</strong> oublier <code>super()</code> provoque une erreur explicite. Si l'enfant n'ajoute rien au constructor, tu peux l'omettre.</div></div>

<div class="theory-block"><h3>🧱 12.5 — new : de la classe à l'instance concrète</h3><p><code>new MaClasse(...)</code> crée un objet, exécute le constructor avec <code>this</code> pointant vers ce nouvel objet, puis le renvoie. Chaque instance est totalement indépendante des autres.</p></div>`,
     starter:`// Jour 12 — Classes
class Animal {
  constructor(nom, son) {
    this.nom = nom;
    this.son = son;
  }
  parler() {
    return \`\${this.nom} fait "\${this.son}"\`;
  }
}

class Chien extends Animal {
  constructor(nom) {
    super(nom, "Wouf !");
    this.tricks = [];
  }
  apprendreTrick(trick) {
    this.tricks.push(trick);
    console.log(\`\${this.nom} a appris : \${trick}\`);
  }
}

const rex = new Chien("Rex");
console.log(rex.parler());
rex.apprendreTrick("s'asseoir");
rex.apprendreTrick("tourner");
console.log("Tricks :", rex.tricks);`,
     quiz:[{q:"extends est utilisé pour ?",opts:["Créer un objet","L'héritage","Appeler une méthode","Importer une classe"],ans:1},
           {q:"super() dans le constructor appelle ?",opts:["Une méthode statique","La classe parente","La méthode this","Le prototype"],ans:1},
           {q:"new MaClasse() fait quoi ?",opts:["Appelle une fonction","Crée une instance","Importe une classe","Supprime un objet"],ans:1}]},
    {d:13,title:"Asynchrone — Callbacks",sub:"setTimeout, setInterval, callbacks",level:"med",
     theory:`<div class="theory-block"><h3>🧵 13.1 — JS n'a qu'un seul fil d'exécution</h3><p>JavaScript est <b>single-threaded</b> : il n'exécute qu'une seule ligne à la fois. Si une opération prend du temps, tout devrait geler — pourtant tu peux continuer à scroller une page pendant qu'une image se charge. La solution s'appelle l'<b>asynchrone</b>.</p></div>

<div class="theory-block"><h3>⏳ 13.2 — setTimeout() : déléguer l'attente</h3><p><code>setTimeout(fonction, delai)</code> délègue le minutage à un système extérieur, et continue immédiatement.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="fn">console</span>.<span class="fn">log</span>(<span class="str">"1 - Début"</span>);

<span class="fn">setTimeout</span>(() => {
  <span class="fn">console</span>.<span class="fn">log</span>(<span class="str">"3 - Après 1 seconde"</span>);
}, <span class="num">1000</span>);

<span class="fn">console</span>.<span class="fn">log</span>(<span class="str">"2 - Fin du code synchrone"</span>);
<span class="cmt">// Ordre affiché : 1, 2, 3</span></div></div>
<p>Même <code>setTimeout(fn, 0)</code> ne s'exécute pas "tout de suite" — toujours <b>après</b> que le code synchrone en cours ait fini.</p></div>

<div class="theory-block"><h3>🔄 13.3 — La pile d'appels, la file d'attente, et l'Event Loop</h3><p>La <b>pile d'appels</b> exécute le code synchrone. Les callbacks asynchrones terminés patientent dans une <b>file d'attente</b>. L'<b>Event Loop</b> surveille : si la pile est vide, il prend le premier callback en attente et l'exécute.</p>
<div class="tip-box"><strong>💡 Analogie :</strong> un serveur de restaurant prend les commandes une par une, mais continue de servir pendant qu'un plat cuit en cuisine.</div></div>

<div class="theory-block"><h3>📞 13.4 — Callback : une fonction qu'on confie pour plus tard</h3><p>Un <b>callback</b> est une fonction passée en argument à une autre fonction, pour être appelée plus tard.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">function</span> <span class="fn">chercherDonnees</span>(<span class="var">callback</span>) {
  <span class="fn">setTimeout</span>(() => {
    <span class="kw">const</span> <span class="var">data</span> = { nom: <span class="str">"Nerija"</span>, score: <span class="num">95</span> };
    callback(data);
  }, <span class="num">500</span>);
}

<span class="fn">chercherDonnees</span>((<span class="var">data</span>) => {
  <span class="fn">console</span>.<span class="fn">log</span>(<span class="str">"Données reçues :"</span>, data);
});</div></div></div>

<div class="theory-block"><h3>⏱️ 13.5 — setInterval() : répéter dans le temps</h3><p><code>setInterval(fonction, delai)</code> répète <b>indéfiniment</b>, jusqu'à <code>clearInterval(id)</code>.</p>
<div class="tip-box"><strong>💡 À venir :</strong> enchaîner plusieurs callbacks dépendants crée une "pyramide du malheur" — c'est ce que les Promises (Jour 14) résolvent.</div></div>`,
     starter:`// Jour 13 — Asynchrone
console.log("Départ de la simulation...");

setTimeout(() => {
  console.log("Résultat après 0ms (async)");
}, 0);

console.log("Code synchrone (s'exécute avant le timeout)");

// Simulation d'une opération qui prend du temps
function chercherDonnees(callback) {
  console.log("Recherche en cours...");
  setTimeout(() => {
    const data = { nom: "Nerija", score: 95 };
    callback(data);
  }, 500);
}

chercherDonnees((data) => {
  console.log("Données reçues :", JSON.stringify(data));
});`,
     quiz:[{q:"setTimeout(fn, 0) s'exécute ?",opts:["Immédiatement","Après tout le code synchrone","Jamais","Avant le code sync"],ans:1},
           {q:"Un callback est ?",opts:["Une variable","Une fonction passée en argument","Une boucle","Une classe"],ans:1},
           {q:"setInterval(fn, 1000) fait quoi ?",opts:["Execute une fois après 1s","Execute toutes les 1s","Attend 1s puis s'arrête","Bloque le code"],ans:1}]},
    {d:14,title:"Promises & Async/Await",sub:"Promise, .then(), async/await",level:"med",
     theory:`<div class="theory-block"><h3>🤝 14.1 — La Promise : une valeur qui n'existe pas encore, mais qui arrivera</h3><p>Une <b>Promise</b> représente le résultat futur d'une opération asynchrone. Elle traverse trois états : <b>pending</b> (en attente), <b>fulfilled</b> (résolue), ou <b>rejected</b> (échec).</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">maPromesse</span> = <span class="kw">new</span> <span class="fn">Promise</span>((<span class="var">resolve</span>, <span class="var">reject</span>) => {
  <span class="kw">const</span> <span class="var">connexionOk</span> = <span class="kw">true</span>;
  <span class="kw">if</span> (connexionOk) {
    <span class="fn">resolve</span>(<span class="str">"Connecté avec succès"</span>);
  } <span class="kw">else</span> {
    <span class="fn">reject</span>(<span class="str">"Échec de connexion"</span>);
  }
});</div></div>
<p><code>resolve(valeur)</code> et <code>reject(erreur)</code> décident comment la Promise se termine.</p></div>

<div class="theory-block"><h3>🔗 14.2 — .then() et .catch() : réagir au résultat</h3><p><code>.then(valeur => ...)</code> pour le succès, <code>.catch(erreur => ...)</code> pour l'échec. Ces méthodes se chaînent.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content">maPromesse
  .<span class="fn">then</span>(<span class="var">resultat</span> => <span class="fn">console</span>.<span class="fn">log</span>(<span class="str">"Succès :"</span>, resultat))
  .<span class="fn">catch</span>(<span class="var">erreur</span> => <span class="fn">console</span>.<span class="fn">log</span>(<span class="str">"Erreur :"</span>, erreur));</div></div></div>

<div class="theory-block"><h3>⚡ 14.3 — async/await : écrire de l'asynchrone comme du synchrone</h3><p><code>async</code> devant une fonction en fait une fonction qui retourne une Promise. <code>await</code> "met en pause" cette fonction jusqu'à ce que la Promise se résolve.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">function</span> <span class="fn">attendre</span>(<span class="var">ms</span>) {
  <span class="kw">return</span> <span class="kw">new</span> <span class="fn">Promise</span>(<span class="var">resolve</span> => <span class="fn">setTimeout</span>(resolve, ms));
}

<span class="kw">async function</span> <span class="fn">mission</span>() {
  <span class="fn">console</span>.<span class="fn">log</span>(<span class="str">"Mission démarrée..."</span>);
  <span class="kw">await</span> <span class="fn">attendre</span>(<span class="num">100</span>);
  <span class="fn">console</span>.<span class="fn">log</span>(<span class="str">"Étape 1 terminée"</span>);
  <span class="kw">return</span> <span class="str">"Mission accomplie !"</span>;
}

mission().<span class="fn">then</span>(<span class="var">msg</span> => <span class="fn">console</span>.<span class="fn">log</span>(msg));</div></div>
<div class="tip-box"><strong>💡 Règle stricte :</strong> <code>await</code> ne fonctionne qu'à l'intérieur d'une fonction <code>async</code>.</div></div>

<div class="theory-block"><h3>🛡️ 14.4 — try/catch : gérer les erreurs proprement avec await</h3><p>Avec async/await, on entoure le code sensible d'un <code>try { }</code> et on attrape l'erreur dans <code>catch (err) { }</code>.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">async function</span> <span class="fn">getData</span>() {
  <span class="kw">try</span> {
    <span class="kw">const</span> <span class="var">result</span> = <span class="kw">await</span> <span class="var">maPromesse</span>;
    <span class="fn">console</span>.<span class="fn">log</span>(result);
  } <span class="kw">catch</span> (<span class="var">err</span>) {
    <span class="fn">console</span>.<span class="fn">log</span>(err);
  }
}</div></div>
<div class="tip-box"><strong>💡 Règle d'or :</strong> préfère toujours <code>async/await</code> + <code>try/catch</code> à <code>.then().catch()</code>.</div></div>

<div class="theory-block"><h3>🚀 14.5 — Promise.all() : lancer plusieurs opérations en parallèle</h3><p>Plusieurs <code>await</code> à la suite sont <b>séquentiels</b>. <code>Promise.all([...])</code> les lance toutes <b>en même temps</b>.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> [<span class="var">a</span>, <span class="var">b</span>, <span class="var">c</span>] = <span class="kw">await</span> <span class="fn">Promise</span>.<span class="fn">all</span>([
  <span class="fn">attendre</span>(<span class="num">100</span>), <span class="fn">attendre</span>(<span class="num">100</span>), <span class="fn">attendre</span>(<span class="num">100</span>)
]); <span class="cmt">// ~100ms au total, pas ~300ms</span></div></div>
<p>Si une seule Promise échoue, tout <code>Promise.all()</code> est rejeté — pour continuer malgré un échec partiel, utilise <code>Promise.allSettled()</code>.</p></div>`,
     starter:`// Jour 14 — Promises & Async/Await
function attendre(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function mission() {
  console.log("Mission démarrée...");
  await attendre(100);
  console.log("Étape 1 : Connexion établie");
  await attendre(100);
  console.log("Étape 2 : Données chargées");
  await attendre(100);
  console.log("Étape 3 : Traitement terminé");
  return "Mission accomplie ! ✅";
}

mission().then(msg => console.log(msg));`,
     quiz:[{q:"await peut s'utiliser seulement dans ?",opts:["Toute fonction","Une fonction async","Une boucle for","Un try/catch"],ans:1},
           {q:"resolve() dans une Promise...",opts:["Rejette la promise","La met en attente","La résout avec succès","Crée une erreur"],ans:2},
           {q:"Promise.all([p1, p2]) fait quoi ?",opts:["Execute séquentiellement","Execute en parallèle, attend toutes","Retourne la première","Ignore les erreurs"],ans:1}]}
  ]},
  {week:"Semaine 3 — Avancé",days:[
    {d:15,title:"Fetch API — Requêtes HTTP",sub:"GET, POST, API REST",level:"med",theory:`<div class="theory-block"><h3>🌐 15.1 — Le web : une conversation client-serveur</h3><p>Chaque fois qu'une page se charge ou qu'une app affiche un fil d'actualité, la même mécanique tourne en coulisses : un <b>client</b> (ton code JS) envoie une <b>requête</b> à un <b>serveur</b> distant, puis attend une <b>réponse</b>. C'est comme commander au restaurant : tu donnes ta commande, le serveur part en cuisine, et revient. Cette conversation suit un protocole standardisé, <b>HTTP</b>. Chaque requête cible une <b>URL</b> précise et porte une <b>méthode</b> qui indique l'intention : lire, créer, modifier, supprimer. Un serveur qui expose ses données de cette façon s'appelle une <b>API REST</b>.</p></div>

<div class="theory-block"><h3>📡 15.2 — fetch() : lancer une requête, recevoir une Promise</h3><p>La fonction native pour parler à un serveur s'appelle <code>fetch()</code>. Tu lui donnes une URL, elle lance la requête... mais elle ne te rend pas les données tout de suite. Le réseau prend du temps, et JS refuse de geler tout le programme en attendant. À la place, <code>fetch()</code> te renvoie <b>immédiatement</b> une Promise, qui se résoudra plus tard.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">promesse</span> = <span class="fn">fetch</span>(<span class="str">"https://api.exemple.com/users/1"</span>);
<span class="fn">console</span>.<span class="fn">log</span>(promesse); <span class="cmt">// Promise { pending } — pas encore les données !</span></div></div>
<div class="tip-box"><strong>💡 Piège classique :</strong> écrire <code>const data = fetch(url)</code> et essayer d'utiliser <code>data</code> directement. Tu obtiens une Promise, pas tes données.</div></div>

<div class="theory-block"><h3>⏳ 15.3 — async/await : la façon propre d'attendre</h3><p>On déclare la fonction <code>async</code>, et à l'intérieur, <code>await</code> met en pause l'exécution de <b>cette fonction précise</b> (pas tout le programme) jusqu'à ce que la Promise se résolve.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">async function</span> <span class="fn">getUser</span>() {
  <span class="kw">const</span> <span class="var">res</span> = <span class="kw">await</span> <span class="fn">fetch</span>(<span class="str">"https://api.exemple.com/users/1"</span>);
  <span class="kw">const</span> <span class="var">data</span> = <span class="kw">await</span> res.<span class="fn">json</span>();
  <span class="fn">console</span>.<span class="fn">log</span>(data);
}

<span class="fn">getUser</span>();
<span class="fn">console</span>.<span class="fn">log</span>(<span class="str">"Cette ligne s'affiche AVANT les données !"</span>);</div></div></div>

<div class="theory-block"><h3>📬 15.4 — Décortiquer la réponse : ok, status, json()</h3><p>L'objet que <code>fetch()</code> résout est un objet <b>Response</b>. <code>res.ok</code> — un booléen, vrai si le code de statut est entre 200 et 299. <code>res.status</code> — le code numérique exact : 200 (OK), 201 (créé), 404 (introuvable), 500 (erreur serveur). <code>res.json()</code> — lit le corps et le convertit en objet JS, et renvoie elle-même une Promise, donc il faut l'<code>await</code>.</p>
<div class="tip-box"><strong>⚠️ Piège n°1 :</strong> <code>fetch()</code> ne rejette PAS sa Promise pour une erreur HTTP comme 404 — seulement en cas d'échec réseau total. C'est à toi de vérifier <code>res.ok</code>.</div></div>

<div class="theory-block"><h3>✉️ 15.5 — Envoyer des données : la méthode POST</h3><p>Pour créer une ressource, on passe un second argument à <code>fetch()</code> : un objet de configuration avec la méthode, les en-têtes et le corps.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">async function</span> <span class="fn">creerUtilisateur</span>(<span class="var">nom</span>) {
  <span class="kw">const</span> <span class="var">res</span> = <span class="kw">await</span> <span class="fn">fetch</span>(<span class="str">"https://api.exemple.com/users"</span>, {
    method: <span class="str">"POST"</span>,
    headers: { <span class="str">"Content-Type"</span>: <span class="str">"application/json"</span> },
    body: <span class="fn">JSON.stringify</span>({ nom })
  });
  <span class="kw">return</span> res.<span class="fn">json</span>();
}</div></div>
<p>Le body doit être une <b>chaîne</b> — d'où <code>JSON.stringify()</code>.</p></div>

<div class="theory-block"><h3>🧭 15.6 — Panorama des méthodes HTTP</h3><p><code>GET</code> lit une ressource. <code>POST</code> en crée une nouvelle. <code>PUT</code> remplace entièrement. <code>PATCH</code> modifie partiellement. <code>DELETE</code> supprime.</p>
<div class="tip-box"><strong>💡 Astuce pro :</strong> Enveloppe toujours tes appels <code>fetch()</code> dans un <code>try/catch</code> (Jour 16) — le réseau est imprévisible.</div></div>`,starter:`// Jour 15 — Fetch API (simulation)
async function simulerFetch(url) {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        ok: true,
        json: () => Promise.resolve({ id: 1, nom: "Nerija", role: "dev" })
      });
    }, 200);
  });
}

async function main() {
  console.log("Appel API...");
  const res = await simulerFetch("https://api.monapp.ci/users/1");
  const user = await res.json();
  console.log("Utilisateur :", JSON.stringify(user));
  console.log(\`Bienvenue, \${user.nom} (\${user.role})\`);
}

main();`,quiz:[{q:"fetch() retourne quoi ?",opts:["Les données directement","Une Promise","Un objet JSON","undefined"],ans:1},{q:"res.json() est nécessaire pour ?",opts:["Vérifier le status","Parser le corps en JSON","Envoyer des données","Fermer la connexion"],ans:1},{q:"Pour un POST avec fetch, que faut-il ajouter ?",opts:["Rien","method: 'POST' et body","Juste body","method: 'post' seulement"],ans:1}]},
    {d:16,title:"Gestion d'erreurs",sub:"try/catch, throw, Error",level:"med",theory:`<div class="theory-block"><h3>🚨 16.1 — Le monde réel est fragile</h3><p>Un utilisateur tape une lettre au lieu d'un nombre. Le réseau coupe en pleine requête. Une division tombe sur zéro. Aucun de ces cas n'est un "bug" au sens où tu aurais mal écrit ton code — ce sont des situations que ton programme <b>doit prévoir</b>. Sans gestion d'erreurs, une exception non interceptée arrête net l'exécution du script. Avec une bonne gestion, ton programme peut afficher un message clair, réessayer, ou continuer avec une valeur par défaut.</p></div>

<div class="theory-block"><h3>🛡️ 16.2 — try / catch : encadrer le code à risque</h3><p>Le bloc <code>try</code> contient le code "à risque". Si une erreur y survient, l'exécution saute <b>immédiatement</b> au bloc <code>catch</code>, qui reçoit l'erreur sous forme d'un objet — traditionnellement nommé <code>err</code>.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">try</span> {
  <span class="kw">const</span> <span class="var">age</span> = JSON.<span class="fn">parse</span>(<span class="str">"pas du JSON"</span>); <span class="cmt">// va planter</span>
  <span class="fn">console</span>.<span class="fn">log</span>(<span class="str">"Cette ligne ne s'exécutera jamais"</span>);
} <span class="kw">catch</span> (err) {
  <span class="fn">console</span>.<span class="fn">log</span>(<span class="str">"On a évité le crash !"</span>);
}</div></div>
<div class="tip-box"><strong>💡 Astuce :</strong> Mets dans le <code>try</code> uniquement les lignes réellement susceptibles d'échouer.</div></div>

<div class="theory-block"><h3>💥 16.3 — throw : déclencher une erreur toi-même</h3><p>Tu peux lancer une erreur explicitement avec <code>throw</code>, dès que ta fonction reçoit une donnée qu'elle refuse de traiter.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">function</span> <span class="fn">diviser</span>(<span class="var">a</span>, <span class="var">b</span>) {
  <span class="kw">if</span> (b === <span class="num">0</span>) <span class="kw">throw new</span> <span class="fn">Error</span>(<span class="str">"Division par zéro !"</span>);
  <span class="kw">return</span> a / b;
}

<span class="kw">try</span> {
  <span class="fn">console</span>.<span class="fn">log</span>(<span class="fn">diviser</span>(<span class="num">10</span>, <span class="num">2</span>)); <span class="cmt">// 5</span>
  <span class="fn">console</span>.<span class="fn">log</span>(<span class="fn">diviser</span>(<span class="num">10</span>, <span class="num">0</span>)); <span class="cmt">// déclenche throw</span>
} <span class="kw">catch</span> (err) {
  <span class="fn">console</span>.<span class="fn">error</span>(<span class="str">\`Erreur : \${err.message}\`</span>);
}</div></div>
<p>Un objet <code>Error</code> possède toujours une propriété <code>.message</code>, récupérable dans le <code>catch</code>.</p></div>

<div class="theory-block"><h3>🏷️ 16.4 — Les familles d'erreurs : TypeError, RangeError...</h3><p><code>Error</code> est la classe de base. <code>TypeError</code> quand une valeur n'est pas du type attendu, <code>RangeError</code> quand une valeur numérique sort d'un intervalle valide. Chaque objet erreur garde la trace de sa classe via <code>err.constructor.name</code>.</p>
<div class="tip-box"><strong>💡 Aller plus loin :</strong> Tu peux créer tes propres classes d'erreurs avec <code>class MonErreur extends Error { ... }</code>.</div></div>

<div class="theory-block"><h3>🔚 16.5 — finally : le bloc qui s'exécute toujours</h3><p>Après <code>try</code> et son éventuel <code>catch</code>, un troisième bloc optionnel, <code>finally</code>, s'exécute systématiquement — que tout se soit bien passé ou non. Il sert typiquement à du nettoyage.</p></div>

<div class="theory-block"><h3>🚫 16.6 — Le piège à éviter absolument</h3><p>Le pire réflexe : le <code>catch</code> vide, <code>catch (err) {}</code>. L'erreur disparaît silencieusement, et tu perds toute visibilité sur ce qui s'est réellement passé.</p>
<div class="tip-box"><strong>⚠️ Règle d'or :</strong> Un <code>catch</code> doit toujours faire QUELQUE CHOSE avec l'erreur — au minimum la logger.</div></div>`,starter:`// Jour 16 — Gestion d'erreurs
function validerAge(age) {
  if (typeof age !== "number") throw new TypeError("L'âge doit être un nombre");
  if (age < 0 || age > 150) throw new RangeError("Âge invalide");
  return \`Âge valide : \${age} ans\`;
}

const tests = [18, -5, "vingt", 200, 25];

tests.forEach(val => {
  try {
    console.log(validerAge(val));
  } catch (err) {
    console.log(\`[ERREUR \${err.constructor.name}] \${err.message}\`);
  }
});`,quiz:[{q:"finally s'exécute...",opts:["Seulement si succès","Seulement si erreur","Toujours","Jamais si throw"],ans:2},{q:"throw new Error('msg') fait quoi ?",opts:["Affiche une alerte","Lance une exception","Ignore l'erreur","Appelle catch"],ans:1},{q:"err.message contient ?",opts:["Le type d'erreur","Le message de l'erreur","Le stack trace","undefined"],ans:1}]},
    {d:17,title:"Modules ES6",sub:"import, export, modules",level:"med",theory:`<div class="theory-block"><h3>📦 17.1 — Le problème du fichier de 5000 lignes</h3><p>Depuis le Jour 1, tout ton code tient dans un seul fichier. Ça fonctionne pour un exercice, mais imagine une vraie application : gestion des utilisateurs, appels API, validation de formulaires... Tout entassé dans un seul fichier devient vite illisible. Les <b>modules ES6</b> résolvent ce problème en te permettant de découper ton code en fichiers indépendants qui communiquent via <code>export</code> et <code>import</code>. Un module ne partage rien par défaut — tout est privé, sauf ce qu'on exporte explicitement.</p></div>

<div class="theory-block"><h3>🏷️ 17.2 — export nommé : partager plusieurs éléments</h3><p>Un <b>export nommé</b> expose une valeur sous un nom précis. Un même fichier peut en avoir autant que nécessaire — idéal quand un module regroupe plusieurs utilitaires liés.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="cmt">// math.js — named exports</span>
<span class="kw">export const</span> <span class="fn">ajouter</span> = (a, b) => a + b;
<span class="kw">export const</span> <span class="fn">multiplier</span> = (a, b) => a * b;
<span class="kw">export const</span> <span class="var">PI</span> = <span class="num">3.14159</span>;</div></div></div>

<div class="theory-block"><h3>⭐ 17.3 — export default : LA chose principale du fichier</h3><p>Quand un module n'a qu'une seule chose importante à proposer, on utilise <code>export default</code>. Contrairement aux exports nommés, un fichier n'a droit qu'à <b>un seul</b> export par défaut.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="cmt">// utils.js — default export</span>
<span class="kw">export default function</span> <span class="fn">formater</span>(<span class="var">val</span>) {
  <span class="kw">return</span> <span class="str">\`Résultat : \${val}\`</span>;
}</div></div>
<div class="tip-box"><strong>💡 Bon à savoir :</strong> Un export par défaut peut être <b>renommé librement</b> à l'import.</div></div>

<div class="theory-block"><h3>📥 17.4 — import : récupérer ce dont tu as besoin</h3><p>La syntaxe diffère selon le type d'export : sans accolades pour un default, avec accolades <code>{ }</code> pour des named exports.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="cmt">// main.js</span>
<span class="kw">import</span> formater <span class="kw">from</span> <span class="str">"./utils.js"</span>;               <span class="cmt">// default, pas d'accolades</span>
<span class="kw">import</span> { ajouter, multiplier } <span class="kw">from</span> <span class="str">"./math.js"</span>;  <span class="cmt">// named, avec accolades</span>

<span class="fn">console</span>.<span class="fn">log</span>(<span class="fn">formater</span>(<span class="fn">ajouter</span>(<span class="num">3</span>, <span class="num">4</span>))); <span class="cmt">// "Résultat : 7"</span></div></div></div>

<div class="theory-block"><h3>🗂️ 17.5 — Organiser un vrai projet</h3><p>Dans un projet réel, chaque module vit dans son propre fichier, regroupé par responsabilité : <code>api/users.js</code>, <code>utils/format.js</code>, <code>components/Card.js</code>. Cette organisation permet à une équipe entière de travailler sans se marcher dessus.</p></div>

<div class="theory-block"><h3>⚖️ 17.6 — Named vs default : lequel choisir ?</h3><p>Si ton fichier expose <b>une seule</b> idée centrale, utilise <code>export default</code>. S'il expose une <b>collection d'utilitaires</b> indépendants, préfère des exports nommés.</p>
<div class="tip-box"><strong>⚠️ Piège fréquent :</strong> Oublier l'extension <code>.js</code> dans le chemin d'import fonctionne avec certains bundlers mais pas nativement dans le navigateur ou Node.</div></div>`,starter:`// Jour 17 — Simulation de modules
// Module "mathUtils"
const mathUtils = {
  ajouter: (a, b) => a + b,
  soustraire: (a, b) => a - b,
  multiplier: (a, b) => a * b,
  diviser: (a, b) => b !== 0 ? a / b : "Erreur",
  puissance: (a, b) => a ** b,
};

// Module "stringUtils"
const stringUtils = {
  capitaliser: str => str.charAt(0).toUpperCase() + str.slice(1),
  inverser: str => str.split("").reverse().join(""),
  compterMots: str => str.split(" ").length,
};

// Utilisation
const { ajouter, puissance } = mathUtils;
const { capitaliser, inverser } = stringUtils;

console.log(ajouter(10, 5));
console.log(puissance(2, 10));
console.log(capitaliser("nerija apprend js"));
console.log(inverser("JavaScript"));`,quiz:[{q:"export default permet d'exporter ?",opts:["Plusieurs valeurs","Une seule valeur principale","Rien","Un tableau"],ans:1},{q:"import { fn } from './mod.js' est un ?",opts:["Default import","Named import","Wildcard import","Dynamic import"],ans:1},{q:"Un fichier peut avoir combien de default exports ?",opts:["Illimité","2","1","0"],ans:2}]},
    {d:18,title:"LocalStorage & JSON",sub:"Persistance des données",level:"med",theory:`<div class="theory-block"><h3>💨 18.1 — Le problème de la mémoire volatile</h3><p>Toutes tes variables vivent dans la RAM : dès que tu recharges la page, elles disparaissent. Pour qu'une application "se souvienne" — un panier, une progression de bootcamp — il faut un endroit qui survit au rechargement. C'est le rôle du <b>localStorage</b>, un petit espace de stockage que chaque navigateur réserve à chaque site.</p></div>

<div class="theory-block"><h3>📥 18.2 — localStorage : une boîte à chaussures dans le navigateur</h3><p>Tu ranges une chose sous un nom, tu la retrouves plus tard grâce à ce même nom.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content">localStorage.<span class="fn">setItem</span>(<span class="str">"pseudo"</span>, <span class="str">"Nerija"</span>);  <span class="cmt">// ranger</span>
<span class="kw">const</span> <span class="var">pseudo</span> = localStorage.<span class="fn">getItem</span>(<span class="str">"pseudo"</span>); <span class="cmt">// récupérer</span>
localStorage.<span class="fn">removeItem</span>(<span class="str">"pseudo"</span>);          <span class="cmt">// supprimer une entrée</span>
localStorage.<span class="fn">clear</span>();                          <span class="cmt">// tout vider</span></div></div>
<p>Ces données restent disponibles même après avoir fermé le navigateur — jusqu'à ce que l'utilisateur les efface ou que ton code appelle <code>removeItem</code>/<code>clear</code>.</p></div>

<div class="theory-block"><h3>🧩 18.3 — Le piège central : localStorage ne parle QUE le texte</h3><p><code>setItem</code> et <code>getItem</code> ne manipulent que des <b>chaînes de caractères</b>. Si tu essaies d'y stocker directement un objet, JS le convertit silencieusement en la chaîne <code>"[object Object]"</code> — inutilisable.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">user</span> = { nom: <span class="str">"Nerija"</span>, score: <span class="num">42</span> };
localStorage.<span class="fn">setItem</span>(<span class="str">"user"</span>, user); <span class="cmt">// ❌ piège !</span>
<span class="fn">console</span>.<span class="fn">log</span>(localStorage.<span class="fn">getItem</span>(<span class="str">"user"</span>)); <span class="cmt">// "[object Object]" — perdu</span></div></div>
<p>La solution : passer par le format <b>JSON</b>, un format texte universel.</p></div>

<div class="theory-block"><h3>➡️ 18.4 — JSON.stringify : objet vers texte</h3><p><code>JSON.stringify()</code> transforme n'importe quelle structure JS en une chaîne fidèle, prête à être stockée.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">user</span> = { nom: <span class="str">"Nerija"</span>, score: <span class="num">42</span> };
<span class="kw">const</span> <span class="var">texte</span> = <span class="fn">JSON.stringify</span>(user);
<span class="fn">console</span>.<span class="fn">log</span>(texte); <span class="cmt">// '{"nom":"Nerija","score":42}' — une VRAIE string</span>
localStorage.<span class="fn">setItem</span>(<span class="str">"user"</span>, texte); <span class="cmt">// ✅ maintenant ça marche</span></div></div></div>

<div class="theory-block"><h3>⬅️ 18.5 — JSON.parse : texte vers objet</h3><p><code>JSON.parse()</code> fait l'inverse : elle relit une chaîne JSON et reconstruit l'objet d'origine, avec les bons types.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">saved</span> = <span class="fn">JSON.parse</span>(localStorage.<span class="fn">getItem</span>(<span class="str">"user"</span>));
<span class="fn">console</span>.<span class="fn">log</span>(saved.nom);           <span class="cmt">// "Nerija"</span>
<span class="fn">console</span>.<span class="fn">log</span>(<span class="kw">typeof</span> saved.score); <span class="cmt">// "number", pas "string" !</span></div></div>
<div class="tip-box"><strong>💡 Le duo à retenir :</strong> avant de stocker, <code>JSON.stringify()</code>. Après avoir récupéré, <code>JSON.parse()</code>.</div></div>

<div class="theory-block"><h3>⚠️ 18.6 — Limites et bonnes pratiques</h3><p>localStorage n'est pas une base de données : capacité limitée (5-10 Mo), propre à un domaine, et <b>pas sécurisé</b> — n'y stocke jamais de mot de passe. <code>getItem()</code> renvoie <code>null</code> si la clé n'existe pas — vérifie avant d'appeler <code>JSON.parse(null)</code>.</p></div>`,starter:`// Jour 18 — JSON & Stockage
const fakeStorage = {};

function sauvegarder(cle, valeur) {
  fakeStorage[cle] = JSON.stringify(valeur);
  console.log(\`✅ Sauvegardé : "\${cle}"\`);
}

function recuperer(cle) {
  const data = fakeStorage[cle];
  return data ? JSON.parse(data) : null;
}

// Sauvegarde de la progression du bootcamp
const progression = {
  etudiant: "Nerija",
  joursCompletes: 18,
  notesMoyennes: 16.5,
  dernierAcces: new Date().toLocaleDateString("fr-FR")
};

sauvegarder("bootcamp_progress", progression);
const data = recuperer("bootcamp_progress");
console.log("Progression récupérée :", data);
console.log(\`\${data.etudiant} : jour \${data.joursCompletes}/30\`);`,quiz:[{q:"localStorage stocke des ?",opts:["Objets JS","Strings uniquement","Nombres","Tableaux"],ans:1},{q:"JSON.parse() fait quoi ?",opts:["Convertit objet en string","Convertit string en objet","Supprime des données","Encode en base64"],ans:1},{q:"Pour stocker un objet dans localStorage ?",opts:["Directement","JSON.stringify() d'abord","JSON.parse() d'abord","Impossible"],ans:1}]},
    {d:19,title:"Regex — Expressions régulières",sub:"Recherche et validation de texte",level:"hard",theory:`<div class="theory-block"><h3>🔍 19.1 — Pourquoi les regex existent</h3><p>Valider un email, extraire tous les hashtags d'un post, vérifier qu'un mot de passe contient un chiffre — ce sont des recherches de <b>motifs</b> dans du texte. Les <b>expressions régulières</b> (regex) sont un mini-langage dédié à décrire ces motifs de façon compacte.</p></div>

<div class="theory-block"><h3>✏️ 19.2 — Créer un pattern : la syntaxe /.../</h3><p>En JS, une regex s'écrit entre deux barres obliques : <code>/pattern/</code>. Chaque caractère normal se cherche lui-même — <code>/chat/</code> cherche littéralement "chat".</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">motLitteral</span> = <span class="op">/chat/</span>;
<span class="fn">console</span>.<span class="fn">log</span>(motLitteral.<span class="fn">test</span>(<span class="str">"J'adore mon chat"</span>)); <span class="cmt">// true</span></div></div></div>

<div class="theory-block"><h3>🧬 19.3 — Classes de caractères et quantificateurs</h3><p><code>\\d</code> un chiffre, <code>\\w</code> un caractère "mot", <code>\\s</code> un espace. Quantificateurs : <code>+</code> (une ou plusieurs fois), <code>*</code> (zéro ou plusieurs), <code>?</code> (zéro ou une), <code>{8,15}</code> (entre 8 et 15 fois).</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">phoneRegex</span> = <span class="op">/^\\+?[\\d\\s-]{8,15}$/</span>;
<span class="fn">console</span>.<span class="fn">log</span>(phoneRegex.<span class="fn">test</span>(<span class="str">"+225 07 12 34 56"</span>)); <span class="cmt">// true</span></div></div></div>

<div class="theory-block"><h3>⚓ 19.4 — Ancres : verrouiller le début et la fin</h3><p><code>^</code> ancre au début, <code>$</code> à la fin. Sans elles, une regex accepte un motif présent n'importe où.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">emailRegex</span> = <span class="op">/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/</span>;
<span class="fn">console</span>.<span class="fn">log</span>(emailRegex.<span class="fn">test</span>(<span class="str">"nerija@ci.dev"</span>));     <span class="cmt">// true</span>
<span class="fn">console</span>.<span class="fn">log</span>(emailRegex.<span class="fn">test</span>(<span class="str">"pas-un-email"</span>));   <span class="cmt">// false</span></div></div>
<div class="tip-box"><strong>⚠️ Piège :</strong> le point <code>.</code> dans une regex signifie "n'importe quel caractère" — échappe-le avec <code>\\.</code> pour un point littéral.</div></div>

<div class="theory-block"><h3>🎯 19.5 — .test() pour valider, .match() pour extraire</h3><p><code>.test(str)</code> renvoie <code>true</code>/<code>false</code>. <code>str.match(regex)</code> renvoie un tableau des correspondances. Avec le flag <code>g</code> (global), la recherche continue jusqu'à la fin.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">post</span> = <span class="str">"J'apprends #JavaScript et #React !"</span>;
<span class="fn">console</span>.<span class="fn">log</span>(post.<span class="fn">match</span>(<span class="op">/#\\w+/g</span>)); <span class="cmt">// ["#JavaScript", "#React"]</span></div></div></div>

<div class="theory-block"><h3>🔁 19.6 — .replace() : chercher ET remplacer</h3><p><code>str.replace(regex, remplacement)</code> combine recherche et substitution.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">texte</span> = <span class="str">"JS est super, JS est rapide"</span>;
<span class="fn">console</span>.<span class="fn">log</span>(texte.<span class="fn">replace</span>(<span class="op">/JS/g</span>, <span class="str">"JavaScript"</span>));</div></div>
<div class="tip-box"><strong>💡 Pense-bête :</strong> <code>.match()</code> renvoie <code>null</code> si rien ne correspond — d'où le réflexe <code>texte.match(regex) || []</code>.</div></div>`,starter:`// Jour 19 — Regex
function validerEmail(email) {
  const regex = /^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/;
  return regex.test(email);
}

function validerTelephone(tel) {
  const regex = /^\\+?[\\d\\s]{8,15}$/;
  return regex.test(tel);
}

function extraireHashtags(texte) {
  return texte.match(/#\\w+/g) || [];
}

const emails = ["nerija@ci.dev", "pas.un.email", "test@test.com", "invalide@"];
emails.forEach(e => console.log(\`\${e}: \${validerEmail(e) ? "✅" : "❌"}\`));

const post = "J'apprends #JavaScript et #React avec #Anthropic !";
console.log("Hashtags :", extraireHashtags(post));`,quiz:[{q:"regex.test(str) retourne ?",opts:["Le match trouvé","true ou false","Le nombre de matches","undefined"],ans:1},{q:"Le flag g dans /pattern/g signifie ?",opts:["Global (tous les matches)","Greedy","Groupé","Genre"],ans:0},{q:"str.match(regex) retourne ?",opts:["true/false","Un tableau de matches","Le premier match","undefined"],ans:1}]},
    {d:20,title:"Itérateurs & Générateurs",sub:"Symbol.iterator, function*, yield",level:"hard",theory:`<div class="theory-block"><h3>🔁 20.1 — Ce qui se cache derrière for...of</h3><p>Tu utilises <code>for...of</code> sur des tableaux sans jamais te demander comment il "sait" parcourir chaque élément. La réponse : tout objet parcourable implémente en coulisses le <b>protocole itérateur</b>. Les générateurs sont le moyen le plus simple d'écrire toi-même un objet qui respecte ce contrat.</p></div>

<div class="theory-block"><h3>⏸️ 20.2 — function* et yield : une fonction qu'on peut mettre en pause</h3><p>Une <b>fonction génératrice</b>, déclarée avec une étoile — <code>function*</code> — peut se <b>mettre en pause</b> à un point précis, marqué par <code>yield</code>, et reprendre exactement où elle s'était arrêtée. Appeler une fonction génératrice ne l'exécute même pas immédiatement : ça renvoie un objet <b>générateur</b>.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">function*</span> <span class="fn">suite</span>(<span class="var">debut</span>) {
  <span class="kw">let</span> <span class="var">n</span> = debut;
  <span class="kw">while</span> (<span class="kw">true</span>) {
    <span class="kw">yield</span> n++; <span class="cmt">// pause ici, renvoie n, incrémente au réveil suivant</span>
  }
}

<span class="kw">const</span> <span class="var">gen</span> = <span class="fn">suite</span>(<span class="num">1</span>); <span class="cmt">// rien ne s'exécute encore !</span></div></div></div>

<div class="theory-block"><h3>🎮 20.3 — .next() : la télécommande du générateur</h3><p>Chaque appel à <code>.next()</code> renvoie un objet à deux propriétés : <code>value</code> et <code>done</code> (vrai une fois épuisé).</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">gen</span> = <span class="fn">suite</span>(<span class="num">1</span>);
<span class="fn">console</span>.<span class="fn">log</span>(gen.<span class="fn">next</span>()); <span class="cmt">// { value: 1, done: false }</span>
<span class="fn">console</span>.<span class="fn">log</span>(gen.<span class="fn">next</span>()); <span class="cmt">// { value: 2, done: false }</span>
<span class="fn">console</span>.<span class="fn">log</span>(gen.<span class="fn">next</span>().value); <span class="cmt">// 3</span></div></div></div>

<div class="theory-block"><h3>♾️ 20.4 — Le superpouvoir : la production à la demande</h3><p>Un générateur peut représenter une séquence <b>infinie</b> sans jamais faire exploser la mémoire, puisqu'aucune valeur n'est calculée avant qu'on la demande.</p></div>

<div class="theory-block"><h3>🐇 20.5 — Cas concret : la suite de Fibonacci</h3><p>Le starter du jour applique ce principe à la suite de Fibonacci.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">function*</span> <span class="fn">fibonacci</span>() {
  <span class="kw">let</span> <span class="var">a</span> = <span class="num">0</span>, <span class="var">b</span> = <span class="num">1</span>;
  <span class="kw">while</span> (<span class="kw">true</span>) {
    <span class="kw">yield</span> a;
    [a, b] = [b, a + b];
  }
}</div></div></div>

<div class="theory-block"><h3>📐 20.6 — Générateur vs tableau : quand utiliser quoi</h3><p>Un générateur devient précieux dès que la séquence est potentiellement infinie. Pour convertir en tableau, on combine avec <code>Array.from()</code>.</p>
<div class="tip-box"><strong>💡 À retenir :</strong> un générateur ne se "rejoue" jamais — une fois épuisé, il faut en recréer un nouveau.</div></div>`,starter:`// Jour 20 — Générateurs
function* fibonacci() {
  let a = 0, b = 1;
  while (true) {
    yield a;
    [a, b] = [b, a + b];
  }
}

const fib = fibonacci();
console.log("Séquence de Fibonacci :");
for (let i = 0; i < 10; i++) {
  console.log(fib.next().value);
}

// Version simplifiée
const fib2 = fibonacci();
const dix = Array.from({ length: 10 }, () => fib2.next().value);
console.log("10 premiers :", dix.join(", "));`,quiz:[{q:"function* crée un ?",opts:["Générateur","Classe","Objet","Module"],ans:0},{q:"yield dans un générateur...",opts:["Retourne et termine","Retourne et met en pause","Appelle la prochaine itération","Lance une erreur"],ans:1},{q:"gen.next() retourne ?",opts:["La valeur seule","{ value, done }","null","Une Promise"],ans:1}]},
    {d:21,title:"Proxy & Reflect",sub:"Intercepter les opérations sur les objets",level:"hard",theory:`<div class="theory-block"><h3>🔮 21.1 — Le problème : surveiller ce qui se passe sur un objet</h3><p>Un objet JS est une boîte passive : on lit ses propriétés, on les modifie, sans que l'objet lui-même ne réagisse. Si tu voulais qu'un objet <b>valide automatiquement</b> chaque écriture, ou <b>logue</b> chaque lecture, il te faudrait intercepter les opérations de base — c'est précisément ce que fait <b>Proxy</b>.</p></div>

<div class="theory-block"><h3>🏗️ 21.2 — new Proxy(target, handler) : la structure de base</h3><p>Un Proxy s'enroule autour d'un objet <b>cible</b> et intercepte les opérations grâce à un objet <b>handler</b>, qui contient des fonctions appelées <b>traps</b> ("pièges") — une par type d'opération.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">cible</span> = { nom: <span class="str">"Nerija"</span> };
<span class="kw">const</span> <span class="var">handler</span> = {}; <span class="cmt">// handler vide = comportement identique à l'objet normal</span>
<span class="kw">const</span> <span class="var">p</span> = <span class="kw">new</span> Proxy(cible, handler);
<span class="fn">console</span>.<span class="fn">log</span>(p.nom); <span class="cmt">// "Nerija" — transparent sans traps définis</span></div></div></div>

<div class="theory-block"><h3>👁️ 21.3 — Le trap get : intercepter la lecture</h3><p>La fonction <code>get(target, key)</code> du handler s'exécute à chaque lecture de propriété sur le Proxy.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">handler</span> = {
  <span class="fn">get</span>(<span class="var">target</span>, <span class="var">key</span>) {
    <span class="fn">console</span>.<span class="fn">log</span>(<span class="str">\`Lecture de \${key}\`</span>);
    <span class="kw">return</span> Reflect.<span class="fn">get</span>(target, key);
  }
};</div></div></div>

<div class="theory-block"><h3>✍️ 21.4 — Le trap set : intercepter et valider l'écriture</h3><p>Le trap <code>set(target, key, val)</code> se déclenche à chaque tentative d'assignation, permettant de <b>refuser</b> une écriture invalide en lançant une erreur.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="fn">set</span>(<span class="var">target</span>, <span class="var">key</span>, <span class="var">val</span>) {
  <span class="kw">if</span> (<span class="kw">typeof</span> val !== <span class="str">"number"</span>) <span class="kw">throw new</span> <span class="fn">TypeError</span>(<span class="str">"Nombre requis"</span>);
  <span class="kw">return</span> Reflect.<span class="fn">set</span>(target, key, val);
}</div></div>
<div class="tip-box"><strong>⚠️ Piège fréquent :</strong> un trap <code>set</code> doit renvoyer <code>true</code> en cas de succès (c'est ce que fait <code>Reflect.set</code>).</div></div>

<div class="theory-block"><h3>🪞 21.5 — Reflect : le partenaire naturel de Proxy</h3><p><code>Reflect</code> regroupe des versions "fonction" des opérations internes de JS : <code>Reflect.get(obj, key)</code> équivaut à <code>obj[key]</code>. Dans un trap Proxy, on délègue quasi systématiquement le "vrai travail" à la méthode <code>Reflect</code> correspondante, après avoir fait sa propre vérification.</p></div>

<div class="theory-block"><h3>🎯 21.6 — Cas d'usage réels</h3><p>Les Proxy sont au cœur de la <b>réactivité</b> de Vue.js, servent à créer des objets en <b>lecture seule</b>, à fournir des <b>valeurs par défaut</b> intelligentes, ou à <b>logger</b> tout accès à un objet sensible.</p>
<div class="tip-box"><strong>💡 Résumé :</strong> le handler ne contient QUE les traps dont tu as besoin — toute opération sans trap défini se comporte comme sur l'objet normal.</div></div>`,starter:`// Jour 21 — Proxy
const creerObjetValide = (schema) => {
  return new Proxy({}, {
    set(target, key, value) {
      if (!(key in schema)) throw new Error(\`Clé '\${key}' non autorisée\`);
      if (typeof value !== schema[key]) throw new TypeError(\`'\${key}' doit être de type \${schema[key]}\`);
      target[key] = value;
      console.log(\`✅ \${key} = \${value}\`);
      return true;
    },
    get(target, key) {
      return key in target ? target[key] : undefined;
    }
  });
};

const user = creerObjetValide({ nom: "string", age: "number" });
user.nom = "Nerija";
user.age = 18;
console.log("nom :", user.nom);

try {
  user.age = "dix-huit"; // Erreur de type
} catch (e) {
  console.log("❌", e.message);
}`,quiz:[{q:"Proxy intercepte quoi ?",opts:["Seulement la lecture","Seulement l'écriture","Toutes les opérations d'un objet","Uniquement les méthodes"],ans:2},{q:"Reflect.get(target, key) équivaut à ?",opts:["target.delete(key)","target[key]","key.get(target)","Object.get(target, key)"],ans:1},{q:"Le handler d'un Proxy contient ?",opts:["Les données","Les 'traps' (intercepteurs)","Les méthodes de l'objet","Les imports"],ans:1}]}
  ]},
  {week:"Semaine 4 — Pro",days:[
    {d:22,title:"Design Patterns",sub:"Module, Factory, Observer, Singleton",level:"hard",theory:`<div class="theory-block"><h3>🏗️ 22.1 — Pourquoi des "design patterns" ?</h3><p>Un design pattern est une <b>solution éprouvée</b> à un problème d'architecture qui revient sans cesse. Connaître ces patterns, c'est disposer d'un vocabulaire partagé avec d'autres développeurs. On regarde ici trois patterns parmi les plus utilisés : le <b>Singleton</b>, l'<b>Observer</b> et la <b>Factory</b>.</p></div>

<div class="theory-block"><h3>🔒 22.2 — Le Singleton : garantir une seule instance</h3><p>Certaines ressources n'ont aucun sens en plusieurs exemplaires : la configuration globale, une connexion unique à une base de données. Le Singleton garantit que <code>new MaClasse()</code> renvoie toujours <b>la même instance</b>.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">class</span> <span class="fn">Config</span> {
  <span class="kw">static</span> instance = <span class="kw">null</span>;

  <span class="fn">constructor</span>() {
    <span class="kw">if</span> (Config.instance) <span class="kw">return</span> Config.instance;
    <span class="kw">this</span>.settings = { theme: <span class="str">"dark"</span>, lang: <span class="str">"fr"</span> };
    Config.instance = <span class="kw">this</span>;
  }
}

<span class="kw">const</span> <span class="var">c1</span> = <span class="kw">new</span> <span class="fn">Config</span>();
<span class="kw">const</span> <span class="var">c2</span> = <span class="kw">new</span> <span class="fn">Config</span>();
<span class="fn">console</span>.<span class="fn">log</span>(c1 === c2); <span class="cmt">// true — c'est le même objet !</span></div></div>
<div class="tip-box"><strong>⚠️ Piège :</strong> un Singleton, c'est un état global déguisé — pratique en config, dangereux si utilisé partout.</div></div>

<div class="theory-block"><h3>📡 22.3 — L'Observer : agir à distance, sans couplage</h3><p>Une sonnette n'a pas besoin de savoir qui va l'entendre. L'Observer (pub/sub) suit ce principe : un émetteur garde une liste d'abonnés, et prévient tout le monde sans connaître leur détail.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">class</span> <span class="fn">EventBus</span> {
  <span class="fn">constructor</span>() { <span class="kw">this</span>.listeners = {}; }
  <span class="fn">on</span>(<span class="var">event</span>, <span class="var">fn</span>) {
    (<span class="kw">this</span>.listeners[event] ||= []).<span class="fn">push</span>(fn);
  }
  <span class="fn">emit</span>(<span class="var">event</span>, <span class="var">data</span>) {
    (<span class="kw">this</span>.listeners[event] || []).<span class="fn">forEach</span>(<span class="var">fn</span> => <span class="fn">fn</span>(data));
  }
}

<span class="kw">const</span> <span class="var">bus</span> = <span class="kw">new</span> <span class="fn">EventBus</span>();
bus.<span class="fn">on</span>(<span class="str">"connexion"</span>, <span class="var">user</span> => <span class="fn">console</span>.<span class="fn">log</span>(user + <span class="str">" connecté !"</span>));
bus.<span class="fn">emit</span>(<span class="str">"connexion"</span>, <span class="str">"Nerija"</span>);</div></div>
<p>L'opérateur <code>||=</code> crée le tableau de listeners <b>seulement s'il n'existe pas déjà</b>, en une ligne.</p></div>

<div class="theory-block"><h3>🏭 22.4 — La Factory : fabriquer sans imposer le "new"</h3><p>Le Factory Pattern déplace la décision "quoi construire" dans une fonction dédiée, en fonction de ce qu'on lui demande.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">function</span> <span class="fn">creerNotification</span>(<span class="var">type</span>, <span class="var">message</span>) {
  <span class="kw">switch</span> (type) {
    <span class="kw">case</span> <span class="str">"succes"</span>: <span class="kw">return</span> { message, icone: <span class="str">"✅"</span> };
    <span class="kw">case</span> <span class="str">"erreur"</span>:  <span class="kw">return</span> { message, icone: <span class="str">"❌"</span> };
    <span class="kw">default</span>:      <span class="kw">return</span> { message, icone: <span class="str">"ℹ️"</span> };
  }
}</div></div>
<p>Avantage : le jour où tu ajoutes un nouveau type, tu modifies <b>un seul endroit</b> — la Factory.</p></div>`,starter:`// Jour 22 — Design Patterns
// Singleton Pattern
class Config {
  static instance = null;
  constructor() {
    if (Config.instance) return Config.instance;
    this.settings = { theme: "dark", lang: "fr" };
    Config.instance = this;
  }
}

const c1 = new Config();
const c2 = new Config();
console.log(c1 === c2); // true — même instance !

// Observer Pattern
class EventBus {
  constructor() { this.listeners = {}; }
  on(event, fn) { (this.listeners[event] ||= []).push(fn); }
  emit(event, data) { (this.listeners[event] || []).forEach(fn => fn(data)); }
}

const bus = new EventBus();
bus.on("connexion", user => console.log(\`\${user} connecté !\`));
bus.on("connexion", user => console.log(\`Bienvenue, \${user}\`));
bus.emit("connexion", "Nerija");`,quiz:[{q:"Le Singleton garantit ?",opts:["Plusieurs instances","Une seule instance","Aucune instance","Des instances en cache"],ans:1},{q:"L'Observer Pattern est basé sur ?",opts:["L'héritage","Les événements et abonnements","Les Promises","Les Proxies"],ans:1},{q:"Le Factory Pattern crée ?",opts:["Des singletons","Des instances sans new","Des modules","Des classes abstraites"],ans:1}]},
    {d:23,title:"Functional Programming",sub:"Pure functions, immutabilité, currying",level:"hard",theory:`<div class="theory-block"><h3>⚡ 23.1 — La programmation fonctionnelle : un autre état d'esprit</h3><p>Jusqu'ici, tu as surtout écrit du code qui modifie des variables au fil du temps. La programmation fonctionnelle (FP) propose une autre approche : construire ton programme en <b>composant des fonctions</b> qui transforment des données sans jamais les modifier sur place.</p></div>

<div class="theory-block"><h3>🧼 23.2 — Fonctions pures : zéro effet de bord</h3><p>Une fonction est <b>pure</b> si : (1) pour les mêmes arguments, elle renvoie toujours le même résultat, et (2) elle ne modifie rien en dehors d'elle-même.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="cmt">// Pure : dépend uniquement de ses paramètres</span>
<span class="kw">const</span> <span class="fn">double</span> = <span class="var">x</span> => x * <span class="num">2</span>;</div></div>
<div class="tip-box"><strong>💡 Repère rapide :</strong> si tu peux remplacer un appel de fonction par sa valeur de retour sans rien changer, elle est pure.</div></div>

<div class="theory-block"><h3>🧊 23.3 — Immutabilité : ne jamais modifier, toujours recréer</h3><p>Muter une donnée partagée peut devenir une source de bugs sournois. L'approche immuable produit toujours une <b>nouvelle</b> copie modifiée, en laissant l'originale intacte.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">notes</span> = [<span class="num">10</span>, <span class="num">12</span>, <span class="num">14</span>];
<span class="kw">const</span> <span class="var">nouvellesNotes</span> = [...notes, <span class="num">16</span>]; <span class="cmt">// nouvelle copie</span>
<span class="fn">console</span>.<span class="fn">log</span>(notes); <span class="cmt">// [10, 12, 14] — inchangé</span></div></div></div>

<div class="theory-block"><h3>🍰 23.4 — Le currying : découper les arguments un par un</h3><p>Curryfier une fonction, c'est transformer <code>f(a, b)</code> en <code>a => b => résultat</code>. On peut "figer" le premier argument.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="fn">multiplierPar</span> = <span class="var">n</span> => <span class="var">x</span> => x * n;
<span class="kw">const</span> <span class="fn">doubler</span> = <span class="fn">multiplierPar</span>(<span class="num">2</span>);
<span class="fn">console</span>.<span class="fn">log</span>(<span class="fn">doubler</span>(<span class="num">5</span>));  <span class="cmt">// 10</span></div></div></div>

<div class="theory-block"><h3>🔗 23.5 — compose et pipe : chaîner les transformations</h3><p><code>pipe</code> applique de gauche à droite ; <code>compose</code> de droite à gauche. Les deux reposent sur <code>reduce</code>.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="fn">pipe</span> = (...<span class="var">fns</span>) => <span class="var">x</span> => fns.<span class="fn">reduce</span>((<span class="var">v</span>, <span class="var">f</span>) => <span class="fn">f</span>(v), x);

<span class="kw">const</span> <span class="fn">trim</span> = <span class="var">s</span> => s.<span class="fn">trim</span>();
<span class="kw">const</span> <span class="fn">toLower</span> = <span class="var">s</span> => s.<span class="fn">toLowerCase</span>();
<span class="kw">const</span> <span class="fn">slugify</span> = <span class="fn">pipe</span>(trim, toLower);
<span class="fn">console</span>.<span class="fn">log</span>(<span class="fn">slugify</span>(<span class="str">"  Nerija  "</span>));</div></div>
<p>Chaque petite fonction reste testable isolément, et le pipeline se lit comme une phrase.</p></div>`,starter:`// Jour 23 — Functional Programming
const compose = (...fns) => x => fns.reduceRight((v, f) => f(v), x);
const pipe = (...fns) => x => fns.reduce((v, f) => f(v), x);

// Fonctions pures
const trim = str => str.trim();
const toLower = str => str.toLowerCase();
const capitaliser = str => str.charAt(0).toUpperCase() + str.slice(1);
const enleverEspaces = str => str.replace(/\\s+/g, "-");

// Pipeline de transformation
const slugify = pipe(trim, toLower, enleverEspaces);
console.log(slugify("  Nerija Apprend JavaScript  "));

// Currying
const multiplierPar = n => x => x * n;
const doubler = multiplierPar(2);
const tripler = multiplierPar(3);
const notes = [10, 12, 14, 16];
console.log("Doublés :", notes.map(doubler));
console.log("Triplés :", notes.map(tripler));`,quiz:[{q:"Une fonction pure dépend de ?",opts:["Variables globales","Seulement de ses paramètres","L'état externe","Des effets de bord"],ans:1},{q:"Currying transforme f(a,b) en ?",opts:["f(a+b)","a => b => résultat","f([a,b])","new f(a,b)"],ans:1},{q:"L'immutabilité signifie ?",opts:["Toujours retourner null","Ne jamais modifier les données originales","Utiliser const partout","Pas de variables"],ans:1}]},
    {d:24,title:"Performance & Optimisation",sub:"Memoization, debounce, throttle, WeakMap",level:"hard",theory:`<div class="theory-block"><h3>🚀 24.1 — Pourquoi optimiser ?</h3><p>Certaines fonctions sont appelées des milliers de fois, d'autres recalculent inutilement un résultat déjà connu. Trois outils reviennent sans cesse : la <b>memoization</b>, le <b>debounce/throttle</b> et <b>WeakMap</b>.</p></div>

<div class="theory-block"><h3>🧠 24.2 — La memoization : ne jamais recalculer deux fois</h3><p>Pour un calcul coûteux mais déterministe, on garde les résultats dans un cache.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">function</span> <span class="fn">memoize</span>(<span class="var">fn</span>) {
  <span class="kw">const</span> <span class="var">cache</span> = <span class="kw">new</span> Map();
  <span class="kw">return</span> (...<span class="var">args</span>) => {
    <span class="kw">const</span> <span class="var">key</span> = <span class="fn">JSON.stringify</span>(args);
    <span class="kw">if</span> (cache.<span class="fn">has</span>(key)) <span class="kw">return</span> cache.<span class="fn">get</span>(key); <span class="cmt">// cache hit</span>
    <span class="kw">const</span> <span class="var">result</span> = <span class="fn">fn</span>(...args);
    cache.<span class="fn">set</span>(key, result);
    <span class="kw">return</span> result;
  };
}</div></div></div>

<div class="theory-block"><h3>⏱️ 24.3 — Debounce et throttle : dompter les événements trop fréquents</h3><p><b>Debounce</b> attend que l'utilisateur arrête d'agir avant d'exécuter (idéal pour une recherche). <b>Throttle</b> exécute au maximum une fois toutes les X ms (idéal pour un scroll).</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">function</span> <span class="fn">debounce</span>(<span class="var">fn</span>, <span class="var">delai</span>) {
  <span class="kw">let</span> <span class="var">timer</span>;
  <span class="kw">return</span> (...<span class="var">args</span>) => {
    <span class="fn">clearTimeout</span>(timer);
    timer = <span class="fn">setTimeout</span>(() => <span class="fn">fn</span>(...args), delai);
  };
}</div></div>
<div class="tip-box"><strong>💡 Mnémotechnique :</strong> debounce = "attends que ça se calme" ; throttle = "au plus une fois toutes les X ms".</div></div>

<div class="theory-block"><h3>🗑️ 24.4 — WeakMap : laisser le ramasse-miettes travailler</h3><p>Un <code>Map</code> classique garde une référence <b>forte</b> vers ses clés — elles ne peuvent jamais être libérées. <code>WeakMap</code> garde une référence <b>faible</b> : si l'objet-clé n'est plus référencé ailleurs, le garbage collector peut le supprimer.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">metadonnees</span> = <span class="kw">new</span> WeakMap();
<span class="kw">let</span> <span class="var">utilisateur</span> = { nom: <span class="str">"Nerija"</span> };
metadonnees.<span class="fn">set</span>(utilisateur, { derniereConnexion: <span class="str">"2026-09-01"</span> });</div></div>
<p>Contrepartie : un <code>WeakMap</code> n'est ni énumérable ni itérable.</p></div>`,starter:`// Jour 24 — Performance
function memoize(fn) {
  const cache = new Map();
  return function(...args) {
    const key = JSON.stringify(args);
    if (cache.has(key)) {
      console.log("⚡ Cache hit !");
      return cache.get(key);
    }
    const result = fn(...args);
    cache.set(key, result);
    return result;
  };
}

// Fibonacci sans memoize = très lent pour grands n
const fib = memoize(function(n) {
  if (n <= 1) return n;
  return fib(n - 1) + fib(n - 2);
});

console.time("fib(40)");
console.log("fib(40) =", fib(40));
console.timeEnd("fib(40)");

console.log("fib(40) =", fib(40)); // Cache hit !`,quiz:[{q:"La memoization sert à ?",opts:["Compresser le code","Mettre en cache les résultats","Déboguer","Minifier"],ans:1},{q:"Debounce est utile pour ?",opts:["Accélérer les boucles","Limiter les appels répétitifs (ex: frappe clavier)","Mémoriser des fonctions","Paralléliser du code"],ans:1},{q:"WeakMap vs Map : la différence principale ?",opts:["WeakMap est plus rapide","WeakMap laisse le GC nettoyer les clés","WeakMap accepte des strings","Map est plus récent"],ans:1}]},
    {d:25,title:"Tests unitaires",sub:"Jest, expect, describe, it",level:"hard",theory:`<div class="theory-block"><h3>🧪 25.1 — Pourquoi tester son code ?</h3><p>Dès qu'un projet grossit, relire à l'œil devient impossible, et une modification anodine peut casser silencieusement une fonctionnalité ailleurs. Les tests automatisés remplacent cette vérification manuelle par du code qui vérifie du code. <b>Jest</b> est l'un des frameworks de test JS les plus utilisés en entreprise.</p></div>

<div class="theory-block"><h3>📦 25.2 — Anatomie d'un test : describe, it, expect</h3><p><code>describe(nom, fonction)</code> regroupe des tests liés. <code>it(nom, fonction)</code> décrit un cas précis. <code>expect(valeur)</code> enveloppe la valeur obtenue et expose des <b>matchers</b>.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="fn">describe</span>(<span class="str">"Fonctions mathématiques"</span>, () => {
  <span class="fn">it</span>(<span class="str">"additionne correctement"</span>, () => {
    <span class="fn">expect</span>(<span class="fn">ajouter</span>(<span class="num">2</span>, <span class="num">3</span>)).<span class="fn">toBe</span>(<span class="num">5</span>);
  });
  <span class="fn">it</span>(<span class="str">"gère les négatifs"</span>, () => {
    <span class="fn">expect</span>(<span class="fn">ajouter</span>(-<span class="num">1</span>, -<span class="num">1</span>)).<span class="fn">toBe</span>(-<span class="num">2</span>);
  });
});</div></div>
<p>Un <code>it</code> par comportement précis : si le test échoue, tu sais exactement lequel a cassé.</p></div>

<div class="theory-block"><h3>🔍 25.3 — Les matchers : toBe, toEqual</h3><p><code>toBe()</code> vérifie une égalité <b>stricte</b> (<code>===</code>) — parfait pour nombres, chaînes, booléens. Pour des objets ou tableaux, utilise <code>toEqual()</code>, qui compare le <b>contenu</b>.</p>
<div class="tip-box"><strong>⚠️ Piège fréquent :</strong> comparer deux objets avec <code>toBe()</code> échoue presque toujours, même avec le même contenu.</div></div>

<div class="theory-block"><h3>🔬 25.4 — Test unitaire vs test d'intégration</h3><p>Un <b>test unitaire</b> vérifie une seule fonction isolée, sans dépendance externe. Un <b>test d'intégration</b> vérifie que plusieurs unités fonctionnent correctement <b>ensemble</b>.</p>
<div class="tip-box"><strong>💡 Bonne pratique :</strong> beaucoup de tests unitaires rapides à la base, quelques tests d'intégration au milieu.</div></div>`,starter:`// Jour 25 — Tests (simulation de Jest)
let passed = 0, failed = 0;

function expect(received) {
  return {
    toBe(expected) {
      if (received === expected) {
        console.log(\`  ✅ Attendu: \${expected}, Reçu: \${received}\`);
        passed++;
      } else {
        console.log(\`  ❌ Attendu: \${expected}, Reçu: \${received}\`);
        failed++;
      }
    },
    toEqual(expected) { this.toBe(JSON.stringify(received) === JSON.stringify(expected) ? expected : received); }
  };
}

function describe(name, fn) { console.log(\`\\n📦 \${name}\`); fn(); }
function it(name, fn) { console.log(\`  🔬 \${name}\`); fn(); }

// Fonctions à tester
const ajouter = (a, b) => a + b;
const capitaliser = s => s.charAt(0).toUpperCase() + s.slice(1);

describe("Mathématiques", () => {
  it("additionne deux nombres", () => expect(ajouter(2, 3)).toBe(5));
  it("gère les négatifs", () => expect(ajouter(-1, 5)).toBe(4));
});

describe("Strings", () => {
  it("capitalise correctement", () => expect(capitaliser("nerija")).toBe("Nerija"));
});

console.log(\`\\n📊 Résultats : \${passed} ✅ | \${failed} ❌\`);`,quiz:[{q:"toBe() dans Jest vérifie ?",opts:["L'égalité stricte","L'égalité profonde","Le type seulement","Le nom de la variable"],ans:0},{q:"describe() dans Jest sert à ?",opts:["Décrire une variable","Grouper des tests","Créer une fonction","Importer Jest"],ans:1},{q:"Qu'est-ce qu'un test unitaire ?",opts:["Tester une seule ligne","Tester une unité fonctionnelle isolée","Tester toute l'app","Tester le réseau"],ans:1}]},
    {d:26,title:"Node.js — Côté serveur",sub:"fs, http, modules natifs",level:"hard",theory:`<div class="theory-block"><h3>🖥️ 26.1 — Node.js : JavaScript hors du navigateur</h3><p>Node.js fait tourner le moteur V8 de Chrome <b>en dehors</b> du navigateur, directement sur ta machine ou un serveur. Plus de DOM — à la place, un accès direct au système de fichiers, au réseau. C'est ce qui permet d'écrire un serveur web entier en JavaScript.</p></div>

<div class="theory-block"><h3>📦 26.2 — Modules : organiser son code sur plusieurs fichiers</h3><p>Chaque module expose ce qu'il veut rendre public via <code>module.exports</code>, et un autre fichier le récupère avec <code>require()</code> — le système CommonJS.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="cmt">// fichier maths.js</span>
<span class="kw">function</span> <span class="fn">addition</span>(<span class="var">a</span>, <span class="var">b</span>) { <span class="kw">return</span> a + b; }
module.exports = { addition };

<span class="cmt">// fichier app.js</span>
<span class="kw">const</span> { addition } = <span class="fn">require</span>(<span class="str">"./maths"</span>);</div></div></div>

<div class="theory-block"><h3>📁 26.3 — Le module fs : lire et écrire des fichiers</h3><p><code>fs</code> donne accès au disque. Ses fonctions existent en version <b>synchrone</b> (<code>Sync</code>, bloquante) et <b>asynchrone</b> (non bloquante, préférée en production).</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> fs = <span class="fn">require</span>(<span class="str">"fs"</span>);
fs.<span class="fn">writeFileSync</span>(<span class="str">"notes.txt"</span>, <span class="str">"18/20"</span>);
fs.<span class="fn">readFile</span>(<span class="str">"notes.txt"</span>, <span class="str">"utf8"</span>, (<span class="var">err</span>, <span class="var">data</span>) => {
  <span class="kw">if</span> (err) <span class="kw">throw</span> err;
  <span class="fn">console</span>.<span class="fn">log</span>(data);
});</div></div>
<div class="tip-box"><strong>⚠️ Piège :</strong> les méthodes <code>*Sync</code> bloquent tout le programme pendant leur exécution.</div></div>

<div class="theory-block"><h3>🌐 26.4 — Créer un serveur avec http.createServer</h3><p>Le module natif <code>http</code> crée un serveur sans dépendance externe.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> http = <span class="fn">require</span>(<span class="str">"http"</span>);

<span class="kw">const</span> <span class="var">server</span> = http.<span class="fn">createServer</span>((<span class="var">req</span>, <span class="var">res</span>) => {
  res.<span class="fn">writeHead</span>(<span class="num">200</span>, { <span class="str">"Content-Type"</span>: <span class="str">"application/json"</span> });
  res.<span class="fn">end</span>(<span class="fn">JSON.stringify</span>({ message: <span class="str">"Hello Nerija !"</span> }));
});

server.<span class="fn">listen</span>(<span class="num">3000</span>, () => <span class="fn">console</span>.<span class="fn">log</span>(<span class="str">"Serveur sur le port 3000"</span>));</div></div></div>

<div class="theory-block"><h3>⚙️ 26.5 — process : dialoguer avec l'environnement d'exécution</h3><p><code>process.argv</code> contient les arguments de ligne de commande. <code>process.env</code> donne accès aux variables d'environnement.</p></div>`,starter:`// Jour 26 — Node.js (simulation)
// Simulation du module 'fs' de Node.js
const fakeFS = {
  data: {},
  writeFileSync(path, content) {
    this.data[path] = content;
    console.log(\`📝 Fichier écrit : \${path}\`);
  },
  readFileSync(path) {
    if (!(path in this.data)) throw new Error(\`Fichier introuvable : \${path}\`);
    return this.data[path];
  },
  existsSync(path) { return path in this.data; }
};

// Simulation d'un serveur de routes
function creerRouteur() {
  const routes = {};
  return {
    get(path, handler) { routes[path] = handler; },
    simulerRequete(path) {
      const handler = routes[path] || (() => ({ status: 404, body: "Not Found" }));
      const res = handler();
      console.log(\`GET \${path} → \${res.status}: \${JSON.stringify(res.body)}\`);
    }
  };
}

const app = creerRouteur();
app.get("/", () => ({ status: 200, body: { msg: "Bienvenue !" } }));
app.get("/users", () => ({ status: 200, body: [{ id: 1, nom: "Nerija" }] }));

app.simulerRequete("/");
app.simulerRequete("/users");
app.simulerRequete("/unknown");`,quiz:[{q:"require() dans Node.js sert à ?",opts:["Demander une ressource HTTP","Importer un module","Créer un serveur","Lire un fichier"],ans:1},{q:"fs.readFileSync() est...",opts:["Asynchrone","Synchrone (bloquant)","Toujours async","Une Promise"],ans:1},{q:"process.argv en Node contient ?",opts:["Les variables d'environnement","Les arguments de ligne de commande","La mémoire utilisée","Les modules chargés"],ans:1}]},
    {d:27,title:"Express.js & REST API",sub:"Router, middleware, CRUD",level:"hard",theory:`<div class="theory-block"><h3>🚀 27.1 — Express.js : simplifier Node.js</h3><p>Écrire un serveur avec le module <code>http</code> pur devient vite pénible. <b>Express.js</b> ajoute une couche par-dessus qui gère l'analyse des routes et du corps de requête, laissant le développeur se concentrer sur la logique métier.</p></div>

<div class="theory-block"><h3>🛣️ 27.2 — Les routes : associer une URL et une méthode à une réponse</h3><p>Une route combine une <b>méthode HTTP</b> et un <b>chemin</b>. Express expose une méthode par verbe.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">const</span> express = <span class="fn">require</span>(<span class="str">"express"</span>);
<span class="kw">const</span> <span class="var">app</span> = <span class="fn">express</span>();

<span class="kw">let</span> <span class="var">users</span> = [{ id: <span class="num">1</span>, nom: <span class="str">"Nerija"</span> }];

app.<span class="fn">get</span>(<span class="str">"/users"</span>, (<span class="var">req</span>, <span class="var">res</span>) => res.<span class="fn">json</span>(users));

app.<span class="fn">get</span>(<span class="str">"/users/:id"</span>, (<span class="var">req</span>, <span class="var">res</span>) => {
  <span class="kw">const</span> <span class="var">user</span> = users.<span class="fn">find</span>(<span class="var">u</span> => u.id === <span class="fn">Number</span>(req.params.id));
  <span class="kw">if</span> (!user) <span class="kw">return</span> res.<span class="fn">status</span>(<span class="num">404</span>).<span class="fn">json</span>({ erreur: <span class="str">"Introuvable"</span> });
  res.<span class="fn">json</span>(user);
});</div></div>
<p><code>:id</code> est un <b>paramètre de route</b>, accessible via <code>req.params.id</code>.</p></div>

<div class="theory-block"><h3>🔌 27.3 — Les middlewares : le fil d'assemblage des requêtes</h3><p>Un middleware <code>(req, res, next)</code> lit ou modifie <code>req</code>/<code>res</code> avant d'appeler <code>next()</code>.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content">app.<span class="fn">use</span>(express.<span class="fn">json</span>());

app.<span class="fn">use</span>((<span class="var">req</span>, <span class="var">res</span>, <span class="var">next</span>) => {
  <span class="fn">console</span>.<span class="fn">log</span>(req.method, req.url);
  <span class="fn">next</span>();
});</div></div>
<div class="tip-box"><strong>⚠️ Piège classique :</strong> oublier <code>next()</code> bloque la requête en silence.</div></div>

<div class="theory-block"><h3>🗂️ 27.4 — CRUD : construire une API complète</h3><p><b>C</b>reate (POST), <b>R</b>ead (GET), <b>U</b>pdate (PUT/PATCH), <b>D</b>elete (DELETE).</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content">app.<span class="fn">post</span>(<span class="str">"/todos"</span>, (<span class="var">req</span>, <span class="var">res</span>) => {
  users.<span class="fn">push</span>({ id: Date.now(), ...req.body });
  res.<span class="fn">status</span>(<span class="num">201</span>).<span class="fn">json</span>({ success: <span class="kw">true</span> });
});</div></div></div>

<div class="theory-block"><h3>📮 27.5 — Les codes de statut HTTP</h3><p><b>2xx</b> — succès (200, 201, 204). <b>4xx</b> — erreur client (400, 401, 404). <b>5xx</b> — erreur serveur (500).</p></div>`,starter:`// Jour 27 — API REST (simulation Express)
function creerApp() {
  const routes = { GET: {}, POST: {}, PUT: {}, DELETE: {} };
  const middlewares = [];

  return {
    use(fn) { middlewares.push(fn); },
    get(path, fn) { routes.GET[path] = fn; },
    post(path, fn) { routes.POST[path] = fn; },
    delete(path, fn) { routes.DELETE[path] = fn; },

    request(method, path, body = null) {
      let result = null;
      const res = { status: 200, json(d) { result = d; return this; }, send(d) { result = d; } };
      const req = { body, params: {} };
      const handler = routes[method]?.[path];
      if (handler) handler(req, res);
      else result = { error: "404 Not Found" };
      console.log(\`\${method} \${path}: \${JSON.stringify(result)}\`);
    }
  };
}

const app = creerApp();
let todos = [{ id: 1, tache: "Apprendre JS", fait: false }];

app.get("/todos", (req, res) => res.json(todos));
app.post("/todos", (req, res) => {
  const todo = { id: Date.now(), ...req.body };
  todos.push(todo);
  res.json({ succes: true, todo });
});

app.request("GET", "/todos");
app.request("POST", "/todos", { tache: "Finir le bootcamp", fait: false });
app.request("GET", "/todos");`,quiz:[{q:"Un middleware Express est ?",opts:["Une route spéciale","Une fonction (req, res, next)","Un type de base de données","Un module npm"],ans:1},{q:"res.status(201).json() envoie ?",opts:["Une erreur","Un succès HTTP 201 avec du JSON","Un fichier","Une redirection"],ans:1},{q:"CRUD correspond à ?",opts:["Create Read Update Delete","Code Run Update Debug","Classes Routes Utils Data","Connect Request Update Destroy"],ans:0}]},
    {d:28,title:"TypeScript basics",sub:"Types, interfaces, generics",level:"hard",theory:`<div class="theory-block"><h3>🦺 28.1 — TypeScript : JavaScript avec un filet de sécurité</h3><p>TypeScript (TS) est un <b>sur-ensemble</b> de JavaScript qui ajoute un système de types <b>statique</b>, vérifié avant l'exécution. Un éditeur comme VS Code te signale une erreur de type pendant que tu écris — pas trois mois plus tard en production. TS se compile ensuite vers du JavaScript classique.</p></div>

<div class="theory-block"><h3>🔢 28.2 — Les types de base</h3><p>La syntaxe ajoute simplement <code>: type</code> après un nom de variable ou de paramètre.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">typescript</span></div><div class="code-content"><span class="kw">const</span> <span class="var">nom</span>: <span class="kw">string</span> = <span class="str">"Nerija"</span>;
<span class="kw">const</span> <span class="var">age</span>: <span class="kw">number</span> = <span class="num">18</span>;
<span class="kw">const</span> <span class="var">notes</span>: <span class="kw">number</span>[] = [<span class="num">14</span>, <span class="num">16</span>];

<span class="cmt">// Union de types : plusieurs types possibles</span>
<span class="kw">let</span> <span class="var">id</span>: <span class="kw">string</span> | <span class="kw">number</span>;
id = <span class="str">"abc123"</span>; <span class="cmt">// OK</span>
id = <span class="num">42</span>;       <span class="cmt">// OK aussi</span></div></div></div>

<div class="theory-block"><h3>📐 28.3 — Les interfaces : décrire la forme d'un objet</h3><p>Une <code>interface</code> décrit à quoi doit ressembler un objet. Le compilateur refuse de compiler si une propriété manque ou a le mauvais type.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">typescript</span></div><div class="code-content"><span class="kw">interface</span> <span class="fn">User</span> {
  id: <span class="kw">number</span>;
  nom: <span class="kw">string</span>;
  email?: <span class="kw">string</span>; <span class="cmt">// optionnel</span>
}

<span class="kw">function</span> <span class="fn">afficherUser</span>(<span class="var">u</span>: User): <span class="kw">void</span> {
  <span class="fn">console</span>.<span class="fn">log</span>(u.nom);
}</div></div>
<p>Le <code>?</code> après <code>email</code> signifie "cette propriété peut être présente ou absente".</p></div>

<div class="theory-block"><h3>🧩 28.4 — Les génériques : écrire une fois, typer pour n'importe quoi</h3><p>Un type "variable", noté <code>T</code> par convention, que TS remplace automatiquement par le type réel utilisé à chaque appel.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">typescript</span></div><div class="code-content"><span class="kw">function</span> <span class="fn">premier</span>&lt;T&gt;(<span class="var">arr</span>: T[]): T {
  <span class="kw">return</span> arr[<span class="num">0</span>];
}

<span class="kw">const</span> <span class="var">n</span> = <span class="fn">premier</span>&lt;<span class="kw">number</span>&gt;([<span class="num">10</span>, <span class="num">20</span>, <span class="num">30</span>]); <span class="cmt">// n est un number</span></div></div></div>

<div class="theory-block"><h3>⚙️ 28.5 — De TypeScript à JavaScript : la compilation</h3><p>Le compilateur officiel, <code>tsc</code>, transforme le fichier TS en JS classique en <b>effaçant toutes les annotations de type</b> au passage — elles n'existent que pour la vérification.</p>
<div class="tip-box"><strong>💡 En résumé :</strong> TypeScript te fait gagner du temps en attrapant les erreurs de type sur ton écran plutôt qu'en production.</div></div>`,starter:`// Jour 28 — TypeScript (simulation des types)
// En vrai TypeScript, les types sont statiques
// Voici une simulation avec validation runtime

function creerUserValide(data) {
  const erreurs = [];
  if (typeof data.nom !== "string") erreurs.push("nom doit être string");
  if (typeof data.age !== "number") erreurs.push("age doit être number");
  if (data.age < 0 || data.age > 150) erreurs.push("age invalide");
  if (erreurs.length) throw new Error(erreurs.join(", "));
  return { id: Math.random().toString(36).slice(2), ...data };
}

const users = [];

try {
  users.push(creerUserValide({ nom: "Nerija", age: 18 }));
  users.push(creerUserValide({ nom: "Flora", age: 17 }));
  console.log("✅ Users créés :", users.map(u => u.nom));

  creerUserValide({ nom: 123, age: "dix-huit" }); // Erreur !
} catch (e) {
  console.log("❌ Erreur TypeScript-like:", e.message);
}`,quiz:[{q:"TypeScript vs JavaScript : principale différence ?",opts:["TS est plus rapide","TS a un typage statique","TS est dans le navigateur","TS remplace complètement JS"],ans:1},{q:"interface en TS définit ?",opts:["Une classe abstraite","La forme d'un objet","Une fonction","Un module"],ans:1},{q:"Le ? dans une interface signifie ?",opts:["Nullable","Optionnel","Requis","Boolean"],ans:1}]},
    {d:29,title:"Projet Final — Partie 1",sub:"Mini app complète : architecture",level:"hard",theory:`<div class="theory-block"><h3>🏆 29.1 — Du prototype au projet réel : penser l'architecture avant le code</h3><p>Chaque jour a isolé une notion dans un petit bout de code autonome. Un projet réel doit faire cohabiter <b>tout ça en même temps</b> : des données, une interface, une logique qui réagit aux actions de l'utilisateur. Sans organisation, ce mélange devient vite un fichier où tout dépend de tout. On va construire un gestionnaire de tâches complet en s'appuyant sur un pattern d'architecture éprouvé : le <b>MVC</b>.</p></div>

<div class="theory-block"><h3>🗺️ 29.2 — Le pattern MVC : séparer données, affichage et logique</h3><p><b>Model</b> — porte les données et les règles métier, sans rien savoir de l'affichage. <b>View</b> — s'occupe uniquement de l'affichage, aucune règle métier. <b>Controller</b> — écoute les actions utilisateur, appelle le Model, puis demande à la View de se rafraîchir.</p>
<div class="code-block"><div class="code-header"><div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div><span class="code-lang">javascript</span></div><div class="code-content"><span class="kw">class</span> <span class="fn">TaskModel</span> { <span class="cmt">/* ajouter(), terminer(), filtrer() ... */</span> }
<span class="kw">class</span> <span class="fn">TaskView</span> { <span class="cmt">/* render(taches) ... */</span> }

<span class="kw">class</span> <span class="fn">TaskController</span> {
  <span class="fn">constructor</span>(<span class="var">model</span>, <span class="var">view</span>) {
    <span class="kw">this</span>.model = model;
    <span class="kw">this</span>.view = view;
  }
  <span class="fn">onAjouterClique</span>(<span class="var">titre</span>) {
    <span class="kw">this</span>.model.<span class="fn">ajouter</span>(titre);
    <span class="kw">this</span>.view.<span class="fn">render</span>(<span class="kw">this</span>.model.tasks);
  }
}</div></div>
<div class="tip-box"><strong>💡 Architecture MVC :</strong> Model = données, View = interface, Controller = logique. C'est la base de frameworks comme Angular, Laravel ou Django.</div></div>

<div class="theory-block"><h3>🧠 29.3 — Le Model en pratique : encapsuler l'état et les règles</h3><p>Dans le code de l'exercice, la classe <code>TaskManager</code> joue le rôle du Model : elle expose des méthodes précises (<code>ajouter()</code>, <code>terminer()</code>, <code>filtrer()</code>, <code>stats()</code>) plutôt que d'exposer directement son tableau de tâches. Cette discipline rend le Model testable indépendamment de toute interface.</p></div>

<div class="theory-block"><h3>🔜 29.4 — Ce qui t'attend au jour 30</h3><p>Le Model est posé et fonctionne en autonomie. Garde cette question en tête pour la suite : "cette ligne de code parle-t-elle de <b>données</b>, d'<b>affichage</b>, ou de <b>coordination</b> ?" Si tu sais toujours répondre, ton architecture tient la route.</p></div>`,starter:`// Jour 29 — Projet : Task Manager
class TaskManager {
  constructor() {
    this.tasks = [];
    this.nextId = 1;
  }

  ajouter(titre, priorite = "normale") {
    const task = {
      id: this.nextId++,
      titre,
      priorite,
      fait: false,
      creeLe: new Date().toLocaleDateString("fr-FR")
    };
    this.tasks.push(task);
    return task;
  }

  terminer(id) {
    const task = this.tasks.find(t => t.id === id);
    if (!task) throw new Error(\`Tâche #\${id} introuvable\`);
    task.fait = true;
    return task;
  }

  filtrer(critere) {
    if (critere === "fait") return this.tasks.filter(t => t.fait);
    if (critere === "en-cours") return this.tasks.filter(t => !t.fait);
    return this.tasks;
  }

  stats() {
    const total = this.tasks.length;
    const faites = this.tasks.filter(t => t.fait).length;
    return { total, faites, restantes: total - faites, pct: Math.round(faites/total*100) || 0 };
  }
}

const tm = new TaskManager();
tm.ajouter("Réviser les closures", "haute");
tm.ajouter("Pratiquer les Promises", "haute");
tm.ajouter("Lire sur TypeScript", "normale");
tm.ajouter("Faire le projet final", "haute");

tm.terminer(1);
tm.terminer(2);

const stats = tm.stats();
console.log(\`📊 Stats : \${stats.faites}/\${stats.total} (\${stats.pct}%)\`);
console.log("En cours :", tm.filtrer("en-cours").map(t => t.titre));`,quiz:[{q:"MVC signifie ?",opts:["Multi View Controller","Model View Controller","Module Variable Class","Main Value Core"],ans:1},{q:"Pourquoi séparer Model et View ?",opts:["Pour aller plus vite","Pour la lisibilité seulement","Pour isoler la logique de l'UI","Pour réduire le code"],ans:2},{q:"Le Controller dans MVC est responsable de ?",opts:["Stocker les données","Afficher l'interface","Coordonner Model et View","Gérer le réseau"],ans:2}]},
    {d:30,title:"Jour 30 — Tu es prêt !",sub:"Bilan, récap, next steps",level:"easy",theory:`<div class="done-banner"><div style="font-size:40px">🎉</div><p>FÉLICITATIONS ! Tu as terminé le bootcamp de 30 jours !</p></div>

<div class="theory-block"><h3>🗺️ 30.1 — Le chemin parcouru : trois paliers</h3><p><b>Fondations (jours 1-10)</b> — variables, types, conditions, boucles, fonctions, tableaux, objets : le socle sur lequel repose tout le reste.</p>
<p style="margin-top:8px"><b>Intermédiaire (jours 11-20)</b> — <code>map/filter/reduce</code>, le DOM, les closures, le spread/rest, les classes, <code>async/await</code> et la Fetch API. À ce stade, tu savais construire une vraie application interactive.</p>
<p style="margin-top:8px"><b>Avancé — Semaine Pro (jours 21-30)</b> — regex, générateurs, Proxy, design patterns, programmation fonctionnelle, performance, tests unitaires, Node.js, Express.js, TypeScript, puis l'architecture MVC d'un projet complet.</p></div>

<div class="theory-block"><h3>🧭 30.2 — Ce que "savoir JavaScript" veut dire, concrètement, maintenant</h3><p>Tu peux aujourd'hui lire un projet JS ou Node.js existant et comprendre l'essentiel de ce qu'il fait. Tu sais aussi pourquoi certains choix sont faits — pourquoi une équipe préfère <code>const</code> à <code>var</code>, pourquoi elle isole un Model d'une View, pourquoi elle écrit des tests. Ce "pourquoi" est ce qui différencie quelqu'un qui recopie du code de quelqu'un qui le conçoit.</p></div>

<div class="theory-block"><h3>🚀 30.3 — Prochaines étapes recommandées</h3><p>1. <strong>React.js</strong> — la librairie UI la plus demandée ; tu as déjà toutes les bases nécessaires.<br>2. <strong>TypeScript</strong> — approfondir au-delà des bases du jour 28.<br>3. <strong>Next.js</strong> — React côté serveur.<br>4. <strong>Express + une vraie base de données</strong> — transformer les API simulées de cette semaine en API branchées sur une vraie persistance.<br>5. <strong>Git/GitHub</strong> — si ce n'est pas encore fait, c'est la priorité absolue.</p></div>

<div class="tip-box"><strong>💪 Un dernier mot :</strong> 30 jours, ce n'est pas "tout savoir" — c'est avoir construit assez de bases solides pour ne plus jamais repartir de zéro face à du code inconnu. La prochaine étape n'est pas un onzième cours théorique : c'est un projet à toi, moche au début, buggé, imparfait — et fini. Portfolio avant diplôme, projet terminé avant projet parfait. Bravo, et à très vite sur la suite du chemin. 🇨🇮</div>`,starter:`// Jour 30 — Récapitulatif Final 🎉
// Tu sais maintenant tout ça :

const COMPETENCES = {
  fondations: ["variables", "conditions", "boucles", "fonctions", "arrays", "objets"],
  intermediaire: ["map/filter/reduce", "DOM", "closures", "classes", "async/await", "fetch"],
  avance: ["regex", "generateurs", "proxy", "design-patterns", "FP", "tests", "nodejs"]
};

const total = Object.values(COMPETENCES).flat().length;
console.log(\`🏆 \${total} compétences maîtrisées !\`);

Object.entries(COMPETENCES).forEach(([niveau, skills]) => {
  console.log(\`\\n📚 \${niveau.toUpperCase()} (\${skills.length} skills):\`);
  skills.forEach(s => console.log(\`  ✅ \${s}\`));
});

console.log("\\n🚀 Prochain objectif : React.js !");
console.log("🇨🇮 Nerija KONAN — Développeur JavaScript — Prêt !");`,quiz:[{q:"Tu as terminé 30 jours de JS. Tu es...",opts:["Un débutant complet","Un développeur JS compétent","Un expert senior","Pas encore prêt"],ans:1},{q:"Quelle est la meilleure façon de progresser maintenant ?",opts:["Relire les cours","Construire des projets réels","Attendre un prof","Mémoriser la doc"],ans:1},{q:"Quel framework front-end apprendre après JS ?",opts:["jQuery","React / Vue / Angular","Flash","Bootstrap"],ans:1}]}
  ]}
];
