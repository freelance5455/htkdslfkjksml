/* ========================= SUPABASE ========================= */
const SUPABASE_URL = 'https://muxuoxmnmmeqlrkoqhbf.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_3ZbPfFslBlE637ByfTea8A_drMp9JgZ';
const supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
