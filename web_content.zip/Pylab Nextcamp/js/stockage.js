/* ========================= STORAGE HELPERS ========================= */
/* Stockage local au navigateur (à remplacer par l'API serveur une fois le back-end déployé) */
const STORE_PREFIX='pylab:';
async function storageGetRaw(key){ try{ return localStorage.getItem(STORE_PREFIX+key); }catch(e){ return null; } }
async function storageSetRaw(key,val){ try{ localStorage.setItem(STORE_PREFIX+key,val); return true; }catch(e){ return false; } }
async function storageGetJSON(key){ const r=await storageGetRaw(key); try{ return r?JSON.parse(r):null; }catch(e){ return null; } }
async function storageSetJSON(key,obj){ return storageSetRaw(key,JSON.stringify(obj)); }
async function storageDelete(key){ try{ localStorage.removeItem(STORE_PREFIX+key); return true; }catch(e){ return false; } }
