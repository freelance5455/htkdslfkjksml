/* ========================= ASSISTANT IA (offre Premium) — via relais serverless (clé côté serveur) ========================= */
/* L'assistant passe par l'Edge Function Supabase 'ai-assistant' (clé secrète côté serveur, abonnement vérifié). */

let aiHistory = [];
let aiSending = false;

function escapeHtml(s){
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
function aiHistoryKey(){ return 'pylab_ai_history:' + (currentUser ? currentUser.email : 'anon'); }
function loadAiHistory(){
  try{ const raw = localStorage.getItem(aiHistoryKey()); aiHistory = raw ? JSON.parse(raw) : []; }
  catch(e){ aiHistory = []; }
}
function persistAiHistory(){
  try{ localStorage.setItem(aiHistoryKey(), JSON.stringify(aiHistory.slice(-40))); }catch(e){}
}

function renderAiTab(){
  const c = document.getElementById('main-content');
  const isPremium = hasActiveOffer(currentUser) && (currentUser.offre === 'premium' || currentUser.offre === 'annuel');
  if(!isPremium){
    c.innerHTML = `<div class="ai-gate">
      <div class="ai-gate-icon">✨</div>
      <h3>Assistant IA — réservé à l'offre Premium</h3>
      <p>Pose tes questions directement à une IA pendant que tu apprends, avec le contexte de la leçon en cours. Passe à l'offre Premium pour débloquer l'assistant.</p>
      <button class="btn btn-primary" onclick="goToPricing()">Voir les offres &gt;&gt;&gt;</button>
    </div>`;
    return;
  }
  loadAiHistory();
  const hasMic = !!(window.SpeechRecognition || window.webkitSpeechRecognition);
  c.innerHTML = `<div class="ai-chat">
    <div class="ai-messages" id="ai-messages"></div>
    <div class="ai-composer">
      <textarea id="ai-input" rows="1" placeholder="Discuter avec l'assistant…" enterkeyhint="send"
        oninput="aiAutosize(this);aiUpdateSend()" onkeydown="handleAiKeydown(event)"></textarea>
      <div class="ai-composer-row">
        <button type="button" class="ai-icon-btn" onclick="aiNewConversation()" aria-label="Nouvelle conversation" title="Nouvelle conversation">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>
        </button>
        <span class="ai-pill">DeepSeek</span>
        <span class="ai-spacer"></span>
        ${hasMic ? `<button type="button" class="ai-icon-btn" id="ai-mic-btn" onclick="toggleAiMic()" aria-label="Dicter un message" title="Dicter">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="3" width="6" height="12" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/></svg>
        </button>` : ''}
        <button type="button" class="ai-send-btn" id="ai-send-btn" onclick="sendAiMessage()" aria-label="Envoyer" disabled>
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M12 19V5M5 12l7-7 7 7"/></svg>
        </button>
      </div>
    </div>
  </div>`;
  renderAiMessages();
}
const AI_MARK = `<svg class="ai-mark" viewBox="0 0 48 48" aria-hidden="true"><g stroke="#8B5CF6" stroke-width="4" stroke-linecap="round"><line x1="30.0" y1="24.0" x2="44.0" y2="24.0"/><line x1="28.2" y1="28.2" x2="38.1" y2="38.1"/><line x1="24.0" y1="30.0" x2="24.0" y2="44.0"/><line x1="19.8" y1="28.2" x2="9.9" y2="38.1"/><line x1="18.0" y1="24.0" x2="4.0" y2="24.0"/><line x1="19.8" y1="19.8" x2="9.9" y2="9.9"/><line x1="24.0" y1="18.0" x2="24.0" y2="4.0"/><line x1="28.2" y1="19.8" x2="38.1" y2="9.9"/></g></svg>`;
/* Mise en forme légère des réponses : blocs de code, `code` en ligne et **gras** (le reste est échappé) */
function aiFormat(raw){
  return String(raw).split('```').map((p,i)=>{
    if(i%2===1){
      const nl = p.indexOf('\n');
      const code = (nl>-1 && /^[\w+#.-]*$/.test(p.slice(0,nl).trim())) ? p.slice(nl+1) : p;
      return `<pre class="ai-code"><code>${escapeHtml(code.replace(/\n+$/,''))}</code></pre>`;
    }
    return escapeHtml(p.replace(/^\n+|\n+$/g,''))
      .replace(/`([^`\n]+)`/g,'<code>$1</code>')
      .replace(/\*\*([^*\n]+)\*\*/g,'<strong>$1</strong>');
  }).join('');
}
function renderAiMessages(){
  const box = document.getElementById('ai-messages');
  if(!box) return;
  if(aiHistory.length===0){
    box.innerHTML = `<div class="ai-empty">${AI_MARK}<h2>Sur quoi allons-nous réfléchir ?</h2><p>Leçon en cours : ${escapeHtml(getDayData(currentDay).title)}</p></div>`;
  } else {
    box.innerHTML = aiHistory.map(m =>
      m.role==='assistant' ? `<div class="ai-msg assistant"><div class="ai-text">${aiFormat(m.text)}</div></div>`
                           : `<div class="ai-msg ${m.role}">${escapeHtml(m.text)}</div>`).join('');
  }
  box.scrollTop = box.scrollHeight;
}
function aiAutosize(el){ el.style.height='auto'; el.style.height=Math.min(el.scrollHeight,140)+'px'; }
function aiUpdateSend(){
  const b=document.getElementById('ai-send-btn'), i=document.getElementById('ai-input');
  if(b && i) b.disabled = aiSending || !i.value.trim();
}
function handleAiKeydown(e){
  /* Ordinateur : Entrée envoie (Maj+Entrée = nouvelle ligne). Téléphone : Entrée = nouvelle ligne, on envoie avec le bouton. */
  const touch = window.matchMedia && window.matchMedia('(pointer:coarse)').matches;
  if(e.key==='Enter' && !e.shiftKey && !touch){ e.preventDefault(); sendAiMessage(); }
}
function aiNewConversation(){
  if(aiSending) return;
  if(aiHistory.length && !confirm('Commencer une nouvelle conversation ? La discussion actuelle sera effacée.')) return;
  aiHistory = []; persistAiHistory(); renderAiMessages();
  const i=document.getElementById('ai-input'); if(i){ i.value=''; aiAutosize(i); i.focus(); }
  aiUpdateSend();
}
let aiRec = null;
function toggleAiMic(){
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if(!SR) return;
  if(aiRec){ aiRec.stop(); return; }
  const btn=document.getElementById('ai-mic-btn'), input=document.getElementById('ai-input');
  const base = input.value ? input.value.trim()+' ' : '';
  const stop = ()=>{ aiRec=null; if(btn) btn.classList.remove('rec'); };
  aiRec = new SR(); aiRec.lang='fr-FR'; aiRec.interimResults=true; aiRec.continuous=false;
  aiRec.onresult = e=>{ let t=''; for(const r of e.results) t+=r[0].transcript; input.value = base+t; aiAutosize(input); aiUpdateSend(); };
  aiRec.onend = stop; aiRec.onerror = stop;
  btn.classList.add('rec');
  try{ aiRec.start(); }catch(e){ stop(); }
}
async function sendAiMessage(){
  if(aiSending) return;
  const input = document.getElementById('ai-input');
  const text = input.value.trim();
  if(!text) return;

  aiHistory.push({role:'user', text});
  input.value = ''; aiAutosize(input);
  renderAiMessages();
  persistAiHistory();

  aiSending = true;
  aiUpdateSend();
  const box = document.getElementById('ai-messages');
  box.insertAdjacentHTML('beforeend', `<div class="ai-msg pending" id="ai-pending" aria-label="L'assistant réfléchit"><span></span><span></span><span></span></div>`);
  box.scrollTop = box.scrollHeight;

  const data = getDayData(currentDay);
  const langLabel = currentTrack==='sql' ? 'SQL (SQLite, Android et iOS)' : trackLabel();
  const lvlLabel = data.level==='easy' ? 'débutant' : data.level==='med' ? 'intermédiaire' : 'avancé';
  const systemPrompt = `Tu es l'assistant pédagogique intégré au bootcamp PYl@b NEXTCAMP. L'apprenant suit le parcours ${langLabel}, niveau ${lvlLabel}. Il étudie actuellement le Jour ${data.d} : "${data.title}" (${data.sub}). Réponds en français, de façon claire, concise et encourageante, avec des exemples de code ${langLabel} si utile. Reste focalisé sur la programmation et ce cours.`;

  try{
    const reply = await callAssistant(systemPrompt, aiHistory.slice(0,-1), text);
    aiHistory.push({role:'assistant', text: reply});
  }catch(err){
    aiHistory.push({role:'error', text: "Erreur : " + (err.message || "impossible de contacter l'assistant.")});
  }
  aiSending = false;
  const pendingEl = document.getElementById('ai-pending');
  if(pendingEl) pendingEl.remove();
  aiUpdateSend();
  renderAiMessages();
  persistAiHistory();
}

async function callAssistant(systemPrompt, history, userMessage){
  const messages = history
    .filter(m=>m.role==='user' || m.role==='assistant')
    .map(m=>({ role:m.role, content:m.text }));
  messages.push({role:'user', content:userMessage});
  const { data, error } = await supabaseClient.functions.invoke('ai-assistant', { body:{ system: systemPrompt, messages } });
  if(error){
    let msg = "Impossible de contacter l'assistant.";
    try{ const j = await error.context.json(); if(j && j.error) msg = j.error; }catch(e){}
    throw new Error(msg);
  }
  if(!data || !data.text) throw new Error("Réponse vide de l'assistant.");
  return data.text;
}

function goToPricing(){ if(!currentUser) return; pendingLangue=currentTrack; navigateTo('pricingView'); }

function markDoneAndNext(){
  const wasDone=completedDays.has(currentDay);
  completedDays.add(currentDay);
  if(!wasDone){ const _d=allDays(); launchConfetti(_d.findIndex(x=>x.d===currentDay)>=_d.length-1 ? 200 : 80); }
  persistProgress();
  const days = allDays();
  const idx = days.findIndex(x=>x.d===currentDay);
  if(idx < days.length-1){ loadDay(days[idx+1].d); showToast('Jour '+currentDay+' terminé ! On enchaîne.'); }
  else { buildSidebar(); showToast(currentTrack==='python' ? 'Bravo, tu es développeur Python !' : currentTrack==='sql' ? 'Bravo, tu maîtrises SQL !' : 'Bravo, tu es développeur JavaScript !'); }
}
function showToast(msg){
  const t=document.getElementById('toast'); t.textContent=msg; t.classList.add('show');
  setTimeout(()=>t.classList.remove('show'), 3200);
}
