function togglePw(id,btn){
  var inp=document.getElementById(id); if(!inp) return;
  var show=inp.type==='password';
  inp.type=show?'text':'password';
  btn.classList.toggle('shown',show);
  btn.setAttribute('aria-label',show?'Masquer le mot de passe':'Afficher le mot de passe');
}
