/* ========================= PROGRAMME (landing) ========================= */
function renderProgrammePreview(track){
  document.getElementById('prog-tab-python').classList.toggle('active', track==='python');
  document.getElementById('prog-tab-js').classList.toggle('active', track==='js');
  document.getElementById('prog-tab-sql').classList.toggle('active', track==='sql');
  const curriculum = track==='python' ? CURRICULUM_PY : track==='sql' ? CURRICULUM_SQL : CURRICULUM_JS;
  const el = document.getElementById('programme-preview');
  el.innerHTML = curriculum.map(week=>{
    const parts = week.week.split('—');
    const h = (parts[0]||'').trim();
    const sub = (parts[1]||'').trim();
    return `<div class="week-card"><h3>${h}</h3><div class="wk-sub">${sub}</div><ol>${week.days.map(d=>`<li><b>${d.d}</b>${d.title}</li>`).join('')}</ol></div>`;
  }).join('');
}

/* ========================= APP UI (commun aux 2 parcours) ========================= */
function getCurriculum(){ return currentTrack==='python' ? CURRICULUM_PY : currentTrack==='sql' ? CURRICULUM_SQL : CURRICULUM_JS; }
function allDays(){ return getCurriculum().flatMap(w=>w.days); }
function getDayData(d){ return allDays().find(x=>x.d===d); }

function buildSidebar(){
  const nav = document.getElementById('day-nav'); nav.innerHTML='';
  getCurriculum().forEach(week=>{
    const t=document.createElement('div'); t.className='wk-title'; t.textContent=week.week; nav.appendChild(t);
    week.days.forEach(day=>{
      const b=document.createElement('button');
      b.className='day-btn'+(day.d===currentDay?' active':'')+(completedDays.has(day.d)?' done':'');
      b.innerHTML=`<span class="node"></span> J${day.d} — ${day.title}`;
      b.onclick=()=>loadDay(day.d);
      nav.appendChild(b);
    });
  });
  updateProgressUI();
}
function updateProgressUI(){
  const total = allDays().length;
  const pct = Math.round((completedDays.size/total)*100);
  animateCount(document.getElementById('prog-pct'), pct);
  document.getElementById('prog-fill').style.width = pct+'%';
}
function loadDay(d){
  currentDay = d;
  const data = getDayData(d);
  document.getElementById('day-badge').textContent = 'JOUR '+d;
  document.getElementById('lesson-title').textContent = data.title;
  document.getElementById('lesson-sub').textContent = data.sub;
  buildSidebar();
  switchTab('theory');
  persistProgress();
}
function switchTab(tab){
  ['theory','practice','quiz','ai','cheat'].forEach(t=>document.getElementById('tab-'+t).classList.toggle('active', t===tab));
  const c = document.getElementById('main-content');
  const data = getDayData(currentDay);
  if(tab==='theory'){
    const lvlLabel = data.level==='easy'?'Débutant':data.level==='med'?'Intermédiaire':'Avancé';
    c.innerHTML = `<div style="margin-bottom:10px"><span class="badge ${data.level}">${lvlLabel}</span></div>` + data.theory;
  }
  else if(tab==='practice') renderPractice(data);
  else if(tab==='quiz') renderQuiz(data);
  else if(tab==='cheat') renderSqlCheat();
  else renderAiTab();
}
function renderPractice(data){
  if(currentTrack==='sql') return renderSqlPractice(data);
  const code = editorCodes[currentDay] !== undefined ? editorCodes[currentDay] : data.starter;
  const langLabel = trackLabel();
  const c = document.getElementById('main-content');
  c.innerHTML = `
   <div class="cell"><div class="cell-head"><span class="cell-tag">In [${data.d}]</span> Éditeur ${langLabel}</div><div class="cell-body" style="padding:14px">
    <div class="editor-wrap"><textarea class="editor-area" id="editor" spellcheck="false">${code.replace(/</g,'&lt;')}</textarea></div>
    <div class="btn-row"><button class="run-btn" onclick="runCode()">▶ Exécuter</button><button class="reset-code" onclick="resetCode()">Réinitialiser le code</button></div>
    <div class="terminal"><div class="term-head">terminal — sortie</div><div class="term-body" id="terminal-out"><span class="term-out info">// Clique sur Exécuter pour voir le résultat</span></div></div>
    ${currentTrack==='python' ? '<div class="sim-note">Simulateur Python simplifié — les fonctionnalités avancées ne sont pas toutes supportées.</div>' : ''}
   </div></div>`;
  document.getElementById('editor').addEventListener('input', e=>{ editorCodes[currentDay]=e.target.value; persistProgress(); });
}
function resetCode(){
  const data = getDayData(currentDay);
  delete editorCodes[currentDay];
  document.getElementById('editor').value = data.starter;
  persistProgress();
}
function renderQuiz(data){
  const c = document.getElementById('main-content');
  let html = '';
  data.quiz.forEach((q,qi)=>{
    html += `<div class="quiz-q"><p class="qtext">${qi+1}. ${q.q}</p>`;
    q.opts.forEach((opt,oi)=>{
      html += `<button class="qopt" onclick="answerQuiz(this,${qi},${oi},${q.ans})">${opt}</button>`;
    });
    html += `</div>`;
  });
  c.innerHTML = html;
}
function answerQuiz(el, qi, oi, correctIdx){
  const group = el.parentElement.querySelectorAll('.qopt');
  group.forEach(b=>b.disabled=true);
  if(oi===correctIdx){ el.classList.add('correct'); }
  else{ el.classList.add('wrong'); group[correctIdx].classList.add('correct'); }
  const qd = getDayData(currentDay).quiz[qi];
  if(qd && qd.e){ el.parentElement.insertAdjacentHTML('beforeend', `<p class="qwhy">${oi===correctIdx ? 'Bonne réponse. ' : 'Pas tout à fait. '}${qd.e}</p>`); }
}
