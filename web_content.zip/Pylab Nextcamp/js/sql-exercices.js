/* ========================= PARCOURS SQL : exercices & aide-mémoire ========================= */
const TRACK_LABEL = { python:'Python', js:'JavaScript', sql:'SQL' };
function trackLabel(){ return TRACK_LABEL[currentTrack] || 'Python'; }

const sqlChipState = {};
function sqlChips(data){
  const ex = data.ex, n = data.d;
  if(!sqlChipState[n]){
    const T = ex.sol.concat(ex.d || []);
    let order = SQLMOD.shuffle(T.map((_, i) => i), n * 97 + 3);
    if(order.slice(0, ex.sol.length).every((v, i) => v === i)) order.reverse();
    sqlChipState[n] = { order, sel:[], res:null, sol:false };
  }
  return sqlChipState[n];
}
function sqlExoBody(data){
  const ex = data.ex, n = data.d, esc = SQLMOD.esc, inl = SQLMOD.inline;
  if(ex.type === 'check'){
    const chk = sqlChk[n] || [];
    const cnt = ex.items.filter((_, i) => chk[i]).length;
    return `<p class="sq-enonce">${inl(ex.enonce)}</p>
      ${ex.starter ? SQLMOD.codeBlock(ex.starter.code, ex.starter.lang) : ''}
      ${ex.items.map((it, i) => `<button class="sq-check${chk[i] ? ' on' : ''}" onclick="sqlToggleCheck(${i})" role="checkbox" aria-checked="${!!chk[i]}"><i>✓</i><span>${inl(it)}</span></button>`).join('')}
      <p class="sq-progline">${cnt} sur ${ex.items.length} étapes terminées${sqlExo[n] ? ' — exercice validé.' : ''}</p>`;
  }
  const st = sqlChips(data), T = ex.sol.concat(ex.d || []), J = ex.j !== undefined ? ex.j : ' ';
  const zone = st.sel.length
    ? st.sel.map(id => `<button class="sq-chip" onclick="sqlChipDel(${id})">${esc(T[id])}</button>`).join('')
    : `<span class="ph">// Touche les blocs ci-dessous, dans l'ordre.</span>`;
  const bank = st.order.filter(id => !st.sel.includes(id)).map(id => `<button class="sq-chip" onclick="sqlChipAdd(${id})">${esc(T[id])}</button>`).join('');
  let fb = '';
  if(st.res === 'ok') fb = `<div class="sq-fb ok">✅ Correct. Voici ta requête :${SQLMOD.codeBlock(ex.sol.join(J), data.exLang)}</div>`;
  else if(st.res === 'ko') fb = `<div class="sq-fb ko">❌ Pas encore. Vérifie l'ordre des blocs, et enlève ceux qui ne servent pas.</div>`;
  else if(sqlExo[n]) fb = `<div class="sq-fb ok">✅ Exercice déjà réussi. Tu peux le refaire pour t'entraîner.</div>`;
  if(st.sol) fb += `<div class="sq-fb">Solution :${SQLMOD.codeBlock(ex.sol.join(J), data.exLang)}</div>`;
  return `<p class="sq-enonce">${inl(ex.enonce)}</p>
    <p class="sq-tables">${esc(ex.tables)}</p>
    <div class="sq-zone" aria-label="Ta requête">${zone}</div>
    <div class="sq-bank" aria-label="Blocs disponibles">${bank}</div>
    <div class="btn-row">
      <button class="run-btn" onclick="sqlChipCheck()"${st.sel.length ? '' : ' disabled'}>▶ Vérifier</button>
      <button class="sq-ghost" onclick="sqlChipClear()"${st.sel.length ? '' : ' disabled'}>Effacer</button>
      <button class="sq-ghost" onclick="sqlChipSol()">Solution</button>
    </div>${fb}`;
}
function sqlRefresh(){
  const box = document.getElementById('sq-body');
  if(box) box.innerHTML = sqlExoBody(getDayData(currentDay));
}
function renderSqlPractice(data){
  const c = document.getElementById('main-content');
  c.innerHTML = `<div class="cell"><div class="cell-head"><span class="cell-tag">In [${data.d}]</span> Exercice SQL</div><div class="cell-body" style="padding:14px" id="sq-body">${sqlExoBody(data)}</div></div>`;
}
function sqlChipAdd(id){ const st = sqlChips(getDayData(currentDay)); st.sel.push(id); st.res = null; sqlRefresh(); }
function sqlChipDel(id){ const st = sqlChips(getDayData(currentDay)); st.sel = st.sel.filter(x => x !== id); st.res = null; sqlRefresh(); }
function sqlChipClear(){ const st = sqlChips(getDayData(currentDay)); st.sel = []; st.res = null; sqlRefresh(); }
function sqlChipSol(){ const st = sqlChips(getDayData(currentDay)); st.sol = !st.sol; sqlRefresh(); }
function sqlChipCheck(){
  const data = getDayData(currentDay), st = sqlChips(data), T = data.ex.sol.concat(data.ex.d || []);
  const ok = st.sel.map(i => T[i]).join('\u0001') === data.ex.sol.join('\u0001');
  st.res = ok ? 'ok' : 'ko';
  if(ok && !sqlExo[currentDay]){ sqlExo[currentDay] = true; persistProgress(); showToast('Exercice réussi !'); }
  sqlRefresh();
  if(!ok){ const fb = document.querySelector('#sq-body .sq-fb.ko'); if(fb) fb.classList.add('shake'); }
}
function sqlToggleCheck(i){
  const data = getDayData(currentDay);
  const chk = sqlChk[currentDay] = sqlChk[currentDay] || [];
  chk[i] = !chk[i];
  const done = data.ex.items.every((_, k) => chk[k]);
  if(done && !sqlExo[currentDay]) showToast('Exercice validé !');
  if(done) sqlExo[currentDay] = true; else delete sqlExo[currentDay];
  persistProgress();
  sqlRefresh();
}

let sqlCheatQuery = '';
function sqlCheatList(){
  const f = sqlCheatQuery.trim().toLowerCase();
  const list = SQLMOD.cheat.filter(x => !f || x.t.toLowerCase().includes(f) || x.c.toLowerCase().includes(f));
  return list.length
    ? list.map(x => `<div class="theory-block"><h3>${SQLMOD.esc(x.t)}</h3>${SQLMOD.codeBlock(x.c, x.l)}</div>`).join('')
    : `<p class="sim-note">Aucun résultat pour « ${SQLMOD.esc(sqlCheatQuery)} ».</p>`;
}
function sqlCheatFilter(v){ sqlCheatQuery = v; document.getElementById('sq-cheatlist').innerHTML = sqlCheatList(); }
function renderSqlCheat(){
  const c = document.getElementById('main-content');
  c.innerHTML = `<div class="cell"><div class="cell-head"><span class="cell-tag">In [∗]</span> Aide-mémoire SQL</div><div class="cell-body">
    <div class="theory-block"><p>Les commandes essentielles, en un coup d'œil.</p></div>
    <div class="field"><input id="sq-search" type="search" placeholder="Chercher : JOIN, index, Room…" value="${SQLMOD.esc(sqlCheatQuery)}" oninput="sqlCheatFilter(this.value)" aria-label="Chercher dans l'aide-mémoire"></div>
    <div id="sq-cheatlist">${sqlCheatList()}</div>
  </div></div>`;
}
