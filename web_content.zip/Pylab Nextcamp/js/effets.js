/* ========================= EFFETS : compteur, confettis, frappe ========================= */
const reduceMotion=()=>matchMedia('(prefers-reduced-motion:reduce)').matches;
function animateCount(el,to){
  const from=parseInt(el.textContent)||0;
  cancelAnimationFrame(el._raf);
  if(from===to||reduceMotion()){ el.textContent=to+'%'; return; }
  const t0=performance.now(), dur=600;
  (function step(t){
    const p=Math.min((t-t0)/dur,1), e=1-Math.pow(1-p,3);
    el.textContent=Math.round(from+(to-from)*e)+'%';
    if(p<1) el._raf=requestAnimationFrame(step);
  })(t0);
}
function launchConfetti(n){
  if(reduceMotion()) return;
  const c=document.createElement('canvas');
  c.style.cssText='position:fixed;inset:0;width:100%;height:100%;pointer-events:none;z-index:9999';
  const W=c.width=innerWidth, H=c.height=innerHeight;
  document.body.appendChild(c);
  const ctx=c.getContext('2d');
  const cols=['#F4502A','#FFC33D','#1E6E62','#7FD8C4','#8FB8FF','#F0C868'];
  const ps=Array.from({length:n},()=>({x:W/2+(Math.random()-.5)*W*.3,y:H*.65,vx:(Math.random()-.5)*14,vy:-Math.random()*16-6,w:6+Math.random()*6,h:4+Math.random()*5,r:Math.random()*6.28,vr:(Math.random()-.5)*.4,c:cols[Math.random()*cols.length|0]}));
  const t0=performance.now();
  (function frame(t){
    const el=t-t0; ctx.clearRect(0,0,W,H);
    ps.forEach(p=>{
      p.vy+=.35; p.vx*=.99; p.x+=p.vx; p.y+=p.vy; p.r+=p.vr;
      ctx.save(); ctx.globalAlpha=Math.max(0,1-el/2400); ctx.translate(p.x,p.y); ctx.rotate(p.r);
      ctx.fillStyle=p.c; ctx.fillRect(-p.w/2,-p.h/2,p.w,p.h); ctx.restore();
    });
    if(el<2400) requestAnimationFrame(frame); else c.remove();
  })(t0);
}
function typeDemo(){
  const body=document.querySelector('.demo-body');
  if(!body || reduceMotion()) return;
  const out=body.querySelector('.demo-out');
  const walker=document.createTreeWalker(body,NodeFilter.SHOW_TEXT,{acceptNode:n=>(out&&out.contains(n))?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT});
  const nodes=[]; while(walker.nextNode()) nodes.push(walker.currentNode);
  const texts=nodes.map(n=>n.textContent);
  body.style.minHeight=body.offsetHeight+'px';
  nodes.forEach(n=>n.textContent='');
  if(out) out.style.visibility='hidden';
  const caret=document.createElement('span'); caret.className='caret';
  let i=0,j=0;
  (function tick(){
    if(i>=nodes.length){
      body.appendChild(caret);
      if(out){ out.style.visibility='visible'; out.style.animation='fadeUp .4s backwards'; }
      return;
    }
    const n=nodes[i], t=texts[i];
    n.parentNode.insertBefore(caret,n.nextSibling);
    if(!t.trim()){ n.textContent=t; i++; j=0; return tick(); }
    j++; n.textContent=t.slice(0,j);
    if(j>=t.length){ i++; j=0; }
    setTimeout(tick,28);
  })();
}
