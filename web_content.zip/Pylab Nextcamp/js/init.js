/* ========================= INIT ========================= */
renderProgrammePreview('python');
setTimeout(typeDemo,700);
(async function initApp(){
  await checkSession();
  await checkPendingPayment();
})();
