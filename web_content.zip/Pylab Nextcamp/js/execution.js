/* ========================= EXÉCUTION JAVASCRIPT NATIVE (parcours JS) ========================= */
function jsRunCode(){
  const code = document.getElementById('editor').value;
  const out = document.getElementById('terminal-out');
  out.innerHTML='';
  const logs=[];
  const origLog=console.log, origErr=console.error, origWarn=console.warn;
  console.log=(...args)=>logs.push({type:'log', msg:args.map(a=>typeof a==='object'?JSON.stringify(a):String(a)).join(' ')});
  console.error=(...args)=>logs.push({type:'err', msg:args.join(' ')});
  console.warn=(...args)=>logs.push({type:'warn', msg:args.join(' ')});
  try{ const fn=new Function(code); fn(); }
  catch(e){ logs.push({type:'err', msg:e.toString()}); }
  finally{ console.log=origLog; console.error=origErr; console.warn=origWarn; }
  if(!logs.length) logs.push({type:'info', msg:'// Exécution terminée (aucun output)'});
  logs.forEach(l=>{
    const line=document.createElement('div');
    line.className='term-out'+(l.type==='err'?' err':l.type==='warn'?' warn':l.type==='info'?' info':'');
    line.textContent=(l.type==='err'?'❌ ':'')+l.msg;
    out.appendChild(line);
  });
}
function runCode(){ if(currentTrack==='python') pyRunCode(); else jsRunCode(); }

/* ========================= MINI-INTERPRÉTEUR PYTHON -> JS (parcours Python) ========================= */
function pyStripComment(line){
  let inS=false, inD=false;
  for(let i=0;i<line.length;i++){
    const c=line[i];
    if(c==="'" && !inD) inS=!inS;
    else if(c==='"' && !inS) inD=!inD;
    else if(c==='#' && !inS && !inD) return line.slice(0,i);
  }
  return line;
}
function pyExprTokens(s){
  s = s.replace(/==/g,'===').replace(/!=/g,'!==');
  s = s.replace(/\b(\w+)\s+not\s+in\s+(\w+)\b/g, '!$2.includes($1)');
  s = s.replace(/\b(\w+)\s+in\s+(\w+)\b/g, '$2.includes($1)');
  s = s.replace(/\bTrue\b/g,'true').replace(/\bFalse\b/g,'false').replace(/\bNone\b/g,'null');
  s = s.replace(/\band\b/g,'&&').replace(/\bor\b/g,'||').replace(/\bnot\s+/g,'!');
  s = s.replace(/\bself\./g,'this.').replace(/\bself\b/g,'this');
  s = s.replace(/\.append\(/g,'.push(');
  s = s.replace(/\.upper\(\)/g,'.toUpperCase()').replace(/\.lower\(\)/g,'.toLowerCase()').replace(/\.strip\(\)/g,'.trim()');
  s = s.replace(/\.startswith\(/g,'.startsWith(').replace(/\.endswith\(/g,'.endsWith(');
  s = s.replace(/\bprint\(/g,'console.log(');
  return s;
}
function pyConvertFStringsOnly(s){
  return s.replace(/f(['"])((?:(?!\1).)*)\1/g, (m,q,content)=>{
    const inner = content.replace(/\{([^{}]+)\}/g, (mm,expr)=>'${'+expr.trim()+'}');
    return '`'+inner+'`';
  });
}
function pyConvertLineContent(s){ return pyConvertFStringsOnly(pyExprTokens(s)); }
function pyInsertNew(s, classNames){
  classNames.forEach(cn=>{
    const re = new RegExp('(^|[^\\w.])'+cn+'\\s*\\(','g');
    s = s.replace(re, (m,pre)=>pre+'new '+cn+'(');
  });
  return s;
}
function pyConvertParams(params){
  if(!params || !params.trim()) return '';
  return params.split(',').map(p=>{
    p=p.trim();
    if(p.includes('=')){ const [name,def]=p.split('='); return name.trim()+'='+pyConvertLineContent(def.trim()); }
    return p;
  }).join(', ');
}
function pySplitArgs(s){ return s.split(',').map(x=>pyConvertLineContent(x.trim())); }
function pyConvertStatementLine(line, classNames){
  let m;
  if(m = line.match(/^([a-zA-Z_]\w*)\s*=\s*(?!=)(.+)$/)){
    let rhs = pyInsertNew(pyConvertLineContent(m[2]), classNames);
    return { code:`var ${m[1]} = ${rhs};`, opensBlock:false };
  }
  if(m = line.match(/^([a-zA-Z_][\w.\[\]'"]*)\s*(\+=|-=|\*=|\/=)\s*(.+)$/)){
    return { code:`${pyConvertLineContent(m[1])} ${m[2]} ${pyConvertLineContent(m[3])};`, opensBlock:false };
  }
  if(m = line.match(/^return(\s+(.+))?$/)){
    const val = m[2] ? pyInsertNew(pyConvertLineContent(m[2]), classNames) : '';
    return { code:`return ${val};`, opensBlock:false };
  }
  if(line==='pass') return { code:'', opensBlock:false };
  if(line==='break'||line==='continue') return { code:line+';', opensBlock:false };
  return { code: pyInsertNew(pyConvertLineContent(line), classNames)+';', opensBlock:false };
}
function pyTranspile(source){
  const rawLines = source.split('\n').map(pyStripComment);
  const lines = rawLines.filter(l=>l.trim()!=='');
  const classNames = [];
  lines.forEach(l=>{ const m=l.trim().match(/^class\s+(\w+)/); if(m) classNames.push(m[1]); });

  let out=[]; let indentStack=[0]; let prevOpens=false;
  for(const rawLine of lines){
    const indent = rawLine.match(/^(\s*)/)[1].replace(/\t/g,'    ').length;
    let line = rawLine.trim();
    while(indent < indentStack[indentStack.length-1]){ indentStack.pop(); out.push('}'); }
    if(prevOpens){ indentStack.push(indent); prevOpens=false; }

    let converted=''; let opens=false; let m;
    if(m = line.match(/^class\s+(\w+)\s*(?:\(\s*(\w+)\s*\))?\s*:$/)){
      converted = m[2] ? `class ${m[1]} extends ${m[2]} {` : `class ${m[1]} {`; opens=true;
    } else if(m = line.match(/^def\s+__init__\s*\(\s*self\s*,?\s*([^)]*)\)\s*:$/)){
      converted = `constructor(${pyConvertParams(m[1])}) {`; opens=true;
    } else if(m = line.match(/^def\s+(\w+)\s*\(\s*self\s*,?\s*([^)]*)\)\s*:$/)){
      converted = `${m[1]}(${pyConvertParams(m[2])}) {`; opens=true;
    } else if(m = line.match(/^def\s+(\w+)\s*\(([^)]*)\)\s*:$/)){
      converted = `function ${m[1]}(${pyConvertParams(m[2])}) {`; opens=true;
    } else if(m = line.match(/^for\s+(\w+)\s*,\s*(\w+)\s+in\s+enumerate\(([^)]+)\)\s*:$/)){
      const it = pyConvertLineContent(m[3]);
      converted = `for (let __i=0; __i<${it}.length; __i++) { let ${m[1]}=__i, ${m[2]}=${it}[__i];`; opens=true;
    } else if(m = line.match(/^for\s+(\w+)\s+in\s+range\(([^)]*)\)\s*:$/)){
      const args = pySplitArgs(m[2]); const v=m[1];
      if(args.length===1) converted = `for (let ${v}=0; ${v}<${args[0]}; ${v}++) {`;
      else if(args.length===2) converted = `for (let ${v}=${args[0]}; ${v}<${args[1]}; ${v}++) {`;
      else converted = `for (let ${v}=${args[0]}; (${args[2]})<0 ? ${v}>${args[1]} : ${v}<${args[1]}; ${v}+=(${args[2]})) {`;
      opens=true;
    } else if(m = line.match(/^for\s+(\w+)\s+in\s+(.+?)\s*:$/)){
      converted = `for (const ${m[1]} of ${pyConvertLineContent(m[2])}) {`; opens=true;
    } else if(m = line.match(/^while\s+(.+?)\s*:$/)){
      converted = `while (${pyConvertLineContent(m[1])}) {`; opens=true;
    } else if(m = line.match(/^if\s+(.+?)\s*:$/)){
      converted = `if (${pyConvertLineContent(m[1])}) {`; opens=true;
    } else if(m = line.match(/^elif\s+(.+?)\s*:$/)){
      converted = `else if (${pyConvertLineContent(m[1])}) {`; opens=true;
    } else if(line==='else:'){ converted='else {'; opens=true; }
    else if(line==='try:'){ converted='try {'; opens=true; }
    else if(m = line.match(/^except(\s+\w+)?(\s+as\s+(\w+))?\s*:$/)){ converted = m[3]?`catch (${m[3]}) {`:`catch (__e) {`; opens=true; }
    else if(line==='finally:'){ converted='finally {'; opens=true; }
    else if(/^(import\s+\w+|from\s+\w+\s+import\s+.+)$/.test(line)){ converted=''; opens=false; }
    else { const st = pyConvertStatementLine(line, classNames); converted=st.code; opens=st.opensBlock; }

    if(converted!=='') out.push(converted);
    prevOpens = opens;
  }
  while(indentStack.length>1){ indentStack.pop(); out.push('}'); }
  return out.join('\n');
}
function pyRuntimePreamble(){
  return `
function len(x){ if(x==null) return 0; return typeof x.length==='number' ? x.length : Object.keys(x).length; }
function str(x){ if(x===null||x===undefined) return 'None'; if(x===true) return 'True'; if(x===false) return 'False'; return String(x); }
function int(x){ const n=parseInt(x,10); if(Number.isNaN(n)) throw new Error("invalid literal for int(): '"+x+"'"); return n; }
function float(x){ const n=parseFloat(x); if(Number.isNaN(n)) throw new Error("could not convert to float: '"+x+"'"); return n; }
function range(a,b,c){ let start=0,stop,step=1; if(b===undefined){stop=a;}else{start=a;stop=b; if(c!==undefined) step=c;} const r=[]; if(step>0){for(let i=start;i<stop;i+=step)r.push(i);}else{for(let i=start;i>stop;i+=step)r.push(i);} return r; }
function sum(arr){ return arr.reduce((a,b)=>a+b,0); }
function max(...a){ const arr=a.length===1&&Array.isArray(a[0])?a[0]:a; return Math.max(...arr); }
function min(...a){ const arr=a.length===1&&Array.isArray(a[0])?a[0]:a; return Math.min(...arr); }
function sorted(arr){ const c=[...arr]; c.sort((a,b)=>typeof a==='number'?a-b:String(a).localeCompare(String(b))); return c; }
function round(x,n){ n=n||0; const f=Math.pow(10,n); return Math.round(x*f)/f; }
function list(x){ return Array.isArray(x)?x.slice():Array.from(x); }
function input(msg){ const v=prompt(msg!==undefined?msg:''); return v===null?'':v; }
const math = { pi:Math.PI, sqrt:Math.sqrt, floor:Math.floor, ceil:Math.ceil, pow:Math.pow };
const random = { randint:(a,b)=>Math.floor(Math.random()*(b-a+1))+a, random:()=>Math.random(), choice:(arr)=>arr[Math.floor(Math.random()*arr.length)] };
`;
}
function pyRepr(v){
  if(v===null||v===undefined) return 'None';
  if(v===true) return 'True'; if(v===false) return 'False';
  if(typeof v==='number') return String(v);
  if(typeof v==='string') return v;
  if(Array.isArray(v)) return '['+v.map(pyReprNested).join(', ')+']';
  if(typeof v==='object') return '{'+Object.entries(v).map(([k,val])=>`'${k}': ${pyReprNested(val)}`).join(', ')+'}';
  return String(v);
}
function pyReprNested(v){ if(typeof v==='string') return `'${v}'`; return pyRepr(v); }
function pyFormatError(e){
  if(e instanceof SyntaxError) return "Erreur de syntaxe — vérifie ton code (indentation, parenthèses, deux-points).";
  return e.message || String(e);
}
function pyRunCode(){
  const code = document.getElementById('editor').value;
  const out = document.getElementById('terminal-out');
  out.innerHTML='';
  const logs=[];
  const origLog=console.log, origErr=console.error;
  console.log=(...args)=>logs.push({type:'log', msg:args.map(pyRepr).join(' ')});
  console.error=(...args)=>logs.push({type:'err', msg:args.join(' ')});
  try{
    const jsCode = pyRuntimePreamble()+'\n'+pyTranspile(code);
    const fn = new Function(jsCode);
    fn();
  }catch(e){ logs.push({type:'err', msg:pyFormatError(e)}); }
  finally{ console.log=origLog; console.error=origErr; }
  if(!logs.length) logs.push({type:'info', msg:'// Exécution terminée (aucune sortie)'});
  logs.forEach(l=>{
    const line=document.createElement('div');
    line.className='term-out'+(l.type==='err'?' err':l.type==='info'?' info':'');
    line.textContent=(l.type==='err'?'❌ ':'')+l.msg;
    out.appendChild(line);
  });
}
