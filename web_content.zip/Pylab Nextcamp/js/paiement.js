/* ========================= PAIEMENT — via relais serverless SasPay (clés côté serveur) ========================= */
/* Déploie le relais (voir DEPLOIEMENT_SASPAY.txt) puis remplace l'URL ci-dessous par celle de ton Worker. */

async function selectOffer(offer){
  const btns = document.querySelectorAll('#pricingView .btn');
  btns.forEach(b=>b.disabled = true);
  try{
    const { data, error } = await supabaseClient.functions.invoke('create-payment', {
      body:{ offer, track: pendingLangue }
    });
    if(error || !data || !data.checkout_url){
      let msg = "Impossible de créer le paiement.";
      try{ const j = await error.context.json(); if(j && j.error) msg = j.error; }catch(e){}
      throw new Error(msg);
    }
    localStorage.setItem('pylab_pending_payment', JSON.stringify({
      reference: data.reference, offer, langue: pendingLangue
    }));
    window.location.href = data.checkout_url;
  }catch(err){
    btns.forEach(b=>b.disabled = false);
    showToast('Erreur paiement : ' + (err.message || 'réessaie plus tard.'));
  }
}
async function checkPendingPayment(){
  let pending;
  try{ pending = JSON.parse(localStorage.getItem('pylab_pending_payment')||'null'); }catch(e){ pending = null; }
  if(!pending || !currentUser || !currentUser.id) return;
  /* Le webhook Saspay (serveur) active l'abonnement ; on interroge la base jusqu'à 5 fois. */
  for(let i=0;i<5;i++){
    const { data: pay } = await supabaseClient.from('payments').select('status')
      .eq('provider_reference', pending.reference).maybeSingle();
    if(pay && pay.status === 'paid'){
      localStorage.removeItem('pylab_pending_payment');
      const { data: { session } } = await supabaseClient.auth.getSession();
      const user = await chargerProfilDepuisSupabase(session.user);
      currentTrack = user.langue || pending.langue || currentTrack;
      await enterApp(user, 'Paiement confirmé — bienvenue dans PYl@b NEXTCAMP !');
      return;
    }
    if(pay && (pay.status === 'failed' || pay.status === 'refunded')){
      localStorage.removeItem('pylab_pending_payment');
      showToast("Le paiement n'a pas abouti. Tu peux réessayer.");
      return;
    }
    await new Promise(r=>setTimeout(r, 2500));
  }
  showToast('Ton paiement est en cours de traitement. Reviens dans un instant.');
}
async function enterAppShell(){
  await loadTrackProgress(currentTrack);
  hideAllViews();
  document.getElementById('appView').style.display='block';
  document.getElementById('side-user-nom').textContent = currentUser.nom;
  document.getElementById('side-user-niveau').textContent = currentUser.niveau==='debutant' ? 'Débutant total' : 'Connaît déjà les bases';
  document.getElementById('side-user-since').textContent = 'Membre depuis ' + new Date(currentUser.dateInscription).toLocaleDateString('fr-FR');
  document.getElementById('track-badge').textContent = ({python:'🐍 Python', js:'🟨 JavaScript', sql:'🗄️ SQL'})[currentTrack] || '🐍 Python';
  document.getElementById('appView').classList.toggle('track-js', currentTrack==='js');
  document.getElementById('tab-cheat').style.display = currentTrack==='sql' ? '' : 'none';
  document.getElementById('tab-practice').textContent = currentTrack==='sql' ? 'Exercice' : 'Terminal';
  buildSidebar(); loadDay(currentDay);
}
async function enterApp(user, toastMsg){
  currentUser = user;
  document.getElementById('nav-guest').style.display='none';
  document.getElementById('nav-user').style.display='';
  document.getElementById('nav-user-name').textContent = user.nom.split(' ')[0];
  document.getElementById('nav-user-avatar').textContent = user.nom.trim()[0].toUpperCase();
  showToast(toastMsg);
  if(user.langue && hasActiveOffer(user)){
    currentTrack = user.langue;
    await enterAppShell();
  } else if(user.langue && user.offre){
    pendingLangue = user.langue;
    showToast('Ton abonnement a expiré : renouvelle-le pour continuer.');
    navigateTo('pricingView');
  } else {
    showLangView();
  }
}
async function checkSession(){
  let session = null, user = null;
  try{
    ({ data: { session } } = await supabaseClient.auth.getSession());
    if(session) user = await chargerProfilDepuisSupabase(session.user);
  }catch(e){ console.error('checkSession', e); }
  document.getElementById('auth-loading').style.display='none';
  if(!user) return;
  await enterApp(user, `Ravi de te revoir, ${user.nom} !`);
}

async function persistProgress(){
  if(!currentUser || !currentUser.id) return;
  const slug = currentTrack==='js' ? 'javascript' : currentTrack;
  const trackId = await trackIdBySlug(slug);
  if(!trackId) return;
  await supabaseClient.from('progress').upsert({
    user_id: currentUser.id,
    track_id: trackId,
    current_day: currentDay,
    completed_days: [...completedDays],
    extra: { editorCodes, sqlExo, sqlChk },
    updated_at: new Date().toISOString()
  }, { onConflict: 'user_id,track_id' });
}async function resetProgress(){
  const label = trackLabel();
  if(!confirm(`Réinitialiser ta progression sur le parcours ${label} ?`)) return;
  completedDays = new Set(); currentDay = 1; editorCodes = {}; sqlExo = {}; sqlChk = {};
  await persistProgress();
  buildSidebar(); loadDay(1);
  showToast('Progression réinitialisée.');
}

async function deleteAccount(){
  if(!currentUser) return;
  if(!confirm('Supprimer définitivement ton compte et toute ta progression ? Cette action est irréversible.')) return;
  const { error } = await supabaseClient.functions.invoke('delete-account', { method:'POST' });
  if(error){ showToast("La suppression a échoué. Réessaie ou contacte le support."); return; }
  try{ localStorage.removeItem(aiHistoryKey()); }catch(e){}
  await handleLogout();
  showToast('Ton compte et toutes tes données ont été supprimés.');
}
