/* ========================= CURRICULUM SQL (parcours intégré, aux couleurs de PYl@b NEXTCAMP) ========================= */
const SQLMOD = (function(){
const SQL_WEEKS = ["Semaine 1 — Fondations", "Semaine 2 — Intermédiaire", "Semaine 3 — SQL sur Android et iOS"];
const DAYS = [
{ n:1, sem:0, titre:"Les bases : tables et données", sub:"CREATE TABLE, INSERT",
  but:"À la fin, tu sais créer une table et y insérer des lignes.",
  l:[
    ['p',"Une base de données relationnelle range l'information dans des **tables**. Chaque table a des **colonnes** (les champs) et des **lignes** (les enregistrements)."],
    ['tbl',['id','titre','fait'],[[1,'Apprendre SQL',0],[2,'Faire les courses',1]]],
    ['p',"**SQLite** est la base intégrée à Android et à iOS. Elle tient dans un simple fichier sur le téléphone, sans serveur."],
    ['c','sql',`CREATE TABLE taches (
  id    INTEGER PRIMARY KEY,
  titre TEXT,
  fait  INTEGER
);`],
    ['p',"SQLite a cinq types : `INTEGER`, `REAL`, `TEXT`, `BLOB` et `NULL`. Il n'y a pas de booléen : on utilise 0 (faux) et 1 (vrai)."],
    ['c','sql',`INSERT INTO taches (titre, fait) VALUES ('Apprendre SQL', 0);`],
    ['t',"Les textes s'écrivent entre apostrophes simples : 'comme ça'. Les guillemets doubles sont réservés aux noms de colonnes."]
  ],
  quiz:[
    {q:"Quel type SQLite utiliser pour stocker vrai ou faux ?", o:["BOOLEAN","INTEGER (0 ou 1)","BIT"], a:1, e:"SQLite n'a pas de type booléen. Par convention, 0 = faux et 1 = vrai."},
    {q:"Comment appelle-t-on une ligne d'une table ?", o:["Un enregistrement","Une colonne","Un index"], a:0, e:"Une ligne est un enregistrement, une colonne est un champ."},
    {q:"Quelle commande ajoute une ligne ?", o:["ADD ROW","INSERT INTO","PUSH"], a:1, e:"INSERT INTO table (colonnes) VALUES (valeurs)."}
  ],
  ex:{type:'chips', enonce:"Ajoute la tâche « Lire » (pas encore faite) dans la table.", tables:"taches(id, titre, fait)",
    sol:["INSERT","INTO","taches","(titre, fait)","VALUES","('Lire', 0);"], d:["ADD","UPDATE"]}
},
{ n:2, sem:0, titre:"Lire les données", sub:"SELECT, WHERE, ORDER BY, LIMIT, LIKE",
  but:"À la fin, tu sais filtrer, trier et limiter les résultats.",
  l:[
    ['p',"`SELECT` lit les données. `*` veut dire « toutes les colonnes ». `WHERE` filtre, `ORDER BY` trie, `LIMIT` coupe la liste."],
    ['c','sql',`SELECT titre
FROM taches
WHERE fait = 0
ORDER BY titre ASC
LIMIT 5;`],
    ['p',"`LIKE` cherche un motif. Le signe `%` remplace n'importe quelle suite de caractères."],
    ['c','sql',`SELECT * FROM taches WHERE titre LIKE 'A%';   -- commence par A
SELECT * FROM taches WHERE titre LIKE '%SQL%'; -- contient SQL`],
    ['t',"L'ordre des clauses est fixe : SELECT, FROM, WHERE, ORDER BY, LIMIT. Pour trier du plus grand au plus petit, ajoute DESC."]
  ],
  quiz:[
    {q:"Dans un LIKE, que veut dire % ?", o:["Un seul caractère","N'importe quelle suite de caractères","Le pourcentage"], a:1, e:"'A%' trouve tout ce qui commence par A, quelle que soit la suite."},
    {q:"Quelle clause filtre les lignes ?", o:["WHERE","ORDER BY","LIMIT"], a:0, e:"WHERE garde uniquement les lignes qui respectent la condition."},
    {q:"Comment trier du plus grand au plus petit ?", o:["ORDER BY prix DESC","ORDER BY prix UP","SORT prix"], a:0, e:"ASC (croissant) est la valeur par défaut, DESC inverse l'ordre."}
  ],
  ex:{type:'chips', enonce:"Affiche les 3 premières tâches non faites, triées par titre.", tables:"taches(id, titre, fait)",
    sol:["SELECT *","FROM taches","WHERE fait = 0","ORDER BY titre","LIMIT 3;"], d:["GROUP BY titre","WHERE fait = 1"]}
},
{ n:3, sem:0, titre:"Modifier et protéger", sub:"UPDATE, DELETE, contraintes",
  but:"À la fin, tu sais modifier, supprimer et imposer des règles sur tes données.",
  l:[
    ['c','sql',`UPDATE taches SET fait = 1 WHERE id = 3;
DELETE FROM taches WHERE fait = 1;`],
    ['t',"Sans WHERE, UPDATE et DELETE touchent toutes les lignes. Écris toujours le WHERE en premier, puis le reste."],
    ['p',"Les **contraintes** protègent la base : `PRIMARY KEY` (identifiant unique), `NOT NULL` (valeur obligatoire), `UNIQUE` (pas de doublon), `DEFAULT` (valeur par défaut)."],
    ['c','sql',`CREATE TABLE users (
  id    INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT NOT NULL UNIQUE,
  pays  TEXT DEFAULT 'FR'
);`]
  ],
  quiz:[
    {q:"Que fait un UPDATE sans WHERE ?", o:["Rien","Il modifie toutes les lignes","Il renvoie une erreur"], a:1, e:"Aucune condition veut dire que chaque ligne est concernée."},
    {q:"À quoi sert UNIQUE ?", o:["Interdire les doublons dans la colonne","Rendre la colonne obligatoire","Trier la colonne"], a:0, e:"Deux lignes ne peuvent pas avoir la même valeur (par exemple le même email)."},
    {q:"À quoi sert DEFAULT ?", o:["Donner une valeur si aucune n'est fournie","Supprimer la valeur","Interdire NULL"], a:0, e:"Si tu omets la colonne dans l'INSERT, la valeur par défaut est utilisée."}
  ],
  ex:{type:'chips', enonce:"Marque la tâche numéro 7 comme faite.", tables:"taches(id, titre, fait)",
    sol:["UPDATE taches","SET fait = 1","WHERE id = 7;"], d:["DELETE FROM taches","SET fait = 0"]}
},
{ n:4, sem:0, titre:"Calculer et regrouper", sub:"COUNT, SUM, AVG, GROUP BY, HAVING",
  but:"À la fin, tu sais produire des statistiques avec une seule requête.",
  l:[
    ['p',"Les fonctions d'agrégation résument plusieurs lignes en une valeur : `COUNT`, `SUM`, `AVG`, `MIN`, `MAX`."],
    ['c','sql',`SELECT COUNT(*) FROM taches WHERE fait = 0;
SELECT AVG(montant), SUM(montant) FROM depenses;`],
    ['p',"`GROUP BY` fait un paquet par valeur. `HAVING` filtre les paquets."],
    ['c','sql',`SELECT priorite, COUNT(*) AS nb
FROM taches
GROUP BY priorite
HAVING nb > 2;`],
    ['t',"WHERE filtre les lignes avant le regroupement. HAVING filtre les groupes après le calcul."]
  ],
  quiz:[
    {q:"Quelle différence entre WHERE et HAVING ?", o:["Aucune","WHERE filtre les lignes, HAVING filtre les groupes","HAVING est plus rapide"], a:1, e:"HAVING peut utiliser le résultat d'un COUNT ou d'un SUM, pas WHERE."},
    {q:"Que renvoie AVG(prix) ?", o:["La somme","La moyenne","Le maximum"], a:1, e:"AVG = average, la moyenne."},
    {q:"Que compte COUNT(*) ?", o:["Toutes les lignes du groupe","Les colonnes","Les valeurs uniques"], a:0, e:"COUNT(*) compte les lignes, même celles qui contiennent des NULL."}
  ],
  ex:{type:'chips', enonce:"Compte le nombre de tâches pour chaque priorité.", tables:"taches(id, titre, priorite)",
    sol:["SELECT priorite,","COUNT(*)","FROM taches","GROUP BY priorite;"], d:["HAVING priorite","ORDER BY COUNT(*)"]}
},
{ n:5, sem:0, titre:"Modéliser une app", sub:"Relations, clés étrangères. Mini-projet : app de tâches",
  but:"À la fin, tu as dessiné le schéma complet d'une app de tâches.",
  l:[
    ['p',"**Relation 1-N** : une liste contient plusieurs tâches. La **clé étrangère** se place du côté « N », dans la table `taches`."],
    ['c','sql',`CREATE TABLE listes (
  id  INTEGER PRIMARY KEY,
  nom TEXT NOT NULL
);
CREATE TABLE taches (
  id       INTEGER PRIMARY KEY,
  titre    TEXT NOT NULL,
  liste_id INTEGER NOT NULL
           REFERENCES listes(id) ON DELETE CASCADE
);`],
    ['p',"**Relation N-N** : une tâche a plusieurs tags, un tag sert à plusieurs tâches. Il faut une **table de liaison**."],
    ['c','sql',`CREATE TABLE tache_tag (
  tache_id INTEGER REFERENCES taches(id) ON DELETE CASCADE,
  tag_id   INTEGER REFERENCES tags(id)   ON DELETE CASCADE,
  PRIMARY KEY (tache_id, tag_id)
);`],
    ['t',"SQLite applique les clés étrangères seulement après PRAGMA foreign_keys = ON;. Room et GRDB l'activent pour toi."]
  ],
  quiz:[
    {q:"Dans une relation 1-N, où se place la clé étrangère ?", o:["Côté « 1 »","Côté « N »","Dans une troisième table"], a:1, e:"Chaque tâche (côté N) pointe vers sa liste (côté 1)."},
    {q:"Que faut-il pour une relation N-N ?", o:["Une table de liaison","Une colonne TEXT","Un trigger"], a:0, e:"La table de liaison contient les deux clés étrangères."},
    {q:"Que fait ON DELETE CASCADE ?", o:["Supprime aussi les lignes enfants","Bloque la suppression","Met la clé à NULL"], a:0, e:"Supprimer une liste supprime automatiquement ses tâches."}
  ],
  ex:{type:'check', enonce:"Mini-projet : écris le schéma SQL de ton app de tâches, puis coche chaque étape.",
    items:["Une table listes et une table taches, avec une clé primaire chacune","Une clé étrangère taches.liste_id avec ON DELETE CASCADE","Une table tags et une table de liaison tache_tag","Les colonnes NOT NULL et DEFAULT bien choisies (fait DEFAULT 0)","3 INSERT de test par table et un SELECT avec jointure à vérifier au jour 6"],
    starter:{lang:'sql', code:`-- Point de départ
CREATE TABLE listes (
  id  INTEGER PRIMARY KEY,
  nom TEXT NOT NULL
);
-- À toi : taches, tags, tache_tag...`}}
},
{ n:6, sem:1, titre:"Jointures", sub:"INNER, LEFT, auto-jointure",
  but:"À la fin, tu sais combiner plusieurs tables dans une seule requête.",
  l:[
    ['p',"Une jointure recolle des lignes de deux tables grâce à la clé étrangère."],
    ['c','sql',`SELECT t.titre, l.nom
FROM taches t
INNER JOIN listes l ON l.id = t.liste_id;`],
    ['p',"`INNER JOIN` garde uniquement les correspondances. `LEFT JOIN` garde toutes les lignes de gauche, avec `NULL` quand il n'y a rien à droite."],
    ['c','sql',`-- Nombre de tâches par liste, y compris les listes vides
SELECT l.nom, COUNT(t.id) AS nb
FROM listes l
LEFT JOIN taches t ON t.liste_id = l.id
GROUP BY l.id;`],
    ['p',"Une **auto-jointure** relie une table à elle-même. Il faut donner deux alias différents."],
    ['c','sql',`SELECT e.nom, m.nom AS manager
FROM employes e
LEFT JOIN employes m ON m.id = e.manager_id;`]
  ],
  quiz:[
    {q:"Quelle jointure affiche aussi les listes sans tâche ?", o:["INNER JOIN","LEFT JOIN depuis listes","Aucune"], a:1, e:"LEFT JOIN conserve toutes les lignes de la table de gauche."},
    {q:"Que faut-il pour joindre une table à elle-même ?", o:["Des alias","Un trigger","Un index unique"], a:0, e:"Sans alias, SQL ne sait pas de quelle « copie » de la table tu parles."},
    {q:"À quoi sert ON dans une jointure ?", o:["Définir la condition de correspondance","Trier","Limiter"], a:0, e:"ON dit quelles colonnes doivent être égales."}
  ],
  ex:{type:'chips', enonce:"Affiche le titre de chaque tâche avec le nom de sa liste.", tables:"taches(id, titre, liste_id)  listes(id, nom)",
    sol:["SELECT t.titre, l.nom","FROM taches t","INNER JOIN listes l","ON l.id = t.liste_id;"], d:["CROSS JOIN listes l","ON t.id = l.liste_id;"]}
},
{ n:7, sem:1, titre:"Requêtes malignes", sub:"Sous-requêtes, CASE, dates, texte",
  but:"À la fin, tu sais écrire une logique conditionnelle et manipuler dates et textes.",
  l:[
    ['p',"Une **sous-requête** est une requête placée dans une autre."],
    ['c','sql',`SELECT titre FROM taches
WHERE liste_id IN (SELECT id FROM listes WHERE nom = 'Travail');`],
    ['p',"`CASE` est le if/else de SQL."],
    ['c','sql',`SELECT titre,
  CASE WHEN fait = 1 THEN 'Terminé' ELSE 'À faire' END AS statut
FROM taches;`],
    ['p',"Dates et textes :"],
    ['c','sql',`SELECT date('now'),                  -- aujourd'hui
       date('now', '-7 days'),       -- il y a 7 jours
       strftime('%Y-%m', creee_le),  -- année-mois
       UPPER(titre), LENGTH(titre),
       SUBSTR(titre, 1, 3),
       titre || ' !'                 -- concaténation
FROM taches;`],
    ['t',"SQLite stocke les dates en TEXT au format 'AAAA-MM-JJ' ou en INTEGER (timestamp). Le format ISO se trie correctement."]
  ],
  quiz:[
    {q:"Quel opérateur concatène deux textes en SQLite ?", o:["+","||","&"], a:1, e:"'Bon' || 'jour' donne 'Bonjour'."},
    {q:"Que renvoie date('now', '-7 days') ?", o:["La date d'il y a 7 jours","La date dans 7 jours","Une erreur"], a:0, e:"Le modificateur '-7 days' recule de 7 jours."},
    {q:"CASE sert à…", o:["Écrire un if/else","Faire une boucle","Créer un index"], a:0, e:"CASE WHEN condition THEN valeur ELSE autre END."}
  ],
  ex:{type:'chips', enonce:"Affiche les tâches créées durant les 7 derniers jours.", tables:"taches(id, titre, creee_le)",
    sol:["SELECT * FROM taches","WHERE creee_le",">=","date('now', '-7 days');"], d:["<=","date('now', '+7 days');"]}
},
{ n:8, sem:1, titre:"Index et performance", sub:"CREATE INDEX, EXPLAIN QUERY PLAN",
  but:"À la fin, tu sais rendre une requête lente rapide, et le prouver.",
  l:[
    ['p',"Un **index** fonctionne comme l'index d'un livre : SQLite trouve les lignes sans lire toute la table. Le prix : un peu d'espace disque et des écritures légèrement plus lentes."],
    ['c','sql',`CREATE INDEX idx_taches_liste ON taches(liste_id);`],
    ['p',"Pour vérifier qu'un index est utilisé :"],
    ['c','sql',`EXPLAIN QUERY PLAN
SELECT * FROM taches WHERE liste_id = 2;
-- SEARCH taches USING INDEX idx_taches_liste (bon)
-- SCAN taches (lecture complète, à éviter)`],
    ['t',"Indexe les colonnes utilisées souvent dans WHERE, JOIN et ORDER BY, ainsi que les clés étrangères. N'indexe pas tout : chaque index ralentit INSERT et UPDATE."]
  ],
  quiz:[
    {q:"Que signifie SCAN dans EXPLAIN QUERY PLAN ?", o:["Lecture de toute la table","Utilisation d'un index","Une erreur"], a:0, e:"SEARCH ... USING INDEX est ce que tu veux voir."},
    {q:"Quel est l'inconvénient d'un index ?", o:["Il ralentit INSERT et UPDATE","Il interdit les jointures","Il supprime les doublons"], a:0, e:"L'index doit être mis à jour à chaque écriture."},
    {q:"Comment savoir si une requête utilise un index ?", o:["EXPLAIN QUERY PLAN","SHOW INDEX","CHECK PLAN"], a:0, e:"Place EXPLAIN QUERY PLAN juste avant ton SELECT."}
  ],
  ex:{type:'chips', enonce:"Crée un index nommé idx_depenses_date sur la colonne date de la table depenses.", tables:"depenses(id, montant, date, categorie)",
    sol:["CREATE INDEX","idx_depenses_date","ON depenses(date);"], d:["CREATE TABLE","INDEX ON"]}
},
{ n:9, sem:1, titre:"Transactions", sub:"ACID, COMMIT, ROLLBACK",
  but:"À la fin, tu sais garantir que plusieurs requêtes réussissent ensemble, ou pas du tout.",
  l:[
    ['p',"Une **transaction** regroupe plusieurs requêtes : tout est validé, ou rien. Exemple : un virement doit retirer et ajouter l'argent, jamais un seul des deux."],
    ['c','sql',`BEGIN;
UPDATE comptes SET solde = solde - 50 WHERE id = 1;
UPDATE comptes SET solde = solde + 50 WHERE id = 2;
COMMIT;   -- ou ROLLBACK; pour tout annuler`],
    ['p',"**ACID** : **A**tomicité (tout ou rien), **C**ohérence (les règles restent vraies), **I**solation (les transactions ne se marchent pas dessus), **D**urabilité (une fois validé, c'est écrit)."],
    ['t',"Mettre 1000 INSERT dans une seule transaction est souvent 100 fois plus rapide que 1000 transactions séparées, car SQLite n'écrit sur le disque qu'une fois."]
  ],
  quiz:[
    {q:"Que veut dire le A de ACID ?", o:["Atomicité","Accès","Automatisation"], a:0, e:"Atomicité : la transaction est indivisible."},
    {q:"Que fait ROLLBACK ?", o:["Annule les changements de la transaction","Valide la transaction","Supprime la table"], a:0, e:"Toute la transaction est défaite, comme si rien ne s'était passé."},
    {q:"Pourquoi grouper des INSERT dans une transaction ?", o:["C'est beaucoup plus rapide","Seulement pour la lisibilité","C'est obligatoire"], a:0, e:"Une seule écriture disque au lieu d'une par requête."}
  ],
  ex:{type:'chips', enonce:"Écris le virement de 50 € du compte 1 vers le compte 2, dans une transaction.", tables:"comptes(id, solde)", j:'\n',
    sol:["BEGIN;","UPDATE comptes SET solde = solde - 50 WHERE id = 1;","UPDATE comptes SET solde = solde + 50 WHERE id = 2;","COMMIT;"], d:["ROLLBACK;"]}
},
{ n:10, sem:1, titre:"Vues, triggers, migrations", sub:"Projet mi-parcours : app de dépenses",
  but:"À la fin, tu as un schéma de dépenses complet, avec vue, index et statistiques.",
  l:[
    ['p',"Une **vue** est une requête enregistrée sous un nom, que tu interroges comme une table."],
    ['c','sql',`CREATE VIEW v_total_categorie AS
SELECT categorie, SUM(montant) AS total
FROM depenses GROUP BY categorie;

SELECT * FROM v_total_categorie;`],
    ['p',"Un **trigger** s'exécute tout seul lors d'un INSERT, UPDATE ou DELETE."],
    ['c','sql',`CREATE TRIGGER maj_modif AFTER UPDATE ON taches
BEGIN
  UPDATE taches SET modifie_le = datetime('now') WHERE id = NEW.id;
END;`],
    ['p',"Une **migration** fait évoluer le schéma sans perdre les données utilisateur."],
    ['c','sql',`ALTER TABLE depenses ADD COLUMN note TEXT;`],
    ['t',"ALTER TABLE gère bien ADD COLUMN et RENAME. Pour changer un type ou supprimer une contrainte : crée la nouvelle table, copie les données, supprime l'ancienne, renomme la nouvelle."]
  ],
  quiz:[
    {q:"Qu'est-ce qu'une vue ?", o:["Une requête enregistrée sous un nom","Une copie physique des données","Un index"], a:0, e:"Elle ne stocke pas de données : elle relance la requête à chaque lecture."},
    {q:"Quand un trigger s'exécute-t-il ?", o:["Automatiquement lors d'un INSERT, UPDATE ou DELETE","Toutes les heures","Quand on l'appelle"], a:0, e:"Il réagit à un événement sur une table."},
    {q:"À quoi sert une migration ?", o:["Faire évoluer le schéma sans perdre les données","Déplacer la base sur un serveur","Supprimer la base"], a:0, e:"Indispensable dès que l'app est publiée : les utilisateurs ont déjà des données."}
  ],
  ex:{type:'check', enonce:"Projet mi-parcours : construis la base d'une app de dépenses, puis coche chaque étape.",
    items:["Tables categories(id, nom) et depenses(id, montant, date, note, categorie_id)","Clé étrangère depenses.categorie_id vers categories","Un index sur depenses(date)","Une vue v_total_categorie avec SUM et GROUP BY","Une requête « total du mois » avec strftime('%Y-%m', date)","Un ALTER TABLE qui ajoute une colonne, testé sans perdre les données"],
    starter:{lang:'sql', code:`SELECT c.nom, SUM(d.montant) AS total
FROM depenses d
INNER JOIN categories c ON c.id = d.categorie_id
WHERE strftime('%Y-%m', d.date) = strftime('%Y-%m', 'now')
GROUP BY c.id
ORDER BY total DESC;`}}
},
{ n:11, sem:2, titre:"SQLite sur le téléphone", sub:"Fichier local, requêtes paramétrées, injection SQL",
  but:"À la fin, tu sais où vit ta base et comment l'interroger sans faille de sécurité.",
  l:[
    ['p',"Sur mobile, la base est un **fichier privé à ton app** : dossier `databases/` sur Android, `Application Support` sur iOS. Aucune autre app ne peut le lire sur un appareil non modifié."],
    ['p',"Le danger : construire une requête en collant le texte de l'utilisateur. C'est l'**injection SQL**. Si quelqu'un tape `x' OR '1'='1`, il récupère toutes les lignes."],
    ['c','kt',`// ❌ Vulnérable
db.rawQuery("SELECT * FROM users WHERE nom = '$saisie'", null)

// ✅ Requête paramétrée
db.rawQuery("SELECT * FROM users WHERE nom = ?", arrayOf(saisie))`],
    ['t',"Le ? est un paramètre : la valeur est envoyée à part, jamais interprétée comme du SQL. Room, GRDB et SwiftData le font pour toi, mais uniquement si tu n'assembles pas le SQL à la main."]
  ],
  quiz:[
    {q:"Comment se protéger de l'injection SQL ?", o:["Requêtes paramétrées","Doubles guillemets","Tout écrire en majuscules"], a:0, e:"La valeur reste une donnée, elle ne devient jamais une instruction."},
    {q:"Où se trouve la base sur un téléphone ?", o:["Dans un fichier local de l'app","Dans le cloud","Uniquement en mémoire"], a:0, e:"Un fichier SQLite privé, sans serveur."},
    {q:"Que représente le ? dans une requête ?", o:["Un paramètre lié à une valeur","Un joker de LIKE","Un commentaire"], a:0, e:"Il est remplacé par la valeur fournie dans arrayOf(...)."}
  ],
  ex:{type:'chips', enonce:"Assemble la requête Kotlin paramétrée qui cherche un utilisateur par nom.", tables:"users(id, nom)", j:'',
    sol:['db.rawQuery(', `"SELECT * FROM users WHERE nom = ?", `, 'arrayOf(saisie)', ')'], d:[`"SELECT * FROM users WHERE nom = '$saisie'", `]}
},
{ n:12, sem:2, titre:"Android avec Room", sub:"Entity, DAO, Database en Kotlin",
  but:"À la fin, tu sais brancher SQLite dans une app Android avec Room.",
  l:[
    ['p',"**Room** est la couche officielle au-dessus de SQLite. Trois pièces : **Entity** (la table), **DAO** (les requêtes), **Database** (le point d'entrée)."],
    ['c','kt',`@Entity(tableName = "taches")
data class Tache(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val titre: String,
  val fait: Boolean = false
)`],
    ['c','kt',`@Dao
interface TacheDao {
  @Query("SELECT * FROM taches WHERE fait = 0 ORDER BY titre")
  fun aFaire(): Flow<List<Tache>>

  @Insert suspend fun ajouter(t: Tache)
  @Delete suspend fun supprimer(t: Tache)
}

@Database(entities = [Tache::class], version = 1)
abstract class AppDb : RoomDatabase() {
  abstract fun taches(): TacheDao
}`],
    ['p',"Room **vérifie ton SQL à la compilation** : une faute de frappe dans un `@Query` fait échouer le build, pas l'app chez l'utilisateur. Un `Flow` renvoie une nouvelle liste à chaque changement de la table."],
    ['t',"Dépendances : androidx.room:room-runtime, room-ktx et le compilateur room-compiler via KSP."]
  ],
  quiz:[
    {q:"Quelle annotation décrit une table dans Room ?", o:["@Entity","@Table","@Model"], a:0, e:"@Entity sur une data class, une ligne = une instance."},
    {q:"Que contient un DAO ?", o:["Les requêtes","Les données","Les migrations"], a:0, e:"DAO = Data Access Object : les fonctions qui lisent et écrivent."},
    {q:"Quand Room vérifie-t-il tes requêtes SQL ?", o:["À la compilation","Jamais","Seulement en production"], a:0, e:"Erreur détectée avant même de lancer l'app."}
  ],
  ex:{type:'chips', enonce:"Déclare un DAO avec une requête réactive qui renvoie les tâches non faites.", tables:"taches(id, titre, fait)", j:'\n',
    sol:["@Dao","interface TacheDao {",`@Query("SELECT * FROM taches WHERE fait = 0")`,"fun aFaire(): Flow<List<Tache>>","}"], d:["@Entity","fun aFaire(): List<Tache>"]}
},
{ n:13, sem:2, titre:"iOS avec SwiftData ou GRDB", sub:"Aperçu de Core Data",
  but:"À la fin, tu sais choisir l'outil iOS qui convient à ton projet.",
  l:[
    ['p',"**SwiftData** (iOS 17+) : moderne, écrit en Swift pur, tu ne vois presque pas de SQL. **GRDB** : une bibliothèque au-dessus de SQLite où tu écris ton propre SQL. **Core Data** : l'ancêtre de SwiftData, encore présent dans beaucoup d'apps."],
    ['c','swift',`// SwiftData
@Model
class Tache {
  var titre: String
  var fait = false
  init(titre: String) { self.titre = titre }
}

// Dans une vue SwiftUI : la liste se met à jour toute seule
@Query(filter: #Predicate<Tache> { !$0.fait }, sort: \\.titre)
var aFaire: [Tache]`],
    ['c','swift',`// GRDB : SQL explicite, le même schéma qu'Android
struct Tache: Codable, FetchableRecord, PersistableRecord {
  var id: Int64?
  var titre: String
  var fait: Bool
}

let aFaire = try dbQueue.read { db in
  try Tache.fetchAll(db, sql: "SELECT * FROM taches WHERE fait = 0")
}`],
    ['t',"Tu veux réutiliser exactement le même schéma SQL sur Android et iOS ? Choisis GRDB. Tu préfères écrire moins de code sur iOS uniquement ? Choisis SwiftData."]
  ],
  quiz:[
    {q:"Quel outil te laisse écrire du SQL directement ?", o:["GRDB","SwiftData","SwiftUI"], a:0, e:"GRDB fournit un accès direct à SQLite."},
    {q:"SwiftData demande au minimum…", o:["iOS 17","iOS 12","macOS uniquement"], a:0, e:"Avant iOS 17, il faut Core Data ou GRDB."},
    {q:"Que fait @Model ?", o:["Rend une classe persistante","Ouvre une connexion réseau","Génère un fichier SQL"], a:0, e:"C'est une macro : la classe devient une table gérée par SwiftData."}
  ],
  ex:{type:'chips', enonce:"Déclare le modèle SwiftData d'une tâche (titre et fait).", tables:"Tache(titre, fait)", j:'\n',
    sol:["@Model","class Tache {","var titre: String","var fait = false","}"], d:["@Entity","@Query"]}
},
{ n:14, sem:2, titre:"Mobile en vrai", sub:"Migrations, hors ligne, sync, pagination, requêtes réactives",
  but:"À la fin, tu connais les 5 pièges qui distinguent une démo d'une vraie app.",
  l:[
    ['p',"**Migrations.** Chaque changement de schéma augmente le numéro de version. Room : `AutoMigration(from = 1, to = 2)` ou une `Migration` manuelle. GRDB : `DatabaseMigrator`. SwiftData : `VersionedSchema`."],
    ['c','sql',`-- Migration 1 -> 2
ALTER TABLE notes ADD COLUMN synchro INTEGER NOT NULL DEFAULT 0;`],
    ['p',"**Hors ligne d'abord.** L'écran lit toujours la base locale. Le réseau ne fait que mettre la base à jour. Ainsi l'app marche dans le métro."],
    ['p',"**Synchronisation.** Ajoute `modifie_le`, `synchro` (0 ou 1) et `supprime_le` (suppression douce). Tu envoies au serveur les lignes où `synchro = 0`."],
    ['p',"**Pagination.** `OFFSET 20000` doit parcourir 20 000 lignes. Préfère la pagination par curseur :"],
    ['c','sql',`SELECT * FROM notes
WHERE id < :dernierId
ORDER BY id DESC
LIMIT 20;`],
    ['p',"**Requêtes réactives.** Android : `Flow` (Room). iOS : `ValueObservation` (GRDB), `@Query` (SwiftData) ou Combine. L'écran se rafraîchit dès que la table change."]
  ],
  quiz:[
    {q:"Quelle pagination reste rapide sur 100 000 lignes ?", o:["Par curseur (WHERE id < ?)","OFFSET très grand","Tout charger en mémoire"], a:0, e:"Avec un index sur id, SQLite saute directement au bon endroit."},
    {q:"Dans une app « hors ligne d'abord », quelle est la source de vérité de l'écran ?", o:["La base locale","Le serveur","La RAM"], a:0, e:"L'UI lit la base, la synchronisation met la base à jour."},
    {q:"Que faut-il faire pour ajouter une colonne dans une app publiée ?", o:["Une migration avec une nouvelle version","Rien","Demander de réinstaller l'app"], a:0, e:"Sans migration, l'app plante ou efface les données des utilisateurs."}
  ],
  ex:{type:'chips', enonce:"Écris la requête de pagination par curseur : 20 notes plus anciennes que :dernierId.", tables:"notes(id, titre)",
    sol:["SELECT * FROM notes","WHERE id < :dernierId","ORDER BY id DESC","LIMIT 20;"], d:["OFFSET 20000","ORDER BY id ASC"]}
},
{ n:15, sem:2, titre:"Projet final", sub:"Notes ou dépenses, Android + iOS, même schéma SQL",
  but:"À la fin, tu as une vraie app avec une base SQL partagée entre Android et iOS.",
  l:[
    ['p',"Tu construis une **app de notes** (ou de dépenses) sur Android avec Room et sur iOS avec GRDB ou SwiftData. Le schéma SQL est identique des deux côtés."],
    ['c','sql',`CREATE TABLE notes (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  titre      TEXT NOT NULL,
  contenu    TEXT NOT NULL DEFAULT '',
  cree_le    TEXT NOT NULL DEFAULT (datetime('now')),
  modifie_le TEXT NOT NULL DEFAULT (datetime('now')),
  synchro    INTEGER NOT NULL DEFAULT 0,
  supprime_le TEXT
);
CREATE TABLE tags (id INTEGER PRIMARY KEY, nom TEXT NOT NULL UNIQUE);
CREATE TABLE note_tag (
  note_id INTEGER REFERENCES notes(id) ON DELETE CASCADE,
  tag_id  INTEGER REFERENCES tags(id)  ON DELETE CASCADE,
  PRIMARY KEY (note_id, tag_id)
);
CREATE INDEX idx_notes_modifie ON notes(modifie_le);`],
    ['t',"Avance par petites étapes : d'abord le schéma testé dans DB Browser for SQLite, puis Android, puis iOS. Chaque plateforme ne doit contenir que la couche d'accès aux données propre à son outil."]
  ],
  quiz:[
    {q:"Pourquoi garder le même schéma SQL sur Android et iOS ?", o:["Pour simplifier la synchronisation et la maintenance","C'est obligatoire","Pour économiser de la mémoire"], a:0, e:"Une seule structure à documenter, migrer et synchroniser avec le serveur."},
    {q:"Quelle colonne permet une suppression douce ?", o:["supprime_le","cree_le","synchro"], a:0, e:"Tu marques la ligne au lieu de la supprimer, et le serveur apprend la suppression à la prochaine sync."},
    {q:"Où tester le schéma en premier ?", o:["Dans un outil SQLite comme DB Browser","Directement en production","Dans le cloud"], a:0, e:"Tu corriges plus vite qu'en recompilant deux apps."}
  ],
  ex:{type:'check', enonce:"Projet final : construis l'app, puis coche chaque étape terminée.",
    items:["Le schéma SQL est testé dans DB Browser for SQLite","Android : Entity, DAO et Database Room avec un Flow qui alimente l'écran","iOS : GRDB ou SwiftData avec une liste qui se met à jour toute seule","Créer, modifier, supprimer une note fonctionne sur les deux plateformes","Recherche avec LIKE et pagination par curseur","Une migration v1 vers v2 (ajout d'une colonne) testée sans perte de données"],
    starter:null}
}
];
const CHEAT = [
 {t:"Créer une table", l:'sql', c:`CREATE TABLE taches (
  id INTEGER PRIMARY KEY,
  titre TEXT NOT NULL,
  fait INTEGER DEFAULT 0
);`},
 {t:"Insérer", l:'sql', c:`INSERT INTO taches (titre) VALUES ('Lire');`},
 {t:"Lire, filtrer, trier", l:'sql', c:`SELECT titre FROM taches
WHERE fait = 0 ORDER BY titre LIMIT 10;`},
 {t:"Modifier", l:'sql', c:`UPDATE taches SET fait = 1 WHERE id = 3;`},
 {t:"Supprimer", l:'sql', c:`DELETE FROM taches WHERE id = 3;`},
 {t:"Compter et regrouper", l:'sql', c:`SELECT priorite, COUNT(*) FROM taches
GROUP BY priorite HAVING COUNT(*) > 2;`},
 {t:"Jointure", l:'sql', c:`SELECT t.titre, l.nom FROM taches t
LEFT JOIN listes l ON l.id = t.liste_id;`},
 {t:"Sous-requête", l:'sql', c:`SELECT * FROM taches WHERE liste_id IN
  (SELECT id FROM listes WHERE nom = 'Travail');`},
 {t:"Condition CASE", l:'sql', c:`CASE WHEN fait = 1 THEN 'Terminé' ELSE 'À faire' END`},
 {t:"Dates", l:'sql', c:`date('now', '-7 days')
strftime('%Y-%m', creee_le)`},
 {t:"Index et plan d'exécution", l:'sql', c:`CREATE INDEX idx_taches_liste ON taches(liste_id);
EXPLAIN QUERY PLAN SELECT ...;`},
 {t:"Transaction", l:'sql', c:`BEGIN;
-- requêtes...
COMMIT;   -- ou ROLLBACK;`},
 {t:"Vue", l:'sql', c:`CREATE VIEW v_total AS
SELECT categorie, SUM(montant) AS total
FROM depenses GROUP BY categorie;`},
 {t:"Migration simple", l:'sql', c:`ALTER TABLE depenses ADD COLUMN note TEXT;`},
 {t:"Requête paramétrée (Android)", l:'kt', c:`db.rawQuery("SELECT * FROM users WHERE nom = ?", arrayOf(saisie))`},
 {t:"Room : requête réactive", l:'kt', c:`@Query("SELECT * FROM taches")
fun toutes(): Flow<List<Tache>>`},
 {t:"SwiftData : modèle", l:'swift', c:`@Model class Tache {
  var titre: String
  init(titre: String) { self.titre = titre }
}`}
];
const esc = s => String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
const inline = s => esc(s).replace(/`([^`]+)`/g,'<code>$1</code>').replace(/\*\*([^*]+)\*\*/g,'<b>$1</b>');

const SQLW = 'SELECT|FROM|WHERE|ORDER|GROUP|BY|HAVING|LIMIT|OFFSET|INSERT|INTO|VALUES|UPDATE|SET|DELETE|CREATE|TABLE|INDEX|VIEW|TRIGGER|ALTER|ADD|COLUMN|PRIMARY|KEY|AUTOINCREMENT|NOT|NULL|UNIQUE|DEFAULT|REFERENCES|ON|CASCADE|INNER|LEFT|JOIN|AS|AND|OR|IN|LIKE|CASE|WHEN|THEN|ELSE|END|BEGIN|COMMIT|ROLLBACK|AFTER|EXPLAIN|QUERY|PLAN|ASC|DESC|COUNT|SUM|AVG|MIN|MAX|PRAGMA|INTEGER|TEXT|REAL|BLOB|IS|DISTINCT|USING';
const SQLRE = new RegExp("(--[^\\n]*)|('(?:[^']|'')*')|\\b(" + SQLW + ")\\b|\\b(\\d+(?:\\.\\d+)?)\\b", 'gi');
const CODEW = 'val|var|fun|class|interface|abstract|data|suspend|override|struct|let|try|import|return|init|func|if|else|in|enum|object|private|public|Flow|List|String|Int|Long|Boolean|Int64|Codable';
const CODERE = new RegExp('(//[^\\n]*)|("(?:[^"\\\\\\n]|\\\\.)*")|(@\\w+|#\\w+)|\\b(' + CODEW + ')\\b|\\b(\\d+)\\b', 'g');
function rng(seed){ let a = seed >>> 0; return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
function shuffle(arr, seed){ const r = rng(seed), a = arr.slice(); for(let i = a.length - 1; i > 0; i--){ const j = Math.floor(r() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
const AGG = /^(COUNT|SUM|AVG|MIN|MAX)$/i;
function hl(code, lang){
  const c = esc(code);
  if(lang === 'sql'){
    return c.replace(SQLRE, (m, com, str, kw, num) =>
      com ? `<span class="cmt">${m}</span>` : str ? `<span class="str">${m}</span>` :
      kw ? (AGG.test(m) ? `<span class="fn">${m}</span>` : `<span class="kw">${m}</span>`) : `<span class="num">${m}</span>`);
  }
  return c.replace(CODERE, (m, com, str, ann, kw, num) =>
    com ? `<span class="cmt">${m}</span>` : str ? `<span class="str">${m}</span>` :
    ann ? `<span class="fn">${m}</span>` : kw ? `<span class="kw">${m}</span>` : `<span class="num">${m}</span>`);
}
const LANG_LABEL = { sql:'sql', kt:'kotlin', swift:'swift' };
const DOTS = '<div class="code-dots"><div class="code-dot" style="background:#ff5f56"></div><div class="code-dot" style="background:#ffbd2e"></div><div class="code-dot" style="background:#27c93f"></div></div>';
const codeBlock = (code, lang) => `<div class="code-block"><div class="code-header">${DOTS}<span class="code-lang">${LANG_LABEL[lang] || lang}</span></div><div class="code-content">${hl(code, lang)}</div></div>`;

function lesson(day){
  let h = `<div class="cell"><div class="cell-head"><span class="cell-tag">In [${day.n}]</span> Théorie — Jour ${day.n}</div><div class="cell-body">`;
  h += `<div class="theory-block"><h3>🎯 Objectif du jour</h3><p>${inline(day.but)}</p></div>`;
  day.l.forEach(b => {
    if(b[0] === 'p') h += `<div class="theory-block"><p>${inline(b[1])}</p></div>`;
    else if(b[0] === 'c') h += codeBlock(b[2], b[1]);
    else if(b[0] === 't') h += `<div class="tip-box"><strong>💡 Astuce :</strong> ${inline(b[1])}</div>`;
    else if(b[0] === 'tbl'){
      h += `<div class="sql-table"><table><thead><tr>${b[1].map(c => `<th>${esc(c)}</th>`).join('')}</tr></thead><tbody>${b[2].map(r => `<tr>${r.map(c => `<td>${esc(c)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
    }
  });
  return h + `</div></div>`;
}
const exLang = n => (n === 11 || n === 12) ? 'kt' : n === 13 ? 'swift' : 'sql';
const LEVELS = ['easy', 'med', 'hard'];

const curriculum = SQL_WEEKS.map((w, wi) => ({
  week: w,
  days: DAYS.filter(x => x.sem === wi).map(x => ({
    d: x.n, title: x.titre, sub: x.sub, level: LEVELS[wi],
    theory: lesson(x),
    starter: '',
    quiz: x.quiz.map(q => ({ q: inline(q.q), opts: q.o.map(esc), ans: q.a, e: inline(q.e) })),
    ex: x.ex,
    exLang: exLang(x.n)
  }))
}));

return { curriculum, cheat: CHEAT, esc, inline, codeBlock, shuffle };
})();
const CURRICULUM_SQL = SQLMOD.curriculum;
