/* ========================= CURRICULUM PYTHON ========================= */
const CURRICULUM_PY = [
{ week:"Semaine 1 — Les fondations", days:[
{d:1, title:"Premiers pas en Python", sub:"print(), variables et types de base", level:"easy",
 theory:`<div class="cell"><div class="cell-head"><span class="cell-tag">In [1]</span> Théorie — Chapitre 1</div><div class="cell-body">

<div class="theory-block"><h3>🐍 1.1 — Pourquoi Python, et comment il te lit</h3><p>Python a été conçu pour se lire presque comme du français : pas d'accolades, pas de point-virgule obligatoire, un minimum de symboles entre toi et ton idée. Quand tu lances un script, l'interpréteur Python lit ton fichier <b>de haut en bas, une instruction à la fois</b>, et exécute chaque ligne immédiatement — il n'y a pas de phase de compilation séparée comme dans d'autres langages. C'est ce qui rend le langage aussi agréable pour débuter : tu écris une ligne, tu vois le résultat, tu ajustes.</p></div>

<div class="theory-block"><h3>📐 1.2 — L'indentation : la grammaire du langage</h3><p>Dans la plupart des langages, on délimite un bloc de code avec <code>{ }</code>. En Python, ce rôle est joué par <b>l'indentation</b> : 4 espaces (jamais de tabulation mélangée à des espaces) au début d'une ligne signifient "cette ligne appartient au bloc précédent". Ce n'est pas juste une question d'esthétique — une indentation incohérente casse littéralement ton programme.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="varc">niveau</span> = <span class="str">"debutant"</span>
<span class="kw">if</span> <span class="varc">niveau</span> == <span class="str">"debutant"</span>:
    <span class="fn">print</span>(<span class="str">"Bienvenue !"</span>)  <span class="cmt"># 4 espaces : dans le bloc du if</span>
<span class="fn">print</span>(<span class="str">"Cette ligne s'exécute toujours"</span>)  <span class="cmt"># pas indentée : hors du bloc</span></div></div>
<div class="tip"><b>Piège fréquent —</b> mélanger espaces et tabulations, ou désaligner une ligne d'un seul espace, provoque une <code>IndentationError</code>. Un bon éditeur de code convertit automatiquement la touche Tab en 4 espaces : vérifie ce réglage dès le départ.</div>
</div>

<div class="theory-block"><h3>📦 1.3 — Créer des variables : nommer ce que tu manipules</h3><p>Une variable est une étiquette posée sur une valeur en mémoire. En Python, on la crée en une seule ligne, sans mot-clé (<code>var</code>, <code>let</code> et compagnie n'existent pas ici) : le simple fait d'écrire <code>nom = valeur</code> crée la variable si elle n'existait pas, ou la met à jour si elle existait déjà. C'est ce qu'on appelle le <b>typage dynamique</b> : une variable n'a pas de type fixé à l'avance, elle prend le type de la valeur qu'on lui donne, et peut même en changer plus tard.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="varc">age</span> = <span class="num">27</span>
<span class="varc">nom</span> = <span class="str">"Nerija"</span>
<span class="varc">actif</span> = <span class="kw">True</span>
<span class="varc">age</span> = <span class="str">"vingt-sept"</span>  <span class="cmt"># valide : age devient un texte</span></div></div>
<p>Une bonne convention de nommage évite bien des maux de tête plus tard : utilise le <code>snake_case</code> (mots en minuscules séparés par <code>_</code>), des noms explicites (<code>age_utilisateur</code> plutôt que <code>a</code>), et jamais de mot réservé du langage (<code>print</code>, <code>if</code>, <code>class</code>...) comme nom de variable.</p></div>

<div class="theory-block"><h3>🔢 1.4 — Les 4 types de base, un par un</h3><p><code>str</code> — une chaîne de caractères, toujours entre guillemets simples ou doubles : <code>"Nerija"</code>. <code>int</code> — un nombre entier, sans décimale : <code>27</code>. <code>float</code> — un nombre à virgule (flottant) : <code>1.78</code> — attention, en Python c'est un <b>point</b>, jamais une virgule. <code>bool</code> — une valeur logique qui ne peut valoir que <code>True</code> ou <code>False</code> (avec la majuscule), typiquement le résultat d'une comparaison comme <code>age &gt;= 18</code>.</p>
<p>Tu peux à tout moment vérifier le type réel d'une variable avec la fonction intégrée <code>type()</code> — un excellent réflexe de débogage quand un calcul renvoie un résultat surprenant.</p></div>

<div class="theory-block"><h3>✍️ 1.5 — Construire du texte : trois façons, une seule vraiment bonne</h3><p>Pour insérer une variable dans un texte, Python propose plusieurs syntaxes historiques, mais une seule est recommandée aujourd'hui.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="cmt"># 1. Concaténation avec + : fonctionne, mais lourde et fragile</span>
<span class="fn">print</span>(<span class="str">"Bonjour "</span> + <span class="varc">nom</span> + <span class="str">", tu as "</span> + <span class="fn">str</span>(<span class="varc">age</span>) + <span class="str">" ans"</span>)

<span class="cmt"># 2. f-string : lisible, rapide, la norme moderne</span>
<span class="fn">print</span>(<span class="str">f"Bonjour {nom}, tu as {age} ans"</span>)</div></div>
<div class="tip"><b>Astuce —</b> avec la concaténation <code>+</code>, tu dois convertir manuellement chaque nombre en texte avec <code>str()</code>, sinon Python lève une <code>TypeError</code> — impossible d'additionner un texte et un nombre. La f-string s'en charge automatiquement pour toi, c'est une raison de plus de l'adopter par défaut.</div>
</div>

<div class="tip-box"><strong>🔑 À retenir avant l'exercice</strong>
<ul style="margin:8px 0 0 18px;line-height:1.7">
<li>L'indentation (4 espaces) délimite les blocs — pas d'accolades.</li>
<li><code>nom = valeur</code> crée ou met à jour une variable, sans mot-clé.</li>
<li>4 types de base : <code>str</code>, <code>int</code>, <code>float</code>, <code>bool</code>.</li>
<li>Pour insérer une variable dans un texte : <code>f"...{variable}..."</code>.</li>
</ul></div>

</div></div>`,
 starter:`# Jour 1 : mes premieres variables
nom = "Nerija"
age = 27
taille = 1.78
apprenti = True

print("Bonjour, je m'appelle", nom)
print(f"J'ai {age} ans et je mesure {taille} m")
print("Suis-je debutant ?", apprenti)
print(nom, age, taille, apprenti)`,
 quiz:[
  {q:"Comment afficher du texte en Python ?", opts:["echo texte","print(\"texte\")","console.log","display"], ans:1},
  {q:"Quel mot-clé sert à créer une variable ?", opts:["var","let","aucun mot-clé nécessaire","dim"], ans:2},
  {q:"Quel type de donnée est True ?", opts:["str","int","bool","float"], ans:2}
 ]},
{d:2, title:"Entrées & opérateurs", sub:"input(), conversions et arithmétique", level:"easy",
 theory:`<div class="cell"><div class="cell-head"><span class="cell-tag">In [2]</span> Théorie — Chapitre 2</div><div class="cell-body">

<div class="theory-block"><h3>⌨️ 2.1 — input() : faire dialoguer ton programme avec l'utilisateur</h3><p>Jusqu'ici, toutes les valeurs de tes variables étaient écrites en dur dans le code. La fonction intégrée <code>input()</code> change ça : elle met le programme en pause, affiche un message optionnel entre parenthèses, attend que l'utilisateur tape quelque chose au clavier et appuie sur Entrée, puis renvoie ce qu'il a tapé. C'est la première brique d'un programme réellement interactif.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="varc">prenom</span> = <span class="fn">input</span>(<span class="str">"Quel est ton prenom ? "</span>)
<span class="fn">print</span>(<span class="str">f"Enchante, {prenom} !"</span>)</div></div>
<p>Le texte entre parenthèses (le <b>prompt</b>) n'est pas obligatoire — <code>input()</code> tout seul fonctionne aussi — mais l'omettre laisse l'utilisateur face à un curseur clignotant sans indication, ce qui est une mauvaise expérience. Prends l'habitude de toujours poser une question claire, terminée par un espace pour que la saisie ne colle pas directement au texte du prompt.</p></div>

<div class="theory-block"><h3>🔄 2.2 — Le piège numéro un : input() renvoie TOUJOURS du texte</h3><p>C'est le point le plus important de la journée, et la source d'erreur la plus fréquente chez les débutants : quoi que l'utilisateur tape — même s'il tape 27 — <code>input()</code> renvoie une <b>chaîne de caractères</b> (<code>str</code>), jamais un nombre. Tant que tu ne t'en sers que pour l'afficher, ce n'est pas un problème. Mais dès que tu veux calculer avec, il faut convertir explicitement.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="varc">age_texte</span> = <span class="fn">input</span>(<span class="str">"Ton age ? "</span>)  <span class="cmt"># age_texte est un str, meme si on tape 27</span>
<span class="fn">print</span>(<span class="fn">type</span>(<span class="varc">age_texte</span>))  <span class="cmt"># affiche : &lt;class 'str'&gt;</span>

<span class="varc">age</span> = <span class="fn">int</span>(<span class="varc">age_texte</span>)  <span class="cmt"># conversion explicite en entier</span>
<span class="fn">print</span>(<span class="varc">age</span> + <span class="num">1</span>)  <span class="cmt"># fonctionne : 28</span></div></div>
<p>Deux fonctions de conversion à connaître : <code>int()</code> transforme un texte en nombre entier (elle plante si le texte contient une virgule ou des lettres), <code>float()</code> transforme un texte en nombre à virgule et accepte aussi bien "1.78" que "27". En pratique, on chaîne très souvent les deux appels sur une seule ligne, comme le fait ton exercice du jour avec l'année de naissance.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="varc">naissance</span> = <span class="fn">int</span>(<span class="fn">input</span>(<span class="str">"En quelle annee es-tu ne ? "</span>))
<span class="varc">age</span> = <span class="num">2026</span> - <span class="varc">naissance</span></div></div>
<div class="tip"><b>Piège classique —</b> <code>"5" + "3"</code> ne donne pas 8 mais <code>"53"</code> : le <code>+</code> entre deux chaînes fait de la <b>concaténation</b> (coller les textes bout à bout), pas une addition. C'est exactement ce qui arrive si tu oublies de convertir le résultat de input() avant de calculer.</div>
</div>

<div class="theory-block"><h3>➗ 2.3 — Les opérateurs arithmétiques, un par un</h3><p>Python propose sept opérateurs arithmétiques. Les quatre premiers ne surprennent personne, les trois suivants méritent qu'on s'y arrête.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="fn">print</span>(<span class="num">7</span> + <span class="num">2</span>)   <span class="cmt"># 9  -&gt; addition</span>
<span class="fn">print</span>(<span class="num">7</span> - <span class="num">2</span>)   <span class="cmt"># 5  -&gt; soustraction</span>
<span class="fn">print</span>(<span class="num">7</span> * <span class="num">2</span>)   <span class="cmt"># 14 -&gt; multiplication</span>
<span class="fn">print</span>(<span class="num">7</span> / <span class="num">2</span>)   <span class="cmt"># 3.5 -&gt; division reelle (toujours un float)</span>
<span class="fn">print</span>(<span class="num">7</span> // <span class="num">2</span>)  <span class="cmt"># 3  -&gt; division entiere (on jette la partie decimale)</span>
<span class="fn">print</span>(<span class="num">7</span> % <span class="num">2</span>)   <span class="cmt"># 1  -&gt; modulo : le RESTE de la division</span>
<span class="fn">print</span>(<span class="num">7</span> ** <span class="num">2</span>)  <span class="cmt"># 49 -&gt; puissance (7 au carre)</span></div></div>
<p>La division <code>/</code> renvoie toujours un <code>float</code>, même quand le résultat est rond (<code>8 / 2</code> donne <code>4.0</code>, pas <code>4</code>). C'est <code>//</code> qu'il faut utiliser quand tu veux un résultat entier — par exemple pour calculer un nombre de paquets complets. Le modulo <code>%</code> est extrêmement utile pour détecter la parité d'un nombre (<code>n % 2 == 0</code> signifie que n est pair) ou pour faire "boucler" une valeur dans un intervalle.</p>
<div class="tip"><b>Astuce —</b> pense à <code>//</code> et <code>%</code> comme les deux moitiés d'une même division : <code>17 // 5</code> vaut 3 (3 fois 5 tient dans 17) et <code>17 % 5</code> vaut 2 (il reste 2). Tu retrouves toujours le nombre de départ avec <code>(17 // 5) * 5 + (17 % 5)</code>.</div>
</div>

<div class="theory-block"><h3>⚖️ 2.4 — Les opérateurs de comparaison : produire un booléen</h3><p>Une comparaison ne calcule pas un nombre, elle calcule une <b>vérité</b> : le résultat est toujours <code>True</code> ou <code>False</code>, le type <code>bool</code> vu au Jour 1. C'est la base de toutes les décisions que ton programme prendra plus tard, dès demain.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="varc">age</span> = <span class="num">19</span>
<span class="fn">print</span>(<span class="varc">age</span> == <span class="num">18</span>)   <span class="cmt"># False -&gt; egal a ?</span>
<span class="fn">print</span>(<span class="varc">age</span> != <span class="num">18</span>)   <span class="cmt"># True  -&gt; different de ?</span>
<span class="fn">print</span>(<span class="varc">age</span> &gt;= <span class="num">18</span>)   <span class="cmt"># True  -&gt; superieur ou egal ?</span>
<span class="fn">print</span>(<span class="varc">age</span> &lt; <span class="num">13</span>)    <span class="cmt"># False -&gt; strictement inferieur ?</span></div></div>
<div class="tip"><b>Piège fréquent —</b> ne confonds jamais <code>=</code> (affectation, "range cette valeur dans la variable") et <code>==</code> (comparaison, "est-ce que ces deux valeurs sont égales ?"). Écrire <code>if age = 18:</code> est une erreur de syntaxe en Python — le langage refuse même de l'exécuter, ce qui t'évite au moins de t'en rendre compte trop tard.</div>
</div>

<div class="theory-block"><h3>🧮 2.5 — Tout assembler : le mini-calcul de l'exercice</h3><p>L'exercice du jour enchaîne exactement les notions vues plus haut : demander un texte, demander un nombre (avec conversion), faire un calcul arithmétique simple, puis afficher une comparaison. C'est un schéma que tu retrouveras dans énormément de scripts réels — un programme qui interroge, calcule, puis répond.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="varc">naissance</span> = <span class="fn">int</span>(<span class="fn">input</span>(<span class="str">"En quelle annee es-tu ne ? "</span>))
<span class="varc">age</span> = <span class="num">2026</span> - <span class="varc">naissance</span>
<span class="fn">print</span>(<span class="str">"Es-tu majeur ?"</span>, <span class="varc">age</span> &gt;= <span class="num">18</span>)</div></div>
<p>Remarque que <code>print()</code> accepte plusieurs arguments séparés par des virgules : il les affiche à la suite, séparés automatiquement par un espace — pas besoin de f-string pour ça.</p></div>

<div class="tip-box"><strong>🔑 À retenir avant l'exercice</strong>
<ul style="margin:8px 0 0 18px;line-height:1.7">
<li><code>input()</code> renvoie toujours une chaîne de caractères — convertis avec <code>int()</code> ou <code>float()</code> avant de calculer.</li>
<li><code>/</code> donne toujours un float, <code>//</code> donne la division entière, <code>%</code> donne le reste.</li>
<li><code>**</code> est la puissance : <code>2 ** 3</code> vaut 8.</li>
<li>Une comparaison (<code>== != &lt; &gt; &lt;= &gt;=</code>) renvoie toujours un booléen, jamais un nombre.</li>
<li>Ne confonds jamais <code>=</code> (affectation) et <code>==</code> (comparaison).</li>
</ul></div>

</div></div>`,
 starter:`# Jour 2 : demander une info et calculer
prenom = input("Quel est ton prenom ? ")
naissance = int(input("En quelle annee es-tu ne ? "))
age = 2026 - naissance

print(f"Salut {prenom} ! Tu as environ {age} ans.")
print("Es-tu majeur ?", age >= 18)
print("Reste avant 30 ans :", 30 - age)`,
 quiz:[
  {q:"Que retourne toujours input() ?", opts:["Un nombre","Une chaîne de caractères","Un booléen","Une liste"], ans:1},
  {q:"Comment convertir une chaîne en entier ?", opts:["str()","int()","float()","bool()"], ans:1},
  {q:"Que vaut 7 // 2 en Python ?", opts:["3.5","3","4","1"], ans:1}
 ]},
{d:3, title:"Décisions", sub:"if, elif, else et opérateurs logiques", level:"easy",
 theory:`<div class="cell"><div class="cell-head"><span class="cell-tag">In [3]</span> Théorie — Chapitre 3</div><div class="cell-body">

<div class="theory-block"><h3>🚦 3.1 — if : la brique de base de la décision</h3><p>Un programme qui fait toujours exactement la même chose n'est pas très utile. <code>if</code> permet d'exécuter un bloc de code <b>seulement si</b> une condition est vraie. La condition est une expression qui vaut <code>True</code> ou <code>False</code> — typiquement une comparaison vue au Jour 2.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="varc">note</span> = <span class="num">14</span>
<span class="kw">if</span> <span class="varc">note</span> &gt;= <span class="num">10</span>:
    <span class="fn">print</span>(<span class="str">"Admis"</span>)</div></div>
<p>Comme pour toute structure de bloc en Python, deux règles sont non négociables : la ligne <code>if ...</code> se termine par <b>deux-points</b> <code>:</code>, et tout ce qui appartient au bloc est <b>indenté de 4 espaces</b> en dessous. Oublie l'un des deux et Python refuse d'exécuter le programme (<code>SyntaxError</code> ou <code>IndentationError</code>).</p></div>

<div class="theory-block"><h3>🪜 3.2 — elif et else : couvrir tous les cas</h3><p><code>else</code> définit ce qui se passe quand la condition du <code>if</code> est fausse — le "sinon" par défaut, sans condition propre. <code>elif</code> (contraction de "else if") ajoute un cas intermédiaire supplémentaire, avec sa propre condition, testée uniquement si tous les <code>if</code>/<code>elif</code> précédents ont échoué.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="kw">if</span> <span class="varc">note</span> &gt;= <span class="num">16</span>:
    <span class="varc">appreciation</span> = <span class="str">"Excellent"</span>
<span class="kw">elif</span> <span class="varc">note</span> &gt;= <span class="num">12</span>:
    <span class="varc">appreciation</span> = <span class="str">"Bien"</span>
<span class="kw">elif</span> <span class="varc">note</span> &gt;= <span class="num">10</span>:
    <span class="varc">appreciation</span> = <span class="str">"Passable"</span>
<span class="kw">else</span>:
    <span class="varc">appreciation</span> = <span class="str">"Insuffisant"</span></div></div>
<p>Point essentiel : Python évalue ce bloc <b>de haut en bas</b>, et s'arrête dès qu'une condition est vraie — les branches suivantes ne sont même pas regardées. Un <code>if</code>/<code>elif</code>/<code>else</code> exécute <b>une seule</b> de ses branches, jamais plusieurs, contrairement à une suite de <code>if</code> indépendants qui seraient tous testés séparément.</p></div>

<div class="theory-block"><h3>🎯 3.3 — Le piège de l'ordre : pourquoi 16 doit venir avant 10</h3><p>Regarde encore l'exemple précédent : les seuils sont rangés du <b>plus strict au plus large</b> (16, puis 12, puis 10). Ce n'est pas un hasard — c'est obligatoire. Si on inversait l'ordre, une note de 18 tomberait dans le premier <code>elif</code> qui matche et n'irait jamais vérifier les suivants.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="cmt"># VERSION BUGUEE : l'ordre des seuils est inverse</span>
<span class="kw">if</span> <span class="varc">note</span> &gt;= <span class="num">10</span>:
    <span class="varc">appreciation</span> = <span class="str">"Passable"</span>   <span class="cmt"># une note de 18 s'arrete ICI !</span>
<span class="kw">elif</span> <span class="varc">note</span> &gt;= <span class="num">16</span>:
    <span class="varc">appreciation</span> = <span class="str">"Excellent"</span>  <span class="cmt"># jamais atteint pour 18</span></div></div>
<div class="tip"><b>Réflexe à prendre —</b> quand tu écris une chaîne de seuils avec <code>elif</code>, pose-toi toujours la question : "si je prends la valeur la plus extrême possible, est-ce qu'elle est interceptée par la bonne branche ?" Range du cas le plus restrictif vers le plus large, exactement comme dans le barème de l'exercice.</div>
</div>

<div class="theory-block"><h3>🔗 3.4 — and, or, not : combiner plusieurs conditions</h3><p>Souvent, une seule comparaison ne suffit pas : il faut vérifier plusieurs critères à la fois. Trois opérateurs logiques permettent de les combiner.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="varc">age</span> = <span class="num">20</span>
<span class="varc">a_le_permis</span> = <span class="kw">True</span>

<span class="fn">print</span>(<span class="varc">age</span> &gt;= <span class="num">18</span> <span class="kw">and</span> <span class="varc">a_le_permis</span>)   <span class="cmt"># True seulement si LES DEUX sont vrais</span>
<span class="fn">print</span>(<span class="varc">age</span> &gt;= <span class="num">18</span> <span class="kw">or</span> <span class="varc">a_le_permis</span>)    <span class="cmt"># True si AU MOINS UNE des deux</span>
<span class="fn">print</span>(<span class="kw">not</span> <span class="varc">a_le_permis</span>)              <span class="cmt"># True -&gt; inverse la valeur</span></div></div>
<p><code>and</code> exige que <b>toutes</b> les conditions soient vraies pour valider l'ensemble — comme une porte avec deux serrures qui doivent être ouvertes en même temps. <code>or</code> se contente qu'<b>une seule</b> condition parmi plusieurs soit vraie. <code>not</code> ne prend qu'une seule condition et inverse purement et simplement sa valeur (<code>True</code> devient <code>False</code> et inversement).</p>
<div class="tip"><b>Astuce —</b> tu peux combiner plusieurs opérateurs, mais utilise des parenthèses pour rendre l'ordre d'évaluation explicite : <code>if (age &gt;= 18 and a_le_permis) or est_accompagne:</code> se lit sans ambiguïté, contrairement à la même ligne sans parenthèses.</div>
</div>

<div class="theory-block"><h3>🧩 3.5 — Assembler : construire un barème complet</h3><p>L'exercice du jour te fait construire exactement le barème vu en 3.2 : quatre appréciations possibles selon une note sur 20, saisie au clavier et convertie en entier (souviens-toi du Jour 2). Une fois la variable <code>appreciation</code> déterminée par le if/elif/else, il ne reste plus qu'à l'afficher avec une f-string.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="varc">note</span> = <span class="fn">int</span>(<span class="fn">input</span>(<span class="str">"Quelle note as-tu obtenue (/20) ? "</span>))

<span class="cmt"># ... if / elif / else pour determiner appreciation ...</span>

<span class="fn">print</span>(<span class="str">f"Note : {note}/20 -&gt; {appreciation}"</span>)</div></div>
<p>Remarque comment les deux journées se combinent naturellement : le Jour 2 t'a donné la saisie et la conversion, le Jour 3 t'apprend à réagir différemment selon la valeur obtenue. C'est exactement comme ça que les compétences s'empilent en programmation.</p></div>

<div class="tip-box"><strong>🔑 À retenir avant l'exercice</strong>
<ul style="margin:8px 0 0 18px;line-height:1.7">
<li><code>if</code> s'exécute seulement si sa condition est <code>True</code> ; <code>elif</code> ajoute des cas, <code>else</code> couvre le reste.</li>
<li>Un seul bloc s'exécute parmi if/elif/else, dans l'ordre, du haut vers le bas.</li>
<li>Range toujours les seuils du plus restrictif au plus large.</li>
<li><code>and</code> exige que tout soit vrai, <code>or</code> se contente d'une seule condition vraie, <code>not</code> inverse.</li>
<li>Le deux-points <code>:</code> et l'indentation délimitent chaque bloc — pas d'accolades.</li>
</ul></div>

</div></div>`,
 starter:`# Jour 3 : notes et appreciations
note = int(input("Quelle note as-tu obtenue (/20) ? "))

if note >= 16:
    appreciation = "Excellent"
elif note >= 12:
    appreciation = "Bien"
elif note >= 10:
    appreciation = "Passable"
else:
    appreciation = "Insuffisant"

print(f"Note : {note}/20 -> {appreciation}")`,
 quiz:[
  {q:"Quel mot-clé teste une condition supplémentaire après un if ?", opts:["elseif","elif","else if","elsif"], ans:1},
  {q:"Que fait \"and\" entre deux conditions ?", opts:["Vrai si l'une des deux est vraie","Vrai si les deux sont vraies","Inverse la condition","Rien"], ans:1},
  {q:"Un bloc if s'ouvre avec…", opts:["des accolades {}","une indentation après :","des parenthèses","un end"], ans:1}
 ]},
{d:4, title:"Boucles", sub:"for, while et range()", level:"easy",
 theory:`<div class="cell"><div class="cell-head"><span class="cell-tag">In [4]</span> Théorie — Chapitre 4</div><div class="cell-body">

<div class="theory-block"><h3>🔁 4.1 — for et range() : répéter un nombre de fois connu à l'avance</h3><p>Une boucle <code>for</code> répète un bloc de code une fois pour chaque élément d'une séquence. La séquence la plus commune pour "répéter N fois" est générée par la fonction intégrée <code>range()</code>, qui produit une suite de nombres entiers.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="kw">for</span> <span class="varc">i</span> <span class="kw">in</span> <span class="fn">range</span>(<span class="num">1</span>, <span class="num">4</span>):
    <span class="fn">print</span>(<span class="varc">i</span>)
<span class="cmt"># affiche 1, puis 2, puis 3</span></div></div>
<p>À chaque tour de boucle, la variable <code>i</code> (le nom est libre, mais <code>i</code> est une convention universelle pour "index") prend successivement chaque valeur de la séquence, et le bloc indenté s'exécute avec cette valeur.</p></div>

<div class="theory-block"><h3>📏 4.2 — range() en détail : la borne de fin est TOUJOURS exclue</h3><p><code>range()</code> accepte une, deux ou trois formes d'appel, et un piège systématique guette les débutants : la valeur de fin n'est <b>jamais incluse</b> dans la séquence produite.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="fn">range</span>(<span class="num">5</span>)         <span class="cmt"># 0, 1, 2, 3, 4        (une seule borne = de 0 a fin-1)</span>
<span class="fn">range</span>(<span class="num">1</span>, <span class="num">6</span>)      <span class="cmt"># 1, 2, 3, 4, 5        (debut inclus, fin EXCLUE)</span>
<span class="fn">range</span>(<span class="num">0</span>, <span class="num">10</span>, <span class="num">2</span>)  <span class="cmt"># 0, 2, 4, 6, 8        (troisieme argument = le pas)</span></div></div>
<p>Retiens-le ainsi : <code>range(1, 6)</code> génère "cinq nombres, à partir de 1" — la soustraction 6 - 1 te donne directement le nombre de tours (5), pas le dernier nombre atteint. C'est pour ça que l'exercice du jour utilise <code>range(1, 6)</code> pour afficher exactement les tours numéro 1 à 5.</p>
<div class="tip"><b>Piège fréquent —</b> vouloir compter jusqu'à 10 inclus et écrire <code>range(1, 10)</code> par réflexe — ça s'arrête à 9. Il faut écrire <code>range(1, 11)</code>.</div>
</div>

<div class="theory-block"><h3>⏳ 4.3 — while : répéter tant qu'une condition reste vraie</h3><p>Contrairement à <code>for</code>, qui répète un nombre de fois <b>connu à l'avance</b> (déterminé par la séquence), <code>while</code> répète tant qu'une condition évaluée à chaque tour reste vraie — utile quand tu ne sais pas d'avance combien de tours seront nécessaires.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="varc">compteur</span> = <span class="num">1</span>
<span class="kw">while</span> <span class="varc">compteur</span> &lt;= <span class="num">5</span>:
    <span class="fn">print</span>(<span class="str">f"Tour {compteur}"</span>)
    <span class="varc">compteur</span> = <span class="varc">compteur</span> + <span class="num">1</span>  <span class="cmt"># INDISPENSABLE : sinon boucle infinie</span></div></div>
<p>La ligne qui modifie <code>compteur</code> n'est pas optionnelle : une boucle <code>while</code> n'avance pas toute seule. Si tu oublies de mettre à jour la variable testée dans la condition, celle-ci reste éternellement vraie et ton programme se fige dans une <b>boucle infinie</b> — le bug classique du débutant sur ce chapitre.</p>
<div class="tip"><b>Astuce de débogage —</b> si ton programme semble "planté" sans erreur ni fin, pense d'abord à une boucle while dont la condition ne devient jamais fausse. Dans un vrai terminal, Ctrl+C l'interrompt de force.</div>
</div>

<div class="theory-block"><h3>🛑 4.4 — break et continue : reprendre le contrôle depuis l'intérieur</h3><p>Deux instructions permettent de dévier du déroulement normal d'une boucle (for comme while), depuis l'intérieur du bloc.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="kw">for</span> <span class="varc">n</span> <span class="kw">in</span> <span class="fn">range</span>(<span class="num">1</span>, <span class="num">10</span>):
    <span class="kw">if</span> <span class="varc">n</span> == <span class="num">5</span>:
        <span class="kw">break</span>       <span class="cmt"># arrete TOTALEMENT la boucle des n == 5</span>
    <span class="kw">if</span> <span class="varc">n</span> % <span class="num">2</span> == <span class="num">0</span>:
        <span class="kw">continue</span>    <span class="cmt"># saute directement au tour suivant, sans afficher</span>
    <span class="fn">print</span>(<span class="varc">n</span>)
<span class="cmt"># affiche : 1, 3</span></div></div>
<p><code>break</code> quitte immédiatement la boucle entière, comme si elle n'existait plus — utile pour arrêter une recherche dès qu'on a trouvé ce qu'on cherchait. <code>continue</code> est plus discret : il n'arrête que le tour <b>en cours</b> et passe directement au suivant, sans exécuter le reste du bloc pour cette itération.</p></div>

<div class="theory-block"><h3>🧩 4.5 — Assembler : compter des tours et accumuler un total</h3><p>L'exercice du jour combine les deux types de boucles côte à côte : un <code>for</code> pour afficher cinq tours numérotés, puis un <code>while</code> pour additionner les nombres de 1 à 5 dans une variable accumulateur. Ce schéma — "accumulateur initialisé à 0, puis mis à jour à chaque tour" — est un des patterns les plus utilisés en programmation.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="varc">total</span> = <span class="num">0</span>          <span class="cmt"># l'accumulateur part toujours d'une valeur neutre</span>
<span class="varc">compteur</span> = <span class="num">1</span>
<span class="kw">while</span> <span class="varc">compteur</span> &lt;= <span class="num">5</span>:
    <span class="varc">total</span> = <span class="varc">total</span> + <span class="varc">compteur</span>
    <span class="varc">compteur</span> = <span class="varc">compteur</span> + <span class="num">1</span>
<span class="fn">print</span>(<span class="str">"Somme de 1 a 5 :"</span>, <span class="varc">total</span>)</div></div>
<p>À chaque tour, <code>total</code> reçoit sa propre valeur précédente plus <code>compteur</code> — c'est ce qui permet d'accumuler un résultat au fil des itérations, plutôt que de le recalculer depuis zéro à chaque fois.</p></div>

<div class="tip-box"><strong>🔑 À retenir avant l'exercice</strong>
<ul style="margin:8px 0 0 18px;line-height:1.7">
<li><code>for</code> répète pour chaque élément d'une séquence ; <code>range(a, b)</code> va de a à b-1, la fin est exclue.</li>
<li><code>while</code> répète tant que sa condition reste <code>True</code> — pense toujours à mettre à jour la variable testée.</li>
<li><code>break</code> arrête complètement la boucle ; <code>continue</code> passe directement au tour suivant.</li>
<li>Un accumulateur (<code>total = 0</code> puis <code>total = total + x</code>) permet de cumuler un résultat au fil des tours.</li>
</ul></div>

</div></div>`,
 starter:`# Jour 4 : boucles
for i in range(1, 6):
    print(f"Tour numero {i}")

total = 0
compteur = 1
while compteur <= 5:
    total = total + compteur
    compteur = compteur + 1

print("Somme de 1 a 5 :", total)`,
 quiz:[
  {q:"Que génère range(5) ?", opts:["1 à 5","0 à 4","0 à 5","1 à 4"], ans:1},
  {q:"Quelle instruction arrête complètement une boucle ?", opts:["continue","pass","break","stop"], ans:2},
  {q:"Une boucle while s'arrête quand…", opts:["le compteur atteint 10","sa condition devient fausse","on appelle stop()","après 100 tours"], ans:1}
 ]},
{d:5, title:"Texte & listes", sub:"chaînes de caractères et listes", level:"easy",
 theory:`<div class="cell"><div class="cell-head"><span class="cell-tag">In [5]</span> Théorie — Chapitre 5</div><div class="cell-body">

<div class="theory-block"><h3>🔤 5.1 — Une chaîne de caractères est une séquence indexée</h3><p>Jusqu'ici tu as utilisé les chaînes (<code>str</code>) comme des blocs de texte indivisibles. En réalité, Python les traite comme des <b>séquences</b> : une suite ordonnée de caractères, chacun accessible individuellement via sa <b>position</b>, appelée index. Comme dans beaucoup de langages de programmation, la numérotation commence à <b>0</b>, pas à 1.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="varc">langage</span> = <span class="str">"python"</span>
<span class="fn">print</span>(<span class="varc">langage</span>[<span class="num">0</span>])   <span class="cmt"># "p" -&gt; premier caractere, index 0</span>
<span class="fn">print</span>(<span class="varc">langage</span>[<span class="num">5</span>])   <span class="cmt"># "n" -&gt; dernier caractere (6 lettres, index 0 a 5)</span>
<span class="fn">print</span>(<span class="varc">langage</span>[-<span class="num">1</span>])  <span class="cmt"># "n" -&gt; l'index -1 designe toujours le DERNIER element</span></div></div>
<p>Les index négatifs comptent depuis la fin : <code>-1</code> est le dernier caractère, <code>-2</code> l'avant-dernier, et ainsi de suite — pratique pour accéder à la fin d'un texte sans devoir d'abord calculer sa longueur.</p>
<div class="tip"><b>Piège fréquent —</b> pour un texte de 6 lettres, le dernier index valide est 5, pas 6. Écrire <code>langage[6]</code> lève une <code>IndexError: string index out of range</code>.</div>
</div>

<div class="theory-block"><h3>🔠 5.2 — len() et les méthodes de transformation .upper() / .lower()</h3><p>La fonction intégrée <code>len()</code> renvoie le nombre de caractères d'une chaîne (espaces compris). Deux méthodes très utilisées permettent de changer la casse d'un texte sans le modifier sur place : <code>.upper()</code> renvoie une version tout en majuscules, <code>.lower()</code> une version tout en minuscules.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="varc">langage</span> = <span class="str">"python"</span>
<span class="fn">print</span>(<span class="varc">langage</span>.<span class="fn">upper</span>())   <span class="cmt"># "PYTHON"</span>
<span class="fn">print</span>(<span class="fn">len</span>(<span class="varc">langage</span>))     <span class="cmt"># 6</span>
<span class="fn">print</span>(<span class="varc">langage</span>)            <span class="cmt"># "python" -&gt; inchangee !</span></div></div>
<p>Remarque le point important : <code>.upper()</code> ne modifie pas la variable <code>langage</code>, elle <b>renvoie une nouvelle chaîne</b>. Les chaînes de caractères sont <b>immuables</b> en Python — une fois créées, elles ne peuvent jamais être modifiées en place. Si tu veux garder le résultat, il faut l'assigner explicitement : <code>langage = langage.upper()</code>.</p>
<div class="tip"><b>Astuce —</b> ce comportement (une méthode qui renvoie un résultat sans toucher l'original) revient souvent : c'est le cas de <code>.upper()</code>, <code>.lower()</code>, et plus tard de <code>sorted()</code>. Retiens le réflexe : si tu veux garder le résultat, il faut le stocker dans une variable.</div>
</div>

<div class="theory-block"><h3>📋 5.3 — Les listes [ ] : stocker plusieurs valeurs, dans l'ordre</h3><p>Une variable ne stocke qu'une seule valeur à la fois. Pour regrouper plusieurs valeurs sous un même nom — une liste de fruits, une série de notes, des prénoms d'une classe — Python fournit le type <code>list</code>, délimité par des crochets <code>[ ]</code> et des valeurs séparées par des virgules.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="varc">fruits</span> = [<span class="str">"mangue"</span>, <span class="str">"banane"</span>, <span class="str">"ananas"</span>]
<span class="fn">print</span>(<span class="varc">fruits</span>[<span class="num">0</span>])   <span class="cmt"># "mangue" -&gt; meme logique d'index qu'une chaine</span>
<span class="fn">print</span>(<span class="fn">len</span>(<span class="varc">fruits</span>))  <span class="cmt"># 3 -&gt; nombre d'elements</span></div></div>
<p>L'indexation fonctionne exactement comme pour les chaînes de caractères vues en 5.1 : premier élément à l'index 0, index négatifs qui comptent depuis la fin. Contrairement aux chaînes, une liste est <b>mutable</b> — tu peux changer, ajouter ou retirer des éléments après sa création, sans devoir recréer toute la liste.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="varc">fruits</span>[<span class="num">0</span>] = <span class="str">"mangue bien murie"</span>  <span class="cmt"># remplacer un element existant</span>
<span class="fn">print</span>(<span class="varc">fruits</span>)</div></div>
</div>

<div class="theory-block"><h3>➕ 5.4 — .append() : agrandir une liste dynamiquement</h3><p>La méthode <code>.append()</code> ajoute un élément unique à la <b>fin</b> de la liste, en modifiant celle-ci directement (contrairement à <code>.upper()</code> sur une chaîne, ici pas besoin de réassigner le résultat).</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="varc">fruits</span> = [<span class="str">"mangue"</span>, <span class="str">"banane"</span>]
<span class="varc">fruits</span>.<span class="fn">append</span>(<span class="str">"papaye"</span>)
<span class="fn">print</span>(<span class="varc">fruits</span>)   <span class="cmt"># ["mangue", "banane", "papaye"]</span>
<span class="fn">print</span>(<span class="fn">len</span>(<span class="varc">fruits</span>))  <span class="cmt"># 3 -&gt; a jour automatiquement</span></div></div>
<p>Une liste peut aussi être parcourue directement avec <code>for</code>, sans passer par les index — tu retrouveras ce pattern dès le Jour 7 pour additionner ou trier des valeurs.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="kw">for</span> <span class="varc">fruit</span> <span class="kw">in</span> <span class="varc">fruits</span>:
    <span class="fn">print</span>(<span class="varc">fruit</span>)</div></div>
<div class="tip"><b>Piège fréquent —</b> <code>.append()</code> ajoute toujours <b>un seul</b> élément, même si tu lui passes une autre liste — elle sera ajoutée comme un seul bloc imbriqué, pas fusionnée élément par élément. Ce n'est pas le sujet d'aujourd'hui, mais garde-le en tête pour éviter la surprise plus tard.</div>
</div>

<div class="theory-block"><h3>🧩 5.5 — Assembler : combiner texte, index et liste dans une f-string</h3><p>L'exercice du jour te fait mélanger toutes ces notions : afficher une chaîne transformée, mesurer sa longueur, indexer son premier caractère, puis construire une liste, l'agrandir avec <code>.append()</code>, et enfin injecter deux informations calculées sur la liste (sa taille et son premier élément) dans une seule f-string.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="varc">fruits</span> = [<span class="str">"mangue"</span>, <span class="str">"banane"</span>, <span class="str">"ananas"</span>]
<span class="varc">fruits</span>.<span class="fn">append</span>(<span class="str">"papaye"</span>)
<span class="fn">print</span>(<span class="str">f"J'ai {len(fruits)} fruits, dont {fruits[0]}"</span>)</div></div>
<p>Une f-string peut contenir n'importe quelle expression Python entre accolades — pas seulement un nom de variable simple, mais aussi un appel de fonction comme <code>len(fruits)</code> ou un accès indexé comme <code>fruits[0]</code>. C'est ce qui la rend tellement plus pratique que la concaténation avec <code>+</code> vue au Jour 1.</p></div>

<div class="tip-box"><strong>🔑 À retenir avant l'exercice</strong>
<ul style="margin:8px 0 0 18px;line-height:1.7">
<li>Chaînes et listes s'indexent pareil : premier élément à l'index 0, -1 pour le dernier.</li>
<li><code>len()</code> donne la taille ; <code>.upper()</code>/<code>.lower()</code> renvoient une nouvelle chaîne sans modifier l'originale.</li>
<li>Une liste <code>[ ]</code> est mutable : <code>.append()</code> y ajoute un élément à la fin, directement.</li>
<li><code>for element in ma_liste:</code> parcourt les valeurs sans passer par les index.</li>
</ul></div>

</div></div>`,
 starter:`# Jour 5 : chaines et listes
langage = "python"
print(langage.upper())
print(len(langage))
print(langage[0])

fruits = ["mangue", "banane", "ananas"]
fruits.append("papaye")
print(fruits)
print(f"J'ai {len(fruits)} fruits, dont {fruits[0]}")`,
 quiz:[
  {q:"Quel index a le premier élément d'une liste ?", opts:["1","0","-1","Ça dépend"], ans:1},
  {q:"Quelle méthode ajoute un élément à la fin d'une liste ?", opts:[".add()",".push()",".append()",".insert()"], ans:2},
  {q:"Que retourne len(\"Python\") ?", opts:["5","6","7","\"Python\""], ans:1}
 ]}
]},
{ week:"Semaine 2 — Structurer son code", days:[
{d:6, title:"Fonctions", sub:"def, paramètres et return", level:"med",
 theory:`<div class="cell"><div class="cell-head"><span class="cell-tag">In [6]</span> Théorie — Chapitre 6</div><div class="cell-body">

<div class="theory-block"><h3>🧩 6.1 — Pourquoi découper son code en fonctions</h3><p>Jusqu'ici, ton code s'exécutait ligne par ligne, du début à la fin. Le problème : dès que tu veux répéter une même logique à plusieurs endroits (calculer une moyenne, valider une saisie, formater un message), tu te retrouves à copier-coller les mêmes lignes encore et encore. Une <b>fonction</b> résout ça : c'est un bloc de code que tu écris une seule fois, que tu nommes, et que tu peux ensuite <b>appeler</b> autant de fois que nécessaire, avec des données différentes à chaque fois. Pense à une fonction comme une recette de cuisine : tu l'écris une fois sur une fiche (la définition), et ensuite tu la suis autant de fois que tu veux, avec des ingrédients différents (les paramètres) — le résultat, c'est le plat que tu obtiens (la valeur renvoyée).</p>
<p>Ce découpage a trois bénéfices concrets : ton code devient plus <b>lisible</b> (un nom de fonction bien choisi documente ce que fait le bloc), plus <b>facile à corriger</b> (un bug dans le calcul ? tu le corriges à un seul endroit), et plus facile à <b>tester</b> isolément.</p></div>

<div class="theory-block"><h3>⚙️ 6.2 — Anatomie d'une fonction : def, paramètres, return</h3><p>Une fonction se construit avec trois ingrédients : le mot-clé <code>def</code> qui annonce "je définis une fonction", un nom suivi de parenthèses contenant ses <b>paramètres</b> (les informations dont elle a besoin pour travailler), et un bloc indenté qui contient les instructions. Le mot-clé <code>return</code> renvoie un résultat à l'endroit où la fonction a été appelée.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="kw">def</span> <span class="fn">carre</span>(<span class="varc">x</span>):
    <span class="kw">return</span> <span class="varc">x</span> * <span class="varc">x</span>

<span class="varc">resultat</span> = <span class="fn">carre</span>(<span class="num">5</span>)
<span class="fn">print</span>(<span class="varc">resultat</span>)  <span class="cmt"># 25</span></div></div>
<p>Ici, <code>x</code> est le paramètre : une variable locale qui n'existe qu'à l'intérieur de la fonction, et qui prend la valeur <code>5</code> au moment de l'appel <code>carre(5)</code>. On dit que <code>5</code> est l'<b>argument</b> passé au paramètre <code>x</code> — "paramètre" désigne la place réservée dans la définition, "argument" désigne la valeur réelle envoyée lors de l'appel. La distinction est subtile mais utile pour comprendre la documentation Python.</p></div>

<div class="theory-block"><h3>🎯 6.3 — Plusieurs paramètres, dans l'ordre</h3><p>Une fonction peut prendre autant de paramètres que nécessaire, séparés par des virgules. Par défaut, Python les associe <b>dans l'ordre</b> où tu les écris à l'appel : le premier argument va au premier paramètre, le deuxième au deuxième, etc.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="kw">def</span> <span class="fn">presenter</span>(<span class="varc">nom</span>, <span class="varc">age</span>, <span class="varc">ville</span>):
    <span class="kw">return</span> <span class="str">f"{nom}, {age} ans, habite a {ville}"</span>

<span class="fn">print</span>(<span class="fn">presenter</span>(<span class="str">"Awa"</span>, <span class="num">22</span>, <span class="str">"Dakar"</span>))</div></div>
<div class="tip"><b>Piège fréquent —</b> inverser l'ordre des arguments à l'appel (par exemple presenter(22, "Awa", "Dakar")) ne provoque aucune erreur immédiate — Python assigne quand même les valeurs aux paramètres dans l'ordre, mais le résultat sera absurde. Toujours vérifier l'ordre attendu par la fonction.</div>
</div>

<div class="theory-block"><h3>🎁 6.4 — Valeurs par défaut : rendre un paramètre optionnel</h3><p>On peut donner à un paramètre une <b>valeur par défaut</b>, utilisée automatiquement si l'appelant ne fournit rien pour ce paramètre. Ça rend la fonction plus souple : elle marche avec un minimum d'informations, mais reste personnalisable.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="kw">def</span> <span class="fn">saluer</span>(<span class="varc">nom</span>, <span class="varc">langage</span>=<span class="str">"Python"</span>):
    <span class="varc">message</span> = <span class="str">f"Salut {nom}, pret pour du {langage} ?"</span>
    <span class="kw">return</span> <span class="varc">message</span>

<span class="fn">print</span>(<span class="fn">saluer</span>(<span class="str">"Nerija"</span>))              <span class="cmt"># utilise "Python" par defaut</span>
<span class="fn">print</span>(<span class="fn">saluer</span>(<span class="str">"Awa"</span>, <span class="str">"JavaScript"</span>))  <span class="cmt"># remplace la valeur par defaut</span></div></div>
<p>Dans le premier appel, <code>langage</code> n'a pas été fourni : Python utilise donc automatiquement <code>"Python"</code>. Dans le second, l'argument <code>"JavaScript"</code> écrase la valeur par défaut. C'est exactement ce mécanisme qui est utilisé dans l'exercice de ce jour.</p>
<div class="tip"><b>Règle stricte —</b> un paramètre avec valeur par défaut doit toujours être placé <b>après</b> les paramètres sans valeur par défaut dans la définition. def f(a=1, b): est une erreur de syntaxe ; def f(a, b=1): est correct.</div>
</div>

<div class="theory-block"><h3>↩️ 6.5 — return n'est pas print : la différence qui piège tout le monde</h3><p><code>print()</code> affiche une valeur à l'écran, pour que <b>toi</b>, humain, la voies — mais ça ne donne rien d'exploitable au reste du programme. <code>return</code> renvoie une valeur à l'endroit où la fonction a été appelée, pour que le <b>programme</b> puisse la réutiliser (la stocker dans une variable, la passer à une autre fonction, l'utiliser dans un calcul). Confondre les deux est l'une des erreurs les plus courantes en début d'apprentissage.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="kw">def</span> <span class="fn">carre_v1</span>(<span class="varc">x</span>):
    <span class="fn">print</span>(<span class="varc">x</span> * <span class="varc">x</span>)  <span class="cmt"># affiche, ne renvoie rien</span>

<span class="kw">def</span> <span class="fn">carre_v2</span>(<span class="varc">x</span>):
    <span class="kw">return</span> <span class="varc">x</span> * <span class="varc">x</span>  <span class="cmt"># renvoie une valeur reelle</span>

<span class="varc">a</span> = <span class="fn">carre_v1</span>(<span class="num">5</span>)  <span class="cmt"># affiche 25, mais a vaut None</span>
<span class="varc">b</span> = <span class="fn">carre_v2</span>(<span class="num">5</span>)  <span class="cmt"># n'affiche rien, mais b vaut 25</span>
<span class="fn">print</span>(<span class="varc">a</span>, <span class="varc">b</span>)  <span class="cmt"># None 25</span></div></div>
<p>C'est justement parce qu'une fonction <b>sans</b> <code>return</code> ne renvoie rien d'exploitable que Python lui attribue automatiquement la valeur spéciale <code>None</code> — le "rien" officiel de Python. Toute fonction dont l'exécution atteint sa dernière ligne sans croiser de <code>return</code> renvoie <code>None</code> par défaut, même si elle contient des <code>print()</code> en pagaille.</p></div>

<div class="theory-block"><h3>🔒 6.6 — Portée locale : ce qui se passe dans la fonction reste dans la fonction</h3><p>Une variable créée à l'intérieur d'une fonction (comme <code>message</code> dans <code>saluer()</code>) n'existe que le temps de l'exécution de cette fonction — on dit qu'elle a une <b>portée locale</b>. Une fois la fonction terminée, cette variable disparaît ; elle est invisible et inaccessible depuis l'extérieur. C'est une bonne nouvelle : ça veut dire que tu peux réutiliser librement des noms de variables simples (<code>x</code>, <code>total</code>, <code>resultat</code>) dans plusieurs fonctions différentes sans qu'elles n'entrent en conflit les unes avec les autres.</p></div>

<div class="tip-box"><strong>🔑 À retenir avant l'exercice</strong>
<ul style="margin:8px 0 0 18px;line-height:1.7">
<li><code>def nom(parametres):</code> définit une fonction ; <code>return</code> lui fait renvoyer un résultat.</li>
<li>Sans <code>return</code>, une fonction renvoie automatiquement <code>None</code>.</li>
<li>Une valeur par défaut (def f(x=10):) rend un paramètre optionnel — elle doit être placée après les paramètres obligatoires.</li>
<li><code>return</code> donne une valeur réutilisable au programme ; <code>print()</code> l'affiche seulement à l'écran.</li>
<li>Les variables créées dans une fonction sont locales : elles n'existent que pendant son exécution.</li>
</ul></div>

</div></div>`,
 starter:`# Jour 6 : fonctions
def saluer(nom, langage="Python"):
    message = f"Salut {nom}, pret pour du {langage} ?"
    return message

def carre(x):
    return x * x

print(saluer("Nerija"))
print(saluer("Awa", "JavaScript"))
print(carre(7))`,
 quiz:[
  {q:"Quel mot-clé définit une fonction ?", opts:["function","def","func","fn"], ans:1},
  {q:"Que renvoie une fonction sans return ?", opts:["0","\"\"","None","une erreur"], ans:2},
  {q:"À quoi sert un paramètre par défaut ?", opts:["Rendre le paramètre obligatoire","Donner une valeur si rien n'est fourni","Bloquer la fonction","Rien du tout"], ans:1}
 ]},
{d:7, title:"Listes avancées", sub:"parcours, tri et agrégations", level:"med",
 theory:`<div class="cell"><div class="cell-head"><span class="cell-tag">In [7]</span> Théorie — Chapitre 7</div><div class="cell-body">

<div class="theory-block"><h3>🔁 7.1 — Parcourir une liste : le réflexe de base</h3><p>Tu as déjà croisé <code>for element in ma_liste:</code> — parcourir une liste élément par élément est le point de départ de presque tout traitement de données en Python. Chaque tour de boucle, la variable (ici <code>element</code>) prend la valeur de l'élément courant, dans l'ordre où il apparaît dans la liste. C'est cette brique de base qui permet de construire des calculs plus riches : additionner tous les éléments, compter ceux qui remplissent une condition, chercher le plus grand, etc.</p></div>

<div class="theory-block"><h3>➕ 7.2 — Accumuler un résultat : le motif "total + compteur"</h3><p>Pour calculer une somme à la main, on utilise un motif très classique : une variable "accumulateur" initialisée à 0 <b>avant</b> la boucle, qu'on incrémente à chaque tour.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="varc">notes</span> = [<span class="num">12</span>, <span class="num">18</span>, <span class="num">9</span>, <span class="num">15</span>]
<span class="varc">total</span> = <span class="num">0</span>
<span class="kw">for</span> <span class="varc">note</span> <span class="kw">in</span> <span class="varc">notes</span>:
    <span class="varc">total</span> = <span class="varc">total</span> + <span class="varc">note</span>

<span class="varc">moyenne</span> = <span class="varc">total</span> / <span class="fn">len</span>(<span class="varc">notes</span>)
<span class="fn">print</span>(<span class="fn">round</span>(<span class="varc">moyenne</span>, <span class="num">2</span>))</div></div>
<p>Ce motif revient partout : <code>total</code> commence à zéro, puis grossit d'un cran à chaque tour de boucle. À la fin, il contient la somme de tous les éléments. Diviser cette somme par <code>len(notes)</code> (le nombre d'éléments) donne la moyenne. La fonction native <code>round(valeur, nb_decimales)</code> arrondit proprement le résultat pour l'affichage — sans elle, une division donne souvent un nombre avec beaucoup trop de décimales.</p></div>

<div class="theory-block"><h3>⚡ 7.3 — sum() : la fonction qui t'évite d'écrire la boucle</h3><p>Additionner une liste est tellement fréquent que Python fournit une fonction native toute prête : <code>sum()</code>. Elle fait exactement ce que fait la boucle manuelle ci-dessus, en une seule ligne.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="varc">notes</span> = [<span class="num">12</span>, <span class="num">18</span>, <span class="num">9</span>, <span class="num">15</span>]
<span class="varc">total</span> = <span class="fn">sum</span>(<span class="varc">notes</span>)     <span class="cmt"># equivalent a la boucle du dessus</span>
<span class="varc">moyenne</span> = <span class="varc">total</span> / <span class="fn">len</span>(<span class="varc">notes</span>)
<span class="fn">print</span>(<span class="varc">total</span>, <span class="varc">moyenne</span>)</div></div>
<p>Écrire la boucle à la main (comme au 7.2) reste une compétence essentielle — c'est ce qui te permet de comprendre <b>ce qui se passe réellement</b>, et c'est indispensable dès que le calcul est plus complexe qu'une simple somme (par exemple si tu veux ignorer certaines valeurs). Mais une fois le mécanisme compris, <code>sum()</code> te fait gagner du temps et rend le code plus lisible pour les cas simples.</p></div>

<div class="theory-block"><h3>🏆 7.4 — max() et min() : trouver les extrêmes sans boucle</h3><p>Autres fonctions natives très utiles : <code>max()</code> renvoie le plus grand élément d'une liste, <code>min()</code> le plus petit. Comme <code>sum()</code>, elles t'évitent d'écrire une boucle de comparaison manuelle.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="varc">notes</span> = [<span class="num">12</span>, <span class="num">18</span>, <span class="num">9</span>, <span class="num">15</span>, <span class="num">20</span>, <span class="num">7</span>]
<span class="fn">print</span>(<span class="str">"Meilleure note :"</span>, <span class="fn">max</span>(<span class="varc">notes</span>))  <span class="cmt"># 20</span>
<span class="fn">print</span>(<span class="str">"Pire note :"</span>, <span class="fn">min</span>(<span class="varc">notes</span>))       <span class="cmt"># 7</span></div></div>
<div class="tip"><b>Piège —</b> <code>max()</code> et <code>min()</code> renvoient l'<b>élément</b> lui-même, pas sa position dans la liste. Si tu as besoin de savoir à quel index se trouve le maximum, il faudra combiner avec .index() : notes.index(max(notes)).</div>
</div>

<div class="theory-block"><h3>📊 7.5 — sorted() : trier sans jamais toucher l'originale</h3><p><code>sorted(ma_liste)</code> renvoie une <b>toute nouvelle liste</b>, triée par ordre croissant, sans modifier <code>ma_liste</code> d'origine. C'est un point important à bien comprendre : la liste que tu passes en argument reste intacte après l'appel.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="varc">notes</span> = [<span class="num">12</span>, <span class="num">18</span>, <span class="num">9</span>, <span class="num">15</span>, <span class="num">20</span>, <span class="num">7</span>]
<span class="varc">notes_triees</span> = <span class="fn">sorted</span>(<span class="varc">notes</span>)
<span class="fn">print</span>(<span class="str">"Notes triees :"</span>, <span class="varc">notes_triees</span>)  <span class="cmt"># [7, 9, 12, 15, 18, 20]</span>
<span class="fn">print</span>(<span class="str">"Notes d'origine :"</span>, <span class="varc">notes</span>)          <span class="cmt"># inchangee : [12, 18, 9, 15, 20, 7]</span>

<span class="cmt"># pour trier du plus grand au plus petit :</span>
<span class="fn">print</span>(<span class="fn">sorted</span>(<span class="varc">notes</span>, <span class="varc">reverse</span>=<span class="kw">True</span>))</div></div>
<p>C'est justement parce que <code>sorted()</code> ne modifie jamais l'originale que tu dois récupérer son résultat dans une nouvelle variable (<code>notes_triees</code> ci-dessus) si tu veux le réutiliser — sinon le tri est calculé puis perdu immédiatement.</p></div>

<div class="tip-box"><strong>🔑 À retenir avant l'exercice</strong>
<ul style="margin:8px 0 0 18px;line-height:1.7">
<li>Le motif total = 0 puis total = total + element dans une boucle calcule une somme à la main.</li>
<li><code>sum(liste)</code>, <code>max(liste)</code>, <code>min(liste)</code> font ces calculs en une seule ligne.</li>
<li><code>sorted(liste)</code> renvoie une nouvelle liste triée — l'originale n'est jamais modifiée.</li>
<li><code>round(valeur, n)</code> arrondit un résultat à n décimales, pratique pour une moyenne.</li>
</ul></div>

</div></div>`,
 starter:`# Jour 7 : parcourir et trier une liste
notes = [12, 18, 9, 15, 20, 7]

total = 0
for note in notes:
    total = total + note

moyenne = total / len(notes)
print(f"Moyenne : {round(moyenne, 2)}")

notes_triees = sorted(notes)
print("Notes triees :", notes_triees)
print("Meilleure note :", max(notes))`,
 quiz:[
  {q:"sorted() sur une liste…", opts:["modifie la liste d'origine","renvoie une nouvelle liste triée","trie seulement les nombres","supprime les doublons"], ans:1},
  {q:"Que fait max() sur une liste ?", opts:["Renvoie l'index du plus grand","Renvoie le plus grand élément","Trie la liste","Compte les éléments"], ans:1},
  {q:"for x in ma_liste: parcourt…", opts:["les index","les valeurs","les deux","rien sans range()"], ans:1}
 ]},
{d:8, title:"Dictionnaires", sub:"paires clé-valeur", level:"med",
 theory:`<div class="cell"><div class="cell-head"><span class="cell-tag">In [8]</span> Théorie — Chapitre 8</div><div class="cell-body">

<div class="theory-block"><h3>🗂️ 8.1 — Pourquoi un nouveau type de données</h3><p>Une liste range des valeurs les unes après les autres, accessibles par leur <b>position</b> (l'index 0, 1, 2...). C'est parfait pour une collection homogène — une liste de notes, de prénoms. Mais pour représenter une <b>fiche</b> — un étudiant avec un nom, un âge, une ville — retenir que "l'âge est à l'index 1" est fragile et illisible. Le <b>dictionnaire</b> résout ce problème : au lieu d'un index numérique, chaque valeur est associée à une <b>clé</b> explicite, un peu comme les entrées d'un vrai dictionnaire papier où chaque définition est rangée sous un mot précis plutôt que sous un numéro de page.</p></div>

<div class="theory-block"><h3>🔑 8.2 — Créer un dictionnaire : des paires clé-valeur</h3><p>Un dictionnaire s'écrit entre accolades <code>{ }</code>, avec des paires <code>cle: valeur</code> séparées par des virgules. Les clés sont le plus souvent des chaînes de caractères, les valeurs peuvent être n'importe quel type — texte, nombre, booléen, voire une autre liste ou un autre dictionnaire.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="varc">etudiant</span> = {
    <span class="str">"nom"</span>: <span class="str">"Nerija"</span>,
    <span class="str">"age"</span>: <span class="num">27</span>,
    <span class="str">"ville"</span>: <span class="str">"Abidjan"</span>
}</div></div>
<p>Chaque clé doit être unique à l'intérieur d'un même dictionnaire — si tu écris deux fois la même clé, seule la dernière valeur est conservée, la première est silencieusement écrasée.</p></div>

<div class="theory-block"><h3>📖 8.3 — Accéder à une valeur par sa clé</h3><p>On récupère une valeur en indiquant sa clé entre crochets — la même syntaxe que pour une liste, mais avec une clé au lieu d'un index numérique.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="fn">print</span>(<span class="varc">etudiant</span>[<span class="str">"nom"</span>])                                  <span class="cmt"># "Nerija"</span>
<span class="fn">print</span>(<span class="str">f"{etudiant['nom']} a {etudiant['age']} ans"</span>)    <span class="cmt"># Nerija a 27 ans</span></div></div>
<p>Remarque la seconde ligne : à l'intérieur d'une f-string déjà délimitée par des guillemets doubles, on utilise des guillemets <b>simples</b> pour la clé du dictionnaire — etudiant['nom']. Mélanger les deux types de guillemets de cette façon évite à Python de confondre la fin de la chaîne du dictionnaire avec la fin de la f-string elle-même.</p>
<div class="tip"><b>Piège —</b> accéder à une clé qui n'existe pas (etudiant["telephone"] si cette clé n'a jamais été définie) provoque une erreur <code>KeyError</code> qui arrête le programme. Tu apprendras au Jour 9 comment se protéger de ce genre d'erreur avec try/except.</div>
</div>

<div class="theory-block"><h3>➕ 8.4 — Ajouter ou modifier une clé</h3><p>On ajoute une nouvelle clé — ou on modifie la valeur d'une clé existante — exactement de la même façon : <code>dictionnaire["cle"] = nouvelle_valeur</code>. Python regarde si la clé existe déjà : si oui, il remplace sa valeur ; si non, il crée la paire clé-valeur à la volée. Il n'y a pas besoin de "déclarer" une clé à l'avance comme pour une variable.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="varc">etudiant</span>[<span class="str">"niveau"</span>] = <span class="str">"Debutant"</span>   <span class="cmt"># "niveau" n'existait pas : elle est creee</span>
<span class="varc">etudiant</span>[<span class="str">"age"</span>] = <span class="num">28</span>            <span class="cmt"># "age" existait deja : sa valeur est remplacee</span>
<span class="fn">print</span>(<span class="varc">etudiant</span>)</div></div>
</div>

<div class="theory-block"><h3>🧭 8.5 — Pour aller plus loin : parcourir un dictionnaire</h3><p>Un dictionnaire se parcourt lui aussi avec <code>for</code>, mais il propose trois façons de le faire selon ce dont tu as besoin : <code>.keys()</code> pour obtenir uniquement les clés, <code>.values()</code> pour obtenir uniquement les valeurs, et <code>.items()</code> pour obtenir les deux en même temps, sous forme de paires.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="kw">for</span> <span class="varc">cle</span>, <span class="varc">valeur</span> <span class="kw">in</span> <span class="varc">etudiant</span>.items():
    <span class="fn">print</span>(<span class="varc">cle</span>, <span class="str">"->"</span>, <span class="varc">valeur</span>)</div></div>
<p>Tu n'en as pas besoin pour l'exercice de ce jour, mais c'est un outil que tu croiseras très vite dès que tu manipuleras plusieurs dictionnaires à la suite.</p></div>

<div class="tip-box"><strong>🔑 À retenir avant l'exercice</strong>
<ul style="margin:8px 0 0 18px;line-height:1.7">
<li>Un dictionnaire { } stocke des paires clé-valeur, accessibles par clé et non par position.</li>
<li>On lit une valeur avec <code>d["cle"]</code>, exactement comme on l'écrit.</li>
<li><code>d["nouvelle_cle"] = valeur</code> crée la clé si elle n'existe pas, ou remplace sa valeur si elle existe déjà.</li>
<li>Accéder à une clé absente provoque une erreur KeyError.</li>
</ul></div>

</div></div>`,
 starter:`# Jour 8 : dictionnaire
etudiant = {"nom": "Nerija", "age": 27, "ville": "Abidjan"}

print(etudiant["nom"])
print(f"{etudiant['nom']} a {etudiant['age']} ans")
etudiant["niveau"] = "Debutant"
print(etudiant)`,
 quiz:[
  {q:"Comment accéder à la valeur associée à \"nom\" dans un dictionnaire d ?", opts:["d.nom","d[\"nom\"]","d(nom)","d->nom"], ans:1},
  {q:"Un dictionnaire stocke des données sous forme de…", opts:["liste ordonnée","paires clé-valeur","texte brut","nombres uniquement"], ans:1},
  {q:"Peut-on ajouter une nouvelle clé après la création ?", opts:["Non jamais","Oui avec d[\"cle\"]=valeur","Seulement à la création","Oui mais uniquement des nombres"], ans:1}
 ]},
{d:9, title:"Gérer les erreurs", sub:"try / except", level:"med",
 theory:`<div class="cell"><div class="cell-head"><span class="cell-tag">In [9]</span> Théorie — Chapitre 9</div><div class="cell-body">

<div class="theory-block"><h3>💥 9.1 — Un programme robuste ne plante pas au premier imprévu</h3><p>Jusqu'ici, si une ligne de ton code provoquait une erreur — une conversion impossible, une division par zéro, une clé absente — le programme entier s'arrêtait brutalement, en affichant un message d'erreur technique (une "exception") à l'utilisateur. C'est acceptable pendant l'apprentissage, mais inacceptable dans un vrai programme : si tu construis un formulaire, une appli, un jeu, tu ne veux pas qu'une seule saisie incorrecte fasse planter tout le reste. Python fournit un mécanisme pour <b>anticiper</b> ces erreurs et réagir proprement au lieu de crasher : le bloc <code>try</code> / <code>except</code>.</p></div>

<div class="theory-block"><h3>🧱 9.2 — Anatomie de try / except</h3><p>Le principe : tu places dans le bloc <code>try</code> le code "à risque" (celui qui pourrait échouer), et dans le bloc <code>except</code> le code de secours à exécuter <b>si et seulement si</b> une erreur survient pendant le try.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="kw">try</span>:
    <span class="varc">n</span> = <span class="fn">int</span>(<span class="str">"abc"</span>)   <span class="cmt"># "abc" n'est pas convertible en nombre</span>
<span class="kw">except</span>:
    <span class="fn">print</span>(<span class="str">"Conversion impossible"</span>)</div></div>
<p>Sans ce garde-fou, la ligne int("abc") aurait immédiatement arrêté le programme avec une erreur <code>ValueError</code>. Avec try/except, l'erreur est <b>interceptée</b> : Python quitte immédiatement le bloc try dès qu'une erreur survient, saute directement au bloc except, l'exécute, puis continue normalement le reste du programme <b>après</b> le bloc entier — comme si de rien n'était.</p></div>

<div class="theory-block"><h3>✅ 9.3 — Et si le try se passe bien ?</h3><p>Si aucune erreur ne survient pendant le try, le bloc except est tout simplement <b>ignoré</b> — il ne s'exécute jamais. Le programme continue son chemin juste après le bloc try/except, sans jamais visiter le code de secours. Le bloc except n'est donc pas une alternative systématique au try : c'est un filet de sécurité qui ne se déclenche que si quelque chose tourne mal.</p></div>

<div class="theory-block"><h3>🛠️ 9.4 — Cas pratique : sécuriser une conversion dans une fonction</h3><p>Le cas d'usage le plus courant en début d'apprentissage : convertir un texte saisi par l'utilisateur en nombre. Toute chaîne ne représentant pas un nombre valide (une lettre, un mot, une chaîne vide) fait planter int() avec une ValueError. On encapsule donc cette conversion dans une fonction protégée par try/except.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="kw">def</span> <span class="fn">convertir</span>(<span class="varc">texte</span>):
    <span class="kw">try</span>:
        <span class="varc">nombre</span> = <span class="fn">int</span>(<span class="varc">texte</span>)
        <span class="fn">print</span>(<span class="str">f"Conversion reussie : {nombre}"</span>)
    <span class="kw">except</span>:
        <span class="fn">print</span>(<span class="str">f"Impossible de convertir '{texte}' en nombre"</span>)

<span class="fn">convertir</span>(<span class="str">"42"</span>)       <span class="cmt"># Conversion reussie : 42</span>
<span class="fn">convertir</span>(<span class="str">"bonjour"</span>)  <span class="cmt"># Impossible de convertir 'bonjour' en nombre</span></div></div>
<p>Remarque que la fonction ne plante jamais, quelle que soit l'entrée : c'est exactement ce qui rend une fonction "sûre" à appeler avec n'importe quelle donnée provenant d'un utilisateur, qu'on ne contrôle jamais complètement.</p></div>

<div class="theory-block"><h3>🎯 9.5 — Pour aller plus loin : cibler le type d'erreur</h3><p>Le except utilisé jusqu'ici est <b>générique</b> : il intercepte n'importe quel type d'erreur, sans distinction. C'est simple, mais ça peut aussi masquer des bugs différents que tu n'avais pas prévus. Une pratique plus rigoureuse consiste à préciser le type d'erreur attendu, par exemple except ValueError: pour ne réagir qu'aux erreurs de conversion, en laissant remonter les autres types d'erreurs (qui révèlent alors un vrai bug à corriger, pas une entrée utilisateur invalide).</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="kw">try</span>:
    <span class="varc">n</span> = <span class="fn">int</span>(<span class="str">"abc"</span>)
<span class="kw">except</span> <span class="varc">ValueError</span>:
    <span class="fn">print</span>(<span class="str">"Ce texte ne represente pas un nombre valide"</span>)</div></div>
<div class="tip"><b>Astuce —</b> tant que tu débutes, un except: générique comme dans l'exercice de ce jour reste tout à fait acceptable. La version ciblée par type d'erreur est une bonne habitude à prendre progressivement, une fois les mécanismes de base bien assimilés.</div>
</div>

<div class="tip-box"><strong>🔑 À retenir avant l'exercice</strong>
<ul style="margin:8px 0 0 18px;line-height:1.7">
<li><code>try</code> contient le code à risque ; <code>except</code> contient le code de secours si une erreur survient.</li>
<li>Si aucune erreur ne survient dans le try, le bloc except est ignoré, et le programme continue normalement.</li>
<li><code>int("bonjour")</code> lève une erreur ValueError car ce texte n'est pas un nombre valide.</li>
<li>Encapsuler une opération risquée dans une fonction protégée par try/except la rend sûre à appeler avec n'importe quelle entrée.</li>
</ul></div>

</div></div>`,
 starter:`# Jour 9 : gerer les erreurs
def convertir(texte):
    try:
        nombre = int(texte)
        print(f"Conversion reussie : {nombre}")
    except:
        print(f"Impossible de convertir '{texte}' en nombre")

convertir("42")
convertir("bonjour")`,
 quiz:[
  {q:"À quoi sert try/except ?", opts:["Accélérer le code","Gérer les erreurs sans planter le programme","Créer des boucles","Définir des fonctions"], ans:1},
  {q:"Que se passe-t-il si aucune erreur ne survient dans try ?", opts:["Le except s'exécute quand même","Le except est ignoré","Le programme plante","Rien ne s'exécute"], ans:1},
  {q:"int(\"bonjour\") va…", opts:["renvoyer 0","lever une erreur","renvoyer None","renvoyer \"bonjour\""], ans:1}
 ]},
{d:10, title:"Mini-projet", sub:"analyseur de mot de passe", level:"med",
 theory:`<div class="cell"><div class="cell-head"><span class="cell-tag">In [10]</span> Mini-projet — Chapitre 10</div><div class="cell-body">

<div class="theory-block"><h3>🎯 10.1 — Le cahier des charges : un analyseur de mot de passe</h3><p>Cinq jours de bases (fonctions, listes, dictionnaires, gestion d'erreurs, et tout ce qui précède) t'ont donné assez d'outils pour construire un vrai petit programme utile, pas juste un exercice isolé. La mission : écrire un outil qui prend un mot de passe en texte et lui attribue un niveau de solidité — <b>Faible</b>, <b>Moyen</b> ou <b>Fort</b> — en fonction de trois critères simples : sa longueur, la présence d'au moins un chiffre, et le mélange de majuscules et de minuscules. C'est exactement le genre de vérification que font de vrais formulaires d'inscription en ligne.</p></div>

<div class="theory-block"><h3>🧩 10.2 — Découper le problème avant d'écrire une seule ligne</h3><p>Le réflexe d'un programmeur expérimenté face à un problème comme celui-ci n'est pas d'écrire une seule grosse fonction qui fait tout d'un coup. C'est de le découper en petites fonctions, chacune responsable d'une seule vérification précise. Ici, on isole d'abord la vérification "ce texte contient-il un chiffre ?" dans sa propre fonction, avant même de s'attaquer à la logique globale.</p>
<div class="tip"><b>Pourquoi découper —</b> une petite fonction dédiée à un seul critère est plus facile à lire, plus facile à tester isolément (tu peux l'appeler seule pour vérifier qu'elle marche), et plus facile à réutiliser ailleurs si un jour tu as besoin de la même vérification dans un autre programme.</div>
</div>

<div class="theory-block"><h3>🔢 10.3 — Détecter un chiffre dans une chaîne, caractère par caractère</h3><p>Comment savoir si un mot de passe contient au moins un chiffre ? On parcourt le texte lettre par lettre, et pour chacune, on regarde si elle apparaît dans la chaîne "0123456789".</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="kw">def</span> <span class="fn">a_un_chiffre</span>(<span class="varc">texte</span>):
    <span class="varc">chiffres</span> = <span class="str">"0123456789"</span>
    <span class="kw">for</span> <span class="varc">lettre</span> <span class="kw">in</span> <span class="varc">texte</span>:
        <span class="kw">if</span> <span class="varc">lettre</span> <span class="kw">in</span> <span class="varc">chiffres</span>:
            <span class="kw">return</span> <span class="kw">True</span>
    <span class="kw">return</span> <span class="kw">False</span></div></div>
<p>L'opérateur <code>in</code> teste directement l'appartenance : "a" in "0123456789" vaut False, "7" in "0123456789" vaut True. Dès que la boucle rencontre un caractère présent dans chiffres, la fonction s'arrête immédiatement avec return True — inutile de continuer à examiner le reste du texte, la réponse est déjà connue. Ce n'est que si la boucle se termine <b>sans avoir jamais trouvé de chiffre</b> que l'on atteint la dernière ligne, return False.</p>
<div class="tip"><b>Piège évité —</b> placer le return False à l'intérieur de la boucle (au même niveau que le if) casserait tout : la fonction s'arrêterait dès le premier caractère qui n'est pas un chiffre, sans laisser une chance aux caractères suivants. C'est pour ça que ce return False final est indenté au même niveau que le for, en dehors de la boucle.</div>
</div>

<div class="theory-block"><h3>🧮 10.4 — Le système de points : additionner les critères remplis</h3><p>Une fois la brique "détection de chiffre" prête, la fonction principale analyser() peut tester les trois critères l'un après l'autre, et attribuer un point à chaque critère rempli.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="kw">def</span> <span class="fn">analyser</span>(<span class="varc">mdp</span>):
    <span class="varc">points</span> = <span class="num">0</span>
    <span class="kw">if</span> <span class="fn">len</span>(<span class="varc">mdp</span>) >= <span class="num">8</span>:
        <span class="varc">points</span> = <span class="varc">points</span> + <span class="num">1</span>          <span class="cmt"># critere 1 : longueur suffisante</span>
    <span class="kw">if</span> <span class="fn">a_un_chiffre</span>(<span class="varc">mdp</span>):
        <span class="varc">points</span> = <span class="varc">points</span> + <span class="num">1</span>          <span class="cmt"># critere 2 : au moins un chiffre</span>
    <span class="kw">if</span> <span class="varc">mdp</span>.upper() != <span class="varc">mdp</span>.lower():
        <span class="varc">points</span> = <span class="varc">points</span> + <span class="num">1</span>          <span class="cmt"># critere 3 : melange de casse</span></div></div>
<p>Le troisième critère mérite un détail : mdp.upper() met tout en majuscules, mdp.lower() met tout en minuscules. Si le mot de passe ne contient <b>que</b> des chiffres ou des symboles (aucune lettre), les deux versions sont strictement identiques — la comparaison != vaut donc False. Mais dès qu'il contient au moins une lettre, mettre cette lettre en majuscule ou en minuscule change le résultat, donc les deux versions diffèrent : != vaut True. C'est une façon élégante de détecter la présence de lettres <b>et</b>, indirectement, la possibilité d'un mélange de casse, sans avoir à écrire une troisième mini-fonction dédiée.</p></div>

<div class="theory-block"><h3>🏁 10.5 — Traduire le score en verdict lisible</h3><p>Trois critères possibles donnent un score de 0 à 3. La dernière étape traduit ce nombre en texte compréhensible, avec un enchaînement if / elif / else classique.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content">    <span class="kw">if</span> <span class="varc">points</span> == <span class="num">3</span>:
        <span class="kw">return</span> <span class="str">"Fort"</span>
    <span class="kw">elif</span> <span class="varc">points</span> == <span class="num">2</span>:
        <span class="kw">return</span> <span class="str">"Moyen"</span>
    <span class="kw">else</span>:
        <span class="kw">return</span> <span class="str">"Faible"</span></div></div>
<p>Remarque que le else final regroupe à la fois points == 1 et points == 0 — pas besoin d'un elif séparé pour chaque cas restant, puisque tout ce qui n'est ni 3 ni 2 mérite le même verdict "Faible".</p></div>

<div class="theory-block"><h3>🧪 10.6 — Vérifier le résultat sur des exemples concrets</h3><p>Avant de faire confiance à un programme, on le teste mentalement sur des cas connus. Reprenons les trois mots de passe de l'exercice :</p>
<p><code>"abc"</code> — longueur 3 (moins de 8, 0 point), pas de chiffre (0 point), pas de majuscule (0 point) → 0 point → <b>Faible</b>.<br>
<code>"motdepasse123"</code> — longueur 13 (≥ 8, 1 point), contient des chiffres (1 point), mais tout en minuscules (0 point) → 2 points → <b>Moyen</b>.<br>
<code>"MonMdp2026"</code> — longueur 10 (≥ 8, 1 point), contient des chiffres (1 point), mélange de majuscules et minuscules (1 point) → 3 points → <b>Fort</b>.</p>
<p>Ce genre de vérification manuelle, critère par critère, est le meilleur réflexe à garder à chaque fois que tu écris une fonction avec plusieurs conditions : avant de lancer le programme, refais le calcul toi-même sur papier pour être sûr que la logique correspond bien à ce que tu veux obtenir.</p></div>

<div class="tip-box"><strong>🔑 À retenir avant l'exercice</strong>
<ul style="margin:8px 0 0 18px;line-height:1.7">
<li>Découper un problème en petites fonctions (une par critère) rend le code plus lisible, testable et réutilisable.</li>
<li>a_un_chiffre() parcourt le texte caractère par caractère avec in, et renvoie True dès qu'un chiffre est trouvé.</li>
<li>points augmente de 1 à chaque critère rempli : longueur, présence d'un chiffre, mélange de casse.</li>
<li>3 points sur 3 donne le verdict Fort, 2 points donne Moyen, le reste donne Faible.</li>
</ul></div>

</div></div>`,
 starter:`# Jour 10 : mini-projet - analyseur de mot de passe
def a_un_chiffre(texte):
    chiffres = "0123456789"
    for lettre in texte:
        if lettre in chiffres:
            return True
    return False

def analyser(mdp):
    points = 0
    if len(mdp) >= 8:
        points = points + 1
    if a_un_chiffre(mdp):
        points = points + 1
    if mdp.upper() != mdp.lower():
        points = points + 1

    if points == 3:
        return "Fort"
    elif points == 2:
        return "Moyen"
    else:
        return "Faible"

print(analyser("abc"))
print(analyser("motdepasse123"))
print(analyser("MonMdp2026"))`,
 quiz:[
  {q:"Pourquoi découper analyser() en plusieurs petites fonctions ?", opts:["Pour que ce soit plus long","Pour rendre le code plus lisible et réutilisable","Ce n'est jamais utile","Python l'exige"], ans:1},
  {q:"Dans l'exercice, points augmente de 1 à chaque…", opts:["erreur","critère rempli","ligne de code","seconde"], ans:1},
  {q:"Un mot de passe \"Fort\" obtient ici…", opts:["0 point","1 point","2 points","3 points"], ans:3}
 ]}
]},
{ week:"Semaine 3 — Python orienté objet", days:[
{d:11, title:"Classes & objets", sub:"class, __init__, self", level:"hard",
 theory:`<div class="cell"><div class="cell-head"><span class="cell-tag">In [11]</span> Théorie — Chapitre 11</div><div class="cell-body">

<div class="theory-block"><h3>🏗️ 11.1 — Penser en objets : le grand changement</h3><p>Jusqu'ici, tu as manipulé des variables et des fonctions séparément : une variable stocke une donnée, une fonction agit sur des données qu'on lui passe en paramètre. La programmation orientée objet (POO) propose une autre organisation : regrouper des données et les fonctions qui les manipulent au même endroit, dans une structure qu'on appelle une <b>classe</b>. Pense à une classe comme à un plan d'architecte : le plan d'une maison n'est pas une maison habitable, mais il décrit précisément ce que chaque maison construite à partir de lui va posséder (des murs, des portes, un toit) et comment elle va se comporter (on peut ouvrir une porte, allumer une lumière). Une fois le plan écrit, tu peux construire autant de maisons que tu veux à partir de lui — chacune est un <b>objet</b>, aussi appelé une <b>instance</b> de la classe.</p></div>

<div class="theory-block"><h3>🧱 11.2 — Déclarer une classe avec class</h3><p>En Python, une classe se déclare avec le mot-clé <code>class</code>, suivi d'un nom qui commence toujours par une majuscule — c'est la convention <b>PascalCase</b> (chaque mot commence par une majuscule, sans underscore), à ne pas confondre avec le <code>snake_case</code> utilisé pour les variables et les fonctions. Cette convention n'est pas juste esthétique : en un coup d'œil, <code>Personnage</code> se lit comme une classe et <code>se_presenter</code> comme une fonction ou une méthode.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="kw">class</span> <span class="fn">Personnage</span>:
    <span class="cmt"># le contenu de la classe vient ici, indente</span></div></div>
</div>

<div class="theory-block"><h3>🔧 11.3 — __init__ : ce qui se passe à la naissance de l'objet</h3><p>Une classe vide n'est pas très utile : ce qui la rend puissante, c'est de pouvoir donner à chaque objet créé ses propres données dès le départ. C'est le rôle de la méthode spéciale <code>__init__</code> (les doubles underscores avant et après se prononcent "dunder init", pour "double underscore init"). Python l'appelle <b>automatiquement</b>, une seule fois, exactement au moment où un nouvel objet est créé — tu ne l'appelles jamais toi-même directement.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="kw">class</span> <span class="fn">Personnage</span>:
    <span class="kw">def</span> <span class="fn">__init__</span>(<span class="varc">self</span>, <span class="varc">nom</span>, <span class="varc">pv</span>):
        <span class="varc">self</span>.nom = <span class="varc">nom</span>
        <span class="varc">self</span>.pv = <span class="varc">pv</span></div></div>
<p>Dès qu'un <code>Personnage</code> est créé, ses attributs <code>nom</code> et <code>pv</code> sont posés immédiatement — impossible d'obtenir un objet "à moitié construit".</p></div>

<div class="theory-block"><h3>🪞 11.4 — self : de quel objet parle-t-on ?</h3><p><code>self</code> est le tout premier paramètre de <b>chaque</b> méthode d'instance, et il représente l'objet précis sur lequel la méthode est en train d'être appelée. C'est un point qui déstabilise beaucoup de débutants : si une classe peut donner naissance à des dizaines d'objets différents, comment une méthode sait-elle sur lequel elle travaille ? Réponse : Python transmet automatiquement l'objet concerné dans <code>self</code> à chaque appel — tu dois l'écrire dans la définition de la méthode, mais tu ne l'écris jamais dans l'appel.</p>
<div class="tip"><b>Piège fréquent —</b> oublier <code>self</code> comme premier paramètre d'une méthode provoque une erreur du type "missing argument" dès le premier appel. Et à l'intérieur d'une méthode, un attribut s'écrit toujours <code>self.nom</code>, jamais juste <code>nom</code> — sans le <code>self.</code>, Python cherche une variable locale qui n'existe pas.</div>
</div>

<div class="theory-block"><h3>🎭 11.5 — Instancier : donner vie au plan</h3><p>Créer un objet à partir d'une classe s'appelle <b>instancier</b>. La syntaxe ressemble à un appel de fonction, avec le nom de la classe : Python appelle <code>__init__</code> pour toi en coulisses, en te dispensant de passer <code>self</code> (il s'en charge).</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="varc">heros</span> = <span class="fn">Personnage</span>(<span class="str">"Nerija"</span>, <span class="num">100</span>)
<span class="varc">rival</span> = <span class="fn">Personnage</span>(<span class="str">"Awa"</span>, <span class="num">80</span>)
<span class="varc">heros</span>.pv = <span class="varc">heros</span>.pv - <span class="num">20</span>
<span class="fn">print</span>(<span class="varc">heros</span>.pv, <span class="varc">rival</span>.pv)  <span class="cmt"># 80 80 -- coincidence, pas un lien !</span></div></div>
<p>Chaque instance possède sa <b>propre copie</b> des attributs définis dans <code>__init__</code>. Modifier <code>heros.pv</code> ne touche en rien <code>rival.pv</code> : ce sont deux emplacements mémoire totalement indépendants, même s'ils viennent du même plan de classe.</p></div>

<div class="theory-block"><h3>📞 11.6 — Appeler une méthode sur un objet</h3><p>Une fois l'objet créé, on appelle ses méthodes avec la notation pointée <code>objet.methode()</code> — sans jamais fournir <code>self</code> dans l'appel, Python le déduit de ce qui se trouve avant le point.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="varc">heros</span>.<span class="fn">se_presenter</span>()
<span class="cmt"># équivaut, en coulisses, à Personnage.se_presenter(heros)</span></div></div>
<div class="tip"><b>Astuce —</b> si tu vois une erreur mentionnant un argument manquant alors que tu n'as rien changé, vérifie que tu n'as pas oublié <code>self</code> dans la définition de la méthode — c'est l'erreur numéro un des débutants en POO.</div>
</div>

<div class="tip-box"><strong>🔑 À retenir avant l'exercice</strong>
<ul style="margin:8px 0 0 18px;line-height:1.7">
<li>Une <code>class</code> est un plan ; un objet créé à partir d'elle est une <b>instance</b>.</li>
<li><code>__init__</code> s'exécute automatiquement à la création de l'objet, jamais appelé à la main.</li>
<li><code>self</code> représente l'instance en cours — premier paramètre obligatoire de chaque méthode.</li>
<li>Chaque instance a ses propres attributs, totalement indépendants des autres instances.</li>
</ul></div>

</div></div>`,
 starter:`# Jour 11 : ma premiere classe
class Personnage:
    def __init__(self, nom, pv):
        self.nom = nom
        self.pv = pv

    def se_presenter(self):
        print(f"Je suis {self.nom}, il me reste {self.pv} PV")

heros = Personnage("Nerija", 100)
heros.se_presenter()
heros.pv = heros.pv - 20
heros.se_presenter()`,
 quiz:[
  {q:"self représente…", opts:["le nom de la classe","l'instance en cours d'utilisation","une variable globale","rien de spécial"], ans:1},
  {q:"__init__ s'exécute…", opts:["à chaque appel de méthode","à la création de l'objet","à la fin du programme","jamais automatiquement"], ans:1},
  {q:"Une classe est un peu comme…", opts:["une fonction sans nom","un plan/modèle pour créer des objets","une boucle spéciale","un fichier séparé"], ans:1}
 ]},
{d:12, title:"Méthodes & attributs", sub:"le comportement des objets", level:"hard",
 theory:`<div class="cell"><div class="cell-head"><span class="cell-tag">In [12]</span> Théorie — Chapitre 12</div><div class="cell-body">

<div class="theory-block"><h3>🧠 12.1 — Attribut ou méthode : donnée ou comportement ?</h3><p>Dans une classe, on distingue deux types de membres. Un <b>attribut</b> (<code>self.xxx</code>) est une donnée : un état, une valeur qui décrit l'objet à un instant donné — un solde, un nom, un âge. Une <b>méthode</b> est une fonction définie à l'intérieur de la classe : elle décrit un <b>comportement</b>, une action que l'objet sait effectuer, et qui a le droit de lire et de modifier ses propres attributs via <code>self</code>. Un objet bien conçu regroupe logiquement ses données et les actions qui les concernent — c'est tout l'intérêt de la POO par rapport à des fonctions et des variables éparpillées.</p></div>

<div class="theory-block"><h3>💰 12.2 — Étude de cas : un compte bancaire</h3><p>Rien de tel qu'un exemple concret pour comprendre l'intérêt des méthodes. Un compte bancaire a un état (qui le possède, combien il contient) et des actions possibles (déposer, retirer). C'est exactement ce que modélise la classe de l'exercice du jour.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="kw">class</span> <span class="fn">CompteBancaire</span>:
    <span class="kw">def</span> <span class="fn">__init__</span>(<span class="varc">self</span>, <span class="varc">proprietaire</span>, <span class="varc">solde</span>):
        <span class="varc">self</span>.proprietaire = <span class="varc">proprietaire</span>
        <span class="varc">self</span>.solde = <span class="varc">solde</span></div></div>
<p>À ce stade, l'objet ne sait rien faire d'autre que stocker deux valeurs. Les méthodes suivantes vont lui donner un vrai comportement.</p></div>

<div class="theory-block"><h3>🔁 12.3 — Une méthode qui fait évoluer l'état de l'objet</h3><p>Contrairement à une fonction classique qui reçoit des données, calcule, puis renvoie un résultat sans rien garder en mémoire, une méthode peut <b>modifier durablement</b> l'objet sur lequel elle travaille. Après l'appel, l'attribut modifié garde sa nouvelle valeur pour tous les appels suivants — l'objet a un état qui évolue dans le temps.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content">    <span class="kw">def</span> <span class="fn">deposer</span>(<span class="varc">self</span>, <span class="varc">montant</span>):
        <span class="varc">self</span>.solde = <span class="varc">self</span>.solde + <span class="varc">montant</span>
        <span class="fn">print</span>(<span class="str">f"+{montant} F -> nouveau solde : {self.solde} F"</span>)</div></div>
<p>Chaque appel à <code>deposer()</code> repart du solde <b>actuel</b> de l'objet, pas d'une valeur figée au moment de l'écriture du code — c'est bien <code>self.solde</code>, la mémoire vivante de l'objet, qui est lue puis réécrite.</p></div>

<div class="theory-block"><h3>🛡️ 12.4 — Garde-fou : vérifier avant d'agir</h3><p>Une bonne méthode ne se contente pas d'exécuter une opération aveuglément : elle protège la cohérence de l'objet. Retirer de l'argent doit être impossible si le solde est insuffisant — sinon le compte basculerait dans un état incohérent (un solde négatif qui n'a pas de sens métier). C'est le rôle du <code>if</code> placé <b>avant</b> la modification.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content">    <span class="kw">def</span> <span class="fn">retirer</span>(<span class="varc">self</span>, <span class="varc">montant</span>):
        <span class="kw">if</span> <span class="varc">montant</span> > <span class="varc">self</span>.solde:
            <span class="fn">print</span>(<span class="str">"Solde insuffisant !"</span>)
        <span class="kw">else</span>:
            <span class="varc">self</span>.solde = <span class="varc">self</span>.solde - <span class="varc">montant</span>
            <span class="fn">print</span>(<span class="str">f"-{montant} F -> nouveau solde : {self.solde} F"</span>)</div></div>
<div class="tip"><b>Astuce —</b> ce réflexe — vérifier une condition avant de modifier un attribut sensible — s'appelle protéger les <b>invariants</b> de l'objet : des règles qui doivent rester vraies en toutes circonstances (ici, "le solde ne peut jamais être négatif").</div>
</div>

<div class="theory-block"><h3>🔗 12.5 — Suivre l'état d'un objet appel après appel</h3><p>Pour bien comprendre une classe, il faut savoir "rejouer le film" des appels de méthodes, un par un, en gardant trace de la valeur de chaque attribut.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="varc">compte</span> = <span class="fn">CompteBancaire</span>(<span class="str">"Nerija"</span>, <span class="num">5000</span>)  <span class="cmt"># solde = 5000</span>
<span class="varc">compte</span>.<span class="fn">deposer</span>(<span class="num">2000</span>)              <span class="cmt"># solde = 7000</span>
<span class="varc">compte</span>.<span class="fn">retirer</span>(<span class="num">10000</span>)             <span class="cmt"># refuse : 10000 > 7000</span>
<span class="varc">compte</span>.<span class="fn">retirer</span>(<span class="num">3000</span>)              <span class="cmt"># solde = 4000</span></div></div>
<p>Rien de magique : à chaque ligne, une seule variable évolue (<code>self.solde</code> à l'intérieur de l'objet <code>compte</code>), et chaque méthode part de la valeur laissée par la précédente.</p></div>

<div class="theory-block"><h3>🚧 12.6 — Python fait confiance au développeur</h3><p>Contrairement à d'autres langages, Python ne possède pas de mot-clé <code>private</code> qui empêcherait techniquement d'écrire <code>compte.solde = 999999</code> depuis l'extérieur, en contournant complètement la vérification de <code>retirer()</code>. La convention de la communauté Python, que tu croiseras souvent, est de préfixer d'un underscore les attributs qu'on préfère ne pas toucher directement (<code>self._solde</code>) — un simple signal de politesse entre développeurs, pas une barrière technique. La vraie protection reste la discipline : passer systématiquement par les méthodes de l'objet plutôt que par ses attributs bruts.</p></div>

<div class="tip-box"><strong>🔑 À retenir avant l'exercice</strong>
<ul style="margin:8px 0 0 18px;line-height:1.7">
<li>Attribut = donnée de l'objet ; méthode = action que l'objet sait faire.</li>
<li>Une méthode peut lire ET modifier durablement les attributs via <code>self</code>.</li>
<li>Vérifier une condition avant de modifier un attribut protège la cohérence de l'objet.</li>
<li>Python ne bloque pas l'accès direct aux attributs — c'est une question de discipline.</li>
</ul></div>

</div></div>`,
 starter:`# Jour 12 : une classe plus complete
class CompteBancaire:
    def __init__(self, proprietaire, solde):
        self.proprietaire = proprietaire
        self.solde = solde

    def deposer(self, montant):
        self.solde = self.solde + montant
        print(f"+{montant} F -> nouveau solde : {self.solde} F")

    def retirer(self, montant):
        if montant > self.solde:
            print("Solde insuffisant !")
        else:
            self.solde = self.solde - montant
            print(f"-{montant} F -> nouveau solde : {self.solde} F")

compte = CompteBancaire("Nerija", 5000)
compte.deposer(2000)
compte.retirer(10000)
compte.retirer(3000)`,
 quiz:[
  {q:"Une méthode est…", opts:["une variable de classe","une fonction définie dans une classe","un type de boucle","un import"], ans:1},
  {q:"Pourquoi vérifier \"montant > self.solde\" avant de retirer ?", opts:["Pour ralentir le programme","Pour éviter un solde négatif","C'est obligatoire en Python","Aucune raison"], ans:1},
  {q:"self.solde appartient…", opts:["à la classe entière","à chaque instance individuellement","à Python lui-même","à aucune classe"], ans:1}
 ]},
{d:13, title:"Héritage", sub:"réutiliser le code entre classes", level:"hard",
 theory:`<div class="cell"><div class="cell-head"><span class="cell-tag">In [13]</span> Théorie — Chapitre 13</div><div class="cell-body">

<div class="theory-block"><h3>🧬 13.1 — Le problème que l'héritage résout</h3><p>Imagine devoir créer les classes <code>Chien</code> et <code>Chat</code> sans héritage : chacune aurait besoin de son propre <code>__init__</code> pour stocker un <code>nom</code>, du code quasi identique copié-collé deux fois. Le jour où tu veux ajouter un attribut commun (par exemple <code>age</code>), il faudrait le modifier dans chaque classe séparément — source classique de bugs et d'oublis. L'<b>héritage</b> résout exactement ce problème : il permet à une classe de récupérer automatiquement tout ce que possède une autre classe, dite <b>classe parente</b> (ou classe de base), pour ne coder que ce qui change réellement.</p></div>

<div class="theory-block"><h3>👪 13.2 — Syntaxe : class Enfant(Parent):</h3><p>Pour hériter, on place le nom de la classe parente entre parenthèses juste après le nom de la nouvelle classe. À partir de cet instant, la classe enfant possède automatiquement tous les attributs et toutes les méthodes de la classe parente, sans avoir eu besoin de les réécrire.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="kw">class</span> <span class="fn">Animal</span>:
    <span class="kw">def</span> <span class="fn">__init__</span>(<span class="varc">self</span>, <span class="varc">nom</span>):
        <span class="varc">self</span>.nom = <span class="varc">nom</span>

    <span class="kw">def</span> <span class="fn">parler</span>(<span class="varc">self</span>):
        <span class="fn">print</span>(<span class="str">f"{self.nom} fait un bruit"</span>)

<span class="kw">class</span> <span class="fn">Chien</span>(<span class="fn">Animal</span>):
    <span class="kw">pass</span>  <span class="cmt"># herite de tout Animal sans rien changer</span></div></div>
<p>Même sans écrire une seule ligne à l'intérieur de <code>Chien</code>, un <code>Chien("Rex")</code> fonctionnerait déjà : il possède <code>self.nom</code> et sait <code>parler()</code>, exactement comme un <code>Animal</code>.</p></div>

<div class="theory-block"><h3>🔊 13.3 — Redéfinir une méthode : override</h3><p>L'intérêt devient évident quand une sous-classe veut se comporter <b>différemment</b> sur un point précis. Il suffit de redéfinir la méthode avec le même nom à l'intérieur de la sous-classe : c'est ce qu'on appelle <b>redéfinir</b> (ou "override" en anglais) une méthode. La nouvelle version remplace complètement l'ancienne pour cette sous-classe — les autres méthodes héritées, elles, restent inchangées.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="kw">class</span> <span class="fn">Chien</span>(<span class="fn">Animal</span>):
    <span class="kw">def</span> <span class="fn">parler</span>(<span class="varc">self</span>):
        <span class="fn">print</span>(<span class="str">f"{self.nom} aboie : Wouf !"</span>)

<span class="kw">class</span> <span class="fn">Chat</span>(<span class="fn">Animal</span>):
    <span class="kw">def</span> <span class="fn">parler</span>(<span class="varc">self</span>):
        <span class="fn">print</span>(<span class="str">f"{self.nom} miaule : Miaou !"</span>)</div></div>
<div class="tip"><b>Règle simple —</b> Python cherche toujours la méthode d'abord dans la classe de l'objet lui-même ; s'il ne la trouve pas là, il remonte vers la classe parente. Une méthode redéfinie dans la sous-classe est donc toujours prioritaire sur celle du parent.</div>
</div>

<div class="theory-block"><h3>🎭 13.4 — Polymorphisme : un seul appel, plusieurs comportements</h3><p>Ce mécanisme porte un nom : le <b>polymorphisme</b> ("plusieurs formes"). Il permet d'écrire une seule ligne de code générique qui produit un résultat différent selon le type réel de l'objet manipulé — sans avoir besoin de savoir à l'avance, ni de tester, de quel type précis il s'agit.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="varc">animaux</span> = [<span class="fn">Chien</span>(<span class="str">"Rex"</span>), <span class="fn">Chat</span>(<span class="str">"Mimi"</span>), <span class="fn">Animal</span>(<span class="str">"Creature"</span>)]
<span class="kw">for</span> <span class="varc">animal</span> <span class="kw">in</span> <span class="varc">animaux</span>:
    <span class="varc">animal</span>.<span class="fn">parler</span>()
<span class="cmt"># Rex aboie / Mimi miaule / Creature fait un bruit</span></div></div>
<p>La ligne <code>animal.parler()</code> est écrite <b>une seule fois</b>, mais elle exécute trois comportements différents selon que <code>animal</code> pointe vers un <code>Chien</code>, un <code>Chat</code> ou un simple <code>Animal</code>. C'est extrêmement puissant : tu peux faire grandir la liste d'espèces sans jamais toucher à la boucle qui les fait parler.</p></div>

<div class="theory-block"><h3>🧩 13.5 — Ce qu'on récupère gratuitement de la classe parente</h3><p>Remarque un détail important : ni <code>Chien</code> ni <code>Chat</code> ne redéfinissent <code>__init__</code>. Pourtant, <code>Chien("Rex")</code> fonctionne parfaitement et pose bien <code>self.nom</code>. C'est parce qu'en l'absence d'un <code>__init__</code> propre à la sous-classe, Python utilise automatiquement celui hérité de la classe parente, <code>Animal</code>. Une sous-classe n'a besoin de redéfinir <b>que</b> ce qui doit réellement changer — tout le reste continue de venir du parent sans effort supplémentaire.</p></div>

<div class="theory-block"><h3>🛠️ 13.6 — Un aperçu pour plus tard : super()</h3><p>Que faire si une sous-classe veut garder le comportement du parent <b>et</b> ajouter quelque chose en plus, plutôt que de tout remplacer ? Python fournit pour cela la fonction <code>super()</code>, qui permet d'appeler explicitement la méthode de la classe parente depuis la sous-classe avant (ou après) d'ajouter du code additionnel. Tu n'en as pas besoin pour l'exercice du jour — retiens simplement que ce mot existe, tu le croiseras dès que tu écriras des hiérarchies de classes plus élaborées.</p></div>

<div class="tip-box"><strong>🔑 À retenir avant l'exercice</strong>
<ul style="margin:8px 0 0 18px;line-height:1.7">
<li><code>class Chien(Animal):</code> fait hériter Chien de tout ce que possède Animal.</li>
<li>Redéfinir une méthode dans la sous-classe remplace la version du parent pour cette classe.</li>
<li>Le polymorphisme : un même appel de méthode produit un comportement différent selon le type réel de l'objet.</li>
<li>Sans <code>__init__</code> propre, une sous-classe utilise automatiquement celui du parent.</li>
</ul></div>

</div></div>`,
 starter:`# Jour 13 : heritage entre classes
class Animal:
    def __init__(self, nom):
        self.nom = nom

    def parler(self):
        print(f"{self.nom} fait un bruit")

class Chien(Animal):
    def parler(self):
        print(f"{self.nom} aboie : Wouf !")

class Chat(Animal):
    def parler(self):
        print(f"{self.nom} miaule : Miaou !")

animaux = [Chien("Rex"), Chat("Mimi"), Animal("Creature")]
for animal in animaux:
    animal.parler()`,
 quiz:[
  {q:"L'héritage permet de…", opts:["dupliquer tout le code","réutiliser le comportement d'une classe parente","supprimer une classe","ralentir le programme"], ans:1},
  {q:"class Chien(Animal): signifie que Chien…", opts:["remplace Animal","hérite d'Animal","importe Animal","est identique à Animal"], ans:1},
  {q:"Si Chien redéfinit parler(), Python utilise…", opts:["toujours la version d'Animal","la version de Chien","les deux en même temps","aucune des deux"], ans:1}
 ]},
{d:14, title:"Modules", sub:"import, random et math", level:"hard",
 theory:`<div class="cell"><div class="cell-head"><span class="cell-tag">In [14]</span> Théorie — Chapitre 14</div><div class="cell-body">

<div class="theory-block"><h3>📦 14.1 — Qu'est-ce qu'un module ?</h3><p>Un module est simplement un fichier Python rempli de fonctions, de classes et de valeurs déjà écrites, testées, et prêtes à être réutilisées. Python est livré avec une immense collection de modules intégrés — c'est ce qu'on appelle sa <b>bibliothèque standard</b>, souvent résumée par l'expression "batteries included" (les piles sont fournies) : pas besoin d'installer quoi que ce soit pour générer un nombre aléatoire ou calculer une racine carrée, c'est déjà là.</p></div>

<div class="theory-block"><h3>🎲 14.2 — import : ouvrir la boîte à outils</h3><p>Pour utiliser un module, on l'importe en tout début de fichier avec le mot-clé <code>import</code>, suivi de son nom. Une fois importé, on accède à son contenu avec la notation pointée <code>module.fonction()</code> — exactement comme on accède à une méthode d'un objet.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="kw">import</span> <span class="varc">random</span>
<span class="kw">import</span> <span class="varc">math</span>

<span class="fn">print</span>(<span class="varc">random</span>.randint(<span class="num">1</span>, <span class="num">6</span>))</div></div>
</div>

<div class="theory-block"><h3>🎯 14.3 — random : simuler le hasard</h3><p>Le module <code>random</code> regroupe les fonctions liées au tirage aléatoire. Deux d'entre elles suffisent largement pour bien démarrer :</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="varc">de</span> = <span class="varc">random</span>.randint(<span class="num">1</span>, <span class="num">6</span>)  <span class="cmt"># entier entre 1 et 6 INCLUS</span>

<span class="varc">fruits</span> = [<span class="str">"mangue"</span>, <span class="str">"banane"</span>, <span class="str">"ananas"</span>, <span class="str">"orange"</span>]
<span class="varc">fruit_du_jour</span> = <span class="varc">random</span>.choice(<span class="varc">fruits</span>)  <span class="cmt"># un element au hasard dans la liste</span></div></div>
<p><code>randint(a, b)</code> tire un entier au hasard entre <code>a</code> et <code>b</code>, les <b>deux bornes incluses</b> — une différence importante avec <code>range()</code>, qui exclut sa borne de fin. <code>choice(sequence)</code>, lui, ne travaille pas sur des nombres mais pioche un élément au hasard dans n'importe quelle liste, quel que soit son contenu.</p>
<div class="tip"><b>Piège fréquent —</b> confondre <code>randint(1, 6)</code> (borne haute incluse, comme un vrai dé à 6 faces) avec <code>range(1, 6)</code> (borne haute exclue, s'arrête à 5). Ce sont deux règles différentes à ne pas mélanger.</div>
</div>

<div class="theory-block"><h3>📐 14.4 — math : les outils mathématiques</h3><p>Le module <code>math</code> fournit des constantes et des fonctions mathématiques prêtes à l'emploi. <code>math.pi</code> n'est pas une fonction mais une <b>constante</b> — pas de parenthèses après elle, c'est directement une valeur. <code>math.pow(x, y)</code>, en revanche, est bien une fonction : elle calcule x élevé à la puissance y.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="varc">rayon</span> = <span class="num">5</span>
<span class="varc">aire</span> = <span class="varc">math</span>.pi * <span class="varc">math</span>.pow(<span class="varc">rayon</span>, <span class="num">2</span>)
<span class="fn">print</span>(<span class="fn">round</span>(<span class="varc">aire</span>, <span class="num">2</span>))</div></div>
<p>Remarque au passage <code>round(valeur, 2)</code> : ce n'est pas une fonction du module <code>math</code>, mais une fonction <b>intégrée</b> de Python (disponible partout, sans import), qui arrondit un nombre à virgule à un nombre de décimales donné — très utile pour afficher un résultat propre plutôt qu'une longue suite de décimales.</p></div>

<div class="theory-block"><h3>🗂️ 14.5 — Pourquoi module.fonction() et pas juste fonction() ?</h3><p>Cette notation pointée n'est pas là pour compliquer les choses : elle évite les conflits de noms. Si deux modules différents définissaient chacun une fonction appelée <code>choice</code>, Python (et toi) sauriez immédiatement laquelle est utilisée grâce au préfixe — <code>random.choice</code> ne peut être confondue avec rien d'autre. C'est aussi une aide à la lecture : en voyant <code>math.pi</code> dans du code que tu n'as pas écrit, tu sais instantanément d'où vient cette valeur.</p></div>

<div class="theory-block"><h3>🧪 14.6 — Ce que simule ce terminal</h3><p>Le terminal de cet exercice simule un sous-ensemble volontairement limité de <code>random</code> et de <code>math</code> — largement suffisant pour couvrir <code>randint</code>, <code>choice</code>, <code>pi</code> et <code>pow</code>. Sur un vrai interpréteur Python installé sur ta machine, ces modules offrent beaucoup plus de fonctions (mélanger une liste avec <code>random.shuffle</code>, calculer une racine carrée avec <code>math.sqrt</code>, etc.) — une bonne raison d'aller explorer la documentation officielle une fois le bootcamp terminé.</p></div>

<div class="tip-box"><strong>🔑 À retenir avant l'exercice</strong>
<ul style="margin:8px 0 0 18px;line-height:1.7">
<li><code>import nom_du_module</code> donne accès à tout son contenu via <code>module.xxx</code>.</li>
<li><code>random.randint(a, b)</code> : entier aléatoire, bornes incluses des deux côtés.</li>
<li><code>random.choice(liste)</code> : un élément pris au hasard dans une séquence.</li>
<li><code>math.pi</code> est une constante, <code>math.pow(x, y)</code> est une fonction.</li>
</ul></div>

</div></div>`,
 starter:`# Jour 14 : modules (random et math)
import random
import math

de = random.randint(1, 6)
print(f"Tu as lance le de : {de}")

rayon = 5
aire = math.pi * math.pow(rayon, 2)
print(f"Aire du cercle (rayon {rayon}) : {round(aire, 2)}")

fruits = ["mangue", "banane", "ananas", "orange"]
fruit_du_jour = random.choice(fruits)
print(f"Fruit du jour : {fruit_du_jour}")`,
 quiz:[
  {q:"import random donne accès à…", opts:["des fonctions liées au hasard","des fonctions mathématiques","des fichiers","rien"], ans:0},
  {q:"À quoi sert math.pi ?", opts:["À une fonction","À la valeur du nombre Pi","À un module entier","À rien en Python"], ans:1},
  {q:"random.choice(liste) renvoie…", opts:["le premier élément","un élément au hasard dans la liste","tous les éléments","l'index le plus grand"], ans:1}
 ]},
{d:15, title:"Premier grand projet", sub:"pierre-papier-ciseaux en console", level:"hard",
 theory:`<div class="cell"><div class="cell-head"><span class="cell-tag">In [15]</span> Projet final — Chapitre 15</div><div class="cell-body">

<div class="theory-block"><h3>🏁 15.1 — Vue d'ensemble : ce qu'on va construire</h3><p>Dernier jour du parcours Python : place à un vrai mini-jeu jouable dans le terminal, pierre-papier-ciseaux contre l'ordinateur. Le déroulé est simple à énoncer mais mobilise pratiquement tout ce que tu as appris depuis le Jour 1 : demander un choix au joueur avec <code>input()</code> (Jour 2), faire tirer un choix aléatoire à l'ordinateur avec <code>random.choice()</code> (Jour 14), comparer les deux choix avec des conditions (Jour 3), encapsuler la décision dans une fonction qui renvoie un résultat (Jour 6), et enfin afficher un message adapté selon ce résultat.</p></div>

<div class="theory-block"><h3>🧠 15.2 — Isoler la décision dans une fonction pure</h3><p>Le cœur du projet est la fonction <code>determiner_gagnant(joueur, ordinateur)</code>. Remarque ce qu'elle <b>ne fait pas</b> : elle n'affiche rien avec <code>print()</code>, elle ne demande rien à l'utilisateur. Elle prend deux valeurs en entrée et renvoie un texte en sortie parmi trois possibilités : <code>"Egalite"</code>, <code>"Joueur"</code> ou <code>"Ordinateur"</code>. Une fonction de ce type s'appelle une fonction <b>pure</b> : son résultat ne dépend que de ses paramètres, jamais d'un état extérieur, ce qui la rend facile à relire, à tester et à réutiliser ailleurs (par exemple pour rejouer plusieurs manches sans tout réécrire).</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="kw">def</span> <span class="fn">determiner_gagnant</span>(<span class="varc">joueur</span>, <span class="varc">ordinateur</span>):
    <span class="kw">if</span> <span class="varc">joueur</span> == <span class="varc">ordinateur</span>:
        <span class="kw">return</span> <span class="str">"Egalite"</span>
    <span class="cmt"># si on arrive ici, joueur != ordinateur</span></div></div>
<p>Traiter l'égalité en tout premier, avec un <code>return</code> immédiat, simplifie tout le reste de la fonction : plus bas, on sait avec certitude que les deux choix sont différents, donc il y a forcément un gagnant.</p></div>

<div class="theory-block"><h3>🔍 15.3 — Décortiquer la condition de victoire</h3><p>La ligne la plus dense du projet mérite d'être lue lentement :</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="varc">gagne</span> = (<span class="varc">joueur</span> == <span class="str">"pierre"</span> <span class="kw">and</span> <span class="varc">ordinateur</span> == <span class="str">"ciseaux"</span>) <span class="kw">or</span> (<span class="varc">joueur</span> == <span class="str">"feuille"</span> <span class="kw">and</span> <span class="varc">ordinateur</span> == <span class="str">"pierre"</span>) <span class="kw">or</span> (<span class="varc">joueur</span> == <span class="str">"ciseaux"</span> <span class="kw">and</span> <span class="varc">ordinateur</span> == <span class="str">"feuille"</span>)</div></div>
<p>C'est en réalité trois petites règles reliées par des <code>or</code> : le joueur gagne si (pierre bat ciseaux) OU (feuille bat pierre) OU (ciseaux bat feuille) — les trois seules combinaisons gagnantes du jeu. Chaque bloc entre parenthèses combine deux égalités avec <code>and</code> : les deux conditions doivent être vraies <b>en même temps</b> pour que ce cas de figure compte comme une victoire. La variable <code>gagne</code> stocke directement un <code>bool</code> (<code>True</code> ou <code>False</code>), résultat de toute cette expression — inutile d'écrire un <code>if</code> pour ça, une comparaison logique renvoie déjà un booléen.</p>
<div class="tip"><b>Astuce de lecture —</b> face à une longue expression avec plusieurs <code>and</code>/<code>or</code>, isole-la visuellement par parenthèses (même quand Python ne les exige pas) : cela force à identifier chaque sous-condition et évite les erreurs de priorité entre <code>and</code> et <code>or</code>.</div>
</div>

<div class="theory-block"><h3>🎲 15.4 — Le hasard qui rend l'adversaire imprévisible</h3><p>Sans <code>random.choice()</code>, l'ordinateur jouerait toujours le même coup, ou un coup écrit en dur — aucun intérêt. En tirant son choix au hasard dans la même liste que celle proposée au joueur, on garantit un adversaire réellement imprévisible, et surtout <b>équitable</b> : il a exactement les mêmes trois options que le joueur, ni plus ni moins.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="varc">choix</span> = [<span class="str">"pierre"</span>, <span class="str">"feuille"</span>, <span class="str">"ciseaux"</span>]
<span class="varc">ordinateur</span> = <span class="varc">random</span>.choice(<span class="varc">choix</span>)</div></div>
</div>

<div class="theory-block"><h3>🗺️ 15.5 — Séparer la logique de l'affichage</h3><p>Regarde bien l'organisation générale du script : d'abord on calcule (<code>determiner_gagnant</code> renvoie un texte), <b>ensuite seulement</b> on affiche, avec un bloc <code>if / elif / else</code> qui choisit le bon message selon la valeur reçue. Cette séparation entre "décider" et "afficher" n'est pas un détail — c'est une habitude d'organisation qui te suivra sur des projets bien plus gros : le jour où tu voudras afficher les résultats autrement (dans une fenêtre graphique, sur une page web, dans un fichier), tu n'auras besoin de changer que la partie affichage. La fonction de décision, elle, n'aura pas à bouger d'une ligne.</p></div>

<div class="theory-block"><h3>🚀 15.6 — Pour aller plus loin</h3><p>Le script actuel joue une seule manche puis s'arrête. Une fois l'exercice terminé, essaie d'aller plus loin par toi-même : ajoute une boucle <code>while</code> pour enchaîner plusieurs manches, garde le score dans deux variables (<code>score_joueur</code>, <code>score_ordinateur</code>) que tu incrémentes selon le résultat, et affiche le score final quand le joueur décide d'arrêter. Envie d'aller encore plus loin avec ce que tu as appris cette semaine ? Transforme le jeu en une classe <code>Jeu</code> avec des attributs pour les scores et une méthode <code>jouer_un_tour()</code> qui encapsule toute la logique — un excellent exercice personnel pour relier le chapitre 11 à ce projet final.</p></div>

<div class="tip-box"><strong>🎉 Bravo, tu termines la semaine 3 !</strong>
<ul style="margin:8px 0 0 18px;line-height:1.7">
<li>Tu es parti de <code>print()</code> et de simples variables, et tu termines avec des classes, de l'héritage et un vrai jeu fonctionnel.</li>
<li>Ce que tu as construit ici n'est pas un exercice jetable : les mêmes briques (fonctions, conditions, boucles, listes, objets) sont celles qu'on retrouve dans absolument tous les programmes Python, des plus petits scripts aux plus grosses applications.</li>
<li>La semaine 4 t'attend : données imbriquées, fonctions avancées, récursivité, algorithmes de recherche et de tri, puis un vrai projet final.</li>
<li>Relis sans hésiter les jours qui t'ont semblé denses (Jours 11 à 13 en particulier) — la POO se comprend souvent mieux à la deuxième lecture, une fois qu'on a vu où elle mène.</li>
</ul></div>

</div></div>`,
 starter:`# Jour 15 : projet final - pierre-papier-ciseaux
def determiner_gagnant(joueur, ordinateur):
    if joueur == ordinateur:
        return "Egalite"
    gagne = (joueur == "pierre" and ordinateur == "ciseaux") or (joueur == "feuille" and ordinateur == "pierre") or (joueur == "ciseaux" and ordinateur == "feuille")
    if gagne:
        return "Joueur"
    else:
        return "Ordinateur"

choix = ["pierre", "feuille", "ciseaux"]
joueur = input("Ton choix (pierre / feuille / ciseaux) : ")
ordinateur = random.choice(choix)

print(f"Ordinateur a choisi : {ordinateur}")
resultat = determiner_gagnant(joueur, ordinateur)

if resultat == "Egalite":
    print("Egalite parfaite !")
elif resultat == "Joueur":
    print("Tu as gagne !")
else:
    print("L'ordinateur a gagne !")`,
 quiz:[
  {q:"determiner_gagnant() renvoie…", opts:["un nombre","un texte parmi plusieurs résultats possibles","rien","toujours \"Egalite\""], ans:1},
  {q:"Pourquoi utiliser random.choice(choix) pour l'ordinateur ?", opts:["Pour tricher","Pour simuler un choix imprévisible","Ce n'est pas nécessaire","Pour ralentir le jeu"], ans:1},
  {q:"Ce projet final combine…", opts:["uniquement des boucles","fonctions + conditions + listes + hasard","uniquement des classes","uniquement l'affichage"], ans:1}
 ]}
]},
{ week:"Semaine 4 — Aller plus loin", days:[
{d:16, title:"Données imbriquées", sub:"listes de dictionnaires et structures composées", level:"hard",
 theory:`<div class="cell"><div class="cell-head"><span class="cell-tag">In [16]</span> Théorie — Chapitre 16</div><div class="cell-body">

<div class="theory-block"><h3>🗂️ 16.1 — Quand une seule structure ne suffit plus</h3><p>Jusqu'ici, tu as rangé des valeurs simples dans des listes (une suite de notes) et des paires clé-valeur dans des dictionnaires (le profil d'un élève). Les vrais programmes mélangent les deux : une boutique gère <b>plusieurs produits</b>, chacun avec un nom, un prix et un stock ; une école gère <b>plusieurs élèves</b>, chacun avec un nom et des notes.</p>
<p>La solution s'appelle l'<b>imbrication</b> : on place des dictionnaires à l'intérieur d'une liste. La liste joue le rôle du classeur, et chaque dictionnaire celui d'une fiche. C'est exactement la forme des données que tu rencontreras plus tard dans les API et les fichiers JSON.</p></div>

<div class="theory-block"><h3>🧱 16.2 — Construire et lire une liste de dictionnaires</h3><div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content">eleves = [{<span class="str">"nom"</span>: <span class="str">"Awa"</span>, <span class="str">"note"</span>: <span class="num">15</span>}, {<span class="str">"nom"</span>: <span class="str">"Moussa"</span>, <span class="str">"note"</span>: <span class="num">12</span>}]

<span class="fn">print</span>(eleves[<span class="num">0</span>])            <span class="cmt"># {'nom': 'Awa', 'note': 15}</span>
<span class="fn">print</span>(eleves[<span class="num">0</span>][<span class="str">"nom"</span>])     <span class="cmt"># Awa</span>
<span class="fn">print</span>(eleves[<span class="num">1</span>][<span class="str">"note"</span>])    <span class="cmt"># 12</span></div></div>
<p>Deux paires de crochets, deux étapes : le premier <code>[0]</code> choisit la <b>fiche</b> (sa position dans la liste), le second <code>["nom"]</code> choisit le <b>champ</b> dans cette fiche. Lis toujours de gauche à droite : « dans la liste, prends la fiche numéro 0, puis son champ nom ».</p>
<div class="tip"><b>Piège fréquent —</b> inverser les deux niveaux. <code>eleves["nom"]</code> provoque une erreur : <code>eleves</code> est une liste, elle attend un numéro, pas un texte. Une liste s'interroge avec un index, un dictionnaire avec une clé.</div></div>

<div class="theory-block"><h3>🔁 16.3 — Parcourir les fiches une par une</h3><p>Dans <code>for eleve in eleves</code>, la variable <code>eleve</code> reçoit à chaque tour une <b>fiche complète</b> : un dictionnaire. Tu lis ensuite ses champs comme d'habitude.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="kw">for</span> eleve <span class="kw">in</span> eleves:
    <span class="fn">print</span>(f<span class="str">"{eleve['nom']} a obtenu {eleve['note']}/20"</span>)</div></div>
<div class="tip"><b>Astuce —</b> dans une f-string délimitée par des guillemets doubles, utilise des guillemets <b>simples</b> pour les clés à l'intérieur des accolades : <code>eleve['nom']</code>. Réutiliser les mêmes guillemets ferme la chaîne trop tôt et provoque une erreur de syntaxe.</div></div>

<div class="theory-block"><h3>📊 16.4 — Calculer, chercher, modifier, ajouter</h3><p>Quatre gestes reviennent sans cesse quand on manipule des fiches : cumuler un champ, chercher la meilleure valeur, corriger une donnée, ajouter une entrée.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content">total = <span class="num">0</span>
<span class="kw">for</span> eleve <span class="kw">in</span> eleves:
    total += eleve[<span class="str">"note"</span>]              <span class="cmt"># cumuler un champ</span>
moyenne = total / <span class="fn">len</span>(eleves)

meilleur = eleves[<span class="num">0</span>]                    <span class="cmt"># chercher le maximum</span>
<span class="kw">for</span> eleve <span class="kw">in</span> eleves:
    <span class="kw">if</span> eleve[<span class="str">"note"</span>] &gt; meilleur[<span class="str">"note"</span>]:
        meilleur = eleve

eleves[<span class="num">1</span>][<span class="str">"note"</span>] = <span class="num">13</span>                  <span class="cmt"># modifier un champ</span>
eleves.<span class="fn">append</span>({<span class="str">"nom"</span>: <span class="str">"Fatou"</span>, <span class="str">"note"</span>: <span class="num">17</span>})   <span class="cmt"># ajouter une fiche</span></div></div>
<p>Un détail important : <code>meilleur = eleve</code> ne <b>recopie pas</b> la fiche, elle donne un second nom à la même fiche. Modifier <code>meilleur["note"]</code> modifierait donc aussi la note dans la liste : c'est le même objet, désigné de deux façons.</p></div>

</div></div>`,
 starter:`# Jour 16 : une classe d'eleves
eleves = [{"nom": "Awa", "note": 15}, {"nom": "Moussa", "note": 12}, {"nom": "Fatou", "note": 17}]

total = 0
for eleve in eleves:
    print(f"{eleve['nom']} : {eleve['note']}/20")
    total += eleve["note"]

moyenne = total / len(eleves)
print(f"Moyenne de la classe : {round(moyenne, 1)}")

meilleur = eleves[0]
for eleve in eleves:
    if eleve["note"] > meilleur["note"]:
        meilleur = eleve
print(f"Meilleure note : {meilleur['nom']}")

eleves.append({"nom": "Koffi", "note": 14})
print("Effectif :", len(eleves))`,
 quiz:[{"q": "Comment lire la note du 2e élève d'une liste eleves de dictionnaires ?", "opts": ["eleves[\"note\"][1]", "eleves[1][\"note\"]", "eleves[\"note\"]", "eleves[2][\"note\"]"], "ans": 1}, {"q": "Dans for eleve in eleves:, que contient eleve à chaque tour ?", "opts": ["Un numéro d'index", "Une fiche complète (un dictionnaire)", "Uniquement le nom de l'élève", "La liste entière"], "ans": 1}, {"q": "Quelle instruction ajoute une nouvelle fiche à la liste ?", "opts": ["eleves.append({\"nom\": \"Koffi\", \"note\": 14})", "eleves[\"Koffi\"] = 14", "eleves.nom = \"Koffi\"", "add(eleves, \"Koffi\")"], "ans": 0}]},
{d:17, title:"Fonctions avancées", sub:"valeurs par défaut, portée et composition", level:"hard",
 theory:`<div class="cell"><div class="cell-head"><span class="cell-tag">In [17]</span> Théorie — Chapitre 17</div><div class="cell-body">

<div class="theory-block"><h3>🎛️ 17.1 — Valeurs par défaut : des paramètres facultatifs</h3><p>Tu sais déjà écrire des fonctions avec des paramètres. Python permet de donner à un paramètre une <b>valeur par défaut</b> : si l'appelant ne fournit rien, la valeur prévue s'applique ; s'il fournit une valeur, elle la remplace.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="kw">def</span> prix_ttc(prix, taux=<span class="num">0.18</span>):
    <span class="kw">return</span> prix * (<span class="num">1</span> + taux)

<span class="fn">print</span>(prix_ttc(<span class="num">1000</span>))          <span class="cmt"># taux par défaut : 0.18</span>
<span class="fn">print</span>(prix_ttc(<span class="num">1000</span>, <span class="num">0.10</span>))    <span class="cmt"># on remplace le défaut</span></div></div>
<div class="tip"><b>Règle à retenir —</b> les paramètres avec valeur par défaut se placent <b>toujours après</b> ceux qui n'en ont pas. <code>def f(taux=0.18, prix)</code> est refusé par Python : comment saurait-il quel argument correspond à quoi ?</div></div>

<div class="theory-block"><h3>🔒 17.2 — La portée : qui voit quoi ?</h3><p>Une variable créée <b>dans</b> une fonction est <b>locale</b> : elle naît à l'appel et disparaît au <code>return</code>. Une variable créée en dehors de toute fonction est <b>globale</b> : les fonctions peuvent la lire.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content">TVA = <span class="num">0.18</span>                        <span class="cmt"># globale (en MAJUSCULES : c'est une constante)</span>

<span class="kw">def</span> total(prix):
    resultat = prix * (<span class="num">1</span> + TVA)   <span class="cmt"># resultat est locale à total()</span>
    <span class="kw">return</span> resultat

<span class="fn">print</span>(total(<span class="num">500</span>))                 <span class="cmt"># 590.0</span>
<span class="cmt"># print(resultat)  -&gt; NameError : resultat n'existe qu'à l'intérieur de la fonction</span></div></div>
<p>Bonne pratique : une fonction devrait recevoir ses données en <b>paramètres</b> et transmettre son résultat avec <b>return</b>, plutôt que de dépendre de variables globales qu'elle irait modifier en cachette. Le code est alors plus facile à tester et à comprendre.</p></div>

<div class="theory-block"><h3>🧩 17.3 — Composer : de petites fonctions qui s'appellent</h3><p>Une bonne fonction fait <b>une seule chose</b>. Pour un travail complexe, on écrit plusieurs petites fonctions et on les fait s'appeler entre elles, comme des pièces de Lego.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="kw">def</span> formater(montant):
    <span class="kw">return</span> f<span class="str">"{round(montant)} FCFA"</span>

<span class="kw">def</span> afficher_facture(article, prix, quantite=<span class="num">1</span>):
    total = prix_ttc(prix) * quantite
    <span class="fn">print</span>(f<span class="str">"{article} x{quantite} : {formater(total)}"</span>)
    <span class="kw">return</span> total</div></div>
<p>Ici <code>afficher_facture</code> s'appuie sur <code>prix_ttc</code> et <code>formater</code>. Si demain le format d'affichage change, tu ne modifies qu'un seul endroit.</p></div>

<div class="theory-block"><h3>↩️ 17.4 — return ou print : une différence qui compte</h3><div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="kw">def</span> double_print(n):
    <span class="fn">print</span>(n * <span class="num">2</span>)          <span class="cmt"># affiche, mais renvoie None</span>

<span class="kw">def</span> double_return(n):
    <span class="kw">return</span> n * <span class="num">2</span>          <span class="cmt"># renvoie la valeur, réutilisable</span>

x = double_return(<span class="num">4</span>) + <span class="num">1</span>  <span class="cmt"># 9 : on peut calculer avec le résultat</span></div></div>
<div class="tip"><b>Piège fréquent —</b> une fonction qui se contente d'afficher ne peut pas être réutilisée dans un calcul : <code>double_print(4) + 1</code> échoue, car la fonction renvoie <code>None</code>. Dans une fonction de calcul, utilise <code>return</code> et laisse l'affichage à l'appelant.</div></div>

</div></div>`,
 starter:`# Jour 17 : fonctions avancees
TVA = 0.18

def prix_ttc(prix, taux=TVA):
    return prix * (1 + taux)

def formater(montant):
    return f"{round(montant)} FCFA"

def afficher_facture(article, prix, quantite=1):
    total = prix_ttc(prix) * quantite
    print(f"{article} x{quantite} : {formater(total)}")
    return total

a = afficher_facture("Cahier", 500, 3)
b = afficher_facture("Stylo", 200)
print("Total a payer :", formater(a + b))`,
 quiz:[{"q": "Avec def f(a, b=10): que vaut b quand on appelle f(5) ?", "opts": ["Une erreur : il manque un argument", "10, la valeur par défaut", "0", "None"], "ans": 1}, {"q": "Une variable créée à l'intérieur d'une fonction est…", "opts": ["visible partout dans le programme", "locale : elle disparaît à la fin de la fonction", "toujours globale", "modifiée automatiquement à l'extérieur"], "ans": 1}, {"q": "Pourquoi préférer return à print dans une fonction de calcul ?", "opts": ["print est interdit dans une fonction", "return renvoie une valeur réutilisable ailleurs dans le programme", "return est plus rapide à taper", "Il n'y a aucune différence"], "ans": 1}]},
{d:18, title:"Récursivité", sub:"une fonction qui s'appelle elle-même", level:"hard",
 theory:`<div class="cell"><div class="cell-head"><span class="cell-tag">In [18]</span> Théorie — Chapitre 18</div><div class="cell-body">

<div class="theory-block"><h3>🪞 18.1 — Une fonction qui s'appelle elle-même</h3><p>Imagine des poupées russes : ouvre la première, tu trouves une poupée identique en plus petit, et ainsi de suite jusqu'à la toute dernière, pleine. La <b>récursivité</b> fonctionne pareil : une fonction résout un problème en s'appelant elle-même sur une version <b>plus petite</b> du même problème.</p>
<p>C'est une technique élégante pour tout ce qui est naturellement imbriqué : des dossiers dans des dossiers, des menus dans des menus, ou des calculs qui se définissent à partir d'eux-mêmes.</p></div>

<div class="theory-block"><h3>🛑 18.2 — Le cas de base : la condition d'arrêt</h3><div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="kw">def</span> compte_a_rebours(n):
    <span class="kw">if</span> n == <span class="num">0</span>:                      <span class="cmt"># cas de base : on s'arrête</span>
        <span class="fn">print</span>(<span class="str">"Décollage !"</span>)
    <span class="kw">else</span>:                           <span class="cmt"># cas récursif : on se rappelle</span>
        <span class="fn">print</span>(n)
        compte_a_rebours(n - <span class="num">1</span>)     <span class="cmt"># avec un problème plus petit</span>

compte_a_rebours(<span class="num">3</span>)                 <span class="cmt"># 3, 2, 1, Décollage !</span></div></div>
<p>Toute fonction récursive repose sur deux règles : un <b>cas de base</b> qui s'arrête sans se rappeler, et un <b>cas récursif</b> dont chaque appel se rapproche du cas de base. Ici, <code>n</code> diminue de 1 à chaque appel jusqu'à atteindre 0.</p>
<div class="tip"><b>Piège fréquent —</b> oublier le cas de base, ou ne jamais s'en rapprocher. Les appels s'empilent sans fin et Python finit par s'arrêter avec une <code>RecursionError</code> (la limite est d'environ 1000 appels imbriqués).</div></div>

<div class="theory-block"><h3>✖️ 18.3 — L'exemple classique : la factorielle</h3><p>La factorielle de 5, notée 5!, vaut 5 × 4 × 3 × 2 × 1 = 120. Remarque que 5! = 5 × 4! : le problème contient une version plus petite de lui-même.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="kw">def</span> factorielle(n):
    <span class="kw">if</span> n &lt;= <span class="num">1</span>:
        <span class="kw">return</span> <span class="num">1</span>                    <span class="cmt"># cas de base</span>
    <span class="kw">return</span> n * factorielle(n - <span class="num">1</span>)   <span class="cmt"># cas récursif</span></div></div>
<p>Voici ce qui se passe pour <code>factorielle(3)</code> : elle calcule <code>3 * factorielle(2)</code>, qui attend <code>2 * factorielle(1)</code>, qui vaut 1. Les résultats <b>remontent</b> ensuite : 2 * 1 = 2, puis 3 * 2 = 6. Chaque appel reste en attente du suivant : c'est la <b>pile d'appels</b>.</p></div>

<div class="theory-block"><h3>⚖️ 18.4 — Récursivité ou boucle ?</h3><p>Tout ce qui s'écrit avec la récursivité peut s'écrire avec une boucle. Pour un simple comptage, la boucle est plus directe et plus économe en mémoire. La récursivité brille quand la structure est elle-même imbriquée, comme un arbre de dossiers.</p>
<div class="tip"><b>À savoir —</b> la suite de Fibonacci s'écrit joliment de façon récursive (<code>fibo(n) = fibo(n-1) + fibo(n-2)</code>), mais la version naïve refait les mêmes calculs des milliers de fois et devient très lente. Élégant ne veut pas toujours dire efficace : c'est un bon sujet à explorer plus tard.</div></div>

</div></div>`,
 starter:`# Jour 18 : la recursivite
def compte_a_rebours(n):
    if n == 0:
        print("Decollage !")
    else:
        print(n)
        compte_a_rebours(n - 1)

def factorielle(n):
    if n <= 1:
        return 1
    return n * factorielle(n - 1)

def somme_jusqua(n):
    if n == 0:
        return 0
    return n + somme_jusqua(n - 1)

compte_a_rebours(3)
print("5! =", factorielle(5))
print("Somme de 1 a 10 :", somme_jusqua(10))`,
 quiz:[{"q": "Qu'est-ce que le cas de base d'une fonction récursive ?", "opts": ["La première ligne du programme", "La condition qui arrête les appels récursifs", "Le dernier appel de la fonction", "Un type de boucle"], "ans": 1}, {"q": "Que se passe-t-il si on oublie le cas de base ?", "opts": ["La fonction renvoie 0", "Python le corrige automatiquement", "Les appels s'enchaînent sans fin jusqu'à une RecursionError", "Rien : la fonction s'arrête seule"], "ans": 2}, {"q": "Que vaut factorielle(4) ?", "opts": ["10", "16", "24", "12"], "ans": 2}]},
{d:19, title:"Algorithmes classiques", sub:"recherche, tri et dichotomie", level:"hard",
 theory:`<div class="cell"><div class="cell-head"><span class="cell-tag">In [19]</span> Théorie — Chapitre 19</div><div class="cell-body">

<div class="theory-block"><h3>🧭 19.1 — Qu'est-ce qu'un algorithme ? La recherche linéaire</h3><p>Un <b>algorithme</b> est une recette : une suite d'étapes précises qui mène à un résultat. Le plus simple des algorithmes de recherche consiste à parcourir la liste case par case jusqu'à trouver la cible.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="kw">def</span> rechercher(liste, cible):
    <span class="kw">for</span> i <span class="kw">in</span> <span class="fn">range</span>(<span class="fn">len</span>(liste)):
        <span class="kw">if</span> liste[i] == cible:
            <span class="kw">return</span> i          <span class="cmt"># trouvé : on renvoie la position</span>
    <span class="kw">return</span> -<span class="num">1</span>                 <span class="cmt"># tout parcouru : la cible est absente</span></div></div>
<p>Par convention, on renvoie <code>-1</code> pour dire « introuvable », car aucune position valide ne peut être négative. Dans le pire des cas, la fonction compare la cible à <b>chaque</b> élément : pour 1000 éléments, 1000 comparaisons.</p></div>

<div class="theory-block"><h3>🫧 19.2 — Le tri à bulles : comparer les voisins</h3><p>Le principe : on parcourt la liste en comparant chaque élément à son voisin, et on les échange s'ils sont dans le mauvais ordre. Après une passe complète, le plus grand élément a « remonté » tout à la fin, comme une bulle. On recommence pour les éléments restants.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="kw">def</span> tri_a_bulles(liste):
    n = <span class="fn">len</span>(liste)
    <span class="kw">for</span> i <span class="kw">in</span> <span class="fn">range</span>(n):
        <span class="kw">for</span> j <span class="kw">in</span> <span class="fn">range</span>(n - i - <span class="num">1</span>):
            <span class="kw">if</span> liste[j] &gt; liste[j + <span class="num">1</span>]:
                temp = liste[j]              <span class="cmt"># échange via une variable</span>
                liste[j] = liste[j + <span class="num">1</span>]      <span class="cmt"># temporaire</span>
                liste[j + <span class="num">1</span>] = temp
    <span class="kw">return</span> liste</div></div>
<div class="tip"><b>À savoir —</b> Python sait aussi échanger en une ligne (<code>liste[j], liste[j + 1] = liste[j + 1], liste[j]</code>), mais la version avec variable temporaire est plus lisible et fonctionne dans le terminal de PYl@b NEXTCAMP. Et dans un vrai projet, tu utiliseras simplement <code>sorted(liste)</code> : le tri à bulles sert à comprendre, il est lent sur les grandes listes.</div></div>

<div class="theory-block"><h3>✂️ 19.3 — La dichotomie : couper en deux</h3><p>Sur une liste <b>déjà triée</b>, on peut faire bien mieux qu'un parcours complet. On regarde l'élément du milieu : s'il est trop petit, la cible ne peut se trouver que dans la moitié droite ; sinon dans la moitié gauche. À chaque tour, on écarte la moitié des candidats.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="kw">def</span> dichotomie(liste, cible):
    bas = <span class="num">0</span>
    haut = <span class="fn">len</span>(liste) - <span class="num">1</span>
    <span class="kw">while</span> bas &lt;= haut:
        milieu = <span class="fn">int</span>((bas + haut) / <span class="num">2</span>)
        <span class="kw">if</span> liste[milieu] == cible:
            <span class="kw">return</span> milieu
        <span class="kw">elif</span> liste[milieu] &lt; cible:
            bas = milieu + <span class="num">1</span>          <span class="cmt"># on garde la moitié droite</span>
        <span class="kw">else</span>:
            haut = milieu - <span class="num">1</span>         <span class="cmt"># on garde la moitié gauche</span>
    <span class="kw">return</span> -<span class="num">1</span></div></div>
<p>Dans un vrai Python, on écrirait souvent <code>(bas + haut) // 2</code> (division entière) ; ici <code>int(...)</code> donne le même résultat pour des nombres positifs.</p>
<div class="tip"><b>Piège fréquent —</b> appliquer la dichotomie sur une liste non triée. L'algorithme « élimine » alors des moitiés au hasard et peut passer à côté de la cible : il donne un résultat faux sans afficher la moindre erreur.</div></div>

<div class="theory-block"><h3>📈 19.4 — Choisir le bon algorithme</h3><p>Pour comparer des algorithmes, on se demande : <b>combien d'étapes si la liste devient 100 fois plus grande ?</b> La recherche linéaire fait 100 fois plus de travail. La dichotomie n'ajoute qu'environ 7 étapes : sur un million d'éléments, elle en demande une vingtaine seulement.</p>
<p>Le compromis : la dichotomie exige une liste triée, et trier a lui aussi un coût. Si tu cherches une seule fois dans une petite liste, le parcours simple suffit ; si tu cherches des milliers de fois dans une grosse liste, trier d'abord devient très rentable.</p></div>

</div></div>`,
 starter:`# Jour 19 : algorithmes classiques
def rechercher(liste, cible):
    for i in range(len(liste)):
        if liste[i] == cible:
            return i
    return -1

def tri_a_bulles(liste):
    n = len(liste)
    for i in range(n):
        for j in range(n - i - 1):
            if liste[j] > liste[j + 1]:
                temp = liste[j]
                liste[j] = liste[j + 1]
                liste[j + 1] = temp
    return liste

def dichotomie(liste, cible):
    bas = 0
    haut = len(liste) - 1
    while bas <= haut:
        milieu = int((bas + haut) / 2)
        if liste[milieu] == cible:
            return milieu
        elif liste[milieu] < cible:
            bas = milieu + 1
        else:
            haut = milieu - 1
    return -1

nombres = [42, 7, 19, 3, 25, 11]
print("Position de 19 :", rechercher(nombres, 19))
tries = tri_a_bulles(nombres)
print("Liste triee :", tries)
print("Position de 25 (dichotomie) :", dichotomie(tries, 25))`,
 quiz:[{"q": "Dans notre fonction rechercher(), que renvoie-t-on quand la cible est absente ?", "opts": ["0", "-1", "True", "La liste vide"], "ans": 1}, {"q": "Quelle condition est indispensable pour utiliser la dichotomie ?", "opts": ["La liste contient des textes", "La liste est déjà triée", "La liste a moins de 10 éléments", "La liste ne contient aucun doublon"], "ans": 1}, {"q": "Que fait une passe du tri à bulles ?", "opts": ["Elle mélange la liste", "Elle compare les voisins et les échange s'ils sont dans le mauvais ordre", "Elle supprime les doublons", "Elle cherche le milieu de la liste"], "ans": 1}]},
{d:20, title:"Projet final", sub:"le jeu du nombre mystère, de A à Z", level:"hard",
 theory:`<div class="cell"><div class="cell-head"><span class="cell-tag">In [20]</span> Théorie — Chapitre 20</div><div class="cell-body">

<div class="theory-block"><h3>🎯 20.1 — Le cahier des charges : le nombre mystère</h3><p>Pour clore le parcours, tu construis un jeu complet. L'ordinateur tire un nombre secret ; le joueur propose des nombres et reçoit un indice (« trop petit », « trop grand ») ; le nombre d'essais est limité et dépend du niveau choisi ; à la fin, on affiche le résultat et l'historique des propositions.</p>
<p>Ce projet mobilise presque tout ce que tu as appris : la saisie et la conversion (J2), les conditions (J3), les boucles <code>while</code> (J4), les listes (J5), les fonctions (J6 et J17), les dictionnaires (J8), la gestion d'erreurs (J9) et le hasard (J14).</p></div>

<div class="theory-block"><h3>🧠 20.2 — Découper en petites fonctions</h3><p>Deux fonctions suffisent à sortir le « sale boulot » de la boucle principale. La première demande un nombre <b>sans jamais faire planter le jeu</b> si le joueur tape des lettres ; la seconde regroupe tous les réglages d'un niveau dans un dictionnaire.</p>
<div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content"><span class="kw">def</span> demander_nombre(message):
    reponse = <span class="fn">input</span>(message)
    <span class="kw">try</span>:
        <span class="kw">return</span> <span class="fn">int</span>(reponse)
    <span class="kw">except</span>:
        <span class="kw">return</span> -<span class="num">1</span>                   <span class="cmt"># texte invalide : on renvoie -1</span>

<span class="kw">def</span> choisir_niveau():
    niveau = <span class="fn">input</span>(<span class="str">"Niveau (facile / moyen / difficile) : "</span>)
    <span class="kw">if</span> niveau == <span class="str">"difficile"</span>:
        <span class="kw">return</span> {<span class="str">"max"</span>: <span class="num">100</span>, <span class="str">"essais"</span>: <span class="num">5</span>}
    <span class="kw">elif</span> niveau == <span class="str">"moyen"</span>:
        <span class="kw">return</span> {<span class="str">"max"</span>: <span class="num">50</span>, <span class="str">"essais"</span>: <span class="num">7</span>}
    <span class="kw">else</span>:
        <span class="kw">return</span> {<span class="str">"max"</span>: <span class="num">20</span>, <span class="str">"essais"</span>: <span class="num">8</span>}</div></div>
<div class="tip"><b>Pourquoi un dictionnaire ?</b> Pour ajouter un niveau ou un réglage (le nombre de vies, par exemple), il suffit de modifier <code>choisir_niveau()</code> : la boucle principale n'a pas à changer.</div></div>

<div class="theory-block"><h3>🔄 20.3 — La boucle principale et son drapeau</h3><div class="code-block"><div class="code-header"><span class="code-lang">python</span></div><div class="code-content">gagne = <span class="kw">False</span>
<span class="kw">while</span> essais_restants &gt; <span class="num">0</span> <span class="kw">and</span> <span class="kw">not</span> gagne:
    proposition = demander_nombre(<span class="str">"Ta proposition : "</span>)
    historique.<span class="fn">append</span>(proposition)
    essais_restants -= <span class="num">1</span>
    <span class="kw">if</span> proposition == secret:
        gagne = <span class="kw">True</span>
    <span class="kw">elif</span> proposition &lt; secret:
        <span class="fn">print</span>(<span class="str">"Trop petit !"</span>)
    <span class="kw">else</span>:
        <span class="fn">print</span>(<span class="str">"Trop grand !"</span>)</div></div>
<p>La variable <code>gagne</code> est un <b>drapeau</b> : un booléen qui change d'état quand un événement se produit. La boucle tourne tant qu'il reste des essais <b>et</b> que le joueur n'a pas gagné ; dès que l'une des deux conditions tombe, elle s'arrête. Après la boucle, un simple <code>if gagne:</code> décide du message final.</p></div>

<div class="theory-block"><h3>🚀 20.4 — Aller plus loin, et la suite</h3><p>Une fois ton jeu fonctionnel, améliore-le sans regarder de correction : ajoute une boucle pour <b>rejouer</b>, mémorise le <b>meilleur score</b> dans un dictionnaire, affiche un indice « chaud / froid » en calculant l'écart entre la proposition et le secret, ou transforme le tout en classe <code>Jeu</code> comme au chapitre 13.</p>
<div class="tip-box"><strong>🎉 Bravo, tu termines le parcours Python !</strong>
<ul style="margin:8px 0 0 18px;line-height:1.7">
<li>En 20 jours, tu es parti de <code>print()</code> et de simples variables pour arriver aux classes, à la récursivité, aux algorithmes de recherche et de tri, et à un jeu complet.</li>
<li>Ces briques (fonctions, conditions, boucles, structures de données) sont celles de tous les programmes Python, des petits scripts aux grosses applications.</li>
<li>La suite logique : un projet personnel, même modeste. C'est en construisant quelque chose qui t'intéresse vraiment que ces notions s'ancrent durablement.</li>
<li>Pense aussi à explorer le parcours <b>JavaScript</b> ou <b>SQL</b> : avec le même compte, tu peux compléter tes compétences.</li>
</ul></div></div>

</div></div>`,
 starter:`# Jour 20 : projet final - le nombre mystere
import random

def demander_nombre(message):
    reponse = input(message)
    try:
        return int(reponse)
    except:
        return -1

def choisir_niveau():
    niveau = input("Niveau (facile / moyen / difficile) : ")
    if niveau == "difficile":
        return {"max": 100, "essais": 5}
    elif niveau == "moyen":
        return {"max": 50, "essais": 7}
    else:
        return {"max": 20, "essais": 8}

reglages = choisir_niveau()
secret = random.randint(1, reglages["max"])
essais_restants = reglages["essais"]
historique = []

print(f"Devine le nombre entre 1 et {reglages['max']} ({essais_restants} essais)")

gagne = False
while essais_restants > 0 and not gagne:
    proposition = demander_nombre("Ta proposition : ")
    historique.append(proposition)
    essais_restants -= 1
    if proposition == secret:
        gagne = True
    elif proposition < secret:
        print("Trop petit !")
    else:
        print("Trop grand !")

if gagne:
    print(f"Bravo ! Trouve en {len(historique)} essai(s).")
else:
    print(f"Perdu ! Le nombre etait {secret}.")
print("Historique :", historique)`,
 quiz:[{"q": "Pourquoi entourer int(reponse) d'un try / except ?", "opts": ["Pour accélérer le programme", "Pour éviter que le jeu plante si le joueur tape autre chose qu'un nombre", "Pour afficher un message d'erreur en rouge", "Ce n'est pas nécessaire"], "ans": 1}, {"q": "La boucle while essais_restants > 0 and not gagne: s'arrête quand…", "opts": ["il reste encore des essais", "le joueur a gagné OU qu'il n'y a plus d'essais", "le joueur a gagné ET qu'il n'y a plus d'essais", "jamais"], "ans": 1}, {"q": "Pourquoi regrouper les réglages dans la fonction choisir_niveau() ?", "opts": ["Pour les centraliser à un seul endroit facile à modifier", "Pour rendre le programme plus long", "Pour éviter d'utiliser des dictionnaires", "Pour remplacer la boucle principale"], "ans": 0}]}
]}
];
