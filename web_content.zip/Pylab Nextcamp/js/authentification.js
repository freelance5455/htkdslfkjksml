/* ========================= AUTH ========================= */
let currentUser = null;
let currentTrack = 'python';
let completedDays = new Set();
let currentDay = 1;
let editorCodes = {};
let sqlExo = {};   // parcours SQL : exercices validés {jour:true}
let sqlChk = {};   // parcours SQL : étapes cochées {jour:[bool]}

function offerExpiry(offer){ const d=new Date(); d.setDate(d.getDate()+(offer==='annuel'?366:31)); return d.toISOString(); }
function hasActiveOffer(u){ return !!(u && u.offre && (!u.offreExpire || new Date(u.offreExpire) > new Date())); }
async function hashPassword(pw){
  const enc = new TextEncoder().encode(pw);
  const buf = await crypto.subtle.digest('SHA-256', enc);
  return Array.from(new Uint8Array(buf)).map(b=>b.toString(16).padStart(2,'0')).join('');
}
function showAuthError(msg){ const el=document.getElementById('auth-error'); el.textContent=msg; el.style.display=msg?'block':'none'; }
function switchAuthTab(tab){
  document.getElementById('tab-login-btn').classList.toggle('active', tab==='login');
  document.getElementById('tab-register-btn').classList.toggle('active', tab==='register');
  document.getElementById('panel-login').classList.toggle('active', tab==='login');
  document.getElementById('panel-register').classList.toggle('active', tab==='register');
  showAuthError('');
}
function scrollToAuth(tab){ switchAuthTab(tab); document.getElementById('auth-anchor').scrollIntoView({behavior:'smooth'}); }

async function handleRegister(ev){
  ev.preventDefault(); showAuthError('');
  const nom = document.getElementById('reg-nom').value.trim();
  const email = document.getElementById('reg-email').value.trim().toLowerCase();
  const pw = document.getElementById('reg-pw').value;
  const pw2 = document.getElementById('reg-pw2').value;
  const niveau = document.getElementById('reg-niveau').value;
  if(!nom||!email||!pw){ showAuthError('Merci de remplir tous les champs.'); return; }
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){ showAuthError('Adresse email invalide.'); return; }
  if(pw.length<8){ showAuthError('Le mot de passe doit contenir au moins 8 caractères.'); return; }
  if(pw!==pw2){ showAuthError('Les mots de passe ne correspondent pas.'); return; }
  if(!document.getElementById('reg-cgu').checked){ showAuthError('Tu dois accepter les Conditions générales et la Politique de confidentialité.'); return; }
  const btn=document.getElementById('reg-submit'); btn.disabled=true; btn.textContent='Création en cours...';
  let data, error;
  try{
    ({ data, error } = await supabaseClient.auth.signUp({
      email, password: pw,
      options:{ data:{ full_name: nom, niveau }, emailRedirectTo: window.location.origin + window.location.pathname }
    }));
  }catch(e){ error = e; }
  btn.disabled=false; btn.textContent="Créer mon compte >>>";
  if(error){ showAuthError(traduireErreurAuth(error)); return; }
  const authUser = data && data.user;
  /* Supabase ne renvoie pas d'erreur si l'e-mail existe déjà (anti-énumération) : identities est alors vide */
  if(authUser && Array.isArray(authUser.identities) && authUser.identities.length===0){
    switchAuthTab('login');
    showAuthError('Un compte existe déjà avec cet email. Connecte-toi (ou confirme ton e-mail si ce n\'est pas déjà fait).');
    return;
  }
  if(authUser && !data.session){
    /* Confirmation par e-mail activée : pas encore de session, le profil est créé côté base par un trigger */
    switchAuthTab('login');
    showAuthError('Compte créé ! Vérifie ta boîte mail et clique sur le lien de confirmation, puis connecte-toi.');
    return;
  }
  if(authUser){
    await supabaseClient.from('profiles').upsert({ id: authUser.id, email, full_name: nom });
  }
  const user = { id: authUser ? authUser.id : null, nom, email, niveau, dateInscription:new Date().toISOString() };
  await enterApp(user, `Identité confirmée — bienvenue ${nom} !`);
}
async function handleLogin(ev){
  ev.preventDefault(); showAuthError('');
  const email = document.getElementById('login-email').value.trim().toLowerCase();
  const pw = document.getElementById('login-pw').value;
  if(!email||!pw){ showAuthError('Merci de remplir tous les champs.'); return; }
  const btn=document.getElementById('login-submit'); btn.disabled=true; btn.textContent='Vérification...';
  let user = null;
  try{
    const { data, error } = await supabaseClient.auth.signInWithPassword({ email, password: pw });
    if(error){ showAuthError(traduireErreurAuth(error)); return; }
    user = await chargerProfilDepuisSupabase(data.user);
  }catch(e){
    showAuthError(traduireErreurAuth(e));
    return;
  }finally{
    btn.disabled=false; btn.textContent="Se connecter >>>";
  }
  await enterApp(user, `Identité confirmée — content de te revoir, ${user.nom} !`);
}
async function signInWithGoogle(){
  showAuthError('');
  const btn = document.getElementById('google-btn'); if(btn) btn.disabled = true;
  const { error } = await supabaseClient.auth.signInWithOAuth({
    provider: 'google',
    options: { redirectTo: window.location.origin + window.location.pathname }
  });
  if(error){
    if(btn) btn.disabled = false;
    showAuthError(/provider is not enabled|unsupported provider/i.test(error.message||'')
      ? "La connexion Google n'est pas encore activée. Utilise ton e-mail pour l'instant."
      : (error.message || 'Connexion Google impossible.'));
  }
}
async function handleLogout(){
  await supabaseClient.auth.signOut();
  currentUser=null;
  pendingLangue=null;
  viewHistory=['landingView'];
  hideAllViews();
  document.getElementById('landingView').style.display='';
  document.getElementById('nav-user').style.display='none';
  document.getElementById('nav-guest').style.display='';
  window.scrollTo(0,0);
}
function traduireErreurAuth(error){
  const msg = (error && error.message) || '';
  if(/already registered/i.test(msg)) return 'Un compte existe déjà avec cet email.';
  if(/invalid login credentials/i.test(msg)) return 'Email ou mot de passe incorrect.';
  if(/password/i.test(msg) && /short|6 characters/i.test(msg)) return 'Le mot de passe doit contenir au moins 8 caractères.';
  if(/email not confirmed/i.test(msg)) return "Ton adresse e-mail n'est pas encore confirmée. Clique sur le lien reçu par mail (regarde aussi dans les spams), puis reconnecte-toi.";
  if(/rate limit|too many requests|security purposes/i.test(msg)) return 'Trop de tentatives. Patiente quelques minutes avant de réessayer.';
  if(/error sending (confirmation|email)|unable to send|email address not authorized/i.test(msg)) return "Impossible d'envoyer l'e-mail de confirmation pour le moment. Réessaie dans quelques minutes.";
  if(/weak|pwned|easy to guess/i.test(msg)) return 'Ce mot de passe est trop simple. Choisis-en un plus robuste.';
  if(/invalid.*email|email.*invalid/i.test(msg)) return 'Adresse email invalide.';
  if(/signups? not allowed|signup is disabled/i.test(msg)) return "Les inscriptions sont momentanément désactivées.";
  if(/failed to fetch|networkerror|load failed/i.test(msg)) return 'Connexion impossible. Vérifie ta connexion internet et réessaie.';
  return msg || 'Une erreur est survenue, réessaie.';
}
/* Reconstruit l'objet "user" utilisé par le reste de l'app à partir du profil Supabase + de l'abonnement actif */
async function chargerProfilDepuisSupabase(authUser){
  let { data: profile } = await supabaseClient.from('profiles').select('*').eq('id', authUser.id).maybeSingle();
  if(!profile){
    const full_name = (authUser.user_metadata && authUser.user_metadata.full_name) || authUser.email.split('@')[0];
    await supabaseClient.from('profiles').upsert({ id: authUser.id, email: authUser.email, full_name });
    profile = { id: authUser.id, email: authUser.email, full_name, created_at: new Date().toISOString() };
  }
  const { data: sub } = await supabaseClient
    .from('subscriptions').select('*').eq('user_id', authUser.id).eq('status','active')
    .order('ends_at', { ascending:false }).limit(1).maybeSingle();
  const user = {
    id: authUser.id,
    nom: profile.full_name,
    email: profile.email,
    niveau: (authUser.user_metadata && authUser.user_metadata.niveau) || 'debutant',
    dateInscription: profile.created_at,
  };
  if(sub){
    user.offre = sub.plan;
    user.offreExpire = sub.ends_at;
    user.langue = sub.plan_track || null;
  }
  return user;
}
async function trackIdBySlug(slug){
  if(!window._pylabTrackIds){
    const { data } = await supabaseClient.from('tracks').select('id,slug');
    window._pylabTrackIds = Object.fromEntries((data||[]).map(t=>[t.slug, t.id]));
  }
  return window._pylabTrackIds[slug];
}
async function loadTrackProgress(track){
  const slug = track==='js' ? 'javascript' : track;
  const trackId = await trackIdBySlug(slug);
  let prog = {completedDays:[],currentDay:1,editorCodes:{},sqlExo:{},sqlChk:{}};
  if(trackId && currentUser && currentUser.id){
    const { data } = await supabaseClient.from('progress').select('*')
      .eq('user_id', currentUser.id).eq('track_id', trackId).maybeSingle();
    if(data){
      prog = {
        completedDays: data.completed_days || [],
        currentDay: data.current_day || 1,
        editorCodes: (data.extra && data.extra.editorCodes) || {},
        sqlExo: (data.extra && data.extra.sqlExo) || {},
        sqlChk: (data.extra && data.extra.sqlChk) || {},
      };
    }
  }
  completedDays = new Set(prog.completedDays);
  currentDay = prog.currentDay || 1;
  editorCodes = prog.editorCodes || {};
  sqlExo = prog.sqlExo || {};
  sqlChk = prog.sqlChk || {};
}
/* ---- Interfaces 2 & 3 : tunnel langage + tarif (affiché une fois, après la 1ere connexion) ---- */
let pendingLangue = null;
function hideAllViews(){
  document.getElementById('landingView').style.display='none';
  document.getElementById('langView').style.display='none';
  document.getElementById('pricingView').style.display='none';
  document.getElementById('appView').style.display='none';
  document.getElementById('privacyView').style.display='none';
  document.getElementById('termsView').style.display='none';
}
/* Navigation generique "retour" entre les vues d'accueil/tunnel/pages legales */
let viewHistory = ['landingView'];
function navigateTo(id){
  viewHistory.push(id);
  hideAllViews();
  document.getElementById(id).style.display = (id==='landingView' ? '' : 'block');
  window.scrollTo(0,0);
}
function goBack(){
  if(viewHistory.length > 1) viewHistory.pop();
  const prev = viewHistory[viewHistory.length-1] || 'landingView';
  hideAllViews();
  document.getElementById(prev).style.display = (prev==='landingView' ? '' : 'block');
  window.scrollTo(0,0);
}
function showLegalView(which){
  navigateTo(which+'View');
}
function showLangView(){
  navigateTo('langView');
}
function selectLanguage(lang){
  pendingLangue = lang;
  navigateTo('pricingView');
}
