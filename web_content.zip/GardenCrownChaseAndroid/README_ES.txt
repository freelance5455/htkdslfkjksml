GARDEN CROWN CHASE — PROYECTO ANDROID V0.5.0

Este proyecto envuelve el juego HTML en una aplicación Android nativa con WebView.
Nombre: Garden Crown Chase
Paquete: com.gardencrownchase.app
Versión: 0.5.0
Modo: horizontal y sin conexión

CÓMO GENERAR LA APK
1. Descomprime este ZIP en un ordenador.
2. Instala Android Studio actualizado.
3. Abre Android Studio y elige Open / Abrir; selecciona la carpeta GardenCrownChaseAndroid.
4. Acepta la sincronización de Gradle e instala el SDK Android 35 si lo solicita.
5. Ve a Build > Build Bundle(s) / APK(s) > Build APK(s).
6. La APK de depuración aparecerá normalmente en app/build/outputs/apk/debug/app-debug.apk.

FUNCIONES PREPARADAS
- Juego HTML incluido en app/src/main/assets/index.html; no necesita conexión.
- Nombre e icono propios.
- Orientación horizontal e interfaz inmersiva.
- Selector de archivos Android para cargar niveles HTML.
- Selector de destino Android para guardar/exportar niveles HTML.

NOTA
Este entorno no dispone de Gradle ni del Android SDK instalados, por lo que aquí se entrega el proyecto Android preparado, no una APK compilada y probada. Es necesario compilarlo con Android Studio o con un entorno que tenga Android SDK/Gradle.
