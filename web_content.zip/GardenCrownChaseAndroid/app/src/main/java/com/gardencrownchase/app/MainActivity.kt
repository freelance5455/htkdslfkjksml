package com.gardencrownchase.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import java.io.OutputStream

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private var pendingExportHtml: String? = null
    private var pendingExportName: String = "nivel-garden-crown-chase.html"

    companion object {
        private const val FILE_CHOOSER_REQUEST = 701
        private const val CREATE_FILE_REQUEST = 702
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            android.view.View.SYSTEM_UI_FLAG_FULLSCREEN or
            android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        )

        webView = WebView(this)
        setContentView(webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.settings.setSupportZoom(false)
        webView.addJavascriptInterface(AndroidBridge(), "AndroidBridge")
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.fileChooserCallback?.onReceiveValue(null)
                this@MainActivity.fileChooserCallback = filePathCallback
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "text/html"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("text/html", "application/xhtml+xml", "application/octet-stream"))
                }
                return try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST)
                    true
                } catch (_: Exception) {
                    this@MainActivity.fileChooserCallback?.onReceiveValue(null)
                    this@MainActivity.fileChooserCallback = null
                    Toast.makeText(this@MainActivity, "No se pudo abrir el selector de archivos", Toast.LENGTH_LONG).show()
                    false
                }
            }
        }
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = false
        }
        webView.loadUrl("file:///android_asset/index.html")
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun saveLevel(html: String, fileName: String) {
            runOnUiThread {
                pendingExportHtml = html
                pendingExportName = fileName.ifBlank { "nivel-garden-crown-chase.html" }
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "text/html"
                    putExtra(Intent.EXTRA_TITLE, pendingExportName)
                }
                try {
                    startActivityForResult(intent, CREATE_FILE_REQUEST)
                } catch (_: Exception) {
                    pendingExportHtml = null
                    Toast.makeText(this@MainActivity, "No se pudo abrir el selector para guardar", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    @Deprecated("Deprecated by Android, retained for compatibility with file chooser")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == FILE_CHOOSER_REQUEST) {
            val result = if (resultCode == RESULT_OK && data?.data != null) arrayOf(data.data!!) else null
            fileChooserCallback?.onReceiveValue(result)
            fileChooserCallback = null
        } else if (requestCode == CREATE_FILE_REQUEST) {
            val uri = if (resultCode == RESULT_OK) data?.data else null
            val html = pendingExportHtml
            pendingExportHtml = null
            if (uri != null && html != null) {
                try {
                    contentResolver.openOutputStream(uri)?.use { out: OutputStream -> out.write(html.toByteArray(Charsets.UTF_8)) }
                    Toast.makeText(this, "Nivel guardado correctamente", Toast.LENGTH_LONG).show()
                } catch (_: Exception) {
                    Toast.makeText(this, "No se pudo guardar el nivel", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onBackPressed() {
        webView.evaluateJavascript("(function(){var b=document.getElementById('pause-btn'); if(b){b.click(); return 'pause';} return 'back';})()", null)
    }
}
