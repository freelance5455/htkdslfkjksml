# Global Sound 3000+ — upgraded starter

## Included
- Mobile-first Global Sound frontend based on the supplied HTML.
- Supabase email/password signup, login and logout.
- Local Android audio import/player and approved public track playback using signed URLs.
- Community posts using the existing `posts` table and RLS.
- Artist profile requests and private audio submissions pending moderation.
- G.S Coins balance read from the append-only `coin_ledger` (the browser cannot mint coins).
- Premium preview; real payments are intentionally not enabled.
- Authenticated server-side Global Sound Intelligence endpoint. The AI key stays in server environment variables.

## Deploy / connect
1. Upload `frontend/index.html`, `server.js`, `package.json`, and `.env.example` into your repository, preserving the `frontend/` folder.
2. In the repository root, install dependencies and deploy with `npm start` on Node.js 20+.
3. Set server environment variables from `.env.example`. Add your real `OPENAI_API_KEY` only in your hosting provider's secret/environment settings, never in GitHub or HTML.
4. Set `FRONTEND_ORIGIN` to the exact HTTPS URL where the app is hosted.
5. Open the app, choose Profile → Connect Supabase, and enter the project URL plus the publishable/anon key. Do not use the service_role key.
6. In Supabase Auth, set the deployed site URL and enable email/password. Run the repository SQL migrations `001_initial_schema.sql` and `002_live_mvp.sql` if not already applied.
7. Test signup, email confirmation, login, Community posts, Artist profile submission, and private audio upload.

## Important limits
- New artist profiles and tracks remain pending until an administrator verifies/approves them. This protects the public catalogue.
- Real broadcasting, payments, subscriptions, withdrawals, licensed catalogue ingestion and Android APK packaging are not implemented by this starter.
- Coin balance is read-only from the secure ledger. Add credits only through a trusted server/admin workflow.
- Browser local audio imports stay on the device and are not cloud uploads.
