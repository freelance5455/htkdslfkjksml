ANDROID APK BUILD INSTRUCTIONS

This is the Android source/build package, not a precompiled APK. A build machine needs Node.js 20+, Android Studio, Android SDK, and a JDK supported by the installed Android Gradle Plugin.

1. Extract this ZIP to a writable folder.
2. Open a terminal in the extracted folder.
3. Run: npm install
4. Run: npx cap add android
   (If an android/ folder already exists, skip this step.)
5. Run: npx cap sync android
6. Run: npx cap open android
7. In Android Studio, allow Gradle/SDK setup to finish. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
8. Android Studio shows the generated APK location, normally android/app/build/outputs/apk/debug/app-debug.apk.

For a distributable signed release APK/AAB, configure your own signing key in Android Studio. Do not share your private signing key.

The ZIP cannot contain a ready-made APK because Android SDK/Gradle build tooling and signing credentials are not present in this package environment.
