CONVERSION FEEDS LTD. | INTRACO

This package includes the complete HTML app and its supplied logo.
Open www/index.html in a modern browser for a direct web preview.
The platform-specific README explains how to build an installable package.

The app stores saved calculations and editable prices in local browser/app storage.
Keep app data on the same device; browser storage may be cleared by device settings.
