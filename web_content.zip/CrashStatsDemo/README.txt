CRASH STATS — READY DEMO PROJECT

What it does:
- Stores completed multiplier rounds on the device/browser.
- Shows rounds, average, highest and lowest.
- Shows a simple historical risk meter.
- Works offline after opening the files.

Important:
This is a statistics/practice app. It does NOT predict or guarantee the next crash point and should not be used as a guaranteed winning system.

Quick start:
1. Extract the ZIP.
2. Open index.html in Chrome.
3. Add completed round multipliers such as 1.42, 2.35, 5.10.
4. Your data is stored locally on that device/browser.

To turn this into a native Android APK, the project needs to be wrapped with an Android build tool such as Capacitor or Android Studio.
