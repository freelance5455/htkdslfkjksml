const KEY="crash_stats_rounds";
let rounds=JSON.parse(localStorage.getItem(KEY)||"[]");

const $=id=>document.getElementById(id);
function save(){localStorage.setItem(KEY,JSON.stringify(rounds)); render();}
function add(){
  const n=parseFloat($("multiplier").value);
  if(!Number.isFinite(n)||n<1){alert("Enter a valid multiplier (1.00 or higher).");return}
  rounds.unshift(Math.round(n*100)/100);
  rounds=rounds.slice(0,200);
  $("multiplier").value="";
  save();
}
function render(){
  const c=rounds.length;
  $("count").textContent=c;
  if(!c){$("avg").textContent="0.00x";$("high").textContent="0.00x";$("low").textContent="0.00x";$("risk").textContent="No data";$("riskText").textContent="Add at least a few completed rounds to see basic statistics.";$("meterBar").style.width="0%";$("history").innerHTML='<p class="muted">No rounds yet.</p>';return}
  const avg=rounds.reduce((a,b)=>a+b,0)/c;
  $("avg").textContent=avg.toFixed(2)+"x";
  $("high").textContent=Math.max(...rounds).toFixed(2)+"x";
  $("low").textContent=Math.min(...rounds).toFixed(2)+"x";
  const lowCount=rounds.filter(x=>x<2).length;
  const lowRate=lowCount/c;
  const score=Math.round(lowRate*100);
  let label="Low"; if(score>=65)label="High"; else if(score>=40)label="Medium";
  $("risk").textContent=label;
  $("meterBar").style.width=score+"%";
  $("riskText").textContent=`Historical low-round rate (<2x): ${score}%. This is a statistic, not a prediction of the next round.`;
  $("history").innerHTML=rounds.slice(0,40).map((x,i)=>`<span class="pill">#${c-i} · ${x.toFixed(2)}x</span>`).join("");
}
$("addBtn").onclick=add;
$("multiplier").addEventListener("keydown",e=>{if(e.key==="Enter")add()});
$("clearBtn").onclick=()=>{if(confirm("Clear all saved rounds?")){rounds=[];save()}};
render();
