KURODECK PARA TABLETS Y TELEFONOS ANDROID (.APK)
================================================

ESTE ZIP INCLUYE EL PROYECTO COMPLETO PARA CUALQUIER METODO:

1. Android Studio (Recomendado para compilar .APK):
   - Extrae este ZIP completo.
   - Abre Android Studio -> "Open" -> selecciona la carpeta "android/".
   - Espera a que sincronice Gradle y haz clic en:
     Build -> Build Bundle(s) / APK(s) -> Build APK(s).
   - Incluye AndroidManifest.xml, MainActivity.java (con selector de ROMs,
     pantalla completa y soporte Bluetooth/USB OTG Xbox, PS4 y PS3),
     build.gradle e iconos ic_launcher.png.

2. Conversores Web-to-APK / Cordova / VoltBuilder / Capacitor:
   - Incluye index.html, manifest.json, config.xml, capacitor.config.json,
     carpeta www/ completa e iconos PNG de 192px y 512px.

3. Instalacion directa sin compilar (PWA):
   - Abre KuroDeck en Chrome en tu telefono o tablet Android y toca "Instalar App".
