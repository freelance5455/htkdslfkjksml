# Robert Le Boss · Studio Vidéo IA

Application web installable (PWA) qui crée des vidéos verticales 9:16 gratuitement :
scénario IA → images IA → voix off IA → musique et bruitages → montage → vidéo MP4 à télécharger.

Tout le montage se fait dans le navigateur de ton téléphone. Aucun serveur à payer.

## Publier gratuitement depuis Android (GitHub Pages)

1. Crée un compte sur github.com, puis **New repository** (nom : `robert-studio`, visibilité **Public**).
2. Dans le dépôt : **Add file → Upload files**. Envoie **tous** les fichiers de ce dossier, en gardant le dossier `assets/` :
   `index.html`, `manifest.webmanifest`, `sw.js`, `assets/` (4 images).
   Astuce Android : dézippe d'abord le fichier avec l'application *Fichiers*, puis envoie les fichiers depuis le navigateur en mode « Site pour ordinateur ».
3. **Commit changes**.
4. **Settings → Pages → Source : Deploy from a branch → Branch : main / (root) → Save**.
5. Après 1 à 2 minutes, ton application est en ligne à `https://TON-PSEUDO.github.io/robert-studio/`.
6. Ouvre ce lien dans Chrome → menu ⋮ → **Installer l'application**.

## Utilisation

1. Écris ton idée, puis **Écrire le scénario avec l'IA** (ou **Charger l'exemple**).
2. Relis les textes, modifie les descriptions d'images si besoin.
3. **Générer toutes les images** (une par scène, environ 10 à 30 s chacune).
4. Choisis la voix, la musique, la qualité, puis **Créer la vidéo**.
5. Garde l'écran allumé pendant le montage (la durée de la vidéo = durée du montage).
6. **Télécharger** ou **Partager** vers YouTube, WhatsApp, TikTok.

Tu peux aussi importer tes propres photos dans une scène avec le bouton 📁.

## Services gratuits utilisés

| Besoin | Service | Clé |
|---|---|---|
| Scénario | text.pollinations.ai | aucune |
| Images | image.pollinations.ai | aucune |
| Voix off | text.pollinations.ai (openai-audio) | aucune |
| Musique, bruitages, montage | dans le navigateur | aucune |

Si un service change d'adresse ou demande une clé, modifie-le dans **Réglages avancés** de l'application, sans toucher au code.

## Limites à connaître

- Ce n'est pas de la « vraie » génération vidéo : chaque scène est une image IA animée (zoom, déplacement, fondu) avec texte et voix. Les générateurs vidéo complets (Veo, Kling, Runway, Sora) ne sont pas gratuits en illimité.
- Qualité maximale : 1080 × 1920 (Full HD). La 4K n'est pas réaliste dans un navigateur de téléphone.
- Les services gratuits peuvent être lents ou occupés aux heures de pointe : l'application réessaie automatiquement.
- La cohérence des personnages dépend du texte « Style et personnages » : décris-les précisément et garde-le identique.
- Sur iPhone/Safari, l'enregistrement vidéo est moins fiable : utilise Chrome sur Android ou ordinateur.
