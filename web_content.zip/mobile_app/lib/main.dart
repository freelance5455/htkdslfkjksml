import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;

const _store = FlutterSecureStorage();

class Api {
  static String base = '';
  static String token = '';
  static Future<dynamic> get(String action) async {
    final r = await http.get(Uri.parse('$base/api/data.php?action=$action'),
        headers: {'X-Auth-Token': token}).timeout(const Duration(seconds: 15));
    final d = jsonDecode(r.body);
    if (r.statusCode != 200) throw (d is Map ? d['error'] : 'error') ?? 'error';
    return d;
  }
  static Future<void> login(String url, String email, String pass) async {
    base = url.trim().replaceAll(RegExp(r'/+$'), '');
    final r = await http.post(Uri.parse('$base/api/login.php'),
        body: jsonEncode({'email': email.trim(), 'password': pass})).timeout(const Duration(seconds: 15));
    final d = jsonDecode(r.body);
    if (r.statusCode != 200) throw d['error'] ?? 'error';
    token = d['token'];
    await _store.write(key: 'base', value: base);
    await _store.write(key: 'token', value: token);
  }
}

void main() => runApp(const App());

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext c) => MaterialApp(
        title: 'Ahmadi WiFi',
        locale: const Locale('ps'),
        supportedLocales: const [Locale('ps'), Locale('en')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate
        ],
        builder: (c, w) => Directionality(textDirection: TextDirection.rtl, child: w!),
        theme: ThemeData(colorSchemeSeed: Colors.indigo, useMaterial3: true),
        home: const Boot(),
      );
}

class Boot extends StatefulWidget {
  const Boot({super.key});
  @override
  State<Boot> createState() => _BootState();
}

class _BootState extends State<Boot> {
  Widget? page;
  @override
  void initState() {
    super.initState();
    () async {
      Api.base = await _store.read(key: 'base') ?? '';
      Api.token = await _store.read(key: 'token') ?? '';
      setState(() => page = Api.token.isEmpty ? const Login() : const Home());
    }();
  }
  @override
  Widget build(BuildContext c) => page ?? const Scaffold(body: Center(child: CircularProgressIndicator()));
}

class Login extends StatefulWidget {
  const Login({super.key});
  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  final url = TextEditingController(text: 'https://');
  final email = TextEditingController();
  final pass = TextEditingController();
  String err = '';
  bool busy = false;
  Future<void> go() async {
    setState(() { busy = true; err = ''; });
    try {
      await Api.login(url.text, email.text, pass.text);
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const Home()));
    } catch (e) {
      setState(() => err = e == 'invalid_credentials' ? 'ایمیل یا پاسورډ ناسم دی' : 'اتصال ونه شو');
    }
    setState(() => busy = false);
  }
  @override
  Widget build(BuildContext c) => Scaffold(
        body: SafeArea(
          child: ListView(padding: const EdgeInsets.all(24), children: [
            const SizedBox(height: 40),
            const Icon(Icons.wifi, size: 72),
            const Center(child: Text('احمدي WiFi', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold))),
            const SizedBox(height: 24),
            TextField(controller: url, keyboardType: TextInputType.url, textDirection: TextDirection.ltr,
                decoration: const InputDecoration(labelText: 'د سرور آدرس (HTTPS)', border: OutlineInputBorder())),
            const SizedBox(height: 12),
            TextField(controller: email, keyboardType: TextInputType.emailAddress, textDirection: TextDirection.ltr,
                decoration: const InputDecoration(labelText: 'ایمیل', border: OutlineInputBorder())),
            const SizedBox(height: 12),
            TextField(controller: pass, obscureText: true,
                decoration: const InputDecoration(labelText: 'پاسورډ', border: OutlineInputBorder())),
            if (err.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 12), child: Text(err, style: const TextStyle(color: Colors.red))),
            const SizedBox(height: 20),
            FilledButton(onPressed: busy ? null : go, child: Text(busy ? '...' : 'ننوتل')),
          ]),
        ),
      );
}

class Home extends StatelessWidget {
  const Home({super.key});
  @override
  Widget build(BuildContext c) => DefaultTabController(
        length: 4,
        child: Scaffold(
          appBar: AppBar(
            title: const Text('احمدي WiFi'),
            actions: [
              IconButton(
                icon: const Icon(Icons.logout),
                onPressed: () async {
                  await _store.deleteAll();
                  Api.token = '';
                  if (c.mounted) Navigator.pushReplacement(c, MaterialPageRoute(builder: (_) => const Login()));
                },
              )
            ],
            bottom: const TabBar(isScrollable: true, tabs: [
              Tab(text: 'ډشبورډ'), Tab(text: 'Hotspot'), Tab(text: 'PPPoE'), Tab(text: 'مشتریان')
            ]),
          ),
          body: const TabBarView(children: [
            Summary(),
            ListTab(action: 'hotspot', title: 'user', sub: ['address', 'uptime']),
            ListTab(action: 'pppoe', title: 'user', sub: ['address', 'uptime']),
            ListTab(action: 'customers', title: 'full_name', sub: ['username', 'package', 'status']),
          ]),
        ),
      );
}

class Loader extends StatefulWidget {
  final String action;
  final Widget Function(dynamic) builder;
  const Loader(this.action, this.builder, {super.key});
  @override
  State<Loader> createState() => _LoaderState();
}

class _LoaderState extends State<Loader> with AutomaticKeepAliveClientMixin {
  late Future<dynamic> f = Api.get(widget.action);
  @override
  bool get wantKeepAlive => true;
  @override
  Widget build(BuildContext c) {
    super.build(c);
    return RefreshIndicator(
      onRefresh: () async { setState(() => f = Api.get(widget.action)); await f.catchError((_) => null); },
      child: FutureBuilder(
        future: f,
        builder: (c, s) {
          if (s.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
          if (s.hasError) {
            final m = s.error == 'router_not_configured' ? 'لومړی د ویب پینل کې MikroTik تنظیم کړئ'
                : s.error == 'router_unreachable' ? 'روټر ته اتصال ونه شو' : 'تېروتنه';
            return ListView(children: [Padding(padding: const EdgeInsets.all(32), child: Center(child: Text(m)))]);
          }
          return widget.builder(s.data);
        },
      ),
    );
  }
}

class Summary extends StatelessWidget {
  const Summary({super.key});
  @override
  Widget build(BuildContext c) => Loader('summary', (d) {
        final r = d['resource'] as Map;
        Widget card(String t, String v, IconData i) =>
            Card(child: ListTile(leading: Icon(i), title: Text(t), trailing: Text(v, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold))));
        return ListView(padding: const EdgeInsets.all(12), children: [
          card('روټر', '${d['identity']}', Icons.router),
          card('Hotspot فعال', '${d['hotspot_active']}', Icons.wifi),
          card('PPPoE فعال', '${d['pppoe_active']}', Icons.cable),
          card('ټول مشتریان', '${d['customers']}', Icons.people),
          card('Uptime', '${r['uptime'] ?? '-'}', Icons.timer),
          card('CPU', '${r['cpu-load'] ?? '-'}%', Icons.memory),
        ]);
      });
}

class ListTab extends StatelessWidget {
  final String action, title;
  final List<String> sub;
  const ListTab({super.key, required this.action, required this.title, required this.sub});
  @override
  Widget build(BuildContext c) => Loader(action, (d) {
        final list = d as List;
        if (list.isEmpty) return ListView(children: const [Padding(padding: EdgeInsets.all(32), child: Center(child: Text('هېڅ ونه موندل شو')))]);
        return ListView.separated(
          itemCount: list.length,
          separatorBuilder: (_, __) => const Divider(height: 1),
          itemBuilder: (_, i) => ListTile(
            title: Text('${list[i][title] ?? ''}'),
            subtitle: Text(sub.map((k) => '${list[i][k] ?? ''}').where((x) => x.isNotEmpty).join(' • ')),
          ),
        );
      });
}
