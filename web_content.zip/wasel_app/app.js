const $=id=>document.getElementById(id);
const read=(key,fallback)=>{try{return JSON.parse(localStorage.getItem(key))??fallback}catch{return fallback}};
let tasks=read('wasel_tasks',[]),notes=read('wasel_notes',[]),filter='all';
const save=()=>{localStorage.setItem('wasel_tasks',JSON.stringify(tasks));localStorage.setItem('wasel_notes',JSON.stringify(notes));render()};
const toast=msg=>{const el=$('toast');el.textContent=msg;el.classList.add('show');setTimeout(()=>el.classList.remove('show'),1800)};
$('todayLabel').textContent=new Intl.DateTimeFormat('ar-EG',{weekday:'long',day:'numeric',month:'long'}).format(new Date());
function render(){
 const done=tasks.filter(t=>t.done).length,open=tasks.length-done,pct=tasks.length?Math.round(done/tasks.length*100):0;
 $('doneCount').textContent=done;$('openCount').textContent=open;$('noteCount').textContent=notes.length;$('progressNum').textContent=pct+'%';
 $('progressRing').style.background=`conic-gradient(var(--accent) ${pct*3.6}deg,var(--line) 0deg)`;
 const shown=tasks.filter(t=>filter==='all'||(filter==='open'&&!t.done)||(filter==='done'&&t.done));
 $('taskList').innerHTML=shown.map(t=>`<div class="task-item ${t.done?'done':''}"><button class="check" data-check="${t.id}" aria-label="تغيير حالة المهمة">${t.done?'✓':''}</button><span class="task-name"></span><span class="priority ${t.priority}">${t.priority==='high'?'مهمة':t.priority==='low'?'لاحقاً':'عادية'}</span><button class="delete-btn" data-task-delete="${t.id}" aria-label="حذف">×</button></div>`).join('');
 [...$('taskList').querySelectorAll('.task-item')].forEach((el,i)=>el.querySelector('.task-name').textContent=shown[i].title);
 $('emptyTasks').classList.toggle('hidden',shown.length!==0);
 $('noteList').innerHTML=notes.map(n=>`<article class="note-card"><button class="delete-btn" data-note-delete="${n.id}" aria-label="حذف الملاحظة">×</button><h4></h4><p></p></article>`).join('');
 [...$('noteList').children].forEach((el,i)=>{el.querySelector('h4').textContent=notes[i].title;el.querySelector('p').textContent=notes[i].body||'بدون تفاصيل'});
 $('emptyNotes').classList.toggle('hidden',notes.length!==0);
}
$('addTaskBtn').onclick=()=>{$('taskForm').classList.toggle('hidden');$('taskInput').focus()};
$('taskForm').onsubmit=e=>{e.preventDefault();const title=$('taskInput').value.trim();if(!title)return;tasks.unshift({id:Date.now(),title,priority:$('taskPriority').value,done:false});$('taskInput').value='';$('taskForm').classList.add('hidden');save();toast('تمت إضافة المهمة')};
$('addNoteBtn').onclick=()=>{$('noteForm').classList.toggle('hidden');$('noteTitle').focus()};
$('noteForm').onsubmit=e=>{e.preventDefault();const title=$('noteTitle').value.trim();if(!title)return;notes.unshift({id:Date.now(),title,body:$('noteBody').value.trim()});$('noteForm').reset();$('noteForm').classList.add('hidden');save();toast('تم حفظ الملاحظة')};
document.addEventListener('click',e=>{
 const check=e.target.closest('[data-check]');if(check){const t=tasks.find(x=>x.id==check.dataset.check);if(t)t.done=!t.done;save();return}
 const td=e.target.closest('[data-task-delete]');if(td){tasks=tasks.filter(x=>x.id!=td.dataset.taskDelete);save();toast('تم حذف المهمة');return}
 const nd=e.target.closest('[data-note-delete]');if(nd){notes=notes.filter(x=>x.id!=nd.dataset.noteDelete);save();toast('تم حذف الملاحظة');return}
 const tab=e.target.closest('[data-tab]');if(tab){document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x===tab));['tasks','notes','focus'].forEach(k=>$(`${k}Panel`).classList.toggle('hidden',k!==tab.dataset.tab))}
 const f=e.target.closest('[data-filter]');if(f){filter=f.dataset.filter;document.querySelectorAll('.filter').forEach(x=>x.classList.toggle('active',x===f));render()}
});
$('themeBtn').onclick=()=>{document.body.classList.toggle('dark');localStorage.setItem('wasel_dark',document.body.classList.contains('dark'))};
if(read('wasel_dark',false))document.body.classList.add('dark');
let duration=25*60,remaining=duration,running=false,interval=null;
function paintTimer(){const m=Math.floor(remaining/60),s=remaining%60;$('timer').textContent=String(m).padStart(2,'0')+':'+String(s).padStart(2,'0')}
function stopTimer(){clearInterval(interval);interval=null;running=false;$('timerStart').textContent='ابدأ'}
$('timerStart').onclick=()=>{if(running){stopTimer();$('timerHint').textContent='تم إيقاف الجلسة مؤقتاً.';return}running=true;$('timerStart').textContent='إيقاف مؤقت';$('timerHint').textContent='أنت بتعمل كويس، كمّل بهدوء.';interval=setInterval(()=>{remaining--;paintTimer();if(remaining<=0){stopTimer();$('timerHint').textContent='أحسنت! انتهت جلسة التركيز.';toast('انتهت جلسة التركيز 🎉')}},1000)};
$('timerReset').onclick=()=>{stopTimer();remaining=duration;paintTimer();$('timerHint').textContent='تمت إعادة ضبط المؤقت.'};
document.querySelectorAll('[data-min]').forEach(b=>b.onclick=()=>{stopTimer();duration=Number(b.dataset.min)*60;remaining=duration;paintTimer();document.querySelectorAll('[data-min]').forEach(x=>x.classList.toggle('selected',x===b));$('timerHint').textContent='المدة جاهزة. ابدأ وقت ما تحب.'});
if('serviceWorker'in navigator && location.protocol.startsWith('http'))window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
render();paintTimer();