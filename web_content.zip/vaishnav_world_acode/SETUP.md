# Setup in Acode

1. Extract the ZIP.
2. Open `vaishnav_world_acode/devotee/index.html` in an Acode/browser preview for the Devotee App.
3. Open `vaishnav_world_acode/admin/index.html` for the Admin App.
4. In Firebase Console, open Authentication → Sign-in method and enable **Anonymous**.
5. Make sure Realtime Database exists and uses the same project shown in `firebase-config.js`.
6. Publish or paste `firebase-rules.json` into Realtime Database Rules for this prototype.

## Login persistence
Firebase Web Auth uses local persistence in this build. After a successful login, refresh/reopen does not return to the login form until the user explicitly logs out, provided the browser still has the same site data.

## Daily quiz workflow
Admin → Quiz → select date → fill Q1 to Q10 → choose each correct option → **Publish Today's 10-Question Quiz**.

The Devotee app automatically loads today's date-wise quiz. The score is stored in `quiz/results/{date}/{uid}` and today's leaderboard is sorted highest score to lowest.

## Important security note
The visible demo code and admin password are prototype-only. Anonymous Auth proves only that a Firebase session exists; it does not prove phone ownership. The password `2011` in client JavaScript is also not a secure production admin login. For a real public app, move admin authorization to Firebase Authentication + role-based Security Rules/custom claims and use real phone/email authentication if identity verification is required.
