# Vaishnav World — updated features

## Devotee app
- Professional circular feature icons inspired by the supplied Play Quiz / Calendar style.
- Hindi Quiz and Bengali Quiz as separate daily quizzes.
- One combined leaderboard for both languages.
- Book Store with admin-uploaded book photos.
- Poster section with admin-uploaded poster images.
- Prabhupada Today Quotes with date, quote and optional source.
- Notifications / Updates page.
- Yatra status, seat number and ticket display.
- Individual member linkage support through `yatraMembers/{uid}`.
- Existing Japa, Sadhana, Challenge, Courses, Katha, Calendar, YouTube and Profile features remain.

## Admin app
- Hindi/Bengali quiz publishing.
- Book Store image upload.
- Poster image upload.
- Prabhupada Today Quote publishing.
- Yatra approve/reject, seat assignment and ticket upload.
- Automatic Firebase notification records on major publishing actions.
