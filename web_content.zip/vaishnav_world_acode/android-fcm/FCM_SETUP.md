# Vaishnav World — FCM setup note

The supplied `google-services.json` is included here for the Android app registered in Firebase.

Package name in the file: `com.bhaktiverse.app`.

The Admin web app now creates Firebase notification records automatically when these are published:
- Hindi Quiz
- Bengali Quiz
- Course
- Book
- Poster
- Calendar festival
- Prabhupada Today Quote
- Weekly Challenge
- YouTube video
- Bhakti content
- Yatra status / seat / ticket update

The Devotee app reads those records and shows them in its Updates/Notifications page.

## Important
This Acode HTML ZIP is not an Android native project, so it does not by itself contain the native Firebase Messaging service that displays OS-level notifications while the APK is closed. Firebase's Android FCM setup requires the Android app to include the Firebase Messaging SDK and notification permission handling. Android 13+ requires the user to grant `POST_NOTIFICATIONS` before notifications can be shown.

For the eventual APK wrapper, keep the Android package name exactly aligned with the supplied Firebase registration (`com.bhaktiverse.app`) or register a new Firebase Android app and download its matching `google-services.json`.

Do not add any Firebase service-account private key to this folder.
