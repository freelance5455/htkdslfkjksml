# Vaishnav World — Acode + Firebase Prototype

This build is designed for Acode using HTML/CSS/JavaScript and Firebase Realtime Database.

## Devotee login flow
1. 3-second Vaishnav World splash screen.
2. Name + mobile number.
3. A 6-digit demo verification code appears on screen.
4. Enter the same code to continue.
5. Firebase anonymous authentication creates the UID used by the app.
6. The Firebase web Auth session uses local persistence, so refreshing/reopening the app on the same browser does not show the login screen again. The login screen returns after explicit Logout (or if browser/site data is cleared).

The 6-digit code is only a demo verification step. It does not verify ownership of a mobile number and does not send SMS.

## Icons
The devotee UI uses custom inline SVG icons and a Vaishnav World SVG mark instead of emoji icons. This keeps the UI consistent in Acode and avoids depending on an emoji font.

## Daily quiz
Admin can select a date and publish all 10 questions together (Q1–Q10). Each question has four options and one correct answer. Previous dates remain under `quiz/daily/{date}` and can be edited or deleted from Admin.

Devotee app reads today's quiz from `quiz/daily/{YYYY-MM-DD}` and saves the result under:
`quiz/results/{YYYY-MM-DD}/{uid}`

Quiz leaderboard is calculated from today's results and sorted by highest score first. Earlier submission wins ties.

## Weekly challenge leaderboard
Challenge progress is saved under `challengeProgress/{challengeId}/{uid}` with `points` and `name`. The devotee app sorts points highest-to-lowest and assigns ranks.

## Admin login
Prototype password: `2011`.

This is client-side prototype authentication, not secure production admin authorization. For a public launch, use a real Firebase Authentication admin account and role-based Security Rules/custom claims.

## Firebase
Project: `hare-krishna-94342`

Enable Firebase Authentication → Sign-in method → Anonymous for this prototype. Firebase Realtime Database rules are in `firebase-rules.json`.

The included rules are development/prototype rules. Before public launch, restrict sensitive paths and especially Yatra/member identity data. Firebase Security Rules are enforced server-side and should be used for real authorization.
