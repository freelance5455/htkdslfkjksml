// Serveur de synchronisation (reseau local / point d'acces Wi-Fi).
// Protocole : POST /api/sync  { token, cid, user, since, evSince, push:[{id,v|del}], bye, ping }
const http = require('http'), os = require('os'), fs = require('fs'), path = require('path'), crypto = require('crypto');

module.exports = function createSyncServer(dataFile) {
  let srv = null, port = 0, token = '';
  let rev = 0, evN = 0;
  const entries = new Map();   // id -> {id, v, del, rev}
  const events = [];           // {n, kind?, id?, op?, v?, by, role, mats, cid, ts}
  const online = new Map();    // cid -> {cid,id,name,role,mats,last}
  let timer = null, saveT = null;
  // --- Espace parents (lecture seule) ---
  const pv = new Map();        // matricule -> {v, ts}  : fiche publiee pour les parents (jamais melangee aux donnees de synchro)
  const dev = new Map();       // jeton d'appareil parent -> {codeId, mat, created}
  const fails = new Map();     // ip -> {n, until}  : protection contre les essais de codes
  let ecole = null;
  const normCode = c => String(c || '').toUpperCase().replace(/[^A-Z0-9]/g, '');

  try {
    const d = JSON.parse(fs.readFileSync(dataFile, 'utf8'));
    rev = d.rev || 0; evN = d.evN || 0;
    (d.entries || []).forEach(e => entries.set(e.id, e));
    (d.pv || []).forEach(x => pv.set(x[0], x[1]));
    (d.dev || []).forEach(x => dev.set(x[0], x[1]));
    ecole = d.ecole || null;
  } catch (e) {}

  function save() {
    clearTimeout(saveT);
    saveT = setTimeout(() => {
      try {
        fs.mkdirSync(path.dirname(dataFile), { recursive: true });
        const tmp = dataFile + '.tmp';
        fs.writeFileSync(tmp, JSON.stringify({ rev, evN, entries: [...entries.values()], pv: [...pv], dev: [...dev], ecole }));
        fs.renameSync(tmp, dataFile);
      } catch (e) {}
    }, 1000);
  }
  function addEvent(o) {
    events.push(Object.assign({ n: ++evN, ts: Date.now() }, o));
    if (events.length > 500) events.splice(0, events.length - 500);
  }
  const who = u => ({ by: u.name || u.id || '?', role: u.role, mats: u.mats || '' });

  function sweep() {
    const now = Date.now();
    for (const [cid, o] of online) if (now - o.last > 20000) {
      online.delete(cid); addEvent({ kind: 'leave', cid, by: o.name, role: o.role, mats: o.mats });
    }
  }

  function handle(b) {
    if (!b || b.token !== token) return { error: 'token' };
    const u = b.user || null;
    if (u && !b.ping) {
      if (b.bye) {
        const o = online.get(b.cid);
        if (o) { online.delete(b.cid); addEvent(Object.assign({ kind: 'leave', cid: b.cid }, who(o))); }
      } else {
        const had = online.has(b.cid);
        online.set(b.cid, { cid: b.cid, id: u.id, name: u.name, role: u.role, mats: u.mats || '', last: Date.now() });
        if (!had) addEvent(Object.assign({ kind: 'join', cid: b.cid }, who(u)));
      }
    }
    let changed = false;
    (b.push || []).forEach(p => {
      if (!p || typeof p.id !== 'string') return;
      const cur = entries.get(p.id);
      // Codes parents : un code utilise ou revoque ne peut jamais redevenir disponible (pas de conflit entre postes)
      if (p.id.startsWith('parentCodes:') && cur && !cur.del && cur.v && p.v && !p.del) {
        p = { id: p.id, v: Object.assign({}, p.v, {
          code: cur.v.code, mat: cur.v.mat,
          used: !!(cur.v.used || p.v.used), revoked: !!(cur.v.revoked || p.v.revoked),
          activatedAt: cur.v.activatedAt || p.v.activatedAt || null }) };
      }
      if (p.del) {
        if (!cur || cur.del) return;
        entries.set(p.id, { id: p.id, del: true, rev: ++rev });
        addEvent(Object.assign({ cid: b.cid, id: p.id, op: 'del' }, who(u || {})));
      } else {
        if (cur && !cur.del && JSON.stringify(cur.v) === JSON.stringify(p.v)) return;
        const op = cur && !cur.del ? 'mod' : 'add';
        entries.set(p.id, { id: p.id, v: p.v, rev: ++rev });
        addEvent(Object.assign({ cid: b.cid, id: p.id, op, v: p.v }, who(u || {})));
      }
      changed = true;
    });
    const P = b.parents;
    if (P && u && u.role === 'admin') {   // publication des fiches parents par la direction
      if (P.ecole && typeof P.ecole === 'object') ecole = P.ecole;
      (P.views || []).forEach(x => { if (x && typeof x.mat === 'string' && x.v && typeof x.v === 'object') pv.set(x.mat, { v: x.v, ts: Date.now() }); });
      (P.remove || []).forEach(m => pv.delete(String(m)));
      if (P.ecole || (P.views || []).length || (P.remove || []).length) changed = true;
    }
    if (changed) save();
    const since = typeof b.since === 'number' ? b.since : 0;
    const out = [];
    if (since < rev) for (const e of entries.values()) if (e.rev > since) out.push(e.del ? { id: e.id, del: true } : { id: e.id, v: e.v });
    const evs = typeof b.evSince === 'number' ? events.filter(e => e.n > b.evSince && e.cid !== b.cid) : [];
    return { rev, pn: pv.size, entries: out, evMax: evN, events: evs, online: [...online.values()].map(o => ({ cid: o.cid, id: o.id, name: o.name, role: o.role, mats: o.mats })) };
  }

  function codeEntry(codeId) { const e = entries.get('parentCodes:' + codeId); return e && !e.del && e.v ? e : null; }
  function parentActivate(codeIn, ip, matIn) {
    const now = Date.now(), f = fails.get(ip) || { n: 0, until: 0 };
    if (f.until > now) return { status: 429, body: { error: 'trop' } };
    const n = normCode(codeIn);
    let found = null;
    if (n.length >= 6) for (const e of entries.values()) if (!e.del && e.id.startsWith('parentCodes:') && e.v && normCode(e.v.code) === n && (!matIn || normCode(e.v.mat) === normCode(matIn))) { found = e; break; }
    if (!found) {
      f.n++; if (f.n >= 8) { f.until = now + 10 * 60000; f.n = 0; } fails.set(ip, f);
      return { status: 200, body: { error: 'invalid' } };
    }
    fails.delete(ip);
    if (found.v.revoked) return { status: 200, body: { error: 'revoked' } };
    const id = found.v.id;
    if (found.v.used || [...dev.values()].some(d => d.codeId === id)) return { status: 200, body: { error: 'used' } };
    const token = crypto.randomBytes(24).toString('hex');
    dev.set(token, { codeId: id, mat: found.v.mat, created: now });
    entries.set(found.id, { id: found.id, v: Object.assign({}, found.v, { used: true, activatedAt: now }), rev: ++rev });
    save();
    return { status: 200, body: { ok: true, token } };
  }
  function parentData(tokens) {
    const children = [];
    (Array.isArray(tokens) ? tokens : []).slice(0, 12).forEach(t => {
      const d = dev.get(String(t));
      if (!d) return children.push({ token: t, status: 'unknown' });
      const ce = codeEntry(d.codeId);
      if (!ce || ce.v.revoked) return children.push({ token: t, status: 'revoked' });
      const x = pv.get(d.mat);
      if (!x) return children.push({ token: t, status: 'pending' });
      children.push({ token: t, status: 'ok', ts: x.ts, v: x.v });   // uniquement la fiche de CET eleve
    });
    return { ecole, children };
  }

  function addresses() {
    const a = [];
    for (const list of Object.values(os.networkInterfaces())) for (const i of list || [])
      if (i.family === 'IPv4' && !i.internal) a.push(i.address);
    return a;
  }

  return {
    status: () => ({ running: !!srv, port, token, addresses: addresses() }),
    start(p, t) {
      return new Promise(resolve => {
        p = parseInt(p, 10); t = String(t || '').trim();
        if (!(p >= 1024 && p <= 65535)) return resolve({ ok: false, error: 'Port invalide (1024 a 65535)' });
        if (t.length < 4) return resolve({ ok: false, error: 'Code d’acces : 4 caracteres minimum' });
        if (srv) return resolve({ ok: true });
        const s = http.createServer((req, res) => {
          const h = { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Content-Type' };
          if (req.method === 'OPTIONS') { res.writeHead(204, h); return res.end(); }
          const url = req.url.split('?')[0];
          if (req.method === 'GET' && (url === '/' || url === '/parent' || url === '/parent/')) {
            try {
              const html = fs.readFileSync(path.join(__dirname, 'parent.html'));
              res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' }); return res.end(html);
            } catch (e) { res.writeHead(404, h); return res.end('{}'); }
          }
          if (req.method === 'POST' && url === '/api/parent') {
            const ch = []; let sz = 0;
            req.on('data', c => { sz += c.length; if (sz > 20000) req.destroy(); else ch.push(c); });
            req.on('end', () => {
              let r;
              try {
                const b = JSON.parse(Buffer.concat(ch).toString('utf8'));
                const ip = req.socket.remoteAddress || '?';
                r = b.action === 'activate' ? parentActivate(b.code, ip, b.mat) : b.action === 'data' ? { status: 200, body: parentData(b.tokens) } : { status: 400, body: { error: 'bad' } };
              } catch (e) { r = { status: 400, body: { error: 'bad' } }; }
              res.writeHead(r.status, h); res.end(JSON.stringify(r.body));
            });
            return;
          }
          if (req.method !== 'POST' || url !== '/api/sync') { res.writeHead(404, h); return res.end('{}'); }
          const chunks = []; let size = 0;
          req.on('data', c => { size += c.length; if (size > 60e6) req.destroy(); else chunks.push(c); });
          req.on('end', () => {
            let r;
            try { r = handle(JSON.parse(Buffer.concat(chunks).toString('utf8'))); }
            catch (e) { res.writeHead(400, h); return res.end('{}'); }
            if (r.error) { res.writeHead(401, h); return res.end(JSON.stringify(r)); }
            res.writeHead(200, h); res.end(JSON.stringify(r));
          });
        });
        s.on('error', e => resolve({ ok: false, error: e.code === 'EADDRINUSE' ? 'Port ' + p + ' deja utilise' : String(e.message) }));
        s.listen(p, '0.0.0.0', () => { srv = s; port = p; token = t; timer = setInterval(sweep, 5000); resolve({ ok: true }); });
      });
    },
    stop() { return new Promise(resolve => { if (!srv) return resolve({ ok: true }); clearInterval(timer); srv.close(() => {}); srv.closeAllConnections && srv.closeAllConnections(); srv = null; resolve({ ok: true }); }); }
  };
};
