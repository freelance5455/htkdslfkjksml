---
name: Nexora Media Digital Authority
colors:
  surface: '#0f131d'
  surface-dim: '#0f131d'
  surface-bright: '#353944'
  surface-container-lowest: '#0a0e17'
  surface-container-low: '#171c25'
  surface-container: '#1b2029'
  surface-container-high: '#262a34'
  surface-container-highest: '#31353f'
  on-surface: '#dfe2f0'
  on-surface-variant: '#bcc9cd'
  inverse-surface: '#dfe2f0'
  inverse-on-surface: '#2c303b'
  outline: '#869397'
  outline-variant: '#3d494c'
  surface-tint: '#4cd7f6'
  primary: '#4cd7f6'
  on-primary: '#003640'
  primary-container: '#06b6d4'
  on-primary-container: '#00424f'
  inverse-primary: '#00687a'
  secondary: '#b4c5ff'
  on-secondary: '#002a78'
  secondary-container: '#0053db'
  on-secondary-container: '#cdd7ff'
  tertiary: '#4edea3'
  on-tertiary: '#003824'
  tertiary-container: '#1bbd85'
  on-tertiary-container: '#00452e'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#acedff'
  primary-fixed-dim: '#4cd7f6'
  on-primary-fixed: '#001f26'
  on-primary-fixed-variant: '#004e5c'
  secondary-fixed: '#dbe1ff'
  secondary-fixed-dim: '#b4c5ff'
  on-secondary-fixed: '#00174b'
  on-secondary-fixed-variant: '#003ea8'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#0f131d'
  on-background: '#dfe2f0'
  surface-variant: '#31353f'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 56px
    fontWeight: '800'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: 0em
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: 0em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.04em
  urdu-headline:
    fontFamily: Noto Sans Arabic
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 52px
    letterSpacing: 0em
  urdu-body:
    fontFamily: Noto Sans Arabic
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 30px
    letterSpacing: 0em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system embodies an elite, tech-forward agency aesthetic that balances high-octane creative energy with enterprise-grade precision. Tailored to bridge regional authority in Pakistan with global digital advertising standards, the visual style combines deep-night nocturnal depths with electric, luminous accents.

### Design Movements & Visual Language
- **Luminous Cyber-Modernism**: Anchored by deep night obsidian navy surfaces, utilizing targeted radiant cyan and electric blue highlights to direct conversion pathways.
- **Precision Glassmorphism**: Translucent container layers with razor-sharp 1px micro-borders (`rgba(255, 255, 255, 0.08)`) and controlled background diffusion, avoiding muddy blurs.
- **Bilingual Typographic Harmony**: Cohesive typographic rhythm prioritizing high-legibility English modern geometric sans-serif alongside native Nastaliq/Arabic forms for localized communication, maintaining strict baseline balance.

### Emotional Goals
- **Authority & Trust**: Evoking corporate solidity, technological competence, and measurable ROI.
- **High-Performance Agility**: Clean, responsive micro-interactions that communicate speed, modern tooling, and data-driven creative mastery.

## Colors

The palette establishes high dynamic range on ultra-deep canvas tones, reserving luminous cyan and electric blue for conversion drivers and structural focal points.

### Palette Architecture
- **Canvas Base (`#070B14`)**: Deepest void navy for full-canvas backgrounds.
- **Surface Elevation 1 (`#0D1322`)**: Primary card base and underlying structural modules.
- **Surface Elevation 2 (`#141E33`)**: Interactive hover states, elevated modals, and input fields.
- **Surface Elevation 3 (`#1A2640`)**: Floating tooltips, dropdown sheets, and active badge states.
- **Primary / Cyber Cyan (`#06B6D4`)**: Brand focal points, active state indicators, key metrics, and primary glowing accents.
- **Secondary / Electric Blue (`#2563EB`)**: Anchor points, high-priority background gradients, and primary interactive buttons.
- **Accent Turquoise (`#14B8A6`)**: Secondary highlight metrics, micro-tags, and progressive indicators.
- **Success / Direct Channel (`#10B981`)**: WhatsApp direct CTA, active campaign status badges, and positive ROI analytics.
- **Text & Contrast Hierarchy**:
  - High Contrast: `#F8FAFC` (Headings, primary button text, hero metrics).
  - Mid Contrast: `#94A3B8` (Body prose, field labels, metadata).
  - Subtle Contrast: `#475569` (Borders, inactive icons, divider rules).

## Typography

The type system blends the punchy, geometric personality of Plus Jakarta Sans for displays with the neutral, ultra-legible utilitarianism of Inter for data density and long-form copy.

### Urdu Localization & RTL Harmony
- For localized Pakistani market campaigns, Noto Sans Arabic (with Nastaliq styling overrides where applicable) handles native Urdu copy.
- Because Nastaliq and standard Arabic typefaces have significantly taller vertical ascenders and descenders, line-heights are scaled to a minimum of `1.6x - 1.8x` relative to font size to avoid clipping.
- Alignments switch automatically under `dir="rtl"`, shifting icon placements and tracking dynamics symmetrically.

## Layout & Spacing

The layout philosophy uses a flexible 12-column grid anchored by maximum viewport constraints, optimized for high conversion velocity on hand-held mobile devices while preserving breathability on ultra-wide desktop viewports.

### Breakpoints & Grid Matrix
- **Mobile (< 768px)**: 4-column layout, `1rem` outer margins, `1rem` gutters. Vertical stack enforcement for conversion modules. Bottom app-style sheets replace desktop modals.
- **Tablet (768px - 1024px)**: 8-column layout, `1.5rem` outer margins, `1.25rem` gutters. Two-column grid configurations for analytical cards and portfolio showcases.
- **Desktop (> 1024px)**: 12-column layout, `2rem` outer margins, `1.5rem` gutters, constrained to a maximum content width of `1280px` centered on canvas.

### Spatial Rhythm
Gaps and internal component padding adhere strictly to the 4px/8px rhythm. Structural section spacing uses `space-xl` scaled dynamically (2.5rem on mobile to 5rem on desktop) to retain an airy, high-end agency stature.

## Elevation & Depth

Visual hierarchy uses luminous glassmorphism and tinted ambient shadows to create depth in a dark interface, avoiding heavy flat outlines.

### Elevation Architecture
1. **Canvas (Base Level 0)**: Unadorned `#070B14`, illuminated solely by subtle, ambient radial gradients (`radial-gradient(circle at 50% 0%, rgba(37, 99, 235, 0.12), transparent 70%)`).
2. **Layer 1 - Standard Glass Cards**: Background: `rgba(13, 19, 34, 0.75)`, backdrop blur: `16px`. Border: 1px solid `rgba(255, 255, 255, 0.08)`. Shadow: `0 10px 30px -10px rgba(0, 0, 0, 0.5)`.
3. **Layer 2 - Floating Controls & Hovered Surfaces**: Background: `rgba(20, 30, 51, 0.85)`, backdrop blur: `20px`. Border: 1px solid `rgba(6, 182, 212, 0.3)`. Shadow: `0 20px 40px -15px rgba(6, 182, 212, 0.15)`.
4. **Layer 3 - High-Priority Modals & Sticky Headers**: Background: `rgba(7, 11, 20, 0.9)`, backdrop blur: `24px`. Border: 1px solid `rgba(255, 255, 255, 0.12)`. Shadow: `0 25px 50px -12px rgba(0, 0, 0, 0.7)`.

### Ambient Glow Logic
Buttons and critical interactive nodes utilize a pseudo-element bloom: an ultra-soft, low-opacity drop shadow colored directly with the element's hue (e.g., `#06B6D4` glow at 25% opacity with 24px blur) that expands on hover.

## Shapes

The geometric framework balances rounded cards (`0.5rem` to `1rem`) with pill-shaped interactive micro-elements (`9999px`).

### Radius Mapping
- **Standard UI Cards & Containers**: Rounded (`0.5rem` / 8px).
- **Large Presentation Panels & Hero Media**: Rounded Large (`1rem` / 16px).
- **Pill Badges, Action Buttons, and Chip Elements**: Fully rounded pill shapes (`9999px`) provide a sleek, streamlined aesthetic that contrasts with structural layout grids.
- **Form Controls & Inputs**: Rounded (`0.5rem` / 8px) to echo card architecture.

## Components

### Buttons
- **Primary CTA**: Pill-shaped container. Gradient fill from `#2563EB` to `#06B6D4`. Label in `#F8FAFC` (`label-md`). Box shadow: `0 4px 20px rgba(6, 182, 212, 0.35)`. Subtle `translateY(-1px)` and increased bloom on hover.
- **Direct WhatsApp Conversion CTA**: Pill-shaped container. Solid `#10B981` fill with `#FFFFFF` text. Micro-glow: `0 4px 16px rgba(16, 185, 129, 0.3)`. Features the brand icon placed inline with 8px margin.
- **Secondary / Ghost**: Pill-shaped container. Background: `rgba(255, 255, 255, 0.04)`. Border: `1px solid rgba(255, 255, 255, 0.15)`. Hover: `rgba(255, 255, 255, 0.08)` and border shifts to cyan (`#06B6D4`).

### Chips & Pill Badges
- **Status Badges**: Fully rounded pills with `0.25rem` vertical and `0.75rem` horizontal padding. Uses a translucent background (`rgba(6, 182, 212, 0.1)`) paired with a crisp text color (`#06B6D4`) and a pulsing 6px colored dot indicator.
- **Filter Chips**: Dark translucent slate background (`#141E33`), thin outline (`rgba(255,255,255,0.08)`), text in `#94A3B8`. Transitions to electric blue tint upon selection.

### Form Inputs & Textareas
- **Surface**: Background `#0D1322` with an inner 1px border of `rgba(255, 255, 255, 0.1)`. Height: 48px for touch optimization.
- **Typography**: `#F8FAFC` input text, `#475569` placeholder text.
- **States**: Focused state triggers a border color transition to `#06B6D4` paired with an external focus ring of `0 0 0 3px rgba(6, 182, 212, 0.15)`. Labels sit outside the field in `#94A3B8` (`label-sm`).

### Checkboxes & Radios
- **Checkbox**: 20px x 20px rounded square (`4px` radius). Border: `1px solid rgba(255, 255, 255, 0.2)`. Checked state: `#06B6D4` fill with `#070B14` bold checkmark vector.
- **Radio**: 20px circular frame. Checked state displays a glowing `#06B6D4` 8px inner circle.

### Cards
- **Portfolio & Service Metric Cards**: Glassmorphic `#0D1322` substrate with `16px` border-radius and `rgba(255, 255, 255, 0.08)` hairline borders. On hover, the border gradient transitions to cyan and the card lifts by `4px` with an expanded tinted ambient shadow.

### Regional Agency Specific Components
- **WhatsApp Direct Action Drawer**: Persistent mobile bottom anchor button with emerald green accenting (`#10B981`) and instantaneous localized Urdu / English quick-inquiry prompts.
- **Bilingual Metric Display**: Twin-readout data cards showing performance metrics (e.g., ROI, ROAS, Impression Reach) paired with bilingual English and Urdu descriptive labels.