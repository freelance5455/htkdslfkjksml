Waltisthbirth Chapri Game v3.0

How to play on Android / Acode:
1. Extract the ZIP into a folder.
2. Open index.html in Acode preview or a browser.
3. Tap START GAME. Tap the game area to fly.
4. Select Jungle, Desert, Sea or Winter Snow from the menu.

Included files:
- index.html, style.css, script.js
- character.png (your uploaded face + yellow bird character, background removed)
- perfect-fart.mp3 (tap/fly sound)
- cid-bc.mp3 (game-over sound)

Difficulty starts easier and gets gradually harder as your score rises. Winter has falling snow and an animated skating penguin; jungle has moving cartoon animals.
