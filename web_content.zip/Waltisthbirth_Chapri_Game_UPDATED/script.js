const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d", { alpha: false });
const faceImg = document.getElementById("face");
const message = document.getElementById("message");
const scoreText = document.getElementById("score");
const coinsText = document.getElementById("coins");
const startBtn = document.getElementById("startBtn");
const musicBtn = document.getElementById("musicBtn");
const pauseBtn = document.getElementById("pauseBtn");
const startSound = document.getElementById("startSound");
const tapSound = document.getElementById("tapSound");
const deathSound = document.getElementById("deathSound");
const chaserImg = document.getElementById("chaser");
let deathAnimation = false, deathAnimFrame = 0;

const W = canvas.width, H = canvas.height, GROUND = 494;
const characters = [
  { id: "classic", name: "Classic", emoji: "🐤", cost: 0, color: "#ffd52e" },
  { id: "blue", name: "Blue Bird", emoji: "🔵", cost: 20, color: "#42d8ff" },
  { id: "pink", name: "Pink Bird", emoji: "🩷", cost: 35, color: "#ff82c6" },
  { id: "gold", name: "Golden Bird", emoji: "👑", cost: 60, color: "#ffb800" }
];
const STORE_KEY = "waltisthbirthRigongSaveV2";
let saved = loadSave();
let bird, pipes = [], score = 0, frame = 0, running = false, paused = false;
let lastTime = 0, audio = null, musicOn = true, musicTimer = null, noteIndex = 0, noiseBuffer = null;
let biome = "jungle", selectedCharacter = saved.selected || "classic", earnedThisRun = 0;
const melody = [392,494,587,494,330,392,523,392,440,523,659,523,349,440,523,440];

function loadSave() {
  try {
    const data = JSON.parse(localStorage.getItem(STORE_KEY) || "{}");
    return { coins: Number(data.coins) || 0, best: Number(data.best) || 0,
      unlocked: Array.isArray(data.unlocked) ? data.unlocked : ["classic"], selected: data.selected || "classic" };
  } catch { return { coins: 0, best: 0, unlocked: ["classic"], selected: "classic" }; }
}
function saveGame() {
  try { localStorage.setItem(STORE_KEY, JSON.stringify(saved)); } catch {}
  updateStats();
}
function updateStats() {
  document.getElementById("homeCoins").textContent = saved.coins;
  document.getElementById("homeBest").textContent = saved.best;
  document.getElementById("shopCoins").textContent = saved.coins;
  coinsText.textContent = saved.coins;
}
function initAudio() {
  if (!audio) {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;
    audio = new AudioCtx();
    const length = Math.floor(audio.sampleRate * .42);
    noiseBuffer = audio.createBuffer(1, length, audio.sampleRate);
    const data = noiseBuffer.getChannelData(0);
    for (let i = 0; i < length; i++) data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / length, 1.5);
  }
  if (audio && audio.state === "suspended") audio.resume();
}
function playTapSound() {
  if (!tapSound) return;
  try { tapSound.pause(); tapSound.currentTime = 0; const p = tapSound.play(); if (p) p.catch(() => {}); } catch {}
}
function playDeathSound() {
  if (!deathSound) return;
  try { deathSound.pause(); deathSound.currentTime = 0; const p = deathSound.play(); if (p) p.catch(() => {}); } catch {}
}
function fartSound() {
  if (!audio || !noiseBuffer) return;
  const t = audio.currentTime;
  const osc = audio.createOscillator(), wobble = audio.createOscillator();
  const wobbleGain = audio.createGain(), lowpass = audio.createBiquadFilter(), toneGain = audio.createGain();
  osc.type = "sawtooth"; osc.frequency.setValueAtTime(92, t); osc.frequency.exponentialRampToValueAtTime(43, t + .34);
  wobble.type = "sine"; wobble.frequency.value = 19; wobbleGain.gain.value = 17;
  wobble.connect(wobbleGain); wobbleGain.connect(osc.frequency);
  lowpass.type = "lowpass"; lowpass.frequency.setValueAtTime(360, t); lowpass.frequency.exponentialRampToValueAtTime(125, t + .35);
  toneGain.gain.setValueAtTime(.001, t); toneGain.gain.linearRampToValueAtTime(.18, t + .025);
  toneGain.gain.setValueAtTime(.13, t + .12); toneGain.gain.exponentialRampToValueAtTime(.001, t + .38);
  osc.connect(lowpass); lowpass.connect(toneGain); toneGain.connect(audio.destination);
  osc.start(t); wobble.start(t); osc.stop(t + .4); wobble.stop(t + .4);
  const noise = audio.createBufferSource(), filter = audio.createBiquadFilter(), gain = audio.createGain();
  noise.buffer = noiseBuffer; filter.type = "bandpass"; filter.frequency.value = 430; filter.Q.value = .8;
  gain.gain.setValueAtTime(.001, t); gain.gain.linearRampToValueAtTime(.06, t + .035); gain.gain.exponentialRampToValueAtTime(.001, t + .36);
  noise.connect(filter); filter.connect(gain); gain.connect(audio.destination); noise.start(t); noise.stop(t + .42);
}
function playNote(freq) {
  if (!audio || !musicOn || !running || paused) return;
  const t = audio.currentTime, osc = audio.createOscillator(), gain = audio.createGain();
  osc.type = "triangle"; osc.frequency.value = freq;
  gain.gain.setValueAtTime(.001, t); gain.gain.linearRampToValueAtTime(.03, t + .025); gain.gain.exponentialRampToValueAtTime(.001, t + .18);
  osc.connect(gain); gain.connect(audio.destination); osc.start(t); osc.stop(t + .19);
}
function stopMusic() { if (musicTimer !== null) { clearInterval(musicTimer); musicTimer = null; } }
function startMusic() {
  stopMusic(); if (!musicOn || !running || paused) return;
  musicTimer = setInterval(() => { if (running && !paused && musicOn) { playNote(melody[noteIndex % melody.length]); noteIndex++; } }, 230);
}
function resetGame() {
  bird = { x: 94, y: 270, velocity: 0 }; pipes = []; score = 0; frame = 0; lastTime = 0; earnedThisRun = 0;
  scoreText.textContent = "0";
}
function showPanel(which, title, subtitle, emoji) {
  document.getElementById("overlayTitle").textContent = title;
  document.getElementById("overlayText").textContent = subtitle;
  document.getElementById("overlayEmoji").textContent = emoji;
  ["homePanel","pausePanel","gameOverPanel","shopPanel"].forEach(id => document.getElementById(id).classList.toggle("hidden", id !== which));
  message.style.display = "flex";
}
function goHome() {
  running = false; paused = false; stopMusic(); tapSound.pause(); deathSound.pause();
  showPanel("homePanel", "Waltisthbirth Chapri Game", "Chapri Bird Adventure", "😂🐦💨");
  document.getElementById("overlayHint").textContent = "Choose your world and bird!";
  pauseBtn.textContent = "Ⅱ"; updateStats();
}
function startGame() {
  initAudio();
  if (startSound) {
    try { startSound.pause(); startSound.currentTime = 0; const p = startSound.play(); if (p) p.catch(() => {}); } catch {}
  }
  tapSound.pause(); tapSound.currentTime = 0;
  deathSound.pause(); deathSound.currentTime = 0;
  resetGame(); running = true; paused = false;
  message.style.display = "none"; pauseBtn.textContent = "Ⅱ"; startMusic();
  bird.velocity = -4.2;
}
function pauseGame() {
  if (!running || paused) return;
  paused = true; stopMusic();
  showPanel("pausePanel", "GAME PAUSED", "Take a breather, then fly again.", "⏸️🐦");
  document.getElementById("overlayHint").textContent = "Your game is saved in this session.";
  pauseBtn.textContent = "▶";
}
function resumeGame() {
  if (!running || !paused) return;
  initAudio(); paused = false; message.style.display = "none"; pauseBtn.textContent = "Ⅱ"; lastTime = 0; startMusic();
}
function endGame() {
  if (!running) return;
  running = false; paused = false; stopMusic(); tapSound.pause();
  if (startSound) { startSound.pause(); startSound.currentTime = 0; }
  playDeathSound();
  const reward = Math.floor(score / 2) + (score > 0 ? 1 : 0);
  earnedThisRun = reward; saved.coins += reward; saved.best = Math.max(saved.best, score); saveGame();
  document.getElementById("finalScore").textContent = score;
  document.getElementById("earnedCoins").textContent = reward;
  showPanel("gameOverPanel", "GAME OVER!", "Nice try! One more flight?", "🤣💨");
  document.getElementById("overlayHint").textContent = "Coins are saved on this device.";
}
function openShop() {
  renderShop(); showPanel("shopPanel", "CHARACTER SHOP", "Unlock a bird with your coins.", "🛒🐦");
  document.getElementById("overlayHint").textContent = "Classic bird is free.";
}
function renderShop() {
  const cards = document.getElementById("characterCards"); cards.innerHTML = "";
  characters.forEach(ch => {
    const unlocked = saved.unlocked.includes(ch.id), selected = selectedCharacter === ch.id;
    const card = document.createElement("div"); card.className = "character-card";
    const avatar = document.createElement("div"); avatar.className = "avatar"; avatar.textContent = ch.emoji;
    const name = document.createElement("div"); name.className = "char-name"; name.textContent = ch.name;
    const cost = document.createElement("div"); cost.className = "char-cost"; cost.textContent = unlocked ? "Unlocked" : `${ch.cost} coins`;
    const btn = document.createElement("button");
    btn.textContent = selected ? "SELECTED" : unlocked ? "SELECT" : "BUY";
    btn.disabled = selected || (!unlocked && saved.coins < ch.cost);
    btn.addEventListener("click", () => {
      if (!saved.unlocked.includes(ch.id)) {
        if (saved.coins < ch.cost) return;
        saved.coins -= ch.cost; saved.unlocked.push(ch.id);
      }
      selectedCharacter = ch.id; saved.selected = ch.id; saveGame(); renderShop();
    });
    card.append(avatar, name, cost, btn); cards.appendChild(card);
  });
}
function drawBackground() {
  let skyColors;
  if (biome === "desert") skyColors = ["#ffb65c","#ffe2a1","#e9a75f"];
  else if (biome === "sea") skyColors = ["#0879b6","#53d8e8","#b5f1e8"];
  else skyColors = ["#087da0","#55c6bd","#b4d99a"];
  const sky = ctx.createLinearGradient(0,0,0,H);
  sky.addColorStop(0,skyColors[0]); sky.addColorStop(.48,skyColors[1]); sky.addColorStop(1,skyColors[2]);
  ctx.fillStyle = sky; ctx.fillRect(0,0,W,H);
  if (biome === "desert") {
    ctx.fillStyle = "#fff2b0"; ctx.beginPath(); ctx.arc(280,80,29,0,Math.PI*2); ctx.fill();
    ctx.fillStyle = "#d28a4d"; ctx.beginPath(); ctx.moveTo(0,290); ctx.quadraticCurveTo(90,185,175,290); ctx.quadraticCurveTo(270,210,360,275); ctx.lineTo(360,GROUND); ctx.lineTo(0,GROUND); ctx.fill();
    ctx.fillStyle = "#bd733e"; ctx.beginPath(); ctx.moveTo(0,355); ctx.quadraticCurveTo(100,290,205,370); ctx.quadraticCurveTo(280,320,360,355); ctx.lineTo(360,GROUND); ctx.lineTo(0,GROUND); ctx.fill();
    // Cactus silhouettes
    for (let i=0;i<4;i++){ const x=25+i*95,y=335+(i%2)*22; ctx.fillStyle="#24784e"; ctx.fillRect(x,y,9,44); ctx.fillRect(x-9,y+10,9,7); ctx.fillRect(x-9,y+4,6,13); ctx.fillRect(x+7,y+20,8,7); ctx.fillRect(x+10,y+14,5,13); }
  } else if (biome === "sea") {
    ctx.fillStyle="#fff6b0"; ctx.beginPath(); ctx.arc(285,76,25,0,Math.PI*2); ctx.fill();
    // distant islands
    ctx.fillStyle="#267b66"; ctx.beginPath(); ctx.ellipse(55,285,65,23,0,Math.PI,Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(310,280,78,26,0,Math.PI,Math.PI*2); ctx.fill();
    // ocean waves
    for(let j=0;j<4;j++){ ctx.strokeStyle=["#1e9cae","#1594a9","#087c99","#076781"][j]; ctx.lineWidth=3; ctx.beginPath(); for(let x=0;x<=W;x+=8){ const y=300+j*37+Math.sin((x+frame*1.4)*.035+j)*7; if(x===0)ctx.moveTo(x,y);else ctx.lineTo(x,y);} ctx.stroke(); }
    // coral / sea grass
    for(let i=0;i<7;i++){const x=i*56+8;ctx.strokeStyle="#f07e70";ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(x,GROUND);ctx.quadraticCurveTo(x-10,GROUND-20,x,GROUND-30);ctx.moveTo(x,GROUND-12);ctx.lineTo(x+12,GROUND-25);ctx.stroke();}
  } else if (biome === "winter") {
    ctx.fillStyle="#eaf8ff"; ctx.beginPath(); ctx.arc(282,76,27,0,Math.PI*2); ctx.fill();
    ctx.fillStyle="#b8d9ee"; ctx.beginPath(); ctx.moveTo(0,300); ctx.lineTo(55,190); ctx.lineTo(105,285); ctx.lineTo(170,165); ctx.lineTo(245,295); ctx.lineTo(305,205); ctx.lineTo(360,290); ctx.lineTo(360,GROUND); ctx.lineTo(0,GROUND); ctx.fill();
    ctx.fillStyle="#fff"; ctx.beginPath(); ctx.moveTo(35,230); ctx.lineTo(55,190); ctx.lineTo(76,230); ctx.fill(); ctx.beginPath(); ctx.moveTo(142,220); ctx.lineTo(170,165); ctx.lineTo(199,220); ctx.fill();
    const skx=35+((frame*.8)%390);
    ctx.fillStyle="#26384c"; ctx.beginPath(); ctx.ellipse(skx,278+Math.sin(frame*.08)*3,13,18,0,0,Math.PI*2); ctx.fill();
    ctx.fillStyle="#fff"; ctx.beginPath(); ctx.ellipse(skx+2,280,7,11,0,0,Math.PI*2); ctx.fill();
    ctx.fillStyle="#ff9e35"; ctx.beginPath(); ctx.moveTo(skx+10,278); ctx.lineTo(skx+20,281); ctx.lineTo(skx+10,284); ctx.fill();
    ctx.strokeStyle="#7bdcff"; ctx.lineWidth=2; ctx.beginPath(); ctx.moveTo(skx-13,299); ctx.lineTo(skx+14,299); ctx.stroke();
    for(let i=0;i<32;i++){const sx=(i*47+frame*(.6+(i%3)*.25))%W;const sy=(i*73+frame*(1.1+(i%4)*.25))%(GROUND-12);ctx.fillStyle="rgba(255,255,255,.9)";ctx.beginPath();ctx.arc(sx,sy,1.5+(i%3)*.5,0,Math.PI*2);ctx.fill();}
  } else {
    ctx.fillStyle="#fff4a6"; ctx.beginPath(); ctx.arc(282,80,28,0,Math.PI*2); ctx.fill();
    ctx.fillStyle="#659b68"; ctx.beginPath(); ctx.moveTo(0,250);
    for(let x=0;x<=W;x+=12)ctx.lineTo(x,220+Math.sin(x*.035)*20);
    ctx.lineTo(W,GROUND);ctx.lineTo(0,GROUND);ctx.fill();
    for(let i=0;i<8;i++){const x=i*57+8,y=235+Math.sin(i*3)*16;ctx.fillStyle="#75512f";ctx.fillRect(x,y,7,48);ctx.fillStyle=i%2?"#17663c":"#23804a";ctx.beginPath();ctx.arc(x+3,y-7,20,0,Math.PI*2);ctx.fill();ctx.beginPath();ctx.arc(x-7,y+1,13,0,Math.PI*2);ctx.fill();}
    const mx=30+((frame*.65)%390), my=315+Math.sin(frame*.12)*5;
    ctx.fillStyle="#8a552c";ctx.beginPath();ctx.arc(mx,my,10,0,Math.PI*2);ctx.fill();ctx.beginPath();ctx.arc(mx-7,my-8,5,0,Math.PI*2);ctx.arc(mx+7,my-8,5,0,Math.PI*2);ctx.fill();
    ctx.fillStyle="#ffe0a8";ctx.beginPath();ctx.arc(mx,my+2,5,0,Math.PI*2);ctx.fill();
    const px=(mx+110)%W;ctx.fillStyle="#35b95b";ctx.beginPath();ctx.arc(px,208+Math.sin(frame*.1)*7,7,0,Math.PI*2);ctx.fill();ctx.fillStyle="#e83d36";ctx.beginPath();ctx.ellipse(px+6,210+Math.sin(frame*.1)*7,8,4,.3,0,Math.PI*2);ctx.fill();
  }
  ctx.fillStyle = biome === "sea" ? "#237d85" : biome === "desert" ? "#d59b4c" : "#6caa3b";
  ctx.fillRect(0,GROUND,W,H-GROUND);
  ctx.fillStyle = biome === "sea" ? "#e0cf91" : biome === "desert" ? "#efc57b" : "#bd9658";
  ctx.fillRect(0,GROUND+12,W,H-GROUND);
  for(let x=0;x<W;x+=22){ctx.fillStyle=biome==="sea"?"#fff0b0":biome==="desert"?"#b8763c":"#397b32";ctx.fillRect(x-(frame*.35%22),GROUND+2,9,4);}
}
function drawPipe(p) {
  const g=ctx.createLinearGradient(p.x,0,p.x+58,0);
  g.addColorStop(0,"#135622");g.addColorStop(.25,"#36a832");g.addColorStop(.48,"#8df15a");g.addColorStop(.72,"#38b42d");g.addColorStop(1,"#104b1e");
  ctx.fillStyle=g;ctx.fillRect(p.x,0,58,p.top);ctx.fillRect(p.x,p.bottom,58,H-p.bottom);
  ctx.fillStyle="#2b8e2a";ctx.fillRect(p.x-5,p.top-18,68,18);ctx.fillRect(p.x-5,p.bottom,68,18);
  ctx.fillStyle="#c5ff94";ctx.fillRect(p.x+7,0,4,Math.max(0,p.top-18));ctx.fillRect(p.x+7,p.bottom+18,4,Math.max(0,H-p.bottom-18));
}
function drawBird() {
  ctx.save();
  const tilt = Math.max(-0.22, Math.min(0.35, bird.velocity * 0.035));
  ctx.translate(bird.x, bird.y); ctx.rotate(tilt);
  const pulse = Math.sin(frame * 0.15) * 1.5;
  if (faceImg.complete && faceImg.naturalWidth > 0) ctx.drawImage(faceImg, -45, -36 + pulse, 90, 72);
  else { ctx.fillStyle="#ffd52e"; ctx.beginPath(); ctx.ellipse(0,0,25,24,0,0,Math.PI*2); ctx.fill(); }
  ctx.restore();
}
function draw() {
  drawBackground(); for(const p of pipes)drawPipe(p); drawBird();
  ctx.save();ctx.textAlign="center";ctx.font="bold 34px Arial";ctx.lineWidth=4;ctx.strokeStyle="#24522c";ctx.strokeText(score,W/2,52);ctx.fillStyle="#fff";ctx.fillText(score,W/2,52);ctx.restore();
}
function update(delta) {
  if(!running||paused)return;
  const step=Math.min(delta/16.67,2);frame+=step;bird.velocity+=.19*step;bird.y+=bird.velocity*step;
  if(frame >= Math.max(76,112-score*1.2)){const gap=Math.max(158,210-score*1.1);const top=42+Math.random()*(GROUND-gap-84);pipes.push({x:W+5,top,bottom:top+gap,scored:false});frame=0;}
  for(const p of pipes){p.x-=Math.min(2.35,1.45+score*0.035)*step;if(!p.scored&&p.x+58<bird.x){p.scored=true;score++;scoreText.textContent=score;}
    const hitX=bird.x+18>p.x-5&&bird.x-18<p.x+63;const hitY=bird.y-35<p.top||bird.y+43>p.bottom;if(hitX&&hitY){endGame();return;}}
  pipes=pipes.filter(p=>p.x>-70);if(bird.y-37<0||bird.y+51>GROUND)endGame();
}
function loop(timestamp) {
  const delta=lastTime?timestamp-lastTime:16.67;lastTime=timestamp;
  if(!paused) update(delta); draw(); requestAnimationFrame(loop);
}
function flap() { if(!running||paused)return;initAudio();bird.velocity=-4.2;playTapSound(); }
startBtn.addEventListener("click",startGame);
document.getElementById("resumeBtn").addEventListener("click",resumeGame);
document.getElementById("restartBtn").addEventListener("click",startGame);
document.getElementById("homeBtn").addEventListener("click",goHome);
document.getElementById("playAgainBtn").addEventListener("click",startGame);
document.getElementById("overHomeBtn").addEventListener("click",goHome);
document.getElementById("shopBtn").addEventListener("click",openShop);
document.getElementById("shopBackBtn").addEventListener("click",()=>showPanel("homePanel","Waltisthbirth Chapri Game","Chapri Bird Adventure","😂🐦💨"));
pauseBtn.addEventListener("click",()=>{if(running&&paused)resumeGame();else pauseGame();});
document.getElementById("biomeSelect").addEventListener("change",e=>{biome=e.target.value;draw();});
document.getElementById("characterSelect").addEventListener("change",e=>{
  const id=e.target.value;
  if(saved.unlocked.includes(id)){selectedCharacter=id;saved.selected=id;saveGame();draw();}
  else {e.target.value=selectedCharacter;openShop();}
});
canvas.addEventListener("pointerdown",e=>{e.preventDefault();flap();});
musicBtn.addEventListener("click",()=>{initAudio();musicOn=!musicOn;musicBtn.textContent=musicOn?"🎵 Music ON":"🔇 Music OFF";if(musicOn)startMusic();else stopMusic();});
document.addEventListener("visibilitychange",()=>{if(document.hidden&&running&&!paused)pauseGame();});
resetGame();updateStats();document.getElementById("characterSelect").value=selectedCharacter;
if(faceImg.complete)draw();else faceImg.onload=draw;
requestAnimationFrame(loop);
