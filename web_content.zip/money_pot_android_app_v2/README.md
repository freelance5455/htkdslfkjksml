# My Money Pots — Android-friendly expense tracker (v3)

Offline-first Progressive Web App (PWA), not a compiled native APK. Transactions are stored in this browser on this device. No bank connection or cloud sync.

## Install on Android
1. Host all files in this folder on an HTTPS static host.
2. Open the HTTPS address in Chrome on Android.
3. Choose Chrome menu → **Install app** or **Add to Home screen**.
4. After the first load, the app can work offline.

## Features
- 14 main categories totaling ₹1,80,000/month.
- Flexible subcategories under **Investments** and **Utilities & recharges**; subcategories have no individual budgets or caps.
- Manual expense entry, parent-category balances, subcategory tracking, transaction history and deletion.
- Monthly and Monday–Sunday weekly reports.
- CSV export and JSON backup/restore.
- Existing v2 browser data is migrated automatically; the former “Investments (including SIP)” category is renamed “Investments”.

## Monthly category allocations
| Main category | Monthly budget |
|---|---:|
| Rent | ₹27,500 |
| Family support | ₹79,000 |
| School & child fees | ₹9,000 |
| Utilities & recharges | ₹4,600 |
| Car & transport | ₹12,000 |
| Insurance & medical | ₹5,250 |
| Groceries | ₹8,000 |
| Food & dining out | ₹2,500 |
| Kids — activities & essentials | ₹4,000 |
| Clothes & footwear | ₹1,500 |
| Household & personal care | ₹1,000 |
| Investments | ₹12,000 |
| Annual & irregular expenses | ₹8,000 |
| Miscellaneous & emergency savings | ₹5,650 |
| **Total** | **₹1,80,000** |

### Flexible subcategories (no separate limits)
- **Utilities & recharges:** Electricity; Mobile recharge; Broadband; DTH / TV; Other utilities.
- **Investments:** Mutual funds / SIP; Fixed savings (FD / RD); Shares / direct equity; PPF; NPS; Gold; Other investments.

## Data safety
Browser data can be erased if site data is cleared or the browser/app is uninstalled. Export a JSON backup regularly and store it safely. CSV is for spreadsheet analysis; JSON restores app data.

These are virtual budgeting categories, not separate bank deposits. Record investment contributions or reserve transfers as transactions only if you want them included in the recorded outflow totals.
