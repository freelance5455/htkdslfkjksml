ASISTENCIA QJMOTOR — PROYECTO ANDROID

Incluye la versión HTML local y sin dependencias externas. PIN configurado: 0602.
No solicita permiso de Internet.

CÓMO GENERAR EL APK CON ANDROID STUDIO
1. Instala Android Studio en un ordenador.
2. Descomprime este ZIP.
3. Android Studio > Open > selecciona la carpeta QJMotorAndroid.
4. Espera a que termine la sincronización de Gradle (requiere conexión la primera vez para descargar herramientas).
5. Menú Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio mostrará un aviso con la opción Locate para abrir el APK generado.

Nota: este ZIP contiene el proyecto fuente listo para compilar, no un APK ya compilado.
El PIN es un bloqueo de interfaz, no cifrado de los datos del HTML.
