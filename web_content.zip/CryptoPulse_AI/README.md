# CryptoPulse AI — Android starter project

A mobile-first, offline-first crypto signal research app. It does **not** place trades.

## Included
- Live Binance public market ticker and OHLC candles (internet required)
- RSI, EMA 20/50, MACD multi-indicator scoring
- Basic candlestick pattern flags (engulfing, hammer-like, shooting-star-like, doji)
- Rule-alignment confidence score (not a probability)
- Historical candle backtest with conservative same-candle stop/target handling
- BUY / SELL / HOLD labels, illustrative entry/stop/target levels
- Local signal history and CSV export
- Service-worker caching and offline cached-price display
- Capacitor Android wrapper configuration

## Important limitations
- Signals are heuristic indicator rules, **not a trained predictive AI model; the confidence display is rule alignment, not a probability** and not guaranteed.
- Offline mode cannot receive live prices or new market candles. It can show cached data and app interface.
- No profitability or accuracy is claimed. Add walk-forward backtesting, fees, slippage and out-of-sample evaluation before relying on any strategy.
- Public Binance API is used without authentication. API availability and regional access may vary.

## Run as a web app
Serve this folder over localhost or HTTPS (service workers do not work reliably from file://):
```bash
python -m http.server 8080
```

## Build Android APK
Requires Node.js 20+, Android Studio, Android SDK and Java 17:
```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```
In Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s).
Debug APK output is usually `android/app/build/outputs/apk/debug/app-debug.apk`.

For a signed release APK, configure a release signing key in Android Studio. Never share your private signing key.

## Before real-money use
Backtest each timeframe across bull, bear and sideways regimes. Include trading fees, spread, slippage and realistic fills. Track signal outcomes separately from raw signal count. This starter intentionally does not connect to exchange trading or request API keys.
