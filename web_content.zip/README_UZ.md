# JARVIS V9 — GREEN TERMINAL EDITION

A phone-friendly HTML/CSS/JavaScript assistant starter with a restrained hacker-terminal aesthetic.

## Included
- Dark black + green terminal-inspired UI.
- Animated reactor and voice waveform.
- Five original generated WAV interface sound effects: startup, click, listening, response, error.
- Sound-effects toggle in Settings.
- Chat UI, speech input/output where browser support exists.
- Quick links and YouTube/Google search commands.
- Configurable OpenAI-compatible chat-completions endpoint.

## Import
Extract this ZIP if your HTML-to-APK builder does not accept ZIP directly. Select `index.html` as the start page and keep the `style.css`, `app.js`, `manifest.json`, `sw.js`, and `assets` folder beside it. Enable Internet and microphone permissions if requested.

## API setup and security
Add your own compatible endpoint, model and API key in Settings. The key is held only in the current page session, but a key in a client-side app is not truly secret. For a distributed APK, route requests through a backend/proxy you control. Free-tier limits and model availability depend on the provider.

## Honest Android limits
This HTML app cannot independently control every other Android app, read contacts, type into arbitrary apps, or continuously listen in the background. Those capabilities require a separate native Android implementation, explicit permissions and user-approved Accessibility Service. Sensitive actions such as sending a message should require confirmation. A web APK wrapper does not automatically provide these privileges.
