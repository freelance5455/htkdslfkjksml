# Xhouse — yakuniy birlashtirilgan loyiha

Bu arxiv ichida alohida ZIP fayllar yo‘q. Saytning ishlaydigan loyiha fayllari bevosita arxiv ildizida joylashgan.

## Tarkibi
- Bosh sahifa va Xhouse dizayni
- Video kartalari, qidiruv va sahifa ichida video pleer
- Video pleer ostida tavsiya etiladigan videolar
- Telefon/planshet/kompyuterga moslashuv
- Til tanlagich (ko‘p tilli interfeys)
- Mobil pull-to-refresh
- Admin panel (`/admin.html`) va Netlify Functions
- Xavfsizlik sarlavhalari hamda `.env.example`

## Netlify’ga joylash
1. Arxivni oching. `index.html`, `netlify.toml`, `netlify/` va qolgan fayllar bir papkada bo‘lishi kerak.
2. Shu papkani Netlify’ga deploy qiling (yoki Git repository’ga yuklang).
3. Netlify Environment variables ichida `.env.example` dagi kerakli kalitlarni to‘ldiring. `ADMIN_USERNAME`, `ADMIN_PASSWORD`, `SESSION_SECRET` va video provayder API kaliti loyiha sozlamasiga qarab kerak bo‘lishi mumkin.
4. Deploy tugagach, `/admin.html` sahifasini tekshiring.

Eslatma: ZIP fayl kodning nusxasi. U Netlify’dagi jonli saytni avtomatik o‘zgartirmaydi va serverdagi oldingi ma’lumotlarni o‘z-o‘zidan tiklamaydi. Jonli saytdagi video ro‘yxati Netlify Blobs yoki video provayder hisobida saqlangan bo‘lsa, o‘sha ma’lumotlar alohida saqlanadi.
