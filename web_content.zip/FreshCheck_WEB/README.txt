FreshCheck - Web App

This ZIP is a web app package intended for Web-to-APK converters.
Open/use index.html as the entry page.

Important:
- Keep index.html at the root of the ZIP.
- Keep logo.png at the root of the ZIP.
- This package is a website/PWA-style app, not a native Android project.
- For a Web-to-APK converter, choose a Website/Web App project, not Native/Gradle.
