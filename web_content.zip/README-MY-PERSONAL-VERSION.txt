YOUR PERSONAL MOBILE APP (Pre-loaded with all 184 days of your meals & weight logs: Apr 18 - Oct 19, 2026, 86.0 kg -> 74.5 kg).

Open MacroPulse-My-Personal-App.html on your phone and tap Add to Home Screen / Install App.