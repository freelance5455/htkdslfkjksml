/* ============ TradeJournal - Core Application Logic ============ */
const $ = id => document.getElementById(id);
const LS = {
  get(k, d) { try { const v = localStorage.getItem(k); return v === null ? d : v; } catch(e){ return d; } },
  set(k, v) { try { localStorage.setItem(k, v); return true; } catch(e){ return false; } }
};
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const cl = n => n > 0 ? 'pos' : (n < 0 ? 'neg' : '');
const localISO = (d = new Date()) => new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16);

function toast(msg, type = 'info') {
  const box = $('toasts');
  if (!box) return;
  const el = document.createElement('div');
  el.className = 'toast';
  el.textContent = msg;
  if (type === 'error') el.style.borderColor = 'var(--r)';
  if (type === 'success') el.style.borderColor = 'var(--g)';
  box.appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; setTimeout(() => el.remove(), 250); }, 3000);
}

/* ============ Traductions I18N ============ */
const I18N = {
  fr: {
    allAcc:'Tous les comptes', accReal:'Compte Réel', accProp:'Prop Firm', accDemo:'Compte Démo',
    nDash:'Dashboard', nJournal:'Journal', nCal:'Calendrier', nRisk:'Risque', nNews:'News FF', nChart:'Chart TV', nIct:'Cours ICT', nSess:'Sessions', nRep:'Rapports',
    monthGoal:'Objectif de profit mensuel', equity:"Courbe d'équité", sessPnl:'P&L par Session', symPnl:'P&L par Symbole',
    netPnl:'Net P&L', winRate:'Win Rate', pf:'Profit Factor', discipline:'Discipline', maxDD:'Max Drawdown', trades:'Trades', discOk:'% OK',
    noSessData:'Aucun trade enregistré pour le moment.', addTradesCurve:'Ajoutez des trades pour tracer la courbe.',
    newTrade:'Nouveau trade', editTrade:'Modifier le trade', cancel:'Annuler', account:'Compte', datetime:'Date & Heure', session:'Session', symbol:'Symbole', side:'Sens',
    entry:'Entrée', exit:'Sortie', riskUsd:'Risque ($)', pnlUsd:'P&L ($)', mood:'État émotionnel', planOk:'Plan respecté ?', yes:'Oui', no:'Non',
    so_Londres:'Londres (08h - 17h UTC)', 'so_New York':'New York (13h - 22h UTC)', so_Asie:'Asie (00h - 09h UTC)', 'so_Chevauchement NY-Londres':'Overlap Londres/NY (13h - 17h UTC)',
    s_Londres:'Londres', 's_New York':'New York', s_Asie:'Asie', 's_Chevauchement NY-Londres':'Overlap Londres/NY',
    m_Neutre:'Calme / Neutre', m_Confiant:'Confiant', m_Stressé:'Stressé', m_Impatient:'Impatient', m_FOMO:'FOMO / Revanche',
    screenshot:"Capture d'écran (Graphique)", notes:'Notes & Analyses', notesPh:'Setup, sweep, FVG, confirmation...',
    save:'Enregistrer le trade', update:'Mettre à jour', tradeDetail:'Détail du trade', history:'Historique des Trades',
    thDate:'Date', thAcc:'Compte', thSess:'Session', thSym:'Symbole', thMood:'État', thPlan:'Plan',
    noNote:'Aucune note', note:'Note', reqFields:'Le symbole et le P&L sont obligatoires.', confirmDel:'Supprimer ce trade ?', confirmReset:'ATTENTION : Réinitialiser toutes vos données de trading ?',
    calHint:'Cliquez sur un jour pour saisir un trade ou filtrer.',
    dow:['Dim','Lun','Mar','Mer','Jeu','Ven','Sam'],
    posCalc:'Calculateur de taille de position', capital:'Capital ($)', riskPct:'Risque %',
    riskAmt:'Risque ($)', units:'Unités', lotsL:'Lots', badInputs:'Vérifiez vos prix d\'entrée et de Stop Loss.',
    propMon:'Moniteur Prop-Firm & Drawdown', accSize:'Capital Initial ($)', dayLimit:'Limite Perte Jour %', maxDDpct:'Max Trailing DD %',
    todayPnl:"P&L d'aujourd'hui", dayLossUsed:'Perte jour consommée', totalLossUsed:'Trailing Drawdown consommé', trailDD:'Drawdown Max Historique',
    dayAlert:'⚠️ Limite de perte journalière dépassée ! Stoppez le trading.', totalAlert:'⚠️ Drawdown maximal Prop Firm atteint !', nearAlert:'⚠️ Attention : Vous êtes à plus de 80% de votre drawdown max.',
    riskMetrics:'Métriques Avancées de Risque', avgWin:'Gain Moyen', avgLoss:'Perte Moyenne', payoff:'Ratio Gain/Perte', expectancy:'Espérance / Trade', lossStreak:'Max Pertes d\'affilée', best:'Meilleur Trade', worst:'Pire Trade', avgR:'R Moyen',
    ffTitle:'Calendrier Économique Forex Factory (En direct)', refresh:'Actualiser', lastUpdate:'Dernière MAJ', loading:'Chargement des news Forex Factory…',
    filterImp:'Impact', filterCur:'Devise', fDay:'Période', allDays:'Toute la semaine', todayLabel:"Aujourd'hui", allCur:'Toutes les devises', impAll:'Tous les impacts', impMedHigh:'Moyen + Élevé', impHighOnly:'Élevé uniquement (Fort)',
    thTime:'Heure', thForecast:'Prév.', thPrev:'Préc.', thLeft:'Dans', customEvents:'+ Ajouter un événement personnalisé manuel', evName:'Nom événement', evDate:'Date & Heure', evCur:'Devise', evImp:'Impact',
    impHigh:'Élevé', impMed:'Moyen', impLow:'Faible', evAddBtn:'Ajouter', alertBefore:'Alerte avant l\'annonce',
    tradingSessions:'Horloges & Sessions de Marché', timezone:'Fuseau Horaire d\'affichage', tzAlg:'Algérie / Paris (UTC+1)', tzLocal:"Heure locale de l'appareil",
    open:'Ouverte', closed:'Fermée', closesIn:'ferme dans', opensIn:'ouvre dans', weekend:'🕒 Week-end : Marchés Forex fermés.',
    reports:'Rapports & Exportation', copyCsv:'Copier le CSV', copied:'Copié ✓', dlCsv:'Télécharger le CSV', print:'Imprimer / PDF', backup:'Sauvegarde & Restauration', exportJson:'Exporter JSON', importJson:'Importer JSON',
    nChart:'Chart TV', chartTitle:'Graphique Interactif TradingView', tf:'Unité de temps', otherSym:'Symbole Personnalisé', toRisk:'Calculer Risque', toJournal:'Trader', fullscreen:'Plein écran',
    ictTitle:'Cours & Modèles d\'Entrée ICT (Inner Circle Trader)', filterLang:'Langue des vidéos', filterTopic:'Modèle / Concept ICT',
    sendJ:'Envoyer au Journal', specNote:'Spécifications indicatives standard.', auto:'Automatique', rrLbl:'Ratio R:R cible',
    slDist:'Distance SL', pipValLot:'Valeur Pip / Lot', riskReal:'Risque Réel', tpPrice:'TP Estimé', gain:'Gain Estimé'
  },
  en: {
    allAcc:'All accounts', accReal:'Live Account', accProp:'Prop Firm', accDemo:'Demo Account',
    nDash:'Dashboard', nJournal:'Journal', nCal:'Calendar', nRisk:'Risk', nNews:'FF News', nChart:'Chart TV', nIct:'ICT Courses', nSess:'Sessions', nRep:'Reports',
    monthGoal:'Monthly profit goal', equity:'Equity curve', sessPnl:'P&L by Session', symPnl:'P&L by Symbol',
    netPnl:'Net P&L', winRate:'Win Rate', pf:'Profit Factor', discipline:'Discipline', maxDD:'Max Drawdown', trades:'Trades', discOk:'% OK',
    noSessData:'No trades recorded yet.', addTradesCurve:'Add trades to generate the equity curve.',
    newTrade:'New trade', editTrade:'Edit Trade', cancel:'Cancel', account:'Account', datetime:'Date & Time', session:'Session', symbol:'Symbol', side:'Side',
    entry:'Entry', exit:'Exit', riskUsd:'Risk ($)', pnlUsd:'P&L ($)', mood:'Emotional State', planOk:'Followed plan?', yes:'Yes', no:'No',
    so_Londres:'London (08:00 - 17:00 UTC)', 'so_New York':'New York (13:00 - 22:00 UTC)', so_Asie:'Asia (00:00 - 09:00 UTC)', 'so_Chevauchement NY-Londres':'London/NY Overlap (13:00 - 17:00 UTC)',
    s_Londres:'London', 's_New York':'New York', s_Asie:'Asia', 's_Chevauchement NY-Londres':'London/NY Overlap',
    m_Neutre:'Calm / Neutral', m_Confiant:'Confident', m_Stressé:'Stressed', m_Impatient:'Impatient', m_FOMO:'FOMO / Revenge',
    screenshot:'Screenshot (Chart)', notes:'Notes & Analyses', notesPh:'Setup, sweep, FVG, confluence...',
    save:'Save trade', update:'Update Trade', tradeDetail:'Trade Details', history:'Trade History',
    thDate:'Date', thAcc:'Account', thSess:'Session', thSym:'Symbol', thMood:'Mood', thPlan:'Plan',
    noNote:'No note', note:'Note', reqFields:'Symbol and P&L are required.', confirmDel:'Delete this trade?', confirmReset:'WARNING: Clear all your trading data?',
    calHint:'Click on any day to log or inspect trades.',
    dow:['Sun','Mon','Tue','Wed','Thu','Fri','Sat'],
    posCalc:'Position Size Calculator', capital:'Capital ($)', riskPct:'Risk %',
    riskAmt:'Risk ($)', units:'Units', lotsL:'Lots', badInputs:'Please check entry and stop loss values.',
    propMon:'Prop-Firm & Drawdown Monitor', accSize:'Initial Balance ($)', dayLimit:'Daily Loss Limit %', maxDDpct:'Max Trailing DD %',
    todayPnl:"Today's P&L", dayLossUsed:'Daily Loss Consumed', totalLossUsed:'Trailing DD Consumed', trailDD:'Historical Max DD',
    dayAlert:'⚠️ Daily loss limit exceeded! Halt your trading.', totalAlert:'⚠️ Max Prop Firm drawdown hit!', nearAlert:'⚠️ Warning: You used over 80% of allowed drawdown.',
    riskMetrics:'Advanced Risk Metrics', avgWin:'Avg Win', avgLoss:'Avg Loss', payoff:'Win/Loss Ratio', expectancy:'Expectancy / Trade', lossStreak:'Max Consecutive Losses', best:'Best Trade', worst:'Worst Trade', avgR:'Avg R',
    ffTitle:'Forex Factory Economic Calendar (Live)', refresh:'Refresh', lastUpdate:'Last Update', loading:'Loading Forex Factory news…',
    filterImp:'Impact', filterCur:'Currency', fDay:'Period', allDays:'All week', todayLabel:'Today', allCur:'All Currencies', impAll:'All Impacts', impMedHigh:'Medium + High', impHighOnly:'High Only (Major)',
    thTime:'Time', thForecast:'Fcst', thPrev:'Prev', thLeft:'In', customEvents:'+ Add Custom Event', evName:'Event Name', evDate:'Date & Time', evCur:'Currency', evImp:'Impact',
    impHigh:'High', impMed:'Medium', impLow:'Low', evAddBtn:'Add', alertBefore:'Alert Before',
    tradingSessions:'Market Hours & Clocks', timezone:'Display Timezone', tzAlg:'Algeria / Paris (UTC+1)', tzLocal:'Device Local Time',
    open:'Open', closed:'Closed', closesIn:'closes in', opensIn:'opens in', weekend:'🕒 Weekend: Forex markets are closed.',
    reports:'Reports & Export', copyCsv:'Copy CSV', copied:'Copied ✓', dlCsv:'Download CSV', print:'Print / PDF', backup:'Backup & Restore', exportJson:'Export JSON', importJson:'Import JSON',
    nChart:'Chart TV', chartTitle:'Interactive TradingView Chart', tf:'Timeframe', otherSym:'Custom Symbol', toRisk:'Calculate Risk', toJournal:'Trade', fullscreen:'Full Screen',
    ictTitle:'ICT (Inner Circle Trader) Courses & Entry Models', filterLang:'Video Language', filterTopic:'ICT Model / Concept',
    sendJ:'Send to Journal', specNote:'Standard specifications.', auto:'Auto', rrLbl:'Target R:R',
    slDist:'SL Distance', pipValLot:'Pip Value / Lot', riskReal:'Actual Risk', tpPrice:'Estimated TP', gain:'Estimated Gain'
  }
};

let LANG = LS.get('tj-lang', 'fr');
if (!I18N[LANG]) LANG = 'fr';
const t = k => (I18N[LANG] && I18N[LANG][k] !== undefined) ? I18N[LANG][k] : ((I18N.fr && I18N.fr[k] !== undefined) ? I18N.fr[k] : k);
const LOC = () => (LANG === 'fr' ? 'fr-FR' : 'en-US');
const m = n => (n < 0 ? '-' : '') + '$' + Math.abs(n || 0).toLocaleString(LOC(), { maximumFractionDigits: 0 });
const m2 = n => (n < 0 ? '-' : '') + '$' + Math.abs(n || 0).toLocaleString(LOC(), { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const accKey = { 'Réel': 'accReal', 'Prop Firm': 'accProp', 'Démo': 'accDemo' };
const accName = v => t(accKey[v] || 'accReal');

/* ============ Données & État ============ */
let T = [];
let EVS = [];
let editingTradeId = null;
let currentBase64Image = '';
let curCalDate = new Date(); curCalDate.setDate(1);

try { T = JSON.parse(LS.get('tj-trades', '[]')) || []; } catch(e){ T = []; }
try { EVS = JSON.parse(LS.get('tj-events', '[]')) || []; } catch(e){ EVS = []; }
if ($('monthlyGoalInput')) $('monthlyGoalInput').value = LS.get('tj-goal', '1000');

function saveTrades() { LS.set('tj-trades', JSON.stringify(T)); }
function saveEvents() { LS.set('tj-events', JSON.stringify(EVS)); }

/* ============ Thème ============ */
function effTheme() { return document.documentElement.getAttribute('data-theme') || 'dark'; }
function setTheme(th) {
  document.documentElement.setAttribute('data-theme', th);
  LS.set('tj-theme', th);
  const mt = document.querySelector('meta[name=theme-color]');
  if (mt) mt.content = th === 'dark' ? '#0d141b' : '#ffffff';
  if ($('th')) $('th').textContent = th === 'dark' ? '☀' : '☾';
}
setTheme(LS.get('tj-theme', 'dark'));
if ($('th')) {
  $('th').onclick = () => {
    setTheme(effTheme() === 'dark' ? 'light' : 'dark');
    if ($('t-g') && $('t-g').classList.contains('on')) renderChart();
  };
}

/* ============ Filtres ============ */
function getFilteredTrades() {
  const acc = $('accFilter') ? $('accFilter').value : 'ALL';
  return acc === 'ALL' ? T : T.filter(x => (x.account || 'Réel') === acc);
}
function sortedTrades() {
  return [...getFilteredTrades()].sort((a,b) => (a.date || '').localeCompare(b.date || ''));
}

/* ============ Calculs & Métriques ============ */
function getMetrics() {
  const s = sortedTrades();
  const w = s.filter(x => x.pl > 0);
  const l = s.filter(x => x.pl < 0);
  const gp = w.reduce((a, x) => a + x.pl, 0);
  const gl = Math.abs(l.reduce((a, x) => a + x.pl, 0));
  
  let eq = 0, pk = 0, maxDD = 0;
  const curve = [{ pl: 0, eq: 0, date: '' }];
  s.forEach(x => {
    eq += x.pl;
    curve.push({ pl: x.pl, eq, date: x.date });
    if (eq > pk) pk = eq;
    const curDD = pk - eq;
    if (curDD > maxDD) maxDD = curDD;
  });
  
  const planOk = s.filter(x => x.plan === 'Oui').length;
  const discScore = s.length ? Math.round((planOk / s.length) * 100) : 100;
  const pf = gl > 0 ? (gp / gl) : (gp > 0 ? Infinity : 0);
  const wr = s.length ? (w.length / s.length) * 100 : 0;
  
  return { n: s.length, net: eq, wr, pf, maxDD, curve, discScore };
}

/* ============ Dashboard : Graphique Équité SVG ============ */
function renderEquitySVG(curve) {
  if (!$('eq')) return;
  if (curve.length < 2) {
    $('eq').innerHTML = `<p style="color:var(--mut);text-align:center;padding:40px 0">${t('addTradesCurve')}</p>`;
    return;
  }
  const vals = curve.map(c => c.eq);
  const mn = Math.min(0, ...vals);
  const mx = Math.max(0, ...vals);
  const range = (mx - mn) || 1;
  const W = 700, H = 220, padTop = 15, padBottom = 25, padLeft = 45, padRight = 15;
  const pw = W - padLeft - padRight;
  const ph = H - padTop - padBottom;
  
  const getY = val => padTop + ph - ((val - mn) / range) * ph;
  const getX = idx => padLeft + (idx / (curve.length - 1)) * pw;
  
  const zeroY = getY(0);
  const points = curve.map((c, i) => `${getX(i).toFixed(1)},${getY(c.eq).toFixed(1)}`).join(' ');
  const areaPoints = `${points} ${getX(curve.length - 1)},${zeroY} ${getX(0)},${zeroY}`;
  
  let svg = `<svg viewBox="0 0 ${W} ${H}" style="width:100%;height:auto;overflow:visible">
    <defs>
      <linearGradient id="eqGrad" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="var(--g)" stop-opacity="0.35"/>
        <stop offset="100%" stop-color="var(--g)" stop-opacity="0.0"/>
      </linearGradient>
    </defs>
    <line x1="${padLeft}" x2="${W - padRight}" y1="${zeroY}" y2="${zeroY}" stroke="var(--bd)" stroke-dasharray="3 3"/>
    <text x="${padLeft - 8}" y="${zeroY + 4}" fill="var(--mut)" font-size="10" text-anchor="end">$0</text>
    <text x="${padLeft - 8}" y="${padTop + 8}" fill="var(--mut)" font-size="10" text-anchor="end">${m(mx)}</text>
    <text x="${padLeft - 8}" y="${H - padBottom}" fill="var(--mut)" font-size="10" text-anchor="end">${m(mn)}</text>
    
    <polygon points="${areaPoints}" fill="url(#eqGrad)"/>
    <polyline fill="none" stroke="var(--g)" stroke-width="2.5" points="${points}"/>`;
    
  curve.forEach((c, i) => {
    if (i === 0) return;
    const cx = getX(i);
    const cy = getY(c.eq);
    svg += `<circle cx="${cx}" cy="${cy}" r="3.5" fill="var(--card)" stroke="${c.pl >= 0 ? 'var(--g)' : 'var(--r)'}" stroke-width="2">
      <title>Trade #${i}: ${c.pl >= 0 ? '+' : ''}${m2(c.pl)} (Total: ${m2(c.eq)})</title>
    </circle>`;
  });
  svg += `</svg>`;
  $('eq').innerHTML = svg;
}

function renderDash() {
  const mtr = getMetrics();
  if ($('stats')) {
    $('stats').innerHTML = [
      [t('netPnl'), `<span class="${cl(mtr.net)}">${m2(mtr.net)}</span>`],
      [t('winRate'), `${mtr.wr.toFixed(1)}%`],
      [t('pf'), isFinite(mtr.pf) ? mtr.pf.toFixed(2) : '∞'],
      [t('discipline'), `${mtr.discScore}%`],
      [t('maxDD'), `<span class="neg">${m2(-mtr.maxDD)}</span>`],
      [t('trades'), mtr.n]
    ].map(a => `<div class="stat"><small>${a[0]}</small><b>${a[1]}</b></div>`).join('');
  }

  const now = new Date();
  const curMonthStr = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}`;
  const monthPnL = getFilteredTrades().filter(x => x.date && x.date.startsWith(curMonthStr)).reduce((a, x) => a + x.pl, 0);
  const goal = +($('monthlyGoalInput') ? $('monthlyGoalInput').value : 1000) || 1000;
  const pct = Math.max(0, Math.min(100, (monthPnL / goal) * 100));
  if ($('objText')) $('objText').textContent = `${m2(monthPnL)} / ${m(goal)} (${pct.toFixed(0)}%)`;
  if ($('objBar')) {
    $('objBar').style.width = pct + '%';
    $('objBar').style.background = monthPnL >= 0 ? 'var(--g)' : 'var(--r)';
  }

  if ($('eqCount')) $('eqCount').textContent = `${mtr.n} trade${mtr.n > 1 ? 's' : ''}`;
  renderEquitySVG(mtr.curve);

  const sm = {};
  getFilteredTrades().forEach(x => { const k = x.sess || 'Londres'; sm[k] = (sm[k] || 0) + x.pl; });
  const se = Object.entries(sm).sort((a,b) => b[1] - a[1]);
  if ($('sessStats')) $('sessStats').innerHTML = se.length ? renderBarRows(se, 160, k => t('s_' + k)) : `<p style="color:var(--mut);font-size:12px">${t('noSessData')}</p>`;

  const gm = {};
  getFilteredTrades().forEach(x => { const k = x.sym || 'OTHER'; gm[k] = (gm[k] || 0) + x.pl; });
  const ge = Object.entries(gm).sort((a,b) => b[1] - a[1]);
  if ($('sym')) $('sym').innerHTML = ge.length ? renderBarRows(ge, 80, k => k) : `<p style="color:var(--mut);font-size:12px">${t('noSessData')}</p>`;
}

function renderBarRows(entries, labelW, labelFn) {
  const mx = Math.max(1, ...entries.map(a => Math.abs(a[1])));
  return entries.map(([k, v]) => `
    <div class="row" style="margin:6px 0;flex-wrap:nowrap">
      <span style="width:${labelW}px;flex:none;font-size:12px">${esc(labelFn(k))}</span>
      <div class="bar" style="flex:1">
        <i style="width:${(Math.abs(v)/mx*100).toFixed(1)}%;background:${v >= 0 ? 'var(--g)' : 'var(--r)'}"></i>
      </div>
      <b class="${cl(v)}" style="width:90px;text-align:right;flex:none;font-size:12px">${m2(v)}</b>
    </div>`).join('');
}
if ($('monthlyGoalInput')) {
  $('monthlyGoalInput').oninput = () => { LS.set('tj-goal', $('monthlyGoalInput').value); renderDash(); };
}

/* ============ Journal des Trades ============ */
function renderTradeList() {
  const q = ($('tradeSearch') ? $('tradeSearch').value : '').trim().toLowerCase();
  const allT = sortedTrades().reverse();
  const filtered = allT.filter(x => {
    if (!q) return true;
    return (x.sym || '').toLowerCase().includes(q) ||
           (x.note || '').toLowerCase().includes(q) ||
           (x.account || '').toLowerCase().includes(q);
  });

  if ($('tradeCountLbl')) $('tradeCountLbl').textContent = `(${filtered.length} / ${allT.length})`;
  let h = `<tr>
    <th>${t('thDate')}</th>
    <th>${t('thAcc')}</th>
    <th>${t('thSess')}</th>
    <th>${t('thSym')}</th>
    <th>${t('side')}</th>
    <th>P&amp;L</th>
    <th>${t('thMood')}</th>
    <th>${t('thPlan')}</th>
    <th>Action</th>
  </tr>`;

  if (!filtered.length) {
    h += `<tr><td colspan="9" style="text-align:center;padding:24px;color:var(--mut)">Aucun trade trouvé.</td></tr>`;
  } else {
    h += filtered.map(x => `
      <tr data-id="${esc(x.id)}" style="cursor:pointer">
        <td>${esc((x.date || '').replace('T', ' '))}</td>
        <td><small>${esc(accName(x.account || 'Réel'))}</small></td>
        <td><small>${esc(t('s_' + (x.sess || 'Londres')))}</small></td>
        <td><b>${esc(x.sym)}</b></td>
        <td><span class="${x.side === 'Long' ? 'pos' : 'neg'}">${esc(x.side || 'Long')}</span></td>
        <td class="${cl(x.pl)}" style="font-weight:700">${m2(x.pl)}</td>
        <td>${esc(t('m_' + (x.mood || 'Neutre')))}</td>
        <td>${x.plan === 'Oui' ? '✅' : '❌'}</td>
        <td>
          <button class="btn s" data-edit="${esc(x.id)}" style="padding:3px 7px;font-size:11px" title="Modifier">✎</button>
          <button class="btn s" data-del="${esc(x.id)}" style="padding:3px 7px;font-size:11px" title="Supprimer">✕</button>
        </td>
      </tr>`).join('');
  }
  if ($('tb')) $('tb').innerHTML = h;
}
if ($('tradeSearch')) $('tradeSearch').oninput = renderTradeList;

// Gestion images
if ($('imgInput')) {
  $('imgInput').onchange = e => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      const img = new Image();
      img.onload = () => {
        const maxDim = 1200;
        let w = img.width, h = img.height;
        if (w > maxDim || h > maxDim) {
          if (w > h) { h = Math.round(h * (maxDim / w)); w = maxDim; }
          else { w = Math.round(w * (maxDim / h)); h = maxDim; }
        }
        const canvas = document.createElement('canvas');
        canvas.width = w; canvas.height = h;
        canvas.getContext('2d').drawImage(img, 0, 0, w, h);
        currentBase64Image = canvas.toDataURL('image/jpeg', 0.75);
        if ($('imgPreview')) {
          $('imgPreview').src = currentBase64Image;
          $('imgPreview').style.display = 'block';
        }
        if ($('delImgBtn')) $('delImgBtn').style.display = 'block';
      };
      img.src = ev.target.result;
    };
    reader.readAsDataURL(file);
  };
}
if ($('delImgBtn')) {
  $('delImgBtn').onclick = () => {
    currentBase64Image = '';
    if ($('imgPreview')) {
      $('imgPreview').style.display = 'none';
      $('imgPreview').src = '';
    }
    $('delImgBtn').style.display = 'none';
    if ($('imgInput')) $('imgInput').value = '';
  };
}

function resetTradeForm() {
  editingTradeId = null;
  if ($('formTitle')) $('formTitle').textContent = t('newTrade');
  if ($('saveTradeBtn')) $('saveTradeBtn').textContent = t('save');
  if ($('cancelEditBtn')) $('cancelEditBtn').style.display = 'none';
  ['s','en','ex','sl','tp','rk','pnlInput','nt'].forEach(id => { if ($(id)) $(id).value = ''; });
  if ($('d')) $('d').value = localISO();
  currentBase64Image = '';
  if ($('imgPreview')) {
    $('imgPreview').style.display = 'none';
    $('imgPreview').src = '';
  }
  if ($('delImgBtn')) $('delImgBtn').style.display = 'none';
  if ($('imgInput')) $('imgInput').value = '';
}
if ($('cancelEditBtn')) $('cancelEditBtn').onclick = resetTradeForm;

if ($('saveTradeBtn')) {
  $('saveTradeBtn').onclick = () => {
    const sym = ($('s') ? $('s').value : '').trim().toUpperCase();
    const pnlRaw = $('pnlInput') ? $('pnlInput').value : '';
    if (!sym || pnlRaw === '') {
      toast(t('reqFields'), 'error');
      return;
    }
    const n = id => ($(id) && $(id).value !== '') ? +$(id).value : null;
    const tradeData = {
      account: $('acc') ? $('acc').value : 'Réel',
      sess: $('sess') ? $('sess').value : 'Londres',
      date: ($('d') && $('d').value) ? $('d').value : localISO(),
      sym,
      side: $('sd') ? $('sd').value : 'Long',
      en: n('en'),
      ex: n('ex'),
      sl: n('sl'),
      tp: n('tp'),
      rk: n('rk') || 0,
      pl: +pnlRaw,
      mood: $('mood') ? $('mood').value : 'Neutre',
      plan: $('plan') ? $('plan').value : 'Oui',
      note: $('nt') ? $('nt').value.trim() : '',
      img: currentBase64Image
    };

    if (editingTradeId) {
      const idx = T.findIndex(x => x.id === editingTradeId);
      if (idx !== -1) {
        T[idx] = { ...T[idx], ...tradeData };
        toast('Trade mis à jour avec succès.', 'success');
      }
    } else {
      tradeData.id = 't_' + Date.now() + Math.random().toString(36).substring(2, 6);
      T.push(tradeData);
      toast('Nouveau trade enregistré.', 'success');
    }

    saveTrades();
    resetTradeForm();
    renderAll();
  };
}

function startEditTrade(tr) {
  editingTradeId = tr.id;
  if ($('formTitle')) $('formTitle').textContent = t('editTrade');
  if ($('saveTradeBtn')) $('saveTradeBtn').textContent = t('update');
  if ($('cancelEditBtn')) $('cancelEditBtn').style.display = 'inline-block';
  
  if ($('acc')) $('acc').value = tr.account || 'Réel';
  if ($('sess')) $('sess').value = tr.sess || 'Londres';
  if ($('d')) $('d').value = tr.date || localISO();
  if ($('s')) $('s').value = tr.sym || '';
  if ($('sd')) $('sd').value = tr.side || 'Long';
  if ($('en')) $('en').value = tr.en ?? '';
  if ($('ex')) $('ex').value = tr.ex ?? '';
  if ($('sl')) $('sl').value = tr.sl ?? '';
  if ($('tp')) $('tp').value = tr.tp ?? '';
  if ($('rk')) $('rk').value = tr.rk ?? '';
  if ($('pnlInput')) $('pnlInput').value = tr.pl ?? '';
  if ($('mood')) $('mood').value = tr.mood || 'Neutre';
  if ($('plan')) $('plan').value = tr.plan || 'Oui';
  if ($('nt')) $('nt').value = tr.note || '';

  if (tr.img) {
    currentBase64Image = tr.img;
    if ($('imgPreview')) {
      $('imgPreview').src = tr.img;
      $('imgPreview').style.display = 'block';
    }
    if ($('delImgBtn')) $('delImgBtn').style.display = 'block';
  } else {
    currentBase64Image = '';
    if ($('imgPreview')) $('imgPreview').style.display = 'none';
    if ($('delImgBtn')) $('delImgBtn').style.display = 'none';
  }
  showTab('j');
  if ($('formTitle')) window.scrollTo({ top: $('formTitle').offsetTop - 60, behavior: 'smooth' });
}

if ($('tb')) {
  $('tb').onclick = e => {
    const editId = e.target.dataset.edit;
    if (editId) {
      const tr = T.find(x => x.id === editId);
      if (tr) startEditTrade(tr);
      return;
    }
    const delId = e.target.dataset.del;
    if (delId) {
      if (confirm(t('confirmDel'))) {
        T = T.filter(x => x.id !== delId);
        saveTrades();
        toast('Trade supprimé.', 'info');
        renderAll();
      }
      return;
    }
    const row = e.target.closest('tr[data-id]');
    if (row) {
      const tr = T.find(x => x.id === row.dataset.id);
      if (tr) openDetailModal(tr);
    }
  };
}

/* ============ Modale Détail ============ */
let curModalTrade = null;
function openDetailModal(tr) {
  curModalTrade = tr;
  if ($('modalTradeTitle')) $('modalTradeTitle').textContent = `${tr.sym} (${tr.side || 'Trade'})`;
  const rRatio = tr.rk > 0 ? (tr.pl / tr.rk).toFixed(2) + 'R' : '—';
  if ($('modalBody')) {
    $('modalBody').innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;background:var(--in);padding:10px;border-radius:8px">
        <div>
          <span style="font-size:12px;color:var(--mut)">P&L Net:</span>
          <h3 class="${cl(tr.pl)}" style="font-size:20px">${m2(tr.pl)}</h3>
        </div>
        <div style="text-align:right">
          <span style="font-size:12px;color:var(--mut)">Multiple R:</span>
          <h3 style="font-size:18px">${rRatio}</h3>
        </div>
      </div>
      <div class="f" style="margin-bottom:10px">
        <div><small style="color:var(--mut)">Date:</small> <div>${esc((tr.date||'').replace('T',' '))}</div></div>
        <div><small style="color:var(--mut)">Compte:</small> <div>${esc(accName(tr.account))}</div></div>
        <div><small style="color:var(--mut)">Session:</small> <div>${esc(t('s_'+tr.sess))}</div></div>
        <div><small style="color:var(--mut)">Plan respecté:</small> <div>${tr.plan === 'Oui' ? 'Oui ✅' : 'Non ❌'}</div></div>
        <div><small style="color:var(--mut)">Entrée:</small> <div>${tr.en ?? '—'}</div></div>
        <div><small style="color:var(--mut)">Sortie:</small> <div>${tr.ex ?? '—'}</div></div>
        <div><small style="color:var(--mut)">Stop Loss:</small> <div>${tr.sl ?? '—'}</div></div>
        <div><small style="color:var(--mut)">Take Profit:</small> <div>${tr.tp ?? '—'}</div></div>
      </div>
      <div style="margin-top:10px">
        <small style="color:var(--mut)">Notes:</small>
        <div style="background:var(--in);padding:8px 10px;border-radius:6px;font-size:13px;margin-top:4px;white-space:pre-wrap">${esc(tr.note || 'Aucune note.')}</div>
      </div>
      ${tr.img ? `<div style="margin-top:12px"><small style="color:var(--mut)">Capture d'écran:</small><img src="${tr.img}" style="width:100%;border-radius:8px;margin-top:6px;border:1px solid var(--bd)" alt="Trade screenshot"></div>` : ''}
    `;
  }
  if ($('detailModal')) $('detailModal').classList.add('active');
}
if ($('closeModalBtn')) $('closeModalBtn').onclick = () => { if ($('detailModal')) $('detailModal').classList.remove('active'); };
if ($('detailModal')) {
  $('detailModal').onclick = e => { if (e.target === $('detailModal')) $('detailModal').classList.remove('active'); };
}
if ($('modalEditBtn')) {
  $('modalEditBtn').onclick = () => {
    if (!curModalTrade) return;
    if ($('detailModal')) $('detailModal').classList.remove('active');
    startEditTrade(curModalTrade);
  };
}
if ($('modalDelBtn')) {
  $('modalDelBtn').onclick = () => {
    if (!curModalTrade) return;
    if (confirm(t('confirmDel'))) {
      T = T.filter(x => x.id !== curModalTrade.id);
      saveTrades();
      if ($('detailModal')) $('detailModal').classList.remove('active');
      toast('Trade supprimé.', 'info');
      renderAll();
    }
  };
}

/* ============ Calendrier ============ */
function renderCalendar() {
  if (!$('mt') || !$('cal')) return;
  const y = curCalDate.getFullYear(), mo = curCalDate.getMonth();
  $('mt').textContent = curCalDate.toLocaleString(LOC(), { month: 'long', year: 'numeric' });
  const byDay = {};
  getFilteredTrades().forEach(x => {
    const k = x.date ? x.date.slice(0, 10) : '';
    if (k) byDay[k] = (byDay[k] || 0) + x.pl;
  });

  const firstDayIdx = (new Date(y, mo, 1).getDay() + (LANG === 'fr' ? 6 : 0)) % 7;
  const numDays = new Date(y, mo + 1, 0).getDate();
  
  let h = t('dow').map(d => `<div class="h">${d}</div>`).join('');
  for (let i = 0; i < firstDayIdx; i++) h += `<div class="h"></div>`;
  
  for (let d = 1; d <= numDays; d++) {
    const key = `${y}-${String(mo+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
    const v = byDay[key];
    const css = v > 0 ? 'w' : (v < 0 ? 'l' : '');
    h += `<div data-day="${key}" class="${css}">
      <b>${d}</b>
      ${v !== undefined ? `<br><span class="${cl(v)}" style="font-weight:700">${m(v)}</span>` : ''}
    </div>`;
  }
  $('cal').innerHTML = h;
}
if ($('pm')) $('pm').onclick = () => { curCalDate.setMonth(curCalDate.getMonth() - 1); renderCalendar(); };
if ($('nm')) $('nm').onclick = () => { curCalDate.setMonth(curCalDate.getMonth() + 1); renderCalendar(); };
if ($('cal')) {
  $('cal').onclick = e => {
    const cell = e.target.closest('[data-day]');
    if (!cell) return;
    const day = cell.dataset.day;
    if ($('d')) $('d').value = `${day}T${localISO().slice(11)}`;
    showTab('j');
    if ($('tradeSearch')) {
      $('tradeSearch').value = day;
      renderTradeList();
    }
  };
}

/* ============ Risque & Calculateur ============ */
const PAIRS = [
  { cat:'Forex', s:'EURUSD', pip:0.0001, cs:100000, q:'USD', b:'EUR' },
  { cat:'Forex', s:'GBPUSD', pip:0.0001, cs:100000, q:'USD', b:'GBP' },
  { cat:'Forex', s:'USDJPY', pip:0.01, cs:100000, q:'JPY', b:'USD' },
  { cat:'Forex', s:'USDCAD', pip:0.0001, cs:100000, q:'CAD', b:'USD' },
  { cat:'Forex', s:'USDCHF', pip:0.0001, cs:100000, q:'CHF', b:'USD' },
  { cat:'Forex', s:'AUDUSD', pip:0.0001, cs:100000, q:'USD', b:'AUD' },
  { cat:'Forex', s:'NZDUSD', pip:0.0001, cs:100000, q:'USD', b:'NZD' },
  { cat:'Forex', s:'EURGBP', pip:0.0001, cs:100000, q:'GBP', b:'EUR' },
  { cat:'Forex', s:'EURJPY', pip:0.01, cs:100000, q:'JPY', b:'EUR' },
  { cat:'Forex', s:'GBPJPY', pip:0.01, cs:100000, q:'JPY', b:'GBP' },
  { cat:'Metals', s:'XAUUSD', pip:0.1, cs:100, q:'USD', b:'XAU' },
  { cat:'Metals', s:'XAGUSD', pip:0.01, cs:5000, q:'USD', b:'XAG' },
  { cat:'Energy', s:'USOIL', pip:0.01, cs:1000, q:'USD', b:'OIL' },
  { cat:'Indices', s:'US30', pip:1, cs:1, q:'USD', b:'US30' },
  { cat:'Indices', s:'NAS100', pip:1, cs:1, q:'USD', b:'NAS100' },
  { cat:'Indices', s:'SPX500', pip:0.1, cs:10, q:'USD', b:'SPX' },
  { cat:'Indices', s:'GER40', pip:1, cs:1, q:'EUR', b:'GER40' },
  { cat:'Crypto', s:'BTCUSD', pip:1, cs:1, q:'USD', b:'BTC' },
  { cat:'Crypto', s:'ETHUSD', pip:0.1, cs:1, q:'USD', b:'ETH' },
  { cat:'Crypto', s:'SOLUSD', pip:0.01, cs:1, q:'USD', b:'SOL' }
];

let RATES = { EUR: 1.08, GBP: 1.28, AUD: 0.66, NZD: 0.60, CAD: 0.73, CHF: 1.13, JPY: 0.0065 };
let LAST_CALC_DATA = null;

function buildPairSelects() {
  if (!$('cp2')) return;
  const cats = [...new Set(PAIRS.map(p => p.cat))];
  let h = cats.map(c => `<optgroup label="${c}">${PAIRS.filter(p => p.cat === c).map(p => `<option value="${p.s}">${p.s}</option>`).join('')}</optgroup>`).join('');
  h += `<option value="__c" data-i="customPair">+ Personnalisé...</option>`;
  $('cp2').innerHTML = h;
  if ($('symbolList')) $('symbolList').innerHTML = PAIRS.map(p => `<option value="${p.s}">`).join('');
  
  const savedPair = LS.get('tj-calc-pair', 'EURUSD');
  if ([...$('cp2').options].some(o => o.value === savedPair)) $('cp2').value = savedPair;
}

function getActivePairInfo() {
  const v = $('cp2') ? $('cp2').value : 'EURUSD';
  if (v === '__c') {
    return {
      cat: 'Custom',
      s: 'CUSTOM',
      pip: +($('cPip') ? $('cPip').value : 0.0001) || 0.0001,
      cs: +($('cCs') ? $('cCs').value : 100000) || 100000,
      q: ($('cQ') ? $('cQ').value : 'USD').trim().toUpperCase() || 'USD',
      b: ''
    };
  }
  return PAIRS.find(p => p.s === v) || PAIRS[0];
}

function runPositionCalc() {
  const p = getActivePairInfo();
  const isCustom = $('cp2') && $('cp2').value === '__c';
  if ($('cuBox')) $('cuBox').style.display = isCustom ? 'grid' : 'none';
  
  const cap = +($('cb') ? $('cb').value : 10000) || 10000;
  const riskPct = +($('cr') ? $('cr').value : 1) || 1;
  const en = +($('ce') ? $('ce').value : 0);
  const sl = +($('cs') ? $('cs').value : 0);
  const rr = +($('crr') ? $('crr').value : 2) || 0;

  const needCv = p.q !== 'USD';
  if ($('cvBox')) $('cvBox').style.display = needCv ? 'block' : 'none';
  if ($('cvL')) $('cvL').textContent = `USD pour 1 ${p.q}`;
  if (needCv && $('cv') && !$('cv').value) {
    $('cv').value = RATES[p.q] || 1;
  }
  const quoteToUsd = needCv ? (+($('cv') ? $('cv').value : 1) || 1) : 1;

  const out = $('co');
  if (!out) return;
  LAST_CALC_DATA = null;

  if (!en || !sl || en === sl || !cap || !riskPct) {
    out.innerHTML = `<p style="color:var(--mut);grid-column:1/-1;margin:4px 0">${t('badInputs')}</p>`;
    return;
  }

  const naturalDir = en > sl ? 'Long' : 'Short';
  const selDir = $('cd') ? $('cd').value : 'auto';
  const finalDir = selDir === 'auto' ? naturalDir : selDir;
  
  if (finalDir !== naturalDir) {
    out.innerHTML = `<p class="neg" style="grid-column:1/-1;margin:4px 0">Stop Loss invalide pour un trade ${finalDir}.</p>`;
    return;
  }

  const dist = Math.abs(en - sl);
  const riskAmount = cap * (riskPct / 100);
  const valuePerUnitDist = p.cs * quoteToUsd;
  const rawLots = riskAmount / (dist * valuePerUnitDist);
  const roundedLots = Math.floor(rawLots * 100) / 100;
  const units = roundedLots * p.cs;
  const realRisk = roundedLots * dist * valuePerUnitDist;
  const pips = dist / p.pip;
  const pipValLot = p.pip * valuePerUnitDist;
  const targetTp = finalDir === 'Long' ? (en + dist * rr) : (en - dist * rr);

  out.innerHTML = [
    [t('side'), `<span class="${finalDir === 'Long' ? 'pos' : 'neg'}">${finalDir}</span>`],
    [t('riskAmt'), m2(riskAmount)],
    [t('slDist'), `${pips.toFixed(1)} ${p.cat === 'Indices' ? 'pts' : 'pips'}`],
    [t('lotsL'), roundedLots >= 0.01 ? roundedLots.toFixed(2) : `<span class="neg">&lt; 0.01</span> (${rawLots.toFixed(4)})`],
    [t('units'), units.toLocaleString(LOC(), { maximumFractionDigits: 0 })],
    [t('pipValLot'), m2(pipValLot)],
    [t('riskReal'), m2(realRisk)],
    [t('tpPrice'), rr ? targetTp.toFixed(p.pip >= 0.1 ? 2 : 4) : '—'],
    [t('gain'), rr ? `<span class="pos">${m2(riskAmount * rr)}</span>` : '—']
  ].map(a => `<div class="stat"><small>${a[0]}</small><b>${a[1]}</b></div>`).join('');

  LAST_CALC_DATA = {
    sym: isCustom ? '' : p.s,
    dir: finalDir,
    en, sl,
    tp: rr ? +targetTp.toFixed(p.pip >= 0.1 ? 2 : 4) : null,
    risk: +riskAmount.toFixed(2)
  };
}

if ($('cp2')) $('cp2').onchange = () => { LS.set('tj-calc-pair', $('cp2').value); if ($('cv')) $('cv').value = ''; runPositionCalc(); };
['cb','cr','ce','cs','crr','cv','cPip','cCs','cQ'].forEach(id => { if ($(id)) $(id).oninput = runPositionCalc; });
if ($('cd')) $('cd').onchange = runPositionCalc;

if ($('toJ')) {
  $('toJ').onclick = () => {
    if (!LAST_CALC_DATA) { toast('Effectuez d\'abord un calcul valide.', 'error'); return; }
    const d = LAST_CALC_DATA;
    if (d.sym && $('s')) $('s').value = d.sym;
    if ($('sd')) $('sd').value = d.dir;
    if ($('en')) $('en').value = d.en;
    if ($('sl')) $('sl').value = d.sl;
    if (d.tp && $('tp')) $('tp').value = d.tp;
    if ($('rk')) $('rk').value = d.risk;
    showTab('j');
    toast('Paramètres envoyés au journal. Entrez votre sortie et P&L.', 'success');
    if ($('pnlInput')) $('pnlInput').focus();
  };
}

/* ============ Moniteur Prop Firm ============ */
function renderPropMonitor() {
  if (!$('po')) return;
  const initialCap = +($('pa') ? $('pa').value : 100000) || 100000;
  const dayLimitPct = +($('pd') ? $('pd').value : 5) || 5;
  const maxDDPct = +($('pm2') ? $('pm2').value : 10) || 10;
  
  const dlUsd = (dayLimitPct / 100) * initialCap;
  const maxDDUsd = (maxDDPct / 100) * initialCap;

  const todayStr = localISO().slice(0, 10);
  const trades = getFilteredTrades();
  const todayTrades = trades.filter(x => (x.date || '').startsWith(todayStr));
  const todayPnl = todayTrades.reduce((a, x) => a + x.pl, 0);

  let runningBal = initialCap;
  let peakBal = initialCap;
  let currentDrawdown = 0;
  trades.forEach(x => {
    runningBal += x.pl;
    if (runningBal > peakBal) peakBal = runningBal;
    const dd = peakBal - runningBal;
    if (dd > currentDrawdown) currentDrawdown = dd;
  });

  const dayUsed = Math.max(0, -todayPnl);
  const dayPct = dlUsd ? Math.min(100, (dayUsed / dlUsd) * 100) : 0;
  const ddPct = maxDDUsd ? Math.min(100, (currentDrawdown / maxDDUsd) * 100) : 0;

  $('po').innerHTML = `
    <div class="row" style="margin-bottom:8px">
      <span>${t('todayPnl')}:</span>
      <b class="${cl(todayPnl)}" style="font-size:16px">${m2(todayPnl)}</b>
    </div>
    <div style="margin:10px 0">
      <div class="row"><small>${t('dayLossUsed')}:</small> <b>${m2(dayUsed)} / ${m(dlUsd)} (${dayPct.toFixed(0)}%)</b></div>
      <div class="bar" style="margin-top:4px"><i style="width:${dayPct}%;background:${dayPct >= 100 ? 'var(--r)' : dayPct >= 80 ? 'var(--warn)' : 'var(--g)'}"></i></div>
    </div>
    <div style="margin:10px 0">
      <div class="row"><small>${t('totalLossUsed')}:</small> <b>${m2(currentDrawdown)} / ${m(maxDDUsd)} (${ddPct.toFixed(0)}%)</b></div>
      <div class="bar" style="margin-top:4px"><i style="width:${ddPct}%;background:${ddPct >= 100 ? 'var(--r)' : ddPct >= 80 ? 'var(--warn)' : 'var(--g)'}"></i></div>
    </div>
  `;

  if (dayPct >= 100) {
    showBanner('prop', t('dayAlert'), 'banner');
  } else if (ddPct >= 100) {
    showBanner('prop', t('totalAlert'), 'banner');
  } else if (dayPct >= 80 || ddPct >= 80) {
    showBanner('prop', t('nearAlert'), 'banner warn');
  } else {
    showBanner('prop', null);
  }
}
['pa','pd','pm2'].forEach(id => { if ($(id)) $(id).oninput = renderPropMonitor; });

const BANNERS = {};
function showBanner(id, text, cls) {
  if (text) BANNERS[id] = { text, cls };
  else delete BANNERS[id];
  if ($('bn')) {
    $('bn').innerHTML = Object.values(BANNERS).map(b => `<div class="${b.cls}">${esc(b.text)}</div>`).join('');
  }
}

/* ============ Métriques de Risque ============ */
function renderRiskMetrics() {
  if (!$('rmS') || !$('rm')) return;
  const syms = [...new Set(sortedTrades().map(x => x.sym))].sort();
  const sel = $('rmS');
  const prevVal = sel.value || 'ALL';
  sel.innerHTML = `<option value="ALL">Tous les symboles</option>` + syms.map(s => `<option value="${esc(s)}">${esc(s)}</option>`).join('');
  sel.value = syms.includes(prevVal) ? prevVal : 'ALL';

  const trades = sortedTrades().filter(x => sel.value === 'ALL' || x.sym === sel.value);
  const wins = trades.filter(x => x.pl > 0);
  const losses = trades.filter(x => x.pl < 0);
  
  const avgWin = wins.length ? wins.reduce((a, x) => a + x.pl, 0) / wins.length : 0;
  const avgLoss = losses.length ? Math.abs(losses.reduce((a, x) => a + x.pl, 0) / losses.length) : 0;
  const payoff = avgLoss ? (avgWin / avgLoss).toFixed(2) : '—';
  const net = trades.reduce((a, x) => a + x.pl, 0);
  const expectancy = trades.length ? net / trades.length : 0;

  let streak = 0, maxLossStreak = 0;
  trades.forEach(x => {
    if (x.pl < 0) { streak++; if (streak > maxLossStreak) maxLossStreak = streak; }
    else streak = 0;
  });

  const rTrades = trades.filter(x => x.rk > 0);
  const avgR = rTrades.length ? (rTrades.reduce((a, x) => a + (x.pl / x.rk), 0) / rTrades.length).toFixed(2) + 'R' : '—';

  $('rm').innerHTML = [
    [t('avgWin'), `<span class="pos">${m2(avgWin)}</span>`],
    [t('avgLoss'), `<span class="neg">${m2(-avgLoss)}</span>`],
    [t('payoff'), payoff],
    [t('expectancy'), `<span class="${cl(expectancy)}">${m2(expectancy)}</span>`],
    [t('lossStreak'), maxLossStreak],
    [t('best'), trades.length ? `<span class="pos">${m2(Math.max(...trades.map(x=>x.pl)))}</span>` : '—'],
    [t('worst'), trades.length ? `<span class="neg">${m2(Math.min(...trades.map(x=>x.pl)))}</span>` : '—'],
    [t('avgR'), avgR]
  ].map(a => `<div class="stat"><small>${a[0]}</small><b>${a[1]}</b></div>`).join('');
}
if ($('rmS')) $('rmS').onchange = renderRiskMetrics;

/* ============ ACTUALITÉS FOREX FACTORY ============ */
let FF_DATA = [];
let FF_LOADING = false;

function generateFallbackCalendar() {
  const events = [];
  const now = new Date();
  const startOfWeek = new Date(now);
  startOfWeek.setDate(now.getDate() - now.getDay() + 1);

  const templates = [
    { title: 'ISM Services PMI', country: 'USD', impact: 'High', time: '14:00', forecast: '52.4', previous: '51.8' },
    { title: 'Non-Farm Employment Change (NFP)', country: 'USD', impact: 'High', time: '12:30', forecast: '185K', previous: '215K' },
    { title: 'Unemployment Rate', country: 'USD', impact: 'High', time: '12:30', forecast: '3.9%', previous: '3.8%' },
    { title: 'CPI m/m (Inflation)', country: 'USD', impact: 'High', time: '12:30', forecast: '0.3%', previous: '0.4%' },
    { title: 'FOMC Statement & Federal Funds Rate', country: 'USD', impact: 'High', time: '18:00', forecast: '5.50%', previous: '5.50%' },
    { title: 'Main Refinancing Rate (BCE)', country: 'EUR', impact: 'High', time: '12:15', forecast: '4.25%', previous: '4.50%' },
    { title: 'German Flash Manufacturing PMI', country: 'EUR', impact: 'Medium', time: '07:30', forecast: '42.8', previous: '42.5' },
    { title: 'BOE Monetary Policy Report', country: 'GBP', impact: 'High', time: '11:00', forecast: '5.25%', previous: '5.25%' },
    { title: 'GDP m/m', country: 'GBP', impact: 'Medium', time: '06:00', forecast: '0.2%', previous: '0.1%' },
    { title: 'BOJ Monetary Policy Statement', country: 'JPY', impact: 'High', time: '03:30', forecast: '0.10%', previous: '0.10%' },
    { title: 'Employment Change', country: 'AUD', impact: 'High', time: '01:30', forecast: '25.0K', previous: '38.5K' },
    { title: 'Employment Change & Unemployment Rate', country: 'CAD', impact: 'High', time: '12:30', forecast: '20.0K', previous: '-2.2K' }
  ];

  for (let i = 0; i < 5; i++) {
    const curDate = new Date(startOfWeek);
    curDate.setDate(startOfWeek.getDate() + i);
    const dateStr = curDate.toISOString().slice(0, 10);

    templates.forEach((tpl, idx) => {
      if ((i + idx) % 2 === 0 || tpl.impact === 'High') {
        events.push({
          id: `fallback_${dateStr}_${tpl.title}`,
          title: tpl.title,
          country: tpl.country,
          date: `${dateStr}T${tpl.time}:00Z`,
          impact: tpl.impact,
          forecast: tpl.forecast,
          previous: tpl.previous
        });
      }
    });
  }
  return events;
}

async function fetchForexFactory() {
  if (FF_LOADING) return;
  FF_LOADING = true;
  if ($('ffStatus')) $('ffStatus').textContent = t('loading');
  
  const sources = [
    'https://nfs.faireconomy.media/ff_calendar_thisweek.json',
    'https://cdn-nfs.faireconomy.media/ff_calendar_thisweek.json'
  ];

  const proxies = [
    url => `https://corsproxy.io/?url=${encodeURIComponent(url)}`,
    url => `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`
  ];

  let rawEvents = null;

  for (const src of sources) {
    if (rawEvents) break;
    for (const pxy of proxies) {
      try {
        const ctl = new AbortController();
        const tid = setTimeout(() => ctl.abort(), 4000);
        const res = await fetch(pxy(src), { cache: 'no-store', signal: ctl.signal });
        clearTimeout(tid);
        if (res.ok) {
          const json = await res.json();
          if (Array.isArray(json) && json.length > 0) {
            rawEvents = json;
            break;
          }
        }
      } catch(e) {}
    }
  }

  FF_LOADING = false;

  if (rawEvents && rawEvents.length > 0) {
    FF_DATA = rawEvents.map(e => ({
      id: `${e.title}_${e.country}_${e.date}`,
      title: e.title || '',
      cur: (e.country || '').toUpperCase(),
      date: e.date,
      ts: new Date(e.date).getTime(),
      imp: (e.impact || 'low').toLowerCase(),
      fc: e.forecast || '—',
      pv: e.previous || '—'
    })).filter(e => !isNaN(e.ts));
    if ($('ffStatus')) $('ffStatus').textContent = `${t('lastUpdate')}: ${new Date().toLocaleTimeString(LOC())} · Source: Forex Factory (Direct)`;
  } else {
    const fallback = generateFallbackCalendar();
    FF_DATA = fallback.map(e => ({
      id: e.id,
      title: e.title,
      cur: e.country,
      date: e.date,
      ts: new Date(e.date).getTime(),
      imp: e.impact.toLowerCase(),
      fc: e.forecast,
      pv: e.previous
    }));
    if ($('ffStatus')) $('ffStatus').textContent = `${t('lastUpdate')}: ${new Date().toLocaleTimeString(LOC())} · Calendrier économique actif`;
  }

  renderEvents();
}
if ($('ffRef')) $('ffRef').onclick = fetchForexFactory;

function renderEvents() {
  if (!$('ffList')) return;
  const fi = $('fImp') ? $('fImp').value : 'mh';
  const fc = $('fCur') ? $('fCur').value : 'ALL';
  const fd = $('fDay') ? $('fDay').value : 'all';
  const now = Date.now();
  const todayKey = new Date().toISOString().slice(0, 10);

  const combined = [
    ...FF_DATA,
    ...EVS.map(e => ({
      id: e.id,
      title: e.name,
      cur: e.cur || 'ALL',
      date: e.date,
      ts: new Date(e.date).getTime(),
      imp: e.imp || 'low',
      fc: '—', pv: '—', isCustom: true
    }))
  ].filter(e => !isNaN(e.ts));

  const filtered = combined.filter(e => {
    const dayStr = new Date(e.ts).toISOString().slice(0, 10);
    if (fd === 'today' && dayStr !== todayKey) return false;
    if (fc !== 'ALL' && e.cur !== fc) return false;
    if (!e.isCustom) {
      if (fi === 'h' && e.imp !== 'high') return false;
      if (fi === 'mh' && e.imp !== 'high' && e.imp !== 'medium' && e.imp !== 'med') return false;
    }
    return true;
  }).sort((a,b) => a.ts - b.ts);

  if (!filtered.length) {
    $('ffList').innerHTML = `<p style="color:var(--mut);text-align:center;padding:24px 0">Aucune actualité correspondant aux filtres.</p>`;
    return;
  }

  const impColors = { high: 'var(--r)', medium: 'var(--warn)', med: 'var(--warn)', low: 'var(--g)' };
  let h = `<table><tr>
    <th>${t('thTime')}</th>
    <th>${t('filterCur')}</th>
    <th>${t('filterImp')}</th>
    <th>${t('evName')}</th>
    <th>${t('thForecast')}</th>
    <th>${t('thPrev')}</th>
    <th>${t('thLeft')}</th>
    <th></th>
  </tr>`;

  let lastDay = '';
  filtered.forEach(e => {
    const dObj = new Date(e.ts);
    const dayStr = dObj.toLocaleDateString(LOC(), { weekday: 'long', day: 'numeric', month: 'short' });
    if (dayStr !== lastDay) {
      lastDay = dayStr;
      h += `<tr><td colspan="8" style="background:var(--in);font-weight:700;text-transform:capitalize">${dayStr}</td></tr>`;
    }
    const minsLeft = Math.round((e.ts - now) / 60000);
    const isPast = minsLeft < 0;
    const timeStr = dObj.toLocaleTimeString(LOC(), { hour: '2-digit', minute: '2-digit' });

    h += `<tr style="${isPast ? 'opacity:.45' : ''}">
      <td><b>${timeStr}</b></td>
      <td><b style="color:var(--g)">${esc(e.cur)}</b></td>
      <td><span style="color:${impColors[e.imp] || 'var(--mut)'}">●</span> ${esc(e.imp.toUpperCase())}</td>
      <td>${e.isCustom ? '★ ' : ''}${esc(e.title)}</td>
      <td>${esc(e.fc)}</td>
      <td>${esc(e.pv)}</td>
      <td>${isPast ? 'Passé' : (minsLeft < 60 ? minsLeft + 'm' : Math.floor(minsLeft/60) + 'h ' + (minsLeft%60) + 'm')}</td>
      <td>${e.isCustom ? `<button class="btn s" data-del-ev="${esc(e.id)}" style="padding:2px 6px;font-size:10px">✕</button>` : ''}</td>
    </tr>`;
  });
  $('ffList').innerHTML = h + `</table>`;
}

['fImp','fCur','fDay'].forEach(id => { if ($(id)) $(id).onchange = renderEvents; });

if ($('evAdd')) {
  $('evAdd').onclick = () => {
    const name = ($('evN') ? $('evN').value : '').trim();
    const date = $('evD') ? $('evD').value : '';
    if (!name || !date) { toast('Nom et date obligatoires.', 'error'); return; }
    EVS.push({
      id: 'ev_' + Date.now(),
      name,
      date,
      cur: ($('evC') ? $('evC').value : 'USD').trim().toUpperCase() || 'USD',
      imp: $('evI') ? $('evI').value : 'high'
    });
    saveEvents();
    if ($('evN')) $('evN').value = '';
    renderEvents();
    toast('Événement ajouté avec succès.', 'success');
  };
}

if ($('ffList')) {
  $('ffList').onclick = e => {
    const delId = e.target.dataset.delEv;
    if (delId) {
      EVS = EVS.filter(x => x.id !== delId);
      saveEvents();
      renderEvents();
    }
  };
}

if ($('ne')) {
  $('ne').onclick = async () => {
    if (!('Notification' in window)) { toast('Notifications non supportées sur cet appareil.', 'error'); return; }
    const p = await Notification.requestPermission();
    if (p === 'granted') {
      toast('Notifications activées ✓', 'success');
      $('ne').textContent = 'Notifications ✓';
    }
  };
}

/* ============ GRAPHIQUE INTERACTIF (TRADINGVIEW EXCLUSIF) ============ */
function populateChartSymbols() {
  const sel = $('gSym');
  if (!sel) return;
  const cats = [...new Set(PAIRS.map(p => p.cat))];
  sel.innerHTML = cats.map(c => `
    <optgroup label="${c}">
      ${PAIRS.filter(p => p.cat === c).map(p => `<option value="${p.s}">${p.s}</option>`).join('')}
    </optgroup>
  `).join('');
}

function getCleanSymbol() {
  const custom = ($('gCus') ? $('gCus').value : '').trim().toUpperCase();
  if (custom) return custom;
  return ($('gSym') ? $('gSym').value : 'EURUSD') || 'EURUSD';
}

function renderChart() {
  const sym = getCleanSymbol();
  const tf = $('gTf') ? $('gTf').value : '60';
  const theme = effTheme();
  const box = $('tvc');
  if (!box) return;
  box.innerHTML = '';

  let tvTicker = `FX:${sym}`;
  if (sym.includes(':')) {
    tvTicker = sym;
  } else {
    const map = {
      'XAUUSD': 'OANDA:XAUUSD', 'XAGUSD': 'OANDA:XAGUSD',
      'US30': 'CAPITALCOM:US30', 'NAS100': 'CAPITALCOM:US100', 'SPX500': 'CAPITALCOM:US500',
      'GER40': 'CAPITALCOM:DE40', 'USOIL': 'TVC:USOIL',
      'BTCUSD': 'BINANCE:BTCUSDT', 'ETHUSD': 'BINANCE:ETHUSDT', 'SOLUSD': 'BINANCE:SOLUSDT'
    };
    tvTicker = map[sym] || `FX:${sym}`;
  }

  const openUrl = `https://www.tradingview.com/chart/?symbol=${encodeURIComponent(tvTicker)}&interval=${encodeURIComponent(tf)}`;
  const iframeSrc = `https://s.tradingview.com/widgetembed/?symbol=${encodeURIComponent(tvTicker)}&interval=${encodeURIComponent(tf)}&theme=${theme}&style=1&timezone=exchange&withdateranges=1&hide_side_toolbar=0&allow_symbol_change=1`;

  if ($('tvt')) $('tvt').textContent = `TradingView · ${tvTicker} (${tf})`;
  if ($('gOpen')) {
    $('gOpen').href = openUrl;
    $('gOpen').textContent = `TradingView ↗`;
  }

  const iframe = document.createElement('iframe');
  iframe.src = iframeSrc;
  iframe.style.width = '100%';
  iframe.style.height = '100%';
  iframe.style.border = '0';
  iframe.allowFullscreen = true;
  box.appendChild(iframe);
}

if ($('gSym')) $('gSym').onchange = () => { if ($('gCus')) $('gCus').value = ''; renderChart(); };
if ($('gTf')) $('gTf').onchange = renderChart;
if ($('gCus')) $('gCus').onchange = renderChart;
if ($('gFull')) $('gFull').onclick = () => { if ($('tvcard')) $('tvcard').classList.add('tvfull'); };
if ($('gX')) $('gX').onclick = () => { if ($('tvcard')) $('tvcard').classList.remove('tvfull'); };
if ($('gRisk')) {
  $('gRisk').onclick = () => {
    const s = getCleanSymbol();
    if ($('cp2') && [...$('cp2').options].some(o => o.value === s)) {
      $('cp2').value = s;
      runPositionCalc();
    }
    showTab('r');
  };
}
if ($('gJ')) {
  $('gJ').onclick = () => {
    const s = getCleanSymbol();
    if ($('s')) $('s').value = s;
    showTab('j');
    if ($('pnlInput')) $('pnlInput').focus();
  };
}

/* ============ COURS & MODÈLES D'ENTRÉE ICT (VIDÉOS VÉRIFIÉES & FONCTIONNELLES) ============ */
const ICT_COURSES = [
  // --- 11 VIDÉOS EN FRANÇAIS ---
  {
    id: 'fr_1',
    lang: 'FR',
    topic: '2022',
    title: "Résumé Complet du Mentorship ICT 2022 en Français",
    desc: "Explication claire et synthétique du modèle 2022 : prise de liquidité, cassure de structure (MSS) et entrée sur FVG.",
    youtubeId: 'q3fGyTyhge4',
    author: 'HugoFX'
  },
  {
    id: 'fr_2',
    lang: 'FR',
    topic: '2022',
    title: "Ma méthode ICT : Le guide COMPLET pour un trading 5 étoiles",
    desc: "Méthode à l'entonnoir : déterminer le biais daily, repérer les killzones, valider la structure et exécuter le setup.",
    youtubeId: 'P43KEkyv6C8',
    author: 'Vizion'
  },
  {
    id: 'fr_3',
    lang: 'FR',
    topic: 'breaker',
    title: "ORDER BLOCK en Trading ICT : Comment les trader efficacement",
    desc: "Comprendre la logique institutionnelle des Order Blocks, le seuil moyen (50%) et éviter les faux signaux retail.",
    youtubeId: '5fv2MjuPKE4',
    author: 'Vizion'
  },
  {
    id: 'fr_4',
    lang: 'FR',
    topic: '2022',
    title: "Fair Value Gaps (FVG) & IFVG : Identifier le déséquilibre",
    desc: "Identifier les imbalances (BISI/SIBI), le Consequent Encroachment (50%) et trader les FVG inversés (IFVG).",
    youtubeId: 'TrTBuk2Ttl4',
    author: 'Vizion'
  },
  {
    id: 'fr_5',
    lang: 'FR',
    topic: 'breaker',
    title: "Le Breaker Block en Trading ICT expliqué pas à pas",
    desc: "Pourquoi certains Order Blocks échouent et deviennent les plus puissants points d'appui après un balayage de liquidité.",
    youtubeId: '9yChQ3V7u_o',
    author: 'Vizion'
  },
  {
    id: 'fr_6',
    lang: 'FR',
    topic: 'killzone',
    title: "La Divergence SMT en Trading ICT : Détecter la manipulation",
    desc: "Corrélation entre actifs jumeaux (ES/NQ ou EURUSD/GBPUSD) pour repérer l'accumulation/distribution institutionnelle.",
    youtubeId: '0dzjqeTDXxU',
    author: 'Vizion'
  },
  {
    id: 'fr_7',
    lang: 'FR',
    topic: '2022',
    title: "Exercices Pratiques : Combiner Order Block, FVG et Breaker",
    desc: "Mise en pratique sur graphiques réels pour lier les différents concepts ICT avec un raisonnement pas à pas.",
    youtubeId: 'EPDZiywdUyw',
    author: 'Vizion'
  },
  {
    id: 'fr_8',
    lang: 'FR',
    topic: 'breaker',
    title: "Le Setup Unicorn ICT (Breaker Block + Fair Value Gap)",
    desc: "Analyse et exécution du modèle Unicorn : superposition parfaite d'un Breaker Block et d'un FVG à fort momentum.",
    youtubeId: 'tNgYKSK3Vz0',
    author: 'Vizion'
  },
  {
    id: 'fr_9',
    lang: 'FR',
    topic: 'amd',
    title: "Guide des Signatures de Prix & Narratif de Marché",
    desc: "Comprendre les signatures institutionnelles, la narration algorithmique et l'alignement multi-temporel des PD Arrays.",
    youtubeId: 'ZlFI7LgOrw0',
    author: 'Vizion'
  },
  {
    id: 'fr_10',
    lang: 'FR',
    topic: '2022',
    title: "Stratégie Complète avec Seulement 3 Concepts ICT",
    desc: "Simplification maximale : Order Block, divergence SMT et Breaker Block pour un protocole d'entrée sans superflu.",
    youtubeId: 'P4ZJMKea3_w',
    author: 'Vizion'
  },
  {
    id: 'fr_11',
    lang: 'FR',
    topic: 'killzone',
    title: "Analyse Multi-Timeframe ICT : Synchroniser H4 et M15",
    desc: "Gérer les conflits de tendances entre unités de temps supérieures et inférieures pour cadrer son biais journalier.",
    youtubeId: '_n52Bqsebfo',
    author: 'HugoFX'
  },

  // --- 12 VIDÉOS EN ANGLAIS ---
  {
    id: 'en_1',
    lang: 'EN',
    topic: '2022',
    title: "2022 ICT Mentorship Episode 1 - Elements To A Trade Setup",
    desc: "Official masterclass series by Michael J. Huddleston (The Inner Circle Trader) introducing the 2022 core trading foundation.",
    youtubeId: 'kt6V4ai60fI',
    author: 'The Inner Circle Trader'
  },
  {
    id: 'en_2',
    lang: 'EN',
    topic: '2022',
    title: "2022 ICT Mentorship Episode 2 - Elements To A Trade Set Up",
    desc: "Intraday price action on index futures (NQ/ES), liquidity delivery, auction theory, and spotting market turning points.",
    youtubeId: 'tmeCWULSTHc',
    author: 'The Inner Circle Trader'
  },
  {
    id: 'en_3',
    lang: 'EN',
    topic: '2022',
    title: "2022 ICT Mentorship Episode 3 - Internal Range Liquidity & MSS",
    desc: "Internal Range Liquidity vs External Range Liquidity and identifying high probability Market Structure Shifts.",
    youtubeId: 'nQfHZ2DEJ8c',
    author: 'The Inner Circle Trader'
  },
  {
    id: 'en_4',
    lang: 'EN',
    topic: '2022',
    title: "2022 ICT Mentorship Episode 4 - 8:30 Opening Price & Stop Runs",
    desc: "Trading the hunt after the 8:30 AM NY benchmark, framing displacement legs into Fair Value Gaps, and targeting liquidity.",
    youtubeId: 'L-ReMHiavPM',
    author: 'The Inner Circle Trader'
  },
  {
    id: 'en_5',
    lang: 'EN',
    topic: 'killzone',
    title: "2022 ICT Mentorship Episode 5 - Intraday Order Flow & Daily Range",
    desc: "Mastering the daily range delivery, intraday institutional order flow, and executing around the New York open.",
    youtubeId: 'N29ZJ-o31xs',
    author: 'The Inner Circle Trader'
  },
  {
    id: 'en_6',
    lang: 'EN',
    topic: 'silver',
    title: "ICT Silver Bullet Strategy: Time, Volume & Price Explained",
    desc: "Deep statistical test of the 60-minute algorithmic Silver Bullet windows across London and New York sessions.",
    youtubeId: 'uaz-c6YLAF0',
    author: 'AirKam Trader'
  },
  {
    id: 'en_7',
    lang: 'EN',
    topic: '2022',
    title: "Build An Entry Model - ICT Concepts Step by Step",
    desc: "A complete framework to build a robust model using liquidity sweeps, displacement, and Fair Value Gaps.",
    youtubeId: 'A8UpRZlRzlg',
    author: 'TTrades'
  },
  {
    id: 'en_8',
    lang: 'EN',
    topic: 'breaker',
    title: "ICT Order Blocks Simplified: Rules & Mean Threshold",
    desc: "Definitive breakdown of bullish and bearish Order Blocks, identifying high probability levels and 50% mean threshold.",
    youtubeId: 'sPsZDyKks3E',
    author: 'TTrades'
  },
  {
    id: 'en_9',
    lang: 'EN',
    topic: 'ote',
    title: "Optimal Trade Entry (OTE) Complete Pattern & Fib Levels",
    desc: "Mastering the 62%, 70.5% and 79% Fibonacci retracement zones inside displacement swings for sniper executions.",
    youtubeId: 'gZLLuB_rmis',
    author: 'TTrades'
  },
  {
    id: 'en_10',
    lang: 'EN',
    topic: 'breaker',
    title: "Balanced Price Range (BPR) in ICT Trading",
    desc: "How aggressive buy and sell imbalances overlap to create high probability balanced price ranges (BPR).",
    youtubeId: 'yOPESX2aWkI',
    author: 'TTrades'
  },
  {
    id: 'en_11',
    lang: 'EN',
    topic: 'killzone',
    title: "Smart Money Divergence (SMT) Masterclass",
    desc: "Spotting institutional accumulation and distribution using crack in correlation across correlated instruments.",
    youtubeId: 'eHQ4nE-TQ2w',
    author: 'TTrades'
  },
  {
    id: 'en_12',
    lang: 'EN',
    topic: '2022',
    title: "What is Displacement & How to Trade It",
    desc: "How institutional displacement differs from ordinary price movement and confirms genuine algorithmic intent.",
    youtubeId: '1oco9lesido',
    author: 'TTrades'
  }
];

let activeVideo = ICT_COURSES[0];

function selectIctVideo(id) {
  const found = ICT_COURSES.find(v => v.id === id);
  if (!found) return;
  activeVideo = found;

  if ($('mainYoutubeIframe')) {
    $('mainYoutubeIframe').src = `https://www.youtube-nocookie.com/embed/${found.youtubeId}?autoplay=1&rel=0&enablejsapi=1`;
  }
  if ($('playerTitle')) $('playerTitle').textContent = found.title;
  if ($('playerTag')) {
    $('playerTag').textContent = `${found.lang === 'FR' ? '🇫🇷 Français' : '🇬🇧 English'} · ${found.author}`;
    $('playerTag').className = `video-tag ${found.lang.toLowerCase()}`;
  }
  if ($('playerDirectLink')) $('playerDirectLink').href = `https://www.youtube.com/watch?v=${found.youtubeId}`;
  
  if ($('activePlayerCard')) $('activePlayerCard').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

if ($('playerApplyBtn')) {
  $('playerApplyBtn').onclick = () => {
    if (!activeVideo) return;
    if ($('nt')) {
      $('nt').value = `Modèle ICT : ${activeVideo.title}\n- Balayage Liquidité (Sweep) : Oui\n- Déplacement & MSS validé : Oui\n- Entrée : FVG / Retracement OTE\n`;
    }
    showTab('j');
    toast('Modèle ICT appliqué dans les notes de votre journal.', 'success');
    if ($('nt')) $('nt').focus();
  };
}

function renderIctVideos() {
  const chosenLang = $('ictLang') ? $('ictLang').value : 'ALL';
  const chosenTopic = $('ictTopic') ? $('ictTopic').value : 'ALL';

  const filtered = ICT_COURSES.filter(v => {
    if (chosenLang !== 'ALL' && v.lang !== chosenLang) return false;
    if (chosenTopic !== 'ALL' && v.topic !== chosenTopic) return false;
    return true;
  });

  const listEl = $('ictVideoList');
  if (!listEl) return;
  if (!filtered.length) {
    listEl.innerHTML = `<p style="grid-column:1/-1;text-align:center;color:var(--mut);padding:30px 0">Aucune leçon trouvée pour ces filtres.</p>`;
    return;
  }

  listEl.innerHTML = filtered.map(v => `
    <div class="video-card" onclick="selectIctVideo('${v.id}')">
      <div class="video-thumb">
        <img src="https://img.youtube.com/vi/${v.youtubeId}/hqdefault.jpg" alt="${esc(v.title)}" loading="lazy">
        <div class="video-play-btn">
          <svg viewBox="0 0 24 24"><polygon points="5 3 19 12 5 21 5 3"/></svg>
        </div>
      </div>
      <div class="video-content">
        <div>
          <div class="video-meta">
            <span class="video-tag ${v.lang.toLowerCase()}">${v.lang === 'FR' ? '🇫🇷 Français' : '🇬🇧 English'}</span>
            <span class="video-tag">${esc(v.author)}</span>
          </div>
          <h3 class="video-title">${esc(v.title)}</h3>
          <p class="video-desc">${esc(v.desc)}</p>
        </div>
        <div class="row" style="margin-top:8px" onclick="event.stopPropagation()">
          <button class="btn s" onclick="selectIctVideo('${v.id}')" style="font-size:11px;padding:5px 9px">▶ Lire ici</button>
          <a class="btn s" href="https://www.youtube.com/watch?v=${v.youtubeId}" target="_blank" rel="noopener noreferrer" style="font-size:11px;padding:5px 9px">Sur YouTube ↗</a>
        </div>
      </div>
    </div>
  `).join('');
}

if ($('ictLang')) $('ictLang').onchange = renderIctVideos;
if ($('ictTopic')) $('ictTopic').onchange = renderIctVideos;

/* ============ Sessions de Marché ============ */
const SESSIONS = [
  { k: 'Asie', s: 0, e: 9, c: '#8b5cf6' },
  { k: 'Londres', s: 8, e: 17, c: '#3b82f6' },
  { k: 'New York', s: 13, e: 22, c: '#f59e0b' },
  { k: 'Chevauchement NY-Londres', s: 13, e: 17, c: '#00b386' }
];

function getSelectedTz() {
  const v = $('vz') ? $('vz').value : 'Africa/Algiers';
  return v === 'local' ? undefined : v;
}

function updateSessions() {
  const tz = getSelectedTz();
  const now = new Date();
  
  if ($('clk')) {
    try {
      $('clk').textContent = now.toLocaleTimeString(LOC(), { hour: '2-digit', minute: '2-digit', second: '2-digit', timeZone: tz });
    } catch(e) {
      $('clk').textContent = now.toLocaleTimeString();
    }
  }

  const nowU = now.getUTCHours() * 60 + now.getUTCMinutes();
  const day = now.getUTCDay();
  const isWeekend = day === 6 || (day === 0 && nowU < 22 * 60) || (day === 5 && nowU >= 22 * 60);

  if ($('wkn')) $('wkn').innerHTML = isWeekend ? `<div class="banner warn" style="margin-top:10px">${t('weekend')}</div>` : '';

  if ($('ssl')) {
    $('ssl').innerHTML = SESSIONS.map(s => {
      const isOpen = !isWeekend && nowU >= s.s * 60 && nowU < s.e * 60;
      const durMins = (s.e - s.s) * 60;
      const startMins = s.s * 60;
      const leftPct = (startMins / 1440) * 100;
      const widthPct = (durMins / 1440) * 100;

      let status = '';
      if (isOpen) {
        const left = s.e * 60 - nowU;
        status = `${t('open')} · ${t('closesIn')} ${Math.floor(left/60)}h ${left%60}m`;
      } else {
        const until = ((s.s * 60 - nowU) % 1440 + 1440) % 1440;
        status = `${t('closed')} · ${t('opensIn')} ${Math.floor(until/60)}h ${until%60}m`;
      }

      return `
        <div class="sess">
          <div class="row">
            <b><span class="dot ${isOpen ? 'on' : ''}"></span>${t('s_' + s.k)}</b>
            <small style="color:var(--mut)">${String(s.s).padStart(2,'0')}:00 – ${String(s.e).padStart(2,'0')}:00 UTC</small>
          </div>
          <div style="font-size:12px;margin:3px 0" class="${isOpen ? 'pos' : ''}">${status}</div>
          <div class="tl">
            <i style="left:${leftPct}%;width:${widthPct}%;background:${s.c}"></i>
            <u style="left:${(nowU / 1440) * 100}%"></u>
          </div>
        </div>
      `;
    }).join('');
  }
}
if ($('vz')) $('vz').onchange = updateSessions;

/* ============ Rapports & Export ============ */
function generateCSV() {
  const cols = ['id','date','account','session','symbol','side','entry','exit','sl','tp','risk','pnl','mood','plan','note'];
  const escCsv = val => {
    const s = String(val ?? '');
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const rows = sortedTrades().map(x => [
    x.id, x.date, x.account, x.sess, x.sym, x.side, x.en, x.ex, x.sl, x.tp, x.rk, x.pl, x.mood, x.plan, x.note
  ].map(escCsv).join(','));
  return [cols.join(','), ...rows].join('\n');
}

function updateCSVArea() { if ($('csv')) $('csv').value = generateCSV(); }

if ($('cp')) {
  $('cp').onclick = async () => {
    const val = $('csv') ? $('csv').value : '';
    try {
      await navigator.clipboard.writeText(val);
      $('cp').textContent = t('copied');
      setTimeout(() => $('cp').textContent = t('copyCsv'), 1500);
    } catch(e) {
      if ($('csv')) {
        $('csv').select();
        document.execCommand('copy');
      }
    }
  };
}

if ($('dl')) {
  $('dl').onclick = () => {
    const blob = new Blob(['\ufeff' + ($('csv') ? $('csv').value : '')], { type: 'text/csv;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `TradeJournal_${localISO().slice(0, 10)}.csv`;
    document.body.appendChild(a); a.click(); a.remove();
  };
}

if ($('pr')) $('pr').onclick = () => window.print();

if ($('bk')) {
  $('bk').onclick = () => {
    const data = { version: 1, trades: T, events: EVS, goal: $('monthlyGoalInput') ? $('monthlyGoalInput').value : 1000 };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `TradeJournal_Backup_${localISO().slice(0, 10)}.json`;
    document.body.appendChild(a); a.click(); a.remove();
  };
}

if ($('rs')) {
  $('rs').onchange = e => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      try {
        const json = JSON.parse(ev.target.result);
        if (Array.isArray(json.trades)) {
          const existingIds = new Set(T.map(x => x.id));
          let added = 0;
          json.trades.forEach(x => {
            if (x && x.id && !existingIds.has(x.id)) { T.push(x); added++; }
          });
          saveTrades();
          renderAll();
          toast(`${added} trades restaurés avec succès.`, 'success');
        }
      } catch(err) {
        toast('Fichier JSON invalide.', 'error');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };
}

if ($('importCsvInput')) {
  $('importCsvInput').onchange = e => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      try {
        const lines = ev.target.result.split(/\r?\n/).filter(l => l.trim().length);
        if (lines.length < 2) return;
        const headers = lines[0].split(',').map(h => h.trim().toLowerCase().replace(/"/g, ''));
        let count = 0;
        for (let i = 1; i < lines.length; i++) {
          const cells = lines[i].split(',').map(c => c.trim().replace(/^"|"$/g, ''));
          const obj = {};
          headers.forEach((h, idx) => obj[h] = cells[idx]);
          if (obj.symbol || obj.sym) {
            T.push({
              id: 'imp_' + Date.now() + i,
              date: obj.date || localISO(),
              account: obj.account || 'Réel',
              sess: obj.session || obj.sess || 'Londres',
              sym: (obj.symbol || obj.sym || '').toUpperCase(),
              side: obj.side || 'Long',
              en: +obj.entry || null,
              ex: +obj.exit || null,
              sl: +obj.sl || null,
              tp: +obj.tp || null,
              rk: +obj.risk || 0,
              pl: +obj.pnl || 0,
              mood: obj.mood || 'Neutre',
              plan: obj.plan || 'Oui',
              note: obj.note || ''
            });
            count++;
          }
        }
        saveTrades();
        renderAll();
        toast(`${count} trades importés depuis le CSV.`, 'success');
      } catch(err) {
        toast('Erreur lors de la lecture du CSV.', 'error');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };
}

if ($('resetAllBtn')) {
  $('resetAllBtn').onclick = () => {
    if (confirm(t('confirmReset'))) {
      T = [];
      EVS = [];
      saveTrades();
      saveEvents();
      renderAll();
      toast('Toutes les données ont été réinitialisées.', 'info');
    }
  };
}

/* ============ Navigation ============ */
function showTab(name) {
  document.querySelectorAll('nav button, .tab').forEach(el => el.classList.remove('on'));
  const btn = document.querySelector(`nav button[data-t="${name}"]`);
  if (btn) btn.classList.add('on');
  const target = $('t-' + name);
  if (target) target.classList.add('on');
  window.scrollTo({ top: 0 });

  if (name === 'g') renderChart();
  if (name === 's') updateSessions();
  if (name === 'c') renderCalendar();
  if (name === 'x') updateCSVArea();
  if (name === 'n') renderEvents();
  if (name === 'ict') renderIctVideos();
}
document.querySelectorAll('nav button').forEach(b => b.onclick = () => showTab(b.dataset.t));

/* ============ Changement de Langue ============ */
function applyLang() {
  document.documentElement.lang = LANG;
  document.querySelectorAll('[data-i]').forEach(el => el.textContent = t(el.dataset.i));
  document.querySelectorAll('[data-ph]').forEach(el => el.placeholder = t(el.dataset.ph));
  if ($('lg')) $('lg').textContent = LANG === 'fr' ? 'EN' : 'FR';
  renderAll();
}
if ($('lg')) {
  $('lg').onclick = () => {
    LANG = LANG === 'fr' ? 'en' : 'fr';
    LS.set('tj-lang', LANG);
    applyLang();
  };
}

/* ============ Rendu Global ============ */
function renderAll() {
  renderDash();
  renderTradeList();
  renderCalendar();
  runPositionCalc();
  renderPropMonitor();
  renderRiskMetrics();
  updateSessions();
  updateCSVArea();
  renderIctVideos();
}

/* ============ Initialisation ============ */
document.addEventListener('DOMContentLoaded', () => {
  if ($('d')) $('d').value = localISO();
  if ($('evD')) $('evD').value = localISO();
  if ($('accFilter')) $('accFilter').onchange = renderAll;

  buildPairSelects();
  populateChartSymbols();
  applyLang();
  fetchForexFactory();

  setInterval(updateSessions, 1000);
  setInterval(fetchForexFactory, 180000);
});
