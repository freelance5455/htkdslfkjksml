/* JOSTECH — MANUEL 05 : INTELLIGENCE ARTIFICIELLE NIVEAU 3 */
registerLessonDetail(5, 3, "ia-3-1-1", {
  title: "Leçon 1 : Deep Learning, Transformers, IA Générative et Prompts",
  duration: "45 min (Manuel universitaire complet)",
  objectives: [
    "Comprendre le Perceptron, les fonctions d'activation (ReLU) et la rétropropagation.",
    "Distinguer CNN (Vision) et architecture Transformer / Mécanisme d'Attention (NLP/LLM).",
    "Maîtriser l'ingénierie des prompts avancée (Few-Shot, Chain-of-Thought) et les limites des LLM."
  ],
  prerequisites: ["Niveau 2 — Machine Learning."],
  sections: [
    {
      type: "definition",
      term: "Réseau de Neurones Profond (Deep Learning)",
      text: "Chaque neurone artificiel calcule une somme pondérée de ses entrées (Σ wi·xi + b) puis applique une fonction non-linéaire appelée fonction d'activation (souvent ReLU). En empilant de nombreuses couches cachées (d'où le terme « Deep »), le réseau extrait des caractéristiques hiérarchiques : sur une image, la couche 1 détecte des traits simples, la couche 3 des yeux/roues, et la dernière reconnaît un visage ou une voiture.\n\nL'algorithme de Rétropropagation (Backpropagation) propage l'erreur finale à rebours pour ajuster les millions (ou milliards) de poids wi."
    },
    {
      type: "theory",
      title: "1. Des CNN aux Transformers (Révolution de l'IA Générative)",
      text: "Les réseaux convolutifs (CNN) dominent la Vision par ordinateur. Pour le texte (NLP), l'architecture Transformer publiée en 2017 (« Attention Is All You Need ») a tout changé grâce au mécanisme d'Auto-Attention (Self-Attention) : le modèle analyse simultanément tous les mots d'une phrase pour comprendre exactement à quoi renvoie chaque mot selon son contexte.\n\nLes Grands Modèles de Langage (LLM) découpent le texte en morceaux appelés « Tokens » et prédisent itérativement le token suivant le plus probable."
    },
    {
      type: "code",
      lang: "Techniques avancées d'Ingénierie des Prompts",
      code: [
        "1. Zero-Shot   : Question directe sans exemple.",
        "2. Few-Shot    : Donner 2 ou 3 exemples Entrée→Sortie pour imposer un format strict.",
        "3. Chain-of-Thought (CoT) : Ajouter « Raisonne étape par étape avant de conclure »",
        "   --> Réduit fortement les erreurs logiques et mathématiques des LLM !",
        "4. RAG (Retrieval-Augmented Generation) : Fournir ses propres cours fiables au LLM",
        "   pour qu'il réponde uniquement à partir de sources vérifiées."
      ].join("\n")
    },
    {
      type: "warning",
      title: "Limites critiques : Hallucinations et Fenêtre de Contexte",
      text: "Un LLM ne « sait » pas la vérité : il calcule des probabilités de suite de mots. Il peut donc inventer de faux articles scientifiques ou de fausses lois avec une assurance parfaite (Hallucination). Toute information critique (santé, droit, code sécurité) doit toujours être vérifiée par un humain."
    }
  ],
  exercises: [
    {
      title: "Exercice 1 — Rôle de la non-linéarité (ReLU)",
      question: "Pourquoi un réseau de neurones de 50 couches SANS aucune fonction d'activation non-linéaire (comme ReLU) ne serait-il pas plus intelligent qu'une seule simple régression linéaire ?",
      solution: "Mathématiquement, combiner plusieurs fonctions linéaires donne toujours une fonction linéaire ! La fonction d'activation non-linéaire (ReLU) est indispensable pour permettre au réseau d'apprendre des frontières courbes complexes."
    },
    {
      title: "Exercice 2 — Réduire les hallucinations dans JOSTECH",
      question: "Vous voulez brancher un assistant IA sur JOSTECH qui cite exactement les livres de votre bibliothèque sans inventer de faux chapitres. Quelle architecture combine base documentaire locale et LLM ?",
      solution: "Le RAG (Retrieval-Augmented Generation) : on recherche d'abord les vrais passages dans les cours JOSTECH, puis on demande au LLM de rédiger la réponse uniquement à partir de ces extraits."
    }
  ],
  summary: "Le Deep Learning empile des couches non-linéaires entraînées par rétropropagation. L'architecture Transformer (Attention) propulse les LLM modernes, dont on maîtrise la précision grâce au Prompt Engineering (CoT, Few-Shot) et au RAG.",
  references: ["Goodfellow, I., Bengio, Y. & Courville, A. — Deep Learning (MIT Press).", "Vaswani, A. et al. (2017) — Attention Is All You Need."]
});