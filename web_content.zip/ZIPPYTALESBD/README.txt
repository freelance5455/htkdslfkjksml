ZIPPYTALESBD website

ব্যবহার: ZIP ফাইল Extract করে index.html ফাইলটি Chrome/যেকোনো ব্রাউজারে খুলুন।
অ্যাডমিন: ডানদিকের 🔒 বাটনে চাপ দিয়ে লগইন করুন।
নোট: এটি একটি static demo। মুভির তথ্য শুধু একই browser/device-এর localStorage-এ থাকে; সব visitor-এর জন্য online sync করতে backend/database লাগবে। এই demo-র login তথ্য HTML/JavaScript-এর মধ্যে আছে, তাই production security নয়।
