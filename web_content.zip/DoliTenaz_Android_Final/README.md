# Doli Tenaz Official — Android Final

Projeto Android baseado em WebView, sem dependência de internet para a interface principal.

## Inclui
- Página oficial Doli Tenaz
- Lançamentos e capas
- Reprodutor de áudio local
- Seleção de ficheiro de música do telefone
- Formulário para preparar novo lançamento
- Guardar rascunho no telefone
- Partilhar os dados do lançamento
- Estrutura preparada para APK/AAB

## Importante
O app não pode, sozinho, distribuir uma música para Spotify/Apple Music/Boomplay etc. Para isso é necessário um serviço de distribuição/backend e contas correspondentes. Os botões e a área de lançamento estão preparados para essa integração futura.

## Compilação
Abrir esta pasta no Android Studio e gerar APK ou Android App Bundle (AAB). É necessário ter Android SDK/Gradle configurados.
