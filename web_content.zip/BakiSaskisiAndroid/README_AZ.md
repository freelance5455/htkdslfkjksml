# BAKI ŞAŞKİSİ — Android layihəsi

Bu qovluq Android Studio ilə açılan native Android layihəsidir. Oyun HTML/JavaScript mühərrikini Android WebView daxilində, internetdən asılı olmayan əsas oyun funksiyaları ilə işlədir. Azərbaycan Dövlət Himni internet bağlantısı tələb edir və giriş ekranında istifadəçi düyməsinə toxunduqdan sonra səslənməyə çalışır.

## APK yaratmaq
1. Android Studio-nu açın.
2. `BakiSaskisiAndroid` qovluğunu **Open** ilə seçin.
3. Gradle Sync tamamlanmasını gözləyin (Android SDK 35 və JDK 17 lazımdır).
4. `Build` → `Build Bundle(s) / APK(s)` → `Build APK(s)` seçin.
5. APK faylı `app/build/outputs/apk/debug/app-debug.apk` yolunda yaranacaq.

## Hazır olanlar
- Native Android launcher tətbiqi və tətbiq ikonu
- Tam ekran WebView konteyneri, yüklənmə indikatoru
- JavaScript, localStorage və oyunçu profilinin saxlanması
- Əvvəlki BAKI ŞAŞKİSİ HTML oyun versiyası daxildə paketlənib
- Himn audio linki üçün internet icazəsi

## Məhdudiyyətlər
Bu mühitdə Android SDK/Gradle quraşdırılmadığı üçün APK burada kompilyasiya və cihazda sınaqdan keçirilməyib. Layihə mənbə kodudur; APK yuxarıdakı addımlarla Android Studio-da qurulmalıdır. Serverli multiplayer, hesab sistemi və mağaza yayımlanması bu ilkin native qablaşdırmaya daxil deyil.
