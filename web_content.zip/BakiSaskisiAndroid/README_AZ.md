# BAKI ŞAŞKİSİ — 2.2.8

Android WebView əsaslı dama oyunu. Bu versiyada başlanğıc ekranı, himn, foto-avatar və avatar sıfırlama axınları yenilənib.

## 2.2.8 dəyişiklikləri
- Yükləmə indikatoru saxta taymerlə deyil, WebView səhifə yüklənməsi və Android MediaPlayer-in faktiki audio mövqeyi ilə yenilənir.
- 100% yalnız himnin tamamlanması zamanı göstərilir; istifadəçi istəsə başlanğıc ekranını özü keçə bilər.
- Himn başladıqda qalan vaxt və real faiz göstərilir; xəta baş verərsə istifadəçiyə davam etmək seçimi verilir.
- PeerJS CDN skripti `async` yüklənir ki, internet/CDN gecikməsi əsas oyunun açılmasını bloklamasın. Online oyun üçün internet və PeerJS CDN əlçatanlığı yenə tələb olunur.
- Avatar seçimi Android sistem foto seçicisini açır, şəkil mərkəzdən kvadrat kəsilir, 320x320 JPEG-ə çevrilir və WebView yaddaşında saxlanır.
- Native URI nəticəsi JavaScript-ə təhlükəsiz JSON quoting ilə ötürülür.
- RESET saxlanmış avatarı silir, standart şəkli həm profilə, həm də oyun panelinə qaytarır.
- Versiya: 2.2.8, versionCode 12.

## Layihənin açılması
Android Studio-da `BakiSaskisiAndroid` qovluğunu açın, Gradle sync edin və Android cihazında işlədin. Min SDK 23, compile SDK 35, Java/Kotlin 17.

## Test qeydi
JavaScript sintaksisi, manifest/resources XML və ZIP arxivi yoxlanıb. Bu mühitdə Android SDK/Gradle build mühiti və fiziki Android cihazı olmadığı üçün APK build, audio çıxışı, foto seçici və real cihaz davranışı təsdiqlənməyib. Bu layihə mənbə kodudur, əvvəlcədən yığılmış APK deyil.
