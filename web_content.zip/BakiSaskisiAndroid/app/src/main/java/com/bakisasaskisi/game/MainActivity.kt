package com.bakisasaskisi.game

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import java.io.ByteArrayOutputStream
import android.net.Uri
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import android.util.Log
import android.view.Gravity
import android.view.View
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.JavascriptInterface
import android.widget.FrameLayout
import android.widget.ProgressBar

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var progress: ProgressBar
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private var anthemPlayer: MediaPlayer? = null
    private var anthemWasPrepared = false
    private var anthemFinished = false
    private var anthemFailed = false
    private var activityInForeground = false
    private val anthemProgressHandler = Handler(Looper.getMainLooper())
    private val anthemProgressRunnable = object : Runnable {
        override fun run() {
            val player = anthemPlayer ?: return
            if (!activityInForeground || !anthemWasPrepared || anthemFinished) return
            try {
                val duration = player.duration.coerceAtLeast(1)
                val position = player.currentPosition.coerceIn(0, duration)
                evaluateAnthemJavascript("window.onNativeAnthemProgress && window.onNativeAnthemProgress($position,$duration)")
                anthemProgressHandler.postDelayed(this, 500L)
            } catch (e: Exception) {
                Log.w(TAG, "Could not read anthem playback position", e)
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 14, 23)
        setVolumeControlStream(android.media.AudioManager.STREAM_MUSIC)
        window.navigationBarColor = Color.rgb(8, 14, 23)

        val root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(8, 14, 23)) }
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            progressTintList = android.content.res.ColorStateList.valueOf(Color.rgb(231, 189, 105))
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(25, 39, 54))
        }
        webView = WebView(this).apply {
            setBackgroundColor(Color.rgb(8, 14, 23))
            settings.javaScriptEnabled = true
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
            settings.allowFileAccessFromFileURLs = false
            settings.allowUniversalAccessFromFileURLs = false
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                settings.safeBrowsingEnabled = true
            }
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.setSupportZoom(false)
            settings.builtInZoomControls = false
            settings.displayZoomControls = false
            isVerticalScrollBarEnabled = false
            isHorizontalScrollBarEnabled = false
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    evaluateAnthemJavascript("window.onNativePageLoaded && window.onNativePageLoaded()")
                    if (anthemFinished) {
                        if (anthemFailed) evaluateAnthemJavascript("window.onNativeAnthemError && window.onNativeAnthemError()")
                        else evaluateAnthemJavascript("window.finishAnthemSplash && window.finishAnthemSplash()")
                    }
                }
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val url = request?.url?.toString() ?: return false
                    return !(url.startsWith("https://") || url.startsWith("http://") || url.startsWith("file:///android_asset/"))
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                    progress.progress = newProgress
                    progress.visibility = if (newProgress >= 100) View.GONE else View.VISIBLE
                    if (::webView.isInitialized) {
                        webView.evaluateJavascript("window.setPageLoadProgress && window.setPageLoadProgress($newProgress)", null)
                    }
                }

                override fun onShowFileChooser(
                    webView: WebView?,
                    filePathCallback: ValueCallback<Array<Uri>>?,
                    fileChooserParams: FileChooserParams?
                ): Boolean {
                    this@MainActivity.fileChooserCallback?.onReceiveValue(null)
                    this@MainActivity.fileChooserCallback = filePathCallback
                    return try {
                        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                            addCategory(Intent.CATEGORY_OPENABLE)
                            type = "image/*"
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        startActivityForResult(intent, FILE_CHOOSER_REQUEST)
                        true
                    } catch (_: Exception) {
                        this@MainActivity.fileChooserCallback = null
                        false
                    }
                }
            }
        }
        webView.addJavascriptInterface(object {
            @JavascriptInterface
            fun stopAnthem() {
                runOnUiThread {
                    anthemFinished = true
                    releaseAnthem()
                }
            }

            @JavascriptInterface
            fun chooseAvatar() {
                runOnUiThread { launchAvatarPicker() }
            }

            @JavascriptInterface
            fun exitApp() {
                runOnUiThread {
                    releaseAnthem()
                    finishAffinity()
                }
            }
        }, "AndroidBridge")
        root.addView(webView, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        root.addView(progress, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, 3, Gravity.TOP))
        setContentView(root)
        if (savedInstanceState == null) webView.loadUrl("file:///android_asset/index.html")
        else webView.restoreState(savedInstanceState)

        // Play the official anthem natively. This avoids Android WebView's
        // HTML-media autoplay restrictions and does not depend on a JS click.
        startNationalAnthem()
    }


    private fun startNationalAnthem() {
        releaseAnthem()
        anthemFinished = false
        anthemFailed = false
        try {
            val attributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()
            // MediaPlayer.create() prepares the packaged raw resource safely,
            // including APK compression; no file-descriptor assumptions or network.
            val player = MediaPlayer.create(this, R.raw.anthem, attributes, android.media.AudioManager.AUDIO_SESSION_ID_GENERATE)
            if (player == null) {
                failAnthem()
                return
            }
            anthemPlayer = player
            player.setVolume(1.0f, 1.0f)
            player.setOnCompletionListener { completed ->
                if (anthemPlayer !== completed) return@setOnCompletionListener
                anthemFinished = true
                releaseAnthem()
                evaluateAnthemJavascript("window.finishAnthemSplash && window.finishAnthemSplash()")
            }
            player.setOnErrorListener { failed, what, extra ->
                Log.e(TAG, "Anthem playback error: what=$what extra=$extra")
                if (anthemPlayer === failed) failAnthem()
                true
            }
            val actualDurationMs = player.duration
            if (actualDurationMs <= 0) {
                failAnthem()
                return
            }
            anthemWasPrepared = true
            if (activityInForeground) startPreparedAnthem(player)
        } catch (_: Exception) {
            failAnthem()
        }
    }

    private fun startPreparedAnthem(player: MediaPlayer) {
        if (anthemPlayer !== player || anthemFinished) return
        try {
            if (!player.isPlaying) {
                player.start()
                evaluateAnthemJavascript("window.onNativeAnthemStarted && window.onNativeAnthemStarted(${player.duration})")
                anthemProgressHandler.removeCallbacks(anthemProgressRunnable)
                anthemProgressHandler.post(anthemProgressRunnable)
            }
        } catch (_: Exception) {
            failAnthem()
        }
    }

    private fun failAnthem() {
        Log.e(TAG, "Anthem could not be played")
        anthemFinished = true
        anthemFailed = true
        releaseAnthem()
        evaluateAnthemJavascript("window.onNativeAnthemError && window.onNativeAnthemError()")
    }

    private fun evaluateAnthemJavascript(script: String) {
        runOnUiThread {
            if (::webView.isInitialized) webView.evaluateJavascript(script, null)
        }
    }

    private fun releaseAnthem() {
        anthemProgressHandler.removeCallbacks(anthemProgressRunnable)
        try { anthemPlayer?.setOnPreparedListener(null); anthemPlayer?.setOnCompletionListener(null); anthemPlayer?.setOnErrorListener(null); anthemPlayer?.release() } catch (_: Exception) { }
        anthemPlayer = null
        anthemWasPrepared = false
    }

    override fun onPause() {
        activityInForeground = false
        anthemProgressHandler.removeCallbacks(anthemProgressRunnable)
        try { if (anthemPlayer?.isPlaying == true) anthemPlayer?.pause() } catch (_: Exception) { }
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        activityInForeground = true
        try {
            val player = anthemPlayer
            if (anthemWasPrepared && player != null && !anthemFinished && !player.isPlaying) {
                startPreparedAnthem(player)
            } else if (anthemWasPrepared && player != null && !anthemFinished && player.isPlaying) {
                anthemProgressHandler.removeCallbacks(anthemProgressRunnable)
                anthemProgressHandler.post(anthemProgressRunnable)
            }
        } catch (_: Exception) { }
    }

    private fun launchAvatarPicker() {
        try {
            // ACTION_GET_CONTENT opens Android's system photo picker on modern
            // Android versions and remains compatible with older gallery apps.
            val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                type = "image/*"
                addCategory(Intent.CATEGORY_OPENABLE)
            }
            startActivityForResult(Intent.createChooser(intent, "Avatar şəkli seç"), AVATAR_PICKER_REQUEST)
        } catch (_: Exception) {
            evaluateAnthemJavascript("window.onNativeAvatarError && window.onNativeAvatarError()")
        }
    }

    private fun uriFromResult(data: Intent?): Uri? {
        data?.data?.let { return it }
        val clip = data?.clipData
        if (clip != null && clip.itemCount > 0) return clip.getItemAt(0).uri
        return null
    }

    private fun makeAvatarDataUri(uri: Uri): String? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 1200) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        val decoded = contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, options)
        } ?: return null

        try {
            val cropSize = minOf(decoded.width, decoded.height)
            if (cropSize <= 0) return null
            val left = (decoded.width - cropSize) / 2
            val top = (decoded.height - cropSize) / 2
            val square = Bitmap.createBitmap(decoded, left, top, cropSize, cropSize)
            val scaled = Bitmap.createScaledBitmap(square, 320, 320, true)
            if (square !== decoded) square.recycle()
            val output = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, 78, output)
            if (scaled !== decoded) scaled.recycle()
            return "data:image/jpeg;base64," + Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP)
        } finally {
            decoded.recycle()
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == AVATAR_PICKER_REQUEST) {
            if (resultCode == RESULT_OK) {
                val uri = uriFromResult(data)
                val dataUrl = try { uri?.let { makeAvatarDataUri(it) } } catch (_: Exception) { null }
                if (dataUrl != null) {
                    val safeDataUrl = JSONObject.quote(dataUrl)
                    webView.evaluateJavascript("window.onNativeAvatarSelected && window.onNativeAvatarSelected($safeDataUrl)", null)
                } else {
                    webView.evaluateJavascript("window.onNativeAvatarError && window.onNativeAvatarError()", null)
                }
            }
            return
        }
        if (requestCode == FILE_CHOOSER_REQUEST) {
            val uri = if (resultCode == RESULT_OK) uriFromResult(data) else null
            fileChooserCallback?.onReceiveValue(uri?.let { arrayOf(it) })
            fileChooserCallback = null
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (::webView.isInitialized) {
            webView.evaluateJavascript(
                "(function(){var game=document.getElementById('gameBoard');var online=document.getElementById('onlinePanel');if(game&&!game.classList.contains('hidden')){document.getElementById('exitGame').click();return true;}if(online&&!online.classList.contains('hidden')){online.classList.add('hidden');return true;}return false;})()"
            ) { handled -> if (handled != "true") moveTaskToBack(true) }
        } else super.onBackPressed()
    }

    override fun onDestroy() {
        fileChooserCallback?.onReceiveValue(null)
        fileChooserCallback = null
        releaseAnthem()
        if (::webView.isInitialized) {
            webView.stopLoading()
            webView.destroy()
        }
        super.onDestroy()
    }

    companion object {
        private const val TAG = "BakiSaskisi"
        private const val FILE_CHOOSER_REQUEST = 7412
        private const val AVATAR_PICKER_REQUEST = 7413
    }
}
