# QA REPORT — 2.2.8

## Yoxlanılanlar
- [x] Inline JavaScript `node --check` sintaksis yoxlamasından keçir.
- [x] AndroidManifest.xml və styles.xml XML kimi düzgün parse olunur.
- [x] Anthem MP3 faylı layihədə mövcuddur (2,172,595 bayt; təxminən 135.76 saniyə).
- [x] Splash faizinin audio hissəsi native MediaPlayer currentPosition/duration əsasında hesablanır; saxta interval/taymer yoxdur.
- [x] Anthem tamamlanma callback-i 100%-ə çatdırır.
- [x] Anthem xəta verərsə xəta mətni və əl ilə davam düyməsi göstərilir.
- [x] Avatar picker ACTION_GET_CONTENT ilə sistem foto seçicisini açır.
- [x] Avatar bitmap-i 320x320 JPEG-ə çevrilir və JSON-safe data URI ilə WebView-ə ötürülür.
- [x] RESET localStorage açarını silir və profil/oyun avatarını standart şəklə qaytarır.
- [x] PeerJS skripti async olduğuna görə CDN gecikməsi əsas HTML/oyun skriptinin parse edilməsini bloklamır.
- [x] ZIP arxiv bütövlüyü yoxlanır.

## Hələ fiziki cihazda təsdiqlənməyib
- APK compile/install/run.
- Telefonun media səs səviyyəsi, audio focus və real hoparlördən 135.76 saniyəlik himnin səslənməsi.
- Android 14/Huawei foto seçicisi və müxtəlif şəkil formatları.
- Avatarın proqram bağlandıqdan sonra qalması və RESET-dən sonra default şəkilə qayıtması.
- PeerJS signaling serverinin real internetdə əlçatanlığı və iki cihaz arasında online oyun.

Bu mühitdə Android SDK/Gradle build alətləri olmadığı üçün hazır APK və fiziki cihaz testinin uğurlu olduğu iddia edilmir.
