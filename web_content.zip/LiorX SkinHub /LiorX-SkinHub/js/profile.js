
import { supabase } from "./supabase.js";

const usernameTitle = document.getElementById("profile-username");
const emailSubtitle = document.getElementById("profile-email");
const usernameInfo = document.getElementById("profile-name");
const emailInfo = document.getElementById("profile-email-info");
const avatar = document.getElementById("profile-avatar");
const message = document.getElementById("profile-message");
const logoutButton = document.getElementById("logout-button");

const favoritesGallery = document.getElementById("favorites-gallery");
const publishedGallery = document.getElementById("published-gallery");

function formatDate(date) {
  if (!date) return "Data indisponível";
  return new Date(date).toLocaleDateString("pt-BR");
}

// CRIAR CARTÃO
function createSkinCard(skin, showRemoveButton = false, userId = null) {
  const card = document.createElement("div");
  card.className = "favorite-card";

  const canvas = document.createElement("canvas");
  canvas.width = 220;
  canvas.height = 220;

  const title = document.createElement("h3");
  title.textContent = skin.name || "Skin sem nome";

  const downloads = document.createElement("p");
  downloads.textContent = `⬇ Downloads: ${skin.downloads || 0}`;

  const date = document.createElement("p");
  date.textContent = `📅 Publicada em: ${formatDate(skin.created_at)}`;

  const openLink = document.createElement("a");
  openLink.href = `skin.html?id=${encodeURIComponent(skin.id)}`;
  openLink.textContent = "Ver skin";

  card.append(canvas, title, downloads, date, openLink);

  // FAVORITOS
  if (showRemoveButton) {
    const removeButton = document.createElement("button");
    removeButton.type = "button";
    removeButton.textContent = "⭐ Remover dos favoritos";

    removeButton.addEventListener("click", async () => {
      removeButton.disabled = true;
      removeButton.textContent = "Removendo...";

      const { error } = await supabase
        .from("skin_favorites")
        .delete()
        .eq("skin_id", skin.id)
        .eq("user_id", userId);

      if (error) {
        alert("Não foi possível remover dos favoritos.");
        removeButton.disabled = false;
        removeButton.textContent = "⭐ Remover dos favoritos";
        return;
      }

      card.remove();

      if (favoritesGallery.children.length === 0) {
        favoritesGallery.textContent =
          "Você ainda não salvou nenhuma skin.";
      }
    });

    card.appendChild(removeButton);
  }

  // EDIÇÃO E EXCLUSÃO DAS PUBLICAÇÕES
  if (!showRemoveButton) {
    const editButton = document.createElement("button");
    editButton.type = "button";
    editButton.textContent = "✏️ Editar publicação";

    editButton.addEventListener("click", async () => {
      const newName = prompt("Novo nome da skin:", skin.name);

      if (newName === null) return;

      if (!newName.trim()) {
        alert("O nome não pode ficar vazio.");
        return;
      }

      const newDescription = prompt(
        "Nova descrição da skin:",
        skin.description || ""
      );

      if (newDescription === null) return;

      editButton.disabled = true;
      editButton.textContent = "Salvando...";

      const { error } = await supabase
        .from("skins")
        .update({
          name: newName.trim(),
          description: newDescription.trim()
        })
        .eq("id", skin.id)
        .eq("user_id", userId);

      if (error) {
        console.error("Erro ao editar skin:", error);
        alert("Não foi possível editar a publicação.");
        editButton.disabled = false;
        editButton.textContent = "✏️ Editar publicação";
        return;
      }

      await loadPublished(userId);
    });

    const deleteButton = document.createElement("button");
    deleteButton.type = "button";
    deleteButton.textContent = "🗑️ Excluir publicação";

    deleteButton.addEventListener("click", async () => {
      const confirmed = confirm(
        `Tem certeza que deseja excluir "${skin.name}"? Essa ação não pode ser desfeita.`
      );

      if (!confirmed) return;

      deleteButton.disabled = true;
      deleteButton.textContent = "Excluindo...";

      const { error: deleteError } = await supabase
        .from("skins")
        .delete()
        .eq("id", skin.id)
        .eq("user_id", userId);

      if (deleteError) {
        console.error("Erro ao excluir skin:", deleteError);
        alert("Não foi possível excluir a publicação.");
        deleteButton.disabled = false;
        deleteButton.textContent = "🗑️ Excluir publicação";
        return;
      }

      const { error: storageError } = await supabase.storage
        .from("skins")
        .remove([skin.image_path]);

      if (storageError) {
        console.error("Erro ao excluir imagem:", storageError);
        alert("A publicação foi excluída, mas a imagem não pôde ser removida do armazenamento.");
      }

      await loadPublished(userId);
      await loadFavorites(userId);
    });

    card.append(editButton, deleteButton);
  }

  const { data: imageData } = supabase.storage
    .from("skins")
    .getPublicUrl(skin.image_path);

  if (window.skinview3d && imageData.publicUrl) {
    try {
      const viewer = new window.skinview3d.SkinViewer({
        canvas,
        width: 220,
        height: 220,
        skin: imageData.publicUrl
      });

      viewer.autoRotate = false;
    } catch (error) {
      console.error("Erro ao carregar modelo 3D:", error);
    }
  }

  return card;
}

// ==========================================
// CARREGAR SKINS FAVORITAS
// ==========================================

async function loadFavorites(userId) {
  favoritesGallery.textContent = "Carregando favoritas...";

  const { data: favorites, error } = await supabase
    .from("skin_favorites")
    .select("skin_id")
    .eq("user_id", userId);

  if (error) {
    favoritesGallery.textContent = "Erro ao carregar favoritas.";
    console.error(error);
    return;
  }

  if (!favorites || favorites.length === 0) {
    favoritesGallery.textContent = "Você ainda não tem skins favoritas.";
    return;
  }

  const skinIds = favorites.map(item => item.skin_id);

  const { data: skins, error: skinsError } = await supabase
    .from("skins")
    .select("*")
    .in("id", skinIds);

  if (skinsError) {
    favoritesGallery.textContent = "Erro ao carregar skins.";
    console.error(skinsError);
    return;
  }

  favoritesGallery.innerHTML = "";

  if (!skins || skins.length === 0) {
    favoritesGallery.textContent = "Nenhuma skin encontrada.";
    return;
  }

  skins.forEach(skin => {
    favoritesGallery.appendChild(
      createSkinCard(skin, true, userId)
    );
  });
}


// ==========================================
// CARREGAR MINHAS PUBLICAÇÕES
// ==========================================

async function loadPublished(userId) {
  publishedGallery.textContent = "Carregando publicações...";

  const { data: skins, error } = await supabase
    .from("skins")
    .select("*")
    .eq("user_id", userId)
    .order("created_at", { ascending: false });

  if (error) {
    publishedGallery.textContent = "Erro ao carregar publicações.";
    console.error(error);
    return;
  }

  publishedGallery.innerHTML = "";

  if (!skins || skins.length === 0) {
    publishedGallery.textContent = "Você ainda não publicou nenhuma skin.";
    return;
  }

  skins.forEach(skin => {
    publishedGallery.appendChild(
      createSkinCard(skin, false, userId)
    );
  });
}


// ==========================================
// CARREGAR PERFIL DO USUÁRIO
// ==========================================

async function loadProfile() {
  const { data: sessionData, error: sessionError } =
    await supabase.auth.getSession();

  if (sessionError || !sessionData.session) {
    window.location.href = "login.html";
    return;
  }

  const user = sessionData.session.user;

  const { data: profile, error } = await supabase
    .from("profiles")
    .select("username")
    .eq("id", user.id)
    .single();

  if (error) {
    console.error("Erro ao carregar perfil:", error);
  }

  const username = profile?.username || "Usuário";

  usernameTitle.textContent = username;
  emailSubtitle.textContent = user.email || "";
  usernameInfo.textContent = username;
  emailInfo.textContent = user.email || "";
  avatar.textContent = username.charAt(0).toUpperCase();

  await loadFavorites(user.id);
  await loadPublished(user.id);
}


// ==========================================
// SAIR DA CONTA
// ==========================================

logoutButton.addEventListener("click", async () => {
  const { error } = await supabase.auth.signOut();

  if (error) {
    alert("Não foi possível sair da conta.");
    console.error(error);
    return;
  }

  window.location.href = "../index.html";
});


// ==========================================
// INICIAR PERFIL
// ==========================================

loadProfile();

