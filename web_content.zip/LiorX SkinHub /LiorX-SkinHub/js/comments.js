
import { supabase } from "./supabase.js";

const commentInput = document.getElementById("comment-input");
const sendButton = document.getElementById("send-comment");
const commentsList = document.getElementById("comments-list");
const commentMessage = document.getElementById("comment-message");

const params = new URLSearchParams(window.location.search);
const skinId = params.get("id");

let currentUser = null;

function showMessage(text, success = false) {
  commentMessage.textContent = text;
  commentMessage.style.color = success ? "#a66aff" : "#ff7777";
}

// BUSCAR USUÁRIO
async function loadUser() {
  const { data, error } = await supabase.auth.getUser();

  if (error) {
    currentUser = null;
    return;
  }

  currentUser = data.user;
}

// CARREGAR COMENTÁRIOS
async function loadComments() {
  commentsList.textContent = "Carregando comentários...";

  const { data: comments, error } = await supabase
    .from("skin_comments")
    .select("id, user_id, content, created_at")
    .eq("skin_id", skinId)
    .order("created_at", { ascending: false });

  if (error) {
    console.error("Erro ao carregar comentários:", error);
    commentsList.textContent = "Não foi possível carregar os comentários.";
    return;
  }

  commentsList.innerHTML = "";

  if (!comments || comments.length === 0) {
    commentsList.textContent = "Ainda não existem comentários. Seja o primeiro!";
    return;
  }

  const userIds = [...new Set(comments.map(comment => comment.user_id))];

  const { data: profiles } = await supabase
    .from("profiles")
    .select("id, username")
    .in("id", userIds);

  const usernames = {};

  (profiles || []).forEach(profile => {
    usernames[profile.id] = profile.username;
  });

  comments.forEach(comment => {
    const card = document.createElement("div");
    card.className = "comment-card";

    const header = document.createElement("div");
    header.className = "comment-card-header";

    const username = document.createElement("strong");
    username.textContent = usernames[comment.user_id] || "Usuário";

    const date = document.createElement("span");
    date.textContent = new Date(comment.created_at).toLocaleDateString("pt-BR");

    header.append(username, date);

    const content = document.createElement("p");
    content.textContent = comment.content;

    card.append(header, content);

    if (currentUser && currentUser.id === comment.user_id) {
      const deleteButton = document.createElement("button");
      deleteButton.type = "button";
      deleteButton.className = "delete-comment";
      deleteButton.textContent = "Excluir comentário";

      deleteButton.addEventListener("click", async () => {
        deleteButton.disabled = true;
        deleteButton.textContent = "Excluindo...";

        const { error } = await supabase
          .from("skin_comments")
          .delete()
          .eq("id", comment.id)
          .eq("user_id", currentUser.id);

        if (error) {
          alert("Não foi possível excluir o comentário.");
          deleteButton.disabled = false;
          deleteButton.textContent = "Excluir comentário";
          return;
        }

        await loadComments();
      });

      card.appendChild(deleteButton);
    }

    commentsList.appendChild(card);
  });
}

// PUBLICAR COMENTÁRIO
sendButton.addEventListener("click", async () => {
  const content = commentInput.value.trim();

  if (!skinId) {
    showMessage("Não foi possível identificar esta skin.");
    return;
  }

  if (!content) {
    showMessage("Escreva um comentário primeiro.");
    return;
  }

  if (content.length > 500) {
    showMessage("O comentário ultrapassou 500 caracteres.");
    return;
  }

  if (!currentUser) {
    showMessage("Entre na sua conta para comentar.");
    return;
  }

  sendButton.disabled = true;
  sendButton.textContent = "Publicando...";

  const { error } = await supabase
    .from("skin_comments")
    .insert({
      skin_id: skinId,
      user_id: currentUser.id,
      content: content
    });

  if (error) {
    console.error("Erro ao publicar comentário:", error);
    showMessage("Não foi possível publicar o comentário.");
    sendButton.disabled = false;
    sendButton.textContent = "Publicar comentário";
    return;
  }

  commentInput.value = "";
  showMessage("Comentário publicado!", true);

  await loadComments();

  sendButton.disabled = false;
  sendButton.textContent = "Publicar comentário";
});

// INICIAR
async function initComments() {
  if (!skinId) {
    commentsList.textContent = "Skin não encontrada.";
    sendButton.disabled = true;
    return;
  }

  await loadUser();
  await loadComments();
}

initComments();
