
import { supabase } from "./supabase.js";

const gallery = document.getElementById("skins-gallery");
const search = document.getElementById("skin-search");

let allSkins = [];
let viewers = [];
let isAdmin = false;

// ==========================================
// VERIFICAR ADMINISTRADOR
// ==========================================

async function checkAdmin() {
  try {
    const { data: sessionData } = await supabase.auth.getSession();

    if (!sessionData.session) return false;

    const { data, error } = await supabase.rpc("is_skinhub_admin");

    if (error) {
      console.error("Erro ao verificar administrador:", error);
      return false;
    }

    return data === true;

  } catch (error) {
    console.error(error);
    return false;
  }
}

// ==========================================
// CARREGAR SKINS
// ==========================================

async function loadSkins() {
  gallery.innerHTML = "<p>Carregando skins...</p>";

  isAdmin = await checkAdmin();

  const { data, error } = await supabase
    .from("skins")
    .select("*")
    .order("created_at", { ascending: false });

  if (error) {
    console.error(error);
    gallery.textContent = "Não foi possível carregar as skins.";
    return;
  }

  allSkins = data || [];
  renderSkins(allSkins);
}

// ==========================================
// EXCLUIR SKIN
// ==========================================

async function deleteSkin(skin, button) {
  const confirmed = confirm(
    `Deseja realmente excluir a skin "${skin.name}"?\n\nEssa ação não poderá ser desfeita.`
  );

  if (!confirmed) return;

  button.disabled = true;
  button.textContent = "Excluindo...";

  try {
    // Excluir registro da skin
    const { error: deleteError } = await supabase
      .from("skins")
      .delete()
      .eq("id", skin.id);

    if (deleteError) throw deleteError;

    // Excluir imagem do armazenamento
    const { error: storageError } = await supabase.storage
      .from("skins")
      .remove([skin.image_path]);

    if (storageError) {
      console.error("Erro ao excluir imagem:", storageError);

      alert(
        "A skin foi excluída da galeria, mas não foi possível remover o arquivo de imagem."
      );
    } else {
      alert("Skin excluída com sucesso!");
    }

    await loadSkins();

  } catch (error) {
    console.error("Erro ao excluir skin:", error);

    alert(
      "Não foi possível excluir a skin: " +
      (error.message || "Erro desconhecido.")
    );

    button.disabled = false;
    button.textContent = "Excluir skin";
  }
}

// ==========================================
// MOSTRAR GALERIA
// ==========================================

function renderSkins(skins) {
  viewers.forEach(viewer => viewer.dispose());
  viewers = [];

  gallery.innerHTML = "";

  if (skins.length === 0) {
    gallery.innerHTML = "<p>Nenhuma skin encontrada.</p>";
    return;
  }

  skins.forEach(skin => {
    const { data } = supabase.storage
      .from("skins")
      .getPublicUrl(skin.image_path);

    const card = document.createElement("div");
    card.className = "skin-card";

    const link = document.createElement("a");
    link.href = `./pages/skin.html?id=${encodeURIComponent(skin.id)}`;
    link.style.textDecoration = "none";
    link.style.color = "inherit";
    link.style.display = "block";

    const canvas = document.createElement("canvas");
    canvas.width = 220;
    canvas.height = 260;
    canvas.style.pointerEvents = "none";

    const title = document.createElement("h3");
    title.textContent = skin.name;

    const description = document.createElement("p");
    description.textContent = skin.description || "Sem descrição.";

    link.append(canvas, title, description);
    card.appendChild(link);

    // Botão exclusivo do administrador
    if (isAdmin) {
      const deleteButton = document.createElement("button");

      deleteButton.type = "button";
      deleteButton.textContent = "Excluir skin";

      deleteButton.style.cssText = `
        width: 100%;
        padding: 11px;
        margin-top: 10px;
        border: none;
        border-radius: 8px;
        background: #8b2635;
        color: white;
        font-weight: bold;
        cursor: pointer;
      `;

      deleteButton.addEventListener("click", () => {
        deleteSkin(skin, deleteButton);
      });

      card.appendChild(deleteButton);
    }

    gallery.appendChild(card);

    try {
      const viewer = new window.skinview3d.SkinViewer({
        canvas,
        width: 220,
        height: 260,
        skin: data.publicUrl
      });

      viewer.autoRotate = false;
      viewers.push(viewer);

    } catch (error) {
      console.error("Erro ao mostrar skin:", error);
    }
  });
}

// ==========================================
// PESQUISA
// ==========================================

search.addEventListener("input", () => {
  const term = search.value.trim().toLowerCase();

  const filtered = allSkins.filter(skin =>
    (skin.name || "").toLowerCase().includes(term) ||
    (skin.description || "").toLowerCase().includes(term)
  );

  renderSkins(filtered);
});

// ==========================================
// INICIAR
// ==========================================

loadSkins();
