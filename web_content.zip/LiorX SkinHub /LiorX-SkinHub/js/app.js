
import { supabase } from "./supabase.js";

const account = document.querySelector(".account");

async function updateAccount() {
  const { data } = await supabase.auth.getSession();
  const session = data.session;

  if (!account) return;

  account.innerHTML = "";

  if (session) {
    const profileLink = document.createElement("a");
    profileLink.href = "./pages/profile.html";
    profileLink.className = "register";
    profileLink.textContent = "Meu perfil";

    const logoutButton = document.createElement("button");
    logoutButton.className = "login";
    logoutButton.textContent = "Sair";
    logoutButton.style.background = "none";
    logoutButton.style.border = "none";
    logoutButton.style.cursor = "pointer";

    logoutButton.addEventListener("click", async () => {
      const { error } = await supabase.auth.signOut();

      if (error) {
        alert("Não foi possível sair da conta.");
        return;
      }

      updateAccount();
    });

    account.append(profileLink, logoutButton);
  } else {
    const loginLink = document.createElement("a");
    loginLink.href = "./pages/login.html";
    loginLink.className = "login";
    loginLink.textContent = "Entrar";

    const registerLink = document.createElement("a");
    registerLink.href = "./pages/register.html";
    registerLink.className = "register";
    registerLink.textContent = "Criar conta";

    account.append(loginLink, registerLink);
  }
}

updateAccount();

supabase.auth.onAuthStateChange(() => {
  updateAccount();
});

console.log("LiorX SkinHub iniciado!");
