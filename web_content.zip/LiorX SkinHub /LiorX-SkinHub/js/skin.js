
import { supabase } from "./supabase.js";

const params = new URLSearchParams(window.location.search);
const skinId = params.get("id");

const nameElement = document.getElementById("skin-name");
const descriptionElement = document.getElementById("skin-description");
const downloadsElement = document.getElementById("skin-downloads");
const dateElement = document.getElementById("skin-date");
const creatorElement = document.getElementById("skin-creator");

const downloadButton = document.getElementById("download-skin");
const likeButton = document.getElementById("like-button");
const likesCount = document.getElementById("likes-count");
const favoriteButton = document.getElementById("favorite-button");

let currentSkin = null;
let publicUrl = null;
let userLiked = false;
let userFavorited = false;

// CARREGAR SKIN
async function loadSkin() {
  if (!skinId) {
    nameElement.textContent = "Skin não encontrada.";
    return;
  }

  const { data: skin, error } = await supabase
    .from("skins")
    .select("*")
    .eq("id", skinId)
    .single();

  if (error || !skin) {
    console.error("Erro ao carregar skin:", error);
    nameElement.textContent = "Não foi possível encontrar essa skin.";
    return;
  }

  currentSkin = skin;

  nameElement.textContent = skin.name;
  descriptionElement.textContent = skin.description || "Sem descrição.";
  downloadsElement.textContent = skin.downloads || 0;

  dateElement.textContent = skin.created_at
    ? new Date(skin.created_at).toLocaleDateString("pt-BR")
    : "Data indisponível";

  const { data: profile } = await supabase
    .from("profiles")
    .select("username")
    .eq("id", skin.user_id)
    .single();

  creatorElement.textContent =
    profile?.username || "Usuário desconhecido";

  const { data: imageData } = supabase.storage
    .from("skins")
    .getPublicUrl(skin.image_path);

  publicUrl = imageData.publicUrl;

  const viewer = new window.skinview3d.SkinViewer({
    canvas: document.getElementById("skin-viewer"),
    width: 300,
    height: 400,
    skin: publicUrl
  });

  viewer.autoRotate = true;

  await updateLikes();
  await updateFavoriteButton();
}

// ATUALIZAR CURTIDAS
async function updateLikes() {
  if (!currentSkin) return;

  const { count, error } = await supabase
    .from("skin_likes")
    .select("*", { count: "exact", head: true })
    .eq("skin_id", currentSkin.id);

  if (error) {
    console.error("Erro nas curtidas:", error);
    return;
  }

  const { data: userData } = await supabase.auth.getUser();
  const user = userData.user;

  if (user) {
    const { data: like, error: likeError } = await supabase
      .from("skin_likes")
      .select("id")
      .eq("skin_id", currentSkin.id)
      .eq("user_id", user.id)
      .maybeSingle();

    if (likeError) {
      console.error("Erro ao verificar curtida:", likeError);
      return;
    }

    userLiked = !!like;
  } else {
    userLiked = false;
  }

  likesCount.textContent = `${count || 0} curtidas`;
  likeButton.textContent = userLiked ? "❤️ Curtido" : "🤍 Curtir";
}

 
// BOTÃO CURTIR / DESCURTIR
likeButton.addEventListener("click", async () => {
  if (!currentSkin) return;

  const { data: userData } = await supabase.auth.getUser();
  const user = userData.user;

  if (!user) {
    alert("Entre na sua conta para curtir skins!");
    return;
  }

  likeButton.disabled = true;

  try {
    // Consulta novamente o banco antes de decidir
    const { data: existingLike, error: checkError } = await supabase
      .from("skin_likes")
      .select("id")
      .eq("skin_id", currentSkin.id)
      .eq("user_id", user.id)
      .maybeSingle();

    if (checkError) throw checkError;

    if (existingLike) {
      const { error } = await supabase
        .from("skin_likes")
        .delete()
        .eq("id", existingLike.id);

      if (error) throw error;
    } else {
      const { error } = await supabase
        .from("skin_likes")
        .insert({
          skin_id: currentSkin.id,
          user_id: user.id
        });

      if (error) throw error;
    }

    await updateLikes();

  } catch (error) {
    console.error("Erro nas curtidas:", error);
    alert("Erro nas curtidas: " + error.message);
  }

  likeButton.disabled = false;
});

// ATUALIZAR FAVORITOS
async function updateFavoriteButton() {
  if (!currentSkin) return;

  const { data: userData } = await supabase.auth.getUser();
  const user = userData.user;

  if (!user) {
    userFavorited = false;
    favoriteButton.textContent = "☆ Adicionar aos favoritos";
    return;
  }

  const { data, error } = await supabase
    .from("skin_favorites")
    .select("id")
    .eq("skin_id", currentSkin.id)
    .eq("user_id", user.id)
    .maybeSingle();

  if (error) {
    console.error("Erro ao carregar favoritos:", error);
    return;
  }

  userFavorited = !!data;

  favoriteButton.textContent = userFavorited
    ? "⭐ Remover dos favoritos"
    : "☆ Adicionar aos favoritos";
}

// BOTÃO FAVORITOS
favoriteButton.addEventListener("click", async () => {
  if (!currentSkin) return;

  const { data: userData } = await supabase.auth.getUser();
  const user = userData.user;

  if (!user) {
    alert("Entre na sua conta para salvar favoritos!");
    return;
  }

  favoriteButton.disabled = true;

  try {
    const { data: existingFavorite, error: checkError } = await supabase
      .from("skin_favorites")
      .select("id")
      .eq("skin_id", currentSkin.id)
      .eq("user_id", user.id)
      .maybeSingle();

    if (checkError) throw checkError;

    if (existingFavorite) {
      const { error } = await supabase
        .from("skin_favorites")
        .delete()
        .eq("id", existingFavorite.id);

      if (error) throw error;
    } else {
      const { error } = await supabase
        .from("skin_favorites")
        .insert({
          skin_id: currentSkin.id,
          user_id: user.id
        });

      if (error) throw error;
    }

    await updateFavoriteButton();

  } catch (error) {
    console.error("Erro nos favoritos:", error);
    alert("Erro nos favoritos: " + error.message);
  }

  favoriteButton.disabled = false;
});

// BOTÃO DOWNLOAD
downloadButton.addEventListener("click", async () => {
  if (!currentSkin || !publicUrl) return;

  downloadButton.disabled = true;
  downloadButton.textContent = "Baixando...";

  try {
    const response = await fetch(publicUrl);

    if (!response.ok) {
      throw new Error("Falha no download.");
    }

    const blob = await response.blob();
    const blobUrl = URL.createObjectURL(blob);

    const link = document.createElement("a");
    link.href = blobUrl;
    link.download = currentSkin.name + ".png";
    link.click();

    setTimeout(() => URL.revokeObjectURL(blobUrl), 1000);

    const { data, error } = await supabase.rpc(
      "increment_skin_downloads",
      { p_skin_id: currentSkin.id }
    );

    if (error) throw error;

    downloadsElement.textContent = data;

  } catch (error) {
    console.error("Erro no download:", error);
    alert("Não foi possível concluir o download: " + error.message);
  }

  downloadButton.disabled = false;
  downloadButton.textContent = "Baixar imagem";
});

// INICIAR SISTEMA
loadSkin();
