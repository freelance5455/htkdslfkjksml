
import { supabase } from "./supabase.js";

const reasonInput = document.getElementById("report-reason");
const detailsInput = document.getElementById("report-details");
const sendButton = document.getElementById("send-report");
const message = document.getElementById("report-message");

function showMessage(text, success = false) {
  message.textContent = text;
  message.style.color = success ? "#a78bfa" : "#ff7777";
}

async function sendReport() {
  const reason = reasonInput.value;
  const details = detailsInput.value.trim();

  if (!reason) {
    showMessage("Selecione um motivo para a denúncia.");
    return;
  }

  const params = new URLSearchParams(window.location.search);
  const skinId = params.get("id");

  if (!skinId) {
    showMessage("Não foi possível identificar esta skin.");
    return;
  }

  sendButton.disabled = true;
  sendButton.textContent = "Enviando...";

  try {
    const { data: sessionData, error: sessionError } =
      await supabase.auth.getSession();

    if (sessionError || !sessionData.session) {
      showMessage("Entre na sua conta para denunciar uma skin.");
      return;
    }

    const user = sessionData.session.user;

    const { data: skin, error: skinError } = await supabase
      .from("skins")
      .select("id, user_id")
      .eq("id", skinId)
      .maybeSingle();

    if (skinError || !skin) {
      showMessage("Esta skin não foi encontrada.");
      return;
    }

    if (skin.user_id === user.id) {
      showMessage("Você não pode denunciar sua própria skin.");
      return;
    }

    const { error } = await supabase
      .from("skin_reports")
      .insert({
        skin_id: skinId,
        reporter_id: user.id,
        reason: reason,
        details: details || null
      });

    if (error) {
      if (error.code === "23505") {
        showMessage("Você já denunciou esta skin.");
      } else {
        console.error("Erro na denúncia:", error);
        showMessage("Não foi possível enviar a denúncia.");
      }

      return;
    }

    showMessage("Denúncia enviada com sucesso! Obrigado por ajudar.", true);

    reasonInput.value = "";
    detailsInput.value = "";

  } catch (error) {
    console.error(error);
    showMessage("Ocorreu um erro ao enviar a denúncia.");
  } finally {
    sendButton.disabled = false;
    sendButton.textContent = "Enviar denúncia";
  }
}

sendButton.addEventListener("click", sendReport);
