
import { supabase } from "./supabase.js";

// CADASTRO
const signupForm = document.getElementById("signup-form");

if (signupForm) {
  signupForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    const username = document
      .getElementById("signup-username")
      .value.trim();

    const email = document
      .getElementById("signup-email")
      .value.trim();

    const password = document
      .getElementById("signup-password")
      .value;

    const message = document.getElementById("signup-message");

    if (!/^[a-zA-Z0-9_]{3,20}$/.test(username)) {
      message.textContent =
        "Use de 3 a 20 caracteres: letras, números ou _";
      return;
    }

    message.textContent = "Criando sua conta...";

    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          username: username
        }
      }
    });

    if (error) {
      message.textContent = error.message;
      return;
    }

    if (data.session) {
      message.textContent = "Conta criada com sucesso!";

      setTimeout(() => {
        window.location.href = "../index.html";
      }, 1200);
    } else {
      message.textContent =
        "Conta criada! Confira seu e-mail para confirmar o cadastro.";
    }
  });
}

// LOGIN
const loginForm = document.getElementById("login-form");

if (loginForm) {
  loginForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    const email = document.getElementById("login-email").value.trim();
    const password = document.getElementById("login-password").value;
    const message = document.getElementById("login-message");

    message.textContent = "Entrando...";

    const { error } = await supabase.auth.signInWithPassword({
      email,
      password
    });

    if (error) {
      message.textContent = error.message;
      return;
    }

    message.textContent = "Login realizado!";

    setTimeout(() => {
      window.location.href = "../index.html";
    }, 1000);
  });
}
