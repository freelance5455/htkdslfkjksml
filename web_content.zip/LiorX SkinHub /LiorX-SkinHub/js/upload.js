
import { supabase } from "./supabase.js";

const form = document.getElementById("upload-form");
const nameInput = document.getElementById("skin-name");
const descriptionInput = document.getElementById("skin-description");
const fileInput = document.getElementById("skin-file");
const preview = document.getElementById("image-preview");
const message = document.getElementById("upload-message");
const publishButton = document.getElementById("publish-button");

let selectedFile = null;

const { data: sessionData } = await supabase.auth.getSession();

if (!sessionData.session) {
  window.location.href = "login.html";
}

fileInput.addEventListener("change", () => {
  selectedFile = fileInput.files[0];

  preview.innerHTML = "";

  if (!selectedFile) {
    preview.textContent = "Sua imagem aparecerá aqui";
    return;
  }

  if (selectedFile.type !== "image/png") {
    selectedFile = null;
    fileInput.value = "";
    preview.textContent = "Selecione um arquivo PNG.";
    return;
  }

  if (selectedFile.size > 2 * 1024 * 1024) {
    selectedFile = null;
    fileInput.value = "";
    preview.textContent = "A imagem deve ter no máximo 2 MB.";
    return;
  }

  const image = document.createElement("img");
  image.src = URL.createObjectURL(selectedFile);
  image.alt = "Pré-visualização da skin";
  preview.appendChild(image);
});

form.addEventListener("submit", async (event) => {
  event.preventDefault();

  const { data: currentData } = await supabase.auth.getSession();
  const user = currentData.session?.user;

  if (!user) {
    window.location.href = "login.html";
    return;
  }

  if (!selectedFile) {
    message.textContent = "Escolha uma imagem PNG válida.";
    return;
  }

  const skinName = nameInput.value.trim();
  const description = descriptionInput.value.trim();

  if (!skinName) {
    message.textContent = "Digite um nome para sua skin.";
    return;
  }

  publishButton.disabled = true;
  publishButton.textContent = "Publicando...";
  message.textContent = "Enviando sua skin...";

  const filePath = `${user.id}/${crypto.randomUUID()}.png`;

  const { error: uploadError } = await supabase.storage
    .from("skins")
    .upload(filePath, selectedFile, {
      contentType: "image/png",
      upsert: false
    });

  if (uploadError) {
    message.textContent = "Erro ao enviar imagem: " + uploadError.message;
    publishButton.disabled = false;
    publishButton.textContent = "Publicar skin";
    return;
  }

  const { error: databaseError } = await supabase
    .from("skins")
    .insert({
      user_id: user.id,
      name: skinName,
      description: description,
      image_path: filePath
    });

  if (databaseError) {
    await supabase.storage.from("skins").remove([filePath]);

    message.textContent = "Erro ao salvar skin: " + databaseError.message;
    publishButton.disabled = false;
    publishButton.textContent = "Publicar skin";
    return;
  }

  message.textContent = "Skin publicada com sucesso! 💜";
  form.reset();
  selectedFile = null;
  preview.textContent = "Sua imagem aparecerá aqui";

  publishButton.disabled = false;
  publishButton.textContent = "Publicar skin";
});
