
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const SUPABASE_URL = "https://ogfbqfpffcdlfqglhjja.supabase.co";
const SUPABASE_KEY = "sb_publishable_YrquSfxPikBcQgxTgW3EgA_Xtr33i2M";

export const supabase = createClient(
  SUPABASE_URL,
  SUPABASE_KEY
);
