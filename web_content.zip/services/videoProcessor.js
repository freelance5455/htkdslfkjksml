const ffmpeg = require('fluent-ffmpeg');
const path = require('path');
const fs = require('fs/promises');

const resolutions = [
  { name: '360p', size: '640x360' },
  { name: '720p', size: '1280x720' },
  { name: '1080p', size: '1920x1080' }
];

async function processVideo(inputPath, outputFolder) {
  await fs.mkdir(outputFolder, { recursive: true });
  const results = [];
  for (const res of resolutions) {
    const outputPath = path.join(outputFolder, `video_${res.name}.mp4`);
    await new Promise((resolve, reject) => {
      ffmpeg(inputPath)
        .videoFilters(`scale=${res.size}:force_original_aspect_ratio=decrease,pad=${res.size}:(ow-iw)/2:(oh-ih)/2`)
        .outputOptions(['-c:v libx264', '-preset veryfast', '-crf 23', '-c:a aac', '-movflags +faststart'])
        .output(outputPath)
        .on('end', resolve)
        .on('error', reject)
        .run();
    });
    results.push({ resolution: res.name, path: outputPath });
  }
  return results;
}

module.exports = { processVideo };
