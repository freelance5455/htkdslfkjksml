
import { GoogleGenAI, Type } from "@google/genai";
import { Question } from "../types";

/**
 * Repairs math and common symbol syntax.
 */
export const repairMathSyntax = (text: string): string => {
  if (!text) return "";
  let r = text.trim();
  const symbols: Record<string, string> = {
    '\\varepsilon_o': '\\varepsilon_0',
    '\\varepsilon_0': '\\varepsilon_0',
    '\\mu_o': '\\mu_0',
    '\\mu_0': '\\mu_0',
    '\\hbar': '\\hbar',
    '\\times': '\\times',
    '\\cdot': '\\cdot',
  };
  Object.entries(symbols).forEach(([k, v]) => {
    const escaped = k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    r = r.replace(new RegExp(escaped, 'gi'), v);
  });
  return r;
};

const cleanQuestionText = (text: string): string => {
  let cleaned = text.trim();
  // Remove leading numbering (e.g., "1. ", "Q1. ", "10)")
  return cleaned.replace(/^(?:Q(?:uestion)?\.?\s*)?\d+[\.:\)\s-]+\s*/i, "").trim();
};

const stripLabels = (text: string): string => {
  let clean = text.trim();
  // Matches (A), A., A), [A], A: at the start
  const labelRegex = /^\s*(?:\(\s*[A-D]\s*\)|[A-D][\.\)\s\-:\]])\s*/i;
  return clean.replace(labelRegex, '').trim();
};

/**
 * Specifically parses structured HTML question blocks.
 */
const parseFromHtml = (htmlContent: string): Question[] => {
  const parser = new DOMParser();
  const doc = parser.parseFromString(htmlContent, 'text/html');
  const questions: Question[] = [];
  
  const qaBlocks = doc.querySelectorAll('.qa');
  
  qaBlocks.forEach(block => {
    const qTextEl = block.querySelector('.qtext');
    const optEls = block.querySelectorAll('.opts li');
    const ansEl = block.querySelector('.ans');
    const expEl = block.querySelector('.exp');

    if (qTextEl && optEls.length >= 4) {
      const qText = cleanQuestionText(qTextEl.textContent || "");
      const options = Array.from(optEls).map(li => stripLabels(li.textContent || ""));
      
      const ansTextRaw = ansEl?.textContent || "";
      // CRITICAL FIX: Remove "Ans" text before matching to avoid catching the 'A' in 'Ans'
      const ansTextNoLabel = ansTextRaw.replace(/Ans|Answer|उत्तर/i, "");
      const ansMatch = ansTextNoLabel.match(/([A-D])/i);
      const correctAnswer = ansMatch ? "ABCD".indexOf(ansMatch[1].toUpperCase()) : 0;
      
      let explanation = expEl?.textContent || "";
      // BUG FIX: Removed \s from brain emoji regex to stop stripping all spaces!
      explanation = explanation.replace(/[\uD83E\uDDE0]/g, '').trim(); 
      // Strip redundant labels (do it twice to catch double labels if they exist)
      explanation = explanation.replace(/^(?:Explanation|Solution|विवरण|Explain)[:\s\-]*/i, '').trim();
      explanation = explanation.replace(/^(?:Explanation|Solution|विवरण|Explain)[:\s\-]*/i, '').trim();

      questions.push({
        id: crypto.randomUUID(),
        text: repairMathSyntax(qText),
        options: options.map(repairMathSyntax),
        correctAnswer: correctAnswer,
        explanation: repairMathSyntax(explanation)
      });
    }
  });

  return questions;
};

/**
 * Robust Parser that identifies MCQ blocks based on patterns.
 */
export const parseRawQuestions = async (rawText: string): Promise<Question[]> => {
  if (!rawText || rawText.trim().length < 5) return [];

  if (rawText.includes('<div') || rawText.includes('<!doctype') || rawText.includes('<ul')) {
    const htmlParsed = parseFromHtml(rawText);
    if (htmlParsed.length > 0) return htmlParsed;
  }

  const chunks = rawText.split(/(?:\n|^)\s*(?=\d+[\.\)\s\-]{1,2})/);
  const questions: Question[] = [];

  for (let block of chunks) {
    const trimmedBlock = block.trim();
    if (!trimmedBlock) continue;

    const aIdx = trimmedBlock.search(/(?:\n|^|\s)(?:\(\s*A\s*\)|A[\.\)\s\-:\]])/i);
    const bIdx = trimmedBlock.search(/(?:\n|^|\s)(?:\(\s*B\s*\)|B[\.\)\s\-:\]])/i);
    const cIdx = trimmedBlock.search(/(?:\n|^|\s)(?:\(\s*C\s*\)|C[\.\)\s\-:\]])/i);
    const dIdx = trimmedBlock.search(/(?:\n|^|\s)(?:\(\s*D\s*\)|D[\.\)\s\-:\]])/i);
    const ansIdx = trimmedBlock.search(/(?:\n|^|\s)(?:Ans|Answer|Correct Answer|उत्तर)[:\s\-\(\[]*/i);

    if (aIdx !== -1 && bIdx !== -1 && cIdx !== -1 && dIdx !== -1) {
      const qTextRaw = trimmedBlock.substring(0, aIdx);
      const qText = cleanQuestionText(qTextRaw) || "Question text missing";
      
      const optA = repairMathSyntax(stripLabels(trimmedBlock.substring(aIdx, bIdx)));
      const optB = repairMathSyntax(stripLabels(trimmedBlock.substring(bIdx, cIdx)));
      const optC = repairMathSyntax(stripLabels(trimmedBlock.substring(cIdx, dIdx)));
      
      let optD = "";
      let ansCharMatch = null;
      let explanation = "";

      if (ansIdx !== -1 && ansIdx > dIdx) {
        optD = repairMathSyntax(stripLabels(trimmedBlock.substring(dIdx, ansIdx)));
        const afterAns = trimmedBlock.substring(ansIdx).trim();
        
        const afterAnsNoLabel = afterAns.replace(/^(?:Ans|Answer|उत्तर)[:\s\-\(\[]*/i, "");
        ansCharMatch = afterAnsNoLabel.match(/([A-D])/i);
        
        const lines = afterAns.split('\n');
        if (lines.length > 1) {
          explanation = lines.slice(1).join('\n').trim();
          // BUG FIX: Removed \s from brain emoji regex to stop stripping all spaces!
          explanation = explanation.replace(/[\uD83E\uDDE0]/g, '').trim();
          explanation = explanation.replace(/^(?:Explanation|Solution|विवरण|Explain)[:\s\-]*/i, '').trim();
          explanation = explanation.replace(/^(?:Explanation|Solution|विवरण|Explain)[:\s\-]*/i, '').trim();
        }
      } else {
        optD = repairMathSyntax(stripLabels(trimmedBlock.substring(dIdx)));
      }
      
      questions.push({
        id: crypto.randomUUID(),
        text: repairMathSyntax(qText),
        options: [optA, optB, optC, optD],
        correctAnswer: ansCharMatch ? "ABCD".indexOf(ansCharMatch[1].toUpperCase()) : 0,
        explanation: repairMathSyntax(explanation)
      });
    }
  }

  return questions;
};

export const generateQuestions = async (topic: string, count: number = 5, difficulty: string = "medium"): Promise<Question[]> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: `Generate ${count} MCQ questions for "${topic}" at ${difficulty} level. Use LaTeX \( ... \) for all math.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              text: { type: Type.STRING },
              options: { type: Type.ARRAY, items: { type: Type.STRING } },
              correctAnswerIndex: { type: Type.INTEGER },
              explanation: { type: Type.STRING }
            },
            required: ["text", "options", "correctAnswerIndex", "explanation"]
          },
        },
      },
    });

    const data = JSON.parse(response.text || "[]");
    return data.map((q: any) => ({
      id: crypto.randomUUID(),
      text: repairMathSyntax(cleanQuestionText(q.text)),
      options: q.options.map((o: string) => repairMathSyntax(stripLabels(o))),
      correctAnswer: q.correctAnswerIndex,
      explanation: repairMathSyntax(q.explanation)
    }));
  } catch (error) {
    console.error("AI Generation Error:", error);
    return [];
  }
};
