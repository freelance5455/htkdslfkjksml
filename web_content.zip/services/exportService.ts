
import { 
  Document, 
  Packer, 
  Paragraph, 
  TextRun, 
  Math,
  MathRun,
  AlignmentType, 
  BorderStyle, 
  Table, 
  TableRow, 
  TableCell, 
  WidthType,
  ShadingType
} from "docx";
import * as FileSaver from "file-saver";
import { Section, DocumentMetadata, MarginPreset } from "../types";

// Word font sizes are in half-points (e.g., 26 = 13pt)
const MAIN_SIZE = 26; 
const EXPL_SIZE = 22; 
const FONT_FAMILY = "Nirmala UI";

/**
 * Escapes characters that break Word's internal XML structure.
 */
const escapeXml = (str: string): string => {
  if (!str) return "";
  return str
    .replace(/&/g, " and ") // '&' is the #1 cause of Word corruption errors
    .replace(/</g, " ( ")
    .replace(/>/g, " ) ")
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F-\u009F]/g, "");
};

/**
 * Converts LaTeX to Word-safe UnicodeMath.
 */
const convertToSafeWordMath = (latex: string): string => {
  if (!latex) return "";
  let m = latex.trim();

  // Structural cleaning
  m = m.replace(/\\begin\{[a-z]*\}/gi, '').replace(/\\end\{[a-z]*\}/gi, '');
  m = m.replace(/\\text\s*\{([^{}]*)\}/g, ' $1 ');
  m = m.replace(/\\mathrm\s*\{([^{}]*)\}/g, '$1');

  // High-fidelity mapping for symbols
  const syms: Record<string, string> = {
    '\\pm': '±', '\\mp': '∓', '\\times': '×', '\\div': '÷', '\\cdot': '·',
    '\\infty': '∞', '\\alpha': 'α', '\\beta': 'β', '\\gamma': 'γ', '\\delta': 'δ',
    '\\Delta': 'Δ', '\\pi': 'π', '\\theta': 'θ', '\\sigma': 'σ', '\\Omega': 'Ω',
    '\\omega': 'ω', '\\lambda': 'λ', '\\mu': 'μ', '\\epsilon': 'ε', '\\approx': '≈',
    '\\neq': '≠', '\\leq': '≤', '\\geq': '≥', '\\rightarrow': '→', '\\Rightarrow': '⇒',
    '\\sum': '∑', '\\int': '∫', '\\partial': '∂', '\\degree': '°', '\\varepsilon': 'ε',
    '\\phi': 'φ', '\\rho': 'ρ', '\\tau': 'τ', '\\eta': 'η', '\\zeta': 'ζ',
    '\\dots': '...', '\\cdots': '⋯', '\\sqrt': '√', '\\hbar': 'ℏ', '\\nabla': '∇',
    '\\varepsilon_o': 'ε₀', '\\varepsilon_0': 'ε₀', '\\epsilon_o': 'ε₀',
    '\\propto': '∝', '\\sim': '∼', '\\angle': '∠', '\\in': '∈', '\\notin': '∉'
  };

  Object.entries(syms).forEach(([tex, sym]) => {
    const escaped = tex.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    m = m.replace(new RegExp(escaped, 'g'), sym);
  });

  // Fraction Handling
  const fracProc = (s: string): string => {
    const reg = /\\frac\s*\{((?:[^{}]|\{[^{}]*\})*)\}\s*\{((?:[^{}]|\{[^{}]*\})*)\}/g;
    let n = s.replace(reg, '($1)/($2)');
    return n === s ? n : fracProc(n);
  };
  m = fracProc(m);

  // Scripts
  m = m.replace(/_\{([^}]+)\}/g, '_($1)');
  m = m.replace(/\^\{([^}]+)\}/g, '^($1)');
  m = m.replace(/_([a-zA-Z0-9])/g, '_($1)');
  m = m.replace(/\^([a-zA-Z0-9])/g, '^($1)');

  // Safeguard purge
  m = m.replace(/\\/g, ''); 
  m = m.replace(/\{/g, '(').replace(/\}/g, ')'); 
  m = m.replace(/-/g, '−'); 

  return escapeXml(m);
};

const renderStyledContent = (text: string, size: number, hexColor: string, isBold: boolean = false) => {
  if (!text) return [];
  const cleanColor = hexColor.replace('#', '').toUpperCase().substring(0, 6);
  const mathRegex = /(\$\$.*?\$\$|\$.*?\$|\\\(.*?\\\)|\\\[.*?\\\])/gs;
  const parts = text.split(mathRegex);
  const result: (TextRun | Math)[] = [];

  parts.forEach(part => {
    if (!part) return;
    const isMath = (part.startsWith('$') || part.startsWith('\\(') || part.startsWith('\\['));
    
    if (isMath) {
      const formula = part.replace(/^(\$\$?|\\\(|\\\[)|(\$\$?|\\\)|\\\])$/g, '').trim();
      const safeMath = convertToSafeWordMath(formula);
      if (safeMath) {
        result.push(new Math({
          children: [new MathRun(safeMath)]
        }));
      }
    } else {
      result.push(new TextRun({
        text: escapeXml(part),
        bold: isBold,
        size: size,
        font: FONT_FAMILY,
        color: cleanColor,
      }));
    }
  });
  return result;
};

const getMarginTwips = (preset: MarginPreset) => {
  switch (preset) {
    case 'Narrow': return 720; 
    case 'Moderate': return 1080; 
    case 'Wide': return 1440; 
    default: return 1440;
  }
};

export const exportToDocx = async (metadata: DocumentMetadata, sections: Section[]) => {
  const marginValue = getMarginTwips(metadata.pageSettings.margin);
  const children: any[] = [];

  // Main Title
  if (metadata.showTitle) {
    children.push(new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 100 },
      children: [new TextRun({ text: escapeXml(metadata.title), bold: true, size: 44, font: FONT_FAMILY })],
    }));
  }

  // Subtitle / Batch Identifier
  if (metadata.showSubtitle && metadata.subtitle) {
    children.push(new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 400 },
      children: [new TextRun({ text: escapeXml(metadata.subtitle), bold: true, size: 28, font: FONT_FAMILY, color: "666666" })],
    }));
  }

  let currentNum = 0;
  sections.forEach((section) => {
    if (section.startNumber !== undefined) currentNum = section.startNumber - 1;
    
    if (section.title) {
      children.push(new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { before: 400, after: 200 },
        children: [new TextRun({ text: escapeXml(section.title), bold: true, size: 28, font: FONT_FAMILY, underline: {} })],
      }));
    }

    section.questions.forEach((q) => {
      currentNum++;
      const qColor = "DC2626"; 
      
      children.push(new Paragraph({
        spacing: { before: 300, after: 150 },
        children: [
          new TextRun({ text: `${currentNum}. `, bold: true, size: MAIN_SIZE, color: qColor, font: FONT_FAMILY }),
          ...renderStyledContent(q.text, MAIN_SIZE, qColor)
        ],
      }));

      const labels = ["A", "B", "C", "D"];
      q.options.forEach((opt, idx) => {
        children.push(new Paragraph({
          spacing: { after: 100 },
          children: [
            new TextRun({ text: `(${labels[idx]}) `, size: MAIN_SIZE, font: FONT_FAMILY, color: "000000" }),
            ...renderStyledContent(opt, MAIN_SIZE, "000000")
          ],
        }));
      });

      children.push(new Paragraph({
        spacing: { before: 200, after: 200 },
        children: [
          new TextRun({ 
            text: `Ans:- (${labels[q.correctAnswer]})`, 
            bold: true, 
            color: "15803D", 
            size: MAIN_SIZE, 
            font: FONT_FAMILY,
            underline: { color: "15803D" }
          }),
        ],
      }));

      if (q.explanation) {
        const explLabelColor = "92400E"; 
        
        children.push(new Table({
          width: { size: 100, type: WidthType.PERCENTAGE },
          rows: [new TableRow({
            children: [new TableCell({
              shading: { fill: "F0FDF4", type: ShadingType.CLEAR }, 
              borders: {
                top: { style: BorderStyle.SINGLE, size: 2, color: "BBF7D0" },
                bottom: { style: BorderStyle.SINGLE, size: 2, color: "BBF7D0" },
                left: { style: BorderStyle.SINGLE, size: 2, color: "BBF7D0" },
                right: { style: BorderStyle.SINGLE, size: 2, color: "BBF7D0" },
              },
              margins: { top: 150, bottom: 150, left: 150, right: 150 },
              children: [new Paragraph({
                children: [
                  new TextRun({ text: "Explanation - ", bold: true, color: explLabelColor, font: FONT_FAMILY, size: EXPL_SIZE }),
                  ...renderStyledContent(q.explanation, EXPL_SIZE, "000000")
                ],
              })],
            })],
          })],
        }));
      }
    });
  });

  const doc = new Document({
    sections: [{
      properties: {
        page: {
          margin: { top: marginValue, bottom: marginValue, left: marginValue, right: marginValue },
          borders: metadata.pageSettings.showBorder ? {
            pageBorderTop: { style: BorderStyle.SINGLE, size: 4, color: "000000" },
            pageBorderBottom: { style: BorderStyle.SINGLE, size: 4, color: "000000" },
            pageBorderLeft: { style: BorderStyle.SINGLE, size: 4, color: "000000" },
            pageBorderRight: { style: BorderStyle.SINGLE, size: 4, color: "000000" },
          } : undefined,
        },
      },
      children: children,
    }],
  });

  try {
    const blob = await Packer.toBlob(doc);
    const saveAs = (FileSaver as any).saveAs || (FileSaver as any).default?.saveAs;
    const cleanFileName = (metadata.subtitle || metadata.title || "Exam")
      .replace(/[^a-z0-9]/gi, '_')
      .substring(0, 40);
    saveAs(blob, `${cleanFileName}.docx`);
  } catch (error) {
    console.error("Critical Export Error:", error);
    alert("EXPORT_FAULT: Data stream contains illegal characters.");
  }
};
