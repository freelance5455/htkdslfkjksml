# 🎲 Randomizer (HTML/CSS/JS)

نسخة ويب خالصة من التطبيق (بدون React Native)، جاهزة للتحويل إلى APK
عبر أي أداة "HTML to APK" / WebView wrapper.

## المحتوى
```
index.html   # كل الشاشات (شاشة البداية + الرئيسية + 10 أدوات)
css/style.css
js/app.js    # التنقل + GSAP + localStorage + منطق كل أداة
```

## طريقة الاستخدام مع أداة HTML to APK

1. افتح أداة التحويل (مثل: WebViewGold، Median، AppMySite، أو أي أداة Cordova/Capacitor مشابهة).
2. ارفع **مجلد `randomizer-web` كاملاً** (وليس ملف index.html وحده) — لازم تبقى بنية المجلدات css/ وjs/ كما هي بجانب index.html.
3. تأكد إن الأداة تضبط `index.html` كملف الدخول (entry point).
4. التطبيق يحتاج **اتصال إنترنت** عند التشغيل لأن مكتبة GSAP محمّلة من CDN (`cdnjs.cloudflare.com`). لو تبي التطبيق يشتغل بدون إنترنت كلياً:
   - نزّل ملف `gsap.min.js` من https://cdnjs.com/libraries/gsap يدوياً.
   - حطه داخل مجلد جديد مثلاً `js/lib/gsap.min.js`.
   - غيّر السطر في `index.html` من:
     `<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>`
     إلى:
     `<script src="js/lib/gsap.min.js"></script>`

## ملاحظة حول localStorage

البيانات المحفوظة (آخر نتيجة لكل أداة) محفوظة محلياً داخل WebView الخاص بالتطبيق،
ومعزولة عن أي متصفح آخر على الجهاز — وهذا هو السلوك المتوقع من localStorage.

## الأدوات العشر
تقسيم الفرق، رمي النرد، رمي العملة، أرقام عشوائية، عجلة الحظ، اختيار اسم،
خلط قائمة، نعم/لا، تاريخ/وقت عشوائي، حجر-ورقة-مقص.
