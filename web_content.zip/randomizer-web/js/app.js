// ===== app.js =====
// التطبيق كامل بـ HTML/CSS/JS خالص: يستخدم GSAP الحقيقية للحركات
// و localStorage الحقيقي للحفظ (كما طلب المستخدم أصلاً)، وجاهز
// ليُحزَّم مباشرة بأي أداة "HTML to APK" (يعمل داخل WebView).

/* ---------- 1) أدوات التخزين (بديل بسيط حول localStorage) ---------- */
const Storage = {
  save(key, value) {
    try {
      localStorage.setItem('randomizer:' + key, JSON.stringify(value));
      return true;
    } catch (e) {
      console.warn('تعذر الحفظ:', e);
      return false;
    }
  },
  load(key, defaultValue = null) {
    try {
      const raw = localStorage.getItem('randomizer:' + key);
      return raw != null ? JSON.parse(raw) : defaultValue;
    } catch (e) {
      console.warn('تعذر التحميل:', e);
      return defaultValue;
    }
  },
  appendHistory(key, entry, maxItems = 20) {
    const history = this.load(key, []);
    const updated = [entry, ...history].slice(0, maxItems);
    this.save(key, updated);
    return updated;
  },
};

/* ---------- 2) قائمة الأدوات العشر ---------- */
const TOOLS = [
  { id: 'teamSplit', title: 'تقسيم الفرق', icon: '👥' },
  { id: 'diceRoll', title: 'رمي النرد', icon: '🎲' },
  { id: 'coinFlip', title: 'رمي العملة', icon: '🪙' },
  { id: 'randomNumber', title: 'أرقام عشوائية', icon: '🔢' },
  { id: 'luckyWheel', title: 'عجلة الحظ', icon: '🎡' },
  { id: 'namePicker', title: 'اختيار اسم', icon: '🙋' },
  { id: 'shuffleList', title: 'خلط قائمة', icon: '🔀' },
  { id: 'yesNo', title: 'نعم أم لا', icon: '❓' },
  { id: 'randomDateTime', title: 'تاريخ/وقت عشوائي', icon: '📅' },
  { id: 'rps', title: 'حجر ورقة مقص', icon: '✂️' },
];

/* ---------- 3) التنقل بين الشاشات ---------- */
function showScreen(id) {
  document.querySelectorAll('.screen').forEach((el) => el.classList.add('hidden'));
  const target = document.getElementById(id);
  target.classList.remove('hidden');
  // حركة ظهور بسيطة بـ GSAP عند كل انتقال
  gsap.fromTo(target, { opacity: 0 }, { opacity: 1, duration: 0.25 });
}

function buildHomeGrid() {
  const grid = document.getElementById('toolsGrid');
  TOOLS.forEach((tool) => {
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = `<span class="icon">${tool.icon}</span><span class="title">${tool.title}</span>`;
    card.addEventListener('click', () => showScreen('tool-' + tool.id));
    grid.appendChild(card);
  });
}

document.querySelectorAll('[data-back]').forEach((btn) => {
  btn.addEventListener('click', () => showScreen('home'));
});

/* ---------- 4) أدوات مساعدة عامة ---------- */
function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
function parseList(text) {
  return text.split(/[,،\n]/).map((s) => s.trim()).filter(Boolean);
}

/* ---------- 5) تقسيم الفرق ---------- */
document.getElementById('ts-split').addEventListener('click', () => {
  const names = parseList(document.getElementById('ts-names').value);
  const count = Math.max(2, parseInt(document.getElementById('ts-count').value, 10) || 2);
  const resultEl = document.getElementById('ts-result');
  resultEl.innerHTML = '';
  if (names.length < count) return;

  const shuffled = shuffle(names);
  const teams = Array.from({ length: count }, () => []);
  shuffled.forEach((name, i) => teams[i % count].push(name));

  Storage.save('team_split_last', { names, count, teams });

  teams.forEach((team, idx) => {
    const card = document.createElement('div');
    card.className = 'team-card';
    card.innerHTML = `<div class="team-title">الفريق ${idx + 1}</div>` +
      team.map((n) => `<div class="member">• ${n}</div>`).join('');
    resultEl.appendChild(card);
    gsap.from(card, { opacity: 0, y: 15, duration: 0.4, delay: idx * 0.1 });
  });
});

/* ---------- 6) رمي النرد ---------- */
const DICE_FACES = ['⚀', '⚁', '⚂', '⚃', '⚄', '⚅'];
let diceRotation = 0;
document.getElementById('dice-roll').addEventListener('click', () => {
  const result = Math.floor(Math.random() * 6);
  const faceEl = document.getElementById('dice-face');
  diceRotation += 720;
  gsap.to(faceEl, {
    rotate: diceRotation,
    duration: 0.5,
    ease: 'power2.out',
    onComplete: () => {
      faceEl.textContent = DICE_FACES[result];
      document.getElementById('dice-result').textContent = `النتيجة: ${result + 1}`;
    },
  });
  Storage.appendHistory('dice_history', result + 1);
});

/* ---------- 7) رمي العملة ---------- */
document.getElementById('coin-flip').addEventListener('click', () => {
  const isHeads = Math.random() < 0.5;
  const coinEl = document.getElementById('coin');
  gsap.fromTo(
    coinEl,
    { rotateY: 0 },
    {
      rotateY: 1800,
      duration: 0.7,
      ease: 'power2.out',
      onComplete: () => {
        const label = isHeads ? 'صورة' : 'كتابة';
        document.getElementById('coin-result').textContent = `النتيجة: ${label}`;
        Storage.appendHistory('coin_history', label);
      },
    }
  );
});

/* ---------- 8) أرقام عشوائية ---------- */
document.getElementById('rn-generate').addEventListener('click', () => {
  const lo = parseInt(document.getElementById('rn-min').value, 10) || 0;
  const hi = parseInt(document.getElementById('rn-max').value, 10) || 0;
  if (hi < lo) return;
  const value = Math.floor(Math.random() * (hi - lo + 1)) + lo;
  const resultEl = document.getElementById('rn-result');
  resultEl.textContent = value;
  gsap.fromTo(resultEl, { scale: 0.5, opacity: 0 }, { scale: 1, opacity: 1, duration: 0.4, ease: 'back.out(2)' });
  Storage.appendHistory('random_number_history', value);
});

/* ---------- 9) عجلة الحظ ---------- */
const WHEEL_COLORS = ['#673ab7', '#9c6ade', '#b39ddb', '#7e57c2', '#5e35b1', '#8e63ce'];
let wheelRotation = 0;
let wheelSpinning = false;

function renderWheel() {
  const options = parseList(document.getElementById('lw-options').value);
  const wheelEl = document.getElementById('lw-wheel');
  wheelEl.innerHTML = '';
  const sliceAngle = 360 / options.length;
  options.forEach((opt, i) => {
    const slice = document.createElement('div');
    slice.className = 'wheel-slice';
    slice.style.transform = `rotate(${i * sliceAngle}deg) skewY(${90 - sliceAngle}deg)`;
    slice.style.background = WHEEL_COLORS[i % WHEEL_COLORS.length];
    slice.innerHTML = `<span style="transform: skewY(${-(90 - sliceAngle)}deg) rotate(${sliceAngle / 2}deg)">${opt}</span>`;
    wheelEl.appendChild(slice);
  });
  return options;
}
renderWheel();
document.getElementById('lw-options').addEventListener('input', renderWheel);

document.getElementById('lw-spin').addEventListener('click', () => {
  if (wheelSpinning) return;
  const options = renderWheel();
  if (options.length < 2) return;
  wheelSpinning = true;
  document.getElementById('lw-winner').textContent = '';

  const sliceAngle = 360 / options.length;
  const randomIndex = Math.floor(Math.random() * options.length);
  const extraSpins = 5 * 360;
  const targetRotation = wheelRotation + extraSpins + (360 - randomIndex * sliceAngle - sliceAngle / 2);

  gsap.to('#lw-wheel', {
    rotate: targetRotation,
    duration: 2.5,
    ease: 'power3.out',
    onComplete: () => {
      wheelRotation = targetRotation % 360;
      wheelSpinning = false;
      document.getElementById('lw-winner').textContent = `🎉 الفائز: ${options[randomIndex]}`;
      Storage.appendHistory('wheel_history', options[randomIndex]);
    },
  });
});

/* ---------- 10) اختيار اسم عشوائي ---------- */
document.getElementById('np-pick').addEventListener('click', () => {
  const names = parseList(document.getElementById('np-names').value);
  if (names.length === 0) return;
  const choice = names[Math.floor(Math.random() * names.length)];
  const resultEl = document.getElementById('np-result');
  resultEl.textContent = '🙋 ' + choice;
  gsap.fromTo(resultEl, { scale: 0.4, opacity: 0 }, { scale: 1, opacity: 1, duration: 0.45, ease: 'back.out(2.5)' });
  Storage.appendHistory('name_picker_history', choice);
});

/* ---------- 11) خلط قائمة ---------- */
document.getElementById('sl-shuffle').addEventListener('click', () => {
  const items = parseList(document.getElementById('sl-items').value);
  const resultEl = document.getElementById('sl-result');
  resultEl.innerHTML = '';
  if (items.length === 0) return;
  const result = shuffle(items);
  Storage.save('shuffle_list_last', result);

  result.forEach((item, idx) => {
    const row = document.createElement('div');
    row.className = 'item-row';
    row.innerHTML = `<span class="item-index">${idx + 1}</span><span>${item}</span>`;
    resultEl.appendChild(row);
    gsap.from(row, { opacity: 0, y: 10, duration: 0.3, delay: idx * 0.06 });
  });
});

/* ---------- 12) نعم أم لا ---------- */
document.getElementById('yn-decide').addEventListener('click', () => {
  const result = Math.random() < 0.5 ? 'نعم ✅' : 'لا ❌';
  const resultEl = document.getElementById('yn-result');
  gsap.timeline()
    .to(resultEl, { scale: 0.7, duration: 0.12 })
    .to(resultEl, { scale: 1, duration: 0.2 });
  resultEl.textContent = result;
  Storage.appendHistory('yesno_history', result);
});

/* ---------- 13) تاريخ/وقت عشوائي ---------- */
document.getElementById('dt-generate').addEventListener('click', () => {
  const now = new Date();
  const offsetDays = Math.floor(Math.random() * 365);
  const offsetMinutes = Math.floor(Math.random() * 24 * 60);
  const randomDate = new Date(now.getTime() + offsetDays * 86400000 + offsetMinutes * 60000);

  const dateEl = document.getElementById('dt-date');
  const timeEl = document.getElementById('dt-time');
  dateEl.textContent = '📅 ' + randomDate.toLocaleDateString('ar-EG', { year: 'numeric', month: 'long', day: 'numeric' });
  timeEl.textContent = '🕒 ' + randomDate.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
  gsap.from([dateEl, timeEl], { opacity: 0, y: 10, duration: 0.4, stagger: 0.1 });

  Storage.appendHistory('random_datetime_history', randomDate.toISOString());
});

/* ---------- 14) حجر ورقة مقص ---------- */
const RPS_ICONS = { rock: '🪨', paper: '📄', scissors: '✂️' };
const RPS_BEATS = { rock: 'scissors', paper: 'rock', scissors: 'paper' };

function decideRPS(player, device) {
  if (player === device) return 'تعادل';
  return RPS_BEATS[player] === device ? 'فزت!' : 'خسرت!';
}

document.querySelectorAll('.choice-btn').forEach((btn) => {
  btn.addEventListener('click', () => {
    const player = btn.dataset.choice;
    const keys = Object.keys(RPS_ICONS);
    const device = keys[Math.floor(Math.random() * keys.length)];
    const outcome = decideRPS(player, device);

    const playerEl = document.getElementById('rps-player');
    const deviceEl = document.getElementById('rps-device');
    const outcomeEl = document.getElementById('rps-outcome');

    playerEl.textContent = RPS_ICONS[player];
    deviceEl.textContent = RPS_ICONS[device];
    outcomeEl.textContent = outcome;

    gsap.from([playerEl, deviceEl], { scale: 0.3, opacity: 0, duration: 0.3, stagger: 0.08 });
    gsap.from(outcomeEl, { scale: 0.5, opacity: 0, duration: 0.3, delay: 0.25, ease: 'back.out(2)' });

    Storage.appendHistory('rps_history', { player, device, outcome });
  });
});

/* ---------- 15) بدء التطبيق ---------- */
buildHomeGrid();
setTimeout(() => {
  showScreen('home');
}, 1800);
