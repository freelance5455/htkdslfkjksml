/* Calendrier Fenua — données scolaires : Vice-rectorat de Polynésie française.
   Source pérenne : https://www.ac-polynesie.pf/calendriers-scolaires
   PDFs consultés : 2026-2027 (23946), 2027-2028 (23947), 2028-2029 (23949).
   Les plages de vacances ci-dessous désignent les journées sans classe de la semaine.
   Les week-ends précédant la reprise ne sont pas systématiquement marqués vacances.
*/
(function(root){
  'use strict';
  const SCHOOL_SOURCE='https://www.ac-polynesie.pf/calendriers-scolaires';
  const schoolYears={
    '2026-2027': {
      pdf:'https://www.ac-polynesie.pf/media/23946/download',teacher:'2026-08-10', start:'2026-08-11',primaryEnd:'2027-07-02',secondaryEnd:'2027-07-03',
      vacations:[
        {name:'Vacances de septembre',from:'2026-09-14',to:'2026-09-20',resume:'2026-09-21'},
        {name:'Vacances de la Toussaint',from:'2026-10-26',to:'2026-11-08',resume:'2026-11-09'},
        {name:'Vacances de Noël',from:'2026-12-14',to:'2027-01-10',resume:'2027-01-11'},
        {name:'Vacances de février',from:'2027-02-15',to:'2027-02-21',resume:'2027-02-22'},
        {name:'Vacances de Pâques',from:'2027-03-29',to:'2027-04-11',resume:'2027-04-12'},
        {name:'Vacances de mai',from:'2027-05-17',to:'2027-05-23',resume:'2027-05-24'}
      ]
    },
    '2027-2028': {
      pdf:'https://www.ac-polynesie.pf/media/23947/download',teacher:'2027-08-23', start:'2027-08-24',primaryEnd:'2028-07-07',secondaryEnd:'2028-07-08',
      vacations:[
        {name:'Vacances de septembre',from:'2027-09-27',to:'2027-10-03',resume:'2027-10-04'},
        {name:'Vacances de novembre',from:'2027-11-08',to:'2027-11-14',resume:'2027-11-15'},
        {name:'Vacances de Noël',from:'2027-12-20',to:'2028-01-09',resume:'2028-01-10'},
        {name:'Vacances de février',from:'2028-02-21',to:'2028-03-05',resume:'2028-03-06'},
        {name:'Vacances d’avril',from:'2028-04-10',to:'2028-04-16',resume:'2028-04-17'},
        {name:'Vacances de mai',from:'2028-05-22',to:'2028-05-28',resume:'2028-05-29'}
      ]
    },
    '2028-2029': {
      pdf:'https://www.ac-polynesie.pf/media/23949/download',teacher:'2028-08-21',start:'2028-08-22',primaryEnd:'2029-07-06',secondaryEnd:'2029-07-07',
      vacations:[
        {name:'Vacances de septembre',from:'2028-09-25',to:'2028-10-01',resume:'2028-10-02'},
        {name:'Vacances de novembre',from:'2028-11-06',to:'2028-11-12',resume:'2028-11-13'},
        {name:'Vacances de Noël',from:'2028-12-18',to:'2029-01-14',resume:'2029-01-15'},
        {name:'Vacances de février',from:'2029-02-19',to:'2029-03-04',resume:'2029-03-05'},
        {name:'Vacances d’avril',from:'2029-04-09',to:'2029-04-15',resume:'2029-04-16'},
        {name:'Vacances de mai',from:'2029-05-21',to:'2029-05-27',resume:'2029-05-28'}
      ]
    }
  };
  const ZONES={
    'Pacific/Tahiti':{label:'Tahiti · Société · Tuamotu · Australes',offset:-600},
    'Pacific/Marquesas':{label:'Marquises',offset:-570},
    'Pacific/Gambier':{label:'Gambier',offset:-540}
  };
  const monthNames=['janvier','février','mars','avril','mai','juin','juillet','août','septembre','octobre','novembre','décembre'];
  const weekdays=['Lun','Mar','Mer','Jeu','Ven','Sam','Dim'];
  function fromISO(s){return new Date(s+'T12:00:00Z')}
  function iso(date){return date.getUTCFullYear()+'-'+String(date.getUTCMonth()+1).padStart(2,'0')+'-'+String(date.getUTCDate()).padStart(2,'0')}
  function shift(s,days){const d=fromISO(s);d.setUTCDate(d.getUTCDate()+days);return iso(d)}
  function dow(s){return (fromISO(s).getUTCDay()+6)%7}
  function monthStart(year,month){return year+'-'+String(month+1).padStart(2,'0')+'-01'}
  function monthLength(year,month){return new Date(Date.UTC(year,month+1,0)).getUTCDate()}
  function human(s,opt){return new Intl.DateTimeFormat('fr-FR',Object.assign({day:'numeric',month:'long',year:'numeric',timeZone:'UTC'},opt||{})).format(fromISO(s))}
  function currentDate(zone){const parts=new Intl.DateTimeFormat('en-US',{timeZone:ZONES[zone]?zone:'Pacific/Tahiti',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date());const val=n=>parts.find(p=>p.type===n).value;return val('year')+'-'+val('month')+'-'+val('day')}
  function easter(year){ // Computus grégorien (Meeus/Jones/Butcher)
    const a=year%19,b=Math.floor(year/100),c=year%100,d=Math.floor(b/4),e=b%4,f=Math.floor((b+8)/25),g=Math.floor((b-f+1)/3),h=(19*a+b-d-g+15)%30,i=Math.floor(c/4),k=c%4,l=(32+2*e+2*i-h-k+7*1000)%7,m=Math.floor((a+11*h+22*l)/451),t=h+l-7*m+114;
    return year+'-'+String(Math.floor(t/31)).padStart(2,'0')+'-'+String(t%31+1).padStart(2,'0');
  }
  function holidays(year){
    const e=easter(year);
    const o={};
    function add(md,name){o[year+'-'+md]=name}
    add('01-01','Jour de l’An');add('03-05','Arrivée de l’Évangile');add('05-01','Fête du Travail');add('05-08','Victoire de 1945');
    add('07-14','Fête nationale');add('08-15','Assomption');add('11-01','Toussaint');add('11-11','Armistice de 1918');
    if(year>=2026)add('11-20','Matari’i – fête de l’Abondance');
    add('12-25','Noël');
    o[shift(e,-2)]='Vendredi saint';o[shift(e,1)]='Lundi de Pâques';o[shift(e,39)]='Ascension';o[shift(e,50)]='Lundi de Pentecôte';
    return o;
  }
  function holiday(s){return holidays(Number(s.slice(0,4)))[s]||null}
  function cultural(s){const y=Number(s.slice(0,4));if(s.slice(5)==='06-29'&&y>=2026)return 'Fête de l’Autonomie (commémoration, non fériée)';const e=easter(y);if(s===e)return 'Pâques (dimanche)';if(s===shift(e,49))return 'Pentecôte (dimanche)';return null}
  function schoolKey(s){const yr=Number(s.slice(0,4)),mo=Number(s.slice(5,7));return mo>=8?`${yr}-${yr+1}`:`${yr-1}-${yr}`}
  function schoolInfo(s,level){
    const yr=schoolYears[schoolKey(s)];if(!yr)return null;
    if(s===yr.teacher)return {kind:'teacher',name:'Pré-rentrée des enseignants'};
    if(s===yr.start)return {kind:'start',name:'Rentrée des élèves'};
    const end=level==='secondary'?yr.secondaryEnd:yr.primaryEnd;
    if(s===end)return {kind:'end',name:'Dernier jour de classe'+(level==='both'?' (voir niveau)':'')};
    const vac=yr.vacations.find(v=>s>=v.from&&s<=v.to);
    if(vac)return {kind:'vacation',name:vac.name,range:vac};
    if(s<yr.start||s>end)return {kind:'vacation',name:'Grandes vacances'};
    return null;
  }
  // Pour "Les deux" on distingue la fin des cours (2 et 3 juillet, etc.).
  function schoolEvents(s,level){
    if(level==='both'){
      const primary=schoolInfo(s,'primary'),secondary=schoolInfo(s,'secondary');
      if(primary?.kind==='end')return [{kind:'end',name:'Fin des cours · écoles et CJA'}];
      if(secondary?.kind==='end')return [{kind:'end',name:'Fin des cours · collèges et lycées'}];
      if(primary?.kind==='vacation'&&secondary?.kind!=='vacation')return [{kind:'vacation',name:'Vacances · écoles et CJA'}];
      return primary?[primary]:[];
    }
    const out=schoolInfo(s,level);return out?[out]:[];
  }
  function toEpoch(date,time,zone){const [y,m,d]=date.split('-').map(Number);const [h,min]=time.split(':').map(Number);const offset=(ZONES[zone]||ZONES['Pacific/Tahiti']).offset;return Date.UTC(y,m-1,d,h,min)-offset*60000}
  function cleanDate(d){return /^\d{4}-\d{2}-\d{2}$/.test(d)&&iso(fromISO(d))===d}
  const api={SCHOOL_SOURCE,schoolYears,ZONES,monthNames,weekdays,fromISO,iso,shift,dow,monthStart,monthLength,human,currentDate,easter,holidays,holiday,cultural,schoolKey,schoolInfo,schoolEvents,toEpoch,cleanDate};
  root.CalData=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
