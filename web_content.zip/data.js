// ================================================
// METALLIC FEAST — data.js
// Bestias, ingredientes, recetas, clientes
// ================================================

const BEASTS = [
  {
    id: 'scorpion_chrome',
    name: 'Escorpión de Cromo',
    emoji: '🦂',
    color: '#aaaaaa',
    hp: 65, maxHp: 65,
    attack: [8, 14], defense: 3,
    xp: 25, credits: 40,
    tier: 'common',
    drops: [
      { id: 'chrome_claw', chance: 0.9, qty: [1, 2] },
      { id: 'blue_venom',  chance: 0.5, qty: [1, 1] }
    ],
    lore: 'Criatura ágil con exoesqueleto de cromo pulido reforzado que patrulla los callejones de Nexus-7.'
  },
  {
    id: 'silicon_spider',
    name: 'Araña de Silicona',
    emoji: '🕷️',
    color: '#aa00ff',
    hp: 55, maxHp: 55,
    attack: [7, 12], defense: 2,
    xp: 22, credits: 35,
    tier: 'common',
    drops: [
      { id: 'fiber_wire', chance: 0.95, qty: [2, 4] },
      { id: 'glass_eye',  chance: 0.4, qty: [1, 1] }
    ],
    lore: 'Pequeña pero venenosa. Teje redes de fibra óptica densas para atrapar presas con descargas.'
  },
  {
    id: 'neon_serpent',
    name: 'Serpiente de Neón',
    emoji: '🐍',
    color: '#00ff88',
    hp: 95, maxHp: 95,
    attack: [12, 20], defense: 5,
    xp: 45, credits: 60,
    tier: 'common',
    drops: [
      { id: 'neon_fluid',      chance: 0.85, qty: [1, 2] },
      { id: 'scale_membrane',  chance: 0.7, qty: [1, 2] }
    ],
    lore: 'Serpiente bioluminiscente con piel refractaria que absorbe impactos antes de morder.'
  },
  // ── 15 NUEVOS MOBS ──
  {
    id: 'plasma_wasp',
    name: 'Avispa de Plasma',
    emoji: '🐝',
    color: '#ffcc00',
    hp: 75, maxHp: 75,
    attack: [14, 22], defense: 4,
    xp: 40, credits: 50,
    tier: 'common',
    drops: [
      { id: 'blue_venom', chance: 0.8, qty: [1, 2] },
      { id: 'plasma_core', chance: 0.35, qty: [1, 1] }
    ],
    lore: 'Insecto zumbador con aguijón sobrecargado térmicamente. Muy molesta en enjambres.'
  },
  {
    id: 'cyber_rat',
    name: 'Rata Cibernética de Alcantarilla',
    emoji: '🐀',
    color: '#8b8b8b',
    hp: 70, maxHp: 70,
    attack: [10, 18], defense: 3,
    xp: 30, credits: 45,
    tier: 'common',
    drops: [
      { id: 'fiber_wire', chance: 0.85, qty: [2, 3] },
      { id: 'heavy_scrap', chance: 0.5, qty: [1, 2] }
    ],
    lore: 'Alimentada con cables de datos y baterías de litio. Muerde con dientes de aleación.'
  },
  {
    id: 'slag_beetle',
    name: 'Escarabajo de Escoria',
    emoji: '🪲',
    color: '#d2691e',
    hp: 110, maxHp: 110,
    attack: [13, 22], defense: 8,
    xp: 50, credits: 70,
    tier: 'common',
    drops: [
      { id: 'heavy_scrap', chance: 0.9, qty: [2, 4] },
      { id: 'scale_membrane', chance: 0.6, qty: [1, 2] }
    ],
    lore: 'Acorazado con una coraza de residuos de fundición. Rebota cuchillos comunes.'
  },
  {
    id: 'volt_centipede',
    name: 'Ciempiés Voltáico',
    emoji: '🐛',
    color: '#00ffee',
    hp: 125, maxHp: 125,
    attack: [16, 25], defense: 7,
    xp: 55, credits: 75,
    tier: 'common',
    drops: [
      { id: 'volt_fang', chance: 0.75, qty: [1, 2] },
      { id: 'fiber_wire', chance: 0.85, qty: [2, 4] }
    ],
    lore: 'Trepa por los postes de luz recargando cada una de sus patas electrificadas.'
  },
  {
    id: 'rust_hound',
    name: 'Sabueso de Óxido',
    emoji: '🐕',
    color: '#b85d19',
    hp: 135, maxHp: 135,
    attack: [18, 28], defense: 8,
    xp: 65, credits: 85,
    tier: 'uncommon',
    drops: [
      { id: 'chrome_claw', chance: 0.8, qty: [2, 3] },
      { id: 'heavy_scrap', chance: 0.7, qty: [2, 3] }
    ],
    lore: 'Canino feral con mandíbulas de engranajes que tritura carne y metal sin distinción.'
  },
  {
    id: 'holo_chameleon',
    name: 'Camaleón Holográfico',
    emoji: '🦎',
    color: '#00ffaa',
    hp: 115, maxHp: 115,
    attack: [17, 27], defense: 6,
    xp: 60, credits: 90,
    tier: 'uncommon',
    drops: [
      { id: 'glass_eye', chance: 0.85, qty: [1, 2] },
      { id: 'neon_fluid', chance: 0.8, qty: [1, 2] }
    ],
    lore: 'Usa camuflaje de proyección óptica. Sorprende a sus presas con un latigazo sintético.'
  },
  {
    id: 'magma_slug',
    name: 'Babosa de Soldadura',
    emoji: '🐌',
    color: '#ff4500',
    hp: 145, maxHp: 145,
    attack: [19, 30], defense: 9,
    xp: 70, credits: 95,
    tier: 'uncommon',
    drops: [
      { id: 'neon_fluid', chance: 0.9, qty: [2, 3] },
      { id: 'red_core', chance: 0.45, qty: [1, 1] }
    ],
    lore: 'Secreta metal líquido incandescente a más de 1200 grados centígrados.'
  },
  {
    id: 'stealth_panther',
    name: 'Pantera de Grafeno',
    emoji: '🐆',
    color: '#2b2b36',
    hp: 160, maxHp: 160,
    attack: [24, 38], defense: 11,
    xp: 85, credits: 110,
    tier: 'uncommon',
    drops: [
      { id: 'titanium_scale', chance: 0.85, qty: [2, 3] },
      { id: 'chrome_claw', chance: 0.75, qty: [2, 3] }
    ],
    lore: 'Felino furtivo recubierto de nanotubos de carbono. Acecha desde los rascacielos derruidos.'
  },
  {
    id: 'laser_mantis',
    name: 'Mantis Fotónica',
    emoji: '🦗',
    color: '#ff0055',
    hp: 150, maxHp: 150,
    attack: [27, 40], defense: 10,
    xp: 90, credits: 120,
    tier: 'uncommon',
    drops: [
      { id: 'glass_eye', chance: 0.9, qty: [2, 2] },
      { id: 'volt_fang', chance: 0.8, qty: [1, 2] }
    ],
    lore: 'Corta el aire con extremidades dotadas de diodos láser coherentes de corte médico.'
  },
  {
    id: 'laser_shark',
    name: 'Tiburón de Alcantarilla Láser',
    emoji: '🦈',
    color: '#1e90ff',
    hp: 190, maxHp: 190,
    attack: [30, 46], defense: 14,
    xp: 120, credits: 150,
    tier: 'elite',
    drops: [
      { id: 'titanium_jaw', chance: 0.7, qty: [1, 1] },
      { id: 'scale_membrane', chance: 0.9, qty: [2, 4] }
    ],
    lore: 'Navega en los túneles inundados de desechos químicos. Posee sensores sonar militares.'
  },
  {
    id: 'reactor_turtle',
    name: 'Tortuga Reactor Subcrítico',
    emoji: '🐢',
    color: '#32cd32',
    hp: 260, maxHp: 260,
    attack: [22, 36], defense: 26,
    xp: 140, credits: 180,
    tier: 'elite',
    drops: [
      { id: 'quantum_condenser', chance: 0.65, qty: [1, 1] },
      { id: 'heavy_scrap', chance: 0.95, qty: [4, 6] }
    ],
    lore: 'Su caparazón alberga una celda nuclear fisible sellada. Casi impenetrable.'
  },
  {
    id: 'spectral_bat',
    name: 'Murciélago Espectral EMP',
    emoji: '🦇',
    color: '#9400d3',
    hp: 165, maxHp: 165,
    attack: [28, 44], defense: 12,
    xp: 110, credits: 140,
    tier: 'elite',
    drops: [
      { id: 'quantum_condenser', chance: 0.6, qty: [1, 1] },
      { id: 'plasma_core', chance: 0.75, qty: [1, 2] }
    ],
    lore: 'Emite pulsos electromagnéticos chirriantes que frien los visores de los chefs novatos.'
  },
  {
    id: 'plasma_ape',
    name: 'Gorila de Plasma y Cables',
    emoji: '🦍',
    color: '#ff1493',
    hp: 280, maxHp: 280,
    attack: [36, 56], defense: 20,
    xp: 190, credits: 230,
    tier: 'elite',
    drops: [
      { id: 'titanium_scale', chance: 0.9, qty: [3, 4] },
      { id: 'red_core', chance: 0.75, qty: [1, 2] }
    ],
    lore: 'Bestia bruta colosal que aplasta vehículos blindados como si fuesen latas de gaseosa.'
  },
  {
    id: 'chrono_owl',
    name: 'Búho Crono-Sincrónico',
    emoji: '🦉',
    color: '#ffd700',
    hp: 210, maxHp: 210,
    attack: [34, 50], defense: 17,
    xp: 170, credits: 210,
    tier: 'elite',
    drops: [
      { id: 'quantum_condenser', chance: 0.8, qty: [1, 2] },
      { id: 'glass_eye', chance: 0.95, qty: [2, 3] }
    ],
    lore: 'Acelera y desacelera micro-fracciones de segundo para esquivar ataques antes de que sucedan.'
  },
  {
    id: 'cyber_bear_apex',
    name: 'Oso Grizzly Cyber-Ápex',
    emoji: '🐻‍❄️',
    color: '#e0ffff',
    hp: 310, maxHp: 310,
    attack: [42, 64], defense: 25,
    xp: 260, credits: 320,
    tier: 'elite',
    drops: [
      { id: 'titanium_jaw', chance: 0.85, qty: [1, 2] },
      { id: 'antimatter_shard', chance: 0.55, qty: [1, 1] }
    ],
    lore: 'Un coloso del yermo polar modificado para la guerra ártica. Imparable una vez que carga.'
  },
  // ── BESTIAS MAYORES Y BOSSES EXISTENTES (CON MAS STATS Y TIER BOSS) ──
  {
    id: 'circuit_dragon',
    name: 'Dragón de Circuito',
    emoji: '🐲',
    color: '#00ccff',
    hp: 150, maxHp: 150,
    attack: [20, 32], defense: 12,
    xp: 90, credits: 120,
    tier: 'uncommon',
    drops: [
      { id: 'plasma_core',    chance: 0.85, qty: [1, 1] },
      { id: 'titanium_scale', chance: 0.7,  qty: [1, 3] }
    ],
    lore: 'Bestia masiva con circuitos expuestos en su piel que recorre las autopistas elevadas.'
  },
  {
    id: 'junk_golem',
    name: 'Gólem de Chatarra',
    emoji: '🤖',
    color: '#ff8800',
    hp: 200, maxHp: 200,
    attack: [25, 40], defense: 18,
    xp: 140, credits: 160,
    tier: 'elite',
    drops: [
      { id: 'heavy_scrap',    chance: 0.95, qty: [3, 6] },
      { id: 'red_core',       chance: 0.65, qty: [1, 2] },
      { id: 'chrome_claw',    chance: 0.4,  qty: [1, 2] }
    ],
    lore: 'Construido con desperdicios de la era pre-colapso. Lento, pero devastador.'
  },
  {
    id: 'hyper_hydra',
    name: 'Hidra de Hiper-Voltaje',
    emoji: '🪱',
    color: '#00e5ff',
    hp: 260, maxHp: 260,
    attack: [32, 50], defense: 22,
    xp: 220, credits: 260,
    tier: 'boss',
    drops: [
      { id: 'volt_fang',      chance: 0.9,  qty: [2, 3] },
      { id: 'neon_fluid',     chance: 0.7,  qty: [1, 2] },
      { id: 'quantum_condenser', chance: 0.65, qty: [1, 2] }
    ],
    lore: 'Serpiente multianular electrificada. Descarga arcos voltaicos capaces de fundir tanques.'
  },
  {
    id: 'cyber_trex',
    name: 'Meca-Tiranosaurio Rex',
    emoji: '🦖',
    color: '#ff003c',
    hp: 350, maxHp: 350,
    attack: [45, 68], defense: 28,
    xp: 320, credits: 400,
    tier: 'boss',
    drops: [
      { id: 'titanium_jaw',   chance: 0.9, qty: [1, 2] },
      { id: 'plasma_core',    chance: 0.85, qty: [1, 2] },
      { id: 'red_core',       chance: 0.75, qty: [1, 2] }
    ],
    lore: 'Antigua arma militar biomecánica descontrolada. Sus mandíbulas pulverizan el titanio templado.'
  },
  {
    id: 'void_titan',
    name: 'Titán del Abismo Cuántico',
    emoji: '👹',
    color: '#7b00ff',
    hp: 460, maxHp: 460,
    attack: [58, 85], defense: 35,
    xp: 480, credits: 580,
    tier: 'boss',
    drops: [
      { id: 'antimatter_shard', chance: 0.85, qty: [1, 2] },
      { id: 'quantum_condenser', chance: 0.85, qty: [1, 2] },
      { id: 'heavy_scrap',     chance: 0.95, qty: [4, 6] }
    ],
    lore: 'Entidad cibernética alimentada por anomalías gravitacionales. Distorsiona el espacio a su paso.'
  },
  {
    id: 'dreadnought_prime',
    name: 'Dreadnought Quimérico Ω',
    emoji: '🛸',
    color: '#ffe600',
    hp: 600, maxHp: 600,
    attack: [75, 115], defense: 44,
    xp: 750, credits: 950,
    tier: 'boss',
    drops: [
      { id: 'antimatter_shard', chance: 0.98, qty: [2, 4] },
      { id: 'titanium_jaw',     chance: 0.9, qty: [2, 3] },
      { id: 'omega_cell',       chance: 0.8, qty: [1, 2] }
    ],
    lore: 'La máquina de asedio definitiva del Sector Negro. Ningún cazador ha sobrevivido para describirla en detalle.'
  }
];

const LEVEL_MILESTONES = {
  5: {
    title: '⭐ MAESTRÍA DE COMBATE (NV. 5)',
    credits: 300,
    heals: 2,
    rewardType: 'ability',
    abilityId: 'overcharge',
    abilityName: '⚡ Sobrecarga de Filo',
    description: 'Recibes 300₿, 2 Curaciones Completas y desbloqueas la habilidad pasiva: ¡Los ataques causan +15% de daño crítico!'
  },
  10: {
    title: '🔥 CIRUJANO DEL APOCALIPSIS (NV. 10)',
    credits: 750,
    heals: 3,
    rewardType: 'weapon',
    weaponId: 'laser_cleaver',
    weaponName: '🪓 Hacha Carnicera Láser',
    description: 'Recibes 750₿, 3 Curaciones Completas y te otorgan el arma legendaria "🪓 Hacha Carnicera Láser" directamente a tu mochila.'
  },
  15: {
    title: '🛡️ BASTIÓN METÁLICO (NV. 15)',
    credits: 1500,
    heals: 5,
    rewardType: 'ability',
    abilityId: 'nanoshield',
    abilityName: '🛡️ Escudo de Nanocélulas',
    description: 'Recibes 1,500₿, 5 Curaciones Completas y la habilidad pasiva: Reduce un 25% de todo el daño enemigo recibido permanentemente.'
  },
  20: {
    title: '👑 CHEF SUPREMO DE NEXUS-7 (NV. 20)',
    credits: 3000,
    heals: 10,
    rewardType: 'weapon',
    weaponId: 'antimatter_edge',
    weaponName: '💫 Filo Antimateria',
    description: '¡Rango Máximo! Recibes 3,000₿, 10 Curaciones Completas y el arma definitiva "💫 Filo Antimateria" (+75 de Daño).'
  }
};

const INGREDIENTS = {
  chrome_claw:        { name: 'Pinza de Cromo',         emoji: '🦾', type: 'protein'   },
  blue_venom:         { name: 'Veneno Azul',             emoji: '💉', type: 'seasoning' },
  fiber_wire:         { name: 'Hilo de Fibra',           emoji: '🧵', type: 'garnish'   },
  glass_eye:          { name: 'Ojo de Vidrio',           emoji: '👁️', type: 'special'   },
  neon_fluid:         { name: 'Fluido Neón',             emoji: '🌊', type: 'seasoning' },
  scale_membrane:     { name: 'Membrana de Escama',      emoji: '🐟', type: 'garnish'   },
  plasma_core:        { name: 'Núcleo de Plasma',        emoji: '⚡', type: 'special'   },
  titanium_scale:     { name: 'Escama de Titanio',       emoji: '🔩', type: 'protein'   },
  heavy_scrap:        { name: 'Chatarra Pesada',          emoji: '⚙️', type: 'protein'   },
  red_core:           { name: 'Núcleo Rojo',             emoji: '🔴', type: 'special'   },
  volt_fang:          { name: 'Colmillo Voltáico',        emoji: '⚡', type: 'protein'   },
  quantum_condenser:  { name: 'Condensador Cuántico',    emoji: '🌀', type: 'seasoning' },
  titanium_jaw:       { name: 'Mandíbula de Titanio',    emoji: '🦷', type: 'protein'   },
  antimatter_shard:   { name: 'Fragmento Antimateria',   emoji: '💠', type: 'special'   },
  omega_cell:         { name: 'Célula Omega',            emoji: '🔮', type: 'special'   }
};

const RECIPES = [
  {
    id: 'chrome_skewer',
    name: 'Brocheta de Cromo',
    emoji: '🍢',
    ingredients: ['chrome_claw', 'chrome_claw'],
    basePrice: 150,
    description: 'Crujiente por fuera, con textura metálica por dentro.'
  },
  {
    id: 'plasma_soup',
    name: 'Sopa de Plasma',
    emoji: '🍲',
    ingredients: ['plasma_core', 'blue_venom'],
    basePrice: 320,
    description: 'Un caldo ardiente que deja rastros de luz en la garganta.'
  },
  {
    id: 'titanium_wings',
    name: 'Alitas de Titanio',
    emoji: '🍗',
    ingredients: ['titanium_scale', 'titanium_scale', 'neon_fluid'],
    basePrice: 280,
    description: 'Glaseadas con fluido neón. Irresistibles para cualquier bestia.'
  },
  {
    id: 'scrap_stew',
    name: 'Estofado de Chatarra',
    emoji: '🫕',
    ingredients: ['heavy_scrap', 'heavy_scrap', 'fiber_wire'],
    basePrice: 200,
    description: 'Contundente y nutritivo. El plato del obrero de la zona roja.'
  },
  {
    id: 'glass_eye_sashimi',
    name: 'Sashimi de Ojo',
    emoji: '🍣',
    ingredients: ['glass_eye', 'scale_membrane', 'neon_fluid'],
    basePrice: 450,
    description: 'Alta cocina cyberpunk. Solo para paladares muy refinados.'
  },
  {
    id: 'red_core_burger',
    name: 'Burger de Núcleo Rojo',
    emoji: '🍔',
    ingredients: ['red_core', 'chrome_claw', 'fiber_wire'],
    basePrice: 380,
    description: 'La más pedida del sector 7. El núcleo le da un sabor explosivo.'
  },
  {
    id: 'volt_ribs',
    name: 'Costillar Electro-Voltáico',
    emoji: '🥩',
    ingredients: ['volt_fang', 'quantum_condenser', 'neon_fluid'],
    basePrice: 650,
    description: 'Erizará los bigotes cibernéticos de tus comensales más exigentes.'
  },
  {
    id: 'trex_steak',
    name: 'Bife T-Rex Blindado',
    emoji: '🍖',
    ingredients: ['titanium_jaw', 'plasma_core', 'blue_venom'],
    basePrice: 850,
    description: 'Corte titánico sellado a temperaturas de soplete industrial.'
  },
  {
    id: 'singularity_roast',
    name: 'Asado de la Singularidad',
    emoji: '🍱',
    ingredients: ['antimatter_shard', 'omega_cell', 'quantum_condenser'],
    basePrice: 1400,
    description: 'Plato místico que desafía las leyes de la termodinámica. Paga fortunas.'
  }
];

const FIXED_SHOP_ITEMS = [
  {
    id: 'full_heal',
    name: 'Nanobots Médicos (Cura Total)',
    emoji: '🧪',
    type: 'heal',
    description: 'Cura 100% de tus PS. Vale la pena en combates duros.',
    baseCost: 250,
    amount: 1
  },
  {
    id: 'attack',
    name: 'Sobrecarga de Cuchillas',
    emoji: '⚔️',
    type: 'stat',
    description: '+3 de daño base permanente',
    baseCost: 180,
    stat: 'attack',
    amount: 3
  }
];

const WEAPONS_CATALOG = [
  // ── TIER 1: ARMAS DE INICIACIÓN ──
  { id: 'vibro_knife',      name: 'Cuchillo Vibrador',        emoji: '🔪', attack:  8,  price:  120,  desc: 'Filo vibrante de alta frecuencia. Primera mejora real para un chef novato.' },
  { id: 'plasma_blade',     name: 'Hoja de Plasma',           emoji: '🗡️', attack:  16, price:  280,  desc: 'Genera un arco de plasma ionizado. Corta acero como mantequilla.' },
  { id: 'shock_baton',      name: 'Porra de Descarga',        emoji: '⚡', attack:  22, price:  420,  desc: 'Libera pulsos eléctricos al impacto. Popular en las rondas de vigilancia.' },
  // ── TIER 2: ARMAS INTERMEDIAS ──
  { id: 'laser_cleaver',    name: 'Hacha Carnicera Láser',    emoji: '🪓', attack:  32, price:  650,  desc: 'Hoja de energía focalizada. Diseñada para desmembrar bestias cibernéticas.' },
  { id: 'arc_saber',        name: 'Sable de Arco',            emoji: '🌙', attack:  42, price:  900,  desc: 'Emite un campo de arco voltaico que amplia el área de corte considerablemente.' },
  { id: 'thermal_cutlass',  name: 'Cimitarra Térmica',        emoji: '🔥', attack:  50, price: 1100,  desc: 'Hoja superenfriada y supercalentada de forma simultánea. Corte devastador.' },
  { id: 'nano_scythe',      name: 'Guadaña Nanotec',          emoji: '🩸', attack:  62, price: 1400,  desc: 'Microfilos nanoscópicos oscilantes de carburo de titanio. Penetra cualquier blindaje.' },
  // ── TIER 3: ARMAS ÉLITE ──
  { id: 'ion_katana',       name: 'Katana de Iones',          emoji: '⚔️', attack:  78, price: 1800,  desc: 'Katana de plasma iónico. Emite descargas voltaicas en cada golpe maestro.' },
  { id: 'gravity_hammer',   name: 'Martillo Gravitacional',   emoji: '🔨', attack:  92, price: 2200,  desc: 'Amplificador de masa gravitacional portátil. Aplasta estructuras enteras.' },
  { id: 'void_reaper',      name: 'Segadora del Vacío',       emoji: '🌑', attack: 108, price: 2800,  desc: 'Crea microdesgarros en la tela espacial en cada oscilación. Daño irreal.' },
  { id: 'crystal_spear',    name: 'Lanza de Cristal Cuántico',emoji: '💎', attack: 122, price: 3500,  desc: 'Proyectil de cristal que colapsa su propia superposición al impactar.' },
  // ── TIER 4: ARMAS LEGENDARIAS ──
  { id: 'antimatter_edge',  name: 'Filo Antimateria',         emoji: '💫', attack: 140, price: 4500,  desc: 'Arma prohibida del Sector Oscuro. Cada corte aniquila la materia a nivel subatómico.' },
  { id: 'omega_blade',      name: 'Espadón Omega Definitivo', emoji: '🌠', attack: 165, price: 6000,  desc: 'Fabricada en los hornos estelares de la última estrella de neutrones. Daño absoluto.' },
  { id: 'singularity_scythe',name: 'Guadaña de la Singularidad',emoji:'✨',attack: 200, price: 9999,  desc: 'La guadaña del fin del mundo. Se dice que fue forjada con la entropía del universo.' }
];

const SHOP_ITEMS = [
  ...FIXED_SHOP_ITEMS,
  { id: 'defense', name: 'Delantal blindado', emoji: '🛡️', type: 'stat', description: '+2 defensa permanente', baseCost: 160, stat: 'defense', amount: 2 },
  { id: 'maxHp', name: 'Implante vital', emoji: '❤️', type: 'stat', description: '+25 vida máxima y cura', baseCost: 220, stat: 'maxHp', amount: 25 }
];

const CUSTOMER_TYPES = [
  {
    id: 'rust_wolf',
    name: 'Lobo de Óxido',
    emoji: '🐺',
    preferences: ['chrome_skewer', 'scrap_stew', 'red_core_burger'],
    budget: 400, patience: 40
  },
  {
    id: 'chrome_mantis',
    name: 'Mantis de Cromo',
    emoji: '🦗',
    preferences: ['glass_eye_sashimi', 'titanium_wings', 'plasma_soup'],
    budget: 600, patience: 30
  },
  {
    id: 'neon_cat',
    name: 'Gato Neón',
    emoji: '🐱',
    preferences: ['titanium_wings', 'glass_eye_sashimi'],
    budget: 350, patience: 45
  },
  {
    id: 'scrap_bear',
    name: 'Oso de Chatarra',
    emoji: '🐻',
    preferences: ['scrap_stew', 'chrome_skewer', 'red_core_burger'],
    budget: 300, patience: 50
  },
  {
    id: 'plasma_hawk',
    name: 'Halcón de Plasma',
    emoji: '🦅',
    preferences: ['plasma_soup', 'glass_eye_sashimi'],
    budget: 500, patience: 28
  },
  {
    id: 'circuit_fox',
    name: 'Zorro de Circuito',
    emoji: '🦊',
    preferences: ['red_core_burger', 'titanium_wings', 'chrome_skewer'],
    budget: 450, patience: 35
  },
  {
    id: 'cyber_syndicate_boss',
    name: 'Jefe del Sindicato Cibernético',
    emoji: '🦹',
    preferences: ['volt_ribs', 'trex_steak', 'singularity_roast'],
    budget: 1200, patience: 32
  },
  {
    id: 'quantum_entity',
    name: 'Comerciante de la Singularidad',
    emoji: '👾',
    preferences: ['singularity_roast', 'trex_steak', 'glass_eye_sashimi'],
    budget: 2000, patience: 25
  }
];

// ── SECTORES DEL YERMO (1 AL 10) ──
// Cada sector tiene una economía distinta: paga mucho más por ciertas comidas y menos por otras.
// El Sector 10 (Gran Mercado Central) paga casi igual por todas las comidas (1.18x parejo, un poco más bajo que las especialidades individuales de 1.45x) para que sea ideal para farmear sin generar abusos de poder.
const SECTORS = [
  {
    id: 1,
    name: 'Sector 1: Yermo de Chatarra',
    emoji: '⚙️',
    desc: 'Zona marginal de recicladores. Pagan premium por comida callejera contundente.',
    reqLevel: 1,
    multipliers: {
      chrome_skewer: 1.40,
      scrap_stew: 1.45,
      titanium_wings: 0.90,
      red_core_burger: 1.10,
      plasma_soup: 0.85,
      glass_eye_sashimi: 0.80,
      volt_ribs: 0.85,
      trex_steak: 0.80,
      singularity_roast: 0.75
    }
  },
  {
    id: 2,
    name: 'Sector 2: Muelles de Ácido',
    emoji: '🧪',
    desc: 'Refinerías químicas clandestinas. Aman las comidas con picante radioactivo y caldo.',
    reqLevel: 2,
    multipliers: {
      plasma_soup: 1.42,
      chrome_skewer: 1.00,
      scrap_stew: 1.10,
      titanium_wings: 1.15,
      red_core_burger: 0.90,
      glass_eye_sashimi: 0.95,
      volt_ribs: 0.85,
      trex_steak: 0.85,
      singularity_roast: 0.80
    }
  },
  {
    id: 3,
    name: 'Sector 3: Nido Neón',
    emoji: '🏮',
    desc: 'Distrito nocturno iluminado por holopantallas. Se pirran por las alitas y brochetas.',
    reqLevel: 3,
    multipliers: {
      titanium_wings: 1.45,
      chrome_skewer: 1.25,
      red_core_burger: 1.15,
      scrap_stew: 0.85,
      plasma_soup: 0.90,
      glass_eye_sashimi: 1.05,
      volt_ribs: 0.90,
      trex_steak: 0.85,
      singularity_roast: 0.80
    }
  },
  {
    id: 4,
    name: 'Sector 4: Factoría de Motores',
    emoji: '🏭',
    desc: 'Talleres mecánicos pesados. Los camioneros cibernéticos pagan fortuna por hamburguesas.',
    reqLevel: 4,
    multipliers: {
      red_core_burger: 1.48,
      scrap_stew: 1.20,
      chrome_skewer: 1.05,
      titanium_wings: 0.95,
      plasma_soup: 0.90,
      glass_eye_sashimi: 0.80,
      volt_ribs: 1.10,
      trex_steak: 0.90,
      singularity_roast: 0.80
    }
  },
  {
    id: 5,
    name: 'Sector 5: Torres Biocromadas',
    emoji: '🏙️',
    desc: 'Barrio alto corporativo. Los ejecutivos pagan sumas ridículas por sashimi exótico.',
    reqLevel: 5,
    multipliers: {
      glass_eye_sashimi: 1.50,
      titanium_wings: 1.10,
      plasma_soup: 1.10,
      chrome_skewer: 0.80,
      scrap_stew: 0.70,
      red_core_burger: 0.85,
      volt_ribs: 1.15,
      trex_steak: 1.10,
      singularity_roast: 1.05
    }
  },
  {
    id: 6,
    name: 'Sector 6: Núcleo de Alta Tensión',
    emoji: '⚡',
    desc: 'Plantas de energía donde las descargas eléctricas abren el apetito por cortes electrizantes.',
    reqLevel: 6,
    multipliers: {
      volt_ribs: 1.48,
      plasma_soup: 1.25,
      red_core_burger: 1.05,
      glass_eye_sashimi: 1.00,
      chrome_skewer: 0.85,
      scrap_stew: 0.80,
      titanium_wings: 0.90,
      trex_steak: 1.10,
      singularity_roast: 0.90
    }
  },
  {
    id: 7,
    name: 'Sector 7: La Franja Carmesí',
    emoji: '🩸',
    desc: 'El sector original de cazadores gladiadores. Valoran la carne de bestias colosales.',
    reqLevel: 7,
    multipliers: {
      trex_steak: 1.45,
      red_core_burger: 1.25,
      volt_ribs: 1.20,
      chrome_skewer: 1.10,
      scrap_stew: 1.05,
      titanium_wings: 1.05,
      plasma_soup: 1.00,
      glass_eye_sashimi: 0.90,
      singularity_roast: 1.10
    }
  },
  {
    id: 8,
    name: 'Sector 8: Foso de Antimateria',
    emoji: '🌀',
    desc: 'Laboratorios secretos y contrabandistas dimensionales. Obsesionados con la Singularidad.',
    reqLevel: 8,
    multipliers: {
      singularity_roast: 1.48,
      trex_steak: 1.25,
      glass_eye_sashimi: 1.20,
      volt_ribs: 1.15,
      plasma_soup: 1.05,
      titanium_wings: 0.85,
      red_core_burger: 0.85,
      chrome_skewer: 0.80,
      scrap_stew: 0.70
    }
  },
  {
    id: 9,
    name: 'Sector 9: El Ápex Negro',
    emoji: '👑',
    desc: 'Búnker de la mafia sintética. Buscan banquetes gourmet de máxima jerarquía.',
    reqLevel: 9,
    multipliers: {
      singularity_roast: 1.40,
      trex_steak: 1.42,
      volt_ribs: 1.35,
      glass_eye_sashimi: 1.30,
      red_core_burger: 0.95,
      titanium_wings: 0.90,
      plasma_soup: 0.90,
      chrome_skewer: 0.80,
      scrap_stew: 0.70
    }
  },
  {
    id: 10,
    name: 'Sector 10: Gran Mercado Central',
    emoji: '🌐',
    desc: 'El bazar interestelar de Nexus-7. Paga un precio balanceado y estable por ABSOLUTAMENTE TODO (~1.18x). Ideal para farmear en masa cualquier comida sin depender de clientes específicos.',
    reqLevel: 10,
    multipliers: {
      chrome_skewer: 1.18,
      plasma_soup: 1.18,
      titanium_wings: 1.18,
      scrap_stew: 1.18,
      glass_eye_sashimi: 1.18,
      red_core_burger: 1.18,
      volt_ribs: 1.18,
      trex_steak: 1.18,
      singularity_roast: 1.18
    }
  }
];
