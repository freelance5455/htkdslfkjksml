/* PCM TRACKER – syllabus data.
 * Chapter lists follow the standard NCERT chapter names for Classes 11 and 12.
 * IDs are permanent: never renumber them, or saved progress will not map to the right chapter.
 * scope: "both" = prescribed for CBSE and relevant to JEE; "cbse" = prescribed for CBSE, generally outside JEE scope.
 * Verify against the NCERT 2026–27 table of contents and CBSE syllabus before final use.
 */
const CLASSES = [
  {
    id: "11", name: "Class 11",
    subjects: [
      { id: "phy", name: "Physics", chapters: [
        { id: "11-phy-01", no: 1, name: "Physical World", scope: "cbse" },
        { id: "11-phy-02", no: 2, name: "Units and Measurement", scope: "both" },
        { id: "11-phy-03", no: 3, name: "Motion in a Straight Line", scope: "both" },
        { id: "11-phy-04", no: 4, name: "Motion in a Plane", scope: "both" },
        { id: "11-phy-05", no: 5, name: "Laws of Motion", scope: "both" },
        { id: "11-phy-06", no: 6, name: "Work, Energy and Power", scope: "both" },
        { id: "11-phy-07", no: 7, name: "System of Particles and Rotational Motion", scope: "both" },
        { id: "11-phy-08", no: 8, name: "Gravitation", scope: "both" },
        { id: "11-phy-09", no: 9, name: "Mechanical Properties of Solids", scope: "both" },
        { id: "11-phy-10", no: 10, name: "Mechanical Properties of Fluids", scope: "both" },
        { id: "11-phy-11", no: 11, name: "Thermal Properties of Matter", scope: "both" },
        { id: "11-phy-12", no: 12, name: "Thermodynamics", scope: "both" },
        { id: "11-phy-13", no: 13, name: "Kinetic Theory", scope: "both" },
        { id: "11-phy-14", no: 14, name: "Oscillations", scope: "both" },
        { id: "11-phy-15", no: 15, name: "Waves", scope: "both" }
      ]},
      { id: "chem", name: "Chemistry", chapters: [
        { id: "11-chem-01", no: 1, name: "Some Basic Concepts of Chemistry", scope: "both" },
        { id: "11-chem-02", no: 2, name: "Structure of Atom", scope: "both" },
        { id: "11-chem-03", no: 3, name: "Classification of Elements and Periodicity in Properties", scope: "both" },
        { id: "11-chem-04", no: 4, name: "Chemical Bonding and Molecular Structure", scope: "both" },
        { id: "11-chem-05", no: 5, name: "States of Matter: Gases and Liquids", scope: "both" },
        { id: "11-chem-06", no: 6, name: "Thermodynamics", scope: "both" },
        { id: "11-chem-07", no: 7, name: "Equilibrium", scope: "both" },
        { id: "11-chem-08", no: 8, name: "Redox Reactions", scope: "both" },
        { id: "11-chem-09", no: 9, name: "Hydrogen", scope: "both" },
        { id: "11-chem-10", no: 10, name: "The s-Block Elements", scope: "both" },
        { id: "11-chem-11", no: 11, name: "The p-Block Elements", scope: "both" },
        { id: "11-chem-12", no: 12, name: "Organic Chemistry: Some Basic Principles and Techniques", scope: "both" },
        { id: "11-chem-13", no: 13, name: "Hydrocarbons", scope: "both" },
        { id: "11-chem-14", no: 14, name: "Environmental Chemistry", scope: "cbse" }
      ]},
      { id: "math", name: "Mathematics", chapters: [
        { id: "11-math-01", no: 1, name: "Sets", scope: "both" },
        { id: "11-math-02", no: 2, name: "Relations and Functions", scope: "both" },
        { id: "11-math-03", no: 3, name: "Trigonometric Functions", scope: "both" },
        { id: "11-math-04", no: 4, name: "Complex Numbers and Quadratic Equations", scope: "both" },
        { id: "11-math-05", no: 5, name: "Linear Inequalities", scope: "both" },
        { id: "11-math-06", no: 6, name: "Permutations and Combinations", scope: "both" },
        { id: "11-math-07", no: 7, name: "Binomial Theorem", scope: "both" },
        { id: "11-math-08", no: 8, name: "Sequences and Series", scope: "both" },
        { id: "11-math-09", no: 9, name: "Straight Lines", scope: "both" },
        { id: "11-math-10", no: 10, name: "Conic Sections", scope: "both" },
        { id: "11-math-11", no: 11, name: "Introduction to Three Dimensional Geometry", scope: "both" },
        { id: "11-math-12", no: 12, name: "Limits and Derivatives", scope: "both" },
        { id: "11-math-13", no: 13, name: "Statistics", scope: "both" },
        { id: "11-math-14", no: 14, name: "Probability", scope: "both" }
      ]}
    ]
  },
  {
    id: "12", name: "Class 12",
    subjects: [
      { id: "phy", name: "Physics", chapters: [
        { id: "12-phy-01", no: 1, name: "Electric Charges and Fields", scope: "both" },
        { id: "12-phy-02", no: 2, name: "Electrostatic Potential and Capacitance", scope: "both" },
        { id: "12-phy-03", no: 3, name: "Current Electricity", scope: "both" },
        { id: "12-phy-04", no: 4, name: "Moving Charges and Magnetism", scope: "both" },
        { id: "12-phy-05", no: 5, name: "Magnetism and Matter", scope: "both" },
        { id: "12-phy-06", no: 6, name: "Electromagnetic Induction", scope: "both" },
        { id: "12-phy-07", no: 7, name: "Alternating Current", scope: "both" },
        { id: "12-phy-08", no: 8, name: "Electromagnetic Waves", scope: "both" },
        { id: "12-phy-09", no: 9, name: "Ray Optics and Optical Instruments", scope: "both" },
        { id: "12-phy-10", no: 10, name: "Wave Optics", scope: "both" },
        { id: "12-phy-11", no: 11, name: "Dual Nature of Radiation and Matter", scope: "both" },
        { id: "12-phy-12", no: 12, name: "Atoms", scope: "both" },
        { id: "12-phy-13", no: 13, name: "Nuclei", scope: "both" },
        { id: "12-phy-14", no: 14, name: "Semiconductor Electronics: Materials, Devices and Simple Circuits", scope: "both" }
      ]},
      { id: "chem", name: "Chemistry", chapters: [
        { id: "12-chem-01", no: 1, name: "Solutions", scope: "both" },
        { id: "12-chem-02", no: 2, name: "Electrochemistry", scope: "both" },
        { id: "12-chem-03", no: 3, name: "Chemical Kinetics", scope: "both" },
        { id: "12-chem-04", no: 4, name: "The d- and f-Block Elements", scope: "both" },
        { id: "12-chem-05", no: 5, name: "Coordination Compounds", scope: "both" },
        { id: "12-chem-06", no: 6, name: "Haloalkanes and Haloarenes", scope: "both" },
        { id: "12-chem-07", no: 7, name: "Alcohols, Phenols and Ethers", scope: "both" },
        { id: "12-chem-08", no: 8, name: "Aldehydes, Ketones and Carboxylic Acids", scope: "both" },
        { id: "12-chem-09", no: 9, name: "Amines", scope: "both" },
        { id: "12-chem-10", no: 10, name: "Biomolecules", scope: "cbse" },
        { id: "12-chem-11", no: 11, name: "Polymers", scope: "cbse" },
        { id: "12-chem-12", no: 12, name: "Chemistry in Everyday Life", scope: "cbse" }
      ]},
      { id: "math", name: "Mathematics", chapters: [
        { id: "12-math-01", no: 1, name: "Relations and Functions", scope: "both" },
        { id: "12-math-02", no: 2, name: "Inverse Trigonometric Functions", scope: "both" },
        { id: "12-math-03", no: 3, name: "Matrices", scope: "both" },
        { id: "12-math-04", no: 4, name: "Determinants", scope: "both" },
        { id: "12-math-05", no: 5, name: "Continuity and Differentiability", scope: "both" },
        { id: "12-math-06", no: 6, name: "Application of Derivatives", scope: "both" },
        { id: "12-math-07", no: 7, name: "Integrals", scope: "both" },
        { id: "12-math-08", no: 8, name: "Application of Integrals", scope: "both" },
        { id: "12-math-09", no: 9, name: "Differential Equations", scope: "both" },
        { id: "12-math-10", no: 10, name: "Vector Algebra", scope: "both" },
        { id: "12-math-11", no: 11, name: "Three Dimensional Geometry", scope: "both" },
        { id: "12-math-12", no: 12, name: "Linear Programming", scope: "both" },
        { id: "12-math-13", no: 13, name: "Probability", scope: "both" }
      ]}
    ]
  }
];

const TASKS = [
  { k: "notes", label: "Concepts / Notes Done" },
  { k: "bpyq", label: "Board PYQs Done" },
  { k: "jpyq", label: "JEE PYQs Done" },
  { k: "brev", label: "Board Revision Done" },
  { k: "jrev", label: "JEE Revision Done" }
];
