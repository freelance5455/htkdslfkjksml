// Pure input helpers. Times are normalized to UTC candle-close milliseconds.
export const MINUTE = 60000;
function splitLine(line, separator) {
  const cells = []; let cell = '', quoted = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (c === '"') { if (quoted && line[i + 1] === '"') { cell += c; i++; } else quoted = !quoted; }
    else if (c === separator && !quoted) { cells.push(cell.trim()); cell = ''; }
    else cell += c;
  }
  if (quoted) throw new Error('Unclosed CSV quote. Multi-line fields are not supported.');
  cells.push(cell.trim()); return cells;
}
export function parseTime(value) {
  let text = String(value).trim();
  if (/^\d{10}$/.test(text)) return Number(text) * 1000;
  if (/^\d{13}$/.test(text)) return Number(text);
  text = text.replace(/^(\d{4})\.(\d{2})\.(\d{2})/, '$1-$2-$3').replace(' ', 'T');
  const match = text.match(/^(\d{4})-(\d{2})-(\d{2})(?:T(\d{2}):(\d{2})(?::(\d{2})(?:\.(\d{1,3}))?)?)?(Z|[+-]\d{2}:\d{2})?$/i);
  if (!match) throw new Error('Use ISO UTC or YYYY.MM.DD HH:mm:ss timestamps.');
  const [, year, month, day, hour = '00', minute = '00', second = '00', , zone] = match;
  const test = new Date(Date.UTC(+year, +month - 1, +day, +hour, +minute, +second));
  if (test.getUTCFullYear() !== +year || test.getUTCMonth() !== +month - 1 || test.getUTCDate() !== +day || +hour > 23 || +minute > 59 || +second > 59) throw new Error('Invalid calendar timestamp.');
  if (!zone) text += 'Z';
  const time = Date.parse(text);
  if (!Number.isFinite(time)) throw new Error('Invalid timestamp.');
  return time;
}
export async function parseCSV(text, mode = 'open', onProgress = () => {}) {
  const lines = text.replace(/^\uFEFF/, '').split(/\r?\n/).filter(line => line.trim());
  if (lines.length < 2) throw new Error('The file must have a header and at least one candle.');
  if (lines.length > 500001) throw new Error('This workspace supports up to 500,000 candles per run.');
  const delimiter = ['\t', ';', ','].sort((a, b) => lines[0].split(b).length - lines[0].split(a).length)[0];
  const headers = splitLine(lines[0], delimiter).map(s => s.toLowerCase().replace(/[<>\s_]/g, ''));
  const find = names => headers.findIndex(h => names.includes(h));
  const ti = find(['timestamp', 'datetime', 'date', 'time']);
  const di = find(['date']); const clock = find(['time']);
  const cols = ['open', 'high', 'low', 'close'].map(h => find([h]));
  const vi = find(['volume', 'tickvol', 'tickvolume', 'vol']);
  if (ti < 0 || cols.some(i => i < 0)) throw new Error('Required columns: timestamp (or date + time), open, high, low, close.');
  const bars = []; let gaps = 0;
  for (let i = 1; i < lines.length; i++) {
    try {
      const cells = splitLine(lines[i], delimiter);
      const stamp = di >= 0 && clock >= 0 && di !== clock ? `${cells[di]} ${cells[clock]}` : cells[ti];
      let t = parseTime(stamp);
      if (t % MINUTE !== 0) throw new Error('Timestamps must align to exact minutes.');
      if (mode === 'open') t += MINUTE;
      const values = cols.map(c => cells[c] === undefined || cells[c] === '' ? NaN : Number(cells[c]));
      const [open, high, low, close] = values;
      const volume = vi < 0 ? 0 : (cells[vi] === '' || cells[vi] === undefined ? NaN : Number(cells[vi]));
      if (!values.every(Number.isFinite) || values.some(v => v <= 0) || !Number.isFinite(volume) || volume < 0) throw new Error('Prices must be positive finite numbers and volume non-negative.');
      if (high < Math.max(open, close) || low > Math.min(open, close) || high < low) throw new Error('OHLC range is inconsistent.');
      if (bars.length) {
        const delta = t - bars[bars.length - 1].t;
        if (delta <= 0) throw new Error('Timestamps must be strictly increasing with no duplicates.');
        if (delta > MINUTE) gaps++;
      }
      bars.push({ t, open, high, low, close, volume });
    } catch (error) { throw new Error(`Row ${i + 1}: ${error.message}`); }
    if (i % 10000 === 0) { onProgress(i / lines.length); await new Promise(resolve => setTimeout(resolve, 0)); }
  }
  return { bars, gaps };
}
// Seeded synthetic OHLC, explicitly not historical market data or evidence of an edge.
export async function syntheticData(onProgress = () => {}) {
  let seed = 47291;
  const random = () => { seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed / 4294967296; };
  const bars = []; let price = 1.1;
  const start = Date.UTC(2025, 0, 6); const count = 40320;
  for (let i = 0; i < count; i++) {
    const open = price;
    const wave = Math.sin(i / 1600) * 0.000008;
    const shock = i % 571 === 0 ? (random() - 0.5) * 0.0025 : 0;
    price = Math.max(0.3, open + (random() - 0.5) * 0.00022 + wave + shock);
    const wick = 0.000015 + random() * 0.00008;
    bars.push({ t: start + (i + 1) * MINUTE, open, high: Math.max(open, price) + wick * random(), low: Math.min(open, price) - wick * random(), close: price, volume: Math.round(10 + random() * 250) });
    if (i % 10000 === 0) { onProgress(i / count); await new Promise(resolve => setTimeout(resolve, 0)); }
  }
  return { bars, gaps: 0 };
}
