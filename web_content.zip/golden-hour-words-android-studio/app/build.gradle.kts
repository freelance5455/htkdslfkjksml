plugins {
    id("com.android.application")
}

android {
    namespace = "com.example.goldenhourwords"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.goldenhourwords"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
}

dependencies {
    // Google Mobile Ads SDK (banner + rewarded)
    implementation("com.google.android.gms:play-services-ads:23.6.0")
}
