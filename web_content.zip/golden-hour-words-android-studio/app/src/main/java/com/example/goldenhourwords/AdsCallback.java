package com.example.goldenhourwords;

/** Called ONLY after the AdMob SDK confirms the user earned the reward. */
public interface AdsCallback {
    void onReward(int coins);
}
