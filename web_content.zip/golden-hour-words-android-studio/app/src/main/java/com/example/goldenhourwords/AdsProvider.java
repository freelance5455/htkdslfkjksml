package com.example.goldenhourwords;

/** Lifecycle hooks for the ad layer (implemented by AdMobHelper). Contains no Google classes, so it always compiles. */
public interface AdsProvider {
    void onPause();
    void onResume();
    void onDestroy();
}
