package com.example.goldenhourwords;

import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.OnUserEarnedRewardListener;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

/**
 * Banner (bottom) + rewarded button. Needs the library com.google.android.gms:play-services-ads.
 * The ad area sits BELOW the game, so it never covers the game or its buttons.
 */
public class AdMobHelper implements AdsProvider {

    // ===================== CONFIG =====================
    // true  = Google's official TEST ads (use while developing).
    // false = your real ad units below. Never tap your own real ads.
    private static final boolean USE_TEST_ADS = true;

    private static final String TEST_BANNER_UNIT   = "ca-app-pub-3940256099942544/9214589741"; // Google test: adaptive banner
    private static final String TEST_REWARDED_UNIT = "ca-app-pub-3940256099942544/5224354917"; // Google test: rewarded

    // Paste REAL unit IDs here only after confirming their format in AdMob (Apps > your app > Ad units).
    // Leave empty to turn that ad type off when USE_TEST_ADS is false.
    private static final String BANNER_UNIT   = "";  // must be a BANNER unit
    private static final String REWARDED_UNIT = "";  // must be a REWARDED unit

    private static final int REWARD_COINS = 5;
    // ==================================================

    private final Activity activity;
    private final AdsCallback callback;
    private final LinearLayout box;
    private final Button rewardButton;
    private AdView adView;
    private RewardedAd rewardedAd;
    private boolean loadingRewarded = false;
    private boolean showingRewarded = false;
    private boolean rewardGiven = false;

    public AdMobHelper(Activity activity, ViewGroup slot, AdsCallback callback) {
        this.activity = activity;
        this.callback = callback;

        box = new LinearLayout(activity);
        box.setOrientation(LinearLayout.VERTICAL);
        slot.addView(box, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        rewardButton = new Button(activity);
        rewardButton.setAllCaps(false);
        rewardButton.setBackgroundColor(0xFF1C1A17);
        rewardButton.setTextColor(0xFFF2EADB);
        rewardButton.setText("Loading ad…");
        rewardButton.setEnabled(false);
        rewardButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { onRewardButton(); }
        });
        box.addView(rewardButton, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));

        MobileAds.initialize(activity, new OnInitializationCompleteListener() {
            @Override public void onInitializationComplete(InitializationStatus status) {
                loadBanner();
                loadRewarded();
            }
        });
    }

    // ---------------- helpers ----------------
    private String bannerUnit()   { return USE_TEST_ADS ? TEST_BANNER_UNIT   : BANNER_UNIT; }
    private String rewardedUnit() { return USE_TEST_ADS ? TEST_REWARDED_UNIT : REWARDED_UNIT; }

    private boolean online() {
        try {
            ConnectivityManager cm = (ConnectivityManager) activity.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo ni = (cm == null) ? null : cm.getActiveNetworkInfo();
            return ni != null && ni.isConnected();
        } catch (Exception e) {
            return true; // if we cannot tell, let the SDK try
        }
    }

    private void toast(String text) {
        Toast.makeText(activity, text, Toast.LENGTH_LONG).show();
    }

    private int dp(int v) {
        return (int) (v * activity.getResources().getDisplayMetrics().density + 0.5f);
    }

    private String reason(LoadAdError e) {
        switch (e.getCode()) {
            case 3:  return "No ad available right now";
            case 2:  return "Network error";
            case 1:  return "Invalid request (check the ad unit ID and App ID)";
            case 0:  return "Internal error";
            default: return e.getMessage();
        }
    }

    // ---------------- banner ----------------
    private void loadBanner() {
        String unit = bannerUnit();
        if (unit == null || unit.length() == 0) return; // banner turned off
        adView = new AdView(activity);
        adView.setAdUnitId(unit);
        int widthDp = (int) (activity.getResources().getDisplayMetrics().widthPixels
                / activity.getResources().getDisplayMetrics().density);
        adView.setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(activity, widthDp));
        adView.setVisibility(View.GONE); // takes no space until an ad has loaded
        adView.setAdListener(new AdListener() {
            @Override public void onAdLoaded() { adView.setVisibility(View.VISIBLE); }
            @Override public void onAdFailedToLoad(LoadAdError error) { adView.setVisibility(View.GONE); }
        });
        box.addView(adView, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        adView.loadAd(new AdRequest.Builder().build());
    }

    // ---------------- rewarded ----------------
    private void onRewardButton() {
        if (showingRewarded || loadingRewarded) return;      // ignore repeated taps
        if (rewardedAd != null) {
            showRewarded();
        } else {
            loadRewarded();
        }
    }

    private void loadRewarded() {
        if (loadingRewarded || showingRewarded || rewardedAd != null) return;
        String unit = rewardedUnit();
        if (unit == null || unit.length() == 0) {
            rewardButton.setText("Rewarded ad not set up");
            rewardButton.setEnabled(false);
            return;
        }
        if (!online()) {
            rewardButton.setText("No internet. Tap to retry");
            rewardButton.setEnabled(true);
            return;
        }
        loadingRewarded = true;
        rewardButton.setText("Loading ad…");
        rewardButton.setEnabled(false);
        RewardedAd.load(activity, unit, new AdRequest.Builder().build(), new RewardedAdLoadCallback() {
            @Override public void onAdLoaded(RewardedAd ad) {
                rewardedAd = ad;
                loadingRewarded = false;
                rewardButton.setText("Watch ad: +" + REWARD_COINS + " coins");
                rewardButton.setEnabled(true);
            }
            @Override public void onAdFailedToLoad(LoadAdError error) {
                rewardedAd = null;
                loadingRewarded = false;
                rewardButton.setText("Ad unavailable. Tap to retry");
                rewardButton.setEnabled(true);
                toast(reason(error) + " [" + error.getCode() + "]");
            }
        });
    }

    private void showRewarded() {
        final RewardedAd ad = rewardedAd;
        if (ad == null) return;
        showingRewarded = true;
        rewardGiven = false;
        rewardedAd = null;                                   // an ad can only be shown once
        rewardButton.setEnabled(false);
        rewardButton.setText("Ad playing…");
        ad.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override public void onAdDismissedFullScreenContent() {
                showingRewarded = false;
                if (!rewardGiven) toast("Watch the whole video to get the reward");
                loadRewarded();                              // prepare the next one
            }
            @Override public void onAdFailedToShowFullScreenContent(AdError error) {
                showingRewarded = false;
                toast("Ad could not be shown: " + error.getMessage());
                loadRewarded();
            }
        });
        ad.show(activity, new OnUserEarnedRewardListener() {
            @Override public void onUserEarnedReward(RewardItem item) {
                if (rewardGiven) return;                     // never pay twice
                rewardGiven = true;
                callback.onReward(REWARD_COINS);             // SDK confirmed completion
            }
        });
    }

    // ---------------- lifecycle ----------------
    @Override public void onPause()   { if (adView != null) adView.pause(); }
    @Override public void onResume()  { if (adView != null) adView.resume(); }
    @Override public void onDestroy() { if (adView != null) adView.destroy(); }
}
