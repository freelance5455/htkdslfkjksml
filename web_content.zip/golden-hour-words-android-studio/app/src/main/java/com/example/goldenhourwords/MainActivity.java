package com.example.goldenhourwords;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {

    private WebView web;
    private AdsProvider ads;

    // Lets the Android back button act like the game's own back/close buttons.
    // Returns "exit" when there is nothing left to close.
    private static final String BACK_JS =
        "(function(){var g=function(i){return document.getElementById(i)};"
      + "var d=function(e){return !!e&&getComputedStyle(e).display!=='none'};"
      + "if(d(g('pn'))){g('px').click();return 'ok'}"
      + "if(d(g('ch'))){g('chb').click();return 'ok'}"
      + "if(!d(g('play'))&&!d(g('prof'))&&g('gb')){g('gb').click();return 'ok'}"
      + "return 'exit'})()";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        web = (WebView) findViewById(R.id.webview);
        web.setBackgroundColor(0xFFF2EADB);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);          // localStorage (saves, coins, progress)
        s.setDatabaseEnabled(true);            // IndexedDB (photo cache)
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);

        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("file".equals(u.getScheme())) {
                    return false; // stay inside the game
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u)); // links open in the browser
                } catch (Exception ignored) { }
                return true;
            }
        });

        initAds();

        if (savedInstanceState == null) {
            web.loadUrl("file:///android_asset/index.html");
        } else {
            web.restoreState(savedInstanceState);
        }
    }

    // AdMob lives in AdMobHelper.java. It needs the play-services-ads library, so it is optional:
    // without that file the app builds and runs with no ads.
    private void initAds() {
        Class<?> c;
        try {
            c = Class.forName("com.example.goldenhourwords.AdMobHelper");
        } catch (Throwable t) {
            return; // AdMobHelper.java is not in this project: no ads
        }
        try {
            ads = (AdsProvider) c.getConstructor(Activity.class, ViewGroup.class, AdsCallback.class)
                    .newInstance(this, (ViewGroup) findViewById(R.id.ads_slot), new AdsCallback() {
                        @Override public void onReward(int coins) { grantReward(coins); }
                    });
        } catch (Throwable t) {
            Throwable r = (t.getCause() != null) ? t.getCause() : t;
            Log.e("WordBrainAds", "AdMob setup failed", r);
            Toast.makeText(this, "Ads setup problem: " + r, Toast.LENGTH_LONG).show();
        }
    }

    // Adds coins inside the game (uses the game's own coins/save/render), only after AdMob confirmed the reward.
    private void grantReward(final int coins) {
        String js = "(function(){try{if(typeof coins==='number'&&typeof save==='function'&&typeof render==='function')"
                  + "{coins+=" + coins + ";save();render();return 'ok'}}catch(e){}return 'no'})()";
        web.evaluateJavascript(js, new ValueCallback<String>() {
            @Override public void onReceiveValue(String v) {
                if (v != null && v.contains("ok")) {
                    Toast.makeText(MainActivity.this, "+" + coins + " coins", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "Reward earned, but the game could not add coins.", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript(BACK_JS, new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String value) {
                if (value == null || value.contains("exit")) {
                    finish();
                }
            }
        });
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.onPause();
        if (ads != null) ads.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
        if (ads != null) ads.onResume();
    }

    @Override
    protected void onDestroy() {
        if (ads != null) ads.onDestroy();
        if (web != null) {
            web.destroy();
        }
        super.onDestroy();
    }
}
