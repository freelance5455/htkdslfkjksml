# Golden Hour Words - Android Studio project (AdMob banner + rewarded)

Same app as the CodeAssist project: your HTML game is in app/src/main/assets/index.html (unchanged),
shown by a native WebView. AdMob is added with the official Google Mobile Ads SDK.

## Build the APK
Option A - Android Studio (easiest)
1. Open this folder in Android Studio (File > Open). Let it sync (it downloads Gradle and the SDK).
2. Build > Build Bundle(s) / APK(s) > Build APK(s).
3. APK: app/build/outputs/apk/debug/app-debug.apk

Option B - command line (needs JDK 17 and Gradle installed once)
    gradle wrapper --gradle-version 8.9
    ./gradlew assembleDebug            (Windows: gradlew.bat assembleDebug)
    adb install -r app/build/outputs/apk/debug/app-debug.apk

## Ads
Edit app/src/main/java/com/example/goldenhourwords/AdMobHelper.java:
- USE_TEST_ADS = true  -> Google test ads (default, use for all testing).
- Real ads: set USE_TEST_ADS = false and paste a BANNER unit ID into BANNER_UNIT and a REWARDED unit ID
  into REWARDED_UNIT (see the instructions in the chat). Never tap your own real ads.
AdMob App ID is in app/src/main/AndroidManifest.xml.
