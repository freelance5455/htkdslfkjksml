MindMate AI – Colorful Simple Chat Edition

Features:
- Simple chat layout with user questions shown as right-side chat bubbles and MindMeta answers on the left.
- Saves recent chats in this browser using local storage. Start a new chat or select an earlier chat from the sidebar.
- Light and dark modes.
- Gemini API key setting for online AI answers and photo understanding.
- Photo attachment preview; images are compressed and stored with the chat so they remain visible when reopening saved chats.
- Built-in offline emergency guidance, common GK facts, school help, and friendly conversation replies.

Run:
1. Extract the ZIP.
2. Open the MindMate_Professional folder in VS Code.
3. Install/use Live Server and open index.html through Live Server.
4. Open Settings and add your Gemini API key for online answers and image analysis.

Notes:
- Photo analysis requires internet and a valid Gemini API key. Photos remain visible in saved chat history in the same browser.
- Chats are stored in this browser on this device; clearing browser storage removes them.
- A browser-only API key is not secure for public distribution. Use a backend before publishing widely.
- Offline mode is limited to built-in knowledge and emergency guidance; it is not a full offline AI model.
- In a real emergency, contact local emergency services immediately.
