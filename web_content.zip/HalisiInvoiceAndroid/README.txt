HALISI MABATI MILLS INVOICE - ANDROID STUDIO PROJECT

Open this folder in Android Studio (File > Open), allow Gradle sync, then select:
Build > Build Bundle(s) / APK(s) > Build APK(s).

The app is offline-first. The Halisi logo and PAID stamp are bundled in app/src/main/assets.
The invoice PDF button uses Android's native print-to-PDF screen. Choose "Save as PDF" there.

Package: ke.co.halisimabati.invoice
Minimum Android: 6.0 (API 23)

No internet permission is required.
