# Electricity Billing Software — Android APK project

Software ID: 01865493321

এই Android Studio প্রজেক্টটি আপনার দেওয়া মোবাইল-উপযোগী HTML বিলিং সফটওয়্যারকে WebView-এর মধ্যে চালায়। এতে মূল HTML-এর গ্রাহক তথ্য, মিটার রিডিং, আবাসিক/বাণিজ্যিক বিল হিসাব ও A4 প্রিন্ট লেআউট রাখা হয়েছে।

## APK তৈরি করার নিয়ম
1. কম্পিউটারে Android Studio (এবং Android SDK Platform 35) ইনস্টল করুন।
2. Android Studio থেকে `ElectricityBillingAndroid` ফোল্ডারটি Open করুন।
3. Gradle Sync শেষ হলে **Build > Build APK(s)** নির্বাচন করুন।
4. APK সাধারণত `app/build/outputs/apk/debug/app-debug.apk`-এ তৈরি হবে।

## সীমাবদ্ধতা ও নিরাপত্তা
- এই পরিবেশে Android SDK/Gradle build tool নেই, তাই এখানে APK compile/sign করা হয়নি। এটি Android Studio-তে build করার source project।
- HTML-এর বিদ্যমান BREB API অংশটি নিজে থেকে লাইভ BREB authentication করে না। আপনার চাওয়া এই সংস্করণে মূল কাজ বিল হিসাব ও প্রিন্ট।
- BREB login/API পরে চালু করতে হলে BREB/PBS-এর অনুমোদিত SOAP request/response format এবং credentials প্রয়োজন। Secret/password কখনো HTML, APK বা client-side code-এ রাখবেন না; নিরাপদ HTTPS backend-এ রাখবেন।
- অ্যাপটি cleartext HTTP ব্লক করে এবং শুধু bundled local HTML চালানোর জন্য WebView সীমাবদ্ধ করা হয়েছে।
