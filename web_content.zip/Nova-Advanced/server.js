'use strict';
const express = require('express');
const path = require('path');
const app = express();
app.disable('x-powered-by');
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Permissions-Policy', 'camera=(), geolocation=(), payment=()');
  next();
});
app.use(express.json({ limit: '64kb' }));
app.use(express.static(path.join(__dirname, 'public'), { maxAge: '1h' }));

app.get('/health', (_req, res) => res.json({ ok: true, service: 'Nova', time: new Date().toISOString() }));
app.get('/api/status', (_req, res) => res.json({
  server: true,
  aiConfigured: Boolean(process.env.OPENAI_API_KEY),
  model: process.env.OPENAI_MODEL || 'gpt-4o-mini',
  features: { chat: Boolean(process.env.OPENAI_API_KEY), news: true, taskManager: 'local-device', automaticExecution: 'limited-and-permissioned' },
  time: new Date().toISOString()
}));

function cleanXml(s) {
  return String(s || '').replace(/<!\[CDATA\[|\]\]>/g, '').replace(/<[^>]*>/g, ' ')
    .replace(/&amp;/g, '&').replace(/&#39;|&apos;/g, "'").replace(/&quot;/g, '"')
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&#(\d+);/g, (_, n) => String.fromCharCode(Number(n)))
    .replace(/\s+/g, ' ').trim();
}
app.get('/api/news', async (_req, res) => {
  const feeds = [
    'https://techcrunch.com/category/artificial-intelligence/feed/',
    'https://www.technologyreview.com/topic/artificial-intelligence/feed/'
  ];
  try {
    const settled = await Promise.allSettled(feeds.map(async url => {
      const r = await fetch(url, { signal: AbortSignal.timeout(8000), headers: { 'User-Agent': 'NovaAssistant/2.0 (+RSS reader)' } });
      if (!r.ok) throw new Error('feed unavailable');
      const xml = await r.text();
      return [...xml.matchAll(/<item\b[\s\S]*?<\/item>/gi)].slice(0, 10).map(m => {
        const part = m[0];
        const pick = tag => cleanXml((part.match(new RegExp('<' + tag + '(?:\\s[^>]*)?>([\\s\\S]*?)<\\/' + tag + '>', 'i')) || [, ''])[1]);
        const link = cleanXml((part.match(/<link>([\s\S]*?)<\/link>/i) || [, ''])[1]);
        return { title: pick('title'), link, date: pick('pubDate'), source: new URL(url).hostname };
      }).filter(n => n.title && /^https:\/\//i.test(n.link));
    }));
    const news = settled.flatMap(x => x.status === 'fulfilled' ? x.value : []).slice(0, 15);
    res.setHeader('Cache-Control', 'public, max-age=600');
    res.json({ news, updatedAt: new Date().toISOString(), note: news.length ? '' : 'لم تتوفر الأخبار من المصادر الآن. حاول لاحقًا.' });
  } catch (_e) { res.json({ news: [], updatedAt: new Date().toISOString(), note: 'تعذر جلب الأخبار حاليًا؛ تحقق من اتصال الخادم بالإنترنت.' }); }
});



// Self-link endpoints. Secrets are read only from server environment variables.
const fs = require('fs');
const crypto = require('crypto');
const PROJECT_ROOT = __dirname;
const LINK_FILES = [
  'README_AR.md', 'server.js', 'package.json', 'render.yaml',
  'public/index.html', 'public/manifest.webmanifest', 'public/sw.js', 'public/icon.svg'
];
function secretMatches(given, expected) {
  if (typeof given !== 'string' || typeof expected !== 'string' || !given || !expected) return false;
  const a = Buffer.from(given); const b = Buffer.from(expected);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
async function githubRequest(url, token, options={}) {
  return fetch(url, { ...options, signal: AbortSignal.timeout(15000), headers: {
    'Authorization': `Bearer ${token}`, 'Accept': 'application/vnd.github+json',
    'X-GitHub-Api-Version': '2022-11-28', 'User-Agent': 'Nova-SelfLink',
    ...(options.headers || {})
  }});
}
app.get('/api/link/status', (_req, res) => {
  res.json({
    controlConfigured: Boolean(process.env.NOVA_CONTROL_TOKEN),
    githubConfigured: Boolean(process.env.GITHUB_TOKEN && process.env.GITHUB_OWNER && process.env.GITHUB_REPO),
    renderConfigured: Boolean(process.env.RENDER_API_KEY && (process.env.RENDER_SERVICE_ID || process.env.RENDER_SERVICE_ID)),
    instructions: 'للتنفيذ الذاتي، اضبط الأسرار في إعدادات Environment على الخادم فقط.'
  });
});
app.post('/api/link/execute', async (req, res) => {
  if (!secretMatches(req.headers.authorization?.replace(/^Bearer\s+/i, ''), process.env.NOVA_CONTROL_TOKEN)) {
    return res.status(401).json({ ok:false, error:'رمز التحكم غير صحيح أو لم يُضبط على الخادم. لا تضع الأسرار في مستودع GitHub.' });
  }
  const missing = [];
  for (const [key, value] of Object.entries({
    GITHUB_TOKEN: process.env.GITHUB_TOKEN, GITHUB_OWNER: process.env.GITHUB_OWNER,
    GITHUB_REPO: process.env.GITHUB_REPO, RENDER_API_KEY: process.env.RENDER_API_KEY,
    RENDER_SERVICE_ID: process.env.RENDER_SERVICE_ID
  })) if (!value) missing.push(key);
  if (missing.length) return res.status(503).json({ ok:false, stage:'configuration', missing, error:'لم يكتمل الإعداد الأولي. أضف المتغيرات المذكورة في Environment على الخادم ثم أعد الأمر somr.' });
  const owner=process.env.GITHUB_OWNER.trim(), repo=process.env.GITHUB_REPO.trim();
  const token=process.env.GITHUB_TOKEN.trim(), branch=process.env.GITHUB_BRANCH?.trim();
  if (!/^[A-Za-z0-9_.-]+$/.test(owner) || !/^[A-Za-z0-9_.-]+$/.test(repo)) return res.status(400).json({ok:false,error:'اسم مالك المستودع أو المستودع غير صالح.'});
  const apiBase=`https://api.github.com/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}`;
  try {
    const repoRes=await githubRequest(apiBase,token);
    if(!repoRes.ok) return res.status(502).json({ok:false,stage:'github',error:repoRes.status===401||repoRes.status===403?'تعذر التفويض إلى GitHub؛ تحقق من صلاحيات الرمز.':'تعذر العثور على المستودع المحدد أو الوصول إليه.'});
    const repoInfo=await repoRes.json();
    const targetBranch=branch || repoInfo.default_branch || undefined;
    const pushed=[], skipped=[];
    for(const rel of LINK_FILES){
      const contentPath=rel.split('/').map(encodeURIComponent).join('/');
      let existing=await githubRequest(`${apiBase}/contents/${contentPath}${targetBranch?'?ref='+encodeURIComponent(targetBranch):''}`,token);
      const local=fs.readFileSync(path.join(PROJECT_ROOT,rel));
      if(existing.ok){
        const old=await existing.json();
        const oldText=Buffer.from(String(old.content||'').replace(/\n/g,''),'base64');
        if(oldText.equals(local)){skipped.push(rel);continue;}
        return res.status(409).json({ok:false,stage:'github',error:`توقف Nova لحماية ملفاتك: الملف ${rel} موجود ومختلف في GitHub، لذلك لم يستبدله.`,pushed,skipped});
      }
      if(existing.status!==404) return res.status(502).json({ok:false,stage:'github',error:`تعذر فحص الملف ${rel} في GitHub.`,pushed,skipped});
      const body={message:`Nova self-link: add ${rel}`,content:local.toString('base64')};
      if(targetBranch) body.branch=targetBranch;
      const put=await githubRequest(`${apiBase}/contents/${contentPath}`,token,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
      if(!put.ok){const err=await put.json().catch(()=>({}));return res.status(502).json({ok:false,stage:'github',error:`تعذر رفع ${rel}. تحقق من صلاحية Contents: write في رمز GitHub.`,detail:String(err.message||'').slice(0,160),pushed,skipped});}
      pushed.push(rel);
    }
    const serviceId=process.env.RENDER_SERVICE_ID.trim();
    const renderCheck=await fetch(`https://api.render.com/v1/services/${encodeURIComponent(serviceId)}`,{headers:{Authorization:`Bearer ${process.env.RENDER_API_KEY.trim()}`,Accept:'application/json'},signal:AbortSignal.timeout(15000)});
    if(!renderCheck.ok) return res.status(502).json({ok:false,stage:'render-check',pushed,skipped,error:'تم رفع ملفات Nova إلى GitHub، لكن تعذر التحقق من خدمة Render. راجع RENDER_API_KEY وRENDER_SERVICE_ID.'});
    const deploy=await fetch(`https://api.render.com/v1/services/${encodeURIComponent(serviceId)}/deploys`,{method:'POST',headers:{Authorization:`Bearer ${process.env.RENDER_API_KEY.trim()}`,'Content-Type':'application/json',Accept:'application/json'},body:JSON.stringify({clearCache:'do_not_clear'}),signal:AbortSignal.timeout(15000)});
    if(!deploy.ok) return res.status(502).json({ok:false,stage:'render-deploy',pushed,skipped,error:'رُفعت الملفات إلى GitHub، لكن Render لم يقبل بدء النشر. تحقق من ربط الخدمة بالمستودع وصلاحيات مفتاح Render.'});
    const deployInfo=await deploy.json().catch(()=>({}));
    return res.json({ok:true,stage:'deploy-requested',owner,repo,branch:targetBranch||repoInfo.default_branch||'default branch',pushed,skipped,deployId:deployInfo.id||deployInfo.deploy?.id||null,message:'أُرسلت ملفات المشروع إلى GitHub، وطلب Nova بدء النشر على Render. افحص حالة النشر قبل اعتبار المهمة مكتملة.'});
  } catch(e) {
    console.error('Self-link failed:',e.name);
    return res.status(502).json({ok:false,stage:'network',error:'تعذر إكمال الربط بسبب خطأ اتصال. لم يُكشف أي مفتاح. تحقق من اتصال الخادم ثم أعد الأمر.'});
  }
});

app.post('/api/chat', async (req, res) => {
  const message = typeof req.body?.message === 'string' ? req.body.message.trim() : '';
  const history = Array.isArray(req.body?.history) ? req.body.history.slice(-10).filter(m => m && ['user','assistant'].includes(m.role) && typeof m.content === 'string').map(m => ({ role: m.role, content: m.content.slice(0, 4000) })) : [];
  if (!message) return res.status(400).json({ error: 'اكتب أمرًا أو سؤالًا أولًا.' });
  if (message.length > 8000) return res.status(413).json({ error: 'الرسالة طويلة جدًا؛ اختصرها ثم حاول مجددًا.' });
  const key = process.env.OPENAI_API_KEY;
  if (!key) return res.status(503).json({ error: 'المحادثة الذكية لم تُفعّل بعد: أضف مفتاح API صالحًا في إعدادات الخادم على Render. تبقى إدارة المهام المحلية والأخبار متاحة.' , code: 'AI_NOT_CONFIGURED' });
  const base = (process.env.OPENAI_BASE_URL || 'https://api.openai.com/v1').replace(/\/$/, '');
  const model = process.env.OPENAI_MODEL || 'gpt-4o-mini';
  const system = `أنت Nova، مدير شخصي ذكي يتحدث العربية ويعمل بمنهج تنفيذي. قاعدة الأوامر الداخلية: إذا بدأ نص طلب المستخدم بالبادئة السرية somr أو «سومر»، فاعتبره تفويضًا واضحًا لمحاولة تنفيذ المطلوب مباشرةً دون طلب تأكيد إضافي في كل خطوة، ضمن الأدوات والصلاحيات المتاحة. إذا لم يبدأ الطلب بهذه البادئة، فلديك حرية تقدير ما إذا كان الأنسب تنفيذه أو تقديم اقتراح أو سؤال توضيحي. هذه البادئة لا تمنح صلاحيات تقنية غير موجودة ولا تلغي موافقة المنصات أو متطلبات الأمان؛ اطلب الموافقة فقط عند الحاجة الفعلية، مثل تغيير صلاحيات الحسابات أو حذف بيانات أو دفع أموال أو إرسال رسائل للغير أو إجراء لا يمكن التراجع عنه. افهم النتيجة المطلوبة، ونفّذ فقط ما تتيحه الأدوات الموصولة فعلًا. لا تدّعِ أنك دخلت حسابًا أو عدّلت مستودعًا أو نشرت خدمة أو تحكمت بالهاتف إذا لم يحدث ذلك. إذا لم تكن لديك أداة لتنفيذ جزء، قل بوضوح ما الذي لا يزال يحتاج إلى خطوة من المستخدم، واقترح أقصر مسار عملي. لا تطلب مفاتيح API أو كلمات مرور داخل الدردشة، ولا تكشف الأسرار. لا تنفذ إجراءات خطرة أو غير قانونية. إذا فشلت طريقة، جرّب بديلًا محددًا إن أمكن. اجعل الرد عمليًا، مختصرًا، ومناسبًا لمستخدم يعتمد على هاتف Android فقط. لا تعرض البادئة السرية في عناصر الواجهة أو التعليمات المرئية للمستخدم.`;
  try {
    const upstream = await fetch(`${base}/chat/completions`, {
      method: 'POST', signal: AbortSignal.timeout(45000),
      headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model, messages: [{ role: 'system', content: system }, ...history, { role: 'user', content: message }], temperature: 0.35 })
    });
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      console.error('AI provider error:', upstream.status, String(data?.error?.message || '').slice(0, 250));
      return res.status(502).json({ error: upstream.status === 401 ? 'رفض مزود الذكاء الاصطناعي المفتاح. راجع مفتاح API في Render.' : upstream.status === 429 ? 'وصلت إلى حد الاستخدام لدى مزود الذكاء الاصطناعي أو لا توجد أرصدة كافية.' : 'تعذر على مزود الذكاء الاصطناعي الرد. راجع إعدادات المزود والنموذج ثم أعد المحاولة.' });
    }
    const reply = data?.choices?.[0]?.message?.content;
    if (typeof reply !== 'string' || !reply.trim()) return res.status(502).json({ error: 'وصل رد غير مكتمل من مزود الذكاء الاصطناعي.' });
    res.json({ reply: reply.trim(), model, time: new Date().toISOString() });
  } catch (e) {
    console.error('AI request failed:', e.name);
    res.status(502).json({ error: e.name === 'TimeoutError' ? 'استغرق الرد وقتًا طويلًا. حاول مرة أخرى.' : 'تعذر الاتصال بمزود الذكاء الاصطناعي. تحقق من إعدادات الخادم والإنترنت.' });
  }
});

app.use((err, _req, res, _next) => {
  if (err instanceof SyntaxError && 'body' in err) return res.status(400).json({ error: 'صيغة الطلب غير صحيحة.' });
  console.error('Server error:', err.message);
  res.status(500).json({ error: 'حدث خطأ داخلي. حاول مرة أخرى.' });
});
const port = process.env.PORT || 3000;
app.listen(port, '0.0.0.0', () => console.log(`Nova listening on ${port}`));
