Mobile Identity Finder v2
1. ZIP extract karein.
2. index.html ko Chrome mein kholen.
3. Apne/permission wale number ke liye confirmation tick karke public web search karein.
4. Apne authorized profile links add karein.
5. Search history, dark mode, Hindi/English, backup/restore available hain.

Privacy: App private platform databases access nahi karta. Search public web tak limited hai. Saved links/history local browser storage mein rehte hain. Backup file aapke device par download hoti hai.
