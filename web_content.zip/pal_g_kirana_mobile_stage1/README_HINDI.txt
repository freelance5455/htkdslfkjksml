PAL G KIRANA STORE — MOBILE STAGE 1
====================================
इस ZIP में चार अलग-अलग मोबाइल-फ्रेंडली स्क्रीन प्रोटोटाइप हैं:

1. customer.html  — ग्राहक ऐप स्क्रीन
2. admin.html     — एडमिन ऐप स्क्रीन
3. delivery.html  — डिलीवरी बॉय ऐप स्क्रीन
4. website.html   — अलग ग्राहक वेबसाइट स्क्रीन
5. assets/style.css — साझा Pink Theme

मोबाइल पर कैसे देखें:
- ZIP को Android फोन में डाउनलोड करके Extract करें।
- किसी HTML Viewer ऐप या फाइल मैनेजर के Browser/Open विकल्प से HTML फाइल खोलें।
- चारों फाइलें अलग-अलग खोलकर देखें।

महत्वपूर्ण:
यह UI prototype है, installable APK या live website नहीं।
अभी वास्तविक लॉगिन, cloud database, server-side Admin permissions,
payment gateway, live GPS, notifications, order sync और hosting जुड़े नहीं हैं।
डेमो उत्पाद/कीमतें वास्तविक दुकान की सूची नहीं हैं।
असली ऐप बनाने के लिए backend और Android build/signing प्रक्रिया करनी होगी।
Admin permissions केवल सर्वर पर लागू की जाएँगी; सिर्फ स्क्रीन के checkbox सुरक्षा नहीं देते।
