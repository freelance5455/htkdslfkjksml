# Pistol Duel — build APK (offline penuh)

Game ada di `www/index.html` (satu file, tanpa internet sama sekali).
Akun, koin, berlian, skill disimpan di penyimpanan internal aplikasi (localStorage WebView),
jadi data ada di HP dan tetap ada selama aplikasi tidak di-uninstall / datanya tidak dihapus.

## Cara 1 — tanpa install apa pun di laptop (GitHub Actions)
1. Buat repo baru di github.com, upload SEMUA isi folder ini (termasuk folder `.github`).
2. Buka tab **Actions → Build APK → Run workflow**.
3. Tunggu ±5–8 menit, lalu unduh **PistolDuel-APK** dari bagian Artifacts. Di dalamnya ada `app-debug.apk`.
4. Kirim ke HP, izinkan "install dari sumber tidak dikenal", lalu pasang.

## Cara 2 — di laptop (Node.js 20 + Java 17 + Android Studio/SDK)
```
npm install
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug        # Windows: gradlew.bat assembleDebug
```
APK ada di `android/app/build/outputs/apk/debug/app-debug.apk`.
(Atau `npx cap open android` lalu Build → Build APK(s) di Android Studio.)

## Update game
Ganti `www/index.html` dengan versi baru, lalu build ulang (Cara 1: push ulang; Cara 2: `npx cap sync android` + build).
Pasang APK baru DI ATAS yang lama (jangan uninstall) supaya data pemain tidak hilang.
Package name harus tetap `com.pistolduel.game`.

## Opsional
- Kunci orientasi: di `android/app/src/main/AndroidManifest.xml` tambahkan
  `android:screenOrientation="sensorLandscape"` (atau `portrait`) pada tag `<activity>`.
- Rilis ke Google Play butuh AAB bertanda tangan (`./gradlew bundleRelease`) dan akun developer.
