Gnani_xolo — Copyright-Safe Educational App

Entry point:
  index.html

Features:
  • Classes 1–12
  • Subject and class filters
  • Unit-wise original sample lessons
  • Search
  • Read-aloud
  • Free TXT downloads
  • Local study-time and progress tracking
  • Privacy/data-choice screen
  • Responsive mobile interface
  • No external JavaScript libraries required

Content policy:
All included lesson wording is original sample content. Do not insert scanned or copied textbooks,
papers, answer keys, images, music, logos, or other copyrighted material unless you own the rights or
have a suitable license.
