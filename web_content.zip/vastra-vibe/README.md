# Vastra Vibe website

Pages: Home, Shop (editorial gallery with quick view), product pages, Bag, Order form, Search, About and Find Us (with an enquiry form), all in one experimental typography-driven design. Orders and enquiries go to your WhatsApp: the customer fills in their details, WhatsApp opens with the message ready (every item in the bag is included), and they tap send.

## What is inside
- `index.html` : the website (design and pages)
- `config.js` : your business details (WhatsApp, phone, email, address, hours, Maps link, packing text)
- `products.js` : your products, prices, colours, sizes and descriptions
- `images/` : one photo per product
- `robots.txt`

## Open it
Double-click `index.html`. No installation is needed. The Shop page loads its display fonts (Anton, Space Mono, Permanent Marker) from Google Fonts, so it looks best with an internet connection; it still works without.

## Change your details (`config.js`)
- `whatsapp`: country code plus number, digits only. Currently `918796079147`.
- `phone`, `email`, `address`, `hours`: replace the `REPLACE_WITH_...` text. Anything left as a placeholder shows as "Not added yet" on the Find Us page.
- `mapsUrl`: your Google Maps link. `instagram`: your Instagram link (leave empty to hide it; it is then also hidden in the Shop footer).
- `cod`: set to `true` only if you really offer Cash on Delivery.
- `pack` and `packPts`: the packing text shown on the site. Edit it so it matches how you really pack orders.

## Change products (`products.js`)
- Prices are SAMPLE prices. Edit the number in each row.
- To add a product: copy a row, give it a new url-name, add `images/<url-name>.jpg`, then add its description in the `X` list further down.
- To replace a photo: keep the same file name and drop in a new portrait photo (about 640x800).
- `OVERSIZED` lists the products shown under the OVERSIZED filter on the Shop page.
- Shape values (`tee`, `shirt`, `jacket`, `jeans`) are only used as a drawing if a photo is missing.

## Put it online (free options)
- **Netlify:** open app.netlify.com/drop and drag this whole folder in.
- **GitHub Pages:** upload the folder to a repository, then Settings > Pages > deploy from the main branch.
- **Any web host:** upload everything to the public folder.

## Good to know
- The site cannot send WhatsApp messages by itself. It opens a ready message and the customer sends it.
- The bag is saved in the visitor's own browser. Nothing the customer types in the order form is stored anywhere.
- "Shipping information" and "Return policy" in the Shop footer open a WhatsApp chat with a ready question, because no policy text has been supplied.
- Product photos are product-only shots (no models). The hover effect on the Shop page zooms into the photo.
- PRICES ARE SAMPLES. Please confirm every price in `products.js` before going live.
- Email, address and business hours are hidden on the Find Us page until you fill them in `config.js`.
- The enquiry form on Find Us opens WhatsApp with the message ready; nothing is stored.
- Privacy Policy and Terms pages are not included.
