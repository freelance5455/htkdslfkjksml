# Vastra Vibe website

Pages: Home, Shop (editorial gallery with quick view), product pages, Bag, Order form, Search, About and Find Us (with an enquiry form), all in one experimental typography-driven design. Orders and enquiries go to your WhatsApp: the customer fills in their details, WhatsApp opens with the message ready (every item in the bag is included), and they tap send.

## What is inside
- `index.html` : the website (design and pages)
- `config.js` : your business details (WhatsApp, phone, email, address, hours, Maps link, packing text)
- `products.js` : the built-in product list (used until the database is connected, and for the home page pictures)
- `supabase-setup.sql` : database setup for the Admin Panel
- `images/` : one photo per product, plus the logo files `logo-lock.png` (header), `logo-full.png` (footer) and `logo-fav.png` (browser tab icon)
- `robots.txt`

## Open it
Double-click `index.html`. No installation is needed. The Shop page loads its display fonts (Anton, Space Mono, Permanent Marker) from Google Fonts, so it looks best with an internet connection; it still works without.

## Change your details (`config.js`)
- `whatsapp`: country code plus number, digits only. Currently `919616523728`.
- `phone`, `email`, `address`, `hours`: replace the `REPLACE_WITH_...` text. Anything left as a placeholder shows as "Not added yet" on the Find Us page.
- `mapsUrl`: your Google Maps link. `instagram`: your Instagram link (leave empty to hide it; it is then also hidden in the Shop footer).
- `cod`: set to `true` only if you really offer Cash on Delivery.
- `pack` and `packPts`: the packing text shown on the site. Edit it so it matches how you really pack orders.

## Change products (`products.js`)
- Prices are SAMPLE prices. Edit the number in each row.
- To add a product: copy a row, give it a new url-name, add `images/<url-name>.jpg`, then add its description in the `X` list further down.
- To replace a photo: keep the same file name and drop in a new portrait photo (about 640x800).
- `OVERSIZED` lists the products shown under the OVERSIZED filter on the Shop page.
- Shape values (`tee`, `shirt`, `jacket`, `jeans`) are only used as a drawing if a photo is missing.

## Put it online (free options)
- **Netlify:** open app.netlify.com/drop and drag this whole folder in.
- **GitHub Pages:** upload the folder to a repository, then Settings > Pages > deploy from the main branch.
- **Any web host:** upload everything to the public folder.

## Hidden Admin Panel (add, edit, hide and delete products)
The public website has no admin button. To open the panel:
1. Click the Vastra Vibe logo in the header 7 times in a row (within a few seconds of each other).
2. Enter the admin password (set in `config.js` as `adminPassword`; change it there any time).
3. Use Dashboard, Add New Product, Manage Products and Categories. "Back to Website" returns to the shop, and Logout exits the panel.

The panel only works once the database below is connected. Until then the website shows its built-in products.

## The database (already connected)
Your Supabase project **"Vastra Vibe"** (project ref `sdqfssqnzasoowygughj`, region Mumbai) is set up and connected: `config.js` already contains its URL and the public anon key, the tables `vv_products` and `vv_categories` hold your 20 starting products in 6 categories, Row Level Security is switched on, and the public `product-images` bucket stores uploaded photos. Just upload this folder to your hosting and open the Admin Panel.

What is saved: name, image, price, original price, category, description, sizes, stock status, visibility, featured and new/oversized labels. The public website and the Android app read this database every time they open, so changes appear for everyone as soon as the app or page is loaded with internet access. If the database cannot be reached, the shop shows a "try again" message instead of old data, so hidden products are never shown by mistake. To make the Android app use the database, rebuild the APK once from this ZIP.

`supabase-setup.sql` is only needed if you ever create a new Supabase project. It is safe to run more than once.

## Important: security of this simple version
This version has no Supabase login, as requested. The Project URL and anon key are inside the website's files, so **anyone who finds them can add, change or delete your products and categories and upload images**. The admin password only hides the screen; it does not protect the database. The website escapes all product text, so stored data cannot inject code into pages. For stronger protection later, add Supabase Auth and restrict the write policies in `supabase-setup.sql` to signed-in admins.

## Good to know
- The site cannot send WhatsApp messages by itself. It opens a ready message and the customer sends it.
- The bag is saved in the visitor's own browser. Nothing the customer types in the order form is stored anywhere.
- "Shipping information" and "Return policy" in the Shop footer open a WhatsApp chat with a ready question, because no policy text has been supplied.
- Product photos are product-only shots (no models). The hover effect on the Shop page zooms into the photo.
- PRICES ARE SAMPLES. Please confirm every price in `products.js` before going live.
- Email, address and business hours are hidden on the Find Us page until you fill them in `config.js`.
- The enquiry form on Find Us opens WhatsApp with the message ready; nothing is stored.
- Privacy Policy and Terms pages are not included.
