-- VASTRA VIBE database setup: products, categories and image storage.
-- Paste the whole file into Supabase SQL Editor and press Run.
-- It is safe to run again. It never deletes tables or data.
-- If the editor warns about DROP POLICY, confirm: it only replaces the access rules.
-- SECURITY: this is the simple no-login version. See README for details.

-- 1. Tables
create table if not exists public.vv_categories (id uuid primary key default gen_random_uuid(), name text not null unique check (length(trim(name)) between 1 and 40), created_at timestamptz not null default now());

create unique index if not exists vv_categories_name_ci on public.vv_categories (lower(name));

create table if not exists public.vv_products (id uuid primary key default gen_random_uuid(), seq bigint generated always as identity, slug text not null unique, name text not null check (length(trim(name)) > 0), image_url text, price numeric(10,2) not null check (price >= 0), original_price numeric(10,2) check (original_price is null or original_price >= 0), category_id uuid references public.vv_categories(id) on delete set null, description text, details text[] not null default '{}', sizes text[] not null default '{}', colors text[] not null default '{}', stock_status text not null default 'in-stock' check (stock_status in ('in-stock','out-of-stock')), visible boolean not null default true, featured boolean not null default false, is_new boolean not null default false, oversized boolean not null default false, created_at timestamptz not null default now(), updated_at timestamptz not null default now());

create index if not exists vv_products_category_idx on public.vv_products (category_id);

create index if not exists vv_products_visible_idx on public.vv_products (visible);

-- 2. Keep updated_at current
create or replace function public.vv_touch() returns trigger language plpgsql set search_path = '' as 'begin new.updated_at = now(); return new; end;';

create or replace trigger vv_products_touch before update on public.vv_products for each row execute function public.vv_touch();

-- 3. Access rules (simple public read and write, no login)
alter table public.vv_categories enable row level security;

alter table public.vv_products enable row level security;

grant select, insert, update, delete on public.vv_categories to anon, authenticated;

grant select, insert, update, delete on public.vv_products to anon, authenticated;

drop policy if exists vv_categories_all on public.vv_categories;

create policy vv_categories_all on public.vv_categories for all to anon, authenticated using (true) with check (true);

drop policy if exists vv_products_all on public.vv_products;

create policy vv_products_all on public.vv_products for all to anon, authenticated using (true) with check (true);

-- 4. Image storage bucket
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types) values ('product-images', 'product-images', true, 5242880, array['image/jpeg','image/png','image/webp']) on conflict (id) do update set public = true, file_size_limit = 5242880, allowed_mime_types = array['image/jpeg','image/png','image/webp'];

drop policy if exists vv_images_read on storage.objects;

create policy vv_images_read on storage.objects for select to anon, authenticated using (bucket_id = 'product-images');

drop policy if exists vv_images_insert on storage.objects;

create policy vv_images_insert on storage.objects for insert to anon, authenticated with check (bucket_id = 'product-images');

drop policy if exists vv_images_update on storage.objects;

create policy vv_images_update on storage.objects for update to anon, authenticated using (bucket_id = 'product-images') with check (bucket_id = 'product-images');

drop policy if exists vv_images_delete on storage.objects;

create policy vv_images_delete on storage.objects for delete to anon, authenticated using (bucket_id = 'product-images');

-- 5. Starting categories
insert into public.vv_categories (name) values ('Shirts'), ('T-Shirts'), ('Jackets'), ('Cargo Pants'), ('Jeans'), ('Track Pants') on conflict do nothing;

-- 6. Starting products (existing products are left untouched)
insert into public.vv_products (slug, name, image_url, price, category_id, description, details, sizes, colors, stock_status, visible, featured, is_new, oversized) values ('blue-striped-shirt', 'Blue Striped Shirt', 'images/blue-striped-shirt.jpg', 1099, (select id from public.vv_categories where name = 'Shirts'), 'A light blue shirt with fine vertical stripes and a soft, relaxed drape.'||chr(10)||chr(10)||'A shirt that moves easily from daytime to evening. Wear it buttoned up for a neater look, or open over a plain tee for something more relaxed.', array['Button-front with a classic collar','Fine vertical stripe pattern','Sleeves shown rolled for a relaxed look','Easy over a plain white tee']::text[], array['S','M','L','XL']::text[], array['Light Blue']::text[], 'in-stock', true, false, false, false) on conflict do nothing;

insert into public.vv_products (slug, name, image_url, price, category_id, description, details, sizes, colors, stock_status, visible, featured, is_new, oversized) values ('spider-graphic-tee', 'Spider Graphic Tee', 'images/spider-graphic-tee.jpg', 899, (select id from public.vv_categories where name = 'T-Shirts'), 'An oversized black tee with a bold red spider graphic on the chest.'||chr(10)||chr(10)||'A statement tee for days when you want your outfit to say something. The oversized shape keeps it comfortable and easy to wear on its own or under a jacket.', array['Oversized, boxy fit','Black base with a faded look','Red spider print on the front','Short sleeves and a round neck']::text[], array['S','M','L','XL','XXL']::text[], array['Black']::text[], 'in-stock', true, true, false, true) on conflict do nothing;

insert into public.vv_products (slug, name, image_url, price, category_id, description, details, sizes, colors, stock_status, visible, featured, is_new, oversized) values ('washed-black-overshirt', 'Washed Black Overshirt', 'images/washed-black-overshirt.jpg', 1499, (select id from public.vv_categories where name = 'Shirts'), 'A washed black overshirt with two chest pockets and a longer curved hem.'||chr(10)||chr(10)||'A shirt that moves easily from daytime to evening. Wear it buttoned up for a neater look, or open over a plain tee for something more relaxed.', array['Button-front with a collar','Two chest flap pockets','Curved hem, slightly longer at the back','Faded, washed-black finish']::text[], array['S','M','L','XL']::text[], array['Washed Black']::text[], 'in-stock', true, false, true, false) on conflict do nothing;

insert into public.vv_products (slug, name, image_url, price, category_id, description, details, sizes, colors, stock_status, visible, featured, is_new, oversized) values ('slate-casual-shirt', 'Slate Casual Shirt', 'images/slate-casual-shirt.jpg', 999, (select id from public.vv_categories where name = 'Shirts'), 'A slate-blue casual shirt in a muted, understated shade.'||chr(10)||chr(10)||'A shirt that moves easily from daytime to evening. Wear it buttoned up for a neater look, or open over a plain tee for something more relaxed.', array['Button-front with a classic collar','Single chest pocket','Long sleeves','Muted slate-blue colour']::text[], array['S','M','L','XL']::text[], array['Slate Blue']::text[], 'in-stock', true, false, false, false) on conflict do nothing;

insert into public.vv_products (slug, name, image_url, price, category_id, description, details, sizes, colors, stock_status, visible, featured, is_new, oversized) values ('brown-plaid-shirt', 'Brown Plaid Shirt', 'images/brown-plaid-shirt.jpg', 1299, (select id from public.vv_categories where name = 'Shirts'), 'A brown plaid shirt with a warm, layered check pattern.'||chr(10)||chr(10)||'A shirt that moves easily from daytime to evening. Wear it buttoned up for a neater look, or open over a plain tee for something more relaxed.', array['Button-front with a collar','Chest pocket','Long sleeves','Brown plaid pattern']::text[], array['S','M','L','XL']::text[], array['Brown']::text[], 'in-stock', true, true, false, false) on conflict do nothing;

insert into public.vv_products (slug, name, image_url, price, category_id, description, details, sizes, colors, stock_status, visible, featured, is_new, oversized) values ('flame-bomber-jacket', 'Flame Bomber Jacket', 'images/flame-bomber-jacket.jpg', 2499, (select id from public.vv_categories where name = 'Jackets'), 'A cream bomber-style jacket with black flame graphics running down the sleeves.'||chr(10)||chr(10)||'A layer you’ll reach for again and again. It sits easily over a tee or hoodie and gives a simple outfit an instant finish.', array['Front zip with ribbed collar and cuffs','Black flame graphics on the sleeves','Cream body with a small chest patch','Roomy, relaxed shape']::text[], array['S','M','L','XL']::text[], array['Cream']::text[], 'in-stock', true, false, true, false) on conflict do nothing;

insert into public.vv_products (slug, name, image_url, price, category_id, description, details, sizes, colors, stock_status, visible, featured, is_new, oversized) values ('washed-spider-tee', 'Washed Spider Tee', 'images/washed-spider-tee.jpg', 949, (select id from public.vv_categories where name = 'T-Shirts'), 'An oversized washed-black tee with a pale spider graphic.'||chr(10)||chr(10)||'A statement tee for days when you want your outfit to say something. The oversized shape keeps it comfortable and easy to wear on its own or under a jacket.', array['Oversized, boxy fit','Faded, acid-wash style finish','Spider graphic on the chest','Short sleeves and a round neck']::text[], array['S','M','L','XL','XXL']::text[], array['Washed Black']::text[], 'in-stock', true, false, false, true) on conflict do nothing;

insert into public.vv_products (slug, name, image_url, price, category_id, description, details, sizes, colors, stock_status, visible, featured, is_new, oversized) values ('blue-check-shirt', 'Blue Check Shirt', 'images/blue-check-shirt.jpg', 1199, (select id from public.vv_categories where name = 'Shirts'), 'A blue and white check shirt with a bold, layered plaid.'||chr(10)||chr(10)||'A shirt that moves easily from daytime to evening. Wear it buttoned up for a neater look, or open over a plain tee for something more relaxed.', array['Button-front with a collar','Chest pocket','Long sleeves','Blue, navy and white check']::text[], array['S','M','L','XL']::text[], array['Blue']::text[], 'in-stock', true, false, false, false) on conflict do nothing;

insert into public.vv_products (slug, name, image_url, price, category_id, description, details, sizes, colors, stock_status, visible, featured, is_new, oversized) values ('beige-check-shirt', 'Beige Check Shirt', 'images/beige-check-shirt.jpg', 1199, (select id from public.vv_categories where name = 'Shirts'), 'A stone-beige shirt with a soft tonal check.'||chr(10)||chr(10)||'A shirt that moves easily from daytime to evening. Wear it buttoned up for a neater look, or open over a plain tee for something more relaxed.', array['Button-front with a collar','Chest pocket','Long sleeves','Tonal beige and cream check']::text[], array['S','M','L','XL']::text[], array['Stone']::text[], 'in-stock', true, false, false, false) on conflict do nothing;

insert into public.vv_products (slug, name, image_url, price, category_id, description, details, sizes, colors, stock_status, visible, featured, is_new, oversized) values ('black-zip-jacket', 'Black Zip Jacket', 'images/black-zip-jacket.jpg', 2999, (select id from public.vv_categories where name = 'Jackets'), 'A black zip-front jacket with a sharp collar and clean lines.'||chr(10)||chr(10)||'A layer you’ll reach for again and again. It sits easily over a tee or hoodie and gives a simple outfit an instant finish.', array['Front zip','Turn-down collar','Plain black with no loud branding','Boxy, easy-to-layer shape']::text[], array['S','M','L','XL']::text[], array['Black']::text[], 'in-stock', true, false, false, false) on conflict do nothing;

insert into public.vv_products (slug, name, image_url, price, category_id, description, details, sizes, colors, stock_status, visible, featured, is_new, oversized) values ('black-cargo-pants', 'Black Cargo Pants', 'images/black-cargo-pants.jpg', 1599, (select id from public.vv_categories where name = 'Cargo Pants'), 'Black cargo pants with light contrast stitching and large side pockets.'||chr(10)||chr(10)||'Utility-style cargos with pockets that are as useful as they look. Balance them with a fitted tee or an oversized shirt.', array['High-rise, straight leg','Large cargo pockets on the sides','Light contrast stitching','Belt loops']::text[], array['28','30','32','34','36']::text[], array['Black']::text[], 'in-stock', true, true, false, false) on conflict do nothing;

insert into public.vv_products (slug, name, image_url, price, category_id, description, details, sizes, colors, stock_status, visible, featured, is_new, oversized) values ('grey-distressed-jeans', 'Grey Distressed Jeans', 'images/grey-distressed-jeans.jpg', 1499, (select id from public.vv_categories where name = 'Jeans'), 'Faded grey jeans with light distressing at the knees.'||chr(10)||chr(10)||'A pair that fits into your regular rotation. Wear it with a plain tee, a shirt worn open or a jacket, and finish with sneakers.', array['Straight leg','Faded grey wash','Light distressing','Five-pocket styling']::text[], array['28','30','32','34','36']::text[], array['Grey']::text[], 'in-stock', true, false, false, false) on conflict do nothing;

insert into public.vv_products (slug, name, image_url, price, category_id, description, details, sizes, colors, stock_status, visible, featured, is_new, oversized) values ('grey-track-pants', 'Grey Track Pants', 'images/grey-track-pants.jpg', 999, (select id from public.vv_categories where name = 'Track Pants'), 'Grey track pants with light piping down the sides.'||chr(10)||chr(10)||'Comfort-first track pants for everyday wear, travel and relaxed weekends. Pair them with a tee, a shirt or a jacket.', array['Elastic waistband','Contrast side piping','Relaxed, straight leg','Gathered hem']::text[], array['S','M','L','XL']::text[], array['Grey']::text[], 'in-stock', true, false, false, false) on conflict do nothing;

insert into public.vv_products (slug, name, image_url, price, category_id, description, details, sizes, colors, stock_status, visible, featured, is_new, oversized) values ('blue-cargo-jeans', 'Blue Cargo Jeans', 'images/blue-cargo-jeans.jpg', 1699, (select id from public.vv_categories where name = 'Jeans'), 'Mid-blue cargo jeans with utility pockets on the legs.'||chr(10)||chr(10)||'A pair that fits into your regular rotation. Wear it with a plain tee, a shirt worn open or a jacket, and finish with sneakers.', array['Straight leg','Cargo pockets on both sides','Classic mid-blue wash','Five-pocket styling']::text[], array['28','30','32','34','36']::text[], array['Blue']::text[], 'in-stock', true, true, false, false) on conflict do nothing;

insert into public.vv_products (slug, name, image_url, price, category_id, description, details, sizes, colors, stock_status, visible, featured, is_new, oversized) values ('light-wash-baggy-jeans', 'Light Wash Baggy Jeans', 'images/light-wash-baggy-jeans.jpg', 1499, (select id from public.vv_categories where name = 'Jeans'), 'Light wash baggy jeans with a wide, relaxed leg.'||chr(10)||chr(10)||'A pair that fits into your regular rotation. Wear it with a plain tee, a shirt worn open or a jacket, and finish with sneakers.', array['Baggy, wide leg','Light-wash faded finish','Mid-to-high rise','Five-pocket styling']::text[], array['28','30','32','34','36']::text[], array['Light Blue']::text[], 'in-stock', true, false, false, false) on conflict do nothing;

insert into public.vv_products (slug, name, image_url, price, category_id, description, details, sizes, colors, stock_status, visible, featured, is_new, oversized) values ('charcoal-cargo-pants', 'Charcoal Cargo Pants', 'images/charcoal-cargo-pants.jpg', 1699, (select id from public.vv_categories where name = 'Cargo Pants'), 'Charcoal cargo pants with big pockets on the sides.'||chr(10)||chr(10)||'Utility-style cargos with pockets that are as useful as they look. Balance them with a fitted tee or an oversized shirt.', array['Relaxed, straight leg','Large cargo pockets on both legs','Muted charcoal tone','Front patch pockets']::text[], array['28','30','32','34','36']::text[], array['Charcoal']::text[], 'in-stock', true, false, false, false) on conflict do nothing;

insert into public.vv_products (slug, name, image_url, price, category_id, description, details, sizes, colors, stock_status, visible, featured, is_new, oversized) values ('light-blue-wide-jeans', 'Light Blue Wide-Leg Jeans', 'images/light-blue-wide-jeans.jpg', 1599, (select id from public.vv_categories where name = 'Jeans'), 'Light blue wide-leg jeans in a clean, simple cut.'||chr(10)||chr(10)||'A pair that fits into your regular rotation. Wear it with a plain tee, a shirt worn open or a jacket, and finish with sneakers.', array['Wide leg','Light blue wash','Five-pocket styling','Clean finish with no distressing']::text[], array['28','30','32','34','36']::text[], array['Light Blue']::text[], 'in-stock', true, false, false, false) on conflict do nothing;

insert into public.vv_products (slug, name, image_url, price, category_id, description, details, sizes, colors, stock_status, visible, featured, is_new, oversized) values ('washed-black-wide-jeans', 'Washed Black Wide Jeans', 'images/washed-black-wide-jeans.jpg', 1699, (select id from public.vv_categories where name = 'Jeans'), 'Washed black wide-leg jeans with a faded, lived-in look.'||chr(10)||chr(10)||'A pair that fits into your regular rotation. Wear it with a plain tee, a shirt worn open or a jacket, and finish with sneakers.', array['Wide leg, long length','Fade from the top down to the hem','Five-pocket styling','Pairs with almost everything']::text[], array['28','30','32','34','36']::text[], array['Washed Black']::text[], 'in-stock', true, false, true, false) on conflict do nothing;

insert into public.vv_products (slug, name, image_url, price, category_id, description, details, sizes, colors, stock_status, visible, featured, is_new, oversized) values ('dark-blue-straight-jeans', 'Dark Blue Straight Jeans', 'images/dark-blue-straight-jeans.jpg', 1499, (select id from public.vv_categories where name = 'Jeans'), 'Dark blue straight-leg jeans, a dependable everyday pair.'||chr(10)||chr(10)||'A pair that fits into your regular rotation. Wear it with a plain tee, a shirt worn open or a jacket, and finish with sneakers.', array['Straight leg','Deep dark-blue wash','Five-pocket styling','Easy to dress up or down']::text[], array['28','30','32','34','36']::text[], array['Dark Blue']::text[], 'in-stock', true, false, false, false) on conflict do nothing;

insert into public.vv_products (slug, name, image_url, price, category_id, description, details, sizes, colors, stock_status, visible, featured, is_new, oversized) values ('black-track-pants', 'Black Track Pants', 'images/black-track-pants.jpg', 999, (select id from public.vv_categories where name = 'Track Pants'), 'Black track pants with white piping curving down the legs.'||chr(10)||chr(10)||'Comfort-first track pants for everyday wear, travel and relaxed weekends. Pair them with a tee, a shirt or a jacket.', array['Drawstring elastic waist','Contrast white piping','Relaxed, wide leg','Made for everyday comfort']::text[], array['S','M','L','XL']::text[], array['Black']::text[], 'in-stock', true, false, true, false) on conflict do nothing;
