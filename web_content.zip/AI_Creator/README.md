# AI Creator — versão inicial

## O que está incluído
- Interface responsiva em português para desktop e celular.
- Painel inicial com ferramentas.
- Gerador local de sugestões de título, descrição e capítulos para e-book.
- Exportação de rascunho em `.txt`.
- Construtor de página de produto com exportação de arquivo `.html`.
- Gerador de texto promocional e ideias de produtos.
- Estilos e ícones próprios.

## Como executar
Requer Node.js instalado.
1. Extraia o ZIP.
2. Abra um terminal nesta pasta.
3. Execute `npm install`
4. Execute `npm run dev`
5. Abra o endereço local mostrado pelo Vite.

Para gerar a versão de produção: `npm run build` (o resultado fica em `dist/`).

## Limites importantes desta versão
Esta é uma primeira versão funcional da interface, com geração de textos por regras locais. Ela ainda NÃO chama um modelo de IA real, não cria PDF diagramado, não tem contas de usuário, banco de dados, pagamentos nem hospedagem automática. Para essas funções, integre um backend seguro a um provedor de IA, um serviço de geração de PDF, armazenamento, autenticação e uma plataforma de hospedagem. Nunca coloque chaves secretas de API no código frontend.
