const netInput = document.querySelector<HTMLInputElement>("#netAmount")!;
const methodSelect = document.querySelector<HTMLSelectElement>("#paymentMethod")!;
const installmentsField = document.querySelector<HTMLDivElement>("#installmentsField")!;
const installmentsSelect = document.querySelector<HTMLSelectElement>("#installments")!;
const rateInput = document.querySelector<HTMLInputElement>("#feeRate")!;
const grossOutput = document.querySelector<HTMLElement>("#grossAmount")!;
const netSummary = document.querySelector<HTMLElement>("#netSummary")!;
const feeOutput = document.querySelector<HTMLElement>("#feeAmount")!;
const installmentOutput = document.querySelector<HTMLElement>("#installmentAmount")!;
const errorOutput = document.querySelector<HTMLDivElement>("#errorMessage")!;
const copyButton = document.querySelector<HTMLButtonElement>("#copyButton")!;
const copyStatus = document.querySelector<HTMLElement>("#copyStatus")!;

const currency = (amount: number): string =>
  amount.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

function suggestedRate(method: string): string {
  // Sugestões meramente ilustrativas; substitua pela taxa real do seu plano.
  if (method === "debit") return "1.99";
  if (method === "credit") return "4.99";
  return "5.59";
}

function calculate(): void {
  const net = Number(netInput.value);
  const rate = Number(rateInput.value);
  const method = methodSelect.value;
  const count = Number(installmentsSelect.value);

  installmentsField.classList.toggle("hidden", method !== "installments");
  errorOutput.classList.add("hidden");
  copyStatus.textContent = "";

  if (!Number.isFinite(net) || net <= 0) {
    showError("Informe um valor líquido maior que zero.");
    return;
  }
  if (!Number.isFinite(rate) || rate < 0 || rate >= 100) {
    showError("Informe uma taxa entre 0% e menos de 100%.");
    return;
  }

  // Se a taxa é descontada como percentual do valor bruto:
  // líquido = bruto × (1 − taxa); portanto bruto = líquido ÷ (1 − taxa).
  const gross = net / (1 - rate / 100);
  const fee = gross - net;

  grossOutput.textContent = currency(gross);
  netSummary.textContent = currency(net);
  feeOutput.textContent = currency(fee);
  installmentOutput.textContent = method === "installments"
    ? `${count}x de ${currency(gross / count)}`
    : "—";
}

function showError(message: string): void {
  errorOutput.textContent = message;
  errorOutput.classList.remove("hidden");
  grossOutput.textContent = "—";
  netSummary.textContent = "—";
  feeOutput.textContent = "—";
  installmentOutput.textContent = "—";
}

methodSelect.addEventListener("change", () => {
  rateInput.value = suggestedRate(methodSelect.value);
  calculate();
});
netInput.addEventListener("input", calculate);
rateInput.addEventListener("input", calculate);
installmentsSelect.addEventListener("change", calculate);

copyButton.addEventListener("click", async () => {
  const summary = [
    "Resumo da cobrança",
    `Valor líquido desejado: ${netSummary.textContent}`,
    `Taxa informada: ${rateInput.value}%`,
    `Taxa estimada em reais: ${feeOutput.textContent}`,
    `Total a cobrar: ${grossOutput.textContent}`,
    `Forma de pagamento: ${methodSelect.options[methodSelect.selectedIndex].text}`,
    ...(methodSelect.value === "installments" ? [`Parcelamento: ${installmentOutput.textContent}`] : []),
    "Estimativa: confirme a taxa real no PagBank."
  ].join("\n");

  try {
    await navigator.clipboard.writeText(summary);
    copyStatus.textContent = "Resumo copiado!";
  } catch {
    copyStatus.textContent = "Não foi possível copiar automaticamente. Selecione os valores e copie manualmente.";
  }
});

calculate();
