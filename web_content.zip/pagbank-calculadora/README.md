# Calculadora PagBank — versão Android

Projeto em HTML, CSS e TypeScript preparado para ser empacotado como aplicativo Android usando Capacitor.

## Gerar o APK localmente

Você precisa de Node.js 22, Java 21 e Android SDK/Android Studio configurados.

```bash
npm install
npm run build
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

No Windows, execute `gradlew.bat assembleDebug` em vez de `./gradlew`.

APK debug gerado em:
`android/app/build/outputs/apk/debug/app-debug.apk`

## Gerar o APK automaticamente pelo GitHub

1. Envie o conteúdo deste projeto para um repositório GitHub.
2. Abra a aba **Actions**.
3. Escolha **Build Android APK** e clique em **Run workflow** (ou envie para a branch main/master).
4. Quando terminar, abra a execução e baixe o artefato `calculadora-pagbank-apk`.
5. Extraia o ZIP do artefato para obter `app-debug.apk`.

## Sobre a aplicação

- ID Android: `br.com.calculadorapagbank.app`
- Nome: Calculadora PagBank
- Os cálculos funcionam localmente/offline depois de instalado.
- As taxas iniciais são apenas exemplos editáveis; substitua pela taxa exata do seu plano PagBank.
- O app não é oficial nem afiliado ao PagBank e não consulta sua conta.
