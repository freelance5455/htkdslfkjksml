import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'br.com.calculadorapagbank.app',
  appName: 'Calculadora PagBank',
  webDir: 'dist',
  bundledWebRuntime: false,
  android: { backgroundColor: '#f3f7f4' }
};

export default config;
