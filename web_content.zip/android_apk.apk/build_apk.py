#!/usr/bin/env python3
"""
MetaFlow Automator - Android APK Builder & Assistant
"""
import os
import sys
import subprocess
import shutil

PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))

def check_environment():
    print("=" * 60)
    print("⚡ MetaFlow Automator - Android APK Build Assistant")
    print("=" * 60)
    
    java_found = shutil.which("java") is not None
    gradle_found = shutil.which("gradle") is not None
    adb_found = shutil.which("adb") is not None
    
    print(f"Java Runtime:     {'✅ Available' if java_found else '❌ Not found'}")
    print(f"Gradle:           {'✅ Available' if gradle_found else '⚠️  Not in PATH (Android Studio can build)'}")
    print(f"Android ADB:      {'✅ Available' if adb_found else '⚠️  Not in PATH'}")
    print("-" * 60)
    
    if gradle_found:
        print("🔨 Found local Gradle! Attempting command line build...")
        try:
            subprocess.run(["gradle", "assembleDebug"], cwd=PROJECT_DIR, check=True)
            print("\n🎉 Build successful! Output APK located at:")
            print(os.path.join(PROJECT_DIR, "app", "build", "outputs", "apk", "debug", "app-debug.apk"))
            return
        except Exception as e:
            print(f"Gradle build encountered an issue: {e}")
    
    print("\n💡 HOW TO BUILD & RUN THE APK:")
    print("1. Method 1 (Android Studio - Recommended & Fastest):")
    print(f"   - Open Android Studio -> Click 'Open'")
    print(f"   - Select this folder: {PROJECT_DIR}")
    print("   - Click 'Build' -> 'Build Bundle(s) / APK(s)' -> 'Build APK(s)'.")
    print("   - You will get 'app-debug.apk' ready to install on your Android device!\n")
    print("2. Method 2 (Install to connected phone via ADB):")
    print("   - Connect phone via USB with USB Debugging enabled.")
    print("   - Run: adb install app-debug.apk\n")
    print("=" * 60)

if __name__ == "__main__":
    check_environment()
