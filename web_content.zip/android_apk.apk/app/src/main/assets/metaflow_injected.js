// ==UserScript==
// @name         MetaFlow Mobile Automator Pro
// @namespace    https://metaflow.app/
// @version      3.8.0
// @description  Automated Meta account registration & disposable mail OTP verification for all mobile browsers (Android / iOS)
// @author       MetaFlow Team
// @match        *://auth.meta.com/*
// @grant        GM_xmlhttpRequest
// @grant        GM_setValue
// @grant        GM_getValue
// @grant        GM_setClipboard
// @run-at       document-end
// ==/UserScript==

(function () {
  'use strict';

  // Prevent multiple injections
  if (window._metaflowMobileInjected) {
    console.log('[MetaFlow Mobile] Already injected.');
    return;
  }
  window._metaflowMobileInjected = true;

  console.log('[MetaFlow Mobile] 🚀 Initializing MetaFlow Mobile Automator v3.8.0...');

  // ==========================================
  // 1. DATA & CONSTANTS
  // ==========================================
  const REALISTIC_FIRST_NAMES = [
    "James", "Michael", "Robert", "David", "William", "Richard", "Joseph", "Thomas", "Charles", "Daniel",
    "Matthew", "Anthony", "Mark", "Donald", "Steven", "Paul", "Andrew", "Joshua", "Kenneth", "Kevin",
    "Brian", "George", "Timothy", "Ronald", "Jason", "Edward", "Jeffrey", "Ryan", "Jacob", "Gary",
    "Nicholas", "Eric", "Jonathan", "Stephen", "Larry", "Justin", "Scott", "Brandon", "Benjamin", "Samuel",
    "Emma", "Olivia", "Ava", "Sophia", "Isabella", "Mia", "Charlotte", "Amelia", "Harper", "Evelyn"
  ];

  const REALISTIC_LAST_NAMES = [
    "Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Rodriguez", "Martinez",
    "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson", "Thomas", "Taylor", "Moore", "Jackson", "Martin",
    "Lee", "Perez", "Thompson", "White", "Harris", "Sanchez", "Clark", "Ramirez", "Lewis", "Robinson"
  ];

  const DEFAULT_AVATAR_BASE64 = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEASABIAAD/2wBDAP//////////////////////////////////////////////////////////////////////////////////////wgALCAABAAEBAREA/8QAFBABAAAAAAAAAAAAAAAAAAAAAP/aAAgBAQABPxA=";

  function getRandomItem(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
  }

  // ==========================================
  // 2. UNIFIED STORAGE WRAPPER (Local & GM)
  // ==========================================
  const Storage = {
    get: function (keys) {
      const result = {};
      const keyList = Array.isArray(keys) ? keys : [keys];
      keyList.forEach(k => {
        try {
          const val = localStorage.getItem('metaflow_' + k);
          result[k] = val !== null ? JSON.parse(val) : undefined;
        } catch (e) {
          result[k] = undefined;
        }
      });
      return result;
    },
    set: function (obj) {
      Object.entries(obj).forEach(([k, v]) => {
        try {
          localStorage.setItem('metaflow_' + k, JSON.stringify(v));
        } catch (e) { }
      });
    },
    getAccountsVault: function () {
      try {
        const raw = localStorage.getItem('metaflow_vault_accounts');
        return raw ? JSON.parse(raw) : [];
      } catch (e) {
        return [];
      }
    },
    saveAccountToVault: function (account) {
      const list = Storage.getAccountsVault();
      list.unshift(account);
      try {
        localStorage.setItem('metaflow_vault_accounts', JSON.stringify(list));
      if (window.AndroidBridge && typeof window.AndroidBridge.saveAccount === 'function') {
        try {
          window.AndroidBridge.saveAccount(account.email, account.password, account.timestamp);
          window.AndroidBridge.vibratePhone(250);
        } catch(e) {}
      }
      } catch (e) { }
    }
  };

  // ==========================================
  // 3. CROSS-PLATFORM NETWORK REQUESTER
  // ==========================================
  async function networkRequest(options) {
    const { url, method = 'GET', headers = {}, body = null } = options;

    // 0. Try Android Native Bridge if running in APK
    if (window.AndroidBridge && typeof window.AndroidBridge.nativeHttp === 'function') {
      try {
        const raw = window.AndroidBridge.nativeHttp(url, method);
        let data = null;
        try { data = JSON.parse(raw); } catch(e){}
        return { ok: true, status: 200, data, text: raw };
      } catch(e) {}
    }

    // 1. Try Tampermonkey GM_xmlhttpRequest if available (CORS bypass)
    if (typeof GM_xmlhttpRequest === 'function') {
      return new Promise((resolve, reject) => {
        GM_xmlhttpRequest({
          method,
          url,
          headers,
          data: body,
          onload: function (res) {
            try {
              const data = JSON.parse(res.responseText);
              resolve({ ok: res.status >= 200 && res.status < 300, status: res.status, data, text: res.responseText });
            } catch (e) {
              resolve({ ok: res.status >= 200 && res.status < 300, status: res.status, data: null, text: res.responseText });
            }
          },
          onerror: function (err) {
            reject(err);
          }
        });
      });
    }

    // 2. Fallback to standard fetch (Direct or via public CORS proxy if blocked)
    try {
      const fetchOpts = {
        method,
        headers: { 'Accept': 'application/json', ...headers },
        body: body ? (typeof body === 'string' ? body : JSON.stringify(body)) : undefined
      };
      let res = await fetch(url, fetchOpts);
      let text = await res.text();
      let data = null;
      try { data = JSON.parse(text); } catch (e) { }
      return { ok: res.ok, status: res.status, data, text };
    } catch (directErr) {
      console.warn('[MetaFlow Network] Direct fetch failed, attempting resilient proxy:', directErr.message);
      try {
        const proxyUrl = 'https://api.allorigins.win/raw?url=' + encodeURIComponent(url);
        const pRes = await fetch(proxyUrl);
        const text = await pRes.text();
        let data = null;
        try { data = JSON.parse(text); } catch (e) { }
        return { ok: pRes.ok, status: pRes.status, data, text };
      } catch (proxyErr) {
        throw new Error('Network request failed: ' + directErr.message);
      }
    }
  }

  // ==========================================
  // 4. MOBILE DISPOSABLE MAIL & OTP ENGINE
  // ==========================================
  const MobileMailEngine = {
    // Generate new email address
    createMail: async function (provider) {
      console.log(`[MetaFlow Mail] Generating email via provider: ${provider}...`);

      // Provider 1: Guerrilla Mail (100% CORS-friendly wildcard *, 0 config)
      if (provider === 'guerrillamail') {
        try {
          const res = await networkRequest({
            url: 'https://api.guerrillamail.com/ajax.php?f=get_email_address&ip=127.0.0.1&agent=MetaFlowMobile'
          });
          if (res.data && res.data.email_addr) {
            Storage.set({
              current_mail: res.data.email_addr,
              guerrilla_sid: res.data.sid_token,
              mail_provider: 'guerrillamail'
            });
            return res.data.email_addr;
          }
        } catch (e) {
          console.warn('[MetaFlow Mail] Guerrilla live endpoint failed, creating fallback:', e);
        }
        const rand = Math.floor(100000000000 + Math.random() * 900000000000);
        const email = `user${rand}@sharklasers.com`;
        Storage.set({ current_mail: email, guerrilla_sid: 'sid_' + rand, mail_provider: 'guerrillamail' });
        return email;
      }

      // Provider 2: Temp-Mail.lol
      if (provider === 'tempmail_lol') {
        try {
          const res = await networkRequest({
            url: 'https://api.tempmail.lol/v2/inbox/create'
          });
          if (res.data && res.data.address && res.data.token) {
            Storage.set({
              current_mail: res.data.address,
              tempmail_token: res.data.token,
              mail_provider: 'tempmail_lol'
            });
            return res.data.address;
          }
        } catch (e) {
          console.warn('[MetaFlow Mail] TempMail.lol error:', e);
        }
      }

      // Provider 3: Mail.tm Hydra API
      if (provider === 'mail_tm') {
        try {
          const dRes = await networkRequest({ url: 'https://api.mail.tm/domains' });
          const domains = dRes.data?.['hydra:member'] || [];
          const domain = domains[0]?.domain || 'maxxspace.com';
          const rand = Math.floor(100000000000 + Math.random() * 900000000000);
          const email = `user${rand}@${domain}`;
          const pass = 'Pass' + Math.random().toString(36).substring(2, 9);

          const cRes = await networkRequest({
            url: 'https://api.mail.tm/accounts',
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: { address: email, password: pass }
          });

          const tRes = await networkRequest({
            url: 'https://api.mail.tm/token',
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: { address: email, password: pass }
          });

          if (tRes.data && tRes.data.token) {
            Storage.set({
              current_mail: email,
              mail_tm_token: tRes.data.token,
              mail_provider: 'mail_tm'
            });
            return email;
          }
        } catch (e) {
          console.warn('[MetaFlow Mail] Mail.tm creation error:', e);
        }
      }

      // Default fallback to Guerrilla Mail
      return MobileMailEngine.createMail('guerrillamail');
    },

    // Poll for OTP verification code
    pollOtp: async function (provider, targetEmail, maxAttempts = 35) {
      console.log(`[MetaFlow OTP] Polling OTP for: ${targetEmail} (${provider})...`);

      for (let attempt = 1; attempt <= maxAttempts; attempt++) {
        const state = Storage.get(['auto_click_active']);
        if (state.auto_click_active === false) {
          console.log('[MetaFlow OTP] Polling stopped by user');
          return null;
        }

        try {
          let foundOtp = null;

          // Guerrilla Mail Poll
          if (provider === 'guerrillamail') {
            const st = Storage.get(['guerrilla_sid']);
            const sid = st.guerrilla_sid || '';
            const res = await networkRequest({
              url: `https://api.guerrillamail.com/ajax.php?f=check_email&seq=0&sid_token=${sid}`
            });
            const list = res.data?.list || [];
            for (const m of list) {
              const text = [m.mail_subject, m.mail_excerpt].filter(Boolean).join(" ");
              let matches = text.match(/\b\d{6}\b/g);
              if (!matches && m.mail_id) {
                const fRes = await networkRequest({
                  url: `https://api.guerrillamail.com/ajax.php?f=fetch_email&email_id=${m.mail_id}&sid_token=${sid}`
                });
                const fBody = [fRes.data?.mail_subject, fRes.data?.mail_body, fRes.data?.mail_excerpt].filter(Boolean).join(" ");
                matches = fBody.match(/\b\d{6}\b/g);
              }
              if (matches && matches.length > 0) {
                foundOtp = matches.find(num => num !== '141823');
                if (foundOtp) break;
              }
            }
          }

          // Temp-Mail.lol Poll
          else if (provider === 'tempmail_lol') {
            const st = Storage.get(['tempmail_token']);
            const token = st.tempmail_token || '';
            const res = await networkRequest({
              url: `https://api.tempmail.lol/v2/inbox?token=${token}`
            });
            const emails = res.data?.emails || [];
            for (const em of emails) {
              const full = [em.subject, em.body, em.html].filter(Boolean).join(" ");
              const matches = full.match(/\b\d{6}\b/g);
              if (matches && matches.length > 0) {
                foundOtp = matches.find(num => num !== '141823');
                if (foundOtp) break;
              }
            }
          }

          // Mail.tm Poll
          else if (provider === 'mail_tm') {
            const st = Storage.get(['mail_tm_token']);
            const token = st.mail_tm_token || '';
            const res = await networkRequest({
              url: 'https://api.mail.tm/messages',
              headers: { 'Authorization': `Bearer ${token}` }
            });
            const msgs = res.data?.['hydra:member'] || [];
            for (const msg of msgs) {
              const fRes = await networkRequest({
                url: `https://api.mail.tm/messages/${msg.id}`,
                headers: { 'Authorization': `Bearer ${token}` }
              });
              const full = [fRes.data?.subject, fRes.data?.intro, fRes.data?.text].filter(Boolean).join(" ");
              const matches = full.match(/\b\d{6}\b/g);
              if (matches && matches.length > 0) {
                foundOtp = matches.find(num => num !== '141823');
                if (foundOtp) break;
              }
            }
          }

          if (foundOtp) {
            console.log(`[MetaFlow OTP] ✅ Verified OTP found: ${foundOtp}`);
            return foundOtp;
          }
        } catch (pollErr) {
          console.warn(`[MetaFlow OTP] Attempt ${attempt} check failed:`, pollErr.message);
        }

        // Wait 2.2 seconds before next attempt
        await new Promise(r => setTimeout(r, 2200));
      }

      console.warn('[MetaFlow OTP] Polling timed out with no OTP.');
      return null;
    }
  };

  // ==========================================
  // 5. DOM & REACT SYNTHETIC EVENT HELPERS
  // ==========================================
  function setReactInputValue(inputElement, value) {
    if (!inputElement) return;
    inputElement.focus();
    inputElement.click();

    const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")?.set;
    if (nativeSetter) {
      nativeSetter.call(inputElement, value);
    } else {
      inputElement.value = value;
    }

    try {
      document.execCommand("selectAll", false, null);
      document.execCommand("insertText", false, value);
    } catch (e) { }

    inputElement.dispatchEvent(new Event("input", { bubbles: true }));
    inputElement.dispatchEvent(new Event("change", { bubbles: true }));
    try {
      inputElement.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: value }));
    } catch (e) { }
    inputElement.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, key: "Enter" }));
    inputElement.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: "Enter" }));
    inputElement.blur();
  }

  function executeMetaUltraClick(element) {
    if (!element) return;
    try {
      element.scrollIntoView({ behavior: "smooth", block: "center" });
    } catch (e) { }

    const rect = element.getBoundingClientRect();
    const clientX = rect.left + rect.width / 2;
    const clientY = rect.top + rect.height / 2;

    const eventOptions = {
      bubbles: true,
      cancelable: true,
      view: window,
      clientX: clientX,
      clientY: clientY,
      button: 0,
      buttons: 1
    };

    element.dispatchEvent(new PointerEvent("pointerdown", { ...eventOptions, pointerId: 1, pointerType: "touch", isPrimary: true }));
    element.dispatchEvent(new MouseEvent("mousedown", eventOptions));
    element.dispatchEvent(new PointerEvent("pointerup", { ...eventOptions, pointerId: 1, pointerType: "touch", isPrimary: true, buttons: 0 }));
    element.dispatchEvent(new MouseEvent("mouseup", { ...eventOptions, buttons: 0 }));
    element.dispatchEvent(new MouseEvent("click", { ...eventOptions, buttons: 0 }));

    if (typeof element.click === "function") {
      element.click();
    }
  }

  function dismissOopsModal() {
    const dialogs = Array.from(document.querySelectorAll("div[role='dialog'], div.uiLayer"));
    for (let dialog of dialogs) {
      const text = (dialog.innerText || "").toLowerCase();
      if (text.includes("oops") || text.includes("error") || text.includes("something went wrong") || text.includes("try again")) {
        const btn = dialog.querySelector("button, div[role='button']");
        if (btn) {
          executeMetaUltraClick(btn);
          return true;
        }
      }
    }
    return false;
  }

  function findUseEmailAddressButton() {
    const candidates = Array.from(document.querySelectorAll("div[role='button'], button, a, span"));
    return candidates.find(el => {
      const txt = (el.innerText || el.textContent || "").toLowerCase().trim();
      return txt.includes("use mobile number or email address") ||
        txt.includes("continue with email") ||
        txt.includes("set up with email") ||
        txt.includes("sign up with email");
    });
  }

  function findEmailOrContactInput() {
    const inputs = Array.from(document.querySelectorAll("input:not([type='hidden']):not([type='checkbox']):not([type='radio'])"));
    return inputs.find(inp => {
      const name = (inp.getAttribute("name") || "").toLowerCase();
      const type = (inp.getAttribute("type") || "").toLowerCase();
      const placeholder = (inp.getAttribute("placeholder") || "").toLowerCase();
      const aria = (inp.getAttribute("aria-label") || "").toLowerCase();
      return type === "email" || name.includes("email") || name.includes("contact") || placeholder.includes("email") || aria.includes("email");
    });
  }

  function findNameInputs() {
    return Array.from(document.querySelectorAll("input:not([type='hidden']):not([type='checkbox']):not([type='radio'])")).filter(inp => {
      const name = (inp.getAttribute("name") || "").toLowerCase();
      const placeholder = (inp.getAttribute("placeholder") || "").toLowerCase();
      const aria = (inp.getAttribute("aria-label") || "").toLowerCase();
      return name.includes("first") || name.includes("last") || placeholder.includes("first") || placeholder.includes("last") || aria.includes("first") || aria.includes("last");
    });
  }

  function findBirthdayYearTarget() {
    const selects = Array.from(document.querySelectorAll("select"));
    const yearSelect = selects.find(s => {
      const aria = (s.getAttribute("aria-label") || "").toLowerCase();
      const name = (s.getAttribute("name") || "").toLowerCase();
      return aria.includes("year") || name.includes("year") || Array.from(s.options).some(o => o.value === "2002");
    });
    if (yearSelect) return yearSelect;

    const comboboxes = Array.from(document.querySelectorAll("div[role='combobox'], input[role='combobox'], [aria-haspopup='listbox']"));
    const yearBox = comboboxes.find(cb => {
      const aria = (cb.getAttribute("aria-label") || "").toLowerCase();
      const txt = (cb.innerText || "").toLowerCase();
      return aria.includes("year") || txt.includes("year") || txt.includes("200");
    });
    return yearBox || null;
  }

  function selectMetaComboboxOption(combobox, year) {
    executeMetaUltraClick(combobox);
    const options = Array.from(document.querySelectorAll("div[role='option'], li[role='option'], div.uiContextualLayer div"));
    const match = options.find(o => (o.innerText || o.textContent || "").trim() === String(year));
    if (match) {
      executeMetaUltraClick(match);
      return true;
    }
    return false;
  }

  function findPasswordInput() {
    return document.querySelector("input[type='password']");
  }

  function findGenericContinueButton() {
    const candidates = Array.from(document.querySelectorAll("div[role='button'], button, a"));
    return candidates.find(b => {
      const txt = (b.innerText || b.textContent || "").toLowerCase().trim();
      return (txt === "next" || txt === "continue" || txt === "submit" || txt === "save" || txt === "done") &&
        b.getAttribute("aria-disabled") !== "true" && !b.hasAttribute("disabled");
    });
  }

  function findDarkBlueContinueButton() {
    const buttons = Array.from(document.querySelectorAll("div[role='button'], button"));
    return buttons.find(b => {
      const style = window.getComputedStyle(b);
      const bg = style.backgroundColor || "";
      const txt = (b.innerText || "").toLowerCase();
      return (bg.includes("rgb(0, 100") || bg.includes("rgb(24, 119") || bg.includes("rgb(0, 106") || bg.includes("rgb(0, 122") || bg.includes("rgb(0, 90")) &&
        (txt.includes("continue") || txt.includes("next") || txt.includes("finish") || txt.includes("done"));
    });
  }

  function isOtpScreenActive() {
    const text = (document.body ? document.body.innerText : "").toLowerCase();
    const hasOtpInput = !!document.querySelector("input[autocomplete='one-time-code'], input[inputmode='numeric']");
    return hasOtpInput || text.includes("enter the confirmation code") || text.includes("we sent a code to") || text.includes("confirm your account");
  }

  function isCaptchaScreenActive() {
    const text = (document.body ? document.body.innerText : "").toLowerCase();
    return text.includes("confirm that you're human") || text.includes("confirm you're human") || !!document.querySelector("iframe[src*='recaptcha'], #captcha-recaptcha");
  }

  function findLogoutButton() {
    const candidates = Array.from(document.querySelectorAll("a, div[role='button'], button, span"));
    return candidates.find(el => {
      const txt = (el.innerText || el.textContent || "").toLowerCase().trim();
      return txt === "log out" || txt === "logout" || txt.includes("log out of all accounts");
    });
  }

  function dataURLtoFile(dataurl, filename) {
    let arr = dataurl.split(","), mime = arr[0].match(/:(.*?);/)[1],
      bstr = atob(arr[1]), n = bstr.length, u8arr = new Uint8Array(n);
    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }
    return new File([u8arr], filename, { type: mime });
  }

  // ==========================================
  // 6. RESPONSIVE MOBILE TOUCH HUD UI
  // ==========================================
  function injectMobileHUD() {
    if (document.getElementById("metaflow-mobile-root")) return;

    const root = document.createElement("div");
    root.id = "metaflow-mobile-root";

    const style = document.createElement("style");
    style.id = "metaflow-mobile-styles";
    style.textContent = `
      #metaflow-mobile-root {
        position: fixed;
        bottom: 16px;
        right: 16px;
        z-index: 2147483647;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        font-size: 13px;
        color: #f8fafc;
        user-select: none;
        -webkit-user-select: none;
      }
      #metaflow-mobile-fab {
        display: flex;
        align-items: center;
        gap: 8px;
        background: linear-gradient(135deg, #4f46e5, #7c3aed);
        color: #fff;
        padding: 10px 16px;
        border-radius: 9999px;
        box-shadow: 0 10px 25px -5px rgba(79, 70, 229, 0.6), 0 0 15px rgba(124, 58, 237, 0.4);
        cursor: pointer;
        font-weight: 700;
        letter-spacing: 0.3px;
        transition: transform 0.2s ease, box-shadow 0.2s ease;
      }
      #metaflow-mobile-fab:active {
        transform: scale(0.95);
      }
      #metaflow-mobile-fab .dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: #22c55e;
        box-shadow: 0 0 8px #22c55e;
      }
      #metaflow-mobile-fab.stopped .dot {
        background: #ef4444;
        box-shadow: 0 0 8px #ef4444;
      }
      #metaflow-mobile-panel {
        display: none;
        position: fixed;
        bottom: 70px;
        right: 16px;
        left: 16px;
        max-width: 420px;
        margin: 0 auto;
        background: rgba(15, 23, 42, 0.96);
        backdrop-filter: blur(20px);
        -webkit-backdrop-filter: blur(20px);
        border: 1px solid rgba(99, 102, 241, 0.35);
        border-radius: 20px;
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.85), 0 0 25px rgba(99, 102, 241, 0.25);
        padding: 16px;
        box-sizing: border-box;
        animation: metaflowSlideUp 0.3s cubic-bezier(0.16, 1, 0.3, 1);
        max-height: 85vh;
        overflow-y: auto;
      }
      @keyframes metaflowSlideUp {
        from { opacity: 0; transform: translateY(20px) scale(0.95); }
        to { opacity: 1; transform: translateY(0) scale(1); }
      }
      .mf-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding-bottom: 12px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        margin-bottom: 12px;
      }
      .mf-title-group {
        display: flex;
        align-items: center;
        gap: 8px;
      }
      .mf-badge {
        background: linear-gradient(135deg, #6366f1, #a855f7);
        width: 26px;
        height: 26px;
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 800;
        font-size: 13px;
      }
      .mf-title {
        font-weight: 700;
        font-size: 14px;
        background: linear-gradient(90deg, #fff, #c7d2fe);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
      }
      .mf-close-btn {
        background: rgba(255, 255, 255, 0.1);
        border: none;
        color: #94a3b8;
        width: 28px;
        height: 28px;
        border-radius: 50%;
        font-size: 15px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
      }
      .mf-row {
        display: flex;
        gap: 8px;
        margin-bottom: 12px;
      }
      .mf-chip-group {
        display: flex;
        background: rgba(30, 41, 59, 0.7);
        padding: 3px;
        border-radius: 10px;
        width: 100%;
        border: 1px solid rgba(255, 255, 255, 0.05);
      }
      .mf-chip {
        flex: 1;
        padding: 6px 4px;
        font-size: 11px;
        font-weight: 600;
        text-align: center;
        border-radius: 8px;
        color: #94a3b8;
        cursor: pointer;
        transition: all 0.2s ease;
      }
      .mf-chip.active {
        background: #4f46e5;
        color: #fff;
        box-shadow: 0 2px 8px rgba(79, 70, 229, 0.4);
      }
      .mf-status-card {
        background: rgba(30, 41, 59, 0.5);
        border: 1px solid rgba(255, 255, 255, 0.06);
        border-radius: 12px;
        padding: 10px;
        margin-bottom: 12px;
      }
      .mf-status-row {
        display: flex;
        justify-content: space-between;
        margin-bottom: 4px;
        font-size: 11px;
      }
      .mf-status-label {
        color: #94a3b8;
      }
      .mf-status-val {
        font-weight: 600;
        color: #e2e8f0;
        max-width: 220px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .mf-btn-primary {
        width: 100%;
        padding: 11px;
        border: none;
        border-radius: 12px;
        font-weight: 700;
        font-size: 13px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        transition: transform 0.15s ease, filter 0.15s ease;
      }
      .mf-btn-start {
        background: linear-gradient(135deg, #10b981, #059669);
        color: #fff;
        box-shadow: 0 4px 15px rgba(16, 185, 129, 0.35);
      }
      .mf-btn-stop {
        background: linear-gradient(135deg, #ef4444, #dc2626);
        color: #fff;
        box-shadow: 0 4px 15px rgba(239, 68, 68, 0.35);
      }
      .mf-btn-vault {
        background: rgba(30, 41, 59, 0.8);
        color: #c7d2fe;
        border: 1px solid rgba(99, 102, 241, 0.3);
        margin-top: 8px;
      }
      .mf-logs {
        font-family: monospace;
        font-size: 10px;
        color: #94a3b8;
        background: #090d16;
        padding: 8px;
        border-radius: 8px;
        height: 70px;
        overflow-y: auto;
        margin-top: 10px;
        border: 1px solid rgba(255, 255, 255, 0.05);
      }
    `;

    document.head.appendChild(style);

    root.innerHTML = `
      <div id="metaflow-mobile-fab">
        <span class="dot"></span>
        <span id="mf-fab-text">⚡ MetaFlow (Idle)</span>
      </div>

      <div id="metaflow-mobile-panel">
        <div class="mf-header">
          <div class="mf-title-group">
            <div class="mf-badge">⚡</div>
            <div class="mf-title">MetaFlow Automator Pro</div>
          </div>
          <button class="mf-close-btn" id="mf-btn-close">✕</button>
        </div>

        <div style="font-size: 10px; color: #94a3b8; margin-bottom: 4px; font-weight: 600;">EMAIL PROVIDER</div>
        <div class="mf-row">
          <div class="mf-chip-group" id="mf-provider-chips">
            <div class="mf-chip active" data-provider="guerrillamail">Guerrilla Mail</div>
            <div class="mf-chip" data-provider="tempmail_lol">TempMail.lol</div>
            <div class="mf-chip" data-provider="mail_tm">Mail.tm</div>
          </div>
        </div>

        <div style="font-size: 10px; color: #94a3b8; margin-bottom: 4px; font-weight: 600;">BATCH TARGET</div>
        <div class="mf-row">
          <div class="mf-chip-group" id="mf-batch-chips">
            <div class="mf-chip active" data-batch="1">1 Account</div>
            <div class="mf-chip" data-batch="5">5 Accounts</div>
            <div class="mf-chip" data-batch="10">10 Accounts</div>
          </div>
        </div>

        <div class="mf-status-card">
          <div class="mf-status-row">
            <span class="mf-status-label">Active Step:</span>
            <span class="mf-status-val" id="mf-status-step" style="color:#60a5fa;">Ready</span>
          </div>
          <div class="mf-status-row">
            <span class="mf-status-label">Email:</span>
            <span class="mf-status-val" id="mf-status-email" style="color:#a78bfa;">(none)</span>
          </div>
          <div class="mf-status-row">
            <span class="mf-status-label">Last OTP:</span>
            <span class="mf-status-val" id="mf-status-otp" style="color:#34d399;">(waiting)</span>
          </div>
        </div>

        <button class="mf-btn-primary mf-btn-start" id="mf-btn-start">▶ START AUTOMATION</button>
        <button class="mf-btn-primary mf-btn-stop" id="mf-btn-stop" style="display:none;">⏹ STOP AUTOMATION</button>
        <button class="mf-btn-primary mf-btn-vault" id="mf-btn-vault">📂 Accounts Vault (<span id="mf-vault-count">0</span>)</button>

        <div class="mf-logs" id="mf-log-box">[System] MetaFlow Mobile ready. Tap START to begin.</div>
      </div>
    `;

    document.body.appendChild(root);

    // Event Listeners
    const fab = document.getElementById("metaflow-mobile-fab");
    const panel = document.getElementById("metaflow-mobile-panel");
    const closeBtn = document.getElementById("mf-btn-close");
    const startBtn = document.getElementById("mf-btn-start");
    const stopBtn = document.getElementById("mf-btn-stop");
    const vaultBtn = document.getElementById("mf-btn-vault");

    fab.addEventListener("click", () => {
      panel.style.display = panel.style.display === "block" ? "none" : "block";
    });

    closeBtn.addEventListener("click", () => {
      panel.style.display = "none";
    });

    // Provider Chip Clicks
    document.querySelectorAll("#mf-provider-chips .mf-chip").forEach(chip => {
      chip.addEventListener("click", () => {
        document.querySelectorAll("#mf-provider-chips .mf-chip").forEach(c => c.classList.remove("active"));
        chip.classList.add("active");
        Storage.set({ mail_provider: chip.dataset.provider });
        logMessage(`Provider selected: ${chip.dataset.provider}`);
      });
    });

    // Batch Chip Clicks
    document.querySelectorAll("#mf-batch-chips .mf-chip").forEach(chip => {
      chip.addEventListener("click", () => {
        document.querySelectorAll("#mf-batch-chips .mf-chip").forEach(c => c.classList.remove("active"));
        chip.classList.add("active");
        Storage.set({ remaining_runs: parseInt(chip.dataset.batch) });
        logMessage(`Batch count set: ${chip.dataset.batch}`);
      });
    });

    startBtn.addEventListener("click", () => {
      startAutomation();
    });

    stopBtn.addEventListener("click", () => {
      stopAutomation();
    });

    vaultBtn.addEventListener("click", () => {
      showVaultModal();
    });

    // Update vault count
    const vault = Storage.getAccountsVault();
    document.getElementById("mf-vault-count").textContent = vault.length;
  }

  function logMessage(msg) {
    console.log(`[MetaFlow Mobile] ${msg}`);
    const box = document.getElementById("mf-log-box");
    if (box) {
      const time = new Date().toLocaleTimeString().split(" ")[0];
      box.innerHTML += `<div>[${time}] ${msg}</div>`;
      box.scrollTop = box.scrollHeight;
    }
  }

  function updateMobileHUD(step, email, otp, isRunning) {
    const fabText = document.getElementById("mf-fab-text");
    const fab = document.getElementById("metaflow-mobile-fab");
    const stepEl = document.getElementById("mf-status-step");
    const emailEl = document.getElementById("mf-status-email");
    const otpEl = document.getElementById("mf-status-otp");
    const startBtn = document.getElementById("mf-btn-start");
    const stopBtn = document.getElementById("mf-btn-stop");

    if (fabText) fabText.textContent = isRunning ? `⚡ ${step || 'Running...'}` : `⚡ MetaFlow (Idle)`;
    if (fab) {
      if (isRunning) fab.classList.remove("stopped");
      else fab.classList.add("stopped");
    }
    if (stepEl && step) stepEl.textContent = step;
    if (emailEl && email) emailEl.textContent = email;
    if (otpEl && otp) otpEl.textContent = otp;

    if (startBtn && stopBtn) {
      startBtn.style.display = isRunning ? "none" : "flex";
      stopBtn.style.display = isRunning ? "flex" : "none";
    }
  }

  function showVaultModal() {
    const accounts = Storage.getAccountsVault();
    if (accounts.length === 0) {
      alert("No accounts in vault yet. Complete a registration run first!");
      return;
    }
    const txtList = accounts.map(a => `${a.email}:${a.password}`).join("\n");
    if (navigator.clipboard) {
      navigator.clipboard.writeText(txtList).then(() => {
        alert(`✅ Copied ${accounts.length} account(s) to clipboard!\n\nPreview:\n${accounts.slice(0, 3).map(a => a.email).join("\n")}${accounts.length > 3 ? "\n..." : ""}`);
      });
    } else {
      alert(`Vault Accounts (${accounts.length}):\n\n` + txtList);
    }
  }

  // ==========================================
  // 7. CORE REGISTRATION AUTOMATION LOOP
  // ==========================================
  let automationInterval = null;
  let isStepInProgress = false;

  function startAutomation() {
    const providerChip = document.querySelector("#mf-provider-chips .mf-chip.active");
    const provider = providerChip ? providerChip.dataset.provider : "guerrillamail";

    const batchChip = document.querySelector("#mf-batch-chips .mf-chip.active");
    const batchCount = batchChip ? parseInt(batchChip.dataset.batch) : 1;

    Storage.set({
      auto_click_active: true,
      mail_provider: provider,
      remaining_runs: batchCount,
      bot_step: "START",
      current_mail: "",
      current_otp: ""
    });

    updateMobileHUD("Starting...", null, null, true);
    logMessage(`Bot started! Provider: ${provider}, Batch: ${batchCount}`);

    // If not on auth.meta.com, redirect
    if (!window.location.href.includes("auth.meta.com")) {
      window.location.href = "https://auth.meta.com";
      return;
    }

    startLoop();
  }

  function stopAutomation() {
    Storage.set({
      auto_click_active: false,
      bot_step: "STOPPED"
    });
    if (automationInterval) {
      clearInterval(automationInterval);
      automationInterval = null;
    }
    updateMobileHUD("Stopped", null, null, false);
    logMessage("Bot stopped by user.");
  }

  function startLoop() {
    if (automationInterval) clearInterval(automationInterval);
    automationInterval = setInterval(runCycleStep, 650);
  }

  async function runCycleStep() {
    if (isStepInProgress) return;

    const state = Storage.get(["auto_click_active", "remaining_runs", "mail_provider", "current_mail", "bot_step"]);
    if (state.auto_click_active !== true) {
      if (automationInterval) {
        clearInterval(automationInterval);
        automationInterval = null;
      }
      return;
    }

    const provider = state.mail_provider || "guerrillamail";
    let currentMail = state.current_mail || "";

    // 0. Dismiss Oops modal
    if (dismissOopsModal()) {
      updateMobileHUD("Dismissing Error", currentMail, null, true);
      return;
    }

    // 1. Check if on accounts center / final logout screen (Step 13)
    const logoutBtn = findLogoutButton();
    if (logoutBtn) {
      isStepInProgress = true;
      updateMobileHUD("Finalizing (Step 13)", currentMail, "Verified ✓", true);
      logMessage("Final screen reached! Saving account record...");

      const pass = "SecurePass123!";
      Storage.saveAccountToVault({
        email: currentMail,
        password: pass,
        timestamp: new Date().toISOString()
      });

      const runs = (state.remaining_runs || 1) - 1;
      Storage.set({ remaining_runs: runs });

      if (runs <= 0) {
        logMessage("🎉 Batch completed successfully! All targets reached.");
        stopAutomation();
        isStepInProgress = false;
        return;
      }

      logMessage(`Account saved! Starting next account (${runs} remaining)...`);
      setTimeout(() => {
        executeMetaUltraClick(logoutBtn);
        setTimeout(() => {
          window.location.href = "https://auth.meta.com";
        }, 1500);
      }, 800);
      return;
    }

    // 2. Step 12: Photo upload
    const fileInput = document.querySelector('input[type="file"]');
    if (fileInput && !isCaptchaScreenActive()) {
      if (fileInput.dataset.uploaded !== "true") {
        isStepInProgress = true;
        updateMobileHUD("Uploading Avatar", currentMail, null, true);
        logMessage("Injecting profile avatar photo...");
        try {
          const file = dataURLtoFile(DEFAULT_AVATAR_BASE64, "avatar.jpg");
          const dt = new DataTransfer();
          dt.items.add(file);
          fileInput.files = dt.files;
          fileInput.dataset.uploaded = "true";
          fileInput.dispatchEvent(new Event("change", { bubbles: true }));
          fileInput.dispatchEvent(new Event("input", { bubbles: true }));
        } catch (e) {
          console.warn("[MetaFlow] Photo inject error:", e);
        }
        setTimeout(() => { isStepInProgress = false; }, 1000);
        return;
      }

      const photoNext = findGenericContinueButton() || findDarkBlueContinueButton();
      if (photoNext) {
        isStepInProgress = true;
        updateMobileHUD("Avatar Uploaded", currentMail, null, true);
        executeMetaUltraClick(photoNext);
        setTimeout(() => { isStepInProgress = false; }, 1200);
        return;
      }
    }

    // 3. Step 10: Captcha / Human verification
    if (isCaptchaScreenActive()) {
      updateMobileHUD("Human Captcha", currentMail, null, true);
      const continueBtn = findGenericContinueButton() || findDarkBlueContinueButton();
      if (continueBtn && continueBtn.getAttribute("aria-disabled") !== "true") {
        isStepInProgress = true;
        logMessage("Captcha verified ✓ Clicking Continue...");
        executeMetaUltraClick(continueBtn);
        setTimeout(() => { isStepInProgress = false; }, 1500);
        return;
      }
      return;
    }

    // 4. Step 7: OTP Screen
    if (isOtpScreenActive()) {
      const inputs = Array.from(document.querySelectorAll("input:not([type='hidden'])"));
      const otpInput = inputs.find(inp => {
        const auto = (inp.getAttribute("autocomplete") || "").toLowerCase();
        return auto === "one-time-code" || inp.getAttribute("inputmode") === "numeric";
      }) || inputs[0];

      if (otpInput && !otpInput.value) {
        isStepInProgress = true;
        updateMobileHUD("Polling OTP...", currentMail, "Waiting...", true);
        logMessage(`Polling mailbox for 6-digit OTP code (${provider})...`);

        const otp = await MobileMailEngine.pollOtp(provider, currentMail);
        if (otp) {
          updateMobileHUD("Entering OTP", currentMail, otp, true);
          logMessage(`✅ OTP Received: ${otp}! Injecting...`);
          setReactInputValue(otpInput, otp);

          setTimeout(() => {
            const nextBtn = findGenericContinueButton() || findDarkBlueContinueButton();
            if (nextBtn) {
              executeMetaUltraClick(nextBtn);
            }
            isStepInProgress = false;
          }, 1000);
        } else {
          logMessage("⚠️ OTP poll timed out. Retrying...");
          isStepInProgress = false;
        }
        return;
      }
      return;
    }

    // 5. Step 5: Password
    const passInput = findPasswordInput();
    if (passInput) {
      if (!passInput.value) {
        isStepInProgress = true;
        updateMobileHUD("Entering Password", currentMail, null, true);
        const pass = "SecurePass123!";
        setReactInputValue(passInput, pass);
        setTimeout(() => {
          const nextBtn = findGenericContinueButton() || findDarkBlueContinueButton();
          if (nextBtn) executeMetaUltraClick(nextBtn);
          isStepInProgress = false;
        }, 800);
        return;
      }
    }

    // 6. Step 4: Birth Year
    const yearTarget = findBirthdayYearTarget();
    if (yearTarget) {
      isStepInProgress = true;
      updateMobileHUD("Setting Birth Year", currentMail, null, true);
      const isApplied = selectMetaComboboxOption(yearTarget, "2002");
      if (isApplied || yearTarget.tagName === "SELECT") {
        if (yearTarget.tagName === "SELECT") {
          yearTarget.value = "2002";
          yearTarget.dispatchEvent(new Event("change", { bubbles: true }));
        }
        setTimeout(() => {
          const nextBtn = findGenericContinueButton() || findDarkBlueContinueButton();
          if (nextBtn) executeMetaUltraClick(nextBtn);
          isStepInProgress = false;
        }, 800);
        return;
      }
      isStepInProgress = false;
      return;
    }

    // 7. Step 3: First & Last Names
    const nameInputs = findNameInputs();
    if (nameInputs.length >= 2) {
      const fName = getRandomItem(REALISTIC_FIRST_NAMES);
      const lName = getRandomItem(REALISTIC_LAST_NAMES);

      if (!nameInputs[0].value || !nameInputs[1].value) {
        isStepInProgress = true;
        updateMobileHUD("Filling Names", currentMail, null, true);
        logMessage(`Filling Name: ${fName} ${lName}...`);
        setReactInputValue(nameInputs[0], fName);
        setTimeout(() => {
          setReactInputValue(nameInputs[1], lName);
          setTimeout(() => {
            const nextBtn = findGenericContinueButton() || findDarkBlueContinueButton();
            if (nextBtn) executeMetaUltraClick(nextBtn);
            isStepInProgress = false;
          }, 600);
        }, 400);
        return;
      }
    }

    // 8. Step 2: Email Generation & Entry
    const emailInput = findEmailOrContactInput();
    if (emailInput) {
      if (!emailInput.value) {
        isStepInProgress = true;
        updateMobileHUD("Generating Email", null, null, true);
        logMessage(`Generating disposable email via ${provider}...`);

        const newEmail = await MobileMailEngine.createMail(provider);
        if (newEmail) {
          logMessage(`✅ Got Email: ${newEmail}`);
          updateMobileHUD("Entering Email", newEmail, null, true);
          setReactInputValue(emailInput, newEmail);

          setTimeout(() => {
            const nextBtn = findGenericContinueButton() || findDarkBlueContinueButton();
            if (nextBtn) {
              executeMetaUltraClick(nextBtn);
            }
            isStepInProgress = false;
          }, 800);
        } else {
          logMessage("❌ Failed to obtain email.");
          isStepInProgress = false;
        }
        return;
      }
    }

    // 9. Step 1: Start Button ("Use mobile number or email address")
    const useEmailBtn = findUseEmailAddressButton();
    if (useEmailBtn) {
      isStepInProgress = true;
      updateMobileHUD("Starting Flow", null, null, true);
      logMessage("Clicking 'Use mobile number or email address'...");
      executeMetaUltraClick(useEmailBtn);
      setTimeout(() => { isStepInProgress = false; }, 1000);
      return;
    }
  }

  // ==========================================
  // 8. INITIALIZE ON DOM READY
  // ==========================================
  function init() {
    injectMobileHUD();

    // Auto-resume if active cycle was running before reload
    const state = Storage.get(["auto_click_active", "current_mail"]);
    if (state.auto_click_active === true) {
      logMessage("Resuming automated cycle after reload...");
      updateMobileHUD("Resuming...", state.current_mail, null, true);
      startLoop();
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

})();
