MON PLANNING PASS — V9

Ouvre index.html dans Chrome.
Cette version ajoute une Banque d'entraînement : import de documents, stockage local des fichiers, génération locale de flashcards à partir de texte collé et transformation de QCM fournis en quiz interactifs avec correction.

Important : une vraie génération IA fiable à partir de PDF/Word nécessite un moteur IA connecté. Cette version ne prétend pas inventer des corrections médicales : elle conserve les documents et utilise les corrections fournies.
