JARVIX (Jarvis + Sweety + Salma)

Kholne ke liye: index.html ko Chrome mein kholo (internet ho to Wikipedia lookup bhi chalega).
APK banane ke liye: WebIntoApp / Median / AppsGeyser mein index.html aur jarvix-icon-512.png upload karo.
