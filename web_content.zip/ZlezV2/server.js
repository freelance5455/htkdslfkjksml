const express = require("express");
const http = require("http");
const path = require("path");
const fs = require("fs");
const pino = require("pino");
const QRCode = require("qrcode");

const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    Browsers,
    fetchLatestBaileysVersion
} = require("@whiskeysockets/baileys");

const { Server } = require("socket.io");

// ============================================================
// CONFIG
// ============================================================

const PORT = Number(process.env.PORT || 3000);

const ROOT_DIR = __dirname;
const PUBLIC_DIR = path.join(ROOT_DIR, "public");
const AUTH_DIR = path.join(ROOT_DIR, "auth_info");
const CHAT_FILE = path.join(ROOT_DIR, "chat_history.json");

// ============================================================
// PREPARE FOLDERS / FILES
// ============================================================

fs.mkdirSync(PUBLIC_DIR, {
    recursive: true
});

fs.mkdirSync(AUTH_DIR, {
    recursive: true
});

if (!fs.existsSync(CHAT_FILE)) {
    fs.writeFileSync(
        CHAT_FILE,
        "[]",
        "utf8"
    );
}

// ============================================================
// EXPRESS + SOCKET.IO
// ============================================================

const app = express();

const server = http.createServer(app);

const io = new Server(server, {
    transports: [
        "websocket",
        "polling"
    ]
});

app.use(express.json());

app.use(
    express.static(PUBLIC_DIR)
);

// ============================================================
// DATA
// ============================================================

let chatMessages = [];

const connectedUsers = new Map();

const colors = [
    "#4f8cff",
    "#8b5cf6",
    "#ec4899",
    "#14b8a6",
    "#f59e0b",
    "#22c55e",
    "#ef4444"
];

// ============================================================
// WHATSAPP STATE
// ============================================================

let whatsappSocket = null;

let whatsappConnected = false;

let whatsappConnecting = false;

let latestQR = null;

let reconnectTimer = null;

// ============================================================
// CHAT STORAGE
// ============================================================

function loadChatHistory() {
    try {
        const data = fs.readFileSync(
            CHAT_FILE,
            "utf8"
        );

        const parsed = JSON.parse(data);

        if (Array.isArray(parsed)) {
            chatMessages = parsed.slice(-200);
        } else {
            chatMessages = [];
        }
    } catch (error) {
        console.log(
            "Gagal membaca chat_history.json"
        );

        chatMessages = [];
    }
}

function saveChatHistory() {
    try {
        chatMessages = chatMessages.slice(-200);

        fs.writeFileSync(
            CHAT_FILE,
            JSON.stringify(
                chatMessages,
                null,
                2
            ),
            "utf8"
        );
    } catch (error) {
        console.log(
            "Gagal menyimpan chat history:",
            error.message
        );
    }
}

// ============================================================
// HELPERS
// ============================================================

function cleanUsername(username) {
    const value = String(
        username || ""
    ).trim();

    if (
        /^[A-Za-z]{3,30}$/.test(value)
    ) {
        return value;
    }

    return "User";
}

function chooseColor() {
    return colors[
        Math.floor(
            Math.random() * colors.length
        )
    ];
}

function cleanPhone(number) {
    return String(
        number || ""
    ).replace(/\D/g, "");
}

function validPhone(number) {
    return /^628\d{8,13}$/.test(
        number
    );
}

function createId(prefix = "msg") {
    return (
        prefix +
        "_" +
        Date.now().toString(36) +
        "_" +
        Math.random()
            .toString(36)
            .slice(2, 10)
    );
}

function isVerified(username) {
    return username === "Zar";
}

// ============================================================
// SYSTEM MESSAGE
// ============================================================

function createSystemMessage(text) {
    return {
        id: createId("system"),
        type: "system",
        username: "System",
        text: String(text),
        timestamp: Date.now()
    };
}

function broadcastSystemMessage(text) {
    const message =
        createSystemMessage(text);

    chatMessages.push(message);

    saveChatHistory();

    io.emit(
        "chat_message",
        message
    );
}

// ============================================================
// ONLINE USERS
// ============================================================

function sendOnlineCount() {
    io.emit(
        "online_count",
        {
            count: connectedUsers.size
        }
    );
}

// ============================================================
// WHATSAPP STATUS
// ============================================================

function broadcastWhatsAppStatus(
    message
) {
    io.emit(
        "wa_status",
        {
            connected:
                whatsappConnected,

            connecting:
                whatsappConnecting,

            message
        }
    );
}

// ============================================================
// PAIRING CODE
// ============================================================

async function requestPairingCode(
    phoneNumber
) {
    if (!whatsappSocket) {
        io.emit(
            "pairing_error",
            {
                message:
                    "Socket WhatsApp belum siap."
            }
        );

        return;
    }

    if (whatsappConnected) {
        io.emit(
            "pairing_error",
            {
                message:
                    "WhatsApp sudah terhubung."
            }
        );

        return;
    }

    const phone =
        cleanPhone(phoneNumber);

    if (!validPhone(phone)) {
        io.emit(
            "pairing_error",
            {
                message:
                    "Nomor harus menggunakan format 628xxxxxxxxxx."
            }
        );

        return;
    }

    try {
        const code =
            await whatsappSocket.requestPairingCode(
                phone
            );

        io.emit(
            "pairing_code",
            {
                code: String(code)
            }
        );

        console.log(
            "Pairing code berhasil dibuat."
        );
    } catch (error) {
        console.log(
            "Pairing error:",
            error.message
        );

        io.emit(
            "pairing_error",
            {
                message:
                    error.message ||
                    "Gagal membuat pairing code."
            }
        );
    }
}

// ============================================================
// WHATSAPP START
// ============================================================

async function startWhatsApp() {
    if (whatsappConnecting) {
        return;
    }

    whatsappConnecting = true;

    broadcastWhatsAppStatus(
        "Menyiapkan koneksi WhatsApp..."
    );

    try {
        const {
            state,
            saveCreds
        } =
            await useMultiFileAuthState(
                AUTH_DIR
            );

        let version;

        try {
            const latest =
                await fetchLatestBaileysVersion();

            version = latest.version;
        } catch (error) {
            console.log(
                "Tidak dapat mengambil versi Baileys terbaru."
            );
        }

        const options = {
            auth: state,

            browser:
                Browsers.macOS(
                    "Safari"
                ),

            logger:
                pino({
                    level: "silent"
                }),

            markOnlineOnConnect:
                false,

            syncFullHistory:
                false
        };

        if (version) {
            options.version =
                version;
        }

        whatsappSocket =
            makeWASocket(options);

        whatsappSocket.ev.on(
            "creds.update",
            saveCreds
        );

        whatsappSocket.ev.on(
            "connection.update",
            async update => {
                const {
                    connection,
                    lastDisconnect,
                    qr
                } = update;

                // --------------------------------------------
                // CONNECTING
                // --------------------------------------------

                if (
                    connection ===
                    "connecting"
                ) {
                    whatsappConnecting =
                        true;

                    broadcastWhatsAppStatus(
                        "Menghubungkan ke WhatsApp..."
                    );
                }

                // --------------------------------------------
                // QR
                // --------------------------------------------

                if (qr) {
                    latestQR = qr;

                    console.log(
                        "QR WhatsApp tersedia."
                    );

                    try {
                        const dataURL =
                            await QRCode.toDataURL(
                                qr,
                                {
                                    width: 320,
                                    margin: 2,
                                    errorCorrectionLevel:
                                        "M"
                                }
                            );

                        io.emit(
                            "qr_update",
                            {
                                qr: dataURL
                            }
                        );
                    } catch (error) {
                        console.log(
                            "Gagal membuat QR:",
                            error.message
                        );

                        io.emit(
                            "pairing_error",
                            {
                                message:
                                    "Gagal membuat QR WhatsApp."
                            }
                        );
                    }
                }

                // --------------------------------------------
                // OPEN
                // --------------------------------------------

                if (
                    connection ===
                    "open"
                ) {
                    whatsappConnected =
                        true;

                    whatsappConnecting =
                        false;

                    latestQR = null;

                    io.emit(
                        "qr_clear"
                    );

                    broadcastWhatsAppStatus(
                        "WhatsApp terhubung."
                    );

                    console.log(
                        "WhatsApp terhubung."
                    );
                }

                // --------------------------------------------
                // CLOSE
                // --------------------------------------------

                if (
                    connection ===
                    "close"
                ) {
                    whatsappConnected =
                        false;

                    whatsappConnecting =
                        false;

                    const statusCode =
                        lastDisconnect
                            ?.error
                            ?.output
                            ?.statusCode;

                    const shouldReconnect =
                        statusCode !==
                        DisconnectReason.loggedOut;

                    if (
                        statusCode ===
                        DisconnectReason.loggedOut
                    ) {
                        latestQR = null;

                        broadcastWhatsAppStatus(
                            "Session WhatsApp logout. Hapus auth_info jika ingin pairing ulang."
                        );

                        console.log(
                            "WhatsApp logout."
                        );

                        return;
                    }

                    broadcastWhatsAppStatus(
                        "Koneksi terputus. Mencoba reconnect..."
                    );

                    console.log(
                        "WhatsApp terputus."
                    );

                    if (
                        shouldReconnect
                    ) {
                        clearTimeout(
                            reconnectTimer
                        );

                        reconnectTimer =
                            setTimeout(
                                () => {
                                    startWhatsApp();
                                },
                                3000
                            );
                    }
                }
            }
        );
    } catch (error) {
        whatsappConnecting =
            false;

        console.log(
            "Gagal menjalankan WhatsApp:",
            error.message
        );

        broadcastWhatsAppStatus(
            "Gagal menjalankan WhatsApp. Reconnect otomatis..."
        );

        clearTimeout(
            reconnectTimer
        );

        reconnectTimer =
            setTimeout(
                () => {
                    startWhatsApp();
                },
                5000
            );
    }
}

// ============================================================
// SOCKET.IO
// ============================================================

io.on(
    "connection",
    socket => {
        console.log(
            "Browser terhubung:",
            socket.id
        );

        // --------------------------------------------
        // SEND WHATSAPP STATUS
        // --------------------------------------------

        socket.emit(
            "wa_status",
            {
                connected:
                    whatsappConnected,

                connecting:
                    whatsappConnecting,

                message:
                    whatsappConnected
                        ? "WhatsApp terhubung."
                        : "WhatsApp belum terhubung."
            }
        );

        // --------------------------------------------
        // ONLINE
        // --------------------------------------------

        socket.emit(
            "online_count",
            {
                count:
                    connectedUsers.size
            }
        );

        // --------------------------------------------
        // SEND EXISTING QR
        // --------------------------------------------

        if (
            latestQR &&
            !whatsappConnected
        ) {
            QRCode.toDataURL(
                latestQR,
                {
                    width: 320,
                    margin: 2,
                    errorCorrectionLevel:
                        "M"
                }
            )
                .then(dataURL => {
                    socket.emit(
                        "qr_update",
                        {
                            qr: dataURL
                        }
                    );
                })
                .catch(() => {});
        }

        // --------------------------------------------
        // CHAT JOIN
        // --------------------------------------------

        socket.on(
            "chat_join",
            data => {
                const username =
                    cleanUsername(
                        data?.username
                    );

                const color =
                    colors.includes(
                        data?.color
                    )
                        ? data.color
                        : chooseColor();

                const verified =
                    isVerified(
                        username
                    );

                connectedUsers.set(
                    socket.id,
                    {
                        username,
                        color,
                        verified
                    }
                );

                // Send last 50 messages
                socket.emit(
                    "chat_history",
                    {
                        messages:
                            chatMessages.slice(
                                -50
                            )
                    }
                );

                socket.broadcast.emit(
                    "chat_user_joined",
                    {
                        username,
                        color,
                        verified
                    }
                );

                broadcastSystemMessage(
                    `${username} bergabung ke chat.`
                );

                sendOnlineCount();

                console.log(
                    `${username} bergabung.`
                );
            }
        );

        // --------------------------------------------
        // CHAT SEND
        // --------------------------------------------

        socket.on(
            "chat_send",
            data => {
                const user =
                    connectedUsers.get(
                        socket.id
                    );

                if (!user) {
                    return;
                }

                if (
                    typeof data?.text !==
                    "string"
                ) {
                    return;
                }

                const text =
                    data.text
                        .replace(
                            /\r\n/g,
                            "\n"
                        )
                        .trim()
                        .slice(
                            0,
                            2000
                        );

                if (!text) {
                    return;
                }

                // ----------------------------------------
                // REPLY
                // ----------------------------------------

                let quote = null;

                if (
                    data.quote &&
                    typeof data.quote ===
                        "object"
                ) {
                    if (
                        typeof data.quote
                            .id ===
                            "string" &&
                        typeof data.quote
                            .text ===
                            "string"
                    ) {
                        quote = {
                            id:
                                data.quote.id.slice(
                                    0,
                                    100
                                ),

                            username:
                                cleanUsername(
                                    data.quote
                                        .username
                                ),

                            text:
                                data.quote.text.slice(
                                    0,
                                    1000
                                ),

                            color:
                                colors.includes(
                                    data.quote.color
                                )
                                    ? data.quote.color
                                    : "#4f8cff"
                        };
                    }
                }

                const message = {
                    id: createId(
                        "chat"
                    ),

                    type: "chat",

                    username:
                        user.username,

                    color:
                        user.color,

                    verified:
                        user.verified,

                    text,

                    quote,

                    timestamp:
                        Date.now()
                };

                chatMessages.push(
                    message
                );

                saveChatHistory();

                io.emit(
                    "chat_message",
                    message
                );
            }
        );

        // --------------------------------------------
        // TYPING
        // --------------------------------------------

        socket.on(
            "chat_typing",
            data => {
                const user =
                    connectedUsers.get(
                        socket.id
                    );

                if (!user) {
                    return;
                }

                socket.broadcast.emit(
                    "chat_typing",
                    {
                        username:
                            user.username,

                        color:
                            user.color,

                        typing:
                            Boolean(
                                data?.typing
                            )
                    }
                );
            }
        );

        // --------------------------------------------
        // PAIRING CODE
        // --------------------------------------------

        socket.on(
            "request_pairing_code",
            data => {
                requestPairing(
                    data?.number
                );
            }
        );

        // --------------------------------------------
        // STATUS
        // --------------------------------------------

        socket.on(
            "check_status",
            () => {
                socket.emit(
                    "wa_status",
                    {
                        connected:
                            whatsappConnected,

                        connecting:
                            whatsappConnecting,

                        message:
                            whatsappConnected
                                ? "WhatsApp terhubung."
                                : "WhatsApp belum terhubung."
                    }
                );
            }
        );

        // --------------------------------------------
        // DISCONNECT
        // --------------------------------------------

        socket.on(
            "disconnect",
            () => {
                const user =
                    connectedUsers.get(
                        socket.id
                    );

                if (user) {
                    connectedUsers.delete(
                        socket.id
                    );

                    broadcastSystemMessage(
                        `${user.username} meninggalkan chat.`
                    );

                    sendOnlineCount();

                    console.log(
                        `${user.username} meninggalkan chat.`
                    );
                }

                console.log(
                    "Browser terputus:",
                    socket.id
                );
            }
        );
    }
);

// ============================================================
// API STATUS
// ============================================================

app.get(
    "/api/status",
    (req, res) => {
        res.json({
            app: "Zlez.Id",

            whatsapp: {
                connected:
                    whatsappConnected,

                connecting:
                    whatsappConnecting
            },

            onlineUsers:
                connectedUsers.size,

            chatMessages:
                chatMessages.length
        });
    }
);

// ============================================================
// FRONTEND FALLBACK
// ============================================================

app.get(
    "*",
    (req, res) => {
        res.sendFile(
            path.join(
                PUBLIC_DIR,
                "index.html"
            )
        );
    }
);

// ============================================================
// START SERVER
// ============================================================

loadChatHistory();

server.listen(
    PORT,
    "0.0.0.0",
    () => {
        console.log("");
        console.log(
            "================================"
        );
        console.log(
            "          Zlez.Id"
        );
        console.log(
            "================================"
        );
        console.log(
            `Server: http://localhost:${PORT}`
        );
        console.log(
            "WhatsApp: Baileys"
        );
        console.log(
            "Browser: Safari"
        );
        console.log(
            "Pairing: Enabled"
        );
        console.log(
            "Global Chat: Enabled"
        );
        console.log(
            "================================"
        );
        console.log("");
    }
);

// ============================================================
// START WHATSAPP
// ============================================================

startWhatsApp();

// ============================================================
// SAFE SHUTDOWN
// ============================================================

function shutdown(signal) {
    console.log(
        `\nMenerima ${signal}. Menutup server...`
    );

    clearTimeout(
        reconnectTimer
    );

    try {
        if (
            whatsappSocket
        ) {
            whatsappSocket.end(
                undefined
            );
        }
    } catch {}

    server.close(
        () => {
            process.exit(0);
        }
    );
}

process.on(
    "SIGINT",
    () => shutdown("SIGINT")
);

process.on(
    "SIGTERM",
    () => shutdown("SIGTERM")
);