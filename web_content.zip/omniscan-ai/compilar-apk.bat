@echo off
chcp 65001 >nul
echo.
echo ============================================
echo   OmniScan AI — Compilacion de APK
echo ============================================
echo.

if not exist "node_modules" (
  echo - Instalando dependencias (solo la primera vez)...
  call npm install
)

echo - Compilando la app web...
call npm run build
if errorlevel 1 goto error

if not exist "android" (
  echo - Creando proyecto Android (solo la primera vez)...
  call npx cap add android
  call node scripts\preparar-android.js
)

echo - Sincronizando con Android...
call npx cap sync android
call node scripts\preparar-android.js

echo - Compilando APK (puede tardar unos minutos)...
cd android
call gradlew.bat assembleDebug
if errorlevel 1 goto error

echo.
echo ============================================
echo   LISTO!
echo   Tu APK esta en:
echo   android\app\build\outputs\apk\debug\app-debug.apk
echo ============================================
echo.
echo Pasala a tu celular e instalala.
echo (Si Android bloquea, activa "Origenes desconocidos")
echo.
pause
exit /b 0

:error
echo.
echo Hubo un error. Revisá que tengas instalado:
echo   - Node.js  (https://nodejs.org)
echo   - Android Studio  (https://developer.android.com/studio)
echo.
pause
exit /b 1
