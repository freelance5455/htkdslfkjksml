# OmniScan AI — Cómo instalar y generar la APK (guía simple)

No hace falta saber programar. Seguí estos pasos en orden.

---

## Lo que necesitás tener instalado (una sola vez)

1. **Node.js**  
   Entrá a: https://nodejs.org  
   Descargá la versión **LTS** e instalá (siguiente, siguiente, listo).

2. **Android Studio**  
   Entrá a: https://developer.android.com/studio  
   Instalá y la primera vez dejá que descargue el Android SDK (puede tardar).

---

## Pasos para generar tu APK

### Opción A — Windows (la más fácil)

1. Descomprimí la carpeta `omniscan-ai`.
2. Hacé **doble clic** en el archivo:
   ```
   compilar-apk.bat
   ```
3. Esperá. La primera vez tarda más (instala cosas).
4. Cuando termine, la APK está en:
   ```
   omniscan-ai\android\app\build\outputs\apk\debug\app-debug.apk
   ```
5. Pasá ese archivo a tu celular (WhatsApp, USB, Drive, etc.).
6. En el celular abrí el archivo e instalá.  
   Si dice “bloquear”, andá a Ajustes → Seguridad → **Permitir orígenes desconocidos**.

### Opción B — Mac o Linux

1. Abrí la Terminal.
2. Entrá a la carpeta:
   ```bash
   cd ruta/a/omniscan-ai
   ```
3. Ejecutá:
   ```bash
   chmod +x compilar-apk.sh
   ./compilar-apk.sh
   ```
4. La APK queda en el mismo lugar:
   ```
   android/app/build/outputs/apk/debug/app-debug.apk
   ```

---

## Clave para abrir la app

```
SHIKITIT@2007
```

---

## Si algo falla

| Problema | Qué hacer |
|----------|-----------|
| “npm no se reconoce” | Reinstalá Node.js y cerrá/abrí la terminal |
| Error de Java / Gradle | Abrí Android Studio una vez y dejá que termine de configurar el SDK |
| La APK no instala | Activá “Orígenes desconocidos” o “Instalar apps desconocidas” |
| No pide cámara/micrófono | En el celular: Ajustes → Apps → OmniScan AI → Permisos → activá Cámara y Micrófono |

---

## Probar sin generar APK (solo en la computadora)

```bash
npm install
npm run dev
```

Se abre en el navegador. Sirve para ver el diseño y las pantallas.

---

Listo. Con el doble clic en `compilar-apk.bat` (Windows) o el script en Mac/Linux deberías obtener la APK.
