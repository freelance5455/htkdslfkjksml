import { defineConfig } from 'vite';

export default defineConfig({
  root: './',
  build: {
    outDir: 'dist',
    emptyOutDir: true,
    target: 'es2020',
    chunkSizeWarningLimit: 2000, // tesseract es pesado
  },
  server: {
    port: 5173,
    host: true
  },
  optimizeDeps: {
    exclude: ['tesseract.js']
  }
});
