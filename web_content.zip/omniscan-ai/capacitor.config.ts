import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'ai.omniscan.app',
  appName: 'OmniScan AI',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  },
  android: {
    allowMixedContent: true,
    backgroundColor: '#0c0a12',
    buildOptions: {
      keystorePath: undefined,
      keystoreAlias: undefined
    }
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 1200,
      backgroundColor: '#0c0a12',
      showSpinner: false
    },
    StatusBar: {
      style: 'DARK',
      backgroundColor: '#0c0a12'
    },
    Camera: {
      permissions: ['camera']
    }
  }
};

export default config;
