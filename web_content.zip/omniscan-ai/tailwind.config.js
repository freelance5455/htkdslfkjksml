/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,html}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        // Base dark
        background: '#0c0a12',
        surface: '#12101a',
        'surface-2': '#1a1625',
        'surface-3': '#221e30',
        'surface-4': '#2c2740',

        // Violet primary system
        violet: {
          50:  '#f5f3ff',
          100: '#ede9fe',
          200: '#ddd6fe',
          300: '#c4b5fd',
          400: '#a78bfa',
          500: '#8b5cf6',
          600: '#7c3aed',
          700: '#6d28d9',
          800: '#5b21b6',
          900: '#4c1d95',
          950: '#2e1065',
        },

        // Accent complementary
        cyan: {
          400: '#22d3ee',
          500: '#06b6d4',
        },
        fuchsia: {
          400: '#e879f9',
          500: '#d946ef',
        },

        // Text
        'text-primary': '#f0eef8',
        'text-secondary': '#a89bbf',
        'text-muted': '#6b6280',

        // Semantic
        success: '#34d399',
        danger: '#f87171',
        warning: '#fbbf24',
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'ui-monospace', 'monospace'],
      },
      boxShadow: {
        'glow-violet': '0 0 20px rgba(139, 92, 246, 0.35)',
        'glow-violet-sm': '0 0 10px rgba(139, 92, 246, 0.25)',
        'glow-cyan': '0 0 16px rgba(34, 211, 238, 0.3)',
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'scan': 'scan 2.5s ease-in-out infinite',
      },
      keyframes: {
        scan: {
          '0%, 100%': { top: '15%' },
          '50%': { top: '75%' },
        }
      }
    }
  },
  plugins: []
}
