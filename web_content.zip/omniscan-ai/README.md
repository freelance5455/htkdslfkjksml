# OmniScan AI v1.2

OCR en vivo · Grabación de clases · Transcripción · Resúmenes con IA  
Todo corre en tu celular. La única limitación es el espacio de almacenamiento.

## Diseño
Violeta moderno, marcos con glow, interfaz oscura e intuitiva.

## Clave de acceso
```
SHIKITIT@2007
```

## Generar la APK (lo más simple)

### Windows
Doble clic en:
```
compilar-apk.bat
```

### Mac / Linux
```bash
chmod +x compilar-apk.sh
./compilar-apk.sh
```

La APK queda en:
```
android/app/build/outputs/apk/debug/app-debug.apk
```

Guía completa paso a paso → **COMO-INSTALAR.md**

## Probar en el navegador
```bash
npm install
npm run dev
```
