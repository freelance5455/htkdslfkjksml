#!/bin/bash
set -e
echo ""
echo "============================================"
echo "  OmniScan AI — Compilación de APK"
echo "============================================"
echo ""

# 1. Dependencias
if [ ! -d "node_modules" ]; then
  echo "→ Instalando dependencias (solo la primera vez)..."
  npm install
fi

# 2. Build web
echo "→ Compilando la app web..."
npm run build

# 3. Plataforma Android
if [ ! -d "android" ]; then
  echo "→ Creando proyecto Android (solo la primera vez)..."
  npx cap add android
  node scripts/preparar-android.js
fi

# 4. Sync
echo "→ Sincronizando con Android..."
npx cap sync android
node scripts/preparar-android.js

# 5. Compilar APK
echo "→ Compilando APK (puede tardar unos minutos)..."
cd android
chmod +x gradlew 2>/dev/null || true
./gradlew assembleDebug

echo ""
echo "============================================"
echo "  ¡LISTO!"
echo "  Tu APK está en:"
echo "  android/app/build/outputs/apk/debug/app-debug.apk"
echo "============================================"
echo ""
echo "Pasala a tu celular e instalala."
echo "(Si Android bloquea, activá 'Orígenes desconocidos')"
echo ""
