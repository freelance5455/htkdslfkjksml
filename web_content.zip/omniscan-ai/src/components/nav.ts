import type { Screen } from '../main';

export function bottomNav(active: Screen): string {
  const items: { id: Screen; icon: string; label: string }[] = [
    { id: 'scanner', icon: 'document_scanner', label: 'Escanear' },
    { id: 'mic', icon: 'mic', label: 'Clases' },
    { id: 'vault', icon: 'lock', label: 'Bóveda' },
    { id: 'history', icon: 'history', label: 'Historial' },
    { id: 'settings', icon: 'settings', label: 'Ajustes' },
  ];

  return `
    <nav class="fixed bottom-0 left-0 right-0 pb-safe bg-surface/95 backdrop-blur-xl border-t border-violet-500/15 z-50">
      <div class="flex items-center justify-around h-[4.25rem] px-1">
        ${items.map(item => `
          <button
            onclick="window.omniNavigate('${item.id}')"
            class="nav-item ${active === item.id ? 'nav-item-active' : 'nav-item-inactive'}"
          >
            <span class="material-symbols-outlined text-[22px] ${active === item.id ? 'text-violet-400' : ''}">${item.icon}</span>
            <span class="text-[10px] font-medium">${item.label}</span>
          </button>
        `).join('')}
      </div>
    </nav>
  `;
}
