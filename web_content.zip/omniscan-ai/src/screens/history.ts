import { bottomNav } from '../components/nav';
import type { Screen } from '../main';
import { getAllItems, type OmniItem, type ItemType } from '../services/storage';

type NavigateFn = (s: Screen) => void;

let filter: ItemType | 'all' = 'all';

export async function renderHistory(container: HTMLElement, navigate: NavigateFn) {
  const all = await getAllItems();
  const items = filter === 'all' ? all : all.filter(i => i.type === filter);

  const filters: { id: typeof filter; label: string }[] = [
    { id: 'all', label: 'Todo' },
    { id: 'ocr', label: 'OCR' },
    { id: 'transcript', label: 'Clases' },
    { id: 'summary', label: 'Resúmenes' },
    { id: 'audio', label: 'Audio' },
  ];

  container.innerHTML = `
    <div class="min-h-screen flex flex-col bg-background relative">
      <header class="fixed top-0 w-full z-50 pt-safe bg-surface/90 backdrop-blur-xl border-b border-violet-500/10">
        <div class="h-14 px-4 flex items-center justify-between">
          <div class="flex items-center gap-2.5">
            <div class="w-9 h-9 rounded-xl bg-violet-600/20 flex items-center justify-center border border-violet-500/30">
              <span class="material-symbols-outlined text-violet-400 text-lg">history</span>
            </div>
            <div>
              <p class="text-sm font-semibold text-text-primary leading-none">Historial</p>
              <p class="text-[10px] text-text-secondary mt-0.5">${all.length} registros</p>
            </div>
          </div>
        </div>
      </header>

      <main class="flex-1 pt-16 pb-28 px-4 flex flex-col gap-3">
        <div class="flex gap-2 overflow-x-auto pb-1 -mx-1 px-1">
          ${filters.map(f => `
            <button data-filter="${f.id}"
              class="px-3.5 py-1.5 rounded-full text-xs whitespace-nowrap transition
              ${filter === f.id
                ? 'bg-violet-600 text-white font-medium shadow-glow-violet-sm'
                : 'bg-surface-3 text-text-secondary border border-violet-500/15'}">
              ${f.label}
            </button>
          `).join('')}
        </div>

        <div class="space-y-2.5">
          ${items.length === 0
            ? `<div class="card text-center py-12">
                <span class="material-symbols-outlined text-3xl text-text-muted">inbox</span>
                <p class="text-sm text-text-secondary mt-2">Sin registros</p>
              </div>`
            : items.map(historyCard).join('')
          }
        </div>
      </main>

      ${bottomNav('history')}
    </div>
  `;

  container.querySelectorAll('[data-filter]').forEach(btn => {
    btn.addEventListener('click', () => {
      filter = (btn as HTMLElement).dataset.filter as any;
      renderHistory(container, navigate);
    });
  });
}

function historyCard(item: OmniItem): string {
  const date = new Date(item.createdAt).toLocaleString('es-AR', {
    day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit'
  });
  const icons: Record<string, string> = {
    ocr: 'document_scanner', audio: 'audio_file', transcript: 'mic',
    summary: 'auto_awesome', file: 'folder'
  };
  return `
    <div class="card">
      <div class="flex items-start gap-3">
        <div class="w-9 h-9 rounded-lg bg-surface-3 flex items-center justify-center flex-shrink-0 mt-0.5">
          <span class="material-symbols-outlined text-sm text-violet-400">${icons[item.type] || 'folder'}</span>
        </div>
        <div class="flex-1 min-w-0">
          <div class="flex items-center justify-between gap-2">
            <p class="text-sm font-medium text-text-primary truncate">${item.title}</p>
            <span class="text-[10px] text-text-muted flex-shrink-0">${date}</span>
          </div>
          <p class="text-xs text-text-secondary mt-1 line-clamp-2 leading-relaxed">${item.content.slice(0, 140)}${item.content.length > 140 ? '…' : ''}</p>
        </div>
      </div>
    </div>
  `;
}
