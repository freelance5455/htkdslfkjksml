import { bottomNav } from '../components/nav';
import type { Screen } from '../main';
import { captureFromVideo, recognizeImage } from '../services/ocr';
import { saveItem, saveBlob, uid } from '../services/storage';
import { aiSummary } from '../services/ai';

type NavigateFn = (s: Screen) => void;

let stream: MediaStream | null = null;
let scanning = false;

export function renderScanner(container: HTMLElement, navigate: NavigateFn) {
  container.innerHTML = `
    <div class="min-h-screen flex flex-col bg-background relative">
      <header class="fixed top-0 w-full z-50 pt-safe bg-surface/90 backdrop-blur-xl border-b border-violet-500/10">
        <div class="h-14 px-4 flex items-center justify-between">
          <div class="flex items-center gap-2.5">
            <div class="w-9 h-9 rounded-xl bg-violet-600/20 flex items-center justify-center border border-violet-500/30">
              <span class="material-symbols-outlined text-violet-400 text-lg">document_scanner</span>
            </div>
            <div>
              <p class="text-sm font-semibold text-text-primary leading-none">Escanear</p>
              <p class="text-[10px] text-text-secondary mt-0.5">OCR · Cámara en vivo</p>
            </div>
          </div>
          <div id="ocr-status" class="text-[10px] px-2.5 py-1 rounded-full bg-surface-3 text-text-muted border border-violet-500/15">
            Listo
          </div>
        </div>
      </header>

      <main class="flex-1 pt-16 pb-28 px-4 flex flex-col gap-3">
        <!-- Viewfinder -->
        <div class="relative flex-1 min-h-[380px] rounded-2xl overflow-hidden bg-surface-2 frame-violet">
          <video id="cam-video" class="absolute inset-0 w-full h-full object-cover" playsinline muted autoplay></video>
          <canvas id="cam-canvas" class="hidden"></canvas>

          <!-- Overlay grid -->
          <div class="absolute inset-0 opacity-[0.07] pointer-events-none"
               style="background-image: radial-gradient(#a78bfa 1px, transparent 1px); background-size: 18px 18px;"></div>

          <!-- Violet corner frames -->
          <div class="absolute top-3 left-3 w-7 h-7 border-t-2 border-l-2 border-violet-400 rounded-tl-lg"></div>
          <div class="absolute top-3 right-3 w-7 h-7 border-t-2 border-r-2 border-violet-400 rounded-tr-lg"></div>
          <div class="absolute bottom-3 left-3 w-7 h-7 border-b-2 border-l-2 border-violet-400 rounded-bl-lg"></div>
          <div class="absolute bottom-3 right-3 w-7 h-7 border-b-2 border-r-2 border-violet-400 rounded-br-lg"></div>

          <!-- Scan line -->
          <div id="scan-line" class="absolute left-2 right-2 h-0.5 bg-gradient-to-r from-transparent via-violet-400 to-transparent shadow-glow-violet opacity-80 animate-scan pointer-events-none"></div>

          <!-- OCR result floating plate -->
          <div id="ocr-plate" class="absolute bottom-4 left-3 right-3 p-3 rounded-xl bg-surface/90 backdrop-blur-md border border-violet-500/25 hidden">
            <div class="flex items-center justify-between mb-1.5">
              <span class="text-[10px] text-violet-400 font-medium flex items-center gap-1">
                <span class="material-symbols-outlined text-sm">document_scanner</span>
                OCR
              </span>
              <span id="ocr-conf" class="text-[10px] text-cyan-400 font-mono"></span>
            </div>
            <p id="ocr-text" class="text-xs text-text-primary font-mono leading-relaxed max-h-20 overflow-y-auto"></p>
          </div>
        </div>

        <!-- Actions -->
        <div class="flex items-center justify-center gap-5 py-1">
          <button id="btn-gallery" class="w-12 h-12 rounded-full bg-surface-3 border border-violet-500/20 flex items-center justify-center active:scale-95 transition">
            <span class="material-symbols-outlined text-text-secondary">photo_library</span>
          </button>
          <button id="btn-capture" class="w-[4.5rem] h-[4.5rem] rounded-full bg-violet-600 border-4 border-violet-400/40 flex items-center justify-center shadow-glow-violet active:scale-95 transition">
            <span class="material-symbols-outlined text-white text-3xl">photo_camera</span>
          </button>
          <button id="btn-summary" class="w-12 h-12 rounded-full bg-surface-3 border border-violet-500/20 flex items-center justify-center active:scale-95 transition opacity-40" disabled>
            <span class="material-symbols-outlined text-text-secondary">auto_awesome</span>
          </button>
        </div>

        <input type="file" id="file-input" accept="image/*" class="hidden" />
      </main>

      ${bottomNav('scanner')}
    </div>
  `;

  startCamera();
  wireEvents(navigate);
}

async function startCamera() {
  const video = document.getElementById('cam-video') as HTMLVideoElement;
  if (!video) return;
  try {
    stream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: 'environment', width: { ideal: 1920 }, height: { ideal: 1080 } },
      audio: false,
    });
    video.srcObject = stream;
  } catch (e) {
    setStatus('Sin cámara — usá galería', true);
    console.warn(e);
  }
}

function setStatus(msg: string, error = false) {
  const el = document.getElementById('ocr-status');
  if (!el) return;
  el.textContent = msg;
  el.className = `text-[10px] px-2.5 py-1 rounded-full border ${
    error
      ? 'bg-danger/10 text-danger border-danger/30'
      : 'bg-surface-3 text-text-muted border-violet-500/15'
  }`;
}

function showOCR(text: string, conf: number) {
  const plate = document.getElementById('ocr-plate');
  const confEl = document.getElementById('ocr-conf');
  const textEl = document.getElementById('ocr-text');
  const btnSum = document.getElementById('btn-summary') as HTMLButtonElement;
  if (!plate || !textEl) return;
  plate.classList.remove('hidden');
  textEl.textContent = text || '(sin texto detectado)';
  if (confEl) confEl.textContent = conf ? `${conf}%` : '';
  if (btnSum && text) {
    btnSum.disabled = false;
    btnSum.classList.remove('opacity-40');
  }
}

function wireEvents(navigate: NavigateFn) {
  const btnCapture = document.getElementById('btn-capture');
  const btnGallery = document.getElementById('btn-gallery');
  const btnSummary = document.getElementById('btn-summary');
  const fileInput = document.getElementById('file-input') as HTMLInputElement;
  let lastText = '';

  btnCapture?.addEventListener('click', async () => {
    if (scanning) return;
    scanning = true;
    setStatus('Procesando OCR…');
    const video = document.getElementById('cam-video') as HTMLVideoElement;
    try {
      const result = await captureFromVideo(video);
      lastText = result.text;
      showOCR(result.text, result.confidence);
      setStatus(result.confidence ? `Listo · ${result.confidence}%` : 'Listo');

      if (result.text) {
        const id = uid();
        await saveItem({
          id,
          type: 'ocr',
          title: result.lines[0]?.slice(0, 40) || 'Escaneo OCR',
          content: result.text,
          meta: { confidence: result.confidence, lines: result.lines.length },
          createdAt: Date.now(),
          sizeBytes: result.text.length,
        });
      }
    } catch (e) {
      setStatus('Error OCR', true);
      console.error(e);
    } finally {
      scanning = false;
    }
  });

  btnGallery?.addEventListener('click', () => fileInput?.click());

  fileInput?.addEventListener('change', async () => {
    const file = fileInput.files?.[0];
    if (!file) return;
    scanning = true;
    setStatus('Procesando imagen…');
    try {
      const result = await recognizeImage(file);
      lastText = result.text;
      showOCR(result.text, result.confidence);
      setStatus(`Listo · ${result.confidence}%`);
      if (result.text) {
        const id = uid();
        await saveBlob(id, file);
        await saveItem({
          id,
          type: 'ocr',
          title: file.name || 'Imagen OCR',
          content: result.text,
          blobKey: id,
          meta: { confidence: result.confidence },
          createdAt: Date.now(),
          sizeBytes: file.size + result.text.length,
        });
      }
    } catch (e) {
      setStatus('Error al leer imagen', true);
    } finally {
      scanning = false;
      fileInput.value = '';
    }
  });

  btnSummary?.addEventListener('click', async () => {
    if (!lastText) return;
    setStatus('Generando resumen…');
    btnSummary.setAttribute('disabled', 'true');
    try {
      const summary = await aiSummary(lastText, { style: 'documento', maxSentences: 5 });
      const id = uid();
      await saveItem({
        id,
        type: 'summary',
        title: 'Resumen OCR',
        content: summary,
        meta: { source: 'ocr' },
        createdAt: Date.now(),
        sizeBytes: summary.length,
      });
      showOCR(summary, 0);
      setStatus('Resumen guardado');
      const confEl = document.getElementById('ocr-conf');
      if (confEl) confEl.textContent = 'IA';
    } catch {
      setStatus('Error al resumir', true);
    } finally {
      btnSummary.removeAttribute('disabled');
    }
  });
}

// Cleanup when leaving (called from outside if needed)
export function stopScannerCamera() {
  stream?.getTracks().forEach(t => t.stop());
  stream = null;
}
