import { bottomNav } from '../components/nav';
import type { Screen } from '../main';
import { getAllItems, deleteItem, estimateUsage, type OmniItem } from '../services/storage';

type NavigateFn = (s: Screen) => void;

const typeIcon: Record<string, string> = {
  ocr: 'document_scanner',
  audio: 'audio_file',
  transcript: 'mic',
  summary: 'auto_awesome',
  file: 'folder',
};

const typeLabel: Record<string, string> = {
  ocr: 'OCR',
  audio: 'Audio',
  transcript: 'Transcripción',
  summary: 'Resumen IA',
  file: 'Archivo',
};

export async function renderVault(container: HTMLElement, _navigate: NavigateFn) {
  const items = await getAllItems();
  const usage = await estimateUsage();

  container.innerHTML = `
    <div class="min-h-screen flex flex-col bg-background relative">
      <header class="fixed top-0 w-full z-50 pt-safe bg-surface/90 backdrop-blur-xl border-b border-violet-500/10">
        <div class="h-14 px-4 flex items-center justify-between">
          <div class="flex items-center gap-2.5">
            <div class="w-9 h-9 rounded-xl bg-violet-600/20 flex items-center justify-center border border-violet-500/30">
              <span class="material-symbols-outlined text-violet-400 text-lg">lock</span>
            </div>
            <div>
              <p class="text-sm font-semibold text-text-primary leading-none">Bóveda</p>
              <p class="text-[10px] text-text-secondary mt-0.5">Local · Cifrado en dispositivo</p>
            </div>
          </div>
        </div>
      </header>

      <main class="flex-1 pt-16 pb-28 px-4 flex flex-col gap-4">
        <div class="card-glow flex items-center gap-3">
          <div class="w-11 h-11 rounded-xl bg-violet-600/20 flex items-center justify-center">
            <span class="material-symbols-outlined text-violet-400">encrypted</span>
          </div>
          <div class="flex-1">
            <p class="text-sm font-medium text-text-primary">Almacenamiento local</p>
            <p class="text-xs text-text-secondary">${usage.items} ítems · ~${usage.usedMB} MB usados</p>
          </div>
          <span class="text-[10px] text-success font-mono px-2 py-0.5 rounded bg-success/10">ACTIVO</span>
        </div>

        <p class="text-[10px] text-text-muted uppercase tracking-wider px-1">Contenido protegido</p>

        <div class="space-y-2.5" id="vault-list">
          ${items.length === 0
            ? `<div class="card text-center py-10">
                <span class="material-symbols-outlined text-3xl text-text-muted mb-2">inventory_2</span>
                <p class="text-sm text-text-secondary">La bóveda está vacía</p>
                <p class="text-xs text-text-muted mt-1">Escaneá o grabá una clase para empezar</p>
              </div>`
            : items.map(item => vaultCard(item)).join('')
          }
        </div>
      </main>

      ${bottomNav('vault')}
    </div>
  `;

  // Delete handlers
  container.querySelectorAll('[data-delete]').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      const id = (btn as HTMLElement).dataset.delete!;
      if (confirm('¿Eliminar este ítem?')) {
        await deleteItem(id);
        renderVault(container, _navigate);
      }
    });
  });

  // Expand content
  container.querySelectorAll('[data-expand]').forEach(card => {
    card.addEventListener('click', () => {
      const body = card.querySelector('.item-body') as HTMLElement;
      if (body) body.classList.toggle('hidden');
    });
  });
}

function vaultCard(item: OmniItem): string {
  const date = new Date(item.createdAt).toLocaleString('es-AR', {
    day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit'
  });
  return `
    <div class="card active:scale-[0.99] transition cursor-pointer" data-expand="${item.id}">
      <div class="flex items-center gap-3">
        <div class="w-10 h-10 rounded-xl bg-surface-3 flex items-center justify-center flex-shrink-0">
          <span class="material-symbols-outlined text-violet-400 text-lg">${typeIcon[item.type] || 'folder'}</span>
        </div>
        <div class="flex-1 min-w-0">
          <p class="text-sm font-medium text-text-primary truncate">${item.title}</p>
          <div class="flex items-center gap-2 mt-0.5">
            <span class="text-[10px] px-1.5 py-0.5 rounded bg-violet-600/15 text-violet-300">${typeLabel[item.type]}</span>
            <span class="text-[10px] text-text-muted">${date}</span>
          </div>
        </div>
        <button data-delete="${item.id}" class="w-8 h-8 rounded-lg flex items-center justify-center text-text-muted hover:text-danger">
          <span class="material-symbols-outlined text-lg">delete</span>
        </button>
      </div>
      <div class="item-body hidden mt-3 pt-3 border-t border-violet-500/10">
        <p class="text-xs text-text-secondary leading-relaxed whitespace-pre-wrap max-h-40 overflow-y-auto">${escapeHtml(item.content.slice(0, 1200))}${item.content.length > 1200 ? '…' : ''}</p>
      </div>
    </div>
  `;
}

function escapeHtml(s: string): string {
  return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
