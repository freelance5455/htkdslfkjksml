import { bottomNav } from '../components/nav';
import type { Screen } from '../main';
import { estimateUsage } from '../services/storage';
import { saveAIConfig } from '../services/ai';

type NavigateFn = (s: Screen) => void;

export async function renderSettings(container: HTMLElement, _navigate: NavigateFn) {
  const usage = await estimateUsage();
  const savedKey = localStorage.getItem('omni_ai_key') || '';
  const savedEndpoint = localStorage.getItem('omni_ai_endpoint') || '';
  const savedModel = localStorage.getItem('omni_ai_model') || 'gpt-4o-mini';

  container.innerHTML = `
    <div class="min-h-screen flex flex-col bg-background relative">
      <header class="fixed top-0 w-full z-50 pt-safe bg-surface/90 backdrop-blur-xl border-b border-violet-500/10">
        <div class="h-14 px-4 flex items-center justify-between">
          <div class="flex items-center gap-2.5">
            <div class="w-9 h-9 rounded-xl bg-violet-600/20 flex items-center justify-center border border-violet-500/30">
              <span class="material-symbols-outlined text-violet-400 text-lg">settings</span>
            </div>
            <div>
              <p class="text-sm font-semibold text-text-primary leading-none">Ajustes</p>
              <p class="text-[10px] text-text-secondary mt-0.5">IA · Almacenamiento</p>
            </div>
          </div>
        </div>
      </header>

      <main class="flex-1 pt-16 pb-28 px-4 flex flex-col gap-5">
        <!-- Storage -->
        <section>
          <p class="text-[10px] text-text-muted uppercase tracking-wider mb-2 px-1">Almacenamiento</p>
          <div class="card space-y-2">
            <div class="flex justify-between text-sm">
              <span class="text-text-secondary">Ítems guardados</span>
              <span class="text-text-primary font-medium">${usage.items}</span>
            </div>
            <div class="flex justify-between text-sm">
              <span class="text-text-secondary">Espacio estimado</span>
              <span class="text-text-primary font-medium">~${usage.usedMB} MB</span>
            </div>
            <p class="text-[11px] text-text-muted pt-1">La única limitación es el espacio de tu celular. Audio se comprime con Opus 24 kbps.</p>
          </div>
        </section>

        <!-- AI Config -->
        <section>
          <p class="text-[10px] text-text-muted uppercase tracking-wider mb-2 px-1">Resúmenes con IA</p>
          <div class="card space-y-3">
            <p class="text-xs text-text-secondary leading-relaxed">
              Sin API key se usa resumen local (extractivo). Con key podés conectar OpenAI, Grok u otro endpoint compatible.
            </p>
            <div>
              <label class="text-[11px] text-text-muted block mb-1">API Key</label>
              <input id="ai-key" type="password" class="input-dark w-full text-sm" placeholder="sk-..." value="${savedKey}" />
            </div>
            <div>
              <label class="text-[11px] text-text-muted block mb-1">Endpoint (opcional)</label>
              <input id="ai-endpoint" type="text" class="input-dark w-full text-sm" placeholder="https://api.openai.com/v1/chat/completions" value="${savedEndpoint}" />
            </div>
            <div>
              <label class="text-[11px] text-text-muted block mb-1">Modelo</label>
              <input id="ai-model" type="text" class="input-dark w-full text-sm" value="${savedModel}" />
            </div>
            <button id="btn-save-ai" class="btn-primary w-full text-sm">Guardar configuración IA</button>
          </div>
        </section>

        <!-- About -->
        <section>
          <p class="text-[10px] text-text-muted uppercase tracking-wider mb-2 px-1">Acerca de</p>
          <div class="card text-sm space-y-1">
            <p class="text-text-primary font-medium">OmniScan AI v1.1</p>
            <p class="text-xs text-text-secondary">OCR local · Grabación comprimida · Transcripción · Resúmenes IA</p>
            <p class="text-[11px] text-text-muted pt-2">Clave maestra demo: SHIKITIT@2007</p>
          </div>
        </section>
      </main>

      ${bottomNav('settings')}
    </div>
  `;

  document.getElementById('btn-save-ai')?.addEventListener('click', () => {
    const key = (document.getElementById('ai-key') as HTMLInputElement).value.trim();
    const endpoint = (document.getElementById('ai-endpoint') as HTMLInputElement).value.trim();
    const model = (document.getElementById('ai-model') as HTMLInputElement).value.trim();
    saveAIConfig(key, endpoint || undefined, model || undefined);
    const btn = document.getElementById('btn-save-ai');
    if (btn) {
      btn.textContent = '✓ Guardado';
      setTimeout(() => { if (btn) btn.textContent = 'Guardar configuración IA'; }, 1800);
    }
  });
}
