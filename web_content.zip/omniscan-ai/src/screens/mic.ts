import { bottomNav } from '../components/nav';
import type { Screen } from '../main';
import { AudioRecorder, LiveTranscriber } from '../services/audio';
import { saveItem, saveBlob, uid } from '../services/storage';
import { aiSummary } from '../services/ai';

type NavigateFn = (s: Screen) => void;

let recorder: AudioRecorder | null = null;
let transcriber: LiveTranscriber | null = null;
let isRecording = false;
let elapsed = 0;
let timerId = 0;
let lastTranscript = '';
let lastBlob: Blob | null = null;

export function renderMic(container: HTMLElement, _navigate: NavigateFn) {
  // Cleanup previous if any
  if (isRecording) stopAll();

  container.innerHTML = `
    <div class="min-h-screen flex flex-col bg-background relative">
      <header class="fixed top-0 w-full z-50 pt-safe bg-surface/90 backdrop-blur-xl border-b border-violet-500/10">
        <div class="h-14 px-4 flex items-center justify-between">
          <div class="flex items-center gap-2.5">
            <div class="w-9 h-9 rounded-xl bg-violet-600/20 flex items-center justify-center border border-violet-500/30">
              <span class="material-symbols-outlined text-violet-400 text-lg">mic</span>
            </div>
            <div>
              <p class="text-sm font-semibold text-text-primary leading-none">Clases</p>
              <p class="text-[10px] text-text-secondary mt-0.5">Grabar · Transcribir · Resumir</p>
            </div>
          </div>
          <div id="rec-badge" class="hidden items-center gap-1.5 px-2.5 py-1 rounded-full bg-danger/15 border border-danger/30">
            <span class="w-1.5 h-1.5 rounded-full bg-danger animate-pulse"></span>
            <span class="text-[10px] text-danger font-medium" id="rec-time">00:00</span>
          </div>
        </div>
      </header>

      <main class="flex-1 pt-16 pb-28 px-4 flex flex-col">
        <!-- Waveform / level -->
        <div class="mt-4 mb-6 h-16 flex items-end justify-center gap-[3px]" id="waveform">
          ${Array.from({ length: 40 }, () =>
            `<div class="w-1 rounded-full bg-violet-500/40 transition-all duration-75" style="height:12%"></div>`
          ).join('')}
        </div>

        <!-- Live transcript -->
        <div class="flex-1 card min-h-[180px] flex flex-col">
          <div class="flex items-center justify-between mb-2">
            <span class="text-[10px] text-violet-400 uppercase tracking-wider font-medium">Transcripción en vivo</span>
            <span id="words-count" class="text-[10px] text-text-muted">0 palabras</span>
          </div>
          <div id="transcript-box" class="flex-1 text-sm text-text-primary leading-relaxed overflow-y-auto max-h-[40vh]">
            <span class="text-text-muted">Presioná grabar para iniciar la clase…</span>
          </div>
        </div>

        <!-- Controls -->
        <div class="mt-6 flex flex-col items-center gap-4">
          <button id="btn-rec" class="w-20 h-20 rounded-full bg-violet-600 border-4 border-violet-400/40 flex items-center justify-center shadow-glow-violet active:scale-95 transition">
            <span id="rec-icon" class="material-symbols-outlined text-white text-4xl">mic</span>
          </button>

          <div class="flex gap-3 w-full max-w-xs">
            <button id="btn-save" class="btn-secondary flex-1 text-sm opacity-40" disabled>
              Guardar audio
            </button>
            <button id="btn-summarize" class="btn-primary flex-1 text-sm flex items-center justify-center gap-1.5 opacity-40" disabled>
              <span class="material-symbols-outlined text-base">auto_awesome</span>
              Resumen IA
            </button>
          </div>
        </div>

        <!-- Hint -->
        <p class="mt-5 text-center text-[11px] text-text-muted leading-relaxed px-4">
          Audio comprimido (Opus 24 kbps) · Transcripción local<br/>
          La única limitación es el espacio de tu celular
        </p>
      </main>

      ${bottomNav('mic')}
    </div>
  `;

  wireMic();
}

function formatTime(sec: number): string {
  const m = Math.floor(sec / 60).toString().padStart(2, '0');
  const s = (sec % 60).toString().padStart(2, '0');
  return `${m}:${s}`;
}

function updateWaveform(level: number) {
  const bars = document.querySelectorAll('#waveform > div');
  bars.forEach((bar, i) => {
    const variance = Math.sin(i * 0.4 + Date.now() / 200) * 0.3 + 0.7;
    const h = Math.max(8, Math.min(100, level * 100 * variance * 1.4));
    (bar as HTMLElement).style.height = `${h}%`;
    (bar as HTMLElement).style.background =
      level > 0.15 ? 'rgb(139, 92, 246)' : 'rgba(139, 92, 246, 0.35)';
  });
}

function setTranscript(full: string, interim: string) {
  const box = document.getElementById('transcript-box');
  const count = document.getElementById('words-count');
  if (!box) return;
  lastTranscript = full;
  const display = full + (interim ? ` <span class="text-text-muted">${interim}</span>` : '');
  box.innerHTML = display || '<span class="text-text-muted">Escuchando…</span>';
  const words = (full + ' ' + interim).trim().split(/\s+/).filter(Boolean).length;
  if (count) count.textContent = `${words} palabras`;
}

function enableActions(enable: boolean) {
  const save = document.getElementById('btn-save') as HTMLButtonElement;
  const sum = document.getElementById('btn-summarize') as HTMLButtonElement;
  [save, sum].forEach(b => {
    if (!b) return;
    b.disabled = !enable;
    b.classList.toggle('opacity-40', !enable);
  });
}

async function startAll() {
  recorder = new AudioRecorder();
  transcriber = new LiveTranscriber();

  await recorder.start((level) => updateWaveform(level));
  transcriber.start(setTranscript);

  isRecording = true;
  elapsed = 0;
  const badge = document.getElementById('rec-badge');
  const icon = document.getElementById('rec-icon');
  const btn = document.getElementById('btn-rec');
  badge?.classList.remove('hidden');
  badge?.classList.add('flex');
  if (icon) icon.textContent = 'stop';
  btn?.classList.add('bg-danger', 'border-danger/40');
  btn?.classList.remove('bg-violet-600', 'border-violet-400/40');

  timerId = window.setInterval(() => {
    elapsed++;
    const t = document.getElementById('rec-time');
    if (t) t.textContent = formatTime(elapsed);
  }, 1000);
}

async function stopAll() {
  if (!isRecording) return;
  isRecording = false;
  clearInterval(timerId);

  const finalText = transcriber?.stop() || lastTranscript;
  lastTranscript = finalText;

  let result = null;
  try {
    result = await recorder?.stop();
  } catch { /* */ }

  if (result) lastBlob = result.blob;

  const badge = document.getElementById('rec-badge');
  const icon = document.getElementById('rec-icon');
  const btn = document.getElementById('btn-rec');
  badge?.classList.add('hidden');
  badge?.classList.remove('flex');
  if (icon) icon.textContent = 'mic';
  btn?.classList.remove('bg-danger', 'border-danger/40');
  btn?.classList.add('bg-violet-600', 'border-violet-400/40');

  updateWaveform(0);
  setTranscript(finalText, '');
  enableActions(!!(finalText || lastBlob));

  // Auto-guardar transcripción
  if (finalText) {
    const id = uid();
    await saveItem({
      id,
      type: 'transcript',
      title: `Clase ${new Date().toLocaleString('es-AR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}`,
      content: finalText,
      meta: { durationSec: elapsed },
      createdAt: Date.now(),
      sizeBytes: finalText.length,
    });
  }
}

function wireMic() {
  const btnRec = document.getElementById('btn-rec');
  const btnSave = document.getElementById('btn-save');
  const btnSum = document.getElementById('btn-summarize');

  btnRec?.addEventListener('click', async () => {
    if (isRecording) {
      await stopAll();
    } else {
      try {
        await startAll();
      } catch (e) {
        alert('No se pudo acceder al micrófono. Revisá los permisos.');
        console.error(e);
      }
    }
  });

  btnSave?.addEventListener('click', async () => {
    if (!lastBlob) return;
    const id = uid();
    await saveBlob(id, lastBlob);
    await saveItem({
      id,
      type: 'audio',
      title: `Audio clase ${formatTime(elapsed)}`,
      content: lastTranscript || '(sin transcripción)',
      blobKey: id,
      meta: { durationSec: elapsed, sizeBytes: lastBlob.size, mime: lastBlob.type },
      createdAt: Date.now(),
      sizeBytes: lastBlob.size,
    });
    btnSave.textContent = '✓ Guardado';
    setTimeout(() => { if (btnSave) btnSave.textContent = 'Guardar audio'; }, 2000);
  });

  btnSum?.addEventListener('click', async () => {
    if (!lastTranscript) return;
    btnSum.setAttribute('disabled', 'true');
    btnSum.innerHTML = '<span class="material-symbols-outlined text-base animate-spin">progress_activity</span> Generando…';
    try {
      const summary = await aiSummary(lastTranscript, { style: 'clase', maxSentences: 7 });
      const id = uid();
      await saveItem({
        id,
        type: 'summary',
        title: `Resumen clase ${new Date().toLocaleString('es-AR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}`,
        content: summary,
        meta: { source: 'clase', words: lastTranscript.split(/\s+/).length },
        createdAt: Date.now(),
        sizeBytes: summary.length,
      });
      // Mostrar resumen en el box
      const box = document.getElementById('transcript-box');
      if (box) {
        box.innerHTML = `<p class="text-violet-300 text-xs mb-2 font-medium">✦ Resumen IA</p><p class="text-sm leading-relaxed">${summary.replace(/\n/g, '<br/>')}</p>`;
      }
    } catch (e) {
      alert('No se pudo generar el resumen');
    } finally {
      btnSum.removeAttribute('disabled');
      btnSum.innerHTML = '<span class="material-symbols-outlined text-base">auto_awesome</span> Resumen IA';
    }
  });
}
