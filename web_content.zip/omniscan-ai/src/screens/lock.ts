export function renderLockScreen(
  container: HTMLElement,
  onUnlock: (key: string) => void
) {
  container.innerHTML = `
    <div class="min-h-screen flex flex-col items-center justify-center px-6 bg-background relative overflow-hidden">
      <!-- Ambient glow -->
      <div class="absolute top-1/4 left-1/2 -translate-x-1/2 w-72 h-72 bg-violet-600/20 rounded-full blur-[100px] pointer-events-none"></div>
      <div class="absolute bottom-1/4 right-0 w-48 h-48 bg-fuchsia-500/10 rounded-full blur-[80px] pointer-events-none"></div>

      <!-- Logo frame -->
      <div class="mb-8 relative z-10">
        <div class="w-28 h-28 rounded-3xl bg-surface-2 frame-violet flex items-center justify-center">
          <svg viewBox="0 0 64 64" width="56" height="56" fill="none">
            <circle cx="32" cy="32" r="22" stroke="url(#vg)" stroke-width="2.5" stroke-dasharray="4 3"/>
            <circle cx="32" cy="32" r="14" stroke="#8b5cf6" stroke-width="2"/>
            <circle cx="32" cy="32" r="6" fill="#8b5cf6"/>
            <path d="M20 20h6M20 20v6M44 20h-6M44 20v6M20 44h6M20 44v-6M44 44h-6M44 44v-6" stroke="#a78bfa" stroke-width="2.5" stroke-linecap="round"/>
            <defs>
              <linearGradient id="vg" x1="0" y1="0" x2="64" y2="64">
                <stop stop-color="#8b5cf6"/><stop offset="1" stop-color="#22d3ee"/>
              </linearGradient>
            </defs>
          </svg>
        </div>
      </div>

      <h1 class="text-2xl font-bold tracking-tight text-text-primary relative z-10">OmniScan AI</h1>
      <p class="text-sm text-text-secondary mt-1 mb-10 relative z-10">Clave maestra · acceso local</p>

      <div class="w-full max-w-xs relative z-10 space-y-4">
        <input
          id="master-key"
          type="password"
          placeholder="••••••••••••"
          class="input-dark w-full text-center tracking-[0.3em] text-lg"
          autocomplete="off"
        />
        <button id="btn-unlock" class="btn-primary w-full flex items-center justify-center gap-2">
          <span class="material-symbols-outlined text-xl">lock_open</span>
          Desbloquear
        </button>
      </div>

      <p class="mt-14 text-[11px] text-text-muted relative z-10 text-center leading-relaxed">
        Todo queda en tu dispositivo<br/>
        Cifrado local · Sin cuentas
      </p>
    </div>
  `;

  const input = document.getElementById('master-key') as HTMLInputElement;
  const btn = document.getElementById('btn-unlock');
  const attempt = () => { if (input?.value) onUnlock(input.value.trim()); };
  btn?.addEventListener('click', attempt);
  input?.addEventListener('keydown', e => { if (e.key === 'Enter') attempt(); });
  setTimeout(() => input?.focus(), 250);
}
