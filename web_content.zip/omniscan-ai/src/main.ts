import './styles/main.css';
import { App } from '@capacitor/app';
import { StatusBar, Style } from '@capacitor/status-bar';
import { Capacitor } from '@capacitor/core';
import { SplashScreen } from '@capacitor/splash-screen';

import { renderLockScreen } from './screens/lock';
import { renderScanner } from './screens/scanner';
import { renderMic } from './screens/mic';
import { renderVault } from './screens/vault';
import { renderHistory } from './screens/history';
import { renderSettings } from './screens/settings';

const MASTER_KEY = 'SHIKITIT@2007';

export type Screen = 'lock' | 'scanner' | 'mic' | 'vault' | 'history' | 'settings';

let currentScreen: Screen = 'lock';
let isAuthenticated = sessionStorage.getItem('omni_auth') === '1';

async function initNative() {
  if (!Capacitor.isNativePlatform()) return;

  try {
    await StatusBar.setStyle({ style: Style.Dark });
    await StatusBar.setBackgroundColor({ color: '#0c0a12' });
  } catch { /* web */ }

  try {
    await SplashScreen.hide();
  } catch { /* */ }

  App.addListener('backButton', ({ canGoBack }) => {
    if (currentScreen !== 'lock' && currentScreen !== 'scanner') {
      navigate('scanner');
    } else if (canGoBack) {
      window.history.back();
    } else {
      App.exitApp();
    }
  });

  App.addListener('appStateChange', ({ isActive }) => {
    if (!isActive) {
      // App en segundo plano: no hacemos nada especial
    }
  });
}

export function navigate(screen: Screen) {
  if (screen !== 'lock' && !isAuthenticated) {
    currentScreen = 'lock';
  } else {
    currentScreen = screen;
  }
  render();
  // Scroll al tope al cambiar de pantalla
  window.scrollTo(0, 0);
}

function render() {
  const app = document.getElementById('app');
  if (!app) return;

  switch (currentScreen) {
    case 'lock':
      renderLockScreen(app, (key) => {
        if (key === MASTER_KEY) {
          isAuthenticated = true;
          sessionStorage.setItem('omni_auth', '1');
          navigate('scanner');
        } else {
          const input = document.getElementById('master-key') as HTMLInputElement;
          if (input) {
            input.classList.add('border-danger', 'animate-pulse');
            setTimeout(() => input.classList.remove('border-danger', 'animate-pulse'), 700);
          }
        }
      });
      break;
    case 'scanner':
      renderScanner(app, navigate);
      break;
    case 'mic':
      renderMic(app, navigate);
      break;
    case 'vault':
      renderVault(app, navigate);
      break;
    case 'history':
      renderHistory(app, navigate);
      break;
    case 'settings':
      renderSettings(app, navigate);
      break;
  }
}

(window as any).omniNavigate = navigate;

initNative().then(render);
