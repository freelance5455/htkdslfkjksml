/**
 * Generación de resúmenes con IA
 * - Preferencia: API externa configurable (OpenAI-compatible / Grok / etc.)
 * - Fallback: resumen extractivo local (sin red)
 */

export interface SummaryOptions {
  maxSentences?: number;
  style?: 'clase' | 'documento' | 'nota';
  apiKey?: string;
  endpoint?: string;
  model?: string;
}

const DEFAULT_ENDPOINT = 'https://api.openai.com/v1/chat/completions'; // o el que configures

/**
 * Resumen extractivo local (sin internet)
 * Selecciona oraciones más relevantes por frecuencia de términos
 */
export function localSummary(text: string, maxSentences = 5): string {
  if (!text || text.length < 40) return text;

  const sentences = text
    .replace(/\s+/g, ' ')
    .split(/(?<=[.!?…])\s+/)
    .map(s => s.trim())
    .filter(s => s.length > 20);

  if (sentences.length <= maxSentences) return sentences.join(' ');

  // Scoring simple por palabras significativas
  const stop = new Set(['el','la','los','las','de','del','un','una','y','o','a','en','que','por','con','para','se','su','al','es','lo','como','más','pero','sus','le','ya','o','fue','ser','han','hay']);
  const freq: Record<string, number> = {};
  const words = text.toLowerCase().match(/\b[a-záéíóúñ]{4,}\b/g) || [];
  words.forEach(w => {
    if (!stop.has(w)) freq[w] = (freq[w] || 0) + 1;
  });

  const scored = sentences.map((s, i) => {
    const sw = s.toLowerCase().match(/\b[a-záéíóúñ]{4,}\b/g) || [];
    let score = sw.reduce((acc, w) => acc + (freq[w] || 0), 0);
    // Bonus a primeras y últimas oraciones (estructura de clase)
    if (i < 2 || i > sentences.length - 3) score *= 1.25;
    return { s, score, i };
  });

  scored.sort((a, b) => b.score - a.score);
  const top = scored.slice(0, maxSentences).sort((a, b) => a.i - b.i);
  return top.map(t => t.s).join(' ');
}

/**
 * Resumen con IA externa (si el usuario configura API key)
 */
export async function aiSummary(text: string, opts: SummaryOptions = {}): Promise<string> {
  const key = opts.apiKey || localStorage.getItem('omni_ai_key') || '';
  const endpoint = opts.endpoint || localStorage.getItem('omni_ai_endpoint') || DEFAULT_ENDPOINT;
  const model = opts.model || localStorage.getItem('omni_ai_model') || 'gpt-4o-mini';

  if (!key) {
    // Sin key → resumen local
    return localSummary(text, opts.maxSentences || 6);
  }

  const styleHint = {
    clase: 'Sos un asistente de estudio. Generá un resumen claro y estructurado de esta clase o dictado, con los puntos principales, definiciones clave y conclusiones. Usá viñetas si ayuda.',
    documento: 'Resumí este documento de forma precisa, conservando datos importantes (números, nombres, fechas).',
    nota: 'Convertí esta nota en un resumen conciso y accionable.',
  }[opts.style || 'clase'];

  try {
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${key}`,
      },
      body: JSON.stringify({
        model,
        messages: [
          { role: 'system', content: styleHint },
          { role: 'user', content: text.slice(0, 12000) },
        ],
        temperature: 0.3,
        max_tokens: 800,
      }),
    });

    if (!res.ok) throw new Error(`API ${res.status}`);
    const data = await res.json();
    return data.choices?.[0]?.message?.content?.trim() || localSummary(text);
  } catch (e) {
    console.warn('AI summary falló, usando local:', e);
    return localSummary(text, opts.maxSentences || 6);
  }
}

export function saveAIConfig(key: string, endpoint?: string, model?: string) {
  if (key) localStorage.setItem('omni_ai_key', key);
  if (endpoint) localStorage.setItem('omni_ai_endpoint', endpoint);
  if (model) localStorage.setItem('omni_ai_model', model);
}
