/**
 * OCR en vivo / desde imagen usando Tesseract.js
 * Procesamiento 100% local en el dispositivo
 */

let workerPromise: Promise<any> | null = null;

async function getWorker() {
  if (!workerPromise) {
    workerPromise = (async () => {
      const Tesseract = await import('tesseract.js');
      const worker = await Tesseract.createWorker('spa'); // español
      await worker.setParameters({
        tessedit_pageseg_mode: '6', // bloque uniforme de texto
      });
      return worker;
    })();
  }
  return workerPromise;
}

export interface OCRResult {
  text: string;
  confidence: number;
  lines: string[];
}

export async function recognizeImage(source: HTMLCanvasElement | HTMLImageElement | string | Blob): Promise<OCRResult> {
  const worker = await getWorker();
  const { data } = await worker.recognize(source);
  const lines = (data.lines || [])
    .map((l: any) => l.text?.trim())
    .filter(Boolean);

  return {
    text: data.text?.trim() || '',
    confidence: Math.round(data.confidence || 0),
    lines,
  };
}

export async function captureFromVideo(video: HTMLVideoElement): Promise<OCRResult> {
  const canvas = document.createElement('canvas');
  canvas.width = video.videoWidth || 1280;
  canvas.height = video.videoHeight || 720;
  const ctx = canvas.getContext('2d')!;
  ctx.drawImage(video, 0, 0);
  return recognizeImage(canvas);
}

export function terminateOCR() {
  workerPromise?.then(w => w.terminate());
  workerPromise = null;
}
