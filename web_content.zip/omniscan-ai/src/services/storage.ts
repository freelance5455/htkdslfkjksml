/**
 * Almacenamiento local de OmniScan AI
 * Usa IndexedDB + localStorage. La única limitación es el espacio del dispositivo.
 */

const DB_NAME = 'omniscan_ai';
const DB_VERSION = 1;
const STORE = 'items';

export type ItemType = 'ocr' | 'audio' | 'transcript' | 'summary' | 'file';

export interface OmniItem {
  id: string;
  type: ItemType;
  title: string;
  content: string;          // texto OCR / transcripción / resumen
  blobKey?: string;         // referencia a blob de audio/imagen
  meta?: Record<string, any>;
  createdAt: number;
  sizeBytes?: number;
}

let dbPromise: Promise<IDBDatabase> | null = null;

function openDB(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onerror = () => reject(req.error);
    req.onsuccess = () => resolve(req.result);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) {
        const store = db.createObjectStore(STORE, { keyPath: 'id' });
        store.createIndex('type', 'type', { unique: false });
        store.createIndex('createdAt', 'createdAt', { unique: false });
      }
      if (!db.objectStoreNames.contains('blobs')) {
        db.createObjectStore('blobs', { keyPath: 'key' });
      }
    };
  });
  return dbPromise;
}

export async function saveItem(item: OmniItem): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).put(item);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function getAllItems(type?: ItemType): Promise<OmniItem[]> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readonly');
    const store = tx.objectStore(STORE);
    const req = type
      ? store.index('type').getAll(type)
      : store.getAll();
    req.onsuccess = () => {
      const items = (req.result as OmniItem[]).sort((a, b) => b.createdAt - a.createdAt);
      resolve(items);
    };
    req.onerror = () => reject(req.error);
  });
}

export async function deleteItem(id: string): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction([STORE, 'blobs'], 'readwrite');
    tx.objectStore(STORE).delete(id);
    tx.objectStore('blobs').delete(id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function saveBlob(key: string, blob: Blob): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('blobs', 'readwrite');
    tx.objectStore('blobs').put({ key, blob, size: blob.size });
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function getBlob(key: string): Promise<Blob | null> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('blobs', 'readonly');
    const req = tx.objectStore('blobs').get(key);
    req.onsuccess = () => resolve(req.result?.blob ?? null);
    req.onerror = () => reject(req.error);
  });
}

export async function estimateUsage(): Promise<{ usedMB: number; items: number }> {
  const items = await getAllItems();
  let total = 0;
  for (const it of items) total += it.sizeBytes || (it.content?.length || 0);
  return { usedMB: +(total / (1024 * 1024)).toFixed(2), items: items.length };
}

export function uid(): string {
  return `${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
}
