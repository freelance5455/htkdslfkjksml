/**
 * Grabación de audio con compresión (audio/webm;codecs=opus)
 * + transcripción con Web Speech API (alta sensibilidad)
 */

export interface RecordingResult {
  blob: Blob;
  durationMs: number;
  mimeType: string;
  sizeBytes: number;
}

export class AudioRecorder {
  private mediaRecorder: MediaRecorder | null = null;
  private chunks: Blob[] = [];
  private stream: MediaStream | null = null;
  private startTime = 0;
  private onLevel?: (level: number) => void;
  private analyser: AnalyserNode | null = null;
  private audioCtx: AudioContext | null = null;
  private rafId = 0;

  async start(onLevel?: (level: number) => void): Promise<void> {
    this.onLevel = onLevel;
    this.chunks = [];

    this.stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true,
        sampleRate: 16000, // suficiente para voz, reduce tamaño
        channelCount: 1,
      }
    });

    // Nivel de audio para UI
    this.audioCtx = new AudioContext();
    const source = this.audioCtx.createMediaStreamSource(this.stream);
    this.analyser = this.audioCtx.createAnalyser();
    this.analyser.fftSize = 256;
    source.connect(this.analyser);
    this.monitorLevel();

    // Preferir Opus (excelente compresión para voz)
    const mime = MediaRecorder.isTypeSupported('audio/webm;codecs=opus')
      ? 'audio/webm;codecs=opus'
      : MediaRecorder.isTypeSupported('audio/webm')
        ? 'audio/webm'
        : 'audio/mp4';

    this.mediaRecorder = new MediaRecorder(this.stream, {
      mimeType: mime,
      audioBitsPerSecond: 24000, // bitrate bajo = buena compresión para voz
    });

    this.mediaRecorder.ondataavailable = (e) => {
      if (e.data.size > 0) this.chunks.push(e.data);
    };

    this.startTime = Date.now();
    this.mediaRecorder.start(1000); // chunks cada 1s
  }

  private monitorLevel() {
    if (!this.analyser || !this.onLevel) return;
    const data = new Uint8Array(this.analyser.frequencyBinCount);
    const tick = () => {
      this.analyser!.getByteFrequencyData(data);
      const avg = data.reduce((a, b) => a + b, 0) / data.length / 255;
      this.onLevel!(avg);
      this.rafId = requestAnimationFrame(tick);
    };
    tick();
  }

  async stop(): Promise<RecordingResult> {
    return new Promise((resolve, reject) => {
      if (!this.mediaRecorder) {
        reject(new Error('No hay grabación activa'));
        return;
      }

      this.mediaRecorder.onstop = () => {
        cancelAnimationFrame(this.rafId);
        this.stream?.getTracks().forEach(t => t.stop());
        this.audioCtx?.close();

        const mimeType = this.mediaRecorder!.mimeType || 'audio/webm';
        const blob = new Blob(this.chunks, { type: mimeType });
        const durationMs = Date.now() - this.startTime;

        resolve({
          blob,
          durationMs,
          mimeType,
          sizeBytes: blob.size,
        });
      };

      this.mediaRecorder.stop();
    });
  }

  isRecording(): boolean {
    return this.mediaRecorder?.state === 'recording';
  }
}

/**
 * Transcripción en vivo con Web Speech API
 * Optimizado para clases / voz continua
 */
export class LiveTranscriber {
  private recognition: any = null;
  private finalText = '';
  private interim = '';
  private onUpdate?: (full: string, interim: string) => void;
  private continuous = true;

  constructor() {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SR) {
      console.warn('SpeechRecognition no disponible en este navegador');
      return;
    }
    this.recognition = new SR();
    this.recognition.lang = 'es-AR'; // o es-ES
    this.recognition.continuous = true;
    this.recognition.interimResults = true;
    this.recognition.maxAlternatives = 3; // más sensibilidad / alternativas

    this.recognition.onresult = (event: any) => {
      let interim = '';
      let finalChunk = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          finalChunk += transcript + ' ';
        } else {
          interim += transcript;
        }
      }
      if (finalChunk) this.finalText += finalChunk;
      this.interim = interim;
      this.onUpdate?.(this.finalText.trim(), this.interim);
    };

    this.recognition.onerror = (e: any) => {
      console.warn('Speech error:', e.error);
      // Reintentar en errores de red / no-speech
      if (e.error === 'no-speech' || e.error === 'network') {
        setTimeout(() => this.tryRestart(), 500);
      }
    };

    this.recognition.onend = () => {
      if (this.continuous) this.tryRestart();
    };
  }

  private tryRestart() {
    try {
      this.recognition?.start();
    } catch { /* already started */ }
  }

  start(onUpdate: (full: string, interim: string) => void) {
    this.onUpdate = onUpdate;
    this.finalText = '';
    this.interim = '';
    this.continuous = true;
    try {
      this.recognition?.start();
    } catch (e) {
      console.warn(e);
    }
  }

  stop(): string {
    this.continuous = false;
    try {
      this.recognition?.stop();
    } catch { /* */ }
    return this.finalText.trim();
  }

  getText(): string {
    return (this.finalText + ' ' + this.interim).trim();
  }
}
