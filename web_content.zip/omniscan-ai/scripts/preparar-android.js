/**
 * Después de "npx cap add android", este script agrega permisos
 * necesarios al AndroidManifest.xml automáticamente.
 */
import fs from 'fs';
import path from 'path';

const manifestPath = path.join('android', 'app', 'src', 'main', 'AndroidManifest.xml');

if (!fs.existsSync(manifestPath)) {
  console.log('⚠️  Todavía no existe la carpeta android.');
  console.log('   Primero corré: npx cap add android');
  process.exit(0);
}

let xml = fs.readFileSync(manifestPath, 'utf8');

const permissions = [
  'android.permission.CAMERA',
  'android.permission.RECORD_AUDIO',
  'android.permission.MODIFY_AUDIO_SETTINGS',
  'android.permission.INTERNET',
  'android.permission.ACCESS_NETWORK_STATE',
  'android.permission.READ_MEDIA_IMAGES',
  'android.permission.READ_EXTERNAL_STORAGE',
  'android.permission.WRITE_EXTERNAL_STORAGE',
];

let changed = false;
for (const p of permissions) {
  const tag = `<uses-permission android:name="${p}" />`;
  if (!xml.includes(p)) {
    // Insertar después de <manifest ...>
    xml = xml.replace(
      /(<manifest[^>]*>)/,
      `$1\n    ${tag}`
    );
    changed = true;
    console.log('  + permiso:', p);
  }
}

// features de cámara y micrófono
const features = [
  '<uses-feature android:name="android.hardware.camera" android:required="false" />',
  '<uses-feature android:name="android.hardware.microphone" android:required="false" />',
];
for (const f of features) {
  if (!xml.includes(f.split('"')[1])) {
    xml = xml.replace(/(<manifest[^>]*>)/, `$1\n    ${f}`);
    changed = true;
  }
}

if (changed) {
  fs.writeFileSync(manifestPath, xml);
  console.log('✓ AndroidManifest.xml actualizado con permisos.');
} else {
  console.log('✓ Permisos ya estaban configurados.');
}
