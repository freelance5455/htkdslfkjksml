# Pravin~Tube — starter project

A dark-theme Expo app scaffold for Android and Web.

## Included in this starter
- Responsive React Native / Expo shell
- Video playback via `expo-video`
- Search, local-session video list, playlists (session-only)
- Add a direct HTTPS video URL you own or are licensed to embed
- Pick a local video file for playback during the current app session
- Playback speed control and Picture-in-Picture capability where supported
- Free Premium information screen (₹0)
- Device offline saving for direct HTTPS files that the user owns or is licensed to download
- Background playback enabled where the platform and device support it

## Not implemented yet
- Permanent user accounts and cloud upload
- Persistent playlists and download library
- Persistent download-library indexing across app restarts
- Background audio behavior on every platform and lock-screen media controls
- Ad serving / ad-free subscription
- External provider integrations
- Production moderation, copyright reporting, analytics and security review

The UI deliberately does not scrape YouTube or bypass YouTube Premium, DRM, or download restrictions. Add external providers only through official APIs/embeds and in accordance with their terms. Offline downloads should be enabled only for media whose license explicitly permits downloading.

## Run
1. Install Node.js LTS.
2. Extract this folder.
3. Run `npm install`.
4. Run `npx expo install --check` and resolve any SDK compatibility suggestions.
5. Run `npm run start` for Expo, or `npm run web` for the web version.
6. Use Expo Go or a development build for Android testing.

## Backend setup
1. Create a Supabase project.
2. Run `supabase/schema.sql` in its SQL editor.
3. Create a private Storage bucket named `videos`.
4. Add authentication and Storage policies before accepting real user uploads.
5. Store only provider-approved URLs and license/download permissions.

Never put Supabase service-role keys in the mobile app. Use a restricted anon/publishable key and Row Level Security. Before public launch, add upload size limits, file-type validation, moderation/reporting, privacy policy, and copyright takedown workflow.


See `NEXT_PHASE.md` for Google sign-in, profiles, cloud playlists, user uploads, and official YouTube API integration setup. Credentials are not included; you must create your own Supabase and Google Cloud projects.
