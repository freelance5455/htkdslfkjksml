# Pravin~Tube — next phase: accounts, profiles, playlists, uploads, YouTube

This phase is designed around:
- Google sign-in through Supabase Auth (OAuth / Google provider).
- A user profile row linked to `auth.users`.
- User-owned playlists and playlist items.
- Uploading user-owned videos to a private Supabase Storage bucket.
- YouTube discovery through the official YouTube Data API v3 and playback through the official YouTube embedded player / approved platform integrations.

## Important YouTube boundary
YouTube videos can appear in search/discovery using the official YouTube Data API, and can be played using YouTube's supported embedded player. This app must respect YouTube API terms, attribution, playback, branding, and user-data rules. It must not download YouTube videos, remove ads, extract stream URLs, bypass DRM, or imitate YouTube Premium entitlements. Offline downloads apply only to the user's own files or third-party media whose license explicitly permits downloads.

## Supabase setup
1. Create a Supabase project.
2. In Authentication > Providers, enable Google and configure the Google OAuth client IDs and secret from Google Cloud Console.
3. Add the app's redirect URL(s) to Supabase Auth redirect allow-list. For Expo development, configure a stable app scheme and use the Expo AuthSession redirect URI.
4. Run `supabase/schema.sql` in the SQL editor.
5. Create a **private** Storage bucket named `videos`.
6. Apply Storage RLS policies so authenticated users can upload/read only their own object paths, e.g. `<auth.uid()>/<filename>`.
7. Add the Supabase URL and publishable/anon key to `.env` (copy `.env.example`). Never put a service-role key in the app.

## Google OAuth setup
- Create OAuth credentials in Google Cloud Console for Web and Android.
- Configure the correct package name (`com.pravin.tube`) and SHA-1 fingerprints for the Android build.
- Add the web client ID and Android client ID to `.env`.
- Configure the Google provider in Supabase with the OAuth client ID/secret.
- OAuth callback/deep-link behavior must be tested in an Expo development build, not assumed to work in Expo Go.

## YouTube API setup
- Enable YouTube Data API v3 in Google Cloud Console.
- Create a restricted API key; restrict it to the YouTube Data API and appropriate app/API restrictions.
- Set `EXPO_PUBLIC_YOUTUBE_API_KEY`.
- Respect quotas, API attribution requirements, and YouTube branding guidelines. Do not expose private keys; the YouTube Data API key is public-client configuration and should be restricted.

## Upload rules
- Accept only video MIME types and enforce file-size limits.
- Upload to private storage.
- Save metadata in `public.videos`.
- Use signed URLs for playback where appropriate.
- Add moderation, reporting, copyright complaint/takedown handling, and abuse controls before public launch.

## Still required before release
- Implement and test Google OAuth callback flow for both Android and web.
- Implement profile editing and account deletion.
- Add persistent playlist CRUD and video metadata.
- Implement resumable/chunked uploads for large files and progress UI.
- Implement YouTube API search + official embedded player.
- Implement licensed offline-download workflow.
- Add background audio only for content/providers that permit it and where the OS/platform supports it.
- Security review, privacy policy, terms, content moderation, and production testing.
