import React, { useEffect, useMemo, useState } from "react";
import {
  SafeAreaView, View, Text, TextInput, Pressable, ScrollView,
  StyleSheet, Alert, Platform
} from "react-native";
import { StatusBar } from "expo-status-bar";
import { VideoView, useVideoPlayer } from "expo-video";
import * as DocumentPicker from "expo-document-picker";
import * as FileSystem from "expo-file-system/legacy";

type VideoItem = {
  id: string; title: string; creator: string; url: string;
  source: "demo" | "external" | "upload"; category: string;
};

const DEMO_VIDEOS: VideoItem[] = [
  {
    id: "demo-1",
    title: "Big Buck Bunny — sample video",
    creator: "Blender Foundation",
    url: "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
    source: "demo",
    category: "Entertainment"
  },
  {
    id: "demo-2",
    title: "For Bigger Joyrides — sample video",
    creator: "Google sample media",
    url: "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4",
    source: "demo",
    category: "Travel"
  }
];

const C = {
  bg: "#0b0b0f", panel: "#17171e", panel2: "#22222b",
  text: "#f7f7fa", muted: "#a5a5b2", red: "#ff343d",
  border: "#30303a", green: "#4bd49a"
};

function Action({ label, onPress, active = false }: {
  label: string; onPress: () => void; active?: boolean
}) {
  return (
    <Pressable onPress={onPress} style={[styles.pill, active && styles.pillActive]}>
      <Text style={[styles.pillText, active && { color: "#fff" }]}>{label}</Text>
    </Pressable>
  );
}

export default function App() {
  const [videos, setVideos] = useState<VideoItem[]>(DEMO_VIDEOS);
  const [query, setQuery] = useState("");
  const [tab, setTab] = useState("Home");
  const [selected, setSelected] = useState<VideoItem>(DEMO_VIDEOS[0]);
  const [urlInput, setUrlInput] = useState("");
  const [titleInput, setTitleInput] = useState("");
  const [savedIds, setSavedIds] = useState<string[]>([]);
  const [speed, setSpeed] = useState(1);
  const [mini, setMini] = useState(false);
  const [downloads, setDownloads] = useState<VideoItem[]>([]);
  const [downloading, setDownloading] = useState(false);

  const player = useVideoPlayer(selected.url, p => {
    p.loop = false;
    p.playbackRate = speed;
    p.staysActiveInBackground = true;
  });

  useEffect(() => {
    player.replaceAsync(selected.url)
      .then(() => { player.playbackRate = speed; player.staysActiveInBackground = true; })
      .catch(() => {});
  }, [selected.url]);

  const filtered = useMemo(() => videos.filter(v =>
    (tab === "Uploads" ? v.source === "upload" : true) &&
    (tab === "Playlists" ? savedIds.includes(v.id) : true) &&
    (tab === "Downloads" ? downloads.some(d => d.id === v.id) : true) &&
    (tab === "Premium" ? false : true) &&
    (v.title + " " + v.creator + " " + v.category).toLowerCase().includes(query.toLowerCase())
  ), [videos, query, tab, savedIds]);

  const play = (v: VideoItem) => {
    setSelected(v);
    setMini(false);
    // expo-video player is bound to selected.url; playback starts after source changes.
  };

  const addExternal = () => {
    const clean = urlInput.trim();
    if (!/^https:\/\/.+/i.test(clean)) {
      Alert.alert("HTTPS link required", "Paste a direct HTTPS video URL that you own or are licensed to use.");
      return;
    }
    const item: VideoItem = {
      id: `external-${Date.now()}`,
      title: titleInput.trim() || "External video",
      creator: "Added by you",
      url: clean,
      source: "external",
      category: "My videos"
    };
    setVideos(old => [item, ...old]);
    setUrlInput("");
    setTitleInput("");
    setTab("Home");
    setSelected(item);
  };

  const pickUpload = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: ["video/*"], copyToCacheDirectory: true
      });
      if (result.canceled) return;
      const file = result.assets[0];
      const item: VideoItem = {
        id: `upload-${Date.now()}`,
        title: file.name,
        creator: "Local device",
        url: file.uri,
        source: "upload",
        category: "Uploads"
      };
      setVideos(old => [item, ...old]);
      setSelected(item);
      setTab("Uploads");
      Alert.alert("Added to this session", "This local file is available in the current app session. Cloud upload and permanent storage need backend setup.");
    } catch {
      Alert.alert("Could not open file", "Please try selecting the video again.");
    }
  };

  const toggleSave = (id: string) => setSavedIds(old =>
    old.includes(id) ? old.filter(x => x !== id) : [...old, id]
  );

  const changeSpeed = (next: number) => {
    setSpeed(next);
    player.playbackRate = next;
  };

  const downloadSelected = async () => {
    if (selected.source === "demo" || !selected.url.startsWith("https://")) {
      Alert.alert("Download unavailable", "Offline saving is available only for direct HTTPS videos that you own or are licensed to download.");
      return;
    }
    if (downloads.some(d => d.id === selected.id)) {
      Alert.alert("Already saved", "This video is already in your offline library.");
      return;
    }
    try {
      setDownloading(true);
      const dir = FileSystem.documentDirectory + "pravin-tube-downloads/";
      await FileSystem.makeDirectoryAsync(dir, { intermediates: true });
      const safeName = (selected.title || "video").replace(/[^a-z0-9-_]/gi, "_").slice(0, 50);
      const target = dir + `${Date.now()}-${safeName}.mp4`;
      const result = await FileSystem.downloadAsync(selected.url, target);
      const saved = { ...selected, url: result.uri };
      setDownloads(old => [saved, ...old]);
      Alert.alert("Saved offline", "The permitted video has been saved on this device. This starter build keeps the download list for the current session.");
    } catch {
      Alert.alert("Download failed", "The source may block direct downloads or may not be a downloadable video file.");
    } finally {
      setDownloading(false);
    }
  };

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="light" />
      <View style={styles.header}>
        <View style={styles.brandMark}><Text style={styles.brandPlay}>▶</Text></View>
        <View style={{ flex: 1 }}>
          <Text style={styles.brand}>Pravin~Tube</Text>
          <Text style={styles.tagline}>Watch • Listen • Save</Text>
        </View>
        <Text style={styles.avatar}>P</Text>
      </View>

      <TextInput
        value={query} onChangeText={setQuery}
        placeholder="Search videos..." placeholderTextColor={C.muted}
        style={styles.search}
      />

      <View style={styles.tabs}>
        {["Home", "Uploads", "Playlists", "Downloads", "Premium"].map(t =>
          <Action key={t} label={t} active={tab === t} onPress={() => setTab(t)} />
        )}
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.playerCard}>
          <View style={styles.playerTop}>
            <Text style={styles.sectionTitle}>Now playing</Text>
            <Text style={styles.quality}>HD-ready*</Text>
          </View>
          <VideoView
            style={styles.video}
            player={player}
            nativeControls
            contentFit="contain"
            allowsFullscreen
            allowsPictureInPicture
          />
          <Text style={styles.videoTitle}>{selected.title}</Text>
          <Text style={styles.muted}>{selected.creator}</Text>
          <View style={styles.controls}>
            <Action label={mini ? "Show player" : "Mini player"} onPress={() => setMini(!mini)} active={mini} />
            <Action label={`Speed ${speed}x`} onPress={() => changeSpeed(speed === 1 ? 1.25 : speed === 1.25 ? 1.5 : speed === 1.5 ? 2 : 1)} />
            <Action label={savedIds.includes(selected.id) ? "Saved ✓" : "＋ Playlist"} onPress={() => toggleSave(selected.id)} active={savedIds.includes(selected.id)} />
            <Action label={downloading ? "Saving…" : downloads.some(d => d.id === selected.id) ? "Offline ✓" : "↓ Download"} onPress={downloadSelected} active={downloads.some(d => d.id === selected.id)} />
          </View>
          {mini && <Text style={styles.notice}>Mini-player mode selected. Floating overlay behavior will be added in the next iteration.</Text>}
        </View>

        {tab === "Premium" && (
          <View style={styles.addCard}>
            <Text style={styles.sectionTitle}>Pravin~Tube Premium</Text>
            <Text style={styles.freePrice}>₹0 · FREE FOREVER</Text>
            <Text style={styles.muted}>No monthly fee and no yearly fee. Premium-style features are free in Pravin~Tube.</Text>
            <Text style={styles.featureLine}>✓ Ad-free Pravin~Tube experience</Text>
            <Text style={styles.featureLine}>✓ Offline downloads for permitted videos</Text>
            <Text style={styles.featureLine}>✓ Background playback where supported</Text>
            <Text style={styles.featureLine}>✓ HD playback when the source provides it</Text>
            <Text style={styles.notice}>YouTube ads and YouTube download restrictions remain controlled by YouTube.</Text>
          </View>
        )}

        {tab === "Home" && (
          <View style={styles.addCard}>
            <Text style={styles.sectionTitle}>Add a permitted video URL</Text>
            <Text style={styles.muted}>Use a direct video file URL or a source whose terms allow embedding.</Text>
            <TextInput value={titleInput} onChangeText={setTitleInput}
              placeholder="Video title" placeholderTextColor={C.muted} style={styles.field} />
            <TextInput value={urlInput} onChangeText={setUrlInput}
              placeholder="https://.../video.mp4" placeholderTextColor={C.muted}
              autoCapitalize="none" style={styles.field} />
            <Pressable style={styles.primaryButton} onPress={addExternal}>
              <Text style={styles.primaryText}>＋ Add video link</Text>
            </Pressable>
            <Pressable style={styles.secondaryButton} onPress={pickUpload}>
              <Text style={styles.secondaryText}>↑ Choose a video from device</Text>
            </Pressable>
          </View>
        )}

        <Text style={styles.sectionTitle}>
          {tab === "Uploads" ? "Your local uploads" : tab === "Playlists" ? "Saved playlist" : "Videos for you"}
        </Text>
        {filtered.map(v => (
          <Pressable key={v.id} style={styles.videoRow} onPress={() => play(v)}>
            <View style={styles.thumbnail}><Text style={styles.thumbnailPlay}>▶</Text></View>
            <View style={{ flex: 1 }}>
              <Text style={styles.videoTitle}>{v.title}</Text>
              <Text style={styles.muted}>{v.creator} • {v.category}</Text>
              <Text style={styles.source}>{v.source.toUpperCase()}</Text>
            </View>
            <Pressable onPress={() => toggleSave(v.id)} hitSlop={10}>
              <Text style={styles.bookmark}>{savedIds.includes(v.id) ? "★" : "☆"}</Text>
            </Pressable>
          </Pressable>
        ))}
        {filtered.length === 0 && <Text style={styles.muted}>No videos here yet. Add a video or save one to your playlist.</Text>}

        {tab !== "Premium" && <View style={styles.downloadCard}>
          <Text style={styles.sectionTitle}>Offline downloads · {downloads.length} saved</Text>
          <Text style={styles.muted}>Save only direct video files you own or are explicitly allowed to download. YouTube videos cannot be downloaded through this app.</Text>
          {downloads.map(d => <Pressable key={d.id} style={styles.videoRow} onPress={() => play(d)}><View style={styles.thumbnail}><Text style={styles.thumbnailPlay}>↓</Text></View><View style={{ flex: 1 }}><Text style={styles.videoTitle}>{d.title}</Text><Text style={styles.muted}>Saved on this device</Text></View></Pressable>)}
        </View>}
        <Text style={styles.footnote}>*HD depends on the source file and network. This is an early development build; no ad network or account system is connected yet.</Text>
      </ScrollView>

      <View style={styles.bottomNav}>
        {["Home", "Uploads", "Playlists", "Downloads", "Premium"].map(t => (
          <Pressable key={t} onPress={() => setTab(t)} style={styles.navItem}>
            <Text style={[styles.navText, tab === t && { color: C.red }]}>{t === "Home" ? "⌂" : t === "Uploads" ? "＋" : t === "Playlists" ? "▤" : t === "Downloads" ? "↓" : "♛"}</Text>
            <Text style={[styles.navLabel, tab === t && { color: C.red }]}>{t}</Text>
          </Pressable>
        ))}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: C.bg, paddingTop: Platform.OS === "android" ? 8 : 0 },
  header: { flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingVertical: 12, gap: 10 },
  brandMark: { width: 38, height: 38, borderRadius: 12, backgroundColor: C.red, alignItems: "center", justifyContent: "center" },
  brandPlay: { color: "#fff", fontSize: 19, fontWeight: "900" },
  brand: { color: C.text, fontSize: 21, fontWeight: "900" },
  tagline: { color: C.muted, fontSize: 11, marginTop: 1 },
  avatar: { color: "#fff", backgroundColor: C.panel2, overflow: "hidden", borderRadius: 20, width: 34, height: 34, textAlign: "center", textAlignVertical: "center", fontWeight: "800" },
  search: { marginHorizontal: 16, marginBottom: 12, backgroundColor: C.panel, borderColor: C.border, borderWidth: 1, borderRadius: 13, color: C.text, paddingHorizontal: 14, paddingVertical: 12 },
  tabs: { flexDirection: "row", gap: 8, paddingHorizontal: 16, marginBottom: 8 },
  pill: { borderRadius: 20, borderWidth: 1, borderColor: C.border, paddingHorizontal: 12, paddingVertical: 8, backgroundColor: C.panel },
  pillActive: { backgroundColor: C.red, borderColor: C.red },
  pillText: { color: C.muted, fontSize: 12, fontWeight: "700" },
  content: { padding: 16, paddingBottom: 90, gap: 14 },
  playerCard: { backgroundColor: C.panel, borderRadius: 18, padding: 12, borderWidth: 1, borderColor: C.border },
  playerTop: { flexDirection: "row", justifyContent: "space-between", marginBottom: 10, alignItems: "center" },
  sectionTitle: { color: C.text, fontSize: 16, fontWeight: "800", marginBottom: 8 },
  quality: { color: C.green, fontSize: 11, fontWeight: "700" },
  video: { width: "100%", aspectRatio: 16 / 9, backgroundColor: "#000", borderRadius: 12 },
  videoTitle: { color: C.text, fontSize: 14, fontWeight: "700", marginTop: 9 },
  muted: { color: C.muted, fontSize: 12, lineHeight: 18 },
  controls: { flexDirection: "row", flexWrap: "wrap", gap: 7, marginTop: 12 },
  notice: { color: "#e5bd73", fontSize: 11, marginTop: 8, lineHeight: 16 },
  addCard: { backgroundColor: C.panel, padding: 14, borderRadius: 16, borderWidth: 1, borderColor: C.border, gap: 9 },
  field: { color: C.text, backgroundColor: C.bg, borderWidth: 1, borderColor: C.border, borderRadius: 10, padding: 11, fontSize: 13 },
  primaryButton: { backgroundColor: C.red, borderRadius: 11, padding: 12, alignItems: "center" },
  primaryText: { color: "#fff", fontWeight: "800" },
  secondaryButton: { backgroundColor: C.panel2, borderRadius: 11, padding: 12, alignItems: "center" },
  secondaryText: { color: C.text, fontWeight: "700" },
  videoRow: { flexDirection: "row", gap: 11, alignItems: "center", paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: C.border },
  thumbnail: { width: 104, height: 66, backgroundColor: C.panel2, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  thumbnailPlay: { color: C.red, fontSize: 23 },
  source: { color: C.green, fontSize: 9, fontWeight: "800", marginTop: 4 },
  bookmark: { color: "#ffd166", fontSize: 24, padding: 5 },
  downloadCard: { backgroundColor: C.panel, borderRadius: 16, padding: 14, borderWidth: 1, borderColor: C.border },
  footnote: { color: "#777783", fontSize: 10, lineHeight: 15 },
  freePrice: { color: C.green, fontSize: 24, fontWeight: "900", marginVertical: 5 },
  featureLine: { color: C.text, fontSize: 13, marginTop: 5 },
  bottomNav: { position: "absolute", bottom: 0, left: 0, right: 0, backgroundColor: "#14141a", borderTopWidth: 1, borderTopColor: C.border, flexDirection: "row", justifyContent: "space-around", paddingTop: 9, paddingBottom: 12 },
  navItem: { alignItems: "center", minWidth: 75, gap: 2 },
  navText: { color: C.muted, fontSize: 21 },
  navLabel: { color: C.muted, fontSize: 10, fontWeight: "600" }
});
