-- Pravin~Tube Supabase schema
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.videos (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  description text,
  source_type text not null check (source_type in ('upload', 'licensed_external', 'youtube')),
  storage_path text,
  external_url text,
  youtube_video_id text,
  is_downloadable boolean not null default false,
  created_at timestamptz not null default now(),
  constraint valid_video_source check (
    (source_type = 'upload' and storage_path is not null and external_url is null and youtube_video_id is null)
    or
    (source_type = 'licensed_external' and external_url is not null and storage_path is null and youtube_video_id is null)
    or
    (source_type = 'youtube' and youtube_video_id is not null and storage_path is null and external_url is null)
  )
);

create table if not exists public.playlists (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  is_public boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.playlist_items (
  playlist_id uuid not null references public.playlists(id) on delete cascade,
  video_id uuid not null references public.videos(id) on delete cascade,
  added_at timestamptz not null default now(),
  primary key (playlist_id, video_id)
);

alter table public.profiles enable row level security;
alter table public.videos enable row level security;
alter table public.playlists enable row level security;
alter table public.playlist_items enable row level security;

create policy "profile owner reads and updates own profile" on public.profiles
  for all using (auth.uid() = id) with check (auth.uid() = id);

create policy "owners manage their videos" on public.videos
  for all using (auth.uid() = owner_id) with check (auth.uid() = owner_id);

create policy "owners manage their playlists" on public.playlists
  for all using (auth.uid() = owner_id) with check (auth.uid() = owner_id);

create policy "playlist owners manage items" on public.playlist_items
  for all using (
    exists (select 1 from public.playlists p
      where p.id = playlist_id and p.owner_id = auth.uid())
  )
  with check (
    exists (select 1 from public.playlists p
      where p.id = playlist_id and p.owner_id = auth.uid())
  );

-- Create a profile automatically when a new auth user is registered.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles (id, display_name, avatar_url)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name'),
    new.raw_user_meta_data->>'avatar_url'
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- Create a private Storage bucket named `videos` in the Supabase dashboard.
-- Storage object names should begin with the authenticated user's UUID.
-- Add Storage policies in the dashboard/SQL editor appropriate to your bucket setup.
