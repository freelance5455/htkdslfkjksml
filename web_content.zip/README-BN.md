# Friendship — Final MVP (Web + HTML-to-APK source)

This package extends the first starter with a More hub, Moments page, Notifications page, read-only Wallet/Gift catalogue, Ludo lobby view, Admin placeholder, and audio/video call connection attempts using the deployed LiveKit token Edge Function.

## Configuration already included
- Supabase project URL and publishable key in `config.js`
- LiveKit WebSocket URL in `config.js`
- Current deployed Edge Function slug: `quick-task` (endpoint `/functions/v1/quick-task`)

## Features currently implemented
- Email signup/login
- Profile view/edit
- User search and follow
- Direct chat creation using `create_direct_conversation`
- Text messaging and realtime message subscription
- Text Moments feed and post creation
- Public voice-room create/list/join with LiveKit token request
- Basic audio/video call connection attempt from a chat
- Notifications list (reads existing notifications)
- Wallet balance and gift catalogue read-only views
- Ludo lobby list view
- Admin panel placeholder with no client-side privilege escalation

## Not yet production-complete
The following require additional trusted backend work and must not be treated as live features yet:
- Remote participant video rendering, incoming-call invitations/signaling, room seats/moderator tools
- Image/video uploads, moderation, block/report, privacy/account deletion
- Secure wallet top-ups and gift transfers (server-side transactional RPC/Edge Function, idempotency, audit logs, payment provider)
- Actual multiplayer Ludo game engine with server-validated dice/moves and anti-cheat
- Push notifications (FCM registration and delivery)
- Admin role provisioning, moderation actions, audit log and strict admin RLS
- Full security review of all existing SQL/RLS policies with at least two test users

Wallet gift-send and Ludo actions are intentionally disabled until secure backend logic exists. Admin panel is intentionally restricted. Never put Supabase service-role/secret key, database password, or LiveKit API Secret in this project.

## Use with HTML to APK Builder
The ZIP contains `index.html` at its root. Import the ZIP if the builder supports root-index HTML projects. Enable internet access and grant microphone/camera permissions when prompted. CDN scripts and Supabase/LiveKit cloud services require an internet connection. Builder import behavior can vary; test on device before release.

## Web hosting
Upload the extracted files to a static host. Serve over HTTPS; do not open the page as a local `file://` URL.
