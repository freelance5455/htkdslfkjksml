Zain Ayaz Digital Attendance — Android-installable PWA package

Included: student list, daily attendance, login screen, QR camera scanning, student QR-card display, CSV export, JSON backup/restore, local browser storage, PWA manifest/service worker.

Demo login: admin
Demo password: Zain@12345

IMPORTANT LIMITATIONS
- This package is an installable web app (PWA), not a signed native APK. To install from Chrome, upload all files to an HTTPS static host, open the URL on Android Chrome, then select menu > Install app / Add to Home screen.
- Camera QR scanning requires HTTPS (or localhost) and camera permission. Scanner and QR generator libraries load from CDNs, so internet is needed for those features.
- This scans QR codes, not RFID chips. Actual RFID requires a compatible external reader/controller; a phone without NFC cannot read RFID chips directly.
- Login is a local demo gate only, not secure server-side authentication. All records are stored in this browser on this device. Do not use for sensitive real student data without secure authentication, backups, and school approval.
- Back up data regularly using the JSON backup button. Clearing browser storage can erase records.
