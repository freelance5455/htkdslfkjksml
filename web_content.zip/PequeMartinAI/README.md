# PequeMartín AI
Aplicación familiar offline-first para registrar crecimiento, alimentación, síntomas, desarrollo e informes.

## Incluye
- Guardado local, perfil editable y estimación de edad corregida.
- Peso, talla y perímetro craneal con gráficos de valores registrados.
- Tomas, síntomas, fotografías locales, actividades e hitos.
- Informe TXT y respaldo/restauración JSON.
- PWA offline y workflow para compilar APK Android.

## Compilar APK
1. Sube el contenido del ZIP al repositorio `rodolfoalbornozk-spec/pequemartin.` en la rama `main`.
2. Abre Actions y ejecuta `Build PequeMartin APK`.
3. Descarga el artefacto `PequeMartin-debug-APK` de la ejecución finalizada.
4. Extrae `app-debug.apk` y transfiérelo a tu tablet Android para instalarlo.

El APK es de depuración, no está firmado para Play Store. La IA generativa conectada no está habilitada; hace falta un backend privado para usar una API sin exponer la clave en el APK. Los gráficos muestran datos registrados y no calculan percentiles OMS oficiales. Los informes no son diagnósticos. Exporta respaldos regularmente; borrar datos o desinstalar puede eliminar registros.
