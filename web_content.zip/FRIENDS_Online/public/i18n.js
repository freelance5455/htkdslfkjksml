// Tiny i18n layer: English (en), Pashto (ps), Dari (fa). RTL is switched automatically.
export const LANGS = { en: { dir: 'ltr' }, ps: { dir: 'rtl' }, fa: { dir: 'rtl' } };

const D = {
  en: {
    offline: 'You are offline.', email: 'Email address', password: 'Password', login: 'Log in',
    forgot: 'Forgot password?', createAccount: 'Create new account', signupTitle: 'Create a new account',
    fullName: 'Full name', newPassword: 'New password (6+ characters)', signup: 'Sign up',
    haveAccount: 'Already have an account? Log in', usePhone: 'Use phone number instead', sendCode: 'Send code',
    smsCode: 'SMS code', verifyPhone: 'Verify', signInStatus: 'Sign in to connect with your friends.',
    home: 'Home', friends: 'Friends', reels: 'Reels', groups: 'Groups', notifications: 'Notifications', menu: 'Menu',
    messages: 'Messages', create: 'Create', search: 'Search', searchPh: 'Search FRIENDS',
    whatsOnMind: "What's on your mind?", photoVideo: 'Photo/video', story: 'Story', createStory: 'Create story',
    reel: 'Reel', createPost: 'Create post', post: 'Post', posting: 'Posting…', public: 'Public', friendsOnly: 'Friends',
    like: 'Like', comment: 'Comment', share: 'Share', writeComment: 'Write a comment…', send: 'Send',
    delete: 'Delete', cancel: 'Cancel', save: 'Save', confirm: 'Confirm', addFriend: 'Add friend',
    requested: 'Request sent', cancelRequest: 'Cancel request', unfriend: 'Unfriend', message: 'Message',
    friendRequests: 'Friend requests', peopleMayKnow: 'People you may know', yourFriends: 'Your friends',
    contacts: 'Contacts', noPosts: 'No posts yet. Share something with your friends!',
    noFriends: 'No friends yet. Search for people to connect with.', noNotifications: 'No notifications yet.',
    noResults: 'No results found.', newGroup: 'Create group', groupName: 'Group name', description: 'Description',
    join: 'Join', leave: 'Leave', members: '{n} members', owner: 'Owner', sell: 'Sell something', market: 'Marketplace',
    itemTitle: 'Title', price: 'Price', publish: 'Publish', messageSeller: 'Message seller', profile: 'Profile',
    editProfile: 'Edit profile', displayName: 'Display name', bio: 'About me', changePhoto: 'Change photo',
    resendVerify: 'Resend', verifyBanner: 'Please verify your email address.', wallet: 'Creator wallet', live: 'Live',
    admin: 'Admin', darkMode: 'Dark mode', language: 'Language', logout: 'Log out',
    writeMessage: 'Write a message…', startChat: 'Choose a friend to start chatting.', noChats: 'No conversations yet.',
    back: 'Back', now: 'Just now', caption: 'Add a caption…', textStory: 'Text', mediaStory: 'Photo/video',
    typeSomething: 'Type something…', shareStory: 'Share to story', confirmDelete: 'Delete this? This cannot be undone.',
    copied: 'Link copied.', loginFirst: 'Please log in first.', postingIn: 'Posting in {name}', comments: '{n} comments',
    commentsOne: '1 comment', users: 'Users', posts: 'Posts', listings: 'Listings', posted: 'Your post is online.',
    storyShared: 'Story shared for 24 hours.', saved: 'Saved.', reelShared: 'Reel published.', listingShared: 'Listing published.',
    groupCreated: 'Group created.', verifySent: 'Verification email sent.', resetSent: 'Password reset email sent. Check Inbox and Spam.',
    codeSent: 'Code sent by SMS.', enterEmail: 'Enter a valid email address.', enterPassword: 'Enter your password.',
    fillAll: 'Enter your name, email and password.', chooseFile: 'Choose a file first.', writeSomething: 'Write something or choose a photo/video.',
    fileBig: 'File is too large.', onlyMedia: 'Only images and videos are allowed.', reqSent: 'Friend request sent.',
    noReels: 'No reels yet. Be the first to upload one!', noGroups: 'No groups yet.', noListings: 'Nothing for sale yet.',
    friendsPost: 'Friends', publicPost: 'Public', suggestionsEmpty: 'No suggestions right now.', noRequests: 'No pending requests.',
    'n.like': '{name} liked your post.', 'n.comment': '{name} commented on your post.',
    'n.friend_request': '{name} sent you a friend request.', 'n.friend_accept': '{name} accepted your friend request.',
    'e.invalid-email': 'Email address is not valid.', 'e.weak-password': 'Password must have at least 6 characters.',
    'e.email-already-in-use': 'This email already has an account. Log in or use Forgot password.',
    'e.user-not-found': 'No account found for this email.', 'e.wrong-password': 'Incorrect password.',
    'e.invalid-credential': 'Email or password is incorrect.', 'e.too-many-requests': 'Too many attempts. Wait a little and retry.',
    'e.network-request-failed': 'Connection failed. Check your internet.',
    'e.operation-not-allowed': 'This sign-in method is not enabled in Firebase Console → Authentication.',
    'e.unauthorized-domain': 'This domain is not authorized in Firebase Console → Authentication → Settings.',
    'e.permission-denied': 'Permission denied. Publish the new firestore.rules in Firebase Console.',
    'e.generic': 'Something went wrong. Please try again.', unread: 'new'
  },
  ps: {
    offline: 'تاسې آفلاین یاست.', email: 'بریښنالیک', password: 'پټنوم', login: 'ننوتل',
    forgot: 'پټنوم مو هېر شوی؟', createAccount: 'نوی حساب جوړ کړئ', signupTitle: 'نوی حساب جوړ کړئ',
    fullName: 'بشپړ نوم', newPassword: 'نوی پټنوم (لږ تر لږه ۶ توري)', signup: 'نوم لیکنه',
    haveAccount: 'مخکې حساب لرئ؟ ننوځئ', usePhone: 'پر ځای یې د تلیفون شمېره وکاروئ', sendCode: 'کوډ ولیږئ',
    smsCode: 'د SMS کوډ', verifyPhone: 'تایید', signInStatus: 'د ملګرو سره د اړیکې لپاره ننوځئ.',
    home: 'کور', friends: 'ملګري', reels: 'ریلز', groups: 'ډلې', notifications: 'خبرتیاوې', menu: 'مینو',
    messages: 'پیغامونه', create: 'جوړول', search: 'لټون', searchPh: 'په FRIENDS کې ولټوئ',
    whatsOnMind: 'په ذهن کې دې څه دي؟', photoVideo: 'انځور/ویډیو', story: 'سټوري', createStory: 'سټوري جوړول',
    reel: 'ریل', createPost: 'پوسټ جوړول', post: 'پوسټ', posting: 'پوسټ کیږي…', public: 'عامه', friendsOnly: 'ملګري',
    like: 'خوښ', comment: 'نظر', share: 'شریکول', writeComment: 'نظر ولیکئ…', send: 'لیږل',
    delete: 'ړنګول', cancel: 'لغوه', save: 'خوندي کول', confirm: 'تایید', addFriend: 'ملګری کړئ',
    requested: 'غوښتنه ولیږل شوه', cancelRequest: 'غوښتنه لغوه کړئ', unfriend: 'ملګرتیا پای ته رسول', message: 'پیغام',
    friendRequests: 'د ملګرتیا غوښتنې', peopleMayKnow: 'هغه کسان چې ښايي یې وپېژنئ', yourFriends: 'ستاسو ملګري',
    contacts: 'اړیکې', noPosts: 'تر اوسه پوسټ نشته. له ملګرو سره یو څه شریک کړئ!',
    noFriends: 'تر اوسه ملګري نشته. د اړیکې لپاره خلک ولټوئ.', noNotifications: 'تر اوسه خبرتیا نشته.',
    noResults: 'پایله ونه موندل شوه.', newGroup: 'ډله جوړه کړئ', groupName: 'د ډلې نوم', description: 'تشریح',
    join: 'ګډون', leave: 'وتل', members: '{n} غړي', owner: 'مالک', sell: 'یو څه وپلورئ', market: 'بازار',
    itemTitle: 'سرلیک', price: 'بیه', publish: 'خپرول', messageSeller: 'پلورونکي ته پیغام', profile: 'پروفایل',
    editProfile: 'پروفایل سمول', displayName: 'نوم', bio: 'زما په اړه', changePhoto: 'انځور بدلول',
    resendVerify: 'بیا ولیږئ', verifyBanner: 'مهرباني وکړئ خپل بریښنالیک تایید کړئ.', wallet: 'د جوړوونکي بټوه', live: 'ژوندی',
    admin: 'اډمین', darkMode: 'تیاره حالت', language: 'ژبه', logout: 'وتل',
    writeMessage: 'پیغام ولیکئ…', startChat: 'د خبرو پیل لپاره یو ملګری وټاکئ.', noChats: 'تر اوسه خبرې اترې نشته.',
    back: 'شاته', now: 'همدا اوس', caption: 'تشریح اضافه کړئ…', textStory: 'متن', mediaStory: 'انځور/ویډیو',
    typeSomething: 'یو څه ولیکئ…', shareStory: 'په سټوري کې خپرول', confirmDelete: 'دا ړنګ کړئ؟ دا بیرته نه شي کېدای.',
    copied: 'لینک کاپي شو.', loginFirst: 'مهرباني وکړئ لومړی ننوځئ.', postingIn: 'په {name} کې پوسټ', comments: '{n} نظرونه',
    commentsOne: '۱ نظر', users: 'کاروونکي', posts: 'پوسټونه', listings: 'اعلانونه', posted: 'ستاسو پوسټ خپور شو.',
    storyShared: 'سټوري د ۲۴ ساعتونو لپاره خپره شوه.', saved: 'خوندي شو.', reelShared: 'ریل خپور شو.', listingShared: 'اعلان خپور شو.',
    groupCreated: 'ډله جوړه شوه.', verifySent: 'د تایید بریښنالیک ولیږل شو.', resetSent: 'د پټنوم بیا ټاکلو بریښنالیک ولیږل شو. Inbox او Spam وګورئ.',
    codeSent: 'کوډ د SMS له لارې ولیږل شو.', enterEmail: 'سم بریښنالیک ولیکئ.', enterPassword: 'خپل پټنوم ولیکئ.',
    fillAll: 'نوم، بریښنالیک او پټنوم ولیکئ.', chooseFile: 'لومړی یوه فایل وټاکئ.', writeSomething: 'یو څه ولیکئ یا انځور/ویډیو وټاکئ.',
    fileBig: 'فایل ډېر لوی دی.', onlyMedia: 'یوازې انځور او ویډیو منل کیږي.', reqSent: 'د ملګرتیا غوښتنه ولیږل شوه.',
    noReels: 'تر اوسه ریل نشته. لومړی تاسو یو پورته کړئ!', noGroups: 'تر اوسه ډلې نشته.', noListings: 'تر اوسه د پلور لپاره څه نشته.',
    friendsPost: 'ملګري', publicPost: 'عامه', suggestionsEmpty: 'اوس مهال وړاندیز نشته.', noRequests: 'هېڅ غوښتنه نشته.',
    'n.like': '{name} ستاسو پوسټ خوښ کړ.', 'n.comment': '{name} ستاسو په پوسټ نظر ورکړ.',
    'n.friend_request': '{name} تاسو ته د ملګرتیا غوښتنه ولیږله.', 'n.friend_accept': '{name} ستاسو د ملګرتیا غوښتنه ومنله.',
    'e.invalid-email': 'بریښنالیک سم نه دی.', 'e.weak-password': 'پټنوم باید لږ تر لږه ۶ توري ولري.',
    'e.email-already-in-use': 'دا بریښنالیک مخکې حساب لري. ننوځئ یا «پټنوم مو هېر شوی» وکاروئ.',
    'e.user-not-found': 'د دې بریښنالیک لپاره حساب ونه موندل شو.', 'e.wrong-password': 'پټنوم ناسم دی.',
    'e.invalid-credential': 'بریښنالیک یا پټنوم ناسم دی.', 'e.too-many-requests': 'ډېرې هڅې وشوې. لږ انتظار وکړئ او بیا هڅه وکړئ.',
    'e.network-request-failed': 'اړیکه ونه شوه. خپل انټرنیټ وګورئ.',
    'e.operation-not-allowed': 'دا د ننوتلو طریقه په Firebase Console → Authentication کې فعاله نه ده.',
    'e.unauthorized-domain': 'دا ډومین په Firebase Console → Authentication → Settings کې نه دی اضافه شوی.',
    'e.permission-denied': 'اجازه نشته. نوی firestore.rules په Firebase Console کې خپور کړئ.',
    'e.generic': 'یوه ستونزه رامنځته شوه. بیا هڅه وکړئ.', unread: 'نوی'
  },
  fa: {
    offline: 'شما آفلاین هستید.', email: 'ایمیل', password: 'رمز عبور', login: 'ورود',
    forgot: 'رمز عبور را فراموش کرده‌اید؟', createAccount: 'ساخت حساب جدید', signupTitle: 'ساخت حساب جدید',
    fullName: 'نام کامل', newPassword: 'رمز جدید (حداقل ۶ نویسه)', signup: 'ثبت‌نام',
    haveAccount: 'حساب دارید؟ وارد شوید', usePhone: 'به جای آن از شماره تلفن استفاده کنید', sendCode: 'ارسال کد',
    smsCode: 'کد پیامک', verifyPhone: 'تأیید', signInStatus: 'برای ارتباط با دوستان وارد شوید.',
    home: 'خانه', friends: 'دوستان', reels: 'ریلز', groups: 'گروه‌ها', notifications: 'اطلاعیه‌ها', menu: 'منو',
    messages: 'پیام‌ها', create: 'ایجاد', search: 'جستجو', searchPh: 'در FRIENDS جستجو کنید',
    whatsOnMind: 'چه در ذهن دارید؟', photoVideo: 'عکس/ویدیو', story: 'استوری', createStory: 'ساخت استوری',
    reel: 'ریل', createPost: 'ایجاد پست', post: 'پست', posting: 'در حال ارسال…', public: 'عمومی', friendsOnly: 'دوستان',
    like: 'پسند', comment: 'نظر', share: 'اشتراک‌گذاری', writeComment: 'نظر بنویسید…', send: 'ارسال',
    delete: 'حذف', cancel: 'لغو', save: 'ذخیره', confirm: 'تأیید', addFriend: 'افزودن دوست',
    requested: 'درخواست ارسال شد', cancelRequest: 'لغو درخواست', unfriend: 'حذف دوستی', message: 'پیام',
    friendRequests: 'درخواست‌های دوستی', peopleMayKnow: 'افرادی که شاید بشناسید', yourFriends: 'دوستان شما',
    contacts: 'مخاطبین', noPosts: 'هنوز پستی نیست. چیزی با دوستان به اشتراک بگذارید!',
    noFriends: 'هنوز دوستی ندارید. افراد را جستجو کنید.', noNotifications: 'هنوز اطلاعیه‌ای نیست.',
    noResults: 'نتیجه‌ای یافت نشد.', newGroup: 'ساخت گروه', groupName: 'نام گروه', description: 'توضیحات',
    join: 'پیوستن', leave: 'ترک', members: '{n} عضو', owner: 'مالک', sell: 'فروش', market: 'بازار',
    itemTitle: 'عنوان', price: 'قیمت', publish: 'انتشار', messageSeller: 'پیام به فروشنده', profile: 'پروفایل',
    editProfile: 'ویرایش پروفایل', displayName: 'نام', bio: 'درباره من', changePhoto: 'تغییر عکس',
    resendVerify: 'ارسال دوباره', verifyBanner: 'لطفاً ایمیل خود را تأیید کنید.', wallet: 'کیف پول سازنده', live: 'زنده',
    admin: 'مدیر', darkMode: 'حالت تاریک', language: 'زبان', logout: 'خروج',
    writeMessage: 'پیام بنویسید…', startChat: 'برای شروع گفتگو یک دوست را انتخاب کنید.', noChats: 'هنوز گفتگویی نیست.',
    back: 'بازگشت', now: 'هم‌اکنون', caption: 'توضیح اضافه کنید…', textStory: 'متن', mediaStory: 'عکس/ویدیو',
    typeSomething: 'چیزی بنویسید…', shareStory: 'انتشار در استوری', confirmDelete: 'این حذف شود؟ قابل بازگشت نیست.',
    copied: 'لینک کپی شد.', loginFirst: 'لطفاً ابتدا وارد شوید.', postingIn: 'پست در {name}', comments: '{n} نظر',
    commentsOne: '۱ نظر', users: 'کاربران', posts: 'پست‌ها', listings: 'آگهی‌ها', posted: 'پست شما منتشر شد.',
    storyShared: 'استوری برای ۲۴ ساعت منتشر شد.', saved: 'ذخیره شد.', reelShared: 'ریل منتشر شد.', listingShared: 'آگهی منتشر شد.',
    groupCreated: 'گروه ساخته شد.', verifySent: 'ایمیل تأیید ارسال شد.', resetSent: 'ایمیل بازنشانی رمز ارسال شد. Inbox و Spam را ببینید.',
    codeSent: 'کد با پیامک ارسال شد.', enterEmail: 'ایمیل معتبر وارد کنید.', enterPassword: 'رمز عبور را وارد کنید.',
    fillAll: 'نام، ایمیل و رمز عبور را وارد کنید.', chooseFile: 'ابتدا یک فایل انتخاب کنید.', writeSomething: 'چیزی بنویسید یا عکس/ویدیو انتخاب کنید.',
    fileBig: 'فایل بیش از حد بزرگ است.', onlyMedia: 'فقط عکس و ویدیو مجاز است.', reqSent: 'درخواست دوستی ارسال شد.',
    noReels: 'هنوز ریلی نیست. اولین نفر باشید!', noGroups: 'هنوز گروهی نیست.', noListings: 'هنوز چیزی برای فروش نیست.',
    friendsPost: 'دوستان', publicPost: 'عمومی', suggestionsEmpty: 'فعلاً پیشنهادی نیست.', noRequests: 'درخواستی نیست.',
    'n.like': '{name} پست شما را پسندید.', 'n.comment': '{name} روی پست شما نظر داد.',
    'n.friend_request': '{name} برای شما درخواست دوستی فرستاد.', 'n.friend_accept': '{name} درخواست دوستی شما را پذیرفت.',
    'e.invalid-email': 'ایمیل معتبر نیست.', 'e.weak-password': 'رمز عبور باید حداقل ۶ نویسه باشد.',
    'e.email-already-in-use': 'این ایمیل قبلاً حساب دارد. وارد شوید یا «رمز را فراموش کرده‌ام» را بزنید.',
    'e.user-not-found': 'حسابی برای این ایمیل پیدا نشد.', 'e.wrong-password': 'رمز عبور نادرست است.',
    'e.invalid-credential': 'ایمیل یا رمز عبور نادرست است.', 'e.too-many-requests': 'تلاش‌های زیاد. کمی صبر کنید و دوباره امتحان کنید.',
    'e.network-request-failed': 'اتصال برقرار نشد. اینترنت را بررسی کنید.',
    'e.operation-not-allowed': 'این روش ورود در Firebase Console → Authentication فعال نیست.',
    'e.unauthorized-domain': 'این دامنه در Firebase Console → Authentication → Settings اضافه نشده است.',
    'e.permission-denied': 'دسترسی ممنوع. firestore.rules جدید را در Firebase Console منتشر کنید.',
    'e.generic': 'مشکلی پیش آمد. دوباره امتحان کنید.', unread: 'جدید'
  }
};

let lang = 'en';
try {
  const saved = localStorage.getItem('friends_lang');
  const nav = (navigator.language || 'en').slice(0, 2);
  lang = D[saved] ? saved : D[nav] ? nav : 'en';
} catch { /* storage blocked */ }

export const getLang = () => lang;
export const isRTL = () => LANGS[lang].dir === 'rtl';

export function t(key, vars) {
  let s = (D[lang] && D[lang][key]) || D.en[key] || key;
  if (vars) for (const [k, v] of Object.entries(vars)) s = s.split('{' + k + '}').join(v);
  return s;
}

export function applyI18n(root = document) {
  root.querySelectorAll('[data-i18n]').forEach(el => { el.textContent = t(el.dataset.i18n); });
  root.querySelectorAll('[data-i18n-ph]').forEach(el => {
    const txt = t(el.dataset.i18nPh);
    if (el.isContentEditable) el.dataset.placeholder = txt; else el.placeholder = txt;
  });
  root.querySelectorAll('[data-i18n-title]').forEach(el => { el.title = t(el.dataset.i18nTitle); el.setAttribute('aria-label', el.title); });
}

export function setLang(l) {
  if (!D[l]) return;
  lang = l;
  try { localStorage.setItem('friends_lang', l); } catch { /* ignore */ }
  document.documentElement.lang = l;
  document.documentElement.dir = LANGS[l].dir;
  applyI18n();
}

export function ago(ts) {
  if (!ts) return t('now');
  const d = ts.toDate ? ts.toDate() : new Date(ts);
  const s = (Date.now() - d.getTime()) / 1000;
  if (s < 45) return t('now');
  try {
    const rtf = new Intl.RelativeTimeFormat(lang, { numeric: 'auto', style: 'short' });
    if (s < 3600) return rtf.format(-Math.round(s / 60), 'minute');
    if (s < 86400) return rtf.format(-Math.round(s / 3600), 'hour');
    if (s < 604800) return rtf.format(-Math.round(s / 86400), 'day');
  } catch { /* fall through */ }
  return d.toLocaleDateString(lang);
}
