// FRIENDS — social network PWA (Firebase Auth + Firestore, Cloudinary for media).
import { t, applyI18n, setLang, getLang, ago } from './i18n.js';

/* ============================== CONFIG ============================== */
const FIREBASE_CONFIG = {
  apiKey: 'AIzaSyBPeS26WsCXhoJRPCArgMZFMHmW4eoGdio',
  authDomain: 'friends-social-network-56ad6.firebaseapp.com',
  projectId: 'friends-social-network-56ad6',
  storageBucket: 'friends-social-network-56ad6.firebasestorage.app',
  messagingSenderId: '1068510058667',
  appId: '1:1068510058667:web:5eb8cd7bb2dd48a511ffee',
  measurementId: 'G-8NH49MGXYE'
};
const CLOUDINARY = { cloud: 'zgwfz5od', preset: 'friends_upload' };
const SDK = 'https://www.gstatic.com/firebasejs/10.14.1/';
const MAX_IMG = 15 * 1024 * 1024, MAX_VID = 100 * 1024 * 1024;
const BGS = ['linear-gradient(135deg,#0866ff,#7b2ff7)', 'linear-gradient(135deg,#f12711,#f5af19)', 'linear-gradient(135deg,#11998e,#38ef7d)',
  'linear-gradient(135deg,#232526,#414345)', 'linear-gradient(135deg,#ee0979,#ff6a00)', 'linear-gradient(135deg,#00c6ff,#0072ff)'];
const SCREENS = ['home', 'friends', 'reels', 'groups', 'group', 'notifications', 'messages', 'profile', 'post', 'market', 'search', 'menu', 'wallet', 'live', 'admin'];
const TAB_OF = { home: 'home', friends: 'friends', reels: 'reels', groups: 'groups', group: 'groups', notifications: 'notifications', menu: 'menu', wallet: 'menu', live: 'menu', admin: 'menu', market: 'menu' };

/* ============================== UTILS ============================== */
const $ = id => document.getElementById(id);
const q = (s, r = document) => r.querySelector(s);
const qa = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const safeUrl = u => (/^https:\/\//i.test(u || '') ? u : '');
const bgUrl = u => `url("${u.replace(/["\\\n]/g, encodeURIComponent)}")`;
const ic = (n, c = '') => `<svg class="ic ${c}"><use href="#i-${n}"/></svg>`;
const el = html => { const tp = document.createElement('template'); tp.innerHTML = html.trim(); return tp.content.firstElementChild; };
const linkify = s => esc(s).replace(/(https?:\/\/[^\s<]+)/g, u => `<a href="${u}" target="_blank" rel="noopener noreferrer nofollow">${u}</a>`);
const ms = ts => (ts && ts.toMillis ? ts.toMillis() : ts ? new Date(ts).getTime() : Date.now());
const hue = n => [...String(n || '?')].reduce((a, c) => (a * 31 + c.codePointAt(0)) % 360, 7);
const initial = n => ([...String(n || '?').trim()][0] || '?').toUpperCase();
const lsGet = (k, d = null) => { try { return localStorage.getItem(k) ?? d; } catch { return d; } };
const lsSet = (k, v) => { try { localStorage.setItem(k, v); } catch { /* ignore */ } };

function avatar(name, photo, cls = '') {
  const u = safeUrl(photo);
  if (u) return `<span class="avatar ${cls}"><img src="${esc(u)}" alt="" loading="lazy"></span>`;
  return `<span class="avatar ${cls}" style="background:hsl(${hue(name)} 55% 45%)">${esc(initial(name))}</span>`;
}
function fillAvatar(e, name, photo) {
  const u = safeUrl(photo);
  if (u) { e.style.background = ''; e.innerHTML = `<img src="${esc(u)}" alt="">`; }
  else { e.style.background = `hsl(${hue(name)} 55% 45%)`; e.textContent = initial(name); }
}

let toastTimer;
function toast(m) { const e = $('toast'); e.textContent = m; e.classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(() => e.classList.remove('show'), 3200); }
const ERR_ALIAS = { 'invalid-login-credentials': 'invalid-credential', 'missing-email': 'invalid-email', 'missing-password': 'invalid-credential' };
function errText(e) {
  const code = (e?.code || '').replace(/^(auth|firestore)\//, '');
  const k = 'e.' + (ERR_ALIAS[code] || code);
  const m = t(k);
  if (m !== k) return m;
  if (e?.message && !e.code) return e.message;
  return t('e.generic');
}
let lastErrAt = 0;
const onErr = e => { console.error(e); if (Date.now() - lastErrAt > 4000) { lastErrAt = Date.now(); toast(errText(e)); } };

function openModal(id) { $(id).classList.remove('hidden'); document.body.style.overflow = 'hidden'; }
function closeModal(id) {
  if (id === 'storyViewer') stopStory();
  $(id).classList.add('hidden');
  if (!qa('.modal').some(m => !m.classList.contains('hidden'))) document.body.style.overflow = '';
}
let confirmRes;
function confirmBox(msg) { $('confirmText').textContent = msg; openModal('m-confirm'); return new Promise(r => { confirmRes = r; }); }

function applyTheme() {
  const m = lsGet('friends_theme', 'auto');
  const dark = m === 'dark' || (m === 'auto' && matchMedia('(prefers-color-scheme: dark)').matches);
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
  $('themeColor').content = dark ? '#242526' : '#ffffff';
  $('themeSwitch')?.classList.toggle('on', dark);
}

/* ============================== FIREBASE ============================== */
let fb = {};
try {
  const [A, Au, F] = await Promise.all([import(SDK + 'firebase-app.js'), import(SDK + 'firebase-auth.js'), import(SDK + 'firebase-firestore.js')]);
  fb = { ...A, ...Au, ...F };
} catch (e) { console.error('Firebase SDK failed to load:', e); }
const ready = !!fb.initializeApp;
const {
  initializeApp, getAuth, onAuthStateChanged, signOut, createUserWithEmailAndPassword, signInWithEmailAndPassword, updateProfile,
  sendEmailVerification, sendPasswordResetEmail, RecaptchaVerifier, signInWithPhoneNumber, setPersistence, browserLocalPersistence,
  getFirestore, doc, setDoc, getDoc, addDoc, collection, query, orderBy, limit, onSnapshot, serverTimestamp, where, getDocs,
  updateDoc, deleteDoc, arrayUnion, arrayRemove, increment, writeBatch, getCountFromServer
} = fb;
let auth = null, db = null;
if (ready) {
  const app = initializeApp(FIREBASE_CONFIG);
  auth = getAuth(app);
  setPersistence(auth, browserLocalPersistence).catch(e => console.warn('Auth persistence:', e));
  db = getFirestore(app);
}

/* ============================== STATE ============================== */
const S = {
  user: null, me: null, route: { id: 'auth', arg: null },
  users: new Map(), all: null, allAt: 0,
  friends: new Set(), incoming: new Map(), outgoing: new Map(),
  feedData: new Map(), stories: [], notifs: [], chats: [],
  unsubs: [], viewUnsubs: [], chatUnsub: null, chatId: null, chatPeer: null,
  composerCtx: {}, storyMode: 'media', storyBg: 0, pendingName: '', profileUid: null, confirmation: null, recaptcha: null
};
const me = () => S.user?.uid;
const myName = () => S.me?.name || S.user?.displayName || (S.user?.email || '').split('@')[0] || S.user?.phoneNumber || 'FRIENDS member';
const myPhoto = () => S.me?.photoUrl || S.user?.photoURL || '';

async function getUser(uid) {
  if (!uid) return { uid: '', name: 'FRIENDS user' };
  if (S.users.has(uid)) return S.users.get(uid);
  try {
    const s = await getDoc(doc(db, 'users', uid));
    const d = s.exists() ? { uid, ...s.data() } : { uid, name: 'FRIENDS user' };
    S.users.set(uid, d); return d;
  } catch (e) { console.warn('getUser', e); return { uid, name: 'FRIENDS user' }; }
}
const ensureUsers = uids => Promise.all([...new Set(uids)].filter(u => u && !S.users.has(u)).map(getUser));
async function allUsers(force = false) {
  if (!force && S.all && Date.now() - S.allAt < 120000) return S.all;
  const s = await getDocs(query(collection(db, 'users'), limit(300)));
  S.all = s.docs.map(d => ({ uid: d.id, ...d.data() }));
  S.all.forEach(u => S.users.set(u.uid, u));
  S.allAt = Date.now();
  return S.all;
}

/* ============================== AUTH ============================== */
function authStatus(msg, isErr = false, id = 'authStatus') { const e = $(id); e.textContent = msg || ''; e.classList.toggle('err', isErr); }
async function guard(btn, fn) {
  if (btn) btn.disabled = true;
  try { return await fn(); } catch (e) { onErr(e); } finally { if (btn) btn.disabled = false; }
}

async function doLogin(b) {
  if (!auth) return toast(t('e.network-request-failed'));
  const email = $('email').value.trim().toLowerCase(), pass = $('password').value;
  if (!email.includes('@')) return authStatus(t('enterEmail'), true);
  if (!pass) return authStatus(t('enterPassword'), true);
  authStatus('');
  await guard(b, async () => {
    try { await signInWithEmailAndPassword(auth, email, pass); } catch (e) { console.error(e); authStatus(errText(e), true); }
  });
}
async function doSignup(b) {
  if (!auth) return toast(t('e.network-request-failed'));
  const name = $('name').value.trim(), email = $('signupEmail').value.trim().toLowerCase(), pass = $('signupPassword').value;
  if (!name || !email || !pass) return authStatus(t('fillAll'), true, 'signupStatus');
  if (!email.includes('@')) return authStatus(t('enterEmail'), true, 'signupStatus');
  if (pass.length < 6) return authStatus(t('e.weak-password'), true, 'signupStatus');
  await guard(b, async () => {
    try {
      S.pendingName = name;
      const cred = await createUserWithEmailAndPassword(auth, email, pass);
      try { await updateProfile(cred.user, { displayName: name }); } catch (e) { console.warn(e); }
      try { await setDoc(doc(db, 'users', cred.user.uid), { uid: cred.user.uid, name, email, bio: '', photoUrl: '', role: 'user', createdAt: serverTimestamp() }, { merge: true }); } catch (e) { console.error(e); toast(t('e.permission-denied')); }
      sendEmailVerification(cred.user).then(() => toast(t('verifySent'))).catch(e => console.warn(e));
    } catch (e) { console.error(e); S.pendingName = ''; authStatus(errText(e), true, 'signupStatus'); }
  });
}
async function doForgot() {
  const email = $('email').value.trim().toLowerCase();
  if (!email.includes('@')) return authStatus(t('enterEmail'), true);
  try { await sendPasswordResetEmail(auth, email); authStatus(t('resetSent')); } catch (e) { console.error(e); authStatus(errText(e), true); }
}

/* ============================== ROUTER ============================== */
function parseHash() {
  const h = location.hash.replace(/^#\/?/, '');
  if (h.startsWith('post-')) return { id: 'post', arg: h.slice(5) };
  const [id, ...rest] = h.split('/');
  if (!SCREENS.includes(id)) return { id: 'home', arg: null };
  return { id, arg: rest.join('/') || null };
}
function go(id, arg = null, opts = {}) {
  if (!S.user) id = 'auth';
  if (id !== 'auth') {
    const hash = '#' + id + (arg ? '/' + arg : '');
    if (opts.replace) history.replaceState(null, '', hash);
    else if (location.hash !== hash) history.pushState(null, '', hash);
  }
  render(id, arg);
}
function cleanupView() {
  S.viewUnsubs.forEach(f => { try { f(); } catch { /* ignore */ } });
  S.viewUnsubs = [];
  ['profilePosts', 'groupPosts', 'singlePost', 'searchPosts'].forEach(i => disposePosts($(i)));
  qa('video').forEach(v => { if (!v.closest('#storyViewer')) v.pause(); });
}
function render(id, arg) {
  cleanupView();
  if (id !== 'messages') stopChat();
  qa('.modal').forEach(m => { if (!m.classList.contains('hidden')) closeModal(m.id); });
  S.route = { id, arg };
  document.body.dataset.view = id;
  qa('.screen').forEach(s => s.classList.toggle('active', s.id === id));
  qa('.tab').forEach(b => b.classList.toggle('active', b.dataset.tab === TAB_OF[id]));
  window.scrollTo(0, 0);
  if (id === 'auth') return;
  const L = {
    friends: renderFriends, reels: loadReels, groups: loadGroups, group: () => loadGroup(arg), notifications: renderNotifs,
    messages: () => { renderChatList(); if (arg) openChat(arg); else showChatEmpty(); },
    profile: () => loadProfile(arg || me()), post: () => loadPost(arg), market: loadMarket, search: () => renderSearch($('globalSearch').value),
    menu: () => { $('themeSwitch').classList.toggle('on', document.documentElement.dataset.theme === 'dark'); $('langSelect2').value = getLang(); }, admin: loadAdmin
  }[id];
  if (L) Promise.resolve(L()).catch(onErr);
}

/* ============================== AUTH STATE ============================== */
function teardown() {
  S.unsubs.forEach(f => { try { f(); } catch { /* ignore */ } }); S.unsubs = [];
  cleanupView(); stopChat();
  Object.assign(S, { user: null, me: null, all: null, friends: new Set(), incoming: new Map(), outgoing: new Map(), feedData: new Map(), stories: [], notifs: [], chats: [] });
  S.users.clear();
  $('feed').innerHTML = ''; $('storyRow').innerHTML = ''; $('feedSkeleton').classList.remove('hidden'); $('feedEmpty').classList.add('hidden');
  ['reqBadge', 'notifBadge', 'msgBadge'].forEach(i => $(i).classList.add('hidden'));
}
async function loadMe(user) {
  const uref = doc(db, 'users', user.uid);
  const base = { uid: user.uid, name: S.pendingName || user.displayName || user.phoneNumber || 'FRIENDS member', email: user.email || '', phone: user.phoneNumber || '', bio: '', photoUrl: user.photoURL || '', role: 'user' };
  try {
    const snap = await getDoc(uref);
    if (snap.exists()) S.me = { uid: user.uid, ...snap.data() };
    else { await setDoc(uref, { ...base, createdAt: serverTimestamp() }); S.me = base; }
  } catch (e) { console.error('Profile load failed:', e); S.me = base; onErr(e); }
  S.pendingName = '';
  S.users.set(user.uid, S.me);
}
function setMyUI() {
  const n = myName(), p = myPhoto();
  qa('.my-avatar').forEach(e => fillAvatar(e, n, p));
  qa('.my-name').forEach(e => { e.textContent = n; });
  $('adminTile').classList.toggle('hidden', S.me?.role !== 'admin');
  $('verifyBanner').classList.toggle('hidden', !(S.user?.email && !S.user.emailVerified));
  qa('.comment-form .avatar').forEach(e => fillAvatar(e, n, p));
}

if (ready) {
  onAuthStateChanged(auth, async user => {
    if (!user) { teardown(); go('auth'); return; }
    S.user = user;
    await loadMe(user);
    setMyUI();
    startListeners();
    renderSide();
    const r = parseHash();
    go(r.id, r.arg, { replace: true });
  });
}

function startListeners() {
  const uid = me();
  const L = (qy, fn, errFn = onErr) => S.unsubs.push(onSnapshot(qy, fn, errFn));
  // feed
  L(query(collection(db, 'posts'), orderBy('createdAt', 'desc'), limit(60)), onFeed, e => { $('feedSkeleton').classList.add('hidden'); applyFeedVisibility(); onErr(e); });
  // stories (last 80, filtered to <24h client-side)
  L(query(collection(db, 'stories'), orderBy('createdAt', 'desc'), limit(80)), s => {
    const now = Date.now();
    S.stories = s.docs.map(d => ({ id: d.id, ...d.data() })).filter(x => (x.expiresAt || 0) > now);
    renderStoryRow();
  });
  // friend graph (derived from friendRequests: pending / accepted)
  L(query(collection(db, 'friendRequests'), where('from', '==', uid)), s => { S.outgoing = new Map(s.docs.map(d => [d.data().to, { id: d.id, ...d.data() }])); friendsChanged(); });
  L(query(collection(db, 'friendRequests'), where('to', '==', uid)), s => { S.incoming = new Map(s.docs.map(d => [d.data().from, { id: d.id, ...d.data() }])); friendsChanged(); });
  // notifications
  L(query(collection(db, 'notifications'), where('to', '==', uid), limit(60)), s => {
    S.notifs = s.docs.map(d => ({ id: d.id, ...d.data() })).sort((a, b) => ms(b.createdAt) - ms(a.createdAt));
    updateBadges();
    if (S.route.id === 'notifications') renderNotifs();
  });
  // conversations
  L(query(collection(db, 'chats'), where('members', 'array-contains', uid), limit(50)), s => {
    S.chats = s.docs.map(d => ({ id: d.id, ...d.data() })).sort((a, b) => ms(b.lastAt) - ms(a.lastAt));
    updateBadges();
    if (S.route.id === 'messages') renderChatList();
  });
}

/* ============================== BADGES ============================== */
const setBadge = (id, n) => { const e = $(id); e.textContent = n > 9 ? '9+' : n; e.classList.toggle('hidden', !n); };
const chatUnread = c => c.lastFrom && c.lastFrom !== me() && c.id !== S.chatId && ms(c.lastAt) > Number(lsGet('seen_' + c.id, 0));
function updateBadges() {
  setBadge('notifBadge', S.notifs.filter(n => !n.read && n.type !== 'friend_request').length);
  setBadge('reqBadge', [...S.incoming.values()].filter(r => r.status === 'pending').length);
  setBadge('msgBadge', S.chats.filter(chatUnread).length);
}

/* ============================== FRIENDS ============================== */
function friendStatus(uid) {
  if (S.incoming.get(uid)?.status === 'accepted' || S.outgoing.get(uid)?.status === 'accepted') return 'friends';
  if (S.outgoing.get(uid)?.status === 'pending') return 'sent';
  if (S.incoming.get(uid)?.status === 'pending') return 'received';
  return 'none';
}
function friendsChanged() {
  const f = new Set();
  S.incoming.forEach((r, u) => { if (r.status === 'accepted') f.add(u); });
  S.outgoing.forEach((r, u) => { if (r.status === 'accepted') f.add(u); });
  S.friends = f;
  updateBadges(); renderSide(); applyFeedVisibility();
  if (S.route.id === 'friends') renderFriends();
  if (S.route.id === 'messages') renderChatList();
  if (S.route.id === 'profile') renderProfileActions();
}
const friendBtns = uid => ({
  friends: `<button class="btn btn-sm" data-act="openChat" data-arg="${uid}">${t('message')}</button>`,
  sent: `<button class="btn btn-sm" data-act="cancelReq" data-arg="${uid}">${t('cancelRequest')}</button>`,
  received: `<button class="btn btn-sm btn-primary" data-act="acceptReq" data-arg="${uid}">${t('confirm')}</button><button class="btn btn-sm" data-act="removeReq" data-arg="${uid}">${t('delete')}</button>`,
  none: `<button class="btn btn-sm btn-soft" data-act="addFriend" data-arg="${uid}">${ic('add', 'sm')}${t('addFriend')}</button>`
}[friendStatus(uid)]);

async function notify(to, type, extra = {}, id = null) {
  if (!to || to === me()) return;
  const data = { to, from: me(), fromName: myName(), fromPhoto: myPhoto(), type, postId: extra.postId || '', read: false, createdAt: serverTimestamp() };
  try { if (id) await setDoc(doc(db, 'notifications', id), data); else await addDoc(collection(db, 'notifications'), data); } catch { /* duplicate / rules: ignore */ }
}
async function sendRequest(uid) {
  if (S.incoming.get(uid)?.status === 'pending') return acceptRequest(uid);
  await setDoc(doc(db, 'friendRequests', `${me()}_${uid}`), { from: me(), to: uid, fromName: myName(), fromPhoto: myPhoto(), status: 'pending', createdAt: serverTimestamp() });
  notify(uid, 'friend_request', {}, `fr_${me()}_${uid}`);
  toast(t('reqSent'));
}
async function acceptRequest(uid) {
  const r = S.incoming.get(uid); if (!r) return;
  await updateDoc(doc(db, 'friendRequests', r.id), { status: 'accepted' });
  notify(uid, 'friend_accept');
}
async function removeRequest(uid) {
  const r = S.outgoing.get(uid) || S.incoming.get(uid); if (!r) return;
  await deleteDoc(doc(db, 'friendRequests', r.id));
}

let sideTok = 0;
async function renderSide() {
  if (!S.user) return;
  const tok = ++sideTok;
  const n = myName();
  const items = [['openMyProfile', '', avatar(n, myPhoto(), 'sm'), esc(n)], ['go', 'friends', ic('users', 'c-blue'), t('friends')], ['go', 'groups', ic('groups', 'c-blue'), t('groups')],
    ['go', 'market', ic('store', 'c-blue'), t('market')], ['go', 'reels', ic('reels', 'c-blue'), t('reels')], ['go', 'messages', ic('chat', 'c-blue'), t('messages')]];
  $('colLeft').innerHTML = `<div class="card" style="padding:8px">${items.map(([a, arg, i, l]) => `<button class="list-item" data-act="${a}" data-arg="${arg}">${i}<span class="t">${l}</span></button>`).join('')}</div>`;
  const pend = [...S.incoming.entries()].filter(([, r]) => r.status === 'pending');
  await ensureUsers([...S.friends, ...pend.map(([u]) => u)].slice(0, 40));
  if (tok !== sideTok) return;
  const nm = u => S.users.get(u)?.name || 'FRIENDS user', ph = u => S.users.get(u)?.photoUrl || '';
  let html = '';
  if (pend.length) html += `<div class="card"><div class="section-title"><span>${t('friendRequests')}</span></div>${pend.slice(0, 3).map(([u]) =>
    `<div class="list-item">${avatar(nm(u), ph(u))}<div class="grow"><button class="t" data-act="openProfile" data-arg="${u}">${esc(nm(u))}</button><div class="row" style="margin-top:6px"><button class="btn btn-sm btn-primary" data-act="acceptReq" data-arg="${u}">${t('confirm')}</button><button class="btn btn-sm" data-act="removeReq" data-arg="${u}">${t('delete')}</button></div></div></div>`).join('')}</div>`;
  html += `<div class="card"><div class="section-title"><span>${t('contacts')}</span></div>${[...S.friends].slice(0, 14).map(u =>
    `<button class="list-item" data-act="openChat" data-arg="${u}">${avatar(nm(u), ph(u), 'sm')}<span class="t">${esc(nm(u))}</span></button>`).join('') || `<div class="muted small" style="padding:6px">${t('noFriends')}</div>`}</div>`;
  $('colRight').innerHTML = html;
}

async function renderFriends() {
  const pend = [...S.incoming.entries()].filter(([, r]) => r.status === 'pending');
  await ensureUsers([...S.friends, ...pend.map(([u]) => u)]);
  const nm = u => S.users.get(u)?.name || 'FRIENDS user', ph = u => S.users.get(u)?.photoUrl || '';
  const row = (u, right) => `<div class="list-item"><button class="row grow" data-act="openProfile" data-arg="${u}">${avatar(nm(u), ph(u))}<span class="t">${esc(nm(u))}</span></button>${right}</div>`;
  $('requestList').innerHTML = pend.map(([u]) => row(u, friendBtns(u))).join('') || `<div class="muted small">${t('noRequests')}</div>`;
  $('friendCount').textContent = S.friends.size || '';
  $('friendList').innerHTML = [...S.friends].map(u => row(u, `<button class="btn btn-sm" data-act="openChat" data-arg="${u}">${t('message')}</button><button class="btn btn-sm btn-danger" data-act="unfriend" data-arg="${u}">${t('unfriend')}</button>`)).join('') || `<div class="muted small">${t('noFriends')}</div>`;
  const users = await allUsers().catch(() => []);
  const sug = users.filter(u => u.uid !== me() && friendStatus(u.uid) === 'none').slice(0, 12);
  $('suggestions').innerHTML = sug.map(u => `<div class="person"><button data-act="openProfile" data-arg="${u.uid}">${avatar(u.name, u.photoUrl)}<div class="t ellipsis">${esc(u.name || 'FRIENDS user')}</div></button>${friendBtns(u.uid)}</div>`).join('') || `<div class="muted small">${t('suggestionsEmpty')}</div>`;
}

/* ============================== UPLOADS ============================== */
function validateFile(f) {
  const v = f.type.startsWith('video/'), i = f.type.startsWith('image/');
  if (!v && !i) throw new Error(t('onlyMedia'));
  if (f.size > (v ? MAX_VID : MAX_IMG)) throw new Error(t('fileBig'));
}
async function prepImage(file) {
  if (file.type === 'image/gif' || !self.createImageBitmap) return file;
  try {
    const bmp = await createImageBitmap(file);
    const sc = Math.min(1, 1600 / Math.max(bmp.width, bmp.height));
    if (sc === 1 && file.size < 1.5e6) return file;
    const c = document.createElement('canvas'); c.width = Math.round(bmp.width * sc); c.height = Math.round(bmp.height * sc);
    c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
    const blob = await new Promise(r => c.toBlob(r, 'image/jpeg', 0.85));
    return blob ? new File([blob], file.name.replace(/\.\w+$/, '') + '.jpg', { type: 'image/jpeg' }) : file;
  } catch { return file; }
}
async function uploadFile(file, progId) {
  validateFile(file);
  const prog = progId ? $(progId) : null;
  const f = file.type.startsWith('image/') ? await prepImage(file) : file;
  const kind = f.type.startsWith('video/') ? 'video' : 'image';
  const fd = new FormData(); fd.append('file', f); fd.append('upload_preset', CLOUDINARY.preset);
  if (prog) { prog.classList.remove('hidden'); q('i', prog).style.width = '0'; }
  return new Promise((res, rej) => {
    const x = new XMLHttpRequest();
    x.open('POST', `https://api.cloudinary.com/v1_1/${CLOUDINARY.cloud}/${kind}/upload`);
    x.upload.onprogress = e => { if (e.lengthComputable && prog) q('i', prog).style.width = Math.round(e.loaded / e.total * 100) + '%'; };
    x.onload = () => {
      let r = {}; try { r = JSON.parse(x.responseText); } catch { /* not json */ }
      if (x.status >= 200 && x.status < 300 && r.secure_url) res(r.secure_url); else rej(new Error(r.error?.message || 'Upload failed'));
    };
    x.onerror = () => rej(Object.assign(new Error('network'), { code: 'network-request-failed' }));
    x.send(fd);
  }).finally(() => { if (prog) setTimeout(() => prog.classList.add('hidden'), 400); });
}
function bindPreview(inputId, prevId) {
  $(inputId).addEventListener('change', () => {
    clearPreview(prevId);
    const f = $(inputId).files[0]; if (!f) return;
    try { validateFile(f); } catch (e) { $(inputId).value = ''; return toast(e.message); }
    const u = URL.createObjectURL(f), pv = $(prevId);
    pv.dataset.url = u;
    pv.innerHTML = (f.type.startsWith('video/') ? `<video src="${u}" controls playsinline muted></video>` : `<img src="${u}" alt="">`) + `<button type="button" class="icon-btn" data-act="clearFile" data-arg="${inputId}|${prevId}">${ic('close', 'sm')}</button>`;
    pv.classList.remove('hidden');
  });
}
function clearPreview(prevId) { const pv = $(prevId); if (pv.dataset.url) URL.revokeObjectURL(pv.dataset.url); pv.dataset.url = ''; pv.innerHTML = ''; pv.classList.add('hidden'); }

/* ============================== POSTS ============================== */
function postVisible(p) {
  if (p.groupId) return false;
  return !(p.privacy === 'friends' && p.uid !== me() && !S.friends.has(p.uid));
}
function renderPost(id, p) {
  const canDel = p.uid === me() || S.me?.role === 'admin';
  const mu = safeUrl(p.mediaUrl), isVid = (p.mediaType || '').startsWith('video');
  const media = mu ? (isVid ? `<video class="post-media" controls playsinline preload="metadata" src="${esc(mu)}"></video>`
    : `<img class="post-media" data-act="lightbox" data-src="${esc(mu)}" src="${esc(mu)}" alt="" loading="lazy">`) : '';
  const big = !mu && p.body && p.body.length < 70 && !p.body.includes('\n') ? ' big' : '';
  const node = el(`<article class="card post" data-id="${esc(id)}">
    <div class="post-head">
      <button data-act="openProfile" data-arg="${esc(p.uid)}">${avatar(p.name, p.photo)}</button>
      <div class="grow"><button class="name" data-act="openProfile" data-arg="${esc(p.uid)}">${esc(p.name || 'FRIENDS user')}</button>
        <div class="sub"><span class="ptime"></span><span>·</span>${ic(p.privacy === 'friends' ? 'lock' : 'globe', 'sm')}${p.groupId ? `<span>·</span><button class="name" style="font-weight:600" data-act="openGroup" data-arg="${esc(p.groupId)}">${esc(p.groupName || '')}</button>` : ''}</div></div>
      ${canDel ? `<button class="icon-btn sm plain" data-act="deletePost" title="${esc(t('delete'))}">${ic('trash', 'sm')}</button>` : ''}
    </div>
    ${p.body ? `<div class="post-text${big}">${linkify(p.body)}</div>` : ''}${media}
    <div class="post-stats"><span class="lk"></span><button class="cc" data-act="toggleComments"></button></div>
    <div class="post-actions">
      <button class="pa like-btn" data-act="like">${ic('like')}<span>${t('like')}</span></button>
      <button class="pa" data-act="toggleComments">${ic('comment')}<span>${t('comment')}</span></button>
      <button class="pa" data-act="sharePost">${ic('share')}<span>${t('share')}</span></button>
    </div>
    <div class="comments hidden"><div class="comment-list"></div>
      <div class="comment-form">${avatar(myName(), myPhoto(), 'sm')}<input class="pill-input" maxlength="1000" placeholder="${esc(t('writeComment'))}"><button class="icon-btn sm plain" data-act="sendComment" style="color:var(--blue)">${ic('send', 'sm')}</button></div></div>
  </article>`);
  updatePost(node, p);
  return node;
}
function updatePost(node, p) {
  node._p = p;
  const likes = p.likes || [], liked = likes.includes(me());
  q('.lk', node).innerHTML = likes.length ? `<span class="dot-like">${ic('like')}</span>${likes.length}` : '';
  const c = p.commentCount || 0;
  q('.cc', node).textContent = c ? (c === 1 ? t('commentsOne') : t('comments', { n: c })) : '';
  q('.like-btn', node).classList.toggle('on', liked);
  q('.ptime', node).textContent = ago(p.createdAt);
}
function disposePosts(box) { if (!box) return; qa('.post', box).forEach(n => { n._cu?.(); n._cu = null; }); }
const findPost = (box, id) => [...box.children].find(n => n.dataset?.id === id);

function onFeed(snap) {
  const feed = $('feed');
  $('feedSkeleton').classList.add('hidden');
  snap.docChanges().forEach(ch => {
    const id = ch.doc.id, p = ch.doc.data();
    if (ch.type === 'removed') { S.feedData.delete(id); const n = findPost(feed, id); if (n) { n._cu?.(); n.remove(); } return; }
    S.feedData.set(id, p);
    if (ch.type === 'added') feed.insertBefore(renderPost(id, p), feed.children[ch.newIndex] || null);
    else { const n = findPost(feed, id); if (n) updatePost(n, p); }
  });
  applyFeedVisibility();
}
function applyFeedVisibility() {
  const feed = $('feed'); let shown = 0;
  [...feed.children].forEach(n => { const ok = n._p ? postVisible(n._p) : true; n.hidden = !ok; if (ok) shown++; });
  $('feedEmpty').classList.toggle('hidden', shown > 0 || !$('feedSkeleton').classList.contains('hidden'));
}

function subscribeComments(node) {
  const id = node.dataset.id; node._cu?.();
  node._cu = onSnapshot(query(collection(db, 'posts', id, 'comments'), orderBy('createdAt', 'asc'), limit(100)), snap => {
    const list = q('.comment-list', node); list.innerHTML = '';
    snap.forEach(d => list.append(commentEl(id, d.id, d.data(), node._p)));
  }, onErr);
}
function commentEl(pid, cid, c, post) {
  const canDel = c.uid === me() || post?.uid === me() || S.me?.role === 'admin';
  const n = el(`<div class="comment" data-cid="${esc(cid)}">${avatar(c.name, c.photo, 'sm')}<div class="grow"><div class="cbub"><b>${esc(c.name || '')}</b>${linkify(c.text)}</div>
    <div class="cmeta"><span>${esc(ago(c.createdAt))}</span>${canDel ? `<button data-act="delComment">${t('delete')}</button>` : ''}</div></div></div>`);
  n.dataset.pid = pid; return n;
}

async function deletePost(node) {
  if (!(await confirmBox(t('confirmDelete')))) return;
  const id = node.dataset.id;
  const cs = await getDocs(collection(db, 'posts', id, 'comments')).catch(() => ({ docs: [] }));
  const b = writeBatch(db);
  cs.docs.slice(0, 400).forEach(d => b.delete(d.ref));
  b.delete(doc(db, 'posts', id));
  await b.commit();
  if (S.route.id === 'post') go('home');
}

/* --- composer --- */
function openComposer(arg) {
  const ctx = S.composerCtx = arg === 'group' ? { groupId: S.route.arg, groupName: S.groupName || '' } : {};
  $('composerTitle').textContent = ctx.groupId ? t('postingIn', { name: ctx.groupName }) : t('createPost');
  $('cPrivacy').classList.toggle('hidden', !!ctx.groupId);
  openModal('m-composer');
  setTimeout(() => $('cText').focus(), 50);
  if (arg === 'media') $('cFile').click();
}
async function publishPost(b) {
  const text = $('cText').value.trim(), file = $('cFile').files[0], ctx = S.composerCtx || {};
  if (!text && !file) return toast(t('writeSomething'));
  await guard(b, async () => {
    b.textContent = t('posting');
    try {
      const mediaUrl = file ? await uploadFile(file, 'cProgress') : '';
      await addDoc(collection(db, 'posts'), {
        uid: me(), name: myName(), photo: myPhoto(), body: text, mediaUrl, mediaType: file?.type || '',
        privacy: ctx.groupId ? 'public' : $('cPrivacy').value, groupId: ctx.groupId || '', groupName: ctx.groupName || '',
        likes: [], commentCount: 0, createdAt: serverTimestamp()
      });
      $('cText').value = ''; $('cFile').value = ''; clearPreview('cPreview');
      closeModal('m-composer'); toast(t('posted'));
      if (!ctx.groupId && S.route.id !== 'home') go('home');
    } finally { b.textContent = t('post'); }
  });
}

/* ============================== STORIES ============================== */
function groupStories() {
  const m = new Map();
  for (const s of S.stories) { if (!m.has(s.uid)) m.set(s.uid, { uid: s.uid, name: s.name, photo: s.photo, items: [] }); m.get(s.uid).items.push(s); }
  m.forEach(g => g.items.sort((a, b) => ms(a.createdAt) - ms(b.createdAt)));
  return [...m.values()].sort((a, b) => ms(b.items.at(-1).createdAt) - ms(a.items.at(-1).createdAt));
}
const seenStories = () => { try { return new Set(JSON.parse(lsGet('friends_seen_stories', '[]'))); } catch { return new Set(); } };
const thumbOf = s => { const u = safeUrl(s.mediaUrl); if (!u) return ''; return (s.mediaType || '').startsWith('video') ? u.replace(/\.[a-z0-9]{2,4}(\?.*)?$/i, '.jpg') : u; };
function renderStoryRow() {
  const row = $('storyRow'), seen = seenStories();
  const mp = safeUrl(myPhoto());
  const create = el(`<button class="story-card create" data-act="openStory"><div class="top">${mp ? '' : esc(initial(myName()))}</div><span class="plus">${ic('add', 'sm')}</span><span class="nm">${t('createStory')}</span></button>`);
  if (mp) create.querySelector('.top').style.backgroundImage = bgUrl(mp);
  row.innerHTML = ''; row.append(create);
  groupStories().forEach(g => {
    const last = g.items.at(-1), allSeen = g.items.every(i => seen.has(i.id));
    const n = el(`<button class="story-card${allSeen ? ' seen' : ''}" data-act="viewStory" data-arg="${esc(g.uid)}"><div class="bg"></div>${last.text ? `<div class="tx">${esc(last.text)}</div>` : ''}${avatar(g.name, g.photo)}<span class="nm ellipsis">${esc(g.name || '')}</span></button>`);
    const bg = n.querySelector('.bg'), th = thumbOf(last);
    bg.style.background = th ? `${bgUrl(th)} center/cover` : BGS[(last.bg || 0) % BGS.length];
    row.append(n);
  });
}
const V = { groups: [], g: 0, i: 0, timer: null };
function stopStory() { clearTimeout(V.timer); V.timer = null; const v = q('#svBox video'); if (v) v.pause(); }
function openViewer(uid) {
  V.groups = groupStories(); V.g = Math.max(0, V.groups.findIndex(g => g.uid === uid)); V.i = 0;
  if (!V.groups.length) return;
  openModal('storyViewer'); showStory();
}
function showStory() {
  stopStory();
  const g = V.groups[V.g], s = g?.items[V.i];
  if (!s) return closeModal('storyViewer');
  const seen = seenStories(); seen.add(s.id); lsSet('friends_seen_stories', JSON.stringify([...seen].slice(-300)));
  const mu = safeUrl(s.mediaUrl), isVid = (s.mediaType || '').startsWith('video');
  const body = s.text ? `<div class="sv-text" style="background:${BGS[(s.bg || 0) % BGS.length]}">${esc(s.text)}</div>`
    : isVid ? `<video class="sv-media" src="${esc(mu)}" autoplay playsinline></video>` : `<img class="sv-media" src="${esc(mu)}" alt="">`;
  $('svBox').innerHTML = `<div class="bars">${g.items.map(() => '<i><b></b></i>').join('')}</div>
    <div class="sv-head">${avatar(g.name, g.photo, 'sm')}<b>${esc(g.name || '')}</b><span class="small">${esc(ago(s.createdAt))}</span><span class="grow"></span>
    ${s.uid === me() ? `<button class="icon-btn" data-act="svDelete">${ic('trash', 'sm')}</button>` : ''}<button class="icon-btn" data-act="closeModal" data-arg="storyViewer">${ic('close', 'sm')}</button></div>
    ${body}${s.caption ? `<div class="sv-cap">${esc(s.caption)}</div>` : ''}<div class="zone l" data-act="svPrev"></div><div class="zone r" data-act="svNext"></div>`;
  const bars = qa('.bars i b', $('svBox'));
  bars.forEach((b, k) => { b.style.width = k < V.i ? '100%' : '0'; });
  const run = dur => {
    const b = bars[V.i]; b.style.transition = `width ${dur}ms linear`; requestAnimationFrame(() => requestAnimationFrame(() => { b.style.width = '100%'; }));
    V.timer = setTimeout(svNext, dur);
  };
  const v = q('video', $('svBox'));
  if (v) {
    v.addEventListener('loadedmetadata', () => { clearTimeout(V.timer); run(Math.min((v.duration || 8) * 1000, 60000)); }, { once: true });
    v.play().catch(() => { v.muted = true; v.play().catch(() => {}); });
  } else run(5000);
}
function svNext() { const g = V.groups[V.g]; if (V.i + 1 < g.items.length) V.i++; else if (V.g + 1 < V.groups.length) { V.g++; V.i = 0; } else { closeModal('storyViewer'); renderStoryRow(); return; } showStory(); }
function svPrev() { if (V.i > 0) V.i--; else if (V.g > 0) { V.g--; V.i = 0; } showStory(); }

function storyMode(mode) {
  S.storyMode = mode;
  $('sTabMedia').classList.toggle('active', mode === 'media'); $('sTabText').classList.toggle('active', mode === 'text');
  $('sMedia').classList.toggle('hidden', mode !== 'media'); $('sText').classList.toggle('hidden', mode !== 'text');
}
function pickBg(i) { S.storyBg = i; $('sTextPrev').style.background = BGS[i]; qa('.bg-pick').forEach((b, k) => b.classList.toggle('on', k === i)); }
async function publishStory(b) {
  const data = { uid: me(), name: myName(), photo: myPhoto(), caption: $('sCaption').value.trim(), createdAt: serverTimestamp(), expiresAt: Date.now() + 86400000, mediaUrl: '', mediaType: '', text: '', bg: 0 };
  await guard(b, async () => {
    if (S.storyMode === 'media') {
      const f = $('sFile').files[0]; if (!f) return toast(t('chooseFile'));
      data.mediaUrl = await uploadFile(f, 'sProgress'); data.mediaType = f.type;
    } else {
      const txt = $('sTextPrev').textContent.trim(); if (!txt) return toast(t('typeSomething'));
      data.text = txt.slice(0, 300); data.bg = S.storyBg;
    }
    await addDoc(collection(db, 'stories'), data);
    $('sFile').value = ''; clearPreview('sPreview'); $('sTextPrev').textContent = ''; $('sCaption').value = '';
    closeModal('m-story'); toast(t('storyShared'));
  });
}

/* ============================== NOTIFICATIONS ============================== */
function renderNotifs() {
  const box = $('notifList');
  box.innerHTML = S.notifs.map(n => `<button class="list-item${n.read ? '' : ' unread'}" data-act="openNotif" data-id="${esc(n.id)}">${avatar(n.fromName, n.fromPhoto)}<span class="grow"><span class="t">${esc(t('n.' + n.type, { name: n.fromName || 'FRIENDS user' }))}</span><span class="s" style="display:block">${esc(ago(n.createdAt))}</span></span></button>`).join('')
    || `<div class="empty">${ic('bell')}<div>${t('noNotifications')}</div></div>`;
  const unread = S.notifs.filter(n => !n.read);
  if (unread.length) setTimeout(() => {
    if (S.route.id !== 'notifications') return;
    const b = writeBatch(db); unread.forEach(n => b.update(doc(db, 'notifications', n.id), { read: true })); b.commit().catch(() => {});
  }, 1500);
}
function openNotif(id) {
  const n = S.notifs.find(x => x.id === id); if (!n) return;
  if (n.type === 'friend_request') go('friends');
  else if (n.type === 'friend_accept') go('profile', n.from);
  else if (n.postId) go('post', n.postId);
}

/* ============================== CHAT ============================== */
const chatIdFor = peer => [me(), peer].sort().join('_');
function stopChat() { S.chatUnsub?.(); S.chatUnsub = null; S.chatId = null; S.chatPeer = null; }
function showChatEmpty() {
  $('msgLayout').classList.remove('chatting');
  $('chatTitle').textContent = ''; $('chatAvatar').innerHTML = ''; $('chatAvatar').style.background = 'none';
  $('chatLog').innerHTML = `<div class="msg-empty">${ic('chat', 'lg')}<p>${t('startChat')}</p></div>`;
}
async function renderChatList() {
  const filter = $('chatFilter').value.trim().toLowerCase(), items = [], seen = new Set();
  const peers = S.chats.map(c => c.members.find(m => m !== me())).filter(Boolean);
  await ensureUsers([...peers, ...S.friends]);
  S.chats.forEach(c => {
    const pid = c.members.find(m => m !== me()); if (!pid) return; seen.add(pid);
    const u = S.users.get(pid);
    items.push({ pid, name: u?.name || c.names?.[pid] || 'FRIENDS user', photo: u?.photoUrl || c.photos?.[pid] || '', last: c.lastText || '', unread: chatUnread(c) });
  });
  S.friends.forEach(f => { if (!seen.has(f)) { const u = S.users.get(f); items.push({ pid: f, name: u?.name || 'FRIENDS user', photo: u?.photoUrl || '', last: '', unread: false }); } });
  const shown = items.filter(i => !filter || i.name.toLowerCase().includes(filter));
  $('chatList').innerHTML = shown.map(i => `<button class="list-item" data-act="openChat" data-arg="${esc(i.pid)}">${avatar(i.name, i.photo)}<span class="grow"><span class="t${i.unread ? ' bold' : ''}">${esc(i.name)}</span><span class="s ellipsis" style="display:block${i.unread ? ';color:var(--text);font-weight:700' : ''}">${esc(i.last)}</span></span>${i.unread ? '<span class="dot-like" style="width:12px;height:12px"></span>' : ''}</button>`).join('')
    || `<div class="empty">${t('noChats')}</div>`;
}
async function openChat(peerUid) {
  stopChat();
  const peer = await getUser(peerUid);
  S.chatPeer = peer; S.chatId = chatIdFor(peerUid);
  $('msgLayout').classList.add('chatting');
  fillAvatar($('chatAvatar'), peer.name, peer.photoUrl); $('chatTitle').textContent = peer.name || ''; $('chatHeadBtn').dataset.arg = peerUid;
  const id = S.chatId;
  S.chatUnsub = onSnapshot(query(collection(db, 'chats', id, 'messages'), orderBy('createdAt', 'asc'), limit(200)), snap => {
    const log = $('chatLog'); log.innerHTML = '';
    snap.forEach(d => {
      const m = d.data(), mu = safeUrl(m.mediaUrl);
      log.append(el(`<div class="bubble${m.uid === me() ? ' mine' : ''}">${mu ? `<img src="${esc(mu)}" data-act="lightbox" data-src="${esc(mu)}" alt="">` : ''}${m.text ? esc(m.text) : ''}<span class="tm">${esc(ago(m.createdAt))}</span></div>`));
    });
    if (!snap.size) log.innerHTML = `<div class="msg-empty">${t('writeMessage')}</div>`;
    log.scrollTop = log.scrollHeight;
    lsSet('seen_' + id, Date.now()); updateBadges();
  }, onErr);
}
async function sendMsg({ text = '', mediaUrl = '' }) {
  const id = S.chatId, peer = S.chatPeer; if (!id || !peer) return toast(t('startChat'));
  await addDoc(collection(db, 'chats', id, 'messages'), { uid: me(), text, mediaUrl, createdAt: serverTimestamp() });
  await setDoc(doc(db, 'chats', id), {
    members: [me(), peer.uid].sort(), lastText: text || '📷', lastFrom: me(), lastAt: serverTimestamp(),
    names: { [me()]: myName(), [peer.uid]: peer.name || '' }, photos: { [me()]: myPhoto(), [peer.uid]: peer.photoUrl || '' }
  }, { merge: true });
}

/* ============================== GROUPS ============================== */
async function loadGroups() {
  const s = await getDocs(query(collection(db, 'groups'), limit(60)));
  const list = s.docs.map(d => ({ id: d.id, ...d.data() })).sort((a, b) => ms(b.createdAt) - ms(a.createdAt));
  $('groupList').innerHTML = list.map(g => groupCard(g)).join('') || `<div class="empty card">${ic('groups')}<div>${t('noGroups')}</div></div>`;
}
function groupBtn(g) {
  const isMember = (g.members || []).includes(me());
  if (g.owner === me()) return `<span class="chip active">${t('owner')}</span>`;
  return `<button class="btn btn-sm ${isMember ? '' : 'btn-primary'}" data-act="${isMember ? 'leaveGroup' : 'joinGroup'}" data-arg="${esc(g.id)}">${isMember ? t('leave') : t('join')}</button>`;
}
const groupCard = g => `<div class="card"><div class="row"><button class="avatar lg" style="background:hsl(${hue(g.name)} 55% 45%)" data-act="openGroup" data-arg="${esc(g.id)}">${esc(initial(g.name))}</button>
  <div class="grow"><button class="t bold" style="font-size:17px" data-act="openGroup" data-arg="${esc(g.id)}">${esc(g.name)}</button><div class="muted small">${esc(t('members', { n: (g.members || []).length }))}</div></div>${groupBtn(g)}</div>
  ${g.description ? `<p class="muted" style="margin:10px 0 0">${esc(g.description)}</p>` : ''}</div>`;
async function loadGroup(id) {
  if (!id) return go('groups');
  S.viewUnsubs.push(onSnapshot(doc(db, 'groups', id), snap => {
    if (!snap.exists()) { $('groupHead').innerHTML = `<div class="empty">${t('noResults')}</div>`; return; }
    const g = { id, ...snap.data() }; S.groupName = g.name;
    $('groupHead').innerHTML = `<div class="row"><span class="avatar lg" style="background:hsl(${hue(g.name)} 55% 45%)">${esc(initial(g.name))}</span><div class="grow"><h2 style="margin:0">${esc(g.name)}</h2><div class="muted small">${esc(t('members', { n: (g.members || []).length }))}</div></div>${groupBtn(g)}</div>
      ${g.description ? `<p class="muted">${esc(g.description)}</p>` : ''}
      ${(g.members || []).includes(me()) ? `<button class="btn btn-primary" style="margin-top:10px;width:100%" data-act="openComposer" data-arg="group">${ic('add', 'sm')}${t('createPost')}</button>` : ''}`;
  }, onErr));
  S.viewUnsubs.push(onSnapshot(query(collection(db, 'posts'), where('groupId', '==', id), limit(100)), snap => {
    const box = $('groupPosts'); disposePosts(box); box.innerHTML = '';
    snap.docs.map(d => ({ id: d.id, p: d.data() })).sort((a, b) => ms(b.p.createdAt) - ms(a.p.createdAt)).forEach(x => box.append(renderPost(x.id, x.p)));
  }, onErr));
}

/* ============================== REELS ============================== */
let reelsMuted = true;
async function loadReels() {
  const box = $('reelList'); box.innerHTML = '';
  const s = await getDocs(query(collection(db, 'reels'), orderBy('createdAt', 'desc'), limit(30)));
  const list = s.docs.map(d => ({ id: d.id, ...d.data() }));
  await ensureUsers(list.map(r => r.uid));
  box.innerHTML = `<div class="reels-bar"><b style="font-size:20px">${t('reels')}</b><button class="btn btn-sm btn-primary" data-act="openReel">${ic('add', 'sm')}${t('reel')}</button></div>`;
  if (!list.length) box.insertAdjacentHTML('beforeend', `<div class="reel"><div class="empty" style="color:#fff">${ic('reels')}<div>${t('noReels')}</div></div></div>`);
  const io = new IntersectionObserver(es => es.forEach(e => { const v = q('video', e.target); if (!v) return; if (e.isIntersecting) { v.muted = reelsMuted; v.play().catch(() => { v.muted = true; v.play().catch(() => {}); }); } else v.pause(); }), { threshold: 0.7 });
  list.forEach(r => {
    const u = S.users.get(r.uid) || {}, vu = safeUrl(r.videoUrl); if (!vu) return;
    const n = el(`<div class="reel" data-id="${esc(r.id)}"><video src="${esc(vu)}" playsinline loop muted preload="metadata"></video>
      <div class="side"><button class="icon-btn" data-act="reelMute">${ic(reelsMuted ? 'mute' : 'volume')}</button>${r.uid === me() || S.me?.role === 'admin' ? `<button class="icon-btn" data-act="delReel">${ic('trash', 'sm')}</button>` : ''}</div>
      <div class="info"><button class="row" data-act="openProfile" data-arg="${esc(r.uid)}">${avatar(u.name, u.photoUrl, 'sm')}<b>${esc(u.name || 'FRIENDS user')}</b></button><div style="margin-top:6px">${esc(r.caption || '')}</div></div></div>`);
    n.addEventListener('click', e => { if (e.target.closest('button')) return; const v = q('video', n); v.paused ? v.play() : v.pause(); });
    box.append(n); io.observe(n);
  });
  S.viewUnsubs.push(() => io.disconnect());
}
async function publishReel(b) {
  const f = $('rFile').files[0]; if (!f || !f.type.startsWith('video/')) return toast(t('chooseFile'));
  await guard(b, async () => {
    const url = await uploadFile(f, 'rProgress');
    await addDoc(collection(db, 'reels'), { uid: me(), name: myName(), photo: myPhoto(), caption: $('rCaption').value.trim(), videoUrl: url, createdAt: serverTimestamp() });
    $('rFile').value = ''; $('rCaption').value = ''; clearPreview('rPreview');
    closeModal('m-reel'); toast(t('reelShared')); if (S.route.id === 'reels') loadReels();
  });
}

/* ============================== MARKETPLACE ============================== */
const listingCache = new Map();
async function loadMarket() {
  const s = await getDocs(query(collection(db, 'marketplace'), orderBy('createdAt', 'desc'), limit(60)));
  listingCache.clear();
  $('marketList').innerHTML = s.docs.map(d => {
    const x = { id: d.id, ...d.data() }; listingCache.set(d.id, x);
    const img = safeUrl(x.imageUrl);
    return `<button class="listing" data-act="viewListing" data-arg="${esc(d.id)}"><div class="ph"${img ? ` style="background-image:${bgUrl(img).replace(/"/g, '&quot;')}"` : ''}>${img ? '' : ic('store', 'lg')}</div><div class="b"><div class="pr">${esc(x.price || '')}</div><div class="ellipsis">${esc(x.title || '')}</div></div></button>`;
  }).join('') || `<div class="empty card" style="grid-column:1/-1">${ic('store')}<div>${t('noListings')}</div></div>`;
}
async function viewListing(id) {
  const x = listingCache.get(id); if (!x) return;
  const seller = await getUser(x.uid), img = safeUrl(x.imageUrl);
  $('listingBody').innerHTML = `${img ? `<img src="${esc(img)}" alt="" style="width:100%;border-radius:10px;max-height:340px;object-fit:cover">` : ''}
    <h2 style="margin:10px 0 2px">${esc(x.title)}</h2><div class="bold" style="font-size:20px">${esc(x.price || '')}</div>
    <p style="white-space:pre-wrap">${linkify(x.description || '')}</p>
    <div class="row" style="margin:10px 0">${avatar(seller.name, seller.photoUrl, 'sm')}<span class="t">${esc(seller.name || '')}</span></div>
    ${x.uid === me() ? `<button class="btn btn-danger" style="width:100%" data-act="delListing" data-arg="${esc(id)}">${ic('trash', 'sm')}${t('delete')}</button>` : `<button class="btn btn-primary" style="width:100%" data-act="openChat" data-arg="${esc(x.uid)}">${ic('chat', 'sm')}${t('messageSeller')}</button>`}`;
  openModal('m-listingView');
}
async function publishListing(b) {
  const title = $('lTitle').value.trim(); if (!title) return toast(t('itemTitle'));
  await guard(b, async () => {
    const f = $('lFile').files[0]; const imageUrl = f ? await uploadFile(f, 'lProgress') : '';
    await addDoc(collection(db, 'marketplace'), { uid: me(), title, price: $('lPrice').value.trim(), description: $('lDesc').value.trim(), imageUrl, createdAt: serverTimestamp() });
    ['lTitle', 'lPrice', 'lDesc', 'lFile'].forEach(i => { $(i).value = ''; }); clearPreview('lPreview');
    closeModal('m-listing'); toast(t('listingShared')); if (S.route.id === 'market') loadMarket();
  });
}

/* ============================== PROFILE / SINGLE POST / SEARCH / ADMIN ============================== */
function renderProfileActions() {
  const uid = S.profileUid, box = $('profileActions'); if (!box || !uid) return;
  box.innerHTML = uid === me() ? `<button class="btn btn-primary" data-act="openProfileEdit">${ic('edit', 'sm')}${t('editProfile')}</button>` : friendBtns(uid) + (friendStatus(uid) !== 'friends' ? `<button class="btn" data-act="openChat" data-arg="${uid}">${t('message')}</button>` : '');
}
async function loadProfile(uid) {
  S.profileUid = uid;
  const u = uid === me() ? S.me : await getUser(uid);
  $('profileHead').innerHTML = `<div class="cover"></div><div class="profile-head">${avatar(u.name, u.photoUrl, 'xl')}<div class="grow"><h2>${esc(u.name || 'FRIENDS user')}</h2>${u.bio ? `<div class="muted">${esc(u.bio)}</div>` : ''}${uid === me() ? `<div class="muted small">${esc(t('friends'))}: ${S.friends.size}</div>` : ''}</div><div class="profile-actions" id="profileActions"></div></div>`;
  renderProfileActions();
  S.viewUnsubs.push(onSnapshot(query(collection(db, 'posts'), where('uid', '==', uid), limit(60)), snap => {
    const box = $('profilePosts'); disposePosts(box); box.innerHTML = '';
    const list = snap.docs.map(d => ({ id: d.id, p: d.data() })).filter(x => x.p.uid === me() || x.p.privacy !== 'friends' || S.friends.has(x.p.uid)).sort((a, b) => ms(b.p.createdAt) - ms(a.p.createdAt));
    list.forEach(x => box.append(renderPost(x.id, x.p)));
    if (!list.length) box.innerHTML = `<div class="empty card">${ic('comment')}<div>${t('noPosts')}</div></div>`;
  }, onErr));
}
function loadPost(id) {
  if (!id) return go('home');
  S.viewUnsubs.push(onSnapshot(doc(db, 'posts', id), snap => {
    const box = $('singlePost'); disposePosts(box); box.innerHTML = '';
    if (!snap.exists()) { box.innerHTML = `<div class="empty card">${t('noResults')}</div>`; return; }
    box.append(renderPost(id, snap.data()));
  }, onErr));
}
let searchTok = 0;
async function renderSearch(term) {
  term = (term || '').trim().toLowerCase();
  const tok = ++searchTok, box = $('searchPeople'), pbox = $('searchPosts');
  disposePosts(pbox); pbox.innerHTML = '';
  if (!term) { box.innerHTML = `<div class="muted small">${t('searchPh')}</div>`; return; }
  const users = (await allUsers().catch(() => [])).filter(u => u.uid !== me() && ((u.name || '').toLowerCase().includes(term) || (u.email || '').toLowerCase().includes(term)));
  if (tok !== searchTok) return;
  box.innerHTML = users.slice(0, 20).map(u => `<div class="list-item"><button class="row grow" data-act="openProfile" data-arg="${u.uid}">${avatar(u.name, u.photoUrl)}<span><span class="t">${esc(u.name || '')}</span></span></button>${friendBtns(u.uid)}</div>`).join('') || `<div class="muted small">${t('noResults')}</div>`;
  [...S.feedData.entries()].filter(([, p]) => ((p.body || '') + ' ' + (p.name || '')).toLowerCase().includes(term) && (p.uid === me() || p.privacy !== 'friends' || S.friends.has(p.uid))).slice(0, 15).forEach(([id, p]) => pbox.append(renderPost(id, p)));
}
async function loadAdmin() {
  const box = $('adminData');
  if (S.me?.role !== 'admin') { box.innerHTML = `<p class="muted">Admin access is restricted. In Firebase Console → Firestore → users → your document, set <code>role</code> to <code>admin</code>.</p>`; return; }
  const cols = [['users', t('users')], ['posts', t('posts')], ['groups', t('groups')], ['marketplace', t('listings')], ['reels', t('reels')]];
  const counts = await Promise.all(cols.map(([c]) => getCountFromServer(collection(db, c)).then(r => r.data().count).catch(() => '—')));
  box.innerHTML = `<div class="menu-grid">${cols.map(([, l], i) => `<div class="menu-tile"><span class="bold" style="font-size:26px">${counts[i]}</span><span class="muted">${esc(l)}</span></div>`).join('')}</div>`;
}

/* ============================== ACTIONS ============================== */
const postOf = b => b.closest('.post');
const actions = {
  go: b => go(b.dataset.arg),
  openProfile: b => go('profile', b.dataset.arg || me()),
  openMyProfile: () => go('profile', me()),
  openGroup: b => go('group', b.dataset.arg),
  openChat: b => go('messages', b.dataset.arg),
  closeChat: () => go('messages'),
  login: b => doLogin(b), signup: b => doSignup(b), forgot: () => doForgot(),
  showSignup: () => { $('loginPanel').classList.add('hidden'); $('signupPanel').classList.remove('hidden'); },
  showLogin: () => { $('signupPanel').classList.add('hidden'); $('loginPanel').classList.remove('hidden'); },
  logout: () => signOut(auth),
  sendOTP: async () => {
    if (!S.recaptcha) S.recaptcha = new RecaptchaVerifier(auth, 'recaptcha-container', { size: 'normal' });
    S.confirmation = await signInWithPhoneNumber(auth, $('phone').value.trim(), S.recaptcha); toast(t('codeSent'));
  },
  verifyOTP: async () => { if (!S.confirmation) return toast(t('sendCode')); await S.confirmation.confirm($('otp').value.trim()); },
  toggleTheme: () => { lsSet('friends_theme', document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark'); applyTheme(); },
  resendVerify: async () => { await sendEmailVerification(S.user); toast(t('verifySent')); },
  closeModal: b => closeModal(b.dataset.arg),
  confirmYes: () => { closeModal('m-confirm'); confirmRes?.(true); },
  confirmNo: () => { closeModal('m-confirm'); confirmRes?.(false); },
  lightbox: b => { $('lightImg').src = b.dataset.src; openModal('lightbox'); },
  pickFile: b => $(b.dataset.arg).click(),
  clearFile: b => { const [i, p] = b.dataset.arg.split('|'); $(i).value = ''; clearPreview(p); },
  // posts
  openComposer: b => openComposer(b?.dataset?.arg),
  publishPost: b => publishPost(b),
  like: async b => {
    const node = postOf(b), id = node.dataset.id, p = node._p, liked = (p.likes || []).includes(me());
    const prev = p.likes || [];
    updatePost(node, { ...p, likes: liked ? prev.filter(x => x !== me()) : [...prev, me()] });
    try {
      await updateDoc(doc(db, 'posts', id), { likes: liked ? arrayRemove(me()) : arrayUnion(me()) });
      if (!liked) notify(p.uid, 'like', { postId: id }, `like_${id}_${me()}`);
    } catch (e) { updatePost(node, p); onErr(e); }
  },
  toggleComments: b => {
    const node = postOf(b), box = q('.comments', node), open = box.classList.toggle('hidden') === false;
    if (open) { subscribeComments(node); q('input', box).focus(); } else { node._cu?.(); node._cu = null; }
  },
  sendComment: async b => {
    const node = postOf(b), inp = q('.comment-form input', node), text = inp.value.trim(); if (!text) return;
    const id = node.dataset.id; inp.value = '';
    const batch = writeBatch(db);
    batch.set(doc(collection(db, 'posts', id, 'comments')), { uid: me(), name: myName(), photo: myPhoto(), text, createdAt: serverTimestamp() });
    batch.update(doc(db, 'posts', id), { commentCount: increment(1) });
    try { await batch.commit(); notify(node._p.uid, 'comment', { postId: id }); } catch (e) { inp.value = text; throw e; }
  },
  delComment: async b => {
    const c = b.closest('.comment'), node = postOf(b);
    if (!(await confirmBox(t('confirmDelete')))) return;
    const batch = writeBatch(db);
    batch.delete(doc(db, 'posts', c.dataset.pid, 'comments', c.dataset.cid));
    batch.update(doc(db, 'posts', c.dataset.pid), { commentCount: increment(-1) });
    await batch.commit(); void node;
  },
  deletePost: b => deletePost(postOf(b)),
  sharePost: async b => {
    const link = `${location.origin}${location.pathname}#post/${postOf(b).dataset.id}`;
    if (navigator.share) { try { await navigator.share({ title: 'FRIENDS', url: link }); } catch { /* cancelled */ } }
    else if (navigator.clipboard) { await navigator.clipboard.writeText(link); toast(t('copied')); }
    else toast(link);
  },
  // friends
  addFriend: b => guard(b, () => sendRequest(b.dataset.arg)),
  acceptReq: b => guard(b, () => acceptRequest(b.dataset.arg)),
  removeReq: b => guard(b, () => removeRequest(b.dataset.arg)),
  cancelReq: b => guard(b, () => removeRequest(b.dataset.arg)),
  unfriend: async b => { if (await confirmBox(t('confirmDelete'))) await removeRequest(b.dataset.arg); },
  // stories
  openStory: () => { storyMode('media'); pickBg(0); openModal('m-story'); },
  storyMode: b => storyMode(b.dataset.arg), pickBg: b => pickBg(Number(b.dataset.arg)),
  publishStory: b => publishStory(b),
  viewStory: b => openViewer(b.dataset.arg), svNext, svPrev,
  svDelete: async () => {
    const s = V.groups[V.g]?.items[V.i]; if (!s) return;
    stopStory(); if (!(await confirmBox(t('confirmDelete')))) return showStory();
    await deleteDoc(doc(db, 'stories', s.id)); closeModal('storyViewer');
  },
  // notifications
  openNotif: b => openNotif(b.dataset.id),
  // chat
  sendMessage: async () => { const inp = $('chatInput'), text = inp.value.trim(); if (!text) return; inp.value = ''; try { await sendMsg({ text }); } catch (e) { inp.value = text; throw e; } },
  chatAttach: () => $('chatFile').click(),
  // groups
  openGroupCreate: () => openModal('m-group'),
  createGroup: async b => {
    const name = $('gName').value.trim(); if (!name) return toast(t('groupName'));
    await guard(b, async () => {
      await addDoc(collection(db, 'groups'), { name, description: $('gDesc').value.trim(), owner: me(), members: [me()], createdAt: serverTimestamp() });
      $('gName').value = ''; $('gDesc').value = ''; closeModal('m-group'); toast(t('groupCreated')); loadGroups();
    });
  },
  joinGroup: async b => { await guard(b, () => updateDoc(doc(db, 'groups', b.dataset.arg), { members: arrayUnion(me()) })); if (S.route.id === 'groups') loadGroups(); },
  leaveGroup: async b => { await guard(b, () => updateDoc(doc(db, 'groups', b.dataset.arg), { members: arrayRemove(me()) })); if (S.route.id === 'groups') loadGroups(); },
  // reels / market
  openReel: () => openModal('m-reel'), publishReel: b => publishReel(b),
  reelMute: b => { reelsMuted = !reelsMuted; qa('.reel video').forEach(v => { v.muted = reelsMuted; }); qa('[data-act=reelMute]').forEach(x => { x.innerHTML = ic(reelsMuted ? 'mute' : 'volume'); }); void b; },
  delReel: async b => { if (!(await confirmBox(t('confirmDelete')))) return; await deleteDoc(doc(db, 'reels', b.closest('.reel').dataset.id)); loadReels(); },
  openListing: () => openModal('m-listing'), publishListing: b => publishListing(b),
  viewListing: b => viewListing(b.dataset.arg),
  delListing: async b => { if (!(await confirmBox(t('confirmDelete')))) return; await deleteDoc(doc(db, 'marketplace', b.dataset.arg)); closeModal('m-listingView'); loadMarket(); },
  // profile
  openProfileEdit: () => { $('pName').value = S.me?.name || ''; $('pBio').value = S.me?.bio || ''; $('pFile').value = ''; openModal('m-profile'); },
  saveProfile: async b => {
    const name = $('pName').value.trim(); if (!name) return toast(t('displayName'));
    await guard(b, async () => {
      const f = $('pFile').files[0]; const photoUrl = f ? await uploadFile(f, 'pProgress') : S.me?.photoUrl || '';
      const bio = $('pBio').value.trim();
      await updateDoc(doc(db, 'users', me()), { name, bio, photoUrl });
      try { await updateProfile(S.user, { displayName: name, ...(photoUrl ? { photoURL: photoUrl } : {}) }); } catch (e) { console.warn(e); }
      S.me = { ...S.me, name, bio, photoUrl }; S.users.set(me(), S.me);
      setMyUI(); renderSide(); renderStoryRow(); closeModal('m-profile'); toast(t('saved'));
      if (S.route.id === 'profile') loadProfile(me());
    });
  }
};

document.addEventListener('click', e => {
  const m = e.target.classList?.contains('modal') ? e.target : null;
  if (m) { if (m.id === 'm-confirm') actions.confirmNo(); else closeModal(m.id); return; }
  const b = e.target.closest('[data-act]'); if (!b) return;
  const fn = actions[b.dataset.act]; if (!fn) return;
  if (b.tagName === 'A') e.preventDefault();
  try { const r = fn(b, e); if (r?.catch) r.catch(onErr); } catch (err) { onErr(err); }
});
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') { const open = qa('.modal').filter(m => !m.classList.contains('hidden')).pop(); if (open) { open.id === 'm-confirm' ? actions.confirmNo() : closeModal(open.id); } return; }
  if (e.key !== 'Enter' || e.shiftKey || e.isComposing) return;
  const tg = e.target;
  if (tg.id === 'password' || tg.id === 'email') actions.login($('loginPanel').querySelector('[data-act=login]'));
  else if (tg.id === 'signupPassword') actions.signup($('signupPanel').querySelector('[data-act=signup]'));
  else if (tg.id === 'chatInput') { e.preventDefault(); actions.sendMessage(); }
  else if (tg.matches?.('.comment-form input')) { e.preventDefault(); q('[data-act=sendComment]', tg.parentElement).click(); }
});
window.addEventListener('popstate', () => { if (!S.user) return; const r = parseHash(); render(r.id, r.arg); });
window.addEventListener('online', () => $('offlineBar').classList.add('hidden'));
window.addEventListener('offline', () => $('offlineBar').classList.remove('hidden'));
matchMedia('(prefers-color-scheme: dark)').addEventListener?.('change', applyTheme);

/* inputs */
['langSelect', 'langSelect2'].forEach(id => $(id).addEventListener('change', e => {
  setLang(e.target.value); $('langSelect').value = e.target.value; $('langSelect2').value = e.target.value;
  authStatus(t('signInStatus')); if (S.user) location.reload();
}));
let sTimer;
const doSearch = v => { clearTimeout(sTimer); sTimer = setTimeout(() => renderSearch(v), 250); };
$('globalSearch').addEventListener('input', e => doSearch(e.target.value));
$('topSearch').addEventListener('input', e => { if (!S.user) return; if (S.route.id !== 'search') go('search'); $('globalSearch').value = e.target.value; doSearch(e.target.value); });
$('topSearch').addEventListener('focus', () => { if (S.user && S.route.id !== 'search') go('search'); });
$('chatFilter').addEventListener('input', () => renderChatList());
$('chatFile').addEventListener('change', async e => {
  const f = e.target.files[0]; e.target.value = ''; if (!f) return;
  try { toast(t('posting')); const url = await uploadFile(f); await sendMsg({ mediaUrl: url }); } catch (err) { onErr(err); }
});
$('sTextPrev').addEventListener('input', () => { const e = $('sTextPrev'); if (!e.textContent.trim()) e.innerHTML = ''; });
bindPreview('cFile', 'cPreview'); bindPreview('sFile', 'sPreview'); bindPreview('rFile', 'rPreview'); bindPreview('lFile', 'lPreview');
$('bgPicks').innerHTML = BGS.map((g, i) => `<button type="button" class="bg-pick" data-act="pickBg" data-arg="${i}" style="background:${g}"></button>`).join('');

/* ============================== BOOT ============================== */
applyTheme();
setLang(getLang());
$('langSelect').value = getLang();
authStatus(ready ? t('signInStatus') : t('e.network-request-failed'), !ready);
if (!navigator.onLine) $('offlineBar').classList.remove('hidden');
if ('serviceWorker' in navigator) addEventListener('load', () => navigator.serviceWorker.register('./sw.js').catch(e => console.warn('SW:', e)));
