import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, onAuthStateChanged, updateProfile, sendEmailVerification, sendPasswordResetEmail, RecaptchaVerifier, signInWithPhoneNumber, setPersistence, browserLocalPersistence } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import { getFirestore, doc, setDoc, getDoc, addDoc, collection, query, orderBy, limit, onSnapshot, serverTimestamp, where, getDocs, updateDoc, arrayUnion, arrayRemove, increment } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";
import { getStorage, ref, uploadBytes, getDownloadURL } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-storage.js";

// 1) Replace every value below with your Firebase project's Web App config.
const firebaseConfig = {
  apiKey: "AIzaSyBPeS26WsCXhoJRPCArgMZFMHmW4eoGdio",
  authDomain: "friends-social-network-56ad6.firebaseapp.com",
  projectId: "friends-social-network-56ad6",
  storageBucket: "friends-social-network-56ad6.firebasestorage.app",
  messagingSenderId: "1068510058667",
  appId: "1:1068510058667:web:5eb8cd7bb2dd48a511ffee",
  measurementId: "G-8NH49MGXYE"
};
const configured = true;
let app,auth,db,storage;
if(configured){app=initializeApp(firebaseConfig);auth=getAuth(app);setPersistence(auth,browserLocalPersistence).catch(e=>console.error('Auth persistence:',e));db=getFirestore(app);storage=getStorage(app);document.getElementById('authStatus').textContent='Firebase connected. Use your email address to sign in.';}
else document.getElementById('authStatus').textContent='Setup required: add your Firebase Web App config in app.js. See SETUP_GUIDE.txt.';
let current=null,chatPeer=null,chatUnsub=null,feedUnsub=null,storyUnsub=null,recaptcha=null,confirmation=null;
const $=id=>document.getElementById(id);
window.toast=(m)=>{let t=$('toast');t.textContent=m;t.style.display='block';setTimeout(()=>t.style.display='none',2600)};
window.show=(id,btn)=>{document.querySelectorAll('.screen').forEach(x=>x.classList.remove('active'));$(id)?.classList.add('active');document.querySelectorAll('.tabs button').forEach(x=>x.classList.remove('active'));if(btn)btn.classList.add('active');if(id==='home'&&current)loadFeed();if(id==='stories'&&current)loadStories();if(id==='notifications'&&current)loadNotifications();if(id==='groups'&&current)loadGroups();if(id==='market'&&current)loadMarket();if(id==='reels'&&current)loadReels();window.scrollTo(0,0)};
function need(){if(!current){toast('Please log in first.');show('auth');return false}if(!db){toast('Configure Firebase first (see setup guide).');return false}return true}
window.showSignup=()=>{$('loginPanel').classList.add('hidden');$('signupPanel').classList.remove('hidden');$('authStatus').textContent='';};
window.showLogin=()=>{$('signupPanel').classList.add('hidden');$('loginPanel').classList.remove('hidden');};
function authMessage(e){
  const code=e?.code||'';
  const messages={
    'auth/invalid-email':'Email address is not valid. Check the spelling.',
    'auth/missing-email':'Enter your email address.',
    'auth/missing-password':'Enter your password.',
    'auth/weak-password':'Password must contain at least 6 characters.',
    'auth/email-already-in-use':'This email already has an account. Log in or use Forgot password.',
    'auth/user-not-found':'No account was found for this email. Create an account first.',
    'auth/wrong-password':'Incorrect password. Try again or use Forgot password.',
    'auth/invalid-credential':'Email or password is incorrect. Check both and try again.',
    'auth/invalid-login-credentials':'Email or password is incorrect. Check both and try again.',
    'auth/too-many-requests':'Too many attempts. Wait a little and try again.',
    'auth/network-request-failed':'Internet connection failed. Check your connection and retry.',
    'auth/operation-not-allowed':'Email/Password sign-in is not enabled in Firebase Console > Authentication > Sign-in method.',
    'auth/unauthorized-domain':'This app domain is not authorized. Add its domain in Firebase Console > Authentication > Settings > Authorized domains.',
    'auth/api-key-not-valid.-please-pass-a-valid-api-key.':'Firebase API key is invalid. Check the Web App config in app.js.',
    'auth/requires-recent-login':'Please log out and log in again, then retry.'
  };
  return messages[code] || e?.message || 'Something went wrong. Check Firebase Authentication settings and try again.';
}
window.signupFromScreen=async()=>{
  if(!configured)return toast('Firebase config is missing.');
  const name=$('name').value.trim(),email=$('signupEmail').value.trim().toLowerCase(),pass=$('signupPassword').value;
  if(!name||!email||!pass)return toast('Enter your name, email and password.');
  if(!email.includes('@'))return toast('Enter a valid email address.');
  if(pass.length<6)return toast('Password must contain at least 6 characters.');
  try{
    const cred=await createUserWithEmailAndPassword(auth,email,pass);
    try{await updateProfile(cred.user,{displayName:name});}catch(e){console.warn('Could not set display name:',e);}
    try{await setDoc(doc(db,'users',cred.user.uid),{uid:cred.user.uid,name,email,bio:'',createdAt:serverTimestamp(),friends:[],role:'user'});}
    catch(e){console.error('Profile document write failed:',e);toast('Account created, but profile data could not be saved. Check Firestore Rules.');}
    try{await sendEmailVerification(cred.user);toast('Account created. A verification email was sent.');}
    catch(e){console.warn('Verification email failed:',e);toast('Account created, but verification email could not be sent: '+authMessage(e));}
  }catch(e){console.error('Sign up failed:',e);toast(authMessage(e));}
};
window.showLogin=()=>{$('signupPanel').classList.add('hidden');$('loginPanel').classList.remove('hidden');};
window.forgotPassword=async()=>{
  if(!configured)return toast('Firebase config is missing.');
  const email=$('email').value.trim().toLowerCase();
  if(!email||!email.includes('@'))return toast('Enter the account email address in the email field first.');
  try{await sendPasswordResetEmail(auth,email);toast('Password reset email sent. Check Inbox and Spam.');}
  catch(e){console.error('Password reset failed:',e);toast(authMessage(e));}
};
window.signup=async()=>window.signupFromScreen();
window.login=async()=>{
  if(!configured)return toast('Firebase config is missing.');
  const email=$('email').value.trim().toLowerCase(),password=$('password').value;
  if(!email||!email.includes('@'))return toast('Enter your email address (phone number is not supported in this email login field).');
  if(!password)return toast('Enter your password.');
  try{await signInWithEmailAndPassword(auth,email,password);}
  catch(e){console.error('Login failed:',e);toast(authMessage(e));}
};
window.logout=async()=>{if(auth)await signOut(auth)};
window.sendOTP=async()=>{if(!configured)return toast('Add Firebase config first.');try{if(!recaptcha)recaptcha=new RecaptchaVerifier(auth,'recaptcha-container',{size:'normal'});confirmation=await signInWithPhoneNumber(auth,$('phone').value.trim(),recaptcha);toast('OTP sent by SMS.')}catch(e){toast(e.message)}};
window.verifyOTP=async()=>{try{if(!confirmation)throw Error('Request an OTP first.');await confirmation.confirm($('otp').value.trim())}catch(e){toast(e.message)}};
if(auth) onAuthStateChanged(auth,async user=>{
  if(!user){current=null;show('auth');return;}
  current=user;
  let data={name:user.displayName||'FRIENDS member',bio:'',email:user.email||''};
  try{
    const uref=doc(db,'users',user.uid),snap=await getDoc(uref);
    if(!snap.exists())await setDoc(uref,{uid:user.uid,name:data.name,email:data.email,bio:'',createdAt:serverTimestamp(),friends:[],role:'user'});
    else data=snap.data();
  }catch(e){console.error('User profile load failed:',e);toast('You are logged in, but profile data could not load. Check Firestore Rules.');}
  $('myAvatar').textContent=(data.name||'F')[0].toUpperCase();
  if(data.photoUrl){$('myAvatar').style.backgroundImage=`url(\"${data.photoUrl}\")`;$('myAvatar').style.backgroundSize='cover';$('myAvatar').textContent='';}
  $('profileName').value=data.name||'';$('profileBio').value=data.bio||'';$('profileEmail').textContent=user.email||user.phoneNumber||'';
  show('home');
  try{loadFeed();loadStories();}catch(e){console.error('Initial app data load failed:',e);}
});
async function upload(file, path) {
  if (!file) return "";
  if (!current) throw new Error("Please log in first.");
  const video = file.type.startsWith("video/");
  const image = file.type.startsWith("image/");
  if (!video && !image) throw new Error("Only images and videos are allowed.");
  const maxSize = video ? 100 * 1024 * 1024 : 10 * 1024 * 1024;
  if (file.size > maxSize) throw new Error("File is too large.");
  const endpoint = `https://api.cloudinary.com/v1_1/zgwfz5od/${video ? "video" : "image"}/upload`;
  const form = new FormData();
  form.append("file", file);
  form.append("upload_preset", "friends_upload");
  const response = await fetch(endpoint, { method: "POST", body: form });
  const result = await response.json();
  if (!response.ok) throw new Error(result.error?.message || "Cloudinary upload failed.");
  return result.secure_url;
}

window.publishPost=async()=>{if(!need())return;try{let text=$('postBody').value.trim();let file=$('postFile').files[0];if(!text&&!file)throw Error('Write a post or select a file.');let mediaUrl=await upload(file,'posts');await addDoc(collection(db,'posts'),{uid:current.uid,name:current.displayName||current.email,body:text,mediaUrl,mediaType:file?.type||'',privacy:$('postPrivacy')?.value||'public',likes:[],createdAt:serverTimestamp()});$('postBody').value='';$('postFile').value='';toast('Your post is online.');show('home');}catch(e){toast(e.message)}};
function loadFeed(){if(!db||!current)return;if(feedUnsub)feedUnsub();let q=query(collection(db,'posts'),orderBy('createdAt','desc'),limit(50));feedUnsub=onSnapshot(q,s=>{let el=$('feed');el.innerHTML='';s.forEach(d=>{let p=d.data(),id=d.id,liked=(p.likes||[]).includes(current.uid);let a=document.createElement('article');a.className='card';let media=p.mediaUrl?(p.mediaType.startsWith('video')?`<video class="postimg" controls src="${p.mediaUrl}"></video>`:`<img class="postimg" src="${p.mediaUrl}">`):'';a.innerHTML=`<div class="posthead"><div class="avatar">${esc((p.name||'F')[0])}</div><div><b>${esc(p.name||'FRIENDS user')}</b><div class="muted">Public · ${time(p.createdAt)}</div></div><div class="spacer"></div></div><div class="posttext">${esc(p.body||'')}</div>${media}<div class="muted">${(p.likes||[]).length} likes</div><div class="postactions"><button data-like="${id}">${liked?'❤️ Liked':'♡ Like'}</button><button data-comment="${id}">💬 Comment</button><button data-share="${id}">↗ Share</button></div><div id="comments-${id}"></div><div class="row"><input class="field" id="comment-input-${id}" placeholder="Write a comment…"><button class="secondary" data-sendcomment="${id}">Send</button></div>`;el.append(a)});});}
$('feed').addEventListener('click',async e=>{let b=e.target.closest('button');if(!b)return;try{if(b.dataset.like){let r=doc(db,'posts',b.dataset.like);let snap=await getDoc(r);let likes=snap.data()?.likes||[];await updateDoc(r,{likes:likes.includes(current.uid)?arrayRemove(current.uid):arrayUnion(current.uid)});}if(b.dataset.sendcomment){let id=b.dataset.sendcomment,txt=$(`comment-input-${id}`).value.trim();if(txt){await addDoc(collection(db,'posts',id,'comments'),{uid:current.uid,name:current.displayName||current.email,text:txt,createdAt:serverTimestamp()});$(`comment-input-${id}`).value='';showComments(id)}}if(b.dataset.comment)showComments(b.dataset.comment);if(b.dataset.share){let link=location.href.split('#')[0]+'#post-'+b.dataset.share;if(navigator.share)await navigator.share({title:'FRIENDS post',url:link});else if(navigator.clipboard){await navigator.clipboard.writeText(link);toast('Post link copied.')}else toast('Share is available after HTTPS hosting.')}}catch(err){toast(err.message)}});
async function showComments(id){let s=await getDocs(query(collection(db,'posts',id,'comments'),orderBy('createdAt','asc'),limit(30)));let el=$(`comments-${id}`);el.innerHTML='';s.forEach(x=>{let c=x.data(),d=document.createElement('div');d.className='bubble';d.textContent=`${c.name}: ${c.text}`;el.append(d)})}
window.publishStory=async()=>{if(!need())return;try{let f=$('storyFile').files[0];if(!f)throw Error('Select a photo or video.');let url=await upload(f,'stories');await addDoc(collection(db,'stories'),{uid:current.uid,name:current.displayName||current.email,caption:$('storyCaption').value,mediaUrl:url,mediaType:f.type,createdAt:serverTimestamp(),expiresAt:Date.now()+86400000});toast('Story shared for 24 hours.');show('home')}catch(e){toast(e.message)}};
function loadStories(){if(storyUnsub)storyUnsub();storyUnsub=onSnapshot(query(collection(db,'stories'),orderBy('createdAt','desc'),limit(40)),s=>{let html='';s.forEach(d=>{let x=d.data();if((x.expiresAt||0)>Date.now())html+=`<div class="story" onclick="window.open('${x.mediaUrl}','_blank')">${esc(x.name)}<br><small>${esc(x.caption||'')}</small></div>`});$('storyList').innerHTML=html;$('allStories').innerHTML=html})}
window.searchPeople=async()=>{if(!need())return;let term=$('peopleSearch').value.trim().toLowerCase();let s=await getDocs(query(collection(db,'users'),limit(60)));let el=$('people');el.innerHTML='';s.forEach(d=>{let u=d.data();if(u.uid!==current.uid&&(!term||(u.name||'').toLowerCase().includes(term)||(u.email||'').toLowerCase().includes(term))){let div=document.createElement('div');div.className='item';div.innerHTML=`<div class="avatar">${esc((u.name||'U')[0])}</div><div class="grow"><b>${esc(u.name||'User')}</b><div class="muted">${esc(u.email||'')}</div></div><button class="secondary" data-add="${u.uid}">Add friend</button>`;el.append(div)}})};
$('people').addEventListener('click',async e=>{let b=e.target.closest('[data-add]');if(!b)return;try{await addDoc(collection(db,'friendRequests'),{from:current.uid,to:b.dataset.add,status:'pending',createdAt:serverTimestamp()});toast('Friend request sent.')}catch(x){toast(x.message)}});
async function loadNotifications(){let el=$('notificationList');el.innerHTML='';let q=query(collection(db,'friendRequests'),where('to','==',current.uid),where('status','==','pending'),limit(30));let s=await getDocs(q);s.forEach(d=>{let x=d.data(),v=document.createElement('div');v.className='item';v.textContent='New friend request';let b=document.createElement('button');b.className='primary';b.textContent='Accept';b.onclick=async()=>{await updateDoc(doc(db,'friendRequests',d.id),{status:'accepted'});await updateDoc(doc(db,'users',current.uid),{friends:arrayUnion(x.from)});await updateDoc(doc(db,'users',x.from),{friends:arrayUnion(current.uid)});v.remove()};v.append(b);el.append(v)})}
window.openChat=async()=>{if(!need())return;let email=$('chatEmail').value.trim();let s=await getDocs(query(collection(db,'users'),where('email','==',email),limit(1)));if(s.empty)return toast('No account found with that email.');chatPeer=s.docs[0].data();$('chatTitle').textContent='Chat with '+chatPeer.name;if(chatUnsub)chatUnsub();let ids=[current.uid,chatPeer.uid].sort(),chatId=ids.join('_');chatUnsub=onSnapshot(query(collection(db,'chats',chatId,'messages'),orderBy('createdAt','asc'),limit(100)),snap=>{let l=$('chatLog');l.innerHTML='';snap.forEach(d=>{let m=d.data(),b=document.createElement('div');b.className='bubble '+(m.uid===current.uid?'mine':'');b.textContent=m.text;l.append(b)});l.scrollTop=l.scrollHeight});$('chatLog').dataset.chatid=chatId};
window.sendMessage=async()=>{if(!need())return;let id=$('chatLog').dataset.chatid,text=$('chatInput').value.trim();if(!id||!text)return toast('Open a chat first.');await addDoc(collection(db,'chats',id,'messages'),{uid:current.uid,text,createdAt:serverTimestamp()});$('chatInput').value=''};
window.createGroup=async()=>{if(!need())return;let name=$('groupName').value.trim();if(!name)return toast('Enter a group name.');await addDoc(collection(db,'groups'),{name,owner:current.uid,members:[current.uid],createdAt:serverTimestamp()});$('groupName').value='';loadGroups()};
async function loadGroups(){let s=await getDocs(query(collection(db,'groups'),limit(50)));$('groupList').innerHTML='';s.forEach(d=>{let g=d.data(),x=document.createElement('div');x.className='item';x.textContent=g.name+' · '+g.members.length+' members';$('groupList').append(x)})}
window.publishReel=async()=>{if(!need())return;try{let f=$('reelFile').files[0];if(!f||!f.type.startsWith('video/'))throw Error('Choose a video file.');let url=await upload(f,'reels');await addDoc(collection(db,'reels'),{uid:current.uid,caption:$('reelCaption').value,videoUrl:url,createdAt:serverTimestamp()});toast('Reel uploaded.');loadReels()}catch(e){toast(e.message)}};
async function loadReels(){if(!db)return;let s=await getDocs(query(collection(db,'reels'),orderBy('createdAt','desc'),limit(30)));$('reelList').innerHTML='';s.forEach(d=>{let x=d.data(),v=document.createElement('video');v.src=x.videoUrl;v.controls=true;v.className='postimg';$('reelList').append(v)})}
window.publishListing=async()=>{if(!need())return;let title=$('marketTitle').value.trim();if(!title)return toast('Enter item title.');await addDoc(collection(db,'marketplace'),{uid:current.uid,title,price:$('marketPrice').value,description:$('marketDesc').value,createdAt:serverTimestamp()});toast('Listing published.');loadMarket()};
async function loadMarket(){let s=await getDocs(query(collection(db,'marketplace'),orderBy('createdAt','desc'),limit(50)));$('marketList').innerHTML='';s.forEach(d=>{let x=d.data(),v=document.createElement('div');v.className='item';v.textContent=x.title+' · '+x.price+' '+x.description;$('marketList').append(v)})}
window.saveProfile=async()=>{if(!need())return;try{let name=$('profileName').value.trim();let f=$('profilePhoto').files[0];let photoUrl=f?await upload(f,'avatars'):null;await updateProfile(current,{displayName:name});let changes={name,bio:$('profileBio').value};if(photoUrl)changes.photoUrl=photoUrl;await updateDoc(doc(db,'users',current.uid),changes);if(photoUrl){$('myAvatar').style.backgroundImage=`url("${photoUrl}")`;$('myAvatar').style.backgroundSize='cover';$('myAvatar').textContent='';}toast('Profile saved.')}catch(e){toast(e.message)}};
window.resendVerification=async()=>{if(!current)return toast('Log in first.');try{await sendEmailVerification(current);toast('Verification email sent again.')}catch(e){toast(e.message)}};
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function time(t){if(!t)return 'Just now';let d=t.toDate?t.toDate():new Date(t);return d.toLocaleString()}
