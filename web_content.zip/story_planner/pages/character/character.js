'use strict';

// ============================================================
// CHARACTER / STORY CONTEXT (resolved from ?id= in the URL)
// ============================================================
const STORIES_KEY = 'stories';

function loadAllStories() {
    try {
        const raw = JSON.parse(localStorage.getItem(STORIES_KEY));
        return Array.isArray(raw) ? raw : [];
    } catch (e) {
        console.error('Failed to read stories:', e);
        return [];
    }
}

function resolveCharacterContext() {
    const params = new URLSearchParams(window.location.search);
    const requestedId = params.get('id');
    const stories = loadAllStories();
    const activeStoryId = localStorage.getItem('activeStoryId');

    let story = stories.find(s => String(s.id) === String(activeStoryId)) || null;
    let character = requestedId
        ? (story?.characters || []).find(c => String(c.id) === String(requestedId)) || null
        : null;

    // Fall back to scanning every story if the character wasn't in the active one
    if (requestedId && !character) {
        for (const s of stories) {
            const found = (s.characters || []).find(c => String(c.id) === String(requestedId));
            if (found) {
                story = s;
                character = found;
                break;
            }
        }
    }

    return { story, character };
}

const { story: currentStoryObj, character: currentCharacter } = resolveCharacterContext();

// ============================================================
// CONSTANTS & STATE
// ============================================================
// Connections/lore/traits are stored per-character so different characters
// don't share the same family/friends/rivals/lore data.
const STORAGE_KEY = currentCharacter
    ? `storyplanner_character_connections_${currentCharacter.id}`
    : 'storyplanner_character_connections';
const LORE_STORAGE_KEY = STORIES_KEY;

const DEFAULT_DATA = {
    family: [],
    friends: [],
    companions: [],
    rivals: [],
    factions: [],
    lore: []
};

let currentAddCategory = 'family';
let currentActiveCategory = 'family';
let currentDetailId = null;
let loreConnectMode = false;

// ============================================================
// LOCAL STORAGE HELPERS
// ============================================================
function getStoredData() {
    const raw = localStorage.getItem(STORAGE_KEY);

    if (!raw) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_DATA));
        return DEFAULT_DATA;
    }

    try {
        const data = JSON.parse(raw);

        // Migrate old single-trait items to the traits array format
        Object.keys(data).forEach(cat => {
            if (!Array.isArray(data[cat])) return;

            data[cat].forEach(item => {
                if (item.traits) return;

                item.traits = [];
                if (item.traitValue || item.traitCategory) {
                    item.traits.push({
                        id: 'trait-' + Date.now() + Math.random().toString(36).substring(2, 5),
                        category: item.traitCategory || 'Trait',
                        value: item.traitValue || ''
                    });
                }
            });
        });

        return data;
    } catch (e) {
        console.error('Failed to parse localStorage data:', e);
        return DEFAULT_DATA;
    }
}

function saveStoredData(data) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    renderAllCategories();
    renderOverviewCounts();
}

// ============================================================
// CATEGORY RENDERING (Family / Friends / Companions / Rivals / Factions)
// ============================================================
function renderCategory(category) {
    if (category === 'lore') {
        renderConnectedLore();
        return;
    }

    const data = getStoredData();
    const items = data[category] || [];
    const grid = document.getElementById(`grid-${category}`);
    if (!grid) return;

    if (items.length === 0) {
        grid.innerHTML = `<div class="empty-state">No ${category} added yet.</div>`;
        return;
    }

    grid.innerHTML = '';

    items.forEach(item => {
        const card = document.createElement('div');
        card.className = 'clickable-card';
        card.onclick = () => viewDetails(item.id, category);

        let traitInfoHtml = '';
        if (item.traits && item.traits.length > 0) {
            const firstTrait = item.traits[0];
            const catLabel = firstTrait.category ? `${escapeHtml(firstTrait.category)}: ` : '';
            const valLabel = firstTrait.value ? escapeHtml(firstTrait.value) : '';
            const moreLabel = item.traits.length > 1
                ? `<span style="opacity:0.6; font-size:11px;">(+${item.traits.length - 1} more)</span>`
                : '';

            traitInfoHtml = `
                <div style="font-size:13px; color:var(--accent-purple); margin-top:4px; font-weight:500;">
                    ${catLabel}${valLabel} ${moreLabel}
                </div>
            `;
        }

        card.innerHTML = `
            <div>
                <div class="item-card-tag">${escapeHtml(item.tag)}</div>
                <div class="item-card-title">${escapeHtml(item.name)}</div>
                ${traitInfoHtml}
                <div class="item-card-desc" style="margin-top:6px;">
                    ${escapeHtml(item.desc || 'No description provided.')}
                </div>
            </div>
            <div class="card-action-text">Click to view details →</div>
        `;

        grid.appendChild(card);
    });
}

function renderAllCategories() {
    const categories = ['family', 'friends', 'companions', 'rivals', 'factions', 'lore'];
    categories.forEach(cat => renderCategory(cat));
}

function renderOverviewCounts() {
    const data = getStoredData();
    const categories = ['family', 'friends', 'companions', 'rivals', 'factions'];

    categories.forEach(cat => {
        const counter = document.getElementById(`count-${cat}`);
        if (counter) counter.textContent = (data[cat] || []).length;
    });
}

// ============================================================
// LORE HELPERS
// ============================================================
function getAllLore() {
    if (!currentStoryObj) return [];

    // Re-read from storage in case lore was added/edited elsewhere since page load.
    const stories = loadAllStories();
    const story = stories.find(s => String(s.id) === String(currentStoryObj.id));
    return story && Array.isArray(story.lore) ? story.lore : [];
}

function getLoreId(lore) {
    return String(lore.id ?? lore._id ?? lore.storyId ?? '');
}

function getLoreTitle(lore) {
    return lore.title ?? lore.name ?? 'Untitled Lore';
}

function getLoreDescription(lore) {
    return lore.description ?? lore.desc ?? lore.content ?? lore.text ?? 'No description provided.';
}

function getConnectedLoreIds() {
    const data = getStoredData();
    if (!Array.isArray(data.lore)) return [];
    return data.lore.map(id => String(id));
}

function buildLoreCard(lore, { showConnect }) {
    const loreId = getLoreId(lore);
    const title = getLoreTitle(lore);
    const description = getLoreDescription(lore);

    const actionButton = showConnect
        ? `
            <button type="button" class="lore-add-btn" onclick="event.stopPropagation(); connectLore('${escapeHtml(loreId)}')" title="Connect Lore" aria-label="Connect Lore">
                <span class="desktop-button-text">Connect</span>
                <span class="mobile-button-icon">+</span>
            </button>
        `
        : `
            <button type="button" class="lore-remove-btn" onclick="event.stopPropagation(); disconnectLore('${escapeHtml(loreId)}')" title="Disconnect Lore" aria-label="Disconnect Lore">
                <span class="desktop-button-text">Disconnect</span>
                <span class="mobile-button-icon">×</span>
            </button>
        `;

    const card = document.createElement('div');
    card.className = 'clickable-card lore-card';
    card.innerHTML = `
        <div>
            <div class="item-card-tag">LORE</div>
            <div class="item-card-title">${escapeHtml(title)}</div>
            <div class="item-card-desc" style="margin-top:6px;">${escapeHtml(description)}</div>
        </div>
        <div class="lore-card-actions">
            <button type="button" class="lore-view-btn" onclick="event.stopPropagation(); viewExistingLore('${escapeHtml(loreId)}')" title="View Lore" aria-label="View Lore">
                <span class="desktop-button-text">View</span>
                <span class="mobile-button-icon">👁</span>
            </button>
            ${actionButton}
        </div>
    `;

    return card;
}

function renderConnectedLore() {
    const grid = document.getElementById('grid-lore');
    if (!grid) return;

    grid.innerHTML = '';

    const allLore = getAllLore();
    const connectedIds = getConnectedLoreIds();

    if (allLore.length === 0) {
        grid.innerHTML = `<div class="empty-state">No lore exists yet.</div>`;
        return;
    }

    // ---------------- CONNECTION MODE ----------------
    if (loreConnectMode) {
        const availableLore = allLore.filter(lore => !connectedIds.includes(getLoreId(lore)));

        if (availableLore.length === 0) {
            grid.innerHTML = `
                <div class="empty-state">
                    All existing lore is already connected.
                    <br><br>
                    Click <strong>Done</strong> to return.
                </div>
            `;
            return;
        }

        const searchInput = document.getElementById('search-lore');
        const query = searchInput ? searchInput.value.trim().toLowerCase() : '';

        const filteredLore = availableLore.filter(lore => {
            const title = getLoreTitle(lore).toLowerCase();
            const description = getLoreDescription(lore).toLowerCase();
            return title.includes(query) || description.includes(query);
        });

        if (filteredLore.length === 0) {
            grid.innerHTML = `<div class="empty-state">No lore matches your search.</div>`;
            return;
        }

        filteredLore.forEach(lore => grid.appendChild(buildLoreCard(lore, { showConnect: true })));
        return;
    }

    // ---------------- NORMAL MODE ----------------
    const connectedLore = allLore.filter(lore => connectedIds.includes(getLoreId(lore)));

    if (connectedLore.length === 0) {
        grid.innerHTML = `
            <div class="empty-state">
                No lore connected yet.
                <br><br>
                Click <strong>+ Connect Lore</strong> to connect an existing lore entry.
            </div>
        `;
        return;
    }

    connectedLore.forEach(lore => grid.appendChild(buildLoreCard(lore, { showConnect: false })));
}

function connectLore(loreId) {
    // No id passed -> toggle connect-mode (triggered by the "+ Connect Lore" button)
    if (loreId === undefined || loreId === null || loreId === '') {
        const allLore = getAllLore();

        if (allLore.length === 0) {
            showLoreNotification('No lore available. Create a lore entry first.');
            return;
        }

        loreConnectMode = !loreConnectMode;

        const buttonText = document.getElementById('connectLoreButtonText');
        if (buttonText) {
            buttonText.textContent = loreConnectMode ? 'Done' : '+ Connect Lore';
        }

        renderConnectedLore();
        return;
    }

    // Connect a specific lore entry
    loreId = String(loreId);

    const allLore = getAllLore();
    const loreExists = allLore.some(lore => getLoreId(lore) === loreId);

    if (!loreExists) {
        showLoreNotification('This lore entry no longer exists.');
        return;
    }

    const data = getStoredData();
    if (!Array.isArray(data.lore)) data.lore = [];
    data.lore = data.lore.map(id => String(id));

    if (data.lore.includes(loreId)) {
        showLoreNotification('This lore is already connected.');
        return;
    }

    data.lore.push(loreId);
    saveStoredData(data);
    showLoreNotification('Lore connected successfully.');

    // Stay in connection mode so the user can connect multiple entries
    renderConnectedLore();
}

function disconnectLore(loreId) {
    const data = getStoredData();
    if (!Array.isArray(data.lore)) return;

    loreId = String(loreId);
    data.lore = data.lore.filter(id => String(id) !== loreId);

    saveStoredData(data);
    showLoreNotification('Lore disconnected.');
    renderConnectedLore();
}

function viewExistingLore(loreId) {
    const allLore = getAllLore();
    const lore = allLore.find(item => getLoreId(item) === String(loreId));

    if (!lore) {
        showLoreNotification('This lore entry no longer exists.');
        return;
    }

    // If the lore object already contains a URL or page, navigate to it
    if (lore.url) {
        window.location.href = lore.url;
        return;
    }

    if (lore.page) {
        window.location.href = lore.page;
        return;
    }

    // TODO: replace with a real lore detail page, e.g.
    // window.location.href = `../lore/lore.html?id=${encodeURIComponent(loreId)}`;
    console.log('Lore selected:', lore);
}

function showLoreNotification(message) {
    const existing = document.getElementById('loreNotification');
    if (existing) existing.remove();

    const notification = document.createElement('div');
    notification.id = 'loreNotification';
    notification.className = 'lore-notification';
    notification.innerHTML = `<span>${escapeHtml(message)}</span>`;

    document.body.appendChild(notification);

    setTimeout(() => notification.classList.add('show'), 10);

    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// ============================================================
// SIDEBAR / TRAITS (detail view attributes)
// ============================================================
function renderSidebar() {
    if (!currentDetailId) return;

    const data = getStoredData();
    const item = (data[currentActiveCategory] || []).find(i => i.id === currentDetailId);
    if (!item) return;

    const container = document.getElementById('detailTraits');
    if (!container) return;

    const traits = item.traits || [];

    if (traits.length === 0) {
        container.innerHTML = `<div class="empty-state">No character attributes added yet.</div>`;
        return;
    }

    container.innerHTML = traits.map(group => `
        <div class="detail-trait">
            <div class="detail-trait-header">
                <div class="detail-trait-category">${escapeHtml(group.category)}</div>
                <button type="button" class="btn-delete-trait" onclick="deleteTraitCategory('${group.id}')" title="Delete Category">×</button>
            </div>
            <div class="detail-trait-values">
                ${(group.values || []).map(value => `
                    <div class="detail-trait-value-row">
                        <div class="detail-trait-value">${escapeHtml(value.value || 'N/A')}</div>
                        <button type="button" class="btn-delete-trait-value" onclick="deleteTraitValue('${group.id}', '${value.id}')" title="Delete Value">×</button>
                    </div>
                `).join('')}
            </div>
        </div>
    `).join('');
}

function openTraitModal() {
    if (!currentDetailId) return;

    const modal = document.getElementById('traitModal');
    if (!modal) return;

    document.getElementById('sidebarNewTraitCat').value = '';
    document.getElementById('sidebarNewTraitVal').value = '';

    modal.classList.add('active');
    setTimeout(() => document.getElementById('sidebarNewTraitCat').focus(), 100);
}

function closeTraitModal() {
    const modal = document.getElementById('traitModal');
    if (modal) modal.classList.remove('active');
}

function addTraitFromSidebar() {
    const catInput = document.getElementById('sidebarNewTraitCat');
    const valInput = document.getElementById('sidebarNewTraitVal');

    const category = catInput.value.trim();
    const value = valInput.value.trim();
    if (!category || !value) return;

    const data = getStoredData();
    const items = data[currentActiveCategory] || [];
    const itemIndex = items.findIndex(i => i.id === currentDetailId);
    if (itemIndex === -1) return;

    if (!items[itemIndex].traits) items[itemIndex].traits = [];
    const traits = items[itemIndex].traits;

    const existingCategory = traits.find(
        trait => trait.category.toLowerCase() === category.toLowerCase()
    );

    const newValue = {
        id: 'value-' + Date.now() + Math.random().toString(36).substring(2, 7),
        value
    };

    if (existingCategory) {
        existingCategory.values.push(newValue);
    } else {
        traits.push({
            id: 'trait-' + Date.now() + Math.random().toString(36).substring(2, 7),
            category,
            values: [newValue]
        });
    }

    saveStoredData(data);
    renderSidebar();
    closeTraitModal();
}

function deleteTraitCategory(categoryId) {
    const data = getStoredData();
    const items = data[currentActiveCategory] || [];
    const itemIndex = items.findIndex(i => i.id === currentDetailId);
    if (itemIndex === -1 || !items[itemIndex].traits) return;

    items[itemIndex].traits = items[itemIndex].traits.filter(trait => trait.id !== categoryId);

    saveStoredData(data);
    renderSidebar();
}

function deleteTraitValue(categoryId, valueId) {
    const data = getStoredData();
    const items = data[currentActiveCategory] || [];
    const itemIndex = items.findIndex(i => i.id === currentDetailId);
    if (itemIndex === -1) return;

    const traits = items[itemIndex].traits || [];
    const category = traits.find(trait => trait.id === categoryId);
    if (!category) return;

    category.values = category.values.filter(value => value.id !== valueId);

    // Auto-remove the category once it has no values left
    if (category.values.length === 0) {
        items[itemIndex].traits = traits.filter(trait => trait.id !== categoryId);
    }

    saveStoredData(data);
    renderSidebar();
}

// ============================================================
// NAVIGATION / TABS
// ============================================================
function switchTab(tabName, element) {
    currentActiveCategory = tabName;
    currentDetailId = null; // exit detail view state

    document.querySelectorAll('.view-section').forEach(sec => sec.classList.remove('active'));
    document.querySelectorAll('.nav-item').forEach(item => item.classList.remove('active'));

    const target = document.getElementById(`view-${tabName}`);
    if (target) target.classList.add('active');

    if (element) {
        element.classList.add('active');
    } else {
        document.querySelectorAll('.nav-item').forEach(nav => {
            const onclick = nav.getAttribute('onclick');
            if (onclick && onclick.includes(`'${tabName}'`)) {
                nav.classList.add('active');
            }
        });
    }

    renderSidebar();
}

// ============================================================
// ADD / EDIT / DELETE ENTRIES
// ============================================================
function openAddForm(category, labelTitle, tagPlaceholder) {
    currentAddCategory = category;

    document.getElementById('formCategoryLabel').textContent = category.toUpperCase();
    document.getElementById('formTitleHeader').textContent = `Add ${labelTitle}`;
    document.getElementById('connTagLabel').textContent = `Relationship / Tag (${labelTitle})`;
    document.getElementById('connTag').placeholder = tagPlaceholder;

    document.getElementById('connectionForm').reset();

    document.querySelectorAll('.view-section').forEach(sec => sec.classList.remove('active'));
    document.getElementById('view-add-form').classList.add('active');

    renderSidebar();
}

function saveConnectionForm(event) {
    event.preventDefault();

    const name = document.getElementById('connName').value.trim();
    const tag = document.getElementById('connTag').value.trim();
    const traitValue = document.getElementById('connTraitValue').value.trim();
    const traitCategory = document.getElementById('connTraitCategory').value.trim();
    const desc = document.getElementById('connDesc').value.trim() || 'No description provided.';

    if (!name || !tag) return;

    const initialTraits = [];
    if (traitValue && traitCategory) {
        initialTraits.push({
            id: 'trait-' + Date.now() + Math.random().toString(36).substring(2, 7),
            category: traitCategory,
            values: [{
                id: 'value-' + Date.now() + Math.random().toString(36).substring(2, 7),
                value: traitValue
            }]
        });
    }

    const data = getStoredData();
    if (!data[currentAddCategory]) data[currentAddCategory] = [];

    const newItem = {
        id: `${currentAddCategory}-${Date.now()}`,
        name,
        tag,
        desc,
        traits: initialTraits
    };

    data[currentAddCategory].push(newItem);
    saveStoredData(data);

    viewDetails(newItem.id, currentAddCategory);
}

function cancelAddForm() {
    switchTab(currentAddCategory);
}

function viewDetails(id, category) {
    currentActiveCategory = category;
    currentDetailId = id;

    const data = getStoredData();
    const item = (data[category] || []).find(i => i.id === id);
    if (!item) return;

    document.getElementById('detailCategoryLabel').textContent = category.toUpperCase();
    document.getElementById('detailNameTitle').textContent = item.name;
    document.getElementById('detailTagSubtitle').textContent = item.tag;
    document.getElementById('detailDescDisplay').textContent = item.desc || 'No description provided.';

    document.querySelectorAll('.view-section').forEach(sec => sec.classList.remove('active'));
    document.getElementById('view-detail').classList.add('active');

    renderSidebar();
}

function backToCategory() {
    switchTab(currentActiveCategory);
}

function deleteCurrentDetail() {
    if (!currentDetailId || !currentActiveCategory) return;

    if (confirm('Are you sure you want to delete this entry?')) {
        const data = getStoredData();
        data[currentActiveCategory] = (data[currentActiveCategory] || []).filter(i => i.id !== currentDetailId);
        saveStoredData(data);
        switchTab(currentActiveCategory);
    }
}

// ============================================================
// SEARCH
// ============================================================
function filterItems(category) {
    const query = document.getElementById(`search-${category}`).value.toLowerCase();
    const cards = document.querySelectorAll(`#grid-${category} .clickable-card`);

    cards.forEach(card => {
        const cardText = card.textContent.toLowerCase();
        card.style.display = cardText.includes(query) ? 'flex' : 'none';
    });
}

// ============================================================
// MOBILE SIDEBAR
// ============================================================
function toggleMobileSidebar() {
    const sidebar = document.querySelector('.left-sidebar');
    const overlay = document.querySelector('.mobile-sidebar-overlay');
    if (!sidebar || !overlay) return;

    if (sidebar.classList.contains('mobile-open')) {
        closeMobileSidebar();
    } else {
        sidebar.classList.add('mobile-open');
        overlay.classList.add('active');
        document.body.classList.add('sidebar-open');
    }
}

function closeMobileSidebar() {
    const sidebar = document.querySelector('.left-sidebar');
    const overlay = document.querySelector('.mobile-sidebar-overlay');
    if (!sidebar || !overlay) return;

    sidebar.classList.remove('mobile-open');
    overlay.classList.remove('active');
    document.body.classList.remove('sidebar-open');
}

// ============================================================
// UTILITIES
// ============================================================
function escapeHtml(str) {
    return String(str ?? '').replace(/[&<>"']/g, m => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    }[m]));
}

// ============================================================
// HEADER / IDENTITY BINDING
// ============================================================
function populateCharacterHeader() {
    const storyTitleEl = document.getElementById('storyTitleHeader');
    if (storyTitleEl) storyTitleEl.textContent = currentStoryObj?.name || 'Story';

    if (!currentCharacter) {
        setText('charNameHeading', 'Character Not Found');
        setText('charSubtitle', 'We couldn\u2019t find this character. Go back to My Stories and open them from the Characters tab.');
        setText('infoRole', '\u2014');
        setText('infoWorld', currentStoryObj?.name || '\u2014');
        setText('infoGoal', '\u2014');
        setText('infoArchetype', '\u2014');
        setText('overviewBioText', 'No character selected.');
        setText('bioFullText', 'No character selected.');
        return;
    }

    document.title = `${currentCharacter.name || 'Character'} - StoryPlanner`;

    setText('charNameHeading', currentCharacter.name || 'Unnamed Character');
    setText('charSubtitle', currentCharacter.description || currentCharacter.goal || 'No description provided yet.');
    setText('infoRole', currentCharacter.role || 'Not set');
    setText('infoWorld', currentStoryObj?.name || 'Not set');
    setText('infoGoal', currentCharacter.goal || 'Not set');
    setText('infoArchetype', currentCharacter.archetype || 'Not set');
    setText('overviewBioText', currentCharacter.description || 'No detailed background provided yet.');
    setText('bioFullText', currentCharacter.description || 'No detailed background provided yet.');
    setText('formSubtitleText', `Fill in the details below to save to ${currentCharacter.name || 'this character'}'s dossier.`);
    setText('loreSectionSubtitle', `Lore entries connected to ${currentCharacter.name || 'this character'}.`);
}

function setText(elementId, value) {
    const el = document.getElementById(elementId);
    if (el) el.textContent = value;
}

// ============================================================
// INIT
// ============================================================
document.addEventListener('DOMContentLoaded', () => {
    populateCharacterHeader();
    renderAllCategories();
    renderOverviewCounts();
    renderSidebar();
    closeMobileSidebar();
});
