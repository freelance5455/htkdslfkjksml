import { storyService } from '../../features/workspace/story/storyService.js';

document.addEventListener('DOMContentLoaded', () => {
    const params = new URLSearchParams(window.location.search);
    const characterId = params.get('id');

    if (!characterId) {
        showError('No Character Specified');
        return;
    }

    const stories = storyService.getStories();
    const currentStory = storyService.getCurrentStory();

    let character = currentStory?.characters?.find(c => String(c.id) === String(characterId));

    // Fallback across all stories
    if (!character && Array.isArray(stories)) {
        for (const story of stories) {
            if (story.characters) {
                const found = story.characters.find(c => String(c.id) === String(characterId));
                if (found) {
                    character = found;
                    break;
                }
            }
        }
    }

    if (!character) {
        showError('Character Not Found');
        return;
    }

    populateDossier(character, currentStory);
});

function populateDossier(char, currentStory) {
    document.title = `${char.name || 'Character'} - Profile`;

    // Header Info
    setText('charAvatar', char.name ? char.name.charAt(0).toUpperCase() : '?');
    setText('charName', char.name || 'Unnamed Character');

    const roleBadge = document.getElementById('charRoleBadge');
    if (roleBadge) {
        const role = char.role || 'Supporting';
        roleBadge.textContent = role;
        roleBadge.className = `role-badge role-${role.toLowerCase()}`;
    }

    const archetypeEl = document.getElementById('charArchetype');
    if (archetypeEl) {
        archetypeEl.innerHTML = char.archetype 
            ? `Archetype: <strong>${escapeHtml(char.archetype)}</strong>` 
            : 'Archetype Unassigned';
    }

    const quoteBox = document.getElementById('charGoalQuote');
    if (quoteBox) {
        if (char.goal) {
            quoteBox.textContent = `"Primary Goal: ${char.goal}"`;
            quoteBox.style.display = 'block';
        } else {
            quoteBox.style.display = 'none';
        }
    }

    // Sidebar Stats
    setText('statRole', char.role || 'Not set');
    setText('statArchetype', char.archetype || 'None');
    setText('statGoal', char.goal || 'Undefined');
    setText('charBio', char.description || 'No detailed background provided.');

    // Dynamic Tags
    renderTags('charBeliefsList', char.beliefs, 'belief-pill', '⚖️', 'No moral beliefs specified.');
    renderTags('charLoreTags', char.lore, 'lore-pill', '📜', 'No worldbuilding connections.');
    renderTags('charArcTags', char.arcs, 'arc-pill', '⚡', 'No story arcs assigned.');
    renderTags('charItemsList', char.possessions || char.items, 'item-pill', '🗡️', 'No items listed.');

    // Categorized Connections
    renderCategorizedRelationships(char.relationships, currentStory, char.id);
}

function renderCategorizedRelationships(relText, currentStory, currentCharId) {
    const container = document.getElementById('connectionsWrapper');
    if (!container) return;

    if (!relText) {
        container.innerHTML = '<span class="empty-tag-text">No recorded family, friends, or companions.</span>';
        return;
    }

    // Categorization Buckets
    const categories = {
        Family: { title: '👨‍👩‍👧 Family Members', class: 'cat-family', icon: '👨‍👩‍👧', items: [] },
        Friends: { title: '🤝 Friends & Allies', class: 'cat-friends', icon: '🤝', items: [] },
        Companions: { title: '🛡️ Companions & Party', class: 'cat-companions', icon: '🛡️', items: [] },
        Rivals: { title: '⚔️ Rivals & Enemies', class: 'cat-rivals', icon: '⚔️', items: [] },
        Other: { title: '📜 Other Connections', class: 'cat-lore', icon: '🔗', items: [] }
    };

    const entries = relText.split(',');

    entries.forEach(entry => {
        const item = entry.trim();
        if (!item) return;

        // Determine Category
        let catKey = 'Other';
        if (/family|father|mother|brother|sister|son|daughter|parent|cousin|uncle|aunt|wife|husband/i.test(item)) {
            catKey = 'Family';
        } else if (/friend|ally|partner/i.test(item)) {
            catKey = 'Friends';
        } else if (/companion|party|guild|guard/i.test(item)) {
            catKey = 'Companions';
        } else if (/rival|enemy|foe|nemesis|villain/i.test(item)) {
            catKey = 'Rivals';
        }

        // Match against existing character profiles
        const matchedChar = currentStory?.characters?.find(c => 
            String(c.id) !== String(currentCharId) && 
            c.name.trim() !== '' && 
            item.toLowerCase().includes(c.name.toLowerCase())
        );

        categories[catKey].items.push({ text: item, matchedChar });
    });

    // Render non-empty categories
    let html = '';
    Object.values(categories).forEach(cat => {
        if (cat.items.length === 0) return;

        const cardsHtml = cat.items.map(itemObj => {
            if (itemObj.matchedChar) {
                return `
                    <a href="character.html?id=${itemObj.matchedChar.id}" class="connection-card clickable-card">
                        <span class="conn-icon">${cat.icon}</span>
                        <div class="conn-info">
                            <span class="conn-text">${escapeHtml(itemObj.text)}</span>
                            <span class="conn-link">View Profile →</span>
                        </div>
                    </a>`;
            }
            return `
                <div class="connection-card">
                    <span class="conn-icon">${cat.icon}</span>
                    <div class="conn-info">
                        <span class="conn-text">${escapeHtml(itemObj.text)}</span>
                    </div>
                </div>`;
        }).join('');

        html += `
            <div class="conn-category-group">
                <div class="conn-category-title ${cat.class}">${cat.title}</div>
                <div class="connection-grid">${cardsHtml}</div>
            </div>`;
    });

    container.innerHTML = html || '<span class="empty-tag-text">No recorded connections.</span>';
}

function renderTags(elementId, textData, pillClass, icon, emptyMsg) {
    const container = document.getElementById(elementId);
    if (!container) return;

    if (!textData) {
        container.innerHTML = `<span class="empty-tag-text">${emptyMsg}</span>`;
        return;
    }

    container.innerHTML = textData.split(',')
        .map(t => `<div class="${pillClass}">${icon} ${escapeHtml(t.trim())}</div>`)
        .join('');
}

function setText(elementId, value) {
    const el = document.getElementById(elementId);
    if (el) el.textContent = value;
}

function showError(message) {
    const container = document.getElementById('profileContainer');
    if (container) {
        container.innerHTML = `<div class="profile-loading"><h2>${message}</h2></div>`;
    }
}

function escapeHtml(str) {
    return str.replace(/[&<>"']/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[m]));
}