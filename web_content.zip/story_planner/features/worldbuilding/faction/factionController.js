import { factionService } from './factionService.js';
import { factionUi } from './factionUi.js';
import { storyService } from '../../workspace/story/storyService.js';

let currentSearchQuery = '';
let currentSearchMode = 'all';
let activeFactionId = null;

function getCharacters() {
    const story = storyService.getCurrentStory();
    return story ? (story.characters || []) : [];
}
function getLocations() {
    const story = storyService.getCurrentStory();
    return story ? (story.locations || []) : [];
}

export function initFactionFeature() {
    attachEventListeners();
}

// Allows other features (e.g. the Story Map) to jump straight into a faction's detail view.
export function openFactionById(id) {
    handleOpenFaction(id);
}

export function loadFactionsTab() {
    currentSearchQuery = '';
    currentSearchMode = 'all';
    activeFactionId = null;
    const els = factionUi.elements;
    if (els.searchInput) els.searchInput.value = '';
    if (els.searchMode) els.searchMode.value = 'all';

    factionUi.showListView();
    renderList();
}

function renderList() {
    const factions = factionService.searchFactions(currentSearchQuery, currentSearchMode);
    factionUi.renderFactionGrid(factions, getCharacters(), getLocations(), {
        onOpen: handleOpenFaction,
        onEdit: handleEditFaction,
        onDelete: handleDeleteFaction
    });
}

function handleOpenFaction(id) {
    activeFactionId = id;
    const faction = factionService.getFactionById(id);
    if (!faction) return;
    factionUi.showDetailView();
    renderDetail(id);
}

function renderDetail(id) {
    const faction = factionService.getFactionById(id);
    if (!faction) return;

    factionUi.renderFactionDetail(faction, getCharacters(), getLocations(), {
        onBack: () => {
            activeFactionId = null;
            factionUi.showListView();
            renderList();
        },
        onDelete: handleDeleteFaction,
        onEdit: handleEditFaction,
        onManageTags: handleManageTags
    });
}

function handleEditFaction(faction) {
    factionUi.openModal(faction);
}

function handleManageTags(faction) {
    factionUi.openTagModal(getCharacters(), getLocations(), faction.characterIds || [], faction.locationIds || []);

    const els = factionUi.elements;
    const onSave = () => {
        const { characterIds, locationIds } = factionUi.readTagModal();
        factionService.updateFaction(faction.id, { characterIds, locationIds });
        factionUi.closeTagModal();
        renderDetail(faction.id);
        cleanup();
    };
    const onCancel = () => {
        factionUi.closeTagModal();
        cleanup();
    };
    function cleanup() {
        els.tagSaveBtn.removeEventListener('click', onSave);
        els.tagCancelBtn.removeEventListener('click', onCancel);
    }
    els.tagSaveBtn.addEventListener('click', onSave);
    els.tagCancelBtn.addEventListener('click', onCancel);
}

function handleDeleteFaction(id) {
    if (!confirm('Delete this faction? This cannot be undone.')) return;
    factionService.deleteFaction(id);
    activeFactionId = null;
    factionUi.showListView();
    renderList();
}

function handleSaveFaction(e) {
    e.preventDefault();
    const formData = factionUi.getFormData();

    if (!formData.title) {
        alert('Please enter a faction title.');
        return;
    }

    let factionId = formData.id;
    if (formData.id) {
        factionService.updateFaction(formData.id, { title: formData.title, description: formData.description });
    } else {
        const created = factionService.addFaction(formData);
        factionId = created.id;
    }

    factionUi.closeModal();

    if (activeFactionId === factionId) {
        renderDetail(factionId);
    } else {
        renderList();
    }
}

function attachEventListeners() {
    const els = factionUi.elements;

    if (els.addBtn) els.addBtn.addEventListener('click', () => factionUi.openModal());
    if (els.cancelBtn) els.cancelBtn.addEventListener('click', () => factionUi.closeModal());
    if (els.form) els.form.addEventListener('submit', handleSaveFaction);
    if (els.searchInput) {
        els.searchInput.addEventListener('input', (e) => {
            currentSearchQuery = e.target.value;
            renderList();
        });
    }
    if (els.searchMode) {
        els.searchMode.addEventListener('change', (e) => {
            currentSearchMode = e.target.value;
            renderList();
        });
    }
}
