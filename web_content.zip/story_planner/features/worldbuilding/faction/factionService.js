import { storyService } from '../../workspace/story/storyService.js';
import { createId } from '../../shared/id.js';

export const factionService = {
    getFactions() {
        const story = storyService.getCurrentStory();
        return story ? (story.factions || []) : [];
    },

    getFactionById(id) {
        return this.getFactions().find(f => f.id === id) || null;
    },

    addFaction(data) {
        const story = storyService.getCurrentStory();
        if (!story) return null;
        if (!story.factions) story.factions = [];

        const newFaction = {
            id: createId(),
            title: data.title,
            description: data.description || '',
            characterIds: data.characterIds || [],
            locationIds: data.locationIds || [],
            createdAt: Date.now()
        };

        story.factions.push(newFaction);
        storyService.updateStoryDetails({});
        return newFaction;
    },

    updateFaction(id, updatedData) {
        const story = storyService.getCurrentStory();
        if (!story || !story.factions) return false;

        const index = story.factions.findIndex(f => f.id === id);
        if (index === -1) return false;

        story.factions[index] = { ...story.factions[index], ...updatedData };
        storyService.updateStoryDetails({});
        return true;
    },

    deleteFaction(id) {
        const story = storyService.getCurrentStory();
        if (!story || !story.factions) return false;

        story.factions = story.factions.filter(f => f.id !== id);

        // Cascade cleanup: remove this faction from anything that tagged it
        (story.ideas || []).forEach(i => {
            if (i.factionIds) i.factionIds = i.factionIds.filter(fid => fid !== id);
        });

        // Cascade cleanup: unlink this faction from any Story Map boxes that referenced it
        if (story.storyMap && story.storyMap.boxes) {
            story.storyMap.boxes.forEach(box => {
                if (box.links && box.links.factions) {
                    box.links.factions = box.links.factions.filter(fid => fid !== id);
                }
            });
        }

        storyService.updateStoryDetails({});
        return true;
    },

    searchFactions(query, mode = 'all') {
        const factions = this.getFactions();
        const q = (query || '').trim().toLowerCase();
        if (!q) return factions;

        const story = storyService.getCurrentStory();
        const characters = story ? (story.characters || []) : [];
        const locations = story ? (story.locations || []) : [];

        return factions.filter(faction => {
            const titleMatch = faction.title.toLowerCase().includes(q);
            const charMatch = (faction.characterIds || [])
                .map(id => characters.find(c => c.id === id))
                .filter(Boolean)
                .some(c => c.name.toLowerCase().includes(q));
            const locMatch = (faction.locationIds || [])
                .map(id => locations.find(l => l.id === id))
                .filter(Boolean)
                .some(l => l.title.toLowerCase().includes(q));

            if (mode === 'title') return titleMatch;
            if (mode === 'character') return charMatch;
            if (mode === 'location') return locMatch;
            return titleMatch || charMatch || locMatch;
        });
    }
};
