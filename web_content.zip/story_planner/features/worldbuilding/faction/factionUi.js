import { renderTagPicker, readTagPicker, wireTagPickerSearch, renderTagChips } from '../../shared/tagPicker.js';

function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str || '';
    return div.innerHTML;
}

const editIconSvg = `<svg class="icon-inline" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <path d="M13.5 3.5l3 3L7 16H4v-3l9.5-9.5z" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/>
</svg>`;

export const factionUi = {
    get elements() {
        return {
            listView: document.getElementById('factionListView'),
            detailView: document.getElementById('factionDetailView'),
            grid: document.getElementById('factionGrid'),
            searchInput: document.getElementById('factionSearchInput'),
            searchMode: document.getElementById('factionSearchMode'),
            addBtn: document.getElementById('addFactionBtn'),

            modal: document.getElementById('factionModal'),
            form: document.getElementById('factionForm'),
            idInput: document.getElementById('factionId'),
            titleInput: document.getElementById('factionTitleInput'),
            descInput: document.getElementById('factionDescInput'),
            cancelBtn: document.getElementById('cancelFactionModal'),

            tagModal: document.getElementById('factionTagModal'),
            characterTagPicker: document.getElementById('factionCharacterTagPicker'),
            characterTagSearchInput: document.getElementById('factionCharacterTagSearchInput'),
            locationTagPicker: document.getElementById('factionLocationTagPicker'),
            locationTagSearchInput: document.getElementById('factionLocationTagSearchInput'),
            tagSaveBtn: document.getElementById('factionTagSaveBtn'),
            tagCancelBtn: document.getElementById('factionTagCancelBtn')
        };
    },

    showListView() {
        this.elements.listView.style.display = 'block';
        this.elements.detailView.style.display = 'none';
    },

    showDetailView() {
        this.elements.listView.style.display = 'none';
        this.elements.detailView.style.display = 'block';
    },

    renderFactionGrid(factions, characters, locations, handlers) {
        const grid = this.elements.grid;
        if (!grid) return;
        grid.innerHTML = '';

        if (!factions || factions.length === 0) {
            grid.innerHTML = `<div class="empty-inline">No factions yet. Click "+ Add Faction" to track a group in your world.</div>`;
            return;
        }

        factions.forEach(faction => {
            const taggedChars = (faction.characterIds || []).map(id => characters.find(c => c.id === id)).filter(Boolean);
            const taggedLocs = (faction.locationIds || []).map(id => locations.find(l => l.id === id)).filter(Boolean);

            const card = document.createElement('div');
            card.className = 'entity-card';
            card.innerHTML = `
                <h3 class="entity-title">${escapeHtml(faction.title)}</h3>
                <p class="entity-desc">${escapeHtml(faction.description) || 'No description yet.'}</p>
                <div class="entity-tags">
                    ${taggedChars.map(c => `<span class="tag-pill">${escapeHtml(c.name)}</span>`).join('')}
                    ${taggedLocs.map(l => `<span class="tag-pill tag-pill-location">${escapeHtml(l.title)}</span>`).join('')}
                    ${(taggedChars.length === 0 && taggedLocs.length === 0) ? `<span class="tag-chip-empty">Nothing tagged yet</span>` : ''}
                </div>
                <div class="entity-actions">
                    <button class="btn-icon open-btn">Open</button>
                    <button class="btn-icon edit-btn">Edit</button>
                    <button class="btn-icon delete delete-btn">Delete</button>
                </div>
            `;
            card.querySelector('.open-btn').addEventListener('click', () => handlers.onOpen(faction.id));
            card.querySelector('.edit-btn').addEventListener('click', () => handlers.onEdit(faction));
            card.querySelector('.delete-btn').addEventListener('click', () => handlers.onDelete(faction.id));
            grid.appendChild(card);
        });
    },

    renderFactionDetail(faction, characters, locations, handlers) {
        const view = this.elements.detailView;
        if (!view) return;

        const taggedChars = (faction.characterIds || []).map(id => characters.find(c => c.id === id)).filter(Boolean);
        const taggedLocs = (faction.locationIds || []).map(id => locations.find(l => l.id === id)).filter(Boolean);

        view.innerHTML = `
            <div class="detail-back" id="factionBackBtn">← Back to Factions</div>
            <div class="detail-title-row">
                <h1 class="entity-title-lg">${escapeHtml(faction.title)}</h1>
                <div class="detail-block-header-actions">
                    <button class="btn-icon content-edit-btn" id="factionEditBtn">${editIconSvg} Edit Title</button>
                    <button class="btn-icon delete" id="factionDeleteBtn">Delete Faction</button>
                </div>
            </div>
            <p class="detail-description">${faction.description ? escapeHtml(faction.description) : 'No description yet.'}</p>

            <div class="detail-block">
                <div class="detail-block-header">
                    <h3>Tags</h3>
                    <button class="btn-icon" id="factionManageTagsBtn">Manage Tags</button>
                </div>

                <div class="tag-section">
                    <span class="tag-section-label">Characters</span>
                    <div class="entity-tags" id="factionCharacterTagChips"></div>
                </div>
                <div class="tag-section">
                    <span class="tag-section-label">Locations</span>
                    <div class="entity-tags" id="factionLocationTagChips"></div>
                </div>
            </div>
        `;

        view.querySelector('#factionBackBtn').addEventListener('click', handlers.onBack);
        view.querySelector('#factionEditBtn').addEventListener('click', () => handlers.onEdit(faction));
        view.querySelector('#factionDeleteBtn').addEventListener('click', () => handlers.onDelete(faction.id));
        view.querySelector('#factionManageTagsBtn').addEventListener('click', () => handlers.onManageTags(faction));

        renderTagChips(view.querySelector('#factionCharacterTagChips'), taggedChars.map(c => ({ id: c.id, label: c.name })), 'No characters tagged yet.');
        renderTagChips(view.querySelector('#factionLocationTagChips'), taggedLocs.map(l => ({ id: l.id, label: l.title })), 'No locations tagged yet.');
    },

    getFormData() {
        const els = this.elements;
        return {
            id: els.idInput?.value ? Number(els.idInput.value) : null,
            title: els.titleInput?.value.trim() || '',
            description: els.descInput?.value.trim() || ''
        };
    },

    openModal(faction = null) {
        const els = this.elements;
        this.clearForm();

        document.getElementById('factionModalTitle').textContent = faction ? 'Edit Faction' : 'Add Faction';

        if (faction) {
            els.idInput.value = faction.id;
            els.titleInput.value = faction.title || '';
            els.descInput.value = faction.description || '';
        }

        els.modal.style.display = 'flex';
        els.titleInput?.focus();
    },

    closeModal() {
        this.elements.modal.style.display = 'none';
        this.clearForm();
    },

    clearForm() {
        const els = this.elements;
        if (els.idInput) els.idInput.value = '';
        if (els.titleInput) els.titleInput.value = '';
        if (els.descInput) els.descInput.value = '';
    },

    // --- Manage-tags modal (searchable, toggle-based) ---
    openTagModal(characters, locations, selectedCharacterIds, selectedLocationIds) {
        const els = this.elements;

        const charItems = characters.map(c => ({ id: c.id, label: c.name, sublabel: c.role }));
        renderTagPicker(els.characterTagPicker, charItems, selectedCharacterIds, 'No characters created yet.');
        wireTagPickerSearch(els.characterTagPicker, els.characterTagSearchInput, charItems, 'No characters created yet.');

        const locItems = locations.map(l => ({ id: l.id, label: l.title }));
        renderTagPicker(els.locationTagPicker, locItems, selectedLocationIds, 'No locations created yet.');
        wireTagPickerSearch(els.locationTagPicker, els.locationTagSearchInput, locItems, 'No locations created yet.');

        els.tagModal.style.display = 'flex';
    },

    closeTagModal() {
        this.elements.tagModal.style.display = 'none';
    },

    readTagModal() {
        const els = this.elements;
        return {
            characterIds: readTagPicker(els.characterTagPicker),
            locationIds: readTagPicker(els.locationTagPicker)
        };
    }
};
