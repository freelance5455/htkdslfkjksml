import { renderTagPicker, readTagPicker, wireTagPickerSearch } from '../../shared/tagPicker.js';

function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str || '';
    return div.innerHTML;
}

export const locationUi = {
    get elements() {
        return {
            listView: document.getElementById('locationListView'),
            detailView: document.getElementById('locationDetailView'),
            grid: document.getElementById('locationGrid'),
            searchInput: document.getElementById('locationSearchInput'),
            addBtn: document.getElementById('addLocationBtn'),

            modal: document.getElementById('locationModal'),
            form: document.getElementById('locationForm'),
            idInput: document.getElementById('locationId'),
            titleInput: document.getElementById('locationTitleInput'),
            descInput: document.getElementById('locationDescInput'),
            cancelBtn: document.getElementById('cancelLocationModal')
        };
    },

    showListView() {
        this.elements.listView.style.display = 'block';
        this.elements.detailView.style.display = 'none';
    },

    showDetailView() {
        this.elements.listView.style.display = 'none';
        this.elements.detailView.style.display = 'block';
    },

    renderLocationGrid(locations, handlers) {
        const grid = this.elements.grid;
        if (!grid) return;
        grid.innerHTML = '';

        if (!locations || locations.length === 0) {
            grid.innerHTML = `<div class="empty-inline">No locations yet. Click "+ Add Location" to catalog a place.</div>`;
            return;
        }

        locations.forEach(loc => {
            const card = document.createElement('div');
            card.className = 'entity-card';
            card.innerHTML = `
                <h3 class="entity-title">${escapeHtml(loc.title)}</h3>
                <p class="entity-desc">${escapeHtml(loc.description)}</p>
                <div class="entity-meta-line">${(loc.chapterIds || []).length} chapter(s) linked</div>
                <div class="entity-actions">
                    <button class="btn-icon open-btn">Open</button>
                    <button class="btn-icon edit-btn">Edit</button>
                    <button class="btn-icon delete delete-btn">Delete</button>
                </div>
            `;
            card.querySelector('.open-btn').addEventListener('click', () => handlers.onOpen(loc.id));
            card.querySelector('.edit-btn').addEventListener('click', () => handlers.onEdit(loc));
            card.querySelector('.delete-btn').addEventListener('click', () => handlers.onDelete(loc.id));
            grid.appendChild(card);
        });
    },

    renderLocationDetail(location, taggedChapters, handlers) {
        const view = this.elements.detailView;
        if (!view) return;

        view.innerHTML = `
            <div class="detail-back" id="locationBackBtn">← Back to Locations</div>
            <div class="detail-title-row">
                <h1 class="entity-title-lg">${escapeHtml(location.title)}</h1>
                <div class="detail-block-header-actions">
                    <button class="btn-icon" id="locationEditBtn">Edit Location</button>
                    <button class="btn-icon delete" id="locationDeleteBtn">Delete Location</button>
                </div>
            </div>
            <p class="detail-description">${escapeHtml(location.description)}</p>

            <div class="detail-block">
                <div class="detail-block-header">
                    <h3>Chapters set here</h3>
                    <button class="btn-icon" id="locationManageChaptersBtn">+ Add / Manage Chapters</button>
                </div>
                <div class="list-of-links" id="locationChapterList"></div>
            </div>
        `;

        view.querySelector('#locationBackBtn').addEventListener('click', handlers.onBack);
        view.querySelector('#locationEditBtn').addEventListener('click', () => handlers.onEdit(location));
        view.querySelector('#locationDeleteBtn').addEventListener('click', () => handlers.onDelete(location.id));
        view.querySelector('#locationManageChaptersBtn').addEventListener('click', () => handlers.onManageChapters(location));

        this.renderLocationChapterList(taggedChapters, handlers.onOpenChapter);
    },

    renderLocationChapterList(chapters, onOpenChapter) {
        const list = document.getElementById('locationChapterList');
        if (!list) return;
        list.innerHTML = '';

        if (!chapters || chapters.length === 0) {
            list.innerHTML = `<div class="tag-chip-empty">No chapters tagged to this location yet.</div>`;
            return;
        }

        chapters.forEach(ch => {
            const row = document.createElement('button');
            row.type = 'button';
            row.className = 'link-row';
            row.innerHTML = `<span>${escapeHtml(ch.title)}</span><span class="link-row-arrow">→</span>`;
            row.addEventListener('click', () => onOpenChapter(ch.id));
            list.appendChild(row);
        });
    },

    getFormData() {
        const els = this.elements;
        return {
            id: els.idInput?.value ? Number(els.idInput.value) : null,
            title: els.titleInput?.value.trim() || '',
            description: els.descInput?.value.trim() || ''
        };
    },

    openModal(location = null) {
        const els = this.elements;
        this.clearForm();

        document.getElementById('locationModalTitle').textContent = location ? 'Edit Location' : 'Add Location';

        if (location) {
            els.idInput.value = location.id;
            els.titleInput.value = location.title || '';
            els.descInput.value = location.description || '';
        }

        els.modal.style.display = 'flex';
        els.titleInput?.focus();
    },

    closeModal() {
        this.elements.modal.style.display = 'none';
        this.clearForm();
    },

    clearForm() {
        const els = this.elements;
        if (els.idInput) els.idInput.value = '';
        if (els.titleInput) els.titleInput.value = '';
        if (els.descInput) els.descInput.value = '';
    },

    openChapterTagModal(chapters, selectedIds) {
        const modal = document.getElementById('locationChapterTagModal');
        const container = document.getElementById('locationChapterTagPicker');
        const searchInput = document.getElementById('locationChapterTagSearchInput');
        const items = chapters.map(c => ({ id: c.id, label: c.title }));
        const emptyMessage = 'No chapters created yet. Add chapters first from the Chapters tab.';

        renderTagPicker(container, items, selectedIds, emptyMessage);
        wireTagPickerSearch(container, searchInput, items, emptyMessage);

        modal.style.display = 'flex';
    },

    closeChapterTagModal() {
        document.getElementById('locationChapterTagModal').style.display = 'none';
    },

    readChapterTagModal() {
        return readTagPicker(document.getElementById('locationChapterTagPicker'));
    }
};
