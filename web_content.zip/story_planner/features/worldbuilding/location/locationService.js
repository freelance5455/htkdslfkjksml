import { storyService } from '../../workspace/story/storyService.js';
import { createId } from '../../shared/id.js';

export const locationService = {
    getLocations() {
        const story = storyService.getCurrentStory();
        return story ? (story.locations || []) : [];
    },

    getLocationById(id) {
        return this.getLocations().find(l => l.id === id) || null;
    },

    addLocation(data) {
        const story = storyService.getCurrentStory();
        if (!story) return null;
        if (!story.locations) story.locations = [];

        const newLocation = {
            id: createId(),
            title: data.title,
            description: data.description,
            chapterIds: data.chapterIds || [],
            createdAt: Date.now()
        };

        story.locations.push(newLocation);
        storyService.updateStoryDetails({});
        return newLocation;
    },

    updateLocation(id, updatedData) {
        const story = storyService.getCurrentStory();
        if (!story || !story.locations) return false;

        const index = story.locations.findIndex(l => l.id === id);
        if (index === -1) return false;

        story.locations[index] = { ...story.locations[index], ...updatedData };
        storyService.updateStoryDetails({});
        return true;
    },

    deleteLocation(id) {
        const story = storyService.getCurrentStory();
        if (!story || !story.locations) return false;

        story.locations = story.locations.filter(l => l.id !== id);

        // Cascade cleanup: remove this location from lore/factions that tagged it
        (story.lore || []).forEach(l => {
            if (l.locationIds) l.locationIds = l.locationIds.filter(id2 => id2 !== id);
        });
        (story.factions || []).forEach(f => {
            if (f.locationIds) f.locationIds = f.locationIds.filter(id2 => id2 !== id);
        });
        (story.ideas || []).forEach(i => {
            if (i.locationIds) i.locationIds = i.locationIds.filter(id2 => id2 !== id);
        });

        // Cascade cleanup: unlink this location from any Story Map boxes that referenced it
        if (story.storyMap && story.storyMap.boxes) {
            story.storyMap.boxes.forEach(box => {
                if (box.links && box.links.locations) {
                    box.links.locations = box.links.locations.filter(lid => lid !== id);
                }
            });
        }

        storyService.updateStoryDetails({});
        return true;
    },

    searchLocations(query) {
        const locations = this.getLocations();
        const q = (query || '').trim().toLowerCase();
        if (!q) return locations;
        return locations.filter(l =>
            l.title.toLowerCase().includes(q) ||
            (l.description || '').toLowerCase().includes(q)
        );
    },

    searchLocationChapters(location, allChapters, query) {
        const tagged = (location.chapterIds || [])
            .map(id => allChapters.find(c => c.id === id))
            .filter(Boolean);
        const q = (query || '').trim().toLowerCase();
        if (!q) return tagged;
        return tagged.filter(c => c.title.toLowerCase().includes(q));
    }
};
