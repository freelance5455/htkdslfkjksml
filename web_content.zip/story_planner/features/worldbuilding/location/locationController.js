import { locationService } from './locationService.js';
import { locationUi } from './locationUi.js';
import { chapterService } from '../../workspace/chapter/chapterService.js';
import { openChapterById } from '../../workspace/chapter/chapterController.js';
import { storyUi } from '../../workspace/story/storyUi.js';

let currentSearchQuery = '';
let activeLocationId = null;

export function initLocationFeature() {
    attachEventListeners();
}

// Allows other features (e.g. the Story Map) to jump straight into a location's detail view.
export function openLocationById(id) {
    handleOpenLocation(id);
}

export function loadLocationsTab() {
    currentSearchQuery = '';
    activeLocationId = null;
    const els = locationUi.elements;
    if (els.searchInput) els.searchInput.value = '';

    locationUi.showListView();
    renderList();
}

function renderList() {
    const locations = locationService.searchLocations(currentSearchQuery);
    locationUi.renderLocationGrid(locations, {
        onOpen: handleOpenLocation,
        onEdit: handleEditLocation,
        onDelete: handleDeleteLocation
    });
}

function handleOpenLocation(id) {
    activeLocationId = id;
    const location = locationService.getLocationById(id);
    if (!location) return;

    const allChapters = chapterService.getChapters();
    const taggedChapters = locationService.searchLocationChapters(location, allChapters, '');

    locationUi.showDetailView();
    locationUi.renderLocationDetail(location, taggedChapters, {
        onBack: () => {
            activeLocationId = null;
            locationUi.showListView();
            renderList();
        },
        onEdit: handleEditLocation,
        onDelete: handleDeleteLocation,
        onManageChapters: handleManageChapters,
        onOpenChapter: (chapterId) => {
            storyUi.switchTab('chapters');
            openChapterById(chapterId);
        }
    });
}

function handleEditLocation(location) {
    locationUi.openModal(location);
}

function handleManageChapters(location) {
    const allChapters = chapterService.getChapters();
    locationUi.openChapterTagModal(allChapters, location.chapterIds || []);

    const saveBtn = document.getElementById('locationChapterTagSaveBtn');
    const cancelBtn = document.getElementById('locationChapterTagCancelBtn');

    const onSave = () => {
        const chapterIds = locationUi.readChapterTagModal();
        locationService.updateLocation(location.id, { chapterIds });
        locationUi.closeChapterTagModal();
        handleOpenLocation(location.id);
        cleanup();
    };
    const onCancel = () => {
        locationUi.closeChapterTagModal();
        cleanup();
    };
    function cleanup() {
        saveBtn.removeEventListener('click', onSave);
        cancelBtn.removeEventListener('click', onCancel);
    }
    saveBtn.addEventListener('click', onSave);
    cancelBtn.addEventListener('click', onCancel);
}

function handleDeleteLocation(id) {
    if (!confirm('Delete this location? This cannot be undone.')) return;
    locationService.deleteLocation(id);
    activeLocationId = null;
    locationUi.showListView();
    renderList();
}

function handleSaveLocation(e) {
    e.preventDefault();
    const formData = locationUi.getFormData();

    if (!formData.title) {
        alert('Please enter a location title.');
        return;
    }
    if (!formData.description) {
        alert('Please enter a location description.');
        return;
    }

    let locationId = formData.id;
    if (formData.id) {
        locationService.updateLocation(formData.id, { title: formData.title, description: formData.description });
    } else {
        const created = locationService.addLocation(formData);
        locationId = created.id;
    }

    locationUi.closeModal();

    // If we were editing from the detail view, stay there and refresh; otherwise refresh the list.
    if (activeLocationId === locationId) {
        handleOpenLocation(locationId);
    } else {
        renderList();
    }
}

function attachEventListeners() {
    const els = locationUi.elements;

    if (els.addBtn) els.addBtn.addEventListener('click', () => locationUi.openModal());
    if (els.cancelBtn) els.cancelBtn.addEventListener('click', () => locationUi.closeModal());
    if (els.form) els.form.addEventListener('submit', handleSaveLocation);
    if (els.searchInput) {
        els.searchInput.addEventListener('input', (e) => {
            currentSearchQuery = e.target.value;
            renderList();
        });
    }
}
