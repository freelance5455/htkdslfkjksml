import { loreService } from './loreService.js';
import { loreUi } from './loreUi.js';
import { storyService } from '../../workspace/story/storyService.js';

let currentSearchQuery = '';
let currentSearchMode = 'all';
let activeLoreId = null;

function getCharacters() {
    const story = storyService.getCurrentStory();
    return story ? (story.characters || []) : [];
}
function getLocations() {
    const story = storyService.getCurrentStory();
    return story ? (story.locations || []) : [];
}

export function initLoreFeature() {
    attachEventListeners();
}

// Allows other features (e.g. the Story Map) to jump straight into a lore entry's detail view.
export function openLoreById(id) {
    handleOpenLore(id);
}

export function loadLoreTab() {
    currentSearchQuery = '';
    currentSearchMode = 'all';
    activeLoreId = null;
    const els = loreUi.elements;
    if (els.searchInput) els.searchInput.value = '';
    if (els.searchMode) els.searchMode.value = 'all';

    loreUi.showListView();
    renderList();
}

function renderList() {
    const loreEntries = loreService.searchLore(currentSearchQuery, currentSearchMode);
    loreUi.renderLoreGrid(loreEntries, getCharacters(), getLocations(), {
        onOpen: handleOpenLore,
        onEdit: handleEditLore,
        onDelete: handleDeleteLore
    });
}

function handleOpenLore(id) {
    activeLoreId = id;
    const entry = loreService.getLoreById(id);
    if (!entry) return;
    loreUi.showDetailView();
    renderDetail(id);
}

function renderDetail(id) {
    const entry = loreService.getLoreById(id);
    if (!entry) return;

    loreUi.renderLoreDetail(entry, getCharacters(), getLocations(), {
        onBack: () => {
            activeLoreId = null;
            loreUi.showListView();
            renderList();
        },
        onDelete: handleDeleteLore,
        onEdit: handleEditLore,
        onManageTags: handleManageTags
    });
}

function handleEditLore(entry) {
    loreUi.openModal(entry);
}

function handleManageTags(entry) {
    loreUi.openTagModal(getCharacters(), getLocations(), entry.characterIds || [], entry.locationIds || []);

    const els = loreUi.elements;
    const onSave = () => {
        const { characterIds, locationIds } = loreUi.readTagModal();
        loreService.updateLore(entry.id, { characterIds, locationIds });
        loreUi.closeTagModal();
        renderDetail(entry.id);
        cleanup();
    };
    const onCancel = () => {
        loreUi.closeTagModal();
        cleanup();
    };
    function cleanup() {
        els.tagSaveBtn.removeEventListener('click', onSave);
        els.tagCancelBtn.removeEventListener('click', onCancel);
    }
    els.tagSaveBtn.addEventListener('click', onSave);
    els.tagCancelBtn.addEventListener('click', onCancel);
}

function handleDeleteLore(id) {
    if (!confirm('Delete this lore entry? This cannot be undone.')) return;
    loreService.deleteLore(id);
    activeLoreId = null;
    loreUi.showListView();
    renderList();
}

function handleSaveLore(e) {
    e.preventDefault();
    const formData = loreUi.getFormData();

    if (!formData.title) {
        alert('Please enter a lore title.');
        return;
    }

    let loreId = formData.id;
    if (formData.id) {
        loreService.updateLore(formData.id, { title: formData.title, description: formData.description });
    } else {
        const created = loreService.addLore(formData);
        loreId = created.id;
    }

    loreUi.closeModal();

    if (activeLoreId === loreId) {
        renderDetail(loreId);
    } else {
        renderList();
    }
}

function attachEventListeners() {
    const els = loreUi.elements;

    if (els.addBtn) els.addBtn.addEventListener('click', () => loreUi.openModal());
    if (els.cancelBtn) els.cancelBtn.addEventListener('click', () => loreUi.closeModal());
    if (els.form) els.form.addEventListener('submit', handleSaveLore);
    if (els.searchInput) {
        els.searchInput.addEventListener('input', (e) => {
            currentSearchQuery = e.target.value;
            renderList();
        });
    }
    if (els.searchMode) {
        els.searchMode.addEventListener('change', (e) => {
            currentSearchMode = e.target.value;
            renderList();
        });
    }
}
