import { storyService } from '../../workspace/story/storyService.js';
import { createId } from '../../shared/id.js';

export const loreService = {
    getLore() {
        const story = storyService.getCurrentStory();
        return story ? (story.lore || []) : [];
    },

    getLoreById(id) {
        return this.getLore().find(l => l.id === id) || null;
    },

    addLore(data) {
        const story = storyService.getCurrentStory();
        if (!story) return null;
        if (!story.lore) story.lore = [];

        const newLore = {
            id: createId(),
            title: data.title,
            description: data.description || '',
            characterIds: data.characterIds || [],
            locationIds: data.locationIds || [],
            createdAt: Date.now()
        };

        story.lore.push(newLore);
        storyService.updateStoryDetails({});
        return newLore;
    },

    updateLore(id, updatedData) {
        const story = storyService.getCurrentStory();
        if (!story || !story.lore) return false;

        const index = story.lore.findIndex(l => l.id === id);
        if (index === -1) return false;

        story.lore[index] = { ...story.lore[index], ...updatedData };
        storyService.updateStoryDetails({});
        return true;
    },

    deleteLore(id) {
        const story = storyService.getCurrentStory();
        if (!story || !story.lore) return false;

        story.lore = story.lore.filter(l => l.id !== id);

        // Cascade cleanup: unlink this lore entry from any Story Map boxes that referenced it
        if (story.storyMap && story.storyMap.boxes) {
            story.storyMap.boxes.forEach(box => {
                if (box.links && box.links.lore) {
                    box.links.lore = box.links.lore.filter(lid => lid !== id);
                }
            });
        }

        storyService.updateStoryDetails({});
        return true;
    },

    searchLore(query, mode = 'all') {
        const loreEntries = this.getLore();
        const q = (query || '').trim().toLowerCase();
        if (!q) return loreEntries;

        const story = storyService.getCurrentStory();
        const characters = story ? (story.characters || []) : [];
        const locations = story ? (story.locations || []) : [];

        return loreEntries.filter(entry => {
            const titleMatch = entry.title.toLowerCase().includes(q);
            const charMatch = (entry.characterIds || [])
                .map(id => characters.find(c => c.id === id))
                .filter(Boolean)
                .some(c => c.name.toLowerCase().includes(q));
            const locMatch = (entry.locationIds || [])
                .map(id => locations.find(l => l.id === id))
                .filter(Boolean)
                .some(l => l.title.toLowerCase().includes(q));

            if (mode === 'title') return titleMatch;
            if (mode === 'character') return charMatch;
            if (mode === 'location') return locMatch;
            return titleMatch || charMatch || locMatch;
        });
    }
};
