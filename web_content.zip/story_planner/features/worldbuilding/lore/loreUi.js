import { renderTagPicker, readTagPicker, wireTagPickerSearch, renderTagChips } from '../../shared/tagPicker.js';

function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str || '';
    return div.innerHTML;
}

const editIconSvg = `<svg class="icon-inline" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <path d="M13.5 3.5l3 3L7 16H4v-3l9.5-9.5z" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/>
</svg>`;

export const loreUi = {
    get elements() {
        return {
            listView: document.getElementById('loreListView'),
            detailView: document.getElementById('loreDetailView'),
            grid: document.getElementById('loreGrid'),
            searchInput: document.getElementById('loreSearchInput'),
            searchMode: document.getElementById('loreSearchMode'),
            addBtn: document.getElementById('addLoreBtn'),

            modal: document.getElementById('loreModal'),
            form: document.getElementById('loreForm'),
            idInput: document.getElementById('loreId'),
            titleInput: document.getElementById('loreTitleInput'),
            descInput: document.getElementById('loreDescInput'),
            cancelBtn: document.getElementById('cancelLoreModal'),

            tagModal: document.getElementById('loreTagModal'),
            characterTagPicker: document.getElementById('loreCharacterTagPicker'),
            characterTagSearchInput: document.getElementById('loreCharacterTagSearchInput'),
            locationTagPicker: document.getElementById('loreLocationTagPicker'),
            locationTagSearchInput: document.getElementById('loreLocationTagSearchInput'),
            tagSaveBtn: document.getElementById('loreTagSaveBtn'),
            tagCancelBtn: document.getElementById('loreTagCancelBtn')
        };
    },

    showListView() {
        this.elements.listView.style.display = 'block';
        this.elements.detailView.style.display = 'none';
    },

    showDetailView() {
        this.elements.listView.style.display = 'none';
        this.elements.detailView.style.display = 'block';
    },

    renderLoreGrid(loreEntries, characters, locations, handlers) {
        const grid = this.elements.grid;
        if (!grid) return;
        grid.innerHTML = '';

        if (!loreEntries || loreEntries.length === 0) {
            grid.innerHTML = `<div class="empty-inline">No lore yet. Click "+ Add Lore" to record your world's history.</div>`;
            return;
        }

        loreEntries.forEach(entry => {
            const taggedChars = (entry.characterIds || []).map(id => characters.find(c => c.id === id)).filter(Boolean);
            const taggedLocs = (entry.locationIds || []).map(id => locations.find(l => l.id === id)).filter(Boolean);

            const card = document.createElement('div');
            card.className = 'entity-card';
            card.innerHTML = `
                <h3 class="entity-title">${escapeHtml(entry.title)}</h3>
                <p class="entity-desc">${escapeHtml(entry.description) || 'No description yet.'}</p>
                <div class="entity-tags">
                    ${taggedChars.map(c => `<span class="tag-pill">${escapeHtml(c.name)}</span>`).join('')}
                    ${taggedLocs.map(l => `<span class="tag-pill tag-pill-location">${escapeHtml(l.title)}</span>`).join('')}
                    ${(taggedChars.length === 0 && taggedLocs.length === 0) ? `<span class="tag-chip-empty">Nothing tagged yet</span>` : ''}
                </div>
                <div class="entity-actions">
                    <button class="btn-icon open-btn">Open</button>
                    <button class="btn-icon edit-btn">Edit</button>
                    <button class="btn-icon delete delete-btn">Delete</button>
                </div>
            `;
            card.querySelector('.open-btn').addEventListener('click', () => handlers.onOpen(entry.id));
            card.querySelector('.edit-btn').addEventListener('click', () => handlers.onEdit(entry));
            card.querySelector('.delete-btn').addEventListener('click', () => handlers.onDelete(entry.id));
            grid.appendChild(card);
        });
    },

    renderLoreDetail(entry, characters, locations, handlers) {
        const view = this.elements.detailView;
        if (!view) return;

        const taggedChars = (entry.characterIds || []).map(id => characters.find(c => c.id === id)).filter(Boolean);
        const taggedLocs = (entry.locationIds || []).map(id => locations.find(l => l.id === id)).filter(Boolean);

        view.innerHTML = `
            <div class="detail-back" id="loreBackBtn">← Back to Lore</div>
            <div class="detail-title-row">
                <h1 class="entity-title-lg">${escapeHtml(entry.title)}</h1>
                <div class="detail-block-header-actions">
                    <button class="btn-icon content-edit-btn" id="loreEditBtn">${editIconSvg} Edit Title</button>
                    <button class="btn-icon delete" id="loreDeleteBtn">Delete Lore</button>
                </div>
            </div>
            <p class="detail-description">${entry.description ? escapeHtml(entry.description) : 'No description yet.'}</p>

            <div class="detail-block">
                <div class="detail-block-header">
                    <h3>Tags</h3>
                    <button class="btn-icon" id="loreManageTagsBtn">Manage Tags</button>
                </div>

                <div class="tag-section">
                    <span class="tag-section-label">Characters</span>
                    <div class="entity-tags" id="loreCharacterTagChips"></div>
                </div>
                <div class="tag-section">
                    <span class="tag-section-label">Locations</span>
                    <div class="entity-tags" id="loreLocationTagChips"></div>
                </div>
            </div>
        `;

        view.querySelector('#loreBackBtn').addEventListener('click', handlers.onBack);
        view.querySelector('#loreEditBtn').addEventListener('click', () => handlers.onEdit(entry));
        view.querySelector('#loreDeleteBtn').addEventListener('click', () => handlers.onDelete(entry.id));
        view.querySelector('#loreManageTagsBtn').addEventListener('click', () => handlers.onManageTags(entry));

        renderTagChips(view.querySelector('#loreCharacterTagChips'), taggedChars.map(c => ({ id: c.id, label: c.name })), 'No characters tagged yet.');
        renderTagChips(view.querySelector('#loreLocationTagChips'), taggedLocs.map(l => ({ id: l.id, label: l.title })), 'No locations tagged yet.');
    },

    getFormData() {
        const els = this.elements;
        return {
            id: els.idInput?.value ? Number(els.idInput.value) : null,
            title: els.titleInput?.value.trim() || '',
            description: els.descInput?.value.trim() || ''
        };
    },

    openModal(entry = null) {
        const els = this.elements;
        this.clearForm();

        document.getElementById('loreModalTitle').textContent = entry ? 'Edit Lore' : 'Add Lore';

        if (entry) {
            els.idInput.value = entry.id;
            els.titleInput.value = entry.title || '';
            els.descInput.value = entry.description || '';
        }

        els.modal.style.display = 'flex';
        els.titleInput?.focus();
    },

    closeModal() {
        this.elements.modal.style.display = 'none';
        this.clearForm();
    },

    clearForm() {
        const els = this.elements;
        if (els.idInput) els.idInput.value = '';
        if (els.titleInput) els.titleInput.value = '';
        if (els.descInput) els.descInput.value = '';
    },

    // --- Manage-tags modal (searchable, toggle-based) ---
    openTagModal(characters, locations, selectedCharacterIds, selectedLocationIds) {
        const els = this.elements;

        const charItems = characters.map(c => ({ id: c.id, label: c.name, sublabel: c.role }));
        renderTagPicker(els.characterTagPicker, charItems, selectedCharacterIds, 'No characters created yet.');
        wireTagPickerSearch(els.characterTagPicker, els.characterTagSearchInput, charItems, 'No characters created yet.');

        const locItems = locations.map(l => ({ id: l.id, label: l.title }));
        renderTagPicker(els.locationTagPicker, locItems, selectedLocationIds, 'No locations created yet.');
        wireTagPickerSearch(els.locationTagPicker, els.locationTagSearchInput, locItems, 'No locations created yet.');

        els.tagModal.style.display = 'flex';
    },

    closeTagModal() {
        this.elements.tagModal.style.display = 'none';
    },

    readTagModal() {
        const els = this.elements;
        return {
            characterIds: readTagPicker(els.characterTagPicker),
            locationIds: readTagPicker(els.locationTagPicker)
        };
    }
};
