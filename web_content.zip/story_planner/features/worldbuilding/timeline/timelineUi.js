import { renderTagPicker, readTagPicker, wireTagPickerSearch } from '../../shared/tagPicker.js';

function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str || '';
    return div.innerHTML;
}

export const timelineUi = {
    get elements() {
        return {
            list: document.getElementById('timelineListContainer'),
            searchInput: document.getElementById('timelineSearchInput'),
            addBtn: document.getElementById('addTimelineBtn'),

            modal: document.getElementById('timelineModal'),
            form: document.getElementById('timelineForm'),
            idInput: document.getElementById('timelineEventId'),
            titleInput: document.getElementById('timelineTitleInput'),
            dateInput: document.getElementById('timelineDateInput'),
            orderInput: document.getElementById('timelineOrderInput'),
            descInput: document.getElementById('timelineDescInput'),
            chapterTagPicker: document.getElementById('timelineChapterTagPicker'),
            chapterTagSearchInput: document.getElementById('timelineChapterTagSearchInput'),
            characterTagPicker: document.getElementById('timelineCharacterTagPicker'),
            characterTagSearchInput: document.getElementById('timelineCharacterTagSearchInput'),
            cancelBtn: document.getElementById('cancelTimelineModal')
        };
    },

    renderTimeline(events, chapters, characters, handlers) {
        const list = this.elements.list;
        if (!list) return;
        list.innerHTML = '';

        if (!events || events.length === 0) {
            list.innerHTML = `<div class="empty-inline">No timeline events yet. Click "+ Add Event" to lay out your world's history.</div>`;
            return;
        }

        events.forEach((ev, i) => {
            const taggedChapters = (ev.chapterIds || []).map(id => chapters.find(c => c.id === id)).filter(Boolean);
            const taggedChars = (ev.characterIds || []).map(id => characters.find(c => c.id === id)).filter(Boolean);

            const item = document.createElement('div');
            item.className = 'timeline-event';
            item.innerHTML = `
                <div class="timeline-event-marker"><span>${i + 1}</span></div>
                <div class="timeline-event-body">
                    <div class="timeline-event-header">
                        <h3 class="entity-title">${escapeHtml(ev.title)}</h3>
                        ${ev.date ? `<span class="timeline-event-date">${escapeHtml(ev.date)}</span>` : ''}
                    </div>
                    <p class="entity-desc">${escapeHtml(ev.description) || 'No description yet.'}</p>
                    <div class="entity-tags">
                        ${taggedChapters.map(c => `<span class="tag-pill tag-pill-chapter">${escapeHtml(c.title)}</span>`).join('')}
                        ${taggedChars.map(c => `<span class="tag-pill">${escapeHtml(c.name)}</span>`).join('')}
                    </div>
                    <div class="entity-actions">
                        <button class="btn-icon edit-btn">Edit</button>
                        <button class="btn-icon delete delete-btn">Delete</button>
                    </div>
                </div>
            `;
            item.querySelector('.edit-btn').addEventListener('click', () => handlers.onEdit(ev));
            item.querySelector('.delete-btn').addEventListener('click', () => handlers.onDelete(ev.id));
            list.appendChild(item);
        });
    },

    getFormData() {
        const els = this.elements;
        return {
            id: els.idInput?.value ? Number(els.idInput.value) : null,
            title: els.titleInput?.value.trim() || '',
            date: els.dateInput?.value.trim() || '',
            order: els.orderInput?.value !== '' ? Number(els.orderInput.value) : 0,
            description: els.descInput?.value.trim() || '',
            chapterIds: readTagPicker(els.chapterTagPicker),
            characterIds: readTagPicker(els.characterTagPicker)
        };
    },

    openModal(chapters, characters, event = null) {
        const els = this.elements;
        this.clearForm();

        document.getElementById('timelineModalTitle').textContent = event ? 'Edit Event' : 'Add Timeline Event';

        if (event) {
            els.idInput.value = event.id;
            els.titleInput.value = event.title || '';
            els.dateInput.value = event.date || '';
            els.orderInput.value = event.order ?? 0;
            els.descInput.value = event.description || '';
        }

        renderTagPicker(
            els.chapterTagPicker,
            chapters.map(c => ({ id: c.id, label: c.title })),
            event ? (event.chapterIds || []) : [],
            'No chapters created yet.'
        );
        wireTagPickerSearch(
            els.chapterTagPicker,
            els.chapterTagSearchInput,
            chapters.map(c => ({ id: c.id, label: c.title })),
            'No chapters created yet.'
        );
        renderTagPicker(
            els.characterTagPicker,
            characters.map(c => ({ id: c.id, label: c.name, sublabel: c.role })),
            event ? (event.characterIds || []) : [],
            'No characters created yet.'
        );
        wireTagPickerSearch(
            els.characterTagPicker,
            els.characterTagSearchInput,
            characters.map(c => ({ id: c.id, label: c.name, sublabel: c.role })),
            'No characters created yet.'
        );

        els.modal.style.display = 'flex';
        els.titleInput?.focus();
    },

    closeModal() {
        this.elements.modal.style.display = 'none';
        this.clearForm();
    },

    clearForm() {
        const els = this.elements;
        if (els.idInput) els.idInput.value = '';
        if (els.titleInput) els.titleInput.value = '';
        if (els.dateInput) els.dateInput.value = '';
        if (els.orderInput) els.orderInput.value = '0';
        if (els.descInput) els.descInput.value = '';
        if (els.chapterTagPicker) els.chapterTagPicker.innerHTML = '';
        if (els.characterTagPicker) els.characterTagPicker.innerHTML = '';
    }
};
