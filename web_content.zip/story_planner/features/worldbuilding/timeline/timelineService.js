import { storyService } from '../../workspace/story/storyService.js';
import { createId } from '../../shared/id.js';

export const timelineService = {
    getEvents() {
        const story = storyService.getCurrentStory();
        const events = story ? (story.timeline || []) : [];
        // Sort chronologically by the user-assigned order, falling back to creation order.
        return [...events].sort((a, b) => {
            const orderA = a.order ?? 0;
            const orderB = b.order ?? 0;
            if (orderA !== orderB) return orderA - orderB;
            return (a.createdAt || 0) - (b.createdAt || 0);
        });
    },

    getEventById(id) {
        return this.getEvents().find(e => e.id === id) || null;
    },

    addEvent(data) {
        const story = storyService.getCurrentStory();
        if (!story) return null;
        if (!story.timeline) story.timeline = [];

        const newEvent = {
            id: createId(),
            title: data.title,
            date: data.date || '',
            order: Number.isFinite(Number(data.order)) ? Number(data.order) : story.timeline.length,
            description: data.description || '',
            chapterIds: data.chapterIds || [],
            characterIds: data.characterIds || [],
            createdAt: Date.now()
        };

        story.timeline.push(newEvent);
        storyService.updateStoryDetails({});
        return newEvent;
    },

    updateEvent(id, updatedData) {
        const story = storyService.getCurrentStory();
        if (!story || !story.timeline) return false;

        const index = story.timeline.findIndex(e => e.id === id);
        if (index === -1) return false;

        story.timeline[index] = { ...story.timeline[index], ...updatedData };
        storyService.updateStoryDetails({});
        return true;
    },

    deleteEvent(id) {
        const story = storyService.getCurrentStory();
        if (!story || !story.timeline) return false;

        story.timeline = story.timeline.filter(e => e.id !== id);
        storyService.updateStoryDetails({});
        return true;
    },

    searchEvents(query) {
        const events = this.getEvents();
        const q = (query || '').trim().toLowerCase();
        if (!q) return events;
        return events.filter(e =>
            e.title.toLowerCase().includes(q) ||
            (e.date || '').toLowerCase().includes(q) ||
            (e.description || '').toLowerCase().includes(q)
        );
    }
};
