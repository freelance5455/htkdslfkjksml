import { timelineService } from './timelineService.js';
import { timelineUi } from './timelineUi.js';
import { storyService } from '../../workspace/story/storyService.js';
import { chapterService } from '../../workspace/chapter/chapterService.js';

let currentSearchQuery = '';

function getCharacters() {
    const story = storyService.getCurrentStory();
    return story ? (story.characters || []) : [];
}

export function initTimelineFeature() {
    attachEventListeners();
}

export function loadTimelineTab() {
    currentSearchQuery = '';
    const els = timelineUi.elements;
    if (els.searchInput) els.searchInput.value = '';
    renderList();
}

function renderList() {
    const events = timelineService.searchEvents(currentSearchQuery);
    timelineUi.renderTimeline(events, chapterService.getChapters(), getCharacters(), {
        onEdit: handleEditEvent,
        onDelete: handleDeleteEvent
    });
}

function handleEditEvent(event) {
    timelineUi.openModal(chapterService.getChapters(), getCharacters(), event);
}

function handleDeleteEvent(id) {
    if (!confirm('Delete this timeline event? This cannot be undone.')) return;
    timelineService.deleteEvent(id);
    renderList();
}

function handleSaveEvent(e) {
    e.preventDefault();
    const formData = timelineUi.getFormData();

    if (!formData.title) {
        alert('Please enter an event title.');
        return;
    }

    if (formData.id) {
        timelineService.updateEvent(formData.id, formData);
    } else {
        timelineService.addEvent(formData);
    }

    timelineUi.closeModal();
    renderList();
}

function attachEventListeners() {
    const els = timelineUi.elements;

    if (els.addBtn) els.addBtn.addEventListener('click', () => timelineUi.openModal(chapterService.getChapters(), getCharacters()));
    if (els.cancelBtn) els.cancelBtn.addEventListener('click', () => timelineUi.closeModal());
    if (els.form) els.form.addEventListener('submit', handleSaveEvent);
    if (els.searchInput) {
        els.searchInput.addEventListener('input', (e) => {
            currentSearchQuery = e.target.value;
            renderList();
        });
    }
}
