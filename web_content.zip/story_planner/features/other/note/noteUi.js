function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str || '';
    return div.innerHTML;
}

const pinIcon = `<svg class="pin-icon" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M7 3h6l-.9 4 2.4 2.4v1H10.8V17l-.8 1-.8-1v-6.6H5.5v-1L7.9 7 7 3z" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/></svg>`;

export const noteUi = {
    get elements() {
        return {
            grid: document.getElementById('noteGrid'),
            searchInput: document.getElementById('noteSearchInput'),
            addBtn: document.getElementById('addNoteBtn'),

            modal: document.getElementById('noteModal'),
            form: document.getElementById('noteForm'),
            idInput: document.getElementById('noteId'),
            titleInput: document.getElementById('noteTitleInput'),
            contentInput: document.getElementById('noteContentInput'),
            pinnedInput: document.getElementById('notePinnedInput'),
            cancelBtn: document.getElementById('cancelNoteModal')
        };
    },

    renderNoteGrid(notes, handlers) {
        const grid = this.elements.grid;
        if (!grid) return;
        grid.innerHTML = '';

        if (!notes || notes.length === 0) {
            grid.innerHTML = `<div class="empty-inline">No notes yet. Click "+ Add Note" to jot something down.</div>`;
            return;
        }

        notes.forEach(note => {
            const card = document.createElement('div');
            card.className = 'entity-card note-card' + (note.pinned ? ' note-card-pinned' : '');
            card.innerHTML = `
                <div class="entity-card-top">
                    <button class="pin-btn ${note.pinned ? 'pin-btn-active' : ''}" title="${note.pinned ? 'Remove from favorites' : 'Add to favorites'}" aria-label="${note.pinned ? 'Remove from favorites' : 'Add to favorites'}">${pinIcon}</button>
                </div>
                <h3 class="entity-title">${escapeHtml(note.title)}</h3>
                <p class="entity-desc note-desc">${escapeHtml(note.content) || 'Empty note.'}</p>
                <div class="entity-actions">
                    <button class="btn-icon edit-btn">Edit</button>
                    <button class="btn-icon delete delete-btn">Delete</button>
                </div>
            `;
            card.querySelector('.pin-btn').addEventListener('click', () => handlers.onTogglePin(note.id));
            card.querySelector('.edit-btn').addEventListener('click', () => handlers.onEdit(note));
            card.querySelector('.delete-btn').addEventListener('click', () => handlers.onDelete(note.id));
            grid.appendChild(card);
        });
    },

    getFormData() {
        const els = this.elements;
        return {
            id: els.idInput?.value ? Number(els.idInput.value) : null,
            title: els.titleInput?.value.trim() || '',
            content: els.contentInput?.value.trim() || '',
            pinned: !!els.pinnedInput?.checked
        };
    },

    openModal(note = null) {
        const els = this.elements;
        this.clearForm();

        document.getElementById('noteModalTitle').textContent = note ? 'Edit Note' : 'Add Note';

        if (note) {
            els.idInput.value = note.id;
            els.titleInput.value = note.title || '';
            els.contentInput.value = note.content || '';
            els.pinnedInput.checked = !!note.pinned;
        }

        els.modal.style.display = 'flex';
        els.titleInput?.focus();
    },

    closeModal() {
        this.elements.modal.style.display = 'none';
        this.clearForm();
    },

    clearForm() {
        const els = this.elements;
        if (els.idInput) els.idInput.value = '';
        if (els.titleInput) els.titleInput.value = '';
        if (els.contentInput) els.contentInput.value = '';
        if (els.pinnedInput) els.pinnedInput.checked = false;
    }
};
