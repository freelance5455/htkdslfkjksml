import { noteService } from './noteService.js';
import { noteUi } from './noteUi.js';

let currentSearchQuery = '';

export function initNoteFeature() {
    attachEventListeners();
}

export function loadNotesTab() {
    currentSearchQuery = '';
    const els = noteUi.elements;
    if (els.searchInput) els.searchInput.value = '';
    renderList();
}

function renderList() {
    const notes = noteService.searchNotes(currentSearchQuery);
    noteUi.renderNoteGrid(notes, {
        onEdit: handleEditNote,
        onDelete: handleDeleteNote,
        onTogglePin: handleTogglePin
    });
}

function handleEditNote(note) {
    noteUi.openModal(note);
}

function handleTogglePin(id) {
    noteService.togglePin(id);
    renderList();
}

function handleDeleteNote(id) {
    if (!confirm('Delete this note? This cannot be undone.')) return;
    noteService.deleteNote(id);
    renderList();
}

function handleSaveNote(e) {
    e.preventDefault();
    const formData = noteUi.getFormData();

    if (!formData.title) {
        alert('Please enter a note title.');
        return;
    }

    if (formData.id) {
        noteService.updateNote(formData.id, formData);
    } else {
        noteService.addNote(formData);
    }

    noteUi.closeModal();
    renderList();
}

function attachEventListeners() {
    const els = noteUi.elements;

    if (els.addBtn) els.addBtn.addEventListener('click', () => noteUi.openModal());
    if (els.cancelBtn) els.cancelBtn.addEventListener('click', () => noteUi.closeModal());
    if (els.form) els.form.addEventListener('submit', handleSaveNote);
    if (els.searchInput) {
        els.searchInput.addEventListener('input', (e) => {
            currentSearchQuery = e.target.value;
            renderList();
        });
    }
}
