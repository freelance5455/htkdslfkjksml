import { storyService } from '../../workspace/story/storyService.js';
import { createId } from '../../shared/id.js';

export const noteService = {
    getNotes() {
        const story = storyService.getCurrentStory();
        const notes = story ? (story.notes || []) : [];
        // Pinned notes float to the top, newest first within each group.
        return [...notes].sort((a, b) => {
            if (!!b.pinned !== !!a.pinned) return (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0);
            return (b.updatedAt || b.createdAt || 0) - (a.updatedAt || a.createdAt || 0);
        });
    },

    getNoteById(id) {
        return this.getNotes().find(n => n.id === id) || null;
    },

    addNote(data) {
        const story = storyService.getCurrentStory();
        if (!story) return null;
        if (!story.notes) story.notes = [];

        const newNote = {
            id: createId(),
            title: data.title || 'Untitled Note',
            content: data.content || '',
            pinned: !!data.pinned,
            createdAt: Date.now(),
            updatedAt: Date.now()
        };

        story.notes.push(newNote);
        storyService.updateStoryDetails({});
        return newNote;
    },

    updateNote(id, updatedData) {
        const story = storyService.getCurrentStory();
        if (!story || !story.notes) return false;

        const index = story.notes.findIndex(n => n.id === id);
        if (index === -1) return false;

        story.notes[index] = { ...story.notes[index], ...updatedData, updatedAt: Date.now() };
        storyService.updateStoryDetails({});
        return true;
    },

    togglePin(id) {
        const note = this.getNoteById(id);
        if (!note) return false;
        return this.updateNote(id, { pinned: !note.pinned });
    },

    deleteNote(id) {
        const story = storyService.getCurrentStory();
        if (!story || !story.notes) return false;

        story.notes = story.notes.filter(n => n.id !== id);
        storyService.updateStoryDetails({});
        return true;
    },

    searchNotes(query) {
        const notes = this.getNotes();
        const q = (query || '').trim().toLowerCase();
        if (!q) return notes;
        return notes.filter(n =>
            n.title.toLowerCase().includes(q) ||
            (n.content || '').toLowerCase().includes(q)
        );
    }
};
