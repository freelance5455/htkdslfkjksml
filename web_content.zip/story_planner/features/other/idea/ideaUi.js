import { renderTagPicker, readTagPicker, wireTagPickerSearch, renderTagChips } from '../../shared/tagPicker.js';

function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str || '';
    return div.innerHTML;
}

const CATEGORY_OPTIONS = ['Plot Twist', 'Character Idea', 'World Detail', 'Theme', 'Other'];
const STATUS_OPTIONS = ['New', 'Considering', 'Using', 'Discarded'];

export const ideaUi = {
    get elements() {
        return {
            listView: document.getElementById('ideaListView'),
            detailView: document.getElementById('ideaDetailView'),
            grid: document.getElementById('ideaGrid'),
            searchInput: document.getElementById('ideaSearchInput'),
            addBtn: document.getElementById('addIdeaBtn'),

            modal: document.getElementById('ideaModal'),
            form: document.getElementById('ideaForm'),
            idInput: document.getElementById('ideaId'),
            titleInput: document.getElementById('ideaTitleInput'),
            categorySelect: document.getElementById('ideaCategorySelect'),
            statusSelect: document.getElementById('ideaStatusSelect'),
            cancelBtn: document.getElementById('cancelIdeaModal'),

            tagModal: document.getElementById('ideaTagModal'),
            tagTypeToggle: document.getElementById('ideaTagTypeToggle'),
            tagPickerLabel: document.getElementById('ideaTagPickerLabel'),
            tagPicker: document.getElementById('ideaTagPicker'),
            tagSearchInput: document.getElementById('ideaTagSearchInput'),
            tagSaveBtn: document.getElementById('ideaTagSaveBtn'),
            tagCancelBtn: document.getElementById('ideaTagCancelBtn')
        };
    },

    showListView() {
        this.elements.listView.style.display = 'block';
        this.elements.detailView.style.display = 'none';
    },

    showDetailView() {
        this.elements.listView.style.display = 'none';
        this.elements.detailView.style.display = 'block';
    },

    renderIdeaGrid(ideas, handlers) {
        const grid = this.elements.grid;
        if (!grid) return;
        grid.innerHTML = '';

        if (!ideas || ideas.length === 0) {
            grid.innerHTML = `<div class="empty-inline">No ideas yet. Click "+ Add Idea" to capture a spark for later.</div>`;
            return;
        }

        ideas.forEach(idea => {
            const statusClass = `status-${(idea.status || 'new').toLowerCase().replace(/\s+/g, '-')}`;

            const card = document.createElement('div');
            card.className = 'entity-card';
            card.innerHTML = `
                <div class="entity-card-top">
                    <span class="badge-category">${escapeHtml(idea.category)}</span>
                    <span class="badge-status ${statusClass}">${escapeHtml(idea.status)}</span>
                </div>
                <h3 class="entity-title">${escapeHtml(idea.title)}</h3>
                <p class="entity-desc">${escapeHtml(idea.content) || 'No details yet.'}</p>
                <div class="entity-actions">
                    <button class="btn-icon open-btn">Open</button>
                    <button class="btn-icon delete delete-btn">Delete</button>
                </div>
            `;
            card.querySelector('.open-btn').addEventListener('click', () => handlers.onOpen(idea.id));
            card.querySelector('.delete-btn').addEventListener('click', () => handlers.onDelete(idea.id));
            grid.appendChild(card);
        });
    },

    // =========================================================
    // DETAIL VIEW — title, category/status, content, and tags
    // are all editable directly inside the open idea.
    // =========================================================
    renderIdeaDetail(idea, refData, handlers) {
        const view = this.elements.detailView;
        if (!view) return;

        view.innerHTML = `
            <div class="detail-back" id="ideaBackBtn">← Back to Ideas</div>
            <div class="detail-title-row">
                <div class="editable-title-row" id="ideaTitleRow"></div>
                <button class="btn-icon delete" id="ideaDeleteBtn">Delete Idea</button>
            </div>

            <div class="idea-meta-row">
                <select id="ideaDetailCategorySelect">
                    ${CATEGORY_OPTIONS.map(opt => `<option value="${opt}"${opt === idea.category ? ' selected' : ''}>${opt}</option>`).join('')}
                </select>
                <select id="ideaDetailStatusSelect">
                    ${STATUS_OPTIONS.map(opt => `<option value="${opt}"${opt === idea.status ? ' selected' : ''}>${opt}</option>`).join('')}
                </select>
            </div>

            <div class="detail-two-col">
                <div class="detail-main">
                    <div class="detail-block">
                        <div class="detail-block-header">
                            <h3>Idea Content</h3>
                            <div class="detail-block-header-actions">
                                <span class="save-status" id="ideaSaveStatus"></span>
                                <button class="btn-icon content-edit-btn" id="ideaContentEditBtn">✎ Edit</button>
                            </div>
                        </div>
                        <div id="ideaContentBody"></div>
                    </div>
                </div>

                <div class="detail-side">
                    <div class="detail-block">
                        <div class="detail-block-header">
                            <h3>Tags</h3>
                            <button class="btn-icon" id="ideaManageTagsBtn">Manage Tags</button>
                        </div>

                        <div class="tag-section">
                            <span class="tag-section-label">Characters</span>
                            <div class="entity-tags" id="ideaCharacterTagChips"></div>
                        </div>
                        <div class="tag-section">
                            <span class="tag-section-label">Locations</span>
                            <div class="entity-tags" id="ideaLocationTagChips"></div>
                        </div>
                        <div class="tag-section">
                            <span class="tag-section-label">Factions</span>
                            <div class="entity-tags" id="ideaFactionTagChips"></div>
                        </div>
                        <div class="tag-section">
                            <span class="tag-section-label">Chapters</span>
                            <div class="entity-tags" id="ideaChapterTagChips"></div>
                        </div>
                        <div class="tag-section">
                            <span class="tag-section-label">Arcs</span>
                            <div class="entity-tags" id="ideaArcTagChips"></div>
                        </div>
                    </div>
                </div>
            </div>
        `;

        view.querySelector('#ideaBackBtn').addEventListener('click', handlers.onBack);
        view.querySelector('#ideaDeleteBtn').addEventListener('click', () => handlers.onDelete(idea.id));
        view.querySelector('#ideaDetailCategorySelect').addEventListener('change', (e) => handlers.onChangeCategory(e.target.value));
        view.querySelector('#ideaDetailStatusSelect').addEventListener('change', (e) => handlers.onChangeStatus(e.target.value));
        view.querySelector('#ideaContentEditBtn').addEventListener('click', () => this.showContentEditMode(idea, handlers));
        view.querySelector('#ideaManageTagsBtn').addEventListener('click', () => handlers.onManageTags(idea));

        this.renderTitleDisplay(idea, handlers);
        this.showContentDisplayMode(idea, handlers);

        renderTagChips(
            view.querySelector('#ideaCharacterTagChips'),
            (idea.characterIds || []).map(id => refData.characters.find(c => c.id === id)).filter(Boolean).map(c => ({ id: c.id, label: c.name })),
            'No characters tagged yet.'
        );
        renderTagChips(
            view.querySelector('#ideaLocationTagChips'),
            (idea.locationIds || []).map(id => refData.locations.find(l => l.id === id)).filter(Boolean).map(l => ({ id: l.id, label: l.title })),
            'No locations tagged yet.'
        );
        renderTagChips(
            view.querySelector('#ideaFactionTagChips'),
            (idea.factionIds || []).map(id => refData.factions.find(f => f.id === id)).filter(Boolean).map(f => ({ id: f.id, label: f.title })),
            'No factions tagged yet.'
        );
        renderTagChips(
            view.querySelector('#ideaChapterTagChips'),
            (idea.chapterIds || []).map(id => refData.chapters.find(c => c.id === id)).filter(Boolean).map(c => ({ id: c.id, label: c.title })),
            'No chapters tagged yet.'
        );
        renderTagChips(
            view.querySelector('#ideaArcTagChips'),
            (idea.arcIds || []).map(id => refData.arcs.find(a => a.id === id)).filter(Boolean).map(a => ({ id: a.id, label: a.title })),
            'No arcs tagged yet.'
        );
    },

    // --- Manage-tags modal: one searchable picker, switched by tag type ---
    openTagModal(idea, refData) {
        const els = this.elements;
        const types = {
            characters: { label: 'Characters', placeholder: 'Search characters...', empty: 'No characters created yet.', items: refData.characters.map(c => ({ id: c.id, label: c.name, sublabel: c.role })), ids: idea.characterIds || [] },
            locations: { label: 'Locations', placeholder: 'Search locations...', empty: 'No locations created yet.', items: refData.locations.map(l => ({ id: l.id, label: l.title })), ids: idea.locationIds || [] },
            factions: { label: 'Factions', placeholder: 'Search factions...', empty: 'No factions created yet.', items: refData.factions.map(f => ({ id: f.id, label: f.title })), ids: idea.factionIds || [] },
            chapters: { label: 'Chapters', placeholder: 'Search chapters...', empty: 'No chapters created yet.', items: refData.chapters.map(c => ({ id: c.id, label: c.title })), ids: idea.chapterIds || [] },
            arcs: { label: 'Arcs', placeholder: 'Search arcs...', empty: 'No arcs created yet.', items: refData.arcs.map(a => ({ id: a.id, label: a.title })), ids: idea.arcIds || [] }
        };
        const selections = Object.fromEntries(Object.entries(types).map(([type, config]) => [type, [...config.ids]]));
        let activeType = 'characters';

        const renderActivePicker = () => {
            const config = types[activeType];
            els.tagPickerLabel.textContent = config.label;
            els.tagSearchInput.placeholder = config.placeholder;
            renderTagPicker(els.tagPicker, config.items, selections[activeType], config.empty, () => {
                selections[activeType] = readTagPicker(els.tagPicker);
            });
            wireTagPickerSearch(els.tagPicker, els.tagSearchInput, config.items, config.empty, () => {
                selections[activeType] = readTagPicker(els.tagPicker);
            });
            els.tagTypeToggle.querySelectorAll('[data-tag-type]').forEach(button => button.classList.toggle('active', button.dataset.tagType === activeType));
        };

        els.tagTypeToggle.onclick = (event) => {
            const button = event.target.closest('[data-tag-type]');
            if (!button) return;
            selections[activeType] = readTagPicker(els.tagPicker);
            activeType = button.dataset.tagType;
            renderActivePicker();
        };
        this._readTagSelections = () => {
            selections[activeType] = readTagPicker(els.tagPicker);
            return {
                characterIds: selections.characters,
                locationIds: selections.locations,
                factionIds: selections.factions,
                chapterIds: selections.chapters,
                arcIds: selections.arcs
            };
        };
        renderActivePicker();
        els.tagModal.style.display = 'flex';
    },

    closeTagModal() {
        this.elements.tagModal.style.display = 'none';
    },

    readTagModal() {
        return this._readTagSelections ? this._readTagSelections() : {};
    },

    // --- Inline-editable title ---
    renderTitleDisplay(idea, handlers) {
        const row = document.getElementById('ideaTitleRow');
        if (!row) return;
        row.innerHTML = `
            <h1 class="entity-title-lg title-tap-hint" id="ideaTitleDisplay" title="Tap to edit">${escapeHtml(idea.title)}</h1>
            <button type="button" class="btn-icon" id="ideaTitleEditBtn">✎ Edit</button>
        `;
        const startEdit = () => this.renderTitleEdit(idea, handlers);
        row.querySelector('#ideaTitleDisplay').addEventListener('click', startEdit);
        row.querySelector('#ideaTitleEditBtn').addEventListener('click', startEdit);
    },

    renderTitleEdit(idea, handlers) {
        const row = document.getElementById('ideaTitleRow');
        if (!row) return;
        row.innerHTML = `<input type="text" class="editable-title-input" id="ideaTitleEditInput" value="${escapeHtml(idea.title)}">`;
        const input = row.querySelector('#ideaTitleEditInput');
        input.focus();
        input.select();

        let settled = false;
        const commit = () => {
            if (settled) return;
            settled = true;
            const newTitle = input.value.trim();
            if (newTitle && newTitle !== idea.title) {
                handlers.onSaveTitle(newTitle);
            } else {
                this.renderTitleDisplay(idea, handlers);
            }
        };
        const cancel = () => {
            if (settled) return;
            settled = true;
            this.renderTitleDisplay(idea, handlers);
        };

        input.addEventListener('blur', commit);
        input.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') { e.preventDefault(); commit(); }
            if (e.key === 'Escape') { e.preventDefault(); cancel(); }
        });
    },

    // --- Content display / tap-to-edit toggle ---
    showContentDisplayMode(idea, handlers) {
        const body = document.getElementById('ideaContentBody');
        const editBtn = document.getElementById('ideaContentEditBtn');
        if (!body) return;
        if (editBtn) editBtn.style.display = '';

        const content = idea.content || '';
        const isEmpty = !content.trim();
        body.innerHTML = `
            <div class="content-display${isEmpty ? ' is-empty' : ''}" id="ideaContentDisplay">${isEmpty ? 'No details yet. Tap to start writing.' : escapeHtml(content)}</div>
        `;
        body.querySelector('#ideaContentDisplay').addEventListener('click', () => this.showContentEditMode(idea, handlers));
    },

    showContentEditMode(idea, handlers) {
        const body = document.getElementById('ideaContentBody');
        const editBtn = document.getElementById('ideaContentEditBtn');
        if (!body) return;
        if (editBtn) editBtn.style.display = 'none';

        body.innerHTML = `
            <textarea id="ideaContentEditor" class="content-editor" placeholder="Describe the idea...">${escapeHtml(idea.content || '')}</textarea>
            <div class="save-bar">
                <span></span>
                <div style="display:flex; gap:8px;">
                    <button type="button" class="btn-icon" id="ideaContentCancelBtn">Cancel</button>
                    <button type="button" class="btn-primary" id="ideaSaveContentBtn">Save Content</button>
                </div>
            </div>
        `;

        body.querySelector('#ideaContentCancelBtn').addEventListener('click', () => this.showContentDisplayMode(idea, handlers));
        body.querySelector('#ideaSaveContentBtn').addEventListener('click', () => {
            const content = body.querySelector('#ideaContentEditor').value;
            handlers.onSaveContent(content);
        });
    },

    flashSaveStatus(message = 'Saved!') {
        const status = document.getElementById('ideaSaveStatus');
        if (!status) return;
        status.textContent = message;
        status.style.color = '#8b7cff';
        setTimeout(() => {
            status.textContent = '';
        }, 1800);
    },

    // =========================================================
    // ADD IDEA MODAL — quick create (title, category, status only;
    // content and tagging happen inside the opened idea)
    // =========================================================
    getFormData() {
        const els = this.elements;
        return {
            id: els.idInput?.value ? Number(els.idInput.value) : null,
            title: els.titleInput?.value.trim() || '',
            category: els.categorySelect?.value || 'Other',
            status: els.statusSelect?.value || 'New'
        };
    },

    openModal() {
        const els = this.elements;
        this.clearForm();
        document.getElementById('ideaModalTitle').textContent = 'Add Idea';
        els.modal.style.display = 'flex';
        els.titleInput?.focus();
    },

    closeModal() {
        this.elements.modal.style.display = 'none';
        this.clearForm();
    },

    clearForm() {
        const els = this.elements;
        if (els.idInput) els.idInput.value = '';
        if (els.titleInput) els.titleInput.value = '';
        if (els.categorySelect) els.categorySelect.value = 'Plot Twist';
        if (els.statusSelect) els.statusSelect.value = 'New';
    }
};
