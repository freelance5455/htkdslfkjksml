import { storyService } from '../../workspace/story/storyService.js';
import { createId } from '../../shared/id.js';

export const ideaService = {
    getIdeas() {
        const story = storyService.getCurrentStory();
        return story ? (story.ideas || []) : [];
    },

    getIdeaById(id) {
        return this.getIdeas().find(i => i.id === id) || null;
    },

    addIdea(data) {
        const story = storyService.getCurrentStory();
        if (!story) return null;
        if (!story.ideas) story.ideas = [];

        const newIdea = {
            id: createId(),
            title: data.title,
            content: data.content || '',
            category: data.category || 'Other',
            status: data.status || 'New',
            characterIds: data.characterIds || [],
            locationIds: data.locationIds || [],
            factionIds: data.factionIds || [],
            chapterIds: data.chapterIds || [],
            arcIds: data.arcIds || [],
            createdAt: Date.now()
        };

        story.ideas.push(newIdea);
        storyService.updateStoryDetails({});
        return newIdea;
    },

    updateIdea(id, updatedData) {
        const story = storyService.getCurrentStory();
        if (!story || !story.ideas) return false;

        const index = story.ideas.findIndex(i => i.id === id);
        if (index === -1) return false;

        story.ideas[index] = { ...story.ideas[index], ...updatedData };
        storyService.updateStoryDetails({});
        return true;
    },

    deleteIdea(id) {
        const story = storyService.getCurrentStory();
        if (!story || !story.ideas) return false;

        story.ideas = story.ideas.filter(i => i.id !== id);

        // Cascade cleanup: unlink this idea from any Story Map boxes that referenced it
        if (story.storyMap && story.storyMap.boxes) {
            story.storyMap.boxes.forEach(box => {
                if (box.links && box.links.ideas) {
                    box.links.ideas = box.links.ideas.filter(iid => iid !== id);
                }
            });
        }

        storyService.updateStoryDetails({});
        return true;
    },

    searchIdeas(query) {
        const ideas = this.getIdeas();
        const q = (query || '').trim().toLowerCase();
        if (!q) return ideas;
        return ideas.filter(i =>
            i.title.toLowerCase().includes(q) ||
            (i.content || '').toLowerCase().includes(q) ||
            (i.category || '').toLowerCase().includes(q)
        );
    }
};
