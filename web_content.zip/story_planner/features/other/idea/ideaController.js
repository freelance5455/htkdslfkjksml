import { ideaService } from './ideaService.js';
import { ideaUi } from './ideaUi.js';
import { storyService } from '../../workspace/story/storyService.js';
import { chapterService } from '../../workspace/chapter/chapterService.js';
import { arcService } from '../../workspace/arc/arcService.js';
import { locationService } from '../../worldbuilding/location/locationService.js';
import { factionService } from '../../worldbuilding/faction/factionService.js';

let currentSearchQuery = '';

function getCharacters() {
    const story = storyService.getCurrentStory();
    return story ? (story.characters || []) : [];
}

function getRefData() {
    return {
        characters: getCharacters(),
        locations: locationService.getLocations(),
        factions: factionService.getFactions(),
        chapters: chapterService.getChapters(),
        arcs: arcService.getArcs()
    };
}

export function initIdeaFeature() {
    attachEventListeners();
}

// Allows other features (e.g. the Story Map) to jump straight into an idea's detail view.
export function openIdeaById(id) {
    handleOpenIdea(id);
}

export function loadIdeasTab() {
    currentSearchQuery = '';
    const els = ideaUi.elements;
    if (els.searchInput) els.searchInput.value = '';
    ideaUi.showListView();
    renderList();
}

function renderList() {
    const ideas = ideaService.searchIdeas(currentSearchQuery);
    ideaUi.renderIdeaGrid(ideas, {
        onOpen: handleOpenIdea,
        onDelete: handleDeleteIdea
    });
}

function handleOpenIdea(id) {
    ideaUi.showDetailView();
    renderDetail(id);
}

function renderDetail(id) {
    const idea = ideaService.getIdeaById(id);
    if (!idea) return;

    ideaUi.renderIdeaDetail(idea, getRefData(), {
        onBack: () => {
            ideaUi.showListView();
            renderList();
        },
        onDelete: handleDeleteIdea,
        onChangeCategory: (value) => {
            ideaService.updateIdea(id, { category: value });
        },
        onChangeStatus: (value) => {
            ideaService.updateIdea(id, { status: value });
        },
        onSaveTitle: (newTitle) => {
            ideaService.updateIdea(id, { title: newTitle });
            renderDetail(id);
            renderList();
        },
        onSaveContent: (content) => {
            ideaService.updateIdea(id, { content });
            renderDetail(id);
        },
        onManageTags: handleManageTags
    });
}

function handleManageTags(idea) {
    ideaUi.openTagModal(idea, getRefData());

    const els = ideaUi.elements;
    const onSave = () => {
        const tagData = ideaUi.readTagModal();
        ideaService.updateIdea(idea.id, tagData);
        ideaUi.closeTagModal();
        renderDetail(idea.id);
        cleanup();
    };
    const onCancel = () => {
        ideaUi.closeTagModal();
        cleanup();
    };
    function cleanup() {
        els.tagSaveBtn.removeEventListener('click', onSave);
        els.tagCancelBtn.removeEventListener('click', onCancel);
    }
    els.tagSaveBtn.addEventListener('click', onSave);
    els.tagCancelBtn.addEventListener('click', onCancel);
}

function handleDeleteIdea(id) {
    if (!confirm('Delete this idea? This cannot be undone.')) return;
    ideaService.deleteIdea(id);
    ideaUi.showListView();
    renderList();
}

function handleSaveIdea(e) {
    e.preventDefault();
    const formData = ideaUi.getFormData();

    if (!formData.title) {
        alert('Please enter an idea title.');
        return;
    }

    ideaService.addIdea(formData);
    ideaUi.closeModal();
    renderList();
}

function attachEventListeners() {
    const els = ideaUi.elements;

    if (els.addBtn) els.addBtn.addEventListener('click', () => ideaUi.openModal());
    if (els.cancelBtn) els.cancelBtn.addEventListener('click', () => ideaUi.closeModal());
    if (els.form) els.form.addEventListener('submit', handleSaveIdea);
    if (els.searchInput) {
        els.searchInput.addEventListener('input', (e) => {
            currentSearchQuery = e.target.value;
            renderList();
        });
    }
}
