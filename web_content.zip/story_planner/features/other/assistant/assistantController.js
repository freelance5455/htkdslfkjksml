import { storyService } from '../../workspace/story/storyService.js';

const input = () => document.getElementById('assistantQueryInput');
const messagesEl = () => document.getElementById('assistantMessages');

function asArray(value) {
    return Array.isArray(value) ? value : [];
}

function splitList(text) {
    return (text || '')
        .split(',')
        .map(part => part.trim())
        .filter(Boolean);
}

// Turns a free-text, comma-separated field (e.g. character.arcs, a plain
// string like "The Fall of the North") into entries — linking each piece
// to a real entity when its text matches one, so free text becomes
// clickable wherever possible instead of staying plain.
function freeTextEntries(text, matchAgainst, type) {
    return splitList(text).map(label => {
        const match = asArray(matchAgainst).find(candidate => {
            const name = candidate.title || candidate.name;
            return name && label.toLowerCase().includes(name.trim().toLowerCase());
        });
        return match ? toEntry(label, type, match.id) : label;
    });
}

// An "entry" is either a plain string (not clickable) or an object
// { label, type, id } that renders as a clickable link to that entity's
// full profile. toEntry() builds the latter.
function toEntry(label, type, id) {
    return { label, type, id };
}

function entryLabel(entry) {
    return typeof entry === 'string' ? entry : entry.label;
}

function mergeUnique(...lists) {
    const seen = new Set();
    const result = [];
    lists.flat().forEach(entry => {
        const key = entryLabel(entry).toLowerCase();
        if (!seen.has(key)) {
            seen.add(key);
            result.push(entry);
        }
    });
    return result;
}

function matches(item, query) {
    return Object.values(item).some(value => typeof value === 'string' && value.toLowerCase().includes(query));
}

// ============================================================
// PER-CHARACTER CONNECTIONS (Family / Friends / Companions / Rivals /
// Factions / Lore added from the character detail page). This data is
// saved separately from the story's own character record — under its own
// localStorage key per character — so it has to be read on its own here,
// or entries added there (like a "wife" in Family) never show up in the
// assistant's answers.
// ============================================================
function getCharacterConnections(characterId) {
    if (!characterId) return null;
    try {
        const raw = localStorage.getItem(`storyplanner_character_connections_${characterId}`);
        if (!raw) return null;
        const data = JSON.parse(raw);
        return data && typeof data === 'object' ? data : null;
    } catch (e) {
        return null;
    }
}

function describeConnectionItem(item) {
    if (!item) return '';
    return item.tag ? `${item.name || 'Unnamed'} — ${item.tag}` : (item.name || 'Unnamed');
}

// Family/friends/companions/rivals/factions entries are free text typed on
// the character page, but if the name matches an existing character or
// faction in the story, link straight to that profile.
function connectionEntry(item, story, matchAgainst, type) {
    const label = describeConnectionItem(item);
    if (!item?.name) return label;
    const match = asArray(matchAgainst).find(candidate => {
        const candidateName = candidate.name || candidate.title;
        return candidateName && candidateName.trim().toLowerCase() === item.name.trim().toLowerCase();
    });
    return match ? toEntry(label, type, match.id) : label;
}

// ============================================================
// CHAT RENDERING
// ============================================================
function addMessage(role, content) {
    const list = messagesEl();
    if (!list) return null;

    const row = document.createElement('div');
    row.className = `chat-msg ${role} chat-msg-enter`;

    const avatar = document.createElement('div');
    avatar.className = 'chat-avatar';
    avatar.textContent = role === 'user' ? '🖊' : '✦';

    const bubble = document.createElement('div');
    bubble.className = 'chat-bubble';
    if (typeof content === 'string') {
        const p = document.createElement('p');
        p.textContent = content;
        bubble.appendChild(p);
    } else {
        bubble.appendChild(content);
    }

    row.append(avatar, bubble);
    list.appendChild(row);
    list.scrollTop = list.scrollHeight;
    return row;
}

// Shows a bouncing-dots "typing" bubble, used while the assistant "thinks"
// before its reply is revealed.
function addTypingIndicator() {
    const list = messagesEl();
    if (!list) return null;

    const row = document.createElement('div');
    row.className = 'chat-msg assistant chat-msg-enter';

    const avatar = document.createElement('div');
    avatar.className = 'chat-avatar';
    avatar.textContent = '✦';

    const bubble = document.createElement('div');
    bubble.className = 'chat-bubble chat-typing';
    bubble.innerHTML = '<span></span><span></span><span></span>';

    row.append(avatar, bubble);
    list.appendChild(row);
    list.scrollTop = list.scrollHeight;
    return row;
}

// Queues an assistant reply: show the typing indicator briefly, then swap
// it out for the real content (which animates in on its own).
function sendAssistantReply(content) {
    const list = messagesEl();
    if (!list) return;

    const typingRow = addTypingIndicator();
    const thinkTime = 450 + Math.random() * 400;

    setTimeout(() => {
        typingRow?.remove();
        addMessage('assistant', content);
    }, thinkTime);
}

function makeSection(title, entries, emptyMessage = 'None yet.') {
    const section = document.createElement('section');
    section.className = 'assistant-result-section';
    const heading = document.createElement('h3');
    heading.textContent = title;
    section.appendChild(heading);
    if (!entries.length) {
        const empty = document.createElement('p');
        empty.className = 'assistant-empty';
        empty.textContent = emptyMessage;
        section.appendChild(empty);
        return section;
    }
    const list = document.createElement('ul');
    entries.forEach(entry => {
        const row = document.createElement('li');
        if (typeof entry === 'object' && entry.type && entry.id) {
            const link = document.createElement('button');
            link.type = 'button';
            link.className = 'assistant-entity-link';
            link.dataset.entityType = entry.type;
            link.dataset.entityId = entry.id;
            link.textContent = entry.label;
            row.appendChild(link);
        } else {
            row.textContent = entryLabel(entry);
        }
        list.appendChild(row);
    });
    section.appendChild(list);
    return section;
}

function buildSimpleAnswer(title, text) {
    const container = document.createElement('div');
    const heading = document.createElement('h2');
    heading.textContent = title;
    const body = document.createElement('p');
    body.textContent = text;
    container.append(heading, body);
    return container;
}

// ============================================================
// ENTITY PROFILE BUILDERS — full description & linked data,
// shown when the user picks a name from a list of many.
// ============================================================
function findCharacterMatch(story, query) {
    const characters = asArray(story.characters).filter(c => c.name && c.name.trim());
    if (!characters.length) return null;

    const q = query.trim().toLowerCase();
    if (!q) return null;

    const exact = characters.find(c => c.name.trim().toLowerCase() === q);
    if (exact) return exact;

    const candidates = characters.filter(c => q.includes(c.name.trim().toLowerCase()));
    if (!candidates.length) return null;

    candidates.sort((a, b) => b.name.length - a.name.length);
    return candidates[0];
}

function buildRelationshipLines(character, story) {
    if (!character.relationships) return [];
    const others = asArray(story.characters).filter(c => c.id !== character.id && c.name);

    return splitList(character.relationships).map(entry => {
        const linked = others.find(c => entry.toLowerCase().includes(c.name.toLowerCase()));
        return linked ? toEntry(entry, 'character', linked.id) : entry;
    });
}

function buildCharacterProfile(story, character) {
    const container = document.createElement('div');

    const heading = document.createElement('h2');
    heading.textContent = character.role ? `${character.name} — ${character.role}` : character.name;
    container.appendChild(heading);

    const introBits = [];
    if (character.archetype) introBits.push(`Archetype: ${character.archetype}`);
    if (character.goal) introBits.push(`Goal: ${character.goal}`);
    if (introBits.length) {
        const intro = document.createElement('p');
        intro.textContent = introBits.join(' · ');
        container.appendChild(intro);
    }

    if (character.description) {
        const bio = document.createElement('p');
        bio.textContent = character.description;
        container.appendChild(bio);
    }

    const chapters = asArray(story.chapters).filter(ch => asArray(ch.characterIds).includes(character.id));
    const chapterIdSet = new Set(chapters.map(ch => ch.id));

    const linkedArcs = asArray(story.arcs).filter(arc => asArray(arc.chapterIds).some(cid => chapterIdSet.has(cid)));
    const arcEntries = mergeUnique(
        linkedArcs.map(a => toEntry(a.title || 'Untitled arc', 'arc', a.id)),
        freeTextEntries(character.arcs, story.arcs, 'arc')
    );

    // Connections (family/friends/companions/rivals/factions/lore) saved
    // from the character detail page live in their own localStorage record.
    const connections = getCharacterConnections(character.id);

    const connectedLoreIds = new Set(asArray(connections?.lore).map(String));
    const linkedLore = asArray(story.lore).filter(l => asArray(l.characterIds).includes(character.id) || connectedLoreIds.has(String(l.id)));
    const loreEntries = mergeUnique(
        linkedLore.map(l => toEntry(l.title || 'Untitled lore', 'lore', l.id)),
        freeTextEntries(character.lore, story.lore, 'lore')
    );

    const linkedFactions = asArray(story.factions).filter(f => asArray(f.characterIds).includes(character.id));
    const factionEntries = mergeUnique(
        linkedFactions.map(f => toEntry(f.title || 'Untitled faction', 'faction', f.id)),
        asArray(connections?.factions).map(item => connectionEntry(item, story, story.factions, 'faction'))
    );

    const linkedLocations = asArray(story.locations).filter(loc => asArray(loc.chapterIds).some(cid => chapterIdSet.has(cid)));

    const linkedEvents = asArray(story.timeline)
        .filter(ev => asArray(ev.characterIds).includes(character.id))
        .sort((a, b) => Number(a.order || 0) - Number(b.order || 0));

    const familyEntries = asArray(connections?.family).map(item => connectionEntry(item, story, story.characters, 'character'));
    const friendEntries = asArray(connections?.friends).map(item => connectionEntry(item, story, story.characters, 'character'));
    const companionEntries = asArray(connections?.companions).map(item => connectionEntry(item, story, story.characters, 'character'));
    const rivalEntries = asArray(connections?.rivals).map(item => connectionEntry(item, story, story.characters, 'character'));
    const otherRelationshipLines = buildRelationshipLines(character, story);

    container.appendChild(makeSection('Chapters', chapters.map(c => toEntry(c.title || 'Untitled chapter', 'chapter', c.id)), 'Not tagged in any chapter yet.'));
    container.appendChild(makeSection('Story arcs', arcEntries, 'No arcs linked yet.'));
    container.appendChild(makeSection('Connected lore', loreEntries, 'No lore connected yet.'));
    container.appendChild(makeSection('Factions', factionEntries, 'Not part of any faction yet.'));
    container.appendChild(makeSection('Locations', linkedLocations.map(l => toEntry(l.title || 'Untitled location', 'location', l.id)), 'No locations linked yet.'));
    container.appendChild(makeSection('Timeline events', linkedEvents.map(e => toEntry(`${e.date ? `${e.date}: ` : ''}${e.title || 'Untitled event'}`, 'event', e.id)), 'No timeline events yet.'));
    container.appendChild(makeSection('Family', familyEntries, 'No family members recorded yet.'));
    container.appendChild(makeSection('Friends', friendEntries, 'No friends recorded yet.'));
    container.appendChild(makeSection('Companions', companionEntries, 'No companions recorded yet.'));
    container.appendChild(makeSection('Rivals', rivalEntries, 'No rivals recorded yet.'));
    if (otherRelationshipLines.length) {
        container.appendChild(makeSection('Other relationships', otherRelationshipLines));
    }

    if (character.beliefs) {
        container.appendChild(makeSection('Beliefs & values', splitList(character.beliefs), 'None recorded.'));
    }

    return container;
}

function buildChapterProfile(story, chapter) {
    const container = document.createElement('div');
    const heading = document.createElement('h2');
    heading.textContent = chapter.title || 'Untitled chapter';
    container.appendChild(heading);

    if (chapter.content) {
        const body = document.createElement('p');
        body.textContent = chapter.content;
        container.appendChild(body);
    }

    const characters = asArray(story.characters).filter(c => asArray(chapter.characterIds).includes(c.id));
    const arcs = asArray(story.arcs).filter(a => asArray(a.chapterIds).includes(chapter.id));
    const locations = asArray(story.locations).filter(l => asArray(l.chapterIds).includes(chapter.id));
    const events = asArray(story.timeline)
        .filter(e => asArray(e.chapterIds).includes(chapter.id))
        .sort((a, b) => Number(a.order || 0) - Number(b.order || 0));
    const ideas = asArray(story.ideas).filter(i => asArray(i.chapterIds).includes(chapter.id));

    container.appendChild(makeSection('Characters', characters.map(c => toEntry(c.name || 'Unnamed', 'character', c.id)), 'No characters tagged yet.'));
    container.appendChild(makeSection('Story arcs', arcs.map(a => toEntry(a.title || 'Untitled arc', 'arc', a.id)), 'Not part of an arc yet.'));
    container.appendChild(makeSection('Locations', locations.map(l => toEntry(l.title || 'Untitled location', 'location', l.id)), 'No locations linked yet.'));
    container.appendChild(makeSection('Timeline events', events.map(e => toEntry(`${e.date ? `${e.date}: ` : ''}${e.title || 'Untitled event'}`, 'event', e.id)), 'No timeline events yet.'));
    container.appendChild(makeSection('Related ideas', ideas.map(i => toEntry(i.title || 'Untitled idea', 'idea', i.id)), 'No ideas linked yet.'));

    return container;
}

function buildArcProfile(story, arc) {
    const container = document.createElement('div');
    const heading = document.createElement('h2');
    heading.textContent = arc.title || 'Untitled arc';
    container.appendChild(heading);

    if (arc.description) {
        const body = document.createElement('p');
        body.textContent = arc.description;
        container.appendChild(body);
    }

    const chapters = asArray(story.chapters).filter(c => asArray(arc.chapterIds).includes(c.id));
    const chapterIdSet = new Set(chapters.map(c => c.id));
    const characterIds = new Set(chapters.flatMap(c => asArray(c.characterIds)));
    const characters = asArray(story.characters).filter(c => characterIds.has(c.id));
    const ideas = asArray(story.ideas).filter(i => asArray(i.arcIds).includes(arc.id));
    const locations = asArray(story.locations).filter(l => asArray(l.chapterIds).some(cid => chapterIdSet.has(cid)));

    container.appendChild(makeSection('Chapters', chapters.map(c => toEntry(c.title || 'Untitled chapter', 'chapter', c.id)), 'No chapters linked yet.'));
    container.appendChild(makeSection('Characters', characters.map(c => toEntry(c.name || 'Unnamed', 'character', c.id)), 'No characters appear in this arc yet.'));
    container.appendChild(makeSection('Locations', locations.map(l => toEntry(l.title || 'Untitled location', 'location', l.id)), 'No locations linked yet.'));
    container.appendChild(makeSection('Related ideas', ideas.map(i => toEntry(i.title || 'Untitled idea', 'idea', i.id)), 'No ideas linked yet.'));

    return container;
}

function buildFactionProfile(story, faction) {
    const container = document.createElement('div');
    const heading = document.createElement('h2');
    heading.textContent = faction.title || 'Untitled faction';
    container.appendChild(heading);

    if (faction.description) {
        const body = document.createElement('p');
        body.textContent = faction.description;
        container.appendChild(body);
    }

    const characters = asArray(story.characters).filter(c => asArray(faction.characterIds).includes(c.id));
    const locations = asArray(story.locations).filter(l => asArray(faction.locationIds).includes(l.id));
    const ideas = asArray(story.ideas).filter(i => asArray(i.factionIds).includes(faction.id));

    container.appendChild(makeSection('Members', characters.map(c => toEntry(c.name || 'Unnamed', 'character', c.id)), 'No members added yet.'));
    container.appendChild(makeSection('Locations', locations.map(l => toEntry(l.title || 'Untitled location', 'location', l.id)), 'No locations linked yet.'));
    container.appendChild(makeSection('Related ideas', ideas.map(i => toEntry(i.title || 'Untitled idea', 'idea', i.id)), 'No ideas linked yet.'));

    return container;
}

function buildLocationProfile(story, location) {
    const container = document.createElement('div');
    const heading = document.createElement('h2');
    heading.textContent = location.title || 'Untitled location';
    container.appendChild(heading);

    if (location.description) {
        const body = document.createElement('p');
        body.textContent = location.description;
        container.appendChild(body);
    }

    const chapters = asArray(story.chapters).filter(c => asArray(location.chapterIds).includes(c.id));
    const factions = asArray(story.factions).filter(f => asArray(f.locationIds).includes(location.id));
    const lore = asArray(story.lore).filter(l => asArray(l.locationIds).includes(location.id));
    const ideas = asArray(story.ideas).filter(i => asArray(i.locationIds).includes(location.id));

    container.appendChild(makeSection('Chapters', chapters.map(c => toEntry(c.title || 'Untitled chapter', 'chapter', c.id)), 'Not featured in a chapter yet.'));
    container.appendChild(makeSection('Factions', factions.map(f => toEntry(f.title || 'Untitled faction', 'faction', f.id)), 'No factions based here yet.'));
    container.appendChild(makeSection('Connected lore', lore.map(l => toEntry(l.title || 'Untitled lore', 'lore', l.id)), 'No lore connected yet.'));
    container.appendChild(makeSection('Related ideas', ideas.map(i => toEntry(i.title || 'Untitled idea', 'idea', i.id)), 'No ideas linked yet.'));

    return container;
}

function buildLoreProfile(story, lore) {
    const container = document.createElement('div');
    const heading = document.createElement('h2');
    heading.textContent = lore.title || 'Untitled lore';
    container.appendChild(heading);

    if (lore.description) {
        const body = document.createElement('p');
        body.textContent = lore.description;
        container.appendChild(body);
    }

    const characters = asArray(story.characters).filter(c => asArray(lore.characterIds).includes(c.id));
    const locations = asArray(story.locations).filter(l => asArray(lore.locationIds).includes(l.id));

    container.appendChild(makeSection('Characters', characters.map(c => toEntry(c.name || 'Unnamed', 'character', c.id)), 'No characters connected yet.'));
    container.appendChild(makeSection('Locations', locations.map(l => toEntry(l.title || 'Untitled location', 'location', l.id)), 'No locations connected yet.'));

    return container;
}

function buildIdeaProfile(story, idea) {
    const container = document.createElement('div');
    const heading = document.createElement('h2');
    heading.textContent = idea.title || 'Untitled idea';
    container.appendChild(heading);

    const metaBits = [];
    if (idea.category) metaBits.push(idea.category);
    if (idea.status) metaBits.push(idea.status);
    if (metaBits.length) {
        const meta = document.createElement('p');
        meta.textContent = metaBits.join(' · ');
        container.appendChild(meta);
    }

    if (idea.content) {
        const body = document.createElement('p');
        body.textContent = idea.content;
        container.appendChild(body);
    }

    const characters = asArray(story.characters).filter(c => asArray(idea.characterIds).includes(c.id));
    const locations = asArray(story.locations).filter(l => asArray(idea.locationIds).includes(l.id));
    const factions = asArray(story.factions).filter(f => asArray(idea.factionIds).includes(f.id));
    const chapters = asArray(story.chapters).filter(c => asArray(idea.chapterIds).includes(c.id));
    const arcs = asArray(story.arcs).filter(a => asArray(idea.arcIds).includes(a.id));

    container.appendChild(makeSection('Characters', characters.map(c => toEntry(c.name || 'Unnamed', 'character', c.id)), 'No characters linked yet.'));
    container.appendChild(makeSection('Chapters', chapters.map(c => toEntry(c.title || 'Untitled chapter', 'chapter', c.id)), 'No chapters linked yet.'));
    container.appendChild(makeSection('Story arcs', arcs.map(a => toEntry(a.title || 'Untitled arc', 'arc', a.id)), 'No arcs linked yet.'));
    container.appendChild(makeSection('Locations', locations.map(l => toEntry(l.title || 'Untitled location', 'location', l.id)), 'No locations linked yet.'));
    container.appendChild(makeSection('Factions', factions.map(f => toEntry(f.title || 'Untitled faction', 'faction', f.id)), 'No factions linked yet.'));

    return container;
}

function buildNoteProfile(story, note) {
    const container = document.createElement('div');
    const heading = document.createElement('h2');
    heading.textContent = note.title || 'Untitled note';
    container.appendChild(heading);

    if (note.pinned) {
        const pin = document.createElement('p');
        pin.textContent = 'Pinned';
        container.appendChild(pin);
    }

    if (note.content) {
        const body = document.createElement('p');
        body.textContent = note.content;
        container.appendChild(body);
    }

    return container;
}

function buildEventProfile(story, event) {
    const container = document.createElement('div');
    const heading = document.createElement('h2');
    heading.textContent = event.date ? `${event.date}: ${event.title || 'Untitled event'}` : (event.title || 'Untitled event');
    container.appendChild(heading);

    if (event.description) {
        const body = document.createElement('p');
        body.textContent = event.description;
        container.appendChild(body);
    }

    const characters = asArray(story.characters).filter(c => asArray(event.characterIds).includes(c.id));
    const chapters = asArray(story.chapters).filter(c => asArray(event.chapterIds).includes(c.id));

    container.appendChild(makeSection('Characters involved', characters.map(c => toEntry(c.name || 'Unnamed', 'character', c.id)), 'No characters tagged yet.'));
    container.appendChild(makeSection('Chapters', chapters.map(c => toEntry(c.title || 'Untitled chapter', 'chapter', c.id)), 'No chapters linked yet.'));

    return container;
}

// Registry mapping an entity "type" (used in data-entity-type attributes)
// to how to find it in the story and how to render its full profile.
const ENTITY_CONFIG = {
    character: {
        list: story => asArray(story.characters),
        label: item => item.name || 'Unnamed character',
        build: buildCharacterProfile
    },
    chapter: {
        list: story => asArray(story.chapters),
        label: item => item.title || 'Untitled chapter',
        build: buildChapterProfile
    },
    arc: {
        list: story => asArray(story.arcs),
        label: item => item.title || 'Untitled arc',
        build: buildArcProfile
    },
    faction: {
        list: story => asArray(story.factions),
        label: item => item.title || 'Untitled faction',
        build: buildFactionProfile
    },
    location: {
        list: story => asArray(story.locations),
        label: item => item.title || 'Untitled location',
        build: buildLocationProfile
    },
    lore: {
        list: story => asArray(story.lore),
        label: item => item.title || 'Untitled lore',
        build: buildLoreProfile
    },
    idea: {
        list: story => asArray(story.ideas),
        label: item => item.title || 'Untitled idea',
        build: buildIdeaProfile
    },
    note: {
        list: story => asArray(story.notes),
        label: item => item.title || 'Untitled note',
        build: buildNoteProfile
    },
    event: {
        list: story => asArray(story.timeline),
        label: item => item.title || 'Untitled event',
        build: buildEventProfile
    }
};

function openEntity(type, id) {
    const story = storyService.getCurrentStory();
    const config = ENTITY_CONFIG[type];
    if (!story || !config) return;

    // dataset values are always strings, but entity ids are numbers
    // (see shared/id.js createId), so compare as strings on both sides.
    const item = config.list(story).find(entry => String(entry.id) === String(id));
    if (!item) return;

    addMessage('user', config.label(item));
    sendAssistantReply(config.build(story, item));
}

// ============================================================
// GENERAL STORY QUERIES
// ============================================================
function buildStoryRecap(story) {
    const container = document.createElement('div');
    const heading = document.createElement('h2');
    heading.textContent = `${story.name || 'Untitled story'} — recap`;
    const intro = document.createElement('p');
    intro.textContent = story.synopsis || story.logline || story.description || 'Add a description or synopsis in the Story tab to create a fuller recap.';
    container.append(heading, intro);
    container.appendChild(makeSection('Story at a glance', [
        `${asArray(story.characters).length} character(s)`,
        `${asArray(story.chapters).length} chapter(s)`,
        `${asArray(story.arcs).length} arc(s)`,
        `${asArray(story.locations).length} location(s)`,
        `${asArray(story.lore).length} lore entry/entries`,
        `${asArray(story.factions).length} faction(s)`,
        `${asArray(story.timeline).length} timeline event(s)`
    ]));

    // Many stories have lots of characters/chapters/arcs — show names only,
    // and let the user pick one to see its full description and data.
    const characters = asArray(story.characters).map(c => toEntry(c.name ? `${c.name}${c.role ? ` — ${c.role}` : ''}` : 'Unnamed', 'character', c.id));
    container.appendChild(makeSection('Characters', characters, 'No characters have been added yet.'));

    const chapters = asArray(story.chapters).map(c => toEntry(c.title || 'Untitled chapter', 'chapter', c.id));
    container.appendChild(makeSection('Chapters', chapters, 'No chapters have been added yet.'));

    const arcs = asArray(story.arcs).map(a => toEntry(a.title || 'Untitled arc', 'arc', a.id));
    container.appendChild(makeSection('Story arcs', arcs, 'No arcs have been added yet.'));

    return container;
}

function buildLooseEnds(story) {
    const container = document.createElement('div');
    const heading = document.createElement('h2');
    heading.textContent = 'Possible loose ends';
    container.appendChild(heading);
    const newIdeas = asArray(story.ideas).filter(idea => idea.status === 'New').map(idea => toEntry(`Idea: ${idea.title || 'Untitled'}`, 'idea', idea.id));
    const unlinkedIdeas = asArray(story.ideas)
        .filter(idea => !['characterIds', 'locationIds', 'factionIds', 'chapterIds', 'arcIds'].some(key => asArray(idea[key]).length))
        .map(idea => toEntry(`Idea with no links: ${idea.title || 'Untitled'}`, 'idea', idea.id));
    const untaggedLore = asArray(story.lore)
        .filter(entry => !asArray(entry.characterIds).length && !asArray(entry.locationIds).length)
        .map(entry => toEntry(`Lore with no tags: ${entry.title || 'Untitled'}`, 'lore', entry.id));
    const chaptersWithoutContent = asArray(story.chapters)
        .filter(chapter => !(chapter.content || '').trim())
        .map(chapter => toEntry(`Chapter without content: ${chapter.title || 'Untitled'}`, 'chapter', chapter.id));
    const all = [...newIdeas, ...unlinkedIdeas, ...untaggedLore, ...chaptersWithoutContent];
    container.appendChild(makeSection('Items to revisit', all, 'Nothing stands out right now — nice work.'));
    return container;
}

function buildTimelineRecap(story) {
    const events = [...asArray(story.timeline)].sort((a, b) => Number(a.order || 0) - Number(b.order || 0));
    const lines = events.map(event => toEntry(`${event.date ? `${event.date}: ` : ''}${event.title || 'Untitled event'}`, 'event', event.id));
    const container = document.createElement('div');
    const heading = document.createElement('h2');
    heading.textContent = 'Timeline recap';
    container.appendChild(heading);
    container.appendChild(makeSection('Events in order', lines, 'No timeline events have been added yet.'));
    return container;
}

function buildSearchResults(story, query) {
    const groups = [
        ['Characters', asArray(story.characters), item => `${item.name || 'Unnamed'}${item.role ? ` — ${item.role}` : ''}`, 'character'],
        ['Chapters', asArray(story.chapters), item => item.title || 'Untitled chapter', 'chapter'],
        ['Locations', asArray(story.locations), item => item.title || 'Untitled location', 'location'],
        ['Lore', asArray(story.lore), item => item.title || 'Untitled lore', 'lore'],
        ['Factions', asArray(story.factions), item => item.title || 'Untitled faction', 'faction'],
        ['Ideas', asArray(story.ideas), item => item.title || 'Untitled idea', 'idea'],
        ['Notes', asArray(story.notes), item => item.title || 'Untitled note', 'note']
    ];
    const container = document.createElement('div');
    const heading = document.createElement('h2');
    heading.textContent = `Results for "${query}"`;
    container.appendChild(heading);
    let count = 0;
    groups.forEach(([name, items, label, type]) => {
        const found = items.filter(item => matches(item, query));
        count += found.length;
        if (found.length) container.appendChild(makeSection(name, found.map(item => toEntry(label(item), type, item.id))));
    });
    if (!count) {
        const empty = document.createElement('p');
        empty.className = 'assistant-empty';
        empty.textContent = 'No matching story information was found. Try a character, place, or topic name.';
        container.appendChild(empty);
    }
    return container;
}

// ============================================================
// "SHOW ME ALL ___" — plain keyword listings
// Typing a bare entity keyword ("locations", "character", "arcs"...) or
// "all" lists every item of that kind (or of every kind) by name only,
// each one clickable to open its full content and everything tagged to it.
// ============================================================
const ENTITY_LIST_CONFIG = [
    {
        type: 'character', keywords: ['character', 'characters'], sectionTitle: 'Characters',
        list: story => asArray(story.characters),
        label: item => item.name ? `${item.name}${item.role ? ` — ${item.role}` : ''}` : 'Unnamed'
    },
    {
        type: 'chapter', keywords: ['chapter', 'chapters'], sectionTitle: 'Chapters',
        list: story => asArray(story.chapters),
        label: item => item.title || 'Untitled chapter'
    },
    {
        type: 'arc', keywords: ['arc', 'arcs'], sectionTitle: 'Story arcs',
        list: story => asArray(story.arcs),
        label: item => item.title || 'Untitled arc'
    },
    {
        type: 'faction', keywords: ['faction', 'factions'], sectionTitle: 'Factions',
        list: story => asArray(story.factions),
        label: item => item.title || 'Untitled faction'
    },
    {
        type: 'location', keywords: ['location', 'locations', 'place', 'places'], sectionTitle: 'Locations',
        list: story => asArray(story.locations),
        label: item => item.title || 'Untitled location'
    },
    {
        type: 'lore', keywords: ['lore'], sectionTitle: 'Lore',
        list: story => asArray(story.lore),
        label: item => item.title || 'Untitled lore'
    },
    {
        type: 'idea', keywords: ['idea', 'ideas'], sectionTitle: 'Ideas',
        list: story => asArray(story.ideas),
        label: item => item.title || 'Untitled idea'
    },
    {
        type: 'note', keywords: ['note', 'notes'], sectionTitle: 'Notes',
        list: story => asArray(story.notes),
        label: item => item.title || 'Untitled note'
    },
    {
        type: 'event', keywords: ['event', 'events', 'timeline'], sectionTitle: 'Timeline events',
        list: story => [...asArray(story.timeline)].sort((a, b) => Number(a.order || 0) - Number(b.order || 0)),
        label: item => `${item.date ? `${item.date}: ` : ''}${item.title || 'Untitled event'}`
    }
];

// Words that don't change which entity type is being asked for, so they're
// stripped before matching — lets "show all locations", "my characters",
// "list the factions" etc. all resolve to the same plain keyword.
const LIST_QUERY_FILLER = /\b(show|list|display|view|see|give|get|me|what|are|is|tell|about|my|the|please|of|in|story|all)\b/g;

function matchEntityListKeyword(query) {
    if (!query) return null;
    const normalized = query.replace(LIST_QUERY_FILLER, ' ').replace(/\s+/g, ' ').trim();

    const config = ENTITY_LIST_CONFIG.find(cfg => cfg.keywords.includes(normalized));
    if (config) return config;

    // Bare "all" (with only filler words alongside it) lists everything.
    if (!normalized && /\ball\b/.test(query)) return 'all';

    return null;
}

function buildEntityListAnswer(story, config) {
    const container = document.createElement('div');
    const heading = document.createElement('h2');
    heading.textContent = config.sectionTitle;
    container.appendChild(heading);
    const items = config.list(story);
    container.appendChild(makeSection(
        config.sectionTitle,
        items.map(item => toEntry(config.label(item), config.type, item.id)),
        `No ${config.sectionTitle.toLowerCase()} have been added yet.`
    ));
    return container;
}

function buildAllEntitiesAnswer(story) {
    const container = document.createElement('div');
    const heading = document.createElement('h2');
    heading.textContent = 'Everything in this story';
    const intro = document.createElement('p');
    intro.textContent = 'Pick any name below to see its full content and everything tagged to it.';
    container.append(heading, intro);
    ENTITY_LIST_CONFIG.forEach(config => {
        const items = config.list(story);
        container.appendChild(makeSection(
            config.sectionTitle,
            items.map(item => toEntry(config.label(item), config.type, item.id)),
            `No ${config.sectionTitle.toLowerCase()} have been added yet.`
        ));
    });
    return container;
}

// ============================================================
// DISAMBIGUATION — a typed phrase can honestly mean more than one thing.
// "predators event" might be the title of a lore entry AND the word
// "event" is also the generic keyword for the timeline. Rather than
// silently guessing, collect every entity type where the phrase actually
// means something and — if there's more than one — ask which one.
// ============================================================
function titleOf(item) {
    return (item.title || item.name || '').trim();
}

// Loose enough to catch "Predators Event" vs "predators event", strict
// enough that short titles ("Az", "Do") don't swallow unrelated queries —
// those still have to match exactly.
function titleMatchesQuery(item, query) {
    const title = titleOf(item).toLowerCase();
    if (!title) return false;
    if (title === query) return true;
    if (title.length < 3 || query.length < 3) return false;
    return title.includes(query) || query.includes(title);
}

// Finds every ENTITY_LIST_CONFIG type where the typed phrase could
// plausibly be pointing: any type with a matching title (a chapter, arc,
// lore entry, etc. actually named that), plus — separately — "timeline
// event" whenever the phrase contains an event/timeline-ish keyword, since
// that's a real meaning too even when no single event's title matches.
function findAmbiguousCandidates(story, query) {
    const candidates = [];

    ENTITY_LIST_CONFIG.forEach(config => {
        const items = config.list(story).filter(item => titleMatchesQuery(item, query));
        if (items.length) {
            candidates.push({ type: config.type, sectionTitle: config.sectionTitle, config, items, byTitle: true });
        }
    });

    if (/(timeline|chronolog|event)/.test(query) && !candidates.some(c => c.type === 'event')) {
        const eventConfig = ENTITY_LIST_CONFIG.find(c => c.type === 'event');
        candidates.push({ type: 'event', sectionTitle: eventConfig.sectionTitle, config: eventConfig, items: eventConfig.list(story), byTitle: false });
    }

    return candidates;
}

function buildAmbiguityPrompt(rawQuery, candidates) {
    const container = document.createElement('div');
    const heading = document.createElement('h2');
    heading.textContent = `Which "${rawQuery}" do you mean?`;
    container.appendChild(heading);

    const intro = document.createElement('p');
    intro.textContent = 'That matches more than one thing — pick one:';
    container.appendChild(intro);

    const optionRow = document.createElement('div');
    optionRow.className = 'assistant-ambiguity-options';
    candidates.forEach(candidate => {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'assistant-ambiguity-btn';
        btn.dataset.ambiguityType = candidate.type;
        btn.dataset.ambiguityQuery = rawQuery;
        btn.textContent = candidate.sectionTitle;
        optionRow.appendChild(btn);
    });
    container.appendChild(optionRow);

    return container;
}

// Called when the user taps one of the disambiguation buttons above.
function resolveAmbiguity(type, rawQuery) {
    const story = storyService.getCurrentStory();
    const config = ENTITY_LIST_CONFIG.find(c => c.type === type);
    if (!story || !config) return;

    addMessage('user', config.sectionTitle);

    const query = (rawQuery || '').trim().toLowerCase();
    const items = config.list(story);
    const titleMatches = items.filter(item => titleMatchesQuery(item, query));

    if (titleMatches.length === 1 && ENTITY_CONFIG[type]) {
        sendAssistantReply(ENTITY_CONFIG[type].build(story, titleMatches[0]));
    } else if (titleMatches.length > 1) {
        sendAssistantReply(buildEntityListAnswer(story, { ...config, list: () => titleMatches }));
    } else if (type === 'event') {
        sendAssistantReply(buildTimelineRecap(story));
    } else {
        sendAssistantReply(buildEntityListAnswer(story, config));
    }
}

// ============================================================
// RESPOND
// ============================================================
const STRUCTURED_INTENT = /(summar|recap|overview|loose|unlinked|unused|unfinished|missing|timeline|chronolog)/;

function respond(rawQuery) {
    const trimmed = (rawQuery || '').trim();
    if (trimmed) addMessage('user', trimmed);

    const story = storyService.getCurrentStory();
    if (!story) {
        sendAssistantReply(buildSimpleAnswer('Choose a story first', 'Open a story from My Stories, then return here to ask about it.'));
        return;
    }

    const query = trimmed.toLowerCase();
    if (!query) {
        sendAssistantReply(buildSimpleAnswer('Ask about your story', 'Try “summarize my story”, “show loose ends”, “show timeline”, “all”, or a plain keyword like “locations” or “characters”.'));
        return;
    }

    const listMatch = matchEntityListKeyword(query);
    if (listMatch === 'all') {
        sendAssistantReply(buildAllEntitiesAnswer(story));
        return;
    }
    if (listMatch) {
        sendAssistantReply(buildEntityListAnswer(story, listMatch));
        return;
    }

    const ambiguousCandidates = findAmbiguousCandidates(story, query);
    if (ambiguousCandidates.length > 1) {
        sendAssistantReply(buildAmbiguityPrompt(trimmed, ambiguousCandidates));
        return;
    }

    const character = findCharacterMatch(story, query);
    if (character && !STRUCTURED_INTENT.test(query)) {
        sendAssistantReply(buildCharacterProfile(story, character));
        return;
    }

    if (/(summar|recap|overview)/.test(query)) {
        sendAssistantReply(buildStoryRecap(story));
    } else if (/(loose|unlinked|unused|unfinished|missing)/.test(query)) {
        sendAssistantReply(buildLooseEnds(story));
    } else if (/(timeline|chronolog|event)/.test(query)) {
        sendAssistantReply(buildTimelineRecap(story));
    } else {
        sendAssistantReply(buildSearchResults(story, query));
    }
}

export function initAssistantFeature() {
    const composer = document.getElementById('assistantComposer');
    composer?.addEventListener('submit', event => {
        event.preventDefault();
        const value = input()?.value || '';
        if (!value.trim()) return;
        respond(value);
        if (input()) {
            input().value = '';
            input().focus();
        }
    });

    // Quick suggestions live behind a single icon button next to the
    // input (instead of a permanent row of buttons) so the composer stays
    // compact on every screen size, phones included. Tapping the icon
    // opens a small popover above it; picking a suggestion or tapping
    // anywhere else closes it again.
    const quickToggle = document.getElementById('assistantQuickToggle');
    const quickPanel = document.getElementById('assistantQuickActions');

    function closeQuickActions() {
        if (!quickPanel || quickPanel.hidden) return;
        quickPanel.hidden = true;
        quickToggle?.setAttribute('aria-expanded', 'false');
    }

    function toggleQuickActions() {
        if (!quickPanel) return;
        const opening = quickPanel.hidden;
        quickPanel.hidden = !opening;
        quickToggle?.setAttribute('aria-expanded', String(opening));
    }

    quickToggle?.addEventListener('click', event => {
        event.stopPropagation();
        toggleQuickActions();
    });

    quickPanel?.addEventListener('click', event => {
        const button = event.target.closest('[data-assistant-query]');
        if (!button) return;
        respond(button.dataset.assistantQuery);
        closeQuickActions();
    });

    document.addEventListener('click', event => {
        if (!quickPanel || quickPanel.hidden) return;
        if (quickPanel.contains(event.target) || quickToggle?.contains(event.target)) return;
        closeQuickActions();
    });

    document.addEventListener('keydown', event => {
        if (event.key === 'Escape') closeQuickActions();
    });

    // Delegated click handling for the clickable name links rendered inside
    // assistant replies (characters, chapters, arcs, and every other entity).
    messagesEl()?.addEventListener('click', event => {
        const ambiguityBtn = event.target.closest('.assistant-ambiguity-btn');
        if (ambiguityBtn) {
            const { ambiguityType, ambiguityQuery } = ambiguityBtn.dataset;
            if (ambiguityType) resolveAmbiguity(ambiguityType, ambiguityQuery);
            return;
        }

        const link = event.target.closest('.assistant-entity-link');
        if (!link) return;
        const { entityType, entityId } = link.dataset;
        if (!entityType || !entityId) return;
        openEntity(entityType, entityId);
    });
}

export function loadAssistantTab() {
    const story = storyService.getCurrentStory();
    const list = messagesEl();
    if (list && list.childElementCount > 0) return; // keep existing conversation on repeat visits

    if (!story) {
        addMessage('assistant', buildSimpleAnswer('Choose a story first', 'Open a story from My Stories, then return here to ask about it.'));
        return;
    }
    addMessage('assistant', buildSimpleAnswer('Ask your story', 'Tap the ✦ next to the input for quick suggestions, type a plain keyword like “locations”, “characters”, or “all”, or ask about anything specific — e.g. “Who is Mara?”.'));
}
