import { createId } from './id.js';

// ============================================================
// Backup & Transfer
// Export stories to a .json file, and import them back from one.
// Everything lives in localStorage:
//   "stories"                                   -> every story (all tabs + story map nested inside)
//   "storyplanner_character_connections_<id>"   -> per-character detail page data
// ============================================================

const STORIES_KEY = 'stories';
const CHARACTER_KEY_PREFIX = 'storyplanner_character_connections_';
const FORMAT_NAME = 'story-planner';
const FORMAT_VERSION = 1;
const LIST_FIELDS = ['chapters', 'characters', 'arcs', 'locations', 'lore', 'factions', 'timeline', 'notes', 'ideas'];

// ---------- storage helpers ----------

function readStories() {
    try {
        const saved = JSON.parse(localStorage.getItem(STORIES_KEY));
        return Array.isArray(saved) ? saved : [];
    } catch {
        return [];
    }
}

function readCharacterDetail(characterId) {
    try {
        const raw = localStorage.getItem(CHARACTER_KEY_PREFIX + characterId);
        return raw ? JSON.parse(raw) : null;
    } catch {
        return null;
    }
}

function isInsideStory() {
    const dash = document.getElementById('dashboardView');
    return !!dash && dash.style.display === 'grid';
}

function getActiveStory() {
    const id = localStorage.getItem('activeStoryId');
    return readStories().find(s => String(s.id) === String(id)) || null;
}

// ---------- export ----------

function buildExport(stories) {
    const characterDetails = {};
    stories.forEach(story => {
        (story.characters || []).forEach(character => {
            const detail = readCharacterDetail(character.id);
            if (detail) characterDetails[String(character.id)] = detail;
        });
    });
    return {
        app: FORMAT_NAME,
        version: FORMAT_VERSION,
        exportedAt: new Date().toISOString(),
        stories,
        characterDetails
    };
}

function slugify(text) {
    return String(text || '')
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-+|-+$/g, '')
        .slice(0, 40) || 'story';
}

// Returns 'shared', 'cancelled' or 'downloaded'.
// On phones/tablets the share sheet ("Save to Files", Drive, messaging apps...) is far more
// reliable than a blob download, which many mobile and in-app browsers silently ignore.
async function saveJsonFile(data, filename) {
    const json = JSON.stringify(data, null, 2);
    const isTouch = !!(window.matchMedia && window.matchMedia('(pointer: coarse)').matches);

    if (isTouch && typeof File === 'function' && navigator.canShare && navigator.share) {
        try {
            const file = new File([json], filename, { type: 'application/json' });
            if (navigator.canShare({ files: [file] })) {
                await navigator.share({ files: [file], title: filename });
                return 'shared';
            }
        } catch (err) {
            if (err && err.name === 'AbortError') return 'cancelled';
            // anything else: fall back to a normal download below
        }
    }

    // Generic binary type + custom extension: chat apps then offer to download the file
    // instead of opening it in a text/JSON viewer.
    const blob = new Blob([json], { type: 'application/octet-stream' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.rel = 'noopener';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 30000);
    return 'downloaded';
}

function today() {
    return new Date().toISOString().slice(0, 10);
}

// ---------- copy-as-text transfer code ----------
// For moving data between devices through any chat app without sending a file:
// "SP1:" + base64(gzip(JSON)). Falls back to plain JSON where gzip isn't available.

const CODE_PREFIX = 'SP1:';

function bytesToBase64(bytes) {
    let binary = '';
    const chunk = 0x8000;
    for (let i = 0; i < bytes.length; i += chunk) {
        binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
    }
    return btoa(binary);
}

function base64ToBytes(b64) {
    const binary = atob(b64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return bytes;
}

async function streamBytes(bytes, transform) {
    const stream = new Blob([bytes]).stream().pipeThrough(transform);
    return new Uint8Array(await new Response(stream).arrayBuffer());
}

async function encodeTransferCode(data) {
    const json = JSON.stringify(data);
    if (typeof CompressionStream === 'function') {
        try {
            const packed = await streamBytes(new TextEncoder().encode(json), new CompressionStream('gzip'));
            return CODE_PREFIX + bytesToBase64(packed);
        } catch (err) {
            console.warn('Compression failed, using plain JSON', err);
        }
    }
    return json;
}

// Turns whatever was pasted (a code, or raw JSON) into JSON text.
async function decodeTransferText(text) {
    const trimmed = String(text || '').trim();
    if (!trimmed.startsWith(CODE_PREFIX)) return trimmed;
    if (typeof DecompressionStream !== 'function') {
        throw new Error('This browser is too old to read a copied code. Update it, or use a file instead.');
    }
    try {
        const b64 = trimmed.slice(CODE_PREFIX.length).replace(/\s+/g, '');
        const bytes = await streamBytes(base64ToBytes(b64), new DecompressionStream('gzip'));
        return new TextDecoder().decode(bytes);
    } catch {
        throw new Error('That code looks incomplete or damaged. Make sure you copied all of it.');
    }
}

// ---------- import ----------

// Accepts our export format (or a bare array of stories) and returns clean data, or throws.
function parseImport(text) {
    let data;
    try {
        data = JSON.parse(text);
    } catch {
        throw new Error('That file is not valid JSON. Pick a file exported from Story Planner.');
    }

    let stories;
    let characterDetails = {};
    if (Array.isArray(data)) {
        stories = data;
    } else if (data && typeof data === 'object' && data.app === FORMAT_NAME && Array.isArray(data.stories)) {
        stories = data.stories;
        if (data.characterDetails && typeof data.characterDetails === 'object') {
            characterDetails = data.characterDetails;
        }
    } else {
        throw new Error('This does not look like a Story Planner export.');
    }

    stories = stories
        .filter(s => s && typeof s === 'object' && !Array.isArray(s) && s.id !== undefined && s.id !== null)
        .map(normalizeStory);

    if (!stories.length) {
        throw new Error('No stories were found in that file.');
    }
    return { stories, characterDetails };
}

function normalizeStory(story) {
    const clean = { ...story };
    if (typeof clean.name !== 'string' || !clean.name.trim()) clean.name = 'Untitled story';
    LIST_FIELDS.forEach(field => {
        if (!Array.isArray(clean[field])) clean[field] = [];
    });
    return clean;
}

function describeStory(story) {
    const parts = [];
    const add = (n, singular, plural) => { if (n) parts.push(`${n} ${n === 1 ? singular : plural}`); };
    add(story.chapters.length, 'chapter', 'chapters');
    add(story.characters.length, 'character', 'characters');
    add(story.arcs.length, 'arc', 'arcs');
    add(story.locations.length, 'location', 'locations');
    add(story.ideas.length, 'idea', 'ideas');
    add(story.storyMap && Array.isArray(story.storyMap.boxes) ? story.storyMap.boxes.length : 0, 'map box', 'map boxes');
    return parts.length ? parts.join(' · ') : 'Empty story';
}

// Gives a story brand-new ids everywhere (including references between items), so an
// imported copy never shares ids -- or character detail records -- with the original.
function cloneWithNewIds(story, characterDetails) {
    const idMap = new Map();

    (function collect(node) {
        if (Array.isArray(node)) {
            node.forEach(collect);
        } else if (node && typeof node === 'object') {
            if ((typeof node.id === 'number' || typeof node.id === 'string') && String(node.id).length >= 6) {
                const key = String(node.id);
                if (!idMap.has(key)) idMap.set(key, createId());
            }
            Object.values(node).forEach(collect);
        }
    })(story);

    const reviver = (_key, value) => {
        if ((typeof value === 'number' || typeof value === 'string') && idMap.has(String(value))) {
            const fresh = idMap.get(String(value));
            return typeof value === 'number' ? fresh : String(fresh);
        }
        return value;
    };

    const newStory = JSON.parse(JSON.stringify(story), reviver);
    const newDetails = {};
    (story.characters || []).forEach(character => {
        const detail = characterDetails[String(character.id)];
        if (!detail) return;
        const newId = idMap.get(String(character.id));
        newDetails[String(newId)] = JSON.parse(JSON.stringify(detail), reviver);
    });
    return { story: newStory, details: newDetails };
}

// mode: 'copy' (keep both) or 'replace' (overwrite stories that already exist)
function applyImport(imported, mode) {
    const library = readStories();
    const detailsToWrite = {};
    let added = 0;
    let replaced = 0;
    let copied = 0;

    imported.stories.forEach(story => {
        const existingIndex = library.findIndex(s => String(s.id) === String(story.id));

        if (existingIndex === -1) {
            library.push(story);
            (story.characters || []).forEach(c => {
                const d = imported.characterDetails[String(c.id)];
                if (d) detailsToWrite[String(c.id)] = d;
            });
            added++;
        } else if (mode === 'replace') {
            library[existingIndex] = story;
            (story.characters || []).forEach(c => {
                const d = imported.characterDetails[String(c.id)];
                if (d) detailsToWrite[String(c.id)] = d;
            });
            replaced++;
        } else {
            const { story: copy, details } = cloneWithNewIds(story, imported.characterDetails);
            copy.name = `${story.name} (imported)`;
            library.push(copy);
            Object.assign(detailsToWrite, details);
            copied++;
        }
    });

    // Write stories first: if the browser is out of space this throws and nothing has changed.
    localStorage.setItem(STORIES_KEY, JSON.stringify(library));
    Object.entries(detailsToWrite).forEach(([id, detail]) => {
        try {
            localStorage.setItem(CHARACTER_KEY_PREFIX + id, JSON.stringify(detail));
        } catch (e) {
            console.warn('Could not store character details for', id, e);
        }
    });

    return { added, replaced, copied };
}

// ---------- UI ----------

let overlay = null;
let pendingImport = null;

function el(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
}

function closeModal() {
    if (overlay) {
        overlay.remove();
        overlay = null;
    }
    pendingImport = null;
    document.removeEventListener('keydown', onKeydown);
}

function onKeydown(e) {
    if (e.key === 'Escape') closeModal();
}

function openModal() {
    closeModal();

    const stories = readStories();
    const activeStory = isInsideStory() ? getActiveStory() : null;

    overlay = el('div', 'backup-overlay');
    overlay.addEventListener('click', (e) => { if (e.target === overlay) closeModal(); });

    const modal = el('div', 'backup-modal');
    modal.setAttribute('role', 'dialog');
    modal.setAttribute('aria-modal', 'true');
    modal.setAttribute('aria-label', 'Backup and transfer');

    // header
    const head = el('div', 'backup-head');
    head.appendChild(el('h2', '', 'Backup & Transfer'));
    const closeBtn = el('button', 'backup-close', '✕');
    closeBtn.type = 'button';
    closeBtn.setAttribute('aria-label', 'Close');
    closeBtn.addEventListener('click', closeModal);
    head.appendChild(closeBtn);
    modal.appendChild(head);

    // ---- export section ----
    const exportSection = el('section', 'backup-section');
    exportSection.appendChild(el('h3', '', 'Export to a file'));
    exportSection.appendChild(el('p', 'backup-hint', 'Download a file as a backup, or copy your stories as text to move them to another device through any chat app.'));

    if (!stories.length) {
        exportSection.appendChild(el('p', 'backup-note', 'You have no stories to export yet.'));
    } else {
        const choices = [];
        if (activeStory) {
            choices.push({ value: 'story', label: `This story: ${activeStory.name}` });
        }
        choices.push({ value: 'all', label: `All stories (${stories.length})` });

        const group = el('div', 'backup-radio-group');
        choices.forEach((choice, i) => {
            const label = el('label', 'backup-radio');
            const input = document.createElement('input');
            input.type = 'radio';
            input.name = 'backupScope';
            input.value = choice.value;
            input.checked = i === 0;
            label.appendChild(input);
            label.appendChild(el('span', '', choice.label));
            group.appendChild(label);
        });
        exportSection.appendChild(group);

        const exportBtn = el('button', 'backup-btn backup-btn-primary', 'Download file');
        exportBtn.type = 'button';
        const exportStatus = el('p', 'backup-status');
        exportStatus.hidden = true;
        exportBtn.addEventListener('click', async () => {
            const scope = modal.querySelector('input[name="backupScope"]:checked').value;
            const chosen = scope === 'story' && activeStory ? [activeStory] : stories;
            const name = scope === 'story' && activeStory ? slugify(activeStory.name) : 'all-stories';
            const filename = `story-planner-${name}-${today()}.storyplanner`;
            try {
                const result = await saveJsonFile(buildExport(chosen), filename);
                if (result === 'cancelled') {
                    exportStatus.hidden = true;
                    return;
                }
                exportStatus.textContent = result === 'shared'
                    ? 'File ready. Choose where to save it.'
                    : `Downloaded ${filename}. Check your Downloads folder.`;
                exportStatus.className = 'backup-status success';
                exportStatus.hidden = false;
            } catch (err) {
                console.error(err);
                exportStatus.textContent = 'Could not create the file in this browser. Try opening Story Planner in Chrome or Safari.';
                exportStatus.className = 'backup-status error';
                exportStatus.hidden = false;
            }
        });
        exportSection.appendChild(exportBtn);

        const copyBtn = el('button', 'backup-btn backup-btn-wide', 'Copy as text instead');
        copyBtn.type = 'button';
        const codeBox = document.createElement('textarea');
        codeBox.className = 'backup-code';
        codeBox.readOnly = true;
        codeBox.rows = 4;
        codeBox.hidden = true;
        copyBtn.addEventListener('click', async () => {
            const scope = modal.querySelector('input[name="backupScope"]:checked').value;
            const chosen = scope === 'story' && activeStory ? [activeStory] : stories;
            try {
                const code = await encodeTransferCode(buildExport(chosen));
                codeBox.value = code;
                codeBox.hidden = false;
                codeBox.focus();
                codeBox.select();
                let copied = false;
                try {
                    if (navigator.clipboard && window.isSecureContext) {
                        await navigator.clipboard.writeText(code);
                        copied = true;
                    } else {
                        copied = document.execCommand('copy');
                    }
                } catch { copied = false; }
                const size = code.length.toLocaleString();
                exportStatus.textContent = (copied
                    ? `Copied (${size} characters). `
                    : `Press and hold the box above, then choose Select all and Copy (${size} characters). `)
                    + 'Send it to yourself in any chat app, then paste it into Import on your other device.'
                    + (code.length > 20000 ? ' It is long, so if a chat app cuts it off, use the file instead.' : '');
                exportStatus.className = 'backup-status success';
                exportStatus.hidden = false;
            } catch (err) {
                console.error(err);
                exportStatus.textContent = 'Could not create the text. Try the file option instead.';
                exportStatus.className = 'backup-status error';
                exportStatus.hidden = false;
            }
        });
        exportSection.appendChild(copyBtn);
        exportSection.appendChild(codeBox);
        exportSection.appendChild(exportStatus);
    }
    modal.appendChild(exportSection);

    // ---- import section ----
    const importSection = el('section', 'backup-section');
    importSection.appendChild(el('h3', '', 'Import from a file'));
    importSection.appendChild(el('p', 'backup-hint', 'Choose an exported file, or paste copied text. Your current stories are kept unless you choose to replace them.'));

    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    // No `accept` filter on purpose: some phones label saved files as text/plain or
    // octet-stream and grey them out. The file's contents are validated instead.
    fileInput.className = 'backup-file-input';
    fileInput.id = 'backupFileInput';

    const chooseLabel = el('label', 'backup-btn', 'Choose file');
    chooseLabel.setAttribute('for', 'backupFileInput');

    const fileName = el('span', 'backup-file-name', 'No file chosen');
    const pickRow = el('div', 'backup-pick-row');
    pickRow.appendChild(chooseLabel);
    pickRow.appendChild(fileName);

    const preview = el('div', 'backup-preview');
    preview.hidden = true;
    const status = el('p', 'backup-status');
    status.hidden = true;

    const pasteToggle = el('button', 'backup-link-btn', 'Or paste copied text instead');
    pasteToggle.type = 'button';
    const pasteBox = el('div', 'backup-paste');
    pasteBox.hidden = true;
    const pasteArea = document.createElement('textarea');
    pasteArea.className = 'backup-code';
    pasteArea.rows = 4;
    pasteArea.placeholder = 'Paste the copied text here';
    pasteArea.setAttribute('autocapitalize', 'off');
    pasteArea.setAttribute('autocorrect', 'off');
    pasteArea.spellcheck = false;
    const pasteGo = el('button', 'backup-btn backup-btn-wide', 'Read pasted text');
    pasteGo.type = 'button';
    pasteBox.appendChild(pasteArea);
    pasteBox.appendChild(pasteGo);
    pasteToggle.addEventListener('click', () => {
        pasteBox.hidden = !pasteBox.hidden;
        if (!pasteBox.hidden) pasteArea.focus();
    });

    importSection.appendChild(fileInput);
    importSection.appendChild(pickRow);
    importSection.appendChild(pasteToggle);
    importSection.appendChild(pasteBox);
    importSection.appendChild(preview);
    importSection.appendChild(status);
    modal.appendChild(importSection);

    function showStatus(message, kind) {
        status.textContent = message;
        status.className = `backup-status ${kind || ''}`;
        status.hidden = !message;
    }

    fileInput.addEventListener('change', async () => {
        const file = fileInput.files && fileInput.files[0];
        if (!file) {
            fileName.textContent = 'No file chosen';
            resetPreview();
            return;
        }
        fileName.textContent = file.name;
        let text;
        try {
            text = await file.text();
        } catch {
            resetPreview();
            showStatus('Could not read that file.', 'error');
            return;
        }
        await loadPreview(text);
    });

    pasteGo.addEventListener('click', async () => {
        if (!pasteArea.value.trim()) {
            resetPreview();
            showStatus('Paste the copied text into the box first.', 'error');
            return;
        }
        await loadPreview(pasteArea.value);
    });

    function resetPreview() {
        pendingImport = null;
        preview.hidden = true;
        preview.replaceChildren();
        showStatus('');
    }

    async function loadPreview(text) {
        resetPreview();

        let imported;
        try {
            imported = parseImport(await decodeTransferText(text));
        } catch (err) {
            showStatus(err.message, 'error');
            return;
        }
        pendingImport = imported;

        const existingIds = new Set(readStories().map(s => String(s.id)));
        const conflicts = imported.stories.filter(s => existingIds.has(String(s.id))).length;

        preview.appendChild(el('p', 'backup-preview-title',
            `Found ${imported.stories.length} ${imported.stories.length === 1 ? 'story' : 'stories'}:`));
        const list = el('ul', 'backup-story-list');
        imported.stories.forEach(story => {
            const item = el('li');
            const top = el('div', 'backup-story-name', story.name);
            if (existingIds.has(String(story.id))) top.appendChild(el('span', 'backup-tag', 'already in your library'));
            item.appendChild(top);
            item.appendChild(el('div', 'backup-story-meta', describeStory(story)));
            list.appendChild(item);
        });
        preview.appendChild(list);

        if (conflicts) {
            const group = el('div', 'backup-radio-group');
            [
                { value: 'copy', label: 'Keep both: import as a new copy', checked: true },
                { value: 'replace', label: 'Replace the existing story with the file' }
            ].forEach(opt => {
                const label = el('label', 'backup-radio');
                const input = document.createElement('input');
                input.type = 'radio';
                input.name = 'backupConflict';
                input.value = opt.value;
                input.checked = !!opt.checked;
                label.appendChild(input);
                label.appendChild(el('span', '', opt.label));
                group.appendChild(label);
            });
            preview.appendChild(group);
        }

        const importBtn = el('button', 'backup-btn backup-btn-primary', 'Import');
        importBtn.type = 'button';
        importBtn.addEventListener('click', () => {
            if (!pendingImport) return;
            const picked = modal.querySelector('input[name="backupConflict"]:checked');
            const mode = picked ? picked.value : 'copy';
            try {
                const result = applyImport(pendingImport, mode);
                const total = result.added + result.replaced + result.copied;
                importBtn.disabled = true;
                showStatus(`Imported ${total} ${total === 1 ? 'story' : 'stories'}. Reloading…`, 'success');
                setTimeout(() => window.location.reload(), 900);
            } catch (err) {
                console.error(err);
                showStatus('Import failed: your browser may be out of storage space. Nothing was changed.', 'error');
            }
        });
        preview.appendChild(importBtn);
        preview.hidden = false;
    }

    overlay.appendChild(modal);
    document.body.appendChild(overlay);
    document.addEventListener('keydown', onKeydown);
}

function addTopbarButton() {
    const actions = document.querySelector('.topbar-actions');
    if (!actions || document.getElementById('backupButton')) return;

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.id = 'backupButton';
    btn.className = 'backup-topbar-btn';
    btn.title = 'Backup & Transfer';
    btn.setAttribute('aria-label', 'Backup and transfer');
    btn.innerHTML =
        '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
        '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>' +
        '<polyline points="7 10 12 15 17 10"></polyline>' +
        '<line x1="12" y1="15" x2="12" y2="3"></line></svg>' +
        '<span class="backup-topbar-label">Backup</span>';
    btn.addEventListener('click', openModal);
    actions.insertBefore(btn, actions.firstChild);
}

addTopbarButton();
