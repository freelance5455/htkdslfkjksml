import { createId } from './id.js';

// ============================================================
// Backup & Transfer
// Export stories to a .json file, and import them back from one.
// Everything lives in localStorage:
//   "stories"                                   -> every story (all tabs + story map nested inside)
//   "storyplanner_character_connections_<id>"   -> per-character detail page data
// ============================================================

const STORIES_KEY = 'stories';
const CHARACTER_KEY_PREFIX = 'storyplanner_character_connections_';
const FORMAT_NAME = 'story-planner';
const FORMAT_VERSION = 1;
const LIST_FIELDS = ['chapters', 'characters', 'arcs', 'locations', 'lore', 'factions', 'timeline', 'notes', 'ideas'];

// ---------- storage helpers ----------

function readStories() {
    try {
        const saved = JSON.parse(localStorage.getItem(STORIES_KEY));
        return Array.isArray(saved) ? saved : [];
    } catch {
        return [];
    }
}

function readCharacterDetail(characterId) {
    try {
        const raw = localStorage.getItem(CHARACTER_KEY_PREFIX + characterId);
        return raw ? JSON.parse(raw) : null;
    } catch {
        return null;
    }
}

function isInsideStory() {
    const dash = document.getElementById('dashboardView');
    return !!dash && dash.style.display === 'grid';
}

function getActiveStory() {
    const id = localStorage.getItem('activeStoryId');
    return readStories().find(s => String(s.id) === String(id)) || null;
}

// ---------- export ----------

function buildExport(stories) {
    const characterDetails = {};
    stories.forEach(story => {
        (story.characters || []).forEach(character => {
            const detail = readCharacterDetail(character.id);
            if (detail) characterDetails[String(character.id)] = detail;
        });
    });
    return {
        app: FORMAT_NAME,
        version: FORMAT_VERSION,
        exportedAt: new Date().toISOString(),
        stories,
        characterDetails
    };
}

function slugify(text) {
    return String(text || '')
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-+|-+$/g, '')
        .slice(0, 40) || 'story';
}

function downloadJson(data, filename) {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function today() {
    return new Date().toISOString().slice(0, 10);
}

// ---------- import ----------

// Accepts our export format (or a bare array of stories) and returns clean data, or throws.
function parseImport(text) {
    let data;
    try {
        data = JSON.parse(text);
    } catch {
        throw new Error('That file is not valid JSON. Pick a file exported from Story Planner.');
    }

    let stories;
    let characterDetails = {};
    if (Array.isArray(data)) {
        stories = data;
    } else if (data && typeof data === 'object' && data.app === FORMAT_NAME && Array.isArray(data.stories)) {
        stories = data.stories;
        if (data.characterDetails && typeof data.characterDetails === 'object') {
            characterDetails = data.characterDetails;
        }
    } else {
        throw new Error('This does not look like a Story Planner export.');
    }

    stories = stories
        .filter(s => s && typeof s === 'object' && !Array.isArray(s) && s.id !== undefined && s.id !== null)
        .map(normalizeStory);

    if (!stories.length) {
        throw new Error('No stories were found in that file.');
    }
    return { stories, characterDetails };
}

function normalizeStory(story) {
    const clean = { ...story };
    if (typeof clean.name !== 'string' || !clean.name.trim()) clean.name = 'Untitled story';
    LIST_FIELDS.forEach(field => {
        if (!Array.isArray(clean[field])) clean[field] = [];
    });
    return clean;
}

function describeStory(story) {
    const parts = [];
    const add = (n, singular, plural) => { if (n) parts.push(`${n} ${n === 1 ? singular : plural}`); };
    add(story.chapters.length, 'chapter', 'chapters');
    add(story.characters.length, 'character', 'characters');
    add(story.arcs.length, 'arc', 'arcs');
    add(story.locations.length, 'location', 'locations');
    add(story.ideas.length, 'idea', 'ideas');
    add(story.storyMap && Array.isArray(story.storyMap.boxes) ? story.storyMap.boxes.length : 0, 'map box', 'map boxes');
    return parts.length ? parts.join(' · ') : 'Empty story';
}

// Gives a story brand-new ids everywhere (including references between items), so an
// imported copy never shares ids -- or character detail records -- with the original.
function cloneWithNewIds(story, characterDetails) {
    const idMap = new Map();

    (function collect(node) {
        if (Array.isArray(node)) {
            node.forEach(collect);
        } else if (node && typeof node === 'object') {
            if ((typeof node.id === 'number' || typeof node.id === 'string') && String(node.id).length >= 6) {
                const key = String(node.id);
                if (!idMap.has(key)) idMap.set(key, createId());
            }
            Object.values(node).forEach(collect);
        }
    })(story);

    const reviver = (_key, value) => {
        if ((typeof value === 'number' || typeof value === 'string') && idMap.has(String(value))) {
            const fresh = idMap.get(String(value));
            return typeof value === 'number' ? fresh : String(fresh);
        }
        return value;
    };

    const newStory = JSON.parse(JSON.stringify(story), reviver);
    const newDetails = {};
    (story.characters || []).forEach(character => {
        const detail = characterDetails[String(character.id)];
        if (!detail) return;
        const newId = idMap.get(String(character.id));
        newDetails[String(newId)] = JSON.parse(JSON.stringify(detail), reviver);
    });
    return { story: newStory, details: newDetails };
}

// mode: 'copy' (keep both) or 'replace' (overwrite stories that already exist)
function applyImport(imported, mode) {
    const library = readStories();
    const detailsToWrite = {};
    let added = 0;
    let replaced = 0;
    let copied = 0;

    imported.stories.forEach(story => {
        const existingIndex = library.findIndex(s => String(s.id) === String(story.id));

        if (existingIndex === -1) {
            library.push(story);
            (story.characters || []).forEach(c => {
                const d = imported.characterDetails[String(c.id)];
                if (d) detailsToWrite[String(c.id)] = d;
            });
            added++;
        } else if (mode === 'replace') {
            library[existingIndex] = story;
            (story.characters || []).forEach(c => {
                const d = imported.characterDetails[String(c.id)];
                if (d) detailsToWrite[String(c.id)] = d;
            });
            replaced++;
        } else {
            const { story: copy, details } = cloneWithNewIds(story, imported.characterDetails);
            copy.name = `${story.name} (imported)`;
            library.push(copy);
            Object.assign(detailsToWrite, details);
            copied++;
        }
    });

    // Write stories first: if the browser is out of space this throws and nothing has changed.
    localStorage.setItem(STORIES_KEY, JSON.stringify(library));
    Object.entries(detailsToWrite).forEach(([id, detail]) => {
        try {
            localStorage.setItem(CHARACTER_KEY_PREFIX + id, JSON.stringify(detail));
        } catch (e) {
            console.warn('Could not store character details for', id, e);
        }
    });

    return { added, replaced, copied };
}

// ---------- UI ----------

let overlay = null;
let pendingImport = null;

function el(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
}

function closeModal() {
    if (overlay) {
        overlay.remove();
        overlay = null;
    }
    pendingImport = null;
    document.removeEventListener('keydown', onKeydown);
}

function onKeydown(e) {
    if (e.key === 'Escape') closeModal();
}

function openModal() {
    closeModal();

    const stories = readStories();
    const activeStory = isInsideStory() ? getActiveStory() : null;

    overlay = el('div', 'backup-overlay');
    overlay.addEventListener('click', (e) => { if (e.target === overlay) closeModal(); });

    const modal = el('div', 'backup-modal');
    modal.setAttribute('role', 'dialog');
    modal.setAttribute('aria-modal', 'true');
    modal.setAttribute('aria-label', 'Backup and transfer');

    // header
    const head = el('div', 'backup-head');
    head.appendChild(el('h2', '', 'Backup & Transfer'));
    const closeBtn = el('button', 'backup-close', '✕');
    closeBtn.type = 'button';
    closeBtn.setAttribute('aria-label', 'Close');
    closeBtn.addEventListener('click', closeModal);
    head.appendChild(closeBtn);
    modal.appendChild(head);

    // ---- export section ----
    const exportSection = el('section', 'backup-section');
    exportSection.appendChild(el('h3', '', 'Export to a file'));
    exportSection.appendChild(el('p', 'backup-hint', 'Download your stories as a file you can keep as a backup or move to another device.'));

    if (!stories.length) {
        exportSection.appendChild(el('p', 'backup-note', 'You have no stories to export yet.'));
    } else {
        const choices = [];
        if (activeStory) {
            choices.push({ value: 'story', label: `This story: ${activeStory.name}` });
        }
        choices.push({ value: 'all', label: `All stories (${stories.length})` });

        const group = el('div', 'backup-radio-group');
        choices.forEach((choice, i) => {
            const label = el('label', 'backup-radio');
            const input = document.createElement('input');
            input.type = 'radio';
            input.name = 'backupScope';
            input.value = choice.value;
            input.checked = i === 0;
            label.appendChild(input);
            label.appendChild(el('span', '', choice.label));
            group.appendChild(label);
        });
        exportSection.appendChild(group);

        const exportBtn = el('button', 'backup-btn backup-btn-primary', 'Download file');
        exportBtn.type = 'button';
        exportBtn.addEventListener('click', () => {
            const scope = modal.querySelector('input[name="backupScope"]:checked').value;
            const chosen = scope === 'story' && activeStory ? [activeStory] : stories;
            const name = scope === 'story' && activeStory ? slugify(activeStory.name) : 'all-stories';
            downloadJson(buildExport(chosen), `story-planner-${name}-${today()}.json`);
        });
        exportSection.appendChild(exportBtn);
    }
    modal.appendChild(exportSection);

    // ---- import section ----
    const importSection = el('section', 'backup-section');
    importSection.appendChild(el('h3', '', 'Import from a file'));
    importSection.appendChild(el('p', 'backup-hint', 'Choose a file exported from Story Planner. Your current stories are kept unless you choose to replace them.'));

    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = '.json,application/json';
    fileInput.className = 'backup-file-input';
    fileInput.id = 'backupFileInput';

    const chooseLabel = el('label', 'backup-btn', 'Choose file');
    chooseLabel.setAttribute('for', 'backupFileInput');

    const fileName = el('span', 'backup-file-name', 'No file chosen');
    const pickRow = el('div', 'backup-pick-row');
    pickRow.appendChild(chooseLabel);
    pickRow.appendChild(fileName);

    const preview = el('div', 'backup-preview');
    preview.hidden = true;
    const status = el('p', 'backup-status');
    status.hidden = true;

    importSection.appendChild(fileInput);
    importSection.appendChild(pickRow);
    importSection.appendChild(preview);
    importSection.appendChild(status);
    modal.appendChild(importSection);

    function showStatus(message, kind) {
        status.textContent = message;
        status.className = `backup-status ${kind || ''}`;
        status.hidden = !message;
    }

    fileInput.addEventListener('change', async () => {
        const file = fileInput.files && fileInput.files[0];
        pendingImport = null;
        preview.hidden = true;
        preview.replaceChildren();
        showStatus('');
        if (!file) {
            fileName.textContent = 'No file chosen';
            return;
        }
        fileName.textContent = file.name;

        let imported;
        try {
            imported = parseImport(await file.text());
        } catch (err) {
            showStatus(err.message, 'error');
            return;
        }
        pendingImport = imported;

        const existingIds = new Set(readStories().map(s => String(s.id)));
        const conflicts = imported.stories.filter(s => existingIds.has(String(s.id))).length;

        preview.appendChild(el('p', 'backup-preview-title',
            `Found ${imported.stories.length} ${imported.stories.length === 1 ? 'story' : 'stories'}:`));
        const list = el('ul', 'backup-story-list');
        imported.stories.forEach(story => {
            const item = el('li');
            const top = el('div', 'backup-story-name', story.name);
            if (existingIds.has(String(story.id))) top.appendChild(el('span', 'backup-tag', 'already in your library'));
            item.appendChild(top);
            item.appendChild(el('div', 'backup-story-meta', describeStory(story)));
            list.appendChild(item);
        });
        preview.appendChild(list);

        if (conflicts) {
            const group = el('div', 'backup-radio-group');
            [
                { value: 'copy', label: 'Keep both: import as a new copy', checked: true },
                { value: 'replace', label: 'Replace the existing story with the file' }
            ].forEach(opt => {
                const label = el('label', 'backup-radio');
                const input = document.createElement('input');
                input.type = 'radio';
                input.name = 'backupConflict';
                input.value = opt.value;
                input.checked = !!opt.checked;
                label.appendChild(input);
                label.appendChild(el('span', '', opt.label));
                group.appendChild(label);
            });
            preview.appendChild(group);
        }

        const importBtn = el('button', 'backup-btn backup-btn-primary', 'Import');
        importBtn.type = 'button';
        importBtn.addEventListener('click', () => {
            if (!pendingImport) return;
            const picked = modal.querySelector('input[name="backupConflict"]:checked');
            const mode = picked ? picked.value : 'copy';
            try {
                const result = applyImport(pendingImport, mode);
                const total = result.added + result.replaced + result.copied;
                importBtn.disabled = true;
                showStatus(`Imported ${total} ${total === 1 ? 'story' : 'stories'}. Reloading…`, 'success');
                setTimeout(() => window.location.reload(), 900);
            } catch (err) {
                console.error(err);
                showStatus('Import failed: your browser may be out of storage space. Nothing was changed.', 'error');
            }
        });
        preview.appendChild(importBtn);
        preview.hidden = false;
    });

    overlay.appendChild(modal);
    document.body.appendChild(overlay);
    document.addEventListener('keydown', onKeydown);
}

function addTopbarButton() {
    const actions = document.querySelector('.topbar-actions');
    if (!actions || document.getElementById('backupButton')) return;

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.id = 'backupButton';
    btn.className = 'backup-topbar-btn';
    btn.title = 'Backup & Transfer';
    btn.setAttribute('aria-label', 'Backup and transfer');
    btn.innerHTML =
        '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
        '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>' +
        '<polyline points="7 10 12 15 17 10"></polyline>' +
        '<line x1="12" y1="15" x2="12" y2="3"></line></svg>' +
        '<span class="backup-topbar-label">Backup</span>';
    btn.addEventListener('click', openModal);
    actions.insertBefore(btn, actions.firstChild);
}

addTopbarButton();
