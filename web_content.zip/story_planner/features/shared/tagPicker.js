// Shared helper for rendering an icon-based "tag existing items" picker, with optional search.
// Used by chapters (tag characters), arcs (tag chapters), locations (tag chapters),
// lore & factions (tag characters + locations), timeline (tag chapters + characters),
// and ideas (tag characters, locations, factions, chapters, arcs).

function checkIconSvg(selected) {
    return selected
        ? `<svg class="tag-picker-icon" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                <circle cx="10" cy="10" r="9" fill="#8b7cff"/>
                <path d="M6 10.3l2.4 2.4L14.2 7.4" stroke="#0e0e10" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
           </svg>`
        : `<svg class="tag-picker-icon" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                <circle cx="10" cy="10" r="9" stroke="#4a4a52" stroke-width="1.6"/>
           </svg>`;
}

/**
 * Renders a tappable, icon-based list of selectable items into a container.
 * Selection state lives on the container itself (data-selected), so readTagPicker
 * keeps working after re-renders caused by search filtering.
 * @param {HTMLElement} container - element to render into
 * @param {Array<{id:number, label:string, sublabel?:string}>} items - available items to tag
 * @param {Array<number>} selectedIds - currently tagged ids
 * @param {string} emptyMessage - message shown when items is empty
 * @param {(id:number, isSelected:boolean)=>void} [onToggle] - optional callback fired right after a toggle (e.g. to auto-save)
 */
export function renderTagPicker(container, items, selectedIds = [], emptyMessage = 'Nothing available to tag yet.', onToggle = null) {
    if (!container) return;
    container.innerHTML = '';

    const selected = new Set(selectedIds);
    container.dataset.selected = JSON.stringify([...selected]);

    if (!items || items.length === 0) {
        container.innerHTML = `<div class="tag-picker-empty">${emptyMessage}</div>`;
        return;
    }

    items.forEach(item => {
        const row = document.createElement('button');
        row.type = 'button';
        row.className = 'tag-picker-item' + (selected.has(item.id) ? ' selected' : '');
        row.dataset.id = item.id;
        row.innerHTML = `
            <span class="tag-picker-item-label">${item.label}${item.sublabel ? `<span class="tag-picker-item-sub">${item.sublabel}</span>` : ''}</span>
            <span class="tag-picker-item-icon-slot">${checkIconSvg(selected.has(item.id))}</span>
        `;
        row.addEventListener('click', () => {
            const isNowSelected = !selected.has(item.id);
            if (isNowSelected) selected.add(item.id); else selected.delete(item.id);
            container.dataset.selected = JSON.stringify([...selected]);
            row.classList.toggle('selected', isNowSelected);
            row.querySelector('.tag-picker-item-icon-slot').innerHTML = checkIconSvg(isNowSelected);
            if (onToggle) onToggle(item.id, isNowSelected);
        });
        container.appendChild(row);
    });
}

/**
 * Reads the currently selected ids out of a tag-picker container.
 * @param {HTMLElement} container
 * @returns {Array<number>}
 */
export function readTagPicker(container) {
    if (!container) return [];
    try {
        return JSON.parse(container.dataset.selected || '[]');
    } catch {
        return [];
    }
}

/**
 * Wires a search input to live-filter a tag picker's items by label/sublabel.
 * Preserves the current selection across re-filtering, and can be called again
 * (e.g. each time a modal opens) without stacking duplicate listeners.
 * @param {HTMLElement} container - the tag-picker container
 * @param {HTMLInputElement} searchInputEl - the search text input
 * @param {Array<{id:number, label:string, sublabel?:string}>} allItems - the full, unfiltered item list
 * @param {string} emptyMessage - message shown when allItems is empty (before any search)
 * @param {(id:number, isSelected:boolean)=>void} [onToggle] - forwarded to renderTagPicker on every re-render
 */
export function wireTagPickerSearch(container, searchInputEl, allItems, emptyMessage = 'Nothing available to tag yet.', onToggle = null) {
    if (!searchInputEl) return;

    if (searchInputEl._tagPickerHandler) {
        searchInputEl.removeEventListener('input', searchInputEl._tagPickerHandler);
    }

    const handler = () => {
        const q = searchInputEl.value.trim().toLowerCase();
        const selectedIds = readTagPicker(container);
        const filtered = !q
            ? allItems
            : allItems.filter(it =>
                it.label.toLowerCase().includes(q) ||
                (it.sublabel || '').toLowerCase().includes(q)
              );
        renderTagPicker(container, filtered, selectedIds, q ? 'No matches found.' : emptyMessage, onToggle);
    };

    searchInputEl._tagPickerHandler = handler;
    searchInputEl.addEventListener('input', handler);
    searchInputEl.value = '';
}

/**
 * Renders a read-only row of tag chips (used in detail views / cards).
 * @param {HTMLElement} container
 * @param {Array<{id:number, label:string}>} items
 * @param {string} emptyMessage
 * @param {(id:number)=>void} [onTap] - optional click handler per chip
 */
export function renderTagChips(container, items, emptyMessage = 'None tagged yet.', onTap = null) {
    if (!container) return;
    container.innerHTML = '';

    if (!items || items.length === 0) {
        container.innerHTML = `<div class="tag-chip-empty">${emptyMessage}</div>`;
        return;
    }

    items.forEach(item => {
        const chip = document.createElement(onTap ? 'button' : 'span');
        chip.type = onTap ? 'button' : undefined;
        chip.className = 'tag-pill' + (onTap ? ' tag-pill-tappable' : '');
        chip.textContent = item.label;
        if (onTap) chip.addEventListener('click', () => onTap(item.id));
        container.appendChild(chip);
    });
}
