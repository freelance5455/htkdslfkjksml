let lastTimestamp = 0;
let sequence = 0;

// Numeric, monotonic IDs keep existing form and tag code compatible while
// avoiding collisions when several records are created in the same millisecond.
export function createId() {
    const now = Date.now();
    sequence = now === lastTimestamp ? sequence + 1 : 0;
    lastTimestamp = now;
    return now * 1000 + sequence;
}
