import { characterService } from './characterService.js';
import { characterUi } from './characterUi.js';

export function initCharacterFeature() {
    attachEventListeners();
}

// Allows other features (e.g. the Story Map) to jump straight into editing a character.
export function openCharacterById(id) {
    const character = characterService.getCharacterById(id);
    if (!character) return;
    handleEditCharacter(character);
}

export function loadCharactersTab() {
    const characters = characterService.getCharacters();
    characterUi.renderCharacters(
        characters,
        handleEditCharacter,
        handleDeleteCharacter
    );
}

function handleSaveCharacter(e) {
    e.preventDefault();
    const formData = characterUi.getFormData();

    if (!formData.name) {
        alert('Please enter a character name.');
        return;
    }

    if (formData.id) {
        characterService.updateCharacter(formData.id, formData);
    } else {
        characterService.addCharacter(formData);
    }

    characterUi.closeModal();

    loadCharactersTab();
}

function handleEditCharacter(character) {
    characterUi.openModal(character);
}

function handleDeleteCharacter(id) {
    if (confirm('Are you sure you want to delete this character?')) {
        characterService.deleteCharacter(id);
        loadCharactersTab();
    }
}

function attachEventListeners() {
    const addBtn = document.getElementById('addCharacterBtn');
    if (addBtn) {
        addBtn.addEventListener('click', () => characterUi.openModal());
    }

    const modalCancelBtn = document.getElementById('cancelCharModal');
    if (modalCancelBtn) {
        modalCancelBtn.addEventListener('click', () => characterUi.closeModal());
    }

    const charForm = document.getElementById('characterForm');
    if (charForm) {
        charForm.addEventListener('submit', handleSaveCharacter);
    }

    const profileBtn = document.getElementById('openCharProfileBtn');
    if (profileBtn) {
        profileBtn.addEventListener('click', () => {
            const id = profileBtn.dataset.characterId;
            if (!id) return;
            window.location.href = `pages/character/character.html?id=${encodeURIComponent(id)}`;
        });
    }
}
