function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str || '';
    return div.innerHTML;
}

export const characterUi = {
    get elements() {
        return {
            characterGrid: document.getElementById('characterGrid'),
            characterModal: document.getElementById('characterModal'),
            modalTitle: document.getElementById('characterModalTitle'),
            charIdInput: document.getElementById('charId'),
            charNameInput: document.getElementById('charName'),
            charRoleSelect: document.getElementById('charRole'),
            charArchetypeInput: document.getElementById('charArchetype'),
            charGoalInput: document.getElementById('charGoal'),
            charDescInput: document.getElementById('charDescription'),
            openCharProfileBtn: document.getElementById('openCharProfileBtn')
        };
    },

    renderCharacters(characters, onEdit, onDelete) {
        const grid = this.elements.characterGrid;
        if (!grid) return;

        grid.innerHTML = '';

        if (!characters || characters.length === 0) {
            grid.innerHTML = `
                <div style="grid-column: 1 / -1; text-align: center; color: #666; padding: 50px 0;">
                    No characters created yet. Click "+ Add Character" to create one.
                </div>
            `;
            return;
        }

        characters.forEach(char => {
            const card = document.createElement('div');
            card.className = 'character-card';

            const roleClass = `role-${(char.role || 'minor').toLowerCase()}`;
            const desc = char.description || 'No description provided.';
            card.innerHTML = `
                <div>
                    <div class="character-card-header">
                        <span class="character-name">${escapeHtml(char.name)}</span>
                        <span class="character-role ${roleClass}">${escapeHtml(char.role || 'Supporting')}</span>
                    </div>
                    <div class="character-meta">
                        ${char.archetype ? `<span>Archetype: ${escapeHtml(char.archetype)}</span>` : ''}
                    </div>
                    <p class="character-desc">${escapeHtml(desc)}</p>
                </div>
                <div class="character-actions">
                    <button class="btn-icon edit-btn">Edit</button>
                    <button class="btn-icon delete delete-btn">Delete</button>
                </div>
            `;

            card.querySelector('.edit-btn').addEventListener('click', () => onEdit(char));
            card.querySelector('.delete-btn').addEventListener('click', () => onDelete(char.id));

            grid.appendChild(card);
        });
    },

    getFormData() {
        const els = this.elements;
        return {
            id: els.charIdInput?.value ? Number(els.charIdInput.value) : null,
            name: els.charNameInput?.value.trim() || '',
            role: els.charRoleSelect?.value || 'Protagonist',
            archetype: els.charArchetypeInput?.value.trim() || '',
            goal: els.charGoalInput?.value.trim() || '',
            description: els.charDescInput?.value.trim() || ''
        };
    },

    openModal(character = null) {
        this.clearForm();
        const els = this.elements;

        if (character) {
            if (els.modalTitle) els.modalTitle.textContent = "Edit Character";
            if (els.charIdInput) els.charIdInput.value = character.id;
            if (els.charNameInput) els.charNameInput.value = character.name || '';
            if (els.charRoleSelect) els.charRoleSelect.value = character.role || 'Protagonist';
            if (els.charArchetypeInput) els.charArchetypeInput.value = character.archetype || '';
            if (els.charGoalInput) els.charGoalInput.value = character.goal || '';
            if (els.charDescInput) els.charDescInput.value = character.description || '';
            if (els.openCharProfileBtn) {
                els.openCharProfileBtn.style.display = 'block';
                els.openCharProfileBtn.dataset.characterId = character.id;
            }
        } else {
            if (els.modalTitle) els.modalTitle.textContent = "Add Character";
            if (els.openCharProfileBtn) {
                els.openCharProfileBtn.style.display = 'none';
                delete els.openCharProfileBtn.dataset.characterId;
            }
        }

        if (els.characterModal) els.characterModal.style.display = 'flex';
        els.charNameInput?.focus();
    },

    closeModal() {
        const els = this.elements;
        if (els.characterModal) els.characterModal.style.display = 'none';
        this.clearForm();
    },

    clearForm() {
        const els = this.elements;
        if (els.charIdInput) els.charIdInput.value = '';
        if (els.charNameInput) els.charNameInput.value = '';
        if (els.charRoleSelect) els.charRoleSelect.value = 'Protagonist';
        if (els.charArchetypeInput) els.charArchetypeInput.value = '';
        if (els.charGoalInput) els.charGoalInput.value = '';
        if (els.charDescInput) els.charDescInput.value = '';
        if (els.openCharProfileBtn) {
            els.openCharProfileBtn.style.display = 'none';
            delete els.openCharProfileBtn.dataset.characterId;
        }
    }
};
