import { storyService } from '../story/storyService.js';
import { createId } from '../../shared/id.js';

export const characterService = {
    getCharacters() {
        const story = storyService.getCurrentStory();
        return story ? (story.characters || []) : [];
    },

    getCharacterById(id) {
        const characters = this.getCharacters();
        return characters.find(c => c.id === id) || null;
    },

    addCharacter(characterData) {
        const story = storyService.getCurrentStory();
        if (!story) return null;

        if (!story.characters) story.characters = [];

        const newCharacter = {
            id: createId(),
            name: characterData.name,
            role: characterData.role || 'Supporting',
            archetype: characterData.archetype || '',
            goal: characterData.goal || '',
            description: characterData.description || '',
            lore: characterData.lore || '',
            arcs: characterData.arcs || '',
            relationships: characterData.relationships || '',
            beliefs: characterData.beliefs || ''
        };

        story.characters.push(newCharacter);
        storyService.updateStoryDetails({});
        return newCharacter;
    },

    updateCharacter(id, updatedData) {
        const story = storyService.getCurrentStory();
        if (!story || !story.characters) return false;

        const index = story.characters.findIndex(c => c.id === id);
        if (index !== -1) {
            story.characters[index] = { ...story.characters[index], ...updatedData };
            storyService.updateStoryDetails({});
            return true;
        }
        return false;
    },

    deleteCharacter(id) {
        const story = storyService.getCurrentStory();
        if (!story || !story.characters) return false;

        story.characters = story.characters.filter(c => c.id !== id);

        // Cascade cleanup: untag this character everywhere it was referenced
        (story.chapters || []).forEach(ch => {
            if (ch.characterIds) ch.characterIds = ch.characterIds.filter(cid => cid !== id);
        });
        (story.lore || []).forEach(l => {
            if (l.characterIds) l.characterIds = l.characterIds.filter(cid => cid !== id);
        });
        (story.factions || []).forEach(f => {
            if (f.characterIds) f.characterIds = f.characterIds.filter(cid => cid !== id);
        });
        (story.timeline || []).forEach(t => {
            if (t.characterIds) t.characterIds = t.characterIds.filter(cid => cid !== id);
        });
        (story.ideas || []).forEach(i => {
            if (i.characterIds) i.characterIds = i.characterIds.filter(cid => cid !== id);
        });

        // Cascade cleanup: unlink this character from any Story Map boxes that referenced it
        if (story.storyMap && story.storyMap.boxes) {
            story.storyMap.boxes.forEach(box => {
                if (box.links && box.links.characters) {
                    box.links.characters = box.links.characters.filter(cid => cid !== id);
                }
            });
        }

        storyService.updateStoryDetails({});
        return true;
    }
};
