// DOM Operations & Visual Updates
export const storyUi = {
    elements: {
        homeView: document.getElementById("homeView"),
        dashboardView: document.getElementById("dashboardView"),
        storyGrid: document.getElementById("storyGrid"),
        modal: document.getElementById("storyModal"),
        topTitle: document.getElementById("topTitle"),
        homeButton: document.getElementById("homeButton"),
        mobileMenuBtn: document.getElementById("mobileMenuBtn"),
        mobileSidebarOverlay: document.getElementById("mobileSidebarOverlay"),
        leftSidebar: document.querySelector(".left"),
        dashboardTitle: document.getElementById("dashboardTitle"),
        dashboardDescription: document.getElementById("dashboardDescription"),
        storyNameInput: document.getElementById("storyName"),
        storyDescInput: document.getElementById("storyDescription"),
        storyGenreInput: document.getElementById("storyGenre"),
        storyTargetInput: document.getElementById("storyTarget"),
        storyLoglineInput: document.getElementById("storyLogline"),
        storyThemeInput: document.getElementById("storyTheme"),
        storySynopsisInput: document.getElementById("storySynopsis"),
        saveStatus: document.getElementById("saveStatus"),
        statCharacters: document.getElementById("statCharacters"),
        statChapters: document.getElementById("statChapters"),
        statArcs: document.getElementById("statArcs"),
        statLocations: document.getElementById("statLocations")
    },

    renderStoriesGrid(stories, onSelectStory, onOpenModal) {
        const grid = this.elements.storyGrid;
        grid.innerHTML = "";

        stories.forEach(story => {
            const card = document.createElement("div");
            card.className = "story-card";
            card.innerHTML = `
                <h2></h2>
                <p></p>
                <div class="story-info">
                    <span>${story.chapters ? story.chapters.length : 0} Chapters</span>
                    <span>${story.characters ? story.characters.length : 0} Characters</span>
                </div>
            `;
            card.querySelector('h2').textContent = story.name;
            card.querySelector('p').textContent = story.description || 'No description yet.';
            card.addEventListener("click", () => onSelectStory(story.id));
            grid.appendChild(card);
        });

        const createCard = document.createElement("div");
        createCard.className = "create-card";
        createCard.innerHTML = `
            <div class="plus">+</div>
            <span>Create New Story</span>
        `;
        createCard.addEventListener("click", onOpenModal);
        grid.appendChild(createCard);
    },

    showDashboardView(story) {
        this.elements.homeView.style.display = "none";
        this.elements.dashboardView.style.display = "grid";
        this.elements.homeButton.style.display = "block";
        if (this.elements.mobileMenuBtn) this.elements.mobileMenuBtn.hidden = false;

        this.elements.topTitle.textContent = story.name;
        this.elements.dashboardTitle.textContent = story.name;
        this.elements.dashboardDescription.textContent = story.description || "No description yet.";

        this.populateStoryDetailsForm(story);
        this.refreshStats(story);
    },

    refreshStats(story) {
        const els = this.elements;
        if (els.statCharacters) els.statCharacters.textContent = (story.characters || []).length;
        if (els.statChapters) els.statChapters.textContent = (story.chapters || []).length;
        if (els.statArcs) els.statArcs.textContent = (story.arcs || []).length;
        if (els.statLocations) els.statLocations.textContent = (story.locations || []).length;
    },

    showHomeView() {
        this.elements.dashboardView.style.display = "none";
        this.elements.homeView.style.display = "block";
        this.elements.homeButton.style.display = "none";
        if (this.elements.mobileMenuBtn) this.elements.mobileMenuBtn.hidden = true;
        this.closeMobileSidebar();
        this.elements.topTitle.textContent = "";
    },

    populateStoryDetailsForm(story) {
        this.elements.storyGenreInput.value = story.genre || "";
        this.elements.storyTargetInput.value = story.targetAudience || "";
        this.elements.storyLoglineInput.value = story.logline || "";
        this.elements.storyThemeInput.value = story.themes || "";
        this.elements.storySynopsisInput.value = story.synopsis || "";
    },

    getCreateFormData() {
        return {
            name: this.elements.storyNameInput.value.trim(),
            description: this.elements.storyDescInput.value.trim()
        };
    },

    clearCreateForm() {
        this.elements.storyNameInput.value = "";
        this.elements.storyDescInput.value = "";
    },

    getStoryDetailsFormData() {
        return {
            genre: this.elements.storyGenreInput.value.trim(),
            targetAudience: this.elements.storyTargetInput.value.trim(),
            logline: this.elements.storyLoglineInput.value.trim(),
            themes: this.elements.storyThemeInput.value.trim(),
            synopsis: this.elements.storySynopsisInput.value.trim()
        };
    },

    switchTab(tabName) {
        document.querySelectorAll(".left .nav-item").forEach(item => {
            if (item.getAttribute("data-tab") === tabName) {
                item.classList.add("active");
                item.textContent = item.textContent.replace("◇", "◈");
            } else {
                item.classList.remove("active");
                item.textContent = item.textContent.replace("◈", "◇");
            }
        });

        document.querySelectorAll(".tab-content").forEach(panel => {
            panel.classList.remove("active");
        });

        const activePanel = document.getElementById(`tab-${tabName}`);
        if (activePanel) {
            activePanel.classList.add("active");
        }
    },

    toggleMobileSidebar() {
        const { leftSidebar, mobileSidebarOverlay } = this.elements;
        if (!leftSidebar || !mobileSidebarOverlay) return;

        if (leftSidebar.classList.contains("mobile-open")) {
            this.closeMobileSidebar();
        } else {
            leftSidebar.classList.add("mobile-open");
            mobileSidebarOverlay.classList.add("active");
            document.body.classList.add("sidebar-open");
        }
    },

    closeMobileSidebar() {
        const { leftSidebar, mobileSidebarOverlay } = this.elements;
        if (!leftSidebar || !mobileSidebarOverlay) return;

        leftSidebar.classList.remove("mobile-open");
        mobileSidebarOverlay.classList.remove("active");
        document.body.classList.remove("sidebar-open");
    },

    openModal() {
        this.elements.modal.style.display = "flex";
        this.elements.storyNameInput.focus();
    },

    closeModal() {
        this.elements.modal.style.display = "none";
    },

    showSaveNotification() {
        const status = this.elements.saveStatus;
        status.textContent = "Saved successfully!";
        status.style.color = "#8b7cff";

        setTimeout(() => {
            status.textContent = "All changes saved to local storage.";
            status.style.color = "#666";
        }, 2000);
    }
};
