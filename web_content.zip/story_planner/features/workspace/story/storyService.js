import { createId } from '../../shared/id.js';

function loadStories() {
    try {
        const saved = JSON.parse(localStorage.getItem('stories'));
        return Array.isArray(saved) ? saved : [];
    } catch {
        console.warn('Saved stories could not be read. Starting with an empty library.');
        return [];
    }
}

// Data & State Management
let stories = loadStories();
let activeStoryId = localStorage.getItem("activeStoryId") || null;
let currentStory = stories.find(s => String(s.id) === String(activeStoryId)) || null;

function saveToLocalStorage() {
    localStorage.setItem("stories", JSON.stringify(stories));
    if (currentStory) {
        localStorage.setItem("activeStoryId", currentStory.id);
    }
}

export const storyService = {
    getStories() {
        stories = loadStories();
        return stories;
    },

    getCurrentStory() {
        if (!currentStory) {
            stories = loadStories();
            const savedId = localStorage.getItem("activeStoryId");
            currentStory = stories.find(s => String(s.id) === String(savedId)) || stories[0] || null;
        }
        return currentStory;
    },

    setCurrentStory(id) {
        stories = loadStories();
        currentStory = stories.find(s => String(s.id) === String(id)) || null;
        if (currentStory) {
            localStorage.setItem("activeStoryId", currentStory.id);
        } else {
            localStorage.removeItem("activeStoryId");
        }
        return currentStory;
    },

    resetCurrentStory() {
        currentStory = null;
        localStorage.removeItem("activeStoryId");
    },

    addStory(name, description) {
        const newStory = {
            id: createId(),
            name,
            description,
            genre: "",
            targetAudience: "",
            logline: "",
            themes: "",
            synopsis: "",
            chapters: [],
            characters: [],
            arcs: [],
            locations: [],
            lore: [],
            factions: [],
            timeline: [],
            notes: [],
            ideas: []
        };
        stories.push(newStory);
        currentStory = newStory;
        saveToLocalStorage();
        return newStory;
    },

    updateStoryDetails(details) {
        if (!currentStory) return false;
        Object.assign(currentStory, details);
        saveToLocalStorage();
        return true;
    },

    getStoryStats(story) {
        if (!story) return { characters: 0, chapters: 0, arcs: 0, locations: 0 };
        return {
            characters: (story.characters || []).length,
            chapters: (story.chapters || []).length,
            arcs: (story.arcs || []).length,
            locations: (story.locations || []).length
        };
    }
};
