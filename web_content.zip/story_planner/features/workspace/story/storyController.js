import { storyService } from './storyService.js';
import { storyUi } from './storyUi.js';
import { initCharacterFeature, loadCharactersTab } from '../character/characterController.js';
import { initChapterFeature, loadChaptersTab } from '../chapter/chapterController.js';
import { initArcFeature, loadArcsTab } from '../arc/arcController.js';
import { initStoryMapFeature, loadStoryMapTab } from '../storymap/storyMapController.js';
import { initLocationFeature, loadLocationsTab } from '../../worldbuilding/location/locationController.js';
import { initLoreFeature, loadLoreTab } from '../../worldbuilding/lore/loreController.js';
import { initFactionFeature, loadFactionsTab } from '../../worldbuilding/faction/factionController.js';
import { initTimelineFeature, loadTimelineTab } from '../../worldbuilding/timeline/timelineController.js';
import { initNoteFeature, loadNotesTab } from '../../other/note/noteController.js';
import { initIdeaFeature, loadIdeasTab } from '../../other/idea/ideaController.js';
import { initAssistantFeature, loadAssistantTab } from '../../other/assistant/assistantController.js';

const tabLoaders = {
    characters: loadCharactersTab,
    chapters: loadChaptersTab,
    arcs: loadArcsTab,
    storymap: loadStoryMapTab,
    locations: loadLocationsTab,
    lore: loadLoreTab,
    factions: loadFactionsTab,
    timeline: loadTimelineTab,
    notes: loadNotesTab,
    ideas: loadIdeasTab,
    assistant: loadAssistantTab
};

function init() {
    renderHomeGrid();
    attachEventListeners();

    // Initialize every feature's static event listeners once at startup
    initCharacterFeature();
    initChapterFeature();
    initArcFeature();
    initStoryMapFeature();
    initLocationFeature();
    initLoreFeature();
    initFactionFeature();
    initTimelineFeature();
    initNoteFeature();
    initIdeaFeature();
    initAssistantFeature();
}

function renderHomeGrid() {
    storyUi.renderStoriesGrid(
        storyService.getStories(),
        handleOpenStory,
        () => storyUi.openModal()
    );
}

function handleOpenStory(id) {
    const story = storyService.setCurrentStory(id);
    if (!story) return;

    storyUi.showDashboardView(story);
    storyUi.switchTab('overview');
}

function handleCreateStory() {
    const { name, description } = storyUi.getCreateFormData();

    if (!name) {
        alert("Please enter a story title.");
        return;
    }

    storyService.addStory(name, description);
    storyUi.clearCreateForm();
    storyUi.closeModal();
    renderHomeGrid();
}

function handleSaveStoryDetails(event) {
    event.preventDefault();
    const formData = storyUi.getStoryDetailsFormData();
    const isUpdated = storyService.updateStoryDetails(formData);

    if (isUpdated) {
        storyUi.showSaveNotification();
    }
}

function handleShowHome() {
    storyService.resetCurrentStory();
    storyUi.showHomeView();
    storyUi.closeMobileSidebar();
    renderHomeGrid();
}

function attachEventListeners() {
    storyUi.elements.homeButton.addEventListener('click', handleShowHome);

    const backBtn = document.querySelector('.back-button');
    if (backBtn) backBtn.addEventListener('click', handleShowHome);

    // Mobile sidebar drawer
    if (storyUi.elements.mobileMenuBtn) {
        storyUi.elements.mobileMenuBtn.addEventListener('click', () => storyUi.toggleMobileSidebar());
    }
    if (storyUi.elements.mobileSidebarOverlay) {
        storyUi.elements.mobileSidebarOverlay.addEventListener('click', () => storyUi.closeMobileSidebar());
    }

    const modalCreateBtn = document.querySelector('#storyModal .create');
    if (modalCreateBtn) modalCreateBtn.addEventListener('click', handleCreateStory);

    const modalCancelBtn = document.querySelector('#storyModal button:not(.create)');
    if (modalCancelBtn) modalCancelBtn.addEventListener('click', () => storyUi.closeModal());

    // Sidebar Tab listeners - dispatch to each feature's loader when its tab is opened
    document.querySelectorAll('.left .nav-item[data-tab]').forEach(item => {
        item.addEventListener('click', (e) => {
            const tabName = e.currentTarget.getAttribute('data-tab');
            storyUi.switchTab(tabName);
            storyUi.closeMobileSidebar();

            const loader = tabLoaders[tabName];
            if (loader) loader();

            if (tabName === 'overview') {
                const story = storyService.getCurrentStory();
                if (story) storyUi.refreshStats(story);
            }
        });
    });

    const form = document.getElementById('storyDetailsForm');
    if (form) {
        form.addEventListener('submit', handleSaveStoryDetails);
    }
}

document.addEventListener('DOMContentLoaded', init);
