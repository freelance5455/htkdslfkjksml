import { renderTagPicker, readTagPicker, wireTagPickerSearch } from '../../shared/tagPicker.js';
import { BOX_TYPES } from './storyMapService.js';

function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str || '';
    return div.innerHTML;
}

export const storyMapUi = {
    get elements() {
        return {
            tab: document.getElementById('tab-storymap'),
            addBtn: document.getElementById('addStoryMapBoxBtn'),
            zoomInBtn: document.getElementById('storyMapZoomInBtn'),
            zoomOutBtn: document.getElementById('storyMapZoomOutBtn'),
            zoomResetBtn: document.getElementById('storyMapZoomResetBtn'),
            zoomLabel: document.getElementById('storyMapZoomLabel'),

            searchInput: document.getElementById('storyMapSearchInput'),
            typeFilters: document.getElementById('storyMapTypeFilters'),
            characterFilter: document.getElementById('storyMapCharacterFilter'),
            locationFilter: document.getElementById('storyMapLocationFilter'),
            chapterFilter: document.getElementById('storyMapChapterFilter'),
            clearFiltersBtn: document.getElementById('storyMapClearFiltersBtn'),

            wrap: document.getElementById('storyMapCanvasWrap'),
            world: document.getElementById('storyMapWorld'),
            svg: document.getElementById('storyMapSvg'),
            boxLayer: document.getElementById('storyMapBoxLayer'),
            emptyState: document.getElementById('storyMapEmptyState'),

            boxModal: document.getElementById('storyMapBoxModal'),
            boxModalTitle: document.getElementById('storyMapBoxModalTitle'),
            boxForm: document.getElementById('storyMapBoxForm'),
            boxIdInput: document.getElementById('storyMapBoxId'),
            boxTitleInput: document.getElementById('storyMapBoxTitleInput'),
            boxTypeSelect: document.getElementById('storyMapBoxTypeSelect'),
            boxDescInput: document.getElementById('storyMapBoxDescInput'),
            boxTagsInput: document.getElementById('storyMapBoxTagsInput'),
            boxCancelBtn: document.getElementById('cancelStoryMapBoxModal'),

            linkModal: document.getElementById('storyMapLinkModal'),
            linkTypeToggle: document.getElementById('storyMapLinkTypeToggle'),
            linkPickerLabel: document.getElementById('storyMapLinkPickerLabel'),
            linkPicker: document.getElementById('storyMapLinkPicker'),
            linkSearchInput: document.getElementById('storyMapLinkSearchInput'),
            linkSaveBtn: document.getElementById('storyMapLinkSaveBtn'),
            linkCancelBtn: document.getElementById('storyMapLinkCancelBtn'),

            dialogueModal: document.getElementById('storyMapDialogueModal'),
            dialogueModalTitle: document.getElementById('storyMapDialogueModalTitle'),
            dialogueList: document.getElementById('storyMapDialogueList'),
            dialogueAddLineBtn: document.getElementById('storyMapDialogueAddLineBtn'),
            dialogueCancelBtn: document.getElementById('storyMapDialogueCancelBtn')
        };
    },

    // =========================================================
    // ADD / EDIT BOX MODAL
    // =========================================================
    openBoxModal(box = null) {
        const els = this.elements;
        els.boxModalTitle.textContent = box ? 'Edit Box' : 'Add Box';
        els.boxIdInput.value = box ? box.id : '';
        els.boxTitleInput.value = box ? box.title : '';
        els.boxTypeSelect.value = box ? box.type : 'chapter';
        els.boxDescInput.value = box ? box.description : '';
        els.boxTagsInput.value = box && box.tags ? box.tags.join(', ') : '';
        els.boxModal.style.display = 'flex';
        els.boxTitleInput.focus();
    },

    closeBoxModal() {
        this.elements.boxModal.style.display = 'none';
    },

    getBoxFormData() {
        const els = this.elements;
        const tags = (els.boxTagsInput.value || '')
            .split(',')
            .map(t => t.trim())
            .filter(Boolean);

        return {
            id: els.boxIdInput.value ? Number(els.boxIdInput.value) : null,
            title: els.boxTitleInput.value.trim(),
            type: BOX_TYPES.includes(els.boxTypeSelect.value) ? els.boxTypeSelect.value : 'chapter',
            description: els.boxDescInput.value.trim(),
            tags
        };
    },

    // =========================================================
    // MANAGE LINKS MODAL — one searchable picker, switched by category
    // (mirrors the idea feature's multi-category tag modal)
    // =========================================================
    openLinkModal(box, refData) {
        const els = this.elements;
        const categories = {
            characters: { label: 'Characters', placeholder: 'Search characters...', empty: 'No characters created yet.', items: refData.characters.map(c => ({ id: c.id, label: c.name, sublabel: c.role })) },
            locations: { label: 'Locations', placeholder: 'Search locations...', empty: 'No locations created yet.', items: refData.locations.map(l => ({ id: l.id, label: l.title })) },
            chapters: { label: 'Chapters', placeholder: 'Search chapters...', empty: 'No chapters created yet.', items: refData.chapters.map(c => ({ id: c.id, label: c.title })) },
            lore: { label: 'Lore', placeholder: 'Search lore...', empty: 'No lore created yet.', items: refData.lore.map(l => ({ id: l.id, label: l.title })) },
            factions: { label: 'Factions', placeholder: 'Search factions...', empty: 'No factions created yet.', items: refData.factions.map(f => ({ id: f.id, label: f.title })) },
            ideas: { label: 'Ideas', placeholder: 'Search ideas...', empty: 'No ideas created yet.', items: refData.ideas.map(i => ({ id: i.id, label: i.title })) }
        };

        const selections = {};
        Object.keys(categories).forEach(cat => {
            selections[cat] = [...(box.links[cat] || [])];
        });
        let activeType = 'characters';

        const renderActivePicker = () => {
            const config = categories[activeType];
            els.linkPickerLabel.textContent = config.label;
            els.linkSearchInput.placeholder = config.placeholder;
            renderTagPicker(els.linkPicker, config.items, selections[activeType], config.empty, () => {
                selections[activeType] = readTagPicker(els.linkPicker);
            });
            wireTagPickerSearch(els.linkPicker, els.linkSearchInput, config.items, config.empty, () => {
                selections[activeType] = readTagPicker(els.linkPicker);
            });
            els.linkTypeToggle.querySelectorAll('[data-tag-type]').forEach(button => {
                button.classList.toggle('active', button.dataset.tagType === activeType);
            });
        };

        els.linkTypeToggle.onclick = (event) => {
            const button = event.target.closest('[data-tag-type]');
            if (!button) return;
            selections[activeType] = readTagPicker(els.linkPicker);
            activeType = button.dataset.tagType;
            renderActivePicker();
        };

        this._readLinkSelections = () => {
            selections[activeType] = readTagPicker(els.linkPicker);
            return { ...selections };
        };

        renderActivePicker();
        els.linkModal.style.display = 'flex';
    },

    closeLinkModal() {
        this.elements.linkModal.style.display = 'none';
    },

    readLinkModal() {
        return this._readLinkSelections ? this._readLinkSelections() : {};
    },

    // =========================================================
    // FILTER BAR
    // =========================================================
    populateEntityFilters(refData) {
        const els = this.elements;
        const fill = (select, items, labelKey, placeholder) => {
            if (!select) return;
            const current = select.value;
            select.innerHTML = `<option value="">${placeholder}</option>` +
                items.map(item => `<option value="${item.id}">${escapeHtml(item[labelKey])}</option>`).join('');
            if ([...select.options].some(o => o.value === current)) select.value = current;
        };
        fill(els.characterFilter, refData.characters, 'name', 'All characters');
        fill(els.locationFilter, refData.locations, 'title', 'All locations');
        fill(els.chapterFilter, refData.chapters, 'title', 'All chapters');
    },

    getActiveTypeFilters() {
        const els = this.elements;
        if (!els.typeFilters) return [];
        return [...els.typeFilters.querySelectorAll('[data-type].active')].map(b => b.dataset.type);
    },

    resetFilters() {
        const els = this.elements;
        if (els.searchInput) els.searchInput.value = '';
        if (els.characterFilter) els.characterFilter.value = '';
        if (els.locationFilter) els.locationFilter.value = '';
        if (els.chapterFilter) els.chapterFilter.value = '';
        if (els.typeFilters) {
            els.typeFilters.querySelectorAll('[data-type]').forEach(b => b.classList.add('active'));
        }
    },

    setZoomLabel(percent) {
        const els = this.elements;
        if (els.zoomLabel) els.zoomLabel.textContent = `${percent}%`;
    },

    // =========================================================
    // DIALOGUE MODAL — chapter boxes only
    // =========================================================
    openDialogueModal(box) {
        const els = this.elements;
        els.dialogueModalTitle.textContent = `Dialogue — ${box.title}`;
        els.dialogueModal.style.display = 'flex';
    },

    closeDialogueModal() {
        this.elements.dialogueModal.style.display = 'none';
    },

    // Renders the list of dialogue lines. `handlers` = { onChange(lineId, {speaker, line}), onDelete(lineId) }
    renderDialogueList(dialogues, handlers) {
        const container = this.elements.dialogueList;
        container.innerHTML = '';

        if (!dialogues || dialogues.length === 0) {
            const empty = document.createElement('div');
            empty.className = 'dialogue-empty';
            empty.textContent = 'No dialogue lines yet. Add the first line below.';
            container.appendChild(empty);
            return;
        }

        dialogues.forEach(d => {
            const row = document.createElement('div');
            row.className = 'dialogue-line-row';
            row.dataset.id = d.id;

            const speakerInput = document.createElement('input');
            speakerInput.type = 'text';
            speakerInput.className = 'dialogue-speaker-input';
            speakerInput.placeholder = 'Speaker';
            speakerInput.value = d.speaker || '';
            speakerInput.setAttribute('list', 'storyMapDialogueSpeakerOptions');

            const lineInput = document.createElement('textarea');
            lineInput.className = 'dialogue-line-input';
            lineInput.placeholder = 'What do they say?';
            lineInput.value = d.line || '';
            lineInput.rows = 2;

            const deleteBtn = document.createElement('button');
            deleteBtn.type = 'button';
            deleteBtn.className = 'dialogue-line-delete';
            deleteBtn.title = 'Delete line';
            deleteBtn.textContent = '\u00d7';

            const commit = () => {
                if (handlers.onChange) {
                    handlers.onChange(d.id, { speaker: speakerInput.value, line: lineInput.value });
                }
            };
            speakerInput.addEventListener('blur', commit);
            lineInput.addEventListener('blur', commit);
            deleteBtn.addEventListener('click', () => {
                if (handlers.onDelete) handlers.onDelete(d.id);
            });

            row.appendChild(speakerInput);
            row.appendChild(lineInput);
            row.appendChild(deleteBtn);
            container.appendChild(row);
        });
    },

    // Populates a shared <datalist> so the speaker field can suggest existing character names.
    populateDialogueSpeakerOptions(characters) {
        let list = document.getElementById('storyMapDialogueSpeakerOptions');
        if (!list) {
            list = document.createElement('datalist');
            list.id = 'storyMapDialogueSpeakerOptions';
            document.body.appendChild(list);
        }
        list.innerHTML = characters.map(c => `<option value="${escapeHtml(c.name)}"></option>`).join('');
    },

    focusLastDialogueLine() {
        const rows = this.elements.dialogueList.querySelectorAll('.dialogue-line-row');
        const last = rows[rows.length - 1];
        if (last) {
            const input = last.querySelector('.dialogue-speaker-input');
            if (input) input.focus();
        }
    }
};
