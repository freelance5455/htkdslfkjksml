// Rendering + interaction engine for the Story Map canvas.
// Keeps all DOM/geometry concerns (pan, zoom, drag, connect-by-dragging,
// bezier connection lines) separate from data (storyMapService) and
// orchestration (storyMapController).

import { LINK_CATEGORIES } from './storyMapService.js';

const SVG_NS = 'http://www.w3.org/2000/svg';
const MIN_ZOOM = 0.3;
const MAX_ZOOM = 2.2;
const DRAG_THRESHOLD = 4;

const TYPE_LABELS = {
    chapter: 'Chapter',
    scene: 'Scene',
    event: 'Event',
    decision: 'Decision',
    idea: 'Idea',
    milestone: 'Milestone'
};

function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str || '';
    return div.innerHTML;
}

function clamp(value, min, max) {
    return Math.min(max, Math.max(min, value));
}

function bezierPath(a, b) {
    const dy = Math.max(Math.abs(b.y - a.y) / 2, 40);
    return `M ${a.x} ${a.y} C ${a.x} ${a.y + dy}, ${b.x} ${b.y - dy}, ${b.x} ${b.y}`;
}

/**
 * @param {Object} els - { wrapEl, worldEl, svgEl, boxLayerEl, emptyStateEl }
 * @param {Object} handlers - callbacks the controller supplies
 */
export function createStoryMapCanvas(els, handlers) {
    const { wrapEl, worldEl, svgEl, boxLayerEl, emptyStateEl } = els;

    let viewport = { x: 40, y: 40, zoom: 1 };
    const boxEls = new Map();
    const boxData = new Map();
    const connEls = new Map();
    const connectionsByBox = new Map();
    let persistTimer = null;

    // One-time SVG setup: arrowhead marker definition.
    const defs = document.createElementNS(SVG_NS, 'defs');
    defs.innerHTML = `
        <marker id="storymap-arrowhead" viewBox="0 0 10 10" refX="8" refY="5"
                markerWidth="7" markerHeight="7" orient="auto-start-reverse">
            <path d="M0,0 L10,5 L0,10 z" fill="#8b7cff"></path>
        </marker>
    `;
    svgEl.appendChild(defs);

    function applyTransform() {
        worldEl.style.transform = `translate(${viewport.x}px, ${viewport.y}px) scale(${viewport.zoom})`;
        if (handlers.onZoomLabel) handlers.onZoomLabel(Math.round(viewport.zoom * 100));
    }

    function schedulePersist() {
        if (persistTimer) clearTimeout(persistTimer);
        persistTimer = setTimeout(() => {
            if (handlers.onViewportChange) handlers.onViewportChange({ ...viewport });
        }, 400);
    }

    function addToIndex(map, key, val) {
        if (!map.has(key)) map.set(key, []);
        map.get(key).push(val);
    }

    function getAnchor(el, box, side) {
        const w = el.offsetWidth || 220;
        const h = el.offsetHeight || 90;
        return side === 'top'
            ? { x: box.x + w / 2, y: box.y }
            : { x: box.x + w / 2, y: box.y + h };
    }

    function refreshConnection(group) {
        const fromId = Number(group.dataset.from);
        const toId = Number(group.dataset.to);
        const fromEl = boxEls.get(fromId);
        const toEl = boxEls.get(toId);
        const fromBox = boxData.get(fromId);
        const toBox = boxData.get(toId);
        if (!fromEl || !toEl || !fromBox || !toBox) return;

        const a = getAnchor(fromEl, fromBox, 'bottom');
        const b = getAnchor(toEl, toBox, 'top');
        const mid = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
        const d = bezierPath(a, b);

        group.querySelector('.storymap-conn-hit').setAttribute('d', d);
        group.querySelector('.storymap-conn-line').setAttribute('d', d);
        group.querySelector('.storymap-conn-delete-bg').setAttribute('cx', mid.x);
        group.querySelector('.storymap-conn-delete-bg').setAttribute('cy', mid.y);
        group.querySelector('.storymap-conn-delete-x').setAttribute('x', mid.x);
        group.querySelector('.storymap-conn-delete-x').setAttribute('y', mid.y);
    }

    function refreshConnectionsTouching(boxId) {
        (connectionsByBox.get(boxId) || []).forEach(connId => {
            const group = connEls.get(connId);
            if (group) refreshConnection(group);
        });
    }

    function buildConnectionEl(conn) {
        const group = document.createElementNS(SVG_NS, 'g');
        group.setAttribute('class', 'storymap-conn-group');
        group.dataset.id = conn.id;
        group.dataset.from = conn.from;
        group.dataset.to = conn.to;

        const hit = document.createElementNS(SVG_NS, 'path');
        hit.setAttribute('class', 'storymap-conn-hit');

        const line = document.createElementNS(SVG_NS, 'path');
        line.setAttribute('class', 'storymap-conn-line');
        line.setAttribute('marker-end', 'url(#storymap-arrowhead)');

        const delBg = document.createElementNS(SVG_NS, 'circle');
        delBg.setAttribute('class', 'storymap-conn-delete-bg');
        delBg.setAttribute('r', 9);

        const delX = document.createElementNS(SVG_NS, 'text');
        delX.setAttribute('class', 'storymap-conn-delete-x');
        delX.textContent = '\u00d7';

        const stop = e => e.stopPropagation();
        const onDelete = e => {
            e.stopPropagation();
            if (handlers.onConnectionDelete) handlers.onConnectionDelete(conn.id);
        };
        [delBg, delX].forEach(node => {
            node.addEventListener('pointerdown', stop);
            node.addEventListener('click', onDelete);
        });

        group.appendChild(hit);
        group.appendChild(line);
        group.appendChild(delBg);
        group.appendChild(delX);
        return group;
    }

    function typeLabel(type) {
        return TYPE_LABELS[type] || type;
    }

    function buildBoxEl(box) {
        const el = document.createElement('div');
        el.className = `storymap-box storymap-box-${box.type}`;
        el.dataset.id = box.id;
        el.style.left = box.x + 'px';
        el.style.top = box.y + 'px';

        const linkedEntries = handlers.resolveLinks ? handlers.resolveLinks(box) : [];
        const dialogueCount = Array.isArray(box.dialogues) ? box.dialogues.length : 0;
        const maxChips = 4;
        const shown = linkedEntries.slice(0, maxChips);
        const extra = linkedEntries.length - shown.length;

        const linksRowHtml = linkedEntries.length
            ? `<div class="storymap-box-links-row">
                ${shown.map(entry => `<button type="button" class="storymap-link-chip" data-open-category="${escapeHtml(entry.category)}" data-open-id="${entry.id}" title="Open ${escapeHtml(entry.label)}">${escapeHtml(entry.label)}</button>`).join('')}
                ${extra > 0 ? `<button type="button" class="storymap-link-chip storymap-link-chip-more" data-action="links">+${extra} more</button>` : ''}
               </div>`
            : '';

        el.innerHTML = `
            <div class="storymap-box-header">
                <span class="storymap-box-type-badge">${escapeHtml(typeLabel(box.type))}</span>
                <div class="storymap-box-header-actions">
                    <button type="button" class="btn-icon storymap-box-action" data-action="duplicate" title="Duplicate box">Dup</button>
                    <button type="button" class="btn-icon delete storymap-box-action" data-action="delete" title="Delete box">&times;</button>
                </div>
            </div>
            <div class="storymap-box-title">${escapeHtml(box.title)}</div>
            ${box.description ? `<div class="storymap-box-desc">${escapeHtml(box.description)}</div>` : ''}
            ${box.tags && box.tags.length ? `<div class="storymap-box-tags">${box.tags.map(t => `<span class="tag-pill storymap-tag-pill">${escapeHtml(t)}</span>`).join('')}</div>` : ''}
            ${linksRowHtml}
            <div class="storymap-box-btn-row">
                <button type="button" class="storymap-box-links-btn" data-action="links">${linkedEntries.length ? 'Manage links' : '+ Link entries'}</button>
                ${box.type === 'chapter' ? `<button type="button" class="storymap-box-dialogue-btn" data-action="dialogue">${dialogueCount > 0 ? `Dialogue (${dialogueCount})` : '+ Dialogue'}</button>` : ''}
            </div>
            <div class="storymap-connector storymap-connector-in" title="Connection target"></div>
            <div class="storymap-connector storymap-connector-out" title="Drag to another box to connect"></div>
        `;
        return el;
    }

    function startDrag(e, boxId) {
        if (e.button !== undefined && e.button !== 0) return;
        e.stopPropagation();

        const boxEl = boxEls.get(boxId);
        const box = boxData.get(boxId);
        if (!boxEl || !box) return;

        const startClientX = e.clientX;
        const startClientY = e.clientY;
        const startX = box.x;
        const startY = box.y;
        let moved = false;

        boxEl.setPointerCapture(e.pointerId);
        boxEl.classList.add('storymap-box-dragging');

        function onMove(ev) {
            const dx = (ev.clientX - startClientX) / viewport.zoom;
            const dy = (ev.clientY - startClientY) / viewport.zoom;
            if (!moved && (Math.abs(dx) > DRAG_THRESHOLD || Math.abs(dy) > DRAG_THRESHOLD)) moved = true;
            box.x = startX + dx;
            box.y = startY + dy;
            boxEl.style.left = box.x + 'px';
            boxEl.style.top = box.y + 'px';
            refreshConnectionsTouching(boxId);
        }

        function onUp(ev) {
            boxEl.releasePointerCapture(e.pointerId);
            boxEl.classList.remove('storymap-box-dragging');
            boxEl.removeEventListener('pointermove', onMove);
            boxEl.removeEventListener('pointerup', onUp);
            if (moved) {
                if (handlers.onBoxDragEnd) handlers.onBoxDragEnd(boxId, box.x, box.y);
            } else if (handlers.onBoxClick) {
                handlers.onBoxClick(boxId);
            }
        }

        boxEl.addEventListener('pointermove', onMove);
        boxEl.addEventListener('pointerup', onUp);
    }

    function startConnect(e, boxId) {
        e.stopPropagation();
        e.preventDefault();

        const sourceEl = boxEls.get(boxId);
        const sourceBox = boxData.get(boxId);
        if (!sourceEl || !sourceBox) return;

        const anchor = getAnchor(sourceEl, sourceBox, 'bottom');
        const tempPath = document.createElementNS(SVG_NS, 'path');
        tempPath.setAttribute('class', 'storymap-conn-temp');
        svgEl.appendChild(tempPath);
        wrapEl.classList.add('storymap-connecting');

        function toWorld(clientX, clientY) {
            const rect = wrapEl.getBoundingClientRect();
            return {
                x: (clientX - rect.left - viewport.x) / viewport.zoom,
                y: (clientY - rect.top - viewport.y) / viewport.zoom
            };
        }

        function onMove(ev) {
            const p = toWorld(ev.clientX, ev.clientY);
            tempPath.setAttribute('d', bezierPath(anchor, p));
        }

        function onUp(ev) {
            document.removeEventListener('pointermove', onMove);
            document.removeEventListener('pointerup', onUp);
            tempPath.remove();
            wrapEl.classList.remove('storymap-connecting');

            const targetEl = document.elementFromPoint(ev.clientX, ev.clientY);
            const targetBoxEl = targetEl ? targetEl.closest('.storymap-box') : null;
            if (targetBoxEl) {
                const targetId = Number(targetBoxEl.dataset.id);
                if (targetId !== boxId && handlers.onConnectionCreate) {
                    handlers.onConnectionCreate(boxId, targetId);
                }
            }
        }

        document.addEventListener('pointermove', onMove);
        document.addEventListener('pointerup', onUp);
    }

    function wireBoxEvents(el, boxId) {
        el.addEventListener('pointerdown', (e) => {
            if (e.target.closest('[data-action]') || e.target.closest('.storymap-connector') || e.target.closest('[data-open-category]')) return;
            startDrag(e, boxId);
        });

        el.querySelectorAll('[data-action]').forEach(btn => {
            btn.addEventListener('pointerdown', e => e.stopPropagation());
            btn.addEventListener('click', e => {
                e.stopPropagation();
                const action = btn.dataset.action;
                if (action === 'duplicate' && handlers.onBoxDuplicate) handlers.onBoxDuplicate(boxId);
                if (action === 'delete' && handlers.onBoxDelete) handlers.onBoxDelete(boxId);
                if (action === 'links' && handlers.onBoxLinksClick) handlers.onBoxLinksClick(boxId);
                if (action === 'dialogue' && handlers.onBoxDialogueClick) handlers.onBoxDialogueClick(boxId);
            });
        });

        el.querySelectorAll('[data-open-category]').forEach(chip => {
            chip.addEventListener('pointerdown', e => e.stopPropagation());
            chip.addEventListener('click', e => {
                e.stopPropagation();
                if (handlers.onOpenLinkedEntry) {
                    handlers.onOpenLinkedEntry(chip.dataset.openCategory, Number(chip.dataset.openId));
                }
            });
        });

        const connOut = el.querySelector('.storymap-connector-out');
        connOut.addEventListener('pointerdown', e => startConnect(e, boxId));
    }

    function render(boxes, connections, matchIds) {
        boxData.clear();
        boxEls.clear();
        connEls.clear();
        connectionsByBox.clear();
        boxLayerEl.innerHTML = '';
        svgEl.querySelectorAll('.storymap-conn-group').forEach(n => n.remove());

        emptyStateEl.style.display = boxes.length === 0 ? 'flex' : 'none';

        boxes.forEach(box => {
            boxData.set(box.id, box);
            const el = buildBoxEl(box);
            boxLayerEl.appendChild(el);
            boxEls.set(box.id, el);
            wireBoxEvents(el, box.id);
        });

        connections.forEach(conn => {
            if (!boxData.has(conn.from) || !boxData.has(conn.to)) return;
            const group = buildConnectionEl(conn);
            svgEl.appendChild(group);
            connEls.set(conn.id, group);
            addToIndex(connectionsByBox, conn.from, conn.id);
            addToIndex(connectionsByBox, conn.to, conn.id);
            refreshConnection(group);
        });

        setMatchState(matchIds);
    }

    function setMatchState(matchIds) {
        boxEls.forEach((el, id) => {
            if (!matchIds) {
                el.classList.remove('storymap-box-dimmed');
            } else {
                el.classList.toggle('storymap-box-dimmed', !matchIds.has(id));
            }
        });
    }

    function zoomAt(screenX, screenY, factor) {
        const newZoom = clamp(viewport.zoom * factor, MIN_ZOOM, MAX_ZOOM);
        const worldX = (screenX - viewport.x) / viewport.zoom;
        const worldY = (screenY - viewport.y) / viewport.zoom;
        viewport.zoom = newZoom;
        viewport.x = screenX - worldX * newZoom;
        viewport.y = screenY - worldY * newZoom;
        applyTransform();
        schedulePersist();
    }

    function zoomAtCenter(factor) {
        const rect = wrapEl.getBoundingClientRect();
        zoomAt(rect.width / 2, rect.height / 2, factor);
    }

    wrapEl.addEventListener('wheel', (e) => {
        e.preventDefault();
        const rect = wrapEl.getBoundingClientRect();
        const factor = Math.exp(-e.deltaY * 0.001);
        zoomAt(e.clientX - rect.left, e.clientY - rect.top, factor);
    }, { passive: false });

    wrapEl.addEventListener('pointerdown', (e) => {
        if (e.button !== 0) return;
        const startClientX = e.clientX;
        const startClientY = e.clientY;
        const startVX = viewport.x;
        const startVY = viewport.y;
        wrapEl.setPointerCapture(e.pointerId);
        wrapEl.classList.add('storymap-panning');

        function onMove(ev) {
            viewport.x = startVX + (ev.clientX - startClientX);
            viewport.y = startVY + (ev.clientY - startClientY);
            applyTransform();
        }
        function onUp() {
            wrapEl.releasePointerCapture(e.pointerId);
            wrapEl.classList.remove('storymap-panning');
            wrapEl.removeEventListener('pointermove', onMove);
            wrapEl.removeEventListener('pointerup', onUp);
            schedulePersist();
        }
        wrapEl.addEventListener('pointermove', onMove);
        wrapEl.addEventListener('pointerup', onUp);
    });

    return {
        render,
        setMatchState,
        setInitialViewport(v) {
            viewport = { x: 40, y: 40, zoom: 1, ...v };
            applyTransform();
        },
        getViewport() {
            return { ...viewport };
        },
        getViewportCenterWorld() {
            const rect = wrapEl.getBoundingClientRect();
            return {
                x: (rect.width / 2 - viewport.x) / viewport.zoom,
                y: (rect.height / 2 - viewport.y) / viewport.zoom
            };
        },
        zoomIn() { zoomAtCenter(1.2); },
        zoomOut() { zoomAtCenter(1 / 1.2); },
        resetView() {
            viewport = { x: 40, y: 40, zoom: 1 };
            applyTransform();
            schedulePersist();
        }
    };
}
