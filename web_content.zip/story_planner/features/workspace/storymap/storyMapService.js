import { storyService } from '../story/storyService.js';
import { createId } from '../../shared/id.js';

// Box types available on the canvas, in the order they should appear in pickers.
export const BOX_TYPES = ['chapter', 'scene', 'event', 'decision', 'idea', 'milestone'];

// Categories of existing Story Planner entries a box can link out to.
export const LINK_CATEGORIES = ['characters', 'locations', 'chapters', 'lore', 'factions', 'ideas'];

function emptyLinks() {
    return { characters: [], locations: [], chapters: [], lore: [], factions: [], ideas: [] };
}

function normalizeLinks(links) {
    const normalized = emptyLinks();
    if (!links) return normalized;
    LINK_CATEGORIES.forEach(cat => {
        if (Array.isArray(links[cat])) normalized[cat] = [...links[cat]];
    });
    return normalized;
}

function ensureStoryMap(story) {
    if (!story.storyMap) {
        story.storyMap = { boxes: [], connections: [], viewport: { x: 0, y: 0, zoom: 1 } };
    }
    if (!Array.isArray(story.storyMap.boxes)) story.storyMap.boxes = [];
    if (!Array.isArray(story.storyMap.connections)) story.storyMap.connections = [];
    if (!story.storyMap.viewport) story.storyMap.viewport = { x: 0, y: 0, zoom: 1 };

    // Backfill older boxes saved before a field existed.
    story.storyMap.boxes.forEach(box => {
        if (!box.links) box.links = emptyLinks();
        if (!Array.isArray(box.tags)) box.tags = [];
        if (!Array.isArray(box.dialogues)) box.dialogues = [];
    });

    return story.storyMap;
}

export const storyMapService = {
    BOX_TYPES,
    LINK_CATEGORIES,

    getStoryMap() {
        const story = storyService.getCurrentStory();
        if (!story) return { boxes: [], connections: [], viewport: { x: 0, y: 0, zoom: 1 } };
        return ensureStoryMap(story);
    },

    getBoxes() {
        return this.getStoryMap().boxes;
    },

    getBoxById(id) {
        return this.getBoxes().find(b => b.id === id) || null;
    },

    getConnections() {
        return this.getStoryMap().connections;
    },

    getViewport() {
        return this.getStoryMap().viewport;
    },

    setViewport(viewport) {
        const story = storyService.getCurrentStory();
        if (!story) return;
        const map = ensureStoryMap(story);
        map.viewport = { ...map.viewport, ...viewport };
        storyService.updateStoryDetails({});
    },

    addBox(data = {}) {
        const story = storyService.getCurrentStory();
        if (!story) return null;
        const map = ensureStoryMap(story);

        const newBox = {
            id: createId(),
            type: BOX_TYPES.includes(data.type) ? data.type : 'chapter',
            title: (data.title || 'Untitled Box').trim(),
            description: data.description || '',
            tags: Array.isArray(data.tags) ? data.tags : [],
            x: typeof data.x === 'number' ? data.x : 80,
            y: typeof data.y === 'number' ? data.y : 80,
            links: emptyLinks(),
            dialogues: [],
            createdAt: Date.now()
        };

        map.boxes.push(newBox);
        storyService.updateStoryDetails({});
        return newBox;
    },

    updateBox(id, updatedData) {
        const map = this.getStoryMap();
        const index = map.boxes.findIndex(b => b.id === id);
        if (index === -1) return false;
        map.boxes[index] = { ...map.boxes[index], ...updatedData };
        storyService.updateStoryDetails({});
        return true;
    },

    updateBoxLinks(id, links) {
        const map = this.getStoryMap();
        const box = map.boxes.find(b => b.id === id);
        if (!box) return false;
        box.links = normalizeLinks(links);
        storyService.updateStoryDetails({});
        return true;
    },

    // =========================================================
    // DIALOGUE — chapter boxes can hold a running list of dialogue lines
    // (who's speaking + what they say) right on the story map.
    // =========================================================
    getDialogues(id) {
        const box = this.getBoxById(id);
        return box ? (box.dialogues || []) : [];
    },

    addDialogueLine(id, data = {}) {
        const map = this.getStoryMap();
        const box = map.boxes.find(b => b.id === id);
        if (!box) return null;
        if (!Array.isArray(box.dialogues)) box.dialogues = [];

        const line = {
            id: createId(),
            speaker: (data.speaker || '').trim(),
            line: (data.line || '').trim(),
            createdAt: Date.now()
        };
        box.dialogues.push(line);
        storyService.updateStoryDetails({});
        return line;
    },

    updateDialogueLine(id, lineId, data = {}) {
        const box = this.getBoxById(id);
        if (!box || !Array.isArray(box.dialogues)) return false;
        const line = box.dialogues.find(d => d.id === lineId);
        if (!line) return false;
        if (typeof data.speaker === 'string') line.speaker = data.speaker.trim();
        if (typeof data.line === 'string') line.line = data.line.trim();
        storyService.updateStoryDetails({});
        return true;
    },

    deleteDialogueLine(id, lineId) {
        const box = this.getBoxById(id);
        if (!box || !Array.isArray(box.dialogues)) return false;
        box.dialogues = box.dialogues.filter(d => d.id !== lineId);
        storyService.updateStoryDetails({});
        return true;
    },

    reorderDialogueLines(id, orderedLineIds) {
        const box = this.getBoxById(id);
        if (!box || !Array.isArray(box.dialogues)) return false;
        const byId = new Map(box.dialogues.map(d => [d.id, d]));
        const reordered = orderedLineIds.map(lid => byId.get(lid)).filter(Boolean);
        // Keep anything not mentioned (shouldn't happen) appended at the end.
        box.dialogues.forEach(d => { if (!orderedLineIds.includes(d.id)) reordered.push(d); });
        box.dialogues = reordered;
        storyService.updateStoryDetails({});
        return true;
    },

    // Position updates happen constantly while dragging; keep this cheap and silent.
    updateBoxPosition(id, x, y) {
        const map = this.getStoryMap();
        const box = map.boxes.find(b => b.id === id);
        if (!box) return false;
        box.x = x;
        box.y = y;
        storyService.updateStoryDetails({});
        return true;
    },

    duplicateBox(id) {
        const map = this.getStoryMap();
        const box = map.boxes.find(b => b.id === id);
        if (!box) return null;

        const copy = {
            ...box,
            id: createId(),
            title: `${box.title} (Copy)`,
            x: box.x + 36,
            y: box.y + 36,
            tags: [...(box.tags || [])],
            links: normalizeLinks(box.links),
            dialogues: (box.dialogues || []).map(d => ({ ...d, id: createId() })),
            createdAt: Date.now()
        };

        map.boxes.push(copy);
        storyService.updateStoryDetails({});
        return copy;
    },

    deleteBox(id) {
        const map = this.getStoryMap();
        map.boxes = map.boxes.filter(b => b.id !== id);
        map.connections = map.connections.filter(c => c.from !== id && c.to !== id);
        storyService.updateStoryDetails({});
        return true;
    },

    addConnection(fromId, toId) {
        if (!fromId || !toId || fromId === toId) return null;
        const map = this.getStoryMap();

        const fromExists = map.boxes.some(b => b.id === fromId);
        const toExists = map.boxes.some(b => b.id === toId);
        if (!fromExists || !toExists) return null;

        const alreadyExists = map.connections.some(c => c.from === fromId && c.to === toId);
        if (alreadyExists) return null;

        const connection = { id: createId(), from: fromId, to: toId };
        map.connections.push(connection);
        storyService.updateStoryDetails({});
        return connection;
    },

    deleteConnection(id) {
        const map = this.getStoryMap();
        map.connections = map.connections.filter(c => c.id !== id);
        storyService.updateStoryDetails({});
        return true;
    },

    // Returns the set of box ids that match the given free-text query and filters.
    // Used to highlight/dim boxes on the canvas rather than hiding them outright.
    matchingBoxIds(query, filters = {}) {
        const boxes = this.getBoxes();
        const q = (query || '').trim().toLowerCase();
        const types = Array.isArray(filters.types) ? new Set(filters.types) : null;
        const { characterId, locationId, chapterId } = filters;

        const matched = boxes.filter(box => {
            if (types && !types.has(box.type)) return false;
            if (characterId && !(box.links.characters || []).includes(characterId)) return false;
            if (locationId && !(box.links.locations || []).includes(locationId)) return false;
            if (chapterId && !(box.links.chapters || []).includes(chapterId)) return false;

            if (!q) return true;
            const titleMatch = (box.title || '').toLowerCase().includes(q);
            const descMatch = (box.description || '').toLowerCase().includes(q);
            const tagMatch = (box.tags || []).some(t => t.toLowerCase().includes(q));
            return titleMatch || descMatch || tagMatch;
        });

        return new Set(matched.map(b => b.id));
    },

    // Cascade helpers — called from other features' delete methods so a deleted
    // character/location/chapter/etc. is unlinked from every box that referenced it.
    untagEverywhere(category, id) {
        if (!LINK_CATEGORIES.includes(category)) return;
        const story = storyService.getCurrentStory();
        if (!story || !story.storyMap || !story.storyMap.boxes) return;
        story.storyMap.boxes.forEach(box => {
            if (box.links && Array.isArray(box.links[category])) {
                box.links[category] = box.links[category].filter(refId => refId !== id);
            }
        });
        storyService.updateStoryDetails({});
    }
};
