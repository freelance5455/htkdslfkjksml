import { storyMapService, BOX_TYPES } from './storyMapService.js';
import { storyMapUi } from './storyMapUi.js';
import { createStoryMapCanvas } from './storyMapCanvas.js';
import { storyService } from '../story/storyService.js';
import { storyUi } from '../story/storyUi.js';
import { chapterService } from '../chapter/chapterService.js';
import { openChapterById } from '../chapter/chapterController.js';
import { openCharacterById } from '../character/characterController.js';
import { locationService } from '../../worldbuilding/location/locationService.js';
import { openLocationById } from '../../worldbuilding/location/locationController.js';
import { loreService } from '../../worldbuilding/lore/loreService.js';
import { openLoreById } from '../../worldbuilding/lore/loreController.js';
import { factionService } from '../../worldbuilding/faction/factionService.js';
import { openFactionById } from '../../worldbuilding/faction/factionController.js';
import { ideaService } from '../../other/idea/ideaService.js';
import { openIdeaById } from '../../other/idea/ideaController.js';

let canvas = null;
let pendingNewBoxPos = null;
let addCascadeCount = 0;

function getCharacters() {
    const story = storyService.getCurrentStory();
    return story ? (story.characters || []) : [];
}

function getRefData() {
    return {
        characters: getCharacters(),
        locations: locationService.getLocations(),
        chapters: chapterService.getChapters(),
        lore: loreService.getLore(),
        factions: factionService.getFactions(),
        ideas: ideaService.getIdeas()
    };
}

// Resolves a box's linked ids into display-ready {category, id, label} entries
// for the clickable chips shown directly on the box.
function resolveLinks(box) {
    const refData = getRefData();
    const lookups = {
        characters: { list: refData.characters, labelKey: 'name' },
        locations: { list: refData.locations, labelKey: 'title' },
        chapters: { list: refData.chapters, labelKey: 'title' },
        lore: { list: refData.lore, labelKey: 'title' },
        factions: { list: refData.factions, labelKey: 'title' },
        ideas: { list: refData.ideas, labelKey: 'title' }
    };

    const entries = [];
    Object.keys(lookups).forEach(category => {
        const ids = (box.links && box.links[category]) || [];
        const { list, labelKey } = lookups[category];
        ids.forEach(id => {
            const item = list.find(i => i.id === id);
            if (item) entries.push({ category, id, label: item[labelKey] });
        });
    });
    return entries;
}

function navigateToLinkedEntry(category, id) {
    const tabByCategory = {
        characters: 'characters',
        locations: 'locations',
        chapters: 'chapters',
        lore: 'lore',
        factions: 'factions',
        ideas: 'ideas'
    };
    const tabName = tabByCategory[category];
    if (!tabName) return;

    storyUi.switchTab(tabName);

    if (category === 'characters') {
        openCharacterById(id);
    } else if (category === 'locations') {
        openLocationById(id);
    } else if (category === 'chapters') {
        openChapterById(id);
    } else if (category === 'lore') {
        openLoreById(id);
    } else if (category === 'factions') {
        openFactionById(id);
    } else if (category === 'ideas') {
        openIdeaById(id);
    }
}

function refreshRender() {
    const map = storyMapService.getStoryMap();
    canvas.render(map.boxes, map.connections, computeMatchIds());
}

function refreshFilterOptions() {
    storyMapUi.populateEntityFilters(getRefData());
}

function computeMatchIds() {
    const els = storyMapUi.elements;
    const query = els.searchInput ? els.searchInput.value : '';
    const types = storyMapUi.getActiveTypeFilters();
    const characterId = els.characterFilter && els.characterFilter.value ? Number(els.characterFilter.value) : null;
    const locationId = els.locationFilter && els.locationFilter.value ? Number(els.locationFilter.value) : null;
    const chapterId = els.chapterFilter && els.chapterFilter.value ? Number(els.chapterFilter.value) : null;

    const hasQuery = query.trim().length > 0;
    const hasTypeFilter = types.length < BOX_TYPES.length;
    const hasEntityFilter = !!(characterId || locationId || chapterId);

    if (!hasQuery && !hasTypeFilter && !hasEntityFilter) return null;

    return storyMapService.matchingBoxIds(query, { types, characterId, locationId, chapterId });
}

function applyFilters() {
    updateFilterDot();
    if (!canvas) return;
    canvas.setMatchState(computeMatchIds());
}

// =========================================================
// BOX MODAL
// =========================================================
function handleAddBoxClick() {
    const center = canvas.getViewportCenterWorld();
    // Place consecutive additions in a small grid so they never stack exactly
    // on top of each other (a diagonal nudge alone isn't enough to clear a box's own size).
    const GRID_COLS = 3;
    const col = addCascadeCount % GRID_COLS;
    const row = Math.floor(addCascadeCount / GRID_COLS) % GRID_COLS;
    addCascadeCount += 1;
    pendingNewBoxPos = { x: center.x + col * 260, y: center.y + row * 150 };
    storyMapUi.openBoxModal();
}

function handleBoxSave(e) {
    e.preventDefault();
    const formData = storyMapUi.getBoxFormData();

    if (!formData.title) {
        alert('Please enter a title for the box.');
        return;
    }

    if (formData.id) {
        storyMapService.updateBox(formData.id, {
            title: formData.title,
            type: formData.type,
            description: formData.description,
            tags: formData.tags
        });
    } else {
        const pos = pendingNewBoxPos || { x: 80, y: 80 };
        storyMapService.addBox({
            title: formData.title,
            type: formData.type,
            description: formData.description,
            tags: formData.tags,
            x: Math.round(pos.x - 110),
            y: Math.round(pos.y - 40)
        });
    }

    storyMapUi.closeBoxModal();
    refreshRender();
}

function handleBoxClick(id) {
    const box = storyMapService.getBoxById(id);
    if (!box) return;
    storyMapUi.openBoxModal(box);
}

function handleBoxDuplicate(id) {
    storyMapService.duplicateBox(id);
    refreshRender();
}

function handleBoxDelete(id) {
    if (!confirm('Delete this box? Its connections will be removed too. This cannot be undone.')) return;
    storyMapService.deleteBox(id);
    refreshRender();
}

function handleBoxDragEnd(id, x, y) {
    storyMapService.updateBoxPosition(id, Math.round(x), Math.round(y));
}

// =========================================================
// LINK MODAL
// =========================================================
function handleBoxLinksClick(id) {
    const box = storyMapService.getBoxById(id);
    if (!box) return;

    storyMapUi.openLinkModal(box, getRefData());

    const els = storyMapUi.elements;
    const onSave = () => {
        const links = storyMapUi.readLinkModal();
        storyMapService.updateBoxLinks(id, links);
        storyMapUi.closeLinkModal();
        refreshRender();
        cleanup();
    };
    const onCancel = () => {
        storyMapUi.closeLinkModal();
        cleanup();
    };
    function cleanup() {
        els.linkSaveBtn.removeEventListener('click', onSave);
        els.linkCancelBtn.removeEventListener('click', onCancel);
    }
    els.linkSaveBtn.addEventListener('click', onSave);
    els.linkCancelBtn.addEventListener('click', onCancel);
}

// =========================================================
// DIALOGUE MODAL (chapter boxes only)
// =========================================================
function handleBoxDialogueClick(id) {
    const box = storyMapService.getBoxById(id);
    if (!box || box.type !== 'chapter') return;

    storyMapUi.populateDialogueSpeakerOptions(getCharacters());
    storyMapUi.openDialogueModal(box);

    const renderList = () => {
        const current = storyMapService.getDialogues(id);
        storyMapUi.renderDialogueList(current, {
            onChange: (lineId, data) => {
                storyMapService.updateDialogueLine(id, lineId, data);
                refreshRender();
            },
            onDelete: (lineId) => {
                storyMapService.deleteDialogueLine(id, lineId);
                renderList();
                refreshRender();
            }
        });
    };
    renderList();

    const els = storyMapUi.elements;
    const onAddLine = () => {
        storyMapService.addDialogueLine(id, { speaker: '', line: '' });
        renderList();
        storyMapUi.focusLastDialogueLine();
        refreshRender();
    };
    const onClose = () => {
        storyMapUi.closeDialogueModal();
        cleanup();
    };
    function cleanup() {
        els.dialogueAddLineBtn.removeEventListener('click', onAddLine);
        els.dialogueCancelBtn.removeEventListener('click', onClose);
    }
    els.dialogueAddLineBtn.addEventListener('click', onAddLine);
    els.dialogueCancelBtn.addEventListener('click', onClose);
}

// =========================================================
// CONNECTIONS
// =========================================================
function handleConnectionCreate(fromId, toId) {
    const created = storyMapService.addConnection(fromId, toId);
    if (created) refreshRender();
}

function handleConnectionDelete(id) {
    storyMapService.deleteConnection(id);
    refreshRender();
}

// =========================================================
// INIT / LOAD
// =========================================================
export function initStoryMapFeature() {
    const els = storyMapUi.elements;

    canvas = createStoryMapCanvas(
        { wrapEl: els.wrap, worldEl: els.world, svgEl: els.svg, boxLayerEl: els.boxLayer, emptyStateEl: els.emptyState },
        {
            resolveLinks,
            onBoxClick: handleBoxClick,
            onBoxDuplicate: handleBoxDuplicate,
            onBoxDelete: handleBoxDelete,
            onBoxLinksClick: handleBoxLinksClick,
            onBoxDialogueClick: handleBoxDialogueClick,
            onBoxDragEnd: handleBoxDragEnd,
            onConnectionCreate: handleConnectionCreate,
            onConnectionDelete: handleConnectionDelete,
            onOpenLinkedEntry: navigateToLinkedEntry,
            onViewportChange: (viewport) => {
                addCascadeCount = 0;
                storyMapService.setViewport(viewport);
            }
        }
    );

    if (els.addBtn) els.addBtn.addEventListener('click', handleAddBoxClick);
    if (els.boxCancelBtn) els.boxCancelBtn.addEventListener('click', () => storyMapUi.closeBoxModal());
    if (els.boxForm) els.boxForm.addEventListener('submit', handleBoxSave);


    if (els.searchInput) els.searchInput.addEventListener('input', applyFilters);
    if (els.characterFilter) els.characterFilter.addEventListener('change', applyFilters);
    if (els.locationFilter) els.locationFilter.addEventListener('change', applyFilters);
    if (els.chapterFilter) els.chapterFilter.addEventListener('change', applyFilters);
    if (els.filterBtn && els.filterDropdown) {
        const setOpen = (open) => {
            els.filterDropdown.hidden = !open;
            els.filterBtn.setAttribute('aria-expanded', String(open));
            if (els.filterMenu) els.filterMenu.classList.toggle('open', open);
        };
        els.filterBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            setOpen(els.filterDropdown.hidden);
        });
        els.filterDropdown.addEventListener('click', (e) => e.stopPropagation());
        if (els.filterDoneBtn) els.filterDoneBtn.addEventListener('click', () => setOpen(false));
        document.addEventListener('click', () => setOpen(false));
        document.addEventListener('keydown', (e) => { if (e.key === 'Escape') setOpen(false); });
    }
    if (els.clearFiltersBtn) {
        els.clearFiltersBtn.addEventListener('click', () => {
            storyMapUi.resetFilters();
            updateFilterDot();
            applyFilters();
        });
    }
    if (els.typeFilters) {
        els.typeFilters.addEventListener('click', (e) => {
            const btn = e.target.closest('[data-type]');
            if (!btn) return;
            btn.classList.toggle('active');
            updateFilterDot();
            applyFilters();
        });
    }
}

export function loadStoryMapTab() {
    storyMapUi.resetFilters();
    updateFilterDot();
    refreshFilterOptions();
    addCascadeCount = 0;

    const map = storyMapService.getStoryMap();
    canvas.setInitialViewport(map.viewport);
    canvas.render(map.boxes, map.connections, null);
}

// Badge on the filter icon: how many filters are currently narrowing the map.
function updateFilterDot() {
    const els = storyMapUi.elements;
    if (!els.filterDot) return;
    let count = 0;
    [els.characterFilter, els.locationFilter, els.chapterFilter].forEach(sel => {
        if (sel && sel.value) count++;
    });
    if (els.typeFilters && els.typeFilters.querySelector('[data-type]:not(.active)')) count++;
    els.filterDot.textContent = String(count);
    els.filterDot.hidden = count === 0;
}
