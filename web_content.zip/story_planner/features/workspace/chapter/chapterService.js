import { storyService } from '../story/storyService.js';
import { createId } from '../../shared/id.js';

export const chapterService = {
    getChapters() {
        const story = storyService.getCurrentStory();
        return story ? (story.chapters || []) : [];
    },

    getChapterById(id) {
        return this.getChapters().find(c => c.id === id) || null;
    },

    addChapter(data) {
        const story = storyService.getCurrentStory();
        if (!story) return null;
        if (!story.chapters) story.chapters = [];

        const newChapter = {
            id: createId(),
            title: data.title,
            content: data.content || '',
            characterIds: data.characterIds || [],
            createdAt: Date.now()
        };

        story.chapters.push(newChapter);
        storyService.updateStoryDetails({});
        return newChapter;
    },

    updateChapter(id, updatedData) {
        const story = storyService.getCurrentStory();
        if (!story || !story.chapters) return false;

        const index = story.chapters.findIndex(c => c.id === id);
        if (index === -1) return false;

        story.chapters[index] = { ...story.chapters[index], ...updatedData };
        storyService.updateStoryDetails({});
        return true;
    },

    deleteChapter(id) {
        const story = storyService.getCurrentStory();
        if (!story || !story.chapters) return false;

        story.chapters = story.chapters.filter(c => c.id !== id);

        // Cascade: remove this chapter's id from anything that tagged it
        (story.arcs || []).forEach(a => {
            if (a.chapterIds) a.chapterIds = a.chapterIds.filter(cid => cid !== id);
        });
        (story.locations || []).forEach(l => {
            if (l.chapterIds) l.chapterIds = l.chapterIds.filter(cid => cid !== id);
        });
        (story.timeline || []).forEach(t => {
            if (t.chapterIds) t.chapterIds = t.chapterIds.filter(cid => cid !== id);
        });
        (story.ideas || []).forEach(i => {
            if (i.chapterIds) i.chapterIds = i.chapterIds.filter(cid => cid !== id);
        });

        // Cascade cleanup: unlink this chapter from any Story Map boxes that referenced it
        if (story.storyMap && story.storyMap.boxes) {
            story.storyMap.boxes.forEach(box => {
                if (box.links && box.links.chapters) {
                    box.links.chapters = box.links.chapters.filter(cid => cid !== id);
                }
            });
        }

        storyService.updateStoryDetails({});
        return true;
    },

    // Remove a character id from every chapter that tagged it (called on character delete)
    untagCharacterEverywhere(characterId) {
        const story = storyService.getCurrentStory();
        if (!story || !story.chapters) return;
        story.chapters.forEach(ch => {
            if (ch.characterIds) ch.characterIds = ch.characterIds.filter(id => id !== characterId);
        });
        storyService.updateStoryDetails({});
    },

    searchChapters(query, mode = 'all') {
        const chapters = this.getChapters();
        const q = (query || '').trim().toLowerCase();
        if (!q) return chapters;

        const story = storyService.getCurrentStory();
        const characters = story ? (story.characters || []) : [];

        return chapters.filter(ch => {
            const titleMatch = ch.title.toLowerCase().includes(q);
            const taggedNames = (ch.characterIds || [])
                .map(id => characters.find(c => c.id === id))
                .filter(Boolean)
                .map(c => c.name.toLowerCase());
            const characterMatch = taggedNames.some(n => n.includes(q));

            if (mode === 'title') return titleMatch;
            if (mode === 'character') return characterMatch;
            return titleMatch || characterMatch;
        });
    }
};
