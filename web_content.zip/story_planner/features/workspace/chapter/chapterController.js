import { chapterService } from './chapterService.js';
import { chapterUi } from './chapterUi.js';
import { storyService } from '../story/storyService.js';

let currentSearchQuery = '';
let currentSearchMode = 'all';
let contentEditMode = false;

function getCharacters() {
    const story = storyService.getCurrentStory();
    return story ? (story.characters || []) : [];
}

export function initChapterFeature() {
    attachEventListeners();
}

// Allows other features (arcs, locations, timeline) to jump straight into a chapter's detail view.
export function openChapterById(id) {
    handleOpenChapter(id);
}

export function loadChaptersTab() {
    currentSearchQuery = '';
    currentSearchMode = 'all';
    const els = chapterUi.elements;
    if (els.searchInput) els.searchInput.value = '';
    if (els.searchMode) els.searchMode.value = 'all';

    chapterUi.showListView();
    renderList();
}

function renderList() {
    const chapters = chapterService.searchChapters(currentSearchQuery, currentSearchMode);
    chapterUi.renderChapterGrid(chapters, getCharacters(), {
        onOpen: handleOpenChapter,
        onDelete: handleDeleteChapter
    });
}

function handleOpenChapter(id) {
    contentEditMode = false;
    const chapter = chapterService.getChapterById(id);
    if (!chapter) return;
    chapterUi.showDetailView();
    renderDetail(id);
}

function renderDetail(id) {
    const chapter = chapterService.getChapterById(id);
    if (!chapter) return;

    chapterUi.renderChapterDetail(chapter, getCharacters(), {
        onBack: () => {
            contentEditMode = false;
            chapterUi.showListView();
            renderList();
        },
        onDelete: handleDeleteChapter,
        onEditTitle: handleEditTitle,
        onManageTags: handleManageTags,
        onStartEditContent: () => {
            contentEditMode = true;
            renderDetail(id);
        },
        onCancelEditContent: () => {
            contentEditMode = false;
            renderDetail(id);
        },
        onSaveContent: handleSaveContent
    }, contentEditMode);
}

function handleSaveContent(id, content) {
    chapterService.updateChapter(id, { content });
    contentEditMode = false;
    renderDetail(id);
    chapterUi.flashSaveStatus('Saved!');
}

function handleEditTitle(chapter) {
    chapterUi.openModal(chapter);
}

function handleManageTags(chapter) {
    chapterUi.openCharacterTagModal(getCharacters(), chapter.characterIds || []);

    const els = chapterUi.elements;
    const onSave = () => {
        const characterIds = chapterUi.readCharacterTagModal();
        chapterService.updateChapter(chapter.id, { characterIds });
        chapterUi.closeCharacterTagModal();
        renderDetail(chapter.id);
        cleanup();
    };
    const onCancel = () => {
        chapterUi.closeCharacterTagModal();
        cleanup();
    };
    function cleanup() {
        els.tagSaveBtn.removeEventListener('click', onSave);
        els.tagCancelBtn.removeEventListener('click', onCancel);
    }
    els.tagSaveBtn.addEventListener('click', onSave);
    els.tagCancelBtn.addEventListener('click', onCancel);
}

function handleDeleteChapter(id) {
    if (!confirm('Delete this chapter? This cannot be undone.')) return;
    chapterService.deleteChapter(id);
    chapterUi.showListView();
    renderList();
}

function handleSaveChapter(e) {
    e.preventDefault();
    const formData = chapterUi.getFormData();

    if (!formData.title) {
        alert('Please enter a chapter title.');
        return;
    }

    let chapterId = formData.id;
    if (formData.id) {
        chapterService.updateChapter(formData.id, { title: formData.title });
    } else {
        const created = chapterService.addChapter(formData);
        chapterId = created.id;
    }

    chapterUi.closeModal();

    // If a detail view is open for this chapter, refresh it; otherwise refresh list
    const detailOpen = chapterUi.elements.detailView.style.display !== 'none';
    if (detailOpen) {
        renderDetail(chapterId);
    } else {
        renderList();
    }
}

function attachEventListeners() {
    const els = chapterUi.elements;

    if (els.addBtn) {
        els.addBtn.addEventListener('click', () => chapterUi.openModal());
    }
    if (els.cancelBtn) {
        els.cancelBtn.addEventListener('click', () => chapterUi.closeModal());
    }
    if (els.form) {
        els.form.addEventListener('submit', handleSaveChapter);
    }
    if (els.searchInput) {
        els.searchInput.addEventListener('input', (e) => {
            currentSearchQuery = e.target.value;
            renderList();
        });
    }
    if (els.searchMode) {
        els.searchMode.addEventListener('change', (e) => {
            currentSearchMode = e.target.value;
            renderList();
        });
    }
}
