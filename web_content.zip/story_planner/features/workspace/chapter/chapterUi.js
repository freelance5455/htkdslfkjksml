import { renderTagPicker, readTagPicker, wireTagPickerSearch } from '../../shared/tagPicker.js';

function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str || '';
    return div.innerHTML;
}

const editIconSvg = `<svg class="icon-inline" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <path d="M13.5 3.5l3 3L7 16H4v-3l9.5-9.5z" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/>
</svg>`;

export const chapterUi = {
    get elements() {
        return {
            listView: document.getElementById('chapterListView'),
            detailView: document.getElementById('chapterDetailView'),
            grid: document.getElementById('chapterGrid'),
            searchInput: document.getElementById('chapterSearchInput'),
            searchMode: document.getElementById('chapterSearchMode'),
            addBtn: document.getElementById('addChapterBtn'),

            modal: document.getElementById('chapterModal'),
            form: document.getElementById('chapterForm'),
            idInput: document.getElementById('chapterId'),
            titleInput: document.getElementById('chapterTitleInput'),
            cancelBtn: document.getElementById('cancelChapterModal'),

            tagModal: document.getElementById('chapterCharacterTagModal'),
            tagPicker: document.getElementById('chapterCharacterTagPicker'),
            tagSearchInput: document.getElementById('chapterCharacterTagSearchInput'),
            tagSaveBtn: document.getElementById('chapterCharacterTagSaveBtn'),
            tagCancelBtn: document.getElementById('chapterCharacterTagCancelBtn')
        };
    },

    showListView() {
        this.elements.listView.style.display = 'block';
        this.elements.detailView.style.display = 'none';
    },

    showDetailView() {
        this.elements.listView.style.display = 'none';
        this.elements.detailView.style.display = 'block';
    },

    renderChapterGrid(chapters, characters, handlers) {
        const grid = this.elements.grid;
        if (!grid) return;
        grid.innerHTML = '';

        if (!chapters || chapters.length === 0) {
            grid.innerHTML = `<div class="empty-inline">No chapters yet. Click "+ Add Chapter" to start writing.</div>`;
            return;
        }

        chapters.forEach((ch, i) => {
            const card = document.createElement('div');
            card.className = 'entity-card';

            const taggedNames = (ch.characterIds || [])
                .map(id => characters.find(c => c.id === id))
                .filter(Boolean);

            const snippet = (ch.content || '').replace(/\s+/g, ' ').trim();

            card.innerHTML = `
                <div class="entity-card-top">
                    <span class="entity-index">CH. ${i + 1}</span>
                </div>
                <h3 class="entity-title">${escapeHtml(ch.title)}</h3>
                <p class="entity-desc">${snippet ? escapeHtml(snippet).slice(0, 140) + (snippet.length > 140 ? '…' : '') : 'No content written yet.'}</p>
                <div class="entity-tags">
                    ${taggedNames.length
                        ? taggedNames.map(c => `<span class="tag-pill">${escapeHtml(c.name)}</span>`).join('')
                        : `<span class="tag-chip-empty">No character tagged</span>`}
                </div>
                <div class="entity-actions">
                    <button class="btn-icon open-btn">Open</button>
                    <button class="btn-icon delete delete-btn">Delete</button>
                </div>
            `;

            card.querySelector('.open-btn').addEventListener('click', () => handlers.onOpen(ch.id));
            card.querySelector('.delete-btn').addEventListener('click', () => handlers.onDelete(ch.id));
            grid.appendChild(card);
        });
    },

    // contentEditing: whether the content block should render as an editable textarea right now
    renderChapterDetail(chapter, characters, handlers, contentEditing = false) {
        const view = this.elements.detailView;
        if (!view) return;

        const taggedIds = chapter.characterIds || [];
        const taggedNames = taggedIds
            .map(id => characters.find(c => c.id === id))
            .filter(Boolean);

        const hasContent = !!(chapter.content && chapter.content.trim());

        view.innerHTML = `
            <div class="detail-back" id="chapterBackBtn">← Back to Chapters</div>
            <div class="detail-title-row">
                <h1 class="entity-title-lg">${escapeHtml(chapter.title)}</h1>
                <div class="detail-block-header-actions">
                    <button class="btn-icon content-edit-btn" id="chapterEditTitleBtn">${editIconSvg} Edit Title</button>
                    <button class="btn-icon delete" id="chapterDeleteBtn">Delete Chapter</button>
                </div>
            </div>

            <div class="detail-two-col">
                <div class="detail-main">
                    <div class="detail-block">
                        <div class="detail-block-header">
                            <h3>Chapter Content</h3>
                            <span class="save-status" id="chapterSaveStatus">All changes saved.</span>
                        </div>
                        ${contentEditing ? `
                            <textarea id="chapterContentEditor" class="content-editor" placeholder="Start writing this chapter...">${escapeHtml(chapter.content || '')}</textarea>
                            <div class="save-bar">
                                <button class="btn-icon" id="chapterCancelContentBtn">Cancel</button>
                                <button class="btn-primary" id="chapterSaveContentBtn">Save Content</button>
                            </div>
                        ` : `
                            <div class="content-display${hasContent ? '' : ' is-empty'}" id="chapterContentDisplay" role="button" tabindex="0">${hasContent ? escapeHtml(chapter.content) : 'No content written yet. Tap to start writing.'}</div>
                        `}
                    </div>
                </div>

                <div class="detail-side">
                    <div class="detail-block">
                        <div class="detail-block-header">
                            <h3>Tagged Characters</h3>
                            <button class="btn-icon" id="chapterManageTagsBtn">Manage Tags</button>
                        </div>
                        <div class="entity-tags" id="chapterTagChips">
                            ${taggedNames.length
                                ? taggedNames.map(c => `<span class="tag-pill">${escapeHtml(c.name)}</span>`).join('')
                                : `<div class="tag-chip-empty">No character tagged</div>`}
                        </div>
                    </div>
                </div>
            </div>
        `;

        view.querySelector('#chapterBackBtn').addEventListener('click', handlers.onBack);
        view.querySelector('#chapterDeleteBtn').addEventListener('click', () => handlers.onDelete(chapter.id));
        view.querySelector('#chapterEditTitleBtn').addEventListener('click', () => handlers.onEditTitle(chapter));
        view.querySelector('#chapterManageTagsBtn').addEventListener('click', () => handlers.onManageTags(chapter));

        if (contentEditing) {
            view.querySelector('#chapterSaveContentBtn').addEventListener('click', () => {
                const content = view.querySelector('#chapterContentEditor').value;
                handlers.onSaveContent(chapter.id, content);
            });
            view.querySelector('#chapterCancelContentBtn').addEventListener('click', () => handlers.onCancelEditContent());
        } else {
            const displayEl = view.querySelector('#chapterContentDisplay');
            const startEdit = () => handlers.onStartEditContent();
            displayEl.addEventListener('click', startEdit);
            displayEl.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); startEdit(); }
            });
        }
    },

    flashSaveStatus(message = 'Saved!') {
        const status = document.getElementById('chapterSaveStatus');
        if (!status) return;
        const original = 'All changes saved.';
        status.textContent = message;
        status.style.color = '#8b7cff';
        setTimeout(() => {
            status.textContent = original;
            status.style.color = '#666';
        }, 1800);
    },

    getFormData() {
        const els = this.elements;
        return {
            id: els.idInput?.value ? Number(els.idInput.value) : null,
            title: els.titleInput?.value.trim() || ''
        };
    },

    openModal(chapter = null) {
        const els = this.elements;
        this.clearForm();

        document.getElementById('chapterModalTitle').textContent = chapter ? 'Edit Chapter Title' : 'Add Chapter';

        if (chapter) {
            els.idInput.value = chapter.id;
            els.titleInput.value = chapter.title || '';
        }

        els.modal.style.display = 'flex';
        els.titleInput?.focus();
    },

    closeModal() {
        this.elements.modal.style.display = 'none';
        this.clearForm();
    },

    clearForm() {
        const els = this.elements;
        if (els.idInput) els.idInput.value = '';
        if (els.titleInput) els.titleInput.value = '';
    },

    // --- Manage-tagged-characters modal (searchable) ---
    openCharacterTagModal(characters, selectedIds) {
        const els = this.elements;
        const items = characters.map(c => ({ id: c.id, label: c.name, sublabel: c.role }));
        renderTagPicker(els.tagPicker, items, selectedIds, 'No characters created yet. Add characters first from the Characters tab.');
        wireTagPickerSearch(els.tagPicker, els.tagSearchInput, items, 'No characters created yet. Add characters first from the Characters tab.');
        els.tagModal.style.display = 'flex';
    },

    closeCharacterTagModal() {
        this.elements.tagModal.style.display = 'none';
    },

    readCharacterTagModal() {
        return readTagPicker(this.elements.tagPicker);
    },

    applySearchResults(chapters, characters, handlers) {
        this.renderChapterGrid(chapters, characters, handlers);
    }
};
