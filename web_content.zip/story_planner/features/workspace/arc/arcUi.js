import { renderTagPicker, readTagPicker, wireTagPickerSearch } from '../../shared/tagPicker.js';

function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str || '';
    return div.innerHTML;
}

export const arcUi = {
    get elements() {
        return {
            listView: document.getElementById('arcListView'),
            detailView: document.getElementById('arcDetailView'),
            grid: document.getElementById('arcGrid'),
            searchInput: document.getElementById('arcSearchInput'),
            addBtn: document.getElementById('addArcBtn'),

            modal: document.getElementById('arcModal'),
            form: document.getElementById('arcForm'),
            idInput: document.getElementById('arcId'),
            titleInput: document.getElementById('arcTitleInput'),
            descInput: document.getElementById('arcDescInput'),
            cancelBtn: document.getElementById('cancelArcModal')
        };
    },

    showListView() {
        this.elements.listView.style.display = 'block';
        this.elements.detailView.style.display = 'none';
    },

    showDetailView() {
        this.elements.listView.style.display = 'none';
        this.elements.detailView.style.display = 'block';
    },

    renderArcGrid(arcs, handlers) {
        const grid = this.elements.grid;
        if (!grid) return;
        grid.innerHTML = '';

        if (!arcs || arcs.length === 0) {
            grid.innerHTML = `<div class="empty-inline">No arcs yet. Click "+ Add Arc" to plan your first major arc.</div>`;
            return;
        }

        arcs.forEach((arc, i) => {
            const card = document.createElement('div');
            card.className = 'entity-card';
            card.innerHTML = `
                <div class="entity-card-top">
                    <span class="entity-index">ARC ${String(i + 1).padStart(2, '0')}</span>
                </div>
                <h3 class="entity-title">${escapeHtml(arc.title)}</h3>
                <p class="entity-desc">${escapeHtml(arc.description) || 'No description yet.'}</p>
                <div class="entity-meta-line">${(arc.chapterIds || []).length} chapter(s) linked</div>
                <div class="entity-actions">
                    <button class="btn-icon open-btn">Open</button>
                    <button class="btn-icon delete delete-btn">Delete</button>
                </div>
            `;
            card.querySelector('.open-btn').addEventListener('click', () => handlers.onOpen(arc.id));
            card.querySelector('.delete-btn').addEventListener('click', () => handlers.onDelete(arc.id));
            grid.appendChild(card);
        });
    },

    renderArcDetail(arc, taggedChapters, handlers) {
        const view = this.elements.detailView;
        if (!view) return;

        view.innerHTML = `
            <div class="detail-back" id="arcBackBtn">← Back to Arcs</div>
            <div class="detail-title-row">
                <h1 class="entity-title-lg">${escapeHtml(arc.title)}</h1>
                <div class="detail-block-header-actions">
                    <button class="btn-icon" id="arcEditBtn">Edit Arc</button>
                    <button class="btn-icon delete" id="arcDeleteBtn">Delete Arc</button>
                </div>
            </div>
            <p class="detail-description">${escapeHtml(arc.description) || 'No description yet.'}</p>

            <div class="detail-block">
                <div class="detail-block-header">
                    <h3>Chapters in this Arc</h3>
                    <button class="btn-icon" id="arcManageChaptersBtn">+ Add / Manage Chapters</button>
                </div>
                <div class="search-bar search-bar-inline">
                    <input type="text" id="arcChapterSearchInput" placeholder="Search chapters in this arc...">
                </div>
                <div class="list-of-links" id="arcChapterList"></div>
            </div>
        `;

        view.querySelector('#arcBackBtn').addEventListener('click', handlers.onBack);
        view.querySelector('#arcEditBtn').addEventListener('click', () => handlers.onEdit(arc));
        view.querySelector('#arcDeleteBtn').addEventListener('click', () => handlers.onDelete(arc.id));
        view.querySelector('#arcManageChaptersBtn').addEventListener('click', () => handlers.onManageChapters(arc));
        view.querySelector('#arcChapterSearchInput').addEventListener('input', (e) => handlers.onSearchChapters(e.target.value));

        this.renderArcChapterList(taggedChapters, handlers.onOpenChapter);
    },

    renderArcChapterList(chapters, onOpenChapter) {
        const list = document.getElementById('arcChapterList');
        if (!list) return;
        list.innerHTML = '';

        if (!chapters || chapters.length === 0) {
            list.innerHTML = `<div class="tag-chip-empty">No chapters tagged to this arc yet.</div>`;
            return;
        }

        chapters.forEach(ch => {
            const row = document.createElement('button');
            row.type = 'button';
            row.className = 'link-row';
            row.innerHTML = `<span>${escapeHtml(ch.title)}</span><span class="link-row-arrow">→</span>`;
            row.addEventListener('click', () => onOpenChapter(ch.id));
            list.appendChild(row);
        });
    },

    getFormData() {
        const els = this.elements;
        return {
            id: els.idInput?.value ? Number(els.idInput.value) : null,
            title: els.titleInput?.value.trim() || '',
            description: els.descInput?.value.trim() || ''
        };
    },

    openModal(arc = null) {
        const els = this.elements;
        this.clearForm();

        document.getElementById('arcModalTitle').textContent = arc ? 'Edit Arc' : 'Add Arc';

        if (arc) {
            els.idInput.value = arc.id;
            els.titleInput.value = arc.title || '';
            els.descInput.value = arc.description || '';
        }

        els.modal.style.display = 'flex';
        els.titleInput?.focus();
    },

    closeModal() {
        this.elements.modal.style.display = 'none';
        this.clearForm();
    },

    clearForm() {
        const els = this.elements;
        if (els.idInput) els.idInput.value = '';
        if (els.titleInput) els.titleInput.value = '';
        if (els.descInput) els.descInput.value = '';
    },

    // --- Manage-chapters mini modal (reuses the tag picker, searchable) ---
    openChapterTagModal(chapters, selectedIds) {
        const modal = document.getElementById('arcChapterTagModal');
        const container = document.getElementById('arcChapterTagPicker');
        const searchInput = document.getElementById('arcChapterTagSearchInput');
        const items = chapters.map(c => ({ id: c.id, label: c.title }));
        const emptyMessage = 'No chapters created yet. Add chapters first from the Chapters tab.';

        renderTagPicker(container, items, selectedIds, emptyMessage);
        wireTagPickerSearch(container, searchInput, items, emptyMessage);

        modal.style.display = 'flex';
    },

    closeChapterTagModal() {
        document.getElementById('arcChapterTagModal').style.display = 'none';
    },

    readChapterTagModal() {
        return readTagPicker(document.getElementById('arcChapterTagPicker'));
    }
};
