import { storyService } from '../story/storyService.js';
import { createId } from '../../shared/id.js';

export const arcService = {
    getArcs() {
        const story = storyService.getCurrentStory();
        return story ? (story.arcs || []) : [];
    },

    getArcById(id) {
        return this.getArcs().find(a => a.id === id) || null;
    },

    addArc(data) {
        const story = storyService.getCurrentStory();
        if (!story) return null;
        if (!story.arcs) story.arcs = [];

        const newArc = {
            id: createId(),
            title: data.title,
            description: data.description || '',
            chapterIds: data.chapterIds || [],
            createdAt: Date.now()
        };

        story.arcs.push(newArc);
        storyService.updateStoryDetails({});
        return newArc;
    },

    updateArc(id, updatedData) {
        const story = storyService.getCurrentStory();
        if (!story || !story.arcs) return false;

        const index = story.arcs.findIndex(a => a.id === id);
        if (index === -1) return false;

        story.arcs[index] = { ...story.arcs[index], ...updatedData };
        storyService.updateStoryDetails({});
        return true;
    },

    deleteArc(id) {
        const story = storyService.getCurrentStory();
        if (!story || !story.arcs) return false;

        story.arcs = story.arcs.filter(a => a.id !== id);

        // Cascade cleanup: remove this arc from anything that tagged it
        (story.ideas || []).forEach(i => {
            if (i.arcIds) i.arcIds = i.arcIds.filter(aid => aid !== id);
        });

        storyService.updateStoryDetails({});
        return true;
    },

    searchArcs(query) {
        const arcs = this.getArcs();
        const q = (query || '').trim().toLowerCase();
        if (!q) return arcs;
        return arcs.filter(a =>
            a.title.toLowerCase().includes(q) ||
            (a.description || '').toLowerCase().includes(q)
        );
    },

    // Search the chapters tagged inside one specific arc, by chapter title
    searchArcChapters(arc, allChapters, query) {
        const tagged = (arc.chapterIds || [])
            .map(id => allChapters.find(c => c.id === id))
            .filter(Boolean);
        const q = (query || '').trim().toLowerCase();
        if (!q) return tagged;
        return tagged.filter(c => c.title.toLowerCase().includes(q));
    }
};
