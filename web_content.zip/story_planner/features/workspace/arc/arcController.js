import { arcService } from './arcService.js';
import { arcUi } from './arcUi.js';
import { chapterService } from '../chapter/chapterService.js';
import { openChapterById } from '../chapter/chapterController.js';
import { storyUi } from '../story/storyUi.js';

let currentArcSearchQuery = '';
let activeArcId = null;
let activeArcChapterSearch = '';

export function initArcFeature() {
    attachEventListeners();
}

export function loadArcsTab() {
    currentArcSearchQuery = '';
    activeArcId = null;
    const els = arcUi.elements;
    if (els.searchInput) els.searchInput.value = '';

    arcUi.showListView();
    renderList();
}

function renderList() {
    const arcs = arcService.searchArcs(currentArcSearchQuery);
    arcUi.renderArcGrid(arcs, {
        onOpen: handleOpenArc,
        onDelete: handleDeleteArc
    });
}

function handleOpenArc(id) {
    activeArcId = id;
    activeArcChapterSearch = '';
    const arc = arcService.getArcById(id);
    if (!arc) return;

    const allChapters = chapterService.getChapters();
    const taggedChapters = arcService.searchArcChapters(arc, allChapters, '');

    arcUi.showDetailView();
    arcUi.renderArcDetail(arc, taggedChapters, {
        onBack: () => {
            activeArcId = null;
            arcUi.showListView();
            renderList();
        },
        onEdit: handleEditArc,
        onDelete: handleDeleteArc,
        onManageChapters: handleManageChapters,
        onSearchChapters: handleSearchArcChapters,
        onOpenChapter: (chapterId) => {
            storyUi.switchTab('chapters');
            openChapterById(chapterId);
        }
    });
}

function handleEditArc(arc) {
    arcUi.openModal(arc);
}

function handleSearchArcChapters(query) {
    activeArcChapterSearch = query;
    const arc = arcService.getArcById(activeArcId);
    if (!arc) return;
    const allChapters = chapterService.getChapters();
    const filtered = arcService.searchArcChapters(arc, allChapters, query);
    arcUi.renderArcChapterList(filtered, (chapterId) => {
        storyUi.switchTab('chapters');
        openChapterById(chapterId);
    });
}

function handleManageChapters(arc) {
    const allChapters = chapterService.getChapters();
    arcUi.openChapterTagModal(allChapters, arc.chapterIds || []);

    const saveBtn = document.getElementById('arcChapterTagSaveBtn');
    const cancelBtn = document.getElementById('arcChapterTagCancelBtn');

    const onSave = () => {
        const chapterIds = arcUi.readChapterTagModal();
        arcService.updateArc(arc.id, { chapterIds });
        arcUi.closeChapterTagModal();
        handleOpenArc(arc.id);
        cleanup();
    };
    const onCancel = () => {
        arcUi.closeChapterTagModal();
        cleanup();
    };
    function cleanup() {
        saveBtn.removeEventListener('click', onSave);
        cancelBtn.removeEventListener('click', onCancel);
    }
    saveBtn.addEventListener('click', onSave);
    cancelBtn.addEventListener('click', onCancel);
}

function handleDeleteArc(id) {
    if (!confirm('Delete this arc? This cannot be undone.')) return;
    arcService.deleteArc(id);
    activeArcId = null;
    arcUi.showListView();
    renderList();
}

function handleSaveArc(e) {
    e.preventDefault();
    const formData = arcUi.getFormData();

    if (!formData.title) {
        alert('Please enter an arc title.');
        return;
    }
    if (!formData.description) {
        alert('Please enter an arc description.');
        return;
    }

    let arcId = formData.id;
    if (formData.id) {
        arcService.updateArc(formData.id, { title: formData.title, description: formData.description });
    } else {
        const created = arcService.addArc(formData);
        arcId = created.id;
    }

    arcUi.closeModal();

    // If we were editing from the detail view, stay there and refresh; otherwise refresh the list.
    if (activeArcId === arcId) {
        handleOpenArc(arcId);
    } else {
        renderList();
    }
}

function attachEventListeners() {
    const els = arcUi.elements;

    if (els.addBtn) els.addBtn.addEventListener('click', () => arcUi.openModal());
    if (els.cancelBtn) els.cancelBtn.addEventListener('click', () => arcUi.closeModal());
    if (els.form) els.form.addEventListener('submit', handleSaveArc);
    if (els.searchInput) {
        els.searchInput.addEventListener('input', (e) => {
            currentArcSearchQuery = e.target.value;
            renderList();
        });
    }
}
