const fs = require('fs');
const path = require('path');
const AdmZip = require('adm-zip');

const rootDir = process.cwd();
const zip = new AdmZip();

// Excluded folders & files
const excludeList = new Set([
  'node_modules',
  '.git',
  'dist',
  'dist.zip',
  'project.zip',
  'hebrew-calendar_1.0.0_all.ipk',
  'app-export.tar.gz'
]);

function addDirectoryRecursively(currentPath, zipPath = '') {
  const items = fs.readdirSync(currentPath);

  for (const item of items) {
    if (excludeList.has(item)) continue;

    const fullPath = path.join(currentPath, item);
    const entryZipPath = zipPath ? `${zipPath}/${item}` : item;
    const stat = fs.statSync(fullPath);

    if (stat.isDirectory()) {
      addDirectoryRecursively(fullPath, entryZipPath);
    } else {
      zip.addLocalFile(fullPath, zipPath);
    }
  }
}

try {
  console.log('Building project.zip...');
  addDirectoryRecursively(rootDir);
  const outPath = path.join(rootDir, 'project.zip');
  zip.writeZip(outPath);
  console.log('project.zip created successfully at:', outPath);
} catch (err) {
  console.error('Error creating project.zip:', err);
}
