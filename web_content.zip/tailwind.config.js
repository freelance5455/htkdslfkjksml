/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      fontFamily: { vazir: ["Vazirmatn", "Tahoma", "sans-serif"] },
      colors: {
        ink: "#07130f",
        forest: "#0a2f1f",
        forest2: "#0d3b28",
        gold: "#d7a85a",
        gold2: "#e4b96d",
        cream: "#f4efe4"
      },
      boxShadow: {
        gold: "0 0 35px rgba(215,168,90,.12)",
        panel: "0 20px 70px rgba(0,0,0,.35)"
      }
    }
  },
  plugins: []
}