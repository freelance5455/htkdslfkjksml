/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        darkBg: '#090D10',
        darkSurface: '#12181F',
        darkElevated: '#1A232C',
        darkBorder: '#273442',
        emeraldPrimary: '#10B981',
        emeraldAccent: '#059669',
        emeraldContainer: '#064E3B',
        emeraldText: '#A7F3D0',
        textPrimary: '#F1F5F9',
        textSecondary: '#94A3B8',
        textMuted: '#64748B',
      },
    },
  },
  plugins: [],
};
