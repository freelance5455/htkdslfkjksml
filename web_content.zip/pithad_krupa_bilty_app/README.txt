PITHAD KRUPA TRANSPORT - BILTY APP

1. Extract this ZIP file on your phone.
2. Open index.html in Chrome.
3. Fill in the bilty details and tap UPDATE / GENERATE BILTY.
4. SAVE BILTY stores the bilty in this browser on this phone.
5. WHATSAPP PHOTO creates a bilty image that you can share.
6. SAVE PDF opens the print dialog; choose Save as PDF.

Note: Bilty history is stored locally in the same browser on this device.
The signature area and bottom spacing have been adjusted in this version.
