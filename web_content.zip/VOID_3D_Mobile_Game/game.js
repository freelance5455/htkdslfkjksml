import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js';

const loading=document.querySelector('#loading');
const scene=new THREE.Scene();
scene.background=new THREE.Color(0x05050c);
scene.fog=new THREE.FogExp2(0x080713,0.025);
const camera=new THREE.PerspectiveCamera(66,innerWidth/innerHeight,.1,180);
camera.position.set(0,5.4,10.5);
const renderer=new THREE.WebGLRenderer({antialias:true,powerPreference:'high-performance'});
renderer.setSize(innerWidth,innerHeight);renderer.setPixelRatio(Math.min(devicePixelRatio,1.8));
renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;
renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.25;
document.body.appendChild(renderer.domElement);

scene.add(new THREE.HemisphereLight(0x9c8dff,0x11101d,1.4));
const key=new THREE.DirectionalLight(0xc4b7ff,2.5);key.position.set(-5,10,7);key.castShadow=true;scene.add(key);
const glow=new THREE.PointLight(0x754bff,24,32);glow.position.set(0,3,-12);scene.add(glow);

const mat=(color,metalness=0,roughness=.5,emissive=0x000000)=>new THREE.MeshStandardMaterial({color,metalness,roughness,emissive,emissiveIntensity:.8});
const floorMat=mat(0x10101b,.7,.35);
const road=new THREE.Mesh(new THREE.BoxGeometry(9,.3,180),floorMat);road.position.set(0,-.25,-55);road.receiveShadow=true;scene.add(road);
const grid=new THREE.GridHelper(180,70,0x6546aa,0x29213f);grid.position.set(0,-.08,-55);scene.add(grid);

const laneX=[-2.65,0,2.65];let lane=1, targetX=0, jumping=false, jumpV=0;
const runner=new THREE.Group();scene.add(runner);
const bodyMat=mat(0x171522,.75,.25,0x21104d), trim=mat(0x9b7aff,.5,.25,0x6c39ff), dark=mat(0x080811,.2,.6);
function box(parent,w,h,d,material,x,y,z){const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),material);m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;parent.add(m);return m;}
box(runner,.72,1.05,.42,bodyMat,0,.95,0);
const head=new THREE.Mesh(new THREE.SphereGeometry(.28,24,18),mat(0x29233b,.2,.45));head.position.set(0,1.68,0);head.castShadow=true;runner.add(head);
box(runner,.78,.1,.48,trim,0,1.42,0);
const visor=new THREE.Mesh(new THREE.BoxGeometry(.42,.08,.04),mat(0xc4aaff,.4,.2,0x9d70ff));visor.position.set(0,1.73,.25);runner.add(visor);
const armL=box(runner,.19,.75,.2,bodyMat,-.5,1.02,0),armR=box(runner,.19,.75,.2,bodyMat,.5,1.02,0);
const legL=box(runner,.25,.68,.25,dark,-.22,.34,0),legR=box(runner,.25,.68,.25,dark,.22,.34,0);
runner.position.set(0,0,4);

const obstacleMat=mat(0x261c3c,.6,.3,0x421b80), shardMat=mat(0x9b83ff,.65,.18,0x8a55ff);
const objects=[];let spawnZ=-28, speed=17, score=0, shards=0, active=false, best=0;
function addObstacle(z){const laneN=Math.floor(Math.random()*3);const h=.8+Math.random()*.8;const o=box(scene,1.2,h,.9,obstacleMat,laneX[laneN],h/2,z);o.userData={type:'obstacle',lane:laneN};objects.push(o);}
function addShard(z){const laneN=Math.floor(Math.random()*3);const s=new THREE.Mesh(new THREE.OctahedronGeometry(.38),shardMat);s.position.set(laneX[laneN],1.35,z);s.castShadow=true;scene.add(s);s.userData={type:'shard',lane:laneN};objects.push(s);}
for(let i=0;i<12;i++){addObstacle(-20-i*13);if(i%2===0)addShard(-27-i*13)}
// distant monoliths and glowing rifts
for(let i=0;i<34;i++){let side=i%2?1:-1;let z=-i*5-8;let tower=box(scene,.45,2+Math.random()*7,.5,mat(0x171329,.5,.35,0x160d30),side*(6+Math.random()*3),1,z);tower.rotation.z=(Math.random()-.5)*.15;}
const riftMat=new THREE.MeshBasicMaterial({color:0x6840d8,transparent:true,opacity:.22,side:THREE.DoubleSide});
for(let i=0;i<7;i++){const ring=new THREE.Mesh(new THREE.TorusGeometry(2.8,.035,8,70),riftMat);ring.position.set((Math.random()-.5)*4,2.2,-20-i*24);scene.add(ring);}

function move(dir){if(!active)return;if(dir==='left')lane=Math.max(0,lane-1);if(dir==='right')lane=Math.min(2,lane+1);if(dir==='jump'&&!jumping){jumping=true;jumpV=9.5;}}
addEventListener('keydown',e=>{if(e.key==='ArrowLeft'||e.key==='a')move('left');if(e.key==='ArrowRight'||e.key==='d')move('right');if(e.key==='ArrowUp'||e.key===' ')move('jump');});
document.querySelectorAll('#touch button').forEach(b=>b.addEventListener('pointerdown',e=>{e.preventDefault();move(b.dataset.move)}));
let sx=0,sy=0;addEventListener('touchstart',e=>{sx=e.changedTouches[0].clientX;sy=e.changedTouches[0].clientY},{passive:true});
addEventListener('touchend',e=>{let dx=e.changedTouches[0].clientX-sx,dy=e.changedTouches[0].clientY-sy;if(Math.abs(dx)>25)move(dx>0?'right':'left');else if(dy<-25)move('jump')},{passive:true});

const scoreEl=document.querySelector('#score'),shardsEl=document.querySelector('#shards');
function endRun(){active=false;document.querySelector('#finalScore').textContent=Math.floor(score);document.querySelector('#finalShards').textContent=shards;document.querySelector('#gameover').classList.remove('hidden');}
function start(){score=0;shards=0;speed=17;lane=1;runner.position.set(0,0,4);objects.forEach(o=>scene.remove(o));objects.length=0;for(let i=0;i<12;i++){addObstacle(-20-i*13);if(i%2===0)addShard(-27-i*13)}spawnZ=-185;active=true;document.querySelector('#intro').classList.add('hidden');document.querySelector('#gameover').classList.add('hidden');}
document.querySelector('#start').onclick=start;document.querySelector('#again').onclick=start;

let last=performance.now();
function animate(now){requestAnimationFrame(animate);const dt=Math.min((now-last)/1000,.04);last=now;
 if(active){score+=dt*10;speed=Math.min(30,17+score/180);targetX=laneX[lane];runner.position.x+=(targetX-runner.position.x)*Math.min(1,dt*12);
 if(jumping){runner.position.y+=jumpV*dt;jumpV-=24*dt;if(runner.position.y<=0){runner.position.y=0;jumping=false;}}
 runner.rotation.z+=(0-runner.rotation.z)*dt*8;
 for(const o of objects){o.position.z+=speed*dt;if(o.userData.type==='shard')o.rotation.y+=dt*3;
  if(o.position.z>3&&o.position.z<5.1&&Math.abs(o.position.x-runner.position.x)<1.15){
   if(o.userData.type==='shard'){shards++;shardsEl.textContent=shards;o.position.z=100;}
   else if(runner.position.y<o.geometry.parameters.height*.45+.5){endRun();}
  }
 }
 if(objects.length<25){spawnZ-=14;addObstacle(spawnZ);if(Math.random()>.35)addShard(spawnZ-5);}
 for(let i=objects.length-1;i>=0;i--)if(objects[i].position.z>13){scene.remove(objects[i]);objects.splice(i,1);}
 scoreEl.textContent=Math.floor(score);
 }
 camera.position.x+=(runner.position.x*.12-camera.position.x)*dt*2;
 camera.lookAt(runner.position.x*.12,1,-3);
 glow.position.z=-12+Math.sin(now*.0007)*3;
 renderer.render(scene,camera);
}
requestAnimationFrame(animate);
addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);});
if('serviceWorker'in navigator)navigator.serviceWorker.register('./sw.js').catch(()=>{});
loading.remove();