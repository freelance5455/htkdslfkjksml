VØID — THE ENDLESS RUN (3D MOBILE WEB APP)

WHAT THIS IS
A playable 3D endless-runner starter app for phones and computers. It has a cinematic dark sci-fi world, a 3D runner, obstacles, collectible shards, score, touch controls and keyboard controls.

IMPORTANT
"4D" is not a standard game-rendering dimension. This project uses real-time 3D graphics with motion, lighting and depth to create an immersive feel. It is a starter game, not a finished commercial game and not an Android APK.

HOW TO RUN
1. Extract this ZIP.
2. Open index.html in a modern browser with internet access.
   The Three.js 3D engine is loaded from a CDN, so the first run needs internet.
3. For best phone experience, host the folder on an HTTPS static host (for example GitHub Pages or Netlify), open the hosted page in Chrome, then use Chrome menu > Add to Home screen / Install app.

ANDROID APK
This ZIP is a web app project, not an APK file. To make a true APK, it needs to be packaged with an Android wrapper/build service or Android development environment. Do not rename the ZIP to .apk.

CONTROLS
Swipe left/right to change lanes. Swipe up to jump. On-screen buttons are also available. On desktop, use arrow keys or A/D and Space.

NEXT DEVELOPMENT
Add original character models, sound effects/music, more environments, saved progress, settings, missions and proper Android packaging.