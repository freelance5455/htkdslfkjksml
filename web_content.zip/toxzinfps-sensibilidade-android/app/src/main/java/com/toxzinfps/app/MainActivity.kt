package com.toxzinfps.app

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import org.json.JSONObject
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var waitingForOverlaySettings = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                syncPanelState()
                openRequestedSection(intent)
            }
        }
        webView.addJavascriptInterface(OverlayBridge(this), "AndroidOverlay")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onResume() {
        super.onResume()
        if (waitingForOverlaySettings) {
            waitingForOverlaySettings = false
            if (Settings.canDrawOverlays(this)) {
                launchOverlay()
                notifyPage("window.onOverlayPermissionResult(true,true)")
            } else {
                notifyPage("window.onOverlayPermissionResult(false,false)")
            }
        } else if (::webView.isInitialized) {
            syncPanelState()
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null) {
            setIntent(intent)
            openRequestedSection(intent)
        }
    }

    private fun requestOverlay() {
        if (Settings.canDrawOverlays(this)) {
            launchOverlay()
            notifyPage("window.onOverlayPermissionResult(true,true)")
            return
        }
        // Android exige que esta permissão especial seja concedida na tela do sistema.
        // Abrimos essa tela imediatamente, sem uma confirmação intermediária do app.
        waitingForOverlaySettings = true
        val settingsIntent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        try {
            startActivity(settingsIntent)
        } catch (_: Exception) {
            waitingForOverlaySettings = false
            notifyPage("window.onOverlayPermissionResult(false,false)")
        }
    }

    private fun launchOverlay() {
        val serviceIntent = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent)
        else startService(serviceIntent)
    }

    private fun stopOverlay() {
        stopService(Intent(this, OverlayService::class.java))
        notifyPage("window.onNativeOverlayState(false)")
    }

    private fun syncPanelState() {
        if (::webView.isInitialized) {
            val running = OverlayService.isRunning
            notifyPage("window.onNativeOverlayState($running)")
        }
    }

    private fun notifyPage(script: String) {
        if (::webView.isInitialized) webView.post { webView.evaluateJavascript(script, null) }
    }

    private fun openRequestedSection(intent: Intent?) {
        val section = intent?.getStringExtra("section") ?: return
        if (section == "aim" || section == "opt") {
            webView.postDelayed({ notifyPage("show('$section')") }, 250)
            intent?.removeExtra("section")
        }
    }

    inner class OverlayBridge(private val context: Context) {
        @JavascriptInterface
        fun requestOverlayPermission() {
            runOnUiThread { requestOverlay() }
        }

        @JavascriptInterface
        fun stopOverlay() {
            runOnUiThread { this@MainActivity.stopOverlay() }
        }

        @JavascriptInterface
        fun isOverlayRunning(): Boolean = OverlayService.isRunning

        @JavascriptInterface
        fun getDeviceMetrics(): String {
            val activityManager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val memory = ActivityManager.MemoryInfo()
            activityManager.getMemoryInfo(memory)
            val stat = StatFs(Environment.getDataDirectory().path)
            val gib = 1024.0 * 1024.0 * 1024.0
            return JSONObject()
                .put("ramAvailableMb", memory.availMem / (1024 * 1024))
                .put("ramTotalMb", memory.totalMem / (1024 * 1024))
                .put("storageFreeGb", String.format(java.util.Locale.US, "%.1f", stat.availableBytes / gib))
                .put("storageTotalGb", String.format(java.util.Locale.US, "%.1f", stat.totalBytes / gib))
                .put("cpuCores", Runtime.getRuntime().availableProcessors())
                .put("model", "${Build.MANUFACTURER} ${Build.MODEL}".trim())
                .put("androidVersion", Build.VERSION.RELEASE ?: "?")
                .toString()
        }

        @JavascriptInterface
        fun openOptimizationSettings(destination: String): Boolean {
            val action = when (destination) {
                "storage" -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS
                "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
                "display" -> Settings.ACTION_DISPLAY_SETTINGS
                "wifi" -> Settings.ACTION_WIFI_SETTINGS
                "apps" -> Settings.ACTION_APPLICATION_SETTINGS
                else -> Settings.ACTION_SETTINGS
            }
            return try {
                context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                true
            } catch (_: Exception) {
                try {
                    context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    true
                } catch (_: Exception) {
                    false
                }
            }
        }

        @JavascriptInterface
        fun openSection(section: String) {
            runOnUiThread {
                this@MainActivity.moveTaskToBack(false)
                webView.postDelayed({ notifyPage("show('$section')") }, 250)
            }
        }
    }
}
