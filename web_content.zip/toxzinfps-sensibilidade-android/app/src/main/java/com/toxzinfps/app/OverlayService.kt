package com.toxzinfps.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.app.ActivityManager
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var panel: LinearLayout? = null
    private var params: WindowManager.LayoutParams? = null
    private lateinit var body: LinearLayout
    private var activeTab = "aim"
    private var optimizationEnabled = false
    private val optimizationChecks = mutableMapOf<String, Boolean>()
    private var floatingAim: TextView? = null
    private var aimMode = "standard"

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        startAsForeground()
        if (panel == null) showPanel()
        isRunning = true
        return START_STICKY
    }

    private fun startAsForeground() {
        val channelId = "toxzinfps_overlay"
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(channelId, "Painel flutuante", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("TOXZIN FPS está ativo")
                .setContentText("Toque para abrir o painel de mira e otimização")
                .setContentIntent(openApp)
                .setOngoing(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("TOXZIN FPS está ativo")
                .setContentText("Painel flutuante ativado")
                .setContentIntent(openApp)
                .setOngoing(true)
                .build()
        }
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(41, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(41, notification)
        }
    }

    private fun showPanel() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded("#101824", 18, "#86B840")
            clipToOutline = true
            elevation = dp(12).toFloat()
        }
        panel = root

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(8), dp(10))
            background = rounded("#192638", 16)
        }
        val title = TextView(this).apply {
            text = "TOXZIN  ·  PAINEL RÁPIDO"
            textSize = 12f
            setTextColor(Color.parseColor("#C6FF52"))
            setTypeface(null, 1)
        }
        header.addView(title, LinearLayout.LayoutParams(0, dp(34), 1f))
        val close = TextView(this).apply {
            text = "×"
            textSize = 23f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(dp(10), 0, dp(8), 0)
            setOnClickListener { stopSelf() }
        }
        header.addView(close, LinearLayout.LayoutParams(dp(42), dp(34)))
        root.addView(header)
        attachDrag(header)

        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(9), dp(8), dp(9), dp(3))
        }
        val aimTab = miniButton("MIRA FLUTUANTE") { activeTab = "aim"; renderBody() }
        val optTab = miniButton("OTIMIZAÇÃO") { activeTab = "opt"; renderBody() }
        tabs.addView(aimTab, LinearLayout.LayoutParams(0, dp(37), 1f).apply { marginEnd = dp(5) })
        tabs.addView(optTab, LinearLayout.LayoutParams(0, dp(37), 1f).apply { marginStart = dp(5) })
        root.addView(tabs)
        body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(13), dp(7), dp(13), dp(13))
        }
        root.addView(body)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        params = WindowManager.LayoutParams(
            dp(296), WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(12)
            y = dp(110)
        }
        windowManager.addView(root, params)
        renderBody()
    }

    private fun renderBody() {
        if (!::body.isInitialized) return
        body.removeAllViews()
        if (activeTab == "aim") {
            body.addView(label("Mira visual por cima dos apps", 12, "#AAB6C7"))
            body.addView(miniButton(if (floatingAim == null) "MOSTRAR MIRA" else "OCULTAR MIRA") {
                toggleFloatingAim()
            }, marginTop = 8)
            body.addView(label("Perfis visuais", 11, "#C6FF52"), marginTop = 10)
            val modes = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            modes.addView(miniButton("Rápido") { setAimMode("fast") }, LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginEnd = dp(4) })
            modes.addView(miniButton("Suave") { setAimMode("soft") }, LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginStart = dp(4) })
            body.addView(modes, marginTop = 5)
            body.addView(label("Os perfis mudam apenas tamanho e cor da mira. Não enviam toques nem alteram os controles do jogo.", 10, "#D7BD83"), marginTop = 8)
        } else {
            body.addView(label("Atalhos reais para configurações do Android", 11, "#AAB6C7"))
            val info = ActivityManager.MemoryInfo()
            (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(info)
            body.addView(label("RAM disponível agora: ${info.availMem / (1024 * 1024)} MB", 12, "#C6FF52"), marginTop = 7)
            body.addView(miniButton("GERENCIAR APPS") { openAndroidSettings("apps") }, marginTop = 8)
            body.addView(miniButton("ARMAZENAMENTO") { openAndroidSettings("storage") }, marginTop = 6)
            body.addView(miniButton("BATERIA") { openAndroidSettings("battery") }, marginTop = 6)
            body.addView(miniButton("WI-FI / REDE") { openAndroidSettings("wifi") }, marginTop = 6)
            body.addView(miniButton("AJUSTES DE TELA") { openAndroidSettings("display") }, marginTop = 6)
            body.addView(label("Esses atalhos abrem telas do sistema. O Android não permite que este app encerre outros apps ou force CPU/GPU.", 10, "#D7BD83"), marginTop = 8)
        }
    }

    private fun toggleFloatingAim() {
        if (floatingAim != null) {
            floatingAim?.let { old -> try { windowManager.removeView(old) } catch (_: Exception) {} }
            floatingAim = null
        } else {
            val mark = TextView(this).apply {
                text = "⊕"
                textSize = 46f
                gravity = Gravity.CENTER
                setTextColor(Color.parseColor("#C6FF52"))
                setShadowLayer(12f, 0f, 0f, Color.parseColor("#C6FF52"))
            }
            val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
            val aimParams = WindowManager.LayoutParams(
                dp(76), dp(76), type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.CENTER }
            try {
                windowManager.addView(mark, aimParams)
                floatingAim = mark
                setAimMode(aimMode, redraw = false)
            } catch (_: Exception) {
                Toast.makeText(this, "Não foi possível exibir a mira. Confira a permissão de sobreposição.", Toast.LENGTH_LONG).show()
            }
        }
        renderBody()
    }

    private fun setAimMode(mode: String, redraw: Boolean = true) {
        aimMode = mode
        floatingAim?.let { view ->
            when (mode) {
                "fast" -> { view.textSize = 40f; view.setTextColor(Color.parseColor("#58E4FA")); view.setShadowLayer(10f, 0f, 0f, Color.parseColor("#58E4FA")) }
                "soft" -> { view.textSize = 54f; view.setTextColor(Color.parseColor("#B9A7FF")); view.setShadowLayer(8f, 0f, 0f, Color.parseColor("#B9A7FF")) }
                else -> { view.textSize = 46f; view.setTextColor(Color.parseColor("#C6FF52")); view.setShadowLayer(12f, 0f, 0f, Color.parseColor("#C6FF52")) }
            }
        }
        if (redraw && ::body.isInitialized) renderBody()
    }

    private fun openAndroidSettings(destination: String) {
        val action = when (destination) {
            "storage" -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "apps" -> Settings.ACTION_APPLICATION_SETTINGS
            "dnd" -> Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        try {
            startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
            try { startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            catch (_: Exception) { Toast.makeText(this, "Configurações indisponíveis", Toast.LENGTH_SHORT).show() }
        }
    }

    private fun optimizationOption(title: String, subtitle: String): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(5), dp(4), dp(5))
            background = rounded("#0C131E", 9, "#263548")
        }
        val text = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        text.addView(label(title, 11, "#E8EDF5"))
        text.addView(label(subtitle, 9, "#91A0B4"))
        row.addView(text, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val checked = optimizationChecks[title] == true
        val action = miniButton(if (checked) "FEITO ✓" else "MARCAR") {
            optimizationChecks[title] = optimizationChecks[title] != true
            renderBody()
        }
        row.addView(action, LinearLayout.LayoutParams(dp(82), dp(34)).apply { marginStart = dp(6) })
        return row
    }

    private fun openApp(section: String) {
        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra("section", section)
        }
        startActivity(intent)
    }

    private fun attachDrag(view: View) {
        var startX = 0f
        var startY = 0f
        var initialX = 0
        var initialY = 0
        view.setOnTouchListener { _, event ->
            val lp = params ?: return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = event.rawX; startY = event.rawY
                    initialX = lp.x; initialY = lp.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = initialX - (event.rawX - startX).toInt()
                    lp.y = initialY + (event.rawY - startY).toInt()
                    try { windowManager.updateViewLayout(panel, lp) } catch (_: Exception) {}
                    true
                }
                else -> false
            }
        }
    }

    private fun miniButton(text: String, action: () -> Unit): Button = Button(this).apply {
        this.text = text
        textSize = 10f
        isAllCaps = false
        setTextColor(Color.parseColor("#C6FF52"))
        background = rounded("#1B2A3B", 10, "#33475D")
        setPadding(dp(5), 0, dp(5), 0)
        setOnClickListener { action() }
    }

    private fun label(text: String, size: Int, color: String): TextView = TextView(this).apply {
        this.text = text
        textSize = size.toFloat()
        setTextColor(Color.parseColor(color))
    }

    private fun LinearLayout.addView(view: View, marginTop: Int) {
        addView(view, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(marginTop)
        })
    }

    private fun rounded(fill: String, radius: Int, stroke: String? = null) = GradientDrawable().apply {
        setColor(Color.parseColor(fill))
        cornerRadius = dp(radius).toFloat()
        if (stroke != null) setStroke(dp(1), Color.parseColor(stroke))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        panel?.let { view -> try { windowManager.removeView(view) } catch (_: Exception) {} }
        panel = null
        floatingAim?.let { view -> try { windowManager.removeView(view) } catch (_: Exception) {} }
        floatingAim = null
        isRunning = false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) stopForeground(STOP_FOREGROUND_REMOVE)
        else stopForeground(true)
        super.onDestroy()
    }

    companion object {
        @Volatile var isRunning: Boolean = false
            private set
    }
}
