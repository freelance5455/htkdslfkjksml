TOXZIN FPS — GERADOR, MIRA FLUTUANTE E ATALHOS ANDROID

Projeto-fonte Android Studio.

- A tela principal mantém o gerador de referências de sensibilidade, com ajustes manuais.
- No painel flutuante, “Mira flutuante” mostra/oculta um marcador visual central. Os perfis Rápido/Suave mudam somente o tamanho e a cor do marcador.
- A mira é visual: não injeta toques, não substitui o botão de tiro e não altera os controles do Free Fire. O Android e o jogo não permitem que um app comum faça isso sem recursos especiais de acessibilidade; este projeto não simula entrada.
- A aba Otimização abre telas oficiais do Android para gerenciar apps, armazenamento, bateria, Wi-Fi e tela. Também mostra RAM disponível lida do sistema. Não promete limpar RAM de terceiros nem forçar CPU/GPU.
- Na primeira abertura, o app verifica a permissão e, se estiver ausente, abre a tela oficial do Android “Exibir sobre outros apps”. O usuário precisa ativá-la manualmente. Se negar, o botão de ativação permite tentar novamente.

Abrir: extraia o ZIP e abra a pasta no Android Studio. Execute em aparelho Android (minSdk 23). Este ZIP é fonte, não APK compilado.


Observações sobre permissões adicionadas ao Manifest
- WRITE_SETTINGS requer aprovação manual do usuário na tela especial do Android e só deve ser usada quando um recurso realmente alterar configurações do sistema.
- WRITE_SECURE_SETTINGS é protegida pelo Android e não é concedida a aplicativos comuns só por declará-la.
- REQUEST_IGNORE_BATTERY_OPTIMIZATIONS não desativa a otimização sozinha; a pessoa precisa aprovar e o uso é sujeito às regras do Android/Google Play.
- RECEIVE_BOOT_COMPLETED, por si só, não inicia o app; é necessário um BroadcastReceiver e respeitar as restrições de execução em segundo plano.
- READ_EXTERNAL_STORAGE e WRITE_EXTERNAL_STORAGE são permissões antigas e não liberam acesso geral a arquivos em Android recente. Este projeto não precisa delas para o painel ou a mira.
