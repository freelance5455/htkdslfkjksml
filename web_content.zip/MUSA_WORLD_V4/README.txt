MUSA WORLD V4 — Android WebView project

Contains 56 game entries across three sections:
1) Local multiplayer (2–6 players; pass-and-play on one device).
2) Local computer-opponent games. These use simple in-game algorithms, not cloud AI.
3) Single-player games.

Quick preview: open app/src/main/assets/index.html in a modern browser.
Build APK: open this folder in Android Studio, allow Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s). The debug APK is usually at app/build/outputs/apk/debug/app-debug.apk.

Offline: the game page uses no remote assets or network services. Multiplayer is local pass-and-play, not online multiplayer.

Important: the only supplied original file was a README describing MUSA WORLD V3; it did not include original source files. This V4 is rebuilt from that description. The 56 entries are playable mini-game modes, with some sharing game engines; they are not 56 separate full-scale commercial games. Android build has not been run in this environment, so build and test on Android Studio before installing.
