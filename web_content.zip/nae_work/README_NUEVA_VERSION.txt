NUESTRO AMOR ETERNO 2.0 — PAQUETE DE DESARROLLO
================================================

CONTENIDO
- index.html: aplicación web con los 365 poemas revisados.
- musica.mp3: música original conservada.
- manifest.webmanifest + sw.js + iconos: base instalable PWA y caché offline.
- android/: proyecto Android Studio con Activity WebView y proveedor de widget nativo.
- REVISION_POEMAS.txt: resumen de los criterios aplicados a los 365 textos.

CAMBIOS DE ESTA ENTREGA
1. Se revisaron los 365 poemas: se quitaron las etiquetas de día dentro de las cartas y se redujeron frases, cierres y comparaciones repetidas.
2. Se sustituyeron fórmulas que aparecían de forma recurrente por expresiones más naturales y variadas, conservando el tono romántico y el sentido general.
3. Se corrigieron construcciones forzadas y puntuación duplicada detectada durante la revisión.
4. Los números se mantienen en la navegación e historial, no dentro del texto de las cartas.
5. La versión de Android WebView usa exactamente el mismo HTML y los mismos poemas que la versión web.
6. Se conserva la música MP3, el diseño romántico, los sonidos de interfaz, el manifiesto PWA y el código fuente del widget Android.

WIDGET NATIVO — CÓMO GENERAR APK
1. Instalar Android Studio en una computadora.
2. Abrir la carpeta android/ como proyecto existente.
3. Permitir que Gradle descargue Android Gradle Plugin y el SDK Android 35.
4. Conectar un teléfono Android o crear un emulador.
5. Ejecutar la configuración “app” o elegir Build > Build APK(s).
6. Instalar la APK. Mantener pulsada la pantalla principal > Widgets > Nuestro Amor Eterno > arrastrar el widget.

Este ZIP contiene el código fuente Android; no contiene una APK ya compilada ni firmada. El widget es una función nativa Android y no puede instalarse desde el HTML por sí solo.

PWA / ACCESO DIRECTO WEB
Para instalar la versión web como aplicación, publicar index.html, musica.mp3, manifest.webmanifest, sw.js e iconos en un hosting HTTPS. Abrir la URL en Chrome Android > menú > Instalar aplicación o Añadir a pantalla principal. Esto crea una aplicación/acceso directo, no el widget nativo.

FECHA DE INICIO CONFIGURADA
La fecha de inicio está configurada como 1 de noviembre de 2026. Si la fecha real de inicio de la relación es distinta, cambiar START en index.html y la fecha LocalDate.of(...) en LoveWidgetProvider.kt.
