package com.nuestroamoreterno.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.time.LocalDate
import java.time.temporal.ChronoUnit

class LoveWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val start = LocalDate.of(2026, 11, 1)
        val days = maxOf(0, ChronoUnit.DAYS.between(start, LocalDate.now()))
        val phrases = listOf(
            "Cada segundo cuenta. Siempre nosotros. ❤️",
            "Hoy vuelvo a elegirte, sin ruido y de verdad. ❤️",
            "Nuestro amor también vive en los pequeños detalles. ❤️",
            "Que nunca nos falten motivos para sonreír juntos. ❤️"
        )
        val phrase = phrases[(days % phrases.size).toInt()]
        ids.forEach { id ->
            val views = RemoteViews(context.packageName, R.layout.love_widget)
            views.setTextViewText(R.id.widget_days, "$days días")
            views.setTextViewText(R.id.widget_phrase, phrase)
            val intent = Intent(context, MainActivity::class.java)
            val pending = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.widget_phrase, pending)
            views.setOnClickPendingIntent(R.id.widget_days, pending)
            manager.updateAppWidget(id, views)
        }
    }
}
