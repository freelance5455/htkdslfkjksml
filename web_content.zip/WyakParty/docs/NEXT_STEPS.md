# Production integration checklist

- Phone OTP/Firebase Authentication and server-side sessions
- PostgreSQL connection, migrations, backups, and authorization middleware
- Agora/ZEGOCLOUD SDK for real live audio; server issues short-lived tokens
- Google Play Billing with server-side purchase token verification before paid coins are credited
- Push notifications, chat, friend/follow, gifts, VIP, family and ranking APIs
- Moderation: mute/kick/lock room, block/report, admin audit log
- HTTPS, secrets management, rate limits, monitoring, privacy policy, account deletion and Play Store compliance

The included room screen is currently UI/demo only; it does not stream microphone audio. The demo backend uses in-memory data and resets on restart. Never treat demo coins as money.
