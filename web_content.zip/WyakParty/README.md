# Wyak Party — Android + Backend starter

This is a starter project, not a production-ready social audio platform.

## Included
- Android app scaffold using Kotlin + Jetpack Compose
- Home screen, profile placeholder, wallet placeholder, 8-seat room UI
- Node.js + Express backend
- Health endpoint, demo user endpoint, room list/create/join endpoints
- In-memory demo data (resets when server restarts)

## Requirements
- Android Studio (current stable)
- JDK 17
- Android SDK (compile SDK 35)
- Node.js 20+

## Run backend
```bash
cd backend
npm install
npm run dev
```
Backend listens on `http://localhost:4000`.

For Android Emulator, use `http://10.0.2.2:4000/` (already configured in `app/build.gradle.kts`).
For a physical phone, replace the base URL with your computer's LAN IP and ensure both devices are on the same Wi-Fi.

## Open Android project
Open the `android/` folder in Android Studio, allow Gradle sync, then run the `app` configuration.

## Important next steps
1. Replace demo in-memory storage with PostgreSQL.
2. Add real authentication (OTP provider / Firebase Auth) and server-issued sessions.
3. Add Agora or ZEGOCLOUD voice SDK; the current room screen is UI only and does not transmit audio.
4. Implement payments through Google Play Billing where applicable. Never credit paid coins from a client request; verify purchase tokens on the backend.
5. Add moderation, reporting, blocking, rate limits, audit logs, privacy policy, terms, age controls, and data deletion.
6. Configure production HTTPS, secrets, backups, monitoring, and Play Store compliance.

Do not put API secrets, payment secrets, or service-account files in the Android app.
