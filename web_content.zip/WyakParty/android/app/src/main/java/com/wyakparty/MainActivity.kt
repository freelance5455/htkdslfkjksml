package com.wyakparty

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF101A36)
private val Blue = Color(0xFF168BFF)
private val Gold = Color(0xFFFFD36A)
private val Page = Color(0xFFF3F6FC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { WyakPartyApp() }
    }
}

@Composable
fun WyakPartyApp() {
    var tab by remember { mutableStateOf(0) }
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Blue,
            secondary = Gold,
            background = Page,
            surface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Page,
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 },
                        icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 },
                        icon = { Icon(Icons.Default.Mic, null) }, label = { Text("Rooms") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 },
                        icon = { Icon(Icons.Default.AccountBalanceWallet, null) }, label = { Text("Wallet") })
                    NavigationBarItem(selected = tab == 3, onClick = { tab = 3 },
                        icon = { Icon(Icons.Default.Person, null) }, label = { Text("Profile") })
                }
            }
        ) { padding ->
            when (tab) {
                0 -> HomeScreen(Modifier.padding(padding), onOpenRoom = { tab = 1 })
                1 -> RoomScreen(Modifier.padding(padding))
                2 -> WalletScreen(Modifier.padding(padding))
                else -> ProfileScreen(Modifier.padding(padding))
            }
        }
    }
}

@Composable
fun HomeScreen(modifier: Modifier = Modifier, onOpenRoom: () -> Unit) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Wyak Party", color = Navy, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                Text("Voice • Friends • Party", color = Color.Gray, fontSize = 13.sp)
            }
            Surface(shape = CircleShape, color = Color.White) {
                Icon(Icons.Default.Notifications, null, Modifier.padding(12.dp), tint = Navy)
            }
        }
        Spacer(Modifier.height(18.dp))
        Box(
            Modifier.fillMaxWidth().height(145.dp)
                .background(Brush.linearGradient(listOf(Blue, Color(0xFF7157D9), Navy)), RoundedCornerShape(22.dp))
                .padding(18.dp)
        ) {
            Column(Modifier.align(Alignment.CenterStart)) {
                Text("WELCOME TO", color = Color.White.copy(alpha = .8f), fontSize = 12.sp)
                Text("YOUR PARTY", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black)
                Text("Meet • Talk • Enjoy", color = Gold)
            }
        }
        Spacer(Modifier.height(20.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Popular Rooms", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Navy, modifier = Modifier.weight(1f))
            Text("See all", color = Blue, modifier = Modifier.clickable { onOpenRoom() })
        }
        Spacer(Modifier.height(10.dp))
        RoomCard("Friends Hangout", "Host: Party King", "5/8 seats", onOpenRoom)
        RoomCard("Music & Masti", "Host: DJ Star", "3/8 seats", onOpenRoom)
        RoomCard("Night Talks", "Host: Moonlight", "7/8 seats", onOpenRoom)
    }
}

@Composable
fun RoomCard(title: String, host: String, count: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).background(Brush.linearGradient(listOf(Blue, Color(0xFF7656D9))), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Groups, null, tint = Color.White)
            }
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                Text(title, color = Navy, fontWeight = FontWeight.Bold)
                Text(host, color = Color.Gray, fontSize = 12.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(count, color = Blue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("OPEN", color = Color(0xFF168B67), fontSize = 10.sp)
            }
        }
    }
}

@Composable
fun RoomScreen(modifier: Modifier = Modifier) {
    var micOn by remember { mutableStateOf(false) }
    var joined by remember { mutableStateOf(false) }
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("Voice Party Room", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Navy)
        Text("Room ID: WP-10001  •  8 seats", color = Color.Gray)
        Spacer(Modifier.height(20.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(4), modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(18.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items((1..8).toList()) { seat ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.size(62.dp).background(if (seat == 1) Gold.copy(alpha = .35f) else Color.White, CircleShape), contentAlignment = Alignment.Center) {
                        Icon(if (seat == 1) Icons.Default.Person else Icons.Default.Add, null, tint = Blue, modifier = Modifier.size(28.dp))
                    }
                    Text(if (seat == 1) "Host" else "Seat $seat", fontSize = 11.sp, color = Navy)
                }
            }
        }
        Text("Room chat and gift feed will appear here.", color = Color.Gray, fontSize = 12.sp)
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { joined = !joined }, modifier = Modifier.weight(1f)) {
                Text(if (joined) "Leave" else "Join Room")
            }
            OutlinedButton(onClick = { micOn = !micOn }, modifier = Modifier.weight(1f)) {
                Icon(if (micOn) Icons.Default.Mic else Icons.Default.MicOff, null)
                Spacer(Modifier.width(5.dp))
                Text(if (micOn) "Mic On" else "Mic Off")
            }
        }
        Text("Demo interface only — live audio is not connected yet.", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
    }
}

@Composable
fun WalletScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("My Wallet", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Navy)
        Spacer(Modifier.height(16.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Navy), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.fillMaxWidth().padding(22.dp)) {
                Text("COIN BALANCE", color = Color.White.copy(alpha = .7f))
                Text("250", color = Gold, fontSize = 38.sp, fontWeight = FontWeight.Black)
                Text("Demo balance", color = Color.White.copy(alpha = .7f))
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("Coin packages", fontWeight = FontWeight.Bold, color = Navy, fontSize = 18.sp)
        listOf("100 Coins", "500 Coins", "1,000 Coins").forEach {
            Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(it, modifier = Modifier.weight(1f), color = Navy, fontWeight = FontWeight.Bold)
                    Text("Coming soon", color = Blue, fontSize = 12.sp)
                }
            }
        }
        Text("Paid coin purchase is not enabled in this starter build.", color = Color.Gray, fontSize = 11.sp)
    }
}

@Composable
fun ProfileScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(25.dp))
        Box(Modifier.size(92.dp).background(Brush.linearGradient(listOf(Blue, Gold)), CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Person, null, tint = Color.White, modifier = Modifier.size(52.dp))
        }
        Spacer(Modifier.height(12.dp))
        Text("Wyak User", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Navy)
        Text("User ID: 10000001", color = Color.Gray)
        Spacer(Modifier.height(24.dp))
        listOf("Edit Profile", "My Friends", "My Gifts", "VIP Center", "Settings", "Help & Support").forEach {
            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(it, modifier = Modifier.weight(1f), color = Navy)
                    Icon(Icons.Default.ChevronRight, null, tint = Color.Gray)
                }
            }
        }
    }
}
