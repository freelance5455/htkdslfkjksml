import express from "express";
import cors from "cors";
import helmet from "helmet";
import morgan from "morgan";
import { z } from "zod";

const app = express();
app.use(helmet());
app.use(cors());
app.use(express.json({ limit: "200kb" }));
app.use(morgan("dev"));

const PORT = process.env.PORT || 4000;

// Demo-only memory storage. Replace with PostgreSQL before production.
const users = [{ id: "10000001", displayName: "Wyak User", coins: 250 }];
const rooms = [
  { id: "WP-10001", name: "Friends Hangout", hostId: "10000001", capacity: 8, members: ["10000001"] },
  { id: "WP-10002", name: "Music & Masti", hostId: "10000001", capacity: 8, members: [] }
];

app.get("/health", (_req, res) => res.json({ ok: true, service: "wyak-party-api" }));

app.get("/api/v1/me/demo", (_req, res) => {
  res.json({ user: users[0], note: "Demo endpoint only; add authentication before production." });
});

app.get("/api/v1/rooms", (_req, res) => {
  res.json({ rooms: rooms.map(r => ({ ...r, memberCount: r.members.length })) });
});

const createRoomSchema = z.object({
  name: z.string().trim().min(3).max(40),
  hostId: z.string().min(1)
});

app.post("/api/v1/rooms", (req, res) => {
  const parsed = createRoomSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid room data", details: parsed.error.flatten() });
  const room = {
    id: `WP-${String(10000 + rooms.length + 1)}`,
    name: parsed.data.name,
    hostId: parsed.data.hostId,
    capacity: 8,
    members: [parsed.data.hostId]
  };
  rooms.push(room);
  res.status(201).json({ room });
});

app.post("/api/v1/rooms/:roomId/join", (req, res) => {
  const room = rooms.find(r => r.id === req.params.roomId);
  if (!room) return res.status(404).json({ error: "Room not found" });
  const userId = typeof req.body?.userId === "string" ? req.body.userId : "";
  if (!userId) return res.status(400).json({ error: "userId is required" });
  if (!room.members.includes(userId) && room.members.length >= room.capacity) {
    return res.status(409).json({ error: "Room is full" });
  }
  if (!room.members.includes(userId)) room.members.push(userId);
  res.json({ roomId: room.id, joined: true, memberCount: room.members.length });
});

app.post("/api/v1/rooms/:roomId/leave", (req, res) => {
  const room = rooms.find(r => r.id === req.params.roomId);
  if (!room) return res.status(404).json({ error: "Room not found" });
  const userId = typeof req.body?.userId === "string" ? req.body.userId : "";
  room.members = room.members.filter(id => id !== userId);
  res.json({ roomId: room.id, left: true, memberCount: room.members.length });
});

// Never add paid coins from a client-supplied amount.
// Production flow: verify Google Play purchase token on server, then credit ledger.
app.post("/api/v1/payments/verify-placeholder", (_req, res) => {
  res.status(501).json({
    error: "Payments are not enabled",
    instruction: "Implement Google Play Billing purchase-token verification on the server before enabling paid coins."
  });
});

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: "Internal server error" });
});

app.listen(PORT, () => console.log(`Wyak Party API listening on port ${PORT}`));
