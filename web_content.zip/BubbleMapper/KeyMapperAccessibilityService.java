public class KeyMapperAccessibilityService extends AccessibilityService {

    private WindowManager windowManager;
    private final List<View> bubbleViews = new ArrayList<>();
    private final Map<View, Character> bubbleKeys = new HashMap<>();

    // Chame isto do JavaScript via ponte para criar as bolhas
    public void createBubbles(int count, float size, float opacity, String[] keys) {
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        removeAllBubbles();

        for (int i = 0; i < count; i++) {
            if (keys[i] == null || keys[i].isEmpty()) continue;
            addBubble(i, size, opacity, keys[i].charAt(0));
        }
    }

    private void addBubble(int id, float sizePx, float opacity, char key) {
        FrameLayout bubble = new FrameLayout(this);
        bubble.setBackgroundResource(R.drawable.bubble_background); // cinza semi-transparente
        bubble.setAlpha(opacity);

        TextView label = new TextView(this);
        label.setText(String.valueOf(key));
        label.setTextSize(sizePx * 0.4f / getResources().getDisplayMetrics().density);
        label.setTextColor(Color.BLACK);
        label.setGravity(Gravity.CENTER);
        bubble.addView(label);

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                (int) sizePx, (int) sizePx,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 200 + (id % 4) * 120;
        params.y = 400 + (id / 4) * 120;

        bubble.setOnTouchListener(new BubbleTouchListener(params, sizePx, key));
        windowManager.addView(bubble, params);
        bubbleViews.add(bubble);
        bubbleKeys.put(bubble, key);
    }

    // Injeção da tecla no app em foco (GTA)
    private void sendKeyToFocusedApp(char c) {
        int keyCode = KeyEvent.keyCodeFromString(String.valueOf(c));
        if (keyCode == KeyEvent.KEYCODE_UNKNOWN) return;

        long now = SystemClock.uptimeMillis();
        KeyEvent down = new KeyEvent(now, now, KeyEvent.ACTION_DOWN, keyCode, 0);
        KeyEvent up = new KeyEvent(now, now, KeyEvent.ACTION_UP, keyCode, 0);

        // Injeta via InputConnection do app em foco
        AccessibilityNodeInfo focus = getRootInActiveWindow();
        if (focus != null) {
            InputConnection conn = focus.getInputConnection();
            if (conn != null) {
                conn.sendKeyEvent(down);
                conn.sendKeyEvent(up);
            }
        }
    }

    private class BubbleTouchListener implements View.OnTouchListener {
        private final WindowManager.LayoutParams params;
        private final float size;
        private final char key;
        private float initialX, initialY;
        private float initialTouchX, initialTouchY;
        private boolean moved;

        BubbleTouchListener(WindowManager.LayoutParams p, float s, char k) {
            this.params = p; this.size = s; this.key = k;
        }

        @Override
        public boolean onTouch(View v, MotionEvent event) {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    initialX = params.x; initialY = params.y;
                    initialTouchX = event.getRawX(); initialTouchY = event.getRawY();
                    moved = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float dx = event.getRawX() - initialTouchX;
                    float dy = event.getRawY() - initialTouchY;
                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true;
                    params.x = (int) (initialX + dx);
                    params.y = (int) (initialY + dy);
                    windowManager.updateViewLayout(v, params);
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!moved) {
                        v.animate().scaleX(0.85f).scaleY(0.85f).setDuration(80)
                         .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f).setDuration(80));
                        sendKeyToFocusedApp(key);
                    }
                    return true;
            }
            return false;
        }
    }

    public void removeAllBubbles() {
        for (View v : bubbleViews) {
            try { windowManager.removeView(v); } catch (Exception ignored) {}
        }
        bubbleViews.clear();
        bubbleKeys.clear();
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {}
    @Override public void onInterrupt() {}
    @Override public void onDestroy() { removeAllBubbles(); super.onDestroy(); }
}