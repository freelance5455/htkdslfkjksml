/* ============================================================
   KeyBubbles — app.js
   ============================================================ */
(() => {
  'use strict';

  const N = 8;                              // quantidade de bolhas
  const STORE = 'keybubbles.v1';
  const DEFAULT_KEYS = ['G', 'P', 'T', 'H', 'K', 'L', 'X', 'Z'];

  const $ = (s) => document.querySelector(s);
  const layer     = $('#bubbleLayer');
  const listEl    = $('#list');
  const logEl     = $('#log');
  const ovLogEl   = $('#overlayLog');
  const overlay   = $('#overlay');
  const btnToggle = $('#toggleOverlay');

  let state = load();

  /* ============================================================
     ESTADO / PERSISTÊNCIA
     ============================================================ */
  function makeDefault() {
    return {
      size: 66,
      opacity: 0.72,
      bubbles: DEFAULT_KEYS.map((k, i) => ({
        id: i,
        key: k,
        enabled: i < 3,      // começa com as 3 primeiras ativas
        x: null,
        y: null
      }))
    };
  }

  function load() {
    try {
      const raw = localStorage.getItem(STORE);
      if (!raw) return makeDefault();
      const s = JSON.parse(raw);
      if (!s || !Array.isArray(s.bubbles)) return makeDefault();

      s.bubbles = Array.from({ length: N }, (_, i) => {
        const b = s.bubbles[i] || {};
        return {
          id: i,
          key: typeof b.key === 'string' ? b.key : DEFAULT_KEYS[i],
          enabled: !!b.enabled,
          x: Number.isFinite(b.x) ? b.x : null,
          y: Number.isFinite(b.y) ? b.y : null
        };
      });
      s.size    = clamp(Number(s.size) || 66, 40, 110);
      s.opacity = clamp(Number(s.opacity) || 0.72, 0.3, 1);
      return s;
    } catch (e) {
      return makeDefault();
    }
  }

  function save() {
    try { localStorage.setItem(STORE, JSON.stringify(state)); } catch (e) {}
  }

  /* ============================================================
     HELPERS
     ============================================================ */
  const clamp = (v, a, b) => Math.min(Math.max(v, a), b);

  const escapeHtml = (s) => String(s).replace(/[&<>"']/g, (c) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
  ));

  function clampXY(x, y, size) {
    const maxX = Math.max(4, window.innerWidth  - size - 4);
    const maxY = Math.max(4, window.innerHeight - size - 4);
    return {
      x: clamp(x, 4, maxX),
      y: clamp(y, 4, maxY)
    };
  }

  function defaultPos(i, size) {
    const gap = 14;
    const col = Math.floor(i / 4);
    const row = i % 4;
    const x = window.innerWidth - (col + 1) * (size + gap) - 8;
    const y = Math.round(window.innerHeight * 0.20) + row * (size + gap);
    return clampXY(x, y, size);
  }

  /* ============================================================
     LISTA DE CONFIGURAÇÃO
     ============================================================ */
  function renderList() {
    listEl.innerHTML = '';

    state.bubbles.forEach((b, i) => {
      const row = document.createElement('div');
      row.className = 'row' + (b.enabled ? '' : ' off');
      row.innerHTML = `
        <label class="switch">
          <input type="checkbox" ${b.enabled ? 'checked' : ''}>
          <span class="track"></span>
        </label>
        <span class="idx">${i + 1}</span>
        <input class="keyInput" type="text" maxlength="1"
               value="${escapeHtml(b.key)}"
               autocomplete="off" autocorrect="off"
               autocapitalize="characters" spellcheck="false"
               inputmode="text">
        <div class="chip">${escapeHtml(b.key || '–')}</div>
      `;

      // liga / desliga
      const cb = row.querySelector('input[type="checkbox"]');
      cb.addEventListener('change', () => {
        b.enabled = cb.checked;
        row.classList.toggle('off', !b.enabled);
        save();
        renderBubbles();
      });

      // tecla
      const ki = row.querySelector('.keyInput');
      ki.addEventListener('input', () => {
        const v = ki.value.trim().toUpperCase().slice(0, 1);
        ki.value = v;
        b.key = v;
        row.querySelector('.chip').textContent = v || '–';
        save();
        renderBubbles();
      });
      ki.addEventListener('focus', () => ki.select());

      listEl.appendChild(row);
    });
  }

  /* ============================================================
     RENDERIZA AS BOLHAS NO OVERLAY
     ============================================================ */
  function renderBubbles() {
    layer.innerHTML = '';

    const size = state.size;

    state.bubbles.forEach((b, i) => {
      if (!b.enabled || !b.key) return;

      // posição inicial automática na primeira vez
      if (b.x === null || b.y === null) {
        const p = defaultPos(i, size);
        b.x = p.x;
        b.y = p.y;
        save();
      }

      const p = clampXY(b.x, b.y, size);

      const el = document.createElement('div');
      el.className = 'bubble';
      el.textContent = b.key;
      el.dataset.id = i;
      el.style.setProperty('--size', size + 'px');
      el.style.setProperty('--op', state.opacity);
      el.style.left = p.x + 'px';
      el.style.top  = p.y + 'px';

      attachBubble(el, b);
      layer.appendChild(el);
    });

    if (!layer.querySelector('.bubble')) {
      const empty = document.createElement('div');
      empty.className = 'ov-empty';
      empty.textContent = 'Nenhuma bolha ativa';
      layer.appendChild(empty);
    }
  }

  /* ============================================================
     ARRASTAR + CLICAR
     ============================================================ */
  function attachBubble(el, b) {
    let dragging = false;
    let moved = false;
    let pid = null;
    let sx = 0, sy = 0, ox = 0, oy = 0;

    el.addEventListener('pointerdown', (e) => {
      e.preventDefault();
      e.stopPropagation();

      pid = e.pointerId;
      try { el.setPointerCapture(pid); } catch (_) {}

      dragging = true;
      moved = false;
      sx = e.clientX; sy = e.clientY;
      ox = parseFloat(el.style.left) || 0;
      oy = parseFloat(el.style.top)  || 0;

      el.classList.add('grabbing');
    });

    el.addEventListener('pointermove', (e) => {
      if (!dragging || e.pointerId !== pid) return;

      const dx = e.clientX - sx;
      const dy = e.clientY - sy;

      if (!moved && Math.hypot(dx, dy) > 6) moved = true;

      if (moved) {
        const p = clampXY(ox + dx, oy + dy, state.size);
        el.style.left = p.x + 'px';
        el.style.top  = p.y + 'px';
      }
    });

    const finish = (e) => {
      if (!dragging || e.pointerId !== pid) return;
      dragging = false;
      el.classList.remove('grabbing');

      try { el.releasePointerCapture(pid); } catch (_) {}
      pid = null;

      if (moved) {
        b.x = parseFloat(el.style.left);
        b.y = parseFloat(el.style.top);
        save();
      } else {
        fire(el, b);
      }
    };

    el.addEventListener('pointerup', finish);
    el.addEventListener('pointercancel', finish);
  }

  function fire(el, b) {
    el.classList.add('hit');
    setTimeout(() => el.classList.remove('hit'), 140);

    if (navigator.vibrate) {
      try { navigator.vibrate(12); } catch (_) {}
    }

    sendKey(b.key);
  }

  /* ============================================================
     ENVIO DA TECLA
     ============================================================ */
  function sendKey(rawKey) {
    const key = String(rawKey || '').trim();

    if (!key) {
      addLog('bolha sem tecla configurada', 'warn');
      return;
    }

    let via = 'web';

    // ---- 1) Ponte nativa Android (WebView / Capacitor / Cordova) ----
    try {
      if (window.AndroidKeyBridge && typeof window.AndroidKeyBridge.sendKey === 'function') {
        window.AndroidKeyBridge.sendKey(key);
        via = 'android';
      } else if (window.Android && typeof window.Android.sendKey === 'function') {
        window.Android.sendKey(key);
        via = 'android';
      } else if (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.KeySender) {
        window.Capacitor.Plugins.KeySender.send({ key });
        via = 'capacitor';
      }
    } catch (err) {
      console.warn('[KeyBubbles] ponte nativa falhou:', err);
      via = 'web';
    }

    // ---- 2) Fallback web: dispara KeyboardEvent ----
    dispatchKeyEvent(key);

    addLog(`tecla "${key}" enviada`, via);

    window.dispatchEvent(new CustomEvent('keybubbles:key', {
      detail: { key, via }
    }));
  }

  /* ---- mapeamento de tecla -> evento ---- */
  function keyInfo(k) {
    if (k.length === 1) {
      const up = k.toUpperCase();
      if (up >= 'A' && up <= 'Z') {
        return { key: k, code: 'Key' + up, keyCode: up.charCodeAt(0) };
      }
      if (k >= '0' && k <= '9') {
        return { key: k, code: 'Digit' + k, keyCode: k.charCodeAt(0) };
      }
      return { key: k, code: 'Unidentified', keyCode: k.charCodeAt(0) };
    }

    const named = {
      enter:     { key: 'Enter',     code: 'Enter',       keyCode: 13 },
      space:     { key: ' ',         code: 'Space',       keyCode: 32 },
      tab:       { key: 'Tab',       code: 'Tab',         keyCode: 9  },
      esc:       { key: 'Escape',    code: 'Escape',      keyCode: 27 },
      escape:    { key: 'Escape',    code: 'Escape',      keyCode: 27 },
      backspace: { key: 'Backspace', code: 'Backspace',   keyCode: 8  },
      del:       { key: 'Delete',    code: 'Delete',      keyCode: 46 },
      shift:     { key: 'Shift',     code: 'ShiftLeft',   keyCode: 16 },
      ctrl:      { key: 'Control',   code: 'ControlLeft', keyCode: 17 },
      alt:       { key: 'Alt',       code: 'AltLeft',     keyCode: 18 },
      up:        { key: 'ArrowUp',   code: 'ArrowUp',     keyCode: 38 },
      down:      { key: 'ArrowDown', code: 'ArrowDown',   keyCode: 40 },
      left:      { key: 'ArrowLeft', code: 'ArrowLeft',   keyCode: 37 },
      right:     { key: 'ArrowRight',code: 'ArrowRight',  keyCode: 39 }
    };

    return named[k.toLowerCase()] || { key: k, code: 'Unidentified', keyCode: 0 };
  }

  function dispatchKeyEvent(k) {
    const info = keyInfo(k);
    const target = document.activeElement || document.body;

    const base = {
      key: info.key,
      code: info.code,
      keyCode: info.keyCode,
      which: info.keyCode,
      charCode: info.key.length === 1 ? info.key.charCodeAt(0) : 0,
      bubbles: true,
      cancelable: true,
      composed: true,
      view: window
    };

    try {
      target.dispatchEvent(new KeyboardEvent('keydown', base));
      if (info.key.length === 1) {
        target.dispatchEvent(new KeyboardEvent('keypress', base));
      }
      target.dispatchEvent(new KeyboardEvent('keyup', base));
    } catch (err) {
      console.warn('[KeyBubbles] dispatch falhou:', err);
    }
  }

  /* ============================================================
     LOG
     ============================================================ */
  function addLog(msg, tag) {
    const t = new Date().toLocaleTimeString('pt-BR', { hour12: false });
    const html =
      `<span class="t">${t}</span>` +
      `<span class="m">${escapeHtml(msg)}</span>` +
      `<span class="tag ${tag}">${tag}</span>`;

    const a = document.createElement('div');
    a.className = 'log-line';
    a.innerHTML = html;
    logEl.prepend(a);
    while (logEl.children.length > 50) logEl.lastChild.remove();

    const b = document.createElement('div');
    b.className = 'ov-line';
    b.innerHTML = html;
    ovLogEl.prepend(b);
    while (ovLogEl.children.length > 3) ovLogEl.lastChild.remove();
  }

  /* ============================================================
     INICIALIZAÇÃO
     ============================================================ */
  function init() {
    // sliders
    const sizeEl = $('#size');
    const opEl   = $('#opacity');
    const sizeOut = $('#sizeOut');
    const opOut   = $('#opOut');

    sizeEl.value = state.size;
    opEl.value   = state.opacity;
    sizeOut.textContent = state.size + 'px';
    opOut.textContent   = Math.round(state.opacity * 100) + '%';

    sizeEl.addEventListener('input', (e) => {
      state.size = Number(e.target.value);
      sizeOut.textContent = state.size + 'px';
      save();
      renderBubbles();
    });

    opEl.addEventListener('input', (e) => {
      state.opacity = Number(e.target.value);
      opOut.textContent = Math.round(state.opacity * 100) + '%';
      save();
      renderBubbles();
    });

    // botões "todas / nenhuma"
    document.querySelectorAll('[data-bulk]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const on = btn.dataset.bulk === 'all';
        state.bubbles.forEach((b) => { b.enabled = on; });
        save();
        renderList();
        renderBubbles();
      });
    });

    // limpar log
    $('#clearLog').addEventListener('click', () => {
      logEl.innerHTML = '';
      ovLogEl.innerHTML = '';
    });

    // ativar / desativar modo flutuante
    btnToggle.addEventListener('click', () => {
      const ativo = overlay.classList.toggle('hidden') === false;
      btnToggle.textContent = ativo ? 'Sair do modo flutuante' : 'Ativar modo flutuante';
      if (ativo) {
        renderBubbles();
        addLog('modo flutuante ativado', 'info');
      }
    });

    // fechar pelo X
    $('#closeOverlay').addEventListener('click', () => {
      overlay.classList.add('hidden');
      btnToggle.textContent = 'Ativar modo flutuante';
    });

    // manter bolhas dentro da tela ao girar / redimensionar
    window.addEventListener('resize', () => {
      let changed = false;
      state.bubbles.forEach((b) => {
        if (b.x === null) return;
        const p = clampXY(b.x, b.y, state.size);
        if (p.x !== b.x || p.y !== b.y) { b.x = p.x; b.y = p.y; changed = true; }
      });
      if (changed) save();
      renderBubbles();
    });

    renderList();
    renderBubbles();
    addLog('pronto — configure as bolhas e ative o modo flutuante', 'info');
  }

  /* ============================================================
     API PÚBLICA (pra usar de fora / da ponte nativa)
     ============================================================ */
  window.KeyBubbles = {
    send: sendKey,
    getState: () => JSON.parse(JSON.stringify(state)),
    setEnabled(id, on) {
      const b = state.bubbles[id];
      if (!b) return;
      b.enabled = !!on;
      save(); renderList(); renderBubbles();
    },
    setKey(id, key) {
      const b = state.bubbles[id];
      if (!b) return;
      b.key = String(key || '').toUpperCase().slice(0, 1);
      save(); renderList(); renderBubbles();
    },
    reset() {
      state = makeDefault();
      save(); renderList(); renderBubbles();
    }
  };

  init();
})();