REAMAB V2 - Salary & Expense Manager

Updated V2 features:
- Analytics and budget score
- Savings goals and monthly target calculation
- Local data storage
- JSON backup and restore
- Localized PDF report generation
- PDF print/save flow from the Reports page and Settings
- Budget distribution and category naming
- Themes, currency selection, expenses and notes

Supported languages:
- العربية (Arabic)
- English
- Français (French)
- 简体中文 (Simplified Chinese)

AI has been completely removed from this V2 build.

PDF:
The PDF report is generated from the current salary, budget distribution and expense data. The report follows the selected app language and opens the device print dialog, where the user can choose Save as PDF when supported by the device.
