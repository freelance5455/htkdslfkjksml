"use strict";

const requiredNum = 'required step="any"';
const weightAttr = requiredNum + ' min="0.000001" max="1000000"';
const markAttr = requiredNum + ' min="0" max="20"';
const subOptions = (selected, all = false) => D.subjects.filter(s => all || s.show).map(s => option(s.id, s.name, selected)).join("");
const terms = t => [1, 2, 3].map(i => option(i, "Trimestre " + i, t)).join("");
function gradeRows(gs) {
  return gs.slice().sort((a, b) => b.date.localeCompare(a.date)).map(g => '<div class="entry"><div class="row"><strong>' + esc(g.name) + '</strong><b>' + fmt(g.score) + ' / ' + fmt(g.max) + '</b></div><small>' + g.date + ' · T' + g.t + ' · coef. ' + fmt(g.coef) + (g.cat ? " · " + (g.cat === "pc" ? "Physique-chimie" : "Maths de spécialité") : "") + '</small>' + (g.comment ? '<p>' + esc(g.comment) + '</p>' : '') + btn("Modifier", "editGrade('" + g.sub + "','" + g.id + "')", "link") + btn("Supprimer", "removeGrade('" + g.id + "')", "link danger") + '</div>').join("");
}
function gradeCard(s) {
  let gs = D.grades.filter(g => g.sub === s.id && (!T || g.t === T)),
    o = D.official[s.id + "-" + T];
  return '<details class="subject"><summary><span>' + esc(s.name) + '<br><small>' + gs.length + ' note(s) · coef. bulletin ' + fmt(s.coef) + (o && o.use ? ' · moyenne officielle' : '') + '</small></span><b>' + fmt(subjectAvg(D, s.id, T)) + ' / 20 ▾</b></summary>' + gradeRows(gs) + (s.id === "pcm" ? ["pc", "ms"].map(cat => '<p class="small">' + (cat === "pc" ? "Physique-chimie" : "Mathématiques de spécialité") + ' · ' + fmt(T ? noteMean(gs.filter(g => g.cat === cat)) : equal([1, 2, 3].map(t => noteMean(gs.filter(g => g.cat === cat && g.t === t))))) + ' / 20</p>').join("") : '') + '<div class="inline">' + btn("+ Note", "editGrade('" + s.id + "')") + (T ? btn("Moyenne officielle", "official('" + s.id + "')", "link") : "") + '</div></details>';
}
function bulletinCards(group) {
  const visible = D.subjects.filter(s => s.show);
  if (!group) return visible.map(gradeCard).join("");
  const inGroup = s => s.id === "tech" || s.id === "itec";
  const children = visible.filter(inGroup);
  const others = visible.filter(s => !inGroup(s)).map(gradeCard).join("");
  if (!children.length) return others;
  return others + '<details class="subject"><summary><span>2I2D + ITEC<br><small>Groupe · coefficient ' + fmt(group.w) + '</small></span><b>' + fmt(group.v) + ' / 20 ▾</b></summary>' + children.map(gradeCard).join("") + '</details>';
}
function gradesPage() {
  let prev = T > 1 ? general(D, T - 1) : null,
    cur = general(D, T),
    diff = prev == null || cur == null ? null : cur - prev,
    group = groups(D, T).find(s => s.id === "group");
  return heading("Bulletin scolaire", "Mes moyennes") + '<div class="tabs">' + [1, 2, 3, 0].map(i => btn(i ? "Trimestre " + i : "Année complète", "T=" + i + ";render()", T === i ? "active" : "")).join("") + '</div><section class="card"><div class="row"><div><span class="small">' + (T ? "Moyenne du trimestre" : "Année complète") + '</span><h2>' + fmt(cur) + ' / 20</h2></div>' + btn("+ Ajouter une note", "editGrade()", "primary") + '</div><p class="small">Année provisoire · ' + fmt(general(D, 0)) + ' / 20' + (diff == null ? '' : ' · Évolution ' + (diff >= 0 ? '+' : '') + fmt(diff) + ' point(s) depuis T' + (T - 1)) + '</p></section><div class="inline spaced">' + btn("Simuler une note", "simulate()") + btn("Gérer les matières", "subjectsDialog()") + (T ? btn("Moyenne Pronote", "official('general')") : "") + '</div>' + bulletinCards(group) + '<div class="row total"><span>MOYENNE GÉNÉRALE</span><strong>' + fmt(cur) + ' / 20</strong></div><p class="small">' + (D.official["general-" + T] && D.official["general-" + T].use ? "Moyenne générale officielle activée. " : "") + 'Année provisoire = moyenne simple des trimestres renseignés. Masquer une matière conserve sa contribution au bulletin. Un coefficient de bulletin nul l’exclut.</p>';
}
function catOptions(v) {
  return option("pc", "Physique-chimie", v) + option("ms", "Mathématiques de spécialité", v);
}
function editGrade(sub, id) {
  if (!D.subjects.length) {
    subjectsDialog();
    return;
  }
  let g = D.grades.find(g => g.id === id) || {
    sub: sub || (D.subjects.find(s => s.show) || {}).id || D.subjects[0].id,
    name: "",
    score: "",
    max: 20,
    coef: 1,
    date: day(),
    t: T || term(D),
    comment: "",
    cat: "pc"
  };
  dlg(id ? "Modifier l’évaluation" : "Ajouter une note", '<form>' + choose("Matière", "sub", subOptions(g.sub, true)) + '<div id="categ">' + choose("Sous-catégorie", "cat", catOptions(g.cat)) + '</div>' + field("Nom de l’évaluation", "name", g.name, "text", 'required maxlength="160"') + '<div class="two">' + field("Note obtenue", "score", g.score, "number", requiredNum + ' min="0" max="' + g.max + '"') + field("Barème", "max", g.max, "number", weightAttr + ' list="baremes"') + '</div><datalist id="baremes"><option>5</option><option>10</option><option>20</option><option>40</option></datalist><div class="two">' + field("Coefficient", "coef", g.coef, "number", weightAttr) + field("Date", "date", g.date, "date", "required") + '</div>' + choose("Trimestre", "t", terms(g.t)) + '<label>Commentaire facultatif<textarea name="comment" maxlength="2000">' + esc(g.comment) + '</textarea></label><button class="primary">Enregistrer la note</button></form>', f => {
    let e = f.elements;
    let item = {
      id: id || uid(),
      sub: e.sub.value,
      cat: e.sub.value === "pcm" ? e.cat.value : "",
      name: e.name.value.trim(),
      score: +e.score.value,
      max: +e.max.value,
      coef: +e.coef.value,
      date: e.date.value,
      t: +e.t.value,
      comment: e.comment.value.trim()
    };
    if (!item.name) {
      notice("Donne un nom à l’évaluation.");
      return;
    }
    if (id) D.grades[D.grades.findIndex(x => x.id === id)] = item;else D.grades.push(item);
    commit();
  });
  let e = $("#inside form").elements;
  const sync = () => {
    $("#categ").hidden = e.sub.value !== "pcm";
    e.score.max = e.max.value;
  };
  e.sub.onchange = e.max.oninput = sync;
  e.date.onchange = () => {
    e.t.value = term(D, e.date.value);
  };
  sync();
}
function removeGrade(id) {
  let g = D.grades.find(x => x.id === id);
  if (g) confirmAction("Supprimer « " + g.name + " » ?", () => {
    D.grades = D.grades.filter(x => x.id !== id);
    commit();
  });
}
function official(id) {
  let k = id + "-" + T,
    o = D.official[k] || {
      value: "",
      use: true
    };
  dlg("Moyenne officielle · T" + T, '<form><p>' + esc(id === "general" ? "Moyenne générale" : nameOf(id)) + '</p>' + field("Valeur Pronote / 20", "value", o.value, "number", markAttr) + check("Utiliser cette valeur pour ce trimestre", "use", o.use) + '<button class="primary">Enregistrer</button></form>' + btn("Effacer cette valeur", "clearOfficial('" + k + "')", "link"), f => {
    D.official[k] = {
      value: +f.elements.value.value,
      use: f.elements.use.checked
    };
    commit();
  });
}
function clearOfficial(k) {
  delete D.official[k];
  commit();
}
function subjectsDialog() {
  dlg("Matières du bulletin", '<p>Le coefficient agit sur la moyenne générale. Le réglage de visibilité agit sur les listes et les recommandations.</p>' + D.subjects.map(s => '<div class="row entry"><span>' + esc(s.name) + ' · ' + fmt(s.coef) + '</span>' + btn("Modifier", "editSub('" + s.id + "')") + '</div>').join("") + btn("+ Nouvelle matière", "editSub()", "primary"));
}
function editSub(id) {
  let s = D.subjects.find(s => s.id === id) || {
    name: "",
    coef: 1,
    show: true
  };
  dlg(id ? "Modifier la matière" : "Nouvelle matière", '<form>' + field("Libellé", "name", s.name, "text", 'required maxlength="100"') + field("Coefficient de bulletin", "coef", s.coef, "number", requiredNum + ' min="0" max="1000000"') + check("Afficher cette matière", "show", s.show) + '<button class="primary">Enregistrer</button></form>' + (id ? btn("Supprimer cette matière et ses notes", "removeSub('" + id + "')", "link danger") : ""), f => {
    let e = f.elements,
      n = e.name.value.trim();
    if (!n) {
      notice("Indique un libellé.");
      return;
    }
    if (!id && D.subjects.some(s => s.name === n)) {
      notice("Ce libellé existe déjà.");
      return;
    }
    let existingId = Object.keys(SUBJECTS).find(k => SUBJECTS[k] === n && !D.subjects.some(s => s.id === k));
    Object.assign(s, {
      id: id || existingId || uid(),
      name: n,
      coef: +e.coef.value,
      show: e.show.checked
    });
    if (!id) D.subjects.push(s);
    commit();
  });
}
function removeSub(id) {
  confirmAction("Supprimer la matière, ses notes et ses moyennes officielles ?", () => {
    D.subjects = D.subjects.filter(s => s.id !== id);
    D.grades = D.grades.filter(g => g.sub !== id);
    [1, 2, 3].forEach(t => delete D.official[id + "-" + t]);
    commit();
  });
}
function simulate() {
  if (!D.subjects.length) {
    subjectsDialog();
    return;
  }
  let sub = D.subjects[0].id;
  dlg("Simuler une prochaine note", '<form>' + choose("Matière", "sub", subOptions(sub, true)) + '<div id="simcat">' + choose("Sous-catégorie", "cat", catOptions("pc")) + '</div>' + choose("Trimestre", "t", terms(T || term(D))) + '<div class="two">' + field("Note simulée / 20", "score", 15, "number", markAttr) + field("Coefficient", "coef", 1, "number", weightAttr) + '</div>' + choose("Objectif à atteindre", "scope", option("mat", "Moyenne de la matière", "mat") + option("gen", "Moyenne générale", "mat")) + field("Cible / 20", "target", D.settings.goal, "number", markAttr) + '<button class="primary">Calculer</button><div id="simresult" aria-live="polite"></div></form>', f => {
    let e = f.elements,
      t = +e.t.value,
      id = e.sub.value;
    let extra = {
      sub: id,
      t,
      cat: e.cat.value,
      max: 20,
      coef: +e.coef.value,
      score: +e.score.value
    };
    let calc = x => e.scope.value === "mat" ? subjectAvg(D, id, t, Object.assign({}, extra, {
      score: x
    })) : general(D, t, Object.assign({}, extra, {
      score: x
    }));
    let lo = calc(0),
      hi = calc(20),
      n = needed(lo, hi, +e.target.value);
    $("#simresult").innerHTML = '<div class="feedback">Avec cette note · ' + fmt(calc(extra.score)) + ' / 20<br>' + (lo === hi ? 'Cette note ne modifie pas la moyenne sélectionnée. Vérifie les coefficients ou les moyennes officielles.' : n == null ? 'Cible inaccessible avec cette seule note.' : 'Note minimale pour la cible · ' + fmt(n) + ' / 20') + '</div>';
  });
  let f = $("#inside form");
  function update() {
    $("#simcat").hidden = f.elements.sub.value !== "pcm";
    $("#simresult").innerHTML = "";
  }
  f.oninput = update;
  update();
}
