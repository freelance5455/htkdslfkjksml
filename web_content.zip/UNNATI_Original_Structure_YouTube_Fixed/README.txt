UNNATI - Original APK Structure with YouTube Links Fixed

This package uses the original assets/www/index.html extracted from the user-provided UNNATI.apk as the base. Original layout, colors, navigation, screens and existing demo functions are preserved. Changes are limited to the Training & Courses screen and its video-opening behavior.

The three supplied YouTube URLs are included exactly as provided. Video links navigate in the same WebView/tab to avoid Android WebView target=_blank pop-up issues. Use the Back button to return to UNNATI. Internet is required.

This is an HTML demo package, not a rebuilt/signed APK. To update the installed Android APK, its Android project/WebView wrapper must package this index.html and handle external URLs as appropriate.
