# DragonFiles Web UI

Esta pasta contém a interface `index.html` conectada ao Firebase Web SDK:
- Firebase Authentication (cadastro/login)
- Cloud Firestore (metadados e uso informado)
- Firebase Storage (upload/download/exclusão)
- Tema roxo/preto responsivo

## Configuração
1. Crie um app do tipo Web no Firebase Console.
2. Copie a configuração do SDK para `firebase-config.js`.
3. Ative Authentication > Email/Password, Firestore Database e Storage.
4. Publique as regras dos arquivos `firestore.rules` e `storage.rules`.
5. Sirva a pasta por um servidor HTTP/HTTPS (por exemplo, Firebase Hosting). Não abra o HTML diretamente como `file://`.

## Firebase Hosting
Instale Firebase CLI, execute `firebase login`, `firebase init hosting`, escolha esta pasta como public e publique com `firebase deploy`.

## Limite de 5 GB
A interface faz uma verificação de uso para a experiência básica, mas não é uma barreira de segurança confiável: um cliente modificado pode falsificar metadados ou iniciar uploads concorrentes. As Storage Rules não conseguem somar todos os arquivos de um usuário. Antes de oferecer publicamente, mova reserva de cota, atualização de uso e confirmação/exclusão para Cloud Functions/servidor confiável, com operações atômicas e tratamento de uploads interrompidos. Não coloque service-account keys no navegador ou no APK.

As credenciais do Firebase Web (apiKey etc.) identificam o projeto, não são uma senha administrativa. A segurança real depende das regras corretas e do backend.
