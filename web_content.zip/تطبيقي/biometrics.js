/* ============================================
   AMMAR VAULT – js/biometrics.js
   فتح التطبيق بالبصمة (Android)
   ============================================ */

import { Capacitor } from '@capacitor/core';
import { Meta, saveToStore } from './database.js';

let NativeBiometric = null;

async function _getPlugin() {
  if (NativeBiometric) return NativeBiometric;
  try {
    const mod = await import('@capgo/capacitor-native-biometric');
    NativeBiometric = mod.NativeBiometric;
    return NativeBiometric;
  } catch (e) {
    console.warn('Biometric plugin not available', e);
    return null;
  }
}

/**
 * هل البصمة متاحة ومفعّلة على الجهاز؟
 */
export async function isBiometricAvailable() {
  if (Capacitor.getPlatform() !== 'android' && Capacitor.getPlatform() !== 'ios') {
    return false;
  }
  const plugin = await _getPlugin();
  if (!plugin) return false;
  try {
    const res = await plugin.isAvailable();
    return !!res.isAvailable;
  } catch (e) {
    return false;
  }
}

/**
 * تفعيل البصمة.
 * يطلب التحقق مرة واحدة ثم يخزن علم في meta.
 * ملاحظة أمنية: لا نخزن كلمة المرور نفسها — بل نستخدم
 * مصادقة البصمة كبديل للتحقق من المستخدم، ثم يُفتح التطبيق
 * فقط إذا كان قد فُتح سابقاً بنجاح. في هذا التطبيق سنستخدم
 * البصمة للتحقق من هوية المستخدم فقط ثم نطلب منه إدخال كلمة
 * المرور مرة لكل جلسة على الويب، لكن على Android يمكن تخزين
 * مفتاح مشفر في SecureStorage (نستخدم ملف منفصل هنا).
 */
export async function enableBiometric() {
  const plugin = await _getPlugin();
  if (!plugin) throw new Error('البصمة غير متاحة على هذا الجهاز.');

  const available = await isBiometricAvailable();
  if (!available) throw new Error('البصمة غير متاحة على هذا الجهاز.');

  // تحقق واحد لتفعيل
  await plugin.verifyIdentity({
    reason: 'تفعيل فتح AMMAR VAULT بالبصمة',
    title: 'تأكيد الهوية',
    subtitle: 'استخدم بصمتك للتفعيل',
    description: 'لن يتم تخزين أي بيانات بيومترية على الجهاز، فقط إشارة تفعيل.'
  });

  await Meta.set('biometric_enabled', '1');
  await saveToStore();
  return true;
}

/**
 * تعطيل البصمة.
 */
export async function disableBiometric() {
  await Meta.set('biometric_enabled', '0');
  await saveToStore();
  return true;
}

/**
 * هل البصمة مفعّلة من داخل التطبيق؟
 */
export async function isBiometricEnabled() {
  try {
    const v = await Meta.get('biometric_enabled');
    return v === '1';
  } catch (_) {
    return false;
  }
}

/**
 * محاولة التحقق بالبصمة.
 * تُرجع {ok:true} إذا نجح، {ok:false, error} إذا فشل/أُلغي.
 */
export async function verifyWithBiometric(reason = 'فتح AMMAR VAULT') {
  const plugin = await _getPlugin();
  if (!plugin) return { ok: false, error: 'plugin_missing' };
  try {
    await plugin.verifyIdentity({
      reason,
      title: 'AMMAR VAULT',
      subtitle: 'المصادقة بالبصمة',
      description: 'ضع إصبعك للمتابعة'
    });
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e.message || 'cancelled' };
  }
}