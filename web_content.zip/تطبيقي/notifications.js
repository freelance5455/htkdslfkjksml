/* ============================================
   AMMAR VAULT – js/notifications.js
   الإشعارات المحلية والتذكيرات
   ============================================ */

import { Capacitor } from '@capacitor/core';

let LocalNotifications = null;

async function _getPlugin() {
  if (LocalNotifications) return LocalNotifications;
  try {
    const mod = await import('@capacitor/local-notifications');
    LocalNotifications = mod.LocalNotifications;
    return LocalNotifications;
  } catch (e) {
    console.warn('LocalNotifications plugin not available', e);
    return null;
  }
}

/**
 * طلب إذن الإشعارات (مرة واحدة).
 */
export async function requestNotificationPermission() {
  const plugin = await _getPlugin();
  if (!plugin) return false;
  try {
    const perm = await plugin.checkPermissions();
    if (perm.display === 'granted') return true;
    const req = await plugin.requestPermissions();
    return req.display === 'granted';
  } catch (e) {
    console.warn('request permission failed', e);
    return false;
  }
}

/**
 * جدولة تذكير لمهمة.
 * @param {string} title
 * @param {string} whenISO - ISO string (مثل "2025-12-01T09:30")
 * @param {string} body
 */
export async function scheduleTaskReminder(title, whenISO, body = '') {
  const plugin = await _getPlugin();
  if (!plugin) {
    console.warn('Notifications not available');
    return false;
  }
  try {
    const granted = await requestNotificationPermission();
    if (!granted) return false;

    const when = new Date(whenISO);
    if (isNaN(when.getTime()) || when.getTime() <= Date.now()) {
      console.warn('Reminder time is in the past, skipping');
      return false;
    }

    // ID شبه عشوائي
    const id = Math.floor(Math.random() * 100000) + 1000;

    await plugin.schedule({
      notifications: [
        {
          id,
          title: 'AMMAR VAULT — تذكير',
          body: title + (body ? ' — ' + body.slice(0, 100) : ''),
          schedule: { at: when, allowWhileIdle: true },
          smallIcon: 'ic_stat_icon_config_sample',
          sound: undefined,
          attachments: undefined,
          actionTypeId: '',
          extra: null
        }
      ]
    });

    return { id, when: when.toISOString() };
  } catch (e) {
    console.warn('schedule failed', e);
    return false;
  }
}

/**
 * إلغاء إشعار مجدول.
 */
export async function cancelNotification(id) {
  const plugin = await _getPlugin();
  if (!plugin) return false;
  try {
    await plugin.cancel({ notifications: [{ id }] });
    return true;
  } catch (e) {
    return false;
  }
}

/**
 * إلغاء كل الإشعارات.
 */
export async function cancelAllNotifications() {
  const plugin = await _getPlugin();
  if (!plugin) return false;
  try {
    await plugin.cancelAll();
    return true;
  } catch (e) {
    return false;
  }
}

/**
 * إشعار فوري (اختبار).
 */
export async function showInstantNotification(title, body = '') {
  const plugin = await _getPlugin();
  if (!plugin) return false;
  try {
    const granted = await requestNotificationPermission();
    if (!granted) return false;
    await plugin.schedule({
      notifications: [
        {
          id: Math.floor(Math.random() * 100000) + 2000,
          title,
          body,
          schedule: { at: new Date(Date.now() + 1000) }
        }
      ]
    });
    return true;
  } catch (e) {
    return false;
  }
}

/**
 * الاستماع لضغطات الإشعارات (اختياري).
 */
export async function onNotificationTapped(callback) {
  const plugin = await _getPlugin();
  if (!plugin) return;
  try {
    await plugin.addListener('localNotificationActionPerformed', (action) => {
      if (typeof callback === 'function') callback(action);
    });
  } catch (_) { /* ignore */ }
}