/* ============================================
   AMMAR VAULT – js/database.js
   قاعدة بيانات SQLite مشفرة (SQLCipher) عبر Capacitor
   ============================================ */

import { CapacitorSQLite, SQLiteConnection } from '@capacitor-community/sqlite';
import { Capacitor } from '@capacitor/core';

const DB_NAME = 'ammar_vault';
const DB_VERSION = 1;
const DB_ENCRYPTED = true;
const DB_MODE = 'secret'; // SQLCipher mode

let sqlite = null;
let db = null;
let isOpen = false;

// ======================= الجداول =======================
const CREATE_TABLES_SQL = `
CREATE TABLE IF NOT EXISTS meta (
  key TEXT PRIMARY KEY,
  value TEXT
);

CREATE TABLE IF NOT EXISTS personal_docs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  category TEXT NOT NULL,
  title TEXT NOT NULL,
  holder_name TEXT,
  doc_number TEXT,
  issue_date TEXT,
  expiry_date TEXT,
  notes TEXT,
  attachment TEXT,
  attachment_name TEXT,
  attachment_type TEXT,
  created_at INTEGER
);

CREATE TABLE IF NOT EXISTS passwords (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  username TEXT,
  password_enc TEXT NOT NULL,
  url TEXT,
  notes TEXT,
  created_at INTEGER
);

CREATE TABLE IF NOT EXISTS debts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  person_name TEXT NOT NULL,
  direction TEXT NOT NULL,
  total_amount REAL NOT NULL,
  currency TEXT DEFAULT 'SAR',
  notes TEXT,
  status TEXT DEFAULT 'unpaid',
  created_at INTEGER
);

CREATE TABLE IF NOT EXISTS debt_payments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  debt_id INTEGER NOT NULL,
  amount REAL NOT NULL,
  paid_at INTEGER,
  note TEXT,
  FOREIGN KEY (debt_id) REFERENCES debts(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS files (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  mime_type TEXT,
  size INTEGER,
  data TEXT,
  category TEXT,
  notes TEXT,
  created_at INTEGER
);

CREATE TABLE IF NOT EXISTS albums (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT UNIQUE NOT NULL,
  created_at INTEGER
);

CREATE TABLE IF NOT EXISTS images (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  album_id INTEGER,
  name TEXT,
  mime_type TEXT,
  data TEXT,
  created_at INTEGER,
  FOREIGN KEY (album_id) REFERENCES albums(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  description TEXT,
  due_date TEXT,
  reminder_at TEXT,
  priority TEXT DEFAULT 'normal',
  done INTEGER DEFAULT 0,
  created_at INTEGER
);

CREATE TABLE IF NOT EXISTS summaries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  tags TEXT,
  created_at INTEGER
);

CREATE TABLE IF NOT EXISTS links (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  url TEXT NOT NULL,
  category TEXT,
  notes TEXT,
  created_at INTEGER
);

CREATE INDEX IF NOT EXISTS idx_personal_cat ON personal_docs(category);
CREATE INDEX IF NOT EXISTS idx_files_cat ON files(category);
CREATE INDEX IF NOT EXISTS idx_tasks_due ON tasks(due_date);
CREATE INDEX IF NOT EXISTS idx_images_album ON images(album_id);
`;

// ======================= التهيئة =======================

/**
 * تهيئة قاعدة البيانات. يجب استدعاؤها بعد فتح القفل بكلمة المرور الرئيسية.
 * @param {string} passphrase كلمة المرور الرئيسية (تُستخدم لتشفير DB بـ SQLCipher)
 */
export async function initDatabase(passphrase) {
  if (isOpen) return;

  // على الويب: نستخدم jeep-sqlite (يبقى في IndexedDB لكن كطبقة تطوير فقط).
  if (Capacitor.getPlatform() === 'web') {
    await _ensureWebStore();
  }

  sqlite = new SQLiteConnection(CapacitorSQLite);

  // تحقق من وجود اتصال سابق
  try {
    const consistency = await sqlite.checkConnectionsConsistency();
    if (consistency.result) {
      const isConn = await sqlite.isConnection(DB_NAME, false);
      if (isConn.result) {
        db = await sqlite.retrieveConnection(DB_NAME, false);
        await sqlite.setEncryptionSecret(passphrase);
        await db.open();
        isOpen = true;
        return;
      }
    }
  } catch (_) { /* تجاهل */ }

  db = await sqlite.createConnection(DB_NAME, DB_ENCRYPTED, DB_MODE, DB_VERSION, false);
  await sqlite.setEncryptionSecret(passphrase);
  await db.open();
  isOpen = true;

  // إنشاء الجداول
  await db.execute(CREATE_TABLES_SQL);
}

async function _ensureWebStore() {
  if (!customElements.get('jeep-sqlite')) {
    // استيراد jeep-sqlite ديناميكياً (يجب أن يكون مثبتاً أو من CDN)
    await import('https://cdn.jsdelivr.net/npm/jeep-sqlite@2.7.1/dist/jeep-sqlite/jeep-sqlite.esm.js').catch(() => {});
  }
  if (!document.querySelector('jeep-sqlite')) {
    const el = document.createElement('jeep-sqlite');
    document.body.appendChild(el);
    try {
      await customElements.whenDefined('jeep-sqlite');
      await el.initWebStore();
    } catch (e) {
      console.warn('jeep-sqlite initWebStore failed', e);
    }
  }
}

export async function closeDatabase() {
  if (db && isOpen) {
    try {
      await db.close();
      await sqlite.closeConnection(DB_NAME, false);
    } catch (_) { /* تجاهل */ }
    isOpen = false;
    db = null;
  }
}

export async function saveToStore() {
  if (Capacitor.getPlatform() === 'web' && db) {
    try {
      await sqlite.saveToStore(DB_NAME);
    } catch (_) { /* تجاهل */ }
  }
}

// ======================= تنفيذ استعلامات =======================

async function run(sql, params = []) {
  if (!db) throw new Error('DB not initialized');
  const res = await db.run(sql, params);
  // lastId قد يكون داخل changes أو result
  return {
    changes: res.changes?.changes ?? res.changes ?? 0,
    lastId: res.changes?.lastId ?? null,
    raw: res
  };
}

async function query(sql, params = []) {
  if (!db) throw new Error('DB not initialized');
  const res = await db.query(sql, params);
  return res.values || [];
}

// ======================= Meta (كلمة المرور الرئيسية) =======================

export const Meta = {
  async get(key) {
    const rows = await query('SELECT value FROM meta WHERE key = ?', [key]);
    return rows[0]?.value ?? null;
  },
  async set(key, value) {
    const existing = await Meta.get(key);
    if (existing === null) {
      return run('INSERT INTO meta (key, value) VALUES (?, ?)', [key, value]);
    }
    return run('UPDATE meta SET value = ? WHERE key = ?', [value, key]);
  },
  async delete(key) {
    return run('DELETE FROM meta WHERE key = ?', [key]);
  },
  async hasMaster() {
    return (await Meta.get('master_salt')) !== null;
  }
};

// ======================= الوثائق الشخصية =======================

export const PersonalDocs = {
  async add(doc) {
    return run(
      `INSERT INTO personal_docs
        (category, title, holder_name, doc_number, issue_date, expiry_date, notes, attachment, attachment_name, attachment_type, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        doc.category, doc.title, doc.holder_name || '', doc.doc_number || '',
        doc.issue_date || '', doc.expiry_date || '', doc.notes || '',
        doc.attachment || null, doc.attachment_name || '', doc.attachment_type || '',
        Date.now()
      ]
    );
  },
  async list() {
    return query('SELECT * FROM personal_docs ORDER BY created_at DESC');
  },
  async byCategory(category) {
    return query('SELECT * FROM personal_docs WHERE category = ? ORDER BY created_at DESC', [category]);
  },
  async update(id, doc) {
    return run(
      `UPDATE personal_docs SET
        category = ?, title = ?, holder_name = ?, doc_number = ?,
        issue_date = ?, expiry_date = ?, notes = ?,
        attachment = ?, attachment_name = ?, attachment_type = ?
       WHERE id = ?`,
      [
        doc.category, doc.title, doc.holder_name || '', doc.doc_number || '',
        doc.issue_date || '', doc.expiry_date || '', doc.notes || '',
        doc.attachment || null, doc.attachment_name || '', doc.attachment_type || '',
        id
      ]
    );
  },
  async remove(id) {
    return run('DELETE FROM personal_docs WHERE id = ?', [id]);
  },
  async count() {
    const r = await query('SELECT COUNT(*) as c FROM personal_docs');
    return r[0]?.c || 0;
  }
};

// ======================= كلمات المرور =======================

export const Passwords = {
  async add(p) {
    return run(
      `INSERT INTO passwords (title, username, password_enc, url, notes, created_at)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [p.title, p.username || '', p.password_enc, p.url || '', p.notes || '', Date.now()]
    );
  },
  async list() {
    return query('SELECT * FROM passwords ORDER BY created_at DESC');
  },
  async update(id, p) {
    return run(
      `UPDATE passwords SET title = ?, username = ?, password_enc = ?, url = ?, notes = ?
       WHERE id = ?`,
      [p.title, p.username || '', p.password_enc, p.url || '', p.notes || '', id]
    );
  },
  async remove(id) {
    return run('DELETE FROM passwords WHERE id = ?', [id]);
  },
  async count() {
    const r = await query('SELECT COUNT(*) as c FROM passwords');
    return r[0]?.c || 0;
  }
};

// ======================= الديون =======================

export const Debts = {
  async add(d) {
    return run(
      `INSERT INTO debts (person_name, direction, total_amount, currency, notes, status, created_at)
       VALUES (?, ?, ?, ?, ?, 'unpaid', ?)`,
      [d.person_name, d.direction, d.total_amount, d.currency || 'SAR', d.notes || '', Date.now()]
    );
  },
  async list() {
    return query('SELECT * FROM debts ORDER BY created_at DESC');
  },
  async byDirection(dir) {
    return query('SELECT * FROM debts WHERE direction = ? ORDER BY created_at DESC', [dir]);
  },
  async update(id, d) {
    return run(
      `UPDATE debts SET person_name = ?, direction = ?, total_amount = ?, currency = ?, notes = ?
       WHERE id = ?`,
      [d.person_name, d.direction, d.total_amount, d.currency || 'SAR', d.notes || '', id]
    );
  },
  async remove(id) {
    // ON DELETE CASCADE يعالج payment rows
    return run('DELETE FROM debts WHERE id = ?', [id]);
  },
  async payments(debtId) {
    return query('SELECT * FROM debt_payments WHERE debt_id = ? ORDER BY paid_at DESC', [debtId]);
  },
  async addPayment(debtId, amount, note = '') {
    return run(
      `INSERT INTO debt_payments (debt_id, amount, paid_at, note) VALUES (?, ?, ?, ?)`,
      [debtId, amount, Date.now(), note]
    );
  },
  async totalPaid(debtId) {
    const r = await query('SELECT COALESCE(SUM(amount),0) as s FROM debt_payments WHERE debt_id = ?', [debtId]);
    return r[0]?.s || 0;
  },
  async updateStatus(debtId) {
    const debtRows = await query('SELECT * FROM debts WHERE id = ?', [debtId]);
    if (!debtRows[0]) return null;
    const debt = debtRows[0];
    const paid = await Debts.totalPaid(debtId);
    let status = 'unpaid';
    if (paid <= 0) status = 'unpaid';
    else if (paid + 0.001 >= debt.total_amount) status = 'paid';
    else status = 'partial';
    await run('UPDATE debts SET status = ? WHERE id = ?', [status, debtId]);
    return status;
  },
  async count() {
    const r = await query('SELECT COUNT(*) as c FROM debts');
    return r[0]?.c || 0;
  },
  async sumOwedToMe() {
    const r = await query(`SELECT COALESCE(SUM(total_amount),0) as s FROM debts WHERE direction='owed_to_me' AND status != 'paid'`);
    return r[0]?.s || 0;
  },
  async sumIOwe() {
    const r = await query(`SELECT COALESCE(SUM(total_amount),0) as s FROM debts WHERE direction='i_owe' AND status != 'paid'`);
    return r[0]?.s || 0;
  }
};

// ======================= الملفات =======================

export const Files = {
  async add(f) {
    return run(
      `INSERT INTO files (name, mime_type, size, data, category, notes, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [f.name, f.mime_type || '', f.size || 0, f.data, f.category || '', f.notes || '', Date.now()]
    );
  },
  async list() {
    return query('SELECT id, name, mime_type, size, category, notes, created_at FROM files ORDER BY created_at DESC');
  },
  async getData(id) {
    const r = await query('SELECT data, name, mime_type FROM files WHERE id = ?', [id]);
    return r[0] || null;
  },
  async update(id, f) {
    return run(
      `UPDATE files SET name = ?, category = ?, notes = ? WHERE id = ?`,
      [f.name, f.category || '', f.notes || '', id]
    );
  },
  async remove(id) {
    return run('DELETE FROM files WHERE id = ?', [id]);
  },
  async count() {
    const r = await query('SELECT COUNT(*) as c FROM files');
    return r[0]?.c || 0;
  }
};

// ======================= الألبومات والصور =======================

export const Albums = {
  async add(name) {
    return run('INSERT INTO albums (name, created_at) VALUES (?, ?)', [name, Date.now()]);
  },
  async list() {
    return query('SELECT * FROM albums ORDER BY name ASC');
  },
  async remove(id) {
    return run('DELETE FROM albums WHERE id = ?', [id]);
  }
};

export const Images = {
  async add(img) {
    return run(
      `INSERT INTO images (album_id, name, mime_type, data, created_at)
       VALUES (?, ?, ?, ?, ?)`,
      [img.album_id || null, img.name || '', img.mime_type || '', img.data, Date.now()]
    );
  },
  async list(albumId = null) {
    if (albumId) {
      return query('SELECT * FROM images WHERE album_id = ? ORDER BY created_at DESC', [albumId]);
    }
    return query('SELECT * FROM images ORDER BY created_at DESC');
  },
  async remove(id) {
    return run('DELETE FROM images WHERE id = ?', [id]);
  },
  async count() {
    const r = await query('SELECT COUNT(*) as c FROM images');
    return r[0]?.c || 0;
  }
};

// ======================= المهام =======================

export const Tasks = {
  async add(t) {
    return run(
      `INSERT INTO tasks (title, description, due_date, reminder_at, priority, done, created_at)
       VALUES (?, ?, ?, ?, ?, 0, ?)`,
      [t.title, t.description || '', t.due_date || '', t.reminder_at || '', t.priority || 'normal', Date.now()]
    );
  },
  async list() {
    return query('SELECT * FROM tasks ORDER BY done ASC, due_date ASC, created_at DESC');
  },
  async update(id, t) {
    return run(
      `UPDATE tasks SET title = ?, description = ?, due_date = ?, reminder_at = ?, priority = ?
       WHERE id = ?`,
      [t.title, t.description || '', t.due_date || '', t.reminder_at || '', t.priority || 'normal', id]
    );
  },
  async toggleDone(id, done) {
    return run('UPDATE tasks SET done = ? WHERE id = ?', [done ? 1 : 0, id]);
  },
  async remove(id) {
    return run('DELETE FROM tasks WHERE id = ?', [id]);
  },
  async count() {
    const r = await query('SELECT COUNT(*) as c FROM tasks');
    return r[0]?.c || 0;
  },
  async pendingCount() {
    const r = await query('SELECT COUNT(*) as c FROM tasks WHERE done = 0');
    return r[0]?.c || 0;
  }
};

// ======================= ملخصات ChatGPT =======================

export const Summaries = {
  async add(s) {
    return run(
      `INSERT INTO summaries (title, content, tags, created_at) VALUES (?, ?, ?, ?)`,
      [s.title, s.content, s.tags || '', Date.now()]
    );
  },
  async list() {
    return query('SELECT * FROM summaries ORDER BY created_at DESC');
  },
  async update(id, s) {
    return run(
      `UPDATE summaries SET title = ?, content = ?, tags = ? WHERE id = ?`,
      [s.title, s.content, s.tags || '', id]
    );
  },
  async remove(id) {
    return run('DELETE FROM summaries WHERE id = ?', [id]);
  },
  async count() {
    const r = await query('SELECT COUNT(*) as c FROM summaries');
    return r[0]?.c || 0;
  }
};

// ======================= الروابط =======================

export const Links = {
  async add(l) {
    return run(
      `INSERT INTO links (name, url, category, notes, created_at) VALUES (?, ?, ?, ?, ?)`,
      [l.name, l.url, l.category || '', l.notes || '', Date.now()]
    );
  },
  async list() {
    return query('SELECT * FROM links ORDER BY created_at DESC');
  },
  async update(id, l) {
    return run(
      `UPDATE links SET name = ?, url = ?, category = ?, notes = ? WHERE id = ?`,
      [l.name, l.url, l.category || '', l.notes || '', id]
    );
  },
  async remove(id) {
    return run('DELETE FROM links WHERE id = ?', [id]);
  },
  async count() {
    const r = await query('SELECT COUNT(*) as c FROM links');
    return r[0]?.c || 0;
  }
};

// ======================= البحث الشامل =======================

export const GlobalSearch = {
  async search(term) {
    const q = `%${term}%`;
    const results = [];

    const p = await query(
      `SELECT id, title, category, notes, doc_number, holder_name FROM personal_docs
       WHERE title LIKE ? OR category LIKE ? OR notes LIKE ? OR doc_number LIKE ? OR holder_name LIKE ?
       LIMIT 20`,
      [q, q, q, q, q]
    );
    p.forEach((r) => results.push({
      section: 'personal', id: r.id, title: r.title,
      subtitle: r.category + (r.doc_number ? ' • ' + r.doc_number : '')
    }));

    const pw = await query(
      `SELECT id, title, username, url FROM passwords WHERE title LIKE ? OR username LIKE ? OR url LIKE ? LIMIT 20`,
      [q, q, q]
    );
    pw.forEach((r) => results.push({
      section: 'passwords', id: r.id, title: r.title,
      subtitle: r.username || ''
    }));

    const d = await query(
      `SELECT id, person_name, notes FROM debts WHERE person_name LIKE ? OR notes LIKE ? LIMIT 20`,
      [q, q]
    );
    d.forEach((r) => results.push({
      section: 'debts', id: r.id, title: r.person_name, subtitle: r.notes || ''
    }));

    const f = await query(
      `SELECT id, name, category FROM files WHERE name LIKE ? OR category LIKE ? OR notes LIKE ? LIMIT 20`,
      [q, q, q]
    );
    f.forEach((r) => results.push({
      section: 'files', id: r.id, title: r.name, subtitle: r.category || ''
    }));

    const s = await query(
      `SELECT id, title, content, tags FROM summaries WHERE title LIKE ? OR content LIKE ? OR tags LIKE ? LIMIT 20`,
      [q, q, q]
    );
    s.forEach((r) => results.push({
      section: 'library', id: r.id, title: r.title, subtitle: (r.content || '').slice(0, 80)
    }));

    const l = await query(
      `SELECT id, name, url FROM links WHERE name LIKE ? OR url LIKE ? LIMIT 20`,
      [q, q]
    );
    l.forEach((r) => results.push({
      section: 'links', id: r.id, title: r.name, subtitle: r.url
    }));

    const t = await query(
      `SELECT id, title, description FROM tasks WHERE title LIKE ? OR description LIKE ? LIMIT 20`,
      [q, q]
    );
    t.forEach((r) => results.push({
      section: 'planner', id: r.id, title: r.title, subtitle: r.description || ''
    }));

    return results;
  }
};

// ======================= إحصائيات =======================

export const Stats = {
  async all() {
    return {
      personal: await PersonalDocs.count(),
      passwords: await Passwords.count(),
      debts: await Debts.count(),
      files: await Files.count(),
      images: await Images.count(),
      tasks: await Tasks.count(),
      pendingTasks: await Tasks.pendingCount(),
      summaries: await Summaries.count(),
      links: await Links.count(),
      sumOwedToMe: await Debts.sumOwedToMe(),
      sumIOwe: await Debts.sumIOwe()
    };
  }
};

// ======================= النسخ الاحتياطي (تصدير/استيراد البيانات) =======================

export const Backup = {
  async exportAll() {
    const data = {
      version: DB_VERSION,
      exportedAt: Date.now(),
      meta: await query('SELECT * FROM meta'),
      personal_docs: await query('SELECT * FROM personal_docs'),
      passwords: await query('SELECT * FROM passwords'),
      debts: await query('SELECT * FROM debts'),
      debt_payments: await query('SELECT * FROM debt_payments'),
      files: await query('SELECT * FROM files'),
      albums: await query('SELECT * FROM albums'),
      images: await query('SELECT * FROM images'),
      tasks: await query('SELECT * FROM tasks'),
      summaries: await query('SELECT * FROM summaries'),
      links: await query('SELECT * FROM links')
    };
    return data;
  },
  async importAll(data) {
    // Wipe then insert (note: only valid when DB is already opened with matching master password)
    await db.execute(`
      DELETE FROM debt_payments;
      DELETE FROM debts;
      DELETE FROM personal_docs;
      DELETE FROM passwords;
      DELETE FROM files;
      DELETE FROM albums;
      DELETE FROM images;
      DELETE FROM tasks;
      DELETE FROM summaries;
      DELETE FROM links;
      DELETE FROM meta;
    `);
    const insertMeta = async (m) => run('INSERT INTO meta (key, value) VALUES (?, ?)', [m.key, m.value]);
    for (const m of data.meta || []) await insertMeta(m);

    const insert = async (table, cols, rows) => {
      for (const row of rows || []) {
        const vals = cols.map((c) => row[c] ?? null);
        const ph = cols.map(() => '?').join(',');
        await run(`INSERT INTO ${table} (${cols.join(',')}) VALUES (${ph})`, vals);
      }
    };

    await insert('personal_docs', ['id','category','title','holder_name','doc_number','issue_date','expiry_date','notes','attachment','attachment_name','attachment_type','created_at'], data.personal_docs);
    await insert('passwords', ['id','title','username','password_enc','url','notes','created_at'], data.passwords);
    await insert('debts', ['id','person_name','direction','total_amount','currency','notes','status','created_at'], data.debts);
    await insert('debt_payments', ['id','debt_id','amount','paid_at','note'], data.debt_payments);
    await insert('files', ['id','name','mime_type','size','data','category','notes','created_at'], data.files);
    await insert('albums', ['id','name','created_at'], data.albums);
    await insert('images', ['id','album_id','name','mime_type','data','created_at'], data.images);
    await insert('tasks', ['id','title','description','due_date','reminder_at','priority','done','created_at'], data.tasks);
    await insert('summaries', ['id','title','content','tags','created_at'], data.summaries);
    await insert('links', ['id','name','url','category','notes','created_at'], data.links);

    await saveToStore();
  }
};