/* ============================================
   AMMAR VAULT – js/security.js
   نظام التشفير: PBKDF2 + AES-GCM
   ============================================ */

const _enc = new TextEncoder();
const _dec = new TextDecoder();

export function randomBytes(n) {
  const arr = new Uint8Array(n);
  crypto.getRandomValues(arr);
  return arr;
}

export function toBase64(u8) {
  let s = '';
  const chunk = 0x8000;
  for (let i = 0; i < u8.length; i += chunk) {
    s += String.fromCharCode.apply(null, u8.subarray(i, i + chunk));
  }
  return btoa(s);
}

export function fromBase64(str) {
  const bin = atob(str);
  const u8 = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
  return u8;
}

/**
 * اشتقاق مفتاح من كلمة مرور باستخدام PBKDF2-SHA256.
 * @param {string} password
 * @param {string|Uint8Array} saltInput - base64 string أو bytes
 * @param {number} iterations
 * @returns {Promise<CryptoKey>}
 */
export async function deriveKey(password, saltInput, iterations = 200000) {
  const salt = typeof saltInput === 'string' ? fromBase64(saltInput) : saltInput;
  const keyMaterial = await crypto.subtle.importKey(
    'raw',
    _enc.encode(password),
    'PBKDF2',
    false,
    ['deriveKey']
  );
  return crypto.subtle.deriveKey(
    { name: 'PBKDF2', salt, iterations, hash: 'SHA-256' },
    keyMaterial,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}

/**
 * تشفير نص باستخدام AES-GCM.
 * الناتج: base64 يحتوي [12 bytes IV][cipher]
 */
export async function encryptText(plaintext, key) {
  const iv = randomBytes(12);
  const cipher = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv },
    key,
    _enc.encode(plaintext)
  );
  const combined = new Uint8Array(iv.length + cipher.byteLength);
  combined.set(iv, 0);
  combined.set(new Uint8Array(cipher), iv.length);
  return toBase64(combined);
}

/**
 * فك تشفير نص.
 */
export async function decryptText(b64, key) {
  const combined = fromBase64(b64);
  const iv = combined.slice(0, 12);
  const data = combined.slice(12);
  const plain = await crypto.subtle.decrypt(
    { name: 'AES-GCM', iv },
    key,
    data
  );
  return _dec.decode(plain);
}

/**
 * إنشاء بيانات تحقق من كلمة المرور (salt + verify blob).
 */
export async function hashPassword(password) {
  const salt = randomBytes(16);
  const saltB64 = toBase64(salt);
  const key = await deriveKey(password, salt);
  const verify = await encryptText('AMMAR_VAULT_VERIFY', key);
  return { salt: saltB64, verify };
}

/**
 * التحقق من كلمة المرور.
 */
export async function verifyPassword(password, saltB64, expectedVerify) {
  try {
    const salt = fromBase64(saltB64);
    const key = await deriveKey(password, salt);
    const result = await decryptText(expectedVerify, key);
    return result === 'AMMAR_VAULT_VERIFY';
  } catch (e) {
    return false;
  }
}

/**
 * تشفير بيانات ثنائية (BLOB) وإرجاعها base64.
 */
export async function encryptBytes(u8, key) {
  const iv = randomBytes(12);
  const cipher = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv },
    key,
    u8
  );
  const combined = new Uint8Array(iv.length + cipher.byteLength);
  combined.set(iv, 0);
  combined.set(new Uint8Array(cipher), iv.length);
  return toBase64(combined);
}

/**
 * فك تشفير بيانات ثنائية.
 */
export async function decryptBytes(b64, key) {
  const combined = fromBase64(b64);
  const iv = combined.slice(0, 12);
  const data = combined.slice(12);
  const plainBuf = await crypto.subtle.decrypt(
    { name: 'AES-GCM', iv },
    key,
    data
  );
  return new Uint8Array(plainBuf);
}