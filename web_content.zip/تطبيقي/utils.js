/* ============================================
   AMMAR VAULT – js/utils.js
   أدوات مساعدة عامة
   ============================================ */

export function showToast(message, type = 'info', duration = 2500) {
  const t = document.getElementById('toast');
  if (!t) return;
  t.textContent = message;
  t.className = 'toast ' + type;
  t.classList.remove('hidden');
  clearTimeout(t._timer);
  t._timer = setTimeout(() => t.classList.add('hidden'), duration);
}

export function openModal(html) {
  const m = document.getElementById('modal');
  const body = document.getElementById('modal-body');
  if (!m || !body) return;
  body.innerHTML = html;
  m.classList.remove('hidden');
}

export function closeModal() {
  const m = document.getElementById('modal');
  if (m) m.classList.add('hidden');
}

export function escapeHtml(str) {
  if (str === null || str === undefined) return '';
  return String(str).replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}

export function formatDate(ts) {
  if (!ts) return '';
  try {
    return new Date(ts).toLocaleDateString('ar-EG');
  } catch { return ''; }
}

export function formatDateTime(ts) {
  if (!ts) return '';
  try {
    return new Date(ts).toLocaleString('ar-EG');
  } catch { return ''; }
}

export function formatBytes(bytes) {
  if (!bytes || bytes < 1) return '0 B';
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return (bytes / Math.pow(1024, i)).toFixed(1) + ' ' + sizes[i];
}

export function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => {
      const res = r.result;
      const idx = res.indexOf(',');
      resolve(res.slice(idx + 1));
    };
    r.onerror = reject;
    r.readAsDataURL(blob);
  });
}

export function base64ToBlob(base64, mime = 'application/octet-stream') {
  const bin = atob(base64);
  const u8 = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
  return new Blob([u8], { type: mime });
}

export function base64ToDataUrl(base64, mime = 'image/jpeg') {
  return `data:${mime};base64,${base64}`;
}

export function copyToClipboard(text) {
  if (navigator.clipboard && navigator.clipboard.writeText) {
    return navigator.clipboard.writeText(text).then(() => true).catch(() => false);
  }
  // fallback
  try {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
    return Promise.resolve(true);
  } catch (e) {
    return Promise.resolve(false);
  }
}

export function getFileIcon(mime, name = '') {
  if (!mime) mime = '';
  const ext = (name.split('.').pop() || '').toLowerCase();
  if (mime.includes('pdf') || ext === 'pdf') return '📕';
  if (mime.includes('word') || ['doc', 'docx'].includes(ext)) return '📘';
  if (mime.includes('excel') || mime.includes('spreadsheet') || ['xls', 'xlsx', 'csv'].includes(ext)) return '📗';
  if (mime.includes('powerpoint') || ['ppt', 'pptx'].includes(ext)) return '📙';
  if (mime.startsWith('image/')) return '🖼️';
  if (mime.startsWith('video/')) return '🎬';
  if (mime.startsWith('audio/')) return '🎵';
  if (mime.includes('zip') || ['zip', 'rar', '7z'].includes(ext)) return '🗜️';
  if (mime.includes('text') || ['txt', 'md'].includes(ext)) return '📄';
  return '📎';
}

export function debounce(fn, delay = 300) {
  let timer;
  return function (...args) {
    clearTimeout(timer);
    timer = setTimeout(() => fn.apply(this, args), delay);
  };
}

export function todayISO() {
  return new Date().toISOString().slice(0, 10);
}