/* ============================================
   AMMAR VAULT – app.js – الجزء 1 من 3
   نقطة الدخول، شاشة القفل، التنقل، لوحة التحكم، الإعدادات
   ============================================ */

import {
  initDatabase, closeDatabase, saveToStore, Meta,
  PersonalDocs, Passwords, Debts, Files, Albums, Images,
  Tasks, Summaries, Links, GlobalSearch, Stats, Backup
} from './js/database.js';

import {
  randomBytes, toBase64, fromBase64,
  deriveKey, encryptText, decryptText, hashPassword, verifyPassword,
  encryptBytes, decryptBytes
} from './js/security.js';

import {
  showToast, openModal, closeModal, escapeHtml,
  formatDate, formatDateTime, formatBytes,
  blobToBase64, base64ToBlob, base64ToDataUrl,
  copyToClipboard, getFileIcon, debounce, todayISO
} from './js/utils.js';

// ======================= الحالة العامة =======================
const state = {
  masterKey: null,      // CryptoKey لـ AES-GCM
  currentSection: 'dashboard',
  activeDebtFilter: 'all',
  activePlannerView: 'day',
  activeAlbumId: null,
  dbReady: false,
  biometricAvailable: false
};

// مراجع سريعة لعناصر DOM
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

// ======================= التشغيل الأولي =======================
document.addEventListener('DOMContentLoaded', async () => {
  _bindLockScreen();
  _bindNavigation();
  _bindHeader();
  _bindGlobalSearch();
  _bindModalClose();
  await _checkFirstRun();
});

async function _checkFirstRun() {
  // هل قاعدة البيانات موجودة مسبقاً؟ لا نفتحها بعد، فقط نعرف إن كانت كلمة المرور موجودة.
  // في هذه الحالة لا نستطيع قراءة meta قبل فتح DB.
  // لذلك: نستخدم flag بسيط في IndexedDB؟ لا.
  // الحل: نحاول فتح DB بمفتاح فارغ لمعرفة إن كان هناك جدول meta.
  // لكن SQLCipher يفشل إذا كانت البيانات مشفرة بمفتاح آخر. لا يمكننا معرفة ذلك بدون محاولة.
  // الحل العملي: تخزين علامة بسيطة خارج DB عبر Capacitor Preferences أو ملف بسيط.
  // نستخدم Capacitor Preferences (آمن للتخزين غير الحساس - مجرد flag).
  try {
    const { Preferences } = await import('@capacitor/preferences');
    const { value } = await Preferences.get({ key: 'ammar_initialized' });
    if (value === '1') {
      $('#lock-hint')?.classList.add('hidden');
    }
  } catch (_) {
    // في حال عدم توفر Preferences (ويب) نعتمد على عدم وجود hint فقط.
  }
}

// ======================= شاشة القفل =======================
function _bindLockScreen() {
  const unlockBtn = $('#unlock-btn');
  const input = $('#master-password-input');
  const err = $('#lock-error');
  const bioBtn = $('#biometric-unlock-btn');

  unlockBtn?.addEventListener('click', async () => {
    const pw = input.value.trim();
    if (pw.length < 6) {
      err.textContent = 'كلمة المرور قصيرة جداً (6 أحرف على الأقل).';
      return;
    }
    err.textContent = 'جارٍ التحقق...';
    unlockBtn.disabled = true;
    try {
      await _tryUnlockOrSetup(pw);
    } catch (e) {
      console.error(e);
      err.textContent = 'فشل: ' + (e.message || 'خطأ غير معروف');
    } finally {
      unlockBtn.disabled = false;
    }
  });

  input?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') unlockBtn.click();
  });

  // بصمة (لاحقاً في الجزء 3 سيُربط بمنطق حقيقي)
  bioBtn?.addEventListener('click', async () => {
    showToast('المصادقة بالبصمة ستتوفر بعد تفعيلها من الإعدادات', 'info');
  });
}

async function _tryUnlockOrSetup(password) {
  // نحاول فتح DB. إذا نجح الفتح وكانت meta فارغة => إعداد أول مرة.
  await initDatabase(password);
  state.dbReady = true;

  const hasMaster = await Meta.hasMaster();
  if (!hasMaster) {
    // إعداد أول مرة: نُنشئ salt وverify
    const { salt, verify } = await hashPassword(password);
    await Meta.set('master_salt', salt);
    await Meta.set('master_verify', verify);
    await Meta.set('created_at', String(Date.now()));
    // اشتقاق مفتاح التشفير من كلمة المرور + salt
    state.masterKey = await deriveKey(password, salt);
    await saveToStore();

    // احفظ flag للإقلاع التالي
    try {
      const { Preferences } = await import('@capacitor/preferences');
      await Preferences.set({ key: 'ammar_initialized', value: '1' });
    } catch (_) {}

    showToast('تم إنشاء الخزنة بنجاح 🔐', 'success');
    _enterApp();
    return;
  }

  // مستخدم عائد: نتحقق من كلمة المرور
  const salt = await Meta.get('master_salt');
  const verify = await Meta.get('master_verify');
  const ok = await verifyPassword(password, salt, verify);
  if (!ok) {
    // كلمة مرور خاطئة: يجب إغلاق DB (لأن SQLCipher فتحها! هذا يعني أن DB غير مشفرة فعلياً بعد)
    await closeDatabase();
    state.dbReady = false;
    throw new Error('كلمة المرور غير صحيحة.');
  }
  state.masterKey = await deriveKey(password, salt);
  _enterApp();
}

function _enterApp() {
  $('#lock-screen')?.classList.add('hidden');
  $('#app')?.classList.remove('hidden');
  _renderDashboard();
  _renderSection('dashboard');
}

function _lockApp() {
  // مسح المفتاح من الذاكرة والقفل
  state.masterKey = null;
  closeDatabase().catch(() => {});
  state.dbReady = false;
  $('#app')?.classList.add('hidden');
  $('#lock-screen')?.classList.remove('hidden');
  const input = $('#master-password-input');
  if (input) input.value = '';
  const err = $('#lock-error');
  if (err) err.textContent = '';
}

// ======================= الهيدر والتنقل =======================
function _bindHeader() {
  $('#menu-toggle')?.addEventListener('click', () => {
    $('#sidebar')?.classList.toggle('open');
    $('#sidebar-overlay')?.classList.toggle('hidden');
  });
  $('#sidebar-overlay')?.addEventListener('click', () => {
    $('#sidebar')?.classList.remove('open');
    $('#sidebar-overlay')?.classList.add('hidden');
  });
  $('#lock-now-btn')?.addEventListener('click', _lockApp);
}

function _bindNavigation() {
  $$('.nav-link').forEach((link) => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const section = link.getAttribute('data-section');
      if (!section) return;
      _renderSection(section);
      // إغلاق الشريط الجانبي على الهاتف
      if (window.innerWidth < 768) {
        $('#sidebar')?.classList.remove('open');
        $('#sidebar-overlay')?.classList.add('hidden');
      }
      // تمييز الرابط النشط
      $$('.nav-link').forEach((l) => l.classList.remove('active'));
      link.classList.add('active');
    });
  });
}

function _renderSection(sectionName) {
  state.currentSection = sectionName;
  const main = $('#main-content');
  if (!main) return;
  const tpl = document.getElementById('tpl-' + sectionName);
  if (!tpl) {
    main.innerHTML = `<section class="section"><h2 class="section-title">قسم غير معروف: ${escapeHtml(sectionName)}</h2></section>`;
    return;
  }
  main.innerHTML = '';
  main.appendChild(tpl.content.cloneNode(true));

  // استدعاء الدالة الخاصة بالقسم
  const renderers = {
    dashboard: _renderDashboard,
    personal: _renderPersonalSection,
    passwords: _renderPasswordsSection,
    debts: _renderDebtsSection,
    files: _renderFilesSection,
    gallery: _renderGallerySection,
    planner: _renderPlannerSection,
    library: _renderLibrarySection,
    links: _renderLinksSection,
    stats: _renderStatsSection,
    backup: _renderBackupSection,
    settings: _renderSettingsSection
  };
  const fn = renderers[sectionName];
  if (fn) fn();
}

// ======================= لوحة التحكم =======================
async function _renderDashboard() {
  const grid = $('#dashboard-cards');
  if (!grid) return;
  try {
    const s = await Stats.all();
    grid.innerHTML = `
      ${_dashCard(s.personal, 'الوثائق الشخصية')}
      ${_dashCard(s.passwords, 'كلمات المرور')}
      ${_dashCard(s.debts, 'الديون')}
      ${_dashCard(s.files, 'الملفات')}
      ${_dashCard(s.images, 'الصور')}
      ${_dashCard(s.pendingTasks + ' / ' + s.tasks, 'المهام (معلقة/الكل)')}
      ${_dashCard(s.summaries, 'الملخصات')}
      ${_dashCard(s.links, 'الروابط')}
      ${_dashCard(s.sumOwedToMe.toFixed(2), 'لي عند الناس')}
      ${_dashCard(s.sumIOwe.toFixed(2), 'علي للناس')}
    `;
  } catch (e) {
    console.error(e);
    grid.innerHTML = `<div class="alert error">تعذّر تحميل الإحصائيات.</div>`;
  }
}

function _dashCard(num, label) {
  return `
    <div class="dash-card">
      <div class="num">${escapeHtml(String(num))}</div>
      <div class="label">${escapeHtml(label)}</div>
    </div>`;
}

// ======================= الإعدادات =======================
function _renderSettingsSection() {
  const changeBtn = $('#change-password-btn');
  const bioToggle = $('#biometric-toggle');
  const notifToggle = $('#notifications-toggle');

  changeBtn?.addEventListener('click', async () => {
    const val = $('#new-master-password')?.value.trim();
    if (!val || val.length < 6) {
      showToast('كلمة المرور الجديدة قصيرة جداً.', 'error');
      return;
    }
    if (!confirm('تغيير كلمة المرور الرئيسية سيعيد تشفير كل شيء. هل تريد المتابعة؟ (قد تحتاج لإعادة فتح التطبيق)')) return;
    try {
      const { salt, verify } = await hashPassword(val);
      await Meta.set('master_salt', salt);
      await Meta.set('master_verify', verify);
      state.masterKey = await deriveKey(val, salt);
      await saveToStore();
      showToast('تم تحديث كلمة المرور. قد تحتاج لإعادة فتح التطبيق لإعادة تشفير القاعدة.', 'success', 4000);
    } catch (e) {
      console.error(e);
      showToast('فشل تحديث كلمة المرور.', 'error');
    }
  });

  // إظهار خيار البصمة إن كان الجهاز يدعمه (لاحقاً)
  bioToggle?.addEventListener('change', () => {
    showToast('خاصية البصمة سيتم ربطها في التحديث القادم.', 'info');
  });

  notifToggle?.addEventListener('change', () => {
    showToast('تم تحديث تفضيلات الإشعارات (محلياً).', 'success');
  });
}

// ======================= نوافذ منبثقة =======================
function _bindModalClose() {
  $('#modal-close')?.addEventListener('click', closeModal);
  $('#modal')?.addEventListener('click', (e) => {
    if (e.target.id === 'modal') closeModal();
  });
}

// ======================= البحث الشامل =======================
function _bindGlobalSearch() {
  const btn = $('#global-search-btn');
  const panel = $('#global-search-panel');
  const input = $('#global-search-input');
  const results = $('#global-search-results');

  btn?.addEventListener('click', () => {
    panel?.classList.toggle('hidden');
    if (!panel?.classList.contains('hidden')) input?.focus();
  });

  const doSearch = debounce(async () => {
    const q = (input?.value || '').trim();
    if (q.length < 2) {
      results.innerHTML = '';
      return;
    }
    try {
      const rows = await GlobalSearch.search(q);
      if (!rows.length) {
        results.innerHTML = `<p class="small-text">لا نتائج.</p>`;
        return;
      }
      results.innerHTML = rows.map((r) => `
        <div class="result-item" data-section="${r.section}" data-id="${r.id}">
          <strong>${escapeHtml(r.title)}</strong>
          <div class="small-text">${escapeHtml(r.subtitle || '')} — قسم: ${_sectionLabel(r.section)}</div>
        </div>
      `).join('');
      results.querySelectorAll('.result-item').forEach((el) => {
        el.addEventListener('click', () => {
          const section = el.getAttribute('data-section');
          _renderSection(section);
          panel.classList.add('hidden');
        });
      });
    } catch (e) {
      console.error(e);
    }
  }, 350);

  input?.addEventListener('input', doSearch);
}

function _sectionLabel(s) {
  const map = {
    personal: 'البيانات الشخصية',
    passwords: 'كلمات المرور',
    debts: 'الديون',
    files: 'الملفات',
    gallery: 'الصور',
    planner: 'المهام',
    library: 'الملخصات',
    links: 'الروابط',
    stats: 'الإحصائيات',
    backup: 'النسخ الاحتياطي',
    settings: 'الإعدادات'
  };
  return map[s] || s;
}

// ======================= تصدير للنطاق (لكي تستخدمه الأجزاء التالية) =======================
window.__AV = {
  state, showToast, openModal, closeModal, escapeHtml,
  formatDate, formatDateTime, formatBytes,
  copyToClipboard, getFileIcon, todayISO,
  encryptText, decryptText, deriveKey, encryptBytes, decryptBytes,
  base64ToBlob, base64ToDataUrl, blobToBase64, toBase64, fromBase64,
  renderSection: _renderSection,
  saveToStore,
  PersonalDocs, Passwords, Debts, Files, Albums, Images,
  Tasks, Summaries, Links, Stats, Backup, GlobalSearch,
  renderDashboard: _renderDashboard
};

// دوال الأقسام القادمة ستُعرَّف في الجزء 2 و 3
// (placeholder — سيتم استبدالها عبر الوحدة نفسها في الأجزاء التالية)
function _renderPersonalSection() {}
function _renderPasswordsSection() {}
function _renderDebtsSection() {}
function _renderFilesSection() {}
function _renderGallerySection() {}
function _renderPlannerSection() {}
function _renderLibrarySection() {}
function _renderLinksSection() {}
function _renderStatsSection() {}
function _renderBackupSection() {}
function _renderPersonalSection() {}
function _renderPasswordsSection() {}
function _renderDebtsSection() {}
function _renderFilesSection() {}
function _renderGallerySection() {}
function _renderPlannerSection() {}
function _renderLibrarySection() {}
function _renderLinksSection() {}
function _renderStatsSection() {}
function _renderBackupSection() {}
/* ============================================
   AMMAR VAULT – app.js – الجزء 2 من 3
   تنفيذ كامل: البيانات الشخصية، كلمات المرور، الديون، الملفات
   ============================================ */

// ==================================================================
// ==================== 1) البيانات الشخصية =========================
// ==================================================================

async function _renderPersonalSection() {
  const addBtn = $('#add-personal-btn');
  addBtn?.addEventListener('click', () => _personalFormModal());
  await _refreshPersonalList();
}

async function _refreshPersonalList() {
  const list = $('#personal-list');
  if (!list) return;
  try {
    const docs = await PersonalDocs.list();
    if (!docs.length) {
      list.innerHTML = `<p class="small-text">لا توجد وثائق شخصية بعد. اضغط "إضافة وثيقة شخصية" للبدء.</p>`;
      return;
    }
    const catLabels = {
      personal_id: '🆔 بطاقة شخصية',
      passport: '🛂 جواز سفر',
      certificate: '🎓 شهادة',
      document: '📄 وثيقة',
      other: '📎 أخرى'
    };
    list.innerHTML = docs.map((d) => `
      <div class="card" data-id="${d.id}">
        <h3>${escapeHtml(d.title)}</h3>
        <p><strong>التصنيف:</strong> ${catLabels[d.category] || escapeHtml(d.category)}</p>
        ${d.holder_name ? `<p><strong>الاسم:</strong> ${escapeHtml(d.holder_name)}</p>` : ''}
        ${d.doc_number ? `<p><strong>الرقم:</strong> ${escapeHtml(d.doc_number)}</p>` : ''}
        ${d.issue_date ? `<p><strong>تاريخ الإصدار:</strong> ${escapeHtml(d.issue_date)}</p>` : ''}
        ${d.expiry_date ? `<p><strong>تاريخ الانتهاء:</strong> ${escapeHtml(d.expiry_date)}</p>` : ''}
        ${d.notes ? `<p><strong>ملاحظات:</strong> ${escapeHtml(d.notes)}</p>` : ''}
        ${d.attachment ? `<p class="small-text">📎 مرفق: ${escapeHtml(d.attachment_name || 'ملف')}</p>` : ''}
        <div class="card-actions">
          ${d.attachment ? `<button data-action="view-attachment" class="gold">👁️ عرض المرفق</button>` : ''}
          <button data-action="edit">✏️ تعديل</button>
          <button data-action="delete" class="danger">🗑️ حذف</button>
        </div>
      </div>
    `).join('');
    _bindPersonalCardActions(docs);
  } catch (e) {
    list.innerHTML = `<div class="alert error">${escapeHtml(e.message)}</div>`;
  }
}

function _bindPersonalCardActions(docs) {
  $$('#personal-list .card').forEach((card) => {
    const id = Number(card.getAttribute('data-id'));
    const doc = docs.find((x) => x.id === id);
    if (!doc) return;

    card.querySelector('[data-action="edit"]')?.addEventListener('click', () => _personalFormModal(id));

    card.querySelector('[data-action="delete"]')?.addEventListener('click', async () => {
      if (!confirm('حذف هذه الوثيقة نهائياً؟')) return;
      try {
        await PersonalDocs.remove(id);
        await _refreshPersonalList();
        showToast('تم الحذف', 'success');
      } catch (e) {
        showToast('فشل الحذف: ' + e.message, 'error');
      }
    });

    card.querySelector('[data-action="view-attachment"]')?.addEventListener('click', async () => {
      try {
        const bytes = await decryptBytes(doc.attachment, state.masterKey);
        const blob = new Blob([bytes], { type: doc.attachment_type || 'application/octet-stream' });
        const url = URL.createObjectURL(blob);
        window.open(url, '_blank');
        setTimeout(() => URL.revokeObjectURL(url), 30000);
      } catch (e) {
        showToast('فشل فك تشفير المرفق: ' + e.message, 'error');
      }
    });
  });
}

function _personalFormModal(id = null) {
  const editing = id != null;
  openModal(`
    <h3>${editing ? 'تعديل' : 'إضافة'} وثيقة شخصية</h3>
    <div class="field-group">
      <label>التصنيف</label>
      <select id="pf-category">
        <option value="personal_id">🆔 بطاقة شخصية</option>
        <option value="passport">🛂 جواز سفر</option>
        <option value="certificate">🎓 شهادة</option>
        <option value="document">📄 وثيقة</option>
        <option value="other">📎 أخرى</option>
      </select>
    </div>
    <div class="field-group"><label>العنوان *</label><input type="text" id="pf-title" /></div>
    <div class="field-group"><label>اسم صاحب الوثيقة</label><input type="text" id="pf-holder" /></div>
    <div class="field-group"><label>رقم الوثيقة</label><input type="text" id="pf-number" /></div>
    <div class="field-group"><label>تاريخ الإصدار</label><input type="date" id="pf-issue" /></div>
    <div class="field-group"><label>تاريخ الانتهاء</label><input type="date" id="pf-expiry" /></div>
    <div class="field-group"><label>ملاحظات</label><textarea id="pf-notes"></textarea></div>
    <div class="field-group"><label>مرفق (اختياري — صورة أو PDF)</label><input type="file" id="pf-file" /></div>
    <button class="btn-gold" id="pf-save" style="width:100%">حفظ</button>
  `);

  if (editing) {
    (async () => {
      const docs = await PersonalDocs.list();
      const d = docs.find((x) => x.id === id);
      if (!d) return;
      $('#pf-category').value = d.category || 'other';
      $('#pf-title').value = d.title || '';
      $('#pf-holder').value = d.holder_name || '';
      $('#pf-number').value = d.doc_number || '';
      $('#pf-issue').value = d.issue_date || '';
      $('#pf-expiry').value = d.expiry_date || '';
      $('#pf-notes').value = d.notes || '';
    })();
  }

  $('#pf-save').addEventListener('click', async () => {
    const title = $('#pf-title').value.trim();
    if (!title) {
      showToast('العنوان مطلوب', 'error');
      return;
    }
    const data = {
      category: $('#pf-category').value,
      title,
      holder_name: $('#pf-holder').value.trim(),
      doc_number: $('#pf-number').value.trim(),
      issue_date: $('#pf-issue').value,
      expiry_date: $('#pf-expiry').value,
      notes: $('#pf-notes').value.trim()
    };
    try {
      const fileInput = $('#pf-file');
      if (fileInput && fileInput.files && fileInput.files[0]) {
        const file = fileInput.files[0];
        const buf = await file.arrayBuffer();
        data.attachment = await encryptBytes(new Uint8Array(buf), state.masterKey);
        data.attachment_name = file.name;
        data.attachment_type = file.type || 'application/octet-stream';
      } else if (editing) {
        const docs = await PersonalDocs.list();
        const existing = docs.find((x) => x.id === id);
        data.attachment = existing?.attachment || null;
        data.attachment_name = existing?.attachment_name || '';
        data.attachment_type = existing?.attachment_type || '';
      }
      if (editing) {
        await PersonalDocs.update(id, data);
      } else {
        await PersonalDocs.add(data);
      }
      closeModal();
      await _refreshPersonalList();
      showToast('تم الحفظ بنجاح', 'success');
    } catch (e) {
      showToast('فشل الحفظ: ' + e.message, 'error');
    }
  });
}

// ==================================================================
// ==================== 2) كلمات المرور =============================
// ==================================================================

async function _renderPasswordsSection() {
  const addBtn = $('#add-password-btn');
  addBtn?.addEventListener('click', () => _passwordFormModal());
  await _refreshPasswordsList();
}

async function _refreshPasswordsList() {
  const list = $('#password-list');
  if (!list) return;
  try {
    const items = await Passwords.list();
    if (!items.length) {
      list.innerHTML = `<p class="small-text">لا كلمات مرور محفوظة بعد.</p>`;
      return;
    }
    list.innerHTML = items.map((p) => `
      <div class="card" data-id="${p.id}">
        <h3>${escapeHtml(p.title)}</h3>
        ${p.username ? `<p><strong>اسم المستخدم:</strong> ${escapeHtml(p.username)}</p>` : ''}
        <p><strong>كلمة المرور:</strong> <span class="password-display pw-display" data-pid="${p.id}">••••••••</span></p>
        ${p.url ? `<p><strong>الرابط:</strong> ${escapeHtml(p.url)}</p>` : ''}
        ${p.notes ? `<p><strong>ملاحظات:</strong> ${escapeHtml(p.notes)}</p>` : ''}
        <div class="card-actions">
          <button data-action="toggle-pw" class="gold">👁️ عرض</button>
          <button data-action="copy-pw">📋 نسخ كلمة المرور</button>
          ${p.username ? `<button data-action="copy-user">👤 نسخ المستخدم</button>` : ''}
          <button data-action="edit">✏️ تعديل</button>
          <button data-action="delete" class="danger">🗑️ حذف</button>
        </div>
      </div>
    `).join('');
    _bindPasswordCardActions(items);
  } catch (e) {
    list.innerHTML = `<div class="alert error">${escapeHtml(e.message)}</div>`;
  }
}

function _bindPasswordCardActions(items) {
  $$('#password-list .card').forEach((card) => {
    const id = Number(card.getAttribute('data-id'));
    const p = items.find((x) => x.id === id);
    if (!p) return;
    const display = card.querySelector('.pw-display');
    const toggleBtn = card.querySelector('[data-action="toggle-pw"]');
    let visible = false;

    toggleBtn?.addEventListener('click', async () => {
      if (!visible) {
        try {
          const pw = await decryptText(p.password_enc, state.masterKey);
          if (display) display.textContent = pw;
          toggleBtn.textContent = '🙈 إخفاء';
          visible = true;
        } catch (e) {
          showToast('فشل فك التشفير', 'error');
        }
      } else {
        if (display) display.textContent = '••••••••';
        toggleBtn.textContent = '👁️ عرض';
        visible = false;
      }
    });

    card.querySelector('[data-action="copy-pw"]')?.addEventListener('click', async () => {
      try {
        const pw = await decryptText(p.password_enc, state.masterKey);
        const ok = await copyToClipboard(pw);
        showToast(ok ? 'تم نسخ كلمة المرور' : 'فشل النسخ', ok ? 'success' : 'error');
      } catch (e) {
        showToast('فشل فك التشفير', 'error');
      }
    });

    card.querySelector('[data-action="copy-user"]')?.addEventListener('click', async () => {
      const ok = await copyToClipboard(p.username || '');
      showToast(ok ? 'تم نسخ اسم المستخدم' : 'فشل النسخ', ok ? 'success' : 'error');
    });

    card.querySelector('[data-action="edit"]')?.addEventListener('click', () => _passwordFormModal(id));

    card.querySelector('[data-action="delete"]')?.addEventListener('click', async () => {
      if (!confirm('حذف كلمة المرور نهائياً؟')) return;
      try {
        await Passwords.remove(id);
        await _refreshPasswordsList();
        showToast('تم الحذف', 'success');
      } catch (e) {
        showToast('فشل الحذف: ' + e.message, 'error');
      }
    });
  });
}

function _passwordFormModal(id = null) {
  const editing = id != null;
  openModal(`
    <h3>${editing ? 'تعديل' : 'إضافة'} كلمة مرور</h3>
    <div class="field-group"><label>العنوان *</label><input type="text" id="pw-title" /></div>
    <div class="field-group"><label>اسم المستخدم</label><input type="text" id="pw-username" /></div>
    <div class="field-group"><label>كلمة المرور *</label><input type="text" id="pw-password" /></div>
    <div class="field-group"><label>الرابط (URL)</label><input type="text" id="pw-url" /></div>
    <div class="field-group"><label>ملاحظات</label><textarea id="pw-notes"></textarea></div>
    <button class="btn-gold" id="pw-save" style="width:100%">حفظ</button>
  `);

  if (editing) {
    (async () => {
      const items = await Passwords.list();
      const p = items.find((x) => x.id === id);
      if (!p) return;
      $('#pw-title').value = p.title || '';
      $('#pw-username').value = p.username || '';
      $('#pw-url').value = p.url || '';
      $('#pw-notes').value = p.notes || '';
      try {
        $('#pw-password').value = await decryptText(p.password_enc, state.masterKey);
      } catch (e) {
        showToast('فشل فك تشفير كلمة المرور القديمة', 'error');
      }
    })();
  }

  $('#pw-save').addEventListener('click', async () => {
    const title = $('#pw-title').value.trim();
    const password = $('#pw-password').value;
    if (!title || !password) {
      showToast('العنوان وكلمة المرور مطلوبان', 'error');
      return;
    }
    try {
      const enc = await encryptText(password, state.masterKey);
      const data = {
        title,
        username: $('#pw-username').value.trim(),
        password_enc: enc,
        url: $('#pw-url').value.trim(),
        notes: $('#pw-notes').value.trim()
      };
      if (editing) {
        await Passwords.update(id, data);
      } else {
        await Passwords.add(data);
      }
      closeModal();
      await _refreshPasswordsList();
      showToast('تم الحفظ بنجاح', 'success');
    } catch (e) {
      showToast('فشل الحفظ: ' + e.message, 'error');
    }
  });
}

// ==================================================================
// ==================== 3) دفتر الديون ==============================
// ==================================================================

async function _renderDebtsSection() {
  const addBtn = $('#add-debt-btn');
  addBtn?.addEventListener('click', () => _debtFormModal());

  $$('#tpl-debts .tab').forEach((tab) => {
    tab.addEventListener('click', () => {
      $$('#tpl-debts .tab').forEach((t) => t.classList.remove('active'));
      tab.classList.add('active');
      state.activeDebtFilter = tab.getAttribute('data-debt-type') || 'all';
      _refreshDebtsList();
    });
  });

  await _refreshDebtsList();
}

async function _refreshDebtsList() {
  const list = $('#debt-list');
  if (!list) return;
  try {
    let debts;
    if (state.activeDebtFilter === 'owed_to_me') {
      debts = await Debts.byDirection('owed_to_me');
    } else if (state.activeDebtFilter === 'i_owe') {
      debts = await Debts.byDirection('i_owe');
    } else {
      debts = await Debts.list();
    }
    if (!debts.length) {
      list.innerHTML = `<p class="small-text">لا توجد ديون في هذا العرض.</p>`;
      return;
    }
    const rows = [];
    for (const d of debts) {
      const paid = await Debts.totalPaid(d.id);
      const remaining = (d.total_amount || 0) - paid;
      const status = d.status || 'unpaid';
      const statusLabel = status === 'paid' ? 'مسدد ✅' : status === 'partial' ? 'سداد جزئي' : 'غير مسدد';
      const statusClass = status === 'paid' ? 'paid' : status === 'partial' ? 'partial' : 'unpaid';
      const dirLabel = d.direction === 'owed_to_me' ? 'لي عند' : 'علي لـ';
      const currency = d.currency || 'SAR';
      rows.push(`
        <div class="card" data-id="${d.id}">
          <h3>${escapeHtml(d.person_name)} <span class="badge ${statusClass}">${statusLabel}</span></h3>
          <p><strong>الاتجاه:</strong> ${dirLabel}</p>
          <p><strong>المبلغ الإجمالي:</strong> ${(d.total_amount || 0).toFixed(2)} ${escapeHtml(currency)}</p>
          <p><strong>المدفوع:</strong> ${paid.toFixed(2)} ${escapeHtml(currency)}</p>
          <p><strong>المتبقي:</strong> ${remaining.toFixed(2)} ${escapeHtml(currency)}</p>
          ${d.notes ? `<p><strong>ملاحظات:</strong> ${escapeHtml(d.notes)}</p>` : ''}
          <div class="card-actions">
            ${remaining > 0.001 ? `<button data-action="pay" class="gold">💰 سداد</button>` : ''}
            <button data-action="view-payments">📋 السدادات</button>
            <button data-action="edit">✏️ تعديل</button>
            <button data-action="delete" class="danger">🗑️ حذف</button>
          </div>
        </div>
      `);
    }
    list.innerHTML = rows.join('');
    _bindDebtCardActions(debts);
  } catch (e) {
    list.innerHTML = `<div class="alert error">${escapeHtml(e.message)}</div>`;
  }
}

function _bindDebtCardActions(debts) {
  $$('#debt-list .card').forEach((card) => {
    const id = Number(card.getAttribute('data-id'));
    const d = debts.find((x) => x.id === id);
    if (!d) return;

    card.querySelector('[data-action="pay"]')?.addEventListener('click', () => _debtPaymentModal(d));
    card.querySelector('[data-action="view-payments"]')?.addEventListener('click', () => _debtViewPaymentsModal(d));
    card.querySelector('[data-action="edit"]')?.addEventListener('click', () => _debtFormModal(id));

    card.querySelector('[data-action="delete"]')?.addEventListener('click', async () => {
      if (!confirm('حذف هذا الدين وكل سدّاداته؟')) return;
      try {
        await Debts.remove(id);
        await _refreshDebtsList();
        showToast('تم الحذف', 'success');
      } catch (e) {
        showToast('فشل الحذف: ' + e.message, 'error');
      }
    });
  });
}

function _debtFormModal(id = null) {
  const editing = id != null;
  openModal(`
    <h3>${editing ? 'تعديل' : 'إضافة'} دين</h3>
    <div class="field-group"><label>اسم الشخص *</label><input type="text" id="db-name" /></div>
    <div class="field-group">
      <label>الاتجاه</label>
      <select id="db-direction">
        <option value="owed_to_me">لي عند الناس</option>
        <option value="i_owe">علي للناس</option>
      </select>
    </div>
    <div class="field-group"><label>المبلغ الإجمالي *</label><input type="number" id="db-total" step="0.01" min="0" /></div>
    <div class="field-group"><label>العملة</label><input type="text" id="db-currency" value="SAR" /></div>
    <div class="field-group"><label>ملاحظات</label><textarea id="db-notes"></textarea></div>
    <button class="btn-gold" id="db-save" style="width:100%">حفظ</button>
  `);

  if (editing) {
    (async () => {
      const debts = await Debts.list();
      const d = debts.find((x) => x.id === id);
      if (!d) return;
      $('#db-name').value = d.person_name || '';
      $('#db-direction').value = d.direction || 'owed_to_me';
      $('#db-total').value = d.total_amount;
      $('#db-currency').value = d.currency || 'SAR';
      $('#db-notes').value = d.notes || '';
    })();
  }

  $('#db-save').addEventListener('click', async () => {
    const name = $('#db-name').value.trim();
    const total = parseFloat($('#db-total').value);
    if (!name) {
      showToast('اسم الشخص مطلوب', 'error');
      return;
    }
    if (!total || total <= 0) {
      showToast('أدخل مبلغاً صحيحاً', 'error');
      return;
    }
    const data = {
      person_name: name,
      direction: $('#db-direction').value,
      total_amount: total,
      currency: $('#db-currency').value.trim() || 'SAR',
      notes: $('#db-notes').value.trim()
    };
    try {
      if (editing) {
        await Debts.update(id, data);
        await Debts.updateStatus(id);
      } else {
        await Debts.add(data);
      }
      closeModal();
      await _refreshDebtsList();
      showToast('تم الحفظ بنجاح', 'success');
    } catch (e) {
      showToast('فشل الحفظ: ' + e.message, 'error');
    }
  });
}

function _debtPaymentModal(debt) {
  openModal(`
    <h3>سداد لـ ${escapeHtml(debt.person_name)}</h3>
    <p class="small-text">المبلغ الإجمالي: ${(debt.total_amount || 0).toFixed(2)} ${escapeHtml(debt.currency || 'SAR')}</p>
    <div class="field-group"><label>مبلغ السداد *</label><input type="number" id="dp-amount" step="0.01" min="0" /></div>
    <div class="field-group"><label>ملاحظة</label><input type="text" id="dp-note" /></div>
    <button class="btn-gold" id="dp-save" style="width:100%">تسجيل السداد</button>
  `);

  $('#dp-save').addEventListener('click', async () => {
    const amount = parseFloat($('#dp-amount').value);
    if (!amount || amount <= 0) {
      showToast('أدخل مبلغاً صحيحاً', 'error');
      return;
    }
    try {
      await Debts.addPayment(debt.id, amount, $('#dp-note').value.trim());
      await Debts.updateStatus(debt.id);
      closeModal();
      await _refreshDebtsList();
      showToast('تم تسجيل السداد', 'success');
    } catch (e) {
      showToast('فشل السداد: ' + e.message, 'error');
    }
  });
}

async function _debtViewPaymentsModal(debt) {
  try {
    const payments = await Debts.payments(debt.id);
    openModal(`
      <h3>سدادات: ${escapeHtml(debt.person_name)}</h3>
      ${payments.length
        ? `<ul class="clean">
            ${payments.map((p) => `
              <li>
                <strong>${p.amount.toFixed(2)}</strong> ${escapeHtml(debt.currency || 'SAR')}
                — ${formatDateTime(p.paid_at)}
                ${p.note ? ' — ' + escapeHtml(p.note) : ''}
              </li>
            `).join('')}
          </ul>`
        : '<p class="small-text">لا سدادات بعد.</p>'}
    `);
  } catch (e) {
    showToast('فشل تحميل السدادات: ' + e.message, 'error');
  }
}

// ==================================================================
// ==================== 4) مدير الملفات =============================
// ==================================================================

async function _renderFilesSection() {
  const uploadBtn = $('#upload-file-btn');
  uploadBtn?.addEventListener('click', () => _fileUploadModal());
  await _refreshFilesList();
}

async function _refreshFilesList() {
  const list = $('#file-list');
  if (!list) return;
  try {
    const files = await Files.list();
    if (!files.length) {
      list.innerHTML = `<p class="small-text">لا ملفات بعد. اضغط "رفع ملف" لاختيار ملف.</p>`;
      return;
    }
    list.innerHTML = files.map((f) => `
      <div class="file-row" data-id="${f.id}">
        <div class="file-icon">${getFileIcon(f.mime_type, f.name)}</div>
        <div class="file-info">
          <h4>${escapeHtml(f.name)}</h4>
          <p>${escapeHtml(f.category || 'بدون تصنيف')} • ${formatBytes(f.size)} • ${formatDate(f.created_at)}</p>
          ${f.notes ? `<p class="small-text">${escapeHtml(f.notes)}</p>` : ''}
        </div>
        <div class="card-actions" style="flex-direction:column;">
          <button data-action="download" class="gold">⬇️ تنزيل</button>
          <button data-action="edit">✏️</button>
          <button data-action="delete" class="danger">🗑️</button>
        </div>
      </div>
    `).join('');
    _bindFileActions();
  } catch (e) {
    list.innerHTML = `<div class="alert error">${escapeHtml(e.message)}</div>`;
  }
}

function _bindFileActions() {
  $$('#file-list .file-row').forEach((row) => {
    const id = Number(row.getAttribute('data-id'));

    row.querySelector('[data-action="download"]')?.addEventListener('click', async () => {
      try {
        const f = await Files.getData(id);
        if (!f) {
          showToast('الملف غير موجود', 'error');
          return;
        }
        const bytes = await decryptBytes(f.data, state.masterKey);
        const blob = new Blob([bytes], { type: f.mime_type || 'application/octet-stream' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = f.name || 'file';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        setTimeout(() => URL.revokeObjectURL(url), 10000);
        showToast('تم تنزيل الملف', 'success');
      } catch (e) {
        showToast('فشل تنزيل الملف: ' + e.message, 'error');
      }
    });

    row.querySelector('[data-action="edit"]')?.addEventListener('click', () => _fileEditModal(id));

    row.querySelector('[data-action="delete"]')?.addEventListener('click', async () => {
      if (!confirm('حذف هذا الملف نهائياً؟')) return;
      try {
        await Files.remove(id);
        await _refreshFilesList();
        showToast('تم الحذف', 'success');
      } catch (e) {
        showToast('فشل الحذف: ' + e.message, 'error');
      }
    });
  });
}

function _fileUploadModal() {
  openModal(`
    <h3>رفع ملف جديد</h3>
    <div class="field-group">
      <label>اختر الملف * (PDF / Word / Excel / صور / أي ملف)</label>
      <input type="file" id="file-input" />
    </div>
    <div class="field-group"><label>التصنيف</label><input type="text" id="file-category" placeholder="مثال: عقود، فواتير..." /></div>
    <div class="field-group"><label>ملاحظات</label><textarea id="file-notes"></textarea></div>
    <button class="btn-gold" id="file-save" style="width:100%">رفع وحفظ</button>
  `);

  $('#file-save').addEventListener('click', async () => {
    const fileInput = $('#file-input');
    if (!fileInput.files || !fileInput.files[0]) {
      showToast('اختر ملفاً أولاً', 'error');
      return;
    }
    const file = fileInput.files[0];
    try {
      const buf = await file.arrayBuffer();
      const enc = await encryptBytes(new Uint8Array(buf), state.masterKey);
      await Files.add({
        name: file.name,
        mime_type: file.type || 'application/octet-stream',
        size: file.size,
        data: enc,
        category: $('#file-category').value.trim(),
        notes: $('#file-notes').value.trim()
      });
      closeModal();
      await _refreshFilesList();
      showToast('تم رفع الملف بنجاح', 'success');
    } catch (e) {
      showToast('فشل رفع الملف: ' + e.message, 'error');
    }
  });
}

async function _fileEditModal(id) {
  const files = await Files.list();
  const f = files.find((x) => x.id === id);
  if (!f) return;
  openModal(`
    <h3>تعديل الملف</h3>
    <div class="field-group"><label>الاسم</label><input type="text" id="fe-name" value="${escapeHtml(f.name)}" /></div>
    <div class="field-group"><label>التصنيف</label><input type="text" id="fe-category" value="${escapeHtml(f.category || '')}" /></div>
    <div class="field-group"><label>ملاحظات</label><textarea id="fe-notes">${escapeHtml(f.notes || '')}</textarea></div>
    <button class="btn-gold" id="fe-save" style="width:100%">حفظ</button>
  `);

  $('#fe-save').addEventListener('click', async () => {
    try {
      await Files.update(id, {
        name: $('#fe-name').value.trim() || f.name,
        category: $('#fe-category').value.trim(),
        notes: $('#fe-notes').value.trim()
      });
      closeModal();
      await _refreshFilesList();
      showToast('تم الحفظ', 'success');
    } catch (e) {
      showToast('فشل الحفظ: ' + e.message, 'error');
    }
  });
}
/* ============================================
   AMMAR VAULT – app.js – الجزء 3 من 3 (الأخير)
   تنفيذ كامل: معرض الصور، الجدول، مكتبة الملخصات،
   الروابط، الإحصائيات، النسخ الاحتياطي
   ============================================ */

// ==================================================================
// ==================== 5) معرض الصور ==============================
// ==================================================================

async function _renderGallerySection() {
  const uploadBtn = $('#upload-image-btn');
  uploadBtn?.addEventListener('click', () => _imageUploadModal());
  await _refreshGallery();
}

async function _refreshGallery() {
  const albumList = $('#album-list');
  const grid = $('#gallery-grid');
  if (!albumList || !grid) return;

  try {
    const albums = await Albums.list();
    const activeId = state.activeAlbumId;

    // شريط الألبومات
    albumList.innerHTML = `
      <button class="album-chip ${!activeId ? 'active' : ''}" data-album="">كل الصور</button>
      ${albums.map((a) => `
        <button class="album-chip ${activeId === a.id ? 'active' : ''}" data-album="${a.id}">
          ${escapeHtml(a.name)}
        </button>
      `).join('')}
      <button class="album-chip" id="add-album-chip" style="background:var(--gold);color:var(--navy)">➕ ألبوم</button>
    `;

    albumList.querySelectorAll('.album-chip[data-album]').forEach((chip) => {
      chip.addEventListener('click', () => {
        const v = chip.getAttribute('data-album');
        state.activeAlbumId = v ? Number(v) : null;
        _refreshGallery();
      });
    });

    $('#add-album-chip')?.addEventListener('click', async () => {
      const name = prompt('اسم الألبوم الجديد:');
      if (!name || !name.trim()) return;
      try {
        await Albums.add(name.trim());
        showToast('تم إنشاء الألبوم', 'success');
        await _refreshGallery();
      } catch (e) {
        showToast('فشل: ' + e.message, 'error');
      }
    });

    // شبكة الصور
    const images = await Images.list(state.activeAlbumId);
    if (!images.length) {
      grid.innerHTML = `<p class="small-text" style="grid-column:1/-1">لا صور في هذا العرض.</p>`;
      return;
    }
    grid.innerHTML = images.map((img) => `
      <div class="gallery-item" data-id="${img.id}" style="position:relative">
        <img src="${base64ToDataUrl(img.data, img.mime_type || 'image/jpeg')}"
             alt="${escapeHtml(img.name || '')}"
             data-id="${img.id}" />
      </div>
    `).join('');

    grid.querySelectorAll('img[data-id]').forEach((el) => {
      el.addEventListener('click', () => {
        const id = Number(el.getAttribute('data-id'));
        _imageViewerModal(id);
      });
    });
  } catch (e) {
    grid.innerHTML = `<div class="alert error">${escapeHtml(e.message)}</div>`;
  }
}

async function _imageViewerModal(id) {
  const images = await Images.list();
  const img = images.find((x) => x.id === id);
  if (!img) return;
  const src = base64ToDataUrl(img.data, img.mime_type || 'image/jpeg');
  openModal(`
    <h3>${escapeHtml(img.name || 'صورة')}</h3>
    <img src="${src}" style="width:100%;border-radius:12px;margin-bottom:12px" />
    <div class="flex gap-2" style="flex-wrap:wrap">
      <a href="${src}" download="${escapeHtml(img.name || 'image')}" class="btn-outline" style="text-decoration:none;text-align:center;flex:1">⬇️ تنزيل</a>
      <button class="btn-gold" id="img-delete" style="flex:1;background:#FDECEA;color:var(--danger)">🗑️ حذف</button>
    </div>
  `);
  $('#img-delete')?.addEventListener('click', async () => {
    if (!confirm('حذف هذه الصورة نهائياً؟')) return;
    try {
      await Images.remove(id);
      closeModal();
      await _refreshGallery();
      showToast('تم الحذف', 'success');
    } catch (e) {
      showToast('فشل الحذف: ' + e.message, 'error');
    }
  });
}

async function _imageUploadModal() {
  const albums = await Albums.list();
  openModal(`
    <h3>إضافة صورة</h3>
    <div class="field-group">
      <label>اختر صورة *</label>
      <input type="file" id="img-input" accept="image/*" multiple />
    </div>
    <div class="field-group">
      <label>الألبوم (اختياري)</label>
      <select id="img-album">
        <option value="">بدون ألبوم</option>
        ${albums.map((a) => `<option value="${a.id}">${escapeHtml(a.name)}</option>`).join('')}
      </select>
    </div>
    <button class="btn-gold" id="img-save" style="width:100%">حفظ الصور</button>
  `);

  $('#img-save')?.addEventListener('click', async () => {
    const input = $('#img-input');
    if (!input.files || !input.files.length) {
      showToast('اختر صورة أولاً', 'error');
      return;
    }
    const albumIdVal = $('#img-album').value;
    const albumId = albumIdVal ? Number(albumIdVal) : null;
    try {
      for (const file of input.files) {
        const buf = await file.arrayBuffer();
        const enc = await encryptBytes(new Uint8Array(buf), state.masterKey);
        await Images.add({
          album_id: albumId,
          name: file.name,
          mime_type: file.type || 'image/jpeg',
          data: enc
        });
      }
      closeModal();
      await _refreshGallery();
      showToast('تم حفظ الصور بنجاح', 'success');
    } catch (e) {
      showToast('فشل الحفظ: ' + e.message, 'error');
    }
  });
}

// ==================================================================
// ==================== 6) الجدول والتذكيرات ========================
// ==================================================================

async function _renderPlannerSection() {
  const addBtn = $('#add-task-btn');
  addBtn?.addEventListener('click', () => _taskFormModal());

  $$('#tpl-planner .tab').forEach((tab) => {
    tab.addEventListener('click', () => {
      $$('#tpl-planner .tab').forEach((t) => t.classList.remove('active'));
      tab.classList.add('active');
      state.activePlannerView = tab.getAttribute('data-view') || 'day';
      _refreshPlannerList();
    });
  });

  await _refreshPlannerList();
}

async function _refreshPlannerList() {
  const list = $('#planner-list');
  if (!list) return;
  try {
    const tasks = await Tasks.list();
    const view = state.activePlannerView;
    const filtered = _filterTasksByView(tasks, view);
    if (!filtered.length) {
      list.innerHTML = `<p class="small-text">لا مهام في هذا العرض.</p>`;
      return;
    }
    list.innerHTML = filtered.map((t) => {
      const prio = t.priority || 'normal';
      const prioLabel = prio === 'high' ? '🔴 عالية' : prio === 'low' ? '🟢 منخفضة' : '🟡 عادية';
      return `
        <div class="task-item ${t.done ? 'done' : ''}" data-id="${t.id}">
          <input type="checkbox" class="task-checkbox" ${t.done ? 'checked' : ''} data-id="${t.id}" />
          <div class="task-body">
            <div class="task-title">${escapeHtml(t.title)}</div>
            ${t.description ? `<p class="small-text">${escapeHtml(t.description)}</p>` : ''}
            <div class="task-meta">
              ${t.due_date ? `📅 ${escapeHtml(t.due_date)}` : ''}
              ${t.reminder_at ? ` • ⏰ ${escapeHtml(t.reminder_at)}` : ''}
              • ${prioLabel}
            </div>
            <div class="card-actions">
              <button data-action="edit">✏️ تعديل</button>
              <button data-action="delete" class="danger">🗑️ حذف</button>
            </div>
          </div>
        </div>
      `;
    }).join('');

    list.querySelectorAll('.task-checkbox').forEach((cb) => {
      cb.addEventListener('change', async () => {
        const id = Number(cb.getAttribute('data-id'));
        try {
          await Tasks.toggleDone(id, cb.checked);
          await _refreshPlannerList();
        } catch (e) {
          showToast('فشل التحديث', 'error');
        }
      });
    });

    list.querySelectorAll('.task-item').forEach((item) => {
      const id = Number(item.getAttribute('data-id'));
      item.querySelector('[data-action="edit"]')?.addEventListener('click', () => _taskFormModal(id));
      item.querySelector('[data-action="delete"]')?.addEventListener('click', async () => {
        if (!confirm('حذف هذه المهمة؟')) return;
        try {
          await Tasks.remove(id);
          await _refreshPlannerList();
          showToast('تم الحذف', 'success');
        } catch (e) {
          showToast('فشل الحذف: ' + e.message, 'error');
        }
      });
    });
  } catch (e) {
    list.innerHTML = `<div class="alert error">${escapeHtml(e.message)}</div>`;
  }
}

function _filterTasksByView(tasks, view) {
  const now = new Date();
  const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  if (view === 'day') {
    const today = startOfDay.toISOString().slice(0, 10);
    return tasks.filter((t) => !t.due_date || t.due_date <= today);
  }
  if (view === 'week') {
    const end = new Date(startOfDay);
    end.setDate(end.getDate() + 7);
    const endStr = end.toISOString().slice(0, 10);
    return tasks.filter((t) => !t.due_date || t.due_date <= endStr);
  }
  // month
  const end = new Date(now.getFullYear(), now.getMonth() + 1, 1);
  const endStr = end.toISOString().slice(0, 10);
  return tasks.filter((t) => !t.due_date || t.due_date <= endStr);
}

async function _taskFormModal(id = null) {
  const editing = id != null;
  openModal(`
    <h3>${editing ? 'تعديل' : 'إضافة'} مهمة</h3>
    <div class="field-group"><label>العنوان *</label><input type="text" id="tk-title" /></div>
    <div class="field-group"><label>الوصف</label><textarea id="tk-desc"></textarea></div>
    <div class="field-group"><label>تاريخ الاستحقاق</label><input type="date" id="tk-due" /></div>
    <div class="field-group"><label>وقت التذكير</label><input type="datetime-local" id="tk-reminder" /></div>
    <div class="field-group">
      <label>الأولوية</label>
      <select id="tk-priority">
        <option value="low">منخفضة</option>
        <option value="normal" selected>عادية</option>
        <option value="high">عالية</option>
      </select>
    </div>
    <button class="btn-gold" id="tk-save" style="width:100%">حفظ</button>
  `);

  if (editing) {
    (async () => {
      const tasks = await Tasks.list();
      const t = tasks.find((x) => x.id === id);
      if (!t) return;
      $('#tk-title').value = t.title || '';
      $('#tk-desc').value = t.description || '';
      $('#tk-due').value = t.due_date || '';
      $('#tk-reminder').value = t.reminder_at || '';
      $('#tk-priority').value = t.priority || 'normal';
    })();
  }

  $('#tk-save').addEventListener('click', async () => {
    const title = $('#tk-title').value.trim();
    if (!title) {
      showToast('العنوان مطلوب', 'error');
      return;
    }
    const data = {
      title,
      description: $('#tk-desc').value.trim(),
      due_date: $('#tk-due').value,
      reminder_at: $('#tk-reminder').value,
      priority: $('#tk-priority').value
    };
    try {
      if (editing) {
        await Tasks.update(id, data);
      } else {
        await Tasks.add(data);
      }
      // جدولة إشعار محلي إذا وُجد reminder
      if (data.reminder_at) {
        try {
          const { scheduleTaskReminder } = await import('./js/notifications.js');
          await scheduleTaskReminder(title, data.reminder_at, data.description);
        } catch (_) { /* الإشعارات اختيارية */ }
      }
      closeModal();
      await _refreshPlannerList();
      showToast('تم الحفظ', 'success');
    } catch (e) {
      showToast('فشل الحفظ: ' + e.message, 'error');
    }
  });
}

// ==================================================================
// ==================== 7) مكتبة الملخصات ===========================
// ==================================================================

async function _renderLibrarySection() {
  const saveBtn = $('#save-summary-btn');
  saveBtn?.addEventListener('click', async () => {
    const title = $('#summary-title-input').value.trim();
    const content = $('#summary-input').value.trim();
    if (!title || !content) {
      showToast('العنوان والمحتوى مطلوبان', 'error');
      return;
    }
    try {
      await Summaries.add({ title, content, tags: '' });
      $('#summary-title-input').value = '';
      $('#summary-input').value = '';
      await _refreshSummaries();
      showToast('تم حفظ الملخص', 'success');
    } catch (e) {
      showToast('فشل الحفظ: ' + e.message, 'error');
    }
  });
  await _refreshSummaries();
}

async function _refreshSummaries() {
  const list = $('#summary-list');
  if (!list) return;
  try {
    const items = await Summaries.list();
    if (!items.length) {
      list.innerHTML = `<p class="small-text">لا ملخصات بعد.</p>`;
      return;
    }
    list.innerHTML = items.map((s) => `
      <div class="card" data-id="${s.id}">
        <h3>${escapeHtml(s.title)}</h3>
        <p class="small-text">${formatDateTime(s.created_at)}</p>
        <p style="white-space:pre-wrap;max-height:180px;overflow:auto">${escapeHtml((s.content || '').slice(0, 500))}${(s.content || '').length > 500 ? '...' : ''}</p>
        <div class="card-actions">
          <button data-action="view" class="gold">👁️ عرض كامل</button>
          <button data-action="copy">📋 نسخ</button>
          <button data-action="edit">✏️ تعديل</button>
          <button data-action="delete" class="danger">🗑️ حذف</button>
        </div>
      </div>
    `).join('');
    _bindSummaryActions(items);
  } catch (e) {
    list.innerHTML = `<div class="alert error">${escapeHtml(e.message)}</div>`;
  }
}

function _bindSummaryActions(items) {
  $$('#summary-list .card').forEach((card) => {
    const id = Number(card.getAttribute('data-id'));
    const s = items.find((x) => x.id === id);
    if (!s) return;
    card.querySelector('[data-action="view"]')?.addEventListener('click', () => {
      openModal(`
        <h3>${escapeHtml(s.title)}</h3>
        <p style="white-space:pre-wrap;max-height:60vh;overflow:auto">${escapeHtml(s.content)}</p>
      `);
    });
    card.querySelector('[data-action="copy"]')?.addEventListener('click', async () => {
      const ok = await copyToClipboard(s.content);
      showToast(ok ? 'تم النسخ' : 'فشل النسخ', ok ? 'success' : 'error');
    });
    card.querySelector('[data-action="edit"]')?.addEventListener('click', async () => {
      const newTitle = prompt('العنوان:', s.title);
      if (newTitle === null) return;
      const newContent = prompt('المحتوى:', s.content);
      if (newContent === null) return;
      try {
        await Summaries.update(id, { title: newTitle, content: newContent, tags: s.tags || '' });
        await _refreshSummaries();
        showToast('تم التحديث', 'success');
      } catch (e) {
        showToast('فشل: ' + e.message, 'error');
      }
    });
    card.querySelector('[data-action="delete"]')?.addEventListener('click', async () => {
      if (!confirm('حذف هذا الملخص؟')) return;
      try {
        await Summaries.remove(id);
        await _refreshSummaries();
        showToast('تم الحذف', 'success');
      } catch (e) {
        showToast('فشل: ' + e.message, 'error');
      }
    });
  });
}

// ==================================================================
// ==================== 8) الروابط المهمة ===========================
// ==================================================================

async function _renderLinksSection() {
  const saveBtn = $('#save-link-btn');
  saveBtn?.addEventListener('click', async () => {
    const name = $('#link-name-input').value.trim();
    const url = $('#link-url-input').value.trim();
    if (!name || !url) {
      showToast('الاسم والرابط مطلوبان', 'error');
      return;
    }
    try {
      await Links.add({ name, url, category: '', notes: '' });
      $('#link-name-input').value = '';
      $('#link-url-input').value = '';
      await _refreshLinks();
      showToast('تم الحفظ', 'success');
    } catch (e) {
      showToast('فشل: ' + e.message, 'error');
    }
  });
  await _refreshLinks();
}

async function _refreshLinks() {
  const list = $('#links-list');
  if (!list) return;
  try {
    const items = await Links.list();
    if (!items.length) {
      list.innerHTML = `<p class="small-text">لا روابط بعد.</p>`;
      return;
    }
    list.innerHTML = items.map((l) => `
      <div class="card" data-id="${l.id}">
        <h3>${escapeHtml(l.name)}</h3>
        <p><a href="${escapeHtml(l.url)}" target="_blank" rel="noopener" style="color:var(--navy);word-break:break-all">${escapeHtml(l.url)}</a></p>
        <div class="card-actions">
          <button data-action="open" class="gold">🌐 فتح</button>
          <button data-action="copy">📋 نسخ</button>
          <button data-action="delete" class="danger">🗑️ حذف</button>
        </div>
      </div>
    `).join('');
    $$('#links-list .card').forEach((card) => {
      const id = Number(card.getAttribute('data-id'));
      const l = items.find((x) => x.id === id);
      if (!l) return;
      card.querySelector('[data-action="open"]')?.addEventListener('click', () => {
        window.open(l.url, '_blank');
      });
      card.querySelector('[data-action="copy"]')?.addEventListener('click', async () => {
        const ok = await copyToClipboard(l.url);
        showToast(ok ? 'تم النسخ' : 'فشل النسخ', ok ? 'success' : 'error');
      });
      card.querySelector('[data-action="delete"]')?.addEventListener('click', async () => {
        if (!confirm('حذف هذا الرابط؟')) return;
        try {
          await Links.remove(id);
          await _refreshLinks();
          showToast('تم الحذف', 'success');
        } catch (e) {
          showToast('فشل: ' + e.message, 'error');
        }
      });
    });
  } catch (e) {
    list.innerHTML = `<div class="alert error">${escapeHtml(e.message)}</div>`;
  }
}

// ==================================================================
// ==================== 9) الإحصائيات ===============================
// ==================================================================

async function _renderStatsSection() {
  const container = $('#stats-content');
  if (!container) return;
  try {
    const s = await Stats.all();
    container.innerHTML = `
      <div class="stats-grid">
        ${_statBox(s.personal, 'وثائق شخصية')}
        ${_statBox(s.passwords, 'كلمات مرور')}
        ${_statBox(s.debts, 'ديون')}
        ${_statBox(s.files, 'ملفات')}
        ${_statBox(s.images, 'صور')}
        ${_statBox(s.tasks, 'مهام')}
        ${_statBox(s.pendingTasks, 'مهام معلقة')}
        ${_statBox(s.summaries, 'ملخصات')}
        ${_statBox(s.links, 'روابط')}
        ${_statBox(s.sumOwedToMe.toFixed(2), 'مستحق لي')}
        ${_statBox(s.sumIOwe.toFixed(2), 'مستحق عليّ')}
      </div>
      <div class="card mt-2">
        <h3>ملخص مالي</h3>
        <p>الصافي: <strong>${(s.sumOwedToMe - s.sumIOwe).toFixed(2)}</strong></p>
        <p class="small-text">${
          s.sumOwedToMe > s.sumIOwe
            ? 'لصالحك — الناس مدينون لك أكثر.'
            : s.sumOwedToMe < s.sumIOwe
            ? 'عليك — أنت مدين بأكثر مما لك.'
            : 'متوازن.'
        }</p>
      </div>
    `;
  } catch (e) {
    container.innerHTML = `<div class="alert error">${escapeHtml(e.message)}</div>`;
  }
}

function _statBox(num, label) {
  return `
    <div class="stat-box">
      <div class="stat-num">${escapeHtml(String(num))}</div>
      <div class="stat-label">${escapeHtml(label)}</div>
    </div>`;
}

// ==================================================================
// ==================== 10) النسخ الاحتياطي =========================
// ==================================================================

function _renderBackupSection() {
  $('#backup-btn')?.addEventListener('click', async () => {
    const status = $('#backup-status');
    try {
      status.innerHTML = `<div class="alert info">جارٍ إنشاء النسخة... قد يستغرق وقتاً.</div>`;
      const { createBackup } = await import('./js/backup.js');
      const result = await createBackup();
      if (result?.cancelled) {
        status.innerHTML = `<div class="alert info">تم الإلغاء.</div>`;
        return;
      }
      status.innerHTML = `<div class="alert success">✅ تم حفظ النسخة بنجاح في: ${escapeHtml(result.path || 'الموقع المختار')}</div>`;
      showToast('تم إنشاء النسخة الاحتياطية', 'success');
    } catch (e) {
      console.error(e);
      status.innerHTML = `<div class="alert error">فشل: ${escapeHtml(e.message)}</div>`;
    }
  });

  $('#restore-btn')?.addEventListener('click', async () => {
    const status = $('#backup-status');
    if (!confirm('استعادة نسخة احتياطية ستستبدل كل البيانات الحالية. متابعة؟')) return;
    try {
      status.innerHTML = `<div class="alert info">جارٍ فتح مستعرض الملفات...</div>`;
      const { restoreBackup } = await import('./js/backup.js');
      const result = await restoreBackup();
      if (result?.cancelled) {
        status.innerHTML = `<div class="alert info">تم الإلغاء.</div>`;
        return;
      }
      status.innerHTML = `<div class="alert success">✅ تمت الاستعادة بنجاح. يُنصح بإعادة تشغيل التطبيق.</div>`;
      showToast('تمت الاستعادة', 'success');
      // إعادة تحميل الأقسام
      await _renderDashboard();
      _renderSection(state.currentSection);
    } catch (e) {
      console.error(e);
      status.innerHTML = `<div class="alert error">فشل: ${escapeHtml(e.message)}</div>`;
    }
  });
}

// ==================================================================
// ==================== تصدير إضافي للاستخدام الداخلي ==============
// ==================================================================

window.__AV.renderGallery = _refreshGallery;
window.__AV.renderPlanner = _refreshPlannerList;
window.__AV.renderSummaries = _refreshSummaries;
window.__AV.renderLinks = _refreshLinks;
window.__AV.renderStats = _renderStatsSection;
window.__AV.renderDebts = _refreshDebtsList;