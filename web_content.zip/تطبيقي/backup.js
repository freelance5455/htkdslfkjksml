/* ============================================
   AMMAR VAULT – js/backup.js
   نسخ احتياطي/استعادة عبر مستعرض الملفات (SAF)
   ============================================ */

import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import { Backup as BackupDB, saveToStore } from './database.js';
import { encryptText, decryptText, fromBase64, toBase64, randomBytes } from './security.js';

const BACKUP_PREFIX = 'AMMAR_VAULT_BACKUP_';
const BACKUP_EXT = '.avault';

/**
 * إنشاء نسخة احتياطية:
 * 1) تصدير كل البيانات
 * 2) تشفيرها باستخدام المفتاح الرئيسي (state.masterKey)
 * 3) حفظها كملف عبر SAF (مستعرض الملفات) أو تنزيل على الويب
 */
export async function createBackup() {
  const state = window.__AV?.state;
  if (!state?.masterKey) throw new Error('الخزنة مقفلة، لا يمكن إنشاء نسخة.');

  // 1) تصدير
  const data = await BackupDB.exportAll();

  // 2) تجهيز payload مع checksum
  const payload = {
    format: 'AMMAR_VAULT',
    version: 1,
    exportedAt: new Date().toISOString(),
    payload: data
  };
  const json = JSON.stringify(payload);

  // 3) تشفير
  const encrypted = await encryptText(json, state.masterKey);

  // 4) اسم الملف
  const ts = new Date().toISOString().replace(/[:.]/g, '-');
  const filename = `${BACKUP_PREFIX}${ts}${BACKUP_EXT}`;

  // 5) حفظ
  const saved = await _saveBackupFile(filename, encrypted);
  return saved;
}

/**
 * استعادة نسخة:
 * 1) اختيار الملف عبر مستعرض الملفات
 * 2) قراءة الملف
 * 3) فك التشفير
 * 4) استبدال البيانات
 */
export async function restoreBackup() {
  const state = window.__AV?.state;
  if (!state?.masterKey) throw new Error('الخزنة مقفلة.');

  // 1) اختيار ملف
  const file = await _pickFile();
  if (!file) return { cancelled: true };

  // 2) قراءة المحتوى
  const text = typeof file.content === 'string' ? file.content : await _readFileAsText(file.file);
  if (!text) throw new Error('تعذّر قراءة الملف.');

  // 3) فك التشفير
  let json;
  try {
    json = await decryptText(text.trim(), state.masterKey);
  } catch (e) {
    throw new Error('تعذّر فك التشفير — تأكد من كلمة المرور الرئيسية أو صحة الملف.');
  }

  // 4) التحقق
  let parsed;
  try {
    parsed = JSON.parse(json);
  } catch (e) {
    throw new Error('ملف النسخة غير صالح.');
  }
  if (parsed.format !== 'AMMAR_VAULT' || !parsed.payload) {
    throw new Error('هذا الملف ليس نسخة AMMAR VAULT صالحة.');
  }

  // 5) الاستيراد
  await BackupDB.importAll(parsed.payload);
  await saveToStore();
  return { cancelled: false };
}

// ==================== الحفظ على Android (SAF) ====================

async function _saveBackupFile(filename, content) {
  // محاولة استخدام SAF (scoped storage) عبر plugin
  if (Capacitor.getPlatform() === 'android') {
    try {
      const scoped = await _getScopedStorage();
      if (scoped) {
        // طلب من المستخدم اختيار مكان الحفظ
        const result = await scoped.createDocument({
          fileName: filename,
          mimeType: 'application/octet-stream'
        });
        if (result?.cancelled) return { cancelled: true, path: null };
        if (result?.uri) {
          await scoped.writeDocument({
            uri: result.uri,
            content
          });
          return { cancelled: false, path: result.uri };
        }
      }
    } catch (e) {
      console.warn('SAF save failed, fallback to Filesystem', e);
    }
  }

  // احتياطي: حفظ في Documents باستخدام Capacitor Filesystem + مشاركة
  try {
    const res = await Filesystem.writeFile({
      path: `AMMAR_VAULT/${filename}`,
      data: content,
      directory: Directory.Documents,
      encoding: Encoding.UTF8,
      recursive: true
    });
    // على الويب نشارك الملف
    if (Capacitor.getPlatform() === 'web') {
      await _downloadWeb(filename, content);
      return { cancelled: false, path: filename };
    }
    return { cancelled: false, path: res.uri || res.path };
  } catch (e) {
    // آخر محاولة: تنزيل على الويب
    if (Capacitor.getPlatform() === 'web') {
      await _downloadWeb(filename, content);
      return { cancelled: false, path: 'download' };
    }
    throw e;
  }
}

async function _getScopedStorage() {
  try {
    const mod = await import('capacitor-scoped-storage');
    return mod.ScopedStorage || mod.default || null;
  } catch (_) {
    return null;
  }
}

// ==================== الاختيار للاستعادة ====================

async function _pickFile() {
  // على الويب: input file
  if (Capacitor.getPlatform() === 'web') {
    return new Promise((resolve) => {
      const inp = document.createElement('input');
      inp.type = 'file';
      inp.accept = '.avault,application/octet-stream,text/plain';
      inp.onchange = async () => {
        if (!inp.files || !inp.files[0]) return resolve(null);
        const file = inp.files[0];
        const content = await _readFileAsText(file);
        resolve({ file, content });
      };
      inp.click();
    });
  }

  // على Android: SAF picker
  try {
    const scoped = await _getScopedStorage();
    if (scoped) {
      const result = await scoped.pickFile({ mimeType: 'application/octet-stream' });
      if (!result || result.cancelled || !result.uri) return null;
      const read = await scoped.readDocument({ uri: result.uri });
      return { file: null, content: read.content };
    }
  } catch (e) {
    console.warn('SAF pick failed', e);
  }

  throw new Error('مستعرض الملفات غير متاح.');
}

function _readFileAsText(file) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result);
    r.onerror = reject;
    r.readAsText(file);
  });
}

async function _downloadWeb(filename, content) {
  const blob = new Blob([content], { type: 'application/octet-stream' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 10000);
}