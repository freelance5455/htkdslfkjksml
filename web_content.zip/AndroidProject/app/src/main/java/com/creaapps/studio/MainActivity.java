package com.creaapps.studio;
import android.app.Activity;import android.os.Bundle;import android.webkit.*;import android.util.Base64;
import android.content.ContentValues;import android.provider.MediaStore;import android.os.Environment;import android.net.Uri;import java.io.OutputStream;import android.widget.Toast;
public class MainActivity extends Activity {
 WebView web;
 public void onCreate(Bundle b){super.onCreate(b);web=new WebView(this);web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);web.addJavascriptInterface(new Bridge(),"CreaAppsNative");setContentView(web);web.loadUrl("file:///android_asset/index.html");}
 public class Bridge {
  @JavascriptInterface public void saveZip(String name,String data){try{
   byte[] bytes=Base64.decode(data,Base64.DEFAULT);ContentValues v=new ContentValues();v.put(MediaStore.Downloads.DISPLAY_NAME,name);v.put(MediaStore.Downloads.MIME_TYPE,"application/zip");v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/CreaApps");
   Uri u=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);if(u==null)throw new Exception("No se pudo crear archivo");
   OutputStream o=getContentResolver().openOutputStream(u);o.write(bytes);o.close();runOnUiThread(()->Toast.makeText(MainActivity.this,"ZIP guardado en Descargas/CreaApps",Toast.LENGTH_LONG).show());
  }catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"Error: "+e.getMessage(),Toast.LENGTH_LONG).show());}}
 }
}
