SIRUMUGAI CENTERING - starter app prototype

Open index.html in Chrome on Android.

Included:
- Add workers (name, 10-digit phone, daily wage, starting advance)
- Daily attendance (full day / half day / absent)
- Salary calculation for a selected date range
- SMS composer opens the phone's SMS app with a prefilled message

Important:
- This is a browser prototype, not an APK yet.
- Data is stored only in this browser on this phone. Clearing browser data may erase it.
- SMS is not sent automatically; user reviews and presses Send in the phone's SMS app.
- Test calculations before using for actual wage payments.
- For APK packaging, this folder must be wrapped in an Android WebView project and built/signed.
