SIRUMUGAI CENTERING - Weekly Salary Update

Features:
- Worker details and delete worker with attendance deletion
- Daily attendance: full day / half day / absent
- Weekly salary calculation for selected date range (defaults to Monday-Sunday)
- Previous advance balance + advances given this week are deducted
- When weekly salary is settled, attendance for that week is cleared
- Any advance amount exceeding weekly wages carries forward to next week
- Settled weekly salary history is retained on this device
- SMS opens the phone SMS app with a prefilled message; user must press Send

Important:
- Data is stored locally in the app/browser. There is no cloud backup or sync.
- Keep a backup before uninstalling or clearing app data.
- Import this ZIP into your HTML-to-APK builder to build an updated APK.
