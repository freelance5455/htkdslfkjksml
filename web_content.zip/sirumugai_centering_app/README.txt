SIRUMUGAI CENTERING - Daily Attendance, Weekly Salary & OT

Open index.html in a browser or import this folder as ZIP into your HTML-to-APK builder.

Attendance: Full day = 1 day wage; Half day = half day wage; Absent = zero.
Normal working day: 8 hours (reference only).
Overtime: enter OT hours for each attendance date. Each worker's hourly rate = daily wage / 8. OT pay = OT hours x that worker's hourly rate.
Salary calculation: choose the start and end dates for the week, then calculate. Base pay = attendance units x daily wage. Hourly rate = daily wage / 8. OT pay = OT hours x hourly rate. Advance deductions are subtracted from gross pay.

Data is stored locally in the app/browser storage. It is not cloud-backed. Do not uninstall or clear app data before backing up records.
SMS opens the phone's SMS composer; the user must press Send.
