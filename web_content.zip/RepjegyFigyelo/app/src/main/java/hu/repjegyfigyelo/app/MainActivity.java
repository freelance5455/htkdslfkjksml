package hu.repjegyfigyelo.app;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {
    EditText key, secret, threshold;
    TextView status;
    SharedPreferences prefs;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs=getSharedPreferences("settings",MODE_PRIVATE);
        createChannel();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 55);
        LinearLayout root=new LinearLayout(this); root.setOrientation(1); root.setPadding(28,24,28,24); root.setBackgroundColor(0xFFF7F8FA);
        ScrollView scroll=new ScrollView(this); scroll.addView(root);
        TextView title=text("✈ Olcsó Repjegy Figyelő",26,true); root.addView(title);
        root.addView(text("Budapest → Várna · Róma · Párizs",17,true));
        root.addView(text("2027. augusztus · 3 felnőtt + 3 gyermek · 5–7 éjszaka",14,false));
        root.addView(text("Árfigyeléshez Amadeus API-hozzáférés kell. A kulcsokat csak ezen a készüléken tároljuk.",14,false));
        key=field("Amadeus API Key",false); key.setText(prefs.getString("key","")); root.addView(key);
        secret=field("Amadeus API Secret",true); secret.setText(prefs.getString("secret","")); root.addView(secret);
        threshold=field("Értesítési küszöb (EUR / összes utas)",false); threshold.setInputType(8194); threshold.setText(prefs.getString("threshold","")); root.addView(threshold);
        Button save=button("Beállítások mentése"); root.addView(save); save.setOnClickListener(v->save());
        Button scan=button("Árak ellenőrzése most"); root.addView(scan); scan.setOnClickListener(v->{ save(); status.setText("Keresés folyamatban…"); new Thread(()->{ String result=FlightScanner.scan(this); runOnUiThread(()->status.setText(result)); }).start(); });
        Button monitor=button("Napi automatikus figyelés bekapcsolása"); root.addView(monitor); monitor.setOnClickListener(v->{save(); Constraints c=new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build(); PeriodicWorkRequest req=new PeriodicWorkRequest.Builder(PriceWorker.class,24,TimeUnit.HOURS).setConstraints(c).build(); WorkManager.getInstance(this).enqueueUniquePeriodicWork("price_watch", ExistingPeriodicWorkPolicy.UPDATE,req); status.setText("Bekapcsolva: Android háttérfeladat naponta próbál ellenőrizni. Az Android az időzítést késleltetheti."); });
        Button stop=button("Automatikus figyelés kikapcsolása"); root.addView(stop); stop.setOnClickListener(v->{WorkManager.getInstance(this).cancelUniqueWork("price_watch"); status.setText("Automatikus figyelés kikapcsolva.");});
        root.addView(text("Gyors keresések foglalási oldalakon",18,true));
        addLink(root,"Várna – Google Flights","https://www.google.com/travel/flights?q=Flights%20from%20Budapest%20to%20Varna%20August%202027%20round%20trip");
        addLink(root,"Róma – Google Flights","https://www.google.com/travel/flights?q=Flights%20from%20Budapest%20to%20Rome%20August%202027%20round%20trip");
        addLink(root,"Párizs – Google Flights","https://www.google.com/travel/flights?q=Flights%20from%20Budapest%20to%20Paris%20August%202027%20round%20trip");
        addLink(root,"Amadeus fejlesztői portál (API-kulcs igénylése)","https://developers.amadeus.com/");
        root.addView(text("Fontos: az ingyenes/sandbox API nem feltétlenül ad valós, foglalható árakat. A kereső 4 heti indulási dátumot (aug. 1., 8., 15., 22.) és 5/6/7 éjszakát ellenőriz célállomásonként; nem garantálja a hónap abszolút legolcsóbb jegyét. A Google Flights linkek megnyitják a keresést, nem biztosítanak automatikus árfigyelést. A Klarna elérhetőségét a foglalási oldal fizetési lépésénél kell ellenőrizni.",13,false));
        status=text("Állapot: még nem futott keresés.",14,true); root.addView(status);
        setContentView(scroll);
    }
    TextView text(String s,int size,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(0xFF20242A);t.setPadding(0,10,0,10);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    EditText field(String hint,boolean password){EditText e=new EditText(this);e.setSingleLine(true);e.setTextSize(15);e.setHint(hint); if(password)e.setInputType(129);else e.setInputType(1);return e;}
    Button button(String s){Button b=new Button(this);b.setText(s);return b;}
    void addLink(LinearLayout root,String label,String url){Button b=button(label);root.addView(b);b.setOnClickListener(v->startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))));}
    void save(){prefs.edit().putString("key",key.getText().toString().trim()).putString("secret",secret.getText().toString().trim()).putString("threshold",threshold.getText().toString().trim()).apply();}
    void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel ch=new NotificationChannel("prices","Repülőjegyárak",NotificationManager.IMPORTANCE_DEFAULT);ch.setDescription("Árküszöb alatti repülőjegyek");((NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(ch);}}
}
