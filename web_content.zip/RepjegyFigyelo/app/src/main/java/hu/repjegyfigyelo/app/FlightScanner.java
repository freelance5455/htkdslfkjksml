package hu.repjegyfigyelo.app;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

public class FlightScanner {
    static class Fare {String city,date,ret; double price; Fare(String c,String d,String r,double p){city=c;date=d;ret=r;price=p;}}
    public static String scan(Context ctx){
        SharedPreferences p=ctx.getSharedPreferences("settings",Context.MODE_PRIVATE);
        String key=p.getString("key","").trim(), secret=p.getString("secret","").trim();
        if(key.isEmpty()||secret.isEmpty()) return "Add meg az Amadeus API Key és Secret értékeket, majd mentsd el. API-kulcs: developers.amadeus.com";
        try{
            String token=token(key,secret); String[] cities={"VAR","ROM","PAR"}; String[] names={"Várna","Róma","Párizs"};
            int[] departures={1,8,15,22}; int[] nights={5,6,7}; Fare best=null; StringBuilder lines=new StringBuilder("Legjobb talált árak (EUR, 6 utas összesen):\n");
            for(int ci=0;ci<cities.length;ci++) for(int day:departures) for(int n:nights){
                String dep=String.format(Locale.US,"2027-08-%02d",day); java.time.LocalDate retDate=java.time.LocalDate.parse(dep).plusDays(n); String ret=retDate.toString();
                try{ JSONArray offers=offers(token,cities[ci],dep,ret); for(int j=0;j<offers.length();j++){JSONObject o=offers.getJSONObject(j);double price=o.getJSONObject("price").getDouble("grandTotal"); if(best==null||price<best.price)best=new Fare(names[ci],dep,ret,price);}}
                catch(Exception ignored){}
                try{Thread.sleep(160);}catch(InterruptedException e){Thread.currentThread().interrupt();}
            }
            if(best==null) return "Nem érkezett használható ajánlat az API-tól. Ellenőrizd, hogy az Amadeus-kulcs érvényes-e, és a fiók engedi-e a Flight Offers Search végpontot. A sandbox árai tesztadatok lehetnek.";
            lines.append(String.format(Locale.US,"\nLegolcsóbb a vizsgált dátumok közül: %s, %s – %s, %.2f EUR",best.city,best.date,best.ret,best.price));
            p.edit().putFloat("best_price",(float)best.price).putString("best_result",lines.toString()).apply();
            String threshold=p.getString("threshold","").trim(); if(!threshold.isEmpty()) try{if(best.price<=Double.parseDouble(threshold)){notify(ctx,"Repülőjegy a keret alatt",lines.toString());}}catch(NumberFormatException ignored){}
            return lines.toString()+"\n\nMegjegyzés: a keresés csak aug. 1., 8., 15. és 22. indulást vizsgál, 5–7 éjszakával; az eredmény nem garantált havi minimum. Az Amadeus által visszaadott ár nem garantálja a Klarna elérhetőségét.";
        }catch(Exception e){return "Keresési hiba: "+e.getMessage()+"\nEllenőrizd az internetkapcsolatot és az API-hozzáférést.";}
    }
    static String token(String key,String secret)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL("https://test.api.amadeus.com/v1/security/oauth2/token").openConnection(); c.setRequestMethod("POST");c.setDoOutput(true);c.setConnectTimeout(15000);c.setReadTimeout(20000);c.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
        String body="grant_type=client_credentials&client_id="+URLEncoder.encode(key,"UTF-8")+"&client_secret="+URLEncoder.encode(secret,"UTF-8");
        try(OutputStream os=c.getOutputStream()){os.write(body.getBytes(StandardCharsets.UTF_8));} String s=read(c);return new JSONObject(s).getString("access_token");
    }
    static JSONArray offers(String token,String dest,String dep,String ret)throws Exception{
        String url="https://test.api.amadeus.com/v2/shopping/flight-offers?originLocationCode=BUD&destinationLocationCode="+dest+"&departureDate="+dep+"&returnDate="+ret+"&adults=3&children=3&currencyCode=EUR&max=5";
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setRequestMethod("GET");c.setConnectTimeout(12000);c.setReadTimeout(20000);c.setRequestProperty("Authorization","Bearer "+token);String s=read(c);return new JSONObject(s).optJSONArray("data")==null?new JSONArray():new JSONObject(s).getJSONArray("data");
    }
    static String read(HttpURLConnection c)throws Exception{int code=c.getResponseCode();InputStream is=code>=200&&code<300?c.getInputStream():c.getErrorStream();ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] buf=new byte[4096];int n;while((n=is.read(buf))>0)b.write(buf,0,n);is.close();String s=b.toString("UTF-8");if(code<200||code>=300)throw new IOException("HTTP "+code+": "+s);return s;}
    static void notify(Context ctx,String title,String body){Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(ctx,"prices"):new Notification.Builder(ctx);b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(body.replace('\n',' ')).setStyle(new Notification.BigTextStyle().bigText(body)).setAutoCancel(true);((NotificationManager)ctx.getSystemService(Context.NOTIFICATION_SERVICE)).notify(1,b.build());}
}
