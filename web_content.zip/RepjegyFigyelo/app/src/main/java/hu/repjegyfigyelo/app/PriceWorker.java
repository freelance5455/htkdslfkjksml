package hu.repjegyfigyelo.app;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

public class PriceWorker extends Worker {
    public PriceWorker(@NonNull Context context,@NonNull WorkerParameters params){super(context,params);}
    @NonNull @Override public Result doWork(){
        String result=FlightScanner.scan(getApplicationContext());
        android.content.SharedPreferences p=getApplicationContext().getSharedPreferences("settings",Context.MODE_PRIVATE);
        p.edit().putString("last_result",result).apply();
        return Result.success();
    }
}
