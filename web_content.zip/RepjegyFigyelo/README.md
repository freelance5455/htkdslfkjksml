# Olcsó Repjegy Figyelő (Android)

Android Studio projekt Java-ban. Budapest indulással, 3 felnőtt + 3 gyermek részére Várna (VAR), Róma (ROM), Párizs (PAR) és 2027. augusztusi oda-vissza utakra készült.

## Fontos korlátok
- A projekt Amadeus Self-Service API-t használ, jelenleg a **test/sandbox** végponton. A sandbox nem feltétlenül mutat valódi, foglalható árakat.
- Az API-kulcsot és titkot a felhasználónak kell igényelnie: https://developers.amadeus.com/
- A kereső az augusztus 1., 8., 15. és 22. indulási napokat nézi, 5, 6 és 7 éjszakás utakra, összesen 36 dátum/útvonal kombinációt. Ez nem teljes körű havi keresés, ezért nem garantálja a hónap abszolút legolcsóbb jegyét.
- Automatikus háttérfigyelés naponta futásra van beállítva; az Android az energiatakarékosság miatt késleltetheti.
- A Klarna nem repülőjegyár-adatforrás. A Klarna csak akkor használható, ha a kiválasztott foglalóoldal felkínálja és jóváhagyja. A Google Flights linkek keresési oldalakat nyitnak, nem garantálnak Klarna-fizetést.
- A kód sandbox API-val próbál lekérdezni. Éles, tényleges jegyárakhoz az Amadeus live hozzáférése és a megfelelő API-jogosultság szükséges; az éles végpontra váltás előtt ellenőrizd az Amadeus feltételeit.

## Build és telepítés
1. Telepítsd az Android Studio-t: https://developer.android.com/studio
2. Csomagold ki a ZIP-et, Android Studio → **Open** → válaszd ki a `RepjegyFigyelo` mappát.
3. Várd meg a Gradle Sync-et. A projekt Android Gradle Plugin 8.7.3-at és WorkManager-t használ.
4. Telefonon engedélyezd a fejlesztői beállításokat és az USB-hibakeresést, csatlakoztasd USB-n, majd nyomj **Run**-t. APK készítéséhez: **Build → Build APK(s)**.
5. Az appban add meg az Amadeus API Key és Secret értékeket, majd mentsd el. Először válaszd az **Árak ellenőrzése most** gombot.
6. A napi figyeléshez nyomd meg a **Napi automatikus figyelés bekapcsolása** gombot, és adj meg árküszöböt EUR-ban, a teljes 6 fős foglalásra.

## Biztonság
Az API-kulcsokat ne oszd meg senkivel és ne töltsd fel nyilvános GitHub-tárolóba. A jelenlegi egyszerű minta helyi SharedPreferences-ben tárolja őket, ezért csak saját készüléken használd; éles alkalmazáshoz biztonságosabb titokkezelés és szerveroldali közvetítés ajánlott.
