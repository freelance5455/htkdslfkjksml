# HTML-verzió

Nyisd meg az `index.html` fájlt egy böngészőben. Mobilra optimalizált, beállításokat a böngészőben megőrző keresőoldal a Budapest–Várna/Róma/Párizs 2027. augusztusi útvonalakhoz.

Fontos: ez a HTML-verzió a keresési linkeket és a helyi beállításmentést biztosítja. Nem végez önálló, háttérben futó élő árfigyelést. Ehhez ár-adat API és külön háttérszolgáltatás szükséges.
