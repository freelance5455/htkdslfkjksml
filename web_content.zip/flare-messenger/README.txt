Flare — messenjer (Supabase bilan)

1. Supabase > SQL Editor: supabase.sql ni ishga tushiring (eski sinov jadvallar o‘chadi).
2. Supabase > Authentication > Sign In / Providers > Email: "Confirm email" ni o‘chiring.
3. index.html ni o‘z hostingingizga joylang yoki brauzerda oching.

Eslatma: telefon raqam email ko‘rinishiga aylantiriladi (index.html boshidagi MAIL).
Ro‘yxatdan o‘tishda "Email address is invalid" chiqsa, MAIL qiymatini o‘zgartiring.

logo.svg — Flare logotipi (ilovaga ham, ikonka sifatida ham ishlatish mumkin).
