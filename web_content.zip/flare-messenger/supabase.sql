-- Flare: Supabase jadvallari. SQL Editor'da bir marta ishga tushiring.
-- DIQQAT: avvalgi sinov jadvallar (profiles, contacts, chats, messages) o‘chiriladi.

drop trigger if exists on_auth_user_created on auth.users;
drop table if exists messages, chats, contacts, profiles cascade;

create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  phone text unique not null,
  name text not null
);

create table chats (
  id bigint generated always as identity primary key,
  owner uuid not null default auth.uid() references auth.users(id) on delete cascade,
  kind text not null check (kind in ('group', 'channel')),
  name text not null
);

create table messages (
  id bigint generated always as identity primary key,
  chat_key text not null,
  sender uuid not null default auth.uid(),
  recipient uuid,
  body text not null,
  created_at timestamptz default now()
);
create index on messages (sender);
create index on messages (recipient);

alter table profiles enable row level security;
alter table chats enable row level security;
alter table messages enable row level security;

-- Kirgan har bir foydalanuvchi boshqalarni kontakt sifatida ko‘radi.
create policy "profiles read" on profiles for select to authenticated using (true);
-- Guruh va kanallarni faqat egasi ko‘radi.
create policy "chats own" on chats for all to authenticated
  using (owner = auth.uid()) with check (owner = auth.uid());
-- Xabarni faqat yuboruvchi va qabul qiluvchi o‘qiydi.
create policy "messages read" on messages for select to authenticated
  using (sender = auth.uid() or recipient = auth.uid());
create policy "messages send" on messages for insert to authenticated
  with check (sender = auth.uid());

-- Hisob yaratilganda profil avtomatik qo‘shiladi (kontaktlar ro‘yxati uchun).
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, phone, name)
  values (new.id, new.raw_user_meta_data->>'phone', new.raw_user_meta_data->>'name');
  return new;
end $$;

create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();
