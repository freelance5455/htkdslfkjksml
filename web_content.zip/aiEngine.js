const AIEngine = {
    _controller: null,
    _controllers: new Set(),
    _QUIZ_JSON_INSTRUCTION: 'Create an interactive quiz and respond ONLY with valid JSON: {\"quiz\":[{\"type\":\"mcq\",\"q\":\"question\",\"options\":[\"A\",\"B\",\"C\",\"D\"],\"answer\":\"exact correct option text\",\"explanation\":\"brief explanation\"}]} for multiple-choice questions. Always provide exactly four plausible options. If the user explicitly asks for written/open-ended questions, use {\"type\":\"written\",\"q\":\"question\",\"expectedAnswer\":\"model answer\",\"rubric\":\"grading criteria\"} instead. Create the requested number of questions, default five. Never include the answer in visible question text.',
    
    _THINKING_INSTRUCTION: `When useful, provide a concise, user-facing explanation of your approach and key checks. Do not reveal private internal reasoning or hidden chain-of-thought. If you create code files, use the file-action format below.`,

    _FILE_INSTRUCTION: `When creating code files, output one marker immediately before each complete fenced code block: <file_action status="creating" filename="relative/path/filename.ext">. For multi-file projects, repeat the marker for every file and include complete contents for every file. Use safe relative file paths. Do not omit supporting files. For presentations, structure the deck with headings exactly like ## Slide 1: Title, ## Slide 2: Title, etc., followed by concise slide content so AsimAI can export a PPTX. For polished documents, use clear headings, tables where useful, and print-ready formatting.`,

    PROVIDERS: {
        openai: {
            endpoint: 'https://api.openai.com/v1/chat/completions',
            modelsEndpoint: 'https://api.openai.com/v1/models',
            authHeader: (key) => ({ 'Authorization': `Bearer ${key}` }),
            defaultModel: 'gpt-4.1'
        },
        groq: {
            endpoint: 'https://api.groq.com/openai/v1/chat/completions',
            modelsEndpoint: 'https://api.groq.com/openai/v1/models',
            authHeader: (key) => ({ 'Authorization': `Bearer ${key}` }),
            defaultModel: 'llama-3.3-70b-versatile'
        },
        openrouter: {
            endpoint: 'https://openrouter.ai/api/v1/chat/completions',
            modelsEndpoint: 'https://openrouter.ai/api/v1/models',
            authHeader: (key) => ({
                'Authorization': `Bearer ${key}`,
                'HTTP-Referer': location.origin || 'http://localhost',
                'X-Title': 'AsimAI'
            }),
            defaultModel: 'openai/gpt-4o-mini'
        },
        deepseek: {
            endpoint: 'https://api.deepseek.com/v1/chat/completions',
            modelsEndpoint: 'https://api.deepseek.com/v1/models',
            authHeader: (key) => ({ 'Authorization': `Bearer ${key}` }),
            defaultModel: 'deepseek-chat'
        },
        gemini: {
            endpoint: (model, key) => `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:streamGenerateContent?alt=sse&key=${encodeURIComponent(key)}`,
            modelsEndpoint: (key) => `https://generativelanguage.googleapis.com/v1beta/models?key=${encodeURIComponent(key)}`,
            defaultModel: 'gemini-2.5-flash'
        }
    },
    abort() {
        for (const controller of this._controllers) { try { controller.abort(); } catch {} }
        this._controllers.clear();
        if (this._controller) { try { this._controller.abort(); } catch {} this._controller = null; }
    },
    async webSearch(query) {
        try {
            const res = await fetch(`https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_html=1&skip_disambig=1`, { signal: AbortSignal.timeout ? AbortSignal.timeout(4000) : undefined });
            if (!res.ok) return null;
            const data = await res.json();
            const results = [];
            if (data.AbstractText) results.push({ title: data.Heading || 'Summary', snippet: data.AbstractText });
            if (Array.isArray(data.RelatedTopics)) {
                data.RelatedTopics.slice(0, 3).forEach(t => {
                    if (t.Text) results.push({ title: t.Text.slice(0, 60), snippet: t.Text });
                });
            }
            return results.length ? results : null;
        } catch (e) {
            console.warn('Web search failed:', e);
            return null;
        }
    },
    buildSystemPrompt(settings) {
        let prompt = settings.systemPrompt || '';
        const customInstructions = String(settings.customInstructions || '').trim();
        if (customInstructions) {
            prompt += '\n\n[User Personalization Instructions]\n' + customInstructions.slice(0, 4000);
        }
        prompt += `

[ASIMAI CORE DIRECTIVES]
You are AsimAI, a capable, precise, proactive general-purpose AI assistant and senior technical collaborator.
1. Understand the user's actual goal and respond directly; do not invent tool access, completed actions, facts, citations, or capabilities.
2. For software tasks, inspect the full supplied context, preserve every existing feature unless removal is explicitly requested, avoid destructive rewrites, and deliver complete, coherent, runnable code.
3. For debugging, identify the likely root cause, explain the reasoning briefly, and provide a minimal safe fix plus verification steps.
4. For attached files, use their actual contents; distinguish what was observed from assumptions. For images, describe visible evidence and avoid guessing hidden details.
5. For complex requests, organize work into clear stages, check dependencies and edge cases, and state any genuine limitation transparently.
6. Match the user's language and level. Prefer clear Roman Urdu when the user writes in Roman Urdu.
7. Never claim that an upload, deployment, external action, or code execution succeeded unless it actually did.
8. When generating multi-file projects, keep filenames, imports, APIs, and setup instructions consistent; include all required files and preserve backward compatibility where practical.
`;
        
        prompt += '\n\n' + (settings.showThinking ? this._THINKING_INSTRUCTION : this._FILE_INSTRUCTION);

        const memories = settings.memories || [];
        if (memories.length > 0) {
            prompt += '\n\n[User Information]\n' + memories.map(m => `- ${m.text}`).join('\n');
        }
        return prompt;
    },
    async generateResponse(messages, model, systemPrompt, webSearchActive, onChunk) {
        const settings = await Storage.getSettings();
        this.lastUsedProvider = null;
        this.lastUsedModel = null;

        const provider = settings.provider || 'simulated';
        const savedKey = settings.providerKeys?.[provider] || '';
        const legacyKey = settings.provider === provider ? (settings.apiKey || '') : '';
        const apiKey = String(savedKey || legacyKey).trim();

        console.log('[AIEngine] provider=', provider, '| hasKey=', !!apiKey, '| model=', model);

        const lastUserMsg = [...messages].reverse().find(m => m.sender === 'user')?.text || '';
        if (/\b(slides?|slide deck|presentation|powerpoint|pptx)\b/i.test(lastUserMsg)) {
            systemPrompt += '\n\n[PRESENTATION OUTPUT] Create a coherent presentation. Use one heading per slide in the exact format “## Slide 1: Title”. Add 3–5 concise, meaningful bullets or short paragraphs per slide. Include an opening slide and a conclusion slide when appropriate. Avoid overly dense slides.';
        }
        if (/\b(code|coding|program|debug|fix|build|create|develop|website|app|project|script|clone|chatgpt|replica|dashboard|interface)\b/i.test(lastUserMsg)) {
            systemPrompt += '\n\n[CODE COMPLETENESS] If producing code, act as a senior full-stack engineer and deliver complete, polished, production-minded implementations rather than toy demos. For app/clone requests, implement the requested product as a coherent, usable MVP with the necessary screens, state, navigation and core interactions—not a lone textarea and submit button. Include a short feature checklist, all required files, responsive desktop/mobile layouts, accessible controls, working event handlers, validation, loading/empty/error states, persistence where appropriate, and consistent visual design. Make every visible button work or clearly mark it disabled with a reason. Never replace requested features with placeholders, ellipses, pseudocode, or a minimal mockup. If the requested scope is too large for one answer, say so and deliver the best complete, runnable first milestone rather than pretending a toy page is a full clone. Do not stop mid-file. Close every code fence. Preserve all requested features. If output limits are reached, continue from the exact stopping point without repeating prior code.';
        }
        if (/\b(multiple files|multi[- ]file|full project|complete project|website project|app project|zip project|chatgpt clone|clone (?:of|for|app|website|site)|replica)\b/i.test(lastUserMsg)) {
            systemPrompt += '\n\n[MULTI-FILE OUTPUT] Generate every necessary source file. Put a <file_action status=\"creating\" filename=\"relative/path.ext\"> marker directly before each fenced code block. Use separate markers for each file, ensure imports and file paths match, and include a README with run instructions when useful.';
        }
        if (/\b(pdf|report|ebook|print[- ]ready)\b/i.test(lastUserMsg)) {
            systemPrompt += '\n\n[DOCUMENT OUTPUT] Produce a polished, well-structured document with a clear title, sections, page-friendly headings, tables where useful, and a concise conclusion. The user can export the conversation as PDF.';
        }

        if (window.RAGEngine && lastUserMsg) {
            try {
                const ragChunks = await window.RAGEngine.search(lastUserMsg, 3);
                if (ragChunks.length > 0) {
                    systemPrompt += '\n\n[Relevant Document Context]\n' + ragChunks.map((c, i) => `[${i + 1}] ${c}`).join('\n\n');
                }
            } catch (e) {
                console.warn('RAG search failed:', e);
            }
        }

        if (/\b(quiz|test)\b/i.test(lastUserMsg)) {
            systemPrompt += '\n\n' + this._QUIZ_JSON_INSTRUCTION;
        }

        if (webSearchActive && settings.realWebSearch) {
            const results = await this.webSearch(lastUserMsg.slice(0, 200));
            if (results) {
                const context = results.map((r, i) => `[${i + 1}] ${r.title}: ${r.snippet}`).join('\n');
                systemPrompt += `\n\n[Web Search Results]\n${context}\n\nUse these results if relevant.`;
            }
        }

        if (provider === 'auto') {
            return await this.generateAutoResponse(messages, systemPrompt, webSearchActive, onChunk, settings, lastUserMsg);
        }

        if (provider === 'simulated') {
            return await this.generateSimulatedResponse(messages, model, systemPrompt, webSearchActive, onChunk, settings.streamSpeed || 1.0);
        }
        if (!apiKey) {
            const message = `No ${provider} API key is configured. Open Settings → AI provider & model and add the key for ${provider}.`;
            if (window.ChatRenderer) ChatRenderer.showToast(message);
            throw new Error(message);
        }
        try {
            const chosenModel = model || settings.providerModels?.[provider] || this.PROVIDERS[provider]?.defaultModel;
            const result = await this.fetchCompleteWithContinuation(
                (msgs, prompt, cb) => provider === 'gemini'
                    ? this.fetchGemini(apiKey, msgs, chosenModel, prompt, cb)
                    : this.fetchOpenAICompatible(provider, apiKey, msgs, chosenModel, prompt, cb),
                messages, systemPrompt, onChunk
            );
            this.lastUsedProvider = provider;
            this.lastUsedModel = model || settings.providerModels?.[provider] || this.PROVIDERS[provider]?.defaultModel;
            if (!String(result || '').trim()) throw new Error(`${provider} returned an empty response. Check the model name and API access.`);
            return result;
        } catch (err) {
            if (err.name === 'AbortError') throw err;
            console.error(`[AIEngine] ${provider} request failed`, err);
            const status = Number(err.status);
            const billingBlocked = status === 402;
            const transient = [408, 429, 500, 502, 503, 504].includes(status) || /network|fetch failed|temporar|high demand|unavailable/i.test(String(err.message || ''));
            // A 402 is not transient: skip retrying this provider and try other
            // configured providers instead of making the user lose the whole reply.
            if (transient || billingBlocked) {
                const alternatives = this.getAutoProviderCandidates(settings, lastUserMsg).filter(x => x.provider !== provider);
                for (const candidate of alternatives) {
                    try {
                        if (window.ChatRenderer) ChatRenderer.showToast(`${provider} ${billingBlocked ? 'billing/credits unavailable' : 'temporarily unavailable'}; trying ${candidate.provider}…`);
                        const fallback = candidate.provider === 'gemini'
                            ? await this.fetchGemini(candidate.apiKey, messages, candidate.model, systemPrompt, onChunk)
                            : await this.fetchOpenAICompatible(candidate.provider, candidate.apiKey, messages, candidate.model, systemPrompt, onChunk);
                        if (String(fallback || '').trim()) {
                            this.lastUsedProvider = candidate.provider;
                            this.lastUsedModel = candidate.model;
                            if (window.ChatRenderer) ChatRenderer.showToast(`Answered using ${candidate.provider} fallback`);
                            return fallback;
                        }
                    } catch (fallbackError) {
                        if (fallbackError?.name === 'AbortError') throw fallbackError;
                        console.warn(`[AIEngine] fallback ${candidate.provider} failed`, fallbackError);
                    }
                }
            }
            if (window.ChatRenderer) ChatRenderer.showToast(`${provider} API error: ${String(err.message || 'Request failed').slice(0, 120)}`);
            throw err;
        }
    },
    getAutoProviderCandidates(settings, prompt) {
        const text = String(prompt || '').toLowerCase();
        const complex = /\b(code|coding|program|debug|architecture|algorithm|math|calculate|derive|proof|reason|analy[sz]e|compare|research|technical|complex|detailed|step by step)\b/.test(text);
        const quick = /\b(quick|brief|short|simple|translate|meaning|define|hello|hi|thanks)\b/.test(text);
        const order = complex
            ? ['openai', 'deepseek', 'gemini', 'groq', 'openrouter']
            : quick
                ? ['groq', 'gemini', 'openrouter', 'deepseek', 'openai']
                : ['gemini', 'openai', 'groq', 'deepseek', 'openrouter'];
        return order.map(provider => {
            const key = String(settings.providerKeys?.[provider] || (settings.provider === provider ? settings.apiKey : '') || '').trim();
            if (!key || !this.PROVIDERS[provider]) return null;
            const model = settings.providerModels?.[provider] || this.PROVIDERS[provider].defaultModel;
            return { provider, apiKey: key, model };
        }).filter(Boolean);
    },

    async generateAutoResponse(messages, systemPrompt, webSearchActive, onChunk, settings, lastUserMsg) {
        const candidates = this.getAutoProviderCandidates(settings, lastUserMsg);
        if (!candidates.length) {
            const message = 'Smart Auto has no configured API keys. Add at least one provider key in Settings → AI provider & model.';
            if (window.ChatRenderer) ChatRenderer.showToast(message);
            throw new Error(message);
        }

        const failures = [];
        for (const candidate of candidates) {
            try {
                // Buffer each attempt so a failed provider cannot leave partial text in the chat.
                const result = await this.fetchCompleteWithContinuation(
                    (msgs, prompt, cb) => candidate.provider === 'gemini'
                        ? this.fetchGemini(candidate.apiKey, msgs, candidate.model, prompt, cb)
                        : this.fetchOpenAICompatible(candidate.provider, candidate.apiKey, msgs, candidate.model, prompt, cb),
                    messages, systemPrompt, null
                );
                this.lastUsedProvider = candidate.provider;
                this.lastUsedModel = candidate.model;
                if (window.ChatRenderer) ChatRenderer.showToast(`Smart Auto selected ${candidate.provider}: ${candidate.model}`);
                if (result) {
                    const pieces = result.split(/(\s+)/);
                    let accumulated = '';
                    for (const piece of pieces) {
                        accumulated += piece;
                        onChunk?.(piece, accumulated);
                    }
                }
                return result;
            } catch (err) {
                if (err?.name === 'AbortError') throw err;
                failures.push(`${candidate.provider}: ${err.message}`);
                console.warn(`[AIEngine] Smart Auto provider failed: ${candidate.provider}`, err);
            }
        }

        console.warn('[AIEngine] Smart Auto failures:', failures);
        const message = `All configured providers failed. ${failures.join(' | ')}`.slice(0, 700);
        if (window.ChatRenderer) ChatRenderer.showToast('All configured AI providers failed. Check the error details.');
        throw new Error(message);
    },

    async fetchOpenAICompatible(providerKey, apiKey, messages, model, systemPrompt, onChunk) {
        const cfg = this.PROVIDERS[providerKey];
        if (!cfg) throw new Error(`Unknown provider: ${providerKey}`);
        const payloadMessages = [
            { role: 'system', content: systemPrompt || '' },
            ...messages.map((m) => {
                const role = m.sender === 'user' ? 'user' : 'assistant';
                const images = Array.isArray(m.images) ? m.images : [];
                if (role === 'user' && images.length) {
                    const content = [{ type: 'text', text: String(m.text || '') }];
                    images.forEach(dataUrl => { if (typeof dataUrl === 'string' && dataUrl.startsWith('data:image/')) content.push({ type: 'image_url', image_url: { url: dataUrl } }); });
                    return { role, content };
                }
                return { role, content: String(m.text || '') };
            })
        ];
        const controller = new AbortController();
        this._controllers.add(controller);
        this._controller = controller;
        try {
            const response = await fetch(cfg.endpoint, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', ...cfg.authHeader(apiKey) },
                body: JSON.stringify({ model: model || cfg.defaultModel, messages: payloadMessages, stream: true, temperature: 0.7, ...(providerKey === 'openai' ? { max_completion_tokens: 8192 } : { max_tokens: 8192 }) }),
                signal: controller.signal
            });
            if (!response.ok) {
                const errText = await response.text().catch(() => response.statusText);
                throw Object.assign(new Error(`${providerKey} ${response.status}: ${errText.slice(0, 500)}`), { status: response.status });
            }
            if (!response.body?.getReader) {
                const data = await response.json();
                const content = data.choices?.[0]?.message?.content || '';
                if (content) onChunk?.(content, content);
                return content;
            }
            const reader = response.body.getReader();
            const decoder = new TextDecoder('utf-8');
            let fullText = ''; let buffer = ''; this._lastFinishReason = null;
            const consume = (line) => {
                const trimmed = line.trim();
                if (!trimmed.startsWith('data:')) return;
                const dataStr = trimmed.slice(5).trim();
                if (!dataStr || dataStr === '[DONE]') return;
                try {
                    const parsed = JSON.parse(dataStr);
                    if (parsed.choices?.[0]?.finish_reason) this._lastFinishReason = parsed.choices[0].finish_reason;
                    const delta = parsed.choices?.[0]?.delta?.content ?? parsed.choices?.[0]?.message?.content ?? '';
                    const token = typeof delta === 'string' ? delta : Array.isArray(delta) ? delta.map(x => x.text || '').join('') : '';
                    if (token) { fullText += token; onChunk?.(token, fullText); }
                    if (parsed.error?.message) throw new Error(parsed.error.message);
                } catch (e) { if (e instanceof SyntaxError) return; throw e; }
            };
            while (true) {
                const { done, value } = await reader.read();
                if (done) break;
                buffer += decoder.decode(value, { stream: true });
                const lines = buffer.split(/\r?\n/);
                buffer = lines.pop() || '';
                lines.forEach(consume);
            }
            buffer += decoder.decode();
            if (buffer.trim()) consume(buffer);
            if (!fullText.trim()) throw new Error(`${providerKey} returned no text. Verify that the model supports chat completions.`);
            return fullText;
        } finally {
            this._controllers.delete(controller);
            if (this._controller === controller) this._controller = null;
        }
    },
    async fetchGemini(apiKey, messages, model, systemPrompt, onChunk) {
        const cfg = this.PROVIDERS.gemini;
        const useModel = model || cfg.defaultModel;
        const contents = messages.map((m) => {
            const parts = [{ text: String(m.text || '') }];
            if (m.sender === 'user' && Array.isArray(m.images)) {
                m.images.forEach(dataUrl => {
                    const match = typeof dataUrl === 'string' && dataUrl.match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/);
                    if (match) parts.push({ inlineData: { mimeType: match[1], data: match[2] } });
                });
            }
            return { role: m.sender === 'user' ? 'user' : 'model', parts };
        });
        const body = {
            contents,
            systemInstruction: { parts: [{ text: systemPrompt || '' }] },
            generationConfig: { temperature: 0.7, maxOutputTokens: 8192 }
        };
        const controller = new AbortController();
        this._controllers.add(controller);
        this._controller = controller;
        try {
            let response;
            for (let attempt = 0; attempt < 3; attempt++) {
                response = await fetch(cfg.endpoint(useModel, apiKey), {
                    method: 'POST', headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(body), signal: controller.signal
                });
                if (response.ok) break;
                const retryable = [429, 500, 502, 503, 504].includes(response.status);
                if (!retryable || attempt === 2) {
                    const errText = await response.text().catch(() => response.statusText);
                    throw Object.assign(new Error(`Gemini ${response.status}: ${errText.slice(0, 500)}`), { status: response.status });
                }
                // Gemini capacity errors are often temporary; retry briefly before provider fallback.
                await new Promise(resolve => setTimeout(resolve, 700 * (attempt + 1)));
            }
            const reader = response.body?.getReader?.();
            if (!reader) {
                const data = await response.json();
                const content = data.candidates?.[0]?.content?.parts?.map(p => p.text || '').join('') || '';
                if (content) onChunk?.(content, content);
                return content;
            }
            const decoder = new TextDecoder('utf-8');
            let fullText = ''; let buffer = ''; this._lastFinishReason = null;
            const consume = (line) => {
                const trimmed = line.trim();
                if (!trimmed.startsWith('data:')) return;
                const dataStr = trimmed.slice(5).trim();
                if (!dataStr || dataStr === '[DONE]') return;
                const parsed = JSON.parse(dataStr);
                if (parsed.candidates?.[0]?.finishReason) this._lastFinishReason = parsed.candidates[0].finishReason;
                const token = parsed.candidates?.[0]?.content?.parts?.map(p => p.text || '').join('') || '';
                if (token) { fullText += token; onChunk?.(token, fullText); }
                const blockReason = parsed.promptFeedback?.blockReason;
                if (blockReason) throw new Error(`Gemini blocked this request: ${blockReason}`);
            };
            while (true) {
                const { done, value } = await reader.read();
                if (done) break;
                buffer += decoder.decode(value, { stream: true });
                const lines = buffer.split(/\r?\n/);
                buffer = lines.pop() || '';
                for (const line of lines) { try { consume(line); } catch (e) { if (!(e instanceof SyntaxError)) throw e; } }
            }
            buffer += decoder.decode();
            if (buffer.trim()) { try { consume(buffer); } catch (e) { if (!(e instanceof SyntaxError)) throw e; } }
            if (!fullText.trim()) throw new Error('Gemini returned no text. Check model availability and API key permissions.');
            return fullText;
        } finally {
            this._controllers.delete(controller);
            if (this._controller === controller) this._controller = null;
        }
    },
    async fetchCompleteWithContinuation(fetcher, messages, systemPrompt, onChunk) {
        let complete = await fetcher(messages, systemPrompt, (chunk, partial) => onChunk?.(chunk, partial));
        for (let attempt = 0; attempt < 2 && ['length', 'MAX_TOKENS', 'max_tokens'].includes(this._lastFinishReason); attempt++) {
            const prefix = complete;
            const continuationMessages = [
                ...messages,
                { sender: 'assistant', text: complete },
                { sender: 'user', text: 'Continue exactly where the previous response stopped. Do not repeat earlier content. Finish every code block and every file completely. If the previous response was code, continue the same file without restarting.' }
            ];
            const more = await fetcher(continuationMessages, systemPrompt, (chunk, partial) => onChunk?.(chunk, prefix + partial));
            if (!more.trim()) break;
            complete += more;
        }
        return complete;
    },

    async generateForProvider(provider, model, messages, systemPrompt, onChunk) {
        const settings = await Storage.getSettings();
        const key = String(settings.providerKeys?.[provider] || (settings.provider === provider ? settings.apiKey : '') || '').trim();
        if (!key) throw new Error(`No API key configured for ${provider}. Add it in Settings.`);
        if (!this.PROVIDERS[provider]) throw new Error(`Unsupported provider: ${provider}`);
        const chosenModel = model || settings.providerModels?.[provider] || this.PROVIDERS[provider]?.defaultModel;
        const result = provider === 'gemini'
            ? await this.fetchGemini(key, messages, chosenModel, systemPrompt, onChunk)
            : await this.fetchOpenAICompatible(provider, key, messages, chosenModel, systemPrompt, onChunk);
        this.lastUsedProvider = provider;
        this.lastUsedModel = chosenModel;
        return result;
    },
    async autoFixCode(code, errorText, language, provider, apiKey, model) {
        const settings = await Storage.getSettings();
        const selected = provider === 'auto' || provider === 'simulated' || !provider ? (settings.provider === 'auto' ? 'auto' : settings.provider) : provider;
        const source = String(code || '');
        if (!source.trim()) throw new Error('The active file is empty.');
        if (source.length > 60000) throw new Error('This file is over 60,000 characters. Split it into smaller files before using AI Auto-Fix so no code is silently omitted.');
        const prompt = `You are a senior ${language || 'software'} engineer performing a precise code repair.
TASK: Fix the reported error while preserving ALL existing features, behavior, UI, functions, imports, comments, and project conventions unless a change is essential to fix the error.
OUTPUT RULES:
1. Return the ENTIRE corrected file from the first character to the last character, not a patch, snippet, diff, or explanation.
2. Return exactly one fenced code block tagged ${language || 'text'}.
3. Never use placeholders such as "...", "rest of code", "same as before", or omit unchanged sections.
4. Do not invent external APIs. If the reported error is caused by an unavailable third-party service, fix the integration safely and explain that limitation only if no code-only repair is possible.
5. Check syntax, matching brackets, function boundaries, imports, and that the file ends cleanly before responding.

ERROR:
${String(errorText || '').slice(0, 5000)}

COMPLETE ORIGINAL SOURCE (${source.length} characters):
\`\`\`${language || ''}
${source}
\`\`\`
`;
        const messages = [{ sender: 'user', text: prompt }];
        let answer;
        if (selected === 'simulated' || !selected) throw new Error('IDE Auto-Fix needs a configured AI API. Select a provider with an API key or Smart Auto in Settings.');
        if (selected === 'auto') {
            answer = await this.generateAutoResponse(messages, 'Return the complete corrected source file only.', false, null, settings, prompt);
        } else {
            try {
                answer = await this.generateForProvider(selected, model || settings.providerModels?.[selected], messages, 'Return the complete corrected source file only.', null);
            } catch (err) {
                const transient = [408, 429, 500, 502, 503, 504].includes(Number(err.status)) || /temporar|high demand|unavailable|network|fetch failed/i.test(String(err.message || ''));
                if (!transient) throw err;
                answer = await this.generateAutoResponse(messages, 'Return the complete corrected source file only.', false, null, settings, prompt);
            }
        }
        const raw = String(answer || '').trim();
        const fences = [...raw.matchAll(/```(?:[\w+#.-]+)?\s*([\s\S]*?)```/g)];
        let fixed = fences.length ? fences[0][1].trim() : raw;
        fixed = fixed.replace(/^<file_action[^>]*>\s*/i, '').trim();
        if (!fixed || /(?:rest of (?:the )?code|same as above|\.\.\.)/i.test(fixed)) throw new Error('AI returned an incomplete file. Original code was not changed. Try Auto-Fix again or use another model.');
        if (!fences.length && /^(here(?:'s| is)|corrected code|explanation|the fix)/i.test(fixed)) throw new Error('AI did not return a code-only file. Original code was not changed.');
        if (source.length > 300 && fixed.length < Math.min(300, source.length * 0.35)) throw new Error('AI response looks truncated or incomplete. Original code was not changed.');
        return fixed;
    },
    async listModels(providerKey, apiKey) {
        const cfg = this.PROVIDERS[providerKey];
        if (!cfg) throw new Error(`Unknown: ${providerKey}`);
        if (providerKey === 'gemini') {
            const res = await fetch(cfg.modelsEndpoint(apiKey));
            if (!res.ok) throw new Error(`Gemini ${res.status}`);
            const data = await res.json();
            return (data.models || [])
                .filter((m) => (m.supportedGenerationMethods || []).includes('generateContent'))
                .map((m) => m.name.replace(/^models\//, ''));
        }
        const res = await fetch(cfg.modelsEndpoint, { headers: cfg.authHeader(apiKey) });
        if (!res.ok) throw new Error(`${providerKey} ${res.status}`);
        const data = await res.json();
        const list = data.data || data.models || [];
        return list.map((m) => m.id || m.name).filter(Boolean).sort();
    },
    async generateSimulatedResponse(messages, model, systemPrompt, webSearchActive, onChunk, speed = 1.0) {
        const lastUserMsg = [...messages].reverse().find((m) => m.sender === 'user')?.text || '';
        const lower = lastUserMsg.toLowerCase();
        const prefix = webSearchActive
            ? `*🌐 Searched: "${Utils.escapeHtml(lastUserMsg.slice(0, 40))}..."*\n\n` : '';
        let responseMarkdown = '';

        if (/\b(quiz|test)\b/i.test(lower) && systemPrompt && /respond ONLY with valid JSON/i.test(systemPrompt)) {
            const quizObj = {
                quiz: [
                    { q: "If 3x - 7 = 2x + 9, what is the value of x?", options: ["-16", "9", "16", "2"], answer: "16" },
                    { q: "What is the capital of France?", options: ["London", "Berlin", "Paris", "Madrid"], answer: "Paris" },
                    { q: "Which planet is known as the Red Planet?", options: ["Venus", "Mars", "Jupiter", "Saturn"], answer: "Mars" },
                    { q: "What does HTML stand for?", options: ["HyperText Markup Language", "HighText Machine Language", "HyperTool Markup Language", "Hyperlinks and Text Markup Language"], answer: "HyperText Markup Language" },
                    { q: "Which of these is NOT a JavaScript data type?", options: ["String", "Number", "Boolean", "Character"], answer: "Character" }
                ]
            };
            const quizJson = JSON.stringify(quizObj, null, 2);
            let currentQuiz = '';
            const qWords = quizJson.split(/(\s+)/);
            const baseDelay = Math.max(2, 20 / speed);
            for (const word of qWords) {
                currentQuiz += word;
                onChunk?.(word, currentQuiz);
                await new Promise((r) => setTimeout(r, Math.random() * baseDelay + baseDelay / 2));
            }
            return currentQuiz;
        }

        if (/(quiz|test|sawal|pooch|question)/i.test(lower)) {
            const quizHtml = `
Chalo! 🔥 Diagnostic Quiz shuru karte hain. Target: 100% Score! 🎯

Pehle apni current level check karo. Har question ko khud solve karna.

<div class="quiz-card" id="quiz-card-1">
    <div class="quiz-header">
        <span class="nav"><i class="fa-solid fa-chevron-left"></i></span>
        <span>1 of 10</span>
        <div class="flex gap-4">
            <span class="nav"><i class="fa-regular fa-lightbulb"></i></span>
            <span class="nav"><i class="fa-regular fa-copy"></i></span>
        </div>
    </div>
    <div class="quiz-question">
        If 3x - 7 = 2x + 9, what is the value of x?
    </div>
    <div class="quiz-options">
        <div class="quiz-opt" onclick="window.selectQuizOption(this, 'A')"><div class="circle">A</div> -16</div>
        <div class="quiz-opt" onclick="window.selectQuizOption(this, 'B')"><div class="circle">B</div> 9</div>
        <div class="quiz-opt" onclick="window.selectQuizOption(this, 'C')"><div class="circle">C</div> 16</div>
        <div class="quiz-opt" onclick="window.selectQuizOption(this, 'D')"><div class="circle">D</div> 2</div>
    </div>
    <div class="quiz-footer">
        <button class="quiz-next-btn" onclick="window.submitQuiz(this)">Next</button>
    </div>
</div>

*Tip: Sahi jawab C (16) hai. (3x - 2x = 9 + 7)*
`;
            let currentQuiz = '';
            const qWords = quizHtml.split(/(\s+)/);
            const baseDelay = Math.max(2, 20 / speed);
            for (const word of qWords) {
                currentQuiz += word;
                onChunk?.(word, currentQuiz);
                await new Promise((r) => setTimeout(r, Math.random() * baseDelay + baseDelay / 2));
            }
            return currentQuiz;
        }

        if (/\b(code|function|javascript|python|html|react|api|css|website|site|calculator)\b/.test(lower)) {
            responseMarkdown = `<thought>
User wants a working code/website. I should create an HTML file and write the structure.
Let's simulate the file creation process.
</thought>
<file_action status="creating" filename="index.html">
Here's a production-ready implementation:

\`\`\`javascript
async function processDataPipeline(items, { concurrency = 5 } = {}) {
  if (!Array.isArray(items)) throw new TypeError('items must be an array');
  const results = [];
  for (let i = 0; i < items.length; i += concurrency) {
    const batch = items.slice(i, i + concurrency);
    const out = await Promise.all(batch.map(async (item) => ({
      id: item?.id ?? crypto.randomUUID(),
      status: 'completed',
      timestamp: new Date().toISOString()
    })));
    results.push(...out);
  }
  return results;
}

processDataPipeline([{ id: 101 }, { id: 102 }])
  .then(console.log)
  .catch(console.error);
\`\`\`

### Key Highlights
1. **Bounded concurrency** — protects APIs
2. **Input validation** — early failure
3. **Deterministic output**`;
        } else if (/\b(quantum|explain|what is|how to|define)\b/.test(lower)) {
            responseMarkdown = `<thought>
User is asking for an explanation. I will break it down into simple points.
</thought>
${prefix}### Explanation

**Classical bits** are 0 or 1. **Qubits** can be *superposition* of both.

| Concept | Meaning |
|---|---|
| Superposition | 0, 1, or both |
| Entanglement | Correlated qubits |
| Interference | Amplifies correct answers |

> **Analogy:** Classical = sequential pages. Quantum = all at once.`;
        } else if (/^(hi|hello|hey|salam|assalam)/.test(lower)) {
            responseMarkdown = `Hello! 👋 Ready to help.

Try:
- **Write code**
- **Explain concepts**
- **Draft text**
- **Take a Quiz** (Type: "Mera quiz lo")

What would you like?`;
        } else {
            responseMarkdown = `<thought>
User is asking a general question. I'll provide a structured response.
</thought>
${prefix}I understand you're asking about **"${Utils.escapeHtml(lastUserMsg.slice(0, 60))}"**.

Structured take:

1. **Context** — clarify your key constraint
2. **Options** — 2-3 valid approaches with tradeoffs
3. **Recommendation** — pick based on your needs

Want me to expand?`;
        }

        let currentText = '';
        const words = responseMarkdown.split(/(\s+)/);
        const baseDelay = Math.max(2, 20 / speed);
        for (const word of words) {
            currentText += word;
            onChunk?.(word, currentText);
            await new Promise((r) => setTimeout(r, Math.random() * baseDelay + baseDelay / 2));
        }
        return currentText;
    }
};
// Expose the engine for IDE auto-fix and other integrated modules.
window.AIEngine = AIEngine;
