package com.clickeruniverse.app

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    private lateinit var web: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        setContentView(web)

        val prefs = getSharedPreferences("clicker_universe", MODE_PRIVATE)
        val role = prefs.getString("role", null)
        if (role == null) {
            AlertDialog.Builder(this)
                .setTitle("Benvenuto in Clicker Universe!")
                .setMessage("Scegli la versione da usare su questo telefono.")
                .setCancelable(false)
                .setPositiveButton("Owner 👑") { _, _ ->
                    prefs.edit().putString("role", "owner").apply()
                    loadGame("owner.html")
                }
                .setNegativeButton("Fratello 🎮") { _, _ ->
                    prefs.edit().putString("role", "brother").apply()
                    loadGame("brother.html")
                }
                .show()
        } else {
            loadGame(if (role == "owner") "owner.html" else "brother.html")
        }
    }

    private fun loadGame(file: String) {
        web.loadUrl("file:///android_asset/$file")
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
