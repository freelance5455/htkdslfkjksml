plugins { id("com.android.application") }

android {
    namespace = "com.clickeruniverse.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.clickeruniverse.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
