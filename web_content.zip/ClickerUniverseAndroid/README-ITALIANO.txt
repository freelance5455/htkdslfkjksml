CLICKER UNIVERSE - PROGETTO APK

Questo progetto contiene i due giochi HTML originali dentro una semplice app Android.
Al primo avvio l'app chiede quale versione usare su QUEL telefono:
- Owner: apre owner.html con il pannello admin
- Fratello: apre brother.html senza pannello admin visibile

COME OTTENERE L'APK USANDO SOLO IL TELEFONO
1. Apri GitHub nel browser e accedi/crea un account.
2. Crea un nuovo repository, per esempio "clicker-universe-app".
3. Carica tutti i file e le cartelle contenuti in questo progetto (non caricare la cartella esterna ClickerUniverseAndroid come singolo file).
4. Apri la scheda Actions del repository.
5. Se GitHub chiede di abilitare Actions, abilitalo.
6. Seleziona "Build Clicker Universe APK" e premi "Run workflow".
7. Quando termina, apri l'esecuzione completata e scarica l'artifact "ClickerUniverse-debug-APK".
8. Estrai lo ZIP dell'artifact: dentro trovi app-debug.apk. Aprilo su Android e installalo.
9. Installa lo stesso APK anche sul telefono di tuo fratello; al primo avvio scegli Owner sul tuo e Fratello sul suo.

IMPORTANTE
- Questo e' un APK di debug per test personali, non una release firmata per il Play Store.
- La scelta Owner/Fratello e' salvata localmente sul dispositivo. Reinstallando o cancellando i dati dell'app potrebbe essere richiesto di scegliere di nuovo.
- Il trasferimento di regali in tempo reale tra telefoni NON e' ancora implementato: richiede un backend online e regole di accesso sicure. Le due copie attuali continuano a usare i salvataggi locali del gioco.
- Non condividere credenziali GitHub o password con nessuno.
