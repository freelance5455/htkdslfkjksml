CLICKER UNIVERSE - BUILD DAL TELEFONO SENZA GITHUB

1) Scarica e installa Code on the Go dal sito ufficiale:
   https://appdevforall.org/code-on-the-go/
2) Scarica questo ZIP e usa Gestione File del Redmi per estrarlo.
3) In Code on the Go scegli Open existing project.
4) Seleziona la cartella ClickerUniverseAndroid estratta (quella che contiene settings.gradle.kts).
5) Attendi la sincronizzazione Gradle. La prima volta può richiedere tempo e parecchio spazio.
6) Usa Build / Quick Run per compilare l'app. Se la compilazione riesce, esporta l'APK dalla sezione Export dell'app.
7) Installa l'APK sul Redmi e sul Samsung. Al primo avvio scegli Owner sul Redmi e Fratello sul Samsung.

NOTA: il progetto incorpora le due versioni HTML in un'app Android WebView. La sincronizzazione dei regali tra telefoni NON è implementata in questo progetto: serve un backend online separato. Il pannello admin della versione Owner è una funzione locale di gioco, non un sistema sicuro per un servizio pubblico.

Se Code on the Go segnala un errore Gradle, manda uno screenshot dell'errore per correggere il progetto.
