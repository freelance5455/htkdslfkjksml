document.addEventListener("DOMContentLoaded", () => {

    /* =====================================================
       العناصر
    ===================================================== */

    const canvas =
        document.getElementById("gameCanvas");

    if (!canvas) return;

    const ctx =
        canvas.getContext("2d");

    if (!ctx) return;

    const $ = id =>
        document.getElementById(id);

    const startScreen =
        $("start-screen");

    const gameOverScreen =
        $("gameover-screen");

    const victoryScreen =
        $("victory-screen");

    const settingsPanel =
        $("settings-panel");

    const startBtn =
        $("start-btn");

    const settingsBtn =
        $("settings-btn");

    const closeSettings =
        $("close-settings");

    const restartBtn =
        $("restart-btn");

    const outBtn =
        $("out-btn");

    const victoryBtn =
        $("victory-btn");

    const victoryOutBtn =
        $("victory-out-btn");

    const pauseBtn =
        $("pause-btn");

    const scoreElement =
        $("score");

    const scoreDisplay =
        $("score-display");

    const finalScoreElement =
        $("final-score");

    const highScoreElement =
        $("high-score");

    const biomeNameElement =
        $("biome-name");

    const volumeSlider =
        $("music-volume");

    const volumeValue =
        $("volume-value");


    /* =====================================================
       المتغيرات
    ===================================================== */

    let animationId = null;

    let gameActive = false;

    let paused = false;

    let score = 0;

    let frame = 0;

    let floorY = 0;

    let gameSpeed = 5.5;

    const gravity = 0.65;

    let obstacles = [];

    let particles = [];

    let effects = [];

    let speedPads = [];

    let currentBiome = 0;

    let nextSpeedPad = 100;

    let speedBoost = false;

    let speedBoostTimer = 0;

    let lastInput = 0;

    let gameOverSoundPlayed = false;


    /* =====================================================
       البيئات
    ===================================================== */

    const biomes = [

        {
            name: "كوكب الغابات النيونية",
            sky: "#020907",
            floor: "#071c12",
            accent: "#39ff14",
            obstacle: "#00ffcc"
        },

        {
            name: "أراضي الحمم البركانية",
            sky: "#130404",
            floor: "#2b0808",
            accent: "#ff3300",
            obstacle: "#ffcc00"
        },

        {
            name: "المدينة السيبرانية المتجمدة",
            sky: "#020b13",
            floor: "#071a2a",
            accent: "#00e5ff",
            obstacle: "#ffffff"
        },

        {
            name: "وادي البلورات البنفسجية",
            sky: "#09020f",
            floor: "#190628",
            accent: "#bd00ff",
            obstacle: "#ff00ff"
        }

    ];


    /* =====================================================
       الصوت
    ===================================================== */

    let audioContext = null;

    let musicGain = null;

    let musicStarted = false;

    let musicTimer = null;


    let musicVolume =
        Number(
            localStorage.getItem(
                "onezero_music_volume"
            )
        );

    if (!Number.isFinite(musicVolume)) {
        musicVolume = 0.35;
    }


    volumeSlider.value =
        Math.round(musicVolume * 100);


    function updateVolumeText() {

        volumeValue.textContent =
            Math.round(
                musicVolume * 100
            ) + "%";
    }

    updateVolumeText();


    volumeSlider.addEventListener(
        "input",
        () => {

            musicVolume =
                Number(
                    volumeSlider.value
                ) / 100;

            localStorage.setItem(
                "onezero_music_volume",
                String(musicVolume)
            );

            updateVolumeText();

            if (musicGain) {

                musicGain.gain.value =
                    musicVolume * 0.10;
            }
        }
    );


    function initAudio() {

        if (!audioContext) {

            const AudioClass =
                window.AudioContext ||
                window.webkitAudioContext;

            if (!AudioClass) return;

            audioContext =
                new AudioClass();

            musicGain =
                audioContext.createGain();

            musicGain.gain.value =
                musicVolume * 0.10;

            musicGain.connect(
                audioContext.destination
            );
        }


        if (
            audioContext.state ===
            "suspended"
        ) {
            audioContext.resume();
        }


        startMusic();
    }


    function startMusic() {

        if (
            musicStarted ||
            !audioContext
        ) return;


        musicStarted = true;


        const notes = [
            146.83,
            220,
            164.81,
            246.94,
            196,
            293.66,
            220,
            329.63
        ];


        let noteIndex = 0;


        musicTimer =
            setInterval(() => {

                if (
                    !gameActive ||
                    paused
                ) return;


                const osc =
                    audioContext.createOscillator();

                const gain =
                    audioContext.createGain();

                const now =
                    audioContext.currentTime;


                osc.type = "triangle";

                osc.frequency.value =
                    notes[
                        noteIndex %
                        notes.length
                    ];


                gain.gain.setValueAtTime(
                    0,
                    now
                );

                gain.gain.linearRampToValueAtTime(
                    0.16,
                    now + 0.04
                );

                gain.gain.exponentialRampToValueAtTime(
                    0.001,
                    now + 0.55
                );


                osc.connect(gain);

                gain.connect(musicGain);

                osc.start(now);

                osc.stop(now + 0.56);

                noteIndex++;

            }, 420);
    }


    function playSound(type) {

        if (!audioContext) return;


        const now =
            audioContext.currentTime;

        const osc =
            audioContext.createOscillator();

        const gain =
            audioContext.createGain();


        osc.connect(gain);

        gain.connect(
            audioContext.destination
        );


        if (type === "jump") {

            osc.type = "sine";

            osc.frequency.setValueAtTime(
                180,
                now
            );

            osc.frequency.exponentialRampToValueAtTime(
                520,
                now + 0.16
            );

            gain.gain.setValueAtTime(
                0.12,
                now
            );

            gain.gain.exponentialRampToValueAtTime(
                0.001,
                now + 0.18
            );

            osc.start(now);

            osc.stop(now + 0.18);
        }


        if (type === "speed") {

            osc.type = "sine";

            osc.frequency.setValueAtTime(
                250,
                now
            );

            osc.frequency.exponentialRampToValueAtTime(
                800,
                now + 0.25
            );

            gain.gain.setValueAtTime(
                0.12,
                now
            );

            gain.gain.exponentialRampToValueAtTime(
                0.001,
                now + 0.27
            );

            osc.start(now);

            osc.stop(now + 0.27);
        }


        if (type === "gameover") {

            osc.type = "sawtooth";

            osc.frequency.setValueAtTime(
                180,
                now
            );

            osc.frequency.exponentialRampToValueAtTime(
                45,
                now + 0.55
            );

            gain.gain.setValueAtTime(
                0.16,
                now
            );

            gain.gain.exponentialRampToValueAtTime(
                0.001,
                now + 0.55
            );

            osc.start(now);

            osc.stop(now + 0.55);
        }
    }


    /* =====================================================
       تغيير حجم Canvas
    ===================================================== */

    function resizeCanvas() {

        canvas.width =
            window.innerWidth;

        canvas.height =
            window.innerHeight;

        floorY =
            canvas.height * 0.75;

        if (player && !player.isJumping) {

            player.y =
                floorY -
                player.height;
        }
    }

    window.addEventListener(
        "resize",
        resizeCanvas
    );


    /* =====================================================
       الجزيئات
    ===================================================== */

    class Particle {

        constructor(
            x,
            y,
            color,
            force = 1,
            size = 2,
            gravityValue = 0.06
        ) {

            this.x = x;

            this.y = y;

            this.size = size;

            this.speedX =
                (
                    Math.random() - .5
                ) * 4 * force;

            this.speedY =
                (
                    Math.random() - .5
                ) * 4 * force;

            this.gravity =
                gravityValue;

            this.life = 1;

            this.color = color;
        }


        update() {

            this.x += this.speedX;

            this.y += this.speedY;

            this.speedY += this.gravity;

            this.life -= .035;
        }


        draw() {

            if (this.life <= 0)
                return;


            ctx.save();

            ctx.globalAlpha =
                this.life;

            ctx.shadowBlur = 10;

            ctx.shadowColor =
                this.color;

            ctx.fillStyle =
                this.color;


            ctx.beginPath();

            ctx.arc(
                this.x,
                this.y,
                this.size,
                0,
                Math.PI * 2
            );

            ctx.fill();

            ctx.restore();
        }
    }


    function createParticles(
        x,
        y,
        color,
        amount = 8,
        force = 1,
        size = 2
    ) {

        for (
            let i = 0;
            i < amount;
            i++
        ) {

            particles.push(
                new Particle(
                    x,
                    y,
                    color,
                    force,
                    size
                )
            );
        }
    }


    /* =====================================================
       انفجار القنبلة
       قطرات حمراء وصفراء
    ===================================================== */

    function bombExplosion(
        x,
        y
    ) {

        for (
            let i = 0;
            i < 32;
            i++
        ) {

            const color =
                Math.random() < .5
                    ? "#ff2614"
                    : "#ffd21a";


            const p =
                new Particle(
                    x,
                    y,
                    color,
                    2.4,
                    Math.random() * 3 + 2,
                    0.08
                );


            /*
                قطرات/شرارات مائلة
            */

            p.speedX *= 1.4;

            p.speedY *= 1.15;

            particles.push(p);
        }


        effects.push({
            type: "bomb",
            x,
            y,
            life: 1,
            radius: 5
        });
    }


    /* =====================================================
       ذوبان اللاعب داخل الحمض
    ===================================================== */

    function acidMeltEffect(
        x,
        y
    ) {

        /*
            قطرات الحمض تصعد
            حول اللاعب
        */

        for (
            let i = 0;
            i < 30;
            i++
        ) {

            const p =
                new Particle(
                    x +
                    (
                        Math.random() - .5
                    ) * 30,

                    y +
                    (
                        Math.random() - .5
                    ) * 20,

                    Math.random() < .7
                        ? "#39ff14"
                        : "#00ff88",

                    1.3,

                    Math.random() * 4 + 1,

                    -0.035
                );


            particles.push(p);
        }


        effects.push({
            type: "acid",
            x,
            y,
            life: 1,
            radius: 5
        });
    }


    /* =====================================================
       تفتيت اللاعب عند الأشواك
    ===================================================== */

    function spikeBreakEffect(
        x,
        y
    ) {

        /*
            أجزاء اللاعب
        */

        const colors = [
            "#07130d",
            "#10251b",
            "#00e5ff",
            "#39ff14"
        ];


        for (
            let i = 0;
            i < 28;
            i++
        ) {

            const p =
                new Particle(
                    x +
                    (
                        Math.random() - .5
                    ) * 24,

                    y +
                    (
                        Math.random() - .5
                    ) * 24,

                    colors[
                        Math.floor(
                            Math.random() *
                            colors.length
                        )
                    ],

                    2,

                    Math.random() * 4 + 1,

                    0.10
                );


            particles.push(p);
        }


        effects.push({
            type: "spike",
            x,
            y,
            life: 1,
            radius: 3
        });
    }


    /* =====================================================
       رسم التأثيرات
    ===================================================== */

    function updateEffects() {

        for (
            let i = effects.length - 1;
            i >= 0;
            i--
        ) {

            const effect =
                effects[i];


            effect.life -= .045;


            if (effect.type === "bomb") {

                effect.radius += 5;

                ctx.save();

                ctx.globalAlpha =
                    effect.life;

                ctx.shadowBlur = 25;

                ctx.shadowColor =
                    "#ff9d00";

                ctx.strokeStyle =
                    "#ffd21a";

                ctx.lineWidth = 3;


                ctx.beginPath();

                ctx.arc(
                    effect.x,
                    effect.y,
                    effect.radius,
                    0,
                    Math.PI * 2
                );

                ctx.stroke();

                ctx.restore();
            }


            if (effect.type === "acid") {

                effect.radius += 3;

                ctx.save();

                ctx.globalAlpha =
                    effect.life * .7;

                ctx.shadowBlur = 22;

                ctx.shadowColor =
                    "#39ff14";

                ctx.strokeStyle =
                    "#39ff14";

                ctx.lineWidth = 4;


                ctx.beginPath();

                ctx.arc(
                    effect.x,
                    effect.y,
                    effect.radius,
                    0,
                    Math.PI * 2
                );

                ctx.stroke();

                ctx.restore();
            }


            if (effect.type === "spike") {

                effect.radius += 6;

                ctx.save();

                ctx.globalAlpha =
                    effect.life * .55;

                ctx.shadowBlur = 18;

                ctx.shadowColor =
                    "#39ff14";

                ctx.strokeStyle =
                    "#ffffff";

                ctx.lineWidth = 2;


                ctx.beginPath();

                ctx.arc(
                    effect.x,
                    effect.y,
                    effect.radius,
                    0,
                    Math.PI * 2
                );

                ctx.stroke();

                ctx.restore();
            }


            if (effect.life <= 0) {

                effects.splice(
                    i,
                    1
                );
            }
        }
    }


    /* =====================================================
       اللاعب
    ===================================================== */

    const player = {

        x: 80,

        y: 0,

        width: 42,

        height: 42,

        velocityY: 0,

        isJumping: false,

        rotation: 0,

        rotationSpeed: 0,

        pulse: 0,

        blinkTimer: 120,

        blinking: false,


        reset() {

            this.y =
                floorY -
                this.height;

            this.velocityY = 0;

            this.isJumping = false;

            this.rotation = 0;

            this.rotationSpeed = 0;

            this.pulse = 0;

            this.blinkTimer = 120;

            this.blinking = false;
        },


        jump() {

            if (
                !gameActive ||
                paused ||
                this.isJumping
            ) return;


            this.velocityY =
                -11.5;

            this.isJumping = true;

            this.rotationSpeed =
                Math.PI * 2.3;


            createParticles(
                this.x +
                this.width / 2,

                this.y +
                this.height,

                "#39ff14",

                12,
                .8,
                2
            );


            playSound("jump");
        },


        update() {

            if (paused) return;


            this.y +=
                this.velocityY;

            this.velocityY +=
                gravity;


            if (this.isJumping) {

                this.rotation +=
                    this.rotationSpeed *
                    .035;

                this.rotationSpeed *=
                    .985;
            }


            if (
                this.y +
                this.height >=
                floorY
            ) {

                if (this.isJumping) {

                    createParticles(
                        this.x +
                        this.width / 2,

                        floorY,

                        "#39ff14",

                        9,
                        .6,
                        2
                    );
                }


                this.y =
                    floorY -
                    this.height;

                this.velocityY = 0;

                this.isJumping = false;

                this.rotation = 0;

                this.rotationSpeed = 0;
            }


            this.pulse += .08;

            this.blinkTimer--;


            if (
                this.blinkTimer <= 0 &&
                !this.blinking
            ) {

                this.blinking = true;

                this.blinkTimer = 5;
            }


            if (this.blinking) {

                this.blinkTimer--;

                if (
                    this.blinkTimer <= 0
                ) {

                    this.blinking = false;

                    this.blinkTimer =
                        100 +
                        Math.random() * 140;
                }
            }
        },


        draw() {

            const cx =
                this.x +
                this.width / 2;

            const cy =
                this.y +
                this.height / 2;

            const pulse =
                Math.sin(
                    this.pulse
                ) * 2;

            const w =
                this.width;

            const h =
                this.height;


            ctx.save();

            ctx.translate(
                cx,
                cy
            );

            ctx.rotate(
                this.rotation
            );


            /* توهج اللاعب */

            ctx.shadowBlur =
                24 + pulse;

            ctx.shadowColor =
                "#39ff14";


            /* جسم اللاعب */

            ctx.fillStyle =
                "#07130d";

            ctx.strokeStyle =
                "#39ff14";

            ctx.lineWidth = 2.5;


            ctx.beginPath();

            ctx.roundRect(
                -w / 2,
                -h / 2,
                w,
                h,
                6
            );

            ctx.fill();

            ctx.stroke();

            ctx.closePath();


            /* الجسم الداخلي */

            ctx.shadowBlur = 12;

            ctx.shadowColor =
                "#00e5ff";

            ctx.fillStyle =
                "#10251b";


            ctx.beginPath();

            ctx.roundRect(
                -w / 2 + 3,
                -h / 2 + 3,
                w - 6,
                h - 6,
                4
            );

            ctx.fill();

            ctx.closePath();


            /* العيون */

            ctx.shadowBlur = 12;

            ctx.shadowColor =
                "#00e5ff";

            ctx.fillStyle =
                "#00e5ff";


            if (!this.blinking) {

                ctx.fillRect(
                    -12,
                    -10,
                    8,
                    8
                );

                ctx.fillRect(
                    4,
                    -10,
                    8,
                    8
                );


                ctx.shadowBlur = 4;

                ctx.fillStyle =
                    "#d9ffff";


                ctx.fillRect(
                    -11,
                    -9,
                    2,
                    2
                );

                ctx.fillRect(
                    5,
                    -9,
                    2,
                    2
                );

            } else {

                ctx.shadowBlur = 7;

                ctx.strokeStyle =
                    "#00e5ff";

                ctx.lineWidth = 2;


                ctx.beginPath();

                ctx.moveTo(
                    -12,
                    -6
                );

                ctx.lineTo(
                    -4,
                    -6
                );

                ctx.moveTo(
                    4,
                    -6
                );

                ctx.lineTo(
                    12,
                    -6
                );

                ctx.stroke();

                ctx.closePath();
            }


            /* الفم */

            ctx.shadowBlur = 10;

            ctx.shadowColor =
                "#00e5ff";

            ctx.fillStyle =
                "#00e5ff";

            ctx.fillRect(
                -14,
                5,
                28,
                6
            );

            ctx.fillStyle =
                "#06100c";

            ctx.fillRect(
                -11,
                7,
                22,
                2
            );


            /* الخط السفلي */

            ctx.shadowBlur = 8;

            ctx.strokeStyle =
                "#39ff14";

            ctx.lineWidth = 1;


            ctx.beginPath();

            ctx.moveTo(
                -10,
                15
            );

            ctx.lineTo(
                10,
                15
            );

            ctx.stroke();

            ctx.closePath();


            /* لمعان */

            ctx.globalAlpha = .45;

            ctx.shadowBlur = 8;

            ctx.shadowColor =
                "#ffffff";

            ctx.strokeStyle =
                "#ffffff";

            ctx.lineWidth = 1;


            ctx.beginPath();

            ctx.moveTo(
                -w / 2 + 6,
                -h / 2 + 3
            );

            ctx.lineTo(
                w / 2 - 9,
                -h / 2 + 3
            );

            ctx.stroke();

            ctx.restore();
        }
    };


    /* =====================================================
       العقبات
    ===================================================== */

    class Obstacle {

        constructor() {

            this.x =
                canvas.width + 60;

            this.passed = false;


            const types = [
                "spikes",
                "bomb",
                "acid"
            ];


            this.type =
                types[
                    Math.floor(
                        Math.random() *
                        types.length
                    )
                ];


            if (
                this.type === "spikes"
            ) {

                this.width = 54;

                this.height = 22;

                this.y =
                    floorY -
                    this.height;

            } else if (
                this.type === "bomb"
            ) {

                this.width = 30;

                this.height = 30;

                this.y =
                    floorY -
                    this.height;

            } else {

                this.width = 60;

                this.height =
                    canvas.height -
                    floorY;

                this.y = floorY;
            }
        }


        draw() {

            const biome =
                biomes[currentBiome];


            ctx.save();

            ctx.shadowBlur = 10;

            ctx.shadowColor =
                biome.obstacle;


            /* الأشواك */

            if (
                this.type === "spikes"
            ) {

                ctx.fillStyle =
                    biome.obstacle;


                const sw =
                    this.width / 3;


                for (
                    let i = 0;
                    i < 3;
                    i++
                ) {

                    const sx =
                        this.x +
                        i * sw;


                    ctx.beginPath();

                    ctx.moveTo(
                        sx,
                        floorY
                    );

                    ctx.lineTo(
                        sx + sw / 2,
                        this.y
                    );

                    ctx.lineTo(
                        sx + sw,
                        floorY
                    );

                    ctx.closePath();

                    ctx.fill();
                }
            }


            /* القنبلة */

            else if (
                this.type === "bomb"
            ) {

                const r =
                    this.width / 2;

                const cx =
                    this.x + r;

                const cy =
                    this.y + r;


                ctx.fillStyle =
                    "#111916";

                ctx.strokeStyle =
                    biome.obstacle;

                ctx.lineWidth = 2;


                ctx.beginPath();

                ctx.arc(
                    cx,
                    cy,
                    r,
                    0,
                    Math.PI * 2
                );

                ctx.fill();

                ctx.stroke();

                ctx.closePath();


                ctx.strokeStyle =
                    "#84958d";

                ctx.beginPath();

                ctx.moveTo(
                    cx,
                    this.y
                );

                ctx.lineTo(
                    cx + 4,
                    this.y - 7
                );

                ctx.stroke();


                ctx.fillStyle =
                    "#ffcc00";

                ctx.beginPath();

                ctx.arc(
                    cx + 4,
                    this.y - 9,
                    3,
                    0,
                    Math.PI * 2
                );

                ctx.fill();

                ctx.closePath();
            }


            /* الحمض */

            else {

                ctx.fillStyle =
                    "#03100a";

                ctx.fillRect(
                    this.x,
                    floorY,
                    this.width,
                    this.height
                );


                ctx.shadowBlur = 18;

                ctx.shadowColor =
                    "#39ff14";

                ctx.fillStyle =
                    "#39ff14";


                ctx.fillRect(
                    this.x + 2,
                    floorY + 2,
                    this.width - 4,
                    this.height
                );


                ctx.beginPath();

                ctx.moveTo(
                    this.x,
                    floorY + 3
                );

                ctx.lineTo(
                    this.x + 10,
                    floorY - 1
                );

                ctx.lineTo(
                    this.x + 20,
                    floorY + 3
                );

                ctx.lineTo(
                    this.x + 31,
                    floorY - 1
                );

                ctx.lineTo(
                    this.x + 43,
                    floorY + 3
                );

                ctx.lineTo(
                    this.x + this.width,
                    floorY - 1
                );

                ctx.lineTo(
                    this.x + this.width,
                    floorY + 8
                );

                ctx.lineTo(
                    this.x,
                    floorY + 8
                );

                ctx.closePath();

                ctx.fill();
            }


            ctx.restore();
        }
    }


    /* =====================================================
       منصة السرعة
    ===================================================== */

    class SpeedPad {

        constructor() {

            this.width = 45;

            this.height = 7;

            this.x =
                canvas.width + 50;

            this.y =
                floorY -
                this.height;

            this.triggered = false;
        }


        draw() {

            ctx.save();

            ctx.shadowBlur = 12;

            ctx.shadowColor =
                "#00e5ff";

            ctx.fillStyle =
                "#071c28";

            ctx.strokeStyle =
                "#00e5ff";

            ctx.lineWidth = 2;


            ctx.beginPath();

            ctx.roundRect(
                this.x,
                this.y,
                this.width,
                this.height,
                3
            );

            ctx.fill();

            ctx.stroke();

            ctx.restore();
        }
    }


    /* =====================================================
       الخلفية
    ===================================================== */

    function drawEnvironment() {

        const biome =
            biomes[currentBiome];


        ctx.fillStyle =
            biome.sky;

        ctx.fillRect(
            0,
            0,
            canvas.width,
            canvas.height
        );


        ctx.fillStyle =
            biome.floor;

        ctx.fillRect(
            0,
            floorY,
            canvas.width,
            canvas.height -
            floorY
        );


        ctx.save();

        ctx.shadowBlur = 15;

        ctx.shadowColor =
            biome.accent;

        ctx.strokeStyle =
            biome.accent;

        ctx.lineWidth = 4;


        ctx.beginPath();

        ctx.moveTo(
            0,
            floorY
        );

        ctx.lineTo(
            canvas.width,
            floorY
        );

        ctx.stroke();

        ctx.restore();
    }


    /* =====================================================
       التصادم
    ===================================================== */

    function checkCollision(
        obstacle
    ) {

        const playerLeft =
            player.x + 5;

        const playerRight =
            player.x +
            player.width - 5;

        const playerTop =
            player.y + 4;

        const playerBottom =
            player.y +
            player.height - 3;


        const obstacleLeft =
            obstacle.x;

        const obstacleRight =
            obstacle.x +
            obstacle.width;


        /* الحمض */

        if (
            obstacle.type === "acid"
        ) {

            const horizontalTouch =
                playerRight >
                obstacleLeft &&
                playerLeft <
                obstacleRight;


            const touchingAcid =
                playerBottom >=
                floorY - 6;


            return (
                horizontalTouch &&
                touchingAcid
            );
        }


        return (
            playerRight >
            obstacleLeft &&

            playerLeft <
            obstacleRight &&

            playerBottom >
            obstacle.y &&

            playerTop <
            obstacle.y +
            obstacle.height
        );
    }


    /* =====================================================
       تأثير الموت
    ===================================================== */

    function deathEffectFor(
        obstacle
    ) {

        const x =
            player.x +
            player.width / 2;

        const y =
            player.y +
            player.height / 2;


        if (
            obstacle.type === "bomb"
        ) {

            bombExplosion(
                x,
                y
            );

        } else if (
            obstacle.type === "acid"
        ) {

            acidMeltEffect(
                x,
                y
            );

        } else {

            spikeBreakEffect(
                x,
                y
            );
        }
    }


    /* =====================================================
       تحديث الجزيئات
    ===================================================== */

    function updateParticles() {

        for (
            let i =
                particles.length - 1;

            i >= 0;

            i--
        ) {

            particles[i].update();

            particles[i].draw();


            if (
                particles[i].life <= 0
            ) {

                particles.splice(
                    i,
                    1
                );
            }
        }
    }


    /* =====================================================
       زر التوقيف
    ===================================================== */

    function togglePause() {

        if (!gameActive)
            return;


        paused =
            !paused;


        pauseBtn.textContent =
            paused
                ? "استئناف"
                : "توقف";
    }


    /* =====================================================
       نهاية اللعبة
    ===================================================== */

    function gameOver(
        obstacle
    ) {

        if (!gameActive)
            return;


        gameActive = false;


        if (animationId) {

            cancelAnimationFrame(
                animationId
            );

            animationId = null;
        }


        /*
            تشغيل تأثير واحد فقط
        */

        deathEffectFor(
            obstacle
        );


        if (
            !gameOverSoundPlayed
        ) {

            gameOverSoundPlayed = true;

            playSound(
                "gameover"
            );
        }


        const oldHigh =
            Number(
                localStorage.getItem(
                    "onezero_highScore"
                )
            ) || 0;


        if (
            score > oldHigh
        ) {

            localStorage.setItem(
                "onezero_highScore",
                String(score)
            );
        }


        const high =
            Math.max(
                score,
                oldHigh
            );


        finalScoreElement.textContent =
            score;

        highScoreElement.textContent =
            high;


        /*
            إخفاء النتيجة من واجهة اللعبة
        */

        scoreDisplay.classList.add(
            "hidden"
        );

        pauseBtn.classList.add(
            "hidden"
        );

        biomeNameElement.classList.add(
            "hidden"
        );


        /*
            إظهار شاشة الخسارة
        */

        setTimeout(() => {

            gameOverScreen.classList.remove(
                "hidden"
            );

        }, 350);
    }


    /* =====================================================
       العودة للصفحة الرئيسية
    ===================================================== */

    function goHome() {

        gameActive = false;

        paused = false;


        if (animationId) {

            cancelAnimationFrame(
                animationId
            );

            animationId = null;
        }


        obstacles = [];

        particles = [];

        effects = [];

        speedPads = [];


        gameOverScreen.classList.add(
            "hidden"
        );

        victoryScreen.classList.add(
            "hidden"
        );


        scoreDisplay.classList.add(
            "hidden"
        );

        pauseBtn.classList.add(
            "hidden"
        );

        biomeNameElement.classList.add(
            "hidden"
        );


        startScreen.classList.remove(
            "hidden"
        );
    }


    /* =====================================================
       الفوز
    ===================================================== */

    function victory() {

        gameActive = false;


        if (animationId) {

            cancelAnimationFrame(
                animationId
            );

            animationId = null;
        }


        scoreDisplay.classList.add(
            "hidden"
        );

        pauseBtn.classList.add(
            "hidden"
        );

        biomeNameElement.classList.add(
            "hidden"
        );


        victoryScreen.classList.remove(
            "hidden"
        );
    }


    /* =====================================================
       بدء اللعبة
    ===================================================== */

    function startGame() {

        initAudio();


        if (animationId) {

            cancelAnimationFrame(
                animationId
            );
        }


        startScreen.classList.add(
            "hidden"
        );

        gameOverScreen.classList.add(
            "hidden"
        );

        victoryScreen.classList.add(
            "hidden"
        );


        scoreDisplay.classList.remove(
            "hidden"
        );

        pauseBtn.classList.remove(
            "hidden"
        );

        biomeNameElement.classList.remove(
            "hidden"
        );


        score = 0;

        frame = 0;

        gameSpeed = 5.5;

        obstacles = [];

        particles = [];

        effects = [];

        speedPads = [];

        currentBiome = 0;

        nextSpeedPad = 100;

        speedBoost = false;

        speedBoostTimer = 0;

        paused = false;

        gameActive = true;

        gameOverSoundPlayed = false;


        scoreElement.textContent =
            "0";


        biomeNameElement.textContent =
            biomes[0].name;


        pauseBtn.textContent =
            "توقف";


        resizeCanvas();

        player.reset();

        gameLoop();
    }


    /* =====================================================
       حلقة اللعبة
    ===================================================== */

    function gameLoop() {

        if (!gameActive)
            return;


        ctx.clearRect(
            0,
            0,
            canvas.width,
            canvas.height
        );


        drawEnvironment();

        updateEffects();

        updateParticles();

        player.update();

        player.draw();


        if (
            score >= 1000
        ) {

            victory();

            return;
        }


        if (!paused) {

            if (speedBoost) {

                gameSpeed =
                    5.5 +
                    score * .08 +
                    4.5;

                speedBoostTimer--;


                if (
                    speedBoostTimer <= 0
                ) {

                    speedBoost = false;
                }

            } else {

                gameSpeed =
                    5.5 +
                    score * .08;
            }


            const newBiome =
                Math.floor(
                    score / 7
                ) %
                biomes.length;


            if (
                newBiome !==
                currentBiome
            ) {

                currentBiome =
                    newBiome;

                biomeNameElement.textContent =
                    biomes[
                        currentBiome
                    ].name;
            }


            if (
                score >=
                nextSpeedPad &&
                speedPads.length === 0
            ) {

                speedPads.push(
                    new SpeedPad()
                );

                nextSpeedPad += 100;
            }


            const obstacleDelay =
                Math.max(
                    62,
                    Math.floor(
                        130 -
                        gameSpeed * 3
                    )
                );


            if (
                frame %
                obstacleDelay ===
                0
            ) {

                obstacles.push(
                    new Obstacle()
                );
            }
        }


        /* منصات السرعة */

        for (
            let i =
                speedPads.length - 1;

            i >= 0;

            i--
        ) {

            const pad =
                speedPads[i];


            if (!paused) {

                pad.x -=
                    gameSpeed;
            }


            pad.draw();


            if (
                player.x +
                player.width >
                pad.x &&

                player.x <
                pad.x +
                pad.width &&

                player.y +
                player.height >=
                pad.y &&

                !pad.triggered
            ) {

                pad.triggered = true;

                speedBoost = true;

                speedBoostTimer = 90;

                playSound("speed");


                createParticles(
                    pad.x + 20,
                    floorY,
                    "#00e5ff",
                    12,
                    .8,
                    2
                );
            }


            if (
                pad.x +
                pad.width <
                0
            ) {

                speedPads.splice(
                    i,
                    1
                );
            }
        }


        /* العقبات */

        for (
            let i =
                obstacles.length - 1;

            i >= 0;

            i--
        ) {

            const obstacle =
                obstacles[i];


            if (!paused) {

                obstacle.x -=
                    gameSpeed;
            }


            obstacle.draw();


            /*
                اصطدام اللاعب
            */

            if (
                checkCollision(
                    obstacle
                )
            ) {

                /*
                    نحذف العقبة فورًا
                    لمنع تكرار التأثير
                */

                obstacles.splice(
                    i,
                    1
                );


                gameOver(
                    obstacle
                );

                return;
            }


            /*
                احتساب النقاط
            */

            if (
                obstacle.x +
                obstacle.width <
                player.x &&

                !obstacle.passed &&

                !paused
            ) {

                score++;

                obstacle.passed = true;

                scoreElement.textContent =
                    score;
            }


            if (
                obstacle.x +
                obstacle.width <
                0
            ) {

                obstacles.splice(
                    i,
                    1
                );
            }
        }


        if (!paused) {

            frame++;
        }


        animationId =
            requestAnimationFrame(
                gameLoop
            );
    }


    /* =====================================================
       منع تكرار الإدخال
    ===================================================== */

    function canInput() {

        const now =
            performance.now();


        if (
            now - lastInput <
            120
        ) {

            return false;
        }


        lastInput = now;

        return true;
    }


    /* =====================================================
       اللمس
    ===================================================== */

    canvas.addEventListener(
        "pointerdown",
        () => {

            if (!canInput())
                return;

            initAudio();

            player.jump();
        },
        {
            passive: true
        }
    );


    /* =====================================================
       لوحة المفاتيح
    ===================================================== */

    document.addEventListener(
        "keydown",
        event => {

            if (
                event.code === "Space" ||
                event.code === "ArrowUp"
            ) {

                event.preventDefault();


                if (!canInput())
                    return;


                initAudio();

                player.jump();
            }


            if (
                event.code === "KeyP"
            ) {

                if (!canInput())
                    return;


                togglePause();
            }
        }
    );


    /* =====================================================
       زر ابدأ
    ===================================================== */

    startBtn.addEventListener(
        "click",
        () => {

            if (!canInput())
                return;

            startGame();
        }
    );


    /* =====================================================
       زر إعادة المحاولة
    ===================================================== */

    restartBtn.addEventListener(
        "click",
        () => {

            if (!canInput())
                return;

            startGame();
        }
    );


    /* =====================================================
       زر Out بعد الخسارة
    ===================================================== */

    outBtn.addEventListener(
        "click",
        () => {

            if (!canInput())
                return;

            goHome();
        }
    );


    /* =====================================================
       زر Out بعد الفوز
    ===================================================== */

    victoryOutBtn.addEventListener(
        "click",
        () => {

            if (!canInput())
                return;

            goHome();
        }
    );


    /* =====================================================
       زر الفوز
    ===================================================== */

    victoryBtn.addEventListener(
        "click",
        () => {

            if (!canInput())
                return;

            startGame();
        }
    );


    /* =====================================================
       زر الإعدادات
    ===================================================== */

    settingsBtn.addEventListener(
        "click",
        event => {

            event.stopPropagation();

            settingsPanel.classList.remove(
                "hidden"
            );
        }
    );


    closeSettings.addEventListener(
        "click",
        () => {

            settingsPanel.classList.add(
                "hidden"
            );
        }
    );


    settingsPanel.addEventListener(
        "click",
        event => {

            if (
                event.target ===
                settingsPanel
            ) {

                settingsPanel.classList.add(
                    "hidden"
                );
            }
        }
    );


    /* =====================================================
       زر التوقف
    ===================================================== */

    pauseBtn.addEventListener(
        "click",
        () => {

            if (!canInput())
                return;

            initAudio();

            togglePause();
        }
    );


    /* =====================================================
       منع القائمة
    ===================================================== */

    canvas.addEventListener(
        "contextmenu",
        event => {
            event.preventDefault();
        }
    );


    /* =====================================================
       البداية
    ===================================================== */

    resizeCanvas();

    player.reset();

    scoreDisplay.classList.add(
        "hidden"
    );

    pauseBtn.classList.add(
        "hidden"
    );

    biomeNameElement.classList.add(
        "hidden"
    );

});