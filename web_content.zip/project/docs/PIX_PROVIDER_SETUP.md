# VT ACCESS — integração PIX (configuração obrigatória)

O código adiciona pedidos no backend e uma interface de adaptador para o provedor. **Nenhum provedor real foi escolhido ou conectado neste pacote.** Não use em produção até adaptar o contrato abaixo ao provedor contratado e testar em sandbox.

## Secrets das Edge Functions

Configure no Supabase (não no `.env` do Vite e nunca no APK):

- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `PIX_PROVIDER_API_URL`: endpoint de criação de cobrança do adaptador do provedor.
- `PIX_PROVIDER_API_TOKEN`: token privado do provedor.
- `PIX_WEBHOOK_HMAC_SECRET`: segredo compartilhado para o formato de assinatura adotado pelo adaptador.
- `LICENSE_DELIVERY_ENCRYPTION_SECRET`: segredo aleatório forte usado para criptografar KEYs pendentes de entrega.

## Contrato do adaptador

`create-pix-order` envia `{ reference_id, amount_cents, currency, description }` e espera `{ payment_id, copy_paste, checkout_url? }`. O adaptador precisa traduzir isso para a API oficial do provedor. Não passe a URL genérica diretamente se a API real tiver outro formato.

O webhook normalizado precisa enviar JSON com `event_id`, `order_id`, `status`, `amount_cents`, `currency` e, quando aplicável, `provider_payment_id`; assinatura no cabeçalho `x-vt-signature: sha256=<HMAC-SHA256 do corpo HTTP bruto>`. A verificação precisa ser mapeada para a assinatura oficial do provedor antes de habilitar produção. Eventos duplicados são rejeitados por chave única. O servidor confere valor e moeda antes de emitir uma licença.

A KEY é guardada somente criptografada na tabela privada `license_deliveries` e deve ser recuperada pelo usuário autenticado via `claim-license`. Nunca devolva KEY ao provedor de pagamento.

## Publicação

1. Aplicar migrations na ordem.
2. Configurar secrets.
3. Implementar/testar o adaptador específico do provedor em sandbox.
4. Publicar `create-pix-order`, `pix-webhook` e `claim-license`.
5. Registrar a URL de `pix-webhook` no painel do provedor e validar assinaturas reais.
6. Fazer testes de valor divergente, assinatura inválida, webhook repetido, pagamento cancelado e corrida de eventos.
