# VT OPTIMIZER — segundo aplicativo Android

`android-vt-optimizer/` é um projeto Gradle Android independente, com `applicationId` e namespace `com.vtstudio.optimizer`, separado do VT ACCESS (`com.vtstudio.access`). É um ponto de partida derivado da interface Android existente para preservar o padrão visual e as telas.

## Antes de distribuir

- Definir o fluxo de handoff autenticado VT ACCESS → VT OPTIMIZER. Não compartilhar access tokens por Intent/clipboard ou armazená-los em texto puro. Preferir código de troca de uso único, curto e vinculado a usuário, licença e instalação, emitido pelo backend.
- Adicionar endpoint backend de troca e validação para o segundo package id.
- Confirmar a licença no backend em cada inicialização, retorno ao foreground e antes de executar funções licenciadas.
- Não considerar a tela de VT ACCESS como prova de licença: o segundo APK sempre valida no servidor.
- Assinar com chave de release própria e configurar Play/App Links ou distribuição privada.

O projeto independente ainda não está pronto para produção: o fluxo de handoff de token e a validação de licença no segundo APK são pendências explícitas, não são simulados.
