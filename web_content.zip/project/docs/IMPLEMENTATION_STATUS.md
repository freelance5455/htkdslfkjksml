# Status da implementação — 09/11/2026

| Área | Estado | Observação |
|---|---|---|
| VT STUDIO existente | Preservado | Telas existentes mantidas; pagamentos adicionado ao menu. |
| Cadastro de planos/preços | Implementado no frontend | Preço em BRL e aplicativo vinculado; requer migration. |
| Recursos por plano | Base implementada | Códigos e verificações server-side; validar matriz de permissões. |
| Pedidos PIX | Backend preparado | Requer provedor real e adaptação do contrato. |
| Confirmação PIX | Backend preparado | HMAC normalizado; assinatura oficial ainda precisa de adaptação/teste. |
| Geração automática de KEY | Implementada no webhook | Só após status pago validado; hash da KEY no cadastro e valor cifrado para resgate. |
| Vínculo cliente/plano/pedido/dispositivo | Parcialmente implementado | Pedido/cliente/plano/licença vinculados; ativação associa usuário/instalação. |
| Revogação pelo VT STUDIO | Parcial | Revogar licença existente; o segundo app ainda precisa revalidar periodicamente. |
| Segundo APK | Projeto independente criado | Handoff seguro e validação obrigatória de licença pendentes. |
| Efeitos sonoros | Parcial | Sons e controle no VT STUDIO; preferência/sons já existentes mantidos nos apps Android. |
| Otimização real/Brevent | Pendente | A interface existente ainda não executa as ações reais. |
| Build e testes | Não verificados | Dependências npm e Gradle/SDK indisponíveis neste ambiente. |
