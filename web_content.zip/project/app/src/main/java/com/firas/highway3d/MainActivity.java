package com.firas.highway3d;

import android.app.Activity;
import android.content.Intent;
import android.content.ClipData;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private static final int FILE_PICKER_REQUEST = 1001;
    private WebView webView;
    private boolean pageReady = false;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        hideSystemUI();

        webView = new WebView(this);
        webView.setBackgroundColor(0xFF000000);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setSupportMultipleWindows(false);

        webView.addJavascriptInterface(new AndroidMediaPicker(), "AndroidMediaPicker");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                pageReady = true;
                super.onPageFinished(view, url);
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    // Called by the game's own JavaScript button. The picker is Android's native
    // Storage Access Framework UI, not a browser page or third-party service.
    private class AndroidMediaPicker {
        @JavascriptInterface
        public void openMediaPicker() {
            runOnUiThread(() -> launchNativePicker());
        }
    }

    private void launchNativePicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"audio/*", "video/*"});
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try {
            startActivityForResult(intent, FILE_PICKER_REQUEST);
        } catch (Exception e) {
            sendSelectionToGame(new JSONArray(), "تعذر فتح مدير الملفات على هذا الجهاز");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_PICKER_REQUEST) return;

        if (resultCode != RESULT_OK || data == null) {
            sendSelectionToGame(new JSONArray(), "لم يتم اختيار أي ملف");
            return;
        }

        // Keep insertion order and avoid duplicates if a provider returns the same URI twice.
        Map<String, Uri> selected = new LinkedHashMap<>();
        ClipData clip = data.getClipData();
        if (clip != null) {
            for (int i = 0; i < clip.getItemCount(); i++) {
                Uri uri = clip.getItemAt(i).getUri();
                if (uri != null) selected.put(uri.toString(), uri);
            }
        } else if (data.getData() != null) {
            Uri uri = data.getData();
            selected.put(uri.toString(), uri);
        }

        JSONArray result = new JSONArray();
        for (Uri uri : selected.values()) {
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {
                // Some document providers grant a temporary read permission only.
            }
            JSONObject item = new JSONObject();
            try {
                item.put("uri", uri.toString());
                item.put("name", queryDisplayName(uri));
                result.put(item);
            } catch (Exception ignored) {
            }
        }

        String status = result.length() > 0
                ? "تم اختيار " + result.length() + " ملف من الجهاز"
                : "لم يتم اختيار أي ملف";
        sendSelectionToGame(result, status);
    }

    private String queryDisplayName(Uri uri) {
        String name = "ملف وسائط";
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) name = cursor.getString(index);
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) cursor.close();
        }
        return name;
    }

    private void sendSelectionToGame(JSONArray files, String status) {
        if (webView == null) return;
        // JSON is generated by org.json, so filenames and content URIs are safely escaped.
        String script = "window.onNativeMediaSelected && window.onNativeMediaSelected(" + files.toString() + "," + JSONObject.quote(status) + ");";
        webView.post(() -> webView.evaluateJavascript(script, null));
    }

    private void hideSystemUI() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUI();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidMediaPicker");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
