# Smart Calculator ko APK banane ka guide

Ye project ab Capacitor ke sath ready kiya gaya hai. Neeche diye steps apne computer
(Windows/Mac/Linux) par follow karein. Poora process pehli dafa ~15-20 minute lega.

## Zaroori cheezein (pehle install karein)

1. **Node.js** (v18 ya usse upar) — https://nodejs.org
2. **Android Studio** — https://developer.android.com/studio
   (isko install karte waqt "Android SDK" aur "Android SDK Platform" khud-ba-khud install ho jate hain)
3. **Java JDK 17** — Android Studio ke sath usually already aata hai.

## Step 1 — Dependencies install karein

Project folder ke andar terminal/cmd khol kar:

```bash
npm install
```

## Step 2 — Apni Gemini API key set karein

`.env.example` ko copy karke `.env` naam se file banayein, aur usme ye line add/edit karein:

```
VITE_GEMINI_API_KEY="yahan_apni_gemini_api_key_dalein"
```

(Gemini API key yahan se milti hai: https://aistudio.google.com/app/apikey — free hai)

> Note: Ye key ab app ke andar (client-side) bundle hogi, kyunke APK me koi alag
> backend server nahi chal raha. Personal use ke liye bilkul theek hai.

## Step 3 — Android project generate karein (sirf pehli dafa)

```bash
npx cap add android
```

Ye ek `android/` folder banayega jisme poora native Android project hoga.

## Step 4 — Web app build karein aur Android project me sync karein

```bash
npm run android:sync
```

## Step 5 — Camera permission add karein

`android/app/src/main/AndroidManifest.xml` file kholein aur `<manifest>` tag ke andar
(application tag se pehle) ye lines add karein agar already na hon:

```xml
<uses-permission android:name="android.permission.CAMERA" />
<uses-feature android:name="android.hardware.camera" android:required="false" />
```

## Step 6 — APK banayein

**Option A — Android Studio se (aasan, GUI):**
```bash
npx cap open android
```
Android Studio khul jayega → upar menu se **Build → Build Bundle(s) / APK(s) → Build APK(s)**
click karein. Kuch minute me niche notification aayegi "APK(s) generated successfully" —
usme "locate" link par click karein, wahan aapki `app-debug.apk` file hogi.

**Option B — Command line se (terminal/cmd):**
```bash
cd android
./gradlew assembleDebug
```
(Windows par: `gradlew.bat assembleDebug`)

APK yahan milegi:
```
android/app/build/outputs/apk/debug/app-debug.apk
```

Ye file apne Android phone me copy/transfer kar ke install kar lein
(phone settings me "Install from unknown sources" allow karna padega).

## Play Store ke liye (release/signed APK)

Agar ye app Play Store par publish karni ho ya kisi ko final version deni ho, to
"debug" ki jagah "release" build chahiye hoga jo signing key se sign ho — us waqt
bata dein, main us ke liye bhi guide bana dunga.

## Agar Android Studio install nahi karna chahte

Online no-code alternatives (inko poora project ya hosted URL chahiye hoga):
- https://pwabuilder.com (agar app ko pehle kahin host kar diya jaye)
- https://median.co
