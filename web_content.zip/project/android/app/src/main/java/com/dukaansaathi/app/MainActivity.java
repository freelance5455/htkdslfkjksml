package com.dukaansaathi.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
