package com.vtstudio.access.ui

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Environment
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.vtstudio.access.data.ApiException
import com.vtstudio.access.data.AppItem
import com.vtstudio.access.data.LicenseApi
import com.vtstudio.access.data.Session
import com.vtstudio.access.ui.theme.Crimson
import com.vtstudio.access.ui.theme.Danger
import com.vtstudio.access.ui.theme.Success
import com.vtstudio.access.ui.theme.TextPrimary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException
import java.security.MessageDigest

private const val APK_MIME = "application/vnd.android.package-archive"
private const val DIGEST_BUFFER_BYTES = 8192

private data class PendingInstall(val downloadId: Long, val checksum: String)

@Composable
fun AppsTab(session: Session, token: String, apps: List<AppItem>?, onChanged: () -> Unit) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var keyInput by remember { mutableStateOf("") }
    var activating by remember { mutableStateOf(false) }
    var activationMessage by remember { mutableStateOf<String?>(null) }
    var activationOk by remember { mutableStateOf(false) }
    var preparingAppId by remember { mutableStateOf<String?>(null) }
    var installError by remember { mutableStateOf<String?>(null) }
    var pending by remember { mutableStateOf<PendingInstall?>(null) }

    DisposableEffect(pending) {
        val current = pending
        if (current == null) {
            onDispose { }
        } else {
            val receiver = object : BroadcastReceiver() {
                override fun onReceive(receiverContext: Context, intent: Intent) {
                    if (intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L) != current.downloadId) return
                    scope.launch {
                        installError = verifyAndInstall(receiverContext, current)
                        pending = null
                    }
                }
            }
            ContextCompat.registerReceiver(
                context,
                receiver,
                IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE),
                ContextCompat.RECEIVER_EXPORTED,
            )
            onDispose { context.unregisterReceiver(receiver) }
        }
    }

    fun activate() {
        val key = keyInput.trim()
        if (key.isEmpty()) {
            activationOk = false
            activationMessage = "Informe a KEY recebida."
            return
        }
        activating = true
        activationMessage = null
        scope.launch {
            try {
                LicenseApi.activate(token, session.installationId, key, Build.MODEL ?: "Android")
                keyInput = ""
                activationOk = true
                activationMessage = "KEY ativada neste aparelho."
                onChanged()
            } catch (caught: ApiException) {
                activationOk = false
                activationMessage = caught.message
            } catch (caught: IOException) {
                activationOk = false
                activationMessage = "Sem conexão. Tente novamente."
            } finally {
                activating = false
            }
        }
    }

    fun install(app: AppItem) {
        preparingAppId = app.id
        installError = null
        scope.launch {
            try {
                val info = LicenseApi.download(token, session.installationId, app.id)
                val manager = context.getSystemService(DownloadManager::class.java)
                val request = DownloadManager.Request(Uri.parse(info.url))
                    .setTitle(info.fileName)
                    .setMimeType(APK_MIME)
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS, info.fileName)
                pending = PendingInstall(manager.enqueue(request), info.checksum)
            } catch (caught: ApiException) {
                installError = caught.message
            } catch (caught: IOException) {
                installError = "Sem conexão. Tente novamente."
            } finally {
                preparingAppId = null
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Column {
            Text("Aplicativos", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = TextPrimary)
            MutedText("Apps liberados pelas suas KEYs.")
        }

        VtCard {
            SectionTitle("Ativar uma KEY")
            OutlinedTextField(
                value = keyInput,
                onValueChange = { keyInput = it.uppercase() },
                placeholder = { Text("VT-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii),
                modifier = Modifier.fillMaxWidth(),
            )
            activationMessage?.let {
                Text(it, color = if (activationOk) Success else Danger, fontSize = 13.sp)
            }
            VtButton(text = "Ativar KEY", onClick = { activate() }, loading = activating)
        }

        when {
            apps == null -> Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Crimson)
            }
            apps.isEmpty() -> VtCard {
                MutedText("Nenhum aplicativo liberado ainda. Ative uma KEY acima para liberar seus apps.")
            }
            else -> apps.forEach { app ->
                AppCard(
                    app = app,
                    preparing = preparingAppId == app.id,
                    onInstall = { install(app) },
                )
            }
        }

        installError?.let { Text(it, color = Danger, fontSize = 13.sp) }
        if (pending != null) {
            MutedText("Baixando o arquivo. A instalação será aberta automaticamente.")
        }
    }
}

@Composable
private fun AppCard(app: AppItem, preparing: Boolean, onInstall: () -> Unit) {
    VtCard {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Box(
                modifier = Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(Crimson),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Rounded.Apps, contentDescription = null, tint = TextPrimary)
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(app.name, color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                MutedText("Versão ${app.version}")
            }
        }
        app.description?.let { MutedText(it) }
        MutedText(app.releaseVersion?.let { "Pronto para instalar · versão $it" } ?: "Arquivo ainda não disponível")
        VtButton(
            text = "Instalar",
            onClick = onInstall,
            enabled = app.releaseVersion != null,
            loading = preparing,
        )
    }
}

private suspend fun verifyAndInstall(context: Context, pending: PendingInstall): String? = withContext(Dispatchers.IO) {
    val manager = context.getSystemService(DownloadManager::class.java)
    val uri = manager.getUriForDownloadedFile(pending.downloadId)
        ?: return@withContext "O download não foi concluído. Tente novamente."

    val digest = MessageDigest.getInstance("SHA-256")
    val readOk = context.contentResolver.openInputStream(uri)?.use { input ->
        val buffer = ByteArray(DIGEST_BUFFER_BYTES)
        var count = input.read(buffer)
        while (count > 0) {
            digest.update(buffer, 0, count)
            count = input.read(buffer)
        }
        true
    } ?: false
    if (!readOk) return@withContext "Não foi possível ler o arquivo baixado."

    val actual = digest.digest().joinToString("") { "%02x".format(it) }
    if (actual != pending.checksum) {
        return@withContext "O arquivo baixado não passou na verificação de segurança e não será instalado."
    }

    context.startActivity(
        Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, APK_MIME)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK),
    )
    null
}
