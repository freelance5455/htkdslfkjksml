package com.vtstudio.access.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vtstudio.access.data.ApiException
import com.vtstudio.access.data.AuthTokens
import com.vtstudio.access.data.LicenseApi
import com.vtstudio.access.data.Session
import com.vtstudio.access.ui.theme.Danger
import com.vtstudio.access.ui.theme.TextPrimary
import com.vtstudio.access.ui.theme.TextSecondary
import kotlinx.coroutines.launch
import java.io.IOException

private val EMAIL_PATTERN = Regex("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$")

@Composable
fun AuthScreen(session: Session, onAuthenticated: (AuthTokens) -> Unit) {
    var isSignUp by remember { mutableStateOf(false) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun submit() {
        val trimmedEmail = email.trim()
        if (!EMAIL_PATTERN.matches(trimmedEmail)) {
            error = "Informe um e-mail válido."
            return
        }
        if (password.length < 8) {
            error = "A senha deve ter pelo menos 8 caracteres."
            return
        }
        loading = true
        error = null
        scope.launch {
            try {
                val tokens = if (isSignUp) {
                    LicenseApi.signUp(trimmedEmail, password)
                } else {
                    LicenseApi.signIn(trimmedEmail, password)
                }
                session.save(tokens)
                onAuthenticated(tokens)
            } catch (caught: ApiException) {
                error = caught.message
            } catch (caught: IOException) {
                error = "Sem conexão. Verifique sua internet e tente novamente."
            } finally {
                loading = false
            }
        }
    }

    DecoratedBackground {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .padding(horizontal = 24.dp, vertical = 32.dp),
            verticalArrangement = Arrangement.Center,
        ) {
            BrandMark()
            Spacer(Modifier.height(40.dp))
            Text(
                text = if (isSignUp) "Criar conta" else "Entrar",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
            )
            Spacer(Modifier.height(6.dp))
            MutedText("Acesse suas licenças e aplicativos liberados pelo seu plano.")
            Spacer(Modifier.height(28.dp))
            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("E-mail") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(14.dp))
            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Senha (mínimo 8 caracteres)") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth(),
            )
            error?.let {
                Spacer(Modifier.height(14.dp))
                Text(it, color = Danger, fontSize = 13.sp)
            }
            Spacer(Modifier.height(24.dp))
            VtButton(
                text = if (isSignUp) "Criar conta" else "Entrar",
                onClick = { submit() },
                loading = loading,
            )
            TextButton(
                onClick = {
                    isSignUp = !isSignUp
                    error = null
                },
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(
                    if (isSignUp) "Já tenho conta" else "Ainda não tenho conta. Criar agora",
                    color = TextSecondary,
                )
            }
        }
    }
}
