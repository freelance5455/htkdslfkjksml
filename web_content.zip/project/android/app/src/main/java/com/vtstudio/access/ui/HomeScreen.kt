package com.vtstudio.access.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.sp
import com.vtstudio.access.data.ApiException
import com.vtstudio.access.data.AppItem
import com.vtstudio.access.data.LicenseApi
import com.vtstudio.access.data.LicenseItem
import com.vtstudio.access.data.Session
import com.vtstudio.access.ui.theme.Crimson
import com.vtstudio.access.ui.theme.Danger
import com.vtstudio.access.ui.theme.GraphiteLine
import com.vtstudio.access.ui.theme.GraphiteSoft
import com.vtstudio.access.ui.theme.Success
import com.vtstudio.access.ui.theme.TextPrimary
import com.vtstudio.access.ui.theme.TextSecondary
import com.vtstudio.access.ui.theme.Warning
import kotlinx.coroutines.launch
import java.io.IOException

enum class HomeTab(val label: String, val icon: ImageVector) {
    Home("Início", Icons.Rounded.Home),
    Optimize("Otimizar", Icons.Rounded.Speed),
    Apps("Aplicativos", Icons.Rounded.Apps),
    Account("Conta", Icons.Rounded.Person),
}

@Composable
fun HomeScreen(session: Session, token: String, email: String, onSignedOut: () -> Unit) {
    var tab by rememberSaveable { mutableStateOf(HomeTab.Home) }
    var apps by remember { mutableStateOf<List<AppItem>?>(null) }
    var licenses by remember { mutableStateOf<List<LicenseItem>?>(null) }
    var soundEnabled by remember { mutableStateOf(session.soundEnabled) }
    var loadError by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val deviceId = session.installationId

    fun reload() {
        scope.launch {
            try {
                apps = LicenseApi.apps(token)
                licenses = LicenseApi.licenses(token)
                loadError = null
            } catch (caught: ApiException) {
                if (caught.sessionExpired) onSignedOut() else loadError = caught.message
            } catch (caught: IOException) {
                loadError = "Sem conexão. Puxe para atualizar quando a internet voltar."
            }
        }
    }

    LaunchedEffect(token) { reload() }

    CompositionLocalProvider(LocalSoundEnabled provides soundEnabled) {
        DecoratedBackground {
            Scaffold(
                containerColor = Color.Transparent,
                bottomBar = { BottomNav(selected = tab, onSelect = { tab = it }) },
            ) { padding ->
                AnimatedContent(
                    targetState = tab,
                    transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(120)) },
                    label = "homeTab",
                    modifier = Modifier.padding(padding),
                ) { current ->
                    when (current) {
                        HomeTab.Home -> HomeOverview(
                            email = email,
                            licenses = licenses,
                            deviceId = deviceId,
                            loadError = loadError,
                            onOpen = { tab = it },
                        )
                        HomeTab.Optimize -> OptimizeTab(
                            token = token,
                            installationId = deviceId,
                            apps = apps,
                        )
                        HomeTab.Apps -> AppsTab(
                            session = session,
                            token = token,
                            apps = apps,
                            onChanged = { reload() },
                        )
                        HomeTab.Account -> AccountTab(
                            email = email,
                            licenses = licenses,
                            apps = apps,
                            soundEnabled = soundEnabled,
                            onSoundChange = {
                                soundEnabled = it
                                session.soundEnabled = it
                            },
                            onSignOut = onSignedOut,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BottomNav(selected: HomeTab, onSelect: (HomeTab) -> Unit) {
    NavigationBar(containerColor = GraphiteSoft) {
        HomeTab.entries.forEach { item ->
            val isSelected = item == selected
            val tint by animateColorAsState(
                targetValue = if (isSelected) TextPrimary else TextSecondary,
                animationSpec = tween(200),
                label = "navTint",
            )
            val sound = LocalSoundEnabled.current
            NavigationBarItem(
                selected = isSelected,
                onClick = {
                    Sfx.click(sound)
                    onSelect(item)
                },
                icon = { Icon(item.icon, contentDescription = item.label, tint = tint) },
                label = { Text(item.label, fontSize = 11.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = TextPrimary,
                    unselectedIconColor = TextSecondary,
                    selectedTextColor = TextPrimary,
                    unselectedTextColor = TextSecondary,
                    indicatorColor = Crimson,
                ),
            )
        }
    }
}

@Composable
private fun HomeOverview(
    email: String,
    licenses: List<LicenseItem>?,
    deviceId: String,
    loadError: String?,
    onOpen: (HomeTab) -> Unit,
) {
    val name = email.substringBefore('@').replaceFirstChar { it.uppercase() }
    val active = licenses.orEmpty().filter { it.active }
    val deviceLinked = active.any { it.installationId == deviceId }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        BrandMark()
        Column {
            Text(
                text = if (name.isEmpty()) "Olá" else "Olá, $name",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
            )
            MutedText("Sua central de otimização e aplicativos.")
        }
        loadError?.let { Text(it, color = Danger, fontSize = 13.sp) }

        VtCard(modifier = Modifier.clickable { onOpen(HomeTab.Optimize) }) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Box(
                    modifier = Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(Crimson),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Rounded.Bolt, contentDescription = null, tint = TextPrimary)
                }
                Column {
                    Text("Otimização", fontWeight = FontWeight.SemiBold, color = TextPrimary, fontSize = 17.sp)
                    MutedText("Escolha o que otimizar e execute com um toque.")
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatusTile(
                modifier = Modifier.weight(1f),
                label = "Licença",
                value = if (active.isEmpty()) "Sem licença ativa" else "${active.size} ativa(s)",
                color = if (active.isEmpty()) Warning else Success,
            )
            StatusTile(
                modifier = Modifier.weight(1f),
                label = "Este aparelho",
                value = if (deviceLinked) "Vinculado" else "Não vinculado",
                color = if (deviceLinked) Success else Warning,
            )
        }

        SectionTitle("Atalhos")
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ShortcutTile(modifier = Modifier.weight(1f), label = "Aplicativos", icon = Icons.Rounded.Apps) { onOpen(HomeTab.Apps) }
            ShortcutTile(modifier = Modifier.weight(1f), label = "Conta e plano", icon = Icons.Rounded.Person) { onOpen(HomeTab.Account) }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun StatusTile(modifier: Modifier, label: String, value: String, color: Color) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(GraphiteSoft)
            .border(1.dp, GraphiteLine, RoundedCornerShape(18.dp))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.size(8.dp).clip(RoundedCornerShape(4.dp)).background(color))
            MutedText(label)
        }
        Text(value, color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}

@Composable
private fun ShortcutTile(modifier: Modifier, label: String, icon: ImageVector, onClick: () -> Unit) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(GraphiteSoft)
            .border(1.dp, GraphiteLine, RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Icon(icon, contentDescription = null, tint = TextPrimary)
        Text(label, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}
