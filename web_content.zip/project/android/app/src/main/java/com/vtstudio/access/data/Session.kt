package com.vtstudio.access.data

import android.content.Context
import java.util.UUID

class Session(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("vt_access", Context.MODE_PRIVATE)

    val accessToken: String?
        get() = prefs.getString(KEY_TOKEN, null)

    val email: String?
        get() = prefs.getString(KEY_EMAIL, null)

    val installationId: String
        get() = prefs.getString(KEY_INSTALLATION, null) ?: UUID.randomUUID().toString().also {
            prefs.edit().putString(KEY_INSTALLATION, it).apply()
        }

    var soundEnabled: Boolean
        get() = prefs.getBoolean(KEY_SOUND, true)
        set(value) {
            prefs.edit().putBoolean(KEY_SOUND, value).apply()
        }

    fun save(tokens: AuthTokens) {
        prefs.edit().putString(KEY_TOKEN, tokens.accessToken).putString(KEY_EMAIL, tokens.email).apply()
    }

    fun clear() {
        prefs.edit().remove(KEY_TOKEN).remove(KEY_EMAIL).apply()
    }

    private companion object {
        const val KEY_TOKEN = "access_token"
        const val KEY_EMAIL = "email"
        const val KEY_INSTALLATION = "installation_id"
        const val KEY_SOUND = "sound_enabled"
    }
}
