# Step 6 – 2.5D Scene Animation Engine

Is update mein har still image ko FFmpeg `zoompan` se motion clip mein badla jata hai.
8 deterministic camera presets rotate hote hain: slow zoom-in, zoom-out, horizontal pan,
vertical pan aur diagonal pan/zoom. Scene audio clip ke saath mux hota hai; frame rate
25 FPS, H.264 video aur AAC audio rakhe gaye hain.

**Important limitation:** Yeh 2.5D camera motion hai. Isse image mein maujood character ke
haath-pair ya chehre independently move nahi karte. Real generative image-to-video animation
ke liye alag hosted AI video API/model aur uski API key/credits chahiye; woh is step mein
connect nahi ki gayi. Scene transitions abhi hard cuts hain, crossfade nahi.

## Test
- Python syntax compile: PASS
- FFmpeg still-image + audio render smoke test: PASS (generated test clip)
- Real project full-length render: NOT RUN (requires generated scene assets and voices)
- Android APK build: NOT RUN
