# VideoGenie Step 4 – Scene-wise Storyboard

## Added
- `/breakdown` API: splits a pasted narration into scene-sized chunks and returns a storyboard preview.
- Gemini enrichment in batches of 8 scenes, requesting a distinct visual prompt, character description, background, camera framing/movement, animation instructions, and continuity notes.
- Fallback storyboard fields when no Gemini key is provided or Gemini enrichment fails. The fallback is clearly generic and is not claimed to be AI-generated.
- Scene metadata is also saved into `scenes.json` during video creation and the image prompt is used by the image pipeline.
- Mobile UI button: **Create scene-by-scene storyboard**.

## How to test
1. Start the Python backend using the instructions in README.md.
2. Open the app from the phone/browser.
3. Paste a script into **Your own script**.
4. Enter a Gemini API key for AI-specific visual prompts and continuity details.
5. Tap **Create scene-by-scene storyboard**.
6. Review narration, image prompt, character, background, camera, animation, and continuity for each scene.
7. Tap **Create video** to use the saved scene pipeline. The video-generation pipeline creates storyboard metadata again when it builds a new project.

## Limitations
- This step creates storyboard instructions and distinct image prompts. It does not create true motion-video clips by itself. Actual per-scene animation/video generation is a later step and needs a compatible video-generation provider or a local animation/rendering pipeline.
- Gemini live API calls were not run because no user API key/network credentials were supplied.
- Android APK was not rebuilt in this step. This ZIP is the updated source package.
