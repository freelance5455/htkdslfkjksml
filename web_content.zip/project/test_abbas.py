#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""اختبار وظيفي شامل لتطبيق عباس (واجهة + مزامنة الراوتر) في Chromium حقيقي."""
import glob
import http.server
import json
import os
import socket
import socketserver
import sys
import threading

from playwright.sync_api import sync_playwright

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(BASE, "abbas")
SHOTS = os.path.join(BASE, "shots-abbas")
os.makedirs(SHOTS, exist_ok=True)

_s = socket.socket()
_s.bind(("127.0.0.1", 0))
PORT = _s.getsockname()[1]
_s.close()

LEASES = [
    {"address": "10.10.0.11", "mac-address": "AA:BB:CC:00:00:11",
     "host-name": "برج الشعلة 1", "status": "bound", "disabled": False},
    {"address": "10.10.0.12", "mac-address": "AA:BB:CC:00:00:12",
     "host-name": "حسين كريم", "status": "bound", "disabled": False},
]

results = []


def check(name, cond, extra=""):
    results.append((name, bool(cond)))
    print(("PASS " if cond else "FAIL ") + name + ((" | " + str(extra)) if extra else ""))


class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *a, **kw):
        super().__init__(*a, directory=ROOT, **kw)

    def do_GET(self):
        if self.path.startswith("/rest/ip/dhcp-lease"):
            body = json.dumps(LEASES, ensure_ascii=False).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        super().do_GET()

    def log_message(self, *a):
        pass


def serve():
    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer(("127.0.0.1", PORT), Handler) as httpd:
        httpd.serve_forever()


threading.Thread(target=serve, daemon=True).start()

exe_list = sorted(glob.glob(os.path.expanduser("~/.cache/ms-playwright/chromium-*/chrome-linux/chrome")))

with sync_playwright() as pw:
    browser = pw.chromium.launch(executable_path=(exe_list[-1] if exe_list else None),
                                 args=["--no-sandbox"])
    ctx = browser.new_context(viewport={"width": 390, "height": 844}, locale="ar-IQ")
    page = ctx.new_page()
    errors = []
    page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
    page.on("pageerror", lambda e: errors.append(str(e)))

    page.goto("http://127.0.0.1:%d/index.html" % PORT)
    page.wait_for_selector("#btnAdd")
    page.evaluate("() => { window.__opened = []; window.open = (u) => { window.__opened.push(u); return null; }; }")

    # 1) مشترك + دين
    page.click("#btnAdd")
    page.fill("#fName", "علي حسين")
    page.fill("#fPhone", "07701234567")
    page.fill("#fArea", "الشعلة")
    page.fill("#fPrice", "25000")
    page.fill("#fDebt", "25000")
    page.fill("#fElink", "ايرثلنك 20 ميجا")
    page.click("#btnSave")
    page.wait_for_timeout(250)
    page.click('.tab[data-goto="subs"]')
    page.wait_for_timeout(300)
    check("إضافة مشترك", page.locator("#subsList .sub").count() == 1, page.locator("#subsList .sub").count())
    check("اسم اشتراك إيرثلنك على البطاقة", "ايرثلنك 20 ميجا" in page.inner_text("#subsList"))
    check("الدين الكلي 25,000", "25,000" in page.inner_text("#statDebt"))

    # 2) تسديد
    page.locator("#subsList [data-pay]").first.click()
    page.fill("#payAmount", "25000")
    page.click("#payForm button[type=submit]")
    page.wait_for_timeout(250)
    check("المستلم هذا الشهر 25,000", "25,000" in page.inner_text("#statReceived"))
    check("الدين صفر", page.inner_text("#statDebt").split()[0] == "0")

    # 3) سجل
    page.locator("#subsList [data-hist]").first.click()
    page.wait_for_timeout(200)
    check("سجل: قيدا دين وتسديد", page.locator("#histList .led").count() == 2)
    check("السجل يذكر التسديد بتاريخ", "تسديد" in page.inner_text("#histList"))
    page.screenshot(path=os.path.join(SHOTS, "history.png"))
    page.click("#histSheet [data-close]")

    # 4) مشترك ثانٍ ودين متراكم
    page.click("#btnAdd")
    page.fill("#fName", "حسين كريم")
    page.fill("#fPhone", "07811223344")
    page.fill("#fPrice", "30000")
    page.click("#btnSave")
    page.wait_for_timeout(250)
    card = page.locator("#subsList .sub", has_text="حسين كريم").first
    card.locator("[data-adddebt]").click()
    page.wait_for_timeout(150)
    page.locator("#subsList .sub", has_text="حسين كريم").first.locator("[data-adddebt]").click()
    page.wait_for_timeout(250)
    check("الدين تراكم 60,000", "60,000" in page.inner_text("#statDebt"))

    # 5) واتساب
    page.locator("#subsList .sub", has_text="حسين كريم").first.locator("[data-wa]").click()
    page.wait_for_timeout(300)
    opened = page.evaluate("() => window.__opened")
    check("رابط واتساب برقم دولي", opened and "wa.me/9647811223344" in opened[-1],
          opened[-1][:80] if opened else "none")

    # 6) التذكير
    page.click('.tab[data-goto="home"]')
    page.wait_for_timeout(300)
    page.click('.tile[data-goto="remind"]')
    page.wait_for_timeout(250)
    check("عدّاد التذكير 1/2", page.inner_text("#remindCount").strip() == "1/2")
    page.click("#btnRemindFirst")
    page.wait_for_timeout(300)
    check("بعد الإرسال 2/2", page.inner_text("#remindCount").strip() == "2/2")

    # 7) الأجهزة يدويًا
    page.click('.tab[data-goto="dev"]')
    page.wait_for_timeout(250)
    page.click("#btnAddDevice")
    page.fill("#dName", "برج الشعلة 1")
    page.fill("#dIp", "10.10.0.2")
    page.fill("#dMac", "AA:BB:CC:DD:EE:FF")
    page.select_option("#dSub", index=1)
    page.click("#devForm button[type=submit]")
    page.wait_for_timeout(300)
    check("إضافة جهاز يدويًا", page.locator("#devList .dev").count() == 1)
    check("لوحة اشتراكات إيرثلنك تجمع الاسم", "ايرثلنك 20 ميجا" in page.inner_text("#elinkList"), page.inner_text("#elinkList").replace("\n"," | ")[:60])
    check("معلومات الجهاز ظاهرة", "10.10.0.2" in page.inner_text("#devList"))

    # 8) مزامنة الراوتر: المعلومات تظهر وحدها
    page.fill("#rtrUrl", "http://127.0.0.1:%d/rest/ip/dhcp-lease" % PORT)
    page.click("#btnRtrSync")
    page.wait_for_timeout(1500)
    txt = page.inner_text("#devList")
    check("ظهر 10.10.0.11 تلقائيًا", "10.10.0.11" in txt, txt.replace("\n", " | ")[:80])
    check("ظهر 10.10.0.12 تلقائيًا", "10.10.0.12" in txt)
    check("ظهر MAC من الراوتر", "AA:BB:CC:00:00:11" in txt)
    check("ربط تلقائي بمشترك", "👤" in txt)
    check("إجمالي الأجهزة 3", page.locator("#devList .dev").count() == 3,
          page.locator("#devList .dev").count())
    check("رسالة المزامنة", "تمت المزامنة" in page.inner_text("#rtrResult"))
    page.click("#btnRtrSync")
    page.wait_for_timeout(1500)
    check("لا تكرار بعد إعادة المزامنة", page.locator("#devList .dev").count() == 3)
    check("وقت المزامنة محفوظ", "آخر مزامنة" in page.inner_text("#rtrLast"))
    page.screenshot(path=os.path.join(SHOTS, "router-sync.png"))

    # 9) الإعدادات + النسخة الاحتياطية
    page.click('.tab[data-goto="settings"]')
    page.fill("#setOrg", "مكتب عباس")
    page.click("#btnSaveSettings")
    page.wait_for_timeout(250)
    check("اسم المكتب محفوظ", page.inner_text("#orgName") == "مكتب عباس")
    page.click("#btnExport")
    page.wait_for_timeout(250)
    backup = page.input_value("#backupText")
    ok = False
    try:
        j = json.loads(backup)
        ok = len(j["data"]["subs"]) == 2 and len(j["data"]["devices"]) == 3
    except Exception:
        ok = False
    check("النسخة الاحتياطية تحتوي المشتركين والأجهزة", ok)
    page.click("#textSheet [data-close]")

    # 10) البحث والتصفية
    page.click('.tab[data-goto="subs"]')
    page.fill("#searchInput", "حسين كريم")
    page.wait_for_timeout(250)
    check("البحث يفلتر", page.locator("#subsList .sub").count() == 1, page.locator("#subsList .sub").count())
    page.fill("#searchInput", "")

    # 11) الثبات
    page.reload()
    page.wait_for_selector("#statTotal")
    page.wait_for_timeout(400)
    check("البيانات باقية بعد التحميل", page.inner_text("#statTotal") == "2")
    check("الأجهزة باقية", page.locator('.tab[data-goto="dev"]').count() == 1)

    # 12) العرض
    page.set_viewport_size({"width": 1366, "height": 900})
    page.wait_for_timeout(300)
    check("لا خروج أفقي 1366",
          page.evaluate("() => document.documentElement.scrollWidth - document.documentElement.clientWidth") <= 0)
    page.screenshot(path=os.path.join(SHOTS, "desktop.png"))
    page.set_viewport_size({"width": 360, "height": 780})
    page.wait_for_timeout(250)
    check("لا خروج أفقي 360",
          page.evaluate("() => document.documentElement.scrollWidth - document.documentElement.clientWidth") <= 0)
    page.set_viewport_size({"width": 390, "height": 844})
    page.wait_for_timeout(200)
    page.screenshot(path=os.path.join(SHOTS, "home-390.png"))
    check("لا أخطاء JavaScript", len(errors) == 0, errors[:2])
    browser.close()

failed = [r[0] for r in results if not r[1]]
print("\n===== %d/%d نجحت =====" % (len(results) - len(failed), len(results)))
if failed:
    print("FAILED:", failed)
    sys.exit(1)
print("ALL_TESTS_PASSED")
