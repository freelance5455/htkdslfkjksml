/* ==========================================================
   تطبيق عباس — منطق التطبيق
   كل البيانات محلية داخل الجهاز (localStorage) + نسخ احتياطي.
   ========================================================== */
(function () {
  'use strict';

  var STORE_KEY = 'abbas_app_v22';
  var SNAP_KEY = 'abbas_snapshots_v1';

  var AR_MONTHS = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
                   'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];

  var DEFAULT_TEMPLATE =
    'السلام عليكم {الاسم}، تحية من {المكتب}. ' +
    'مبلغ الاشتراك لشهر {الشهر} هو {السعر}، والدين الكلي {الدين}. ' +
    'يرجى التسديد في أول الشهر. شكرًا لتعاونكم.';

  var state = null;
  var currentPayId = null;
  var currentFilter = 'all';

  /* ============================ أدوات ============================ */

  function $(sel, root) { return (root || document).querySelector(sel); }
  function $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function uid() {
    return 's' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  }

  function esc(str) {
    return String(str == null ? '' : str)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  function num(v) {
    var n = parseInt(v, 10);
    return isNaN(n) || n < 0 ? 0 : n;
  }

  function money(v) {
    var n = Math.round(Number(v) || 0);
    return n.toLocaleString('en-US') + ' ' + (state.settings.currency || 'د.ع');
  }

  function monthKey(d) {
    d = d || new Date();
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0');
  }

  function monthLabel(key) {
    var parts = String(key).split('-');
    var m = parseInt(parts[1], 10) - 1;
    return (AR_MONTHS[m] || '') + ' ' + parts[0];
  }

  function today() { return new Date(); }

  function toast(msg) {
    var el = $('#toast');
    el.textContent = msg;
    el.hidden = false;
    clearTimeout(toast._t);
    toast._t = setTimeout(function () { el.hidden = true; }, 2400);
  }

  /* ============================ التخزين ============================ */

  function blankState() {
    return {
      v: 1,
      settings: {
        org: 'عباس',
        currency: 'د.ع',
        defaultPrice: 25000,
        template: DEFAULT_TEMPLATE
      },
      subs: [],
      devices: [],
      payments: [],
      charges: [],
      vpn: { url: '', lastCheck: '', lastSync: '' },
      router: { url: '', user: '', lastSync: '' },
      reminders: {},
      createdAt: new Date().toISOString()
    };
  }

  function load() {
    var raw = null;
    try { raw = localStorage.getItem(STORE_KEY); } catch (e) { raw = null; }

    // ترحيل بيانات الإصدارات السابقة دون حذف المفتاح القديم.
    // الإصدار السابق كان يستخدم abbas_app_v1؛ تغيير المفتاح وحده كان
    // يجعل التطبيق يبدو وكأنه فقد المشتركين والديون عند التحديث.
    if (!raw) {
      var legacyKeys = ['abbas_app_v1'];
      for (var i = 0; i < legacyKeys.length && !raw; i++) {
        try { raw = localStorage.getItem(legacyKeys[i]); } catch (e) { raw = null; }
      }
      if (raw) {
        try {
          var migrated = normalize(JSON.parse(raw));
          try { localStorage.setItem(STORE_KEY, JSON.stringify(migrated)); }
          catch (e) { /* تبقى البيانات القديمة محفوظة حتى لو تعذّر نسخها */ }
          return migrated;
        } catch (e) {
          // لا نمسح النسخة القديمة إذا كان محتواها غير قابل للقراءة.
          return blankState();
        }
      }
    }

    if (!raw) return blankState();
    try {
      var obj = JSON.parse(raw);
      return normalize(obj);
    } catch (e) {
      return blankState();
    }
  }

  function metric(v) {
    if (v === '' || v === null || v === undefined) return '';
    var n = Number(v);
    return Number.isFinite(n) ? n : '';
  }

  function normalize(obj) {
    var base = blankState();
    if (!obj || typeof obj !== 'object') return base;
    var s = obj.settings && typeof obj.settings === 'object' ? obj.settings : {};
    base.settings.org = String(s.org || base.settings.org).slice(0, 30);
    base.settings.currency = String(s.currency || base.settings.currency).slice(0, 6);
    base.settings.defaultPrice = num(s.defaultPrice || base.settings.defaultPrice);
    base.settings.template = String(s.template || base.settings.template).slice(0, 400);
    base.subs = Array.isArray(obj.subs) ? obj.subs.filter(Boolean).map(function (x) {
      return {
        id: String(x.id || uid()),
        name: String(x.name || '').slice(0, 50),
        phone: String(x.phone || '').slice(0, 20),
        area: String(x.area || '').slice(0, 40),
        elink: String(x.elink || '').slice(0, 60),
        earthlinkStatus: String(x.earthlinkStatus || '').slice(0, 40),
        earthlinkSyncedAt: String(x.earthlinkSyncedAt || ''),
        price: num(x.price),
        debt: num(x.debt),
        paidMonth: String(x.paidMonth || ''),
        note: String(x.note || '').slice(0, 80),
        createdAt: String(x.createdAt || new Date().toISOString())
      };
    }) : [];
    base.payments = Array.isArray(obj.payments) ? obj.payments.filter(Boolean).map(function (p) {
      return {
        id: String(p.id || uid()),
        subId: String(p.subId || ''),
        amount: num(p.amount),
        at: String(p.at || new Date().toISOString())
      };
    }) : [];
    base.charges = Array.isArray(obj.charges) ? obj.charges.filter(Boolean).map(function (c) {
      return {
        id: String(c.id || uid()),
        subId: String(c.subId || ''),
        amount: num(c.amount),
        at: String(c.at || new Date().toISOString()),
        note: String(c.note || '').slice(0, 60)
      };
    }) : [];
    base.devices = Array.isArray(obj.devices) ? obj.devices.filter(Boolean).map(function (d) {
      return {
        id: String(d.id || uid()),
        name: String(d.name || '').slice(0, 40),
        type: String(d.type || 'برج').slice(0, 20),
        ip: String(d.ip || '').slice(0, 40),
        mac: String(d.mac || '').slice(0, 30),
        subId: String(d.subId || ''),
        status: d.status === 'down' ? 'down' : 'up',
        signal: metric(d.signal), ccq: metric(d.ccq), snr: metric(d.snr), cpu: metric(d.cpu),
        tx: metric(d.tx), rx: metric(d.rx),
        src: d.src === 'router' ? 'router' : (d.src === 'vpn' ? 'vpn' : ''),
        note: String(d.note || '').slice(0, 80),
        updatedAt: String(d.updatedAt || new Date().toISOString())
      };
    }) : [];
    var rt = obj.router && typeof obj.router === 'object' ? obj.router : {};
    base.router = {
      url: String(rt.url || '').slice(0, 200),
      radioUrl: String(rt.radioUrl || '').slice(0, 200),
      user: String(rt.user || '').slice(0, 40),
      lastSync: String(rt.lastSync || ''),
      radioLastSync: String(rt.radioLastSync || '')
    };
    var vp = obj.vpn && typeof obj.vpn === 'object' ? obj.vpn : {};
    base.vpn = {
      url: String(vp.url || '').slice(0, 200),
      lastCheck: String(vp.lastCheck || ''),
      lastSync: String(vp.lastSync || '')
    };
    base.reminders = obj.reminders && typeof obj.reminders === 'object' ? obj.reminders : {};
    return base;
  }

  function save() {
    try {
      localStorage.setItem(STORE_KEY, JSON.stringify(state));
    } catch (e) {
      toast('تعذّر الحفظ: ذاكرة الجهاز ممتلئة');
    }
  }

  /* نسخ تلقائية داخلية (آخر 3 حالات) للحماية من الخطأ البشري */
  function autoSnapshot() {
    try {
      var raw = localStorage.getItem(SNAP_KEY);
      var list = raw ? JSON.parse(raw) : [];
      if (!Array.isArray(list)) list = [];
      list.unshift({ at: new Date().toISOString(), data: JSON.stringify(state) });
      list = list.slice(0, 3);
      localStorage.setItem(SNAP_KEY, JSON.stringify(list));
    } catch (e) { /* تجاهل */ }
  }

  function commit() {
    save();
    renderAll();
  }

  /* ============================ الحسابات ============================ */

  function totalDebt() {
    return state.subs.reduce(function (a, s) { return a + num(s.debt); }, 0);
  }

  function expectedMonthly() {
    return state.subs.reduce(function (a, s) { return a + num(s.price); }, 0);
  }

  function receivedIn(key) {
    return state.payments.reduce(function (a, p) {
      return monthKey(new Date(p.at)) === key ? a + num(p.amount) : a;
    }, 0);
  }

  function isPaidThisMonth(s) {
    return s.paidMonth === monthKey();
  }

  function unpaidCount() {
    return state.subs.filter(function (s) { return !isPaidThisMonth(s) || num(s.debt) > 0; }).length;
  }

  function lastMonths(n) {
    var out = [];
    var d = today();
    for (var i = 0; i < n; i++) {
      var k = monthKey(new Date(d.getFullYear(), d.getMonth() - i, 1));
      out.push({ key: k, total: receivedIn(k) });
    }
    return out;
  }

  /* ============================ واتساب ============================ */

  function normalizePhone(raw) {
    var d = String(raw || '').replace(/[^\d]/g, '');
    if (!d) return '';
    if (d.indexOf('00') === 0) d = d.slice(2);
    if (d.indexOf('964') === 0) return d;
    if (d.charAt(0) === '0') return '964' + d.slice(1);
    if (d.length === 10 && d.charAt(0) === '7') return '964' + d;
    return d;
  }

  function buildMessage(sub) {
    var tpl = state.settings.template || DEFAULT_TEMPLATE;
    return tpl
      .replace(/\{الاسم\}/g, sub.name || '')
      .replace(/\{الدين\}/g, money(sub.debt))
      .replace(/\{السعر\}/g, money(sub.price))
      .replace(/\{المكتب\}/g, state.settings.org || 'عباس')
      .replace(/\{الشهر\}/g, monthLabel(monthKey()));
  }

  function waLink(sub) {
    var phone = normalizePhone(sub.phone);
    var text = encodeURIComponent(buildMessage(sub));
    if (!phone) return 'https://wa.me/?text=' + text;
    return 'https://wa.me/' + phone + '?text=' + text;
  }

  function openWhatsApp(sub) {
    if (!normalizePhone(sub.phone)) {
      toast('أضف رقم الهاتف أولًا لهذا المشترك');
      return false;
    }
    markReminded(sub.id);
    window.open(waLink(sub), '_blank');
    return true;
  }

  function remindMap() {
    var k = monthKey();
    if (!state.reminders[k] || typeof state.reminders[k] !== 'object') state.reminders[k] = {};
    return state.reminders[k];
  }

  function markReminded(id) {
    remindMap()[id] = new Date().toISOString();
    save();
    renderReminders();
    renderHome();
  }

  function remindedCount() {
    var map = remindMap();
    return state.subs.filter(function (s) { return !!map[s.id]; }).length;
  }

  /* ============================ التنقل ============================ */

  function showView(name) {
    $$('.view').forEach(function (v) { v.hidden = v.getAttribute('data-view') !== name; });
    $$('.tab').forEach(function (t) {
      if (t.getAttribute('data-goto') === name) t.setAttribute('aria-current', 'page');
      else t.removeAttribute('aria-current');
    });
    var main = $('#main');
    if (main) main.scrollTop = 0;
    window.scrollTo(0, 0);
  }

  /* ============================ الرسم ============================ */

  function renderAll() {
    $('#orgName').textContent = state.settings.org || 'عباس';
    renderHome();
    renderSubs();
    renderReminders();
    renderDevices();
    renderSettings();
  }

  function renderHome() {
    var cur = monthKey();
    $('#statTotal').textContent = state.subs.length;
    $('#statDebt').textContent = money(totalDebt());
    $('#statReceived').textContent = money(receivedIn(cur));

    $('#accDebt').textContent = money(totalDebt());
    $('#accReceived').textContent = money(receivedIn(cur));
    $('#accUnpaid').textContent = unpaidCount() + ' من ' + state.subs.length;
    $('#accExpected').textContent = money(expectedMonthly());

    var months = lastMonths(6);
    $('#monthsHint').textContent = monthLabel(cur);
    $('#monthList').innerHTML = months.map(function (m) {
      var bar = months[0].total > 0 ? Math.round((m.total / Math.max(months[0].total, 1)) * 100) : 0;
      return '<div class="month">' +
        '<div class="month__top"><b>' + esc(monthLabel(m.key)) + '</b>' +
        '<span>' + esc(money(m.total)) + '</span></div>' +
        '<div class="month__bar"><i style="width:' + Math.min(100, bar) + '%"></i></div>' +
        '</div>';
    }).join('');

    // بانر أول الشهر
    var banner = $('#monthBanner');
    var day = today().getDate();
    var pending = state.subs.length - remindedCount();
    if (state.subs.length > 0 && day <= 10 && pending > 0) {
      banner.innerHTML =
        '<button type="button" class="banner" data-goto="remind">' +
        '<span class="banner__dot"></span>' +
        '<span class="banner__text">بداية الشهر: باقي ' + pending + ' مشترك لم تُرسل له رسالة التذكير</span>' +
        '<span class="banner__go">إرسال</span>' +
        '</button>';
    } else {
      banner.innerHTML = '';
    }

    var due = state.subs.slice().sort(function (a, b) { return num(b.debt) - num(a.debt); })
      .filter(function (s) { return num(s.debt) > 0; }).slice(0, 4);

    $('#dueList').innerHTML = due.length ? due.map(function (s) {
      return '<div class="sub sub--due">' +
        '<div class="sub__top"><div><div class="sub__name">' + esc(s.name) + '</div>' +
        '<div class="sub__meta">' +
        (s.area ? '<span>' + esc(s.area) + '</span>' : '') +
        (s.phone ? '<span dir="ltr">' + esc(s.phone) + '</span>' : '') +
        '</div></div>' +
        '<span class="badge badge--due">' + esc(money(s.debt)) + '</span></div>' +
        '<div class="sub__actions">' +
        '<button type="button" class="mini mini--ok" data-wa="' + esc(s.id) + '">واتساب</button>' +
        '<button type="button" class="mini" data-pay="' + esc(s.id) + '">تسديد</button>' +
        '</div></div>';
    }).join('') : '<div class="empty"><b>لا يوجد دين</b>كل المشتركين مسدّدون حاليًا</div>';
  }

  function renderEarthlink() {
    var box = $('#elinkList');
    if (!box) return;
    var map = {};
    state.subs.forEach(function (s) {
      var nm = String(s.elink || '').trim();
      if (!nm) return;
      if (!map[nm]) map[nm] = { n: 0, price: 0, debt: 0 };
      map[nm].n += 1;
      map[nm].price += num(s.price);
      map[nm].debt += num(s.debt);
    });
    var names = Object.keys(map).sort(function (a, b) { return map[b].n - map[a].n; });
    if (!names.length) {
      box.innerHTML = '<div class="empty"><b>لا توجد أسماء اشتراكات بعد</b>' +
        'أضف اسم اشتراك إيرثلنك عند إضافة أو تعديل المشترك</div>';
      return;
    }
    box.innerHTML = names.map(function (nm) {
      var d = map[nm];
      return '<button type="button" class="elink" data-elink="' + esc(nm) + '">' +
        '<span class="elink__name">🛰️ ' + esc(nm) + '</span>' +
        '<span class="elink__meta">' + d.n + ' مشترك · <b>' + esc(money(d.price)) + '</b> شهريًا' +
        (d.debt > 0 ? ' · دين ' + esc(money(d.debt)) : ' · بلا دين') +
        '</span></button>';
    }).join('');
  }

  function renderSubs() {
    renderEarthlink();
    var q = ($('#searchInput').value || '').trim().toLowerCase();
    $('#subsCount').textContent = state.subs.length;

    var list = state.subs.slice().sort(function (a, b) {
      return String(a.name).localeCompare(String(b.name), 'ar');
    }).filter(function (s) {
      if (currentFilter === 'due' && !(num(s.debt) > 0 || !isPaidThisMonth(s))) return false;
      if (currentFilter === 'paid' && !isPaidThisMonth(s)) return false;
      if (!q) return true;
      return (s.name + ' ' + s.phone + ' ' + s.area + ' ' + (s.elink || '')).toLowerCase().indexOf(q) !== -1;
    });

    if (!list.length) {
      $('#subsList').innerHTML = state.subs.length
        ? '<div class="empty"><b>لا نتائج</b>جرّب بحثًا آخر أو غيّر التصفية</div>'
        : '<div class="empty"><b>لا يوجد مشتركون بعد</b>اضغط زر + لإضافة أول مشترك</div>';
      return;
    }

    $('#subsList').innerHTML = list.map(function (s) {
      var paid = isPaidThisMonth(s);
      var due = num(s.debt) > 0;
      return '<div class="sub' + (due ? ' sub--due' : '') + '" data-sub="' + esc(s.id) + '">' +
        '<div class="sub__top">' +
        '<div class="sub__left"><div class="sub__name">' + esc(s.name) + '</div>' +
        '<div class="sub__meta">' +
        (s.area ? '<span>📍 ' + esc(s.area) + '</span>' : '') +
        (s.phone ? '<span dir="ltr">📞 ' + esc(s.phone) + '</span>' : '<span class="warn-xs">بلا رقم</span>') +
        (s.elink ? '<span>🛰️ ' + esc(s.elink) + '</span>' : '') +
        '</div></div>' +
        '<span class="badge ' + (paid ? 'badge--paid' : 'badge--due') + '">' +
        (paid ? 'مسدّد' : 'غير مسدّد') + '</span>' +
        '</div>' +
        '<div class="sub__price">السعر الشهري: <b>' + esc(money(s.price)) + '</b>' +
        (due ? ' · الدين: <b class="txt-warn">' + esc(money(s.debt)) + '</b>' : ' · بلا دين') +
        '</div>' +
        (s.note ? '<div class="sub__note">' + esc(s.note) + '</div>' : '') +
        '<div class="sub__actions">' +
        '<button type="button" class="mini mini--ok" data-wa="' + esc(s.id) + '">واتساب</button>' +
        '<button type="button" class="mini mini--warn" data-pay="' + esc(s.id) + '">تسديد</button>' +
        '<button type="button" class="mini" data-adddebt="' + esc(s.id) + '">+ شهر دين</button>' +
        '<button type="button" class="mini mini--info" data-hist="' + esc(s.id) + '">السجل</button>' +
        '<button type="button" class="mini" data-edit="' + esc(s.id) + '">تعديل</button>' +
        '<button type="button" class="mini mini--danger" data-del="' + esc(s.id) + '">حذف</button>' +
        '</div></div>';
    }).join('');
  }

  function renderReminders() {
    var map = remindMap();
    var total = state.subs.length;
    var done = remindedCount();
    $('#remindCount').textContent = done + '/' + total;
    $('#remindMonth').textContent = 'رسائل ' + monthLabel(monthKey());
    $('#remindState').textContent = done >= total && total > 0 ? 'تم إرسال الكل' : 'باقي ' + Math.max(0, total - done);

    var first = state.subs[0];
    $('#remindPreview').textContent = first ? buildMessage(first) : 'أضف مشتركًا أولًا لعرض نموذج الرسالة.';

    var pending = state.subs.filter(function (s) { return !map[s.id]; });
    $('#btnRemindFirst').textContent = pending.length ? 'إرسال للباقي (' + pending.length + ')' : 'تم الإرسال للكل';
    $('#btnRemindFirst').disabled = pending.length === 0;

    if (!total) {
      $('#remindList').innerHTML = '<div class="empty"><b>لا مشتركين</b>أضف مشتركين أولًا</div>';
      return;
    }

    $('#remindList').innerHTML = state.subs.map(function (s) {
      var sent = !!map[s.id];
      return '<div class="remind">' +
        '<div class="remind__body">' +
        '<b>' + esc(s.name) + '</b>' +
        '<small>' + (s.phone ? '<span dir="ltr">' + esc(s.phone) + '</span>' : 'بلا رقم') +
        ' · ' + esc(money(s.debt)) + '</small>' +
        '</div>' +
        '<span class="remind__state ' + (sent ? 'is-sent' : '') + '">' + (sent ? 'أُرسلت' : 'لم تُرسل') + '</span>' +
        '<button type="button" class="mini mini--ok" data-wa="' + esc(s.id) + '">' +
        (sent ? 'إعادة' : 'إرسال') + '</button>' +
        '</div>';
    }).join('');
  }

  function renderSettings() {
    $('#setOrg').value = state.settings.org || '';
    $('#setPrice').value = state.settings.defaultPrice || 0;
    $('#setCurrency').value = state.settings.currency || '';
    $('#setTemplate').value = state.settings.template || DEFAULT_TEMPLATE;
  }

  /* ============================ النوافذ ============================ */

  function openSheet(id) { var el = $(id); if (el) el.hidden = false; }
  function closeSheet(el) { if (el) el.hidden = true; }

  function askConfirm(title, text) {
    return new Promise(function (resolve) {
      $('#confirmTitle').textContent = title;
      $('#confirmText').textContent = text;
      openSheet('#confirmSheet');
      var sheet = $('#confirmSheet');
      function done(val) {
        closeSheet(sheet);
        $('#confirmYes').removeEventListener('click', yes);
        $$('[data-close]', sheet).forEach(function (b) { b.removeEventListener('click', no); });
        resolve(val);
      }
      function yes() { done(true); }
      function no() { done(false); }
      $('#confirmYes').addEventListener('click', yes);
      $$('[data-close]', sheet).forEach(function (b) { b.addEventListener('click', no); });
    });
  }

  /* ---------------- نموذج المشترك ---------------- */

  var editingId = null;

  function openSubForm(id) {
    editingId = id || null;
    var s = id ? state.subs.find(function (x) { return x.id === id; }) : null;
    $('#sheetTitle').textContent = s ? 'تعديل مشترك' : 'مشترك جديد';
    $('#fName').value = s ? s.name : '';
    $('#fPhone').value = s ? s.phone : '';
    $('#fArea').value = s ? s.area : '';
    $('#fElink').value = s ? (s.elink || '') : '';
    $('#fPrice').value = s ? s.price : (state.settings.defaultPrice || '');
    $('#fDebt').value = s ? s.debt : 0;
    $('#fPaid').checked = s ? isPaidThisMonth(s) : false;
    $('#fNote').value = s ? s.note : '';
    $('#errName').hidden = true;
    openSheet('#subSheet');
    setTimeout(function () { $('#fName').focus(); }, 60);
  }

  function submitSub(e) {
    e.preventDefault();
    var name = $('#fName').value.trim();
    if (!name) {
      $('#errName').hidden = false;
      $('#fName').focus();
      return;
    }
    var data = {
      name: name,
      phone: $('#fPhone').value.trim(),
      area: $('#fArea').value.trim(),
      elink: $('#fElink').value.trim(),
      price: num($('#fPrice').value) || state.settings.defaultPrice,
      debt: num($('#fDebt').value),
      note: $('#fNote').value.trim()
    };
    var paid = $('#fPaid').checked;

    if (editingId) {
      var s = state.subs.find(function (x) { return x.id === editingId; });
      if (s) {
        Object.keys(data).forEach(function (k) { s[k] = data[k]; });
        s.paidMonth = paid ? monthKey() : '';
      }
      toast('تم حفظ التعديل');
    } else {
      var sub = {
        id: uid(),
        name: data.name,
        phone: data.phone,
        area: data.area,
        elink: data.elink,
        price: data.price,
        debt: data.debt,
        paidMonth: paid ? monthKey() : '',
        note: data.note,
        createdAt: new Date().toISOString()
      };
      state.subs.push(sub);
      if (sub.debt > 0) {
        state.charges.push({ id: uid(), subId: sub.id, amount: sub.debt,
          at: new Date().toISOString(), note: 'دين افتتاحي' });
      }
      toast('أُضيف المشترك');
    }
    closeSheet($('#subSheet'));
    commit();
  }

  function deleteSub(id) {
    var s = state.subs.find(function (x) { return x.id === id; });
    if (!s) return;
    askConfirm('حذف مشترك', 'سيتم حذف "' + s.name + '" مع سجل دفعاته. لا يمكن التراجع إلا من نسخة احتياطية.').then(function (ok) {
      if (!ok) return;
      autoSnapshot();
      state.subs = state.subs.filter(function (x) { return x.id !== id; });
      state.payments = state.payments.filter(function (p) { return p.subId !== id; });
      state.charges = (state.charges || []).filter(function (c) { return c.subId !== id; });
      Object.keys(state.reminders).forEach(function (k) {
        if (state.reminders[k]) delete state.reminders[k][id];
      });
      toast('تم الحذف');
      commit();
    });
  }

  /* ---------------- التسديد ---------------- */

  function openPay(id) {
    var s = state.subs.find(function (x) { return x.id === id; });
    if (!s) return;
    currentPayId = id;
    $('#payWho').textContent = s.name + (s.phone ? ' · ' + s.phone : '');
    $('#payDebtLine').textContent = 'الدين الحالي: ' + money(s.debt) + ' · السعر الشهري: ' + money(s.price);
    $('#payAmount').value = s.debt > 0 ? s.debt : s.price;
    openSheet('#paySheet');
    setTimeout(function () { $('#payAmount').select(); }, 60);
  }

  function submitPay(e) {
    e.preventDefault();
    var s = state.subs.find(function (x) { return x.id === currentPayId; });
    if (!s) return;
    var amount = num($('#payAmount').value);
    if (amount <= 0) { toast('أدخل مبلغًا أكبر من صفر'); return; }

    autoSnapshot();
    state.payments.push({ id: uid(), subId: s.id, amount: amount, at: new Date().toISOString() });
    s.debt = Math.max(0, num(s.debt) - amount);
    s.paidMonth = monthKey();

    closeSheet($('#paySheet'));
    toast('تم تسجيل ' + money(amount));
    commit();
  }

  function addDebtMonth(id) {
    var s = state.subs.find(function (x) { return x.id === id; });
    if (!s) return;
    s.debt = num(s.debt) + num(s.price);
    s.paidMonth = '';
    state.charges.push({ id: uid(), subId: s.id, amount: num(s.price),
      at: new Date().toISOString(), note: 'شهر إضافي' });
    toast(s.name + ': أُضيف شهر دين (' + money(s.price) + ')');
    commit();
  }

  /* ---------------- النسخ الاحتياطي ---------------- */

  function openBackupText(text, hint) {
    $('#backupText').value = text;
    $('#textSheetHint').textContent = hint || '';
    openSheet('#textSheet');
    setTimeout(function () { $('#backupText').select(); }, 60);
  }

  function copyTextarea() {
    var ta = $('#backupText');
    ta.select();
    var ok = false;
    try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(ta.value).then(function () { toast('تم النسخ'); },
        function () { toast(ok ? 'تم النسخ' : 'انسخ يدويًا: النص محدد'); });
    } else {
      toast(ok ? 'تم النسخ' : 'انسخ يدويًا: النص محدد');
    }
  }

  function exportBackup() {
    var payload = { app: 'abbas', v: 1, exportedAt: new Date().toISOString(), data: state };
    openBackupText(JSON.stringify(payload), 'انسخ النص كاملًا واحفظه في واتساب أو الملاحظات أو بريدك.');
  }

  function importBackup() {
    var txt = window.prompt('الصق نص النسخة الاحتياطية هنا:');
    if (!txt) return;
    var parsed = null;
    try { parsed = JSON.parse(txt); } catch (e) { toast('النص غير صالح'); return; }
    var data = parsed && parsed.data ? parsed.data : parsed;
    if (!data || !Array.isArray(data.subs)) { toast('النسخة لا تحتوي بيانات صالحة'); return; }
    askConfirm('استعادة نسخة', 'سيتم استبدال البيانات الحالية بـ ' + data.subs.length + ' مشترك. هل تريد المتابعة؟')
      .then(function (ok) {
        if (!ok) return;
        autoSnapshot();
        state = normalize(data);
        commit();
        toast('تمت الاستعادة');
      });
  }

  function resetAll() {
    askConfirm('حذف كل المشتركين', 'سيتم حذف جميع المشتركين والدفعات نهائيًا. خُذ نسخة احتياطية أولًا.').then(function (ok) {
      if (!ok) return;
      autoSnapshot();
      state = blankState();
      commit();
      toast('تم حذف كل البيانات');
    });
  }


  /* ---------------- سجل الدين والتسديد ---------------- */

  function fmtDate(iso) {
    var d = new Date(iso);
    if (isNaN(d.getTime())) return '—';
    function p2(n) { return String(n).padStart(2, '0'); }
    return p2(d.getDate()) + '/' + p2(d.getMonth() + 1) + '/' + d.getFullYear() +
      ' · ' + p2(d.getHours()) + ':' + p2(d.getMinutes());
  }

  function ledgerFor(subId) {
    var rows = [];
    (state.charges || []).forEach(function (c) {
      if (c.subId === subId) {
        rows.push({ at: c.at, type: 'charge', amount: num(c.amount), note: c.note || 'دين' });
      }
    });
    state.payments.forEach(function (p) {
      if (p.subId === subId) {
        rows.push({ at: p.at, type: 'payment', amount: num(p.amount), note: 'تسديد' });
      }
    });
    rows.sort(function (a, b) { return new Date(a.at) - new Date(b.at); });
    return rows;
  }

  function openHistory(id) {
    var s = state.subs.find(function (x) { return x.id === id; });
    if (!s) return;
    var rows = ledgerFor(id);
    var paidTotal = rows.filter(function (r) { return r.type === 'payment'; })
      .reduce(function (a, r) { return a + r.amount; }, 0);
    var chargedTotal = rows.filter(function (r) { return r.type === 'charge'; })
      .reduce(function (a, r) { return a + r.amount; }, 0);

    $('#histTitle').textContent = 'سجل ' + s.name;
    $('#histSum').innerHTML =
      '<div class="hist-sum__row"><span>الدين الحالي</span><b class="txt-warn">' + esc(money(s.debt)) + '</b></div>' +
      '<div class="hist-sum__row"><span>إجمالي المسدد</span><b class="txt-ok">' + esc(money(paidTotal)) + '</b></div>' +
      '<div class="hist-sum__row"><span>إجمالي ما تراكم</span><b>' + esc(money(chargedTotal)) + '</b></div>' +
      '<div class="hist-sum__row"><span>آخر تسديد</span><b>' + (lastPaidLabel(rows) || 'لم يسدد بعد') + '</b></div>';

    $('#histList').innerHTML = rows.length ? rows.map(function (r) {
      var isPay = r.type === 'payment';
      return '<div class="led">' +
        '<span class="led__sign ' + (isPay ? 'led__sign--ok' : 'led__sign--warn') + '">' + (isPay ? '↓' : '↑') + '</span>' +
        '<span class="led__body"><b>' + (isPay ? 'تسديد' : 'دين') + ' — ' + esc(money(r.amount)) + '</b>' +
        '<small>' + esc(fmtDate(r.at)) + ' · ' + esc(r.note) + '</small></span>' +
        '<span class="led__tag ' + (isPay ? 'is-ok' : 'is-warn') + '">' + (isPay ? 'وارد' : 'مستحق') + '</span>' +
        '</div>';
    }).join('') : '<div class="empty"><b>لا حركة بعد</b>لم يُسجَّل دين ولا تسديد لهذا المشترك</div>';

    openSheet('#histSheet');
  }

  function lastPaidLabel(rows) {
    var pays = rows.filter(function (r) { return r.type === 'payment'; });
    if (!pays.length) return '';
    return fmtDate(pays[pays.length - 1].at);
  }


  /* ---------------- الأجهزة والبرج ---------------- */

  var editingDev = null;

  function devTypeIcon(type) {
    if (type === 'راوتر') return '📶';
    if (type === 'لاقط') return '📡';
    if (type === 'سويتش') return '🔀';
    return '🗼';
  }

  function subName(id) {
    var s = state.subs.find(function (x) { return x.id === id; });
    return s ? s.name : '';
  }

  function renderDevices() {
    var list = state.devices || [];
    var up = list.filter(function (d) { return d.status !== 'down'; }).length;
    if ($('#devCount')) $('#devCount').textContent = list.length + ' جهاز';
    if ($('#devStat')) $('#devStat').textContent = up + ' يعمل · ' + (list.length - up) + ' متوقف';
    if ($('#vpnUrl')) $('#vpnUrl').value = (state.vpn && state.vpn.url) || '';
    if ($('#rtrUrl')) $('#rtrUrl').value = (state.router && state.router.url) || '';
    if ($('#rtrRadioUrl')) $('#rtrRadioUrl').value = (state.router && state.router.radioUrl) || '';
    if ($('#rtrUser')) $('#rtrUser').value = (state.router && state.router.user) || '';
    if ($('#rtrLast')) {
      $('#rtrLast').textContent = (state.router && state.router.lastSync)
        ? 'آخر مزامنة: ' + fmtDate(state.router.lastSync)
        : 'لم تتم مزامنة بعد';
    }
    if ($('#vpnState')) {
      var vs = state.vpn || {};
      $('#vpnState').textContent = vs.lastCheck
        ? 'آخر فحص: ' + fmtDate(vs.lastCheck) + (vs.lastSync ? ' · آخر استيراد: ' + fmtDate(vs.lastSync) : '')
        : 'لم يُفحص بعد';
    }
    if (!$('#devList')) return;

    $('#devList').innerHTML = list.length ? list.map(function (d) {
      var owner = subName(d.subId);
      return '<div class="dev">' +
        '<div class="dev__icon">' + devTypeIcon(d.type) + '</div>' +
        '<div class="dev__body">' +
        '<div class="dev__top"><b>' + esc(d.name) + '</b>' +
        '<span class="dev__dot ' + (d.status === 'down' ? 'is-down' : 'is-up') + '"></span></div>' +
        '<small>' + esc(d.type) + (d.ip ? ' · <span dir="ltr">' + esc(d.ip) + '</span>' : '') +
        (d.mac ? ' · <span dir="ltr">' + esc(d.mac) + '</span>' : '') + '</small>' +
        (owner ? '<small class="dev__owner">👤 ' + esc(owner) + '</small>' : '<small class="dev__owner warn-xs">غير مربوط بمشترك</small>') +
        '<div class="dev-metrics">' +
        (d.signal !== '' && d.signal !== undefined ? '<span>Signal <b>' + esc(d.signal) + ' dBm</b></span>' : '') +
        (d.ccq !== '' && d.ccq !== undefined ? '<span>CCQ <b>' + esc(d.ccq) + '%</b></span>' : '') +
        (d.snr !== '' && d.snr !== undefined ? '<span>SNR <b>' + esc(d.snr) + ' dB</b></span>' : '') +
        (d.cpu !== '' && d.cpu !== undefined ? '<span>CPU <b>' + esc(d.cpu) + '%</b></span>' : '') +
        (d.tx !== '' && d.tx !== undefined ? '<span>TX <b>' + esc(d.tx) + ' Mbps</b></span>' : '') +
        (d.rx !== '' && d.rx !== undefined ? '<span>RX <b>' + esc(d.rx) + ' Mbps</b></span>' : '') +
        '</div>' +
        '</div>' +
        '<div class="dev__acts">' +
        '<button type="button" class="mini" data-devedit="' + esc(d.id) + '">تعديل</button>' +
        '<button type="button" class="mini mini--danger" data-devdel="' + esc(d.id) + '">حذف</button>' +
        '</div></div>';
    }).join('') : '<div class="empty"><b>لا أجهزة بعد</b>أضف برجًا أو راوترًا واربطه بالمشترك</div>';
  }

  function openDeviceForm(id) {
    editingDev = id || null;
    var d = id ? state.devices.find(function (x) { return x.id === id; }) : null;
    $('#devSheetTitle').textContent = d ? 'تعديل جهاز' : 'جهاز جديد';
    $('#dName').value = d ? d.name : '';
    $('#dType').value = d ? d.type : 'برج';
    $('#dIp').value = d ? d.ip : '';
    $('#dMac').value = d ? d.mac : '';
    $('#dStatus').value = d ? d.status : 'up';
    $('#dSignal').value = d && d.signal !== '' ? d.signal : '';
    $('#dCcq').value = d && d.ccq !== '' ? d.ccq : '';
    $('#dSnr').value = d && d.snr !== '' ? d.snr : '';
    $('#dCpu').value = d && d.cpu !== '' ? d.cpu : '';
    $('#dTx').value = d && d.tx !== '' ? d.tx : '';
    $('#dRx').value = d && d.rx !== '' ? d.rx : '';
    $('#dNote').value = d ? d.note : '';
    var sel = $('#dSub');
    sel.innerHTML = '<option value="">— بلا مشترك —</option>' + state.subs.map(function (s) {
      return '<option value="' + esc(s.id) + '">' + esc(s.name) + '</option>';
    }).join('');
    sel.value = d ? (d.subId || '') : '';
    $('#errDev').hidden = true;
    openSheet('#devSheet');
    setTimeout(function () { $('#dName').focus(); }, 60);
  }

  function submitDevice(e) {
    e.preventDefault();
    var name = $('#dName').value.trim();
    if (!name) { $('#errDev').hidden = false; $('#dName').focus(); return; }
    var data = {
      name: name,
      type: $('#dType').value,
      ip: $('#dIp').value.trim(),
      mac: $('#dMac').value.trim(),
      subId: $('#dSub').value,
      status: $('#dStatus').value,
      signal: metric($('#dSignal').value), ccq: metric($('#dCcq').value),
      snr: metric($('#dSnr').value), cpu: metric($('#dCpu').value),
      tx: metric($('#dTx').value), rx: metric($('#dRx').value),
      note: $('#dNote').value.trim(),
      updatedAt: new Date().toISOString()
    };
    if (editingDev) {
      var d = state.devices.find(function (x) { return x.id === editingDev; });
      if (d) Object.keys(data).forEach(function (k) { d[k] = data[k]; });
      toast('تم حفظ الجهاز');
    } else {
      var nd = { id: uid() };
      Object.keys(data).forEach(function (k) { nd[k] = data[k]; });
      state.devices.push(nd);
      toast('أُضيف الجهاز');
    }
    closeSheet($('#devSheet'));
    commit();
  }

  function deleteDevice(id) {
    var d = state.devices.find(function (x) { return x.id === id; });
    if (!d) return;
    askConfirm('حذف جهاز', 'سيتم حذف "' + d.name + '" من القائمة.').then(function (ok) {
      if (!ok) return;
      autoSnapshot();
      state.devices = state.devices.filter(function (x) { return x.id !== id; });
      toast('تم الحذف');
      commit();
    });
  }

  function vpnCheck() {
    var url = $('#vpnUrl').value.trim();
    if (!url) { toast('أدخل عنوان سيرفر OpenVPN'); return; }
    state.vpn.url = url;
    save();
    var out = $('#vpnResult');
    out.textContent = 'جارٍ الفحص…';
    var ctrl = new AbortController();
    var timer = setTimeout(function () { ctrl.abort(); }, 9000);
    fetch(url, { method: 'GET', cache: 'no-store', signal: ctrl.signal })
      .then(function (r) {
        clearTimeout(timer);
        state.vpn.lastCheck = new Date().toISOString();
        save();
        renderDevices();
        out.textContent = 'السيرفر يستجيب — رمز ' + r.status + '. المزامنة الكاملة تحتاج واجهة API تعطي قائمة الأجهزة.';
        toast('السيرفر يستجيب');
      })
      .catch(function () {
        clearTimeout(timer);
        state.vpn.lastCheck = new Date().toISOString();
        save();
        renderDevices();
        out.textContent = 'تعذّر الوصول من التطبيق (شهادة، تسجيل دخول، أو السيرفر غير متاح). يمكنك استيراد القائمة يدويًا.';
        toast('تعذّر الوصول للسيرفر');
      });
  }

  function importDevices() {
    var txt = window.prompt('الصق قائمة الأجهزة: كل سطر "اسم, IP, MAC" أو JSON من OpenVPN');
    if (!txt) return;
    var items = [];
    var t = txt.trim();
    if (t.charAt(0) === '[' || t.charAt(0) === '{') {
      try {
        var parsed = JSON.parse(t);
        if (parsed && parsed.data) parsed = parsed.data;
        if (Array.isArray(parsed)) {
          parsed.forEach(function (x) {
            items.push({ name: x.name || x.common_name || x.cn || 'جهاز',
                         ip: x.ip || x.virtual_address || '', mac: x.mac || '' });
          });
        }
      } catch (e) { toast('JSON غير صالح'); return; }
    } else {
      t.split(/\r?\n/).forEach(function (line) {
        if (!line.trim()) return;
        var parts = line.split(',');
        if (parts.length < 2) return;
        items.push({ name: parts[0].trim(), ip: (parts[1] || '').trim(), mac: (parts[2] || '').trim() });
      });
    }
    if (!items.length) { toast('لا أسطر صالحة'); return; }
    autoSnapshot();
    items.forEach(function (it) {
      state.devices.push({
        id: uid(), name: it.name.slice(0, 40), type: 'برج',
        ip: it.ip.slice(0, 40), mac: it.mac.slice(0, 30),
        subId: '', status: 'up', note: 'مستورد من OpenVPN',
        updatedAt: new Date().toISOString()
      });
    });
    state.vpn.lastSync = new Date().toISOString();
    commit();
    toast('أُضيف ' + items.length + ' جهاز');
  }


  /* ---------------- مزامنة الراوتر (معلومات تظهر تلقائيًا) ---------------- */

  function httpGetRemote(url, user, pass) {
    return new Promise(function (resolve) {
      if (window.AbbasNative && typeof window.AbbasNative.httpGet === 'function') {
        try {
          var raw = window.AbbasNative.httpGet(url, user || '', pass || '');
          var obj = JSON.parse(raw);
          resolve(obj);
        } catch (e) {
          resolve({ ok: false, error: 'تعذّر تنفيذ الطلب داخل التطبيق' });
        }
        return;
      }
      var headers = {};
      if (user) {
        try { headers['Authorization'] = 'Basic ' + btoa(unescape(encodeURIComponent(user + ':' + pass))); }
        catch (e) { /* تجاهل */ }
      }
      var ctrl = new AbortController();
      var timer = setTimeout(function () { ctrl.abort(); }, 12000);
      fetch(url, { headers: headers, cache: 'no-store', signal: ctrl.signal })
        .then(function (r) {
          return r.text().then(function (b) {
            clearTimeout(timer);
            resolve({ ok: r.ok, status: r.status, body: b });
          });
        })
        .catch(function () {
          clearTimeout(timer);
          resolve({ ok: false, error: 'تعذّر الوصول للراوتر من المتصفح (CORS). داخل التطبيق يعمل عبر الاتصال المباشر.' });
        });
    });
  }

  function parseLeases(text) {
    var items = [];
    var t = String(text || '').trim();
    if (!t) return items;

    if (t.charAt(0) === '[' || t.charAt(0) === '{') {
      try {
        var j = JSON.parse(t);
        var arr = Array.isArray(j) ? j : (j.leases || j.data || j.results || j.hosts || null);
        if (!arr) {
          Object.keys(j).some(function (k) {
            if (Array.isArray(j[k])) { arr = j[k]; return true; }
            return false;
          });
        }
        if (Array.isArray(arr)) {
          arr.forEach(function (o) {
            if (!o || typeof o !== 'object') return;
            var ip = o.address || o.ip || o['active-address'] || o.ipAddress || '';
            var mac = o['mac-address'] || o.mac || o.macAddress || '';
            var nm = o['host-name'] || o.hostname || o.name || o.comment || '';
            var st = 'up';
            if (o.disabled === true || o.status === 'waiting' || o.status === 'expired' || o.active === false) st = 'down';
            if (ip || mac) items.push({ name: String(nm || ''), ip: String(ip), mac: String(mac), status: st });
          });
        }
      } catch (e) { /* ليس JSON */ }
    }

    if (!items.length) {
      t.split(/\r?\n/).forEach(function (line) {
        if (!line.trim() || /^\s*(#|\/\/)/.test(line)) return;
        var ipm = line.match(/(\d{1,3}(?:\.\d{1,3}){3})/);
        var macm = line.match(/([0-9A-Fa-f]{2}(?::[0-9A-Fa-f]{2}){5})/);
        if (!ipm && !macm) return;
        var nm = line.split(/[,;\t]/)[0].replace(ipm ? ipm[1] : '', '').replace(macm ? macm[1] : '', '').trim();
        items.push({ name: nm, ip: ipm ? ipm[1] : '', mac: macm ? macm[1] : '', status: 'up' });
      });
    }
    return items.map(function (it, i) {
      return { name: it.name || ('جهاز ' + (i + 1)), ip: it.ip, mac: it.mac, status: it.status };
    });
  }

  function matchSubscriber(name) {
    if (!name) return '';
    var hit = state.subs.find(function (s) {
      if (!s.name || s.name.length < 3) return false;
      return name.indexOf(s.name) !== -1 || s.name.indexOf(name) !== -1;
    });
    return hit ? hit.id : '';
  }

  function mergeLeases(items) {
    var added = 0, updated = 0, seen = {};
    items.forEach(function (it) {
      var mac = (it.mac || '').toUpperCase().replace(/-/g, ':');
      var ip = it.ip || '';
      var d = null;
      if (mac) d = state.devices.find(function (x) { return (x.mac || '').toUpperCase().replace(/-/g, ':') === mac; });
      if (!d && ip) d = state.devices.find(function (x) { return x.ip === ip; });

      if (d) {
        if (it.mac) d.mac = it.mac;
        if (ip) d.ip = ip;
        if (it.name && (!d.name || /^جهاز /.test(d.name))) d.name = it.name;
        if (!d.subId) { var sid = matchSubscriber(it.name); if (sid) d.subId = sid; }
        d.status = it.status;
        d.src = 'router';
        d.updatedAt = new Date().toISOString();
        updated++;
      } else {
        state.devices.push({
          id: uid(),
          name: it.name || 'جهاز',
          type: 'راوتر',
          ip: ip,
          mac: it.mac || '',
          subId: matchSubscriber(it.name),
          status: it.status,
          note: 'تلقائي من الراوتر',
          src: 'router',
          updatedAt: new Date().toISOString()
        });
        added++;
      }
      if (mac) seen[mac] = 1; else if (ip) seen['ip:' + ip] = 1;
    });

    var down = 0;
    state.devices.forEach(function (d) {
      if (d.src !== 'router') return;
      var key = (d.mac || '').toUpperCase().replace(/-/g, ':');
      var present = key ? !!seen[key] : !!seen['ip:' + (d.ip || '')];
      if (!present && d.status !== 'down') { d.status = 'down'; down++; }
    });
    return { added: added, updated: updated, down: down };
  }

  function routerSync() {
    var url = $('#rtrUrl').value.trim();
    var user = $('#rtrUser').value.trim();
    var pass = $('#rtrPass').value;
    if (!url) { toast('أدخل عنوان الراوتر أولًا'); return; }
    state.router.url = url;
    state.router.user = user;
    save();
    var out = $('#rtrResult');
    out.textContent = 'جارٍ المزامنة مع الراوتر…';
    httpGetRemote(url, user, pass).then(function (res) {
      if (!res || !res.ok) {
        out.textContent = 'تعذّر الاتصال: ' + ((res && res.error) || 'تحقق من العنوان وبيانات الدخول');
        toast('فشلت المزامنة');
        return;
      }
      var items = parseLeases(res.body);
      if (!items.length) {
        out.textContent = 'تم الاتصال بالراوتر لكن لم تصل أجهزة. جرّب مسار /rest/ip/dhcp-lease أو صفحة DHCP.';
        return;
      }
      autoSnapshot();
      var r = mergeLeases(items);
      state.router.lastSync = new Date().toISOString();
      commit();
      out.textContent = 'تمت المزامنة: ' + items.length + ' جهاز · جديد ' + r.added +
        ' · محدّث ' + r.updated + ' · صار متوقف ' + r.down;
      toast('ظهرت معلومات ' + items.length + ' جهاز تلقائيًا');
    });
  }


  /* ---------------- قراءات لاسلكية حقيقية من MikroTik RouterOS v7 ---------------- */
  function parseRate(v) {
    if (v === undefined || v === null || v === '') return '';
    var m = String(v).match(/[0-9]+(?:\.[0-9]+)?/);
    return m ? Number(m[0]) : '';
  }
  function parseSignal(v) {
    if (v === undefined || v === null || v === '') return '';
    var m = String(v).match(/-?\d+(?:\/-?\d+)?/);
    if (!m) return '';
    var first = m[0].split('/')[0];
    return Number(first);
  }
  function radioSync() {
    var url = ($('#rtrRadioUrl') && $('#rtrRadioUrl').value.trim()) || '';
    var user = $('#rtrUser').value.trim();
    var pass = $('#rtrPass').value;
    if (!url) { toast('أدخل رابط registration-table أولاً'); return; }
    state.router.radioUrl = url;
    save();
    var out = $('#rtrResult');
    out.textContent = 'جارٍ قراءة الإشارات من MikroTik…';
    httpGetRemote(url, user, pass).then(function (res) {
      if (!res || !res.ok) { out.textContent = 'فشلت قراءة اللاسلكي: ' + ((res && res.error) || 'تحقق من الاتصال والصلاحيات'); return; }
      var raw = res.body;
      var arr = [];
      try { var j = typeof raw === 'string' ? JSON.parse(raw) : raw; arr = Array.isArray(j) ? j : (j.data || j.results || []); } catch (e) {}
      if (!Array.isArray(arr) || !arr.length) { out.textContent = 'اتصل الراوتر لكن لم تصل سجلات لاسلكية. تأكد من تفعيل Wireless واستخدام المسار المناسب لطرازك.'; return; }
      var updated = 0;
      arr.forEach(function (r) {
        var mac = String(r['mac-address'] || r.mac || r.macAddress || '').toUpperCase().replace(/-/g, ':');
        var ip = String(r['last-ip'] || r.address || r.ip || '');
        var d = state.devices.find(function (x) {
          return (mac && String(x.mac || '').toUpperCase().replace(/-/g, ':') === mac) || (ip && x.ip === ip);
        });
        if (!d) return;
        var sig = parseSignal(r['signal-strength'] || r.signal || r.signalStrength);
        var ccq = parseRate(r['tx-ccq'] || r.ccq || r.txCcq);
        var snr = parseRate(r['signal-to-noise'] || r.snr || r.signalToNoise);
        var tx = parseRate(r['tx-rate'] || r.txRate || r['tx-rate-bps']);
        var rx = parseRate(r['rx-rate'] || r.rxRate || r['rx-rate-bps']);
        if (sig !== '') d.signal = sig;
        if (ccq !== '') d.ccq = ccq;
        if (snr !== '') d.snr = snr;
        if (tx !== '') d.tx = tx;
        if (rx !== '') d.rx = rx;
        d.status = 'up'; d.src = 'router'; d.updatedAt = new Date().toISOString();
        updated++;
      });
      var resourceUrl = url.replace(/\/rest\/.+$/i, '/rest/system/resource');
      httpGetRemote(resourceUrl, user, pass).then(function (rr) {
        if (rr && rr.ok) {
          try {
            var resource = JSON.parse(rr.body);
            if (Array.isArray(resource)) resource = resource[0] || {};
            var host = '';
            try { host = new URL(url).hostname; } catch (e) {}
            var routerDevice = state.devices.find(function (x) { return x.ip === host; });
            if (routerDevice && resource['cpu-load'] !== undefined) routerDevice.cpu = metric(resource['cpu-load']);
          } catch (e) {}
        }
        state.router.radioLastSync = new Date().toISOString();
        commit();
        out.textContent = 'وصلت ' + arr.length + ' سجلات لاسلكية؛ تم تحديث ' + updated + ' جهاز مطابق بالـ MAC أو IP. ' + (updated ? '' : 'اربط الأجهزة بنفس MAC/IP المسجل في القائمة.');
        toast('اكتملت قراءة MikroTik');
      });
    });
  }

  /* ---------------- استيراد كشف CSV من بوابة وكيل Earthlink ---------------- */
  function csvRows(text) {
    var rows = [], row = [], cell = '', quoted = false;
    for (var i = 0; i < text.length; i++) {
      var c = text[i], n = text[i + 1];
      if (c === '"' && quoted && n === '"') { cell += '"'; i++; }
      else if (c === '"') quoted = !quoted;
      else if ((c === ',' || c === ';' || c === '\t') && !quoted) { row.push(cell.trim()); cell = ''; }
      else if ((c === '\n' || c === '\r') && !quoted) {
        if (cell || row.length) { row.push(cell.trim()); rows.push(row); }
        row = []; cell = ''; if (c === '\r' && n === '\n') i++;
      } else cell += c;
    }
    if (cell || row.length) { row.push(cell.trim()); rows.push(row); }
    return rows.filter(function (r) { return r.some(Boolean); });
  }
  function normHead(v) { return String(v || '').toLowerCase().replace(/[\s_\-]/g, '').replace(/[أإآ]/g, 'ا'); }
  function earthlinkImport(file) {
    var out = $('#earthlinkSyncResult');
    var reader = new FileReader();
    reader.onload = function () {
      var rows = csvRows(String(reader.result || '').replace(/^\uFEFF/, ''));
      if (rows.length < 2) { out.textContent = 'الملف فارغ أو لا يحتوي صفوف بيانات.'; return; }
      var heads = rows.shift().map(normHead);
      function col(names) { for (var i=0;i<names.length;i++){ var k=heads.indexOf(normHead(names[i])); if(k>=0)return k; } return -1; }
      var nameI = col(['name','fullname','subscriber','customer','الاسم','اسمالمشترك']);
      var userI = col(['username','account','accountid','userid','subscriberid','رقمالحساب','الحساب','اليوزر']);
      var phoneI = col(['phone','mobile','الهاتف','الموبايل']);
      var priceI = col(['price','amount','subscriptionprice','السعر','المبلغ']);
      var statusI = col(['status','state','الحالة']);
      var updated = 0, missed = 0;
      autoSnapshot();
      rows.forEach(function (r) {
        var nm = nameI >= 0 ? (r[nameI] || '') : '';
        var un = userI >= 0 ? (r[userI] || '') : '';
        var ph = phoneI >= 0 ? (r[phoneI] || '') : '';
        var sub = state.subs.find(function (s) {
          return (un && String(s.elink || '').trim().toLowerCase() === un.trim().toLowerCase()) ||
            (nm && String(s.name || '').trim().toLowerCase() === nm.trim().toLowerCase());
        });
        if (!sub) { missed++; return; }
        if (un) sub.elink = un;
        if (ph) sub.phone = ph;
        if (priceI >= 0 && r[priceI]) { var p = Number(String(r[priceI]).replace(/[^0-9.]/g,'')); if (isFinite(p) && p >= 0) sub.price = Math.round(p); }
        if (statusI >= 0 && r[statusI]) sub.earthlinkStatus = r[statusI];
        sub.earthlinkSyncedAt = new Date().toISOString();
        updated++;
      });
      commit();
      out.textContent = 'تم استيراد الكشف: تحديث ' + updated + ' مشترك، غير مطابق ' + missed + '. لم يتم تغيير الديون أو تسجيل دفعات تلقائياً.';
      toast('اكتمل استيراد كشف الوكيل');
    };
    reader.onerror = function () { out.textContent = 'تعذرت قراءة الملف.'; };
    reader.readAsText(file, 'UTF-8');
  }

  /* ============================ الأحداث ============================ */

  function bind() {
    document.addEventListener('click', function (e) {
      var t = e.target.closest('[data-goto]');
      if (t) {
        if (t.tagName === 'A' && t.getAttribute('href')) return;
        e.preventDefault();
        showView(t.getAttribute('data-goto'));
        return;
      }
      var closeBtn = e.target.closest('[data-close]');
      if (closeBtn) {
        var sheet = closeBtn.closest('.sheet');
        closeSheet(sheet);
        return;
      }
      var wa = e.target.closest('[data-wa]');
      if (wa) { var s1 = state.subs.find(function (x) { return x.id === wa.getAttribute('data-wa'); }); if (s1) openWhatsApp(s1); return; }
      var pay = e.target.closest('[data-pay]');
      if (pay) { openPay(pay.getAttribute('data-pay')); return; }
      var addd = e.target.closest('[data-adddebt]');
      if (addd) { addDebtMonth(addd.getAttribute('data-adddebt')); return; }
      var dv = e.target.closest('[data-devedit]');
      if (dv) { openDeviceForm(dv.getAttribute('data-devedit')); return; }
      var dvd = e.target.closest('[data-devdel]');
      if (dvd) { deleteDevice(dvd.getAttribute('data-devdel')); return; }
      var elinkBtn = e.target.closest('[data-elink]');
      if (elinkBtn) {
        var tabSubs = document.querySelector('.tab[data-goto="subs"]');
        if (tabSubs) tabSubs.click();
        $('#searchInput').value = elinkBtn.getAttribute('data-elink');
        renderSubs();
        window.scrollTo(0, 0);
        return;
      }

      var hist = e.target.closest('[data-hist]');
      if (hist) { openHistory(hist.getAttribute('data-hist')); return; }
      var ed = e.target.closest('[data-edit]');
      if (ed) { openSubForm(ed.getAttribute('data-edit')); return; }
      var del = e.target.closest('[data-del]');
      if (del) { deleteSub(del.getAttribute('data-del')); return; }
    });

    $('#btnAdd').addEventListener('click', function () { openSubForm(null); });
    if ($('#btnAddDevice')) $('#btnAddDevice').addEventListener('click', function () { openDeviceForm(null); });
    if ($('#devForm')) $('#devForm').addEventListener('submit', submitDevice);
    if ($('#btnRtrSync')) $('#btnRtrSync').addEventListener('click', routerSync);
    if ($('#btnRadioSync')) $('#btnRadioSync').addEventListener('click', radioSync);
    if ($('#btnEarthlinkCsv')) $('#btnEarthlinkCsv').addEventListener('click', function () { $('#earthlinkCsv').click(); });
    if ($('#earthlinkCsv')) $('#earthlinkCsv').addEventListener('change', function (e) { var f = e.target.files && e.target.files[0]; if (f) earthlinkImport(f); e.target.value = ''; });
    if ($('#btnVpnCheck')) $('#btnVpnCheck').addEventListener('click', vpnCheck);
    if ($('#btnVpnImport')) $('#btnVpnImport').addEventListener('click', importDevices);
    $('#subForm').addEventListener('submit', submitSub);
    $('#payForm').addEventListener('submit', submitPay);

    $('#payFull').addEventListener('click', function () {
      var s = state.subs.find(function (x) { return x.id === currentPayId; });
      if (s) $('#payAmount').value = Math.max(num(s.debt), num(s.price));
    });
    $('#payMonth').addEventListener('click', function () {
      var s = state.subs.find(function (x) { return x.id === currentPayId; });
      if (s) $('#payAmount').value = num(s.price);
    });

    $('#searchInput').addEventListener('input', renderSubs);

    $('#filterChips').addEventListener('click', function (e) {
      var c = e.target.closest('.chip');
      if (!c) return;
      currentFilter = c.getAttribute('data-filter');
      $$('.chip').forEach(function (x) { x.classList.toggle('is-on', x === c); });
      renderSubs();
    });

    $('#btnRemindFirst').addEventListener('click', function () {
      var map = remindMap();
      var next = state.subs.filter(function (s) { return !map[s.id]; })[0];
      if (!next) { toast('تم الإرسال للجميع'); return; }
      if (!openWhatsApp(next)) return;
    });

    $('#btnCopyAll').addEventListener('click', function () {
      var sample = state.subs[0];
      var text = sample ? buildMessage(sample) : (state.settings.template || DEFAULT_TEMPLATE);
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(function () { toast('تم نسخ الرسالة'); },
          function () { openBackupText(text, 'انسخ الرسالة يدويًا.'); });
      } else {
        openBackupText(text, 'انسخ الرسالة يدويًا.');
      }
    });

    $('#btnBackupQuick').addEventListener('click', function () {
      showView('settings');
      exportBackup();
    });
    $('#btnExport').addEventListener('click', exportBackup);
    $('#btnImport').addEventListener('click', importBackup);
    $('#btnCopy').addEventListener('click', copyTextarea);
    $('#btnReset').addEventListener('click', resetAll);

    $('#btnSaveSettings').addEventListener('click', function () {
      var org = $('#setOrg').value.trim() || 'عباس';
      var price = num($('#setPrice').value) || 25000;
      var curr = $('#setCurrency').value.trim() || 'د.ع';
      var tpl = $('#setTemplate').value.trim() || DEFAULT_TEMPLATE;
      state.settings.org = org;
      state.settings.defaultPrice = price;
      state.settings.currency = curr;
      state.settings.template = tpl;
      commit();
      toast('تم حفظ الإعدادات');
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') $$('.sheet').forEach(closeSheet);
    });
  }

  /* ============================ البدء ============================ */

  function init() {
    state = load();
    bind();
    renderAll();
    showView('home');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
