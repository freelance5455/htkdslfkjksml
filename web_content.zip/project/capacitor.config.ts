import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.dukaansaathi.app',
  appName: 'Dukaan Saathi',
  webDir: 'dist',
  backgroundColor: '#f8fafc',
  android: {
    allowMixedContent: false,
    backgroundColor: '#f8fafc',
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 1200,
      backgroundColor: '#059669',
      androidScaleType: 'CENTER_CROP',
      showSpinner: false,
      android: {
        backgroundColor: '#059669',
      },
    },
    StatusBar: {
      style: 'DARK',
      backgroundColor: '#059669',
    },
  },
};

export default config;
