package com.vtstudio.optimizer.ui

import android.media.AudioManager
import android.media.ToneGenerator
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vtstudio.optimizer.ui.theme.Crimson
import com.vtstudio.optimizer.ui.theme.Graphite
import com.vtstudio.optimizer.ui.theme.GraphiteLine
import com.vtstudio.optimizer.ui.theme.GraphiteSoft
import com.vtstudio.optimizer.ui.theme.Ink
import com.vtstudio.optimizer.ui.theme.TextPrimary
import com.vtstudio.optimizer.ui.theme.TextSecondary
import java.time.OffsetDateTime
import java.time.format.DateTimeFormatter

val LocalSoundEnabled = compositionLocalOf { true }

private val DATE_FORMAT = DateTimeFormatter.ofPattern("dd/MM/yyyy")

fun formatDate(iso: String?): String =
    iso?.let { runCatching { OffsetDateTime.parse(it).format(DATE_FORMAT) }.getOrNull() } ?: "-"

object Sfx {
    private var tone: ToneGenerator? = null

    fun click(enabled: Boolean) {
        if (!enabled) return
        val generator = tone ?: runCatching { ToneGenerator(AudioManager.STREAM_NOTIFICATION, 25) }.getOrNull() ?: return
        tone = generator
        generator.startTone(ToneGenerator.TONE_PROP_BEEP, 35)
    }
}

@Composable
fun DecoratedBackground(content: @Composable () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Ink)
            .background(
                Brush.radialGradient(
                    colors = listOf(Crimson.copy(alpha = 0.22f), Color.Transparent),
                    radius = 900f,
                ),
            ),
    ) {
        content()
    }
}

@Composable
fun BrandMark(modifier: Modifier = Modifier) {
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(
            modifier = Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)).background(Crimson),
            contentAlignment = Alignment.Center,
        ) {
            Text("VT", color = TextPrimary, fontWeight = FontWeight.Black, fontSize = 13.sp)
        }
        Text("VT ACCESS", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

@Composable
fun VtCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(GraphiteSoft)
            .border(1.dp, GraphiteLine, RoundedCornerShape(20.dp))
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        content = content,
    )
}

@Composable
fun VtButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, loading: Boolean = false) {
    val sound = LocalSoundEnabled.current
    Button(
        onClick = {
            Sfx.click(sound)
            onClick()
        },
        enabled = enabled && !loading,
        modifier = modifier.fillMaxWidth().height(52.dp),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Crimson,
            contentColor = TextPrimary,
            disabledContainerColor = Graphite,
            disabledContentColor = TextSecondary,
        ),
    ) {
        if (loading) {
            CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = TextPrimary)
        } else {
            Text(text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = TextPrimary)
}

@Composable
fun MutedText(text: String) {
    Text(text, color = TextSecondary, fontSize = 13.sp)
}

