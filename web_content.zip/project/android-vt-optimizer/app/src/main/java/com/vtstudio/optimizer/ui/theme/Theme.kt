package com.vtstudio.optimizer.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Ink = Color(0xFF090909)
val GraphiteSoft = Color(0xFF161616)
val Graphite = Color(0xFF242424)
val GraphiteLine = Color(0xFF2E2E2E)
val Crimson = Color(0xFF8F001A)
val CrimsonBright = Color(0xFFB0203A)
val TextPrimary = Color(0xFFF2F2F2)
val TextSecondary = Color(0xFFA8A8A8)
val Success = Color(0xFF7BD389)
val Warning = Color(0xFFE0B25C)
val Danger = Color(0xFFFF7A7A)

private val VtColors = darkColorScheme(
    primary = CrimsonBright,
    onPrimary = TextPrimary,
    secondary = Graphite,
    onSecondary = TextPrimary,
    background = Ink,
    onBackground = TextPrimary,
    surface = GraphiteSoft,
    onSurface = TextPrimary,
    surfaceVariant = Graphite,
    onSurfaceVariant = TextSecondary,
    outline = GraphiteLine,
    error = Danger,
)

@Composable
fun VtAccessTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = VtColors, content = content)
}
