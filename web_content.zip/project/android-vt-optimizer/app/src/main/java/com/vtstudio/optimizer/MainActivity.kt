package com.vtstudio.optimizer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.vtstudio.optimizer.data.Session
import com.vtstudio.optimizer.ui.AuthScreen
import com.vtstudio.optimizer.ui.HomeScreen
import com.vtstudio.optimizer.ui.theme.VtAccessTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val session = Session(applicationContext)
        setContent {
            VtAccessTheme { VtAccessRoot(session) }
        }
    }
}

@Composable
private fun VtAccessRoot(session: Session) {
    var token by remember { mutableStateOf(session.accessToken) }
    var email by remember { mutableStateOf(session.email.orEmpty()) }
    val activeToken = token
    if (activeToken == null) {
        AuthScreen(
            session = session,
            onAuthenticated = { tokens ->
                token = tokens.accessToken
                email = tokens.email
            },
        )
    } else {
        HomeScreen(
            session = session,
            token = activeToken,
            email = email,
            onSignedOut = {
                session.clear()
                token = null
            },
        )
    }
}
