package com.vtstudio.optimizer.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vtstudio.optimizer.data.AppItem
import com.vtstudio.optimizer.data.LicenseItem
import com.vtstudio.optimizer.ui.theme.Crimson
import com.vtstudio.optimizer.ui.theme.GraphiteLine
import com.vtstudio.optimizer.ui.theme.Success
import com.vtstudio.optimizer.ui.theme.TextPrimary
import com.vtstudio.optimizer.ui.theme.TextSecondary
import com.vtstudio.optimizer.ui.theme.Warning

@Composable
fun AccountTab(
    email: String,
    licenses: List<LicenseItem>?,
    apps: List<AppItem>?,
    soundEnabled: Boolean,
    onSoundChange: (Boolean) -> Unit,
    onSignOut: () -> Unit,
) {
    val active = licenses.orEmpty().filter { it.active }
    val expiries = active.mapNotNull { it.expiresAt }
    val planLabel = if (active.isEmpty()) "Sem plano ativo" else "VT ACCESS · ${active.size} licença(s)"
    val validityLabel = when {
        active.isEmpty() -> "Nenhuma licença ativa"
        expiries.isEmpty() -> "Sem prazo de validade"
        else -> "Válida até ${formatDate(expiries.min())}"
    }
    val name = email.substringBefore('@').replaceFirstChar { it.uppercase() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Column {
            Text("Conta", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = TextPrimary)
            MutedText("Seus dados, plano e histórico de ativação.")
        }

        VtCard {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Box(
                    modifier = Modifier
                        .size(68.dp)
                        .clip(RoundedCornerShape(34.dp))
                        .background(Crimson),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = email.firstOrNull()?.uppercaseChar()?.toString() ?: "V",
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 26.sp,
                    )
                }
                Column {
                    Text(name, color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                    MutedText(email)
                }
            }
        }

        VtCard {
            SectionTitle("Plano")
            Text(planLabel, color = TextPrimary, fontWeight = FontWeight.Medium)
            MutedText(validityLabel)
        }

        VtCard {
            SectionTitle("Histórico de ativação")
            when {
                licenses == null -> MutedText("Carregando histórico...")
                licenses.isEmpty() -> MutedText("Nenhuma KEY ativada ainda.")
                else -> licenses.forEach { license ->
                    val appName = apps.orEmpty().firstOrNull { it.id == license.appId }?.name ?: "Aplicativo"
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Column {
                            Text(appName, color = TextPrimary, fontWeight = FontWeight.Medium)
                            MutedText("Ativada em ${formatDate(license.activatedAt)}")
                        }
                        Text(
                            text = if (license.active) "Ativa" else "Inativa",
                            color = if (license.active) Success else Warning,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                        )
                    }
                }
            }
        }

        VtCard {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Efeitos sonoros", color = TextPrimary, fontWeight = FontWeight.Medium)
                    MutedText("Sons discretos ao tocar em botões")
                }
                Switch(
                    checked = soundEnabled,
                    onCheckedChange = onSoundChange,
                    colors = SwitchDefaults.colors(checkedTrackColor = Crimson, uncheckedTrackColor = GraphiteLine),
                )
            }
        }

        OutlinedButton(
            onClick = onSignOut,
            modifier = Modifier.fillMaxWidth().height52(),
            shape = RoundedCornerShape(14.dp),
        ) {
            Text("Sair da conta", color = TextSecondary, fontWeight = FontWeight.SemiBold)
        }
    }
}
