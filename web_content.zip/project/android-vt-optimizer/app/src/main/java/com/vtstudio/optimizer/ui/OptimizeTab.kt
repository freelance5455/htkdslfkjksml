package com.vtstudio.optimizer.ui

import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vtstudio.optimizer.data.ApiException
import com.vtstudio.optimizer.data.LicenseApi
import com.vtstudio.optimizer.data.Optimization
import com.vtstudio.optimizer.data.AppItem
import com.vtstudio.optimizer.ui.theme.Crimson
import com.vtstudio.optimizer.ui.theme.Danger
import com.vtstudio.optimizer.ui.theme.Graphite
import com.vtstudio.optimizer.ui.theme.TextPrimary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.IOException

private enum class RunPhase { Idle, Running, Done }

private const val RUN_DURATION_MS = 3200

@Composable
fun OptimizeTab(token: String, installationId: String, apps: List<AppItem>?) {
    val scope = rememberCoroutineScope()
    var selectedAppId by remember { mutableStateOf<String?>(null) }
    val app = apps.orEmpty().firstOrNull { it.id == selectedAppId } ?: apps.orEmpty().firstOrNull()
    var options by remember { mutableStateOf<List<Optimization>?>(null) }
    var optionsError by remember { mutableStateOf<String?>(null) }
    var chosen by remember { mutableStateOf(setOf<String>()) }
    var phase by remember { mutableStateOf(RunPhase.Idle) }

    val progress by animateFloatAsState(
        targetValue = if (phase == RunPhase.Idle) 0f else 1f,
        animationSpec = tween(durationMillis = RUN_DURATION_MS, easing = LinearOutSlowInEasing),
        label = "runProgress",
    )

    LaunchedEffect(app?.id) {
        options = null
        optionsError = null
        chosen = emptySet()
        phase = RunPhase.Idle
        val target = app ?: return@LaunchedEffect
        try {
            options = LicenseApi.optimizations(token, installationId, target.id)
        } catch (caught: ApiException) {
            optionsError = caught.message
        } catch (caught: IOException) {
            optionsError = "Sem conexão. Tente novamente."
        }
    }

    LaunchedEffect(phase) {
        if (phase == RunPhase.Running) {
            delay(RUN_DURATION_MS.toLong())
            phase = RunPhase.Done
        }
    }

    val selectedOptions = options.orEmpty().filter { it.id in chosen }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Column {
            Text("Otimização", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = TextPrimary)
            MutedText("Escolha as otimizações liberadas para o aplicativo.")
        }

        if (apps.isNullOrEmpty()) {
            VtCard {
                MutedText(
                    if (apps == null) "Carregando aplicativos..." else "Nenhum aplicativo liberado. Ative uma KEY na aba Aplicativos.",
                )
            }
            return@Column
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            apps.forEach { item ->
                FilterChip(
                    selected = item.id == app?.id,
                    onClick = { selectedAppId = item.id },
                    label = { Text(item.name) },
                )
            }
        }

        Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(
                progress = { progress },
                modifier = Modifier.size(200.dp),
                color = Crimson,
                trackColor = Graphite,
                strokeWidth = 10.dp,
            )
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = when (phase) {
                        RunPhase.Idle -> "${chosen.size}"
                        RunPhase.Running -> "..."
                        RunPhase.Done -> "OK"
                    },
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 36.sp,
                )
                MutedText(
                    when (phase) {
                        RunPhase.Idle -> "itens selecionados"
                        RunPhase.Running -> "otimizando"
                        RunPhase.Done -> "concluído"
                    },
                )
            }
        }

        optionsError?.let { Text(it, color = Danger, fontSize = 13.sp) }

        if (phase == RunPhase.Done) {
            VtCard {
                SectionTitle("Resultado")
                Text("${selectedOptions.size} itens processados", color = TextPrimary, fontWeight = FontWeight.SemiBold)
                selectedOptions.forEach { MutedText("• ${it.name}") }
                MutedText("Esta versão registra a execução. As alterações reais no aparelho ainda não estão ativas.")
                VtButton(text = "Nova execução", onClick = { phase = RunPhase.Idle })
            }
        } else {
            VtCard {
                SectionTitle("Otimizações disponíveis")
                when {
                    options == null && optionsError == null -> MutedText("Carregando otimizações...")
                    options.isNullOrEmpty() -> MutedText("Nenhuma otimização liberada para este aplicativo.")
                    else -> options.orEmpty().forEach { option ->
                        val selected = option.id in chosen
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable(enabled = phase == RunPhase.Idle) {
                                    chosen = if (selected) chosen - option.id else chosen + option.id
                                },
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            Checkbox(
                                checked = selected,
                                onCheckedChange = null,
                                colors = CheckboxDefaults.colors(checkedColor = Crimson),
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(option.name, color = TextPrimary, fontWeight = FontWeight.Medium)
                                option.description?.let { MutedText(it) }
                            }
                            Icon(Icons.Rounded.Bolt, contentDescription = null, tint = Color.Unspecified, modifier = Modifier.size(0.dp))
                        }
                    }
                }
            }
            Spacer(Modifier.height(4.dp))
            VtButton(
                text = "OTIMIZAR",
                onClick = { phase = RunPhase.Running },
                enabled = selectedOptions.isNotEmpty() && phase == RunPhase.Idle,
                loading = phase == RunPhase.Running,
            )
        }
    }
}
