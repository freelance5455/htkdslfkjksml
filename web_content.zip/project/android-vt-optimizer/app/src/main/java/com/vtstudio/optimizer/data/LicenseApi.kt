package com.vtstudio.optimizer.data

import com.vtstudio.optimizer.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class ApiException(message: String, val sessionExpired: Boolean = false) : Exception(message)

data class AuthTokens(val accessToken: String, val email: String)
data class AppItem(val id: String, val name: String, val version: String, val description: String?, val releaseVersion: String?)
data class LicenseItem(val appId: String, val installationId: String, val activatedAt: String, val expiresAt: String?, val active: Boolean)
data class Optimization(val id: String, val name: String, val description: String?)
data class Download(val url: String, val fileName: String, val checksum: String)

object LicenseApi {
    private const val LICENSE_PATH = "/functions/v1/client-license"
    private const val GENERIC_ERROR = "Não foi possível concluir. Tente novamente."

    suspend fun signUp(email: String, password: String): AuthTokens =
        withContext(Dispatchers.IO) {
            val json = send("/auth/v1/signup", JSONObject().put("email", email).put("password", password), null)
            tokensFrom(json, email)
        }

    suspend fun signIn(email: String, password: String): AuthTokens =
        withContext(Dispatchers.IO) {
            val json = send("/auth/v1/token?grant_type=password", JSONObject().put("email", email).put("password", password), null)
            tokensFrom(json, email)
        }

    suspend fun activate(token: String, installationId: String, key: String, deviceLabel: String): String =
        call(token, JSONObject().put("action", "activate").put("key", key).put("installation_id", installationId).put("device_label", deviceLabel))
            .optString("status")

    suspend fun apps(token: String): List<AppItem> {
        val json = call(token, JSONObject().put("action", "apps"))
        return json.optJSONArray("apps").objects().map {
            AppItem(
                id = it.getString("id"),
                name = it.getString("name"),
                version = it.getString("version"),
                description = it.str("description"),
                releaseVersion = it.str("release_version"),
            )
        }
    }

    suspend fun licenses(token: String): List<LicenseItem> {
        val json = call(token, JSONObject().put("action", "status"))
        return json.optJSONArray("licenses").objects().map {
            LicenseItem(
                appId = it.getString("app_id"),
                installationId = it.getString("installation_id"),
                activatedAt = it.getString("activated_at"),
                expiresAt = it.str("expires_at"),
                active = it.optBoolean("active"),
            )
        }
    }

    suspend fun optimizations(token: String, installationId: String, appId: String): List<Optimization> {
        val json = call(
            token,
            JSONObject().put("action", "optimizations").put("installation_id", installationId).put("app_id", appId),
        )
        return json.optJSONArray("optimizations").objects().map {
            Optimization(id = it.getString("id"), name = it.getString("name"), description = it.str("description"))
        }
    }

    suspend fun download(token: String, installationId: String, appId: String): Download {
        val json = call(token, JSONObject().put("action", "download").put("installation_id", installationId).put("app_id", appId))
        return Download(
            url = json.getString("url"),
            fileName = json.getString("file_name"),
            checksum = json.getString("checksum_sha256"),
        )
    }

    private suspend fun call(token: String, body: JSONObject): JSONObject =
        withContext(Dispatchers.IO) { send(LICENSE_PATH, body, token) }

    private fun tokensFrom(json: JSONObject, email: String): AuthTokens {
        val accessToken = json.optString("access_token")
        if (accessToken.isEmpty()) throw ApiException("Não foi possível abrir a sessão. Tente entrar novamente.")
        return AuthTokens(accessToken, json.optJSONObject("user")?.str("email") ?: email)
    }

    private fun send(path: String, body: JSONObject, bearer: String?): JSONObject {
        val connection = (URL(BuildConfig.SUPABASE_URL + path).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15_000
            readTimeout = 30_000
            setRequestProperty("apikey", BuildConfig.SUPABASE_ANON_KEY)
            setRequestProperty("Authorization", "Bearer ${bearer ?: BuildConfig.SUPABASE_ANON_KEY}")
            setRequestProperty("Content-Type", "application/json")
            doOutput = true
        }
        try {
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            val json = runCatching { JSONObject(text) }.getOrDefault(JSONObject())
            if (code !in 200..299) throw failureFor(path, code, json)
            return json
        } finally {
            connection.disconnect()
        }
    }

    private fun failureFor(path: String, code: Int, json: JSONObject): ApiException = when {
        path.startsWith("/auth/v1/token") && code in 400..403 -> ApiException("E-mail ou senha incorretos.")
        path.startsWith("/auth/v1/signup") -> ApiException("Não foi possível criar a conta. Verifique os dados e tente novamente.")
        code == 401 -> ApiException("Sua sessão expirou. Entre novamente.", sessionExpired = true)
        path == LICENSE_PATH -> ApiException(json.str("error") ?: GENERIC_ERROR)
        else -> ApiException(GENERIC_ERROR)
    }

    private fun JSONArray?.objects(): List<JSONObject> =
        if (this == null) emptyList() else (0 until length()).map { getJSONObject(it) }

    private fun JSONObject.str(key: String): String? = if (isNull(key)) null else optString(key).ifEmpty { null }
}
