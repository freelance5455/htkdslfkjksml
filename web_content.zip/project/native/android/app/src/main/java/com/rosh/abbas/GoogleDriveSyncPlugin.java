package com.rosh.abbas;

import android.app.Activity;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.IntentSenderRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import com.getcapacitor.*;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.PluginMethod;
import com.google.android.gms.auth.api.identity.AuthorizationRequest;
import com.google.android.gms.auth.api.identity.AuthorizationResult;
import com.google.android.gms.auth.api.identity.Identity;
import com.google.android.gms.common.api.Scope;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@CapacitorPlugin(name = "GoogleDriveSync")
public class GoogleDriveSyncPlugin extends Plugin {
    private static final String SCOPE = "https://www.googleapis.com/auth/drive.appdata";
    private static final String BACKUP_NAME = "abbas-backup.json";
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private ActivityResultLauncher<IntentSenderRequest> authLauncher;
    private PluginCall pendingCall;
    private String pendingAction;
    private String pendingData;

    @Override public void load() {
        authLauncher = getBridge().registerForActivityResult(
            new ActivityResultContracts.StartIntentSenderForResult(), this::onAuthorizationResult);
    }

    @PluginMethod public void connect(PluginCall call) {
        beginAuthorization(call, "connect", null);
    }

    @PluginMethod public void backup(PluginCall call) {
        String data = call.getString("data");
        if (data == null || data.isEmpty()) { call.reject("بيانات النسخة فارغة"); return; }
        beginAuthorization(call, "backup", data);
    }

    @PluginMethod public void restore(PluginCall call) {
        beginAuthorization(call, "restore", null);
    }

    private void beginAuthorization(PluginCall call, String action, String data) {
        pendingCall = call; pendingAction = action; pendingData = data;
        AuthorizationRequest request = AuthorizationRequest.builder()
            .setRequestedScopes(Collections.singletonList(new Scope(SCOPE))).build();
        Identity.getAuthorizationClient(getActivity()).authorize(request)
            .addOnSuccessListener(result -> {
                if (result.hasResolution()) {
                    authLauncher.launch(new IntentSenderRequest.Builder(result.getPendingIntent().getIntentSender()).build());
                } else {
                    executeWithToken(result.getAccessToken());
                }
            })
            .addOnFailureListener(e -> rejectPending("تعذر طلب صلاحية Google: " + e.getLocalizedMessage()));
    }

    private void onAuthorizationResult(ActivityResult result) {
        if (pendingCall == null) return;
        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null) {
            rejectPending("تم إلغاء إذن Google Drive"); return;
        }
        try {
            AuthorizationResult auth = Identity.getAuthorizationClient(getActivity()).getAuthorizationResultFromIntent(result.getData());
            executeWithToken(auth.getAccessToken());
        } catch (Exception e) { rejectPending("فشل تفويض Google: " + e.getLocalizedMessage()); }
    }

    private void executeWithToken(String token) {
        if (token == null || token.isEmpty()) { rejectPending("Google لم يرجع رمز وصول"); return; }
        final PluginCall call = pendingCall;
        final String action = pendingAction;
        final String data = pendingData;
        executor.execute(() -> {
            try {
                String restored = "";
                if ("backup".equals(action)) uploadOrUpdate(token, data);
                else if ("restore".equals(action)) restored = downloadBackup(token);
                JSObject ret = new JSObject();
                ret.put("data", restored);
                ret.put("message", "connect".equals(action) ? "تم منح التطبيق صلاحية Google Drive" : ("backup".equals(action) ? "تم حفظ النسخة في Google Drive" : "تم استرجاع النسخة من Google Drive"));
                getActivity().runOnUiThread(() -> { call.resolve(ret); clearPending(); });
            } catch (Exception e) {
                getActivity().runOnUiThread(() -> { call.reject("فشلت مزامنة Google Drive: " + e.getLocalizedMessage()); clearPending(); });
            }
        });
    }

    private void clearPending() { pendingCall = null; pendingAction = null; pendingData = null; }
    private void rejectPending(String message) { if (pendingCall != null) pendingCall.reject(message); clearPending(); }

    private String http(String url, String method, String token, byte[] body, String contentType) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod(method); c.setConnectTimeout(25000); c.setReadTimeout(25000);
        c.setRequestProperty("Authorization", "Bearer " + token);
        if (body != null) { c.setDoOutput(true); c.setRequestProperty("Content-Type", contentType); try (OutputStream os = c.getOutputStream()) { os.write(body); } }
        int code = c.getResponseCode(); InputStream is = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
        StringBuilder out = new StringBuilder();
        if (is != null) try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) { String line; while ((line = br.readLine()) != null) out.append(line); }
        c.disconnect();
        if (code < 200 || code >= 300) throw new Exception("Google Drive HTTP " + code + ": " + out);
        return out.toString();
    }

    private String findFile(String token) throws Exception {
        String q = "name='" + BACKUP_NAME + "' and trashed=false";
        String url = "https://www.googleapis.com/drive/v3/files?q=" + URLEncoder.encode(q, "UTF-8") + "&spaces=appDataFolder&fields=files(id,name)&pageSize=5";
        JSONArray files = new JSONObject(http(url, "GET", token, null, null)).optJSONArray("files");
        return files != null && files.length() > 0 ? files.getJSONObject(0).optString("id", null) : null;
    }

    private void uploadOrUpdate(String token, String data) throws Exception {
        String id = findFile(token); String boundary = "abbas_" + System.currentTimeMillis();
        JSONObject meta = new JSONObject().put("name", BACKUP_NAME);
        if (id == null) meta.put("parents", new JSONArray().put("appDataFolder"));
        String multipart = "--" + boundary + "\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n" + meta +
            "\r\n--" + boundary + "\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n" + data + "\r\n--" + boundary + "--";
        String endpoint = id == null ? "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id" :
            "https://www.googleapis.com/upload/drive/v3/files/" + id + "?uploadType=multipart&fields=id";
        http(endpoint, id == null ? "POST" : "PATCH", token, multipart.getBytes(StandardCharsets.UTF_8), "multipart/related; boundary=" + boundary);
    }

    private String downloadBackup(String token) throws Exception {
        String id = findFile(token);
        if (id == null) throw new Exception("ماكو نسخة احتياطية بهذا الحساب بعد");
        return http("https://www.googleapis.com/drive/v3/files/" + id + "?alt=media", "GET", token, null, null);
    }
}
