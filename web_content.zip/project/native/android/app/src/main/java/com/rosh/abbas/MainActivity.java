package com.rosh.abbas;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override public void onCreate(Bundle savedInstanceState) {
        registerPlugin(GoogleDriveSyncPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
