import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

// Allow large image uploads (base64)
app.use(express.json({ limit: "25mb" }));

// Initialize Gemini SDK with User-Agent header as required
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;
if (apiKey) {
  ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

// Health check
app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    hasApiKey: !!apiKey,
    timestamp: new Date().toISOString(),
  });
});

// Scan Receipt / Handwritten Slip endpoint using Gemini Vision
app.post("/api/scan-receipt", async (req, res) => {
  try {
    const { imageBase64, mimeType = "image/jpeg" } = req.body;

    if (!imageBase64) {
      return res.status(400).json({
        success: false,
        error: "Missing image data. Please provide a valid photo.",
      });
    }

    if (!ai) {
      return res.status(500).json({
        success: false,
        error: "Gemini API key is not configured on the server.",
      });
    }

    // Clean base64 string if it contains data URI prefix
    const cleanBase64 = imageBase64.replace(/^data:image\/[a-zA-Z0-9+.-]+;base64,/, "");

    const prompt = `You are a world-class OCR expert specializing in printed and handwritten receipts, invoices, bills, and shop slips ("parchis").
Your goal is to extract all financial item amounts and line items accurately so they can be summed in a smart calculator.

Types of receipts you handle:
1. Handwritten shop slips (e.g., Pakistani hardware, electrical, sanitary, mobile accessory, grocery, or general store "parchi" / katcha bill / pakka bill).
2. Printed supermarket, pharmacy, POS, and restaurant receipts.
3. Handwritten columns of expense figures or calculations on ruled or plain paper.

Rules for Extraction:
1. IDENTIFY EVERY ITEM AMOUNT:
   - Identify each item line's final cost/price.
   - For example, if a handwritten list has amounts like:
     360
     150
     250
     400
     1350
     300
     30
     450
     10
     500
     400
     200
     120
     Extract every single one of these 13 amounts as an item in "items"!
   - For labels: If item names are handwritten (in English, Urdu, or Roman Urdu such as "switch", "wire", "tape", "plug", "socket", "charger", "cable", "breaker", "sheet", "pipe"), transcribe or translate them reasonably.
   - If the label is difficult to read or missing, DO NOT SKIP THE AMOUNT! Use a helpful label like "Item 1", "Item 2", "Item 3 (Switch)", or transcribed text.

2. STRICT SMART FILTERING (DO NOT put these into 'items'):
   Carefully filter out non-price numbers and put them in "unrelatedNumbers":
   - Phone & mobile numbers (e.g. 0300-1234567, 0321-xxxxxxx, 0345-xxxxxxx, 042-xxxxxxx, 051-xxxxxxx, +92..., 555-...)
   - Dates & timestamps (e.g. 12/09/2026, 12-09-24, 14:30)
   - Invoice, bill, voucher, or token numbers (e.g. Bill # 142, Inv-9821)
   - Table serial numbers (1, 2, 3, 4, 5 in the "Sr. No" column - do NOT mistake sequential 1, 2, 3 for prices)
   - Shop registration, NTN, STRN, or GST numbers
   - Addresses and shop floor numbers
   - Quantity or unit counts (e.g. "2 pcs" or "10 mtr") unless the amount column is derived from them; extract the final line amount.

3. GRAND TOTAL vs LINE ITEMS:
   - If there is a sum or grand total at the bottom (e.g., labeled "Total", "Net", "Mizan", "Kul Raqam", "G.Total"), place it in "detectedTotal".
   - DO NOT duplicate the grand total as an individual line item inside "items". Only put the constituent item prices in "items".

4. RESILIENCE:
   - If ANY numbers or prices can be read in the image, extract them! Never return an empty list if there are readable numbers. The user can easily review, edit, or delete items on the next screen.

Return STRICT JSON matching this schema:
{
  "items": [
    {
      "label": "Switch / Socket",
      "amount": 360,
      "confidence": "high",
      "category": "price"
    },
    {
      "label": "Wire 2.5mm",
      "amount": 150,
      "confidence": "high",
      "category": "price"
    }
  ],
  "unrelatedNumbers": [
    {
      "label": "Mobile Contact",
      "value": "0300-4521980",
      "reason": "Shop mobile number"
    },
    {
      "label": "Date",
      "value": "12/09/2026",
      "reason": "Transaction date"
    }
  ],
  "detectedTotal": 4520,
  "notes": "13 handwritten line amounts detected"
}`;

    const imagePart = {
      inlineData: {
        mimeType: mimeType || "image/jpeg",
        data: cleanBase64,
      },
    };

    const textPart = {
      text: prompt,
    };

    // Use gemini-3.8-flash for rapid, accurate multimodal vision OCR
    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: { parts: [imagePart, textPart] },
      config: {
        responseMimeType: "application/json",
        temperature: 0.1,
      },
    });

    const responseText = response.text || "";
    let parsedData;
    try {
      parsedData = JSON.parse(responseText);
    } catch {
      // Fallback regex extract JSON
      const jsonMatch = responseText.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        parsedData = JSON.parse(jsonMatch[0]);
      } else {
        throw new Error("Unable to parse OCR response as JSON");
      }
    }

    const items = Array.isArray(parsedData.items) ? parsedData.items : [];
    const formattedItems = items
      .filter((it: any) => typeof it.amount === "number" || !isNaN(Number(it.amount)))
      .map((it: any, index: number) => ({
        id: `ocr-${Date.now()}-${index}`,
        label: String(it.label || `Item ${index + 1}`).trim(),
        amount: Number(it.amount),
        confidence: it.confidence || "high",
        category: it.category || "price",
        included: true,
      }));

    return res.json({
      success: true,
      items: formattedItems,
      unrelatedNumbers: parsedData.unrelatedNumbers || [],
      detectedTotal: parsedData.detectedTotal,
      notes: parsedData.notes || "",
    });
  } catch (error: any) {
    console.error("Error in /api/scan-receipt:", error);
    return res.status(500).json({
      success: false,
      error: error?.message || "Failed to process image OCR. Please try again.",
    });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Smart Calculator server running on http://localhost:${PORT}`);
  });
}

startServer();
