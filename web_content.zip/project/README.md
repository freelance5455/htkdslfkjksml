# VideoGenie Pro

> `index.html` aur `lite.html` APK builder ke liye hain (app ki screen). Baaki files (`app.py`, `pipeline.py`) computer par chalne wala asli video maker hain.

Topic ya script do -> ye banata hai: har scene ki image, awaaz (voice-over) ke saath video, thumbnail, SEO, tags aur script.
Lambi video (30 minute tak, 60 tak allowed) bhi ban sakti hai.

## Ye kahan chalta hai
Ye APK ke andar nahi chalta. Ye ek programme hai jo **computer (Windows/Mac/Linux)** par chalta hai,
ya **Android phone par Termux** me. Chalane ke baad aap browser me `http://127.0.0.1:5000` kholte ho.

## Windows
1. Python 3.10+ install karo (python.org, "Add to PATH" tick karo).
2. ffmpeg install karo (ffmpeg.org ya `winget install ffmpeg`).
3. Is folder me `start.bat` par double-click karo.
4. Browser me http://127.0.0.1:5000 kholo.

## Mac / Linux
```
chmod +x start.sh && ./start.sh
```
(ffmpeg pehle install karo: `brew install ffmpeg` ya `sudo apt install ffmpeg`)

## Android (Termux)
Termux F-Droid se install karo, phir:
```
pkg update
pkg install python ffmpeg python-pillow
pip install flask requests edge-tts
cd <is folder ka path>
python app.py
```
Phir Chrome me http://127.0.0.1:5000 kholo. Phone me render slow hota hai, 480p chuno.

## Keys (dono free)
- **Gemini API key** (aistudio.google.com): scene-wise AI script, image ideas aur SEO likhne ke liye. Quick Mode mein 5, 10, 20 ya 30 minute ke liye scene batches generate hote hain. Bina key ke basic template script milti hai.
- **Pexels key** (pexels.com/api): sirf tab, jab asli stock photos chahiye. Default "AI images" me key nahi chahiye.

Keys sirf aapke computer ki `config.json` me save hoti hain.

## Step 3: AI Script Generator
Quick Mode (`lite.html`) supports English, Hindi (Devanagari), and Marathi (Devanagari). Choose 5/10/20/30 minutes (20/40/80/120 scenes). Gemini writes the script in batches of up to 20 scenes so long scripts do not depend on a single very large response. Review/edit the generated script before moving to Video.

Note: Gemini API usage depends on the model's current quota, availability and billing rules. The API key is entered in the app/browser; do not share the key or publish this app with a hard-coded key. For a public production service, move key handling to a secured backend.

## Output
`output/<topic>/` me: `video.mp4`, `thumbnail.jpg`, `seo.txt` (titles, description, chapters, tags, hashtags), `script.txt`.

## Dhyan rakhne wali baatein
- **Awaaz ke liye internet chahiye** (Edge TTS). Hindi, Marathi aur English ke female/male voice options aur voice preview available hain. Har scene ka audio validate hota hai; speech fail hone par app error degi—silent audio ko successful output nahi maanegi.
- **Time lagta hai.** 30 minute ki video me lagbhag 120 images aur awaazen banti hain. PC par aam taur par 30-90 minute, phone par zyada. Screen on rakho.
- Beech me ruk jaye to "Resume the previous run" tick karke dobara chalao. Bani hui images/awaaz dobara nahi banti.
- AI images free service (Pollinations) se aati hain. Kabhi slow ya fail ho sakti hain. Fail hone par simple placeholder lagta hai (log me likha aata hai).
- AI-generated content (script, images, awaaz) YouTube par upload karte waqt platform ke AI-disclosure rules dekh lena.

## Phone app (APK) se jodna
`start-for-phone-app.bat` (ya `.sh`) chalao. Wo ek address dikhayega, jaise `http://192.168.1.5:5000`.
APK ke andar wo address daalo (APK ka ZIP `VideoGenie-APK.zip` me hai). Phone aur computer ek hi Wi-Fi par hone chahiye.
Agar app "http" address nahi kholta, to ngrok ya cloudflared se https link banao aur wo daalo.

## Hindi thumbnail
Thumbnail me Hindi text ke liye computer me Hindi font chahiye (Windows me Nirmala, Android me Noto hota hai).
Font na mile to thumbnail English text se banta hai aur log me Note dikhta hai.


## Step 7: AI Voice Generation
- Per-scene Edge TTS narration with retry and playable-audio validation.
- Long narration is split at sentence/word boundaries and recombined into one scene audio file.
- Voice preview endpoint: `/voice-preview`.
- English (India/US), Hindi and Marathi voice options, including male/female variants where available.
- No silent-audio fallback: if the speech service is unavailable, the render stops with a clear error.

## Step 8 – Background music and sound effects
The full workflow can now synthesize a simple ambient music bed locally with FFmpeg. Choose a mood (Auto, Calm, Happy, Adventure, Emotional, Suspense), set its level, or disable it. The music is ducked beneath narration automatically. Action/suspense scene wording can also trigger a subtle generated sound cue. These are synthetic effects, not a licensed music or realistic Foley library. FFmpeg and ffprobe must be installed and available on PATH.

## Step 10 – Professional video rendering
- Export sizes: 480p, 720p and 1080p for landscape, portrait and square formats.
- Scene joins support hard cuts or short video/audio crossfades; caption timing accounts for the overlap.
- MP4 encoding uses H.264 video, AAC audio, yuv420p and `+faststart` for broad playback compatibility.
- Compression choices: CRF 20 (higher quality/larger), 23 (balanced), 27 (smaller file).
- `render_report.json` records final dimensions, duration, codecs and file size. Final output is checked with `ffprobe` for both audio and video streams and the requested resolution.
- 1080p and long videos are resource-intensive. Use a computer for 20–30 minute or 1080p renders; on Android/Termux prefer 480p/720p and hard cuts to reduce memory, heat and processing time.
