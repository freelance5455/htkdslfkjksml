# CONGOLO — scaffold integrado (v0.1)

This is an early online lobby/account scaffold, not a finished game.

## Run
- Node.js 20+ recommended.
- `npm install`
- Set `JWT_SECRET` to a strong random secret. Set `PORT` if desired.
- `npm start`
- Open `http://localhost:3000`

SQLite persists user data and rooms in `congolo.sqlite` in the working directory. Do not deploy publicly without HTTPS, exact-origin CORS/socket configuration, rate limits, security review, backups and moderation. Passwords are bcrypt hashed.

## Included
- Username/password signup/login (minimum password length 8; user ID generated)
- User search and friend request send/accept/reject
- Private room code creation and room join; Socket.IO lobby notifications
- Lobby UI

## Not yet implemented
- Actual 3D board/seed model and launch physics integration
- authoritative gameplay, turn logic and anti-cheat validation
- room roster/max-6 enforcement, invites, matchmaking, friend removal, profile/statistics, password recovery, moderation
- deployment or live testing

This is a development starting point, not a production-ready service. Configure a production `JWT_SECRET`; never use the placeholder.
