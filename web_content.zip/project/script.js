/* ============================================================
   NOVA MUSIC — Application Logic
   Mobile music player with IndexedDB storage, Web Audio API
   visualizers, playlists, favorites, and full playback controls.
   Developed by Yassin Bekhouche
   ============================================================ */

'use strict';

/* ============================================================
   SECTION 1: IndexedDB Storage
   Stores song blobs and metadata persistently in the browser.
   ============================================================ */

const DB_NAME = 'nova-music-db';
const DB_VERSION = 1;
const STORE_SONGS = 'songs';      // {id, title, artist, album, duration, blob, artworkBlob, favorite, dateAdded}
const STORE_PLAYLISTS = 'playlists'; // {id, name, songIds:[], dateCreated}

let db = null;

/** Open (or create) the IndexedDB database with two object stores. */
function openDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = (e) => {
      const database = e.target.result;
      if (!database.objectStoreNames.contains(STORE_SONGS)) {
        database.createObjectStore(STORE_SONGS, { keyPath: 'id' });
      }
      if (!database.objectStoreNames.contains(STORE_PLAYLISTS)) {
        database.createObjectStore(STORE_PLAYLISTS, { keyPath: 'id' });
      }
    };
    req.onsuccess = () => { db = req.result; resolve(db); };
    req.onerror = () => reject(req.error);
  });
}

/** Generic add/put helper. */
function dbPut(store, value) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(store, 'readwrite');
    tx.objectStore(store).put(value);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

/** Generic get-all helper. */
function dbGetAll(store) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(store, 'readonly');
    const req = tx.objectStore(store).getAll();
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

/** Generic get-one helper. */
function dbGet(store, id) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(store, 'readonly');
    const req = tx.objectStore(store).get(id);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

/** Generic delete helper. */
function dbDelete(store, id) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(store, 'readwrite');
    tx.objectStore(store).delete(id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

/* ============================================================
   SECTION 2: App State
   Global state shared across UI components.
   ============================================================ */

const state = {
  songs: [],          // all songs from IndexedDB
  playlists: [],      // all playlists
  currentSong: null,  // currently loaded song object
  currentIndex: -1,    // index in the active queue
  queue: [],           // array of song ids currently playable
  queueName: 'Library',
  isPlaying: false,
  shuffle: false,
  repeat: 'off',       // 'off' | 'one' | 'all'
  volume: 0.8,
  currentView: 'library',
  currentPlaylistId: null,
  visualizerStyle: 'particles', // current visualizer style
  moreMenuSongId: null, // song id for the "more" modal
};

/* ============================================================
   SECTION 3: DOM References
   ============================================================ */

const $ = (id) => document.getElementById(id);
const audio = $('audioElement');

/* ============================================================
   SECTION 4: Utility Functions
   ============================================================ */

/** Format seconds as M:SS */
function formatTime(sec) {
  if (!sec || isNaN(sec)) return '0:00';
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${s.toString().padStart(2, '0')}`;
}

/** Generate a unique id */
function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 9);
}

/** Show a toast message */
let toastTimer = null;
function showToast(msg) {
  const toast = $('toast');
  toast.textContent = msg;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 2500);
}

/** Escape HTML to prevent injection in user-provided text */
function escapeHtml(str) {
  if (!str) return '';
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

/** Create an object URL from a blob, with caching */
const urlCache = new Map();
function getArtworkURL(artworkBlob) {
  if (!artworkBlob) return null;
  if (urlCache.has(artworkBlob)) return urlCache.get(artworkBlob);
  const url = URL.createObjectURL(artworkBlob);
  urlCache.set(artworkBlob, url);
  return url;
}

/* ============================================================
   SECTION 5: File Upload & Metadata Extraction
   Reads ID3 tags from MP3 files and stores everything in IndexedDB.
   ============================================================ */

/** Extract album artwork and metadata from an audio file's ID3 tags. */
function extractMetadata(file) {
  return new Promise((resolve) => {
    // Use FileReader to read the first part of the file for ID3v2 tags
    const sliceSize = 256 * 1024; // first 256KB should contain tags
    const reader = new FileReader();
    reader.onload = () => {
      const buf = reader.result;
      const result = parseID3v2(new Uint8Array(buf));
      resolve(result);
    };
    reader.onerror = () => resolve({});
    reader.readAsArrayBuffer(file.slice(0, sliceSize));
  });
}

/**
 * Minimal ID3v2 tag parser — extracts title, artist, album, and artwork.
 * Supports ID3v2.3 and v2.4 (most common for MP3 files).
 */
function parseID3v2(bytes) {
  const result = {};
  // Check for "ID3" header
  if (bytes.length < 10 || bytes[0] !== 0x49 || bytes[1] !== 0x44 || bytes[2] !== 0x33) {
    return result;
  }
  const versionMajor = bytes[3];
  // Calculate tag size using synchsafe integer
  let size = (bytes[6] << 21) | (bytes[7] << 14) | (bytes[8] << 7) | bytes[9];
  let offset = 10;

  // Parse frames
  while (offset < size + 10 && offset + 10 < bytes.length) {
    const frameId = String.fromCharCode(bytes[offset], bytes[offset+1], bytes[offset+2], bytes[offset+3]);
    if (bytes[offset] === 0) break; // padding

    let frameSize;
    if (versionMajor >= 4) {
      // ID3v2.4 synchsafe
      frameSize = (bytes[offset+4] << 21) | (bytes[offset+5] << 14) | (bytes[offset+6] << 7) | bytes[offset+7];
    } else {
      // ID3v2.3 standard
      frameSize = (bytes[offset+4] << 24) | (bytes[offset+5] << 16) | (bytes[offset+6] << 8) | bytes[offset+7];
    }
    const frameOffset = offset + 10;

    if (frameSize <= 0 || frameOffset + frameSize > bytes.length) break;

    try {
      if (frameId === 'TIT2') {
        result.title = decodeText(bytes, frameOffset, frameSize);
      } else if (frameId === 'TPE1' || frameId === 'TPE2') {
        if (!result.artist) result.artist = decodeText(bytes, frameOffset, frameSize);
      } else if (frameId === 'TALB') {
        result.album = decodeText(bytes, frameOffset, frameSize);
      } else if (frameId === 'APIC') {
        const pic = parseAPIC(bytes, frameOffset, frameSize);
        if (pic) result.artworkBlob = pic;
      }
    } catch (e) { /* skip malformed frame */ }

    offset = frameOffset + frameSize;
  }
  return result;
}

/** Decode text from ID3 frame (handles ISO-8859-1, UTF-16, UTF-8). */
function decodeText(bytes, offset, size) {
  if (size < 1) return '';
  const encoding = bytes[offset];
  let str = '';
  try {
    if (encoding === 0) {
      // ISO-8859-1
      str = new TextDecoder('iso-8859-1').decode(bytes.slice(offset + 1, offset + size));
    } else if (encoding === 1) {
      // UTF-16 with BOM
      str = new TextDecoder('utf-16').decode(bytes.slice(offset + 1, offset + size));
    } else if (encoding === 2) {
      // UTF-16BE
      str = new TextDecoder('utf-16be').decode(bytes.slice(offset + 1, offset + size));
    } else if (encoding === 3) {
      // UTF-8
      str = new TextDecoder('utf-8').decode(bytes.slice(offset + 1, offset + size));
    }
  } catch (e) { str = ''; }
  // Remove null terminators and trim
  return str.replace(/\0+$/g, '').trim();
}

/** Parse APIC frame to extract embedded artwork as a Blob. */
function parseAPIC(bytes, offset, size) {
  if (size < 14) return null;
  const encoding = bytes[offset];
  let pos = offset + 1;
  // Read MIME type (null-terminated)
  let mimeEnd = pos;
  while (mimeEnd < offset + size && bytes[mimeEnd] !== 0) mimeEnd++;
  const mime = String.fromCharCode(...bytes.slice(pos, mimeEnd));
  pos = mimeEnd + 1;
  // Skip picture type (1 byte)
  pos += 1;
  // Skip description (null-terminated, encoding-dependent)
  if (encoding === 1 || encoding === 2) {
    // UTF-16: null is two bytes
    while (pos < offset + size - 1 && !(bytes[pos] === 0 && bytes[pos+1] === 0)) pos += 2;
    pos += 2;
  } else {
    while (pos < offset + size && bytes[pos] !== 0) pos++;
    pos += 1;
  }
  // Remaining bytes are the image data
  const imgData = bytes.slice(pos, offset + size);
  if (imgData.length < 10) return null;
  // Determine image type from magic bytes
  let type = 'image/jpeg';
  if (imgData[0] === 0x89 && imgData[1] === 0x50) type = 'image/png';
  else if (imgData[0] === 0x47 && imgData[1] === 0x49) type = 'image/gif';
  return new Blob([imgData], { type });
}

/** Handle file upload: extract metadata, create song record, store in IndexedDB. */
async function handleFileUpload(files) {
  const audioFiles = Array.from(files).filter(f => f.type.startsWith('audio/') || /\.(mp3|wav|ogg|m4a|flac|aac)$/i.test(f.name));
  if (audioFiles.length === 0) {
    showToast('No valid audio files found');
    return;
  }

  showToast(`Processing ${audioFiles.length} file${audioFiles.length > 1 ? 's' : ''}...`);

  let added = 0;
  for (const file of audioFiles) {
    try {
      // Extract metadata (title, artist, album, artwork)
      const meta = await extractMetadata(file);

      // Get duration by loading into a temporary audio element
      const duration = await getAudioDuration(file);

      // Create song record
      const song = {
        id: uid(),
        title: meta.title || file.name.replace(/\.[^/.]+$/, ''),
        artist: meta.artist || 'Unknown Artist',
        album: meta.album || 'Unknown Album',
        duration: duration,
        blob: file,                    // store the actual file as a Blob
        artworkBlob: meta.artworkBlob || null,
        favorite: false,
        dateAdded: Date.now(),
      };

      await dbPut(STORE_SONGS, song);
      state.songs.push(song);
      added++;
    } catch (err) {
      console.error('Error adding file:', file.name, err);
    }
  }

  if (added > 0) {
    showToast(`${added} song${added > 1 ? 's' : ''} added to library`);
    renderLibrary();
    renderPlaylists();
  } else {
    showToast('Could not process audio files');
  }
}

/** Get audio duration from a file by creating a temporary audio element. */
function getAudioDuration(file) {
  return new Promise((resolve) => {
    const tempAudio = new Audio();
    tempAudio.preload = 'metadata';
    const url = URL.createObjectURL(file);
    tempAudio.onloadedmetadata = () => {
      const d = tempAudio.duration;
      URL.revokeObjectURL(url);
      resolve(isNaN(d) ? 0 : d);
    };
    tempAudio.onerror = () => {
      URL.revokeObjectURL(url);
      resolve(0);
    };
    tempAudio.src = url;
  });
}

/* ============================================================
   SECTION 6: Rendering — Library, Playlists, Favorites, Search
   ============================================================ */

/** Build a song item DOM element. */
function createSongItem(song, index, queue) {
  const item = document.createElement('div');
  item.className = 'song-item';
  item.dataset.songId = song.id;
  if (state.currentSong && state.currentSong.id === song.id) {
    item.classList.add('playing');
  }

  // Album artwork
  const artUrl = getArtworkURL(song.artworkBlob);
  const artHtml = artUrl
    ? `<img src="${artUrl}" alt="" />`
    : `<span class="song-art-placeholder">♪</span>`;

  item.innerHTML = `
    <div class="song-art">${artHtml}</div>
    <div class="song-info">
      <div class="song-name">${escapeHtml(song.title)}</div>
      <div class="song-meta">${escapeHtml(song.artist)} • ${escapeHtml(song.album)}</div>
    </div>
    <div class="song-equalizer"><span></span><span></span><span></span><span></span></div>
    <span class="song-duration">${formatTime(song.duration)}</span>
    <button class="song-more-btn" aria-label="More options">
      <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="5" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="12" cy="19" r="1"/></svg>
    </button>
  `;

  // Click to play
  item.addEventListener('click', (e) => {
    if (e.target.closest('.song-more-btn')) return;
    playSong(song.id, queue);
  });

  // More button
  const moreBtn = item.querySelector('.song-more-btn');
  moreBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    openMoreMenu(song.id);
  });

  return item;
}

/** Render the library song list. */
function renderLibrary() {
  const list = $('songList');
  list.innerHTML = '';

  if (state.songs.length === 0) {
    list.innerHTML = `
      <div class="empty-state" id="emptyLibrary">
        <div class="empty-icon">
          <svg viewBox="0 0 24 24" width="48" height="48" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>
        </div>
        <h3>No music yet</h3>
        <p>Upload your favorite tracks to get started</p>
        <button class="btn-primary" onclick="document.getElementById('fileInput').click()">
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
          <span>Upload Music</span>
        </button>
      </div>`;
    return;
  }

  // Sort by date added (newest first)
  const sorted = [...state.songs].sort((a, b) => b.dateAdded - a.dateAdded);
  const queue = sorted.map(s => s.id);
  sorted.forEach((song, i) => list.appendChild(createSongItem(song, i, queue)));
}

/** Render the playlists list. */
function renderPlaylists() {
  const list = $('playlistList');
  list.innerHTML = '';

  if (state.playlists.length === 0) {
    list.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">
          <svg viewBox="0 0 24 24" width="48" height="48" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M3 2v18"/><path d="M7 2v18"/><path d="M11 2v18"/><path d="M15 2v18"/><path d="M19 2v18"/></svg>
        </div>
        <h3>No playlists</h3>
        <p>Create a playlist to organize your music</p>
      </div>`;
    return;
  }

  state.playlists.forEach(pl => {
    const item = document.createElement('div');
    item.className = 'playlist-item';
    item.innerHTML = `
      <div class="playlist-art">
        <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 2v18"/><path d="M7 2v18"/><path d="M11 2v18"/><path d="M15 2v18"/><path d="M19 2v18"/></svg>
      </div>
      <div class="playlist-info">
        <div class="playlist-name">${escapeHtml(pl.name)}</div>
        <div class="playlist-count">${pl.songIds.length} song${pl.songIds.length !== 1 ? 's' : ''}</div>
      </div>
      <div class="playlist-actions">
        <button class="icon-btn rename-pl-btn" aria-label="Rename">
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
        </button>
        <button class="icon-btn delete-pl-btn" aria-label="Delete">
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
        </button>
      </div>`;
    item.addEventListener('click', (e) => {
      if (e.target.closest('.rename-pl-btn') || e.target.closest('.delete-pl-btn')) return;
      openPlaylistDetail(pl.id);
    });
    item.querySelector('.rename-pl-btn').addEventListener('click', (e) => {
      e.stopPropagation();
      openRenamePlaylist(pl.id);
    });
    item.querySelector('.delete-pl-btn').addEventListener('click', (e) => {
      e.stopPropagation();
      deletePlaylist(pl.id);
    });
    list.appendChild(item);
  });
}

/** Render playlist detail view (songs in a playlist). */
function renderPlaylistDetail(playlistId) {
  const playlist = state.playlists.find(p => p.id === playlistId);
  if (!playlist) return;

  $('playlistDetailTitle').textContent = playlist.name;
  const list = $('playlistSongs');
  list.innerHTML = '';

  if (playlist.songIds.length === 0) {
    list.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">
          <svg viewBox="0 0 24 24" width="48" height="48" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>
        </div>
        <h3>Empty playlist</h3>
        <p>Add songs from your library using the menu button</p>
      </div>`;
    return;
  }

  const queue = [...playlist.songIds];
  playlist.songIds.forEach((songId, i) => {
    const song = state.songs.find(s => s.id === songId);
    if (song) list.appendChild(createSongItem(song, i, queue));
  });
}

/** Render favorites view. */
function renderFavorites() {
  const list = $('favoritesList');
  list.innerHTML = '';

  const favorites = state.songs.filter(s => s.favorite);
  if (favorites.length === 0) {
    list.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">
          <svg viewBox="0 0 24 24" width="48" height="48" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
        </div>
        <h3>No favorites</h3>
        <p>Tap the heart icon on any song to add it here</p>
      </div>`;
    return;
  }

  const queue = favorites.map(s => s.id);
  favorites.forEach((song, i) => list.appendChild(createSongItem(song, i, queue)));
}

/** Render search results. */
function renderSearch(query) {
  const results = $('searchResults');
  const q = query.trim().toLowerCase();

  if (!q) {
    results.innerHTML = '<div class="search-empty">Start typing to search your library</div>';
    return;
  }

  const matches = state.songs.filter(s =>
    s.title.toLowerCase().includes(q) ||
    s.artist.toLowerCase().includes(q) ||
    (s.album && s.album.toLowerCase().includes(q))
  );

  if (matches.length === 0) {
    results.innerHTML = '<div class="search-empty">No songs found</div>';
    return;
  }

  results.innerHTML = '';
  const queue = matches.map(s => s.id);
  matches.forEach((song, i) => results.appendChild(createSongItem(song, i, queue)));
}

/* ============================================================
   SECTION 7: View Navigation
   ============================================================ */

function switchView(viewName) {
  state.currentView = viewName;
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.querySelectorAll('.side-menu-item').forEach(m => m.classList.remove('active'));

  const viewMap = {
    library: 'libraryView',
    playlists: 'playlistsView',
    favorites: 'favoritesView',
    about: 'aboutView',
  };

  if (viewMap[viewName]) {
    $(viewMap[viewName]).classList.add('active');
  }

  // Highlight menu item
  const menuItem = document.querySelector(`.side-menu-item[data-view="${viewName}"]`);
  if (menuItem) menuItem.classList.add('active');

  if (viewName === 'library') renderLibrary();
  if (viewName === 'playlists') renderPlaylists();
  if (viewName === 'favorites') renderFavorites();

  closeSideMenu();
}

function openPlaylistDetail(playlistId) {
  state.currentPlaylistId = playlistId;
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  $('playlistDetailView').classList.add('active');
  renderPlaylistDetail(playlistId);
  closeSideMenu();
}

/* ============================================================
   SECTION 8: Side Menu
   ============================================================ */

function openSideMenu() { $('sideMenu').classList.add('active'); }
function closeSideMenu() { $('sideMenu').classList.remove('active'); }

/* ============================================================
   SECTION 9: Search
   ============================================================ */

function openSearch() {
  $('searchOverlay').classList.add('active');
  setTimeout(() => $('searchInput').focus(), 300);
}
function closeSearch() {
  $('searchOverlay').classList.remove('active');
  $('searchInput').value = '';
  $('searchResults').innerHTML = '';
}

/* ============================================================
   SECTION 10: Audio Playback Engine
   Manages the HTMLAudioElement, queue, shuffle, repeat.
   ============================================================ */

/** Play a song by its id, setting the active queue. */
async function playSong(songId, queue) {
  state.queue = queue || state.songs.map(s => s.id);
  state.queueName = queue ? 'Selection' : 'Library';
  state.currentIndex = state.queue.indexOf(songId);

  const song = state.songs.find(s => s.id === songId);
  if (!song) return;

  state.currentSong = song;

  // Create object URL from the stored blob
  if (audio.src) URL.revokeObjectURL(audio.src);
  audio.src = URL.createObjectURL(song.blob);
  audio.volume = state.volume;

  try {
    await audio.play();
    state.isPlaying = true;
  } catch (err) {
    console.error('Playback failed:', err);
    showToast('Could not play this file');
  }

  updatePlayerUI();
  updateMiniPlayer();
  startVisualizer();
}

/** Toggle play/pause. */
function togglePlay() {
  if (!state.currentSong) {
    if (state.songs.length > 0) {
      playSong(state.songs[0].id);
    }
    return;
  }
  if (state.isPlaying) {
    audio.pause();
    state.isPlaying = false;
  } else {
    audio.play();
    state.isPlaying = true;
  }
  updatePlayerUI();
  updateMiniPlayer();
}

/** Play next song (respects shuffle). */
function nextSong() {
  if (state.queue.length === 0) return;
  let nextIndex;
  if (state.shuffle) {
    // Random next, avoiding the same song
    do {
      nextIndex = Math.floor(Math.random() * state.queue.length);
    } while (state.queue.length > 1 && nextIndex === state.currentIndex);
  } else {
    nextIndex = state.currentIndex + 1;
    if (nextIndex >= state.queue.length) {
      if (state.repeat === 'all') {
        nextIndex = 0;
      } else {
        // End of queue
        audio.pause();
        state.isPlaying = false;
        updatePlayerUI();
        return;
      }
    }
  }
  state.currentIndex = nextIndex;
  playSong(state.queue[nextIndex], state.queue);
}

/** Play previous song, or restart current if near the beginning. */
function prevSong() {
  if (state.queue.length === 0) return;
  // If more than 3 seconds in, restart current song
  if (audio.currentTime > 3) {
    audio.currentTime = 0;
    return;
  }
  let prevIndex = state.currentIndex - 1;
  if (prevIndex < 0) {
    if (state.repeat === 'all') {
      prevIndex = state.queue.length - 1;
    } else {
      prevIndex = 0;
    }
  }
  state.currentIndex = prevIndex;
  playSong(state.queue[prevIndex], state.queue);
}

/** Toggle shuffle mode. */
function toggleShuffle() {
  state.shuffle = !state.shuffle;
  $('shuffleBtn').classList.toggle('active', state.shuffle);
  showToast(state.shuffle ? 'Shuffle on' : 'Shuffle off');
}

/** Cycle repeat mode: off → all → one → off. */
function toggleRepeat() {
  const modes = ['off', 'all', 'one'];
  const idx = modes.indexOf(state.repeat);
  state.repeat = modes[(idx + 1) % modes.length];
  const btn = $('repeatBtn');
  btn.classList.remove('active');
  if (state.repeat !== 'off') {
    btn.classList.add('active');
    // Add "one" indicator
    if (state.repeat === 'one') {
      btn.innerHTML = `<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/><text x="12" y="15" fill="currentColor" font-size="7" text-anchor="middle" stroke="none">1</text></svg>`;
    } else {
      btn.innerHTML = `<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>`;
    }
  }
  showToast(state.repeat === 'off' ? 'Repeat off' : state.repeat === 'all' ? 'Repeat all' : 'Repeat one');
}

/** Toggle favorite on current song. */
async function toggleFavorite(songId) {
  const song = state.songs.find(s => s.id === songId);
  if (!song) return;
  song.favorite = !song.favorite;
  await dbPut(STORE_SONGS, song);
  updateFavoriteUI(song.favorite);
  if (state.currentView === 'favorites') renderFavorites();
  if (state.currentView === 'library') renderLibrary();
  showToast(song.favorite ? 'Added to favorites' : 'Removed from favorites');
}

/** Set volume (0–1). */
function setVolume(vol) {
  state.volume = Math.max(0, Math.min(1, vol));
  audio.volume = state.volume;
  $('volumeFill').style.width = (state.volume * 100) + '%';
}

/** Seek to a position (0–1 of total duration). */
function seek(ratio) {
  if (!audio.duration || isNaN(audio.duration)) return;
  audio.currentTime = ratio * audio.duration;
  updateProgress();
}

/* ============================================================
   SECTION 11: UI Updates (Player, Mini Player, Progress)
   ============================================================ */

function updatePlayerUI() {
  if (!state.currentSong) return;
  $('playerTitle').textContent = state.currentSong.title;
  $('playerArtist').textContent = state.currentSong.artist;

  // Album art
  const artUrl = getArtworkURL(state.currentSong.artworkBlob);
  const front = $('albumArtFront');
  if (artUrl) {
    front.innerHTML = `<img src="${artUrl}" alt="" />`;
  } else {
    front.innerHTML = `<span class="album-art-placeholder">♪</span>`;
  }

  // Play/pause icon
  const playIcon = $('playPauseIcon');
  if (state.isPlaying) {
    playIcon.innerHTML = '<rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/>';
  } else {
    playIcon.innerHTML = '<polygon points="5 3 19 12 5 21 5 3"/>';
  }

  // Album art rotation
  const albumArt = $('albumArt');
  const albumGlow = $('albumGlow');
  if (state.isPlaying) {
    albumArt.classList.add('spinning');
    albumGlow.classList.add('active');
  } else {
    albumArt.classList.remove('spinning');
    albumGlow.classList.remove('active');
  }

  // Favorite button
  updateFavoriteUI(state.currentSong.favorite);

  // Total time
  $('totalTime').textContent = formatTime(state.currentSong.duration);

  // Highlight current song in lists
  document.querySelectorAll('.song-item').forEach(item => {
    item.classList.toggle('playing', item.dataset.songId === state.currentSong.id);
  });
}

function updateFavoriteUI(isFav) {
  const btn = $('favoriteBtn');
  btn.classList.toggle('active', isFav);
}

function updateMiniPlayer() {
  const mini = $('miniPlayer');
  if (!state.currentSong) {
    mini.classList.add('hidden');
    mini.classList.remove('visible');
    return;
  }
  mini.classList.remove('hidden');
  mini.classList.add('visible');

  $('miniTitle').textContent = state.currentSong.title;
  $('miniArtist').textContent = state.currentSong.artist;

  const artUrl = getArtworkURL(state.currentSong.artworkBlob);
  const miniArt = $('miniArt');
  if (artUrl) {
    miniArt.innerHTML = `<img src="${artUrl}" alt="" />`;
  } else {
    miniArt.innerHTML = `<div class="mini-art-placeholder">♪</div>`;
  }

  // Mini play icon
  const miniIcon = $('miniPlayIcon');
  if (state.isPlaying) {
    miniIcon.innerHTML = '<rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/>';
  } else {
    miniIcon.innerHTML = '<polygon points="5 3 19 12 5 21 5 3"/>';
  }
}

function updateProgress() {
  if (!audio.duration || isNaN(audio.duration)) return;
  const ratio = audio.currentTime / audio.duration;
  $('progressFill').style.width = (ratio * 100) + '%';
  $('progressHandle').style.left = (ratio * 100) + '%';
  $('currentTime').textContent = formatTime(audio.currentTime);
  $('miniProgress').style.width = (ratio * 100) + '%';
}

/* ============================================================
   SECTION 12: Full Player Open/Close
   ============================================================ */

function openFullPlayer() {
  if (!state.currentSong) return;
  $('fullPlayer').classList.add('active');
  startVisualizer();
}
function closeFullPlayer() {
  $('fullPlayer').classList.remove('active');
}

/* ============================================================
   SECTION 13: Modals (More Menu, Playlist Picker, Create/Rename)
   ============================================================ */

function openMoreMenu(songId) {
  state.moreMenuSongId = songId;
  const song = state.songs.find(s => s.id === songId);
  if (!song) return;
  $('moreMenuSongInfo').querySelector('.more-song-title').textContent = song.title;
  $('moreMenuSongInfo').querySelector('.more-song-artist').textContent = song.artist;
  $('toggleFavoriteBtn').querySelector('span').textContent = song.favorite ? 'Remove from favorites' : 'Add to favorites';
  $('moreMenu').classList.remove('hidden');
}
function closeMoreMenu() {
  $('moreMenu').classList.add('hidden');
  state.moreMenuSongId = null;
}

function openPlaylistPicker(songId) {
  const list = $('playlistPickerList');
  list.innerHTML = '';
  if (state.playlists.length === 0) {
    list.innerHTML = '<div class="playlist-picker-empty">No playlists yet. Create one first.</div>';
  } else {
    state.playlists.forEach(pl => {
      const item = document.createElement('div');
      item.className = 'playlist-picker-item';
      const has = pl.songIds.includes(songId);
      item.innerHTML = `
        <div class="playlist-art">
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 2v18"/><path d="M7 2v18"/><path d="M11 2v18"/><path d="M15 2v18"/><path d="M19 2v18"/></svg>
        </div>
        <div class="playlist-info">
          <div class="playlist-name">${escapeHtml(pl.name)}</div>
          <div class="playlist-count">${has ? 'Already added' : pl.songIds.length + ' songs'}</div>
        </div>`;
      item.addEventListener('click', () => addSongToPlaylist(pl.id, songId));
      list.appendChild(item);
    });
  }
  $('playlistPicker').classList.remove('hidden');
}

async function addSongToPlaylist(playlistId, songId) {
  const pl = state.playlists.find(p => p.id === playlistId);
  if (!pl) return;
  if (!pl.songIds.includes(songId)) {
    pl.songIds.push(songId);
    await dbPut(STORE_PLAYLISTS, pl);
    showToast('Added to playlist');
  } else {
    showToast('Already in this playlist');
  }
  $('playlistPicker').classList.add('hidden');
  if (state.currentView === 'playlists') renderPlaylists();
  if (state.currentPlaylistId === playlistId) renderPlaylistDetail(playlistId);
}

async function deleteSong(songId) {
  // Remove from all playlists
  for (const pl of state.playlists) {
    const idx = pl.songIds.indexOf(songId);
    if (idx !== -1) {
      pl.songIds.splice(idx, 1);
      await dbPut(STORE_PLAYLISTS, pl);
    }
  }
  // Remove from IndexedDB
  await dbDelete(STORE_SONGS, songId);
  // Remove from state
  state.songs = state.songs.filter(s => s.id !== songId);

  // If current song, stop playback
  if (state.currentSong && state.currentSong.id === songId) {
    audio.pause();
    audio.src = '';
    state.currentSong = null;
    state.isPlaying = false;
    updateMiniPlayer();
    updatePlayerUI();
  }

  showToast('Song deleted');
  renderLibrary();
  renderPlaylists();
  if (state.currentPlaylistId) renderPlaylistDetail(state.currentPlaylistId);
  if (state.currentView === 'favorites') renderFavorites();
}

/* ============================================================
   SECTION 14: Playlist CRUD
   ============================================================ */

function openCreatePlaylistModal() {
  $('playlistNameInput').value = '';
  $('createPlaylistModal').classList.remove('hidden');
  setTimeout(() => $('playlistNameInput').focus(), 200);
}

async function createPlaylist() {
  const name = $('playlistNameInput').value.trim();
  if (!name) {
    showToast('Please enter a name');
    return;
  }
  const playlist = {
    id: uid(),
    name: name,
    songIds: [],
    dateCreated: Date.now(),
  };
  state.playlists.push(playlist);
  await dbPut(STORE_PLAYLISTS, playlist);
  $('createPlaylistModal').classList.add('hidden');
  showToast('Playlist created');
  renderPlaylists();
}

async function deletePlaylist(playlistId) {
  if (!confirm('Delete this playlist? (Songs will remain in your library)')) return;
  await dbDelete(STORE_PLAYLISTS, playlistId);
  state.playlists = state.playlists.filter(p => p.id !== playlistId);
  if (state.currentPlaylistId === playlistId) {
    switchView('playlists');
  }
  showToast('Playlist deleted');
  renderPlaylists();
}

function openRenamePlaylist(playlistId) {
  const pl = state.playlists.find(p => p.id === playlistId);
  if (!pl) return;
  $('renamePlaylistInput').value = pl.name;
  $('renamePlaylistModal').dataset.playlistId = playlistId;
  $('renamePlaylistModal').classList.remove('hidden');
  setTimeout(() => $('renamePlaylistInput').focus(), 200);
}

async function renamePlaylist() {
  const playlistId = $('renamePlaylistModal').dataset.playlistId;
  const name = $('renamePlaylistInput').value.trim();
  if (!name) {
    showToast('Please enter a name');
    return;
  }
  const pl = state.playlists.find(p => p.id === playlistId);
  if (pl) {
    pl.name = name;
    await dbPut(STORE_PLAYLISTS, pl);
  }
  $('renamePlaylistModal').classList.add('hidden');
  showToast('Playlist renamed');
  renderPlaylists();
  if (state.currentPlaylistId === playlistId) {
    $('playlistDetailTitle').textContent = name;
  }
}

/* ============================================================
   SECTION 15: 3D Audio Visualizer
   Uses Web Audio API (AnalyserNode) + Canvas 2D for real-time
   visualization. Multiple styles: particles, bars, waves,
   rings, galaxy. Optimized for mobile with capped DPR.
   ============================================================ */

let audioContext = null;
let analyser = null;
let sourceNode = null;
let dataArray = null;
let canvasCtx = null;
let canvas = null;
let animationId = null;
let particles = [];
let rings = [];
let galaxyStars = [];

/** Initialize the Web Audio API analyser (called once on first play). */
function initAudioContext() {
  if (audioContext) return;
  try {
    audioContext = new (window.AudioContext || window.webkitAudioContext)();
    analyser = audioContext.createAnalyser();
    analyser.fftSize = 256;
    analyser.smoothingTimeConstant = 0.8;
    sourceNode = audioContext.createMediaElementSource(audio);
    sourceNode.connect(analyser);
    analyser.connect(audioContext.destination);
    dataArray = new Uint8Array(analyser.frequencyBinCount);
  // Resume context if suspended (mobile autoplay policy)
    if (audioContext.state === 'suspended') {
      audioContext.resume();
    }
  } catch (err) {
    console.error('Web Audio API init failed:', err);
  }
}

/** Set up the canvas with proper DPR scaling for crisp rendering on mobile. */
function initCanvas() {
  canvas = $('visualizerCanvas');
  canvasCtx = canvas.getContext('2d');
  resizeCanvas();
}

function resizeCanvas() {
  if (!canvas) return;
  const dpr = Math.min(window.devicePixelRatio || 1, 2); // cap at 2x for performance
  const rect = canvas.getBoundingClientRect();
  canvas.width = rect.width * dpr;
  canvas.height = rect.height * dpr;
  canvasCtx.scale(dpr, dpr);
}

/** Start the visualizer animation loop. */
function startVisualizer() {
  if (!audioContext) initAudioContext();
  if (audioContext && audioContext.state === 'suspended') {
    audioContext.resume();
  }
  if (!canvas) initCanvas();
  if (animationId) cancelAnimationFrame(animationId);
  animationId = requestAnimationFrame(animateVisualizer);
}

/** Stop the visualizer. */
function stopVisualizer() {
  if (animationId) {
    cancelAnimationFrame(animationId);
    animationId = null;
  }
}

/** Main animation loop — routes to the selected visualizer style. */
function animateVisualizer() {
  animationId = requestAnimationFrame(animateVisualizer);

  if (!canvasCtx || !canvas) return;

  const w = canvas.width / (Math.min(window.devicePixelRatio || 1, 2));
  const h = canvas.height / (Math.min(window.devicePixelRatio || 1, 2));

  // Get frequency data
  let freqData = null;
  let timeData = null;
  if (analyser && dataArray) {
    analyser.getByteFrequencyData(dataArray);
    freqData = dataArray;
    // Also get time-domain data for waveforms
    timeData = new Uint8Array(analyser.fftSize);
    analyser.getByteTimeDomainData(timeData);
  }

  // Clear with fade for trail effect
  canvasCtx.fillStyle = 'rgba(5, 5, 15, 0.15)';
  canvasCtx.fillRect(0, 0, w, h);

  const style = state.visualizerStyle;
  switch (style) {
    case 'particles': drawParticles(w, h, freqData); break;
    case 'bars':      drawBars(w, h, freqData); break;
    case 'waves':     drawWaves(w, h, timeData); break;
    case 'rings':     drawRings(w, h, freqData); break;
    case 'galaxy':    drawGalaxy(w, h, freqData); break;
  }
}

/* ---------- Visualizer Style 1: Particles ---------- */
function drawParticles(w, h, freqData) {
  // Initialize particles on first run
  if (particles.length === 0) {
    for (let i = 0; i < 80; i++) {
      particles.push({
        x: Math.random() * w,
        y: Math.random() * h,
        vx: (Math.random() - 0.5) * 0.5,
        vy: (Math.random() - 0.5) * 0.5,
        size: Math.random() * 3 + 1,
        hue: Math.random() * 60 + 200, // blue to teal range
      });
    }
  }

  // Calculate overall energy
  let energy = 0;
  if (freqData) {
    for (let i = 0; i < freqData.length; i++) energy += freqData[i];
    energy /= freqData.length * 255;
  }

  particles.forEach((p, i) => {
    // Get frequency value for this particle
    const freqIdx = Math.floor((i / particles.length) * (freqData ? freqData.length : 64));
    const freqVal = freqData ? freqData[freqIdx] / 255 : 0;

    // Move particles
    p.x += p.vx * (1 + energy * 3);
    p.y += p.vy * (1 + energy * 3);

    // Bounce off edges
    if (p.x < 0 || p.x > w) p.vx *= -1;
    if (p.y < 0 || p.y > h) p.vy *= -1;

    // Size reacts to frequency
    const size = p.size * (1 + freqVal * 4);

    // Draw glowing particle
    const glow = size * 3;
    const grad = canvasCtx.createRadialGradient(p.x, p.y, 0, p.x, p.y, glow);
    grad.addColorStop(0, `hsla(${p.hue}, 80%, 60%, ${0.8 + freqVal * 0.2})`);
    grad.addColorStop(0.5, `hsla(${p.hue}, 80%, 50%, ${0.3 + freqVal * 0.3})`);
    grad.addColorStop(1, `hsla(${p.hue}, 80%, 50%, 0)`);
    canvasCtx.fillStyle = grad;
    canvasCtx.beginPath();
    canvasCtx.arc(p.x, p.y, glow, 0, Math.PI * 2);
    canvasCtx.fill();

    // Core
    canvasCtx.fillStyle = `hsla(${p.hue}, 90%, 70%, ${0.9 + freqVal * 0.1})`;
    canvasCtx.beginPath();
    canvasCtx.arc(p.x, p.y, size, 0, Math.PI * 2);
    canvasCtx.fill();

    // Connect nearby particles
    for (let j = i + 1; j < particles.length; j++) {
      const p2 = particles[j];
      const dx = p.x - p2.x;
      const dy = p.y - p2.y;
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist < 80) {
        canvasCtx.strokeStyle = `hsla(${p.hue}, 70%, 60%, ${(1 - dist / 80) * 0.3 * (1 + energy)})`;
        canvasCtx.lineWidth = 1;
        canvasCtx.beginPath();
        canvasCtx.moveTo(p.x, p.y);
        canvasCtx.lineTo(p2.x, p2.y);
        canvasCtx.stroke();
      }
    }
  });
}

/* ---------- Visualizer Style 2: Equalizer Bars ---------- */
function drawBars(w, h, freqData) {
  const barCount = 48;
  const barWidth = w / barCount;
  const centerY = h / 2;

  for (let i = 0; i < barCount; i++) {
    const freqIdx = Math.floor((i / barCount) * (freqData ? freqData.length : 64));
    const freqVal = freqData ? freqData[freqIdx] / 255 : 0;
    const barHeight = freqVal * h * 0.35;

    // Gradient color based on frequency position
    const hue = 200 + (i / barCount) * 80; // blue → teal → green
    const grad = canvasCtx.createLinearGradient(0, centerY - barHeight, 0, centerY + barHeight);
    grad.addColorStop(0, `hsla(${hue}, 80%, 60%, 0.9)`);
    grad.addColorStop(0.5, `hsla(${hue + 20}, 80%, 50%, 0.7)`);
    grad.addColorStop(1, `hsla(${hue}, 80%, 60%, 0.9)`);

    canvasCtx.fillStyle = grad;
    // Top bar (mirror effect)
    const x = i * barWidth + barWidth * 0.1;
    const bw = barWidth * 0.8;

    // Rounded bars (with fallback for older browsers without roundRect)
    const r = Math.min(bw / 2, 3);
    drawRoundedBar(x, centerY - barHeight, bw, barHeight, r, 'top');
    drawRoundedBar(x, centerY, bw, barHeight, r, 'bottom');

    // Glow on high-energy bars
    if (freqVal > 0.6) {
      canvasCtx.shadowBlur = 15;
      canvasCtx.shadowColor = `hsla(${hue}, 80%, 60%, 0.8)`;
      canvasCtx.fillRect(x, centerY - barHeight, bw, barHeight * 2);
      canvasCtx.shadowBlur = 0;
    }
  }
}

/** Draw a rounded bar — uses roundRect if available, falls back to fillRect. */
function drawRoundedBar(x, y, w, h, r, side) {
  if (h < 1) return;
  if (canvasCtx.roundRect) {
    canvasCtx.beginPath();
    if (side === 'top') {
      canvasCtx.roundRect(x, y, w, h, [r, r, 0, 0]);
    } else {
      canvasCtx.roundRect(x, y, w, h, [0, 0, r, r]);
    }
    canvasCtx.fill();
  } else {
    canvasCtx.fillRect(x, y, w, h);
  }
}

/* ---------- Visualizer Style 3: Animated Waves ---------- */
function drawWaves(w, h, timeData) {
  const centerY = h / 2;
  const samples = timeData ? timeData.length : 128;

  // Draw multiple layered waves
  for (let layer = 0; layer < 4; layer++) {
    const hue = 200 + layer * 30;
    const alpha = 0.6 - layer * 0.12;
    const amplitude = (40 + layer * 15);
    const yOffset = layer * 8;

    canvasCtx.strokeStyle = `hsla(${hue}, 80%, 60%, ${alpha})`;
    canvasCtx.lineWidth = 2 + layer * 0.5;
    canvasCtx.shadowBlur = 10;
    canvasCtx.shadowColor = `hsla(${hue}, 80%, 60%, 0.5)`;

    canvasCtx.beginPath();
    for (let i = 0; i <= samples; i++) {
      const x = (i / samples) * w;
      const sampleIdx = i % samples;
      const val = timeData ? (timeData[sampleIdx] - 128) / 128 : 0;
      const y = centerY + Math.sin(i * 0.05 + layer + performance.now() * 0.001) * 20 + val * amplitude + yOffset;
      if (i === 0) canvasCtx.moveTo(x, y);
      else canvasCtx.lineTo(x, y);
    }
    canvasCtx.stroke();
  }
  canvasCtx.shadowBlur = 0;
}

/* ---------- Visualizer Style 4: Glowing Rings ---------- */
function drawRings(w, h, freqData) {
  const cx = w / 2;
  const cy = h / 2;

  // Initialize rings
  if (rings.length === 0) {
    for (let i = 0; i < 5; i++) {
      rings.push({ radius: 50 + i * 30, rotation: 0, speed: 0.005 + i * 0.002 });
    }
  }

  // Calculate bass and treble energy
  let bass = 0, treble = 0;
  if (freqData) {
    for (let i = 0; i < 10; i++) bass += freqData[i];
    bass /= 10 * 255;
    for (let i = freqData.length - 20; i < freqData.length; i++) treble += freqData[i];
    treble /= 20 * 255;
  }

  rings.forEach((ring, i) => {
    ring.rotation += ring.speed * (1 + bass * 3);
    const freqIdx = Math.floor((i / rings.length) * (freqData ? freqData.length : 64));
    const freqVal = freqData ? freqData[freqIdx] / 255 : 0;
    const radius = ring.radius + freqVal * 30 + bass * 20;
    const hue = 200 + i * 40;

    // Draw ring with segments
    const segments = 64;
    for (let s = 0; s < segments; s++) {
      const angle = (s / segments) * Math.PI * 2 + ring.rotation;
      const segFreq = freqData ? freqData[Math.floor((s / segments) * freqData.length)] / 255 : 0;
      const segRadius = radius + segFreq * 15;

      canvasCtx.strokeStyle = `hsla(${hue + segFreq * 40}, 80%, 60%, ${0.3 + segFreq * 0.7})`;
      canvasCtx.lineWidth = 2 + segFreq * 3;
      canvasCtx.beginPath();
      canvasCtx.arc(cx, cy, segRadius, angle, angle + (Math.PI * 2 / segments) * 0.8);
      canvasCtx.stroke();
    }

    // Center glow
    if (i === 0) {
      const glowGrad = canvasCtx.createRadialGradient(cx, cy, 0, cx, cy, radius);
      glowGrad.addColorStop(0, `hsla(${hue}, 80%, 60%, ${0.3 + bass * 0.4})`);
      glowGrad.addColorStop(1, `hsla(${hue}, 80%, 60%, 0)`);
      canvasCtx.fillStyle = glowGrad;
      canvasCtx.beginPath();
      canvasCtx.arc(cx, cy, radius, 0, Math.PI * 2);
      canvasCtx.fill();
    }
  });
}

/* ---------- Visualizer Style 5: Galaxy Spiral ---------- */
function drawGalaxy(w, h, freqData) {
  const cx = w / 2;
  const cy = h / 2;

  // Initialize galaxy stars
  if (galaxyStars.length === 0) {
    for (let i = 0; i < 150; i++) {
      const arm = Math.floor(Math.random() * 3);
      const dist = Math.random() * Math.min(w, h) * 0.4;
      galaxyStars.push({
        angle: arm * (Math.PI * 2 / 3) + dist * 0.02,
        dist: dist,
        size: Math.random() * 2 + 0.5,
        hue: 200 + Math.random() * 80,
        speed: 0.002 + Math.random() * 0.003,
      });
    }
  }

  // Overall energy
  let energy = 0;
  if (freqData) {
    for (let i = 0; i < freqData.length; i++) energy += freqData[i];
    energy /= freqData.length * 255;
  }

  // Draw spiral arms
  galaxyStars.forEach((star, i) => {
    star.angle += star.speed * (1 + energy * 2);
    const freqIdx = Math.floor((i / galaxyStars.length) * (freqData ? freqData.length : 64));
    const freqVal = freqData ? freqData[freqIdx] / 255 : 0;

    const x = cx + Math.cos(star.angle) * star.dist * (1 + energy * 0.3);
    const y = cy + Math.sin(star.angle) * star.dist * (1 + energy * 0.3);
    const size = star.size * (1 + freqVal * 3);

    // Glow
    const grad = canvasCtx.createRadialGradient(x, y, 0, x, y, size * 4);
    grad.addColorStop(0, `hsla(${star.hue}, 80%, 70%, ${0.8 + freqVal * 0.2})`);
    grad.addColorStop(1, `hsla(${star.hue}, 80%, 60%, 0)`);
    canvasCtx.fillStyle = grad;
    canvasCtx.beginPath();
    canvasCtx.arc(x, y, size * 4, 0, Math.PI * 2);
    canvasCtx.fill();

    // Core
    canvasCtx.fillStyle = `hsla(${star.hue}, 90%, 80%, ${0.9})`;
    canvasCtx.beginPath();
    canvasCtx.arc(x, y, size, 0, Math.PI * 2);
    canvasCtx.fill();
  });

  // Central glowing core
  const coreRadius = 30 + energy * 40;
  const coreGrad = canvasCtx.createRadialGradient(cx, cy, 0, cx, cy, coreRadius);
  coreGrad.addColorStop(0, `hsla(220, 80%, 70%, ${0.4 + energy * 0.4})`);
  coreGrad.addColorStop(0.5, `hsla(200, 80%, 60%, ${0.2 + energy * 0.3})`);
  coreGrad.addColorStop(1, `hsla(200, 80%, 60%, 0)`);
  canvasCtx.fillStyle = coreGrad;
  canvasCtx.beginPath();
  canvasCtx.arc(cx, cy, coreRadius, 0, Math.PI * 2);
  canvasCtx.fill();
}

/* ============================================================
   SECTION 16: Event Listeners
   ============================================================ */

function setupEventListeners() {
  // --- File upload ---
  $('fileInput').addEventListener('change', (e) => {
    if (e.target.files.length > 0) {
      handleFileUpload(e.target.files);
      e.target.value = ''; // reset for re-upload
    }
  });
  $('uploadBtn').addEventListener('click', () => $('fileInput').click());
  $('uploadMenuBtn').addEventListener('click', () => {
    closeSideMenu();
    $('fileInput').click();
  });

  // --- Header buttons ---
  $('searchBtn').addEventListener('click', openSearch);
  $('menuBtn').addEventListener('click', openSideMenu);
  $('logoBtn').addEventListener('click', () => switchView('library'));

  // --- Side menu navigation ---
  document.querySelectorAll('.side-menu-item[data-view]').forEach(item => {
    item.addEventListener('click', () => switchView(item.dataset.view));
  });
  $('menuBackdrop').addEventListener('click', closeSideMenu);

  // --- Search ---
  $('searchInput').addEventListener('input', (e) => renderSearch(e.target.value));
  $('closeSearchBtn').addEventListener('click', closeSearch);

  // --- Playlist detail ---
  $('backFromPlaylist').addEventListener('click', () => switchView('playlists'));
  $('playlistPlayBtn').addEventListener('click', () => {
    if (state.currentPlaylistId) {
      const pl = state.playlists.find(p => p.id === state.currentPlaylistId);
      if (pl && pl.songIds.length > 0) {
        playSong(pl.songIds[0], pl.songIds);
        openFullPlayer();
      }
    }
  });

  // --- Create playlist ---
  $('createPlaylistBtn').addEventListener('click', openCreatePlaylistModal);
  $('confirmCreatePlaylist').addEventListener('click', createPlaylist);
  $('cancelCreatePlaylist').addEventListener('click', () => $('createPlaylistModal').classList.add('hidden'));
  $('playlistNameInput').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') createPlaylist();
  });

  // --- Rename playlist ---
  $('confirmRenamePlaylist').addEventListener('click', renamePlaylist);
  $('cancelRenamePlaylist').addEventListener('click', () => $('renamePlaylistModal').classList.add('hidden'));
  $('renamePlaylistInput').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') renamePlaylist();
  });

  // --- Playback controls ---
  $('playPauseBtn').addEventListener('click', togglePlay);
  $('prevBtn').addEventListener('click', prevSong);
  $('nextBtn').addEventListener('click', nextSong);
  $('shuffleBtn').addEventListener('click', toggleShuffle);
  $('repeatBtn').addEventListener('click', toggleRepeat);
  $('favoriteBtn').addEventListener('click', () => {
    if (state.currentSong) toggleFavorite(state.currentSong.id);
  });

  // --- Mini player ---
  $('miniPlayer').addEventListener('click', (e) => {
    if (e.target.closest('.mini-play-btn')) {
      e.stopPropagation();
      togglePlay();
    } else {
      openFullPlayer();
    }
  });
  $('miniPlayBtn').addEventListener('click', (e) => { e.stopPropagation(); togglePlay(); });

  // --- Full player ---
  $('closePlayerBtn').addEventListener('click', closeFullPlayer);
  $('moreBtn').addEventListener('click', () => {
    if (state.currentSong) openMoreMenu(state.currentSong.id);
  });

  // --- Progress bar (seek) ---
  let isDraggingProgress = false;
  const progressBar = $('progressBar');
  function handleSeekEvent(e) {
    const rect = progressBar.getBoundingClientRect();
    const x = (e.touches ? e.touches[0].clientX : e.clientX) - rect.left;
    const ratio = Math.max(0, Math.min(1, x / rect.width));
    seek(ratio);
  }
  progressBar.addEventListener('mousedown', (e) => {
    isDraggingProgress = true;
    progressBar.classList.add('dragging');
    handleSeekEvent(e);
  });
  progressBar.addEventListener('touchstart', (e) => {
    isDraggingProgress = true;
    progressBar.classList.add('dragging');
    handleSeekEvent(e);
  }, { passive: true });
  document.addEventListener('mousemove', (e) => { if (isDraggingProgress) handleSeekEvent(e); });
  document.addEventListener('touchmove', (e) => { if (isDraggingProgress) handleSeekEvent(e); }, { passive: true });
  document.addEventListener('mouseup', () => { isDraggingProgress = false; progressBar.classList.remove('dragging'); });
  document.addEventListener('touchend', () => { isDraggingProgress = false; progressBar.classList.remove('dragging'); });

  // --- Volume bar ---
  const volumeBar = $('volumeBar');
  let isDraggingVol = false;
  function handleVolEvent(e) {
    const rect = volumeBar.getBoundingClientRect();
    const x = (e.touches ? e.touches[0].clientX : e.clientX) - rect.left;
    const ratio = Math.max(0, Math.min(1, x / rect.width));
    setVolume(ratio);
  }
  volumeBar.addEventListener('mousedown', (e) => { isDraggingVol = true; handleVolEvent(e); });
  volumeBar.addEventListener('touchstart', (e) => { isDraggingVol = true; handleVolEvent(e); }, { passive: true });
  document.addEventListener('mousemove', (e) => { if (isDraggingVol) handleVolEvent(e); });
  document.addEventListener('touchmove', (e) => { if (isDraggingVol) handleVolEvent(e); }, { passive: true });
  document.addEventListener('mouseup', () => { isDraggingVol = false; });
  document.addEventListener('touchend', () => { isDraggingVol = false; });

  // --- Visualizer style switcher ---
  document.querySelectorAll('.viz-dot').forEach(dot => {
    dot.addEventListener('click', () => {
      document.querySelectorAll('.viz-dot').forEach(d => d.classList.remove('active'));
      dot.classList.add('active');
      state.visualizerStyle = dot.dataset.viz;
      // Reset particle arrays for fresh start
      particles = [];
      rings = [];
      galaxyStars = [];
      showToast('Visualizer: ' + dot.dataset.viz.charAt(0).toUpperCase() + dot.dataset.viz.slice(1));
    });
  });

  // --- More menu ---
  $('addToPlaylistBtn').addEventListener('click', () => {
    const songId = state.moreMenuSongId;
    closeMoreMenu();
    openPlaylistPicker(songId);
  });
  $('toggleFavoriteBtn').addEventListener('click', () => {
    if (state.moreMenuSongId) toggleFavorite(state.moreMenuSongId);
    closeMoreMenu();
  });
  $('deleteSongBtn').addEventListener('click', () => {
    if (state.moreMenuSongId) {
      if (confirm('Delete this song from your library?')) {
        deleteSong(state.moreMenuSongId);
      }
    }
    closeMoreMenu();
  });
  $('cancelMoreBtn').addEventListener('click', closeMoreMenu);

  // --- Playlist picker ---
  $('cancelPlaylistPicker').addEventListener('click', () => $('playlistPicker').classList.add('hidden'));

  // --- Audio element events ---
  audio.addEventListener('timeupdate', updateProgress);
  audio.addEventListener('ended', () => {
    if (state.repeat === 'one') {
      audio.currentTime = 0;
      audio.play();
    } else {
      nextSong();
    }
  });
  audio.addEventListener('play', () => {
    state.isPlaying = true;
    updatePlayerUI();
    updateMiniPlayer();
    startVisualizer();
  });
  audio.addEventListener('pause', () => {
    state.isPlaying = false;
    updatePlayerUI();
    updateMiniPlayer();
  });

  // --- Resize ---
  window.addEventListener('resize', () => {
    resizeCanvas();
  });

  // --- Keyboard shortcuts (desktop) ---
  document.addEventListener('keydown', (e) => {
    if (e.target.tagName === 'INPUT') return;
    if (e.code === 'Space') { e.preventDefault(); togglePlay(); }
    if (e.code === 'ArrowRight') nextSong();
    if (e.code === 'ArrowLeft') prevSong();
  });
}

/* ============================================================
   SECTION 17: Initialization
   ============================================================ */

async function init() {
  try {
    // Open database
    await openDB();

    // Load songs and playlists from IndexedDB
    state.songs = await dbGetAll(STORE_SONGS);
    state.playlists = await dbGetAll(STORE_PLAYLISTS);

    // Sort songs by date added
    state.songs.sort((a, b) => b.dateAdded - a.dateAdded);

    // Set initial volume
    audio.volume = state.volume;
    $('volumeFill').style.width = (state.volume * 100) + '%';

    // Set up all event listeners
    setupEventListeners();

    // Initialize canvas
    initCanvas();

    // Render initial views
    renderLibrary();
    renderPlaylists();

    // Hide splash screen after a delay
    setTimeout(() => {
      $('splash').classList.add('hidden');
    }, 1500);

  } catch (err) {
    console.error('Initialization error:', err);
    showToast('Could not initialize app. Please refresh.');
  }
}

// Start the app when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
