/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        'rose-gold': '#e8b4b8',
        'rose-gold-bright': '#f0c6cb',
        'gold': '#d4af7a',
        'gold-bright': '#e8c9a0',
        'midnight': '#150a2e',
        'midnight-deep': '#0a0518',
      },
    },
  },
  plugins: [],
};
