/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        display: ['Sora', 'Inter', 'system-ui', 'sans-serif'],
      },
      colors: {
        ink: {
          DEFAULT: '#090909',
        },
        graphite: {
          50: '#f4f4f5',
          100: '#e4e4e7',
          300: '#a1a1aa',
          400: '#8a8a93',
          500: '#5c5c66',
          600: '#3a3a42',
          700: '#2e2e2e',
          800: '#242424',
          900: '#161616',
        },
        crimson: {
          50: '#fdf2f4',
          100: '#fbe3e8',
          200: '#f5b8c4',
          300: '#e97f95',
          400: '#d14a68',
          500: '#b0243f',
          600: '#a0112f',
          700: '#8F001A',
          800: '#6f0014',
          900: '#4a000d',
        },
        success: {
          400: '#4ade80',
          500: '#22c55e',
          900: '#052e16',
        },
        warning: {
          400: '#fbbf24',
          500: '#f59e0b',
          900: '#451a03',
        },
        danger: {
          400: '#fb7185',
          500: '#f43f5e',
          900: '#4c0519',
        },
      },
    },
  },
  plugins: [],
};
