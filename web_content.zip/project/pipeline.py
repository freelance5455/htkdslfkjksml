"""VideoGenie pipeline: script -> scene images -> voice-over -> video + thumbnail + SEO."""
import asyncio, hashlib, json, math, os, random, re, shutil, subprocess, time
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import quote
import requests
from PIL import Image, ImageDraw, ImageFont

SEC_PER_SCENE = 15          # one scene is roughly 15 seconds of narration
WORDS_PER_SCENE = 38
FPS = 25
LANGS = {
    "en-IN": {"label": "English", "voice": "en-IN-NeerjaNeural"},
    "en-US": {"label": "English", "voice": "en-US-AriaNeural"},
    "hi":    {"label": "Hindi (Devanagari script)", "voice": "hi-IN-SwaraNeural"},
    "hi-m":  {"label": "Hindi (Devanagari script)", "voice": "hi-IN-MadhurNeural"},
    "mr":    {"label": "Marathi (female)", "voice": "mr-IN-AarohiNeural"},
    "mr-m":  {"label": "Marathi (male)", "voice": "mr-IN-ManoharNeural"},
    "en-IN-m": {"label": "English (India, male)", "voice": "en-IN-PrabhatNeural"},
}
SIZES = {  # (ratio, quality) -> (w, h)
    ("16:9", "1080"): (1920, 1080), ("16:9", "720"): (1280, 720), ("16:9", "480"): (854, 480),
    ("9:16", "1080"): (1080, 1920), ("9:16", "720"): (720, 1280), ("9:16", "480"): (480, 854),
    ("1:1", "1080"): (1080, 1080), ("1:1", "720"): (720, 720), ("1:1", "480"): (720, 720),
}
STOP = set("the a an and or but if of to in on at for with from by is are was were be been it this that these those you your we our they their i he she as so not no can will just about into than then there what when which who how why do does did have has had more most very also".split())


class Cancelled(Exception):
    pass


def need_ffmpeg():
    if not (shutil.which("ffmpeg") and shutil.which("ffprobe")):
        raise RuntimeError("ffmpeg is not installed. Install it first (see README), then try again.")


def sh(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        raise RuntimeError("ffmpeg error: " + (r.stderr or "")[-600:])
    return r.stdout


def duration(path):
    return float(sh(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", path]).strip())


def slug(s):
    s = re.sub(r"[^\w]+", "-", s.lower(), flags=re.U).strip("-")
    return (s[:40] or "video")


def clean_tts(t):
    t = re.sub(r"[*_#`~>\[\]]", "", t)
    return re.sub(r"\s+", " ", t).strip()


def fmt_time(sec):
    sec = int(sec)
    h, m, s = sec // 3600, (sec % 3600) // 60, sec % 60
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"



# ------------------------------------------------------- music and sound effects
MUSIC_PRESETS = {
    "auto": (220, 277, 330), "calm": (196, 247, 294),
    "happy": (262, 330, 392), "adventure": (220, 330, 440),
    "emotional": (174, 220, 262), "suspense": (110, 164, 207),
}

def make_music_bed(seconds, mood, out, volume=0.13):
    """Create a royalty-free synthetic ambient bed locally with FFmpeg."""
    seconds = max(1.0, float(seconds))
    freqs = MUSIC_PRESETS.get(mood, MUSIC_PRESETS["auto"])
    # Gentle layered tones, slow tremolo and fade. No external music download/API.
    src = (f"sine=frequency={freqs[0]}:duration={seconds},volume=0.34[a];"
           f"sine=frequency={freqs[1]}:duration={seconds},volume=0.22[b];"
           f"sine=frequency={freqs[2]}:duration={seconds},volume=0.14[c];"
           "[a][b][c]amix=inputs=3:normalize=0,lowpass=f=1800,"
           f"volume={max(0.01,min(0.4,float(volume))):.3f},"
           f"afade=t=in:st=0:d=2,afade=t=out:st={max(0,seconds-3):.3f}:d=3,"
           "aformat=sample_fmts=fltp:sample_rates=44100:channel_layouts=stereo[out]")
    sh(["ffmpeg", "-y", "-f", "lavfi", "-i", f"anullsrc=r=44100:cl=stereo:d={seconds}",
        "-filter_complex", src, "-map", "[out]", "-t", f"{seconds:.3f}", "-c:a", "libmp3lame", "-q:a", "5", out])
    validate_audio(out)
    return out

def make_scene_sfx(text, seconds, out):
    """Create a short subtle whoosh/impact cue based on scene wording."""
    words = (text or "").lower()
    action = any(w in words for w in ("run", "fight", "crash", "attack", "jump", "fall", "explod", "chase", " удар"))
    suspense = any(w in words for w in ("mystery", "dark", "shadow", "monster", "ghost", "secret", "fear", "horror"))
    if not action and not suspense:
        return None
    length = min(1.25, max(0.45, float(seconds) * 0.22))
    freq = 95 if action else 68
    filt = (f"sine=frequency={freq}:duration={length},"
            f"afade=t=in:st=0:d=0.08,afade=t=out:st={max(0.05,length-0.35):.3f}:d=0.35,"
            "volume=0.16,lowpass=f=500")
    sh(["ffmpeg", "-y", "-f", "lavfi", "-i", filt, "-ac", "2", "-ar", "44100",
        "-c:a", "libmp3lame", "-q:a", "7", out])
    return out

def mix_scene_audio(voice_path, sfx_path, out):
    """Overlay a brief effect at the start while preserving the complete narration."""
    if not sfx_path:
        return voice_path
    sh(["ffmpeg", "-y", "-i", voice_path, "-i", sfx_path, "-filter_complex",
        "[1:a]adelay=250|250,volume=0.55[fx];[0:a][fx]amix=inputs=2:duration=first:dropout_transition=0:normalize=0[out]",
        "-map", "[out]", "-c:a", "libmp3lame", "-q:a", "4", out])
    validate_audio(out)
    return out

def add_music_to_video(video_path, music_path, out, music_volume=0.13):
    """Duck background music under narration and keep original video stream."""
    sh(["ffmpeg", "-y", "-i", video_path, "-i", music_path, "-filter_complex",
        f"[1:a]volume={max(0.01,min(0.4,float(music_volume))):.3f}[bg];"
        "[bg][0:a]sidechaincompress=threshold=0.025:ratio=8:attack=20:release=450[duck];"
        "[0:a][duck]amix=inputs=2:duration=first:dropout_transition=2:normalize=0[a]",
        "-map", "0:v:0", "-map", "[a]", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
        "-shortest", "-movflags", "+faststart", out])
    return out

# ---------------------------------------------------------------- Gemini
def gemini(key, model, prompt, as_json=False):
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
    body = {"contents": [{"parts": [{"text": prompt}]}]}
    if as_json:
        body["generationConfig"] = {"responseMimeType": "application/json"}
    last = None
    for attempt in range(4):
        try:
            r = requests.post(url, params={"key": key}, json=body, timeout=120)
            j = r.json()
            if r.status_code == 429 or r.status_code >= 500:
                last = RuntimeError(j.get("error", {}).get("message", f"HTTP {r.status_code}"))
                time.sleep(5 * (attempt + 1))
                continue
            if r.status_code != 200:
                raise RuntimeError(j.get("error", {}).get("message", f"HTTP {r.status_code}"))
            text = j["candidates"][0]["content"]["parts"][0]["text"]
            if as_json:
                return json.loads(re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.M).strip())
            return text
        except (json.JSONDecodeError, KeyError, IndexError) as e:
            last = e
            time.sleep(2)
        except requests.RequestException as e:
            last = e
            time.sleep(3 * (attempt + 1))
    raise RuntimeError(f"Gemini failed: {last}")


def keywords_from(text, topic):
    words = [w for w in re.findall(r"[A-Za-z]{4,}", text.lower()) if w not in STOP]
    if len(words) < 2:
        words = re.findall(r"[A-Za-z]{3,}", topic.lower()) or ["abstract"]
    freq = {}
    for w in words:
        freq[w] = freq.get(w, 0) + 1
    top = sorted(freq, key=lambda w: (-freq[w], -len(w)))[:3]
    return " ".join(top)


def gen_script(cfg, log, cancelled):
    key, model, topic, minutes = cfg["gemini_key"], cfg["model"], cfg["topic"], cfg["minutes"]
    lang = LANGS[cfg["lang"]]["label"]
    n = max(3, round(minutes * 60 / SEC_PER_SCENE))
    ns = max(3, min(12, round(n / 10)))
    log("Planning the video outline with Gemini…", 2)
    outline = gemini(key, model,
        f'Plan a YouTube video about "{topic}" lasting about {minutes} minutes. Return JSON: '
        f'{{"title": string, "sections": [{{"heading": string, "summary": string}}]}} with exactly {ns} sections. '
        f'Write in {lang}.', True)
    secs = [x for x in outline.get("sections", []) if isinstance(x, dict)][:ns]
    if not secs:
        raise RuntimeError("Gemini returned no outline. Try again or paste your own script.")
    ns = len(secs)
    base, extra = divmod(n, ns)
    scenes, headings, done_heads = [], [], []
    for i, sec in enumerate(secs):
        if cancelled():
            raise Cancelled()
        k = base + (1 if i < extra else 0)
        sec.setdefault("heading", f"Part {i+1}")
        log(f"Writing section {i+1}/{ns}: {sec['heading']}", 2 + 8 * (i / ns))
        flow = ("This is the opening: start with a strong hook. " if i == 0 else "") + \
               ("This is the final section: finish with a short conclusion and ask viewers to like and subscribe. "
                if i == ns - 1 else "Do not conclude the video here. ")
        p = (f'You write narration for a YouTube video titled "{outline.get("title", topic)}". '
             f'Now write section {i+1} of {ns}: "{sec["heading"]}" ({sec.get("summary","")}). '
             f'Earlier sections already covered: {", ".join(done_heads) or "nothing yet"}. {flow}'
             f'Write exactly {k} scenes. Each scene has "narration" (spoken text, about {WORDS_PER_SCENE} words, '
             f'natural spoken {lang}, no stage directions, no markdown) and "image_prompt" (English, 12-25 words, '
             f'one concrete visual, no text, no logos, no real people) and "keywords" (English, 2-3 words for stock photo search). '
             f'Return a JSON array of {k} objects.')
        arr = None
        for attempt in range(3):
            try:
                arr = gemini(key, model, p, True)
                if isinstance(arr, dict):
                    arr = next(iter(arr.values()), None)
                if isinstance(arr, list) and arr:
                    break
                arr = None
            except RuntimeError:
                if attempt == 2:
                    raise
        if not arr:
            raise RuntimeError(f'Gemini gave no usable text for section "{sec.get("heading", i + 1)}". Try again.')
        for a in arr:
            if isinstance(a, dict) and a.get("narration"):
                scenes.append({"text": clean_tts(a["narration"]), "prompt": a.get("image_prompt") or topic,
                               "keywords": a.get("keywords") or keywords_from(a["narration"], topic), "section": i})
        headings.append(sec["heading"])
        done_heads.append(sec["heading"])
    return outline.get("title", topic), scenes, headings


def split_script(raw, topic):
    chunks = []
    for para in [p.strip() for p in re.split(r"\n+", raw) if p.strip()]:
        sents = re.split(r"(?<=[.!?।])\s+", para)
        cur = ""
        for s in sents:
            if cur and len((cur + " " + s).split()) > WORDS_PER_SCENE * 1.6:
                chunks.append(cur)
                cur = s
            else:
                cur = (cur + " " + s).strip()
        if cur:
            chunks.append(cur)
    return [{"text": clean_tts(c), "prompt": "", "keywords": keywords_from(c, topic), "section": None}
            for c in chunks if clean_tts(c)]



def enrich_scene_details(cfg, scenes, log=lambda *_: None):
    """Add consistent visual direction to each narration scene. Gemini enriches in batches;
    deterministic defaults keep the project usable when no API key is configured."""
    key = (cfg.get("gemini_key") or "").strip()
    model = cfg.get("model") or "gemini-2.5-flash"
    topic = cfg.get("topic") or "the video topic"
    lang = LANGS.get(cfg.get("lang", "en-IN"), LANGS["en-IN"])["label"]
    for start in range(0, len(scenes), 8):
        batch = scenes[start:start+8]
        if key:
            prompt = (
                "You are a professional animation storyboard artist. Convert each narration into one distinct, "
                "visually coherent storyboard scene. Return a JSON array in exactly the same order and length. "
                "Each object must contain: image_prompt (English, 25-45 words, concrete visual, no text/logos), "
                "character_description (consistent character appearance or 'No recurring character'), "
                "background_description (specific environment, lighting and time of day), "
                "camera_angle (clear shot/framing and camera movement), "
                "animation_instructions (specific motion for characters, objects and camera), "
                "continuity_notes (how this scene connects visually to the next). Keep recurring characters consistent. "
                "Do not introduce unrelated characters. Topic: " + topic + ". Narration language: " + lang + ".\n" +
                "SCENES:\n" + "\n".join(f"{i+1}. {x['text']}" for i, x in enumerate(batch))
            )
            try:
                result = gemini(key, model, prompt, True)
                if isinstance(result, dict):
                    result = next((v for v in result.values() if isinstance(v, list)), [])
                if not isinstance(result, list) or len(result) != len(batch):
                    raise RuntimeError("Gemini returned an unexpected scene count")
                for scene, detail in zip(batch, result):
                    if not isinstance(detail, dict):
                        continue
                    for field in ("image_prompt", "character_description", "background_description",
                                  "camera_angle", "animation_instructions", "continuity_notes"):
                        if detail.get(field):
                            scene[field] = str(detail[field]).strip()
                    if scene.get("image_prompt"):
                        scene["prompt"] = scene["image_prompt"]
            except Exception as exc:
                log(f"Scene visual direction batch {start+1}-{start+len(batch)}: AI enrichment failed ({exc}); using safe defaults.")
        for index, scene in enumerate(batch, start=start+1):
            scene.setdefault("character_description", "No recurring character; focus on the subject described in the narration.")
            scene.setdefault("background_description", f"A detailed environment relevant to: {topic}; cinematic natural lighting.")
            if not scene.get("prompt"):
                scene["prompt"] = f"{scene.get('keywords') or topic}, cinematic storyboard illustration, detailed environment, no text or logos"
            scene.setdefault("image_prompt", scene["prompt"])
            scene.setdefault("camera_angle", "Medium-wide establishing shot with a gentle slow push-in.")
            scene.setdefault("animation_instructions", "Subtle environmental movement, natural object motion, and a slow camera push-in; avoid static-frame appearance.")
            scene.setdefault("continuity_notes", "Maintain the same visual style, color palette and recurring character design as adjacent scenes.")
            scene.setdefault("scene_number", index)
            scene.setdefault("duration_seconds", SEC_PER_SCENE)
    return scenes

def add_prompts(cfg, scenes, log):
    key = cfg.get("gemini_key")
    todo = [s for s in scenes if not s["prompt"]]
    if key and todo:
        for b in range(0, len(todo), 25):
            batch = todo[b:b + 25]
            log(f"Creating image ideas ({b+1}-{b+len(batch)} of {len(todo)})…", 8)
            try:
                arr = gemini(key, cfg["model"],
                    'For each narration below, return JSON array (same order, same length) of objects '
                    '{"image_prompt": English 12-25 words describing one concrete visual, no text/logos/real people, '
                    '"keywords": English 2-3 words for stock photo search}.\n' +
                    "\n".join(f"{i+1}. {s['text']}" for i, s in enumerate(batch)), True)
                for s, a in zip(batch, arr):
                    s["prompt"], s["keywords"] = a.get("image_prompt", ""), a.get("keywords") or s["keywords"]
            except RuntimeError as e:
                log(f"Image ideas by AI failed ({e}); using keywords instead.", 8)
    for s in scenes:
        if not s["prompt"]:
            s["prompt"] = f'{s["keywords"]}, {cfg["topic"]}'


# ---------------------------------------------------------------- images
def placeholder(text, w, h, out):
    seed = int(hashlib.md5(text.encode()).hexdigest()[:6], 16)
    r = random.Random(seed)
    c1 = tuple(r.randint(30, 160) for _ in range(3))
    c2 = tuple(r.randint(80, 230) for _ in range(3))
    img = Image.new("RGB", (w, h))
    d = ImageDraw.Draw(img)
    for y in range(h):
        t = y / h
        d.line([(0, y), (w, y)], fill=tuple(int(c1[i] * (1 - t) + c2[i] * t) for i in range(3)))
    f = font(int(min(w, h) * 0.08), True, False)
    lines = wrap(d, text.upper(), f, w * 0.8)
    y = h / 2 - len(lines) * f.size * 0.6
    for l in lines:
        d.text((w / 2, y), l, font=f, fill="white", anchor="ma")
        y += f.size * 1.2
    img.save(out, quality=90)


def cover(img, w, h):
    r = max(w / img.width, h / img.height)
    img = img.resize((max(w, round(img.width * r)), max(h, round(img.height * r))), Image.LANCZOS)
    x, y = (img.width - w) // 2, (img.height - h) // 2
    return img.crop((x, y, x + w, y + h))


def build_visual_prompt(sc, idx, cfg):
    """Build a scene-specific prompt while preserving recurring character identity."""
    parts = [sc.get("image_prompt") or sc.get("prompt") or sc.get("keywords") or cfg.get("topic", "")]
    character = sc.get("character_description", "").strip()
    background = sc.get("background_description", "").strip()
    camera = sc.get("camera_angle", "").strip()
    animation = sc.get("animation_instructions", "").strip()
    continuity = sc.get("continuity_notes", "").strip()
    if character:
        parts.append("same recurring character appearance: " + character)
    if background:
        parts.append("scene setting: " + background)
    if camera:
        parts.append("camera composition: " + camera)
    if animation:
        parts.append("visual action moment: " + animation)
    if continuity:
        parts.append("continuity: " + continuity)
    parts.extend([cfg.get("style", "cinematic, high quality"),
                  "unique scene composition, detailed illustration, no text, no watermark"])
    return ", ".join(x for x in parts if x)


def fetch_image(sc, idx, cfg, size, out):
    """Download and validate a distinct scene image. Never silently substitute a placeholder."""
    w, h = size
    prov = cfg.get("provider", "pollinations")
    prompt = build_visual_prompt(sc, idx, cfg)
    tried = []
    if prov == "placeholder":
        if cfg.get("allow_placeholders"):
            placeholder(sc.get("keywords") or sc.get("prompt") or f"Scene {idx + 1}", w, h, out)
            return "placeholder"
        raise RuntimeError("Placeholder images are disabled. Select AI images or provide an image service.")

    for attempt in range(3):
        try:
            if prov == "pollinations":
                # A deterministic but scene-unique seed avoids accidental repeated outputs.
                seed_text = f"{cfg.get('topic','')}|{idx}|{prompt}"
                seed = int(hashlib.sha256(seed_text.encode("utf-8")).hexdigest()[:8], 16)
                url = f"https://image.pollinations.ai/prompt/{quote(prompt, safe='')}"
                params = {"width": w, "height": h, "seed": seed, "nologo": "true", "model": cfg.get("image_model", "flux")}
                response = requests.get(url, params=params, timeout=(20, 180),
                                        headers={"Accept": "image/*", "User-Agent": "VideoGenie/1.0"})
                response.raise_for_status()
                content_type = response.headers.get("content-type", "").lower()
                if not content_type.startswith("image/") or len(response.content) < 5000:
                    raise ValueError(f"Image service returned invalid content ({content_type or 'unknown type'}, {len(response.content)} bytes).")
                data = response.content
            elif prov == "pexels":
                key = cfg.get("pexels_key", "")
                if not key:
                    raise ValueError("Pexels selected but API key is missing.")
                orientation = {"16:9": "landscape", "9:16": "portrait", "1:1": "square"}[cfg["ratio"]]
                query = sc.get("keywords") or sc.get("image_prompt") or sc.get("prompt") or cfg.get("topic", "")
                response = requests.get("https://api.pexels.com/v1/search",
                    headers={"Authorization": key},
                    params={"query": query, "per_page": 30, "orientation": orientation}, timeout=30)
                response.raise_for_status()
                photos = response.json().get("photos", [])
                if not photos:
                    raise ValueError(f"Pexels found no photos for scene {idx + 1}: {query}")
                # Select a stable but different result per scene.
                photo = photos[(idx * 7) % len(photos)]
                image_response = requests.get(photo["src"].get("large2x") or photo["src"]["large"], timeout=60)
                image_response.raise_for_status()
                data = image_response.content
                if len(data) < 5000:
                    raise ValueError("Pexels returned an image that is too small or incomplete.")
            else:
                raise ValueError(f"Unknown image provider: {prov}")

            tmp = out + ".download"
            with open(tmp, "wb") as f:
                f.write(data)
            try:
                with Image.open(tmp) as source:
                    source.verify()
                with Image.open(tmp) as source:
                    cover(source.convert("RGB"), w, h).save(out, "JPEG", quality=93, optimize=True)
            finally:
                if os.path.exists(tmp):
                    os.remove(tmp)
            if not os.path.exists(out) or os.path.getsize(out) < 5000:
                raise ValueError("Downloaded image failed final validation.")
            return prov
        except Exception as exc:
            tried.append(f"attempt {attempt + 1}: {exc}")
            if attempt < 2:
                time.sleep(2 ** attempt)
    raise RuntimeError(f"Image generation failed for scene {idx + 1} after 3 attempts. " + " | ".join(tried))


# ---------------------------------------------------------------- voice
def _split_tts_text(text, limit=2400):
    """Split long narration at sentence/word boundaries for cloud TTS limits."""
    text = clean_tts(text)
    if not text:
        raise RuntimeError("Voice generation failed: narration is empty.")
    parts, current = [], ""
    sentences = re.split(r"(?<=[.!?।])\s+", text)
    for sentence in sentences:
        sentence = sentence.strip()
        if not sentence:
            continue
        if len(sentence) > limit:
            words = sentence.split()
            sentence_parts, buf = [], ""
            for word in words:
                candidate = (buf + " " + word).strip()
                if len(candidate) > limit and buf:
                    sentence_parts.append(buf)
                    buf = word
                else:
                    buf = candidate
            if buf:
                sentence_parts.append(buf)
        else:
            sentence_parts = [sentence]
        for part in sentence_parts:
            candidate = (current + " " + part).strip()
            if len(candidate) > limit and current:
                parts.append(current)
                current = part
            else:
                current = candidate
    if current:
        parts.append(current)
    return parts


def validate_audio(path):
    """Reject empty, silent-placeholder, or unreadable audio outputs."""
    if not os.path.isfile(path) or os.path.getsize(path) < 1000:
        raise RuntimeError("Generated voice file is missing or too small.")
    probe = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", path],
        capture_output=True, text=True
    )
    try:
        seconds = float(probe.stdout.strip())
    except Exception:
        seconds = 0
    if probe.returncode != 0 or seconds <= 0.25:
        raise RuntimeError("Generated voice file is not valid playable audio.")
    return seconds


def tts(text, voice, speed, out):
    """Generate real speech with Edge TTS; fail loudly instead of making silent audio."""
    try:
        import edge_tts
    except ImportError as exc:
        raise RuntimeError("Voice engine missing. Install requirements: pip install -r requirements.txt") from exc
    pct = int(round((speed - 1) * 100))
    chunks = _split_tts_text(text)
    os.makedirs(os.path.dirname(out), exist_ok=True)
    temp_files = []

    async def save_chunk(chunk, target):
        await edge_tts.Communicate(chunk, voice, rate=f"{pct:+d}%").save(target)

    try:
        for index, chunk in enumerate(chunks):
            target = out + f".part{index:03d}.mp3"
            last_error = None
            for attempt in range(3):
                try:
                    if os.path.exists(target):
                        os.remove(target)
                    asyncio.run(save_chunk(chunk, target))
                    validate_audio(target)
                    last_error = None
                    break
                except Exception as exc:
                    last_error = exc
                    time.sleep(1 + attempt * 2)
            if last_error:
                raise RuntimeError(f"Speech service failed on narration part {index + 1}/{len(chunks)} using {voice}: {last_error}")
            temp_files.append(target)
        if len(temp_files) == 1:
            shutil.move(temp_files[0], out)
        else:
            # Re-encode concatenated chunks into a single clean MP3.
            inputs = []
            cmd = ["ffmpeg", "-y"]
            for part in temp_files:
                cmd += ["-i", part]
                inputs.append(f"[{len(inputs)}:a]")
            cmd += ["-filter_complex", "".join(inputs) + f"concat=n={len(inputs)}:v=0:a=1[out]", "-map", "[out]", "-codec:a", "libmp3lame", "-q:a", "4", out]
            sh(cmd)
        validate_audio(out)
        return "edge-tts"
    finally:
        for part in temp_files:
            if os.path.exists(part):
                os.remove(part)


# ---------------------------------------------------------------- video
def validate_video(path, expected_size=None, min_duration=0.1):
    """Fail loudly if the final MP4 is missing streams, truncated, or malformed."""
    if not os.path.isfile(path) or os.path.getsize(path) < 4096:
        raise RuntimeError("Final MP4 is missing or unexpectedly small.")
    raw = sh(["ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json", path])
    info = json.loads(raw)
    streams = info.get("streams", [])
    video = next((x for x in streams if x.get("codec_type") == "video"), None)
    audio = next((x for x in streams if x.get("codec_type") == "audio"), None)
    if not video or not audio:
        raise RuntimeError("Final MP4 must contain both video and narration/audio streams.")
    seconds = float(info.get("format", {}).get("duration") or 0)
    if seconds < min_duration:
        raise RuntimeError("Final MP4 duration is invalid.")
    if expected_size and (int(video.get("width", 0)), int(video.get("height", 0))) != tuple(expected_size):
        raise RuntimeError("Final MP4 resolution does not match the selected output size.")
    return {"duration": seconds, "width": int(video["width"]), "height": int(video["height"]),
            "video_codec": video.get("codec_name"), "audio_codec": audio.get("codec_name"),
            "bytes": os.path.getsize(path)}


def join_scene_clips(clips, out, transition_seconds=0.0, crf=23):
    """Join scene MP4s, optionally using short crossfades, and encode a web-friendly MP4."""
    if not clips:
        raise RuntimeError("No scene clips were produced.")
    if len(clips) == 1:
        sh(["ffmpeg", "-y", "-i", clips[0], "-c:v", "libx264", "-preset", "veryfast", "-crf", str(crf),
            "-c:a", "aac", "-b:a", "160k", "-movflags", "+faststart", out])
        return validate_video(out)
    trans = max(0.0, min(0.8, float(transition_seconds)))
    if trans <= 0:
        lst = out + ".concat.txt"
        with open(lst, "w", encoding="utf-8") as f:
            for clip in clips:
                safe = os.path.abspath(clip).replace("\\", "/").replace("'", "'\\''")
                f.write("file '" + safe + "'\n")
        sh(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", lst,
            "-c:v", "libx264", "-preset", "veryfast", "-crf", str(crf), "-c:a", "aac", "-b:a", "160k",
            "-movflags", "+faststart", out])
        try: os.remove(lst)
        except OSError: pass
    else:
        ds = [duration(x) for x in clips]
        trans = min(trans, min(ds) * 0.2)
        cmd = ["ffmpeg", "-y"]
        for clip in clips: cmd += ["-i", clip]
        filters = []
        vprev, aprev = "0:v", "0:a"
        elapsed = ds[0]
        for i in range(1, len(clips)):
            vout, aout = f"v{i}", f"a{i}"
            offset = max(0.0, elapsed - trans)
            filters.append(f"[{vprev}][{i}:v]xfade=transition=fade:duration={trans:.3f}:offset={offset:.3f}[{vout}]")
            filters.append(f"[{aprev}][{i}:a]acrossfade=d={trans:.3f}:c1=tri:c2=tri[{aout}]")
            vprev, aprev = vout, aout
            elapsed += ds[i] - trans
        cmd += ["-filter_complex", ";".join(filters), "-map", f"[{vprev}]", "-map", f"[{aprev}]",
                "-c:v", "libx264", "-preset", "veryfast", "-crf", str(crf), "-pix_fmt", "yuv420p",
                "-c:a", "aac", "-b:a", "160k", "-movflags", "+faststart", out]
        sh(cmd)
    return validate_video(out)


def render_scene(img, audio, size, idx, out):
    """Turn a still scene image into a motion clip with deterministic camera moves.

    This is 2.5D camera animation (pan/zoom), not generative character animation.
    Each scene gets a different motion preset; audio remains synchronized.
    """
    w, h = size
    d = max(1.0, duration(audio) + 0.35)
    n = max(1, math.ceil(d * FPS))
    # Keep the source larger than the output so pans never expose empty edges.
    scale_w, scale_h = w * 2, h * 2
    center_x = "iw/2-(iw/zoom/2)"
    center_y = "ih/2-(ih/zoom/2)"
    progress = f"on/{n}"
    presets = [
        (f"1+0.16*{progress}", center_x, center_y),                         # slow push in
        (f"1.16-0.16*{progress}", center_x, center_y),                     # pull out
        ("1.12", f"(iw-iw/zoom)*{progress}", center_y),                    # pan left to right
        ("1.12", f"(iw-iw/zoom)*(1-{progress})", center_y),                # pan right to left
        ("1.13", center_x, f"(ih-ih/zoom)*{progress}"),                    # pan top to bottom
        ("1.13", center_x, f"(ih-ih/zoom)*(1-{progress})"),                # pan bottom to top
        (f"1.04+0.10*{progress}", f"(iw-iw/zoom)*{progress}",
         f"(ih-ih/zoom)*(1-{progress})"),                                   # diagonal push
        (f"1.14-0.08*{progress}", f"(iw-iw/zoom)*(1-{progress})",
         f"(ih-ih/zoom)*{progress}"),                                      # diagonal pull
    ]
    z, x, y = presets[idx % len(presets)]
    vf = (f"scale={scale_w}:{scale_h}:force_original_aspect_ratio=increase,"
          f"crop={scale_w}:{scale_h},"
          f"zoompan=z='{z}':x='{x}':y='{y}':d={n}:s={w}x{h}:fps={FPS},"
          "setsar=1,format=yuv420p")
    sh(["ffmpeg", "-y", "-loop", "1", "-i", img, "-i", audio,
        "-vf", vf, "-af", "apad=pad_dur=0.35", "-t", f"{d:.3f}",
        "-r", str(FPS), "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
        "-c:a", "aac", "-b:a", "128k", "-ar", "44100", "-ac", "2",
        "-movflags", "+faststart", out])
    return d




# ------------------------------------------------------- subtitles and captions
def _caption_chunks(text, max_chars=42):
    """Split narration into readable caption phrases without dropping words."""
    text = re.sub(r"\s+", " ", (text or "")).strip()
    if not text:
        return []
    sentences = re.split(r"(?<=[.!?।])\s+", text)
    chunks = []
    for sentence in sentences:
        words = sentence.split()
        buf = ""
        for word in words:
            candidate = (buf + " " + word).strip()
            if len(candidate) > max_chars and buf:
                chunks.append(buf)
                buf = word
            else:
                buf = candidate
        if buf:
            chunks.append(buf)
    return chunks

def _srt_time(seconds):
    ms = max(0, int(round(float(seconds) * 1000)))
    h, rem = divmod(ms, 3600000)
    m, rem = divmod(rem, 60000)
    sec, milli = divmod(rem, 1000)
    return f"{h:02d}:{m:02d}:{sec:02d},{milli:03d}"

def make_srt(scenes, out_path):
    """Create approximate phrase-level captions aligned to each scene narration duration.

    This is timing-by-text-length, not word-level forced alignment.
    """
    entries = []
    for scene in scenes:
        start = float(scene.get("start", 0.0))
        end = float(scene.get("end", start + 1.0))
        total = max(0.5, end - start)
        phrases = _caption_chunks(scene.get("text", ""))
        if not phrases:
            continue
        weights = [max(1, len(x.replace(" ", ""))) for x in phrases]
        weight_sum = sum(weights)
        cursor = start
        for idx, (phrase, weight) in enumerate(zip(phrases, weights)):
            seg = total * weight / weight_sum
            # Keep a small gap between caption cards while preserving the scene end.
            seg = max(0.45, seg) if len(phrases) <= 1 else seg
            seg_end = end if idx == len(phrases) - 1 else min(end, cursor + seg)
            if seg_end <= cursor:
                seg_end = min(end, cursor + 0.25)
            entries.append((cursor, seg_end, phrase))
            cursor = seg_end
    with open(out_path, "w", encoding="utf-8-sig", newline="\n") as f:
        for i, (start, end, text) in enumerate(entries, 1):
            f.write(f"{i}\n{_srt_time(start)} --> {_srt_time(end)}\n{text}\n\n")
    if not entries:
        raise RuntimeError("Subtitle generation failed: no narration text was available.")
    return len(entries)

def burn_subtitles(video_path, srt_path, out_path):
    """Burn SRT captions into the MP4 using FFmpeg/libass."""
    filters = subprocess.run(["ffmpeg", "-hide_banner", "-filters"], capture_output=True, text=True, encoding="utf-8", errors="replace")
    if filters.returncode != 0 or not re.search(r"\bsubtitles\b", filters.stdout):
        raise RuntimeError("FFmpeg was built without the subtitles/libass filter. SRT was saved separately; install an FFmpeg build with libass to burn captions into MP4.")
    # FFmpeg filter paths need escaping for Windows drive letters, colons and apostrophes.
    path = os.path.abspath(srt_path).replace("\\", "/")
    path = path.replace(":", r"\:").replace("'", r"\'")
    vf = f"subtitles=filename='{path}':force_style='FontSize=22,Outline=2,Shadow=1,Alignment=2,MarginV=28'"
    sh(["ffmpeg", "-y", "-i", video_path, "-vf", vf, "-c:v", "libx264", "-preset", "veryfast", "-crf", "22",
        "-c:a", "copy", "-movflags", "+faststart", out_path])
    if not os.path.isfile(out_path) or os.path.getsize(out_path) < 10000:
        raise RuntimeError("Subtitle burn-in failed: output MP4 is missing or too small.")
    return out_path

# ---------------------------------------------------------------- thumbnail + SEO
DEV_FONTS = ["/system/fonts/NotoSansDevanagari-Bold.ttf", "/system/fonts/NotoSansDevanagari-Regular.ttf",
             "/usr/share/fonts/truetype/noto/NotoSansDevanagari-Bold.ttf", "C:/Windows/Fonts/NirmalaB.ttf",
             "C:/Windows/Fonts/Nirmala.ttf", "/System/Library/Fonts/Supplemental/Devanagari Sangam MN.ttc",
             "/Library/Fonts/Arial Unicode.ttf"]


def has_dev_font():
    return any(os.path.exists(p) for p in DEV_FONTS)


def font(size, bold=True, dev=False):
    paths = list(DEV_FONTS) if dev else []
    paths += ["C:/Windows/Fonts/impact.ttf", "C:/Windows/Fonts/arialbd.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
              "/system/fonts/Roboto-Black.ttf", "/system/fonts/Roboto-Bold.ttf", "/system/fonts/DroidSans-Bold.ttf",
              "/Library/Fonts/Arial Bold.ttf", "/System/Library/Fonts/Supplemental/Arial Bold.ttf"]
    for p in paths:
        if os.path.exists(p):
            try:
                return ImageFont.truetype(p, size)
            except Exception:
                pass
    return ImageFont.load_default()


def wrap(d, text, f, maxw):
    lines, cur = [], ""
    for w in text.split():
        q = (cur + " " + w).strip()
        if d.textlength(q, font=f) > maxw and cur:
            lines.append(cur)
            cur = w
        else:
            cur = q
    return lines + ([cur] if cur else [])


def make_thumbnail(img_path, text, out, dev):
    W, H = 1280, 720
    img = cover(Image.open(img_path).convert("RGB"), W, H)
    ov = Image.new("RGBA", (W, H))
    od = ImageDraw.Draw(ov)
    for x in range(W):
        od.line([(x, 0), (x, H)], fill=(0, 0, 0, int(190 * max(0, 1 - x / (W * 0.85)))))
    img = Image.alpha_composite(img.convert("RGBA"), ov).convert("RGB")
    d = ImageDraw.Draw(img)
    size = 130
    while True:
        f = font(size, True, dev)
        lines = wrap(d, text, f, W * 0.62)
        if (len(lines) <= 4 and len(lines) * size * 1.15 < H * 0.8) or size <= 54:
            break
        size -= 8
    y = H / 2 - len(lines) * size * 1.15 / 2
    for l in lines:
        d.text((60, y), l, font=f, fill="white", stroke_width=max(4, size // 14), stroke_fill="black")
        y += size * 1.15
    img.save(out, quality=92)


def make_seo(cfg, title, scenes, headings, total):
    topic, key, y = cfg["topic"], cfg.get("gemini_key"), time.localtime().tm_year
    chapters = ""
    if headings:
        starts, seen = [], set()
        for s in scenes:
            if s["section"] is not None and s["section"] not in seen:
                seen.add(s["section"])
                starts.append((s["start"], headings[s["section"]]))
        if len(starts) >= 3:
            chapters = "\n".join(f"{fmt_time(t)} {h}" for t, h in starts)
    if key:
        try:
            j = gemini(key, cfg["model"],
                f'Create YouTube SEO for a video titled "{title}" about "{topic}". Language of titles/description: '
                f'{LANGS[cfg["lang"]]["label"]}. Return JSON {{"titles": [5 titles under 70 characters], '
                f'"description": "150-250 words, no hashtags", "tags": [15 tags], "hashtags": [5 strings starting with #], '
                f'"thumbnail_text": "max 5 words, punchy, in the same language"}}.', True)
            if isinstance(j, dict) and j.get("titles"):
                j["description"] = j.get("description") or topic
                j["tags"] = [str(x) for x in (j.get("tags") or [topic])]
                j["hashtags"] = [str(x) for x in (j.get("hashtags") or [])]
                j["titles"] = [str(x) for x in j["titles"]]
                return j, chapters
        except RuntimeError:
            pass
    ws = [w for w in re.findall(r"\w{3,}", topic.lower()) if w not in STOP]
    t = topic.strip()
    core = re.sub(r"^how to ", "", t, flags=re.I)
    tags = [t, f"how to {core}", f"{core} {y}", f"{t} tutorial", f"{t} for beginners", f"{t} tips", f"{t} explained"] + ws
    uniq = list(dict.fromkeys(x.lower() for x in tags))[:15]
    first = scenes[0]["text"] if scenes else t
    return {"titles": [f"{t}: Everything You Need to Know ({y})", f"How to {core} (Step by Step)",
                       f"5 Mistakes to Avoid With {t}", f"{t} Explained Simply", f"The Truth About {t}"],
            "description": f"{first}\n\nIn this video you will learn {t} step by step. Watch till the end.\n\nLike, share and subscribe for more.",
            "tags": uniq, "hashtags": [f"#{w}" for w in ws[:4]] + ["#youtube"],
            "thumbnail_text": t.upper()[:40]}, chapters


# ---------------------------------------------------------------- main
def run(cfg, log, cancelled=lambda: False):
    need_ffmpeg()
    topic = cfg["topic"].strip()
    if not topic:
        raise ValueError("Please enter a topic.")
    size = SIZES[(cfg["ratio"], cfg["quality"])]
    base = os.path.join(cfg["output_dir"], slug(topic))
    out = base if cfg.get("resume") else (base if not os.path.exists(base) else f"{base}-{time.strftime('%H%M%S')}")
    for sub in ("images", "audio", "clips"):
        os.makedirs(os.path.join(out, sub), exist_ok=True)
    sp = os.path.join(out, "scenes.json")

    if cfg.get("resume") and os.path.exists(sp):
        data = json.load(open(sp, encoding="utf-8"))
        title, scenes, headings = data["title"], data["scenes"], data["headings"]
        log(f"Resuming with saved script ({len(scenes)} scenes).", 10)
    else:
        if cfg.get("script", "").strip():
            title, headings = topic, []
            scenes = split_script(cfg["script"], topic)
            if not scenes:
                raise ValueError("Your script is empty.")
            log(f"Using your script: {len(scenes)} scenes.", 3)
            add_prompts(cfg, scenes, log)
        else:
            if not cfg.get("gemini_key"):
                raise ValueError("Add a free Gemini API key to auto-write the script, or paste your own script.")
            title, scenes, headings = gen_script(cfg, log, cancelled)
        log("Building scene-by-scene storyboard details…", 9)
        enrich_scene_details(cfg, scenes, log)
        json.dump({"title": title, "scenes": scenes, "headings": headings}, open(sp, "w", encoding="utf-8"),
                  ensure_ascii=False, indent=1)
    N = len(scenes)

    # images
    log(f"Creating {N} scene images…", 10)
    done = [0]
    kinds = {}

    def img_job(i):
        if cancelled():
            raise Cancelled()
        p = os.path.join(out, "images", f"{i:03d}.jpg")
        valid_existing = False
        if os.path.exists(p):
            try:
                with Image.open(p) as existing:
                    existing.verify()
                valid_existing = os.path.getsize(p) >= 5000
            except Exception:
                valid_existing = False
        if not valid_existing:
            if os.path.exists(p):
                os.remove(p)
            kinds[i] = fetch_image(scenes[i], i, cfg, size, p)
        done[0] += 1
        log(f"Image {done[0]}/{N}", 10 + 35 * done[0] / N)
    with ThreadPoolExecutor(max_workers=2 if cfg["provider"] == "pexels" else 1) as ex:
        list(ex.map(img_job, range(N)))
    image_manifest = []
    for i, scene in enumerate(scenes):
        image_path = os.path.join(out, "images", f"{i:03d}.jpg")
        image_manifest.append({"scene": i + 1, "file": os.path.basename(image_path),
                               "provider": kinds.get(i, "resumed"),
                               "prompt": build_visual_prompt(scene, i, cfg),
                               "bytes": os.path.getsize(image_path) if os.path.exists(image_path) else 0})
    with open(os.path.join(out, "image_manifest.json"), "w", encoding="utf-8") as mf:
        json.dump(image_manifest, mf, ensure_ascii=False, indent=2)
    log(f"Validated {len(image_manifest)} scene images. See image_manifest.json for prompts and providers.", 45)

    # voice
    voice = LANGS[cfg["lang"]]["voice"]
    log("Recording voice-over…", 45)
    modes = set()
    for i, s in enumerate(scenes):
        if cancelled():
            raise Cancelled()
        p = os.path.join(out, "audio", f"{i:03d}.mp3")
        if os.path.exists(p):
            try:
                validate_audio(p)
            except Exception:
                os.remove(p)
        if not os.path.exists(p):
            modes.add(tts(s["text"], voice, cfg["speed"], p))
        if i % 3 == 0 or i == N - 1:
            log(f"Voice {i+1}/{N}", 45 + 15 * (i + 1) / N)
    log("Voice-over generated and validated for every scene.", 60)

    # clips
    t = 0.0
    clips = []
    transition_seconds = max(0.0, min(0.8, float(cfg.get("transition_seconds", 0.25))))
    for i, s in enumerate(scenes):
        if cancelled():
            raise Cancelled()
        c = os.path.join(out, "clips", f"{i:03d}.mp4")
        a = os.path.join(out, "audio", f"{i:03d}.mp3")
        sfx = make_scene_sfx(s.get("text", ""), duration(a), os.path.join(out, "audio", f"sfx_{i:03d}.mp3"))
        render_audio = mix_scene_audio(a, sfx, os.path.join(out, "audio", f"mixed_{i:03d}.mp3")) if sfx else a
        if not os.path.exists(c):
            render_scene(os.path.join(out, "images", f"{i:03d}.jpg"), render_audio, size, i, c)
        clips.append(c)
        log(f"Video scene {i+1}/{N}", 60 + 32 * (i + 1) / N)
    # Match subtitle/music timing to the exact transition duration used by the joiner.
    clip_durations = [duration(c) for c in clips]
    effective_transition = min(transition_seconds, min(clip_durations) * 0.2) if len(clips) > 1 else 0.0
    t = 0.0
    for i, (scene, clip_duration) in enumerate(zip(scenes, clip_durations)):
        if i > 0:
            t = max(0.0, t - effective_transition)
        scene["start"] = t
        t += clip_duration
        scene["end"] = t
    log("Joining scenes with validated transitions and MP4 encoding…", 93)
    vid = os.path.join(out, "video.mp4")
    crf = int(cfg.get("compression_crf", 23))
    if crf not in (20, 23, 27): crf = 23
    video_info = join_scene_clips(clips, vid, transition_seconds, crf)
    log(f"Rendered {video_info['width']}x{video_info['height']} MP4 ({video_info['video_codec']}/{video_info['audio_codec']}).", 94)
    # Add a locally synthesized, selectable mood bed; narration automatically ducks it.
    if cfg.get("music_enabled", True):
        music = os.path.join(out, "audio", "background_music.mp3")
        make_music_bed(t, cfg.get("music_mood", "auto"), music, cfg.get("music_volume", 0.13))
        mixed_video = os.path.join(out, "video_with_music.mp4")
        add_music_to_video(vid, music, mixed_video, cfg.get("music_volume", 0.13))
        os.replace(mixed_video, vid)
        log("Background music added and ducked under narration; scene effects mixed where relevant.", 95)

    # Captions: phrase-level estimated timing from each scene's narration duration.
    subtitle_path = os.path.join(out, "subtitles.srt")
    caption_count = make_srt(scenes, subtitle_path)
    log(f"Generated {caption_count} synchronized caption segments (phrase-level timing).", 96)
    if cfg.get("burn_subtitles", True):
        subtitled = os.path.join(out, "video_subtitled.mp4")
        burn_subtitles(vid, subtitle_path, subtitled)
        os.replace(subtitled, vid)
        log("Subtitles burned into final MP4; editable SRT also saved.", 97)

    # thumbnail + seo
    log("Making thumbnail and SEO…", 96)
    seo, chapters = make_seo(cfg, title, scenes, headings, t)
    ttext = seo.get("thumbnail_text") or topic.upper()
    dev = bool(re.search(r"[\u0900-\u097F]", ttext))
    if dev and not has_dev_font():
        ttext = topic.upper() if topic.isascii() else "NEW VIDEO"
        dev = False
        log("Note: no Hindi font found on this device, so the thumbnail uses English text.", 96)
    best = os.path.join(out, "images", f"{min(1, N-1):03d}.jpg")
    make_thumbnail(best, ttext, os.path.join(out, "thumbnail.jpg"), dev)
    with open(os.path.join(out, "seo.txt"), "w", encoding="utf-8") as f:
        f.write("TITLE IDEAS\n" + "\n".join(f"- {x}" for x in seo["titles"]))
        f.write("\n\nDESCRIPTION\n" + seo["description"])
        if chapters:
            f.write("\n\nCHAPTERS\n" + chapters)
        f.write("\n\nHASHTAGS\n" + " ".join(seo["hashtags"]))
        f.write("\n\nTAGS (comma separated)\n" + ", ".join(seo["tags"]) + "\n")
    with open(os.path.join(out, "script.txt"), "w", encoding="utf-8") as f:
        f.write(title + "\n\n" + "\n\n".join(s["text"] for s in scenes) + "\n")
    final_info = validate_video(vid, expected_size=size)
    with open(os.path.join(out, "render_report.json"), "w", encoding="utf-8") as rf:
        json.dump(final_info, rf, ensure_ascii=False, indent=2)
    shutil.rmtree(os.path.join(out, "clips"), ignore_errors=True)
    log(f"Final MP4 validated: {final_info['width']}x{final_info['height']}, {fmt_time(final_info['duration'])}, {final_info['bytes'] // 1024} KB.", 99)
    log(f"Done. Video length {fmt_time(final_info['duration'])}.", 100)
    return out, ["video.mp4", "subtitles.srt", "thumbnail.jpg", "seo.txt", "script.txt", "render_report.json"]
