"""VideoGenie offline integration self-test.

Exercises the real local rendering pipeline without paid/live AI services.
Only the external TTS network call is replaced with a short synthetic test tone.
Run: python self_test.py
"""
import json
import os
import shutil
import subprocess
import tempfile

import pipeline


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def fake_tts(text, voice, speed, out):
    os.makedirs(os.path.dirname(out), exist_ok=True)
    subprocess.run([
        "ffmpeg", "-y", "-f", "lavfi", "-i", "sine=frequency=440:duration=1.2",
        "-ac", "2", "-ar", "44100", "-c:a", "libmp3lame", "-q:a", "6", out
    ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    pipeline.validate_audio(out)
    return "synthetic-test-tone (TTS network mocked)"


def main():
    pipeline.need_ffmpeg()
    original_tts = pipeline.tts
    work = tempfile.mkdtemp(prefix="videogenie_selftest_")
    try:
        pipeline.tts = fake_tts
        cfg = {
            "topic": "A little forest adventure",
            "script": (
                "A curious child walks into a bright forest and notices a tiny glowing path.\n"
                "The child follows the path and discovers a friendly fox beside an old oak tree."
            ),
            "minutes": 1, "lang": "en-IN", "ratio": "16:9", "quality": "480",
            "provider": "placeholder", "allow_placeholders": True,
            "style": "storybook illustration", "speed": 1.0,
            "music_enabled": True, "music_mood": "calm", "music_volume": 0.10,
            "burn_subtitles": True, "transition_seconds": 0.25,
            "compression_crf": 27, "resume": False, "output_dir": work,
            "gemini_key": "", "model": "gemini-2.5-flash"
        }
        events = []
        folder, files = pipeline.run(cfg, lambda message, pct=None: events.append((pct, message)))

        required_files = ["video.mp4", "subtitles.srt", "thumbnail.jpg", "seo.txt",
                          "script.txt", "render_report.json", "image_manifest.json"]
        for name in required_files:
            path = os.path.join(folder, name)
            require(os.path.isfile(path) and os.path.getsize(path) > 0,
                    f"Missing or empty output: {name}")

        report = json.load(open(os.path.join(folder, "render_report.json"), encoding="utf-8"))
        require((report["width"], report["height"]) == (854, 480), "Unexpected output dimensions")
        require(report["video_codec"] == "h264", "Expected H.264 video stream")
        require(report["audio_codec"] == "aac", "Expected AAC audio stream")
        require(report["duration"] >= 1.0, "Output video duration is too short")
        require(os.path.getsize(os.path.join(folder, "subtitles.srt")) > 0, "SRT is empty")
        require(os.path.isfile(os.path.join(folder, "thumbnail.jpg")), "Thumbnail missing")
        require(events and events[-1][0] == 100, "Pipeline did not report completion")

        # Ensure the pipeline does not silently substitute placeholder art in normal mode.
        blocked = os.path.join(work, "blocked.jpg")
        try:
            pipeline.fetch_image({"text": "test"}, 0,
                                 {"provider": "placeholder", "allow_placeholders": False,
                                  "topic": "test", "style": "test"}, (320, 180), blocked)
        except RuntimeError as exc:
            require("Placeholder images are disabled" in str(exc), "Unexpected placeholder failure")
        else:
            raise AssertionError("Placeholder fallback was not blocked")
        require(not os.path.exists(blocked), "Blocked placeholder unexpectedly created an image")

        print("PASS: FFmpeg/ffprobe preflight")
        print("PASS: script -> scenes -> test images -> audio mock -> animated clips")
        print("PASS: scene join/crossfade -> background music -> subtitles burn-in")
        print("PASS: thumbnail + SEO + script + image manifest")
        print("PASS: final MP4 has H.264/AAC streams and expected dimensions")
        print("PASS: placeholder fallback remains explicitly opt-in")
        print("NOTE: TTS was mocked; live Gemini, image service and Edge TTS were not tested.")
        print("TEST OUTPUT:", folder)
    finally:
        pipeline.tts = original_tts
        shutil.rmtree(work, ignore_errors=True)


if __name__ == "__main__":
    main()
