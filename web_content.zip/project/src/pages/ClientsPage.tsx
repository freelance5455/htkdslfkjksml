import { useCallback, useEffect, useMemo, useState } from 'react';
import { Pencil, Plus, Search, Trash2, Users } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { errorMessage } from '@/lib/errors';
import type { Client } from '@/types/studio';
import { Alert, Badge, Button, ConfirmModal, EmptyState, IconButton, PageHeader, Spinner, TextInput } from '@/components/ui';
import { ClientFormModal } from '@/components/clients/ClientFormModal';

export function ClientsPage() {
  const [clients, setClients] = useState<Client[] | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Client | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Client | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  const loadClients = useCallback(async () => {
    const { data, error } = await supabase.from('clients').select('*').order('name').returns<Client[]>();
    if (error) {
      setLoadError(errorMessage(error));
      return;
    }
    setLoadError(null);
    setClients(data ?? []);
  }, []);

  useEffect(() => {
    loadClients();
  }, [loadClients]);

  const filtered = useMemo(() => {
    if (!clients) return [];
    const term = search.trim().toLowerCase();
    if (!term) return clients;
    return clients.filter((client) =>
      [client.name, client.email, client.company, client.document].some((value) => (value ?? '').toLowerCase().includes(term))
    );
  }, [clients, search]);

  const openCreate = () => {
    setEditing(null);
    setFormOpen(true);
  };

  const openEdit = (client: Client) => {
    setEditing(client);
    setFormOpen(true);
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    setDeleteError(null);
    const { error } = await supabase.from('clients').delete().eq('id', deleteTarget.id);
    setDeleting(false);
    if (error) {
      setDeleteError(errorMessage(error));
      return;
    }
    setDeleteTarget(null);
    await loadClients();
  };

  return (
    <div className="animate-fade-up space-y-8">
      <PageHeader
        title="Clientes"
        description="Cadastre quem recebe as licenças do VT ACCESS. Clientes com KEYs vinculadas não podem ser removidos."
        actions={
          <Button icon={Plus} onClick={openCreate}>
            Novo cliente
          </Button>
        }
      />

      {loadError ? <Alert>{loadError}</Alert> : null}

      {clients === null && !loadError ? (
        <Spinner label="Carregando clientes" />
      ) : clients && clients.length === 0 ? (
        <div className="surface">
          <EmptyState
            icon={Users}
            title="Nenhum cliente cadastrado"
            description="Cadastre o primeiro cliente para associá-lo a uma KEY e acompanhar suas instalações."
            action={
              <Button icon={Plus} onClick={openCreate}>
                Cadastrar cliente
              </Button>
            }
          />
        </div>
      ) : clients ? (
        <div className="space-y-5">
          <div className="relative sm:max-w-sm">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-graphite-400" aria-hidden="true" />
            <TextInput
              type="search"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Buscar por nome, e-mail, empresa ou documento"
              aria-label="Buscar clientes"
              className="pl-9"
            />
          </div>

          <div className="surface overflow-hidden">
            {filtered.length === 0 ? (
              <EmptyState icon={Search} title="Nenhum cliente encontrado" description="Tente outro termo de busca." />
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full min-w-[680px] text-left text-sm">
                  <thead className="border-b border-graphite-700 text-xs uppercase tracking-wider text-graphite-400">
                    <tr>
                      <th className="px-5 py-3 font-medium">Cliente</th>
                      <th className="px-5 py-3 font-medium">Contato</th>
                      <th className="px-5 py-3 font-medium">Empresa</th>
                      <th className="px-5 py-3 font-medium">Situação</th>
                      <th className="px-5 py-3 text-right font-medium">Ações</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-graphite-700/70">
                    {filtered.map((client) => (
                      <tr key={client.id} className="transition-colors duration-150 hover:bg-graphite-700/30">
                        <td className="px-5 py-4">
                          <p className="font-medium text-graphite-50">{client.name}</p>
                          {client.document ? <p className="text-xs text-graphite-400">{client.document}</p> : null}
                        </td>
                        <td className="px-5 py-4 text-graphite-300">
                          <p>{client.email ?? '-'}</p>
                          {client.phone ? <p className="text-xs text-graphite-400">{client.phone}</p> : null}
                        </td>
                        <td className="px-5 py-4 text-graphite-300">{client.company ?? '-'}</td>
                        <td className="px-5 py-4">
                          <Badge tone={client.status === 'active' ? 'success' : 'neutral'}>{client.status === 'active' ? 'Ativo' : 'Inativo'}</Badge>
                        </td>
                        <td className="px-5 py-4">
                          <div className="flex justify-end gap-1">
                            <IconButton icon={Pencil} label="Editar cliente" onClick={() => openEdit(client)} />
                            <IconButton
                              icon={Trash2}
                              label="Excluir cliente"
                              tone="danger"
                              onClick={() => {
                                setDeleteError(null);
                                setDeleteTarget(client);
                              }}
                            />
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      ) : null}

      <ClientFormModal open={formOpen} client={editing} onClose={() => setFormOpen(false)} onSaved={loadClients} />

      <ConfirmModal
        open={deleteTarget !== null}
        title="Excluir cliente"
        message={`O cadastro de ${deleteTarget?.name ?? 'este cliente'} será removido. Esta ação não pode ser desfeita.`}
        confirmLabel="Excluir"
        busy={deleting}
        error={deleteError}
        onConfirm={handleDelete}
        onClose={() => setDeleteTarget(null)}
      />
    </div>
  );
}
