import { useState, type FormEvent } from 'react';
import { ArrowRight, Loader2 } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { Alert, Button, Field, TextInput } from '@/components/ui';

type Mode = 'signin' | 'signup';

const MIN_PASSWORD_LENGTH = 8;

export function LoginPage() {
  const { signIn, signUp } = useAuth();
  const [mode, setMode] = useState<Mode>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const isSignUp = mode === 'signup';

  const switchMode = (next: Mode) => {
    setMode(next);
    setError(null);
    setConfirmPassword('');
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError(null);

    const trimmedEmail = email.trim();
    if (!trimmedEmail || !password) {
      setError('Informe e-mail e senha.');
      return;
    }
    if (isSignUp) {
      if (password.length < MIN_PASSWORD_LENGTH) {
        setError(`A senha deve ter pelo menos ${MIN_PASSWORD_LENGTH} caracteres.`);
        return;
      }
      if (password !== confirmPassword) {
        setError('As senhas não coincidem.');
        return;
      }
    }

    setSubmitting(true);
    try {
      if (isSignUp) {
        await signUp(trimmedEmail, password);
      } else {
        await signIn(trimmedEmail, password);
      }
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'Não foi possível entrar. Tente novamente.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="site-backdrop relative flex min-h-screen items-center justify-center overflow-hidden px-4 py-12">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-40 left-1/2 h-[480px] w-[480px] -translate-x-1/2 rounded-full bg-crimson-700/25 blur-3xl"
      />
      <div className="animate-fade-up relative w-full max-w-md space-y-8">
        <div className="flex flex-col items-center gap-4 text-center">
          <img
            src="/file_000000006c70820e86c736074b81b735.png"
            alt="Logo SLOW OPTIMIZER"
            className="h-16 w-16 rounded-2xl object-cover shadow-xl shadow-crimson-900/60 ring-1 ring-inset ring-crimson-700/50"
          />
          <div className="space-y-1">
            <h1 className="font-display text-2xl font-semibold text-graphite-50">VT STUDIO</h1>
            <p className="text-sm text-graphite-300">Acesso restrito aos administradores do ecossistema VT ACCESS.</p>
          </div>
        </div>

        <div className="surface space-y-6 p-6 sm:p-8">
          <div role="tablist" aria-label="Tipo de acesso" className="grid grid-cols-2 rounded-xl bg-ink p-1">
            {(['signin', 'signup'] as Mode[]).map((option) => {
              const active = mode === option;
              return (
                <button
                  key={option}
                  type="button"
                  role="tab"
                  aria-selected={active}
                  onClick={() => switchMode(option)}
                  className={`rounded-lg py-2 text-sm font-medium transition-all duration-200 ${
                    active ? 'bg-graphite-700 text-graphite-50 shadow-sm' : 'text-graphite-400 hover:text-graphite-100'
                  }`}
                >
                  {option === 'signin' ? 'Entrar' : 'Criar conta'}
                </button>
              );
            })}
          </div>

          <form onSubmit={handleSubmit} className="space-y-5" noValidate>
            <Field label="E-mail">
              <TextInput
                type="email"
                autoComplete="email"
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                placeholder="voce@empresa.com"
                required
              />
            </Field>
            <Field label="Senha" hint={isSignUp ? `Mínimo de ${MIN_PASSWORD_LENGTH} caracteres.` : undefined}>
              <TextInput
                type="password"
                autoComplete={isSignUp ? 'new-password' : 'current-password'}
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                required
              />
            </Field>
            {isSignUp ? (
              <Field label="Confirmar senha">
                <TextInput
                  type="password"
                  autoComplete="new-password"
                  value={confirmPassword}
                  onChange={(event) => setConfirmPassword(event.target.value)}
                  required
                />
              </Field>
            ) : null}

            {error ? <Alert>{error}</Alert> : null}

            <Button type="submit" className="w-full" disabled={submitting}>
              {submitting ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                  Aguarde...
                </>
              ) : (
                <>
                  {isSignUp ? 'Criar conta' : 'Entrar no painel'}
                  <ArrowRight className="h-4 w-4" aria-hidden="true" />
                </>
              )}
            </Button>
          </form>
        </div>

        <p className="text-center text-xs text-graphite-400">
          Se ainda não houver administrador no painel, a primeira conta que entrar recebe acesso.
        </p>
      </div>
    </div>
  );
}
