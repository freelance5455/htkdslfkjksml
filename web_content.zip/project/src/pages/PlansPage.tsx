import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { Layers, Pencil, Plus, Trash2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { errorMessage } from '@/lib/errors';
import { Alert, Badge, Button, ConfirmModal, EmptyState, Field, IconButton, Modal, PageHeader, SelectInput, Spinner, TextArea, TextInput } from '@/components/ui';

interface Plan {
  id: string;
  name: string;
  description: string | null;
  max_activations: number;
  validity_days: number | null;
  status: 'active' | 'archived';
  price_cents: number | null;
  app_id: string | null;
}

interface PlanForm {
  name: string;
  description: string;
  maxActivations: string;
  validityDays: string;
  status: 'active' | 'archived';
  price: string;
  appId: string;
  featureCodes: string;
}

const EMPTY_FORM: PlanForm = { name: '', description: '', maxActivations: '1', validityDays: '', status: 'active', price: '', appId: '', featureCodes: '' };

function PlanFormModal({ plan, open, onClose, onSaved }: { plan: Plan | null; open: boolean; onClose: () => void; onSaved: () => void }) {
  const [form, setForm] = useState<PlanForm>(EMPTY_FORM);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [apps, setApps] = useState<{ id: string; name: string }[]>([]);

  useEffect(() => {
    if (!open) return;
    setError(null);
    void supabase.from('apps').select('id,name').eq('status', 'published').order('name').then(({ data }) => setApps(data ?? []));
    if (plan) void supabase.from('plan_features').select('feature_code').eq('plan_id', plan.id).eq('enabled', true).then(({ data }) => setForm(current => ({ ...current, featureCodes: (data ?? []).map(item => item.feature_code).join(', ') }))); 
    setForm(
      plan
        ? {
            name: plan.name,
            description: plan.description ?? '',
            maxActivations: String(plan.max_activations),
            validityDays: plan.validity_days ? String(plan.validity_days) : '',
            status: plan.status,
            price: plan.price_cents == null ? '' : (plan.price_cents / 100).toFixed(2),
            appId: plan.app_id ?? '',
            featureCodes: '',
          }
        : EMPTY_FORM
    );
  }, [open, plan]);

  const update = (field: keyof PlanForm, value: string) => setForm((current) => ({ ...current, [field]: value }));

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const maxActivations = Number(form.maxActivations);
    const validityText = form.validityDays.trim();
    const validityDays = validityText === '' ? null : Number(validityText);

    if (!form.name.trim()) return setError('Informe o nome do plano.');
    if (!Number.isInteger(maxActivations) || maxActivations < 1 || maxActivations > 100) return setError('Informe um limite de instalações entre 1 e 100.');
    if (validityDays !== null && (!Number.isInteger(validityDays) || validityDays < 1 || validityDays > 3650)) {
      return setError('A validade deve ser um número de dias entre 1 e 3650, ou fica em branco.');
    }

    const priceText = form.price.trim().replace(',', '.');
    const price = priceText === '' ? null : Math.round(Number(priceText) * 100);
    if (price !== null && (!Number.isFinite(price) || price < 100 || price > 100000000)) return setError('Informe um preço entre R$ 1,00 e R$ 1.000.000,00.');
    if (price !== null && !form.appId) return setError('Selecione o aplicativo liberado por este plano.');

    const payload = {
      name: form.name.trim(),
      description: form.description.trim() || null,
      max_activations: maxActivations,
      validity_days: validityDays,
      status: form.status,
      price_cents: price,
      app_id: form.appId || null,
      updated_at: new Date().toISOString(),
    };

    setError(null);
    setSaving(true);
    let savedPlanId = plan?.id ?? '';
    let saveError: { message: string } | null = null;
    if (plan) {
      const result = await supabase.from('plans').update(payload).eq('id', plan.id);
      saveError = result.error;
    } else {
      const result = await supabase.from('plans').insert(payload).select('id').single();
      saveError = result.error;
      savedPlanId = result.data?.id ?? '';
    }
    setSaving(false);

    if (saveError) return setError(errorMessage(saveError));
    if (!savedPlanId) return setError('Não foi possível identificar o plano salvo.');
    const featureCodes = [...new Set(form.featureCodes.split(',').map(code => code.trim().toLowerCase()).filter(Boolean))];
    if (featureCodes.some(code => !/^[a-z][a-z0-9_.-]{1,79}$/.test(code))) return setError('Use códigos de recurso válidos, separados por vírgula (ex.: optimizer.advanced).');
    const { error: clearFeaturesError } = await supabase.from('plan_features').delete().eq('plan_id', savedPlanId);
    if (clearFeaturesError) return setError(errorMessage(clearFeaturesError));
    if (featureCodes.length) {
      const { error: featureError } = await supabase.from('plan_features').insert(featureCodes.map(feature_code => ({ plan_id: savedPlanId, feature_code, enabled: true })));
      if (featureError) return setError(errorMessage(featureError));
    }
    onSaved();
    onClose();
  };

  return (
    <Modal
      open={open}
      title={plan ? 'Editar plano' : 'Novo plano'}
      description="Planos definem limites de instalação e validade para as licenças."
      onClose={onClose}
      size="lg"
      footer={
        <>
          <Button variant="secondary" onClick={onClose} disabled={saving}>
            Cancelar
          </Button>
          <Button type="submit" form="plan-form" loading={saving}>
            {plan ? 'Salvar alterações' : 'Criar plano'}
          </Button>
        </>
      }
    >
      <form id="plan-form" onSubmit={handleSubmit} className="grid gap-5 sm:grid-cols-2" noValidate>
        <div className="sm:col-span-2">
          <Field label="Nome do plano">
            <TextInput value={form.name} onChange={(event) => update('name', event.target.value)} maxLength={120} required />
          </Field>
        </div>
        <Field label="Instalações permitidas">
          <TextInput type="number" inputMode="numeric" min={1} max={100} value={form.maxActivations} onChange={(event) => update('maxActivations', event.target.value)} />
        </Field>
        <Field label="Validade (dias)" hint="Vazio para sem vencimento.">
          <TextInput type="number" inputMode="numeric" min={1} max={3650} value={form.validityDays} onChange={(event) => update('validityDays', event.target.value)} />
        </Field>
        <Field label="Preço (R$)" hint="Deixe vazio para plano não comercial.">
          <TextInput inputMode="decimal" placeholder="29,90" value={form.price} onChange={(event) => update('price', event.target.value)} />
        </Field>
        <Field label="Aplicativo liberado">
          <SelectInput value={form.appId} onChange={(event) => update('appId', event.target.value)}>
            <option value="">Nenhum (sem compra automática)</option>
            {apps.map(app => <option key={app.id} value={app.id}>{app.name}</option>)}
          </SelectInput>
        </Field>
        <Field label="Situação">
          <SelectInput value={form.status} onChange={(event) => update('status', event.target.value)}>
            <option value="active">Ativo</option>
            <option value="archived">Arquivado</option>
          </SelectInput>
        </Field>
        <div className="sm:col-span-2">
          <Field label="Recursos liberados" hint="Códigos separados por vírgula. Ex.: optimizer.basic, optimizer.advanced, app.download">
            <TextInput value={form.featureCodes} onChange={(event) => update('featureCodes', event.target.value)} placeholder="optimizer.basic, app.download" />
          </Field>
        </div>
        <div className="sm:col-span-2">
          <Field label="Descrição">
            <TextArea value={form.description} onChange={(event) => update('description', event.target.value)} maxLength={500} />
          </Field>
        </div>
        {error ? (
          <div className="sm:col-span-2">
            <Alert>{error}</Alert>
          </div>
        ) : null}
      </form>
    </Modal>
  );
}

export function PlansPage() {
  const [plans, setPlans] = useState<Plan[] | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Plan | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Plan | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  const loadPlans = useCallback(async () => {
    const { data, error } = await supabase.from('plans').select('*').order('name').returns<Plan[]>();
    if (error) return setLoadError(errorMessage(error));
    setLoadError(null);
    setPlans(data ?? []);
  }, []);

  useEffect(() => {
    loadPlans();
  }, [loadPlans]);

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    setDeleteError(null);
    const { error } = await supabase.from('plans').delete().eq('id', deleteTarget.id);
    setDeleting(false);
    if (error) return setDeleteError(errorMessage(error));
    setDeleteTarget(null);
    loadPlans();
  };

  return (
    <div className="animate-fade-up space-y-8">
      <PageHeader
        title="Planos"
        description="Modelos de licença com limites de instalação e validade, prontos para orientar a geração de KEYs."
        actions={
          <Button icon={Plus} onClick={() => { setEditing(null); setFormOpen(true); }}>
            Novo plano
          </Button>
        }
      />

      {loadError ? <Alert>{loadError}</Alert> : null}

      {plans === null && !loadError ? (
        <Spinner label="Carregando planos" />
      ) : plans && plans.length === 0 ? (
        <div className="surface">
          <EmptyState icon={Layers} title="Nenhum plano cadastrado" description="Crie planos para padronizar limites e validades das licenças." action={<Button icon={Plus} onClick={() => setFormOpen(true)}>Criar plano</Button>} />
        </div>
      ) : plans ? (
        <ul className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
          {plans.map((plan) => (
            <li key={plan.id} className="surface flex flex-col gap-5 p-6">
              <div className="flex items-start justify-between gap-3">
                <h2 className="font-display text-lg font-semibold text-graphite-50">{plan.name}</h2>
                <Badge tone={plan.status === 'active' ? 'success' : 'neutral'}>{plan.status === 'active' ? 'Ativo' : 'Arquivado'}</Badge>
              </div>
              <dl className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <dt className="text-xs text-graphite-400">Instalações</dt>
                  <dd className="font-medium text-graphite-100">{plan.max_activations}</dd>
                </div>
                <div>
                  <dt className="text-xs text-graphite-400">Validade</dt>
                  <dd className="font-medium text-graphite-100">{plan.validity_days ? `${plan.validity_days} dias` : 'Sem vencimento'}</dd>
                </div>
                <div>
                  <dt className="text-xs text-graphite-400">Preço</dt>
                  <dd className="font-medium text-graphite-100">{plan.price_cents == null ? 'Não comercial' : (plan.price_cents / 100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</dd>
                </div>
              </dl>
              {plan.description ? <p className="line-clamp-3 text-sm text-graphite-300">{plan.description}</p> : null}
              <div className="mt-auto flex justify-end gap-1 border-t border-graphite-700 pt-4">
                <IconButton icon={Pencil} label="Editar plano" onClick={() => { setEditing(plan); setFormOpen(true); }} />
                <IconButton icon={Trash2} label="Excluir plano" tone="danger" onClick={() => { setDeleteError(null); setDeleteTarget(plan); }} />
              </div>
            </li>
          ))}
        </ul>
      ) : null}

      <PlanFormModal open={formOpen} plan={editing} onClose={() => setFormOpen(false)} onSaved={loadPlans} />

      <ConfirmModal
        open={deleteTarget !== null}
        title="Excluir plano"
        message={`O plano ${deleteTarget?.name ?? ''} será removido. As KEYs já geradas não são alteradas.`}
        confirmLabel="Excluir"
        busy={deleting}
        error={deleteError}
        onConfirm={handleDelete}
        onClose={() => setDeleteTarget(null)}
      />
    </div>
  );
}
