import { useEffect, useState, type FormEvent } from 'react';
import { Palette, Save } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { errorMessage } from '@/lib/errors';
import type { AppCustomization, StudioApp } from '@/types/studio';
import { Alert, Button, EmptyState, Field, PageHeader, SelectInput, Spinner, TextArea, TextInput } from '@/components/ui';

const HEX_PATTERN = /^#[0-9A-Fa-f]{6}$/;
const DEFAULT_COLOR = '#8F001A';

interface CustomizationForm {
  displayName: string;
  tagline: string;
  primaryColor: string;
  supportEmail: string;
  welcomeMessage: string;
}

const EMPTY_FORM: CustomizationForm = { displayName: '', tagline: '', primaryColor: DEFAULT_COLOR, supportEmail: '', welcomeMessage: '' };
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function CustomizationPage() {
  const [apps, setApps] = useState<StudioApp[] | null>(null);
  const [appId, setAppId] = useState('');
  const [form, setForm] = useState<CustomizationForm>(EMPTY_FORM);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    supabase
      .from('apps')
      .select('*')
      .order('name')
      .returns<StudioApp[]>()
      .then(({ data, error: appsError }) => {
        if (appsError) return setError(errorMessage(appsError));
        setApps(data ?? []);
        setAppId(data?.[0]?.id ?? '');
      });
  }, []);

  useEffect(() => {
    if (!appId) return;
    let cancelled = false;
    setLoading(true);
    setError(null);
    setSaved(false);
    (async () => {
      const { data, error: loadError } = await supabase
        .from('app_customizations')
        .select('*')
        .eq('app_id', appId)
        .maybeSingle<AppCustomization>();
      if (cancelled) return;
      setLoading(false);
      if (loadError) return setError(errorMessage(loadError));
      setForm(
        data
          ? {
              displayName: data.display_name,
              tagline: data.tagline ?? '',
              primaryColor: data.primary_color,
              supportEmail: data.support_email ?? '',
              welcomeMessage: data.welcome_message ?? '',
            }
          : { ...EMPTY_FORM, displayName: apps?.find((app) => app.id === appId)?.name ?? '' }
      );
    })();
    return () => {
      cancelled = true;
    };
    // The app list is only used to prefill the display name when no customization exists yet.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [appId]);

  const update = (field: keyof CustomizationForm, value: string) => {
    setSaved(false);
    setForm((current) => ({ ...current, [field]: value }));
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!form.displayName.trim()) return setError('Informe o nome exibido no aplicativo.');
    if (!HEX_PATTERN.test(form.primaryColor)) return setError('Informe uma cor no formato #RRGGBB.');
    if (form.supportEmail.trim() && !EMAIL_PATTERN.test(form.supportEmail.trim())) return setError('Informe um e-mail de suporte válido.');

    setError(null);
    setSaving(true);
    const { error: saveError } = await supabase.from('app_customizations').upsert(
      {
        app_id: appId,
        display_name: form.displayName.trim(),
        tagline: form.tagline.trim() || null,
        primary_color: form.primaryColor,
        support_email: form.supportEmail.trim() || null,
        welcome_message: form.welcomeMessage.trim() || null,
        updated_at: new Date().toISOString(),
      },
      { onConflict: 'app_id' }
    );
    setSaving(false);
    if (saveError) return setError(errorMessage(saveError));
    setSaved(true);
  };

  if (apps === null) return <Spinner label="Carregando aplicativos" />;

  return (
    <div className="animate-fade-up space-y-8">
      <PageHeader
        title="Personalização"
        description="Defina a identidade visual e as mensagens que o VT ACCESS exibirá para cada aplicativo do catálogo."
      />

      {apps.length === 0 ? (
        <div className="surface">
          <EmptyState icon={Palette} title="Nenhum aplicativo cadastrado" description="Cadastre um aplicativo para personalizar sua identidade." action={<a href="#/apps" className="text-sm text-crimson-300 hover:text-crimson-200">Ir para aplicativos</a>} />
        </div>
      ) : (
        <div className="grid gap-8 xl:grid-cols-5">
          <form onSubmit={handleSubmit} className="surface space-y-6 p-6 xl:col-span-3" noValidate>
            <Field label="Aplicativo">
              <SelectInput value={appId} onChange={(event) => setAppId(event.target.value)}>
                {apps.map((app) => (
                  <option key={app.id} value={app.id}>
                    {app.name}
                  </option>
                ))}
              </SelectInput>
            </Field>

            {loading ? (
              <Spinner label="Carregando personalização" />
            ) : (
              <>
                <div className="grid gap-5 sm:grid-cols-2">
                  <Field label="Nome exibido">
                    <TextInput value={form.displayName} onChange={(event) => update('displayName', event.target.value)} maxLength={60} required />
                  </Field>
                  <Field label="Slogan">
                    <TextInput value={form.tagline} onChange={(event) => update('tagline', event.target.value)} maxLength={90} />
                  </Field>
                  <Field label="Cor principal">
                    <div className="flex items-center gap-3">
                      <input
                        type="color"
                        aria-label="Selecionar cor principal"
                        value={HEX_PATTERN.test(form.primaryColor) ? form.primaryColor : DEFAULT_COLOR}
                        onChange={(event) => update('primaryColor', event.target.value.toUpperCase())}
                        className="h-11 w-14 cursor-pointer rounded-lg border border-graphite-600 bg-ink p-1"
                      />
                      <TextInput value={form.primaryColor} onChange={(event) => update('primaryColor', event.target.value.toUpperCase())} maxLength={7} className="font-mono" />
                    </div>
                  </Field>
                  <Field label="E-mail de suporte">
                    <TextInput type="email" value={form.supportEmail} onChange={(event) => update('supportEmail', event.target.value)} maxLength={160} />
                  </Field>
                </div>
                <Field label="Mensagem de boas-vindas">
                  <TextArea value={form.welcomeMessage} onChange={(event) => update('welcomeMessage', event.target.value)} maxLength={280} />
                </Field>
                {error ? <Alert>{error}</Alert> : null}
                <div className="flex items-center justify-end gap-4">
                  {saved ? <p className="text-sm text-success-400">Personalização salva.</p> : null}
                  <Button type="submit" icon={Save} loading={saving}>
                    Salvar personalização
                  </Button>
                </div>
              </>
            )}
          </form>

          <aside className="space-y-3 xl:col-span-2">
            <p className="text-xs font-medium uppercase tracking-wider text-graphite-400">Pré-visualização (demonstração)</p>
            <div className="mx-auto w-full max-w-xs overflow-hidden rounded-[2rem] border-4 border-graphite-700 bg-ink shadow-2xl">
              <div className="h-40 p-6" style={{ background: `linear-gradient(160deg, ${form.primaryColor}, #090909)` }}>
                <p className="font-display text-xl font-semibold text-white">{form.displayName || 'Nome do app'}</p>
                <p className="mt-1 text-sm text-white/80">{form.tagline || 'Slogan do aplicativo'}</p>
              </div>
              <div className="space-y-4 p-6">
                <p className="text-sm text-graphite-200">{form.welcomeMessage || 'A mensagem de boas-vindas aparece aqui.'}</p>
                <div className="rounded-lg py-2.5 text-center text-sm font-medium text-white" style={{ backgroundColor: form.primaryColor }}>
                  Ativar KEY
                </div>
                {form.supportEmail ? <p className="text-center text-xs text-graphite-400">Suporte: {form.supportEmail}</p> : null}
              </div>
            </div>
            <p className="text-xs text-graphite-400">
              Esta visualização é apenas ilustrativa. O aplicativo Android passará a ler estas configurações quando for conectado ao backend.
            </p>
          </aside>
        </div>
      )}
    </div>
  );
}
