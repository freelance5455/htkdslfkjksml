import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { AppWindow, Package, Pencil, Plus, Trash2, SlidersHorizontal, Palette } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { errorMessage } from '@/lib/errors';
import type { AppStatus, StudioApp } from '@/types/studio';
import { Alert, Badge, Button, ConfirmModal, EmptyState, Field, IconButton, Modal, PageHeader, SelectInput, Spinner, TextArea, TextInput } from '@/components/ui';
import { RELEASE_BUCKET, ReleasesModal } from '@/components/apps/ReleasesModal';

const STATUS_LABELS: Record<AppStatus, string> = { draft: 'Rascunho', published: 'Publicado', archived: 'Arquivado' };
const STATUS_TONES: Record<AppStatus, 'warning' | 'success' | 'neutral'> = { draft: 'warning', published: 'success', archived: 'neutral' };
const PACKAGE_PATTERN = /^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/;

interface AppFormState {
  name: string;
  package_name: string;
  version: string;
  description: string;
  status: AppStatus;
}

const EMPTY_FORM: AppFormState = { name: '', package_name: '', version: '1.0.0', description: '', status: 'draft' };

function AppFormModal({ app, open, onClose, onSaved }: { app: StudioApp | null; open: boolean; onClose: () => void; onSaved: () => void }) {
  const [form, setForm] = useState<AppFormState>(EMPTY_FORM);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!open) return;
    setError(null);
    setForm(
      app
        ? { name: app.name, package_name: app.package_name, version: app.version, description: app.description ?? '', status: app.status }
        : EMPTY_FORM
    );
  }, [open, app]);

  const update = (field: keyof AppFormState, value: string) => setForm((current) => ({ ...current, [field]: value }));

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const name = form.name.trim();
    const packageName = form.package_name.trim();
    const version = form.version.trim();
    if (!name) return setError('Informe o nome do aplicativo.');
    if (!PACKAGE_PATTERN.test(packageName)) return setError('Use o formato do pacote Android, por exemplo com.empresa.app.');
    if (!version) return setError('Informe a versão.');

    const payload = {
      name,
      package_name: packageName,
      version,
      description: form.description.trim() || null,
      status: form.status,
      updated_at: new Date().toISOString(),
    };

    setError(null);
    setSaving(true);
    const result = app
      ? await supabase.from('apps').update(payload).eq('id', app.id)
      : await supabase.from('apps').insert(payload);
    setSaving(false);

    if (result.error) return setError(errorMessage(result.error));
    onSaved();
    onClose();
  };

  return (
    <Modal
      open={open}
      title={app ? 'Editar aplicativo' : 'Novo aplicativo'}
      description="Aplicativos do catálogo podem receber KEYs, planos e otimizações."
      onClose={onClose}
      size="lg"
      footer={
        <>
          <Button variant="secondary" onClick={onClose} disabled={saving}>
            Cancelar
          </Button>
          <Button type="submit" form="app-form" loading={saving}>
            {app ? 'Salvar alterações' : 'Cadastrar aplicativo'}
          </Button>
        </>
      }
    >
      <form id="app-form" onSubmit={handleSubmit} className="grid gap-5 sm:grid-cols-2" noValidate>
        <Field label="Nome">
          <TextInput value={form.name} onChange={(event) => update('name', event.target.value)} maxLength={120} required />
        </Field>
        <Field label="Pacote Android" hint="Identificador único, ex.: com.empresa.app">
          <TextInput value={form.package_name} onChange={(event) => update('package_name', event.target.value)} maxLength={150} required />
        </Field>
        <Field label="Versão">
          <TextInput value={form.version} onChange={(event) => update('version', event.target.value)} maxLength={30} required />
        </Field>
        <Field label="Situação">
          <SelectInput value={form.status} onChange={(event) => update('status', event.target.value)}>
            <option value="draft">Rascunho</option>
            <option value="published">Publicado</option>
            <option value="archived">Arquivado</option>
          </SelectInput>
        </Field>
        <div className="sm:col-span-2">
          <Field label="Descrição">
            <TextArea value={form.description} onChange={(event) => update('description', event.target.value)} maxLength={500} />
          </Field>
        </div>
        {error ? (
          <div className="sm:col-span-2">
            <Alert>{error}</Alert>
          </div>
        ) : null}
      </form>
    </Modal>
  );
}

export function AppsPage() {
  const [apps, setApps] = useState<StudioApp[] | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<StudioApp | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<StudioApp | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);
  const [releasesApp, setReleasesApp] = useState<StudioApp | null>(null);

  const loadApps = useCallback(async () => {
    const { data, error } = await supabase.from('apps').select('*').order('name').returns<StudioApp[]>();
    if (error) return setLoadError(errorMessage(error));
    setLoadError(null);
    setApps(data ?? []);
  }, []);

  useEffect(() => {
    loadApps();
  }, [loadApps]);

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    setDeleteError(null);
    const { data: releases, error: releasesErr } = await supabase
      .from('app_releases')
      .select('storage_path')
      .eq('app_id', deleteTarget.id)
      .returns<{ storage_path: string }[]>();
    if (releasesErr) {
      setDeleting(false);
      return setDeleteError(errorMessage(releasesErr));
    }
    const paths = (releases ?? []).map((release) => release.storage_path);
    if (paths.length > 0) {
      const { error: storageErr } = await supabase.storage.from(RELEASE_BUCKET).remove(paths);
      if (storageErr) {
        setDeleting(false);
        return setDeleteError(errorMessage(storageErr));
      }
    }
    const { error } = await supabase.from('apps').delete().eq('id', deleteTarget.id);
    setDeleting(false);
    if (error) return setDeleteError(errorMessage(error));
    setDeleteTarget(null);
    loadApps();
  };

  return (
    <div className="animate-fade-up space-y-8">
      <PageHeader
        title="Aplicativos"
        description="Catálogo de aplicativos administrados pelo VT STUDIO. Apps com KEYs vinculadas não podem ser removidos."
        actions={
          <Button icon={Plus} onClick={() => { setEditing(null); setFormOpen(true); }}>
            Novo aplicativo
          </Button>
        }
      />

      {loadError ? <Alert>{loadError}</Alert> : null}

      {apps === null && !loadError ? (
        <Spinner label="Carregando aplicativos" />
      ) : apps && apps.length === 0 ? (
        <div className="surface">
          <EmptyState
            icon={AppWindow}
            title="Nenhum aplicativo cadastrado"
            description="Cadastre o VT ACCESS para começar a gerar KEYs e configurar sua personalização."
            action={<Button icon={Plus} onClick={() => { setEditing(null); setFormOpen(true); }}>Cadastrar aplicativo</Button>}
          />
        </div>
      ) : apps ? (
        <ul className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
          {apps.map((app) => (
            <li key={app.id} className="surface flex flex-col gap-5 p-6 transition-all duration-200 hover:-translate-y-0.5 hover:border-graphite-600">
              <div className="flex items-start justify-between gap-3">
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-crimson-700/20 ring-1 ring-inset ring-crimson-700/40">
                  <AppWindow className="h-5 w-5 text-crimson-300" aria-hidden="true" />
                </div>
                <Badge tone={STATUS_TONES[app.status]}>{STATUS_LABELS[app.status]}</Badge>
              </div>
              <div className="min-w-0 flex-1 space-y-1.5">
                <h2 className="font-display text-lg font-semibold text-graphite-50">{app.name}</h2>
                <p className="truncate font-mono text-xs text-graphite-400">{app.package_name}</p>
                <p className="text-xs text-graphite-400">Versão {app.version}</p>
                {app.description ? <p className="line-clamp-3 pt-2 text-sm text-graphite-300">{app.description}</p> : null}
              </div>
              <div className="flex flex-wrap items-center justify-between gap-2 border-t border-graphite-700 pt-4">
                <div className="flex gap-2">
                  <a href="#/customization" className="inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-medium text-graphite-300 transition-colors hover:bg-graphite-700 hover:text-graphite-50">
                    <Palette className="h-3.5 w-3.5" aria-hidden="true" /> Personalizar
                  </a>
                  <a href="#/optimizations" className="inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-medium text-graphite-300 transition-colors hover:bg-graphite-700 hover:text-graphite-50">
                    <SlidersHorizontal className="h-3.5 w-3.5" aria-hidden="true" /> Otimizações
                  </a>
                  <button type="button" onClick={() => setReleasesApp(app)} className="inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-medium text-graphite-300 transition-colors hover:bg-graphite-700 hover:text-graphite-50">
                    <Package className="h-3.5 w-3.5" aria-hidden="true" /> Arquivos
                  </button>
                </div>
                <div className="flex gap-1">
                  <IconButton icon={Pencil} label="Editar aplicativo" onClick={() => { setEditing(app); setFormOpen(true); }} />
                  <IconButton icon={Trash2} label="Excluir aplicativo" tone="danger" onClick={() => { setDeleteError(null); setDeleteTarget(app); }} />
                </div>
              </div>
            </li>
          ))}
        </ul>
      ) : null}

      <AppFormModal open={formOpen} app={editing} onClose={() => setFormOpen(false)} onSaved={loadApps} />

      <ReleasesModal app={releasesApp} onClose={() => setReleasesApp(null)} />

      <ConfirmModal
        open={deleteTarget !== null}
        title="Excluir aplicativo"
        message={`${deleteTarget?.name ?? 'Este aplicativo'} e suas otimizações serão removidos do catálogo. Esta ação não pode ser desfeita.`}
        confirmLabel="Excluir"
        busy={deleting}
        error={deleteError}
        onConfirm={handleDelete}
        onClose={() => setDeleteTarget(null)}
      />
    </div>
  );
}
