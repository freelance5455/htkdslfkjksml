import { useEffect, useState } from 'react';
import { CalendarClock, KeyRound, Smartphone, Users, AppWindow, ShieldCheck, Check, Clock, type LucideIcon } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { errorMessage } from '@/lib/errors';
import { maskedLicenseKey } from '@/lib/licenseKeys';
import { Alert, Badge, EmptyState, PageHeader, Spinner } from '@/components/ui';
import type { StudioRoute } from '@/components/AppShell';

interface DashboardStats {
  clientsTotal: number;
  clientsActive: number;
  keysTotal: number;
  keysActive: number;
  keysExpiringSoon: number;
  activationsTotal: number;
  appsPublished: number;
}

interface RecentActivation {
  id: string;
  installation_id: string;
  device_label: string | null;
  activated_at: string;
  license_key: { key_prefix: string } | null;
}

const EXPIRY_WINDOW_DAYS = 30;

const DATE_FORMAT = new Intl.DateTimeFormat('pt-BR', { dateStyle: 'short', timeStyle: 'short' });

async function countRows(build: () => PromiseLike<{ count: number | null; error: unknown }>): Promise<number> {
  const { count, error } = await build();
  if (error) throw error;
  return count ?? 0;
}

async function loadDashboard(): Promise<{ stats: DashboardStats; recent: RecentActivation[] }> {
  const now = new Date();
  const horizon = new Date(now.getTime() + EXPIRY_WINDOW_DAYS * 24 * 60 * 60 * 1000);

  const [clientsTotal, clientsActive, keysTotal, keysActive, keysExpiringSoon, activationsTotal, appsPublished, recentResult] =
    await Promise.all([
      countRows(() => supabase.from('clients').select('id', { count: 'exact', head: true })),
      countRows(() => supabase.from('clients').select('id', { count: 'exact', head: true }).eq('status', 'active')),
      countRows(() => supabase.from('license_keys').select('id', { count: 'exact', head: true })),
      countRows(() => supabase.from('license_keys').select('id', { count: 'exact', head: true }).eq('status', 'active')),
      countRows(() =>
        supabase
          .from('license_keys')
          .select('id', { count: 'exact', head: true })
          .eq('status', 'active')
          .gte('expires_at', now.toISOString())
          .lte('expires_at', horizon.toISOString())
      ),
      countRows(() => supabase.from('activations').select('id', { count: 'exact', head: true })),
      countRows(() => supabase.from('apps').select('id', { count: 'exact', head: true }).eq('status', 'published')),
      supabase
        .from('activations')
        .select('id, installation_id, device_label, activated_at, license_key:license_keys(key_prefix)')
        .order('activated_at', { ascending: false })
        .limit(5)
        .returns<RecentActivation[]>(),
    ]);

  if (recentResult.error) throw recentResult.error;

  return {
    stats: {
      clientsTotal,
      clientsActive,
      keysTotal,
      keysActive,
      keysExpiringSoon,
      activationsTotal,
      appsPublished,
    },
    recent: recentResult.data ?? [],
  };
}

interface StatCardProps {
  icon: LucideIcon;
  label: string;
  value: number;
  detail: string;
  href: StudioRoute;
}

function StatCard({ icon: Icon, label, value, detail, href }: StatCardProps) {
  return (
    <a
      href={`#/${href}`}
      className="surface group flex flex-col gap-4 p-5 transition-all duration-200 hover:-translate-y-0.5 hover:border-crimson-700/60 hover:shadow-lg hover:shadow-crimson-900/20"
    >
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium text-graphite-300">{label}</span>
        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-crimson-700/15 ring-1 ring-inset ring-crimson-700/40">
          <Icon className="h-4 w-4 text-crimson-300" aria-hidden="true" />
        </div>
      </div>
      <div className="space-y-1">
        <p className="font-display text-3xl font-semibold text-graphite-50">{value}</p>
        <p className="text-xs text-graphite-400">{detail}</p>
      </div>
    </a>
  );
}

const MODULES: { name: string; description: string; status: 'available' | 'next' }[] = [
  { name: 'VT STUDIO (painel)', description: 'Gestão de chaves, clientes, licenças, apps e configurações.', status: 'available' },
  { name: 'Validação de licenças no servidor', description: 'Ativação de KEY por instalação com verificação no backend.', status: 'next' },
  { name: 'VT ACCESS (Android)', description: 'Aplicativo Kotlin e Jetpack Compose que consome as licenças.', status: 'next' },
];

export function DashboardPage() {
  const [data, setData] = useState<{ stats: DashboardStats; recent: RecentActivation[] } | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    loadDashboard()
      .then((result) => {
        if (!cancelled) setData(result);
      })
      .catch((caught: unknown) => {
        if (!cancelled) setError(errorMessage(caught));
      });
    return () => {
      cancelled = true;
    };
  }, []);

  if (error) {
    return (
      <div className="space-y-6">
        <PageHeader title="Dashboard" description="Visão geral do ecossistema VT ACCESS." />
        <Alert>{error}</Alert>
      </div>
    );
  }

  if (!data) {
    return <Spinner label="Carregando indicadores" />;
  }

  const { stats, recent } = data;

  return (
    <div className="animate-fade-up space-y-10">
      <PageHeader title="Dashboard" description="Visão geral de clientes, chaves e instalações ativas do ecossistema VT ACCESS." />

      <section aria-labelledby="stats-heading" className="space-y-4">
        <h2 id="stats-heading" className="sr-only">
          Indicadores
        </h2>
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <StatCard icon={KeyRound} label="Chaves ativas" value={stats.keysActive} detail={`${stats.keysTotal} no total`} href="keys" />
          <StatCard icon={CalendarClock} label="Vencem em 30 dias" value={stats.keysExpiringSoon} detail="Chaves ativas com validade próxima" href="keys" />
          <StatCard icon={Smartphone} label="Instalações ativadas" value={stats.activationsTotal} detail="Dispositivos vinculados às chaves" href="keys" />
          <StatCard icon={Users} label="Clientes" value={stats.clientsTotal} detail={`${stats.clientsActive} ativos`} href="clients" />
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <StatCard icon={AppWindow} label="Apps publicados" value={stats.appsPublished} detail="Itens publicados no catálogo" href="apps" />
          <StatCard icon={ShieldCheck} label="Chaves totais" value={stats.keysTotal} detail="Incluindo revogadas" href="keys" />
        </div>
      </section>

      <div className="grid gap-6 xl:grid-cols-5">
        <section aria-labelledby="recent-heading" className="surface space-y-5 p-6 xl:col-span-3">
          <div className="flex items-center justify-between">
            <h2 id="recent-heading" className="font-display text-base font-semibold text-graphite-50">
              Ativações recentes
            </h2>
            <a href="#/keys" className="text-sm text-crimson-300 transition-colors hover:text-crimson-200">
              Ver KEYs
            </a>
          </div>
          {recent.length === 0 ? (
            <EmptyState
              icon={Smartphone}
              title="Nenhuma ativação ainda"
              description="Quando uma instalação do VT ACCESS ativar uma KEY, ela aparecerá aqui."
            />
          ) : (
            <ul className="divide-y divide-graphite-700">
              {recent.map((item) => (
                <li key={item.id} className="flex items-center justify-between gap-4 py-3">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium text-graphite-100">{item.device_label ?? 'Dispositivo sem nome'}</p>
                    <p className="font-mono text-xs text-graphite-400">
                      {item.license_key ? maskedLicenseKey(item.license_key.key_prefix) : 'Chave removida'}
                    </p>
                  </div>
                  <div className="flex shrink-0 items-center gap-2 text-xs text-graphite-400">
                    <Clock className="h-3.5 w-3.5" aria-hidden="true" />
                    {DATE_FORMAT.format(new Date(item.activated_at))}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section aria-labelledby="modules-heading" className="surface space-y-5 p-6 xl:col-span-2">
          <h2 id="modules-heading" className="font-display text-base font-semibold text-graphite-50">
            Estado do ecossistema
          </h2>
          <ul className="space-y-4">
            {MODULES.map((module) => (
              <li key={module.name} className="flex items-start justify-between gap-4">
                <div className="space-y-1">
                  <p className="text-sm font-medium text-graphite-100">{module.name}</p>
                  <p className="text-xs text-graphite-400">{module.description}</p>
                </div>
                {module.status === 'available' ? (
                  <Badge tone="success">
                    <Check className="h-3 w-3" aria-hidden="true" />
                    Disponível
                  </Badge>
                ) : (
                  <Badge tone="warning">Próxima etapa</Badge>
                )}
              </li>
            ))}
          </ul>
        </section>
      </div>
    </div>
  );
}
