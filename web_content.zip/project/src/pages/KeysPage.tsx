import { useCallback, useEffect, useMemo, useState } from 'react';
import { Ban, Eye, KeyRound, Plus, RotateCcw, Search } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { errorMessage } from '@/lib/errors';
import { getLicenseState, maskedLicenseKey, type LicenseState } from '@/lib/licenseKeys';
import type { Client, LicenseKeyRow } from '@/types/studio';
import { Alert, Badge, Button, ConfirmModal, EmptyState, IconButton, PageHeader, Spinner, TextInput } from '@/components/ui';
import { GenerateKeysModal } from '@/components/keys/GenerateKeysModal';
import { LicenseDetailModal } from '@/components/licenses/LicenseDetailModal';

type StatusFilter = 'all' | LicenseState;

const STATUS_LABELS: Record<LicenseState, string> = {
  active: 'Ativa',
  revoked: 'Revogada',
  expired: 'Vencida',
};

const STATUS_TONES: Record<LicenseState, 'success' | 'danger' | 'warning'> = {
  active: 'success',
  revoked: 'danger',
  expired: 'warning',
};

const DATE_FORMAT = new Intl.DateTimeFormat('pt-BR', { dateStyle: 'medium' });
const KEY_SELECT =
  'id, key_prefix, status, max_activations, expires_at, notes, created_at, revoked_at, app_id, client_id, app:apps(name), client:clients(name), activations(count)';

function installationsUsed(row: LicenseKeyRow): number {
  return row.activations[0]?.count ?? 0;
}

export function KeysPage() {
  const [rows, setRows] = useState<LicenseKeyRow[] | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');
  const [search, setSearch] = useState('');
  const [generatorOpen, setGeneratorOpen] = useState(false);
  const [toggleTarget, setToggleTarget] = useState<LicenseKeyRow | null>(null);
  const [toggling, setToggling] = useState(false);
  const [toggleError, setToggleError] = useState<string | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [clients, setClients] = useState<Client[]>([]);

  useEffect(() => {
    supabase
      .from('clients')
      .select('*')
      .order('name')
      .returns<Client[]>()
      .then(({ data }) => setClients(data ?? []));
  }, []);

  const loadKeys = useCallback(async () => {
    const { data, error } = await supabase
      .from('license_keys')
      .select(KEY_SELECT)
      .order('created_at', { ascending: false })
      .returns<LicenseKeyRow[]>();
    if (error) {
      setLoadError(errorMessage(error));
      return;
    }
    setLoadError(null);
    setRows(data ?? []);
  }, []);

  useEffect(() => {
    loadKeys();
  }, [loadKeys]);

  const filteredRows = useMemo(() => {
    if (!rows) return [];
    const term = search.trim().toLowerCase();
    return rows.filter((row) => {
      if (statusFilter !== 'all' && getLicenseState(row) !== statusFilter) return false;
      if (!term) return true;
      return (
        row.key_prefix.toLowerCase().includes(term) ||
        (row.app?.name ?? '').toLowerCase().includes(term) ||
        (row.client?.name ?? '').toLowerCase().includes(term)
      );
    });
  }, [rows, statusFilter, search]);

  const handleToggle = async () => {
    if (!toggleTarget) return;
    const revoking = toggleTarget.status === 'active';
    setToggling(true);
    setToggleError(null);
    const { error } = await supabase
      .from('license_keys')
      .update(revoking ? { status: 'revoked', revoked_at: new Date().toISOString() } : { status: 'active', revoked_at: null })
      .eq('id', toggleTarget.id);
    setToggling(false);
    if (error) {
      setToggleError(errorMessage(error));
      return;
    }
    setToggleTarget(null);
    await loadKeys();
  };

  const counts = useMemo(() => {
    const base = { all: rows?.length ?? 0, active: 0, revoked: 0, expired: 0 };
    rows?.forEach((row) => {
      base[getLicenseState(row)] += 1;
    });
    return base;
  }, [rows]);

  return (
    <div className="animate-fade-up space-y-8">
      <PageHeader
        title="Chaves (KEYs)"
        description="Gere chaves de ativação individuais, acompanhe seu estado e revogue quando necessário."
        actions={
          <Button icon={Plus} onClick={() => setGeneratorOpen(true)}>
            Gerar KEYs
          </Button>
        }
      />

      {loadError ? <Alert>{loadError}</Alert> : null}

      {rows === null && !loadError ? (
        <Spinner label="Carregando chaves" />
      ) : rows && rows.length === 0 ? (
        <div className="surface">
          <EmptyState
            icon={KeyRound}
            title="Nenhuma KEY gerada"
            description="Gere a primeira KEY para liberar o VT ACCESS em uma instalação. A chave completa é exibida apenas uma vez, no momento da criação."
            action={<Button icon={Plus} onClick={() => setGeneratorOpen(true)}>Gerar primeira KEY</Button>}
          />
        </div>
      ) : rows ? (
        <div className="space-y-5">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex flex-wrap gap-2" role="group" aria-label="Filtrar por estado">
              {(['all', 'active', 'expired', 'revoked'] as StatusFilter[]).map((filter) => {
                const active = statusFilter === filter;
                const label = filter === 'all' ? 'Todas' : STATUS_LABELS[filter];
                return (
                  <button
                    key={filter}
                    type="button"
                    aria-pressed={active}
                    onClick={() => setStatusFilter(filter)}
                    className={`rounded-full px-3.5 py-1.5 text-xs font-medium ring-1 ring-inset transition-all duration-200 ${
                      active
                        ? 'bg-crimson-700 text-white ring-crimson-600'
                        : 'text-graphite-300 ring-graphite-600 hover:text-graphite-50 hover:ring-graphite-500'
                    }`}
                  >
                    {label} <span className="opacity-70">({counts[filter]})</span>
                  </button>
                );
              })}
            </div>
            <div className="relative sm:w-72">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-graphite-400" aria-hidden="true" />
              <TextInput
                type="search"
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="Buscar por chave, app ou cliente"
                aria-label="Buscar chaves"
                className="pl-9"
              />
            </div>
          </div>

          <div className="surface overflow-hidden">
            {filteredRows.length === 0 ? (
              <EmptyState icon={Search} title="Nenhum resultado" description="Ajuste o filtro ou a busca para ver outras chaves." />
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full min-w-[760px] text-left text-sm">
                  <thead className="border-b border-graphite-700 text-xs uppercase tracking-wider text-graphite-400">
                    <tr>
                      <th className="px-5 py-3 font-medium">Chave</th>
                      <th className="px-5 py-3 font-medium">Aplicativo</th>
                      <th className="px-5 py-3 font-medium">Cliente</th>
                      <th className="px-5 py-3 font-medium">Instalações</th>
                      <th className="px-5 py-3 font-medium">Validade</th>
                      <th className="px-5 py-3 font-medium">Estado</th>
                      <th className="px-5 py-3 text-right font-medium">Ações</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-graphite-700/70">
                    {filteredRows.map((row) => {
                      const state = getLicenseState(row);
                      return (
                        <tr key={row.id} className="transition-colors duration-150 hover:bg-graphite-700/30">
                          <td className="px-5 py-4 font-mono text-xs text-graphite-100">{maskedLicenseKey(row.key_prefix)}</td>
                          <td className="px-5 py-4 text-graphite-200">{row.app?.name ?? '-'}</td>
                          <td className="px-5 py-4 text-graphite-300">{row.client?.name ?? <span className="text-graphite-500">Sem cliente</span>}</td>
                          <td className="px-5 py-4 tabular-nums text-graphite-200">
                            {installationsUsed(row)} / {row.max_activations}
                          </td>
                          <td className="px-5 py-4 text-graphite-300">
                            {row.expires_at ? DATE_FORMAT.format(new Date(row.expires_at)) : 'Sem vencimento'}
                          </td>
                          <td className="px-5 py-4">
                            <Badge tone={STATUS_TONES[state]}>{STATUS_LABELS[state]}</Badge>
                          </td>
                          <td className="px-5 py-4">
                            <div className="flex justify-end gap-1">
                              <IconButton icon={Eye} label="Ver detalhes da licença" onClick={() => setSelectedId(row.id)} />
                              {row.status === 'active' ? (
                                <IconButton icon={Ban} label="Revogar KEY" tone="danger" onClick={() => setToggleTarget(row)} />
                              ) : (
                                <IconButton icon={RotateCcw} label="Reativar KEY" onClick={() => setToggleTarget(row)} />
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      ) : null}

      <LicenseDetailModal license={rows?.find((row) => row.id === selectedId) ?? null} clients={clients} onClose={() => setSelectedId(null)} onChanged={loadKeys} />

      <GenerateKeysModal open={generatorOpen} onClose={() => setGeneratorOpen(false)} onGenerated={loadKeys} />

      <ConfirmModal
        open={toggleTarget !== null}
        title={toggleTarget?.status === 'active' ? 'Revogar KEY' : 'Reativar KEY'}
        message={
          toggleTarget?.status === 'active'
            ? `A chave ${toggleTarget ? maskedLicenseKey(toggleTarget.key_prefix) : ''} deixará de funcionar em todas as instalações. Você poderá reativá-la depois.`
            : `A chave ${toggleTarget ? maskedLicenseKey(toggleTarget.key_prefix) : ''} voltará a ser válida, respeitando a validade e o limite de instalações.`
        }
        confirmLabel={toggleTarget?.status === 'active' ? 'Revogar' : 'Reativar'}
        tone={toggleTarget?.status === 'active' ? 'danger' : 'primary'}
        busy={toggling}
        error={toggleError}
        onConfirm={handleToggle}
        onClose={() => {
          setToggleTarget(null);
          setToggleError(null);
        }}
      />
    </div>
  );
}
