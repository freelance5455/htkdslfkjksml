import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { SlidersHorizontal, Plus, Trash2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { errorMessage } from '@/lib/errors';
import type { StudioApp } from '@/types/studio';
import { Alert, Button, ConfirmModal, EmptyState, Field, IconButton, Modal, PageHeader, SelectInput, Spinner, TextInput } from '@/components/ui';

interface AppOptimization {
  id: string;
  app_id: string;
  name: string;
  description: string | null;
  enabled: boolean;
  feature_code: string;
}

export function OptimizationsPage() {
  const [apps, setApps] = useState<StudioApp[] | null>(null);
  const [appId, setAppId] = useState('');
  const [items, setItems] = useState<AppOptimization[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [createOpen, setCreateOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<AppOptimization | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  useEffect(() => {
    supabase
      .from('apps')
      .select('*')
      .order('name')
      .returns<StudioApp[]>()
      .then(({ data, error: appsError }) => {
        if (appsError) return setError(errorMessage(appsError));
        setApps(data ?? []);
        setAppId((current) => current || data?.[0]?.id || '');
      });
  }, []);

  const loadItems = useCallback(async (id: string) => {
    setItems(null);
    const { data, error: loadError } = await supabase
      .from('app_optimizations')
      .select('*')
      .eq('app_id', id)
      .order('created_at')
      .returns<AppOptimization[]>();
    if (loadError) return setError(errorMessage(loadError));
    setError(null);
    setItems(data ?? []);
  }, []);

  useEffect(() => {
    if (appId) loadItems(appId);
  }, [appId, loadItems]);

  const toggle = async (item: AppOptimization) => {
    const { error: toggleError } = await supabase.from('app_optimizations').update({ enabled: !item.enabled }).eq('id', item.id);
    if (toggleError) return setError(errorMessage(toggleError));
    loadItems(appId);
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    setDeleteError(null);
    const { error: removeError } = await supabase.from('app_optimizations').delete().eq('id', deleteTarget.id);
    setDeleting(false);
    if (removeError) return setDeleteError(errorMessage(removeError));
    setDeleteTarget(null);
    loadItems(appId);
  };

  const enabledCount = items?.filter((item) => item.enabled).length ?? 0;

  return (
    <div className="animate-fade-up space-y-8">
      <PageHeader
        title="Otimizações"
        description="Ative ou desative otimizações de desempenho e recursos de cada aplicativo do catálogo."
        actions={
          apps && apps.length > 0 ? (
            <Button icon={Plus} onClick={() => setCreateOpen(true)}>
              Nova otimização
            </Button>
          ) : null
        }
      />

      {error ? <Alert>{error}</Alert> : null}

      {apps === null ? (
        <Spinner label="Carregando aplicativos" />
      ) : apps.length === 0 ? (
        <div className="surface">
          <EmptyState icon={SlidersHorizontal} title="Nenhum aplicativo cadastrado" description="Cadastre um aplicativo no catálogo para configurar suas otimizações." action={<a href="#/apps" className="text-sm text-crimson-300 hover:text-crimson-200">Ir para aplicativos</a>} />
        </div>
      ) : (
        <div className="space-y-5">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div className="sm:w-72">
              <Field label="Aplicativo">
                <SelectInput value={appId} onChange={(event) => setAppId(event.target.value)}>
                  {apps.map((app) => (
                    <option key={app.id} value={app.id}>
                      {app.name}
                    </option>
                  ))}
                </SelectInput>
              </Field>
            </div>
            {items ? <p className="text-sm text-graphite-300">{enabledCount} de {items.length} ativas</p> : null}
          </div>

          {items === null ? (
            <Spinner label="Carregando otimizações" />
          ) : items.length === 0 ? (
            <div className="surface">
              <EmptyState icon={SlidersHorizontal} title="Nenhuma otimização" description="Crie a primeira otimização deste aplicativo para começar a controlar seu comportamento." />
            </div>
          ) : (
            <ul className="surface divide-y divide-graphite-700 overflow-hidden">
              {items.map((item) => (
                <li key={item.id} className="flex items-center justify-between gap-4 px-6 py-5">
                  <div className="min-w-0 space-y-1">
                    <p className="font-medium text-graphite-50">{item.name}</p>
                    {item.description ? <p className="text-sm text-graphite-400">{item.description}</p> : null}
                    <p className="text-xs text-graphite-500">Recurso: {item.feature_code}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      role="switch"
                      aria-checked={item.enabled}
                      aria-label={`${item.enabled ? 'Desativar' : 'Ativar'} ${item.name}`}
                      onClick={() => toggle(item)}
                      className={`relative h-6 w-11 shrink-0 rounded-full transition-colors duration-200 ${item.enabled ? 'bg-crimson-700' : 'bg-graphite-600'}`}
                    >
                      <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform duration-200 ${item.enabled ? 'translate-x-5' : 'translate-x-0.5'}`} />
                    </button>
                    <IconButton icon={Trash2} label="Excluir otimização" tone="danger" onClick={() => { setDeleteError(null); setDeleteTarget(item); }} />
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}

      <OptimizationFormModal open={createOpen} appId={appId} onClose={() => setCreateOpen(false)} onSaved={() => loadItems(appId)} />

      <ConfirmModal
        open={deleteTarget !== null}
        title="Excluir otimização"
        message={`A otimização "${deleteTarget?.name ?? ''}" será removida deste aplicativo.`}
        confirmLabel="Excluir"
        busy={deleting}
        error={deleteError}
        onConfirm={handleDelete}
        onClose={() => setDeleteTarget(null)}
      />
    </div>
  );
}

function OptimizationFormModal({ open, appId, onClose, onSaved }: { open: boolean; appId: string; onClose: () => void; onSaved: () => void }) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [featureCode, setFeatureCode] = useState('optimizer.basic');
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) {
      setName('');
      setDescription('');
      setFeatureCode('optimizer.basic');
      setError(null);
    }
  }, [open]);

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!name.trim()) return setError('Informe o nome da otimização.');
    if (!/^[a-z][a-z0-9_.-]{1,79}$/.test(featureCode.trim().toLowerCase())) return setError('Informe um código de recurso válido.');
    setError(null);
    setSaving(true);
    const { error: insertError } = await supabase
      .from('app_optimizations')
      .insert({ app_id: appId, name: name.trim(), description: description.trim() || null, feature_code: featureCode.trim().toLowerCase(), enabled: false });
    setSaving(false);
    if (insertError) return setError(errorMessage(insertError));
    onSaved();
    onClose();
  };

  return (
    <Modal
      open={open}
      title="Nova otimização"
      description="Novas otimizações começam desativadas."
      onClose={onClose}
      footer={
        <>
          <Button variant="secondary" onClick={onClose} disabled={saving}>
            Cancelar
          </Button>
          <Button type="submit" form="optimization-form" loading={saving}>
            Criar otimização
          </Button>
        </>
      }
    >
      <form id="optimization-form" onSubmit={handleSubmit} className="space-y-5" noValidate>
        <Field label="Nome">
          <TextInput value={name} onChange={(event) => setName(event.target.value)} maxLength={120} required />
        </Field>
        <Field label="Descrição">
          <TextInput value={description} onChange={(event) => setDescription(event.target.value)} maxLength={300} />
        </Field>
        <Field label="Código do recurso exigido" hint="Precisa estar liberado no plano do cliente.">
          <TextInput value={featureCode} onChange={(event) => setFeatureCode(event.target.value)} maxLength={80} />
        </Field>
        {error ? <Alert>{error}</Alert> : null}
      </form>
    </Modal>
  );
}
