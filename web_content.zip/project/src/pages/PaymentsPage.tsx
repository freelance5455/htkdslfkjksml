import { useCallback, useEffect, useState } from 'react';
import { CreditCard, RefreshCw } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { errorMessage } from '@/lib/errors';
import { Alert, Badge, Button, PageHeader, Spinner } from '@/components/ui';

interface PaymentOrder {
  id: string;
  amount_cents: number;
  currency: string;
  status: 'pending' | 'paid' | 'cancelled' | 'expired' | 'refunded' | 'failed';
  created_at: string;
  paid_at: string | null;
  plan: { name: string } | null;
  client: { name: string; email: string | null } | null;
}
const statusLabel: Record<PaymentOrder['status'], string> = { pending: 'Pendente', paid: 'Pago', cancelled: 'Cancelado', expired: 'Expirado', refunded: 'Estornado', failed: 'Falhou' };
const tone: Record<PaymentOrder['status'], 'success' | 'warning' | 'danger' | 'neutral'> = { pending: 'warning', paid: 'success', cancelled: 'neutral', expired: 'neutral', refunded: 'danger', failed: 'danger' };

export function PaymentsPage() {
  const [orders, setOrders] = useState<PaymentOrder[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const load = useCallback(async () => {
    setRefreshing(true);
    const { data, error: queryError } = await supabase.from('payment_orders').select('id,amount_cents,currency,status,created_at,paid_at,plan:plans(name),client:clients(name,email)').order('created_at', { ascending: false }).limit(100).returns<PaymentOrder[]>();
    if (queryError) setError(errorMessage(queryError)); else { setError(null); setOrders(data ?? []); }
    setRefreshing(false);
  }, []);
  useEffect(() => { void load(); }, [load]);
  return <div className="animate-fade-up space-y-8">
    <PageHeader title="Pagamentos" description="Pedidos PIX e situação confirmada pelo webhook do provedor." actions={<Button icon={RefreshCw} variant="secondary" onClick={() => void load()} loading={refreshing}>Atualizar</Button>} />
    {error ? <Alert>{error}</Alert> : null}
    {orders === null && !error ? <Spinner label="Carregando pedidos" /> : orders?.length ? <div className="surface overflow-hidden"><div className="overflow-x-auto"><table className="w-full min-w-[760px] text-left text-sm"><thead className="border-b border-graphite-700 text-xs uppercase tracking-wide text-graphite-400"><tr><th className="px-5 py-4">Cliente</th><th className="px-5 py-4">Plano</th><th className="px-5 py-4">Valor</th><th className="px-5 py-4">Situação</th><th className="px-5 py-4">Criado em</th></tr></thead><tbody className="divide-y divide-graphite-800">{orders.map(order => <tr key={order.id}><td className="px-5 py-4"><p className="font-medium text-graphite-100">{order.client?.name ?? 'Cliente'}</p><p className="text-xs text-graphite-400">{order.client?.email ?? order.id}</p></td><td className="px-5 py-4 text-graphite-200">{order.plan?.name ?? 'Plano'}</td><td className="px-5 py-4 font-medium text-graphite-100">{(order.amount_cents / 100).toLocaleString('pt-BR', { style: 'currency', currency: order.currency })}</td><td className="px-5 py-4"><Badge tone={tone[order.status]}>{statusLabel[order.status]}</Badge></td><td className="px-5 py-4 text-graphite-300">{new Date(order.created_at).toLocaleString('pt-BR')}</td></tr>)}</tbody></table></div></div> : <div className="surface p-8 text-center"><CreditCard className="mx-auto mb-3 h-8 w-8 text-graphite-400"/><p className="font-medium text-graphite-100">Nenhum pedido encontrado</p><p className="mt-1 text-sm text-graphite-400">Os pedidos aparecerão aqui quando o checkout PIX estiver configurado.</p></div>}
  </div>;
}
