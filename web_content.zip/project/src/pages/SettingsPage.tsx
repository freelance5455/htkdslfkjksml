import { useEffect, useState, type FormEvent } from 'react';
import { Save, ShieldCheck } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { errorMessage } from '@/lib/errors';
import { useAuth } from '@/hooks/useAuth';
import type { StudioSettings } from '@/types/studio';
import { Alert, Button, Field, PageHeader, Spinner, TextInput } from '@/components/ui';

const MIN_PASSWORD_LENGTH = 8;

function StudioSettingsSection() {
  const [settings, setSettings] = useState<StudioSettings | null>(null);
  const [name, setName] = useState('');
  const [validity, setValidity] = useState('');
  const [maxActivations, setMaxActivations] = useState('1');
  const [loadError, setLoadError] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    supabase
      .from('studio_settings')
      .select('*')
      .eq('id', 1)
      .maybeSingle<StudioSettings>()
      .then(({ data, error: loadErr }) => {
        if (loadErr) return setLoadError(errorMessage(loadErr));
        if (!data) return setLoadError('As configurações do estúdio ainda não foram criadas.');
        setSettings(data);
        setName(data.studio_name);
        setValidity(data.default_validity_days ? String(data.default_validity_days) : '');
        setMaxActivations(String(data.default_max_activations));
      });
  }, []);

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const max = Number(maxActivations);
    const validityDays = validity.trim() === '' ? null : Number(validity);
    if (!name.trim()) return setError('Informe o nome do estúdio.');
    if (!Number.isInteger(max) || max < 1 || max > 100) return setError('O limite padrão de instalações deve ser entre 1 e 100.');
    if (validityDays !== null && (!Number.isInteger(validityDays) || validityDays < 1 || validityDays > 3650)) {
      return setError('A validade padrão deve ser entre 1 e 3650 dias, ou fica em branco.');
    }

    setError(null);
    setSaved(false);
    setSaving(true);
    const { error: saveError } = await supabase
      .from('studio_settings')
      .update({
        studio_name: name.trim(),
        default_validity_days: validityDays,
        default_max_activations: max,
        updated_at: new Date().toISOString(),
      })
      .eq('id', 1);
    setSaving(false);
    if (saveError) return setError(errorMessage(saveError));
    setSaved(true);
  };

  if (loadError) return <Alert>{loadError}</Alert>;
  if (!settings) return <Spinner label="Carregando configurações" />;

  return (
    <form onSubmit={handleSubmit} className="surface space-y-6 p-6" noValidate>
      <div className="space-y-1">
        <h2 className="font-display text-base font-semibold text-graphite-50">Estúdio</h2>
        <p className="text-sm text-graphite-300">Valores padrão usados ao gerar novas KEYs.</p>
      </div>
      <div className="grid gap-5 sm:grid-cols-2">
        <div className="sm:col-span-2">
          <Field label="Nome do estúdio">
            <TextInput value={name} onChange={(event) => { setSaved(false); setName(event.target.value); }} maxLength={80} />
          </Field>
        </div>
        <Field label="Validade padrão (dias)" hint="Vazio para sem vencimento.">
          <TextInput type="number" inputMode="numeric" min={1} max={3650} value={validity} onChange={(event) => { setSaved(false); setValidity(event.target.value); }} />
        </Field>
        <Field label="Instalações padrão por KEY">
          <TextInput type="number" inputMode="numeric" min={1} max={100} value={maxActivations} onChange={(event) => { setSaved(false); setMaxActivations(event.target.value); }} />
        </Field>
      </div>
      {error ? <Alert>{error}</Alert> : null}
      <div className="flex items-center justify-end gap-4">
        {saved ? <p className="text-sm text-success-400">Configurações salvas.</p> : null}
        <Button type="submit" icon={Save} loading={saving}>
          Salvar configurações
        </Button>
      </div>
    </form>
  );
}

function AccountSection() {
  const { session } = useAuth();
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  const [saving, setSaving] = useState(false);

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (password.length < MIN_PASSWORD_LENGTH) return setError(`A nova senha deve ter pelo menos ${MIN_PASSWORD_LENGTH} caracteres.`);
    if (password !== confirmPassword) return setError('As senhas não coincidem.');

    setError(null);
    setSaved(false);
    setSaving(true);
    const { error: updateError } = await supabase.auth.updateUser({ password });
    setSaving(false);
    if (updateError) return setError(errorMessage(updateError));
    setPassword('');
    setConfirmPassword('');
    setSaved(true);
  };

  return (
    <div className="surface space-y-6 p-6">
      <div className="space-y-1">
        <h2 className="font-display text-base font-semibold text-graphite-50">Conta administrativa</h2>
        <p className="text-sm text-graphite-300">Conectado como {session?.user.email}</p>
      </div>
      <form onSubmit={handleSubmit} className="grid gap-5 sm:grid-cols-2" noValidate>
        <Field label="Nova senha">
          <TextInput type="password" autoComplete="new-password" value={password} onChange={(event) => { setSaved(false); setPassword(event.target.value); }} />
        </Field>
        <Field label="Confirmar nova senha">
          <TextInput type="password" autoComplete="new-password" value={confirmPassword} onChange={(event) => { setSaved(false); setConfirmPassword(event.target.value); }} />
        </Field>
        {error ? (
          <div className="sm:col-span-2">
            <Alert>{error}</Alert>
          </div>
        ) : null}
        <div className="flex items-center justify-end gap-4 sm:col-span-2">
          {saved ? <p className="text-sm text-success-400">Senha alterada.</p> : null}
          <Button type="submit" variant="secondary" loading={saving} disabled={!password}>
            Alterar senha
          </Button>
        </div>
      </form>
    </div>
  );
}

export function SettingsPage() {
  return (
    <div className="animate-fade-up space-y-8">
      <PageHeader title="Configurações" description="Valores padrão do estúdio e segurança da sua conta administrativa." />
      <div className="grid gap-8 xl:grid-cols-2">
        <StudioSettingsSection />
        <div className="space-y-8">
          <AccountSection />
          <div className="surface flex gap-4 p-6">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-crimson-700/20 ring-1 ring-inset ring-crimson-700/40">
              <ShieldCheck className="h-5 w-5 text-crimson-300" aria-hidden="true" />
            </div>
            <div className="space-y-1">
              <p className="text-sm font-medium text-graphite-100">Acesso protegido</p>
              <p className="text-sm text-graphite-300">
                Chaves são guardadas apenas como resumo seguro (hash SHA-256). A chave completa é exibida uma única vez na criação.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
