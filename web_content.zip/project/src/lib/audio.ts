let audioCtx: AudioContext | null = null;
let muted = false;

export function setMuted(value: boolean) {
  muted = value;
}

function getCtx(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  if (!audioCtx) {
    const Ctor = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!Ctor) return null;
    audioCtx = new Ctor();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume().catch(() => {});
  }
  return audioCtx;
}

type WaveType = OscillatorType;

interface ChimeOptions {
  frequency?: number;
  duration?: number;
  type?: WaveType;
  volume?: number;
  attack?: number;
  release?: number;
}

function playChime({
  frequency = 523.25,
  duration = 0.4,
  type = 'sine',
  volume = 0.15,
  attack = 0.02,
  release = 0.3,
}: ChimeOptions = {}) {
  if (muted) return;
  const ctx = getCtx();
  if (!ctx) return;

  const now = ctx.currentTime;
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();

  osc.type = type;
  osc.frequency.setValueAtTime(frequency, now);

  gain.gain.setValueAtTime(0, now);
  gain.gain.linearRampToValueAtTime(volume, now + attack);
  gain.gain.linearRampToValueAtTime(volume, now + duration - release);
  gain.gain.linearRampToValueAtTime(0, now + duration);

  osc.connect(gain);
  gain.connect(ctx.destination);

  osc.start(now);
  osc.stop(now + duration);
}

export const sounds = {
  unlock: () => {
    playChime({ frequency: 523.25, duration: 0.3, type: 'sine' });
    setTimeout(() => playChime({ frequency: 659.25, duration: 0.3, type: 'sine' }), 120);
    setTimeout(() => playChime({ frequency: 783.99, duration: 0.5, type: 'sine' }), 240);
  },
  chime: () => playChime({ frequency: 880, duration: 0.25, type: 'sine', volume: 0.1 }),
  softChime: () => playChime({ frequency: 660, duration: 0.2, type: 'triangle', volume: 0.08 }),
  reveal: () => {
    playChime({ frequency: 440, duration: 0.2, type: 'sine', volume: 0.1 });
    setTimeout(() => playChime({ frequency: 660, duration: 0.3, type: 'sine', volume: 0.1 }), 100);
  },
  flip: () => playChime({ frequency: 550, duration: 0.15, type: 'triangle', volume: 0.08 }),
  scratch: () => playChime({ frequency: 300, duration: 0.08, type: 'sawtooth', volume: 0.04 }),
  jar: () => {
    playChime({ frequency: 700, duration: 0.15, type: 'sine', volume: 0.08 });
    setTimeout(() => playChime({ frequency: 900, duration: 0.2, type: 'sine', volume: 0.1 }), 80);
  },
  envelope: () => {
    playChime({ frequency: 400, duration: 0.25, type: 'sine', volume: 0.1 });
    setTimeout(() => playChime({ frequency: 500, duration: 0.25, type: 'sine', volume: 0.1 }), 150);
    setTimeout(() => playChime({ frequency: 600, duration: 0.4, type: 'sine', volume: 0.12 }), 300);
  },
  tap: () => playChime({ frequency: 1000, duration: 0.05, type: 'sine', volume: 0.05 }),
};

export function initAudio() {
  getCtx();
}
