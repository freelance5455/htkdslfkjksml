const KEY_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const KEY_SEGMENTS = 8;
const KEY_SEGMENT_LENGTH = 4;

export interface GeneratedLicenseKey {
  plainKey: string;
  keyHash: string;
  keyPrefix: string;
}

export type LicenseState = 'active' | 'revoked' | 'expired';

export function normalizeLicenseKey(input: string): string {
  return input.replace(/\s+/g, '').toUpperCase();
}

export async function hashLicenseKey(plainKey: string): Promise<string> {
  const data = new TextEncoder().encode(normalizeLicenseKey(plainKey));
  const digest = await crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, '0')).join('');
}

function randomSegment(): string {
  const bytes = new Uint8Array(KEY_SEGMENT_LENGTH);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (byte) => KEY_ALPHABET[byte % KEY_ALPHABET.length]).join('');
}

export async function generateLicenseKey(): Promise<GeneratedLicenseKey> {
  const segments = Array.from({ length: KEY_SEGMENTS }, randomSegment);
  const plainKey = ['VT', ...segments].join('-');
  return {
    plainKey,
    keyHash: await hashLicenseKey(plainKey),
    keyPrefix: `VT-${segments[0]}`,
  };
}

export function getLicenseState(license: { status: string; expires_at: string | null }): LicenseState {
  if (license.status === 'revoked') return 'revoked';
  if (license.expires_at && new Date(license.expires_at).getTime() < Date.now()) return 'expired';
  return 'active';
}

export function maskedLicenseKey(keyPrefix: string): string {
  return `${keyPrefix}${"-••••".repeat(7)}`;
}
