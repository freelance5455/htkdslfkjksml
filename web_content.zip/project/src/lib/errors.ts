const DATABASE_MESSAGES: Record<string, string> = {
  '23503': 'Este registro está em uso e não pode ser removido.',
  '23505': 'Já existe um registro com este valor.',
  '42501': 'Você não tem permissão para realizar esta operação.',
};

export function errorMessage(error: unknown): string {
  if (error && typeof error === 'object' && 'code' in error) {
    const code = String((error as { code: unknown }).code);
    if (DATABASE_MESSAGES[code]) return DATABASE_MESSAGES[code];
  }
  if (error instanceof Error && error.message) return error.message;
  return 'Não foi possível concluir a operação. Tente novamente.';
}
