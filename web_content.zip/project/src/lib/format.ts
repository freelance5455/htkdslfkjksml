// Pakistani Rupee formatting using the en-PK locale where available,
// falling back to a manual grouping for older runtimes.
const PKR_FORMATTER =
  typeof Intl !== 'undefined'
    ? new Intl.NumberFormat('en-PK', {
        maximumFractionDigits: 0,
      })
    : null;

export function formatPKR(amount: number): string {
  const rounded = Math.round(amount || 0);
  const grouped = PKR_FORMATTER ? PKR_FORMATTER.format(rounded) : manualGroup(rounded);
  return `Rs. ${grouped}`;
}

export function formatNumber(n: number): string {
  const rounded = Math.round(n || 0);
  return PKR_FORMATTER ? PKR_FORMATTER.format(rounded) : manualGroup(rounded);
}

function manualGroup(n: number): string {
  const neg = n < 0;
  const digits = Math.abs(n).toString();
  let out = '';
  for (let i = 0; i < digits.length; i++) {
    if (i > 0 && (digits.length - i) % 3 === 0) out += ',';
    out += digits[i];
  }
  return (neg ? '-' : '') + out;
}

// "Sat, 17 Oct" style short date
export function formatDate(iso: string): string {
  const d = new Date(iso + 'T00:00:00');
  if (isNaN(d.getTime())) return iso;
  return d.toLocaleDateString('en-PK', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
  });
}

export function formatMonth(iso: string): string {
  const d = new Date(iso + 'T00:00:00');
  if (isNaN(d.getTime())) return iso;
  return d.toLocaleDateString('en-PK', { month: 'long', year: 'numeric' });
}

export function todayISO(): string {
  return new Date().toISOString().slice(0, 10);
}

export function isSameDay(iso: string, ref: string): boolean {
  return iso === ref;
}

export function isSameMonth(iso: string, ref: string): boolean {
  return iso.slice(0, 7) === ref.slice(0, 7);
}

export function uid(): string {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}
