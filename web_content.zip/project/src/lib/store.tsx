import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import type { AppData, Customer, CreditEntry, Product, Transaction } from '@/types';
import { uid } from './format';
import { buildSampleData } from './sampleData';

const STORAGE_KEY = 'dukaan-saathi-data-v1';

function loadData(): AppData {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as AppData;
      if (parsed && Array.isArray(parsed.transactions)) return parsed;
    }
  } catch {
    // ignore corrupted data
  }
  return buildSampleData();
}

function saveData(data: AppData) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch {
    // storage full or unavailable — ignore for this prototype
  }
}

export interface NewTransactionInput {
  type: 'sale' | 'expense';
  amount: number;
  date: string;
  note: string;
}

export interface NewCreditInput {
  customerId: string;
  amount: number; // positive = udhaar, negative = payment
  date: string;
  note: string;
}

export interface NewProductInput {
  name: string;
  purchasePrice: number;
  sellingPrice: number;
  quantity: number;
  lowStockThreshold: number;
}

interface StoreValue extends AppData {
  isDemo: boolean;
  resetToSample: () => void;
  clearAll: () => void;
  // transactions
  addTransaction: (input: NewTransactionInput) => void;
  updateTransaction: (id: string, input: NewTransactionInput) => void;
  deleteTransaction: (id: string) => void;
  // customers
  addCustomer: (name: string, phone?: string, note?: string) => string;
  updateCustomer: (id: string, name: string, phone?: string, note?: string) => void;
  deleteCustomer: (id: string) => void;
  // credits
  addCredit: (input: NewCreditInput) => void;
  deleteCredit: (id: string) => void;
  // products
  addProduct: (input: NewProductInput) => void;
  updateProduct: (id: string, input: NewProductInput) => void;
  deleteProduct: (id: string) => void;
  adjustStock: (id: string, delta: number) => void;
}

const StoreContext = createContext<StoreValue | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<AppData>(() => loadData());

  useEffect(() => {
    saveData(data);
  }, [data]);

  const addTransaction = useCallback((input: NewTransactionInput) => {
    const t: Transaction = { id: uid(), ...input, createdAt: Date.now() };
    setData((d) => ({ ...d, transactions: [t, ...d.transactions] }));
  }, []);

  const updateTransaction = useCallback((id: string, input: NewTransactionInput) => {
    setData((d) => ({
      ...d,
      transactions: d.transactions.map((t) =>
        t.id === id ? { ...t, ...input } : t
      ),
    }));
  }, []);

  const deleteTransaction = useCallback((id: string) => {
    setData((d) => ({ ...d, transactions: d.transactions.filter((t) => t.id !== id) }));
  }, []);

  const addCustomer = useCallback((name: string, phone?: string, note?: string): string => {
    const id = uid();
    const c: Customer = { id, name: name.trim(), phone: phone?.trim() || undefined, note: note?.trim() || undefined, createdAt: Date.now() };
    setData((d) => ({ ...d, customers: [c, ...d.customers] }));
    return id;
  }, []);

  const updateCustomer = useCallback((id: string, name: string, phone?: string, note?: string) => {
    setData((d) => ({
      ...d,
      customers: d.customers.map((c) =>
        c.id === id ? { ...c, name: name.trim(), phone: phone?.trim() || undefined, note: note?.trim() || undefined } : c
      ),
    }));
  }, []);

  const deleteCustomer = useCallback((id: string) => {
    setData((d) => ({
      ...d,
      customers: d.customers.filter((c) => c.id !== id),
      credits: d.credits.filter((cr) => cr.customerId !== id),
    }));
  }, []);

  const addCredit = useCallback((input: NewCreditInput) => {
    const c: CreditEntry = { id: uid(), ...input, createdAt: Date.now() };
    setData((d) => ({ ...d, credits: [c, ...d.credits] }));
  }, []);

  const deleteCredit = useCallback((id: string) => {
    setData((d) => ({ ...d, credits: d.credits.filter((c) => c.id !== id) }));
  }, []);

  const addProduct = useCallback((input: NewProductInput) => {
    const p: Product = { id: uid(), ...input, createdAt: Date.now() };
    setData((d) => ({ ...d, products: [p, ...d.products] }));
  }, []);

  const updateProduct = useCallback((id: string, input: NewProductInput) => {
    setData((d) => ({
      ...d,
      products: d.products.map((p) => (p.id === id ? { ...p, ...input } : p)),
    }));
  }, []);

  const deleteProduct = useCallback((id: string) => {
    setData((d) => ({ ...d, products: d.products.filter((p) => p.id !== id) }));
  }, []);

  const adjustStock = useCallback((id: string, delta: number) => {
    setData((d) => ({
      ...d,
      products: d.products.map((p) =>
        p.id === id ? { ...p, quantity: Math.max(0, p.quantity + delta) } : p
      ),
    }));
  }, []);

  const resetToSample = useCallback(() => setData(buildSampleData()), []);
  const clearAll = useCallback(
    () => setData({ customers: [], credits: [], transactions: [], products: [], seeded: true }),
    []
  );

  const value = useMemo<StoreValue>(
    () => ({
      ...data,
      isDemo: !localStorage.getItem(STORAGE_KEY),
      resetToSample,
      clearAll,
      addTransaction,
      updateTransaction,
      deleteTransaction,
      addCustomer,
      updateCustomer,
      deleteCustomer,
      addCredit,
      deleteCredit,
      addProduct,
      updateProduct,
      deleteProduct,
      adjustStock,
    }),
    [data, resetToSample, clearAll, addTransaction, updateTransaction, deleteTransaction, addCustomer, updateCustomer, deleteCustomer, addCredit, deleteCredit, addProduct, updateProduct, deleteProduct, adjustStock]
  );

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore(): StoreValue {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error('useStore must be used within StoreProvider');
  return ctx;
}

// Derived helpers
export function customerBalance(credits: CreditEntry[], customerId: string): number {
  return credits.filter((c) => c.customerId === customerId).reduce((s, c) => s + c.amount, 0);
}

export function totalOutstanding(credits: CreditEntry[]): number {
  const byCustomer = new Map<string, number>();
  for (const c of credits) {
    byCustomer.set(c.customerId, (byCustomer.get(c.customerId) ?? 0) + c.amount);
  }
  let total = 0;
  for (const v of byCustomer.values()) if (v > 0) total += v;
  return total;
}
