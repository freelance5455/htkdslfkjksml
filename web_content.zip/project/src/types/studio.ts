export type ClientStatus = 'active' | 'inactive';
export type AppStatus = 'draft' | 'published' | 'archived';
export type LicenseStatus = 'active' | 'revoked';

export interface Client {
  id: string;
  name: string;
  email: string | null;
  document: string | null;
  phone: string | null;
  company: string | null;
  notes: string | null;
  status: ClientStatus;
  created_at: string;
}

export interface StudioApp {
  id: string;
  name: string;
  package_name: string;
  version: string;
  description: string | null;
  status: AppStatus;
  created_at: string;
}

export interface AppCustomization {
  app_id: string;
  display_name: string;
  tagline: string | null;
  primary_color: string;
  support_email: string | null;
  welcome_message: string | null;
}

export interface LicenseKeyRow {
  id: string;
  key_prefix: string;
  status: LicenseStatus;
  max_activations: number;
  expires_at: string | null;
  notes: string | null;
  created_at: string;
  revoked_at: string | null;
  app_id: string;
  client_id: string | null;
  app: { name: string } | null;
  client: { name: string } | null;
  activations: { count: number }[];
}

export interface ActivationRow {
  id: string;
  license_key_id: string;
  installation_id: string;
  device_label: string | null;
  activated_at: string;
  last_validated_at: string | null;
}

export interface StudioSettings {
  id: number;
  studio_name: string;
  default_validity_days: number | null;
  default_max_activations: number;
}
