export const APP_NAME = 'Money Making Empire AI Website Builder';
export const APP_SHORT_NAME = 'MME Builder';
export const APP_VERSION = '2.5.0';
export const APP_BUILD_ID = 'PROD-20261007-PARITY';
export const BUILD_TIMESTAMP = '2026-10-07T07:15:00Z';
