import { useEffect, useState, type FormEvent } from 'react';
import { supabase } from '@/lib/supabase';
import { errorMessage } from '@/lib/errors';
import type { Client, ClientStatus } from '@/types/studio';
import { Alert, Button, Field, Modal, SelectInput, TextArea, TextInput } from '@/components/ui';

interface ClientFormModalProps {
  open: boolean;
  client: Client | null;
  onClose: () => void;
  onSaved: () => void;
}

interface ClientFormState {
  name: string;
  email: string;
  document: string;
  phone: string;
  company: string;
  notes: string;
  status: ClientStatus;
}

const EMPTY_CLIENT_FORM: ClientFormState = {
  name: '',
  email: '',
  document: '',
  phone: '',
  company: '',
  notes: '',
  status: 'active',
};

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function toFormState(client: Client | null): ClientFormState {
  if (!client) return EMPTY_CLIENT_FORM;
  return {
    name: client.name,
    email: client.email ?? '',
    document: client.document ?? '',
    phone: client.phone ?? '',
    company: client.company ?? '',
    notes: client.notes ?? '',
    status: client.status,
  };
}

export function ClientFormModal({ open, client, onClose, onSaved }: ClientFormModalProps) {
  const [form, setForm] = useState<ClientFormState>(() => toFormState(client));
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!open) return;
    setForm(toFormState(client));
    setError(null);
  }, [open, client]);

  const update = (field: keyof ClientFormState, value: string) => {
    setForm((current) => ({ ...current, [field]: value }));
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError(null);

    const name = form.name.trim();
    const email = form.email.trim();
    if (!name) {
      setError('Informe o nome do cliente.');
      return;
    }
    if (email && !EMAIL_PATTERN.test(email)) {
      setError('Informe um e-mail válido.');
      return;
    }

    const payload = {
      name,
      email: email || null,
      document: form.document.trim() || null,
      phone: form.phone.trim() || null,
      company: form.company.trim() || null,
      notes: form.notes.trim() || null,
      status: form.status,
      updated_at: new Date().toISOString(),
    };

    setSaving(true);
    const { error: saveError } = client
      ? await supabase.from('clients').update(payload).eq('id', client.id)
      : await supabase.from('clients').insert(payload);
    setSaving(false);

    if (saveError) {
      setError(errorMessage(saveError));
      return;
    }
    onSaved();
    onClose();
  };

  return (
    <Modal
      open={open}
      title={client ? 'Editar cliente' : 'Novo cliente'}
      description="Dados usados para vincular licenças e identificar quem recebeu cada KEY."
      onClose={onClose}
      size="lg"
      footer={
        <>
          <Button variant="secondary" onClick={onClose} disabled={saving}>
            Cancelar
          </Button>
          <Button type="submit" form="client-form" loading={saving}>
            {client ? 'Salvar alterações' : 'Cadastrar cliente'}
          </Button>
        </>
      }
    >
      <form id="client-form" onSubmit={handleSubmit} className="grid gap-5 sm:grid-cols-2" noValidate>
        <div className="sm:col-span-2">
          <Field label="Nome">
            <TextInput value={form.name} onChange={(event) => update('name', event.target.value)} maxLength={120} required />
          </Field>
        </div>
        <Field label="E-mail">
          <TextInput type="email" value={form.email} onChange={(event) => update('email', event.target.value)} maxLength={160} />
        </Field>
        <Field label="Telefone">
          <TextInput type="tel" value={form.phone} onChange={(event) => update('phone', event.target.value)} maxLength={32} />
        </Field>
        <Field label="Empresa">
          <TextInput value={form.company} onChange={(event) => update('company', event.target.value)} maxLength={120} />
        </Field>
        <Field label="CPF ou CNPJ">
          <TextInput value={form.document} onChange={(event) => update('document', event.target.value)} maxLength={32} />
        </Field>
        <div className="sm:col-span-2">
          <Field label="Situação">
            <SelectInput value={form.status} onChange={(event) => update('status', event.target.value)}>
              <option value="active">Ativo</option>
              <option value="inactive">Inativo</option>
            </SelectInput>
          </Field>
        </div>
        <div className="sm:col-span-2">
          <Field label="Observações">
            <TextArea value={form.notes} onChange={(event) => update('notes', event.target.value)} maxLength={1000} />
          </Field>
        </div>
        {error ? (
          <div className="sm:col-span-2">
            <Alert>{error}</Alert>
          </div>
        ) : null}
      </form>
    </Modal>
  );
}
