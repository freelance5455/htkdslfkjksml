import type { ButtonHTMLAttributes, InputHTMLAttributes, ReactNode, SelectHTMLAttributes, TextareaHTMLAttributes } from 'react';
import { useEffect, useId } from 'react';
import { AlertTriangle, Loader2, X, type LucideIcon } from 'lucide-react';

type ButtonVariant = 'primary' | 'secondary' | 'ghost' | 'danger';

const BUTTON_VARIANTS: Record<ButtonVariant, string> = {
  primary:
    'bg-crimson-700 text-white shadow-sm shadow-crimson-900/40 hover:bg-crimson-600 active:bg-crimson-800',
  secondary:
    'border border-graphite-600 bg-graphite-700 text-graphite-50 hover:border-graphite-500 hover:bg-graphite-600',
  ghost: 'text-graphite-300 hover:bg-graphite-700 hover:text-graphite-50',
  danger: 'bg-danger-500 text-white hover:bg-danger-400',
};

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  loading?: boolean;
  icon?: LucideIcon;
}

export function Button({ variant = 'primary', loading = false, icon: Icon, className = '', children, disabled, ...rest }: ButtonProps) {
  return (
    <button
      {...rest}
      disabled={disabled || loading}
      className={`inline-flex items-center justify-center gap-2 rounded-lg px-4 py-2.5 text-sm font-medium transition-all duration-200 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-50 ${BUTTON_VARIANTS[variant]} ${className}`}
    >
      {loading ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> : Icon ? <Icon className="h-4 w-4" aria-hidden="true" /> : null}
      {children}
    </button>
  );
}

export function IconButton({
  icon: Icon,
  label,
  tone = 'default',
  onClick,
  disabled,
}: {
  icon: LucideIcon;
  label: string;
  tone?: 'default' | 'danger';
  onClick: () => void;
  disabled?: boolean;
}) {
  const toneClass = tone === 'danger' ? 'hover:text-danger-400 hover:bg-danger-900/40' : 'hover:text-graphite-50 hover:bg-graphite-700';
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      onClick={onClick}
      disabled={disabled}
      className={`rounded-lg p-2 text-graphite-300 transition-colors duration-200 disabled:opacity-40 ${toneClass}`}
    >
      <Icon className="h-4 w-4" aria-hidden="true" />
    </button>
  );
}

export function Field({ label, error, hint, children }: { label: string; error?: string | null; hint?: string; children: ReactNode }) {
  return (
    <label className="block space-y-1.5">
      <span className="text-sm font-medium text-graphite-100">{label}</span>
      {children}
      {error ? (
        <span className="block text-xs text-danger-400">{error}</span>
      ) : hint ? (
        <span className="block text-xs text-graphite-400">{hint}</span>
      ) : null}
    </label>
  );
}

export function TextInput(props: InputHTMLAttributes<HTMLInputElement>) {
  return <input {...props} className={`field-input ${props.className ?? ''}`} />;
}

export function TextArea(props: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea {...props} className={`field-input min-h-[88px] resize-y ${props.className ?? ''}`} />;
}

export function SelectInput(props: SelectHTMLAttributes<HTMLSelectElement>) {
  return <select {...props} className={`field-input appearance-none ${props.className ?? ''}`} />;
}

type BadgeTone = 'success' | 'warning' | 'danger' | 'crimson' | 'neutral';

const BADGE_TONES: Record<BadgeTone, string> = {
  success: 'bg-success-900 text-success-400 ring-success-500/30',
  warning: 'bg-warning-900 text-warning-400 ring-warning-500/30',
  danger: 'bg-danger-900 text-danger-400 ring-danger-500/30',
  crimson: 'bg-crimson-900 text-crimson-200 ring-crimson-600/40',
  neutral: 'bg-graphite-700 text-graphite-200 ring-graphite-500/40',
};

export function Badge({ tone = 'neutral', children }: { tone?: BadgeTone; children: ReactNode }) {
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium ring-1 ring-inset ${BADGE_TONES[tone]}`}>
      {children}
    </span>
  );
}

export function Alert({ tone = 'danger', children }: { tone?: 'danger' | 'warning'; children: ReactNode }) {
  const toneClass = tone === 'danger' ? 'border-danger-500/40 bg-danger-900/60 text-danger-400' : 'border-warning-500/40 bg-warning-900/60 text-warning-400';
  return (
    <div role="alert" className={`flex items-start gap-3 rounded-xl border px-4 py-3 text-sm ${toneClass}`}>
      <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
      <div className="text-graphite-100">{children}</div>
    </div>
  );
}

export function Spinner({ label = 'Carregando' }: { label?: string }) {
  return (
    <div role="status" className="flex items-center justify-center gap-3 py-16 text-sm text-graphite-300">
      <Loader2 className="h-5 w-5 animate-spin text-crimson-400" aria-hidden="true" />
      {label}
    </div>
  );
}

export function EmptyState({ icon: Icon, title, description, action }: { icon: LucideIcon; title: string; description: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 px-6 py-16 text-center">
      <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-graphite-700 ring-1 ring-graphite-600">
        <Icon className="h-5 w-5 text-crimson-300" aria-hidden="true" />
      </div>
      <h3 className="font-display text-base text-graphite-50">{title}</h3>
      <p className="max-w-sm text-sm text-graphite-300">{description}</p>
      {action ? <div className="mt-2">{action}</div> : null}
    </div>
  );
}

export function PageHeader({ title, description, actions }: { title: string; description: string; actions?: ReactNode }) {
  return (
    <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
      <div className="space-y-1">
        <h1 className="font-display text-2xl font-semibold text-graphite-50 sm:text-3xl">{title}</h1>
        <p className="max-w-2xl text-sm text-graphite-300">{description}</p>
      </div>
      {actions ? <div className="flex flex-wrap items-center gap-3">{actions}</div> : null}
    </div>
  );
}

interface ModalProps {
  open: boolean;
  title: string;
  description?: string;
  onClose: () => void;
  children: ReactNode;
  footer?: ReactNode;
  size?: 'md' | 'lg';
}

export function Modal({ open, title, description, onClose, children, footer, size = 'md' }: ModalProps) {
  const titleId = useId();

  useEffect(() => {
    if (!open) return;
    const handleKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', handleKey);
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', handleKey);
      document.body.style.overflow = previousOverflow;
    };
  }, [open, onClose]);

  if (!open) return null;

  const width = size === 'lg' ? 'max-w-2xl' : 'max-w-lg';

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 p-0 backdrop-blur-sm sm:items-center sm:p-6" onMouseDown={onClose}>
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        onMouseDown={(event) => event.stopPropagation()}
        className={`animate-scale-in flex max-h-[92vh] w-full ${width} flex-col rounded-t-2xl border border-graphite-600 bg-graphite-800 shadow-2xl sm:rounded-2xl`}
      >
        <div className="flex items-start justify-between gap-4 border-b border-graphite-700 px-6 py-5">
          <div className="space-y-1">
            <h2 id={titleId} className="font-display text-lg font-semibold text-graphite-50">
              {title}
            </h2>
            {description ? <p className="text-sm text-graphite-300">{description}</p> : null}
          </div>
          <IconButton icon={X} label="Fechar" onClick={onClose} />
        </div>
        <div className="overflow-y-auto px-6 py-5">{children}</div>
        {footer ? <div className="flex flex-col-reverse gap-3 border-t border-graphite-700 px-6 py-4 sm:flex-row sm:justify-end">{footer}</div> : null}
      </div>
    </div>
  );
}

export function ConfirmModal({
  open,
  title,
  message,
  confirmLabel,
  tone = 'danger',
  busy = false,
  error,
  onConfirm,
  onClose,
}: {
  open: boolean;
  title: string;
  message: string;
  confirmLabel: string;
  tone?: 'danger' | 'primary';
  busy?: boolean;
  error?: string | null;
  onConfirm: () => void;
  onClose: () => void;
}) {
  return (
    <Modal
      open={open}
      title={title}
      onClose={onClose}
      footer={
        <>
          <Button variant="secondary" onClick={onClose} disabled={busy}>
            Cancelar
          </Button>
          <Button variant={tone === 'danger' ? 'danger' : 'primary'} onClick={onConfirm} loading={busy}>
            {confirmLabel}
          </Button>
        </>
      }
    >
      <div className="space-y-4">
        <p className="text-sm text-graphite-200">{message}</p>
        {error ? <Alert>{error}</Alert> : null}
      </div>
    </Modal>
  );
}
