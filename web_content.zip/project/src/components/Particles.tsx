import { useMemo } from 'react';

interface ParticlesProps {
  count?: number;
}

export function Particles({ count = 25 }: ParticlesProps) {
  const particles = useMemo(
    () =>
      Array.from({ length: count }, () => {
        const size = 2 + Math.random() * 5;
        const isStar = Math.random() > 0.5;
        return {
          id: Math.random(),
          left: `${Math.random() * 100}%`,
          size: `${size}px`,
          duration: `${8 + Math.random() * 12}s`,
          delay: `${Math.random() * 10}s`,
          color: isStar
            ? 'rgba(232, 180, 184, 0.5)'
            : 'rgba(212, 175, 122, 0.4)',
          isStar,
          animType: Math.random() > 0.5 ? 'float-up' : 'twinkle',
        };
      }),
    [count]
  );

  return (
    <>
      <div className="ambient-bg" />
      {particles.map((p) => (
        <div
          key={p.id}
          className="particle"
          style={{
            left: p.left,
            width: p.size,
            height: p.size,
            background: p.color,
            boxShadow: `0 0 ${p.isStar ? 8 : 4}px ${p.color}`,
            animation: `${p.animType} ${p.duration} ease-in-out ${p.delay} infinite`,
          }}
        />
      ))}
    </>
  );
}
