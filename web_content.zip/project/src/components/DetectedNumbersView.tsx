import React, { useState, useMemo } from "react";
import {
  CheckSquare,
  Square,
  Edit2,
  Trash2,
  Plus,
  ArrowRight,
  RotateCcw,
  Sparkles,
  Eye,
  EyeOff,
  AlertTriangle,
  PlusCircle,
  Save,
  X,
} from "lucide-react";
import { CalculationItem, UnrelatedNumber, AppSettings } from "../types";
import { sanitizeNumber } from "../utils/calculator";

interface DetectedNumbersViewProps {
  items: CalculationItem[];
  unrelatedNumbers?: UnrelatedNumber[];
  imagePreviewUrl?: string;
  notes?: string;
  settings: AppSettings;
  onUpdateItems: (items: CalculationItem[]) => void;
  onCalculateTotal: (selectedItems: CalculationItem[], total: number) => void;
  onRetakePhoto: () => void;
  onAddManualItem: () => void;
}

export const DetectedNumbersView: React.FC<DetectedNumbersViewProps> = ({
  items,
  unrelatedNumbers = [],
  imagePreviewUrl,
  notes,
  settings,
  onUpdateItems,
  onCalculateTotal,
  onRetakePhoto,
}) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editLabel, setEditLabel] = useState<string>("");
  const [editAmount, setEditAmount] = useState<string>("");
  const [showImagePreview, setShowImagePreview] = useState<boolean>(false);
  const [showUnrelated, setShowUnrelated] = useState<boolean>(false);

  // New item manual add inline state
  const [isAddingNew, setIsAddingNew] = useState<boolean>(false);
  const [newLabel, setNewLabel] = useState<string>("");
  const [newAmount, setNewAmount] = useState<string>("");

  // Running sum of all checked items - recalculates automatically
  const activeItems = useMemo(() => items.filter((item) => item.included), [items]);
  const liveTotal = useMemo(() => {
    const sum = activeItems.reduce((acc, curr) => acc + (curr.amount || 0), 0);
    return sanitizeNumber(sum);
  }, [activeItems]);

  // Toggle inclusion
  const handleToggleInclude = (id: string) => {
    onUpdateItems(
      items.map((item) => (item.id === id ? { ...item, included: !item.included } : item))
    );
  };

  // Toggle select all
  const handleSelectAll = (select: boolean) => {
    onUpdateItems(items.map((item) => ({ ...item, included: select })));
  };

  // Delete item
  const handleDeleteItem = (id: string) => {
    onUpdateItems(items.filter((item) => item.id !== id));
  };

  // Start editing
  const handleStartEdit = (item: CalculationItem) => {
    setEditingId(item.id);
    setEditLabel(item.label);
    setEditAmount(String(item.amount));
  };

  // Save edit
  const handleSaveEdit = (id: string) => {
    const parsedAmount = parseFloat(editAmount);
    if (isNaN(parsedAmount)) return;

    onUpdateItems(
      items.map((item) =>
        item.id === id
          ? {
              ...item,
              label: editLabel.trim() || item.label,
              amount: sanitizeNumber(parsedAmount),
            }
          : item
      )
    );
    setEditingId(null);
  };

  // Add new item manually
  const handleAddNewItem = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedAmount = parseFloat(newAmount);
    if (isNaN(parsedAmount)) return;

    const newItem: CalculationItem = {
      id: `manual-${Date.now()}`,
      label: newLabel.trim() || `Item ${items.length + 1}`,
      amount: sanitizeNumber(parsedAmount),
      confidence: "high",
      category: "price",
      included: true,
    };

    onUpdateItems([...items, newItem]);
    setNewLabel("");
    setNewAmount("");
    setIsAddingNew(false);
  };

  // Promote an unrelated number to an item amount (in case user wants to include it)
  const handleIncludeUnrelated = (unrelated: UnrelatedNumber) => {
    const num = parseFloat(String(unrelated.value).replace(/[^0-9.]/g, ""));
    if (isNaN(num)) return;

    const newItem: CalculationItem = {
      id: `unrelated-${Date.now()}`,
      label: unrelated.label || "Manual Added",
      amount: sanitizeNumber(num),
      confidence: "medium",
      category: "price",
      included: true,
    };
    onUpdateItems([...items, newItem]);
  };

  return (
    <div
      id="detected-numbers-screen"
      className="flex flex-col h-full w-full max-w-lg mx-auto p-4 justify-between animate-in fade-in duration-200"
    >
      {/* Top Header Card */}
      <div className="rounded-3xl bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 p-4 sm:p-5 mb-3 shadow-xs">
        <div className="flex items-center justify-between mb-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold tracking-wider uppercase text-emerald-600 dark:text-emerald-400">
                OCR Scanner Result
              </span>
              {notes && (
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-zinc-200 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400">
                  {notes}
                </span>
              )}
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-zinc-900 dark:text-zinc-100 mt-0.5">
              Detected Numbers
            </h2>
          </div>

          {imagePreviewUrl && (
            <button
              onClick={() => setShowImagePreview(!showImagePreview)}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-zinc-200/80 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 text-xs font-semibold hover:bg-zinc-300 dark:hover:bg-zinc-700 transition-all cursor-pointer"
              title="Toggle receipt preview"
            >
              {showImagePreview ? (
                <>
                  <EyeOff className="w-3.5 h-3.5" />
                  <span>Hide Photo</span>
                </>
              ) : (
                <>
                  <Eye className="w-3.5 h-3.5" />
                  <span>View Photo</span>
                </>
              )}
            </button>
          )}
        </div>

        {/* Live Total & Item Count Banner */}
        <div className="flex items-end justify-between pt-2 border-t border-zinc-200 dark:border-zinc-800">
          <div>
            <div className="text-xs text-zinc-500 dark:text-zinc-400 font-medium">
              Total Items: <span className="font-bold text-zinc-800 dark:text-zinc-200">{activeItems.length}</span> / {items.length}
            </div>
            <div className="text-[11px] text-zinc-400 dark:text-zinc-500">
              Check/uncheck to include or exclude
            </div>
          </div>

          <div className="text-right">
            <div className="text-xs text-zinc-500 dark:text-zinc-400 font-medium">Running Total</div>
            <div className="text-2xl sm:text-3xl font-black text-emerald-600 dark:text-emerald-400">
              {settings.currency}
              {liveTotal.toLocaleString()}
            </div>
          </div>
        </div>

        {/* Collapsible Photo Preview */}
        {showImagePreview && imagePreviewUrl && (
          <div className="mt-3 pt-3 border-t border-zinc-200 dark:border-zinc-800 rounded-xl overflow-hidden max-h-48 flex justify-center bg-black/5 dark:bg-black/40">
            <img
              src={imagePreviewUrl}
              alt="Scanned slip"
              className="max-h-48 object-contain rounded-lg shadow-sm"
            />
          </div>
        )}
      </div>

      {/* Main Editable List of Detected Numbers */}
      <div className="flex-1 overflow-y-auto pr-1 space-y-2.5 mb-3 min-h-[220px]">
        {/* Quick Batch Selection & Add Item Toolbar */}
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center gap-2">
            <button
              onClick={() => handleSelectAll(true)}
              className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:underline cursor-pointer"
            >
              Select All
            </button>
            <span className="text-zinc-300 dark:text-zinc-700">|</span>
            <button
              onClick={() => handleSelectAll(false)}
              className="text-xs font-semibold text-zinc-500 dark:text-zinc-400 hover:underline cursor-pointer"
            >
              Deselect All
            </button>
          </div>

          <button
            id="btn-add-number-inline"
            onClick={() => setIsAddingNew(true)}
            className="flex items-center gap-1 text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:text-emerald-500 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Number</span>
          </button>
        </div>

        {/* Inline Add Item Form */}
        {isAddingNew && (
          <form
            onSubmit={handleAddNewItem}
            className="p-3 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800/70 space-y-2 animate-in fade-in"
          >
            <div className="text-xs font-bold text-emerald-800 dark:text-emerald-300">
              Add New Amount
            </div>
            <div className="grid grid-cols-2 gap-2">
              <input
                type="text"
                placeholder="Description (e.g. Milk)"
                value={newLabel}
                onChange={(e) => setNewLabel(e.target.value)}
                className="px-3 py-2 text-xs rounded-xl bg-white dark:bg-zinc-900 border border-zinc-300 dark:border-zinc-700 text-zinc-900 dark:text-zinc-100 focus:outline-emerald-500"
                autoFocus
              />
              <input
                type="number"
                step="any"
                placeholder="Amount (e.g. 250)"
                value={newAmount}
                onChange={(e) => setNewAmount(e.target.value)}
                required
                className="px-3 py-2 text-xs rounded-xl bg-white dark:bg-zinc-900 border border-zinc-300 dark:border-zinc-700 text-zinc-900 dark:text-zinc-100 focus:outline-emerald-500 font-bold"
              />
            </div>
            <div className="flex justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={() => setIsAddingNew(false)}
                className="px-3 py-1.5 text-xs rounded-xl bg-zinc-200 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 cursor-pointer font-medium"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 text-xs rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold cursor-pointer shadow-xs"
              >
                Add Item
              </button>
            </div>
          </form>
        )}

        {/* Item Rows */}
        {items.length === 0 ? (
          <div className="text-center py-8 px-4 rounded-2xl bg-zinc-50 dark:bg-zinc-900/50 border border-dashed border-zinc-200 dark:border-zinc-800">
            <p className="text-sm font-semibold text-zinc-600 dark:text-zinc-400">
              No numbers in list
            </p>
            <p className="text-xs text-zinc-400 dark:text-zinc-500 mt-1">
              Tap "Add Number" or retake photo with clearer lighting.
            </p>
          </div>
        ) : (
          items.map((item, index) => {
            const isEditing = editingId === item.id;

            return (
              <div
                key={item.id}
                className={`p-3 sm:p-3.5 rounded-2xl border transition-all flex items-center justify-between gap-2.5 ${
                  item.included
                    ? "bg-white dark:bg-zinc-900/90 border-zinc-200 dark:border-zinc-800 shadow-xs"
                    : "bg-zinc-50/70 dark:bg-zinc-950/50 border-zinc-200/60 dark:border-zinc-800/40 opacity-60"
                }`}
              >
                {/* Left: Checkbox */}
                <button
                  onClick={() => handleToggleInclude(item.id)}
                  aria-label={item.included ? "Exclude item" : "Include item"}
                  className="shrink-0 p-1 text-emerald-600 dark:text-emerald-400 hover:scale-105 active:scale-95 transition-all cursor-pointer"
                >
                  {item.included ? (
                    <CheckSquare className="w-5 h-5 fill-emerald-100 dark:fill-emerald-950" />
                  ) : (
                    <Square className="w-5 h-5 text-zinc-400" />
                  )}
                </button>

                {/* Middle: Content or Edit Inputs */}
                {isEditing ? (
                  <div className="flex-1 grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      value={editLabel}
                      onChange={(e) => setEditLabel(e.target.value)}
                      className="px-2.5 py-1.5 text-xs rounded-xl bg-zinc-100 dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 text-zinc-900 dark:text-zinc-100"
                      placeholder="Label"
                    />
                    <input
                      type="number"
                      step="any"
                      value={editAmount}
                      onChange={(e) => setEditAmount(e.target.value)}
                      className="px-2.5 py-1.5 text-xs rounded-xl bg-zinc-100 dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 text-zinc-900 dark:text-zinc-100 font-bold"
                      placeholder="Amount"
                    />
                  </div>
                ) : (
                  <div
                    className="flex-1 min-w-0 cursor-pointer"
                    onClick={() => handleToggleInclude(item.id)}
                  >
                    <div className="flex items-baseline justify-between">
                      <div className="flex items-center gap-1.5 truncate">
                        <span className="text-xs font-semibold text-zinc-800 dark:text-zinc-200 truncate">
                          {item.label}
                        </span>
                        {item.confidence === "high" && (
                          <span className="text-[9px] px-1.5 py-0.2 rounded-md bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-400 font-medium">
                            OCR
                          </span>
                        )}
                      </div>

                      <span
                        className={`text-base font-bold font-mono tracking-tight shrink-0 ml-2 ${
                          item.included
                            ? "text-zinc-900 dark:text-zinc-100"
                            : "text-zinc-400 line-through"
                        }`}
                      >
                        {settings.currency}
                        {item.amount.toLocaleString()}
                      </span>
                    </div>
                  </div>
                )}

                {/* Right: Actions */}
                <div className="flex items-center gap-1 shrink-0">
                  {isEditing ? (
                    <>
                      <button
                        onClick={() => handleSaveEdit(item.id)}
                        className="p-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer"
                        title="Save edit"
                      >
                        <Save className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setEditingId(null)}
                        className="p-1.5 rounded-lg bg-zinc-200 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 cursor-pointer"
                        title="Cancel"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </>
                  ) : (
                    <>
                      <button
                        onClick={() => handleStartEdit(item)}
                        className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-all cursor-pointer"
                        title="Edit amount or name"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteItem(item.id)}
                        className="p-1.5 rounded-lg text-zinc-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/50 transition-all cursor-pointer"
                        title="Delete item"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </>
                  )}
                </div>
              </div>
            );
          })
        )}

        {/* Smart Filtering Accordion for Excluded Unrelated Numbers (phone numbers, dates, invoice numbers) */}
        {unrelatedNumbers.length > 0 && (
          <div className="rounded-2xl border border-zinc-200 dark:border-zinc-800/80 bg-zinc-50/50 dark:bg-zinc-900/40 p-3 mt-4">
            <button
              onClick={() => setShowUnrelated(!showUnrelated)}
              className="flex items-center justify-between w-full text-left text-xs font-semibold text-zinc-500 dark:text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 cursor-pointer"
            >
              <div className="flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
                <span>
                  {unrelatedNumbers.length} Unrelated Number{unrelatedNumbers.length > 1 ? "s" : ""} Filtered (Dates, IDs, Phone)
                </span>
              </div>
              <span className="text-[11px] underline">
                {showUnrelated ? "Hide" : "Review"}
              </span>
            </button>

            {showUnrelated && (
              <div className="mt-2.5 space-y-1.5 pt-2 border-t border-zinc-200 dark:border-zinc-800">
                <p className="text-[11px] text-zinc-400 mb-2">
                  These numbers were detected but identified as phone numbers, dates, or invoice codes. Tap + to include any as an amount:
                </p>
                {unrelatedNumbers.map((unr, idx) => (
                  <div
                    key={idx}
                    className="flex items-center justify-between p-2 rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-xs"
                  >
                    <div>
                      <span className="font-semibold text-zinc-800 dark:text-zinc-200">
                        {unr.label}:
                      </span>{" "}
                      <span className="font-mono text-zinc-600 dark:text-zinc-400">
                        {unr.value}
                      </span>
                      <span className="text-[10px] text-zinc-400 ml-2 italic">
                        ({unr.reason})
                      </span>
                    </div>
                    <button
                      onClick={() => handleIncludeUnrelated(unr)}
                      className="flex items-center gap-1 px-2 py-1 rounded-lg bg-zinc-100 dark:bg-zinc-800 hover:bg-emerald-100 dark:hover:bg-emerald-950 text-[11px] font-semibold text-zinc-700 dark:text-zinc-300 hover:text-emerald-700 dark:hover:text-emerald-300 transition-all cursor-pointer"
                    >
                      <Plus className="w-3 h-3" />
                      <span>Include</span>
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Bottom Actions Bar with "Calculate Total" and "Retake Photo" */}
      <div className="pt-2 border-t border-zinc-200 dark:border-zinc-800 space-y-2 shrink-0">
        <button
          id="btn-calculate-total"
          onClick={() => onCalculateTotal(activeItems, liveTotal)}
          disabled={activeItems.length === 0}
          className="w-full py-3.5 sm:py-4 px-6 rounded-2xl bg-emerald-600 hover:bg-emerald-500 active:scale-98 text-white font-black text-base sm:text-lg flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/25 transition-all cursor-pointer disabled:opacity-40 disabled:scale-100"
        >
          <span>Calculate Total ({settings.currency}{liveTotal.toLocaleString()})</span>
          <ArrowRight className="w-5 h-5" />
        </button>

        <div className="flex gap-2">
          <button
            id="btn-retake-photo"
            onClick={onRetakePhoto}
            className="flex-1 py-2.5 rounded-xl bg-zinc-200/80 hover:bg-zinc-300 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-xs font-semibold text-zinc-700 dark:text-zinc-300 flex items-center justify-center gap-1.5 transition-all cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Retake Photo</span>
          </button>
          <button
            onClick={() => setIsAddingNew(true)}
            className="flex-1 py-2.5 rounded-xl bg-zinc-200/80 hover:bg-zinc-300 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-xs font-semibold text-zinc-700 dark:text-zinc-300 flex items-center justify-center gap-1.5 transition-all cursor-pointer"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>Add Item</span>
          </button>
        </div>
      </div>
    </div>
  );
};
