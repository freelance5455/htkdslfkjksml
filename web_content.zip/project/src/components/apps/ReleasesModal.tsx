import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { CheckCircle2, Trash2, Upload } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { errorMessage } from '@/lib/errors';
import type { StudioApp } from '@/types/studio';
import { Alert, Badge, Button, ConfirmModal, Field, IconButton, Modal, Spinner, TextInput } from '@/components/ui';

export const RELEASE_BUCKET = 'app-releases';
const MAX_FILE_BYTES = 200 * 1024 * 1024;
const VERSION_PATTERN = /^[0-9A-Za-z][0-9A-Za-z.+_-]{0,39}$/;

export interface AppRelease {
  id: string;
  app_id: string;
  version: string;
  file_name: string;
  file_size: number;
  checksum_sha256: string;
  storage_path: string;
  is_current: boolean;
  created_at: string;
}

const DATE_FORMAT = new Intl.DateTimeFormat('pt-BR', { dateStyle: 'short', timeStyle: 'short' });

function formatSize(bytes: number): string {
  return bytes >= 1024 * 1024 ? `${(bytes / (1024 * 1024)).toFixed(1)} MB` : `${Math.max(1, Math.round(bytes / 1024))} KB`;
}

async function sha256Hex(file: File): Promise<string> {
  const digest = await crypto.subtle.digest('SHA-256', await file.arrayBuffer());
  return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, '0')).join('');
}

export function ReleasesModal({ app, onClose }: { app: StudioApp | null; onClose: () => void }) {
  const [releases, setReleases] = useState<AppRelease[] | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [version, setVersion] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [fileInputKey, setFileInputKey] = useState(0);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<AppRelease | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  const appId = app?.id ?? null;

  const loadReleases = useCallback(async () => {
    if (!appId) return;
    const { data, error } = await supabase
      .from('app_releases')
      .select('*')
      .eq('app_id', appId)
      .order('created_at', { ascending: false })
      .returns<AppRelease[]>();
    if (error) return setLoadError(errorMessage(error));
    setLoadError(null);
    setReleases(data ?? []);
  }, [appId]);

  useEffect(() => {
    setReleases(null);
    setVersion('');
    setFile(null);
    setUploadError(null);
    loadReleases();
  }, [loadReleases]);

  const handleUpload = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!app) return;
    const trimmedVersion = version.trim();
    if (!VERSION_PATTERN.test(trimmedVersion)) return setUploadError('Informe a versão, por exemplo 1.2.0.');
    if (!file) return setUploadError('Selecione o arquivo .apk.');
    if (!file.name.toLowerCase().endsWith('.apk')) return setUploadError('O arquivo precisa ser um .apk.');
    if (file.size <= 0 || file.size > MAX_FILE_BYTES) return setUploadError('O arquivo deve ter até 200 MB.');

    setUploadError(null);
    setUploading(true);
    const safeName = file.name.replace(/[^A-Za-z0-9._-]/g, '_');
    const storagePath = `${app.id}/${Date.now()}-${safeName}`;

    try {
      const checksum = await sha256Hex(file);
      const { error: uploadErr } = await supabase.storage
        .from(RELEASE_BUCKET)
        .upload(storagePath, file, { contentType: 'application/vnd.android.package-archive', upsert: false });
      if (uploadErr) throw uploadErr;

      const { data: inserted, error: insertErr } = await supabase
        .from('app_releases')
        .insert({
          app_id: app.id,
          version: trimmedVersion,
          file_name: file.name,
          file_size: file.size,
          checksum_sha256: checksum,
          storage_path: storagePath,
          is_current: true,
        })
        .select('id')
        .single<{ id: string }>();
      if (insertErr) {
        await supabase.storage.from(RELEASE_BUCKET).remove([storagePath]);
        throw insertErr;
      }

      const { error: currentErr } = await supabase
        .from('app_releases')
        .update({ is_current: false })
        .eq('app_id', app.id)
        .neq('id', inserted.id);
      if (currentErr) throw currentErr;

      setVersion('');
      setFile(null);
      setFileInputKey((key) => key + 1);
      loadReleases();
    } catch (caught) {
      setUploadError(errorMessage(caught));
    } finally {
      setUploading(false);
    }
  };

  const makeCurrent = async (release: AppRelease) => {
    if (!app) return;
    setLoadError(null);
    const { error: clearErr } = await supabase.from('app_releases').update({ is_current: false }).eq('app_id', app.id);
    if (clearErr) return setLoadError(errorMessage(clearErr));
    const { error: setErr } = await supabase.from('app_releases').update({ is_current: true }).eq('id', release.id);
    if (setErr) return setLoadError(errorMessage(setErr));
    loadReleases();
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    setDeleteError(null);
    const { error: storageErr } = await supabase.storage.from(RELEASE_BUCKET).remove([deleteTarget.storage_path]);
    if (storageErr) {
      setDeleting(false);
      return setDeleteError(errorMessage(storageErr));
    }
    const { error } = await supabase.from('app_releases').delete().eq('id', deleteTarget.id);
    setDeleting(false);
    if (error) return setDeleteError(errorMessage(error));
    setDeleteTarget(null);
    loadReleases();
  };

  return (
    <>
      <Modal
        open={app !== null}
        title="Arquivos do aplicativo"
        description={app ? `Envie os arquivos .apk de ${app.name}. A versão marcada como atual é a entregue aos clientes.` : undefined}
        onClose={onClose}
        size="lg"
      >
        <div className="space-y-8">
          <form onSubmit={handleUpload} className="space-y-5 rounded-xl border border-graphite-700 bg-ink/60 p-5" noValidate>
            <div className="grid gap-5 sm:grid-cols-2">
              <Field label="Versão">
                <TextInput value={version} onChange={(event) => setVersion(event.target.value)} maxLength={40} placeholder="1.0.0" />
              </Field>
              <Field label="Arquivo .apk" hint="Até 200 MB.">
                <input
                  key={fileInputKey}
                  type="file"
                  accept=".apk,application/vnd.android.package-archive"
                  onChange={(event) => setFile(event.target.files?.[0] ?? null)}
                  className="block w-full text-sm text-graphite-300 file:mr-3 file:rounded-lg file:border-0 file:bg-graphite-700 file:px-3 file:py-2 file:text-sm file:font-medium file:text-graphite-50 hover:file:bg-graphite-600"
                />
              </Field>
            </div>
            {uploadError ? <Alert>{uploadError}</Alert> : null}
            <div className="flex justify-end">
              <Button type="submit" icon={Upload} loading={uploading}>
                Enviar arquivo
              </Button>
            </div>
          </form>

          <section className="space-y-3">
            <h3 className="font-display text-sm font-semibold text-graphite-50">Versões enviadas</h3>
            {loadError ? <Alert>{loadError}</Alert> : null}
            {releases === null && !loadError ? (
              <Spinner label="Carregando arquivos" />
            ) : releases && releases.length === 0 ? (
              <p className="py-6 text-center text-sm text-graphite-400">Nenhum arquivo enviado para este aplicativo.</p>
            ) : releases ? (
              <ul className="divide-y divide-graphite-700 rounded-xl border border-graphite-700">
                {releases.map((release) => (
                  <li key={release.id} className="flex items-center justify-between gap-4 px-4 py-3">
                    <div className="min-w-0 space-y-1">
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-medium text-graphite-100">Versão {release.version}</p>
                        {release.is_current ? <Badge tone="success">Atual</Badge> : null}
                      </div>
                      <p className="truncate font-mono text-xs text-graphite-400">{release.file_name}</p>
                      <p className="text-xs text-graphite-500">
                        {formatSize(release.file_size)} · SHA-256 {release.checksum_sha256.slice(0, 12)}… · {DATE_FORMAT.format(new Date(release.created_at))}
                      </p>
                    </div>
                    <div className="flex shrink-0 items-center gap-1">
                      {!release.is_current ? (
                        <IconButton icon={CheckCircle2} label="Definir como versão atual" onClick={() => makeCurrent(release)} />
                      ) : null}
                      <IconButton
                        icon={Trash2}
                        label="Excluir arquivo"
                        tone="danger"
                        onClick={() => {
                          setDeleteError(null);
                          setDeleteTarget(release);
                        }}
                      />
                    </div>
                  </li>
                ))}
              </ul>
            ) : null}
          </section>
        </div>
      </Modal>

      <ConfirmModal
        open={deleteTarget !== null}
        title="Excluir arquivo"
        message={`O arquivo ${deleteTarget?.file_name ?? ''} será removido. Clientes não poderão mais baixá-lo.`}
        confirmLabel="Excluir"
        busy={deleting}
        error={deleteError}
        onConfirm={handleDelete}
        onClose={() => setDeleteTarget(null)}
      />
    </>
  );
}
