import React, { useState } from 'react';
import { useProjects } from '../../context/ProjectContext';
import { 
  Settings as SettingsIcon, 
  Cpu, 
  Building2, 
  Server, 
  RefreshCw, 
  ShieldCheck, 
  Lock,
  Sparkles,
  Check,
  Smartphone,
  Download,
  Terminal,
  CheckCircle2
} from 'lucide-react';
import { AndroidAppModal } from '../common/AndroidAppModal';
import { usePWAInstall } from '../../hooks/usePWAInstall';
import { APP_SHORT_NAME, APP_BUILD_ID, APP_VERSION } from '../../config/version';
import { PRODUCTION_API_URL, getApiBaseUrl } from '../../services/apiConfig';

export const SettingsView: React.FC = () => {
  const { aiStatus, refreshAiStatus } = useProjects();
  const { isInstallable, isInstalled, install } = usePWAInstall();
  const [androidModalOpen, setAndroidModalOpen] = useState(false);
  const [agencyName, setAgencyName] = useState('Money Making Empire Studio');
  const [agencyContact, setAgencyContact] = useState('studio@moneymakingempire.internal');
  const [defaultTtl, setDefaultTtl] = useState('3600');
  const [saveFeedback, setSaveFeedback] = useState(false);

  const handleSave = () => {
    setSaveFeedback(true);
    setTimeout(() => setSaveFeedback(false), 2000);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-8">
      
      {/* Header */}
      <div>
        <div className="text-[11px] font-mono uppercase tracking-wider text-amber-400 font-semibold mb-1">
          System Configuration & Preferences
        </div>
        <h1 className="text-2xl font-bold text-neutral-100 tracking-tight">Studio Settings</h1>
        <p className="text-xs text-neutral-400 mt-1">
          Internal configuration for AI models, agency defaults, and edge deployment providers.
        </p>
      </div>

      {/* Card 1: AI Provider Architecture */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-6 shadow-sm space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-400 flex items-center justify-center">
              <Cpu className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white">AI Provider Architecture</h2>
              <p className="text-[11px] text-neutral-400">Server-side LLM engine with fallback</p>
            </div>
          </div>

          <button
            onClick={refreshAiStatus}
            className="px-3 py-1.5 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Check Engine</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
          <div className="p-3.5 rounded-lg bg-neutral-950 border border-neutral-800">
            <span className="text-[10px] text-neutral-500 block mb-1">Provider</span>
            <span className="font-semibold text-white">{aiStatus.provider}</span>
          </div>

          <div className="p-3.5 rounded-lg bg-neutral-950 border border-neutral-800">
            <span className="text-[10px] text-neutral-500 block mb-1">Active Model</span>
            <span className="font-mono font-semibold text-amber-400">{aiStatus.model}</span>
          </div>

          <div className="p-3.5 rounded-lg bg-neutral-950 border border-neutral-800">
            <span className="text-[10px] text-neutral-500 block mb-1">Operational Mode</span>
            <span className="flex items-center gap-1.5 font-semibold text-white">
              <span className={`w-2 h-2 rounded-full ${aiStatus.configured ? 'bg-emerald-400' : 'bg-amber-400'}`} />
              <span className="capitalize">{aiStatus.mode} Mode</span>
            </span>
          </div>
        </div>

        <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-800 text-[11px] text-neutral-400 flex items-center gap-2">
          <Lock className="w-4 h-4 text-emerald-400 flex-shrink-0" />
          <span>
            API keys are strictly managed via server environment variables (`GEMINI_API_KEY`) and are never exposed to browser bundles.
          </span>
        </div>
      </div>

      {/* Card 2: Agency Information */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-6 shadow-sm space-y-4">
        <div className="flex items-center gap-2.5 pb-3 border-b border-neutral-800">
          <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-400 flex items-center justify-center">
            <Building2 className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white">Agency Studio Profile</h2>
            <p className="text-[11px] text-neutral-400">Internal studio branding and default contact</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div>
            <label className="block text-neutral-400 font-semibold mb-1">Studio Brand Name</label>
            <input
              type="text"
              value={agencyName}
              onChange={(e) => setAgencyName(e.target.value)}
              className="w-full px-3 py-2 rounded bg-neutral-950 border border-neutral-800 text-white focus:outline-none focus:border-amber-500"
            />
          </div>

          <div>
            <label className="block text-neutral-400 font-semibold mb-1">Studio Contact Email</label>
            <input
              type="email"
              value={agencyContact}
              onChange={(e) => setAgencyContact(e.target.value)}
              className="w-full px-3 py-2 rounded bg-neutral-950 border border-neutral-800 text-white focus:outline-none focus:border-amber-500"
            />
          </div>
        </div>
      </div>

      {/* Card 3: Deployment & DNS Defaults */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-6 shadow-sm space-y-4">
        <div className="flex items-center gap-2.5 pb-3 border-b border-neutral-800">
          <div className="w-8 h-8 rounded-lg bg-cyan-500/10 text-cyan-400 flex items-center justify-center">
            <Server className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white">DNS & Deployment Defaults</h2>
            <p className="text-[11px] text-neutral-400">Default DNS configuration for client records</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div>
            <label className="block text-neutral-400 font-semibold mb-1">Default Apex A Record Target</label>
            <input
              type="text"
              readOnly
              value="76.76.21.21"
              className="w-full px-3 py-2 rounded bg-neutral-950 border border-neutral-800 text-neutral-400 font-mono"
            />
          </div>

          <div>
            <label className="block text-neutral-400 font-semibold mb-1">Default CNAME Target</label>
            <input
              type="text"
              readOnly
              value="cname.empire-network.net"
              className="w-full px-3 py-2 rounded bg-neutral-950 border border-neutral-800 text-neutral-400 font-mono"
            />
          </div>
        </div>
      </div>

      {/* Card 4: Android & Mobile App Architecture */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-6 shadow-sm space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-400 flex items-center justify-center">
              <Smartphone className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white">Android & Mobile Application</h2>
              <p className="text-[11px] text-neutral-400">PWA standalone engine & Capacitor Android wrapper</p>
            </div>
          </div>

          <button
            onClick={() => setAndroidModalOpen(true)}
            className="px-3 py-1.5 rounded bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/20 text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Install & APK Guide</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
          <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-800">
            <div className="text-neutral-500 font-medium mb-1">Android Package ID</div>
            <div className="font-mono text-neutral-200 text-[11px] truncate">com.moneymakingempire.websitebuilder</div>
          </div>

          <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-800">
            <div className="text-neutral-500 font-medium mb-1">Production Build</div>
            <div className="font-mono text-amber-400 font-bold text-[11px] truncate" title={APP_BUILD_ID}>
              {APP_BUILD_ID}
            </div>
          </div>

          <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-800">
            <div className="text-neutral-500 font-medium mb-1">Display Mode</div>
            <div className="text-neutral-200 font-semibold flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              <span>Standalone Fullscreen</span>
            </div>
          </div>

          <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-800">
            <div className="text-neutral-500 font-medium mb-1">Production Backend Target</div>
            <div className="font-mono text-neutral-300 text-[10px] truncate" title={PRODUCTION_API_URL}>
              ais-pre-...run.app
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 pt-1 text-xs text-neutral-400">
          <span>Theme Color: <code className="text-amber-300 font-mono text-[11px]">#0a0a0a</code> · Background: <code className="text-amber-300 font-mono text-[11px]">#0a0a0a</code></span>
          {isInstallable && (
            <button
              onClick={() => install()}
              className="text-amber-400 hover:text-amber-300 font-semibold flex items-center gap-1"
            >
              <Download className="w-3 h-3" />
              <span>Trigger 1-Click Install Now</span>
            </button>
          )}
        </div>
      </div>

      <AndroidAppModal isOpen={androidModalOpen} onClose={() => setAndroidModalOpen(false)} />

      {/* Save Button */}
      <div className="flex items-center justify-end gap-3 pt-2">
        {saveFeedback && (
          <span className="text-xs text-emerald-400 flex items-center gap-1 font-semibold">
            <Check className="w-3.5 h-3.5" /> Saved studio preferences
          </span>
        )}
        <button
          onClick={handleSave}
          className="px-5 py-2.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-neutral-950 text-xs font-bold shadow transition-all active:scale-95"
        >
          Save Settings
        </button>
      </div>

    </div>
  );
};
