import React, { useState } from 'react';
import { useProjects } from '../../context/ProjectContext';
import { ClientWebsiteRenderer } from '../preview/ClientWebsiteRenderer';
import { ImageStudioModal } from '../common/ImageStudioModal';
import { 
  WebsiteProject,
  WebsiteSection, 
  SectionType, 
  LayoutVariant, 
  CTAButton, 
  BrandStyle,
  ImageAspectRatio,
  ImageFocalPoint,
  ImageOrigin,
  WebsitePage,
  ProjectStatus 
} from '../../types/website';
import { 
  optimizeClientImageUpload, 
  generateBrandedPlaceholderSvg,
  imageAspectRatioToClass,
  imageFocalPointToClass 
} from '../../utils/imageOptimizer';
import { aiProvider } from '../../services/aiProvider';
import { runQualityAudit } from '../../services/qualityChecker';
import { downloadProjectZip, generateStandaloneHtml } from '../../services/exportService';
import { AIPromptEditorPanel } from './AIPromptEditorPanel';
import { VersionHistoryModal } from './VersionHistoryModal';
import { ProjectVersion } from '../../types/website';
import { 
  Monitor, 
  Tablet, 
  Smartphone, 
  Maximize2, 
  Minimize2, 
  RefreshCw, 
  Download, 
  Sparkles, 
  ShieldCheck, 
  ArrowUp, 
  ArrowDown, 
  Trash2, 
  Plus, 
  Eye, 
  EyeOff, 
  Sliders, 
  Type, 
  Palette, 
  Search, 
  Wand2, 
  Check, 
  ChevronRight,
  ExternalLink,
  Copy,
  AlertCircle,
  Image as ImageIcon,
  Crop,
  Upload,
  Undo2,
  Redo2,
  History,
  Save,
  Globe,
  Share2,
  ArrowLeft,
  Layers,
  FileText,
  X,
  PanelLeftClose,
  PanelLeftOpen,
  Phone,
  MessageSquare
} from 'lucide-react';

export const WebsiteEditor: React.FC = () => {
  const { activeProject, updateProject, duplicateProject, setActiveView, aiStatus, addAsset } = useProjects();

  if (!activeProject) {
    return (
      <div className="p-12 text-center text-neutral-400">
        <p className="mb-4">No active project selected.</p>
        <button
          onClick={() => setActiveView('projects')}
          className="px-4 py-2 bg-amber-500 text-neutral-950 font-bold rounded"
        >
          View Projects
        </button>
      </div>
    );
  }

  // Device viewports
  const [device, setDevice] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [clientPreviewOpen, setClientPreviewOpen] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [lastSavedTime, setLastSavedTime] = useState<string | null>(null);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [isDeployModalOpen, setIsDeployModalOpen] = useState(false);
  const [isNewPageModalOpen, setIsNewPageModalOpen] = useState(false);
  const [newPageTitle, setNewPageTitle] = useState('');
  const [newPageSlug, setNewPageSlug] = useState('');
  const [isDeploying, setIsDeploying] = useState(false);
  const [copiedShareLink, setCopiedShareLink] = useState(false);

  const [editorMode, setEditorMode] = useState<'prompt' | 'visual'>('prompt');
  const [activeTab, setActiveTab] = useState<'sections' | 'inspector' | 'style' | 'seo' | 'ai' | 'audit'>('sections');

  // Multi-Page resolution
  const pages = activeProject.pages && activeProject.pages.length > 0 ? activeProject.pages : [
    {
      id: 'page-home',
      title: 'Home',
      slug: '/',
      isHome: true,
      sections: [],
      seo: {
        pageTitle: activeProject.business.name,
        metaDescription: activeProject.business.description,
        ogTitle: activeProject.business.name,
        ogDescription: activeProject.business.description,
        ogImage: '',
        canonicalUrl: activeProject.business.websiteUrl,
        robots: 'index, follow',
        businessCategory: activeProject.business.industry,
        serviceArea: activeProject.business.location,
      }
    }
  ];

  const [activePageId, setActivePageId] = useState<string>(
    activeProject.activePageId || pages[0]?.id || 'page-home'
  );

  const currentPage = pages.find((p) => p.id === activePageId) || pages.find((p) => p.isHome) || pages[0];
  const sections = currentPage.sections || [];
  const [selectedSectionId, setSelectedSectionId] = useState<string | null>(
    sections[0]?.id || null
  );

  // Undo / Redo & Version History state
  const [undoStack, setUndoStack] = useState<WebsiteProject[]>([]);
  const [redoStack, setRedoStack] = useState<WebsiteProject[]>([]);
  const [isVersionModalOpen, setIsVersionModalOpen] = useState(false);

  // Image Studio Modal state
  const [isImageStudioOpen, setIsImageStudioOpen] = useState(false);
  const [editingItemIndex, setEditingItemIndex] = useState<number | null>(null);

  // AI Assistant input state
  const [aiPrompt, setAiPrompt] = useState('');
  const [isAiProcessing, setIsAiProcessing] = useState(false);
  const [aiFeedback, setAiFeedback] = useState<string | null>(null);

  // Export state
  const [isExporting, setIsExporting] = useState(false);

  const selectedSection = sections.find((s) => s.id === selectedSectionId) || sections[0];

  // Update project with undo history and version checkpoint
  const handleProjectUpdateWithHistory = (updated: WebsiteProject, summary?: string) => {
    setUndoStack((prev) => [JSON.parse(JSON.stringify(activeProject)), ...prev.slice(0, 19)]);
    setRedoStack([]);

    const currentVersions = activeProject.versionHistory || [];
    const nextVerNum = currentVersions.length + 1;
    const newVersion: ProjectVersion = {
      id: `ver-${nextVerNum}-${Date.now()}`,
      versionNumber: nextVerNum,
      timestamp: new Date().toISOString(),
      label: `Version ${nextVerNum} - ${summary || 'AI Modification'}`,
      summary: summary || 'AI refined layout and styling',
      snapshot: JSON.parse(JSON.stringify(updated)),
    };

    const finalized: WebsiteProject = {
      ...updated,
      activePageId: currentPage.id,
      versionHistory: [newVersion, ...currentVersions],
      updatedAt: new Date().toISOString(),
    };

    updateProject(finalized);
  };

  const handleUndo = () => {
    if (undoStack.length === 0) return;
    const previousState = undoStack[0];
    setUndoStack((prev) => prev.slice(1));
    setRedoStack((prev) => [JSON.parse(JSON.stringify(activeProject)), ...prev]);
    updateProject(previousState);
  };

  const handleRedo = () => {
    if (redoStack.length === 0) return;
    const nextState = redoStack[0];
    setRedoStack((prev) => prev.slice(1));
    setUndoStack((prev) => [JSON.parse(JSON.stringify(activeProject)), ...prev]);
    updateProject(nextState);
  };

  const handleRestoreVersion = (version: ProjectVersion) => {
    if (!version.snapshot) return;
    handleProjectUpdateWithHistory(
      version.snapshot,
      `Restored Version ${version.versionNumber}`
    );
  };

  // Save / Update helper for active page sections
  const handleUpdateSection = (updatedSec: WebsiteSection) => {
    const updatedSections = sections.map((s) => (s.id === updatedSec.id ? updatedSec : s));
    const updatedPages = activeProject.pages.map((p) =>
      p.id === currentPage.id ? { ...p, sections: updatedSections } : p
    );
    handleProjectUpdateWithHistory(
      { ...activeProject, pages: updatedPages, activePageId: currentPage.id },
      `Updated ${updatedSec.type} section on ${currentPage.title}`
    );
  };

  const handleMoveSection = (index: number, direction: 'up' | 'down') => {
    const targetIdx = direction === 'up' ? index - 1 : index + 1;
    if (targetIdx < 0 || targetIdx >= sections.length) return;

    const reordered = [...sections];
    const temp = reordered[index];
    reordered[index] = reordered[targetIdx];
    reordered[targetIdx] = temp;

    const finalized = reordered.map((sec, idx) => ({ ...sec, order: idx + 1 }));
    const updatedPages = activeProject.pages.map((p) =>
      p.id === currentPage.id ? { ...p, sections: finalized } : p
    );
    updateProject({ ...activeProject, pages: updatedPages, activePageId: currentPage.id });
  };

  const handleToggleVisibility = (sectionId: string) => {
    const updatedSections = sections.map((s) =>
      s.id === sectionId ? { ...s, isVisible: !s.isVisible } : s
    );
    const updatedPages = activeProject.pages.map((p) =>
      p.id === currentPage.id ? { ...p, sections: updatedSections } : p
    );
    updateProject({ ...activeProject, pages: updatedPages, activePageId: currentPage.id });
  };

  const handleDeleteSection = (sectionId: string) => {
    if (sections.length <= 1) {
      alert('Cannot delete the last remaining section on this page.');
      return;
    }
    const updatedSections = sections.filter((s) => s.id !== sectionId);
    const updatedPages = activeProject.pages.map((p) =>
      p.id === currentPage.id ? { ...p, sections: updatedSections } : p
    );
    updateProject({ ...activeProject, pages: updatedPages, activePageId: currentPage.id });
    setSelectedSectionId(updatedSections[0]?.id || null);
  };

  // Multi-page management
  const handleAddPage = () => {
    if (!newPageTitle.trim()) return;
    const title = newPageTitle.trim();
    let slug = newPageSlug.trim() || `/${title.toLowerCase().replace(/[^a-z0-9]/g, '-')}`;
    if (!slug.startsWith('/')) slug = `/${slug}`;
    const newPageId = `page-${Date.now()}`;
    const newPage: WebsitePage = {
      id: newPageId,
      title,
      slug,
      isHome: false,
      seo: {
        pageTitle: `${title} | ${activeProject.business.name}`,
        metaDescription: `${title} - ${activeProject.business.description}`,
        ogTitle: `${title} | ${activeProject.business.name}`,
        ogDescription: activeProject.business.description,
        ogImage: '',
        canonicalUrl: `${activeProject.business.websiteUrl}${slug}`,
        robots: 'index, follow',
        businessCategory: activeProject.business.industry,
        serviceArea: activeProject.business.location,
      },
      sections: [
        {
          id: `sec-hero-${Date.now()}`,
          type: 'hero',
          title: title,
          subtitle: `Explore ${title.toLowerCase()} tailored for your specific goals.`,
          layoutVariant: 'centered',
          isVisible: true,
          order: 1,
        },
        {
          id: `sec-feat-${Date.now()}`,
          type: 'features',
          title: 'Core Capabilities',
          subtitle: 'Precision execution with certified deliverables.',
          layoutVariant: 'grid-3',
          items: [
            { id: 'f-1', title: 'Excellence in Service', description: 'Tailored roadmaps built around client success.' },
            { id: 'f-2', title: 'Transparent Process', description: 'Clear milestones with prompt status updates.' },
            { id: 'f-3', title: 'Dedicated Support', description: 'Direct contact with knowledgeable specialists.' },
          ],
          isVisible: true,
          order: 2,
        },
        {
          id: `sec-cta-${Date.now()}`,
          type: 'cta-banner',
          title: 'Ready to Get Started?',
          subtitle: 'Connect with our dedicated team today.',
          layoutVariant: 'centered',
          ctaPrimary: {
            label: 'Contact Us',
            link: '#contact',
            type: 'primary',
            icon: 'arrow',
          },
          isVisible: true,
          order: 3,
        }
      ],
    };

    const updatedPages = [...pages, newPage];
    handleProjectUpdateWithHistory(
      { ...activeProject, pages: updatedPages, activePageId: newPageId },
      `Added new page: ${title}`
    );
    setActivePageId(newPageId);
    setSelectedSectionId(newPage.sections[0].id);
    setIsNewPageModalOpen(false);
    setNewPageTitle('');
    setNewPageSlug('');
  };

  const handleDeletePage = (pageId: string) => {
    if (pages.length <= 1) {
      alert('A website must have at least one page.');
      return;
    }
    const target = pages.find((p) => p.id === pageId);
    if (target?.isHome) {
      alert('The Home page cannot be deleted.');
      return;
    }
    const confirmed = window.confirm ? window.confirm(`Delete page "${target?.title}"?`) : true;
    if (!confirmed) return;

    const updatedPages = pages.filter((p) => p.id !== pageId);
    const nextActive = updatedPages[0].id;
    handleProjectUpdateWithHistory(
      { ...activeProject, pages: updatedPages, activePageId: nextActive },
      `Deleted page: ${target?.title}`
    );
    setActivePageId(nextActive);
    setSelectedSectionId(updatedPages[0].sections[0]?.id || null);
  };

  const handleSaveDraft = () => {
    const now = new Date();
    const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const updated = {
      ...activeProject,
      activePageId: currentPage.id,
      updatedAt: now.toISOString(),
      status: (activeProject.status === 'live' ? 'live' : 'draft') as ProjectStatus,
    };
    updateProject(updated);
    setLastSavedTime(timeStr);
  };

  const handleDeploy = () => {
    setIsDeploying(true);
    const deploymentUrl = `https://${activeProject.id.slice(0, 16)}.empire-preview.app`;
    const updated = {
      ...activeProject,
      status: 'ready_to_deploy' as const,
      updatedAt: new Date().toISOString(),
      deployment: {
        ...activeProject.deployment,
        deploymentUrl,
        verified: true,
        httpsActive: true,
        dnsStatus: 'propagated' as const,
      },
    };
    updateProject(updated);
    setTimeout(() => {
      setIsDeploying(false);
      setIsDeployModalOpen(true);
    }, 300);
  };

  const handleAddSection = (type: SectionType) => {
    const newId = `sec-${type}-${Date.now()}`;
    let newSection: WebsiteSection = {
      id: newId,
      type,
      title:
        type === 'about'
          ? `About ${activeProject.business.name}`
          : type === 'gallery'
          ? 'Studio & Facility Visual Showcase'
          : type === 'portfolio'
          ? 'Featured Client Engagements'
          : type === 'faq'
          ? 'Frequently Asked Questions'
          : type === 'process'
          ? 'Our Execution Process'
          : type === 'services'
          ? 'Additional Services'
          : 'Schedule a Private Consultation',
      subtitle:
        type === 'gallery'
          ? 'A photographic exploration of our facilities, craftsmanship, and bespoke clinical suites.'
          : 'Clear, transparent communication structured around your priorities.',
      layoutVariant:
        type === 'about'
          ? 'split-left'
          : type === 'gallery' || type === 'services' || type === 'portfolio'
          ? 'grid-3'
          : type === 'faq'
          ? 'accordion'
          : 'timeline',
      imageUrl:
        type === 'about'
          ? 'https://images.unsplash.com/photo-1497215728101-856f4ea42174?auto=format&fit=crop&w=1200&q=80'
          : undefined,
      imageAlt:
        type === 'about'
          ? `Architectural studio and workspace of ${activeProject.business.name}`
          : undefined,
      imageOrigin: type === 'about' ? 'stock_licensed' : undefined,
      imageAspectRatio: type === 'about' ? '4:3' : '16:9',
      imageFocalPoint: 'center',
      isImagePlaceholder: false,
      isVisible: true,
      order: sections.length + 1,
      items:
        type === 'portfolio'
          ? [
              {
                id: 'p-1',
                title: 'Private Estate Transformation',
                description: 'Full-scope architectural restoration with custom materials.',
                imageUrl: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=800&q=80',
                badge: 'Completed',
              },
              {
                id: 'p-2',
                title: 'Executive Headquarters Overhaul',
                description: 'State-of-the-art corporate workspace with custom acoustic paneling.',
                imageUrl: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=800&q=80',
                badge: 'Completed',
              },
            ]
          : [
              { id: 'item-1', title: 'Consultation & Scoping', description: 'Comprehensive review of requirements and delivery roadmap.' },
              { id: 'item-2', title: 'Precision Execution', description: 'Engineered according to rigorous quality standards.' },
            ],
    };

    const updatedPages = activeProject.pages.map((p) =>
      p.id === currentPage.id ? { ...p, sections: [...sections, newSection] } : p
    );
    updateProject({ ...activeProject, pages: updatedPages });
    setSelectedSectionId(newId);
    setActiveTab('inspector');
  };

  // AI Command Execution
  const handleExecuteAiCommand = async (cmdToRun?: string) => {
    const command = cmdToRun || aiPrompt;
    if (!command.trim()) return;

    setIsAiProcessing(true);
    setAiFeedback(null);

    try {
      const result = await aiProvider.modifyWebsite(command, activeProject);
      updateProject(result.updatedProject);
      setAiFeedback(`${result.summary} (${result.mode === 'online' ? 'Gemini 3.8 Flash' : 'Deterministic Engine'})`);
      if (!cmdToRun) setAiPrompt('');
    } catch (err: any) {
      setAiFeedback(`Error: ${err.message || 'AI modification failed'}`);
    } finally {
      setIsAiProcessing(false);
    }
  };

  // Download ZIP
  const handleDownloadZip = async () => {
    setIsExporting(true);
    try {
      const blob = await downloadProjectZip(activeProject);
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${activeProject.business.name.toLowerCase().replace(/[^a-z0-9]/g, '-')}-website.zip`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (e: any) {
      alert(`Export failed: ${e.message}`);
    } finally {
      setIsExporting(false);
    }
  };

  // Open Preview in Standalone Window
  const handleOpenStandalone = () => {
    const html = generateStandaloneHtml(activeProject);
    const win = window.open('', '_blank');
    if (win) {
      win.document.write(html);
      win.document.close();
    }
  };

  // Quality Audit
  const qualityReport = runQualityAudit(activeProject);

  return (
    <div className={`w-full flex-1 flex flex-col md:h-[calc(100vh-4rem)] bg-neutral-950 text-neutral-100 min-h-0 ${isFullscreen ? 'fixed inset-0 z-50 h-screen' : ''}`}>
      
      {/* EDITOR CONTROL BAR */}
      <div className="h-14 border-b border-neutral-800 px-3 sm:px-4 flex items-center justify-between bg-neutral-900/90 backdrop-blur z-20 flex-shrink-0 gap-2 overflow-x-auto no-scrollbar max-w-full">
        
        {/* Project Name, Status Selector & Save Draft */}
        <div className="flex items-center gap-2 sm:gap-3 flex-shrink-0">
          <button
            onClick={() => setActiveView('projects')}
            className="text-xs text-neutral-400 hover:text-white font-medium flex items-center gap-1"
          >
            ← Projects
          </button>
          <span className="text-neutral-700">/</span>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-neutral-100 max-w-[100px] xs:max-w-[130px] sm:max-w-[180px] truncate" title={activeProject.business.name}>
              {activeProject.business.name}
            </span>
            <select
              value={activeProject.status}
              onChange={(e) => updateProject({ ...activeProject, status: e.target.value as any })}
              className="text-[11px] font-mono uppercase px-2 py-0.5 rounded bg-neutral-950 border border-neutral-700 text-amber-400 focus:outline-none cursor-pointer"
            >
              <option value="draft">Draft</option>
              <option value="demo">Demo</option>
              <option value="client_review">Client Review</option>
              <option value="approved">Approved</option>
              <option value="ready_to_deploy">Ready to Deploy</option>
              <option value="live">Live</option>
            </select>
          </div>

          {/* Save Draft Button */}
          <button
            type="button"
            onClick={handleSaveDraft}
            className="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-neutral-950 border border-neutral-800 hover:border-neutral-700 text-xs text-neutral-300 font-medium transition-colors"
            title="Save current project draft"
          >
            <Save className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-[11px]">{lastSavedTime ? `Saved ${lastSavedTime}` : 'Save Draft'}</span>
          </button>
        </div>

        {/* Center: EDITING MODE & DEVICE SWITCHER */}
        <div className="hidden md:flex items-center gap-2">
          {/* EDITING MODE SWITCHER */}
          <div className="flex items-center p-0.5 rounded-xl bg-neutral-950 border border-neutral-800 shadow-sm">
            <button
              type="button"
              onClick={() => setEditorMode('prompt')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                editorMode === 'prompt'
                  ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-neutral-950 shadow-md shadow-amber-500/20'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>PROMPT EDITOR</span>
            </button>
            <button
              type="button"
              onClick={() => setEditorMode('visual')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                editorMode === 'visual'
                  ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-neutral-950 shadow-md shadow-amber-500/20'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>VISUAL EDITOR</span>
            </button>
          </div>

          {/* Device Switcher Controls */}
          <div className="flex items-center gap-1 bg-neutral-950 p-1 rounded-lg border border-neutral-800">
            <button
              onClick={() => setDevice('desktop')}
              className={`p-1.5 rounded text-xs transition-colors flex items-center gap-1 ${
                device === 'desktop' ? 'bg-neutral-800 text-amber-400 font-bold' : 'text-neutral-400 hover:text-white'
              }`}
              title="Desktop View"
            >
              <Monitor className="w-3.5 h-3.5" />
              <span className="hidden xl:inline">Desktop</span>
            </button>
            <button
              onClick={() => setDevice('tablet')}
              className={`p-1.5 rounded text-xs transition-colors flex items-center gap-1 ${
                device === 'tablet' ? 'bg-neutral-800 text-amber-400 font-bold' : 'text-neutral-400 hover:text-white'
              }`}
              title="Tablet 768px"
            >
              <Tablet className="w-3.5 h-3.5" />
              <span className="hidden xl:inline">Tablet</span>
            </button>
            <button
              onClick={() => setDevice('mobile')}
              className={`p-1.5 rounded text-xs transition-colors flex items-center gap-1 ${
                device === 'mobile' ? 'bg-neutral-800 text-amber-400 font-bold' : 'text-neutral-400 hover:text-white'
              }`}
              title="Mobile 390px"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span className="hidden xl:inline">Mobile</span>
            </button>
          </div>
        </div>

        {/* Right Action Tools: PREVIEW, DEPLOY, SHARE, EXPORT */}
        <div className="flex items-center gap-2 flex-shrink-0">
          {/* PROMINENT CLIENT PREVIEW BUTTON */}
          <button
            type="button"
            onClick={() => setClientPreviewOpen(true)}
            className="px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-neutral-950 font-extrabold text-xs flex items-center gap-1.5 shadow-md shadow-amber-500/20 active:scale-95 transition-all"
            title="Open large full-screen presentation preview"
          >
            <Eye className="w-4 h-4" />
            <span>PREVIEW</span>
          </button>

          {/* DEPLOY BUTTON */}
          <button
            type="button"
            onClick={handleDeploy}
            disabled={isDeploying}
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-sm active:scale-95 transition-all disabled:opacity-50"
            title="Deploy live public staging link"
          >
            <Globe className="w-3.5 h-3.5" />
            <span>{isDeploying ? 'Deploying...' : 'Deploy'}</span>
          </button>

          {/* SHARE WITH CLIENT BUTTON */}
          <button
            type="button"
            onClick={() => setIsShareModalOpen(true)}
            className="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-neutral-950 border border-neutral-800 hover:border-neutral-700 text-amber-400 text-xs font-semibold transition-colors"
            title="Share preview link with client"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Share</span>
          </button>

          {/* Undo / Redo & Version History */}
          <div className="hidden lg:flex items-center gap-1">
            <button
              type="button"
              onClick={handleUndo}
              disabled={undoStack.length === 0}
              title="Undo last modification"
              className="p-1.5 rounded bg-neutral-950 border border-neutral-800 hover:border-neutral-700 text-neutral-300 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
            >
              <Undo2 className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={handleRedo}
              disabled={redoStack.length === 0}
              title="Redo modification"
              className="p-1.5 rounded bg-neutral-950 border border-neutral-800 hover:border-neutral-700 text-neutral-300 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
            >
              <Redo2 className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => setIsVersionModalOpen(true)}
              title="View Version History"
              className="px-2 py-1 rounded bg-neutral-950 border border-neutral-800 hover:border-neutral-700 text-neutral-300 hover:text-amber-400 flex items-center gap-1 text-[11px] font-mono transition-colors"
            >
              <History className="w-3.5 h-3.5 text-amber-400" />
              <span>v{activeProject.versionHistory?.length || 1}</span>
            </button>
          </div>

          {/* Quality Audit Shortcut */}
          <button
            onClick={() => {
              setEditorMode('visual');
              setActiveTab('audit');
            }}
            className="hidden xl:flex items-center gap-1.5 px-2 py-1 rounded bg-neutral-950 border border-neutral-800 hover:border-neutral-700 text-xs text-neutral-300 font-medium"
          >
            <ShieldCheck className={`w-3.5 h-3.5 ${qualityReport.overallScore >= 80 ? 'text-emerald-400' : 'text-amber-400'}`} />
            <span>{qualityReport.overallScore}%</span>
          </button>

          {/* Standalone Window */}
          <button
            onClick={handleOpenStandalone}
            title="Open in new window"
            className="p-1.5 text-neutral-400 hover:text-white rounded hover:bg-neutral-800 transition-colors"
          >
            <ExternalLink className="w-4 h-4" />
          </button>

          {/* Fullscreen Toggle */}
          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            title="Toggle Fullscreen"
            className="p-1.5 text-neutral-400 hover:text-white rounded hover:bg-neutral-800 transition-colors"
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>

          {/* Export ZIP */}
          <button
            onClick={handleDownloadZip}
            disabled={isExporting}
            className="px-3 py-1.5 rounded bg-neutral-100 hover:bg-white text-neutral-950 font-bold text-xs flex items-center gap-1 shadow-sm active:scale-95 disabled:opacity-50"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{isExporting ? 'Exporting...' : 'Export'}</span>
          </button>
        </div>
      </div>

      {/* WORKSPACE: LEFT/TOP EDIT CONTROLS & RIGHT/BOTTOM PREVIEW CANVAS */}
      <div className="flex-1 flex flex-col md:flex-row min-h-0 relative overflow-y-auto md:overflow-hidden overflow-x-hidden">
        
        {/* EDIT CONTROLS: TOP ON MOBILE, LEFT ON DESKTOP */}
        <div className={`
          ${sidebarCollapsed ? 'hidden' : 'flex'}
          w-full md:w-80 lg:w-96 border-b md:border-b-0 md:border-r border-neutral-800 bg-neutral-900 flex-col flex-shrink-0 z-10 md:h-full md:overflow-hidden
        `}>
          {/* Mobile Edit Controls Header with Quick Switcher */}
          <div className="md:hidden flex items-center justify-between px-3 py-2 bg-neutral-950 border-b border-neutral-800 flex-shrink-0">
            <div className="flex items-center gap-1.5 font-bold text-xs text-neutral-200">
              <Sliders className="w-3.5 h-3.5 text-amber-400" />
              <span>Edit Controls</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="flex items-center p-0.5 rounded-lg bg-neutral-900 border border-neutral-800 text-[11px]">
                <button
                  type="button"
                  onClick={() => setEditorMode('prompt')}
                  className={`px-2 py-0.5 rounded font-semibold transition-all ${
                    editorMode === 'prompt' ? 'bg-amber-500 text-neutral-950 font-bold' : 'text-neutral-400'
                  }`}
                >
                  Prompt
                </button>
                <button
                  type="button"
                  onClick={() => setEditorMode('visual')}
                  className={`px-2 py-0.5 rounded font-semibold transition-all ${
                    editorMode === 'visual' ? 'bg-amber-500 text-neutral-950 font-bold' : 'text-neutral-400'
                  }`}
                >
                  Visual
                </button>
              </div>
              <button
                type="button"
                onClick={() => setSidebarCollapsed(true)}
                className="px-2 py-0.5 rounded bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-white text-[11px]"
                title="Collapse controls to view canvas"
              >
                Hide
              </button>
            </div>
          </div>
          {editorMode === 'prompt' ? (
            <AIPromptEditorPanel
              project={activeProject}
              activePageId={activePageId}
              selectedSection={selectedSection}
              selectedSectionId={selectedSectionId}
              onSelectSection={(id) => setSelectedSectionId(id)}
              onUpdateProject={handleProjectUpdateWithHistory}
              onUndo={handleUndo}
              onRedo={handleRedo}
              canUndo={undoStack.length > 0}
              canRedo={redoStack.length > 0}
              onOpenVersionsModal={() => setIsVersionModalOpen(true)}
            />
          ) : (
            <>
              {/* Subtabs Bar */}
              <div className="flex border-b border-neutral-800 text-xs overflow-x-auto bg-neutral-950/70">
                {[
                  { id: 'sections', label: 'Sections', icon: Sliders },
                  { id: 'inspector', label: 'Inspector', icon: Type },
                  { id: 'style', label: 'Brand & Colors', icon: Palette },
                  { id: 'seo', label: 'SEO & Meta', icon: Search },
                  { id: 'ai', label: 'AI Assist', icon: Sparkles },
                  { id: 'audit', label: 'Quality', icon: ShieldCheck },
                ].map((tab) => {
                  const Icon = tab.icon;
                  const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`px-3 py-2.5 font-medium whitespace-nowrap flex items-center gap-1.5 transition-all border-b-2 ${
                    isActive
                      ? 'border-amber-400 text-amber-400 bg-neutral-900'
                      : 'border-transparent text-neutral-400 hover:text-neutral-200'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* TAB 1: SECTIONS LIST & REORDER */}
          {activeTab === 'sections' && (
            <div className="flex-1 overflow-y-auto max-h-[50vh] md:max-h-none p-4 space-y-3">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs uppercase tracking-wider text-neutral-400 font-semibold">
                  Page Sections ({sections.length})
                </span>
                <span className="text-[10px] text-neutral-500 font-mono">Drag or Reorder</span>
              </div>

              <div className="space-y-2">
                {sections.map((sec, idx) => {
                  const isSelected = selectedSectionId === sec.id;
                  return (
                    <div
                      key={sec.id}
                      onClick={() => {
                        setSelectedSectionId(sec.id);
                        setActiveTab('inspector');
                      }}
                      className={`p-3 rounded-lg border transition-all cursor-pointer flex items-center justify-between ${
                        isSelected
                          ? 'bg-neutral-800 border-amber-500 shadow-sm'
                          : 'bg-neutral-950 border-neutral-800 hover:border-neutral-700'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 truncate">
                        <span className="text-[10px] font-mono text-neutral-500">0{idx + 1}</span>
                        <div className="truncate">
                          <div className="text-xs font-semibold text-neutral-200 capitalize truncate">
                            {sec.type}
                          </div>
                          <div className="text-[11px] text-neutral-400 truncate max-w-[160px]">
                            {sec.title}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-1 text-neutral-400" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={() => handleToggleVisibility(sec.id)}
                          className="p-1 hover:text-white"
                          title={sec.isVisible ? 'Hide Section' : 'Show Section'}
                        >
                          {sec.isVisible ? <Eye className="w-3.5 h-3.5 text-neutral-400" /> : <EyeOff className="w-3.5 h-3.5 text-neutral-600" />}
                        </button>
                        <button
                          disabled={idx === 0}
                          onClick={() => handleMoveSection(idx, 'up')}
                          className="p-1 hover:text-white disabled:opacity-20"
                          title="Move Up"
                        >
                          <ArrowUp className="w-3.5 h-3.5" />
                        </button>
                        <button
                          disabled={idx === sections.length - 1}
                          onClick={() => handleMoveSection(idx, 'down')}
                          className="p-1 hover:text-white disabled:opacity-20"
                          title="Move Down"
                        >
                          <ArrowDown className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDeleteSection(sec.id)}
                          className="p-1 hover:text-rose-400"
                          title="Delete Section"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Add Section Quick Bar */}
              <div className="pt-4 border-t border-neutral-800">
                <span className="block text-xs uppercase tracking-wider text-neutral-400 font-semibold mb-2">
                  Add Section
                </span>
                <div className="grid grid-cols-2 gap-2">
                  {(['about', 'services', 'gallery', 'portfolio', 'process', 'pricing', 'faq', 'contact'] as SectionType[]).map((st) => (
                    <button
                      key={st}
                      onClick={() => handleAddSection(st)}
                      className="px-2.5 py-1.5 rounded bg-neutral-950 border border-neutral-800 hover:border-neutral-700 text-[11px] text-neutral-300 capitalize text-left flex items-center gap-1.5"
                    >
                      <Plus className="w-3 h-3 text-amber-400" />
                      <span>{st} Section</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: VISUAL SECTION INSPECTOR */}
          {activeTab === 'inspector' && selectedSection && (
            <div className="flex-1 overflow-y-auto max-h-[50vh] md:max-h-none p-4 space-y-4 text-xs">
              <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
                <span className="font-bold uppercase tracking-wider text-amber-400">
                  Editing: {selectedSection.type}
                </span>
                <span className="text-[10px] text-neutral-500 font-mono">ID: {selectedSection.id.slice(0, 10)}</span>
              </div>

              {/* Section Headline */}
              <div>
                <label className="block text-[11px] uppercase tracking-wider text-neutral-400 font-semibold mb-1">
                  Headline Text
                </label>
                <textarea
                  rows={2}
                  value={selectedSection.title}
                  onChange={(e) => handleUpdateSection({ ...selectedSection, title: e.target.value })}
                  className="w-full px-3 py-2 rounded bg-neutral-950 border border-neutral-800 text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              {/* Subheadline */}
              <div>
                <label className="block text-[11px] uppercase tracking-wider text-neutral-400 font-semibold mb-1">
                  Subtitle / Description
                </label>
                <textarea
                  rows={3}
                  value={selectedSection.subtitle || ''}
                  onChange={(e) => handleUpdateSection({ ...selectedSection, subtitle: e.target.value })}
                  className="w-full px-3 py-2 rounded bg-neutral-950 border border-neutral-800 text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              {/* Kicker (for Hero) */}
              {selectedSection.type === 'hero' && (
                <div>
                  <label className="block text-[11px] uppercase tracking-wider text-neutral-400 font-semibold mb-1">
                    Pre-Header Kicker
                  </label>
                  <input
                    type="text"
                    value={selectedSection.kicker || ''}
                    onChange={(e) => handleUpdateSection({ ...selectedSection, kicker: e.target.value })}
                    className="w-full px-3 py-2 rounded bg-neutral-950 border border-neutral-800 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
              )}

              {/* Layout Variant Selector */}
              <div>
                <label className="block text-[11px] uppercase tracking-wider text-neutral-400 font-semibold mb-1">
                  Layout Variant
                </label>
                <select
                  value={selectedSection.layoutVariant}
                  onChange={(e) => handleUpdateSection({ ...selectedSection, layoutVariant: e.target.value as LayoutVariant })}
                  className="w-full px-3 py-2 rounded bg-neutral-950 border border-neutral-800 text-white focus:outline-none focus:border-amber-500"
                >
                  <option value="centered">Centered Content</option>
                  <option value="split-right">Split (Image on Right)</option>
                  <option value="split-left">Split (Image on Left)</option>
                  <option value="grid-3">3-Column Grid</option>
                  <option value="timeline">Step Timeline</option>
                  <option value="accordion">Expandable Accordion</option>
                </select>
              </div>

              {/* Primary CTA */}
              {selectedSection.ctaPrimary && (
                <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-800 space-y-2">
                  <span className="font-semibold text-neutral-300">Primary CTA Button</span>
                  <div>
                    <label className="block text-[10px] text-neutral-500 mb-1">Button Label</label>
                    <input
                      type="text"
                      value={selectedSection.ctaPrimary.label}
                      onChange={(e) =>
                        handleUpdateSection({
                          ...selectedSection,
                          ctaPrimary: { ...selectedSection.ctaPrimary!, label: e.target.value },
                        })
                      }
                      className="w-full px-2.5 py-1.5 rounded bg-neutral-900 border border-neutral-700 text-white focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-neutral-500 mb-1">Button Action Link</label>
                    <input
                      type="text"
                      value={selectedSection.ctaPrimary.link}
                      onChange={(e) =>
                        handleUpdateSection({
                          ...selectedSection,
                          ctaPrimary: { ...selectedSection.ctaPrimary!, link: e.target.value },
                        })
                      }
                      placeholder="#contact or tel:+1..."
                      className="w-full px-2.5 py-1.5 rounded bg-neutral-900 border border-neutral-700 text-white focus:outline-none"
                    />
                  </div>
                </div>
              )}

              {/* Image Studio & Optimization Controls */}
              <div className="p-3.5 rounded-xl bg-neutral-950 border border-neutral-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-neutral-200 flex items-center gap-1.5">
                    <ImageIcon className="w-3.5 h-3.5 text-amber-400" />
                    <span>Section Imagery Studio</span>
                  </span>
                  {selectedSection.imageOrigin && (
                    <span className="text-[9px] font-mono uppercase px-1.5 py-0.5 rounded bg-neutral-900 border border-neutral-700 text-neutral-400">
                      {selectedSection.imageOrigin.replace('_', ' ')}
                    </span>
                  )}
                </div>

                {selectedSection.imageUrl ? (
                  <div className="space-y-3">
                    {/* Thumbnail Preview */}
                    <div className="relative rounded-lg overflow-hidden border border-neutral-800 bg-neutral-900 aspect-[16/9] group">
                      <img
                        src={selectedSection.imageUrl}
                        alt={selectedSection.imageAlt || selectedSection.title}
                        className={`w-full h-full object-cover ${imageFocalPointToClass(selectedSection.imageFocalPoint)}`}
                      />
                      <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                        <button
                          type="button"
                          onClick={() => setIsImageStudioOpen(true)}
                          className="px-3 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-neutral-950 font-bold text-xs shadow flex items-center gap-1"
                        >
                          <Crop className="w-3.5 h-3.5" />
                          <span>Edit / Replace</span>
                        </button>
                      </div>
                    </div>

                    {/* Quick Button to Launch Studio */}
                    <button
                      type="button"
                      onClick={() => setIsImageStudioOpen(true)}
                      className="w-full py-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-amber-400 font-semibold text-xs border border-amber-500/20 flex items-center justify-center gap-1.5 transition-colors"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Open Image Studio (AI / Upload / Crop)</span>
                    </button>

                    {/* Aspect Ratio and Focal Point Grid */}
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-[10px] text-neutral-500 mb-1">Aspect Ratio</label>
                        <select
                          value={selectedSection.imageAspectRatio || '16:9'}
                          onChange={(e) =>
                            handleUpdateSection({
                              ...selectedSection,
                              imageAspectRatio: e.target.value as ImageAspectRatio,
                            })
                          }
                          className="w-full px-2 py-1.5 rounded bg-neutral-900 border border-neutral-800 text-neutral-200 text-xs focus:outline-none"
                        >
                          <option value="16:9">16:9 Wide</option>
                          <option value="4:3">4:3 Standard</option>
                          <option value="1:1">1:1 Square</option>
                          <option value="21:9">21:9 Cinema</option>
                          <option value="3:4">3:4 Portrait</option>
                          <option value="auto">Auto</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-[10px] text-neutral-500 mb-1">Focal Point</label>
                        <select
                          value={selectedSection.imageFocalPoint || 'center'}
                          onChange={(e) =>
                            handleUpdateSection({
                              ...selectedSection,
                              imageFocalPoint: e.target.value as ImageFocalPoint,
                            })
                          }
                          className="w-full px-2 py-1.5 rounded bg-neutral-900 border border-neutral-800 text-neutral-200 text-xs focus:outline-none capitalize"
                        >
                          <option value="center">Center</option>
                          <option value="top">Top</option>
                          <option value="bottom">Bottom</option>
                          <option value="left">Left</option>
                          <option value="right">Right</option>
                        </select>
                      </div>
                    </div>

                    {/* Alt Text */}
                    <div>
                      <label className="block text-[10px] text-neutral-500 mb-1">Accessibility Alt Text</label>
                      <input
                        type="text"
                        value={selectedSection.imageAlt || ''}
                        onChange={(e) => handleUpdateSection({ ...selectedSection, imageAlt: e.target.value })}
                        placeholder="Accurate description of visual scene..."
                        className="w-full px-2.5 py-1.5 rounded bg-neutral-900 border border-neutral-800 text-neutral-200 text-xs focus:outline-none focus:border-amber-500"
                      />
                    </div>

                    {/* Placeholder & Removal Buttons */}
                    <div className="flex items-center justify-between pt-1">
                      <button
                        type="button"
                        onClick={() =>
                          handleUpdateSection({
                            ...selectedSection,
                            isImagePlaceholder: !selectedSection.isImagePlaceholder,
                          })
                        }
                        className={`text-[10px] font-semibold px-2 py-1 rounded border transition-colors ${
                          selectedSection.isImagePlaceholder
                            ? 'bg-amber-500/10 border-amber-500/40 text-amber-400'
                            : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-white'
                        }`}
                      >
                        {selectedSection.isImagePlaceholder ? '✓ Placeholder Active' : 'Mark as Placeholder'}
                      </button>

                      <button
                        type="button"
                        onClick={() =>
                          handleUpdateSection({
                            ...selectedSection,
                            imageUrl: undefined,
                            imageAlt: undefined,
                          })
                        }
                        className="text-[10px] text-rose-400 hover:text-rose-300"
                      >
                        Remove Image
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="p-4 border border-dashed border-neutral-800 rounded-lg text-center space-y-2">
                    <p className="text-[11px] text-neutral-400">No image assigned to this section.</p>
                    <button
                      type="button"
                      onClick={() => setIsImageStudioOpen(true)}
                      className="px-3 py-1.5 rounded bg-neutral-800 hover:bg-neutral-700 text-amber-400 text-xs font-semibold inline-flex items-center gap-1.5"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Add Section Image</span>
                    </button>
                  </div>
                )}
              </div>

              {/* Items Imagery Manager (for Services, Portfolio, Gallery, Testimonials) */}
              {selectedSection.items && selectedSection.items.length > 0 && (
                <div className="p-3.5 rounded-xl bg-neutral-950 border border-neutral-800 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-neutral-200 flex items-center gap-1.5">
                      <ImageIcon className="w-3.5 h-3.5 text-amber-400" />
                      <span>Card & Item Imagery ({selectedSection.items.length} items)</span>
                    </span>
                  </div>
                  <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                    {selectedSection.items.map((item, itIdx) => (
                      <div
                        key={item.id || itIdx}
                        className="p-2 rounded-lg bg-neutral-900 border border-neutral-800/80 flex items-center justify-between gap-2 text-xs"
                      >
                        <div className="flex items-center gap-2 overflow-hidden flex-1">
                          <div className="w-10 h-10 rounded overflow-hidden bg-neutral-950 border border-neutral-800 flex-shrink-0 relative">
                            {item.imageUrl ? (
                              <img
                                src={item.imageUrl}
                                alt={item.title}
                                className="w-full h-full object-cover"
                                loading="lazy"
                              />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center text-neutral-600">
                                <ImageIcon className="w-4 h-4" />
                              </div>
                            )}
                          </div>
                          <div className="truncate flex-1">
                            <span className="font-semibold text-neutral-200 block truncate">{item.title}</span>
                            <span className="text-[10px] text-neutral-500 font-mono">
                              {item.imageUrl ? (item.imageOrigin?.replace('_', ' ') || 'Image assigned') : 'No image'}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-1.5 flex-shrink-0">
                          <button
                            type="button"
                            onClick={() => {
                              setEditingItemIndex(itIdx);
                              setIsImageStudioOpen(true);
                            }}
                            className="px-2 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-amber-400 text-[10px] font-semibold border border-amber-500/20"
                          >
                            {item.imageUrl ? 'Edit' : '+ Add'}
                          </button>
                          {item.imageUrl && (
                            <button
                              type="button"
                              onClick={() => {
                                const updatedItems = [...selectedSection.items!];
                                updatedItems[itIdx] = {
                                  ...updatedItems[itIdx],
                                  imageUrl: undefined,
                                  imageAlt: undefined,
                                  imageOrigin: undefined,
                                };
                                handleUpdateSection({
                                  ...selectedSection,
                                  items: updatedItems,
                                });
                              }}
                              className="p-1 rounded text-neutral-500 hover:text-rose-400"
                              title="Remove image"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: BRAND & COLORS */}
          {activeTab === 'style' && (
            <div className="flex-1 overflow-y-auto max-h-[50vh] md:max-h-none p-4 space-y-4 text-xs">
              <span className="font-bold uppercase tracking-wider text-amber-400 block pb-2 border-b border-neutral-800">
                Client Brand System
              </span>

              <div>
                <label className="block text-neutral-400 font-semibold mb-1">Primary Color</label>
                <div className="flex gap-2 items-center">
                  <input
                    type="color"
                    value={activeProject.brand.primaryColor}
                    onChange={(e) =>
                      updateProject({
                        ...activeProject,
                        brand: { ...activeProject.brand, primaryColor: e.target.value },
                      })
                    }
                    className="w-9 h-9 rounded border border-neutral-700 bg-neutral-950 cursor-pointer"
                  />
                  <input
                    type="text"
                    value={activeProject.brand.primaryColor}
                    onChange={(e) =>
                      updateProject({
                        ...activeProject,
                        brand: { ...activeProject.brand, primaryColor: e.target.value },
                      })
                    }
                    className="flex-1 px-3 py-1.5 rounded bg-neutral-950 border border-neutral-800 font-mono text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-neutral-400 font-semibold mb-1">Accent Color</label>
                <div className="flex gap-2 items-center">
                  <input
                    type="color"
                    value={activeProject.brand.accentColor}
                    onChange={(e) =>
                      updateProject({
                        ...activeProject,
                        brand: { ...activeProject.brand, accentColor: e.target.value },
                      })
                    }
                    className="w-9 h-9 rounded border border-neutral-700 bg-neutral-950 cursor-pointer"
                  />
                  <input
                    type="text"
                    value={activeProject.brand.accentColor}
                    onChange={(e) =>
                      updateProject({
                        ...activeProject,
                        brand: { ...activeProject.brand, accentColor: e.target.value },
                      })
                    }
                    className="flex-1 px-3 py-1.5 rounded bg-neutral-950 border border-neutral-800 font-mono text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-neutral-400 font-semibold mb-1">Typography Pairing</label>
                <select
                  value={activeProject.brand.fontPairing}
                  onChange={(e) =>
                    updateProject({
                      ...activeProject,
                      brand: { ...activeProject.brand, fontPairing: e.target.value as any },
                    })
                  }
                  className="w-full px-3 py-2 rounded bg-neutral-950 border border-neutral-800 text-white"
                >
                  <option value="modern">Plus Jakarta Sans (Modern & Clean)</option>
                  <option value="luxury">Cinzel Serif (High Luxury & Heritage)</option>
                  <option value="editorial">Playfair Display (Editorial Elegance)</option>
                  <option value="clean">Inter (Clean Corporate & SaaS)</option>
                  <option value="technical">JetBrains Mono (Technical / Developer)</option>
                </select>
              </div>

              <div>
                <label className="block text-neutral-400 font-semibold mb-1">Geometry & Corner Radius</label>
                <select
                  value={activeProject.brand.borderRadius}
                  onChange={(e) =>
                    updateProject({
                      ...activeProject,
                      brand: { ...activeProject.brand, borderRadius: e.target.value as any },
                    })
                  }
                  className="w-full px-3 py-2 rounded bg-neutral-950 border border-neutral-800 text-white"
                >
                  <option value="none">Square (0px)</option>
                  <option value="subtle">Subtle (6-8px)</option>
                  <option value="rounded">Rounded Pill (16px+)</option>
                </select>
              </div>

              <div>
                <label className="block text-neutral-400 font-semibold mb-1">Website Base Canvas</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() =>
                      updateProject({
                        ...activeProject,
                        brand: { ...activeProject.brand, lightMode: true },
                      })
                    }
                    className={`py-2 rounded border text-center ${
                      activeProject.brand.lightMode
                        ? 'border-amber-400 text-amber-400 bg-amber-500/10 font-bold'
                        : 'border-neutral-800 text-neutral-400 bg-neutral-950'
                    }`}
                  >
                    Light Canvas
                  </button>
                  <button
                    onClick={() =>
                      updateProject({
                        ...activeProject,
                        brand: { ...activeProject.brand, lightMode: false },
                      })
                    }
                    className={`py-2 rounded border text-center ${
                      !activeProject.brand.lightMode
                        ? 'border-amber-400 text-amber-400 bg-amber-500/10 font-bold'
                        : 'border-neutral-800 text-neutral-400 bg-neutral-950'
                    }`}
                  >
                    Dark Canvas
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: SEO & META */}
          {activeTab === 'seo' && (
            <div className="flex-1 overflow-y-auto max-h-[50vh] md:max-h-none p-4 space-y-4 text-xs">
              <span className="font-bold uppercase tracking-wider text-amber-400 block pb-2 border-b border-neutral-800">
                SEO & Search Performance
              </span>

              <div>
                <label className="block text-neutral-400 font-semibold mb-1">
                  Page Title ({(currentPage.seo?.pageTitle || '').length}/70 chars)
                </label>
                <input
                  type="text"
                  value={currentPage.seo?.pageTitle || ''}
                  onChange={(e) => {
                    const updatedPages = activeProject.pages.map((p) =>
                      p.id === currentPage.id ? { ...p, seo: { ...p.seo, pageTitle: e.target.value } } : p
                    );
                    updateProject({ ...activeProject, pages: updatedPages });
                  }}
                  className="w-full px-3 py-2 rounded bg-neutral-950 border border-neutral-800 text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block text-neutral-400 font-semibold mb-1">
                  Meta Description ({(currentPage.seo?.metaDescription || '').length}/160 chars)
                </label>
                <textarea
                  rows={3}
                  value={currentPage.seo?.metaDescription || ''}
                  onChange={(e) => {
                    const updatedPages = activeProject.pages.map((p) =>
                      p.id === currentPage.id ? { ...p, seo: { ...p.seo, metaDescription: e.target.value } } : p
                    );
                    updateProject({ ...activeProject, pages: updatedPages });
                  }}
                  className="w-full px-3 py-2 rounded bg-neutral-950 border border-neutral-800 text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block text-neutral-400 font-semibold mb-1">Canonical URL</label>
                <input
                  type="text"
                  value={currentPage.seo?.canonicalUrl || ''}
                  onChange={(e) => {
                    const updatedPages = activeProject.pages.map((p) =>
                      p.id === currentPage.id ? { ...p, seo: { ...p.seo, canonicalUrl: e.target.value } } : p
                    );
                    updateProject({ ...activeProject, pages: updatedPages });
                  }}
                  className="w-full px-3 py-2 rounded bg-neutral-950 border border-neutral-800 text-white focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-neutral-400 font-semibold mb-1">Local Business Category</label>
                <input
                  type="text"
                  value={currentPage.seo?.businessCategory || ''}
                  onChange={(e) => {
                    const updatedPages = activeProject.pages.map((p) =>
                      p.id === currentPage.id ? { ...p, seo: { ...p.seo, businessCategory: e.target.value } } : p
                    );
                    updateProject({ ...activeProject, pages: updatedPages });
                  }}
                  className="w-full px-3 py-2 rounded bg-neutral-950 border border-neutral-800 text-white focus:outline-none"
                />
              </div>
            </div>
          )}

          {/* TAB 5: AI ASSISTANT DRAWER */}
          {activeTab === 'ai' && (
            <div className="flex-1 overflow-y-auto max-h-[50vh] md:max-h-none p-4 space-y-4 text-xs">
              <div>
                <span className="font-bold uppercase tracking-wider text-amber-400 block mb-1">
                  AI Design & Copy Assistant
                </span>
                <p className="text-[11px] text-neutral-400">
                  Powered by {aiStatus.configured ? 'Gemini 3.8 Flash' : 'Studio Engine'}. Give real directives to update copy, layout, colors, and conversion paths.
                </p>
              </div>

              {aiFeedback && (
                <div className="p-3 rounded-lg bg-neutral-950 border border-amber-500/40 text-amber-300 text-xs">
                  <div className="font-bold mb-1 flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5" /> AI Update Summary:
                  </div>
                  <div>{aiFeedback}</div>
                </div>
              )}

              <div>
                <label className="block text-neutral-400 font-semibold mb-1">What would you like to improve?</label>
                <textarea
                  rows={3}
                  value={aiPrompt}
                  onChange={(e) => setAiPrompt(e.target.value)}
                  placeholder="e.g. Make the hero more premium and add a WhatsApp CTA button..."
                  className="w-full px-3 py-2 rounded bg-neutral-950 border border-neutral-800 text-white placeholder-neutral-600 focus:outline-none focus:border-amber-500"
                />
              </div>

              <button
                onClick={() => handleExecuteAiCommand()}
                disabled={isAiProcessing || !aiPrompt.trim()}
                className="w-full py-2.5 rounded bg-amber-400 hover:bg-amber-300 text-neutral-950 font-bold flex items-center justify-center gap-1.5 shadow transition-all active:scale-95 disabled:opacity-50"
              >
                {isAiProcessing ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-neutral-950 border-t-transparent rounded-full animate-spin" />
                    <span>Applying Enhancements...</span>
                  </>
                ) : (
                  <>
                    <Wand2 className="w-3.5 h-3.5" />
                    <span>Run AI Modification</span>
                  </>
                )}
              </button>

              {/* Quick AI Presets */}
              <div className="space-y-1.5 pt-2 border-t border-neutral-800">
                <span className="block text-[10px] uppercase tracking-wider text-neutral-500 font-semibold">
                  Quick AI Actions (One-Click)
                </span>
                {[
                  'Make the hero more premium and authoritative.',
                  'Make this website look more luxurious.',
                  'Add a direct WhatsApp CTA button.',
                  'Rewrite the hero and services for a high-end cosmetic clinic.',
                  'Add an elegant 3-step client execution process section.',
                  'Reduce the amount of text and make bullet points punchier.',
                ].map((preset, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleExecuteAiCommand(preset)}
                    disabled={isAiProcessing}
                    className="w-full text-left p-2 rounded bg-neutral-950 border border-neutral-800/80 hover:border-amber-500/50 text-[11px] text-neutral-300 hover:text-white transition-all flex items-center justify-between group"
                  >
                    <span className="truncate">{preset}</span>
                    <ChevronRight className="w-3 h-3 text-neutral-500 group-hover:text-amber-400 flex-shrink-0" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* TAB 6: QUALITY AUDIT REPORT */}
          {activeTab === 'audit' && (
            <div className="flex-1 overflow-y-auto max-h-[50vh] md:max-h-none p-4 space-y-4 text-xs">
              <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
                <span className="font-bold uppercase tracking-wider text-amber-400">
                  Website Quality Audit
                </span>
                <span className="text-[10px] text-neutral-500 font-mono">Real-time heuristics</span>
              </div>

              {/* Overall Score Dial */}
              <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 text-center">
                <div className="text-3xl font-extrabold text-amber-400 font-mono mb-1">
                  {qualityReport.overallScore}%
                </div>
                <div className="text-[11px] text-neutral-400 font-medium">Production Readiness Score</div>
              </div>

              {/* Category Breakdown */}
              <div className="grid grid-cols-2 gap-2 text-center">
                <div className="p-2.5 rounded bg-neutral-950 border border-neutral-800">
                  <div className="text-[10px] text-neutral-500">SEO</div>
                  <div className="text-base font-bold text-white font-mono">{qualityReport.seoScore}%</div>
                </div>
                <div className="p-2.5 rounded bg-neutral-950 border border-neutral-800">
                  <div className="text-[10px] text-neutral-500">Conversion</div>
                  <div className="text-base font-bold text-white font-mono">{qualityReport.conversionScore}%</div>
                </div>
                <div className="p-2.5 rounded bg-neutral-950 border border-neutral-800">
                  <div className="text-[10px] text-neutral-500">Accessibility</div>
                  <div className="text-base font-bold text-white font-mono">{qualityReport.accessibilityScore}%</div>
                </div>
                <div className="p-2.5 rounded bg-neutral-950 border border-neutral-800">
                  <div className="text-[10px] text-neutral-500">Mobile</div>
                  <div className="text-base font-bold text-white font-mono">{qualityReport.mobileScore}%</div>
                </div>
              </div>

              {/* Detailed Checks */}
              <div className="space-y-2 pt-2">
                <span className="block text-[10px] uppercase tracking-wider text-neutral-400 font-semibold">
                  Audited Checkpoints ({qualityReport.checks.length})
                </span>
                {qualityReport.checks.map((chk) => (
                  <div key={chk.id} className="p-2.5 rounded bg-neutral-950 border border-neutral-800/80 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-neutral-200">{chk.title}</span>
                      <span
                        className={`text-[10px] px-1.5 py-0.5 rounded font-mono uppercase ${
                          chk.status === 'pass'
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                            : chk.status === 'warning'
                            ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                            : chk.status === 'fail'
                            ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                            : 'bg-neutral-800 text-neutral-400'
                        }`}
                      >
                        {chk.status === 'not_checked' ? 'Not Checked' : chk.status}
                      </span>
                    </div>
                    <p className="text-[11px] text-neutral-400 leading-relaxed">{chk.description}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
          </>
        )}

        </div>

        {/* RIGHT/BOTTOM AREA: PAGE TABS & PREVIEW CANVAS */}
        <div className="flex-1 flex flex-col min-w-0 w-full bg-neutral-950 md:h-full md:overflow-hidden">
          {/* Top Page Selector Bar */}
          <div className="h-11 border-b border-neutral-800 bg-neutral-900/80 backdrop-blur px-3 sm:px-4 flex items-center justify-between flex-shrink-0 sticky top-16 md:top-0 z-20">
            {sidebarCollapsed && (
              <button
                type="button"
                onClick={() => setSidebarCollapsed(false)}
                className="md:hidden mr-1.5 px-2 py-1 rounded bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/20 text-[11px] font-bold flex items-center gap-1 flex-shrink-0"
                title="Expand edit controls"
              >
                <Sliders className="w-3 h-3" />
                <span>Controls</span>
              </button>
            )}
            <div className="flex items-center gap-1.5 sm:gap-2 overflow-x-auto py-1 flex-1 min-w-0 no-scrollbar">
              <span className="text-[11px] font-mono uppercase text-neutral-500 flex items-center gap-1 mr-1 flex-shrink-0">
                <Layers className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden sm:inline">Pages:</span>
              </span>
              {pages.map((p) => {
                const isCur = p.id === activePageId;
                return (
                  <div key={p.id} className="flex items-center group flex-shrink-0">
                    <button
                      type="button"
                      onClick={() => {
                        setActivePageId(p.id);
                        setSelectedSectionId(p.sections[0]?.id || null);
                      }}
                      className={`px-3 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                        isCur
                          ? 'bg-amber-500 text-neutral-950 font-bold shadow-sm'
                          : 'bg-neutral-950 text-neutral-400 hover:text-white border border-neutral-800 hover:border-neutral-700'
                      }`}
                    >
                      <span>{p.title}</span>
                      <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                        isCur ? 'bg-neutral-950/20 text-neutral-950 font-bold' : 'bg-neutral-800 text-neutral-400'
                      }`}>
                        {p.sections?.length || 0}
                      </span>
                    </button>
                    {!p.isHome && (
                      <button
                        type="button"
                        onClick={() => handleDeletePage(p.id)}
                        className="p-1 text-neutral-600 hover:text-rose-400 opacity-0 group-hover:opacity-100 transition-opacity ml-0.5"
                        title={`Delete ${p.title}`}
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                );
              })}
              <button
                type="button"
                onClick={() => setIsNewPageModalOpen(true)}
                className="px-2.5 py-1 rounded-lg bg-neutral-950 border border-dashed border-neutral-700 hover:border-amber-400 text-neutral-400 hover:text-amber-400 text-xs font-semibold flex items-center gap-1 transition-colors whitespace-nowrap flex-shrink-0"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Page</span>
              </button>
            </div>

            <div className="flex items-center gap-2 text-xs text-neutral-400 flex-shrink-0 ml-2">
              {/* CLEAR PREVIEW TOOLBAR: [Desktop] [Tablet] [Mobile] (hidden on mobile, device is phone) */}
              <div className="hidden sm:flex items-center gap-1 bg-neutral-950 p-1 rounded-lg border border-neutral-800">
                <button
                  type="button"
                  onClick={() => setDevice('desktop')}
                  className={`px-2 py-1 rounded text-xs font-semibold flex items-center gap-1 transition-all ${
                    device === 'desktop'
                      ? 'bg-amber-500 text-neutral-950 shadow-sm font-bold'
                      : 'text-neutral-400 hover:text-white'
                  }`}
                  title="Desktop View"
                >
                  <Monitor className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Desktop</span>
                </button>
                <button
                  type="button"
                  onClick={() => setDevice('tablet')}
                  className={`px-2 py-1 rounded text-xs font-semibold flex items-center gap-1 transition-all ${
                    device === 'tablet'
                      ? 'bg-amber-500 text-neutral-950 shadow-sm font-bold'
                      : 'text-neutral-400 hover:text-white'
                  }`}
                  title="Tablet 768px"
                >
                  <Tablet className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Tablet</span>
                </button>
                <button
                  type="button"
                  onClick={() => setDevice('mobile')}
                  className={`px-2 py-1 rounded text-xs font-semibold flex items-center gap-1 transition-all ${
                    device === 'mobile'
                      ? 'bg-amber-500 text-neutral-950 shadow-sm font-bold'
                      : 'text-neutral-400 hover:text-white'
                  }`}
                  title="Mobile 390px"
                >
                  <Smartphone className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Mobile</span>
                </button>
              </div>

              {/* Fullscreen presentation button */}
              <button
                type="button"
                onClick={() => setClientPreviewOpen(true)}
                className="px-2 py-1 rounded text-xs font-semibold flex items-center gap-1 bg-neutral-900 border border-neutral-700 hover:border-amber-400 text-amber-400 transition-all hover:bg-neutral-800"
                title="Full-Screen Presentation Mode"
              >
                <Maximize2 className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Fullscreen</span>
              </button>

              <button
                type="button"
                onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
                className="hidden lg:flex items-center gap-1 px-2 py-1 rounded bg-neutral-950 border border-neutral-800 hover:border-neutral-700 text-neutral-400 hover:text-neutral-200 text-xs"
                title={sidebarCollapsed ? 'Expand editing panel' : 'Collapse editing panel for full-width canvas'}
              >
                {sidebarCollapsed ? <PanelLeftOpen className="w-3.5 h-3.5" /> : <PanelLeftClose className="w-3.5 h-3.5" />}
                <span className="text-[11px]">{sidebarCollapsed ? 'Controls' : 'Full Canvas'}</span>
              </button>
            </div>
          </div>

          {/* PREVIEW CANVAS CONTAINER WITH WORKING NATURAL VERTICAL SCROLL */}
          <div className="flex-1 min-w-0 bg-neutral-950 md:overflow-y-auto overflow-x-hidden p-0 sm:p-4 lg:p-6 scroll-smooth flex flex-col w-full">
            {/* MOBILE VIEWPORT (<= 768px): FULL USABLE WIDTH, REAL PHONE-SIZED WEBSITE PREVIEW */}
            <div className="block md:hidden w-full bg-white text-neutral-900 shadow-xl transition-all flex flex-col min-h-screen">
              <ClientWebsiteRenderer
                project={activeProject}
                activePageId={activePageId}
                onNavigatePage={(pId) => {
                  setActivePageId(pId);
                  const target = pages.find((p) => p.id === pId);
                  if (target) setSelectedSectionId(target.sections[0]?.id || null);
                }}
                onSectionClick={(secId) => {
                  setSelectedSectionId(secId);
                  setEditingItemIndex(null);
                  if (editorMode === 'visual') setActiveTab('inspector');
                }}
                onImageClick={(secId, itemIdx) => {
                  setSelectedSectionId(secId);
                  if (typeof itemIdx === 'number') setEditingItemIndex(itemIdx);
                  else setEditingItemIndex(null);
                  setIsImageStudioOpen(true);
                }}
                selectedSectionId={selectedSectionId}
              />
            </div>

            {/* DESKTOP & TABLET VIEWPORT (> 768px): PRESERVED SIMULATOR FRAMES */}
            <div className="hidden md:flex flex-col flex-1 w-full">
              {device === 'desktop' ? (
                <div className="w-full max-w-6xl mx-auto bg-white text-neutral-900 rounded-xl shadow-2xl border border-neutral-800 transition-all flex flex-col min-h-full">
                  <ClientWebsiteRenderer
                    project={activeProject}
                    activePageId={activePageId}
                    onNavigatePage={(pId) => {
                      setActivePageId(pId);
                      const target = pages.find((p) => p.id === pId);
                      if (target) setSelectedSectionId(target.sections[0]?.id || null);
                    }}
                    onSectionClick={(secId) => {
                      setSelectedSectionId(secId);
                      setEditingItemIndex(null);
                      if (editorMode === 'visual') setActiveTab('inspector');
                    }}
                    onImageClick={(secId, itemIdx) => {
                      setSelectedSectionId(secId);
                      if (typeof itemIdx === 'number') setEditingItemIndex(itemIdx);
                      else setEditingItemIndex(null);
                      setIsImageStudioOpen(true);
                    }}
                    selectedSectionId={selectedSectionId}
                  />
                </div>
              ) : device === 'tablet' ? (
                <div className="w-full max-w-[768px] mx-auto my-2 sm:my-4 rounded-2xl border-4 border-neutral-800 shadow-2xl bg-white text-neutral-900 transition-all flex flex-col overflow-hidden">
                  <div className="h-6 bg-neutral-900 flex items-center justify-center flex-shrink-0 border-b border-neutral-800">
                    <div className="w-2.5 h-2.5 rounded-full bg-neutral-800 border border-neutral-700" />
                  </div>
                  <ClientWebsiteRenderer
                    project={activeProject}
                    activePageId={activePageId}
                    onNavigatePage={(pId) => {
                      setActivePageId(pId);
                      const target = pages.find((p) => p.id === pId);
                      if (target) setSelectedSectionId(target.sections[0]?.id || null);
                    }}
                    onSectionClick={(secId) => {
                      setSelectedSectionId(secId);
                      setEditingItemIndex(null);
                      if (editorMode === 'visual') setActiveTab('inspector');
                    }}
                    onImageClick={(secId, itemIdx) => {
                      setSelectedSectionId(secId);
                      if (typeof itemIdx === 'number') setEditingItemIndex(itemIdx);
                      else setEditingItemIndex(null);
                      setIsImageStudioOpen(true);
                    }}
                    selectedSectionId={selectedSectionId}
                  />
                </div>
              ) : (
                <div className="w-full max-w-[420px] mx-auto my-2 sm:my-4 rounded-2xl sm:rounded-3xl border-4 sm:border-8 border-neutral-800 shadow-2xl bg-white text-neutral-900 transition-all flex flex-col overflow-hidden">
                  <div className="h-7 bg-neutral-900 flex items-center justify-center flex-shrink-0 border-b border-neutral-800">
                    <div className="w-24 h-3 rounded-full bg-neutral-800 flex items-center justify-center">
                      <div className="w-2 h-2 rounded-full bg-neutral-950 ml-auto mr-2" />
                    </div>
                  </div>
                  <ClientWebsiteRenderer
                    project={activeProject}
                    activePageId={activePageId}
                    onNavigatePage={(pId) => {
                      setActivePageId(pId);
                      const target = pages.find((p) => p.id === pId);
                      if (target) setSelectedSectionId(target.sections[0]?.id || null);
                    }}
                    onSectionClick={(secId) => {
                      setSelectedSectionId(secId);
                      setEditingItemIndex(null);
                      if (editorMode === 'visual') setActiveTab('inspector');
                    }}
                    onImageClick={(secId, itemIdx) => {
                      setSelectedSectionId(secId);
                      if (typeof itemIdx === 'number') setEditingItemIndex(itemIdx);
                      else setEditingItemIndex(null);
                      setIsImageStudioOpen(true);
                    }}
                    selectedSectionId={selectedSectionId}
                  />
                </div>
              )}
            </div>
          </div>
        </div>

      </div>

      {/* FULL-SCREEN CLIENT PRESENTATION PREVIEW MODAL */}
      {clientPreviewOpen && (
        <div className="fixed inset-0 z-50 bg-neutral-950 flex flex-col animate-in fade-in duration-200">
          {/* Presentation Header Bar */}
          <div className="h-14 border-b border-neutral-800 bg-neutral-900/95 backdrop-blur px-3 sm:px-4 flex items-center justify-between z-30 flex-shrink-0 gap-2 overflow-x-auto">
            <div className="flex items-center gap-3 flex-shrink-0">
              <button
                type="button"
                onClick={() => setClientPreviewOpen(false)}
                className="px-3.5 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-neutral-950 font-extrabold text-xs flex items-center gap-1.5 shadow-md shadow-amber-500/20 active:scale-95 transition-all"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Back to Editor</span>
              </button>
              <span className="hidden md:inline text-neutral-700">|</span>
              <span className="hidden md:inline text-xs font-bold text-neutral-200 truncate max-w-[200px]">
                {activeProject.business.name}
              </span>
            </div>

            {/* Presentation Page Navigation */}
            <div className="flex items-center gap-1 bg-neutral-950 p-1 rounded-lg border border-neutral-800 overflow-x-auto">
              {pages.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => setActivePageId(p.id)}
                  className={`px-3 py-1 rounded text-xs font-semibold whitespace-nowrap transition-all ${
                    p.id === activePageId
                      ? 'bg-neutral-800 text-amber-400 shadow-sm'
                      : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  {p.title}
                </button>
              ))}
            </div>

            {/* Viewport switchers & Share */}
            <div className="flex items-center gap-2 flex-shrink-0">
              <div className="hidden sm:flex items-center gap-1 bg-neutral-950 p-1 rounded-lg border border-neutral-800">
                <button
                  onClick={() => setDevice('desktop')}
                  className={`p-1.5 rounded text-xs flex items-center gap-1 ${device === 'desktop' ? 'bg-neutral-800 text-amber-400 font-bold' : 'text-neutral-400 hover:text-white'}`}
                  title="Desktop View"
                >
                  <Monitor className="w-3.5 h-3.5" />
                  <span className="hidden lg:inline">Desktop</span>
                </button>
                <button
                  onClick={() => setDevice('tablet')}
                  className={`p-1.5 rounded text-xs flex items-center gap-1 ${device === 'tablet' ? 'bg-neutral-800 text-amber-400 font-bold' : 'text-neutral-400 hover:text-white'}`}
                  title="Tablet View"
                >
                  <Tablet className="w-3.5 h-3.5" />
                  <span className="hidden lg:inline">Tablet</span>
                </button>
                <button
                  onClick={() => setDevice('mobile')}
                  className={`p-1.5 rounded text-xs flex items-center gap-1 ${device === 'mobile' ? 'bg-neutral-800 text-amber-400 font-bold' : 'text-neutral-400 hover:text-white'}`}
                  title="Mobile View"
                >
                  <Smartphone className="w-3.5 h-3.5" />
                  <span className="hidden lg:inline">Mobile</span>
                </button>
              </div>

              <button
                type="button"
                onClick={() => setIsShareModalOpen(true)}
                className="px-3 py-1.5 rounded-lg bg-neutral-950 border border-neutral-800 hover:border-neutral-700 text-amber-400 text-xs font-semibold flex items-center gap-1.5 transition-colors"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span className="hidden md:inline">Share with Client</span>
              </button>

              <button
                type="button"
                onClick={() => setClientPreviewOpen(false)}
                className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
                title="Close Presentation Mode"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Presentation Viewport */}
          <div className="flex-1 bg-neutral-950 overflow-y-auto overflow-x-hidden p-0 sm:p-4">
            <div className={`transition-all bg-white text-neutral-900 shadow-2xl ${
              device === 'desktop'
                ? 'w-full min-h-full mx-auto'
                : device === 'tablet'
                ? 'w-full max-w-[768px] mx-auto my-4 rounded-2xl border-4 border-neutral-800 overflow-hidden flex flex-col'
                : 'w-full max-w-[420px] mx-auto my-4 rounded-3xl border-8 border-neutral-800 overflow-hidden flex flex-col'
            }`}>
              <ClientWebsiteRenderer
                project={activeProject}
                activePageId={activePageId}
                onNavigatePage={(pId) => setActivePageId(pId)}
                interactive={false}
              />
            </div>
          </div>
        </div>
      )}

      {/* SHARE WITH CLIENT MODAL */}
      {isShareModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-neutral-900 border border-neutral-800 rounded-2xl max-w-lg w-full p-6 space-y-5 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <div className="flex items-center gap-2 text-amber-400 font-bold text-base">
                <Share2 className="w-5 h-5" />
                <span>Share Website With Client</span>
              </div>
              <button
                onClick={() => setIsShareModalOpen(false)}
                className="text-neutral-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-neutral-400 leading-relaxed">
              Provide this public presentation link to <strong className="text-white">{activeProject.clientName || activeProject.business.name}</strong>. The client will see a clean, interactive preview with working navigation across all pages and 24/7 AI chatbot, without any builder editing controls.
            </p>

            {/* Public Link Box */}
            <div className="p-3 bg-neutral-950 rounded-xl border border-neutral-800 space-y-2">
              <span className="text-[10px] font-mono uppercase text-neutral-500">Live Client Link</span>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  readOnly
                  value={activeProject.deployment.deploymentUrl || `https://${activeProject.id.slice(0, 16)}.empire-preview.app`}
                  className="flex-1 bg-transparent text-xs text-amber-300 font-mono outline-none select-all"
                />
                <button
                  type="button"
                  onClick={() => {
                    const link = activeProject.deployment.deploymentUrl || `https://${activeProject.id.slice(0, 16)}.empire-preview.app`;
                    navigator.clipboard.writeText(link);
                    setCopiedShareLink(true);
                    setTimeout(() => setCopiedShareLink(false), 2000);
                  }}
                  className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs flex items-center gap-1.5 transition-colors"
                >
                  {copiedShareLink ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedShareLink ? 'Copied!' : 'Copy'}</span>
                </button>
              </div>
            </div>

            {/* Quick Share Actions */}
            <div className="grid grid-cols-2 gap-3 text-xs">
              <a
                href={`https://wa.me/?text=${encodeURIComponent(`Hello! Here is the live presentation preview of your new website for ${activeProject.business.name}: ${activeProject.deployment.deploymentUrl || `https://${activeProject.id.slice(0, 16)}.empire-preview.app`}`)}`}
                target="_blank"
                rel="noreferrer"
                className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 hover:bg-emerald-500/20 font-semibold flex items-center justify-center gap-2 transition-all"
              >
                <Phone className="w-4 h-4" />
                <span>Send on WhatsApp</span>
              </a>
              <button
                type="button"
                onClick={() => {
                  setIsShareModalOpen(false);
                  setClientPreviewOpen(true);
                }}
                className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 hover:bg-amber-500/20 font-semibold flex items-center justify-center gap-2 transition-all"
              >
                <Eye className="w-4 h-4" />
                <span>Test Client View</span>
              </button>
            </div>

            {/* Connect Client Domain Button */}
            <div className="pt-3 border-t border-neutral-800 flex items-center justify-between">
              <span className="text-[11px] text-neutral-500">Ready for custom domain?</span>
              <button
                type="button"
                onClick={() => {
                  setIsShareModalOpen(false);
                  setActiveView('deployment');
                }}
                className="text-xs text-amber-400 hover:underline font-semibold flex items-center gap-1"
              >
                <Globe className="w-3.5 h-3.5" />
                <span>Connect Custom Domain →</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* DEPLOY CONFIRMATION MODAL */}
      {isDeployModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-neutral-900 border border-neutral-800 rounded-2xl max-w-lg w-full p-6 space-y-5 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <div className="flex items-center gap-2 text-emerald-400 font-bold text-base">
                <Check className="w-5 h-5" />
                <span>Website Deployed Successfully!</span>
              </div>
              <button
                onClick={() => setIsDeployModalOpen(false)}
                className="text-neutral-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-neutral-300 leading-relaxed">
              Your website for <strong className="text-white">{activeProject.business.name}</strong> is now live on the Money Making Empire edge staging network with SSL/HTTPS encryption active.
            </p>

            <div className="p-3 bg-neutral-950 rounded-xl border border-neutral-800 space-y-2">
              <span className="text-[10px] font-mono uppercase text-neutral-500">Live Staging URL</span>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  readOnly
                  value={activeProject.deployment.deploymentUrl}
                  className="flex-1 bg-transparent text-xs text-emerald-400 font-mono outline-none select-all"
                />
                <button
                  type="button"
                  onClick={() => {
                    navigator.clipboard.writeText(activeProject.deployment.deploymentUrl);
                    setCopiedShareLink(true);
                    setTimeout(() => setCopiedShareLink(false), 2000);
                  }}
                  className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 transition-colors"
                >
                  {copiedShareLink ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedShareLink ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2">
              <button
                type="button"
                onClick={() => {
                  setIsDeployModalOpen(false);
                  setClientPreviewOpen(true);
                }}
                className="px-4 py-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-semibold flex items-center gap-1.5"
              >
                <Eye className="w-3.5 h-3.5" />
                <span>View Live Site</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setIsDeployModalOpen(false);
                  setActiveView('deployment');
                }}
                className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-neutral-950 text-xs font-bold flex items-center gap-1.5"
              >
                <Globe className="w-3.5 h-3.5" />
                <span>Connect Client Domain</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ADD PAGE MODAL */}
      {isNewPageModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-neutral-900 border border-neutral-800 rounded-2xl max-w-md w-full p-6 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
              <div className="flex items-center gap-2 text-white font-bold text-base">
                <Plus className="w-5 h-5 text-amber-400" />
                <span>Add New Page</span>
              </div>
              <button
                onClick={() => setIsNewPageModalOpen(false)}
                className="text-neutral-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-neutral-300 font-semibold mb-1">Page Title</label>
                <input
                  type="text"
                  placeholder="e.g. Gallery, Pricing, Portfolio, Team"
                  value={newPageTitle}
                  onChange={(e) => {
                    setNewPageTitle(e.target.value);
                    if (!newPageSlug || newPageSlug === `/${newPageTitle.toLowerCase().replace(/[^a-z0-9]/g, '-')}`) {
                      setNewPageSlug(`/${e.target.value.toLowerCase().replace(/[^a-z0-9]/g, '-')}`);
                    }
                  }}
                  className="w-full px-3 py-2 rounded-lg bg-neutral-950 border border-neutral-800 text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block text-neutral-300 font-semibold mb-1">Page URL Slug</label>
                <input
                  type="text"
                  placeholder="/gallery"
                  value={newPageSlug}
                  onChange={(e) => setNewPageSlug(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-neutral-950 border border-neutral-800 text-white font-mono focus:outline-none focus:border-amber-500"
                />
              </div>

              {/* Quick Preset Buttons */}
              <div>
                <span className="block text-neutral-500 font-semibold mb-1.5">Common Page Presets:</span>
                <div className="flex flex-wrap gap-1.5">
                  {['Gallery', 'Pricing', 'Team', 'Portfolio', 'Case Studies', 'FAQ'].map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => {
                        setNewPageTitle(preset);
                        setNewPageSlug(`/${preset.toLowerCase().replace(/[^a-z0-9]/g, '-')}`);
                      }}
                      className="px-2 py-1 rounded bg-neutral-950 border border-neutral-800 hover:border-neutral-700 text-neutral-300 hover:text-white text-[11px]"
                    >
                      +{preset}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-neutral-800">
              <button
                type="button"
                onClick={() => setIsNewPageModalOpen(false)}
                className="px-3 py-2 rounded-lg text-neutral-400 hover:text-white text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={!newPageTitle.trim()}
                onClick={handleAddPage}
                className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-neutral-950 text-xs font-bold disabled:opacity-50 transition-colors"
              >
                Create Page
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Image Studio Modal */}
      {selectedSection && (
        <ImageStudioModal
          isOpen={isImageStudioOpen}
          onClose={() => {
            setIsImageStudioOpen(false);
            setEditingItemIndex(null);
          }}
          currentImageUrl={
            editingItemIndex !== null && selectedSection.items?.[editingItemIndex]
              ? selectedSection.items[editingItemIndex].imageUrl
              : selectedSection.imageUrl
          }
          currentAltText={
            editingItemIndex !== null && selectedSection.items?.[editingItemIndex]
              ? selectedSection.items[editingItemIndex].imageAlt || selectedSection.items[editingItemIndex].title
              : selectedSection.imageAlt
          }
          currentOrigin={
            editingItemIndex !== null && selectedSection.items?.[editingItemIndex]
              ? selectedSection.items[editingItemIndex].imageOrigin
              : selectedSection.imageOrigin
          }
          currentAspectRatio={selectedSection.imageAspectRatio}
          currentFocalPoint={selectedSection.imageFocalPoint}
          isPlaceholder={
            editingItemIndex !== null && selectedSection.items?.[editingItemIndex]
              ? selectedSection.items[editingItemIndex].isPlaceholder
              : selectedSection.isImagePlaceholder
          }
          sectionTitle={
            editingItemIndex !== null && selectedSection.items?.[editingItemIndex]
              ? `${selectedSection.title} - ${selectedSection.items[editingItemIndex].title}`
              : selectedSection.title
          }
          sectionType={selectedSection.type}
          onApply={(data) => {
            if (editingItemIndex !== null && selectedSection.items) {
              const updatedItems = [...selectedSection.items];
              updatedItems[editingItemIndex] = {
                ...updatedItems[editingItemIndex],
                imageUrl: data.url,
                imageAlt: data.altText,
                imageOrigin: data.origin,
                isPlaceholder: data.isPlaceholder,
              };
              handleUpdateSection({
                ...selectedSection,
                items: updatedItems,
              });
              setEditingItemIndex(null);
            } else {
              handleUpdateSection({
                ...selectedSection,
                imageUrl: data.url,
                imageAlt: data.altText,
                imageOrigin: data.origin,
                imageAspectRatio: data.aspectRatio,
                imageFocalPoint: data.focalPoint,
                isImagePlaceholder: data.isPlaceholder,
              });
            }
          }}
        />
      )}

      {/* Version History Modal */}
      <VersionHistoryModal
        isOpen={isVersionModalOpen}
        onClose={() => setIsVersionModalOpen(false)}
        project={activeProject}
        onRestoreVersion={handleRestoreVersion}
      />
    </div>
  );
};
