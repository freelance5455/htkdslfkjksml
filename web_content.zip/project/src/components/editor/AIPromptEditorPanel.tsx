import React, { useState } from 'react';
import { 
  WebsiteProject, 
  WebsiteSection, 
  ProjectVersion 
} from '../../types/website';
import { aiProvider } from '../../services/aiProvider';
import { 
  Sparkles, 
  Wand2, 
  MessageSquare, 
  Send, 
  History, 
  RotateCcw, 
  Check, 
  AlertCircle, 
  Layers, 
  ChevronRight, 
  Sliders, 
  Bot, 
  User, 
  Palette, 
  Smartphone, 
  Plus, 
  ArrowRight,
  ShieldCheck,
  Undo2,
  Redo2,
  Clock
} from 'lucide-react';

interface AIPromptEditorPanelProps {
  project: WebsiteProject;
  activePageId?: string;
  selectedSection: WebsiteSection;
  selectedSectionId: string | null;
  onSelectSection: (id: string) => void;
  onUpdateProject: (updated: WebsiteProject, summary?: string) => void;
  onUndo: () => void;
  onRedo: () => void;
  canUndo: boolean;
  canRedo: boolean;
  onOpenVersionsModal: () => void;
}

export const AIPromptEditorPanel: React.FC<AIPromptEditorPanelProps> = ({
  project,
  activePageId,
  selectedSection,
  selectedSectionId,
  onSelectSection,
  onUpdateProject,
  onUndo,
  onRedo,
  canUndo,
  canRedo,
  onOpenVersionsModal,
}) => {
  // Input states
  const [sectionPrompt, setSectionPrompt] = useState('');
  const [chatMessage, setChatMessage] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [feedbackMessage, setFeedbackMessage] = useState<string | null>(null);

  const activePage = project.pages.find((p) => p.id === (activePageId || project.activePageId)) || project.pages.find((p) => p.isHome) || project.pages[0];
  const sections = activePage?.sections || [];

  // Section AI Editing Chips per user brief
  const SECTION_ACTION_CHIPS = [
    { label: 'Make more modern', prompt: 'Make this section more modern with cleaner whitespace and crisp typography' },
    { label: 'Change layout', prompt: 'Change the layout to an alternative high-converting variant' },
    { label: 'Rewrite copy', prompt: 'Rewrite the copy to be more punchy, authoritative, and direct' },
    { label: 'Add CTA', prompt: 'Add an action-oriented primary consultation CTA button' },
    { label: 'Change colors', prompt: 'Enhance this section with refined brand accent styling and subtle contrast' },
    { label: 'Improve mobile layout', prompt: 'Optimize the layout and content density specifically for mobile screens' },
    { label: 'Replace image', prompt: 'Select a more fitting high-resolution architectural image for this section' },
    { label: 'Add subtle animation', prompt: 'Configure subtle, restrained premium fade-in section transitions' },
  ];

  // Whole-Site AI Directives per user brief
  const GLOBAL_QUICK_ACTIONS = [
    'Make the hero more premium.',
    'Change the color palette to black and gold.',
    'Add a testimonials section.',
    'Make the buttons larger and punchier.',
    'Add a WhatsApp button.',
    'Make the website look more luxurious.',
    'Reduce the amount of text and animation.',
    'Add an appointment booking section.',
  ];

  // Handle Section-Specific AI Prompt
  const handleRefineSection = async (customCmd?: string) => {
    const cmd = customCmd || sectionPrompt;
    if (!cmd.trim() || !selectedSection) return;

    setIsProcessing(true);
    setFeedbackMessage(null);

    try {
      const result = await aiProvider.refineSection(cmd, selectedSection, project);
      
      // Update section inside project while preserving everything else
      const updatedSections = sections.map((s) => (s.id === selectedSection.id ? result.updatedSection : s));
      const updatedPages = project.pages.map((p) =>
        p.id === activePage.id ? { ...p, sections: updatedSections } : p
      );

      const clone: WebsiteProject = {
        ...project,
        pages: updatedPages,
        updatedAt: new Date().toISOString(),
      };

      onUpdateProject(clone, `AI refined ${selectedSection.type} section: "${cmd}"`);
      setFeedbackMessage(result.summary || `Updated ${selectedSection.type} section.`);
      if (!customCmd) setSectionPrompt('');
    } catch (err: any) {
      setFeedbackMessage(`Error: ${err.message || 'Section refinement failed'}`);
    } finally {
      setIsProcessing(false);
    }
  };

  // Handle Conversational Chat-Style Refinement
  const handleSendChatMessage = async (presetText?: string) => {
    const msg = presetText || chatMessage;
    if (!msg.trim()) return;

    setIsProcessing(true);
    setFeedbackMessage(null);

    try {
      const result = await aiProvider.chatRefine(
        msg,
        project,
        selectedSectionId || undefined,
        project.aiConversationHistory
      );

      // Append message to conversation history
      const newHistory = [
        ...(project.aiConversationHistory || []),
        {
          id: `usr-${Date.now()}`,
          role: 'user' as const,
          content: msg,
          timestamp: new Date().toISOString(),
        },
        {
          id: `ai-${Date.now()}`,
          role: 'assistant' as const,
          content: result.reply,
          timestamp: new Date().toISOString(),
          actionApplied: result.summary,
        },
      ];

      const finalizedProject: WebsiteProject = {
        ...result.updatedProject,
        aiConversationHistory: newHistory,
        updatedAt: new Date().toISOString(),
      };

      onUpdateProject(finalizedProject, result.summary);
      setFeedbackMessage(result.summary);
      if (!presetText) setChatMessage('');
    } catch (err: any) {
      setFeedbackMessage(`Error: ${err.message || 'AI chat refinement failed'}`);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="flex-1 overflow-y-auto max-h-[50vh] md:max-h-none p-3 sm:p-4 space-y-4 text-xs">
      
      {/* TOP UNDO / REDO / VERSION BAR */}
      <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={onUndo}
            disabled={!canUndo}
            title="Undo last change"
            className="p-1.5 rounded bg-neutral-950 border border-neutral-800 hover:border-neutral-700 text-neutral-300 disabled:opacity-30 disabled:cursor-not-allowed flex items-center gap-1 font-mono text-[11px]"
          >
            <Undo2 className="w-3.5 h-3.5" />
            <span>Undo</span>
          </button>
          <button
            type="button"
            onClick={onRedo}
            disabled={!canRedo}
            title="Redo change"
            className="p-1.5 rounded bg-neutral-950 border border-neutral-800 hover:border-neutral-700 text-neutral-300 disabled:opacity-30 disabled:cursor-not-allowed flex items-center gap-1 font-mono text-[11px]"
          >
            <Redo2 className="w-3.5 h-3.5" />
            <span>Redo</span>
          </button>
        </div>

        <button
          type="button"
          onClick={onOpenVersionsModal}
          className="px-2.5 py-1.5 rounded bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 text-amber-400 font-semibold flex items-center gap-1.5 text-[11px] transition-all"
        >
          <History className="w-3.5 h-3.5" />
          <span>Versions ({project.versionHistory?.length || 1})</span>
        </button>
      </div>

      {/* FEEDBACK BANNER */}
      {feedbackMessage && (
        <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/40 text-amber-300 text-xs flex items-start gap-2 animate-in fade-in duration-150">
          <Sparkles className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
          <div className="flex-1">
            <span className="font-bold block mb-0.5">AI Modification Summary:</span>
            <span>{feedbackMessage}</span>
          </div>
        </div>
      )}

      {/* 1. SELECTED SECTION AI EDITING PANEL */}
      <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 space-y-3 shadow-inner">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
            <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
              Selected Section Target
            </span>
          </div>
          <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-neutral-900 border border-neutral-800 text-neutral-300">
            {selectedSection?.type || 'hero'}
          </span>
        </div>

        {/* Section Quick Switcher */}
        <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-thin">
          {sections.map((sec, idx) => (
            <button
              key={sec.id}
              onClick={() => onSelectSection(sec.id)}
              className={`px-2.5 py-1 rounded text-[10px] font-semibold whitespace-nowrap transition-all border ${
                selectedSection?.id === sec.id
                  ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                  : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-white'
              }`}
            >
              0{idx + 1} {sec.type}
            </button>
          ))}
        </div>

        {/* Selected Section Information */}
        <div className="text-[11px] text-neutral-400 bg-neutral-900/60 p-2.5 rounded-lg border border-neutral-800/80">
          <div className="font-semibold text-neutral-200 truncate">{selectedSection?.title || 'Untitled Section'}</div>
          <div className="text-[10px] text-neutral-500 truncate mt-0.5">Layout: {selectedSection?.layoutVariant} · Items: {selectedSection?.items?.length || 0}</div>
        </div>

        {/* Section Action Chips */}
        <div>
          <span className="text-[10px] uppercase tracking-wider text-neutral-500 font-semibold block mb-1.5">
            Ask AI to edit this section:
          </span>
          <div className="flex flex-wrap gap-1.5">
            {SECTION_ACTION_CHIPS.map((chip, idx) => (
              <button
                key={idx}
                type="button"
                disabled={isProcessing}
                onClick={() => handleRefineSection(chip.prompt)}
                className="px-2.5 py-1 rounded-md bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 hover:border-amber-500/40 text-[10px] text-neutral-300 hover:text-amber-300 transition-all active:scale-95 disabled:opacity-40"
              >
                {chip.label}
              </button>
            ))}
          </div>
        </div>

        {/* Custom Section Prompt Input */}
        <div className="space-y-2 pt-1">
          <textarea
            rows={2}
            value={sectionPrompt}
            onChange={(e) => setSectionPrompt(e.target.value)}
            placeholder={`e.g. Make this ${selectedSection?.type} more premium with a gold accent border and punchier value proposition...`}
            className="w-full px-3 py-2 rounded-lg bg-neutral-900 border border-neutral-800 text-white placeholder-neutral-600 focus:outline-none focus:border-amber-500 text-xs"
          />
          <button
            type="button"
            disabled={isProcessing || !sectionPrompt.trim()}
            onClick={() => handleRefineSection()}
            className="w-full py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs flex items-center justify-center gap-1.5 shadow transition-all active:scale-95 disabled:opacity-40"
          >
            {isProcessing ? (
              <>
                <div className="w-3.5 h-3.5 border-2 border-neutral-950 border-t-transparent rounded-full animate-spin" />
                <span>Applying to Section...</span>
              </>
            ) : (
              <>
                <Wand2 className="w-3.5 h-3.5" />
                <span>Refine Selected Section</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* 2. CHAT-STYLE AI REFINEMENT CONVERSATION */}
      <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold uppercase tracking-wider text-neutral-300 flex items-center gap-1.5">
            <MessageSquare className="w-3.5 h-3.5 text-amber-400" />
            AI Design Conversation
          </span>
          <span className="text-[10px] text-neutral-500">Whole site or global styling</span>
        </div>

        {/* Conversation Message List */}
        <div className="max-h-48 overflow-y-auto space-y-2.5 p-2 rounded-lg bg-neutral-900/60 border border-neutral-800/80 scrollbar-thin">
          {(!project.aiConversationHistory || project.aiConversationHistory.length === 0) ? (
            <div className="text-center py-4 text-neutral-500 text-[11px]">
              No messages yet. Tell the AI what you want to improve, and it will apply the adjustments while preserving your structure.
            </div>
          ) : (
            project.aiConversationHistory.map((item, idx) => (
              <div
                key={item.id || idx}
                className={`p-2.5 rounded-lg text-xs ${
                  item.role === 'user'
                    ? 'bg-amber-500/10 border border-amber-500/20 text-neutral-200 ml-4'
                    : 'bg-neutral-900 border border-neutral-800 text-neutral-300 mr-4'
                }`}
              >
                <div className="flex items-center justify-between mb-1 text-[10px] font-mono text-neutral-500">
                  <span className="flex items-center gap-1 font-semibold text-neutral-400">
                    {item.role === 'user' ? <User className="w-3 h-3 text-amber-400" /> : <Bot className="w-3 h-3 text-emerald-400" />}
                    {item.role === 'user' ? 'You' : 'AI Architect'}
                  </span>
                  <span>{new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                </div>
                <div className="leading-relaxed whitespace-pre-wrap">{item.content}</div>
                {item.actionApplied && (
                  <div className="mt-1.5 pt-1 border-t border-neutral-800 text-[10px] text-amber-400/90 font-mono">
                    ✓ {item.actionApplied}
                  </div>
                )}
              </div>
            ))
          )}
        </div>

        {/* Quick Global Action Directives */}
        <div>
          <span className="text-[10px] uppercase tracking-wider text-neutral-500 font-semibold block mb-1.5">
            Quick Global Commands:
          </span>
          <div className="grid grid-cols-1 gap-1">
            {GLOBAL_QUICK_ACTIONS.map((action, idx) => (
              <button
                key={idx}
                type="button"
                disabled={isProcessing}
                onClick={() => handleSendChatMessage(action)}
                className="w-full text-left p-1.5 rounded bg-neutral-900 hover:bg-neutral-800/80 border border-neutral-800 text-[10px] text-neutral-300 hover:text-white flex items-center justify-between transition-colors"
              >
                <span className="truncate">{action}</span>
                <ChevronRight className="w-3 h-3 text-neutral-500 flex-shrink-0" />
              </button>
            ))}
          </div>
        </div>

        {/* Chat Input Field */}
        <div className="flex gap-2 pt-1">
          <input
            type="text"
            value={chatMessage}
            onChange={(e) => setChatMessage(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleSendChatMessage())}
            placeholder="e.g. Make the website feel more premium and increase button sizes..."
            className="flex-1 min-w-0 px-3 py-2 rounded-lg bg-neutral-900 border border-neutral-800 text-white placeholder-neutral-600 focus:outline-none focus:border-amber-500 text-xs"
          />
          <button
            type="button"
            disabled={isProcessing || !chatMessage.trim()}
            onClick={() => handleSendChatMessage()}
            className="px-4 py-2 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-neutral-950 font-bold rounded-lg flex items-center gap-1.5 transition-all shadow active:scale-95 disabled:opacity-40"
          >
            <Send className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
