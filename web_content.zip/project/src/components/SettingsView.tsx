import React from "react";
import {
  Moon,
  Sun,
  Volume2,
  VolumeX,
  Vibrate,
  ShieldCheck,
  DollarSign,
  Info,
  Smartphone,
  Trash2,
} from "lucide-react";
import { AppSettings } from "../types";

interface SettingsViewProps {
  settings: AppSettings;
  onUpdateSettings: (newSettings: Partial<AppSettings>) => void;
  onClearAllData: () => void;
}

const CURRENCY_OPTIONS = [
  { label: "None (Raw Numbers)", value: "" },
  { label: "USD ($)", value: "$" },
  { label: "EUR (€)", value: "€" },
  { label: "GBP (£)", value: "£" },
  { label: "INR (₹)", value: "₹" },
  { label: "JPY / CNY (¥)", value: "¥" },
  { label: "CAD ($)", value: "CA$" },
  { label: "AUD ($)", value: "A$" },
];

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  onUpdateSettings,
  onClearAllData,
}) => {
  return (
    <div
      id="settings-screen"
      className="flex flex-col h-full w-full max-w-lg mx-auto p-4 justify-between animate-in fade-in duration-200"
    >
      <div className="space-y-4 overflow-y-auto pr-1">
        {/* Header */}
        <div>
          <span className="text-xs font-bold tracking-wider uppercase text-emerald-600 dark:text-emerald-400">
            Preferences
          </span>
          <h2 className="text-xl sm:text-2xl font-black text-zinc-900 dark:text-zinc-100">
            Settings
          </h2>
        </div>

        {/* Appearance: Light / Dark Mode */}
        <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center text-zinc-700 dark:text-zinc-300">
                {settings.theme === "dark" ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
              </div>
              <div>
                <div className="text-sm font-bold text-zinc-900 dark:text-zinc-100">Appearance</div>
                <div className="text-xs text-zinc-500 dark:text-zinc-400">
                  Switch between Light and Dark interface
                </div>
              </div>
            </div>

            {/* Theme Toggle Buttons */}
            <div className="flex bg-zinc-100 dark:bg-zinc-800 p-1 rounded-xl">
              <button
                id="btn-theme-light"
                onClick={() => onUpdateSettings({ theme: "light" })}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  settings.theme === "light"
                    ? "bg-white text-zinc-900 shadow-xs"
                    : "text-zinc-500 dark:text-zinc-400 hover:text-zinc-900"
                }`}
              >
                <Sun className="w-3.5 h-3.5" />
                <span>Light</span>
              </button>
              <button
                id="btn-theme-dark"
                onClick={() => onUpdateSettings({ theme: "dark" })}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  settings.theme === "dark"
                    ? "bg-zinc-950 text-white shadow-xs"
                    : "text-zinc-500 dark:text-zinc-400 hover:text-zinc-200"
                }`}
              >
                <Moon className="w-3.5 h-3.5" />
                <span>Dark</span>
              </button>
            </div>
          </div>
        </div>

        {/* Currency Formatting */}
        <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center text-zinc-700 dark:text-zinc-300">
                <DollarSign className="w-4 h-4" />
              </div>
              <div>
                <div className="text-sm font-bold text-zinc-900 dark:text-zinc-100">
                  Currency Symbol
                </div>
                <div className="text-xs text-zinc-500 dark:text-zinc-400">
                  Used for total display & receipt breakdown
                </div>
              </div>
            </div>

            <select
              id="select-currency"
              value={settings.currency}
              onChange={(e) => onUpdateSettings({ currency: e.target.value })}
              className="px-3 py-1.5 text-xs font-semibold rounded-xl bg-zinc-100 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-900 dark:text-zinc-100 focus:outline-emerald-500 cursor-pointer"
            >
              {CURRENCY_OPTIONS.map((opt) => (
                <option key={opt.value} value={opt.value}>
                  {opt.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Keypad Feedback (Audio & Haptics) */}
        <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-4">
          <div className="text-xs font-bold uppercase tracking-wider text-zinc-500 dark:text-zinc-400">
            Touch & Feedback
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center text-zinc-700 dark:text-zinc-300">
                {settings.soundEnabled ? (
                  <Volume2 className="w-4 h-4 text-emerald-500" />
                ) : (
                  <VolumeX className="w-4 h-4 text-zinc-400" />
                )}
              </div>
              <div>
                <div className="text-sm font-bold text-zinc-900 dark:text-zinc-100">Sound Effects</div>
                <div className="text-xs text-zinc-500 dark:text-zinc-400">
                  Audible clicks when tapping keypad
                </div>
              </div>
            </div>

            <input
              id="toggle-sound"
              type="checkbox"
              checked={settings.soundEnabled}
              onChange={(e) => onUpdateSettings({ soundEnabled: e.target.checked })}
              className="w-5 h-5 accent-emerald-600 rounded cursor-pointer"
            />
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-zinc-100 dark:border-zinc-800">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center text-zinc-700 dark:text-zinc-300">
                <Vibrate className="w-4 h-4 text-emerald-500" />
              </div>
              <div>
                <div className="text-sm font-bold text-zinc-900 dark:text-zinc-100">
                  Haptic Vibration
                </div>
                <div className="text-xs text-zinc-500 dark:text-zinc-400">
                  Vibrate on keypress (supported mobile devices)
                </div>
              </div>
            </div>

            <input
              id="toggle-vibration"
              type="checkbox"
              checked={settings.vibrationEnabled}
              onChange={(e) => onUpdateSettings({ vibrationEnabled: e.target.checked })}
              className="w-5 h-5 accent-emerald-600 rounded cursor-pointer"
            />
          </div>
        </div>

        {/* Privacy & Security Card (Requirement 11) */}
        <div className="p-4 rounded-2xl bg-emerald-50/60 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/60 shadow-xs">
          <div className="flex items-start gap-3">
            <div className="p-1.5 rounded-lg bg-emerald-100 dark:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 mt-0.5">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div className="space-y-1">
              <div className="text-xs font-bold text-emerald-900 dark:text-emerald-200">
                Privacy Protection
              </div>
              <p className="text-[11px] text-emerald-800/80 dark:text-emerald-300/80 leading-relaxed">
                Photos are processed transiently in memory for OCR extraction and are never permanently
                stored on any database or external server.
              </p>
            </div>
          </div>
        </div>

        {/* Reset App Data */}
        <div className="pt-2">
          <button
            id="btn-reset-data"
            onClick={onClearAllData}
            className="w-full py-2.5 px-4 rounded-xl border border-rose-200 dark:border-rose-900/50 bg-rose-50/50 dark:bg-rose-950/20 hover:bg-rose-100 dark:hover:bg-rose-950/40 text-rose-700 dark:text-rose-400 text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Reset All Local Storage Data</span>
          </button>
        </div>
      </div>

      {/* App Info Footer */}
      <div className="pt-4 text-center text-xs text-zinc-400 dark:text-zinc-500">
        Smart Calculator • Mobile-Friendly OCR Scanner
      </div>
    </div>
  );
};
