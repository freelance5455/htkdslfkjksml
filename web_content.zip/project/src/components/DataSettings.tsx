import { useState } from 'react';
import { AlertTriangle, X, RotateCcw, Trash2 } from 'lucide-react';
import { Modal } from './Modal';
import { ConfirmDialog } from './ConfirmDialog';
import { useStore } from '@/lib/store';

export function DataLossBanner({ onDismiss }: { onDismiss: () => void }) {
  return (
    <div className="bg-amber-50 border border-amber-200 text-amber-800 px-4 py-3 text-sm flex items-start gap-2.5">
      <AlertTriangle size={18} className="shrink-0 mt-0.5 text-amber-600" />
      <p className="flex-1 leading-relaxed">
        Yeh data sirf is browser mein save hai. Agar browser data clear ho ya device badle to data <strong>delete</strong> ho sakta hai.
      </p>
      <button onClick={onDismiss} className="shrink-0 text-amber-600 hover:text-amber-800" aria-label="Dismiss">
        <X size={16} />
      </button>
    </div>
  );
}

export function DataSettingsButton() {
  const { resetToSample, clearAll } = useStore();
  const [open, setOpen] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);
  const [confirmClear, setConfirmClear] = useState(false);

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="text-slate-500 hover:text-slate-700"
        aria-label="Data settings"
      >
        <RotateCcw size={18} />
      </button>

      <Modal open={open} onClose={() => setOpen(false)} title="Data Settings">
        <div className="space-y-4">
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-sm text-amber-800 leading-relaxed">
            <div className="flex gap-2 font-semibold mb-1">
              <AlertTriangle size={16} className="shrink-0 mt-0.5" />
              Ehtiyat (Caution)
            </div>
            Saara data sirf is browser mein save hai. Cloud backup abhi nahi hai. Browser clear ya device change hone se data mit sakta hai.
          </div>

          <button
            onClick={() => setConfirmReset(true)}
            className="w-full flex items-center gap-3 px-4 py-3.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-left"
          >
            <RotateCcw size={18} className="text-slate-500" />
            <div>
              <p className="font-semibold text-slate-700 text-sm">Demo data wapas load karein</p>
              <p className="text-xs text-slate-400">Saari current data replace ho jayegi</p>
            </div>
          </button>

          <button
            onClick={() => setConfirmClear(true)}
            className="w-full flex items-center gap-3 px-4 py-3.5 rounded-xl border border-red-200 hover:bg-red-50 text-left"
          >
            <Trash2 size={18} className="text-red-500" />
            <div>
              <p className="font-semibold text-red-600 text-sm">Saara data delete karein</p>
              <p className="text-xs text-red-400">Sab records, udhaar aur stock khatam</p>
            </div>
          </button>
        </div>
      </Modal>

      <ConfirmDialog
        open={confirmReset}
        title="Demo data load?"
        message="Current saara data delete ho jayega aur naya demo data load hoga. Continue?"
        confirmLabel="Haan, Load"
        onConfirm={() => {
          resetToSample();
          setConfirmReset(false);
          setOpen(false);
        }}
        onCancel={() => setConfirmReset(false)}
      />

      <ConfirmDialog
        open={confirmClear}
        title="Saara data delete?"
        message="Yeh sab customers, udhaar, sales, expenses aur stock mita dega. Yeh wapas nahi aayega. Continue?"
        confirmLabel="Delete All"
        onConfirm={() => {
          clearAll();
          setConfirmClear(false);
          setOpen(false);
        }}
        onCancel={() => setConfirmClear(false)}
      />
    </>
  );
}
