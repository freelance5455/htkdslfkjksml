import React, { useState } from "react";
import {
  Trash2,
  Clock,
  Camera,
  Calculator,
  ArrowUpRight,
  Search,
  CheckCircle,
  FileSpreadsheet,
} from "lucide-react";
import { CalculationHistoryEntry, AppSettings } from "../types";

interface HistoryViewProps {
  history: CalculationHistoryEntry[];
  settings: AppSettings;
  onDeleteEntry: (id: string) => void;
  onClearAllHistory: () => void;
  onLoadIntoCalculator: (total: number, formula: string) => void;
}

export const HistoryView: React.FC<HistoryViewProps> = ({
  history,
  settings,
  onDeleteEntry,
  onClearAllHistory,
  onLoadIntoCalculator,
}) => {
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [confirmClear, setConfirmClear] = useState<boolean>(false);

  const filteredHistory = history.filter((entry) => {
    if (!searchTerm.trim()) return true;
    const term = searchTerm.toLowerCase();
    return (
      entry.formula.toLowerCase().includes(term) ||
      String(entry.total).includes(term) ||
      entry.dateFormatted.toLowerCase().includes(term)
    );
  });

  return (
    <div
      id="history-screen"
      className="flex flex-col h-full w-full max-w-lg mx-auto p-4 justify-between animate-in fade-in duration-200"
    >
      <div className="flex-1 overflow-hidden flex flex-col">
        {/* Header & Clear All */}
        <div className="flex items-center justify-between mb-3">
          <div>
            <span className="text-xs font-bold tracking-wider uppercase text-emerald-600 dark:text-emerald-400">
              Activity Log
            </span>
            <h2 className="text-xl sm:text-2xl font-black text-zinc-900 dark:text-zinc-100">
              Calculation History
            </h2>
          </div>

          {history.length > 0 && (
            <div>
              {confirmClear ? (
                <div className="flex items-center gap-1">
                  <button
                    id="btn-confirm-clear-history"
                    onClick={() => {
                      onClearAllHistory();
                      setConfirmClear(false);
                    }}
                    className="px-2.5 py-1 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition-all cursor-pointer"
                  >
                    Confirm Clear
                  </button>
                  <button
                    onClick={() => setConfirmClear(false)}
                    className="px-2 py-1 rounded-lg bg-zinc-200 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 text-xs font-medium cursor-pointer"
                  >
                    Cancel
                  </button>
                </div>
              ) : (
                <button
                  id="btn-clear-all-history"
                  onClick={() => setConfirmClear(true)}
                  className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-zinc-100 dark:bg-zinc-800/80 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-zinc-600 dark:text-zinc-400 hover:text-rose-600 dark:hover:text-rose-400 text-xs font-semibold transition-all cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Clear All</span>
                </button>
              )}
            </div>
          )}
        </div>

        {/* Search Bar */}
        {history.length > 4 && (
          <div className="relative mb-3">
            <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search numbers or dates..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-xs rounded-xl bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-zinc-800 dark:text-zinc-200 focus:outline-emerald-500"
            />
          </div>
        )}

        {/* History Entry List */}
        <div className="flex-1 overflow-y-auto space-y-2.5 pr-1">
          {filteredHistory.length === 0 ? (
            <div className="h-64 flex flex-col items-center justify-center text-center p-6 rounded-3xl bg-zinc-50 dark:bg-zinc-900/40 border border-dashed border-zinc-200 dark:border-zinc-800">
              <div className="w-12 h-12 rounded-2xl bg-zinc-200/70 dark:bg-zinc-800 flex items-center justify-center text-zinc-400 mb-3">
                <Clock className="w-6 h-6" />
              </div>
              <h3 className="text-sm font-bold text-zinc-700 dark:text-zinc-300">
                {searchTerm ? "No matching calculations" : "No calculation history yet"}
              </h3>
              <p className="text-xs text-zinc-400 dark:text-zinc-500 max-w-xs mt-1">
                {searchTerm
                  ? "Try searching for a different number or amount."
                  : "Perform a calculation or scan a receipt with the camera to save records here."}
              </p>
            </div>
          ) : (
            filteredHistory.map((entry) => (
              <div
                key={entry.id}
                className="p-3.5 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-xs hover:border-emerald-500/40 transition-all flex flex-col gap-2"
              >
                {/* Top metadata */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    {entry.source === "receipt_scan" ? (
                      <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-400">
                        <Camera className="w-3 h-3" />
                        <span>Receipt Scan</span>
                      </span>
                    ) : (
                      <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400">
                        <Calculator className="w-3 h-3" />
                        <span>Manual Calc</span>
                      </span>
                    )}
                    <span className="text-[11px] text-zinc-400 dark:text-zinc-500">
                      {entry.dateFormatted}
                    </span>
                  </div>

                  <button
                    onClick={() => onDeleteEntry(entry.id)}
                    className="p-1 rounded-lg text-zinc-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/50 transition-all cursor-pointer"
                    title="Delete this calculation"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Formula string */}
                <div className="text-xs font-mono text-zinc-600 dark:text-zinc-400 overflow-x-auto whitespace-nowrap scrollbar-none py-0.5">
                  {entry.formula}
                </div>

                {/* Total and Load Action */}
                <div className="flex items-center justify-between pt-1 border-t border-zinc-100 dark:border-zinc-800/80">
                  <div className="text-lg sm:text-xl font-black font-mono text-zinc-900 dark:text-zinc-100">
                    {settings.currency}
                    {entry.total.toLocaleString()}
                  </div>

                  <button
                    onClick={() => onLoadIntoCalculator(entry.total, entry.formula)}
                    className="flex items-center gap-1 text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:text-emerald-500 cursor-pointer"
                  >
                    <span>Use in Calc</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
