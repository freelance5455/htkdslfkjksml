import { Lock, Heart, Gift, Sparkles, Mail } from 'lucide-react';
import { sounds } from '@/lib/audio';

export type ScreenId = 'vault' | 'timeline' | 'coupons' | 'jar' | 'letters';

interface BottomNavProps {
  active: ScreenId;
  onChange: (screen: ScreenId) => void;
}

const items: { id: ScreenId; label: string; icon: typeof Lock }[] = [
  { id: 'vault', label: 'Vault', icon: Lock },
  { id: 'timeline', label: 'Journey', icon: Heart },
  { id: 'coupons', label: 'Coupons', icon: Gift },
  { id: 'jar', label: 'Reasons', icon: Sparkles },
  { id: 'letters', label: 'Letters', icon: Mail },
];

export function BottomNav({ active, onChange }: BottomNavProps) {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 px-3 pb-4 pt-2">
      <div className="glass-card rounded-2xl flex justify-around items-center px-2 py-2.5 max-w-md mx-auto">
        {items.map((item) => {
          const Icon = item.icon;
          const isActive = active === item.id;
          return (
            <button
              key={item.id}
              onClick={() => {
                if (!isActive) {
                  sounds.tap();
                  onChange(item.id);
                }
              }}
              className={`tap-bounce flex flex-col items-center gap-1 px-3 py-1.5 rounded-xl transition-all duration-300 ${
                isActive
                  ? 'text-rose-gold-bright'
                  : 'text-white/40 hover:text-white/60'
              }`}
              style={{
                background: isActive
                  ? 'radial-gradient(ellipse at center, rgba(232,180,184,0.15) 0%, transparent 70%)'
                  : 'transparent',
              }}
            >
              <Icon
                size={22}
                className={isActive ? 'drop-shadow-[0_0_8px_rgba(232,180,184,0.6)]' : ''}
                style={{
                  transition: 'all 0.3s ease',
                  transform: isActive ? 'scale(1.15)' : 'scale(1)',
                }}
              />
              <span className="text-[10px] font-medium tracking-wide">
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
