import React from "react";
import { Calculator, History, Settings, Camera } from "lucide-react";
import { ActiveTab } from "../types";

interface BottomNavProps {
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  onTriggerCamera: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onSelectTab,
  onTriggerCamera,
}) => {
  return (
    <nav
      id="bottom-navigation-bar"
      aria-label="Bottom Navigation"
      className="shrink-0 w-full max-w-md mx-auto px-4 py-2 border-t border-zinc-200/80 dark:border-zinc-800/80 bg-white/95 dark:bg-zinc-950/95 backdrop-blur-md z-30"
    >
      <div className="flex items-center justify-around">
        {/* Calculator Tab */}
        <button
          id="nav-tab-calculator"
          onClick={() => onSelectTab("calculator")}
          className={`flex flex-col items-center gap-1 px-3 py-1.5 rounded-xl transition-all cursor-pointer ${
            activeTab === "calculator"
              ? "text-emerald-600 dark:text-emerald-400 font-bold"
              : "text-zinc-500 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200"
          }`}
        >
          <Calculator className="w-5 h-5" />
          <span className="text-[11px]">Calculator</span>
        </button>

        {/* Quick Camera Action (Prominent Center Button) */}
        <button
          id="nav-quick-camera"
          onClick={onTriggerCamera}
          className="relative -top-3 w-12 h-12 rounded-full bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white flex items-center justify-center shadow-lg shadow-emerald-600/30 transition-all cursor-pointer border-2 border-white dark:border-zinc-950"
          title="Scan Receipt with Camera"
        >
          <Camera className="w-6 h-6" />
        </button>

        {/* History Tab */}
        <button
          id="nav-tab-history"
          onClick={() => onSelectTab("history")}
          className={`flex flex-col items-center gap-1 px-3 py-1.5 rounded-xl transition-all cursor-pointer ${
            activeTab === "history"
              ? "text-emerald-600 dark:text-emerald-400 font-bold"
              : "text-zinc-500 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200"
          }`}
        >
          <History className="w-5 h-5" />
          <span className="text-[11px]">History</span>
        </button>

        {/* Settings Tab */}
        <button
          id="nav-tab-settings"
          onClick={() => onSelectTab("settings")}
          className={`flex flex-col items-center gap-1 px-3 py-1.5 rounded-xl transition-all cursor-pointer ${
            activeTab === "settings"
              ? "text-emerald-600 dark:text-emerald-400 font-bold"
              : "text-zinc-500 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200"
          }`}
        >
          <Settings className="w-5 h-5" />
          <span className="text-[11px]">Settings</span>
        </button>
      </div>
    </nav>
  );
};
