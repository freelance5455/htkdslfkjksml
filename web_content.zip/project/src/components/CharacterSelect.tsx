import { useState } from 'react';

interface Props {
  onSelect: (character: string) => void;
}

const characters = [
  {
    key: 'gumball',
    name: 'غامبول',
    desc: 'القط الأزرق المرح والمغامر',
    color: '#4a90d9',
    emoji: '🐱',
  },
  {
    key: 'darwin',
    name: 'داروين',
    desc: 'السمكة الذهبية الوفيّة والطيّب',
    color: '#ff8c42',
    emoji: '🐟',
  },
  {
    key: 'anais',
    name: 'أنيس',
    desc: 'الأرنبة الذكية والعبقرية',
    color: '#f4d23c',
    emoji: '🐰',
  },
];

export function CharacterSelect({ onSelect }: Props) {
  const [selected, setSelected] = useState(0);

  return (
    <div
      dir="rtl"
      className="fixed inset-0 z-50 flex flex-col items-center justify-center overflow-hidden"
      style={{
        background: 'linear-gradient(135deg, #1a2a4a 0%, #2a4a6a 50%, #1a3a5a 100%)',
      }}
    >
      {/* Animated background bubbles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {Array.from({ length: 20 }).map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full opacity-10"
            style={{
              width: `${20 + Math.random() * 80}px`,
              height: `${20 + Math.random() * 80}px`,
              background: ['#4a90d9', '#ff8c42', '#f4d23c'][i % 3],
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animation: `float ${3 + Math.random() * 4}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 2}s`,
            }}
          />
        ))}
      </div>

      <style>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-30px); }
        }
        @keyframes slideIn {
          from { opacity: 0; transform: translateY(30px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes pulse {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.05); }
        }
      `}</style>

      <h1
        className="text-5xl md:text-6xl font-bold text-white mb-2 tracking-wide"
        style={{ textShadow: '0 4px 20px rgba(0,0,0,0.5)', animation: 'slideIn 0.6s ease-out' }}
      >
        عالم غامبول المذهل
      </h1>
      <p
        className="text-lg md:text-xl text-blue-200 mb-10"
        style={{ animation: 'slideIn 0.8s ease-out' }}
      >
        محاكي الحياة المفتوح ثلاثي الأبعاد
      </p>

      <div className="flex gap-4 md:gap-8 mb-10 flex-wrap justify-center px-4">
        {characters.map((char, i) => (
          <button
            key={char.key}
            onClick={() => setSelected(i)}
            className={`relative rounded-2xl p-6 transition-all duration-300 ${
              selected === i
                ? 'scale-110 shadow-2xl'
                : 'scale-100 opacity-60 hover:opacity-90'
            }`}
            style={{
              background: selected === i
                ? `linear-gradient(145deg, ${char.color}, ${char.color}cc)`
                : 'rgba(255,255,255,0.05)',
              border: selected === i ? `3px solid ${char.color}` : '3px solid transparent',
              width: '200px',
              animation: `slideIn ${0.6 + i * 0.15}s ease-out`,
            }}
          >
            <div
              className="text-6xl mb-3 text-center"
              style={{ animation: selected === i ? 'pulse 2s ease-in-out infinite' : 'none' }}
            >
              {char.emoji}
            </div>
            <div className="text-2xl font-bold text-white text-center mb-1">{char.name}</div>
            <div className="text-sm text-white/80 text-center">{char.desc}</div>
            {selected === i && (
              <div className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-green-400 flex items-center justify-center text-white text-xs font-bold">
                ✓
              </div>
            )}
          </button>
        ))}
      </div>

      <button
        onClick={() => onSelect(characters[selected].key)}
        className="px-12 py-4 rounded-xl text-xl font-bold text-white transition-all duration-300 hover:scale-105 active:scale-95"
        style={{
          background: `linear-gradient(135deg, ${characters[selected].color}, ${characters[selected].color}dd)`,
          boxShadow: `0 8px 30px ${characters[selected].color}66`,
          animation: 'slideIn 1s ease-out',
        }}
      >
        ابدأ اللعب بـ {characters[selected].name}
      </button>

      <div className="mt-8 text-center text-white/40 text-sm">
        <p>تحكم بلوحة المفاتيح: WASD للحركة | مسافة للقفز | F للسيارة | E للفوضى | C لتبديل الشخصية | Tab للهاتف</p>
      </div>
    </div>
  );
}
