import { useState, type ReactNode } from 'react';
import { AppWindow, KeyRound, LayoutDashboard, Layers, LogOut, Menu, Palette, Settings, SlidersHorizontal, Users, X, ReceiptText, Volume2, VolumeX, type LucideIcon } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui';

export type StudioRoute = 'dashboard' | 'apps' | 'optimizations' | 'keys' | 'plans' | 'payments' | 'clients' | 'customization' | 'settings';

interface NavItem {
  route: StudioRoute;
  label: string;
  icon: LucideIcon;
}

export const NAV_ITEMS: NavItem[] = [
  { route: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { route: 'apps', label: 'Aplicativos', icon: AppWindow },
  { route: 'optimizations', label: 'Otimizações', icon: SlidersHorizontal },
  { route: 'keys', label: 'KEYs', icon: KeyRound },
  { route: 'plans', label: 'Planos', icon: Layers },
  { route: 'payments', label: 'Pagamentos', icon: ReceiptText },
  { route: 'clients', label: 'Clientes', icon: Users },
  { route: 'customization', label: 'Personalização', icon: Palette },
  { route: 'settings', label: 'Configurações', icon: Settings },
];

function NavLinks({ current, onNavigate }: { current: StudioRoute; onNavigate?: () => void }) {
  return (
    <nav className="space-y-1" aria-label="Navegação principal">
      {NAV_ITEMS.map(({ route, label, icon: Icon }) => {
        const active = route === current;
        return (
          <a
            key={route}
            href={`#/${route}`}
            onClick={onNavigate}
            aria-current={active ? 'page' : undefined}
            className={`group flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all duration-200 ${
              active
                ? 'bg-crimson-700/20 text-graphite-50 ring-1 ring-inset ring-crimson-600/50'
                : 'text-graphite-300 hover:bg-graphite-700/60 hover:text-graphite-50'
            }`}
          >
            <Icon className={`h-4 w-4 transition-transform duration-200 group-hover:scale-110 ${active ? 'text-crimson-300' : ''}`} aria-hidden="true" />
            {label}
          </a>
        );
      })}
    </nav>
  );
}

function Brand() {
  return (
    <div className="flex items-center gap-3">
      <img
        src="/file_000000006c70820e86c736074b81b735.png"
        alt="Logo SLOW OPTIMIZER"
        className="h-10 w-10 rounded-xl object-cover shadow-lg shadow-crimson-900/50 ring-1 ring-inset ring-crimson-700/50"
      />
      <div className="leading-tight">
        <p className="font-display text-sm font-semibold tracking-wide text-graphite-50">VT STUDIO</p>
        <p className="text-xs text-graphite-400">Painel administrativo</p>
      </div>
    </div>
  );
}

export function AppShell({ current, title, children }: { current: StudioRoute; title: string; children: ReactNode }) {
  const { session, signOut } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);
  const [signingOut, setSigningOut] = useState(false);
  const [signOutError, setSignOutError] = useState<string | null>(null);
  const [soundsEnabled, setSoundsEnabled] = useState(() => { try { return localStorage.getItem('vt-studio-sounds') !== 'off'; } catch { return true; } });

  const playUiSound = () => {
    if (!soundsEnabled) return;
    try {
      const AudioContextClass = window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AudioContextClass) return;
      const audio = new AudioContextClass();
      const oscillator = audio.createOscillator();
      const gain = audio.createGain();
      oscillator.type = 'sine'; oscillator.frequency.setValueAtTime(720, audio.currentTime);
      gain.gain.setValueAtTime(0.025, audio.currentTime); gain.gain.exponentialRampToValueAtTime(0.001, audio.currentTime + 0.045);
      oscillator.connect(gain); gain.connect(audio.destination); oscillator.start(); oscillator.stop(audio.currentTime + 0.045);
      oscillator.onended = () => { void audio.close(); };
    } catch { /* áudio é opcional; não deve bloquear ações */ }
  };

  const toggleSounds = () => {
    setSoundsEnabled(current => { const next = !current; try { localStorage.setItem('vt-studio-sounds', next ? 'on' : 'off'); } catch { /* storage opcional */ } return next; });
  };

  const handleSignOut = async () => {
    setSigningOut(true);
    setSignOutError(null);
    try {
      await signOut();
    } catch (error) {
      setSignOutError(error instanceof Error ? error.message : 'Não foi possível sair. Tente novamente.');
      setSigningOut(false);
    }
  };

  const footer = (
    <div className="space-y-3 border-t border-graphite-700 pt-4">
      <div className="min-w-0">
        <p className="text-xs text-graphite-400">Conectado como</p>
        <p className="truncate text-sm text-graphite-100">{session?.user.email}</p>
      </div>
      <Button variant="secondary" icon={LogOut} onClick={handleSignOut} loading={signingOut} className="w-full">
        Sair
      </Button>
      {signOutError ? <p className="text-xs text-danger-400">{signOutError}</p> : null}
    </div>
  );

  return (
    <div className="site-backdrop min-h-screen" onClickCapture={(event) => { const target = event.target as HTMLElement; if (target.closest('button, a, [role=button]')) playUiSound(); }}> 
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 flex-col border-r border-graphite-800 bg-ink px-4 py-6 lg:flex">
        <div className="px-2 pb-8">
          <Brand />
        </div>
        <div className="flex-1 overflow-y-auto">
          <NavLinks current={current} />
        </div>
        {footer}
      </aside>

      {menuOpen ? (
        <div className="fixed inset-0 z-40 bg-black/70 backdrop-blur-sm lg:hidden" onMouseDown={() => setMenuOpen(false)}>
          <aside
            className="animate-scale-in flex h-full w-72 flex-col border-r border-graphite-700 bg-ink px-4 py-6"
            onMouseDown={(event) => event.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-8">
              <Brand />
              <button
                type="button"
                aria-label="Fechar menu"
                onClick={() => setMenuOpen(false)}
                className="rounded-lg p-2 text-graphite-300 hover:bg-graphite-700 hover:text-graphite-50"
              >
                <X className="h-5 w-5" aria-hidden="true" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto">
              <NavLinks current={current} onNavigate={() => setMenuOpen(false)} />
            </div>
            {footer}
          </aside>
        </div>
      ) : null}

      <div className="lg:pl-64">
        <header className="sticky top-0 z-20 flex items-center gap-4 border-b border-graphite-800 bg-ink/90 px-4 py-4 backdrop-blur-md sm:px-8">
          <button
            type="button"
            aria-label="Abrir menu"
            onClick={() => setMenuOpen(true)}
            className="rounded-lg p-2 text-graphite-200 hover:bg-graphite-800 lg:hidden"
          >
            <Menu className="h-5 w-5" aria-hidden="true" />
          </button>
          <h2 className="font-display text-base font-semibold text-graphite-50 sm:text-lg">{title}</h2>
          <div className="ml-auto"><Button variant="secondary" icon={soundsEnabled ? Volume2 : VolumeX} onClick={toggleSounds} aria-label={soundsEnabled ? 'Desativar sons' : 'Ativar sons'}>{soundsEnabled ? 'Sons ligados' : 'Sons desligados'}</Button></div>
        </header>
        <main className="mx-auto w-full max-w-6xl px-4 py-8 sm:px-8 sm:py-10">{children}</main>
      </div>
    </div>
  );
}
