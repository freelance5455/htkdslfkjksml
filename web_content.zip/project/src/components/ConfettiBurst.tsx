import { useEffect, useState } from 'react';

interface ConfettiBurstProps {
  active: boolean;
  onComplete?: () => void;
}

const colors = ['#e8b4b8', '#d4af7a', '#f0c6cb', '#e8c9a0', '#c4a0d4', '#b8d4e8'];

export function ConfettiBurst({ active, onComplete }: ConfettiBurstProps) {
  const [pieces, setPieces] = useState<
    { id: number; left: string; delay: string; duration: string; color: string; rotation: string; shape: string }[]
  >([]);

  useEffect(() => {
    if (!active) {
      setPieces([]);
      return;
    }
    const newPieces = Array.from({ length: 60 }, (_, i) => ({
      id: i,
      left: `${Math.random() * 100}%`,
      delay: `${Math.random() * 0.5}s`,
      duration: `${2.5 + Math.random() * 1.5}s`,
      color: colors[Math.floor(Math.random() * colors.length)],
      rotation: `${Math.random() * 360}deg`,
      shape: Math.random() > 0.5 ? 'circle' : 'rect',
    }));
    setPieces(newPieces);

    const timer = setTimeout(() => {
      onComplete?.();
    }, 4000);
    return () => clearTimeout(timer);
  }, [active, onComplete]);

  if (!active) return null;

  return (
    <div className="fixed inset-0 z-[100] pointer-events-none">
      {pieces.map((p) => (
        <div
          key={p.id}
          className="confetti-piece"
          style={{
            left: p.left,
            backgroundColor: p.color,
            animationDelay: p.delay,
            animationDuration: p.duration,
            transform: `rotate(${p.rotation})`,
            borderRadius: p.shape === 'circle' ? '50%' : '2px',
            width: p.shape === 'circle' ? '10px' : '8px',
            height: p.shape === 'circle' ? '10px' : '14px',
          }}
        />
      ))}
    </div>
  );
}
