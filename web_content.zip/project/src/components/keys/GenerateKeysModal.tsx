import { useEffect, useState, type FormEvent } from 'react';
import { Check, Copy, KeyRound } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { errorMessage } from '@/lib/errors';
import { generateLicenseKey, type GeneratedLicenseKey } from '@/lib/licenseKeys';
import type { Client, StudioApp, StudioSettings } from '@/types/studio';
import { Alert, Button, Field, Modal, SelectInput, TextInput } from '@/components/ui';

const MAX_BATCH = 50;
const MAX_INSTALLATIONS = 100;
const MAX_VALIDITY_DAYS = 3650;

interface GenerateKeysModalProps {
  open: boolean;
  onClose: () => void;
  onGenerated: () => void;
}

interface FormState {
  appId: string;
  clientId: string;
  quantity: string;
  validityDays: string;
  maxActivations: string;
  notes: string;
}

const EMPTY_FORM: FormState = {
  appId: '',
  clientId: '',
  quantity: '1',
  validityDays: '',
  maxActivations: '1',
  notes: '',
};

function parseWhole(value: string, min: number, max: number): number | null {
  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed < min || parsed > max) return null;
  return parsed;
}

export function GenerateKeysModal({ open, onClose, onGenerated }: GenerateKeysModalProps) {
  const [apps, setApps] = useState<StudioApp[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [form, setForm] = useState<FormState>(EMPTY_FORM);
  const [loadingOptions, setLoadingOptions] = useState(false);
  const [optionsError, setOptionsError] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [generated, setGenerated] = useState<GeneratedLicenseKey[] | null>(null);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [copyError, setCopyError] = useState<string | null>(null);

  useEffect(() => {
    if (!open) return;
    let cancelled = false;
    setLoadingOptions(true);
    setOptionsError(null);
    setGenerated(null);
    setFormError(null);

    Promise.all([
      supabase.from('apps').select('*').neq('status', 'archived').order('name').returns<StudioApp[]>(),
      supabase.from('clients').select('*').order('name').returns<Client[]>(),
      supabase.from('studio_settings').select('*').eq('id', 1).maybeSingle<StudioSettings>(),
    ])
      .then(([appsResult, clientsResult, settingsResult]) => {
        if (cancelled) return;
        if (appsResult.error) throw appsResult.error;
        if (clientsResult.error) throw clientsResult.error;
        if (settingsResult.error) throw settingsResult.error;
        const settings = settingsResult.data;
        setApps(appsResult.data ?? []);
        setClients(clientsResult.data ?? []);
        setForm({
          ...EMPTY_FORM,
          appId: appsResult.data?.[0]?.id ?? '',
          validityDays: settings?.default_validity_days ? String(settings.default_validity_days) : '',
          maxActivations: String(settings?.default_max_activations ?? 1),
        });
      })
      .catch((caught: unknown) => {
        if (!cancelled) setOptionsError(errorMessage(caught));
      })
      .finally(() => {
        if (!cancelled) setLoadingOptions(false);
      });

    return () => {
      cancelled = true;
    };
  }, [open]);

  const updateField = (field: keyof FormState, value: string) => {
    setForm((current) => ({ ...current, [field]: value }));
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setFormError(null);

    const quantity = parseWhole(form.quantity, 1, MAX_BATCH);
    const maxActivations = parseWhole(form.maxActivations, 1, MAX_INSTALLATIONS);
    const validityDays = form.validityDays.trim() === '' ? null : parseWhole(form.validityDays, 1, MAX_VALIDITY_DAYS);

    if (!form.appId) {
      setFormError('Selecione o aplicativo da chave.');
      return;
    }
    if (quantity === null) {
      setFormError(`Informe uma quantidade entre 1 e ${MAX_BATCH}.`);
      return;
    }
    if (maxActivations === null) {
      setFormError(`Informe um limite de instalações entre 1 e ${MAX_INSTALLATIONS}.`);
      return;
    }
    if (form.validityDays.trim() !== '' && validityDays === null) {
      setFormError(`A validade deve ser um número de dias entre 1 e ${MAX_VALIDITY_DAYS}.`);
      return;
    }

    setSaving(true);
    try {
      const keys = await Promise.all(Array.from({ length: quantity }, () => generateLicenseKey()));
      const expiresAt =
        validityDays === null ? null : new Date(Date.now() + validityDays * 24 * 60 * 60 * 1000).toISOString();

      const { error } = await supabase.from('license_keys').insert(
        keys.map((key) => ({
          key_hash: key.keyHash,
          key_prefix: key.keyPrefix,
          app_id: form.appId,
          client_id: form.clientId || null,
          max_activations: maxActivations,
          expires_at: expiresAt,
          notes: form.notes.trim() || null,
        }))
      );
      if (error) throw error;

      setGenerated(keys);
      onGenerated();
    } catch (caught) {
      setFormError(errorMessage(caught));
    } finally {
      setSaving(false);
    }
  };

  const copyKey = async (plainKey: string) => {
    setCopyError(null);
    try {
      await navigator.clipboard.writeText(plainKey);
      setCopiedKey(plainKey);
      window.setTimeout(() => setCopiedKey((current) => (current === plainKey ? null : current)), 1800);
    } catch {
      setCopyError('Não foi possível copiar. Selecione a chave e copie manualmente.');
    }
  };

  if (generated) {
    return (
      <Modal
        open={open}
        title="Chaves geradas"
        description="Copie as chaves agora. Por segurança, elas não podem ser exibidas novamente."
        onClose={onClose}
        size="lg"
        footer={<Button onClick={onClose}>Concluir</Button>}
      >
        <div className="space-y-4">
          <ul className="space-y-2">
            {generated.map((key) => (
              <li
                key={key.keyHash}
                className="flex items-center justify-between gap-3 rounded-xl border border-graphite-600 bg-ink px-4 py-3"
              >
                <code className="select-all break-all font-mono text-sm tracking-wider text-graphite-50">{key.plainKey}</code>
                <button
                  type="button"
                  onClick={() => copyKey(key.plainKey)}
                  className="inline-flex shrink-0 items-center gap-2 rounded-lg px-3 py-2 text-xs font-medium text-graphite-200 transition-colors hover:bg-graphite-700"
                >
                  {copiedKey === key.plainKey ? (
                    <>
                      <Check className="h-3.5 w-3.5 text-success-400" aria-hidden="true" />
                      Copiada
                    </>
                  ) : (
                    <>
                      <Copy className="h-3.5 w-3.5" aria-hidden="true" />
                      Copiar
                    </>
                  )}
                </button>
              </li>
            ))}
          </ul>
          {copyError ? <Alert>{copyError}</Alert> : null}
        </div>
      </Modal>
    );
  }

  return (
    <Modal
      open={open}
      title="Gerar novas KEYs"
      description="Cada KEY pode ser ativada em um número limitado de instalações."
      onClose={onClose}
      size="lg"
      footer={
        <>
          <Button variant="secondary" onClick={onClose} disabled={saving}>
            Cancelar
          </Button>
          <Button type="submit" form="generate-keys-form" icon={KeyRound} loading={saving} disabled={loadingOptions || !!optionsError || apps.length === 0}>
            Gerar KEYs
          </Button>
        </>
      }
    >
      {loadingOptions ? (
        <p className="py-8 text-center text-sm text-graphite-300">Carregando aplicativos e clientes...</p>
      ) : optionsError ? (
        <Alert>{optionsError}</Alert>
      ) : apps.length === 0 ? (
        <Alert tone="warning">Cadastre um aplicativo no catálogo antes de gerar KEYs.</Alert>
      ) : (
        <form id="generate-keys-form" onSubmit={handleSubmit} className="grid gap-5 sm:grid-cols-2" noValidate>
          <div className="sm:col-span-2">
            <Field label="Aplicativo">
              <SelectInput value={form.appId} onChange={(event) => updateField('appId', event.target.value)} required>
                {apps.map((app) => (
                  <option key={app.id} value={app.id}>
                    {app.name} ({app.status === 'published' ? 'publicado' : 'rascunho'})
                  </option>
                ))}
              </SelectInput>
            </Field>
          </div>
          <div className="sm:col-span-2">
            <Field label="Cliente" hint="Opcional. Você pode atribuir o cliente depois, na página de licenças.">
              <SelectInput value={form.clientId} onChange={(event) => updateField('clientId', event.target.value)}>
                <option value="">Sem cliente</option>
                {clients.map((client) => (
                  <option key={client.id} value={client.id}>
                    {client.name}
                  </option>
                ))}
              </SelectInput>
            </Field>
          </div>
          <Field label="Quantidade">
            <TextInput type="number" inputMode="numeric" min={1} max={MAX_BATCH} value={form.quantity} onChange={(event) => updateField('quantity', event.target.value)} />
          </Field>
          <Field label="Instalações por KEY">
            <TextInput
              type="number"
              inputMode="numeric"
              min={1}
              max={MAX_INSTALLATIONS}
              value={form.maxActivations}
              onChange={(event) => updateField('maxActivations', event.target.value)}
            />
          </Field>
          <Field label="Validade (dias)" hint="Deixe em branco para uma KEY sem vencimento.">
            <TextInput
              type="number"
              inputMode="numeric"
              min={1}
              max={MAX_VALIDITY_DAYS}
              value={form.validityDays}
              onChange={(event) => updateField('validityDays', event.target.value)}
              placeholder="Sem vencimento"
            />
          </Field>
          <div className="sm:col-span-2">
            <Field label="Observações">
              <TextInput value={form.notes} onChange={(event) => updateField('notes', event.target.value)} maxLength={300} placeholder="Ex.: lote de março" />
            </Field>
          </div>
          {formError ? (
            <div className="sm:col-span-2">
              <Alert>{formError}</Alert>
            </div>
          ) : null}
        </form>
      )}
    </Modal>
  );
}
