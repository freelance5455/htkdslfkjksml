import { GameHudState } from '@/game/engine';
import { Minimap } from '@/components/Minimap';

interface Props {
  state: GameHudState;
}

export function HUD({ state }: Props) {
  return (
    <div dir="rtl" className="fixed inset-0 pointer-events-none z-30 select-none">
      {/* Top-right: Stats */}
      <div className="absolute top-4 right-4 flex flex-col gap-2 items-end">
        {/* Money counter */}
        <div
          className="flex items-center gap-2 px-4 py-2 rounded-xl backdrop-blur-md"
          style={{ background: 'rgba(0, 40, 20, 0.75)', border: '1px solid rgba(50, 200, 100, 0.3)' }}
        >
          <span className="text-2xl font-bold text-green-400" style={{ textShadow: '0 2px 4px rgba(0,0,0,0.5)' }}>
            ${state.money}
          </span>
          <span className="text-sm text-green-300">عداد الكاش</span>
        </div>

        {/* Health bar */}
        <div className="w-56">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs text-red-300 font-bold">الصحة</span>
            <span className="text-xs text-white/60">{state.health}%</span>
          </div>
          <div className="h-3 rounded-full bg-black/50 overflow-hidden border border-red-900/30">
            <div
              className="h-full rounded-full transition-all duration-300"
              style={{
                width: `${state.health}%`,
                background: state.health > 30
                  ? 'linear-gradient(90deg, #ff4466, #ff6688)'
                  : 'linear-gradient(90deg, #aa0000, #ff2222)',
                boxShadow: '0 0 8px rgba(255, 68, 102, 0.5)',
              }}
            />
          </div>
        </div>

        {/* Energy bar */}
        <div className="w-56">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs text-orange-300 font-bold">الطاقة / الجوع</span>
            <span className="text-xs text-white/60">{state.energy}%</span>
          </div>
          <div className="h-3 rounded-full bg-black/50 overflow-hidden border border-orange-900/30">
            <div
              className="h-full rounded-full transition-all duration-300"
              style={{
                width: `${state.energy}%`,
                background: state.energy > 30
                  ? 'linear-gradient(90deg, #ff9933, #ffcc66)'
                  : 'linear-gradient(90deg, #884400, #cc6622)',
                boxShadow: '0 0 8px rgba(255, 153, 51, 0.5)',
              }}
            />
          </div>
        </div>
      </div>

      {/* Top-left: Wanted level + Minimap */}
      <div className="absolute top-4 left-4 flex flex-col gap-2">
        <Minimap
          state={state}
          playerPos={{ x: state.playerX, z: state.playerZ }}
          playerRot={state.playerRot}
          missionPos={state.missionMarker}
          timeLabel={state.timeLabel}
        />
        {state.wantedLevel > 0 && (
          <div className="flex flex-col gap-1 items-center">
            <span className="text-sm font-bold text-yellow-400" style={{ textShadow: '0 2px 4px rgba(0,0,0,0.8)' }}>
              المطلوب للعدالة
            </span>
            <div className="flex gap-1">
              {Array.from({ length: 5 }).map((_, i) => (
                <span
                  key={i}
                  className="text-2xl transition-all"
                  style={{
                    filter: i < state.wantedLevel ? 'drop-shadow(0 0 6px #ffaa00)' : 'grayscale(1) opacity(0.3)',
                    animation: i < state.wantedLevel ? 'wantedPulse 1s ease-in-out infinite' : 'none',
                    animationDelay: `${i * 0.1}s`,
                  }}
                >
                  ⭐
                </span>
              ))}
            </div>
          </div>
        )}
      </div>

      <style>{`
        @keyframes wantedPulse {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.2); }
        }
        @keyframes messageIn {
          from { opacity: 0; transform: translateY(-20px) scale(0.9); }
          to { opacity: 1; transform: translateY(0) scale(1); }
        }
        @keyframes missionSlide {
          from { opacity: 0; transform: translateX(-30px); }
          to { opacity: 1; transform: translateX(0); }
        }
      `}</style>

      {/* Center: Character name badge */}
      <div className="absolute top-4 left-1/2 -translate-x-1/2">
        <div
          className="px-4 py-1.5 rounded-full backdrop-blur-md text-white text-sm font-bold"
          style={{ background: 'rgba(0,0,0,0.5)', border: '1px solid rgba(255,255,255,0.1)' }}
        >
          {state.characterName} {state.isInVehicle && '🚗'}
        </div>
      </div>

      {/* Mission tracker (left side, below minimap) */}
      {state.mission && state.mission.isActive && (
        <div
          className="absolute top-48 left-4 w-52 rounded-xl backdrop-blur-md p-3"
          style={{
            background: 'rgba(20, 25, 40, 0.8)',
            border: '1px solid rgba(255, 170, 0, 0.3)',
            animation: 'missionSlide 0.5s ease-out',
          }}
        >
          <div className="flex items-center gap-2 mb-1">
            <span className="text-yellow-400 text-sm font-bold">المهمة</span>
            <span className="text-white/40 text-xs">{state.mission.completedCount}/{state.mission.completedCount + 1}</span>
          </div>
          <div className="text-white text-sm font-bold mb-1">{state.mission.title}</div>
          <div className="text-white/60 text-xs mb-2">{state.mission.description}</div>
          <div className="flex items-center gap-2">
            <div className="flex-1 h-2 rounded-full bg-black/40 overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-500"
                style={{ width: '100%', background: 'linear-gradient(90deg, #ffaa00, #ffdd44)' }}
              />
            </div>
            <span className="text-green-400 text-xs font-bold">+{state.mission.reward}$</span>
          </div>
        </div>
      )}

      {/* All missions completed */}
      {state.mission && !state.mission.isActive && state.mission.isCompleted && (
        <div
          className="absolute top-48 left-4 w-52 rounded-xl backdrop-blur-md p-3"
          style={{ background: 'rgba(20, 40, 20, 0.8)', border: '1px solid rgba(50, 200, 100, 0.3)' }}
        >
          <div className="text-green-400 text-sm font-bold mb-1">جميع المهام مكتملة!</div>
          <div className="text-white/60 text-xs">استمتع بالحرية الكاملة في إلمور</div>
        </div>
      )}

      {/* Center message */}
      {state.message && (
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2">
          <div
            className="px-6 py-3 rounded-xl backdrop-blur-md text-white text-lg font-bold text-center max-w-md"
            style={{
              background: 'rgba(0,0,0,0.7)',
              border: '1px solid rgba(255,255,255,0.15)',
              animation: 'messageIn 0.3s ease-out',
              textShadow: '0 2px 4px rgba(0,0,0,0.5)',
            }}
          >
            {state.message}
          </div>
        </div>
      )}

      {/* Bottom-center: Context prompts */}
      <div className="absolute bottom-28 md:bottom-8 left-1/2 -translate-x-1/2 flex flex-col gap-2 items-center">
        {state.nearVehicle && !state.isInVehicle && (
          <div className="px-4 py-2 rounded-lg bg-black/70 text-white text-sm backdrop-blur-md border border-white/10">
            اضغط <kbd className="px-2 py-0.5 bg-white/20 rounded mx-1">F</kbd> لركوب السيارة
          </div>
        )}
        {state.isInVehicle && (
          <div className="px-4 py-2 rounded-lg bg-black/70 text-white text-sm backdrop-blur-md border border-white/10">
            اضغط <kbd className="px-2 py-0.5 bg-white/20 rounded mx-1">F</kbd> للخروج من السيارة
          </div>
        )}
        {state.nearBuilding && !state.isIndoors && (
          <div className="px-4 py-2 rounded-lg bg-black/70 text-white text-sm backdrop-blur-md border border-white/10">
            {state.nearBuilding}
          </div>
        )}
        {state.nearHouse && (
          <div className="px-4 py-2 rounded-lg bg-black/70 text-white text-sm backdrop-blur-md border border-white/10">
            اضغط <kbd className="px-2 py-0.5 bg-white/20 rounded mx-1">F</kbd> لدخول البيت
          </div>
        )}
        {state.isIndoors && (
          <div className="px-4 py-2 rounded-lg bg-black/70 text-white text-sm backdrop-blur-md border border-white/10">
            اضغط <kbd className="px-2 py-0.5 bg-white/20 rounded mx-1">F</kbd> للخروج من البيت
          </div>
        )}
      </div>

      {/* Work shift progress */}
      {state.workShiftActive && (
        <div className="absolute top-20 left-1/2 -translate-x-1/2 w-64">
          <div className="text-center text-white text-sm font-bold mb-1" style={{ textShadow: '0 2px 4px rgba(0,0,0,0.8)' }}>
            وردية العمل جارية...
          </div>
          <div className="h-3 rounded-full bg-black/50 overflow-hidden border border-green-900/30">
            <div
              className="h-full rounded-full transition-all duration-300"
              style={{
                width: `${state.workShiftProgress * 100}%`,
                background: 'linear-gradient(90deg, #44aa66, #66cc88)',
              }}
            />
          </div>
        </div>
      )}

      {/* Death overlay */}
      {state.isDead && (
        <div className="absolute inset-0 flex items-center justify-center" style={{ background: 'rgba(100, 0, 0, 0.5)' }}>
          <div className="text-center">
            <div className="text-5xl font-bold text-white mb-4" style={{ textShadow: '0 4px 20px rgba(0,0,0,0.8)' }}>
              لقد فقدت الوعي!
            </div>
            <div className="text-xl text-white/80">
              إعادة الإحياء...
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
