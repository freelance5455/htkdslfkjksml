import { useState } from 'react';

interface Props {
  onClose: () => void;
  onSwitchCharacter: (key: string) => void;
  onWorkShift: () => void;
  onBuyFood: () => void;
  characterKey: string;
  money: number;
  health: number;
  energy: number;
  wantedLevel: number;
  missionTitle: string;
  missionDesc: string;
  missionReward: number;
  missionActive: boolean;
  missionCompletedCount: number;
  timeLabel: string;
}

type Screen = 'home' | 'character' | 'work' | 'map' | 'stats' | 'missions';

export function PhoneMenu({ onClose, onSwitchCharacter, onWorkShift, onBuyFood, characterKey, money, health, energy, wantedLevel, missionTitle, missionDesc, missionReward, missionActive, missionCompletedCount, timeLabel }: Props) {
  const [screen, setScreen] = useState<Screen>('home');

  const apps: { id: Screen; label: string; icon: string; color: string }[] = [
    { id: 'character', label: 'الشخصيات', icon: '👥', color: '#4a90d9' },
    { id: 'work', label: 'العمل', icon: '💼', color: '#44aa66' },
    { id: 'missions', label: 'المهام', icon: '🎯', color: '#ffaa00' },
    { id: 'map', label: 'الخريطة', icon: '🗺️', color: '#cc8844' },
    { id: 'stats', label: 'الإحصائيات', icon: '📊', color: '#aa4466' },
  ];

  return (
    <div dir="rtl" className="fixed inset-0 z-40 flex items-center justify-center" style={{ background: 'rgba(0,0,0,0.5)' }}>
      {/* Phone frame */}
      <div
        className="relative rounded-[2rem] overflow-hidden"
        style={{
          width: '340px',
          height: '620px',
          maxWidth: '90vw',
          maxHeight: '80vh',
          background: 'linear-gradient(145deg, #1a1a2e, #16213e)',
          border: '3px solid #333',
          boxShadow: '0 20px 60px rgba(0,0,0,0.5)',
        }}
      >
        {/* Notch */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-24 h-5 bg-black rounded-b-2xl z-10" />

        {/* Screen */}
        <div className="h-full overflow-y-auto" style={{ background: 'linear-gradient(180deg, #0f3460, #16213e)' }}>
          {/* Status bar */}
          <div className="flex justify-between items-center px-5 pt-8 pb-2 text-white text-xs">
            <span>{timeLabel}</span>
            <div className="flex gap-2">
              <span>🔋 {health}%</span>
              <span>💰 {money}$</span>
            </div>
          </div>

          {/* Home screen */}
          {screen === 'home' && (
            <div className="px-5 py-4">
              <div className="text-center text-white/80 text-sm mb-4">
                {new Date().toLocaleDateString('ar', { weekday: 'long', day: 'numeric', month: 'long' })}
              </div>
              <div className="grid grid-cols-3 gap-4 mt-6">
                {apps.map((app) => (
                  <button
                    key={app.id}
                    onClick={() => setScreen(app.id)}
                    className="flex flex-col items-center gap-2 transition-transform hover:scale-110 active:scale-95"
                  >
                    <div
                      className="w-16 h-16 rounded-2xl flex items-center justify-center text-3xl"
                      style={{ background: `${app.color}44`, border: `2px solid ${app.color}88` }}
                    >
                      {app.icon}
                    </div>
                    <span className="text-white text-xs">{app.label}</span>
                  </button>
                ))}
              </div>

              {/* Quick actions */}
              <div className="mt-8 space-y-2">
                <button
                  onClick={onBuyFood}
                  className="w-full py-3 rounded-xl text-white font-bold text-sm transition-all hover:scale-[1.02] active:scale-95"
                  style={{ background: 'linear-gradient(135deg, #ff9933, #cc6622)' }}
                >
                  🍔 شراء طعام (50$) — +40 طاقة
                </button>
                <button
                  onClick={onWorkShift}
                  className="w-full py-3 rounded-xl text-white font-bold text-sm transition-all hover:scale-[1.02] active:scale-95"
                  style={{ background: 'linear-gradient(135deg, #44aa66, #228844)' }}
                >
                  💼 بدء وردية في جوي فول (+150$)
                </button>
              </div>
            </div>
          )}

          {/* Character screen */}
          {screen === 'character' && (
            <div className="px-5 py-4">
              <BackButton onClick={() => setScreen('home')} />
              <h2 className="text-white text-lg font-bold mb-4 text-center">اختر الشخصية</h2>
              <div className="space-y-3">
                {[
                  { key: 'gumball', name: 'غامبول', emoji: '🐱', color: '#4a90d9' },
                  { key: 'darwin', name: 'داروين', emoji: '🐟', color: '#ff8c42' },
                  { key: 'anais', name: 'أنيس', emoji: '🐰', color: '#f4d23c' },
                ].map((char) => (
                  <button
                    key={char.key}
                    onClick={() => { onSwitchCharacter(char.key); setScreen('home'); }}
                    className={`w-full py-3 px-4 rounded-xl flex items-center gap-3 transition-all hover:scale-[1.02] ${
                      characterKey === char.key ? 'ring-2' : ''
                    }`}
                    style={{
                      background: `${char.color}33`,
                      border: `1px solid ${char.color}66`,
                    }}
                  >
                    <span className="text-3xl">{char.emoji}</span>
                    <span className="text-white font-bold">{char.name}</span>
                    {characterKey === char.key && (
                      <span className="mr-auto text-green-400">✓ نشط</span>
                    )}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Work screen */}
          {screen === 'work' && (
            <div className="px-5 py-4">
              <BackButton onClick={() => setScreen('home')} />
              <h2 className="text-white text-lg font-bold mb-4 text-center">الوظائف</h2>
              <div className="space-y-3">
                <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                  <div className="text-3xl mb-2">🍔</div>
                  <h3 className="text-white font-bold mb-1">جوي فول</h3>
                  <p className="text-white/60 text-sm mb-3">اعمل وردية لمدة 20 ثانية واربح 150$</p>
                  <button
                    onClick={onWorkShift}
                    className="w-full py-2 rounded-lg text-white text-sm font-bold"
                    style={{ background: 'linear-gradient(135deg, #44aa66, #228844)' }}
                  >
                    ابدأ الوردية
                  </button>
                </div>
                <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                  <div className="text-3xl mb-2">🍔</div>
                  <h3 className="text-white font-bold mb-1">شراء وجبة</h3>
                  <p className="text-white/60 text-sm mb-3">اشترِ طعاماً مقابل 50$ لاستعادة 40 طاقة و10 صحة</p>
                  <button
                    onClick={onBuyFood}
                    className="w-full py-2 rounded-lg text-white text-sm font-bold"
                    style={{ background: 'linear-gradient(135deg, #ff9933, #cc6622)' }}
                  >
                    شراء (50$)
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Map screen */}
          {screen === 'map' && (
            <div className="px-5 py-4">
              <BackButton onClick={() => setScreen('home')} />
              <h2 className="text-white text-lg font-bold mb-4 text-center">خريطة إلمور</h2>
              <div
                className="relative rounded-xl overflow-hidden"
                style={{
                  background: '#2a5a2a',
                  height: '300px',
                  border: '2px solid rgba(255,255,255,0.1)',
                }}
              >
                {/* Roads */}
                <div className="absolute" style={{ left: '50%', top: 0, bottom: 0, width: '12px', background: '#333', transform: 'translateX(-50%)' }} />
                <div className="absolute" style={{ top: '50%', left: 0, right: 0, height: '12px', background: '#333', transform: 'translateY(-50%)' }} />

                {/* House */}
                <MapMarker x="50%" y="35%" color="#e8c170" label="بيت غامبول" />
                {/* School */}
                <MapMarker x="20%" y="70%" color="#c4a060" label="المدرسة" />
                {/* Restaurant */}
                <MapMarker x="78%" y="60%" color="#ffe066" label="جوي فول" />
                {/* Park */}
                <div className="absolute rounded-full" style={{ left: '42%', top: '48%', width: '30px', height: '30px', background: '#3a7a2a', border: '2px solid #2a5a1a' }} />
              </div>
              <p className="text-white/50 text-xs mt-2 text-center">المدينة مفتوحة بالكامل للاستكشاف</p>
            </div>
          )}

          {/* Missions screen */}
          {screen === 'missions' && (
            <div className="px-5 py-4">
              <BackButton onClick={() => setScreen('home')} />
              <h2 className="text-white text-lg font-bold mb-4 text-center">المهام</h2>
              {missionActive ? (
                <div className="p-4 rounded-xl" style={{ background: 'rgba(255,170,0,0.1)', border: '1px solid rgba(255,170,0,0.3)' }}>
                  <div className="text-yellow-400 text-sm font-bold mb-1">المهمة الحالية</div>
                  <div className="text-white text-lg font-bold mb-2">{missionTitle}</div>
                  <div className="text-white/60 text-sm mb-3">{missionDesc}</div>
                  <div className="flex items-center gap-2">
                    <span className="text-green-400 font-bold">المكافأة: {missionReward}$</span>
                  </div>
                </div>
              ) : (
                <div className="p-4 rounded-xl bg-white/5 border border-white/10 text-center">
                  <div className="text-3xl mb-2">🏆</div>
                  <div className="text-white font-bold">أكملت جميع المهام!</div>
                  <div className="text-white/60 text-sm mt-1">استمتع بالحرية في إلمور</div>
                </div>
              )}
              <div className="mt-4 text-white/40 text-xs text-center">
                المهام المكتملة: {missionCompletedCount}
              </div>
            </div>
          )}

          {/* Stats screen */}
          {screen === 'stats' && (
            <div className="px-5 py-4">
              <BackButton onClick={() => setScreen('home')} />
              <h2 className="text-white text-lg font-bold mb-4 text-center">الإحصائيات</h2>
              <div className="space-y-3">
                <StatRow label="الصحة" value={`${health}%`} icon="❤️" color="#ff4466" />
                <StatRow label="الطاقة" value={`${energy}%`} icon="⚡" color="#ff9933" />
                <StatRow label="المال" value={`${money}$`} icon="💰" color="#44cc66" />
                <StatRow label="مستوى المطلوبية" value={`${'⭐'.repeat(wantedLevel) || 'لا يوجد'}`} icon="⭐" color="#ffaa00" />
              </div>
            </div>
          )}
        </div>

        {/* Home button */}
        <button
          onClick={onClose}
          className="absolute bottom-3 left-1/2 -translate-x-1/2 w-10 h-10 rounded-full border-2 border-white/20 flex items-center justify-center text-white/40 text-xs hover:bg-white/10"
        >
          ✕
        </button>
      </div>
    </div>
  );
}

function BackButton({ onClick }: { onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="text-white/60 text-sm mb-3 flex items-center gap-1 hover:text-white"
    >
      → رجوع
    </button>
  );
}

function MapMarker({ x, y, color, label }: { x: string; y: string; color: string; label: string }) {
  return (
    <div className="absolute flex flex-col items-center" style={{ left: x, top: y, transform: 'translate(-50%, -50%)' }}>
      <div className="w-4 h-4 rounded-full" style={{ background: color, border: '2px solid white' }} />
      <span className="text-[8px] text-white mt-0.5 whitespace-nowrap" style={{ textShadow: '0 1px 2px black' }}>{label}</span>
    </div>
  );
}

function StatRow({ label, value, icon, color }: { label: string; value: string; icon: string; color: string }) {
  return (
    <div className="flex items-center gap-3 p-3 rounded-xl bg-white/5 border border-white/10">
      <span className="text-2xl">{icon}</span>
      <span className="text-white/80 text-sm">{label}</span>
      <span className="mr-auto text-white font-bold" style={{ color }}>{value}</span>
    </div>
  );
}
