import React, { useState, useRef, useEffect, useCallback } from "react";
import {
  Camera,
  Image as ImageIcon,
  RotateCcw,
  RotateCw,
  X,
  FlipHorizontal,
  Sparkles,
  AlertCircle,
  PlusCircle,
  FileText,
  CheckCircle2,
  Wand2,
} from "lucide-react";
import {
  compressAndResizeImage,
  captureVideoFrame,
  preprocessReceiptImage,
} from "../utils/imageUtils";
import { SAMPLE_RECEIPTS, SampleReceipt } from "../utils/sampleReceipts";
import { scanReceiptClient } from "../utils/geminiOcr";
import { CalculationItem, ScanResultPayload } from "../types";

interface CameraScannerProps {
  onClose: () => void;
  onScanComplete: (result: ScanResultPayload) => void;
  onAddManually: () => void;
}

export const CameraScanner: React.FC<CameraScannerProps> = ({
  onClose,
  onScanComplete,
  onAddManually,
}) => {
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [facingMode, setFacingMode] = useState<"environment" | "user">("environment");
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [processingStatus, setProcessingStatus] = useState<string>("Analyzing image...");
  const [capturedPreview, setCapturedPreview] = useState<string | null>(null);
  const [currentRotation, setCurrentRotation] = useState<number>(0);
  const [showSampleSelector, setShowSampleSelector] = useState<boolean>(false);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const rawImageRef = useRef<string | null>(null);

  // Initialize camera stream
  const startCamera = useCallback(async () => {
    setCameraError(null);
    if (stream) {
      stream.getTracks().forEach((track) => track.stop());
      setStream(null);
    }

    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error("Camera API is not supported by your browser or environment.");
      }

      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: { ideal: facingMode },
          width: { ideal: 1920 },
          height: { ideal: 1080 },
        },
        audio: false,
      });

      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
        videoRef.current.play().catch((err) => console.warn("Video play error:", err));
      }
    } catch (err: any) {
      console.warn("Camera init failed:", err);
      setCameraError(
        err?.message ||
          "Camera access was denied or not available. You can still select an image from gallery or try a sample receipt."
      );
    }
  }, [facingMode]);

  useEffect(() => {
    startCamera();
    return () => {
      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
      }
    };
  }, [facingMode]);

  // Clean up stream on unmount
  useEffect(() => {
    return () => {
      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
      }
    };
  }, [stream]);

  // Send preprocessed image to backend OCR endpoint
  const processImage = async (base64Image: string, dataUri: string) => {
    setIsProcessing(true);
    setProcessingStatus("Reading numbers with Gemini Vision AI...");

    try {
      const data = await scanReceiptClient(base64Image, "image/jpeg");

      if (!data.success) {
        throw new Error(data.error || "OCR request failed");
      }

      if (data.items && data.items.length > 0) {
        onScanComplete({
          items: data.items,
          unrelatedNumbers: data.unrelatedNumbers || [],
          detectedTotal: data.detectedTotal,
          notes: data.notes || `${data.items.length} amounts detected`,
          imagePreviewUrl: dataUri,
        });
        return;
      }

      // If no items were detected from this image
      setCameraError(
        "No price amounts were detected. You can add them manually or retake the photo."
      );
    } catch (err: any) {
      console.error("OCR process error:", err);
      setCameraError(
        err.message || "Could not process image. Please try again or enter amounts manually."
      );
    } finally {
      setIsProcessing(false);
    }
  };

  // Run full image preprocessing pipeline
  const runPreprocessAndScan = async (source: string | File, rotation = 0) => {
    setIsProcessing(true);
    setProcessingStatus("Enhancing image (crop, deskew, sharpen)...");

    try {
      const preprocessed = await preprocessReceiptImage(source, {
        autoCrop: true,
        autoDeskew: true,
        enhanceContrast: true,
        rotationDegrees: rotation,
      });

      setCapturedPreview(preprocessed.dataUri);
      await processImage(preprocessed.base64, preprocessed.dataUri);
    } catch (err: any) {
      console.warn("Preprocessing failed, falling back to standard resize:", err);
      try {
        const fallback = await compressAndResizeImage(
          source instanceof File ? source : new Blob([source])
        );
        setCapturedPreview(fallback.dataUri);
        await processImage(fallback.base64, fallback.dataUri);
      } catch (fallbackErr: any) {
        setCameraError(fallbackErr.message || "Failed to prepare image.");
        setIsProcessing(false);
      }
    }
  };

  // Capture current video frame
  const handleCapture = async () => {
    if (!videoRef.current) return;
    const captured = captureVideoFrame(videoRef.current);
    if (!captured) {
      setCameraError("Failed to capture snapshot from camera.");
      return;
    }

    rawImageRef.current = captured.dataUri;
    setCurrentRotation(0);
    await runPreprocessAndScan(captured.dataUri, 0);
  };

  // Handle gallery file selection
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const reader = new FileReader();
      reader.onload = async (ev) => {
        const rawUri = ev.target?.result as string;
        rawImageRef.current = rawUri;
        setCurrentRotation(0);
        await runPreprocessAndScan(file, 0);
      };
      reader.readAsDataURL(file);
    } catch (err: any) {
      setCameraError(err.message || "Failed to process selected image.");
    }
  };

  // Rotate preview 90 degrees and re-run OCR
  const handleRotateImage = async () => {
    if (!rawImageRef.current || isProcessing) return;
    const newRotation = (currentRotation + 90) % 360;
    setCurrentRotation(newRotation);
    await runPreprocessAndScan(rawImageRef.current, newRotation);
  };

  // Load a sample receipt (Supermarket Rice/Milk/Sugar/Oil prompt example)
  const handleSelectSample = (sample: SampleReceipt) => {
    setShowSampleSelector(false);
    setCapturedPreview(sample.svgDataUri);
    onScanComplete({
      items: sample.items,
      unrelatedNumbers: sample.unrelatedNumbers,
      detectedTotal: sample.detectedTotal,
      notes: `Scanned from ${sample.title}`,
      imagePreviewUrl: sample.svgDataUri,
    });
  };

  const handleFlipCamera = () => {
    setFacingMode((prev) => (prev === "environment" ? "user" : "environment"));
  };

  const handleRetake = () => {
    setCapturedPreview(null);
    setCameraError(null);
    setCurrentRotation(0);
    rawImageRef.current = null;
    startCamera();
  };

  return (
    <div
      id="camera-scanner-modal"
      className="fixed inset-0 z-50 bg-black/95 flex flex-col justify-between p-3 sm:p-5 text-white animate-in fade-in duration-200"
    >
      {/* Top Header */}
      <div className="flex items-center justify-between z-10 pt-1">
        <button
          id="btn-close-scanner"
          onClick={onClose}
          className="p-2 rounded-full bg-zinc-800/80 hover:bg-zinc-700 active:scale-95 text-zinc-200 transition-all cursor-pointer"
          title="Close scanner"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-zinc-900/80 border border-zinc-700/60 text-xs font-medium">
          <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
          <span>Receipt & Slip Scanner</span>
        </div>

        <button
          id="btn-sample-receipts"
          onClick={() => setShowSampleSelector(true)}
          className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-emerald-600/90 hover:bg-emerald-500 text-xs font-semibold active:scale-95 transition-all cursor-pointer shadow-sm"
          title="Try prompt sample receipts"
        >
          <FileText className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Try</span> Sample
        </button>
      </div>

      {/* Main Viewfinder Area */}
      <div className="relative flex-1 my-3 rounded-2xl overflow-hidden bg-zinc-950 flex items-center justify-center border border-zinc-800">
        {capturedPreview ? (
          <div className="relative w-full h-full flex items-center justify-center bg-zinc-900">
            <img
              src={capturedPreview}
              alt="Captured Receipt"
              className="w-full h-full object-contain"
            />
            {/* Rotate 90 deg button on preview */}
            {!isProcessing && (
              <button
                onClick={handleRotateImage}
                className="absolute top-3 right-3 px-3 py-1.5 rounded-full bg-black/70 hover:bg-black/90 backdrop-blur-md text-xs font-semibold text-zinc-200 border border-white/10 flex items-center gap-1.5 transition-all active:scale-95 cursor-pointer shadow-lg"
                title="Rotate image 90 degrees"
              >
                <RotateCw className="w-3.5 h-3.5 text-emerald-400" />
                Rotate 90°
              </button>
            )}

            {/* Preprocessing indicator badge */}
            <div className="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/30 text-[10px] text-emerald-300 font-medium flex items-center gap-1 backdrop-blur-md">
              <Wand2 className="w-3 h-3" />
              <span>Auto-Enhanced (Crop, Deskew, Sharpen)</span>
            </div>
          </div>
        ) : stream && !cameraError ? (
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="p-6 text-center max-w-sm flex flex-col items-center">
            <div className="w-14 h-14 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-400 mb-3">
              <Camera className="w-7 h-7" />
            </div>
            <h3 className="text-base font-semibold text-zinc-200 mb-1">Receipt Scanner</h3>
            <p className="text-xs text-zinc-400 mb-5 leading-relaxed">
              {cameraError ||
                "Align your handwritten slip, Pakistani shop parchi, or printed bill in good lighting."}
            </p>
            <div className="flex flex-col sm:flex-row gap-2.5 w-full">
              <button
                onClick={() => fileInputRef.current?.click()}
                className="flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-xs font-semibold text-white transition-all cursor-pointer"
              >
                <ImageIcon className="w-4 h-4" />
                Select Photo from Gallery
              </button>
              <button
                onClick={() => setShowSampleSelector(true)}
                className="flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold text-zinc-200 transition-all cursor-pointer"
              >
                <FileText className="w-4 h-4" />
                Try Sample Slip
              </button>
            </div>
          </div>
        )}

        {/* Framing Guides Overlay */}
        {!cameraError && !capturedPreview && (
          <div className="absolute inset-0 pointer-events-none p-6 sm:p-8 flex flex-col justify-between">
            <div className="flex justify-between">
              <div className="w-8 h-8 border-t-2 border-l-2 border-emerald-400 rounded-tl-lg" />
              <div className="w-8 h-8 border-t-2 border-r-2 border-emerald-400 rounded-tr-lg" />
            </div>
            <div className="self-center bg-black/60 backdrop-blur-md px-3 py-1 rounded-full text-[11px] text-zinc-300 border border-white/10 tracking-wide">
              Position handwritten or printed amounts inside frame
            </div>
            <div className="flex justify-between">
              <div className="w-8 h-8 border-b-2 border-l-2 border-emerald-400 rounded-bl-lg" />
              <div className="w-8 h-8 border-b-2 border-r-2 border-emerald-400 rounded-br-lg" />
            </div>
          </div>
        )}

        {/* Active Scanning Laser Animation */}
        {isProcessing && (
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm flex flex-col items-center justify-center z-20">
            <div className="relative w-48 h-48 rounded-2xl border-2 border-dashed border-emerald-400/60 overflow-hidden flex items-center justify-center mb-4 bg-emerald-950/20">
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-emerald-400 to-transparent animate-bounce shadow-lg shadow-emerald-400/50" />
              <Sparkles className="w-10 h-10 text-emerald-400 animate-pulse" />
            </div>
            <div className="text-sm font-semibold text-white tracking-wide">
              {processingStatus}
            </div>
            <p className="text-xs text-zinc-400 mt-1 max-w-xs text-center">
              Extracting item amounts and ignoring phone numbers, dates, and invoice codes...
            </p>
          </div>
        )}

        {/* Error Notification Overlay with fallback to Add Manually */}
        {cameraError && (
          <div className="absolute inset-x-4 bottom-4 bg-zinc-900/95 border border-zinc-700/80 rounded-2xl p-4 shadow-xl z-20 backdrop-blur-md">
            <div className="flex items-start gap-3 mb-3">
              <AlertCircle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="text-xs sm:text-sm font-semibold text-zinc-100">
                  {cameraError}
                </p>
                <p className="text-[11px] text-zinc-400 mt-1">
                  You can retake a clearer photo or enter/edit the numbers directly in the calculator list.
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              <button
                id="btn-error-retake"
                onClick={handleRetake}
                className="flex-1 py-2 px-3 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold text-zinc-200 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Retake Photo
              </button>
              <button
                id="btn-error-add-manually"
                onClick={onAddManually}
                className="flex-1 py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-xs font-semibold text-white transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <PlusCircle className="w-3.5 h-3.5" />
                Add Manually
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Hidden File Picker for Gallery */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleFileChange}
      />

      {/* Bottom Controls Bar */}
      <div className="flex items-center justify-around py-2 z-10">
        {/* Gallery Button */}
        <button
          id="btn-gallery-picker"
          onClick={() => fileInputRef.current?.click()}
          disabled={isProcessing}
          className="flex flex-col items-center gap-1 text-zinc-400 hover:text-white active:scale-95 transition-all p-2 cursor-pointer disabled:opacity-50"
          title="Pick from gallery"
        >
          <div className="w-11 h-11 rounded-full bg-zinc-800 flex items-center justify-center">
            <ImageIcon className="w-5 h-5" />
          </div>
          <span className="text-[11px] font-medium">Gallery</span>
        </button>

        {/* Shutter Button */}
        <button
          id="btn-shutter-snap"
          onClick={handleCapture}
          disabled={isProcessing || !stream}
          className="w-18 h-18 rounded-full bg-white p-1 border-4 border-zinc-700 hover:scale-105 active:scale-95 transition-all cursor-pointer disabled:opacity-40 disabled:scale-100 flex items-center justify-center shadow-lg shadow-white/10"
          title="Take photo"
        >
          <div className="w-full h-full rounded-full bg-emerald-500 border-2 border-white flex items-center justify-center">
            <Camera className="w-7 h-7 text-white" />
          </div>
        </button>

        {/* Flip Camera */}
        <button
          id="btn-flip-camera"
          onClick={handleFlipCamera}
          disabled={isProcessing || !stream}
          className="flex flex-col items-center gap-1 text-zinc-400 hover:text-white active:scale-95 transition-all p-2 cursor-pointer disabled:opacity-50"
          title="Switch front/rear camera"
        >
          <div className="w-11 h-11 rounded-full bg-zinc-800 flex items-center justify-center">
            <FlipHorizontal className="w-5 h-5" />
          </div>
          <span className="text-[11px] font-medium">Flip</span>
        </button>
      </div>

      {/* Sample Receipts Modal */}
      {showSampleSelector && (
        <div className="fixed inset-0 z-60 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-sm rounded-3xl bg-zinc-900 border border-zinc-800 p-5 shadow-2xl text-left">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h4 className="text-base font-bold text-zinc-100">Select a Sample Receipt</h4>
                <p className="text-xs text-zinc-400">
                  Instant test with realistic receipts and slips
                </p>
              </div>
              <button
                onClick={() => setShowSampleSelector(false)}
                className="p-1 rounded-full text-zinc-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2.5 my-4 max-h-[60vh] overflow-y-auto pr-1">
              {SAMPLE_RECEIPTS.map((sample) => (
                <div
                  key={sample.id}
                  onClick={() => handleSelectSample(sample)}
                  className="p-3 rounded-2xl bg-zinc-800/80 hover:bg-zinc-800 border border-zinc-700/60 hover:border-emerald-500/60 cursor-pointer transition-all active:scale-98"
                >
                  <div className="flex items-start justify-between mb-1">
                    <span className="text-xs font-bold text-zinc-100">{sample.title}</span>
                    <span className="text-xs font-bold text-emerald-400">
                      Total: {sample.detectedTotal}
                    </span>
                  </div>
                  <p className="text-[11px] text-zinc-400 mb-2">{sample.description}</p>
                  <div className="flex flex-wrap gap-1">
                    {sample.items.map((it) => (
                      <span
                        key={it.id}
                        className="text-[10px] px-2 py-0.5 rounded-md bg-zinc-900 text-zinc-300 font-mono"
                      >
                        {it.label}: {it.amount}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            <button
              onClick={() => setShowSampleSelector(false)}
              className="w-full py-2.5 rounded-xl bg-zinc-800 text-xs font-semibold text-zinc-300 hover:bg-zinc-700 transition-all cursor-pointer"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
