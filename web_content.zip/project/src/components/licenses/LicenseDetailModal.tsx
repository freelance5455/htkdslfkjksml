import { useEffect, useState, type FormEvent } from 'react';
import { Smartphone, Trash2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { errorMessage } from '@/lib/errors';
import { getLicenseState, maskedLicenseKey } from '@/lib/licenseKeys';
import type { ActivationRow, Client, LicenseKeyRow } from '@/types/studio';
import { Alert, Badge, Button, ConfirmModal, EmptyState, Field, IconButton, Modal, SelectInput, Spinner, TextInput } from '@/components/ui';

interface LicenseDetailModalProps {
  license: LicenseKeyRow | null;
  clients: Client[];
  onClose: () => void;
  onChanged: () => void;
}

const DATE_FORMAT = new Intl.DateTimeFormat('pt-BR', { dateStyle: 'medium', timeStyle: 'short' });

function toDateInput(value: string | null): string {
  if (!value) return '';
  const date = new Date(value);
  const offset = date.getTimezoneOffset() * 60000;
  return new Date(date.getTime() - offset).toISOString().slice(0, 10);
}

function endOfDayIso(dateInput: string): string {
  return new Date(`${dateInput}T23:59:59`).toISOString();
}

export function LicenseDetailModal({ license, clients, onClose, onChanged }: LicenseDetailModalProps) {
  const [clientId, setClientId] = useState('');
  const [expiry, setExpiry] = useState('');
  const [maxActivations, setMaxActivations] = useState('1');
  const [activations, setActivations] = useState<ActivationRow[] | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [unbindTarget, setUnbindTarget] = useState<ActivationRow | null>(null);
  const [unbinding, setUnbinding] = useState(false);
  const [unbindError, setUnbindError] = useState<string | null>(null);

  const licenseId = license?.id ?? null;

  useEffect(() => {
    if (!license) return;
    setClientId(license.client_id ?? '');
    setExpiry(toDateInput(license.expires_at));
    setMaxActivations(String(license.max_activations));
    setFormError(null);
    setActivations(null);
    setLoadError(null);
    loadActivations(license.id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [licenseId]);

  const loadActivations = async (id: string) => {
    const { data, error } = await supabase
      .from('activations')
      .select('*')
      .eq('license_key_id', id)
      .order('activated_at', { ascending: false })
      .returns<ActivationRow[]>();
    if (error) {
      setLoadError(errorMessage(error));
      return;
    }
    setActivations(data ?? []);
  };

  if (!license) return null;

  const usedInstallations = activations?.length ?? license.activations[0]?.count ?? 0;
  const state = getLicenseState(license);

  const handleSave = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setFormError(null);

    const max = Number(maxActivations);
    if (!Number.isInteger(max) || max < 1 || max > 100) {
      setFormError('Informe um limite de instalações entre 1 e 100.');
      return;
    }
    if (activations && max < activations.length) {
      setFormError(`Esta KEY já tem ${activations.length} instalação(ões). O limite não pode ser menor que isso.`);
      return;
    }

    setSaving(true);
    const { error } = await supabase
      .from('license_keys')
      .update({
        client_id: clientId || null,
        expires_at: expiry ? endOfDayIso(expiry) : null,
        max_activations: max,
      })
      .eq('id', license.id);
    setSaving(false);

    if (error) {
      setFormError(errorMessage(error));
      return;
    }
    onChanged();
  };

  const handleUnbind = async () => {
    if (!unbindTarget) return;
    setUnbinding(true);
    setUnbindError(null);
    const { error } = await supabase.from('activations').delete().eq('id', unbindTarget.id);
    setUnbinding(false);
    if (error) {
      setUnbindError(errorMessage(error));
      return;
    }
    setUnbindTarget(null);
    await loadActivations(license.id);
    onChanged();
  };

  return (
    <>
      <Modal
        open
        title="Detalhes da licença"
        description={`${maskedLicenseKey(license.key_prefix)} · ${license.app?.name ?? 'Aplicativo removido'}`}
        onClose={onClose}
        size="lg"
        footer={
          <>
            <Button variant="secondary" onClick={onClose} disabled={saving}>
              Fechar
            </Button>
            <Button type="submit" form="license-form" loading={saving}>
              Salvar alterações
            </Button>
          </>
        }
      >
        <div className="space-y-8">
          <div className="flex flex-wrap items-center gap-3 text-sm text-graphite-300">
            <Badge tone={state === 'active' ? 'success' : state === 'expired' ? 'warning' : 'danger'}>
              {state === 'active' ? 'Ativa' : state === 'expired' ? 'Vencida' : 'Revogada'}
            </Badge>
            <span>
              {usedInstallations} de {license.max_activations} instalação(ões) em uso
            </span>
          </div>

          <form id="license-form" onSubmit={handleSave} className="grid gap-5 sm:grid-cols-2" noValidate>
            <div className="sm:col-span-2">
              <Field label="Cliente">
                <SelectInput value={clientId} onChange={(event) => setClientId(event.target.value)}>
                  <option value="">Sem cliente</option>
                  {clients.map((client) => (
                    <option key={client.id} value={client.id}>
                      {client.name}
                    </option>
                  ))}
                </SelectInput>
              </Field>
            </div>
            <Field label="Vencimento" hint="Deixe em branco para não vencer.">
              <TextInput type="date" value={expiry} onChange={(event) => setExpiry(event.target.value)} />
            </Field>
            <Field label="Instalações permitidas">
              <TextInput
                type="number"
                inputMode="numeric"
                min={1}
                max={100}
                value={maxActivations}
                onChange={(event) => setMaxActivations(event.target.value)}
              />
            </Field>
            {formError ? (
              <div className="sm:col-span-2">
                <Alert>{formError}</Alert>
              </div>
            ) : null}
          </form>

          <section aria-labelledby="installations-heading" className="space-y-3">
            <h3 id="installations-heading" className="font-display text-sm font-semibold text-graphite-50">
              Instalações vinculadas
            </h3>
            {loadError ? <Alert>{loadError}</Alert> : null}
            {activations === null && !loadError ? (
              <Spinner label="Carregando instalações" />
            ) : activations && activations.length === 0 ? (
              <EmptyState icon={Smartphone} title="Nenhuma instalação" description="Esta KEY ainda não foi ativada em nenhum dispositivo." />
            ) : activations ? (
              <ul className="divide-y divide-graphite-700 rounded-xl border border-graphite-700">
                {activations.map((activation) => (
                  <li key={activation.id} className="flex items-center justify-between gap-4 px-4 py-3">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-medium text-graphite-100">{activation.device_label ?? 'Dispositivo sem nome'}</p>
                      <p className="text-xs text-graphite-400">Ativada em {DATE_FORMAT.format(new Date(activation.activated_at))}</p>
                    </div>
                    <IconButton
                      icon={Trash2}
                      label="Desvincular instalação"
                      tone="danger"
                      onClick={() => {
                        setUnbindError(null);
                        setUnbindTarget(activation);
                      }}
                    />
                  </li>
                ))}
              </ul>
            ) : null}
          </section>
        </div>
      </Modal>

      <ConfirmModal
        open={unbindTarget !== null}
        title="Desvincular instalação"
        message="O dispositivo perderá o acesso ao VT ACCESS e poderá ativar a KEY novamente, desde que ainda haja vagas disponíveis."
        confirmLabel="Desvincular"
        busy={unbinding}
        error={unbindError}
        onConfirm={handleUnbind}
        onClose={() => setUnbindTarget(null)}
      />
    </>
  );
}
