import React, { useState } from "react";
import {
  Copy,
  Share2,
  RotateCcw,
  RefreshCw,
  Check,
  CheckCircle2,
  Receipt,
  Calculator,
  ExternalLink,
} from "lucide-react";
import { CalculationItem, AppSettings } from "../types";

interface ResultScreenProps {
  items: CalculationItem[];
  total: number;
  settings: AppSettings;
  onCopy: () => void;
  onShare: () => void;
  onRetakePhoto: () => void;
  onCalculateAgain: () => void;
  onDone: () => void;
}

export const ResultScreen: React.FC<ResultScreenProps> = ({
  items,
  total,
  settings,
  onRetakePhoto,
  onCalculateAgain,
  onDone,
}) => {
  const [copied, setCopied] = useState<boolean>(false);
  const [shared, setShared] = useState<boolean>(false);

  // Generate formula string: e.g. "100 + 250 + 75 + 500"
  const formulaString = items.map((it) => it.amount).join(" + ");
  const itemizedFormulaString = items.map((it) => `${it.label} (${it.amount})`).join(" + ");

  const fullShareText = `Smart Calculator Receipt Total:\n${items
    .map((it) => `• ${it.label}: ${settings.currency}${it.amount}`)
    .join("\n")}\n\nCalculation: ${formulaString}\nTOTAL = ${settings.currency}${total.toLocaleString()}`;

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(fullShareText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: "Receipt Calculation Result",
          text: fullShareText,
        });
        setShared(true);
        setTimeout(() => setShared(false), 2000);
      } catch (err) {
        // User cancelled or share failed, fallback to copy
        handleCopy();
      }
    } else {
      handleCopy();
    }
  };

  return (
    <div
      id="calculation-result-screen"
      className="flex flex-col h-full w-full max-w-lg mx-auto p-4 justify-between animate-in fade-in duration-200"
    >
      <div className="space-y-4">
        {/* Header Badge */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-emerald-100 dark:bg-emerald-950 flex items-center justify-center text-emerald-600 dark:text-emerald-400">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[11px] font-bold tracking-wider uppercase text-emerald-600 dark:text-emerald-400">
                Verified Sum
              </span>
              <h2 className="text-xl sm:text-2xl font-black text-zinc-900 dark:text-zinc-100">
                Calculation Result
              </h2>
            </div>
          </div>
          <span className="text-xs px-2.5 py-1 rounded-full bg-zinc-200 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300 font-medium">
            {items.length} {items.length === 1 ? "item" : "items"}
          </span>
        </div>

        {/* Highlighted Result Billboard */}
        <div className="rounded-3xl bg-zinc-900 dark:bg-zinc-950 text-white p-6 sm:p-7 shadow-xl border border-zinc-800 relative overflow-hidden">
          {/* Subtle background glow */}
          <div className="absolute top-0 right-0 w-48 h-48 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

          {/* Mathematical formula breakdown */}
          <div className="text-xs sm:text-sm text-zinc-400 font-mono tracking-wide overflow-x-auto whitespace-nowrap scrollbar-none pb-2">
            {formulaString}
          </div>

          {/* TOTAL Display */}
          <div className="pt-2 border-t border-zinc-800/80 flex items-baseline justify-between gap-2">
            <span className="text-xs sm:text-sm font-bold tracking-wider uppercase text-zinc-400">
              TOTAL =
            </span>
            <div
              id="result-total-display"
              className="text-3xl sm:text-4xl font-black text-emerald-400 tracking-tight font-mono"
            >
              {settings.currency}
              {total.toLocaleString()}
            </div>
          </div>
        </div>

        {/* Breakdown of items used */}
        <div className="rounded-2xl bg-zinc-100 dark:bg-zinc-900/90 border border-zinc-200 dark:border-zinc-800 p-4 max-h-[220px] overflow-y-auto">
          <div className="text-xs font-bold uppercase tracking-wider text-zinc-500 dark:text-zinc-400 mb-2">
            Included Amounts Breakdown
          </div>
          <div className="space-y-2">
            {items.map((it) => (
              <div
                key={it.id}
                className="flex items-center justify-between text-xs sm:text-sm py-1 border-b border-zinc-200/60 dark:border-zinc-800/60 last:border-none"
              >
                <span className="text-zinc-700 dark:text-zinc-300 font-medium truncate pr-2">
                  {it.label}
                </span>
                <span className="font-mono font-bold text-zinc-900 dark:text-zinc-100 shrink-0">
                  {settings.currency}
                  {it.amount.toLocaleString()}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Buttons as required by Prompt Section 6:
          - Copy
          - Share
          - Retake Photo
          - Calculate Again
          - Done
      */}
      <div className="pt-3 border-t border-zinc-200 dark:border-zinc-800 space-y-2.5 shrink-0">
        {/* Top pair: Copy & Share */}
        <div className="grid grid-cols-2 gap-2.5">
          <button
            id="btn-result-copy"
            onClick={handleCopy}
            className="py-3 px-4 rounded-xl bg-zinc-200/80 hover:bg-zinc-300 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-xs sm:text-sm font-bold text-zinc-800 dark:text-zinc-200 flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer shadow-xs"
          >
            {copied ? (
              <>
                <Check className="w-4 h-4 text-emerald-500" />
                <span>Copied!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4 text-zinc-500" />
                <span>Copy</span>
              </>
            )}
          </button>

          <button
            id="btn-result-share"
            onClick={handleShare}
            className="py-3 px-4 rounded-xl bg-zinc-200/80 hover:bg-zinc-300 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-xs sm:text-sm font-bold text-zinc-800 dark:text-zinc-200 flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer shadow-xs"
          >
            {shared ? (
              <>
                <Check className="w-4 h-4 text-emerald-500" />
                <span>Shared!</span>
              </>
            ) : (
              <>
                <Share2 className="w-4 h-4 text-zinc-500" />
                <span>Share</span>
              </>
            )}
          </button>
        </div>

        {/* Middle pair: Retake Photo & Calculate Again */}
        <div className="grid grid-cols-2 gap-2.5">
          <button
            id="btn-result-retake"
            onClick={onRetakePhoto}
            className="py-3 px-4 rounded-xl border border-zinc-300 dark:border-zinc-700 hover:bg-zinc-100 dark:hover:bg-zinc-800 text-xs sm:text-sm font-bold text-zinc-700 dark:text-zinc-300 flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Retake Photo</span>
          </button>

          <button
            id="btn-result-again"
            onClick={onCalculateAgain}
            className="py-3 px-4 rounded-xl border border-zinc-300 dark:border-zinc-700 hover:bg-zinc-100 dark:hover:bg-zinc-800 text-xs sm:text-sm font-bold text-zinc-700 dark:text-zinc-300 flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer"
          >
            <RefreshCw className="w-4 h-4" />
            <span>Calculate Again</span>
          </button>
        </div>

        {/* Primary Done Button */}
        <button
          id="btn-result-done"
          onClick={onDone}
          className="w-full py-3.5 sm:py-4 px-6 rounded-2xl bg-emerald-600 hover:bg-emerald-500 active:scale-98 text-white font-black text-base flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/25 transition-all cursor-pointer"
        >
          <Calculator className="w-5 h-5" />
          <span>Done (Use in Calculator)</span>
        </button>
      </div>
    </div>
  );
};
