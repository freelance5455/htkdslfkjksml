import React, { useEffect, useCallback } from "react";
import { Camera, Delete, CornerDownLeft, Sparkles, RotateCcw } from "lucide-react";
import { formatNumberDisplay, sanitizeNumber } from "../utils/calculator";
import { playKeySound, triggerHaptic } from "../utils/sound";
import { AppSettings } from "../types";

interface MainCalculatorProps {
  settings: AppSettings;
  onOpenScanner: () => void;
  onSaveHistory: (formula: string, total: number, source?: "manual" | "receipt_scan") => void;
  externalTotal?: number | null;
  onClearExternalTotal?: () => void;
}

export const MainCalculator: React.FC<MainCalculatorProps> = ({
  settings,
  onOpenScanner,
  onSaveHistory,
  externalTotal,
  onClearExternalTotal,
}) => {
  const [display, setDisplay] = React.useState<string>("0");
  const [expression, setExpression] = React.useState<string>("");
  const [prevCalculation, setPrevCalculation] = React.useState<string>("");
  const [isNewInput, setIsNewInput] = React.useState<boolean>(true);

  // If a total was passed in from scanner result
  useEffect(() => {
    if (externalTotal !== undefined && externalTotal !== null) {
      setDisplay(String(externalTotal));
      setExpression("");
      setPrevCalculation(`Imported from Receipt: ${settings.currency}${externalTotal}`);
      setIsNewInput(true);
      if (onClearExternalTotal) onClearExternalTotal();
    }
  }, [externalTotal, settings.currency, onClearExternalTotal]);

  const triggerFeedback = useCallback(
    (type: "number" | "operator" | "action" | "equal" = "number") => {
      if (settings.soundEnabled) playKeySound(type);
      if (settings.vibrationEnabled) triggerHaptic(12);
    },
    [settings.soundEnabled, settings.vibrationEnabled]
  );

  const handleDigit = useCallback(
    (digit: string) => {
      triggerFeedback("number");
      setDisplay((prev) => {
        if (isNewInput || prev === "0" || prev === "Error") {
          setIsNewInput(false);
          return digit;
        }
        if (prev.length >= 15) return prev; // Limit max digits
        return prev + digit;
      });
    },
    [isNewInput, triggerFeedback]
  );

  const handleDecimal = useCallback(() => {
    triggerFeedback("number");
    setDisplay((prev) => {
      if (isNewInput || prev === "Error") {
        setIsNewInput(false);
        return "0.";
      }
      if (prev.includes(".")) return prev;
      return prev + ".";
    });
  }, [isNewInput, triggerFeedback]);

  const handleOperator = useCallback(
    (op: string) => {
      triggerFeedback("operator");
      const currentVal = display;
      if (currentVal === "Error") return;

      if (expression && !isNewInput) {
        // Append currentVal and next operator
        setExpression((prev) => `${prev} ${currentVal} ${op}`);
      } else if (expression && isNewInput) {
        // Replace trailing operator
        setExpression((prev) => prev.replace(/[\+\−\×\÷]\s*$/, `${op} `));
      } else {
        setExpression(`${currentVal} ${op}`);
      }

      setIsNewInput(true);
    },
    [display, expression, isNewInput, triggerFeedback]
  );

  const handleClear = useCallback(() => {
    triggerFeedback("action");
    setDisplay("0");
    setExpression("");
    setIsNewInput(true);
  }, [triggerFeedback]);

  const handleBackspace = useCallback(() => {
    triggerFeedback("action");
    setDisplay((prev) => {
      if (prev === "Error" || isNewInput) return "0";
      if (prev.length <= 1 || (prev.length === 2 && prev.startsWith("-"))) {
        return "0";
      }
      return prev.slice(0, -1);
    });
  }, [isNewInput, triggerFeedback]);

  const handleToggleSign = useCallback(() => {
    triggerFeedback("action");
    setDisplay((prev) => {
      if (prev === "0" || prev === "Error") return prev;
      if (prev.startsWith("-")) return prev.slice(1);
      return "-" + prev;
    });
  }, [triggerFeedback]);

  const handlePercentage = useCallback(() => {
    triggerFeedback("operator");
    setDisplay((prev) => {
      const num = parseFloat(prev);
      if (isNaN(num)) return "0";
      const res = sanitizeNumber(num / 100);
      return String(res);
    });
  }, [triggerFeedback]);

  const handleEquals = useCallback(() => {
    triggerFeedback("equal");
    if (!expression && isNewInput) return;

    const fullFormula = expression ? `${expression} ${display}` : display;
    const sanitizedFormula = fullFormula
      .replace(/×/g, "*")
      .replace(/÷/g, "/")
      .replace(/−/g, "-")
      .replace(/,/g, "")
      .trim();

    try {
      // Safe math evaluation
      // eslint-disable-next-line no-new-func
      const result = Function(`"use strict"; return (${sanitizedFormula})`)();
      if (typeof result === "number" && !isNaN(result) && isFinite(result)) {
        const cleanResult = sanitizeNumber(result);
        const resultStr = String(cleanResult);
        setPrevCalculation(`${fullFormula} = ${cleanResult}`);
        setDisplay(resultStr);
        setExpression("");
        setIsNewInput(true);

        // Save to calculation history
        onSaveHistory(fullFormula, cleanResult, "manual");
      } else {
        setDisplay("Error");
        setIsNewInput(true);
      }
    } catch {
      setDisplay("Error");
      setIsNewInput(true);
    }
  }, [display, expression, isNewInput, onSaveHistory, triggerFeedback]);

  // Physical keyboard listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't intercept if focus is inside an input/textarea
      if (
        document.activeElement?.tagName === "INPUT" ||
        document.activeElement?.tagName === "TEXTAREA"
      ) {
        return;
      }

      if (e.key >= "0" && e.key <= "9") {
        e.preventDefault();
        handleDigit(e.key);
      } else if (e.key === ".") {
        e.preventDefault();
        handleDecimal();
      } else if (e.key === "+") {
        e.preventDefault();
        handleOperator("+");
      } else if (e.key === "-") {
        e.preventDefault();
        handleOperator("−");
      } else if (e.key === "*") {
        e.preventDefault();
        handleOperator("×");
      } else if (e.key === "/") {
        e.preventDefault();
        handleOperator("÷");
      } else if (e.key === "%") {
        e.preventDefault();
        handlePercentage();
      } else if (e.key === "Enter" || e.key === "=") {
        e.preventDefault();
        handleEquals();
      } else if (e.key === "Backspace") {
        e.preventDefault();
        handleBackspace();
      } else if (e.key === "Escape" || e.key.toLowerCase() === "c") {
        e.preventDefault();
        handleClear();
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [
    handleDigit,
    handleDecimal,
    handleOperator,
    handleEquals,
    handleBackspace,
    handleClear,
    handlePercentage,
  ]);

  return (
    <div className="flex flex-col h-full w-full max-w-md mx-auto justify-between px-3 sm:px-4 pt-2 pb-2">
      {/* Top Banner with Camera CTA */}
      <div className="flex items-center justify-between py-1 px-1">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
          <span className="text-xs font-semibold tracking-wider uppercase text-zinc-500 dark:text-zinc-400">
            Standard & Receipt Calc
          </span>
        </div>
        <button
          id="btn-scan-receipt-top"
          onClick={onOpenScanner}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800/80 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 active:scale-95 transition-all shadow-xs"
        >
          <Camera className="w-3.5 h-3.5" />
          <span>Scan Receipt</span>
        </button>
      </div>

      {/* Screen Display Area */}
      <div className="relative rounded-3xl bg-zinc-100 dark:bg-zinc-900/90 border border-zinc-200 dark:border-zinc-800 p-5 sm:p-6 mb-3 shadow-inner flex flex-col justify-end min-h-[140px] sm:min-h-[160px]">
        {/* Past History / Active Formula */}
        <div className="text-right overflow-x-auto whitespace-nowrap text-zinc-400 dark:text-zinc-500 text-sm sm:text-base font-medium min-h-[22px] tracking-wide mb-1 scrollbar-none">
          {expression ? (
            <span className="text-zinc-600 dark:text-zinc-300 font-semibold">{expression}</span>
          ) : prevCalculation ? (
            <span>{prevCalculation}</span>
          ) : (
            <span className="opacity-0">0</span>
          )}
        </div>

        {/* Big Main Display */}
        <div className="flex items-baseline justify-end gap-1.5 overflow-hidden">
          {settings.currency && (
            <span className="text-xl sm:text-2xl font-bold text-zinc-400 dark:text-zinc-500">
              {settings.currency}
            </span>
          )}
          <div
            id="calculator-display"
            className="text-right font-semibold tracking-tight text-zinc-900 dark:text-zinc-50 select-all overflow-x-auto whitespace-nowrap scrollbar-none transition-all"
            style={{
              fontSize:
                display.length > 12
                  ? "1.75rem"
                  : display.length > 8
                  ? "2.4rem"
                  : "3.25rem",
              lineHeight: 1.15,
            }}
          >
            {formatNumberDisplay(display)}
          </div>
        </div>
      </div>

      {/* Calculator Keypad Grid */}
      <div className="grid grid-cols-4 gap-2.5 sm:gap-3">
        {/* Row 1: Clear, Backspace, %, Division */}
        <button
          id="calc-btn-clear"
          onClick={handleClear}
          className="h-14 sm:h-16 rounded-2xl bg-zinc-200/80 hover:bg-zinc-300 dark:bg-zinc-800/80 dark:hover:bg-zinc-700 active:scale-95 text-rose-600 dark:text-rose-400 text-lg font-bold transition-all shadow-xs flex items-center justify-center cursor-pointer"
        >
          C
        </button>

        <button
          id="calc-btn-backspace"
          onClick={handleBackspace}
          aria-label="Backspace"
          className="h-14 sm:h-16 rounded-2xl bg-zinc-200/80 hover:bg-zinc-300 dark:bg-zinc-800/80 dark:hover:bg-zinc-700 active:scale-95 text-zinc-700 dark:text-zinc-200 text-lg font-bold transition-all shadow-xs flex items-center justify-center cursor-pointer"
        >
          <Delete className="w-5 h-5" />
        </button>

        <button
          id="calc-btn-percent"
          onClick={handlePercentage}
          className="h-14 sm:h-16 rounded-2xl bg-zinc-200/80 hover:bg-zinc-300 dark:bg-zinc-800/80 dark:hover:bg-zinc-700 active:scale-95 text-zinc-700 dark:text-zinc-200 text-lg font-bold transition-all shadow-xs flex items-center justify-center cursor-pointer"
        >
          %
        </button>

        <button
          id="calc-btn-divide"
          onClick={() => handleOperator("÷")}
          className="h-14 sm:h-16 rounded-2xl bg-amber-500/15 hover:bg-amber-500/25 dark:bg-amber-500/20 dark:hover:bg-amber-500/30 active:scale-95 text-amber-600 dark:text-amber-400 text-2xl font-bold transition-all shadow-xs flex items-center justify-center cursor-pointer"
        >
          ÷
        </button>

        {/* Row 2: 7, 8, 9, Multiplication */}
        <button
          id="calc-btn-7"
          onClick={() => handleDigit("7")}
          className="h-14 sm:h-16 rounded-2xl bg-white hover:bg-zinc-100 dark:bg-zinc-800/50 dark:hover:bg-zinc-800 active:scale-95 text-zinc-900 dark:text-zinc-100 text-2xl font-semibold border border-zinc-200/70 dark:border-zinc-700/50 transition-all shadow-xs flex items-center justify-center cursor-pointer"
        >
          7
        </button>
        <button
          id="calc-btn-8"
          onClick={() => handleDigit("8")}
          className="h-14 sm:h-16 rounded-2xl bg-white hover:bg-zinc-100 dark:bg-zinc-800/50 dark:hover:bg-zinc-800 active:scale-95 text-zinc-900 dark:text-zinc-100 text-2xl font-semibold border border-zinc-200/70 dark:border-zinc-700/50 transition-all shadow-xs flex items-center justify-center cursor-pointer"
        >
          8
        </button>
        <button
          id="calc-btn-9"
          onClick={() => handleDigit("9")}
          className="h-14 sm:h-16 rounded-2xl bg-white hover:bg-zinc-100 dark:bg-zinc-800/50 dark:hover:bg-zinc-800 active:scale-95 text-zinc-900 dark:text-zinc-100 text-2xl font-semibold border border-zinc-200/70 dark:border-zinc-700/50 transition-all shadow-xs flex items-center justify-center cursor-pointer"
        >
          9
        </button>
        <button
          id="calc-btn-multiply"
          onClick={() => handleOperator("×")}
          className="h-14 sm:h-16 rounded-2xl bg-amber-500/15 hover:bg-amber-500/25 dark:bg-amber-500/20 dark:hover:bg-amber-500/30 active:scale-95 text-amber-600 dark:text-amber-400 text-2xl font-bold transition-all shadow-xs flex items-center justify-center cursor-pointer"
        >
          ×
        </button>

        {/* Row 3: 4, 5, 6, Subtraction */}
        <button
          id="calc-btn-4"
          onClick={() => handleDigit("4")}
          className="h-14 sm:h-16 rounded-2xl bg-white hover:bg-zinc-100 dark:bg-zinc-800/50 dark:hover:bg-zinc-800 active:scale-95 text-zinc-900 dark:text-zinc-100 text-2xl font-semibold border border-zinc-200/70 dark:border-zinc-700/50 transition-all shadow-xs flex items-center justify-center cursor-pointer"
        >
          4
        </button>
        <button
          id="calc-btn-5"
          onClick={() => handleDigit("5")}
          className="h-14 sm:h-16 rounded-2xl bg-white hover:bg-zinc-100 dark:bg-zinc-800/50 dark:hover:bg-zinc-800 active:scale-95 text-zinc-900 dark:text-zinc-100 text-2xl font-semibold border border-zinc-200/70 dark:border-zinc-700/50 transition-all shadow-xs flex items-center justify-center cursor-pointer"
        >
          5
        </button>
        <button
          id="calc-btn-6"
          onClick={() => handleDigit("6")}
          className="h-14 sm:h-16 rounded-2xl bg-white hover:bg-zinc-100 dark:bg-zinc-800/50 dark:hover:bg-zinc-800 active:scale-95 text-zinc-900 dark:text-zinc-100 text-2xl font-semibold border border-zinc-200/70 dark:border-zinc-700/50 transition-all shadow-xs flex items-center justify-center cursor-pointer"
        >
          6
        </button>
        <button
          id="calc-btn-subtract"
          onClick={() => handleOperator("−")}
          className="h-14 sm:h-16 rounded-2xl bg-amber-500/15 hover:bg-amber-500/25 dark:bg-amber-500/20 dark:hover:bg-amber-500/30 active:scale-95 text-amber-600 dark:text-amber-400 text-2xl font-bold transition-all shadow-xs flex items-center justify-center cursor-pointer"
        >
          −
        </button>

        {/* Row 4: 1, 2, 3, Addition */}
        <button
          id="calc-btn-1"
          onClick={() => handleDigit("1")}
          className="h-14 sm:h-16 rounded-2xl bg-white hover:bg-zinc-100 dark:bg-zinc-800/50 dark:hover:bg-zinc-800 active:scale-95 text-zinc-900 dark:text-zinc-100 text-2xl font-semibold border border-zinc-200/70 dark:border-zinc-700/50 transition-all shadow-xs flex items-center justify-center cursor-pointer"
        >
          1
        </button>
        <button
          id="calc-btn-2"
          onClick={() => handleDigit("2")}
          className="h-14 sm:h-16 rounded-2xl bg-white hover:bg-zinc-100 dark:bg-zinc-800/50 dark:hover:bg-zinc-800 active:scale-95 text-zinc-900 dark:text-zinc-100 text-2xl font-semibold border border-zinc-200/70 dark:border-zinc-700/50 transition-all shadow-xs flex items-center justify-center cursor-pointer"
        >
          2
        </button>
        <button
          id="calc-btn-3"
          onClick={() => handleDigit("3")}
          className="h-14 sm:h-16 rounded-2xl bg-white hover:bg-zinc-100 dark:bg-zinc-800/50 dark:hover:bg-zinc-800 active:scale-95 text-zinc-900 dark:text-zinc-100 text-2xl font-semibold border border-zinc-200/70 dark:border-zinc-700/50 transition-all shadow-xs flex items-center justify-center cursor-pointer"
        >
          3
        </button>
        <button
          id="calc-btn-add"
          onClick={() => handleOperator("+")}
          className="h-14 sm:h-16 rounded-2xl bg-amber-500/15 hover:bg-amber-500/25 dark:bg-amber-500/20 dark:hover:bg-amber-500/30 active:scale-95 text-amber-600 dark:text-amber-400 text-2xl font-bold transition-all shadow-xs flex items-center justify-center cursor-pointer"
        >
          +
        </button>

        {/* Row 5: 📷 Camera Scanner (Key requirement: "Camera button 📷 clearly visible on main screen"), 0, Decimal, Equals */}
        <button
          id="calc-btn-camera"
          onClick={onOpenScanner}
          aria-label="Scan receipt camera"
          title="Scan handwritten or printed receipt"
          className="h-14 sm:h-16 rounded-2xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white transition-all shadow-md shadow-emerald-600/20 flex flex-col items-center justify-center gap-0.5 cursor-pointer"
        >
          <Camera className="w-5 h-5" />
          <span className="text-[10px] font-bold tracking-tight uppercase">Scan</span>
        </button>

        <button
          id="calc-btn-0"
          onClick={() => handleDigit("0")}
          className="h-14 sm:h-16 rounded-2xl bg-white hover:bg-zinc-100 dark:bg-zinc-800/50 dark:hover:bg-zinc-800 active:scale-95 text-zinc-900 dark:text-zinc-100 text-2xl font-semibold border border-zinc-200/70 dark:border-zinc-700/50 transition-all shadow-xs flex items-center justify-center cursor-pointer"
        >
          0
        </button>

        <button
          id="calc-btn-dot"
          onClick={handleDecimal}
          className="h-14 sm:h-16 rounded-2xl bg-white hover:bg-zinc-100 dark:bg-zinc-800/50 dark:hover:bg-zinc-800 active:scale-95 text-zinc-900 dark:text-zinc-100 text-2xl font-bold border border-zinc-200/70 dark:border-zinc-700/50 transition-all shadow-xs flex items-center justify-center cursor-pointer"
        >
          .
        </button>

        <button
          id="calc-btn-equals"
          onClick={handleEquals}
          className="h-14 sm:h-16 rounded-2xl bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white text-2xl font-bold transition-all shadow-md shadow-emerald-600/25 flex items-center justify-center cursor-pointer"
        >
          =
        </button>
      </div>
    </div>
  );
};
