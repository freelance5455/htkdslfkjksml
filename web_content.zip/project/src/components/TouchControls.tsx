import { useRef, useState, useEffect } from 'react';

interface Props {
  onMove: (x: number, y: number) => void;
}

export function TouchJoystick({ onMove }: Props) {
  const baseRef = useRef<HTMLDivElement>(null);
  const [knobPos, setKnobPos] = useState({ x: 0, y: 0 });
  const [active, setActive] = useState(false);
  const touchId = useRef<number | null>(null);
  const baseRadius = 60;

  const handleStart = (e: React.TouchEvent) => {
    e.preventDefault();
    const touch = e.changedTouches[0];
    touchId.current = touch.identifier;
    setActive(true);
    updateKnob(touch.clientX, touch.clientY);
  };

  const handleMove = (e: React.TouchEvent) => {
    e.preventDefault();
    if (touchId.current === null) return;
    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      if (touch.identifier === touchId.current) {
        updateKnob(touch.clientX, touch.clientY);
        break;
      }
    }
  };

  const handleEnd = (e: React.TouchEvent) => {
    e.preventDefault();
    if (touchId.current === null) return;
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === touchId.current) {
        touchId.current = null;
        setActive(false);
        setKnobPos({ x: 0, y: 0 });
        onMove(0, 0);
        break;
      }
    }
  };

  const updateKnob = (clientX: number, clientY: number) => {
    if (!baseRef.current) return;
    const rect = baseRef.current.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    let dx = clientX - cx;
    let dy = clientY - cy;
    const dist = Math.sqrt(dx * dx + dy * dy);
    if (dist > baseRadius) {
      dx = (dx / dist) * baseRadius;
      dy = (dy / dist) * baseRadius;
    }
    setKnobPos({ x: dx, y: dy });
    onMove(dx / baseRadius, -dy / baseRadius);
  };

  return (
    <div
      ref={baseRef}
      onTouchStart={handleStart}
      onTouchMove={handleMove}
      onTouchEnd={handleEnd}
      onTouchCancel={handleEnd}
      className="relative rounded-full"
      style={{
        width: '140px',
        height: '140px',
        background: active ? 'rgba(255,255,255,0.15)' : 'rgba(255,255,255,0.08)',
        border: '2px solid rgba(255,255,255,0.2)',
        backdropFilter: 'blur(8px)',
        touchAction: 'none',
      }}
    >
      <div
        className="absolute rounded-full"
        style={{
          width: '60px',
          height: '60px',
          left: '40px',
          top: '40px',
          transform: `translate(${knobPos.x}px, ${knobPos.y}px)`,
          background: 'rgba(100, 180, 255, 0.5)',
          border: '2px solid rgba(100, 180, 255, 0.8)',
          transition: active ? 'none' : 'transform 0.2s ease-out',
          boxShadow: '0 4px 12px rgba(0,0,0,0.3)',
        }}
      />
    </div>
  );
}

interface CameraAreaProps {
  onSwipe: (dx: number, dy: number) => void;
}

export function CameraSwipeArea({ onSwipe }: CameraAreaProps) {
  const lastPos = useRef<{ x: number; y: number } | null>(null);
  const touchId = useRef<number | null>(null);

  const handleStart = (e: React.TouchEvent) => {
    e.preventDefault();
    const touch = e.changedTouches[0];
    touchId.current = touch.identifier;
    lastPos.current = { x: touch.clientX, y: touch.clientY };
  };

  const handleMove = (e: React.TouchEvent) => {
    e.preventDefault();
    if (touchId.current === null || !lastPos.current) return;
    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      if (touch.identifier === touchId.current) {
        const dx = touch.clientX - lastPos.current.x;
        const dy = touch.clientY - lastPos.current.y;
        onSwipe(dx, dy);
        lastPos.current = { x: touch.clientX, y: touch.clientY };
        break;
      }
    }
  };

  const handleEnd = (e: React.TouchEvent) => {
    e.preventDefault();
    if (touchId.current === null) return;
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === touchId.current) {
        touchId.current = null;
        lastPos.current = null;
        break;
      }
    }
  };

  return (
    <div
      onTouchStart={handleStart}
      onTouchMove={handleMove}
      onTouchEnd={handleEnd}
      onTouchCancel={handleEnd}
      className="fixed bottom-0 left-0 z-20"
      style={{
        width: '45%',
        height: '60%',
        touchAction: 'none',
        pointerEvents: 'auto',
      }}
    />
  );
}

interface ActionButtonProps {
  label: string;
  icon: string;
  onPress: () => void;
  color?: string;
  size?: number;
}

export function ActionButton({ label, icon, onPress, color = '#4466aa', size = 64 }: ActionButtonProps) {
  const [pressed, setPressed] = useState(false);

  const handlePress = (e: React.TouchEvent | React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setPressed(true);
    onPress();
  };

  useEffect(() => {
    if (pressed) {
      const t = setTimeout(() => setPressed(false), 150);
      return () => clearTimeout(t);
    }
  }, [pressed]);

  return (
    <button
      onTouchStart={handlePress}
      onMouseDown={handlePress}
      className="rounded-full flex flex-col items-center justify-center text-white font-bold transition-all"
      style={{
        width: `${size}px`,
        height: `${size}px`,
        background: pressed ? `${color}88` : `${color}cc`,
        border: `2px solid ${color}`,
        backdropFilter: 'blur(8px)',
        transform: pressed ? 'scale(0.9)' : 'scale(1)',
        boxShadow: '0 4px 12px rgba(0,0,0,0.3)',
        touchAction: 'none',
      }}
    >
      <span className="text-2xl">{icon}</span>
      <span className="text-[10px] mt-0.5">{label}</span>
    </button>
  );
}

interface HoldButtonProps {
  label: string;
  icon: string;
  onHold: (active: boolean) => void;
  color?: string;
  size?: number;
}

export function HoldButton({ label, icon, onHold, color = '#aa6644', size = 56 }: HoldButtonProps) {
  const [held, setHeld] = useState(false);

  const start = (e: React.TouchEvent | React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setHeld(true);
    onHold(true);
  };
  const end = (e: React.TouchEvent | React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setHeld(false);
    onHold(false);
  };

  return (
    <button
      onTouchStart={start}
      onTouchEnd={end}
      onTouchCancel={end}
      onMouseDown={start}
      onMouseUp={end}
      onMouseLeave={end}
      className="rounded-full flex flex-col items-center justify-center text-white font-bold transition-all"
      style={{
        width: `${size}px`,
        height: `${size}px`,
        background: held ? `${color}ff` : `${color}99`,
        border: `2px solid ${color}`,
        backdropFilter: 'blur(8px)',
        transform: held ? 'scale(0.9)' : 'scale(1)',
        boxShadow: '0 4px 12px rgba(0,0,0,0.3)',
        touchAction: 'none',
      }}
    >
      <span className="text-xl">{icon}</span>
      <span className="text-[9px] mt-0.5">{label}</span>
    </button>
  );
}
