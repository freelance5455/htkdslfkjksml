import { GameHudState } from '@/game/engine';

interface Props {
  state: GameHudState;
  playerPos: { x: number; z: number };
  playerRot: number;
  missionPos: { x: number; z: number } | null;
  timeLabel: string;
}

const MAP_SCALE = 0.4; // pixels per world unit
const MAP_SIZE = 140;
const WORLD_RANGE = 100;

export function Minimap({ state, playerPos, playerRot, missionPos, timeLabel }: Props) {
  const toMapX = (worldX: number) => (worldX * MAP_SCALE) + MAP_SIZE / 2;
  const toMapY = (worldZ: number) => (worldZ * MAP_SCALE) + MAP_SIZE / 2;

  const px = toMapX(playerPos.x);
  const py = toMapY(playerPos.z);

  return (
    <div
      className="relative rounded-xl overflow-hidden backdrop-blur-md"
      style={{
        width: `${MAP_SIZE}px`,
        height: `${MAP_SIZE}px`,
        background: 'rgba(20, 30, 20, 0.8)',
        border: '2px solid rgba(255,255,255,0.15)',
      }}
    >
      {/* Roads */}
      <div className="absolute" style={{
        left: `${MAP_SIZE / 2 - 2}px`, top: 0, bottom: 0,
        width: '4px', background: '#444',
      }} />
      <div className="absolute" style={{
        top: `${MAP_SIZE / 2 - 2}px`, left: 0, right: 0,
        height: '4px', background: '#444',
      }} />
      {/* Cross roads */}
      <div className="absolute" style={{
        top: `${toMapY(-50) - 1}px`, left: 0, right: 0,
        height: '3px', background: '#3a3a3a',
      }} />
      <div className="absolute" style={{
        top: `${toMapY(50) - 1}px`, left: 0, right: 0,
        height: '3px', background: '#3a3a3a',
      }} />

      {/* Buildings */}
      <MapBuilding x={toMapX(0)} y={toMapY(30)} w={8} h={7} color="#e8c170" />
      <MapBuilding x={toMapX(-60)} y={toMapY(-40)} w={11} h={7} color="#c4a060" />
      <MapBuilding x={toMapX(55)} y={toMapY(-30)} w={7} h={6} color="#ffe066" />

      {/* Park */}
      <div className="absolute rounded-full" style={{
        left: `${toMapX(30) - 5}px`, top: `${toMapY(0) - 5}px`,
        width: '10px', height: '10px', background: '#3a6a2a',
      }} />

      {/* Mission marker */}
      {missionPos && (
        <div
          className="absolute"
          style={{
            left: `${toMapX(missionPos.x) - 6}px`,
            top: `${toMapY(missionPos.z) - 6}px`,
            width: '12px',
            height: '12px',
          }}
        >
          <div
            className="w-3 h-3 rounded-full border-2 border-white"
            style={{
              background: '#ffaa00',
              animation: 'missionPulse 1.5s ease-in-out infinite',
            }}
          />
        </div>
      )}

      {/* Player dot */}
      <div
        className="absolute"
        style={{
          left: `${px - 5}px`,
          top: `${py - 5}px`,
          width: '10px',
          height: '10px',
        }}
      >
        <div
          className="w-2.5 h-2.5 rounded-full"
          style={{
            background: state.isInVehicle ? '#4488ff' : '#44ff88',
            border: '2px solid white',
            boxShadow: '0 0 4px rgba(0,255,100,0.6)',
          }}
        />
        {/* Direction indicator */}
        <div
          className="absolute"
          style={{
            left: '3px',
            top: '-4px',
            width: 0,
            height: 0,
            borderLeft: '2px solid transparent',
            borderRight: '2px solid transparent',
            borderBottom: '5px solid rgba(255,255,255,0.8)',
            transform: `rotate(${playerRot}rad)`,
            transformOrigin: '2px 7px',
          }}
        />
      </div>

      {/* Time label */}
      <div className="absolute bottom-0 left-0 right-0 text-center text-white/70 text-[10px] py-0.5" style={{ background: 'rgba(0,0,0,0.4)' }}>
        {timeLabel} {state.wantedLevel > 0 ? '⚠️' : ''}
      </div>

      <style>{`
        @keyframes missionPulse {
          0%, 100% { transform: scale(1); opacity: 1; }
          50% { transform: scale(1.4); opacity: 0.6; }
        }
      `}</style>
    </div>
  );
}

function MapBuilding({ x, y, w, h, color }: { x: number; y: number; w: number; h: number; color: string }) {
  return (
    <div
      className="absolute rounded-sm"
      style={{
        left: `${x - (w * MAP_SCALE) / 2}px`,
        top: `${y - (h * MAP_SCALE) / 2}px`,
        width: `${w * MAP_SCALE}px`,
        height: `${h * MAP_SCALE}px`,
        background: color,
        opacity: 0.8,
      }}
    />
  );
}
