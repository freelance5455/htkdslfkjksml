import { Capacitor } from '@capacitor/core';

// Production backend URL for Money Making Empire AI Website Builder
export const PRODUCTION_API_URL = 'https://ais-pre-yz5tqwalcshuoj2yv3l2nv-67395993204.asia-southeast1.run.app';

/**
 * Returns the active API base URL.
 * - When running in browser on Cloud Run, returns '' (same origin, relative paths).
 * - When running inside Capacitor on an Android device or WebView (origin is https://localhost),
 *   it automatically connects to the live production Cloud Run backend URL.
 * - Supports custom override via localStorage('MME_BACKEND_URL') for custom private deployments.
 */
export function getApiBaseUrl(): string {
  if (typeof window !== 'undefined') {
    // 1. Check user override in localStorage
    const customUrl = localStorage.getItem('MME_BACKEND_URL');
    if (customUrl && customUrl.trim().length > 0) {
      return customUrl.trim().replace(/\/+$/, '');
    }

    // 2. Check if running inside native Capacitor or local WebView container
    const isCapacitorNative = Capacitor.isNativePlatform();
    const isLocalhostOrigin = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';
    
    // In Capacitor on Android, local assets are served from https://localhost or capacitor://localhost
    // but the backend runs in the cloud. Direct to the production Cloud Run backend.
    if (isCapacitorNative || (isLocalhostOrigin && window.location.port !== '3000' && window.location.port !== '8080')) {
      return PRODUCTION_API_URL;
    }
  }

  // Standard web browser in Cloud Run environment (same-origin relative paths)
  return '';
}

/**
 * Returns the fully qualified URL for an API endpoint.
 * Example: apiUrl('/api/ai/generate-website')
 */
export function apiUrl(endpoint: string): string {
  const base = getApiBaseUrl();
  const cleanEndpoint = endpoint.startsWith('/') ? endpoint : `/${endpoint}`;
  return base ? `${base}${cleanEndpoint}` : cleanEndpoint;
}
