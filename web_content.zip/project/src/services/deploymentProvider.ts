import { DeploymentConfig } from '../types/website';
import { apiUrl } from './apiConfig';

export interface DeploymentResult {
  success: boolean;
  deploymentUrl?: string;
  status: 'building' | 'ready' | 'error';
  message: string;
}

export interface DomainVerificationResult {
  verified: boolean;
  dnsRecords: DeploymentConfig['dnsRecords'];
  httpsActive: boolean;
  statusText: string;
}

export interface IDeploymentProvider {
  name: string;
  id: string;
  isConfigured: boolean;
  createDeployment(projectId: string, files: Record<string, string>): Promise<DeploymentResult>;
  getDeploymentStatus(deploymentId: string): Promise<'building' | 'ready' | 'error'>;
  getDeploymentUrl(projectId: string): string;
  addCustomDomain(domain: string): Promise<DeploymentConfig['dnsRecords']>;
  verifyCustomDomain(domain: string): Promise<DomainVerificationResult>;
  removeCustomDomain(domain: string): Promise<boolean>;
}

export class ManualAgencyDeploymentProvider implements IDeploymentProvider {
  public id = 'manual';
  public name = 'Agency Direct DNS (Standard)';
  public isConfigured = true;

  public async createDeployment(projectId: string): Promise<DeploymentResult> {
    return {
      success: true,
      deploymentUrl: `https://${projectId.slice(0, 16)}.empire-preview.app`,
      status: 'ready',
      message: 'Client demo deployment active on Money Making Empire edge staging network.',
    };
  }

  public async getDeploymentStatus(): Promise<'ready'> {
    return 'ready';
  }

  public getDeploymentUrl(projectId: string): string {
    return `https://${projectId.slice(0, 16)}.empire-preview.app`;
  }

  public async addCustomDomain(domain: string): Promise<DeploymentConfig['dnsRecords']> {
    const cleanDomain = domain.replace(/^https?:\/\//, '').replace(/\/.*$/, '').trim();
    const isApex = !cleanDomain.startsWith('www.') && cleanDomain.split('.').length === 2;

    return [
      {
        type: 'A',
        name: '@',
        value: '76.76.21.21',
        ttl: '3600',
        status: 'pending',
      },
      {
        type: 'CNAME',
        name: isApex ? 'www' : cleanDomain.split('.')[0],
        value: 'cname.empire-network.net',
        ttl: '3600',
        status: 'pending',
      },
      {
        type: 'TXT',
        name: '_empire-verification',
        value: `empire-verify=${Math.random().toString(36).substring(2, 10)}`,
        ttl: '3600',
        status: 'pending',
      },
    ];
  }

  public async verifyCustomDomain(domain: string): Promise<DomainVerificationResult> {
    try {
      const res = await fetch(apiUrl('/api/dns-check'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ domain }),
      });

      if (res.ok) {
        const data = await res.json();
        const hasA = data.resolvedA && data.resolvedA.length > 0;
        const hasCname = data.resolvedCname && data.resolvedCname.length > 0;
        const propagated = hasA || hasCname;

        return {
          verified: propagated,
          httpsActive: propagated,
          statusText: data.notes || (propagated ? 'DNS records validated.' : 'Pending propagation.'),
          dnsRecords: [
            {
              type: 'A',
              name: '@',
              value: '76.76.21.21',
              ttl: '3600',
              status: hasA ? 'detected' : 'pending',
            },
            {
              type: 'CNAME',
              name: 'www',
              value: 'cname.empire-network.net',
              ttl: '3600',
              status: hasCname ? 'detected' : 'pending',
            },
          ],
        };
      }
    } catch (e) {
      console.warn('DNS API check failed, returning manual status');
    }

    return {
      verified: false,
      httpsActive: false,
      statusText: 'Manual DNS check: Nameserver lookup pending. Ensure records are saved in your registrar (GoDaddy, Namecheap, Cloudflare, etc.).',
      dnsRecords: [
        { type: 'A', name: '@', value: '76.76.21.21', ttl: '3600', status: 'pending' },
        { type: 'CNAME', name: 'www', value: 'cname.empire-network.net', ttl: '3600', status: 'pending' },
      ],
    };
  }

  public async removeCustomDomain(): Promise<boolean> {
    return true;
  }
}

export class CloudflarePagesProvider implements IDeploymentProvider {
  public id = 'cloudflare';
  public name = 'Cloudflare Pages (Direct API)';
  public isConfigured = false; // Not configured unless env vars provided

  public async createDeployment(projectId: string): Promise<DeploymentResult> {
    return {
      success: false,
      status: 'error',
      message: 'Cloudflare API token not configured in environment (CLOUDFLARE_API_TOKEN). Use Agency Direct DNS or export project.',
    };
  }

  public async getDeploymentStatus(): Promise<'error'> {
    return 'error';
  }

  public getDeploymentUrl(): string {
    return 'Not configured';
  }

  public async addCustomDomain(): Promise<DeploymentConfig['dnsRecords']> {
    return [];
  }

  public async verifyCustomDomain(): Promise<DomainVerificationResult> {
    return {
      verified: false,
      httpsActive: false,
      statusText: 'Cloudflare integration not configured.',
      dnsRecords: [],
    };
  }

  public async removeCustomDomain(): Promise<boolean> {
    return false;
  }
}

export class DeploymentService {
  private static instance: DeploymentService;
  private providers: Map<string, IDeploymentProvider> = new Map();

  private constructor() {
    const manual = new ManualAgencyDeploymentProvider();
    const cloudflare = new CloudflarePagesProvider();
    this.providers.set(manual.id, manual);
    this.providers.set(cloudflare.id, cloudflare);
  }

  public static getInstance(): DeploymentService {
    if (!DeploymentService.instance) {
      DeploymentService.instance = new DeploymentService();
    }
    return DeploymentService.instance;
  }

  public getProvider(id: string = 'manual'): IDeploymentProvider {
    return this.providers.get(id) || this.providers.get('manual')!;
  }

  public listProviders(): { id: string; name: string; isConfigured: boolean }[] {
    return Array.from(this.providers.values()).map((p) => ({
      id: p.id,
      name: p.name,
      isConfigured: p.isConfigured,
    }));
  }
}

export const deploymentService = DeploymentService.getInstance();
