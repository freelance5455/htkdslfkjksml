import { 
  ChatbotConfig, 
  ChatbotLead, 
  ChatMessage, 
  ChatbotConversation,
  ChatbotAnalytics 
} from '../types/chatbot';
import { BusinessInfo } from '../types/website';
import { apiUrl } from './apiConfig';

export interface ChatbotStatus {
  configured: boolean;
  is24x7Available: boolean;
  provider: string;
  model: string | null;
  statusMessage: string;
}

export interface BusinessChatContext {
  businessName: string;
  businessDescription: string;
  services: any[];
  servicesSummary?: string;
  faqs?: { question: string; answer: string }[];
  businessHours?: string;
  location?: string;
  contactPhone?: string;
  contactEmail?: string;
  whatsapp?: string;
  bookingUrl?: string;
  tone?: string;
}

export interface SendMessageResult {
  reply: string;
  shouldOfferLeadCapture?: boolean;
  relevantServices?: string[];
  directContactAction?: 'call' | 'whatsapp' | 'book' | 'contact' | null;
  error?: string;
  failsafe?: boolean;
  configured: boolean;
}

export interface IChatbotProvider {
  initializeChat(
    config: ChatbotConfig, 
    business: BusinessInfo,
    projectId?: string
  ): Promise<{
    welcomeMessage: string;
    suggestedQuestions: string[];
    configured: boolean;
    is24x7Available: boolean;
    statusMessage: string;
  }>;

  sendMessage(
    message: string,
    history: ChatMessage[],
    context: BusinessChatContext,
    meta?: { projectId?: string; websiteName?: string }
  ): Promise<SendMessageResult>;

  getBusinessContext(
    config: ChatbotConfig, 
    business: BusinessInfo
  ): BusinessChatContext;

  collectLead(
    leadData: {
      projectId: string;
      websiteName: string;
      name: string;
      email: string;
      phone: string;
      whatsapp?: string;
      interestedService?: string;
      message?: string;
    }
  ): Promise<{ success: boolean; lead?: ChatbotLead; error?: string }>;

  endConversation(
    conversationId: string,
    data: {
      projectId: string;
      websiteName: string;
      messages: ChatMessage[];
      status: 'completed' | 'lead_captured' | 'active';
      lead?: ChatbotLead;
      requestedService?: string;
    }
  ): Promise<void>;

  getStatus(): Promise<ChatbotStatus>;
  
  getLeads(projectId?: string): Promise<ChatbotLead[]>;
  deleteLead(leadId: string): Promise<boolean>;
  getConversations(projectId?: string): Promise<ChatbotConversation[]>;
  deleteConversation(conversationId: string): Promise<boolean>;
}

class ServerChatbotProvider implements IChatbotProvider {
  private cachedStatus: ChatbotStatus | null = null;
  private lastStatusFetch: number = 0;

  async getStatus(): Promise<ChatbotStatus> {
    const now = Date.now();
    // Cache status for 15 seconds to avoid hammering server
    if (this.cachedStatus && now - this.lastStatusFetch < 15000) {
      return this.cachedStatus;
    }

    try {
      const res = await fetch(apiUrl('/api/chatbot/status'));
      if (res.ok) {
        const data = await res.json();
        this.cachedStatus = {
          configured: Boolean(data.configured),
          is24x7Available: Boolean(data.is24x7Available),
          provider: data.provider || 'Google Gemini AI',
          model: data.model || null,
          statusMessage: data.statusMessage || (data.configured ? 'AI assistant available 24/7' : 'AI chatbot not configured'),
        };
      } else {
        this.cachedStatus = {
          configured: false,
          is24x7Available: false,
          provider: 'Not Configured',
          model: null,
          statusMessage: 'AI chatbot not configured',
        };
      }
    } catch {
      this.cachedStatus = {
        configured: false,
        is24x7Available: false,
        provider: 'Unavailable',
        model: null,
        statusMessage: 'AI assistant temporarily unavailable',
      };
    }
    this.lastStatusFetch = now;
    return this.cachedStatus;
  }

  getBusinessContext(config: ChatbotConfig, business: BusinessInfo): BusinessChatContext {
    return {
      businessName: config.businessName || business.name,
      businessDescription: config.businessDescription || business.description,
      services: business.services || [],
      servicesSummary: config.servicesSummary,
      faqs: config.faqs || [],
      businessHours: config.businessHours || business.businessHours || 'Mon - Fri: 9:00 AM - 5:00 PM',
      location: config.location || business.location,
      contactPhone: config.contactPhone || business.phone,
      contactEmail: config.contactEmail || business.email,
      whatsapp: config.whatsapp || business.whatsapp,
      bookingUrl: config.bookingUrl,
      tone: config.tone || 'professional',
    };
  }

  async initializeChat(
    config: ChatbotConfig, 
    business: BusinessInfo,
    _projectId?: string
  ) {
    const status = await this.getStatus();
    
    // Prepare tailored default questions based on actual business services
    let questions = config.suggestedQuestions && config.suggestedQuestions.length > 0 
      ? config.suggestedQuestions 
      : [];

    if (questions.length === 0) {
      questions = [
        'What services do you offer?',
        'How can I book an appointment?',
        'Where are you located?',
        'How can I contact you?'
      ];
    }

    const greeting = config.welcomeMessage || 
      config.customGreeting || 
      `Hi! I'm the AI assistant for ${config.businessName || business.name}. How can I help you today?`;

    return {
      welcomeMessage: greeting,
      suggestedQuestions: questions,
      configured: status.configured,
      is24x7Available: status.is24x7Available,
      statusMessage: status.statusMessage,
    };
  }

  async sendMessage(
    message: string,
    history: ChatMessage[],
    context: BusinessChatContext,
    meta?: { projectId?: string; websiteName?: string }
  ): Promise<SendMessageResult> {
    try {
      const res = await fetch(apiUrl('/api/chatbot/chat'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message,
          history: history.map((h) => ({ role: h.role, content: h.content })),
          businessContext: context,
          projectId: meta?.projectId,
          websiteName: meta?.websiteName,
        }),
      });

      if (res.status === 503) {
        // AI provider is not configured
        const data = await res.json().catch(() => ({}));
        return {
          reply: 'AI chatbot not configured. Please contact the business directly or configure the AI provider.',
          configured: false,
          error: data.error || 'AI chatbot not configured',
        };
      }

      if (!res.ok) {
        // Server or upstream failure
        return {
          reply: 'The AI assistant is temporarily unavailable. Please contact us directly.',
          configured: true,
          failsafe: true,
          error: 'AI service unavailable',
        };
      }

      const data = await res.json();
      return {
        reply: data.reply || "I don't have that information. You can contact the business directly here.",
        shouldOfferLeadCapture: Boolean(data.shouldOfferLeadCapture),
        relevantServices: data.relevantServices || [],
        directContactAction: data.directContactAction || null,
        configured: true,
      };
    } catch {
      // Network failure
      return {
        reply: 'The AI assistant is temporarily unavailable. Please contact us directly.',
        configured: false,
        failsafe: true,
        error: 'Network error',
      };
    }
  }

  async collectLead(leadData: {
    projectId: string;
    websiteName: string;
    name: string;
    email: string;
    phone: string;
    whatsapp?: string;
    interestedService?: string;
    message?: string;
  }): Promise<{ success: boolean; lead?: ChatbotLead; error?: string }> {
    try {
      const res = await fetch(apiUrl('/api/chatbot/leads'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(leadData),
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        return { success: false, error: err.error || 'Failed to save lead' };
      }

      const data = await res.json();
      return { success: true, lead: data.lead };
    } catch {
      // Local fallback in case server route is unreachable
      const fallbackLead: ChatbotLead = {
        id: `lead_${Date.now()}`,
        projectId: leadData.projectId,
        websiteName: leadData.websiteName,
        date: new Date().toISOString(),
        name: leadData.name,
        email: leadData.email,
        phone: leadData.phone,
        whatsapp: leadData.whatsapp,
        interestedService: leadData.interestedService,
        message: leadData.message,
        status: 'new',
        source: 'chatbot',
      };
      return { success: true, lead: fallbackLead };
    }
  }

  async endConversation(
    conversationId: string,
    data: {
      projectId: string;
      websiteName: string;
      messages: ChatMessage[];
      status: 'completed' | 'lead_captured' | 'active';
      lead?: ChatbotLead;
      requestedService?: string;
    }
  ): Promise<void> {
    try {
      await fetch(apiUrl('/api/chatbot/conversations'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: conversationId,
          ...data,
        }),
      });
    } catch {
      // Non-blocking sync failure
    }
  }

  async getLeads(projectId?: string): Promise<ChatbotLead[]> {
    try {
      const url = projectId ? `/api/chatbot/leads?projectId=${encodeURIComponent(projectId)}` : '/api/chatbot/leads';
      const res = await fetch(apiUrl(url));
      if (res.ok) {
        const data = await res.json();
        return data.leads || [];
      }
      return [];
    } catch {
      return [];
    }
  }

  async deleteLead(leadId: string): Promise<boolean> {
    try {
      const res = await fetch(apiUrl(`/api/chatbot/leads/${encodeURIComponent(leadId)}`), {
        method: 'DELETE',
      });
      return res.ok;
    } catch {
      return false;
    }
  }

  async getConversations(projectId?: string): Promise<ChatbotConversation[]> {
    try {
      const url = projectId 
        ? `/api/chatbot/conversations?projectId=${encodeURIComponent(projectId)}` 
        : '/api/chatbot/conversations';
      const res = await fetch(apiUrl(url));
      if (res.ok) {
        const data = await res.json();
        return data.conversations || [];
      }
      return [];
    } catch {
      return [];
    }
  }

  async deleteConversation(conversationId: string): Promise<boolean> {
    try {
      const res = await fetch(apiUrl(`/api/chatbot/conversations/${encodeURIComponent(conversationId)}`), {
        method: 'DELETE',
      });
      return res.ok;
    } catch {
      return false;
    }
  }
}

export const chatbotProvider: IChatbotProvider = new ServerChatbotProvider();
