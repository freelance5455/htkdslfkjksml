import * as THREE from 'three';
import { CHARACTERS, createCharacterModel, CharacterConfig } from './models/characters';
import { InputState } from './input';
import { ElmoreWorld, VehicleInfo } from './world';

const GRAVITY = -20;
const JUMP_FORCE = 8;
const WALK_SPEED = 5;
const RUN_SPEED = 9;

export class PlayerController {
  scene: THREE.Scene;
  world: ElmoreWorld;
  model: THREE.Group;
  characterKey: string = 'gumball';
  characterConfig: CharacterConfig;

  position = new THREE.Vector3(0, 0, 25);
  velocity = new THREE.Vector3();
  rotationY = 0;
  onGround = true;
  isInVehicle = false;
  currentVehicle: VehicleInfo | null = null;
  health = 100;
  energy = 100;
  money = 500;
  animTime = 0;
  isMoving = false;
  isRunning = false;

  // Camera orbit
  cameraAngle = 0;
  cameraPitch = 0.35;
  cameraDistance = 8;

  constructor(scene: THREE.Scene, world: ElmoreWorld) {
    this.scene = scene;
    this.world = world;
    this.characterConfig = CHARACTERS['gumball'];
    this.model = createCharacterModel(this.characterConfig);
    this.model.position.copy(this.position);
    scene.add(this.model);
  }

  switchCharacter(key: string) {
    if (!CHARACTERS[key]) return;
    if (this.isInVehicle) return;
    this.scene.remove(this.model);
    this.characterKey = key;
    this.characterConfig = CHARACTERS[key];
    this.model = createCharacterModel(this.characterConfig);
    this.model.position.copy(this.position);
    this.model.rotation.y = this.rotationY;
    this.scene.add(this.model);
  }

  enterVehicle(vehicle: VehicleInfo) {
    if (this.isInVehicle) return;
    this.isInVehicle = true;
    this.currentVehicle = vehicle;
    vehicle.occupied = true;
    this.model.visible = false;
  }

  exitVehicle() {
    if (!this.isInVehicle || !this.currentVehicle) return;
    const v = this.currentVehicle;
    v.occupied = false;
    v.velocity *= 0.3;
    this.isInVehicle = false;
    this.model.visible = true;
    // Place player beside vehicle
    this.position.set(
      v.position.x + Math.cos(v.rotation) * 2,
      0,
      v.position.z - Math.sin(v.rotation) * 2
    );
    this.velocity.set(0, 0, 0);
    this.currentVehicle = null;
  }

  update(input: InputState, dt: number, camera: THREE.Camera) {
    // Camera orbit
    this.cameraAngle -= input.cameraDeltaX * 0.005;
    this.cameraPitch -= input.cameraDeltaY * 0.003;
    this.cameraPitch = Math.max(0.1, Math.min(1.2, this.cameraPitch));

    if (this.isInVehicle && this.currentVehicle) {
      this.updateVehicle(input, dt, camera);
    } else {
      this.updateOnFoot(input, dt, camera);
    }

    // Decay stats
    this.energy = Math.max(0, this.energy - dt * 0.3);
    if (this.energy < 20) {
      this.health = Math.max(0, this.health - dt * 0.1);
    }
  }

  private updateOnFoot(input: InputState, dt: number, camera: THREE.Camera) {
    // Movement relative to camera
    const cosA = Math.cos(this.cameraAngle);
    const sinA = Math.sin(this.cameraAngle);
    const forward = new THREE.Vector3(sinA, 0, cosA);
    const right = new THREE.Vector3(cosA, 0, -sinA);

    const speed = input.sprint && this.energy > 5 ? RUN_SPEED : WALK_SPEED;
    const moveDir = new THREE.Vector3();
    moveDir.addScaledVector(forward, input.moveY);
    moveDir.addScaledVector(right, input.moveX);

    if (moveDir.lengthSq() > 0) {
      moveDir.normalize();
      const newPos = this.position.clone().addScaledVector(moveDir, speed * dt);
      if (!this.world.checkCollision(newPos, 0.6)) {
        this.position.copy(newPos);
      } else {
        // Try sliding on X or Z
        const tryX = this.position.clone();
        tryX.x += moveDir.x * speed * dt;
        if (!this.world.checkCollision(tryX, 0.6)) this.position.copy(tryX);
        else {
          const tryZ = this.position.clone();
          tryZ.z += moveDir.z * speed * dt;
          if (!this.world.checkCollision(tryZ, 0.6)) this.position.copy(tryZ);
        }
      }
      this.rotationY = Math.atan2(moveDir.x, moveDir.z);
      this.isMoving = true;
      this.isRunning = input.sprint && this.energy > 5;
      if (this.isRunning) this.energy = Math.max(0, this.energy - dt * 0.5);
    } else {
      this.isMoving = false;
      this.isRunning = false;
    }

    // Jump
    if (input.jump && this.onGround) {
      this.velocity.y = JUMP_FORCE;
      this.onGround = false;
    }

    // Gravity
    this.velocity.y += GRAVITY * dt;
    this.position.y += this.velocity.y * dt;

    if (this.position.y <= 0) {
      this.position.y = 0;
      this.velocity.y = 0;
      this.onGround = true;
    }

    // Clamp to world
    this.position.x = Math.max(-180, Math.min(180, this.position.x));
    this.position.z = Math.max(-180, Math.min(180, this.position.z));

    // Update model
    this.model.position.copy(this.position);
    this.model.rotation.y = this.rotationY;

    // Walk/run animation
    this.animTime += dt * (this.isRunning ? 12 : 6);
    const ud = this.model.userData;
    if (this.isMoving && ud.legL && ud.legR) {
      ud.legL.rotation.x = Math.sin(this.animTime) * 0.5;
      ud.legR.rotation.x = -Math.sin(this.animTime) * 0.5;
      ud.armL.rotation.x = -Math.sin(this.animTime) * 0.3;
      ud.armR.rotation.x = Math.sin(this.animTime) * 0.3;
    } else {
      if (ud.legL) ud.legL.rotation.x *= 0.8;
      if (ud.legR) ud.legR.rotation.x *= 0.8;
      if (ud.armL) ud.armL.rotation.x *= 0.8;
      if (ud.armR) ud.armR.rotation.x *= 0.8;
    }

    // Camera follow
    this.updateCamera(camera);
  }

  private updateVehicle(input: InputState, dt: number, camera: THREE.Camera) {
    const v = this.currentVehicle!;
    const maxSpeed = 25;
    const accel = 15;
    const reverseAccel = 10;
    const turnSpeed = 1.8;

    if (input.moveY > 0) {
      v.velocity += accel * input.moveY * dt;
    } else if (input.moveY < 0) {
      v.velocity += reverseAccel * input.moveY * dt;
    } else {
      v.velocity *= 0.98;
    }

    if (input.brake) {
      v.velocity *= 0.9;
    }

    v.velocity = Math.max(-maxSpeed * 0.5, Math.min(maxSpeed, v.velocity));

    // Turning - only when moving
    if (Math.abs(v.velocity) > 0.5) {
      v.rotation -= input.moveX * turnSpeed * dt * (v.velocity > 0 ? 1 : -1);
    }

    // Move
    const dx = Math.sin(v.rotation) * v.velocity * dt;
    const dz = Math.cos(v.rotation) * v.velocity * dt;
    const newPos = new THREE.Vector3(v.position.x + dx, 0, v.position.z + dz);

    if (!this.world.checkCollision(newPos, 1.5)) {
      v.position.copy(newPos);
    } else {
      v.velocity *= 0.3; // crash slow down
    }

    v.position.x = Math.max(-180, Math.min(180, v.position.x));
    v.position.z = Math.max(-180, Math.min(180, v.position.z));

    // Update mesh
    v.mesh.position.copy(v.position);
    v.mesh.rotation.y = v.rotation;
    v.bbox.setFromObject(v.mesh);

    // Spin wheels
    if (v.mesh.userData.wheels) {
      const wheelRot = v.velocity * dt * 2;
      for (const wheel of v.mesh.userData.wheels as THREE.Mesh[]) {
        wheel.rotation.x += wheelRot;
      }
    }

    // Player follows vehicle
    this.position.copy(v.position);
    this.position.y = 0;
    this.rotationY = v.rotation;

    // Camera follows from behind vehicle (smoothed)
    const targetPos = v.position.clone();
    const camDist = this.cameraDistance + 3;
    const camHeight = 5;
    const desiredCam = new THREE.Vector3(
      targetPos.x - Math.sin(v.rotation) * camDist,
      camHeight,
      targetPos.z - Math.cos(v.rotation) * camDist
    );
    camera.position.lerp(desiredCam, 0.08);
    camera.lookAt(targetPos.x, 1, targetPos.z);
  }

  private updateCamera(camera: THREE.Camera) {
    const targetPos = this.position.clone();
    const camX = targetPos.x - Math.sin(this.cameraAngle) * this.cameraDistance * Math.cos(this.cameraPitch);
    const camY = targetPos.y + this.cameraDistance * Math.sin(this.cameraPitch) + 1;
    const camZ = targetPos.z - Math.cos(this.cameraAngle) * this.cameraDistance * Math.cos(this.cameraPitch);

    camera.position.lerp(new THREE.Vector3(camX, camY, camZ), 0.12);
    camera.lookAt(targetPos.x, targetPos.y + 1, targetPos.z);
  }

  takeDamage(amount: number) {
    this.health = Math.max(0, this.health - amount);
  }

  heal(amount: number) {
    this.health = Math.min(100, this.health + amount);
  }

  restoreEnergy(amount: number) {
    this.energy = Math.min(100, this.energy + amount);
  }

  addMoney(amount: number) {
    this.money += amount;
  }

  spendMoney(amount: number): boolean {
    if (this.money >= amount) {
      this.money -= amount;
      return true;
    }
    return false;
  }
}
