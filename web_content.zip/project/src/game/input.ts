export interface InputState {
  moveX: number;   // -1 to 1 (left/right)
  moveY: number;   // -1 to 1 (forward/back)
  jump: boolean;
  sprint: boolean;
  action: boolean;      // attack/interact
  enterVehicle: boolean;
  cameraDeltaX: number; // swipe delta
  cameraDeltaY: number;
  phoneToggle: boolean;
  switchCharacter: boolean;
  brake: boolean;
}

export class InputManager {
  private keys: Record<string, boolean> = {};
  private joyX = 0;
  private joyY = 0;
  private touchCamX = 0;
  private touchCamY = 0;
  private jumpQueued = false;
  private actionQueued = false;
  private enterQueued = false;
  private phoneQueued = false;
  private switchQueued = false;
  private brakeHeld = false;
  private sprintHeld = false;
  private actionCooldown = 0;

  // Touch control setters (called from React UI)
  setJoystick(x: number, y: number) {
    this.joyX = x;
    this.joyY = y;
  }

  pressJump() { this.jumpQueued = true; }
  pressAction() {
    if (this.actionCooldown <= 0) {
      this.actionQueued = true;
      this.actionCooldown = 0.5;
    }
  }
  pressEnter() { this.enterQueued = true; }
  pressPhone() { this.phoneQueued = true; }
  pressSwitch() { this.switchQueued = true; }
  setBrake(v: boolean) { this.brakeHeld = v; }
  setSprint(v: boolean) { this.sprintHeld = v; }
  setCameraDelta(dx: number, dy: number) {
    this.touchCamX += dx;
    this.touchCamY += dy;
  }

  constructor() {
    window.addEventListener('keydown', (e) => {
      this.keys[e.code] = true;
      if (e.code === 'Space') this.jumpQueued = true;
      if (e.code === 'KeyF') this.enterQueued = true;
      if (e.code === 'KeyE') {
        if (this.actionCooldown <= 0) {
          this.actionQueued = true;
          this.actionCooldown = 0.5;
        }
      }
      if (e.code === 'Tab') { this.phoneQueued = true; e.preventDefault(); }
      if (e.code === 'KeyC') this.switchQueued = true;
    });
    window.addEventListener('keyup', (e) => {
      this.keys[e.code] = false;
    });
  }

  tick(dt: number) {
    if (this.actionCooldown > 0) this.actionCooldown -= dt;
  }

  getState(): InputState {
    let mx = this.joyX;
    let my = this.joyY;
    let sprint = this.sprintHeld;
    let brake = this.brakeHeld;

    if (this.keys['KeyW'] || this.keys['ArrowUp']) my = 1;
    if (this.keys['KeyS'] || this.keys['ArrowDown']) my = -1;
    if (this.keys['KeyA'] || this.keys['ArrowLeft']) mx = -1;
    if (this.keys['KeyD'] || this.keys['ArrowRight']) mx = 1;
    if (this.keys['ShiftLeft']) sprint = true;
    if (this.keys['Space']) brake = true;

    // When on foot (no joystick brake), don't let Space trigger brake
    if (!this.brakeHeld && this.keys['Space']) brake = false;

    // Clamp
    mx = Math.max(-1, Math.min(1, mx));
    my = Math.max(-1, Math.min(1, my));

    const camX = this.touchCamX;
    const camY = this.touchCamY;
    this.touchCamX = 0;
    this.touchCamY = 0;

    const state: InputState = {
      moveX: mx,
      moveY: my,
      jump: this.jumpQueued,
      sprint,
      action: this.actionQueued,
      enterVehicle: this.enterQueued,
      cameraDeltaX: camX,
      cameraDeltaY: camY,
      phoneToggle: this.phoneQueued,
      switchCharacter: this.switchQueued,
      brake,
    };

    this.jumpQueued = false;
    this.actionQueued = false;
    this.enterQueued = false;
    this.phoneQueued = false;
    this.switchQueued = false;

    return state;
  }
}
