import * as THREE from 'three';
import { createPoliceCar } from './models/vehicles';
import { createPoliceModel } from './models/characters';
import { PlayerController } from './player';
import { ElmoreWorld } from './world';

interface PoliceUnit {
  mesh: THREE.Group;
  driver: THREE.Group;
  position: THREE.Vector3;
  rotation: number;
  velocity: number;
  bbox: THREE.Box3;
}

export class PoliceSystem {
  scene: THREE.Scene;
  world: ElmoreWorld;
  player: PlayerController;
  units: PoliceUnit[] = [];
  wantedLevel = 0; // 0-5
  chaseTimer = 0;
  flashTimer = 0;
  damageTimer = 0;

  constructor(scene: THREE.Scene, world: ElmoreWorld, player: PlayerController) {
    this.scene = scene;
    this.world = world;
    this.player = player;
  }

  addWanted(amount: number) {
    this.wantedLevel = Math.min(5, this.wantedLevel + amount);
    this.chaseTimer = 30;
    if (this.wantedLevel > 0 && this.units.length < this.wantedLevel * 2) {
      this.spawnUnit();
    }
  }

  private spawnUnit() {
    const car = createPoliceCar();
    const angle = Math.random() * Math.PI * 2;
    const dist = 40 + Math.random() * 20;
    const x = this.player.position.x + Math.cos(angle) * dist;
    const z = this.player.position.z + Math.sin(angle) * dist;
    car.position.set(x, 0, z);
    this.scene.add(car);

    const driver = createPoliceModel();
    driver.position.set(0, 0, 0);
    driver.visible = false;
    car.add(driver);

    this.units.push({
      mesh: car,
      driver,
      position: new THREE.Vector3(x, 0, z),
      rotation: 0,
      velocity: 0,
      bbox: new THREE.Box3().setFromObject(car),
    });
  }

  clearWanted() {
    this.wantedLevel = 0;
    for (const u of this.units) {
      this.scene.remove(u.mesh);
    }
    this.units = [];
  }

  update(dt: number) {
    this.flashTimer += dt;
    this.damageTimer += dt;

    if (this.wantedLevel > 0) {
      this.chaseTimer -= dt;
      if (this.chaseTimer <= 0) {
        this.wantedLevel = Math.max(0, this.wantedLevel - 1);
        this.chaseTimer = 30;
        if (this.wantedLevel === 0) {
          this.clearWanted();
          return;
        }
      }

      // Spawn more units if needed
      const targetUnits = this.wantedLevel * 2;
      while (this.units.length < targetUnits) {
        this.spawnUnit();
      }
    }

    // Update police AI
    for (const unit of this.units) {
      const toPlayer = new THREE.Vector3().subVectors(this.player.position, unit.position);
      toPlayer.y = 0;
      const dist = toPlayer.length();
      const targetAngle = Math.atan2(toPlayer.x, toPlayer.z);

      // Steer toward player
      let angleDiff = targetAngle - unit.rotation;
      while (angleDiff > Math.PI) angleDiff -= Math.PI * 2;
      while (angleDiff < -Math.PI) angleDiff += Math.PI * 2;
      unit.rotation += angleDiff * 2 * dt;

      // Accelerate
      const targetSpeed = 18 + this.wantedLevel * 2;
      if (dist > 5) {
        unit.velocity = Math.min(targetSpeed, unit.velocity + 15 * dt);
      } else {
        unit.velocity *= 0.9;
      }

      // Move
      const dx = Math.sin(unit.rotation) * unit.velocity * dt;
      const dz = Math.cos(unit.rotation) * unit.velocity * dt;
      const newPos = new THREE.Vector3(unit.position.x + dx, 0, unit.position.z + dz);
      if (!this.world.checkCollision(newPos, 1.5)) {
        unit.position.copy(newPos);
      } else {
        unit.velocity *= 0.5;
      }

      unit.mesh.position.copy(unit.position);
      unit.mesh.rotation.y = unit.rotation;
      unit.bbox.setFromObject(unit.mesh);

      // Flashing lights
      if (unit.mesh.userData.lightBar) {
        const { red, blue } = unit.mesh.userData.lightBar;
        const flash = Math.floor(this.flashTimer * 4) % 2 === 0;
        red.material.emissive.setHex(flash ? 0xff0000 : 0x330000);
        blue.material.emissive.setHex(flash ? 0x000033 : 0x0000ff);
      }

      // Catch player - damage if close
      if (dist < 2.5 && this.damageTimer > 1) {
        this.player.takeDamage(8);
        this.damageTimer = 0;
      }

      // If player in vehicle and police crash into them
      if (this.player.isInVehicle && dist < 3) {
        if (this.player.currentVehicle) {
          this.player.currentVehicle.velocity *= 0.7;
        }
      }
    }
  }
}
