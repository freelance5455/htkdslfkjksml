import * as THREE from 'three';
import { ElmoreWorld } from './world';
import { PlayerController } from './player';
import { PoliceSystem } from './police';
import { InputManager } from './input';
import { PickupSystem } from './pickups';
import { DayNightCycle } from './daynight';
import { TrafficSystem } from './traffic';
import { MissionSystem, MissionHudState } from './missions';

export interface GameHudState {
  health: number;
  energy: number;
  money: number;
  wantedLevel: number;
  characterKey: string;
  characterName: string;
  isInVehicle: boolean;
  nearVehicle: boolean;
  nearBuilding: string | null;
  nearHouse: boolean;
  isIndoors: boolean;
  workShiftActive: boolean;
  workShiftProgress: number;
  isDead: boolean;
  message: string | null;
  // New fields
  playerX: number;
  playerZ: number;
  playerRot: number;
  mission: MissionHudState | null;
  missionMarker: { x: number; z: number } | null;
  timeLabel: string;
}

export type HudCallback = (state: GameHudState) => void;

export class GameEngine {
  scene: THREE.Scene;
  camera: THREE.PerspectiveCamera;
  renderer: THREE.WebGLRenderer;
  world: ElmoreWorld;
  player: PlayerController;
  police: PoliceSystem;
  input: InputManager;
  pickups: PickupSystem;
  dayNight: DayNightCycle;
  traffic: TrafficSystem;
  missions: MissionSystem;

  running = false;
  lastTime = 0;
  hudCallback: HudCallback | null = null;
  message: string | null = null;
  messageTimer = 0;
  phoneOpen = false;
  onPhoneToggle: (() => void) | null = null;
  isDead = false;
  deathTimer = 0;

  // Work shift state
  workShiftActive = false;
  workShiftTimer = 0;
  workShiftTarget = 0;

  constructor(container: HTMLElement) {
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 500);
    this.camera.position.set(0, 10, 20);

    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(this.renderer.domElement);

    this.world = new ElmoreWorld(this.scene);
    this.player = new PlayerController(this.scene, this.world);
    this.police = new PoliceSystem(this.scene, this.world, this.player);
    this.input = new InputManager();
    this.pickups = new PickupSystem(this.scene);
    this.traffic = new TrafficSystem(this.scene);

    // Day/night - extract references from world
    const sunLight = this.world.getSunLight();
    const ambient = this.world.getAmbientLight();
    const hemi = this.world.getHemiLight();
    const sunMesh = this.world.getSunMesh();
    const fog = this.world.getFog();
    this.dayNight = new DayNightCycle(this.scene, sunLight, ambient, hemi, sunMesh, fog);

    this.missions = new MissionSystem((msg) => this.showMessage(msg));

    window.addEventListener('resize', this.onResize);
  }

  onResize = () => {
    this.camera.aspect = window.innerWidth / window.innerHeight;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(window.innerWidth, window.innerHeight);
  };

  setHudCallback(cb: HudCallback) {
    this.hudCallback = cb;
  }

  start() {
    this.running = true;
    this.lastTime = performance.now();
    this.loop();
  }

  stop() {
    this.running = false;
    window.removeEventListener('resize', this.onResize);
    this.renderer.dispose();
    if (this.renderer.domElement.parentElement) {
      this.renderer.domElement.parentElement.removeChild(this.renderer.domElement);
    }
  }

  showMessage(msg: string, duration = 3) {
    this.message = msg;
    this.messageTimer = duration;
  }

  switchCharacter(key: string) {
    this.player.switchCharacter(key);
    this.showMessage(`تم التبديل إلى ${this.player.characterConfig.name}`);
    this.emitHud();
  }

  startWorkShift() {
    const restPos = this.world.restaurantPosition;
    if (this.player.position.distanceTo(restPos) > 15) {
      this.showMessage('اذهب إلى مطعم جوي فول أولاً!');
      return;
    }
    if (this.workShiftActive) return;
    this.workShiftActive = true;
    this.workShiftTimer = 0;
    this.workShiftTarget = 20;
    this.showMessage('بدأت وردية العمل! انتظر 20 ثانية');
  }

  buyFood() {
    const restPos = this.world.restaurantPosition;
    if (this.player.position.distanceTo(restPos) > 15) {
      this.showMessage('اذهب إلى مطعم جوي فول أولاً!');
      return;
    }
    if (this.player.spendMoney(50)) {
      this.player.restoreEnergy(40);
      this.player.heal(10);
      this.showMessage('اشتريت طعاماً! +40 طاقة +10 صحة');
    } else {
      this.showMessage('ليس لديك ما يكفي من المال! تحتاج 50$');
    }
  }

  private emitHud() {
    if (!this.hudCallback) return;
    const missionMarker = this.missions.getMissionMarker();
    const state: GameHudState = {
      health: Math.round(this.player.health),
      energy: Math.round(this.player.energy),
      money: Math.round(this.player.money),
      wantedLevel: this.police.wantedLevel,
      characterKey: this.player.characterKey,
      characterName: this.player.characterConfig.name,
      isInVehicle: this.player.isInVehicle,
      nearVehicle: !this.player.isInVehicle && this.world.getNearestVehicle(this.player.position) !== null &&
        this.world.getNearestVehicle(this.player.position)!.position.distanceTo(this.player.position) < 5,
      nearBuilding: this.world.getNearbyBuilding(this.player.position)?.nameAr ?? null,
      nearHouse: !this.player.isInVehicle && !this.world.isIndoors &&
        this.player.position.distanceTo(this.world.housePosition) < 8,
      isIndoors: this.world.isIndoors,
      workShiftActive: this.workShiftActive,
      workShiftProgress: this.workShiftTarget > 0 ? this.workShiftTimer / this.workShiftTarget : 0,
      isDead: this.isDead,
      message: this.message,
      playerX: this.player.position.x,
      playerZ: this.player.position.z,
      playerRot: this.player.rotationY,
      mission: this.missions.getHudState(),
      missionMarker: missionMarker ? { x: missionMarker.position.x, z: missionMarker.position.z } : null,
      timeLabel: this.dayNight.getTimeLabel(),
    };
    this.hudCallback(state);
  }

  private loop = () => {
    if (!this.running) return;
    requestAnimationFrame(this.loop);

    const now = performance.now();
    let dt = (now - this.lastTime) / 1000;
    this.lastTime = now;
    if (dt > 0.1) dt = 0.1;

    const input = this.input.getState();
    this.input.tick(dt);

    // Phone toggle
    if (input.phoneToggle) {
      this.phoneOpen = !this.phoneOpen;
      if (this.onPhoneToggle) this.onPhoneToggle();
    }

    // Switch character
    if (input.switchCharacter && !this.phoneOpen) {
      const keys = ['gumball', 'darwin', 'anais'];
      const idx = keys.indexOf(this.player.characterKey);
      const next = keys[(idx + 1) % keys.length];
      this.switchCharacter(next);
    }

    // Enter/exit: vehicle or house
    if (input.enterVehicle && !this.isDead) {
      if (this.player.isInVehicle) {
        this.player.exitVehicle();
        this.showMessage('خرجت من السيارة');
      } else if (this.world.isIndoors) {
        this.world.toggleInterior(false);
        const housePos = this.world.housePosition;
        this.player.position.set(housePos.x, 0, housePos.z + 5);
        this.showMessage('خرجت من البيت');
      } else {
        const v = this.world.getNearestVehicle(this.player.position);
        if (v && v.position.distanceTo(this.player.position) < 5) {
          this.player.enterVehicle(v);
          this.showMessage('ركبت السيارة!');
          if (!v.isStationWagon) {
            this.police.addWanted(1);
            this.showMessage('سرقت سيارة! النجمة 1');
          }
        } else {
          const housePos = this.world.housePosition;
          if (this.player.position.distanceTo(housePos) < 8) {
            this.world.toggleInterior(true);
            this.player.position.set(0, 0, 0);
            this.showMessage('دخلت البيت!');
          }
        }
      }
    }

    // Action button
    if (input.action && !this.player.isInVehicle && !this.isDead) {
      this.police.addWanted(1);
      this.showMessage('ارتكبت فوضى! النجمة +1');
      this.player.energy = Math.max(0, this.player.energy - 2);
    }

    // Death/respawn
    if (this.isDead) {
      this.deathTimer -= dt;
      if (this.deathTimer <= 0) {
        this.respawn();
      }
    } else {
      if (this.player.health <= 0) {
        this.isDead = true;
        this.deathTimer = 3;
        this.showMessage('لقد فقدت الوعي! إعادة الإحياء...', 3);
        this.police.clearWanted();
        if (this.player.isInVehicle) {
          this.player.exitVehicle();
        }
      }

      // Update player
      this.player.update(input, dt, this.camera);
    }

    // Update police
    this.police.update(dt);

    // Update NPCs
    this.world.updateNPCs(dt);

    // Update day/night
    this.dayNight.update(dt);

    // Update traffic
    this.traffic.update(dt, this.player.position);

    // Update pickups
    const pickupResult = this.pickups.update(dt, this.player.position);
    if (pickupResult) {
      if (pickupResult.type === 'health') {
        this.player.heal(pickupResult.value);
        this.showMessage(`+${pickupResult.value} صحة!`);
      } else if (pickupResult.type === 'energy') {
        this.player.restoreEnergy(pickupResult.value);
        this.showMessage(`+${pickupResult.value} طاقة!`);
      } else {
        this.player.addMoney(pickupResult.value);
        this.showMessage(`+${pickupResult.value}$!`);
      }
    }

    // Update missions
    this.missions.update(this.player.position, (n) => this.player.addMoney(n));

    // Work shift
    if (this.workShiftActive) {
      this.workShiftTimer += dt;
      if (this.workShiftTimer >= this.workShiftTarget) {
        this.workShiftActive = false;
        this.player.addMoney(150);
        this.showMessage('انتهت الوردية! حصلت على 150$');
      }
    }

    // Message timer
    if (this.messageTimer > 0) {
      this.messageTimer -= dt;
      if (this.messageTimer <= 0) this.message = null;
    }

    // HUD update (throttled)
    this.hudAccum += dt;
    if (this.hudAccum > 0.1) {
      this.hudAccum = 0;
      this.emitHud();
    }

    this.renderer.render(this.scene, this.camera);
  };

  hudAccum = 0;

  private respawn() {
    this.isDead = false;
    this.player.health = 100;
    this.player.energy = 100;
    this.player.position.set(0, 0, 25);
    this.player.velocity.set(0, 0, 0);
    this.police.clearWanted();
    this.world.toggleInterior(false);
    this.pickups.resetAll();
    this.showMessage('إحياء! عدت إلى البيت');
  }

  getInputManager(): InputManager {
    return this.input;
  }
}
