import * as THREE from 'three';

export type PickupType = 'health' | 'energy' | 'money';

export interface PickupItem {
  mesh: THREE.Group;
  position: THREE.Vector3;
  type: PickupType;
  value: number;
  collected: boolean;
  spinSpeed: number;
}

export class PickupSystem {
  scene: THREE.Scene;
  pickups: PickupItem[] = [];

  constructor(scene: THREE.Scene) {
    this.scene = scene;
    this.spawnPickups();
  }

  private spawnPickups() {
    const configs: { type: PickupType; x: number; z: number; value: number }[] = [
      { type: 'health', x: 20, z: -5, value: 25 },
      { type: 'health', x: -40, z: 15, value: 25 },
      { type: 'health', x: 65, z: 20, value: 25 },
      { type: 'energy', x: -10, z: -20, value: 30 },
      { type: 'energy', x: 45, z: 10, value: 30 },
      { type: 'energy', x: -55, z: -50, value: 30 },
      { type: 'money', x: 15, z: 50, value: 100 },
      { type: 'money', x: -70, z: -60, value: 100 },
      { type: 'money', x: 70, z: -60, value: 150 },
      { type: 'money', x: -20, z: -65, value: 100 },
      { type: 'money', x: 35, z: 60, value: 100 },
    ];

    for (const c of configs) {
      const mesh = this.createPickupMesh(c.type);
      mesh.position.set(c.x, 1, c.z);
      this.scene.add(mesh);
      this.pickups.push({
        mesh,
        position: new THREE.Vector3(c.x, 1, c.z),
        type: c.type,
        value: c.value,
        collected: false,
        spinSpeed: 1.5 + Math.random(),
      });
    }
  }

  private createPickupMesh(type: PickupType): THREE.Group {
    const group = new THREE.Group();
    let color = 0xff4466;
    let icon = 'heart';
    if (type === 'energy') { color = 0xff9933; icon = 'energy'; }
    if (type === 'money') { color = 0x44cc66; icon = 'money'; }

    // Base ring
    const ringGeo = new THREE.TorusGeometry(0.4, 0.08, 8, 16);
    const ringMat = new THREE.MeshLambertMaterial({ color, emissive: color, emissiveIntensity: 0.3 });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.rotation.x = Math.PI / 2;
    group.add(ring);

    // Center icon
    let iconMesh: THREE.Mesh;
    if (type === 'health') {
      iconMesh = new THREE.Mesh(
        new THREE.SphereGeometry(0.25, 12, 12),
        new THREE.MeshLambertMaterial({ color: 0xff6688, emissive: 0xff2244, emissiveIntensity: 0.4 })
      );
    } else if (type === 'energy') {
      iconMesh = new THREE.Mesh(
        new THREE.ConeGeometry(0.25, 0.5, 8),
        new THREE.MeshLambertMaterial({ color: 0xffaa44, emissive: 0xff8822, emissiveIntensity: 0.4 })
      );
    } else {
      iconMesh = new THREE.Mesh(
        new THREE.CylinderGeometry(0.25, 0.25, 0.15, 12),
        new THREE.MeshLambertMaterial({ color: 0x66dd88, emissive: 0x44aa66, emissiveIntensity: 0.4 })
      );
    }
    group.add(iconMesh);

    // Glow halo
    const haloGeo = new THREE.RingGeometry(0.5, 0.7, 16);
    const haloMat = new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.3, side: THREE.DoubleSide });
    const halo = new THREE.Mesh(haloGeo, haloMat);
    halo.rotation.x = -Math.PI / 2;
    halo.position.y = -0.9;
    group.add(halo);

    return group;
  }

  update(dt: number, playerPos: THREE.Vector3): { type: PickupType; value: number } | null {
    for (const p of this.pickups) {
      if (p.collected) continue;
      p.mesh.rotation.y += p.spinSpeed * dt;
      p.mesh.position.y = 1 + Math.sin(performance.now() * 0.003) * 0.3;

      const dist = p.position.distanceTo(playerPos);
      if (dist < 2) {
        p.collected = true;
        p.mesh.visible = false;
        return { type: p.type, value: p.value };
      }
    }
    return null;
  }

  resetAll() {
    for (const p of this.pickups) {
      p.collected = false;
      p.mesh.visible = true;
    }
  }
}
