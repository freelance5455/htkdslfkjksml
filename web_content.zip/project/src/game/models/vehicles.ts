import * as THREE from 'three';

export interface VehicleConfig {
  bodyColor: number;
  roofColor: number;
  width: number;
  height: number;
  length: number;
  isStationWagon?: boolean;
  isPolice?: boolean;
}

export function createVehicle(config: VehicleConfig): THREE.Group {
  const group = new THREE.Group();
  const { width, height, length, bodyColor } = config;

  // Lower body
  const lowerGeo = new THREE.BoxGeometry(width, height * 0.5, length);
  const lowerMat = new THREE.MeshLambertMaterial({ color: bodyColor });
  const lower = new THREE.Mesh(lowerGeo, lowerMat);
  lower.position.y = height * 0.35;
  lower.castShadow = true;
  group.add(lower);

  // Upper body / cabin
  const cabinLen = config.isStationWagon ? length * 0.7 : length * 0.55;
  const cabinGeo = new THREE.BoxGeometry(width * 0.85, height * 0.4, cabinLen);
  const cabinMat = new THREE.MeshLambertMaterial({ color: config.roofColor });
  const cabin = new THREE.Mesh(cabinGeo, cabinMat);
  cabin.position.y = height * 0.72;
  cabin.position.z = -length * 0.05;
  cabin.castShadow = true;
  group.add(cabin);

  // Windows
  const winMat = new THREE.MeshLambertMaterial({ color: 0x222831, emissive: 0x111122 });
  const windshieldGeo = new THREE.BoxGeometry(width * 0.7, height * 0.25, 0.05);
  const windshield = new THREE.Mesh(windshieldGeo, winMat);
  windshield.position.set(0, height * 0.72, cabinLen / 2 - length * 0.05);
  windshield.rotation.x = -0.2;
  group.add(windshield);

  const rearWin = new THREE.Mesh(windshieldGeo, winMat);
  rearWin.position.set(0, height * 0.72, -cabinLen / 2 - length * 0.05);
  rearWin.rotation.x = 0.2;
  group.add(rearWin);

  // Side windows
  const sideWinGeo = new THREE.BoxGeometry(0.05, height * 0.2, cabinLen * 0.7);
  const sideWinL = new THREE.Mesh(sideWinGeo, winMat);
  sideWinL.position.set(width * 0.43, height * 0.72, -length * 0.05);
  group.add(sideWinL);
  const sideWinR = sideWinL.clone();
  sideWinR.position.x *= -1;
  group.add(sideWinR);

  // Wheels
  const wheelGeo = new THREE.CylinderGeometry(height * 0.2, height * 0.2, width * 0.18, 12);
  const wheelMat = new THREE.MeshLambertMaterial({ color: 0x222222 });
  const wheelOffsets = [
    [width * 0.42, height * 0.18, length * 0.32],
    [-width * 0.42, height * 0.18, length * 0.32],
    [width * 0.42, height * 0.18, -length * 0.32],
    [-width * 0.42, height * 0.18, -length * 0.32],
  ];
  const wheels: THREE.Mesh[] = [];
  for (const [x, y, z] of wheelOffsets) {
    const wheel = new THREE.Mesh(wheelGeo, wheelMat);
    wheel.position.set(x, y, z);
    wheel.rotation.z = Math.PI / 2;
    wheel.castShadow = true;
    group.add(wheel);
    wheels.push(wheel);
  }

  // Headlights
  const lightGeo = new THREE.SphereGeometry(0.15, 8, 8);
  const lightMat = new THREE.MeshLambertMaterial({ color: 0xffffaa, emissive: 0xffff66 });
  const lightL = new THREE.Mesh(lightGeo, lightMat);
  lightL.position.set(width * 0.3, height * 0.35, length / 2 + 0.01);
  group.add(lightL);
  const lightR = lightL.clone();
  lightR.position.x *= -1;
  group.add(lightR);

  // Tail lights
  const tailMat = new THREE.MeshLambertMaterial({ color: 0xff2222, emissive: 0x660000 });
  const tailL = new THREE.Mesh(lightGeo, tailMat);
  tailL.position.set(width * 0.3, height * 0.35, -length / 2 - 0.01);
  group.add(tailL);
  const tailR = tailL.clone();
  tailR.position.x *= -1;
  group.add(tailR);

  // Police extras
  if (config.isPolice) {
    const barGeo = new THREE.BoxGeometry(width * 0.5, 0.15, 0.3);
    const redMat = new THREE.MeshLambertMaterial({ color: 0xff0000, emissive: 0x660000 });
    const blueMat = new THREE.MeshLambertMaterial({ color: 0x0000ff, emissive: 0x000066 });
    const redLight = new THREE.Mesh(barGeo, redMat);
    redLight.position.set(-width * 0.12, height * 0.95, 0);
    group.add(redLight);
    const blueLight = new THREE.Mesh(barGeo, blueMat);
    blueLight.position.set(width * 0.12, height * 0.95, 0);
    group.add(blueLight);
    group.userData.lightBar = { red: redLight, blue: blueLight };

    // White stripe
    const stripeGeo = new THREE.BoxGeometry(width + 0.02, height * 0.3, length * 0.8);
    const stripeMat = new THREE.MeshLambertMaterial({ color: 0xffffff });
    const stripe = new THREE.Mesh(stripeGeo, stripeMat);
    stripe.position.y = height * 0.35;
    group.add(stripe);
  }

  group.userData.wheels = wheels;
  return group;
}

export function createStationWagon(): THREE.Group {
  return createVehicle({
    bodyColor: 0xcc3333,
    roofColor: 0xaa2222,
    width: 2.0,
    height: 1.6,
    length: 4.2,
    isStationWagon: true,
  });
}

export function createSedan(color: number): THREE.Group {
  return createVehicle({
    bodyColor: color,
    roofColor: color,
    width: 1.8,
    height: 1.4,
    length: 3.8,
  });
}

export function createPoliceCar(): THREE.Group {
  return createVehicle({
    bodyColor: 0x1a1a2e,
    roofColor: 0x1a1a2e,
    width: 1.9,
    height: 1.5,
    length: 4.0,
    isPolice: true,
  });
}
