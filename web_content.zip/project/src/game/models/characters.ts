import * as THREE from 'three';

export interface CharacterConfig {
  name: string;
  bodyColor: number;
  headColor: number;
  accentColor: number;
  scale: number;
  bodyWidth: number;
  bodyHeight: number;
  headRadius: number;
}

export const CHARACTERS: Record<string, CharacterConfig> = {
  gumball: {
    name: 'غامبول',
    bodyColor: 0x4a90d9,
    headColor: 0x4a90d9,
    accentColor: 0x2a6ab9,
    scale: 1.0,
    bodyWidth: 0.7,
    bodyHeight: 1.0,
    headRadius: 0.45,
  },
  darwin: {
    name: 'داروين',
    bodyColor: 0xff8c42,
    headColor: 0xff8c42,
    accentColor: 0xcc6b30,
    scale: 1.05,
    bodyWidth: 0.6,
    bodyHeight: 1.1,
    headRadius: 0.42,
  },
  anais: {
    name: 'أنيس',
    bodyColor: 0xf4d23c,
    headColor: 0xf4d23c,
    accentColor: 0xc9a82f,
    scale: 0.75,
    bodyWidth: 0.5,
    bodyHeight: 0.7,
    headRadius: 0.38,
  },
};

export function createCharacterModel(config: CharacterConfig): THREE.Group {
  const group = new THREE.Group();
  const s = config.scale;

  // Body (capsule-ish)
  const bodyGeo = new THREE.CapsuleGeometry(config.bodyWidth * 0.5 * s, config.bodyHeight * s, 6, 12);
  const bodyMat = new THREE.MeshLambertMaterial({ color: config.bodyColor });
  const body = new THREE.Mesh(bodyGeo, bodyMat);
  body.position.y = (config.bodyHeight * 0.5 + config.headRadius * 0.3) * s;
  body.castShadow = true;
  group.add(body);

  // Head
  const headGeo = new THREE.SphereGeometry(config.headRadius * s, 16, 16);
  const headMat = new THREE.MeshLambertMaterial({ color: config.headColor });
  const head = new THREE.Mesh(headGeo, headMat);
  head.position.y = (config.bodyHeight + config.headRadius * 0.5 + config.headRadius) * s + 0.1;
  head.castShadow = true;
  group.add(head);

  // Eyes (white)
  const eyeGeo = new THREE.SphereGeometry(config.headRadius * 0.28 * s, 8, 8);
  const eyeMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
  const eyeOffsetX = config.headRadius * 0.25 * s;
  const eyeOffsetY = head.position.y + config.headRadius * 0.15 * s;
  const eyeOffsetZ = config.headRadius * 0.7 * s;
  const eyeL = new THREE.Mesh(eyeGeo, eyeMat);
  eyeL.position.set(eyeOffsetX, eyeOffsetY, eyeOffsetZ);
  group.add(eyeL);
  const eyeR = new THREE.Mesh(eyeGeo, eyeMat);
  eyeR.position.set(-eyeOffsetX, eyeOffsetY, eyeOffsetZ);
  group.add(eyeR);

  // Pupils
  const pupilGeo = new THREE.SphereGeometry(config.headRadius * 0.13 * s, 6, 6);
  const pupilMat = new THREE.MeshBasicMaterial({ color: 0x111111 });
  const pupilL = new THREE.Mesh(pupilGeo, pupilMat);
  pupilL.position.set(eyeOffsetX, eyeOffsetY, eyeOffsetZ + config.headRadius * 0.15 * s);
  group.add(pupilL);
  const pupilR = new THREE.Mesh(pupilGeo, pupilMat);
  pupilR.position.set(-eyeOffsetX, eyeOffsetY, eyeOffsetZ + config.headRadius * 0.15 * s);
  group.add(pupilR);

  // Arms
  const armGeo = new THREE.CapsuleGeometry(0.12 * s, 0.5 * s, 4, 8);
  const armMat = new THREE.MeshLambertMaterial({ color: config.bodyColor });
  const armL = new THREE.Mesh(armGeo, armMat);
  armL.position.set(config.bodyWidth * 0.65 * s, body.position.y + 0.15 * s, 0);
  armL.castShadow = true;
  group.add(armL);
  const armR = armL.clone();
  armR.position.x *= -1;
  group.add(armR);

  // Legs
  const legGeo = new THREE.CapsuleGeometry(0.15 * s, 0.3 * s, 4, 8);
  const legMat = new THREE.MeshLambertMaterial({ color: config.accentColor });
  const legL = new THREE.Mesh(legGeo, legMat);
  legL.position.set(0.18 * s, 0.1 * s, 0);
  legL.castShadow = true;
  group.add(legL);
  const legR = legL.clone();
  legR.position.x *= -1;
  group.add(legR);

  // Store references for animation
  group.userData = { body, head, armL, armR, legL, legR, pupilL, pupilR, eyeL, eyeR };
  return group;
}

export function createNPCModel(color: number, scale = 1): THREE.Group {
  const config: CharacterConfig = {
    name: 'NPC',
    bodyColor: color,
    headColor: color,
    accentColor: 0x333333,
    scale: scale,
    bodyWidth: 0.6,
    bodyHeight: 0.9,
    headRadius: 0.4,
  };
  return createCharacterModel(config);
}

export function createPoliceModel(): THREE.Group {
  // Doughnut Sheriff - dark blue uniform
  const group = new THREE.Group();
  const s = 1.0;

  // Body
  const bodyGeo = new THREE.CapsuleGeometry(0.35 * s, 0.8 * s, 6, 12);
  const bodyMat = new THREE.MeshLambertMaterial({ color: 0x1a3a5c });
  const body = new THREE.Mesh(bodyGeo, bodyMat);
  body.position.y = 0.7 * s;
  body.castShadow = true;
  group.add(body);

  // Head (doughnut shape - torus)
  const headGeo = new THREE.TorusGeometry(0.28 * s, 0.14 * s, 8, 16);
  const headMat = new THREE.MeshLambertMaterial({ color: 0xd4a574 });
  const head = new THREE.Mesh(headGeo, headMat);
  head.position.y = 1.35 * s;
  head.rotation.x = Math.PI / 2;
  head.castShadow = true;
  group.add(head);

  // Hat
  const hatGeo = new THREE.CylinderGeometry(0.3 * s, 0.32 * s, 0.15 * s, 12);
  const hatMat = new THREE.MeshLambertMaterial({ color: 0x0a1a3c });
  const hat = new THREE.Mesh(hatGeo, hatMat);
  hat.position.y = 1.6 * s;
  group.add(hat);

  // Arms
  const armGeo = new THREE.CapsuleGeometry(0.1 * s, 0.45 * s, 4, 8);
  const armMat = new THREE.MeshLambertMaterial({ color: 0x1a3a5c });
  const armL = new THREE.Mesh(armGeo, armMat);
  armL.position.set(0.42 * s, 0.8 * s, 0);
  armL.castShadow = true;
  group.add(armL);
  const armR = armL.clone();
  armR.position.x *= -1;
  group.add(armR);

  // Legs
  const legGeo = new THREE.CapsuleGeometry(0.13 * s, 0.25 * s, 4, 8);
  const legMat = new THREE.MeshLambertMaterial({ color: 0x0a1a3c });
  const legL = new THREE.Mesh(legGeo, legMat);
  legL.position.set(0.15 * s, 0.15 * s, 0);
  legL.castShadow = true;
  group.add(legL);
  const legR = legL.clone();
  legR.position.x *= -1;
  group.add(legR);

  group.userData = { body, head, armL, armR, legL, legR };
  return group;
}
