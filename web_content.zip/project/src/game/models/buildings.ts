import * as THREE from 'three';

export interface BuildingConfig {
  width: number;
  depth: number;
  height: number;
  wallColor: number;
  roofColor: number;
  doorColor: number;
  hasRoof?: boolean;
}

export function createBuilding(config: BuildingConfig): THREE.Group {
  const group = new THREE.Group();
  const { width, depth, height, wallColor, roofColor, doorColor } = config;

  // Walls
  const wallMat = new THREE.MeshLambertMaterial({ color: wallColor });
  const wallGeo = new THREE.BoxGeometry(width, height, depth);
  const walls = new THREE.Mesh(wallGeo, wallMat);
  walls.position.y = height / 2;
  walls.castShadow = true;
  walls.receiveShadow = true;
  group.add(walls);

  // Roof
  if (config.hasRoof !== false) {
    const roofMat = new THREE.MeshLambertMaterial({ color: roofColor });
    const roofGeo = new THREE.ConeGeometry(Math.max(width, depth) * 0.7, height * 0.35, 4);
    const roof = new THREE.Mesh(roofGeo, roofMat);
    roof.position.y = height + height * 0.17;
    roof.rotation.y = Math.PI / 4;
    roof.castShadow = true;
    group.add(roof);
  }

  // Door
  const doorMat = new THREE.MeshLambertMaterial({ color: doorColor });
  const doorGeo = new THREE.BoxGeometry(width * 0.2, height * 0.35, 0.15);
  const door = new THREE.Mesh(doorGeo, doorMat);
  door.position.set(0, height * 0.175, depth / 2 + 0.01);
  group.add(door);

  // Windows
  const winMat = new THREE.MeshLambertMaterial({ color: 0xa0c8e0, emissive: 0x223344 });
  const winGeo = new THREE.BoxGeometry(width * 0.15, height * 0.15, 0.1);
  for (let i = 0; i < 3; i++) {
    const win = new THREE.Mesh(winGeo, winMat);
    win.position.set(
      -width * 0.25 + i * width * 0.25,
      height * 0.55,
      depth / 2 + 0.01
    );
    group.add(win);
  }

  return group;
}

export function createHouse(color: number = 0xe8c170): THREE.Group {
  return createBuilding({
    width: 8,
    depth: 7,
    height: 4,
    wallColor: color,
    roofColor: 0x8b4513,
    doorColor: 0x4a2c1a,
    hasRoof: true,
  });
}

export function createSchool(): THREE.Group {
  const group = new THREE.Group();

  // Main building
  const main = createBuilding({
    width: 22,
    depth: 14,
    height: 7,
    wallColor: 0xc4a060,
    roofColor: 0x6b4226,
    doorColor: 0x3a2010,
    hasRoof: false,
  });
  group.add(main);

  // Flat roof
  const roofMat = new THREE.MeshLambertMaterial({ color: 0x6b4226 });
  const roofGeo = new THREE.BoxGeometry(23, 0.5, 15);
  const roof = new THREE.Mesh(roofGeo, roofMat);
  roof.position.y = 7.25;
  roof.castShadow = true;
  group.add(roof);

  // Flag pole
  const poleGeo = new THREE.CylinderGeometry(0.05, 0.05, 3, 8);
  const poleMat = new THREE.MeshLambertMaterial({ color: 0x999999 });
  const pole = new THREE.Mesh(poleGeo, poleMat);
  pole.position.set(0, 8.75, 0);
  group.add(pole);

  const flagGeo = new THREE.BoxGeometry(1, 0.6, 0.02);
  const flagMat = new THREE.MeshLambertMaterial({ color: 0x22aa44 });
  const flag = new THREE.Mesh(flagGeo, flagMat);
  flag.position.set(0.5, 9.5, 0);
  group.add(flag);

  return group;
}

export function createRestaurant(): THREE.Group {
  const group = new THREE.Group();

  // Main building
  const main = createBuilding({
    width: 14,
    depth: 12,
    height: 5,
    wallColor: 0xffe066,
    roofColor: 0xcc9900,
    doorColor: 0x884400,
    hasRoof: false,
  });
  group.add(main);

  // Flat roof
  const roofMat = new THREE.MeshLambertMaterial({ color: 0xcc9900 });
  const roofGeo = new THREE.BoxGeometry(15, 0.4, 13);
  const roof = new THREE.Mesh(roofGeo, roofMat);
  roof.position.y = 5.2;
  roof.castShadow = true;
  group.add(roof);

  // Sign
  const signMat = new THREE.MeshLambertMaterial({ color: 0xff4444, emissive: 0x661111 });
  const signGeo = new THREE.BoxGeometry(8, 1.5, 0.3);
  const sign = new THREE.Mesh(signGeo, signMat);
  sign.position.set(0, 5.9, 6.2);
  group.add(sign);

  // Golden arches / decoration
  const archGeo = new THREE.TorusGeometry(1.5, 0.15, 8, 16, Math.PI);
  const archMat = new THREE.MeshLambertMaterial({ color: 0xffcc00, emissive: 0x664400 });
  const arch = new THREE.Mesh(archGeo, archMat);
  arch.position.set(0, 5.5, 6.3);
  arch.rotation.z = Math.PI;
  group.add(arch);

  return group;
}

export function createGenericBuilding(width: number, height: number, depth: number, color: number): THREE.Group {
  const group = new THREE.Group();
  const mat = new THREE.MeshLambertMaterial({ color });
  const geo = new THREE.BoxGeometry(width, height, depth);
  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.y = height / 2;
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  group.add(mesh);

  // Windows grid
  const winMat = new THREE.MeshLambertMaterial({ color: 0x88aacc, emissive: 0x223344 });
  const winGeo = new THREE.BoxGeometry(width * 0.08, height * 0.06, 0.08);
  const cols = Math.floor(width / 3);
  const rows = Math.floor(height / 3);
  for (let r = 1; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const win = new THREE.Mesh(winGeo, winMat);
      win.position.set(
        -width / 2 + 1.5 + c * 3,
        r * 3,
        depth / 2 + 0.01
      );
      group.add(win);
    }
  }
  return group;
}
