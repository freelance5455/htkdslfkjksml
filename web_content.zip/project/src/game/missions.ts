import * as THREE from 'three';

export interface MissionObjective {
  id: string;
  title: string;
  description: string;
  objective: string;
  targetPosition: THREE.Vector3;
  radius: number;
  reward: number;
  type: 'reach' | 'collect' | 'survive';
  completed: boolean;
  active: boolean;
}

export interface MissionHudState {
  title: string;
  description: string;
  objective: string;
  reward: number;
  progress: number;
  isActive: boolean;
  isCompleted: boolean;
  completedCount: number;
}

export class MissionSystem {
  missions: MissionObjective[] = [];
  currentMissionIndex = 0;
  showMessage: (msg: string) => void;

  constructor(showMessage: (msg: string) => void) {
    this.showMessage = showMessage;
    this.setupMissions();
  }

  private setupMissions() {
    this.missions = [
      {
        id: 'go_school',
        title: 'الذهاب إلى المدرسة',
        description: 'اذهب إلى مدرسة إلمور الثانوية',
        objective: 'صل إلى المدرسة',
        targetPosition: new THREE.Vector3(-60, 0, -40),
        radius: 12,
        reward: 100,
        type: 'reach',
        completed: false,
        active: true,
      },
      {
        id: 'go_restaurant',
        title: 'جوعان؟',
        description: 'اذهب إلى مطعم جوي فول لشراء الطعام',
        objective: 'صل إلى مطعم جوي فول',
        targetPosition: new THREE.Vector3(55, 0, -30),
        radius: 12,
        reward: 50,
        type: 'reach',
        completed: false,
        active: false,
      },
      {
        id: 'go_home',
        title: 'العودة إلى البيت',
        description: 'ارجع إلى البيت بعد رحلتك في المدينة',
        objective: 'صل إلى البيت',
        targetPosition: new THREE.Vector3(0, 0, 30),
        radius: 10,
        reward: 75,
        type: 'reach',
        completed: false,
        active: false,
      },
      {
        id: 'reach_park',
        title: 'استكشاف الحديقة',
        description: 'اذهب إلى الحديقة في وسط المدينة',
        objective: 'صل إلى الحديقة',
        targetPosition: new THREE.Vector3(30, 0, 0),
        radius: 10,
        reward: 60,
        type: 'reach',
        completed: false,
        active: false,
      },
      {
        id: 'far_corner',
        title: 'استكشاف أطراف المدينة',
        description: 'اذهب إلى أقصى شرق المدينة',
        objective: 'صل إلى أقصى الشرق',
        targetPosition: new THREE.Vector3(80, 0, 0),
        radius: 15,
        reward: 120,
        type: 'reach',
        completed: false,
        active: false,
      },
    ];
  }

  getCurrentMission(): MissionObjective | null {
    if (this.currentMissionIndex >= this.missions.length) return null;
    return this.missions[this.currentMissionIndex];
  }

  update(playerPos: THREE.Vector3, addMoney: (n: number) => void): boolean {
    const mission = this.getCurrentMission();
    if (!mission || mission.completed) return false;

    const dist = playerPos.distanceTo(mission.targetPosition);
    if (dist < mission.radius) {
      mission.completed = true;
      addMoney(mission.reward);
      this.showMessage(`مهمة مكتملة: ${mission.title}! +${mission.reward}$`);

      // Advance to next mission
      this.currentMissionIndex++;
      if (this.currentMissionIndex < this.missions.length) {
        this.missions[this.currentMissionIndex].active = true;
        const next = this.missions[this.currentMissionIndex];
        this.showMessage(`مهمة جديدة: ${next.title} — ${next.description}`);
      } else {
        this.showMessage('أكملت جميع المهام! استمتع بالاستكشاف الحر!');
      }
      return true;
    }
    return false;
  }

  getHudState(): MissionHudState {
    const mission = this.getCurrentMission();
    if (!mission) {
      return {
        title: '',
        description: '',
        objective: '',
        reward: 0,
        progress: 1,
        isActive: false,
        isCompleted: true,
        completedCount: this.missions.length,
      };
    }
    return {
      title: mission.title,
      description: mission.description,
      objective: mission.objective,
      reward: mission.reward,
      progress: 0,
      isActive: true,
      isCompleted: false,
      completedCount: this.currentMissionIndex,
    };
  }

  getMissionMarker(): { position: THREE.Vector3; active: boolean } | null {
    const mission = this.getCurrentMission();
    if (!mission || mission.completed) return null;
    return { position: mission.targetPosition, active: true };
  }
}
