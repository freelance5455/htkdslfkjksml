import * as THREE from 'three';
import { createHouse, createSchool, createRestaurant, createGenericBuilding } from './models/buildings';
import { createStationWagon, createSedan, createVehicle } from './models/vehicles';
import { createNPCModel } from './models/characters';

export interface BuildingInfo {
  name: string;
  nameAr: string;
  mesh: THREE.Group;
  position: THREE.Vector3;
  boundingBox: THREE.Box3;
  isInterior?: boolean;
}

export interface VehicleInfo {
  mesh: THREE.Group;
  position: THREE.Vector3;
  rotation: number;
  velocity: number;
  turnRate: number;
  isStationWagon: boolean;
  isPolice: boolean;
  occupied: boolean;
  bbox: THREE.Box3;
}

const CITY_SIZE = 200;
const ROAD_WIDTH = 10;

export class ElmoreWorld {
  scene: THREE.Scene;
  buildings: BuildingInfo[] = [];
  vehicles: VehicleInfo[] = [];
  npcs: THREE.Group[] = [];
  collidables: THREE.Box3[] = [];
  spawnPoint = new THREE.Vector3(0, 0, 30);
  housePosition = new THREE.Vector3(0, 0, 30);
  schoolPosition = new THREE.Vector3(-60, 0, -40);
  restaurantPosition = new THREE.Vector3(55, 0, -30);
  interiorTrigger = new THREE.Vector3(0, 0, 34);
  isIndoors = false;
  interiorMeshes: THREE.Group[] = [];

  constructor(scene: THREE.Scene) {
    this.scene = scene;
    this.build();
  }

  private build() {
    this.createSky();
    this.createGround();
    this.createRoads();
    this.createBuildings();
    this.createProps();
    this.createVehicles();
    this.createNPCs();
    this.createInterior();
  }

  private createSky() {
    this.scene.background = new THREE.Color(0x87ceeb);
    const fog = new THREE.Fog(0x87ceeb, 80, 200);
    this.scene.fog = fog;
    this.fog = fog;

    const sunLight = new THREE.DirectionalLight(0xffffff, 1.2);
    sunLight.position.set(50, 100, 30);
    sunLight.castShadow = true;
    sunLight.shadow.mapSize.set(2048, 2048);
    sunLight.shadow.camera.left = -120;
    sunLight.shadow.camera.right = 120;
    sunLight.shadow.camera.top = 120;
    sunLight.shadow.camera.bottom = -120;
    sunLight.shadow.camera.near = 1;
    sunLight.shadow.camera.far = 300;
    this.scene.add(sunLight);
    this.sunLight = sunLight;

    const ambient = new THREE.AmbientLight(0xffffff, 0.45);
    this.scene.add(ambient);
    this.ambientLight = ambient;

    const hemi = new THREE.HemisphereLight(0x87ceeb, 0x88aa66, 0.3);
    this.scene.add(hemi);
    this.hemiLight = hemi;

    // Sun sphere
    const sunGeo = new THREE.SphereGeometry(5, 16, 16);
    const sunMat = new THREE.MeshBasicMaterial({ color: 0xffffaa });
    const sun = new THREE.Mesh(sunGeo, sunMat);
    sun.position.set(80, 120, 60);
    this.scene.add(sun);
    this.sunMesh = sun;

    // Clouds
    const cloudMat = new THREE.MeshLambertMaterial({ color: 0xffffff, transparent: true, opacity: 0.8 });
    for (let i = 0; i < 15; i++) {
      const cloud = new THREE.Group();
      for (let j = 0; j < 3 + Math.floor(Math.random() * 3); j++) {
        const blob = new THREE.Mesh(
          new THREE.SphereGeometry(2 + Math.random() * 3, 8, 8),
          cloudMat
        );
        blob.position.set(j * 3 - 3, Math.random() * 2, Math.random() * 2);
        cloud.add(blob);
      }
      cloud.position.set(
        (Math.random() - 0.5) * 300,
        40 + Math.random() * 20,
        (Math.random() - 0.5) * 300
      );
      this.scene.add(cloud);
    }
  }

  private createGround() {
    // Grass ground
    const grassGeo = new THREE.PlaneGeometry(CITY_SIZE * 3, CITY_SIZE * 3);
    const grassMat = new THREE.MeshLambertMaterial({ color: 0x4a7c3a });
    const grass = new THREE.Mesh(grassGeo, grassMat);
    grass.rotation.x = -Math.PI / 2;
    grass.receiveShadow = true;
    this.scene.add(grass);

    // Sidewalks near buildings
    const sidewalkMat = new THREE.MeshLambertMaterial({ color: 0x999999 });
    const sidewalkGeo = new THREE.PlaneGeometry(CITY_SIZE, CITY_SIZE);
    const sidewalk = new THREE.Mesh(sidewalkGeo, sidewalkMat);
    sidewalk.rotation.x = -Math.PI / 2;
    sidewalk.position.y = 0.01;
    sidewalk.receiveShadow = true;
    this.scene.add(sidewalk);
  }

  private createRoads() {
    const roadMat = new THREE.MeshLambertMaterial({ color: 0x333333 });
    const lineMat = new THREE.MeshBasicMaterial({ color: 0xffff00 });

    // Main horizontal road
    const roadH = new THREE.Mesh(new THREE.PlaneGeometry(CITY_SIZE * 1.5, ROAD_WIDTH), roadMat);
    roadH.rotation.x = -Math.PI / 2;
    roadH.position.y = 0.02;
    roadH.receiveShadow = true;
    this.scene.add(roadH);

    // Main vertical road
    const roadV = new THREE.Mesh(new THREE.PlaneGeometry(ROAD_WIDTH, CITY_SIZE * 1.5), roadMat);
    roadV.rotation.x = -Math.PI / 2;
    roadV.position.y = 0.02;
    roadV.receiveShadow = true;
    this.scene.add(roadV);

    // Cross roads
    for (const z of [-50, 50]) {
      const road = new THREE.Mesh(new THREE.PlaneGeometry(CITY_SIZE * 1.5, ROAD_WIDTH * 0.8), roadMat);
      road.rotation.x = -Math.PI / 2;
      road.position.set(0, 0.02, z);
      road.receiveShadow = true;
      this.scene.add(road);
    }

    // Road lines
    for (let i = -80; i < 80; i += 8) {
      const line = new THREE.Mesh(new THREE.PlaneGeometry(3, 0.3), lineMat);
      line.rotation.x = -Math.PI / 2;
      line.position.set(i, 0.03, 0);
      this.scene.add(line);

      const line2 = new THREE.Mesh(new THREE.PlaneGeometry(0.3, 3), lineMat);
      line2.rotation.x = -Math.PI / 2;
      line2.position.set(0, 0.03, i);
      this.scene.add(line2);
    }

    // Street lights
    const poleMat = new THREE.MeshLambertMaterial({ color: 0x444444 });
    const bulbMat = new THREE.MeshLambertMaterial({ color: 0xffffaa, emissive: 0xffff44 });
    for (let i = -60; i <= 60; i += 30) {
      for (const [x, z] of [[ROAD_WIDTH / 2 + 2, i], [-(ROAD_WIDTH / 2 + 2), i], [i, ROAD_WIDTH / 2 + 2], [i, -(ROAD_WIDTH / 2 + 2)]]) {
        const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.15, 5, 8), poleMat);
        pole.position.set(x, 2.5, z);
        pole.castShadow = true;
        this.scene.add(pole);
        const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.3, 8, 8), bulbMat);
        bulb.position.set(x, 5.2, z);
        this.scene.add(bulb);
      }
    }
  }

  private addBuilding(mesh: THREE.Group, x: number, z: number, name: string, nameAr: string) {
    mesh.position.set(x, 0, z);
    this.scene.add(mesh);
    const bbox = new THREE.Box3().setFromObject(mesh);
    this.collidables.push(bbox);
    this.buildings.push({ name, nameAr, mesh, position: new THREE.Vector3(x, 0, z), boundingBox: bbox });
  }

  private createBuildings() {
    // Gumball's house
    const house = createHouse(0xe8c170);
    this.addBuilding(house, 0, 30, 'House', 'بيت غامبول');

    // Elmore High School
    const school = createSchool();
    this.addBuilding(school, -60, -40, 'School', 'مدرسة إلمور الثانوية');

    // Joyful Burger
    const restaurant = createRestaurant();
    this.addBuilding(restaurant, 55, -30, 'Restaurant', 'مطعم جوي فول');

    // Generic city buildings
    const colors = [0x88aacc, 0xcc8866, 0x99ccaa, 0xddaadd, 0xaacc88, 0xccccaa];
    const positions: [number, number][] = [
      [25, 30], [40, 35], [-30, 30], [-45, 25],
      [25, -40], [40, -45], [-30, -10], [-45, -5],
      [60, 10], [55, 25], [-70, 10], [-65, 25],
      [30, 55], [-30, 55], [10, -60], [-10, -65],
    ];
    for (let i = 0; i < positions.length; i++) {
      const [x, z] = positions[i];
      const w = 6 + Math.random() * 6;
      const h = 5 + Math.random() * 10;
      const d = 6 + Math.random() * 6;
      const bldg = createGenericBuilding(w, h, d, colors[i % colors.length]);
      this.addBuilding(bldg, x, z, `Building ${i}`, `مبنى ${i + 1}`);
    }

    // Park area
    const parkMat = new THREE.MeshLambertMaterial({ color: 0x3a6a2a });
    const park = new THREE.Mesh(new THREE.CircleGeometry(12, 24), parkMat);
    park.rotation.x = -Math.PI / 2;
    park.position.set(30, 0.015, 0);
    park.receiveShadow = true;
    this.scene.add(park);

    // Trees
    for (let i = 0; i < 20; i++) {
      this.createTree(
        (Math.random() - 0.5) * 180,
        (Math.random() - 0.5) * 180,
        0.5 + Math.random()
      );
    }
    // Trees in park
    for (let i = 0; i < 6; i++) {
      const angle = (i / 6) * Math.PI * 2;
      this.createTree(30 + Math.cos(angle) * 8, Math.sin(angle) * 8, 1.2);
    }
  }

  private createTree(x: number, z: number, scale: number) {
    const group = new THREE.Group();
    const trunkMat = new THREE.MeshLambertMaterial({ color: 0x6b4226 });
    const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.2 * scale, 0.3 * scale, 2 * scale, 8), trunkMat);
    trunk.position.y = scale;
    trunk.castShadow = true;
    group.add(trunk);

    const leafMat = new THREE.MeshLambertMaterial({ color: 0x3a7a2a });
    for (let j = 0; j < 3; j++) {
      const leaves = new THREE.Mesh(new THREE.SphereGeometry(1.2 * scale, 8, 8), leafMat);
      leaves.position.y = (2 + j * 0.6) * scale;
      leaves.position.x = (Math.random() - 0.5) * 0.5;
      leaves.castShadow = true;
      group.add(leaves);
    }
    group.position.set(x, 0, z);
    this.scene.add(group);
    const bbox = new THREE.Box3().setFromObject(group);
    this.collidables.push(bbox);
  }

  private createProps() {
    // Benches
    const benchMat = new THREE.MeshLambertMaterial({ color: 0x8b6b3a });
    for (let i = 0; i < 4; i++) {
      const bench = new THREE.Mesh(new THREE.BoxGeometry(2, 0.4, 0.6), benchMat);
      bench.position.set(25 + i * 3, 0.2, -2);
      bench.castShadow = true;
      this.scene.add(bench);
    }

    // Fire hydrants
    const hydrantMat = new THREE.MeshLambertMaterial({ color: 0xcc2222 });
    for (let i = 0; i < 8; i++) {
      const hydrant = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.25, 0.7, 8), hydrantMat);
      hydrant.position.set(
        (Math.random() - 0.5) * 160,
        0.35,
        (Math.random() - 0.5) * 160
      );
      this.scene.add(hydrant);
    }

    // Trash cans
    const trashMat = new THREE.MeshLambertMaterial({ color: 0x448844 });
    for (let i = 0; i < 6; i++) {
      const trash = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.3, 0.8, 8), trashMat);
      trash.position.set(
        (Math.random() - 0.5) * 140,
        0.4,
        (Math.random() - 0.5) * 140
      );
      this.scene.add(trash);
    }
  }

  private createVehicles() {
    // Waterson's red station wagon near house
    const wagon = createStationWagon();
    wagon.position.set(6, 0, 28);
    wagon.rotation.y = 0.3;
    this.scene.add(wagon);
    const wagonBbox = new THREE.Box3().setFromObject(wagon);
    this.vehicles.push({
      mesh: wagon,
      position: wagon.position.clone(),
      rotation: 0.3,
      velocity: 0,
      turnRate: 0,
      isStationWagon: true,
      isPolice: false,
      occupied: false,
      bbox: wagonBbox,
    });

    // Random sedans
    const sedanColors = [0x3366cc, 0xcc3333, 0x33aa33, 0xcccccc, 0x222222, 0xff8800, 0x9944cc];
    for (let i = 0; i < 8; i++) {
      const car = createSedan(sedanColors[i % sedanColors.length]);
      const angle = Math.random() * Math.PI * 2;
      const dist = 20 + Math.random() * 60;
      const x = Math.cos(angle) * dist;
      const z = (Math.random() - 0.5) * 160;
      car.position.set(x, 0, z);
      car.rotation.y = Math.random() * Math.PI * 2;
      this.scene.add(car);
      this.vehicles.push({
        mesh: car,
        position: car.position.clone(),
        rotation: car.rotation.y,
        velocity: 0,
        turnRate: 0,
        isStationWagon: false,
        isPolice: false,
        occupied: false,
        bbox: new THREE.Box3().setFromObject(car),
      });
    }
  }

  private createNPCs() {
    const npcColors = [0xff6644, 0x44aaff, 0x66ff66, 0xffaa44, 0xff66aa, 0xaaff44];
    for (let i = 0; i < 12; i++) {
      const npc = createNPCModel(npcColors[i % npcColors.length]);
      npc.position.set(
        (Math.random() - 0.5) * 120,
        0,
        (Math.random() - 0.5) * 120
      );
      npc.rotation.y = Math.random() * Math.PI * 2;
      this.scene.add(npc);
      npc.userData.wanderTarget = new THREE.Vector3(
        npc.position.x + (Math.random() - 0.5) * 20,
        0,
        npc.position.z + (Math.random() - 0.5) * 20
      );
      npc.userData.wanderTimer = Math.random() * 5;
      this.npcs.push(npc);
    }
  }

  createInterior() {
    // Living room
    const interior = new THREE.Group();

    // Floor
    const floorMat = new THREE.MeshLambertMaterial({ color: 0xc4a070 });
    const floor = new THREE.Mesh(new THREE.PlaneGeometry(12, 12), floorMat);
    floor.rotation.x = -Math.PI / 2;
    floor.receiveShadow = true;
    interior.add(floor);

    // Walls
    const wallMat = new THREE.MeshLambertMaterial({ color: 0xe8d4a0 });
    const wallH = 4;
    const wallT = 0.2;
    const wallS = 12;

    const wallN = new THREE.Mesh(new THREE.BoxGeometry(wallS, wallH, wallT), wallMat);
    wallN.position.set(0, wallH / 2, -wallS / 2);
    interior.add(wallN);
    const wallS_mesh = new THREE.Mesh(new THREE.BoxGeometry(wallS, wallH, wallT), wallMat);
    wallS_mesh.position.set(0, wallH / 2, wallS / 2);
    interior.add(wallS_mesh);
    const wallE = new THREE.Mesh(new THREE.BoxGeometry(wallT, wallH, wallS), wallMat);
    wallE.position.set(wallS / 2, wallH / 2, 0);
    interior.add(wallE);
    const wallW = new THREE.Mesh(new THREE.BoxGeometry(wallT, wallH, wallS), wallMat);
    wallW.position.set(-wallS / 2, wallH / 2, 0);
    interior.add(wallW);

    // Sofa
    const sofaMat = new THREE.MeshLambertMaterial({ color: 0x4466aa });
    const sofaBase = new THREE.Mesh(new THREE.BoxGeometry(3, 0.5, 1.2), sofaMat);
    sofaBase.position.set(-3, 0.25, 3);
    sofaBase.castShadow = true;
    interior.add(sofaBase);
    const sofaBack = new THREE.Mesh(new THREE.BoxGeometry(3, 1, 0.2), sofaMat);
    sofaBack.position.set(-3, 0.75, 3.5);
    interior.add(sofaBack);

    // TV
    const tvMat = new THREE.MeshLambertMaterial({ color: 0x222222 });
    const tvStand = new THREE.Mesh(new THREE.BoxGeometry(2, 0.6, 0.5), tvMat);
    tvStand.position.set(3, 0.3, -4);
    interior.add(tvStand);
    const tvScreen = new THREE.Mesh(
      new THREE.BoxGeometry(1.8, 1, 0.1),
      new THREE.MeshLambertMaterial({ color: 0x113355, emissive: 0x002244 })
    );
    tvScreen.position.set(3, 1.3, -4);
    interior.add(tvScreen);

    // Table
    const tableMat = new THREE.MeshLambertMaterial({ color: 0x8b6b3a });
    const table = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.4, 1), tableMat);
    table.position.set(0, 0.2, 0);
    table.castShadow = true;
    interior.add(table);

    // Lamp
    const lampPole = new THREE.Mesh(
      new THREE.CylinderGeometry(0.05, 0.05, 1.5, 8),
      new THREE.MeshLambertMaterial({ color: 0x444444 })
    );
    lampPole.position.set(4.5, 0.75, 3);
    interior.add(lampPole);
    const lampShade = new THREE.Mesh(
      new THREE.ConeGeometry(0.3, 0.4, 8),
      new THREE.MeshLambertMaterial({ color: 0xffee88, emissive: 0x664400 })
    );
    lampShade.position.set(4.5, 1.6, 3);
    interior.add(lampShade);

    // Ceiling light
    const ceilLight = new THREE.PointLight(0xffeeaa, 0.8, 15);
    ceilLight.position.set(0, 3.8, 0);
    interior.add(ceilLight);

    // Rug
    const rugMat = new THREE.MeshLambertMaterial({ color: 0xaa4444 });
    const rug = new THREE.Mesh(new THREE.PlaneGeometry(4, 3), rugMat);
    rug.rotation.x = -Math.PI / 2;
    rug.position.set(0, 0.01, 1);
    interior.add(rug);

    interior.visible = false;
    this.scene.add(interior);
    this.interiorMeshes.push(interior);
    this.interiorGroup = interior;
  }

  interiorGroup?: THREE.Group;
  private sunLight?: THREE.DirectionalLight;
  private ambientLight?: THREE.AmbientLight;
  private hemiLight?: THREE.HemisphereLight;
  private sunMesh?: THREE.Mesh;
  private fog?: THREE.Fog;

  getSunLight(): THREE.DirectionalLight { return this.sunLight!; }
  getAmbientLight(): THREE.AmbientLight { return this.ambientLight!; }
  getHemiLight(): THREE.HemisphereLight { return this.hemiLight!; }
  getSunMesh(): THREE.Mesh { return this.sunMesh!; }
  getFog(): THREE.Fog { return this.fog!; }

  toggleInterior(show: boolean) {
    if (this.interiorGroup) {
      this.interiorGroup.visible = show;
    }
    this.isIndoors = show;
  }

  getNearestVehicle(pos: THREE.Vector3): VehicleInfo | null {
    let nearest: VehicleInfo | null = null;
    let minDist = Infinity;
    for (const v of this.vehicles) {
      if (v.occupied) continue;
      const d = v.position.distanceTo(pos);
      if (d < minDist) {
        minDist = d;
        nearest = v;
      }
    }
    return nearest;
  }

  checkCollision(pos: THREE.Vector3, radius: number = 0.5): boolean {
    const sphere = new THREE.Sphere(pos, radius);
    for (const box of this.collidables) {
      if (box.intersectsSphere(sphere)) return true;
    }
    return false;
  }

  updateNPCs(dt: number) {
    for (const npc of this.npcs) {
      npc.userData.wanderTimer -= dt;
      if (npc.userData.wanderTimer <= 0) {
        npc.userData.wanderTarget = new THREE.Vector3(
          npc.position.x + (Math.random() - 0.5) * 30,
          0,
          npc.position.z + (Math.random() - 0.5) * 30
        );
        npc.userData.wanderTimer = 3 + Math.random() * 4;
      }
      const target = npc.userData.wanderTarget as THREE.Vector3;
      const dir = new THREE.Vector3().subVectors(target, npc.position);
      dir.y = 0;
      const dist = dir.length();
      if (dist > 1) {
        dir.normalize();
        npc.position.add(dir.multiplyScalar(2 * dt));
        npc.rotation.y = Math.atan2(dir.x, dir.z);
        // Walk animation
        const t = performance.now() * 0.005;
        const ud = npc.userData;
        if (ud.legL && ud.legR) {
          ud.legL.rotation.x = Math.sin(t) * 0.4;
          ud.legR.rotation.x = -Math.sin(t) * 0.4;
          ud.armL.rotation.x = -Math.sin(t) * 0.3;
          ud.armR.rotation.x = Math.sin(t) * 0.3;
        }
      }
    }
  }

  getNearbyBuilding(pos: THREE.Vector3): BuildingInfo | null {
    for (const b of this.buildings) {
      if (b.nameAr === 'بيت غامبول') {
        if (pos.distanceTo(b.position) < 10) return b;
      }
    }
    return null;
  }
}
