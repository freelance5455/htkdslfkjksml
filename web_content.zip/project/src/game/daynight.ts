import * as THREE from 'three';

export class DayNightCycle {
  scene: THREE.Scene;
  sunLight: THREE.DirectionalLight;
  ambient: THREE.AmbientLight;
  hemi: THREE.HemisphereLight;
  sunMesh: THREE.Mesh;
  moonMesh: THREE.Mesh;
  fog: THREE.Fog;

  // 0 = dawn, 0.25 = noon, 0.5 = dusk, 0.75 = midnight
  time = 0.15; // start in morning
  daySpeed = 0.005; // full cycle ~ 200 seconds
  isNight = false;

  constructor(
    scene: THREE.Scene,
    sunLight: THREE.DirectionalLight,
    ambient: THREE.AmbientLight,
    hemi: THREE.HemisphereLight,
    sunMesh: THREE.Mesh,
    fog: THREE.Fog
  ) {
    this.scene = scene;
    this.sunLight = sunLight;
    this.ambient = ambient;
    this.hemi = hemi;
    this.sunMesh = sunMesh;
    this.fog = fog;

    // Create moon
    const moonGeo = new THREE.SphereGeometry(4, 16, 16);
    const moonMat = new THREE.MeshBasicMaterial({ color: 0xddddee });
    this.moonMesh = new THREE.Mesh(moonGeo, moonMat);
    this.moonMesh.visible = false;
    this.scene.add(this.moonMesh);
  }

  update(dt: number) {
    this.time += this.daySpeed * dt;
    if (this.time >= 1) this.time -= 1;

    const angle = this.time * Math.PI * 2;
    const sunAngle = angle - Math.PI / 2;
    const sunHeight = Math.sin(sunAngle);
    const sunX = Math.cos(sunAngle) * 100;
    const sunY = sunHeight * 100;
    const sunZ = 40;

    this.sunLight.position.set(sunX, Math.max(sunY, 10), sunZ);
    this.sunMesh.position.set(sunX, sunY, sunZ);

    // Moon is opposite
    this.moonMesh.position.set(-sunX, -sunY, sunZ);

    const dayFactor = Math.max(0, sunHeight);

    // Determine if night
    this.isNight = sunHeight < -0.1;

    // Sky color
    let skyColor: THREE.Color;
    if (sunHeight > 0.3) {
      skyColor = new THREE.Color(0x87ceeb); // day
    } else if (sunHeight > -0.1) {
      // sunset/sunrise - blend orange to dark blue
      const t = (sunHeight + 0.1) / 0.4;
      skyColor = new THREE.Color(0x224466).lerp(new THREE.Color(0xff8844), t * 0.6 + 0.3);
      skyColor.lerp(new THREE.Color(0x87ceeb), Math.max(0, t - 0.5) * 2);
    } else {
      skyColor = new THREE.Color(0x0a0a22); // night
    }
    this.scene.background = skyColor;
    this.fog.color = skyColor;

    // Light intensity
    this.sunLight.intensity = dayFactor * 1.2;
    this.ambient.intensity = 0.15 + dayFactor * 0.35;
    this.hemi.intensity = 0.1 + dayFactor * 0.25;

    // Sun/moon visibility
    this.sunMesh.visible = sunHeight > -0.05;
    this.moonMesh.visible = sunHeight < 0.05;

    // Sun color shift at sunset
    if (sunHeight > 0 && sunHeight < 0.3) {
      const sunsetT = 1 - sunHeight / 0.3;
      this.sunLight.color.lerpColors(
        new THREE.Color(0xffffff),
        new THREE.Color(0xffaa66),
        sunsetT
      );
      this.sunMesh.material instanceof THREE.MeshBasicMaterial &&
        (this.sunMesh.material.color.setHex(sunsetT > 0.5 ? 0xff6644 : 0xffffaa));
    } else {
      this.sunLight.color.setHex(0xffffff);
    }
  }

  getTimeLabel(): string {
    const hour = Math.floor(this.time * 24);
    if (hour >= 5 && hour < 12) return 'صباحاً';
    if (hour >= 12 && hour < 17) return 'ظهراً';
    if (hour >= 17 && hour < 20) return 'مساءً';
    return 'ليلاً';
  }
}
