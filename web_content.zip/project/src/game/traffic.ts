import * as THREE from 'three';
import { createSedan } from './models/vehicles';

interface TrafficCar {
  mesh: THREE.Group;
  position: THREE.Vector3;
  rotation: number;
  speed: number;
  // Road network: cars drive along the main roads
  // 0 = horizontal road (along X), 1 = vertical road (along Z)
  axis: 0 | 1;
  direction: 1 | -1;
}

// Road layout: main horizontal road at z=0, main vertical road at x=0
// Cross roads at z=-50 and z=50
const ROAD_WIDTH = 10;

export class TrafficSystem {
  scene: THREE.Scene;
  cars: TrafficCar[] = [];
  colors = [0x3366cc, 0xcc3333, 0x33aa33, 0xcccccc, 0x222222, 0xff8800, 0x9944cc, 0xdd6644, 0x4499aa];

  constructor(scene: THREE.Scene) {
    this.scene = scene;
    this.spawnTraffic();
  }

  private spawnTraffic() {
    const roads: { axis: 0 | 1; offset: number }[] = [
      { axis: 0, offset: 0 },   // horizontal at z=0
      { axis: 1, offset: 0 },   // vertical at x=0
      { axis: 0, offset: -50 }, // horizontal at z=-50
      { axis: 0, offset: 50 },  // horizontal at z=50
    ];

    for (let i = 0; i < 12; i++) {
      const road = roads[i % roads.length];
      const color = this.colors[i % this.colors.length];
      const car = createSedan(color);

      let x = 0, z = 0;
      let rotation = 0;
      const direction: 1 | -1 = Math.random() > 0.5 ? 1 : -1;

      if (road.axis === 0) {
        // Horizontal road - car drives along X
        x = (Math.random() - 0.5) * 160;
        z = road.offset + (direction > 0 ? -2.5 : 2.5); // right lane
        rotation = direction > 0 ? Math.PI / 2 : -Math.PI / 2;
      } else {
        // Vertical road - car drives along Z
        z = (Math.random() - 0.5) * 160;
        x = road.offset + (direction > 0 ? 2.5 : -2.5);
        rotation = direction > 0 ? 0 : Math.PI;
      }

      car.position.set(x, 0, z);
      car.rotation.y = rotation;
      this.scene.add(car);

      this.cars.push({
        mesh: car,
        position: new THREE.Vector3(x, 0, z),
        rotation,
        speed: 6 + Math.random() * 6,
        axis: road.axis,
        direction,
      });
    }
  }

  update(dt: number, playerPos: THREE.Vector3) {
    for (const car of this.cars) {
      // Move along axis
      if (car.axis === 0) {
        car.position.x += car.direction * car.speed * dt;
        // Wrap around
        if (car.direction > 0 && car.position.x > 90) car.position.x = -90;
        if (car.direction < 0 && car.position.x < -90) car.position.x = 90;
      } else {
        car.position.z += car.direction * car.speed * dt;
        if (car.direction > 0 && car.position.z > 90) car.position.z = -90;
        if (car.direction < 0 && car.position.z < -90) car.position.z = 90;
      }

      car.mesh.position.copy(car.position);
      car.mesh.rotation.y = car.rotation;

      // Spin wheels
      if (car.mesh.userData.wheels) {
        for (const wheel of car.mesh.userData.wheels as THREE.Mesh[]) {
          wheel.rotation.x += car.speed * dt * 2;
        }
      }

      // Slow down near player to avoid running them over
      const distToPlayer = car.position.distanceTo(playerPos);
      if (distToPlayer < 8) {
        const targetSpeed = distToPlayer < 4 ? 0 : 3;
        car.speed = THREE.MathUtils.lerp(car.speed, targetSpeed, dt * 3);
      } else {
        car.speed = THREE.MathUtils.lerp(car.speed, 8, dt * 0.5);
      }
    }
  }
}
