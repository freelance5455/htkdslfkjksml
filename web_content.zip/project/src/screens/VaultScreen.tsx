import { useEffect, useRef, useState, useCallback } from 'react';
import { Heart, Lock } from 'lucide-react';
import { sounds, initAudio } from '@/lib/audio';
import { ConfettiBurst } from '@/components/ConfettiBurst';

interface VaultScreenProps {
  onUnlocked: () => void;
}

type Phase = 'locked' | 'holding' | 'unlocked' | 'letter';

const HOLD_DURATION = 1500;

export function VaultScreen({ onUnlocked }: VaultScreenProps) {
  const [phase, setPhase] = useState<Phase>('locked');
  const [progress, setProgress] = useState(0);
  const [showConfetti, setShowConfetti] = useState(false);
  const holdTimer = useRef<number | null>(null);
  const rafRef = useRef<number | null>(null);
  const holdStart = useRef(0);

  const stopHold = useCallback(() => {
    if (holdTimer.current) {
      clearTimeout(holdTimer.current);
      holdTimer.current = null;
    }
    if (rafRef.current) {
      cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    }
    if (phase === 'holding') {
      setPhase('locked');
      setProgress(0);
    }
  }, [phase]);

  const animateProgress = useCallback(() => {
    const elapsed = Date.now() - holdStart.current;
    const pct = Math.min(elapsed / HOLD_DURATION, 1);
    setProgress(pct);
    if (pct < 1) {
      rafRef.current = requestAnimationFrame(animateProgress);
    }
  }, []);

  const startHold = useCallback(() => {
    initAudio();
    sounds.softChime();
    holdStart.current = Date.now();
    setPhase('holding');
    animateProgress();

    holdTimer.current = window.setTimeout(() => {
      setPhase('unlocked');
      setShowConfetti(true);
      sounds.unlock();
    }, HOLD_DURATION);
  }, [animateProgress]);

  useEffect(() => {
    return () => {
      if (holdTimer.current) clearTimeout(holdTimer.current);
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, []);

  const handleConfettiDone = useCallback(() => {
    setShowConfetti(false);
    setPhase('letter');
  }, []);

  const radius = 52;
  const circumference = 2 * Math.PI * radius;
  const dashOffset = circumference * (1 - progress);

  if (phase === 'letter') {
    return (
      <div className="screen-enter min-h-screen flex items-center justify-center px-6 py-8 pb-28">
        <div className="glass-card-warm rounded-3xl p-8 max-w-md w-full relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-rose-gold/10 rounded-full blur-3xl -translate-y-10 translate-x-10" />
          <div className="relative z-10">
            <div className="flex justify-center mb-6">
              <div className="w-14 h-14 rounded-full bg-rose-gold/15 flex items-center justify-center">
                <Heart size={28} className="text-rose-gold-bright heartbeat" fill="currentColor" />
              </div>
            </div>
            <p className="text-center text-xs uppercase tracking-[0.3em] text-rose-gold/60 mb-4 font-body">
              A Gift Made With Love
            </p>
            <h1 className="font-serif-display text-3xl text-center text-white/95 mb-6 leading-snug">
              Welcome, beautiful soul.
            </h1>
            <div className="space-y-4 text-white/70 text-[15px] leading-relaxed font-body">
              <p>
                I built this little world just for you. It lives on your phone,
                works without the internet, and is here whenever you need it.
              </p>
              <p>
                Inside you'll find our memories, surprise coupons, a jar of
                reasons why you're amazing, and letters for the moments you need
                them most.
              </p>
              <p className="text-rose-gold-bright font-body italic">
                Take your time. Explore. And remember — you are loved.
              </p>
            </div>
            <button
              onClick={() => {
                sounds.chime();
                onUnlocked();
              }}
              className="tap-bounce mt-8 w-full py-4 rounded-2xl bg-gradient-to-r from-rose-gold/20 to-gold/20 border border-rose-gold/30 text-rose-gold-bright font-body font-medium text-sm tracking-wide hover:from-rose-gold/30 hover:to-gold/30 transition-all"
            >
              Enter Your Gift
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="screen-enter min-h-screen flex flex-col items-center justify-center px-6 pb-28 relative">
      <ConfettiBurst active={showConfetti} onComplete={handleConfettiDone} />

      {/* Floating lock icon */}
      <div className="mb-8 flex flex-col items-center gap-3">
        <div className="w-16 h-16 rounded-full glass-card flex items-center justify-center">
          <Lock size={26} className="text-white/50" />
        </div>
        <p className="text-xs uppercase tracking-[0.35em] text-white/30 font-body">
          The Vault
        </p>
      </div>

      {/* Hold to unlock heart */}
      <div className="relative flex flex-col items-center">
        <div className="relative w-32 h-32 flex items-center justify-center">
          {/* Progress ring */}
          {phase === 'holding' && (
            <svg className="absolute inset-0 -rotate-90" width="128" height="128">
              <circle
                cx="64"
                cy="64"
                r={radius}
                fill="none"
                stroke="rgba(232,180,184,0.1)"
                strokeWidth="3"
              />
              <circle
                cx="64"
                cy="64"
                r={radius}
                fill="none"
                stroke="url(#holdGrad)"
                strokeWidth="3"
                strokeLinecap="round"
                strokeDasharray={circumference}
                strokeDashoffset={dashOffset}
                style={{ transition: 'stroke-dashoffset 0.05s linear' }}
              />
              <defs>
                <linearGradient id="holdGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#e8b4b8" />
                  <stop offset="100%" stopColor="#d4af7a" />
                </linearGradient>
              </defs>
            </svg>
          )}

          {/* Heart button */}
          <button
            onPointerDown={startHold}
            onPointerUp={stopHold}
            onPointerLeave={stopHold}
            onPointerCancel={stopHold}
            disabled={phase === 'unlocked'}
            className={`relative w-24 h-24 rounded-full flex items-center justify-center tap-bounce ${
              phase === 'holding' ? 'glow-heart' : ''
            }`}
            style={{
              background:
                phase === 'holding'
                  ? 'radial-gradient(circle, rgba(232,180,184,0.25) 0%, rgba(109,40,217,0.1) 70%)'
                  : 'radial-gradient(circle, rgba(255,255,255,0.06) 0%, rgba(255,255,255,0.02) 70%)',
              border: '1px solid rgba(232,180,184,0.2)',
            }}
          >
            <Heart
              size={40}
              className={`text-rose-gold-bright ${phase === 'holding' ? 'heartbeat' : ''}`}
              fill="currentColor"
              style={{
                filter: 'drop-shadow(0 0 12px rgba(232,180,184,0.5))',
                transition: 'all 0.3s ease',
                opacity: phase === 'unlocked' ? 0.3 : 1,
              }}
            />
          </button>
        </div>

        <p className="mt-6 text-sm text-white/50 font-body tracking-wide text-center">
          {phase === 'locked' && 'Hold the heart to unlock'}
          {phase === 'holding' && 'Keep holding...'}
          {phase === 'unlocked' && 'Opening your gift...'}
        </p>
      </div>

      {/* Decorative glow orbs */}
      <div className="absolute top-1/4 left-8 w-24 h-24 bg-violet-500/10 rounded-full blur-3xl" style={{ animation: 'drift 8s ease-in-out infinite' }} />
      <div className="absolute bottom-1/3 right-6 w-32 h-32 bg-rose-gold/8 rounded-full blur-3xl" style={{ animation: 'drift 10s ease-in-out infinite reverse' }} />
    </div>
  );
}
