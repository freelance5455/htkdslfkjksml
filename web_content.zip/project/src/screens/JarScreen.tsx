import { useCallback, useState } from 'react';
import { Sparkles, Plus, X, Shuffle } from 'lucide-react';
import { sounds } from '@/lib/audio';
import { useLocalStorage } from '@/lib/useLocalStorage';

const defaultReasons: string[] = [
  'You make people feel seen — really seen — in a way very few can.',
  "Your kindness isn't selective. You're gentle with strangers, and that says everything.",
  "You find humor in the small things, and it makes ordinary days feel special.",
  "You don't give up on people, even when they'd understand if you did.",
  "The way your eyes light up when you talk about something you love — it's magnetic.",
  "You listen with your whole self. Not just your ears, but your heart too.",
  "You're braver than you think. I've watched you face things that would break most people.",
  "Your laugh is the kind that makes other people laugh, even if they don't know why.",
  "You make the people around you better, just by being yourself.",
  "You've been through a lot, and you're still soft. That's not weakness — that's the strongest thing in the world.",
];

export function JarScreen() {
  const [customReasons, setCustomReasons] = useLocalStorage<string[]>('gift_custom_reasons', []);
  const [currentNote, setCurrentNote] = useState<string | null>(null);
  const [noteIndex, setNoteIndex] = useState<number | null>(null);
  const [showAdd, setShowAdd] = useState(false);
  const [newReason, setNewReason] = useState('');
  const [jarShake, setJarShake] = useState(false);

  const allReasons = [...defaultReasons, ...customReasons];

  const drawNote = useCallback(() => {
    sounds.jar();
    setJarShake(true);
    setTimeout(() => setJarShake(false), 500);

    let idx = Math.floor(Math.random() * allReasons.length);
    if (noteIndex !== null && allReasons.length > 1) {
      while (idx === noteIndex) {
        idx = Math.floor(Math.random() * allReasons.length);
      }
    }
    setNoteIndex(idx);
    setCurrentNote(allReasons[idx]);
  }, [allReasons, noteIndex]);

  const handleAddReason = () => {
    const trimmed = newReason.trim();
    if (!trimmed) return;
    sounds.chime();
    setCustomReasons((prev) => [...prev, trimmed]);
    setNewReason('');
    setShowAdd(false);
  };

  const handleRemoveCustom = (reason: string) => {
    sounds.tap();
    setCustomReasons((prev) => prev.filter((r) => r !== reason));
  };

  return (
    <div className="screen-enter min-h-screen px-5 pt-14 pb-28">
      {/* Header */}
      <div className="mb-6 text-center">
        <div className="inline-flex items-center gap-2 mb-2">
          <Sparkles size={16} className="text-rose-gold/60" />
          <p className="text-xs uppercase tracking-[0.3em] text-rose-gold/50 font-body">
            Why You're Amazing
          </p>
        </div>
        <h1 className="font-serif-display text-3xl text-white/95 glow-text">
          Jar of Reasons
        </h1>
        <p className="text-white/40 text-sm font-body mt-2 max-w-xs mx-auto">
          Tap the jar to pull out a glowing note
        </p>
      </div>

      {/* Jar */}
      <div className="flex flex-col items-center mb-6">
        <button
          onClick={drawNote}
          className="tap-bounce relative"
          aria-label="Tap the jar to draw a reason"
        >
          <div
            className={`jar-glow ${jarShake ? '' : ''}`}
            style={{
              transform: jarShake ? 'rotate(-3deg)' : 'rotate(0deg)',
              transition: 'transform 0.1s ease',
            }}
          >
            <svg width="140" height="180" viewBox="0 0 140 180" fill="none">
              {/* Lid */}
              <rect x="35" y="12" width="70" height="18" rx="4" fill="rgba(212,175,122,0.4)" stroke="rgba(212,175,122,0.6)" strokeWidth="1.5" />
              <rect x="38" y="8" width="64" height="8" rx="3" fill="rgba(212,175,122,0.3)" stroke="rgba(212,175,122,0.5)" strokeWidth="1" />
              {/* Jar body */}
              <path
                d="M40 30 Q40 28 42 28 L98 28 Q100 28 100 30 L100 150 Q100 165 85 165 L55 165 Q40 165 40 150 Z"
                fill="rgba(255,255,255,0.04)"
                stroke="rgba(232,180,184,0.3)"
                strokeWidth="1.5"
              />
              {/* Inner glow notes */}
              <circle cx="58" cy="70" r="4" fill="rgba(232,180,184,0.3)" />
              <circle cx="78" cy="85" r="3" fill="rgba(212,175,122,0.3)" />
              <circle cx="68" cy="100" r="5" fill="rgba(232,180,184,0.25)" />
              <circle cx="82" cy="115" r="3" fill="rgba(212,175,122,0.25)" />
              <circle cx="60" cy="125" r="4" fill="rgba(232,180,184,0.2)" />
              <circle cx="75" cy="140" r="3" fill="rgba(212,175,122,0.2)" />
              {/* Highlight */}
              <ellipse cx="52" cy="80" rx="5" ry="30" fill="rgba(255,255,255,0.06)" />
              {/* Label */}
              <rect x="50" y="100" width="40" height="30" rx="3" fill="rgba(232,180,184,0.06)" stroke="rgba(232,180,184,0.15)" strokeWidth="0.5" />
              <text x="70" y="115" textAnchor="middle" fill="rgba(232,180,184,0.4)" fontSize="8" fontFamily="Outfit, sans-serif">
                Reasons
              </text>
              <text x="70" y="124" textAnchor="middle" fill="rgba(232,180,184,0.4)" fontSize="8" fontFamily="Outfit, sans-serif">
                I love you
              </text>
            </svg>
          </div>
        </button>
        <p className="text-white/40 text-xs font-body mt-3 flex items-center gap-1.5">
          <Shuffle size={11} />
          {allReasons.length} reasons inside
        </p>
      </div>

      {/* Current note */}
      {currentNote && (
        <div className="max-w-md mx-auto mb-6">
          <div
            key={noteIndex}
            className="note-rise glass-card-warm rounded-2xl p-6 relative"
          >
            <div className="absolute top-0 right-0 w-24 h-24 bg-rose-gold/8 rounded-full blur-2xl -translate-y-8 translate-x-8" />
            <div className="relative z-10">
              <div className="flex items-center gap-2 mb-3">
                <Sparkles size={14} className="text-rose-gold/60" />
                <p className="text-[10px] uppercase tracking-wider text-rose-gold/50 font-body">
                  Reason #{(noteIndex ?? 0) + 1}
                </p>
                {noteIndex !== null && noteIndex >= defaultReasons.length && (
                  <span className="text-[9px] bg-rose-gold/15 text-rose-gold-bright px-2 py-0.5 rounded-full font-body">
                    Yours
                  </span>
                )}
              </div>
              <p className="font-serif-display italic text-lg text-white/90 leading-relaxed">
                "{currentNote}"
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Add your own */}
      {showAdd ? (
        <div className="max-w-md mx-auto glass-card rounded-2xl p-5">
          <div className="flex items-center justify-between mb-3">
            <p className="text-sm text-white/70 font-body">Add your own reason</p>
            <button
              onClick={() => { setShowAdd(false); setNewReason(''); }}
              className="tap-bounce text-white/40 hover:text-white/60 transition-colors"
            >
              <X size={18} />
            </button>
          </div>
          <textarea
            value={newReason}
            onChange={(e) => setNewReason(e.target.value)}
            placeholder="Write something from the heart..."
            rows={3}
            className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-white/80 text-sm font-body placeholder:text-white/25 focus:outline-none focus:border-rose-gold/30 resize-none transition-colors"
            autoFocus
          />
          <button
            onClick={handleAddReason}
            disabled={!newReason.trim()}
            className="tap-bounce mt-3 w-full py-3 rounded-xl bg-gradient-to-r from-rose-gold/20 to-gold/20 border border-rose-gold/30 text-rose-gold-bright font-body text-sm font-medium disabled:opacity-30 disabled:cursor-not-allowed transition-all"
          >
            Add to Jar
          </button>
        </div>
      ) : (
        <div className="max-w-md mx-auto">
          <button
            onClick={() => { sounds.tap(); setShowAdd(true); }}
            className="tap-bounce w-full py-3 rounded-xl glass-card text-white/60 text-sm font-body flex items-center justify-center gap-2 hover:text-white/80 transition-colors"
          >
            <Plus size={16} />
            Add your own reason
          </button>
        </div>
      )}

      {/* Custom reasons list */}
      {customReasons.length > 0 && !showAdd && (
        <div className="max-w-md mx-auto mt-6">
          <p className="text-[10px] uppercase tracking-wider text-white/30 font-body mb-3 px-1">
            Your added reasons ({customReasons.length})
          </p>
          <div className="space-y-2">
            {customReasons.map((reason, i) => (
              <div
                key={i}
                className="glass-card rounded-xl p-3 flex items-start justify-between gap-3"
              >
                <p className="text-white/55 text-[13px] font-body leading-relaxed flex-1">
                  {reason}
                </p>
                <button
                  onClick={() => handleRemoveCustom(reason)}
                  className="tap-bounce text-white/20 hover:text-rose-gold/60 transition-colors flex-shrink-0 mt-0.5"
                >
                  <X size={14} />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
