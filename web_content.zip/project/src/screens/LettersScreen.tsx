import { useCallback, useState } from 'react';
import { Mail, CloudMoon, Trophy, Heart, X } from 'lucide-react';
import { sounds } from '@/lib/audio';
import { useLocalStorage } from '@/lib/useLocalStorage';

interface Letter {
  id: number;
  label: string;
  icon: typeof Mail;
  gradient: string;
  subject: string;
  body: string;
}

const letters: Letter[] = [
  {
    id: 1,
    label: "Open when you're feeling down",
    icon: CloudMoon,
    gradient: 'from-blue-900/30 to-violet-900/20',
    subject: 'For when the world feels heavy',
    body: `Hey you,

I know today is hard. I know it feels like everything is too much and you want to hide from it all. That's okay. You don't have to be okay right now.

But I want you to remember something: every storm you've ever been through, you've come out the other side. Not because you're invincible — but because you're resilient in a way you don't even see.

You are allowed to rest. You are allowed to ask for help. You are allowed to not be fine.

And when you're ready — even if it takes a while — I'll be here. Always.

With all my heart,
Me`,
  },
  {
    id: 2,
    label: "Open when you can't sleep",
    icon: CloudMoon,
    gradient: 'from-indigo-900/30 to-violet-900/20',
    subject: 'A lullaby in letter form',
    body: `It's late, and your mind won't quiet down. I know that feeling — the thoughts that circle like restless birds.

Here's what I want you to do: close your eyes and breathe. In for four counts. Hold for four. Out for four.

Now think of that day we did nothing — absolutely nothing — and it was perfect. Remember how the light looked? How safe everything felt?

That peace isn't gone. It's still yours. It's waiting for you, whenever you let yourself arrive.

The night isn't your enemy. It's just a very long pause between good days.

Sleep well. You've earned it.`,
  },
  {
    id: 3,
    label: 'Open when you achieved something big',
    icon: Trophy,
    gradient: 'from-amber-900/30 to-rose-900/20',
    subject: "I'm not surprised — not even a little",
    body: `You did it. And I'm not surprised, not even a little.

I've watched you work toward this when no one else was looking. The late nights, the doubts you pushed through, the times you wanted to quit and didn't. I saw all of it.

You deserve this moment. Not because of luck or timing — but because you earned every single piece of it with your own two hands.

So celebrate. Really celebrate. Don't downplay it, don't deflect, don't say "it's not a big deal." It IS a big deal. YOU are a big deal.

I'm so incredibly proud of you. And this is just the beginning.`,
  },
  {
    id: 4,
    label: 'Open when you miss me',
    icon: Heart,
    gradient: 'from-rose-900/30 to-pink-900/20',
    subject: 'I miss you too — always',
    body: `I miss you too.

But here's the thing about missing someone: it means you have something worth missing. And that's not sad — that's beautiful.

Close your eyes for a second. I'm there. In every memory we've made, in every inside joke, in every "you had to be there" moment. That version of us doesn't disappear just because we're apart.

And the distance? It's temporary. The connection isn't.

Think of it like this: we're just two stars in the same constellation, temporarily on different sides of the sky. But the constellation? It's still there. We're still part of the same picture.

I'll see you soon. Until then, know that you're in my thoughts — always.`,
  },
];

export function LettersScreen() {
  const [openedIds, setOpenedIds] = useLocalStorage<number[]>('gift_letters_opened', []);
  const [activeLetter, setActiveLetter] = useState<Letter | null>(null);
  const [isOpening, setIsOpening] = useState(false);

  const openLetter = useCallback((letter: Letter) => {
    sounds.envelope();
    setIsOpening(true);
    setActiveLetter(letter);
    if (!openedIds.includes(letter.id)) {
      setOpenedIds((prev) => [...prev, letter.id]);
    }
    setTimeout(() => setIsOpening(false), 700);
  }, [openedIds, setOpenedIds]);

  const closeLetter = useCallback(() => {
    sounds.softChime();
    setActiveLetter(null);
  }, []);

  return (
    <div className="screen-enter min-h-screen px-5 pt-14 pb-28">
      {/* Header */}
      <div className="mb-8 text-center">
        <div className="inline-flex items-center gap-2 mb-2">
          <Mail size={16} className="text-rose-gold/60" />
          <p className="text-xs uppercase tracking-[0.3em] text-rose-gold/50 font-body">
            For Specific Moments
          </p>
        </div>
        <h1 className="font-serif-display text-3xl text-white/95 glow-text">
          Open When...
        </h1>
        <p className="text-white/40 text-sm font-body mt-2 max-w-xs mx-auto">
          Tap an envelope to open it — read it when the moment is right
        </p>
      </div>

      {/* Envelope grid */}
      <div className="max-w-md mx-auto grid grid-cols-2 gap-4">
        {letters.map((letter) => {
          const Icon = letter.icon;
          const isOpened = openedIds.includes(letter.id);
          return (
            <button
              key={letter.id}
              onClick={() => openLetter(letter)}
              className="tap-bounce relative"
            >
              <div className={`glass-card rounded-2xl p-4 h-full flex flex-col items-center text-center justify-center bg-gradient-to-br ${letter.gradient}`} style={{ minHeight: '170px' }}>
                {/* Envelope SVG */}
                <div className="relative w-16 h-12 mb-3">
                  <svg viewBox="0 0 64 48" fill="none" className="w-full h-full">
                    {/* Envelope body */}
                    <rect x="2" y="8" width="60" height="38" rx="3" fill="rgba(255,255,255,0.06)" stroke="rgba(232,180,184,0.3)" strokeWidth="1.5" />
                    {/* Flap */}
                    <path d="M2 8 L32 28 L62 8" stroke="rgba(232,180,184,0.3)" strokeWidth="1.5" fill="rgba(255,255,255,0.03)" />
                    {/* Wax seal */}
                    {isOpened ? (
                      <circle cx="32" cy="30" r="6" fill="rgba(232,180,184,0.2)" stroke="rgba(232,180,184,0.3)" strokeWidth="1" strokeDasharray="2,2" />
                    ) : (
                      <circle cx="32" cy="22" r="6" fill="rgba(232,180,184,0.25)" stroke="rgba(232,180,184,0.5)" strokeWidth="1" />
                    )}
                    <text x="32" y="25" textAnchor="middle" fill="rgba(232,180,184,0.5)" fontSize="7" fontFamily="Outfit, sans-serif">
                      {isOpened ? '✓' : '♥'}
                    </text>
                  </svg>
                </div>
                <div className="w-8 h-8 rounded-full bg-white/8 flex items-center justify-center mb-2">
                  <Icon size={16} className="text-rose-gold-bright" />
                </div>
                <p className="text-white/70 text-[12px] font-body leading-snug px-1">
                  {letter.label}
                </p>
                {isOpened && (
                  <p className="text-rose-gold/40 text-[9px] font-body mt-2 uppercase tracking-wider">
                    Read
                  </p>
                )}
              </div>
            </button>
          );
        })}
      </div>

      {/* Letter Modal */}
      {activeLetter && (
        <div
          className="fixed inset-0 z-[90] flex items-center justify-center p-6"
          style={{ background: 'rgba(10,5,24,0.85)', backdropFilter: 'blur(8px)', animation: 'fade-in 0.3s ease forwards' }}
          onClick={closeLetter}
        >
          <div
            className={`relative max-w-md w-full ${isOpening ? '' : 'scale-in'}`}
            onClick={(e) => e.stopPropagation()}
            style={{ maxHeight: '85vh' }}
          >
            {/* Envelope flap animation */}
            <div className="relative overflow-hidden rounded-2xl glass-card-warm">
              {/* Close button */}
              <button
                onClick={closeLetter}
                className="tap-bounce absolute top-3 right-3 z-20 w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-white/50 hover:text-white/80 transition-colors"
              >
                <X size={16} />
              </button>

              {/* Flap */}
              <div
                className={`envelope-flap absolute top-0 left-0 right-0 z-10 ${isOpening ? 'open' : ''}`}
                style={{ height: '0', overflow: 'visible' }}
              >
                <svg viewBox="0 0 400 60" preserveAspectRatio="none" className="w-full h-12">
                  <polygon points="0,0 400,0 200,55" fill="rgba(232,180,184,0.12)" stroke="rgba(232,180,184,0.25)" strokeWidth="1" />
                </svg>
              </div>

              {/* Letter content */}
              <div
                className={`p-7 pt-10 ${isOpening ? 'letter-slide' : ''}`}
                style={{ maxHeight: '85vh', overflowY: 'auto' }}
              >
                <div className="text-center mb-5">
                  <p className="text-[10px] uppercase tracking-[0.3em] text-rose-gold/50 font-body mb-2">
                    A Letter For You
                  </p>
                  <h2 className="font-serif-display text-2xl text-white/95 leading-snug">
                    {activeLetter.subject}
                  </h2>
                </div>
                {/* Decorative divider */}
                <div className="flex items-center justify-center gap-2 mb-5">
                  <div className="h-px w-12 bg-gradient-to-r from-transparent to-rose-gold/30" />
                  <Heart size={10} className="text-rose-gold/40" fill="currentColor" />
                  <div className="h-px w-12 bg-gradient-to-l from-transparent to-rose-gold/30" />
                </div>
                <div className="text-white/70 text-[14px] font-body leading-relaxed whitespace-pre-line">
                  {activeLetter.body}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
