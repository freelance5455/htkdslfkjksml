import { useState } from 'react';
import { Sparkles, FlipHorizontal, Calendar } from 'lucide-react';
import { sounds } from '@/lib/audio';

interface Memory {
  id: number;
  date: string;
  icon: string;
  headline: string;
  caption: string;
  secret: string;
}

const memories: Memory[] = [
  {
    id: 1,
    date: 'The Beginning',
    icon: 'sparkles',
    headline: 'The Day We Met',
    caption: 'Neither of us knew that random Tuesday would change everything. You smiled, and the whole room got warmer.',
    secret: "I went home that night and told my diary I'd met someone special. I was right.",
  },
  {
    id: 2,
    date: 'First Adventure',
    icon: 'compass',
    headline: 'Getting Lost Together',
    caption: 'We took that wrong turn and ended up watching the sunset from a place neither of us had seen before.',
    secret: 'I pretended to be annoyed about the wrong turn. I was actually thrilled — it meant more time with you.',
  },
  {
    id: 3,
    date: 'Inside Joke #1',
    icon: 'smile',
    headline: 'The Coffee Shop Incident',
    caption: "You ordered the most ridiculous drink and then couldn't stop laughing. The barista still remembers us.",
    secret: 'That was the moment I realized your laugh was my favorite sound in the world.',
  },
  {
    id: 4,
    date: 'The Late Night',
    icon: 'moon',
    headline: '3 AM Conversations',
    caption: "We talked until the sun came up about everything and nothing. I've never felt so understood.",
    secret: "I set an alarm for 6 AM that night. I never turned it on. I didn't want to miss a second.",
  },
  {
    id: 5,
    date: 'Your Birthday',
    icon: 'cake',
    headline: "The Surprise That Wasn't",
    caption: "You figured it out three days early but pretended to be shocked anyway. That's love.",
    secret: "Your pretend-surprised face is genuinely the worst acting I've ever seen. And I adore it.",
  },
  {
    id: 6,
    date: 'The Rainy Day',
    icon: 'cloud',
    headline: 'Dancing in the Rain',
    caption: 'We got caught in a downpour and instead of running, you started dancing. So I joined you.',
    secret: "That was the day I knew — I want to dance with you in every storm, for as long as you'll have me.",
  },
];

function MemoryIcon({ icon, size = 28 }: { icon: string; size?: number }) {
  const iconMap: Record<string, string> = {
    sparkles: '✦',
    compass: '✧',
    smile: '☺',
    moon: '☾',
    cake: '❀',
    cloud: '☁',
  };
  return (
    <span
      className="text-rose-gold-bright"
      style={{ fontSize: size, filter: 'drop-shadow(0 0 8px rgba(232,180,184,0.4))' }}
    >
      {iconMap[icon] || '✦'}
    </span>
  );
}

export function TimelineScreen() {
  const [flipped, setFlipped] = useState<number | null>(null);

  const toggleFlip = (id: number) => {
    sounds.flip();
    setFlipped(flipped === id ? null : id);
  };

  return (
    <div className="screen-enter min-h-screen px-5 pt-14 pb-28">
      {/* Header */}
      <div className="mb-8 text-center">
        <div className="inline-flex items-center gap-2 mb-2">
          <Sparkles size={16} className="text-rose-gold/60" />
          <p className="text-xs uppercase tracking-[0.3em] text-rose-gold/50 font-body">
            Our Journey
          </p>
          <Sparkles size={16} className="text-rose-gold/60" />
        </div>
        <h1 className="font-serif-display text-3xl text-white/95 glow-text">
          Memory Timeline
        </h1>
        <p className="text-white/40 text-sm font-body mt-2 max-w-xs mx-auto">
          Tap any card to reveal a secret thought
        </p>
      </div>

      {/* Timeline */}
      <div className="relative max-w-md mx-auto">
        {/* Vertical line */}
        <div className="absolute left-6 top-0 bottom-0 w-px bg-gradient-to-b from-transparent via-rose-gold/30 to-transparent" />

        <div className="space-y-6">
          {memories.map((memory) => (
            <div key={memory.id} className="relative pl-16">
              {/* Timeline dot */}
              <div className="absolute left-3.5 top-6 w-6 h-6 rounded-full glass-card-warm flex items-center justify-center z-10">
                <div className="w-2 h-2 rounded-full bg-rose-gold-bright" style={{ boxShadow: '0 0 8px rgba(232,180,184,0.6)' }} />
              </div>

              {/* Flip card */}
              <div
                className={`flip-card ${flipped === memory.id ? 'flipped' : ''}`}
                style={{ minHeight: '180px' }}
              >
                <button
                  onClick={() => toggleFlip(memory.id)}
                  className="flip-card-inner w-full text-left"
                  style={{ minHeight: '180px' }}
                >
                  {/* Front */}
                  <div className="flip-card-front glass-card rounded-2xl p-5 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between mb-3">
                        <span className="inline-flex items-center gap-1.5 text-[10px] uppercase tracking-wider text-rose-gold/60 font-body bg-rose-gold/8 px-2.5 py-1 rounded-full">
                          <Calendar size={10} />
                          {memory.date}
                        </span>
                        <MemoryIcon icon={memory.icon} size={22} />
                      </div>
                      <h3 className="font-serif-display text-xl text-white/95 mb-2">
                        {memory.headline}
                      </h3>
                      <p className="text-white/55 text-[13px] font-body leading-relaxed line-clamp-3">
                        {memory.caption}
                      </p>
                    </div>
                    <div className="flex items-center gap-1.5 mt-3 text-rose-gold/40 text-[11px] font-body">
                      <FlipHorizontal size={12} />
                      Tap to reveal secret thought
                    </div>
                  </div>

                  {/* Back */}
                  <div className="flip-card-back glass-card-warm rounded-2xl p-5 flex flex-col justify-between">
                    <div>
                      <p className="text-[10px] uppercase tracking-wider text-rose-gold/50 font-body mb-3">
                        Secret Thought
                      </p>
                      <p className="font-serif-display italic text-lg text-white/90 leading-relaxed">
                        "{memory.secret}"
                      </p>
                    </div>
                    <div className="flex items-center gap-1.5 mt-3 text-rose-gold/40 text-[11px] font-body">
                      <FlipHorizontal size={12} />
                      Tap to flip back
                    </div>
                  </div>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      <p className="text-center text-white/25 text-xs font-body mt-10 italic">
        More memories yet to be made...
      </p>
    </div>
  );
}
