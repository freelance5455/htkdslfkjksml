import { useMemo } from 'react';
import { TrendingUp, TrendingDown, Wallet, Users, Plus, ArrowRight, AlertTriangle } from 'lucide-react';
import { useStore, totalOutstanding } from '@/lib/store';
import { formatPKR, todayISO, isSameDay, formatDate } from '@/lib/format';
import { StatCard } from '@/components/UI';
import { DataSettingsButton } from '@/components/DataSettings';
import type { Screen } from '@/types';

export function Dashboard({ onNavigate, onQuickAdd }: { onNavigate: (s: Screen) => void; onQuickAdd: (s: Screen) => void }) {
  const { transactions, credits, customers, products } = useStore();
  const today = todayISO();

  const stats = useMemo(() => {
    const todaySales = transactions.filter((t) => t.type === 'sale' && isSameDay(t.date, today)).reduce((s, t) => s + t.amount, 0);
    const todayExpenses = transactions.filter((t) => t.type === 'expense' && isSameDay(t.date, today)).reduce((s, t) => s + t.amount, 0);
    const profit = todaySales - todayExpenses;
    const outstanding = totalOutstanding(credits);
    return { todaySales, todayExpenses, profit, outstanding };
  }, [transactions, credits, today]);

  const lowStock = products.filter((p) => p.quantity <= p.lowStockThreshold);
  const recentTxns = transactions.slice(0, 5);

  return (
    <div className="px-4 pt-4 pb-4">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div>
          <p className="text-sm text-slate-500">Assalam-o-Alaikum</p>
          <h1 className="text-2xl font-extrabold text-slate-800">Dukaan Saathi</h1>
        </div>
        <DataSettingsButton />
      </div>

      {/* Today summary */}
      <div className="bg-gradient-to-br from-emerald-600 to-teal-700 rounded-2xl p-5 text-white shadow-lg shadow-emerald-600/20 mb-4">
        <p className="text-emerald-100 text-sm font-medium">Aaj ka hisab</p>
        <p className="text-3xl font-extrabold mt-1">{formatPKR(stats.todaySales)}</p>
        <div className="flex items-center gap-2 mt-2 text-emerald-100 text-sm">
          <TrendingUp size={15} />
          <span>Today's sales</span>
        </div>
        <div className="mt-4 pt-4 border-t border-white/20 grid grid-cols-2 gap-4">
          <div>
            <p className="text-emerald-100 text-xs">Aaj ka profit (approx)</p>
            <p className="text-lg font-bold">{formatPKR(stats.profit)}</p>
          </div>
          <div>
            <p className="text-emerald-100 text-xs">Aaj ka kharcha</p>
            <p className="text-lg font-bold">{formatPKR(stats.todayExpenses)}</p>
          </div>
        </div>
      </div>

      {/* Quick actions */}
      <div className="grid grid-cols-3 gap-3 mb-5">
        <QuickAction icon={TrendingUp} label="Sale" tone="emerald" onClick={() => onQuickAdd('sales')} />
        <QuickAction icon={TrendingDown} label="Kharcha" tone="red" onClick={() => onQuickAdd('sales')} />
        <QuickAction icon={Users} label="Udhaar" tone="amber" onClick={() => onQuickAdd('udhaar')} />
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 gap-3 mb-5">
        <StatCard label="Aaj ki Sale" value={formatPKR(stats.todaySales)} icon={TrendingUp} tone="emerald" />
        <StatCard label="Aaj ka Kharcha" value={formatPKR(stats.todayExpenses)} icon={TrendingDown} tone="red" />
        <StatCard label="Est. Profit" value={formatPKR(stats.profit)} icon={Wallet} tone="blue" sub="Sales - Expenses" />
        <StatCard label="Baqaya Udhaar" value={formatPKR(stats.outstanding)} icon={Users} tone="amber" sub={`${customers.length} customers`} />
      </div>

      {/* Low stock alert */}
      {lowStock.length > 0 && (
        <div className="mb-5 bg-red-50 border border-red-200 rounded-2xl p-4">
          <div className="flex items-center gap-2 text-red-700 font-semibold text-sm mb-2">
            <AlertTriangle size={16} />
            Stock kam hai ({lowStock.length})
          </div>
          <div className="space-y-1.5">
            {lowStock.slice(0, 3).map((p) => (
              <div key={p.id} className="flex justify-between text-sm">
                <span className="text-red-700 truncate">{p.name}</span>
                <span className="text-red-500 font-semibold">{p.quantity} left</span>
              </div>
            ))}
          </div>
          <button onClick={() => onNavigate('stock')} className="text-red-600 text-xs font-semibold mt-2 flex items-center gap-1">
            Stock manage karein <ArrowRight size={12} />
          </button>
        </div>
      )}

      {/* Recent transactions */}
      <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 border-b border-slate-100">
          <h2 className="font-bold text-slate-800 text-sm">Recent Hisab</h2>
          <button onClick={() => onNavigate('sales')} className="text-emerald-600 text-xs font-semibold flex items-center gap-1">
            Sab dekhein <ArrowRight size={12} />
          </button>
        </div>
        {recentTxns.length === 0 ? (
          <p className="px-4 py-8 text-center text-sm text-slate-400">Abhi koi transaction nahi</p>
        ) : (
          <div className="divide-y divide-slate-50">
            {recentTxns.map((t) => (
              <div key={t.id} className="flex items-center justify-between px-4 py-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${t.type === 'sale' ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600'}`}>
                    {t.type === 'sale' ? <TrendingUp size={16} /> : <TrendingDown size={16} />}
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-slate-700 truncate">{t.note || (t.type === 'sale' ? 'Sale' : 'Kharcha')}</p>
                    <p className="text-xs text-slate-400">{formatDate(t.date)}</p>
                  </div>
                </div>
                <p className={`text-sm font-bold ${t.type === 'sale' ? 'text-emerald-600' : 'text-red-600'}`}>
                  {t.type === 'sale' ? '+' : '-'}{formatPKR(t.amount)}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* FAB */}
      <button
        onClick={() => onQuickAdd('sales')}
        className="fixed right-5 bottom-20 z-20 w-14 h-14 rounded-full bg-emerald-600 text-white shadow-lg shadow-emerald-600/30 flex items-center justify-center active:scale-95 transition-transform"
        aria-label="Add sale"
      >
        <Plus size={26} />
      </button>
    </div>
  );
}

function QuickAction({ icon: Icon, label, tone, onClick }: { icon: typeof Plus; label: string; tone: 'emerald' | 'red' | 'amber'; onClick: () => void }) {
  const tones = {
    emerald: 'bg-emerald-50 text-emerald-600',
    red: 'bg-red-50 text-red-600',
    amber: 'bg-amber-50 text-amber-600',
  };
  return (
    <button onClick={onClick} className="flex flex-col items-center gap-2 py-3.5 bg-white rounded-2xl border border-slate-100 shadow-sm active:scale-95 transition-transform">
      <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${tones[tone]}`}>
        <Icon size={20} />
      </div>
      <span className="text-xs font-semibold text-slate-600">{label}</span>
    </button>
  );
}
