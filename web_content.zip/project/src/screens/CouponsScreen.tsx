import { useCallback, useEffect, useRef, useState } from 'react';
import { Gift, Coffee, Film, Heart, KeyRound, RotateCcw } from 'lucide-react';
import { sounds } from '@/lib/audio';
import { useLocalStorage } from '@/lib/useLocalStorage';

interface Coupon {
  id: number;
  icon: typeof Gift;
  gradient: string;
  title: string;
  revealedText: string;
  description: string;
}

const coupons: Coupon[] = [
  {
    id: 1,
    icon: Coffee,
    gradient: 'from-amber-700/30 to-rose-900/20',
    title: 'Scratch to Reveal',
    revealedText: '1 Free Coffee Date',
    description: 'Redeem anytime. I bring the coffee, you bring the conversation.',
  },
  {
    id: 2,
    icon: KeyRound,
    gradient: 'from-violet-700/30 to-indigo-900/20',
    title: 'Scratch to Reveal',
    revealedText: 'Midnight Rant Pass',
    description: 'Unlimited late-night venting session. I promise to listen — not fix.',
  },
  {
    id: 3,
    icon: Film,
    gradient: 'from-rose-700/30 to-purple-900/20',
    title: 'Scratch to Reveal',
    revealedText: 'Movie Marathon of Your Choice',
    description: 'You pick every movie. I bring the snacks. No complaints allowed.',
  },
  {
    id: 4,
    icon: Heart,
    gradient: 'from-pink-700/30 to-rose-900/20',
    title: 'Scratch to Reveal',
    revealedText: 'A Secret Truth',
    description: "There's something I never told you. Now you get to know.",
  },
];

interface ScratchCardProps {
  coupon: Coupon;
  revealed: boolean;
  onReveal: (id: number) => void;
}

function ScratchCard({ coupon, revealed, onReveal }: ScratchCardProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const ctxRef = useRef<CanvasRenderingContext2D | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [scratchProgress, setScratchProgress] = useState(0);
  const lastSoundRef = useRef(0);
  const revealedRef = useRef(revealed);

  useEffect(() => {
    revealedRef.current = revealed;
  }, [revealed]);

  const initCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const parent = canvas.parentElement;
    if (!parent) return;

    const rect = parent.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    canvas.style.width = `${rect.width}px`;
    canvas.style.height = `${rect.height}px`;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.scale(dpr, dpr);
    ctxRef.current = ctx;

    // Draw scratch overlay
    const gradient = ctx.createLinearGradient(0, 0, rect.width, rect.height);
    gradient.addColorStop(0, '#6d28d9');
    gradient.addColorStop(0.5, '#9333ea');
    gradient.addColorStop(1, '#4c1d95');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, rect.width, rect.height);

    // Add shimmer pattern
    ctx.fillStyle = 'rgba(255,255,255,0.05)';
    for (let i = 0; i < 20; i++) {
      ctx.beginPath();
      ctx.arc(
        Math.random() * rect.width,
        Math.random() * rect.height,
        Math.random() * 30,
        0,
        Math.PI * 2
      );
      ctx.fill();
    }

    // Add "SCRATCH ME" text
    ctx.fillStyle = 'rgba(255,255,255,0.4)';
    ctx.font = '500 14px Outfit, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('Scratch Me!', rect.width / 2, rect.height / 2);
    ctx.font = '400 11px Outfit, sans-serif';
    ctx.fillStyle = 'rgba(255,255,255,0.25)';
    ctx.fillText('Drag your finger across', rect.width / 2, rect.height / 2 + 20);

    ctx.globalCompositeOperation = 'destination-out';
  }, []);

  useEffect(() => {
    if (revealed) return; // Don't init canvas if already revealed
    initCanvas();
  }, [initCanvas, revealed]);

  const getPercentage = useCallback(() => {
    const canvas = canvasRef.current;
    const ctx = ctxRef.current;
    if (!canvas || !ctx) return 0;
    try {
      const dpr = window.devicePixelRatio || 1;
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      let transparent = 0;
      const step = 40;
      for (let i = 3; i < imageData.data.length; i += step * 4) {
        if (imageData.data[i] === 0) transparent++;
      }
      const total = imageData.data.length / (step * 4);
      return transparent / total;
    } catch {
      return 0;
    }
  }, []);

  const scratch = useCallback(
    (clientX: number, clientY: number) => {
      const canvas = canvasRef.current;
      const ctx = ctxRef.current;
      if (!canvas || !ctx) return;

      const rect = canvas.getBoundingClientRect();
      const x = clientX - rect.left;
      const y = clientY - rect.top;

      ctx.beginPath();
      ctx.arc(x, y, 22, 0, Math.PI * 2);
      ctx.fill();

      // Throttled scratch sound
      const now = Date.now();
      if (now - lastSoundRef.current > 80) {
        lastSoundRef.current = now;
        sounds.scratch();
      }

      const pct = getPercentage();
      setScratchProgress(pct);

      if (pct > 0.45 && !revealedRef.current) {
        // Auto-reveal
        ctx.globalCompositeOperation = 'source-over';
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        sounds.reveal();
        onReveal(coupon.id);
      }
    },
    [coupon.id, getPercentage, onReveal]
  );

  const handlePointerDown = (e: React.PointerEvent) => {
    if (revealed) return;
    e.preventDefault();
    setIsDrawing(true);
    scratch(e.clientX, e.clientY);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDrawing || revealed) return;
    e.preventDefault();
    scratch(e.clientX, e.clientY);
  };

  const handlePointerUp = () => setIsDrawing(false);

  const Icon = coupon.icon;

  return (
    <div
      className={`relative rounded-2xl overflow-hidden bg-gradient-to-br ${coupon.gradient} border border-white/10`}
      style={{ minHeight: '140px' }}
    >
      {/* Revealed content */}
      <div className="p-5 flex flex-col h-full justify-between" style={{ minHeight: '140px' }}>
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center">
            <Icon size={20} className="text-rose-gold-bright" />
          </div>
          <div>
            <p className="text-[10px] uppercase tracking-wider text-rose-gold/50 font-body">Coupon Revealed</p>
            <h3 className="font-serif-display text-lg text-white/95">
              {coupon.revealedText}
            </h3>
          </div>
        </div>
        <p className="text-white/55 text-[12px] font-body leading-relaxed">
          {coupon.description}
        </p>
      </div>

      {/* Scratch overlay canvas */}
      {!revealed && (
        <canvas
          ref={canvasRef}
          className="scratch-canvas"
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerLeave={handlePointerUp}
        />
      )}

      {/* Progress hint */}
      {!revealed && scratchProgress > 0 && scratchProgress < 0.45 && (
        <div className="absolute bottom-2 right-3 text-[10px] text-white/30 font-body pointer-events-none">
          {Math.round(scratchProgress * 100)}%
        </div>
      )}

      {/* Revealed badge */}
      {revealed && (
        <div className="absolute top-3 right-3 flex items-center gap-1 text-rose-gold/50 text-[10px] font-body">
          <Heart size={10} fill="currentColor" />
          Redeemable
        </div>
      )}
    </div>
  );
}

export function CouponsScreen() {
  const [revealedIds, setRevealedIds] = useLocalStorage<number[]>('gift_coupons_revealed', []);

  const handleReveal = useCallback(
    (id: number) => {
      if (!revealedIds.includes(id)) {
        setRevealedIds((prev) => [...prev, id]);
      }
    },
    [revealedIds, setRevealedIds]
  );

  const handleReset = () => {
    sounds.tap();
    setRevealedIds([]);
  };

  const allRevealed = revealedIds.length === coupons.length;

  return (
    <div className="screen-enter min-h-screen px-5 pt-14 pb-28">
      {/* Header */}
      <div className="mb-8 text-center">
        <div className="inline-flex items-center gap-2 mb-2">
          <Gift size={16} className="text-rose-gold/60" />
          <p className="text-xs uppercase tracking-[0.3em] text-rose-gold/50 font-body">
            Interactive Surprises
          </p>
        </div>
        <h1 className="font-serif-display text-3xl text-white/95 glow-text">
          Scratch & Reveal
        </h1>
        <p className="text-white/40 text-sm font-body mt-2 max-w-xs mx-auto">
          Drag your finger across each card to uncover your surprise coupons
        </p>
      </div>

      {/* Coupons */}
      <div className="max-w-md mx-auto space-y-5">
        {coupons.map((coupon) => (
          <ScratchCard
            key={coupon.id}
            coupon={coupon}
            revealed={revealedIds.includes(coupon.id)}
            onReveal={handleReveal}
          />
        ))}
      </div>

      {/* Reset button */}
      {revealedIds.length > 0 && (
        <div className="max-w-md mx-auto mt-8">
          <button
            onClick={handleReset}
            className="tap-bounce w-full py-3 rounded-xl glass-card text-white/50 text-sm font-body flex items-center justify-center gap-2 hover:text-white/70 transition-colors"
          >
            <RotateCcw size={14} />
            Reset all coupons
          </button>
        </div>
      )}

      {allRevealed && (
        <p className="text-center text-rose-gold/40 text-xs font-body mt-6 italic">
          All coupons unlocked! Redeem them whenever you're ready.
        </p>
      )}
    </div>
  );
}
