import { useMemo, useState } from 'react';
import { Receipt, Plus, TrendingUp, TrendingDown, Pencil, Trash2 } from 'lucide-react';
import { useStore, type NewTransactionInput } from '@/lib/store';
import { formatPKR, formatDate, todayISO, isSameDay } from '@/lib/format';
import { Button, IconButton } from '@/components/Button';
import { Modal } from '@/components/Modal';
import { ConfirmDialog } from '@/components/ConfirmDialog';
import { SearchBar, AmountInput, TextField, DateField, validateAmount } from '@/components/Form';
import { EmptyState } from '@/components/UI';
import { StatCard } from '@/components/UI';
import type { Transaction, TxnType } from '@/types';

type Filter = 'all' | 'sale' | 'expense';

export function SalesScreen() {
  const { transactions, addTransaction, updateTransaction, deleteTransaction } = useStore();
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState<Filter>('all');
  const [addOpen, setAddOpen] = useState(false);
  const [editTxn, setEditTxn] = useState<Transaction | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const today = todayISO();

  const todaySales = transactions.filter((t) => t.type === 'sale' && isSameDay(t.date, today)).reduce((s, t) => s + t.amount, 0);
  const todayExpenses = transactions.filter((t) => t.type === 'expense' && isSameDay(t.date, today)).reduce((s, t) => s + t.amount, 0);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return transactions
      .filter((t) => (filter === 'all' ? true : t.type === filter))
      .filter((t) => (!q ? true : (t.note ?? '').toLowerCase().includes(q) || formatPKR(t.amount).toLowerCase().includes(q)))
      .sort((a, b) => b.createdAt - a.createdAt);
  }, [transactions, filter, query]);

  return (
    <div className="px-4 pt-4 pb-4">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-800">Hisab</h1>
          <p className="text-sm text-slate-500">Sales & Kharcha</p>
        </div>
        <Button size="sm" onClick={() => setAddOpen(true)}>
          <Plus size={16} /> Add
        </Button>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-4">
        <StatCard label="Aaj ki Sale" value={formatPKR(todaySales)} icon={TrendingUp} tone="emerald" />
        <StatCard label="Aaj ka Kharcha" value={formatPKR(todayExpenses)} icon={TrendingDown} tone="red" />
      </div>

      <div className="mb-3">
        <SearchBar value={query} onChange={setQuery} placeholder="Note ya raqam search..." />
      </div>

      <div className="flex gap-2 mb-4">
        {(['all', 'sale', 'expense'] as Filter[]).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-4 py-2 rounded-lg text-sm font-semibold transition-colors ${
              filter === f ? 'bg-slate-800 text-white' : 'bg-white text-slate-500 border border-slate-200'
            }`}
          >
            {f === 'all' ? 'Sab' : f === 'sale' ? 'Sales' : 'Kharcha'}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <EmptyState icon={Receipt} title="Koi transaction nahi" hint="Naya sale ya kharcha add karein" />
      ) : (
        <div className="space-y-2">
          {filtered.map((t) => (
            <div key={t.id} className="bg-white rounded-xl border border-slate-100 shadow-sm p-3.5 flex items-center gap-3">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${t.type === 'sale' ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600'}`}>
                {t.type === 'sale' ? <TrendingUp size={18} /> : <TrendingDown size={18} />}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-slate-700 truncate">{t.note || (t.type === 'sale' ? 'Sale' : 'Kharcha')}</p>
                <p className="text-xs text-slate-400">{formatDate(t.date)}</p>
              </div>
              <p className={`text-sm font-bold shrink-0 ${t.type === 'sale' ? 'text-emerald-600' : 'text-red-600'}`}>
                {t.type === 'sale' ? '+' : '-'}{formatPKR(t.amount)}
              </p>
              <div className="flex shrink-0">
                <IconButton onClick={() => setEditTxn(t)} className="!p-1.5 text-slate-300 hover:text-slate-600">
                  <Pencil size={14} />
                </IconButton>
                <IconButton onClick={() => setDeleteId(t.id)} className="!p-1.5 text-slate-300 hover:text-red-500">
                  <Trash2 size={14} />
                </IconButton>
              </div>
            </div>
          ))}
        </div>
      )}

      <TransactionModal
        open={addOpen}
        onClose={() => setAddOpen(false)}
        onSave={(input) => {
          addTransaction(input);
          setAddOpen(false);
        }}
      />

      {editTxn && (
        <TransactionModal
          open={!!editTxn}
          initial={editTxn}
          onClose={() => setEditTxn(null)}
          onSave={(input) => {
            updateTransaction(editTxn.id, input);
            setEditTxn(null);
          }}
        />
      )}

      <ConfirmDialog
        open={!!deleteId}
        title="Transaction delete?"
        message="Yeh entry delete ho jayegi. Totals automatically update honge. Continue?"
        confirmLabel="Delete"
        onConfirm={() => {
          if (deleteId) deleteTransaction(deleteId);
          setDeleteId(null);
        }}
        onCancel={() => setDeleteId(null)}
      />
    </div>
  );
}

function TransactionModal({
  open,
  onClose,
  onSave,
  initial,
}: {
  open: boolean;
  onClose: () => void;
  onSave: (input: NewTransactionInput) => void;
  initial?: Transaction;
}) {
  const [type, setType] = useState<TxnType>(initial?.type ?? 'sale');
  const [amount, setAmount] = useState(initial ? String(initial.amount) : '');
  const [date, setDate] = useState(initial?.date ?? todayISO());
  const [note, setNote] = useState(initial?.note ?? '');
  const [err, setErr] = useState('');

  const [openTracker, setOpenTracker] = useState(false);
  if (open !== openTracker) {
    setOpenTracker(open);
    if (open) {
      setType(initial?.type ?? 'sale');
      setAmount(initial ? String(initial.amount) : '');
      setDate(initial?.date ?? todayISO());
      setNote(initial?.note ?? '');
      setErr('');
    }
  }

  const submit = () => {
    const n = validateAmount(amount);
    if (n === null) {
      setErr('Sahi raqam likhein (0 se zyada)');
      return;
    }
    onSave({ type, amount: n, date, note });
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={initial ? 'Transaction Edit' : 'Naya Transaction'}
      footer={
        <div className="flex gap-3">
          <Button variant="secondary" block onClick={onClose}>
            Cancel
          </Button>
          <Button block onClick={submit}>
            Save
          </Button>
        </div>
      }
    >
      <div className="space-y-4">
        {err && <p className="text-sm text-red-600 bg-red-50 rounded-lg px-3 py-2">{err}</p>}

        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => setType('sale')}
            className={`py-3 rounded-xl font-semibold flex items-center justify-center gap-2 transition-colors ${
              type === 'sale' ? 'bg-emerald-600 text-white' : 'bg-emerald-50 text-emerald-600'
            }`}
          >
            <TrendingUp size={18} /> Sale
          </button>
          <button
            onClick={() => setType('expense')}
            className={`py-3 rounded-xl font-semibold flex items-center justify-center gap-2 transition-colors ${
              type === 'expense' ? 'bg-red-600 text-white' : 'bg-red-50 text-red-600'
            }`}
          >
            <TrendingDown size={18} /> Kharcha
          </button>
        </div>

        <AmountInput value={amount} onChange={(v) => { setAmount(v); setErr(''); }} autoFocus label="Raqam (Amount)" />
        <DateField value={date} onChange={setDate} />
        <TextField value={note} onChange={setNote} label="Note (optional)" placeholder="Item, detail ya remark" multiline />
      </div>
    </Modal>
  );
}
