import { useEffect, useState, type ReactElement } from 'react';
import { LogOut, ShieldAlert } from 'lucide-react';
import { AuthProvider, useAuth } from '@/hooks/useAuth';
import { AppShell, NAV_ITEMS, type StudioRoute } from '@/components/AppShell';
import { Alert, Button, Spinner } from '@/components/ui';
import { LoginPage } from '@/pages/LoginPage';
import { DashboardPage } from '@/pages/DashboardPage';
import { AppsPage } from '@/pages/AppsPage';
import { OptimizationsPage } from '@/pages/OptimizationsPage';
import { KeysPage } from '@/pages/KeysPage';
import { PlansPage } from '@/pages/PlansPage';
import { PaymentsPage } from '@/pages/PaymentsPage';
import { ClientsPage } from '@/pages/ClientsPage';
import { CustomizationPage } from '@/pages/CustomizationPage';
import { SettingsPage } from '@/pages/SettingsPage';

const ROUTES = NAV_ITEMS.map((item) => item.route);

function routeFromHash(): StudioRoute {
  const value = window.location.hash.replace(/^#\/?/, '') as StudioRoute;
  return ROUTES.includes(value) ? value : 'dashboard';
}

function useStudioRoute(): StudioRoute {
  const [route, setRoute] = useState<StudioRoute>(routeFromHash);
  useEffect(() => {
    const handle = () => setRoute(routeFromHash());
    window.addEventListener('hashchange', handle);
    return () => window.removeEventListener('hashchange', handle);
  }, []);
  return route;
}

const PAGE_TITLES: Record<StudioRoute, string> = Object.fromEntries(NAV_ITEMS.map((item) => [item.route, item.label])) as Record<StudioRoute, string>;

const PAGES: Record<StudioRoute, () => ReactElement> = {
  dashboard: DashboardPage,
  apps: AppsPage,
  optimizations: OptimizationsPage,
  keys: KeysPage,
  plans: PlansPage,
  payments: PaymentsPage,
  clients: ClientsPage,
  customization: CustomizationPage,
  settings: SettingsPage,
};

function AccessGate() {
  const { session, checking, isAdmin, accessError, signOut } = useAuth();
  const route = useStudioRoute();
  const [signingOut, setSigningOut] = useState(false);
  const [signOutError, setSignOutError] = useState<string | null>(null);

  if (checking) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-ink">
        <Spinner label="Verificando acesso" />
      </div>
    );
  }

  if (!session) return <LoginPage />;

  if (accessError || !isAdmin) {
    const handleSignOut = async () => {
      setSigningOut(true);
      setSignOutError(null);
      try {
        await signOut();
      } catch (caught) {
        setSignOutError(caught instanceof Error ? caught.message : 'Não foi possível sair. Tente novamente.');
        setSigningOut(false);
      }
    };
    return (
      <div className="flex min-h-screen items-center justify-center bg-ink px-4">
        <div className="animate-fade-up surface w-full max-w-md space-y-6 p-8 text-center">
          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-graphite-700 ring-1 ring-graphite-600">
            <ShieldAlert className="h-6 w-6 text-crimson-300" aria-hidden="true" />
          </div>
          <div className="space-y-2">
            <h1 className="font-display text-xl font-semibold text-graphite-50">Acesso não autorizado</h1>
            <p className="text-sm text-graphite-300">
              {accessError ?? 'Esta conta não tem permissão de administrador no VT STUDIO. Entre com outra conta ou solicite acesso ao responsável.'}
            </p>
          </div>
          {signOutError ? <Alert>{signOutError}</Alert> : null}
          <Button variant="secondary" icon={LogOut} onClick={handleSignOut} loading={signingOut} className="w-full">
            Sair
          </Button>
        </div>
      </div>
    );
  }

  const Page = PAGES[route];
  return (
    <AppShell current={route} title={PAGE_TITLES[route]}>
      <Page />
    </AppShell>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AccessGate />
    </AuthProvider>
  );
}
