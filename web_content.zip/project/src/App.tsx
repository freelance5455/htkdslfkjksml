import { useCallback, useEffect, useState } from 'react';
import { Volume2, VolumeX } from 'lucide-react';
import { Particles } from '@/components/Particles';
import { BottomNav, type ScreenId } from '@/components/BottomNav';
import { VaultScreen } from '@/screens/VaultScreen';
import { TimelineScreen } from '@/screens/TimelineScreen';
import { CouponsScreen } from '@/screens/CouponsScreen';
import { JarScreen } from '@/screens/JarScreen';
import { LettersScreen } from '@/screens/LettersScreen';
import { useLocalStorage } from '@/lib/useLocalStorage';
import { sounds, initAudio, setMuted as setAudioMuted } from '@/lib/audio';

export default function App() {
  const [unlocked, setUnlocked] = useLocalStorage<boolean>('gift_unlocked', false);
  const [activeScreen, setActiveScreen] = useState<ScreenId>('vault');
  const [muted, setMuted] = useLocalStorage<boolean>('gift_muted', false);
  const [transitionKey, setTransitionKey] = useState(0);

  const handleUnlock = useCallback(() => {
    setUnlocked(true);
    setActiveScreen('timeline');
    setTransitionKey((k) => k + 1);
  }, [setUnlocked]);

  const handleScreenChange = useCallback((screen: ScreenId) => {
    setActiveScreen(screen);
    setTransitionKey((k) => k + 1);
  }, []);

  const toggleMute = useCallback(() => {
    setMuted((prev) => {
      const next = !prev;
      setAudioMuted(next);
      if (!next) {
        initAudio();
        sounds.chime();
      }
      return next;
    });
  }, [setMuted]);

  useEffect(() => {
    setAudioMuted(muted);
  }, [muted]);

  const showNav = unlocked && activeScreen !== 'vault';

  const renderScreen = () => {
    if (!unlocked || activeScreen === 'vault') {
      // If unlocked but navigated back to vault, show a re-lock screen
      if (unlocked && activeScreen === 'vault') {
        return <VaultRevisited onEnter={handleScreenChange} />;
      }
      return <VaultScreen onUnlocked={handleUnlock} />;
    }

    switch (activeScreen) {
      case 'timeline':
        return <TimelineScreen />;
      case 'coupons':
        return <CouponsScreen />;
      case 'jar':
        return <JarScreen />;
      case 'letters':
        return <LettersScreen />;
      default:
        return <TimelineScreen />;
    }
  };

  return (
    <div className="relative min-h-screen overflow-x-hidden">
      <Particles count={30} />

      {/* Mute toggle */}
      {unlocked && (
        <button
          onClick={toggleMute}
          className="tap-bounce fixed top-4 right-4 z-50 w-10 h-10 rounded-full glass-card flex items-center justify-center text-white/50 hover:text-white/80 transition-colors"
          aria-label={muted ? 'Unmute sounds' : 'Mute sounds'}
        >
          {muted ? <VolumeX size={18} /> : <Volume2 size={18} />}
        </button>
      )}

      {/* Screen content */}
      <div key={transitionKey} className={transitionKey > 0 ? 'screen-enter' : ''}>
        {renderScreen()}
      </div>

      {/* Bottom navigation */}
      {showNav && <BottomNav active={activeScreen} onChange={handleScreenChange} />}
    </div>
  );
}

// Small component for revisiting the vault after unlocking
function VaultRevisited({ onEnter }: { onEnter: (screen: ScreenId) => void }) {
  return (
    <div className="screen-enter min-h-screen flex flex-col items-center justify-center px-6 pb-28">
      <div className="glass-card-warm rounded-3xl p-8 max-w-md w-full text-center">
        <div className="w-16 h-16 rounded-full bg-rose-gold/15 flex items-center justify-center mx-auto mb-5">
          <Volume2 size={28} className="text-rose-gold-bright" />
        </div>
        <h2 className="font-serif-display text-2xl text-white/95 mb-3">
          Welcome back
        </h2>
        <p className="text-white/60 text-sm font-body mb-6">
          Your gift is still here. Where would you like to go?
        </p>
        <button
          onClick={() => { sounds.chime(); onEnter('timeline'); }}
          className="tap-bounce w-full py-3.5 rounded-2xl bg-gradient-to-r from-rose-gold/20 to-gold/20 border border-rose-gold/30 text-rose-gold-bright font-body font-medium text-sm"
        >
          Continue to Memories
        </button>
      </div>
    </div>
  );
}
