import { useState, useRef, useEffect, useCallback } from 'react';
import { CharacterSelect } from '@/components/CharacterSelect';
import { HUD } from '@/components/HUD';
import { PhoneMenu } from '@/components/PhoneMenu';
import { TouchJoystick, ActionButton, HoldButton, CameraSwipeArea } from '@/components/TouchControls';
import { GameEngine, GameHudState } from '@/game/engine';

export default function App() {
  const [started, setStarted] = useState(false);
  const [phoneOpen, setPhoneOpen] = useState(false);
  const [hud, setHud] = useState<GameHudState | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<GameEngine | null>(null);

  useEffect(() => {
    if (!started || !containerRef.current) return;

    const engine = new GameEngine(containerRef.current);
    engineRef.current = engine;
    engine.setHudCallback((state) => setHud(state));
    engine.onPhoneToggle = () => setPhoneOpen(prev => !prev);
    engine.start();

    return () => {
      engine.stop();
      engineRef.current = null;
    };
  }, [started]);

  const handleCharacterSelect = useCallback((character: string) => {
    if (engineRef.current) {
      engineRef.current.switchCharacter(character);
    }
    setStarted(true);
  }, []);

  const handleSwitchCharacter = useCallback((key: string) => {
    engineRef.current?.switchCharacter(key);
  }, []);

  const handleWorkShift = useCallback(() => {
    engineRef.current?.startWorkShift();
    setPhoneOpen(false);
  }, []);

  const handleBuyFood = useCallback(() => {
    engineRef.current?.buyFood();
  }, []);

  const input = engineRef.current?.getInputManager();

  return (
    <div className="fixed inset-0 overflow-hidden bg-black" style={{ touchAction: 'none' }}>
      {/* 3D canvas container */}
      <div ref={containerRef} className="absolute inset-0" />

      {started && hud && (
        <>
          <HUD state={hud} />

          {/* Phone button (fixed) */}
          <button
            onClick={() => setPhoneOpen(true)}
            className="fixed z-30 px-4 py-2 rounded-xl text-white text-sm backdrop-blur-md transition-all hover:scale-105 active:scale-95"
            style={{ background: 'rgba(0,0,0,0.5)', border: '1px solid rgba(255,255,255,0.1)', top: '60px', left: '50%', transform: 'translateX(-50%)' }}
          >
            📱 الهاتف
          </button>

          {/* Touch Controls - shown on all devices for mobile */}
          <div className="md:hidden">
            {/* Camera swipe area (left half of screen) */}
            <CameraSwipeArea onSwipe={(dx, dy) => input?.setCameraDelta(dx, dy)} />

            {/* Joystick (bottom-left) */}
            <div className="fixed bottom-6 left-6 z-30" style={{ pointerEvents: 'auto' }}>
              <TouchJoystick onMove={(x, y) => input?.setJoystick(x, y)} />
            </div>

            {/* Action buttons (bottom-right) */}
            <div className="fixed bottom-6 right-6 z-30 flex flex-col items-end gap-3" style={{ pointerEvents: 'auto' }}>
              <div className="flex gap-3">
                <ActionButton
                  label="فوضى"
                  icon="💥"
                  color="#cc3333"
                  size={56}
                  onPress={() => input?.pressAction()}
                />
                <ActionButton
                  label="سيارة"
                  icon="🚗"
                  color="#4488cc"
                  size={56}
                  onPress={() => input?.pressEnter()}
                />
              </div>
              <div className="flex gap-3 items-end">
                <HoldButton
                  label="جري"
                  icon="🏃"
                  color="#44aa66"
                  size={48}
                  onHold={(v) => input?.setSprint(v)}
                />
                <ActionButton
                  label="قفز"
                  icon="⬆️"
                  color="#ff9933"
                  size={72}
                  onPress={() => input?.pressJump()}
                />
              </div>
            </div>

            {/* Switch character button (top-right area) */}
            <button
              onClick={() => input?.pressSwitch()}
              className="fixed bottom-6 left-1/2 -translate-x-1/2 z-30 px-4 py-2 rounded-xl text-white text-xs backdrop-blur-md transition-all active:scale-95"
              style={{ background: 'rgba(100,150,200,0.5)', border: '1px solid rgba(255,255,255,0.2)' }}
            >
              👥 تبديل
            </button>
          </div>

          {/* Desktop hint */}
          <div className="hidden md:block fixed bottom-4 right-4 z-30 text-white/40 text-xs text-right" dir="rtl">
            <p>WASD: حركة | مسافة: قفز | F: سيارة | E: فوضى | C: تبديل | Tab: هاتف</p>
            <p>الماوس: غير متاح — استخدم اللمس أو لوحة المفاتيح</p>
          </div>

          {phoneOpen && hud && hud.mission && (
            <PhoneMenu
              onClose={() => setPhoneOpen(false)}
              onSwitchCharacter={handleSwitchCharacter}
              onWorkShift={handleWorkShift}
              onBuyFood={handleBuyFood}
              characterKey={hud.characterKey}
              money={hud.money}
              health={hud.health}
              energy={hud.energy}
              wantedLevel={hud.wantedLevel}
              missionTitle={hud.mission.title}
              missionDesc={hud.mission.description}
              missionReward={hud.mission.reward}
              missionActive={hud.mission.isActive}
              missionCompletedCount={hud.mission.completedCount}
              timeLabel={hud.timeLabel}
            />
          )}
        </>
      )}

      {!started && <CharacterSelect onSelect={handleCharacterSelect} />}
    </div>
  );
}
