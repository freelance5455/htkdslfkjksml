import React, { useState, useEffect, useCallback } from "react";
import { MainCalculator } from "./components/MainCalculator";
import { CameraScanner } from "./components/CameraScanner";
import { DetectedNumbersView } from "./components/DetectedNumbersView";
import { ResultScreen } from "./components/ResultScreen";
import { HistoryView } from "./components/HistoryView";
import { SettingsView } from "./components/SettingsView";
import { BottomNav } from "./components/BottomNav";
import {
  ActiveTab,
  ScanStep,
  CalculationItem,
  UnrelatedNumber,
  CalculationHistoryEntry,
  AppSettings,
  ScanResultPayload,
} from "./types";
import { sanitizeNumber } from "./utils/calculator";

const SETTINGS_STORAGE_KEY = "smart_calc_settings_v1";
const HISTORY_STORAGE_KEY = "smart_calc_history_v1";

const DEFAULT_SETTINGS: AppSettings = {
  theme: "dark",
  currency: "",
  soundEnabled: true,
  vibrationEnabled: true,
  autoLoadScanResult: true,
};

export default function App() {
  // Navigation & Screen states
  const [activeTab, setActiveTab] = useState<ActiveTab>("calculator");
  const [scanStep, setScanStep] = useState<ScanStep>("closed");

  // Scanner data states
  const [detectedItems, setDetectedItems] = useState<CalculationItem[]>([]);
  const [unrelatedNumbers, setUnrelatedNumbers] = useState<UnrelatedNumber[]>([]);
  const [finalCalculatedTotal, setFinalCalculatedTotal] = useState<number>(0);
  const [scanNotes, setScanNotes] = useState<string>("");
  const [scanImagePreview, setScanImagePreview] = useState<string | undefined>(undefined);

  // External total to import into MainCalculator
  const [externalTotalForCalc, setExternalTotalForCalc] = useState<number | null>(null);

  // Settings
  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const stored = localStorage.getItem(SETTINGS_STORAGE_KEY);
      if (stored) return { ...DEFAULT_SETTINGS, ...JSON.parse(stored) };
    } catch {
      // Ignore storage errors
    }
    return DEFAULT_SETTINGS;
  });

  // Calculation History
  const [history, setHistory] = useState<CalculationHistoryEntry[]>(() => {
    try {
      const stored = localStorage.getItem(HISTORY_STORAGE_KEY);
      if (stored) return JSON.parse(stored);
    } catch {
      // Ignore storage errors
    }
    return [];
  });

  // Apply theme to html root
  useEffect(() => {
    const root = document.documentElement;
    if (settings.theme === "dark") {
      root.classList.add("dark");
    } else {
      root.classList.remove("dark");
    }
    try {
      localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(settings));
    } catch {
      // Ignore storage failure
    }
  }, [settings]);

  // Persist history changes
  useEffect(() => {
    try {
      localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(history));
    } catch {
      // Ignore storage failure
    }
  }, [history]);

  // Save entry to calculation history
  const handleSaveHistory = useCallback(
    (formula: string, total: number, source: "manual" | "receipt_scan" = "manual", items?: CalculationItem[]) => {
      const now = new Date();
      const dateFormatted = now.toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      });

      const entry: CalculationHistoryEntry = {
        id: `calc-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        timestamp: Date.now(),
        dateFormatted,
        source,
        formula,
        total: sanitizeNumber(total),
        items,
      };

      setHistory((prev) => [entry, ...prev]);
    },
    []
  );

  // Handle OCR scan completion from CameraScanner
  const handleScanComplete = (payload: ScanResultPayload) => {
    setDetectedItems(payload.items);
    setUnrelatedNumbers(payload.unrelatedNumbers || []);
    setScanNotes(payload.notes || "");
    setScanImagePreview(payload.imagePreviewUrl);
    setScanStep("review");
  };

  // Handle manual item add request from scanner error screen
  const handleAddManuallyFromScanner = () => {
    setDetectedItems([
      {
        id: `manual-${Date.now()}`,
        label: "Item 1",
        amount: 0,
        confidence: "high",
        category: "price",
        included: true,
      },
    ]);
    setUnrelatedNumbers([]);
    setScanNotes("Manual entry");
    setScanImagePreview(undefined);
    setScanStep("review");
  };

  // Handle Calculate Total button click on Detected Numbers screen
  const handleCalculateTotal = (selectedItems: CalculationItem[], total: number) => {
    setFinalCalculatedTotal(total);
    setScanStep("result");

    // Formulate string and add to history
    const formula = selectedItems.map((it) => it.amount).join(" + ");
    handleSaveHistory(formula, total, "receipt_scan", selectedItems);
  };

  // Handle "Done" on result screen: load total into calculator
  const handleResultDone = () => {
    setExternalTotalForCalc(finalCalculatedTotal);
    setScanStep("closed");
    setActiveTab("calculator");
  };

  // Load a historic entry back into calculator
  const handleLoadHistoryIntoCalc = (total: number) => {
    setExternalTotalForCalc(total);
    setActiveTab("calculator");
  };

  // Delete an individual history entry
  const handleDeleteHistoryEntry = (id: string) => {
    setHistory((prev) => prev.filter((item) => item.id !== id));
  };

  // Clear all history
  const handleClearAllHistory = () => {
    setHistory([]);
  };

  // Clear all data (Settings)
  const handleClearAllData = () => {
    setHistory([]);
    setSettings(DEFAULT_SETTINGS);
    localStorage.removeItem(HISTORY_STORAGE_KEY);
    localStorage.removeItem(SETTINGS_STORAGE_KEY);
  };

  return (
    <div className="h-dvh w-screen flex flex-col bg-zinc-50 dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100 antialiased select-none overflow-hidden font-sans">
      {/* Active Content Area */}
      <main className="flex-1 overflow-hidden relative flex flex-col">
        {scanStep === "closed" && (
          <>
            {activeTab === "calculator" && (
              <MainCalculator
                settings={settings}
                onOpenScanner={() => setScanStep("camera")}
                onSaveHistory={handleSaveHistory}
                externalTotal={externalTotalForCalc}
                onClearExternalTotal={() => setExternalTotalForCalc(null)}
              />
            )}

            {activeTab === "history" && (
              <HistoryView
                history={history}
                settings={settings}
                onDeleteEntry={handleDeleteHistoryEntry}
                onClearAllHistory={handleClearAllHistory}
                onLoadIntoCalculator={handleLoadHistoryIntoCalc}
              />
            )}

            {activeTab === "settings" && (
              <SettingsView
                settings={settings}
                onUpdateSettings={(newSettings) =>
                  setSettings((prev) => ({ ...prev, ...newSettings }))
                }
                onClearAllData={handleClearAllData}
              />
            )}
          </>
        )}

        {/* Scan Workflow Step 1: Camera Scanner */}
        {scanStep === "camera" && (
          <CameraScanner
            onClose={() => setScanStep("closed")}
            onScanComplete={handleScanComplete}
            onAddManually={handleAddManuallyFromScanner}
          />
        )}

        {/* Scan Workflow Step 2: Detected Numbers Screen */}
        {scanStep === "review" && (
          <DetectedNumbersView
            items={detectedItems}
            unrelatedNumbers={unrelatedNumbers}
            imagePreviewUrl={scanImagePreview}
            notes={scanNotes}
            settings={settings}
            onUpdateItems={setDetectedItems}
            onCalculateTotal={handleCalculateTotal}
            onRetakePhoto={() => setScanStep("camera")}
            onAddManualItem={() => {}}
          />
        )}

        {/* Scan Workflow Step 3: Calculation Result Screen */}
        {scanStep === "result" && (
          <ResultScreen
            items={detectedItems.filter((it) => it.included)}
            total={finalCalculatedTotal}
            settings={settings}
            onCopy={() => {}}
            onShare={() => {}}
            onRetakePhoto={() => setScanStep("camera")}
            onCalculateAgain={() => setScanStep("review")}
            onDone={handleResultDone}
          />
        )}
      </main>

      {/* Bottom Navigation Bar (Shown when scanner modal is not active) */}
      {scanStep === "closed" && (
        <BottomNav
          activeTab={activeTab}
          onSelectTab={setActiveTab}
          onTriggerCamera={() => setScanStep("camera")}
        />
      )}
    </div>
  );
}
