export interface CalculationItem {
  id: string;
  label: string;
  amount: number;
  confidence?: "high" | "medium" | "low";
  category?: "price" | "subtotal" | "discount" | "tax" | "code" | "other";
  included: boolean;
  notes?: string;
}

export interface UnrelatedNumber {
  label: string;
  value: string | number;
  reason: string;
}

export interface CalculationHistoryEntry {
  id: string;
  timestamp: number;
  dateFormatted: string;
  source: "receipt_scan" | "manual";
  formula: string;
  total: number;
  items?: CalculationItem[];
}

export interface AppSettings {
  theme: "light" | "dark" | "system";
  currency: string;
  soundEnabled: boolean;
  vibrationEnabled: boolean;
  autoLoadScanResult: boolean;
}

export type ActiveTab = "calculator" | "history" | "settings";

export type ScanStep = "closed" | "camera" | "processing" | "review" | "result" | "error";

export interface ScanResultPayload {
  items: CalculationItem[];
  unrelatedNumbers?: UnrelatedNumber[];
  detectedTotal?: number | null;
  notes?: string;
  imagePreviewUrl?: string;
}
