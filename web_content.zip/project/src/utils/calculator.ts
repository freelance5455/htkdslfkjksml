/**
 * Precision calculator engine
 */

export interface CalcState {
  display: string; // The current input or final result
  expression: string; // Full running expression, e.g. "100 + 250 + 75"
  history: string; // Previous calculation expression
  isNewInput: boolean; // Flag to replace display on next digit
  hasCalculated: boolean;
}

export const INITIAL_CALC_STATE: CalcState = {
  display: "0",
  expression: "",
  history: "",
  isNewInput: true,
  hasCalculated: false,
};

// Clean floating point errors (e.g. 0.1 + 0.2 -> 0.3)
export function sanitizeNumber(num: number): number {
  if (isNaN(num) || !isFinite(num)) return 0;
  return Math.round((num + Number.EPSILON) * 10000000000) / 10000000000;
}

export function formatNumberDisplay(value: string | number): string {
  const str = String(value);
  if (str === "Error" || str === "NaN" || str === "Infinity") return str;

  // If there's an active decimal point at the end, preserve it (e.g. "12.")
  const endsWithDot = str.endsWith(".");
  const parts = str.split(".");
  const integerPart = parts[0];
  const decimalPart = parts[1];

  const formattedInt = Number(integerPart).toLocaleString("en-US");
  if (isNaN(Number(integerPart))) return str;

  if (parts.length > 1) {
    return `${formattedInt}.${decimalPart}`;
  }
  return endsWithDot ? `${formattedInt}.` : formattedInt;
}

// Safely evaluates arithmetic expressions (+, -, ×, ÷)
export function evaluateExpression(expr: string): number | null {
  try {
    if (!expr || !expr.trim()) return null;

    // Convert display symbols to standard math tokens
    let sanitized = expr
      .replace(/×/g, "*")
      .replace(/÷/g, "/")
      .replace(/−/g, "-")
      .replace(/,/g, "")
      .trim();

    // Remove trailing operator if user hasn't typed the next number
    sanitized = sanitized.replace(/[\+\-\*\/]+$/, "").trim();
    if (!sanitized) return null;

    // Safety check: only allow digits, operators, dots, parentheses, whitespace
    if (!/^[0-9\+\-\*\/\.\s\(\)]+$/.test(sanitized)) {
      return null;
    }

    // Function constructor safer than eval for pure math
    // eslint-disable-next-line no-new-func
    const result = Function(`"use strict"; return (${sanitized})`)();
    if (typeof result === "number" && !isNaN(result) && isFinite(result)) {
      return sanitizeNumber(result);
    }
    return null;
  } catch {
    return null;
  }
}
