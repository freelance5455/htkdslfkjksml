/**
 * Reliable Project ZIP Downloader for AI Studio environment
 * Prevents Google AI Studio authentication/cookie-check proxy page interception
 * by using in-page authenticated fetch + blob stream with base64 fallback.
 */

import { apiUrl } from '../services/apiConfig';

export interface DownloadResult {
  success: boolean;
  filename: string;
  sizeBytes?: number;
  error?: string;
}

export async function triggerProjectZipDownload(
  onStatusUpdate?: (status: string) => void
): Promise<DownloadResult> {
  const filename = 'money-making-empire-ai-website-builder.zip';

  try {
    onStatusUpdate?.('Packaging current project files...');

    // Method 1: In-page fetch for application/zip binary
    try {
      const response = await fetch(apiUrl('/api/download-project-zip'), {
        method: 'GET',
        headers: {
          Accept: 'application/zip, application/octet-stream',
        },
      });

      const contentType = response.headers.get('content-type') || '';

      // Check if proxy intercepted with HTML (e.g. cookie check page)
      if (response.ok && !contentType.toLowerCase().includes('text/html')) {
        const blob = await response.blob();
        
        // Double check header of the blob: ZIP files start with PK (0x50, 0x4B)
        if (blob.size > 2000) {
          const bufferSlice = await blob.slice(0, 4).arrayBuffer();
          const bytes = new Uint8Array(bufferSlice);
          if (bytes[0] === 0x50 && bytes[1] === 0x4b) {
            saveBlobToUserDisk(blob, filename);
            onStatusUpdate?.('Download started!');
            return {
              success: true,
              filename,
              sizeBytes: blob.size,
            };
          }
        }
      }
    } catch (binErr) {
      console.warn('Binary fetch failed, falling back to JSON stream:', binErr);
    }

    // Method 2: JSON API Base64 fallback (Proxy NEVER intercepts JSON API calls with cookie check!)
    onStatusUpdate?.('Downloading project archive via secure data channel...');
    const jsonRes = await fetch(apiUrl('/api/download-project-zip?format=base64'), {
      method: 'GET',
      headers: {
        Accept: 'application/json',
      },
    });

    if (!jsonRes.ok) {
      throw new Error(`Server returned status HTTP ${jsonRes.status}`);
    }

    const data = await jsonRes.json();
    if (!data.base64) {
      throw new Error(data.error || 'Server did not return archive data');
    }

    onStatusUpdate?.('Extracting ZIP stream...');
    const binaryString = window.atob(data.base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }

    const zipBlob = new Blob([bytes], { type: 'application/zip' });
    saveBlobToUserDisk(zipBlob, data.filename || filename);
    onStatusUpdate?.('Download started!');

    return {
      success: true,
      filename: data.filename || filename,
      sizeBytes: zipBlob.size,
    };
  } catch (err: any) {
    console.error('Failed to download project zip:', err);
    onStatusUpdate?.(`Download error: ${err.message || 'Unknown'}`);
    return {
      success: false,
      filename,
      error: err.message || 'Could not download ZIP archive',
    };
  }
}

function saveBlobToUserDisk(blob: Blob, filename: string) {
  const blobUrl = window.URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.style.display = 'none';
  link.href = blobUrl;
  link.download = filename;
  link.setAttribute('download', filename);

  document.body.appendChild(link);
  link.click();

  setTimeout(() => {
    document.body.removeChild(link);
    window.URL.revokeObjectURL(blobUrl);
  }, 10000);
}
