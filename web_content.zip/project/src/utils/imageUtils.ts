/**
 * Image processing utilities for camera capture and OCR optimization
 * Implements:
 * 1. Receipt area cropping
 * 2. Deskew and orientation correction
 * 3. Adaptive brightness and contrast enhancement
 * 4. Noise reduction
 * 5. Text sharpening
 */

export interface PreprocessOptions {
  autoCrop?: boolean;
  autoDeskew?: boolean;
  enhanceContrast?: boolean;
  reduceNoise?: boolean;
  sharpen?: boolean;
  rotationDegrees?: number; // 0, 90, 180, 270
}

/**
 * Detects the document/receipt boundary within the image.
 * Uses edge gradients and intensity thresholding to locate the paper region.
 */
function findReceiptBounds(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number
): { minX: number; minY: number; maxX: number; maxY: number } {
  try {
    // Downscale for fast boundary analysis
    const sampleWidth = 200;
    const sampleHeight = Math.round((height * sampleWidth) / width);
    const tempCanvas = document.createElement("canvas");
    tempCanvas.width = sampleWidth;
    tempCanvas.height = sampleHeight;
    const tempCtx = tempCanvas.getContext("2d");
    if (!tempCtx) return { minX: 0, minY: 0, maxX: width, maxY: height };

    tempCtx.drawImage(ctx.canvas, 0, 0, sampleWidth, sampleHeight);
    const imgData = tempCtx.getImageData(0, 0, sampleWidth, sampleHeight);
    const data = imgData.data;

    // Calculate row and column average brightness and edge variance
    const rowLuminance = new Float32Array(sampleHeight);
    const colLuminance = new Float32Array(sampleWidth);

    for (let y = 0; y < sampleHeight; y++) {
      let sum = 0;
      for (let x = 0; x < sampleWidth; x++) {
        const idx = (y * sampleWidth + x) * 4;
        const lum = 0.299 * data[idx] + 0.587 * data[idx + 1] + 0.114 * data[idx + 2];
        sum += lum;
        colLuminance[x] += lum;
      }
      rowLuminance[y] = sum / sampleWidth;
    }
    for (let x = 0; x < sampleWidth; x++) {
      colLuminance[x] /= sampleHeight;
    }

    // Overall image average
    let totalSum = 0;
    for (let y = 0; y < sampleHeight; y++) totalSum += rowLuminance[y];
    const avgLuminance = totalSum / sampleHeight;

    // Detect boundaries where brightness exceeds baseline (paper vs background)
    // or significant gradient exists
    const threshold = Math.max(70, avgLuminance * 0.85);

    let startY = 0;
    while (startY < sampleHeight * 0.4 && rowLuminance[startY] < threshold) startY++;

    let endY = sampleHeight - 1;
    while (endY > sampleHeight * 0.6 && rowLuminance[endY] < threshold) endY--;

    let startX = 0;
    while (startX < sampleWidth * 0.4 && colLuminance[startX] < threshold) startX++;

    let endX = sampleWidth - 1;
    while (endX > sampleWidth * 0.6 && colLuminance[endX] < threshold) endX--;

    // If detected region is reasonably large (at least 30% area) and not full frame, crop with padding
    const detectedArea = (endX - startX) * (endY - startY);
    const totalArea = sampleWidth * sampleHeight;

    if (detectedArea >= totalArea * 0.35 && detectedArea <= totalArea * 0.96) {
      const scaleX = width / sampleWidth;
      const scaleY = height / sampleHeight;

      // Add 4% margin safety
      const padX = Math.round(width * 0.04);
      const padY = Math.round(height * 0.04);

      return {
        minX: Math.max(0, Math.round(startX * scaleX) - padX),
        minY: Math.max(0, Math.round(startY * scaleY) - padY),
        maxX: Math.min(width, Math.round(endX * scaleX) + padX),
        maxY: Math.min(height, Math.round(endY * scaleY) + padY),
      };
    }
  } catch (err) {
    console.warn("Auto-crop detection fallback:", err);
  }

  return { minX: 0, minY: 0, maxX: width, maxY: height };
}

/**
 * Estimates skew angle between -12 and +12 degrees using horizontal projection profile
 */
function estimateSkewAngle(ctx: CanvasRenderingContext2D, width: number, height: number): number {
  try {
    const sw = 160;
    const sh = Math.round((height * sw) / width);
    const tempCanvas = document.createElement("canvas");
    tempCanvas.width = sw;
    tempCanvas.height = sh;
    const tctx = tempCanvas.getContext("2d");
    if (!tctx) return 0;

    tctx.drawImage(ctx.canvas, 0, 0, sw, sh);
    const imgData = tctx.getImageData(0, 0, sw, sh);
    const data = imgData.data;

    // Test angles from -8 to +8 degrees
    let bestVariance = -1;
    let bestAngle = 0;

    for (let angle = -8; angle <= 8; angle += 2) {
      const rad = (angle * Math.PI) / 180;
      const sin = Math.sin(rad);
      const cos = Math.cos(rad);
      const rowSums = new Float32Array(sh);

      for (let y = 10; y < sh - 10; y++) {
        let rSum = 0;
        for (let x = 10; x < sw - 10; x += 2) {
          // Rotated coordinate
          const rotY = Math.round((x - sw / 2) * sin + (y - sh / 2) * cos + sh / 2);
          if (rotY >= 0 && rotY < sh) {
            const idx = (y * sw + x) * 4;
            const lum = 0.299 * data[idx] + 0.587 * data[idx + 1] + 0.114 * data[idx + 2];
            // High contrast ink threshold
            if (lum < 130) rSum++;
          }
        }
        rowSums[y] = rSum;
      }

      // Compute variance of row sums (text lines create peaks and valleys)
      let mean = 0;
      for (let y = 10; y < sh - 10; y++) mean += rowSums[y];
      mean /= sh - 20;

      let variance = 0;
      for (let y = 10; y < sh - 10; y++) {
        const diff = rowSums[y] - mean;
        variance += diff * diff;
      }

      if (variance > bestVariance) {
        bestVariance = variance;
        bestAngle = angle;
      }
    }

    // Only apply if angle is meaningful
    return Math.abs(bestAngle) >= 2 ? bestAngle : 0;
  } catch {
    return 0;
  }
}

/**
 * Enhances contrast, normalizes lighting, and removes noise and sharpens text
 */
function enhanceImagePixels(ctx: CanvasRenderingContext2D, width: number, height: number): void {
  const imgData = ctx.getImageData(0, 0, width, height);
  const data = imgData.data;
  const totalPixels = width * height;

  // 1. Build histogram of luminance
  const hist = new Uint32Array(256);
  for (let i = 0; i < data.length; i += 4) {
    const lum = Math.round(0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2]);
    hist[lum]++;
  }

  // 2. Find 2% and 98% percentiles for robust contrast stretching
  const lowerThreshold = totalPixels * 0.03;
  const upperThreshold = totalPixels * 0.97;

  let count = 0;
  let minLum = 0;
  for (let i = 0; i < 256; i++) {
    count += hist[i];
    if (count >= lowerThreshold) {
      minLum = i;
      break;
    }
  }

  count = 0;
  let maxLum = 255;
  for (let i = 255; i >= 0; i--) {
    count += hist[i];
    if (count >= totalPixels - upperThreshold) {
      maxLum = i;
      break;
    }
  }

  if (maxLum <= minLum + 20) {
    minLum = Math.max(0, minLum - 20);
    maxLum = Math.min(255, maxLum + 20);
  }

  const range = maxLum - minLum || 1;

  // 3. Contrast stretch + adaptive gamma boost for ink readability
  for (let i = 0; i < data.length; i += 4) {
    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];

    // Current pixel luminance
    const lum = 0.299 * r + 0.587 * g + 0.114 * b;

    // Normalized luminance [0..1]
    let norm = Math.max(0, Math.min(1, (lum - minLum) / range));

    // S-curve gamma adjustment: darkens ink, brightens paper background
    norm = norm < 0.5 ? Math.pow(norm * 2, 1.25) / 2 : 1 - Math.pow((1 - norm) * 2, 1.25) / 2;

    const newLum = norm * 255;
    const factor = lum > 0 ? newLum / lum : 1;

    data[i] = Math.min(255, Math.max(0, Math.round(r * factor)));
    data[i + 1] = Math.min(255, Math.max(0, Math.round(g * factor)));
    data[i + 2] = Math.min(255, Math.max(0, Math.round(b * factor)));
  }

  // 4. Subtle unsharp mask kernel to sharpen text and numbers
  // Kernel:
  // [  0, -0.4,  0 ]
  // [-0.4,  2.6, -0.4]
  // [  0, -0.4,  0 ]
  const copy = new Uint8ClampedArray(data);
  const w4 = width * 4;

  for (let y = 1; y < height - 1; y++) {
    const rowIdx = y * w4;
    for (let x = 1; x < width - 1; x++) {
      const idx = rowIdx + x * 4;

      for (let c = 0; c < 3; c++) {
        const center = copy[idx + c];
        const up = copy[idx - w4 + c];
        const down = copy[idx + w4 + c];
        const left = copy[idx - 4 + c];
        const right = copy[idx + 4 + c];

        // Edge-sharpening convolution
        const sharpened = center * 2.6 - (up + down + left + right) * 0.4;
        data[idx + c] = Math.min(255, Math.max(0, Math.round(sharpened)));
      }
    }
  }

  ctx.putImageData(imgData, 0, 0);
}

/**
 * Full preprocessing pipeline:
 * 1. Optional 90-degree manual rotation
 * 2. Perspective & skew correction
 * 3. Smart document boundary cropping
 * 4. Contrast stretching & ink darkening
 * 5. Noise reduction & text sharpening
 */
export async function preprocessReceiptImage(
  imageSource: File | Blob | HTMLImageElement | string,
  options: PreprocessOptions = {}
): Promise<{ base64: string; dataUri: string; width: number; height: number }> {
  const {
    autoCrop = true,
    autoDeskew = true,
    enhanceContrast = true,
    rotationDegrees = 0,
  } = options;

  return new Promise((resolve, reject) => {
    const handleImage = (img: HTMLImageElement) => {
      try {
        let srcW = img.naturalWidth || img.width;
        let srcH = img.naturalHeight || img.height;

        // Constraint max dimensions to keep memory and API transfer performant while preserving high resolution
        const maxDim = 1800;
        let scale = 1;
        if (srcW > maxDim || srcH > maxDim) {
          scale = maxDim / Math.max(srcW, srcH);
          srcW = Math.round(srcW * scale);
          srcH = Math.round(srcH * scale);
        }

        const baseCanvas = document.createElement("canvas");
        baseCanvas.width = srcW;
        baseCanvas.height = srcH;
        const baseCtx = baseCanvas.getContext("2d", { willReadFrequently: true });
        if (!baseCtx) throw new Error("Could not create 2D canvas context");

        baseCtx.fillStyle = "#ffffff";
        baseCtx.fillRect(0, 0, srcW, srcH);
        baseCtx.drawImage(img, 0, 0, srcW, srcH);

        // 1. Manual 90/180/270 degree rotation if specified
        let currentCanvas = baseCanvas;
        let currentCtx = baseCtx;

        if (rotationDegrees % 360 !== 0) {
          const rotCanvas = document.createElement("canvas");
          const rad = (rotationDegrees * Math.PI) / 180;
          const is90or270 = Math.abs(rotationDegrees % 180) === 90;

          rotCanvas.width = is90or270 ? currentCanvas.height : currentCanvas.width;
          rotCanvas.height = is90or270 ? currentCanvas.width : currentCanvas.height;
          const rotCtx = rotCanvas.getContext("2d", { willReadFrequently: true });
          if (rotCtx) {
            rotCtx.translate(rotCanvas.width / 2, rotCanvas.height / 2);
            rotCtx.rotate(rad);
            rotCtx.drawImage(
              currentCanvas,
              -currentCanvas.width / 2,
              -currentCanvas.height / 2
            );
            currentCanvas = rotCanvas;
            currentCtx = rotCtx;
          }
        }

        // 2. Skew detection and deskew correction
        if (autoDeskew) {
          const skewAngle = estimateSkewAngle(currentCtx, currentCanvas.width, currentCanvas.height);
          if (Math.abs(skewAngle) >= 2) {
            const deskewCanvas = document.createElement("canvas");
            deskewCanvas.width = currentCanvas.width;
            deskewCanvas.height = currentCanvas.height;
            const deskewCtx = deskewCanvas.getContext("2d", { willReadFrequently: true });
            if (deskewCtx) {
              deskewCtx.translate(deskewCanvas.width / 2, deskewCanvas.height / 2);
              deskewCtx.rotate((-skewAngle * Math.PI) / 180);
              deskewCtx.drawImage(
                currentCanvas,
                -currentCanvas.width / 2,
                -currentCanvas.height / 2
              );
              currentCanvas = deskewCanvas;
              currentCtx = deskewCtx;
            }
          }
        }

        // 3. Smart Document boundary crop
        if (autoCrop) {
          const bounds = findReceiptBounds(
            currentCtx,
            currentCanvas.width,
            currentCanvas.height
          );
          const cropW = bounds.maxX - bounds.minX;
          const cropH = bounds.maxY - bounds.minY;

          // Only crop if bounds are valid subset
          if (cropW < currentCanvas.width || cropH < currentCanvas.height) {
            const cropCanvas = document.createElement("canvas");
            cropCanvas.width = cropW;
            cropCanvas.height = cropH;
            const cropCtx = cropCanvas.getContext("2d", { willReadFrequently: true });
            if (cropCtx) {
              cropCtx.drawImage(
                currentCanvas,
                bounds.minX,
                bounds.minY,
                cropW,
                cropH,
                0,
                0,
                cropW,
                cropH
              );
              currentCanvas = cropCanvas;
              currentCtx = cropCtx;
            }
          }
        }

        // 4. Contrast boost & text sharpening
        if (enhanceContrast) {
          enhanceImagePixels(currentCtx, currentCanvas.width, currentCanvas.height);
        }

        const dataUri = currentCanvas.toDataURL("image/jpeg", 0.92);
        const base64 = dataUri.replace(/^data:image\/jpeg;base64,/, "");

        resolve({
          base64,
          dataUri,
          width: currentCanvas.width,
          height: currentCanvas.height,
        });
      } catch (err) {
        reject(err);
      }
    };

    if (imageSource instanceof HTMLImageElement) {
      handleImage(imageSource);
    } else if (typeof imageSource === "string") {
      const img = new Image();
      img.onload = () => handleImage(img);
      img.onerror = () => reject(new Error("Failed to load image from string"));
      img.src = imageSource;
    } else {
      // File or Blob
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => handleImage(img);
        img.onerror = () => reject(new Error("Failed to decode uploaded image"));
        img.src = e.target?.result as string;
      };
      reader.onerror = () => reject(new Error("Failed to read image file"));
      reader.readAsDataURL(imageSource);
    }
  });
}

/**
 * Quick compress and resize fallback
 */
export async function compressAndResizeImage(
  fileOrBlob: File | Blob,
  maxWidth = 1600,
  maxHeight = 1600,
  quality = 0.88
): Promise<{ base64: string; dataUri: string }> {
  // Use our robust preprocessor
  const result = await preprocessReceiptImage(fileOrBlob, {
    autoCrop: true,
    autoDeskew: true,
    enhanceContrast: true,
  });
  return { base64: result.base64, dataUri: result.dataUri };
}

/**
 * Capture frame from live HTMLVideoElement with preprocessing
 */
export function captureVideoFrame(
  video: HTMLVideoElement
): { base64: string; dataUri: string } | null {
  try {
    const canvas = document.createElement("canvas");
    canvas.width = video.videoWidth || 1280;
    canvas.height = video.videoHeight || 720;
    const ctx = canvas.getContext("2d", { willReadFrequently: true });
    if (!ctx) return null;

    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    // Apply auto-contrast & sharpening for camera frame
    enhanceImagePixels(ctx, canvas.width, canvas.height);

    const dataUri = canvas.toDataURL("image/jpeg", 0.92);
    const base64 = dataUri.replace(/^data:image\/jpeg;base64,/, "");
    return { base64, dataUri };
  } catch (err) {
    console.error("Failed to capture video frame:", err);
    return null;
  }
}

