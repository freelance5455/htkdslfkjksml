import { CalculationItem, UnrelatedNumber } from "../types";

export interface SampleReceipt {
  id: string;
  title: string;
  type: string;
  description: string;
  items: CalculationItem[];
  unrelatedNumbers: UnrelatedNumber[];
  detectedTotal: number;
  svgDataUri: string;
}

// Generate SVG image of a supermarket receipt
function generateReceiptSvg(
  storeName: string,
  lines: { label: string; price: string }[],
  total: string,
  extra: { date: string; invoice: string; phone: string }
): string {
  const itemRows = lines
    .map(
      (item, i) =>
        `<text x="24" y="${170 + i * 32}" font-family="monospace" font-size="16" fill="#1e293b">${item.label}</text>
         <text x="350" y="${170 + i * 32}" text-anchor="end" font-family="monospace" font-size="16" font-weight="bold" fill="#0f172a">${item.price}</text>`
    )
    .join("");

  const svg = `
<svg xmlns="http://www.w3.org/2000/svg" width="380" height="520" viewBox="0 0 380 520">
  <defs>
    <filter id="paperShadow" x="-5%" y="-5%" width="110%" height="110%">
      <feDropShadow dx="0" dy="4" stdDeviation="6" flood-color="#000000" flood-opacity="0.15"/>
    </filter>
  </defs>
  <!-- Paper background with jagged edge effect -->
  <rect x="10" y="10" width="360" height="500" rx="4" fill="#faf9f5" stroke="#e2e8f0" stroke-width="1.5" filter="url(#paperShadow)"/>
  
  <!-- Header -->
  <text x="190" y="48" text-anchor="middle" font-family="sans-serif" font-size="18" font-weight="800" fill="#0f172a" letter-spacing="1">${storeName.toUpperCase()}</text>
  <text x="190" y="70" text-anchor="middle" font-family="sans-serif" font-size="11" fill="#64748b">TEL: ${extra.phone}</text>
  <text x="190" y="88" text-anchor="middle" font-family="sans-serif" font-size="11" fill="#64748b">DATE: ${extra.date} | INV: ${extra.invoice}</text>
  
  <!-- Divider -->
  <line x1="24" y1="108" x2="356" y2="108" stroke="#cbd5e1" stroke-width="1.5" stroke-dasharray="4 4"/>
  <text x="24" y="132" font-family="sans-serif" font-size="12" font-weight="bold" fill="#475569">ITEM</text>
  <text x="350" y="132" text-anchor="end" font-family="sans-serif" font-size="12" font-weight="bold" fill="#475569">AMOUNT</text>
  <line x1="24" y1="144" x2="356" y2="144" stroke="#cbd5e1" stroke-width="1.5"/>
  
  <!-- Line Items -->
  ${itemRows}
  
  <!-- Subtotal / Total -->
  <line x1="24" y1="360" x2="356" y2="360" stroke="#cbd5e1" stroke-width="1.5" stroke-dasharray="4 4"/>
  <text x="24" y="394" font-family="sans-serif" font-size="16" font-weight="800" fill="#0f172a">TOTAL</text>
  <text x="350" y="394" text-anchor="end" font-family="sans-serif" font-size="18" font-weight="800" fill="#0f172a">${total}</text>
  
  <!-- Barcode footer -->
  <rect x="70" y="430" width="240" height="36" fill="#0f172a" rx="2" opacity="0.85"/>
  <text x="190" y="482" text-anchor="middle" font-family="monospace" font-size="11" fill="#64748b">* 9 8 7 4 1 0 2 3 5 *</text>
</svg>`;

  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

// Generate realistic SVG image of a handwritten Pakistani shop slip (parchi)
function generateHandwrittenSlipSvg(
  storeName: string,
  lines: { label: string; price: string }[],
  total: string,
  extra: { date: string; invoice: string; phone: string }
): string {
  const rowHeight = 25;
  const startY = 140;

  // Horizontal blue ruled lines
  let ruledLines = "";
  for (let i = 0; i < 16; i++) {
    const y = startY + i * rowHeight;
    ruledLines += `<line x1="16" y1="${y}" x2="384" y2="${y}" stroke="#bfdbfe" stroke-width="1" opacity="0.8"/>`;
  }

  const itemRows = lines
    .map(
      (item, i) =>
        `<text x="48" y="${startY + i * rowHeight - 6}" font-family="cursive, 'Comic Sans MS', sans-serif" font-size="13" font-weight="600" fill="#1e3a8a">${item.label}</text>
         <text x="370" y="${startY + i * rowHeight - 6}" text-anchor="end" font-family="cursive, 'Comic Sans MS', sans-serif" font-size="14" font-weight="bold" fill="#0f172a">${item.price}</text>`
    )
    .join("");

  const svg = `
<svg xmlns="http://www.w3.org/2000/svg" width="400" height="570" viewBox="0 0 400 570">
  <defs>
    <filter id="parchiShadow" x="-5%" y="-5%" width="110%" height="110%">
      <feDropShadow dx="0" dy="4" stdDeviation="5" flood-color="#000000" flood-opacity="0.12"/>
    </filter>
  </defs>
  <!-- Lined parchi pad background -->
  <rect x="10" y="10" width="380" height="550" rx="3" fill="#fefce8" stroke="#fef08a" stroke-width="1.5" filter="url(#parchiShadow)"/>
  
  <!-- Red vertical margin line on left -->
  <line x1="42" y1="18" x2="42" y2="550" stroke="#fca5a5" stroke-width="1.5" opacity="0.85"/>

  <!-- Urdu Bismillah Calligraphy simulation -->
  <text x="200" y="32" text-anchor="middle" font-family="serif" font-size="12" fill="#15803d" font-weight="bold">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ (786)</text>

  <!-- Store Header -->
  <text x="200" y="52" text-anchor="middle" font-family="sans-serif" font-size="15" font-weight="800" fill="#1e293b">${storeName}</text>
  <text x="200" y="68" text-anchor="middle" font-family="sans-serif" font-size="10" fill="#64748b">Main Bazar, Shop #14 | Mobile: ${extra.phone}</text>
  
  <!-- Slip Info -->
  <text x="48" y="90" font-family="sans-serif" font-size="10" font-weight="bold" fill="#334155">Bill No: ${extra.invoice}</text>
  <text x="370" y="90" text-anchor="end" font-family="sans-serif" font-size="10" font-weight="bold" fill="#334155">Date: ${extra.date}</text>
  
  <!-- Table Header -->
  <rect x="20" y="98" width="360" height="22" fill="#e2e8f0" rx="2" opacity="0.7"/>
  <text x="28" y="113" font-family="sans-serif" font-size="10" font-weight="bold" fill="#1e293b">S#</text>
  <text x="54" y="113" font-family="sans-serif" font-size="10" font-weight="bold" fill="#1e293b">TAFSEEL / PARTICULARS</text>
  <text x="370" y="113" text-anchor="end" font-family="sans-serif" font-size="10" font-weight="bold" fill="#1e293b">AMOUNT (RS)</text>

  <!-- Ruled notebook lines -->
  ${ruledLines}

  <!-- 13 Handwritten Items -->
  ${itemRows}

  <!-- Grand Total / Mizan -->
  <line x1="20" y1="472" x2="380" y2="472" stroke="#475569" stroke-width="1.5"/>
  <text x="48" y="494" font-family="sans-serif" font-size="14" font-weight="800" fill="#0f172a">TOTAL / MIZAN (ميزان)</text>
  <text x="370" y="494" text-anchor="end" font-family="cursive, sans-serif" font-size="18" font-weight="900" fill="#0f172a">Rs. ${total}/=</text>

  <!-- Shop Stamp / Signature simulation -->
  <ellipse cx="100" cy="528" rx="45" ry="16" fill="none" stroke="#2563eb" stroke-width="1.2" stroke-dasharray="3 2" opacity="0.6" transform="rotate(-6 100 528)"/>
  <text x="100" y="532" text-anchor="middle" font-family="sans-serif" font-size="9" fill="#2563eb" font-weight="bold" opacity="0.7" transform="rotate(-6 100 532)">PAID / WASOOL</text>
  <text x="340" y="535" text-anchor="end" font-family="cursive" font-size="12" fill="#64748b">Signature: ________</text>
</svg>`;

  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

export const SAMPLE_RECEIPTS: SampleReceipt[] = [
  {
    id: "pakistani-handwritten-bill",
    title: "Pakistani Shop Slip (Electric & Hardware)",
    type: "Handwritten Shop Slip (Parchi)",
    description: "13 handwritten items: 360, 150, 250, 400, 1350, 300, 30, 450, 10, 500, 400, 200, 120",
    items: [
      { id: "pk-1", label: "Switch & Socket Sheet", amount: 360, confidence: "high", category: "price", included: true },
      { id: "pk-2", label: "2.5mm Wire Coil", amount: 150, confidence: "high", category: "price", included: true },
      { id: "pk-3", label: "Circuit Breaker 20A", amount: 250, confidence: "high", category: "price", included: true },
      { id: "pk-4", label: "LED Concealed Light", amount: 400, confidence: "high", category: "price", included: true },
      { id: "pk-5", label: "Copper Cable Roll", amount: 1350, confidence: "high", category: "price", included: true },
      { id: "pk-6", label: "Gang Box (8-Way)", amount: 300, confidence: "high", category: "price", included: true },
      { id: "pk-7", label: "Insulation Tape", amount: 30, confidence: "high", category: "price", included: true },
      { id: "pk-8", label: "Fan Dimmer Regulator", amount: 450, confidence: "high", category: "price", included: true },
      { id: "pk-9", label: "Rawal Plugs & Screws", amount: 10, confidence: "high", category: "price", included: true },
      { id: "pk-10", label: "PVC Conduit Pipe 10ft", amount: 500, confidence: "high", category: "price", included: true },
      { id: "pk-11", label: "Bracket Light Holder", amount: 400, confidence: "high", category: "price", included: true },
      { id: "pk-12", label: "Multi-Plug Adapter", amount: 200, confidence: "high", category: "price", included: true },
      { id: "pk-13", label: "Flexible Pipe 15ft", amount: 120, confidence: "high", category: "price", included: true },
    ],
    unrelatedNumbers: [
      { label: "Shop Mobile", value: "0300-4521980", reason: "Shop contact phone number" },
      { label: "Date", value: "12/09/2026", reason: "Transaction slip date" },
      { label: "Bill #", value: "142", reason: "Parchi sequence number" },
    ],
    detectedTotal: 4520,
    svgDataUri: generateHandwrittenSlipSvg(
      "Al-Madina Electric & Hardware Store",
      [
        { label: "1. Switch / Socket Sheet", price: "360" },
        { label: "2. 2.5mm Wire", price: "150" },
        { label: "3. Breaker 20A", price: "250" },
        { label: "4. LED Concealed Light", price: "400" },
        { label: "5. Copper Cable Roll", price: "1350" },
        { label: "6. Gang Box 8 Way", price: "300" },
        { label: "7. Tape Roll", price: "30" },
        { label: "8. Fan Dimmer", price: "450" },
        { label: "9. Rawal Plugs", price: "10" },
        { label: "10. PVC Pipe 10ft", price: "500" },
        { label: "11. Bracket Holder", price: "400" },
        { label: "12. Multi Plug", price: "200" },
        { label: "13. Flexible Pipe", price: "120" },
      ],
      "4520",
      { date: "12/09/2026", invoice: "142", phone: "0300-4521980" }
    ),
  },
  {
    id: "grocery-example",
    title: "Grocery Slip (Prompt Example)",
    type: "Printed Grocery Slip",
    description: "Rice 100, Milk 250, Sugar 75, Oil 500",
    items: [
      { id: "s1-1", label: "Rice", amount: 100, confidence: "high", category: "price", included: true },
      { id: "s1-2", label: "Milk", amount: 250, confidence: "high", category: "price", included: true },
      { id: "s1-3", label: "Sugar", amount: 75, confidence: "high", category: "price", included: true },
      { id: "s1-4", label: "Oil", amount: 500, confidence: "high", category: "price", included: true },
    ],
    unrelatedNumbers: [
      { label: "Phone", value: "+1-800-555-0199", reason: "Store contact number" },
      { label: "Date", value: "2026-09-12", reason: "Transaction date" },
      { label: "Invoice #", value: "INV-9821", reason: "Receipt sequence number" },
    ],
    detectedTotal: 925,
    svgDataUri: generateReceiptSvg(
      "Daily Mart & Provisions",
      [
        { label: "Rice (Basmati 1kg)", price: "100" },
        { label: "Fresh Milk 1L", price: "250" },
        { label: "Refined Sugar 500g", price: "75" },
        { label: "Cooking Oil 1L", price: "500" },
      ],
      "925",
      { date: "12/09/2026", invoice: "INV-9821", phone: "555-0199" }
    ),
  },
  {
    id: "cafe-bill",
    title: "Cafe & Bakery Receipt",
    type: "Restaurant Bill",
    description: "Coffee, Croissant, Avocado Toast, Fresh Juice",
    items: [
      { id: "s2-1", label: "Espresso Double", amount: 4.5, confidence: "high", category: "price", included: true },
      { id: "s2-2", label: "Almond Croissant", amount: 3.75, confidence: "high", category: "price", included: true },
      { id: "s2-3", label: "Avocado Toast", amount: 12.0, confidence: "high", category: "price", included: true },
      { id: "s2-4", label: "Orange Juice", amount: 5.5, confidence: "high", category: "price", included: true },
    ],
    unrelatedNumbers: [
      { label: "Table", value: "04", reason: "Table identifier" },
      { label: "Time", value: "11:42", reason: "Order timestamp" },
      { label: "Server ID", value: "88", reason: "Staff employee code" },
    ],
    detectedTotal: 25.75,
    svgDataUri: generateReceiptSvg(
      "Artisan Cafe & Bakery",
      [
        { label: "Espresso Double", price: "4.50" },
        { label: "Almond Croissant", price: "3.75" },
        { label: "Avocado Toast", price: "12.00" },
        { label: "Orange Juice", price: "5.50" },
      ],
      "25.75",
      { date: "12/09/2026", invoice: "ORD-4412", phone: "555-0142" }
    ),
  },
  {
    id: "handwritten-slip",
    title: "Handwritten Expense Slip",
    type: "Handwritten Memo",
    description: "Taxi, Stationery, Lunch, Shipping",
    items: [
      { id: "s3-1", label: "Taxi Fare", amount: 35, confidence: "high", category: "price", included: true },
      { id: "s3-2", label: "Stationery / Pens", amount: 18, confidence: "high", category: "price", included: true },
      { id: "s3-3", label: "Client Lunch", amount: 54, confidence: "high", category: "price", included: true },
      { id: "s3-4", label: "Courier Express", amount: 22, confidence: "high", category: "price", included: true },
    ],
    unrelatedNumbers: [
      { label: "Voucher #", value: "V-104", reason: "Expense voucher reference" },
      { label: "Project Code", value: "PRJ-90", reason: "Internal billing reference" },
    ],
    detectedTotal: 129,
    svgDataUri: generateReceiptSvg(
      "Field Expense Voucher",
      [
        { label: "Taxi Fare", price: "35" },
        { label: "Stationery / Pens", price: "18" },
        { label: "Client Lunch", price: "54" },
        { label: "Courier Express", price: "22" },
      ],
      "129",
      { date: "12/09/2026", invoice: "EXP-104", phone: "555-0811" }
    ),
  },
];
