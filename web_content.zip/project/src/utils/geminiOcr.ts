import { GoogleGenAI } from "@google/genai";

// Client-side Gemini call (moved from server.ts so the app can run
// fully offline-packaged inside an Android APK with no backend server).
// The API key is bundled into the app at build time via VITE_GEMINI_API_KEY.

const apiKey = import.meta.env.VITE_GEMINI_API_KEY as string | undefined;

let ai: GoogleGenAI | null = null;
if (apiKey) {
  ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

const OCR_PROMPT = `You are a world-class OCR expert specializing in printed and handwritten receipts, invoices, bills, and shop slips ("parchis").
Your goal is to extract all financial item amounts and line items accurately so they can be summed in a smart calculator.

Types of receipts you handle:
1. Handwritten shop slips (e.g., Pakistani hardware, electrical, sanitary, mobile accessory, grocery, or general store "parchi" / katcha bill / pakka bill).
2. Printed supermarket, pharmacy, POS, and restaurant receipts.
3. Handwritten columns of expense figures or calculations on ruled or plain paper.

Rules for Extraction:
1. IDENTIFY EVERY ITEM AMOUNT:
   - Identify each item line's final cost/price.
   - For labels: If item names are handwritten (in English, Urdu, or Roman Urdu such as "switch", "wire", "tape", "plug", "socket", "charger", "cable", "breaker", "sheet", "pipe"), transcribe or translate them reasonably.
   - If the label is difficult to read or missing, DO NOT SKIP THE AMOUNT! Use a helpful label like "Item 1", "Item 2", "Item 3 (Switch)", or transcribed text.

2. STRICT SMART FILTERING (DO NOT put these into 'items'):
   Carefully filter out non-price numbers and put them in "unrelatedNumbers":
   - Phone & mobile numbers
   - Dates & timestamps
   - Invoice, bill, voucher, or token numbers
   - Table serial numbers (Sr. No column)
   - Shop registration, NTN, STRN, or GST numbers
   - Addresses and shop floor numbers
   - Quantity or unit counts unless the amount column is derived from them

3. GRAND TOTAL vs LINE ITEMS:
   - If there is a sum or grand total at the bottom, place it in "detectedTotal".
   - DO NOT duplicate the grand total as an individual line item inside "items".

4. RESILIENCE:
   - If ANY numbers or prices can be read in the image, extract them! Never return an empty list if there are readable numbers.

Return STRICT JSON matching this schema:
{
  "items": [
    { "label": "Switch / Socket", "amount": 360, "confidence": "high", "category": "price" }
  ],
  "unrelatedNumbers": [
    { "label": "Mobile Contact", "value": "0300-4521980", "reason": "Shop mobile number" }
  ],
  "detectedTotal": 4520,
  "notes": "13 handwritten line amounts detected"
}`;

export interface ScanReceiptResult {
  success: boolean;
  items: any[];
  unrelatedNumbers: any[];
  detectedTotal?: number;
  notes: string;
  error?: string;
}

export async function scanReceiptClient(
  imageBase64: string,
  mimeType: string = "image/jpeg"
): Promise<ScanReceiptResult> {
  if (!imageBase64) {
    return { success: false, items: [], unrelatedNumbers: [], notes: "", error: "Missing image data. Please provide a valid photo." };
  }

  if (!ai) {
    return {
      success: false,
      items: [],
      unrelatedNumbers: [],
      notes: "",
      error: "Gemini API key is not configured. Set VITE_GEMINI_API_KEY when building the app.",
    };
  }

  try {
    const cleanBase64 = imageBase64.replace(/^data:image\/[a-zA-Z0-9+.-]+;base64,/, "");

    const imagePart = { inlineData: { mimeType: mimeType || "image/jpeg", data: cleanBase64 } };
    const textPart = { text: OCR_PROMPT };

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: { parts: [imagePart, textPart] },
      config: {
        responseMimeType: "application/json",
        temperature: 0.1,
      },
    });

    const responseText = response.text || "";
    let parsedData: any;
    try {
      parsedData = JSON.parse(responseText);
    } catch {
      const jsonMatch = responseText.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        parsedData = JSON.parse(jsonMatch[0]);
      } else {
        throw new Error("Unable to parse OCR response as JSON");
      }
    }

    const items = Array.isArray(parsedData.items) ? parsedData.items : [];
    const formattedItems = items
      .filter((it: any) => typeof it.amount === "number" || !isNaN(Number(it.amount)))
      .map((it: any, index: number) => ({
        id: `ocr-${Date.now()}-${index}`,
        label: String(it.label || `Item ${index + 1}`).trim(),
        amount: Number(it.amount),
        confidence: it.confidence || "high",
        category: it.category || "price",
        included: true,
      }));

    return {
      success: true,
      items: formattedItems,
      unrelatedNumbers: parsedData.unrelatedNumbers || [],
      detectedTotal: parsedData.detectedTotal,
      notes: parsedData.notes || "",
    };
  } catch (error: any) {
    console.error("Error in scanReceiptClient:", error);
    return {
      success: false,
      items: [],
      unrelatedNumbers: [],
      notes: "",
      error: error?.message || "Failed to process image OCR. Please try again.",
    };
  }
}
