import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import type { Session } from '@supabase/supabase-js';
import { supabase } from '@/lib/supabase';
import { errorMessage } from '@/lib/errors';

interface AuthContextValue {
  session: Session | null;
  checking: boolean;
  isAdmin: boolean;
  accessError: string | null;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

function translateAuthError(error: unknown): string {
  const message = error instanceof Error ? error.message : '';
  if (message.includes('Invalid login credentials')) return 'E-mail ou senha incorretos.';
  if (message.includes('User already registered')) return 'Já existe uma conta com este e-mail.';
  if (message.includes('Password should be at least')) return 'A senha deve ter pelo menos 8 caracteres.';
  if (message.includes('fetch')) return 'Sem conexão com o servidor. Verifique sua internet.';
  return errorMessage(error);
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [checking, setChecking] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [accessError, setAccessError] = useState<string | null>(null);

  useEffect(() => {
    const resolveAccess = async (nextSession: Session | null) => {
      if (!nextSession) {
        setIsAdmin(false);
        setAccessError(null);
        setChecking(false);
        return;
      }
      const { data, error } = await supabase.rpc('claim_first_studio_admin');
      if (error) {
        setIsAdmin(false);
        setAccessError('Não foi possível verificar seu acesso ao painel. Tente novamente.');
      } else {
        setIsAdmin(data === true);
        setAccessError(null);
      }
      setChecking(false);
    };

    const { data: listener } = supabase.auth.onAuthStateChange((event, nextSession) => {
      setSession(nextSession);
      if (event !== 'SIGNED_IN' && event !== 'INITIAL_SESSION') {
        if (!nextSession) {
          setIsAdmin(false);
          setAccessError(null);
        }
        return;
      }
      setChecking(true);
      (async () => {
        await resolveAccess(nextSession);
      })();
    });

    return () => listener.subscription.unsubscribe();
  }, []);

  const signIn = useCallback(async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw new Error(translateAuthError(error));
  }, []);

  const signUp = useCallback(async (email: string, password: string) => {
    const { error } = await supabase.auth.signUp({ email, password });
    if (error) throw new Error(translateAuthError(error));
  }, []);

  const signOut = useCallback(async () => {
    const { error } = await supabase.auth.signOut();
    if (error) throw new Error(translateAuthError(error));
  }, []);

  const value = useMemo<AuthContextValue>(
    () => ({ session, checking, isAdmin, accessError, signIn, signUp, signOut }),
    [session, checking, isAdmin, accessError, signIn, signUp, signOut]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
}
