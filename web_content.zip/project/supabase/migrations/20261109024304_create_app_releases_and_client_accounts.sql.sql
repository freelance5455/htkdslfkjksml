/*
# App release files and client account binding

1. Changes to existing tables
- `activations`: new nullable column `user_id` that stores the client account which activated the KEY on a device. The license service fills it; administrators keep read and unbind access.

2. New Tables
- `app_releases`: one row per uploaded installation file (.apk) of a catalogue app. Stores version, file name, file size, SHA-256 checksum, storage path and whether it is the current release.

3. Storage
- New private bucket `app-releases` (200 MB limit, Android package type only). No public access; files are delivered through short-lived signed links created by the license service.
- Storage policies allow only studio administrators to list, upload and delete objects in this bucket.

4. Security
- Row level security enabled on `app_releases`. Only administrators can read or write it. Grants go only to `authenticated`.
- Client accounts never query these tables directly; they use the license service, which checks the KEY on every request.

5. Important Notes
- Deleting an application removes its release rows. Storage objects are removed by the administrator from the releases dialog before the row is deleted.
*/

ALTER TABLE activations ADD COLUMN IF NOT EXISTS user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE;

CREATE TABLE IF NOT EXISTS app_releases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  app_id uuid NOT NULL REFERENCES apps(id) ON DELETE CASCADE,
  version text NOT NULL,
  file_name text NOT NULL,
  file_size bigint NOT NULL CHECK (file_size > 0),
  checksum_sha256 text NOT NULL CHECK (checksum_sha256 ~ '^[0-9a-f]{64}$'),
  storage_path text NOT NULL UNIQUE,
  is_current boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS app_releases_app_id_idx ON app_releases (app_id);

ALTER TABLE app_releases ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON app_releases TO authenticated;

DROP POLICY IF EXISTS "admin_select_app_releases" ON app_releases;
CREATE POLICY "admin_select_app_releases" ON app_releases FOR SELECT TO authenticated USING (is_studio_admin());
DROP POLICY IF EXISTS "admin_insert_app_releases" ON app_releases;
CREATE POLICY "admin_insert_app_releases" ON app_releases FOR INSERT TO authenticated WITH CHECK (is_studio_admin());
DROP POLICY IF EXISTS "admin_update_app_releases" ON app_releases;
CREATE POLICY "admin_update_app_releases" ON app_releases FOR UPDATE TO authenticated USING (is_studio_admin()) WITH CHECK (is_studio_admin());
DROP POLICY IF EXISTS "admin_delete_app_releases" ON app_releases;
CREATE POLICY "admin_delete_app_releases" ON app_releases FOR DELETE TO authenticated USING (is_studio_admin());

INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'app-releases',
  'app-releases',
  false,
  209715200,
  ARRAY['application/vnd.android.package-archive', 'application/octet-stream']
)
ON CONFLICT (id) DO UPDATE SET
  public = false,
  file_size_limit = 209715200,
  allowed_mime_types = ARRAY['application/vnd.android.package-archive', 'application/octet-stream'];

DROP POLICY IF EXISTS "admin_select_app_release_files" ON storage.objects;
CREATE POLICY "admin_select_app_release_files" ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'app-releases' AND is_studio_admin());

DROP POLICY IF EXISTS "admin_insert_app_release_files" ON storage.objects;
CREATE POLICY "admin_insert_app_release_files" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'app-releases' AND is_studio_admin());

DROP POLICY IF EXISTS "admin_delete_app_release_files" ON storage.objects;
CREATE POLICY "admin_delete_app_release_files" ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'app-releases' AND is_studio_admin());
