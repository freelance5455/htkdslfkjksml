/*
# Plans and app optimizations

1. New Tables
- `plans`: commercial licence plans. Name, description, maximum installations, validity in days (empty means no expiry) and status (active or archived).
- `app_optimizations`: configurable optimisation options for each catalogue app. Name, description, enabled flag, belongs to one app.

2. Security
- Row level security enabled on both tables.
- Only studio administrators (`is_studio_admin()`) can read or write them. Policies are split per command.
- Grants are given only to `authenticated`.

3. Important Notes
- Deleting an app removes its optimisation options. Plans are independent of apps.
*/

CREATE TABLE IF NOT EXISTS plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  max_activations integer NOT NULL DEFAULT 1 CHECK (max_activations > 0),
  validity_days integer CHECK (validity_days IS NULL OR validity_days > 0),
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'archived')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS app_optimizations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  app_id uuid NOT NULL REFERENCES apps(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text,
  enabled boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS app_optimizations_app_id_idx ON app_optimizations (app_id);

ALTER TABLE plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE app_optimizations ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON plans TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON app_optimizations TO authenticated;

DROP POLICY IF EXISTS "admin_select_plans" ON plans;
CREATE POLICY "admin_select_plans" ON plans FOR SELECT TO authenticated USING (is_studio_admin());
DROP POLICY IF EXISTS "admin_insert_plans" ON plans;
CREATE POLICY "admin_insert_plans" ON plans FOR INSERT TO authenticated WITH CHECK (is_studio_admin());
DROP POLICY IF EXISTS "admin_update_plans" ON plans;
CREATE POLICY "admin_update_plans" ON plans FOR UPDATE TO authenticated USING (is_studio_admin()) WITH CHECK (is_studio_admin());
DROP POLICY IF EXISTS "admin_delete_plans" ON plans;
CREATE POLICY "admin_delete_plans" ON plans FOR DELETE TO authenticated USING (is_studio_admin());

DROP POLICY IF EXISTS "admin_select_app_optimizations" ON app_optimizations;
CREATE POLICY "admin_select_app_optimizations" ON app_optimizations FOR SELECT TO authenticated USING (is_studio_admin());
DROP POLICY IF EXISTS "admin_insert_app_optimizations" ON app_optimizations;
CREATE POLICY "admin_insert_app_optimizations" ON app_optimizations FOR INSERT TO authenticated WITH CHECK (is_studio_admin());
DROP POLICY IF EXISTS "admin_update_app_optimizations" ON app_optimizations;
CREATE POLICY "admin_update_app_optimizations" ON app_optimizations FOR UPDATE TO authenticated USING (is_studio_admin()) WITH CHECK (is_studio_admin());
DROP POLICY IF EXISTS "admin_delete_app_optimizations" ON app_optimizations;
CREATE POLICY "admin_delete_app_optimizations" ON app_optimizations FOR DELETE TO authenticated USING (is_studio_admin());
