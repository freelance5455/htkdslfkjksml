/*
# Admin access control for VT STUDIO

1. New Tables
- `admin_users`: lists which authenticated accounts may use the VT STUDIO panel. One row per administrator. Columns: `user_id` (primary key, references the Supabase account), `created_at`.

2. New Functions
- `is_studio_admin()`: returns true when the signed-in account is listed in `admin_users`. Used by the policies of every studio table.
- `claim_first_studio_admin()`: lets a signed-in account become the first administrator, only while `admin_users` is empty. Once an administrator exists, the function does nothing.

3. Security
- Row level security is enabled on `admin_users`.
- Administrators can only read their own row. Nobody can insert, update or delete rows from the API directly; additional administrators must be added by an existing administrator through a controlled process.
- Both functions are restricted: `anon` and `PUBLIC` cannot execute them. `is_studio_admin()` is granted to `authenticated` so policies can use it.

4. Important Notes
- The first account that signs in and claims the panel becomes the owner. No seed data or credentials are stored in this migration.
*/

CREATE TABLE IF NOT EXISTS admin_users (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE admin_users ENABLE ROW LEVEL SECURITY;

GRANT SELECT ON admin_users TO authenticated;

DROP POLICY IF EXISTS "admins_read_own_row" ON admin_users;
CREATE POLICY "admins_read_own_row" ON admin_users FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE OR REPLACE FUNCTION is_studio_admin()
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (SELECT 1 FROM admin_users WHERE user_id = auth.uid());
$$;

REVOKE EXECUTE ON FUNCTION is_studio_admin() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION is_studio_admin() TO authenticated;

CREATE OR REPLACE FUNCTION claim_first_studio_admin()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  claimed boolean := false;
BEGIN
  IF auth.uid() IS NULL THEN
    RETURN false;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM admin_users) THEN
    INSERT INTO admin_users (user_id) VALUES (auth.uid())
    ON CONFLICT (user_id) DO NOTHING;
    claimed := true;
  END IF;

  RETURN claimed OR EXISTS (SELECT 1 FROM admin_users WHERE user_id = auth.uid());
END;
$$;

REVOKE EXECUTE ON FUNCTION claim_first_studio_admin() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION claim_first_studio_admin() TO authenticated;
