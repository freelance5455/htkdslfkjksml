-- VT ACCESS ECOSYSTEM: commerce, plan entitlements and secure payment ledger.
-- No client-facing role can mark an order paid or issue a license.

ALTER TABLE plans ADD COLUMN IF NOT EXISTS price_cents bigint CHECK (price_cents IS NULL OR price_cents >= 0);
ALTER TABLE plans ADD COLUMN IF NOT EXISTS currency text NOT NULL DEFAULT 'BRL' CHECK (currency = 'BRL');
ALTER TABLE plans ADD COLUMN IF NOT EXISTS app_id uuid REFERENCES apps(id) ON DELETE RESTRICT;
ALTER TABLE clients ADD COLUMN IF NOT EXISTS user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL;
CREATE UNIQUE INDEX IF NOT EXISTS clients_user_id_unique ON clients(user_id) WHERE user_id IS NOT NULL;

CREATE TABLE IF NOT EXISTS plan_features (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  plan_id uuid NOT NULL REFERENCES plans(id) ON DELETE CASCADE,
  feature_code text NOT NULL CHECK (feature_code ~ '^[a-z][a-z0-9_.-]{1,79}$'),
  enabled boolean NOT NULL DEFAULT true,
  UNIQUE(plan_id, feature_code)
);

CREATE TABLE IF NOT EXISTS payment_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE RESTRICT,
  client_id uuid REFERENCES clients(id) ON DELETE RESTRICT,
  plan_id uuid NOT NULL REFERENCES plans(id) ON DELETE RESTRICT,
  app_id uuid NOT NULL REFERENCES apps(id) ON DELETE RESTRICT,
  amount_cents bigint NOT NULL CHECK (amount_cents > 0),
  currency text NOT NULL DEFAULT 'BRL' CHECK (currency = 'BRL'),
  provider text NOT NULL DEFAULT 'pix' CHECK (provider = 'pix'),
  provider_payment_id text UNIQUE,
  provider_checkout_url text,
  pix_copy_paste text,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','paid','cancelled','expired','refunded','failed')),
  paid_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(id, user_id)
);

CREATE TABLE IF NOT EXISTS payment_webhook_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  provider text NOT NULL,
  provider_event_id text NOT NULL,
  order_id uuid REFERENCES payment_orders(id) ON DELETE SET NULL,
  payload_sha256 text NOT NULL CHECK (payload_sha256 ~ '^[0-9a-f]{64}$'),
  processed_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(provider, provider_event_id)
);

CREATE TABLE IF NOT EXISTS order_licenses (
  order_id uuid PRIMARY KEY REFERENCES payment_orders(id) ON DELETE RESTRICT,
  license_key_id uuid NOT NULL UNIQUE REFERENCES license_keys(id) ON DELETE RESTRICT,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE plan_features ENABLE ROW LEVEL SECURITY;
ALTER TABLE payment_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE payment_webhook_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE order_licenses ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON plan_features TO authenticated;
GRANT SELECT ON payment_orders TO authenticated;
GRANT SELECT ON order_licenses TO authenticated;
-- No authenticated/anon table access to webhook ledger.
REVOKE ALL ON payment_webhook_events FROM anon, authenticated;

DROP POLICY IF EXISTS admin_all_plan_features ON plan_features;
CREATE POLICY admin_all_plan_features ON plan_features FOR ALL TO authenticated
  USING (is_studio_admin()) WITH CHECK (is_studio_admin());
DROP POLICY IF EXISTS admin_all_payment_orders ON payment_orders;
CREATE POLICY admin_all_payment_orders ON payment_orders FOR ALL TO authenticated
  USING (is_studio_admin()) WITH CHECK (is_studio_admin());
DROP POLICY IF EXISTS buyer_read_own_payment_orders ON payment_orders;
CREATE POLICY buyer_read_own_payment_orders ON payment_orders FOR SELECT TO authenticated
  USING (user_id = auth.uid());
DROP POLICY IF EXISTS admin_all_order_licenses ON order_licenses;
CREATE POLICY admin_all_order_licenses ON order_licenses FOR ALL TO authenticated
  USING (is_studio_admin()) WITH CHECK (is_studio_admin());
DROP POLICY IF EXISTS buyer_read_own_order_licenses ON order_licenses;
CREATE POLICY buyer_read_own_order_licenses ON order_licenses FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM payment_orders o WHERE o.id = order_id AND o.user_id = auth.uid()));

-- Serialize activation allocation to enforce max_activations under concurrent requests.
CREATE OR REPLACE FUNCTION activate_license_atomic(
  p_license_key_id uuid, p_user_id uuid, p_installation_id text, p_device_label text
) RETURNS text LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_limit integer; v_count integer; v_existing activations%ROWTYPE;
BEGIN
  PERFORM pg_advisory_xact_lock(hashtextextended(p_license_key_id::text, 0));
  SELECT max_activations INTO v_limit FROM license_keys
    WHERE id = p_license_key_id AND status = 'active'
      AND (expires_at IS NULL OR expires_at > now()) AND revoked_at IS NULL;
  IF v_limit IS NULL THEN RAISE EXCEPTION 'license_unavailable'; END IF;
  SELECT * INTO v_existing FROM activations
    WHERE license_key_id = p_license_key_id AND installation_id = p_installation_id;
  IF FOUND THEN
    IF v_existing.user_id IS DISTINCT FROM p_user_id THEN RAISE EXCEPTION 'installation_bound'; END IF;
    UPDATE activations SET last_validated_at = now() WHERE id = v_existing.id;
    RETURN 'already_active';
  END IF;
  SELECT count(*) INTO v_count FROM activations WHERE license_key_id = p_license_key_id;
  IF v_count >= v_limit THEN RAISE EXCEPTION 'activation_limit'; END IF;
  INSERT INTO activations(license_key_id, user_id, installation_id, device_label, last_validated_at)
    VALUES (p_license_key_id, p_user_id, p_installation_id, p_device_label, now());
  RETURN 'activated';
END; $$;
REVOKE ALL ON FUNCTION activate_license_atomic(uuid,uuid,text,text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION activate_license_atomic(uuid,uuid,text,text) TO service_role;

-- Payment/order tables are written only by trusted Edge Functions using service_role.
REVOKE INSERT, UPDATE, DELETE ON payment_orders, order_licenses FROM authenticated;

CREATE TABLE IF NOT EXISTS license_deliveries (
  order_id uuid PRIMARY KEY REFERENCES payment_orders(id) ON DELETE RESTRICT,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE RESTRICT,
  encrypted_key text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  claimed_at timestamptz
);
ALTER TABLE license_deliveries ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON license_deliveries FROM PUBLIC, anon, authenticated;

ALTER TABLE app_optimizations ADD COLUMN IF NOT EXISTS feature_code text NOT NULL DEFAULT 'optimizer.basic'
  CHECK (feature_code ~ '^[a-z][a-z0-9_.-]{1,79}$');
