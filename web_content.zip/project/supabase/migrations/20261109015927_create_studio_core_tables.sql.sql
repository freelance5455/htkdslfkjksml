/*
# VT STUDIO core tables

1. New Tables
- `clients`: customers who receive licenses. Name, email, document, phone, company, notes and status (active or inactive).
- `apps`: application catalog. Name, package name, version, description and status (draft, published, archived).
- `app_customizations`: branding that the VT ACCESS app will read. One row per catalog app: display name, tagline, primary color, support email, welcome message.
- `license_keys`: individual activation KEYs. Stores only a SHA-256 hash of the key plus a short visible prefix. Each key belongs to one app, can be assigned to one client, has an optional expiry, a maximum number of installations and a status (active or revoked).
- `activations`: installations bound to a key. Each row is one device/installation identifier with a label and timestamps.
- `studio_settings`: single-row studio configuration (studio name, default key validity in days, default maximum installations).

2. Security
- Row level security is enabled on every table.
- Only administrators (checked with `is_studio_admin()`) can read or write these tables. Each policy is split into SELECT, INSERT, UPDATE and DELETE.
- Grants are given only to `authenticated`. The anon role has no access.
- Activations are created by the license validation service (server side, using the service role) in a later step; administrators can read and unbind them here.

3. Important Notes
- The full license key is never stored. Only its hash is kept, so a lost key must be revoked and replaced.
- Foreign keys prevent deleting an app or client that still has keys (restrict). Deleting a key removes its activations.
*/

CREATE TABLE IF NOT EXISTS clients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text,
  document text,
  phone text,
  company text,
  notes text,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS apps (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  package_name text NOT NULL UNIQUE,
  version text NOT NULL DEFAULT '1.0.0',
  description text,
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'published', 'archived')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS app_customizations (
  app_id uuid PRIMARY KEY REFERENCES apps(id) ON DELETE CASCADE,
  display_name text NOT NULL,
  tagline text,
  primary_color text NOT NULL DEFAULT '#8F001A' CHECK (primary_color ~ '^#[0-9A-Fa-f]{6}$'),
  support_email text,
  welcome_message text,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS license_keys (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key_hash text NOT NULL UNIQUE,
  key_prefix text NOT NULL,
  app_id uuid NOT NULL REFERENCES apps(id) ON DELETE RESTRICT,
  client_id uuid REFERENCES clients(id) ON DELETE RESTRICT,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'revoked')),
  max_activations integer NOT NULL DEFAULT 1 CHECK (max_activations > 0),
  expires_at timestamptz,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  revoked_at timestamptz
);

CREATE INDEX IF NOT EXISTS license_keys_app_id_idx ON license_keys (app_id);
CREATE INDEX IF NOT EXISTS license_keys_client_id_idx ON license_keys (client_id);

CREATE TABLE IF NOT EXISTS activations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  license_key_id uuid NOT NULL REFERENCES license_keys(id) ON DELETE CASCADE,
  installation_id text NOT NULL,
  device_label text,
  activated_at timestamptz NOT NULL DEFAULT now(),
  last_validated_at timestamptz,
  UNIQUE (license_key_id, installation_id)
);

CREATE TABLE IF NOT EXISTS studio_settings (
  id smallint PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  studio_name text NOT NULL DEFAULT 'VT STUDIO',
  default_validity_days integer CHECK (default_validity_days IS NULL OR default_validity_days > 0),
  default_max_activations integer NOT NULL DEFAULT 1 CHECK (default_max_activations > 0),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE clients ENABLE ROW LEVEL SECURITY;
ALTER TABLE apps ENABLE ROW LEVEL SECURITY;
ALTER TABLE app_customizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE license_keys ENABLE ROW LEVEL SECURITY;
ALTER TABLE activations ENABLE ROW LEVEL SECURITY;
ALTER TABLE studio_settings ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON clients TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON apps TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON app_customizations TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON license_keys TO authenticated;
GRANT SELECT, DELETE ON activations TO authenticated;
GRANT SELECT, INSERT, UPDATE ON studio_settings TO authenticated;

DROP POLICY IF EXISTS "admin_select_clients" ON clients;
CREATE POLICY "admin_select_clients" ON clients FOR SELECT TO authenticated USING (is_studio_admin());
DROP POLICY IF EXISTS "admin_insert_clients" ON clients;
CREATE POLICY "admin_insert_clients" ON clients FOR INSERT TO authenticated WITH CHECK (is_studio_admin());
DROP POLICY IF EXISTS "admin_update_clients" ON clients;
CREATE POLICY "admin_update_clients" ON clients FOR UPDATE TO authenticated USING (is_studio_admin()) WITH CHECK (is_studio_admin());
DROP POLICY IF EXISTS "admin_delete_clients" ON clients;
CREATE POLICY "admin_delete_clients" ON clients FOR DELETE TO authenticated USING (is_studio_admin());

DROP POLICY IF EXISTS "admin_select_apps" ON apps;
CREATE POLICY "admin_select_apps" ON apps FOR SELECT TO authenticated USING (is_studio_admin());
DROP POLICY IF EXISTS "admin_insert_apps" ON apps;
CREATE POLICY "admin_insert_apps" ON apps FOR INSERT TO authenticated WITH CHECK (is_studio_admin());
DROP POLICY IF EXISTS "admin_update_apps" ON apps;
CREATE POLICY "admin_update_apps" ON apps FOR UPDATE TO authenticated USING (is_studio_admin()) WITH CHECK (is_studio_admin());
DROP POLICY IF EXISTS "admin_delete_apps" ON apps;
CREATE POLICY "admin_delete_apps" ON apps FOR DELETE TO authenticated USING (is_studio_admin());

DROP POLICY IF EXISTS "admin_select_app_customizations" ON app_customizations;
CREATE POLICY "admin_select_app_customizations" ON app_customizations FOR SELECT TO authenticated USING (is_studio_admin());
DROP POLICY IF EXISTS "admin_insert_app_customizations" ON app_customizations;
CREATE POLICY "admin_insert_app_customizations" ON app_customizations FOR INSERT TO authenticated WITH CHECK (is_studio_admin());
DROP POLICY IF EXISTS "admin_update_app_customizations" ON app_customizations;
CREATE POLICY "admin_update_app_customizations" ON app_customizations FOR UPDATE TO authenticated USING (is_studio_admin()) WITH CHECK (is_studio_admin());
DROP POLICY IF EXISTS "admin_delete_app_customizations" ON app_customizations;
CREATE POLICY "admin_delete_app_customizations" ON app_customizations FOR DELETE TO authenticated USING (is_studio_admin());

DROP POLICY IF EXISTS "admin_select_license_keys" ON license_keys;
CREATE POLICY "admin_select_license_keys" ON license_keys FOR SELECT TO authenticated USING (is_studio_admin());
DROP POLICY IF EXISTS "admin_insert_license_keys" ON license_keys;
CREATE POLICY "admin_insert_license_keys" ON license_keys FOR INSERT TO authenticated WITH CHECK (is_studio_admin());
DROP POLICY IF EXISTS "admin_update_license_keys" ON license_keys;
CREATE POLICY "admin_update_license_keys" ON license_keys FOR UPDATE TO authenticated USING (is_studio_admin()) WITH CHECK (is_studio_admin());
DROP POLICY IF EXISTS "admin_delete_license_keys" ON license_keys;
CREATE POLICY "admin_delete_license_keys" ON license_keys FOR DELETE TO authenticated USING (is_studio_admin());

DROP POLICY IF EXISTS "admin_select_activations" ON activations;
CREATE POLICY "admin_select_activations" ON activations FOR SELECT TO authenticated USING (is_studio_admin());
DROP POLICY IF EXISTS "admin_delete_activations" ON activations;
CREATE POLICY "admin_delete_activations" ON activations FOR DELETE TO authenticated USING (is_studio_admin());

DROP POLICY IF EXISTS "admin_select_studio_settings" ON studio_settings;
CREATE POLICY "admin_select_studio_settings" ON studio_settings FOR SELECT TO authenticated USING (is_studio_admin());
DROP POLICY IF EXISTS "admin_insert_studio_settings" ON studio_settings;
CREATE POLICY "admin_insert_studio_settings" ON studio_settings FOR INSERT TO authenticated WITH CHECK (is_studio_admin());
DROP POLICY IF EXISTS "admin_update_studio_settings" ON studio_settings;
CREATE POLICY "admin_update_studio_settings" ON studio_settings FOR UPDATE TO authenticated USING (is_studio_admin()) WITH CHECK (is_studio_admin());

INSERT INTO studio_settings (id) VALUES (1) ON CONFLICT (id) DO NOTHING;
