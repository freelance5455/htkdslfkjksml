import { createClient } from "npm:@supabase/supabase-js@2";
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json" } });
Deno.serve(async req => {
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405);
  const token = req.headers.get("Authorization")?.replace(/^Bearer\s+/i, "");
  if (!token) return json({ error: "auth_required" }, 401);
  const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false } });
  const { data: auth, error: authError } = await admin.auth.getUser(token);
  if (authError || !auth.user) return json({ error: "invalid_session" }, 401);
  let body: any; try { body = await req.json(); } catch { return json({ error: "invalid_json" }, 400); }
  if (typeof body.plan_id !== "string") return json({ error: "plan_required" }, 400);
  const { data: plan, error: planError } = await admin.from("plans").select("id,price_cents,currency,status,app_id").eq("id", body.plan_id).single();
  if (planError || !plan || plan.status !== "active" || !plan.app_id || !plan.price_cents || plan.price_cents < 1) return json({ error: "plan_unavailable_or_unpriced" }, 422);
  const { data: app } = await admin.from("apps").select("id,status").eq("id", plan.app_id).single();
  if (!app || app.status !== "published") return json({ error: "app_unavailable" }, 422);
  let { data: client } = await admin.from("clients").select("id").eq("user_id", auth.user.id).maybeSingle();
  if (!client) {
    const customerName = String(auth.user.user_metadata?.full_name ?? auth.user.email ?? "Cliente VT").slice(0, 160);
    const { data: createdClient, error: clientError } = await admin.from("clients").insert({ user_id: auth.user.id, name: customerName, email: auth.user.email ?? null }).select("id").single();
    if (clientError || !createdClient) return json({ error: "customer_profile_creation_failed" }, 500);
    client = createdClient;
  }
  const { data: order, error: orderError } = await admin.from("payment_orders").insert({
    user_id: auth.user.id, client_id: client.id, plan_id: plan.id, app_id: plan.app_id,
    amount_cents: plan.price_cents, currency: plan.currency, status: "pending",
  }).select("id,amount_cents,currency,status,created_at").single();
  if (orderError || !order) return json({ error: "order_creation_failed" }, 500);

  // Generic adapter contract. A real provider adapter must be configured and tested before production.
  const providerUrl = Deno.env.get("PIX_PROVIDER_API_URL");
  const providerToken = Deno.env.get("PIX_PROVIDER_API_TOKEN");
  if (!providerUrl || !providerToken) return json({ order, payment: null, integration: "pending_provider_configuration", message: "Pedido criado. Configure o provedor PIX antes de cobrar o cliente." }, 202);
  try {
    const response = await fetch(providerUrl, {
      method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${providerToken}` },
      body: JSON.stringify({ reference_id: order.id, amount_cents: order.amount_cents, currency: order.currency, description: `VT ACCESS plano ${plan.id}` }),
    });
    if (!response.ok) throw new Error(`provider_http_${response.status}`);
    const payment = await response.json();
    if (typeof payment.payment_id !== "string" || typeof payment.copy_paste !== "string") throw new Error("provider_response_invalid");
    const { error: updateError } = await admin.from("payment_orders").update({ provider_payment_id: payment.payment_id, pix_copy_paste: payment.copy_paste, provider_checkout_url: typeof payment.checkout_url === "string" ? payment.checkout_url : null, updated_at: new Date().toISOString() }).eq("id", order.id);
    if (updateError) throw updateError;
    return json({ order, payment: { payment_id: payment.payment_id, copy_paste: payment.copy_paste, checkout_url: payment.checkout_url ?? null } }, 201);
  } catch (error) {
    console.error("PIX provider adapter failed", error);
    await admin.from("payment_orders").update({ status: "failed", updated_at: new Date().toISOString() }).eq("id", order.id);
    return json({ error: "pix_provider_unavailable", order_id: order.id }, 502);
  }
});
