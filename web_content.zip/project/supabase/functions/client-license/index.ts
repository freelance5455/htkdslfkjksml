import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const RELEASE_BUCKET = "app-releases";
const DOWNLOAD_TTL_SECONDS = 300;
const INSTALLATION_PATTERN = /^[A-Za-z0-9-]{8,64}$/;

class ClientError extends Error {}

function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

async function sha256Hex(text: string): Promise<string> {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
}

function requireInstallation(value: unknown): string {
  if (typeof value !== "string" || !INSTALLATION_PATTERN.test(value)) {
    throw new ClientError("Instalação inválida.");
  }
  return value;
}

function isLicenseUsable(license: { status: string; revoked_at: string | null; expires_at: string | null }): boolean {
  if (license.status !== "active" || license.revoked_at) return false;
  return !license.expires_at || new Date(license.expires_at).getTime() > Date.now();
}

type Admin = ReturnType<typeof createClient>;

interface LicenseRow {
  id: string;
  app_id: string;
  status: string;
  max_activations: number;
  expires_at: string | null;
  revoked_at: string | null;
}

interface ActivationRow {
  id: string;
  license_key_id: string;
  user_id: string | null;
  installation_id: string;
  activated_at: string;
  license_keys: LicenseRow & { apps: { status: string } | null };
}

async function activate(admin: Admin, userId: string, body: Record<string, unknown>) {
  const installationId = requireInstallation(body.installation_id);
  const deviceLabel = typeof body.device_label === "string" ? body.device_label.slice(0, 80) : null;
  if (typeof body.key !== "string" || body.key.trim() === "") throw new ClientError("Informe a KEY.");

  const keyHash = await sha256Hex(body.key.replace(/\s+/g, "").toUpperCase());
  const { data: license, error: licenseErr } = await admin
    .from("license_keys")
    .select("id, app_id, status, max_activations, expires_at, revoked_at")
    .eq("key_hash", keyHash)
    .maybeSingle<LicenseRow>();
  if (licenseErr) throw licenseErr;
  if (!license || !isLicenseUsable(license)) throw new ClientError("KEY inválida, revogada ou expirada.");

  const { data: app, error: appErr } = await admin
    .from("apps")
    .select("status")
    .eq("id", license.app_id)
    .maybeSingle<{ status: string }>();
  if (appErr) throw appErr;
  if (!app || app.status !== "published") throw new ClientError("Este aplicativo não está disponível.");

  const { data: activationStatus, error: activationErr } = await admin.rpc("activate_license_atomic", {
    p_license_key_id: license.id,
    p_user_id: userId,
    p_installation_id: installationId,
    p_device_label: deviceLabel,
  });
  if (activationErr) {
    const message = activationErr.message.includes("activation_limit")
      ? "Limite de instalações desta KEY atingido."
      : activationErr.message.includes("installation_bound")
        ? "Esta instalação já está vinculada a outra conta."
        : "Não foi possível ativar esta KEY.";
    throw new ClientError(message);
  }
  return { status: activationStatus, app_id: license.app_id };
}

async function status(admin: Admin, userId: string) {
  const { data, error } = await admin
    .from("activations")
    .select("id, license_key_id, user_id, installation_id, activated_at, license_keys(id, app_id, status, max_activations, expires_at, revoked_at, apps(status))")
    .eq("user_id", userId)
    .order("activated_at", { ascending: false })
    .returns<ActivationRow[]>();
  if (error) throw error;

  const licenses = (data ?? []).map((row) => ({
    activation_id: row.id,
    app_id: row.license_keys.app_id,
    installation_id: row.installation_id,
    activated_at: row.activated_at,
    expires_at: row.license_keys.expires_at,
    active: isLicenseUsable(row.license_keys) && row.license_keys.apps?.status === "published",
  }));
  return { licenses };
}

async function apps(admin: Admin, userId: string) {
  const { data: rows, error: rowsErr } = await admin
    .from("activations")
    .select("installation_id, license_keys!inner(app_id, status, revoked_at, expires_at, apps!inner(id, name, version, description, status))")
    .eq("user_id", userId)
    .returns<{
      installation_id: string;
      license_keys: { app_id: string; status: string; revoked_at: string | null; expires_at: string | null; apps: { id: string; name: string; version: string; description: string | null; status: string } };
    }[]>();
  if (rowsErr) throw rowsErr;

  const granted = new Map<string, { id: string; name: string; version: string; description: string | null }>();
  for (const row of rows ?? []) {
    const license = row.license_keys;
    if (!isLicenseUsable(license) || license.apps.status !== "published") continue;
    granted.set(license.apps.id, { id: license.apps.id, name: license.apps.name, version: license.apps.version, description: license.apps.description });
  }

  const appIds = [...granted.keys()];
  if (appIds.length === 0) return { apps: [] };

  const { data: releases, error: releasesErr } = await admin
    .from("app_releases")
    .select("app_id, version")
    .in("app_id", appIds)
    .eq("is_current", true)
    .returns<{ app_id: string; version: string }[]>();
  if (releasesErr) throw releasesErr;

  const releaseByApp = new Map((releases ?? []).map((release) => [release.app_id, release.version]));
  return {
    apps: appIds.map((id) => {
      const app = granted.get(id)!;
      return { ...app, release_version: releaseByApp.get(id) ?? null };
    }),
  };
}

async function assertEntitled(admin: Admin, userId: string, installationId: string, appId: unknown): Promise<void> {
  if (typeof appId !== "string") throw new ClientError("Aplicativo inválido.");

  const { data: rows, error: rowsErr } = await admin
    .from("activations")
    .select("license_keys!inner(app_id, status, revoked_at, expires_at)")
    .eq("user_id", userId)
    .eq("installation_id", installationId)
    .returns<{ license_keys: { app_id: string; status: string; revoked_at: string | null; expires_at: string | null } }[]>();
  if (rowsErr) throw rowsErr;

  const entitled = (rows ?? []).some((row) => row.license_keys.app_id === appId && isLicenseUsable(row.license_keys));
  if (!entitled) throw new ClientError("Você não tem acesso a este aplicativo nesta instalação.");
}

async function optimizations(admin: Admin, userId: string, body: Record<string, unknown>) {
  const installationId = requireInstallation(body.installation_id);
  await assertEntitled(admin, userId, installationId, body.app_id);

  const entitlement = await features(admin, userId, body);
  const { data, error } = await admin
    .from("app_optimizations")
    .select("id, name, description, feature_code")
    .eq("app_id", body.app_id as string)
    .eq("enabled", true)
    .order("name")
    .returns<{ id: string; name: string; description: string | null; feature_code: string }[]>();
  if (error) throw error;
  const allowed = entitlement.features;
  return { optimizations: (data ?? []).filter(item => allowed.length === 0 || allowed.includes(item.feature_code)) };
}

async function features(admin: Admin, userId: string, body: Record<string, unknown>) {
  const installationId = requireInstallation(body.installation_id);
  if (typeof body.app_id !== "string") throw new ClientError("Aplicativo inválido.");
  const { data: activations, error: activationError } = await admin
    .from("activations")
    .select("license_key_id, license_keys!inner(app_id,status,revoked_at,expires_at)")
    .eq("user_id", userId)
    .eq("installation_id", installationId)
    .returns<{ license_key_id: string; license_keys: { app_id: string; status: string; revoked_at: string | null; expires_at: string | null } }[]>();
  if (activationError) throw activationError;
  const licenseIds = (activations ?? []).filter(row => row.license_keys.app_id === body.app_id && isLicenseUsable(row.license_keys)).map(row => row.license_key_id);
  if (!licenseIds.length) throw new ClientError("Licença não ativa para este aplicativo.");
  const { data: links, error: linkError } = await admin.from("order_licenses").select("order_id").in("license_key_id", licenseIds);
  if (linkError) throw linkError;
  const orderIds = (links ?? []).map(row => row.order_id);
  if (!orderIds.length) return { features: [] };
  const { data: orders, error: orderError } = await admin.from("payment_orders").select("plan_id").in("id", orderIds).eq("status", "paid");
  if (orderError) throw orderError;
  const planIds = [...new Set((orders ?? []).map(row => row.plan_id))];
  if (!planIds.length) return { features: [] };
  const { data, error } = await admin.from("plan_features").select("feature_code,enabled").in("plan_id", planIds).eq("enabled", true);
  if (error) throw error;
  return { features: [...new Set((data ?? []).map(row => row.feature_code))] };
}

async function download(admin: Admin, userId: string, body: Record<string, unknown>) {
  const installationId = requireInstallation(body.installation_id);
  await assertEntitled(admin, userId, installationId, body.app_id);
  const entitlement = await features(admin, userId, body);
  if (entitlement.features.length > 0 && !entitlement.features.includes("app.download")) {
    throw new ClientError("Seu plano não inclui download de aplicativos.");
  }

  const { data: release, error: releaseErr } = await admin
    .from("app_releases")
    .select("storage_path, file_name, checksum_sha256, version")
    .eq("app_id", body.app_id)
    .eq("is_current", true)
    .maybeSingle<{ storage_path: string; file_name: string; checksum_sha256: string; version: string }>();
  if (releaseErr) throw releaseErr;
  if (!release) throw new ClientError("Nenhum arquivo disponível para este aplicativo.");

  const { data: signed, error: signedErr } = await admin.storage
    .from(RELEASE_BUCKET)
    .createSignedUrl(release.storage_path, DOWNLOAD_TTL_SECONDS);
  if (signedErr || !signed?.signedUrl) throw signedErr ?? new Error("signed url missing");

  return {
    url: signed.signedUrl,
    file_name: release.file_name,
    version: release.version,
    checksum_sha256: release.checksum_sha256,
    expires_in: DOWNLOAD_TTL_SECONDS,
  };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 200, headers: corsHeaders });

  try {
    const token = req.headers.get("Authorization")?.replace(/^Bearer\s+/i, "");
    if (!token) return json({ error: "Sessão necessária." }, 401);

    const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, {
      auth: { persistSession: false, autoRefreshToken: false },
    });

    const { data: userData, error: userErr } = await admin.auth.getUser(token);
    if (userErr || !userData.user) return json({ error: "Sessão inválida. Entre novamente." }, 401);
    const userId = userData.user.id;

    const body = req.method === "POST" ? ((await req.json()) as Record<string, unknown>) : {};
    const action = body.action;

    if (action === "activate") return json(await activate(admin, userId, body));
    if (action === "status") return json(await status(admin, userId));
    if (action === "apps") return json(await apps(admin, userId));
    if (action === "download") return json(await download(admin, userId, body));
    if (action === "optimizations") return json(await optimizations(admin, userId, body));
    if (action === "features") return json(await features(admin, userId, body));
    return json({ error: "Ação inválida." }, 400);
  } catch (caught) {
    if (caught instanceof ClientError) return json({ error: caught.message }, 422);
    console.error("client-license failed", caught);
    return json({ error: "Não foi possível concluir a operação. Tente novamente." }, 500);
  }
});
