import { createClient } from "npm:@supabase/supabase-js@2";
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json" } });
function fromHex(value: string) { const out = new Uint8Array(value.length / 2); for (let i=0;i<out.length;i++) out[i]=parseInt(value.slice(i*2,i*2+2),16); return out; }
async function decryptKey(value: string): Promise<string> {
  const secret = Deno.env.get("LICENSE_DELIVERY_ENCRYPTION_SECRET"); if (!secret) throw new Error("delivery secret missing");
  const raw = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(secret));
  const aes = await crypto.subtle.importKey("raw", raw, "AES-GCM", false, ["decrypt"]);
  const [iv, cipher] = value.split(".");
  return new TextDecoder().decode(await crypto.subtle.decrypt({ name: "AES-GCM", iv: fromHex(iv) }, aes, fromHex(cipher)));
}
Deno.serve(async req => {
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405);
  const token = req.headers.get("Authorization")?.replace(/^Bearer\s+/i, ""); if (!token) return json({ error: "auth_required" }, 401);
  const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false } });
  const { data: auth, error: authError } = await admin.auth.getUser(token);
  if (authError || !auth.user) return json({ error: "invalid_session" }, 401);
  const { data: delivery, error } = await admin.from("license_deliveries").select("order_id,encrypted_key").eq("user_id", auth.user.id).is("claimed_at", null).order("created_at", { ascending: true }).limit(1).maybeSingle();
  if (error) return json({ error: "delivery_lookup_failed" }, 500);
  if (!delivery) return json({ license_key: null, message: "Nenhuma KEY pendente." });
  const { data: claimed, error: claimError } = await admin.from("license_deliveries").update({ claimed_at: new Date().toISOString() }).eq("order_id", delivery.order_id).eq("user_id", auth.user.id).is("claimed_at", null).select("order_id").maybeSingle();
  if (claimError || !claimed) return json({ error: "already_claimed" }, 409);
  try { return json({ order_id: delivery.order_id, license_key: await decryptKey(delivery.encrypted_key) }); }
  catch { await admin.from("license_deliveries").update({ claimed_at: null }).eq("order_id", delivery.order_id); return json({ error: "delivery_decryption_failed" }, 500); }
});
