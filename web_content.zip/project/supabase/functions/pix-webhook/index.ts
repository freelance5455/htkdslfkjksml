import { createClient } from "npm:@supabase/supabase-js@2";

const hex = (bytes: Uint8Array) => Array.from(bytes, b => b.toString(16).padStart(2, "0")).join("");
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json" } });

async function hmacHex(secret: string, body: string): Promise<string> {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return hex(new Uint8Array(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(body))));
}
function safeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let out = 0; for (let i = 0; i < a.length; i++) out |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return out === 0;
}
async function sha256(value: string) { return hex(new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value)))); }
async function encryptKey(key: string): Promise<string> {
  const secret = Deno.env.get("LICENSE_DELIVERY_ENCRYPTION_SECRET");
  if (!secret) throw new Error("LICENSE_DELIVERY_ENCRYPTION_SECRET missing");
  const raw = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(secret));
  const aes = await crypto.subtle.importKey("raw", raw, "AES-GCM", false, ["encrypt"]);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const cipher = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv }, aes, new TextEncoder().encode(key)));
  return `${hex(iv)}.${hex(cipher)}`;
}
function makeKey() {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const bytes = crypto.getRandomValues(new Uint8Array(32));
  const segments = Array.from({ length: 8 }, (_, index) =>
    Array.from(bytes.slice(index * 4, index * 4 + 4), byte => alphabet[byte & 31]).join("")
  );
  return ["VT", ...segments].join("-");
}

// Provider adapter contract: provider must send x-vt-signature: sha256=<HMAC-SHA256(raw body)>.
// Configure PIX_WEBHOOK_HMAC_SECRET only after mapping the actual provider's signed webhook format.
Deno.serve(async (req) => {
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405);
  const secret = Deno.env.get("PIX_WEBHOOK_HMAC_SECRET");
  if (!secret) return json({ error: "webhook_not_configured" }, 503);
  if (!Deno.env.get("LICENSE_DELIVERY_ENCRYPTION_SECRET")) return json({ error: "license_delivery_not_configured" }, 503);
  const raw = await req.text();
  const supplied = (req.headers.get("x-vt-signature") ?? "").replace(/^sha256=/i, "").toLowerCase();
  const expected = await hmacHex(secret, raw);
  if (!safeEqual(supplied, expected)) return json({ error: "invalid_signature" }, 401);

  let event: any;
  try { event = JSON.parse(raw); } catch { return json({ error: "invalid_json" }, 400); }
  const eventId = typeof event.event_id === "string" ? event.event_id : "";
  const orderId = typeof event.order_id === "string" ? event.order_id : "";
  const paymentStatus = event.status;
  if (!eventId || !orderId || !["paid", "cancelled", "expired", "refunded", "failed"].includes(paymentStatus)) return json({ error: "invalid_event" }, 400);

  const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false } });
  const { data: order, error: orderError } = await admin.from("payment_orders").select("*").eq("id", orderId).maybeSingle();
  if (orderError || !order) return json({ error: "order_not_found" }, 404);
  if (Number(event.amount_cents) !== Number(order.amount_cents) || event.currency !== order.currency) return json({ error: "amount_mismatch" }, 422);
  if (event.provider_payment_id && order.provider_payment_id && event.provider_payment_id !== order.provider_payment_id) return json({ error: "payment_reference_mismatch" }, 422);

  const { error: eventError } = await admin.from("payment_webhook_events").insert({
    provider: "pix", provider_event_id: eventId, order_id: order.id, payload_sha256: await sha256(raw),
  });
  if (eventError?.code === "23505") return json({ received: true, duplicate: true });
  if (eventError) return json({ error: "event_store_failed" }, 500);

  if (paymentStatus !== "paid") {
    if (order.status === "pending") await admin.from("payment_orders").update({ status: paymentStatus, updated_at: new Date().toISOString() }).eq("id", order.id);
    return json({ received: true, status: paymentStatus });
  }
  if (order.status === "paid") return json({ received: true, already_paid: true });
  if (order.status !== "pending") return json({ error: "order_not_payable" }, 409);

  const { data: plan, error: planError } = await admin.from("plans").select("validity_days,max_activations,status,app_id").eq("id", order.plan_id).single();
  if (planError || plan.status !== "active" || plan.app_id !== order.app_id) return json({ error: "plan_unavailable" }, 409);
  const key = makeKey();
  const keyHash = await sha256(key.replace(/\s+/g, "").toUpperCase());
  const expiresAt = plan.validity_days ? new Date(Date.now() + Number(plan.validity_days) * 86400000).toISOString() : null;

  // Claim order once. If another event races, the unique order_licenses key prevents a second license.
  const { data: claimed, error: claimError } = await admin.from("payment_orders").update({ status: "paid", paid_at: new Date().toISOString(), updated_at: new Date().toISOString() }).eq("id", order.id).eq("status", "pending").select("id").maybeSingle();
  if (claimError || !claimed) return json({ error: "order_already_processed" }, 409);
  const { data: license, error: licenseError } = await admin.from("license_keys").insert({
    key_hash: keyHash, key_prefix: key.split("-").slice(0, 2).join("-"), app_id: order.app_id, status: "active",
    client_id: order.client_id, max_activations: plan.max_activations, expires_at: expiresAt, notes: `Pedido PIX ${order.id}`,
  }).select("id").single();
  if (licenseError || !license) {
    await admin.from("payment_orders").update({ status: "pending", paid_at: null }).eq("id", order.id);
    await admin.from("payment_webhook_events").delete().eq("provider", "pix").eq("provider_event_id", eventId);
    return json({ error: "license_issue_failed" }, 500);
  }
  const { error: linkError } = await admin.from("order_licenses").insert({ order_id: order.id, license_key_id: license.id });
  const encryptedKey = await encryptKey(key);
  const { error: deliveryError } = await admin.from("license_deliveries").insert({ order_id: order.id, user_id: order.user_id, encrypted_key: encryptedKey });
  if (linkError || deliveryError) {
    await admin.from("license_deliveries").delete().eq("order_id", order.id);
    await admin.from("order_licenses").delete().eq("order_id", order.id);
    await admin.from("license_keys").delete().eq("id", license.id);
    await admin.from("payment_orders").update({ status: "pending", paid_at: null }).eq("id", order.id);
    await admin.from("payment_webhook_events").delete().eq("provider", "pix").eq("provider_event_id", eventId);
    return json({ error: "license_delivery_setup_failed" }, 500);
  }
  // The clear KEY is never returned to the payment provider or persisted in plaintext.
  return json({ received: true, status: "paid", order_id: order.id, license_created: true });
});
