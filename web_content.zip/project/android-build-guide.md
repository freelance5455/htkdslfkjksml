# CONGOLO para Android (Capacitor)

Este proyecto es un preparativo para empaquetar CONGOLO como APK. No contiene aún un APK compilado ni la integración de la app móvil con el backend remoto.

## Requisitos
- Node.js LTS
- Android Studio y Android SDK
- Un equipo Windows/Linux/macOS para generar el APK (Android Studio no se ejecuta de forma práctica en la mayoría de teléfonos Android).

## Pasos
1. Instala Node.js y Android Studio.
2. En esta carpeta ejecuta `npm install`.
3. Añade Capacitor: `npm install @capacitor/core @capacitor/cli @capacitor/android`.
4. Inicializa si necesario: `npx cap add android`.
5. El frontend está en `public`; configura la app para usar el backend desplegado (URL HTTPS) antes de empaquetar. La versión actual usa rutas relativas `/api` y Socket.IO en el mismo origen, por lo que aún no funcionará en un APK offline sin esta adaptación.
6. Ejecuta `npx cap sync android` y `npx cap open android`.
7. En Android Studio: Build > Build APK(s). El APK de debug aparecerá bajo `android/app/build/outputs/apk/debug/`.

## Importante
- Aún no está compilado ni probado en dispositivo.
- No subas credenciales al código.
- El backend debe alojarse con HTTPS y soporte Socket.IO/WebSockets.
