# VT ACCESS ECOSYSTEM — continuação incremental

Este pacote preserva os projetos existentes `src/` (VT STUDIO) e `android/` (VT ACCESS), acrescentando migração de comércio/licenças, Edge Functions, tela de pagamentos, preços e recursos por plano, sons do painel e um segundo projeto Android independente em `android-vt-optimizer/`.

## O que está implementado no código

- VT STUDIO preservado; menu Pagamentos e listagem somente leitura de pedidos.
- Cadastro de preço em centavos e vínculo do plano com um aplicativo publicado.
- Cadastro de códigos de recursos liberados por plano e associação de cada otimização a um código de recurso.
- Endpoint backend para criar pedido PIX a partir do plano e do preço lidos no servidor.
- Webhook com verificação HMAC sobre o corpo bruto, idempotência por evento, conferência de valor/moeda, criação de KEY aleatória e associação pedido → plano → app → cliente → licença.
- KEY armazenada por hash na tabela de licenças e criptografada na caixa privada de entrega; endpoint autenticado de resgate de KEY.
- Ativação de licença com RPC transacional/advisory lock para respeitar limite de dispositivos em requisições concorrentes.
- Resposta backend para recursos do plano e filtragem de otimizações/download conforme os códigos habilitados.
- Segundo projeto Gradle independente `android-vt-optimizer/`, com namespace e applicationId `com.vtstudio.optimizer`.
- Controle de sons no VT STUDIO; VT ACCESS já tinha preferência e sons de clique e estes foram preservados no segundo APK copiado.

## Ainda depende de configuração ou implementação externa

- **Provedor PIX:** ainda não foi escolhido. `create-pix-order` usa um contrato de adaptador genérico, não uma integração certificada com um provedor específico. Implementar o mapeamento da API real, configurar credenciais e testar em sandbox.
- **Webhook PIX:** adaptar o formato de assinatura oficial do provedor ao contrato HMAC normalizado descrito em `docs/PIX_PROVIDER_SETUP.md`. Não habilitar cobrança em produção antes dessa validação.
- **Supabase:** aplicar todas as migrations em `supabase/migrations/`, configurar secrets e publicar as Edge Functions `client-license`, `create-pix-order`, `pix-webhook` e `claim-license`.
- **Entrega de KEY:** o backend já disponibiliza resgate autenticado de KEY, mas falta ligar o fluxo de compra/resgate às telas do cliente Android e à tela de histórico do cliente.
- **Handoff entre APKs:** o segundo app é projeto separado, mas ainda falta implementar código de troca de uso único entre VT ACCESS e VT OPTIMIZER, vinculado a usuário, licença, dispositivo e validade. Não enviar tokens de sessão em Intent ou clipboard.
- **Validação no segundo APK:** adicionar verificação de licença obrigatória no início, retorno ao foreground e antes de cada recurso, incluindo revogação remota.
- **Otimização real / Brevent:** permanece pendente. Não há comandos de otimização reais executados nesta versão; nenhuma ação deve ser apresentada como concluída. Integrar apenas ações suportadas pelo Android e pelo Brevent, com consentimento e permissões explícitas.
- **Assinatura dos APKs:** configurar keystore de release, versionamento, testes em aparelhos e distribuição. Nenhum APK assinado foi gerado neste ambiente.
- **Recursos por plano:** os códigos e verificações backend estão implementados; criar uma matriz de códigos oficial e testes por plano antes da publicação.

## Secrets de backend

Veja `docs/PIX_PROVIDER_SETUP.md`. `SUPABASE_SERVICE_ROLE_KEY`, token do provedor PIX, segredo HMAC e segredo de criptografia nunca devem entrar no `.env` do Vite, no frontend, no repositório público ou em APK.

## Verificação desta entrega

O ambiente de execução não conseguiu completar `npm ci` (dependências não ficaram instaladas), portanto `npm run typecheck`, `npm run build` e ESLint não puderam ser concluídos. Não havia Gradle/Android SDK disponível para compilar os APKs. As alterações foram feitas no código-fonte e precisam passar por CI e testes Supabase/Android antes de produção.
