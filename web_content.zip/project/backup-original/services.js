const SERVICE_STORAGE_KEYS = {
    appointments: 'ccsjdm_appointments',
    tickets: 'ccsjdm_queue_tickets',
    queueState: 'ccsjdm_queue_state',
    notifications: 'ccsjdm_notifications'
};

const QUEUE_STATUS = {
    waiting: 'Waiting',
    almost: 'Almost Your Turn',
    called: 'Called',
    serving: 'Serving',
    completed: 'Completed',
    missed: 'Missed',
    cancelled: 'Cancelled'
};

const APPOINTMENT_STATUS = {
    confirmed: 'Confirmed',
    checkedIn: 'Checked In',
    completed: 'Completed',
    cancelled: 'Cancelled',
    missed: 'Missed'
};

const WEEKDAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

const SERVICE_OFFICES = [
    {
        id: 'registrar',
        prefix: 'R',
        name: 'Office of the Registrar',
        shortName: 'Registrar',
        icon: '&#128220;',
        tagline: 'Records, enrolment, and official documents',
        description: 'Handles student records, enrolment concerns, and requests for official academic documents such as transcripts, certifications, and form copies.',
        location: 'Ground Floor, Administration Building',
        room: 'Room A-101',
        days: [1, 2, 3, 4, 5],
        openTime: '08:00',
        closeTime: '17:00',
        breakStart: '12:00',
        breakEnd: '13:00',
        queueEnabled: true,
        averageServiceMinutes: 9,
        dailyQueueLimit: 60,
        contact: 'registrar@ccsjdm.edu.ph',
        services: [
            {
                id: 'registrar-tor',
                name: 'Request Transcript of Records',
                mode: 'appointment',
                processingTime: '5 to 7 working days',
                description: 'Official transcript for employment, board examinations, or transfer to another school.',
                requirements: [
                    'Valid school ID or any government-issued ID',
                    'Accomplished document request form',
                    'Official receipt of payment from the Cashier',
                    'Authorisation letter if claimed by a representative'
                ]
            },
            {
                id: 'registrar-cor',
                name: 'Certificate of Registration Copy',
                mode: 'both',
                processingTime: 'Same day',
                description: 'Reprint of your Certificate of Registration for the current term.',
                requirements: [
                    'Valid school ID',
                    'Student number',
                    'Official receipt of payment from the Cashier'
                ]
            },
            {
                id: 'registrar-goodmoral',
                name: 'Certification, Authentication and Verification',
                mode: 'appointment',
                processingTime: '3 working days',
                description: 'Certification of enrolment, units earned, graduation, or English as medium of instruction.',
                requirements: [
                    'Valid school ID',
                    'Accomplished request form indicating the purpose',
                    'Official receipt of payment from the Cashier'
                ]
            },
            {
                id: 'registrar-enrolment',
                name: 'Enrolment and Subject Concern',
                mode: 'queue',
                processingTime: 'Same day',
                description: 'Assistance for adding, dropping, or correcting subjects and sections.',
                requirements: [
                    'Valid school ID',
                    'Printed Certificate of Registration',
                    'Adviser or Program Head approval slip'
                ]
            }
        ]
    },
    {
        id: 'clinic',
        prefix: 'C',
        name: 'Medical and Dental Clinic',
        shortName: 'Clinic',
        icon: '&#127973;',
        tagline: 'Medical, dental, and health clearance services',
        description: 'Provides basic medical consultation, dental services, first aid, and medical clearance for school activities and internships.',
        location: 'Second Floor, Student Center',
        room: 'Room S-204',
        days: [1, 2, 3, 4, 5],
        openTime: '08:00',
        closeTime: '16:00',
        breakStart: '12:00',
        breakEnd: '13:00',
        queueEnabled: true,
        averageServiceMinutes: 12,
        dailyQueueLimit: 40,
        contact: 'clinic@ccsjdm.edu.ph',
        services: [
            {
                id: 'clinic-consult',
                name: 'Medical Consultation',
                mode: 'queue',
                processingTime: '10 to 15 minutes',
                description: 'Consultation for fever, headache, stomach pain, injuries, and other immediate health concerns.',
                requirements: [
                    'Valid school ID',
                    'Brief description of your symptoms',
                    'List of medicines you are currently taking, if any'
                ]
            },
            {
                id: 'clinic-dental',
                name: 'Dental Check-up',
                mode: 'appointment',
                processingTime: '20 to 30 minutes',
                description: 'Routine dental examination, cleaning advice, and tooth extraction referral.',
                requirements: [
                    'Valid school ID',
                    'Previous dental record, if available'
                ]
            },
            {
                id: 'clinic-certificate',
                name: 'Medical Certificate and Clearance',
                mode: 'both',
                processingTime: '1 to 2 working days',
                description: 'Medical clearance for internship, intramurals, field trips, and organisation activities.',
                requirements: [
                    'Valid school ID',
                    'Letter or endorsement from your department',
                    'Result of recent medical examination, if required'
                ]
            }
        ]
    },
    {
        id: 'guidance',
        prefix: 'G',
        name: 'Guidance and Counseling Office',
        shortName: 'Guidance',
        icon: '&#129504;',
        tagline: 'Counseling, good moral, and career guidance',
        description: 'Offers confidential counseling, career and academic guidance, good moral certification, and student wellbeing programmes.',
        location: 'Second Floor, Administration Building',
        room: 'Room A-210',
        days: [1, 2, 3, 4, 5],
        openTime: '08:00',
        closeTime: '17:00',
        breakStart: '12:00',
        breakEnd: '13:00',
        queueEnabled: false,
        averageServiceMinutes: 30,
        dailyQueueLimit: 0,
        contact: 'guidance@ccsjdm.edu.ph',
        services: [
            {
                id: 'guidance-counseling',
                name: 'Personal Counseling Session',
                mode: 'appointment',
                processingTime: '30 to 45 minutes',
                description: 'A private and confidential session with a licensed guidance counselor.',
                requirements: [
                    'Valid school ID',
                    'Short description of your concern, kept confidential'
                ]
            },
            {
                id: 'guidance-goodmoral',
                name: 'Good Moral Certificate',
                mode: 'both',
                processingTime: '2 to 3 working days',
                description: 'Certification of good moral character for transfer, employment, or scholarship application.',
                requirements: [
                    'Valid school ID',
                    'Official receipt of payment from the Cashier',
                    'Clearance from the Office of Student Affairs'
                ]
            },
            {
                id: 'guidance-career',
                name: 'Career and Academic Guidance',
                mode: 'appointment',
                processingTime: '30 minutes',
                description: 'Guidance on shifting programmes, study habits, internship readiness, and career planning.',
                requirements: [
                    'Valid school ID',
                    'Copy of your latest grades, if the concern is academic'
                ]
            }
        ]
    },
    {
        id: 'quality-assurance',
        prefix: 'Q',
        name: 'Quality Assurance Office',
        shortName: 'Quality Assurance',
        icon: '&#9989;',
        tagline: 'Feedback, document verification, and accreditation',
        description: 'Receives student feedback and complaints, verifies the authenticity of school-issued documents, and manages accreditation surveys.',
        location: 'Third Floor, Administration Building',
        room: 'Room A-305',
        days: [1, 2, 3, 4, 5],
        openTime: '08:00',
        closeTime: '17:00',
        breakStart: '12:00',
        breakEnd: '13:00',
        queueEnabled: true,
        averageServiceMinutes: 10,
        dailyQueueLimit: 30,
        contact: 'qao@ccsjdm.edu.ph',
        services: [
            {
                id: 'qa-feedback',
                name: 'File Feedback or Complaint',
                mode: 'both',
                processingTime: '3 to 5 working days',
                description: 'Formal channel for service complaints, suggestions, and commendations about any office or facility.',
                requirements: [
                    'Valid school ID',
                    'Written narration of the concern with date and place',
                    'Supporting evidence such as a photo or receipt, if available'
                ]
            },
            {
                id: 'qa-verification',
                name: 'Document Verification',
                mode: 'queue',
                processingTime: 'Same day',
                description: 'Verification and authentication of certificates and documents issued by the college.',
                requirements: [
                    'Valid school ID',
                    'Original copy of the document to be verified',
                    'Photocopy of the document'
                ]
            },
            {
                id: 'qa-survey',
                name: 'Accreditation Survey Assistance',
                mode: 'appointment',
                processingTime: '20 minutes',
                description: 'Assistance for students invited as respondents or student representatives during accreditation visits.',
                requirements: [
                    'Valid school ID',
                    'Invitation or endorsement from your department'
                ]
            }
        ]
    },
    {
        id: 'student-affairs',
        prefix: 'S',
        name: 'Office of Student Affairs and Services',
        shortName: 'Student Affairs',
        icon: '&#127891;',
        tagline: 'Organisations, scholarships, and student welfare',
        description: 'Supervises student organisations, scholarship assistance, student discipline, identification cards, and campus activity permits.',
        location: 'Ground Floor, Student Center',
        room: 'Room S-105',
        days: [1, 2, 3, 4, 5],
        openTime: '08:00',
        closeTime: '17:00',
        breakStart: '12:00',
        breakEnd: '13:00',
        queueEnabled: true,
        averageServiceMinutes: 8,
        dailyQueueLimit: 50,
        contact: 'osas@ccsjdm.edu.ph',
        services: [
            {
                id: 'osas-scholarship',
                name: 'Scholarship and Financial Assistance',
                mode: 'both',
                processingTime: '3 to 5 working days',
                description: 'Application, renewal, and follow-up for government and institutional scholarship grants.',
                requirements: [
                    'Valid school ID',
                    'Certificate of Registration for the current term',
                    'Latest grade report',
                    'Barangay certificate of indigency, for assistance grants'
                ]
            },
            {
                id: 'osas-id',
                name: 'Student ID Concern',
                mode: 'queue',
                processingTime: 'Same day to 3 working days',
                description: 'Application, replacement, or correction of the official student identification card.',
                requirements: [
                    'Affidavit of loss, for replacement',
                    'Official receipt of payment from the Cashier',
                    'Recent photo with white background'
                ]
            },
            {
                id: 'osas-org',
                name: 'Organisation and Activity Permit',
                mode: 'appointment',
                processingTime: '5 working days',
                description: 'Accreditation of student organisations and approval of campus activity proposals.',
                requirements: [
                    'Accomplished activity proposal form',
                    'Letter of request signed by the organisation adviser',
                    'List of officers and members',
                    'Budget plan for the activity'
                ]
            },
            {
                id: 'osas-clearance',
                name: 'Student Clearance Signature',
                mode: 'queue',
                processingTime: 'Same day',
                description: 'Signing of clearance forms for graduating students and transferees.',
                requirements: [
                    'Valid school ID',
                    'Printed clearance form',
                    'Settled accountabilities from other offices'
                ]
            }
        ]
    },
    {
        id: 'faculty',
        prefix: 'F',
        name: 'Faculty Consultation',
        shortName: 'Faculty',
        icon: '&#128218;',
        tagline: 'Book a consultation with your professor',
        description: 'Schedule a one-on-one consultation with a professor for academic advising, grade clarification, thesis guidance, or make-up requirements.',
        location: 'Faculty Room, Second Floor Academic Building',
        room: 'Room B-201',
        days: [1, 2, 3, 4, 5],
        openTime: '08:00',
        closeTime: '17:00',
        breakStart: '12:00',
        breakEnd: '13:00',
        queueEnabled: false,
        averageServiceMinutes: 20,
        dailyQueueLimit: 0,
        contact: 'faculty@ccsjdm.edu.ph',
        services: [
            {
                id: 'faculty-consultation',
                name: 'Academic Consultation',
                mode: 'appointment',
                processingTime: '20 to 30 minutes',
                description: 'One-on-one consultation with your professor during their official consultation hours.',
                requirements: [
                    'Valid school ID',
                    'Subject code and section',
                    'Specific topic or question you want to discuss'
                ]
            }
        ]
    }
];

const FACULTY_MEMBERS = [
    {
        id: 'fac-001',
        name: 'Prof. Ramon Villanueva',
        position: 'Associate Professor',
        department: 'College of Computer Studies',
        subjects: ['Data Structures', 'Algorithms', 'Capstone Project'],
        days: [1, 3, 5],
        startTime: '09:00',
        endTime: '11:00',
        room: 'Room B-201',
        email: 'rvillanueva@ccsjdm.edu.ph'
    },
    {
        id: 'fac-002',
        name: 'Prof. Celine Marquez',
        position: 'Program Head',
        department: 'College of Computer Studies',
        subjects: ['Software Engineering', 'Systems Analysis and Design'],
        days: [2, 4],
        startTime: '13:00',
        endTime: '16:00',
        room: 'Room B-203',
        email: 'cmarquez@ccsjdm.edu.ph'
    },
    {
        id: 'fac-003',
        name: 'Prof. Daniel Ocampo',
        position: 'Assistant Professor',
        department: 'College of Business and Accountancy',
        subjects: ['Financial Accounting', 'Business Statistics'],
        days: [1, 2, 4],
        startTime: '10:00',
        endTime: '12:00',
        room: 'Room C-110',
        email: 'docampo@ccsjdm.edu.ph'
    },
    {
        id: 'fac-004',
        name: 'Prof. Aileen Bautista',
        position: 'Professor',
        department: 'College of Education',
        subjects: ['Facilitating Learning', 'Assessment of Learning'],
        days: [3, 4, 5],
        startTime: '08:00',
        endTime: '10:00',
        room: 'Room D-105',
        email: 'abautista@ccsjdm.edu.ph'
    },
    {
        id: 'fac-005',
        name: 'Prof. Michael Santos',
        position: 'Associate Professor',
        department: 'College of Engineering',
        subjects: ['Engineering Mathematics', 'Thermodynamics'],
        days: [1, 3],
        startTime: '14:00',
        endTime: '16:00',
        room: 'Room E-202',
        email: 'msantos@ccsjdm.edu.ph'
    },
    {
        id: 'fac-006',
        name: 'Prof. Grace Delos Reyes',
        position: 'Instructor',
        department: 'College of Arts and Sciences',
        subjects: ['Purposive Communication', 'Technical Writing'],
        days: [2, 5],
        startTime: '09:00',
        endTime: '11:30',
        room: 'Room F-108',
        email: 'gdelosreyes@ccsjdm.edu.ph'
    }
];

let appointments = [];
let queueTickets = [];
let queueState = {};
let serviceNotifications = [];

function todayKey(date) {
    const value = date || new Date();
    const month = String(value.getMonth() + 1).padStart(2, '0');
    const day = String(value.getDate()).padStart(2, '0');
    return value.getFullYear() + '-' + month + '-' + day;
}

function readJson(key, fallback) {
    try {
        const raw = localStorage.getItem(key);
        if (!raw) return fallback;
        const parsed = JSON.parse(raw);
        return parsed === null || parsed === undefined ? fallback : parsed;
    } catch (error) {
        return fallback;
    }
}

function loadServiceData() {
    appointments = readJson(SERVICE_STORAGE_KEYS.appointments, []);
    queueTickets = readJson(SERVICE_STORAGE_KEYS.tickets, []);
    queueState = readJson(SERVICE_STORAGE_KEYS.queueState, {});
    serviceNotifications = readJson(SERVICE_STORAGE_KEYS.notifications, []);

    if (!Array.isArray(appointments)) appointments = [];
    if (!Array.isArray(queueTickets)) queueTickets = [];
    if (!queueState || typeof queueState !== 'object') queueState = {};
    if (!Array.isArray(serviceNotifications)) serviceNotifications = [];
}

function saveServiceData() {
    localStorage.setItem(SERVICE_STORAGE_KEYS.appointments, JSON.stringify(appointments));
    localStorage.setItem(SERVICE_STORAGE_KEYS.tickets, JSON.stringify(queueTickets));
    localStorage.setItem(SERVICE_STORAGE_KEYS.queueState, JSON.stringify(queueState));
    localStorage.setItem(SERVICE_STORAGE_KEYS.notifications, JSON.stringify(serviceNotifications));
}

function findOffice(officeId) {
    return SERVICE_OFFICES.find(function (office) { return office.id === officeId; }) || null;
}

function findService(serviceId) {
    for (let index = 0; index < SERVICE_OFFICES.length; index++) {
        const match = SERVICE_OFFICES[index].services.find(function (service) {
            return service.id === serviceId;
        });
        if (match) return match;
    }
    return null;
}

function findOfficeOfService(serviceId) {
    return SERVICE_OFFICES.find(function (office) {
        return office.services.some(function (service) { return service.id === serviceId; });
    }) || null;
}

function findFaculty(facultyId) {
    return FACULTY_MEMBERS.find(function (member) { return member.id === facultyId; }) || null;
}

function allServices() {
    const list = [];
    SERVICE_OFFICES.forEach(function (office) {
        office.services.forEach(function (service) {
            list.push({ office: office, service: service });
        });
    });
    return list;
}

function timeToMinutes(value) {
    const parts = String(value).split(':');
    return (parseInt(parts[0], 10) * 60) + parseInt(parts[1] || '0', 10);
}

function minutesToTime(total) {
    const hours = Math.floor(total / 60);
    const minutes = total % 60;
    return String(hours).padStart(2, '0') + ':' + String(minutes).padStart(2, '0');
}

function formatTimeLabel(value) {
    const total = timeToMinutes(value);
    let hours = Math.floor(total / 60);
    const minutes = total % 60;
    const suffix = hours >= 12 ? 'PM' : 'AM';
    if (hours === 0) hours = 12;
    else if (hours > 12) hours -= 12;
    return hours + ':' + String(minutes).padStart(2, '0') + ' ' + suffix;
}

function formatDateLabel(isoDate) {
    const parts = String(isoDate).split('-');
    if (parts.length !== 3) return isoDate;
    const date = new Date(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10));
    const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    return WEEKDAY_NAMES[date.getDay()] + ', ' + months[date.getMonth()] + ' ' + date.getDate() + ', ' + date.getFullYear();
}

function describeSchedule(entity) {
    const days = entity.days || [];
    if (days.length === 0) return 'By appointment only';
    const sorted = days.slice().sort();
    const names = sorted.map(function (day) { return WEEKDAY_NAMES[day].slice(0, 3); });
    let range = names.join(', ');
    if (sorted.length > 2 && sorted[sorted.length - 1] - sorted[0] === sorted.length - 1) {
        range = WEEKDAY_NAMES[sorted[0]].slice(0, 3) + ' to ' + WEEKDAY_NAMES[sorted[sorted.length - 1]].slice(0, 3);
    }
    const start = entity.openTime || entity.startTime;
    const end = entity.closeTime || entity.endTime;
    return range + ', ' + formatTimeLabel(start) + ' to ' + formatTimeLabel(end);
}

function isOfficeOpenNow(office, referenceDate) {
    const now = referenceDate || new Date();
    if ((office.days || []).indexOf(now.getDay()) === -1) return false;
    const current = (now.getHours() * 60) + now.getMinutes();
    if (current < timeToMinutes(office.openTime) || current >= timeToMinutes(office.closeTime)) return false;
    if (office.breakStart && office.breakEnd) {
        if (current >= timeToMinutes(office.breakStart) && current < timeToMinutes(office.breakEnd)) return false;
    }
    return true;
}

function officeStatusLabel(office, referenceDate) {
    const now = referenceDate || new Date();
    if ((office.days || []).indexOf(now.getDay()) === -1) return { label: 'Closed today', state: 'closed' };
    const current = (now.getHours() * 60) + now.getMinutes();
    if (office.breakStart && current >= timeToMinutes(office.breakStart) && current < timeToMinutes(office.breakEnd)) {
        return { label: 'On break until ' + formatTimeLabel(office.breakEnd), state: 'break' };
    }
    if (current < timeToMinutes(office.openTime)) {
        return { label: 'Opens at ' + formatTimeLabel(office.openTime), state: 'closed' };
    }
    if (current >= timeToMinutes(office.closeTime)) {
        return { label: 'Closed for today', state: 'closed' };
    }
    return { label: 'Open now until ' + formatTimeLabel(office.closeTime), state: 'open' };
}

function getQueueState(officeId) {
    const key = officeId + ':' + todayKey();
    if (!queueState[key]) {
        queueState[key] = { lastNumber: 0, nowServing: 0, open: true };
    }
    return queueState[key];
}

function setQueueState(officeId, patch) {
    const key = officeId + ':' + todayKey();
    queueState[key] = Object.assign(getQueueState(officeId), patch);
    saveServiceData();
}

function ticketsForOfficeToday(officeId) {
    const day = todayKey();
    return queueTickets.filter(function (ticket) {
        return ticket.officeId === officeId && ticket.date === day;
    });
}

function activeTicketsForOffice(officeId) {
    return ticketsForOfficeToday(officeId).filter(function (ticket) {
        return ticket.status === QUEUE_STATUS.waiting || ticket.status === QUEUE_STATUS.almost ||
            ticket.status === QUEUE_STATUS.called || ticket.status === QUEUE_STATUS.serving;
    });
}

function formatQueueCode(office, number) {
    return office.prefix + '-' + String(number).padStart(3, '0');
}

function queuePosition(ticket) {
    if (ticket.status === QUEUE_STATUS.serving || ticket.status === QUEUE_STATUS.called) return 0;
    const ahead = ticketsForOfficeToday(ticket.officeId).filter(function (other) {
        return other.number < ticket.number &&
            (other.status === QUEUE_STATUS.waiting || other.status === QUEUE_STATUS.almost ||
             other.status === QUEUE_STATUS.called || other.status === QUEUE_STATUS.serving);
    });
    return ahead.length;
}

function estimatedWaitMinutes(ticket) {
    const office = findOffice(ticket.officeId);
    if (!office) return 0;
    return queuePosition(ticket) * office.averageServiceMinutes;
}

function formatWaitLabel(minutes) {
    if (minutes <= 0) return 'You are next';
    if (minutes < 60) return 'About ' + minutes + ' minutes';
    const hours = Math.floor(minutes / 60);
    const rest = minutes % 60;
    return 'About ' + hours + (hours > 1 ? ' hours' : ' hour') + (rest ? ' ' + rest + ' minutes' : '');
}

function canIssueTicket(office) {
    if (!office.queueEnabled) {
        return { allowed: false, reason: 'This office accepts scheduled appointments only. Please book an appointment instead.' };
    }
    const state = getQueueState(office.id);
    if (!state.open) {
        return { allowed: false, reason: 'The queue for this office is currently closed. Please try again when the office reopens or book an appointment.' };
    }
    if (!isOfficeOpenNow(office)) {
        const status = officeStatusLabel(office);
        return { allowed: false, reason: 'The office is not accepting walk-ins right now. ' + status.label + '. You may book an appointment instead.' };
    }
    if (state.lastNumber >= office.dailyQueueLimit) {
        return { allowed: false, reason: 'The queue is already full for today. Please come back tomorrow or book an appointment.' };
    }
    return { allowed: true, reason: '' };
}

function studentHasActiveTicket(officeId, studentId) {
    return activeTicketsForOffice(officeId).some(function (ticket) {
        return ticket.studentId === studentId;
    });
}

function issueQueueTicket(officeId, serviceId, student) {
    const office = findOffice(officeId);
    if (!office) return { ok: false, message: 'That office could not be found.' };

    const check = canIssueTicket(office);
    if (!check.allowed) return { ok: false, message: check.reason };

    if (studentHasActiveTicket(officeId, student.id)) {
        return { ok: false, message: 'You already have an active queue number for this office. Please use your existing ticket.' };
    }

    const state = getQueueState(officeId);
    const number = state.lastNumber + 1;
    const service = findService(serviceId);
    const ticket = {
        id: 'TKT-' + Date.now(),
        code: formatQueueCode(office, number),
        number: number,
        officeId: officeId,
        officeName: office.name,
        serviceId: serviceId,
        serviceName: service ? service.name : 'General Service',
        studentId: student.id,
        studentName: student.name,
        date: todayKey(),
        issuedAt: new Date().toISOString(),
        status: QUEUE_STATUS.waiting,
        calledAt: null,
        completedAt: null
    };

    queueTickets.push(ticket);
    setQueueState(officeId, { lastNumber: number });
    addServiceNotification(student.id, 'Queue number ' + ticket.code + ' issued for ' + office.shortName + '.', 'queue');
    saveServiceData();
    return { ok: true, ticket: ticket };
}

function cancelQueueTicket(ticketId) {
    const ticket = queueTickets.find(function (item) { return item.id === ticketId; });
    if (!ticket) return false;
    ticket.status = QUEUE_STATUS.cancelled;
    saveServiceData();
    return true;
}

function callNextTicket(officeId) {
    const waiting = ticketsForOfficeToday(officeId)
        .filter(function (ticket) { return ticket.status === QUEUE_STATUS.waiting || ticket.status === QUEUE_STATUS.almost; })
        .sort(function (a, b) { return a.number - b.number; });

    ticketsForOfficeToday(officeId).forEach(function (ticket) {
        if (ticket.status === QUEUE_STATUS.serving) ticket.status = QUEUE_STATUS.completed;
        if (ticket.status === QUEUE_STATUS.called) ticket.status = QUEUE_STATUS.serving;
    });

    if (waiting.length === 0) {
        saveServiceData();
        return null;
    }

    const next = waiting[0];
    next.status = QUEUE_STATUS.serving;
    next.calledAt = new Date().toISOString();
    setQueueState(officeId, { nowServing: next.number });
    addServiceNotification(next.studentId, 'Your number ' + next.code + ' is now being served.', 'queue');
    saveServiceData();
    return next;
}

function updateTicketStatus(ticketId, status) {
    const ticket = queueTickets.find(function (item) { return item.id === ticketId; });
    if (!ticket) return false;
    ticket.status = status;
    if (status === QUEUE_STATUS.completed) ticket.completedAt = new Date().toISOString();
    addServiceNotification(ticket.studentId, 'Queue ' + ticket.code + ' was marked as ' + status + '.', 'queue');
    saveServiceData();
    return true;
}

function buildTimeSlots(entity, durationMinutes) {
    const start = timeToMinutes(entity.openTime || entity.startTime);
    const end = timeToMinutes(entity.closeTime || entity.endTime);
    const breakStart = entity.breakStart ? timeToMinutes(entity.breakStart) : null;
    const breakEnd = entity.breakEnd ? timeToMinutes(entity.breakEnd) : null;
    const slots = [];
    for (let cursor = start; cursor + durationMinutes <= end; cursor += durationMinutes) {
        if (breakStart !== null && cursor >= breakStart && cursor < breakEnd) continue;
        slots.push(minutesToTime(cursor));
    }
    return slots;
}

function appointmentsFor(targetId, isoDate) {
    return appointments.filter(function (item) {
        return item.targetId === targetId && item.date === isoDate &&
            item.status !== APPOINTMENT_STATUS.cancelled;
    });
}

function availableSlots(targetId, isoDate) {
    const office = findOffice(targetId);
    const faculty = findFaculty(targetId);
    const entity = office || faculty;
    if (!entity) return [];

    const parts = String(isoDate).split('-');
    const date = new Date(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10));
    if ((entity.days || []).indexOf(date.getDay()) === -1) return [];

    const duration = faculty ? 30 : (office.averageServiceMinutes >= 20 ? 30 : 20);
    const taken = appointmentsFor(targetId, isoDate).map(function (item) { return item.time; });
    const now = new Date();
    const isToday = isoDate === todayKey();
    const currentMinutes = (now.getHours() * 60) + now.getMinutes();

    return buildTimeSlots(entity, duration).filter(function (slot) {
        if (taken.indexOf(slot) !== -1) return false;
        if (isToday && timeToMinutes(slot) <= currentMinutes) return false;
        return true;
    });
}

function generateAppointmentReference() {
    const year = new Date().getFullYear();
    let counter = appointments.length + 1;
    let reference = 'APT-' + year + '-' + String(counter).padStart(4, '0');
    while (appointments.some(function (item) { return item.reference === reference; })) {
        counter += 1;
        reference = 'APT-' + year + '-' + String(counter).padStart(4, '0');
    }
    return reference;
}

function bookAppointment(details) {
    const office = findOffice(details.targetId);
    const faculty = findFaculty(details.targetId);
    const entity = office || faculty;
    if (!entity) return { ok: false, message: 'That office or faculty member could not be found.' };

    if (availableSlots(details.targetId, details.date).indexOf(details.time) === -1) {
        return { ok: false, message: 'That time slot is no longer available. Please choose another schedule.' };
    }

    const duplicate = appointments.some(function (item) {
        return item.studentId === details.studentId && item.targetId === details.targetId &&
            item.date === details.date && item.status === APPOINTMENT_STATUS.confirmed;
    });
    if (duplicate) {
        return { ok: false, message: 'You already have a confirmed appointment with this office on the selected date.' };
    }

    const appointment = {
        id: 'APT-' + Date.now(),
        reference: generateAppointmentReference(),
        targetId: details.targetId,
        targetName: office ? office.name : faculty.name,
        targetType: office ? 'office' : 'faculty',
        serviceId: details.serviceId || '',
        serviceName: details.serviceName || 'Consultation',
        studentId: details.studentId,
        studentName: details.studentName,
        date: details.date,
        time: details.time,
        purpose: details.purpose || '',
        requirementsConfirmed: !!details.requirementsConfirmed,
        status: APPOINTMENT_STATUS.confirmed,
        createdAt: new Date().toISOString()
    };

    appointments.push(appointment);
    addServiceNotification(details.studentId,
        'Appointment ' + appointment.reference + ' confirmed for ' + formatDateLabel(appointment.date) + ' at ' + formatTimeLabel(appointment.time) + '.',
        'appointment');
    saveServiceData();
    return { ok: true, appointment: appointment };
}

function cancelAppointment(appointmentId) {
    const appointment = appointments.find(function (item) { return item.id === appointmentId; });
    if (!appointment) return false;
    appointment.status = APPOINTMENT_STATUS.cancelled;
    addServiceNotification(appointment.studentId, 'Appointment ' + appointment.reference + ' was cancelled.', 'appointment');
    saveServiceData();
    return true;
}

function updateAppointmentStatus(appointmentId, status) {
    const appointment = appointments.find(function (item) { return item.id === appointmentId; });
    if (!appointment) return false;
    appointment.status = status;
    addServiceNotification(appointment.studentId, 'Appointment ' + appointment.reference + ' is now marked as ' + status + '.', 'appointment');
    saveServiceData();
    return true;
}

function addServiceNotification(studentId, message, kind) {
    serviceNotifications.unshift({
        id: 'NTF-' + Date.now() + '-' + Math.floor(Math.random() * 1000),
        studentId: studentId,
        message: message,
        kind: kind || 'info',
        createdAt: new Date().toISOString(),
        read: false
    });
    if (serviceNotifications.length > 60) serviceNotifications = serviceNotifications.slice(0, 60);
}

function notificationsForStudent(studentId) {
    return serviceNotifications.filter(function (item) { return item.studentId === studentId; });
}

function appointmentsForStudent(studentId) {
    return appointments.filter(function (item) { return item.studentId === studentId; });
}

function ticketsForStudent(studentId) {
    return queueTickets.filter(function (item) { return item.studentId === studentId; });
}

function serviceModeLabel(mode) {
    if (mode === 'queue') return 'Walk-in queue';
    if (mode === 'appointment') return 'Appointment required';
    return 'Appointment or walk-in';
}

function initServiceDirectoryPage() {
    const officeGrid = document.getElementById('officeGrid');
    const facultyGrid = document.getElementById('facultyGrid');
    if (!officeGrid && !facultyGrid) return;

    const searchInput = document.getElementById('serviceSearchInput');
    const tabButtons = document.querySelectorAll('.directory-tab');
    const officePanel = document.getElementById('officePanel');
    const facultyPanel = document.getElementById('facultyPanel');
    const departmentFilter = document.getElementById('departmentFilter');
    const officeCount = document.getElementById('officeResultCount');
    const facultyCount = document.getElementById('facultyResultCount');

    if (departmentFilter && !departmentFilter.dataset.ready) {
        const departments = [];
        FACULTY_MEMBERS.forEach(function (member) {
            if (departments.indexOf(member.department) === -1) departments.push(member.department);
        });
        departmentFilter.innerHTML = '<option value="all">All Departments</option>' +
            departments.map(function (name) {
                return '<option value="' + escapeHtml(name) + '">' + escapeHtml(name) + '</option>';
            }).join('');
        departmentFilter.dataset.ready = 'true';
    }

    function renderOffices() {
        if (!officeGrid) return;
        const term = (searchInput ? searchInput.value : '').trim().toLowerCase();
        const matches = SERVICE_OFFICES.filter(function (office) {
            if (!term) return true;
            const haystack = [office.name, office.shortName, office.tagline, office.description, office.location]
                .concat(office.services.map(function (service) { return service.name; }))
                .join(' ').toLowerCase();
            return haystack.indexOf(term) !== -1;
        });

        if (officeCount) {
            officeCount.textContent = matches.length + (matches.length === 1 ? ' office' : ' offices');
        }

        if (matches.length === 0) {
            officeGrid.innerHTML = '<div class="empty-state"><div class="empty-icon">&#128269;</div>' +
                '<h3>No office matches your search</h3>' +
                '<p>Try a different keyword such as document, medical, scholarship, or counseling.</p></div>';
            return;
        }

        officeGrid.innerHTML = matches.map(function (office) {
            const status = officeStatusLabel(office);
            const state = getQueueState(office.id);
            const waiting = activeTicketsForOffice(office.id).length;
            const queueLine = office.queueEnabled
                ? '<span class="office-queue-chip">&#127915; ' + waiting + ' in queue &bull; Now serving ' +
                  (state.nowServing ? formatQueueCode(office, state.nowServing) : 'none') + '</span>'
                : '<span class="office-queue-chip muted">&#128197; Appointment only</span>';

            return '<article class="office-card">' +
                '<div class="office-card-head">' +
                '<span class="office-icon">' + office.icon + '</span>' +
                '<div>' +
                '<h3>' + escapeHtml(office.name) + '</h3>' +
                '<p class="office-tagline">' + escapeHtml(office.tagline) + '</p>' +
                '</div>' +
                '</div>' +
                '<span class="office-status ' + status.state + '">' + escapeHtml(status.label) + '</span>' +
                '<p class="office-desc">' + escapeHtml(office.description) + '</p>' +
                '<ul class="office-meta">' +
                '<li>&#128205; ' + escapeHtml(office.location) + ' &bull; ' + escapeHtml(office.room) + '</li>' +
                '<li>&#128336; ' + escapeHtml(describeSchedule(office)) + '</li>' +
                '<li>&#128231; ' + escapeHtml(office.contact) + '</li>' +
                '</ul>' +
                queueLine +
                '<div class="office-services">' +
                office.services.slice(0, 3).map(function (service) {
                    return '<span class="service-pill">' + escapeHtml(service.name) + '</span>';
                }).join('') +
                (office.services.length > 3 ? '<span class="service-pill more">+' + (office.services.length - 3) + ' more</span>' : '') +
                '</div>' +
                '<a class="btn-primary btn-block" href="service-details.html?office=' + encodeURIComponent(office.id) + '">View Services and Requirements</a>' +
                '</article>';
        }).join('');
    }

    function renderFaculty() {
        if (!facultyGrid) return;
        const term = (searchInput ? searchInput.value : '').trim().toLowerCase();
        const department = departmentFilter ? departmentFilter.value : 'all';

        const matches = FACULTY_MEMBERS.filter(function (member) {
            const matchesDepartment = department === 'all' || member.department === department;
            if (!matchesDepartment) return false;
            if (!term) return true;
            const haystack = [member.name, member.position, member.department, member.room]
                .concat(member.subjects).join(' ').toLowerCase();
            return haystack.indexOf(term) !== -1;
        });

        if (facultyCount) {
            facultyCount.textContent = matches.length + (matches.length === 1 ? ' professor' : ' professors');
        }

        if (matches.length === 0) {
            facultyGrid.innerHTML = '<div class="empty-state"><div class="empty-icon">&#128269;</div>' +
                '<h3>No professor matches your search</h3>' +
                '<p>Try searching by name, department, or subject.</p></div>';
            return;
        }

        const today = new Date().getDay();
        facultyGrid.innerHTML = matches.map(function (member) {
            const availableToday = member.days.indexOf(today) !== -1;
            const initials = member.name.replace('Prof. ', '').split(' ').map(function (part) {
                return part.charAt(0).toUpperCase();
            }).slice(0, 2).join('');

            return '<article class="faculty-card">' +
                '<div class="faculty-head">' +
                '<span class="faculty-avatar">' + escapeHtml(initials) + '</span>' +
                '<div>' +
                '<h3>' + escapeHtml(member.name) + '</h3>' +
                '<p class="faculty-position">' + escapeHtml(member.position) + '</p>' +
                '<p class="faculty-department">' + escapeHtml(member.department) + '</p>' +
                '</div>' +
                '</div>' +
                '<span class="office-status ' + (availableToday ? 'open' : 'closed') + '">' +
                (availableToday ? 'Consultation hours today' : 'Not available today') + '</span>' +
                '<ul class="office-meta">' +
                '<li>&#128336; ' + escapeHtml(describeSchedule(member)) + '</li>' +
                '<li>&#128205; ' + escapeHtml(member.room) + '</li>' +
                '<li>&#128231; ' + escapeHtml(member.email) + '</li>' +
                '</ul>' +
                '<div class="office-services">' +
                member.subjects.map(function (subject) {
                    return '<span class="service-pill">' + escapeHtml(subject) + '</span>';
                }).join('') +
                '</div>' +
                '<a class="btn-primary btn-block" href="service-details.html?faculty=' + encodeURIComponent(member.id) + '">Book a Consultation</a>' +
                '</article>';
        }).join('');
    }

    function switchTab(mode) {
        tabButtons.forEach(function (button) {
            const isActive = button.dataset.directory === mode;
            button.classList.toggle('active', isActive);
            button.setAttribute('aria-selected', String(isActive));
        });
        if (officePanel) officePanel.hidden = mode !== 'offices';
        if (facultyPanel) facultyPanel.hidden = mode !== 'faculty';
    }

    tabButtons.forEach(function (button) {
        button.onclick = function () { switchTab(button.dataset.directory); };
    });

    if (searchInput) {
        searchInput.oninput = function () {
            renderOffices();
            renderFaculty();
        };
        searchInput.onkeydown = function (keyEvent) {
            if (keyEvent.key === 'Enter') {
                keyEvent.preventDefault();
                renderOffices();
                renderFaculty();
            }
        };
    }

    const searchButton = document.getElementById('serviceSearchBtn');
    if (searchButton) {
        searchButton.onclick = function () {
            renderOffices();
            renderFaculty();
        };
    }

    if (departmentFilter) {
        departmentFilter.onchange = renderFaculty;
    }

    const params = new URLSearchParams(window.location.search);
    switchTab(params.get('view') === 'faculty' ? 'faculty' : 'offices');
    renderOffices();
    renderFaculty();
}

document.addEventListener('DOMContentLoaded', function () {
    loadServiceData();

    const path = window.location.pathname;
    if (path.includes('services.html')) {
        initServiceDirectoryPage();
    }
});
