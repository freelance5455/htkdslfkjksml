# VideoGenie Step 5 – AI Image Generation Engine

## Is step mein kya update hua
- Har scene ka visual prompt narration, character description, background, camera angle, animation action aur continuity notes ko combine karta hai.
- Pollinations AI image requests ke liye scene-specific SHA-256 seed use hota hai; alag scene ko alag seed milta hai.
- Image service se response aane ke baad content-type, minimum file size aur actual image decoding validate hoti hai.
- Network/service failure par 3 attempts aur clear error message milta hai.
- Failed AI image ko ab chupke se gradient placeholder se replace nahi kiya jata.
- Resume ke waqt existing image corrupt/too small ho to regenerate hoti hai.
- Output folder mein `image_manifest.json` save hota hai (scene, provider, prompt, file size).

## Kaise test karein
1. ZIP extract karein.
2. `VideoGenie-Pro` folder mein terminal kholein.
3. Dependencies install karein: `pip install -r requirements.txt`.
4. FFmpeg/FFprobe install karke PATH mein add karein.
5. `start.bat` (Windows) ya `start-for-phone-app.sh` (Termux) run karein.
6. UI mein Images = `AI images (free, no key)` select karein, topic/script dein aur Create video dabayein.
7. Output ke project folder mein `images/` aur `image_manifest.json` check karein.

## Important limitations
- Pollinations ek third-party online service hai; availability, latency, model behavior aur free access guaranteed nahi hain. Internet zaroori hai.
- Scene-specific seeds/prompts improve variety but cannot guarantee identical character identity across all images. Strong character consistency usually needs a reference-image/character-LoRA capable provider, which is a later enhancement and may cost money.
- Is step mein images generate hoti hain; image-to-video motion generation agle step ka kaam hai.
- Ye source ZIP hai, rebuilt/verified Android APK nahi.
