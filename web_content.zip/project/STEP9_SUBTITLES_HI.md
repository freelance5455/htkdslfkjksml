# Step 9 – Automatic Subtitles & Captions

- Generates `subtitles.srt` from each scene's narration and measured clip timing.
- Supports Unicode captions (Hindi, Marathi, English).
- Optionally burns captions into `video.mp4` with FFmpeg/libass (default enabled).
- Keeps a separate editable SRT download.
- Timing is phrase-level estimated timing, not word-level forced alignment.
- Install an FFmpeg build with the `subtitles`/libass filter for burn-in support.
