package com.weldmaster.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.InputStream;
import java.io.FileOutputStream;

public class MainActivity extends Activity {
  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    getWindow().setStatusBarColor(0xFF000000);
    getWindow().setNavigationBarColor(0xFF000000);
    WebView web = new WebView(this);
    web.setBackgroundColor(0xFF000000);
    WebSettings s = web.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setAllowFileAccess(true);
    s.setAllowContentAccess(true);
    web.addJavascriptInterface(new PdfBridge(), "Android");
    web.setWebViewClient(new WebViewClient());
    web.setWebChromeClient(new WebChromeClient());
    setContentView(web);
    web.loadUrl("file:///android_asset/index.html");
  }
  public class PdfBridge {
    @JavascriptInterface public void openPdf(String assetName) {
      runOnUiThread(() -> {
        try {
          File dir = new File(getCacheDir(), "pdfs"); dir.mkdirs();
          File out = new File(dir, assetName);
          try (InputStream in = getAssets().open(assetName); FileOutputStream fos = new FileOutputStream(out)) {
            byte[] buf = new byte[8192]; int n; while ((n = in.read(buf)) > 0) fos.write(buf, 0, n);
          }
          Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName()+".provider", out);
          Intent intent = new Intent(Intent.ACTION_VIEW); intent.setDataAndType(uri, "application/pdf");
          intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
          startActivity(intent);
        } catch (Exception e) { Toast.makeText(MainActivity.this, "Установите PDF-просмотрщик", Toast.LENGTH_LONG).show(); }
      });
    }
  }
}
