package com.aura.customizer.widgets
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.os.BatteryManager
import android.widget.RemoteViews
import com.aura.customizer.R

class AuraBatteryWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val i = context.registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        ids.forEach { id ->
            val v = RemoteViews(context.packageName, R.layout.battery_widget)
            v.setTextViewText(R.id.battery_text, if (level >= 0) "$level%" else "—")
            manager.updateAppWidget(id, v)
        }
    }
}
