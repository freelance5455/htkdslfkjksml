package com.aura.customizer

import android.app.WallpaperManager
import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.content.Intent
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import java.text.SimpleDateFormat
import java.util.*
import com.aura.customizer.data.AuraStore

private enum class Tab(val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    HOME("Home", Icons.Rounded.Home),
    CUSTOMIZE("Customize", Icons.Rounded.Tune),
    WIDGETS("Widgets", Icons.Rounded.Widgets),
    WALLPAPERS("Wallpapers", Icons.Rounded.Image),
    THEMES("Themes", Icons.Rounded.Favorite),
    SETTINGS("Settings", Icons.Rounded.Settings)
}

private data class ThemePreset(
    val name: String,
    val category: String,
    val image: String,
    val clock: String,
    val accent: Color
)

private val presets = listOf(
    ThemePreset("Midnight Japan", "Japanese", "https://images.unsplash.com/photo-1528360983277-13d401cdc186?w=1200", "21:29", Color(0xFFE8E5DF)),
    ThemePreset("Rainy Forest", "Nature", "https://images.unsplash.com/photo-1511497584788-876760111969?w=1200", "07:31", Color(0xFFD9DDD4)),
    ThemePreset("Coffee & Books", "Bookish", "https://images.unsplash.com/photo-1495446815901-a7297e633e8d?w=1200", "09:45", Color(0xFFE5D5BE)),
    ThemePreset("Night Train", "Travel", "https://images.unsplash.com/photo-1474487548417-781cb71495f3?w=1200", "23:17", Color(0xFFD9DDE5)),
    ThemePreset("Monochrome City", "Minimal", "https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?w=1200", "20:20", Color(0xFFEAEAEA)),
    ThemePreset("Film Camera", "Photography", "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=1200", "11:13", Color(0xFFE4DDD2))
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AuraV2() }
    }
}

@Composable
private fun AuraV2() {
    var tab by remember { mutableStateOf(Tab.HOME) }
    var preset by remember { mutableStateOf(presets.first()) }
    var toast by remember { mutableStateOf<String?>(null) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Color(0xFF090909),
            surface = Color(0xFF151515),
            surfaceVariant = Color(0xFF232323),
            primary = Color(0xFFF1EEE8),
            onPrimary = Color(0xFF101010),
            onBackground = Color(0xFFF4F2ED),
            onSurface = Color(0xFFF4F2ED),
            outline = Color(0xFF4A4A4A)
        )
    ) {
        Scaffold(
            containerColor = Color(0xFF090909),
            snackbarHost = { SnackbarHost(remember { SnackbarHostState() }) },
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF111111)) {
                    Tab.entries.forEach { t ->
                        NavigationBarItem(
                            selected = tab == t,
                            onClick = { tab = t },
                            icon = { Icon(t.icon, null) },
                            label = { Text(t.label, fontSize = 9.sp) }
                        )
                    }
                }
            }
        ) { pad ->
            Box(Modifier.fillMaxSize().padding(pad)) {
                AnimatedContent(tab, label = "navigation") { selected ->
                    when (selected) {
                        Tab.HOME -> HomePage(
                            onCustomize = { preset = it; tab = Tab.CUSTOMIZE },
                            onToast = { toast = it }
                        )
                        Tab.CUSTOMIZE -> CustomizePage(preset, onToast = { toast = it })
                        Tab.WIDGETS -> WidgetsPage(onToast = { toast = it })
                        Tab.WALLPAPERS -> WallpapersPage(onToast = { toast = it })
                        Tab.THEMES -> ThemesPage(onToast = { toast = it })
                        Tab.SETTINGS -> SettingsPage()
                    }
                }
                toast?.let {
                    Surface(
                        Modifier.align(Alignment.BottomCenter).padding(18.dp),
                        shape = RoundedCornerShape(16.dp),
                        color = Color(0xFF262626)
                    ) {
                        Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(it, fontSize = 13.sp)
                            Spacer(Modifier.width(12.dp))
                            Text("×", Modifier.clickable { toast = null }, color = Color.Gray)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Header(title: String, subtitle: String? = null) {
    Column(Modifier.padding(20.dp)) {
        Text(title, fontSize = 31.sp, fontWeight = FontWeight.ExtraLight, letterSpacing = (-0.7).sp)
        subtitle?.let {
            Spacer(Modifier.height(5.dp))
            Text(it, color = Color(0xFF9A9A9A), fontSize = 13.sp)
        }
    }
}

@Composable
private fun HomePage(onCustomize: (ThemePreset) -> Unit, onToast: (String) -> Unit) {
    var category by remember { mutableStateOf("All") }
    val categories = listOf("All", "Dark", "Japanese", "Nature", "Bookish", "Travel", "Minimal", "Photography")
    val visible = if (category == "All") presets else presets.filter { it.category == category }

    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        contentPadding = PaddingValues(14.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(span = { GridItemSpan(2) }) { Header("AURA", "Aesthetic Phone Customization Studio") }
        item(span = { GridItemSpan(2) }) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(categories) { c ->
                    FilterChip(selected = category == c, onClick = { category = c }, label = { Text(c) })
                }
            }
        }
        item(span = { GridItemSpan(2) }) { SectionTitle("Discover") }
        items(visible) { theme ->
            PresetCard(theme, onClick = { onCustomize(theme) })
        }
        item(span = { GridItemSpan(2) }) {
            ActionCard(
                title = "Build from scratch",
                subtitle = "Start with your wallpaper and add only the pieces you want.",
                button = "CREATE",
                onClick = { onToast("Blank AURA canvas ready in Customize") }
            )
        }
    }
}

@Composable
private fun PresetCard(theme: ThemePreset, onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(24.dp)).background(Color(0xFF171717)).clickable(onClick = onClick)
    ) {
        AsyncImage(theme.image, theme.name, Modifier.fillMaxWidth().height(205.dp), contentScale = ContentScale.Crop)
        Column(Modifier.padding(12.dp)) {
            Text(theme.name, fontWeight = FontWeight.Medium)
            Text(theme.category, color = Color.Gray, fontSize = 11.sp)
        }
    }
}

@Composable
private fun CustomizePage(theme: ThemePreset, onToast: (String) -> Unit) {
    val context = LocalContext.current
    var clock24 by remember { mutableStateOf(context.getSharedPreferences("aura", 0).getBoolean("clock24", true)) }
    var overlay by remember { mutableFloatStateOf(context.getSharedPreferences("aura", 0).getFloat("overlay", 0.32f)) }
    var selectedComponent by remember { mutableStateOf("Clock") }

    LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
        item { Header("Customize", theme.name) }
        item {
            PhoneCanvas(theme.image, overlay, clock24, selectedComponent)
        }
        item { SectionTitle("Quick components") }
        item {
            LazyRow(contentPadding = PaddingValues(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(listOf("Clock", "Date", "Photo", "Weather", "Music", "Quote", "Countdown", "Battery")) { item ->
                    FilterChip(selected = selectedComponent == item, onClick = { selectedComponent = item }, label = { Text(item) })
                }
            }
        }
        item {
            ControlCard("Clock", "Live device time") {
                SettingRow("24-hour clock", if (clock24) "21:29" else "09:29") {
                    Switch(clock24, {
                        clock24 = it
                        context.getSharedPreferences("aura", 0).edit().putBoolean("clock24", it).apply()
                    })
                }
            }
        }
        item {
            ControlCard("Wallpaper readability", "Overlay helps text remain legible") {
                Slider(overlay, { overlay = it; context.getSharedPreferences("aura", 0).edit().putFloat("overlay", it).apply() }, valueRange = 0f..0.8f)
            }
        }
        item {
            ControlCard("Apply safely", "Each action affects only the selected component.") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { onToast("$selectedComponent preview saved") }, Modifier.weight(1f)) { Text("SAVE") }
                    Button(onClick = { onToast("Add $selectedComponent through Android's supported flow") }, Modifier.weight(1f)) { Text("ADD") }
                }
            }
        }
    }
}

@Composable
private fun PhoneCanvas(image: String, overlay: Float, clock24: Boolean, selected: String) {
    val now = Calendar.getInstance()
    val fmt = if (clock24) "HH:mm" else "hh:mm"
    val time = SimpleDateFormat(fmt, Locale.getDefault()).format(now.time)
    Box(
        Modifier.padding(horizontal = 18.dp).fillMaxWidth().height(360.dp)
            .clip(RoundedCornerShape(34.dp)).background(Color(0xFF202020))
    ) {
        AsyncImage(image, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = overlay)))
        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(time, fontSize = 70.sp, fontWeight = FontWeight.ExtraLight)
            Text(SimpleDateFormat("EEE • dd MMMM", Locale.getDefault()).format(now.time).uppercase(), fontSize = 11.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(16.dp))
            Text(selected.uppercase(), color = Color.White.copy(alpha = 0.6f), fontSize = 9.sp, letterSpacing = 3.sp)
        }
    }
}

@Composable
private fun WidgetsPage(onToast: (String) -> Unit) {
    val widgets = listOf(
        "Oversized Clock" to "Live 12/24-hour typography",
        "Photo Card" to "Gallery image with crop and frame",
        "Date + Calendar" to "Minimal monthly calendar",
        "Weather" to "Temperature, condition and H/L",
        "Music" to "Android MediaSession-compatible controls",
        "Quote" to "Custom text and typography",
        "Countdown" to "Days/hours to an event",
        "Battery" to "Device battery and charging state",
        "Travel" to "Destination, local time and countdown",
        "Notes" to "Tiny to-do, journal or study card"
    )
    LazyColumn(contentPadding = PaddingValues(bottom = 20.dp)) {
        item { Header("Widget Studio", "Create and add components independently.") }
        items(widgets) { (name, desc) ->
            WidgetRow(name, desc, onAdd = { onToast("Use Android's widget picker to place $name") })
        }
        item {
            ActionCard("Custom Widget Builder", "Combine photo + clock + date + quote + countdown.", "OPEN") {
                onToast("Custom widget canvas opened")
            }
        }
    }
}

@Composable
private fun WidgetRow(name: String, desc: String, onAdd: () -> Unit) {
    Card(
        Modifier.padding(horizontal = 16.dp, vertical = 5.dp).fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF151515)),
        shape = RoundedCornerShape(19.dp)
    ) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(52.dp).clip(RoundedCornerShape(15.dp)).background(Color(0xFF292929)), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Widgets, null, tint = Color(0xFFE8E5DF))
            }
            Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f)) {
                Text(name, fontWeight = FontWeight.Medium)
                Text(desc, color = Color.Gray, fontSize = 11.sp)
            }
            OutlinedButton(onClick = onAdd) { Text("ADD") }
        }
    }
}

@Composable
private fun WallpapersPage(onToast: (String) -> Unit) {
    var selected by remember { mutableStateOf<Uri?>(null) }
    val context = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { selected = it }

    LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
        item { Header("Wallpapers", "Use original presets or your own photos.") }
        item {
            Button(
                onClick = { picker.launch(ActivityResultContracts.PickVisualMedia.ImageOnly) },
                Modifier.padding(horizontal = 18.dp).fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(18.dp)
            ) {
                Icon(Icons.Rounded.PhotoLibrary, null)
                Spacer(Modifier.width(8.dp))
                Text("USE PHOTO FROM GALLERY")
            }
        }
        selected?.let { uri ->
            item {
                Spacer(Modifier.height(14.dp))
                AsyncImage(uri, "Selected photo", Modifier.padding(horizontal = 18.dp).fillMaxWidth().height(300.dp).clip(RoundedCornerShape(26.dp)), contentScale = ContentScale.Crop)
            }
            item {
                Row(Modifier.padding(18.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton({ applyWallpaper(context, uri, false); onToast("Home wallpaper applied") }, Modifier.weight(1f)) { Text("HOME") }
                    OutlinedButton({ applyWallpaper(context, uri, true); onToast("Lock wallpaper applied") }, Modifier.weight(1f)) { Text("LOCK") }
                    Button({ applyWallpaper(context, uri, null); onToast("Both wallpapers applied") }, Modifier.weight(1f)) { Text("BOTH") }
                }
            }
        }
        item { SectionTitle("Original AURA collections") }
        items(presets) { theme ->
            Row(
                Modifier.padding(horizontal = 18.dp, vertical = 5.dp).fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp)).background(Color(0xFF161616)).padding(9.dp)
            ) {
                AsyncImage(theme.image, theme.name, Modifier.size(76.dp).clip(RoundedCornerShape(14.dp)), contentScale = ContentScale.Crop)
                Column(Modifier.padding(start = 12.dp).weight(1f)) {
                    Text(theme.name, fontWeight = FontWeight.Medium)
                    Text(theme.category, color = Color.Gray, fontSize = 11.sp)
                }
            }
        }
    }
}

private fun applyWallpaper(context: Context, uri: Uri, lock: Boolean?) {
    runCatching {
        val bitmap = context.contentResolver.openInputStream(uri)?.use(BitmapFactory::decodeStream) ?: return
        val manager = WallpaperManager.getInstance(context)
        when (lock) {
            true -> manager.setBitmap(bitmap, null, true, WallpaperManager.FLAG_LOCK)
            false -> manager.setBitmap(bitmap, null, true, WallpaperManager.FLAG_SYSTEM)
            null -> manager.setBitmap(bitmap, null, true, WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK)
        }
        bitmap.recycle()
    }
}

@Composable
private fun ThemesPage(onToast: (String) -> Unit) {
    val context = LocalContext.current
    val store = remember { AuraStore(context) }
    var saved by remember { mutableStateOf(store.getSavedThemes()) }

    LazyColumn(contentPadding = PaddingValues(bottom = 20.dp)) {
        item { Header("My Themes", "Save reusable configurations without touching your existing apps.") }
        item {
            ActionCard("Save current setup", "Store the selected component settings locally.", "SAVE") {
                store.saveTheme("AURA setup ${saved.size + 1}")
                saved = store.getSavedThemes()
                onToast("Theme saved locally")
            }
        }
        item { SectionTitle("Saved setups") }
        if (saved.isEmpty()) {
            item { Text("No saved themes yet.", Modifier.padding(20.dp), color = Color.Gray) }
        } else {
            items(saved) { name ->
                Card(Modifier.padding(horizontal = 18.dp, vertical = 5.dp).fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF171717)),
                    shape = RoundedCornerShape(18.dp)) {
                    Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.FavoriteBorder, null)
                        Spacer(Modifier.width(12.dp))
                        Text(name, Modifier.weight(1f))
                        Text("LOCAL", color = Color.Gray, fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsPage() {
    val context = LocalContext.current
    LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
        item { Header("Settings", "Privacy, performance and Android compatibility.") }
        item {
            ControlCard("Privacy-first", "AURA does not need full Gallery access for selected-photo workflows.") {
                Text("Selected photos stay on the device unless you explicitly export, share or back them up.", color = Color.Gray, fontSize = 12.sp)
            }
        }
        item {
            ControlCard("Data Saver", "Core editing remains local.") {
                SettingRow("Cache-heavy downloads", "Off by default") { }
                SettingRow("Background refresh", "Scheduled / event-based") { }
            }
        }
        item {
            ControlCard("Android limitations", "The OS controls secure and launcher-level features.") {
                Text("AURA never changes your PIN, password, biometrics, app data or installed applications.", color = Color.Gray, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                OutlinedButton({ runCatching { context.startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) } }) {
                    Text("OPEN HOME SETTINGS")
                }
            }
        }
        item {
            ControlCard("About AURA", "Version 2.0.0") {
                Text("Built around supported Android APIs and privacy-minimal permissions.", color = Color.Gray, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, Modifier.padding(horizontal = 18.dp, vertical = 12.dp), fontSize = 19.sp, fontWeight = FontWeight.Medium)
}

@Composable
private fun ControlCard(title: String, subtitle: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.padding(horizontal = 18.dp, vertical = 6.dp).fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF151515)),
        shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(title, fontWeight = FontWeight.Medium)
            Text(subtitle, color = Color.Gray, fontSize = 11.sp)
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
private fun SettingRow(title: String, value: String, action: @Composable () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 13.sp)
            Text(value, color = Color.Gray, fontSize = 10.sp)
        }
        action()
    }
}

@Composable
private fun ActionCard(title: String, subtitle: String, button: String, onClick: () -> Unit) {
    Card(Modifier.padding(18.dp).fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1C1C)), shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.padding(18.dp)) {
            Text(title, fontSize = 18.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(4.dp))
            Text(subtitle, color = Color.Gray, fontSize = 12.sp)
            Spacer(Modifier.height(14.dp))
            Button(onClick = onClick, shape = RoundedCornerShape(14.dp)) { Text(button) }
        }
    }
}
