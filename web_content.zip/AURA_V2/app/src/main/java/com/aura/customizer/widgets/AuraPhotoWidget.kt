package com.aura.customizer.widgets

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.widget.RemoteViews
import com.aura.customizer.R

class AuraPhotoWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { id ->
            val views = RemoteViews(context.packageName, R.layout.photo_widget)
            views.setTextViewText(R.id.photo_placeholder, "AURA\nPHOTO")
            manager.updateAppWidget(id, views)
        }
    }
}
