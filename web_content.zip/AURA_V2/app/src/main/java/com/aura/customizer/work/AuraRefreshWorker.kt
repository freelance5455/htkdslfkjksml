package com.aura.customizer.work

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

class AuraRefreshWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        // Intentionally local and lightweight. Future scheduled rotations can be
        // implemented here without a permanently running background service.
        return Result.success()
    }
}
