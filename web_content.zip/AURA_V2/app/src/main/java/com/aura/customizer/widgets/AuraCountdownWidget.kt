package com.aura.customizer.widgets
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.widget.RemoteViews
import com.aura.customizer.R

class AuraCountdownWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { id ->
            val v = RemoteViews(context.packageName, R.layout.countdown_widget)
            v.setTextViewText(R.id.countdown_text, "COUNTDOWN")
            v.setTextViewText(R.id.countdown_sub, "Set an event in AURA")
            manager.updateAppWidget(id, v)
        }
    }
}
