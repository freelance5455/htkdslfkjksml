package com.aura.customizer.widgets
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.widget.RemoteViews
import com.aura.customizer.R
import java.text.SimpleDateFormat
import java.util.*

class AuraDateWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val date = SimpleDateFormat("EEE\ndd MMM", Locale.getDefault()).format(Date()).uppercase()
        ids.forEach { id ->
            val v = RemoteViews(context.packageName, R.layout.date_widget)
            v.setTextViewText(R.id.date_text, date)
            manager.updateAppWidget(id, v)
        }
    }
}
