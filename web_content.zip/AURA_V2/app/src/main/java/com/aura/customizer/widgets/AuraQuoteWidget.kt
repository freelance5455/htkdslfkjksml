package com.aura.customizer.widgets
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.widget.RemoteViews
import com.aura.customizer.R

class AuraQuoteWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { id ->
            val v = RemoteViews(context.packageName, R.layout.quote_widget)
            v.setTextViewText(R.id.quote_text, "Make room for what matters.")
            manager.updateAppWidget(id, v)
        }
    }
}
