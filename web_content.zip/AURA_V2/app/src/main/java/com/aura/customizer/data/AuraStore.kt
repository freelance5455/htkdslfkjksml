package com.aura.customizer.data

import android.content.Context
import org.json.JSONArray

class AuraStore(context: Context) {
    private val prefs = context.getSharedPreferences("aura_store", Context.MODE_PRIVATE)

    fun saveTheme(name: String) {
        val arr = JSONArray(prefs.getString("themes", "[]"))
        arr.put(name)
        prefs.edit().putString("themes", arr.toString()).apply()
    }

    fun getSavedThemes(): List<String> {
        val arr = JSONArray(prefs.getString("themes", "[]"))
        return buildList { for (i in 0 until arr.length()) add(arr.getString(i)) }
    }
}
