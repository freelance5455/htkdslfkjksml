package com.aura.customizer.widgets

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.widget.RemoteViews
import com.aura.customizer.R
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AuraClockWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { id ->
            val views = RemoteViews(context.packageName, R.layout.clock_widget)
            val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            val date = SimpleDateFormat("EEE • dd MMM", Locale.getDefault()).format(Date()).uppercase()
            views.setTextViewText(R.id.clock_time, time)
            views.setTextViewText(R.id.clock_date, date)
            manager.updateAppWidget(id, views)
        }
    }
}
