# AURA V2 — Aesthetic Phone Customization Studio

A production-oriented Android Studio implementation of the AURA specification.

## Implemented in V2
- Premium dark Compose UI
- Discoverable aesthetic presets with category filters
- Independent Customize workflow
- Live device clock preview with 12/24-hour setting
- Adjustable wallpaper readability overlay
- Android Photo Picker for user photos
- Home / Lock / Both wallpaper application
- Widget Studio catalogue
- Native Clock, Date, Battery, Countdown, Quote and Photo widget providers
- Local saved-theme store
- Data/privacy settings screen
- Minimal permissions
- No launcher replacement pretending to be universal
- No secure lock-screen bypass
- No app deletion, app-data deletion, PIN/password/biometric modification
- WorkManager refresh architecture for future scheduled rotations
- Core configuration remains local/offline

## Android reality
Some features requested in the original specification are OEM/launcher controlled. A third-party app cannot universally:
1. replace every installed app's icon system-wide,
2. replace the secure lock screen,
3. arbitrarily reposition another launcher's widgets,
4. control every music application,
5. guarantee the same behavior on every Android skin.

AURA V2 uses official Android mechanisms where available and presents the limitation instead of faking functionality.

## Security / privacy
- No cleartext network traffic is enabled.
- No full-media permission is requested.
- User-selected images are handled through Android's Photo Picker.
- No spyware, hidden service, credential collection, or destructive device operation is included.
- Network image URLs in the demo discovery feed are only for the sample UI; production release should replace them with original/licensed packaged assets or a controlled content service.

## Build
Open this folder in Android Studio, sync Gradle, and build the debug APK on Android 8.0+.

For a Play Store release, complete:
- release signing,
- privacy policy,
- accessibility review,
- device/OEM testing,
- automated tests,
- licensed/original production assets,
- widget configuration activities,
- proper weather provider integration,
- MediaSession integration for the supported music widget,
- persistent photo-widget configuration,
- full custom-widget editor,
- backup/export/import schema.

### Web UI asset
A standalone AURA interface is included at `app/src/main/assets/index.html`. It is a self-contained HTML/CSS/JavaScript preview of the AURA discovery, customization, widgets, wallpapers, and settings experience. The current Compose app does not automatically launch this HTML file; it is included as a web asset for future WebView/web-layer integration.
