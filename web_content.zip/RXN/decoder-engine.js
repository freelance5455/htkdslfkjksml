
/*
 * RAXEN Decoder Engine v1.0
 * RAXEN Symbol + AES-256-GCM
 *
 * Requires:
 * 1. raxen-symbol.js
 * 2. raxen-crypto.js
 */

"use strict";

(function (root) {

  function checkDependencies() {
    if (!root.RaxenSymbol) {
      throw new Error("RAXEN Symbol Engine unavailable.");
    }

    if (!root.RaxenCrypto) {
      throw new Error("RAXEN Encryption Engine unavailable.");
    }

    if (!root.crypto || !root.crypto.subtle) {
      throw new Error("Web Crypto API unavailable.");
    }
  }

  function inspectPackage(packageText) {
    if (typeof packageText !== "string") {
      throw new TypeError("Package must be a string.");
    }

    let pkg;

    try {
      pkg = JSON.parse(packageText);
    } catch (error) {
      throw new Error("Invalid RAXEN package format.");
    }

    if (
      !pkg ||
      pkg.format !== "RAXEN-PROTECTED" ||
      pkg.version !== 1 ||
      pkg.algorithm !== "AES-256-GCM" ||
      pkg.kdf !== "PBKDF2-SHA256"
    ) {
      throw new Error("Unsupported RAXEN package.");
    }

    if (
      !Number.isInteger(pkg.iterations) ||
      pkg.iterations !== 250000
    ) {
      throw new Error("Invalid key derivation settings.");
    }

    if (
      typeof pkg.salt !== "string" ||
      typeof pkg.iv !== "string" ||
      typeof pkg.data !== "string"
    ) {
      throw new Error("Incomplete RAXEN package.");
    }

    return {
      format: pkg.format,
      version: pkg.version,
      algorithm: pkg.algorithm,
      kdf: pkg.kdf,
      iterations: pkg.iterations
    };
  }

  async function decodePackage(packageText, password) {
    checkDependencies();

    // Validate package structure first.
    const metadata = inspectPackage(packageText);

    // Decrypt and authenticate using AES-GCM.
    // RaxenCrypto internally decodes RAXEN symbols.
    const originalText = await root.RaxenCrypto.decryptText(
      packageText,
      password
    );

    return {
      success: true,
      metadata: metadata,
      text: originalText
    };
  }

  const api = Object.freeze({
    version: "1.0",
    inspectPackage,
    decodePackage
  });

  root.RaxenDecoder = api;

})(globalThis);
