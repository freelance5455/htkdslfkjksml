/*
 * RAXEN Symbol Engine v1.0
 * "." = 0, "+" = 1, "!" = 2
 * Reversible encoding only — NOT encryption.
 */
"use strict";

(function (root) {
  const SYMBOLS = [".", "+", "!"];
  const SYMBOL_TO_VALUE = new Map([[".", 0], ["+", 1], ["!", 2]]);
  const SYMBOLS_PER_BYTE = 6;

  function assertUint8Array(input) {
    if (!(input instanceof Uint8Array)) throw new TypeError("RAXEN expects a Uint8Array.");
  }

  function encodeBytes(input) {
    assertUint8Array(input);
    let output = "";
    for (let i = 0; i < input.length; i++) {
      let value = input[i];
      const digits = new Array(SYMBOLS_PER_BYTE);
      for (let j = SYMBOLS_PER_BYTE - 1; j >= 0; j--) {
        digits[j] = SYMBOLS[value % 3];
        value = Math.floor(value / 3);
      }
      output += digits.join("");
    }
    return output;
  }

  function decodeBytes(encoded) {
    if (typeof encoded !== "string") throw new TypeError("RAXEN input must be a string.");
    if (encoded.length % SYMBOLS_PER_BYTE !== 0) {
      throw new Error("Invalid RAXEN length: expected groups of six symbols.");
    }
    const output = new Uint8Array(encoded.length / SYMBOLS_PER_BYTE);
    for (let i = 0; i < encoded.length; i += SYMBOLS_PER_BYTE) {
      let value = 0;
      for (let j = 0; j < SYMBOLS_PER_BYTE; j++) {
        const digit = SYMBOL_TO_VALUE.get(encoded[i + j]);
        if (digit === undefined) throw new Error("Invalid RAXEN symbol at position " + (i + j) + ".");
        value = value * 3 + digit;
      }
      if (value > 255) throw new Error("Invalid RAXEN byte value in group " + (i / 6) + ".");
      output[i / SYMBOLS_PER_BYTE] = value;
    }
    return output;
  }

  function encodeText(text) {
    if (typeof text !== "string") throw new TypeError("RAXEN text input must be a string.");
    return encodeBytes(new TextEncoder().encode(text));
  }

  function decodeText(encoded) {
    return new TextDecoder("utf-8", { fatal: true }).decode(decodeBytes(encoded));
  }

  const api = Object.freeze({
    version: "1.0",
    alphabet: Object.freeze([".", "+", "!"]),
    symbolsPerByte: SYMBOLS_PER_BYTE,
    encodeBytes, decodeBytes, encodeText, decodeText
  });

  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else root.RaxenSymbol = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
