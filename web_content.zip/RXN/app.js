
"use strict";

// ======================================
// RAXEN PROTECTOR - APP CONTROLLER
// ======================================

// DOM ELEMENTS
const createBtn = document.getElementById("createBtn");
const zipBtn = document.getElementById("zipBtn");
const htmlBtn = document.getElementById("htmlBtn");

const zipInput = document.getElementById("zipInput");
const htmlInput = document.getElementById("htmlInput");

const projectName = document.getElementById("projectName");
const fileInfo = document.getElementById("fileInfo");
const message = document.getElementById("message");

const passwordInput = document.getElementById("protectionPassword");
const protectBtn = document.getElementById("protectBtn");
const downloadBtn = document.getElementById("downloadBtn");
const protectedOutput = document.getElementById("protectedOutput");

const raxenInput = document.getElementById("raxenInput");
const restorePassword = document.getElementById("restorePassword");
const restoreBtn = document.getElementById("restoreBtn");
const restoreDownloadBtn = document.getElementById("restoreDownloadBtn");
const restoredOutput = document.getElementById("restoredOutput");
const restoreMessage = document.getElementById("restoreMessage");

const engineStatuses = document.querySelectorAll(".engine b");

// APP DATA
let selectedHTMLFile = null;
let protectedPackage = null;
let protectedFileName = "protected.raxen";

let selectedProtectedFile = null;
let restoredHTML = null;
let restoredFileName = "restored.html";

const GREEN = "#00e676";
const RED = "#ff4444";
const YELLOW = "#ffca28";

// ======================================
// GENERAL FUNCTIONS
// ======================================

function showMessage(text) {
  if (message) message.textContent = text;
}

function showRestoreMessage(text, color) {
  if (!restoreMessage) return;

  restoreMessage.textContent = text;

  if (color) {
    restoreMessage.style.color = color;
  }
}

function setEngineStatus(index, status, color) {
  const element = engineStatuses[index];

  if (!element) return;

  element.textContent = status;
  element.style.color = color;
}

function downloadTextFile(content, fileName, mimeType) {
  const blob = new Blob(
    [content],
    { type: mimeType }
  );

  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");

  link.href = url;
  link.download = fileName;

  document.body.appendChild(link);
  link.click();
  link.remove();

  // Allow the browser time to begin the download.
  setTimeout(function () {
    URL.revokeObjectURL(url);
  }, 1000);
}

// ======================================
// 1. SYMBOL ENGINE TEST
// ======================================

function testRaxenEngine() {
  try {
    if (!window.RaxenSymbol) {
      throw new Error("RAXEN Symbol Engine not loaded.");
    }

    const original = "RAXEN PROTECTOR TEST";
    const encoded = RaxenSymbol.encodeText(original);
    const decoded = RaxenSymbol.decodeText(encoded);

    if (decoded !== original) {
      throw new Error("Symbol test failed.");
    }

    setEngineStatus(0, "WORKING", GREEN);
    return true;

  } catch (error) {
    setEngineStatus(0, "ERROR", RED);
    showMessage("Symbol Engine Error: " + error.message);
    return false;
  }
}

// ======================================
// 2. ENCRYPTION ENGINE TEST
// ======================================

async function testEncryptionEngine() {
  try {
    if (!window.RaxenCrypto) {
      throw new Error("Encryption Engine not loaded.");
    }

    const original = "RAXEN ENCRYPTION TEST";
    const password = "RAXEN-Test-Password-2026";

    const encrypted = await RaxenCrypto.encryptText(
      original,
      password
    );

    const decrypted = await RaxenCrypto.decryptText(
      encrypted,
      password
    );

    if (decrypted !== original) {
      throw new Error("Encryption test failed.");
    }

    let rejected = false;

    try {
      await RaxenCrypto.decryptText(
        encrypted,
        "Wrong-Test-Password"
      );
    } catch (error) {
      rejected = true;
    }

    if (!rejected) {
      throw new Error("Wrong password was accepted.");
    }

    setEngineStatus(1, "WORKING", GREEN);
    return true;

  } catch (error) {
    setEngineStatus(1, "ERROR", RED);
    showMessage("Encryption Error: " + error.message);
    return false;
  }
}

// ======================================
// 3. DECODER ENGINE TEST
// ======================================

async function testDecoderEngine() {
  try {
    if (!window.RaxenDecoder) {
      throw new Error("Decoder Engine not loaded.");
    }

    const original = "RAXEN DECODER TEST";
    const password = "RAXEN-Decoder-Test-2026";

    const encrypted = await RaxenCrypto.encryptText(
      original,
      password
    );

    const result = await RaxenDecoder.decodePackage(
      encrypted,
      password
    );

    if (!result.success || result.text !== original) {
      throw new Error("Decoder test failed.");
    }

    setEngineStatus(2, "WORKING", GREEN);
    return true;

  } catch (error) {
    setEngineStatus(2, "ERROR", RED);
    showMessage("Decoder Error: " + error.message);
    return false;
  }
}

// ======================================
// 4. CREATE PROJECT
// ======================================

if (createBtn) {
  createBtn.addEventListener("click", function () {
    if (projectName) {
      projectName.textContent = "New RAXEN Project";
    }

    if (fileInfo) {
      fileInfo.textContent = "Project created successfully.";
    }

    showMessage("RAXEN Project Initialized Successfully!");
  });
}

// ======================================
// 5. IMPORT ZIP
// ======================================

if (zipBtn && zipInput) {
  zipBtn.addEventListener("click", function () {
    zipInput.click();
  });

  zipInput.addEventListener("change", function () {
    const file = zipInput.files[0];

    if (!file) return;

    if (projectName) projectName.textContent = file.name;

    if (fileInfo) {
      fileInfo.textContent =
        "ZIP selected: " + file.size + " bytes";
    }

    showMessage(
      "ZIP selected. ZIP extraction is not implemented yet."
    );
  });
}

// ======================================
// 6. IMPORT HTML
// ======================================

if (htmlBtn && htmlInput) {
  htmlBtn.addEventListener("click", function () {
    htmlInput.click();
  });

  htmlInput.addEventListener("change", function () {
    const file = htmlInput.files[0];

    if (!file) return;

    selectedHTMLFile = file;
    protectedPackage = null;

    if (downloadBtn) downloadBtn.disabled = true;
    if (protectedOutput) protectedOutput.value = "";

    if (projectName) projectName.textContent = file.name;

    if (fileInfo) {
      fileInfo.textContent =
        "HTML selected: " + file.size + " bytes";
    }

    showMessage(
      "HTML file selected. Enter a password and press Protect HTML."
    );
  });
}

// ======================================
// 7. PROTECT HTML
// ======================================

if (protectBtn) {
  protectBtn.addEventListener("click", async function () {
    try {
      if (!selectedHTMLFile) {
        throw new Error("Please import an HTML file first.");
      }

      if (!window.RaxenCrypto) {
        throw new Error("Encryption Engine unavailable.");
      }

      const password = passwordInput
        ? passwordInput.value
        : "";

      if (!password || password.length < 8) {
        throw new Error(
          "Password must contain at least 8 characters."
        );
      }

      protectBtn.disabled = true;
      showMessage("Reading HTML file...");

      const htmlContent = await selectedHTMLFile.text();

      if (!htmlContent.trim()) {
        throw new Error("The selected HTML file is empty.");
      }

      showMessage("Encrypting HTML with AES-256-GCM...");

      const encrypted = await RaxenCrypto.encryptText(
        htmlContent,
        password
      );

      if (window.RaxenDecoder) {
        RaxenDecoder.inspectPackage(encrypted);
      }

      protectedPackage = encrypted;

      protectedFileName =
        selectedHTMLFile.name.replace(/\.html?$/i, "") +
        ".raxen";

      if (protectedOutput) {
        protectedOutput.value = encrypted;
      }

      if (downloadBtn) {
        downloadBtn.disabled = false;
      }

      showMessage(
        "HTML protection successful. Your RAXEN package is ready."
      );

    } catch (error) {
      protectedPackage = null;

      if (downloadBtn) {
        downloadBtn.disabled = true;
      }

      showMessage("Protection Error: " + error.message);

    } finally {
      protectBtn.disabled = false;
    }
  });
}

// ======================================
// 8. DOWNLOAD PROTECTED FILE
// ======================================

if (downloadBtn) {
  downloadBtn.addEventListener("click", function () {
    if (!protectedPackage) {
      showMessage("No protected package available.");
      return;
    }

    try {
      downloadTextFile(
        protectedPackage,
        protectedFileName,
        "application/json;charset=utf-8"
      );

      showMessage(
        "Protected RAXEN file download requested."
      );

    } catch (error) {
      showMessage("Download Error: " + error.message);
    }
  });
}

// ======================================
// 9. IMPORT PROTECTED RAXEN FILE
// ======================================

if (raxenInput) {
  raxenInput.addEventListener("change", function () {
    const file = raxenInput.files[0];

    if (!file) return;

    selectedProtectedFile = file;
    restoredHTML = null;

    if (restoreDownloadBtn) {
      restoreDownloadBtn.disabled = true;
    }

    if (restoredOutput) {
      restoredOutput.value = "";
    }

    if (restorePassword) {
      restorePassword.value = "";
    }

    showRestoreMessage(
      "Protected file selected: " + file.name,
      GREEN
    );
  });
}

// ======================================
// 10. RESTORE / DECRYPT HTML
// ======================================

if (restoreBtn) {
  restoreBtn.addEventListener("click", async function () {
    try {
      if (!selectedProtectedFile) {
        throw new Error("Please import a .raxen file first.");
      }

      if (!window.RaxenDecoder) {
        throw new Error("Decoder Engine unavailable.");
      }

      const password = restorePassword
        ? restorePassword.value
        : "";

      if (!password) {
        throw new Error("Please enter your decryption password.");
      }

      restoreBtn.disabled = true;
      restoredHTML = null;

      if (restoreDownloadBtn) {
        restoreDownloadBtn.disabled = true;
      }

      if (restoredOutput) {
        restoredOutput.value = "";
      }

      showRestoreMessage(
        "Reading protected RAXEN package...",
        YELLOW
      );

      const packageText = await selectedProtectedFile.text();

      if (!packageText.trim()) {
        throw new Error("The protected file is empty.");
      }

      showRestoreMessage(
        "Checking package and decrypting...",
        YELLOW
      );

      const result = await RaxenDecoder.decodePackage(
        packageText,
        password
      );

      if (!result || result.success !== true) {
        throw new Error("Decryption was unsuccessful.");
      }

      if (typeof result.text !== "string") {
        throw new Error("Restored content is invalid.");
      }

      restoredHTML = result.text;

      restoredFileName =
        selectedProtectedFile.name.replace(/\.raxen$/i, "") +
        ".restored.html";

      if (restoredOutput) {
        restoredOutput.value = restoredHTML;
      }

      if (restoreDownloadBtn) {
        restoreDownloadBtn.disabled = false;
      }

      showRestoreMessage(
        "SUCCESS: HTML restored. You can now download it.",
        GREEN
      );

    } catch (error) {
      restoredHTML = null;

      if (restoreDownloadBtn) {
        restoreDownloadBtn.disabled = true;
      }

      if (restoredOutput) {
        restoredOutput.value = "";
      }

      showRestoreMessage(
        "RESTORATION FAILED: " + error.message,
        RED
      );

    } finally {
      restoreBtn.disabled = false;
    }
  });
}

// ======================================
// 11. DOWNLOAD RESTORED HTML
// ======================================

if (restoreDownloadBtn) {
  restoreDownloadBtn.addEventListener("click", function () {
    if (typeof restoredHTML !== "string") {
      showRestoreMessage(
        "No restored HTML available.",
        RED
      );
      return;
    }

    try {
      downloadTextFile(
        restoredHTML,
        restoredFileName,
        "text/html;charset=utf-8"
      );

      showRestoreMessage(
        "Restored HTML download requested.",
        GREEN
      );

    } catch (error) {
      showRestoreMessage(
        "Download Error: " + error.message,
        RED
      );
    }
  });
}

// ======================================
// 12. INITIALIZE ALL ENGINES
// ======================================

async function initializeRaxen() {
  const symbolWorking = testRaxenEngine();

  if (!symbolWorking) {
    setEngineStatus(1, "BLOCKED", YELLOW);
    setEngineStatus(2, "BLOCKED", YELLOW);
    return;
  }

  const encryptionWorking = await testEncryptionEngine();

  if (!encryptionWorking) {
    setEngineStatus(2, "BLOCKED", YELLOW);
    return;
  }

  await testDecoderEngine();
}

initializeRaxen();
