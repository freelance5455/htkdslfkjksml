
/*
 * RAXEN Encryption Engine v1.0
 * AES-256-GCM + PBKDF2
 * Requires raxen-symbol.js
 */

"use strict";

(function (root) {
  const ITERATIONS = 250000;
  const SALT_LENGTH = 16;
  const IV_LENGTH = 12;

  function getEngine() {
    if (!root.RaxenSymbol) {
      throw new Error("RAXEN Symbol Engine not loaded.");
    }

    if (!root.crypto || !root.crypto.subtle) {
      throw new Error(
        "Web Crypto API unavailable. Secure context required."
      );
    }

    return root.crypto.subtle;
  }

  function randomBytes(length) {
    const bytes = new Uint8Array(length);
    root.crypto.getRandomValues(bytes);
    return bytes;
  }

  async function deriveKey(password, salt) {
    if (typeof password !== "string" || password.length < 8) {
      throw new Error("Password must contain at least 8 characters.");
    }

    const subtle = getEngine();

    const material = await subtle.importKey(
      "raw",
      new TextEncoder().encode(password),
      "PBKDF2",
      false,
      ["deriveKey"]
    );

    return subtle.deriveKey(
      {
        name: "PBKDF2",
        salt: salt,
        iterations: ITERATIONS,
        hash: "SHA-256"
      },
      material,
      {
        name: "AES-GCM",
        length: 256
      },
      false,
      ["encrypt", "decrypt"]
    );
  }

  async function encryptText(plainText, password) {
    const subtle = getEngine();

    if (typeof plainText !== "string") {
      throw new TypeError("Input must be text.");
    }

    const salt = randomBytes(SALT_LENGTH);
    const iv = randomBytes(IV_LENGTH);
    const key = await deriveKey(password, salt);

    const encrypted = await subtle.encrypt(
      {
        name: "AES-GCM",
        iv: iv
      },
      key,
      new TextEncoder().encode(plainText)
    );

    return JSON.stringify({
      format: "RAXEN-PROTECTED",
      version: 1,
      algorithm: "AES-256-GCM",
      kdf: "PBKDF2-SHA256",
      iterations: ITERATIONS,
      salt: root.RaxenSymbol.encodeBytes(salt),
      iv: root.RaxenSymbol.encodeBytes(iv),
      data: root.RaxenSymbol.encodeBytes(
        new Uint8Array(encrypted)
      )
    });
  }

  async function decryptText(packageText, password) {
    const subtle = getEngine();

    const pkg = JSON.parse(packageText);

    if (
      pkg.format !== "RAXEN-PROTECTED" ||
      pkg.version !== 1 ||
      pkg.algorithm !== "AES-256-GCM" ||
      pkg.kdf !== "PBKDF2-SHA256" ||
      pkg.iterations !== ITERATIONS
    ) {
      throw new Error("Unsupported or invalid RAXEN package.");
    }

    const salt = root.RaxenSymbol.decodeBytes(pkg.salt);
    const iv = root.RaxenSymbol.decodeBytes(pkg.iv);
    const data = root.RaxenSymbol.decodeBytes(pkg.data);

    if (
      salt.length !== SALT_LENGTH ||
      iv.length !== IV_LENGTH
    ) {
      throw new Error("Invalid encryption metadata.");
    }

    const key = await deriveKey(password, salt);

    const decrypted = await subtle.decrypt(
      {
        name: "AES-GCM",
        iv: iv
      },
      key,
      data
    );

    return new TextDecoder("utf-8", {
      fatal: true
    }).decode(decrypted);
  }

  root.RaxenCrypto = Object.freeze({
    version: "1.0",
    algorithm: "AES-256-GCM",
    encryptText,
    decryptText
  });

})(globalThis);
