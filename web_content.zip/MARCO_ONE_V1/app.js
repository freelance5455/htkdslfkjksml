import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import {
  getAuth, GoogleAuthProvider, signInWithPopup, onAuthStateChanged, signOut
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";

// إعدادات Firebase التي أرسلها صاحب المشروع
const firebaseConfig = {
  apiKey: "AIzaSyD8tsgA4Tu1lzu59AOAK1LjH1RptWMxVrk",
  authDomain: "marco-arena.firebaseapp.com",
  projectId: "marco-arena",
  storageBucket: "marco-arena.firebasestorage.app",
  messagingSenderId: "327613084379",
  appId: "1:327613084379:web:04e4b4795029af74d3d2fe",
  measurementId: "G-J796TTE1PQ"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const provider = new GoogleAuthProvider();
provider.setCustomParameters({ prompt: "select_account" });

const $ = (id) => document.getElementById(id);
const welcome = $("welcome");
const dashboard = $("dashboard");
const loginButton = $("googleLogin");
const authMessage = $("authMessage");

function showToast(message) {
  const toast = $("toast");
  toast.textContent = message;
  toast.classList.add("show");
  window.setTimeout(() => toast.classList.remove("show"), 2800);
}

loginButton.addEventListener("click", async () => {
  loginButton.disabled = true;
  loginButton.style.opacity = ".7";
  authMessage.textContent = "جارٍ فتح نافذة Google...";
  try {
    await signInWithPopup(auth, provider);
  } catch (error) {
    console.error("Google sign-in error:", error);
    const messages = {
      "auth/popup-closed-by-user": "تم إغلاق نافذة تسجيل الدخول قبل اكتمال العملية.",
      "auth/unauthorized-domain": "هذا النطاق غير مضاف في Firebase Authorized domains.",
      "auth/operation-not-allowed": "فعّل Google من Firebase Authentication > Sign-in method.",
      "auth/popup-blocked": "المتصفح منع النافذة المنبثقة. اسمح بالنوافذ المنبثقة وحاول مرة أخرى."
    };
    authMessage.textContent = messages[error.code] || "تعذر تسجيل الدخول. راجع إعدادات Firebase وحاول مرة أخرى.";
  } finally {
    loginButton.disabled = false;
    loginButton.style.opacity = "1";
  }
});

$("logoutBtn").addEventListener("click", async () => {
  try {
    await signOut(auth);
    showToast("تم تسجيل الخروج بنجاح");
  } catch (error) {
    console.error(error);
    showToast("تعذر تسجيل الخروج، حاول مرة أخرى");
  }
});

onAuthStateChanged(auth, (user) => {
  if (user) {
    welcome.classList.add("hidden");
    dashboard.classList.remove("hidden");
    $("profileName").textContent = user.displayName || "مستخدم MARCO";
    $("profileEmail").textContent = user.email || "";
    $("miniName").textContent = user.displayName || "حسابي";
    const photo = user.photoURL || "https://www.gravatar.com/avatar/?d=mp&s=120";
    $("profilePhoto").src = photo;
    $("miniPhoto").src = photo;
    $("userMini").classList.remove("hidden");
    authMessage.textContent = "تم تسجيل الدخول";
  } else {
    dashboard.classList.add("hidden");
    welcome.classList.remove("hidden");
    $("userMini").classList.add("hidden");
  }
});

$("themeBtn").addEventListener("click", () => {
  document.body.classList.toggle("light");
});

document.querySelectorAll(".feature-card").forEach((card) => {
  card.addEventListener("click", () => {
    const names = { ai: "MARCO AI", design: "استوديو الصور", learn: "منطقة التعلم", tools: "الأدوات الذكية" };
    showToast(`${names[card.dataset.feature]} — سيتم تفعيل هذه الخدمة في تحديث قادم.`);
  });
});
