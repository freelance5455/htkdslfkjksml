# MARCO ONE V1.0

واجهة ويب عربية متجاوبة مع تسجيل دخول Google باستخدام Firebase Authentication.

## تشغيل المشروع
1. افتح Firebase Console للمشروع `marco-arena`.
2. اذهب إلى Authentication > Sign-in method وفعّل Google.
3. من Authentication > Settings > Authorized domains أضف نطاق الاستضافة الذي ستستخدمه.
4. شغّل المشروع من خلال خادم محلي (لا تفتح index.html مباشرة من file://).

مثال باستخدام إضافة Live Server في VS Code:
- افتح المجلد في VS Code.
- شغّل Live Server على index.html.

## النشر
يمكن نشر المجلد على Firebase Hosting أو أي استضافة HTTPS. بعد النشر أضف اسم النطاق إلى Authorized domains في Firebase.

## ملاحظات
- اسم وصورة المستخدم والبريد تُقرأ من بيانات Google التي يعيدها Firebase Authentication بعد نجاح تسجيل الدخول.
- لا تضع مفاتيح Service Account أو مفاتيح إدارية داخل تطبيق الواجهة.
- إعدادات Firebase Web config الموجودة في app.js تخص تطبيق الويب، لكنها لا تغني عن إعداد قواعد Firestore/Storage عند إضافة تخزين بيانات لاحقًا.
- أقسام MARCO AI وتصميم الصور والدراسة والأدوات هي واجهات أولية، وليست خدمات ذكاء اصطناعي متصلة بعد.
- قبل استخدام التطبيق على نطاق واسع، أضف سياسة خصوصية وشروط استخدام، واضبط Authorized domains وقواعد الأمان.
