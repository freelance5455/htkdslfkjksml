'use strict';
require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');

class UpErr extends Error { constructor(kind) { super(kind); this.kind = kind; } }
const MSG = {
  http: 'The service is temporarily unavailable. Please try again.',
  json: 'The service returned an unexpected reply. Please try again.',
  timeout: 'The request took too long. Please try again.',
  network: 'Could not reach the service. Check your connection and retry.',
  empty: 'The assistant returned an empty reply. Please retry.',
  shape: 'The service returned an unexpected reply. Please try again.'
};

function normalizeVoices(d) {
  let a = Array.isArray(d) ? d : d && (d.voices || d.result || d.data || d.list);
  if (a && !Array.isArray(a) && typeof a === 'object') {
    a = a.voices || a.list || Object.entries(a).map(([k, v]) => (typeof v === 'string' ? { id: k, name: v } : { id: k, ...v }));
  }
  if (!Array.isArray(a)) return null;
  const seen = new Set(), out = [];
  for (const o of a) {
    const v = typeof o === 'string' ? { id: o, name: o } : o && typeof o === 'object' ? {
      id: String(o.id || o.voice || o.ShortName || o.short_name || o.name || '').trim(),
      name: String(o.name || o.DisplayName || o.display_name || o.id || o.voice || '').trim(),
      language: o.language || o.locale || o.lang || o.Locale || '',
      gender: o.gender || o.Gender || ''
    } : null;
    if (!v || !v.id || seen.has(v.id)) continue;
    if (!v.name) v.name = v.id;
    seen.add(v.id); out.push({ id: v.id, name: v.name, language: String(v.language || ''), gender: String(v.gender || '') });
  }
  return out;
}

function createApp({ fetchImpl = fetch, env = process.env } = {}) {
  const AI = env.DEEPSEEK_ENDPOINT, TTS = env.AIRMORE_ENDPOINT;
  const TIMEOUT = Number(env.REQUEST_TIMEOUT_MS) || 30000;
  const app = express();
  app.disable('x-powered-by');
  app.use(helmet({ contentSecurityPolicy: { directives: {
    defaultSrc: ["'self'"], mediaSrc: ["'self'", 'https:'], imgSrc: ["'self'", 'data:'],
    connectSrc: ["'self'"], 'upgrade-insecure-requests': null } } }));
  app.use(express.json({ limit: '16kb' }));
  app.use('/api', rateLimit({ windowMs: 60000, limit: Number(env.RATE_LIMIT) || 60, standardHeaders: true, legacyHeaders: false,
    message: { success: false, error: 'Too many requests. Please slow down.' } }));

  async function getJson(url) {
    const ac = new AbortController(), t = setTimeout(() => ac.abort(), TIMEOUT);
    try {
      const r = await fetchImpl(url, { signal: ac.signal, headers: { Accept: 'application/json' } });
      if (!r.ok) throw new UpErr('http');
      const txt = await r.text();
      try { return JSON.parse(txt); } catch { throw new UpErr('json'); }
    } catch (e) {
      if (e instanceof UpErr) throw e;
      throw new UpErr(e && e.name === 'AbortError' ? 'timeout' : 'network');
    } finally { clearTimeout(t); }
  }
  const fail = (res, e) => {
    const kind = e instanceof UpErr ? e.kind : 'network';
    res.status(kind === 'timeout' ? 504 : 502).json({ success: false, error: MSG[kind] || MSG.network });
  };
  const bad = (res, m) => res.status(400).json({ success: false, error: m });

  app.get('/api/health', (req, res) => res.json({ status: 'ok' }));

  app.post('/api/chat', async (req, res) => {
    const p = req.body && typeof req.body.prompt === 'string' ? req.body.prompt.trim() : '';
    if (!p) return bad(res, 'Please enter a message.');
    if (p.length > 4000) return bad(res, 'Message is too long (max 4000 characters).');
    try {
      const u = new URL(AI); u.searchParams.set('prompt', p);
      const d = await getJson(u);
      if (!d || typeof d !== 'object' || d.success === false) throw new UpErr('shape');
      const r = typeof d.response === 'string' ? d.response.trim() : '';
      if (!r) throw new UpErr('empty');
      res.json({ success: true, response: r });
    } catch (e) { fail(res, e); }
  });

  app.get('/api/voices', async (req, res) => {
    try {
      const u = new URL(TTS); u.searchParams.set('list', 'voices');
      const voices = normalizeVoices(await getJson(u));
      if (!voices) throw new UpErr('shape');
      res.json({ success: true, voices });
    } catch (e) { fail(res, e); }
  });

  app.post('/api/tts', async (req, res) => {
    const text = req.body && typeof req.body.text === 'string' ? req.body.text.trim() : '';
    const voice = req.body && req.body.voice;
    if (!text) return bad(res, 'Nothing to speak.');
    if (text.length > 1500) return bad(res, 'Text is too long to speak (max 1500 characters).');
    if (voice != null && (typeof voice !== 'string' || !/^[\w.\- ]{1,100}$/.test(voice))) return bad(res, 'Invalid voice.');
    try {
      const u = new URL(TTS); u.searchParams.set('text', text);
      if (voice) u.searchParams.set('voice', voice);
      const d = await getJson(u);
      const url = d && d.result && d.result.audio_url;
      if (!url || !/^https?:\/\//i.test(url)) throw new UpErr('shape');
      res.json({ success: true, audioUrl: url });
    } catch (e) { fail(res, e); }
  });

  app.use(express.static(path.join(__dirname, 'public')));
  app.use((err, req, res, next) => bad(res, 'Invalid request.'));
  return app;
}

module.exports = { createApp, normalizeVoices };
if (require.main === module) {
  const port = Number(process.env.PORT) || 3000;
  if (!process.env.DEEPSEEK_ENDPOINT || !process.env.AIRMORE_ENDPOINT) { console.error('Missing endpoint configuration. Copy .env.example to .env.'); process.exit(1); }
  createApp().listen(port, () => console.log(`RAUF AI ASSISTANT running on port ${port}`));
}
