const test = require('node:test'); const assert = require('node:assert');
const { createApp, normalizeVoices } = require('../server');
const env = { DEEPSEEK_ENDPOINT: 'https://x.test/ai', AIRMORE_ENDPOINT: 'https://x.test/tts', REQUEST_TIMEOUT_MS: '200', RATE_LIMIT: '1000' };
const ok = (b) => async () => ({ ok: true, text: async () => (typeof b === 'string' ? b : JSON.stringify(b)) });
async function run(fetchImpl, path, opts, e = env) {
  const s = createApp({ fetchImpl, env: e }).listen(0);
  try { const r = await fetch(`http://127.0.0.1:${s.address().port}${path}`, opts); return { status: r.status, body: await r.json() }; } finally { s.close(); }
}
const post = (b) => ({ method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(b) });
test('health', async () => assert.equal((await run(ok({}), '/api/health')).body.status, 'ok'));
test('chat ok', async () => { const r = await run(ok({ success: true, response: 'Hi' }), '/api/chat', post({ prompt: 'Hello' })); assert.equal(r.body.response, 'Hi'); });
test('chat empty prompt', async () => assert.equal((await run(ok({}), '/api/chat', post({ prompt: '  ' }))).status, 400));
test('chat upstream http error', async () => assert.equal((await run(async () => ({ ok: false }), '/api/chat', post({ prompt: 'a' }))).status, 502));
test('chat invalid json', async () => assert.equal((await run(ok('<html>'), '/api/chat', post({ prompt: 'a' }))).status, 502));
test('chat empty response', async () => assert.equal((await run(ok({ success: true, response: '' }), '/api/chat', post({ prompt: 'a' }))).status, 502));
test('chat timeout', async () => {
  const slow = (u, { signal }) => new Promise((_, rej) => signal.addEventListener('abort', () => rej(Object.assign(new Error('a'), { name: 'AbortError' }))));
  assert.equal((await run(slow, '/api/chat', post({ prompt: 'a' }))).status, 504);
});
test('voices parse + empty', async () => {
  assert.equal(normalizeVoices({ result: [{ name: 'A', locale: 'en-US' }, 'B'] }).length, 2);
  assert.deepEqual(normalizeVoices([]), []); assert.equal(normalizeVoices('x'), null);
});
test('tts passes voice and parses audio_url', async () => {
  let seen; const f = async (u) => { seen = new URL(u); return { ok: true, text: async () => JSON.stringify({ status: true, result: { audio_url: 'https://a.test/a.mp3' } }) }; };
  const r = await run(f, '/api/tts', post({ text: 'Hi', voice: 'Zed' }));
  assert.equal(r.body.audioUrl, 'https://a.test/a.mp3'); assert.equal(seen.searchParams.get('voice'), 'Zed');
});
test('rate limit', async () => {
  const s = createApp({ fetchImpl: ok({}), env: { ...env, RATE_LIMIT: '2' } }).listen(0); const u = `http://127.0.0.1:${s.address().port}/api/health`;
  try { await fetch(u); await fetch(u); assert.equal((await fetch(u)).status, 429); } finally { s.close(); }
});
