'use strict';
const $ = (id) => document.getElementById(id);
const store = { get(k, d) { try { return localStorage.getItem(k) ?? d; } catch { return d; } }, set(k, v) { try { localStorage.setItem(k, v); } catch {} } };
const S = { busy: false, voice: store.get('voiceId', ''), voiceName: store.get('voiceName', ''), voiceOn: store.get('voiceOn', '0') === '1', voices: [], audio: null, ttsBusy: false };
const chat = $('chat'), input = $('input'), sendBtn = $('send');

async function api(path, opts) {
  let r; try { r = await fetch(path, { headers: { 'Content-Type': 'application/json' }, ...opts }); } catch { throw new Error('You appear to be offline. Check your connection.'); }
  let d; try { d = await r.json(); } catch { throw new Error('Unexpected reply from the app server.'); }
  if (!r.ok || !d.success) throw new Error(d.error || 'Something went wrong. Please try again.');
  return d;
}
function showErr(m, retry) {
  const e = $('err'); e.hidden = false; e.textContent = '';
  const s = document.createElement('span'); s.textContent = m; e.append(s);
  if (retry) { const b = document.createElement('button'); b.className = 'ghost'; b.textContent = 'Retry'; b.onclick = () => { e.hidden = true; retry(); }; e.append(b); }
}
function addMsg(role, text, cls = '') {
  $('welcome')?.remove();
  const d = document.createElement('div'); d.className = `msg ${role} ${cls}`;
  const p = document.createElement('div'); p.textContent = text; d.append(p);
  if (role === 'bot' && !cls) {
    const t = document.createElement('div'); t.className = 'tools';
    const c = document.createElement('button'); c.textContent = 'Copy';
    c.onclick = async () => { try { await navigator.clipboard.writeText(text); c.textContent = 'Copied'; setTimeout(() => (c.textContent = 'Copy'), 1500); } catch { showErr('Copy is not available here.'); } };
    const s = document.createElement('button'); s.textContent = '🔊 Speak'; s.onclick = () => speak(text, s);
    t.append(c, s); d.append(t); d._speak = s;
  }
  chat.append(d); chat.scrollTop = chat.scrollHeight; return d;
}
async function send(textOverride) {
  const prompt = (textOverride ?? input.value).trim();
  if (!prompt || S.busy) return;
  S.busy = true; sendBtn.disabled = true; $('err').hidden = true;
  addMsg('user', prompt); if (textOverride == null) { input.value = ''; grow(); }
  const wait = addMsg('bot', 'Thinking…', 'typing');
  try {
    const d = await api('/api/chat', { method: 'POST', body: JSON.stringify({ prompt }) });
    wait.remove(); const m = addMsg('bot', d.response);
    if (S.voiceOn) speak(d.response, m._speak);
  } catch (e) {
    wait.remove(); if (textOverride == null) { input.value = prompt; grow(); }
    showErr(e.message, () => send(textOverride));
  } finally { S.busy = false; sendBtn.disabled = false; input.focus(); }
}
function stopAudio() { if (S.audio) { S.audio.pause(); S.audio.removeAttribute('src'); S.audio.load(); S.audio = null; } document.querySelectorAll('.tools button.on, #vtest.on').forEach((b) => { b.classList.remove('on'); b.textContent = b.id === 'vtest' ? 'Test selected voice' : '🔊 Speak'; }); }
async function speak(text, btn) {
  const idle = btn && btn.id === 'vtest' ? 'Test selected voice' : '🔊 Speak';
  if (S.audio) { stopAudio(); return; }
  if (S.ttsBusy) return;
  S.ttsBusy = true; if (btn) btn.textContent = '… Loading';
  try {
    const d = await api('/api/tts', { method: 'POST', body: JSON.stringify({ text: text.slice(0, 1500), voice: S.voice || undefined }) });
    const a = new Audio(d.audioUrl); S.audio = a;
    const done = () => { if (S.audio === a) stopAudio(); if (btn) btn.textContent = idle; };
    a.onended = done; a.onerror = () => { done(); showErr('Audio could not be played. The link may have expired; tap Speak to try again.'); };
    if (btn) { btn.textContent = '■ Stop'; btn.classList.add('on'); }
    await a.play();
  } catch (e) { stopAudio(); if (btn) btn.textContent = idle; showErr(e.message); }
  finally { S.ttsBusy = false; }
}
function grow() { input.style.height = 'auto'; input.style.height = Math.min(input.scrollHeight, 140) + 'px'; }
input.addEventListener('input', grow);
input.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey && matchMedia('(hover:hover)').matches) { e.preventDefault(); send(); } });
$('composer').addEventListener('submit', (e) => { e.preventDefault(); send(); });
document.querySelectorAll('.chip').forEach((c) => (c.onclick = () => send(c.textContent)));

// Microphone (browser/WebView speech recognition; permission requested only on tap)
const SR = window.SpeechRecognition || window.webkitSpeechRecognition; let rec = null;
$('mic').onclick = () => {
  if (!SR) return showErr('Speech input is not supported on this device. You can type instead.');
  if (rec) { rec.stop(); return; }
  rec = new SR(); rec.interimResults = true; rec.lang = navigator.language || 'en-US';
  const base = input.value ? input.value + ' ' : '';
  rec.onstart = () => $('mic').classList.add('live');
  rec.onresult = (e) => { input.value = base + Array.from(e.results).map((r) => r[0].transcript).join(' '); grow(); };
  rec.onerror = (e) => showErr(e.error === 'not-allowed' || e.error === 'service-not-allowed' ? 'Microphone permission was denied. Enable it in your settings to use voice input.' : 'Speech input failed. Please try again.');
  rec.onend = () => { $('mic').classList.remove('live'); rec = null; input.focus(); };
  try { rec.start(); } catch { rec = null; }
};

// Clear chat
$('clearBtn').onclick = () => $('clearDlg').showModal();
$('cNo').onclick = () => $('clearDlg').close();
$('cYes').onclick = () => { stopAudio(); chat.querySelectorAll('.msg').forEach((m) => m.remove()); $('clearDlg').close(); };

// Voices
function renderSel() { $('selName').textContent = S.voiceName || 'Default'; }
function note(l, t) { const n = document.createElement('div'); n.className = 'note'; n.textContent = t; l.append(n); }
function renderVoices() {
  const q = $('vsearch').value.trim().toLowerCase(), l = $('vlist'); l.textContent = '';
  if (!S.voices.length) return note(l, 'No voices available.');
  const items = S.voices.filter((v) => v.name.toLowerCase().includes(q));
  if (!items.length) return note(l, 'No voices match your search.');
  for (const v of items) {
    const b = document.createElement('button'); b.className = 'v' + (v.id === S.voice ? ' on' : '');
    const a = document.createElement('div'); a.textContent = (v.id === S.voice ? '✓ ' : '') + v.name;
    const m = document.createElement('span'); m.textContent = [v.language, v.gender].filter(Boolean).join(' · ');
    b.append(a, m);
    b.onclick = () => { S.voice = v.id; S.voiceName = v.name; store.set('voiceId', v.id); store.set('voiceName', v.name); renderSel(); renderVoices(); };
    l.append(b);
  }
}
async function loadVoices() {
  const l = $('vlist'); l.textContent = ''; note(l, 'Loading voices…');
  try {
    S.voices = (await api('/api/voices')).voices;
    if (S.voice && !S.voices.some((v) => v.id === S.voice)) { S.voice = ''; S.voiceName = ''; store.set('voiceId', ''); store.set('voiceName', ''); renderSel(); }
    renderVoices();
  } catch (e) {
    l.textContent = ''; note(l, e.message);
    const r = document.createElement('button'); r.className = 'ghost'; r.textContent = 'Retry'; r.onclick = loadVoices; l.append(r);
  }
}
$('voiceBtn').onclick = () => { renderSel(); $('voiceOn').checked = S.voiceOn; $('voiceDlg').showModal(); loadVoices(); };
$('vclose').onclick = () => $('voiceDlg').close();
$('vsearch').oninput = renderVoices;
$('voiceOn').onchange = (e) => { S.voiceOn = e.target.checked; store.set('voiceOn', S.voiceOn ? '1' : '0'); };
$('vtest').onclick = () => speak('Hello! This is how I sound.', $('vtest'));

async function health() {
  try { const r = await fetch('/api/health'); const d = await r.json(); if (!r.ok || d.status !== 'ok') throw 0; $('dot').className = 'dot ok'; $('status').textContent = 'Online'; }
  catch { $('dot').className = 'dot bad'; $('status').textContent = 'Offline'; }
}
health(); setInterval(health, 30000); renderSel();
