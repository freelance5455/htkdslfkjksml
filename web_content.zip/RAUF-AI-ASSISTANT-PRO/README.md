# RAUF AI ASSISTANT PRO
© Rauf · Powered by Rauf Legacy

Express backend (proxy) + mobile-first web UI + Capacitor Android wrapper instructions.
**Status:** source only. Nothing here has been built into an APK, and `npm install`/tests were not run at packaging time.

## Run locally
1. Node 20+. `npm install`
2. `cp .env.example .env` (upstream endpoints live only here, server-side)
3. `npm start` → open http://localhost:3000
4. `npm test` (uses mocked upstreams; no network needed)

## Deploy (HTTPS)
Host on any Node host (Render, Railway, VPS + reverse proxy). Set the env vars from `.env.example`. Serve over HTTPS only. Add authentication if public; rate limiting (60 req/min/IP) is built in.

## Android (Capacitor)
Deploy the backend first, then:
```
npm i -D @capacitor/cli && npm i @capacitor/core @capacitor/android
cp android/capacitor.config.json ./capacitor.config.json   # edit YOUR-DEPLOYED-BACKEND host
npx cap add android && npx cap sync android
```
In `android/app/src/main/AndroidManifest.xml` keep only `INTERNET` and `RECORD_AUDIO` (+ `MODIFY_AUDIO_SETTINGS` if prompted). Set launcher icon/splash with `npx @capacitor/assets generate` (needs `assets/icon.png`).
Speech input uses the WebView's Web Speech API; if unsupported on a device, the app says so and typing still works.
- Debug APK: `cd android && ./gradlew assembleDebug` → `app/build/outputs/apk/debug/`
- Release: create a keystore (`keytool -genkey -v -keystore rauf.jks -alias rauf -keyalg RSA -keysize 2048 -validity 10000`), configure signing, then `./gradlew assembleRelease` (or `bundleRelease` for Play Store). Never commit the keystore.

## Troubleshooting
- Status shows Offline: backend not running / wrong host.
- Chat error: check `DEEPSEEK_ENDPOINT`, raise `REQUEST_TIMEOUT_MS`.
- Voice list empty or error: check `AIRMORE_ENDPOINT`; the parser (`normalizeVoices` in server.js) accepts arrays, `voices`/`result`/`data`/`list` keys, or key→name objects. Adjust it if the real schema differs.
- Audio won't play: returned links can expire; tap Speak again.
