MATTAI CALCULATION — Android-installable PWA

Included:
- index.html: Mattai calculator
- manifest.webmanifest: app name and install metadata
- sw.js: offline cache
- icon.svg: app icon

Calculation outline:
- Average height = average of 3 heights (inches)
- Final height = average height / 12
- Area = length (ft) × width (ft) × final height (ft)
- Mattai buying cost = quantity × buying rate
- Diesel used = distance / mileage
- Diesel cost = diesel used × diesel rate
- Total expenses = buying cost + diesel cost + entered other expenses
- Sales = area × sales rate per sq.ft
- Net profit = sales − total expenses
- Profit split shown as 50% / 50% for the two partners

Install on Android:
1. Publish all files on an HTTPS static host (for example, GitHub Pages).
2. Open the published website in Google Chrome.
3. Chrome menu ⋮ → Install app (or Add to Home screen).
4. Launch it from the home screen. After the first online load, cached files can work offline.

Important:
- This package is a Progressive Web App (PWA), not a native APK.
- A native APK needs a separate Android build and signing step.
- Check the calculator results against your actual Excel/workbook before using them for business decisions.
- Calculation history is stored locally in that browser on that phone.
