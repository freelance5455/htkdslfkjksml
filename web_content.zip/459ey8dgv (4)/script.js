const SIZE = 12;
const $ = id => document.getElementById(id);
const opponent = side => side === "red" ? "blue" : "red";

let activeView = "homeView";
let board = [];
let turn = "red";
let selected = null;
let moves = [];
let history = [];
let forced = null;
let gameOver = false;
let checkerSoundOn = true;
let aiBusy = false;
let checkerAudio;

function showView(viewId) {
  activeView = viewId;
  document.querySelectorAll(".view").forEach(view => {
    view.hidden = view.id !== viewId;
  });
  if (viewId !== "checkersView") aiBusy = false;
  if (viewId !== "snakeView" && snakeRunning) {
    clearInterval(snakeLoop);
    snakePaused = true;
    $("pauseBtn").textContent = "RESUME";
  }
}

document.querySelectorAll("[data-open]").forEach(button => {
  button.addEventListener("click", () => showView(button.dataset.open));
});
document.querySelectorAll("[data-home]").forEach(button => {
  button.addEventListener("click", () => showView("homeView"));
});

// Royal Checkers
function newGame() {
  board = Array.from({ length: SIZE }, () => Array(SIZE).fill(null));
  for (let r = 0; r < 3; r++) {
    for (let c = 0; c < SIZE; c++) {
      if ((r + c) % 2) board[r][c] = { side: "blue", king: false };
    }
  }
  for (let r = 9; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) {
      if ((r + c) % 2) board[r][c] = { side: "red", king: false };
    }
  }
  turn = "red";
  selected = null;
  moves = [];
  forced = null;
  history = [];
  gameOver = false;
  aiBusy = false;
  $("checkerMessage").textContent = "Red starts!";
  renderBoard();
}

function inside(r, c) { return r >= 0 && r < SIZE && c >= 0 && c < SIZE; }
function directions(piece) {
  if (piece.king) return [[-1, -1], [-1, 1], [1, -1], [1, 1]];
  return piece.side === "red" ? [[-1, -1], [-1, 1]] : [[1, -1], [1, 1]];
}
function captures(r, c, piece) {
  const result = [];
  for (const [dr, dc] of [[-1, -1], [-1, 1], [1, -1], [1, 1]]) {
    const mr = r + dr, mc = c + dc, tr = r + 2 * dr, tc = c + 2 * dc;
    if (inside(tr, tc) && board[mr][mc] && board[mr][mc].side !== piece.side && !board[tr][tc]) {
      result.push({ from: [r, c], to: [tr, tc], cap: [mr, mc] });
    }
  }
  return result;
}
function allMoves(side) {
  const captureMoves = [], normalMoves = [];
  for (let r = 0; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) {
      const piece = board[r][c];
      if (!piece || piece.side !== side) continue;
      const pieceCaptures = captures(r, c, piece);
      captureMoves.push(...pieceCaptures);
      if (!pieceCaptures.length) {
        for (const [dr, dc] of directions(piece)) {
          const nr = r + dr, nc = c + dc;
          if (inside(nr, nc) && !board[nr][nc]) normalMoves.push({ from: [r, c], to: [nr, nc], cap: null });
        }
      }
    }
  }
  return captureMoves.length ? captureMoves : normalMoves;
}
function renderBoard() {
  const element = $("board");
  element.innerHTML = "";
  const targets = new Set(moves.map(move => move.to.join(",")));
  for (let r = 0; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) {
      const cell = document.createElement("div");
      cell.className = "cell " + ((r + c) % 2 ? "dark" : "light");
      if (selected && selected[0] === r && selected[1] === c) cell.classList.add("selected");
      if (targets.has(`${r},${c}`)) cell.classList.add("target");
      const piece = board[r][c];
      if (piece) {
        const pieceElement = document.createElement("div");
        pieceElement.className = "piece " + piece.side + (piece.king ? " king" : "");
        cell.appendChild(pieceElement);
      }
      if ((r + c) % 2) cell.addEventListener("click", () => clickCell(r, c));
      element.appendChild(cell);
    }
  }
  $("redCount").textContent = board.flat().filter(piece => piece?.side === "red").length;
  $("blueCount").textContent = board.flat().filter(piece => piece?.side === "blue").length;
  $("turn").textContent = gameOver ? "Game Over" : `${turn.toUpperCase()}'s Turn`;
}
function clickCell(r, c) {
  if (gameOver || aiBusy) return;
  if ($("mode").value === "computer" && turn === "blue") return;
  if (forced && (r !== forced[0] || c !== forced[1])) return;
  const move = moves.find(item => item.to[0] === r && item.to[1] === c);
  if (move) { playCheckerMove(move); return; }
  const piece = board[r][c];
  if (piece && piece.side === turn) {
    moves = allMoves(turn).filter(item => item.from[0] === r && item.from[1] === c);
    if (moves.length) selected = [r, c];
    renderBoard();
    return;
  }
  if (!forced) { selected = null; moves = []; renderBoard(); }
}
function saveHistory() {
  history.push({ board: board.map(row => row.map(piece => piece ? { ...piece } : null)), turn });
}
function playCheckerMove(move) {
  saveHistory();
  const [r, c] = move.from, [tr, tc] = move.to;
  const piece = board[r][c];
  board[r][c] = null;
  board[tr][tc] = piece;
  if (move.cap) board[move.cap[0]][move.cap[1]] = null;
  if ((piece.side === "red" && tr === 0) || (piece.side === "blue" && tr === SIZE - 1)) piece.king = true;
  checkerPlaySound(move.cap ? "capture" : "move");
  if (move.cap) {
    const nextCaptures = captures(tr, tc, piece);
    if (nextCaptures.length) {
      forced = [tr, tc]; selected = [tr, tc]; moves = nextCaptures;
      $("checkerMessage").textContent = "Continue capturing!";
      renderBoard();
      if ($("mode").value === "computer" && turn === "blue") setTimeout(computerMove, 350);
      return;
    }
  }
  forced = null; selected = null; moves = [];
  turn = opponent(turn);
  if (countPieces(turn) === 0 || allMoves(turn).length === 0) {
    gameOver = true;
    $("checkerMessage").textContent = `${opponent(turn).toUpperCase()} WINS!`;
  } else {
    $("checkerMessage").textContent = turn === "red" ? "Red's turn" : "Blue's turn";
  }
  renderBoard();
  if ($("mode").value === "computer" && turn === "blue" && !gameOver) setTimeout(computerMove, 350);
}
function countPieces(side) { return board.flat().filter(piece => piece && piece.side === side).length; }
function evaluate(side) {
  let score = 0;
  for (let r = 0; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) {
      const piece = board[r][c];
      if (!piece) continue;
      let value = piece.king ? 190 : 100;
      if (!piece.king) value += piece.side === "blue" ? r * 2 : (SIZE - 1 - r) * 2;
      score += piece.side === side ? value : -value;
    }
  }
  return score;
}
function simulate(move) {
  const copy = board.map(row => row.map(piece => piece ? { ...piece } : null));
  const [r, c] = move.from, [tr, tc] = move.to;
  const piece = copy[r][c];
  copy[r][c] = null; copy[tr][tc] = piece;
  if (move.cap) copy[move.cap[0]][move.cap[1]] = null;
  if ((piece.side === "blue" && tr === SIZE - 1) || (piece.side === "red" && tr === 0)) piece.king = true;
  return copy;
}
function computerMove() {
  if (gameOver || turn !== "blue" || activeView !== "checkersView") return;
  aiBusy = true;
  setTimeout(() => {
    if (gameOver || turn !== "blue" || activeView !== "checkersView") { aiBusy = false; return; }
    const options = forced ? moves : allMoves("blue");
    if (!options.length) { aiBusy = false; return; }
    const level = $("level").value;
    let best = options[0], bestScore = -Infinity;
    for (const move of options) {
      const oldBoard = board;
      board = simulate(move);
      let score = evaluate("blue");
      if (level === "medium" || level === "hard") {
        const replies = allMoves("red");
        if (replies.length) score -= replies.length * 2;
      }
      if (level === "hard") score += Math.random() * 2;
      else if (level === "easy") score += Math.random() * 60;
      board = oldBoard;
      if (score > bestScore) { bestScore = score; best = move; }
    }
    aiBusy = false;
    playCheckerMove(best);
  }, 300);
}
function undoMove() {
  if (aiBusy) return;
  const previous = history.pop();
  if (!previous) { $("checkerMessage").textContent = "No moves to undo."; return; }
  board = previous.board; turn = previous.turn; selected = null; moves = []; forced = null; gameOver = false;
  renderBoard();
  $("checkerMessage").textContent = "Move undone.";
}
function showHint() {
  if (gameOver || aiBusy || ($("mode").value === "computer" && turn === "blue")) return;
  const options = forced ? moves : allMoves(turn);
  if (!options.length) return;
  const move = options.find(item => item.cap) || options[0];
  selected = move.from;
  moves = options.filter(item => item.from.join(",") === move.from.join(","));
  $("checkerMessage").textContent = "Try the highlighted move.";
  renderBoard();
}
function checkerPlaySound(type) {
  if (!checkerSoundOn) return;
  try {
    checkerAudio = checkerAudio || new (window.AudioContext || window.webkitAudioContext)();
    const oscillator = checkerAudio.createOscillator(), gain = checkerAudio.createGain();
    oscillator.connect(gain); gain.connect(checkerAudio.destination);
    oscillator.frequency.value = type === "capture" ? 250 : 420;
    gain.gain.value = 0.04;
    oscillator.start(); oscillator.stop(checkerAudio.currentTime + 0.12);
  } catch (error) { /* Audio may be unavailable in some browsers. */ }
}
$("newCheckerGame").addEventListener("click", newGame);
$("undoCheckerMove").addEventListener("click", undoMove);
$("checkerHint").addEventListener("click", showHint);
$("mode").addEventListener("change", newGame);
$("checkerSoundBtn").addEventListener("click", () => {
  checkerSoundOn = !checkerSoundOn;
  $("checkerSoundBtn").textContent = checkerSoundOn ? "🔊 Sound ON" : "🔇 Sound OFF";
});

// Snake
const canvas = $("gameCanvas");
const ctx = canvas.getContext("2d");
const grid = 20, tile = 20;
let snake = [], food = null, goldFood = null;
let dx = 1, dy = 0, nextDx = 1, nextDy = 0;
let snakeScore = 0, bestScore = 0, snakeLoop = null;
let snakeRunning = false, snakePaused = false, snakeSoundOn = true, snakeAudio;
try { bestScore = Number(localStorage.getItem("rpGroopSnakeBest")) || 0; } catch (error) { bestScore = 0; }
$("best").textContent = bestScore;
function createFood(excluded = []) {
  const freeCells = [];
  for (let y = 0; y < grid; y++) {
    for (let x = 0; x < grid; x++) {
      const occupiedBySnake = snake.some(part => part.x === x && part.y === y);
      const occupiedByFood = excluded.some(item => item && item.x === x && item.y === y);
      if (!occupiedBySnake && !occupiedByFood) freeCells.push({ x, y });
    }
  }
  if (!freeCells.length) return null;
  return freeCells[Math.floor(Math.random() * freeCells.length)];
}
function startSnakeGame() {
  clearInterval(snakeLoop);
  snake = [{ x: 10, y: 10 }, { x: 9, y: 10 }, { x: 8, y: 10 }];
  dx = 1; dy = 0; nextDx = 1; nextDy = 0; snakeScore = 0;
  $("score").textContent = snakeScore;
  food = createFood(); goldFood = null; snakeRunning = true; snakePaused = false;
  $("snakeMessage").style.display = "none";
  $("pauseBtn").textContent = "PAUSE";
  drawSnakeGame();
  snakeLoop = setInterval(updateSnake, Number($("difficulty").value));
}
function drawSnakeGame() {
  ctx.fillStyle = "#071b10"; ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.strokeStyle = "#123321"; ctx.lineWidth = 0.5;
  for (let i = 0; i <= canvas.width; i += tile) {
    ctx.beginPath(); ctx.moveTo(i, 0); ctx.lineTo(i, canvas.height); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(0, i); ctx.lineTo(canvas.width, i); ctx.stroke();
  }
  if (food) {
    ctx.fillStyle = "#ff4545"; ctx.beginPath(); ctx.arc(food.x * tile + 10, food.y * tile + 10, 8, 0, Math.PI * 2); ctx.fill();
  }
  if (goldFood) {
    ctx.fillStyle = "#ffd700"; ctx.beginPath(); ctx.arc(goldFood.x * tile + 10, goldFood.y * tile + 10, 9, 0, Math.PI * 2); ctx.fill();
  }
  snake.forEach((part, index) => {
    ctx.fillStyle = index === 0 ? "#b6ff00" : "#39ff79";
    ctx.shadowColor = "#39ff79"; ctx.shadowBlur = 8;
    ctx.fillRect(part.x * tile + 2, part.y * tile + 2, tile - 4, tile - 4); ctx.shadowBlur = 0;
  });
  if (snake.length) {
    ctx.fillStyle = "black";
    ctx.fillRect(snake[0].x * tile + 5, snake[0].y * tile + 5, 3, 3);
    ctx.fillRect(snake[0].x * tile + 13, snake[0].y * tile + 5, 3, 3);
  }
}
function updateSnake() {
  if (!snakeRunning || snakePaused) return;
  dx = nextDx; dy = nextDy;
  const head = { x: snake[0].x + dx, y: snake[0].y + dy };
  if (head.x < 0 || head.x >= grid || head.y < 0 || head.y >= grid) { endSnakeGame(); return; }
  const ateFood = food && head.x === food.x && head.y === food.y;
  const ateGold = goldFood && head.x === goldFood.x && head.y === goldFood.y;
  const collisionBody = ateFood || ateGold ? snake : snake.slice(0, -1);
  if (collisionBody.some(part => part.x === head.x && part.y === head.y)) { endSnakeGame(); return; }
  snake.unshift(head);
  if (ateFood) {
    snakeScore += 10; food = createFood();
    if (snakeScore % 50 === 0 && !goldFood) goldFood = createFood(food ? [food] : []);
    snakePlaySound(600);
  } else if (ateGold) { snakeScore += 50; goldFood = null; snakePlaySound(900); }
  else snake.pop();
  $("score").textContent = snakeScore;
  if (snakeScore > bestScore) {
    bestScore = snakeScore; $("best").textContent = bestScore;
    try { localStorage.setItem("rpGroopSnakeBest", bestScore); } catch (error) { /* Storage is optional. */ }
  }
  drawSnakeGame();
}
function endSnakeGame() {
  clearInterval(snakeLoop); snakeRunning = false;
  $("snakeMessage").innerHTML = `<h3>GAME OVER!</h3><p>Your Score: ${snakeScore}</p><button id="restartSnake" class="start-button">PLAY AGAIN</button>`;
  $("snakeMessage").style.display = "flex";
  $("restartSnake").addEventListener("click", startSnakeGame);
}
function changeSnakeDirection(direction) {
  if (!snakeRunning || snakePaused || activeView !== "snakeView") return;
  if (direction === "up" && dy !== 1) { nextDx = 0; nextDy = -1; }
  else if (direction === "down" && dy !== -1) { nextDx = 0; nextDy = 1; }
  else if (direction === "left" && dx !== 1) { nextDx = -1; nextDy = 0; }
  else if (direction === "right" && dx !== -1) { nextDx = 1; nextDy = 0; }
}
document.addEventListener("keydown", event => {
  if (activeView !== "snakeView") return;
  const keys = { ArrowUp: "up", ArrowDown: "down", ArrowLeft: "left", ArrowRight: "right" };
  if (keys[event.key]) { event.preventDefault(); changeSnakeDirection(keys[event.key]); }
});
let swipeStart = null;
canvas.addEventListener("pointerdown", event => {
  if (event.pointerType === "touch" && snakeRunning && !snakePaused) {
    swipeStart = { x: event.clientX, y: event.clientY };
  }
});
canvas.addEventListener("pointerup", event => {
  if (!swipeStart) return;
  const deltaX = event.clientX - swipeStart.x;
  const deltaY = event.clientY - swipeStart.y;
  swipeStart = null;
  if (Math.max(Math.abs(deltaX), Math.abs(deltaY)) < 20) return;
  if (Math.abs(deltaX) > Math.abs(deltaY)) {
    changeSnakeDirection(deltaX > 0 ? "right" : "left");
  } else {
    changeSnakeDirection(deltaY > 0 ? "down" : "up");
  }
});
canvas.addEventListener("pointercancel", () => { swipeStart = null; });
document.querySelectorAll(".controls button").forEach(button => {
  button.addEventListener("click", () => changeSnakeDirection(button.dataset.dir));
});
$("startBtn").addEventListener("click", startSnakeGame);
$("pauseBtn").addEventListener("click", () => {
  if (!snakeRunning) return;
  snakePaused = !snakePaused;
  $("pauseBtn").textContent = snakePaused ? "RESUME" : "PAUSE";
  if (snakePaused) clearInterval(snakeLoop);
  else snakeLoop = setInterval(updateSnake, Number($("difficulty").value));
});
$("difficulty").addEventListener("change", () => {
  if (snakeRunning && !snakePaused) {
    clearInterval(snakeLoop);
    snakeLoop = setInterval(updateSnake, Number($("difficulty").value));
  }
});
function snakePlaySound(frequency) {
  if (!snakeSoundOn) return;
  try {
    snakeAudio = snakeAudio || new (window.AudioContext || window.webkitAudioContext)();
    const oscillator = snakeAudio.createOscillator(), gain = snakeAudio.createGain();
    oscillator.frequency.value = frequency; gain.gain.value = 0.04;
    oscillator.connect(gain); gain.connect(snakeAudio.destination);
    oscillator.start(); oscillator.stop(snakeAudio.currentTime + 0.08);
  } catch (error) { /* Audio may be unavailable in some browsers. */ }
}
$("snakeSoundBtn").addEventListener("click", () => {
  snakeSoundOn = !snakeSoundOn;
  $("snakeSoundBtn").textContent = snakeSoundOn ? "🔊 SOUND ON" : "🔇 SOUND OFF";
});
drawSnakeGame();
newGame();
