# Paracraft Online — application Android

Le jeu HTML tourne dans une application Android native (WebView) :
- **toujours à l’horizontale, dans un seul sens** (paysage fixe, l’écran ne pivote pas) ;
- **plein écran** : barres système cachées, écran qui ne se met pas en veille ;
- touche **Retour** : ferme la fenêtre ouverte dans le jeu (sac, dialogue, chat) au lieu de quitter ;
- sauvegarde automatique quand l'application passe en arrière-plan ;
- même dans le navigateur d’un téléphone tenu à la verticale, le jeu s’affiche tourné à l’horizontale ;
- les fichiers du jeu sont dans `app/src/main/assets/www` et fonctionnent **hors ligne** (seules les polices Google se chargent avec Internet ; sans connexion, une police de secours est utilisée).

## Construire l'APK — méthode 1 : Android Studio (sur ton ordinateur)
1. Installe Android Studio (gratuit) : https://developer.android.com/studio
2. *File › Open* et choisis ce dossier `paracraft-android`. Laisse Android Studio télécharger ce qu'il demande (Gradle, SDK 34).
3. *Build › Build App Bundle(s) / APK(s) › Build APK(s)*.
4. L'APK est dans `app/build/outputs/apk/debug/app-debug.apk`. Copie-le sur ton téléphone et ouvre-le (autorise « sources inconnues »), ou branche le téléphone en USB et clique sur ▶ Run.

## Construire l'APK — méthode 2 : GitHub, sans rien installer
1. Crée un dépôt GitHub et envoie-y ce dossier.
2. L'action `.github/workflows/android.yml` construit l'APK à chaque envoi.
3. Onglet *Actions* › dernière exécution › *Artifacts* › `paracraft-online-apk`.

## Mettre à jour le jeu dans l'application
Copie les nouveaux fichiers du jeu (le dossier qui contient `eldora.html` et les `.js`) puis lance :

    ./sync_www.sh chemin/vers/le/dossier/du/jeu

et reconstruis l'APK. Pense à augmenter `versionCode` dans `app/build.gradle` à chaque version.

## Pour le Play Store (plus tard)
- Génère un **App Bundle signé** : *Build › Generate Signed App Bundle*. Garde précieusement la clé de signature.
- Identifiant de l'application : `com.paracraft.online` (modifiable dans `app/build.gradle` avant la première publication, pas après).
- Les comptes et personnages sont aujourd'hui stockés sur le téléphone. Un vrai serveur sera nécessaire pour le multijoueur et des comptes sécurisés.
