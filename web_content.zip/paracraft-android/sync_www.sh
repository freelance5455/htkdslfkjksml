#!/bin/sh
# Copie la dernière version du jeu (dossier du jeu passé en argument) dans l'application Android.
SRC="${1:-../eldora}"; DST="$(dirname "$0")/app/src/main/assets/www"
mkdir -p "$DST"
for f in core sprites world game quests render events economy inventory kingdom icons ui ui2 chat2 login ui3 mobs; do cp "$SRC/$f.js" "$DST/"; done
cp "$SRC/logo.png" "$DST/logo.png"
{ printf '<!doctype html>\n<html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover,user-scalable=no"><meta name="theme-color" content="#000000"></head><body>\n'; cat "$SRC/eldora.html"; printf '\n</body></html>\n'; } > "$DST/index.html"
echo "www mis à jour depuis $SRC"
