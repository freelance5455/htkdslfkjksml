'use strict';
/* ===================== Moteur de jeu ===================== */
const INV_MAX=36, MAX_CHARS=4;let CHAR_KEY='paracraft_chars';
let P=null,CHARS=loadJSON(CHAR_KEY,[]),CI=-1,state='title',paused=false;
let mons=[],projs=[],fxs=[],texts=[],bags=[],parts=[],bots=[],party=null,petE=null,dgRun=null;
let tGame=0,tDay=150,saveT=0;
const WAR={st:'idle',t:150,sc:{solarix:0,umbra:0},own:null,ann:false,part:false,tick:0};
const WB={titan:{map:'c_maudit',lv:43,t:240,alive:false,respawn:7200,mon:null,sim:0},wyrm:{map:'c_abysse',lv:50,t:480,alive:false,respawn:10800,mon:null,sim:0}};
let MARKET=[],marketT=0,hdvT=15,guildT=30;
const curId=()=>M?M.id:'';
const inPvp=()=>!!(M&&M.def&&M.def.pvp);

/* ---------- personnage ---------- */
function newChar(name,cls,fac,hc){
  const c={name,cls,fac,hc:!!hc,lvl:1,xp:0,gold:80,hp:0,mp:0,map:FACTIONS[fac].cap,x:0,y:0,al:{for:0,dex:0,int:0,con:0,sag:0},pts:0,
    inv:[],eq:{},res:{},cons:{pv:6,pm:4,retour:1,ench1:1},prof:{},qs:{act:{},done:{},bdefs:[],board:[],bT:0},codex:{},guild:null,hdv:{list:[],mail:0},honor:0,pk:0,pkT:0,buffs:[],
    pet:null,petF:{gold:true,eq:true,min:0,res:true,cons:true},skr:[1,0,0,0,0,0,0,0,0,0],bags:[null,null],bar:[0,1,2,3,4,5],ev:{},uid:1,created:Date.now(),deaths:0,kills:0,pvpk:0};
  for(const k in PROFS)c.prof[k]={l:1,xp:0};
  c.eq.arme=mkItem(c,'arme',0,0,cls);c.eq.armure=mkItem(c,'armure',0,0);
  return c;}
const SAVE_FIELDS=['name','cls','fac','hc','lvl','xp','gold','hp','mp','map','x','y','al','pts','inv','eq','res','cons','prof','qs','codex','guild','hdv','honor','pk','pkT','buffs','pet','petF','skr','bar','ev','bags','uid','created','deaths','kills','pvpk'];
function snap(){const o={};for(const k of SAVE_FIELDS)o[k]=P[k];if(dgRun){o.map=dgRun.ret.map;o.x=dgRun.ret.x;o.y=dgRun.ret.y;}return JSON.parse(JSON.stringify(o));}
function save(){if(!P||CI<0||state==='title'||state==='tomb')return;CHARS[CI]=snap();saveJSON(CHAR_KEY,CHARS);}
function initRuntime(){Object.assign(P,{atkT:0,sk:[0,0,0,0,0,0,0,0,0,0],potT:0,guard:0,inv0:0,lastHit:99,fx:0,fy:1,dir:'d',mv:false,target:null,chase:false,moveTo:null,goTo:null,harv:null,anim:0,flip:false,pkMode:false,guardT:0,lunge:0});}

/* ---------- objets ---------- */
function mkItem(owner,type,tier,rar,cls){const o=owner||P;const it={id:o.uid++,type,tier:clamp(tier,0,9),rar,plus:0,dur:100,bon:{}};
  if(type==='arme'||type==='second')it.cls=cls||pick(Object.keys(CLASSES));
  for(let k=0;k<rar;k++){const b=pick(BONUS_KEYS);it.bon[b]=(it.bon[b]||0)+(b==='hp'?ri(8,16)*(tier+1):b==='crit'?ri(1,2+Math.floor(tier/2)):ri(1+tier,3+tier*2));}
  return it;}
function itemName(it){const b=BASEN[it.type];const arr=(it.type==='arme'||it.type==='second')?b[it.cls]:b;return arr[it.tier%arr.length]+' '+MATS[it.tier]+(it.plus?' +'+it.plus:'');}
function itemStats(it){if(it.dur<=0)return{};const q=TIER_REQ[it.tier],R=RARM[it.rar]*(1+.08*it.plus),p=it.plus,t=it.tier,s={},r=v=>Math.round(v);
  switch(it.type){
    case'arme':s.atk=r((6+q*1.7)*R+p*(1+t));break;
    case'second':if(it.cls==='guerrier'){s.def=r((2+q*.5)*R+p*.5);s.hp=r((6+q*3)*R);}else if(it.cls==='archer')s.atk=r((2+q*.5)*R+p*.5);else{s.mp=r((8+q*3)*R);s.atk=r((1+q*.35)*R+p*.4);}break;
    case'casque':s.def=r((1+q*.35)*R+p*.4);s.hp=r((5+q*4)*R);break;
    case'armure':s.def=r((2+q*.7)*R+p*.6);s.hp=r((10+q*7)*R);break;
    case'gants':s.atk=r((1+q*.25)*R+p*.3);s.def=r((.5+q*.2)*R);break;
    case'bottes':s.def=r((1+q*.3)*R+p*.3);s.hp=r((4+q*3)*R);break;
    case'collier':s.hp=r((8+q*6)*R);s.mp=r((6+q*4)*R);break;
    case'anneau':s.mp=r((4+q*3)*R);s.atk=r((1+q*.2)*R+p*.3);break;}
  return s;}
const STAT_LBL={atk:'Atq',def:'Déf',hp:'PV',mp:'PM'};
function statTxt(it){if(it.dur<=0)return'Cassé : à réparer chez le forgeron';const a=Object.entries(itemStats(it)).filter(([,v])=>v).map(([k,v])=>STAT_LBL[k]+' +'+v);for(const [k,v] of Object.entries(it.bon||{}))a.push(BONUS_N[k]+' +'+v);return a.join(' · ');}
function itemValue(it){return Math.round(8*(it.tier+1)*(it.tier+1)*(it.rar+1)*(it.rar+1)*(1+it.plus*.5));}
function canEquip(it){if(P.lvl<TIER_REQ[it.tier])return'Niveau '+TIER_REQ[it.tier]+' requis';if(it.cls&&it.cls!==P.cls)return'Réservé à la classe '+CLASSES[it.cls].nom;return null;}
function slotFor(it){if(it.type==='anneau')return !P.eq.anneau1?'anneau1':!P.eq.anneau2?'anneau2':'anneau1';return it.type;}
function equip(it){const why=canEquip(it);if(why){toast(why);return;}const sl=slotFor(it),old=P.eq[sl];P.eq[sl]=it;P.inv=P.inv.filter(i=>i!==it);if(old)P.inv.push(old);clampHM();}
function unequip(sl){const it=P.eq[sl];if(!it)return;if(invFull()){toast('Sac plein');return;}P.eq[sl]=null;P.inv.push(it);clampHM();}
function findItem(id){for(const sl of SLOTS)if(P.eq[sl]&&P.eq[sl].id===id)return P.eq[sl];return P.inv.find(i=>i.id===id);}
function tierFor(L){let t=0;for(let i=0;i<TIER_REQ.length;i++)if(TIER_REQ[i]<=L)t=i;return t;}
const LOOT_TYPES=['arme','second','casque','armure','gants','bottes','collier','anneau'];

/* ---------- caractéristiques ---------- */
function guildBonus(){if(!P.guild)return{xp:0,hp:0,atk:0,def:0};const l=P.guild.lvl;return{xp:l*.02,hp:l>=3?.05:0,atk:l>=5?.05:0,def:l>=7?.05:0};}
function xpMult(){let x=1;for(const b of P.buffs)x+=b.xp||0;return x+guildBonus().xp;}
function stats(){const c=CLASSES[P.cls],a={};for(const k of STATS5)a[k]=c.base[k]+(P.al[k]||0);
  let atk=0,def=0,hp=0,mp=0,crit=0;
  for(const sl of SLOTS){const it=P.eq[sl];if(!it)continue;const s=itemStats(it);atk+=s.atk||0;def+=s.def||0;hp+=s.hp||0;mp+=s.mp||0;if(it.dur>0)for(const [k,v] of Object.entries(it.bon||{})){if(k in a)a[k]+=v;else if(k==='hp')hp+=v;else if(k==='crit')crit+=v;}}
  for(const b of P.buffs){if(b.intp)a.int=Math.round(a.int*(1+b.intp));if(b.sagp)a.sag=Math.round(a.sag*(1+b.sagp));}
  const S={a};
  // CON : PV max et défense physique · SAG : PM max et puissance des soins/buffs
  S.maxhp=c.hp0+a.con*10+c.hpl*P.lvl+hp;S.maxmp=c.mp0+a.sag*7+a.int*1+c.mpl*P.lvl+mp;
  // FOR : dégâts au corps à corps · DEX : dégâts à distance · INT : dégâts des sorts
  S.melee=4+a.for*.8+a.dex*.1+P.lvl+atk;S.ranged=4+a.dex*.75+a.for*.15+P.lvl+atk;S.matk=4+a.int*.82+a.sag*.08+P.lvl+atk;
  S.atk=P.cls==='guerrier'?S.melee:P.cls==='archer'?S.ranged:S.matk;
  S.def=c.def0+a.con*.5+P.lvl*.4+def;
  // DEX : précision, esquive, critique
  S.hit=Math.min(99,88+a.dex*.15);S.crit=Math.min(45,5+a.dex*.18+crit);S.dodge=Math.min(25,a.dex*.12);S.aspd=1-Math.min(.25,a.dex*.004);
  // INT : burst de zone et durée des contrôles · SAG : soins et buffs
  S.aoe=1+a.int*.005;S.ctl=1+Math.min(.6,a.int*.004);S.heal=1+a.sag*.015;S.buffp=1+a.sag*.006;S.mreg=.012+a.sag*.0004;
  // FOR : poids d'inventaire (pods)
  S.pods=Math.round(120+a.for*6+P.lvl*2);
  let bh=0,ba=0,bd=0,rg=0,dr=0,rb=0,mr=0,dg=0;for(const b of P.buffs){bh+=b.hp||0;ba+=b.atk||0;bd+=b.def||0;rg+=b.regen||0;dr+=b.dr||0;rb+=b.rng||0;mr+=b.mreg||0;dg+=b.dodge||0;}const gb=guildBonus();bh+=gb.hp;ba+=gb.atk;bd+=gb.def;if(P.guard>0)bd+=.6;
  for(const b of P.buffs)if(b.crit)S.crit=Math.min(60,S.crit+b.crit);S.dodge=Math.min(45,S.dodge+dg);S.mreg*=1+mr;S.dr=Math.min(.8,dr);S.rngB=rb;
  S.maxhp=Math.round(S.maxhp*(1+bh));S.maxmp=Math.round(S.maxmp);S.atk=Math.round(S.atk*(1+ba));S.def=Math.round(S.def*(1+bd));S.regen=1+rg;
  return S;}
function invWeight(){let w=0;for(const it of P.inv)w+=it.slot==='armure'||it.slot==='arme'?6:3;for(const v of Object.values(P.res||{}))w+=v*.5;for(const [k,v] of Object.entries(P.cons||{}))w+=(k.startsWith('livre_')?1:.2)*v;return Math.round(w);}
function clampHM(){const s=stats();P.hp=Math.min(P.hp,s.maxhp);P.mp=Math.min(P.mp,s.maxmp);}
function addBuff(b){P.buffs=P.buffs.filter(x=>x.id!==b.id);P.buffs.push(Object.assign({},b));}
const skRank=i=>(P.skr&&P.skr[i])||0, skMul=i=>1+.25*(Math.max(1,skRank(i))-1);

/* ---------- messages ---------- */
const chatLines=[];
function chat(name,txt,col,chan){chatLines.push({name,txt,col,chan:chan||(name?'say':'sys')});while(chatLines.length>80)chatLines.shift();renderChat();}
function addText(x,y,txt,col,big){if(!SET.dmg&&/^-?\d+$/.test(txt))return;texts.push({x,y,txt,col,t:0,big:!!big});}
function addFx(o){o.t=0;fxs.push(o);}
function burst(x,y,col,n){if(!SET.parts)return;for(let i=0;i<n;i++){const a=rnd()*6.28,s=rr(20,70);parts.push({x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s-20,t:0,life:rr(.3,.6),col,g:120});}}

/* ---------- cartes et transitions ---------- */
function transition(id,place){const f=$('#fade');f.classList.add('on');paused=true;setTimeout(()=>{enterMap(id,place);paused=!$('#modal').hidden;setTimeout(()=>f.classList.remove('on'),40);},230);}
function enterMap(id,place){place=place||{};
  M=place.dgMap||getMap(id);
  mons=[];projs=[];bags=[];fxs=[];texts=[];parts=[];
  for(const s of M.spawns)spawnMon(s);
  if(M.def&&M.def.wb){const k=M.def.wb[0],w=WB[k];if(w.alive&&M.wbPos)w.mon=spawnMon({type:k,lv:M.def.wb[1],x:M.wbPos.x,y:M.wbPos.y});}
  if(place.from){const e=M.exits.find(x=>x.to===place.from);if(e){const mid=(e.a+e.b)/2;
      if(e.dir==='w'){P.x=3*TS;P.y=mid*TS+8;}else if(e.dir==='e'){P.x=(M.w-3)*TS;P.y=mid*TS+8;}else if(e.dir==='n'){P.x=mid*TS+8;P.y=4*TS;}else{P.x=mid*TS+8;P.y=(M.h-3)*TS;}}}
  else if(place.x!=null){P.x=place.x;P.y=place.y;}
  else{const sp=M.spawnPt||M.entry||{x:M.w*8,y:M.h*8};P.x=sp.x;P.y=sp.y;}
  if(!canStand(P.x,P.y)){const sp=nearFree(P.x,P.y);P.x=sp.x;P.y=sp.y;}
  if(M.kind!=='dungeon')P.map=M.id;
  for(const b of bots)b.placed=false;
  if(party)for(const b of party.members){b.map=M.id;b.x=P.x+rr(-18,18);b.y=P.y+rr(6,14);b.placed=true;}
  for(const b of bots)if(b.map===M.id&&!b.placed)placeBot(b);
  if(P.pet)petE={x:P.x-14,y:P.y,anim:0,flip:false,tb:null};
  for(const c of M.citizens){const s=c.hx!=null?nearFree(c.hx+rr(-30,30),c.hy+rr(-30,30)):nearFree(M.spawnPt.x+rr(-60,60),M.spawnPt.y+rr(-90,10));c.x=s.x;c.y=s.y;}
  P.target=null;P.moveTo=null;P.goTo=null;P.harv=null;P.lastZone=null;
  const d=M.def;
  if(M.kind==='dungeon'){const D=DUNGEONS[M.dg];toast(D.n+' · étage '+M.floor+'/'+D.floors,'Niv. '+D.lv[0]+' à '+D.lv[1]);}
  else if(d){toast(d.n,d.kind==='city'?'Capitale de '+FACTIONS[d.side].n+' · zone sûre':'Niv. '+d.lv[0]+' à '+d.lv[1]+(d.pvp?' · zone contestée, PvP sauvage':' · territoire sûr'));
    if(d.pvp&&P.lvl<d.lv[0]-4)chat(null,'Attention : cette zone est bien au-dessus de ton niveau.');
    if(d.kind==='city'&&P.pkT>0&&d.side===P.fac)chat(null,'Les gardes de la cité pourchassent les noms rouges !');}
  onEnterMap();renderZone();save();
}
function nearFree(x,y){for(let r=0;r<12;r++)for(let k=0;k<16;k++){const a=k/16*6.28,nx=x+Math.cos(a)*r*TS,ny=y+Math.sin(a)*r*TS;if(canStand(nx,ny))return{x:nx,y:ny};}return{x,y};}
function checkExits(){if(!M.exits||M.kind==='dungeon')return;const mx=M.w*TS,my=M.h*TS,tx=P.x/TS,ty=P.y/TS;
  for(const e of M.exits){let hit=false;
    if(e.dir==='e')hit=P.x>mx-7&&ty>=e.a&&ty<=e.b+1;else if(e.dir==='w')hit=P.x<7&&ty>=e.a&&ty<=e.b+1;else if(e.dir==='n')hit=P.y<12&&tx>=e.a&&tx<=e.b+1;else hit=P.y>my-4&&tx>=e.a&&tx<=e.b+1;
    if(!hit)continue;const d=MAPS[e.to];
    if(d.side&&d.side!==P.fac){toast('Territoire de '+FACTIONS[d.side].n,'Accès interdit à ta faction');P.x+=e.dir==='e'?-14:e.dir==='w'?14:0;P.y+=e.dir==='s'?-14:e.dir==='n'?14:0;P.moveTo=null;return;}
    transition(e.to,{from:M.id});return;}}
function enterDungeon(portal){const dg=portal.dg,D=DUNGEONS[dg];if(P.lvl<D.lv[0]-3)chat(null,`Ce donjon est prévu pour le niveau ${D.lv[0]} et plus. Bonne chance.`);
  dgRun={dg,floor:1,seed:ri(1,1e9),ret:{map:M.id,x:portal.x,y:portal.y+28}};const m=genDungeon(dg,1,dgRun.seed);bakeMap(m);transition(m.id,{dgMap:m,x:m.entry.x,y:m.entry.y+18});}
function nextFloor(){dgRun.floor++;const m=genDungeon(dgRun.dg,dgRun.floor,dgRun.seed);bakeMap(m);transition(m.id,{dgMap:m,x:m.entry.x,y:m.entry.y+18});}
function leaveDungeon(){const r=dgRun.ret;dgRun=null;transition(r.map,{x:r.x,y:r.y});}

/* ---------- collisions ---------- */
function canStand(x,y,mon){for(const [a,b] of [[x-4,y-1],[x+4,y-1],[x-4,y-5],[x+4,y-5]]){if(solidPx(a,b))return false;if(mon&&M.blocked){const i=tAt(Math.floor(a/TS),Math.floor(b/TS));if(i>=0&&M.blocked[i]&&M.kind==='city')return false;}}return true;}
function moveEnt(e,dx,dy,mon){let mv=false;if(dx&&canStand(e.x+dx,e.y,mon)){e.x+=dx;mv=true;}if(dy&&canStand(e.x,e.y+dy,mon)){e.y+=dy;mv=true;}return mv;}
function steer(e,vx,vy,mon){if(moveEnt(e,vx,vy,mon))return true;const a=Math.atan2(vy,vx),l=Math.hypot(vx,vy);for(const da of [.8,-.8,1.6,-1.6]){if(moveEnt(e,Math.cos(a+da)*l,Math.sin(a+da)*l,mon))return true;}return false;}
const dirOf=(vx,vy)=>Math.abs(vx)>Math.abs(vy)*1.1?(vx<0?'l':'r'):(vy<0?'u':'d');

/* ---------- monstres ---------- */
function spawnMon(s){const t=MT[s.type],lv=s.lv||1,elite=!t.boss&&!s.dg&&lv>=8&&rnd()<.03,st=monStats(s.type,lv,elite),sp=MSPR[t.spr];
  const m=Object.assign({kind:'m',type:s.type,t,lv,elite,x:s.x,y:s.y,sx:s.x,sy:s.y,dead:false,rt:0,agg:false,ret:false,ac:0,sc:rr(0,1),rc:1,slc:2,slamT:0,wt:rr(0,3),wx:0,wy:0,slow:0,stun:0,root:0,tag:0,flip:false,anim:rr(0,6),ang:0,hitT:0,dg:!!s.dg,dir:'d',
    hr:Math.max(8,sp.w*.32),hh:Math.round(sp.h*.45),name:(elite?'Élite · ':'')+t.n},st);m.hp=m.maxhp;if(s.dg)m.respawn=1e9;mons.push(m);return m;}
function fire(m,ang,spd,col,r){projs.push({x:m.x,y:m.y-m.hh,vx:Math.cos(ang)*spd,vy:Math.sin(ang)*spd,life:3.2,from:'m',r:r||3,col,dmg:Math.round(m.dmg*.85*gapMul(m.lv)),src:m.name});}
function updMons(dt){
  const safe=M.kind==='city';
  for(const m of mons){
    if(m.dead){if(m.respawn<1e8){m.rt-=dt;if(m.rt<=0){m.dead=false;m.hp=m.maxhp;m.x=m.sx;m.y=m.sy;m.agg=false;m.ret=false;m.tag=0;}}continue;}
    const dp=dist(m,P);if(dp>600&&!m.agg)continue;
    m.anim+=dt*4;m.hitT-=dt;m.slow-=dt;m.weakT-=dt;m.sunT-=dt;if(m.stun>0){m.stun-=dt;continue;}m.root-=dt;
    const t=m.t,sp=t.spd*(m.slow>0?.5:1)*dt*(m.root>0?0:1);
    if(!m.agg&&!m.ret&&t.agr&&dp<m.aggro&&state==='play'&&P.hp>0)m.agg=true;
    if(m.agg&&(state!=='play'||P.hp<=0||Math.hypot(m.x-m.sx,m.y-m.sy)>(t.boss?420:320))){m.agg=false;m.ret=true;}
    if(m.agg){const dx=P.x-m.x,dy=P.y-m.y,d=dp||1;m.flip=dx<0;m.dir=dirOf(dx,dy);
      if(t.keep){if(d>t.keep+12)steer(m,dx/d*sp,dy/d*sp,true);else if(d<t.keep-26)steer(m,-dx/d*sp*.8,-dy/d*sp*.8,true);}
      else if(d>m.hr+6)steer(m,dx/d*sp,dy/d*sp,true);
      m.ac-=dt;if(!t.keep&&d<m.hr+12&&m.ac<=0){hurtPlayer(m.dmg*(m.weakT>0?1-m.weak:1)*gapMul(m.lv),m.name);m.ac=t.boss?1.3:1.1;}
      m.sc-=dt;const role=t.role;
      if(role!=='m'&&m.sc<=0&&d<m.aggro+60){const a=Math.atan2(dy+4,dx);
        if(role==='r'){fire(m,a,130,'#e8e4d4');m.sc=1.7;}
        else if(role==='s'){for(let k=-1;k<=1;k++)fire(m,a+k*.22,150,'#ff8a3a');m.sc=1.5;}
        else if(role==='c'){const n=t.boss?16:10,o=rnd()*6;for(let k=0;k<n;k++)fire(m,o+k*Math.PI*2/n,t.boss?90:75,t.boss?'#7ff3ff':'#9be36a',t.boss?4:3);m.sc=t.boss?2.2:2.6;}
        else if(role==='sp'){m.ang+=.38;fire(m,m.ang,95,'#7ff3ff',3);fire(m,m.ang+Math.PI,95,'#c58cff',3);m.sc=.11;m.rc-=.11;if(m.rc<=0){m.rc=3.2;for(let k=0;k<18;k++)fire(m,k*Math.PI/9,80,'#c58cff',4);}}}
      if(t.slam){m.slc-=dt;if(m.slamT>0){m.slamT-=dt;if(m.slamT<=0){addFx({k:'ring',x:m.x,y:m.y-4,r0:10,r1:70,life:.3,col:'#c88a4a'});burst(m.x,m.y-4,'#c8a070',12);if(dist(m,P)<70)hurtPlayer(m.dmg*1.4*gapMul(m.lv),m.name);}}
        else if(m.slc<=0&&d<80){m.slc=4;m.slamT=.75;addFx({k:'tele',x:m.x,y:m.y-4,r:70,life:.75,col:'#ff5a3a'});}}}
    else if(m.ret){const dx=m.sx-m.x,dy=m.sy-m.y,d=Math.hypot(dx,dy);m.hp=Math.min(m.maxhp,m.hp+m.maxhp*.3*dt);if(d<6){m.ret=false;m.tag=0;}else{m.flip=dx<0;m.dir=dirOf(dx,dy);if(!steer(m,dx/d*sp*1.4,dy/d*sp*1.4,true)){m.x=m.sx;m.y=m.sy;m.ret=false;}}}
    else{m.wt-=dt;if(m.wt<=0){m.wt=rr(1.5,4);const a=rnd()*6.28;m.wx=Math.cos(a);m.wy=Math.sin(a);if(rnd()<.4)m.wx=m.wy=0;if(Math.hypot(m.x-m.sx,m.y-m.sy)>40){const dx=m.sx-m.x,dy=m.sy-m.y,l=Math.hypot(dx,dy);m.wx=dx/l;m.wy=dy/l;}}
      if(m.wx||m.wy){steer(m,m.wx*sp*.45,m.wy*sp*.45,true);m.flip=m.wx<0;m.dir=dirOf(m.wx,m.wy);}}
  }
}
function hitMon(m,dmg,col,fromParty,crit){if(m.dead)return;m.hp-=dmg;m.tag=1;m.hitT=.12;if(!m.agg){m.agg=true;m.ret=false;}
  addText(m.x,m.y-m.hh*2-4,String(dmg),crit?'#ffd36a':(col||(fromParty?'#c8c0d8':'#ffffff')),crit);burst(m.x,m.y-m.hh,'#ffffff',3);
  if(m.hp<=0)killMon(m);}
function killMon(m){m.dead=true;m.rt=m.respawn;m.agg=false;burst(m.x,m.y-m.hh,'#f1e9d6',10);
  if(P.target===m){P.target=null;P.chase=false;}
  if(m.t.wb){onWbKill(m);}
  if(!m.tag)return;
  P.kills++;
  const near=partyNear(),n=1+near.length,lc=lvlColor(m.lv,P.lvl);
  const share=Math.round(m.xp*lc.x*(1+.15*(n-1))/n*xpMult());if(share>0)gainXp(share,n>1);else if(lc.x===0)addText(P.x,P.y-30,'Trop faible : 0 XP','#8f8a99');
  qEvent('kill',m);if(P.guild){P.guild.mission.prog=Math.min(P.guild.mission.n,P.guild.mission.prog+1);}
  dropLoot(m,near);
  if(m.dg&&m.t.boss&&M.chestPos&&!M.chest){M.chest={x:M.chestPos.x,y:M.chestPos.y,open:false};toast(DUNGEONS[M.dg].n+' vaincu','Le coffre du donjon est apparu');}
  if(m.t.mini&&!m.dg)chat(null,`${P.name} a vaincu ${m.t.n} !`);
}
function bookIdx(cls,m){const tags=CLASSES[cls].tags,out=[];const mine=curId(),mp=MAPS[mine],cz=!!(mp&&mp.pvp);
  tags.forEach((g,i)=>{if(g==='inne'||g==='city')return;if(!m){out.push(i);return;}const L=m.lv,boss=m.t.boss||m.t.mini;
    if(g==='wb'&&m.t.wb)out.push(i);
    else if(g==='mini12'&&boss&&!m.t.wb&&L>=9&&L<=16)out.push(i);
    else if(g==='mini16'&&boss&&!m.t.wb&&L>=14&&L<=22)out.push(i);
    else if(g==='phare2'&&m.type==='g_capnoye')out.push(i);
    else if(g==='elite'&&m.elite&&L>=14)out.push(i);
    else if(g==='rare'&&L>=18&&L<=24&&!boss)out.push(i);
    else if(g==='contest'&&cz&&L>=30&&!m.t.wb)out.push(i);
    else if(g==='d35'&&L>=35&&!m.t.wb)out.push(i);});return out;}
function bookKey(m){const cls=rnd()<.6?P.cls:pick(Object.keys(CLASSES));const ix=bookIdx(cls,m);if(!ix.length)return null;return'livre_'+cls+'_'+pick(ix);}
function bookChance(m){if(m.t.wb)return 1;if(m.type==='g_capnoye')return .5;if(m.t.boss||m.t.mini)return .4;if(m.elite)return .05;return .004;}
function autoBar(i){if(!P.bar)P.bar=[0,1,2,3,4,5];if(P.bar.includes(i))return P.bar.indexOf(i);let j=P.bar.findIndex(x=>x==null||!skRank(x));if(j<0)return -1;P.bar[j]=i;return j;}

function dropLoot(m,near){const L=m.lv,tier=tierFor(L),boss=m.t.boss||m.t.mini;
  /* table de drop façon TWOM : or 90 %, base 25 % (+ peaux de economy.js ≈ 45 %), équipement courant 10 %, rare 0,8 %, grimoire 0,4 %, objet ultime de boss 3 % */
  const b={x:m.x+rr(-4,4),y:m.y+rr(-2,2),items:[],cons:{},res:{},gold:0,t:rr(60,90),owner:'p'};
  const cls=()=>rnd()<.6?P.cls:pick(Object.keys(CLASSES)),add=(k,n)=>b.cons[k]=(b.cons[k]||0)+n;
  const eq=r=>{const it=mkItem(P,pick(LOOT_TYPES),Math.max(0,tier-(r<1&&rnd()<.3?1:0)),r,cls());b.items.push(it);return it;};
  const gold=ri(m.gold[0],m.gold[1]),gotGold=gold>0&&(boss||rnd()<.9);
  if(m.t.wb){for(let k=0;k<4;k++)eq(rnd()<.5?3:2);{const k=bookKey(m);if(k)add(k,1);}add('ench3',1);if(rnd()<.03){const it=eq(4);chat(null,'Objet ultime : '+itemName(it)+' !');}}
  else if(m.t.boss){const n=ri(2,3);for(let k=0;k<n;k++)eq(rnd()<.25?2:1);if(rnd()<bookChance(m)){const k=bookKey(m);if(k)add(k,1);}add(L>=35?'ench3':L>=20?'ench2':'ench1',1);
    if(rnd()<.03){const it=eq(3);chat(null,'Objet ultime de la zone : '+itemName(it)+' !');toast('Objet ultime !',itemName(it));}}
  else{const e=m.elite;if(rnd()<.10*(e?3:1))eq(rnd()<.8?0:1);if(rnd()<.008*(e?5:1))eq(rnd()<.7?1:2);if(rnd()<bookChance(m)){const k=bookKey(m);if(k)add(k,1);}}
  if(rnd()<.25){const r=rnd();if(r<.35)add('pv',1);else if(r<.55)add('pm',1);else{const rt=Math.min(3,Math.floor(L/12));const rs=pick([WOOD,ORE,HERB,FISH])[rt];b.res[rs]=(b.res[rs]||0)+ri(1,2);}}
  if(rnd()<.03&&L<30)add('ench1',1);if(L>=20&&rnd()<.012)add('ench2',1);if(L>=35&&rnd()<.003)add('ench3',1);
  // or : pièces au sol, séparées du sac, ramassables par le familier
  if(gotGold)bags.push({x:m.x+rr(-6,6),y:m.y+rr(0,4),items:[],cons:{},res:{},gold,t:rr(60,90),owner:'p',coin:1});
  if(!b.items.length&&!Object.keys(b.cons).length&&!Object.keys(b.res).length)return;
  // partage du butin en groupe
  if(party&&near.length){const mode=party.loot;
    if(mode==='random'){b.items=b.items.filter(it=>{const w=ri(0,near.length);if(w===0)return true;chat(near[w-1].n,'reçoit '+itemName(it)+' (tirage du groupe)','#9be3ff','party');return false;});}
    else if(mode==='free')b.owner='free';}
  b.rar=Math.max(0,...b.items.map(i=>i.rar));bags.push(b);}
function bagEmpty(b){return!b.gold&&!b.items.length&&!Object.keys(b.cons).length&&!Object.keys(b.res).length;}
function pickBag(b,byPet){const F=P.petF||{};let any=false;
  if(b.gold&&(!byPet||F.gold)){P.gold+=b.gold;addText(b.x,b.y-10,'+'+b.gold+' or','#f2c14e');b.gold=0;any=true;}
  for(const k of Object.keys(b.cons)){if(byPet&&!F.cons)continue;P.cons[k]=(P.cons[k]||0)+b.cons[k];addText(b.x,b.y-18,CONS[k].n,'#ffd0a0');if(k.startsWith('livre')||k.startsWith('ench'))chat(null,'Obtenu : '+CONS[k].n);delete b.cons[k];any=true;}
  for(const k of Object.keys(b.res)){if(byPet&&!F.res)continue;P.res[k]=(P.res[k]||0)+b.res[k];addText(b.x,b.y-14,'+'+b.res[k]+' '+RES[k].n,'#d8e8c0');delete b.res[k];any=true;}
  b.items=b.items.filter(it=>{if(byPet&&(!F.eq||it.rar<F.min))return true;if(invFull()){if(!b.full){b.full=1;addText(P.x,P.y-30,'Sac plein','#ff8a8a');}return true;}P.inv.push(it);any=true;chat(null,'Obtenu : '+itemName(it)+' ('+RAR[it.rar]+')');addText(b.x,b.y-22,itemName(it),RARC[it.rar]);return false;});
  return any;}

/* ---------- joueurs simulés ---------- */
function mapForLevel(l,f){const s=f==='solarix'?'sol_':'umb_';return l<6?s+1:l<11?s+2:l<16?s+3:l<21?s+4:l<26?'c_front':l<30?'c_marais':l<36?'c_desert':l<42?'c_maudit':'c_abysse';}
function botLook(cls,fac,i){const L=Object.assign({},CLASSES[cls].look);L.cape=FACTIONS[fac].cape;L.hair=['#5a3a22','#d9a441','#e8e0f0','#2a2a2a','#a83a2a','#8a6a4a'][i%6];L.hairStyle=['short','long','pony'][i%3];if(fac==='umbra'&&cls==='guerrier'){L.body='#4a4458';L.body2='#2e2a3a';}if(fac==='umbra'&&cls==='archer'){L.body='#3a2a4a';L.hood='#2a1a3a';}return L;}
function createBots(){bots=[];return;const LV=[2,3,5,7,9,11,13,15,18,20,22,25,28,32,36,40,45,49];
  for(const fac of ['solarix','umbra'])BOT_NAMES[fac].forEach((n,i)=>{const lvl=LV[i],cls=['guerrier','archer','mage'][i%3];
    const b={kind:'b',n,cls,fac,lvl,guild:rnd()<.7?pick(GUILDS[fac]).n:null,pk:i===13||i===16,x:0,y:0,dir:'d',anim:0,atkT:0,talk:rr(5,40),stuck:0,mt:rr(20,60),dead:false,rt:0,stun:0,root:0,healT:0,war:false,placed:false};
    b.maxhp=Math.round(60+lvl*16);b.hp=b.maxhp;b.atk=Math.round(10+lvl*3.4);b.def=Math.round(3+lvl*1.4);b.look=botLook(cls,fac,i);
    b.home=[0,6,10].includes(i)?FACTIONS[fac].cap:mapForLevel(lvl,fac);b.map=b.home;bots.push(b);});}
function placeBot(b){let p;if(b.bf&&EV.bf){const s=bfBase(b.fac);p=nearFree(s.x+rr(-30,30),s.y+rr(-50,50));}else if(M.kind==='city')p=nearFree(M.spawnPt.x+rr(-90,90),M.spawnPt.y+rr(-110,20));
  else if(b.war&&M.id==='c_front')p=nearFree((b.fac==='solarix'?8:M.w-8)*TS,(M.h/2+rr(-6,6))*TS);
  else if(b.wb&&M.wbPos)p=nearFree(M.wbPos.x+rr(-90,90),M.wbPos.y+rr(-70,70));
  else{const s=M.spawns.length?pick(M.spawns):{x:M.w*8,y:M.h*8};p=nearFree(s.x+rr(-40,40),s.y+rr(-40,40));}
  b.x=p.x;b.y=p.y;b.tx=b.x;b.ty=b.y;b.placed=true;}
const botsHostile=(a,b)=>inPvp()&&(a.fac!==b.fac||a.pk||b.pk)&&!(a.party&&b.party);
function botHostileToPlayer(b){return!b.party&&inPvp()&&(b.fac!==P.fac||b.pk||P.pkT>0);}
function canTarget(o){if(!o||o.dead)return false;if(o.kind==='m')return o.team!==P.fac;if(o.party||!inPvp())return false;return o.fac!==P.fac||o.pk||P.pkMode||P.pkT>0;}
function partyNear(){return party?party.members.filter(b=>!b.dead&&b.map===curId()&&dist(b,P)<420):[];}
function updBots(dt){const id=curId();
  for(const b of bots){
    if(b.dead){b.rt-=dt;if(b.rt<=0){b.dead=false;b.hp=b.maxhp;if(b.party){b.map=id;b.x=P.x+rr(-16,16);b.y=P.y+12;}else if(!b.war&&!b.wb){b.map=b.home;}if(b.map===id&&!b.party)placeBot(b);}continue;}
    if(b.map!==id){offMap(b,dt);continue;}
    b.atkT-=dt;b.talk-=dt;b.stun-=dt;b.root-=dt;if(b.stun>0)continue;
    if(b.talk<=0){b.talk=rr(30,80);if(b.fac===P.fac){if(b.party)chat(b.n,pick(['on continue ?','bien joué','je suis là','attention derrière']),'#9be3ff','party');else if(P.guild&&b.guild===P.guild.name)chat(b.n,pick(GUILD_LINES),'#9be36a','guild');else chat(b.n,pick(BOT_LINES),FACTIONS[b.fac].c);}}
    const c=CLASSES[b.cls],rng=c.ranged?110:20;let tgt=null,td=1e9;
    if(inPvp()){if(state==='play'&&P.hp>0&&botHostileToPlayer(b)){const d=dist(b,P);if(d<160){tgt=P;td=d;}}
      for(const o of bots){if(o===b||o.dead||o.map!==id||!botsHostile(b,o))continue;const d=dist(b,o);if(d<160&&d<td){td=d;tgt=o;}}}
    if(!tgt){if(b.party){const pt=P.target;if(pt&&!pt.dead&&pt.kind==='m'&&dist(P,pt)<220){tgt=pt;td=dist(b,pt);}else for(const m of mons){if(m.dead||!m.agg)continue;const d=dist(b,m);if(d<200&&d<td){td=d;tgt=m;}}}
      else for(const m of mons){if(m.dead||m.team)continue;if(m.t.boss&&!m.t.wb&&dist(m,P)>230)continue;if(m.t.wb&&!b.wb)continue;const d=dist(b,m);if(d<(b.wb?400:110)&&d<td){td=d;tgt=m;}}}
    if(b.party&&b.cls==='mage'){b.healT-=dt;const s=stats();if(b.healT<=0&&P.hp<s.maxhp*.6&&state==='play'){b.healT=7;const h=Math.round(s.maxhp*.15);P.hp=Math.min(s.maxhp,P.hp+h);addText(P.x,P.y-30,'+'+h+' ('+b.n+')','#9be36a');addFx({k:'ring',x:P.x,y:P.y-6,r0:18,r1:6,life:.5,col:'#9be36a'});}}
    b.hp=Math.min(b.maxhp,b.hp+b.maxhp*(tgt?.01:.06)*dt);
    let vx=0,vy=0,spd=b.party?72:52;
    if(tgt){const rr2=tgt.kind==='m'?rng+tgt.hr*.5:rng;if(td>rr2){vx=(tgt.x-b.x)/td;vy=(tgt.y-b.y)/td;}else if(b.atkT<=0){b.atkT=.95;botAttack(b,tgt,td);}}
    else if(b.party){const d=dist(b,P);if(d>34){vx=(P.x-b.x)/d;vy=(P.y-b.y)/d;spd=d>120?110:72;}if(d>500){b.x=P.x;b.y=P.y+10;}}
    else{const goal=b.goal?b.goal:b.war&&id==='c_front'&&M.fort?{x:M.fort.x+Math.sin(b.n.length*7)*50,y:M.fort.y+Math.cos(b.n.length*5)*40}:b.wb&&M.wbPos?{x:M.wbPos.x,y:M.wbPos.y}:{x:b.tx,y:b.ty};
      const dx=goal.x-b.x,dy=goal.y-b.y,d=Math.hypot(dx,dy);
      if(d<10||b.stuck>1.6){if(!b.war&&!b.wb){if(M.kind==='city'){const p=nearFree(M.spawnPt.x+rr(-140,140),M.spawnPt.y+rr(-160,40));b.tx=p.x;b.ty=p.y;}else{const s=M.spawns.length?pick(M.spawns):{x:b.x,y:b.y};b.tx=s.x+rr(-30,30);b.ty=s.y+rr(-30,30);}}b.stuck=0;}
      else{vx=dx/d;vy=dy/d;}}
    if((vx||vy)&&b.root<=0){const ox=b.x,oy=b.y;steer(b,vx*spd*dt,vy*spd*dt,false);if(Math.hypot(b.x-ox,b.y-oy)<.05)b.stuck+=dt;else{b.stuck=0;b.anim+=dt*8;b.dir=dirOf(vx,vy);b.mv=true;}}else b.mv=false;
  }
  // butin « celui qui ramasse »
  if(party&&party.loot==='free')for(const b of party.members){if(b.dead||b.map!==id)continue;for(let i=bags.length-1;i>=0;i--){const g=bags[i];if(g.owner!=='free'||g.coin)continue;if(dist(b,g)<26&&rnd()<dt*.6){for(const it of g.items)chat(b.n,'ramasse '+itemName(it),'#9be3ff','party');bags.splice(i,1);}}}
}
function botAttack(b,t,d){const c=CLASSES[b.cls];b.dir=dirOf(t.x-b.x,t.y-b.y);
  if(c.ranged)projs.push({x:b.x,y:b.y-12,vx:(t.x-b.x)/d*280,vy:(t.y-(t.hh||12)-b.y+12)/d*280,life:d/280,from:'v',r:2,col:c.proj.col});else addFx({k:'slash',x:(b.x+t.x)/2,y:(b.y+t.y)/2-10,a:Math.atan2(t.y-b.y,t.x-b.x),life:.18,col:'#f1e9d6'});
  if(t===P){hurtPlayer(b.atk,b.n+(b.pk?' (PK)':''));return;}
  const dmg=Math.max(1,Math.round(b.atk*rr(.85,1.15)-t.def*.5));
  if(t.kind==='m'){t.hp-=dmg;if(b.party){t.tag=1;t.agg=true;}if(dist(t,P)<380)addText(t.x,t.y-t.hh*2-4,String(dmg),'#c8c0d8');if(t.hp<=0&&!t.dead){t.hp=0;killMon(t);}}
  else hitBot(t,dmg,b);}
function hitBot(o,dmg,src){if(o.dead)return;o.hp-=dmg;if(dist(o,P)<380)addText(o.x,o.y-34,String(dmg),src===P?'#ffffff':'#c8c0d8');if(o.hp<=0)killBot(o,src);}
function killBot(o,src){o.dead=true;o.rt=o.party?15:22;burst(o.x,o.y-12,'#ff6a6a',12);if(P.target===o){P.target=null;P.chase=false;}
  if(WAR.st==='active'&&curId()==='c_front'&&src&&src.fac&&src.fac!==o.fac)WAR.sc[src.fac]+=15;
  if(o.party)chat(null,o.n+' est tombé. Il te rejoindra bientôt.');
  if(src!==P)return;
  if(o.fac===P.fac&&!o.pk){P.pk++;P.pkT+=600;toast('Ton nom devient rouge','Tu as tué un allié : les gardes et tous les joueurs peuvent te traquer');chat(null,`${P.name} a assassiné ${o.n}. Son nom devient rouge.`);}
  else{const hon=o.pk?25:12+Math.max(0,o.lvl-P.lvl);P.honor+=hon;P.pvpk++;addText(P.x,P.y-36,'+'+hon+' honneur','#ffd36a');chat(null,`Tu as vaincu ${o.n}${o.pk?' (chasse au PK)':''}.`);if(o.fac!==P.fac)qEvent('pvp');
    const x=Math.round(monXpAt(o.lvl)*4*lvlColor(o.lvl,P.lvl).x*xpMult());if(x>0)gainXp(x);}}
function offMap(b,dt){if(b.party||b.war||b.wb||b.sg||b.bf)return;b.mt-=dt;if(b.mt>0)return;b.mt=rr(40,90);
  if(rnd()<.3){b.map=b.map===b.home?(rnd()<.5?FACTIONS[b.fac].cap:mapForLevel(Math.max(1,b.lvl-4),b.fac)):b.home;if(b.map===curId())placeBot(b);}}

/* ---------- joueur ---------- */
function gainXp(n,shared){if(P.lvl>=MAX_LVL)return;P.xp+=n;addText(P.x-10,P.y-34,'+'+n+' xp'+(shared?' (groupe)':''),'#9be36a');
  if(P.guild)guildAddXp(Math.round(n*.1));
  while(P.lvl<MAX_LVL&&P.xp>=xpNeed(P.lvl)){P.xp-=xpNeed(P.lvl);P.lvl++;P.pts+=P.hc?PTS_LVL.hc:PTS_LVL.normal;const s=stats();P.hp=s.maxhp;P.mp=s.maxmp;
    toast('Niveau '+P.lvl+' !','+'+(P.hc?PTS_LVL.hc:PTS_LVL.normal)+' points de caractéristique à répartir');chat(null,`${P.name} atteint le niveau ${P.lvl}.`);addFx({k:'ring',x:P.x,y:P.y-8,r0:4,r1:44,life:.6,col:'#f2c14e'});burst(P.x,P.y-12,'#f2c14e',20);
    if(P.lvl===20)chat(null,'Niveau 20 : ta compétence de zone est débloquée. Le farm intensif commence.');
    if(P.lvl===21)chat(null,'Niveau 21 : les zones contestées s’ouvrent à toi. Le PvP y est permanent.');
    qEvent('level');setSkillLabels();}
  if(P.lvl>=MAX_LVL)P.xp=0;}
function hurtPlayer(d,src){if(state!=='play'||P.inv0>0||P.hp<=0)return;const s=stats();
  if(rnd()*100<s.dodge){addText(P.x,P.y-28,'Esquive','#b3e8ff');return;}
  const mit=s.def/(s.def+40+10*P.lvl);let dmg=Math.max(1,Math.round(d*rr(.9,1.1)*(1-mit)*(1-s.dr)));if(P.shield>0){const ab=Math.min(P.shield,dmg);P.shield-=ab;dmg-=ab;if(ab)addText(P.x+10,P.y-40,'absorbé '+ab,'#c58cff');if(!dmg)return;}P.hp-=dmg;P.lastHit=0;addText(P.x,P.y-28,'-'+dmg,'#ff5a5a');
  if(P.hp<=0){P.hp=0;die(src);}}
function die(src){P.deaths++;P.target=null;P.harv=null;
  if(P.hc){state='tomb';const c=CHARS[CI];CHARS.splice(CI,1);saveJSON(CHAR_KEY,CHARS);CI=-1;openPanel('tomb',{src,c:P});return;}
  const loss=deathXpLoss(P.lvl)+(P.pkT>0?.15:0),lost=Math.round(xpNeed(P.lvl)*loss);P.xp=Math.max(0,P.xp-lost);
  for(const sl of SLOTS)if(P.eq[sl])P.eq[sl].dur=Math.max(0,P.eq[sl].dur-10);
  let dropped=null;if(P.pkT>0&&P.inv.length&&rnd()<.5){dropped=P.inv.splice(ri(0,P.inv.length-1),1)[0];}
  state='dead';openPanel('death',{src,lost,dropped});}
function respawn(){const s=stats();P.hp=Math.round(s.maxhp*.6);P.mp=Math.round(s.maxmp*.6);state='play';dgRun=null;$('#modal').hidden=true;paused=false;panelKind=null;P.inv0=2;transition(FACTIONS[P.fac].cap,{});}
function alloc(k,n){n=Math.min(n,P.pts);if(n<=0)return;P.al[k]+=n;P.pts-=n;clampHM();qEvent('stats');}
function resetStats(){const cost=resetCost();if(P.gold<cost)return false;P.gold-=cost;for(const k of STATS5)P.al[k]=0;P.pts=(P.lvl-1)*(P.hc?PTS_LVL.hc:PTS_LVL.normal);clampHM();return true;}
const resetCost=()=>P.lvl<15?0:P.lvl*60;

/* ---------- combat du joueur ---------- */
function aimVec(){const t=P.target;if(t&&!t.dead){const dx=t.x-P.x,dy=(t.y-(t.hh||12))-(P.y-12),l=Math.hypot(dx,dy)||1;return[dx/l,dy/l];}return[P.fx,P.fy];}
function pdmg(t,mult,o){o=o||{};const s=stats();const gap=Math.max(0,(t.lv||t.lvl||P.lvl)-P.lvl);if(!o.sure&&rnd()*100>s.hit-Math.min(35,gap*4))return{d:0,miss:1};let df=(t.def||0)*(t.sunT>0?1-t.sunV:1)*(1-(o.ign||0));let d=((o.ma?s.matk:s.atk)*mult*rr(.9,1.1)-df*.5)*Math.max(.55,1-gap*.05);const crit=o.crit||rnd()*100<s.crit+(o.cb||0);if(crit)d*=1.6;return{d:Math.max(1,Math.round(d)),crit};}
function hitTarget(t,mult,col,o){const r=pdmg(t,mult,o);if(r.miss){addText(t.x,t.y-(t.hh||12)*2-4,'Raté','#9a90b0');if(t.kind==='m'&&!t.agg){t.agg=true;t.ret=false;}return r;}if(t.kind==='m')hitMon(t,r.d,col,false,r.crit);else hitBot(t,r.d,P);return r;}
function shoot(dx,dy,o){const c=CLASSES[P.cls];projs.push(Object.assign({x:P.x+dx*6,y:P.y-12+dy*6,vx:dx*c.proj.spd,vy:dy*c.proj.spd,life:(c.range+(stats().rngB||0))/c.proj.spd+.12,from:'p',r:c.proj.r,col:c.proj.col,hit:new Set(),mult:1},o));}
function basicAttack(){const c=CLASSES[P.cls],s=stats(),t=P.target;if(!canTarget(t))return;P.atkT=c.cd*s.aspd;const[dx,dy]=aimVec();P.fx=dx;P.fy=dy;P.dir=dirOf(dx,dy);P.flip=dx<0;
  if(c.ranged)shoot(dx,dy,{});else{hitTarget(t,1);P.lunge=.12;addFx({k:'slash',x:P.x+dx*12,y:P.y-12+dy*12,a:Math.atan2(dy,dx),life:.18,col:'#f1e9d6'});}}
function enemiesNear(x,y,r){const out=[];for(const m of mons)if(!m.dead&&Math.hypot(m.x-x,m.y-y)<r+m.hr*.6)out.push(m);if(inPvp())for(const b of bots)if(b.map===curId()&&canTarget(b)&&Math.hypot(b.x-x,b.y-y)<r)out.push(b);return out;}
const RV=(x,rk)=>Array.isArray(x)?x[Math.max(1,rk)-1]:x;
let traps=[];
function updTraps(dt){for(const tp of traps){tp.t-=dt;if(tp.t<=0)continue;const es=enemiesNear(tp.x,tp.y,16);if(es.length){const e=es[0];e.root=tp.root;addText(e.x,e.y-(e.hh||12)*2-14,'Entravé','#a8e8a0');addFx({k:'roots',x:e.x,y:e.y,life:tp.root,tgt:e});burst(tp.x,tp.y-4,'#a8e8a0',10);tp.t=0;}}traps=traps.filter(t=>t.t>0&&t.map===curId());}
function moveDir(len,back){let mx=P.fx,my=P.fy;if(joyV.x||joyV.y){const l=Math.hypot(joyV.x,joyV.y);mx=joyV.x/l;my=joyV.y/l;}if(back){mx=-mx;my=-my;}for(let k=0;k<10;k++)moveEnt(P,mx*len/10,my*len/10,false);P.moveTo=null;}
function useSkill(i){if(state!=='play'||paused||i==null)return;const c=CLASSES[P.cls],sk=c.sk[i],s=stats();
  if(!sk)return;const rk=skRank(i);if(!rk){toast(sk.n+' : grimoire requis','Où le trouver : '+c.src[i]);return;}
  if(P.lvl<sk.lv){toast(sk.n+' : niveau '+sk.lv+' requis');return;}if(P.sk[i]>0)return;const mp=Math.round(RV(sk.mp,rk)*encMp()),cd=RV(sk.cd,rk),m=RV(sk.m,rk),v=RV(sk.v,rk);if(P.mp<mp){addText(P.x,P.y-30,'PM insuffisants','#7fb0ff');return;}
  const t=P.target,hasT=canTarget(t);const[dx,dy]=aimVec();const ma=P.cls==='mage';
  const need={basic:c.range+14,charge:150,stun:c.range+14,execute:c.range+14,sunder:c.range+14,root:180,curse:200,snipe:c.range+80};
  if(need[sk.k]&&(!hasT||dist(P,t)>need[sk.k]+(t&&t.hr?t.hr*.6:0))){addText(P.x,P.y-30,'Aucune cible à portée','#b3a8c7');return;}
  P.mp-=mp;P.sk[i]=cd;qEvent('cast');if(hasT){P.fx=dx;P.fy=dy;P.dir=dirOf(dx,dy);P.flip=dx<0;}
  if(hasT&&!['heal','shield','rally','bastion','tracker','benison','leap','blink','massheal','trap','taunt'].includes(sk.k)&&dist(P,t)<=atkRange(t)+60)P.atkOn=true;
  const lbl=(e,txt,col)=>addText(e.x,e.y-(e.hh||12)*2-14,txt,col),ctl=x=>+(x*s.ctl).toFixed(1);
  const zone=(cx,cy,r,mult,col,max,o)=>{let n=0;for(const e of enemiesNear(cx,cy,r)){if(max&&n>=max)break;hitTarget(e,mult*s.aoe,col,o);n++;if(o&&o.after)o.after(e);}addFx({k:'ring',x:cx,y:cy-6,r0:6,r1:r,life:.35,col});burst(cx,cy-8,col,16);};
  switch(sk.k){
  case'basic':if(c.ranged)shoot(dx,dy,{mult:m,ma});else{hitTarget(t,m);P.lunge=.12;addFx({k:'slash',x:P.x+dx*12,y:P.y-12+dy*12,a:Math.atan2(dy,dx),life:.18,col:'#f1e9d6'});}break;
  case'charge':{const d=dist(P,t),st=Math.max(0,d-16);for(let k=0;k<10;k++)moveEnt(P,dx*st/10,dy*st/10,false);P.inv0=.3;P.atkOn=true;hitTarget(t,m,'#ff8a5a');t.slow=ctl(3);lbl(t,'Ralenti '+Math.round(RV(sk.slow,rk)*100)+' %','#a8e8ff');addFx({k:'ring',x:P.x,y:P.y-8,r0:4,r1:22,life:.3,col:'#ff8a5a'});P.chase=true;break;}
  case'stun':hitTarget(t,m);t.stun=ctl(RV(sk.stun,rk));lbl(t,'Étourdi','#ffd36a');addFx({k:'ring',x:t.x,y:t.y-6,r0:16,r1:6,life:.4,col:'#ffd36a'});P.lunge=.15;break;
  case'taunt':{let n=0;for(const e of enemiesNear(P.x,P.y,sk.r)){if(e.kind==='m'){e.agg=true;e.ret=false;e.ac=Math.max(e.ac||0,.4);}else{e.stun=Math.max(e.stun||0,.6);}n++;}addFx({k:'ring',x:P.x,y:P.y-8,r0:sk.r,r1:8,life:.5,col:'#ff5a3a'});addText(P.x,P.y-34,'Provocation ('+n+')','#ff7a5a');break;}
  case'aoe':zone(P.x,P.y,sk.r,m,sk.col,sk.max);break;
  case'rally':{const h=v*s.buffp;addBuff({id:'rally',n:'Cri de ralliement',hp:h,t:sk.dur});for(const b of partyNear())b.hp=Math.min(b.maxhp*(1+h),b.hp+b.maxhp*h);addFx({k:'ring',x:P.x,y:P.y-8,r0:6,r1:60,life:.6,col:'#f2c14e'});addText(P.x,P.y-34,'PV max +'+Math.round(h*100)+' %','#f2c14e');break;}
  case'execute':{const low=t.hp/(t.maxhp||1)<RV(sk.th,rk);hitTarget(t,low?m*2.2:m,low?'#ff3a3a':'#ffb36a',{cb:low?25:0});P.lunge=.18;if(low)burst(t.x,t.y-10,'#ff3a3a',16);break;}
  case'sunder':hitTarget(t,m,'#ffb36a');t.sunT=6;t.sunV=v;lbl(t,'Défense −'+Math.round(v*100)+' %','#ffb36a');P.lunge=.15;break;
  case'bastion':addBuff({id:'bastion',n:'Bastion inébranlable',dr:v,t:sk.dur});addFx({k:'ring',x:P.x,y:P.y-8,r0:30,r1:8,life:.6,col:'#d8d8ff'});addText(P.x,P.y-34,'Bastion !','#d8d8ff');break;
  case'slowshot':shoot(dx,dy,{mult:m,slow:ctl(3),col:'#a8e8ff',r:3});break;
  case'tracker':addBuff({id:'tracker',n:'Poste de traqueur',crit:v,rng:RV(sk.rng,rk),t:sk.dur});addFx({k:'ring',x:P.x,y:P.y-8,r0:26,r1:6,life:.5,col:'#ffd36a'});addText(P.x,P.y-34,'Traqueur','#ffd36a');break;
  case'trap':traps.push({x:P.x,y:P.y,t:30,root:ctl(RV(sk.root,rk)),map:curId()});addText(P.x,P.y-30,'Piège posé','#a8e8a0');break;
  case'volley':{const a0=Math.atan2(dy,dx);for(let k=0;k<sk.cnt;k++){const a=a0+(k-(sk.cnt-1)/2)*.15;shoot(Math.cos(a),Math.sin(a),{mult:m*s.aoe});}break;}
  case'pierce':shoot(dx,dy,{mult:m,pierce:true,ign:RV(sk.ign,rk),cb:25,vx:dx*380,vy:dy*380,life:.75,r:3,col:'#fff2a8'});break;
  case'snipe':{const out=t.kind==='m'?!t.agg:(t.atkT||0)<=-2;shoot(dx,dy,{mult:m,crit:out,vx:dx*480,vy:dy*480,life:(c.range+RV(sk.rng,rk))/480+.1,r:3,col:'#ffffff'});if(out)addText(P.x,P.y-34,'Tir parfait','#ffd36a');break;}
  case'leap':moveDir(sk.len,true);P.inv0=.4;P.root=0;P.slow=0;addBuff({id:'leap',n:'Esquive acrobatique',dodge:v,t:sk.dur});addFx({k:'ring',x:P.x,y:P.y-8,r0:4,r1:18,life:.25,col:'#f1e9d6'});break;
  case'rain':{const cx=hasT?t.x:P.x+P.fx*60,cy=hasT?t.y:P.y+P.fy*60,W=RV(sk.waves,rk);addFx({k:'tele',x:cx,y:cy-4,r:sk.r,life:.5,col:'#f5e6a8'});for(let w=0;w<W;w++)setTimeout(()=>{if(state!=='play')return;for(const e of enemiesNear(cx,cy,sk.r))hitTarget(e,m*s.aoe);for(let k=0;k<10;k++)projs.push({x:cx+rr(-sk.r,sk.r),y:cy-90+rr(-20,20),vx:0,vy:320,life:.28,from:'v',r:2,col:'#f5e6a8'});addFx({k:'ring',x:cx,y:cy-4,r0:8,r1:sk.r,life:.3,col:'#f5e6a8'});},450+w*550);break;}
  case'heal':{const h=Math.round(s.maxhp*v*s.heal);P.hp=Math.min(s.maxhp,P.hp+h);addText(P.x,P.y-34,'+'+h,'#9be36a');const pn=partyNear().filter(b=>b.hp<b.maxhp).sort((a,b)=>a.hp/a.maxhp-b.hp/b.maxhp)[0];if(pn){pn.hp=Math.min(pn.maxhp,pn.hp+pn.maxhp*v*s.heal*1.2);addFx({k:'ring',x:pn.x,y:pn.y-8,r0:16,r1:6,life:.5,col:'#9be36a'});}addFx({k:'ring',x:P.x,y:P.y-8,r0:24,r1:6,life:.5,col:'#9be36a'});burst(P.x,P.y-14,'#9be36a',12);break;}
  case'root':hitTarget(t,m,'#a8e8a0',{ma});t.root=ctl(RV(sk.root,rk));lbl(t,'Immobilisé','#a8e8a0');addFx({k:'roots',x:t.x,y:t.y,life:t.root,tgt:t});break;
  case'shield':{const sh=Math.round(v*(1+(s.a.int+s.a.sag)*.004));P.shield=sh;addBuff({id:'shield',n:'Barrière arcanique ('+sh+')',t:sk.dur});addFx({k:'ring',x:P.x,y:P.y-8,r0:6,r1:30,life:.6,col:'#c58cff'});burst(P.x,P.y-14,'#c58cff',18);addText(P.x,P.y-34,'Bouclier '+sh,'#c58cff');break;}
  case'curse':{const d=RV(sk.dur,rk);t.weak=v;t.weakT=ctl(d);if(t.kind==='b')t.atkT=(t.atkT||0)+1;lbl(t,'Maudit −'+Math.round(v*100)+' % ATK','#c58cff');addFx({k:'ring',x:t.x,y:t.y-6,r0:20,r1:6,life:.5,col:'#8a5ac8'});break;}
  case'storm':{const cx=hasT&&dist(P,t)<220?t.x:P.x,cy=hasT&&dist(P,t)<220?t.y:P.y;zone(cx,cy,sk.r,m,'#7ff3ff',sk.max,{ma});for(let k=0;k<5;k++)addFx({k:'meteor',x:cx+rr(-sk.r*.6,sk.r*.6),y:cy+rr(-sk.r*.4,sk.r*.4),life:.35});break;}
  case'benison':{const vv=v*s.buffp;addBuff({id:'benison',n:'Flux de mana et bénédiction',intp:vv,sagp:vv,mreg:vv*3,t:sk.dur});addFx({k:'ring',x:P.x,y:P.y-8,r0:6,r1:60,life:.6,col:'#8ab4ff'});addText(P.x,P.y-34,'INT/SAG +'+Math.round(vv*100)+' %','#8ab4ff');break;}
  case'blink':moveDir(RV(sk.len,rk));P.inv0=.2;burst(P.x,P.y-12,'#c58cff',14);addFx({k:'ring',x:P.x,y:P.y-8,r0:18,r1:4,life:.3,col:'#c58cff'});break;
  case'massheal':{const h=Math.round(s.maxhp*v*s.heal);P.hp=Math.min(s.maxhp,P.hp+h);addText(P.x,P.y-34,'+'+h,'#9be36a');for(const b of partyNear())if(Math.hypot(b.x-P.x,b.y-P.y)<sk.r){b.hp=Math.min(b.maxhp,b.hp+b.maxhp*v*s.heal);addFx({k:'ring',x:b.x,y:b.y-8,r0:16,r1:6,life:.5,col:'#9be36a'});}addFx({k:'ring',x:P.x,y:P.y-8,r0:6,r1:sk.r,life:.6,col:'#9be36a'});burst(P.x,P.y-14,'#9be36a',22);break;}
  case'apoca':{const cx=hasT?t.x:P.x+P.fx*70,cy=hasT?t.y:P.y+P.fy*70;addFx({k:'tele',x:cx,y:cy-4,r:sk.r,life:.7,col:'#ff5a3a'});setTimeout(()=>{if(state!=='play')return;zone(cx,cy,sk.r,m,'#ff8a3a',0,{ma,after:e=>{e.stun=Math.max(e.stun||0,.6);}});for(let k=0;k<10;k++)addFx({k:'meteor',x:cx+rr(-sk.r*.7,sk.r*.7),y:cy+rr(-sk.r*.5,sk.r*.5),life:.4});},700);break;}
  }
}
function usePot(k){if(state!=='play'||paused||P.potT>0)return;const s=stats();
  if(k==='pv'){if(!(P.cons.pv>0)||P.hp>=s.maxhp)return;P.cons.pv--;const h=Math.round(s.maxhp*.45);P.hp=Math.min(s.maxhp,P.hp+h);addText(P.x,P.y-30,'+'+h,'#ff8a8a');}
  else{if(!(P.cons.pm>0)||P.mp>=s.maxmp)return;P.cons.pm--;const h=Math.round(s.maxmp*.5);P.mp=Math.min(s.maxmp,P.mp+h);addText(P.x,P.y-30,'+'+h,'#8ab4ff');}P.potT=1;}
function useCons(k){const c=CONS[k];if(!(P.cons[k]>0))return;
  if(k==='pv'||k==='pm'){usePot(k);return;}
  if(k==='retour'){if(state!=='play')return;P.cons[k]--;closePanel(true);dgRun=null;transition(FACTIONS[P.fac].cap,{});return;}
  if(c.book){if(c.book.cls!==P.cls){toast('Ce grimoire est destiné à la classe '+CLASSES[c.book.cls].nom,'Tu peux le vendre à l’hôtel des ventes');return;}const i=c.book.i,sk=CLASSES[P.cls].sk[i];if(!sk)return;if(skRank(i)>=3){toast('Rang maximum déjà atteint');return;}P.cons[k]--;P.skr[i]=skRank(i)+1;if(P.skr[i]===1){const slot=autoBar(i);toast('Nouveau sort : '+sk.n,(P.lvl<sk.lv?'Utilisable au niveau '+sk.lv+'. ':'')+(slot>=0?'Placé en case '+(slot+1)+' de ta barre':'Place-le dans ta barre depuis la fenêtre des sorts'));qEvent('learn');}else toast(sk.n+' rang '+P.skr[i],'+25 % d’efficacité');burst(P.x,P.y-14,'#c58cff',20);setSkillLabels();return;}
  if(c.buff){P.cons[k]--;addBuff(c.buff);toast(c.n,c.d);return;}
  if(k.startsWith('ench'))toast('Les parchemins s’utilisent chez le forgeron');}
function atkRange(t){const c=CLASSES[P.cls],s=stats();return c.range+(s.rngB||0)+(t.kind==='m'?t.hr*.6:4)+4;}
function attackBtn(){if(state!=='play'||paused)return;
  if(!canTarget(P.target)){let best=null,bd=190;for(const m of mons)if(!m.dead&&!m.team){const d=dist(m,P);if(d<bd){bd=d;best=m;}}
    if(inPvp())for(const b of bots)if(b.map===curId()&&canTarget(b)&&!(b.fac===P.fac&&!b.pk&&P.pkT<=0)){const d=dist(b,P);if(d<bd){bd=d;best=b;}}
    if(!best){addText(P.x,P.y-30,'Aucune cible','#b3a8c7');return;}P.target=best;P.atkOn=false;}
  const t=P.target;if(dist(P,t)>atkRange(t)){addText(P.x,P.y-30,'Trop loin : rapproche-toi','#ffb36a');addFx({k:'ring',x:P.x,y:P.y-4,r0:atkRange(t),r1:atkRange(t)-4,life:.6,col:'#ffb36a'});return;}
  P.atkOn=true;P.moveTo=null;P.chase=false;const[dx,dy]=[t.x-P.x,t.y-P.y];P.dir=dirOf(dx,dy);P.flip=dx<0;if(P.atkT<=0)basicAttack();}

/* ---------- interactions ---------- */
function interactTarget(){
  for(const b of bags)if((b.owner==='p'||b.owner==='free')&&Math.hypot(b.x-P.x,b.y-P.y)<24)return{k:'bag',o:b,l:'Ramasser'};
  for(const n of M.npcs)if(Math.hypot(n.x-P.x,n.y-P.y)<34)return{k:'npc',o:n,l:'Parler'};
  if(M.stations)for(const s of M.stations)if(Math.hypot(s.x-P.x,s.y-P.y)<30)return{k:'station',o:s,l:{alambic:'Alambic',pupitre:'Pupitre',enclume:'Enclume'}[s.k]};
  for(const p of M.portals)if(Math.hypot(p.x-P.x,p.y-P.y)<34)return{k:'portal',o:p,l:p.out?'Sortir':'Entrer'};
  if(M.steles)for(const s of M.steles)if(Math.hypot(s.x-P.x,s.y-P.y)<28)return{k:'stele',o:s,l:'Lire'};
  if(M.board&&Math.hypot(M.board.x-P.x,M.board.y-P.y)<30)return{k:'board',l:'Primes'};
  if(M.stairs&&Math.hypot(M.stairs.x-P.x,M.stairs.y-P.y)<30)return{k:'stairs',l:'Descendre'};
  if(M.chest&&!M.chest.open&&Math.hypot(M.chest.x-P.x,M.chest.y-P.y)<26)return{k:'chest',l:'Ouvrir'};
  for(const n of M.nodes){if(!n.alive)continue;const fx=n.fx||n.x,fy=n.fy||n.y;if(Math.hypot(fx-P.x,fy-P.y)<(n.kind==='poisson'?22:24)||Math.hypot(n.x-P.x,n.y-P.y)<22)return{k:'node',o:n,l:PROFS[RES[n.res].prof].verb};}
  return null;}
function actionBtn(){if(state!=='play'||paused)return;const it=interactTarget();if(!it)return;
  if(it.k==='npc'){const n=it.o;if(n.fac&&n.fac!==P.fac){toast('Cet habitant refuse de te parler');return;}if(n.qid)qEvent('talk',n.qid);if(n.role==='quest'||n.role==='camp')openPanel('npc',n);else openPanel(n.role);}
  else if(it.k==='station')openPanel('craft',{prof:{alambic:'alchimiste',pupitre:'scribe',enclume:'runesmith'}[it.o.k]});
  else if(it.k==='bag'){const b=it.o;pickBag(b,false);if(bagEmpty(b)){const i=bags.indexOf(b);if(i>=0)bags.splice(i,1);}}
  else if(it.k==='stele')readStele(it.o);
  else if(it.k==='board')openPanel('primes');
  else if(it.k==='portal'){if(it.o.out)leaveDungeon();else enterDungeon(it.o);}
  else if(it.k==='stairs')nextFloor();
  else if(it.k==='chest')openChest();
  else if(it.k==='node')startHarvest(it.o);}
function startHarvest(n){const r=RES[n.res],pl=P.prof[r.prof].l;if(pl<r.lvl){toast(PROFS[r.prof].n+' niveau '+r.lvl+' requis','Ton niveau actuel : '+pl);return;}P.harv={n,t:0};P.moveTo=null;}
function openChest(){const D=DUNGEONS[M.dg],tier=tierFor(D.lv[1]),b={x:M.chest.x,y:M.chest.y+10,items:[],cons:{},res:{},gold:ri(D.lv[1]*40,D.lv[1]*80),t:120,owner:'p'};
  const n=ri(3,4);for(let k=0;k<n;k++)b.items.push(mkItem(P,pick(LOOT_TYPES),tier,rnd()<.06?3:rnd()<.35?2:1,rnd()<.6?P.cls:null));
  b.cons[D.lv[1]>=35?'ench3':D.lv[1]>=20?'ench2':'ench1']=1;if(rnd()<.3){const k=bookKey();if(k)b.cons[k]=1;}
  M.chest.open=true;bags.push(b);burst(b.x,b.y-6,'#ffd36a',24);chat(null,`${P.name} a terminé ${D.n} !`);}
function profAdd(k,xp){const p=P.prof[k];if(p.l>=PROF_MAX)return;p.xp+=Math.round(xp);let up=false;while(p.l<PROF_MAX&&p.xp>=profNeed(p.l)){p.xp-=profNeed(p.l);p.l++;up=true;}if(up)toast(PROFS[k].n+' niveau '+p.l,'De nouvelles ressources ou recettes sont accessibles');}
function finishHarvest(n){const r=RES[n.res],p=P.prof[r.prof],gap=p.l-r.lvl,qty=1+(rnd()<p.l/80?1:0);
  P.res[n.res]=(P.res[n.res]||0)+qty;n.alive=false;n.rt=rr(30,50);addText(n.x,n.y-20,'+'+qty+' '+r.n,'#d8e8c0');burst(n.x,n.y-8,'#d8e8c0',8);
  profAdd(r.prof,[6,14,26,44][r.tier]*(gap>=20?.3:gap>=10?.6:1));qEvent('harvest');}
function canCraft(rc){if(P.prof[rc.prof].l<rc.lvl)return false;for(const [k,q] of Object.entries(rc.ing))if((P.res[k]||0)<q)return false;if(rc.out.eq&&invFull())return false;return true;}
function craft(rc){if(!canCraft(rc))return null;for(const [k,q] of Object.entries(rc.ing))P.res[k]-=q;let msg;
  if(rc.out.eq){const pl=P.prof[rc.prof].l,r=rnd()*100,rar=r<.5+pl*.08?3:r<2+pl*.25?2:r<10+pl*.7?1:0;const it=mkItem(P,rc.out.eq,rc.out.tier,rar,rc.out.cls);it.by=P.name;P.inv.push(it);msg=`<span style="color:${RARC[rar]}">${esc(itemName(it))}</span> (${RAR[rar]})`;}
  else{P.cons[rc.out.cons]=(P.cons[rc.out.cons]||0)+rc.out.n;msg=rc.out.n+' × '+CONS[rc.out.cons].n;}
  profAdd(rc.prof,rc.xp);qEvent('craft');return msg;}

/* ---------- enchantement (parchemins) et réparation ---------- */
function enchInfo(it){const p=it.plus;const scroll=p<4?'ench1':p<7?'ench2':'ench3';return{scroll,gold:Math.round(30*Math.pow(p+1,1.6)*(1+it.tier*.3)),chance:[100,92,84,74,64,52,42,32,22,14][p]};}
function enchant(it){const e=enchInfo(it);if(it.plus>=10||!(P.cons[e.scroll]>0)||P.gold<e.gold)return null;P.cons[e.scroll]--;P.gold-=e.gold;
  if(rnd()*100<e.chance){it.plus++;if(it.plus>=7)chat(null,`${P.name} a enchanté ${itemName(it)} !`);qEvent('enchant',it.plus);return{ok:true,t:'Réussi ! '+itemName(it)};}
  if(it.plus>=8&&rnd()<.2){for(const sl of SLOTS)if(P.eq[sl]===it)P.eq[sl]=null;P.inv=P.inv.filter(i=>i!==it);clampHM();return{ok:false,t:'L’objet s’est brisé sous la magie…'};}
  if(it.plus>=5){it.plus--;return{ok:false,t:'Échec : l’objet redescend à +'+it.plus+'.'};}
  return{ok:false,t:'Échec. Rien n’est perdu à ce niveau.'};}
function repairCost(){let c=0;for(const sl of SLOTS){const it=P.eq[sl];if(it)c+=(100-it.dur)*(it.tier+1)*.6;}for(const it of P.inv)c+=(100-it.dur)*(it.tier+1)*.6;return Math.round(c);}
function repairAll(){const c=repairCost();if(P.gold<c)return false;P.gold-=c;for(const sl of SLOTS)if(P.eq[sl])P.eq[sl].dur=100;for(const it of P.inv)it.dur=100;clampHM();return true;}

/* ---------- familier ---------- */
function updPet(dt){if(!P.pet){petE=null;return;}if(!petE)petE={x:P.x,y:P.y,anim:0,flip:false,tb:null};const F=P.petF;
  const wants=b=>(b.owner==='p'||b.owner==='free')&&((b.gold&&F.gold)||(F.cons&&Object.keys(b.cons).length)||(F.res&&Object.keys(b.res).length)||(F.eq&&b.items.some(i=>i.rar>=F.min)));
  if(petE.tb&&(!bags.includes(petE.tb)||!wants(petE.tb)))petE.tb=null;
  if(!petE.tb){let bd=150;for(const b of bags)if(wants(b)&&dist(b,P)<150){const d=dist(b,petE);if(d<bd){bd=d;petE.tb=b;}}}
  let gx,gy,spd=95;if(petE.tb){gx=petE.tb.x;gy=petE.tb.y;spd=130;}else{gx=P.x-(P.flip?-16:16);gy=P.y+4;}
  const dx=gx-petE.x,dy=gy-petE.y,d=Math.hypot(dx,dy);
  if(d>3){const s=Math.min(d,spd*dt*(d>200?4:1));petE.x+=dx/d*s;petE.y+=dy/d*s;petE.anim+=dt*8;petE.flip=dx<0;}
  if(petE.tb&&d<8){pickBag(petE.tb,true);if(bagEmpty(petE.tb))bags.splice(bags.indexOf(petE.tb),1);petE.tb=null;}}

/* ---------- groupe ---------- */
function partyInvite(b){if(b.fac!==P.fac||b.pk)return'Impossible';if(!party)party={loot:'chef',members:[]};if(party.members.length>=3)return'Groupe complet (4 joueurs)';
  if(rnd()<.25){chat(b.n,'désolé, pas dispo','#9be3ff','party');return b.n+' a refusé.';}b.party=true;b.map=curId();party.members.push(b);chat(null,b.n+' rejoint le groupe.');return b.n+' rejoint ton groupe.';}
function partyKick(b){if(!party)return;b.party=false;party.members=party.members.filter(x=>x!==b);b.map=b.home;if(!party.members.length)party=null;chat(null,b.n+' quitte le groupe.');}
function partyLeave(){if(!party)return;for(const b of party.members){b.party=false;b.map=b.home;}party=null;chat(null,'Tu as quitté le groupe.');}

/* ---------- guildes ---------- */
const guildNeed=l=>Math.round(1500*Math.pow(l,1.5));
function guildAddXp(n){const g=P.guild;if(!g||g.lvl>=10)return;g.xp+=n;while(g.lvl<10&&g.xp>=guildNeed(g.lvl)){g.xp-=guildNeed(g.lvl);g.lvl++;toast('Guilde niveau '+g.lvl,g.name+' gagne de nouveaux bonus');chat(null,`La guilde ${g.name} passe au niveau ${g.lvl} !`,null,'guild');}}
function guildCreate(name){name=(name||'').trim().slice(0,20);if(name.length<3)return'Le nom doit faire au moins 3 caractères.';if(P.lvl<5)return'Niveau 5 requis.';if(P.gold<300)return'Il faut 300 or.';
  P.gold-=300;P.guild={name,lvl:1,xp:0,role:'Chef',members:[{n:P.name,cls:P.cls,lvl:P.lvl,role:'Chef'}],mission:{n:40,prog:0},founded:Date.now()};chat(null,'Guilde fondée : '+name,null,'guild');return null;}
function guildJoin(g){const mem=bots.filter(b=>b.fac===P.fac&&b.guild===g.n).map(b=>({n:b.n,cls:b.cls,lvl:b.lvl,role:'Membre'}));if(mem[0])mem[0].role='Chef';
  P.guild={name:g.n,lvl:g.lvl,xp:0,role:'Recrue',members:mem.concat([{n:P.name,cls:P.cls,lvl:P.lvl,role:'Recrue'}]),mission:{n:40+g.lvl*10,prog:0}};chat(null,'Bienvenue dans '+g.n+' !',null,'guild');}
function guildLeave(){if(!P.guild)return;chat(null,'Tu as quitté '+P.guild.name+'.',null,'guild');P.guild=null;}
function guildInvite(b){const g=P.guild;if(!g||!['Chef','Officier'].includes(g.role))return'Seuls le chef et les officiers recrutent.';if(b.guild)return b.n+' a déjà une guilde.';
  if(rnd()<.4)return b.n+' décline l’invitation.';b.guild=g.name;g.members.push({n:b.n,cls:b.cls,lvl:b.lvl,role:'Membre'});chat(b.n,'merci pour l’invitation !','#9be36a','guild');return b.n+' rejoint la guilde.';}
function guildMissionClaim(){const g=P.guild,m=g.mission;if(m.prog<m.n)return;guildAddXp(600*g.lvl);const gold=100*g.lvl;P.gold+=gold;m.n=40+g.lvl*10;m.prog=0;toast('Mission de guilde accomplie','+'+gold+' or, XP de guilde');}
function guildTick(){const g=P.guild;if(!g)return;guildAddXp(g.members.length*2*g.lvl);if(rnd()<.5){const mm=g.members.filter(x=>x.n!==P.name);if(mm.length)chat(pick(mm).n,pick(GUILD_LINES),'#9be36a','guild');}}

/* ---------- hôtel des ventes de faction ---------- */
function genMarket(){MARKET=[];const names=BOT_NAMES[P.fac],tp=tierFor(P.lvl);
  for(let i=0;i<16;i++){const tier=clamp(tp+ri(-1,1),0,9),rar=rnd()<.06?3:rnd()<.12?2:rnd()<.4?1:0,it=mkItem(P,pick(LOOT_TYPES),tier,rar,rnd()<.55?P.cls:null);MARKET.push({id:'m'+i,seller:pick(names),item:it,price:Math.round(itemValue(it)*rr(2.2,4.5))});}
  for(const r of Object.keys(RES))if(rnd()<.5){const q=pick([5,10,20]);MARKET.push({id:'r'+r,seller:pick(names),res:r,qty:q,price:Math.round(q*RES_PRICE[RES[r].tier]*rr(.8,1.4))});}
  for(const c of ['pv','pm','ench1','ench2','elxp','elatk','retour','plat2','parch'])if(rnd()<.6){const q=c.startsWith('ench')?ri(1,3):pick([3,5,10]);MARKET.push({id:'c'+c,seller:pick(names),cons:c,qty:q,price:Math.round(q*CONS[c].price*rr(.9,1.5))});}
  if(rnd()<.7){const k=bookKey();if(k)MARKET.push({id:'b'+k,seller:pick(names),cons:k,qty:1,price:Math.round(CONS[k].price*rr(1,2))});}
  marketT=240;}
function fairPrice(l){if(l.item)return itemValue(l.item)*3;if(l.res)return l.qty*RES_PRICE[RES[l.res].tier];return l.qty*CONS[l.cons].price;}
function hdvBuy(id){const l=MARKET.find(x=>x.id===id);if(!l)return'Annonce expirée.';if(P.gold<l.price)return'Pas assez d’or.';if(l.item&&invFull())return'Sac plein.';
  P.gold-=l.price;if(l.item){l.item.id=P.uid++;P.inv.push(l.item);}else if(l.res)P.res[l.res]=(P.res[l.res]||0)+l.qty;else P.cons[l.cons]=(P.cons[l.cons]||0)+l.qty;MARKET=MARKET.filter(x=>x!==l);return'Achat réussi.';}
function hdvList(kind,key,price,qty){price=Math.max(1,Math.round(price||0));if(P.hdv.list.length>=10)return'Maximum 10 annonces.';const fee=Math.max(1,Math.round(price*.02));if(P.gold<fee)return'Frais de mise en vente : '+fee+' or.';
  const L={id:'p'+Date.now()+ri(0,999),price,t:0};
  if(kind==='item'){const it=P.inv.find(i=>i.id===key);if(!it)return'Objet introuvable.';P.inv=P.inv.filter(i=>i!==it);L.item=it;}
  else if(kind==='res'){qty=Math.min(qty,P.res[key]||0);if(qty<1)return'Quantité insuffisante.';P.res[key]-=qty;L.res=key;L.qty=qty;}
  else{qty=Math.min(qty,P.cons[key]||0);if(qty<1)return'Quantité insuffisante.';P.cons[key]-=qty;L.cons=key;L.qty=qty;}
  P.gold-=fee;P.hdv.list.push(L);return'Mis en vente pour '+price+' or (frais '+fee+' or).';}
function hdvCancel(id){const L=P.hdv.list.find(x=>x.id===id);if(!L)return;if(L.item){if(invFull())return'Sac plein.';P.inv.push(L.item);}else if(L.res)P.res[L.res]=(P.res[L.res]||0)+L.qty;else P.cons[L.cons]=(P.cons[L.cons]||0)+L.qty;P.hdv.list=P.hdv.list.filter(x=>x!==L);return'Annonce retirée.';}
function hdvTick(){for(const L of [...P.hdv.list]){const p=clamp(.3*Math.pow(fairPrice(L)/L.price,2),.02,.6);if(rnd()<p){P.hdv.mail+=Math.round(L.price*.95);P.hdv.list=P.hdv.list.filter(x=>x!==L);chat(null,'Hôtel des ventes : '+lotName(L)+' vendu pour '+L.price+' or.');}}}
function lotName(l){return l.item?itemName(l.item):l.res?l.qty+' × '+RES[l.res].n:l.qty+' × '+CONS[l.cons].n;}

/* ---------- guerre de faction (boost d'XP façon TWOM) ---------- */
function updWar(dt){WAR.t-=dt;
  if(WAR.st==='idle'){if(WAR.t<=30&&!WAR.ann){WAR.ann=true;chat(null,'Les cors sonnent : la guerre de la Frontière commence dans 30 secondes !');}if(WAR.t<=0)startWar();}
  else{WAR.tick-=dt;if(WAR.tick<=0){WAR.tick=1;
      if(curId()==='c_front'&&M.fort){WAR.part=true;const cnt={solarix:0,umbra:0};if(P.hp>0&&dist(P,M.fort)<90)cnt[P.fac]++;for(const b of bots)if(!b.dead&&b.map==='c_front'&&dist(b,M.fort)<90)cnt[b.fac]++;
        if(cnt.solarix!==cnt.umbra){const w=cnt.solarix>cnt.umbra?'solarix':'umbra';WAR.own=w;WAR.sc[w]+=2;}}
      else{WAR.sc.solarix+=rr(0,2.4);WAR.sc.umbra+=rr(0,2.4);}}
    if(WAR.t<=0)endWar();}}
function startWar(){WAR.st='active';WAR.t=180;WAR.sc={solarix:0,umbra:0};WAR.own=null;WAR.part=false;WAR.tick=1;
  for(const fac of ['solarix','umbra']){const pool=bots.filter(b=>b.fac===fac&&!b.party&&!b.wb).sort((a,b)=>b.lvl-a.lvl).slice(0,8);for(const b of pool){b.war=true;b.map='c_front';if(curId()==='c_front')placeBot(b);}}
  toast('Guerre de la Frontière !','Prends le fort pour ta faction. Bouton Rejoindre en haut.');chat(null,'La guerre de la Frontière a commencé ! Tenez le fort central.');}
function endWar(){const s=WAR.sc,w=Math.round(s.solarix)===Math.round(s.umbra)?null:(s.solarix>s.umbra?'solarix':'umbra');WAR.st='idle';WAR.t=480;WAR.ann=false;
  for(const b of bots)if(b.war){b.war=false;b.map=b.home;if(curId()==='c_front'&&b.map!=='c_front')b.placed=false;}
  if(!w){toast('Guerre terminée : égalité');}
  else if(w===P.fac){addBuff({id:'war',n:'Victoire de faction',xp:.5,t:900});toast('Victoire de '+FACTIONS[w].n+' !','+50 % d’XP pour toute la faction pendant 15 min');}
  else{addBuff({id:'war',n:'Honneur du vaincu',xp:.1,t:300});toast('Victoire de '+FACTIONS[w].n,'Ta faction obtient +10 % d’XP pendant 5 min');}
  chat(null,w?`${FACTIONS[w].n} remporte la guerre de la Frontière (${Math.round(s.solarix)} à ${Math.round(s.umbra)}).`:'La guerre de la Frontière se termine sur une égalité.');
  if(WAR.part){const h=40+(w===P.fac?80:0);P.honor+=h;chat(null,'Participation : +'+h+' honneur.');qEvent('war');}}
function joinWar(){if(WAR.st!=='active')return;if(P.lvl<21){toast('Niveau 21 requis pour les zones contestées');return;}if(dgRun)dgRun=null;transition('c_front',{x:(P.fac==='solarix'?8:64)*TS,y:27*TS});}

/* ---------- boss de monde : affrontements de guildes ---------- */
function updWb(dt){for(const k in WB){const w=WB[k];
  if(!w.alive){w.t-=dt;if(w.t<=0){w.alive=true;w.sim=150;const map=MAPS[w.map];chat(null,`${MT[k].n} est apparu : ${map.n} !`);toast(MT[k].n+' est apparu',map.n+' · niv. '+w.lv);
      const pool=bots.filter(b=>b.guild&&!b.party&&!b.war&&b.lvl>=28);for(const b of pool){b.wb=k;b.map=w.map;if(curId()===w.map)placeBot(b);}
      if(curId()===w.map&&M.wbPos)w.mon=spawnMon({type:k,lv:w.lv,x:M.wbPos.x,y:M.wbPos.y});}}
}}
function wbReset(k){const w=WB[k];w.alive=false;w.t=w.respawn;w.mon=null;for(const b of bots)if(b.wb===k){b.wb=false;b.map=b.home;}}
function onWbKill(m){const k=m.type;chat(null,`${MT[k].n} est tombé${m.tag?' sous les coups de '+P.name+(P.guild?' («'+P.guild.name+'»)':''):''} !`);if(m.tag)toast(MT[k].n+' vaincu','Butin unique au sol');wbReset(k);}

/* ---------- boucle ---------- */
function update(dt){
  tGame+=dt;tDay+=dt;const c=CLASSES[P.cls],s=stats();
  for(let i=0;i<P.sk.length;i++)P.sk[i]=Math.max(0,P.sk[i]-dt);if(P.shield>0&&!P.buffs.some(b=>b.id==='shield'))P.shield=0;updTraps(dt);
  P.atkT-=dt;P.potT-=dt;P.guard-=dt;P.inv0-=dt;P.lastHit+=dt;P.lunge-=dt;
  if(P.pkT>0)P.pkT=Math.max(0,P.pkT-dt);
  for(const b of P.buffs)b.t-=dt;P.buffs=P.buffs.filter(b=>b.t>0);
  if(P.lastHit>5)P.hp=Math.min(s.maxhp,P.hp+s.maxhp*.022*s.regen*dt);
  P.mp=Math.min(s.maxmp,P.mp+s.maxmp*s.mreg*s.regen*dt);P.hp=Math.min(P.hp,s.maxhp);
  // déplacement
  let ix=0,iy=0;if(keys.has('arrowleft')||keys.has('q')||keys.has('a'))ix-=1;if(keys.has('arrowright')||keys.has('d'))ix+=1;if(keys.has('arrowup')||keys.has('z')||keys.has('w'))iy-=1;if(keys.has('arrowdown')||keys.has('s'))iy+=1;
  if(joyV.x||joyV.y){ix=joyV.x;iy=joyV.y;}
  const onRoad=gtAt(P.x,P.y-3)===GT.ROAD,heavy=invWeight()>s.pods,spd=66*(onRoad?1.2:1)*encMv()*(P.slowT>0?.6:1)*(s.mv||1);let mvx=0,mvy=0;
  if(ix||iy){const l=Math.max(1,Math.hypot(ix,iy));mvx=ix/l;mvy=iy/l;P.moveTo=null;P.chase=false;P.goTo=null;P.harv=null;if(P.atkOn){P.atkOn=false;}}
  else if(P.chase&&canTarget(P.target)){const t=P.target,d=dist(P,t),rg=c.range+(s.rngB||0)+(t.kind==='m'?t.hr*.5:0);if(d>rg-4){mvx=(t.x-P.x)/d;mvy=(t.y-P.y)/d;}}
  else if(P.moveTo){const dx=P.moveTo.x-P.x,dy=P.moveTo.y-P.y,d=Math.hypot(dx,dy);if(d<3){P.moveTo=null;if(P.goTo){const g=P.goTo;P.goTo=null;if(g.k==='node')startHarvest(g.o);else actionBtn();}}else{mvx=dx/d;mvy=dy/d;}}
  P.mv=false;
  if(mvx||mvy){const ox=P.x,oy=P.y;if(P.moveTo)steer(P,mvx*spd*dt,mvy*spd*dt,false);else moveEnt(P,mvx*spd*dt,mvy*spd*dt,false);P.mv=Math.hypot(P.x-ox,P.y-oy)>.01;if(!P.mv&&P.moveTo){P.moveTo=null;P.goTo=null;}P.fx=mvx;P.fy=mvy;P.dir=dirOf(mvx,mvy);P.flip=mvx<0;P.anim+=dt*9;P.harv=null;}
  if(P.target&&(P.target.dead||(P.target.kind==='b'&&P.target.map!==curId())))P.target=null;
  if(P.target&&dist(P,P.target)>360){P.target=null;P.chase=false;}
  if(!canTarget(P.target))P.atkOn=false;
  if(P.atkOn&&canTarget(P.target)&&P.atkT<=0&&dist(P,P.target)<=c.range+(s.rngB||0)+(P.target.kind==='m'?P.target.hr*.6:4)+4)basicAttack();
  // récolte
  if(P.harv){const n=P.harv.n;if(!n.alive)P.harv=null;else{P.harv.t+=dt;if(rnd()<dt*6)burst(n.x,n.y-10,'#e8e0c0',1);if(P.harv.t>=1.6){finishHarvest(n);P.harv=null;}}}
  for(const n of M.nodes)if(!n.alive){n.rt-=dt;if(n.rt<=0)n.alive=true;}
  // butin
  for(let i=bags.length-1;i>=0;i--){const b=bags[i];b.t-=dt;if(b.t<=0){bags.splice(i,1);continue;}}
  // gardes contre les noms rouges
  if(M.kind==='city'&&P.pkT>0&&M.def.side===P.fac){P.guardT-=dt;for(const g of M.guards)if(Math.hypot(g.x-P.x,g.y-P.y)<120&&P.guardT<=0){P.guardT=1.3;addFx({k:'slash',x:P.x,y:P.y-12,a:0,life:.2,col:'#ff4a4a'});hurtPlayer(s.maxhp*.3+s.def*.4,'les gardes de la cité');if(rnd()<.3)chat(null,'Garde : « Hors-la-loi ! Rends-toi ! »');break;}}
  // citoyens
  for(const ct of M.citizens){ct.wt-=dt;if(ct.wt<=0){ct.wt=rr(2,6);const p=ct.hx!=null?nearFree(ct.hx+rr(-70,70),ct.hy+rr(-60,60)):nearFree(M.spawnPt.x+rr(-150,150),M.spawnPt.y+rr(-170,40));ct.tx=p.x;ct.ty=p.y;}const dx=ct.tx-ct.x,dy=ct.ty-ct.y,d=Math.hypot(dx,dy);ct.moving=d>4;if(ct.moving){steer(ct,dx/d*30*dt,dy/d*30*dt,false);ct.anim+=dt*7;ct.dir=dirOf(dx,dy);}}
  checkExits();
  updMons(dt);updProjs(dt);updBots(dt);updPet(dt);updWar(dt);updWb(dt);
  for(let i=fxs.length-1;i>=0;i--){fxs[i].t+=dt;if(fxs[i].t>=fxs[i].life)fxs.splice(i,1);}
  for(let i=texts.length-1;i>=0;i--){texts[i].t+=dt;if(texts[i].t>1.1)texts.splice(i,1);}
  for(let i=parts.length-1;i>=0;i--){const p=parts[i];p.t+=dt;p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=(p.g||0)*dt;if(p.t>=p.life)parts.splice(i,1);}
  ambient(dt);
  marketT-=dt;if(P.qs)P.qs.bT-=dt;hdvT-=dt;if(hdvT<=0){hdvT=15;hdvTick();}guildT-=dt;if(guildT<=0){guildT=30;guildTick();}
  saveT-=dt;if(saveT<=0){saveT=8;save();}
}
function ambient(dt){if(!SET.parts||parts.length>160)return;const vw=VW/Z,vh=VH/Z,b=M.def&&M.def.biome,night=nightK();
  const spawn=(col,vy,glow,life)=>parts.push({x:camX+rnd()*vw,y:camY+rnd()*vh,vx:rr(-8,8),vy,t:0,life:life||rr(2,4),col,glow,g:0});
  if((b==='vale'||b==='moon'||b==='forest'||M.def&&M.def.side==='umbra')&&night>.3&&rnd()<dt*6)spawn(b==='moon'||M.def&&M.def.side==='umbra'?'#d8b0ff':'#e8ff8a',rr(-6,6),true);
  if((b==='ash'||b==='abyss')&&rnd()<dt*10)spawn('#ff7a3a',rr(-30,-12),true);
  if(M.kind==='dungeon'&&rnd()<dt*4)spawn('#a8a0b8',rr(-4,4),false);
  if(M.kind==='city'&&M.def.side==='solarix'&&night<.3&&rnd()<dt*2)spawn('#fff0b0',rr(-10,-4),true,2);}
function updProjs(dt){
  for(let i=projs.length-1;i>=0;i--){const p=projs[i];p.x+=p.vx*dt;p.y+=p.vy*dt;p.life-=dt;let dead=p.life<=0||solidPx(p.x,p.y+10);
    if(!dead&&p.from==='m'){if(Math.hypot(p.x-P.x,p.y-(P.y-12))<7+p.r){EC.magic=p.col!=='#e8e4d4';hurtPlayer(p.dmg,p.src);EC.magic=false;dead=true;}}
    else if(!dead&&p.from==='p'){for(const e of enemiesNear(p.x,p.y+10,10)){if(p.hit.has(e))continue;const hy=e.kind==='m'?e.hh:12,hr=e.kind==='m'?e.hr:8;if(Math.hypot(p.x-e.x,p.y-(e.y-hy))>hr+p.r+2)continue;
        if(p.explode){for(const o of enemiesNear(p.x,p.y+8,p.explode))hitTarget(o,p.mult,'#ffb36a');addFx({k:'ring',x:p.x,y:p.y,r0:4,r1:p.explode,life:.3,col:'#ff8a3a'});burst(p.x,p.y,'#ff9a3a',14);dead=true;break;}
        hitTarget(e,p.mult,null,p);if(p.slow){e.slow=p.slow;}if(p.root){e.root=p.root;}p.hit.add(e);if(!p.pierce){dead=true;break;}}}
    if(dead)projs.splice(i,1);}}
