'use strict';
/* ===================== Sprites : personnages, monstres, décors ===================== */
function cnv(w,h){const c=document.createElement('canvas');c.width=w;c.height=h;return c;}
function outline(src,col){const w=src.width,h=src.height,c=cnv(w+2,h+2),g=c.getContext('2d');
  const sd=src.getContext('2d').getImageData(0,0,w,h).data,od=g.createImageData(w+2,h+2),o=od.data;
  const oc=col||[20,15,28];const A=(x,y)=>x>=0&&y>=0&&x<w&&y<h&&sd[(y*w+x)*4+3]>40;
  for(let y=0;y<h+2;y++)for(let x=0;x<w+2;x++){const sx=x-1,sy=y-1,i=(y*(w+2)+x)*4;
    if(A(sx,sy)){const j=(sy*w+sx)*4;o[i]=sd[j];o[i+1]=sd[j+1];o[i+2]=sd[j+2];o[i+3]=sd[j+3];}
    else if(A(sx-1,sy)||A(sx+1,sy)||A(sx,sy-1)||A(sx,sy+1)){o[i]=oc[0];o[i+1]=oc[1];o[i+2]=oc[2];o[i+3]=255;}}
  g.putImageData(od,0,0);return c;}
function flipC(c){const f=cnv(c.width,c.height),g=f.getContext('2d');g.translate(c.width,0);g.scale(-1,1);g.drawImage(c,0,0);return f;}
function scaleC(c,s){if(s===1)return c;const o=cnv(c.width*s,c.height*s),g=o.getContext('2d');g.imageSmoothingEnabled=false;g.drawImage(c,0,0,o.width,o.height);return o;}
function shade(hex,f){const n=parseInt(hex.slice(1,7),16);let r=n>>16,g=n>>8&255,b=n&255;
  if(f>1){const k=f-1;r+=(255-r)*k;g+=(255-g)*k;b+=(255-b)*k;}else{r*=f;g*=f;b*=f;}
  return'#'+[r,g,b].map(v=>Math.round(clamp(v,0,255)).toString(16).padStart(2,'0')).join('');}
function rowsC(rows,pal){const h=rows.length,w=rows[0].length,c=cnv(w,h),g=c.getContext('2d');for(let y=0;y<h;y++)for(let x=0;x<w;x++){const ch=rows[y][x];if(ch==='.')continue;g.fillStyle=pal[ch]||'#f0f';g.fillRect(x,y,1,1);}return c;}
function fin(c,sc=1){const o=scaleC(outline(c),sc);return{c:o,f:flipC(o),w:o.width,h:o.height};}
function disc(g,cx,cy,r,col){g.fillStyle=col;for(let y=-r;y<=r;y++){const w=Math.floor(Math.sqrt(r*r+r*.8-y*y));if(w>=0)g.fillRect(Math.round(cx-w),Math.round(cy+y),w*2+1,1);}}

/* ---------- humanoïdes (4 directions, 4 images de marche) ---------- */
function drawHum(g,L,dir,fr){
  const Y0=2;const P=(x,y,w,h,c)=>{g.fillStyle=c;g.fillRect(x,y+Y0,w,h);};
  const skin=L.skin||'#e7b98c',eye=L.eye||'#1a1020',hair=L.hair||'#5a3a22',body=L.body||'#7a6a5a',b2=L.body2||shade(body,.72),legs=L.legs||'#4a4a52',boots=L.boots||'#2a2020',belt=L.belt||'#5a3a1a';
  const step=fr===1?1:fr===3?-1:0,oy=step?-1:0,metal='#a8b0bc',metal2='#7e8694',hood=L.hood||'#4a3a2a',hat=L.hat||'#3a2a5a';
  const hs=L.hairStyle||'short';
  const weapon=(side)=>{const w=L.weapon,ay=oy;if(!w||w==='none')return;
    if(side==='d'){const x=15;
      if(w==='sword'){P(x,7+ay,1,10,'#e2e6ee');P(x+1,8+ay,1,9,'#a8b0bc');P(x-1,17+ay,3,1,'#8a6a2a');P(x,18+ay,1,2,'#5a3a1a');}
      else if(w==='bow'){P(x,9+ay,1,12,'#8a5a2a');P(x+1,8+ay,1,1,'#8a5a2a');P(x+1,21+ay,1,1,'#8a5a2a');P(x-1,9+ay,1,12,'#e8e0d0');}
      else if(w==='staff'){P(x,4+ay,1,18,'#8a5a2a');P(x-1,1+ay,3,3,L.orb||'#c58cff');P(x-1,1+ay,1,1,'#ffffff');}
      else if(w==='halberd'){P(x,1+ay,1,23,'#7a5a3a');P(x+1,2+ay,2,5,'#c8ccd4');P(x-1,3+ay,1,3,'#c8ccd4');}
      else if(w==='dagger'){P(x,14+ay,1,5,'#e2e6ee');P(x-1,18+ay,3,1,'#6a4a2a');}
      else if(w==='crossbow'){P(x-3,16+ay,5,1,'#7a5a3a');P(x+1,13+ay,1,7,'#5a3a2a');}
      else if(w==='pick'){P(x,9+ay,1,11,'#7a5a3a');P(x-2,8+ay,5,1,'#a8a8b0');P(x-2,9+ay,1,1,'#a8a8b0');}
      else if(w==='hammer'){P(x,9+ay,1,12,'#7a5a3a');P(x-2,7+ay,5,3,'#8a8a96');}}
    else if(side==='r'){const x=13;
      if(w==='sword'){P(x,7+ay,1,10,'#e2e6ee');P(x-1,17+ay,3,1,'#8a6a2a');P(x,18+ay,1,2,'#5a3a1a');}
      else if(w==='bow'){P(x+1,9+ay,1,12,'#8a5a2a');P(x,9+ay,1,1,'#8a5a2a');P(x,20+ay,1,1,'#8a5a2a');P(x,10+ay,1,10,'#e8e0d0');}
      else if(w==='staff'){P(x,4+ay,1,18,'#8a5a2a');P(x-1,1+ay,3,3,L.orb||'#c58cff');}
      else if(w==='halberd'){P(x,1+ay,1,23,'#7a5a3a');P(x+1,2+ay,2,5,'#c8ccd4');}
      else if(w==='dagger'){P(x,14+ay,1,5,'#e2e6ee');}
      else if(w==='crossbow'){P(x-2,16+ay,5,1,'#7a5a3a');P(x+2,13+ay,1,7,'#5a3a2a');}
      else if(w==='pick'){P(x,9+ay,1,11,'#7a5a3a');P(x-2,8+ay,5,1,'#a8a8b0');}
      else if(w==='hammer'){P(x,9+ay,1,12,'#7a5a3a');P(x-2,7+ay,5,3,'#8a8a96');}}
    else if(side==='u'&&['sword','bow','staff','halberd','pick','hammer'].includes(w)){const col=w==='sword'?'#c8ccd4':'#7a5a3a';for(let i=0;i<15;i++)P(4+Math.round(i*9/14),21+ay-i,1,1,col);if(w==='staff')P(12,5+ay,3,3,L.orb||'#c58cff');}
  };
  const headTop=(side)=>{const e=L.extra;
    if(e==='helm'){if(side==='r'){P(6,4+oy,7,4,metal);P(6,4+oy,7,1,'#d0d6de');P(6,8+oy,2,3,metal2);P(12,8+oy,1,1,metal2);}else{P(5,4+oy,8,4,metal);P(5,4+oy,8,1,'#d0d6de');P(5,8+oy,1,2,metal2);P(12,8+oy,1,2,metal2);if(side==='d')P(8,8+oy,2,2,metal2);else P(6,8+oy,6,3,metal2);}if(L.plume)P(side==='r'?7:8,2+oy,2,2,L.plume);}
    else if(e==='hood'){if(side==='r'){P(5,4+oy,7,9,hood);P(9,7+oy,3,6,skin);}else{P(5,4+oy,8,9,hood);if(side==='d')P(7,7+oy,4,6,skin);}}
    else if(e==='hat'){P(3,5+oy,12,1,hat);const rws=side==='r'?[[5,7],[5,6],[5,5],[4,5],[3,4]]:[[5,8],[6,6],[6,6],[7,4],[8,3]];rws.forEach(([x,w],i)=>P(x,4-i+oy,w,1,hat));P(5,4+oy,8,1,L.belt||'#f2c14e');}
    else if(e==='crown'){P(6,5+oy,6,2,'#f2c14e');P(6,4+oy,1,1,'#f2c14e');P(8,3+oy,2,2,'#f2c14e');P(11,4+oy,1,1,'#f2c14e');P(8,5+oy,2,1,'#e04a8a');}
    else if(e==='horns'){P(4,3+oy,1,3,'#e8d8b0');P(5,5+oy,1,2,'#e8d8b0');P(13,3+oy,1,3,'#e8d8b0');P(12,5+oy,1,2,'#e8d8b0');}
    else if(e==='bandana'){P(5,6+oy,8,2,'#a82a2a');if(side==='d')P(6,10+oy,6,3,'#2a2a2a');if(side==='r')P(9,10+oy,4,3,'#2a2a2a');}
    else if(e==='ears'){if(side==='r')P(6,8+oy,1,2,skin);else{P(3,8+oy,3,1,skin);P(12,8+oy,3,1,skin);}}
    else if(e==='wrap'){for(let y=6;y<13;y+=2)P(side==='r'?6:6,y+oy,6,1,shade(skin,.82));}
  };
  // jambes
  if(dir==='r'){
    if(L.robe){P(6,19,6,5,b2);P(6,23,6,1,shade(b2,.75));P(7,24,5,1,boots);}
    else if(!step){P(8,19,3,4,legs);P(8,23,4,2,boots);}
    else{P(6,19,2,4,shade(legs,.78));P(5,23,3,2,shade(boots,.8));P(10,19,2,4,legs);P(10,23,3,2,boots);}
  }else{
    const lL=step===1?-1:0,rL=step===-1?-1:0;
    if(L.robe){P(5,19,8,5,b2);P(5,23,8,1,shade(b2,.75));P(6,24,2,1,boots);P(10,24,2,1,boots);}
    else{P(6,19+lL,2,4,legs);P(10,19+rL,2,4,legs);P(7,19+lL,1,4,shade(legs,.8));P(11,19+rL,1,4,shade(legs,.8));P(6,23+lL,2,2,boots);P(10,23+rL,2,2,boots);}
  }
  if(dir==='r'&&L.cape)P(4,13+oy,3,9,L.cape);
  // torse
  if(dir==='r'){P(6,13+oy,6,6,body);P(6,13+oy,1,6,b2);P(7,13+oy,3,1,shade(body,1.25));P(6,18+oy,6,1,belt);}
  else{P(5,13+oy,8,6,body);P(12,13+oy,1,6,b2);P(6,13+oy,2,1,shade(body,1.25));P(5,18+oy,8,1,belt);if(dir==='d')P(8,18+oy,2,1,'#e8c860');
    if(dir==='d'&&L.cape)P(6,13+oy,6,1,L.cape);}
  if(dir==='u'&&L.cape){P(5,13+oy,8,8,L.cape);P(8,13+oy,1,8,shade(L.cape,.78));}
  // bras
  if(dir==='r'){P(9+step,13+oy,2,4,shade(body,.9));P(9+step,17+oy,2,1,skin);}
  else{const aL=step,aR=-step;P(3,13+oy+aL,2,4,shade(body,.9));P(3,17+oy+aL,2,1,skin);P(13,13+oy+aR,2,4,b2);P(13,17+oy+aR,2,1,skin);}
  if(dir==='d'&&L.shield){P(1,14+oy,3,6,L.shield);P(1,14+oy,3,1,shade(L.shield,1.3));P(2,16+oy,1,2,'#e8c860');}
  // tête
  const ex=L.extra;
  if(dir==='u'){P(6,6+oy,6,7,hs==='bald'?skin:hair);if(hs==='long')P(6,12+oy,6,2,hair);if(ex!=='hood'&&ex!=='helm'&&ex!=='hat'){if(hs==='spiky'){P(6,4+oy,1,2,hair);P(8,3+oy,2,3,hair);P(11,4+oy,1,2,hair);}if(hs==='bun')P(7,3+oy,4,3,hair);if(hs==='pony')P(8,12+oy,2,4,hair);}headTop('u');weapon('u');return;}
  P(6,6+oy,6,7,skin);P(dir==='r'?6:11,6+oy,1,7,shade(skin,.85));
  if(ex!=='hood'&&ex!=='helm'&&hs!=='bald'){
    if(dir==='r'){P(6,5+oy,6,2,hair);P(6,7+oy,2,4,hair);if(hs==='long')P(5,8+oy,2,6,hair);if(hs==='pony')P(4,8+oy,2,4,hair);if(hs==='spiky'&&ex!=='hat'){P(6,3+oy,1,2,hair);P(8,2+oy,2,3,hair);P(11,3+oy,1,2,hair);}if(hs==='bun'&&ex!=='hat')P(5,3+oy,4,3,hair);}
    else{P(6,5+oy,6,2,hair);P(5,6+oy,1,3,hair);P(12,6+oy,1,3,hair);P(7,7+oy,2,1,hair);if(hs==='long'){P(5,9+oy,1,5,hair);P(12,9+oy,1,5,hair);}if(hs==='pony'){P(12,8+oy,2,4,hair);}if(hs==='spiky'&&ex!=='hat'){P(6,3+oy,1,2,hair);P(8,2+oy,2,3,hair);P(11,3+oy,1,2,hair);P(10,7+oy,1,1,hair);}if(hs==='bun'&&ex!=='hat'){P(7,2+oy,4,3,hair);P(8,2+oy,2,1,shade(hair,1.3));}}
  }
  headTop(dir);
  if(L.fem&&ex!=='helm'){if(dir==='d'){P(6,10+oy,1,1,'#f0a0a0');P(11,10+oy,1,1,'#f0a0a0');P(7,8+oy,1,1,shade(hair,.6));P(10,8+oy,1,1,shade(hair,.6));}else P(10,10+oy,1,1,'#f0a0a0');}
  if(dir==='d'){if(ex==='skull'||ex==='wrap'){P(7,9+oy,2,2,'#1a1a1a');P(10,9+oy,2,2,'#1a1a1a');P(7,9+oy,1,1,eye);P(10,9+oy,1,1,eye);}else{P(7,9+oy,1,1,eye);P(10,9+oy,1,1,eye);}}
  else{if(ex==='skull')P(10,9+oy,2,2,'#1a1a1a');P(10,9+oy,1,1,eye);P(12,10+oy,1,1,shade(skin,.8));}
  weapon(dir==='r'?'r':'d');
}
const _humCache=new Map();
function humSprite(L,sc=1){const key=JSON.stringify(L)+'|'+sc;let s=_humCache.get(key);if(s)return s;s={};
  for(const d of ['d','u','r']){s[d]=[];for(let f=0;f<4;f++){const c=cnv(18,28);drawHum(c.getContext('2d'),L,d,f);s[d].push(scaleC(outline(c),sc));}}
  s.l=s.r.map(flipC);s.w=s.d[0].width;s.h=s.d[0].height;_humCache.set(key,s);return s;}

/* ---------- monstres ---------- */
const SLIME_A=["...GGGG...","..GWGGGG..",".GWGGGGGG.",".GGKGGKGG.","GGGKGGKGGG","GGGGGGGGGG",".GGGGGGGG.","..DDDDDD.."];
const SLIME_B=["...GGGGGG...","..GWGGGGGG..",".GWGGKGGKGG.","GGGGGKGGKGGG","GGGGGGGGGGGG",".GGGGGGGGGG.","..DDDDDDDD.."];
const QUAD_A=["........F.F.","T.......FFFF",".T.....FFKFF",".FFFFFFFFFFN",".FFFFFFFFFF.","..FFFFFFFF..","..F.F..F.F..","..D.D..D.D.."];
const QUAD_B=["........F.F.","T.......FFFF",".T.....FFKFF",".FFFFFFFFFFN",".FFFFFFFFFF.","..FFFFFFFF..","...F.F..F.F.","...D.D..D.D."];
const MUSH_A=["..RRRRRR..",".RRWRRWRR.","RRRRRRRRRR","RWRRRRRWRR","RRRRRRRRRR","..SSSSSS..","..SKSSKS..","..SSSSSS..","...S..S...","..SS..SS.."];
const MUSH_B=["..RRRRRR..",".RRWRRWRR.","RRRRRRRRRR","RWRRRRRWRR","RRRRRRRRRR","..SSSSSS..","..SKSSKS..","..SSSSSS..","..S....S..",".SS....SS."];
const GOLEM_A=["...GGGGGG...","..GLLLLLLG..","..GLYLLYLG..","..GGGGGGGG..","GGGGOGGOGGGG","GLLGGGGGGLLG","GLLGGOOGGLLG","GGGGGGGGGGGG",".DD.GGGG.DD.","....GGGG....","...GG..GG...","...DD..DD..."];
const GOLEM_B=["...GGGGGG...","..GLLLLLLG..","..GLYLLYLG..","..GGGGGGGG..","GGGGOGGOGGGG","GLLGGGGGGLLG","GLLGGOOGGLLG","GGGGGGGGGGGG",".DD.GGGG.DD.","....GGGG....","..GG....GG..","..DD....DD.."];
const SPID_A=["..L..BB..L..",".L.LBBBBL.L.","L..BBEBEBB.L","..LBBBBBBL..",".L.LBBBBL.L.","L...L..L...L"];
const SPID_B=[".L...BB...L.","L..LBBBBL..L","...BBEBEBB..",".L.BBBBBBL.L","L..LBBBBL...",".L..L..L..L."];
const SCORP_A=["...........TT.","..........T..T","..........T...","PP..BBBBBBT...","PPBBBBBBBBB...",".PBBEBBBBBB...","..L.L.L.L.L...",".L.L.L.L.L...."];
const SCORP_B=["...........TT.","..........T..T","..........T...","PP..BBBBBBT...","PPBBBBBBBBB...",".PBBEBBBBBB...",".L.L.L.L.L....","..L.L.L.L.L..."];
const BAT_A=["W..........W","WW..BBBB..WW",".WWWBEEBWWW.","..WWBBBBWW..","....B..B...."];
const BAT_B=["....BBBB....","...WBEEBW...","..WWBBBBWW..",".WWW.BB.WWW.","WW........WW"];
const SERP_A=["........HHH.",".......HHEHH","........HHHT","..BBB...BB..",".BB.BB.BB...","BB...BBB....",".B.........."];
const SERP_B=["........HHH.",".......HHEHH","........HHH.","...BB...BB..","..B.BB.BB...",".BB...BB....","BB.........."];
const GHOST_A=["...GGGG...","..GGGGGG..",".GGKGGKGG.",".GGKGGKGG.",".GGGGGGGG.",".GGGOOGGG.",".GGGGGGGG.","GGGGGGGGGG","GGGGGGGGGG","G.GG.GG.GG","..G..G..G."];
const GHOST_B=["...GGGG...","..GGGGGG..",".GGKGGKGG.",".GGKGGKGG.",".GGGGGGGG.",".GGGOOGGG.",".GGGGGGGG.","GGGGGGGGGG","GGGGGGGGGG",".GG.GG.GG.",".G..G..G.."];
const TOAD=["..EE......EE..",".EKEE....EKEE.",".GGGGGGGGGGGG.","GGGGGGGGGGGGGG","GGGGGGGGGGGGGG","GGGGMMMMMMGGGG","GGWWWWWWWWWWGG",".GWWWWWWWWWWG.","LL..........LL"];
const TOAD_B=[".EE........EE.","EKEE......EKEE",".GGGGGGGGGGGG.","GGGGGGGGGGGGGG","GGGGGGGGGGGGGG","GGGGMMMMMMGGGG","GGWWWWWWWWWWGG",".GWWWWWWWWWWG.",".LL........LL."];
function rowSet(A,B,pal,sc,faceL){const a=fin(rowsC(A,pal),sc),b=fin(rowsC(B||A,pal),sc);return{fr:[a,b],w:a.w,h:a.h,faceL:!!faceL};}
function humMon(L,sc=1){const h=humSprite(L,sc);return{hum:h,w:h.w,h:h.h,sc};}
let MSPR={};
function buildMonsterSprites(){
  MSPR={
    slime:rowSet(SLIME_A,SLIME_B,{G:'#5fd16a',W:'#c8f8c0',K:'#173a1c',D:'#2f8a3a'},2),
    slimeb:rowSet(SLIME_A,SLIME_B,{G:'#5fb8e0',W:'#d0f0ff',K:'#10304a',D:'#2f7aa8'},2),
    loup:rowSet(QUAD_A,QUAD_B,{F:'#8a8a96',T:'#b8b8c4',K:'#f5e663',N:'#1a1a1a',D:'#4a4a52'},2),
    renard:rowSet(QUAD_A,QUAD_B,{F:'#d8782a',T:'#f8f0e0',K:'#1a1a1a',N:'#1a1a1a',D:'#5a2a10'},2),
    sanglier:rowSet(QUAD_A,QUAD_B,{F:'#6a4a32',T:'#4a3220',K:'#ff4a3a',N:'#f0e8d0',D:'#2a1a10'},2),
    ours:rowSet(QUAD_A,QUAD_B,{F:'#6b4428',T:'#8a5a34',K:'#ff4a3a',N:'#1a1010',D:'#3a2414'},4),
    champi:rowSet(MUSH_A,MUSH_B,{R:'#d8443a',W:'#f5efe0',S:'#efe2c4',K:'#2a1a10'},2),
    araignee:rowSet(SPID_A,SPID_B,{B:'#3a2a4a',E:'#ff4a4a',L:'#5a4a6a'},2),
    crapaud:rowSet(TOAD,TOAD_B,{E:'#7a8a3a',K:'#f5e663',G:'#6a7a32',W:'#a8b85a',M:'#2a3a1a',L:'#4a5a22'},2),
    scorpion:rowSet(SCORP_A,SCORP_B,{B:'#c89a4a',T:'#a87a3a',P:'#e0b060',E:'#1a1a1a',L:'#8a6a3a'},2,true),
    golem:rowSet(GOLEM_A,GOLEM_B,{G:'#5e5866',L:'#7a7484',Y:'#ff8a2a',D:'#3a3540',O:'#ff6a2a'},3),
    chauve:rowSet(BAT_A,BAT_B,{W:'#5a4a6a',B:'#2a2030',E:'#ff5a5a'},2),
    serpent:rowSet(SERP_A,SERP_B,{H:'#5aa86a',B:'#4a8a5a',E:'#ffe14a',T:'#e04a4a'},2),
    hydre:rowSet(SERP_A,SERP_B,{H:'#3a8a9a',B:'#2a6a7a',E:'#ff4a8a',T:'#e04a4a'},5),
    spectre:rowSet(GHOST_A,GHOST_B,{G:'#c8d8f0',K:'#1a1a3a',O:'#3a3a6a'},2),
    squelette:humMon({skin:'#e8e4d4',eye:'#ff4a4a',hairStyle:'bald',body:'#cfc9b4',body2:'#a8a290',legs:'#cfc9b4',boots:'#a8a290',belt:'#8a8470',extra:'skull',weapon:'bow'}),
    sqnoir:humMon({skin:'#6a6478',eye:'#ff3a3a',hairStyle:'bald',body:'#3a3446',body2:'#2a2434',legs:'#4a4456',boots:'#2a2434',belt:'#6a2a2a',extra:'skull',weapon:'sword',shield:'#4a3a5a'}),
    sorciere:humMon({skin:'#9cc48a',eye:'#f5e663',hair:'#2a1d3a',hairStyle:'long',body:'#3a2a52',body2:'#2a1d3a',belt:'#9be36a',robe:true,extra:'hat',hat:'#2a1d3a',weapon:'staff',orb:'#9be36a'}),
    demon:humMon({skin:'#c43a2a',eye:'#ffd84a',hairStyle:'bald',body:'#8a2a1e',legs:'#5a1a14',boots:'#2a1010',belt:'#2a1010',extra:'horns',weapon:'none'}),
    brigand:humMon({skin:'#d8a07a',hair:'#3a2a1a',body:'#6a4a2a',legs:'#3a3a3a',boots:'#2a1a10',extra:'bandana',weapon:'sword'}),
    renegat:humMon({skin:'#d8a07a',body:'#5a5a3a',legs:'#3a3a2a',extra:'hood',hood:'#4a4a2a',weapon:'crossbow'}),
    gobelin:humMon({skin:'#7ab84a',eye:'#ff4a2a',hairStyle:'bald',body:'#6a4a2a',legs:'#4a3a2a',extra:'ears',weapon:'dagger'}),
    farfadet:humMon({skin:'#e7b98c',hair:'#f2c14e',body:'#4a8a3a',legs:'#3a5a2a',extra:'hat',hat:'#3a7a2a',belt:'#f2c14e',weapon:'bow'}),
    kobold:humMon({skin:'#a87a4a',eye:'#ffd84a',hairStyle:'bald',body:'#5a4a3a',legs:'#3a3028',extra:'ears',weapon:'pick'}),
    krog:humMon({skin:'#a87a4a',eye:'#ffd84a',body:'#5a4a3a',legs:'#3a3028',extra:'helm',weapon:'hammer'},2),
    noye:humMon({skin:'#6a9aa8',eye:'#d8f8ff',hair:'#2a4a4a',hairStyle:'long',body:'#3a5a6a',legs:'#2a4a5a',boots:'#1a3a4a',weapon:'none'}),
    momie:humMon({skin:'#d8cfb0',eye:'#ff4a2a',hairStyle:'bald',body:'#d8cfb0',body2:'#b8ae90',legs:'#d8cfb0',boots:'#b8ae90',belt:'#b8ae90',extra:'wrap',weapon:'none'}),
    titan:rowSet(GOLEM_A,GOLEM_B,{G:'#4a3a3a',L:'#6a5050',Y:'#ff3a1a',D:'#2a1e1e',O:'#ff8a2a'},6),
    wyrm:rowSet(SERP_A,SERP_B,{H:'#3a1a5a',B:'#2a1446',E:'#ff3ad8',T:'#ff4a4a'},7),
    reinescorp:rowSet(SCORP_A,SCORP_B,{B:'#a83a2a',T:'#8a2a1a',P:'#e05a3a',E:'#ffd84a',L:'#6a2a1a'},4,true),
    liche:humMon({skin:'#d8d4e8',eye:'#7ff3ff',hairStyle:'bald',body:'#4b3a78',body2:'#2c2148',robe:true,extra:'crown',weapon:'staff',orb:'#7ff3ff',cape:'#2c2148'},2),
  };
}

/* ---------- décors ---------- */
const PROPS={};
function mkProp(w,h,fn,noOut){const c=cnv(w,h),g=c.getContext('2d');fn(g);const o=noOut?c:outline(c);return{c:o,w:o.width,h:o.height};}
function treeCanopy(g,cx,cy,r,cols){disc(g,cx+1,cy+2,r,cols[0]);disc(g,cx-1,cy,r-1,cols[1]);disc(g,cx-r*.35,cy-r*.3,Math.round(r*.55),cols[2]);disc(g,cx+r*.35,cy-r*.15,Math.round(r*.5),cols[1]);disc(g,cx-r*.4,cy-r*.45,Math.round(r*.3),cols[3]);}
function trunk(g,x,y,h,c1,c2){g.fillStyle=c1;g.fillRect(x,y,4,h);g.fillStyle=c2;g.fillRect(x+3,y,1,h);g.fillRect(x-1,y+h-2,6,2);}
function buildProps(){
  const T=(k,w,h,fn)=>{PROPS[k]=mkProp(w,h,fn);};
  T('oak',34,42,g=>{trunk(g,15,24,17,'#6b4a2b','#4a3220');treeCanopy(g,17,15,12,['#25692f','#2f7d3a','#4aa04a','#8ad878']);});
  T('oak2',34,44,g=>{trunk(g,15,26,17,'#5a3a22','#3a2414');treeCanopy(g,17,15,13,['#174a22','#1f5a2c','#2f7a3a','#5aa860']);});
  T('moon',34,42,g=>{trunk(g,15,24,17,'#5a4a6a','#3a2e4a');treeCanopy(g,17,15,12,['#245a66','#2f6f7a','#4fa0aa','#b8f8ff']);g.fillStyle='#e8ffff';for(const [x,y] of [[10,12],[22,9],[17,20],[25,17],[12,6]])g.fillRect(x,y,1,1);});
  T('pine',26,46,g=>{trunk(g,11,36,9,'#5a3a22','#3a2414');const L=[['#1a4426',0],['#22542e',0],['#2c6838',0]];for(let i=0;i<4;i++){const y=4+i*8,w=6+i*4;g.fillStyle=L[0][0];g.fillRect(13-w,y+4,w*2,6);g.fillStyle=L[1][0];g.fillRect(13-w+1,y+3,w*2-3,5);g.fillStyle=L[2][0];g.fillRect(13-w+2,y+2,w-1,3);}g.fillStyle='#4a8a50';g.fillRect(12,2,2,3);});
  T('willow',38,44,g=>{trunk(g,17,26,17,'#4a3b2a','#2e2418');treeCanopy(g,19,16,13,['#3a5a2e','#4a6a3a','#5a8048','#7a9a5a']);g.fillStyle='#4a6a3a';for(let x=6;x<34;x+=3)g.fillRect(x,20,1,10+(x%7));});
  T('dead',26,36,g=>{g.fillStyle='#4a3b2a';g.fillRect(12,8,3,27);g.fillRect(6,14,6,2);g.fillRect(5,10,2,5);g.fillRect(15,18,6,2);g.fillRect(20,12,2,7);g.fillRect(9,5,2,5);g.fillStyle='#2e2418';g.fillRect(14,8,1,27);});
  T('deadash',26,38,g=>{g.fillStyle='#2a2228';g.fillRect(12,8,3,29);g.fillRect(5,13,7,2);g.fillRect(4,8,2,6);g.fillRect(15,17,7,2);g.fillRect(21,10,2,8);g.fillStyle='#ff6a2a';g.fillRect(4,8,1,1);g.fillRect(22,10,1,1);g.fillRect(13,10,1,1);});
  T('palm',30,44,g=>{g.fillStyle='#8a6a3a';for(let i=0;i<30;i++){g.fillRect(14+Math.round(Math.sin(i/9)*3),13+i,3,1);if(i%4===0){g.fillStyle='#6a4a2a';g.fillRect(14+Math.round(Math.sin(i/9)*3),13+i,3,1);g.fillStyle='#8a6a3a';}}g.fillStyle='#3a8a3a';for(const [dx,dy] of [[-1,0],[1,0],[-1,-.6],[1,-.6],[0,-1]])for(let i=0;i<12;i++)g.fillRect(16+dx*i,12+dy*i+(i*i)*.06,2,2);g.fillStyle='#6a4a2a';g.fillRect(14,12,4,3);});
  T('cactus',16,24,g=>{g.fillStyle='#3a8a4a';g.fillRect(6,2,5,21);g.fillRect(1,8,3,7);g.fillRect(1,13,5,2);g.fillRect(13,5,3,8);g.fillRect(10,11,5,2);g.fillStyle='#5aaa5a';g.fillRect(7,3,1,19);g.fillStyle='#f8e8a0';g.fillRect(8,1,1,1);});
  T('frene',30,40,g=>{g.fillStyle='#ece8dc';g.fillRect(13,20,4,19);g.fillStyle='#2a2a2a';for(const y of [23,28,33])g.fillRect(13+(y%3),y,2,1);treeCanopy(g,15,13,10,['#6aa840','#7ab84a','#a8d868','#e0f8b0']);});
  T('chene',38,46,g=>{trunk(g,17,28,17,'#5a3a22','#3a2414');treeCanopy(g,19,16,14,['#8a4a1e','#b8682a','#e0943a','#f8c860']);});
  T('if',26,46,g=>{trunk(g,11,36,9,'#4a2a1e','#2a1810');for(let i=0;i<4;i++){const y=4+i*8,w=5+i*4;g.fillStyle='#163a30';g.fillRect(13-w,y+4,w*2,6);g.fillStyle='#205040';g.fillRect(13-w+1,y+3,w*2-3,5);}g.fillStyle='#e03a3a';for(const [x,y] of [[8,14],[17,20],[6,30],[19,31],[12,24]])g.fillRect(x,y,2,2);});
  T('spectral',34,44,g=>{trunk(g,15,26,17,'#8aa8b8','#5a7888');treeCanopy(g,17,15,12,['#4a98a8','#6ab8c8','#a0e0f0','#ffffff']);g.fillStyle='#ffffff';for(const [x,y] of [[9,10],[24,14],[15,22]])g.fillRect(x,y,1,1);});
  T('stump',16,10,g=>{g.fillStyle='#6b4a2b';g.fillRect(2,3,12,6);g.fillStyle='#c8a070';g.fillRect(3,1,10,4);g.fillStyle='#8a6a40';g.fillRect(6,2,4,2);});
  T('rock',18,14,g=>{g.fillStyle='#5a5462';g.fillRect(2,4,14,9);g.fillRect(4,2,10,11);g.fillStyle='#7a7484';g.fillRect(4,3,7,3);g.fillRect(3,5,3,3);g.fillStyle='#3e3846';g.fillRect(3,12,12,1);});
  T('rockd',18,14,g=>{g.fillStyle='#a8844a';g.fillRect(2,4,14,9);g.fillRect(4,2,10,11);g.fillStyle='#c8a46a';g.fillRect(4,3,7,3);g.fillStyle='#7a5a2e';g.fillRect(3,12,12,1);});
  T('rocka',18,14,g=>{g.fillStyle='#2e2834';g.fillRect(2,4,14,9);g.fillRect(4,2,10,11);g.fillStyle='#4a4252';g.fillRect(4,3,7,3);g.fillStyle='#ff6a2a';g.fillRect(10,8,3,1);g.fillRect(12,9,1,2);});
  for(const [k,c,h] of [['fer','#c9b8a8','#f0e6d8'],['cristal','#4ad6e0','#c8faff'],['mithril','#b07cff','#f0d8ff'],['obsidienne','#3a2a4a','#9a7aca']])
    T('ore_'+k,20,18,g=>{g.fillStyle='#5e5866';g.fillRect(2,7,16,10);g.fillRect(4,5,12,12);g.fillStyle='#7a7484';g.fillRect(4,6,6,3);g.fillStyle=c;g.fillRect(6,2,3,7);g.fillRect(11,4,3,6);g.fillRect(9,9,2,4);g.fillStyle=h;g.fillRect(6,2,1,3);g.fillRect(11,4,1,2);});
  T('herb_ortie',12,12,g=>{g.fillStyle='#3a8a3a';for(const [x,y,h] of [[5,1,10],[2,4,7],[8,3,8]])g.fillRect(x,y,2,h);g.fillStyle='#5ab85a';g.fillRect(1,4,3,1);g.fillRect(8,3,3,1);g.fillRect(4,1,3,1);});
  T('herb_sauge',12,12,g=>{g.fillStyle='#7aa88a';disc(g,4,6,3,'#7aa88a');disc(g,8,5,3,'#9ac8a8');g.fillStyle='#5a7a5a';g.fillRect(5,8,2,4);});
  T('herb_trefle',12,12,g=>{disc(g,4,4,2,'#78c8f0');disc(g,8,4,2,'#9ad8ff');disc(g,6,7,2,'#b8e8ff');g.fillStyle='#4a8aa8';g.fillRect(6,8,1,4);});
  T('herb_mandragore',12,12,g=>{g.fillStyle='#5a3a6a';g.fillRect(2,2,3,5);g.fillRect(7,1,3,6);g.fillStyle='#8a4a9a';g.fillRect(4,3,4,3);disc(g,6,9,2,'#c84a8a');});
  T('bush',18,13,g=>{disc(g,6,7,5,'#2f7a3a');disc(g,12,7,5,'#2f7a3a');disc(g,9,5,5,'#3f9a48');disc(g,7,4,2,'#6ac06a');});
  T('bushb',18,13,g=>{disc(g,6,7,5,'#2f6a5a');disc(g,12,7,5,'#2f6a5a');disc(g,9,5,5,'#3f8a7a');g.fillStyle='#e0b0ff';for(const [x,y] of [[5,5],[12,4],[9,8],[14,8]])g.fillRect(x,y,1,1);});
  T('bushf',18,13,g=>{disc(g,6,7,5,'#2f7a3a');disc(g,12,7,5,'#2f7a3a');disc(g,9,5,5,'#3f9a48');g.fillStyle='#e04a5a';for(const [x,y] of [[5,5],[12,4],[9,8],[14,8],[8,3]])g.fillRect(x,y,2,2);});
  T('reed',12,18,g=>{g.fillStyle='#5a7a3a';for(const x of [2,5,8])g.fillRect(x,2+(x%3),1,15);g.fillStyle='#6a4a2a';g.fillRect(2,1,2,4);g.fillRect(8,3,2,4);});
  T('crate',14,14,g=>{g.fillStyle='#8a6440';g.fillRect(1,1,12,12);g.fillStyle='#6a4a2a';g.fillRect(1,1,12,1);g.fillRect(1,6,12,1);g.fillRect(1,12,12,1);g.fillRect(1,1,1,12);g.fillRect(12,1,1,12);});
  T('barrel',12,14,g=>{g.fillStyle='#8a5a30';g.fillRect(2,1,8,12);g.fillRect(1,3,10,8);g.fillStyle='#4a3a2a';g.fillRect(1,4,10,1);g.fillRect(1,9,10,1);g.fillStyle='#a87040';g.fillRect(3,2,2,10);});
  T('lamp',8,30,g=>{g.fillStyle='#3a3640';g.fillRect(3,8,2,22);g.fillRect(1,28,6,2);g.fillStyle='#2a2630';g.fillRect(1,2,6,7);g.fillStyle='#f8e090';g.fillRect(2,3,4,5);g.fillStyle='#fff8d0';g.fillRect(3,4,2,2);});
  T('anvil',16,12,g=>{g.fillStyle='#4a4a54';g.fillRect(1,2,14,4);g.fillRect(5,6,6,4);g.fillRect(3,10,10,2);g.fillStyle='#6a6a76';g.fillRect(2,2,12,1);});
  T('chest',16,13,g=>{g.fillStyle='#8a5a2a';g.fillRect(1,4,14,8);g.fillStyle='#a8743a';g.fillRect(1,1,14,4);g.fillStyle='#e8c860';g.fillRect(1,4,14,1);g.fillRect(7,4,2,3);g.fillStyle='#5a3a1a';g.fillRect(1,11,14,1);});
  T('chesto',16,13,g=>{g.fillStyle='#8a5a2a';g.fillRect(1,4,14,8);g.fillStyle='#3a2410';g.fillRect(2,5,12,3);g.fillStyle='#a8743a';g.fillRect(1,0,14,3);g.fillStyle='#e8c860';g.fillRect(1,3,14,1);});
  T('stairs',30,22,g=>{for(let i=0;i<5;i++){g.fillStyle=i%2?'#3a3446':'#4a4458';g.fillRect(2+i*2,2+i*4,26-i*4,4);}g.fillStyle='#120e18';g.fillRect(12,18,6,3);});
  T('pillar',14,34,g=>{g.fillStyle='#8a8494';g.fillRect(2,4,10,28);g.fillStyle='#a8a2b2';g.fillRect(3,4,3,28);g.fillStyle='#6a6474';g.fillRect(1,30,12,4);g.fillRect(1,1,12,4);g.fillStyle='#7ff3ff';g.fillRect(6,12,2,8);});
  T('portal',44,48,g=>{g.fillStyle='#5a5466';g.fillRect(2,10,8,38);g.fillRect(34,10,8,38);g.fillRect(2,4,40,8);g.fillStyle='#7a7484';g.fillRect(3,10,3,38);g.fillRect(35,10,3,38);g.fillRect(4,4,36,2);g.fillStyle='#1a1028';g.fillRect(10,12,24,36);g.fillStyle='#c58cff';g.fillRect(20,6,4,4);});
  T('fortwall',16,22,g=>{g.fillStyle='#6e6878';g.fillRect(0,6,16,16);g.fillStyle='#8a8494';g.fillRect(0,4,16,3);g.fillRect(2,2,5,3);g.fillRect(10,1,4,4);g.fillStyle='#565062';for(let y=9;y<22;y+=4)g.fillRect(0,y,16,1);g.fillRect(7,6,1,3);g.fillRect(3,10,1,3);g.fillRect(11,14,1,3);});
  T('flagpole',6,48,g=>{g.fillStyle='#5a4a3a';g.fillRect(2,2,2,46);g.fillStyle='#e8c860';g.fillRect(1,0,4,3);});
  T('banner_solarix',12,34,g=>{g.fillStyle='#5a4a3a';g.fillRect(5,0,2,34);g.fillStyle='#f4ead0';g.fillRect(1,3,10,18);g.fillRect(1,21,4,3);g.fillRect(7,21,4,3);disc(g,6,11,3,'#e8b830');g.fillStyle='#e8b830';g.fillRect(6,5,1,2);g.fillRect(6,15,1,2);g.fillRect(2,11,2,1);g.fillRect(9,11,2,1);});
  T('banner_umbra',12,34,g=>{g.fillStyle='#2a2430';g.fillRect(5,0,2,34);g.fillStyle='#2a1a44';g.fillRect(1,3,10,18);g.fillRect(1,21,4,3);g.fillRect(7,21,4,3);disc(g,6,11,3,'#b48cff');disc(g,7,10,2,'#2a1a44');});
  T('stall_red',34,30,g=>{g.fillStyle='#6b4a2b';g.fillRect(2,8,2,22);g.fillRect(30,8,2,22);for(let k=0;k<7;k++){g.fillStyle=k%2?'#e0464e':'#f1e9d6';g.fillRect(1+k*5,2,5,7);}g.fillStyle='#8a6440';g.fillRect(2,20,30,5);g.fillStyle='#c8a050';g.fillRect(6,17,4,3);g.fillRect(14,16,5,4);g.fillStyle='#e04a4a';g.fillRect(23,17,4,3);});
  T('stall_grey',34,30,g=>{g.fillStyle='#6b4a2b';g.fillRect(2,8,2,22);g.fillRect(30,8,2,22);for(let k=0;k<7;k++){g.fillStyle=k%2?'#4a4652':'#f2c14e';g.fillRect(1+k*5,2,5,7);}g.fillStyle='#8a6440';g.fillRect(2,20,30,5);g.fillStyle='#a8b0bc';g.fillRect(8,14,2,7);g.fillRect(20,15,6,2);});
  T('fountain',56,40,g=>{g.fillStyle='#8a8894';g.fillRect(2,12,52,24);g.fillRect(6,8,44,32);g.fillStyle='#a8a6b2';g.fillRect(6,8,44,3);g.fillStyle='#3a7ac8';g.fillRect(8,13,40,20);g.fillStyle='#5aa0e6';g.fillRect(10,15,36,4);g.fillStyle='#b5b3bb';g.fillRect(24,4,8,22);g.fillRect(20,0,16,6);g.fillStyle='#d8d6de';g.fillRect(25,4,2,20);});
  T('tower_o',26,52,g=>{g.fillStyle='#7a7682';g.fillRect(1,12,24,40);g.fillStyle='#9a96a2';g.fillRect(0,6,26,7);for(let x=0;x<26;x+=6)g.fillRect(x,2,4,5);g.fillStyle='#5f5b68';for(let y=16;y<52;y+=6)g.fillRect(1,y,24,1);g.fillStyle='#1a1428';g.fillRect(10,20,5,8);});
  T('tower_s',26,52,g=>{g.fillStyle='#3a3446';g.fillRect(2,12,22,40);g.fillStyle='#4e4860';g.fillRect(0,8,26,6);g.fillStyle='#2a2434';for(let y=17;y<52;y+=6)g.fillRect(2,y,22,1);g.fillStyle='#6a3aa8';g.fillRect(9,0,8,9);g.fillStyle='#b48cff';g.fillRect(11,1,4,6);g.fillStyle='#d8b0ff';g.fillRect(12,22,2,8);});
  T('wall_o',16,30,g=>{g.fillStyle='#7a7682';g.fillRect(0,9,16,21);g.fillStyle='#9a96a2';g.fillRect(0,3,16,7);g.fillRect(1,0,5,4);g.fillRect(10,0,5,4);g.fillStyle='#5f5b68';for(let y=13;y<30;y+=5)g.fillRect(0,y,16,1);g.fillRect(7,9,1,4);g.fillRect(3,14,1,4);g.fillRect(11,19,1,5);});
  T('wall_s',16,30,g=>{g.fillStyle='#3a3446';g.fillRect(0,8,16,22);g.fillStyle='#4e4860';g.fillRect(0,3,16,6);for(let x=0;x<16;x+=5){g.fillRect(x+1,0,3,3);}g.fillStyle='#2a2434';for(let y=12;y<30;y+=5)g.fillRect(0,y,16,1);g.fillRect(5,8,1,4);g.fillRect(10,13,1,4);g.fillStyle='#8a5ad0';g.fillRect(7,19,2,2);});
  T('mothertree',150,140,g=>{g.fillStyle='#5a3a24';g.fillRect(60,70,30,70);g.fillRect(50,120,50,20);g.fillRect(44,130,14,10);g.fillRect(92,128,14,12);g.fillStyle='#7a5234';g.fillRect(64,70,8,70);g.fillStyle='#3a2414';g.fillRect(84,70,4,66);
    treeCanopy(g,75,52,48,['#22163e','#33215e','#4e3388','#a888e8']);disc(g,40,60,22,'#33215e');disc(g,112,58,22,'#33215e');disc(g,36,54,10,'#4e3388');disc(g,108,50,10,'#4e3388');
    g.fillStyle='#d8b0ff';for(const [x,y] of [[40,70],[66,84],[104,74],[86,40],[54,30],[120,62]]){g.fillRect(x,y,3,4);g.fillStyle='#ffffff';g.fillRect(x+1,y+1,1,2);g.fillStyle='#d8b0ff';}});
  // maisons
  const icon=(g,x,y,role)=>{g.fillStyle='#5a3a1a';g.fillRect(x,y,14,10);g.fillStyle='#8a6440';g.fillRect(x+1,y+1,12,8);g.fillStyle='#2a1a10';g.fillRect(x+3,y-3,1,3);g.fillRect(x+10,y-3,1,3);
    g.fillStyle='#f2c14e';if(role==='hdv'){disc(g,x+7,y+5,3,'#f2c14e');g.fillStyle='#a87a1a';g.fillRect(x+7,y+3,1,4);}
    else if(role==='guild'){g.fillStyle='#c8ccd4';g.fillRect(x+4,y+2,6,4);g.fillRect(x+5,y+6,4,1);g.fillRect(x+6,y+7,2,1);}
    else if(role==='craft'){g.fillStyle='#c8ccd4';g.fillRect(x+3,y+2,7,3);g.fillStyle='#8a5a2a';g.fillRect(x+6,y+5,1,4);}
    else{g.fillStyle='#c8ccd4';for(let i=0;i<6;i++){g.fillRect(x+3+i,y+2+i,1,1);g.fillRect(x+10-i,y+2+i,1,1);}}};
  for(const st of ['o','s'])for(const role of ['hdv','guild','craft','war','home']){
    PROPS['house_'+st+'_'+role]=mkProp(104,84,g=>{
      if(st==='o'){g.fillStyle='#b8b0a0';g.fillRect(4,52,96,32);g.fillStyle='#9a9282';for(let y=56;y<84;y+=5)g.fillRect(4,y,96,1);for(let y=52,r=0;y<84;y+=5,r++)for(let x=4+(r%2)*6;x<100;x+=12)g.fillRect(x,y,1,5);
        g.fillStyle='#2f4a80';g.fillRect(0,8,104,46);for(let y=10;y<54;y+=5){g.fillStyle=(y/5)%2?'#3a5a9a':'#34528c';g.fillRect(1,y,102,4);}g.fillStyle='#5a7ab8';g.fillRect(0,8,104,3);g.fillStyle='#22385e';g.fillRect(0,52,104,3);
        g.fillStyle='#8a8494';g.fillRect(78,0,12,16);g.fillStyle='#6a6474';g.fillRect(78,0,12,2);}
      else{g.fillStyle='#4a4458';g.fillRect(4,52,96,32);g.fillStyle='#3a3446';for(let y=56;y<84;y+=5)g.fillRect(4,y,96,1);for(let y=52,r=0;y<84;y+=5,r++)for(let x=4+(r%2)*7;x<100;x+=14)g.fillRect(x,y,1,5);
        g.fillStyle='#2a1a44';g.fillRect(0,10,104,44);for(let y=12;y<54;y+=5){g.fillStyle=(y/5)%2?'#3e2a66':'#36245a';g.fillRect(1,y,102,4);}g.fillStyle='#6a4aa8';g.fillRect(0,10,104,2);g.fillStyle='#1a1030';g.fillRect(0,52,104,3);
        g.fillStyle='#2a1a44';for(const x of [10,52,94]){g.fillRect(x-2,0,4,12);}g.fillStyle='#b48cff';for(const x of [10,52,94])g.fillRect(x-1,1,2,3);}
      if(role!=='home'){g.fillStyle=st==='o'?'#3a2414':'#4a2a14';g.fillRect(43,58,18,26);g.fillStyle=st==='o'?'#5a3a20':'#6a3a1a';g.fillRect(45,60,14,24);g.fillStyle='#e8c860';g.fillRect(55,72,2,2);if(st==='s'){g.fillStyle='#4a2a14';g.fillRect(45,58,14,2);}icon(g,62,60,role);}
      else{g.fillStyle='#4a2a14';g.fillRect(45,62,14,22);}
      for(const wx of [14,78]){if(st==='o'){g.fillStyle='#5a4a3a';g.fillRect(wx-1,59,18,14);g.fillStyle='#f8e8a0';g.fillRect(wx,60,16,12);g.fillStyle='#5a4a3a';g.fillRect(wx+7,60,2,12);g.fillRect(wx,65,16,1);}
        else{disc(g,wx+8,66,6,'#2a2434');disc(g,wx+8,66,5,'#d8b0ff');g.fillStyle='#2a2434';g.fillRect(wx+7,61,1,10);}}
    });}
}

const PET_ROWS={chaton:[["O....O..","OO..OO..","OOOOOO..","OEOOEO..","OOWWOO..",".OOOOOOT",".O.O.OT."],["O....O..","OO..OO..","OOOOOO..","OEOOEO..","OOWWOO..",".OOOOOOT","O.O.O..T"],{O:'#e8783a',E:'#1a1a1a',W:'#f8e8d8',T:'#c85a2a'}],
  hibou:[[".W...W.",".WWWWW.","WYYWYYW","WKYWYKW",".WWBWW.",".WWWWW.","WWWWWWW",".F...F."],["W.....W","WWWWWWW","WYYWYYW","WKYWYKW",".WWBWW.",".WWWWW.",".WWWWW.",".F...F."],{W:'#e8eef8',Y:'#ffd84a',K:'#1a1a1a',B:'#e8a83a',F:'#e8a83a'}],
  slimou:[["..PPP..",".PWPPP.","PPKPKPP","PPPPPPP",".DDDDD."],["..PPP..",".PWPPP.","PPKPKPP","PPPPPPP","PPPPPPP","DDDDDDD"].slice(0,5),{P:'#ff8ad0',W:'#ffe0f4',K:'#3a1a2a',D:'#c85aa0'}]};
let PSPR={};
function buildPetSprites(){for(const k in PET_ROWS){const [a,b,pal]=PET_ROWS[k];PSPR[k]=rowSet(a,b,pal,2);}}

/* ---------- décors des campements, ruines et lieux ---------- */
function buildProps2(){
  const T=(k,w,h,fn)=>{PROPS[k]=mkProp(w,h,fn);};
  const tent=(c1,c2,c3)=>g=>{for(let y=0;y<22;y++){const hw=Math.round(2+y*.75);g.fillStyle=y%4<2?c1:c2;g.fillRect(17-hw,4+y,hw*2,1);}g.fillStyle=c3;g.fillRect(14,14,6,12);g.fillStyle='#1a1410';g.fillRect(15,16,4,10);g.fillStyle='#5a4a3a';g.fillRect(16,0,2,6);g.fillStyle=c2;g.fillRect(18,0,6,3);};
  T('tent_s',34,28,tent('#f4ead0','#e0d0a8','#b8862a'));T('tent_u',34,28,tent('#4a3a6a','#3a2a58','#8a5ad0'));T('tent_n',34,28,tent('#a8844a','#8a6a3a','#5a4428'));
  T('campfire',16,12,g=>{g.fillStyle='#5a3a1a';g.fillRect(2,8,12,3);g.fillRect(4,6,8,2);g.fillStyle='#6e6878';for(const x of [0,4,8,12])g.fillRect(x,9,3,3);});
  T('sign',16,30,g=>{g.fillStyle='#6b4a2b';g.fillRect(7,8,2,22);g.fillStyle='#8a6440';g.fillRect(1,3,14,8);g.fillStyle='#a87c52';g.fillRect(1,3,14,2);g.fillStyle='#4a3018';g.fillRect(3,7,10,1);});
  T('board',22,30,g=>{g.fillStyle='#6b4a2b';g.fillRect(2,10,2,20);g.fillRect(18,10,2,20);g.fillStyle='#8a6440';g.fillRect(0,2,22,16);g.fillStyle='#f0e6d0';g.fillRect(3,5,6,7);g.fillRect(12,4,7,6);g.fillRect(11,11,7,5);g.fillStyle='#c84a3a';g.fillRect(5,5,2,1);g.fillRect(14,4,2,1);});
  T('stele',18,30,g=>{g.fillStyle='#6e6878';g.fillRect(3,6,12,22);g.fillRect(5,3,8,4);g.fillStyle='#8a8494';g.fillRect(4,6,4,22);g.fillStyle='#4e4858';g.fillRect(1,26,16,4);g.fillStyle='#9ad8ff';g.fillRect(8,10,2,8);g.fillRect(6,13,6,2);});
  T('ruin',14,30,g=>{g.fillStyle='#8a8494';g.fillRect(2,8,10,20);g.fillStyle='#a8a2b2';g.fillRect(3,8,3,20);g.fillStyle='#6a6474';g.fillRect(1,26,12,4);g.fillRect(2,5,4,4);g.fillRect(8,7,4,2);g.fillStyle='#4a7a3a';g.fillRect(9,18,3,5);});
  T('ruinwall',16,20,g=>{g.fillStyle='#7a7484';g.fillRect(0,8,16,12);g.fillRect(0,4,7,5);g.fillRect(10,6,4,3);g.fillStyle='#5a5466';for(let y=11;y<20;y+=4)g.fillRect(0,y,16,1);g.fillRect(6,8,1,3);g.fillStyle='#4a7a3a';g.fillRect(2,16,4,4);});
  T('grave',12,16,g=>{g.fillStyle='#7a7484';g.fillRect(2,3,8,12);g.fillRect(3,1,6,3);g.fillStyle='#5a5466';g.fillRect(5,5,2,6);g.fillRect(4,7,4,1);g.fillStyle='#4a3a2a';g.fillRect(0,14,12,2);});
  T('bones',14,8,g=>{g.fillStyle='#e8e0c8';g.fillRect(1,4,9,2);g.fillRect(0,3,2,4);g.fillRect(9,3,2,4);g.fillRect(9,1,4,3);g.fillStyle='#1a1a1a';g.fillRect(10,2,1,1);});
  T('crystal',16,22,g=>{g.fillStyle='#6a3aa8';g.fillRect(6,2,4,18);g.fillRect(2,8,3,12);g.fillRect(11,6,3,14);g.fillStyle='#b48cff';g.fillRect(7,3,1,14);g.fillRect(3,9,1,9);g.fillRect(12,7,1,10);g.fillStyle='#e8d8ff';g.fillRect(7,3,1,3);});
  T('obelisk',14,40,g=>{g.fillStyle='#c8a868';g.fillRect(3,6,8,32);g.fillRect(5,2,4,5);g.fillStyle='#e0c486';g.fillRect(4,6,2,32);g.fillStyle='#8a6a3a';g.fillRect(1,36,12,4);g.fillStyle='#4ad6e0';g.fillRect(6,14,2,2);g.fillRect(6,22,2,2);});
}
