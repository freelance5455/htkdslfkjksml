'use strict';
/* ================== Paracraft Online · chat ==================
   Bouton « Chat » : la fenêtre s'ouvre en bas au centre, se redimensionne en glissant la poignée,
   se referme en touchant de nouveau « Chat ». Ce que tu écris s'affiche dans une bulle au-dessus de ton personnage. */

const CH_N={say:'Général',party:'Groupe',guild:'Guilde',sys:'Système'};
let chatOpen=false,_tickT=null,_lastN=0;
renderChat=function(){const el=$('#chat');if(!el)return;
  el.innerHTML=chatLines.map(l=>{const tag=l.chan==='guild'?'<em class="cg">[Guilde]</em> ':l.chan==='party'?'<em class="cp">[Groupe]</em> ':'';const cls=l.chan==='sys'?'sys':l.chan;
    return l.name?`<div class="${cls}">${tag}<b style="color:${l.col||'#f1e9d6'}">${esc(l.name)}</b> : ${esc(l.txt)}</div>`:`<div class="${cls}">${tag}${esc(l.txt)}</div>`;}).join('');
  el.scrollTop=el.scrollHeight;
  if(!chatOpen&&chatLines.length&&chatLines.length!==_lastN){const l=chatLines[chatLines.length-1],t=$('#chattick');if(t){t.innerHTML=(l.name?`<b style="color:${l.col||'#f1e9d6'}">${esc(l.name)}</b> : `:'')+esc(l.txt);t.classList.add('on');clearTimeout(_tickT);_tickT=setTimeout(()=>t.classList.remove('on'),4500);}}
  _lastN=chatLines.length;};
function setChat(open){chatOpen=open;$('#chatbox').hidden=!open;$('#bChat').classList.toggle('on',open);$('#chattick').classList.remove('on');if(open){applyChatH();renderChat();}else{const i=$('#chatin');if(i)i.blur();}}
function applyChatH(){const h=clamp(SET.chatH||150,90,Math.round(innerHeight*.7));$('#chatbox').style.height=h+'px';}
// bouton Chat (sous la rangée d'icônes, comme IMO)
$('#hudR').insertAdjacentHTML('beforeend',`<button id="bChat" class="ib chatb" type="button"><img src="${uiIcon('chat')}" alt=""><span>Chat</span></button>`);
$('#bChat').addEventListener('click',()=>{if(state==='play')setChat(!chatOpen);});
// poignée de redimensionnement
{const grip=$('#chatgrip');let drag=null;
  grip.addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();drag={y:e.clientY,h:$('#chatbox').getBoundingClientRect().height};try{grip.setPointerCapture(e.pointerId);}catch(_){}});
  grip.addEventListener('pointermove',e=>{if(!drag)return;SET.chatH=Math.round(drag.h+(drag.y-e.clientY));applyChatH();const el=$('#chat');el.scrollTop=el.scrollHeight;});
  const end=()=>{if(drag){drag=null;saveSettings();}};grip.addEventListener('pointerup',end);grip.addEventListener('pointercancel',end);}
// envoi
const REPLY={hello:['salut !','yo','bonjour à toi','hey !','re'],q:['aucune idée','demande au capitaine sur la place','regarde dans ton journal (Quêtes)','essaie la Frontière si t’es 21+','check l’HDV'],gen:['mdr','gg','+1','ok','ah ouais ?','pareil','je suis dans le coin','qui veut grouper ?','on se voit à la fontaine','bonne chance','haha']};
function botReply(txt,ch){return;const pool=ch==='party'&&party?party.members.filter(b=>!b.dead):bots.filter(b=>!b.dead&&b.map===curId()&&b.fac===P.fac&&(ch!=='guild'||(P.guild&&b.guild===P.guild.name))&&dist(b,P)<420);
  if(!pool.length)return;const b=pick(pool),low=txt.toLowerCase(),line=pick(/^(salut|bonjour|yo|hey|coucou|re\b)/.test(low)?REPLY.hello:low.includes('?')?REPLY.q:REPLY.gen);
  setTimeout(()=>{if(state!=='play')return;chat(b.n,line,ch==='party'?'#9be3ff':ch==='guild'?'#9be36a':FACTIONS[b.fac].c,ch);bubbleSay(b,line,4);},rr(1200,2800));}
$('#chatform').addEventListener('submit',e=>{e.preventDefault();const inp=$('#chatin'),txt=(inp.value||'').replace(/\s+/g,' ').trim().slice(0,80);if(!txt||state!=='play')return;
  let ch=$('#chatch').value;if(ch==='party'&&!party){chat(null,'Tu n’es dans aucun groupe.');return;}if(ch==='guild'&&!P.guild){chat(null,'Tu n’as pas de guilde.');return;}
  chat(P.name,txt,ch==='party'?'#9be3ff':ch==='guild'?'#9be36a':'#ffffff',ch);bubbleSay(P,txt,5);inp.value='';botReply(txt,ch);});
$('#chatin').addEventListener('keydown',e=>{e.stopPropagation();if(e.key==='Escape'){$('#chatin').blur();setChat(false);}});
addEventListener('keydown',e=>{if(e.key==='Enter'&&state==='play'&&$('#modal').hidden&&document.activeElement!==$('#chatin')){e.preventDefault();if(!chatOpen)setChat(true);$('#chatin').focus();}});
for(const id of ['#chatbox'])for(const ev of ['pointerdown','touchstart'])$(id).addEventListener(ev,e=>e.stopPropagation(),{passive:true});
const _toTitleC=toTitle;toTitle=function(){setChat(false);_toTitleC();};
renderChat();
