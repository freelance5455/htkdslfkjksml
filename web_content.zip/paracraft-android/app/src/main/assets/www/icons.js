/* ================== Paracraft Online · icônes pixel ==================
   Icônes 16×16 dessinées par code, agrandies ×2 avec contour, servies en URL de données (cache). */

const _icoCache=new Map();
const TIERC=['#c8884a','#a8acb8','#d8dce6','#7fd4ff','#7a6a9a','#b07cff','#c83a6a','#ff7a3a','#ffe7a0','#ffffff'];
function icoMake(key,fn,bg){let u=_icoCache.get(key);if(u)return u;const c=cnv(16,16),g=c.getContext('2d');fn(g);const o=outline(c,'#1a1210');const big=cnv(36,36),bg2=big.getContext('2d');bg2.imageSmoothingEnabled=false;
  if(bg){bg2.fillStyle=bg;bg2.beginPath();bg2.arc(18,18,17,0,7);bg2.fill();}bg2.drawImage(o,0,0,18,18,0,0,36,36);u=big.toDataURL();_icoCache.set(key,u);return u;}
const I={r:(g,x,y,w,h,c)=>{g.fillStyle=c;g.fillRect(x,y,w,h);},
  line:(g,x0,y0,x1,y1,c)=>{g.fillStyle=c;const n=Math.max(Math.abs(x1-x0),Math.abs(y1-y0));for(let i=0;i<=n;i++)g.fillRect(Math.round(x0+(x1-x0)*i/n),Math.round(y0+(y1-y0)*i/n),1,1);},
  d:(g,x,y,r,c)=>disc(g,x,y,r,c)};
const sh=(c,k)=>shade(c,k);
/* ---------- objets ---------- */
const ICO_ITEM={
  sword:(g,c)=>{I.line(g,3,12,11,4,c);I.line(g,4,12,12,4,sh(c,.75));I.line(g,11,3,13,5,'#fff');I.r(g,2,10,5,2,'#8a6a2a');I.r(g,1,12,3,3,'#5a3a1a');},
  bow:(g,c)=>{for(let i=0;i<12;i++){const x=Math.round(4+Math.sin(i/11*Math.PI)*5);I.r(g,x,2+i,2,1,'#8a5a2a');}I.line(g,5,2,5,13,'#e8e0d0');I.line(g,3,8,13,8,c);I.r(g,12,7,2,3,'#e8e8f0');I.r(g,2,7,2,3,'#c83a3a');},
  staff:(g,c)=>{I.line(g,4,14,10,5,'#8a5a2a');I.line(g,5,14,11,5,'#6a4020');I.d(g,11,4,3,c);I.r(g,10,3,1,1,'#fff');},
  helm_g:(g,c)=>{I.r(g,3,4,10,8,c);I.r(g,3,4,10,1,sh(c,1.3));I.r(g,3,12,3,2,sh(c,.7));I.r(g,10,12,3,2,sh(c,.7));I.r(g,7,8,2,6,sh(c,.6));I.r(g,4,7,8,1,'#2a2a30');I.r(g,7,1,2,3,'#c83a3a');},
  helm_a:(g,c)=>{I.d(g,8,8,6,'#3f6a3a');I.r(g,4,8,8,6,'#e7b98c');I.r(g,2,8,2,6,'#3f6a3a');I.r(g,12,8,2,6,'#3f6a3a');I.r(g,4,3,8,2,c);},
  helm_m:(g,c)=>{for(let i=0;i<9;i++){const w2=2+i*1.4;I.r(g,8-w2/2,2+i,w2,1,'#4a2f88');}I.r(g,1,11,14,2,'#4a2f88');I.r(g,4,10,8,1,c);I.r(g,9,1,2,2,c);},
  armor_g:(g,c)=>{I.r(g,3,3,10,11,c);I.r(g,1,3,3,5,sh(c,.8));I.r(g,12,3,3,5,sh(c,.8));I.r(g,6,3,4,2,'#2a2a30');I.r(g,7,6,2,7,sh(c,1.25));I.r(g,3,12,10,2,'#8a6a2a');},
  armor_a:(g,c)=>{I.r(g,3,3,10,11,'#7a5232');I.r(g,1,3,3,5,'#5a3a22');I.r(g,12,3,3,5,'#5a3a22');I.r(g,6,3,4,3,'#3a2414');I.r(g,4,9,8,2,c);I.r(g,7,6,1,8,'#3a2414');},
  armor_m:(g,c)=>{I.r(g,4,2,8,13,'#5a3f9a');I.r(g,2,4,3,6,'#4a2f88');I.r(g,11,4,3,6,'#4a2f88');I.r(g,3,12,10,3,'#5a3f9a');I.r(g,7,2,2,13,c);I.r(g,5,2,6,1,c);},
  gloves:(g,c)=>{I.r(g,3,5,5,8,c);I.r(g,3,3,4,3,c);I.r(g,8,8,2,3,c);I.r(g,3,12,5,2,sh(c,.6));I.r(g,9,4,5,8,sh(c,.85));I.r(g,9,2,4,3,sh(c,.85));I.r(g,9,11,5,2,sh(c,.6));},
  boots:(g,c)=>{I.r(g,2,3,4,9,c);I.r(g,2,11,7,3,c);I.r(g,2,13,7,1,sh(c,.6));I.r(g,9,4,4,8,sh(c,.85));I.r(g,9,11,6,3,sh(c,.85));I.r(g,2,4,4,1,'#8a6a2a');},
  necklace:(g,c)=>{for(let i=0;i<12;i++){const a=i/11*Math.PI;I.r(g,Math.round(8-Math.cos(a)*6),Math.round(2+Math.sin(a)*7),1,1,'#e8c860');}I.d(g,8,11,3,c);I.r(g,7,10,1,1,'#fff');},
  ring:(g,c)=>{I.d(g,8,9,5,'#e8c860');I.d(g,8,9,3,'#00000000');g.clearRect(6,7,5,5);I.r(g,6,1,4,4,c);I.r(g,7,2,1,1,'#fff');},
  cape:(g,c)=>{I.r(g,4,2,8,2,sh(c,.7));for(let i=0;i<11;i++){const w2=8+Math.round(i*.5);I.r(g,8-w2/2,4+i,w2,1,i%3?c:sh(c,.85));}I.d(g,8,8,2,'#f2c14e');},
  bag:(g,c)=>{I.r(g,2,6,12,8,c);I.r(g,2,6,12,2,sh(c,1.2));I.r(g,5,3,6,2,sh(c,.6));I.r(g,5,3,1,4,sh(c,.6));I.r(g,10,3,1,4,sh(c,.6));I.r(g,7,8,2,3,'#f2c14e');I.r(g,2,13,12,1,sh(c,.6));},
};
function itemIcon(it){const t=it.type,c=TIERC[it.tier||0];
  if(t==='sac'){const col={musette:'#c8a070',sacoche:'#8a5a32',besace:'#4a3a6a',runique:it.fac==='umbra'?'#6a3aa8':'#2f5aa0',abime:'#2a1a3a'}[it.bag]||'#8a5a32';return icoMake('sac'+it.bag+(it.fac||''),g=>ICO_ITEM.bag(g,col));}
  if(t==='arme')return icoMake('w'+it.cls+it.tier,g=>ICO_ITEM[{guerrier:'sword',archer:'bow',mage:'staff'}[it.cls]||'sword'](g,c));
  if(t==='casque')return icoMake('h'+it.cls+it.tier,g=>ICO_ITEM[{guerrier:'helm_g',archer:'helm_a',mage:'helm_m'}[it.cls]||'helm_g'](g,c));
  if(t==='armure')return icoMake('a'+it.cls+it.tier,g=>ICO_ITEM[{guerrier:'armor_g',archer:'armor_a',mage:'armor_m'}[it.cls]||'armor_g'](g,c));
  if(t==='gants')return icoMake('gl'+it.tier,g=>ICO_ITEM.gloves(g,it.cls==='mage'?'#8a6ac8':it.cls==='archer'?'#8a5a32':c));
  if(t==='bottes')return icoMake('bo'+it.cls+it.tier,g=>ICO_ITEM.boots(g,it.cls==='mage'?'#5a3f9a':it.cls==='archer'?'#7a5232':c));
  if(t==='collier')return icoMake('ne'+it.rar,g=>ICO_ITEM.necklace(g,RARC[it.rar]||'#7fd4ff'));
  if(t==='anneau')return icoMake('ri'+it.rar,g=>ICO_ITEM.ring(g,RARC[it.rar]||'#ff6a8a'));
  if(t==='cape')return icoMake('ca'+it.fac,g=>ICO_ITEM.cape(g,it.fac==='umbra'?'#6a3aa8':'#c8962a'));
  return icoMake('second',g=>{I.r(g,3,3,10,10,'#7a6a5a');I.r(g,5,5,6,6,'#a89a8a');});}
/* ---------- consommables et ressources ---------- */
const flask=(g,c,tall)=>{if(tall){I.r(g,6,1,4,2,'#c8a070');I.r(g,6,3,4,3,'#d8e8f0');I.r(g,4,6,8,9,c);I.r(g,4,6,8,2,'#d8e8f0');I.r(g,5,8,2,4,sh(c,1.5));}else{I.r(g,6,2,4,2,'#c8a070');I.r(g,7,4,2,2,'#d8e8f0');I.d(g,8,10,5,c);I.r(g,4,8,8,1,sh(c,1.3));I.r(g,6,9,2,2,'#ffffffaa');}};
const scroll=(g,c,mark)=>{I.r(g,2,4,12,9,'#f4ead0');I.r(g,2,4,12,1,'#d8c8a0');I.r(g,1,3,2,11,'#c8a070');I.r(g,13,3,2,11,'#c8a070');for(let y=6;y<11;y+=2)I.r(g,4,y,6,1,'#a89878');if(c){I.d(g,11,11,3,c);if(mark)for(let k=0;k<mark;k++)I.r(g,9+k*2,11,1,1,'#fff');}};
const book=(g,c)=>{I.r(g,3,2,10,12,c);I.r(g,3,2,10,1,sh(c,1.3));I.r(g,3,2,2,12,sh(c,.6));I.r(g,12,3,2,11,'#f4ead0');I.r(g,7,5,4,4,'#f2c14e');I.r(g,8,6,2,2,sh(c,1.4));};
const RESC={frene:'#c8a070',chene:'#8a5a32',if:'#5a3a22',spectral:'#9ad8ff',fer:'#c9b8a8',cristal:'#4ad6e0',mithril:'#b07cff',obsidienne:'#3a2a4a',fernoir:'#3a3a44',quartzombre:'#7a3aa8',ortie:'#3a8a3a',sauge:'#7aa88a',trefle:'#78c8f0',mandragore:'#8a4a9a',moussesang:'#c83a3a',racarcane:'#7a5aff',champcav:'#e8c870',goujon:'#9ab0c0',truite:'#c88a6a',anguille:'#4a5a3a',poissonlune:'#c8d8ff'};
function consIcon(k){const C=(fn,bg)=>icoMake('c_'+k,fn,bg);
  if(k==='pv')return C(g=>flask(g,'#e0464e'));if(k==='pm')return C(g=>flask(g,'#4b8ef0'));
  if(k==='elurg'||k==='elurg1')return C(g=>flask(g,k==='elurg'?'#ff2a4a':'#e06a6a',1));if(k==='flux'||k==='flux1')return C(g=>flask(g,k==='flux'?'#2a6aff':'#6a9af0',1));
  if(k==='elxp')return C(g=>flask(g,'#9be36a',1));if(k==='elatk')return C(g=>flask(g,'#ff8a2a',1));if(k==='potpvp')return C(g=>flask(g,'#c8ccd4',1));if(k==='huile')return C(g=>flask(g,'#4a4a3a',1));
  if(/^ench\d/.test(k))return C(g=>scroll(g,'#c83a3a',+k[4]));if(/^encha\d/.test(k))return C(g=>scroll(g,'#2f6ac8',+k[5]));
  if(k==='retour')return C(g=>scroll(g,'#7ff3ff'));if(k==='parch')return C(g=>scroll(g,'#f2c14e'));if(k==='velin')return C(g=>scroll(g,null));
  if(k.startsWith('livre_')){const cl=k.split('_')[1];return C(g=>book(g,{guerrier:'#a83a2a',archer:'#3a7a3a',mage:'#4a3aa8'}[cl]));}
  if(k==='poussiere')return C(g=>{I.d(g,8,11,5,'#8a6ac8');I.d(g,6,10,2,'#c8a8ff');I.r(g,10,5,1,1,'#fff');I.r(g,5,4,1,1,'#c8a8ff');});
  if(k==='essence')return C(g=>{for(let i=0;i<7;i++)I.r(g,8-i,3+i,i*2+1,1,'#5ad8ff');for(let i=0;i<5;i++)I.r(g,4+i,10+i,8-i*2,1,'#2a8ac8');I.r(g,6,5,2,2,'#fff');});
  if(k==='fraggrim')return C(g=>{I.r(g,3,3,9,10,'#e8dcc0');I.line(g,11,3,8,13,'#00000000');g.clearRect(10,7,3,7);I.r(g,4,5,5,1,'#8a7a5a');I.r(g,4,8,4,1,'#8a7a5a');});
  if(k==='fragcle'||/^cle\d/.test(k)){const c={fragcle:'#a8a090',cle1:'#c8ccd4',cle2:'#f2c14e',cle3:'#b07cff'}[k];return C(g=>{I.d(g,5,6,3,c);g.clearRect(4,5,2,2);I.r(g,7,6,7,2,c);I.r(g,11,8,1,3,c);I.r(g,13,8,1,2,c);if(k==='fragcle')g.clearRect(10,5,6,6);});}
  if(k==='friandise')return C(g=>{I.d(g,8,8,4,'#ff6a8a');I.r(g,1,7,4,3,'#ffd36a');I.r(g,12,7,4,3,'#ffd36a');I.r(g,7,6,2,2,'#fff');});
  if(k==='gateau'||k==='grandgateau')return C(g=>{I.r(g,2,8,12,6,'#e8c070');I.r(g,2,8,12,2,'#fff4f8');I.r(g,4,11,8,1,'#ff6a8a');if(k==='grandgateau'){I.r(g,4,4,8,4,'#e8c070');I.r(g,4,4,8,1,'#fff4f8');}I.r(g,8,1,1,3,'#fff');I.r(g,8,0,1,1,'#ffd36a');});
  if(k==='boite'||k==='boiteanniv')return C(g=>{const c=k==='boite'?'#3a8ac8':'#c83a6a';I.r(g,2,6,12,8,c);I.r(g,1,4,14,3,sh(c,1.2));I.r(g,7,4,2,10,'#f2c14e');I.r(g,4,1,3,3,'#f2c14e');I.r(g,9,1,3,3,'#f2c14e');});
  if(k==='affut')return C(g=>{I.r(g,2,7,12,5,'#7a7a84');I.r(g,2,7,12,1,'#a8a8b4');I.line(g,4,3,12,6,'#e8e8f0');});
  if(k==='fleches')return C(g=>{for(const o of [0,3]){I.line(g,2+o,13,11+o,4,'#8a5a2a');I.r(g,10+o,2,3,3,'#c8ccd4');I.r(g,1+o,12,2,3,'#c83a3a');}});
  if(k==='kit')return C(g=>{I.r(g,2,6,12,8,'#a83a2a');I.r(g,2,6,12,2,'#c85a3a');I.r(g,6,3,4,3,'#5a3a22');I.r(g,7,9,2,4,'#fff');I.r(g,5,10,6,2,'#fff');});
  if(k==='enclume')return C(g=>{I.r(g,2,5,12,3,'#5a5a64');I.r(g,1,5,2,2,'#5a5a64');I.r(g,6,8,4,3,'#4a4a52');I.r(g,3,11,10,3,'#4a4a52');I.r(g,3,5,10,1,'#8a8a94');});
  if(k.startsWith('plat'))return C(g=>{I.d(g,8,10,6,'#e8e0d0');I.d(g,8,10,4,'#d8d0c0');I.r(g,5,8,7,3,{plat1:'#9ab0c0',plat2:'#c88a6a',plat3:'#6a5a3a',plat4:'#c8d8ff'}[k]||'#c88a6a');I.r(g,10,8,2,1,'#3a8a3a');});
  if(k.startsWith('comp_')){const s=k.slice(5);return C(g=>{if(s==='ombres'){I.d(g,8,9,5,'#ff8a2a');I.r(g,7,2,2,3,'#3a6a2a');I.r(g,6,8,1,2,'#1a1a1a');I.r(g,9,8,1,2,'#1a1a1a');I.r(g,6,11,4,1,'#1a1a1a');}else if(s==='moisson'){for(let i=0;i<3;i++)I.line(g,5+i*3,14,6+i*2,3,'#e8c860');}else{for(const [x,y] of [[8,2],[8,14],[2,8],[14,8]])I.line(g,8,8,x,y,'#ffe7a0');I.d(g,8,8,2,'#fff');}});}
  if(k.startsWith('lettre_'))return icoMake('c_'+k,g=>{I.r(g,2,2,12,12,'#f4ead0');I.r(g,2,2,12,1,'#ffd36a');g.fillStyle='#a83a2a';g.font='bold 11px monospace';g.textAlign='center';g.textBaseline='middle';g.fillText(k.slice(7),8,9);});
  if(k.startsWith('bag_'))return icoMake('c_'+k,g=>ICO_ITEM.bag(g,'#8a5a32'));
  return C(g=>{I.r(g,4,4,8,8,'#a89878');I.r(g,6,6,4,4,'#f4ead0');});}
function resIcon(k){const c=RESC[k]||'#a89878',r=RES[k]||{};return icoMake('r_'+k,g=>{
  if(r.prof==='bucheron'){for(const y of [9,4]){I.r(g,2,y,12,4,c);I.r(g,2,y,12,1,sh(c,1.3));I.d(g,13,y+2,2,sh(c,1.5));I.r(g,13,y+2,1,1,sh(c,.7));}}
  else if(r.prof==='mineur'){I.d(g,8,9,6,'#6a6470');I.d(g,7,8,4,c);I.r(g,5,6,2,2,sh(c,1.6));I.r(g,10,10,2,2,c);}
  else if(r.prof==='herboriste'){I.line(g,8,15,8,6,'#3a6a2a');I.d(g,5,7,3,c);I.d(g,11,6,3,c);I.d(g,8,4,3,sh(c,1.2));}
  else if(r.prof==='pecheur'){I.d(g,7,8,5,c);I.r(g,2,8,10,3,c);I.r(g,11,6,4,6,sh(c,.8));I.r(g,4,7,1,1,'#1a1a1a');}
  else if(k==='cuir'||k==='peaurare'){const col=k==='cuir'?'#a8743a':'#7a3aa8';I.r(g,3,3,10,10,col);I.r(g,1,5,2,6,col);I.r(g,13,5,2,6,col);I.r(g,5,1,6,2,col);I.r(g,5,13,6,2,col);I.r(g,6,6,4,4,sh(col,1.2));}
  else{flask(g,'#c83a6a',1);}});}
/* ---------- sorts ---------- */
const CLSC={guerrier:'#7a2a24',archer:'#2a5a2a',mage:'#2a2a6a'};
const ICO_SK={
  basic:(g,cl)=>cl==='archer'?ICO_SK.arrow(g):cl==='mage'?ICO_SK.bolt(g):ICO_ITEM.sword(g,'#e8ecf4'),
  arrow:g=>{I.line(g,2,13,12,3,'#c8a070');I.r(g,11,2,3,3,'#e8ecf4');I.r(g,1,12,3,3,'#c83a3a');},
  bolt:g=>{const p=[[10,1],[5,8],[9,8],[4,15],[12,6],[8,6],[12,1]];g.fillStyle='#ffe14a';g.beginPath();g.moveTo(p[0][0],p[0][1]);for(const q of p)g.lineTo(q[0],q[1]);g.fill();I.r(g,8,3,1,3,'#fff');},
  charge:g=>{for(const y of [4,8,12])I.line(g,1,y,8,y,'#ff8a5a');for(let i=0;i<6;i++)I.r(g,9+i,2+i,1,12-i*2,'#e8ecf4');},
  stun:g=>{I.r(g,2,4,9,9,'#a8acb8');I.r(g,2,4,9,1,'#e8ecf4');I.d(g,6,8,2,'#f2c14e');for(const [x,y] of [[12,2],[14,6],[12,10]])I.r(g,x,y,2,2,'#ffe14a');},
  taunt:g=>{I.d(g,8,8,6,'#e8c070');I.d(g,8,9,3,'#5a1a1a');I.r(g,5,5,2,2,'#1a1a1a');I.r(g,9,5,2,2,'#1a1a1a');I.r(g,1,2,2,4,'#ff5a3a');I.r(g,13,2,2,4,'#ff5a3a');},
  aoe:g=>{for(let a=0;a<8;a++){const x=8+Math.cos(a*.785)*6,y=8+Math.sin(a*.785)*6;I.line(g,8,8,Math.round(x),Math.round(y),a%2?'#f2c14e':'#e8ecf4');}I.d(g,8,8,2,'#fff');},
  rally:g=>{I.r(g,3,2,1,13,'#6a4a2a');I.r(g,4,2,9,7,'#f2c14e');I.r(g,4,6,6,3,'#c83a3a');I.r(g,9,3,3,2,'#fff');},
  execute:g=>{I.d(g,8,7,5,'#e8e0d0');I.r(g,5,6,2,2,'#1a1a1a');I.r(g,9,6,2,2,'#1a1a1a');I.r(g,6,11,4,3,'#e8e0d0');I.r(g,7,11,1,2,'#1a1a1a');I.line(g,1,15,15,1,'#ff3a3a');},
  sunder:g=>{I.r(g,3,3,10,10,'#8a8a96');I.r(g,3,3,10,1,'#c8ccd4');I.line(g,5,3,9,8,'#1a1a1a');I.line(g,9,8,6,13,'#1a1a1a');I.r(g,11,1,3,3,'#ff8a5a');},
  bastion:g=>{I.r(g,3,2,10,9,'#c8ccd4');for(let i=0;i<5;i++)I.r(g,3+i,11+i,10-i*2,1,'#c8ccd4');I.r(g,7,3,2,10,'#f2c14e');I.r(g,4,6,8,2,'#f2c14e');},
  slowshot:g=>{ICO_SK.arrow(g);for(const [x,y] of [[3,3],[5,6],[2,8]])I.r(g,x,y,1,1,'#a8e8ff');I.r(g,11,2,3,3,'#a8e8ff');},
  tracker:g=>{I.d(g,8,8,6,'#e8e0d0');I.d(g,8,8,4,'#3a8a3a');I.d(g,8,8,2,'#1a1a1a');I.r(g,7,7,1,1,'#fff');},
  trap:g=>{I.r(g,2,10,12,3,'#6a6a74');for(let x=2;x<14;x+=3){I.r(g,x,6,2,4,'#c8ccd4');I.r(g,x,5,1,1,'#fff');}I.d(g,8,12,1,'#c83a3a');},
  volley:g=>{for(const o of [-3,0,3]){I.line(g,3,13,11+o,3,'#c8a070');I.r(g,10+o,2,3,2,'#e8ecf4');}},
  pierce:g=>{I.line(g,1,8,14,8,'#fff2a8');I.line(g,1,7,14,7,'#c8a070');I.r(g,12,5,3,5,'#e8ecf4');for(const x of [5,9])I.r(g,x,4,1,8,'#7fd4ff');},
  snipe:g=>{I.d(g,8,8,6,'#c83a3a');I.d(g,8,8,5,'#00000000');g.clearRect(4,4,9,9);I.r(g,7,1,2,14,'#e8ecf4');I.r(g,1,7,14,2,'#e8ecf4');I.r(g,7,7,2,2,'#ff3a3a');},
  leap:g=>{for(let i=0;i<8;i++)I.r(g,2+i,12-Math.round(Math.sin(i/7*Math.PI)*8),2,2,'#e8ecf4');I.r(g,11,10,4,1,'#c8a070');I.line(g,10,6,14,10,'#9be36a');},
  rain:g=>{for(const [x,y] of [[3,2],[7,4],[11,1],[5,9],[10,8],[13,6]]){I.line(g,x,y,x-2,y+4,'#c8a070');I.r(g,x-3,y+4,2,2,'#e8ecf4');}},
  heal:g=>{I.d(g,5,6,3,'#ff6a8a');I.d(g,11,6,3,'#ff6a8a');for(let i=0;i<6;i++)I.r(g,2+i,7+i,12-i*2,1,'#ff6a8a');I.r(g,6,4,2,2,'#fff');},
  root:g=>{for(const [x,s] of [[4,1],[8,-1],[12,1]]){for(let y=15;y>3;y--)I.r(g,x+Math.round(Math.sin(y*.8)*s*1.5),y,2,1,'#5a8a3a');}I.r(g,3,3,10,2,'#2a1a3a');},
  shield:g=>{I.d(g,8,8,7,'#c58cff');I.d(g,8,8,5,'#3a2a6a');I.d(g,8,8,3,'#c58cff');I.r(g,5,4,2,2,'#fff');},
  curse:g=>{I.d(g,8,7,5,'#6a3aa8');I.r(g,5,6,2,2,'#c8ff6a');I.r(g,9,6,2,2,'#c8ff6a');I.r(g,6,11,4,3,'#6a3aa8');for(const x of [3,12])I.line(g,x,15,x+1,11,'#9a5ad8');},
  storm:g=>{I.d(g,6,5,4,'#7a8aa8');I.d(g,10,5,4,'#8a9ab8');I.r(g,3,5,11,3,'#8a9ab8');I.line(g,8,8,6,12,'#7ff3ff');I.line(g,6,12,9,12,'#7ff3ff');I.line(g,9,12,7,15,'#7ff3ff');},
  benison:g=>{for(const [x,y,r] of [[8,8,3],[3,4,1],[13,3,1],[12,12,1],[4,12,1]])I.d(g,x,y,r,'#8ab4ff');I.r(g,7,1,2,14,'#d8e8ff');I.r(g,1,7,14,2,'#d8e8ff');},
  blink:g=>{for(let i=0;i<18;i++){const a=i*.7,r=1+i*.33;I.r(g,Math.round(8+Math.cos(a)*r),Math.round(8+Math.sin(a)*r),1,1,i%2?'#c58cff':'#7ff3ff');}},
  massheal:g=>{I.d(g,8,8,7,'#3a8a3a');I.r(g,6,3,4,10,'#e8ffe0');I.r(g,3,6,10,4,'#e8ffe0');},
  apoca:g=>{I.d(g,8,10,5,'#ff5a1a');I.d(g,8,10,3,'#ffd060');for(const [x,y] of [[3,2],[12,1],[7,0]]){I.line(g,x,y,x+2,y+5,'#ff8a2a');I.r(g,x+2,y+5,2,2,'#ffd060');}},
  rage:g=>ICO_SK.taunt(g),hawk:g=>ICO_SK.tracker(g),barrier:g=>ICO_SK.shield(g),nova:g=>ICO_SK.storm(g),meteor:g=>ICO_SK.apoca(g),fireball:g=>ICO_SK.apoca(g),dash:g=>ICO_SK.charge(g),guard:g=>ICO_SK.bastion(g),heavy:g=>ICO_SK.sunder(g)};
function spellIcon(cls,sk){return icoMake('sk_'+cls+sk.k,g=>(ICO_SK[sk.k]||ICO_SK.aoe)(g,cls),CLSC[cls]);}
/* ---------- interface ---------- */
const ICO_UI={
  sac:g=>ICO_ITEM.bag(g,'#a8743a'),
  carte:g=>{I.r(g,1,3,14,11,'#e8d8a8');I.r(g,1,3,14,1,'#c8b088');I.r(g,5,3,1,11,'#c8b088');I.r(g,10,3,1,11,'#c8b088');I.line(g,3,11,12,6,'#c83a3a');I.r(g,11,5,3,3,'#c83a3a');},
  quetes:g=>{scroll(g,null);I.r(g,7,3,2,6,'#ffd36a');I.r(g,7,10,2,2,'#ffd36a');},
  sorts:g=>book(g,'#4a3aa8'),
  perso:g=>ICO_ITEM.helm_g(g,'#c8ccd4'),
  menu:g=>{for(const y of [3,7,11])I.r(g,2,y,12,2,'#e8dcc0');},
  metiers:g=>{I.r(g,2,9,7,3,'#5a5a64');I.line(g,7,12,13,3,'#8a5a2a');I.r(g,11,1,4,4,'#a8acb8');},
  guilde:g=>{I.r(g,3,2,10,9,'#2f5aa0');for(let i=0;i<5;i++)I.r(g,3+i,11+i,10-i*2,1,'#2f5aa0');I.r(g,6,4,4,4,'#f2c14e');},
  event:g=>{I.r(g,2,6,3,6,'#c8962a');for(let i=0;i<8;i++)I.r(g,5+i,6-Math.round(i*.5),1,6+i,'#f2c14e');I.r(g,4,13,2,2,'#8a5a2a');},
  pk:g=>{I.line(g,2,2,13,13,'#e8ecf4');I.line(g,13,2,2,13,'#e8ecf4');I.r(g,1,11,4,4,'#c83a3a');I.r(g,11,11,4,4,'#c83a3a');},
  chat:g=>{I.r(g,1,2,14,9,'#f4ead0');I.r(g,3,11,3,3,'#f4ead0');for(const x of [4,8,12])I.r(g,x-1,6,2,2,'#5a4a3a');},
  attaque:g=>ICO_ITEM.sword(g,'#e8ecf4'),parler:g=>ICO_UI.chat(g),
  pv:g=>flask(g,'#e0464e'),pm:g=>flask(g,'#4b8ef0'),or:g=>{I.d(g,8,8,6,'#c8962a');I.d(g,8,8,5,'#f2c14e');I.r(g,6,5,2,6,'#ffe7a0');}};
function uiIcon(k){return icoMake('ui_'+k,ICO_UI[k]||ICO_UI.menu);}
