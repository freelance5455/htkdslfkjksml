/* ================== Paracraft Online · inventaire, sacs et encombrement ==================
   Document « Gestion de l'Inventaire & des Sacs » : poche de 12 emplacements, 2 emplacements de sac,
   piles (équipement et grimoires 1, consommables 20, matériaux 50, monnaies virtuelles 0),
   poids max = 50 kg + FOR × 2 + CON × 1, paliers 75 % / 100 %, pertes à la mort en zone contestée,
   usure et rupture des sacs. */

const POCKET=12,STACK_CONS=20,STACK_RES=50;
const BAGS={
  musette:{n:'Musette en toile rustique',slots:4,rar:0,d:'Sac de départ.',src:'Marchande (100 or), quête de niveau 5'},
  sacoche:{n:'Sacoche en cuir renforcé',slots:8,rar:1,d:'Le sac courant des farmeurs.',src:'Forgeron-embaumeur niv. 15'},
  besace:{n:'Besace du voyageur d’ombre',slots:12,rar:2,light:.1,d:'Réduit de 10 % le poids des objets transportés.',src:'Butin rare des élites niv. 25–35'},
  runique:{n:'Sacoche runique',slots:14,rar:2,safe:1,d:'Inviolable en PvP : son contenu ne tombe pas à la mort.',src:'Intendant des Cornes de Bravoure'},
  abime:{n:'Grand sac de l’Abîme',slots:16,rar:3,d:'Le sac ultime de fin de jeu.',src:'Gardiens du Phare (étage 4+), maître artisan'}};
SLOT_N.sac='Sac';ITEM_KG.sac=.5;
for(const k in BAGS)CONS['bag_'+k]={n:BAGS[k].n+' (+'+BAGS[k].slots+')',d:BAGS[k].d,price:0};
const isVirtual=k=>k.startsWith('comp_')||k.startsWith('lettre_')||k.startsWith('bag_');
function mkBag(kind,owner){const o=owner||P,B=BAGS[kind];const it={id:o.uid++,type:'sac',bag:kind,tier:0,rar:B.rar,plus:0,dur:100,bon:{}};if(kind==='runique')it.fac=o.fac;return it;}

/* ---------- capacité ---------- */
const bagOk=b=>b&&b.dur>0;
function invCap(){return POCKET+(P.bags||[]).reduce((a,b)=>a+(bagOk(b)?BAGS[b.bag].slots:0),0);}
function consSlots(k,n){if(!(n>0)||isVirtual(k))return 0;return k.startsWith('livre_')?n:Math.ceil(n/STACK_CONS);}
function invUsed(){let u=P.inv.length;for(const [k,n] of Object.entries(P.cons||{}))u+=consSlots(k,n);for(const n of Object.values(P.res||{}))if(n>0)u+=Math.ceil(n/STACK_RES);return u;}
function invFull(n){return invUsed()+(n==null?1:n)>invCap();}
function roomFor(kind,k,q){if(kind==='res'){const a=P.res[k]||0;return Math.ceil((a+q)/STACK_RES)-Math.ceil(a/STACK_RES);}const a=P.cons[k]||0;return consSlots(k,a+q)-consSlots(k,a);}
function fullMsg(x,y){addText(x!=null?x:P.x,(y!=null?y:P.y)-30,'Sac plein','#ff8a8a');}

/* ---------- poids et encombrement ---------- */
const _stats3=stats;stats=function(){const S=_stats3();S.pods=Math.round(50+S.a.for*2+S.a.con);return S;};
const _invWeight=invWeight;invWeight=function(){let w=_invWeight();for(const b of P.bags||[])if(bagOk(b)&&BAGS[b.bag].light)w*=1-BAGS[b.bag].light;return Math.round(w*10)/10;};
function encRatio(){return invWeight()/Math.max(1,stats().pods);}
function encState(){const r=encRatio();return r>=1?2:r>.75?1:0;}
function encMv(){return[1,.8,.5][encState()];}
function encMp(){return encState()?1.5:1;}
function canTP(){if(encState()===2){toast('Encombré','Impossible de te téléporter au-delà de 100 % de ta charge : allège ton sac');return false;}return true;}

/* ---------- ramassage, récolte, butin ---------- */
pickBag=function(b,byPet){const F=P.petF||{};let any=false,full=false;
  if(b.gold&&(!byPet||F.gold)){P.gold+=b.gold;addText(b.x,b.y-10,'+'+b.gold+' or','#f2c14e');b.gold=0;any=true;}
  for(const k of Object.keys(b.cons)){if(byPet&&!F.cons)continue;let q=b.cons[k];if(invUsed()+roomFor('cons',k,q)>invCap()){let fit=0;while(fit<q&&invUsed()+roomFor('cons',k,fit+1)<=invCap())fit++;full=true;if(!fit)continue;q=fit;}
    P.cons[k]=(P.cons[k]||0)+q;b.cons[k]-=q;if(b.cons[k]<=0)delete b.cons[k];addText(b.x,b.y-18,CONS[k].n,'#ffd0a0');if(k.startsWith('livre')||k.startsWith('ench'))chat(null,'Obtenu : '+CONS[k].n);any=true;}
  for(const k of Object.keys(b.res)){if(byPet&&!F.res)continue;let q=b.res[k];if(invUsed()+roomFor('res',k,q)>invCap()){let fit=0;while(fit<q&&invUsed()+roomFor('res',k,fit+1)<=invCap())fit++;full=true;if(!fit)continue;q=fit;}
    P.res[k]=(P.res[k]||0)+q;b.res[k]-=q;if(b.res[k]<=0)delete b.res[k];addText(b.x,b.y-14,'+'+q+' '+RES[k].n,'#d8e8c0');any=true;}
  b.items=b.items.filter(it=>{if(byPet&&it.type!=='sac'&&(!F.eq||it.rar<F.min))return true;if(invFull()){full=true;return true;}P.inv.push(it);any=true;chat(null,'Obtenu : '+itemName(it)+' ('+RAR[it.rar]+')');addText(b.x,b.y-22,itemName(it),RARC[it.rar]);return false;});
  if(full&&!b.full){b.full=1;fullMsg();}return any;};
const _startHarvest2=startHarvest;startHarvest=function(n){if(invUsed()+roomFor('res',n.res,2)>invCap()){toast('Sac plein','Plus de place pour '+RES[n.res].n+' : vide ton sac en ville ou équipe un sac plus grand');return;}_startHarvest2(n);};
const _dropLoot3=dropLoot;dropLoot=function(m,near){const n0=bags.length;_dropLoot3(m,near);if(!m.tag||m.team)return;let bag=null;
  if(m.elite&&m.lv>=25&&m.lv<=35&&rnd()<.04)bag='besace';
  if(m.t.boss&&dgRun&&dgRun.dg==='phare'&&dgRun.floor>=4&&rnd()<.15)bag='abime';
  if(m.t.boss&&!m.t.wb&&m.lv>=10&&m.lv<=25&&!dgRun&&rnd()<.08)bag='sacoche';
  if(bag){const b=bags[bags.length-1]&&bags.length>n0?bags[bags.length-1]:null,it=mkBag(bag);if(b&&b.items)b.items.push(it);else bags.push({x:m.x,y:m.y+6,items:[it],cons:{},res:{},gold:0,t:120,owner:'p'});chat(null,'Butin rare : '+BAGS[bag].n+' !');}};

/* ---------- équiper un sac ---------- */
const _itemName=itemName;itemName=function(it){if(it.type==='sac')return BAGS[it.bag].n+(it.bag==='runique'?' '+FACTIONS[it.fac||P.fac].n:'');return _itemName(it);};
const _statTxt=statTxt;statTxt=function(it){if(it.type==='sac'){const B=BAGS[it.bag];return'+'+B.slots+' emplacements · '+B.d+(it.dur<=0?' · PERCÉ : emplacements verrouillés, à réparer':' · durabilité '+it.dur+' %');}return _statTxt(it);};
const _canEquip=canEquip;canEquip=function(it){if(it.type==='sac'){if(it.bag==='runique'&&it.fac&&it.fac!==P.fac)return'Sacoche d’une autre faction';return null;}return _canEquip(it);};
const _equip=equip;equip=function(it){if(it.type!=='sac')return _equip(it);P.bags=P.bags||[null,null];let j=P.bags.findIndex(b=>!b);
  if(j<0){j=BAGS[P.bags[0].bag].slots<=BAGS[P.bags[1].bag].slots?0:1;const old=P.bags[j];P.inv=P.inv.filter(i=>i!==it);P.bags[j]=it;if(invUsed()+1>invCap()){P.bags[j]=old;P.inv.push(it);toast('Pas assez de place','Le sac remplacé ne tiendrait plus dans l’inventaire');return;}P.inv.push(old);return;}
  P.inv=P.inv.filter(i=>i!==it);P.bags[j]=it;toast(BAGS[it.bag].n+' équipé','+'+BAGS[it.bag].slots+' emplacements');};
function unequipBag(j){const b=P.bags[j];if(!b)return'';const cap=invCap()-(bagOk(b)?BAGS[b.bag].slots:0);if(invUsed()+1>cap)return'Vide d’abord le contenu de ce sac : il ne tiendrait plus dans ton inventaire.';P.bags[j]=null;P.inv.push(b);return'Sac retiré.';}

/* ---------- mort : pertes en zone contestée, usure des sacs ---------- */
const _die2=die;die=function(src){if(P.hc||(EV.bf&&curId()==='bf_vallee'))return _die2(src);const lost=[];
  const wild=!!(M.def&&M.def.pvp)&&M.kind!=='dungeon',drop={cons:{},res:{},items:[]};
  if(wild){const safeB=(P.bags||[]).find(b=>bagOk(b)&&BAGS[b.bag].safe);let prot=safeB?BAGS[safeB.bag].slots:0;
    const stacks=Object.entries(P.res).filter(([,n])=>n>0).sort((a,b)=>(RES[b[0]].tier-RES[a[0]].tier)||(b[1]-a[1]));
    for(const [k,n] of stacks){const sl=Math.ceil(n/STACK_RES);if(prot>=sl){prot-=sl;continue;}const q=Math.max(1,Math.round(n*rr(.15,.3)));P.res[k]-=q;drop.res[k]=q;lost.push(q+' '+RES[k].n);}
    for(const [k,n] of Object.entries(P.cons)){if(!(n>0)||isVirtual(k)||k.startsWith('livre_'))continue;const sl=consSlots(k,n);if(prot>=sl){prot-=sl;continue;}if(rnd()<.1){const q=Math.max(1,Math.round(n*.1));P.cons[k]-=q;lost.push(q+' '+CONS[k].n+' (détruit)');}}
    if(P.pkT>0||P.pk>0)for(const [k,n] of Object.entries(P.cons))if(k.startsWith('livre_')&&n>0&&rnd()<.05){P.cons[k]--;drop.cons[k]=1;lost.push(CONS[k].n);}
    if(Object.keys(drop.res).length||Object.keys(drop.cons).length)bags.push({x:P.x,y:P.y+4,items:[],cons:drop.cons,res:drop.res,gold:0,t:300,owner:'all',defeat:1});}
  for(const b of P.bags||[])if(b&&b.dur>0){b.dur=Math.max(0,b.dur-5);if(b.dur===0){lost.push(BAGS[b.bag].n+' percé');chat(null,'Ton '+BAGS[b.bag].n.toLowerCase()+' est percé : ses emplacements sont verrouillés jusqu’à réparation.');}}
  let over=invUsed()-invCap(),fell=[];while(over>0&&P.inv.length){const it=P.inv.pop();fell.push(it);over--;}
  if(fell.length){bags.push({x:P.x+6,y:P.y+6,items:fell,cons:{},res:{},gold:0,t:300,owner:'all'});lost.push(fell.length+' objet(s) tombé(s) du sac percé');}
  if(lost.length)setTimeout(()=>chat(null,'Sac d’insigne de défaite : '+lost.join(', ')+'.'),50);
  return _die2(src);};
const _repairCost=repairCost;repairCost=function(){let c=_repairCost();for(const b of P.bags||[])if(b)c+=(100-b.dur)*(BAGS[b.bag].rar+1)*1.5;return Math.round(c);};
const _repairAll=repairAll;repairAll=function(){const c=repairCost(),base=_repairCost();if(P.gold<c)return false;if(!_repairAll())return false;P.gold-=c-base;for(const b of P.bags||[])if(b)b.dur=100;for(const it of P.inv)if(it.type==='sac')it.dur=100;return true;};
const _useCons3=useCons;useCons=function(k){
  if(k==='retour'&&!canTP())return;
  if(k==='kit'&&P.cons.kit>0){const br=(P.bags||[]).filter(b=>b&&b.dur<100);if(br.length&&(!P.eq.arme||P.eq.arme.dur>=100)){P.cons.kit--;for(const b of br)b.dur=Math.min(100,b.dur+30);toast('Sacs rapiécés','+30 % de durabilité');return;}}
  return _useCons3(k);};
const _joinInv=joinInv;joinInv=function(){if(!canTP())return;_joinInv();};

/* ---------- autres sources : marchande, quête niv. 5, artisanat, cornes, maître artisan ---------- */
RECIPES.push({id:'r_sac',prof:'runesmith',lvl:15,out:{cons:'bag_sacoche',n:1},ing:{cuir:10,fer:6,velin:1},xp:60,rate:.85,st:'enclume'});
MASTER.push({id:'m_sac',n:'Grand sac de l’Abîme',lvl:40,ing:{cuir:20,essence:8,poussiere:12,peaurare:3},gold:12000,out:'sac',bag:'abime'});
const _craftFinish=craftFinish;craftFinish=function(rc){if(!rc.out.cons.startsWith('bag_'))return _craftFinish(rc);if(invFull())return'Échec : sac plein, impossible de ranger le nouveau sac.';
  const r=_craftFinish(Object.assign({},rc,{out:{cons:'__bag',n:0}}));if(r.startsWith('Échec'))return r;delete P.cons.__bag;const it=mkBag(rc.out.cons.slice(4));it.by=P.name;P.inv.push(it);return itemName(it);};
CONS.__bag={n:'',d:'',price:0};
const _masterCraft=masterCraft;masterCraft=function(id){const R=MASTER.find(x=>x.id===id);if(!R||!R.bag)return _masterCraft(id);if(masterWhy(R))return'';for(const [k,q] of Object.entries(R.ing)){if(RES[k])P.res[k]-=q;else P.cons[k]-=q;}P.gold-=R.gold;const it=mkBag(R.bag);it.by=npcName('craft');P.inv.push(it);return'Reçu : <span style="color:'+RARC[it.rar]+'">'+esc(itemName(it))+'</span>';};
const _masterWhy=masterWhy;masterWhy=function(R){return _masterWhy(R)||(invFull()?'Sac plein':null);};
const _qTurnIn=qTurnIn;qTurnIn=function(id){const r=_qTurnIn(id);if(id==='M6'&&r!==null&&!P.ev.bagM6){P.ev.bagM6=1;P.inv.push(mkBag('musette'));toast('Récompense : '+BAGS.musette.n,'Équipe-la depuis ton sac : +4 emplacements');}return r;};
const _genMarket2=genMarket;genMarket=function(){_genMarket2();const names=BOT_NAMES[P.fac];for(const [k,p] of [['sacoche',900],['besace',6000],['abime',40000]])if(rnd()<(k==='abime'?.25:.6))MARKET.push({id:'bag_'+k,seller:pick(names),item:mkBag(k),price:Math.round(p*rr(.9,1.6))});};
EXTRA_ACT.bagbuy=()=>{if(P.gold<100){panelMsg='Pas assez d’or.';return;}if(invFull()){panelMsg='Sac plein.';return;}P.gold-=100;P.inv.push(mkBag('musette'));panelMsg='Musette achetée : équipe-la depuis ton sac.';};
EXTRA_ACT.hornbag=()=>{if((P.ev.horns||0)<60){panelMsg='Il faut 60 Cornes de Bravoure.';return;}if(invFull()){panelMsg='Sac plein.';return;}P.ev.horns-=60;P.inv.push(mkBag('runique'));panelMsg='Sacoche runique reçue.';};
EXTRA_ACT.bagoff=v=>{panelMsg=esc(unequipBag(+v));};
EXTRA_ACT.drop=(v,b)=>{const id=+b.dataset.id,it=P.inv.find(i=>i.id===id);if(it){P.inv=P.inv.filter(i=>i!==it);bags.push({x:P.x,y:P.y+8,items:[it],cons:{},res:{},gold:0,t:120,owner:'p'});panelMsg='Jeté au sol : '+esc(itemName(it));}};
EXTRA_ACT.dropc=(v,b)=>{const kind=b.dataset.k,src=kind==='res'?P.res:P.cons,n=Math.min(src[v]||0,kind==='res'?STACK_RES:STACK_CONS);if(n>0){src[v]-=n;const o={x:P.x,y:P.y+8,items:[],cons:{},res:{},gold:0,t:120,owner:'p'};o[kind==='res'?'res':'cons'][v]=n;bags.push(o);panelMsg='Pile jetée au sol.';}};

/* ---------- alerte de charge ---------- */
let _encLast=0;const _update4=update;update=function(dt){_update4(dt);const e=encState();if(e!==_encLast){if(e>_encLast)toast(e===2?'Encombré (100 %+)':'Surcharge (plus de 75 %)',e===2?'Déplacement −50 %, téléportation impossible':'Déplacement −20 %, sorts +50 % de PM');_encLast=e;}};

/* ---------- panneau du sac ---------- */
function bagPanelHead(s){const w=invWeight(),r=w/s.pods,e=encState();
  let h=`<div class="invbar"><div><b>Emplacements</b> ${invUsed()} / ${invCap()}${bar(invUsed()/invCap(),invUsed()>=invCap()?'#ff7a5a':'#9be36a')}</div><div><b>Poids</b> ${w} / ${s.pods} kg${bar(r,e===2?'#ff5a5a':e?'#f2c14e':'#7fd4ff')}</div></div>`;
  h+=`<p class="sub">${e===2?'<b style="color:#ff7a7a">Encombré</b> : déplacement −50 %, pas de téléportation. ':e?'<b style="color:#f2c14e">Surcharge</b> : déplacement −20 %, sorts +50 % PM. ':''}Poche 12 · consommables par 20 · matériaux par 50 · équipement et grimoires 1 par case · monnaies hors inventaire. ${P.gold} or.</p><div class="bagslots">`;
  for(let j=0;j<2;j++){const b=(P.bags||[])[j];h+=b?`<div class="bslot"><b style="color:${RARC[b.rar]}">${esc(itemName(b))}</b><small>+${BAGS[b.bag].slots} · ${b.dur>0?'durabilité '+b.dur+' %':'<span style="color:#ff7a7a">percé</span>'}</small>${B('bagoff','Retirer',`data-v="${j}"`)}</div>`:`<div class="bslot empty"><b>Sac secondaire ${j+1}</b><small>vide · la marchande vend une musette (+4)</small></div>`;}
  return h+'</div>';}
