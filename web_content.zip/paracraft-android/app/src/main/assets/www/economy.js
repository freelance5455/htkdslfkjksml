/* ================== Paracraft Online · équipement, enchantement, métiers hardcore ==================
   Document « Équipement, Enchantement et Économie » : 8 emplacements, armures par classe, 4 raretés,
   parchemins d'arme / d'armure +1 à +10 avec destruction, poussière d'enchantement, artisans de cité.
   Document « Métiers Hardcore v2 » : Alchimiste de guerre, Scribe des runes, Forgeron-embaumeur,
   récolte en zone contestée, échecs, canalisation, poids en kg. */

const EC={cap:3,allowLeg:true,magic:false,pvp:false};

/* ---------- emplacements, raretés ---------- */
SLOTS.length=0;SLOTS.push('arme','casque','armure','gants','bottes','collier','anneau','cape');
Object.assign(SLOT_N,{cape:'Cape de faction',anneau:'Anneau'});
RAR.length=0;RAR.push('Normal','Rare','Épique','Légendaire');
RARC.length=0;RARC.push('#d8d4cc','#7fd4ff','#c58cff','#ffb84a');
RARM.length=0;RARM.push(1,1.25,1.55,2);
LOOT_TYPES.length=0;LOOT_TYPES.push('arme','casque','armure','gants','bottes','collier','anneau');
const ARMOR_T=['casque','armure','gants','bottes'];
const ARMN={guerrier:{n:'Armure lourde',casque:['Heaume','Casque à nasal','Grand heaume'],armure:['Cuirasse','Harnois','Plastron'],gants:['Gantelets','Poings de plates'],bottes:['Solerets','Grèves']},
  archer:{n:'Armure de cuir',casque:['Capuche','Coiffe de cuir'],armure:['Brigandine','Veste de cuir','Gilet de traqueur'],gants:['Mitaines','Gants d’archer'],bottes:['Bottes souples','Bottes de pisteur']},
  mage:{n:'Robe de tissu',casque:['Chapeau','Capuchon','Diadème'],armure:['Robe','Tunique runique','Manteau d’arcane'],gants:['Gants de soie','Manchettes'],bottes:['Sandales','Chausses']}};
const PRIM=['for','dex','int','con','sag'],SECO=['crit','hit','dodge','critd','mres','dr','mv','aspd'];
Object.assign(BONUS_N,{crit:'Critique %',hit:'Précision %',dodge:'Esquive %',critd:'Dégâts critiques %',mres:'Résistance magique %',dr:'Réduction de dégâts %',mv:'Vitesse de déplacement %',aspd:'Vitesse d’attaque %',mp:'PM',regen:'Régénération %',pvp:'Dégâts vs faction ennemie %',pvpres:'Résistance PvP %'});
const LEG={vampire:{n:'Soif de sang',d:'4 % des dégâts infligés rendus en PV'},colosse:{n:'Colosse',d:'PV max +8 %'},celerite:{n:'Célérité',d:'Déplacement +12 %'},arcane:{n:'Cœur arcanique',d:'Régénération de PM +25 %, dégâts des sorts +5 %'},predateur:{n:'Prédateur',d:'Critique +3 %, dégâts critiques +15 %'}};
const ITEM_KG={arme:4,casque:2,armure:6,gants:1,bottes:2,collier:.3,anneau:.1,cape:1,second:2};

/* ---------- consommables, ressources, métiers ---------- */
Object.assign(CONS.pv,{n:'Potion de vie (PNJ)',d:'Rend 30 % des PV. Recharge 15 s.'});Object.assign(CONS.pm,{n:'Potion de mana (PNJ)',d:'Rend 30 % des PM. Recharge 15 s.'});
Object.assign(CONS.retour,{n:'Parchemin de retour de faction',d:'Canalisation de 4 s sans subir de coup, puis retour à ta capitale.'});
const SCR=[['I','+1 à +3',60],['II','+4 à +7',400],['III','+8 à +10',2500]];
SCR.forEach(([g,r,p],i)=>{CONS['ench'+(i+1)]={n:'Parchemin d’arme '+g,d:'Enchante une arme de '+r+' (ATK / MATK).',price:p};CONS['encha'+(i+1)]={n:'Parchemin d’armure '+g,d:'Enchante une armure, un bijou ou une cape de '+r+' (DEF et PV).',price:p};});
Object.assign(CONS,{
  poussiere:{n:'Poussière d’enchantement',d:'Reste d’un objet détruit ou démantelé. Composant de craft.',price:40},
  essence:{n:'Essence arcanique',d:'Extraite d’un objet rare ou mieux. Composant des pièces légendaires.',price:120},
  fraggrim:{n:'Fragment de grimoire',d:'Le Scribe en combine 3 pour tenter de restaurer un grimoire scellé.',price:60},
  velin:{n:'Vélin vierge',d:'Support de tous les parchemins d’enchantement.',price:50},
  elurg1:{n:'Élixir d’urgence mineur',d:'Rend 150 PV instantanément. Recharge 5 s.',price:30},
  elurg:{n:'Élixir d’urgence',d:'Rend 350 PV instantanément. Recharge 5 s.',price:90},
  flux1:{n:'Fiole de flux mineure',d:'Rend 100 PM instantanément. Recharge 5 s.',price:30},
  flux:{n:'Fiole de flux',d:'Rend 250 PM instantanément. Recharge 5 s.',price:90},
  huile:{n:'Huile de dissimulation',d:'Portée d’agression des monstres −50 % pendant 3 min.',buff:{id:'huile',n:'Dissimulation',hide:.5,t:180},price:150},
  affut:{n:'Pierre d’affûtage',d:'+5 % de dégâts physiques pendant 15 min ou 200 coups.',buff:{id:'affut',n:'Affûtage',atk:.05,t:900,hits:200},price:60},
  fleches:{n:'Flèches perçantes',d:'Archer : +10 % de précision. Une flèche par tir.',price:1},
  kit:{n:'Kit de réparation de terrain',d:'Restaure 30 % de la durabilité de ton arme, n’importe où.',price:200},
  enclume:{n:'Enclume portative',d:'Permet au Forgeron-embaumeur de travailler hors des cités.',price:250},
});
const CONS_KG=k=>k==='elurg'||k==='flux'||k==='elurg1'||k==='flux1'?1.5:k==='fleches'?.02:k==='kit'?2:k==='enclume'?6:k==='affut'?.5:k.startsWith('livre_')?.5:k==='pv'||k==='pm'?.3:.1;
Object.assign(RES,{
  moussesang:{n:'Mousse de sang',prof:'herboriste',lvl:20,tier:2,pvp:1},racarcane:{n:'Racine d’arcane',prof:'herboriste',lvl:28,tier:3,pvp:1},champcav:{n:'Champignon des cavernes',prof:'herboriste',lvl:35,tier:3,pvp:1},
  fernoir:{n:'Fer noir',prof:'mineur',lvl:20,tier:2,pvp:1,glow:1},quartzombre:{n:'Quartz d’ombre',prof:'mineur',lvl:28,tier:3,pvp:1,glow:1},
  cuir:{n:'Cuir brut',prof:null,lvl:1,tier:0,drop:1},pigment:{n:'Pigment de boss',prof:null,lvl:1,tier:3,drop:1},peaurare:{n:'Peau rare du Phare',prof:null,lvl:1,tier:3,drop:1},
});
for(const k of ['forgeron','armurier','bijoutier','cuisinier'])delete PROFS[k];
Object.assign(PROFS,{
  alchimiste:{n:'Alchimiste de guerre',k:'c',d:'Élixirs d’urgence, fioles de flux, huiles. Aux alambics des camps ; recettes de haut niveau seulement en zone contestée.'},
  scribe:{n:'Scribe des runes',k:'c',d:'Vélins, parchemins d’enchantement, retour de faction, restauration de grimoires. Au pupitre, 10 s d’incantation immobile.'},
  runesmith:{n:'Forgeron-embaumeur',k:'c',d:'Pierres d’affûtage, flèches perçantes, kits de réparation. À la forge des cités ou sur une enclume portative.'}});
RECIPES.length=0;
{const R=(id,prof,lvl,out,n,ing,o)=>RECIPES.push(Object.assign({id,prof,lvl,out:{cons:out,n},ing,xp:12+lvl*3,rate:1},o||{}));
  R('a_urg1','alchimiste',1,'elurg1',2,{ortie:3},{rate:.95,st:'alambic'});
  R('a_flux1','alchimiste',5,'flux1',2,{ortie:2,sauge:1},{rate:.95,st:'alambic'});
  R('a_elxp','alchimiste',12,'elxp',1,{sauge:3,trefle:1},{rate:.9,st:'alambic'});
  R('a_urg','alchimiste',20,'elurg',2,{trefle:2,moussesang:1},{rate:.8,st:'alambic',hi:1,rare:'moussesang'});
  R('a_flux','alchimiste',25,'flux',2,{trefle:1,racarcane:1},{rate:.75,st:'alambic',hi:1,rare:'racarcane'});
  R('a_huile','alchimiste',30,'huile',1,{mandragore:2,champcav:1},{rate:.65,st:'alambic',hi:1,rare:'champcav'});
  R('a_elatk','alchimiste',35,'elatk',1,{mandragore:2,moussesang:2},{rate:.7,st:'alambic',hi:1,rare:'moussesang'});
  R('s_velin','scribe',1,'velin',1,{cuir:2,ortie:1},{rate:.6,st:'pupitre',chan:1});
  R('s_ret','scribe',6,'retour',1,{velin:1,sauge:1},{rate:.9,st:'pupitre',chan:1});
  R('s_e1','scribe',8,'ench1',1,{velin:1,fer:2},{rate:.85,st:'pupitre',chan:1});
  R('s_ea1','scribe',8,'encha1',1,{velin:1,sauge:2},{rate:.85,st:'pupitre',chan:1});
  R('s_grim','scribe',18,'grimoire',1,{fraggrim:3,peaurare:1},{rate:.35,st:'pupitre',chan:1});
  R('s_e2','scribe',22,'ench2',1,{velin:1,poussiere:2,mithril:2},{rate:.75,st:'pupitre',chan:1});
  R('s_ea2','scribe',22,'encha2',1,{velin:1,poussiere:2,trefle:2},{rate:.75,st:'pupitre',chan:1});
  R('s_e3','scribe',38,'ench3',1,{velin:2,poussiere:5,pigment:1},{rate:.6,st:'pupitre',chan:1});
  R('s_ea3','scribe',38,'encha3',1,{velin:2,poussiere:5,peaurare:1},{rate:.6,st:'pupitre',chan:1});
  R('r_fl','runesmith',1,'fleches',50,{frene:2,fer:1},{rate:.95,st:'enclume'});
  R('r_aff','runesmith',8,'affut',1,{fer:3,cristal:1},{rate:.9,st:'enclume'});
  R('r_kit','runesmith',16,'kit',1,{mithril:2,cuir:2},{rate:.85,st:'enclume'});
  R('r_aff2','runesmith',24,'affut',3,{fernoir:2,cristal:2},{rate:.8,st:'enclume'});
  R('r_kit2','runesmith',32,'kit',2,{quartzombre:1,fernoir:2,cuir:3},{rate:.75,st:'enclume'});}
const MASTER=[{id:'m_cape',n:'Cape de faction',lvl:21,ing:{cuir:6,essence:2,poussiere:3},gold:1500,honor:300,out:'cape'},
  ...['arme','armure','casque','gants','bottes','collier','anneau'].map(t=>({id:'m_'+t,n:'Pièce légendaire : '+SLOT_N[t],lvl:30,ing:{poussiere:10,essence:5,fernoir:3,quartzombre:3,cuir:4},gold:4000,out:t,leg:1}))];

/* ---------- objets ---------- */
mkItem=function(owner,type,tier,rar,cls){const o=owner||P;rar=rar>=4?3:Math.min(rar,EC.cap);if(rar===3&&!EC.allowLeg)rar=2;
  const it={id:o.uid++,type,tier:clamp(tier,0,9),rar,plus:0,dur:100,bon:{}};
  if(type==='arme'||ARMOR_T.includes(type))it.cls=cls||pick(Object.keys(CLASSES));
  if(type==='cape')it.fac=o.fac||P.fac;
  const t=it.tier,pv=()=>ri(1+t,3+t*2),sv=k=>k==='critd'?ri(4,8+t):k==='mres'||k==='dr'?ri(2,3+Math.floor(t/2)):k==='mv'||k==='aspd'?ri(2,4+Math.floor(t/3)):ri(1,2+Math.floor(t/2));
  const nP=[0,ri(1,2),ri(2,3),4][rar],nS=rar===2?1:rar===3?ri(1,2):0;
  const prim=type==='anneau'?(it.cls==='mage'||rnd()<.33?['int','sag']:['for','dex','con']):type==='collier'?['sag','int','con']:it.cls==='guerrier'?['for','con','dex']:it.cls==='archer'?['dex','for','con']:it.cls==='mage'?['int','sag','con']:PRIM;
  for(let k=0;k<nP;k++){const b=k<2?prim[k%prim.length]:pick(PRIM);it.bon[b]=(it.bon[b]||0)+pv();}
  for(let k=0;k<nS;k++){const b=pick(SECO);it.bon[b]=(it.bon[b]||0)+sv(b);}
  if(rar===3)it.leg=pick(Object.keys(LEG));
  return it;};
itemName=function(it){if(it.type==='cape')return'Cape de '+FACTIONS[it.fac||P.fac].n+(it.plus?' +'+it.plus:'');let arr;
  if(ARMOR_T.includes(it.type)&&it.cls)arr=ARMN[it.cls][it.type];else{const b=BASEN[it.type];arr=(it.type==='arme'||it.type==='second')?b[it.cls]:b;}
  return(it.rar===3&&it.leg?LEG[it.leg].n+' : ':'')+arr[it.tier%arr.length]+' '+MATS[it.tier]+(it.plus?' +'+it.plus:'');};
const isWeapon=it=>it.type==='arme';
itemStats=function(it){if(it.dur<=0)return{};const q=TIER_REQ[it.tier],R=RARM[it.rar]||1,p=it.plus,t=it.tier,s={},r=v=>Math.round(v);
  const ew=p*(3+Math.round(t*5/9)),ea=p*(1+Math.round(t*.4)),eh=p*(4+t*3),cl=it.cls,heavy=cl==='guerrier',cloth=cl==='mage';
  switch(it.type){
    case'arme':s.atk=r((6+q*1.7)*R)+ew;s.crit=cl==='archer'?2:1;break;
    case'casque':s.def=r((1+q*.35)*R*(heavy?1.3:cloth?.6:1))+ea;s.hp=r((5+q*4)*R)+eh;s.mres=cloth?4+Math.floor(t/2):1;break;
    case'armure':s.def=r((2+q*.8)*R*(heavy?1.4:cloth?.55:1))+ea;s.hp=r((10+q*7)*R*(heavy?1.2:1))+eh;s.mp=r((6+q*4)*R*(cloth?1.6:.6));s.dr=heavy?2+Math.floor(t/3):1;if(cloth)s.mres=6+t;if(cl==='archer')s.dodge=2;break;
    case'gants':s.def=r((.5+q*.2)*R)+ea;s.hit=2+Math.floor(t/2);s.aspd=2+Math.floor(t/3);break;
    case'bottes':s.def=r((1+q*.3)*R*(heavy?1.2:1))+ea;s.mv=3+Math.floor(t/2);s.dodge=1+Math.floor(t/3);break;
    case'collier':s.hp=r((6+q*4)*R)+eh;s.regen=5+t;s.critd=3+t;break;
    case'anneau':s.hp=r((3+q*2)*R)+eh;s.mp=r((4+q*3)*R);break;
    case'cape':s.hp=r((8+q*5)*R)+eh;s.def=ea;s.pvp=3+Math.floor(t/2)+Math.floor(p/2);s.pvpres=3+Math.floor(t/2)+Math.floor(p/2);break;
    case'second':break;}
  return s;};
Object.assign(STAT_LBL,{crit:'Crit %',mres:'Rés. mag. %',dr:'Réduc. %',hit:'Préc. %',aspd:'Vit. atq %',mv:'Vit. %',dodge:'Esq. %',regen:'Régén. %',critd:'Dégâts crit %',pvp:'PvP %',pvpres:'Rés. PvP %'});
statTxt=function(it){if(it.type==='second')return'Objet obsolète : la main gauche n’existe plus. Vends-le ou démantèle-le.';if(it.dur<=0)return'Cassé : à réparer chez le forgeron';
  const a=Object.entries(itemStats(it)).filter(([,v])=>v).map(([k,v])=>STAT_LBL[k]+' +'+v);for(const [k,v] of Object.entries(it.bon||{}))a.push(BONUS_N[k]+' +'+v);
  if(it.leg)a.push('★ '+LEG[it.leg].d);if(ARMOR_T.includes(it.type)&&it.cls)a.unshift(ARMN[it.cls].n);return a.join(' · ');};
canEquip=function(it){if(it.type==='second')return'La main gauche n’existe plus : cet objet est obsolète';if(P.lvl<TIER_REQ[it.tier])return'Niveau '+TIER_REQ[it.tier]+' requis';
  if(it.cls&&it.cls!==P.cls)return(ARMOR_T.includes(it.type)?ARMN[it.cls].n+' : réservée à la classe ':'Réservé à la classe ')+CLASSES[it.cls].nom;
  if(it.type==='cape'&&it.fac!==P.fac)return'Cape d’une autre faction';return null;};
slotFor=function(it){return it.type;};
itemValue=function(it){return Math.round(8*(it.tier+1)*(it.tier+1)*(it.rar+1)*(it.rar+1)*(1+it.plus*.6));};

/* ---------- caractéristiques : bonus secondaires de l'équipement ---------- */
const _stats=stats;stats=function(){const S=_stats();const x={crit:0,hit:0,dodge:0,critd:0,mres:0,dr:0,mv:0,aspd:0,regen:0,pvp:0,pvpres:0,mp:0};let legs={};
  for(const sl of SLOTS){const it=P.eq[sl];if(!it||it.dur<=0)continue;const s=itemStats(it);for(const k in x){if(k==='mp')continue;x[k]+=s[k]||0;}
    for(const [k,v] of Object.entries(it.bon||{}))if(k in x&&k!=='crit')x[k]+=v;x.mp+=(it.bon||{}).mp||0;if(it.leg)legs[it.leg]=1;
    if(it.type==='armure'&&it.cls==='guerrier')x.dodge-=3;}
  for(const b of P.buffs){if(b.pvp)x.pvpres+=b.pvp*100;}
  if(legs.colosse)S.maxhp=Math.round(S.maxhp*1.08);if(legs.celerite)x.mv+=12;if(legs.arcane){S.mreg*=1.25;S.matk*=1.05;if(P.cls==='mage')S.atk=Math.round(S.atk*1.05);}if(legs.predateur){x.crit+=3;x.critd+=15;}
  S.crit=Math.min(60,S.crit+x.crit);S.hit=Math.min(99,S.hit+x.hit);S.dodge=clamp(S.dodge+x.dodge,0,45);S.critd=.6+x.critd/100;S.mres=Math.min(.6,x.mres/100);
  S.dr=Math.min(.8,(S.dr||0)+x.dr/100);S.mv=1+x.mv/100;S.aspd=Math.max(.6,S.aspd*(1-x.aspd/100));S.mreg*=1+x.regen/100;S.regen*=1+x.regen/200;S.pvp=x.pvp/100;S.pvpres=Math.min(.5,x.pvpres/100);S.legs=legs;
  S.maxmp+=x.mp;S.pods=Math.round(40+S.a.for*1.2+P.lvl*.6);return S;};
invWeight=function(){let w=0;for(const it of P.inv)w+=ITEM_KG[it.type]||1;for(const sl of SLOTS)if(P.eq[sl])w+=(ITEM_KG[P.eq[sl].type]||1)*.5;
  for(const [k,v] of Object.entries(P.res||{}))w+=v*(RES[k]&&RES[k].prof==='mineur'?1:.4);for(const [k,v] of Object.entries(P.cons||{}))w+=CONS_KG(k)*v;return Math.round(w*10)/10;};

/* ---------- combat : critique, vol de vie, résistances, flèches, affûtage ---------- */
const _pdmg=pdmg;pdmg=function(t,mult,o){const s=stats();o=Object.assign({},o||{});
  if(P.cls==='archer'&&P.cons.fleches>0&&!o.noArrow){P.cons.fleches--;if(!o.sure&&rnd()<.1)o.sure=1;}
  const r=_pdmg(t,mult,o);if(r.miss)return r;if(r.crit)r.d=Math.round(r.d/1.6*(1+s.critd));if(t.kind==='b'&&t.fac!==P.fac)r.d=Math.round(r.d*(1+s.pvp));
  const af=P.buffs.find(b=>b.id==='affut');if(af){af.hits=(af.hits==null?200:af.hits)-1;if(af.hits<=0)af.t=0;}
  if(s.legs.vampire){const h=Math.max(1,Math.round(r.d*.04));P.hp=Math.min(s.maxhp,P.hp+h);}return r;};
const _hurtPlayer=hurtPlayer;hurtPlayer=function(d,src){if(state!=='play'||P.inv0>0||P.hp<=0)return;const s=stats();
  if(EC.magic)d*=1-s.mres;if(EC.pvp)d*=1-s.pvpres;
  if(P.chan){const c=P.chan;P.chan=null;toast(c.n+' interrompu',c.k==='craft'?'Le coup a brisé ta concentration : les matériaux sont perdus':'Tu as été frappé pendant la canalisation');if(c.k==='craft')consumeIng(c.rc,true);}
  return _hurtPlayer(d,src);};
const _botAttack2=botAttack;botAttack=function(b,t,d){EC.pvp=t===P;const r=_botAttack2(b,t,d);EC.pvp=false;return r;};

/* ---------- potions : PNJ (15 s) vs alchimie (5 s) ---------- */
usePot=function(k){if(state!=='play'||paused)return;const s=stats();
  const alc=k==='pv'?['elurg','elurg1']:['flux','flux1'],ak=alc.find(x=>P.cons[x]>0);
  if(ak&&(P.alcT||0)<=0){if(k==='pv'&&P.hp>=s.maxhp)return;if(k==='pm'&&P.mp>=s.maxmp)return;P.cons[ak]--;const v={elurg:350,elurg1:150,flux:250,flux1:100}[ak];
    if(k==='pv'){P.hp=Math.min(s.maxhp,P.hp+v);addText(P.x,P.y-30,'+'+v,'#ff8a8a');}else{P.mp=Math.min(s.maxmp,P.mp+v);addText(P.x,P.y-30,'+'+v,'#8ab4ff');}P.alcT=5;return;}
  if(P.potT>0)return;
  if(k==='pv'){if(!(P.cons.pv>0)||P.hp>=s.maxhp)return;P.cons.pv--;const h=Math.round(s.maxhp*.3);P.hp=Math.min(s.maxhp,P.hp+h);addText(P.x,P.y-30,'+'+h,'#ff8a8a');}
  else{if(!(P.cons.pm>0)||P.mp>=s.maxmp)return;P.cons.pm--;const h=Math.round(s.maxmp*.3);P.mp=Math.min(s.maxmp,P.mp+h);addText(P.x,P.y-30,'+'+h,'#8ab4ff');}P.potT=15;};
const _useCons2=useCons;useCons=function(k){if(!(P.cons[k]>0))return _useCons2(k);
  if(k==='elurg'||k==='elurg1'){usePot('pv');return;}if(k==='flux'||k==='flux1'){usePot('pm');return;}
  if(k==='retour'){if(state!=='play')return;if(P.chan)return;closePanel(true);P.chan={k:'retour',n:'Retour de faction',t:4,t0:4};toast('Canalisation du retour','4 s sans bouger ni être frappé');return;}
  if(k==='kit'){const w=P.eq.arme;if(!w){toast('Aucune arme équipée');return;}if(w.dur>=100){toast('Ton arme est intacte');return;}P.cons.kit--;w.dur=Math.min(100,w.dur+30);clampHM();toast('Arme réparée sur le terrain','Durabilité : '+w.dur+' %');return;}
  if(k==='fleches'||k==='enclume'||k==='velin'||k==='poussiere'||k==='essence'||k==='fraggrim'){toast(CONS[k].n,CONS[k].d);return;}
  if(k.startsWith('ench')){toast('Les parchemins s’utilisent chez le forgeron');return;}
  return _useCons2(k);};

/* ---------- enchantement hardcore ---------- */
const ENCH_RATE=[100,100,100,70,50,35,20,10,5,2];
enchInfo=function(it){const p=it.plus,g=p<3?1:p<7?2:3;return{scroll:(isWeapon(it)?'ench':'encha')+g,gold:Math.round(30*Math.pow(p+1,1.6)*(1+it.tier*.3)),chance:ENCH_RATE[p]||0,risk:p<3?'aucun risque':p<5?'le parchemin disparaît':p<7?'retombe de 1':'DESTRUCTION'};};
enchant=function(it){const e=enchInfo(it);if(it.plus>=10||it.type==='second'||!(P.cons[e.scroll]>0)||P.gold<e.gold)return null;P.cons[e.scroll]--;P.gold-=e.gold;
  if(rnd()*100<e.chance){it.plus++;if(it.plus>=6)chat(null,`${P.name} a enchanté ${itemName(it)} !`);qEvent('enchant',it.plus);clampHM();return{ok:true,t:'Réussi ! '+itemName(it)};}
  if(it.plus>=7){const n=2+it.tier+it.plus;for(const sl of SLOTS)if(P.eq[sl]===it)P.eq[sl]=null;P.inv=P.inv.filter(i=>i!==it);P.cons.poussiere=(P.cons.poussiere||0)+n;clampHM();chat(null,`${itemName(it)} s’est désintégré sous la magie de ${P.name}.`);return{ok:false,t:'L’objet est détruit et se change en '+n+' poussières d’enchantement.'};}
  if(it.plus>=5){it.plus--;clampHM();return{ok:false,t:'Échec : l’objet retombe à +'+it.plus+'.'};}
  return{ok:false,t:'Échec : le parchemin disparaît, l’objet reste à +'+it.plus+'.'};};
function dismantle(it){if(!it)return'';const dust=(it.plus>=4?it.plus-2:0)+(it.type==='second'?1:0),ess=it.rar;
  if(!dust&&!ess)return'Objet trop commun : rien à extraire (seuls les objets rares ou enchantés +4 donnent des composants).';
  for(const sl of SLOTS)if(P.eq[sl]===it)P.eq[sl]=null;P.inv=P.inv.filter(i=>i!==it);if(dust)P.cons.poussiere=(P.cons.poussiere||0)+dust;if(ess)P.cons.essence=(P.cons.essence||0)+ess;clampHM();
  return'Démantelé : '+[dust?dust+' poussière'+(dust>1?'s':''):'',ess?ess+' essence'+(ess>1?'s':''):''].filter(Boolean).join(' et ');}

/* ---------- butin : rareté selon la source ---------- */
const BEASTS=['loup','renard','sanglier','ours','araignee','scorpion','crapaud','serpent','hydre','reinescorp'];
const _dropLoot2=dropLoot;dropLoot=function(m,near){const n0=bags.length;EC.cap=m.t.wb?3:m.t.boss||m.t.mini?2:m.elite?2:1;EC.allowLeg=!!m.t.wb;
  if(!m.t.boss&&!m.t.wb&&!m.elite&&rnd()>.06)EC.cap=Math.min(EC.cap,rnd()<.92?0:1);
  try{_dropLoot2(m,near);}finally{EC.cap=3;EC.allowLeg=true;}
  for(let i=n0;i<bags.length;i++){const b=bags[i];for(const g of [1,2,3])if(b.cons['ench'+g]&&rnd()<.5){b.cons['encha'+g]=(b.cons['encha'+g]||0)+b.cons['ench'+g];delete b.cons['ench'+g];}}
  if(!m.tag||m.team)return;const res={},cons={};
  if(BEASTS.includes(m.type)&&rnd()<.25)res.cuir=ri(1,2);if(m.t.wb){res.pigment=ri(3,5);cons.fraggrim=ri(1,3);}
  if(m.dg&&dgRun&&dgRun.dg==='phare'&&!m.t.boss&&rnd()<.1)res.peaurare=1;if(m.lv>=10&&rnd()<(m.elite?.08:.012))cons.fraggrim=1;
  if(Object.keys(res).length||Object.keys(cons).length)bags.push({x:m.x+rr(-8,8),y:m.y+rr(2,8),items:[],cons,res,gold:0,t:90,owner:'p'});};
const _openChest=openChest;openChest=function(){const D=DUNGEONS[M.dg];EC.allowLeg=false;EC.cap=M.dg==='phare'&&M.floor<=3?1:2;try{_openChest();}finally{EC.cap=3;EC.allowLeg=true;}};
const _genMarket=genMarket;genMarket=function(){EC.allowLeg=false;try{_genMarket();}finally{EC.allowLeg=true;}};

/* ---------- récolte : prospection lumineuse ---------- */
const _startHarvest=startHarvest;startHarvest=function(n){_startHarvest(n);const r=RES[n.res];if(!P.harv||!r.glow)return;
  addFx({k:'ring',x:n.x,y:n.y-8,r0:10,r1:120,life:1.2,col:'#ffe14a'});chat(null,'Le filon instable s’illumine : ta position est visible par l’ennemi.');
  for(const b of bots)if(b.map===curId()&&!b.party&&b.fac!==P.fac&&!b.dead)b.goal={x:n.x+rr(-20,20),y:n.y+rr(-20,20)};};

/* ---------- artisanat ---------- */
const have=k=>(RES[k]?P.res[k]:P.cons[k])||0,ingN=k=>RES[k]?RES[k].n:CONS[k].n;
function nearSt(k){if(!M.stations)return null;return M.stations.find(s=>s.k===k&&Math.hypot(s.x-P.x,s.y-P.y)<70)||null;}
function craftCtx(){const city=M.kind==='city'&&M.def&&M.def.side===P.fac&&M.npcs.some(n=>n.role==='craft'&&Math.hypot(n.x-P.x,n.y-P.y)<90);return{city,pvp:!!(M.def&&M.def.pvp)};}
function craftWhy(rc){const C=craftCtx(),p=P.prof[rc.prof];if(!p||p.l<rc.lvl)return'Niveau '+rc.lvl+' de '+PROFS[rc.prof].n+' requis';
  for(const [k,q] of Object.entries(rc.ing))if(have(k)<q)return'Il manque '+ingN(k);
  if(rc.st==='alambic'){const s=nearSt('alambic');if(rc.hi&&!(s&&C.pvp))return'Alambic d’un camp de zone contestée requis';if(!s&&!C.city)return'Alambic requis (camps, atelier de la cité)';}
  if(rc.st==='pupitre'&&!nearSt('pupitre')&&!C.city)return'Pupitre d’inscription requis (atelier de la cité, camps contestés)';
  if(rc.st==='enclume'&&!C.city&&!(P.cons.enclume>0)&&!nearSt('enclume'))return'Forge de cité ou enclume portative requise';
  if(P.chan)return'Tu es déjà occupé';return null;}
canCraft=function(rc){return!craftWhy(rc);};
function consumeIng(rc,all){for(const [k,q] of Object.entries(rc.ing)){if(!all&&rc.rare&&k!==rc.rare)continue;if(RES[k])P.res[k]=Math.max(0,(P.res[k]||0)-q);else P.cons[k]=Math.max(0,(P.cons[k]||0)-q);}}
function craftFinish(rc){const ok=rnd()<rc.rate+Math.min(.1,(P.prof[rc.prof].l-rc.lvl)*.004);
  if(!ok){if(rc.prof==='alchimiste'&&rc.rare){consumeIng(rc,false);const d=Math.round(stats().maxhp*.12);P.hp=Math.max(1,P.hp-d);addText(P.x,P.y-30,'-'+d+' (toxique)','#9be36a');burst(P.x,P.y-14,'#7a9a3a',22);profAdd(rc.prof,rc.xp*.3);return'Échec : le réactif rare se consume dans un nuage toxique.';}
    if(rc.prof==='runesmith'){for(const [k,q] of Object.entries(rc.ing)){const l=Math.ceil(q/2);if(RES[k])P.res[k]-=l;else P.cons[k]-=l;}profAdd(rc.prof,rc.xp*.3);return'Échec : la moitié des matériaux est perdue.';}
    consumeIng(rc,true);profAdd(rc.prof,rc.xp*.3);return'Échec : le vélin et l’encre sont détruits.';}
  consumeIng(rc,true);let out;
  if(rc.out.cons==='grimoire'){const ix=CLASSES[P.cls].tags.map((g,i)=>g!=='inne'&&g!=='city'?i:-1).filter(i=>i>0);const k='livre_'+P.cls+'_'+pick(ix);P.cons[k]=(P.cons[k]||0)+1;out=CONS[k].n+' restauré !';}
  else{P.cons[rc.out.cons]=(P.cons[rc.out.cons]||0)+rc.out.n;out=rc.out.n+' × '+CONS[rc.out.cons].n;}
  profAdd(rc.prof,rc.xp);qEvent('craft');return out;}
craft=function(rc){const why=craftWhy(rc);if(why)return null;
  if(rc.chan){P.chan={k:'craft',n:'Inscription : '+(rc.out.cons==='grimoire'?'restauration':CONS[rc.out.cons].n),t:10,t0:10,rc};closePanel(true);toast('Incantation (10 s)','Ne bouge pas, un coup adverse fait échouer le craft');return'Incantation en cours…';}
  return craftFinish(rc);};
function masterWhy(R){if(P.lvl<R.lvl)return'Niveau '+R.lvl+' requis';if(P.gold<R.gold)return'Pas assez d’or';if(R.honor&&P.honor<R.honor)return'Pas assez d’honneur';for(const [k,q] of Object.entries(R.ing))if(have(k)<q)return'Il manque '+ingN(k);if(invFull())return'Sac plein';return null;}
function masterCraft(id){const R=MASTER.find(x=>x.id===id);if(!R||masterWhy(R))return'';for(const [k,q] of Object.entries(R.ing)){if(RES[k])P.res[k]-=q;else P.cons[k]-=q;}P.gold-=R.gold;if(R.honor)P.honor-=R.honor;
  const it=mkItem(P,R.out,tierFor(P.lvl),R.leg?4:2,P.cls);it.by=npcName('craft');P.inv.push(it);chat(null,`${P.name} reçoit ${itemName(it)} des mains du maître artisan.`);return'Reçu : <span style="color:'+RARC[it.rar]+'">'+esc(itemName(it))+'</span>';}

/* ---------- canalisations (retour, inscription) ---------- */
const _update2=update;update=function(dt){_update2(dt);P.alcT=(P.alcT||0)-dt;
  if(P.chan){const c=P.chan;if(P.mv){P.chan=null;toast(c.n+' interrompu','Tu as bougé'+(c.k==='craft'?' : les matériaux sont perdus':''));if(c.k==='craft')consumeIng(c.rc,true);return;}
    c.t-=dt;if(rnd()<dt*8)burst(P.x+rr(-8,8),P.y-14,c.k==='craft'?'#c58cff':'#7ff3ff',1);
    if(c.t<=0){P.chan=null;if(c.k==='retour'){if(!(P.cons.retour>0))return;P.cons.retour--;dgRun=null;if(EV.bf)return;transition(FACTIONS[P.fac].cap,{});}else{const r=craftFinish(c.rc);toast('Inscription terminée',r.replace(/<[^>]+>/g,''));}}}};
const _upd3=updMons;updMons=function(dt){const h=P&&P.buffs.find(b=>b.id==='huile');if(h)for(const m of mons)if(!m.agg&&!m._ag0){m._ag0=m.aggro;m.aggro*=.5;}if(!h)for(const m of mons)if(m._ag0){m.aggro=m._ag0;m._ag0=0;}_upd3(dt);};

/* ---------- panneaux ---------- */
function ecoForgePanel(fac,msg){const P1=g=>P.cons['ench'+g]||0,P2=g=>P.cons['encha'+g]||0;let h=CLOSE+`<h2>${esc(npcName('forge'))}, forgeron</h2><p class="sub">+1 à +3 : 100 % · +4 70 % · +5 50 % (échec : parchemin perdu) · +6 35 % · +7 20 % (échec : −1) · +8 10 % · +9 5 % · +10 2 % (échec : objet détruit, changé en poussière).</p>`;
  const rc=repairCost();h+=row(`<b>Réparer tout l’équipement</b><small>Chaque mort retire 10 % de durabilité. À 0 %, l’objet ne donne plus rien.</small>`,B('repair',rc?rc+' or':'Intact',rc&&P.gold>=rc?'':'disabled','go'));
  h+=`<h3>PARCHEMINS D’ARME I ${P1(1)} · II ${P1(2)} · III ${P1(3)} &nbsp; D’ARMURE I ${P2(1)} · II ${P2(2)} · III ${P2(3)}</h3>`;
  for(const it of [...SLOTS.map(sl=>P.eq[sl]).filter(Boolean),...P.inv]){if(it.type==='second'){h+=row(itemLine(it),B('dism','Démanteler',`data-id="${it.id}"`));continue;}const e=enchInfo(it);
    h+=row(itemLine(it),(it.plus>=10?'<span class="why">Max</span>':`<span class="why">${e.chance} % · ${e.risk} · ${e.gold} or · ${esc(CONS[e.scroll].n)}</span>`+B('ench','+'+(it.plus+1),`data-id="${it.id}" ${!(P.cons[e.scroll]>0)||P.gold<e.gold?'disabled':''}`,'go'))+((it.rar||it.plus>=4)?B('dism','Démanteler',`data-id="${it.id}"`):''));}
  return h+msg();}
function ecoCraftPanel(msg){const crafts=Object.entries(PROFS).filter(([,p])=>p.k==='c'),C=craftCtx();const tl=crafts.map(([pk,p])=>[pk,p.n+' '+P.prof[pk].l]);if(C.city)tl.push(['maitre','Maître artisan']);
  if(!tl.some(t=>t[0]===panelTab))panelTab=(panelData&&panelData.prof)||tl[0][0];
  const st=['alambic','pupitre','enclume'].filter(nearSt).map(k=>({alambic:'alambic',pupitre:'pupitre d’inscription',enclume:'enclume'}[k]));
  let h=CLOSE+`<h2>${C.city?'Atelier de la cité':'Artisanat'}</h2><p class="sub">Aucun métier ne crée d’or : ils transforment les ressources, et un échec détruit des matériaux. ${C.city?'L’atelier offre alambic, pupitre et forge.':st.length?'À proximité : '+st.join(', ')+'.':'Aucune station à proximité.'}${C.pvp?' Zone contestée : recettes de haut niveau autorisées.':''}</p>`+tabs(tl,panelTab);
  if(panelTab==='maitre'){h+='<p class="sub">Les pièces légendaires et les capes de faction ne tombent pas des monstres ordinaires : elles se commandent ici, contre des composants issus de la destruction d’objets enchantés et des matériaux des zones contestées.</p>';
    for(const R of MASTER){const why=masterWhy(R);h+=row(`<b>${esc(R.n)}</b><small>${Object.entries(R.ing).map(([k,q])=>`<span class="${have(k)>=q?'have':'miss'}">${esc(ingN(k))} ${have(k)}/${q}</span>`).join(' · ')} · ${R.gold} or${R.honor?' · '+R.honor+' honneur':''} · niv. ${R.lvl}${why?' · <span class="miss">'+esc(why)+'</span>':''}</small>`,B('master','Commander',`data-v="${R.id}" ${why?'disabled':''}`,'go'));}
    return h+msg();}
  h+=`<p class="sub">${esc(PROFS[panelTab].d)}</p>`;
  for(const rc of RECIPES.filter(r=>r.prof===panelTab)){const why=craftWhy(rc),lock=P.prof[rc.prof].l<rc.lvl,out=rc.out.cons==='grimoire'?'Restauration de grimoire scellé':rc.out.n+' × '+CONS[rc.out.cons].n;
    h+=row(`<b class="${lock?'dimb':''}">${esc(out)}</b><small>${Object.entries(rc.ing).map(([x,q])=>`<span class="${have(x)>=q?'have':'miss'}">${esc(ingN(x))} ${have(x)}/${q}</span>`).join(' · ')} · niv. ${rc.lvl} · réussite ${Math.round(rc.rate*100)} %${rc.hi?' · zone contestée':''}${rc.chan?' · 10 s immobile':''}${why&&!lock?' · <span class="miss">'+esc(why)+'</span>':''}</small>`,B('craft','Fabriquer',`data-v="${rc.id}" ${why?'disabled':''}`,'go'));}
  return h+msg();}
EXTRA_ACT.dism=(v,b)=>{panelMsg=esc(dismantle(findItem(+b.dataset.id)));};
EXTRA_ACT.master=v=>{panelMsg=masterCraft(v);};

/* ---------- stations : alambic, pupitre, enclume ---------- */
function buildEcoProps(){const T=(k,w,h,fn)=>{PROPS[k]=mkProp(w,h,fn);};
  T('alambic',18,26,g=>{g.fillStyle='#6a4a2a';g.fillRect(2,20,14,5);g.fillStyle='#b87a3a';disc(g,9,15,6,'#c88a4a');g.fillStyle='#e8c870';g.fillRect(8,3,2,8);g.fillRect(10,3,6,2);g.fillRect(15,3,2,9);disc(g,9,15,3,'#7ff39a');g.fillStyle='#ff9a3a';g.fillRect(6,22,6,2);});
  T('pupitre',18,24,g=>{g.fillStyle='#5a3a22';g.fillRect(7,10,4,14);g.fillRect(3,22,12,2);g.fillStyle='#7a5232';g.fillRect(1,6,16,6);g.fillStyle='#f4ead0';g.fillRect(3,4,6,5);g.fillRect(9,4,6,5);g.fillStyle='#3a2a4a';g.fillRect(4,5,4,1);g.fillRect(10,6,4,1);g.fillStyle='#c58cff';g.fillRect(15,1,1,5);});
  T('enclume',20,16,g=>{g.fillStyle='#4a4a52';g.fillRect(2,3,16,4);g.fillRect(0,3,4,2);g.fillRect(7,7,6,5);g.fillRect(4,12,12,3);g.fillStyle='#7a7a84';g.fillRect(3,3,14,1);});
  for(const [k,a] of [['moussesang','mandragore'],['racarcane','trefle'],['champcav','sauge']])if(PROPS['herb_'+a]){const c=cnv(PROPS['herb_'+a].c.width,PROPS['herb_'+a].c.height),g=c.getContext('2d');g.drawImage(PROPS['herb_'+a].c,0,0);g.globalCompositeOperation='source-atop';g.fillStyle={moussesang:'rgba(200,30,40,.55)',racarcane:'rgba(120,80,255,.5)',champcav:'rgba(230,200,120,.5)'}[k];g.fillRect(0,0,c.width,c.height);PROPS['herb_'+k]={c,w:c.width,h:c.height};}
  for(const [k,c,h] of [['fernoir','#2a2a30','#8a8aa0'],['quartzombre','#5a2a8a','#e0b0ff']])T('ore_'+k,20,18,g=>{g.fillStyle='#5e5866';g.fillRect(2,7,16,10);g.fillRect(4,5,12,12);g.fillStyle='#7a7484';g.fillRect(4,6,6,3);g.fillStyle=c;g.fillRect(6,2,3,7);g.fillRect(11,4,3,6);g.fillRect(9,9,2,4);g.fillStyle=h;g.fillRect(6,2,1,3);g.fillRect(11,4,1,2);});}
