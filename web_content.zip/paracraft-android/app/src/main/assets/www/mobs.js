'use strict';
/* ================== Paracraft Online · monstres, IA et butin ==================
   Passifs : n'attaquent que si on les frappe. Agressifs : zone de détection, appel des congénères proches.
   Boss et mini-boss : toujours agressifs, détection et poursuite plus larges, compétences (coup étourdissant,
   onde de choc, soin). Poursuite limitée (leash) : au-delà, le monstre devient invincible, revient en courant
   à son point d'apparition et récupère toute sa vie. Réapparition : 10 à 30 s, mini-boss 15 min, boss de monde
   plusieurs heures. Butin réservé 12 s à son vainqueur, puis public ; il disparaît après 60 à 90 s. */

const LEASH=m=>m.t.boss?460:m.elite?360:300;
const SOCIAL_R=120;
/* zone de poursuite : le joueur qui s'éloigne trop du point d'apparition fait abandonner le monstre */
const _updMonsM=updMons;updMons=function(dt){
  for(const m of mons){if(m.dead||!m.agg)continue;const far=Math.hypot(P.x-m.sx,P.y-m.sy)>LEASH(m)+40||Math.hypot(m.x-m.sx,m.y-m.sy)>LEASH(m);
    if(far||P.hp<=0){m.agg=false;m.ret=true;}}
  _updMonsM(dt);
  for(const m of mons){if(m.dead||!m.ret)continue;
    if(m.hp<m.maxhp){m.hp=m.maxhp;addText(m.x,m.y-m.hh*2-6,'Retour','#9aa6c4');}m.tag=0;m.bskT=0;m.healed=0;
    const dx=m.sx-m.x,dy=m.sy-m.y,d=Math.hypot(dx,dy);if(d>6){const sp=m.t.spd*dt*1.2;if(!steer(m,dx/d*sp,dy/d*sp,true)){m.x=m.sx;m.y=m.sy;}}}
  bossSkills(dt);};
/* invincible pendant le retour ; aggro de groupe des congénères agressifs */
const _hitMonM=hitMon;hitMon=function(m,dmg,col,fromParty,crit){if(m.dead)return;
  if(m.ret){addText(m.x,m.y-m.hh*2-4,'Invincible','#c8d0e4');return;}
  if(!m.agg&&m.t.agr&&!m.t.boss)for(const o of mons)if(o!==m&&!o.dead&&!o.agg&&!o.ret&&o.type===m.type&&dist(o,m)<SOCIAL_R){o.agg=true;addText(o.x,o.y-o.hh*2-6,'!','#ff6a4a');}
  _hitMonM(m,dmg,col,fromParty,crit);};
/* réapparition : normaux 10 à 30 s, mini-boss 15 min (le minuteur survit aux changements de carte) */
const miniKey=s=>curId()+':'+s.type;
const _killMonM=killMon;killMon=function(m){_killMonM(m);if(m.dg||m.t.wb)return;
  if(m.t.mini||m.t.boss){m.rt=m.respawn;P.miniT=P.miniT||{};P.miniT[miniKey(m)]=Date.now()+m.respawn*1000;}else m.rt=rr(10,30);};
const _spawnMonM=spawnMon;spawnMon=function(s){const m=_spawnMonM(s);
  if((m.t.mini||m.t.boss)&&!m.t.wb&&!m.dg&&P&&P.miniT){const left=(P.miniT[miniKey(m)]||0)-Date.now();if(left>0){m.dead=true;m.rt=left/1000;}}return m;};
SAVE_FIELDS.push('miniT');
/* compétences des boss et mini-boss */
function bossSkills(dt){if(state!=='play')return;for(const m of mons){if(m.dead||!m.agg||!(m.t.boss||m.t.mini))continue;
  if(m.cast){m.cast.t-=dt;if(m.cast.t<=0){const c=m.cast;m.cast=null;const d=dist(m,P);
      if(c.k==='stun'&&d<c.r){hurtPlayer(m.dmg*1.2*gapMul(m.lv),m.name);P.stunT=1.4;addText(P.x,P.y-34,'Étourdi !','#ffd84a');}
      else if(c.k==='wave'){addFx({k:'ring',x:m.x,y:m.y-4,r0:12,r1:c.r,life:.35,col:'#ff7a3a'});burst(m.x,m.y-4,'#ff9a5a',14);if(d<c.r)hurtPlayer(m.dmg*1.5*gapMul(m.lv),m.name);}}continue;}
  m.bskT=(m.bskT||rr(4,7))-dt;if(m.bskT>0)continue;m.bskT=rr(7,10);const d=dist(m,P);
  if(m.hp<m.maxhp*.4&&(m.healed||0)<2){m.healed=(m.healed||0)+1;const h=Math.round(m.maxhp*.12);m.hp=Math.min(m.maxhp,m.hp+h);addText(m.x,m.y-m.hh*2-6,'+'+h,'#7ff07f');burst(m.x,m.y-m.hh,'#7ff07f',12);chat(null,m.name+' se soigne !');}
  else if(d<90){m.cast={k:'stun',t:.7,r:72};addFx({k:'tele',x:m.x,y:m.y-4,r:72,life:.7,col:'#ffd84a'});addText(m.x,m.y-m.hh*2-6,'Coup étourdissant','#ffd84a');}
  else{m.cast={k:'wave',t:1,r:120};addFx({k:'tele',x:m.x,y:m.y-4,r:120,life:1,col:'#ff5a3a'});addText(m.x,m.y-m.hh*2-6,'Onde de choc','#ff9a5a');}}}
/* étourdissement du joueur : pas de déplacement, d'attaque ni de sort */
const _updateM=update;update=function(dt){if(P&&P.stunT>0&&state==='play'){P.stunT-=dt;joyV.x=joyV.y=0;keys.clear();P.atkOn=false;P.moveTo=null;}_updateM(dt);};
const _attackBtnM=attackBtn;attackBtn=function(){if(P&&P.stunT>0)return;_attackBtnM();};
const _useSkillM=useSkill;useSkill=function(i){if(P&&P.stunT>0)return;_useSkillM(i);};
/* verrou de butin : 12 s */
LOCK_T=12;
