'use strict';
/* ================== Paracraft Online · interface épurée ==================
   HUD façon IMO (portrait rond, barres, boutons icônes, compétences rondes), fenêtres parchemin façon TWOM
   (onglets icônes, poupée d'équipement, grille de sac), dialogues PNJ avec portrait et choix,
   bulles de paroles, écran de serveur, création de personnage et répartition des caractéristiques. */

/* ---------- apparence du joueur ---------- */
const HAIR_M=[['short','Courts'],['spiky','Hérissés'],['bald','Rasés']],HAIR_F=[['long','Longs'],['pony','Queue'],['bun','Chignon']];
const HAIR_C=['#5a3a22','#d9a441','#a83a2a','#2a2a2a','#e8e0f0','#7a4ab8'];
const SKIN_C=['#f1c9a0','#e7b98c','#b07a4a'];
function playerLook(c){const L=Object.assign({},CLASSES[c.cls].look),lk=c.look2||{fem:0,hs:'short',hc:0,sk:1};L.cape=FACTIONS[c.fac].cape;L.hair=HAIR_C[lk.hc]||HAIR_C[0];L.hairStyle=lk.hs;L.skin=SKIN_C[lk.sk==null?1:lk.sk];if(lk.fem)L.fem=1;
  if(c.fac==='umbra'&&c.cls==='guerrier'){L.body='#4a4458';L.body2='#2e2a3a';}
  if(!(c.eq&&c.eq.casque))L.extra='none';return L;}
function refreshLook(){if(P)P.look=playerLook(P);}
const _equipL=equip;equip=function(it){_equipL(it);refreshLook();};const _unequipL=unequip;unequip=function(sl){_unequipL(sl);refreshLook();};
function lookURL(L,sc){const s=humSprite(L,sc||4);return s.d[0].toDataURL();}

/* ---------- groupe de fenêtres (onglets icônes) ---------- */
const GROUP=[['perso','perso','Perso'],['sac','sac','Sac'],['sorts','sorts','Sorts'],['questlog','quetes','Quêtes'],['metiers','metiers','Métiers'],['guilde','guilde','Guilde'],['carte','carte','Carte']];
function groupStrip(){return'<nav class="gtabs">'+GROUP.map(([k,ic,n])=>`<button class="gtab ${panelKind===k?'on':''}" data-a="goto" data-v="${k}" type="button"><img src="${uiIcon(ic)}" alt=""><span>${n}</span></button>`).join('')+'</nav>';}

/* ---------- inventaire façon TWOM ---------- */
const DOLL=[['casque','Casque'],['collier','Collier'],['armure','Armure'],['arme','Arme'],['gants','Gants'],['anneau','Anneau'],['bottes','Bottes'],['cape','Cape']];
function invCells(){const cells=[];for(const it of P.inv)cells.push({t:'i',it,key:'i:'+it.id});
  for(const [k,n] of Object.entries(P.cons)){if(!(n>0)||isVirtual(k))continue;const per=k.startsWith('livre_')?1:STACK_CONS;let left=n,j=0;while(left>0){const q=Math.min(per,left);cells.push({t:'c',k,n:q,key:'c:'+k+':'+j});left-=q;j++;}}
  for(const [k,n] of Object.entries(P.res)){if(!(n>0))continue;let left=n,j=0;while(left>0){const q=Math.min(STACK_RES,left);cells.push({t:'r',k,n:q,key:'r:'+k+':'+j});left-=q;j++;}}return cells;}
function cellIcon(c){return c.t==='i'?itemIcon(c.it):c.t==='c'?consIcon(c.k):resIcon(c.k);}
function cellHTML(c,act,sel){const rc=c.t==='i'?RARC[c.it.rar]:'#8a6a44',badge=c.t==='i'?(c.it.plus?'+'+c.it.plus:''):(c.n>1?c.n:''),broken=c.t==='i'&&c.it.dur<=0;
  return`<button class="cell ${sel?'sel':''} ${broken?'broken':''}" style="--rc:${rc}" data-a="${act||'isel'}" data-v="${c.key}" type="button"><img src="${cellIcon(c)}" alt="">${badge?`<i>${badge}</i>`:''}</button>`;}
function findCell(key){if(!key)return null;if(key.startsWith('e:')){const sl=key.slice(2),it=P.eq[sl];return it?{t:'e',it,sl,key}:null;}if(key.startsWith('b:')){const j=+key.slice(2),b=P.bags[j];return b?{t:'b',it:b,j,key}:null;}return invCells().find(c=>c.key===key)||null;}
function cellDetail(c){if(!c)return'<div class="idet empty">Touche un objet pour voir ses détails.</div>';let h='<div class="idet">',name,desc,acts='';
  if(c.t==='i'||c.t==='e'||c.t==='b'){const it=c.it;name=`<b style="color:${RARC[it.rar]}">${esc(itemName(it))}</b>`;desc=`${RAR[it.rar]} · ${SLOT_N[it.type]||'Objet'}${it.cls?' · '+CLASSES[it.cls].nom:''} · niv. ${TIER_REQ[it.tier]}<br>${esc(statTxt(it))}${it.dur<100&&it.type!=='sac'?' · durabilité '+it.dur+' %':''}`;
    if(c.t==='e')acts=B('uneq','Retirer',`data-v="${c.sl}"`);else if(c.t==='b')acts=B('bagoff','Retirer le sac',`data-v="${c.j}"`);
    else{const why=canEquip(it);acts=(why?`<span class="why">${esc(why)}</span>`:B('equip','Équiper',`data-id="${it.id}"`,'go'))+B('drop','Jeter',`data-id="${it.id}"`,'red');}}
  else if(c.t==='c'){const C=CONS[c.k];name=`<b>${esc(C.n)}</b>`;desc=`${esc(C.d||'')}<br>${c.n} dans cette pile · ${P.cons[c.k]} au total`;acts=(c.k.startsWith('ench')?'<span class="why">S’utilise chez le forgeron</span>':B('use','Utiliser',`data-v="${c.k}"`,'go'))+B('dropc','Jeter la pile',`data-v="${c.k}" data-k="cons"`,'red');}
  else{const R=RES[c.k];name=`<b>${esc(R.n)}</b>`;desc=`Ressource${R.prof?' · '+PROFS[R.prof].n+' niv. '+R.lvl:''} · ${P.res[c.k]} au total, piles de 50`;acts=B('dropc','Jeter la pile',`data-v="${c.k}" data-k="res"`,'red');}
  return h+`<img src="${c.t==='c'?consIcon(c.k):c.t==='r'?resIcon(c.k):itemIcon(c.it)}" alt=""><div class="idt">${name}<small>${desc}</small><div class="iact">${acts}</div></div></div>`;}
function sacPanel(s){const sel=panelData&&panelData.sel,cells=invCells(),cap=invCap(),w=invWeight(),e=encState();
  let h=CLOSE+'<h2>Sac</h2><div class="invwrap"><div class="doll">';
  const slot=(sl,lab)=>{const it=P.eq[sl];return it?`<button class="cell eq ${sel==='e:'+sl?'sel':''}" style="--rc:${RARC[it.rar]}" data-a="isel" data-v="e:${sl}" type="button"><img src="${itemIcon(it)}" alt="">${it.plus?`<i>+${it.plus}</i>`:''}</button>`:`<div class="cell eq none" title="${lab}"><small>${lab}</small></div>`;};
  h+=`<div class="dcol">${slot('casque','Casque')}${slot('armure','Armure')}${slot('gants','Gants')}${slot('bottes','Bottes')}</div>`;
  h+=`<div class="dmid"><div class="dpor"><img src="${lookURL(P.look,4)}" alt=""></div><small>Défense ${s.def} · Attaque ${s.atk}</small><div class="dbags">`;
  for(let j=0;j<2;j++){const b=P.bags[j];h+=b?`<button class="cell bag ${sel==='b:'+j?'sel':''} ${b.dur<=0?'broken':''}" style="--rc:${RARC[b.rar]}" data-a="isel" data-v="b:${j}" type="button"><img src="${itemIcon(b)}" alt=""><i>+${BAGS[b.bag].slots}</i></button>`:'<div class="cell eq none"><small>Sac</small></div>';}
  h+=`</div></div><div class="dcol">${slot('arme','Arme')}${slot('collier','Collier')}${slot('anneau','Anneau')}${slot('cape','Cape')}</div></div><div class="bagside">`;
  h+=`<div class="money"><span><img src="${uiIcon('or')}" alt=""> ${P.gold.toLocaleString('fr-FR')}</span><span>Honneur ${P.honor}</span><span>Cornes ${P.ev.horns||0}</span></div>`;
  h+=`<div class="meter"><span>Cases ${invUsed()} / ${cap}</span>${bar(invUsed()/cap,invUsed()>=cap?'#c83a2a':'#5a9a3a')}<span>Poids ${w} / ${s.pods} kg</span>${bar(w/s.pods,e===2?'#c83a2a':e?'#d8962a':'#3a7ac8')}</div>`;
  h+='<div class="grid">';const used=invUsed();let shown=0;for(const c of cells){h+=cellHTML(c,'isel',sel===c.key);shown++;}
  for(let k=used;k<cap;k++)h+='<div class="cell none"></div>';
  let locked=0;for(const b of P.bags)if(b&&b.dur<=0)locked+=BAGS[b.bag].slots;for(let k=0;k<locked;k++)h+='<div class="cell lock"></div>';
  h+='</div>';const virt=Object.entries(P.cons).filter(([k,n])=>n>0&&isVirtual(k));if(virt.length)h+='<div class="virt">'+virt.map(([k,n])=>`<span><img src="${consIcon(k)}" alt="">${n}</span>`).join('')+'</div>';
  h+='</div></div>'+cellDetail(findCell(sel))+(e?`<p class="sub warn">${e===2?'Encombré : déplacement −50 %, téléportation impossible.':'Surcharge : déplacement −20 %, sorts +50 % de PM.'}</p>`:'');
  return h+msg0();}
const msg0=()=>`<p class="msg">${panelMsg}</p>`;
EXTRA_ACT.isel=v=>{panelData=Object.assign({},panelData||{},{sel:(panelData&&panelData.sel===v)?null:v});};

/* ---------- fenêtre des sorts ---------- */
function sortsPanel(){const c=CLASSES[P.cls];if(!/^\d$/.test(String(panelTab))||!c.sk[+panelTab])panelTab='0';const i=+panelTab,sk=c.sk[i],rk=skRank(i),bk='livre_'+P.cls+'_'+i,have=P.cons[bk]||0,R3=a=>Array.isArray(a)?a.join(' / '):a;
  let h=CLOSE+`<h2>Sorts · ${c.nom}</h2><div class="spgrid">`;
  c.sk.forEach((x,j)=>{const r=skRank(j),own=P.cons['livre_'+P.cls+'_'+j]>0,b=P.bar.indexOf(j);h+=`<button class="spi ${j===i?'on':''} ${r?'':'locked'}" data-a="spsel" data-v="${j}" type="button"><span class="ring"><img src="${spellIcon(P.cls,x)}" alt="">${b>=0?`<i>${b+1}</i>`:''}${own&&r<3?'<em>!</em>':''}</span><b>${esc(x.s)}</b><small>${r?'●'.repeat(r)+'○'.repeat(3-r):'niv. '+x.lv}</small></button>`;});
  h+=`</div><div class="spdet"><img src="${spellIcon(P.cls,sk)}" alt=""><div><b>${esc(sk.n)}</b> <small class="num">niv. ${sk.lv} · ${rk?'rang '+rk+'/3':'non appris'}</small><p>${esc(skillDesc(sk,Math.max(1,rk)))}</p><small>PM ${R3(sk.mp)} · recharge ${R3(sk.cd)} s · ${i===0?'sort inné':'grimoire : '+esc(c.src[i])}</small></div></div>`;
  if(have&&rk<3)h+=`<p>${B('learn',rk?'Lire le grimoire : rang '+(rk+1):'Apprendre '+esc(sk.n),`data-v="${bk}"`,'go')} <span class="why">${have} en main</span></p>`;
  if(rk){h+='<h3>BARRE DE RACCOURCIS</h3><div class="barset2">'+[0,1,2,3,4,5].map(j=>{const x=c.sk[P.bar[j]];return`<button class="spi mini ${P.bar[j]===i?'on':''}" data-a="bar" data-v="${j}" data-s="${i}" type="button"><span class="ring">${x?`<img src="${spellIcon(P.cls,x)}" alt="">`:''}<i>${j+1}</i></span></button>`;}).join('')+'</div><p class="sub">Touche une case pour y placer « '+esc(sk.n)+' ».</p>';}
  return h+msg0();}

/* ---------- dialogues PNJ ---------- */
const NPC_TALK={
  quest:["Le royaume a besoin de bras, et toi tu en as deux.","Chaque éclat retrouvé est une vie sauvée.","Les rapports arrivent de partout. Écoute bien."],
  event:["Les cors sonnent bientôt ! Inscris-toi pendant qu’il reste de la place.","Champ de bataille, sièges, invasions : tout passe par moi.","La gloire n’attend pas les retardataires."],
  shop:["Potions fraîches, parchemins, tout ce qu’il faut pour ne pas mourir bêtement.","Regarde, mais ne touche qu’avec de l’or !","Bonne journée pour faire des affaires."],
  forge:["Le métal ne ment jamais. Les enchantements, si.","Au-delà de +7, je ne garantis plus rien.","Une lame bien entretenue vaut deux lames neuves."],
  trainer:["Un guerrier sans entraînement est un cadavre qui s’ignore.","Je peux redistribuer tes forces, si tu t’es trompé de chemin.","Le grimoire de la cité ne s’achète qu’ici."],
  hdv:["Tout s’achète et tout se vend, sauf à l’ennemi.","Les sacs de l’Abîme partent à prix d’or ces jours-ci.","Commission raisonnable, comme toujours."],
  guild:["Seul, on survit. En guilde, on conquiert.","Un monument de plus et ta guilde lèvera la taxe.","Fonde ta bannière ou rejoins une maison."],
  craft:["L’atelier est ouvert : alambic, pupitre, forge.","Un échec détruit les matériaux, n’oublie pas.","Le maître artisan accepte les commandes légendaires."],
  war:["La Frontière brûle encore. Y vas-tu ?","L’honneur se gagne sur le champ de bataille, pas à la taverne.","La victoire donne de l’expérience à toute la faction."],
  roi:["Approche. Le trône t’écoute.","Mon royaume tient parce que des gens comme toi se lèvent chaque matin.","{rival} rêve de nos murs. Qu’elle continue de rêver."],
  banque:["Ce que tu déposes ici, aucun ennemi ne peut te le prendre.","Ton coffre t’attend. Trente cases, bien gardées.","La mort fait perdre des choses. Pas ici."],
  temple:["Que la lumière veille sur toi, voyageur.","Les noms rouges trouvent ici le pardon, contre une offrande.","Une bénédiction avant de partir ?"],
  taverne:["Assieds-toi, la soupe est chaude !","On entend tout, à une table de taverne.","Un repas ici, et la route paraît moins longue."],
  biblio:["Les pupitres dehors portent nos plus anciens livres.","Chaque grimoire est une porte. Chaque livre, une fenêtre.","Chut. Ici, on lit."],
  camp:["Le camp tient, mais pour combien de temps ?","Repose-toi un peu, le feu est chaud.","Les bêtes rôdent la nuit."]};
const SERV={quest:null,event:['event','Événements et inscriptions'],shop:['shop','Voir les marchandises'],forge:['forge','Réparer, enchanter, démanteler'],trainer:['trainer','Caractéristiques et grimoire'],hdv:['hdv','Ouvrir l’hôtel des ventes'],guild:['guild','Les guildes'],craft:['craft','Ouvrir l’atelier'],war:['war','Guerre et honneur'],banque:['bank','Ouvrir mon coffre'],taverne:['tavern','Commander à manger']};
function npcGreet(n){if(n.role==='quest')return PROLOGUE[P.fac==='solarix'?3:4];if(n.role==='camp')return CAMPS[M.id]?CAMPS[M.id].g:'';const L=NPC_TALK[n.role]||['Bonjour, voyageur.'];return tok(L[Math.floor(tGame/7+n.x)%L.length]).replace('{rival}',FACTIONS[enemyOf(P.fac)].n);}
function dialogPanel(){const n=panelData,qid=n.qid;let opts=[];
  const ti=qid?qTurnIns(qid):[],av=qid?qAvail(qid):[],ip=qid?qInProg(qid):[],nx=qid?qLockedNext(qid):null;
  for(const id of ti)opts.push(B('qview',`<i class="mk ok">?</i> Rendre : ${esc(tok(qDef(id).t))}`,`data-v="${id}"`,'opt go'));
  for(const q of av)opts.push(B('qview',`<i class="mk">!</i> ${q.chain==='main'?'Campagne : ':''}${esc(tok(q.t))}`,`data-v="${q.id}"`,'opt'));
  for(const id of ip)opts.push(B('qview',`<i class="mk dim">…</i> ${esc(tok(qDef(id).t))}`,`data-v="${id}"`,'opt'));
  const sv=SERV[n.role];if(sv)opts.push(B('goto',esc(sv[1]),`data-v="${sv[0]}"`,'opt go'));
  if(n.role==='camp'){opts.push(B('npcshop','5 potions de vie · 75 or','data-v="pv" '+(P.gold<75?'disabled':''),'opt'));opts.push(B('npcshop','5 potions de mana · 75 or','data-v="pm" '+(P.gold<75?'disabled':''),'opt'));}
  if(n.role==='temple'){opts.push(B('bless','Recevoir la bénédiction',P.ev.blessT>tGameAbs()?'disabled':'','opt go'));if(P.pkT>0||P.pk>0)opts.push(B('purify',`Purifier mon nom · ${purifyCost()} or`,'','opt'));}
  if(n.role==='taverne')opts.push(B('rumor','Écouter les rumeurs','','opt'));
  if(n.role==='roi'||n.role==='biblio')opts.push(B('lorek','Parle-moi du royaume','','opt'));
  if(n.role==='roi')for(const L of [10,20,30,40,50])if(P.lvl>=L&&!(P.ev.royal||{})[L]){opts.push(B('royal',`Faveur royale du niveau ${L}`,`data-v="${L}"`,'opt go'));break;}
  if(nx)opts.push(`<div class="opt dimb">Prochain chapitre au niveau ${nx.lvl}</div>`);
  opts.push(B('close','Au revoir','','opt'));
  const txt=panelData.say||npcGreet(n);
  return`<div class="dlg"><div class="dpic"><img src="${lookURL(n.look,5)}" alt=""></div><div class="dbody"><div class="dname">${esc(n.n)}<small>${esc(n.r)}</small></div><p class="dtxt">${esc(txt)}</p><div class="dopts">${opts.join('')}</div>${panelMsg?`<p class="msg">${panelMsg}</p>`:''}</div></div>`;}
const tGameAbs=()=>Date.now()/1000;
const purifyCost=()=>Math.round(300+P.pk*200+P.lvl*20);
const RUMORS=["On dit qu’un sac de l’Abîme est tombé au quatrième étage du Phare.","Le Titan des Terres maudites aurait été volé au dernier coup par une guilde d’Umbra… ou de Solarix, selon qui raconte.","Les mannequins de la caserne ne mordent pas, mais ils encaissent.","Un marchand de l’hôtel des ventes vend des besaces d’ombre à prix cassé, paraît-il.","La Frontière change de bannière plus vite que la météo.","Prie sur les tombes du cimetière : la prêtresse en sera reconnaissante.","Les filons de fer noir brillent la nuit. L’ennemi aussi les voit."];
const KLORE={solarix:"Aurelia fut bâtie avec la pierre blanche tombée la nuit de la Fracture. Le palais garde le dernier fragment intact du Prisme. Tant qu’il brille, le royaume tient.",umbra:"Nocthar est née sous l’Arbre d’Ombre. La Reine Morgane ne dort plus depuis son couronnement : elle veille sur le Prisme brisé et sur les rêves de son peuple."};
EXTRA_ACT.bless=()=>{addBuff({id:'bless',n:'Bénédiction',xp:.1,def:.05,t:1800});P.ev.blessT=tGameAbs()+1800;panelData.say='Que la lumière te garde. Expérience +10 % et défense +5 % pendant 30 minutes.';};
EXTRA_ACT.purify=()=>{const c=purifyCost();if(P.gold<c){panelMsg='Il faut '+c+' or.';return;}P.gold-=c;P.pkT=0;P.pk=Math.max(0,P.pk-1);panelData.say='Ton nom est lavé. Ne recommence pas.';};
EXTRA_ACT.rumor=()=>{panelData.say=pick(RUMORS);};
EXTRA_ACT.lorek=()=>{panelData.say=KLORE[P.fac];};
EXTRA_ACT.royal=v=>{const L=+v;P.ev.royal=P.ev.royal||{};if(P.ev.royal[L]||P.lvl<L)return;P.ev.royal[L]=1;const g=L*60;P.gold+=g;const add=(k,n)=>P.cons[k]=(P.cons[k]||0)+n;add('pv',5);add(L>=30?'ench2':'ench1',1);add(L>=30?'encha2':'encha1',1);
  if(L===20&&!invFull())P.inv.push(mkBag('sacoche'));panelData.say=`Pour tes ${L} saisons de service : ${g} or, des potions et des parchemins${L===20?', et une sacoche des réserves royales':''}.`;};

/* ---------- banque ---------- */
const BANK_CAP=30;
function bankUsed(){const b=P.bank;let u=b.items.length;for(const [k,n] of Object.entries(b.cons))u+=consSlots(k,n);for(const n of Object.values(b.res))if(n>0)u+=Math.ceil(n/STACK_RES);return u;}
EXTRA_PANELS.bank=()=>{P.bank=P.bank||{items:[],cons:{},res:{}};const B2=P.bank;let h=CLOSE+`<h2>${esc(npcName('banque'))}</h2><p class="sub">Ce qui est au coffre ne tombe jamais à la mort. Touche un objet pour le déposer ou le retirer.</p>`;
  h+=`<div class="bankw"><div><h3>SAC · ${invUsed()} / ${invCap()}</h3><div class="grid">`+invCells().map(c=>cellHTML(c,'bdep')).join('')+`</div></div><div><h3>COFFRE · ${bankUsed()} / ${BANK_CAP}</h3><div class="grid">`;
  for(const it of B2.items)h+=cellHTML({t:'i',it,key:'i:'+it.id},'bwd');for(const [k,n] of Object.entries(B2.cons))if(n>0)h+=cellHTML({t:'c',k,n,key:'c:'+k},'bwd');for(const [k,n] of Object.entries(B2.res))if(n>0)h+=cellHTML({t:'r',k,n,key:'r:'+k},'bwd');
  for(let k=bankUsed();k<BANK_CAP;k++)h+='<div class="cell none"></div>';return h+'</div></div></div>'+msg0();};
EXTRA_ACT.bdep=v=>{const c=invCells().find(x=>x.key===v),B2=P.bank;if(!c)return;
  if(c.t==='i'){if(bankUsed()+1>BANK_CAP){panelMsg='Coffre plein.';return;}P.inv=P.inv.filter(i=>i!==c.it);B2.items.push(c.it);}
  else{const src=c.t==='c'?P.cons:P.res,dst=c.t==='c'?B2.cons:B2.res,before=bankUsed();dst[c.k]=(dst[c.k]||0)+c.n;if(bankUsed()>BANK_CAP){dst[c.k]-=c.n;panelMsg='Coffre plein.';return;}src[c.k]-=c.n;}};
EXTRA_ACT.bwd=v=>{const [t,k]=v.split(':'),B2=P.bank;
  if(t==='i'){const it=B2.items.find(i=>String(i.id)===k);if(!it)return;if(invFull()){panelMsg='Sac plein.';return;}B2.items=B2.items.filter(i=>i!==it);P.inv.push(it);}
  else{const src=t==='c'?B2.cons:B2.res,n=src[k]||0;let q=n;while(q>0&&invUsed()+roomFor(t==='c'?'cons':'res',k,q)>invCap())q--;if(!q){panelMsg='Sac plein.';return;}src[k]-=q;if(t==='c')P.cons[k]=(P.cons[k]||0)+q;else P.res[k]=(P.res[k]||0)+q;}};

/* ---------- taverne ---------- */
const MENU=[['plat1',20],['plat2',40],['plat3',70],['plat4',120]];
EXTRA_PANELS.tavern=()=>{let h=CLOSE+`<h2>${esc(npcName('taverne'))}</h2><p class="sub">Un repas donne un bonus pendant 10 minutes. Or : <b class="gold">${P.gold}</b></p>`;
  h+=MENU.map(([k,p])=>row(`<b><img class="ii" src="${consIcon(k)}" alt=""> ${esc(CONS[k].n)}</b><small>${esc(CONS[k].d)} · ${p} or</small>`,B('buy','Commander',`data-v="${k}" data-p="${p}" data-n="1" ${P.gold<p?'disabled':''}`,'go'))).join('');
  h+=row(`<b>Tournée générale</b><small>+5 % d’expérience pendant 15 min · 50 or</small>`,B('round','Payer',P.gold<50?'disabled':'','go'));return h+msg0();};
EXTRA_ACT.round=()=>{if(P.gold<50)return;P.gold-=50;addBuff({id:'round',n:'Tournée',xp:.05,t:900});panelMsg='Toute la taverne lève son verre à ta santé !';chat(null,P.name+' offre une tournée générale !');};

/* ---------- rendu des panneaux ---------- */
const _renderPanel=renderPanel;renderPanel=function(){const el=$('#panel'),k=panelKind;el.classList.toggle('talk',k==='npc');
  if(k==='npc'){el.innerHTML=dialogPanel();return;}
  if(k==='sac'){el.innerHTML=groupStrip()+sacPanel(stats());return;}
  if(k==='sorts'){el.innerHTML=groupStrip()+sortsPanel();return;}
  _renderPanel();if(GROUP.some(g=>g[0]===k))el.insertAdjacentHTML('afterbegin',groupStrip());
  for(const b of el.querySelectorAll('.btn.close'))b.innerHTML='<b>✕</b>';};
const _actionBtn=actionBtn;actionBtn=function(){if(state!=='play'||paused)return;const it=interactTarget();
  if(it&&it.k==='npc'){const n=it.o;if(n.fac&&n.fac!==P.fac){toast('Cet habitant refuse de te parler');return;}if(n.qid)qEvent('talk',n.qid);if(KQ[n.role])qEvent('talk',n.role);delete n.say;openPanel('npc',n);bubbleSay(n,npcGreet(n),3);return;}
  return _actionBtn();};

/* ---------- bulles de paroles ---------- */
const BUBS=[];let bubT=2;
const CIT_TALK=["Belle journée !","Tu as vu la nouvelle armure du capitaine ?","Le pain a encore augmenté…","On dit que la Frontière est tombée.","Attention aux noms rouges.","J’ai trop mangé à la taverne.","Ma fille veut devenir mage.","Le roi parle demain sur la place.","Les mannequins ont encore perdu.","Qui veut acheter des carottes ?","Ce soir, je m’inscris au champ de bataille !","♪ la la la ♪"];
const GUARD_TALK=["Circulez.","Rien à signaler.","Les portes ferment au crépuscule.","Hors-la-loi interdits !"];
function bubbleSay(o,t,life){const i=BUBS.findIndex(b=>b.o===o);if(i>=0)BUBS.splice(i,1);BUBS.push({o,t:t.length>58?t.slice(0,56)+'…':t,life:life||4.5});}
function bubbleTick(dt){for(const b of BUBS)b.life-=dt;for(let i=BUBS.length-1;i>=0;i--)if(BUBS[i].life<=0)BUBS.splice(i,1);
  bubT-=dt;if(bubT>0||!M)return;bubT=rr(1.6,3.2);const near=o=>Math.abs(o.x-P.x)<260&&Math.abs(o.y-P.y)<180;
  const pool=[];for(const n of M.npcs)if(near(n))pool.push([n,()=>npcGreet(n)]);for(const c of M.citizens||[])if(near(c))pool.push([c,()=>pick(CIT_TALK)]);for(const g of M.guards||[])if(near(g))pool.push([g,()=>pick(GUARD_TALK)]);
  if(pool.length&&BUBS.length<3){const [o,f]=pick(pool);if(!BUBS.some(b=>b.o===o))bubbleSay(o,f());}}
function drawBubbles(S,F,fs){if(!SET.names)return;ctx.font=F(Math.round(fs*.82));ctx.textBaseline='middle';
  for(const b of BUBS){const o=b.o;if(o!==P&&o.map&&o.map!==curId())continue;const[x,y]=S(o.x,o.y-(o.role?50:38));const words=b.t.split(' '),lines=[];let cur='';const maxW=fs*16;
    for(const w of words){const t=cur?cur+' '+w:w;if(ctx.measureText(t).width>maxW&&cur){lines.push(cur);cur=w;}else cur=t;}lines.push(cur);
    const lh=fs*1.15,W=Math.max(...lines.map(l=>ctx.measureText(l).width))+fs*1.2,H=lines.length*lh+fs*.7,bx=Math.round(x-W/2),by=Math.round(y-H-fs*.6);
    ctx.globalAlpha=Math.min(1,b.life*2);ctx.fillStyle='#1a1210';ctx.beginPath();ctx.roundRect(bx-2,by-2,W+4,H+4,fs*.7);ctx.fill();ctx.fillStyle='#fffaf0';ctx.beginPath();ctx.roundRect(bx,by,W,H,fs*.6);ctx.fill();
    ctx.beginPath();ctx.moveTo(x-fs*.4,by+H);ctx.lineTo(x,by+H+fs*.6);ctx.lineTo(x+fs*.4,by+H);ctx.fill();
    ctx.fillStyle='#3a2a1a';lines.forEach((l,i)=>ctx.fillText(l,x,by+fs*.35+lh*(i+.5)));ctx.globalAlpha=1;}
  ctx.textBaseline='bottom';}
const _update5=update;update=function(dt){_update5(dt);bubbleTick(dt);};

/* ---------- HUD ---------- */
function setupHUD(){
  $('#menu').innerHTML=[['bQuest','quetes','Quêtes'],['bMap','carte','Carte'],['bSac','sac','Sac'],['bPerso','perso','Perso'],['bMenu','menu','Menu'],['bPK','pk','PK']].map(([id,ic,n])=>`<button id="${id}" class="ib" type="button" ${id==='bPK'?'hidden':''}><img src="${uiIcon(ic)}" alt=""><span>${n}</span></button>`).join('');
  for(const [id,k] of [['#bPerso','perso'],['#bSac','sac'],['#bMenu','menu'],['#bQuest','questlog'],['#bMap','carte']])$(id).addEventListener('click',()=>{if(state==='play')openPanel(k);});
  $('#bPK').addEventListener('click',()=>{P.pkMode=!P.pkMode;$('#bPK').classList.toggle('on',P.pkMode);toast(P.pkMode?'Mode PK activé':'Mode PK désactivé',P.pkMode?'Tu peux attaquer les joueurs de ta faction. Tuer un allié rend ton nom rouge.':'');});
  const ic=(id,k)=>{const b=$(id);if(b&&!b.querySelector('img.bi'))b.insertAdjacentHTML('beforeend',`<img class="bi" src="${uiIcon(k)}" alt="">`);};
  ic('#bAtk','attaque');ic('#bPV','pv');ic('#bPM','pm');ic('#bAct','parler');}
const _setSkillLabels=setSkillLabels;setSkillLabels=function(){_setSkillLabels();if(!P)return;const L=CLASSES[P.cls].sk;for(let j=0;j<6;j++){const b=$('#bS'+j);if(!b)continue;const x=L[P.bar[j]];let img=b.querySelector('img.bi');if(!img){b.insertAdjacentHTML('beforeend','<img class="bi" alt="">');img=b.querySelector('img.bi');}if(x){img.src=spellIcon(P.cls,x);img.hidden=false;}else img.hidden=true;}};
let _porKey='';function drawPortrait(){const c=$('#portrait');if(!c||!P)return;const key=JSON.stringify(P.look);if(key===_porKey)return;_porKey=key;const g=c.getContext('2d'),s=humSprite(P.look,4);g.clearRect(0,0,c.width,c.height);g.imageSmoothingEnabled=false;g.drawImage(s.d[0],0,0,s.d[0].width,s.d[0].height*.55,(c.width-s.d[0].width)/2,6,s.d[0].width,s.d[0].height*.55);}
const _hud=hud;hud=function(){_hud();if(!P||state==='title')return;const tg=P.target;if(tg&&!tg.dead){const lv=tg.lvl||tg.lv,lc=lvlColor(lv,P.lvl),far=dist(P,tg)>atkRange(tg);setTxt('tgi',(P.atkOn?'⚔ Combat engagé':far?'Sélectionné · trop loin':'Sélectionné · touche Attaque ou un sort')+(tg.kind==='m'?' · '+lc.n:''));}drawPortrait();setTxt('pvn',String(P.cons.pv||0));setTxt('pmn',String(P.cons.pm||0));const pk=$('#bPK');if(pk)pk.hidden=!(M&&M.def&&M.def.pvp);
  const ai=$('#bAct img.bi'),it=interactTarget();if(ai&&it){const k=it.k==='npc'?'parler':it.k==='bag'?'sac':it.k==='node'?'metiers':it.k==='portal'?'carte':'quetes';if(ai.dataset.k!==k){ai.dataset.k=k;ai.src=uiIcon(k);}}};
/* chroniques : carte de lore au lieu du chat */
function showLore(t,x){const el=$('#lorecard');if(!el)return;el.innerHTML=`<b>${esc(t)}</b><span>${esc(x)}</span>`;el.classList.add('on');clearTimeout(showLore.h);showLore.h=setTimeout(()=>el.classList.remove('on'),7000);}
const _onEnterMapL=onEnterMap;onEnterMap=function(){const id=M.kind==='dungeon'?null:M.id,first=id&&MAP_LORE[id]&&!(P.codex&&P.codex['zone:'+id]);const n=chatLines.length;_onEnterMapL();if(first){if(chatLines.length>n&&chatLines[chatLines.length-1].txt.startsWith('Chroniques'))chatLines.pop();renderChat();showLore('Chroniques · '+MAPS[id].n,MAP_LORE[id]);}};
/* chat compact : 4 lignes récentes */
const _renderChat=renderChat;renderChat=function(){_renderChat();const el=$('#chat');while(el.children.length>4)el.removeChild(el.firstChild);};

/* ---------- écran d'entrée : serveur, personnages, création, caractéristiques ---------- */
const SERVERS=[{n:'Prisme d’Éther',st:'Actif',pop:'Ouvert',d:'Serveur principal · PvP de faction'}];
let selServer=0,cr={fem:0,hs:'short',hc:0,sk:1,cls:'guerrier',fac:'solarix',hc2:false,name:'',al:{for:0,dex:0,int:0,con:0,sag:0}};
const START_PTS=10;
function scr(id){for(const s of ['sServer','sMain','sNew','sStats'])$('#'+s).hidden=s!==id;}
function showServers(){scr('sServer');$('#srvList').innerHTML=SERVERS.map((s,i)=>`<button class="srv ${i===selServer?'on':''}" data-i="${i}" type="button"><b>${esc(s.n)}</b><span class="act">${s.st}</span><small>${s.d}</small></button>`).join('');}
$('#srvList').addEventListener('click',e=>{const b=e.target.closest('.srv');if(b){selServer=+b.dataset.i;showServers();}});
$('#srvOk').onclick=()=>{showChars();};
showChars=(function(orig){return function(){orig();scr('sMain');$('#srvName').textContent=SERVERS[selServer].n;};})(showChars);
function crLook(){return playerLook({cls:cr.cls,fac:cr.fac,look2:{fem:cr.fem,hs:cr.hs,hc:cr.hc,sk:cr.sk},eq:{}});}
function buildCreate(){const opt=(grp,val,inner,on,extra)=>`<button class="copt ${on?'on':''}" data-g="${grp}" data-v="${val}" type="button" ${extra||''}>${inner}</button>`;
  const head=(hs)=>{const L=Object.assign({},crLook(),{hairStyle:hs,extra:'none',weapon:'none'});const s=humSprite(L,3);return`<img src="${s.d[0].toDataURL()}" alt="" style="object-fit:cover;object-position:top;height:42px">`;};
  let h='<div class="crow"><span class="clab">Sexe</span>'+opt('fem',0,'<b>♂</b><small>Homme</small>',!cr.fem)+opt('fem',1,'<b>♀</b><small>Femme</small>',!!cr.fem)+'</div>';
  h+='<div class="crow"><span class="clab">Coiffure</span>'+(cr.fem?HAIR_F:HAIR_M).map(([k,n])=>opt('hs',k,head(k)+`<small>${n}</small>`,cr.hs===k)).join('')+'</div>';
  h+='<div class="crow"><span class="clab">Couleur</span>'+HAIR_C.map((c,i)=>opt('hc',i,`<i class="sw" style="background:${c}"></i>`,cr.hc===i)).join('')+'</div>';
  h+='<div class="crow"><span class="clab">Peau</span>'+SKIN_C.map((c,i)=>opt('sk',i,`<i class="sw" style="background:${c}"></i>`,cr.sk===i)).join('')+'</div>';
  h+='<div class="crow"><span class="clab">Classe</span>'+Object.entries(CLASSES).map(([k,C])=>opt('cls',k,`<img src="${spellIcon(k,C.sk[0])}" alt=""><small>${C.nom}</small>`,cr.cls===k)).join('')+'</div>';
  h+='<div class="crow"><span class="clab">Faction</span>'+Object.entries(FACTIONS).map(([k,f])=>opt('fac',k,`<i class="sw" style="background:${f.c}"></i><small>${esc(f.n)}</small>`,cr.fac===k)).join('')+'</div>';
  $('#crOpts').innerHTML=h;$('#crPrev').src=lookURL(crLook(),5);
  const C=CLASSES[cr.cls];$('#crInfo').innerHTML=`<b>${C.nom}</b> · <em>${esc(C.role)}</em><br><span>${esc(FACTIONS[cr.fac].full)}</span>`;}
$('#crOpts').addEventListener('click',e=>{const b=e.target.closest('.copt');if(!b)return;const g=b.dataset.g;let v=b.dataset.v;if(g==='fem'||g==='hc'||g==='sk')v=+v;cr[g]=v;if(g==='fem')cr.hs=v?'long':'short';if(g==='cls')cr.al={for:0,dex:0,int:0,con:0,sag:0};buildCreate();});
function showCreate(){scr('sNew');$('#nameIn').value=cr.name||'';$('#nameMsg').textContent='';buildCreate();}
$('#bNew').onclick=showCreate;$('#bBack').onclick=()=>showChars();
$('#crNext').onclick=()=>{const name=($('#nameIn').value||'').trim().slice(0,14);if(name.length<3){$('#nameMsg').textContent='Le nom doit faire au moins 3 caractères.';return;}if(CHARS.some(c=>c.name.toLowerCase()===name.toLowerCase())){$('#nameMsg').textContent='Ce nom est déjà pris.';return;}cr.name=name;showStats();};
const STAT_ROWS=[['for','Force','Dégâts au corps à corps, poids'],['int','Intelligence','Dégâts des sorts, contrôles'],['dex','Dextérité','Précision, esquive, critique, distance'],['con','Constitution','PV et défense'],['sag','Sagesse','PM, soins et buffs']];
function crLeft(){return START_PTS-Object.values(cr.al).reduce((a,b)=>a+b,0);}
function showStats(){scr('sStats');const C=CLASSES[cr.cls];$('#stPrev').src=$('#crPrev').src;
  $('#stRows').innerHTML=STAT_ROWS.map(([k,n,d])=>`<div class="strow"><span><b>${n}</b><small>${d}</small></span><button class="arr" data-k="${k}" data-d="-1" type="button" ${cr.al[k]<=0?'disabled':''}>◀</button><b class="sv ${cr.al[k]?'up':''}">${C.base[k]+cr.al[k]}</b><button class="arr" data-k="${k}" data-d="1" type="button" ${crLeft()<=0?'disabled':''}>▶</button></div>`).join('')+`<div class="stpts">Points <b>${crLeft()}</b></div>`;
  $('#hcTog').setAttribute('aria-pressed',cr.hc2);$('#hcTog').textContent=cr.hc2?'Hardcore : activé':'Hardcore : désactivé';}
$('#stRows').addEventListener('click',e=>{const b=e.target.closest('.arr');if(!b||b.disabled)return;const k=b.dataset.k,d=+b.dataset.d;if(d>0&&crLeft()>0)cr.al[k]++;if(d<0&&cr.al[k]>0)cr.al[k]--;showStats();});
$('#hcTog').onclick=()=>{cr.hc2=!cr.hc2;showStats();};
$('#stBack').onclick=showCreate;
$('#stOk').onclick=()=>{const c=newChar(cr.name,cr.cls,cr.fac,cr.hc2);c.look2={fem:cr.fem,hs:cr.hs,hc:cr.hc,sk:cr.sk};for(const k of STATS5)c.al[k]=cr.al[k];c.pts=crLeft();
  CHARS.push(c);saveJSON(CHAR_KEY,CHARS);cr.name='';cr.al={for:0,dex:0,int:0,con:0,sag:0};startGame(CHARS.length-1);};
preview=function(cls,fac,c){const s=humSprite(c?playerLook(c):playerLook({cls,fac,eq:{}}),1).d[0],n=cnv(s.width,s.height);n.getContext('2d').drawImage(s,0,0);return n;};
showChars=(function(orig){return function(){orig();for(const [i,cc] of CHARS.entries()){const card=$('#charList').children[i];if(!card)continue;const old=card.querySelector('canvas');if(old){const s=humSprite(playerLook(cc),2).d[0];const n=cnv(s.width,s.height);n.getContext('2d').drawImage(s,0,0);n.className='cpv';old.replaceWith(n);}}};})(showChars);
const _startGame=startGame;startGame=function(i){_startGame(i);if(!P.qs.done.M1){const pro=new Set(PROLOGUE);for(let j=chatLines.length-1;j>=0;j--)if(pro.has(chatLines[j].txt))chatLines.splice(j,1);renderChat();setTimeout(()=>showLore('Prologue',PROLOGUE.slice(0,2).join(' ')),1600);}P.bank=P.bank||{items:[],cons:{},res:{}};refreshLook();_porKey='';$('#pname').textContent=P.name;};
SAVE_FIELDS.push('look2','bank');

/* ---------- démarrage ---------- */
buildKingdomProps();buildKingdomSprites();buildKingdomQuests();setupHUD();mapCache.clear();showServers();
