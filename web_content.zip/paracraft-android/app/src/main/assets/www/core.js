'use strict';
/* ===================== Paracraft Online — données et utilitaires ===================== */
const TS=16;
/* ---------- vue : paysage forcé ---------- */
const VIEW={w:innerWidth,h:innerHeight,rot:false};
function evalMedia(q){if(!q||q==='all')return true;return q.split(',').some(part=>part.trim().split(/\s+and\s+/).every(t=>{t=t.trim();if(!t||t==='screen'||t==='all')return true;
  const m=t.match(/^\(\s*([a-z-]+)\s*:\s*([^)]+?)\s*\)$/);if(!m)return typeof matchMedia==='function'?matchMedia(t).matches:true;const [,f,v]=m,n=parseFloat(v);
  if(f==='max-width')return VIEW.w<=n;if(f==='min-width')return VIEW.w>=n;if(f==='max-height')return VIEW.h<=n;if(f==='min-height')return VIEW.h>=n;if(f==='orientation')return(VIEW.w>=VIEW.h?'landscape':'portrait')===v;
  return typeof matchMedia==='function'?matchMedia(t).matches:true;}));}
function updView(){const coarse=typeof matchMedia==='function'&&matchMedia('(pointer:coarse)').matches;VIEW.rot=!!(coarse&&innerHeight>innerWidth);
  VIEW.w=VIEW.rot?innerHeight:innerWidth;VIEW.h=VIEW.rot?innerWidth:innerHeight;const de=document.documentElement;if(!de||!de.classList)return;
  de.classList.toggle('rot',VIEW.rot);if(de.style&&de.style.setProperty){de.style.setProperty('--appw',VIEW.w+'px');de.style.setProperty('--apph',VIEW.h+'px');de.style.setProperty('--vw',(VIEW.w/100)+'px');}
  for(const sh of document.styleSheets||[]){let rules;try{rules=sh.cssRules;}catch(_){continue;}for(const r of rules||[])if(r.media&&r.type===4){if(r._orig==null)r._orig=r.media.mediaText;r.media.mediaText=VIEW.rot?(evalMedia(r._orig)?'all':'not all'):r._orig;}}}
const GX=e=>VIEW.rot?e.clientY:e.clientX,GY=e=>VIEW.rot?innerWidth-e.clientX:e.clientY;
const $=s=>document.querySelector(s);
const rnd=Math.random, rr=(a,b)=>a+rnd()*(b-a), ri=(a,b)=>Math.floor(rr(a,b+1)), pick=a=>a[Math.floor(rnd()*a.length)];
const clamp=(v,a,b)=>v<a?a:v>b?b:v;
const dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmtT=s=>{s=Math.max(0,Math.ceil(s));return Math.floor(s/60)+':'+String(s%60).padStart(2,'0');};
function mulberry(a){return()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};}
function hash(x,y){let h=(Math.imul(x|0,374761393)+Math.imul(y|0,668265263))|0;h=Math.imul(h^(h>>>13),1274126177);return((h^(h>>>16))>>>0)/4294967296;}
function vnoise(x,y){const xi=Math.floor(x),yi=Math.floor(y),xf=x-xi,yf=y-yi,s=t=>t*t*(3-2*t);const a=hash(xi,yi),b=hash(xi+1,yi),c=hash(xi,yi+1),d=hash(xi+1,yi+1),u=s(xf),v=s(yf);return a+(b-a)*u+(c-a)*v+(a-b-c+d)*u*v;}
function fbm(x,y){return vnoise(x,y)*.6+vnoise(x*2.1+17,y*2.1+5)*.3+vnoise(x*4.3+3,y*4.3+11)*.1;}
function strSeed(s){let h=2166136261;for(const c of s){h^=c.charCodeAt(0);h=Math.imul(h,16777619);}return h>>>0;}
function loadJSON(k,d){try{const s=localStorage.getItem(k);return s?JSON.parse(s):d;}catch(e){return d;}}
function saveJSON(k,v){try{localStorage.setItem(k,JSON.stringify(v));}catch(e){}}
const SET=Object.assign({joy:'flottant',btn:'normal',names:true,daynight:true,dmg:true,parts:true},loadJSON('paracraft_settings',{}));
const saveSettings=()=>saveJSON('paracraft_settings',SET);

/* ---------- factions : aucun chat, groupe ni commerce entre elles ---------- */
const FACTIONS={
  solarix:{n:'Solarix',full:"Solarix, l'Ordre et la Lumière",c:'#ffd36a',cape:'#b8862a',cap:'sol_cap',capN:'Aurelia',style:'o',d:'Cités fortifiées, discipline et armures étincelantes. Capitale : Aurelia.'},
  umbra:{n:'Umbra',full:"Umbra, le Chaos et l'Ombre",c:'#c09aff',cape:'#4a2a7a',cap:'umb_cap',capN:'Nocthar',style:'s',d:'Forces occultes, liberté sauvage et énergies crépusculaires. Capitale : Nocthar.'}};
const enemyOf=f=>f==='solarix'?'umbra':'solarix';

/* ---------- caractéristiques ---------- */
const STATS5=['for','dex','int','con','sag'];
const STATN={for:'Force (STR)',dex:'Dextérité (DEX)',int:'Intelligence (INT)',con:'Constitution (CON)',sag:'Sagesse (WIS)'};
const STATD={for:'Dégâts physiques au corps à corps, poids d’inventaire',dex:'Précision, esquive, coups critiques, dégâts à distance',int:'Dégâts des sorts, burst de zone, efficacité des contrôles',con:'PV max et défense physique',sag:'PM max, puissance des soins et des buffs'};

/* ---------- classes : triangle Tank / DPS / Support ---------- */
// k : type d'effet. lv : niveau requis pour l'utiliser. Tous les sorts s'apprennent par grimoire (rang 1 à 3).
const CLASSES={
  guerrier:{nom:'Guerrier',role:'Tank · contrôle · corps à corps',desc:'Corps à corps. PV et défense élevés, étourdissements. Force et Constitution.',main:'for',sec:'con',prio:['for','con'],
    base:{for:12,dex:6,int:2,con:11,sag:3},hp0:40,hpl:8,mp0:16,mpl:2,def0:5,range:26,cd:.62,ranged:false,
    look:{body:'#c8ccd6',body2:'#8a92a2',hair:'#5a3a22',legs:'#4a4f5c',boots:'#3a2a1e',belt:'#6b4a2b',extra:'helm',weapon:'sword',shield:'#8a7a5a'},
    sk:[{n:'Entaille lourde',s:'Entaille',k:'basic',lv:1,mp:[0,0,0],cd:[1.5,1.5,1.5],m:[1,1.15,1.3]},{n:'Charge sanguinaire',s:'Charge',k:'charge',lv:6,mp:[12,16,20],cd:[12,10,8],m:[1.2,1.4,1.6],slow:[.3,.45,.6]},{n:'Coup de bouclier',s:'Bouclier',k:'stun',lv:12,mp:[15,20,25],cd:[10,9,8],m:[1,1.2,1.4],stun:[1.5,2,2.5]},{n:'Provocation',s:'Provoc.',k:'taunt',lv:16,mp:[15,25,35],cd:[8,7,6],r:80},{n:'Balayage dévastateur',s:'Balayage',k:'aoe',lv:20,mp:[25,35,50],cd:[4,3.5,3],m:[1.6,1.9,2.2],r:52,max:6,col:'#f2c14e'},{n:'Cri de ralliement',s:'Ralliement',k:'rally',lv:28,mp:[30,45,60],cd:[45,40,35],v:[.15,.25,.35],dur:20},{n:'Exécution',s:'Exécution',k:'execute',lv:34,mp:[30,45,60],cd:[10,9,8],m:[1.5,1.8,2.1],th:[.3,.35,.4]},{n:'Fracasse-armure',s:'Fracasse',k:'sunder',lv:36,mp:[22,30,38],cd:[6,5,4],m:[1.2,1.3,1.4],v:[.2,.35,.5],dur:6},{n:'Bastion inébranlable',s:'Bastion',k:'bastion',lv:44,mp:[50,70,90],cd:[90,75,60],v:[.4,.6,.75],dur:6}],
    src:['Inné','PNJ de la cité (maître d’armes)','Mini-boss niv. 10–15 (Contremaître Krog)','Monstres élites','Butin rare des monstres niv. 18–24','Gardien du Phare des Éclats, étage 2','Monstres des zones contestées','Monstres des zones contestées','World boss niv. 40+'],tags:['inne','city','mini12','elite','rare','phare2','contest','contest','wb']},
  archer:{nom:'Archer',role:'DPS distance · mobilité · kiting',desc:'Arc et arbalète. Mobilité, critiques dévastateurs, tir en mouvement. Dextérité.',main:'dex',sec:'for',prio:['dex','for'],
    base:{for:7,dex:13,int:3,con:8,sag:3},hp0:26,hpl:6,mp0:20,mpl:3,def0:2,range:155,cd:.5,ranged:true,proj:{spd:300,col:'#f5e6a8',r:2},
    look:{body:'#4a7a3a',body2:'#2e5228',hair:'#d9a441',legs:'#5a4a32',boots:'#3a2a1a',belt:'#6b4a2b',extra:'hood',hood:'#2f4a2a',weapon:'bow'},
    sk:[{n:'Tir rapide',s:'Tir',k:'basic',lv:1,mp:[0,0,0],cd:[1.2,1.2,1.2],m:[1,1.12,1.25]},{n:'Flèche givrante',s:'Givre',k:'slowshot',lv:6,mp:[10,14,18],cd:[8,7,6],m:[1.1,1.25,1.4],slow:[.35,.5,.65]},{n:'Poste de traqueur',s:'Traqueur',k:'tracker',lv:12,mp:[18,25,32],cd:[30,30,30],v:[5,11,18],rng:[16,32,48],dur:30},{n:'Piège d’entraves',s:'Piège',k:'trap',lv:16,mp:[20,35,50],cd:[15,13,11],root:[2,3,4]},{n:'Tir multiple',s:'Multiple',k:'volley',lv:20,mp:[28,40,55],cd:[5,4.5,4],m:[1,1.15,1.3],cnt:5},{n:'Tir perçant',s:'Perçant',k:'pierce',lv:28,mp:[25,35,45],cd:[10,9,8],m:[2.2,2.5,2.8],ign:[.2,.33,.45]},{n:'Tir de snipe',s:'Snipe',k:'snipe',lv:34,mp:[35,50,70],cd:[12,10,8],m:[2.6,3,3.4],rng:[48,64,80]},{n:'Esquive acrobatique',s:'Esquive',k:'leap',lv:36,mp:[20,25,30],cd:[15,12,10],len:64,v:[15,20,25],dur:4},{n:'Pluie mortelle',s:'Pluie',k:'rain',lv:44,mp:[60,80,100],cd:[25,20,15],m:[1.4,1.6,1.8],r:80,waves:[3,4,4]}],
    src:['Inné','PNJ de la cité (maître d’armes)','Mini-boss niv. 10–15 (Contremaître Krog)','Mini-boss niv. 15–20 (Ours des Ronces)','Butin rare des monstres niv. 18–24','Gardien du Phare des Éclats, étage 2','Monstres des zones contestées','Monstres des zones contestées','World boss niv. 40+'],tags:['inne','city','mini12','mini16','rare','phare2','contest','contest','wb']},
  mage:{nom:'Mage',role:'Support · soigneur · magie de zone',desc:'Seul à soigner et à renforcer ses alliés. Sorts de zone et immobilisations. Intelligence et Sagesse.',main:'int',sec:'sag',prio:['int','sag'],
    base:{for:2,dex:5,int:13,con:7,sag:9},hp0:16,hpl:5,mp0:24,mpl:5,def0:1,range:145,cd:.72,ranged:true,proj:{spd:235,col:'#c58cff',r:3},
    look:{body:'#5a3f9a',body2:'#3e2a70',hair:'#e8e0f0',legs:'#3e2c70',boots:'#2a1d4a',belt:'#f2c14e',extra:'hat',hat:'#4a2f88',robe:true,weapon:'staff',orb:'#c58cff'},
    sk:[{n:'Éclair électrique',s:'Éclair',k:'basic',lv:1,mp:[0,0,0],cd:[1.5,1.5,1.5],m:[1,1.15,1.3]},{n:'Soin lumineux',s:'Soin',k:'heal',lv:6,mp:[18,30,45],cd:[2.5,2,1.5],v:[.22,.3,.38]},{n:'Prison d’ombre',s:'Prison',k:'root',lv:12,mp:[22,30,40],cd:[12,10,8],m:[.8,.9,1],root:[2.5,3.5,4.5]},{n:'Barrière arcanique',s:'Barrière',k:'shield',lv:15,mp:[30,50,75],cd:[12,10,8],v:[200,500,800],dur:20},{n:'Malédiction',s:'Malédic.',k:'curse',lv:16,mp:[25,40,60],cd:[10,9,8],v:[.15,.25,.35],dur:[6,8,10]},{n:'Tempête élémentaire',s:'Tempête',k:'storm',lv:20,mp:[35,55,80],cd:[4,3.5,3],m:[1.7,2,2.3],r:64,max:6},{n:'Flux de mana et bénédiction',s:'Bénédic.',k:'benison',lv:28,mp:[40,60,80],cd:[60,60,60],v:[.08,.12,.16],dur:600},{n:'Téléportation',s:'Téléport',k:'blink',lv:34,mp:[40,60,80],cd:[16,13,10],len:[64,96,128]},{n:'Soin majeur de zone',s:'Soin zone',k:'massheal',lv:36,mp:[65,95,130],cd:[8,7,6],v:[.3,.4,.5],r:128},{n:'Apocalypse',s:'Apocal.',k:'apoca',lv:44,mp:[90,130,180],cd:[20,16,12],m:[3.5,4.2,5],r:96}],
    src:['Inné','PNJ de la cité (maître d’armes)','Mini-boss niv. 10–15 (Contremaître Krog)','Mini-boss niv. 15–20 (Ours des Ronces)','Mini-boss niv. 15–20 (Ours des Ronces)','Butin rare des monstres niv. 18–24','Gardien du Phare des Éclats, étage 2','Donjons et zones niv. 35+','Monstres des zones contestées','World boss niv. 40+'],tags:['inne','city','mini12','mini16','mini16','rare','phare2','d35','contest','wb']},
};
const PTS_LVL={normal:4,hc:6};
const MAX_LVL=50;
// Courbe d'expérience : ~220 h de jeu effectif pour atteindre le niveau 50 (environ 5 mois à 1 h 30 par jour).
// heures par niveau = 0,07·e^(0,12·niv) ; XP/heure = 375 × XP d'un monstre du même niveau (≈ 300 kills/h + quêtes).
const monXpAt=l=>6+l*4+l*l*.25;
const xpHours=l=>.07*Math.exp(.12*l)*(l<5?.5:1);
const xpNeed=l=>Math.round(xpHours(l)*375*monXpAt(l)/10)*10;
const deathXpLoss=l=>l<=20?.05:l<=40?.1:.15;

/* ---------- équipement : 9 emplacements, 10 paliers jusqu'au niveau 50 ---------- */
const SLOTS=['arme','second','casque','armure','gants','bottes','collier','anneau1','anneau2'];
const SLOT_N={arme:'Arme',second:'Main gauche',casque:'Casque',armure:'Armure',gants:'Gants',bottes:'Bottes',collier:'Collier',anneau:'Anneau',anneau1:'Anneau',anneau2:'Anneau'};
const TIER_REQ=[1,6,11,16,21,26,31,36,41,46];
const MATS=['de bronze','de fer','d’acier','runique','d’obsidienne','de mithril','du crépuscule','draconique','céleste','primordial'];
const BASEN={arme:{guerrier:['Épée','Hache','Lame'],archer:['Arc','Arbalète','Arc long'],mage:['Bâton','Sceptre','Grimoire']},
  second:{guerrier:['Bouclier'],archer:['Carquois'],mage:['Orbe']},casque:['Casque'],armure:['Armure'],gants:['Gantelets'],bottes:['Bottes'],collier:['Collier'],anneau:['Anneau']};
const RAR=['Commun','Rare','Épique','Légendaire','Unique'];
const RARC=['#d8cfbf','#b98cff','#5fe0ea','#ffd36a','#ff7a3a'];
const RARM=[1,1.22,1.5,1.9,2.4];
const BONUS_KEYS=['for','dex','int','con','sag','crit','hp'];
const BONUS_N={for:'Force',dex:'Dextérité',int:'Intelligence',con:'Constitution',sag:'Sagesse',crit:'Critique %',hp:'PV'};

/* ---------- métiers façon Dofus ---------- */
const RES={
  frene:{n:'Bois de frêne',prof:'bucheron',lvl:1,tier:0},chene:{n:'Bois de chêne',prof:'bucheron',lvl:10,tier:1},if:{n:"Bois d'if",prof:'bucheron',lvl:20,tier:2},spectral:{n:'Bois spectral',prof:'bucheron',lvl:30,tier:3},
  fer:{n:'Minerai de fer',prof:'mineur',lvl:1,tier:0},cristal:{n:'Cristal',prof:'mineur',lvl:10,tier:1},mithril:{n:'Mithril',prof:'mineur',lvl:20,tier:2},obsidienne:{n:'Obsidienne',prof:'mineur',lvl:30,tier:3},
  ortie:{n:'Ortie',prof:'herboriste',lvl:1,tier:0},sauge:{n:'Sauge',prof:'herboriste',lvl:10,tier:1},trefle:{n:'Trèfle lunaire',prof:'herboriste',lvl:20,tier:2},mandragore:{n:'Mandragore',prof:'herboriste',lvl:30,tier:3},
  goujon:{n:'Goujon',prof:'pecheur',lvl:1,tier:0},truite:{n:'Truite',prof:'pecheur',lvl:10,tier:1},anguille:{n:'Anguille',prof:'pecheur',lvl:20,tier:2},poissonlune:{n:'Poisson-lune',prof:'pecheur',lvl:30,tier:3},
};
const WOOD=['frene','chene','if','spectral'],ORE=['fer','cristal','mithril','obsidienne'],HERB=['ortie','sauge','trefle','mandragore'],FISH=['goujon','truite','anguille','poissonlune'];
const RES_PRICE=[6,14,30,60];
const PROFS={bucheron:{n:'Bûcheron',k:'r',verb:'Couper'},mineur:{n:'Mineur',k:'r',verb:'Miner'},herboriste:{n:'Herboriste',k:'r',verb:'Cueillir'},pecheur:{n:'Pêcheur',k:'r',verb:'Pêcher'},
  forgeron:{n:'Forgeron',k:'c',d:'Armes et main gauche'},armurier:{n:'Armurier',k:'c',d:'Casques, armures, gants, bottes'},bijoutier:{n:'Bijoutier',k:'c',d:'Colliers et anneaux'},alchimiste:{n:'Alchimiste',k:'c',d:'Potions, élixirs et parchemins'},cuisinier:{n:'Cuisinier',k:'c',d:'Plats qui donnent des bonus'}};
const PROF_MAX=50;
const profNeed=l=>Math.round(22*Math.pow(l,1.45));
const CONS={
  pv:{n:'Potion de vie',d:'Rend 45 % des PV.',price:12},
  pm:{n:'Potion de mana',d:'Rend 50 % des PM.',price:12},
  ench1:{n:"Parchemin d'enchantement mineur",d:'Enchante un objet de +0 à +4.',price:60},
  ench2:{n:"Parchemin d'enchantement majeur",d:'Enchante un objet de +4 à +7.',price:400},
  ench3:{n:"Parchemin d'enchantement divin",d:'Enchante un objet de +7 à +10.',price:2500},
  elxp:{n:'Élixir de sagesse',d:'+30 % d’XP pendant 10 min.',buff:{id:'elxp',n:'Sagesse',xp:.3,t:600},price:120},
  elatk:{n:'Élixir de puissance',d:'+15 % d’attaque pendant 10 min.',buff:{id:'elatk',n:'Puissance',atk:.15,t:600},price:140},
  parch:{n:"Parchemin d'expérience",d:'+50 % d’XP pendant 15 min.',buff:{id:'parch',n:'Parchemin',xp:.5,t:900},price:300},
  retour:{n:'Parchemin de retour',d:'Te ramène à ta capitale.',price:30},
  plat1:{n:'Goujon grillé',d:'Régénération doublée pendant 10 min.',buff:{id:'food',n:'Repas',regen:1,t:600},price:20},
  plat2:{n:'Truite aux herbes',d:'+8 % de PV max pendant 10 min.',buff:{id:'food',n:'Repas',hp:.08,t:600},price:40},
  plat3:{n:'Anguille fumée',d:'+10 % de défense pendant 10 min.',buff:{id:'food',n:'Repas',def:.1,t:600},price:70},
  plat4:{n:'Festin de poisson-lune',d:'+10 % PV, attaque et défense pendant 10 min.',buff:{id:'food',n:'Festin',hp:.1,atk:.1,def:.1,t:600},price:120},
};
// livres de compétences : livre_<classe>_<index>
for(const ck in CLASSES)CLASSES[ck].sk.forEach((s,i)=>{if(i>0)CONS['livre_'+ck+'_'+i]={n:'Grimoire : '+s.n,d:`Apprend « ${s.n} » (${CLASSES[ck].nom}, niv. ${s.lv}), ou monte son rang. Rang max 3.`,book:{cls:ck,i},price:Math.round(150+s.lv*s.lv*1.5)};});
const CRAFT_LVL=[1,6,12,17,22,27,32,37,42,47], CRAFT_RT=[0,0,1,1,2,2,3,3,3,3], CRAFT_XP=[12,20,30,42,56,72,90,110,135,160];
const RECIPES=[];
(function(){
  for(let t=0;t<10;t++){const r=CRAFT_RT[t],q=1+Math.floor(t/2);
    for(const cls of ['guerrier','archer','mage']){
      RECIPES.push({id:'arme_'+cls+t,prof:'forgeron',lvl:CRAFT_LVL[t],cls,out:{eq:'arme',tier:t,cls},ing:{[WOOD[r]]:2+q,[ORE[r]]:2+q},xp:CRAFT_XP[t]});
      RECIPES.push({id:'sec_'+cls+t,prof:'forgeron',lvl:CRAFT_LVL[t],cls,out:{eq:'second',tier:t,cls},ing:{[WOOD[r]]:1+q,[ORE[r]]:2+q},xp:CRAFT_XP[t]});}
    for(const sl of ['casque','armure','gants','bottes'])RECIPES.push({id:sl+t,prof:'armurier',lvl:CRAFT_LVL[t],out:{eq:sl,tier:t},ing:sl==='armure'?{[ORE[r]]:3+q,[WOOD[r]]:1+q}:{[ORE[r]]:2+q,[HERB[r]]:1+q},xp:CRAFT_XP[t]});
    for(const sl of ['collier','anneau'])RECIPES.push({id:sl+t,prof:'bijoutier',lvl:CRAFT_LVL[t],out:{eq:sl,tier:t},ing:{[ORE[r]]:1+q,[HERB[r]]:2+q},xp:CRAFT_XP[t]});
  }
  const C=(id,prof,lvl,cons,n,ing,xp)=>RECIPES.push({id,prof,lvl,out:{cons,n},ing,xp});
  C('c_pv','alchimiste',1,'pv',2,{ortie:3},10);C('c_pm','alchimiste',5,'pm',2,{ortie:2,frene:1},14);C('c_ret','alchimiste',10,'retour',1,{sauge:2,chene:1},24);
  C('c_e1','alchimiste',15,'ench1',1,{sauge:3,cristal:2},34);C('c_elxp','alchimiste',20,'elxp',1,{trefle:3,sauge:2},42);C('c_e2','alchimiste',28,'ench2',1,{trefle:4,mithril:3},62);
  C('c_elatk','alchimiste',30,'elatk',1,{mandragore:3,obsidienne:1},70);C('c_e3','alchimiste',42,'ench3',1,{mandragore:6,obsidienne:5,spectral:3},120);
  C('c_p1','cuisinier',1,'plat1',1,{goujon:2},10);C('c_p2','cuisinier',10,'plat2',1,{truite:2,sauge:1},26);C('c_p3','cuisinier',20,'plat3',1,{anguille:2,trefle:1},46);C('c_p4','cuisinier',30,'plat4',1,{poissonlune:2,mandragore:1},80);
})();

/* ---------- monstres : le niveau est donné par la carte ---------- */
// rôle : m mêlée, r tir visé, s éventail, c anneau, sp spirale. mini : mini-boss (livres). wb : boss de monde.
const MT={
  slime:{n:'Slime',role:'m',spr:'slime',spd:28,hp:.9},loup:{n:'Loup gris',role:'m',spr:'loup',spd:54},
  slimeb:{n:'Slime d’ombre',role:'m',spr:'slimeb',spd:28,hp:.9},renard:{n:'Renard crépusculaire',role:'m',spr:'renard',spd:56},
  sanglier:{n:'Sanglier',role:'m',spr:'sanglier',spd:46,hp:1.2},gobelin:{n:'Gobelin pillard',role:'m',spr:'gobelin',spd:44},
  champi:{n:'Champignon',role:'m',spr:'champi',spd:30,hp:1.2},farfadet:{n:'Farfadet',role:'r',spr:'farfadet',spd:40,keep:85},
  squelette:{n:'Squelette archer',role:'r',spr:'squelette',spd:34,keep:92},araignee:{n:'Araignée sylvestre',role:'m',spr:'araignee',spd:50},
  ours:{n:'Ours des Ronces',boss:1,mini:1,role:'m',spr:'ours',spd:42,slam:1},
  brigand:{n:'Brigand',role:'m',spr:'brigand',spd:46},renegat:{n:'Arbalétrier renégat',role:'s',spr:'renegat',spd:38,keep:100},
  sorciere:{n:'Sorcière des marais',role:'c',spr:'sorciere',spd:30,keep:82},crapaud:{n:'Crapaud géant',role:'m',spr:'crapaud',spd:38,hp:1.3},
  scorpion:{n:'Scorpion des sables',role:'m',spr:'scorpion',spd:46},momie:{n:'Momie',role:'s',spr:'momie',spd:30,keep:90},
  reinescorp:{n:'Reine scorpion',boss:1,mini:1,role:'m',spr:'reinescorp',spd:44,slam:1},
  golem:{n:'Golem de cendre',role:'m',spr:'golem',spd:26,hp:1.5},demon:{n:'Démon mineur',role:'s',spr:'demon',spd:44,keep:100},
  kobold:{n:'Kobold mineur',role:'m',spr:'kobold',spd:46},chauve:{n:'Chauve-souris',role:'m',spr:'chauve',spd:64,hp:.7},
  krog:{n:'Contremaître Krog',boss:1,mini:1,role:'m',spr:'krog',spd:40,slam:1},
  noye:{n:'Noyé',role:'m',spr:'noye',spd:36},serpent:{n:'Serpent du temple',role:'r',spr:'serpent',spd:40,keep:90},
  hydre:{n:'Hydre des profondeurs',boss:1,mini:1,role:'c',spr:'hydre',spd:20,keep:100},
  sqnoir:{n:'Squelette noir',role:'m',spr:'sqnoir',spd:42},spectre:{n:'Spectre',role:'c',spr:'spectre',spd:40,keep:80},
  liche:{n:'Seigneur Liche',boss:1,mini:1,role:'sp',spr:'liche',spd:22,keep:110},
  titan:{n:'Titan de cendre',boss:1,wb:1,role:'c',spr:'titan',spd:24,slam:1,keep:60},
  wyrm:{n:'Wyrm du Néant',boss:1,wb:1,role:'sp',spr:'wyrm',spd:20,keep:120},
};
const PASSIVE=['slime','slimeb','renard','sanglier','champi','crapaud','scorpion'];
for(const k in MT)MT[k].agr=!PASSIVE.includes(k);
function monStats(type,lv,elite){const t=MT[type],b=t.wb?40:t.boss?12:1,e=elite?3:1;
  return{maxhp:Math.round((50+lv*45+lv*lv*1.2)*(t.hp||1)*b*e),dmg:Math.round((4+lv*2.1)*(t.role==='m'?1:.8)*(t.wb?2:t.boss?1.5:1)*(elite?1.4:1)),def:Math.round(lv*.7*(t.boss?1.4:1)),
    xp:Math.round((6+lv*4+lv*lv*.25)*(t.wb?40:t.boss?14:1)*(elite?4:1)),gold:t.boss?[lv*20*e,lv*40*e]:[Math.round((4+lv*1.5)*e),Math.round((10+lv*3.5)*e)],aggro:t.boss?200:(t.keep?135:90),respawn:t.wb?1e9:t.boss?900:20};}
/* couleur du nom selon l'écart de niveau, et part d'XP */
function lvlColor(mlv,plv){const d=mlv-plv;
  if(d<=-7)return{c:'#8f8a99',n:'Trop faible : aucune XP',x:0};
  if(d<=-4)return{c:'#5ab85a',n:'Très facile : '+Math.round((.5-(-d-4)*.12)*100)+' % d’XP',x:.5-(-d-4)*.12};
  if(d<=-2)return{c:'#9be36a',n:'Facile : 80 % d’XP',x:.8};
  if(d<=2)return{c:'#f1e9d6',n:'Équilibré : 100 % d’XP',x:1};
  if(d<=4)return{c:'#ffd84a',n:'Difficile : +25 % XP, frappe plus fort',x:1.25};
  if(d<=7)return{c:'#ff9a3a',n:'Dangereux : +50 % XP, tu rates souvent',x:1.5};
  return{c:'#ff4a4a',n:'Mortel : +60 % XP, presque intouchable',x:1.6};}
/* écart de niveau : dégâts reçus et infligés */
function gapMul(mlv){const d=mlv-(P?P.lvl:mlv);return d>0?1+d*.08:Math.max(.6,1+d*.03);}

/* ---------- cartes façon TWOM ---------- */
// 1 à 20 : territoires sûrs de faction. 21 à 50 : zones contestées, PvP sauvage permanent.
const MAPS={
  sol_cap:{n:'Aurelia',side:'solarix',kind:'city',style:'o',lv:[1,50],w:60,h:46,ex:{e:'sol_1'}},
  sol_1:{n:'Plaines dorées',side:'solarix',biome:'meadow',lv:[1,6],tier:0,ex:{w:'sol_cap',e:'sol_2'},mons:[['slime',16,2],['loup',14,4]]},
  sol_2:{n:'Collines de Brasse',side:'solarix',biome:'hills',lv:[6,11],tier:1,ex:{w:'sol_1',e:'sol_3'},mons:[['sanglier',14,7],['gobelin',14,9]],dungeon:'mine'},
  sol_3:{n:'Bois de l’Aube',side:'solarix',biome:'forest',lv:[11,16],tier:1,ex:{w:'sol_2',e:'sol_4'},mons:[['squelette',13,13],['araignee',13,14],['ours',1,16]]},
  sol_4:{n:'Remparts du Levant',side:'solarix',biome:'steppe',lv:[16,21],tier:2,ex:{w:'sol_3',e:'c_front'},mons:[['brigand',14,18],['renegat',12,19]]},
  umb_cap:{n:'Nocthar',side:'umbra',kind:'city',style:'s',lv:[1,50],w:60,h:46,ex:{w:'umb_1'}},
  umb_1:{n:'Landes du Crépuscule',side:'umbra',biome:'moon',lv:[1,6],tier:0,ex:{e:'umb_cap',w:'umb_2'},mons:[['slimeb',16,2],['renard',14,4]]},
  umb_2:{n:'Vallon des Lucioles',side:'umbra',biome:'vale',lv:[6,11],tier:1,ex:{e:'umb_1',w:'umb_3'},mons:[['champi',14,7],['farfadet',14,9]],dungeon:'mine'},
  umb_3:{n:'Forêt Noire',side:'umbra',biome:'forest',lv:[11,16],tier:1,ex:{e:'umb_2',w:'umb_4'},mons:[['squelette',13,13],['araignee',13,14],['ours',1,16]]},
  umb_4:{n:'Tourbières maudites',side:'umbra',biome:'swamp',lv:[16,21],tier:2,ex:{e:'umb_3',w:'c_front'},mons:[['sorciere',14,18],['crapaud',12,19]]},
  c_front:{n:'La Frontière',side:null,pvp:true,biome:'steppe',lv:[21,26],tier:2,ex:{w:'sol_4',e:'umb_4',n:'c_marais',s:'c_desert'},mons:[['brigand',14,22],['renegat',12,24]],fort:true},
  c_marais:{n:'Marais de Brume',side:null,pvp:true,biome:'swamp',lv:[24,30],tier:2,ex:{s:'c_front'},mons:[['sorciere',14,26],['crapaud',14,28]],dungeon:'temple'},
  c_desert:{n:'Désert de Kharan',side:null,pvp:true,biome:'desert',lv:[30,36],tier:3,ex:{n:'c_front',s:'c_maudit'},mons:[['scorpion',16,32],['momie',13,34],['reinescorp',1,36]]},
  c_maudit:{n:'Terres maudites',side:null,pvp:true,biome:'ash',lv:[36,42],tier:3,ex:{n:'c_desert',s:'c_abysse'},mons:[['golem',14,38],['demon',14,40]],dungeon:'citadelle',wb:['titan',43]},
  c_abysse:{n:'Abysses du Néant',side:null,pvp:true,biome:'abyss',lv:[42,50],tier:3,ex:{n:'c_maudit'},mons:[['spectre',14,44],['sqnoir',14,46],['demon',10,48]],wb:['wyrm',50]},
};
const DUNGEONS={
  mine:{n:'Mine abandonnée',lv:[8,12],floors:2,style:'cave',mons:[['kobold',9],['chauve',10]],boss:['krog',12]},
  temple:{n:'Temple englouti',lv:[26,30],floors:3,style:'temple',mons:[['noye',27],['serpent',28]],boss:['hydre',30]},
  citadelle:{n:'Citadelle de la Liche',lv:[40,45],floors:3,style:'crypt',mons:[['sqnoir',42],['spectre',43]],boss:['liche',45]},
};
const WORLD_LAYOUT={sol_cap:[0,1],sol_1:[1,1],sol_2:[2,1],sol_3:[3,1],sol_4:[4,1],c_front:[5,1],umb_4:[6,1],umb_3:[7,1],umb_2:[8,1],umb_1:[9,1],umb_cap:[10,1],c_marais:[5,0],c_desert:[5,2],c_maudit:[5,3],c_abysse:[5,4]};

/* ---------- lore ---------- */
const PROLOGUE=["Il y a trois siècles, le Prisme d'Éther, cœur de cristal qui liait la magie au monde, s'est brisé : c'est la Fracture.",
 "Ses éclats se sont dispersés sur toutes les terres. Là où ils tombent, les bêtes deviennent folles et les morts se relèvent.",
 "Des éclats sont nés les Grimoires : chaque sort de ce monde dort dans un livre, et seul celui qui le lit peut l'éveiller.",
 "Solarix, héritière de l'Ordre de l'Aube, veut rassembler les éclats et reforger le Prisme pour une lumière éternelle.",
 "Umbra, née du Conclave du Crépuscule, refuse ce joug : elle veut que chaque éclat reste libre, comme la magie elle-même.",
 "Entre les deux, au plus profond des Abysses, le Wyrm du Néant dévore les éclats perdus et grandit."];
const MAP_LORE={
  sol_cap:"Aurelia, la Cité de l'Aube. Ses remparts furent bâtis avec la pierre blanche tombée du ciel la nuit de la Fracture.",
  sol_1:"Les Plaines dorées nourrissent Aurelia. Depuis que des éclats y sont tombés, même les slimes deviennent agressifs à la nuit.",
  sol_2:"Les Collines de Brasse abritaient les forges de l'Ordre. La vieille mine fut fermée le jour où l'on y trouva un éclat noir.",
  sol_3:"Le Bois de l'Aube garde les tombes des chevaliers de la Première Guerre. Leurs os ne reposent plus en paix.",
  sol_4:"Les Remparts du Levant sont la dernière ligne avant la Frontière. Ici, la loi d'Aurelia cède la place à celle du plus fort.",
  umb_cap:"Nocthar, la Cité du Crépuscule, grandit autour de l'Arbre d'Ombre, né d'un éclat planté par le premier Conclave.",
  umb_1:"Les Landes du Crépuscule ne connaissent jamais vraiment le jour. Les renards y suivent les âmes égarées.",
  umb_2:"Dans le Vallon des Lucioles, chaque lueur serait une parcelle d'éclat. Les farfadets les protègent jalousement.",
  umb_3:"La Forêt Noire fut le premier champ de bataille entre l'Aube et le Crépuscule. Les morts y montent encore la garde.",
  umb_4:"Les Tourbières maudites marquent la frontière d'Umbra. Les sorcières y distillent la brume des éclats.",
  c_front:"La Frontière n'appartient à personne. Au centre, le Fort Brisé change de bannière à chaque guerre.",
  c_marais:"Le Marais de Brume a englouti le Temple de l'Éther. Ce qui garde ses salles n'a plus rien d'humain.",
  c_desert:"Le Désert de Kharan était une mer avant la Fracture. Les scarabées d'éther y nichent dans le sable vitrifié.",
  c_maudit:"Les Terres maudites entourent la citadelle du roi Morvhal, premier mortel à avoir touché le Prisme.",
  c_abysse:"Les Abysses du Néant s'ouvrent là où le Prisme a explosé. Le Wyrm y sommeille sur un lit d'éclats.",
};
const STELE_LORE={
  sol_1:"« Ici tomba le premier éclat de l'Aube. Que sa lumière guide les justes. » Gravé au nom de la reine Aurélienne.",
  sol_2:"« La forge ne ment pas : le fer révèle ce que l'homme cache. » Devise des maîtres forgerons de Brasse.",
  sol_3:"« Nous sommes tombés pour l'Aube. Ne laissez pas l'Ombre réveiller nos os. » Stèle des Chevaliers de la Première Guerre.",
  sol_4:"« Premier jour de la Fracture : le ciel s'ouvrit et le Prisme pleura mille larmes de cristal. »",
  umb_1:"« Le crépuscule n'est pas la fin du jour, c'est l'instant où tout est encore possible. » Premier Conclave.",
  umb_2:"« Qui capture une luciole éteint un rêve. » Inscription laissée par les farfadets.",
  umb_3:"« L'Aube voulut tout éclairer. Nous avons choisi de laisser une part d'ombre au monde. » Stèle des Veilleurs.",
  umb_4:"« Premier jour de la Fracture : la brume monta des tourbières et chanta le nom de chaque éclat. »",
  c_front:"« Ce fort a porté trente bannières. Aucune n'est restée. » Écrit à la main sous un blason effacé.",
  c_marais:"« Le temple garde le Cœur Noyé. L'hydre ne dort que lorsque l'eau est calme. »",
  c_desert:"« Kharan était une mer. Elle reviendra le jour où le Prisme sera entier. » Prophétie nomade.",
  c_maudit:"« Moi, Morvhal, j'ai touché le Prisme et j'ai vu l'éternité. Elle avait faim. »",
  c_abysse:"« Tout ce qui est brisé finit ici. Même les dieux. » Gravure sans auteur, à demi fondue.",
};
const CAMPS={
  sol_1:{qid:'camp1',n:'Éclaireuse Maelis',r:'Éclaireuse',g:"Les plaines sont calmes le jour, mais la nuit les bêtes changent. Garde l'œil ouvert."},
  sol_2:{qid:'camp2',n:'Prospecteur Odran',r:'Prospecteur',g:"La mine nous a tout donné, puis tout repris. Il paraît que Krog y rôde encore."},
  sol_3:{qid:'camp3',n:'Garde forestier Hal',r:'Garde forestier',g:"Ces bois sont un cimetière. Respecte les morts, mais ne leur tourne jamais le dos."},
  sol_4:{qid:'camp4',n:'Sergent Vauclair',r:'Sergent',g:"Au-delà de ce rempart, plus personne ne te protège. Ici, on apprend à tenir."},
  umb_1:{qid:'camp1',n:'Rôdeuse Isk',r:'Rôdeuse',g:"Les landes parlent à ceux qui écoutent. En ce moment, elles hurlent."},
  umb_2:{qid:'camp2',n:'Herboriste Syl',r:'Herboriste',g:"Chaque plante du vallon a bu un peu d'éclat. Certaines guérissent, d'autres mordent."},
  umb_3:{qid:'camp3',n:'Chasseur Korv',r:'Chasseur',g:"La Forêt Noire a ses propres règles. La première : ne jamais suivre une lumière."},
  umb_4:{qid:'camp4',n:'Nécromante Elva',r:'Nécromante',g:"Les morts me parlent de la Frontière. Ils disent que tu y laisseras des plumes."},
  c_front:{qid:'front',n:'Mercenaire Dorg',r:'Mercenaire',g:"Solarix, Umbra, je m'en moque. Ici, seul l'or a une bannière.",shop:1},
  c_marais:{qid:'marais',n:'Ermite Bal',r:'Ermite',g:"Le marais garde tout ce qu'on y jette. Les secrets surtout.",shop:1},
  c_desert:{qid:'desert',n:'Nomade Saïra',r:'Nomade',g:"Le sable se souvient de la mer. Écoute-le, et tu trouveras l'eau.",shop:1},
  c_maudit:{qid:'maudit',n:'Exorciste Wren',r:'Exorciste',g:"Morvhal n'est pas mort. Il attend. Comme tout ce qui vit ici.",shop:1},
  c_abysse:{qid:'abysse',n:'Le Gardien Oublié',r:'Gardien',g:"Tu es venu jusqu'au bord du monde. Peu en reviennent.",shop:1},
};
const QITEM={slime:'Gelée de slime',loup:'Croc de loup',slimeb:"Gelée d'ombre",renard:'Queue de renard',sanglier:'Défense de sanglier',gobelin:'Oreille de gobelin',champi:'Spore lumineuse',farfadet:'Clochette de farfadet',squelette:'Sceau ancien',araignee:'Soie sylvestre',brigand:'Insigne de brigand',renegat:'Carreau gravé',sorciere:'Fiole de brume',crapaud:'Peau visqueuse',scorpion:"Scarabée d'éther",momie:'Bandelette maudite',golem:'Cœur de cendre',demon:'Corne de démon',spectre:'Ectoplasme',sqnoir:'Os noir'};
const SIDE_TOK={solarix:{m1a:'slime',m1b:'loup',m2a:'sanglier',m2b:'gobelin',m4a:'brigand',m4b:'renegat',s:'sol_'},umbra:{m1a:'slimeb',m1b:'renard',m2a:'champi',m2b:'farfadet',m4a:'sorciere',m4b:'crapaud',s:'umb_'}};
/* campagne principale : {pm1a} = nom pluriel d'un monstre, {z1} = carte, {camp1} = PNJ */
const MAIN=[
 {id:'M1',t:'Le serment',giver:'cap',lvl:1,d:"Bienvenue à {cap}, recrue. Depuis la Fracture, les éclats du Prisme rendent les bêtes folles, et {fac} a besoin de bras. Prouve ta valeur : élimine 6 {pm1a} aux portes de la cité.",obj:[{k:'kill',m:'{m1a}',n:6}],rew:{xp:60,gold:40,book:1},fin:"Bien. Ton premier sort, tu l'as en toi. Les autres dorment dans des grimoires : prends celui-ci, tu pourras t'en servir au niveau 6."},
 {id:'M2',t:'La voix des grimoires',giver:'cap',req:'M1',lvl:1,d:"Ouvre ton sac et lis le grimoire, puis utilise trois fois ton sort inné, la première case de ta barre. Sans livre, aucun mage, aucun guerrier ne progresse.",obj:[{k:'learn',n:1},{k:'cast',n:3}],rew:{xp:80,cons:{pv:5}},fin:"Tu l'as senti ? C'est l'éclat qui parle à travers toi."},
 {id:'M3',t:"L'avant-poste",giver:'cap',req:'M2',lvl:2,d:"Notre avant-poste de {z1} attend des renforts. Rejoins {camp1} à son campement, à l'est de la route.",obj:[{k:'talk',q:'camp1',n:1}],end:'camp1',rew:{xp:90},fin:"Ah, enfin quelqu'un. {cap} ne m'a pas oubliée, donc."},
 {id:'M4',t:'Crocs et éclats',giver:'camp1',req:'M3',lvl:2,d:"Les {pm1b} avalent les éclats tombés dans l'herbe, et ça les rend fous. Rapporte-moi 6 éclats ternis : on les mettra en sûreté.",obj:[{k:'collect',m:'{m1b}',it:'Éclat terni',p:.45,n:6}],rew:{xp:240,gold:90,item:1},fin:"Six éclats… et ce n'est qu'une poignée. Tiens, prends cet équipement, il te servira mieux qu'à moi."},
 {id:'M5',t:'Les métiers du peuple',giver:'camp1',req:'M4',lvl:3,d:"On ne gagne pas une guerre qu'avec l'épée. Récolte des ressources sur les nœuds qui scintillent, puis fabrique un élixir à l'alambic du camp : c'est l'Alchimie de guerre. Rien ne s'y crée sans risque.",obj:[{k:'harvest',n:5},{k:'craft',n:1}],rew:{xp:320,gold:80},fin:"Voilà quelqu'un d'utile."},
 {id:'M6',t:'La route des collines',giver:'camp1',req:'M5',lvl:5,d:"{camp2} tient un camp de prospecteurs dans {z2}, la zone suivante. Il a besoin d'aide avec la vieille mine.",obj:[{k:'talk',q:'camp2',n:1}],end:'camp2',rew:{xp:280},fin:"Tu viens pour la mine ? Personne ne vient jamais pour la mine."},
 {id:'M7',t:'La mine maudite',giver:'camp2',req:'M6',lvl:7,d:"Le jour où nous avons trouvé un éclat noir au fond de la mine, le contremaître Krog est devenu fou. Ses kobolds tiennent les galeries. Descends par le portail et mets fin à son règne.",obj:[{k:'kill',m:'krog',n:1}],rew:{xp:1200,gold:300,book:2,item:1},fin:"Krog est tombé ? Alors l'éclat noir… garde-le loin de moi. Ce grimoire était dans son coffre."},
 {id:'M8',t:'Ombres sous les arbres',giver:'camp2',req:'M7',lvl:10,d:"Les bois au-delà sont hantés par les soldats de la Première Guerre. {camp3} les surveille. Va le voir.",obj:[{k:'talk',q:'camp3',n:1}],end:'camp3',rew:{xp:650},fin:"Ces bois sont un cimetière. Tu tombes à pic, si j'ose dire."},
 {id:'M9',t:'Les os de la Fracture',giver:'camp3',req:'M8',lvl:11,d:"Ces squelettes portent encore les sceaux de la première guerre. Brise-en 10 et rapporte 4 sceaux : je veux savoir qui les a relevés.",obj:[{k:'kill',m:'squelette',n:10},{k:'collect',m:'squelette',it:'Sceau ancien',p:.35,n:4}],rew:{xp:1900,gold:240},fin:"Ces sceaux portent la marque de Morvhal… Le roi mort se réveille."},
 {id:'M10',t:'La bête des Ronces',giver:'camp3',req:'M9',lvl:14,d:"L'Ours des Ronces a dévoré un éclat entier. Il est devenu énorme. Abats-le avant qu'il ne devienne pire, il rôde dans la partie la plus profonde du bois.",obj:[{k:'kill',m:'ours',n:1}],rew:{xp:2800,gold:400,item:2,book:3},fin:"Tu as abattu la bête ! Les bois respireront mieux cette nuit."},
 {id:'M11',t:'Le rempart',giver:'camp3',req:'M10',lvl:16,d:"{camp4} garde le rempart face à {rival}. Il manque de combattants.",obj:[{k:'talk',q:'camp4',n:1}],end:'camp4',rew:{xp:1600},fin:"Encore un volontaire. Bien. Les derniers ne sont pas revenus."},
 {id:'M12',t:'Tenir la ligne',giver:'camp4',req:'M11',lvl:17,d:"Les {pm4a} attaquent nos convois. Repousses-en 12, puis lis la stèle de la Fracture, au cœur de {z4}. Tu sauras pourquoi on se bat.",obj:[{k:'kill',m:'{m4a}',n:12},{k:'read',map:'{z4}',n:1}],rew:{xp:4400,gold:500},fin:"Maintenant tu sais. Le Prisme a pleuré, et nous ramassons encore ses larmes."},
 {id:'M13',t:'Aux portes du conflit',giver:'camp4',req:'M12',lvl:18,d:"Au-delà, c'est la Frontière : plus de loi, plus de protection, PvP sauvage. Quand tu atteindras le niveau 21, franchis-la et présente-toi au mercenaire Dorg.",obj:[{k:'level',n:21},{k:'talk',q:'front',n:1}],end:'front',rew:{xp:5200,gold:600,book:4},fin:"Encore un soldat de {fac}. Tiens, j'ai récupéré ce grimoire sur un cadavre. Il ne lui servira plus."},
 {id:'M14',t:'Pour {fac} !',giver:'front',req:'M13',lvl:21,d:"Ici, chacun se bat pour soi. Mais si tu veux que {fac} prospère, montre aux renégats que la Frontière n'est pas à eux. Abats-en 10.",obj:[{k:'kill',m:'renegat',n:10}],rew:{xp:9500,gold:800,honor:100},fin:"Pas mal. Ta faction parlera de toi ce soir."},
 {id:'M15',t:'Le temple englouti',giver:'front',req:'M14',lvl:24,d:"Le Marais de Brume, au nord, cache le Temple de l'Éther, noyé par la Fracture. Une hydre y garde un grand éclat : le Cœur Noyé. Va le chercher.",obj:[{k:'kill',m:'hydre',n:1}],rew:{xp:17000,gold:1500,book:5},fin:"Le Cœur Noyé… Il bat encore. Garde ce grimoire, l'hydre l'avait avalé."},
 {id:'M16',t:'Les sables de Kharan',giver:'front',req:'M15',lvl:30,d:"Au sud, le Désert de Kharan. Les scarabées d'éther se nourrissent d'éclats ; rapporte-m'en 8, puis abats leur reine.",obj:[{k:'collect',m:'scorpion',it:"Scarabée d'éther",p:.35,n:8},{k:'kill',m:'reinescorp',n:1}],rew:{xp:27000,gold:2000,item:2},fin:"La reine est morte. Le désert sera plus calme… pour un temps."},
 {id:'M17',t:'La citadelle de Morvhal',giver:'front',req:'M16',lvl:38,d:"Le roi Morvhal, premier à avoir touché le Prisme, est devenu le Seigneur Liche. C'est lui qui relève les morts. Sa citadelle se dresse dans les Terres maudites. Monte jusqu'à son trône.",obj:[{k:'kill',m:'liche',n:1}],rew:{xp:62000,gold:4000,book:7},fin:"Morvhal est tombé. Son grimoire te revient : il y a écrit son dernier sort."},
 {id:'M18',t:'Le cœur des Abysses',giver:'front',req:'M17',lvl:44,d:"Le Wyrm du Néant dévore les derniers éclats. S'il les avale tous, il n'y aura plus de Prisme à reforger ni à libérer. Rassemble ta guilde et abats-le quand il surgit dans les Abysses.",obj:[{k:'kill',m:'wyrm',n:1}],rew:{xp:150000,gold:10000,item:4,book:8},fin:"Le Wyrm est tombé. Les éclats sont libres… et la vraie guerre pour le Prisme peut commencer."},
];



/* ---------- joueurs simulés ---------- */
const BOT_NAMES={solarix:['Kaelith','Bastok','Orrin','Fenrik','Thalorn','Galahar','Mirelle','Vexa','Dorian','Aldwin','Sigrun','Lyssa','Brom','Elowen','Garrik','Tamsin','Aurore','Cassius'],
  umbra:['Moru','Nyra','Pixou','Saphyr','Ziggo','Ylvaine','Korrin','Feyla','Nocturne','Talios','Nimra','Oskar','Lunae','Rhoswen','Faelan','Ivy','Morgrim','Selka']};
const GUILDS={solarix:[{n:'Lames d’Argent',lvl:6},{n:'Ordre du Griffon',lvl:8},{n:'Gardiens de l’Aube',lvl:3}],umbra:[{n:'Racines Profondes',lvl:7},{n:'Voile Écarlate',lvl:5},{n:'Crocs du Néant',lvl:4}]};
const BOT_LINES=['qqn pour le donjon de la mine ?','vends parchemin majeur, mp','lf groupe marais','gg','le forgeron m’a cassé mon +8…','où on trouve du mithril ?','attention PK rouge à la Frontière','+5 réussi du premier coup !!','quelqu’un a vu l’Ours ?','achète cristal x10 à l’HDV','afk 5 min','rdv à la fontaine','vive la guerre de faction, +50 % xp','qui monte bûcheron ?','Titan bientôt, la guilde se prépare','je cherche une guilde active','livre de Multi-Shot dispo à l’HDV','up 21 enfin, direction la Frontière','besoin d’un mage soigneur pour le temple'];
const GUILD_LINES=['bien joué pour la guerre','qui veut faire la mission de guilde ?','je monte alchimiste si besoin de potions','on fait la mine ce soir ?','merci pour le stuff !','gg tout le monde','on se regroupe pour le world boss','quelqu’un a du fer à vendre ?'];
const HONOR_RANKS=[[0,'Recrue'],[100,'Soldat'],[300,'Sergent'],[700,'Lieutenant'],[1500,'Capitaine'],[3000,'Commandant'],[6000,'Champion'],[12000,'Légende']];
const honorRank=h=>{let r=HONOR_RANKS[0][1];for(const [v,n] of HONOR_RANKS)if(h>=v)r=n;return r;};
const PETS={chaton:{n:'Chaton de braise',price:250},hibou:{n:'Hibou des neiges',price:250},slimou:{n:'Slimou',price:250}};

/* ===================== Données des événements ===================== */
Object.assign(MT,{
  g_capnoye:{n:'Capitaine noyé',boss:1,mini:1,role:'m',spr:'g_capnoye',spd:40,slam:1},
  g_verre:{n:'Sentinelle de verre',boss:1,mini:1,role:'c',spr:'g_verre',spd:30,keep:90},
  g_phare:{n:'Gardien du Phare',boss:1,mini:1,role:'m',spr:'g_phare',spd:28,slam:1},
  g_echo:{n:'Écho du Prisme',boss:1,mini:1,role:'sp',spr:'g_echo',spd:34,keep:100},
  g_lumiere:{n:'Gardien de la Lumière',boss:1,mini:1,role:'sp',spr:'g_lumiere',spd:24,keep:110},
  forgemaitre:{n:'Maître de la Forge',boss:1,mini:1,role:'m',spr:'forgemaitre',spd:30,slam:1},
  chefhorde:{n:'Chef de horde',boss:1,role:'m',spr:'chefhorde',spd:40,slam:1},
  cristal:{n:'Cristal',role:'none',spr:'cristal',spd:0,stat:1,hp:6},
});
for(const k of ['g_capnoye','g_verre','g_phare','g_echo','g_lumiere','forgemaitre','chefhorde','cristal'])MT[k].agr=k!=='cristal';
Object.assign(DUNGEONS,{
  phare:{n:'Phare des Éclats',lv:[21,42],floors:10,style:'phare',mons:[['noye',22],['serpent',24]],boss:['g_capnoye',23]},
  raid_crypte:{n:'Crypte de Morvhal',lv:[40,44],floors:1,style:'crypt',mons:[['sqnoir',42],['spectre',43]],boss:['liche',46],raid:1,key:'cle1',timer:360},
  raid_sanct:{n:'Sanctuaire du Néant',lv:[44,48],floors:1,style:'temple',mons:[['spectre',45],['demon',46]],boss:['hydre',49],raid:1,key:'cle2',timer:360},
  raid_forge:{n:'Forge des Titans',lv:[47,50],floors:1,style:'cave',mons:[['golem',48],['demon',49]],boss:['forgemaitre',51],raid:1,key:'cle3',timer:360},
});
const PHARE_FL=[null,{lv:21,g:'g_capnoye'},{lv:23,g:'g_capnoye'},{lv:24,g:'g_verre'},{lv:26,g:'g_verre'},{lv:28,g:'g_phare'},{lv:30,g:'g_echo'},{lv:33,g:'g_echo'},{lv:36,g:'g_echo'},{lv:39,g:'g_echo'},{lv:42,g:'g_lumiere'}];
const PHARE_MONS=[['noye','serpent'],['noye','serpent'],['spectre','serpent'],['spectre','noye'],['spectre','sqnoir'],['sqnoir','demon'],['sqnoir','golem'],['golem','demon'],['demon','spectre'],['golem','sqnoir']];
MAPS.c_front.phare=true;MAPS.c_maudit.raids=true;
const MONUMENTS={c_front:'Fort Brisé',c_desert:'Obélisque de Kharan',c_marais:'Sanctuaire Noyé',c_abysse:'Porte des Abysses'};
Object.assign(CONS,{
  fragcle:{n:'Fragment de clé',d:'Sert à forger les clés de raid chez le forgeron.',price:80},
  cle1:{n:'Clé de la Crypte',d:'Ouvre la Crypte de Morvhal (raid, niv. 40+).',price:1200},
  cle2:{n:'Clé du Sanctuaire',d:'Ouvre le Sanctuaire du Néant (raid, niv. 44+).',price:2500},
  cle3:{n:'Clé de la Forge',d:'Ouvre la Forge des Titans (raid, niv. 47+).',price:5000},
  potpvp:{n:'Potion de résistance',d:'−10 % de dégâts reçus des joueurs pendant 60 s.',buff:{id:'potpvp',n:'Résistance',pvp:.1,t:60},price:40},
  friandise:{n:'Friandise de saison',d:'+15 % d’XP pendant 30 min.',buff:{id:'friandise',n:'Friandise',xp:.15,t:1800},price:60},
  gateau:{n:"Gâteau d'anniversaire",d:'+20 % d’XP pendant 30 min. Ne se cumule pas avec le grand gâteau.',buff:{id:'gateau',n:'Gâteau',xp:.2,t:1800},price:200},
  grandgateau:{n:'Grand gâteau',d:'+30 % d’XP pendant 60 min.',buff:{id:'gateau',n:'Grand gâteau',xp:.3,t:3600},price:600},
  boite:{n:'Boîte surprise',d:'Potions, or, parfois un parchemin ou un grimoire.',price:100},
  boiteanniv:{n:"Boîte d'anniversaire",d:'Contient de beaux cadeaux de Paracraft.',price:300},
});
const KEY_RECIPES=[{id:'cle1',ing:{fragcle:3,obsidienne:2,ench1:1}},{id:'cle2',ing:{fragcle:5,obsidienne:4,ench2:1}},{id:'cle3',ing:{fragcle:8,spectral:4,ench3:1}}];
const SEASONS=[{id:'moisson',n:'Fête de la Moisson',m0:9,d0:15,m1:10,d1:5,comp:'Épis dorés',npc:'Fermière Agathe',deco:'wheat'},
  {id:'ombres',n:'Nuit des Ombres',m0:10,d0:20,m1:11,d1:10,comp:'Citrouilles',npc:'Sorcière Méliane',deco:'pumpkin'},
  {id:'etoiles',n:'Fête des Étoiles',m0:12,d0:15,m1:1,d1:6,comp:"Fragments d'étoile",npc:'Père Givre',deco:'snowman'}];
const LETTERS={P:2,A:2.5,R:2,C:1.5,F:1.2,T:.8};
const BF_MODES={cristal:'Destruction du cristal',drapeaux:'Capture des drapeaux',kills:'Score de kills'};
const BF_SYL=['Ar','Bel','Cor','Dra','El','Fen','Gal','Hel','Ior','Kel','Lun','Mor','Nar','Or','Pel','Ryn','Syl','Tor','Ul','Vor'],BF_SUF=['ian','dor','wen','ra','th','is','an','el','ok','ys','ar','in'];
