'use strict';
/* ===================== Rendu ===================== */
const cv=$('#cv'),ctx=cv.getContext('2d');
let dpr=1,Z=3,VW=0,VH=0,camX=0,camY=0;
const dark=cnv(4,4),dctx=dark.getContext('2d');
function resize(){dpr=Math.min(window.devicePixelRatio||1,2.5);VW=cv.width=Math.round(innerWidth*dpr);VH=cv.height=Math.round(innerHeight*dpr);cv.style.width=innerWidth+'px';cv.style.height=innerHeight+'px';
  Z=Math.max(2,Math.round(Math.min(VW,VH)/(TS*12)));ctx.imageSmoothingEnabled=false;dark.width=Math.ceil(VW/2);dark.height=Math.ceil(VH/2);}
addEventListener('resize',resize);resize();
function nightK(){if(M&&M.kind==='dungeon')return .86;if(!SET.daynight)return 0;const ph=(tDay%720)/720,v=-Math.cos(ph*Math.PI*2);return clamp((v-.05)*1.25,0,1);}
const BAGR=["..TT..",".BHBB.","BHBBBB","BBBBBB","BBBBBB",".BBBB."];
let BAGSPR=null;
function bagSprites(){BAGSPR=['#9a6a3a','#a65cff','#4ad6e0','#f5d24a','#ff7a3a'].map((c,i)=>fin(rowsC(BAGR,{B:c,H:shade(c,1.5),T:'#3a2a1a'})));}
const looks=new Map();
function lookOf(e){let L=looks.get(e);if(!L){L=botLook(e.cls,e.fac,strSeed(e.n||e.name||'x')%6);looks.set(e,L);}return L;}
const GUARD_LOOK={solarix:{body:'#d8dce6',body2:'#9aa0ae',legs:'#5a5f6c',boots:'#3a2a1e',belt:'#b8862a',extra:'helm',plume:'#ffd36a',weapon:'halberd',cape:'#b8862a',shield:'#e8c860'},
  umbra:{body:'#4a4458',body2:'#2e2a3a',legs:'#2a2434',boots:'#1a1420',belt:'#8a5ad0',extra:'helm',plume:'#b48cff',weapon:'halberd',cape:'#4a2a7a',skin:'#c8b8d8'}};
function drawHumAt(L,x,y,dir,moving,anim,alpha,sc){const s=humSprite(L,sc||1);const fr=moving?Math.floor(anim)%4:0;const img=(s[dir]||s.d)[fr];if(alpha!=null)ctx.globalAlpha=alpha;ctx.drawImage(img,Math.round(x-img.width/2),Math.round(y-img.height+3*(sc||1)));ctx.globalAlpha=1;return img;}
function shadow(x,y,w){ctx.fillStyle='rgba(0,0,0,.28)';ctx.beginPath();ctx.ellipse(x,y,w,w*.38,0,0,7);ctx.fill();}
function render(){
  ctx.setTransform(1,0,0,1,0,0);ctx.fillStyle='#0d0b14';ctx.fillRect(0,0,VW,VH);
  if(!P||!M||state==='title')return;
  const vw=VW/Z,vh=VH/Z,MW=M.w*TS,MH=M.h*TS;
  camX=MW<vw?(MW-vw)/2:clamp(P.x-vw/2,0,MW-vw);camY=MH<vh?(MH-vh)/2:clamp(P.y-14-vh/2,0,MH-vh);camX=Math.round(camX*Z)/Z;camY=Math.round(camY*Z)/Z;
  ctx.setTransform(Z,0,0,Z,-camX*Z,-camY*Z);ctx.imageSmoothingEnabled=false;
  const sx=Math.max(0,Math.floor(camX)),sy=Math.max(0,Math.floor(camY)),sw=Math.min(MW-sx,Math.ceil(vw)+2),sh=Math.min(MH-sy,Math.ceil(vh)+2);
  ctx.drawImage(M.canvas,sx,sy,sw,sh,sx,sy,sw,sh);
  const inV=(x,y,m=48)=>x>camX-m&&x<camX+vw+m&&y>camY-m&&y<camY+vh+m*2;
  // eau animée
  const tx0=Math.max(0,Math.floor(camX/TS)),ty0=Math.max(0,Math.floor(camY/TS)),tx1=Math.min(M.w-1,Math.ceil((camX+vw)/TS)),ty1=Math.min(M.h-1,Math.ceil((camY+vh)/TS));
  for(let ty=ty0;ty<=ty1;ty++)for(let tx=tx0;tx<=tx1;tx++){const g=M.gr[ty*M.w+tx];if(g!==GT.WATER&&g!==GT.DEEP&&g!==GT.LAVA)continue;const h=hash(tx,ty),ph=tGame*1.4+h*9;
    ctx.fillStyle=g===GT.LAVA?'rgba(255,200,90,.7)':'rgba(220,240,255,.55)';const k=(ph%3)/3;if(k<.6){ctx.fillRect(tx*TS+((h*13)|0),ty*TS+((h*29)%14|0),Math.round(2+k*3),1);}}
  // décals au sol
  for(const f of fxs)if(f.k==='tele'){const k=f.t/f.life;ctx.fillStyle=f.col+'30';ctx.beginPath();ctx.ellipse(f.x,f.y,f.r,f.r*.6,0,0,7);ctx.fill();ctx.strokeStyle=f.col;ctx.lineWidth=1;ctx.beginPath();ctx.ellipse(f.x,f.y,f.r*k,f.r*k*.6,0,0,7);ctx.stroke();}
  if(M.fort&&WAR.st==='active'){ctx.strokeStyle=WAR.own?FACTIONS[WAR.own].c:'#f1e9d6';ctx.setLineDash([4,3]);ctx.beginPath();ctx.ellipse(M.fort.x,M.fort.y,90,54,0,0,7);ctx.stroke();ctx.setLineDash([]);}
  if(P.target&&!P.target.dead){const t=P.target,w=t.kind==='m'?t.hr:9;ctx.strokeStyle=t.kind==='b'?'#ff6a6a':(t.t.agr?'#ff4a4a':'#ffd84a');ctx.lineWidth=1;ctx.beginPath();ctx.ellipse(t.x,t.y,w+3,(w+3)*.4,0,0,7);ctx.stroke();}
  if(P.moveTo){ctx.strokeStyle='rgba(241,233,214,.6)';ctx.beginPath();ctx.ellipse(P.moveTo.x,P.moveTo.y,4,1.6,0,0,7);ctx.stroke();}
  for(const n of M.nodes)if(n.kind==='poisson'&&n.alive&&inV(n.x,n.y)){const k=(tGame*.8+hash(n.x,n.y))%1;ctx.strokeStyle=`rgba(230,245,255,${1-k})`;ctx.beginPath();ctx.ellipse(n.x,n.y,2+k*7,1+k*3,0,0,7);ctx.stroke();ctx.fillStyle='#e8f8ff';ctx.fillRect(n.x-1,n.y-1-Math.round(Math.sin(tGame*5)),2,1);}
  // entités et décors triés par profondeur
  const E=[];const add=(y,d)=>E.push({y,d});
  const r0=Math.max(0,Math.floor(camY/TS)-1),r1=Math.min(M.h-1,Math.ceil((camY+vh)/TS)+9);
  for(let r=r0;r<=r1;r++){const row=M.props[r];if(!row)continue;for(const p of row){const S=PROPS[p.k];if(!S)continue;if(p.x<camX-S.w||p.x>camX+vw+S.w)continue;add(p.y,()=>drawProp(p,S));}}
  for(const b of bags)if(inV(b.x,b.y))add(b.y-2,()=>{if(b.t<10&&Math.floor(tGame*6)%2)return;const bob=Math.round(Math.sin(tGame*4+b.x)*1);
    if(b.coin){ctx.fillStyle='#8a6a1a';ctx.fillRect(Math.round(b.x)-3,Math.round(b.y)-2+bob,7,3);ctx.fillStyle='#f2c14e';ctx.fillRect(Math.round(b.x)-2,Math.round(b.y)-4+bob,5,3);ctx.fillStyle='#fff2b0';ctx.fillRect(Math.round(b.x)-1,Math.round(b.y)-4+bob,1,1);return;}
    const s=BAGSPR[b.rar||0];ctx.drawImage(s.c,Math.round(b.x-s.w/2),Math.round(b.y-s.h+bob));if(b.rar>=2&&SET.parts&&rnd()<.05)parts.push({x:b.x+rr(-4,4),y:b.y-8,vx:0,vy:-14,t:0,life:.8,col:RARC[b.rar],glow:true,g:0});});
  if(M.chest&&inV(M.chest.x,M.chest.y))add(M.chest.y,()=>{const S=PROPS[M.chest.open?'chesto':'chest'];ctx.drawImage(S.c,Math.round(M.chest.x-S.w/2),Math.round(M.chest.y-S.h));});
  for(const n of M.npcs)if(inV(n.x,n.y))add(n.y,()=>{shadow(n.x,n.y,6);drawHumAt(Object.assign({},n.look,{cape:n.look.cape||(n.fac?FACTIONS[n.fac].cape:null)}),n.x,n.y,'d',false,0);});
  for(const g of M.guards)if(inV(g.x,g.y))add(g.y,()=>{shadow(g.x,g.y,6);drawHumAt(GUARD_LOOK[g.fac],g.x,g.y,'d',false,0);});
  for(const c of M.citizens)if(inV(c.x,c.y))add(c.y,()=>{shadow(c.x,c.y,5);drawHumAt(c.look,c.x,c.y,c.dir,c.moving,c.anim);});
  for(const m of mons)if(!m.dead&&inV(m.x,m.y,90))add(m.y,()=>drawMon(m));
  const id=curId();
  for(const b of bots)if(!b.dead&&b.map===id&&inV(b.x,b.y))add(b.y,()=>{shadow(b.x,b.y,6);drawHumAt(lookOf(b),b.x,b.y,b.dir,b.mv,b.anim);});
  if(petE&&P.pet)add(petE.y,()=>{const s=PSPR[P.pet],bob=P.pet==='hibou'?-6+Math.sin(tGame*6)*2:0;shadow(petE.x,petE.y,4);const im=s.fr[Math.floor(petE.anim)%2];ctx.drawImage(petE.flip?im.f:im.c,Math.round(petE.x-im.w/2),Math.round(petE.y-im.h+bob));});
  add(P.y,()=>{shadow(P.x,P.y,6);if(P.inv0>0&&Math.floor(tGame*20)%2)return;
    if(P.guard>0){ctx.strokeStyle='#9be36a';ctx.globalAlpha=.6;ctx.beginPath();ctx.ellipse(P.x,P.y-1,11,4.4,0,0,7);ctx.stroke();ctx.globalAlpha=1;}
    const lx=P.lunge>0?P.fx*3:0,ly=P.lunge>0?P.fy*3:0;drawHumAt(P.look,P.x+lx,P.y+ly,P.dir,P.mv,P.anim);
    if(P.harv){const k=P.harv.t/1.6;ctx.fillStyle='#000';ctx.fillRect(Math.round(P.x-9),Math.round(P.y-36),18,3);ctx.fillStyle='#9be36a';ctx.fillRect(Math.round(P.x-8),Math.round(P.y-35),Math.round(16*k),1);}});
  E.sort((a,b)=>a.y-b.y);for(const e of E)e.d();
  // projectiles et effets
  for(const p of projs){if(!inV(p.x,p.y))continue;ctx.fillStyle=p.col;if(p.from==='m'){ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,7);ctx.fill();ctx.fillStyle='rgba(255,255,255,.8)';ctx.fillRect(Math.round(p.x)-1,Math.round(p.y)-1,1,1);}
    else{const a=Math.atan2(p.vy,p.vx);ctx.save();ctx.translate(p.x,p.y);ctx.rotate(a);if(p.explode){ctx.beginPath();ctx.arc(0,0,p.r,0,7);ctx.fill();ctx.fillStyle='#ffe08a';ctx.fillRect(-1,-1,2,2);}else ctx.fillRect(-p.r*2,-p.r/2,p.r*3,Math.max(1,p.r));ctx.restore();}}
  for(const f of fxs){const k=f.t/f.life;
    if(f.k==='ring'){ctx.strokeStyle=f.col;ctx.globalAlpha=1-k;ctx.lineWidth=2;ctx.beginPath();const r=f.r0+(f.r1-f.r0)*k;ctx.ellipse(f.x,f.y,Math.max(1,r),Math.max(1,r*.6),0,0,7);ctx.stroke();ctx.globalAlpha=1;ctx.lineWidth=1;}
    else if(f.k==='slash'){ctx.strokeStyle=f.col;ctx.globalAlpha=1-k;ctx.lineWidth=2;ctx.beginPath();ctx.arc(f.x,f.y,9,f.a-1+k,f.a+.5+k);ctx.stroke();ctx.globalAlpha=1;ctx.lineWidth=1;}
    else if(f.k==='meteor'){const y0=f.y-80*(1-k);ctx.fillStyle='#ff9a3a';ctx.beginPath();ctx.arc(f.x+20*(1-k),y0,3,0,7);ctx.fill();ctx.fillStyle='#ffe08a';ctx.fillRect(f.x+20*(1-k)-1,y0-1,2,2);}
    else if(f.k==='roots'&&f.tgt&&!f.tgt.dead){ctx.strokeStyle='#5a8a3a';ctx.lineWidth=2;for(let i=0;i<5;i++){const a=i*1.26+tGame;ctx.beginPath();ctx.moveTo(f.tgt.x+Math.cos(a)*9,f.tgt.y+Math.sin(a)*3);ctx.lineTo(f.tgt.x+Math.cos(a)*4,f.tgt.y-8-Math.sin(tGame*3+i)*2);ctx.stroke();}ctx.lineWidth=1;}}
  for(const p of parts){if(!inV(p.x,p.y,8))continue;ctx.globalAlpha=Math.min(1,(p.life-p.t)*2.5);ctx.fillStyle=p.col;ctx.fillRect(Math.round(p.x),Math.round(p.y),p.glow?2:1,p.glow?2:1);}ctx.globalAlpha=1;
  // nuit et lumières
  const nk=nightK();
  if(nk>.02){const W2=dark.width,H2=dark.height,sc=Z/2;dctx.globalCompositeOperation='source-over';dctx.clearRect(0,0,W2,H2);
    const base=M.kind==='dungeon'?'rgba(6,4,14,':'rgba(10,10,34,';dctx.fillStyle=base+(nk*(M.kind==='dungeon'?.9:.62))+')';dctx.fillRect(0,0,W2,H2);dctx.globalCompositeOperation='destination-out';
    const L=(x,y,r,a)=>{const X=(x-camX)*sc,Y=(y-camY)*sc,R=r*sc;if(X<-R||Y<-R||X>W2+R||Y>H2+R)return;const g=dctx.createRadialGradient(X,Y,0,X,Y,R);g.addColorStop(0,'rgba(0,0,0,'+a+')');g.addColorStop(1,'rgba(0,0,0,0)');dctx.fillStyle=g;dctx.fillRect(X-R,Y-R,R*2,R*2);};
    L(P.x,P.y-12,M.kind==='dungeon'?110:90,1);
    for(const p of M.lights)L(p.x,p.y-(p.k==='lamp'?24:16),p.light.r*(1+Math.sin(tGame*7+p.x)*.04),.95);
    for(let r=r0;r<=r1;r++){const row=M.props[r];if(!row)continue;for(const p of row)if(p.win)for(const [wx,wy] of p.win)L(wx,wy,34,.8);}
    for(const p of projs)if(p.from==='p'&&p.explode)L(p.x,p.y,40,.8);
    for(const m of mons)if(!m.dead&&(m.type==='liche'||m.type==='spectre'||m.type==='demon'))L(m.x,m.y-m.hh,46,.6);
    ctx.setTransform(1,0,0,1,0,0);ctx.imageSmoothingEnabled=true;ctx.drawImage(dark,0,0,VW,VH);ctx.imageSmoothingEnabled=false;
    ctx.globalCompositeOperation='lighter';for(const p of M.lights){const X=(p.x-camX)*Z,Y=(p.y-(p.k==='lamp'?24:16)-camY)*Z,R=p.light.r*Z*.6;if(X<-R||Y<-R||X>VW+R||Y>VH+R)continue;const g=ctx.createRadialGradient(X,Y,0,X,Y,R);g.addColorStop(0,p.light.c+'40');g.addColorStop(1,p.light.c+'00');ctx.fillStyle=g;ctx.fillRect(X-R,Y-R,R*2,R*2);}ctx.globalCompositeOperation='source-over';}
  // couche écran : noms, barres, textes
  ctx.setTransform(1,0,0,1,0,0);
  const S=(x,y)=>[(x-camX)*Z,(y-camY)*Z],fs=Math.max(10,Math.round(4*Z)),F=f=>`${f}px Silkscreen, ui-monospace, monospace`;
  ctx.font=F(fs);ctx.textAlign='center';ctx.textBaseline='bottom';
  const label=(t,x,y,c)=>{ctx.fillStyle='rgba(0,0,0,.8)';ctx.fillText(t,x+1,y+1);ctx.fillStyle=c;ctx.fillText(t,x,y);};
  const bar=(x,y,w,k,col)=>{const h=Math.max(3,Z*.9);ctx.fillStyle='#000';ctx.fillRect(x-w/2-1,y-h-1,w+2,h+2);ctx.fillStyle=col;ctx.fillRect(x-w/2,y-h,w*clamp(k,0,1),h);};
  if(SET.names){
    for(const n of M.npcs)if(inV(n.x,n.y)){const[x,y]=S(n.x,n.y-34);label(n.n,x,y,'#ffd36a');ctx.font=F(Math.round(fs*.82));label('<'+n.r+'>',x,y+fs*.95,'#e8d8a8');ctx.font=F(fs);
      const mk=(!n.fac||n.fac===P.fac)&&npcMark(n.qid);if(mk){ctx.font=F(fs*1.7);label(mk,x,y-fs*1.1+Math.sin(tGame*4)*3,mk==='?'?'#9be36a':'#ffd36a');ctx.font=F(fs);}}
    ctx.font=F(Math.round(fs*.85));for(const sg of M.signs||[])if(inV(sg.x,sg.y)){const[x,y]=S(sg.x,sg.y);label(sg.t,x,y,'#f2e6c8');}
    if(M.board&&qTurnIns('board').length){const[x,y]=S(M.board.x,M.board.y-44);ctx.font=F(fs*1.7);label('?',x,y+Math.sin(tGame*4)*3,'#9be36a');}ctx.font=F(fs);
    for(const b of bots)if(!b.dead&&b.map===id&&inV(b.x,b.y)){const[x,y]=S(b.x,b.y-34);const hostile=botHostileToPlayer(b);
      label(b.n+' ['+b.lvl+']',x,y,b.pk?'#ff4a4a':b.party?'#9be3ff':b.fac!==P.fac?(hostile?'#ff8a8a':FACTIONS[b.fac].c):FACTIONS[b.fac].c);
      if(b.guild&&b.fac===P.fac){ctx.font=F(Math.round(fs*.8));label('«'+b.guild+'»',x,y+fs*.9,'#9be36a');ctx.font=F(fs);}
      if(b.hp<b.maxhp||hostile||b.party)bar(x,y-fs-2,14*Z/2.5,b.hp/b.maxhp,b.party?'#5ad06a':'#e0464e');}
    {const[x,y]=S(P.x,P.y-34);label((P.hc?'[HC] ':'')+P.name,x,y,P.pkT>0?'#ff4a4a':P.pkMode?'#ff9a3a':'#ffffff');if(P.guild){ctx.font=F(Math.round(fs*.8));label('«'+P.guild.name+'»',x,y+fs*.9,'#9be36a');ctx.font=F(fs);}}}
  for(const m of mons){if(m.dead||!inV(m.x,m.y,70))continue;const big=m.t.boss,top=monTop(m);
    if(m.hp<m.maxhp||m.agg||big||m===P.target||m.elite){const[x,y]=S(m.x,top-3);const w=(big?44:18)*Z/3;bar(x,y,w,m.hp/m.maxhp,big?'#c58cff':'#e0464e');
      if(m.t.agr){ctx.fillStyle='#ff4a4a';ctx.fillRect(x-w/2-Z*2.4,y-Z*2.4,Z*1.6,Z*1.6);}
      if(big||m===P.target||m.elite){const lc=lvlColor(m.lv,P.lvl);label(m.name+' · '+m.lv,x,y-Math.max(3,Z*.9)-3,m.elite?'#ffd36a':lc.c);}}}
  for(const t of texts){const[x,y]=S(t.x,t.y-t.t*20);ctx.globalAlpha=Math.min(1,2.2-t.t*2);ctx.font=F(t.big?fs*1.4:fs);label(t.txt,x,y,t.col);}ctx.globalAlpha=1;
  if(typeof drawBubbles==='function')drawBubbles(S,F,fs);
  hud();
}
function monTop(m){const s=MSPR[m.t.spr];return m.y-(s.hum?s.h-3*s.sc:s.h)-(m.type==='chauve'||m.type==='spectre'?8:0);}
function drawMon(m){const s=MSPR[m.t.spr],fly=m.type==='chauve'||m.type==='spectre';const bob=fly?-8+Math.sin(tGame*5+m.x)*2:0;shadow(m.x,m.y,Math.max(5,s.w*.32));
  if(m.hitT>0)ctx.globalAlpha=.6;if(m.type==='spectre')ctx.globalAlpha=.75;
  if(s.hum){const dir=m.agg?m.dir:'d',fr=(m.agg||m.wx||m.wy)?Math.floor(m.anim)%4:0,img=(s.hum[dir]||s.hum.d)[fr];ctx.drawImage(img,Math.round(m.x-img.width/2),Math.round(m.y-img.height+3*s.sc+bob));}
  else{const fr=s.fr[(m.agg||m.wx||m.wy)?Math.floor(m.anim)%2:0];let flip=m.flip;if(s.faceL)flip=!flip;const sq=m.type==='slime'||m.type==='slimeb'||m.type==='crapaud'?Math.abs(Math.sin(m.anim*1.5))*-2:0;
    ctx.drawImage(flip?fr.f:fr.c,Math.round(m.x-fr.w/2),Math.round(m.y-fr.h+bob+sq));}
  ctx.globalAlpha=1;
  if(m.elite&&Math.floor(tGame*4)%2){ctx.strokeStyle='#ffd36a';ctx.beginPath();ctx.ellipse(m.x,m.y,m.hr+4,(m.hr+4)*.4,0,0,7);ctx.stroke();}
  if(m.stun>0){ctx.fillStyle='#ffd36a';for(let i=0;i<3;i++){const a=tGame*6+i*2.1;ctx.fillRect(Math.round(m.x+Math.cos(a)*7),Math.round(monTop(m)+2+Math.sin(a)*2),2,2);}}
  if(m.slamT>0){ctx.globalAlpha=.35+Math.sin(tGame*30)*.15;ctx.fillStyle='#ff5a3a';ctx.beginPath();ctx.ellipse(m.x,m.y-m.hh,m.hr,m.hh,0,0,7);ctx.fill();ctx.globalAlpha=1;}}
function drawProp(p,S){let c=S.c,w=S.w,h=S.h,k=p.k;
  if(p.node&&!p.node.alive){if(p.node.kind==='bois'){const st=PROPS.stump;ctx.drawImage(st.c,Math.round(p.x-st.w/2),Math.round(p.y-st.h));}return;}
  let a=1;if(p.fade&&P.y<p.y-2&&P.y>p.y-h+8&&Math.abs(P.x-p.x)<w/2-2)a=.5;
  ctx.globalAlpha=a;ctx.drawImage(c,Math.round(p.x-w/2),Math.round(p.y-h));ctx.globalAlpha=1;
  if(p.node&&SET.parts&&Math.floor(tGame*2+p.x)%5===0){ctx.fillStyle='#ffffff';const t=(tGame*3+p.x)%1;ctx.fillRect(Math.round(p.x-4+t*8),Math.round(p.y-h*.6-t*4),1,1);}
  if(p.flag){const col=WAR.own?FACTIONS[WAR.own].c:'#e8e0d0',w2=Math.sin(tGame*4);ctx.fillStyle=col;for(let i=0;i<12;i++)ctx.fillRect(Math.round(p.x+1+i),Math.round(p.y-46+Math.sin(tGame*4+i*.5)*1.5),1,8);}
  if(p.portal){ctx.globalAlpha=.75;for(let i=0;i<4;i++){const r=4+((tGame*10+i*5)%16);ctx.strokeStyle=i%2?'#c58cff':'#7ff3ff';ctx.beginPath();ctx.ellipse(p.x,p.y-20,r*.7,r,0,0,7);ctx.stroke();}ctx.globalAlpha=1;}
  if(p.fire){for(let i=0;i<6;i++){const h=3+((tGame*12+i*7)%6);ctx.fillStyle=i%2?'#ffb040':'#ff6a2a';ctx.fillRect(Math.round(p.x-5+i*2),Math.round(p.y-6-h),2,h);}ctx.fillStyle='#fff0a0';ctx.fillRect(Math.round(p.x-1),Math.round(p.y-9),2,3);if(SET.parts&&rnd()<.2)parts.push({x:p.x+rr(-3,3),y:p.y-12,vx:rr(-6,6),vy:rr(-30,-14),t:0,life:.8,col:'#ff9a3a',glow:true,g:0});}
  if(p.stele&&!(P.codex&&P.codex['stele:'+p.stele])){const k=(tGame*2)%1;ctx.strokeStyle=`rgba(154,216,255,${1-k})`;ctx.beginPath();ctx.ellipse(p.x,p.y-4,6+k*10,(6+k*10)*.4,0,0,7);ctx.stroke();}
  if(p.fountain&&SET.parts&&rnd()<.3)parts.push({x:p.x+rr(-3,3),y:p.y-34,vx:rr(-14,14),vy:rr(-30,-10),t:0,life:.7,col:'#a8d4ff',g:90});}
let mmT=0;
function drawMinimap(){const c=$('#mm');if(!M||!M.mm)return;const g=c.getContext('2d'),W=c.width,H=c.height,sc=Math.min(W/M.w,H/M.h),ox=(W-M.w*sc)/2,oy=(H-M.h*sc)/2;
  g.fillStyle='#07060b';g.fillRect(0,0,W,H);g.imageSmoothingEnabled=false;g.drawImage(M.mm,ox,oy,M.w*sc,M.h*sc);
  const dot=(x,y,col,s)=>{g.fillStyle=col;g.fillRect(Math.round(ox+x/TS*sc-s/2),Math.round(oy+y/TS*sc-s/2),s,s);};
  for(const p of M.portals)dot(p.x,p.y,'#c58cff',4);if(M.stairs)dot(M.stairs.x,M.stairs.y,'#ffffff',4);
  for(const n of M.npcs)dot(n.x,n.y,'#ffd36a',3);
  const id=curId();for(const b of bots)if(!b.dead&&b.map===id)dot(b.x,b.y,b.party?'#9be3ff':botHostileToPlayer(b)?'#ff4a4a':FACTIONS[b.fac].c,2);
  for(const m of mons)if(!m.dead&&m.t.boss)dot(m.x,m.y,'#ff3a3a',5);
  if(M.fort)dot(M.fort.x,M.fort.y,WAR.own?FACTIONS[WAR.own].c:'#e8e0d0',5);
  for(const e of M.exits||[]){const mid=(e.a+e.b)/2*TS+8;const [x,y]=e.dir==='e'?[M.w*TS-8,mid]:e.dir==='w'?[8,mid]:e.dir==='n'?[mid,8]:[mid,M.h*TS-8];dot(x,y,'#7ff3ff',4);}
  dot(P.x,P.y,'#ffffff',4);dot(P.x,P.y,'#000000',2);}
