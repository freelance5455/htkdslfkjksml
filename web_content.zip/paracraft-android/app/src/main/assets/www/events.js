/* ================== Paracraft Online · événements ==================
   Inscriptions auprès du PNJ « Événements » de n'importe quelle ville de sa faction
   (capitale et camps des territoires 1–20).
   Hot Time · saisons · lettres d'anniversaire · invasions de capitale · champ de bataille 10v10
   · siège des monuments de guilde · registre kill & steal des boss de monde · Phare des Éclats · raids à clé */

const EXTRA_PANELS={},EXTRA_ACT={};
const EV={bf:null,q:null,inv:{st:'idle',t:360,wave:0,kills:0,chef:null,city:null,ann:false},sg:{st:'idle',t:600,map:null,pts:null,ann:false},tick:0,banT:0,taxT:60};

/* ---------- données complémentaires ---------- */
for(const S of SEASONS)CONS['comp_'+S.id]={n:S.comp,d:'Monnaie de la '+S.n+'. À échanger auprès du PNJ des événements.',price:5};
for(const L of Object.keys(LETTERS))CONS['lettre_'+L]={n:'Lettre '+L,d:"Lettre de l'anniversaire de Paracraft. Forme le mot PARACRAFT.",price:20};
MT.cristal.keep=1;MT.cristal.agr=false;MT.chefhorde.hp=1.2;
Object.assign(DUNGEONS.phare,{floors:10,everyBoss:1,style:'phare',monsFl:f=>PHARE_MONS[f-1].map(t=>[t,PHARE_FL[f].lv]),bossFl:f=>[PHARE_FL[f].g,PHARE_FL[f].lv+2]});
MAPS.bf_vallee={n:'Vallée des Échos',side:null,pvp:true,biome:'steppe',lv:[1,50],tier:0,ex:{},mons:[],bf:true};
MAP_LORE.bf_vallee="Une vallée hors du monde, ouverte par les mages des deux camps pour que la guerre s'y joue sans brûler les villages.";
const HORN_SHOP=[['potpvp',2,1],['ench1',3,1],['fragcle',6,1],['boite',5,1],['ench2',12,1],['ench3',40,1]];
const WORD='PARACRAFT';

/* ---------- sprites ---------- */
const CRYS_A=["....CC....","...CLLC...","..CLLWLC..","..CLLLLC..",".CLLWLLLC.",".CLLLLLLC.",".CLLLLWLC.","..CLLLLC..","..CLLLLC..","...CLLC...","..SSSSSS..",".SSDDDDSS.","SSDDDDDDSS"];
function buildEvSprites(){Object.assign(MSPR,{
  g_capnoye:humMon({skin:'#6a9aa8',eye:'#d8f8ff',hair:'#2a4a4a',body:'#2a3a5a',body2:'#1a2a3a',legs:'#1a2a3a',extra:'helm',weapon:'sword',cape:'#1a3a4a'},2),
  g_verre:humMon({skin:'#c8f0ff',eye:'#7ff3ff',hairStyle:'bald',body:'#9ad8f0',body2:'#6ab0d8',legs:'#6ab0d8',weapon:'staff',orb:'#7ff3ff'},2),
  g_phare:humMon({skin:'#d8c8a8',eye:'#ffe14a',hairStyle:'bald',body:'#8a7a5a',legs:'#5a4a3a',extra:'helm',plume:'#ffe14a',weapon:'halberd'},2),
  g_echo:humMon({skin:'#e8d8ff',eye:'#c58cff',hair:'#c58cff',hairStyle:'long',body:'#5a3a8a',body2:'#3a2468',robe:true,weapon:'staff',orb:'#c58cff',cape:'#3a2468'},2),
  g_lumiere:humMon({skin:'#fff4d8',eye:'#ffffff',hair:'#f2c14e',hairStyle:'long',body:'#f4ead0',body2:'#e0c070',robe:true,extra:'crown',weapon:'staff',orb:'#ffffff',cape:'#f2c14e'},3),
  forgemaitre:humMon({skin:'#a85a3a',eye:'#ffb030',hairStyle:'bald',body:'#3a3a40',body2:'#2a2a30',legs:'#2a2a30',belt:'#ff8a2a',extra:'helm',weapon:'hammer'},3),
  chefhorde:humMon({skin:'#7a8a4a',eye:'#ff4a4a',hair:'#2a2a1a',body:'#5a3a22',legs:'#3a2a1a',extra:'helm',plume:'#c83a2a',weapon:'axe'},2),
  cristal:rowSet(CRYS_A,CRYS_A,{C:'#3a6a9a',L:'#8ad8ff',W:'#ffffff',S:'#5a5a6a',D:'#3a3a48'},3)});}

/* ---------- horloge réelle : Hot Time, saisons, anniversaire ---------- */
function hotTime(){const h=new Date().getHours();return h===12||h===20||h===21;}
function nextHot(){const d=new Date(),h=d.getHours(),m=d.getMinutes();const starts=[12,20];for(const s of starts)if(h<s)return(s-h)*60-m;return(24-h+12)*60-m;}
function inRange(m0,d0,m1,d1){const d=new Date(),m=d.getMonth()+1,dd=d.getDate(),v=m*100+dd,a=m0*100+d0,b=m1*100+d1;return a<=b?v>=a&&v<=b:v>=a||v<=b;}
function season(){return SEASONS.find(S=>inRange(S.m0,S.d0,S.m1,S.d1))||null;}
function anniv(){return inRange(11,1,11,14);}
const _xpMult=xpMult;xpMult=function(){return _xpMult()+(hotTime()?.5:0);};

/* ---------- butin d'événement ---------- */
const _dropLoot=dropLoot;dropLoot=function(m,near){_dropLoot(m,near);if(!m.tag||m.team)return;
  const lc=lvlColor(m.lv,P.lvl);if(lc.x<=0)return;const cons={};
  const S=season();if(S&&rnd()<(m.t.boss?1:.14*(hotTime()?1.5:1)))cons['comp_'+S.id]=m.t.boss?ri(3,6):1;
  if(anniv()&&rnd()<.07){const tot=Object.values(LETTERS).reduce((a,b)=>a+b,0);let r=rnd()*tot;for(const [L,w] of Object.entries(LETTERS)){r-=w;if(r<=0){cons['lettre_'+L]=1;break;}}}
  if(hotTime()&&rnd()<.15)cons.pv=1;
  if((MAPS[curId()]||{}).pvp&&m.elite&&rnd()<.25)cons.fragcle=1;
  if(Object.keys(cons).length)bags.push({x:m.x+rr(-8,8),y:m.y+rr(2,8),items:[],cons,res:{},gold:0,t:90,owner:'p'});};

/* ---------- boîtes ---------- */
const _useCons=useCons;useCons=function(k){if((k==='boite'||k==='boiteanniv')&&P.cons[k]>0){P.cons[k]--;const got=[],add=(x,n)=>{P.cons[x]=(P.cons[x]||0)+n;got.push(n+' × '+CONS[x].n);};
    if(k==='boite'){add(pick(['pv','pm']),3);const g=ri(100,300);P.gold+=g;got.push(g+' or');if(rnd()<.2)add('ench1',1);if(rnd()<.05)add('ench2',1);if(rnd()<.04){const b=bookKey();if(b)add(b,1);}}
    else{const g=ri(500,1000);P.gold+=g;got.push(g+' or');add('ench2',1);if(rnd()<.3)add('ench3',1);add('friandise',1);if(rnd()<.15){const b=bookKey();if(b)add(b,1);}}
    toast(CONS[k].n+' ouverte',got.join(' · '));burst(P.x,P.y-14,'#f2c14e',16);return;}
  return _useCons(k);};

/* ---------- registre des boss de monde : kill & steal ---------- */
const _hitMon=hitMon;hitMon=function(m,dmg,col,fromParty,crit){if(m.t.wb&&!fromParty){m.dmgP=(m.dmgP||0)+dmg;m.lastBy='P';}return _hitMon(m,dmg,col,fromParty,crit);};
const _botAttack=botAttack;botAttack=function(b,t,d){if(t&&t.kind==='m')t.lastBy=b;return _botAttack(b,t,d);};
const _onWbKill=onWbKill;onWbKill=function(m){const share=(m.dmgP||0)/m.maxhp,killerB=m.lastBy&&m.lastBy!=='P'?m.lastBy:null;
  const mine=P.guild?P.guild.name:P.name;const killer=m.lastBy==='P'?mine:killerB?(killerB.guild||killerB.n):'les soldats';
  const top=share>=.35?mine:killer;const stolen=top!==killer;
  P.ev.ledger=[{b:MT[m.type].n,map:MAPS[curId()].n,k:killer,top,share:Math.round(share*100),stolen,at:Date.now()}].concat(P.ev.ledger||[]).slice(0,10);
  if(stolen&&top===mine){P.cons.boite=(P.cons.boite||0)+1;P.honor+=60;toast('Kill volé par '+killer,'Ta part de dégâts ('+Math.round(share*100)+' %) est inscrite au registre : 1 boîte surprise et 60 honneur en compensation');chat(null,`Registre : ${killer} a volé le dernier coup sur ${MT[m.type].n} (dégâts majoritaires : ${mine}).`);}
  else if(stolen&&killer===mine){chat(null,`Registre : ${mine} a volé ${MT[m.type].n} ! Le butin est à vous, mais l'honneur reste au registre.`);}
  return _onWbKill(m);};

/* ---------- donjons d'événement : Phare, raids à clé ---------- */
const _enterDungeon=enterDungeon;enterDungeon=function(portal){const D=DUNGEONS[portal.dg];
  if(D.raid){if(P.lvl<D.lv[0]-2){toast(D.n,'Niveau '+D.lv[0]+' requis');return;}if(!(P.cons[D.key]>0)){toast(D.n+' : clé requise',CONS[D.key].n+' · se forge auprès du PNJ des événements avec des fragments de clé');return;}P.cons[D.key]--;}
  if(portal.dg==='phare'&&P.lvl<19){toast('Phare des Éclats','Niveau 21 conseillé, 19 minimum');return;}
  _enterDungeon(portal);if(D.raid&&dgRun){dgRun.timer=D.timer;chat(null,`${D.n} : ${Math.round(D.timer/60)} minutes pour abattre le boss. La clé est consumée.`);}};
const _killMon=killMon;killMon=function(m){const wasDead=m.dead;_killMon(m);if(wasDead)return;if(EV.inv.st==='active'&&m===EV.inv.chef){if(m.tag)EV.inv.kills++;invEnd(true);return;}if(!m.tag)return;
  if(dgRun&&m.t.boss){const D=DUNGEONS[dgRun.dg];
    if(dgRun.dg==='phare'){const f=dgRun.floor;P.ev.phare=Math.max(P.ev.phare||0,f);if(rnd()<.45)bags.push({x:m.x,y:m.y+6,items:[],cons:{fragcle:ri(1,2)},res:{},gold:0,t:90,owner:'p'});toast('Phare des Éclats · étage '+f+' libéré',f<10?'L’escalier mène à l’étage '+(f+1):'Le sommet est à toi. Record : étage 10');}
    if(D.raid&&dgRun.timer!=null){toast(D.n+' terminé','Temps restant : '+fmtT(dgRun.timer));dgRun.timer=null;P.cons.ench3=(P.cons.ench3||0)+1;const b=bookKey(m);if(b)P.cons[b]=(P.cons[b]||0)+1;chat(null,'Butin de raid : un parchemin majeur et un grimoire ajoutés à ton sac.');}}
  if(EV.inv.st==='active'&&m.inv)EV.inv.kills++;};

/* ---------- inscriptions ---------- */
function signed(k){return!!(P.ev.sign&&P.ev.sign[k]);}
function signUp(k){P.ev.sign=P.ev.sign||{};
  if(k==='bf'){if(P.lvl<10)return'Niveau 10 requis pour le champ de bataille';if(EV.bf)return'Tu es déjà sur le champ de bataille';if(EV.q)return'Tu es déjà dans la file';EV.q={t:rr(8,14)};return'Inscrit. Les escouades de soldats se rassemblent…';}
  if(k==='siege'&&!P.guild)return'Il faut une guilde pour inscrire au siège';
  if(k==='siege'&&P.lvl<21)return'Niveau 21 requis (zones contestées)';
  P.ev.sign[k]=true;return k==='inv'?'Tu défendras '+FACTIONS[P.fac].capN+' à la prochaine invasion : bonus de récompense ×1,5':'Ta guilde « '+P.guild.name+' » est inscrite au prochain siège';}

/* ---------- champ de bataille 10v10 ---------- */
function bfBase(fac){return{x:(fac==='solarix'?7:65)*TS,y:27*TS};}
function bfName(){return pick(BF_SYL)+pick(BF_SUF);}
function bfStart(){const foe=P.fac==='solarix'?'umbra':'solarix',mode=pick(Object.keys(BF_MODES));
  const ret=dgRun?dgRun.ret:{map:P.map,x:P.x,y:P.y};dgRun=null;
  EV.bf={mode,t:300,sc:{solarix:0,umbra:0},foe,ret,kills:0,deaths:0,setup:false,flags:null,crys:null};
  for(const fac of [P.fac,foe]){const n=fac===P.fac?9:10;for(let i=0;i<n;i++){const cls=['guerrier','archer','mage'][i%3],lvl=clamp(P.lvl+ri(-2,2),1,50);
    const b={kind:'b',n:['Fantassin','Archer','Mage de guerre'][i%3]+(fac==='solarix'?' d’Aurelia':' de Nocthar'),npc:1,cls,fac,lvl,guild:null,pk:false,x:0,y:0,dir:'d',anim:0,atkT:0,talk:rr(20,60),stuck:0,mt:1e9,dead:false,rt:0,stun:0,root:0,healT:0,war:false,placed:false,bf:true,bfi:i};
    b.maxhp=Math.round(60+lvl*16);b.hp=b.maxhp;b.atk=Math.round(10+lvl*3.4);b.def=Math.round(3+lvl*1.4);b.look=botLook(cls,fac,i+3);b.home='bf_vallee';b.map='bf_vallee';bots.push(b);}}
  toast('Champ de bataille : '+BF_MODES[mode],'Solarix contre Umbra · 10 contre 10 · 5 minutes');
  transition('bf_vallee',Object.assign({},bfBase(P.fac)));}
function bfArena(){const base=BIOME_GT.steppe;for(let ty=1;ty<M.h-1;ty++)for(let tx=1;tx<M.w-1;tx++){const i=ty*M.w+tx;if(M.gr[i]!==GT.ROAD)M.gr[i]=base;M.sol[i]=0;if(M.blocked)M.blocked[i]=0;}
  M.props=[];M.lights=[];M.nodes=[];M.steles=[];M.signs=[];M.portals=[];M.npcs=[];M.stations=[];
  for(const fac of ['solarix','umbra']){const b=bfBase(fac);for(const dy of [-60,60])addProp(M,'banner_'+fac,b.x+(fac==='solarix'?-20:20),b.y+dy);addProp(M,'campfire',b.x,b.y+30,{light:{r:80,c:'#ffb050'},fire:1});}
  const R=mulberry(7);for(let k=0;k<40;k++){const tx=2+Math.floor(R()*(M.w-4)),ty=2+Math.floor(R()*(M.h-4));if(Math.abs(ty-27)<12)continue;addProp(M,pick(['rock','bush','bones']),tx*TS+8,ty*TS+14);}
  bakeMap(M);}
function bfSetup(){const B=EV.bf;B.setup=true;const mid=27*TS;bfArena();
  if(B.mode==='cristal'){B.crys={};for(const fac of ['solarix','umbra']){const s=bfBase(fac),p=nearFree(s.x+(fac==='solarix'?40:-40),s.y);const m=spawnMon({type:'cristal',lv:P.lvl,x:p.x,y:p.y});m.team=fac;m.respawn=1e9;m.name='Cristal '+FACTIONS[fac].n;m.maxhp=m.hp=Math.round(m.maxhp*2.2);B.crys[fac]=m;}}
  if(B.mode==='drapeaux'){B.flags=[22,36,50].map((tx,i)=>{const p=nearFree(tx*TS,mid+(i===1?0:(i?1:-1)*5*TS));const pr=addProp(M,'obelisk',p.x,p.y+6);return{x:p.x,y:p.y,own:null,pr,n:['Ouest','Centre','Est'][i]};});}
  bfGoals();}
function bfGoals(){const B=EV.bf;for(const b of bots){if(!b.bf)continue;const own=bfBase(b.fac),foeB=bfBase(b.fac==='solarix'?'umbra':'solarix');
  if(B.mode==='cristal'){const atk=b.bfi%3!==2,c=B.crys&&B.crys[atk?(b.fac==='solarix'?'umbra':'solarix'):b.fac];b.goal=c?{x:c.x+rr(-30,30),y:c.y+rr(-30,30)}:{x:foeB.x,y:foeB.y};}
  else if(B.mode==='drapeaux'&&B.flags){const f=B.flags[b.bfi%3];b.goal={x:f.x+rr(-26,26),y:f.y+rr(-20,20)};}
  else b.goal={x:(own.x+foeB.x)/2+rr(-90,90),y:27*TS+rr(-120,120)};}}
function bfTick(){const B=EV.bf;if(curId()!=='bf_vallee')return;if(!B.setup)bfSetup();
  const other=f=>f==='solarix'?'umbra':'solarix';
  if(B.mode==='cristal'&&B.crys){for(const fac of ['solarix','umbra']){const c=B.crys[fac];if(c.dead)continue;let n=0;for(const b of bots)if(b.bf&&!b.dead&&b.fac!==fac&&dist(b,c)<130)n++;if(n){c.hp-=c.maxhp*.006*n;c.hitT=.1;}if(c.hp<=0){c.hp=0;c.dead=true;c.rt=1e9;burst(c.x,c.y-20,'#8ad8ff',30);}}
    B.sc.solarix=Math.round((1-B.crys.umbra.hp/B.crys.umbra.maxhp)*100);B.sc.umbra=Math.round((1-B.crys.solarix.hp/B.crys.solarix.maxhp)*100);
    if(B.crys.solarix.dead||B.crys.umbra.dead)return bfEnd();}
  if(B.mode==='drapeaux'&&B.flags){for(const f of B.flags){const cnt={solarix:0,umbra:0};if(P.hp>0&&dist(P,f)<60)cnt[P.fac]++;for(const b of bots)if(b.bf&&!b.dead&&dist(b,f)<60)cnt[b.fac]++;
      if(cnt.solarix!==cnt.umbra){const w=cnt.solarix>cnt.umbra?'solarix':'umbra';if(f.own!==w){f.own=w;f.pr.k='banner_'+w;chat(null,`Drapeau ${f.n} capturé par ${FACTIONS[w].n}.`);}}
      if(f.own)B.sc[f.own]+=1;}
    if(B.sc.solarix>=200||B.sc.umbra>=200)return bfEnd();}
  if(B.mode==='kills'&&(B.sc.solarix>=25||B.sc.umbra>=25))return bfEnd();
  if(rnd()<.08)bfGoals();}
function bfEnd(){const B=EV.bf;if(!B)return;const w=B.sc.solarix===B.sc.umbra?null:B.sc.solarix>B.sc.umbra?'solarix':'umbra',win=w===P.fac;
  const horns=w?(win?3:1):2,hon=win?90:30,xp=Math.round(xpNeed(P.lvl)*(win?.18:.08));
  P.ev.horns=(P.ev.horns||0)+horns;P.honor+=hon;
  toast(w?(win?'Victoire !':'Défaite'):'Égalité',`${horns} Corne${horns>1?'s':''} de Bravoure · ${hon} honneur · ${xp} XP`);chat(null,`Champ de bataille (${BF_MODES[B.mode]}) : ${w?FACTIONS[w].n+' l’emporte':'égalité'} · ${B.sc.solarix} à ${B.sc.umbra}. Tes kills : ${B.kills}.`);
  bots=bots.filter(b=>!b.bf);for(const m of mons)if(m.team){m.dead=true;m.rt=1e9;}EV.bf=null;mapCache.delete('bf_vallee');
  const r=B.ret;setTimeout(()=>{gainXp(xp);qEvent('pvp');},50);transition(r.map,{x:r.x,y:r.y});}
const _killBot=killBot;killBot=function(o,src){_killBot(o,src);const B=EV.bf;if(!B||!o.bf)return;o.rt=6;const kf=o.fac==='solarix'?'umbra':'solarix';
  if(B.mode==='kills')B.sc[kf]++;else if(B.mode==='drapeaux')B.sc[kf]+=3;else if(B.crys){const c=B.crys[o.fac];if(c&&!c.dead){c.hp-=c.maxhp*.025;c.hitT=.1;}}if(src===P)B.kills++;};
const _die=die;die=function(src){const B=EV.bf;if(B&&curId()==='bf_vallee'){const s=stats(),b=bfBase(P.fac);B.deaths++;if(B.crys&&!B.crys[P.fac].dead)B.crys[P.fac].hp-=B.crys[P.fac].maxhp*.025;if(B.mode==='kills')B.sc[B.foe]++;else if(B.mode==='drapeaux')B.sc[B.foe]+=3;
    P.hp=s.maxhp;P.mp=s.maxmp;P.x=b.x;P.y=b.y;P.inv0=3;P.target=null;toast('Tu réapparais à ta base','Vaincu par '+(src||'un ennemi')+' · aucune perte d’expérience ici');return;}
  return _die(src);};

/* ---------- invasions de capitale ---------- */
function invTypes(){const m=MAPS[mapForLevel(P.lvl,P.fac)];return(m&&m.mons||[['loup']]).map(x=>x[0]);}
function invSpawn(n){const sp=M.spawnPt||{x:M.w*8,y:M.h*8},ty=invTypes();for(let i=0;i<n;i++){const a=rnd()*6.28,p=nearFree(sp.x+Math.cos(a)*rr(180,260),sp.y+Math.sin(a)*rr(150,220));
  const m=spawnMon({type:pick(ty),lv:clamp(P.lvl+ri(-1,1),2,50),x:p.x,y:p.y});m.inv=1;m.respawn=1e9;m.agg=true;m.name='Envahisseur · '+m.t.n;m.aggro=400;}}
function invTick(dt){const I=EV.inv;I.t-=dt;
  if(I.st==='idle'){if(I.t<=30&&!I.ann){I.ann=true;chat(null,`Les éclaireurs sonnent l'alarme : une horde marche sur ${FACTIONS[P.fac].capN} ! Arrivée dans 30 secondes.`);}
    if(I.t<=0){I.st='active';I.t=180;I.wave=0;I.kills=0;I.chef=null;I.city=FACTIONS[P.fac].cap;I.ann=false;toast('Invasion de '+FACTIONS[P.fac].capN+' !',signed('inv')?'Tu es inscrit : rejoins la défense depuis la bannière':'Inscris-toi auprès du PNJ des événements pour toucher le bonus');}}
  else{if(curId()===I.city){const alive=mons.filter(m=>m.inv&&!m.dead).length;
      if(!alive&&I.wave<3){I.wave++;invSpawn(4+I.wave*2);chat(null,`Vague ${I.wave} sur 3 aux portes de ${FACTIONS[P.fac].capN} !`);}
      else if(!alive&&I.wave>=3&&!I.chef){const sp=M.spawnPt,p=nearFree(sp.x,sp.y-200);I.chef=spawnMon({type:'chefhorde',lv:clamp(P.lvl+2,4,52),x:p.x,y:p.y});I.chef.inv=1;I.chef.respawn=1e9;I.chef.agg=true;toast('Le chef de horde arrive','Abats-le pour sauver la cité');}}
    if(I.t<=0)invEnd(curId()!==I.city&&rnd()<.7);}}
function invEnd(won){const I=EV.inv,part=I.kills>0,mul=signed('inv')?1.5:1;
  for(const m of mons)if(m.inv){m.dead=true;m.rt=1e9;}
  if(won){chat(null,`${FACTIONS[P.fac].capN} a repoussé l'invasion !`);addBuff({id:'invwin',n:'Cité sauvée',xp:.1,t:600});}else chat(null,`La horde a pillé les faubourgs de ${FACTIONS[P.fac].capN}.`);
  if(part){const g=Math.round((50+P.lvl*12)*mul*(won?1:.5)),h=Math.round(30*mul);P.gold+=g;P.honor+=h;P.cons.boite=(P.cons.boite||0)+(won?1:0);toast(won?'Invasion repoussée':'Invasion terminée',`${I.kills} envahisseurs abattus · ${g} or · ${h} honneur${won?' · 1 boîte surprise':''}`);}
  I.st='idle';I.t=900;I.chef=null;I.wave=0;if(P.ev.sign)P.ev.sign.inv=false;}
function joinInv(){if(EV.inv.st!=='active')return;if(EV.bf)return;dgRun=null;transition(EV.inv.city,{});}

/* ---------- siège des monuments de guilde ---------- */
function monOwner(map){return(P.ev.mon||{})[map]||null;}
function sgTick(dt){const G=EV.sg;G.t-=dt;
  if(G.st==='idle'){if(G.t<=30&&!G.ann){G.ann=true;G.map=pick(Object.keys(MONUMENTS));chat(null,`Siège dans 30 s : ${MONUMENTS[G.map]} (${MAPS[G.map].n}). Les guildes inscrites s'y rassemblent.`);}
    if(G.t<=0){G.st='active';G.t=180;G.pts={me:0,them:0};G.ann=false;G.map=G.map||pick(Object.keys(MONUMENTS));toast('Siège : '+MONUMENTS[G.map],signed('siege')?'Ta guilde est inscrite : tiens le monument':'Inscris ta guilde auprès du PNJ des événements');
      const pool=bots.filter(b=>b.guild&&!b.party&&!b.war&&!b.wb&&!b.bf&&b.lvl>=21).slice(0,10);for(const b of pool){b.sg=true;b.map=G.map;if(curId()===G.map)placeBot(b);}}}
  else{if(curId()===G.map&&M.monPos&&!G.spawned){G.spawned=true;const ty=(MAPS[G.map].mons||[]).filter(x=>!MT[x[0]].boss).map(x=>x[0]);for(let k=0;k<5&&ty.length;k++){const p=nearFree(M.monPos.x+rr(-60,60),M.monPos.y+rr(-50,50));const m=spawnMon({type:pick(ty),lv:MAPS[G.map].lv[1],x:p.x,y:p.y});m.sgd=1;m.respawn=1e9;m.name='Garde du monument';}chat(null,'Des gardes défendent le monument : abats-les puis tiens la position.');}
    if(curId()===G.map&&M.monPos&&signed('siege')){let me=0,them=0;if(P.hp>0&&dist(P,M.monPos)<85)me++;for(const m of mons)if(m.sgd&&!m.dead&&dist(m,M.monPos)<120)them++;
      if(me>them)G.pts.me++;else if(them>me)G.pts.them++;}
    if(G.t<=0)sgEnd();}}
function sgEnd(){const G=EV.sg;P.ev.mon=P.ev.mon||{};let g;
  if(signed('siege')&&G.pts.me>G.pts.them&&P.guild){g={g:P.guild.name,fac:P.fac};P.honor+=80;toast(MONUMENTS[G.map]+' conquis !','La guilde « '+P.guild.name+' » perçoit désormais la taxe du monument');}
  else{const fac=pick(['solarix','umbra']);g={g:'Garnison de '+FACTIONS[fac].n,fac};}
  P.ev.mon[G.map]=g;chat(null,`${MONUMENTS[G.map]} appartient désormais à la guilde ${g.g} (${FACTIONS[g.fac].n}).`);
  for(const b of bots)if(b.sg){b.sg=false;b.goal=null;b.map=b.home;}G.st='idle';G.t=1200;G.map=null;G.spawned=false;for(const m of mons)if(m.sgd){m.dead=true;m.rt=1e9;}if(P.ev.sign)P.ev.sign.siege=false;}
function taxTick(){if(!P.guild)return;for(const [mp,o] of Object.entries(P.ev.mon||{}))if(o.g===P.guild.name)P.ev.tax=(P.ev.tax||0)+Math.round(15+MAPS[mp].lv[0]);}

/* ---------- carte : monument, retour hors événement ---------- */
const _onEnterMap=onEnterMap;onEnterMap=function(){_onEnterMap();
  if(curId()==='bf_vallee'&&!EV.bf){setTimeout(()=>transition(FACTIONS[P.fac].cap,{}),60);return;}
  if(curId()==='bf_vallee'&&EV.bf&&!EV.bf.setup){bfSetup();for(const b of bots)if(b.bf)placeBot(b);}
  if(MONUMENTS[M.id]&&!M.monPos){const p=M.fort?{x:M.fort.x,y:M.fort.y}:nearFree(M.w*8+60,M.h*8+40);M.monPos=p;if(!M.fort){addProp(M,'obelisk',p.x,p.y+6,{light:{r:60,c:'#f2c14e'}});(M.signs||(M.signs=[])).push({x:p.x,y:p.y-40,t:MONUMENTS[M.id]});}}
  if(EV.sg.st==='active'&&M.id===EV.sg.map)for(const b of bots)if(b.sg)b.goal={x:M.monPos.x+rr(-50,50),y:M.monPos.y+rr(-40,40)};};

/* ---------- boucle ---------- */
const _update=update;update=function(dt){_update(dt);evTick(dt);};
function evTick(dt){if(!P||!P.ev)return;
  if(EV.q){EV.q.t-=dt;if(EV.q.t<=0){EV.q=null;bfStart();}}
  if(EV.bf){EV.bf.t-=dt;EV.tick-=dt;if(EV.tick<=0){EV.tick=1;bfTick();}if(EV.bf&&EV.bf.t<=0)bfEnd();}
  invTick(dt);sgTick(dt);
  EV.taxT-=dt;if(EV.taxT<=0){EV.taxT=60;taxTick();}
  if(dgRun&&dgRun.timer!=null){dgRun.timer-=dt;if(dgRun.timer<=0){dgRun.timer=null;toast('Temps écoulé','Le raid se referme. La clé est perdue.');leaveDungeon();}}
  EV.banT-=dt;if(EV.banT<=0){EV.banT=.5;renderBan();}}
function renderBan(){const el=$('#evBan');if(!el)return;const a=[];
  if(EV.bf){const B=EV.bf;a.push(`<b class="bfb">${BF_MODES[B.mode]} · ${fmtT(B.t)}</b> &nbsp;<span style="color:${FACTIONS.solarix.c}">${B.sc.solarix}</span> – <span style="color:${FACTIONS.umbra.c}">${B.sc.umbra}</span>`);}
  else if(EV.q)a.push('<b>File du champ de bataille</b> '+Math.ceil(EV.q.t)+' s');
  if(dgRun&&dgRun.timer!=null)a.push('<b>Raid</b> '+fmtT(dgRun.timer));
  if(EV.inv.st==='active')a.push(`<b class="red">Invasion</b> vague ${EV.inv.wave}/3 · ${fmtT(EV.inv.t)}${curId()!==EV.inv.city&&!EV.bf?' <button class="btn go" data-ev="inv" type="button">Défendre</button>':''}`);
  else if(EV.inv.t<=60)a.push('<b>Invasion</b> dans '+fmtT(EV.inv.t));
  if(EV.sg.st==='active')a.push(`<b>Siège</b> ${esc(MONUMENTS[EV.sg.map])} · ${fmtT(EV.sg.t)}${curId()===EV.sg.map&&signed('siege')?' · '+EV.sg.pts.me+' / '+EV.sg.pts.them:''}`);
  if(hotTime())a.push('<b class="gold">Hot Time</b> XP +50 %');
  const h=a.map(x=>'<div>'+x+'</div>').join('');if(el.dataset.h!==h){el.dataset.h=h;el.innerHTML=h;}el.hidden=!a.length||state!=='play';}

/* ---------- panneau du PNJ des événements ---------- */
EXTRA_PANELS.event=(s,c,fac,msg)=>{const S=season(),A=anniv(),t=panelTab=panelTab||'cal';
  const nm=(npcName('event'));let h=CLOSE+`<h2>${esc(nm)}, héraut des événements</h2><p class="sub">Toutes les inscriptions se font ici, dans n'importe quelle ville de ${fac.n}. Cornes de Bravoure : <b class="gold">${P.ev.horns||0}</b> · Or : <b class="gold">${P.gold}</b></p>`;
  const tl=[['cal','Calendrier'],['bf','Champ de bataille']];if(S)tl.push(['saison',S.n]);if(A)tl.push(['anniv','Anniversaire']);tl.push(['cles','Phare et raids'],['reg','Registre']);
  h+=tabs(tl,t);const st=(on,txt)=>`<em class="tag" style="${on?'':'opacity:.6'}">${txt}</em>`;
  if(t==='cal'){
    h+='<h3>EN CONTINU</h3>';
    h+=row(`<b>Hot Time ${st(hotTime(),hotTime()?'en cours':'dans '+Math.floor(nextHot()/60)+' h '+String(nextHot()%60).padStart(2,'0'))}</b><small>Chaque jour de 12 h à 13 h et de 20 h à 22 h : XP +50 %, butin de saison et potions plus fréquents.</small>`);
    h+=row(`<b>${S?esc(S.n):'Aucune saison'} ${st(!!S,S?'active':'—')}</b><small>${S?'Les monstres lâchent des '+esc(S.comp.toLowerCase())+'. Échange-les dans l’onglet de la saison.':'Moisson (15 sept.–5 oct.), Nuit des Ombres (20 oct.–10 nov.), Fête des Étoiles (15 déc.–6 janv.).'}</small>`);
    h+=row(`<b>Anniversaire de Paracraft ${st(A,A?'1–14 novembre':'du 1er au 14 novembre')}</b><small>Les lettres P, A, R, C, F, T tombent des monstres. Forme PARACRAFT pour la grande récompense.</small>`);
    h+='<h3>SUR INSCRIPTION</h3>';
    h+=row(`<b>Invasion de ${esc(fac.capN)} ${st(EV.inv.st==='active',EV.inv.st==='active'?'en cours':'dans '+fmtT(EV.inv.t))}</b><small>3 vagues puis un chef de horde. Inscrit : récompenses ×1,5 et retour direct en ville.${signed('inv')?' <b class="gold">Inscrit.</b>':''}</small>`,EV.inv.st==='active'?B('evjoin','Défendre','data-v="inv"','go'):B('evsign',signed('inv')?'Inscrit':'S’inscrire','data-v="inv" '+(signed('inv')?'disabled':''),'go'));
    h+=row(`<b>Siège de monument ${st(EV.sg.st==='active',EV.sg.st==='active'?esc(MONUMENTS[EV.sg.map])+' · '+fmtT(EV.sg.t):'dans '+fmtT(EV.sg.t))}</b><small>Une guilde inscrite tient le monument 3 minutes pour le conquérir, puis perçoit une taxe. Guilde et niveau 21 requis.${signed('siege')?' <b class="gold">Guilde inscrite.</b>':''}</small>`,B('evsign',signed('siege')?'Inscrite':'Inscrire ma guilde','data-v="siege" '+(signed('siege')?'disabled':''),'go'));
    h+=row(`<b>Champ de bataille 10 contre 10</b><small>Cristal, drapeaux ou score de kills. Dès le niveau 10. Voir l’onglet dédié.</small>`,B('tab','Voir','data-v="bf"'));
    const mons=Object.entries(MONUMENTS).map(([mp,n])=>{const o=monOwner(mp);return`${esc(n)} : ${o?esc(o.g)+' ('+FACTIONS[o.fac].n+')':'libre'}`;}).join(' · ');
    h+=`<h3>MONUMENTS</h3><p class="sub">${mons}</p>`;if(P.ev.tax)h+=row(`<b>Taxe de monument</b><small>${P.ev.tax} or en attente pour ta guilde</small>`,B('evtax','Percevoir','','go'));}
  else if(t==='bf'){const q=!!EV.q;
    h+=`<p class="sub">Inscris-toi : deux escouades de soldats PNJ, une par armée, se battent avec toi. Une partie dure 5 minutes. Victoire : 3 Cornes de Bravoure, 90 honneur. Défaite : 1 corne, 30 honneur. Pas de perte d’XP en cas de mort.</p>`;
    for(const [k,n] of Object.entries(BF_MODES))h+=row(`<b>${n}</b><small>${{cristal:'Détruis le cristal ennemi, défends le tien.',drapeaux:'Tiens les trois drapeaux : 1 point par seconde et par drapeau, 200 pour gagner.',kills:'Première équipe à 25 kills.'}[k]}</small>`);
    h+=`<p>${B('evsign',q?'Dans la file…':EV.bf?'Partie en cours':'S’inscrire',`data-v="bf" ${q||EV.bf?'disabled':''}`,'go big')}</p>`;
    h+='<h3>INTENDANT · CORNES DE BRAVOURE</h3>'+row(`<b>${BAGS.runique.n} ${fac.n}</b><small>${esc(BAGS.runique.d)} · +14 emplacements · 60 cornes</small>`,B('hornbag','Échanger',(P.ev.horns||0)<60?'disabled':'','go'))+HORN_SHOP.map(([k,p,n])=>row(`<b>${esc(CONS[k].n)}</b><small>${esc(CONS[k].d||'')} · ${p} corne${p>1?'s':''}</small>`,B('evhorn','Échanger',`data-v="${k}" data-p="${p}" data-n="${n}" ${(P.ev.horns||0)<p?'disabled':''}`,'go'))).join('');}
  else if(t==='saison'&&S){const ck='comp_'+S.id,have=P.cons[ck]||0;h+=`<p class="sub">${esc(S.npc)} échange les ${esc(S.comp.toLowerCase())} récoltées sur les monstres. Tu en as <b class="gold">${have}</b>.</p>`;
    for(const [k,n,lab] of [['friandise',10,'Friandise de saison'],['boite',25,'Boîte surprise'],['livre',60,'Grimoire aléatoire de ta classe']])h+=row(`<b>${lab}</b><small>${n} ${esc(S.comp.toLowerCase())}</small>`,B('evseason','Échanger',`data-v="${k}" data-n="${n}" ${have<n?'disabled':''}`,'go'));}
  else if(t==='anniv'&&A){const cnt=w=>{const need={};for(const ch of w)need[ch]=(need[ch]||0)+1;return Object.entries(need).every(([L,n])=>(P.cons['lettre_'+L]||0)>=n);};
    h+=`<p class="sub">Tes lettres : ${Object.keys(LETTERS).map(L=>`<b>${L}</b> ×${P.cons['lettre_'+L]||0}`).join(' · ')}</p>`;
    h+=row(`<b>PARACRAFT</b><small>Boîte d’anniversaire et grand gâteau (+30 % XP, 1 h)</small>`,B('evword','Former','data-v="PARACRAFT" '+(cnt('PARACRAFT')?'':'disabled'),'go'));
    h+=row(`<b>CRAFT</b><small>Gâteau d’anniversaire (+20 % XP, 30 min)</small>`,B('evword','Former','data-v="CRAFT" '+(cnt('CRAFT')?'':'disabled'),'go'));}
  else if(t==='cles'){h+=`<p class="sub">Phare des Éclats : 10 étages dans la Frontière, un gardien par étage. Ton record : étage <b class="gold">${P.ev.phare||0}</b>. Les gardiens et les élites des zones contestées lâchent des fragments de clé (tu en as ${P.cons.fragcle||0}).</p><h3>FORGER UNE CLÉ DE RAID</h3>`;
    for(const R of KEY_RECIPES){const D=Object.values(DUNGEONS).find(d=>d.key===R.id),ok=Object.entries(R.ing).every(([k,n])=>((RES[k]?P.res[k]:P.cons[k])||0)>=n);
      h+=row(`<b>${esc(CONS[R.id].n)}</b><small>${esc(D.n)} · niv. ${D.lv[0]}+ · ${Math.round(D.timer/60)} min · ${Object.entries(R.ing).map(([k,n])=>n+' × '+(RES[k]?RES[k].n:CONS[k].n)+' ('+((RES[k]?P.res[k]:P.cons[k])||0)+')').join(', ')}</small>`,B('evkey','Forger',`data-v="${R.id}" ${ok?'':'disabled'}`,'go'));}
    h+='<p class="sub">Les portails des raids se trouvent sur les Terres maudites. La clé est consumée à l’entrée.</p>';}
  else if(t==='reg'){const L=P.ev.ledger||[];h+='<p class="sub">Registre kill & steal des boss de monde : qui a fait le plus de dégâts, qui a porté le dernier coup. Un kill volé avec plus de 35 % de dégâts est compensé.</p>';
    h+=L.length?L.map(e=>row(`<b>${esc(e.b)} · ${esc(e.map)}</b><small>Dernier coup : ${esc(e.k)} · dégâts majoritaires : ${esc(e.top)} (${e.share} % pour toi)${e.stolen?' · <span style="color:#ff7a7a">volé</span>':''}</small>`)).join(''):'<p class="sub">Aucun boss de monde abattu pour l’instant. Le Titan des Terres maudites et le Wyrm des Abysses réapparaissent régulièrement.</p>';}
  return h+msg();};
EXTRA_ACT.evsign=v=>{panelMsg=esc(signUp(v));};
EXTRA_ACT.evjoin=v=>{if(v==='inv'){closePanel(true);joinInv();return false;}};
EXTRA_ACT.evtax=()=>{P.gold+=P.ev.tax||0;panelMsg='Tu perçois '+(P.ev.tax||0)+' or de taxe.';P.ev.tax=0;};
EXTRA_ACT.evhorn=(v,b)=>{const p=+b.dataset.p;if((P.ev.horns||0)>=p){P.ev.horns-=p;P.cons[v]=(P.cons[v]||0)+(+b.dataset.n);panelMsg='Échange effectué : '+esc(CONS[v].n);}};
EXTRA_ACT.evseason=(v,b)=>{const S=season(),ck='comp_'+S.id,n=+b.dataset.n;if((P.cons[ck]||0)<n)return;P.cons[ck]-=n;let k=v;if(v==='livre'){const ix=CLASSES[P.cls].tags.map((g,i)=>g!=='inne'&&g!=='city'&&g!=='wb'?i:-1).filter(i=>i>0);k='livre_'+P.cls+'_'+pick(ix);}P.cons[k]=(P.cons[k]||0)+1;panelMsg='Reçu : '+esc(CONS[k].n);};
EXTRA_ACT.evword=v=>{const need={};for(const ch of v)need[ch]=(need[ch]||0)+1;for(const [L,n] of Object.entries(need))if((P.cons['lettre_'+L]||0)<n)return;for(const [L,n] of Object.entries(need))P.cons['lettre_'+L]-=n;
  if(v==='PARACRAFT'){P.cons.boiteanniv=(P.cons.boiteanniv||0)+1;P.cons.grandgateau=(P.cons.grandgateau||0)+1;panelMsg='Joyeux anniversaire ! Boîte d’anniversaire et grand gâteau reçus.';}else{P.cons.gateau=(P.cons.gateau||0)+1;panelMsg='Gâteau d’anniversaire reçu.';}};
EXTRA_ACT.evkey=v=>{const R=KEY_RECIPES.find(r=>r.id===v);if(!R)return;const get=k=>(RES[k]?P.res[k]:P.cons[k])||0;if(!Object.entries(R.ing).every(([k,n])=>get(k)>=n))return;for(const [k,n] of Object.entries(R.ing)){if(RES[k])P.res[k]-=n;else P.cons[k]-=n;}P.cons[v]=(P.cons[v]||0)+1;panelMsg='Forgé : '+esc(CONS[v].n);};
document.addEventListener('click',e=>{const b=e.target.closest('[data-ev]');if(!b)return;if(b.dataset.ev==='inv')joinInv();});
