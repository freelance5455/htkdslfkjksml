'use strict';
/* ================== Paracraft Online · connexion et inscription ==================
   Comptes locaux (cet appareil) : nom de compte + mot de passe haché, « rester connecté »,
   personnages rangés par compte. Fond : vue réelle du royaume d'Aurelia. */

/* plus de faux joueurs : guildes fictives et vendeurs nommés retirés */
GUILDS.solarix.length=0;GUILDS.umbra.length=0;BOT_NAMES.solarix=['Comptoir royal d’Aurelia'];BOT_NAMES.umbra=['Comptoir des Ombres'];bots=[];

const ACC_KEY='paracraft_accounts',SES_KEY='paracraft_session';
let lgMode='login';
async function hashPw(user,pw){const txt='paracraft|'+user.toLowerCase()+'|'+pw;
  try{if(crypto&&crypto.subtle){const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(txt));return[...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('');}}catch(_){}
  let h=2166136261;for(let i=0;i<txt.length;i++){h^=txt.charCodeAt(i);h=Math.imul(h,16777619);}return'f'+(h>>>0).toString(16);}
function accounts(){return loadJSON(ACC_KEY,{});}
function useAccount(user){const u=user.toLowerCase();CHAR_KEY='paracraft_chars_'+u;CHARS=loadJSON(CHAR_KEY,[]);
  const legacy=loadJSON('paracraft_chars',[]);if(!CHARS.length&&legacy.length){CHARS=legacy;saveJSON(CHAR_KEY,CHARS);try{localStorage.removeItem('paracraft_chars');}catch(_){}}
  $('#acctName').textContent=user;}
function lgSet(mode){lgMode=mode;$('#tLogin').classList.toggle('on',mode==='login');$('#tSign').classList.toggle('on',mode==='sign');$('#lgConfW').hidden=mode!=='sign';
  $('#lgGo').textContent=mode==='login'?'Se connecter':'Créer mon compte';$('#lgPass').autocomplete=mode==='login'?'current-password':'new-password';$('#lgMsg').textContent='';}
function lgMem(){const s=loadJSON(SES_KEY,null);$('#lgMemT').textContent=s?'Compte mémorisé : '+s.u:'Aucun compte mémorisé sur ce navigateur';$('#lgMem').classList.toggle('on',!!s);$('#lgChange').hidden=!s;}
function showLogin(){for(const s of ['sServer','sMain','sNew','sStats','sLogin'])$('#'+s).hidden=s!=='sLogin';$('#start').classList.add('login');lgMem();lgSet(lgMode);
  const s=loadJSON(SES_KEY,null);if(s)$('#lgUser').value=s.u;}
$('#tLogin').onclick=()=>lgSet('login');$('#tSign').onclick=()=>lgSet('sign');
$('#lgShow').onclick=()=>{const p=$('#lgPass'),c=$('#lgConf'),show=p.type==='password';p.type=c.type=show?'text':'password';$('#lgShow').textContent=show?'Cacher':'Voir';};
$('#lgChange').onclick=()=>{try{localStorage.removeItem(SES_KEY);}catch(_){}$('#lgUser').value='';$('#lgPass').value='';lgMem();$('#lgUser').focus();};
$('#lgForm').addEventListener('submit',async e=>{e.preventDefault();const msg=t=>{$('#lgMsg').textContent=t;};
  const user=($('#lgUser').value||'').trim(),pw=$('#lgPass').value||'';
  if(!/^[A-Za-z0-9_À-ÿ-]{3,16}$/.test(user))return msg('Nom de compte : 3 à 16 lettres, chiffres, - ou _.');
  if(pw.length<6)return msg('Le mot de passe doit faire au moins 6 caractères.');
  const A=accounts(),key=user.toLowerCase(),h=await hashPw(user,pw);
  if(lgMode==='sign'){if(A[key])return msg('Ce nom de compte existe déjà.');if(pw!==$('#lgConf').value)return msg('Les deux mots de passe ne correspondent pas.');A[key]={u:user,h,created:Date.now()};saveJSON(ACC_KEY,A);}
  else{if(!A[key])return msg('Compte introuvable. Crée-le avec l’onglet « Créer un compte ».');if(A[key].h!==h)return msg('Mot de passe incorrect.');}
  if($('#lgStay').checked)saveJSON(SES_KEY,{u:A[key].u});else{try{localStorage.removeItem(SES_KEY);}catch(_){}}
  $('#lgPass').value='';$('#lgConf').value='';useAccount(A[key].u);$('#start').classList.remove('login');showServers();});
$('#bLogout').onclick=()=>{try{localStorage.removeItem(SES_KEY);}catch(_){}CHARS=[];showLogin();};
scr=function(id){for(const s of ['sServer','sMain','sNew','sStats','sLogin'])$('#'+s).hidden=s!==id;$('#start').classList.toggle('login',id==='sLogin');};

/* ---------- décor : vraie vue du royaume, rangée de héros ---------- */
function buildLoginArt(){try{
  const m=getMap('sol_cap'),cx=50*TS,cy=36*TS,W=1100,H=620,c=cnv(W,H),g=c.getContext('2d');g.imageSmoothingEnabled=false;const x0=cx-W/2,y0=cy-H/2;
  g.drawImage(m.canvas,x0,y0,W,H,0,0,W,H);
  const all=[];for(const row of m.props)if(row)for(const p of row)if(p.x>x0-150&&p.x<x0+W+150&&p.y>y0-40&&p.y<y0+H+220)all.push(p);
  all.sort((a,b)=>a.y-b.y);for(const p of all){const S=PROPS[p.k];if(S)g.drawImage(S.c,Math.round(p.x-S.w/2-x0),Math.round(p.y-S.h-y0));}
  for(const n of m.npcs){if(n.x<x0||n.x>x0+W||n.y<y0||n.y>y0+H)continue;const s=humSprite(n.look,1).d[0];g.drawImage(s,Math.round(n.x-s.width/2-x0),Math.round(n.y-s.height+3-y0));}
  $('#start').style.setProperty('--bgmap',`url(${c.toDataURL()})`);}catch(e){}
  const row=$('#lgRow');row.innerHTML='';const heroes=[['guerrier','solarix',{fem:0,hs:'spiky',hc:2,sk:1}],['archer','umbra',{fem:1,hs:'pony',hc:1,sk:0}],['mage','solarix',{fem:1,hs:'long',hc:4,sk:1}],['guerrier','umbra',{fem:0,hs:'short',hc:3,sk:2}],['archer','solarix',{fem:0,hs:'short',hc:0,sk:1}],['mage','umbra',{fem:0,hs:'spiky',hc:5,sk:0}],['guerrier','solarix',{fem:1,hs:'bun',hc:1,sk:1}]];
  heroes.forEach(([cls,fac,lk],i)=>{const s=humSprite(playerLook({cls,fac,look2:lk,eq:{casque:i%2?1:null}}),3).d[0],im=document.createElement('img');im.src=s.toDataURL();im.alt='';im.style.animationDelay=(i*.18)+'s';row.appendChild(im);});
  for(const k of ['slime','loup','champi']){const s=MSPR[k];if(!s||!s.fr)continue;const im=document.createElement('img');const f=s.fr[0];im.src=(f.c||f).toDataURL();im.alt='';im.className='mon';row.insertBefore(im,row.children[Math.floor(row.children.length/2)]);}}

buildLoginArt();
{const s=loadJSON(SES_KEY,null),A=accounts();if(s&&A[s.u.toLowerCase()]){useAccount(s.u);showServers();}else showLogin();}

/* plein écran + verrouillage paysage sur mobile (refusé sans bruit si le navigateur ne le permet pas) */
function goLandscape(){if(!matchMedia('(pointer:coarse)').matches||document.fullscreenElement)return;const el=document.documentElement;
  try{const p=el.requestFullscreen&&el.requestFullscreen({navigationUI:'hide'});if(p&&p.then)p.then(()=>{try{const o=screen.orientation&&screen.orientation.lock&&screen.orientation.lock('landscape-primary');if(o&&o.catch)o.catch(()=>{});}catch(_){}}).catch(()=>{});}catch(_){}}
for(const id of ['#lgGo','#srvOk','#stOk'])$(id).addEventListener('click',goLandscape);
