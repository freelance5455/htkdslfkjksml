'use strict';
/* ===================== Interface : HUD, panneaux, écrans, contrôles ===================== */
let panelKind=null,panelTab=null,panelMsg='',panelData=null;
function toast(a,b){const el=$('#toast');el.innerHTML=esc(a)+(b?'<small>'+esc(b)+'</small>':'');el.classList.add('on');clearTimeout(toast.h);toast.h=setTimeout(()=>el.classList.remove('on'),2600);}
function renderChat(){$('#chat').innerHTML=chatLines.map(l=>{const tag=l.chan==='guild'?'[Guilde] ':l.chan==='party'?'[Groupe] ':'';const cls=l.chan==='sys'?'sys':l.chan;return l.name?`<div class="${cls}">${tag}<b style="color:${l.col||'#f1e9d6'}">${esc(l.name)}</b> : ${esc(l.txt)}</div>`:`<div class="${cls}">${tag}${esc(l.txt)}</div>`;}).join('');}
function renderTrack(){const el=$('#track');if(!P||!P.qs){el.hidden=true;return;}const ids=Object.keys(P.qs.act).sort((a,b)=>(a[0]==='M'?0:1)-(b[0]==='M'?0:1)).slice(0,3);
  if(!ids.length){const nx=Object.values(QDB).find(q=>q.chain==='main'&&!qdone(q.id)&&(!q.req||qdone(q.req)));if(!nx){el.hidden=true;return;}el.hidden=false;el.innerHTML=`<b>${esc(tok(nx.t))}</b><div>${P.lvl>=nx.lvl?'Parle à '+esc(qGiverName(nx.giver))+' ('+esc(qGiverPlace(nx.giver))+')':'Disponible au niveau '+nx.lvl}</div>`;return;}
  el.hidden=false;el.innerHTML=ids.map(id=>{const q=qDef(id),st=P.qs.act[id];if(!q)return'';if(qComplete(id))return`<b>${esc(tok(q.t))}</b><div class="done">À rendre : ${esc(qGiverName(q.end||q.giver))}</div>`;const j=q.obj.findIndex((o,jj)=>objProg(q,st,jj)<o.n),o=objText(q,j,st);return`<b>${esc(tok(q.t))}</b><div>${esc(o.t)} · ${o.pr}/${o.n}</div>`;}).join('');}
function setSkillLabels(){if(!P)return;const L=CLASSES[P.cls].sk;for(let j=0;j<6;j++){const b=$('#bS'+j);if(!b)continue;const i=P.bar[j],sk=L[i];if(!sk){b.children[1].textContent='—';b.setAttribute('data-lock','vide');continue;}b.children[1].textContent=sk.s||sk.n;b.setAttribute('data-lock',!skRank(i)?'grimoire':P.lvl<sk.lv?'niv. '+sk.lv:'');}}
function renderZone(){if(!M)return;const d=M.def;let n,l;if(M.kind==='dungeon'){const D=DUNGEONS[M.dg];n=D.n;l='Étage '+M.floor+'/'+D.floors;}else{n=d.n;l=d.kind==='city'?'Zone sûre':(d.pvp?'PvP · ':'')+'Niv. '+d.lv[0]+'–'+d.lv[1];}$('#zone').innerHTML=esc(n)+'<small class="'+(d&&d.pvp?'pvp':'')+'">'+esc(l)+'</small>';$('#bPK').hidden=!inPvp();}
const _t={};function setTxt(id,v){if(_t[id]===v)return;_t[id]=v;const e=document.getElementById(id);if(e)e.textContent=v;}
function setW(el,k){const v=Math.round(clamp(k,0,1)*1000)/10+'%';if(el._w!==v){el._w=v;el.style.width=v;}}
function hud(){if(!P||state==='title'||state==='tomb')return;const s=stats();
  setW($('#hpb i'),P.hp/s.maxhp);setTxt('hpt',Math.ceil(P.hp)+' / '+s.maxhp);setW($('#mpb i'),P.mp/s.maxmp);setTxt('mpt',Math.floor(P.mp)+' / '+s.maxmp);setW($('#xpb i'),P.lvl>=MAX_LVL?1:P.xp/xpNeed(P.lvl));
  setTxt('plv','NIV '+P.lvl);setTxt('gold',P.gold+' or · '+P.honor+' honneur');setTxt('pvn','PV '+(P.cons.pv||0));setTxt('pmn','PM '+(P.cons.pm||0));
  const pn=$('#pname');const nc=P.pkT>0?'#ff4a4a':P.pkMode?'#ff9a3a':'';if(pn._c!==nc){pn._c=nc;pn.style.color=nc;}
  $('#bPerso').classList.toggle('badge',P.pts>0);
  const sk=CLASSES[P.cls].sk;for(let j=0;j<6;j++){const b=$('#bS'+j),i=P.bar[j],x=sk[i];if(!x){b.children[0].style.height='100%';b.classList.add('off','lock');continue;}const rk=skRank(i),lock=!rk||P.lvl<x.lv;b.children[0].style.height=(lock?100:P.sk[i]/RV(x.cd,rk)*100)+'%';b.classList.toggle('off',lock||P.mp<RV(x.mp,rk));b.classList.toggle('lock',lock);}
  $('#bPV').children[0].style.height=Math.max(0,P.potT)/15*100+'%';$('#bPM').children[0].style.height=Math.max(0,P.potT)/15*100+'%';
  const it=interactTarget(),act=$('#bAct');if(it){act.hidden=false;setTxt('actl',it.l);}else act.hidden=true;
  // buffs
  const bf=P.buffs.map(b=>b.n+' '+fmtT(b.t)).join(' · ')+(P.pkT>0?(P.buffs.length?' · ':'')+'Nom rouge '+fmtT(P.pkT):'');setTxt('buffs',bf);
  // cible
  const t=P.target,tg=$('#tgt');if(t&&!t.dead){tg.hidden=false;const lv=t.lvl||t.lv,lc=lvlColor(lv,P.lvl);setTxt('tgn',(t.kind==='m'?t.name:t.n)+' · niv. '+lv);$('#tgn').style.color=t.kind==='b'?(t.pk?'#ff4a4a':FACTIONS[t.fac].c):(t.elite?'#ffd36a':lc.c);
    setTxt('tgi',t.kind==='m'?(t.t.agr?'Agressif':'Passif')+' · '+lc.n:(t.pk?'Nom rouge':FACTIONS[t.fac].n)+(t.guild?' · «'+t.guild+'»':''));setW($('#tgb i'),t.hp/t.maxhp);}else tg.hidden=true;
  // guerre
  const w=$('#war');if(WAR.st==='active'){w.hidden=false;setTxt('wart','Guerre de la Frontière · '+fmtT(WAR.t));setTxt('wars','Solarix '+Math.round(WAR.sc.solarix)+' · '+Math.round(WAR.sc.umbra)+' Umbra');$('#warJoin').hidden=curId()==='c_front';}
  else if(WAR.t<=30){w.hidden=false;setTxt('wart','Guerre dans '+fmtT(WAR.t));setTxt('wars','Fort de la Frontière');$('#warJoin').hidden=true;}else w.hidden=true;
  mmT-=1/60;if(mmT<=0){mmT=.2;drawMinimap();}}

/* ---------- entrées ---------- */
const keys=new Set();let joy=null;const joyV={x:0,y:0};
addEventListener('keydown',e=>{const k=e.key.toLowerCase();if(document.activeElement&&['INPUT','SELECT'].includes(document.activeElement.tagName))return;
  if(!$('#modal').hidden){if(k==='escape'||(k==='i'&&panelKind==='sac'))closePanel();return;}
  if(state!=='play')return;keys.add(k);
  const map={' ':()=>attackBtn(),'1':()=>useSkill(P.bar[0]),'&':()=>useSkill(P.bar[0]),'2':()=>useSkill(P.bar[1]),'é':()=>useSkill(P.bar[1]),'3':()=>useSkill(P.bar[2]),'"':()=>useSkill(P.bar[2]),'4':()=>useSkill(P.bar[3]),"'":()=>useSkill(P.bar[3]),'5':()=>useSkill(P.bar[4]),'(':()=>useSkill(P.bar[4]),'6':()=>useSkill(P.bar[5]),'-':()=>useSkill(P.bar[5]),k:()=>openPanel('sorts'),j:()=>openPanel('questlog'),r:()=>usePot('pv'),t:()=>usePot('pm'),e:actionBtn,f:actionBtn,i:()=>openPanel('sac'),c:()=>openPanel('perso'),g:()=>openPanel('guilde'),m:()=>openPanel('carte'),escape:()=>{P.target=null;}};
  if(map[k]){map[k]();e.preventDefault();}});
addEventListener('keyup',e=>keys.delete(e.key.toLowerCase()));addEventListener('blur',()=>keys.clear());
const ptrs=new Map();
function joyCenter(){const b=$('#joyBase').getBoundingClientRect();return{x:b.left+b.width/2,y:b.top+b.height/2};}
cv.addEventListener('pointerdown',e=>{if(state!=='play'||paused)return;e.preventDefault();const p={sx:e.clientX,sy:e.clientY,moved:false};ptrs.set(e.pointerId,p);
  if(!joy){if(SET.joy==='fixe'){const c=joyCenter();if(Math.hypot(e.clientX-c.x,e.clientY-c.y)<90){joy={id:e.pointerId,ox:c.x,oy:c.y,fixed:true};p.moved=true;moveJoy(e.clientX,e.clientY);}}
    else if(e.clientX<innerWidth*.5){joy={id:e.pointerId,ox:e.clientX,oy:e.clientY};const j=$('#joy');j.style.left=e.clientX+'px';j.style.top=e.clientY+'px';j.firstElementChild.style.transform='';j.hidden=false;}}
  try{cv.setPointerCapture(e.pointerId);}catch(_){}});
function moveJoy(x,y){let dx=x-joy.ox,dy=y-joy.oy;const l=Math.hypot(dx,dy),mx=46;if(l>mx){dx*=mx/l;dy*=mx/l;}(joy.fixed?$('#joyBase'):$('#joy')).firstElementChild.style.transform=`translate(${dx}px,${dy}px)`;joyV.x=dx/mx;joyV.y=dy/mx;if(Math.hypot(joyV.x,joyV.y)<.15)joyV.x=joyV.y=0;}
cv.addEventListener('pointermove',e=>{const p=ptrs.get(e.pointerId);if(!p)return;if(Math.hypot(e.clientX-p.sx,e.clientY-p.sy)>10)p.moved=true;if(joy&&joy.id===e.pointerId&&p.moved)moveJoy(e.clientX,e.clientY);});
function endPtr(e){const p=ptrs.get(e.pointerId);if(!p)return;ptrs.delete(e.pointerId);if(joy&&joy.id===e.pointerId){if(joy.fixed)$('#joyBase').firstElementChild.style.transform='';joy=null;joyV.x=joyV.y=0;$('#joy').hidden=true;}if(!p.moved&&e.type==='pointerup')tap(e.clientX,e.clientY);}
cv.addEventListener('pointerup',endPtr);cv.addEventListener('pointercancel',endPtr);
function tap(sx,sy){if(state!=='play'||paused)return;const wx=camX+sx*dpr/Z,wy=camY+sy*dpr/Z;
  let best=null,bd=22;for(const m of mons){if(m.dead)continue;const d=Math.hypot(m.x-wx,(m.y-m.hh)-wy)-m.hr+10;if(d<bd){bd=d;best=m;}}
  for(const b of bots){if(b.dead||b.map!==curId()||!canTarget(b))continue;const d=Math.hypot(b.x-wx,b.y-12-wy);if(d<bd){bd=d;best=b;}}
  if(best){if(best.kind==='b'&&best.fac===P.fac&&!best.pk&&P.pkT<=0&&!P.pkMode){toast('Active le mode PK pour attaquer un allié');return;}if(best===P.target){attackBtn();return;}P.target=best;P.chase=false;P.atkOn=false;P.moveTo=null;P.harv=null;addFx({k:'ring',x:best.x,y:best.y-4,r0:18,r1:8,life:.35,col:'#ffd36a'});return;}
  for(const b of bags)if((b.owner==='p'||b.owner==='free')&&Math.hypot(b.x-wx,b.y-4-wy)<14){P.moveTo={x:b.x,y:b.y+2};P.goTo={k:'act'};P.chase=false;return;}
  for(const n of M.npcs)if(Math.hypot(n.x-wx,n.y-12-wy)<18){P.moveTo={x:n.x,y:n.y+14};P.goTo={k:'npc'};P.chase=false;return;}
  for(const n of M.nodes)if(n.alive&&Math.hypot(n.x-wx,n.y-8-wy)<16){P.moveTo={x:n.fx||n.x,y:(n.fy||n.y)+(n.fx?0:12)};P.goTo={k:'node',o:n};P.chase=false;return;}
  for(const p of M.portals)if(Math.hypot(p.x-wx,p.y-20-wy)<24){P.moveTo={x:p.x,y:p.y+8};P.goTo={k:'act'};return;}
  P.moveTo={x:wx,y:wy};P.chase=false;P.goTo=null;addFx({k:'ring',x:wx,y:wy,r0:6,r1:2,life:.3,col:'#f1e9d6'});}
function bindBtn(id,fn){const b=$(id);b.addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();fn();});b.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();fn();}});}
bindBtn('#bAtk',attackBtn);for(let i=0;i<6;i++)bindBtn('#bS'+i,()=>useSkill(P.bar[i]));bindBtn('#bPV',()=>usePot('pv'));bindBtn('#bPM',()=>usePot('pm'));bindBtn('#bAct',actionBtn);
for(const [id,k] of [['#bPerso','perso'],['#bSac','sac'],['#bMenu','menu']])$(id).addEventListener('click',()=>{if(state==='play')openPanel(k);});
$('#bPK').addEventListener('click',()=>{P.pkMode=!P.pkMode;$('#bPK').classList.toggle('on',P.pkMode);toast(P.pkMode?'Mode PK activé':'Mode PK désactivé',P.pkMode?'Tu peux attaquer les joueurs de ta faction. Tuer un allié rend ton nom rouge.':'');});
$('#warJoin').addEventListener('click',joinWar);
function applySettings(){$('#joyBase').hidden=SET.joy!=='fixe'||state!=='play';$('#pad').classList.toggle('big',SET.btn==='grand');}

/* ---------- panneaux ---------- */
function openPanel(kind,data){panelKind=kind;panelMsg='';panelData=data||null;panelTab=null;paused=true;P&&(P.moveTo=null);keys.clear();joyV.x=joyV.y=0;joy=null;$('#joy').hidden=true;$('#modal').hidden=false;renderPanel();$('#panel').scrollTop=0;}
function closePanel(force){if(!force&&(panelKind==='death'||panelKind==='tomb'))return;$('#modal').hidden=true;paused=false;panelKind=null;save();renderTrack();}
const CLOSE='<button class="btn close" data-a="close" type="button" aria-label="Fermer"><b>✕</b></button>';
const itemLine=it=>`<b style="color:${RARC[it.rar]}">${esc(itemName(it))}</b><small>${RAR[it.rar]} · ${SLOT_N[it.type]}${it.cls?' · '+CLASSES[it.cls].nom:''} · niv. ${TIER_REQ[it.tier]} · ${statTxt(it)}${it.dur<100?' · durabilité '+it.dur+' %':''}${it.by?' · fabriqué par '+esc(it.by):''}</small>`;
const row=(inner,btns)=>`<div class="row"><div class="nm">${inner}</div>${btns||''}</div>`;
const B=(a,txt,extra,cls)=>`<button class="btn ${cls||''}" data-a="${a}" ${extra||''} type="button">${txt}</button>`;
const tabs=(list,cur)=>`<div class="tabs">${list.map(([k,n])=>`<button class="tab ${k===cur?'on':''}" data-a="tab" data-v="${k}" type="button">${n}</button>`).join('')}</div>`;
const bar=(k,col)=>`<div class="pbar"><i style="width:${clamp(k,0,1)*100}%;background:${col}"></i></div>`;
function renderPanel(){const el=$('#panel'),k=panelKind,s=stats(),c=CLASSES[P.cls];let h='';const fac=FACTIONS[P.fac];
  const msg=()=>`<p class="msg">${panelMsg}</p>`;
  if(k==='menu'){h+=CLOSE+'<h2>Menu</h2><p class="sub">'+esc(P.name)+' · niveau '+P.lvl+' · '+fac.n+'</p><div class="mgrid">'+[['perso','Personnage','Caractéristiques, équipement, compétences'+(P.pts?' · '+P.pts+' points':'')],['sac','Sac','Objets, consommables, ressources'],['metiers','Métiers','Récolte et artisanat'],['groupe','Groupe',party?party.members.length+1+' joueurs':'Inviter des joueurs'],['guilde','Guilde',P.guild?'«'+P.guild.name+'»':'Aucune guilde'],['pet','Familier',P.pet?PETS[P.pet].n:'Aucun'],['sorts','Sorts','Grimoires appris : '+(P.skr||[]).filter(x=>x>0).length+'/6'],['questlog','Journal',Object.keys(P.qs.act).length+' quêtes · chroniques'],['carte','Carte du monde','Zones et boss de monde'],['options','Options','Joystick, affichage, personnage']].map(([v,n,d])=>`<button class="btn" data-a="goto" data-v="${v}" type="button">${n}<small>${esc(d)}</small></button>`).join('')+'</div>';}
  else if(k==='perso'){panelTab=panelTab||'stats';
    h+=CLOSE+`<h2>${esc(P.name)}${P.hc?' <span class="hc">HARDCORE</span>':''}</h2><p class="sub">${c.nom} · ${c.role} · niveau ${P.lvl} · <span style="color:${fac.c}">${fac.n}</span>${P.guild?' · «'+esc(P.guild.name)+'»':''}</p>`;
    h+=tabs([['stats','Caractéristiques'],['equip','Équipement'],['skills','Compétences']],panelTab);
    if(panelTab==='stats'){h+=`<h3>POINTS À RÉPARTIR : ${P.pts}</h3>`;
      for(const st of STATS5){const v=s.a[st];h+=row(`<b>${STATN[st]} <span class="num">${v}</span>${st===c.prio[0]?' <em class="tag">prioritaire</em>':st===c.prio[1]?' <em class="tag">secondaire</em>':''}</b><small>${STATD[st]}</small>`,B('alloc','+1',`data-v="${st}" data-n="1" ${P.pts<1?'disabled':''}`)+B('alloc','+5',`data-v="${st}" data-n="5" ${P.pts<1?'disabled':''}`));}
      h+=`<h3>VALEURS</h3><div class="stats"><div>PV<b>${Math.ceil(P.hp)} / ${s.maxhp}</b></div><div>PM<b>${Math.floor(P.mp)} / ${s.maxmp}</b></div><div>Mêlée (FOR)<b>${Math.round(s.melee)}</b></div><div>Distance (DEX)<b>${Math.round(s.ranged)}</b></div><div>Magie (INT)<b>${Math.round(s.matk)}</b></div><div>Défense<b>${s.def}</b></div><div>Précision<b>${s.hit.toFixed(1)} %</b></div><div>Critique<b>${s.crit.toFixed(1)} %</b></div><div>Esquive<b>${s.dodge.toFixed(1)} %</b></div><div>Vitesse d'attaque<b>${Math.round((1/s.aspd)*100)} %</b></div><div>Burst de zone<b>${Math.round(s.aoe*100)} %</b></div><div>Durée des contrôles<b>${Math.round(s.ctl*100)} %</b></div><div>Soins et buffs<b>${Math.round(s.heal*100)} %</b></div><div>Poids<b>${invWeight()} / ${s.pods} kg</b></div><div>Expérience<b>${P.xp} / ${xpNeed(P.lvl)}</b></div><div>Bonus d'XP<b>+${Math.round((xpMult()-1)*100)} %</b></div><div>Honneur<b>${P.honor} · ${honorRank(P.honor)}</b></div><div>Joueurs vaincus<b>${P.pvpk}</b></div></div>`;
      if(P.hc)h+=`<p class="sub" style="margin-top:10px">Personnage hardcore : ${PTS_LVL.hc} points par niveau au lieu de ${PTS_LVL.normal}, mais la mort est définitive.</p>`;}
    else if(panelTab==='equip'){for(const sl of SLOTS){const it=P.eq[sl];h+=it?row(itemLine(it),B('uneq','Retirer',`data-v="${sl}"`)):row(`<b class="empty">${SLOT_N[sl]} : vide</b>`);}}
    else{h+='<p class="sub">Le sort de niveau 1 est inné ; les autres s’apprennent avec des grimoires.</p>'+B('goto','Ouvrir la fenêtre des sorts','data-v="sorts"','go');}
  }
  else if(k==='sac'){panelTab=panelTab||'eq';h+=CLOSE+'<h2>Sac</h2>'+bagPanelHead(s);
    h+=tabs([['eq','Équipement'],['cons','Consommables'],['res','Ressources']],panelTab);
    if(panelTab==='eq'){if(!P.inv.length)h+='<p class="sub">Aucun objet. Les monstres lâchent des sacs colorés selon la rareté.</p>';P.inv.forEach(it=>{const why=canEquip(it);h+=row(itemLine(it),(why?`<span class="why">${esc(why)}</span>`:B('equip','Équiper',`data-id="${it.id}"`))+B('drop','Jeter',`data-id="${it.id}"`,'red'));});}
    else if(panelTab==='cons'){const ks=Object.keys(P.cons).filter(x=>P.cons[x]>0);if(!ks.length)h+='<p class="sub">Aucun consommable.</p>';for(const x of ks)h+=row(`<b>${esc(CONS[x].n)} <span class="num">× ${P.cons[x]}</span></b><small>${esc(CONS[x].d)} · ${isVirtual(x)?'hors inventaire':consSlots(x,P.cons[x])+' case'+(consSlots(x,P.cons[x])>1?'s':'')}</small>`,(x.startsWith('ench')?'':B('use','Utiliser',`data-v="${x}"`))+(isVirtual(x)?'':B('dropc','Jeter',`data-v="${x}" data-k="cons"`,'red')));}
    else{const ks=Object.keys(P.res).filter(x=>P.res[x]>0);if(!ks.length)h+='<p class="sub">Aucune ressource. Récolte les nœuds qui scintillent.</p>';for(const x of ks)h+=row(`<b>${esc(RES[x].n)} <span class="num">× ${P.res[x]}</span></b><small>${Math.ceil(P.res[x]/STACK_RES)} case${P.res[x]>STACK_RES?'s':''} · piles de 50</small>`,B('dropc','Jeter 50',`data-v="${x}" data-k="res"`,'red'));}}
  else if(k==='metiers'){h+=CLOSE+'<h2>Métiers</h2><p class="sub">Comme dans Dofus : chaque métier monte séparément. Récolte sur le terrain, fabrique à l’atelier de ta capitale.</p>';
    for(const [pk,pd] of Object.entries(PROFS)){const p=P.prof[pk],res=pd.k==='r'?Object.entries(RES).filter(([,r])=>r.prof===pk).map(([,r])=>r.n+' (niv. '+r.lvl+')').join(', '):pd.d;h+=row(`<b>${pd.n} <span class="num">niv. ${p.l}</span></b>${bar(p.l>=PROF_MAX?1:p.xp/profNeed(p.l),'#9be36a')}<small>${esc(res)}</small>`);}}
  else if(k==='groupe'){h+=CLOSE+'<h2>Groupe</h2><p class="sub">Jusqu’à 4 joueurs de ta faction. L’XP est partagée entre les membres proches, avec un bonus de 15 % par membre.</p>';
    if(party){h+='<h3>MEMBRES</h3>'+row(`<b>${esc(P.name)} <em class="tag">chef</em></b><small>${c.nom} · niv. ${P.lvl}</small>`);
      for(const b of party.members)h+=row(`<b>${esc(b.n)}</b>${bar(b.hp/b.maxhp,'#5ad06a')}<small>${CLASSES[b.cls].nom} · niv. ${b.lvl}${b.dead?' · à terre':''}</small>`,B('pkick','Exclure',`data-v="${esc(b.n)}"`));
      h+='<h3>RÉPARTITION DU BUTIN</h3><div class="seg">'+[['chef','Au chef'],['random','Aléatoire'],['free','Celui qui ramasse']].map(([v,n])=>`<button class="tab ${party.loot===v?'on':''}" data-a="ploot" data-v="${v}" type="button">${n}</button>`).join('')+'</div>';
      h+=`<p class="sub">${{chef:'Tout le butin revient au chef du groupe.',random:'Chaque objet est tiré au sort entre les membres proches.',free:'Le premier qui ramasse le sac garde son contenu.'}[party.loot]}</p><p>${B('pleave','Quitter le groupe','','red')}</p>`;}
    const cand=bots.filter(b=>!b.dead&&b.map===curId()&&b.fac===P.fac&&!b.party&&!b.pk).slice(0,8);
    h+='<h3>JOUEURS À PROXIMITÉ</h3>'+(cand.length?cand.map(b=>row(`<b>${esc(b.n)}</b><small>${CLASSES[b.cls].nom} · niv. ${b.lvl}${b.guild?' · «'+esc(b.guild)+'»':''}</small>`,B('pinv','Inviter',`data-v="${esc(b.n)}" ${party&&party.members.length>=3?'disabled':''}`))).join(''):'<p class="sub">Aucun autre joueur connecté pour le moment. Les groupes s’ouvriront avec le serveur multijoueur.</p>')+msg();}
  else if(k==='guilde'||k==='guild'){h+=CLOSE+(k==='guild'?`<h2>${esc(npcName('guild'))}</h2>`:'<h2>Guilde</h2>');
    if(!P.guild){h+='<p class="sub">Tu n’as pas de guilde. Les guildes donnent des bonus d’XP et de statistiques, des missions, et se disputent les boss de monde.</p>';
      if(k==='guild'){h+=`<h3>FONDER UNE GUILDE · 300 OR · NIVEAU 5</h3><div class="row"><input id="gname" maxlength="20" placeholder="Nom de la guilde" autocomplete="off">${B('gcreate','Fonder','','go')}</div>`;
        for(const g of GUILDS[P.fac]){const n=bots.filter(b=>b.guild===g.n).length+ri(0,0);h+=row(`<b>${esc(g.n)}</b><small>Niveau ${g.lvl} · ${n+8} membres</small>`,B('gjoin','Postuler',`data-v="${esc(g.n)}"`));}}
      else h+='<p class="sub">Va voir l’intendant des guildes dans ta capitale pour en fonder ou en rejoindre une.</p>';}
    else{const g=P.guild,gb=guildBonus();h+=`<p class="sub">«${esc(g.name)}» · niveau ${g.lvl} · ${g.members.length} membres · ton rang : ${g.role}</p>${bar(g.lvl>=10?1:g.xp/guildNeed(g.lvl),'#9be36a')}`;
      h+=`<h3>BONUS</h3><div class="stats"><div>XP<b>+${Math.round(gb.xp*100)} %</b></div><div>PV<b>+${Math.round(gb.hp*100)} %</b></div><div>Attaque<b>+${Math.round(gb.atk*100)} %</b></div><div>Défense<b>+${Math.round(gb.def*100)} %</b></div></div>`;
      h+=`<h3>MISSION DE GUILDE</h3>`+row(`<b>Abattre ${g.mission.n} monstres</b>${bar(g.mission.prog/g.mission.n,'#f2c14e')}<small>${g.mission.prog} / ${g.mission.n} · récompense : ${100*g.lvl} or et XP de guilde</small>`,B('gclaim','Valider',g.mission.prog<g.mission.n?'disabled':'','go'));
      h+='<h3>MEMBRES</h3>'+g.members.slice(0,14).map(m=>row(`<b>${esc(m.n)} <em class="tag">${m.role}</em></b><small>${CLASSES[m.cls]?CLASSES[m.cls].nom:''} · niv. ${m.lvl}</small>`,P.guild.role==='Chef'&&m.n!==P.name&&m.role==='Membre'?B('gpromo','Officier',`data-v="${esc(m.n)}"`):'')).join('');
      if(['Chef','Officier'].includes(g.role)){const cand=bots.filter(b=>b.fac===P.fac&&!b.guild).slice(0,5);h+='<h3>RECRUTER</h3>'+(cand.length?cand.map(b=>row(`<b>${esc(b.n)}</b><small>${CLASSES[b.cls].nom} · niv. ${b.lvl}</small>`,B('ginv','Inviter',`data-v="${esc(b.n)}"`))).join(''):'<p class="sub">Aucun joueur sans guilde en ligne.</p>');}
      h+=`<p>${B('gleave','Quitter la guilde','','red')}</p>`;}h+=msg();}
  else if(k==='pet'){h+=CLOSE+'<h2>Familier</h2>';if(!P.pet)h+=`<p class="sub">Tu n’as pas de familier. ${fac.capN} : la marchande en vend pour ${PETS.chaton.price} or. Il te suit et ramasse le butin à ta place.</p>`;
    else{const F=P.petF;h+=`<p class="sub">${PETS[P.pet].n} ramasse automatiquement ce que tu choisis, dans un rayon proche.</p><h3>CE QU'IL RAMASSE</h3>`;
      for(const [key,n] of [['gold','Or'],['eq','Équipement'],['cons','Potions, parchemins, livres'],['res','Ressources']])h+=row(`<b>${n}</b>`,`<button class="tog ${F[key]?'on':''}" data-a="petf" data-v="${key}" type="button">${F[key]?'Oui':'Non'}</button>`);
      h+='<h3>RARETÉ MINIMALE DE L\'ÉQUIPEMENT</h3><div class="seg">'+RAR.slice(0,4).map((r,i)=>`<button class="tab ${F.min===i?'on':''}" data-a="petmin" data-v="${i}" type="button" style="color:${RARC[i]}">${r}</button>`).join('')+'</div>';}}
  else if(k==='npc'){const n=panelData,qid=n.qid,greet=n.role==='quest'?PROLOGUE[P.fac==='solarix'?3:4]:(CAMPS[M.id]?CAMPS[M.id].g:'');
    h+=CLOSE+`<h2>${esc(n.n)}</h2><p class="sub">&lt;${esc(n.r)}&gt; · « ${esc(greet)} »</p>`;
    const ti=qTurnIns(qid),av=qAvail(qid),ip=qInProg(qid),nx=qLockedNext(qid);
    if(ti.length)h+='<h3>À RENDRE</h3>'+ti.map(id=>row(`<b class="gold">${esc(tok(qDef(id).t))}</b><small>Objectifs remplis</small>`,B('qview','Rendre',`data-v="${id}"`,'go'))).join('');
    if(av.length)h+='<h3>DISPONIBLES</h3>'+av.map(q=>row(`<b>${q.chain==='main'?'<em class="tag">campagne</em> ':''}${esc(tok(q.t))}</b><small>Niveau ${q.lvl}${q.rep?' · répétable':''}</small>`,B('qview','Voir',`data-v="${q.id}"`))).join('');
    if(ip.length)h+='<h3>EN COURS</h3>'+ip.map(id=>{const q=qDef(id);return row(`<b>${esc(tok(q.t))}</b><small>${q.obj.map((o,j)=>{const t=objText(q,j,P.qs.act[id]);return esc(t.t)+' '+t.pr+'/'+t.n;}).join(' · ')}</small>`,B('qview','Détails',`data-v="${id}"`));}).join('');
    if(nx)h+=row(`<b class="dimb">${esc(tok(nx.t))}</b><small>Prochain chapitre de la campagne au niveau ${nx.lvl}</small>`);
    if(!ti.length&&!av.length&&!ip.length&&!nx)h+='<p class="sub">Rien de nouveau pour le moment.</p>';
    if(n.role==='camp')h+='<h3>RAVITAILLEMENT</h3>'+row('<b>5 potions de vie</b><small>75 or</small>',B('npcshop','Acheter','data-v="pv" '+(P.gold<75?'disabled':''),'go'))+row('<b>5 potions de mana</b><small>75 or</small>',B('npcshop','Acheter','data-v="pm" '+(P.gold<75?'disabled':''),'go'));
    h+=msg();}
  else if(k==='qdetail'){const id=panelData.id,q=qDef(id),st=P.qs.act[id],n=panelData.n;if(!q){h+=CLOSE+'<p class="sub">Quête introuvable.</p>';}else{
    const ci=q.chain==='main'?MAIN.findIndex(x=>x.id===id)+1:0;
    h+=CLOSE+`<h2>${esc(tok(q.t))}</h2><p class="sub">${ci?'Campagne · chapitre '+ci+' / '+MAIN.length:q.chain==='bounty'?'Contrat de prime':'Quête de '+esc(qGiverName(q.giver))} · niveau ${q.lvl||1}</p><div class="qbox">${esc(tok(q.d))}</div>`;
    h+='<h3>OBJECTIFS</h3>'+q.obj.map((o,j)=>{const t=objText(q,j,st);return row(`<b class="${st&&t.done?'have':''}">${st&&t.done?'✓ ':''}${esc(t.t)}</b><small>${st?t.pr:0} / ${t.n}</small>`);}).join('');
    h+=`<h3>RÉCOMPENSES</h3><p class="sub">${esc(rewardText(q.rew||{}))}</p>`;
    const here=n&&(n.qid===(q.end||q.giver));
    h+='<p class="go-row">';if(st&&qComplete(id)&&here)h+=B('qturn','Rendre la quête',`data-v="${id}"`,'go');else if(!st&&n&&n.qid===q.giver)h+=B('qaccept','Accepter',`data-v="${id}"`,'go');
    if(st)h+=B('qabandon','Abandonner',`data-v="${id}"`,'red');if(n)h+=B('qback','Retour');h+='</p>';if(st&&qComplete(id)&&!here)h+=`<p class="sub">À rendre à ${esc(qGiverName(q.end||q.giver))}, ${esc(qGiverPlace(q.end||q.giver))}.</p>`;}h+=msg();}
  else if(k==='questlog'){panelTab=panelTab||'act';h+=CLOSE+'<h2>Journal</h2>'+tabs([['act','Quêtes ('+Object.keys(P.qs.act).length+')'],['main','Campagne'],['codex','Chroniques']],panelTab);
    if(panelTab==='act'){const ids=Object.keys(P.qs.act);if(!ids.length)h+='<p class="sub">Aucune quête en cours. Les « ! » au-dessus des personnages signalent des quêtes disponibles.</p>';
      for(const id of ids){const q=qDef(id),st=P.qs.act[id];if(!q)continue;h+=row(`<b class="${qComplete(id)?'have':''}">${q.chain==='main'?'<em class="tag">campagne</em> ':''}${esc(tok(q.t))}</b><small>${q.obj.map((o,j)=>{const t=objText(q,j,st);return(t.done?'✓ ':'')+esc(t.t)+' '+t.pr+'/'+t.n;}).join(' · ')}<br>${qComplete(id)?'À rendre à ':'Donnée par '}${esc(qGiverName(q.end||q.giver))} · ${esc(qGiverPlace(q.end||q.giver))}</small>`,B('qview','Détails',`data-v="${id}"`));}}
    else if(panelTab==='main'){h+='<p class="sub">La guerre pour les éclats du Prisme, du niveau 1 au niveau 50.</p>';MAIN.forEach((q,i)=>{const d=qdone(q.id),a=!!P.qs.act[q.id];h+=row(`<b class="${d?'have':a?'gold':'dimb'}">${d?'✓':a?'▶':'·'} ${i+1}. ${esc(tok(q.t))}</b><small>Niveau ${q.lvl} · ${esc(qGiverName(q.giver))}, ${esc(qGiverPlace(q.giver))}${q.rew.book!=null?' · grimoire':''}</small>`);});}
    else{const E=codexEntries();h+=`<p class="sub">${E.length} / ${codexTotal()} chroniques découvertes. Explore les zones, lis les stèles et avance dans la campagne.</p><h3>PROLOGUE</h3><div class="qbox">${PROLOGUE.map(esc).join('<br><br>')}</div>`;
      for(const cat of ['Lieux','Stèles','Campagne']){const es=E.filter(e=>e.cat===cat);if(es.length)h+=`<h3>${cat.toUpperCase()}</h3>`+es.map(e=>row(`<b>${esc(e.t)}</b><small style="font-family:var(--display);font-size:12px">${esc(e.x)}</small>`)).join('');}}}
  else if(k==='sorts'){if(!/^\d$/.test(String(panelTab))||!c.sk[+panelTab])panelTab='0';const i=+panelTab,sk=c.sk[i],rk=skRank(i),bk='livre_'+P.cls+'_'+i,have=P.cons[bk]||0;
    h+=CLOSE+`<h2>Sorts · ${c.nom}</h2><p class="sub">Le sort de niveau 1 est inné. Tous les autres s’apprennent en lisant leur grimoire, puis montent jusqu’au rang 3 avec d’autres exemplaires.</p><div class="sgrid">`;
    c.sk.forEach((x,j)=>{const r=skRank(j),own=P.cons['livre_'+P.cls+'_'+j]>0,on=P.bar.indexOf(j);h+=`<button class="spc ${j===i?'on':''} ${r?'':'locked'}" data-a="spsel" data-v="${j}" type="button"><b>${esc(x.s)}</b><small>niv. ${x.lv} · ${r?'●'.repeat(r)+'○'.repeat(3-r):own?'Grimoire en main':'Grimoire requis'}${on>=0?' · case '+(on+1):''}</small>${own&&r<3?'<i class="up"></i>':''}</button>`;});
    h+='</div>';
    const mk=MARKET.filter(l=>l.cons===bk).length,R3=a=>Array.isArray(a)?a.join(' / '):a;
    h+=`<div class="qbox"><b class="gold">${esc(sk.n)}</b> · niv. ${sk.lv} · ${rk?'rang '+rk+'/3':'verrouillé'}${P.lvl<sk.lv?' · utilisable au niveau '+sk.lv:''}<br>${esc(skillDesc(sk,Math.max(1,rk)))}<br><span class="dim">PM ${R3(sk.mp)} · recharge ${R3(sk.cd)} s (rangs 1 / 2 / 3)</span><br><span class="dim">${i===0?'Sort inné, connu dès la création.':(rk?'Rang suivant : ':'')+'Grimoire : '+esc(sk.n)+' · Obtention : '+esc(c.src[i])+(mk?' · '+mk+' offre(s) à l’hôtel des ventes':'')}</span></div>`;
    if(have&&rk<3)h+=`<p>${B('learn',rk?'Lire le grimoire : rang '+(rk+1):'Apprendre '+esc(sk.n),`data-v="${bk}"`,'go')} <span class="why">${have} en main</span></p>`;
    if(rk){h+='<h3>PLACER DANS LA BARRE</h3><div class="barset">'+[0,1,2,3,4,5].map(j=>{const x=c.sk[P.bar[j]];return B('bar',`${j+1}<small>${x?esc(x.s):'vide'}</small>`,`data-v="${j}" data-s="${i}"`,P.bar[j]===i?'go':'');}).join('')+'</div>';}
    h+=msg();}
  else if(k==='primes'){if(!(P.qs.board&&P.qs.board.length)||P.qs.bT<=0)genBounties();h+=CLOSE+`<h2>Tableau des primes</h2><p class="sub">Contrats du conseil de ${fac.capN}, renouvelés toutes les 10 minutes. Trois contrats en même temps au maximum.</p>`;
    const mine=(P.qs.bdefs||[]).filter(b=>P.qs.act[b.id]);if(mine.length)h+='<h3>MES CONTRATS</h3>'+mine.map(b=>row(`<b>${esc(b.t)}</b><small>${objText(b,0,P.qs.act[b.id]).pr} / ${b.obj[0].n} · ${esc(rewardText(b.rew))}</small>`,qComplete(b.id)?B('qturnb','Toucher la prime',`data-v="${b.id}"`,'go'):'')).join('');
    h+='<h3>CONTRATS AFFICHÉS · NOUVEAUX DANS '+fmtT(P.qs.bT)+'</h3>'+(P.qs.board.length?P.qs.board.map(b=>row(`<b>${esc(b.t)}</b><small>${esc(b.d)}<br>${esc(rewardText(b.rew))}</small>`,B('bounty','Signer',`data-v="${b.id}"`,'go'))).join(''):'<p class="sub">Tous les contrats ont été pris.</p>')+msg();}
  else if(k==='lore'){const d=panelData;h+=CLOSE+`<h2>${esc(d.t)}</h2><div class="qbox" style="font-size:15px">${esc(d.x)}</div><p class="sub" style="margin-top:10px">${d.first?'Ajouté aux Chroniques. Tu gagnes de l’expérience.':'Déjà dans tes Chroniques.'}</p>`;}
  else if(k==='carte'){h+=CLOSE+'<h2>Carte du monde</h2><p class="sub">Les cartes se relient par leurs bords, comme dans TWOM. Niveaux 1 à 20 : territoires de faction. Niveaux 21 à 50 : zones contestées.</p><div class="wmap">';
    for(const [id,[x,y]] of Object.entries(WORLD_LAYOUT)){const d=MAPS[id],here=(dgRun?dgRun.ret.map:P.map)===id,col=d.side?FACTIONS[d.side].c:'#ff8a6a',locked=d.side&&d.side!==P.fac;
      h+=`<div class="wm ${here?'here':''} ${locked?'locked':''}" style="grid-column:${x+1};grid-row:${y+1};border-color:${col}"><b>${esc(d.n)}</b><small>${d.kind==='city'?'Capitale':'Niv. '+d.lv[0]+'–'+d.lv[1]}${d.pvp?' · PvP':''}${d.dungeon?' · donjon':''}${d.wb?' · boss de monde':''}</small></div>`;}
    h+='</div><p class="sub">Boss de monde : '+Object.entries(WB).map(([k2,w])=>MT[k2].n+(w.alive?' (en vie)':' dans '+fmtT(w.t))).join(' · ')+'</p>';}
  else if(k==='options'){h+=CLOSE+'<h2>Options</h2><h3>JOYSTICK</h3><div class="seg">'+[['flottant','Flottant'],['fixe','Fixe']].map(([v,n])=>`<button class="tab ${SET.joy===v?'on':''}" data-a="set" data-k="joy" data-v="${v}" type="button">${n}</button>`).join('')+'</div><p class="sub">Fixe : le joystick reste toujours en bas à gauche. Flottant : il apparaît là où tu poses le pouce.</p>';
    h+='<h3>TAILLE DES BOUTONS</h3><div class="seg">'+[['normal','Normale'],['grand','Grande']].map(([v,n])=>`<button class="tab ${SET.btn===v?'on':''}" data-a="set" data-k="btn" data-v="${v}" type="button">${n}</button>`).join('')+'</div><h3>AFFICHAGE</h3>';
    for(const [key,n] of [['names','Noms au-dessus des personnages'],['daynight','Cycle jour et nuit'],['parts','Particules'],['dmg','Nombres de dégâts']])h+=row(`<b>${n}</b>`,`<button class="tog ${SET[key]?'on':''}" data-a="setb" data-k="${key}" type="button">${SET[key]?'Oui':'Non'}</button>`);
    h+=`<h3>PERSONNAGE</h3><p>${B('tochars','Changer de personnage')}</p>`;}
  else if(k==='shop'){h+=CLOSE+`<h2>${esc(npcName('shop'))}, marchande</h2><p class="sub">Or : <b class="gold">${P.gold}</b></p>`+tabs([['buy','Acheter'],['sell','Vendre'],['pets','Familiers']],panelTab=panelTab||'buy');
    if(panelTab==='buy')h+=row(`<b>${BAGS.musette.n}</b><small>Sac de départ : +4 emplacements · 100 or</small>`,B('bagbuy','Acheter',P.gold<100?'disabled':'','go'));
    if(panelTab==='buy')for(const [x,q] of [['pv',1],['pv',10],['pm',1],['pm',10],['retour',1],['ench1',1],['encha1',1],['enclume',1]]){const pr=CONS[x].price*q*(x.startsWith('ench')?2:1);h+=row(`<b>${CONS[x].n}${q>1?' × '+q:''}</b><small>${esc(CONS[x].d)} · ${pr} or</small>`,B('buy','Acheter',`data-v="${x}" data-n="${q}" data-p="${pr}" ${P.gold<pr?'disabled':''}`,'go'));}
    else if(panelTab==='sell'){if(!P.inv.length)h+='<p class="sub">Ton sac est vide.</p>';P.inv.forEach(it=>{h+=row(itemLine(it),B('sell',itemValue(it)+' or',`data-id="${it.id}"`));});}
    else for(const [pk,pd] of Object.entries(PETS))h+=row(`<b>${pd.n}</b><small>Ramasse le butin selon tes filtres · ${pd.price} or</small>`,P.pet===pk?'<span class="why">Actif</span>':B('pet','Adopter',`data-v="${pk}" ${P.gold<pd.price?'disabled':''}`,'go'));
    h+=msg();}
  else if(k==='forge'){h+=ecoForgePanel(fac,msg);}
  else if(k==='trainer'){const cost=resetCost();h+=CLOSE+`<h2>${esc(npcName('trainer'))}</h2><p class="sub">« Je peux effacer tes choix pour que tu répartisses à nouveau tes points. »</p>`+row(`<b>Réinitialiser les caractéristiques</b><small>${cost?cost+' or':'Gratuit jusqu’au niveau 14'} · tous les points te sont rendus</small>`,B('reset','Réinitialiser',P.gold<cost?'disabled':'','go'))+`<p>${B('toperso','Ouvrir mes caractéristiques')}</p>`+(()=>{const sk=c.sk[1],k2='livre_'+P.cls+'_1',pr=180;return '<h3>GRIMOIRE DE LA CITÉ</h3>'+row(`<b>Grimoire : ${esc(sk.n)}</b><small>Sort de niveau ${sk.lv} · ${pr} or · ${skRank(1)?'monte le sort au rang suivant':'premier sort à apprendre'}</small>`,B('tbook','Acheter',`data-v="${k2}" data-p="${pr}" ${P.gold<pr?'disabled':''}`,'go'));})()+msg();}
  else if(k==='hdv'){if(marketT<=0||!MARKET.length)genMarket();panelTab=panelTab||'buy';
    h+=CLOSE+`<h2>Hôtel des ventes de ${fac.capN}</h2><p class="sub">Réservé à ${fac.n} : aucun échange avec l’autre faction. Taxe de 5 % sur les ventes. Or : <b class="gold">${P.gold}</b></p>`+tabs([['buy','Acheter'],['sell','Vendre'],['mine','Mes ventes'+(P.hdv.mail?' ('+P.hdv.mail+' or)':'')]],panelTab);
    if(panelTab==='buy')for(const l of MARKET)h+=row(l.item?itemLine(l.item):`<b>${esc(lotName(l))}</b><small>${esc(l.res?RES[l.res].n:CONS[l.cons].d)}</small>`,`<span class="why">${esc(l.seller)}</span>`+B('hbuy',l.price+' or',`data-v="${l.id}" ${P.gold<l.price?'disabled':''}`,'go'));
    else if(panelTab==='sell'){h+='<p class="sub">Indique ton prix. Plus il est proche du prix du marché, plus vite l’objet part.</p>';
      P.inv.forEach(it=>{const fp=itemValue(it)*3;h+=row(itemLine(it),`<input class="price" id="pr_i${it.id}" inputmode="numeric" value="${fp}">`+B('hsell','Vendre',`data-k="item" data-v="${it.id}"`));});
      for(const [x,q] of Object.entries(P.res))if(q>0){const n=Math.min(q,10);h+=row(`<b>${RES[x].n} × ${n}</b><small>Tu en as ${q}</small>`,`<input class="price" id="pr_r${x}" inputmode="numeric" value="${n*RES_PRICE[RES[x].tier]}">`+B('hsell','Vendre',`data-k="res" data-v="${x}" data-n="${n}"`));}
      for(const [x,q] of Object.entries(P.cons))if(q>0&&x!=='retour'){const n=x.startsWith('livre')||x.startsWith('ench')?1:Math.min(q,5);h+=row(`<b>${CONS[x].n} × ${n}</b><small>Tu en as ${q}</small>`,`<input class="price" id="pr_c${x}" inputmode="numeric" value="${n*CONS[x].price}">`+B('hsell','Vendre',`data-k="cons" data-v="${x}" data-n="${n}"`));}}
    else{h+=row(`<b>Or à récupérer : ${P.hdv.mail}</b><small>Les ventes conclues arrivent ici.</small>`,B('hmail','Récupérer',P.hdv.mail?'':'disabled','go'));if(!P.hdv.list.length)h+='<p class="sub">Aucune annonce en cours.</p>';
      for(const l of P.hdv.list)h+=row(l.item?itemLine(l.item):`<b>${esc(lotName(l))}</b>`,`<span class="why">${l.price} or</span>`+B('hcancel','Retirer',`data-v="${l.id}"`));}h+=msg();}
  else if(k==='war'){h+=CLOSE+`<h2>${esc(npcName('war'))}</h2><p class="sub">Guerre de la Frontière toutes les 8 minutes environ. La faction victorieuse gagne +50 % d’XP pendant 15 minutes. Rang : <b class="gold">${honorRank(P.honor)}</b> · ${P.honor} honneur</p>`;
    h+=`<div class="qbox">${WAR.st==='active'?'Guerre en cours : '+fmtT(WAR.t)+' restantes · Solarix '+Math.round(WAR.sc.solarix)+' · Umbra '+Math.round(WAR.sc.umbra):'Prochaine guerre dans '+fmtT(WAR.t)}</div>`;
    if(WAR.st==='active')h+=`<p>${B('wjoin','Rejoindre la bataille','','go')}</p>`;
    h+='<h3>BOUTIQUE D\'HONNEUR</h3>';for(const [x,q,pr] of [['parch',1,120],['pv',10,50],['ench2',1,300],['encha2',1,300],['ench3',1,1500],['encha3',1,1500]])h+=row(`<b>${CONS[x].n}${q>1?' × '+q:''}</b><small>${esc(CONS[x].d)} · ${pr} honneur</small>`,B('hon','Échanger',`data-v="${x}" data-n="${q}" data-p="${pr}" ${P.honor<pr?'disabled':''}`,'go'));
    h+=row(`<b>Insigne de ${fac.n}</b><small>Anneau épique de ton niveau · 600 honneur</small>`,B('honring','Échanger',P.honor<600?'disabled':'','go'))+msg();}
  else if(k==='craft'){h+=ecoCraftPanel(msg);}
  else if(k==='death'){const d=panelData||{};h+=`<h2>Tu es tombé</h2><p class="sub">Vaincu par ${esc(d.src||'un ennemi')}. Tu perds ${d.lost||0} points d’expérience et 10 % de durabilité sur ton équipement.${d.dropped?' Ton nom rouge t’a fait perdre : '+esc(itemName(d.dropped))+'.':''}</p><p>${B('respawn','Revenir à '+fac.capN,'','go big')}</p>`;}
  else if(k==='tomb'){const d=panelData||{};h+=`<h2>Ci-gît ${esc(d.c?d.c.name:'')}</h2><p class="sub">Personnage hardcore ${CLASSES[d.c.cls].nom.toLowerCase()} de niveau ${d.c.lvl}, tué par ${esc(d.src||'un ennemi')}. La mort est définitive : ce personnage est effacé.</p><p>${B('tochars','Retour aux personnages','','go big')}</p>`;}
  else if(EXTRA_PANELS[k])h+=EXTRA_PANELS[k](s,c,fac,msg);
  el.innerHTML=h;}
function npcName(r){const n=M.npcs.find(x=>x.role===r);return n?n.n:NPC_DEF[P.fac][r][0];}
function skillDesc(sk,rk){rk=rk||1;const v=x=>RV(x,rk),pc=x=>Math.round(v(x)*100)+' %',m=sk.m?' ('+pc(sk.m)+' ATK)':'';return{
  basic:'Attaque de base'+m,charge:'Fonce sur l’ennemi'+m+' et le ralentit de '+pc(sk.slow),stun:'Étourdit la cible '+v(sk.stun)+' s'+m,taunt:'Force les monstres autour à t’attaquer, gêne les joueurs',
  aoe:'Frappe jusqu’à '+sk.max+' cibles autour de toi'+m,rally:'PV max +'+pc(sk.v)+' pour toi et tes alliés pendant '+sk.dur+' s',execute:'Finisseur'+m+' ; dégâts massifs si la cible a moins de '+pc(sk.th)+' de PV',
  sunder:'Réduit la défense de la cible de '+pc(sk.v)+' pendant 6 s'+m,bastion:'Réduit les dégâts subis de '+pc(sk.v)+' pendant '+sk.dur+' s',
  slowshot:'Ralentit la cible de '+pc(sk.slow)+m,tracker:'Portée +'+v(sk.rng)+' et critique +'+v(sk.v)+' % pendant '+sk.dur+' s',trap:'Piège au sol : immobilise le premier ennemi '+v(sk.root)+' s',
  volley:'Salve en cône touchant '+sk.cnt+' cibles'+m,pierce:'Traverse les ennemis, ignore '+pc(sk.ign)+' de la défense'+m,snipe:'Très longue portée'+m+', critique garanti hors combat',
  leap:'Bond en arrière, dissipe les contrôles, esquive +'+v(sk.v)+' %',rain:v(sk.waves)+' vagues de flèches sur une zone'+m,
  heal:'Restaure '+pc(sk.v)+' des PV (scalé SAG), soigne aussi l’allié le plus blessé',root:'Immobilise la cible '+v(sk.root)+' s',shield:'Absorbe '+v(sk.v)+' dégâts (scalé INT/SAG) pendant '+sk.dur+' s',
  curse:'Réduit l’ATK et la MATK de la cible de '+pc(sk.v)+' pendant '+v(sk.dur)+' s',storm:'Magie de zone, jusqu’à '+sk.max+' ennemis'+m,benison:'INT, SAG et régénération de PM +'+pc(sk.v)+' pendant 10 min',
  blink:'Téléportation de '+v(sk.len)+' px dans la direction visée',massheal:'Soigne tous les alliés proches de '+pc(sk.v)+' des PV',apoca:'Cataclysme de zone'+m+', interrompt les ennemis'}[sk.k]||'';}
$('#panel').addEventListener('click',e=>{const b=e.target.closest('[data-a]');if(!b||b.disabled)return;const a=b.dataset.a,v=b.dataset.v,id=+b.dataset.id;panelMsg='';
  const botN=n=>bots.find(x=>x.n===n);
  switch(a){
    case'close':closePanel();return;
    case'tab':panelTab=v;break;
    case'goto':panelKind=v;panelTab=null;break;
    case'alloc':alloc(v,+b.dataset.n);break;
    case'uneq':unequip(v);break;
    case'equip':{const it=P.inv.find(i=>i.id===id);if(it)equip(it);break;}
    case'use':useCons(v);if(!$('#modal').hidden)break;return;
    case'pinv':panelMsg=esc(partyInvite(botN(v)));break;
    case'pkick':partyKick(botN(v));break;
    case'ploot':party.loot=v;chat(null,'Butin du groupe : '+{chef:'au chef',random:'aléatoire',free:'celui qui ramasse'}[v]+'.',null,'party');break;
    case'pleave':partyLeave();break;
    case'gcreate':panelMsg=esc(guildCreate($('#gname').value)||'Guilde fondée !');break;
    case'gjoin':guildJoin(GUILDS[P.fac].find(g=>g.n===v));break;
    case'gleave':guildLeave();break;
    case'gclaim':guildMissionClaim();break;
    case'ginv':panelMsg=esc(guildInvite(botN(v)));break;
    case'gpromo':{const m=P.guild.members.find(x=>x.n===v);if(m)m.role='Officier';break;}
    case'petf':P.petF[v]=!P.petF[v];break;
    case'petmin':P.petF.min=+v;break;
    case'qview':panelData={id:v,n:panelKind==='npc'?panelData:panelData&&panelData.n};panelKind='qdetail';break;
    case'qaccept':{const r=qAccept(v);panelMsg=esc(r||'Quête acceptée.');if(!r&&panelData.n){panelKind='npc';panelData=panelData.n;}break;}
    case'qturn':{qTurnIn(v);if(panelData.n){panelKind='npc';panelData=panelData.n;}break;}
    case'qturnb':qTurnIn(v);break;
    case'qabandon':qAbandon(v);if(panelData&&panelData.n){panelKind='npc';panelData=panelData.n;}else panelKind='questlog';break;
    case'qback':panelKind='npc';panelData=panelData.n;break;
    case'npcshop':if(P.gold>=75){P.gold-=75;P.cons[v]=(P.cons[v]||0)+5;panelMsg='Merci, et bonne chance.';}break;
    case'spsel':panelTab=v;break;
    case'bar':{const j=+v,si=+b.dataset.s,o=P.bar.indexOf(si);if(o>=0)P.bar[o]=P.bar[j];P.bar[j]=si;setSkillLabels();panelMsg='Case '+(j+1)+' : '+esc(c.sk[si].n);break;}
    case'tbook':{const k2=v,pr=+b.dataset.p;if(P.gold>=pr){P.gold-=pr;P.cons[k2]=(P.cons[k2]||0)+1;panelMsg='Lis-le depuis ton sac ou la fenêtre des sorts.';}else panelMsg='Pas assez d’or.';break;}
    case'learn':useCons(v);break;
    case'bounty':panelMsg=esc(takeBounty(v)||'Contrat signé.');break;
    case'set':SET[b.dataset.k]=v;saveSettings();applySettings();break;
    case'setb':SET[b.dataset.k]=!SET[b.dataset.k];saveSettings();break;
    case'tochars':closePanel(true);toTitle();return;
    case'buy':{const p=+b.dataset.p;if(P.gold>=p){P.gold-=p;P.cons[v]=(P.cons[v]||0)+(+b.dataset.n);panelMsg='Merci, bonne route.';}break;}
    case'sell':{const it=P.inv.find(i=>i.id===id);if(it){P.gold+=itemValue(it);P.inv=P.inv.filter(i=>i!==it);panelMsg='Vendu : '+esc(itemName(it));}break;}
    case'pet':if(P.gold>=PETS[v].price){P.gold-=PETS[v].price;P.pet=v;petE=null;panelMsg=esc(PETS[v].n)+' te suit désormais.';}break;
    case'repair':panelMsg=repairAll()?'Équipement réparé.':'Pas assez d’or.';break;
    case'ench':{const it=findItem(id),r=it&&enchant(it);if(r)panelMsg=`<span style="color:${r.ok?'#9be36a':'#ff7a7a'}">${esc(r.t)}</span>`;break;}
    case'reset':panelMsg=resetStats()?'Points rendus : '+P.pts+'.':'Pas assez d’or.';break;
    case'toperso':panelKind='perso';panelTab='stats';break;
    case'hbuy':panelMsg=esc(hdvBuy(v));break;
    case'hsell':{const kind=b.dataset.k,inp=$('#pr_'+(kind==='item'?'i':kind==='res'?'r':'c')+v);panelMsg=esc(hdvList(kind,kind==='item'?+v:v,+(inp&&inp.value),+b.dataset.n||1));break;}
    case'hcancel':panelMsg=esc(hdvCancel(v)||'');break;
    case'hmail':P.gold+=P.hdv.mail;panelMsg='Tu récupères '+P.hdv.mail+' or.';P.hdv.mail=0;break;
    case'wjoin':closePanel(true);joinWar();return;
    case'hon':{const p=+b.dataset.p;if(P.honor>=p){P.honor-=p;P.cons[v]=(P.cons[v]||0)+(+b.dataset.n);panelMsg='Échange effectué.';}break;}
    case'honring':if(P.honor>=600&&!invFull()){P.honor-=600;const it=mkItem(P,'anneau',tierFor(P.lvl),2);P.inv.push(it);panelMsg='Reçu : '+esc(itemName(it));}break;
    case'craft':{const rc=RECIPES.find(r=>r.id===v),m=rc&&craft(rc);if(m==='Incantation en cours…')return;panelMsg=m?(m.startsWith('Échec')?'<span style="color:#ff7a7a">'+m+'</span>':'Fabriqué : '+m):'Impossible pour l’instant.';break;}
    case'respawn':respawn();return;
    default:if(EXTRA_ACT[a]){if(EXTRA_ACT[a](v,b)===false)return;}
  }
  renderPanel();renderTrack();save();});
$('#modal').addEventListener('pointerdown',e=>{if(e.target.id==='modal')closePanel();});

/* ---------- écrans titre, personnages, création ---------- */
let selCls='guerrier',selFac='solarix',selHC=false,delArm=-1;
function preview(cls,fac){const L=botLook(cls,fac,1),s=humSprite(L,1),c=cnv(s.w,s.h);c.getContext('2d').drawImage(s.d[0],0,0);return c;}
function toTitle(){save();state='title';P=null;CI=-1;party=null;$('#hud').hidden=true;$('#joyBase').hidden=true;$('#start').hidden=false;showChars();}
function showChars(){$('#sNew').hidden=true;$('#sMain').hidden=false;const L=$('#charList');L.innerHTML='';
  if(!CHARS.length)L.innerHTML='<p class="help">Aucun personnage. Crée le premier pour entrer dans le monde.</p>';
  CHARS.forEach((c,i)=>{const d=document.createElement('div');d.className='ccard';d.appendChild(preview(c.cls,c.fac));
    d.insertAdjacentHTML('beforeend',`<div class="ci"><b>${esc(c.name)}${c.hc?' <span class="hc">HC</span>':''}</b><small>${CLASSES[c.cls].nom} · niveau ${c.lvl} · <span style="color:${FACTIONS[c.fac].c}">${FACTIONS[c.fac].n}</span></small></div>`);
    const play=document.createElement('button');play.className='btn go';play.type='button';play.textContent='Jouer';play.onclick=()=>startGame(i);
    const del=document.createElement('button');del.className='btn red';del.type='button';del.textContent=delArm===i?'Confirmer':'Supprimer';del.onclick=()=>{if(delArm===i){CHARS.splice(i,1);saveJSON(CHAR_KEY,CHARS);delArm=-1;}else delArm=i;showChars();};
    const bx=document.createElement('div');bx.className='cbtn';bx.append(play,del);d.appendChild(bx);L.appendChild(d);});
  $('#bNew').disabled=CHARS.length>=MAX_CHARS;$('#bNew').textContent=CHARS.length>=MAX_CHARS?'4 personnages maximum':'Nouveau personnage';}
function showNew(){$('#sMain').hidden=true;$('#sNew').hidden=false;buildPick();}
function buildPick(){const cp=$('#clsPick');cp.innerHTML='';
  for(const k in CLASSES){const C=CLASSES[k],b=document.createElement('button');b.type='button';b.className='card';b.setAttribute('aria-pressed',k===selCls);b.appendChild(preview(k,selFac));b.insertAdjacentHTML('beforeend',`<b>${C.nom}</b><small><em>${C.role}</em><br>${C.desc}</small>`);b.onclick=()=>{selCls=k;buildPick();};cp.appendChild(b);}
  const fp=$('#facPick');fp.innerHTML='';
  for(const k in FACTIONS){const f=FACTIONS[k],b=document.createElement('button');b.type='button';b.className='card fac';b.setAttribute('aria-pressed',k===selFac);b.innerHTML=`<b><i style="background:${f.c}"></i>${esc(f.full)}</b><small>${esc(f.d)}</small>`;b.onclick=()=>{selFac=k;buildPick();};fp.appendChild(b);}
  $('#hcTog').setAttribute('aria-pressed',selHC);$('#hcTog').textContent=selHC?'Hardcore : activé':'Hardcore : désactivé';}
$('#bNew').onclick=showNew;$('#bBack').onclick=showChars;
$('#hcTog').onclick=()=>{selHC=!selHC;buildPick();};
if($('#bCreate'))$('#bCreate').onclick=()=>{const name=($('#nameIn').value||'').trim().slice(0,14);if(name.length<3){$('#nameMsg').textContent='Le nom doit faire au moins 3 caractères.';return;}if(CHARS.some(c=>c.name.toLowerCase()===name.toLowerCase())){$('#nameMsg').textContent='Ce nom est déjà pris.';return;}
  CHARS.push(newChar(name,selCls,selFac,selHC));saveJSON(CHAR_KEY,CHARS);startGame(CHARS.length-1);};
function startGame(i){CI=i;P=JSON.parse(JSON.stringify(CHARS[i]));
  P.al=Object.assign({for:0,dex:0,int:0,con:0,sag:0},P.al);P.cons=P.cons||{};P.res=P.res||{};P.eq=P.eq||{};P.buffs=P.buffs||[];P.skr=(P.skr||[]).concat([0,0,0,0,0,0,0,0,0,0]).slice(0,10);if(!P.skr[0])P.skr[0]=1;P.bar=Array.isArray(P.bar)&&P.bar.length===6?P.bar:[0,1,2,3,4,5];P.ev=P.ev||{};P.bags=Array.isArray(P.bags)?P.bags:[null,null];for(const k in PROFS)if(!P.prof[k])P.prof[k]={l:1,xp:0};if(P.eq.anneau1&&!P.eq.anneau)P.eq.anneau=P.eq.anneau1;for(const k of ['second','anneau1','anneau2'])if(P.eq[k]){if(P.eq[k]!==P.eq.anneau)P.inv.push(P.eq[k]);delete P.eq[k];}for(const it of [...P.inv,...Object.values(P.eq).filter(Boolean)])if(it.rar>3)it.rar=3;P.qs=P.qs||{act:{},done:{},bdefs:[],board:[],bT:0};P.codex=P.codex||{};if(P.q)delete P.q;P.petF=Object.assign({gold:true,eq:true,min:0,res:true,cons:true},P.petF);for(const k in PROFS)P.prof[k]=P.prof[k]||{l:1,xp:0};P.hdv=P.hdv||{list:[],mail:0};
  initRuntime();P.look=botLook(P.cls,P.fac,strSeed(P.name)%6);
  if(!bots.length)createBots();party=null;chatLines.length=0;
  const s=stats();if(!P.hp||P.hp<=0)P.hp=s.maxhp;if(!P.mp)P.mp=s.maxmp;
  $('#start').hidden=true;$('#hud').hidden=false;state='play';paused=false;tGame=0;
  $('#pname').textContent=P.name;$('#fac').innerHTML=`<span style="color:${FACTIONS[P.fac].c}">${FACTIONS[P.fac].n}</span> · ${CLASSES[P.cls].nom}${P.hc?' · <span class="hc">HC</span>':''}`;
  setSkillLabels();
  const mp=MAPS[P.map]?P.map:FACTIONS[P.fac].cap;enterMap(mp,P.x?{x:P.x,y:P.y}:{});
  if(!P.qs.done.M1&&!P.qs.act.M1){for(const l of PROLOGUE.slice(0,3))chat(null,l);toast('Bienvenue à '+FACTIONS[P.fac].capN,'Parle à '+NPC_DEF[P.fac].quest[0]+', le « ! » au nord de la place');}else chat(null,`De retour à ${FACTIONS[P.fac].capN}.`);applySettings();renderTrack();}

/* ---------- démarrage ---------- */
buildMonsterSprites();buildEvSprites();buildProps();buildProps2();buildEcoProps();buildPetSprites();buildQDB();bagSprites();showChars();
let last=performance.now();
function frame(now){const dt=Math.min(.05,(now-last)/1000);last=now;if(state==='play'&&!paused)update(dt);render();requestAnimationFrame(frame);}
requestAnimationFrame(frame);
addEventListener('pagehide',save);document.addEventListener('visibilitychange',()=>{if(document.hidden)save();});
