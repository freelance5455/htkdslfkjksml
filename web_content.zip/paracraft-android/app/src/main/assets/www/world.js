'use strict';
/* ===================== Génération des cartes (façon TWOM) ===================== */
const GT={BRIDGE:24,MEADOW:0,MOON:1,FOREST:2,SWAMP:3,STEPPE:4,ASH:5,ROAD:6,SAND:7,STONE:8,MOSS:9,WATER:10,DEEP:11,PLAZA:12,DECK:13,FORT:14,MUD:15,HILLS:16,VALE:17,DESERT:18,CAVE:19,TEMPLE:20,CRYPT:21,VOID:22,LAVA:23};
const PAL=[
 [0x4f9a45,0x5aa84c,0x66b555,0x79c364],[0x3f8f6a,0x48a076,0x55ae82,0x6cc296],[0x2b5e33,0x31693a,0x3a7643,0x45844d],[0x3a4529,0x43502f,0x4c5a35,0x56653c],
 [0x7a7a40,0x8a8a4a,0x96964f,0xa4a45c],[0x3e3446,0x473c50,0x52465c,0x5e5268],[0x8a6c45,0x9a7a50,0xa8875a,0xb59466],[0xc0a46c,0xcdb27a,0xd8bf88,0xe2cb95],
 [0x6e6c75,0x7f7d86,0x8c8a93,0x99979f],[0x53603f,0x5d6a48,0x68774f,0x72825a],[0x2a5f9e,0x2a64a8,0x2e6fb5,0x3478bd],[0x15325e,0x173868,0x1b3f7a,0x1e4682],
 [0x8a8892,0x9a98a2,0xa8a6b0,0xb4b2bc],[0x7a5838,0x8a6440,0x9a7048,0xa87c52],[0x5e5868,0x6e6878,0x7a7484,0x86808e],[0x343420,0x3a3a26,0x44442c,0x4e4e34],
 [0x5e8a40,0x6a9a48,0x76a852,0x84b45e],[0x407a4c,0x4a8a58,0x55966a,0x62a476],[0xc8a868,0xd8b878,0xe0c486,0xe8d094],[0x403830,0x4a4038,0x544a40,0x5e5448],
 [0x345058,0x3a5a62,0x426670,0x4c727c],[0x302a3a,0x3a3444,0x443e50,0x4e485a],[0x0e0a14,0x120e18,0x16121e,0x1a1624],[0xb8341a,0xd8442a,0xe8642a,0xf8943a],[0x6a4a2a,0x7a5634,0x8a6440,0x9a7048]];
const NATURAL=new Set([0,1,2,3,4,5,6,7,15,16,17,18]);
const BIOME_GT={abyss:GT.CRYPT,meadow:GT.MEADOW,moon:GT.MOON,hills:GT.HILLS,vale:GT.VALE,forest:GT.FOREST,steppe:GT.STEPPE,swamp:GT.SWAMP,desert:GT.DESERT,ash:GT.ASH};
const MMCOL=['#5aa84c','#48a076','#31693a','#4c5a35','#8a8a4a','#473c50','#a8875a','#d8bf88','#8c8a93','#68774f','#2e6fb5','#1b3f7a','#a8a6b0','#8a6440','#7a7484','#3a3a26','#76a852','#55966a','#e0c486','#544a40','#426670','#443e50','#120e18','#e8642a','#9a7048'];

let M=null;
const mapCache=new Map();
function tAt(tx,ty){if(!M||tx<0||ty<0||tx>=M.w||ty>=M.h)return -1;return ty*M.w+tx;}
function solidT(tx,ty){const i=tAt(tx,ty);return i<0||M.sol[i]===1;}
function solidPx(px,py){return solidT(Math.floor(px/TS),Math.floor(py/TS));}
function gtAt(px,py){const i=tAt(Math.floor(px/TS),Math.floor(py/TS));return i<0?-1:M.gr[i];}
function addProp(m,k,x,y,o){const p=Object.assign({k,x,y},o||{});const r=clamp(Math.floor((y-1)/TS),0,m.h-1);(m.props[r]||(m.props[r]=[])).push(p);if(p.light)m.lights.push(p);return p;}

function newMap(id,w,h,kind){const m={steles:[],signs:[],id,w,h,kind,gr:new Uint8Array(w*h),sol:new Uint8Array(w*h),props:[],lights:[],nodes:[],exits:[],spawns:[],npcs:[],guards:[],citizens:[],portals:[],chests:[],road:new Uint8Array(w*h),def:MAPS[id]||null};return m;}
function setT(m,tx,ty,gt,sol){if(tx<0||ty<0||tx>=m.w||ty>=m.h)return;const i=ty*m.w+tx;m.gr[i]=gt;m.sol[i]=sol?1:0;}
function roadLine(m,x0,y0,x1,y1,wd,R){const n=Math.ceil(Math.hypot(x1-x0,y1-y0))*2;const ph=R()*100;
  for(let i=0;i<=n;i++){const t=i/n;let x=x0+(x1-x0)*t,y=y0+(y1-y0)*t;const off=(vnoise(t*4+ph,ph)-.5)*3*Math.sin(t*Math.PI);
    if(Math.abs(x1-x0)>Math.abs(y1-y0))y+=off;else x+=off;
    for(let dy=-wd;dy<=wd;dy++)for(let dx=-wd;dx<=wd;dx++){if(dx*dx+dy*dy>wd*wd+.5)continue;const tx=Math.round(x+dx),ty=Math.round(y+dy);if(tx<1||ty<1||tx>=m.w-1||ty>=m.h-1)continue;const k=ty*m.w+tx;if(m.gr[k]===GT.DEEP&&m.kind!=='field')continue;m.gr[k]=GT.ROAD;m.sol[k]=0;m.road[k]=1;}}}
function freeTile(m,R,test,tries=3000){for(let n=0;n<tries;n++){const tx=2+Math.floor(R()*(m.w-4)),ty=2+Math.floor(R()*(m.h-4)),i=ty*m.w+tx;if(m.sol[i]||!test(tx,ty,i))continue;return{tx,ty};}return null;}
function nearRoad(m,tx,ty,r){for(let y=-r;y<=r;y++)for(let x=-r;x<=r;x++){const i=(ty+y)*m.w+tx+x;if(tx+x>=0&&ty+y>=0&&tx+x<m.w&&ty+y<m.h&&m.road[i])return true;}return false;}
function clearZone(m,cx,cy,r,gt){for(let y=-r;y<=r;y++)for(let x=-r;x<=r;x++){if(x*x+y*y>r*r)continue;const tx=cx+x,ty=cy+y;if(tx<1||ty<1||tx>=m.w-1||ty>=m.h-1)continue;const i=ty*m.w+tx;if(m.gr[i]!==GT.ROAD)m.gr[i]=gt;m.sol[i]=0;m.blocked&&(m.blocked[i]=1);}}

/* ---------- carte de terrain ---------- */
function genField(id){
  const d=MAPS[id],w=72,h=54,m=newMap(id,w,h,'field'),R=mulberry(strSeed(id)),base=BIOME_GT[d.biome],seed=strSeed(id)%1000;
  m.blocked=new Uint8Array(w*h);
  for(let ty=0;ty<h;ty++)for(let tx=0;tx<w;tx++)setT(m,tx,ty,base,0);
  // eau
  for(let ty=0;ty<h;ty++)for(let tx=0;tx<w;tx++){const i=ty*w+tx;
    if(d.biome==='swamp'){if(vnoise(tx*.17+seed,ty*.17)>.6)setT(m,tx,ty,GT.WATER,1);}
    else if(d.biome==='ash'||d.biome==='abyss'){if(fbm(tx*.09+seed,ty*.09)>.7)setT(m,tx,ty,GT.LAVA,1);}
    else if(d.biome==='desert'){if(fbm(tx*.08+seed,ty*.08)>.78)setT(m,tx,ty,GT.WATER,1);}
    else{if(fbm(tx*.07+seed,ty*.07)>.71)setT(m,tx,ty,GT.WATER,1);}}
  // bordure
  const bordK={meadow:'oak',moon:'moon',hills:'oak',vale:'oak2',forest:'pine',steppe:'rock',swamp:'water',desert:'rockd',ash:'rocka',abyss:'rocka'}[d.biome];
  const exitR={};for(const dir in d.ex)exitR[dir]=true;
  const midX=Math.floor(w/2),midY=Math.floor(h/2);
  const inExit=(tx,ty)=>(exitR.n&&ty<6&&Math.abs(tx-midX)<=3)||(exitR.s&&ty>h-7&&Math.abs(tx-midX)<=3)||(exitR.w&&tx<6&&Math.abs(ty-midY)<=3)||(exitR.e&&tx>w-7&&Math.abs(ty-midY)<=3);
  for(let ty=0;ty<h;ty++)for(let tx=0;tx<w;tx++){const e=Math.min(tx,ty,w-1-tx,h-1-ty)+(vnoise(tx*.25+seed,ty*.25)-.5)*2.4;
    if(e<2.6&&!inExit(tx,ty)){if(bordK==='water')setT(m,tx,ty,GT.DEEP,1);else{setT(m,tx,ty,base,1);if((tx+ty)%2===0||R()<.5)addProp(m,bordK,tx*TS+8+(R()-.5)*6,ty*TS+14,{fade:true,border:1});}}}
  // routes : sorties -> centre
  const cx=midX,cy=midY;
  for(const dir in d.ex){const [ex,ey]={n:[midX,0],s:[midX,h-1],w:[0,midY],e:[w-1,midY]}[dir];roadLine(m,ex,ey,cx,cy,1.2,R);
    const lim={n:[midX-3,midX+3],s:[midX-3,midX+3],w:[midY-3,midY+3],e:[midY-3,midY+3]}[dir];m.exits.push({dir,to:d.ex[dir],a:lim[0],b:lim[1]});
    const pp={n:[[midX-4,3],[midX+4,3]],s:[[midX-4,h-3],[midX+4,h-3]],w:[[2,midY-4],[2,midY+4]],e:[[w-3,midY-4],[w-3,midY+4]]}[dir];
    for(const [px,py] of pp){setT(m,px,py,GT.ROAD,1);addProp(m,'pillar',px*TS+8,py*TS+16,{light:{r:44,c:'#7ff3ff'}});}}
  // portail de donjon
  if(d.dungeon){const pt={x:cx+(R()<.5?-14:14),y:cy+(R()<.5?-10:9)};clearZone(m,pt.x,pt.y,4,base);roadLine(m,pt.x,pt.y+2,cx,cy,1,R);
    for(let x=-1;x<=1;x++)setT(m,pt.x+x,pt.y,base,1);m.portals.push({x:pt.x*TS+8,y:(pt.y+1)*TS+2,dg:d.dungeon});addProp(m,'portal',pt.x*TS+8,(pt.y+1)*TS,{light:{r:70,c:'#c58cff'},portal:1});}
  // portails d'événements : Phare des Éclats, raids à clé
  {const extra=(d.phare?['phare']:[]).concat(d.raids?['raid_crypte','raid_sanct','raid_forge']:[]),offs=[[-22,-14],[22,-14],[-22,14],[22,14]];
    extra.forEach((dg,k)=>{const pt={x:cx+offs[k][0],y:cy+offs[k][1]};clearZone(m,pt.x,pt.y,4,base);roadLine(m,pt.x,pt.y+2,cx,cy,1,R);for(let x=-1;x<=1;x++)setT(m,pt.x+x,pt.y,base,1);m.portals.push({x:pt.x*TS+8,y:(pt.y+1)*TS+2,dg});addProp(m,'portal',pt.x*TS+8,(pt.y+1)*TS,{light:{r:80,c:dg==='phare'?'#7ff3ff':'#ff5a5a'},portal:1});addProp(m,'sign',pt.x*TS+8+28,(pt.y+2)*TS);(m.signs||(m.signs=[])).push({x:pt.x*TS+8+28,y:(pt.y+2)*TS-26,t:DUNGEONS[dg].n});});}
  // fort de la Frontière
  if(d.fort){for(let y=-8;y<=8;y++)for(let x=-8;x<=8;x++){const r=Math.hypot(x,y),tx=cx+x,ty=cy+y;if(r<7.6){setT(m,tx,ty,GT.FORT,0);m.blocked[ty*w+tx]=1;}
      if(r>=6.2&&r<7.2&&Math.abs(x)>1&&Math.abs(y)>1&&hash(tx,ty)<.8){setT(m,tx,ty,GT.FORT,1);addProp(m,'fortwall',tx*TS+8,(ty+1)*TS);}}
    m.fort={x:cx*TS+8,y:cy*TS+8};addProp(m,'flagpole',cx*TS+8,cy*TS+10,{flag:1,light:{r:60,c:'#ffb050'}});setT(m,cx,cy,GT.FORT,1);}
  // boss : arène dégagée
  const bossT=(d.mons||[]).find(x=>MT[x[0]].boss);
  if(bossT){const bp={x:w-14,y:12};if(d.side==='umbra')bp.x=13;clearZone(m,bp.x,bp.y,5,base);m.bossPos={x:bp.x*TS+8,y:bp.y*TS+12};}
  // rivière et ponts
  if(['meadow','hills','forest','moon','vale'].includes(d.biome)){const rx0=Math.floor(w*.64);
    for(let ty=0;ty<h;ty++){const rx=rx0+Math.round(Math.sin(ty*.18+seed)*3+(vnoise(ty*.1,seed)-.5)*4);for(let x=rx;x<rx+2;x++){const i=ty*w+x;if(m.blocked[i])continue;if(m.road[i]){m.gr[i]=GT.BRIDGE;m.sol[i]=0;}else setT(m,x,ty,GT.WATER,1);}}}
  // campement et ruines
  const spots=[[cx-12,cy+9],[cx+12,cy+9],[cx-12,cy-9],[cx+12,cy-9],[cx-20,cy],[cx+20,cy]];
  const okBlk=([x,y],r)=>{for(let yy=-r;yy<=r;yy++)for(let xx=-r;xx<=r;xx++){const i=(y+yy)*w+x+xx;if(x+xx<4||y+yy<4||x+xx>w-5||y+yy>h-5||m.blocked[i])return false;}return true;};
  const okSpot=([x,y],r)=>{for(let yy=-r;yy<=r;yy++)for(let xx=-r;xx<=r;xx++){const i=(y+yy)*w+x+xx;if(x+xx<4||y+yy<4||x+xx>w-5||y+yy>h-5)return false;if(m.blocked[i]||m.gr[i]===GT.WATER||m.gr[i]===GT.DEEP||m.gr[i]===GT.LAVA)return false;}return true;};
  const free=spots.filter(sp=>okSpot(sp,4));for(const sp of spots)if(free.length<2&&!free.includes(sp)&&okBlk(sp,4))free.push(sp);
  const C=CAMPS[id];
  if(C&&free.length){const [ax,ay]=free.shift();clearZone(m,ax,ay,4,base);roadLine(m,ax,ay+3,cx,cy,1,R);
    const tent=d.side==='solarix'?'tent_s':d.side==='umbra'?'tent_u':'tent_n';
    for(const [tx2,ty2] of [[ax-3,ay-2],[ax+2,ay-2]]){setT(m,tx2,ty2,m.gr[ty2*w+tx2],1);setT(m,tx2+1,ty2,m.gr[ty2*w+tx2+1],1);addProp(m,tent,(tx2+1)*TS,(ty2+1)*TS,{fade:true});}
    addProp(m,'campfire',ax*TS+8,(ay+1)*TS+4,{light:{r:80,c:'#ffb050'},fire:1});setT(m,ax,ay,m.gr[ay*w+ax],1);
    addProp(m,'crate',(ax-3)*TS+8,(ay+2)*TS+2);addProp(m,'barrel',(ax+3)*TS+8,(ay+2)*TS+2);
    const r2=mulberry(strSeed(id+'npc'));const look={hair:['#3a2a1a','#d8b048','#8a3a1a','#e8e0d0','#2a2a2a'][Math.floor(r2()*5)],hairStyle:['short','long','pony'][Math.floor(r2()*3)],body:d.side==='solarix'?'#8a7a4a':d.side==='umbra'?'#4a3a6a':'#6a4a2a',legs:'#3a3028',belt:'#2a1a10',extra:r2()<.5?'hood':'none',hood:'#3a3a2a',weapon:pick(['sword','bow','staff','dagger'])};
    m.npcs.push({role:'camp',qid:C.qid,fac:d.side||null,n:C.n,r:C.r,x:ax*TS+8,y:(ay+2)*TS+10,look});
    if(d.side){const en=NPC_DEF[d.side].event;m.npcs.push({role:'event',fac:d.side,n:d.side==='solarix'?'Messagère Ilwen':'Messager Dravos',r:'Événements',x:(ax+3)*TS+8,y:(ay+3)*TS+10,look:Object.assign({},NPC_LOOK.event)});}
    m.stations=m.stations||[];const stA={k:'alambic',x:(ax-4)*TS+8,y:(ay+3)*TS};addProp(m,'alambic',stA.x,stA.y);m.stations.push(stA);if(d.pvp){const stP={k:'pupitre',x:(ax+4)*TS+8,y:(ay-1)*TS};addProp(m,'pupitre',stP.x,stP.y);m.stations.push(stP);}
    m.campPos={x:ax*TS+8,y:(ay+2)*TS};}
  if(STELE_LORE[id]&&free.length){const [rx,ry]=free.shift();clearZone(m,rx,ry,3,base);
    for(let k=0;k<10;k++){const a=k/10*6.283,tx2=Math.round(rx+Math.cos(a)*3),ty2=Math.round(ry+Math.sin(a)*3);if(k%3===2)continue;setT(m,tx2,ty2,m.gr[ty2*w+tx2],1);addProp(m,k%2?'ruin':'ruinwall',tx2*TS+8,(ty2+1)*TS);}
    addProp(m,'stele',rx*TS+8,(ry+1)*TS,{stele:id,light:{r:40,c:'#9ad8ff'}});setT(m,rx,ry,m.gr[ry*w+rx],1);m.steles.push({x:rx*TS+8,y:(ry+1)*TS+12,map:id});}
  // panneaux aux sorties
  for(const e of m.exits){const mid=Math.round((e.a+e.b)/2);const [sx,sy]=e.dir==='e'?[w-6,mid-2]:e.dir==='w'?[5,mid-2]:e.dir==='n'?[mid+3,5]:[mid+3,h-6];if(m.sol[sy*w+sx])continue;
    addProp(m,'sign',sx*TS+8,(sy+1)*TS);m.signs.push({x:sx*TS+8,y:(sy+1)*TS-26,t:(e.dir==='e'?'→ ':e.dir==='w'?'← ':e.dir==='n'?'↑ ':'↓ ')+MAPS[e.to].n});}
  // rivages
  const W=(tx,ty)=>{const i=tAt2(m,tx,ty);return i>=0&&(m.gr[i]===GT.WATER||m.gr[i]===GT.DEEP);};
  for(let ty=1;ty<h-1;ty++)for(let tx=1;tx<w-1;tx++){const i=ty*w+tx;if(m.sol[i]||m.road[i])continue;if(W(tx-1,ty)||W(tx+1,ty)||W(tx,ty-1)||W(tx,ty+1))m.gr[i]=d.biome==='swamp'?GT.MUD:GT.SAND;}
  // décor
  const dens={meadow:[['oak',.025],['bushf',.02],['bush',.015],['rock',.006]],moon:[['moon',.035],['bushb',.025],['rock',.005]],hills:[['oak',.02],['rock',.025],['bush',.02]],
    vale:[['oak2',.03],['bushb',.02],['moon',.01]],forest:[['pine',.08],['oak2',.06],['bush',.03]],steppe:[['rock',.02],['oak',.008],['bush',.01]],
    swamp:[['willow',.035],['dead',.025],['reed',.05]],desert:[['cactus',.02],['palm',.008],['rockd',.02]],ash:[['deadash',.03],['rocka',.04],['crystal',.008],['bones',.006]],abyss:[['deadash',.02],['rocka',.03],['spectral',.01],['crystal',.02]]}[d.biome];
  if(d.biome==='forest')dens.push(['grave',.006]);if(d.biome==='desert')dens.push(['obelisk',.004],['bones',.008]);if(d.biome==='swamp'||d.biome==='steppe')dens.push(['bones',.008]);
  for(let ty=3;ty<h-3;ty++)for(let tx=3;tx<w-3;tx++){const i=ty*w+tx;if(m.sol[i]||m.blocked[i]||m.road[i]||nearRoad(m,tx,ty,1))continue;if(Math.hypot(tx-cx,ty-cy)<4)continue;
    const v=R();let acc=0;for(const [k,p] of dens){acc+=p;if(v<acc){const solid=!['bush','bushb','bushf','reed','bones'].includes(k);if(solid)m.sol[i]=1;addProp(m,k,tx*TS+8+(R()-.5)*4,ty*TS+14,{fade:solid&&!k.startsWith('rock')&&k!=='cactus'});break;}}}
  // nœuds de récolte
  const rt=Math.min(3,d.tier);
  const place=(n,kind,res)=>{for(let k=0;k<n;k++){const p=freeTile(m,R,(tx,ty,i)=>!m.road[i]&&!m.blocked[i]&&!nearRoad(m,tx,ty,1)&&Math.hypot(tx-cx,ty-cy)>4);if(!p)continue;const i=p.ty*w+p.tx;
    const node={kind,res,x:p.tx*TS+8,y:p.ty*TS+14,alive:true,rt:0};
    if(kind==='bois'){m.sol[i]=1;node.prop=addProp(m,res,node.x,node.y,{fade:true,node});}
    else node.prop=addProp(m,kind==='minerai'?'ore_'+res:'herb_'+res,node.x,node.y,{node});
    m.nodes.push(node);}};
  place(9,'bois',WOOD[rt]);place(7,'minerai',ORE[rt]);place(9,'plante',HERB[rt]);
  if(d.pvp&&!d.bf){place(4,'plante','moussesang');place(3,'minerai','fernoir');if(d.lv[0]>=26){place(3,'plante','racarcane');place(3,'minerai','quartzombre');}if(d.lv[0]>=30)place(3,'plante','champcav');}
  if(d.biome!=='ash'){let n=0;for(let k=0;k<4000&&n<6;k++){const tx=3+Math.floor(R()*(w-6)),ty=3+Math.floor(R()*(h-6)),i=ty*w+tx;if(m.gr[i]!==GT.WATER)continue;
    let land=null;for(const [dx,dy] of [[0,1],[1,0],[-1,0],[0,-1]]){const j=(ty+dy)*w+tx+dx;if(!m.sol[j])land=[tx+dx,ty+dy];}if(!land)continue;
    m.nodes.push({kind:'poisson',res:FISH[rt],x:tx*TS+8,y:ty*TS+8,alive:true,rt:0,fx:land[0]*TS+8,fy:land[1]*TS+12});n++;}}
  // points d'apparition
  for(const [type,n,lv] of d.mons||[]){if(MT[type].boss){m.spawns.push({type,lv,x:m.bossPos.x,y:m.bossPos.y});continue;}
    for(let k=0;k<n;k++){const p=freeTile(m,R,(tx,ty,i)=>!m.blocked[i]&&!m.road[i]&&Math.min(tx,ty,w-tx,h-ty)>6&&!(d.fort&&Math.hypot(tx-cx,ty-cy)<10));if(p)m.spawns.push({type,lv,x:p.tx*TS+8,y:p.ty*TS+12});}}
  if(d.wb){const p=freeTile(m,R,(tx,ty,i)=>!m.road[i]&&Math.hypot(tx-cx,ty-cy)>12&&Math.min(tx,ty,w-tx,h-ty)>9);if(p){clearZone(m,p.tx,p.ty,6,base);m.wbPos={x:p.tx*TS+8,y:p.ty*TS+12};}}
  return m;
}
function tAt2(m,tx,ty){if(tx<0||ty<0||tx>=m.w||ty>=m.h)return -1;return ty*m.w+tx;}

/* ---------- capitale façon WoW ---------- */
const NPC_DEF={
  solarix:{event:['Héraute Lysandre','Événements'],quest:['Capitaine Aldric','Quêtes'],shop:['Bertille','Marchande'],forge:['Grom','Forgeron'],trainer:['Maître d’armes Hugues','Caractéristiques'],hdv:['Commissaire Velin','Hôtel des ventes'],guild:['Intendante Maëlle','Guildes'],craft:['Artisane Iselde','Métiers'],war:['Héraut Gaspard','Guerre et honneur']},
  umbra:{event:['Crieur Vaelis','Événements'],quest:['Oracle Ysolde','Quêtes'],shop:['Fenna','Marchande'],forge:['Torvek','Forgeron'],trainer:['Sage Oren','Caractéristiques'],hdv:['Négociant Lirio','Hôtel des ventes'],guild:['Gardienne Sylwen','Guildes'],craft:['Tisserande Nalia','Métiers'],war:['Brann Cor-de-guerre','Guerre et honneur']}};
const NPC_ROLES=['event','quest','shop','forge','trainer','hdv','guild','craft','war'];
const NPC_LOOK={
  event:{hair:'#e8c860',hairStyle:'pony',body:'#b8402a',body2:'#f2c14e',belt:'#f2c14e',legs:'#3a2a4a',cape:'#f2c14e',weapon:'none'},
  quest:{hair:'#d8d8d8',body:'#3a5a9a',belt:'#f2c14e',legs:'#2a3a6a',cape:'#7a1a2a'},shop:{hair:'#7a4a22',hairStyle:'long',body:'#c9873a',belt:'#5a3a1a',legs:'#4a3a2a'},
  forge:{hair:'#2a2a2a',skin:'#c9946a',body:'#5a5a62',belt:'#8a5a2a',legs:'#3a3a40',weapon:'hammer'},trainer:{hair:'#8a6a4a',body:'#8a2a2a',legs:'#3a2a2a',weapon:'sword',extra:'helm'},
  hdv:{hair:'#4a3a2a',body:'#6a3a8a',belt:'#f2c14e',legs:'#3a2a4a'},guild:{hair:'#c84a2a',hairStyle:'pony',body:'#2a6a6a',belt:'#d8d8d8',legs:'#1a3a3a'},
  craft:{hair:'#e8c860',hairStyle:'long',body:'#7a6a3a',belt:'#4a3a1a',legs:'#5a4a2a'},war:{hair:'#3a2a1a',body:'#8a95a8',legs:'#4a4f5c',extra:'helm',plume:'#e04a4a',weapon:'halberd'}};
function genCity(id){
  const d=MAPS[id],w=d.w,h=d.h,m=newMap(id,w,h,'city'),R=mulberry(strSeed(id)),st=d.style,fac=d.side;
  const cx=30,cy=23,ground=st==='o'?GT.STONE:GT.MOSS,outside=st==='o'?GT.MEADOW:GT.MOON;
  m.blocked=new Uint8Array(w*h);
  for(let ty=0;ty<h;ty++)for(let tx=0;tx<w;tx++){const dx=tx-cx,dy=ty-cy,r=Math.hypot(dx+.5,dy+.5);let gt=outside,sol=0;
    const e=Math.min(tx,ty,w-1-tx,h-1-ty);
    if(r<16.4){gt=ground;if(Math.abs(dx)<=1||Math.abs(dy)<=1)gt=st==='o'?GT.PLAZA:GT.DECK;if(r<5.2)gt=st==='o'?GT.PLAZA:GT.DECK;
      if(r>=15.2&&Math.abs(dx)>1&&Math.abs(dy)>1){sol=1;}}
    else if(e<2){sol=1;}
    setT(m,tx,ty,gt,sol);if(r<16.4)m.blocked[ty*w+tx]=1;}
  // murs
  for(let ty=0;ty<h;ty++)for(let tx=0;tx<w;tx++){const dx=tx-cx,dy=ty-cy,r=Math.hypot(dx+.5,dy+.5);
    if(r>=15.2&&r<16.4&&Math.abs(dx)>1&&Math.abs(dy)>1){const gateSide=(Math.abs(dx)===2&&Math.abs(dy)>12)||(Math.abs(dy)===2&&Math.abs(dx)>12);addProp(m,gateSide?'tower_'+st:'wall_'+st,tx*TS+8,(ty+1)*TS,{wall:1});}}
  // bordure d'arbres
  for(let ty=0;ty<h;ty++)for(let tx=0;tx<w;tx++){const e=Math.min(tx,ty,w-1-tx,h-1-ty);const exitOpen=(st==='o'?tx>w-4:tx<3)&&Math.abs(ty-cy)<=3;
    if(e<2&&!exitOpen&&((tx+ty)%2===0))addProp(m,st==='o'?'oak':'moon',tx*TS+8,ty*TS+14,{fade:true,border:1});
    if(exitOpen)m.sol[ty*w+tx]=0;}
  roadLine(m,st==='o'?cx+16:cx-16,cy,st==='o'?w-1:0,cy,1.2,R);
  m.exits.push({dir:st==='o'?'e':'w',to:d.ex[st==='o'?'e':'w'],a:cy-3,b:cy+3});
  // centre
  for(let y=-1;y<=1;y++)for(let x=-1;x<=1;x++)m.sol[(cy+y)*w+cx+x]=1;
  if(st==='o')addProp(m,'fountain',(cx+.5)*TS,(cy+2)*TS,{fountain:1});else addProp(m,'mothertree',(cx+.5)*TS,(cy+2)*TS,{fade:true,big:1});
  // bâtiments
  const B=[['hdv',-11,-10],['guild',6,-10],['craft',-11,6],['war',6,6],['home',-14,-5],['home',9,-5],['home',-14,2],['home',9,2]];
  for(const [role,x0,y0] of B){for(let y=y0;y<y0+3;y++)for(let x=x0;x<x0+6;x++)m.sol[(cy+y)*w+cx+x]=1;addProp(m,'house_'+st+'_'+role,(cx+x0+3)*TS,(cy+y0+3)*TS,{fade:true,house:1,win:[[(cx+x0+1)*TS,(cy+y0+2)*TS],[(cx+x0+5)*TS,(cy+y0+2)*TS]]});}
  // PNJ
  const pos={event:[cx-3.2,cy+4.2],quest:[cx+.5,cy-2.4],shop:[cx-3.2,cy+.9],forge:[cx+4.2,cy+.9],trainer:[cx+.5,cy+4.2],hdv:[cx-8,cy-6.4],guild:[cx+9,cy-6.4],craft:[cx-8,cy+9.6],war:[cx+9,cy+9.6]};
  for(const role in pos){const [nx,ny]=pos[role],nd=NPC_DEF[fac][role];m.npcs.push({role,fac,qid:role==='quest'?'cap':null,n:nd[0],r:nd[1],x:nx*TS,y:ny*TS,look:Object.assign({},NPC_LOOK[role])});}
  {const c0=pos.craft;m.stations=[{k:'alambic',x:(c0[0]-1.6)*TS,y:(c0[1]+.4)*TS},{k:'pupitre',x:(c0[0]+1.6)*TS,y:(c0[1]+.4)*TS},{k:'enclume',x:(pos.forge[0]+1.4)*TS,y:(pos.forge[1]+.6)*TS}];for(const st of m.stations)addProp(m,st.k,st.x,st.y);}
  addProp(m,'board',(cx-2.6)*TS,(cy-1.8)*TS);m.board={x:(cx-2.6)*TS,y:(cy-1.6)*TS};m.signs.push({x:(cx-2.6)*TS,y:(cy-1.8)*TS-30,t:'Primes'});
  addProp(m,st==='o'?'stall_red':'stall_grey',(cx-3.2)*TS,(cy-.2)*TS);addProp(m,'stall_grey',(cx+4.2)*TS,(cy-.2)*TS);addProp(m,'anvil',(cx+5.6)*TS,(cy+1.2)*TS);
  addProp(m,'crate',(cx-4.6)*TS,(cy+1.4)*TS);addProp(m,'barrel',(cx-5.4)*TS,(cy+1.6)*TS);
  for(const [x,y] of [[3,6],[-3,6],[3,-6],[-3,-6],[6,3],[-6,3],[6,-3],[-6,-3]])addProp(m,'lamp',(cx+x+.5)*TS,(cy+y+1)*TS,{light:{r:64,c:'#ffd890'}});
  for(const [x,y] of [[4,4],[-4,4],[4,-4],[-4,-4]])addProp(m,'banner_'+fac,(cx+x+.5)*TS,(cy+y+1)*TS);
  // gardes
  for(const [gx,gy] of [[-2,-13],[3,-13],[-2,14],[3,14],[-13,-2],[-13,3],[14,-2],[14,3]])m.guards.push({x:(cx+gx)*TS,y:(cy+gy)*TS,fac,dir:'d'});
  // citoyens
  const cols=['#8a4a3a','#4a6a8a','#7a7a3a','#6a3a6a','#3a7a6a','#9a6a3a'];
  for(let k=0;k<7;k++)m.citizens.push({x:(cx+.5)*TS,y:(cy+3.5)*TS,tx:0,ty:0,wt:0,anim:0,dir:'d',moving:false,look:{hair:pick(['#3a2a1a','#d8b048','#8a3a1a','#e8e0d0']),hairStyle:pick(['short','long','pony']),body:pick(cols),legs:pick(['#4a3a2a','#3a3a4a','#5a4a3a']),belt:'#4a3a2a'}});
  m.spawnPt={x:(cx+.5)*TS,y:(cy+4.2)*TS+20};
  return m;
}

/* ---------- donjon : salles et couloirs ---------- */
function genDungeon(dgId,floor,seed){
  const D=DUNGEONS[dgId],w=50,h=40,id=dgId+'#'+floor,m=newMap(id,w,h,'dungeon'),R=mulberry(seed+floor*977);
  const fl={cave:GT.CAVE,temple:GT.TEMPLE,crypt:GT.CRYPT,phare:GT.TEMPLE}[D.style];
  m.dg=dgId;m.floor=floor;m.dark=true;m.blocked=new Uint8Array(w*h);
  for(let i=0;i<w*h;i++){m.gr[i]=GT.VOID;m.sol[i]=1;}
  const rooms=[];
  for(let k=0;k<60&&rooms.length<8;k++){const last=floor===D.floors&&rooms.length===7;const rw=last?14:6+Math.floor(R()*5),rh=last?11:5+Math.floor(R()*4);const x=2+Math.floor(R()*(w-rw-4)),y=2+Math.floor(R()*(h-rh-4));
    if(rooms.some(r=>x<r.x+r.w+2&&x+rw+2>r.x&&y<r.y+r.h+2&&y+rh+2>r.y))continue;rooms.push({x,y,w:rw,h:rh,cx:x+Math.floor(rw/2),cy:y+Math.floor(rh/2)});}
  rooms.sort((a,b)=>(a.cx+a.cy*.5)-(b.cx+b.cy*.5));
  for(const r of rooms)for(let y=r.y;y<r.y+r.h;y++)for(let x=r.x;x<r.x+r.w;x++){m.gr[y*w+x]=fl;m.sol[y*w+x]=0;}
  const carve=(x,y)=>{for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){const i=(y+dy)*w+x+dx;if(x+dx>0&&y+dy>0&&x+dx<w-1&&y+dy<h-1){m.gr[i]=fl;m.sol[i]=0;}}};
  for(let k=1;k<rooms.length;k++){const a=rooms[k-1],b=rooms[k];let x=a.cx,y=a.cy;while(x!==b.cx){carve(x,y);x+=Math.sign(b.cx-x);}while(y!==b.cy){carve(x,y);y+=Math.sign(b.cy-y);}carve(x,y);}
  const first=rooms[0],last=rooms[rooms.length-1];
  m.entry={x:first.cx*TS+8,y:first.cy*TS+12};
  addProp(m,'portal',first.cx*TS+8,(first.y+1)*TS+4,{light:{r:70,c:'#c58cff'},portal:1});m.portals.push({x:first.cx*TS+8,y:(first.y+1)*TS+6,out:1});
  for(let x=-1;x<=1;x++)m.sol[first.y*w+first.cx+x]=1;
  for(const r of rooms){for(const [tx,ty] of [[r.x,r.y-1],[r.x+r.w-1,r.y-1]])if(ty>0&&m.sol[ty*w+tx])addProp(m,'lamp',tx*TS+8,(ty+1)*TS,{light:{r:70,c:'#ff9a4a'},torch:1});}
  const mlist=D.monsFl?D.monsFl(floor):D.mons,bossD=D.bossFl?D.bossFl(floor):D.boss;
  rooms.forEach((r,k)=>{if(k===0)return;const isBoss=(floor===D.floors||D.everyBoss)&&r===last;const n=isBoss?3:3+Math.floor(R()*3);
    for(let j=0;j<n;j++){const tx=r.x+1+Math.floor(R()*(r.w-2)),ty=r.y+1+Math.floor(R()*(r.h-2)),mm=mlist[j%mlist.length];m.spawns.push({type:mm[0],lv:mm[1]+floor-1,x:tx*TS+8,y:ty*TS+12,dg:1});}
    if(isBoss)m.spawns.push({type:bossD[0],lv:bossD[1],x:r.cx*TS+8,y:r.cy*TS+12,dg:1});});
  if(floor<D.floors){addProp(m,'stairs',last.cx*TS+8,last.cy*TS+12,{stairs:1});m.stairs={x:last.cx*TS+8,y:last.cy*TS+4};}
  else m.chestPos={x:last.cx*TS+8,y:(last.cy+3)*TS+8};
  return m;
}

/* ---------- cuisson du sol ---------- */
function bakeMap(m){
  const W=m.w*TS,H=m.h*TS,c=cnv(W,H),g=c.getContext('2d'),img=g.createImageData(W,H),D=img.data;
  const blk=new Float32Array(Math.ceil(W/2)*Math.ceil(H/2)),bw=Math.ceil(W/2);
  const sd=strSeed(m.id)%997;
  for(let by=0;by<Math.ceil(H/2);by++)for(let bx=0;bx<bw;bx++)blk[by*bw+bx]=vnoise(bx*.07+sd,by*.07);
  const jw=Math.ceil(W/4),jx=new Int8Array(jw*Math.ceil(H/4)),jy=new Int8Array(jw*Math.ceil(H/4));
  for(let by=0;by<Math.ceil(H/4);by++)for(let bx=0;bx<jw;bx++){jx[by*jw+bx]=Math.round((vnoise(bx*.18+50,by*.18)-.5)*12);jy[by*jw+bx]=Math.round((vnoise(bx*.18,by*.18+70)-.5)*12);}
  const isW=g2=>g2===GT.WATER||g2===GT.DEEP||g2===GT.LAVA;
  const FLW={0:[0xf7e26b,0xf08ad0,0xffffff],1:[0xb8f8ff,0xe0b0ff,0xffffff],16:[0xf8e8a0,0xffffff],17:[0xf8c8e0,0xd8f0ff]};
  for(let py=0;py<H;py++){const ty=py>>4,ly=py&15;for(let px=0;px<W;px++){const tx=px>>4,lx=px&15,i=ty*m.w+tx;let gt=m.gr[i];
    if(NATURAL.has(gt)){const ji=(py>>2)*jw+(px>>2);const sx=px+jx[ji],sy=py+jy[ji];if(sx>=0&&sy>=0&&sx<W&&sy<H){const g2=m.gr[(sy>>4)*m.w+(sx>>4)];if(NATURAL.has(g2))gt=g2;}}
    const n=blk[(py>>1)*bw+(px>>1)],gr=hash(px+sd,py),pal=PAL[gt];let si=n*.78+gr*.22;let col=pal[si<.36?0:si<.52?1:si<.68?2:3];let mul=1;
    if(gt<=2||gt===16||gt===17||gt===4){if(gr<.05)mul=.82;else if(gr>.975)mul=1.12;const fl=FLW[gt];if(fl&&hash(px*3+7,py*5+1)<.0022)col=fl[Math.floor(gr*fl.length*7)%fl.length];}
    else if(gt===GT.ROAD){if(gr<.03)col=0xc8b088;if(hash(px,py+3)<.012)mul=.82;}
    else if(gt===GT.SAND||gt===GT.DESERT){if(Math.sin(px*.31+py*.13+n*7)>.92)mul=1.08;}
    else if(gt===GT.STONE){const lx2=(px+((py>>3)&1)*4)&7,ly2=py&7;if(lx2===0||ly2===0)col=0x5e5c66;else if(ly2===1)mul=1.08;}
    else if(gt===GT.PLAZA){const lx2=px%12,ly2=py%12;if(lx2===0||ly2===0)col=0x77757f;else if(lx2===1||ly2===1)mul=1.06;}
    else if(gt===GT.MOSS){const cx2=Math.floor(px/12)*12+6+Math.floor(hash(Math.floor(px/12),Math.floor(py/12))*3),cy2=Math.floor(py/12)*12+6;if(Math.hypot(px-cx2,py-cy2)<4.3)col=gr<.5?0x8a8a7a:0x9a9a88;}
    else if(gt===GT.DECK){const ly2=py%6;if(ly2===0)col=0x4a3420;else if(ly2===1)mul=1.08;if(((px+Math.floor(py/6)*13)%24)===0)col=0x4a3420;}
    else if(gt===GT.FORT||gt===GT.CRYPT||gt===GT.TEMPLE){const s=gt===GT.TEMPLE?8:10;const lx2=(px+((Math.floor(py/s))&1)*(s/2))%s,ly2=py%s;if(lx2===0||ly2===0)mul=.72;else if(ly2===1)mul=1.07;}
    else if(gt===GT.ASH){const cr=vnoise(px*.09+3,py*.09);if(cr>.485&&cr<.505)col=0xe2603a;}
    else if(gt===GT.MUD){if(n>.66)col=0x2a3020;}
    else if(gt===GT.BRIDGE){const ly2=py%5;if(ly2===0)col=0x3a2614;else if(ly2===1)mul=1.12;if(lx===0||lx===15)col=0x4a3018;}
    else if(gt===GT.CAVE){if(gr<.06)mul=.8;}
    if(isW(gt)){// rivages et vagues
      let d=99;const chk=(dx,dy,dd)=>{const j=tAt2(m,tx+dx,ty+dy);if(j>=0&&!isW(m.gr[j]))d=Math.min(d,dd);};
      chk(-1,0,lx);chk(1,0,15-lx);chk(0,-1,ly);chk(0,1,15-ly);chk(-1,-1,Math.max(lx,ly));chk(1,-1,Math.max(15-lx,ly));chk(-1,1,Math.max(lx,15-ly));chk(1,1,Math.max(15-lx,15-ly));
      if(gt===GT.LAVA){if(Math.sin(px*.4+py*.2+n*9)>.8)col=0xf8c050;if(d<2)col=0x5a2010;}
      else{if(Math.sin(px*.35+py*.9+n*5)>.88)col=gt===GT.WATER?0x5a9ade:0x2a5a98;if(d<2)col=hash(px,py*7)<.6?0xd8eef8:0xa8d0ea;else if(d<5)mul=1.18;}
    }
    if(gt===GT.VOID){const below=tAt2(m,tx,ty+1);const floorBelow=below>=0&&m.gr[below]!==GT.VOID;
      if(floorBelow&&ly>=6){const fc={19:0x5a4a3e,20:0x3a6a74,21:0x4a4458}[m.gr[below]]||0x4a4458;col=fc;mul=ly===6?1.25:(ly%5===0?.75:1);if(((px+(ly>10?4:0))&7)===0)mul=.75;}
      else if(gr<.04)col=0x2a2434;}
    let r=(col>>16)&255,gg=(col>>8)&255,b=col&255;if(mul!==1){r=Math.min(255,r*mul);gg=Math.min(255,gg*mul);b=Math.min(255,b*mul);}
    const k=(py*W+px)*4;D[k]=r;D[k+1]=gg;D[k+2]=b;D[k+3]=255;}}
  g.putImageData(img,0,0);
  m.canvas=c;
  const mm=cnv(m.w,m.h),mg=mm.getContext('2d');for(let ty=0;ty<m.h;ty++)for(let tx=0;tx<m.w;tx++){const i=ty*m.w+tx;mg.fillStyle=m.sol[i]&&!isW(m.gr[i])&&m.gr[i]!==GT.VOID?'#24442a':MMCOL[m.gr[i]];if(m.kind==='city'&&m.sol[i]&&m.gr[i]!==GT.MEADOW&&m.gr[i]!==GT.MOON)mg.fillStyle='#4a4652';mg.fillRect(tx,ty,1,1);}
  m.mm=mm;
}
function getMap(id){let m=mapCache.get(id);if(m)return m;const d=MAPS[id];m=d.kind==='city'?genCity(id):genField(id);bakeMap(m);mapCache.set(id,m);return m;}
