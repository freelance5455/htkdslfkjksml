'use strict';
/* ===================== Quêtes, primes, stèles et chroniques ===================== */
const QDB={};
function plural(n){return n.split(' ').map(w=>/^(d’|d'|de|des|du|·)/.test(w)||/[sx]$/.test(w)?w:w+'s').join(' ').toLowerCase();}
function buildQDB(){
  for(const q of MAIN){QDB[q.id]=Object.assign({chain:'main'},q);QDB[q.id].rew=Object.assign({},q.rew,{xp:Math.round(xpNeed(Math.max(1,q.lvl))*.35/10)*10});}
  for(const mid in CAMPS){const d=MAPS[mid];if(!d.mons)continue;const C=CAMPS[mid],real=d.mons.filter(x=>!MT[x[0]].boss);
    const [a,,la]=real[0],[b,,lb]=real[1]||real[0],L=d.lv[0],id=k=>'S_'+mid+'_'+k;
    QDB[id(1)]={id:id(1),chain:'side',map:mid,giver:C.qid,lvl:L,rep:true,t:'Chasse : '+plural(MT[a].n),
      d:`${C.g} En attendant, éclaircis les environs du camp : abats 10 ${plural(MT[a].n)}.`,obj:[{k:'kill',m:a,n:10}],rew:{xp:Math.round(monStats(a,la).xp*10),gold:la*15},fin:'Le camp respire mieux. Reviens quand tu veux, il en repousse toujours.'};
    QDB[id(2)]={id:id(2),chain:'side',map:mid,giver:C.qid,lvl:L,t:'Trophées : '+QITEM[b],
      d:`On me paie bien pour ces trophées, et les ${plural(MT[b].n)} en portent. Rapporte-m'en 6.`,obj:[{k:'collect',m:b,it:QITEM[b],p:.4,n:6}],rew:{xp:Math.round(monStats(b,lb).xp*12),gold:lb*20,cons:{pv:3}},fin:'Belle pièce. Voilà ta part.'};
    QDB[id(3)]={id:id(3),chain:'side',map:mid,giver:C.qid,lvl:L,t:'Mémoire des pierres',
      d:`Une stèle ancienne se dresse quelque part dans ${d.n}. Lis ce qui y est gravé, et récolte 4 ressources en chemin : rien ne se perd ici.`,obj:[{k:'read',map:mid,n:1},{k:'harvest',n:4}],rew:{xp:Math.round(monStats(a,la).xp*8),gold:la*10,book:L>=11?'rand':null,item:L<11?1:null},fin:'Les pierres se souviennent mieux que nous. Merci.'};}
  for(const q of Object.values(QDB))if(q.chain==='side'&&q.map)q.rew.xp=Math.max(q.rew.xp||0,Math.round(xpNeed(q.lvl)*.12/10)*10);
}
const qdone=id=>!!P.qs.done[id];
function qDef(id){return QDB[id]||(P.qs.bdefs||[]).find(b=>b.id===id)||null;}
function tok(s){if(typeof s!=='string')return s;const T=SIDE_TOK[P.fac],f=FACTIONS[P.fac];
  return s.replace(/\{(\w+)\}/g,(m,k)=>{if(k==='fac')return f.n;if(k==='cap')return f.capN;if(k==='rival')return FACTIONS[enemyOf(P.fac)].n;
    if(/^z\d$/.test(k))return MAPS[T.s+k[1]].n;if(/^camp\d$/.test(k))return CAMPS[T.s+k[4]].n;if(k[0]==='p'&&T[k.slice(1)])return plural(MT[T[k.slice(1)]].n);if(T[k])return T[k];return m;});}
const tokMap=m=>m&&m[0]==='{'?SIDE_TOK[P.fac].s+m[2]:m;
function qGiverName(qid){if(qid==='cap')return NPC_DEF[P.fac].quest[0];if(qid==='board')return'le tableau des primes';const T=SIDE_TOK[P.fac];if(/^camp\d$/.test(qid))return CAMPS[T.s+qid[4]].n;for(const k in CAMPS)if(CAMPS[k].qid===qid)return CAMPS[k].n;return'?';}
function qGiverPlace(qid){if(qid==='cap')return FACTIONS[P.fac].capN;if(qid==='board')return FACTIONS[P.fac].capN;const T=SIDE_TOK[P.fac];if(/^camp\d$/.test(qid))return MAPS[T.s+qid[4]].n;for(const k in CAMPS)if(CAMPS[k].qid===qid)return MAPS[k].n;return'';}
function objProg(q,st,j){const o=q.obj[j];if(o.k==='level')return Math.min(o.n,P.lvl);return Math.min(o.n,st.p[j]||0);}
function qComplete(id){const q=qDef(id),st=P.qs.act[id];return!!(q&&st)&&q.obj.every((o,j)=>objProg(q,st,j)>=o.n);}
function qAvail(qid){if(qid==='board')return[];return Object.values(QDB).filter(q=>q.giver===qid&&!P.qs.act[q.id]&&(!qdone(q.id)||q.rep)&&(!q.req||qdone(q.req))&&P.lvl>=(q.lvl||1)-(q.chain==='main'?0:2)&&(!q.map||!MAPS[q.map].side||MAPS[q.map].side===P.fac));}
function qLockedNext(qid){return Object.values(QDB).find(q=>q.giver===qid&&q.chain==='main'&&!qdone(q.id)&&!P.qs.act[q.id]&&(!q.req||qdone(q.req))&&P.lvl<q.lvl);}
function qTurnIns(qid){return Object.keys(P.qs.act).filter(id=>{const q=qDef(id);return q&&(q.end||q.giver)===qid&&qComplete(id);});}
function qInProg(qid){return Object.keys(P.qs.act).filter(id=>{const q=qDef(id);return q&&(q.end||q.giver)===qid&&!qComplete(id);});}
function npcMark(qid){if(!qid||!P)return null;if(qTurnIns(qid).length)return'?';if(qAvail(qid).length)return'!';return null;}
function qAccept(id){const q=qDef(id);if(!q)return'Quête introuvable.';if(Object.keys(P.qs.act).length>=12)return'Journal plein (12 quêtes au maximum).';
  P.qs.act[id]={p:q.obj.map(()=>0)};chat(null,'Quête acceptée : '+tok(q.t));qEvent('level');renderTrack();return null;}
function qAbandon(id){delete P.qs.act[id];if(id[0]==='B')P.qs.bdefs=P.qs.bdefs.filter(b=>b.id!==id);renderTrack();}
function rewardText(r){const a=[];if(r.xp)a.push(r.xp+' XP');if(r.gold)a.push(r.gold+' or');if(r.honor)a.push(r.honor+' honneur');
  if(r.book!=null)a.push(r.book==='rand'?'un grimoire de ta classe':'Grimoire : '+CLASSES[P.cls].sk[r.book].n);if(r.item)a.push('un objet '+RAR[r.item].toLowerCase());
  if(r.cons)for(const [k,n] of Object.entries(r.cons))a.push(n+' × '+CONS[k].n);return a.join(' · ');}
function qTurnIn(id){const q=qDef(id);if(!q||!qComplete(id))return null;const r=q.rew||{};delete P.qs.act[id];P.qs.done[id]=true;
  if(r.gold)P.gold+=r.gold;if(r.honor)P.honor+=r.honor;if(r.cons)for(const [k,n] of Object.entries(r.cons))P.cons[k]=(P.cons[k]||0)+n;
  const got=[];
  if(r.book!=null){const k=r.book==='rand'?'livre_'+P.cls+'_'+ri(2,CLASSES[P.cls].sk.length-2):'livre_'+P.cls+'_'+r.book;P.cons[k]=(P.cons[k]||0)+1;got.push(CONS[k].n);}
  if(r.item){const it=mkItem(P,pick(LOOT_TYPES),tierFor(P.lvl),r.item,P.cls);if(!invFull()){P.inv.push(it);got.push(itemName(it));}}
  if(id[0]==='B')P.qs.bdefs=P.qs.bdefs.filter(b=>b.id!==id);
  if(q.chain==='main'){codexAdd('main:'+id);}
  chat(qGiverName(q.end||q.giver),tok(q.fin||'Merci.'),'#ffd36a');toast('Quête terminée : '+tok(q.t),rewardText(r));
  if(got.length)chat(null,'Reçu : '+got.join(', '));
  if(r.xp)gainXp(Math.round(r.xp*xpMult()));
  renderTrack();save();return got;}
function qEvent(k,data){if(!P||!P.qs)return;
  for(const id of Object.keys(P.qs.act)){const q=qDef(id),st=P.qs.act[id];if(!q){delete P.qs.act[id];continue;}let ch=false;
    q.obj.forEach((o,j)=>{if((st.p[j]||0)>=o.n)return;let inc=0;
      if(k==='kill'&&o.k==='kill'&&tok(o.m)===data.type)inc=1;
      else if(k==='kill'&&o.k==='collect'&&tok(o.m)===data.type&&rnd()<o.p){inc=1;addText(data.x,data.y-30,'+1 '+o.it,'#ffd36a');}
      else if(o.k===k&&['harvest','craft','learn','cast','pvp','war'].includes(k))inc=1;
      else if(k==='talk'&&o.k==='talk'&&o.q===data)inc=1;
      else if(k==='read'&&o.k==='read'&&tokMap(o.map)===data)inc=1;
      if(inc){st.p[j]=Math.min(o.n,(st.p[j]||0)+inc);ch=true;}});
    if((ch||k==='level')&&!st.ok&&qComplete(id)){st.ok=1;toast('Objectifs remplis : '+tok(q.t),'Retourne voir '+qGiverName(q.end||q.giver));}}
  renderTrack();}
function objText(q,j,st){const o=q.obj[j],pr=st?objProg(q,st,j):0,n=o.n;let t;
  switch(o.k){case'kill':t=`Abattre ${n>1?n+' ':''}${n>1?plural(MT[tok(o.m)].n):MT[tok(o.m)].n}`;break;case'collect':t=`${o.it} sur les ${plural(MT[tok(o.m)].n)}`;break;
    case'talk':t='Parler à '+qGiverName(o.q);break;case'read':t='Lire la stèle de '+MAPS[tokMap(o.map)].n;break;case'harvest':t='Récolter des ressources';break;case'craft':t='Fabriquer un objet (alambic, pupitre ou forge)';break;
    case'learn':t='Apprendre un sort avec un grimoire';break;case'cast':t='Lancer un sort';break;case'pvp':t='Vaincre des joueurs de '+FACTIONS[enemyOf(P.fac)].n;break;case'war':t='Participer à une guerre de faction';break;case'level':t='Atteindre le niveau '+n;break;default:t=o.k;}
  return{t,pr,n,done:pr>=n};}

/* ---------- primes du tableau ---------- */
function genBounties(){const out=[],maps=[mapForLevel(P.lvl,P.fac),mapForLevel(Math.min(50,P.lvl+4),P.fac)];
  for(let k=0;k<3;k++){const mid=maps[k%2],d=MAPS[mid],mons=d.mons.filter(x=>!MT[x[0]].boss),[ty,,lv]=pick(mons),n=ri(12,20);
    out.push({id:'B'+(Date.now()%1e8)+k,chain:'bounty',giver:'board',lvl:1,t:'Prime : '+plural(MT[ty].n),d:`Contrat signé par le conseil de ${FACTIONS[P.fac].capN} : abattre ${n} ${plural(MT[ty].n)} dans ${d.n}.`,obj:[{k:'kill',m:ty,n}],rew:{xp:Math.max(Math.round(monStats(ty,lv).xp*n*.9),Math.round(xpNeed(P.lvl)*.08)),gold:lv*n*3,honor:5},fin:'Contrat honoré. La prime t’est versée.'});}
  P.qs.board=out;P.qs.bT=600;}
function takeBounty(id){const b=(P.qs.board||[]).find(x=>x.id===id);if(!b)return'Contrat expiré.';if(P.qs.bdefs.length>=3)return'Trois contrats au maximum en même temps.';P.qs.bdefs.push(b);P.qs.board=P.qs.board.filter(x=>x!==b);return qAccept(b.id);}

/* ---------- chroniques ---------- */
function codexAdd(key){if(!P.codex)P.codex={};if(P.codex[key])return false;P.codex[key]=1;return true;}
function codexEntries(){const out=[];for(const k in P.codex){const [t,id]=k.split(':');if(t==='zone'&&MAP_LORE[id])out.push({cat:'Lieux',t:MAPS[id].n,x:MAP_LORE[id]});else if(t==='stele'&&STELE_LORE[id])out.push({cat:'Stèles',t:'Stèle de '+MAPS[id].n,x:STELE_LORE[id]});else if(t==='main'&&QDB[id])out.push({cat:'Campagne',t:tok(QDB[id].t),x:tok(QDB[id].fin)});}return out;}
let codexTotal=()=>Object.keys(MAP_LORE).length+Object.keys(STELE_LORE).length+MAIN.length;
function onEnterMap(){const id=M.kind==='dungeon'?null:M.id;if(id&&MAP_LORE[id]&&codexAdd('zone:'+id))chat(null,'Chroniques : '+MAP_LORE[id]);}
function readStele(s){const first=codexAdd('stele:'+s.map);if(first){const x=Math.round(xpNeed(P.lvl)*.06);gainXp(Math.round(x*xpMult()));}qEvent('read',s.map);openPanel('lore',{t:'Stèle de '+MAPS[s.map].n,x:STELE_LORE[s.map],first});}
