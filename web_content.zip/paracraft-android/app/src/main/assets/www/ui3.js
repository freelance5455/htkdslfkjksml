'use strict';
/* ================== Paracraft Online · interface « ciel » ==================
   Fenêtres claires bleu lavande à onglet violet, rail d'icônes à gauche, bouton rond de fermeture,
   écrans d'entrée plein écran (serveur, royaume, personnages, classe, apparence, nom),
   HUD à icônes, tiroir Menu, présence quotidienne, carte à fil d'Ariane, communauté, chat en barre. */

/* ---------- icônes supplémentaires ---------- */
Object.assign(ICO_UI,{
  chron:g=>{I.r(g,3,2,10,12,'#8a5a2a');I.r(g,4,3,8,10,'#f4ead0');I.r(g,3,2,2,12,'#5a3a1a');for(const y of [5,7,9])I.r(g,6,y,5,1,'#8a7a5a');},
  pet:g=>{I.d(g,8,10,3,'#f0a0b0');for(const [x,y] of [[4,5],[7,3],[10,3],[13,5]])I.d(g,x,y,1,'#f0a0b0');},
  commu:g=>{I.d(g,5,5,3,'#f4ead0');I.r(g,2,9,7,5,'#6a8ac8');I.d(g,11,6,3,'#ffd36a');I.r(g,8,10,7,4,'#c86a8a');I.r(g,4,5,1,1,'#2a2a30');I.r(g,10,6,1,1,'#2a2a30');},
  opts:g=>{for(let a=0;a<8;a++){const x=8+Math.round(Math.cos(a*Math.PI/4)*6),y=8+Math.round(Math.sin(a*Math.PI/4)*6);I.r(g,x-1,y-1,3,3,'#a8acb8');}I.d(g,8,8,5,'#c8ccd4');I.d(g,8,8,2,'#4a4a54');},
  lobby:g=>{for(let i=0;i<6;i++)I.r(g,8-i-1,2+i,2+i*2,1,'#c84a3a');I.r(g,3,8,10,6,'#f4ead0');I.r(g,7,10,3,4,'#8a5a2a');I.r(g,4,9,2,2,'#7fc4f0');I.r(g,11,9,2,2,'#7fc4f0');},
  aide:g=>{I.d(g,8,8,6,'#3a9ae8');I.r(g,6,4,4,2,'#fff');I.r(g,9,5,2,3,'#fff');I.r(g,7,8,2,2,'#fff');I.r(g,7,11,2,2,'#fff');},
  full:g=>{const c='#e8ecf4';I.r(g,1,1,5,2,c);I.r(g,1,1,2,5,c);I.r(g,10,1,5,2,c);I.r(g,13,1,2,5,c);I.r(g,1,13,5,2,c);I.r(g,1,10,2,5,c);I.r(g,10,13,5,2,c);I.r(g,13,10,2,5,c);},
  st_for:g=>ICO_ITEM.sword(g,'#ff8a6a'),st_dex:g=>ICO_ITEM.bow(g,'#9be36a'),st_int:g=>ICO_ITEM.staff(g,'#b07cff'),
  st_con:g=>{const c='#e0464e';I.r(g,3,4,4,3,c);I.r(g,9,4,4,3,c);I.r(g,2,5,12,3,c);I.r(g,3,8,10,2,c);I.r(g,5,10,6,2,c);I.r(g,7,12,2,1,c);I.r(g,4,5,2,1,'#fff');},
  st_sag:g=>{const c='#4b8ef0';for(let i=0;i<6;i++)I.r(g,8-Math.floor(i/2),2+i,1+Math.floor(i/2)*2,1,c);I.d(g,8,10,4,c);I.r(g,6,9,1,2,'#fff');},
  st_crit:g=>{const c='#ffd36a';I.r(g,7,1,2,14,c);I.r(g,1,7,14,2,c);I.r(g,5,5,6,6,c);I.r(g,7,7,2,2,'#fff');},
  st_hit:g=>{I.d(g,8,8,6,'#c83a3a');I.d(g,8,8,4,'#fff');I.d(g,8,8,2,'#c83a3a');},
  st_dodge:g=>{for(const [y,w] of [[4,9],[8,12],[12,7]])I.r(g,2,y,w,2,'#9ad8f0');},
  honneur:g=>{I.line(g,3,3,12,12,'#e8ecf4');I.line(g,12,3,3,12,'#e8ecf4');I.d(g,8,8,4,'#4a5ac8');I.r(g,7,6,2,4,'#ffd36a');}});
const icoSil=(k,col)=>{const s=cnv(16,16);ICO_UI[k](s.getContext('2d'));const g=s.getContext('2d');g.globalCompositeOperation='source-in';g.fillStyle=col;g.fillRect(0,0,16,16);return s;};
function mkPattern(col){const c=cnv(180,180),g=c.getContext('2d');g.imageSmoothingEnabled=false;const ks=['attaque','st_dex','pv','sorts','st_int','event','st_con','carte','st_crit'];
  ks.forEach((k,i)=>{const x=(i%3)*60+(Math.floor(i/3)%2?30:6),y=Math.floor(i/3)*60+8;g.drawImage(icoSil(k,col),x,y,32,32);});return c.toDataURL();}
document.documentElement.style.setProperty('--wpat',`url(${mkPattern('rgba(255,255,255,.42)')})`);
document.documentElement.style.setProperty('--ico-q',`url(${uiIcon('quetes')})`);

/* ---------- petits blocs graphiques ---------- */
const CLS_W={guerrier:'sword',archer:'bow',mage:'staff'};
const clsIcon=k=>icoMake('cls_'+k,g=>ICO_ITEM[CLS_W[k]||'sword'](g,'#e8ecf4'));
const STAT_S={for:'FOR',dex:'DEX',int:'INT',con:'CON',sag:'SAG'},STAT_L={for:'Force',dex:'Dextérité',int:'Intelligence',con:'Constitution',sag:'Sagesse'};
function emblem(f,em,bg){return f==='solarix'
  ?`<g><circle cx="60" cy="64" r="17" fill="${em}"/>${[0,1,2,3,4,5,6,7].map(i=>`<rect x="57" y="30" width="6" height="12" rx="2" fill="${em}" transform="rotate(${i*45} 60 64)"/>`).join('')}<circle cx="60" cy="64" r="9" fill="${bg}" opacity=".35"/></g>`
  :`<g><circle cx="58" cy="64" r="20" fill="${em}"/><circle cx="68" cy="57" r="18" fill="${bg}"/><path d="M84 36l2 6 6 2-6 2-2 6-2-6-6-2 6-2z" fill="${em}"/><path d="M90 74l1.5 4 4 1.5-4 1.5-1.5 4-1.5-4-4-1.5 4-1.5z" fill="${em}"/></g>`;}
function bannerSVG(f){const sol=f==='solarix',c1=sol?'#3f7fe0':'#8a3ab8',c2=sol?'#2a5ab8':'#62288a',em=sol?'#ffd36a':'#eef0ff';
  return`<svg class="banner" viewBox="0 0 120 176" aria-hidden="true"><path d="M8 0H112V142L60 172L8 142Z" fill="${c2}"/><path d="M14 0H106V136L60 162L14 136Z" fill="${c1}"/>
  <path d="M26 0V124M94 0V124" stroke="#fff" stroke-opacity=".55" stroke-width="5"/><path d="M14 112L60 138L106 112V136L60 162L14 136Z" fill="#fff" fill-opacity=".14"/>${emblem(f,em,c1)}
  <path d="M60 96l3 9 9 3-9 3-3 9-3-9-9-3 9-3z" fill="${em}"/><path d="M8 142L60 172L112 142" fill="none" stroke="#c8d0e4" stroke-width="5"/></svg>`;}
const facMini=f=>`<svg viewBox="20 20 80 90" aria-hidden="true">${emblem(f,'#fff',f==='solarix'?'#d83a3a':'#6a3aa8')}</svg>`;
const dia=(inner,col,lab)=>`<span class="dia" style="--dc:${col}" title="${lab||''}"><span>${inner}</span></span>`;
const facDia=f=>dia(facMini(f),f==='solarix'?'#d8463a':'#6a3aa8',FACTIONS[f].n);
const clsDia=k=>dia(`<img src="${clsIcon(k)}" alt="">`,'#5d6788',CLASSES[k].nom);
const sexDia=fem=>dia(`<b>${fem?'♀':'♂'}</b>`,'#8a94b4',fem?'Femme':'Homme');
const REALM_LORE={
  solarix:'Depuis Aurelia, la couronne de Solarix garde les Remparts du Levant. Ses chevaliers jurent de rassembler les éclats du Prisme avant que l’ombre ne les corrompe.',
  umbra:'À Nocthar, les mages d’Umbra lisent les étoiles mortes. Ils veulent les éclats du Prisme pour briser l’ordre de Solarix et rendre le monde libre.'};
let _headC=new Map();function headURL(c){const k=JSON.stringify([c.cls,c.fac,c.look2,!!(c.eq&&c.eq.casque)]);let u=_headC.get(k);if(u)return u;
  const s=humSprite(playerLook(c),3).d[0],n=cnv(s.width,Math.round(s.height*.55)),g=n.getContext('2d');g.imageSmoothingEnabled=false;g.drawImage(s,0,0);u=n.toDataURL();_headC.set(k,u);return u;}

/* ---------- île flottante (écran des personnages) ---------- */
function buildIsle(){const W=200,H=112,c=cnv(W,H),g=c.getContext('2d'),R=mulberry(77);const px=(x,y,w,h,col)=>{g.fillStyle=col;g.fillRect(x|0,y|0,w|0,h|0);};
  const cx=100,top=40;
  for(let y=0;y<56;y++){const t=y/56,hw=Math.round(88*Math.sqrt(1-t*t*.98)*(1-t*.55));px(cx-hw,top+y,hw*2,1,y<10?'#c8722a':y<24?'#8a4a22':y<40?'#6a3618':'#4a2410');
    if(y>=2&&y<10)for(let x=-hw;x<hw;x+=7)px(cx+x+(y%2?3:0),top+y,5,1,'#e0904a');}
  for(let i=0;i<9;i++){const x=cx-60+i*15+R()*6,h=6+R()*14;for(let y=0;y<h;y++)px(x-(h-y)/5,top+44+y,(h-y)/2.5+1,1,'#3a1c0c');}
  for(let y=-26;y<=12;y++){const t=y/26,hw=Math.round(96*Math.sqrt(Math.max(0,1-(y<0?t*t:(y/12)**2))));px(cx-hw,top+y,hw*2,1,y>9?'#4a8a2a':y<-22?'#a8e05a':'#7ec83a');}
  for(let i=0;i<70;i++){const a=R()*6.28,r=R(),x=cx+Math.cos(a)*r*86,y=top-6+Math.sin(a)*r*16;px(x,y,2,1,R()<.5?'#6ab830':'#94d84a');}
  const st=[[-30,-6],[-16,-4],[-2,-5],[12,-4],[26,-6],[-22,2],[-8,3],[6,2],[20,3],[-36,-12],[34,-12]];for(const [x,y] of st){px(cx+x,top+y,12,6,'#9aa0aa');px(cx+x,top+y,12,2,'#d8dce4');px(cx+x+1,top+y+5,10,1,'#6a707a');}
  px(cx-8,top-34,26,14,'#7a4a24');px(cx-10,top-24,30,6,'#5a3418');g.fillStyle='#c88a4a';g.beginPath();g.ellipse(cx+5,top-34,13,4,0,0,7);g.fill();g.strokeStyle='#7a4a24';g.beginPath();g.ellipse(cx+5,top-34,7,2,0,0,7);g.stroke();
  px(cx-70,top-30,14,22,'#7a8494');px(cx-70,top-30,14,3,'#a8b0bc');g.strokeStyle='#4a5464';g.beginPath();g.arc(cx-63,top-18,4,0,5);g.stroke();
  px(cx+56,top-26,4,16,'#9aa0aa');px(cx+52,top-28,12,4,'#b8bec8');px(cx+66,top-20,8,3,'#9aa0aa');
  for(let i=0;i<14;i++){const a=R()*6.28,r=.3+R()*.65,x=cx+Math.cos(a)*r*84,y=top-4+Math.sin(a)*r*15;px(x,y,2,2,'#fff');px(x,y+2,1,1,'#f0c040');}
  px(cx-24,top-14,4,3,'#c83a3a');px(cx-20,top-12,4,3,'#c83a3a');px(cx+44,top+6,10,3,'#5a3418');
  return c.toDataURL();}
let _isle=null;

/* ---------- écrans d'entrée ---------- */
const SCRS=['sLogin','sServer','sRealm','sMain','sNew','sStats'];
scr=function(id){for(const s of SCRS)$('#'+s).hidden=s!==id;$('#start').classList.toggle('login',id==='sLogin');$('#start').dataset.s=id;$('#nmModal').hidden=true;};
const _showLogin3=showLogin;showLogin=function(){_showLogin3();$('#sRealm').hidden=true;$('#start').dataset.s='sLogin';};
showServers=function(){scr('sServer');$('#srvList').innerHTML=SERVERS.map((s,i)=>`<button class="srv ${i===selServer?'on':''}" data-i="${i}" type="button"><i class="orb g"></i><b>${esc(s.n)}</b><em class="nbadge">Nouveau</em><small>${esc(s.d)}</small></button>`).join('');};
function showRealm(){scr('sRealm');$('#rlCards').innerHTML=Object.entries(FACTIONS).map(([k,f])=>`<button class="rlhalf ${k} ${cr.fac===k?'on':''}" data-f="${k}" type="button"><span class="rlcard">${bannerSVG(k)}<b>${esc(f.n)}</b><em>Royaume de ${esc(f.capN)}</em><hr><span class="rltxt">${esc(REALM_LORE[k])}</span></span></button>`).join('');}
$('#rlCards').addEventListener('click',e=>{const b=e.target.closest('.rlhalf');if(!b)return;if(cr.fac===b.dataset.f){showCreate();return;}cr.fac=b.dataset.f;showRealm();});
$('#rlOk').onclick=()=>showCreate();$('#rlBack').onclick=()=>showChars();$('#chBack').onclick=()=>showServers();$('#bBack').onclick=()=>showRealm();$('#bNew').onclick=showRealm;
let chSel=0,chDelArm=false;
showChars=function(){scr('sMain');$('#srvName').textContent=SERVERS[selServer].n;if(chSel>=MAX_CHARS)chSel=0;if(!_isle)_isle=buildIsle();$('#chIsle').src=_isle;
  let h='';for(let i=0;i<MAX_CHARS;i++){const c=CHARS[i];h+=`<button class="slot ${i===chSel?'on':''} ${c?'':'empty'}" data-i="${i}" type="button" aria-label="${c?esc(c.name):'Emplacement libre'}">${c?`<img src="${headURL(c)}" alt=""><i>${c.lvl}</i>`:'<b>+</b>'}</button>`;}
  $('#charList').innerHTML=h;const c=CHARS[chSel],hero=$('#chHero');
  if(c){hero.src=lookURL(playerLook(c),5);hero.hidden=false;$('#chInfo').innerHTML=`<div class="chcard"><b>${esc(c.name)}${c.hc?' <span class="hc">HC</span>':''}</b><span>${CLASSES[c.cls].nom} · niveau ${c.lvl}</span><span style="color:${FACTIONS[c.fac].c}">${esc(FACTIONS[c.fac].n)} · ${esc(FACTIONS[c.fac].capN)}</span></div>`;}
  else{hero.hidden=true;$('#chInfo').innerHTML='<div class="newband">NOUVEAU PERSONNAGE</div>';}
  $('#chEnter').textContent=c?'Entrer':'Créer';$('#chDel').hidden=!c;$('#chDel').textContent=chDelArm?'Confirmer ?':'Supprimer';$('#chDel').classList.toggle('red',chDelArm);};
$('#charList').addEventListener('click',e=>{const b=e.target.closest('.slot');if(!b)return;const i=+b.dataset.i;chDelArm=false;if(i===chSel&&!CHARS[i]){showRealm();return;}chSel=Math.min(i,CHARS.length);showChars();});
$('#chEnter').onclick=()=>{goLandscape();if(CHARS[chSel])startGame(chSel);else showRealm();};
$('#chDel').onclick=()=>{if(!CHARS[chSel])return;if(chDelArm){CHARS.splice(chSel,1);saveJSON(CHAR_KEY,CHARS);chDelArm=false;chSel=Math.max(0,Math.min(chSel,CHARS.length-1));}else chDelArm=true;showChars();};
$('#srvOk').onclick=()=>{chSel=0;showChars();};
/* classe */
buildCreate=function(){const C=CLASSES[cr.cls];
  $('#crOpts').innerHTML=Object.keys(CLASSES).map(k=>`<button class="copt dbtn ${cr.cls===k?'on':''}" data-g="cls" data-v="${k}" type="button" aria-label="${CLASSES[k].nom}"><span><img src="${clsIcon(k)}" alt=""></span></button>`).join('');
  const lk=(fem,hs,hc)=>playerLook({cls:cr.cls,fac:cr.fac,look2:{fem,hs,hc,sk:1},eq:{casque:1}});
  $('#clsArt').innerHTML=`<img class="a1" src="${lookURL(lk(0,'spiky',3),9)}" alt=""><img class="a2" src="${lookURL(lk(1,'long',2),9)}" alt="">`;
  $('#crPrev').src=lookURL(crLook(),3);$('#clsDia').innerHTML=facDia(cr.fac)+clsDia(cr.cls);
  $('#crInfo').innerHTML=`<h3>${C.nom}</h3><em>${esc(C.role)}</em><hr><p>${esc(C.desc)}</p><p class="rec">Stats conseillées : ${STAT_S[C.prio[0]]} / ${STAT_S[C.prio[1]]}</p>`;};
$('#crNext').onclick=()=>showStats();
/* apparence + caractéristiques */
showStats=function(){scr('sStats');const C=CLASSES[cr.cls],copt=(g,v,inner,on,lab)=>`<button class="copt ${on?'on':''}" data-g="${g}" data-v="${v}" type="button" aria-label="${lab||''}">${inner}</button>`;
  const head=hs=>{const L=Object.assign({},crLook(),{hairStyle:hs,extra:'none',weapon:'none'});const s=humSprite(L,3).d[0],n=cnv(s.width,Math.round(s.height*.5));n.getContext('2d').drawImage(s,0,0);return`<img src="${n.toDataURL()}" alt="">`;};
  $('#stLook').innerHTML=`<div class="wsec">✂ Coiffure</div><div class="lrow">${(cr.fem?HAIR_F:HAIR_M).map(([k,n])=>copt('hs',k,head(k),cr.hs===k,n)).join('')}</div>
   <div class="wsec">💧 Couleur des cheveux</div><div class="lrow">${HAIR_C.map((c,i)=>copt('hc',i,`<i class="drop" style="--c:${c}"></i>`,cr.hc===i,'Couleur '+(i+1))).join('')}</div>
   <div class="wsec">✋ Peau</div><div class="lrow">${SKIN_C.map((c,i)=>copt('sk',i,`<i class="drop" style="--c:${c}"></i>`,cr.sk===i,'Peau '+(i+1))).join('')}</div>`;
  $('#stSex').innerHTML=copt('fem',0,'<span>♂</span>',!cr.fem,'Homme').replace('copt','copt dbtn')+copt('fem',1,'<span>♀</span>',!!cr.fem,'Femme').replace('copt','copt dbtn');
  $('#stPrev').src=lookURL(crLook(),5);$('#stDia').innerHTML=facDia(cr.fac)+clsDia(cr.cls)+sexDia(cr.fem);
  $('#stRows').innerHTML=STATS5.map(k=>{const rk=C.prio[0]===k?'<em class="rk">1er</em>':C.prio[1]===k?'<em class="rk">2e</em>':'<em class="rk none"></em>';
    return`<div class="srow" title="${esc(STATD[k])}">${rk}<span class="sic"><img src="${uiIcon('st_'+k)}" alt=""></span><b>${STAT_L[k]}</b><span class="step"><button class="arr" data-k="${k}" data-d="-1" type="button" aria-label="Retirer" ${cr.al[k]<=0?'disabled':''}>−</button><span class="sv ${cr.al[k]?'up':''}">${C.base[k]+cr.al[k]}</span><button class="arr" data-k="${k}" data-d="1" type="button" aria-label="Ajouter" ${crLeft()<=0?'disabled':''}>+</button></span></div>`;}).join('')+`<div class="spts">Points<b>${crLeft()}</b></div>`;
  $('#hcTog').setAttribute('aria-pressed',cr.hc2);$('#hcTog').textContent=cr.hc2?'☠ Hardcore : activé':'Hardcore : désactivé';};
$('#sStats').addEventListener('click',e=>{const b=e.target.closest('.copt');if(!b)return;const g=b.dataset.g;let v=b.dataset.v;if(g!=='hs')v=+v;cr[g]=v;if(g==='fem')cr.hs=v?'long':'short';showStats();});
$('#stOk').onclick=()=>{$('#nmModal').hidden=false;$('#nameIn').value=cr.name||'';$('#nameMsg').textContent='';setTimeout(()=>$('#nameIn').focus(),30);};
$('#nmCancel').onclick=()=>{$('#nmModal').hidden=true;};
$('#nameIn').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();$('#nmOk').click();}});
$('#nmOk').onclick=()=>{const name=($('#nameIn').value||'').replace(/\s+/g,' ').trim().slice(0,14),m=t=>{$('#nameMsg').textContent=t;};
  if(name.length<3)return m('Le nom doit faire au moins 3 caractères.');if(!/^[A-Za-z0-9À-ÿ' -]+$/.test(name))return m('Lettres, chiffres, espaces, apostrophes et tirets seulement.');
  if(CHARS.some(c=>c.name.toLowerCase()===name.toLowerCase()))return m('Ce nom est déjà pris.');if(CHARS.length>=MAX_CHARS)return m(MAX_CHARS+' personnages maximum.');
  goLandscape();cr.name=name;const c=newChar(cr.name,cr.cls,cr.fac,cr.hc2);c.look2={fem:cr.fem,hs:cr.hs,hc:cr.hc,sk:cr.sk};for(const k of STATS5)c.al[k]=cr.al[k];c.pts=crLeft();
  CHARS.push(c);saveJSON(CHAR_KEY,CHARS);cr.name='';cr.al={for:0,dex:0,int:0,con:0,sag:0};chSel=CHARS.length-1;$('#nmModal').hidden=true;startGame(CHARS.length-1);};

/* ---------- présence quotidienne (par compte) ---------- */
const MOIS=['janvier','février','mars','avril','mai','juin','juillet','août','septembre','octobre','novembre','décembre'];
const CI_DAY=[['pv',5],['or',400],['ench1',1],['pm',5],['retour',3],['elxp',1],['parch',2],['pv',5],['or',600],['ench1',2],['pm',5],['plat2',3],['elatk',1],['ench2',1],['pv',8],['or',800],['ench1',2],['pm',8],['plat4',2],['elxp',2],['parch',3],['pv',10],['or',1200],['ench1',3]];
const CI_FINAL=[['ench2',2],['or',3000]];
const ciKey=()=>CHAR_KEY.replace('paracraft_chars','paracraft_ci');
const dayStr=d=>d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
function ciState(){const now=new Date(),m=dayStr(now).slice(0,7);let s=loadJSON(ciKey(),null);if(!s||s.m!==m)s={m,n:0,last:''};return s;}
const ciCan=()=>{const s=ciState();return s.n<25&&s.last!==dayStr(new Date());};
const rwIcon=k=>k==='or'?uiIcon('or'):consIcon(k),rwName=k=>k==='or'?'Or':CONS[k]?CONS[k].n:k;
function ciGive(list){let need=0;for(const [k,n] of list)if(k!=='or')need+=roomFor('cons',k,n);if(invUsed()+need>invCap())return false;
  for(const [k,n] of list){if(k==='or')P.gold+=n;else P.cons[k]=(P.cons[k]||0)+n;}return true;}
EXTRA_ACT.ciclaim=()=>{if(!ciCan()){panelMsg='Déjà récupéré aujourd’hui. Reviens demain !';return;}const s=ciState(),d=s.n+1,list=d===25?CI_FINAL:[CI_DAY[d-1]];
  if(!ciGive(list)){panelMsg='Sac plein : libère de la place pour récupérer la récompense.';return;}s.n=d;s.last=dayStr(new Date());saveJSON(ciKey(),s);
  panelMsg=`Jour ${d} récupéré : ${list.map(([k,n])=>n+' × '+rwName(k)).join(' et ')}.`;toast('Présence du jour',list.map(([k,n])=>n+' × '+rwName(k)).join(', '));save();};
EXTRA_ACT.cimode=v=>{panelData=Object.assign({},panelData||{},{ci:+v});};
function timeLeftMonth(){const n=new Date(),e=new Date(n.getFullYear(),n.getMonth()+1,1),ms=e-n,d=Math.floor(ms/864e5),h=Math.floor(ms%864e5/36e5),mi=Math.floor(ms%36e5/6e4);return`${d} j ${h} h ${mi} min`;}
function presencePanel(){const s=ciState(),now=new Date(),mo=MOIS[now.getMonth()],can=ciCan(),mode=panelData.ci;
  let h=CLOSE+'<h2>Événement</h2><div class="ev2"><div class="evside">'+
   `<button class="evcard ${mode===1?'on':''}" data-a="cimode" data-v="1" type="button"><b>Présence de ${mo}</b><small>25 jours · ${s.n}/25 récupérés</small><small>Fin dans ${timeLeftMonth()}</small></button>`+
   `<button class="evcard alt ${mode===2?'on':''}" data-a="cimode" data-v="2" type="button"><b>Événements du royaume</b><small>Hot Time, saisons, champ de bataille</small></button></div><div class="evmain">`;
  if(mode===1){h+=`<div class="evtop"><b>${mo[0].toUpperCase()+mo.slice(1)} : la Route de l’aventure</b><span class="evtime">Temps restant : ${timeLeftMonth()}</span></div><div class="cigrid">`;
    for(let d=1;d<=24;d++){const [k,n]=CI_DAY[d-1],row=d<=14?Math.ceil(d/7):3+Math.floor((d-15)/5),col=d<=14?(d-1)%7+1:(d-15)%5+1,got=d<=s.n,today=can&&d===s.n+1,next=d===s.n+(can?2:1);
      h+=`<div class="ciday ${got?'got':''} ${today?'today':''} ${d%7===0?'spec':''}" style="grid-row:${row};grid-column:${col}" title="${n} × ${esc(rwName(k))}"><i>${d}</i>${today?'<em class="rib r">AUJOURD’HUI</em>':next?'<em class="rib o">ENSUITE</em>':''}<img src="${rwIcon(k)}" alt=""><span>×${n}</span>${got?'<b class="ck">✔</b>':''}</div>`;}
    const fg=s.n>=25,ft=can&&s.n===24;
    h+=`<div class="ciday final ${fg?'got':''} ${ft?'today':''}" style="grid-row:3 / 5;grid-column:6 / 8"><i>25</i><em class="ribbon2">Récompense finale</em><div class="fin">${CI_FINAL.map(([k,n])=>`<span><img src="${rwIcon(k)}" alt="">×${n}</span>`).join('')}</div>${fg?'<b class="ck">✔</b>':''}</div></div>`;
    h+=`<div class="evfoot"><small>La présence se récupère une fois par jour et par compte, pour le personnage connecté.</small><button class="wbtn blue" data-a="ciclaim" type="button" ${can?'':'disabled'}>${can?'Tout récupérer':'Revenir demain'}</button></div>`;}
  else{const S=season(),A=typeof anniv==='function'?anniv():null,ht=hotTime();
    h+=`<div class="evtop"><b>Événements du royaume</b><span class="evtime">${ht?'Hot Time en cours':'Prochain Hot Time dans '+Math.floor(nextHot()/60)+' h '+String(nextHot()%60).padStart(2,'0')}</span></div><div class="evlist">`+
     [[uiIcon('event'),'Hot Time','Chaque jour de 12 h à 13 h et de 20 h à 22 h : expérience +50 % et butin plus généreux.'],
      [uiIcon('honneur'),'Champ de bataille 10 contre 10','Inscription auprès du héraut des événements, dans n’importe quelle ville de '+FACTIONS[P.fac].n+'.'],
      [uiIcon('guilde'),'Sièges et monuments','Les guildes se disputent les monuments des zones contestées. La guilde qui tient un monument lève la taxe.'],
      [uiIcon('st_crit'),S?S.n:'Saison',S?'Saison en cours : butin et monnaie de saison sur tous les monstres.':'Aucune saison en cours pour le moment.'],
      [uiIcon('chron'),A?'Anniversaire':'Lettres d’anniversaire',A?'Les lettres d’anniversaire tombent des monstres. Échange-les auprès du héraut.':'Pas d’anniversaire en ce moment.']]
      .map(([ic,t,d])=>`<div class="evli"><span class="hic"><img src="${ic}" alt=""></span><div><b>${esc(t)}</b><small>${esc(d)}</small></div></div>`).join('')+'</div>';}
  return h+`</div></div><p class="msg">${panelMsg}</p>`;}
const _evPanel=EXTRA_PANELS.event;EXTRA_PANELS.event=function(...a){return panelData&&panelData.ci?presencePanel():_evPanel(...a);};

/* ---------- statut ---------- */
function persoPanel(){const s=stats(),c=CLASSES[P.cls],fac=FACTIONS[P.fac],need=xpNeed(P.lvl),pct=Math.min(1,P.xp/need),lk=P.look2||{};
  let h=CLOSE+'<h2>Statut</h2><div class="stat2"><div class="stcard"><div class="dias">'+facDia(P.fac)+clsDia(P.cls)+sexDia(lk.fem)+`</div><div class="ped big"><img src="${lookURL(P.look,5)}" alt=""></div><div class="ribbon">${esc(fac.full)}</div><p>${esc(REALM_LORE[P.fac])}</p></div><div class="stside">`;
  h+=`<div class="sthead"><b>${esc(honorRank(P.honor))} ${esc(P.name)}</b>${P.hc?' <span class="hc">HARDCORE</span>':''}<div class="lvrow"><span class="lv">Niv ${P.lvl}</span><span>${P.xp.toLocaleString('fr-FR')} / ${need.toLocaleString('fr-FR')}</span></div><div class="xpb"><i style="width:${(pct*100).toFixed(1)}%"></i></div></div>`;
  h+=`<div class="wbox"><div class="wboxh"><span>Caractéristiques</span><span class="pts ${P.pts?'on':''}">Points : <b>${P.pts}</b></span></div><div class="g5">`+STATS5.map(st=>`<div class="sl"><img src="${uiIcon('st_'+st)}" alt=""><em>${STAT_S[st]}</em><b>${s.a[st]}</b>${st===c.prio[0]?'<i class="rk">1er</i>':st===c.prio[1]?'<i class="rk">2e</i>':''}${P.pts?`<span class="al">${B('alloc','+1',`data-v="${st}" data-n="1"`)}${P.pts>=5?B('alloc','+5',`data-v="${st}" data-n="5"`):''}</span>`:''}</div>`).join('')+'</div></div>';
  const v=[['PV',Math.ceil(P.hp)+' / '+s.maxhp],['PM',Math.floor(P.mp)+' / '+s.maxmp],['Mêlée',Math.round(s.melee)],['Distance',Math.round(s.ranged)],['Magie',Math.round(s.matk)],['Défense',s.def],['Précision',s.hit.toFixed(1)+' %'],['Critique',s.crit.toFixed(1)+' %'],['Esquive',s.dodge.toFixed(1)+' %'],['Vit. d’attaque',Math.round((1/s.aspd)*100)+' %'],['Zone',Math.round(s.aoe*100)+' %'],['Contrôle',Math.round(s.ctl*100)+' %'],['Soins',Math.round(s.heal*100)+' %'],['Poids',invWeight()+' / '+s.pods+' kg'],['Bonus d’XP','+'+Math.round((xpMult()-1)*100)+' %'],['Honneur',P.honor]];
  h+=`<div class="wbox"><div class="wboxh"><span>Valeurs de combat</span><button class="phelp sm" data-a="help" type="button" aria-label="Explications">?</button></div><div class="cgrid">${v.map(([a,b])=>`<div><span>${a}</span><b>${b}</b></div>`).join('')}</div></div>`;
  return h+'</div></div>'+`<p class="msg">${panelMsg}</p>`;}

/* ---------- sorts : préréglages, arc de raccourcis, grille ---------- */
EXTRA_ACT.preset=v=>{const j=+v;P.barSets=P.barSets||[0,1,2,3,4].map(()=>P.bar.slice());P.barSets[P.barSet||0]=P.bar.slice();P.barSet=j;P.bar=P.barSets[j].slice();setSkillLabels();panelMsg='Préréglage '+(j+1)+' chargé.';};
sortsPanel=function(){const c=CLASSES[P.cls];if(!/^\d+$/.test(String(panelTab))||!c.sk[+panelTab])panelTab='0';const i=+panelTab,sk=c.sk[i],rk=skRank(i),bk='livre_'+P.cls+'_'+i,have=P.cons[bk]||0,R3=a=>Array.isArray(a)?a.join(' / '):a;
  const books=Object.keys(P.cons).filter(k=>k.startsWith('livre_'+P.cls+'_')&&P.cons[k]>0).reduce((a,k)=>a+P.cons[k],0),bs=P.barSet||0;
  let h=CLOSE+'<h2>Sorts</h2><div class="sk2"><div class="skl"><div class="presets">'+[0,1,2,3,4].map(j=>`<button class="wnum ${bs===j?'on':''}" data-a="preset" data-v="${j}" type="button">${j+1}</button>`).join('')+'</div><div class="arc">';
  const ang=[205,168,131,94,57,20];for(let j=0;j<6;j++){const x=c.sk[P.bar[j]],a=ang[j]*Math.PI/180;
    h+=`<button class="aslot ${x&&P.bar[j]===i?'on':''}" style="left:${(50+40*Math.cos(a)).toFixed(1)}%;top:${(54-40*Math.sin(a)).toFixed(1)}%" data-a="bar" data-v="${j}" data-s="${i}" type="button" ${rk?'':'disabled'} aria-label="Case ${j+1}">${x?`<img src="${spellIcon(P.cls,x)}" alt="">`:'<b>+</b>'}<i>${j+1}</i></button>`;}
  h+=`<span class="arcmid"><img src="${uiIcon('attaque')}" alt=""></span></div><div class="skpts">Grimoires en main<b>${books}</b></div></div><div class="skr"><div class="skrh"><img src="${uiIcon('sorts')}" alt=""> Sorts de ${c.nom}</div><div class="skgrid">`;
  c.sk.forEach((x,j)=>{const r=skRank(j),own=P.cons['livre_'+P.cls+'_'+j]>0;h+=`<button class="skb ${j===i?'on':''} ${r?'':'locked'}" data-a="spsel" data-v="${j}" type="button" aria-label="${esc(x.n)}"><span class="ring"><img src="${spellIcon(P.cls,x)}" alt="">${own&&r<3?'<em>!</em>':''}</span><span class="pips">${[0,1,2].map(q=>`<i class="${q<r?'on':''}"></i>`).join('')}</span><small>${r?esc(x.s):'niv. '+x.lv}</small></button>`;});
  h+=`</div><div class="skdet"><img src="${spellIcon(P.cls,sk)}" alt=""><div><b>${esc(sk.n)}</b> <small class="num">niv. ${sk.lv} · ${rk?'rang '+rk+'/3':'non appris'}</small><p>${esc(skillDesc(sk,Math.max(1,rk)))}</p><small>PM ${R3(sk.mp)} · recharge ${R3(sk.cd)} s · ${i===0?'sort inné':'grimoire : '+esc(c.src[i])}</small>`;
  if(have&&rk<3)h+=`<p>${B('learn',rk?'Lire le grimoire : rang '+(rk+1):'Apprendre '+esc(sk.n),`data-v="${bk}"`,'go')} <span class="why">${have} en main</span></p>`;
  h+=`${rk?'<p class="hint">Touche une case de l’arc pour y placer ce sort.</p>':''}</div></div></div></div><p class="msg">${panelMsg}</p>`;return h;};
SAVE_FIELDS.push('barSets','barSet');

/* ---------- carte : continent, zone, donjons ---------- */
const BIO_C={meadow:'#8ed05a',hills:'#76b44a',forest:'#3f8a3a',steppe:'#c8b870',moon:'#7a8ac8',vale:'#5ab88a',swamp:'#5a8a6a',desert:'#ecc878',ash:'#6a5a5a',abyss:'#3a2a4a'};
let _cont=null;function contImg(){if(_cont)return _cont;const CW=72,CH=60,W=11*CW,H=5*CH,c=cnv(W,H),g=c.getContext('2d'),R=mulberry(9);
  g.fillStyle='#5aa8e0';g.fillRect(0,0,W,H);for(let i=0;i<260;i++){g.fillStyle=R()<.5?'#6ab4e8':'#4e9cd6';g.fillRect(R()*W|0,R()*H|0,6+R()*10|0,2);}
  const ctr=id=>{const [x,y]=WORLD_LAYOUT[id];return[x*CW+CW/2,y*CH+CH/2];};
  for(const [id] of Object.entries(WORLD_LAYOUT)){const [x,y]=ctr(id),d=MAPS[id],col=d.kind==='city'?(d.side==='solarix'?'#f0dca0':'#b8a8d8'):BIO_C[d.biome]||'#8ed05a';
    g.fillStyle='#e8d8a8';g.beginPath();g.ellipse(x,y+3,CW*.52,CH*.46,0,0,7);g.fill();g.fillStyle=col;g.beginPath();g.ellipse(x,y,CW*.5,CH*.42,0,0,7);g.fill();
    for(let k=0;k<14;k++){const a=R()*6.28,r=R()*.8,px=x+Math.cos(a)*r*CW*.45,py=y+Math.sin(a)*r*CH*.36;
      if(d.biome==='forest'||d.biome==='vale'||d.biome==='hills'){g.fillStyle=d.biome==='forest'?'#2a6a2a':'#4a9a3a';g.beginPath();g.moveTo(px,py-6);g.lineTo(px-4,py+3);g.lineTo(px+4,py+3);g.fill();}
      else if(d.biome==='ash'||d.biome==='abyss'){g.fillStyle=R()<.3?'#ff7a3a':'#4a3a3a';g.fillRect(px,py,3,3);}else if(d.biome==='desert'){g.fillStyle='#c8a050';g.fillRect(px,py,4,2);}
      else if(d.biome==='swamp'||d.biome==='moon'){g.fillStyle='rgba(60,120,150,.7)';g.fillRect(px,py,6,3);}}
    if(d.kind==='city'){const cc=d.side==='solarix'?'#e8ecf4':'#5a4a78';g.fillStyle=cc;g.fillRect(x-14,y-10,28,16);for(let t=-14;t<14;t+=6)g.fillRect(x+t,y-14,4,4);g.fillRect(x-4,y-22,8,12);g.fillStyle=d.side==='solarix'?'#3f7fe0':'#c09aff';g.fillRect(x-1,y-28,2,6);g.fillRect(x+1,y-28,6,3);g.fillStyle='#4a3a2a';g.fillRect(x-3,y,6,6);}}
  g.setLineDash([4,4]);g.lineWidth=2;g.strokeStyle='#fff6dc';for(const [id] of Object.entries(WORLD_LAYOUT))for(const to of Object.values(MAPS[id].ex||{})){if(!WORLD_LAYOUT[to])continue;const [a,b]=ctr(id),[x2,y2]=ctr(to);g.beginPath();g.moveTo(a,b);g.lineTo(x2,y2);g.stroke();}
  _cont={url:c.toDataURL(),W,H,CW,CH};return _cont;}
const _thumbs=new Map();function mapThumb(m){const key=m.id+':'+m.canvas.width;let t=_thumbs.get(key);if(t)return t;const W=m.canvas.width,H=m.canvas.height,sc=Math.min(520/W,360/H),c=cnv(Math.round(W*sc),Math.round(H*sc)),g=c.getContext('2d');
  g.drawImage(m.canvas,0,0,c.width,c.height);try{for(const row of m.props||[])if(row)for(const p of row){const S=PROPS[p.k];if(S)g.drawImage(S.c,(p.x-S.w/2)*sc,(p.y-S.h)*sc,S.w*sc,S.h*sc);}}catch(_){}
  t={url:c.toDataURL(),W,H};if(m.kind!=='dungeon')_thumbs.set(key,t);return t;}
EXTRA_ACT.mapz=v=>{panelData=Object.assign({},panelData||{},{z:v});};
function mapPanel(){const v=panelTab=panelTab||'zone',here=dgRun?dgRun.ret.map:P.map,zn=(M&&M.def&&M.def.n)||(MAPS[curId()]||{}).n||curId();
  let h=CLOSE+'<h2>Carte</h2><div class="map2"><div class="mapside">'+`<button class="wpill ${v==='cont'?'on':''}" data-a="tab" data-v="cont" type="button">Région</button><button class="wpill ${v==='zone'?'on':''}" data-a="tab" data-v="zone" type="button">Ici</button><button class="dgbtn ${v==='dg'?'on':''}" data-a="tab" data-v="dg" type="button"><img src="${uiIcon('lobby')}" alt=""><span>Donjons</span></button></div><div class="mapmain">`;
  h+=`<nav class="crumbs"><button data-a="tab" data-v="cont" type="button" class="${v==='cont'?'cur':''}">Monde d’Éther</button><button data-a="tab" data-v="cont" type="button" class="${v==='cont'?'cur':''}">Continent du Prisme</button>${v==='zone'?`<button type="button" class="cur" data-a="tab" data-v="zone">${esc(zn)}</button>`:v==='dg'?'<button type="button" class="cur">Donjons</button>':''}</nav>`;
  if(v==='cont'){const C=contImg(),sel=(panelData&&panelData.z)||here;
    h+=`<div class="contwrap"><div class="cont"><img src="${C.url}" alt="Carte du continent">`+Object.entries(WORLD_LAYOUT).map(([id,[x,y]])=>{const d=MAPS[id];return`<button class="zlab ${id===here?'here':''} ${id===sel?'sel':''}" style="left:${Math.min(94,Math.max(5,(x+.5)/11*100)).toFixed(2)}%;top:${((y+.5+(y===1?(x%2?-.36:.36):.3))/5*100).toFixed(2)}%" data-a="mapz" data-v="${id}" type="button">${id===here?'<i class="pin"></i>':''}<span>${esc(d.n)}</span></button>`;}).join('')+'</div>';
    const d=MAPS[sel];h+=`<div class="zinfo"><b>${esc(d.n)}</b><small>${d.kind==='city'?'Capitale de '+FACTIONS[d.side].n:'Niveaux '+d.lv[0]+' à '+d.lv[1]}${d.pvp?' · zone contestée, PvP':d.side?' · territoire '+(d.side===P.fac?'allié':'ennemi'):''}${d.wb?' · boss de monde : '+esc(MT[d.wb[0]].n):''}${d.dungeon?' · donjon':''}</small></div></div>`;}
  else if(v==='zone'){const t=mapThumb(M),pin=(o,cls,lab)=>`<i class="${cls}" style="left:${(o.x/t.W*100).toFixed(2)}%;top:${(o.y/t.H*100).toFixed(2)}%" title="${esc(lab||'')}"></i>`;
    h+=`<div class="zonewrap"><div class="zmap"><img src="${t.url}" alt="Carte de ${esc(zn)}">${(M.npcs||[]).map(n=>pin(n,'mnpc',n.n)).join('')}${pin(P,'mme','Toi')}</div><div class="zlist"><b class="zt">${esc(zn)}</b><div class="zpos"><i class="pin"></i>Position actuelle<b>${Math.round(P.x/TS)},${Math.round(P.y/TS)}</b></div><ul>${(M.npcs||[]).map(n=>`<li><span class="face"></span>${esc(n.n)}<small>${esc(n.r||'')}</small></li>`).join('')||'<li class="none">Aucun habitant ici.</li>'}</ul></div></div>`;}
  else{h+='<div class="dglist">'+Object.values(DUNGEONS).map(d=>`<div class="dgi"><img src="${uiIcon('lobby')}" alt=""><div><b>${esc(d.n)}</b><small>Niveaux ${d.lv[0]} à ${d.lv[1]} · ${d.floors} étage${d.floors>1?'s':''}${d.boss&&MT[d.boss[0]]?' · boss : '+esc(MT[d.boss[0]].n):''}</small></div></div>`).join('')+'</div>';}
  h+='<p class="sub wbline">Boss de monde : '+Object.entries(WB).map(([k2,w])=>esc(MT[k2].n)+(w.alive?' (en vie)':' dans '+fmtT(w.t))).join(' · ')+'</p>';
  return h+'</div></div>';}

/* ---------- communauté ---------- */
const frKey=()=>CHAR_KEY.replace('paracraft_chars','paracraft_friends');
EXTRA_ACT.fradd=()=>{const inp=$('#frIn'),n=(inp&&inp.value||'').trim(),t=panelTab,D=loadJSON(frKey(),{amis:[],bloq:[]}),L=D[t]=D[t]||[];if(n.length<3){panelMsg='Écris un nom d’au moins 3 caractères.';return;}
  if(L.some(x=>x.toLowerCase()===n.toLowerCase())){panelMsg='Déjà dans ta liste.';return;}if(n.toLowerCase()===P.name.toLowerCase()){panelMsg='C’est toi !';return;}
  if(t==='amis'&&!CHARS.some(c=>c.name.toLowerCase()===n.toLowerCase())){panelMsg=`Aucun aventurier nommé « ${esc(n)} » sur ce serveur.`;return;}if(L.length>=40){panelMsg='Liste pleine (40).';return;}
  L.push(n);saveJSON(frKey(),D);panelMsg=t==='amis'?esc(n)+' ajouté à tes amis.':esc(n)+' bloqué.';};
EXTRA_ACT.frdel=v=>{const D=loadJSON(frKey(),{amis:[],bloq:[]}),L=D[panelTab]||[];const i=L.indexOf(v);if(i>=0){L.splice(i,1);saveJSON(frKey(),D);panelMsg=esc(v)+' retiré.';}};
EXTRA_PANELS.commu=()=>{const t=panelTab=panelTab||'amis',D=loadJSON(frKey(),{amis:[],bloq:[]}),L=D[t]||[];
  let h=CLOSE+'<h2>Communauté</h2><div class="cm2"><div class="cmside">'+[['amis','Amis'],['groupe','Groupe'],['bloq','Bloqués']].map(([k,n])=>`<button class="wpill ${t===k?'on':''}" data-a="tab" data-v="${k}" type="button">${n}</button>`).join('')+'</div>';
  if(t==='groupe'){const mem=party?party.members:[];h+=`<div class="cmmid"><img class="cmart" src="${uiIcon('commu')}" alt=""><div class="cmcount"><b>${party?mem.length+1:0}</b>/5</div><hr>${B('goto','Fenêtre de groupe','data-v="groupe"','wide')}</div><div class="cmlist">${party?['<div class="cmrow"><b>'+esc(P.name)+'</b><small>chef · niv. '+P.lvl+'</small></div>'].concat(mem.map(m=>`<div class="cmrow"><b>${esc(m.n)}</b><small>niv. ${m.lvl||m.lv||'?'}</small></div>`)).join(''):'<p class="cmempty">Aucune information de groupe.</p>'}</div>`;}
  else{h+=`<div class="cmmid"><img class="cmart" src="${uiIcon(t==='amis'?'commu':'pk')}" alt=""><div class="cmcount"><b>${L.length}</b>/40</div><hr><input id="frIn" maxlength="14" placeholder="Nom du personnage" autocomplete="off">${B('fradd',t==='amis'?'Ajouter un ami':'Bloquer','','wide')}</div><div class="cmlist">${L.length?L.map(n=>{const c=CHARS.find(x=>x.name===n);return`<div class="cmrow"><b>${esc(n)}</b><small>${c?CLASSES[c.cls].nom+' · niv. '+c.lvl+' · hors ligne':'bloqué'}</small>${B('frdel','Retirer',`data-v="${esc(n)}"`)}</div>`;}).join(''):'<p class="cmempty">Il n’y a personne dans ta liste.</p>'}</div>`;}
  return h+`</div><p class="msg">${panelMsg}</p>`;};
EXTRA_PANELS.aide=()=>CLOSE+'<h2>Aide</h2><div class="evlist">'+[[uiIcon('attaque'),'Combat','Touche un monstre pour le sélectionner, puis Attaque ou un sort. Il faut être à portée : rien ne se déplace tout seul.'],[uiIcon('sac'),'Butin','Chaque monstre lâche de l’or et parfois un sac. Ramasse-les avec le bouton d’action. Un familier peut ramasser pour toi.'],[uiIcon('chat'),'Chat','Touche Chat pour ouvrir la fenêtre, glisse la poignée pour la redimensionner, touche Chat à nouveau pour la fermer.'],[uiIcon('event'),'Présence','Chaque jour, récupère ta récompense dans Événement. 25 jours par mois, la dernière est la plus belle.'],[uiIcon('perso'),'Clavier','ZQSD pour bouger, Espace pour attaquer, 1 à 6 pour les sorts, E pour interagir, Entrée pour le chat.']].map(([ic,t,d])=>`<div class="evli"><span class="hic"><img src="${ic}" alt=""></span><div><b>${t}</b><small>${d}</small></div></div>`).join('')+'</div>';

/* ---------- aide « ? » des fenêtres ---------- */
const HELP={
  perso:['Valeurs de combat',[['st_for','Force (FOR)','Dégâts au corps à corps et poids que tu peux porter.'],['st_dex','Dextérité (DEX)','Précision, esquive, critiques et dégâts à distance.'],['st_int','Intelligence (INT)','Dégâts des sorts, zone d’effet et durée des contrôles.'],['st_con','Constitution (CON)','Points de vie maximum et défense.'],['st_sag','Sagesse (SAG)','Points de mana maximum, puissance des soins et des buffs.'],['honneur','Honneur','Gagné en battant des joueurs de l’autre faction et sur le champ de bataille.']]],
  sac:['Sac et poids',[['sac','Cases','12 cases de poche, plus les sacs équipés. Un sac percé verrouille ses cases.'],['st_for','Poids','Capacité : 50 + FOR × 2 + CON. À 75 % tu ralentis, à 100 % tu es encombré.'],['pv','Piles','Consommables par 20, ressources par 50.'],['pk','Mort','En zone contestée, une mort peut faire tomber des objets du sac. Le coffre de la banque est sûr.']]],
  sorts:['Sorts et grimoires',[['sorts','Grimoires','Le sort de niveau 1 est inné. Les autres s’apprennent avec un grimoire, puis montent au rang 3 en relisant le livre.'],['attaque','Arc de raccourcis','Choisis un sort dans la grille, puis touche une case de l’arc pour l’y placer.'],['chron','Préréglages','Les boutons 1 à 5 gardent cinq barres différentes : chasse, donjon, PvP…']]],
  carte:['Carte',[['carte','Territoires','Niveaux 1 à 20 : territoires de faction, sans PvP. Au-delà : zones contestées.'],['pk','PvP','Dans les zones contestées, l’autre faction peut t’attaquer.'],['lobby','Donjons','Les donjons à étages se trouvent dans les zones. Leur boss garde les meilleurs grimoires.']]]};
let helpOn=null;EXTRA_ACT.help=()=>{helpOn=panelKind;};EXTRA_ACT.helpx=()=>{helpOn=null;};
function helpPop(k){const [t,L]=HELP[k];return`<div class="wpop"><div class="wdlg"><div class="whead">${t}</div><div class="hgrid">${L.map(([ic,a,d])=>`<div class="hit"><span class="hic"><img src="${uiIcon(ic)}" alt=""></span><div><b>${a}</b><small>${d}</small></div></div>`).join('')}</div><div class="wfoot"><button class="wbtn grey" data-a="helpx" type="button">OK</button></div></div></div>`;}

/* ---------- habillage commun des fenêtres ---------- */
GROUP.length=0;GROUP.push(['perso','perso','Statut'],['sac','sac','Sac'],['sorts','sorts','Sorts'],['questlog','quetes','Quêtes'],['carte','carte','Carte'],['metiers','metiers','Métiers'],['guilde','guilde','Guilde'],['commu','commu','Communauté']);
groupStrip=function(){return'<nav class="gtabs">'+GROUP.map(([k,ic,n])=>`<button class="gtab ${panelKind===k?'on':''}" data-a="goto" data-v="${k}" type="button" aria-label="${n}"><img src="${uiIcon(ic)}" alt=""><span>${n}</span></button>`).join('')+'</nav>';};
const CAPS={perso:'STATUT',sac:'INVENTAIRE',sorts:'SORTS',questlog:'JOURNAL',metiers:'MÉTIERS',guilde:'GUILDE',guild:'GUILDES',carte:'CARTE',commu:'COMMUNAUTÉ',event:'ÉVÉNEMENT',options:'RÉGLAGES',menu:'MENU',aide:'AIDE',shop:'BOUTIQUE',forge:'FORGE',hdv:'MARCHÉ',bank:'COFFRE',tavern:'TAVERNE',trainer:'MAÎTRE D’ARMES',craft:'ATELIER',pet:'FAMILIER',groupe:'GROUPE',war:'GUERRE',primes:'PRIMES',qdetail:'QUÊTE',lore:'CHRONIQUE'};
const _rp3=renderPanel;
renderPanel=function(){const el=$('#panel'),k=panelKind,ob=el.querySelector(':scope>.pbody'),keep=ob&&el.dataset.k===k?ob.scrollTop:0;
  if(k==='perso')el.innerHTML=groupStrip()+persoPanel();else if(k==='carte')el.innerHTML=groupStrip()+mapPanel();else _rp3();
  el.dataset.k=k||'';el.classList.remove('railed','wide');if(k==='npc')return;
  const kids=[...el.children],rail=kids.find(x=>x.classList.contains('gtabs')),h2=kids.find(x=>x.tagName==='H2'),cl=kids.find(x=>x.classList.contains('close'));
  const head=document.createElement('div');head.className='phead'+(h2?'':' nohead');head.innerHTML=(CAPS[k]?`<small>${CAPS[k]}</small>`:'')+`<b>${h2?h2.innerHTML:''}</b>`+(HELP[k]?'<button class="phelp" data-a="help" type="button" aria-label="Aide">?</button>':'');
  const body=document.createElement('div');body.className='pbody';for(const x of kids)if(x!==rail&&x!==h2&&x!==cl)body.appendChild(x);
  el.textContent='';el.append(head);if(rail)el.append(rail);el.append(body);if(cl){cl.innerHTML='<b>✕</b>';el.append(cl);}
  el.classList.toggle('railed',!!rail);el.classList.toggle('wide',!!rail||k==='event'||k==='commu'||k==='aide');body.scrollTop=keep;
  if(helpOn===k&&HELP[k])el.insertAdjacentHTML('beforeend',helpPop(k));};
const _openPanel3=openPanel;openPanel=function(k,d){helpOn=null;closeDrawer();_openPanel3(k,d);};

/* ---------- dialogues : bandeau en haut, choix au centre ---------- */
const HL_BLUE=()=>[FACTIONS.solarix.n,FACTIONS.umbra.n,FACTIONS.solarix.capN,FACTIONS.umbra.capN],HL_RED=['Prisme d’Éther','Prisme','Fracture','éclats','Éclats','grimoire','Grimoires','champ de bataille','Hot Time'];
function hl(t){let s=esc(t);for(const w of HL_BLUE())s=s.split(esc(w)).join(`<em class="hb">${esc(w)}</em>`);for(const w of HL_RED)s=s.split(esc(w)).join(`<em class="hr">${esc(w)}</em>`);return s;}
const _dlg3=dialogPanel;dialogPanel=function(){const n=panelData,t=document.createElement('div');t.innerHTML=_dlg3();const o=t.querySelector('.dopts'),m=t.querySelector('.msg'),txt=n.say||npcGreet(n);
  const opts=(o?o.innerHTML:'').split('Campagne : ').join('<em class="req">[Campagne]</em> ');
  return`<div class="tbox"><div class="tname">${esc(n.n)}</div><div class="tpic"><img src="${lookURL(n.look,4)}" alt=""></div><div class="tmain"><small class="trole">${esc(n.r||'')}</small><p class="ttxt">${hl(txt)}</p></div><button class="tx" data-a="close" type="button" aria-label="Fermer">✕</button></div><div class="topts">${opts}</div>${m?m.outerHTML:''}`;};

/* ---------- HUD : rangée d'icônes, tiroir Menu ---------- */
$('#menu').innerHTML=[['bEvent','event','Événement'],['bQuest','quetes','Quêtes'],['bMap','carte','Carte'],['bSac','sac','Sac'],['bMenu','menu','Menu'],['bPK','pk','PK'],['bPerso','perso','Statut']].map(([id,ic,n])=>`<button id="${id}" class="ib" type="button" ${id==='bPK'||id==='bPerso'?'hidden':''}><img src="${uiIcon(ic)}" alt=""><span>${n}</span></button>`).join('');
for(const [id,k,d] of [['#bQuest','questlog'],['#bMap','carte'],['#bSac','sac'],['#bPerso','perso'],['#bEvent','event',{ci:1}]])$(id).addEventListener('click',()=>{if(state==='play')openPanel(k,d);});
$('#bPK').addEventListener('click',()=>{P.pkMode=!P.pkMode;$('#bPK').classList.toggle('on',P.pkMode);toast(P.pkMode?'Mode PK activé':'Mode PK désactivé',P.pkMode?'Tu peux attaquer les joueurs de ta faction. Tuer un allié rend ton nom rouge.':'');});
const DRAWER=[['perso','perso','Statut'],['sorts','sorts','Sorts'],['questlog','quetes','Quêtes'],['questlog:codex','chron','Chroniques'],['metiers','metiers','Métiers'],['guilde','guilde','Guilde'],['pet','pet','Familier'],['commu','commu','Communauté'],['event','event','Événements'],['carte','carte','Carte'],['sac','sac','Sac'],['options','opts','Réglages']],
  DRAWER2=[['lobby','lobby','Personnages'],['aide','aide','Aide'],['full','full','Plein écran']];
$('#hud').insertAdjacentHTML('beforeend',`<div id="mdrawer" hidden><div class="mdgrid">${DRAWER.map(([k,ic,n])=>`<button class="mdt" data-k="${k}" type="button"><img src="${uiIcon(ic)}" alt=""><span>${n}</span></button>`).join('')}</div><div class="mdbot">${DRAWER2.map(([k,ic,n])=>`<button class="mdt" data-k="${k}" type="button"><img src="${uiIcon(ic)}" alt=""><span>${n}</span></button>`).join('')}</div></div>`);
function closeDrawer(){const d=$('#mdrawer');if(d){d.hidden=true;$('#bMenu').classList.remove('on');}}
$('#bMenu').addEventListener('click',()=>{if(state!=='play')return;const d=$('#mdrawer');d.hidden=!d.hidden;$('#bMenu').classList.toggle('on',!d.hidden);if(!d.hidden){const lc=$('#lorecard');if(lc)lc.classList.remove('on');}if(!d.hidden)$('.mdt[data-k="perso"]').classList.toggle('badge',P.pts>0);});
$('#mdrawer').addEventListener('click',e=>{const b=e.target.closest('.mdt');if(!b)return;const [k,t]=b.dataset.k.split(':');closeDrawer();
  if(k==='lobby'){toTitle();return;}if(k==='full'){if(document.fullscreenElement){try{document.exitFullscreen();}catch(_){}}else goLandscape();return;}
  openPanel(k,k==='event'?{ci:1}:undefined);if(t){panelTab=t;renderPanel();}});
for(const ev of ['pointerdown','touchstart'])$('#mdrawer').addEventListener(ev,e=>e.stopPropagation(),{passive:true});
const _hud3=hud;hud=function(){_hud3();if(!P||state==='title')return;const m=$('#bMenu');if(m)m.classList.toggle('badge',P.pts>0);const ev=$('#bEvent');if(ev)ev.classList.toggle('badge',ciCan());};
const _toTitle3=toTitle;toTitle=function(){closeDrawer();_toTitle3();};

/* ---------- chat en barre : canal coloré, émotes ---------- */
const CHC={say:['Tous','#e8604a'],party:['Groupe','#3a9ae8'],guild:['Guilde','#4ab85a']};
{const sel=$('#chatch'),form=$('#chatform');sel.hidden=true;
  form.insertAdjacentHTML('afterbegin','<button id="chanBtn" type="button" aria-label="Changer de canal"></button>');
  $('#chatin').insertAdjacentHTML('afterend','<button id="emoBtn" type="button" aria-label="Émotes">☺</button>');
  $('#chatbox').insertAdjacentHTML('beforeend','<div id="emoRow" hidden>'+['♥','★','☺','♪','!','?','✿','⚔','☀','☾','gg','merci'].map(x=>`<button type="button">${x}</button>`).join('')+'</div>');
  const paint=()=>{const [n,c]=CHC[sel.value]||CHC.say;$('#chanBtn').textContent=n;$('#chanBtn').style.setProperty('--cc',c);};paint();
  $('#chanBtn').onclick=()=>{const o=[...sel.options].map(x=>x.value),i=o.indexOf(sel.value);sel.value=o[(i+1)%o.length];paint();};
  $('#emoBtn').onclick=()=>{$('#emoRow').hidden=!$('#emoRow').hidden;};
  $('#emoRow').addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;const i=$('#chatin');i.value=(i.value+(i.value&&!i.value.endsWith(' ')?' ':'')+b.textContent).slice(0,80);i.focus();});}

/* ---------- contrôles : fiche « déplacement, ciblage, ramassage, raccourcis » ---------- */
/* joystick fixe en bas à gauche par défaut */
if(!('joy' in loadJSON('paracraft_settings',{})))SET.joy='fixe';
/* verrouillage : l'ennemi agressif le plus proche dans le champ de vision */
function lockNearest(){const x0=camX,y0=camY,x1=camX+VIEW.w*dpr/Z,y1=camY+VIEW.h*dpr/Z,inV=o=>o.x>x0&&o.x<x1&&o.y>y0&&o.y<y1;let best=null,bs=1e9;
  for(const m of mons){if(m.dead||m.team||!inV(m))continue;const sc=dist(m,P)-(m.agg?400:0)-(m.t&&m.t.agr?120:0);if(sc<bs){bs=sc;best=m;}}
  if(inPvp())for(const b of bots)if(b.map===curId()&&inV(b)&&canTarget(b)&&!(b.fac===P.fac&&!b.pk&&P.pkT<=0)){const sc=dist(b,P)-300;if(sc<bs){bs=sc;best=b;}}
  if(!best){addText(P.x,P.y-30,'Aucune cible en vue','#b3a8c7');return null;}
  P.target=best;P.atkOn=false;P.chase=false;addFx({k:'ring',x:best.x,y:best.y-4,r0:18,r1:8,life:.35,col:'#ffd36a'});addText(P.x,P.y-30,'Cible verrouillée','#ffd84a');return best;}
/* bouton d'attaque : sans cible, il verrouille d'abord ; avec une cible, il lance l'attaque automatique */
const _attackBtn3=attackBtn;attackBtn=function(){if(state!=='play'||paused)return;if(!canTarget(P.target)){lockNearest();return;}_attackBtn3();};
/* sorts offensifs : il faut une cible verrouillée avant */
const TGT_K=new Set(['basic','charge','stun','execute','sunder','root','curse','snipe','pierce','slowshot','tracker','cast']);
const _useSkill3=useSkill;useSkill=function(i){if(state!=='play'||paused||i==null)return;const sk=CLASSES[P.cls].sk[i];
  if(sk&&TGT_K.has(sk.k)&&skRank(i)&&!canTarget(P.target)){if(lockNearest())addText(P.x,P.y-44,'Touche de nouveau '+sk.s,'#ffd84a');return;}_useSkill3(i);};
/* toucher le sol : annule la cible, sans déplacement (on bouge au joystick) */
tap=function(sx,sy){if(state!=='play'||paused)return;const wx=camX+sx*dpr/Z,wy=camY+sy*dpr/Z;
  let best=null,bd=22;for(const m of mons){if(m.dead)continue;const d=Math.hypot(m.x-wx,(m.y-m.hh)-wy)-m.hr+10;if(d<bd){bd=d;best=m;}}
  for(const b of bots){if(b.dead||b.map!==curId()||!canTarget(b))continue;const d=Math.hypot(b.x-wx,b.y-12-wy);if(d<bd){bd=d;best=b;}}
  if(best){if(best.kind==='b'&&best.fac===P.fac&&!best.pk&&P.pkT<=0&&!P.pkMode){toast('Active le mode PK pour attaquer un allié');return;}if(best===P.target){attackBtn();return;}
    P.target=best;P.chase=false;P.atkOn=false;P.moveTo=null;P.harv=null;addFx({k:'ring',x:best.x,y:best.y-4,r0:18,r1:8,life:.35,col:'#ffd36a'});return;}
  const near=(o,r)=>dist(o,P)<r;
  for(const n of M.npcs)if(Math.hypot(n.x-wx,n.y-12-wy)<18){if(near(n,46)){P.target=null;P.atkOn=false;actionBtn();}else addText(P.x,P.y-30,'Approche-toi pour parler','#b3a8c7');return;}
  for(const n of M.nodes)if(n.alive&&Math.hypot(n.x-wx,n.y-8-wy)<16){if(near(n,40))startHarvest(n);else addText(P.x,P.y-30,'Approche-toi pour récolter','#b3a8c7');return;}
  for(const b of bags)if(Math.hypot(b.x-wx,b.y-4-wy)<14){addText(P.x,P.y-30,near(b,LOOT_R)?'Touche Ramasser':'Approche-toi, puis Ramasser','#ffd84a');return;}
  if(P.target){P.target=null;P.atkOn=false;addFx({k:'ring',x:wx,y:wy,r0:6,r1:2,life:.3,col:'#9aa6c4'});}};
/* ramassage : bouton dédié (main), à portée immédiate ; butin réservé à son vainqueur pendant 30 s, puis public */
const LOOT_R=28;let LOCK_T=12;
const canLoot=b=>b.owner==='p'||b.owner==='free'||b.owner==='all';
function lootBtn(){if(state!=='play'||paused)return;const L=bags.filter(b=>canLoot(b)&&Math.hypot(b.x-P.x,b.y-P.y)<LOOT_R);
  if(!L.length){const far=bags.some(b=>canLoot(b)&&Math.hypot(b.x-P.x,b.y-P.y)<90);addText(P.x,P.y-30,far?'Trop loin : approche-toi':'Rien à ramasser','#b3a8c7');return;}
  for(const b of L){pickBag(b);if(bagEmpty(b)){const i=bags.indexOf(b);if(i>=0)bags.splice(i,1);}}}
const _interact3=interactTarget;interactTarget=function(){const sv=bags;bags=[];try{return _interact3();}finally{bags=sv;}};
const _update3=update;update=function(dt){_update3(dt);if(state!=='play')return;for(const b of bags){if(b.owner!=='p')continue;if(b.lock==null)b.lock=LOCK_T;b.lock-=dt;if(b.lock<=0)b.owner='free';}};
$('#pad').insertAdjacentHTML('beforeend','<button class="cb" id="bLoot" type="button" aria-label="Ramasser"><span>Ramasser</span><i class="k">F</i></button>');
ICO_UI.main=g=>{const c='#f1c9a0',d='#c8946a';I.r(g,4,7,9,7,c);for(const [x,h] of [[4,4],[6,6],[8,6],[10,5]])I.r(g,x,7-h,2,h,c);I.r(g,12,8,3,2,c);I.r(g,4,13,9,1,d);I.r(g,5,9,7,1,d);};
bindBtn('#bLoot',lootBtn);$('#bLoot').insertAdjacentHTML('beforeend',`<img class="bi" src="${uiIcon('main')}" alt="">`);
addEventListener('keydown',e=>{if((e.key==='f'||e.key==='F')&&state==='play'&&!paused&&document.activeElement!==$('#chatin'))lootBtn();});
/* barre d'accès rapide : deux cases de consommables configurables (par défaut potions de vie et de mana) */
const qc=()=>{P.qc=P.qc||['pv','pm'];return P.qc;};
function useQuick(j){const k=qc()[j];if(!k)return;if(!(P.cons[k]>0)){addText(P.x,P.y-30,'Plus de '+(CONS[k]?CONS[k].n:k),'#b3a8c7');return;}if(k==='pv'||k==='pm')usePot(k);else{useCons(k);hud();}}
for(const [j,id] of [[0,'#bPV'],[1,'#bPM']]){const o=$(id),n=o.cloneNode(true);o.replaceWith(n);bindBtn(id,()=>useQuick(j));}
EXTRA_ACT.qset=v=>{const [j,k]=v.split(':');qc()[+j]=k;panelMsg=`Raccourci ${+j+1} : ${esc(CONS[k].n)}`;};
const _cellDetail3=cellDetail;cellDetail=function(c){let h=_cellDetail3(c);
  if(c&&c.t==='c'&&!c.k.startsWith('ench')&&!c.k.startsWith('livre_')&&!isVirtual(c.k))h=h.replace('<div class="iact">','<div class="iact">'+[0,1].map(j=>B('qset','Raccourci '+(j+1),`data-v="${j}:${c.k}"`,qc()[j]===c.k?'go':'')).join(''));
  if(c&&c.t==='i'&&!canEquip(c.it))h=h.replace('<div class="idt">','<div class="idt"><em class="dtap">Double-tap pour équiper</em>');return h;};
/* double-tap sur un objet du sac : l'équipe */
let _lastSel={v:null,t:0};const _isel3=EXTRA_ACT.isel;
EXTRA_ACT.isel=v=>{const now=performance.now(),dbl=_lastSel.v===v&&now-_lastSel.t<450;_lastSel={v,t:now};
  if(dbl){const c=findCell(v);if(c&&c.t==='i'&&!canEquip(c.it)){equip(c.it);panelMsg='Équipé : '+esc(itemName(c.it));panelData=Object.assign({},panelData||{},{sel:null});_lastSel.v=null;return;}}
  if(dbl&&panelData&&panelData.sel===v)return;_isel3(v);};
const _hud4=hud;hud=function(){_hud4();if(!P||state==='title')return;const Q=qc();
  [['pvn','#bPV',0],['pmn','#bPM',1]].forEach(([t,id,j])=>{const k=Q[j];setTxt(t,String(P.cons[k]||0));const im=$(id+' img.bi');if(im&&im.dataset.k!==k){im.dataset.k=k;im.src=k==='pv'?uiIcon('pv'):k==='pm'?uiIcon('pm'):consIcon(k);}});
  const lb=$('#bLoot');if(lb)lb.classList.toggle('ready',bags.some(b=>canLoot(b)&&Math.hypot(b.x-P.x,b.y-P.y)<LOOT_R));};
SAVE_FIELDS.push('qc');

/* ---------- prologue : une seule fois par personnage, touche pour fermer ---------- */
const _showLore3=showLore;showLore=function(t,x){if(t==='Prologue'){if(!P||P.proSeen)return;P.proSeen=1;}_showLore3(t,x);};
SAVE_FIELDS.push('proSeen');
$('#lorecard').addEventListener('pointerdown',e=>{e.stopPropagation();$('#lorecard').classList.remove('on');});

/* ---------- défilement tactile quand le jeu est tourné (téléphone tenu en portrait) ---------- */
{let sc=null;const canS=e=>{const cs=getComputedStyle(e);return(/(auto|scroll)/.test(cs.overflowY)&&e.scrollHeight>e.clientHeight+2)||(/(auto|scroll)/.test(cs.overflowX)&&e.scrollWidth>e.clientWidth+2);};
  const scroller=el=>{for(let e=el;e&&e.nodeType===1&&e!==document.body;e=e.parentElement)if(canS(e))return e;return null;};
  addEventListener('touchstart',e=>{sc=null;if(!VIEW.rot||e.touches.length!==1)return;const tg=e.target;if(!tg.closest||tg.closest('#cv,#pad,#joyBase,#chatgrip'))return;const el=scroller(tg);if(!el)return;const t=e.touches[0];sc={el,x:GX(t),y:GY(t),moved:false,vx:0,vy:0};},{passive:true,capture:true});
  addEventListener('touchmove',e=>{if(!sc)return;const t=e.touches[0],x=GX(t),y=GY(t),dx=x-sc.x,dy=y-sc.y;if(!sc.moved&&Math.hypot(dx,dy)<7)return;sc.moved=true;if(e.cancelable)e.preventDefault();sc.el.scrollTop-=dy;sc.el.scrollLeft-=dx;sc.vx=dx;sc.vy=dy;sc.x=x;sc.y=y;},{passive:false,capture:true});
  addEventListener('touchend',()=>{const s=sc;sc=null;if(!s||!s.moved)return;let vx=s.vx,vy=s.vy;const step=()=>{if(Math.abs(vy)<.4&&Math.abs(vx)<.4)return;s.el.scrollTop-=vy;s.el.scrollLeft-=vx;vy*=.93;vx*=.93;requestAnimationFrame(step);};requestAnimationFrame(step);
    const kill=ev=>{ev.stopPropagation();ev.preventDefault();};addEventListener('click',kill,{capture:true,once:true});setTimeout(()=>removeEventListener('click',kill,{capture:true}),350);},{capture:true});}

/* ---------- pavé de combat : arc de sorts autour de l'attaque ---------- */
const PAD_R=154,PAD_C=56,ARC_A=[184,163,142,121,100,81];
function layoutPad(){const sz=58;
  ARC_A.forEach((a,j)=>{const r=a*Math.PI/180,b=$('#bS'+j);b.style.right=(PAD_C-PAD_R*Math.cos(r)-sz/2).toFixed(1)+'px';b.style.bottom=(PAD_C+PAD_R*Math.sin(r)-sz/2).toFixed(1)+'px';});
  const put=(id,a,rad,size)=>{const r=a*Math.PI/180,b=$(id);b.style.right=(PAD_C-rad*Math.cos(r)-size/2).toFixed(1)+'px';b.style.bottom=(PAD_C+rad*Math.sin(r)-size/2).toFixed(1)+'px';};
  put('#bLoot',106,100,50);put('#bAct',152,102,50);}
$('#pad').insertAdjacentHTML('beforeend','<div id="barDots" role="group" aria-label="Barres de sorts">'+[0,1,2,3,4].map(j=>`<button type="button" data-j="${j}" aria-label="Barre ${j+1}"></button>`).join('')+'</div>');
$('#barDots').addEventListener('pointerdown',e=>{const b=e.target.closest('button');if(!b||state!=='play')return;e.stopPropagation();e.preventDefault();EXTRA_ACT.preset(b.dataset.j);toast('Barre de sorts '+(+b.dataset.j+1));paintDots();});
function paintDots(){const j=P&&P.barSet||0;[...$('#barDots').children].forEach((b,i)=>b.classList.toggle('on',i===j));}
const _setSkillLabels3=setSkillLabels;setSkillLabels=function(){_setSkillLabels3();if(P)paintDots();};
layoutPad();addEventListener('resize',layoutPad);

/* ---------- taille des boutons et du joystick (réglages) ---------- */
const padAuto=()=>+clamp(VIEW.h/540,.55,1).toFixed(2),joyAuto=()=>+clamp(VIEW.h/500,.6,1).toFixed(2);
const padS=()=>SET.padS||padAuto(),joyS=()=>SET.joyS||joyAuto();
const mmS=()=>SET.mmS||1;
function applyMap(){const w=$('#mmwrap');if(!w)return;w.hidden=!!SET.mmOff;const c=$('#mm');c.style.width=Math.round(96*mmS())+'px';c.style.height=Math.round(72*mmS())+'px';
  const top=Math.round(72*mmS())+14;for(const [id,dy] of [['#zone',0],['#gold',30]]){const e=$(id);if(e){e.style.top=`calc(env(safe-area-inset-top,0px) + ${SET.mmOff?6+dy:top+dy}px)`;e.style.width=Math.max(104,Math.round(96*mmS())+8)+'px';}}}
function applySizes(){applyMap();const p=$('#pad');if(p){p.style.transformOrigin='right bottom';p.style.transform=`scale(${padS()})`;}
  const jb=$('#joyBase');if(jb){jb.style.transformOrigin='left bottom';jb.style.transform=`scale(${joyS()})`;}const j=$('#joy');if(j)j.style.transform=`scale(${joyS()})`;}
const _applySettings3=applySettings;applySettings=function(){_applySettings3();applySizes();};
addEventListener('resize',applySizes);applySizes();
const sizeRow=(k,lab,val,mn,mx,extra)=>`<div class="szrow"><span>${lab}</span><input type="range" min="${mn||45}" max="${mx||130}" step="5" value="${Math.round(val*100)}" data-sz="${k}" aria-label="${lab}"><b id="szv_${k}">${Math.round(val*100)} %</b>${extra||`<button class="btn ${SET[k]?'':'go'}" data-a="szauto" data-v="${k}" type="button">Auto${SET[k]?'':' ✔'}</button>`}</div>`;
EXTRA_ACT.mmtog=()=>{SET.mmOff=!SET.mmOff;saveSettings();applySizes();panelMsg=SET.mmOff?'Mini-carte masquée':'Mini-carte affichée';};
EXTRA_ACT.szauto=v=>{delete SET[v];saveSettings();applySizes();panelMsg='Taille automatique : '+Math.round((v==='padS'?padAuto():joyAuto())*100)+' %';};
$('#panel').addEventListener('input',e=>{const r=e.target.closest('input[data-sz]');if(!r)return;const k=r.dataset.sz;SET[k]=r.value/100;applySizes();const b=$('#szv_'+k);if(b)b.textContent=r.value+' %';});
$('#panel').addEventListener('change',e=>{if(e.target.closest('input[data-sz]')){saveSettings();renderPanel();}});
const _rp4=renderPanel;renderPanel=function(){_rp4();if(panelKind!=='options')return;const body=$('#panel .pbody');if(!body)return;
  const h3=[...body.querySelectorAll('h3')].find(x=>/TAILLE DES BOUTONS/.test(x.textContent));if(!h3)return;const seg=h3.nextElementSibling;
  const box=document.createElement('div');box.className='szbox';box.innerHTML=sizeRow('padS','Boutons de combat',padS())+sizeRow('joyS','Joystick',joyS())+sizeRow('mmS','Mini-carte',mmS(),50,220,`<button class="btn ${SET.mmOff?'go':''}" data-a="mmtog" type="button">${SET.mmOff?'Afficher':'Masquer'}</button>`)+'<p class="sub">« Auto » adapte la taille à ton écran. Glisse pour agrandir ou réduire, l’effet est immédiat.</p>';
  if(seg&&seg.classList.contains('seg'))seg.replaceWith(box);else h3.after(box);};

/* ---------- coordonnées du joueur (sous le portrait), mini-carte touchable ---------- */
$('#hudL').insertAdjacentHTML('beforeend','<span id="pcoord" aria-label="Coordonnées"></span>');
const _hud5=hud;hud=function(){_hud5();if(!P||state==='title')return;setTxt('pcoord',`${Math.round(P.x/TS)},${Math.round(P.y/TS)}`);};
$('#mmwrap').addEventListener('click',()=>{if(state==='play')openPanel('carte');});

/* ---------- état initial ---------- */
{const vis=SCRS.find(s=>!$('#'+s).hidden)||'sLogin';$('#start').dataset.s=vis;if(vis==='sServer')showServers();}
