/* ================== Paracraft Online · royaumes de départ ==================
   Aurelia (Solarix) et Nocthar (Umbra) deviennent des royaumes complets : remparts, palais et souverain,
   grande avenue, marché, quartier des artisans, temple et cimetière, taverne, banque, bibliothèque,
   caserne et terrain d'entraînement avec mannequins, maison des guildes, quartiers d'habitation,
   et campagne agricole entre la porte et la route. */

const KW=112,KH=84;
MAPS.sol_cap.w=KW;MAPS.sol_cap.h=KH;MAPS.umb_cap.w=KW;MAPS.umb_cap.h=KH;

/* ---------- PNJ supplémentaires ---------- */
Object.assign(NPC_DEF.solarix,{roi:['Roi Aldéric IV','Souverain de Solarix'],banque:['Trésorier Bastien','Banque royale'],temple:['Prêtresse Séraphine','Temple de l’Aube'],taverne:['Mère Gertrude','Taverne du Soleil Levant'],biblio:['Archiviste Elouan','Grande Bibliothèque']});
Object.assign(NPC_DEF.umbra,{roi:['Reine Morgane','Souveraine d’Umbra'],banque:['Coffrier Vashk','Banque des Ombres'],temple:['Prêtresse Nyx','Sanctuaire de la Lune'],taverne:['Corbeau Silas','Taverne du Corbeau'],biblio:['Gardienne Ilyra','Archives du Crépuscule']});
Object.assign(NPC_LOOK,{
  roi:{hair:'#e8e0c8',body:'#8a1a2a',body2:'#f2c14e',belt:'#f2c14e',legs:'#4a1a22',cape:'#c83a3a',extra:'crown',weapon:'sword'},
  banque:{hair:'#5a4a3a',body:'#3a4a3a',body2:'#c8a050',belt:'#f2c14e',legs:'#2a2a2a',weapon:'none'},
  temple:{hair:'#f4ead0',hairStyle:'long',body:'#f4ead0',body2:'#e0c070',robe:true,weapon:'staff',orb:'#ffe8a0'},
  taverne:{hair:'#8a3a1a',hairStyle:'pony',body:'#7a5a3a',body2:'#e8dcc0',belt:'#4a3a1a',legs:'#4a3a2a',weapon:'none'},
  biblio:{hair:'#c8c8c8',body:'#3a3a6a',body2:'#2a2a4a',robe:true,extra:'hood',hood:'#2a2a4a',weapon:'staff',orb:'#9ad8ff'}});
const KUMBRA={roi:{body:'#3a2468',body2:'#b48cff',cape:'#2a1a44',hair:'#1a1a2a',hairStyle:'long'},temple:{body:'#2a2a4a',body2:'#9ad8ff',hair:'#d8d8f0',orb:'#c8d8ff'}};
NPC_ROLES.push('roi','banque','temple','taverne','biblio');

/* ---------- monstre d'entraînement ---------- */
MT.mannequin={n:'Mannequin d’entraînement',role:'m',spr:'mannequin',spd:0,hp:6,agr:false,keep:1};
const DUMMY=["....SSSS....","...SKSSKS...","...SSSSSS...","....SSSS....","..BBBBBBBB..","BBBBBBBBBBBB","B.BBRRBBBB.B","..BBRRRRBB..","..BBBBBBBB..","....WWWW....","....WWWW....",".....WW.....","....WWWW....","..WWWWWWWW.."];
const _spawnMon=spawnMon;spawnMon=function(s){const m=_spawnMon(s);if(s.type==='mannequin'){m.xp=0;m.gold=[0,0];m.respawn=3;m.lv=P?P.lvl:1;m.def=0;m.maxhp=m.hp=Math.round(400+(P?P.lvl:1)*120);m.name='Mannequin d’entraînement';}return m;};
const _dropLootK=dropLoot;dropLoot=function(m,near){if(m.type==='mannequin')return;return _dropLootK(m,near);};
const _hitMonK=hitMon;hitMon=function(m,dmg,col,fp,crit){if(m.type==='mannequin'){m.agg=false;m.dps=(m.dps||0)+dmg;}return _hitMonK(m,dmg,col,fp,crit);};

/* ---------- sprites des bâtiments ---------- */
const KPAL={o:{wall:'#d8d0c0',wall2:'#c4baa6',line:'#a89c86',roof:'#2f5aa0',roof2:'#3e6cb8',roofE:'#1e3a6a',trim:'#f2c14e',win:'#ffe7a0',door:'#5a3a20',dome:'#f2c14e',dome2:'#c8962a',flag:'#f2c14e'},
  s:{wall:'#4a4458',wall2:'#3e384c',line:'#2a2434',roof:'#3e2a66',roof2:'#523a84',roofE:'#1a1030',trim:'#b48cff',win:'#d8b0ff',door:'#2a1a14',dome:'#6a3aa8',dome2:'#4a2478',flag:'#b48cff'}};
function kR(g,x,y,w,h,c){g.fillStyle=c;g.fillRect(x,y,w,h);}
function kBrick(g,x,y,w,h,p){kR(g,x,y,w,h,p.wall);g.fillStyle=p.line;for(let yy=y+5,r=0;yy<y+h;yy+=6,r++){g.fillRect(x,yy,w,1);for(let xx=x+(r%2)*7;xx<x+w;xx+=14)g.fillRect(xx,yy-5,1,5);}kR(g,x,y,w,2,p.wall2);}
function kRoof(g,x,y,w,h,p){for(let i=0;i<h;i++){const inset=Math.round((h-i)*.35);g.fillStyle=(Math.floor(i/4))%2?p.roof:p.roof2;g.fillRect(x+inset,y+i,w-inset*2,1);}kR(g,x,y+h-3,w,3,p.roofE);g.fillStyle=p.roofE;for(let xx=x+6;xx<x+w-6;xx+=10)g.fillRect(xx,y+h-12,1,8);}
function kWin(g,x,y,w,h,p,arch){kR(g,x-1,y-1,w+2,h+2,p.line);kR(g,x,y,w,h,p.win);kR(g,x+Math.floor(w/2),y,1,h,p.line);kR(g,x,y+Math.floor(h/2),w,1,p.line);if(arch){g.fillStyle=p.line;g.fillRect(x,y,1,2);g.fillRect(x+w-1,y,1,2);}}
function kDoor(g,x,y,w,h,p){kR(g,x-2,y-3,w+4,h+3,p.trim);kR(g,x,y,w,h,p.door);kR(g,x+Math.floor(w/2),y,1,h,'#00000055');kR(g,x+w-4,y+h/2,2,2,p.trim);}
function kCrenel(g,x,y,w,p){for(let xx=x;xx<x+w;xx+=8){kR(g,xx,y,5,5,p.wall);kR(g,xx,y,5,1,p.wall2);}}
function kFlag(g,x,y,p){kR(g,x,y,1,16,'#3a2a1a');kR(g,x+1,y,9,6,p.flag);kR(g,x+1,y+6,6,2,p.flag);}
function kSign(g,x,y,col,ic){kR(g,x,y,14,12,'#5a3a1a');kR(g,x+1,y+1,12,10,'#8a6440');g.fillStyle=col;ic(g,x,y);}
function buildKingdomProps(){const T=(k,w,h,fn)=>{PROPS[k]=mkProp(w,h,fn);};
  for(const st of ['o','s']){const p=KPAL[st];
    T('palace_'+st,256,200,g=>{
      // tours latérales
      for(const tx of [4,204]){kBrick(g,tx,60,48,140,p);kCrenel(g,tx-2,54,52,p);g.fillStyle=p.roof;for(let i=0;i<46;i++){const w2=Math.max(2,Math.round(i*1.15));g.fillStyle=i%6<3?p.roof:p.roof2;g.fillRect(tx+24-w2/2,8+i,w2,1);}kFlag(g,tx+24,0,p);kWin(g,tx+18,90,12,18,p,1);kWin(g,tx+18,130,12,18,p,1);}
      // corps
      kBrick(g,50,96,156,104,p);kCrenel(g,48,90,160,p);
      // donjon central
      kBrick(g,92,40,72,64,p);kCrenel(g,90,34,76,p);
      if(st==='o'){disc(g,128,30,22,p.dome2);disc(g,128,28,20,p.dome);kR(g,106,30,44,8,p.dome);kR(g,126,0,4,10,p.trim);disc(g,128,4,3,p.trim);}
      else{for(let i=0;i<40;i++){const w2=Math.max(2,Math.round(i*1.4));g.fillStyle=i%5<2?p.dome2:p.dome;g.fillRect(128-w2/2,i,w2,1);}disc(g,128,4,3,p.trim);}
      kWin(g,104,58,14,20,p,1);kWin(g,138,58,14,20,p,1);
      for(const wx of [62,84,160,182])kWin(g,wx,116,12,18,p,1);
      // portail
      kR(g,108,140,40,60,p.line);kR(g,110,142,36,58,p.door);g.fillStyle=p.door;disc(g,128,144,18,p.door);kR(g,127,130,2,70,'#00000044');kR(g,104,136,48,4,p.trim);
      // bannières
      for(const bx of [74,170]){kR(g,bx,104,14,34,p.flag);kR(g,bx+2,106,10,30,st==='o'?'#f8f0d8':'#2a1a44');disc(g,bx+7,118,4,p.flag);}
      kR(g,50,196,156,4,p.line);});
    T('temple_'+st,160,150,g=>{kBrick(g,10,64,140,86,p);for(let i=0;i<36;i++){const inset=Math.round((36-i)*1.9);g.fillStyle=i%4<2?p.roof:p.roof2;g.fillRect(10+inset,28+i,140-inset*2,1);}
      kR(g,62,6,36,60,p.wall);kR(g,62,6,36,2,p.wall2);for(let i=0;i<20;i++){const w2=Math.max(2,Math.round(i*1.9));g.fillStyle=p.roof2;g.fillRect(80-w2/2,i-14,w2,1);}
      disc(g,80,30,9,p.trim);disc(g,80,30,7,st==='o'?'#ffe7a0':'#9ad8ff');kR(g,79,22,2,16,p.line);kR(g,72,29,16,2,p.line);
      for(const cx of [22,46,106,130]){kR(g,cx,70,10,76,p.wall2);kR(g,cx-2,68,14,4,p.trim);kR(g,cx-2,144,14,4,p.trim);kR(g,cx+3,72,1,72,p.line);}
      kDoor(g,68,110,24,40,p);kWin(g,72,78,16,22,p,1);kR(g,6,146,148,4,p.line);});
    T('tavern_'+st,128,104,g=>{kR(g,8,52,112,52,st==='o'?'#e8dcc0':'#5a5068');g.fillStyle='#5a3a1a';for(const x of [8,40,64,88,118])g.fillRect(x,52,3,52);g.fillRect(8,76,112,3);kRoof(g,0,8,128,48,p);kR(g,96,0,12,24,'#6a4a3a');kR(g,96,0,12,2,'#4a3a2a');
      kDoor(g,52,78,22,26,p);kWin(g,18,60,16,12,p);kWin(g,94,60,16,12,p);kWin(g,18,84,16,12,p);kWin(g,94,84,16,12,p);
      kSign(g,78,58,'#f2c14e',(g,x,y)=>{g.fillStyle='#f2c14e';g.fillRect(x+4,y+3,5,7);g.fillStyle='#fff';g.fillRect(x+4,y+2,5,2);g.fillStyle='#f2c14e';g.fillRect(x+9,y+5,2,3);});});
    T('bank_'+st,128,104,g=>{kBrick(g,8,40,112,64,p);for(let i=0;i<20;i++){const inset=Math.round((20-i)*2.8);g.fillStyle=p.wall2;g.fillRect(8+inset,20+i,112-inset*2,1);}kR(g,4,38,120,4,p.trim);
      for(const cx of [16,36,84,104]){kR(g,cx,44,8,58,p.wall2);kR(g,cx+2,46,1,54,p.line);}kDoor(g,52,72,24,32,p);disc(g,64,30,6,p.trim);disc(g,64,30,4,'#c8962a');kR(g,63,27,2,6,p.trim);kR(g,4,100,120,4,p.line);});
    T('library_'+st,144,116,g=>{kBrick(g,8,56,128,60,p);kRoof(g,0,6,144,54,p);disc(g,72,32,10,p.line);disc(g,72,32,8,p.win);kR(g,71,24,2,16,p.line);kR(g,64,31,16,2,p.line);
      kDoor(g,62,84,20,32,p);for(const wx of [18,40,96,118])kWin(g,wx,70,10,26,p,1);
      kSign(g,86,64,'#9ad8ff',(g,x,y)=>{g.fillStyle='#e8dcc0';g.fillRect(x+3,y+2,8,8);g.fillStyle='#3a5aa0';g.fillRect(x+3,y+2,3,8);});});
    T('barracks_'+st,160,104,g=>{kBrick(g,6,30,148,74,p);kCrenel(g,4,24,152,p);kBrick(g,60,6,40,30,p);kCrenel(g,58,0,44,p);kFlag(g,80,-2,p);
      kDoor(g,66,70,28,34,p);for(const wx of [18,40,108,130])kWin(g,wx,50,10,14,p);
      kSign(g,100,74,'#c8ccd4',(g,x,y)=>{g.fillStyle='#c8ccd4';for(let i=0;i<7;i++){g.fillRect(x+3+i,y+2+i,1,1);g.fillRect(x+10-i,y+2+i,1,1);}});});
    T('guildhall_'+st,144,116,g=>{kBrick(g,10,50,124,66,p);kRoof(g,0,4,144,50,p);for(const bx of [18,112]){kR(g,bx,58,14,40,p.flag);kR(g,bx+2,60,10,36,st==='o'?'#2f5aa0':'#2a1a44');disc(g,bx+7,76,4,p.flag);}
      kDoor(g,58,80,28,36,p);kWin(g,44,60,10,14,p,1);kWin(g,90,60,10,14,p,1);kSign(g,92,84,'#c8ccd4',(g,x,y)=>{g.fillStyle='#c8ccd4';g.fillRect(x+4,y+2,6,5);g.fillRect(x+5,y+7,4,2);});});
    T('forgeb_'+st,128,100,g=>{kBrick(g,8,46,112,54,p);kRoof(g,0,8,128,42,p);kR(g,94,0,16,30,p.wall2);kR(g,94,0,16,3,'#2a2a2a');kR(g,20,66,48,34,'#2a1a14');kR(g,24,74,40,26,'#ff7a2a');kR(g,30,80,28,20,'#ffd060');kR(g,20,64,48,3,p.trim);
      kDoor(g,84,70,20,30,p);kSign(g,72,54,'#c8ccd4',(g,x,y)=>{g.fillStyle='#c8ccd4';g.fillRect(x+2,y+4,10,3);g.fillRect(x+5,y+7,4,3);});});
    T('kingdomhouse_'+st,80,72,g=>{kBrick(g,6,34,68,38,p);kRoof(g,0,4,80,34,p);kDoor(g,34,52,12,20,p);kWin(g,14,44,10,10,p);kWin(g,56,44,10,10,p);kR(g,58,6,8,14,p.wall2);});
    T('kingdomhouse2_'+st,96,76,g=>{kR(g,6,36,84,40,st==='o'?'#e8dcc0':'#5a5068');g.fillStyle='#5a3a1a';for(const x of [6,30,62,88])g.fillRect(x,36,2,40);g.fillRect(6,54,84,2);kRoof(g,0,6,96,34,p);kDoor(g,42,56,12,20,p);kWin(g,14,42,10,10,p);kWin(g,70,42,10,10,p);});
    T('throne_'+st,40,44,g=>{kR(g,4,36,32,8,p.line);kR(g,8,4,24,34,st==='o'?'#c8962a':'#4a2478');kR(g,11,8,18,22,st==='o'?'#c83a3a':'#2a1a44');kR(g,6,22,4,16,p.trim);kR(g,30,22,4,16,p.trim);disc(g,20,4,4,p.trim);});
    T('statue_'+st,28,56,g=>{kR(g,2,42,24,14,p.wall2);kR(g,4,40,20,3,p.trim);kR(g,10,14,8,26,'#9a9aa6');disc(g,14,10,5,'#a8a8b4');kR(g,6,18,4,14,'#9a9aa6');kR(g,18,18,4,14,'#9a9aa6');kR(g,20,4,2,30,'#c8ccd4');});
  }
  T('lectern',16,26,g=>{kR(g,6,10,4,16,'#5a3a22');kR(g,2,24,12,2,'#5a3a22');kR(g,0,4,16,7,'#7a5232');kR(g,1,2,7,6,'#f4ead0');kR(g,8,2,7,6,'#efe2c4');kR(g,2,3,5,1,'#3a2a4a');kR(g,9,4,5,1,'#3a2a4a');});
  T('hedge',32,18,g=>{kR(g,0,4,32,14,'#2f6a32');for(let x=0;x<32;x+=6)disc(g,x+3,5,4,'#3f8a42');kR(g,0,16,32,2,'#1f4a22');});
  T('flowerbed',32,14,g=>{kR(g,0,6,32,8,'#6a4a2a');kR(g,1,7,30,6,'#4a3420');for(let x=2;x<30;x+=4){disc(g,x+1,5,2,'#3f8a42');kR(g,x,3,2,2,['#ff6a8a','#ffd36a','#c58cff','#ffffff'][(x/4)%4]);}});
  T('crop',16,14,g=>{for(let x=1;x<16;x+=5){kR(g,x,4,1,10,'#6a8a2a');kR(g,x-1,2,3,4,'#e8c860');kR(g,x+1,7,2,1,'#8aa83a');}});
  T('haystack',28,22,g=>{disc(g,14,13,10,'#c8a040');kR(g,4,13,20,9,'#c8a040');g.fillStyle='#a8842a';for(let x=5;x<24;x+=3)g.fillRect(x,8+(x%2),1,12);});
  T('windmill',72,120,g=>{kR(g,22,50,28,70,'#e8dcc0');kR(g,22,50,28,2,'#c8bca0');kR(g,30,96,12,24,'#5a3a20');for(let i=0;i<22;i++){const w2=Math.max(2,Math.round(i*1.5));g.fillStyle='#8a3a2a';g.fillRect(36-w2/2,30+i,w2,1);}
    g.fillStyle='#6a4a2a';for(let i=-30;i<=30;i++){g.fillRect(36+i,40+Math.round(i*.9),2,2);g.fillRect(36+i,40-Math.round(i*.9),2,2);}g.fillStyle='#f4ead0';g.fillRect(8,12,12,16);g.fillRect(52,52,12,16);g.fillRect(50,12,14,12);g.fillRect(8,54,12,14);disc(g,36,40,4,'#3a2a1a');});
  T('well',28,32,g=>{kR(g,2,18,24,14,'#8a8894');kR(g,4,20,20,4,'#3a7ac8');kR(g,3,4,2,16,'#5a3a22');kR(g,23,4,2,16,'#5a3a22');kR(g,0,2,28,4,'#8a3a2a');kR(g,12,6,4,6,'#6a4a2a');});
  T('bench',30,14,g=>{kR(g,0,4,30,3,'#7a5232');kR(g,0,0,30,2,'#7a5232');kR(g,2,7,3,7,'#5a3a22');kR(g,25,7,3,7,'#5a3a22');});
  T('table',30,20,g=>{kR(g,0,4,30,6,'#8a6440');kR(g,0,4,30,1,'#a8845a');kR(g,3,10,3,10,'#5a3a22');kR(g,24,10,3,10,'#5a3a22');kR(g,6,0,6,5,'#e8dcc0');kR(g,18,1,5,4,'#f2c14e');});
  T('target',22,30,g=>{kR(g,9,18,4,12,'#5a3a22');disc(g,11,11,10,'#e8dcc0');disc(g,11,11,7,'#c83a3a');disc(g,11,11,4,'#e8dcc0');disc(g,11,11,2,'#c83a3a');});
  T('rack',32,28,g=>{kR(g,0,24,32,4,'#5a3a22');kR(g,2,6,2,20,'#5a3a22');kR(g,28,6,2,20,'#5a3a22');kR(g,0,8,32,2,'#7a5232');for(const x of [7,13,19,25]){kR(g,x,0,2,22,'#c8ccd4');kR(g,x-1,18,4,2,'#8a6440');}});
  T('cart',40,28,g=>{kR(g,4,6,32,12,'#8a6440');kR(g,4,6,32,2,'#a8845a');disc(g,10,22,5,'#5a3a22');disc(g,30,22,5,'#5a3a22');disc(g,10,22,2,'#8a6440');disc(g,30,22,2,'#8a6440');kR(g,8,2,10,6,'#c8a040');kR(g,22,2,10,5,'#c83a3a');});
  T('fence',16,14,g=>{kR(g,0,4,16,2,'#8a6440');kR(g,0,9,16,2,'#8a6440');kR(g,2,0,2,14,'#6a4a2a');kR(g,12,0,2,14,'#6a4a2a');});
}
function buildKingdomSprites(){MSPR.mannequin=rowSet(DUMMY,DUMMY,{S:'#d8c890',K:'#3a2a1a',B:'#a8843a',R:'#c83a3a',W:'#6a4a2a'},2);}

/* ---------- livres de la bibliothèque ---------- */
const KBOOKS={solarix:[
  ['La Charte de l’Aube',"Quand la Fracture déchira le ciel, sept familles se réfugièrent derrière la pierre blanche. Elles jurèrent de ne jamais laisser un éclat aux mains de l’Ombre. Cette charte est encore lue à chaque couronnement."],
  ['Aldéric le Bâtisseur',"Le premier roi d’Aurelia ne savait pas lire. Il fit graver ses lois sur les murs de la ville pour que chacun puisse les toucher. On dit que les gardes les récitent encore en faisant leur ronde."],
  ['Traité des grimoires',"Un grimoire n’enseigne pas : il réveille. Le sort dort déjà dans celui qui le lit, mais la page est la clé. Brûler un grimoire, c’est condamner un sort à dormir pour toujours."],
  ['Chronique de la Frontière',"Trente bannières ont flotté sur le Fort Brisé. Aucune n’est restée plus d’une saison. Les vieux soldats disent que le fort appartient à ceux qui l’oublient."]],
 umbra:[
  ['Le Premier Conclave',"Ils étaient sept mages bannis du royaume de l’Aube. Dans la forêt sans lune, ils plantèrent un éclat et attendirent. L’Arbre d’Ombre poussa en une nuit, et Nocthar naquit sous ses branches."],
  ['Morgane l’Éveillée',"La reine n’a jamais dormi depuis son couronnement, dit-on. Ses yeux restent ouverts sur le Prisme brisé, et ses rêves passent dans ceux de ses sujets."],
  ['Traité des grimoires',"Un grimoire n’enseigne pas : il réveille. Le sort dort déjà dans celui qui le lit, mais la page est la clé. Brûler un grimoire, c’est condamner un sort à dormir pour toujours."],
  ['Les Corbeaux de la Frontière',"Nos éclaireurs envoient leurs messages par corbeau. Un corbeau qui revient sans message signifie que la Frontière a changé de maître."]]};
const _readStele=readStele;readStele=function(s){if(s.grave){qEvent('read','grave');burst(s.x,s.y-12,'#e8e0ff',10);toast('Tu te recueilles','« Que la lumière garde ceux qui dorment ici. »');return;}if(!s.book)return _readStele(s);const [t,x]=KBOOKS[P.fac][s.book-1],key='book:'+P.fac+s.book,first=codexAdd(key);if(first)gainXp(Math.round(xpNeed(P.lvl)*.05*xpMult()));qEvent('read','book'+s.book);openPanel('lore',{t,x,first});};
const _codexEntries=codexEntries;codexEntries=function(){const out=_codexEntries();for(const k in P.codex)if(k.startsWith('book:')){const f=k.slice(5,-1),i=+k.slice(-1);if(KBOOKS[f]&&KBOOKS[f][i-1])out.push({cat:'Bibliothèque',t:KBOOKS[f][i-1][0],x:KBOOKS[f][i-1][1]});}return out;};
const _codexTotal=codexTotal;codexTotal=function(){return _codexTotal()+4;};

/* ---------- quêtes du royaume ---------- */
const KQ={roi:'roi',temple:'temple',taverne:'taverne',biblio:'biblio',banque:'banque'};
const _qGiverName=qGiverName;qGiverName=function(q){if(KQ[q])return NPC_DEF[P.fac][q][0];return _qGiverName(q);};
const _qGiverPlace=qGiverPlace;qGiverPlace=function(q){if(KQ[q])return FACTIONS[P.fac].capN;return _qGiverPlace(q);};
const _objText=objText;objText=function(q,j,st){const o=q.obj[j];if(o.k==='read'&&o.map&&o.map.startsWith('book')){const pr=st?objProg(q,st,j):0;return{t:'Lire « '+KBOOKS[P.fac][+o.map.slice(4)-1][0]+' »',pr,n:o.n,done:pr>=o.n};}if(o.k==='kill'&&o.m==='mannequin'){const pr=st?objProg(q,st,j):0;return{t:'Abattre des mannequins d’entraînement',pr,n:o.n,done:pr>=o.n};}return _objText(q,j,st);};
function buildKingdomQuests(){const Q=(id,o)=>{QDB[id]=Object.assign({id,chain:'side',lvl:1},o);const q=QDB[id];q.rew=Object.assign({},q.rew,{xp:Math.round(xpNeed(Math.max(1,q.lvl))*(id==='K6'?.6:.3)/10)*10});};
  Q('K1',{giver:'roi',t:'Audience royale',d:"Tu arrives dans mon royaume avec une épée et beaucoup de questions. Avant de servir {fac}, connais ceux qui la font vivre : la prêtresse, l’aubergiste, l’archiviste et le trésorier.",obj:[{k:'talk',q:'temple',n:1},{k:'talk',q:'taverne',n:1},{k:'talk',q:'biblio',n:1},{k:'talk',q:'banque',n:1}],rew:{xp:120,gold:60,cons:{pv:3}},fin:"Tu connais maintenant le cœur de {cap}. Il bat pour toi aussi."});
  Q('K2',{giver:'roi',req:'K1',t:'L’épreuve des mannequins',d:"Mes soldats s’entraînent derrière la caserne. Frappe les mannequins jusqu’à en abattre cinq : je veux voir ta main avant de voir ton nom sur une liste de morts.",obj:[{k:'kill',m:'mannequin',n:5}],rew:{xp:160,gold:80,cons:{pm:3}},fin:"Une main sûre. La Frontière en aura besoin."});
  Q('K3',{giver:'biblio',t:'Les archives du royaume',d:"Quatre ouvrages reposent sur les pupitres devant la bibliothèque. Lis-en trois, et tu comprendras pourquoi nous nous battons.",obj:[{k:'read',map:'book1',n:1},{k:'read',map:'book2',n:1},{k:'read',map:'book3',n:1}],rew:{xp:180,gold:40},fin:"Savoir pourquoi on se bat rend les coups plus justes."});
  Q('K4',{giver:'taverne',lvl:3,t:'Une tournée pour la garde',d:"La garde a soif et ma réserve de viande est vide. Ramène-moi de quoi cuisiner : abats huit {pm1b} dans {z1}.",obj:[{k:'kill',m:'{m1b}',n:8}],rew:{xp:220,gold:70,cons:{plat2:3}},fin:"La garde boira à ta santé ce soir !"});
  Q('K5',{giver:'temple',lvl:4,t:'Les âmes du cimetière',d:"Les morts de notre cimetière dorment mal depuis la Fracture. Prie sur trois tombes au sud-ouest du temple, puis reviens.",obj:[{k:'read',map:'grave',n:3}],rew:{xp:200,gold:50,cons:{elxp:1}},fin:"Leur sommeil est plus calme. Le tien le sera aussi."});
  Q('K6',{giver:'roi',req:'K2',lvl:14,t:'Faveur royale',d:"Le royaume récompense ceux qui grandissent à son service. Atteins le niveau 15 et reviens me voir.",obj:[{k:'level',n:15}],rew:{xp:900,gold:400,item:2},fin:"Prends cet équipement des armureries royales. Tu l’as mérité."});}
const _objTextG=objText;objText=function(q,j,st){const o=q.obj[j];if(o.k==='read'&&o.map==='grave'){const pr=st?objProg(q,st,j):0;return{t:'Prier sur les tombes du cimetière',pr,n:o.n,done:pr>=o.n};}return _objTextG(q,j,st);};

/* ---------- génération du royaume ---------- */
genCity=function(id){
  const d=MAPS[id],w=KW,h=KH,m=newMap(id,w,h,'city'),R=mulberry(strSeed(id)),st=d.style,fac=d.side,mir=st==='s';
  const X=x=>mir?w-1-x:x,PX=x=>(mir?w-1-x:x)*TS+8,PY=y=>y*TS;
  const STREET=st==='o'?GT.PLAZA:GT.DECK,BLOCK=st==='o'?GT.STONE:GT.MOSS,GREEN=st==='o'?GT.MEADOW:GT.MOON;
  m.blocked=new Uint8Array(w*h);
  const T=(x,y,gt,sol)=>{x=Math.round(x);y=Math.round(y);if(x<0||y<0||x>=w||y>=h)return;const i=y*w+X(x);m.gr[i]=gt;m.sol[i]=sol?1:0;m.blocked[i]=1;};
  const fill=(x0,y0,x1,y1,gt,sol)=>{for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++)T(x,y,gt,sol);};
  const solid=(x,y)=>{x=Math.round(x);y=Math.round(y);if(x>=0&&y>=0&&x<w&&y<h)m.sol[y*w+X(x)]=1;};
  const prop=(k,x,y,o)=>addProp(m,k,PX(x)-8+(o&&o.dx||0),PY(y),o);
  const build=(k,x,y,wins)=>{const S=PROPS[k],wT=S.w/TS,hT=Math.max(2,Math.round(S.h*.42/TS));for(let yy=Math.round(y-hT);yy<y;yy++)for(let xx=Math.round(x-wT/2+.5);xx<Math.round(x+wT/2-.5);xx++)solid(xx,yy);
    return addProp(m,k,PX(x)-8,PY(y),{fade:true,house:1,win:(wins||[]).map(([wx,wy])=>[PX(x)-8+(mir?-wx:wx),PY(y)-wy])});};
  // sol : campagne, ville, rues
  fill(0,0,w-1,h-1,GREEN,0);
  fill(6,5,92,79,BLOCK,0);
  const street=(x0,y0,x1,y1)=>fill(x0,y0,x1,y1,STREET,0);
  street(8,41,111,43);street(49,20,51,77);street(10,30,90,31);street(10,58,90,59);street(28,8,29,77);street(72,8,73,77);
  for(let y=-7;y<=7;y++)for(let x=-7;x<=7;x++)if(x*x+y*y<=50)T(50+x,42+y,STREET,0);
  // jardins du palais, parcs
  fill(34,19,66,29,GREEN,0);street(49,19,51,29);fill(38,23,41,25,GT.WATER,1);fill(59,23,62,25,GT.WATER,1);
  fill(52,61,70,76,GREEN,0);fill(58,66,63,70,GT.WATER,1);fill(10,8,27,13,GREEN,0);fill(10,60,15,77,GREEN,0);
  // champs hors les murs
  for(let k=0;k<4;k++)fill(96,8+k*7,108,12+k*7,GT.MUD,0);for(let k=0;k<3;k++)fill(96,52+k*8,108,56+k*8,GT.MUD,0);
  // remparts et porte
  for(let x=6;x<=92;x++)for(const y of [5,79]){T(x,y,BLOCK,1);prop((x%10===0)?'tower_'+st:'wall_'+st,x,y+1,{wall:1});}
  for(let y=6;y<79;y++)for(const x of [6,92]){const gate=x===92&&y>=40&&y<=44;if(gate)continue;T(x,y,BLOCK,1);prop((y%10===0||(x===92&&(y===39||y===45)))?'tower_'+st:'wall_'+st,x,y+1,{wall:1});}
  fill(92,40,92,44,STREET,0);
  // bordure d'arbres
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const e=Math.min(x,y,w-1-x,h-1-y),gateRoad=x>92&&y>=40&&y<=44;if(e<2&&!gateRoad){solid(x,y);if((x+y)%2===0)prop(st==='o'?'oak':'moon',x,y+1,{fade:true,border:1});}}
  for(let k=0;k<26;k++){const x=94+Math.floor(R()*16),y=3+Math.floor(R()*78);if(Math.abs(y-42)<4||m.gr[y*w+X(x)]===GT.MUD)continue;solid(x,y);prop(R()<.5?'oak':'oak2',x,y+1,{fade:true});}
  m.exits.push({dir:mir?'w':'e',to:d.ex[mir?'w':'e'],a:39,b:45});
  // place centrale
  for(let y=-1;y<=1;y++)for(let x=-1;x<=1;x++)solid(50+x,42+y);
  if(st==='o')prop('fountain',50.5,44,{fountain:1});else prop('mothertree',50.5,44,{fade:true,big:1});
  for(const [x,y] of [[44,36],[56,36],[44,48],[56,48],[42,42],[58,42]])prop('lamp',x,y,{light:{r:64,c:'#ffd890'}});
  for(const [x,y] of [[45,38],[55,38],[45,47],[55,47]])prop('banner_'+fac,x,y);
  prop('board',53.4,46.2);m.board={x:PX(53.4)-8,y:PY(46.4)};m.signs.push({x:m.board.x,y:m.board.y-30,t:'Primes'});
  // palais
  build('palace_'+st,50,18,[[ -60,80],[60,80],[0,120]]);prop('throne_'+st,50,21.2);solid(50,20);
  for(const [x,y] of [[44,22],[56,22],[44,28],[56,28]])prop('statue_'+st,x,y);for(const x of [36,64])for(const y of [20,27])prop('hedge',x,y);
  for(const x of [43,47,53,57])prop('flowerbed',x,26);for(const [x,y] of [[47,21],[53,21]])prop('banner_'+fac,x,y);
  m.signs.push({x:PX(50)-8,y:PY(30)-6,t:'Palais royal'});
  // bibliothèque (nord-ouest)
  build('library_'+st,19,21,[[-40,40],[40,40]]);m.signs.push({x:PX(19)-8,y:PY(29)-4,t:'Grande Bibliothèque'});
  [[13,26],[17,27],[21,27],[25,26]].forEach(([x,y],i)=>{prop('lectern',x,y);solid(x,y-1);m.steles.push({x:PX(x)-8,y:PY(y)+8,book:i+1,map:'book'+(i+1)});});
  for(const [x,y] of [[11,10],[15,9],[23,10],[26,12]])prop('oak',x,y,{fade:true});
  // caserne et terrain d'entraînement (nord-est)
  build('barracks_'+st,82,15,[[-50,50],[50,50]]);m.signs.push({x:PX(82)-8,y:PY(29)-4,t:'Caserne royale'});
  for(const [x,y] of [[76,23],[79,25],[82,23],[85,25],[88,23]])m.spawns.push({type:'mannequin',lv:1,x:PX(x)-8+8,y:PY(y)+8});
  for(const x of [76,80,84,88])prop('target',x,19.6);prop('rack',90,20);prop('rack',75,27.5);
  // hôtel des ventes, banque (au nord de l'avenue)
  build('kingdomhouse2_'+st,62,39,[[-30,26],[30,26]]);build('bank_'+st,39,39,[[0,40]]);
  m.signs.push({x:PX(62)-8,y:PY(33)-4,t:'Hôtel des ventes'});
  // artisans (ouest)
  build('forgeb_'+st,16,40,[[30,40]]);build('kingdomhouse_'+st,24,52,[[-20,24],[20,24]]);
  prop('anvil',21,41);prop('crate',11,40.6);prop('barrel',12,41.2);prop('crate',26,54.2);prop('barrel',19,53.6);prop('cart',13,56);
  m.signs.push({x:PX(18)-8,y:PY(33)-4,t:'Quartier des artisans'});
  // marché (sud-ouest de la place)
  for(const [x,y,k] of [[33,48,'stall_red'],[38,48,'stall_grey'],[43,52,'stall_red'],[33,54,'stall_grey'],[38,55,'stall_red']])prop(k,x,y);
  prop('crate',35,50.6);prop('barrel',41,50.4);prop('cart',45,56);m.signs.push({x:PX(39)-8,y:PY(46)-4,t:'Marché'});
  // taverne (sud-est de la place)
  build('tavern_'+st,62,54,[[-40,40],[40,40]]);for(const [x,y] of [[56,56.4],[68,56.4]])prop('table',x,y);for(const [x,y] of [[55,57.4],[67,57.4]])prop('bench',x,y);prop('barrel',70,55);
  // maison des guildes (est, sud de l'avenue)
  build('guildhall_'+st,82,55,[[-36,40],[36,40]]);
  // temple et cimetière (sud-ouest)
  build('temple_'+st,20,70,[[0,80]]);m.signs.push({x:PX(20)-8,y:PY(61)-4,t:st==='o'?'Temple de l’Aube':'Sanctuaire de la Lune'});
  const graves=[[11,63],[13,63],[11,66],[13,66],[11,69],[13,69],[11,72],[13,72]];graves.forEach(([x,y],i)=>{prop('grave',x,y);solid(x,y-1);if(i<4)m.steles.push({x:PX(x)-8,y:PY(y)+8,grave:1,map:'grave'});});
  for(const x of [16,24])prop('flowerbed',x,74);
  // quartiers d'habitation
  const homes=[[34,66],[42,66],[34,74],[42,74],[78,66],[86,66],[78,74],[86,74],[36,36],[64,66]];
  homes.forEach(([x,y],i)=>build((i%2?'kingdomhouse2_':'kingdomhouse_')+st,x,y,[[-14,26],[14,26]]));
  prop('well',60,64);for(const [x,y] of [[54,63],[67,63],[55,73],[68,72]])prop('oak',x,y,{fade:true});prop('bench',58,72);
  // lampadaires et bannières
  for(let x=14;x<=88;x+=8)if(Math.abs(x-50)>8){prop('lamp',x,40,{light:{r:60,c:'#ffd890'}});prop('lamp',x,45.5,{light:{r:60,c:'#ffd890'}});}
  for(let y=24;y<=74;y+=10)if(Math.abs(y-42)>8){prop('lamp',48,y,{light:{r:60,c:'#ffd890'}});prop('lamp',52.6,y,{light:{r:60,c:'#ffd890'}});}
  for(const y of [38,46])prop('banner_'+fac,90.4,y);m.signs.push({x:PX(92)-8,y:PY(38)-6,t:st==='o'?'Porte de l’Aube':'Porte du Crépuscule'});
  // campagne
  for(let k=0;k<4;k++)for(let x=97;x<=107;x+=2)prop('crop',x,9.6+k*7+2);for(let k=0;k<3;k++)for(let x=97;x<=107;x+=2)prop('crop',x,53.6+k*8+2);
  build('windmill',102,37,[]);build('kingdomhouse2_'+st,103,49,[[-14,26],[14,26]]);for(const [x,y] of [[98,36],[108,47],[96,48]])prop('haystack',x,y);
  for(let x=95;x<=109;x++)if(x%2===0){prop('fence',x,38.4);prop('fence',x,46.8);}
  // PNJ
  const pos={quest:[50,37],event:[46,46.6],shop:[38,50.4],forge:[19.6,42],trainer:[78,21.4],war:[86,21.4],hdv:[62,40.4],guild:[82,56.6],craft:[24,53.6],
    roi:[50,22.4],banque:[39,40.4],temple:[20,71.6],taverne:[62,55.6],biblio:[19,22.6]};
  for(const role in pos){const [nx,ny]=pos[role],nd=NPC_DEF[fac][role],look=Object.assign({},NPC_LOOK[role],fac==='umbra'&&KUMBRA[role]||{});
    m.npcs.push({role,fac,qid:role==='quest'?'cap':KQ[role]||null,n:nd[0],r:nd[1],x:PX(nx)-8+8,y:PY(ny),look});}
  m.stations=[{k:'alambic',x:PX(21)-8,y:PY(55.2)},{k:'pupitre',x:PX(27)-8,y:PY(55.2)},{k:'enclume',x:PX(22.6)-8,y:PY(42.2)}];for(const s of m.stations)addProp(m,s.k,s.x,s.y);
  // gardes
  for(const [gx,gy] of [[90,39],[90,46],[46,22],[54,22],[47,30.5],[53,30.5],[76,29],[30,41],[50,57]])m.guards.push({x:PX(gx)-8+8,y:PY(gy),fac,dir:'d'});
  // habitants
  const cols=fac==='solarix'?['#8a4a3a','#4a6a8a','#7a7a3a','#c8a050','#3a7a6a','#9a6a3a']:['#4a3a6a','#3a4a5a','#5a3a5a','#2a4a4a','#6a4a7a','#3a3a4a'];
  const homesC=[[50,47],[40,52],[60,57],[20,45],[24,57],[80,24],[62,44],[50,33],[20,74],[36,62],[80,62],[102,44],[100,58],[40,45],[30,50],[84,48],[56,66],[14,28],[70,40],[100,30]];
  for(const [hx,hy] of homesC){const farmer=hx>93;m.citizens.push({x:PX(hx),y:PY(hy),hx:PX(hx),hy:PY(hy),tx:0,ty:0,wt:0,anim:0,dir:'d',moving:false,look:{hair:pick(['#3a2a1a','#d8b048','#8a3a1a','#e8e0d0','#2a2a2a']),hairStyle:pick(['short','long','pony']),body:farmer?'#8a7a4a':pick(cols),legs:pick(['#4a3a2a','#3a3a4a','#5a4a3a']),belt:'#4a3a2a',extra:farmer?'hood':'none',hood:'#c8a050'}});}
  m.spawnPt={x:PX(50),y:PY(49)};
  return m;};
