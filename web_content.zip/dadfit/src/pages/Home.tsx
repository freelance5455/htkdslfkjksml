import { format } from 'date-fns';
import { ArrowRight, CalendarDays, Flame, Footprints, Gauge, Route, Timer } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useApp } from '../context';
import ProgressRing from '../components/ProgressRing';
import ActivityButton from '../components/ActivityButton';
import DailyPlan from '../components/DailyPlan';
import StreakBadge from '../components/StreakBadge';
import AlarmBanner from '../components/AlarmBanner';

export default function Home(){
 const {profile,todayCalories,yesterdayCalories,todaySteps,todayDistance,todayMinutes,streak}=useApp();
 if(!profile) return null;
 const messages=todayCalories===0?['Let’s make today count — start with an easy walk.']:todayCalories<profile.calorieGoal*0.35?['Great start. A little more movement will build momentum.']:todayCalories<profile.calorieGoal?['Nice work. Keep moving at a comfortable pace.']:['Daily activity goal reached. Great job — recover well!'];
 return <div className="mx-auto max-w-xl px-4 pb-4 pt-5"><AlarmBanner/><header className="mb-6 flex items-start justify-between gap-3"><div><div className="flex items-center gap-2"><h1 className="text-3xl font-black tracking-tight">Today’s Progress</h1><StreakBadge days={streak}/></div><p className="mt-2 flex items-center gap-2 text-base font-semibold text-slate-600 dark:text-slate-300"><CalendarDays size={18}/> {format(new Date(),'EEEE, d MMMM yyyy')}</p></div></header>
 <section className="rounded-[2rem] border border-slate-200 bg-white p-5 shadow-soft dark:border-slate-700 dark:bg-slate-900"><ProgressRing value={todayCalories} max={profile.calorieGoal} label={`${todayCalories} kcal`} sublabel={`goal ${profile.calorieGoal} kcal`}/><div className="mt-4 grid grid-cols-2 gap-3"><Stat label="Yesterday" value={`${yesterdayCalories} kcal`} icon={Flame}/><Stat label="Today so far" value={`${todayCalories} kcal`} icon={Gauge}/></div></section>
 <div className="mt-4 grid grid-cols-3 gap-3"><Mini label="Steps" value={todaySteps.toLocaleString()} icon={Footprints}/><Mini label="Distance" value={`${todayDistance.toFixed(1)} km`} icon={Route}/><Mini label="Active" value={`${todayMinutes} min`} icon={Timer}/></div>
 <section className="mt-7"><div className="mb-3 flex items-end justify-between"><div><h2 className="text-2xl font-extrabold">Start an activity</h2><p className="text-base text-slate-600 dark:text-slate-300">Log it when you finish.</p></div></div><div className="grid grid-cols-2 gap-3">{(['walking','running','cycling','exercise'] as const).map(t=><ActivityButton key={t} type={t}/>)}</div></section>
 <DailyPlan/>
 {todayCalories===0 && <div className="mt-5 rounded-3xl border border-amber-200 bg-amber-50 p-5 dark:border-amber-900 dark:bg-amber-950"><div className="text-xl font-extrabold text-amber-900 dark:text-amber-100">No activity logged today</div><p className="mt-1 text-base text-amber-800 dark:text-amber-200">Continue now with a gentle walk, or start fresh tomorrow. Monday is your rest day.</p></div>}
 <div className="mt-7 rounded-3xl bg-sky-50 p-5 dark:bg-sky-950"><p className="text-xl font-extrabold text-sky-900 dark:text-sky-100">{messages[0]}</p><p className="mt-2 text-base text-sky-800 dark:text-sky-200">24-week target: <b>{profile.targetWeightKg} kg</b> (planning estimate).</p><Link to="/history" className="mt-4 inline-flex items-center gap-2 font-extrabold text-sky-700 dark:text-sky-300">View activity history <ArrowRight size={20}/></Link></div>
 </div>
}
function Stat({label,value,icon:Icon}:{label:string,value:string,icon:React.ElementType}){return <div className="rounded-2xl bg-slate-50 p-4 dark:bg-slate-800"><Icon className="mb-2 text-emerald-600" size={24}/><div className="text-xl font-black">{value}</div><div className="text-sm font-semibold text-slate-600 dark:text-slate-300">{label}</div></div>}
function Mini({label,value,icon:Icon}:{label:string,value:string,icon:React.ElementType}){return <div className="rounded-2xl border border-slate-200 bg-white p-3 text-center dark:border-slate-700 dark:bg-slate-900"><Icon className="mx-auto mb-1 text-emerald-600" size={22}/><div className="text-lg font-black">{value}</div><div className="text-sm font-semibold text-slate-500">{label}</div></div>}
