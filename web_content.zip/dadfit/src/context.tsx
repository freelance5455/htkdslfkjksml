import { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { AppData, ActivityEntry, ActivityType, Intensity, UserProfile } from './types';
import { dateKey } from './lib/dates';
import { defaultPlan, getDayRecord, saveData, setDayRecord } from './lib/storage';
import { caloriesBurned } from './lib/fitness';

interface AppContextValue {
  data: AppData;
  today: string;
  profile: UserProfile | null;
  completePlanItem: (id: string) => void;
  addActivity: (input: Omit<ActivityEntry, 'id' | 'date' | 'calories' | 'createdAt'>) => ActivityEntry | null;
  updateProfile: (profile: UserProfile) => void;
  setTheme: (theme: 'light' | 'dark') => void;
  setAlarmEnabled: (enabled: boolean) => void;
  dismissAlarm: () => void;
  resetAll: () => void;
  getDayActivities: (key: string) => ActivityEntry[];
  todayCalories: number;
  todaySteps: number;
  todayDistance: number;
  todayMinutes: number;
  yesterdayCalories: number;
  streak: number;
}

const AppContext = createContext<AppContextValue | null>(null);

function initialData(): AppData {
  const raw = localStorage.getItem('dadfit-app-v1');
  try { return raw ? JSON.parse(raw) as AppData : { version: 1, profile: null, activities: [], daily: {}, theme: 'light', alarmEnabled: true }; }
  catch { return { version: 1, profile: null, activities: [], daily: {}, theme: 'light', alarmEnabled: true }; }
}

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [data, setData] = useState<AppData>(() => initialData());
  const today = dateKey();

  useEffect(() => {
    if (!data.profile) return;
    const current = getDayRecord(data, today);
    if (!current.plan.length) {
      const next = setDayRecord(data, { ...current, plan: defaultPlan(data.profile), lastOpenedAt: new Date().toISOString() });
      setData(next); saveData(next);
    } else if (current.lastOpenedAt === undefined) {
      const next = setDayRecord(data, { ...current, lastOpenedAt: new Date().toISOString() });
      setData(next); saveData(next);
    }
  }, [data.profile, today]);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', data.theme === 'dark');
    document.documentElement.style.colorScheme = data.theme;
  }, [data.theme]);

  const profile = data.profile;
  const todayActivities = data.activities.filter(a => a.date === today);
  const yesterday = dateKey(new Date(Date.now() - 86400000));
  const yesterdayActivities = data.activities.filter(a => a.date === yesterday);
  const todayCalories = todayActivities.reduce((s, a) => s + a.calories, 0);
  const todaySteps = todayActivities.reduce((s, a) => s + (a.steps ?? 0), 0);
  const todayDistance = todayActivities.reduce((s, a) => s + (a.distanceKm ?? 0), 0);
  const todayMinutes = todayActivities.reduce((s, a) => s + a.durationMin, 0);
  const yesterdayCalories = yesterdayActivities.reduce((s, a) => s + a.calories, 0);

  const streak = useMemo(() => {
    let count = 0;
    let cursor = new Date();
    // Monday is the weekly rest day and never breaks a streak.
    for (let i = 0; i < 370; i++) {
      if (cursor.getDay() === 1) { cursor = new Date(cursor.getTime() - 86400000); continue; }
      const key = dateKey(cursor);
      const acts = data.activities.filter(a => a.date === key);
      const record = data.daily[key];
      const active = acts.length > 0 || record?.plan?.some(p => p.completed);
      if (!active) break;
      count++;
      cursor = new Date(cursor.getTime() - 86400000);
    }
    return count;
  }, [data.activities, data.daily]);

  function persist(next: AppData) { setData(next); saveData(next); }

  function completePlanItem(id: string) {
    const record = getDayRecord(data, today);
    const plan = (record.plan.length ? record.plan : (profile ? defaultPlan(profile) : [])).map(p => p.id === id ? { ...p, completed: !p.completed } : p);
    persist(setDayRecord(data, { ...record, plan }));
  }

  function addActivity(input: Omit<ActivityEntry, 'id' | 'date' | 'calories' | 'createdAt'>) {
    if (!profile || input.durationMin <= 0) return null;
    const entry: ActivityEntry = {
      ...input,
      id: crypto.randomUUID(),
      date: today,
      calories: caloriesBurned(input.activity, input.intensity, profile.weightKg, input.durationMin),
      createdAt: new Date().toISOString()
    };
    persist({ ...data, activities: [entry, ...data.activities] });
    return entry;
  }

  function updateProfile(nextProfile: UserProfile) {
    persist({ ...data, profile: { ...nextProfile, updatedAt: new Date().toISOString() } });
  }
  function setTheme(theme: 'light' | 'dark') { persist({ ...data, theme }); }
  function setAlarmEnabled(alarmEnabled: boolean) { persist({ ...data, alarmEnabled }); }
  function dismissAlarm() { persist({ ...data, alarmDismissedDate: today }); }
  function resetAll() { localStorage.removeItem('dadfit-app-v1'); window.location.href = '/'; }
  function getDayActivities(key: string) { return data.activities.filter(a => a.date === key); }

  const value = { data, today, profile, completePlanItem, addActivity, updateProfile, setTheme, setAlarmEnabled, dismissAlarm, resetAll, getDayActivities, todayCalories, todaySteps, todayDistance, todayMinutes, yesterdayCalories, streak };
  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const value = useContext(AppContext);
  if (!value) throw new Error('useApp must be used inside AppProvider');
  return value;
}
