import { useEffect } from 'react';
import { Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useApp } from './context';
import Onboarding from './pages/Onboarding';
import Home from './pages/Home';
import ActivityLog from './pages/ActivityLog';
import History from './pages/History';
import Settings from './pages/Settings';
import BottomNav from './components/BottomNav';
import { dateKey } from './lib/dates';
import { isAfterAlarmToday, isAlarmTime, showAlarmNotification, showReminderNotification } from './lib/notifications';
import { isMonday } from './lib/dates';

function Shell(){const {profile,data}=useApp(); const loc=useLocation(); useEffect(()=>{ if(!profile) return; const today=dateKey(); const alarmCheck=async()=>{const now=new Date(); if(!isMonday(now)&&isAlarmTime(now)&&data.alarmEnabled&&data.alarmDismissedDate!==today){await showAlarmNotification();} }; void alarmCheck(); const reminder=async()=>{const now=new Date(); if(!isMonday(now)&&isAfterAlarmToday(now)&&now.getHours()>=20){const activities=data.activities.filter(a=>a.date===today);const plan=data.daily[today]?.plan??[];if(!activities.length&&!plan.some(p=>p.completed)&&!data.daily[today]?.reminderShown){await showReminderNotification();}}}; void reminder();},[profile,data]); if(!profile)return <Routes><Route path="*" element={<Onboarding/>}/></Routes>; return <div className="min-h-screen bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-white"><motion.div key={loc.pathname} initial={{opacity:0,y:8}} animate={{opacity:1,y:0}} transition={{duration:.2}}><Routes><Route path="/" element={<Home/>}/><Route path="/activity/:type" element={<ActivityLog/>}/><Route path="/history" element={<History/>}/><Route path="/settings" element={<Settings/>}/><Route path="*" element={<Navigate to="/" replace/>}/></Routes></motion.div><BottomNav/></div>}
export default Shell;
