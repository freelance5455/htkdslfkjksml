const ALARM_HOUR = 5;
const ALARM_MINUTE = 30;

export function isAlarmTime(date = new Date()) {
  return date.getHours() === ALARM_HOUR && date.getMinutes() === ALARM_MINUTE;
}

export function isAfterAlarmToday(date = new Date()) {
  const minutes = date.getHours() * 60 + date.getMinutes();
  return minutes >= ALARM_HOUR * 60 + ALARM_MINUTE;
}

export async function requestNotifications() {
  if (!('Notification' in window)) return 'unsupported' as const;
  if (Notification.permission === 'granted') return 'granted' as const;
  if (Notification.permission === 'denied') return 'denied' as const;
  return Notification.requestPermission();
}

export async function showAlarmNotification() {
  if (!('Notification' in window) || Notification.permission !== 'granted') return false;
  const registration = await navigator.serviceWorker?.ready;
  if (registration) {
    await registration.showNotification('DadFit – Time to move', {
      body: 'Good morning! Start today’s walk and keep your streak going.',
      icon: '/icon-192.png',
      badge: '/icon-192.png',
      tag: 'dadfit-morning-alarm',
      requireInteraction: true,
      vibrate: [300, 120, 300]
    } as NotificationOptions);
    return true;
  }
  new Notification('DadFit – Time to move', { body: 'Good morning! Start today’s walk and keep your streak going.', icon: '/icon-192.png' });
  return true;
}

export async function showReminderNotification() {
  if (!('Notification' in window) || Notification.permission !== 'granted') return false;
  const registration = await navigator.serviceWorker?.ready;
  const options: NotificationOptions = {
    body: 'You have not logged today’s plan yet. Continue now or start fresh tomorrow.',
    icon: '/icon-192.png',
    badge: '/icon-192.png',
    tag: 'dadfit-daily-reminder',
    requireInteraction: true,
    vibrate: [200, 100, 200]
  };
  if (registration) await registration.showNotification('DadFit reminder', options);
  else new Notification('DadFit reminder', options);
  return true;
}

export { ALARM_HOUR, ALARM_MINUTE };
