import { AppData, DailyRecord, DayPlan, UserProfile } from '../types';

const KEY = 'dadfit-app-v1';

const blank: AppData = {
  version: 1,
  profile: null,
  activities: [],
  daily: {},
  theme: 'light',
  alarmEnabled: true
};

export function loadData(): AppData {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return structuredClone(blank);
    const parsed = JSON.parse(raw) as Partial<AppData>;
    return {
      ...blank,
      ...parsed,
      activities: parsed.activities ?? [],
      daily: parsed.daily ?? {},
      theme: parsed.theme === 'dark' ? 'dark' : 'light',
      alarmEnabled: parsed.alarmEnabled !== false
    };
  } catch {
    return structuredClone(blank);
  }
}

export function saveData(data: AppData) {
  localStorage.setItem(KEY, JSON.stringify(data));
}

export function resetData() {
  localStorage.removeItem(KEY);
}

export function getDayRecord(data: AppData, date: string): DailyRecord {
  return data.daily[date] ?? { date, plan: [] };
}

export function setDayRecord(data: AppData, record: DailyRecord): AppData {
  return { ...data, daily: { ...data.daily, [record.date]: record } };
}

export function defaultPlan(profile: UserProfile): DayPlan[] {
  const stepTarget = Math.max(1200, Math.round(profile.stepsGoal * 0.45));
  const afternoonMin = Math.round(Math.max(15, Math.min(30, 20 + (profile.age < 55 ? 5 : 0))));
  const eveningMin = Math.round(Math.max(10, Math.min(20, 15 + (profile.age < 60 ? 5 : 0))));
  return [
    { id: 'morning', title: 'Morning Walk', subtitle: 'Gentle brisk walk', target: `${stepTarget.toLocaleString()} steps`, completed: false },
    { id: 'afternoon', title: 'Afternoon Activity', subtitle: 'Walk, cycle or easy movement', target: `${afternoonMin} min`, completed: false },
    { id: 'evening', title: 'Evening Workout', subtitle: 'Light strength & mobility', target: `${eveningMin} min`, completed: false }
  ];
}
