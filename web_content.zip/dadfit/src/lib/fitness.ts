import { ActivityType, Intensity, UserProfile } from '../types';

const MET: Record<ActivityType, Record<Intensity, number>> = {
  walking: { easy: 3.5, moderate: 4.0, hard: 4.5 },
  running: { easy: 7.0, moderate: 8.5, hard: 10.0 },
  cycling: { easy: 6.0, moderate: 7.0, hard: 8.0 },
  exercise: { easy: 4.0, moderate: 5.0, hard: 6.0 }
};

export function calculateBmr(weightKg: number, heightCm: number, age: number) {
  return Math.round(10 * weightKg + 6.25 * heightCm - 5 * age + 5);
}

export function calculateCalorieGoal(bmr: number) {
  // Conservative planning value: estimated BMR + a light activity allowance, less ~500 kcal.
  // This is a planning estimate, not medical advice.
  return Math.max(1200, Math.round(bmr * 1.35 - 500));
}

export function calculateStepsGoal(weightKg: number, age: number) {
  const ageAdjustment = age >= 65 ? -500 : age >= 55 ? 0 : 500;
  const weightAdjustment = weightKg >= 100 ? -500 : weightKg <= 70 ? 500 : 0;
  return Math.min(10000, Math.max(7000, 8000 + ageAdjustment + weightAdjustment));
}

export function calculateTargetWeight(weightKg: number, heightCm: number) {
  const heightM = heightCm / 100;
  const bmi22_5Weight = 22.5 * heightM * heightM;
  return Math.max(bmi22_5Weight, weightKg * 0.90);
}

export function createProfile(weightKg: number, age: number, heightCm: number): UserProfile {
  const bmr = calculateBmr(weightKg, heightCm, age);
  return {
    weightKg,
    age,
    heightCm,
    bmr,
    calorieGoal: calculateCalorieGoal(bmr),
    stepsGoal: calculateStepsGoal(weightKg, age),
    targetWeightKg: Math.round(calculateTargetWeight(weightKg, heightCm) * 10) / 10,
    planWeeks: 24,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
}

export function caloriesBurned(activity: ActivityType, intensity: Intensity, weightKg: number, durationMin: number) {
  const met = MET[activity][intensity];
  return Math.round(met * weightKg * (durationMin / 60));
}
