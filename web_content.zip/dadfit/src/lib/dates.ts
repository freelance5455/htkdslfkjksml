import { format, subDays } from 'date-fns';

export const dateKey = (date = new Date()) => format(date, 'yyyy-MM-dd');
export const prettyDate = (date = new Date()) => format(date, 'EEEE, d MMMM yyyy');
export const shortDate = (key: string) => format(new Date(`${key}T12:00:00`), 'EEE, d MMM');
export const previousDateKey = (key: string) => dateKey(subDays(new Date(`${key}T12:00:00`), 1));
export const isMonday = (date = new Date()) => date.getDay() === 1;
