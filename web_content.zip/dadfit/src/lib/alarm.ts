let audio: HTMLAudioElement | null = null;

export function startAlarmSound() {
  stopAlarmSound();
  audio = new Audio('/alarm.wav');
  audio.loop = true;
  void audio.play().catch(() => undefined);
}

export function stopAlarmSound() {
  if (audio) {
    audio.pause();
    audio.currentTime = 0;
    audio = null;
  }
}
