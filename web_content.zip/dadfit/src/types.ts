export type ActivityType = 'walking' | 'running' | 'cycling' | 'exercise';
export type Intensity = 'easy' | 'moderate' | 'hard';

export interface UserProfile {
  weightKg: number;
  age: number;
  heightCm: number;
  bmr: number;
  calorieGoal: number;
  stepsGoal: number;
  targetWeightKg: number;
  planWeeks: number;
  createdAt: string;
  updatedAt: string;
}

export interface ActivityEntry {
  id: string;
  date: string;
  activity: ActivityType;
  durationMin: number;
  distanceKm?: number;
  steps?: number;
  intensity: Intensity;
  calories: number;
  notes?: string;
  createdAt: string;
}

export interface DayPlan {
  id: string;
  title: string;
  subtitle: string;
  target: string;
  completed: boolean;
}

export interface DailyRecord {
  date: string;
  plan: DayPlan[];
  reminderShown?: boolean;
  lastOpenedAt?: string;
}

export interface AppData {
  version: 1;
  profile: UserProfile | null;
  activities: ActivityEntry[];
  daily: Record<string, DailyRecord>;
  theme: 'light' | 'dark';
  alarmEnabled: boolean;
  alarmDismissedDate?: string;
  lastOpenedDate?: string;
}

export const ACTIVITY_LABELS: Record<ActivityType, string> = {
  walking: 'Walking',
  running: 'Running',
  cycling: 'Cycling',
  exercise: 'Exercise'
};
