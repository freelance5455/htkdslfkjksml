interface Props { value: number; max: number; label: string; sublabel: string; }
export default function ProgressRing({ value, max, label, sublabel }: Props) {
  const pct = max > 0 ? Math.min(100, Math.round((value / max) * 100)) : 0;
  const radius = 78;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (pct / 100) * circumference;
  return (
    <div className="relative mx-auto h-56 w-56" aria-label={`${pct}% complete`}>
      <svg className="h-full w-full -rotate-90" viewBox="0 0 180 180">
        <circle cx="90" cy="90" r={radius} fill="none" stroke="currentColor" strokeWidth="13" className="text-emerald-100 dark:text-slate-700" />
        <circle cx="90" cy="90" r={radius} fill="none" stroke="currentColor" strokeWidth="13" strokeLinecap="round" className="text-emerald-600 transition-all duration-700" strokeDasharray={circumference} strokeDashoffset={offset} />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
        <div className="text-4xl font-extrabold text-slate-900 dark:text-white">{label}</div>
        <div className="mt-1 text-lg font-semibold text-emerald-700 dark:text-emerald-400">{pct}%</div>
        <div className="text-sm text-slate-600 dark:text-slate-300">{sublabel}</div>
      </div>
    </div>
  );
}
