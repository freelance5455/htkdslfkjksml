import { useEffect, useState } from 'react';
import { BellRing, Square } from 'lucide-react';
import { isAlarmTime, requestNotifications, showAlarmNotification } from '../lib/notifications';
import { isMonday } from '../lib/dates';
import { startAlarmSound, stopAlarmSound } from '../lib/alarm';
import { useApp } from '../context';

export default function AlarmBanner() {
  const { data, dismissAlarm } = useApp();
  const [ringing, setRinging] = useState(false);
  useEffect(() => {
    if (!data.alarmEnabled) return;
    const check = async () => {
      const now = new Date();
      if (!isMonday(now) && isAlarmTime(now) && data.alarmDismissedDate !== now.toISOString().slice(0,10)) {
        setRinging(true); startAlarmSound(); await showAlarmNotification();
      }
    };
    void check();
    const timer = window.setInterval(check, 15000);
    return () => window.clearInterval(timer);
  }, [data.alarmEnabled, data.alarmDismissedDate]);
  if (!ringing) return <button onClick={() => void requestNotifications()} className="mb-4 flex w-full items-center gap-3 rounded-2xl border border-sky-200 bg-sky-50 p-4 text-left dark:border-sky-900 dark:bg-sky-950"><BellRing className="text-sky-600"/><span><b>5:30 AM alarm</b><span className="block text-sm text-slate-600 dark:text-slate-300">Tap to allow DadFit morning reminders.</span></span></button>;
  return <div className="fixed inset-x-4 top-4 z-50 rounded-3xl border-2 border-orange-400 bg-white p-5 shadow-2xl dark:bg-slate-900"><div className="flex items-center gap-3"><BellRing className="text-orange-500" size={34}/><div><div className="text-xl font-extrabold">Good morning — time to move!</div><div className="text-base text-slate-600 dark:text-slate-300">5:30 AM DadFit alarm</div></div></div><button onClick={()=>{stopAlarmSound();dismissAlarm();setRinging(false)}} className="mt-5 flex min-h-14 w-full items-center justify-center gap-2 rounded-2xl bg-slate-900 text-lg font-extrabold text-white dark:bg-white dark:text-slate-900"><Square size={20}/> Stop alarm</button></div>;
}
