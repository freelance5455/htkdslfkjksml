import { CheckCircle2, Circle } from 'lucide-react';
import { useApp } from '../context';
import { defaultPlan } from '../lib/storage';
export default function DailyPlan() {
  const { data, profile, today, completePlanItem } = useApp();
  const plan = data.daily[today]?.plan?.length ? data.daily[today].plan : profile ? defaultPlan(profile) : [];
  return <section className="mt-7">
    <div className="mb-3 flex items-end justify-between"><div><h2 className="text-2xl font-extrabold">Today’s plan</h2><p className="text-base text-slate-600 dark:text-slate-300">Simple steps toward your 24-week goal.</p></div></div>
    <div className="space-y-3">{plan.map(item => <button key={item.id} onClick={() => completePlanItem(item.id)} className="flex w-full items-center gap-4 rounded-2xl border border-slate-200 bg-white p-4 text-left shadow-sm dark:border-slate-700 dark:bg-slate-900">
      {item.completed ? <CheckCircle2 className="shrink-0 text-emerald-600" size={30} /> : <Circle className="shrink-0 text-slate-400" size={30} />}
      <span className="min-w-0 flex-1"><span className={`block text-lg font-extrabold ${item.completed ? 'text-emerald-700 line-through dark:text-emerald-400' : ''}`}>{item.title}</span><span className="block text-base text-slate-600 dark:text-slate-300">{item.subtitle} · <b>{item.target}</b></span></span>
    </button>)}</div>
  </section>;
}
