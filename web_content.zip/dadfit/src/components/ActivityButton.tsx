import { ActivityType } from '../types';
import { Bike, Dumbbell, Footprints, PersonStanding } from 'lucide-react';
import { Link } from 'react-router-dom';
const icons = { walking: Footprints, running: PersonStanding, cycling: Bike, exercise: Dumbbell };
const labels = { walking: 'Walking', running: 'Running', cycling: 'Cycling', exercise: 'Exercise' };
export default function ActivityButton({ type }: { type: ActivityType }) {
  const Icon = icons[type];
  return <Link to={`/activity/${type}`} className="flex min-h-28 flex-col items-center justify-center gap-2 rounded-3xl border border-slate-200 bg-white p-4 text-center shadow-soft transition active:scale-95 dark:border-slate-700 dark:bg-slate-900">
    <span className="rounded-2xl bg-emerald-50 p-3 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300"><Icon size={30} strokeWidth={2.2} /></span>
    <span className="font-bold text-slate-900 dark:text-white">{labels[type]}</span>
  </Link>;
}
