/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: 'class',
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      fontSize: { base: '18px' },
      boxShadow: { soft: '0 10px 35px rgba(15,118,110,.10)' }
    }
  },
  plugins: []
};
