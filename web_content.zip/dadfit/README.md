# DadFit – Daily Walk & Burn

A mobile-first, offline-first PWA for one user. Built with React + TypeScript + Vite + Tailwind CSS, React Router, date-fns and Framer Motion. All profile, activity, plan and history data is stored in localStorage.

## Features

- First-run onboarding: weight, age, height.
- Mifflin-St Jeor male BMR estimate.
- Gentle planning target around a 500 kcal daily deficit.
- 7,000–10,000 step target adjusted for age/weight.
- Conservative 24-week weight-loss planning target (maximum 10% initial-weight reduction; BMI-based floor is used to avoid an aggressive target).
- Walking, running, cycling and general exercise logging.
- MET-based calorie calculation by intensity.
- Daily plan with completion checkboxes.
- Daily streak with 🔥 and Monday rest-day handling.
- Last 30 days, plus individual activity entries retained separately.
- Dark mode and editable profile.
- PWA manifest, service worker and supplied reference-style app icon.
- 5:30 AM alarm/reminder setting, with Monday as the rest day.
- End-of-day reminder when the app is used/open and notifications are permitted.

## Important platform note about the 5:30 AM alarm

A browser PWA cannot guarantee an exact-time alarm while completely closed/offline on every Android and iOS version. Browsers intentionally restrict arbitrary background JavaScript timers. DadFit therefore implements the alarm in three layers: an in-app timer while the PWA is open, a service-worker notification when the browser permits it, and a notification permission flow. For guaranteed 5:30 AM alarms even when the app is closed, use the phone's native Alarm/Clock app alongside DadFit or add a push/OS-native backend in a future version.

## Run locally

```bash
npm install
npm run dev
```

Open the Vite URL shown in the terminal, normally `http://localhost:5173`.

Production build:

```bash
npm run build
npm run preview
```

For PWA installation, serve the production build over HTTPS (localhost is also treated as secure for development). On Android Chrome: open the site, choose the browser menu, then **Install app** / **Add to Home screen**. On iPhone Safari: Share → **Add to Home Screen**.

## Replit

1. Create a new Replit app from the uploaded project or import this folder.
2. Run `npm install`.
3. Set the run command to `npm run dev -- --host 0.0.0.0`.
4. Use Replit's web preview for development.
5. For installation on a phone, deploy the app to a public HTTPS URL. Open it on the phone and install it from the browser.

## Data model

Everything is in localStorage under `dadfit-app-v1`. Each activity entry has its own ID and date. Daily plan completion is stored separately by date. Reset All Data removes the complete local dataset and returns to onboarding.

## Safety / health note

The BMR, calorie and weight-loss values are estimates for planning. They are not a diagnosis or individualized medical prescription. The app deliberately uses a conservative 24-week planning horizon. If your father has a medical condition, takes medication affecting exercise/weight, or has been given a clinician's diet/exercise plan, follow that plan instead.
