HUSSAIN SECRET CODE — OFFLINE WEB APP SOURCE

This is a single-file offline-first web app source, not an Android APK.
Open index.html in a browser/viewer that supports JavaScript and Web Crypto. Some Android file:// viewers disable Web Crypto; for Secure Code use a Web Crypto-capable HTTPS/localhost viewer.

MODES
- Quick Code: updates automatically while typing and decodes automatically when a code is pasted. It is reversible obfuscation, NOT secure encryption.
- Secure Code: after entering text and a password of at least 8 characters, it automatically generates HSC1 code. Paste an HSC1 code and type the password to automatically recover the message.
- Secure mode uses Web Crypto AES-256-GCM with a random salt and nonce, and PBKDF2-SHA256 (250,000 iterations). This has not undergone an independent security audit.
- Messages/codes are not uploaded to a server or stored in a history by this app. Theme preferences may be stored locally in browser storage. Copy/share is user-initiated.

IMPORTANT
- Never reuse a weak password. Share the Secure Code and its password through separate channels.
- This ZIP contains HTML source only; it does not contain an APK and has not been APK-tested.
