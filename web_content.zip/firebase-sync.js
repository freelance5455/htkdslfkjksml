/**
 * Firebase Cloud Firestore Real-Time Sync Service
 * Maa Annapurna Tiffin Management System
 * Features:
 * - Automatic background cloud sync (Zero manual setup)
 * - Automatic user profile creation on first login
 * - Real-time cross-device sync (doc.onSnapshot)
 * - Offline-first caching with automatic catch-up
 * - Multi-tenant security isolation (tiffin_users/{userId})
 * - Developer Export / Import Database capabilities
 */

class FirebaseSyncService {
  constructor() {
    this.unsubscribeSnapshot = null;
    this.saveTimeout = null;
    this.isSyncing = false;
    this.lastSavedTimestamp = null;
    this.collectionName = 'tiffin_users';
  }

  get db() {
    return FirebaseAppManager.db;
  }

  isConfigured() {
    return FirebaseAppManager.isInitialized;
  }

  getUserDocRef() {
    const userId = FirebaseAuth.getUserId();
    if (!this.db || !userId) return null;
    return this.db.collection(this.collectionName).doc(userId);
  }

  /**
   * Update Navigation Sync Indicator Badge
   */
  updateIndicator(status) {
    const badge = document.getElementById('cloudSyncStatusBadge');
    if (!badge) return;

    if (!FirebaseAppManager.isCloudSyncEnabled()) {
      badge.className = 'badge-soft-purple text-[10.5px] font-bold px-2 py-0.5 rounded-lg flex items-center space-x-1';
      badge.innerHTML = '<span class="w-1.5 h-1.5 rounded-full bg-purple-500"></span><span>⏸️ Sync Paused</span>';
      return;
    }

    if (status === 'syncing') {
      badge.className = 'badge-soft-amber text-[10.5px] font-bold px-2 py-0.5 rounded-lg flex items-center space-x-1';
      badge.innerHTML = '<span class="w-1.5 h-1.5 rounded-full bg-amber-500 animate-ping"></span><span>☁️ Syncing to Cloud...</span>';
    } else if (status === 'synced') {
      badge.className = 'badge-soft-emerald text-[10.5px] font-bold px-2 py-0.5 rounded-lg flex items-center space-x-1';
      badge.innerHTML = '<span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span><span>☁️ Cloud: Synced</span>';
    } else if (status === 'offline') {
      badge.className = 'badge-soft-purple text-[10.5px] font-bold px-2 py-0.5 rounded-lg flex items-center space-x-1';
      badge.innerHTML = '<span class="w-1.5 h-1.5 rounded-full bg-purple-500"></span><span>☁️ Offline Cache</span>';
    } else if (status === 'sandbox') {
      badge.className = 'badge-soft-emerald text-[10.5px] font-bold px-2 py-0.5 rounded-lg flex items-center space-x-1';
      badge.innerHTML = '<span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span><span>☁️ Cloud: Synced</span>';
    }
  }

  /**
   * Automatically Initialize User Profile & Partition in Firestore
   */
  async initUserProfile(user) {
    if (!user || !user.uid) return;

    const userProfile = {
      uid: user.uid,
      displayName: user.displayName || 'Maa Annapurna Admin',
      email: user.email || '',
      phoneNumber: user.phoneNumber || '',
      businessName: 'Maa Annapurna Tiffin Service',
      location: 'Kunwar Singh Nagar',
      phone: '+91 9311155593',
      lastLogin: new Date().toISOString()
    };

    AppLogger.info('Provisioning user profile in cloud database...', user.uid);

    // Save to local cache
    try {
      localStorage.setItem('MAT_USER_PROFILE', JSON.stringify(userProfile));
    } catch (e) {}

    const docRef = this.getUserDocRef();
    if (!docRef || !FirebaseAppManager.isCloudSyncEnabled()) return;

    try {
      await docRef.set({ userProfile }, { merge: true });
      AppLogger.success('User profile synced to cloud Firestore', user.uid);
    } catch (err) {
      AppLogger.warn('Cloud profile provision note (offline storage active):', err.message);
    }
  }

  /**
   * Save User Data to Cloud Firestore (Automatic Debounced Cloud Backup)
   */
  saveUserData(payload, immediate = false) {
    // Keep local fast storage backup
    try {
      localStorage.setItem('MAT_LOCAL_CACHE', JSON.stringify(payload));
    } catch (e) {}

    if (!FirebaseAppManager.isCloudSyncEnabled() || !FirebaseAuth.isAuthenticated()) {
      this.updateIndicator('offline');
      return Promise.resolve(true);
    }

    if (this.saveTimeout) {
      clearTimeout(this.saveTimeout);
      this.saveTimeout = null;
    }

    const delay = immediate ? 0 : 500;

    return new Promise((resolve) => {
      this.updateIndicator('syncing');

      this.saveTimeout = setTimeout(async () => {
        try {
          const docRef = this.getUserDocRef();
          if (!docRef) {
            this.updateIndicator('offline');
            resolve(false);
            return;
          }

          const cleanPayload = {
            clients: payload.clients || [],
            boxStates: payload.boxStates || {},
            qrDatabase: payload.qrDatabase || [],
            logs: payload.logs || [],
            settings: payload.settings || {},
            weeklyMenu: payload.weeklyMenu || {},
            customMenus: payload.customMenus || [],
            extraItemsCatalog: payload.extraItemsCatalog || [],
            menuItemsList: payload.menuItemsList || [],
            userProfile: {
              uid: FirebaseAuth.getUserId(),
              email: FirebaseAuth.getUserEmail(),
              phoneNumber: FirebaseAuth.getUserPhone(),
              displayName: FirebaseAuth.getUserDisplayName(),
              lastSync: new Date().toISOString()
            },
            updatedAt: new Date().toISOString()
          };

          await docRef.set(cleanPayload, { merge: true });

          this.lastSavedTimestamp = cleanPayload.updatedAt;
          this.updateIndicator('synced');
          AppLogger.success('All tiffin data backed up & synced to Cloud Firestore', {
            clients: cleanPayload.clients.length,
            boxes: cleanPayload.qrDatabase.length
          });
          resolve(true);
        } catch (err) {
          AppLogger.warn('Cloud save notice, stored in offline cache:', err.message);
          this.updateIndicator('offline');
          resolve(false);
        }
      }, delay);
    });
  }

  /**
   * Fetch User Data from Cloud Firestore (Restore on new device)
   */
  async fetchUserData() {
    if (!FirebaseAuth.isAuthenticated()) {
      return null;
    }

    // Try fetching from Firestore
    if (FirebaseAppManager.isCloudSyncEnabled()) {
      try {
        this.updateIndicator('syncing');
        const docRef = this.getUserDocRef();
        if (docRef) {
          const docSnap = await docRef.get();
          if (docSnap.exists) {
            const data = docSnap.data();
            this.updateIndicator('synced');
            AppLogger.success('Tiffin data restored from Cloud Firestore', data.updatedAt);
            return data;
          }
        }
      } catch (err) {
        AppLogger.warn('Firestore fetch notice, loading from local offline cache:', err.message);
      }
    }

    // Fallback to local cache
    try {
      const cached = localStorage.getItem('MAT_LOCAL_CACHE');
      if (cached) {
        this.updateIndicator('offline');
        return JSON.parse(cached);
      }
    } catch (e) {}

    return null;
  }

  /**
   * Real-Time Cross-Device Synchronization
   */
  listenToRealtimeUpdates(callback) {
    if (this.unsubscribeSnapshot) {
      this.unsubscribeSnapshot();
      this.unsubscribeSnapshot = null;
    }

    if (!FirebaseAppManager.isCloudSyncEnabled() || !FirebaseAuth.isAuthenticated()) {
      return;
    }

    const docRef = this.getUserDocRef();
    if (!docRef) return;

    try {
      this.unsubscribeSnapshot = docRef.onSnapshot((docSnapshot) => {
        if (!docSnapshot.exists) return;

        const remoteData = docSnapshot.data();
        if (remoteData.updatedAt && remoteData.updatedAt === this.lastSavedTimestamp) {
          return; // Ignore own echo
        }

        AppLogger.info('Real-time sync update received from Cloud Firestore');
        this.updateIndicator('synced');

        if (typeof callback === 'function') {
          callback(remoteData);
        }
      }, (error) => {
        AppLogger.warn('Firestore snapshot listener notice:', error.message);
        this.updateIndicator('offline');
      });
    } catch (e) {
      AppLogger.warn('Could not setup Firestore onSnapshot:', e.message);
    }
  }

  /**
   * Developer Tool: Export Entire Database as JSON File
   */
  exportDatabaseJSON() {
    try {
      const data = {
        exportedAt: new Date().toISOString(),
        user: {
          uid: FirebaseAuth.getUserId(),
          email: FirebaseAuth.getUserEmail(),
          phone: FirebaseAuth.getUserPhone()
        },
        clients: window.clients || [],
        logs: window.logs || [],
        boxStates: window.boxStates || {},
        qrDatabase: window.qrDatabase || [],
        weeklyMenu: window.weeklyMenu || {},
        customMenus: window.customMenus || [],
        extraItemsCatalog: window.extraItemsCatalog || [],
        menuItemsList: window.menuItemsList || [],
        settings: window.settings || {}
      };

      const jsonStr = JSON.stringify(data, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `maa-annapurna-db-backup-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      AppLogger.success('Database backup exported successfully');
      return true;
    } catch (err) {
      AppLogger.error('Database export error:', err.message);
      throw err;
    }
  }

  /**
   * Developer Tool: Import Database from JSON File
   */
  async importDatabaseJSON(jsonContent) {
    try {
      const parsed = typeof jsonContent === 'string' ? JSON.parse(jsonContent) : jsonContent;
      if (!parsed || (!parsed.clients && !parsed.qrDatabase)) {
        throw new Error('Invalid database format. File must contain clients or qrDatabase.');
      }

      if (window.applyLoadedCloudData) {
        window.applyLoadedCloudData(parsed);
      }
      if (window.saveData) {
        window.saveData(true);
      }

      AppLogger.success('Database successfully imported & synced to cloud');
      return true;
    } catch (err) {
      AppLogger.error('Database import failed:', err.message);
      throw err;
    }
  }

  cleanup() {
    if (this.unsubscribeSnapshot) {
      this.unsubscribeSnapshot();
      this.unsubscribeSnapshot = null;
    }
    if (this.saveTimeout) {
      clearTimeout(this.saveTimeout);
      this.saveTimeout = null;
    }
  }
}

// Global Singleton Instance
window.FirebaseSync = new FirebaseSyncService();
