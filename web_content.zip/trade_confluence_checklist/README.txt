TRADE CONFLUENCE CHECKLIST — HTML TO APK PACKAGE

Files:
- index.html: the complete app (HTML, CSS and JavaScript in one file).

How to use:
1. Open index.html in Chrome or your preferred browser to test it.
2. In your HTML-to-APK converter, import index.html or the ZIP, depending on the converter's supported workflow.
3. Set the app name to "Trade Confluence".
4. Enable JavaScript and local storage in the converter/WebView settings.
5. If offered, enable file upload access if you want to import JSON backups. Some converters may handle file inputs differently.
6. Build the APK and test saving a setup, closing/reopening the app, and exporting a backup.

Features:
- Live confluence score with default weights totaling 7 points.
- Configurable score weights and minimum R:R.
- Buy/Sell trend alignment, BOS, Fibonacci, and entry trigger checks.
- Entry, stop-loss, and take-profit validation.
- R:R and potential account-gain calculations.
- Local trade journal, result recording, analytics, JSON backup/restore, and CSV export.
- Qualified, rejected, and incomplete setups can be saved to the journal.

Important:
- All data is stored locally in the WebView/browser localStorage. Uninstalling the APK or clearing app data can erase records. Export JSON backups regularly.
- The app does not fetch market prices, connect to a broker, or automatically verify chart structure.
- This is a journal/checklist, not financial advice.
