WAFA NANO Android Project
=========================

App: WAFA NANO
Package: com.wafananosocial
Web app: V20 real-loading/offline splash

Wannan project an shirya shi ne domin a gina APK ba tare da wani wrapper branding ba.

A waya:
1. Bude project din da Android IDE/Android build environment mai goyon bayan Gradle.
2. Open/Import wannan folder.
3. Sync Gradle.
4. Build -> APK / assembleDebug domin gwaji.
5. Don release: configure signing key sannan assembleRelease.

Muhimmi: kada a saka Gemini API key ko Supabase service_role key cikin app.
Supabase anon key kawai ya kasance a client idan RLS yana aiki yadda ya kamata.
