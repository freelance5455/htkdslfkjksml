# WAFA NANO release rules
