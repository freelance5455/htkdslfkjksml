# Baba Tiloo Game

## Files
- `index.html` — complete responsive website (HTML, CSS and JavaScript in one file).
- `Baba-Tiloo-Website-Banner.png` — Baba Tiloo hero banner used by the homepage.
- `PROMPT-FOR-CHANGES.txt` — prompt to use when asking an AI to modify this project.

## Publish with GitHub Pages
1. Extract this ZIP on your device.
2. Upload `index.html` and `Baba-Tiloo-Website-Banner.png` to the root of your `baba-tiloo-game` GitHub repository.
3. Commit the files.
4. In repository Settings → Pages, choose Deploy from a branch, select `main` and `/ (root)`, then Save.
5. Wait for GitHub Pages to publish and open the URL shown there.

## Important
The included Admin/Game Manager is a browser-local demo. It stores games in that browser only. A secure admin login and shared online game catalogue require a backend/database and must be added separately. No real games are preloaded. Some external game URLs may block embedding; this version opens games in a new tab.
