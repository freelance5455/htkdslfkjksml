# My To-Do ✨ — HTML App

Open `index.html` in a browser. Tasks are saved locally on the device using localStorage.

To turn it into an APK, use any trusted HTML/WebView-to-APK builder that accepts a local HTML file.
