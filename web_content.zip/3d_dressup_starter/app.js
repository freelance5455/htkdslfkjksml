import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.164.1/build/three.module.js';
import { GLTFLoader } from 'https://cdn.jsdelivr.net/npm/three@0.164.1/examples/jsm/loaders/GLTFLoader.js';
import { OrbitControls } from 'https://cdn.jsdelivr.net/npm/three@0.164.1/examples/jsm/controls/OrbitControls.js';

const canvas = document.querySelector('#scene');
const statusBox = document.querySelector('#status');
const loading = document.querySelector('#loading');
const scene = new THREE.Scene();
scene.background = new THREE.Color('#f4e6f1');
const camera = new THREE.PerspectiveCamera(35, 1, 0.1, 100);
camera.position.set(0, 1.5, 5.8);
const renderer = new THREE.WebGLRenderer({canvas, antialias:true, alpha:false});
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;

scene.add(new THREE.HemisphereLight(0xffffff, 0x9b7894, 2.1));
const key = new THREE.DirectionalLight(0xffffff, 2.4); key.position.set(3,5,4); key.castShadow=true; scene.add(key);
const fill = new THREE.DirectionalLight(0xffcce8, 1.1); fill.position.set(-4,2,-3); scene.add(fill);

const floor = new THREE.Mesh(new THREE.CircleGeometry(3.3, 64), new THREE.MeshStandardMaterial({color:'#e8d4e4', roughness:.95}));
floor.rotation.x = -Math.PI/2; floor.position.y=-1.08; floor.receiveShadow=true; scene.add(floor);
const controls = new OrbitControls(camera, renderer.domElement);
controls.target.set(0,0.1,0); controls.enableDamping=true; controls.dampingFactor=.06; controls.minDistance=2.5; controls.maxDistance=9;
const loader = new GLTFLoader();
let character = null, clothes = [], rotating = false, dressMaterial = null;
const characterGroup = new THREE.Group(); scene.add(characterGroup);

function material(color, roughness=.72){return new THREE.MeshStandardMaterial({color,roughness,metalness:0.02});}
function mesh(geo, mat, x,y,z, parent=characterGroup){const m=new THREE.Mesh(geo,mat);m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;parent.add(m);return m;}
function makeStarterCharacter(){
  characterGroup.clear(); clothes=[];
  const skin=material('#dca783'), hair=material('#4a2d31'), top=material('#e84b8a'), pants=material('#51435f'), shoes=material('#f6edf4');
  dressMaterial=top;
  // Stylized mannequin starter, intended to be replaced by the user's own GLB.
  mesh(new THREE.SphereGeometry(.23,32,24),skin,0,.68,0);
  mesh(new THREE.SphereGeometry(.245,32,24,0,Math.PI*2,0,Math.PI*.58),hair,0,.75,-.035);
  mesh(new THREE.CapsuleGeometry(.12,.52,6,16),skin,-.29,.08,0).rotation.z=.08;
  mesh(new THREE.CapsuleGeometry(.12,.52,6,16),skin,.29,.08,0).rotation.z=-.08;
  mesh(new THREE.CapsuleGeometry(.14,.55,6,16),pants,-.115,-.58,0).rotation.z=.035;
  mesh(new THREE.CapsuleGeometry(.14,.55,6,16),pants,.115,-.58,0).rotation.z=-.035;
  mesh(new THREE.BoxGeometry(.28,.12,.42),shoes,-.115,-.95,.06);
  mesh(new THREE.BoxGeometry(.28,.12,.42),shoes,.115,-.95,.06);
  mesh(new THREE.CapsuleGeometry(.28,.48,8,24),top,0,.12,0);
  // Simple skirt
  const skirt=mesh(new THREE.CylinderGeometry(.22,.42,.4,32),top,0,-.27,0);
  skirt.scale.z=.8;
  character=characterGroup;
}
makeStarterCharacter();

function setStatus(text){statusBox.textContent=text;}
function disposeObject(obj){obj.traverse?.(n=>{if(n.geometry)n.geometry.dispose(); if(n.material){for(const m of (Array.isArray(n.material)?n.material:[n.material]))m.dispose?.();}});}
function fitObject(obj, targetHeight=2.0){
  const box=new THREE.Box3().setFromObject(obj);
  if(box.isEmpty()) return;
  const size=box.getSize(new THREE.Vector3());
  const maxDim=Math.max(size.x,size.y,size.z);
  if(maxDim>0)obj.scale.multiplyScalar(targetHeight/maxDim);
  const newBox=new THREE.Box3().setFromObject(obj);
  const center=newBox.getCenter(new THREE.Vector3());
  obj.position.x-=center.x; obj.position.y-=newBox.min.y+1.05; obj.position.z-=center.z;
}
async function loadModel(file, asClothes=false){
  if(!file) return;
  const url=URL.createObjectURL(file);
  loading.style.display='grid'; loading.textContent='جارٍ تحميل النموذج...';
  try{
    const gltf=await loader.loadAsync(url);
    const obj=gltf.scene;
    obj.traverse(n=>{if(n.isMesh){n.castShadow=true;n.receiveShadow=true;}});
    if(asClothes){
      // Keep original scale and position as much as possible; artists should export clothes aligned to origin.
      fitObject(obj, 1.7);
      clothes.push(obj); scene.add(obj);
      setStatus('تمت إضافة قطعة الملابس. إذا لم تكن فوق الشخصية، عدّل موضعها/حجمها في برنامج التصميم ثم صدّر GLB من جديد.');
    }else{
      if(character && character!==characterGroup){scene.remove(character);disposeObject(character);}
      characterGroup.clear(); characterGroup.add(obj); character=obj; fitObject(obj,2.0);
      setStatus('تم استيراد الشخصية بنجاح. يمكنك الآن إضافة ملفات الملابس.');
    }
  }catch(e){
    console.error(e); setStatus('تعذّر فتح الملف. جرّب تصديره بصيغة GLB وتأكد أن الملف سليم.');
  }finally{URL.revokeObjectURL(url);loading.style.display='none';}
}
document.querySelector('#characterFile').addEventListener('change',e=>loadModel(e.target.files[0],false));
document.querySelector('#clothesFile').addEventListener('change',e=>loadModel(e.target.files[0],true));
document.querySelector('#resetCharacter').addEventListener('click',()=>{
  if(character && character!==characterGroup){scene.remove(character);disposeObject(character);}
  makeStarterCharacter(); setStatus('تم إرجاع الشخصية التجريبية.');
});
document.querySelector('#clearClothes').addEventListener('click',()=>{
  clothes.forEach(o=>{scene.remove(o);disposeObject(o)});clothes=[];
  setStatus('تم حذف قطع الملابس التي أضفتها.');
});
document.querySelectorAll('[data-color]').forEach(b=>b.addEventListener('click',()=>{
  const c=new THREE.Color(b.dataset.color);
  let found=false;
  characterGroup.traverse(n=>{if(n.isMesh && n.material && n.material.color){n.material.color.copy(c);found=true;}});
  if(!found && character && character!==characterGroup) character.traverse(n=>{if(n.isMesh && n.material && n.material.color)n.material.color.copy(c);});
  setStatus('تم تطبيق اللون على مواد الشخصية التجريبية/النموذج. قد لا تتغير كل المواد إذا كان النموذج يستخدم خامات متعددة.');
}));
document.querySelector('#turntable').addEventListener('click',()=>{rotating=!rotating;setStatus(rotating?'الدوران التلقائي يعمل.':'تم إيقاف الدوران التلقائي.');});
document.querySelector('#homeCamera').addEventListener('click',()=>{camera.position.set(0,1.5,5.8);controls.target.set(0,0.1,0);controls.update();});
function resize(){const w=canvas.clientWidth,h=canvas.clientHeight;renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix();}
new ResizeObserver(resize).observe(canvas); resize(); loading.style.display='none';
function animate(){requestAnimationFrame(animate);if(rotating)characterGroup.rotation.y+=.008;controls.update();renderer.render(scene,camera);}
animate();
