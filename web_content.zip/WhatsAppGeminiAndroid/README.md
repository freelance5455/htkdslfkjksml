# WhatsApp Gemini Bot — Android Studio project

This project packages the supplied `whatsapp_gemini_bot.html` as an Android app using a Kotlin WebView wrapper.

## Build an APK

1. Install Android Studio on a computer.
2. Open this folder (`WhatsAppGeminiAndroid`) in Android Studio.
3. Allow Gradle sync to finish and install the requested Android SDK platform if prompted.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the generated APK location, normally:
   `app/build/outputs/apk/debug/app-debug.apk`

For a distributable release, use **Build → Generate Signed Bundle / APK** and create your own signing key.

## Notes

- Your original HTML is bundled at `app/src/main/assets/index.html`.
- The wrapper enables JavaScript and DOM storage because the page uses JavaScript and localStorage.
- Internet permission is included because the page loads Tailwind/Google Fonts from CDNs and can call the Gemini API.
- This packages the existing page; it does not turn the simulator into a real WhatsApp automation service. The Node.js bridge is a separate setup and requires its own runtime and WhatsApp account linking.
- The HTML currently stores its optional Gemini API key in browser localStorage. Treat that key as a secret; anyone with access to the app's local data may be able to retrieve it. For a production app, use a secure backend rather than embedding a long-lived API key in the client.
