// ---------- jogador e estado da partida ----------
const novoP=()=>({x:3,y:4.7,z:7,vy:0,yaw:.55,pitch:-.05,vida:100,fome:90,ar:15,sel:0,inv:Array(36).fill(null),armadura:[null,null,null,null,null],moedas:5,casa:null,correndo:false,passo:0,recarga:0,golpe:0,efeitos:{},voando:false,barco:null,pesca:null,marca:null,quebrando:null,noChao:true,sub:0,submerso:false,zoom:false,isca:null,proxEvento:150,corpoSujo:true,andou:0,minerado:{},forma:0,modoObra:'um',montaria:null});
let P=novoP();
const entrada={f:0,l:0,correr:false,atacando:false,pular:false,descer:false};
let estado='menu',emPartida=false,comecou=false,hora=.3,dia=1,construcoes=[],stats={},rotObra=0,alvoAtual=null,tempo=0,MODO='sobrevivencia',META=null,corpoJogador=null;
const criativo=()=>MODO==='criativo';
const novasStats=()=>({coletado:{},fabricado:{},mortos:{},construido:{},falou:{},baus:{},vilas:{},noites:{},cavernas:{},chefes:{},quebrou:{},plantou:{},pescou:{},domou:{}});
function contar(cat,chave,q=1){const s=stats[cat];s[chave]=(s[chave]||0)+q;verificarMissoes()}
const total=cat=>Object.values(stats[cat]).reduce((a,b)=>a+b,0);
const pes=()=>P.y-1.7;
// ---------- inventário ----------
const tem=id=>id==='moeda'?P.moedas:P.inv.reduce((s,c)=>s+(c&&c[0]===id?c[1]:0),0);
function adicionar(id,q){if(id==='moeda'){P.moedas+=q;return 0}const pilha=ITENS[id].pilha;
 for(const c of P.inv)if(q&&c&&c[0]===id&&c[1]<pilha){const n=Math.min(q,pilha-c[1]);c[1]+=n;q-=n}
 for(let i=0;i<P.inv.length&&q;i++)if(!P.inv[i]){const n=Math.min(q,pilha);P.inv[i]=[id,n];q-=n}
 atualizarBarra();return q}
function remover(id,q){if(criativo())return;for(let i=P.inv.length-1;i>=0&&q;i--){const c=P.inv[i];if(c&&c[0]===id){const n=Math.min(q,c[1]);c[1]-=n;q-=n;if(!c[1])P.inv[i]=null}}atualizarBarra()}
function gastar(i=P.sel){if(criativo())return;const c=P.inv[i];if(c&&--c[1]<=0)P.inv[i]=null;atualizarBarra()}
function trocarItem(novo,i=P.sel){if(criativo())return;const c=P.inv[i];if(c[1]<=1)P.inv[i]=[novo,1];else{c[1]--;if(adicionar(novo,1))soltar(novo,1,P.x,P.z,pes())}atualizarBarra()}
function pegar(id,q){const resto=adicionar(id,q),n=q-resto;if(n){avisar(`+${n} ${ITENS[id].n}`,2.2);contar('coletado',id,n);som(id==='moeda'?'moeda':'pegar',.7)}if(resto){avisar('Mochila cheia',2);soltar(id,resto,P.x,P.z,pes());M.chao[M.chao.length-1].espera=5}return n}
const naMao=()=>P.inv[P.sel]?ITENS[P.inv[P.sel][0]]:null;
const defesa=()=>Math.min(.8,P.armadura.reduce((s,c)=>s+(c&&ITENS[c[0]].defesa||0),0));
function equipar(i){const c=P.inv[i];if(!c)return false;const it=ITENS[c[0]];if(it.slot===undefined)return false;const antes=P.armadura[it.slot];P.armadura[it.slot]=c;P.inv[i]=antes;P.corpoSujo=true;som('equipar');avisar(`Equipado: ${it.n}`,2);atualizarBarra();return true}
function desequipar(s){const c=P.armadura[s];if(!c)return;const resto=adicionar(c[0],c[1]);if(resto===c[1]){avisar('Mochila cheia',2);return}P.armadura[s]=resto?[c[0],resto]:null;P.corpoSujo=true;som('equipar');atualizarBarra()}
const NOME_EFEITO={veloz:'Velocidade',salto:'Salto alto',folego:'Fôlego',forca:'Força'};
function comer(i){const c=P.inv[i];if(!c)return;const it=ITENS[c[0]];if(it.cat!=='comida')return;
 if(it.efeito){P.efeitos[it.efeito]=90;gastar(i);som('comer');avisar(`${NOME_EFEITO[it.efeito]} por 90 segundos`,3);return}
 if(P.vida>=100&&P.fome>=99&&it.cura>=0){avisar('Você está bem alimentado',2);return}
 P.fome=clamp(P.fome+it.comida,0,100);P.vida=clamp(P.vida+it.cura,1,100);gastar(i);som('comer');avisar(it.cura<0?`${it.n}: isso fez mal`:it.comida?`Comeu ${it.n.toLowerCase()}`:`Usou ${it.n.toLowerCase()}`,2)}
function largar(){const s=P.inv[P.sel];if(!s)return;const[fx,fz]=frente();soltar(s[0],1,P.x+fx*2.5,P.z+fz*2.5,pes()+.4);M.chao.at(-1).espera=2;if(!--s[1])P.inv[P.sel]=null;atualizarBarra()}
const pertoDe=est=>!est||criativo()||M.estacoes.some(s=>s.tipo===est&&dist2(s.x,s.z,P.x,P.z)<5);
const podeFazer=r=>pertoDe(r.est)&&(criativo()||Object.entries(r.ing).every(([id,q])=>tem(id)>=q));
function fabricar(r){if(!podeFazer(r))return;for(const[id,q]of Object.entries(r.ing))remover(id,q);const resto=adicionar(r.id,r.qtd);if(resto)soltar(r.id,resto,P.x,P.z,pes());som('criar');avisar(`Criado: ${r.qtd>1?r.qtd+'× ':''}${ITENS[r.id].n}`,2);contar('fabricado',r.id,r.qtd);salvar()}

// ---------- mira ----------
const frente=()=>[-Math.sin(P.yaw),-Math.cos(P.yaw)];
const dirOlhar=()=>{const c=Math.cos(P.pitch);return[-Math.sin(P.yaw)*c,Math.sin(P.pitch),-Math.cos(P.yaw)*c]};
function mirar(lista,alcance,raioDe){const[fx,fz]=frente();let melhor=null,md=1e9;
 for(const o of lista){const dx=o.x-P.x,dz=o.z-P.z;if(Math.abs(dx)>alcance+4||Math.abs(dz)>alcance+4)continue;const r=raioDe(o),f=dx*fx+dz*fz,l=Math.abs(dx*fz-dz*fx),d=Math.hypot(dx,dz);
  if(f<=0||d-r>alcance||l>r+.35+f*.22)continue;const nota=d-r+l*.6;if(nota<md){md=nota;melhor=o}}return melhor?{o:melhor,d:md}:null}
const raioRec=r=>Math.max(RECURSOS[r.tipo].raio*r.s,.45);
function raioTerreno(max){const t=raioT([P.x,P.y,P.z],dirOlhar(),max);return t&&{t:t.t,x:t.x,y:t.y,z:t.z,n:t.n}}
function raioAguaMar(max){const d=dirOlhar();for(let t=.5;t<max;t+=.25){const x=P.x+d[0]*t,y=P.y+d[1]*t,z=P.z+d[2]*t;if(y<altura(x,z))return null;if(y<.05&&altura(x,z)<-.3)return{t,x,y:0,z}}return null}
// o que está na mira para atacar: criatura, bloco, recurso, obra ou chão
function alvoAtaque(){const it=naMao(),alcance=it?Math.min(it.alcance,4.2):2.4,vox=raioVox([P.x,P.y,P.z],dirOlhar(),5.2),dv=vox?vox.t:1e9;
 const vivo=mirar(seres.filter(e=>!e.morte&&P.barco!==e&&P.montaria!==e&&e.y<P.y+1.2&&e.y+e.def.alt>pes()-1),alcance,e=>e.def.raio);
 if(vivo&&vivo.d<dv+.4){const rec=mirar(recursosPerto(),alcance,raioRec);if(!rec||vivo.d<rec.d+.8)return{tipo:'ser',o:vivo.o}}
 const rec=mirar(recursosPerto().filter(r=>Math.abs(r.y-pes())<4),Math.min(alcance,3),raioRec),obra=mirar(construcoes.filter(c=>Math.abs(c.y-pes())<3),2.6,c=>c.tipo==='farol'?1.3:.6);
 if(obra&&it&&it.ferramenta&&it.id!=='tocha'&&obra.d<dv&&(!rec||obra.d<rec.d))return{tipo:'obra',o:obra.o};
 if(rec&&rec.d<dv-.2&&P.pitch>-.95)return{tipo:'rec',o:rec.o};
 if(vox&&BLOCOS[vox.n].solido){const t=raioTerreno(dv);if(!t)return{tipo:'vox',o:vox}}
 if(rec)return{tipo:'rec',o:rec.o};
 const t=raioTerreno(Math.min(4.6,dv));if(t&&(!it||['pa','picareta','machado','martelo'].includes(it.ferramenta)||it.id==='martelo'||it.cat==='recurso'||it.cat==='cubo'))return{tipo:'terra',o:t};return null}

// ---------- ataque, mineração e coleta ----------
function atacar(){if(estado!=='jogando')return;const it=naMao();if(P.barco&&!it)return;
 if(it&&(it.cat==='ovo'||it.cat==='comida'||it.cat==='bloco')){if(P.recarga<=0){P.recarga=.4;usarItem()}return}
 if(it&&it.distancia){if(P.recarga>0)return;P.golpe=1;if(!criativo()&&!tem('flecha')){avisar('Sem flechas. Crie mais na mesa de artesanato.',2.5);P.recarga=.6;return}remover('flecha',1);P.recarga=it.cad;
  const d=dirOlhar(),v=it.id==='besta'?60:42,f=P.efeitos.forca?1.35:1;atirar(P.x+d[0]*.6,P.y-.12+d[1]*.6,P.z+d[2]*.6,d[0]*v,d[1]*v+1,d[2]*v,it.dano*f,true);som('arco');return}
 const a=alvoAtaque();
 if(a&&(a.tipo==='vox'||a.tipo==='terra')){if(criativo()&&P.recarga<=0){P.recarga=.22;P.golpe=1;a.tipo==='vox'?quebrarBloco(a.o):escavarEm(a.o,it)}return}
 if(P.recarga>0)return;P.golpe=1;P.recarga=it?it.cad:.45;som('golpe',.6);if(!a)return;
 if(a.tipo==='ser'){const dano=(it?it.dano:4)*(P.efeitos.forca?1.6:1)*(criativo()?4:1);ferirSer(a.o,dano*(.9+Math.random()*.25),P.x,P.z,'jogador');return}
 if(a.tipo==='obra'){const c=a.o;c.hp=(c.hp??(c.tipo==='tocha'||it.id==='martelo'?1:3))-1;som('madeira');faisca(c.x,c.y+1,c.z,[.7,.5,.2],6,.2);if(c.hp<=0)desmontar(c);return}
 golpearRecurso(a.o,it)}
function golpearRecurso(r,it){const def=RECURSOS[r.tipo];if(criativo()){derrubar(r,true);return}if(def.coletar){coletar(r);return}
 const certo=it&&def.ferr&&it.ferramenta===def.ferr,pedra=def.ferr==='picareta';
 if(def.nivel&&(!certo||it.nivel<def.nivel)){avisar(`Precisa de uma picareta ${['','de madeira','de pedra','de ferro'][def.nivel]}`,2.5);som('pedra',.6);return}
 const dano=(certo?8+it.nivel*5:it?Math.max(4,it.dano*(def.ferr?.35:.9)):4)*(P.efeitos.forca?1.5:1);r.hp-=dano;som(pedra?'pedra':'madeira');
 faisca(lerp(r.x,P.x,.3),P.y-.6,lerp(r.z,P.z,.3),pedra?[.7,.7,.7]:[.65,.45,.15],6,.16);alvoAtual={r,t:2.5};
 if(r.hp<=0)coletar(r)}
function derrubar(r,pega){if(r.morto)return;alternarRecurso(r,false);ES.removidos[r.id]=dia+RECURSOS[r.tipo].volta;if(alvoAtual&&alvoAtual.r===r)alvoAtual=null;if(pega){faisca(r.x,r.y+1,r.z,[.5,.45,.25],10,.25);som('madeira')}}
function coletar(r){const def=RECURSOS[r.tipo];derrubar(r);for(const[id,a,b]of def.drops){const q=sorte(a,b)*CFG.multColeta;if(q)pegar(id,q)}}
function tempoBloco(b,it){const certa=it&&b.ferr&&it.ferramenta===b.ferr,apto=!b.nivel||(certa&&it.nivel>=b.nivel);let v=certa?1.6+it.nivel*1.3:it&&it.id==='martelo'?3:it&&it.ferramenta==='tesoura'&&b.id==='folhas'?6:1;if(!apto)v=.3;if(P.efeitos.forca)v*=1.4;if(P.submerso)v*=.5;return{t:Math.max(.12,b.dur*.95/v),apto}}
const centroCava=t=>{const d=dirOlhar();return[t.x+d[0]*.45,t.y+d[1]*.45,t.z+d[2]*.45]};
function durezaTerra(t,it){const m=MATT[materialEm(...centroCava(t))],[,nome,,dur,ferr,nivel]=m,broca=it?.id==='broca',certa=broca||it&&(!ferr||it.ferramenta===ferr),tier=certa?Math.max(1,it?.nivel||0):0,apto=!nivel||tier>=nivel;
 let v=certa&&it?1.8+(it.nivel||0)*1.3:1;if(!apto)v=.3;if(P.efeitos.forca)v*=1.4;if(P.submerso)v*=.5;return{t:Math.max(.14,(dur||.7)*.8/v),apto,tier,nome,nivel,dur}}
function escavarEm(t,it){const q=durezaTerra(t,it);if(q.dur===Infinity)return;const[x,y,z]=centroCava(t),raio=(it?.raio||CFG.escava)*(it?.ferramenta||criativo()?1:.75);
 const r=cavar(x,y,z,raio,criativo()?9:q.tier);faisca(t.x,t.y+.1,t.z,[.45,.34,.24],14,.2);som(q.nivel?'pedra':'passo');if(!criativo()){recolherTerra(r);if(!q.apto)avisar(`Falta uma picareta melhor para recolher ${String(q.nome).toLowerCase()}`,2.5)}}
function quebrarBloco(v){const b=BLOCOS[v.n];if(b.dur===Infinity&&!(criativo()&&v.y>=FUNDO-0)){return}if(b.id==='rocha_mae'&&v.y<FUNDO)return;
 const{apto}=tempoBloco(b,naMao()),fo=v.v>>10&15;definirBloco(v.x,v.y,v.z,0);
 if(fo===FM.porta||fo===FM.porta_aberta)for(const d of[1,-1]){const q=bruto(v.x,v.y+d,v.z);if(q&&(q>>10&15)===fo){definirBloco(v.x,v.y+d,v.z,0);break}}verificarApoio(v.x,v.y,v.z,1);faisca(v.x+.5,v.y+.5,v.z+.5,rgb(CORES_BLOCO[b.id]||'#888888'),12,.2);som(b.ferr==='picareta'?'pedra':b.ferr==='machado'?'madeira':'passo');
 contar('quebrou',b.id);if(criativo())return;if(b.solta&&apto){let id=b.solta;if(b.id==='folhas'){if(naMao()?.ferramenta!=='tesoura'){id=Math.random()<.2?'maca':Math.random()<.3?'fibra':null}}if(id)soltar(id,1,v.x+.5,v.z+.5,v.y+.15),M.chao.at(-1).espera=.15}
 else if(!apto)avisar(`Precisa de uma picareta ${['','de madeira','de pedra','de ferro','de diamante'][b.nivel]} para recolher`,2.5)}
function minerar(dt){const a=entrada.atacando&&!criativo()?alvoAtaque():null;if(!a||a.tipo!=='vox'&&a.tipo!=='terra'||naMao()?.distancia){P.quebrando=null;return}
 const v=a.o,terra=a.tipo==='terra';let k,dur,b,cor,som_;
 if(terra){const q=durezaTerra(v,naMao());k='t'+Math.round(v.x)+','+Math.round(v.y)+','+Math.round(v.z);dur=q.t;if(q.dur===Infinity){P.quebrando=null;return}cor=[.45,.34,.24];som_=q.nivel?'pedra':'passo'}
 else{b=BLOCOS[v.n];if(b.dur===Infinity){P.quebrando=null;return}k=VK(v.x,v.y,v.z);dur=tempoBloco(b,naMao()).t;cor=rgb(CORES_BLOCO[b.id]||'#888888');som_=b.ferr==='picareta'?'pedra':'madeira'}
 const Q=P.quebrando;if(!Q||Q.k!==k&&!(terra&&Q.terra&&Math.hypot(Q.x-v.x,Q.y-v.y,Q.z-v.z)<.8))P.quebrando={k,terra,x:v.x,y:v.y,z:v.z,p:0,som:0};const q=P.quebrando;q.p+=dt/dur;P.golpe=Math.max(P.golpe,.35+.65*Math.abs(Math.sin(tempo*11)));
 if((q.som-=dt)<0){q.som=.28;som(som_,.5);if(terra)faisca(v.x,v.y+.1,v.z,cor,3,.1);else faisca(v.x+.5+v.nx*.55,v.y+.5+v.ny*.55,v.z+.5+v.nz*.55,cor,3,.1)}
 if(q.p>=1){P.quebrando=null;if(terra)escavarEm(v,naMao());else quebrarBloco(v)}}

// ---------- colocar blocos e construções ----------
function celulaAlvo(){const o=[P.x,P.y,P.z],v=raioVox(o,dirOlhar(),6),t=raioTerreno(v?v.t:6);let x,y,z;
 if(t){const nm=t.n||[0,1,0];x=Math.floor(t.x+nm[0]*.35);z=Math.floor(t.z+nm[2]*.35);y=Math.floor(t.y+nm[1]*.35+.2);for(let i=0;i<4&&solidoVox(x,y,z);i++)y++}else if(v){x=v.x+v.nx;y=v.y+v.ny;z=v.z+v.nz}else return null;return{x,y,z}}
function ocupaJogador(x,y,z){return P.x+.3>x&&P.x-.3<x+1&&P.z+.3>z&&P.z-.3<z+1&&pes()+1.8>y&&pes()<y+1}
function previaBloco(){const it=naMao();if(!it||it.cat!=='cubo')return null;const c=celulaAlvo();if(!c)return null;const n=bloco(c.x,c.y,c.z),b=BLOCOS[it.bloco];
 if(n&&!BLOCOS[n].agua&&!BLOCOS[n].lava)return null;if(b.solido&&(ocupaJogador(c.x,c.y,c.z)||seres.some(e=>!e.morte&&Math.abs(e.x-c.x-.5)<.5+e.def.raio*.6&&Math.abs(e.z-c.z-.5)<.5+e.def.raio*.6&&e.y<c.y+1&&e.y+e.def.alt>c.y)))c.erro='Há alguém no caminho';
 else if(c.y>90)c.erro='Alto demais';else if(Math.max(Math.abs(c.x),Math.abs(c.z))>M.MEIO-25)c.erro='Fim do mundo';return c}
function colocarBloco(){const it=naMao(),c=previaBloco();if(!c)return;if(c.erro){avisar(c.erro,2.5);return}const f=P.forma||0,g=giroOlhar();let postos=0;
 for(const q of celulasModo(c)){if(!naMao()||naMao().id!==it.id)break;const n=bloco(q.x,q.y,q.z);if(n&&!BLOCOS[n].agua&&!BLOCOS[n].lava)continue;if(BLOCOS[it.bloco].solido&&ocupaJogador(q.x,q.y,q.z))continue;
  definirBloco(q.x,q.y,q.z,it.bloco,f,g);if(f===FM.porta&&!bloco(q.x,q.y+1,q.z))definirBloco(q.x,q.y+1,q.z,it.bloco,f,g);gastar();postos++}
 if(postos){P.golpe=1;som(BLOCOS[it.bloco].ferr==='picareta'?'pedra':'madeira',.7);contar('construido','cubo',postos)}}
function previsao(){const it=naMao();if(!it||it.cat!=='bloco')return null;const[fx,fz]=frente(),longe=it.id==='farol'?4:3,x=Math.round(P.x+fx*longe),z=Math.round(P.z+fz*longe),a=Math.round(P.yaw/(Math.PI/2))*Math.PI/2+rotObra*Math.PI/4,y=Math.max(solo(x,z,pes()+1.1),chaoVox(x,z,pes()+1.1,.3));
 let erro=null;if(y<-.3&&altura(x,z)<-.3)erro='Não dá para construir na água'; else if(it.id==='farol'&&Math.hypot(x,z)>28)erro='O farol precisa ficar perto do acampamento';
 else if(construcoes.some(c=>dist2(c.x,c.z,x,z)<(it.id==='piso'||c.tipo==='piso'?(it.id===c.tipo?1.5:0):.9)&&Math.abs(c.y-y)<1.5))erro='Já há algo construído aí';
 else if(it.id!=='piso'&&bloqueado(x,y+.5,z))erro='Há um obstáculo no lugar';
 return{tipo:it.id,x,z,y,a,erro}}
function addConstrucao(c){c.y??=altura(c.x,c.z);c.cols=[];const{tipo,x,z,a}=c,caixa=(hw,hd,t)=>{const k=addCol({x,z,hw,hd,a,topo:c.y+t});c.cols.push(k);return k},circ=(r,t,px=x,pz=z)=>c.cols.push(addCol({x:px,z:pz,r,topo:c.y+t}));
 if(tipo.startsWith('parede'))caixa(1,.16,2.7);else if(tipo==='cerca')caixa(1,.1,1.2);else if(tipo==='bancada')caixa(.75,.5,1.1);else if(tipo==='cama')caixa(.65,1.15,.8);
 else if(tipo==='fogueira')circ(.65,.6);else if(tipo==='poste')circ(.14,2.4);else if(tipo==='bau')circ(.55,1);else if(tipo==='farol')circ(1.2,5);
 else if(tipo==='porta'){for(const s of[-1,1])circ(.14,2.6,...girar(x,z,a,s*.86,0));c.folha=caixa(.72,.08,2.4);c.folha.morto=!!c.aberto}
 if(tipo==='bancada'||tipo==='fogueira')M.estacoes.push({tipo:tipo==='bancada'?'bancada':'fogo',x,z,obra:c});
 if(['fogueira','poste','farol','tocha'].includes(tipo))M.luzes.push({x,y:c.y+(tipo==='farol'?4.5:tipo==='poste'?2.4:tipo==='tocha'?.9:1),z,i:tipo==='farol'?7:tipo==='poste'?1.2:tipo==='tocha'?1.1:1.6,obra:c,cav:!!c.cav});
 if(tipo==='cama')M.camas.push({x,z,obra:c});if(tipo==='bau')c.itens=c.itens||[];construcoes.push(c);return c}
function colocarObra(){const p=previsao();if(!p)return;if(p.erro){avisar(p.erro,2.5);return}gastar();addConstrucao({tipo:p.tipo,x:p.x,z:p.z,y:p.y,a:p.a});som('madeira');P.golpe=1;contar('construido',p.tipo);salvar()}
function desmontar(c){tirarCols(c.cols);construcoes=construcoes.filter(o=>o!==c);for(const k of['estacoes','luzes','camas'])M[k]=M[k].filter(o=>o.obra!==c);if(!criativo()){pegar(c.tipo,1);for(const[id,q]of c.itens||[])pegar(id,q)}salvar()}

// ---------- vida ----------
function ferirJogador(d,ox,oz){if(estado!=='jogando'||criativo()||d<=0)return;d*=1-defesa();
 if(P.armadura[4]?.[0]==='escudo'&&ox!==undefined){const[fx,fz]=frente(),dx=ox-P.x,dz=oz-P.z,l=Math.hypot(dx,dz);if(l>.1&&(dx*fx+dz*fz)/l>.45){d*=.6;som('pedra',.5)}}
 P.vida-=d;if(d>1){som('ferido');$('dano').style.opacity=clamp(d/18,.35,.9)}
 if(ox!==undefined&&!P.barco){const dx=P.x-ox,dz=P.z-oz,l=Math.hypot(dx,dz);if(l>.1){const nx=P.x+dx/l*.35,nz=P.z+dz/l*.35;if(!colideVox(nx,pes()+.01,nz,.3,1.8))[P.x,P.z]=resolver(nx,nz,.35,pes()+.2)}}if(P.vida<=0)morrer()}
function morrer(){P.vida=0;estado='morto';P.barco=null;som('morte');soltarControles();if(document.pointerLockElement)document.exitPointerLock();telaMorte()}
function renascer(){P.montaria=null;const[x,z]=P.casa||[3,7];const perdidas=Math.floor(P.moedas*.3);P.moedas-=perdidas;Object.assign(P,{x,z,vida:100,fome:Math.max(P.fome,65),ar:15,vy:0,efeitos:{},barco:null,pesca:null});P.y=Math.max(soloTopo(x,z),chaoVox(x,z,altura(x,z)+8))+1.7;atualizarMundo(99);seres.forEach(e=>{if(e.def.monstro&&!e.manso)e.sumir=true;e.raiva=0;e.irritado=0});flechas=[];jogar();avisar(perdidas?`Você acordou em segurança. Perdeu ${perdidas} moedas.`:'Você acordou em segurança.',5);salvar()}
