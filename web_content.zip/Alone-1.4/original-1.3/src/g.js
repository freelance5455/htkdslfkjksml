// ---------- modelos de criaturas ----------
const CORPOS={};
const parte=(g,pivo,anim,fase=0)=>({m:g.malha(),pivo,anim,fase});
function humano(o){const G=()=>new Geo(),w=o.magro?.55:1,partes=[];let g=G();
 if(o.osso){g.caixa(0,1.15,0,.1,.7,.1,o.pele);for(let i=0;i<4;i++)g.caixa(0,.98+i*.13,0,.46-(i===0)*.12,.06,.24,o.pele);g.caixa(0,.82,0,.34,.14,.2,o.pele)}
 else{g.caixa(0,1.12,0,.56,.68,.3,o.camisa);g.caixa(0,.8,0,.57,.1,.31,[.2,.13,.08]);g.caixa(.12,1.05,.16,.14,.2,.02,o.pele).caixa(-.15,.9,.16,.1,.08,.02,[.14,.2,.3])}
 partes.push(parte(g,[0,0,0]));
 g=G().caixa(0,.25,0,.44,.44,.42,o.pele);for(const s of[-1,1])g.caixa(s*.11,.29,.22,.09,o.osso?.11:.07,.03,o.olho||[.08,.06,.05],o.olho?-1:0);
 g.caixa(0,.12,.22,.18,.04,.02,[.2,.05,.05]);if(o.cabelo)g.caixa(0,.5,-.02,.49,.12,.47,o.cabelo).caixa(0,.28,-.23,.49,.4,.06,o.cabelo);
 if(o.coroa){g.caixa(0,.52,0,.5,.1,.48,[1,.78,.18],-.4);for(const[x,z]of[[-.2,.2],[.2,.2],[-.2,-.2],[.2,-.2],[0,.21]])g.caixa(x,.65,z,.08,.18,.08,[1,.78,.18],-.4);g.caixa(0,.55,.25,.1,.08,.02,[.9,.15,.2],-.8)}
 partes.push(parte(g,[0,1.46,0],'cabeca'));
 for(const s of[-1,1]){g=G().caixa(0,-.3,0,.17*w,.66,.19*w,o.osso?o.pele:o.camisa).caixa(0,-.66,0,.15*w,.14,.16*w,o.pele);
  if(o.arco&&s>0){for(let i=-3;i<=3;i++)g.caixa(0,-.68-(9-i*i)*.035,i*.17,.06,.07,.19,[.55,.34,.14]);g.caixa(0,-.68,0,.015,.015,1.1,[.9,.9,.85])}
  partes.push(parte(g,[s*(o.magro?.31:.38),1.42,0],o.zumbi?'frente':'braco',s>0?Math.PI:0));
  g=G().caixa(0,-.4,0,.2*w,.8,.22*w,o.osso?o.pele:o.calca).caixa(0,-.76,.04,.22*w,.1,.3*w,o.osso?o.pele:[.22,.14,.08]);
  partes.push(parte(g,[s*.15,.8,0],'perna',s>0?0:Math.PI))}
 return{partes}}
function quadrupede(o){const G=()=>new Geo(),{cor,w,h,c,perna}=o,esc=o.escuro||cor.map(v=>v*.55),partes=[];
 let g=G().caixa(0,perna+h/2,0,w,h,c,cor);if(o.barriga)g.caixa(0,perna+.04,0,w*.78,.12,c*.8,o.barriga);if(o.la)for(let i=0;i<9;i++)g.bola((i%3-1)*w*.35,perna+h*.7,((i/3|0)-1)*c*.32,w*.38,h*.4,c*.2,o.la,0,.15);
 if(o.manchas)for(const[x,y,z,a,b]of[[1,.7,.3,.4,.4],[-1,.4,-.25,.45,.35],[1,.3,-.35,.25,.25],[-1,.75,.28,.3,.25]])g.caixa(x*w/2,perna+h*y,z*c,.04,h*b,c*a*.7,o.manchas);
 if(o.manchas)g.caixa(.1,perna+h+.01,-.15,w*.5,.03,c*.3,o.manchas).caixa(0,perna-.04,-c*.22,w*.4,.14,.28,[.92,.62,.6]);
 g.caixa(0,perna+h*.75,-c/2-.08,w*.28,h*.3,.18,o.cauda||cor);if(o.extra)o.extra(g,o);partes.push(parte(g,[0,0,0]));
 const cb=o.cabeca,hc=o.corCabeca||cor;g=G().caixa(0,o.pescoco/2,.05,cb*.75,o.pescoco+.1,cb*.8,cor).caixa(0,o.pescoco+cb*.2,cb*.55,cb,cb*.95,cb*1.4,hc).caixa(0,o.pescoco+cb*.06,cb*1.35,cb*.55,cb*.45,cb*.35,o.focinho||esc);
 for(const s of[-1,1]){g.caixa(s*cb*.38,o.pescoco+cb*.9,cb*.35,cb*.24,o.orelha,cb*.12,hc);g.caixa(s*cb*.5,o.pescoco+cb*.35,cb*1,cb*.1,cb*.14,cb*.14,o.olho||[.08,.05,.03],o.olho?-1:0);
  if(o.chifre)g.caixa(s*.15,o.pescoco+.55,.18,.05,.5,.05,[.86,.78,.62]).caixa(s*.26,o.pescoco+.6,.18,.22,.05,.05,[.86,.78,.62]);if(o.corno)g.caixa(s*cb*.62,o.pescoco+cb*.72,cb*.5,cb*.32,cb*.12,cb*.12,[.9,.86,.74]);if(o.presa)g.caixa(s*cb*.3,o.pescoco-.02,cb*1.45,.06,.2,.06,[.95,.92,.82])}
 if(o.coleira)g.caixa(0,o.pescoco*.45,.06,cb*.82,.09,cb*.88,o.coleira);
 if(o.extraC)o.extraC(g,o);
 partes.push(parte(g,[0,perna+h*.7,c/2-.05],'pescoco'));
 for(const[x,z,f]of[[-1,1,0],[1,1,Math.PI],[-1,-1,Math.PI],[1,-1,0]])partes.push(parte(G().caixa(0,-perna/2,0,w*.23,perna,w*.25,cor.map(v=>v*.85)).caixa(0,-perna+.06,0,w*.25,.12,w*.27,esc),[x*w*.34,perna,z*c*.38],'perna',f));
 return{partes}}
function corpoAranha(c=[.14,.11,.14],c2=[.2,.14,.18]){const G=()=>new Geo(),p=[];const g=G().bola(0,.55,-.35,.45,.36,.55,c,0,.12).bola(0,.5,.25,.32,.26,.32,c2,0,.1);g.caixa(0,.8,-.45,.12,.08,.4,[.55,.1,.35]);
 for(const[x,y,t]of[[-.15,.58,.09],[.15,.58,.09],[-.06,.66,.06],[.06,.66,.06]])g.caixa(x,y,.55,t,t,.05,[1,.12,.12],-1);for(const s of[-1,1])g.caixa(s*.08,.38,.56,.05,.18,.05,[.8,.78,.7]);p.push(parte(g,[0,0,0]));
 for(const s of[-1,1])for(let k=0;k<4;k++){const z=.3-k*.18,leg=G().caixa(s*.28,.1,0,.58,.08,.08,c).caixa(s*.6,-.18,0,.08,.64,.08,c);p.push(parte(leg,[s*.2,.5,z],'pata',k*1.6+(s>0?Math.PI:0)))}return{partes:p}}
function corpoGosma(cor=[.38,.82,.36]){const G=()=>new Geo();const g=G().caixa(0,.45,0,.95,.8,.95,cor).caixa(0,.9,0,.7,.14,.7,cor.map(v=>Math.min(1,v*1.2))).caixa(0,.06,0,1.1,.12,1.1,cor.map(v=>v*.75)).caixa(.18,.7,.2,.2,.16,.2,[.75,1,.65],-.3);
 for(const s of[-1,1])g.caixa(s*.2,.58,.49,.15,.2,.03,[.05,.12,.05]).caixa(s*.23,.63,.51,.05,.06,.02,[1,1,1],-.6);g.caixa(0,.32,.49,.22,.06,.03,[.05,.2,.08]);return{partes:[parte(g,[0,0,0],'gelatina')]}}
function corpoPeixe(cor){const G=()=>new Geo();const g=G().bola(0,.2,0,.12,.2,.34,cor,0,.08).caixa(0,.42,-.02,.03,.12,.2,cor.map(v=>v*.7));for(const s of[-1,1])g.caixa(s*.1,.25,.2,.03,.07,.07,[.05,.05,.08]);
 return{partes:[parte(g,[0,0,0]),parte(G().caixa(0,0,-.16,.03,.3,.2,cor.map(v=>v*.75)).caixa(0,0,-.04,.05,.14,.12,cor),[0,.2,-.28],'cauda')]}}
function corpoGolem(pedra=[.5,.52,.48],escura=[.36,.38,.36],musgo=[.27,.46,.18],luz=[.25,.95,.82]){const G=()=>new Geo(),p=[];
 let g=G().caixa(0,1.75,0,1.25,.95,.75,pedra).caixa(0,1.15,0,.7,.35,.5,escura).caixa(-.3,2.26,-.05,.55,.12,.7,musgo).caixa(.42,2.0,.39,.3,.4,.05,musgo).caixa(-.45,1.45,.39,.22,.18,.04,musgo).caixa(0,1.82,.39,.3,.3,.06,escura).caixa(0,1.82,.43,.16,.2,.04,luz,-1);p.push(parte(g,[0,0,0]));
 g=G().caixa(0,.28,0,.6,.5,.56,pedra).caixa(0,.52,0,.66,.12,.62,escura).caixa(.14,.6,-.1,.28,.08,.3,musgo).caixa(0,.12,.3,.34,.1,.06,escura);for(const s of[-1,1])g.caixa(s*.14,.32,.29,.13,.09,.03,luz,-1);p.push(parte(g,[0,2.18,.08],'cabeca'));
 for(const s of[-1,1]){g=G().caixa(0,-.45,0,.36,.9,.4,pedra).caixa(0,-1.15,.02,.48,.62,.52,escura).caixa(s*.05,.12,0,.5,.34,.55,pedra).caixa(s*.1,.32,0,.3,.1,.36,musgo);p.push(parte(g,[s*.84,2.05,0],'braco',s>0?Math.PI:0));
  p.push(parte(G().caixa(0,-.35,0,.42,.7,.46,escura).caixa(0,-.84,.05,.52,.32,.62,pedra),[s*.32,1,0],'perna',s>0?0:Math.PI))}return{partes:p}}
function criarCorpos(){semearTexto('corpos');
 CORPOS.cervo=quadrupede({cor:[.55,.34,.18],barriga:[.86,.78,.62],w:.6,h:.6,c:1.35,perna:.85,pescoco:.55,cabeca:.34,orelha:.18,chifre:true});
 CORPOS.coelho=quadrupede({cor:[.66,.58,.5],cauda:[.95,.95,.95],w:.3,h:.3,c:.46,perna:.16,pescoco:.1,cabeca:.22,orelha:.3});
 CORPOS.javali=quadrupede({cor:[.27,.19,.15],w:.7,h:.7,c:1.2,perna:.4,pescoco:.05,cabeca:.46,orelha:.16,presa:true});
 CORPOS.lobo=quadrupede({cor:[.42,.43,.46],barriga:[.65,.65,.66],w:.48,h:.5,c:1.15,perna:.55,pescoco:.28,cabeca:.34,orelha:.2,olho:[1,.75,.1]});
 CORPOS.lobo_manso=quadrupede({cor:[.7,.68,.66],barriga:[.9,.9,.88],w:.48,h:.5,c:1.15,perna:.55,pescoco:.28,cabeca:.34,orelha:.2,coleira:[.85,.12,.1]});
 CORPOS.ovelha=quadrupede({cor:[.86,.84,.78],la:[.95,.93,.88],corCabeca:[.25,.2,.17],w:.7,h:.62,c:1.05,perna:.45,pescoco:.2,cabeca:.34,orelha:.1});
 CORPOS.ovelha_tosada=quadrupede({cor:[.86,.72,.68],corCabeca:[.25,.2,.17],w:.56,h:.48,c:.95,perna:.45,pescoco:.2,cabeca:.34,orelha:.1});
 CORPOS.vaca=quadrupede({cor:[.72,.46,.24],manchas:[.95,.9,.82],focinho:[.9,.68,.62],w:.85,h:.8,c:1.5,perna:.62,pescoco:.18,cabeca:.46,orelha:.1,corno:true});
 CORPOS.urso=quadrupede({cor:[.3,.18,.1],focinho:[.55,.4,.26],w:1.05,h:.95,c:1.75,perna:.6,pescoco:.12,cabeca:.55,orelha:.16});
 {const G=()=>new Geo(),p=[];p.push(parte(G().bola(0,.42,0,.24,.22,.32,[.96,.95,.9]).caixa(0,.56,-.3,.12,.24,.12,[.9,.88,.82]),[0,0,0]));
  p.push(parte(G().caixa(0,.16,.02,.18,.3,.18,[.96,.95,.9]).caixa(0,.14,.15,.1,.07,.12,[1,.66,.1]).caixa(0,.34,.02,.06,.1,.14,[.85,.15,.1]),[0,.5,.22],'pescoco'));
  for(const s of[-1,1])p.push(parte(G().caixa(0,-.13,0,.05,.28,.05,[1,.66,.1]),[s*.1,.28,0],'perna',s>0?0:Math.PI));CORPOS.galinha={partes:p}}
 CORPOS.zumbi=humano({pele:[.36,.55,.28],camisa:[.24,.3,.4],calca:[.2,.19,.16],olho:[1,.2,.1],cabelo:[.1,.12,.08],zumbi:true});
 CORPOS.esqueleto=humano({pele:[.86,.84,.74],osso:true,magro:true,arco:true,olho:[.5,.9,1]});
 CORPOS.rei_ossos=humano({pele:[.78,.74,.62],osso:true,arco:true,olho:[1,.25,.5],coroa:true});
 CORPOS.aranha=corpoAranha();CORPOS.gosma=corpoGosma();CORPOS.golem=corpoGolem();
 CORPOS.peixe=corpoPeixe([.95,.55,.2]);CORPOS.peixe_azul=corpoPeixe([.3,.6,.85]);CORPOS.peixe_prata=corpoPeixe([.7,.76,.8]);criarAnimais()}

// ---------- tipos de criatura ----------
const BICHOS={
 cervo:{n:'Cervo',hp:34,vel:9,calmo:1.4,foge:13,alt:1.8,raio:.55,drops:[['carne_crua',2,3],['couro',1,2]]},
 coelho:{n:'Coelho',hp:8,vel:7.5,calmo:1.2,foge:8,alt:.7,raio:.3,drops:[['carne_crua',1,1],['couro',0,1]]},
 javali:{n:'Javali',hp:55,vel:6.8,calmo:1,dano:11,alt:1.2,raio:.65,drops:[['carne_crua',2,4],['couro',1,2]]},
 lobo:{n:'Lobo',hp:42,vel:8,calmo:1.6,dano:10,agressivoNoite:15,alt:1.2,raio:.55,drops:[['couro',1,3],['carne_crua',1,2]]},
 urso:{n:'Urso',hp:120,vel:6.4,calmo:.9,dano:18,agressivoPerto:7,alt:1.7,raio:.85,drops:[['carne_crua',3,5],['couro',3,5]]},
 ovelha:{n:'Ovelha',hp:26,vel:4.5,calmo:.8,alt:1.3,raio:.55,drops:[['la',2,3],['carne_crua',1,2]]},
 vaca:{n:'Vaca',hp:40,vel:4,calmo:.7,alt:1.6,raio:.7,drops:[['carne_vaca',2,4],['couro',1,3]]},
 galinha:{n:'Galinha',hp:8,vel:3.5,calmo:.8,alt:.8,raio:.28,drops:[['pena',2,4],['carne_crua',1,1]]},
 peixe:{n:'Peixe',hp:4,vel:3,calmo:.9,foge:4,alt:.4,raio:.25,aquatico:true,drops:[['peixe_cru',1,1]]},
 zumbi:{n:'Zumbi',hp:46,vel:3.3,calmo:1,dano:12,monstro:true,queima:true,afunda:true,alt:1.95,raio:.45,drops:[['carne_podre',0,1],['moeda',1,5],['fibra',0,2],['ferro',-4,1],['cenoura',-5,1],['batata',-5,1]]},
 esqueleto:{n:'Esqueleto',hp:34,vel:3.6,calmo:1,dano:9,monstro:true,queima:true,afunda:true,arqueiro:true,alt:1.95,raio:.4,drops:[['osso',1,3],['flecha',1,5],['moeda',1,6],['arco',-6,1]]},
 aranha:{n:'Aranha',hp:30,vel:5.4,calmo:1.2,dano:8,monstro:true,pula:true,alt:1,raio:.6,drops:[['linha',1,3],['moeda',0,3]]},
 gosma:{n:'Gosma',hp:28,vel:3.4,calmo:1.6,dano:7,monstro:true,saltita:true,alt:1,raio:.55,drops:[['gosma',1,3]]},
 rei_ossos:{n:'Rei dos Ossos',hp:320,vel:3.4,calmo:.8,dano:17,monstro:true,arqueiro:true,chefe:true,escala:1.6,alt:3.1,raio:.7,drops:[['diamante',3,6],['esmeralda',2,4],['moeda',60,140],['espada_diamante',-1,1],['nucleo_golem',1,1]]},
 golem:{n:'Golem',hp:220,vel:2.6,calmo:1.1,dano:28,alt:2.8,raio:.8,drops:[['pedra',3,8],['lingote',2,5],['nucleo_golem',-1,1]]},
 barco:{n:'Barco',hp:12,vel:0,calmo:0,alt:.7,raio:.9,drops:[['barco',1,1]]},
 npc:{n:'Morador',hp:999,vel:1.5,calmo:1.2,alt:1.95,raio:.42,drops:[]}};
let seres=[],flechas=[],faiscas=[],bombas=[],proxNascer=3,proxAnimal=6,noite=0;
function criar(tipo,x,z,extra){const def=BICHOS[tipo],hp=def.hp*(def.monstro?DIFICULDADES[CFG.dif].hp:1);
 const e=Object.assign({tipo,def,x,z,y:0,vy:0,h:Math.random()*TAU,v:0,hp,max:hp,t:Math.random()*3,fase:Math.random()*6,flash:0,atq:1,raiva:0,panico:0,morte:0,corpo:CORPOS[tipo],lado:Math.random()<.5?1:-1,desvio:0,escala:def.escala||1,cav:!!CAV},extra);
 if(extra&&extra.y!==undefined)e.y=extra.y;else if(def.aquatico)e.y=clamp(altura(x,z)*.5,-6,-.6);else if(tipo==='barco')e.y=0;else e.y=Math.max(soloTopo(x,z),chaoVox(x,z,altura(x,z)+6,def.raio));
 e.fundo=e.y<altura(x,z)-3.5;if(def.voa&&!(extra&&extra.y!==undefined))e.y+=def.voa*.7;
 seres.push(e);return e}
function lugarLivre(cx,cz,dMin,dMax,hMax=18){for(let t=0;t<30;t++){const a=Math.random()*TAU,d=dMin+Math.random()*(dMax-dMin),x=cx+Math.cos(a)*d,z=cz+Math.sin(a)*d;
 if(Math.abs(x)<M.MEIO-30&&Math.abs(z)<M.MEIO-30){const h=altura(x,z);if(h>.6&&h<hMax&&!mexido(x,z))return[x,z]}}return null}
function lugarAgua(cx,cz,dMin,dMax){for(let t=0;t<24;t++){const a=Math.random()*TAU,d=dMin+Math.random()*(dMax-dMin),x=cx+Math.cos(a)*d,z=cz+Math.sin(a)*d;if(Math.abs(x)<M.MEIO-30&&Math.abs(z)<M.MEIO-30&&altura(x,z)<-1.4)return[x,z]}return null}
// refúgio: fogueiras e o acampamento impedem a aproximação; vilas só impedem o surgimento
const emRefugio=(x,z,f=1)=>Math.hypot(x,z)<15*f||construcoes.some(c=>c.tipo==='fogueira'&&Math.hypot(c.x-x,c.z-z)<10*f);
const semSurgir=(x,z)=>emRefugio(x,z,1.2)||M.refugios.some(r=>Math.hypot(r.x-x,r.z-z)<r.r);
const FAUNA={carvalhal:['cervo','coelho','javali','cervo','coelho','lobo'],pinheiral:['lobo','urso','cervo','javali','cervo'],betulas:['cervo','coelho','galinha','ovelha'],campina:['vaca','ovelha','galinha','coelho','vaca'],savana:['javali','cervo','vaca'],neve:['lobo','urso','coelho'],deserto:['coelho']};
const EM_BANDO={zebra:3,pinguim:4,pombo:4,borboleta:3,flamingo:3,cavalo:3,bufalo:3,galinha:3,ovelha:3,vaca:3,cervo:2,coelho:2,lobo:2,peixe:3};
function bando(tipo,x,z,ch){const q=1+(Math.random()*(EM_BANDO[tipo]||1)|0);for(let i=0;i<q;i++){const px=x+(Math.random()-.5)*5,pz=z+(Math.random()-.5)*5;
 const e=criar(tipo,px,pz,{ch,cav:false});if(tipo==='peixe')e.corpo=CORPOS[qualquer(['peixe','peixe_azul','peixe_prata'])]}}
function faunaDoChunk(ch){if(CAV)return;const x0=ch.cx*BLOCO,z0=ch.cz*BLOCO,animais=seres.filter(e=>!e.def.monstro&&!e.npc&&!e.morte&&Math.hypot(e.x-ch.x,e.z-ch.z)<90).length;
 if(animais<14*CFG.multBicho&&Math.random()<.5*CFG.multBicho){const x=x0+5+Math.random()*40,z=z0+5+Math.random()*40,h=altura(x,z);if(h>.7&&h<20&&!M.refugios.some(r=>Math.hypot(r.x-x,r.z-z)<r.r+8))bando(sortearFauna(bioma(x,z)),x,z,ch.k)}
 if(ch.temAgua&&Math.random()<.5){const x=x0+5+Math.random()*40,z=z0+5+Math.random()*40;if(altura(x,z)<-1.6){bando('peixe',x,z,ch.k);if(Math.random()<.18)bando(qualquer(['tubarao','golfinho','polvo','golfinho']),x,z,ch.k)}}}
function povoarVila(v,ch){for(const n of M.npcs){if(n.vila!==v.i)continue;if(!CORPOS[n.id])CORPOS[n.id]=corpoNpc(n);criar('npc',n.x,n.z,{npc:n,corpo:CORPOS[n.id],ch,cav:false,casa:n.casa,h:Math.atan2(v.x-n.x,v.z-n.z),t:Math.random()*4})}
 if(ES.cavernas['g'+v.i]!==dia)criar('golem',v.x+3.5,v.z+6.5,{ch,cav:false,vila:v,posto:{x:v.x,z:v.z}});
 for(let k=0;k<3;k++){const p=lugarLivre(v.roca.x,v.roca.z,6,10);if(p)criar('galinha',...p,{ch,cav:false,casa:v.roca})}
 for(let k=0;k<2;k++){const p=lugarLivre(v.x,v.z,32,44);if(p)criar(k?'vaca':'ovelha',...p,{ch,cav:false})}}
// criaturas que seguem salvas: lobos mansos, golens criados pelo jogador e barcos
const dadosPets=()=>seres.filter(e=>e.manso&&!e.morte).map(e=>[e.tipo,+e.x.toFixed(1),+e.z.toFixed(1),Math.round(e.hp),e.sentado?1:0,e.posto?[+e.posto.x.toFixed(1),+e.posto.z.toFixed(1)]:0]);
function restaurarPets(lista){for(const[tipo,x,z,hp,s,p]of lista||[]){if(!BICHOS[tipo])continue;const e=criar(tipo,x,z,{manso:true,cav:false,sentado:!!s});e.hp=hp;if(p)e.posto={x:p[0],z:p[1]};if(tipo==='lobo')e.corpo=CORPOS.lobo_manso}}
function limparSeres(){seres=[];flechas=[];faiscas=[];bombas=[];proxNascer=4;proxAnimal=4}
function nascimentos(dt){proxNascer-=dt;proxAnimal-=dt;const dif=DIFICULDADES[CFG.dif],maxM=Math.round(dif.max*CFG.multMob),fundo=profundidade(P.x,pes(),P.z)>5;
 if(fundo){if(proxNascer<0){proxNascer=3.5/Math.max(.2,CFG.multMob);const t=pes();if(seres.filter(e=>e.fundo&&e.def.monstro&&!e.morte).length<Math.min(8,maxM)&&!criativo()){const p=arLivre(P.x,t,P.z,12,28);if(p){const tipo=monstroDaCaverna(p.y);criar(tipo,p.x,p.z,{y:p.y+(BICHOS[tipo].voa?1:0),surge:BICHOS[tipo].voa?0:1,fundo:true})}}
   if(seres.filter(e=>e.tipo==='rato'&&!e.morte).length<2){const p=arLivre(P.x,t,P.z,8,22);if(p)criar('rato',p.x,p.z,{y:p.y,fundo:true})}
   const c=M.camaras.find(c=>Math.hypot(c.x-P.x,c.z-P.z)<22&&Math.abs(c.y-pes())<14&&c===M.cavernas[c.i]?.fundo);if(c&&!criativo()&&CFG.dif!=='pacifico'&&!ES.cavernas['r'+c.i]&&(c.i+(hash(c.i,3)*3|0))%2===0&&!seres.some(e=>e.def.chefe&&!e.morte)){const y=solo(c.x,c.z,c.y+2);criar('rei_ossos',c.x,c.z,{y,fundo:true,camara:c.i});avisar('O Rei dos Ossos desperta…',5);som('caverna')}}
  seres=seres.filter(e=>!(e.fundo&&e.def.monstro&&!e.manso&&!e.def.chefe&&Math.hypot(e.x-P.x,e.y-pes(),e.z-P.z)>70));return}
 if(proxNascer<0){proxNascer=2.2;const n=seres.filter(e=>e.def.monstro&&!e.fundo&&!e.morte).length;
  if(noite>.65&&n<maxM){let p=null;const v=M.vilas.find(v=>Math.hypot(v.x-P.x,v.z-P.z)<45);p=v&&Math.random()<.4?lugarLivre(v.x,v.z,33,44,26):lugarLivre(P.x,P.z,22,48,26);
   if(p&&!semSurgir(p[0],p[1])&&Math.hypot(p[0]-P.x,p[1]-P.z)>18){const tipo=monstroDaSuperficie(bioma(...p));criar(tipo,...p,{surge:BICHOS[tipo].voa?0:1});if(Math.random()<.5)somEm('gemido',...p)}}}
 if(proxAnimal<0){proxAnimal=5;const perto=seres.filter(e=>!e.def.monstro&&!e.npc&&!e.manso&&!e.fundo&&Math.hypot(e.x-P.x,e.z-P.z)<95);
  if(perto.filter(e=>!e.def.aquatico).length<16*CFG.multBicho){const p=lugarLivre(P.x,P.z,30,80);if(p&&!semSurgir(...p))bando(sortearFauna(bioma(...p)),...p)}
  if(perto.filter(e=>e.def.aquatico).length<8*CFG.multBicho){const p=lugarAgua(P.x,P.z,12,55);if(p)bando(Math.random()<.14?qualquer(['tubarao','golfinho','polvo','golfinho','tartaruga']):'peixe',...p)}}}
const onda=(x,z,t)=>Math.sin(x*.35+t*1.4)*.08+Math.cos(z*.27+t*1.1)*.07;
const chaoDe=(x,z,y,r,sobe=1.1)=>{const t=solo(x,z,y+sobe);return Math.max(t,chaoVox(x,z,y+sobe,r,Math.max(4,y+sobe-t+2)))};
function andar(e,dt){if(!e.v)return true;const def=e.def,nx=e.x+Math.sin(e.h)*e.v*dt,nz=e.z+Math.cos(e.h)*e.v*dt;
 if(def.aquatico){if(altura(nx,nz)>-.9){e.h+=Math.PI*(.6+Math.random()*.8);return false}e.x=nx;e.z=nz;return true}
 if(!e.fundo){const h=altura(nx,nz);if(!def.monstro&&e.panico<=0&&((h<-.45&&h<altura(e.x,e.z))||h>30)){e.desvio=.9;e.h+=2.5*dt*e.lado;return false}
  if(def.monstro&&emRefugio(nx,nz,.7)&&!emRefugio(P.x,P.z,.35)){e.v=0;return false}}
 const r=def.raio*.75,alto=Math.max(.4,def.alt-1.1);if(colideVox(nx,e.y+(def.alt<1.1?.55:1.08),nz,r,def.alt<1.1?.3:alto)||(e.fundo||mexido(nx,nz))&&colideTerra(nx,e.y+.85,nz,r,Math.max(.1,def.alt-1.1))){e.desvio=.8;return false}
 let[x,z]=resolver(nx,nz,def.raio,e.y+.2);const travou=Math.hypot(x-nx,z-nz)>e.v*dt*.5;
 if(travou){e.preso=(e.preso||0)+dt;if(e.preso>.3){e.lado*=-1;e.desvio=.9;e.preso=0}}
 const L=M.MEIO-20;e.x=clamp(x,-L,L);e.z=clamp(z,-L,L);return!travou}
function fisicaSer(e,dt,t){const def=e.def;
 if(def.aquatico){const fundo=altura(e.x,e.z)+.25;e.alvoY??=e.y;if(Math.random()<dt*.3)e.alvoY=lerp(fundo,-.6,Math.random());e.y=clamp(e.y+clamp(e.alvoY-e.y,-1,1)*dt*.6,fundo,-.45);if(altura(e.x,e.z)>-.5){e.y=altura(e.x,e.z);if(!e.def.monstro)e.hp-=dt*2}return}
 const chao=chaoDe(e.x,e.z,e.y,def.raio*.6),nivel=onda(e.x,e.z,t),fundo=altura(e.x,e.z)<0&&e.y>altura(e.x,e.z)-1&&chao<nivel-def.alt*.55;e.naAgua=altura(e.x,e.z)<nivel&&e.y<nivel-.15&&e.y>altura(e.x,e.z)-1;
 if(fundo&&!def.afunda&&e.y<nivel){const alvo=nivel-def.alt*(e.tipo==='barco'?.12:.55);e.vy=0;e.y+=(Math.max(alvo,chao)-e.y)*Math.min(1,dt*3);return}
 if(e.y>chao+.02||e.vy>0){e.vy-=(e.naAgua?4:20)*dt;if(e.naAgua)e.vy=Math.max(e.vy,-1.5);e.y+=e.vy*dt;if(e.y<=chao){if(e.vy<-13)ferirSer(e,(-e.vy-13)*4,e.x,e.z,'queda');e.y=chao;e.vy=0}}
 else{e.y=chao-e.y>.05?Math.min(chao,e.y+dt*7):chao;e.vy=0}
 if(!isFinite(e.y))e.y=altura(e.x,e.z);e.fundo=e.y<altura(e.x,e.z)-3.5;
 const b=bloco(Math.floor(e.x),Math.floor(e.y+.2),Math.floor(e.z));if(b&&BLOCOS[b].lava){ferirSer(e,30*dt,e.x,e.z,'lava');if(Math.random()<dt*8)faisca(e.x,e.y+.5,e.z,[1,.5,.1],2,.2)}}
const mira=(e,x,z)=>Math.atan2(x-e.x,z-e.z);
function golpearSer(e,alvo,dano){if(alvo==='jogador')ferirJogador(dano,e.x,e.z);else if(alvo.npc){alvo.panico=5}else ferirSer(alvo,dano,e.x,e.z,e)}
function pensarMonstro(e,dt,d,dx,dz){const def=e.def,dif=DIFICULDADES[CFG.dif];if(CFG.dif==='pacifico'){e.sumir=true;return}
 if(def.queima&&!e.fundo&&!e.manso&&noite<.3&&!e.naAgua){e.hp-=9*dt;if(Math.random()<dt*14)faisca(e.x,e.y+Math.random()*1.6,e.z,[1,.45,.1],1,.3);if(e.hp<=0){e.morte=.01;return}}
 if(Math.random()<dt*.07&&d<30)somEm(e.tipo==='zumbi'?'gemido':e.tipo==='aranha'?'chiado':'ossos',e.x,e.z);
 // escolhe o alvo: quem o atacou, o jogador ou um morador próximo
 let alvo=null,ad=1e9;if(e.inimigo&&!e.inimigo.morte&&e.raiva>0){alvo=e.inimigo;ad=Math.hypot(alvo.x-e.x,alvo.z-e.z)}
 const manso=e.tipo==='aranha'&&!e.cav&&noite<.3&&e.raiva<=0;
 if(!criativo()&&!manso&&d<(def.chefe?30:46)&&Math.abs(P.y-1.7-e.y)<(e.fundo?8:30)&&!(emRefugio(P.x,P.z,.75)&&emRefugio(e.x,e.z,1.3))&&d<ad){alvo='jogador';ad=d}
 if(!e.cav&&!manso)for(const o of seres){if(!o.npc||o.cav)continue;const q=Math.hypot(o.x-e.x,o.z-e.z);if(q<Math.min(16,ad*.7)){alvo=o;ad=q}}
 if(!alvo){if(e.t<0){e.h+=(Math.random()-.5)*2;e.t=2+Math.random()*3;e.v=Math.random()<.4?0:def.calmo}andar(e,dt);return}
 const ax=alvo==='jogador'?P.x:alvo.x,az=alvo==='jogador'?P.z:alvo.z,ay=alvo==='jogador'?P.y-1.7:alvo.y,rumo=mira(e,ax,az);
 if(def.arqueiro&&!(def.chefe&&ad<5)){const dir=ad>17?rumo:ad<7?rumo+Math.PI:rumo+1.5*e.lado;e.v=def.vel*(ad>7&&ad<17?.45:1);e.h=dir+(e.desvio>0?1.4*e.lado:0);andar(e,dt);e.h=rumo;
  if(ad<30&&e.atq<0){e.atq=def.chefe?1.8:2.3+Math.random();e.golpe=1;const t=ad/26,ey=e.y+1.5*e.escala,sx=e.x+Math.sin(rumo)*.7,sz=e.z+Math.cos(rumo)*.7;
   for(let k=0;k<(def.chefe?3:1);k++)atirar(sx,ey,sz,(ax-e.x)/t+(Math.random()-.5)*2.4+(k-(def.chefe?1:0))*3*Math.cos(rumo),(ay+1.35-ey+4.5*t*t)/t+(Math.random()-.5),(az-e.z)/t+(Math.random()-.5)*2.4-(k-(def.chefe?1:0))*3*Math.sin(rumo),def.dano*dif.dano*(def.chefe?.7:1),false);somEm('arco',e.x,e.z)}return}
 const alcance=def.raio+(alvo==='jogador'?.9:alvo.def.raio+.5);e.h=rumo+(e.desvio>0?1.3*e.lado:0);e.v=ad>alcance?def.vel:0;
 if(def.pula&&ad<6&&ad>2.5&&e.vy===0&&Math.random()<dt*1.2){e.vy=7;e.y+=.05;e.salto=.7}if((e.salto-=dt)>0)e.v=def.vel*1.5;
 if(def.saltita){if(e.vy===0&&e.t<0){e.vy=6.5;e.y+=.05;e.t=.9+Math.random()*.4}if(e.y<=chaoDe(e.x,e.z,e.y,.4)+.05)e.v=0}
 andar(e,dt);if(ad<alcance+.25&&Math.abs(ay-e.y)<1.8+def.alt*.3&&e.atq<0){e.atq=1.25;e.golpe=1;golpearSer(e,alvo,def.dano*(alvo==='jogador'?dif.dano:1))}}
function inimigoPerto(x,z,raio,cav){let m=null,md=raio;for(const o of seres){if(o.morte||!o.def.monstro||o.cav!==cav||o.manso)continue;const d=Math.hypot(o.x-x,o.z-z);if(d<md){md=d;m=o}}return m}
function irAte(e,x,z,vel,dt,perto){const d=Math.hypot(x-e.x,z-e.z);if(d<=perto){e.v=0;return true}e.h=mira(e,x,z)+(e.desvio>0?1.1*e.lado:0);e.v=vel;andar(e,dt);return false}
function pensarGolem(e,dt,d){const posto=e.posto||{x:e.x,z:e.z};e.posto=posto;e.inimigoT=(e.inimigoT||0)-dt;
 if(e.inimigoT<0){e.inimigoT=.5;e.inimigo=inimigoPerto(posto.x,posto.z,e.vila?34:24,e.cav)}
 let alvo=e.inimigo;if(alvo&&alvo.morte)alvo=null;
 if(e.irritado>0&&!criativo()&&d<26){e.irritado-=dt;alvo='jogador'}
 if(alvo){const ax=alvo==='jogador'?P.x:alvo.x,az=alvo==='jogador'?P.z:alvo.z,ad=Math.hypot(ax-e.x,az-e.z),alc=e.def.raio+(alvo==='jogador'?1.1:alvo.def.raio+.7);
  if(!irAte(e,ax,az,e.def.vel*1.35,dt,alc)){}else e.h=mira(e,ax,az);
  if(ad<alc+.3&&e.atq<0){e.atq=1.5;e.golpe=1;somEm('golem',e.x,e.z);if(alvo==='jogador'){ferirJogador(e.def.dano*.8,e.x,e.z);P.vy=7}else{alvo.vy=8.5;alvo.y+=.1;ferirSer(alvo,e.def.dano,e.x,e.z,e)}}return}
 e.hp=Math.min(e.max,e.hp+3*dt);
 if(e.manso&&!e.posto)return;if(e.t<0){const pts=e.vila?e.vila.pontos:null;e.alvo=pts?qualquer(pts):{x:posto.x+(Math.random()-.5)*14,z:posto.z+(Math.random()-.5)*14};e.t=9+Math.random()*6}
 if(e.alvo){if(irAte(e,e.alvo.x,e.alvo.z,e.def.calmo,dt,1.4))e.alvo=null}else e.v=0}
function pensarNpc(e,dt,d,rumo){const v=M.vilas[e.npc.vila];e.fala=Math.max(0,(e.fala||0)-dt);
 const perigo=inimigoPerto(e.x,e.z,8,false);if(perigo)e.panico=Math.max(e.panico,1.5);
 if(e.panico>0){irAte(e,e.casa[0],e.casa[1],3.6,dt,1);return}
 if(d<3.2&&!criativo()||d<2.4){e.h=rumo;e.v=0;return}
 if(e.fala>0){e.v=0;if(e.parceiro){e.h=mira(e,e.parceiro.x,e.parceiro.z);if(Math.random()<dt*.9)e.golpe=.35}return}
 if(noite>.6){if(irAte(e,e.casa[0],e.casa[1],e.def.vel,dt,.8))e.h=mira(e,v.x,v.z)+Math.PI*0;e.alvo=null;return}
 if(e.alvo){e.desisto-=dt;if(irAte(e,e.alvo.x,e.alvo.z,e.def.calmo,dt,1)||e.desisto<0){e.alvo=null;e.t=2+Math.random()*5}return}
 e.v=0;
 const outro=seres.find(o=>o!==e&&o.npc&&!(o.fala>0)&&!o.alvo&&Math.hypot(o.x-e.x,o.z-e.z)<2.6);
 if(outro&&Math.random()<dt*.35){e.fala=outro.fala=3+Math.random()*4;e.parceiro=outro;outro.parceiro=e;return}
 if(e.t<0){const fixo=['ferreiro','mercador','anciao'].includes(e.npc.papel),posto={x:e.npc.x,z:e.npc.z};
  e.alvo=Math.random()<(fixo?.65:.2)?posto:Math.random()<.25?(()=>{const o=qualquer(seres.filter(o=>o!==e&&o.npc&&o.npc.vila===e.npc.vila));return o?{x:o.x+1.2,z:o.z+.6}:posto})():qualquer(v.pontos);e.desisto=18;e.t=3}}
function pensarPet(e,dt,d,rumo){e.hp=Math.min(e.max,e.hp+dt);if(e.sentado){e.v=0;return}
 let alvo=e.inimigo;if(alvo&&(alvo.morte||Math.hypot(alvo.x-P.x,alvo.z-P.z)>22))alvo=e.inimigo=null;if(!alvo)alvo=inimigoPerto(P.x,P.z,9,e.cav);
 if(alvo&&e.def.dano){if(irAte(e,alvo.x,alvo.z,e.def.vel,dt,alvo.def.raio+1)&&e.atq<0){e.atq=1;e.golpe=1;ferirSer(alvo,e.def.dano,e.x,e.z,e)}return}
 if(d>28){e.x=P.x-Math.sin(P.yaw||0)*-2;e.z=P.z+2;e.y=P.y-1.6;e.v=0;return}
 if(d>4)irAte(e,P.x,P.z,d>9?e.def.vel:3.5,dt,3);else{e.v=0;e.h=rumo}}
function atualizarSeres(dt,t){
 for(const e of seres){if(e.morte){e.morte+=dt;continue}
  if(e.manso&&e.tipo==='lobo'&&!e.sentado)e.cav=!!CAV;if(e.cav!==!!CAV)continue;
  const dx=P.x-e.x,dz=P.z-e.z,d=Math.hypot(dx,dz),def=e.def,rumo=Math.atan2(dx,dz);e.flash=Math.max(0,e.flash-dt);e.atq-=dt;e.t-=dt;e.panico-=dt;e.raiva-=dt;e.desvio-=dt;e.golpe=Math.max(0,(e.golpe||0)-dt*2.5);if(e.surge)e.surge=Math.max(0,e.surge-dt);
  if(e.ch===undefined&&!e.manso&&!e.npc&&d>Math.max(130,CFG.dist*.8)){e.sumir=true;continue}if(d>CFG.dist+10||e.fundo&&Math.abs(e.y-P.y)>40)continue;
  if(e.amor>0)e.amor-=dt;if(e.filhote){if((e.filhote-=dt)<=0){e.filhote=0;e.escala=def.escala||1}}if(def.bota&&(e.ovo=(e.ovo??60+Math.random()*120)-dt)<0){e.ovo=120+Math.random()*120;if(d<40)soltar(def.bota,1,e.x,e.z,e.y)}
  if(P.montaria===e){e.x=P.x;e.z=P.z;e.y=pes();e.h=P.yaw+Math.PI;e.v=Math.min(8,Math.hypot(entrada.f,entrada.l)*def.vel);e.fase+=e.v*dt*1.6;continue}
  if(def.voa){pensarVoo(e,dt,d);if(e.hp<=0&&!e.morte)e.morte=.01;e.fase+=dt*8;continue}
  if(e.tipo==='barco'){e.v=0;if(P.barco!==e)fisicaSer(e,dt,t);continue}
  if(e.tipo==='golem')pensarGolem(e,dt,d);
  else if(def.monstro&&!e.manso){pensarMonstro(e,dt,d,dx,dz);if(e.morte||e.sumir)continue}
  else if(e.npc)pensarNpc(e,dt,d,rumo);
  else if(e.manso){pensarPet(e,dt,d,rumo)}
  else{e.tosada=Math.max(0,(e.tosada||0)-dt);if(e.tipo==='ovelha')e.corpo=e.tosada?CORPOS.ovelha_tosada:CORPOS.ovelha;
   const hostil=!criativo()&&CFG.dif!=='pacifico'&&!emRefugio(P.x,P.z);
   if(def.agressivoNoite&&noite>.6&&d<def.agressivoNoite&&hostil)e.raiva=Math.max(e.raiva,3);if(def.agressivoPerto&&d<def.agressivoPerto&&hostil)e.raiva=Math.max(e.raiva,4);
   const seguindo=!criativo()&&d<9&&d>2.2&&P.isca&&P.isca.includes(e.tipo)&&e.raiva<=0;
   if(e.inimigo&&!e.inimigo.morte&&e.raiva>0&&def.dano){if(irAte(e,e.inimigo.x,e.inimigo.z,def.vel,dt,e.inimigo.def.raio+1)&&e.atq<0){e.atq=1.3;e.golpe=1;ferirSer(e.inimigo,def.dano,e.x,e.z,e)}}
   else if(e.raiva>0&&def.dano&&!criativo()){e.h=rumo+(e.desvio>0?1.2*e.lado:0);e.v=d>def.raio+.9?def.vel:0;andar(e,dt);if(d<def.raio+1.35&&Math.abs(P.y-1.7-e.y)<2&&e.atq<0){e.atq=1.3;e.golpe=1;ferirJogador(def.dano*Math.max(DIFICULDADES[CFG.dif].dano,.4),e.x,e.z)}}
   else if(seguindo){irAte(e,P.x,P.z,Math.max(def.calmo*2,2),dt,2.2);e.h=rumo}
   else{if(e.panico>0||(def.foge&&!criativo()&&d<(P.correndo?def.foge*1.8:def.foge))){if(e.t<0||e.v<def.vel){e.h=rumo+Math.PI+(Math.random()-.5);e.t=1}e.v=def.vel}
    else if(e.t<0){e.v=Math.random()<.55&&!def.aquatico?0:def.calmo;e.h+=(Math.random()-.5)*3;if(e.casa&&Math.hypot(e.casa.x-e.x,e.casa.z-e.z)>8)e.h=mira(e,e.casa.x,e.casa.z);e.t=2+Math.random()*5}
    andar(e,dt)}}
  fisicaSer(e,dt,t);if(e.hp<=0&&!e.morte)e.morte=.01;e.fase+=(e.v||0)*dt*(def.alt<1.1?5:e.tipo==='golem'?1.5:2.4)}
 seres=seres.filter(e=>!e.sumir&&e.morte<1.4)}
function ferirSer(e,dano,ox,oz,quem='jogador'){if(e.morte)return;
 if(quem==='jogador'){if(e.npc){e.panico=6;for(const g of seres)if(g.tipo==='golem'&&!g.manso&&Math.hypot(g.x-e.x,g.z-e.z)<45)g.irritado=18;avisar('Os golens não gostaram disso!',3);return}
  if(e.tipo==='golem'&&!e.manso)e.irritado=18;if(e.manso&&e.tipo!=='barco')return;
  for(const p of seres)if(p.manso&&p.tipo==='lobo')p.inimigo=e}
 else if(e.npc)return;
 e.hp-=dano;if(quem!=='queda'&&quem!=='lava'){e.flash=.18;e.raiva=14;e.panico=6;if(typeof quem==='object')e.inimigo=quem;
  const dx=e.x-ox,dz=e.z-oz,l=Math.hypot(dx,dz)||1,k=e.tipo==='golem'||e.def.chefe?.08:.45,nx=e.x+dx/l*k,nz=e.z+dz/l*k;if(!colideVox(nx,e.y+1.1,nz,e.def.raio*.7,.6))[e.x,e.z]=resolver(nx,nz,e.def.raio,e.y+.2);
  faisca(e.x,e.y+e.def.alt*.6,e.z,e.tipo==='esqueleto'||e.def.chefe?[.9,.9,.8]:e.tipo==='golem'?[.5,.55,.5]:e.tipo==='gosma'?[.4,.9,.4]:e.tipo==='barco'?[.6,.4,.2]:[.9,.1,.08],8,.2);som('acerto');if(quem==='jogador')alvoAtual={e,t:3}}
 if(e.hp<=0){e.morte=.01;if(P.barco===e)P.barco=null;
  if(quem==='jogador'||quem==='tnt'||quem.manso){for(const[id,a,b]of e.def.drops){const q=sorte(a,b);if(q>0)soltar(id,q,e.x+(Math.random()-.5),e.z+(Math.random()-.5),e.y)}if(e.tipo!=='barco'){contar('mortos',e.tipo);avisar(`${e.def.n} derrotado`,2)}}
  if(e.tipo==='gosma'&&e.escala>.7)for(let i=0;i<2;i++){const f=criar('gosma',e.x+(i-.5),e.z,{escala:.55,y:e.y,cav:e.cav,def:{...BICHOS.gosma,raio:.3,alt:.55,dano:4,drops:[['gosma',0,1]]}});f.hp=f.max=10}
  if(e.tipo==='golem'&&e.vila)ES.cavernas['g'+e.vila.i]=dia;if(e.def.chefe){ES.cavernas['r'+(e.camara??0)]=1;contar('chefes','rei');avisar('Você derrotou o Rei dos Ossos!',5)}}}
function soltar(item,q,x,z,y){M.chao.push({id:null,item,q,x,z,y:y??Math.max(solo(x,z,P.y),altura(x,z)<0?0:-99),pego:false,solto:true,espera:.6,vida:240,cav:!!CAV})}
function atirar(x,y,z,vx,vy,vz,dano,minha){flechas.push({x,y,z,vx,vy,vz,dano,minha,t:0,presa:false})}
function atualizarFlechas(dt){for(const f of flechas){f.t+=dt;if(f.presa)continue;
 for(let k=0;k<4&&!f.presa;k++){const s=dt/4;f.vy-=9*s;if(f.y<0&&altura(f.x,f.z)<0){const a=Math.exp(-3*s);f.vx*=a;f.vy*=a;f.vz*=a}f.x+=f.vx*s;f.y+=f.vy*s;f.z+=f.vz*s;
  const e=seres.find(e=>!e.morte&&e.cav===!!CAV&&(f.minha||e.tipo==='golem')&&!(f.minha&&e.manso)&&Math.hypot(e.x-f.x,e.z-f.z)<e.def.raio+.25&&f.y>e.y-.1&&f.y<e.y+e.def.alt+.2);
  if(e){ferirSer(e,f.dano,f.x-f.vx,f.z-f.vz,f.minha?'jogador':'flecha');f.t=99;break}
  if(!f.minha&&Math.hypot(P.x-f.x,P.z-f.z)<.5&&f.y<P.y+.25&&f.y>P.y-1.75){ferirJogador(f.dano,f.x-f.vx,f.z-f.vz);f.t=99;break}
  if(solidoT(f.x,f.y,f.z)||bloqueado(f.x,f.y,f.z)){f.presa=true;f.t=0;if(f.minha&&!criativo()&&Math.random()<.6){soltar('flecha',1,f.x-f.vx*.03,f.z-f.vz*.03,f.y-.2);f.t=99}}}}
 flechas=flechas.filter(f=>f.t<(f.presa?7:6))}
function faisca(x,y,z,cor,n=6,s=.18){if(!CFG.part&&n>1)n=2;for(let i=0;i<n;i++)faiscas.push({x,y,z,vx:(Math.random()-.5)*3,vy:Math.random()*3,vz:(Math.random()-.5)*3,cor,s,vida:.5+Math.random()*.4})}
function atualizarFaiscas(dt){for(const f of faiscas){f.vida-=dt;f.vy-=7*dt;f.x+=f.vx*dt;f.y+=f.vy*dt;f.z+=f.vz*dt}faiscas=faiscas.filter(f=>f.vida>0).slice(-350)}
// ---------- explosivos ----------
function acender(x,y,z,pavio=3){if(bloco(x,y,z)!==NB_.tnt)return false;definirBloco(x,y,z,0);bombas.push({x:x+.5,y,z:z+.5,t:pavio,vy:2.5});som('pavio');return true}
function explodir(x,y,z,R=3.2){const X=Math.floor(x),Y=Math.floor(y+.5),Z=Math.floor(z);
 for(let a=-4;a<=4;a++)for(let b=-4;b<=4;b++)for(let c=-4;c<=4;c++){if(Math.hypot(a,b,c)>R+Math.random()*.5)continue;const n=bloco(X+a,Y+b,Z+c);if(!n)continue;const def=BLOCOS[n];
  if(n===NB_.tnt){acender(X+a,Y+b,Z+c,.25+Math.random()*.5);continue}if(def.dur===Infinity||n===NB_.obsidiana)continue;
  definirBloco(X+a,Y+b,Z+c,0);if(def.solta&&!criativo()&&Math.random()<.3)soltar(def.solta,1,X+a+.5,Z+c+.5,Y+b)}
 for(const r of recursosPerto(20))if(Math.hypot(r.x-x,r.z-z)<R+.8&&Math.abs(r.y-y)<5){derrubar(r)}
 for(const e of seres){const d=Math.hypot(e.x-x,e.y+e.def.alt/2-y,e.z-z);if(d<R*2&&e.cav===!!CAV){if(!e.npc){ferirSer(e,70*(1-d/(R*2)),x,z,'tnt');e.vy=7*(1-d/(R*2));e.y+=.1}}}
 const d=Math.hypot(P.x-x,P.y-1-y,P.z-z);if(d<R*2){ferirJogador(55*(1-d/(R*2)),x,z);P.vy=Math.max(P.vy,8*(1-d/(R*2)))}
 cavar(x,y+.3,z,R*.85,3);verificarApoio(X,Y,Z,Math.ceil(R)+1);
 faisca(x,y+.5,z,[1,.55,.1],40,.8);faisca(x,y+1,z,[.35,.33,.32],30,1.1);somEm('explosao',x,z)}
function atualizarBombas(dt){for(const b of bombas){b.t-=dt;b.vy-=14*dt;const chao=chaoDe(b.x,b.z,b.y,.3,.3);b.y=Math.max(chao,b.y+b.vy*dt);if(b.y===chao)b.vy=0;if(Math.random()<dt*20)faisca(b.x,b.y+1.1,b.z,[1,.8,.3],1,.12)}
 for(const b of bombas.filter(b=>b.t<=0)){bombas.splice(bombas.indexOf(b),1);explodir(b.x,b.y,b.z)}}
