// ---------- texturas realistas geradas (64×64, sem emendas) ----------
const cacheTex={},TL=64;
{const A=(n,e,c,c2)=>{if(!TEX[n])TEX[n]=[e,c,c2]},C=CORES_BLOCO;
 A('grama_topo','grama','#5d9b34');A('grama_lado','grama_lado','#8a5a35','#5d9b34');A('terra','terra','#8a5a35');A('areia','areia','#dcc98a');A('neve','neve','#eef4f6');A('cascalho','paralelos','#9a948c','#605a52');A('pedra','rocha','#8a8d8c');A('pedregulho','paralelos','#8a8d8b','#4c4f4e');
 A('tijolo_pedra','tijolos','#8a8e8d','#545857');A('tijolo','tijolos','#a8503a','#d8cbb8');A('pedra_polida','polida','#a7aaa8');A('marmore','marmore','#e6e2da','#9a948a');A('tronco_lado','casca','#6e4a28');A('tronco_topo','anel','#c89a60');A('tabuas','tabuas','#b8894e');A('estante','livros','#9a6a3a');
 A('folhas','folhas','#3f7d2c');A('vidro','vidro','#dff4fa');A('palha','feno','#d9b54a');A('gelo','gelo','#a9d6f0');A('lampada','luz','#ffd968','#a8742a');A('abobora','melancia','#e07f1c','#b85f0e');A('abobora_topo','melancia','#c87018','#4e6a20');A('obsidiana','cristais','#2a1f3e');A('tnt_lado','tnt','#c8362c');A('tnt_topo','xadrez','#c9bca0','#c8362c');A('rocha_mae','rocha','#3a3b3c');A('lava','lava','#e8550a');A('agua','agua','#2f74c8');
 for(const k in C){if(k.startsWith('la_'))A(k,'la',C[k]);if(k.startsWith('min_'))A(k,'minerio','#878a89',k==='min_carvao'?'#1c1c20':C[k]);if(k.startsWith('bloco_'))A(k,'metal',C[k])}}
function texCanvas(nome){if(cacheTex[nome])return cacheTex[nome];const[estilo,cor,cor2]=TEX[nome]||['liso','#ff00ff'],cv=document.createElement('canvas');cv.width=cv.height=TL;const g=cv.getContext('2d'),im=g.createImageData(TL,TL),D=im.data;
 let sem=7;for(const ch of nome)sem=(Math.imul(sem,31)+ch.charCodeAt(0))|0;
 const H=(i,j,s=0)=>{let h=Math.imul(i+sem,374761393)^Math.imul(j+s*131,668265263);h=Math.imul(h^h>>>13,1274126177);return((h^h>>>16)>>>0)/4294967296};
 // ruído periódico: repete a cada 64 pixels
 const N=(x,y,fx,fy=fx,s=0)=>{const X=x*fx/TL,Y=y*fy/TL,i=Math.floor(X),j=Math.floor(Y),a=X-i,b=Y-j,u=a*a*(3-2*a),v=b*b*(3-2*b),h=(p,q)=>H(((p%fx)+fx)%fx,((q%fy)+fy)%fy,s);return lerp(lerp(h(i,j),h(i+1,j),u),lerp(h(i,j+1),h(i+1,j+1),u),v)};
 const F=(x,y,f=4,s=0)=>N(x,y,f,f,s)*.5+N(x,y,f*2,f*2,s+1)*.3+N(x,y,f*4,f*4,s+2)*.2;
 // células de Voronoi periódicas: [distância à borda, número da célula]
 const V=(x,y,n,s=0)=>{const p=TL/n;let a=1e9,b=1e9,id=0;const ci=Math.floor(x/p),cj=Math.floor(y/p);for(let i=ci-1;i<=ci+1;i++)for(let j=cj-1;j<=cj+1;j++){const wi=(i+n)%n,wj=(j+n)%n,d=Math.hypot(x-(i+.15+H(wi,wj,s)*.7)*p,y-(j+.15+H(wi,wj,s+5)*.7)*p);if(d<a){b=a;a=d;id=wi*17+wj}else if(d<b)b=d}return[b-a,id]};
 const c1=rgb(cor),c2=cor2?rgb(cor2):c1;
 for(let y=0;y<TL;y++)for(let x=0;x<TL;x++){let c=c1,k=1,al=255;const r=H(x,y,9),fino=(r-.5);
  switch(estilo){
   case'rocha':{const f=F(x,y,4);k=.74+f*.52+fino*.1;const q=Math.abs(N(x,y,5,5,7)-.5);if(q<.025)k*=.72;if(r>.97)k*=1.2;break}
   case'terra':{k=.7+F(x,y,5)*.6+fino*.2;const[b,id]=V(x,y,7);if(b>4&&H(id,1)>.72){k*=1.22;c=[c1[0]*1.05,c1[1]*1.05,c1[2]*1.1]}if(r>.95)k*=.6;break}
   case'grama':{k=.62+F(x,y,6)*.55+N(x,y,32,12,4)*.34;if(r>.93){c=[c1[0]*1.5,c1[1]*1.25,c1[2]*.7]}break}
   case'grama_lado':{const h=11+N(x,0,10,1,3)*10+N(x,0,32,1,4)*5;if(y<h){c=c2;k=.72+F(x,y,8,2)*.55}else{k=.72+F(x,y,5)*.55+fino*.2;if(y<h+3)k*=.72}break}
   case'areia':k=.88+F(x,y,4)*.18+fino*.16+Math.sin((y+N(x,y,4)*18)*TAU/16)*.025;break;
   case'neve':k=.93+F(x,y,4)*.12+(r>.985?.1:0);break;
   case'granulado':k=.78+F(x,y,8)*.35+fino*.32;break;
   case'concreto':k=.93+F(x,y,4)*.12+fino*.07;break;
   case'polida':{k=.9+F(x,y,3)*.2+fino*.05;const e=Math.min(x,y,63-x,63-y);if(e<3)k*=(x<3||y<3)?1.16:.78;break}
   case'camadas':k=.8+N(x,y+N(x,y,4)*10,2,10,3)*.35+fino*.12;break;
   case'colunas':{const q=(x+N(x,y,2,6)*5)%16;k=.75+F(x,y,5)*.4+fino*.1;if(q<2)k*=.62;else if(q<4)k*=1.15;break}
   case'tijolos':case'musgo':{const alt=16,lin=Math.floor(y/alt),ox=(x+(lin%2)*16)%64,col=Math.floor(ox/32),lx=ox%32,ly=y%alt;
     if(ly<2||lx<2){c=estilo==='musgo'?[.33,.35,.34]:c2;k=.85+fino*.25}else{k=.8+H(col,lin,2)*.3+F(x,y,8)*.22-.1+fino*.08;if(ly<4||lx<4)k*=1.14;if(ly>13||lx>29)k*=.8}
     if(estilo==='musgo'&&F(x,y,5,9)+(ly<4?.1:0)>.6){c=c2;k=.7+F(x,y,12)*.6}break}
   case'paralelos':case'musgo_pedras':{const[b,id]=V(x,y,4);if(b<2.2){c=estilo==='musgo_pedras'?[.2,.22,.2]:c2;k=.8+fino*.3}else{k=.72+H(id,3)*.45+F(x,y,10)*.25-.1+Math.min(b,9)*.016}if(estilo==='musgo_pedras'&&F(x,y,5,9)>.6){c=c2;k=.7+F(x,y,12)*.6}break}
   case'tabuas':case'deck':{const t=estilo==='deck'?8:16,lin=Math.floor(y/t),junta=(H(lin,7)*64)|0,veio=N(x+H(lin,2)*64,y,3,32,lin);k=.78+H(lin,4)*.18+veio*.3+fino*.06;const nx=(x-junta+64)%64,dn=Math.hypot((x-(junta+30)%64)/2.2,y%t-t/2);if(dn<2.5)k*=.65;if(y%t<1||nx<1)k*=.52;else if(y%t<2)k*=1.12;if(nx>1&&nx<6&&Math.abs(y%t-t/2)<1)k*=.6;break}
   case'parquet':{const bx=Math.floor(x/32),by=Math.floor(y/32),v=(bx+by)%2,p=v?x:y,q=v?y:x;k=.75+H(Math.floor(p/8),bx*2+by,3)*.3+N(q,p,3,32,2)*.25;if(p%8<1||x%32<1||y%32<1)k*=.6;break}
   case'casca':{const s=N(x+N(x,y,4,4,8)*7,y,16,3,2),s2=N(x,y,32,8,5);k=.55+s*.65+s2*.25;if(s<.3)k*=.7;if(cor==='#e4e0d4'){k=.9+s2*.15;if(N(x,y,5,14,7)>.72)k=.28}break}
   case'anel':{const d=Math.hypot(x-31.5,y-31.5)+F(x,y,5)*5;if(d>29){c=[.38,.26,.14];k=.7+F(x,y,10)*.6}else k=.82+Math.sin(d*1.15)*.14+fino*.08;break}
   case'folhas':{const[b,id]=V(x,y,8,2);if(b<1.2&&H(id,2)>.35)al=0;k=.55+H(id,4)*.65+Math.min(b,6)*.04+fino*.12;break}
   case'la':k=.86+F(x,y,6)*.2+Math.sin(x*TAU/8+Math.floor(y/4)*2)*.07+Math.sin(y*TAU/4)*.05+fino*.12;break;
   case'metal':{k=.94+N(x,y,2,40,3)*.16+fino*.04;const e=Math.min(x,y,63-x,63-y);if(e<4)k*=(x<4||y<4)?1.28:.68;if(((x+y+128)%64)<7&&e>=4)k*=1.16;const rx=Math.min(x,63-x),ry=Math.min(y,63-y);if(Math.hypot(rx-9,ry-9)<2.5)k*=.65;break}
   case'cristais':{const[b,id]=V(x,y,5,3);k=.65+H(id,1)*.75;if(b<1.5)k*=1.35;if(r>.98)k*=1.6;break}
   case'minerio':{k=.74+F(x,y,4)*.5+fino*.1;const[b,id]=V(x,y,5,11);if(H(id,8)>.52&&b>2.6+N(x,y,16)*3){c=c2;k=.75+N(x,y,12,12,3)*.55;if(r>.93)k*=1.5}break}
   case'vidro':{const e=Math.min(x,y,63-x,63-y),risco=Math.abs(x+y-46)<2||Math.abs(x+y-60)<1;al=e<4||risco?255:0;k=e<2?.82:1.08;break}
   case'telha':{const lin=Math.floor(y/16),lx=(x+(lin%2)*8)%16,ly=y%16,curva=Math.sin(lx/16*Math.PI);k=.55+curva*.5+H((x+(lin%2)*8)>>4,lin,3)*.18+fino*.08;if(ly>12)k*=1.25-(ly-12)*.18;if(ly<2)k*=.6;break}
   case'ceramica':{const e=Math.min(x%32,y%32,31-x%32,31-y%32);k=.9+F(x,y,4)*.18;if(e<1)k*=.65;else if(e<3)k*=1.12;break}
   case'azulejo':case'azulejo_flor':{const lx=x%32,ly=y%32,e=Math.min(lx,ly,31-lx,31-ly);if(e<1){c=[.55,.57,.55]}else{k=.96+F(x,y,4)*.1+(lx+ly<20?.05:0);if(estilo==='azulejo_flor'){const a=Math.atan2(ly-16,lx-16),d=Math.hypot(lx-16,ly-16);if(d<4||d<8+Math.cos(a*4)*5||Math.hypot(Math.min(lx,31-lx),Math.min(ly,31-ly))<7)c=c2}}break}
   case'xadrez':{const v=((x>>5)+(y>>5))%2;c=v?c2:c1;k=.92+F(x,y,4)*.16;if(x%32<1||y%32<1)k*=.75;break}
   case'marmore':{const v=Math.abs(Math.sin((x+y)*TAU/64+F(x,y,3)*9));k=.93+F(x,y,5)*.12;if(v<.16){c=mix(c1,c2,1-v/.16)}break}
   case'listras':{c=(x%16)<5?c2:c1;k=.94+F(x,y,8)*.12;break}
   case'feno':k=.62+N(x,y,32,6,2)*.6+fino*.15;if(Math.abs(y-14)<3||Math.abs(y-50)<3){c=[.55,.3,.12];k=.8+fino*.3}break;
   case'bambu':{const q=x%16;k=.5+Math.sin(q/16*Math.PI)*.65+fino*.07;if((y+(x>>4)*23)%32<2)k*=.62;break}
   case'trelica':{const a=(x+y)%32<6,b=(x-y+64)%32<6;al=a||b||Math.min(x,y,63-x,63-y)<4?255:0;k=.8+F(x,y,8)*.35;break}
   case'melancia':{k=.75+F(x,y,6)*.25;if(Math.sin(x*TAU/16+N(x,y,4,8)*3)<-.4){c=c2;k=.8+fino*.3}break}
   case'cacto':{const q=x%16;k=.65+Math.sin(q/16*Math.PI)*.45+fino*.08;if(q===8&&y%12<3){c=[.95,.95,.75];k=1}break}
   case'osso':{k=.92+F(x,y,5)*.14;if(Math.abs((x%32)-16)<1+N(x,y,8)*2)k*=.82;break}
   case'esponja':{const[b,id]=V(x,y,7,4);k=.95+F(x,y,8)*.15;if(H(id,5)>.5&&b>3)k*=.5;break}
   case'mel':k=.85+F(x,y,3)*.35+(Math.min(x,y,63-x,63-y)<6?.15:0);break;
   case'arada':k=.7+F(x,y,8)*.4+Math.sin(y*TAU/16)*.22+fino*.15;break;
   case'gelo':{k=.94+F(x,y,3)*.16;if(Math.abs(N(x,y,5,5,3)-.5)<.02)k*=1.2;al=255;break}
   case'livros':{const lin=y>>5,ly=y%32;if(ly<4||x<3||x>60){k=.85+N(x,y,3,32)*.3}else{const l=Math.floor((x-3)/6),h=H(l,lin,2);if(ly<6+h*7){c=[.16,.1,.06];k=1}else{c=[[.68,.18,.18],[.18,.36,.65],[.18,.55,.35],[.76,.62,.2],[.45,.22,.55]][(H(l,lin,5)*5)|0];k=.75+Math.sin((x-3)%6/6*Math.PI)*.4;if(ly===14||ly===24)k*=1.4}}break}
   case'luz':{const e=Math.min(x,y,63-x,63-y);if(e<7||Math.abs(x-31.5)<2||Math.abs(y-31.5)<2){c=c2;k=.9+fino*.2}else k=1.05+F(x,y,6)*.2;break}
   case'lanterna':{const e=Math.min(x,63-x);if(y<10||y>54||e<8||Math.abs(x-31.5)<2){c=[.16,.15,.14];k=.8+F(x,y,8)*.5}else k=1.2-Math.hypot(x-31.5,y-32)/80;break}
   case'neon':{const e=Math.min(x,y,63-x,63-y);k=e<5?.65:1.05+F(x,y,4)*.15+(e<12?.1:0);break}
   case'cogumelo_luz':{const[b,id]=V(x,y,4,6);k=.65+F(x,y,6)*.3;if(b>6&&H(id,2)>.3){c=[.85,1,.95];k=1.1}break}
   case'brasa':{const[b]=V(x,y,4,9);if(b<4){c=[1,.62,.12];k=1.2-b*.1}else{c=[.2,.14,.13];k=.7+F(x,y,8)*.6}break}
   case'lava':{const f=F(x,y,4),[b]=V(x,y,4,2);k=.75+f*.55;if(b<5)c=[1,.78,.15];if(f<.38)c=[.55,.12,.02];break}
   case'agua':k=.85+F(x,y,4)*.3+(Math.abs(N(x,y,6,12,3)-.5)<.04?.25:0);break;
   case'engrenagem':{const lx=x%32-16,ly=y%32-16,d=Math.hypot(lx,ly),a=Math.atan2(ly,lx),R=10+(Math.cos(a*8)>0?4:0);k=.75+F(x,y,6)*.2;if(d<R){k=1.2-d*.012;if(d<4)k=.45}break}
   case'tnt':{if(y>20&&y<44){c=[.94,.91,.84];k=.95+fino*.08;const lx=(x-8)%48,ly=y-25;const T=(ox)=>ly>=0&&ly<14&&((ly<3&&lx>=ox&&lx<ox+12)||(lx>=ox+4&&lx<ox+8)),Nn=(ox)=>ly>=0&&ly<14&&((lx>=ox&&lx<ox+3)||(lx>=ox+9&&lx<ox+12)||Math.abs(lx-ox-ly*.7-1)<2);if(T(0)||Nn(15)||T(30)){c=[.12,.1,.1];k=1}}else{k=.8+Math.sin((x%16)/16*Math.PI)*.35+fino*.1}break}
   default:k=1+fino*.1}
  const o=(y*TL+x)*4;D[o]=clamp(c[0]*k*255,0,255);D[o+1]=clamp(c[1]*k*255,0,255);D[o+2]=clamp(c[2]*k*255,0,255);D[o+3]=al}
 g.putImageData(im,0,0);return cacheTex[nome]=cv}
const TEXTURAS=[...new Set(BLOCOS.slice(1).flatMap(b=>b.tex))];
const camada=BLOCOS.map(b=>b?b.tex.map(t=>TEXTURAS.indexOf(t)):null);
let atlas=null;
function criarAtlas(){atlas=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D_ARRAY,atlas);gl.texStorage3D(gl.TEXTURE_2D_ARRAY,7,gl.RGBA8,TL,TL,TEXTURAS.length);
 TEXTURAS.forEach((t,i)=>gl.texSubImage3D(gl.TEXTURE_2D_ARRAY,0,0,0,i,TL,TL,1,gl.RGBA,gl.UNSIGNED_BYTE,texCanvas(t).getContext('2d').getImageData(0,0,TL,TL).data));
 gl.generateMipmap(gl.TEXTURE_2D_ARRAY);const an=gl.getExtension('EXT_texture_filter_anisotropic');if(an)gl.texParameterf(gl.TEXTURE_2D_ARRAY,an.TEXTURE_MAX_ANISOTROPY_EXT,4);
 gl.texParameteri(gl.TEXTURE_2D_ARRAY,gl.TEXTURE_MIN_FILTER,gl.LINEAR_MIPMAP_LINEAR);filtroAtlas();
 MATT.forEach((m,i)=>camadaT[i]=Math.max(0,TEXTURAS.indexOf(i===0?'grama_topo':m[0]==='argila'?'argila_bloco':BLOCOS[NB_[m[0]]]?.tex[0]||'terra')))}
function filtroAtlas(){if(!atlas)return;gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D_ARRAY,atlas);gl.texParameteri(gl.TEXTURE_2D_ARRAY,gl.TEXTURE_MAG_FILTER,CFG.texSuave?gl.LINEAR:gl.NEAREST)}
// ícones dos blocos em perspectiva, com a textura real
{const antigo=icone;icone=function(id){const it=ITENS[id];if(!it||it.cat!=='cubo')return antigo(id);if(cacheIcone[id])return cacheIcone[id];const c=document.createElement('canvas');c.width=c.height=64;const g=c.getContext('2d'),b=BLOCOS[it.bloco];
 for(const[tex,m,s]of[[b.tex[0],[28,14,-28,14,32,4],0],[b.tex[1],[28,14,0,28,4,18],.18],[b.tex[1],[28,-14,0,28,32,32],.34]]){g.save();g.setTransform(m[0]/64,m[1]/64,m[2]/64,m[3]/64,m[4],m[5]);g.drawImage(texCanvas(tex),0,0);g.globalCompositeOperation='source-atop';g.fillStyle=`rgba(0,0,0,${s})`;g.fillRect(0,0,64,64);g.restore()}return cacheIcone[id]=c.toDataURL()}}
