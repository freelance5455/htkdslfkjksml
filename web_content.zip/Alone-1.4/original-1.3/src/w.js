// ---------- mundo em pedaços ----------
const PASSO=2.5,BLOCO=50,CEL=20,REG=260;
let M=null,ATUAL=null,ES=null;
const novoES=()=>({removidos:{},baus:{},pegos:{},sorteios:{},suprimentos:[],edits:[],cavernas:{},cava:[]});
const celula=(x,z)=>(Math.floor(x/6)+900)*4000+Math.floor(z/6)+900;
function addCol(c){const R=c.r!==undefined?c.r:Math.hypot(c.hw,c.hd);c.cels=[];
 for(let a=Math.floor((c.x-R)/6);a<=Math.floor((c.x+R)/6);a++)for(let b=Math.floor((c.z-R)/6);b<=Math.floor((c.z+R)/6);b++){const k=(a+900)*4000+b+900;let l=M.solidos.get(k);if(!l)M.solidos.set(k,l=[]);l.push(c);c.cels.push(k)}
 if(ATUAL)ATUAL.cols.push(c);return c}
function tirarCols(lista){for(const c of lista){c.morto=true;for(const k of c.cels){const l=M.solidos.get(k);if(l){const i=l.indexOf(c);if(i>=0)l.splice(i,1);if(!l.length)M.solidos.delete(k)}}}}
const circulo=(x,z,r,topo=3)=>addCol({x,z,r,topo:altura(x,z)+topo});
const paredeCol=(x,z,hw,hd,a,topo=2.7)=>addCol({x,z,hw,hd,a,topo:altura(x,z)+topo});
function resolver(x,z,raio,y){if(CAV)return[x,z];const gx=Math.floor(x/6),gz=Math.floor(z/6);
 for(let a=-1;a<=1;a++)for(let b=-1;b<=1;b++){const l=M.solidos.get((gx+a+900)*4000+gz+b+900);if(!l)continue;for(const c of l){if(c.morto||(y!==undefined&&(y>c.topo||y<c.topo-10)))continue;
  if(c.r!==undefined){const dx=x-c.x,dz=z-c.z,d=Math.hypot(dx,dz),m=c.r+raio;if(d<m&&d>1e-4){x=c.x+dx/d*m;z=c.z+dz/d*m}}
  else{const co=Math.cos(c.a),s=Math.sin(c.a),dx=x-c.x,dz=z-c.z;let lx=co*dx-s*dz,lz=s*dx+co*dz;const hw=c.hw+raio,hd=c.hd+raio;
   if(Math.abs(lx)<hw&&Math.abs(lz)<hd){if(hw-Math.abs(lx)<hd-Math.abs(lz))lx=hw*(lx<0?-1:1);else lz=hd*(lz<0?-1:1);x=c.x+co*lx+s*lz;z=c.z-s*lx+co*lz}}}}
 return[x,z]}
function bloqueado(x,y,z){if(solidoVox(Math.floor(x),Math.floor(y),Math.floor(z)))return true;if(CAV)return false;const l=M.solidos.get(celula(x,z));if(!l)return false;return l.some(c=>{if(c.morto||y>c.topo||y<c.topo-10)return false;if(c.r!==undefined)return Math.hypot(x-c.x,z-c.z)<c.r;
 const co=Math.cos(c.a),s=Math.sin(c.a),dx=x-c.x,dz=z-c.z;return Math.abs(co*dx-s*dz)<c.hw&&Math.abs(s*dx+co*dz)<c.hd})}
const girar=(x,z,a,lx,lz)=>[x+Math.cos(a)*lx+Math.sin(a)*lz,z-Math.sin(a)*lx+Math.cos(a)*lz];

// ---------- relevo ----------
const regiaoDe=(i,j)=>M.regioes.get(i*1000+j);
function vizinhas(x,z){const i=Math.round(x/REG),j=Math.round(z/REG),k=i*1000+j;if(M.vizK===k)return M.vizL;const l=[];for(let a=-1;a<=1;a++)for(let b=-1;b<=1;b++){const r=regiaoDe(i+a,j+b);if(r)l.push(r)}M.vizK=k;return M.vizL=l}
function relevoBase(x,z){const d0=Math.hypot(x,z),mar=(1-smooth(.2,.36,ruido(x*.0017+17,z*.0017+5)))*smooth(150,330,d0);
 let h=(fbm(x*.011+3,z*.011+8)-.4)*25+(ruido(x*.07,z*.07)-.5)*1.4+(ruido(x*.0045+2,z*.0045)-.45)*9;h=lerp(h,-7.5+ruido(x*.03,z*.03)*3,mar);
 for(const r of vizinhas(x,z)){const l=r.lago;if(l){const d=Math.hypot(x-l.x,z-l.z);if(d<l.r)h=lerp(h,-l.f,1-smooth(l.r*.45,l.r,d))}const s=r.serra;if(s){const d=Math.hypot(x-s.x,z-s.z);if(d<s.r){const k=1-smooth(0,s.r,d);h+=k*k*s.alt*(.75+fbm(x*.08,z*.08)*.55)}}}
 h=lerp(3,h,smooth(11,42,d0));return h+smooth(M.MEIO-60,M.MEIO,Math.max(Math.abs(x),Math.abs(z)))*45}
function relevo(x,z){let h=relevoBase(x,z);for(const r of vizinhas(x,z)){const v=r.vila;if(v){const d=Math.hypot(x-v.x,z-v.z);if(d<54)h=lerp(v.y,h,smooth(31,54,d))}}return h}
function alturas(cx,cz){const k=(cx+500)*1000+cz+500;let a=M.hc.get(k);if(!a){if(M.hc.size>1200)M.hc.clear();a=new Float32Array((CEL+1)**2);for(let j=0;j<=CEL;j++)for(let i=0;i<=CEL;i++)a[j*(CEL+1)+i]=relevo(cx*BLOCO+i*PASSO,cz*BLOCO+j*PASSO);M.hc.set(k,a)}return a}
function altura(x,z){const cx=Math.floor(x/BLOCO),cz=Math.floor(z/BLOCO),H=alturas(cx,cz),fx=clamp((x-cx*BLOCO)/PASSO,0,CEL-.001),fz=clamp((z-cz*BLOCO)/PASSO,0,CEL-.001),i=fx|0,j=fz|0,u=fx-i,v=fz-j,q=j*(CEL+1)+i;
 const a=H[q],b=H[q+1],c=H[q+CEL+1],d=H[q+CEL+2];return u+v<1?a+(b-a)*u+(c-a)*v:d+(c-d)*(1-u)+(b-d)*(1-v)}
function bioma(x,z){const perto=1-smooth(60,130,Math.hypot(x,z)),t=lerp(ruido(x*.0034+50,z*.0034+9),.5,perto),u=lerp(ruido(x*.004+13,z*.004+70),.55,perto);
 return t<.3?'neve':t>.68&&u<.36?'deserto':t>.62&&u<.5?'savana':u>.62?'pinheiral':u<.38?'betulas':ruido(x*.012+4,z*.012+31)<.4?'campina':'carvalhal'}
const NOME_BIOMA={neve:'Campos nevados',deserto:'Deserto',savana:'Savana dourada',pinheiral:'Pinheiral',betulas:'Bosque de bétulas',campina:'Campina',carvalhal:'Carvalhal'};
const CORES_BIOMA={carvalhal:[[.17,.32,.1],[.33,.46,.14]],pinheiral:[[.11,.25,.11],[.22,.34,.13]],betulas:[[.28,.41,.13],[.47,.52,.18]],campina:[[.28,.45,.13],[.5,.58,.2]],savana:[[.55,.45,.17],[.7,.57,.25]],neve:[[.76,.82,.86],[.93,.96,.98]],deserto:[[.8,.68,.42],[.89,.79,.52]]};

// ---------- características do mundo, sorteadas por região ----------
const NOMES_VILA=['Aroeira','Jatobá','Ipê','Cedro','Orvalho','Serena','Juazeiro','Aurora','Pitanga','Sabiá','Mandacaru','Buriti','Angico','Peroba','Carnaúba','Umbuzeiro','Maracá','Araçá','Cajá','Seriema'];
const PREFIXOS=['Vila ','Recanto ','Arraial ','Povoado ','Sítio ','Porto '];
const NOMES_H=['Bento','Tião','Raul','Inácio','Joaquim','Otávio','Caio','Severino','Davi','Lucas','Amadeu','Rui','Zeca','Anselmo'],NOMES_M=['Irma','Dalva','Cecília','Nina','Zulmira','Helena','Iara','Rosa','Lurdes','Marina','Teresa','Bia','Antônia','Jurema'];
function layoutVila(v){semearLocal(Math.round(v.x),Math.round(v.z),5);const angRoca=rnd()*TAU,n=inteiro(5,7),casas=[],pontos=[[0,3.6],[3.2,-2],[-3.2,-2],[6,6],[-6,6],[7,-6],[-7,-7],[0,10],[11,0],[-11,0],[0,-11]];
 const roca={x:v.x+Math.sin(angRoca)*22,z:v.z+Math.cos(angRoca)*22,a:angRoca+Math.PI};
 for(let k=1;k<=n;k++){const ang=angRoca+k*TAU/(n+1)+entre(-.1,.1),r=entre(19,24),x=v.x+Math.sin(ang)*r,z=v.z+Math.cos(ang)*r,a=Math.round(Math.atan2(v.x-x,v.z-z)/(Math.PI/2))*(Math.PI/2),w=7,d=7;const porta=girar(Math.floor(x)+.5,Math.floor(z)+.5,a,0,d/2+1.2);casas.push({x:Math.floor(x)+.5,z:Math.floor(z)+.5,a,w,d,porta});pontos.push([porta[0]-v.x,porta[1]-v.z])}
 pontos.push([(roca.x-v.x)*.65,(roca.z-v.z)*.65]);v.casas=casas;v.roca=roca;v.pontos=pontos.map(([a,b])=>({x:v.x+a,z:v.z+b}));
 const npc=(papel,lx,lz,k=0)=>{const fem=rnd()<.5||papel==='fazendeira',pool=fem?NOMES_M:NOMES_H;M.npcs.push({id:`v${v.i}-${papel}${k}`,papel,nome:(papel==='anciao'?(fem?'Anciã ':'Ancião '):'')+escolher(pool),fem,vila:v.i,x:v.x+lx,z:v.z+lz,cor:[entre(.2,.8),entre(.2,.7),entre(.2,.8)],casa:escolher(casas).porta})};
 npc('anciao',-1,4);npc('ferreiro',-6.4,-3.2);npc('mercador',1,-8.9);npc('fazendeira',(roca.x-v.x)*.62,(roca.z-v.z)*.62);npc('cacador',9,-1);for(let k=1;k<=inteiro(2,4);k++)npc('aldeao',entre(-8,8),entre(4,10),k)}
function criarRegioes(){const n=Math.ceil(M.MEIO/REG),usados={};
 for(let i=-n;i<=n;i++)for(let j=-n;j<=n;j++){const cx=i*REG,cz=j*REG;if(Math.max(Math.abs(cx),Math.abs(cz))>M.MEIO-100)continue;semearLocal(i,j,3);const r={i,j};M.regioes.set(i*1000+j,r);M.vizK=null;
  const q=[[-66,-66],[66,-66],[-66,66],[66,66]].sort(()=>rnd()-.5),inicial=!i&&!j;let tipos;
  if(inicial)tipos=['vila','pedreira','lago','caverna'];else{tipos=[['vila',.36],['serra',.26],['lago',.38],['pedreira',.22],['ruina',.45],['caverna',.35]].filter(t=>rnd()<t[1]).map(t=>t[0]).sort(()=>rnd()-.5).slice(0,4);if(Math.abs(i)+Math.abs(j)===1&&(i===1||j===1)&&!tipos.includes('serra'))tipos=['serra',...tipos].slice(0,4)}
  tipos.forEach((t,k)=>{const x=cx+q[k][0]+entre(-12,12),z=cz+q[k][1]+entre(-12,12);if(Math.max(Math.abs(x),Math.abs(z))>M.MEIO-80)return;
   if(t==='lago')r.lago={x,z,r:entre(26,54),f:entre(3,6)};else if(t==='serra'){r.serra={x,z,r:entre(42,60),alt:entre(17,28),i:M.serras.length};M.serras.push(r.serra)}else r['_'+t]={x,z}});
 }
 // segunda passada: o que depende do relevo
 for(const r of M.regioes.values()){M.vizK=null;semearLocal(r.i,r.j,4);const p=r._vila;
  if(p){const am=[[0,0],[20,0],[-20,0],[0,20],[0,-20]].map(o=>relevoBase(p.x+o[0],p.z+o[1]));if(!r.i&&!r.j||Math.min(...am)>-4){let nome=escolher(PREFIXOS)+escolher(NOMES_VILA);usados[nome]=(usados[nome]||0)+1;if(usados[nome]>1)nome+=' '+['','','II','III','IV','V','VI','VII','VIII'][Math.min(usados[nome],8)];
    const v={i:M.vilas.length,x:p.x,z:p.z,y:Math.round(clamp(am.reduce((s,a)=>s+a)/5,2,8)),nome,descoberta:false};M.vilas.push(v);r.vila=v}}}
 for(const r of M.regioes.values()){M.vizK=null;
  for(const[t,lista]of[['_pedreira',M.pedreiras],['_ruina',M.ruinas],['_caverna',M.cavernas]]){const p=r[t];if(!p)continue;const h=relevo(p.x,p.z),inicial=!r.i&&!r.j;if(!inicial&&(h<1||h>22))continue;p.i=lista.length;lista.push(p);r[t.slice(1)]=p}}
 for(const v of M.vilas)layoutVila(v)}
function gerarMapa(){const L=420,cv=document.createElement('canvas');cv.width=cv.height=L;const g=cv.getContext('2d'),im=g.createImageData(L,L),p=M.MEIO*2/L;
 for(let j=0;j<L;j++)for(let i=0;i<L;i++){const x=(i+.5)*p-M.MEIO,z=(j+.5)*p-M.MEIO,h=relevo(x,z);let c;if(h<0)c=mix([.2,.46,.6],[.08,.22,.36],clamp(-h/6,0,1));else{const b=CORES_BIOMA[bioma(x,z)];c=mix(b[0],b[1],.5);c=mix(c,[.45,.45,.42],smooth(14,24,h));c=mix(c,[.85,.88,.9],smooth(30,40,h)).map(v=>v*clamp(.9+h*.012,.9,1.15))}
  im.data.set([c[0]*255,c[1]*255,c[2]*255,255],(j*L+i)*4)}g.putImageData(im,0,0);M.imagemMapa=cv}
function descartarMundo(){if(!M)return;for(const c of[...M.chunks.values()])descarregar(c);for(const v of M.vch.values()){if(v.malha)apagarMalha(v.malha);if(v.agua)apagarMalha(v.agua)}for(const[k,t]of[...M.tmalhas])descartarT(k,t)}
function gerarMundo(semente,tam){descartarMundo();semearTexto(semente);
 M={semente,tam,MEIO:TAMANHOS[tam][0],regioes:new Map(),vilas:[],serras:[],pedreiras:[],ruinas:[],cavernas:[],npcs:[],solidos:new Map(),hc:new Map(),chunks:new Map(),estacoes:[],luzes:[],camas:[],baus:[],chao:[],entradas:[],refugios:[],edits:new Map(),estrut:new Map(),tags:new Map(),vch:new Map(),vizK:null,vizL:[]};
 criarRegioes();M.hc.clear();M.vizK=null;M.refugios=[{x:0,z:0,r:15},...M.vilas.map(v=>({x:v.x,z:v.z,r:31}))];gerarMapa();iniciarTerra();return M}
