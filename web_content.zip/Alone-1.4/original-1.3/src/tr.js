// ---------- terreno escavável: campo de densidade, cavernas e malha suave ----------
// materiais do subsolo: [bloco da textura, nome, item recolhido, dureza, ferramenta, nível]
const MATT=[['grama','Terra',null,.55,'pa',0],['terra','Terra','b_terra',.55,'pa',0],['areia','Areia','b_areia',.5,'pa',0],['cascalho','Cascalho','b_cascalho',.7,'pa',0],
 ['pedra','Pedra','pedra',1.7,'picareta',1],['granito','Granito','b_granito',1.9,'picareta',1],['basalto','Basalto','b_basalto',2.2,'picareta',1],['marmore','Mármore','b_marmore',1.9,'picareta',1],
 ['min_carvao','Carvão','carvao',2,'picareta',1],['min_ferro','Ferro','ferro',2.3,'picareta',2],['min_cobre','Cobre','cobre',2.1,'picareta',2],['min_ouro','Ouro','ouro',2.6,'picareta',3],['min_cristal','Cristal','cristal',2.7,'picareta',3],
 ['min_diamante','Diamante','diamante',3,'picareta',3],['min_esmeralda','Esmeralda','esmeralda',2.8,'picareta',3],['min_rubi','Rubi','rubi',2.8,'picareta',3],['min_safira','Safira','safira',2.8,'picareta',3],['min_ametista','Ametista','ametista',2.5,'picareta',2],['rocha_mae','Rocha-mãe',null,Infinity,null,9],
 ['neve','Neve','b_neve',.4,'pa',0],['calcario','Calcário','b_calcario',1.7,'picareta',1],['argila','Argila','argila',.6,'pa',0]];
// veios: [material, fundura mínima, limiar, escala]
const VEIOS=[[13,44,.815,.27],[15,36,.822,.29],[16,34,.822,.31],[14,30,.825,.3],[12,26,.815,.26],[11,18,.812,.25],[17,14,.815,.24],[9,8,.795,.23],[10,6,.8,.22],[8,3.5,.775,.2]];
const hash3=(x,y,z)=>{let h=Math.imul(x+deslX,374761393)^Math.imul(y,1103515245)^Math.imul(z+deslZ,668265263);h=Math.imul(h^h>>>13,1274126177);return((h^h>>>16)>>>0)/4294967296};
function ruido3(x,y,z){const i=Math.floor(x),j=Math.floor(y),k=Math.floor(z),f=x-i,g=y-j,h=z-k,u=f*f*(3-2*f),v=g*g*(3-2*g),w=h*h*(3-2*h);
 const a=hash3(i,j,k),b=hash3(i+1,j,k),c=hash3(i,j+1,k),d=hash3(i+1,j+1,k),e=hash3(i,j,k+1),F=hash3(i+1,j,k+1),G=hash3(i,j+1,k+1),H=hash3(i+1,j+1,k+1);
 return lerp(lerp(lerp(a,b,u),lerp(c,d,u),v),lerp(lerp(e,F,u),lerp(G,H,u),v),w)}
function materialT(x,y,z,prof){if(y<=FUNDO+3)return 18;if(prof<3.4){const b=bioma(x,z);return b==='deserto'||altura(x,z)<1?2:b==='neve'&&prof<1.4?19:1}
 for(let q=0;q<VEIOS.length;q++){const[m,p,l,s]=VEIOS[q];if(prof>p&&ruido3(x*s+q*37.7,y*s*1.15+q*11.3,z*s-q*23.1)>l)return m}
 const a=ruido3(x*.085+90,y*.11,z*.085);if(a>.76)return 3;if(a<.2)return prof<14?21:5;const b=ruido3(x*.055,y*.075+50,z*.055+70);if(b>.74)return 7;if(b<.22)return prof<18?20:6;
 return y<-38+ruido(x*.1,z*.1)*8?6:4}

// cavernas naturais: túneis sinuosos e salões. Positivo = rocha
function cavidade(x,y,z){const a=ruido3(x*.037,y*.062,z*.037)-.5,b=ruido3(x*.037+43,y*.062+17,z*.037-29)-.5,t=(Math.sqrt(a*a+b*b)-.082)*20,s=(.755-ruido3(x*.046-61,y*.07+7,z*.046+13))*22;return Math.min(t,s)}
const tk=(a,b)=>(a+2048)*4096+b+2048,ck=(a,b,c)=>((a+2048)*4096+b+2048)*64+c+32; // (x, z, y)
const sdSeg=(x,y,z,s)=>{const[ax,ay,az,bx,by,bz,r]=s,dx=bx-ax,dy=by-ay,dz=bz-az,l=dx*dx+dy*dy+dz*dz,t=l?clamp(((x-ax)*dx+(y-ay)*dy+(z-az)*dz)/l,0,1):0;return Math.hypot(x-ax-dx*t,y-ay-dy*t,z-az-dz*t)-r};
function marcarArea(x,z,r,corta){for(let a=Math.floor((x-r)/16);a<=Math.floor((x+r)/16);a++)for(let b=Math.floor((z-r)/16);b<=Math.floor((z+r)/16);b++){M.mexidos.add(tk(a,b));if(corta&&!M.cortes.has(tk(a,b))){M.cortes.set(tk(a,b),[a,b]);M.mascaraSuja=true}}}
function criarTuneis(){M.tuneis=[];M.camaras=[];
 for(const f of M.cavernas){semearLocal(Math.round(f.x),Math.round(f.z),778);const novos=[];
  const andarT=(p,a,passo,desce,r)=>{const q=[p[0]+Math.sin(a)*passo,p[1]-desce,p[2]+Math.cos(a)*passo];novos.push([...p,...q,r]);return q};
  let a=rnd()*TAU;f.dir=a;const boca=[f.x,relevo(f.x,f.z)+.9,f.z];let p=andarT(boca,a,9,4.6,2.5);p=andarT(p,a+=entre(-.6,.6),9,5,2.3);const meio=p;
  for(let k=0;k<3;k++)p=andarT(p,a+=entre(-.9,.9),entre(8,12),entre(2,5),entre(1.9,2.7));
  const sala=r=>{novos.push([...p,p[0]+entre(-4,4),p[1],p[2]+entre(-4,4),r]);M.camaras.push({x:p[0],y:p[1],z:p[2],r,i:f.i})};sala(entre(5.5,7.5));f.fundo=M.camaras.at(-1);
  p=meio;a+=Math.PI*.6;for(let k=0;k<3;k++)p=andarT(p,a+=entre(-.7,.7),entre(8,11),entre(.5,3.5),entre(1.8,2.4));sala(entre(4.5,6));
  p=[f.fundo.x,f.fundo.y,f.fundo.z];for(let k=0;k<4;k++)p=andarT(p,a+=entre(-1,1),entre(9,12),entre(3,6),entre(1.7,2.3));sala(entre(5,8));
  M.tuneis.push(...novos);
  for(const s of novos){const l=Math.hypot(s[3]-s[0],s[5]-s[2]),n=Math.ceil(l/4)+1;for(let i=0;i<=n;i++){const t=i/n,x=lerp(s[0],s[3],t),y=lerp(s[1],s[4],t),z=lerp(s[2],s[5],t);marcarArea(x,z,s[6]+2.5,y+s[6]>relevo(x,z)-1.6)}}}}
function iniciarTerra(){Object.assign(M,{campos:new Map(),tmalhas:new Map(),opsC:new Map(),mexidos:new Set(),cortes:new Map(),mascaraSuja:true,mascaraO:null});criarTuneis();
 const l=ES.cava||(ES.cava=[]);for(let i=0;i+4<l.length;i+=5)registrarOp([l[i]/10,l[i+1]/10,l[i+2]/10,l[i+3]/10,l[i+4]])}
function registrarOp(op){const[x,y,z,r]=op,R=r+2.5;
 for(let a=Math.floor((x-R)/16);a<=Math.floor((x+R)/16);a++)for(let b=Math.floor((z-R)/16);b<=Math.floor((z+R)/16);b++)for(let c=Math.floor((y-R)/16);c<=Math.floor((y+R)/16);c++){const k=ck(a,b,c);let l=M.opsC.get(k);if(!l)M.opsC.set(k,l=[]);l.push(op)}
 marcarArea(x,z,r+1.2,y+r>=relevo(x,z)-1.8)}

// ---------- campo ----------
function gerarCampo(cx,cy,cz){const f=new Float32Array(6859),x0=cx*16-1,y0=cy*16-1,z0=cz*16-1,hs=new Float32Array(361);let hMax=-1e9;
 for(let k=0;k<19;k++)for(let i=0;i<19;i++){const h=altura(x0+i,z0+k);hs[k*19+i]=h;if(h>hMax)hMax=h}
 if(y0>hMax+1.5){f.fill(-1.5);return f}
 const tun=M.tuneis.filter(s=>{const r=s[6]+2;return Math.max(s[0],s[3])+r>x0&&Math.min(s[0],s[3])-r<x0+18&&Math.max(s[2],s[5])+r>z0&&Math.min(s[2],s[5])-r<z0+18&&Math.max(s[1],s[4])+r>y0&&Math.min(s[1],s[4])-r<y0+18});
 let grosso=null;if(hMax-y0>3.5){grosso=new Float32Array(1000);for(let j=0;j<10;j++)for(let k=0;k<10;k++)for(let i=0;i<10;i++)grosso[(j*10+k)*10+i]=cavidade(x0+i*2,y0+j*2,z0+k*2)}
 const G=(i,j,k)=>grosso[(j*10+k)*10+i],ops=M.opsC.get(ck(cx,cz,cy));
 for(let j=0;j<19;j++){const y=y0+j;for(let k=0;k<19;k++){const z=z0+k;for(let i=0;i<19;i++){const x=x0+i,h=hs[k*19+i],d=h-y;let v=d>1.5?1.5:d;
    if(grosso&&d>3.2&&y>FUNDO+4){const a=i>>1,b=j>>1,c=k>>1,u=(i&1)*.5,w=(j&1)*.5,t=(k&1)*.5,a1=Math.min(9,a+1),b1=Math.min(9,b+1),c1=Math.min(9,c+1);
     let n=lerp(lerp(lerp(G(a,b,c),G(a1,b,c),u),lerp(G(a,b1,c),G(a1,b1,c),u),w),lerp(lerp(G(a,b,c1),G(a1,b,c1),u),lerp(G(a,b1,c1),G(a1,b1,c1),u),w),t);
     if(n<2.2){n+=(ruido3(x*.42,y*.55,z*.42)-.5)*1.5+(1-smooth(3.5,9,d))*4;if(n<v)v=n}}
    for(const s of tun){let n=sdSeg(x,y,z,s);if(n<v){if(n<1.5&&d>1.5)n+=(ruido3(x*.4+9,y*.5,z*.4)-.5)*1.1;if(n<v)v=n}}
    if(y<=FUNDO+3)v=1.5;
    f[(j*19+k)*19+i]=v<-1.5?-1.5:v}}}
 if(ops)for(const op of ops)aplicarNoCampo(f,cx,cy,cz,op);
 return f}
function aplicarNoCampo(f,cx,cy,cz,op){const[x,y,z,r,tier]=op,x0=cx*16-1,y0=cy*16-1,z0=cz*16-1;
 for(let j=Math.max(0,Math.floor(y-r-2)-y0);j<=Math.min(18,Math.ceil(y+r+2)-y0);j++)for(let k=Math.max(0,Math.floor(z-r-2)-z0);k<=Math.min(18,Math.ceil(z+r+2)-z0);k++)for(let i=Math.max(0,Math.floor(x-r-2)-x0);i<=Math.min(18,Math.ceil(x+r+2)-x0);i++){
  const px=x0+i,py=y0+j,pz=z0+k;if(py<=FUNDO+3)continue;const v=clamp(Math.hypot(px-x,py-y,pz-z)-r,-1.5,1.5),q=(j*19+k)*19+i;
  if(v<f[q]){if(tier<3&&MATT[materialT(px,py,pz,altura(px,pz)-py)][5]>tier)continue;f[q]=v}}}
function campoC(cx,cy,cz){const k=ck(cx,cz,cy);let f=M.campos.get(k);if(!f){if(M.campos.size>1100){let n=0;for(const q of M.campos.keys()){M.campos.delete(q);if(++n>300)break}}M.campos.set(k,f=gerarCampo(cx,cy,cz))}return f}
const lattice=(x,y,z)=>{const a=x>>4,b=y>>4,c=z>>4;return campoC(a,b,c)[(((y-b*16)+1)*19+(z-c*16)+1)*19+(x-a*16)+1]};
function campo(x,y,z){const i=Math.floor(x),j=Math.floor(y),k=Math.floor(z),a=i>>4,b=j>>4,c=k>>4,f=campoC(a,b,c),q=(((j-b*16)+1)*19+(k-c*16)+1)*19+(i-a*16)+1,u=x-i,v=y-j,w=z-k;
 return lerp(lerp(lerp(f[q],f[q+1],u),lerp(f[q+361],f[q+362],u),v),lerp(lerp(f[q+19],f[q+20],u),lerp(f[q+380],f[q+381],u),v),w)}
const mexido=(x,z)=>M.mexidos.has(tk(Math.floor(x/16),Math.floor(z/16)));
function solidoT(x,y,z){const h=altura(x,z);if(y>h+.04)return false;if(h-y<3.2&&!mexido(x,z))return true;if(y<=FUNDO+3)return true;return campo(x,y,z)>0}
// altura do chão logo abaixo de y
function solo(x,z,y){const h=altura(x,z),mx=mexido(x,z);if(!mx&&y>=h-1.6)return h;
 let t=Math.min(y,h+.25);if(solidoT(x,t,z)){for(let s=.2;s<=1.8;s+=.2)if(!solidoT(x,t+s,z))return t+s;return t}
 for(let n=0;n<260;n++){const u=t-.3;if(solidoT(x,u,z)){let a=u,b=t;for(let i=0;i<5;i++){const m=(a+b)/2;if(solidoT(x,m,z))a=m;else b=m}return b}t=u;if(t<FUNDO)break}return t}
const soloTopo=(x,z)=>mexido(x,z)?solo(x,z,altura(x,z)+.3):altura(x,z);
function colideTerra(x,y,z,r,alt){const n=alt>1?2:1;for(let j=0;j<=n;j++){const py=y+alt*j/n;if(solidoT(x,py,z)||solidoT(x+r,py,z)||solidoT(x-r,py,z)||solidoT(x,py,z+r)||solidoT(x,py,z-r))return true}return false}
function normalT(x,y,z){const e=.45;if(!mexido(x,z)){const a=altura(x+e,z)-altura(x-e,z),b=altura(x,z+e)-altura(x,z-e),l=Math.hypot(a,2*e,b);return[-a/l,2*e/l,-b/l]}
 const g=[campo(x-e,y,z)-campo(x+e,y,z),campo(x,y-e,z)-campo(x,y+e,z),campo(x,y,z-e)-campo(x,y,z+e)],l=Math.hypot(...g)||1;return g.map(v=>v/l)}
function raioT(o,d,max){let ant=0;for(let t=.15;t<max;t+=.14){if(solidoT(o[0]+d[0]*t,o[1]+d[1]*t,o[2]+d[2]*t)){let a=ant,b=t;for(let i=0;i<5;i++){const m=(a+b)/2;if(solidoT(o[0]+d[0]*m,o[1]+d[1]*m,o[2]+d[2]*m))b=m;else a=m}const x=o[0]+d[0]*b,y=o[1]+d[1]*b,z=o[2]+d[2]*b;return{t:b,x,y,z,n:normalT(x,y,z)}}ant=t}return null}
const profundidade=(x,y,z)=>altura(x,z)-y;
const materialEm=(x,y,z)=>materialT(Math.round(x),Math.round(y),Math.round(z),altura(x,z)-y);

// ---------- escavar ----------
function cavar(x,y,z,r,tier){const op=[Math.round(x*10)/10,Math.round(y*10)/10,Math.round(z*10)/10,Math.round(r*10)/10,tier],removidos={};[x,y,z,r]=op;
 const antes=[];for(let a=Math.ceil(x-r-1);a<=x+r+1;a++)for(let b=Math.ceil(y-r-1);b<=y+r+1;b++)for(let c=Math.ceil(z-r-1);c<=z+r+1;c++)if(Math.hypot(a-x,b-y,c-z)<r&&b<=altura(a,c)&&lattice(a,b,c)>0)antes.push([a,b,c]);
 // regiões ainda intocadas passam a usar o campo, que precisa estar pronto
 registrarOp(op);for(let a=Math.floor((x-r-2.5)/16);a<=Math.floor((x+r+2.5)/16);a++)for(let b=Math.floor((y-r-2.5)/16);b<=Math.floor((y+r+2.5)/16);b++)for(let c=Math.floor((z-r-2.5)/16);c<=Math.floor((z+r+2.5)/16);c++){const k=ck(a,c,b),f=M.campos.get(k);if(f)aplicarNoCampo(f,a,b,c,op);const m=M.tmalhas.get(k);if(m)m.sujo=true;else M.tmalhas.set(k,{cx:a,cy:b,cz:c,sujo:true,malha:null,deco:[],novo:true})}
 for(const[a,b,c]of antes)if(lattice(a,b,c)<=0){const m=materialT(a,b,c,altura(a,c)-b);removidos[m]=(removidos[m]||0)+1}
 ES.cava.push(...[op[0],op[1],op[2],op[3]].map(v=>Math.round(v*10)),tier);
 semApoio(x,y,z,r);return removidos}
// plantas, obras e blocos que perderam o chão
function semApoio(x,y,z,r){if(y+r<altura(x,z)-3)return verificarApoio(Math.floor(x),Math.floor(y),Math.floor(z),Math.ceil(r)+1);
 for(let a=Math.floor((x-r-1)/BLOCO);a<=Math.floor((x+r+1)/BLOCO);a++)for(let b=Math.floor((z-r-1)/BLOCO);b<=Math.floor((z+r+1)/BLOCO);b++){const ch=M.chunks.get(a+','+b);if(!ch)continue;
  for(const q of ch.recursos)if(!q.morto&&Math.hypot(q.x-x,q.z-z)<r+.4&&!solidoT(q.x,q.y-.25,q.z)){if(!criativo()&&RECURSOS[q.tipo].ferr!=='picareta')coletar(q);else derrubar(q,true)}
  for(const m of ch.miudos)if(m[5]&&Math.hypot(m[2]-x,m[4]-z)<r+.4&&!solidoT(m[2],m[3]-.2,m[4])){m[5]=0;const it=ch.itens[m[0]];if(it){gl.bindBuffer(gl.ARRAY_BUFFER,it.ibuf);gl.bufferSubData(gl.ARRAY_BUFFER,m[1]*24+12,new Float32Array([0]))}}}
 for(const c of[...construcoes])if(Math.hypot(c.x-x,c.z-z)<r+.5&&!solidoT(c.x,c.y-.25,c.z)&&!solidoVox(Math.floor(c.x),Math.floor(c.y-.25),Math.floor(c.z)))desmontar(c);
 verificarApoio(Math.floor(x),Math.floor(y),Math.floor(z),Math.ceil(r)+1)}
function recolherTerra(removidos){for(const k in removidos){const m=+k,[,,item]=MATT[m],chance=m>=8&&m<18?.5:.24;let id=item;if(!id)id=bioma(P.x,P.z)==='deserto'?'b_areia':'b_terra';
  P.minerado[id]=(P.minerado[id]||0)+removidos[k]*chance;const q=Math.floor(P.minerado[id]);if(q>=1){P.minerado[id]-=q;pegar(id,q);contar('quebrou',MATT[m][0])}}}

// ---------- malha suave (redes de superfície) ----------
const ARESTAS=[[0,1],[2,3],[4,5],[6,7],[0,2],[1,3],[4,6],[5,7],[0,4],[1,5],[2,6],[3,7]];
const camadaT=MATT.map(m=>null);
function malhaT(t){const{cx,cy,cz}=t,f=campoC(cx,cy,cz),x0=cx*16,y0=cy*16,z0=cz*16;t.sujo=false;t.novo=false;
 if(t.malha){apagarMalha(t.malha);t.malha=null}apagarDeco(t);
 let temS=false,temA=false;for(let q=0;q<f.length;q+=1){if(f[q]>0)temS=true;else temA=true;if(temS&&temA)break}
 if(!(temS&&temA)){decorar(t,[],f);return}
 const idx=new Int32Array(5832).fill(-1),V=[],cortado=M.cortes.has(tk(cx,cz)),c=new Float32Array(8),chao=[],teto=[];
 for(let j=-1;j<=16;j++)for(let k=-1;k<=16;k++)for(let i=-1;i<=16;i++){const q=((j+1)*19+k+1)*19+i+1;let mask=0;
  for(let n=0;n<8;n++){c[n]=f[q+(n&1)+(n&2?361:0)+(n&4?19:0)];if(c[n]>0)mask|=1<<n}if(mask===0||mask===255)continue;
  let sx=0,sy=0,sz=0,n=0;for(const[a,b]of ARESTAS){if((c[a]>0)===(c[b]>0))continue;const u=c[a]/(c[a]-c[b]);sx+=(a&1)+((b&1)-(a&1))*u;sy+=((a>>1)&1)+(((b>>1)&1)-((a>>1)&1))*u;sz+=(a>>2)+((b>>2)-(a>>2))*u;n++}
  const x=x0+i+sx/n,y=y0+j+sy/n,z=z0+k+sz/n;let gx=c[0]+c[2]+c[4]+c[6]-c[1]-c[3]-c[5]-c[7],gy=c[0]+c[1]+c[4]+c[5]-c[2]-c[3]-c[6]-c[7],gz=c[0]+c[1]+c[2]+c[3]-c[4]-c[5]-c[6]-c[7];const l=Math.hypot(gx,gy,gz)||1;
  let best=-1,bd=9;for(let m=0;m<8;m++)if(mask>>m&1){const d=Math.abs((m&1)-sx/n)+Math.abs(((m>>1)&1)-sy/n)+Math.abs((m>>2)-sz/n);if(d<bd){bd=d;best=m}}
  const px=x0+i+(best&1),py=y0+j+((best>>1)&1),pz=z0+k+(best>>2),prof=altura(x,z)-y;
  const v={x,y,z,nx:gx/l,ny:gy/l,nz:gz/l,prof,mat:materialT(px,py,pz,altura(px,pz)-py),sup:null,ceu:clamp(1-(prof-.9)/6.5,0,1)};
  if(prof<1.3){const e=altura(x+1,z)-altura(x-1,z),g=altura(x,z+1)-altura(x,z-1);v.sup=corChao(x,z,altura(x,z),Math.hypot(e,g)/2)}
  idx[((j+1)*18+k+1)*18+i+1]=V.length;V.push(v);
  if(i>=0&&i<16&&j>=0&&j<16&&k>=0&&k<16&&prof>6){if(v.ny>.85)chao.push(v);else if(v.ny<-.8)teto.push(v)}}
 const saida=[],ID=(i,j,k)=>idx[((j+1)*18+k+1)*18+i+1];
 const tri=(a,b,d)=>{const m=a.prof>b.prof?(a.prof>d.prof?a:d):(b.prof>d.prof?b:d),sup=a.sup&&b.sup&&d.sup&&m.prof<.9;if(!cortado&&m.prof<.9)return;
  const lay=sup?-1:camadaT[m.mat];for(const v of[a,b,d]){const col=sup?v.sup:(v.sup&&m.mat===1?[1.05,1,.95]:[1,1,1]);saida.push(v.x,v.y,v.z,v.nx,v.ny,v.nz,col[0],col[1],col[2],lay,v.ceu)}};
 for(let j=0;j<=16;j++)for(let k=0;k<=16;k++)for(let i=0;i<=16;i++){const q=((j+1)*19+k+1)*19+i+1,s=f[q]>0;
  for(let e=0;e<3;e++){if((f[q+(e===0?1:e===1?361:19)]>0)===s)continue;
   const a=e===0?ID(i,j-1,k-1):e===1?ID(i-1,j,k-1):ID(i-1,j-1,k),b=e===0?ID(i,j,k-1):e===1?ID(i,j,k-1):ID(i,j-1,k),c2=ID(i,j,k),d=e===0?ID(i,j-1,k):e===1?ID(i-1,j,k):ID(i-1,j,k);
   if(a<0||b<0||c2<0||d<0)continue;tri(V[a],V[b],V[c2]);tri(V[a],V[c2],V[d])}}
 if(saida.length){const vao=gl.createVertexArray();gl.bindVertexArray(vao);const buf=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buf);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(saida),gl.STATIC_DRAW);
  [[0,3,0],[1,3,12],[2,3,24],[3,2,36]].forEach(([i,n,o])=>{gl.enableVertexAttribArray(i);gl.vertexAttribPointer(i,n,gl.FLOAT,false,44,o)});gl.bindVertexArray(null);t.malha={vao,buf,n:saida.length/11}}
 decorar(t,{chao,teto},f)}

// ---------- enfeites, poças, lava e baús das cavernas ----------
function apagarDeco(t){for(const m of t.deco)apagarMalha(m);t.deco=[]}
function decorar(t,pts,f){const key=ck(t.cx,t.cz,t.cy),tag='t'+key,x0=t.cx*16,y0=t.cy*16,z0=t.cz*16;M.luzes=M.luzes.filter(l=>l.ch!==tag);
 // lava no fundo e poças de água
 if(!t.liquidos){t.liquidos=true;for(let y=y0;y<y0+16;y++){if(y>-12)break;for(let z=z0;z<z0+16;z++)for(let x=x0;x<x0+16;x++){const q=(((y-y0)+1)*19+(z-z0)+1)*19+(x-x0)+1;
    if((f[q]+f[q+1]+f[q+19]+f[q+20]+f[q+361]+f[q+362]+f[q+380]+f[q+381])>=-.8)continue;
    if(y<=-50&&y>FUNDO+2)porEstrutura(tag,x,y,z,NB_.lava);else if(y<altura(x,z)-10&&ruido3(x*.045+300,3,z*.045)>.7&&f[q-361]+f[q-360]+f[q-342]+f[q-341]>.6)porEstrutura(tag,x,y,z,NB_.agua0)}}}
 const listas={};let luzes=0;
 const por=(tipo,v,s)=>{(listas[tipo]||(listas[tipo]=[])).push(v.x,v.y+(tipo==='estalactite'?.2:-.15),v.z,s,hash3(v.x|0,v.y|0,v.z|0)*TAU,1)};
 for(const v of pts.chao||[]){const h=hash3(Math.floor(v.x*3),Math.floor(v.y*3),Math.floor(v.z*3));if(h<.018)por('estalagmite',v,.5+h*40);else if(h<.026&&v.y<-8){por('cogu_luz',v,.8+(h-.018)*60);if(luzes<2){M.luzes.push({x:v.x,y:v.y+.7,z:v.z,i:.55,ch:tag});luzes++}}else if(h<.031&&v.y<-24){por('cristal_cav',v,.6+(h-.026)*100);if(luzes<3){M.luzes.push({x:v.x,y:v.y+.9,z:v.z,i:.7,ch:tag});luzes++}}}
 for(const v of pts.teto||[]){const h=hash3(Math.floor(v.x*3)+7,Math.floor(v.y*3),Math.floor(v.z*3));if(h<.035)por('estalactite',v,.45+h*28)}
 for(const k in listas)t.deco.push(instanciar(modelos[k],listas[k]));
 if(!t.bauVisto){t.bauVisto=true;const l=(pts.chao||[]).filter(v=>v.y<-6&&altura(v.x,v.z)-v.y>9);if(l.length>5&&hash3(t.cx*3,t.cy*5,t.cz*7)<.16){const v=l[Math.floor(hash3(t.cx,t.cy,t.cz)*l.length)];semearLocal(t.cx*31+t.cy,t.cz,55);
    addBau('T'+key,v.x,v.z,rnd()*TAU,saquear(v.y<-38?3:v.y<-18?2:1,inteiro(3,5)),v.y-.05,{ch:tag,fundo:true,rar:v.y<-30?2:1})}}}
function descartarT(k,t){if(t.malha)apagarMalha(t.malha);apagarDeco(t);const tag='t'+k;M.luzes=M.luzes.filter(l=>l.ch!==tag);M.baus=M.baus.filter(b=>b.ch!==tag);tirarEstrutura(tag);M.tmalhas.delete(k)}

// ---------- quais pedaços desenhar ----------
let proxT=0,filaT=[];
function planejarTerra(){const quer=new Map(),px=P.x,pz=P.z,R=Math.min(CFG.dist,200),pedir=(a,b,c,d)=>{const k=ck(a,c,b);if(!quer.has(k))quer.set(k,[a,b,c,d])};
 for(const[a,c]of M.cortes.values()){const d=Math.hypot(a*16+8-px,c*16+8-pz);if(d>R)continue;let lo=1e9,hi=-1e9;for(let i=0;i<=16;i+=4)for(let j=0;j<=16;j+=4){const h=altura(a*16+i,c*16+j);lo=Math.min(lo,h);hi=Math.max(hi,h)}
  for(let b=Math.floor((lo-2.5)/16);b<=Math.floor((hi+1)/16);b++)pedir(a,b,c,d*.8)}
 const prof=profundidade(px,pes(),pz);let perto=prof>1.2;if(!perto)for(let a=-2;a<=2&&!perto;a++)for(let c=-2;c<=2;c++)if(M.mexidos.has(tk(Math.floor(px/16)+a,Math.floor(pz/16)+c))){perto=true;break}
 if(perto){const rh=CFG.cavR,rv=prof>3?2:1,A=Math.floor(px/16),B=Math.floor(pes()/16),C=Math.floor(pz/16);
  for(let a=-rh;a<=rh;a++)for(let c=-rh;c<=rh;c++)for(let b=-rv;b<=rv;b++){const x=A+a,y=B+b,z=C+c;if(a*a+c*c>(rh+.5)**2||y*16>altura(x*16+8,z*16+8)+14||y<Math.floor(FUNDO/16))continue;
    if(prof<=1.2&&!M.mexidos.has(tk(x,z)))continue;pedir(x,y,z,Math.hypot(x*16+8-px,y*16+8-pes(),z*16+8-pz))}}
 for(const[k,t]of M.tmalhas)if(!quer.has(k))descartarT(k,t);
 filaT=[];for(const[k,[a,b,c,d]]of quer){const t=M.tmalhas.get(k);if(!t||t.novo)filaT.push([d,k,a,b,c])}filaT.sort((a,b)=>a[0]-b[0])}
function atualizarTerra(ms=6){if((proxT-=1)<=0){planejarTerra();proxT=20}
 const t0=performance.now();for(const t of M.tmalhas.values())if(t.sujo&&!t.novo)malhaT(t);
 for(const t of M.tmalhas.values())if(t.novo&&t.sujo){malhaT(t)}
 while(filaT.length&&performance.now()-t0<ms){const[,k,a,b,c]=filaT.shift();let t=M.tmalhas.get(k);if(!t)M.tmalhas.set(k,t={cx:a,cy:b,cz:c,deco:[],malha:null});if(!t.malha)malhaT(t)}}
function terraPronta(){proxT=0;atualizarTerra(4000)}
function refazerTerra(){for(const t of M.tmalhas.values())t.sujo=true}
// ponto de ar com chão firme perto de um lugar subterrâneo
function arLivre(cx,cy,cz,dMin,dMax){for(let n=0;n<40;n++){const a=Math.random()*TAU,d=dMin+Math.random()*(dMax-dMin),x=cx+Math.cos(a)*d,z=cz+Math.sin(a)*d,y=cy+(Math.random()-.5)*14;
 if(y>altura(x,z)-6||solidoT(x,y,z)||solidoT(x,y+1.4,z))continue;const s=solo(x,z,y);if(y-s<6&&!solidoT(x,s+.9,z)&&!solidoT(x,s+1.8,z)){const b=bloco(Math.floor(x),Math.floor(s+.2),Math.floor(z));if(!b)return{x,y:s,z}}}return null}
