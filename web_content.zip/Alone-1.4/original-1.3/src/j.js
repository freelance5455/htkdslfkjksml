// ---------- missões ----------
let missoes={};
const iniciarMissoes=()=>{missoes={passo:0,extras:[],feitas:0,seguir:'principal',seq:1,conquistas:{}}};
const maisPerto=lista=>lista.reduce((m,o)=>!m||dist2(o.x,o.z,P.x,P.z)<dist2(m.x,m.z,P.x,P.z)?o:m,null);
const s_=(c,k)=>stats[c][k]||0, qualDe=(c,ids)=>ids.reduce((a,k)=>a+s_(c,k),0);
const picaretas=['picareta_madeira','picareta_pedra','picareta_ferro'];
const PRINCIPAL=[
 {t:'Acordar sozinho',d:'Bata em árvores até juntar 8 de madeira.',meta:8,v:()=>s_('coletado','madeira'),premio:[['moeda',5],['maca',2]]},
 {t:'Um lugar para trabalhar',d:'Crie uma mesa de artesanato (Criar), segure-a e use para colocar no chão.',meta:1,v:()=>s_('construido','bancada'),premio:[['fibra',6]]},
 {t:'Primeira picareta',d:'Crie uma picareta perto da mesa de artesanato.',meta:1,v:()=>qualDe('fabricado',picaretas)+(picaretas.some(tem)?1:0),premio:[['madeira',6]]},
 {t:'Pedra sobre pedra',d:'Quebre rochas até juntar 8 de pedra.',meta:8,v:()=>s_('coletado','pedra'),premio:[['pao',2]],alvo:()=>maisPerto(M.pedreiras)},
 {t:'Há mais alguém?',d:'Siga a bússola até encontrar uma vila.',meta:1,v:()=>total('vilas')?1:0,premio:[['tocha',4]],alvo:()=>maisPerto(M.vilas)},
 {t:'A voz dos antigos',d:'Converse com o ancião ou a anciã de uma vila.',meta:1,v:()=>s_('falou','anciao')?1:0,premio:[['moeda',15],['atadura',2]],alvo:()=>maisPerto(M.npcs.filter(n=>n.papel==='anciao'))},
 {t:'A longa noite',d:'Sobreviva até o amanhecer. Fogueiras e vilas são seguras.',meta:1,v:()=>total('noites')?1:0,premio:[['flecha',12],['carne_assada',2]]},
 {t:'Os que não descansam',d:'À noite, derrote 5 zumbis.',meta:5,v:()=>s_('mortos','zumbi'),premio:[['moeda',30]]},
 {t:'Forja',d:'Minere ferro e carvão, faça lingotes numa fogueira e crie uma espada de ferro.',meta:1,v:()=>s_('fabricado','espada_ferro')+(tem('espada_ferro')?1:0),premio:[['pocao',2]],alvo:()=>maisPerto(M.pedreiras)},
 {t:'Flechas no escuro',d:'Derrote 5 esqueletos.',meta:5,v:()=>s_('mortos','esqueleto'),premio:[['moeda',40],['flecha',20]]},
 {t:'Brilho da montanha',d:'Com uma picareta de ferro, junte 4 cristais nas serras.',meta:4,v:()=>s_('coletado','cristal'),premio:[['ouro',2],['linha',3]],alvo:()=>maisPerto(M.serras)},
 {t:'Fundo da terra',d:'Encontre a entrada de uma caverna e desça por ela.',meta:1,v:()=>total('cavernas')?1:0,premio:[['tocha',12],['atadura',3]],alvo:()=>maisPerto(M.cavernas)},
 {t:'O sinal',d:'Crie o farol de sinal e construa-o perto do acampamento.',meta:1,v:()=>s_('construido','farol'),premio:[['moeda',200]],alvo:()=>({x:0,z:0})}];
let verificando=false;
const CONQUISTAS=[['lenha','Lenhador','Junte 50 de madeira',()=>s_('coletado','madeira'),50],['mineiro','Mineiro','Quebre 40 blocos',()=>total('quebrou'),40],['obra','Arquiteto','Coloque 60 blocos',()=>s_('construido','cubo'),60],
 ['caca','Caçador de monstros','Derrote 25 monstros',()=>qualDe('mortos',['zumbi','esqueleto','aranha','gosma']),25],['rei','Fim do reinado','Derrote o Rei dos Ossos',()=>total('chefes'),1],['viajante','Viajante','Descubra 5 vilas',()=>total('vilas'),5],['fundo','Espeleólogo','Explore 3 cavernas',()=>Object.keys(stats.cavernas).length,3],
 ['tesouro','Caça-tesouros','Abra 10 baús',()=>total('baus'),10],['amigo','Melhor amigo','Domestique um lobo',()=>total('domou'),1],['horta','Boa colheita','Plante 10 mudas',()=>total('plantou'),10],['pesca','Pescador','Pesque 10 vezes',()=>total('pescou'),10],['brilho','Sorte grande','Obtenha um diamante',()=>s_('coletado','diamante'),1],['dias','Sobrevivente','Chegue ao dia 7',()=>dia,7]];
function verificarMissoes(){if(verificando||!emPartida||criativo())return;verificando=true;
 for(const[id,n,,v,meta]of CONQUISTAS)if(!missoes.conquistas[id]&&v()>=meta){missoes.conquistas[id]=1;avisar(`Conquista desbloqueada: ${n}`,5);som('missao',.7);premiar([['moeda',20]])}
 while(missoes.passo<PRINCIPAL.length&&PRINCIPAL[missoes.passo].v()>=PRINCIPAL[missoes.passo].meta){const m=PRINCIPAL[missoes.passo++];premiar(m.premio);som('missao');
  avisar(`Missão concluída: ${m.t}`,5);if(missoes.passo===PRINCIPAL.length)setTimeout(()=>avisar('O farol está aceso. Quem estiver perdido saberá o caminho. Você não está mais sozinho.',14),1200)}
 verificando=false}
function premiar(lista){for(const[id,q]of lista){const r=adicionar(id,q);if(r)soltar(id,r,P.x,P.z,pes());avisar(`Recompensa: ${q}× ${ITENS[id].n}`,3)}}
const progresso=e=>e.tipo==='entregar'?tem(e.alvo):e.tipo==='matar'?s_('mortos',e.alvo)-e.base:e.tipo==='bau'?s_('baus',e.alvo):0;
function ofertaPara(n){const nomeDe=id=>ITENS[id].n.toLowerCase();
 const entregar=(lista)=>{const[id,q]=qualquer(lista);return{tipo:'entregar',alvo:id,qtd:q,titulo:`Entregar ${q}× ${nomeDe(id)}`,premio:[['moeda',Math.round(ITENS[id].valor*q*1.3)+8]]}};
 const matar=(lista)=>{const[id,q]=qualquer(lista);return{tipo:'matar',alvo:id,qtd:q,base:s_('mortos',id),titulo:`Caçar: ${q}× ${BICHOS[id].n.toLowerCase()}`,premio:[['moeda',q*(BICHOS[id].monstro?10:8)],['flecha',q*2]]}};
 const bau=()=>{const l=M.ruinas.filter(r=>!ES.baus['R'+r.i]).sort((a,b)=>dist2(a.x,a.z,n.x,n.z)-dist2(b.x,b.z,n.x,n.z)).slice(0,4);if(!l.length)return matar([['zumbi',3]]);const r=qualquer(l);return{tipo:'bau',alvo:'R'+r.i,qtd:1,base:0,titulo:'Abrir o baú perdido nas ruínas',premio:[['moeda',40],['pao',2]]}};
 const carta=()=>{const outros=M.npcs.filter(o=>o.papel==='anciao'&&o.vila!==n.vila);if(!outros.length)return matar([['esqueleto',3]]);const o=qualquer(outros);return{tipo:'carta',alvo:o.id,qtd:1,titulo:`Levar carta para ${o.nome}, em ${M.vilas[o.vila].nome}`,premio:[['moeda',45],['pocao',1]]}};
 const f={ferreiro:()=>entregar([['ferro',6],['carvao',8],['madeira',20],['pedra',20]]),fazendeira:()=>Math.random()<.7?entregar([['trigo',8],['frutas',10],['cogumelo',6]]):matar([['javali',2]]),
  cacador:()=>matar([['lobo',3],['javali',3],['zumbi',5],['esqueleto',4],['cervo',3],['aranha',4],['urso',1]]),mercador:()=>entregar([['couro',5],['pena',6],['la',4],['osso',6]]),anciao:()=>Math.random()<.65?carta():matar([['zumbi',6],['esqueleto',5]]),aldeao:()=>Math.random()<.5?bau():entregar([['maca',4],['carne_assada',2],['fibra',12]])}[n.papel];
 return Object.assign(f(),{npc:n.id,nome:n.nome,vila:n.vila})}
function aceitar(o){if(missoes.extras.length>=4){avisar('Você já tem 4 pedidos. Conclua algum antes.',3);return false}missoes.extras.push(Object.assign({id:missoes.seq++},o));missoes.seguir=missoes.extras.at(-1).id;som('pegar');salvar();return true}
function concluir(e){if(e.tipo!=='carta'&&progresso(e)<e.qtd)return;if(e.tipo==='entregar')remover(e.alvo,e.qtd);missoes.extras=missoes.extras.filter(o=>o!==e);missoes.feitas++;if(missoes.seguir===e.id)missoes.seguir='principal';premiar(e.premio);som('missao');salvar()}
function alvoDe(e){if(progresso(e)>=e.qtd&&e.tipo!=='carta')return M.npcs.find(n=>n.id===e.npc);if(e.tipo==='carta')return M.npcs.find(n=>n.id===e.alvo);if(e.tipo==='bau')return M.ruinas[+e.alvo.slice(1)];
 if(e.tipo==='matar')return maisPerto(seres.filter(s=>s.tipo===e.alvo&&!s.morte&&!s.cav));return null}
function alvoAtualMissao(){if(P.marca)return{a:P.marca,nome:'Tesouro do mapa'};if(criativo())return{a:{x:0,z:0},nome:'Acampamento'};const e=missoes.extras.find(e=>e.id===missoes.seguir);if(e){const a=alvoDe(e);if(a)return{a,nome:e.titulo}}
 const m=PRINCIPAL[missoes.passo];if(m&&m.alvo){const a=m.alvo();if(a)return{a,nome:m.t}}
 const casa={x:0,z:0};return{a:casa,nome:'Acampamento'}}

// ---------- conversas ----------
function direcao(o){const a=Math.atan2(o.x-P.x,-(o.z-P.z));return['norte','nordeste','leste','sudeste','sul','sudoeste','oeste','noroeste'][(Math.round(a/(Math.PI/4))+8)%8]}
const FALAS={
 anciao:['Antes das noites ruins, esta mata era cheia de gente.','Os mortos temem a luz. Mantenha uma fogueira acesa.','Dizem que um farol de cristal guiaria os perdidos de volta.','Nosso golem dorme pouco e bate forte. Não o provoque.','O cristal dorme no alto das serras. Só o ferro o arranca.'],
 ferreiro:['Pedra quebra ferro? Não. Picareta de pedra, porém, arranca ferro do veio.','Dois minérios e um carvão na fogueira viram um lingote.','Uma lâmina boa vale mais que dez tochas.','Se achar ouro, guarde. Ele serve às melhores armas.'],
 mercador:['Compro quase tudo. Pago quase bem.','Moeda não enche barriga, mas pão custa moeda.','Viajar à noite? Só com flechas sobrando.'],
 fazendeira:['O trigo cresce de novo em um dia.','Ensopado quente cura quase qualquer coisa.','Carne crua faz mal. Asse antes.'],
 cacador:['Esqueletos erram quem não para de andar.','Lobo é manso de dia. De noite, não.','A lança alcança antes que o bicho chegue.','Javali ferido revida. Esteja pronto.'],
 aldeao:['Durmo cedo para não ouvir os gemidos.','Já viu as ruínas? Há baús lá, e coisa pior.','Que bom ver um rosto novo por aqui!','Minha avó dizia: cama é onde a noite passa depressa.']};
function falaNpc(n){const dicas=[];const b=maisPerto(M.baus.filter(b=>!b.aberto&&dist2(b.x,b.z,P.x,P.z)>25)),v=maisPerto(M.vilas.filter(v=>v.i!==n.vila)),p=maisPerto(M.pedreiras),s=maisPerto(M.serras);
const cv=maisPerto(M.cavernas);if(cv)dicas.push(`Há uma caverna ao ${direcao(cv)}. Ouvi dizer que brilha lá dentro.`);
 if(b)dicas.push(`Vi um baú para o ${direcao(b)}, a uns ${Math.round(dist2(b.x,b.z,P.x,P.z)/10)*10} passos.`);if(v)dicas.push(`${v.nome} fica ao ${direcao(v)} daqui.`);if(p)dicas.push(`Há uma pedreira com ferro ao ${direcao(p)}.`);if(s)dicas.push(`A serra dos cristais está ao ${direcao(s)}.`);
 return Math.random()<.4&&dicas.length?qualquer(dicas):qualquer(FALAS[n.papel])}
function saudacao(n){const v=M.vilas[n.vila].nome;return noite>.5?`Está escuro. Fique perto das luzes de ${v}.`:qualquer([`Bem-vindo a ${v}.`,`Olá, viajante. Eu sou ${n.nome}.`,`Pensei que ninguém mais vinha a ${v}.`])}
const LOJAS={mercador:[['pao',1],['atadura',1],['tocha',4],['flecha',10],['pocao',1],['arco',1],['bau',1],['balde',1],['bussola',1],['relogio',1],['barco',1],['pocao_velocidade',1],['mapa_tesouro',1],['b_vidro',8],['b_lampada',4],['b_la_vermelha',8]],
 ferreiro:[['faca',1],['espada_pedra',1],['machado_pedra',1],['picareta_pedra',1],['pa_pedra',1],['carvao',5],['lingote',1],['espada_ferro',1],['picareta_ferro',1],['capacete_ferro',1],['armadura_ferro',1],['calca_ferro',1],['botas_ferro',1],['escudo',1],['tesoura',1],['martelo',1],['isqueiro',1],['nucleo_golem',1]],
 fazendeira:[['maca',3],['trigo',5],['pao',2],['sementes',6],['cenoura',4],['batata',4],['enxada_pedra',1],['bolo',1],['mel',1],['ensopado',1],['la',3],['balde_leite',1]],cacador:[['flecha',15],['arco',1],['besta',1],['lanca',1],['faca_cacador',1],['capacete_couro',1],['armadura_couro',1],['calca_couro',1],['botas_couro',1],['vara_pesca',1],['luneta',1],['carne_assada',2]]};
const precoCompra=(id,q)=>Math.ceil(ITENS[id].valor*q*1.4), precoVenda=id=>Math.max(1,Math.floor(ITENS[id].valor*.6));
function conversar(e){const n=e.npc;contar('falou',n.papel);const entrega=missoes.extras.find(m=>m.tipo==='carta'&&m.alvo===n.id);
 let texto=saudacao(n);if(entrega){texto=`Uma carta de ${entrega.nome}? Há quanto tempo! Tome isto pelo caminho.`;concluir(entrega)}abrirPainel('dialogo',{e,texto})}
