// ---------- shaders ----------
const extFloat=gl.getExtension('EXT_color_buffer_float');
const VS_CENA=`
layout(location=0) in vec3 aP;layout(location=1) in vec3 aN;layout(location=2) in vec3 aC;layout(location=3) in float aS;
layout(location=4) in vec4 iP;layout(location=5) in vec2 iR;
uniform mat4 uVP,uModel;uniform float uTime,uFade;uniform vec3 uEye;out vec3 vP,vN,vC;out float vE,vT;
void main(){float c=cos(iR.x),s=sin(iR.x);mat3 R=mat3(c,0.,-s,0.,1.,0.,s,0.,c);float esc=iP.w;if(uFade>0.)esc*=1.-smoothstep(uFade*.75,uFade,distance(iP.xz,uEye.xz));
 bool terr=aS>1.5;float sw=terr?0.:max(aS,0.);vE=terr?0.:max(-aS,0.);vT=terr?1.:0.;vec3 p=R*aP*esc+iP.xyz;p.x+=sin(uTime*1.7+p.x*.15+p.z*.2)*sw*esc;p.z+=cos(uTime*1.3+p.z*.17)*sw*esc*.6;
 vec4 w=uModel*vec4(p,1.);vP=w.xyz;vN=mat3(uModel)*(R*aN);vC=aC*iR.y;gl_Position=uVP*w;}`;
const LUZ=`precision highp sampler2DShadow;
uniform vec3 uEye,uSun,uSunCol,uAmb,uChao,uFog;uniform vec4 uLuz[12],uTint;uniform float uTime,uDens,uTocha,uNoite,uSombra,uTexel;uniform mat4 uLuzVP;uniform sampler2DShadow uMapa;uniform float uCav;float gCeu=1.;
float hs(vec2 p){p=fract(p*vec2(.1031,.1030));p+=dot(p,p.yx+33.33);return fract((p.x+p.y)*p.x);}
float rs(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hs(i),hs(i+vec2(1,0)),f.x),mix(hs(i+vec2(0,1)),hs(i+1.),f.x),f.y);}
float sombra(vec3 p,vec3 n){if(uSombra<=0.)return 1.;vec4 q=uLuzVP*vec4(p+n*.12,1.);vec3 c=q.xyz*.5+.5;float borda=max(abs(c.x-.5),abs(c.y-.5))*2.;if(borda>=1.||c.z>=1.)return 1.;
 float s=0.;for(int i=-1;i<=1;i++)for(int j=-1;j<=1;j++)s+=texture(uMapa,vec3(c.xy+vec2(i,j)*uTexel,c.z-.0011));return mix(1.,s/9.,uSombra*(1.-smoothstep(.8,1.,borda)));}
vec3 iluminar(vec3 base,vec3 n,vec3 p,float emis,float ao){vec3 V=uEye-p;float d=length(V);V/=d;float dif=max(dot(n,uSun),0.);if(dif>0.)dif*=sombra(p,n);
 vec3 luz=mix(uChao,uAmb,n.y*.5+.5)*ao*gCeu+vec3(.2,.2,.25)*uCav*(1.-gCeu)*(.62+.38*n.y)*ao+uSunCol*dif*(.55+.45*ao)*gCeu;
 for(int i=0;i<12;i++){if(uLuz[i].w<=0.)continue;vec3 f=uLuz[i].xyz-p;float fd=length(f);luz+=vec3(1.,.58,.26)*uLuz[i].w*max(dot(n,f/max(fd,.01))*.6+.4,0.)/(1.+fd*fd*.05)*(.5+.5*ao);}
 luz+=vec3(1.,.74,.46)*uTocha*max(dot(n,V)*.55+.45,0.)/(1.+d*d*.022);
 vec3 cor=base*luz;cor=mix(cor,base*(.75+1.1*uNoite),min(emis,1.));return mix(cor,uTint.rgb,uTint.a);}
vec3 neblina(vec3 c,vec3 p){float d=distance(uEye,p);return mix(c,uFog,1.-exp(-pow(d*uDens,2.)));}`;
const cena=programa(VS_CENA,LUZ+`
in vec3 vP,vN,vC;in float vE,vT;out vec4 o;uniform float uAlfa;uniform sampler2D uMasc;bool cortado(vec3 p){return texelFetch(uMasc,ivec2(floor(p.xz/16.))+256,0).r>.5;}
void main(){if(vT>.5&&cortado(vP))discard;vec3 n=normalize(vN),base=vC;
 if(vT>.5){float d=distance(uEye,vP),k=1.-smoothstep(25.,90.,d);if(k>0.){float a=rs(vP.xz*2.3),b=rs(vP.xz*7.1),g=rs(vP.xz*.55);base*=1.+((a-.5)*.2+(b-.5)*.16)*k+(g-.5)*.14;
   n=normalize(n+vec3(rs(vP.xz*1.7+9.)-.5,0.,rs(vP.xz*1.7+31.)-.5)*.35*k);}}
 o=vec4(neblina(iluminar(base,n,vP,vE,1.),vP),uAlfa);}`);
const voxel=programa(`layout(location=0) in vec3 aP;layout(location=1) in vec3 aN;layout(location=2) in vec2 aU;layout(location=3) in vec4 aT;uniform mat4 uVP;uniform float uTime,uAgua;out vec3 vP,vN,vU;out vec4 vT;
void main(){vec3 p=aP;if(uAgua>0.&&fract(p.y)>.01)p.y+=sin(uTime*2.+p.x*1.3+p.z*.9)*.025;vP=p;vN=aN;vU=vec3(aU,aT.x);vT=aT;gl_Position=uVP*vec4(p,1.);}`,LUZ+`precision highp sampler2DArray;
in vec3 vP,vN,vU;in vec4 vT;out vec4 o;uniform sampler2DArray uAtlas;uniform float uAgua;
void main(){vec3 uv=vU;if(uAgua>0.)uv.xy+=vec2(uTime*.06,uTime*.1);vec4 t=texture(uAtlas,uv);if(t.a<.35&&uAgua<=0.)discard;
 gCeu=vT.w;vec3 c=iluminar(t.rgb,normalize(vN),vP,vT.z,vT.y);o=vec4(neblina(c,vP),uAgua>0.?.7:1.);}`);
const sombraCena=programa(VS_CENA,`precision highp float;in vec3 vP;in float vT;out vec4 o;uniform sampler2D uMasc;bool cortado(vec3 p){return texelFetch(uMasc,ivec2(floor(p.xz/16.))+256,0).r>.5;}void main(){if(vT>.5&&cortado(vP))discard;o=vec4(1.);}`);
const terra=programa(`layout(location=0) in vec3 aP;layout(location=1) in vec3 aN;layout(location=2) in vec3 aC;layout(location=3) in vec2 aL;uniform mat4 uVP;out vec3 vP,vN,vC;out vec2 vL;void main(){vP=aP;vN=aN;vC=aC;vL=aL;gl_Position=uVP*vec4(aP,1.);}`,LUZ+`precision highp sampler2DArray;
in vec3 vP,vN,vC;in vec2 vL;out vec4 o;uniform sampler2DArray uAtlas;
void main(){vec3 n=normalize(vN),base=vC;gCeu=vL.y;
 if(vL.x>-.5){vec3 w=pow(abs(n),vec3(4.));w/=w.x+w.y+w.z;float L=floor(vL.x+.5);vec3 q=vP*.5;
  vec3 t=texture(uAtlas,vec3(q.zy,L)).rgb*w.x+texture(uAtlas,vec3(q.xz,L)).rgb*w.y+texture(uAtlas,vec3(q.xy,L)).rgb*w.z;base=t*vC*(.8+.4*rs(vP.xz*.23+vP.y*.31));}
 else{float a=rs(vP.xz*2.3),b=rs(vP.xz*7.1),g=rs(vP.xz*.55);base*=1.+(a-.5)*.2+(b-.5)*.16+(g-.5)*.14;}
 float ao=.78+.22*clamp(n.y+.6,0.,1.);o=vec4(neblina(iluminar(base,n,vP,0.,ao),vP),1.);}`);
const sombraVox=programa(`layout(location=0) in vec3 aP;layout(location=2) in vec2 aU;layout(location=3) in vec3 aT;uniform mat4 uVP;out vec3 vU;void main(){vU=vec3(aU,aT.x);gl_Position=uVP*vec4(aP,1.);}`,
 `precision highp sampler2DArray;in vec3 vU;out vec4 o;uniform sampler2DArray uAtlas;void main(){if(texture(uAtlas,vU).a<.35)discard;o=vec4(1.);}`);
const mar=programa(`layout(location=0) in vec3 aP;layout(location=3) in float aS;uniform mat4 uVP;uniform float uTime;out vec3 vP;out float vF;
void main(){vec3 p=aP;p.y=sin(p.x*.35+uTime*1.4)*.08+cos(p.z*.27+uTime*1.1)*.07;vP=p;vF=aS;gl_Position=uVP*vec4(p,1.);}`,LUZ+`
in vec3 vP;in float vF;out vec4 o;uniform vec3 uTopo;
void main(){if(vF<-.18)discard;vec2 p=vP.xz;float t=uTime;
 vec2 g=vec2(.028*cos(p.x*.35+t*1.4),-.019*sin(p.y*.27+t*1.1));float k=1.-smoothstep(40.,150.,distance(uEye,vP));
 g+=(vec2(rs(p*.9+vec2(t*.5,t*.2)),rs(p*.9-vec2(t*.3,t*.55)+7.))-.5)*.22*k+(vec2(rs(p*2.7-vec2(t*.9,0.)),rs(p*2.7+vec2(0.,t*.8)+3.))-.5)*.14*k;
 vec3 n=normalize(vec3(-g.x,1.,-g.y)),V=normalize(uEye-vP);bool baixo=uEye.y<vP.y;if(baixo)n=-n;
 float fundo=max(vF,0.),s=sombra(vP,vec3(0.,1.,0.));vec3 base=mix(vec3(.16,.55,.55),vec3(.03,.17,.33),smoothstep(0.,4.5,fundo));
 vec3 cor=base*(uAmb+uSunCol*.55*s);float fr=.04+.96*pow(1.-max(dot(n,V),0.),4.);vec3 refl=reflect(-V,n);vec3 ceuC=mix(uFog,uTopo,pow(max(refl.y,0.),.55));cor=mix(cor,ceuC,baixo?.15:fr*.85);
 cor+=uSunCol*s*pow(max(dot(reflect(-uSun,n),V),0.),160.)*3.;
 for(int i=0;i<12;i++){if(uLuz[i].w<=0.)continue;vec3 f=uLuz[i].xyz-vP;float fd=length(f);cor+=vec3(1.,.55,.22)*uLuz[i].w*pow(max(dot(reflect(-f/fd,n),V),0.),30.)/(1.+fd*fd*.02);}
 float esp=smoothstep(.42,.02,fundo+(rs(p*1.8+t*.35)-.5)*.35+sin(t*1.5+fundo*14.)*.07);cor=mix(cor,(uAmb+uSunCol)*.85,esp*.75);
 float a=clamp(mix(.42,.9,smoothstep(0.,3.5,fundo))+fr*.4+esp*.4,0.,.97)*smoothstep(-.18,.02,vF);if(baixo)a=.55;
 o=vec4(neblina(mix(cor,uTint.rgb,uTint.a),vP),a);}`);
const ceu=programa(`out vec2 v;void main(){vec2 p=vec2((gl_VertexID<<1)&2,gl_VertexID&2)*2.-1.;v=p;gl_Position=vec4(p,0.,1.);}`,`
in vec2 v;out vec4 o;uniform vec3 uF,uR,uU,uSun,uTopo,uFog,uGlow;uniform float uNoite,uTime,uNuvens,uRaio;
float h(vec2 p){p=fract(p*vec2(.1031,.1030));p+=dot(p,p.yx+33.33);return fract((p.x+p.y)*p.x);}
float r(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(h(i),h(i+vec2(1,0)),f.x),mix(h(i+vec2(0,1)),h(i+1.),f.x),f.y);}
float fb(vec2 p){float s=0.,a=.5;for(int i=0;i<5;i++){s+=r(p)*a;p=p*2.03+vec2(11.7,5.3);a*=.5;}return s;}
void main(){vec3 d=normalize(uF+uR*v.x+uU*v.y);float alto=max(d.y,0.);vec3 c=mix(uFog,uTopo,pow(alto,.48));
 float s=max(dot(d,uSun),0.),limpo=1.-uNuvens*.85;c+=uGlow*(pow(s,6.)*.28+pow(s,48.)*.35+pow(s,600.)*.5)*limpo;c+=vec3(2.2,1.9,1.4)*smoothstep(.99935,.99965,s)*limpo*(1.-uNoite);
 float lua=dot(d,-uSun),disco=smoothstep(.99938,.99958,lua);c+=vec3(1.,1.05,1.2)*(disco*(.8+.35*r(d.xz*260.))+pow(max(lua,0.),180.)*.2)*uNoite*limpo;
 vec3 q=floor(d*210.);float e=h(q.xy+q.z*37.7);c+=step(.9962,e)*uNoite*smoothstep(.02,.25,d.y)*(.55+.45*sin(uTime*2.+e*900.))*limpo*(1.+step(.9992,e));
 float faixa=exp(-pow(dot(d,normalize(vec3(.5,.35,-.8)))*4.5,2.));c+=vec3(.12,.1,.2)*faixa*fb(d.xz*9.+d.y*5.)*uNoite*limpo;
 if(d.y>.015){vec2 p=d.xz/(d.y+.16)*1.25+vec2(uTime*.009,uTime*.003);float n=fb(p),cob=smoothstep(.56-uNuvens*.34,.86-uNuvens*.3,n),vol=fb(p+uSun.xz*.14);
  vec3 claro=mix(vec3(1.02,1.,.98),uFog*1.5,uNoite*.85)+uGlow*.3*pow(s,3.),escuro=mix(uFog,claro,.45)*(1.-uNuvens*.4);vec3 cn=mix(claro,escuro,smoothstep(-.05,.25,vol-n+.08+uNuvens*.12));
  c=mix(c,cn,cob*smoothstep(.015,.22,d.y)*(.86+uNuvens*.14));}
 c+=vec3(.75,.8,1.)*uRaio;o=vec4(c,1.);}`);
const pontos=programa(`layout(location=0) in vec4 aP;layout(location=1) in vec4 aC;uniform mat4 uVP;uniform float uAlt;out vec4 vC;
void main(){gl_Position=uVP*vec4(aP.xyz,1.);gl_PointSize=clamp(aP.w*uAlt/max(gl_Position.w,.1),1.,220.);vC=aC;}`,`
in vec4 vC;out vec4 o;void main(){float a=max(1.-length(gl_PointCoord-.5)*2.,0.);o=vec4(vC.rgb*vC.a*(a*a+smoothstep(.35,.7,a)*.6),1.);}`);
const linhas=programa(`layout(location=0) in vec3 aP;uniform mat4 uVP;void main(){gl_Position=uVP*vec4(aP,1.);}`,`uniform vec4 uCor;out vec4 o;void main(){o=uCor;}`);
const VS_TELA=`out vec2 v;void main(){vec2 p=vec2((gl_VertexID<<1)&2,gl_VertexID&2);v=p;gl_Position=vec4(p*2.-1.,0.,1.);}`;
const pBrilho=programa(VS_TELA,`in vec2 v;out vec4 o;uniform sampler2D uT;uniform vec2 uD;uniform float uModo;
void main(){if(uModo<.5){vec3 c=vec3(0.);for(int i=0;i<4;i++)c+=texture(uT,v+uD*(vec2(i&1,i>>1)-.5)*2.).rgb;c*=.25;float l=max(c.r,max(c.g,c.b));o=vec4(c*max(l-.82,0.)/max(l,.001)*1.6,1.);return;}
 vec3 c=texture(uT,v).rgb*.227;float w[4]=float[](.194,.122,.054,.016);for(int i=1;i<5;i++)c+=(texture(uT,v+uD*float(i)).rgb+texture(uT,v-uD*float(i)).rgb)*w[i-1];o=vec4(c,1.);}`);
const pFinal=programa(VS_TELA,`in vec2 v;out vec4 o;uniform sampler2D uT,uB,uC;uniform float uSub,uTime,uBloom,uSat,uCont,uVin;
void main(){vec2 p=v;if(uSub>0.)p+=vec2(sin(v.y*18.+uTime*2.3),cos(v.x*15.+uTime*1.9))*.0035;
 vec3 c=texture(uT,p).rgb+(texture(uB,p).rgb*.75+texture(uC,p).rgb*.7)*uBloom;
 c=mix(c,.8+.2*(1.-exp(-(c-.8)/.24)),step(.8,c));float l=dot(c,vec3(.299,.587,.114));c=max(mix(vec3(l),c,1.12*uSat),0.);c=mix(c,c*c*(3.-2.*c),.14);c=max((c-.5)*uCont+.5,0.);
 vec2 q=v-.5;c*=1.-dot(q,q)*.42*uVin;if(uSub>0.){c=mix(c,c*vec3(.5,.82,1.)+vec3(0.,.04,.1),uSub);c*=1.-dot(q,q)*.7*uSub;}
 c+=(fract(sin(dot(v,vec2(12.9898,78.233)))*43758.5453)-.5)/255.;o=vec4(c,1.);}`);

// ---------- alvos de renderização ----------
const vazioVao=gl.createVertexArray();
let alvos=null,mapaSombra=null;
function textura(w,h,interno,formato,tipo,filtro){const t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,t);gl.texImage2D(gl.TEXTURE_2D,0,interno,w,h,0,formato,tipo,null);
 gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,filtro);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,filtro);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);return t}
function alvoCor(w,h){const t=extFloat?textura(w,h,gl.RGBA16F,gl.RGBA,gl.HALF_FLOAT,gl.LINEAR):textura(w,h,gl.RGBA8,gl.RGBA,gl.UNSIGNED_BYTE,gl.LINEAR),f=gl.createFramebuffer();gl.bindFramebuffer(gl.FRAMEBUFFER,f);gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,t,0);return{t,f,w,h}}
function criarAlvos(w,h){if(alvos&&alvos.w===w&&alvos.h===h)return alvos;if(alvos){for(const a of alvos.lista){gl.deleteTexture(a.t);gl.deleteFramebuffer(a.f)}gl.deleteRenderbuffer(alvos.rc);gl.deleteRenderbuffer(alvos.rd);gl.deleteFramebuffer(alvos.ms)}
 const am=Math.min(4,gl.getParameter(gl.MAX_SAMPLES)),ms=gl.createFramebuffer(),rc=gl.createRenderbuffer(),rd=gl.createRenderbuffer();gl.bindRenderbuffer(gl.RENDERBUFFER,rc);gl.renderbufferStorageMultisample(gl.RENDERBUFFER,am,extFloat?gl.RGBA16F:gl.RGBA8,w,h);
 gl.bindRenderbuffer(gl.RENDERBUFFER,rd);gl.renderbufferStorageMultisample(gl.RENDERBUFFER,am,gl.DEPTH_COMPONENT24,w,h);gl.bindFramebuffer(gl.FRAMEBUFFER,ms);gl.framebufferRenderbuffer(gl.FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.RENDERBUFFER,rc);gl.framebufferRenderbuffer(gl.FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.RENDERBUFFER,rd);
 const ok=gl.checkFramebufferStatus(gl.FRAMEBUFFER)===gl.FRAMEBUFFER_COMPLETE,w4=Math.max(1,w>>2),h4=Math.max(1,h>>2),w8=Math.max(1,w>>3),h8=Math.max(1,h>>3);
 const lista=[alvoCor(w,h),alvoCor(w4,h4),alvoCor(w4,h4),alvoCor(w8,h8),alvoCor(w8,h8)];gl.bindFramebuffer(gl.FRAMEBUFFER,null);return alvos={w,h,ok,ms,rc,rd,lista}}
function criarSombra(tam){if(mapaSombra&&mapaSombra.tam===tam)return mapaSombra;if(mapaSombra){gl.deleteTexture(mapaSombra.t);gl.deleteFramebuffer(mapaSombra.f)}
 gl.activeTexture(gl.TEXTURE1);const t=textura(tam,tam,gl.DEPTH_COMPONENT24,gl.DEPTH_COMPONENT,gl.UNSIGNED_INT,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_COMPARE_MODE,gl.COMPARE_REF_TO_TEXTURE);
 const f=gl.createFramebuffer();gl.bindFramebuffer(gl.FRAMEBUFFER,f);gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.TEXTURE_2D,t,0);gl.drawBuffers([gl.NONE]);gl.readBuffer(gl.NONE);gl.bindFramebuffer(gl.FRAMEBUFFER,null);gl.activeTexture(gl.TEXTURE0);return mapaSombra={t,f,tam}}
function posProcesso(w,h,sub){const a=alvos,[res,b1,b2,c1,c2]=a.lista;
 gl.bindFramebuffer(gl.READ_FRAMEBUFFER,a.ms);gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,res.f);gl.blitFramebuffer(0,0,w,h,0,0,w,h,gl.COLOR_BUFFER_BIT,gl.NEAREST);
 gl.disable(gl.DEPTH_TEST);gl.disable(gl.BLEND);gl.bindVertexArray(vazioVao);gl.useProgram(pBrilho.p);const u=pBrilho.u;gl.uniform1i(u.uT,0);gl.activeTexture(gl.TEXTURE0);
 const passo=(de,para,dx,dy,modo)=>{gl.bindFramebuffer(gl.FRAMEBUFFER,para.f);gl.viewport(0,0,para.w,para.h);gl.bindTexture(gl.TEXTURE_2D,de.t);gl.uniform2f(u.uD,dx,dy);gl.uniform1f(u.uModo,modo);gl.drawArrays(gl.TRIANGLES,0,3)};
 passo(res,b1,1/w,1/h,0);passo(b1,b2,1.3/b1.w,0,1);passo(b2,b1,0,1.3/b1.h,1);passo(b1,c1,1.5/c1.w,0,1);passo(c1,c2,0,1.5/c1.h,1);
 gl.bindFramebuffer(gl.FRAMEBUFFER,null);gl.viewport(0,0,w,h);gl.useProgram(pFinal.p);const f=pFinal.u;
 [res,b1,c2].forEach((x,i)=>{gl.activeTexture(gl.TEXTURE0+2+i);gl.bindTexture(gl.TEXTURE_2D,x.t)});gl.uniform1i(f.uT,2);gl.uniform1i(f.uB,3);gl.uniform1i(f.uC,4);gl.uniform1f(f.uSub,sub);gl.uniform1f(f.uTime,tempo);gl.uniform1f(f.uBloom,.8*CFG.bloom);gl.uniform1f(f.uSat,CFG.sat);gl.uniform1f(f.uCont,CFG.contraste);gl.uniform1f(f.uVin,CFG.vinheta?1:0);gl.drawArrays(gl.TRIANGLES,0,3);
 for(let i=2;i<5;i++){gl.activeTexture(gl.TEXTURE0+i);gl.bindTexture(gl.TEXTURE_2D,null)}gl.activeTexture(gl.TEXTURE0)}

// máscara dos trechos escavados (o relevo antigo some ali)
const texMasc=gl.createTexture();gl.activeTexture(gl.TEXTURE5);gl.bindTexture(gl.TEXTURE_2D,texMasc);gl.texImage2D(gl.TEXTURE_2D,0,gl.R8,512,512,0,gl.RED,gl.UNSIGNED_BYTE,null);
for(const p of[gl.TEXTURE_MIN_FILTER,gl.TEXTURE_MAG_FILTER])gl.texParameteri(gl.TEXTURE_2D,p,gl.NEAREST);gl.activeTexture(gl.TEXTURE0);
function atualizarMascara(){gl.activeTexture(gl.TEXTURE5);gl.bindTexture(gl.TEXTURE_2D,texMasc);if(M.mascaraSuja&&M.cortes){M.mascaraSuja=false;const d=new Uint8Array(262144);for(const[a,b]of M.cortes.values())if(a>=-256&&a<256&&b>=-256&&b<256)d[(b+256)*512+a+256]=255;gl.pixelStorei(gl.UNPACK_ALIGNMENT,1);gl.texSubImage2D(gl.TEXTURE_2D,0,0,0,512,512,gl.RED,gl.UNSIGNED_BYTE,d)}gl.activeTexture(gl.TEXTURE0)}

// ---------- partículas e linhas ----------
const MAXP=4000,pVao=gl.createVertexArray(),pBuf=gl.createBuffer(),pDados=new Float32Array(8*MAXP);
gl.bindVertexArray(pVao);gl.bindBuffer(gl.ARRAY_BUFFER,pBuf);gl.bufferData(gl.ARRAY_BUFFER,pDados.byteLength,gl.DYNAMIC_DRAW);
for(const[i,o]of[[0,0],[1,16]]){gl.enableVertexAttribArray(i);gl.vertexAttribPointer(i,4,gl.FLOAT,false,32,o)}gl.bindVertexArray(null);
let np=0;const ponto=(x,y,z,s,r,g,b,a)=>{if(np<MAXP)pDados.set([x,y,z,s,r,g,b,a],np++*8)};
const lVao=gl.createVertexArray(),lBuf=gl.createBuffer();gl.bindVertexArray(lVao);gl.bindBuffer(gl.ARRAY_BUFFER,lBuf);gl.enableVertexAttribArray(0);gl.vertexAttribPointer(0,3,gl.FLOAT,false,12,0);gl.bindVertexArray(null);
function desenharLinhas(VP,v,cor){if(!v.length)return;gl.useProgram(linhas.p);gl.uniformMatrix4fv(linhas.u.uVP,false,VP);gl.uniform4fv(linhas.u.uCor,cor);gl.bindVertexArray(lVao);gl.bindBuffer(gl.ARRAY_BUFFER,lBuf);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(v),gl.STREAM_DRAW);gl.drawArrays(gl.LINES,0,v.length/3)}
function cubo(x,y,z,l=1,f=.004){const v=[],a=[x-f,y-f,z-f],d=l+2*f,p=i=>[a[0]+(i&1?d:0),a[1]+(i&2?d:0),a[2]+(i&4?d:0)];for(const[i,j]of[[0,1],[2,3],[4,5],[6,7],[0,2],[1,3],[4,6],[5,7],[0,4],[1,5],[2,6],[3,7]])v.push(...p(i),...p(j));return v}
