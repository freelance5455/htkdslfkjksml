// ---------- formas de bloco ----------
// cada forma é um conjunto de caixas [x0,y0,z0,x1,y1,z1] dentro do cubo, virado para o norte
const FORMAS=[
 {id:'cubo',n:'Cubo',caixas:[[0,0,0,1,1,1]]},{id:'laje',n:'Meia laje',caixas:[[0,0,0,1,.5,1]]},{id:'laje_alta',n:'Laje alta',caixas:[[0,.5,0,1,1,1]]},
 {id:'escada',n:'Escada',caixas:[[0,0,0,1,.5,1],[0,.5,0,1,1,.5]]},{id:'telhado',n:'Telhado inclinado',rampa:true,caixas:[[0,0,0,1,.5,1],[0,.5,0,1,1,.5]]},
 {id:'pilar',n:'Pilar',caixas:[[.25,0,.25,.75,1,.75]]},{id:'parede',n:'Parede fina',caixas:[[0,0,.37,1,1,.63]]},{id:'viga',n:'Viga',caixas:[[.3,.6,0,.7,1,1]]},
 {id:'poste',n:'Poste',caixas:[[.38,0,.38,.62,1,.62]]},{id:'tapete',n:'Piso fino',caixas:[[0,0,0,1,.07,1]]},{id:'janela',n:'Janela',caixas:[[0,0,.43,1,1,.57]]},
 {id:'porta',n:'Porta',caixas:[[0,0,.82,1,1,1]]},{id:'porta_aberta',n:'Porta aberta',caixas:[[0,0,0,.18,1,1]],oculta:true}];
const FM={};FORMAS.forEach((f,i)=>FM[f.id]=i);
const GIRADAS=FORMAS.map(f=>[0,1,2,3].map(r=>{const a=r*Math.PI/2,c=Math.round(Math.cos(a)),s=Math.round(Math.sin(a));return f.caixas.map(([x0,y0,z0,x1,y1,z1])=>{const p=(x,z)=>[.5+c*(x-.5)+s*(z-.5),.5-s*(x-.5)+c*(z-.5)],a=p(x0,z0),b=p(x1,z1);return[Math.min(a[0],b[0]),y0,Math.min(a[1],b[1]),Math.max(a[0],b[0]),y1,Math.max(a[1],b[1])]})}));

// ---------- armazenamento: valor = bloco + forma*1024 + giro*16384 ----------
const FUNDO=-64;
const VK=(x,y,z)=>(x+4096)*8388608+(z+4096)*1024+(y+512);
const deVK=k=>[Math.floor(k/8388608)-4096,k%1024-512,Math.floor(k/1024)%8192-4096];
let CAV=null;
const bruto=(x,y,z)=>{const k=VK(x,y,z);let e=M.edits.get(k);if(e===undefined)e=M.estrut.get(k);return e||0};
const bloco=(x,y,z)=>bruto(x,y,z)&1023;
const caixasDe=v=>GIRADAS[(v>>10)&15][(v>>14)&3];
const solidoVox=(x,y,z)=>{const n=bloco(x,y,z);return n!==0&&BLOCOS[n].solido};
const ehAgua=n=>n!==0&&BLOCOS[n].agua>0;
const chaveV=(cx,cz)=>cx+','+cz;
function vchunk(cx,cz){const k=chaveV(cx,cz);let v=M.vch.get(k);if(!v){v={cx,cz,set:new Set(),base:new Set(),malha:null,agua:null,sujo:true,luzes:[]};M.vch.set(k,v)}return v}
function marcar(x,z){vchunk(x>>4,z>>4).sujo=true;const lx=x&15,lz=z&15;
 for(const[a,b]of[[lx===0?-1:lx===15?1:0,0],[0,lz===0?-1:lz===15?1:0]])if(a||b){const v=M.vch.get(chaveV((x>>4)+a,(z>>4)+b));if(v)v.sujo=true}}
function registrar(x,y,z,v){const k=VK(x,y,z);M.edits.set(k,v);const c=vchunk(x>>4,z>>4);if(v)c.set.add(k);else c.set.delete(k)}
function definirBloco(x,y,z,n,forma=0,giro=0){registrar(x,y,z,n?n|forma<<10|giro<<14:0);marcar(x,z);for(const[a,b,c]of[[0,0,0],[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]])filaAgua.add(VK(x+a,y+b,z+c))}
// blocos gerados com o mundo (casas, lagos e lava das cavernas); não são salvos
function porEstrutura(tag,x,y,z,n,forma=0,giro=0){const k=VK(x,y,z);M.estrut.set(k,n|forma<<10|giro<<14);let l=M.tags.get(tag);if(!l)M.tags.set(tag,l=[]);l.push(k);vchunk(x>>4,z>>4).base.add(k);marcar(x,z)}
function tirarEstrutura(tag){for(const k of M.tags.get(tag)||[]){M.estrut.delete(k);const[x,,z]=deVK(k),v=M.vch.get(chaveV(x>>4,z>>4));if(v){v.base.delete(k);v.sujo=true}}M.tags.delete(tag)}

// ---------- malhas ----------
const FACES=[[[1,0,0],[[1,0,1],[1,0,0],[1,1,0],[1,1,1]]],[[-1,0,0],[[0,0,0],[0,0,1],[0,1,1],[0,1,0]]],[[0,1,0],[[0,1,1],[1,1,1],[1,1,0],[0,1,0]]],[[0,-1,0],[[0,0,0],[1,0,0],[1,0,1],[0,0,1]]],[[0,0,1],[[0,0,1],[1,0,1],[1,1,1],[0,1,1]]],[[0,0,-1],[[1,0,0],[0,0,0],[0,1,0],[1,1,0]]]];
const UVS=[[0,1],[1,1],[1,0],[0,0]];
function malhaVox(d){const vao=gl.createVertexArray();gl.bindVertexArray(vao);const buf=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buf);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(d),gl.STATIC_DRAW);
 [[0,3,0],[1,3,12],[2,2,24],[3,4,32]].forEach(([i,n,o])=>{gl.enableVertexAttribArray(i);gl.vertexAttribPointer(i,n,gl.FLOAT,false,48,o)});gl.bindVertexArray(null);return{vao,buf,n:d.length/12}}
const cheio=v=>{const n=v&1023;return n!==0&&BLOCOS[n].opaco&&BLOCOS[n].solido&&!(v>>10&15)};
const opacoEm=(x,y,z)=>cheio(bruto(x,y,z))?1:0;
const ceuDe=(x,y,z)=>{const p=altura(x,z)-y;return p<2.5?1:clamp(1-(p-2.5)/6,0,1)};
// um canto é arredondado quando não há bloco nenhum encostado daquele lado
function livreLado(w,a,s){const R=i=>Math.abs(w[i]-Math.round(w[i]))<1e-6?[Math.round(w[i])-1,Math.round(w[i])]:[Math.floor(w[i])],E=[R(0),R(1),R(2)];E[a]=[Math.round(w[a])+(s>0?0:-1)];
 for(const x of E[0])for(const y of E[1])for(const z of E[2])if(opacoEm(x,y,z))return false;return true}
const BV=.11,GRADE=[0,BV,1-BV,1];
function faces(x,y,z,v,solido,agua){const n=v&1023,b=BLOCOS[n],forma=v>>10&15;if(forma){formaMalha(x,y,z,v,solido);return}
 for(let f=0;f<6;f++){const[nm,cs]=FACES[f],X=x+nm[0],Y=y+nm[1],Z=z+nm[2],vv=bruto(X,Y,Z),viz=vv&1023,o=BLOCOS[viz];
  if(b.agua){if(viz!==0&&(o.agua||cheio(vv)))continue}else if(cheio(vv)&&!o.lava)continue;else if(!b.opaco&&viz===n&&!(vv>>10&15))continue;
  const alto=b.agua?(ehAgua(bloco(x,y+1,z))?1:.9-(b.agua-1)*.17):1,cam=camada[n][f===2?0:f===3?2:1],luz=[],ceu=b.luz>.5?1:ceuDe(X+.5,Y,Z+.5);
  for(let q=0;q<4;q++){const c=cs[q];if(b.agua||b.luz>.5){luz.push(1);continue}const ax=[0,1,2].filter(i=>nm[i]===0),p=[X,Y,Z],a=p.slice(),d=p.slice();a[ax[0]]+=c[ax[0]]*2-1;d[ax[1]]+=c[ax[1]]*2-1;const e=a.slice();e[ax[1]]+=c[ax[1]]*2-1;
   const s1=opacoEm(...a),s2=opacoEm(...d);luz.push(.5+.5/3*(s1&&s2?0:3-s1-s2-opacoEm(...e)))}
  const saida=b.agua?agua:solido;
  let redondo=false;if(CFG.arred&&b.opaco&&b.solido&&b.luz<.9)for(let i=0;i<3&&!redondo;i++)if(!nm[i])for(const s of[-1,1]){const p=[x,y,z];p[i]+=s;if(!opacoEm(...p)){redondo=true;break}}
  if(!redondo){const ordem=luz[0]+luz[2]<luz[1]+luz[3]?[1,2,3,1,3,0]:[0,1,2,0,2,3];
   for(const q of ordem){const c=cs[q];saida.push(x+c[0],y+c[1]*alto,z+c[2],nm[0],nm[1],nm[2],UVS[q][0],UVS[q][1],cam,luz[q],b.luz,ceu)}continue}
  const c0=cs[0],e1=[0,1,2].map(i=>cs[1][i]-c0[i]),e2=[0,1,2].map(i=>cs[3][i]-c0[i]),G=[];
  for(const t of GRADE)for(const s of GRADE){const p=[0,1,2].map(i=>c0[i]+e1[i]*s+e2[i]*t),w=[x+p[0],y+p[1],z+p[2]],q=p.slice();
   for(let a=0;a<3;a++){if(p[a]<1e-6&&livreLado(w,a,-1))q[a]=BV;else if(p[a]>1-1e-6&&livreLado(w,a,1))q[a]=1-BV}
   const d=[p[0]-q[0],p[1]-q[1],p[2]-q[2]],l=Math.hypot(...d),nn=l>1e-5?d.map(v=>v/l):nm,pos=l>1e-5?[q[0]+nn[0]*BV,q[1]+nn[1]*BV,q[2]+nn[2]*BV]:p;
   G.push([x+pos[0],y+pos[1],z+pos[2],nn[0],nn[1],nn[2],s,1-t,cam,lerp(lerp(luz[0],luz[1],s),lerp(luz[3],luz[2],s),t),b.luz,ceu])}
  for(let j=0;j<3;j++)for(let i=0;i<3;i++){const a=j*4+i;for(const q of[a,a+1,a+5,a,a+5,a+4])saida.push(...G[q])}}}
// lajes, escadas, telhados, pilares e demais formas
function formaMalha(x,y,z,v,saida){const n=v&1023,b=BLOCOS[n],fo=FORMAS[v>>10&15],giro=v>>14&3,ceu=ceuDe(x+.5,y,z+.5);
 const vert=(p,nm,u,w,cam)=>saida.push(x+p[0],y+p[1],z+p[2],nm[0],nm[1],nm[2],u,w,cam,.92,b.luz,ceu);
 const uvDe=(p,nm)=>Math.abs(nm[1])>.9?[p[0],p[2]]:Math.abs(nm[0])>Math.abs(nm[2])?[1-p[2],1-p[1]]:[p[0],1-p[1]];
 const poli=(pts,nm,cam)=>{for(const i of pts.length===4?[0,1,2,0,2,3]:[0,1,2]){const p=pts[i],[u,w]=uvDe(p,nm);vert(p,nm,u,w,cam)}};
 if(fo.rampa){const a=giro*Math.PI/2,c=Math.round(Math.cos(a)),s=Math.round(Math.sin(a)),R=(px,py,pz)=>[.5+c*(px-.5)+s*(pz-.5),py,.5-s*(px-.5)+c*(pz-.5)],N=(nx,ny,nz)=>[c*nx+s*nz,ny,-s*nx+c*nz],k=Math.SQRT1_2;
  poli([R(0,0,1),R(1,0,1),R(1,1,0),R(0,1,0)],N(0,k,k),camada[n][1]);poli([R(1,0,0),R(0,0,0),R(0,1,0),R(1,1,0)],N(0,0,-1),camada[n][1]);poli([R(0,0,0),R(1,0,0),R(1,0,1),R(0,0,1)],[0,-1,0],camada[n][2]);
  poli([R(1,0,1),R(1,0,0),R(1,1,0)],N(1,0,0),camada[n][1]);poli([R(0,0,0),R(0,0,1),R(0,1,0)],N(-1,0,0),camada[n][1]);return}
 for(const k of caixasDe(v))for(let f=0;f<6;f++){const[nm,cs]=FACES[f],eixo=nm[0]?0:nm[1]?1:2,borda=nm[eixo]>0?k[eixo+3]===1:k[eixo]===0;if(borda&&cheio(bruto(x+nm[0],y+nm[1],z+nm[2])))continue;
  poli(cs.map(c=>[c[0]?k[3]:k[0],c[1]?k[4]:k[1],c[2]?k[5]:k[2]]),nm,camada[n][f===2?0:f===3?2:1])}}
function refazer(v){if(v.malha)apagarMalha(v.malha);if(v.agua)apagarMalha(v.agua);const s=[],a=[];v.luzes=[];let cont=0;
 const um=(k,val)=>{if(!val)return;const[x,y,z]=deVK(k),antes=s.length,b=BLOCOS[val&1023];if(!b)return;faces(x,y,z,val,s,a);if(b.luz>.5&&s.length>antes){const forte=b.luz>.85&&!b.lava;if(forte||cont++%7===0)v.luzes.push({x:x+.5,y:y+.8,z:z+.5,i:forte?1.6:.8})}};
 for(const k of v.set)um(k,M.edits.get(k));for(const k of v.base)if(!M.edits.has(k))um(k,M.estrut.get(k));
 v.malha=s.length?malhaVox(s):null;v.agua=a.length?malhaVox(a):null;v.sujo=false}
function atualizarVoxels(limite){const lista=[];for(const v of M.vch.values())if(v.sujo)lista.push(v);lista.sort((a,b)=>dist2(a.cx*16+8,a.cz*16+8,P.x,P.z)-dist2(b.cx*16+8,b.cz*16+8,P.x,P.z));for(const v of lista.slice(0,limite))refazer(v)}

// ---------- colisão e raios ----------
function colideVox(x,y,z,r,h){for(let a=Math.floor(x-r);a<=Math.floor(x+r);a++)for(let b=Math.floor(y+.001);b<=Math.floor(y+h-.001);b++)for(let c=Math.floor(z-r);c<=Math.floor(z+r);c++){const v=bruto(a,b,c),n=v&1023;if(!n||!BLOCOS[n].solido)continue;if(!(v>>10&15))return true;
 for(const k of caixasDe(v))if(x+r>a+k[0]&&x-r<a+k[3]&&y+h-.001>b+k[1]&&y+.001<b+k[4]&&z+r>c+k[2]&&z-r<c+k[5])return true}return false}
// topo mais alto sob a pegada, até a altura yMax
function chaoVox(x,z,yMax,r=.28,fundo=14){let m=-Infinity;for(let a=Math.floor(x-r);a<=Math.floor(x+r);a++)for(let c=Math.floor(z-r);c<=Math.floor(z+r);c++)for(let b=Math.floor(yMax);b>yMax-fundo-1;b--){const v=bruto(a,b,c),n=v&1023;if(!n||!BLOCOS[n].solido)continue;let achou=false;
 for(const k of caixasDe(v))if(x+r>a+k[0]&&x-r<a+k[3]&&z+r>c+k[2]&&z-r<c+k[5]){const t=b+k[4];if(t<=yMax+.001){m=Math.max(m,t);achou=true}}if(achou)break}return m}
function raioVox(o,d,max,comAgua){let x=Math.floor(o[0]),y=Math.floor(o[1]),z=Math.floor(o[2]);const p=[x,y,z],passo=d.map(v=>v>0?1:-1),delta=d.map(v=>v?Math.abs(1/v):1e9),prox=d.map((v,i)=>v?((v>0?p[i]+1-o[i]:o[i]-p[i]))*delta[i]:1e9);let t=0,n=[0,0,0];
 while(t<=max){const v=bruto(x,y,z),b=v&1023;if(b&&(BLOCOS[b].solido||BLOCOS[b].lava||(comAgua&&ehAgua(b))))return{x,y,z,nx:n[0],ny:n[1],nz:n[2],t,n:b,v};
  const i=prox[0]<prox[1]?(prox[0]<prox[2]?0:2):(prox[1]<prox[2]?1:2);t=prox[i];prox[i]+=delta[i];n=[0,0,0];n[i]=-passo[i];if(i===0)x+=passo[0];else if(i===1)y+=passo[1];else z+=passo[2]}return null}

// ---------- água que escorre ----------
const filaAgua=new Set();let proxAgua=0;
const vazio=(x,y,z)=>y>FUNDO&&bloco(x,y,z)===0&&!solidoT(x+.5,y+.5,z+.5)&&!(y+.5<0&&altura(x+.5,z+.5)<0);
function fluirAgua(dt){if((proxAgua-=dt)>0)return;proxAgua=.22;const lote=[...filaAgua].slice(0,160);for(const k of lote)filaAgua.delete(k);const A=NB_.agua0;
 for(const k of lote){const[x,y,z]=deVK(k),n=bloco(x,y,z);if(!ehAgua(n))continue;const nivel=n-A,lados=[[1,0],[-1,0],[0,1],[0,-1]];
  for(const[a,b,c]of[[1,0,0],[-1,0,0],[0,-1,0],[0,0,1],[0,0,-1]]){const v=bloco(x+a,y+b,z+c);if(v&&BLOCOS[v].lava)definirBloco(x+a,y+b,z+c,NB_.obsidiana)}
  if(nivel>0&&!ehAgua(bloco(x,y+1,z))&&!lados.some(([a,c])=>{const v=bloco(x+a,y,z+c);return ehAgua(v)&&v-A<nivel})){definirBloco(x,y,z,0);continue}
  if(vazio(x,y-1,z))definirBloco(x,y-1,z,A+1);
  else if(!ehAgua(bloco(x,y-1,z))&&nivel<4)for(const[a,c]of lados)if(vazio(x+a,y,z+c))definirBloco(x+a,y,z+c,A+nivel+1)}}

