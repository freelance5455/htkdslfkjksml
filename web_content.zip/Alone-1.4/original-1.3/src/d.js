// ---------- modelos do cenário ----------
const modelos={},GEO={};
const COR={casca:[.29,.19,.11],madeira:[.55,.36,.18],tabua:[.66,.46,.25],pedra:[.46,.48,.46],ferro:[.7,.73,.76],pano:[.76,.36,.14],fogo:[1,.62,.16]};
function criarModelos(){semearTexto('modelos');const G=()=>new Geo();let g;
 const pinheiro=neve=>{const g=G().tronco(0,0,-.3,3.2,.32,.2,6,COR.casca);[[2.4,2.1,3.2,0],[3.5,1.7,2.9,.03],[4.6,1.3,2.6,.07],[5.7,.85,2.3,.12]].forEach(([y,r,a,s],k)=>{const c=neve&&k>0?[.62+k*.08,.74+k*.07,.76+k*.07]:[.07+k*.018,.25+k*.035,.17+k*.012];g.tronco(0,0,y,y+a,r,0,8,c,s,s+.09);g.tronco(0,0,y+.01,y,r,0,8,c.map(v=>v*.55),s,s)});return g};
 GEO.pinheiro=pinheiro(false);GEO.pinheiro_neve=pinheiro(true);
 GEO.carvalho=G().tronco(0,0,-.3,3.2,.42,.22,7,COR.casca).bola(0,4.4,0,2.1,1.7,2.1,[.22,.43,.14],.12).bola(1.3,3.6,.5,1.3,1.1,1.3,[.18,.37,.12],.09).bola(-1.1,3.8,-.7,1.4,1.2,1.4,[.27,.48,.15],.1).bola(.1,5.6,.2,1.3,1.1,1.3,[.33,.53,.17],.17);
 g=G().tronco(0,0,-.3,4.2,.2,.1,6,[.82,.8,.72]);for(const y of[.7,1.5,2.4,3.1])g.tronco(0,0,y,y+.1,.215-y*.024,.213-y*.024,6,[.16,.14,.12]);
 GEO.betula=g.bola(0,4.6,0,1.2,1.5,1.2,[.62,.66,.18],.15).bola(.5,3.7,.4,.8,.8,.8,[.52,.6,.16],.11).bola(-.3,5.7,-.1,.7,.8,.7,[.74,.7,.2],.2);
 GEO.seca=G().tronco(0,0,-.3,3,.3,.16,6,[.42,.3,.18]).tronco(.5,0,2,3.8,.14,.05,5,[.42,.3,.18]).bola(0,3.6,0,2.4,.7,2.4,[.55,.55,.2],.08).bola(.9,4.1,.3,1.2,.5,1.2,[.6,.58,.22],.1);
 GEO.pedra=G().bola(0,.35,0,1,.85,.9,COR.pedra,0,.35).bola(.7,.15,.4,.5,.4,.5,[.35,.38,.35],0,.3);
 const minerio=(cor,brilho)=>{const g=G().bola(0,.4,0,.95,.85,.95,[.3,.31,.32],0,.3);for(let k=0;k<9;k++){const a=k*2.4,y=.25+(k%4)*.24,r=.82-(k%4)*.11;g.bola(Math.cos(a)*r,y,Math.sin(a)*r,.2,.18,.2,cor,brilho,.3)}return g};
 GEO.carvao_no=minerio([.06,.06,.07],0);GEO.ferro_no=minerio([.85,.5,.3],0);GEO.ouro_no=minerio([1,.8,.15],-.3);
 g=G().bola(0,.2,0,.9,.45,.9,[.3,.31,.34],0,.3);for(const[x,z,h,r]of[[0,0,1.7,.3],[.45,.2,1.1,.2],[-.4,.3,1,.22],[.1,-.45,.8,.18]])g.tronco(x,z,0,h*.75,r,r*.8,5,[.4,.82,1],-.7,-.7).tronco(x,z,h*.75,h,r*.8,0,5,[.7,.95,1],-.9,-.9);GEO.cristal_no=g;
 GEO.arbusto=G().bola(0,.45,0,.8,.65,.8,[.14,.33,.12],.05,.3).bola(.55,.3,.2,.5,.45,.5,[.2,.4,.13],.05,.3);
 g=G().junta(GEO.arbusto,0,0,0);for(let k=0;k<14;k++){const a=k*2.4,r=.45+(k%3)*.14;g.bola(Math.cos(a)*r,.45+(k%4)*.13,Math.sin(a)*r,.09,.09,.09,[.65,.12,.5],0,.1)}GEO.fruteira=g;
 const folhas=(n,cor,hmin,hmax,w,raio,sw)=>{const g=G();for(let k=0;k<n;k++){const a=entre(0,TAU),r=entre(0,raio),x=Math.cos(a)*r,z=Math.sin(a)*r,h=entre(hmin,hmax),dx=Math.cos(a+1.6)*w,dz=Math.sin(a+1.6)*w;g.tri([x-dx,0,z-dz],[x+dx,0,z+dz],[x+entre(-.2,.2),h,z+entre(-.2,.2)],cor,[0,0,sw],null,[0,1,0])}return g};
 GEO.capim=folhas(9,[.29,.5,.15],.3,.75,.06,.55,.12);
 g=folhas(11,[.55,.72,.3],.9,1.5,.07,.4,.14);for(let k=0;k<4;k++){const a=k*1.7;g.bola(Math.cos(a)*.22,1.15+k*.07,Math.sin(a)*.22,.07,.2,.07,[.5,.32,.14],.12,.1)}GEO.junco=g;
 g=G();for(let k=0;k<22;k++){const x=((k%5)-2)*.2+entre(-.05,.05),z=((k/5|0)-2)*.2;g.tronco(x,z,0,.75,.022,.015,3,[.72,.62,.22],0,.08);g.bola(x,.86,z,.06,.15,.06,[.93,.76,.28],.09,.1)}GEO.trigo=g;
 g=G();[[0,0,.45,[.95,.85,.25]],[.35,.2,.35,[.9,.9,.95]],[-.3,.25,.4,[.75,.45,.9]],[.1,-.35,.3,[.95,.5,.45]]].forEach(([x,z,h,c])=>{g.tronco(x,z,0,h,.015,.01,3,[.2,.4,.1],0,.07);g.bola(x,h+.03,z,.09,.05,.09,c,.07,0)});GEO.flor=g;
 g=G();[[0,0,1],[.3,.15,.7],[-.18,.25,.55]].forEach(([x,z,s])=>{g.tronco(x,z,0,.3*s,.07*s,.06*s,5,[.9,.86,.74]);g.tronco(x,z,.27*s,.52*s,.27*s,0,7,[.78,.16,.1]);g.bola(x+.09*s,.42*s,z+.09*s,.04*s,.03*s,.04*s,[1,.97,.9],0,0)});GEO.cogumelo=g;
 // construções
 const M2=COR.madeira,Tb=COR.tabua;
 g=G().caixa(0,.92,0,1.5,.18,1,Tb);for(const x of[-.62,.62])for(const z of[-.38,.38])g.caixa(x,.42,z,.14,.84,.14,M2);
 GEO.bancada=g.caixa(-.35,1.05,0,.5,.06,.12,COR.ferro).caixa(.35,1.07,.15,.2,.12,.2,COR.pedra).caixa(0,.5,0,1.2,.08,.7,M2);
 g=G();for(let i=0;i<9;i++){const a=i/9*TAU;g.bola(Math.cos(a)*.7,.1,Math.sin(a)*.7,.24,.18,.24,[.4,.4,.39],0,.25)}for(let i=0;i<5;i++){const a=i/5*TAU,c=Math.cos(a),s=Math.sin(a);g.tri([c*.6,.04,s*.6],[-s*.11,.55,c*.11],[s*.11,.55,-c*.11],[.2,.11,.06],0,[0,-1,0])}GEO.fogueira=g;
 g=G();for(let i=0;i<5;i++)g.caixa(-.8+i*.4,1.3,0,.38,2.6,.22,Tb.map(v=>v*(.82+(i%2)*.2)));GEO.parede=g.caixa(0,.35,0,2,.12,.3,M2).caixa(0,2.25,0,2,.12,.3,M2);
 g=G();for(let r=0;r<5;r++)for(let i=0;i<(r%2?5:4);i++){const w=r%2?.4:.5;g.caixa(-1+w/2+i*w,.26+r*.52,0,w-.04,.48,.34,COR.pedra.map(v=>v*(.85+((i+r)%3)*.12)))}GEO.parede_pedra=g;
 GEO.porta=G().caixa(.7,1.15,0,1.4,2.3,.12,M2).caixa(.7,1.7,0,1.2,.1,.18,Tb).caixa(.7,.6,0,1.2,.1,.18,Tb).bola(1.15,1.15,.12,.07,.07,.07,[1,.8,.2],0,0);
 GEO.batente=G().caixa(-.86,1.3,0,.28,2.6,.28,Tb).caixa(.86,1.3,0,.28,2.6,.28,Tb).caixa(0,2.46,0,1.5,.28,.28,Tb);
 GEO.piso=G().caixa(-.5,.06,0,.97,.12,2,Tb).caixa(.5,.06,0,.97,.12,2,Tb.map(v=>v*.87));
 GEO.cerca=G().caixa(-.9,.6,0,.16,1.2,.16,M2).caixa(0,.6,0,.16,1.2,.16,M2).caixa(.9,.6,0,.16,1.2,.16,M2).caixa(0,.9,0,2,.12,.08,Tb).caixa(0,.45,0,2,.12,.08,Tb);
 GEO.poste=G().caixa(0,1,0,.16,2,.16,M2).caixa(0,2.05,0,.32,.14,.32,COR.casca).bola(0,2.32,0,.2,.3,.2,COR.fogo,-1,.2);
 GEO.bau=G().caixa(0,.35,0,1.1,.7,.7,M2).caixa(0,.8,0,1.16,.22,.76,Tb).caixa(0,.62,.37,.18,.24,.06,[1,.8,.2],-.35).caixa(-.4,.46,0,.1,.96,.74,[.3,.3,.32]).caixa(.4,.46,0,.1,.96,.74,[.3,.3,.32]);
 GEO.bau_aberto=G().caixa(0,.35,0,1.1,.7,.7,M2).caixa(0,1,-.45,1.16,.7,.14,Tb).caixa(0,.71,0,.95,.04,.55,[.12,.08,.04]).caixa(-.4,.36,0,.1,.72,.74,[.3,.3,.32]).caixa(.4,.36,0,.1,.72,.74,[.3,.3,.32]);
 GEO.cama=G().caixa(0,.3,0,1.3,.3,2.3,M2).caixa(0,.52,.15,1.2,.18,1.85,[.75,.2,.18]).caixa(0,.62,-.8,.9,.16,.45,[.93,.93,.9]).caixa(0,.6,-1.15,1.3,.9,.12,M2);
 GEO.farol=G().tronco(0,0,0,3.2,1.2,.75,8,COR.pedra).tronco(0,0,3.2,3.45,1.05,1.05,8,M2).tronco(0,0,3.45,4.3,.5,.62,6,[.5,.9,1],-1,-1).tronco(0,0,4.3,5.3,.62,0,6,[.75,.97,1],-1,-1);
 GEO.tenda=(()=>{const g=G(),A=[-1.5,0,-1.7],B=[1.5,0,-1.7],C=[0,2.4,-1.7],D=[-1.5,0,1.7],E_=[1.5,0,1.7],F=[0,2.4,1.7],m=[0,.8,0],l=COR.pano;for(const t of[[A,C,F],[A,F,D],[B,E_,F],[B,F,C]])g.tri(...t,l,0,m);return g.tri(A,B,C,[.5,.23,.1],0,m)})();
 GEO.tronco_banco=G().bola(0,.3,0,1.2,.35,.45,[.35,.23,.13],0,.08);
 GEO.poco=(()=>{const g=G().tronco(0,0,0,.9,1.2,1.2,10,COR.pedra).tronco(0,0,.75,.76,1,0,10,[.08,.25,.35]);for(const x of[-1,1])g.caixa(x,1.6,0,.16,1.8,.16,M2);return g.tronco(0,0,2.4,3.3,1.6,0,4,[.5,.2,.14])})();
 GEO.bigorna=G().caixa(0,.35,0,.6,.7,.5,COR.casca).caixa(0,.82,0,.4,.25,.3,[.25,.27,.3]).caixa(.1,1.02,0,1,.16,.4,[.35,.37,.4]);
 GEO.banca=(()=>{const g=G().caixa(0,.9,0,2.6,.14,1.2,Tb);for(const x of[-1.2,1.2])for(const z of[-.55,.55])g.caixa(x,1.3,z,.12,2.6,.12,M2);for(let i=0;i<6;i++)g.caixa(-1.25+i*.5,2.65,0,.5,.1,1.7,i%2?[.8,.2,.15]:[.92,.88,.8]);return g.bola(-.7,1.1,0,.2,.2,.2,[.8,.2,.1]).bola(0,1.1,.1,.25,.17,.2,[.75,.5,.2]).bola(.7,1.1,0,.2,.2,.2,[.9,.75,.2])})();
 GEO.diamante_no=minerio([.3,.95,.85],-.5);
 g=G().tronco(0,0,-.1,.12,.5,.5,5,[.2,.42,.12]).bola(0,.4,0,.52,.4,.52,[.9,.48,.08],0,.06).bola(.62,.25,.35,.3,.24,.3,[.86,.42,.06],0,.06).tronco(0,0,.72,.95,.07,.04,5,[.3,.35,.1]);GEO.abobora_pe=g;
 GEO.canteiro=G().caixa(0,-.12,0,.96,.4,.96,[.3,.19,.1]).caixa(0,.09,-.25,.9,.05,.14,[.22,.13,.07]).caixa(0,.09,.25,.9,.05,.14,[.22,.13,.07]);
 const pe=(folha,raiz,h)=>{const g=G();for(const[x,z]of[[-.25,-.25],[.25,-.25],[-.25,.25],[.25,.25]]){if(raiz)g.bola(x,.14,z,.11,.09,.11,raiz,0,.1);for(let k=0;k<4;k++){const a=k*1.6+x*5;g.tri([x-.04,.12,z],[x+.04,.12,z],[x+Math.cos(a)*.17,h,z+Math.sin(a)*.17],folha,[0,0,.08],[x,0,z])}}return g};
 GEO.broto=pe([.35,.62,.2],null,.3);GEO.cenoura_pe=pe([.25,.55,.18],[.92,.48,.08],.55);GEO.batata_pe=pe([.3,.45,.2],[.75,.58,.34],.45);
 GEO.trigo_pe=(()=>{const g=G();for(const x of[-.25,.25])for(const z of[-.25,.25]){const t=G().junta(GEO.trigo,0,0,0),v=t.v;for(let i=0;i<v.length;i+=10){v[i]*=.5;v[i+1]*=.75;v[i+2]*=.5}g.junta(t,x,.08,z)}return g})();
 GEO.tocha=G().caixa(0,.32,0,.1,.64,.1,M2).caixa(0,.67,0,.16,.1,.16,[.2,.14,.1]).bola(0,.84,0,.11,.17,.11,[1,.7,.18],-1,.15);
 GEO.barco=(()=>{const g=G(),c=[.55,.36,.18],e=[.38,.24,.12];g.caixa(0,.12,0,1.3,.14,2.4,e);for(const s of[-1,1]){g.caixa(s*.7,.42,-.05,.14,.5,2.5,c).caixa(s*.7,.7,-.05,.18,.08,2.55,e).caixa(s*1.05,.62,.1,.7,.06,.08,e).caixa(s*1.45,.5,.1,.28,.04,.34,c)}
  g.caixa(0,.42,-1.3,1.45,.5,.14,c).caixa(0,.45,1.28,1,.45,.16,c).caixa(0,.5,1.5,.5,.35,.3,e).caixa(0,.45,-.6,1.3,.08,.35,c);return g})();
 g=G().tronco(0,0,-.2,2.3,.27,.25,8,[.2,.48,.2]).bola(0,2.3,0,.25,.2,.25,[.24,.54,.22]).bola(.5,1.15,0,.4,.14,.15,[.2,.46,.19]).tronco(.82,0,1.1,1.9,.15,.14,7,[.22,.5,.2]).bola(.82,1.9,0,.14,.12,.14,[.25,.55,.22]).bola(-.46,.8,0,.36,.13,.14,[.2,.46,.19]).tronco(-.74,0,.75,1.4,.13,.12,7,[.22,.5,.2]).bola(-.74,1.4,0,.12,.11,.12,[.25,.55,.22]).bola(0,2.5,0,.09,.08,.09,[.95,.4,.55],0,.1);GEO.cacto=g;
 {const pedra=[.5,.47,.43];let g=G().tronco(0,0,0,.55,.2,.12,6,pedra).tronco(0,0,.55,1.05,.12,.02,6,[.6,.57,.52]).tronco(.24,.08,0,.5,.1,.02,5,pedra);GEO.estalagmite=g;
  GEO.estalactite=G().tronco(0,0,-1.1,-.6,.02,.1,6,[.6,.57,.52]).tronco(0,0,-.6,0,.1,.22,6,pedra).tronco(-.22,.1,-.55,0,.02,.1,5,pedra);
  g=G();for(const[x,z,h]of[[0,0,.5],[.22,.14,.3],[-.2,.1,.36],[.05,-.24,.22]])g.tronco(x,z,0,h,.04,.03,5,[.8,.9,.85],0,-.6).bola(x,h+.03,z,h*.32,h*.18,h*.32,[.3,.95,.85],-.95,.1);GEO.cogu_luz=g;
  g=G();for(const[x,z,h,cor]of[[0,0,.9,[.5,.85,1]],[.25,.1,.55,[.75,.55,1]],[-.22,-.12,.62,[.55,.7,1]],[.04,.26,.4,[.9,.7,1]]])g.tronco(x,z,0,h*.7,.1,.09,5,cor,0,-.8).tronco(x,z,h*.7,h,.09,.0,5,cor,0,-.9);GEO.cristal_cav=g}
 for(const k in GEO)modelos[k]=GEO[k].malha()}

// ---------- definição dos recursos ----------
const res=(n,hp,ferr,nivel,drops,raio,extra)=>Object.assign({n,hp,ferr,nivel,drops,raio,volta:3},extra);
const RECURSOS={
 pinheiro:res('Pinheiro',36,'machado',0,[['madeira',3,5]],.4),pinheiro_neve:res('Pinheiro nevado',36,'machado',0,[['madeira',3,5]],.4),
 carvalho:res('Carvalho',44,'machado',0,[['madeira',4,6],['maca',0,2]],.45),betula:res('Bétula',28,'machado',0,[['madeira',2,4]],.28),seca:res('Árvore seca',30,'machado',0,[['madeira',3,4]],.35),
 cacto:res('Cacto',16,null,0,[['fibra',2,4]],.34),
 diamante_no:res('Veio de diamante',90,'picareta',3,[['diamante',1,2]],.85),abobora_pe:res('Abóbora',10,null,0,[['b_abobora',1,1]],0,{coletar:true,volta:3}),
 pedra:res('Rocha',32,'picareta',1,[['pedra',2,4]],.85),carvao_no:res('Veio de carvão',36,'picareta',1,[['carvao',2,4],['pedra',0,1]],.9),
 ferro_no:res('Veio de ferro',48,'picareta',2,[['ferro',2,3],['pedra',0,2]],.9),ouro_no:res('Veio de ouro',60,'picareta',3,[['ouro',1,3]],.9),cristal_no:res('Cristal',72,'picareta',3,[['cristal',1,2]],.8),
 arbusto:res('Arbusto',14,null,0,[['fibra',1,3]],0),fruteira:res('Frutas silvestres',14,null,0,[['frutas',2,4]],0,{coletar:true,volta:1}),
 junco:res('Planta de fibra',6,null,0,[['fibra',2,4]],0,{coletar:true,volta:1}),cogumelo:res('Cogumelo',4,null,0,[['cogumelo',1,2]],0,{coletar:true,volta:1}),
 trigo:res('Trigo',6,null,0,[['trigo',2,3]],0,{coletar:true,volta:1})};
// alcance de desenho por tipo
const ALCANCE={cacto:.8,pinheiro:1,pinheiro_neve:1,carvalho:1,betula:1,seca:1,pedra:.8,carvao_no:.8,ferro_no:.8,ouro_no:.8,cristal_no:1,diamante_no:1,abobora_pe:.6,arbusto:.55,fruteira:.55,junco:.45,trigo:.5,capim:.33,flor:.35,cogumelo:.35};
