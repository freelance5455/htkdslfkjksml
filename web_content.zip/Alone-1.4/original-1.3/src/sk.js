// ---------- skins e corpo do personagem ----------
const ESTILOS={curto:'Curto',longo:'Longo',moicano:'Moicano',coque:'Coque',cacheado:'Cacheado',careca:'Careca'};
const CHAPEUS={nenhum:'Nenhum',palha:'Palha',bone:'Boné',cartola:'Cartola',coroa:'Coroa',capuz:'Capuz',chifres:'Chifres',antena:'Antena'};
const ACESSORIOS={capa:'Capa',oculos:'Óculos',barba:'Barba',mochila:'Mochila',mascara:'Máscara'};
const CORPOS_TIPO={normal:'Normal',forte:'Forte',esguio:'Esguio'};
const PALETAS={pele:['#f6d3b3','#e9b48a','#c68a5e','#9c6440','#6e4430','#4a2e22','#9fd08a','#b9c4d8'],
 cabelo:['#17110d','#4a2c17','#8a5426','#d9a441','#efe3c0','#b33a22','#9a9a9a','#3556c9','#7b3fb0','#2f9d6a','#e667a4'],
 roupa:['#d8473c','#e88326','#e9c534','#4c9a3a','#1f8f86','#3568c4','#6a45b8','#d4619a','#eeeae0','#8a8f96','#2b2d33','#6b4426'],
 olhos:['#1d1611','#2a5db8','#2f8a4a','#7a4a1e','#c22b2b','#8a38c2','#35d6e8','#f0b000']};
const PADRAO_SKIN={nick:'Viajante',pele:'#e9b48a',cabelo:'#4a2c17',estilo:'curto',camisa:'#1f8f86',calca:'#2b3a55',sapato:'#4a2e1c',olhos:'#1d1611',chapeu:'nenhum',corChapeu:'#d8473c',acessorios:{},corCapa:'#a8322c',corpo:'normal',face:null,torso:null};
const preset=(n,o)=>({n,s:{...PADRAO_SKIN,acessorios:{},...o}});
const PRESETS=[preset('Viajante',{}),preset('Lenhadora',{cabelo:'#b33a22',estilo:'longo',camisa:'#d8473c',calca:'#2b3a55',olhos:'#2f8a4a',acessorios:{mochila:true}}),
 preset('Mineiro',{pele:'#c68a5e',camisa:'#8a8f96',calca:'#6b4426',chapeu:'bone',corChapeu:'#e9c534',acessorios:{barba:true,mochila:true},corpo:'forte'}),
 preset('Arqueira',{pele:'#9c6440',cabelo:'#17110d',estilo:'coque',camisa:'#4c9a3a',calca:'#4a3420',chapeu:'capuz',corChapeu:'#2c5a28',acessorios:{capa:true},corCapa:'#2c5a28',corpo:'esguio'}),
 preset('Cavaleiro',{cabelo:'#d9a441',camisa:'#3568c4',calca:'#2b2d33',olhos:'#2a5db8',acessorios:{capa:true},corpo:'forte'}),
 preset('Maga',{pele:'#f6d3b3',cabelo:'#7b3fb0',estilo:'longo',camisa:'#6a45b8',calca:'#3a2a6a',olhos:'#8a38c2',chapeu:'cartola',corChapeu:'#3a2a6a',acessorios:{capa:true},corCapa:'#6a45b8'}),
 preset('Ninja',{camisa:'#2b2d33',calca:'#1c1d22',sapato:'#111216',olhos:'#c22b2b',chapeu:'capuz',corChapeu:'#1c1d22',acessorios:{mascara:true},corpo:'esguio'}),
 preset('Fazendeiro',{camisa:'#e9c534',calca:'#3568c4',chapeu:'palha',acessorios:{barba:true}}),
 preset('Realeza',{pele:'#c68a5e',cabelo:'#efe3c0',estilo:'cacheado',camisa:'#d4619a',calca:'#eeeae0',chapeu:'coroa',acessorios:{capa:true},corCapa:'#d8473c'}),
 preset('Autômato',{pele:'#b9c4d8',estilo:'careca',camisa:'#8a8f96',calca:'#5a6068',sapato:'#2b2d33',olhos:'#35d6e8',chapeu:'antena',corChapeu:'#35d6e8',corpo:'forte'}),
 preset('Duende',{pele:'#9fd08a',cabelo:'#2f9d6a',estilo:'moicano',camisa:'#6b4426',calca:'#4c9a3a',olhos:'#f0b000',corpo:'esguio'})];
const corValida=c=>typeof c==='string'&&/^#[0-9a-fA-F]{6}$/.test(c);
function validarSkin(o){const s={...PADRAO_SKIN,acessorios:{}};if(!o||typeof o!=='object')return s;
 s.nick=String(o.nick??s.nick).replace(/[<>&"'`\\]/g,'').slice(0,16).trim()||'Viajante';
 for(const k of['pele','cabelo','camisa','calca','sapato','olhos','corChapeu','corCapa'])if(corValida(o[k]))s[k]=o[k];
 if(Object.hasOwn(ESTILOS,o.estilo))s.estilo=o.estilo;if(Object.hasOwn(CHAPEUS,o.chapeu))s.chapeu=o.chapeu;if(Object.hasOwn(CORPOS_TIPO,o.corpo))s.corpo=o.corpo;
 for(const k in ACESSORIOS)if(o.acessorios&&o.acessorios[k])s.acessorios[k]=true;
 for(const[k,n]of[['face',64],['torso',96]])if(Array.isArray(o[k])&&o[k].length===n)s[k]=o[k].map(c=>corValida(c)?c:null);return s}
const codigoSkin=s=>btoa(unescape(encodeURIComponent(JSON.stringify(s))));
function lerCodigoSkin(t){try{const o=JSON.parse(decodeURIComponent(escape(atob(t.trim()))));return o&&typeof o==='object'&&o.pele?validarSkin(o):null}catch(e){return null}}
function skinAleatoria(nick){const q=qualquer,s={...PADRAO_SKIN,nick,pele:q(PALETAS.pele),cabelo:q(PALETAS.cabelo),estilo:q(Object.keys(ESTILOS)),camisa:q(PALETAS.roupa),calca:q(PALETAS.roupa),sapato:q(['#4a2e1c','#2b2d33','#6b4426','#eeeae0','#8a1f1f']),
 olhos:q(PALETAS.olhos),chapeu:Math.random()<.5?'nenhum':q(Object.keys(CHAPEUS)),corChapeu:q(PALETAS.roupa),corCapa:q(PALETAS.roupa),corpo:q(Object.keys(CORPOS_TIPO)),acessorios:{},face:null,torso:null};
 for(const k in ACESSORIOS)if(Math.random()<.2)s.acessorios[k]=true;return s}
const lerSkin=()=>{try{return validarSkin(JSON.parse(localStorage.getItem('alone.skin')))}catch(e){return validarSkin(null)}};
let SKIN=lerSkin();
const gravarSkin=()=>{try{localStorage.setItem('alone.skin',JSON.stringify(SKIN))}catch(e){}};

// monta as partes do personagem; armadura = [cabeça, tronco, pernas, pés, mão] com ids de item
function corpoSkin(s,arm=[]){const G=()=>new Geo(),c=k=>rgb(s[k]),pele=c('pele'),cab=c('cabelo'),cam=c('camisa'),cal=c('calca'),sap=c('sapato'),ac=s.acessorios||{},partes=[];
 const w=s.corpo==='forte'?1.16:s.corpo==='esguio'?.84:1,corArm=i=>arm[i]&&ITENS[arm[i]]&&ITENS[arm[i]].slot===i?rgb(ITENS[arm[i]].cor):null,brilho=i=>arm[i]&&['cristal','diamante'].includes(ITENS[arm[i]]?.material)?-.22:0,
  A0=corArm(0),A1=corArm(1),A2=corArm(2),A3=corArm(3),sombra=(v,k=.75)=>v.map(x=>x*k);
 let g=G().caixa(0,1.12,0,.54*w,.68,.29,cam);g.caixa(0,.8,0,.55*w,.1,.3,sombra(cal,.6)).caixa(0,1.44,.01,.2,.04,.27,pele);
 if(s.torso)s.torso.forEach((cor,i)=>{if(cor){const px=i%8,py=i/8|0;g.caixa((px-3.5)*.54*w/8,1.44-(py+.5)*.64/12,.147,.54*w/8,.64/12,.012,rgb(cor))}});
 if(A1){g.caixa(0,1.14,0,.62*w,.66,.37,A1,brilho(1)).caixa(0,1.14,.19,.2*w,.38,.02,sombra(A1),brilho(1)).caixa(0,.84,0,.63*w,.08,.38,sombra(A1,.6))}
 if(ac.mochila)g.caixa(0,1.13,-.27,.4*w,.46,.22,[.46,.3,.14]).caixa(0,1.28,-.39,.42*w,.16,.04,[.35,.22,.1]).caixa(0,1,-.39,.2,.14,.04,[.58,.4,.2]);
 partes.push(parte(g,[0,0,0]));
 if(ac.capa)partes.push(parte(G().caixa(0,-.48,-.03,.56*w,.98,.05,c('corCapa')).caixa(0,-.02,.02,.6*w,.07,.1,[1,.8,.25]),[0,1.43,ac.mochila?-.4:-.19],'capa'));
 g=G().caixa(0,.25,0,.44,.44,.42,pele);
 if(s.face)s.face.forEach((cor,i)=>{if(cor){const px=i%8,py=i/8|0;g.caixa((px-3.5)*.055,.47-(py+.5)*.055,.213,.055,.055,.01,rgb(cor))}});
 else{for(const k of[-1,1])g.caixa(k*.11,.28,.213,.1,.075,.012,[.97,.97,.95]).caixa(k*.09,.28,.221,.052,.075,.012,c('olhos'),s.olhos==='#35d6e8'?-.8:0).caixa(k*.11,.35,.214,.12,.025,.012,sombra(cab,.8));g.caixa(0,.2,.222,.07,.05,.03,sombra(pele,.88)).caixa(0,.12,.214,.14,.032,.012,sombra(pele,.5))}
 if(!A0||ITENS[arm[0]].material==='couro'){const e=s.estilo;
  if(e!=='careca'){if(e==='moicano')g.caixa(0,.55,-.02,.1,.2,.46,cab).caixa(0,.43,-.215,.1,.2,.04,cab);
   else{g.caixa(0,.49,-.01,.47,.09,.46,cab).caixa(0,.3,-.215,.47,.36,.05,cab);for(const k of[-1,1])g.caixa(k*.225,.36,-.07,.035,.24,.32,cab);g.caixa(.06,.45,.215,.28,.07,.03,cab)}
   if(e==='longo'){g.caixa(0,.05,-.22,.48,.5,.07,cab);for(const k of[-1,1])g.caixa(k*.23,.12,-.1,.05,.36,.22,cab)}if(e==='coque')g.bola(0,.58,-.2,.14,.14,.14,cab,0,.05);
   if(e==='cacheado')for(let i=0;i<16;i++){const a=i*2.4,r=.12+(i%3)*.055;g.bola(Math.cos(a)*r,.5+(i%2)*.04,Math.sin(a)*r-.03,.11,.1,.11,cab,0,.12)}}}
 if(ac.barba)g.caixa(0,.07,.2,.36,.14,.07,cab).caixa(0,.165,.225,.2,.04,.03,cab);
 if(ac.mascara)g.caixa(0,.12,.205,.46,.18,.05,[.15,.16,.2]);
 if(ac.oculos){for(const k of[-1,1])g.caixa(k*.11,.325,.235,.15,.022,.015,[.08,.08,.1]).caixa(k*.11,.235,.235,.15,.022,.015,[.08,.08,.1]).caixa(k*.185,.28,.235,.022,.11,.015,[.08,.08,.1]).caixa(k*.035,.28,.235,.022,.11,.015,[.08,.08,.1]);g.caixa(0,.29,.235,.07,.02,.015,[.08,.08,.1])}
 if(A0){const b=brilho(0);g.caixa(0,.46,0,.52,.14,.5,A0,b).caixa(0,.27,-.235,.52,.36,.05,A0,b);for(const k of[-1,1])g.caixa(k*.245,.27,-.02,.05,.36,.46,A0,b);g.caixa(0,.55,0,.12,.07,.52,sombra(A0),b)}
 else{const h=c('corChapeu'),t=s.chapeu;if(t==='palha')g.tronco(0,0,.46,.5,.52,.46,10,[.88,.72,.32]).tronco(0,0,.49,.68,.27,.18,10,[.9,.74,.34]).tronco(0,0,.5,.55,.28,.27,10,h);
  else if(t==='bone')g.caixa(0,.51,0,.48,.13,.46,h).caixa(0,.47,.31,.36,.04,.2,sombra(h));else if(t==='cartola')g.tronco(0,0,.47,.51,.4,.4,10,h).tronco(0,0,.5,.92,.24,.2,10,h).tronco(0,0,.53,.6,.25,.245,10,[1,.82,.25]);
  else if(t==='coroa'){g.caixa(0,.52,0,.48,.08,.46,[1,.8,.2],-.3);for(const[x,z]of[[-.2,.19],[.2,.19],[-.2,-.19],[.2,-.19],[0,.2]])g.caixa(x,.62,z,.07,.15,.07,[1,.8,.2],-.3);g.caixa(0,.53,.235,.08,.06,.02,[.85,.1,.2],-.8)}
  else if(t==='capuz'){g.caixa(0,.5,-.01,.53,.1,.5,h).caixa(0,.24,-.245,.53,.46,.06,h);for(const k of[-1,1])g.caixa(k*.248,.24,0,.05,.46,.46,h);g.tronco(0,-.22,.4,.72,.18,0,4,h)}
  else if(t==='chifres')for(const k of[-1,1])g.caixa(k*.27,.45,0,.14,.09,.09,[.92,.88,.76]).caixa(k*.33,.55,0,.08,.16,.07,[.92,.88,.76]);else if(t==='antena')g.caixa(0,.6,0,.03,.26,.03,[.5,.52,.56]).bola(0,.76,0,.07,.07,.07,h,-1,0)}
 partes.push(parte(g,[0,1.46,0],'cabeca'));
 const lb=.17*w;for(const k of[-1,1]){g=G().caixa(0,-.15,0,lb,.34,.19,cam).caixa(0,-.45,0,lb*.9,.28,.17,pele).caixa(0,-.66,0,lb*.92,.14,.175,pele);
  if(A1){const b=brilho(1);g.caixa(k*.015,-.02,0,lb+.1,.2,.28,A1,b).caixa(0,-.47,0,lb+.03,.22,.22,sombra(A1),b)}
  partes.push(parte(g,[k*(.275*w+lb/2+.005),1.42,0],k>0?'braco_d':'braco',k>0?Math.PI:0));
  g=G().caixa(0,-.37,0,.2*w,.74,.22,cal).caixa(0,-.745,.035,.215*w,.11,.29,sap);
  if(A2)g.caixa(0,-.27,0,.25*w,.5,.27,A2,brilho(2)).caixa(0,-.4,.145,.14,.12,.02,sombra(A2),brilho(2));if(A3)g.caixa(0,-.69,.035,.26*w,.24,.34,A3,brilho(3));
  partes.push(parte(g,[k*.14*w,.8,0],'perna',k>0?0:Math.PI))}
 return{partes}}
function apagarCorpo(c){if(c)for(const p of c.partes)apagarMalha(p.m)}
// aparência dos moradores, sempre a mesma para cada um
function corpoNpc(n){const guardado=estadoRnd;let h=0;for(const c of n.id+n.nome)h=(Math.imul(h,31)+c.charCodeAt(0))|0;estadoRnd=h;const f=n.fem,hex=v=>'#'+v.map(k=>Math.round(k*255).toString(16).padStart(2,'0')).join('');
 const s={...PADRAO_SKIN,acessorios:{},pele:escolher(PALETAS.pele.slice(0,6)),cabelo:escolher(PALETAS.cabelo.slice(0,6)),olhos:escolher(PALETAS.olhos.slice(0,4)),estilo:f?escolher(['longo','coque','cacheado','longo']):escolher(['curto','curto','careca','cacheado']),camisa:hex(n.cor),calca:escolher(['#4a3420','#2b3a55','#5a5148','#3d4a2a']),corpo:escolher(['normal','normal','forte','esguio'])};
 const extra={anciao:{cabelo:'#d8d8d2',camisa:'#6a45b8',calca:'#4a3080',acessorios:{capa:true,barba:!f},corCapa:'#4a3080'},ferreiro:{acessorios:{barba:!f},corpo:'forte',camisa:'#5a4030',torso:Array.from({length:96},(_,i)=>i>=24&&i%8>0&&i%8<7?'#3a2416':null)},
  mercador:{chapeu:'cartola',corChapeu:'#a8322c',acessorios:{mochila:true}},fazendeira:{chapeu:'palha',corChapeu:'#a8322c'},cacador:{chapeu:'capuz',corChapeu:'#2c5a28',camisa:'#6b4426'},aldeao:rnd()<.35?{chapeu:escolher(['palha','bone']),corChapeu:escolher(PALETAS.roupa)}:{}}[n.papel];
 const r=corpoSkin({...s,...extra});estadoRnd=guardado;return r}
