// ---------- versão 3: configurações novas ----------
Object.assign(CFG_PADRAO,{arred:true,texSuave:true,fisica:true,escava:1.3,cavR:3,luzCav:1,hudEsc:1,mira:'ponto',miraCor:'#ffffff',minimapa:1,coords:true,mostrarMao:true,balanco:true,autoPulo:false,sat:1,contraste:1,vinheta:1,bloom:1,limFps:0,tamBot:1,opBot:.9,
 multMob:1,multBicho:1,fomeOn:true,quedaOn:true,manterItens:true,regen:1,multColeta:1,velJog:1,nomeBichos:false,chuvaFreq:1,verBloco:true,dicasForma:true,sustos:true,casasQuebram:true});
CFG=Object.assign({},CFG_PADRAO,CFG);

// ---------- blocos novos ----------
const TEX={}; // textura -> [estilo, cor, cor secundária]
const t=(nome,estilo,cor,cor2)=>TEX[nome]=[estilo,cor,cor2];
function novoBloco(id,n,estilo,cor,dur,ferr,ing,qtd=4,extra={},cor2){t(id,estilo,cor,cor2);CORES_BLOCO[id]=cor;defB(id,n,id,dur,ferr,extra.nivel||0,undefined,extra);if(ing)RECEITAS_B.push(['b_'+id,qtd,ing])}
const RECEITAS_B=[],PRIMEIRO_NOVO=BLOCOS.length;
// pedras
novoBloco('granito','Granito','rocha','#a5725f',2.4,'picareta',{pedra:2,b_cascalho:1});
novoBloco('granito_polido','Granito polido','polida','#b07c68',2.4,'picareta',{b_granito:4});
novoBloco('tijolo_granito','Tijolo de granito','tijolos','#a5725f',2.4,'picareta',{b_granito:4},4,{},'#6d5148');
novoBloco('basalto','Basalto','colunas','#47484d',2.6,'picareta',{pedra:2,carvao:1});
novoBloco('basalto_polido','Basalto polido','polida','#4d4f55',2.6,'picareta',{b_basalto:4});
novoBloco('tijolo_basalto','Tijolo de basalto','tijolos','#47484d',2.6,'picareta',{b_basalto:4},4,{},'#25262a');
novoBloco('calcario','Calcário','rocha','#cfc7ae',2,'picareta',{pedra:1,b_areia:1},2);
novoBloco('tijolo_calcario','Tijolo de calcário','tijolos','#d6ceb4',2,'picareta',{b_calcario:4},4,{},'#a49c86');
novoBloco('arenito','Arenito','camadas','#d8b977',1.6,'picareta',{b_areia:4},2);
novoBloco('arenito_liso','Arenito liso','polida','#dcc084',1.6,'picareta',{b_arenito:4});
novoBloco('ardosia','Ardósia','camadas','#5a626b',2.4,'picareta',{pedra:2,b_terra:1});
novoBloco('tijolo_musgoso','Tijolo musgoso','musgo','#7f8382',2.4,'picareta',{b_tijolo_pedra:1,fibra:1},1,{},'#4e7a2c');
novoBloco('pedregulho_musgoso','Pedregulho musgoso','musgo_pedras','#7d807e',2.2,'picareta',{b_pedregulho:1,fibra:1},1,{},'#4e7a2c');
novoBloco('tijolo_claro','Tijolo claro','tijolos','#c9a58a',2,'picareta',{b_tijolo:2,b_areia:1},3,{},'#eadfcf');
novoBloco('tijolo_escuro','Tijolo escuro','tijolos','#5e3a34',2,'picareta',{b_tijolo:2,carvao:1},3,{},'#2e2422');
novoBloco('cimento','Cimento','concreto','#a9aaa6',2.2,'picareta',{b_cascalho:2,b_areia:2});
novoBloco('asfalto','Asfalto','granulado','#34363a',1.8,'picareta',{b_cascalho:3,carvao:1});
novoBloco('paralelepipedo','Paralelepípedo','paralelos','#8b8880',2.2,'picareta',{pedra:4},4,{},'#55524c');
// madeiras
for(const[m,n,casca,tabua]of[['escuro','escura','#3d2a17','#6a4526'],['betula','de bétula','#e4e0d4','#d9c58e'],['pinho','de pinho','#5a3d24','#a9773f'],['cerejeira','de cerejeira','#6e3e46','#e0959a'],['mogno','de mogno','#4a231a','#9b4a34']]){
 novoBloco('tronco_'+m,'Tronco '+n.replace('escura','escuro'),'casca',casca,1.4,'machado',{madeira:2,[{escuro:'carvao',betula:'pena',pinho:'fibra',cerejeira:'frutas',mogno:'b_terra'}[m]]:1},2);
 novoBloco('tabuas_'+m,'Tábuas '+n,'tabuas',tabua,1.1,'machado',{['b_tronco_'+m]:1},4)}
novoBloco('bambu','Bambu','bambu','#b6b04a',.9,'machado',{fibra:4});
novoBloco('deck','Deck de madeira','deck','#8f6034',1.1,'machado',{madeira:3});
novoBloco('treliça','Treliça de madeira','trelica','#a8743c',.6,'machado',{madeira:2},4,{opaco:false});
// telhados
for(const[c,n,cor]of[['vermelha','vermelha','#a83a2a'],['azul','azul','#35548f'],['verde','verde','#3d7248'],['preta','preta','#34353c'],['barro','de barro','#c0693a']])novoBloco('telha_'+c,'Telha '+n,'telha',cor,1.2,'picareta',{argila:2,b_areia:1},8);
novoBloco('telhado_madeira','Telhado de madeira','telha','#7a5230',1,'machado',{madeira:2},6);
// cores
const CORES16=[['branco','branco','branca','#e9eae6'],['cinza_claro','cinza-claro','cinza-clara','#a8aaa6'],['cinza','cinza','cinza','#5c6064'],['preto','preto','preta','#222227'],['marrom','marrom','marrom','#6e4426'],['vermelho','vermelho','vermelha','#b8332b'],['laranja','laranja','laranja','#e5741c'],['amarelo','amarelo','amarela','#eec32a'],
 ['lima','verde-lima','verde-lima','#78c22a'],['verde','verde','verde','#3d7a2c'],['ciano','ciano','ciano','#1f9aa6'],['azul_claro','azul-claro','azul-clara','#58a8e0'],['azul','azul','azul','#2f4aa8'],['roxo','roxo','roxa','#6f35a8'],['magenta','magenta','magenta','#b83aa0'],['rosa','rosa','rosa','#ea94ae']];
const TINTA={branco:'osso',cinza_claro:'pena',cinza:'pedra',preto:'carvao',marrom:'b_terra',vermelho:'frutas',laranja:'cenoura',amarelo:'trigo',lima:'sementes',verde:'fibra',ciano:'linha',azul_claro:'b_neve',azul:'b_cascalho',roxo:'cogumelo',magenta:'maca',rosa:'couro'};
for(const[c,n,,cor]of CORES16)novoBloco('concreto_'+c,'Concreto '+n,'concreto',cor,2,'picareta',{b_areia:2,b_cascalho:2,[TINTA[c]]:1},8);
for(const[c,,f,cor]of CORES16){const velha={branco:'branca',preto:'preta',vermelho:'vermelha',amarelo:'amarela',roxo:'roxa'}[c]||c;if(!NB_['la_'+velha])novoBloco('la_'+velha,'Lã '+f,'la',cor,.7,null,{la:1,[TINTA[c]]:1},1)}
for(const[c,n,,cor]of CORES16.filter((_,i)=>[0,3,5,7,9,12,13,15,6,10].includes(i)))novoBloco('vidro_'+c,'Vidro '+n,'vidro',cor,.4,null,{b_vidro:4,[TINTA[c]]:1},4,{opaco:false});
for(const[c,n,,cor]of CORES16)novoBloco('ceramica_'+c,'Cerâmica '+n,'ceramica',cor,1.8,'picareta',{argila:4,[TINTA[c]]:1},8);
// pisos
novoBloco('azulejo_branco','Azulejo branco','azulejo','#e8ece8',1.6,'picareta',{argila:2,osso:1},8,{},'#b8c4c0');
novoBloco('azulejo_azul','Azulejo azul','azulejo_flor','#e8ece8',1.6,'picareta',{argila:2,b_cascalho:1},8,{},'#2f5ab0');
novoBloco('piso_xadrez','Piso xadrez','xadrez','#e6e2da',1.8,'picareta',{b_marmore:2,carvao:1},4,{},'#26262a');
novoBloco('marmore_negro','Mármore negro','marmore','#2c2c34',2.2,'picareta',{b_marmore:2,carvao:2},2,{},'#c9b46a');
novoBloco('parquet','Parquet','parquet','#b07a42',1.1,'machado',{madeira:2},4);
// metais e pedras preciosas
for(const[id,n,cor,ing,nivel,luz]of[['cobre','cobre','#d9824a','cobre',2,0],['aco','aço','#8f9aa8','aco',3,0],['rubi','rubi','#e0304a','rubi',3,.15],['safira','safira','#2f6ae0','safira',3,.15],['esmeralda','esmeralda','#26b456','esmeralda',3,.15],['ametista','ametista','#a864e0','ametista',2,.3],['carvao','carvão','#2c2c30','carvao',1,0]])
 novoBloco('bloco_'+id,'Bloco de '+n,id==='carvao'||id==='ametista'?'cristais':'metal',cor,3,'picareta',{[ing]:4},1,{nivel,luz});
for(const[id,n,cor]of[['cobre','cobre','#d9824a'],['rubi','rubi','#e0304a'],['safira','safira','#2f6ae0'],['ametista','ametista','#a864e0']]){t('min_'+id,'minerio','#878a89',cor);CORES_BLOCO['min_'+id]=cor;defB('min_'+id,'Minério de '+n,'min_'+id,3.2,'picareta',id==='cobre'||id==='ametista'?2:3,id,{luz:id==='cobre'?0:.25})}
// luzes
novoBloco('lanterna','Lanterna','lanterna','#ffc45a',.5,null,{lingote:1,tocha:2},2,{luz:1,opaco:false});
for(const[c,n,,cor]of CORES16.filter((_,i)=>[5,7,8,10,12,14,0,6].includes(i)))novoBloco('neon_'+c,'Luz '+n,'neon',cor,.5,null,{b_vidro:1,cristal:1,[TINTA[c]]:1},4,{luz:1});
novoBloco('cogumelo_luz','Cogumelo luminoso','cogumelo_luz','#4ad8c8',.4,null,{cogumelo:4},1,{luz:.9});
novoBloco('brasa','Pedra em brasa','brasa','#d8581a',2,'picareta',{pedra:2,carvao:2},2,{luz:.6});
// natureza e diversos
novoBloco('feno','Fardo de feno','feno','#d9b13c',.6,null,{trigo:6},1);
novoBloco('melancia','Melancia','melancia','#4f9a30',.8,'machado',{melancia_fatia:6},1,{},'#285a18');
novoBloco('cacto_bloco','Bloco de cacto','cacto','#3d8a34',.6,null,{fibra:5});
novoBloco('osso_bloco','Bloco de osso','osso','#e6dfc8',1.8,'picareta',{osso:6},1);
novoBloco('argila_bloco','Bloco de argila','granulado','#9aa2ae',.7,'pa',{argila:4},1);
novoBloco('esponja','Esponja','esponja','#d8c83a',.6,null,{linha:4,b_areia:2},1);
novoBloco('mel_bloco','Bloco de mel','mel','#e8a018',.6,null,{mel:4},1,{opaco:false});
novoBloco('musgo','Bloco de musgo','granulado','#4e7a2c',.4,null,{fibra:3},2);
novoBloco('terra_arada','Terra arada','arada','#5a3a20',.6,'pa',{b_terra:2},2);
novoBloco('gelo_azul','Gelo azul','gelo','#6aa8f0',1.2,'picareta',{b_gelo:4},1);
novoBloco('neve_compacta','Neve compacta','tijolos','#e8f2f8',.8,'pa',{b_neve:4},4,{},'#b8ccd8');
novoBloco('papel_parede','Papel de parede','listras','#d8c8a8',.9,'machado',{madeira:1,fibra:2},4,{},'#8a4a4a');
novoBloco('livros','Pilha de livros','livros','#8a5a2a',.8,'machado',{madeira:2,couro:1},2);
novoBloco('engrenagem','Bloco de engrenagens','engrenagem','#8a8f96',2.4,'picareta',{lingote:2,cobre:2},2);
for(const b of BLOCOS.slice(PRIMEIRO_NOVO))item('b_'+b.id,b.n,'cubo',{ic:'cubo',cor:CORES_BLOCO[b.id],bloco:b.num,pilha:64,valor:b.id.startsWith('bloco_')?60:b.id.startsWith('min_')?10:3});

// ---------- materiais, comidas, armas, ferramentas ----------
for(const[id,n,ic,cor,valor]of[['cobre','Cobre','rocha','#d9824a',8],['aco','Aço','barra','#8f9aa8',28],['rubi','Rubi','cristal','#e0304a',60],['safira','Safira','cristal','#2f6ae0',60],['ametista','Ametista','cristal','#a864e0',30],['argila','Argila','po','#9aa2ae',3],['ovo','Ovo','fruta','#f2e8d0',4],['escama','Escama','couro','#4a9a78',9],['marfim','Marfim','osso','#f4ead0',30],['veneno','Veneno','pocao','#6ad83a',12],['pele','Pele rara','couro','#d89a4a',25],['asa','Asa de morcego','pena','#4a3a52',7],['chifre','Chifre','osso','#c8b088',14],['la_lhama','Fibra de lhama','nuvem','#e8d8b8',10]])
 item(id,n,'recurso',{ic,cor,valor});
for(const[id,n,cor,ic,fome,cura,valor]of[['laranja','Laranja','#f08a1c','fruta',14,3,3],['banana','Banana','#f4d83a','fruta',15,3,3],['uva','Uvas','#7a3aa8','bagas',12,3,3],['morango','Morangos','#e02a3a','bagas',11,4,3],['melancia_fatia','Fatia de melancia','#e84a54','carne',12,3,2],['abacaxi','Abacaxi','#e8b82a','fruta',20,5,6],['coco','Coco','#8a5a34','fruta',18,4,5],['manga','Manga','#f0a42a','fruta',17,5,5],['milho','Milho','#f4cc34','trigo',9,0,3],['tomate','Tomate','#d8342a','fruta',10,3,3],
 ['queijo','Queijo','#f4cc4a','pao',22,6,9],['ovo_frito','Ovo frito','#f8f0d8','tigela',20,5,8],['pizza','Pizza','#d8762a','bolo',60,18,30],['hamburguer','Hambúrguer','#a85a2a','pao',58,20,28],['sanduiche','Sanduíche','#d8a860','pao',38,10,15],['sopa_legumes','Sopa de legumes','#d86a2a','tigela',40,22,18],['salada','Salada de frutas','#e05a6a','tigela',34,16,14],['biscoito','Biscoito','#c8904a','pao',14,3,5],['suco','Suco de laranja','#f8a01c','pocao',18,10,9],['chocolate','Chocolate','#5a321c','pao',20,6,10],
 ['pastel','Pastel','#e0a848','pao',30,8,12],['pao_queijo','Pão de queijo','#f0cc78','pao',28,9,12],['brigadeiro','Brigadeiro','#3a2014','bagas',16,8,10],['acai','Açaí na tigela','#4a1a58','tigela',36,18,18],['tapioca','Tapioca','#f4f0e6','pao',30,8,12],['churrasco','Churrasco','#8a3018','carne',65,25,32],['sorvete','Sorvete','#f4b8d0','bolo',20,12,14],['mingau','Mingau','#f0e0b0','tigela',26,8,8]])comida(id,n,cor,ic,fome,cura,valor);
for(const[m,nm,cor,nv,dano]of[['cobre','de cobre','#d9824a',2,12],['aco','de aço','#8f9aa8',3,19],['rubi','de rubi','#e0304a',4,26],['safira','de safira','#2f6ae0',4,25],['esmeralda','de esmeralda','#2fcc5a',4,27]]){
 ferr('picareta_'+m,'Picareta '+nm,'picareta',nv,dano-4,cor,nv*55);ferr('machado_'+m,'Machado '+nm,'machado',nv,dano,cor,nv*55);ferr('pa_'+m,'Pá '+nm,'pa',nv,dano-6,cor,nv*40);ferr('enxada_'+m,'Enxada '+nm,'enxada',nv,dano-7,cor,nv*35);
 arma('espada_'+m,'Espada '+nm,'espada',dano*2,3.1,.38,cor,nv*90)}
arma('adaga','Adaga','faca',16,2.1,.22,'#cfd6dc',30);arma('katana','Katana','espada',44,3.3,.3,'#e8eef4',220);arma('martelo_guerra','Martelo de guerra','machado',70,2.7,.9,'#6a7078',240);arma('foice','Foice','lanca',34,3.6,.55,'#8f9aa8',120);arma('tridente','Tridente','lanca',46,3.9,.55,'#2fd0c0',260);arma('clava','Clava','tronco',20,2.5,.6,'#8a5a2a',12);
item('arco_longo','Arco longo','arma',{ic:'arco',cor:'#5a3a1a',dano:38,alcance:90,cad:.95,distancia:true,valor:150});
item('broca','Broca de cristal','ferramenta',{ic:'picareta',cor:'#58e8ff',ferramenta:'picareta',nivel:5,dano:20,alcance:3,cad:.4,valor:600,raio:2.4});
for(const[m,nm,cor,def,base]of[['cobre','de cobre','#d9824a',[.07,.13,.09,.06],'cobre'],['aco','de aço','#8f9aa8',[.11,.22,.16,.1],'aco'],['rubi','de rubi','#e0304a',[.13,.26,.2,.11],'rubi'],['safira','de safira','#2f6ae0',[.13,.26,.2,.11],'safira'],['esmeralda','de esmeralda','#2fcc5a',[.14,.28,.21,.12],'esmeralda']]){
 ARMADURAS[m]=[nm,cor,def,base];PECAS.forEach(([p,n,ic],s)=>{item(`${p}_${m}`,`${n} ${nm}`,'armadura',{ic,cor,slot:s,material:m,defesa:def[s],valor:Math.round(def[s]*700)});RC(`${p}_${m}`,1,{[base]:PECAS[s][3]})})}

// ---------- receitas ----------
for(const[id,qtd,ing]of RECEITAS_B)RC(id,qtd,ing);
RC('aco',1,{lingote:1,carvao:2},'fogo');RC('argila',2,{b_terra:2,b_areia:1},null);RC('b_tijolo',4,{argila:4,carvao:1},'fogo');
for(const[m,base]of[['cobre','cobre'],['aco','aco'],['rubi','rubi'],['safira','safira'],['esmeralda','esmeralda']]){RC('picareta_'+m,1,{[base]:3,madeira:2});RC('machado_'+m,1,{[base]:3,madeira:2});RC('pa_'+m,1,{[base]:1,madeira:2});RC('enxada_'+m,1,{[base]:2,madeira:2});RC('espada_'+m,1,{[base]:3,madeira:1})}
RC('adaga',1,{ferro:1,madeira:1});RC('katana',1,{aco:3,couro:1});RC('martelo_guerra',1,{aco:5,madeira:2});RC('foice',1,{lingote:2,madeira:3});RC('tridente',1,{aco:3,safira:2,escama:2});RC('clava',1,{madeira:4},null);RC('arco_longo',1,{madeira:5,linha:4,chifre:1});RC('broca',1,{aco:6,cristal:4,diamante:3});
for(const[id,q,ing,est]of[['ovo_frito',1,{ovo:1},'fogo'],['queijo',1,{balde_leite:1},'fogo'],['pizza',1,{trigo:3,queijo:1,tomate:2},'fogo'],['hamburguer',1,{pao:1,bife:1,queijo:1},'bancada'],['sanduiche',1,{pao:1,queijo:1,tomate:1},null],['sopa_legumes',1,{cenoura:1,batata:1,tomate:1},'fogo'],['salada',1,{maca:1,banana:1,laranja:1},null],['biscoito',4,{trigo:2,ovo:1},'fogo'],['suco',1,{laranja:3},null],['chocolate',2,{coco:1,mel:1},'fogo'],
 ['pastel',2,{trigo:2,queijo:1},'fogo'],['pao_queijo',3,{queijo:1,ovo:1,trigo:1},'fogo'],['brigadeiro',4,{chocolate:1,balde_leite:1},'fogo'],['acai',1,{uva:3,banana:1},'bancada'],['tapioca',2,{batata:2,coco:1},'fogo'],['churrasco',1,{carne_vaca:2,carne_crua:2,carvao:1},'fogo'],['sorvete',2,{balde_leite:1,morango:2,b_neve:2},'bancada'],['mingau',1,{milho:2},'fogo']])RC(id,q,ing,est);
// todo bloco do catálogo pode ser obtido na sobrevivência
{const extra={b_grama:[4,{b_terra:3,sementes:1}],b_terra:[2,{b_areia:1,fibra:1}],b_areia:[4,{b_cascalho:2}],b_cascalho:[4,{pedra:2}],b_neve:[4,{linha:1,osso:1}],b_pedra:[2,{pedra:2}],b_pedregulho:[2,{pedra:2}],b_folhas:[8,{fibra:4}],b_rocha_mae:[1,{b_obsidiana:4,diamante:1}],b_obsidiana:[1,{b_basalto:3,cristal:1}],b_gelo:[2,{b_neve:4}],b_min_carvao:[1,{carvao:2,pedra:2}],b_min_ferro:[1,{ferro:2,pedra:2}],b_min_ouro:[1,{ouro:2,pedra:2}],b_min_cristal:[1,{cristal:2,pedra:2}],b_min_diamante:[1,{diamante:2,pedra:2}],b_min_esmeralda:[1,{esmeralda:2,pedra:2}],b_min_cobre:[1,{cobre:2,pedra:2}],b_min_rubi:[1,{rubi:2,pedra:2}],b_min_safira:[1,{safira:2,pedra:2}],b_min_ametista:[1,{ametista:2,pedra:2}]};
 for(const it of Object.values(ITENS))if(it.cat==='cubo'&&!RECEITAS.some(r=>r.id===it.id)){const[q,ing]=extra[it.id]||[4,{pedra:2,fibra:1}];RC(it.id,q,ing)}}
