// ---------- som ----------
let ac=null,mix_={},ruidoBuf,proxCanto=0,proxAcorde=1,passoAcorde=0,proxChuva=0;
function iniciarSom(){if(ac){if(ac.state!=='running')ac.resume();return}try{ac=new(window.AudioContext||window.webkitAudioContext)()}catch(e){return}
 mix_.mestre=ac.createGain();mix_.mestre.connect(ac.destination);for(const k of['fx','amb','mus']){mix_[k]=ac.createGain();mix_[k].connect(mix_.mestre)}volumes();
 ruidoBuf=ac.createBuffer(1,ac.sampleRate*2,ac.sampleRate);const d=ruidoBuf.getChannelData(0);let u=0;for(let i=0;i<d.length;i++){u=(u+(Math.random()*2-1)*.06)/1.02;d[i]=u*2.5}
 const s=ac.createBufferSource(),f=ac.createBiquadFilter(),g=ac.createGain();s.buffer=ruidoBuf;s.loop=true;f.type='lowpass';f.frequency.value=420;g.gain.value=.2;s.connect(f).connect(g).connect(mix_.amb);s.start()}
function volumes(){if(!ac)return;mix_.mestre.gain.value=CFG.vMestre;mix_.fx.gain.value=CFG.vFx;mix_.amb.gain.value=CFG.vAmb;mix_.mus.gain.value=CFG.vMus}
function nota(f0,f1,dur,vol,quando=0,tipo='sine',canal='fx',ataque=.02){if(!ac)return;const t=ac.currentTime+quando,o=ac.createOscillator(),g=ac.createGain();o.type=tipo;
 o.frequency.setValueAtTime(f0,t);o.frequency.exponentialRampToValueAtTime(f1,t+dur);g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(vol,t+Math.min(ataque,dur/2));g.gain.exponentialRampToValueAtTime(.0001,t+dur);
 o.connect(g).connect(mix_[canal]);o.start(t);o.stop(t+dur+.05)}
function chiado(freq,dur,vol,quando=0,tipo='bandpass'){if(!ac)return;const s=ac.createBufferSource(),f=ac.createBiquadFilter(),g=ac.createGain(),t=ac.currentTime+quando;s.buffer=ruidoBuf;f.type=tipo;f.frequency.value=freq;
 g.gain.setValueAtTime(vol,t);g.gain.exponentialRampToValueAtTime(.001,t+dur);s.connect(f).connect(g).connect(mix_.fx);s.start(t,Math.random(),dur+.05)}
const SONS={golpe:v=>chiado(1500,.13,.5*v),acerto:v=>{chiado(500,.12,.8*v);nota(180,80,.12,.25*v,0,'square')},
 madeira:v=>{chiado(750,.09,.9*v);nota(150,90,.1,.3*v,0,'triangle')},pedra:v=>{chiado(2600,.07,.6*v);nota(900,500,.06,.12*v,0,'square')},
 pegar:v=>{nota(520,880,.12,.18*v);nota(780,1200,.1,.1*v,.07)},moeda:v=>{nota(1300,1300,.08,.14*v);nota(1750,1750,.2,.12*v,.07)},
 criar:v=>{for(let i=0;i<3;i++)chiado(900+i*300,.08,.7*v,i*.12)},comer:v=>{for(let i=0;i<3;i++)chiado(420,.09,.8*v,i*.15)},
 arco:v=>{nota(320,110,.18,.25*v,0,'triangle');chiado(2200,.12,.3*v)},gemido:v=>{nota(120,70,.9,.22*v,0,'sawtooth','fx',.25);nota(125,66,.9,.1*v,.05,'sawtooth')},
 ossos:v=>{for(let i=0;i<5;i++)chiado(2800+Math.random()*900,.03,.5*v,i*.07)},ferido:v=>{nota(220,90,.25,.35*v,0,'sawtooth')},
 morte:v=>{[330,262,196,131].forEach((f,i)=>nota(f,f*.9,.5,.2*v,i*.22,'triangle'))},missao:v=>{[523,659,784,1047].forEach((f,i)=>nota(f,f,.7,.16*v,i*.11,'triangle'))},
 bau:v=>{nota(90,160,.35,.2*v,0,'sawtooth');nota(1050,1050,.4,.1*v,.3)},porta:v=>{nota(140,95,.3,.18*v,0,'sawtooth');chiado(500,.1,.5*v,.25)},
 passo:v=>chiado(480+Math.random()*320,.09,.28*v),agua:v=>chiado(1300,.24,.45*v),
 mergulho:v=>{chiado(700,.35,.7*v);chiado(1800,.2,.4*v,.06);nota(300,90,.3,.14*v)},explosao:v=>{chiado(160,1.1,1.4*v,0,'lowpass');chiado(900,.4,.8*v);nota(90,30,.8,.5*v,0,'sawtooth')},
 pavio:v=>chiado(5200,.9,.25*v),fogo:v=>{chiado(1600,.25,.4*v);chiado(600,.3,.3*v,.1)},equipar:v=>{nota(700,1000,.08,.14*v,0,'triangle');chiado(3000,.08,.3*v,.05)},tesoura:v=>{chiado(4200,.05,.5*v);chiado(4200,.05,.5*v,.12)},
 latido:v=>{nota(520,300,.1,.2*v,0,'square');nota(560,320,.12,.2*v,.16,'square')},golem:v=>{nota(80,45,.5,.4*v,0,'square');chiado(220,.4,.8*v,0,'lowpass')},chiado:v=>chiado(3600,.35,.35*v),
 caverna:v=>{nota(70,55,1.8,.2*v,0,'sawtooth','amb',.4);nota(880,870,.5,.05*v,.7)},trovao:v=>{chiado(120,2.4,1.3*v,0,'lowpass');chiado(400,.5,.6*v,.05)},pingo:v=>nota(1500+Math.random()*900,700,.12,.05*v)};
function som(n,v=1){if(ac&&SONS[n])SONS[n](v)}
function somEm(n,x,z){const v=1-Math.hypot(x-P.x,z-P.z)/45;if(v>.05)som(n,v)}
function ambiente(){if(!ac)return;const t=ac.currentTime;
 if(chuvaForca>.15&&!CAV&&t>proxChuva){chiado(2600+Math.random()*1800,.5,.16*chuvaForca);proxChuva=t+.22}
 if(t>proxCanto){if(CAV){som('pingo');proxCanto=t+1+Math.random()*4}else if(noite>.5){for(let i=0;i<4;i++)nota(4300,4250,.045,.03,i*.08,'sine','amb');proxCanto=t+.6+Math.random()}
  else if(chuvaForca<.4){const b=2000+Math.random()*1600,n=2+Math.random()*4|0;for(let i=0;i<n;i++)nota(b,b*(1.15+Math.random()*.3),.1,.045,i*.14,'sine','amb');proxCanto=t+1.5+Math.random()*4}else proxCanto=t+3}
 // música gerada: acordes lentos e uma melodia esparsa
 if(t>proxAcorde&&CFG.vMus>0){const claro=[[196,247,294],[165,196,247],[131,165,196],[147,185,220]],escuro=[[110,131,165],[87,104,131],[98,117,147],[82,98,123]],a=(noite>.5||CAV?escuro:claro)[passoAcorde++%4];
  a.forEach((f,i)=>nota(f,f,6.5,.07,i*.12,'triangle','mus',2));for(let i=0;i<4;i++)if(Math.random()<.55){const f=a[Math.random()*3|0]*(noite>.5||CAV?2:4);nota(f,f,1.4,.045,.8+i*1.3,'sine','mus',.08)}proxAcorde=t+6}}
