// ---------- construção: plantas prontas, formas, modos e física das estruturas ----------
const giraXZ=(x,z,r)=>{const c=[1,0,-1,0][r&3],s=[0,1,0,-1][r&3];return[c*x+s*z,-s*x+c*z]};
const giroOlhar=()=>((Math.round(P.yaw/(Math.PI/2))%4)+4)%4;
function planoCasa(w,d,h,m){const hw=w>>1,hd=d>>1,l=[],c=(x,y,z,n,f='cubo',g=0)=>l.push([x,y,z,n,f,g]),telha=m.telha||'telhado_madeira';
 for(let x=-hw;x<=hw;x++)for(let z=-hd;z<=hd;z++){const bx=Math.abs(x)===hw,bz=Math.abs(z)===hd;
  if(!bx&&!bz){c(x,0,z,m.piso||'tabuas','tapete');if(h>=6)c(x,3,z,m.piso||'tabuas','laje_alta');continue}
  for(let y=0;y<h;y++){if(z===hd&&x===0&&y<2){c(x,y,z,m.porta||'tabuas','porta');continue}
   const andar=y%3===1,jan=andar&&!(bx&&bz)&&(bz&&Math.abs(x)===hw-1||bx&&z===0);
   if(jan)c(x,y,z,m.vidro||'vidro','janela',bx&&!bz?1:0);else c(x,y,z,bx&&bz?m.canto||'tronco':m.parede||'tabuas')}}
 for(let k=0;k<=hd+1;k++){const q=hd+1-k;for(let x=-hw;x<=hw;x++){if(q)c(x,h+k,q,telha,'telhado',0),c(x,h+k,-q,telha,'telhado',2);else c(x,h+k,0,telha,'laje')}
  for(let z=-(hd-k);z<=hd-k;z++)for(const x of[-hw,hw])c(x,h+k,z,m.parede||'tabuas')}
 return l}
function porPlano(tag,plano,x,y,z,r=0){for(const[a,b,c,n,f,g]of plano){const id=NB_[n]??NB_.tabuas,[ox,oz]=giraXZ(a,c,r);porEstrutura(tag,x+ox,y+b,z+oz,id,FM[f],(g+r)&3)}}
const caixaOca=(l,hw,hd,y0,y1,n)=>{for(let x=-hw;x<=hw;x++)for(let z=-hd;z<=hd;z++)if(Math.abs(x)===hw||Math.abs(z)===hd)for(let y=y0;y<=y1;y++)l.push([x,y,z,n,'cubo',0])};
const PLANTAS={
 cabana:['Cabana',()=>planoCasa(5,5,3,{parede:'tronco',canto:'tronco_escuro',telha:'telhado_madeira'})],
 casa:['Casa de família',()=>planoCasa(7,7,3,{parede:'tabuas',telha:'telha_vermelha'})],
 alvenaria:['Casa de tijolos',()=>planoCasa(9,7,4,{parede:'tijolo',canto:'pedregulho',telha:'telha_barro'})],
 sobrado:['Sobrado',()=>{const l=planoCasa(9,9,6,{parede:'tijolo_claro',canto:'tronco_escuro',telha:'telha_azul'}).filter(([x,y,z,n,f])=>!(y===3&&f==='laje_alta'&&x===-3&&z<2));for(let i=0;i<4;i++)l.push([-3,i,1-i,'tabuas','escada',0]);return l}],
 celeiro:['Celeiro',()=>planoCasa(9,11,4,{parede:'tabuas_escuro',canto:'tronco',telha:'telha_preta'})],
 torre:['Torre de vigia',()=>{const l=[];caixaOca(l,2,2,0,8,'pedregulho');const sai=l.filter(([x,y,z])=>!(x===0&&z===2&&y<2));
   const volta=[[-1,-1],[0,-1],[1,-1],[1,0],[1,1],[0,1],[-1,1],[-1,0]];for(let i=0;i<8;i++){const[x,z]=volta[(i+6)%8],[a,b]=volta[(i+7)%8];sai.push([x,i,z,'tabuas','escada',a>x?3:a<x?1:b>z?2:0])}
   for(let x=-2;x<=2;x++)for(let z=-2;z<=2;z++){if(!(x===-1&&Math.abs(z)<2||z===1&&x<1))sai.push([x,9,z,'tabuas','cubo',0]);if((Math.abs(x)===2||Math.abs(z)===2)&&(x+z)%2===0)sai.push([x,10,z,'pedregulho','cubo',0])}return sai}],
 muralha:['Muralha',()=>{const l=[];for(let x=-5;x<=5;x++){for(let y=0;y<4;y++)l.push([x,y,0,'pedregulho','cubo',0]);if(x%2===0)l.push([x,4,0,'pedregulho','laje',0])}return l}],
 ponte:['Ponte',()=>{const l=[];for(let z=0;z>-14;z--){for(let x=-1;x<=1;x++)l.push([x,0,z,'tabuas','laje',0]);for(const x of[-1,1])if(z%2===0)l.push([x,1,z,'tronco','poste',0])}return l}],
 poco:['Poço de pedra',()=>{const l=[];caixaOca(l,1,1,0,0,'pedregulho');for(const[x,z]of[[-1,-1],[1,1],[-1,1],[1,-1]])for(let y=1;y<3;y++)l.push([x,y,z,'tronco','poste',0]);for(let x=-1;x<=1;x++)for(let z=-1;z<=1;z++)l.push([x,3,z,'telhado_madeira','laje',0]);l.push([0,0,0,'agua0','cubo',0]);return l}],
 cercado:['Cercado',()=>{const l=[];caixaOca(l,4,4,0,0,'tronco');return l.filter(([x,y,z])=>!(x===0&&z===4)).map(c=>(c[4]='poste',c))}],
 piramide:['Pirâmide',()=>{const l=[];for(let k=0;k<6;k++){const s=5-k;for(let x=-s;x<=s;x++)for(let z=-s;z<=s;z++)if(Math.abs(x)===s||Math.abs(z)===s)l.push([x,k,z,'arenito','cubo',0])}return l}]};
const custoPlano=l=>{const m={};for(const c of l){const id='b_'+(NB_[c[3]]!==undefined?c[3]:'tabuas');if(c[3]!=='agua0')m[id]=(m[id]||0)+(['laje','laje_alta','tapete','janela','poste'].includes(c[4])?.5:1)}for(const k in m)m[k]=Math.ceil(m[k]);return m};
let planta=null,obraAndando=null;
const MODOS_OBRA={um:'Um bloco',linha:'Fileira (5)',parede:'Parede 5×3',piso:'Piso 5×5'};
function escolherPlanta(k){planta=k;avisar(`${PLANTAS[k][0]}: mire no chão e use (E) para erguer. Cancele no painel de construção.`,5)}
// onde a planta vai ficar: a porta fica virada para o jogador
function lugarPlanta(){if(!planta)return null;const c=celulaAlvo();if(!c)return null;const l=PLANTAS[planta][1](),r=giroOlhar();let zf=0;for(const q of l)zf=Math.max(zf,q[2]);
 const[ox,oz]=giraXZ(0,-zf,r),o={x:c.x+ox,y:c.y,z:c.z+oz,r,l,caixa:[1e9,1e9,1e9,-1e9,-1e9,-1e9]};
 for(const[a,b,d]of l){const[i,j]=giraXZ(a,d,r),p=[o.x+i,o.y+b,o.z+j];for(let e=0;e<3;e++){o.caixa[e]=Math.min(o.caixa[e],p[e]);o.caixa[e+3]=Math.max(o.caixa[e+3],p[e]+1)}}
 if(!criativo()){const falta=Object.entries(custoPlano(l)).filter(([id,q])=>tem(id)<q);if(falta.length)o.erro='Faltam materiais: '+falta.slice(0,3).map(([id,q])=>`${q-tem(id)} ${ITENS[id]?.n||id}`).join(', ')}return o}
function erguerPlanta(){const o=lugarPlanta();if(!o){avisar('Mire no chão',2);return}if(o.erro){avisar(o.erro,4);return}
 if(!criativo())for(const[id,q]of Object.entries(custoPlano(o.l)))remover(id,q);
 const fila=o.l.map(([a,b,c,n,f,g])=>{const[i,j]=giraXZ(a,c,o.r);return[o.x+i,o.y+b,o.z+j,NB_[n]??NB_.tabuas,FM[f],(g+o.r)&3]}).sort((a,b)=>a[1]-b[1]);
 obraAndando={fila,i:0,t:0};contar('construido','planta');planta=null;P.golpe=1}
function atualizarConstrucao(dt){const o=obraAndando;if(!o)return;o.t+=dt*Math.max(40,o.fila.length/5);while(o.t>=1&&o.i<o.fila.length){o.t--;const[x,y,z,n,f,g]=o.fila[o.i++];if(!ocupaJogador(x,y,z)||f)definirBloco(x,y,z,n,f,g);if(o.i%9===0){som('madeira',.35);faisca(x+.5,y+.5,z+.5,[.8,.7,.5],4,.1)}}
 if(o.i>=o.fila.length){obraAndando=null;avisar('Construção concluída!',3);salvar()}}
// ---------- formas e portas ----------
function trocarForma(f){const vis=FORMAS.map((x,i)=>i).filter(i=>!FORMAS[i].oculta);P.forma=f??vis[(vis.indexOf(P.forma||0)+1)%vis.length];avisar('Forma: '+FORMAS[P.forma].n,1.5)}
function celulasModo(c){const m=P.modoObra||'um',g=giroOlhar(),[fx,fz]=giraXZ(0,-1,g),l=[];
 if(m==='um')return[c];for(let i=0;i<5;i++)for(let j=0;j<(m==='linha'?1:m==='parede'?3:5);j++){const lado=i-2;
  if(m==='linha')l.push({x:c.x+fx*i,y:c.y,z:c.z+fz*i});else if(m==='parede')l.push({x:c.x-fz*lado,y:c.y+j,z:c.z+fx*lado});else l.push({x:c.x-fz*lado+fx*j,y:c.y,z:c.z+fx*lado+fz*j})}return l}
function alternarPorta(v){const f=v.v>>10&15,nova=f===FM.porta?FM.porta_aberta:FM.porta;for(const d of[0,1,-1]){const q=bruto(v.x,v.y+d,v.z);if(q&&(q>>10&15)===f)definirBloco(v.x,v.y+d,v.z,q&1023,nova,q>>14&3)}som('porta')}
const portaNaMira=()=>{const v=raioVox([P.x,P.y,P.z],dirOlhar(),3.5);return v&&((v.v>>10&15)===FM.porta||(v.v>>10&15)===FM.porta_aberta)?v:null};
// ---------- física das estruturas ----------
function limiteApoio(v){const b=BLOCOS[v&1023];if((v>>10&15)===FM.telhado||/telh/.test(b.id))return 12;if(/ferro|aco|cobre|metal/.test(b.id))return 14;return b.ferr==='machado'?10:8}
const granular=v=>!(v>>10&15)&&/^(areia|cascalho|areia_)/.test(BLOCOS[v&1023].id);
const pesaVox=v=>v&&BLOCOS[v&1023].solido&&!BLOCOS[v&1023].agua&&!BLOCOS[v&1023].lava;
const VIZ_APOIO=[[0,1,0,0],[1,0,0,1],[-1,0,0,1],[0,0,1,1],[0,0,-1,1],[1,1,0,1],[-1,1,0,1],[0,1,1,1],[0,1,-1,1],[0,-1,0,2]];
function verificarApoio(x,y,z,r){if(!CFG.fisica)return;const vistos=new Map(),pilha=[];
 const junta=(a,b,c)=>{const k=VK(a,b,c);if(vistos.has(k))return;const v=bruto(a,b,c);if(!pesaVox(v))return;const n={a,b,c,v,k,custo:1e9};vistos.set(k,n);pilha.push(n)};
 for(let a=x-r-1;a<=x+r+1;a++)for(let b=y-r-1;b<=y+r+2;b++)for(let c=z-r-1;c<=z+r+1;c++)junta(a,b,c);
 for(let i=0;i<pilha.length;i++){if(pilha.length>1400)return;const n=pilha[i];for(const[a,b,c]of VIZ_APOIO)junta(n.a+a,n.b+b,n.c+c)}
 const fila=[];for(const n of pilha)if([[0,-.2,0],[0,.2,0],[.7,.5,0],[-.7,.5,0],[0,.5,.7],[0,.5,-.7]].some(([a,b,c],i)=>(i===0||!granular(n.v))&&solidoT(n.a+.5+a,n.b+b,n.c+.5+c))||n.b<=FUNDO){n.custo=0;fila.push(n)}
 for(let i=0;i<fila.length;i++){const n=fila[i];for(const[a,b,c,p]of VIZ_APOIO){const m=vistos.get(VK(n.a+a,n.b+b,n.c+c));if(!m||granular(m.v)&&!(b===1&&!a&&!c))continue;const q=n.custo+p;if(q<m.custo&&q<=limiteApoio(m.v)){m.custo=q;fila.push(m)}}}
 const soltos=pilha.filter(n=>n.custo===1e9).sort((a,b)=>a.b-b.b);if(!soltos.length)return;let drops=0;
 for(const n of soltos){definirBloco(n.a,n.b,n.c,0);if(granular(n.v)){let b=n.b;while(b>FUNDO&&!bloco(n.a,b-1,n.c)&&!solidoT(n.a+.5,b-.5,n.c+.5))b--;if(b<n.b){definirBloco(n.a,b,n.c,n.v&1023);continue}}
  const id=BLOCOS[n.v&1023].solta;if(!criativo()&&id&&ITENS[id]&&drops++<40)soltar(id,1,n.a+.5,n.c+.5,n.b+.2)}
 for(let i=0;i<soltos.length;i+=Math.ceil(soltos.length/14)){const n=soltos[i];faisca(n.a+.5,n.b+.5,n.c+.5,rgb(CORES_BLOCO[BLOCOS[n.v&1023].id]||'#998877'),8,.2)}som('pedra')}
