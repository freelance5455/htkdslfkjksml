// ---------- muitos animais e criaturas novas ----------
const G_=()=>new Geo();
function ave(o){const c=o.cor,a=o.asa||c.map(v=>v*.75),bico=o.bico||[.95,.65,.1],h=o.perna||.12,s=o.s||1,partes=[];
 let g=G_().bola(0,h+.22*s,0,.2*s,.2*s,.3*s,c,0,.08).caixa(0,h+.24*s,-.34*s,.16*s,.05*s,.22*s,a);if(o.barriga)g.bola(0,h+.18*s,.06*s,.17*s,.16*s,.24*s,o.barriga,0,.06);partes.push(parte(g,[0,0,0]));
 const pc=o.pescoco||0;g=G_();if(pc)g.caixa(0,pc/2,0,.07*s,pc,.07*s,c);g.bola(0,pc+.1*s,.04*s,.13*s,.13*s,.14*s,o.cabeca||c,0,.06).caixa(0,pc+.07*s,.2*s,.07*s,.05*s,(o.bicoL||.14)*s,bico);for(const l of[-1,1])g.caixa(l*.1*s,pc+.13*s,.11*s,.035,.035,.035,[.05,.04,.04]);if(o.crista)g.caixa(0,pc+.25*s,0,.04,.12*s,.12*s,o.crista);partes.push(parte(g,[0,h+.3*s,.2*s],'pescoco'));
 for(const l of[-1,1]){partes.push(parte(G_().caixa(l*.22*s,0,-.02,.44*s,.03,.26*s,a).caixa(l*.46*s,0,-.07,.16*s,.025,.16*s,a.map(v=>v*.8)),[l*.15*s,h+.28*s,0],'asa',l));partes.push(parte(G_().caixa(0,-h/2,0,.035,h,.035,bico).caixa(0,-h+.02,.05,.1,.03,.14,bico),[l*.09*s,h+.04,0],'perna',l>0?0:Math.PI))}return{partes}}
function inseto(cor,asa){return{partes:[parte(G_().bola(0,.1,0,.05,.05,.13,[.12,.1,.08],0,.05),[0,0,0]),...[-1,1].map(l=>parte(G_().caixa(l*.12,0,.02,.22,.012,.18,cor).caixa(l*.1,.001,-.1,.16,.012,.12,asa),[l*.03,.12,0],'asa',l))]}}
function morcegoCorpo(){const c=[.2,.15,.22];return{partes:[parte(G_().bola(0,.2,0,.13,.14,.18,c,0,.1).caixa(-.08,.36,.08,.06,.12,.03,c).caixa(.08,.36,.08,.06,.12,.03,c).caixa(-.05,.23,.17,.03,.03,.02,[1,.2,.15],-.9).caixa(.05,.23,.17,.03,.03,.02,[1,.2,.15],-.9),[0,0,0]),...[-1,1].map(l=>parte(G_().caixa(l*.24,0,0,.4,.02,.26,c).caixa(l*.48,0,-.05,.18,.015,.14,c),[l*.08,.24,0],'asa',l))]}}
function fantasmaCorpo(){const c=[.72,.9,.95],g=G_().bola(0,1.5,0,.36,.38,.34,c,-.35,.08).tronco(0,0,.5,1.35,.18,.42,9,c,-.2,-.35);for(const l of[-1,1])g.caixa(l*.13,1.56,.31,.1,.15,.05,[.03,.05,.1]);g.caixa(0,1.35,.32,.14,.16,.04,[.03,.05,.1]);return{partes:[parte(g,[0,0,0]),...[-1,1].map(l=>parte(G_().caixa(0,-.25,.1,.13,.5,.13,c,-.3),[l*.42,1.2,0],'frente'))]}}
function sapoCorpo(c){const g=G_().bola(0,.16,0,.24,.15,.26,c,0,.08).bola(0,.12,.1,.2,.09,.2,[.85,.85,.5],0,.05);for(const l of[-1,1])g.bola(l*.13,.31,.14,.08,.08,.08,c).caixa(l*.14,.33,.21,.05,.05,.03,[.05,.04,.02]).caixa(l*.24,.06,-.08,.14,.09,.28,c.map(v=>v*.8));return{partes:[parte(g,[0,0,0])]}}
function tartarugaCorpo(){const casco=[.3,.4,.18],p=[.45,.62,.3],partes=[parte(G_().bola(0,.3,0,.42,.24,.5,casco,0,.12).caixa(0,.18,0,.72,.08,.86,[.62,.55,.3]),[0,0,0]),parte(G_().bola(0,.04,.16,.14,.13,.18,p,0,.05).caixa(-.1,.09,.26,.04,.04,.04,[.05,.04,.02]).caixa(.1,.09,.26,.04,.04,.04,[.05,.04,.02]),[0,.22,.45],'pescoco')];
 for(const[x,z,f]of[[-1,1,0],[1,1,Math.PI],[-1,-1,Math.PI],[1,-1,0]])partes.push(parte(G_().caixa(0,-.09,0,.17,.2,.19,p),[x*.34,.2,z*.3],'perna',f));return{partes}}
function cobraCorpo(c,l){const partes=[parte(G_().caixa(0,.12,.52,.17,.13,.24,c).caixa(-.06,.17,.62,.03,.03,.03,[1,.8,.1]).caixa(.06,.17,.62,.03,.03,.03,[1,.8,.1]).caixa(0,.09,.7,.03,.02,.14,[.9,.1,.1]),[0,0,0])];for(let i=0;i<7;i++)partes.push(parte(G_().bola(0,.09,0,.1-i*.01,.09-i*.008,.13,i%2?c:l,0,.05),[0,0,.34-i*.18],'cauda'));return{partes}}
function peixeGrande(cor,s,barriga){const g=G_().bola(0,.5,0,.34*s,.34*s,1.1*s,cor,0,.07).bola(0,.4,.1*s,.28*s,.24*s,.85*s,barriga,0,.05).caixa(0,.5+.42*s,-.1*s,.07,.34*s,.4*s,cor).caixa(0,.5,-1.2*s,.07,.75*s,.3*s,cor);for(const l of[-1,1])g.caixa(l*.45*s,.42,.2*s,.45*s,.05,.28*s,cor).caixa(l*.27*s,.62,.72*s,.05,.07,.07,[.03,.03,.05]);return{partes:[parte(g,[0,0,0])]}}
function polvoCorpo(c){const g=G_().bola(0,.62,0,.34,.4,.34,c,0,.08);for(const l of[-1,1])g.caixa(l*.17,.6,.3,.1,.1,.05,[.98,.98,.9]).caixa(l*.17,.6,.33,.05,.05,.03,[.02,.02,.02]);const p=[parte(g,[0,0,0])];for(let i=0;i<8;i++){const a=i/8*TAU;p.push(parte(G_().tronco(Math.sin(a)*.4,Math.cos(a)*.4,-.05,.12,.04,.08,5,c).tronco(Math.sin(a)*.24,Math.cos(a)*.24,.1,.42,.07,.12,5,c),[0,0,0],'cauda'))}return{partes:p}}
// extras para quadrúpedes
const faixas=cor=>(g,o)=>{for(let i=-3;i<=3;i+=2)g.caixa(0,o.perna+o.h/2,i*o.c*.12,o.w+.03,o.h+.03,o.c*.065,cor)};
const pintas=cor=>(g,o)=>{for(let i=0;i<14;i++){const s=i%2?1:-1;g.caixa(s*(o.w/2+.012),o.perna+o.h*(.15+(i*.37)%.75),((i*.29)%.9-.45)*o.c,.03,o.h*.16,o.c*.08,cor)}g.caixa(.05,o.perna+o.h+.01,.1,o.w*.3,.03,o.c*.15,cor).caixa(-.1,o.perna+o.h+.01,-.3,o.w*.25,.03,o.c*.12,cor)};
const Q_=quadrupede;
// id, nome, vida, velocidade, altura, raio, itens, extras, corpo
const NOVOS=[
 ['porco','Porco',26,4,1.1,.55,[['carne_crua',2,4]],{comida:'cenoura'},()=>Q_({cor:[.93,.62,.6],focinho:[.85,.45,.48],w:.72,h:.62,c:1.1,perna:.34,pescoco:.04,cabeca:.42,orelha:.14})],
 ['cavalo','Cavalo',70,7.5,1.9,.7,[['couro',2,4]],{domar:'maca',montaria:2,comida:'trigo',foge:5},()=>Q_({cor:[.42,.23,.12],cauda:[.12,.08,.05],w:.66,h:.7,c:1.55,perna:.9,pescoco:.65,cabeca:.38,orelha:.2,extraC:(g,o)=>g.caixa(0,o.pescoco*.7,-.14,.12,o.pescoco*1.1,.14,[.12,.08,.05])})],
 ['cavalo_branco','Cavalo branco',70,8.5,1.9,.7,[['couro',2,4]],{domar:'maca',montaria:2.3,comida:'trigo',foge:5},()=>Q_({cor:[.92,.91,.86],cauda:[.75,.73,.68],w:.66,h:.7,c:1.55,perna:.9,pescoco:.65,cabeca:.38,orelha:.2,extraC:(g,o)=>g.caixa(0,o.pescoco*.7,-.14,.12,o.pescoco*1.1,.14,[.7,.68,.62])})],
 ['burro','Burro',55,5.5,1.6,.6,[['couro',1,3]],{domar:'cenoura',montaria:1.6,comida:'trigo'},()=>Q_({cor:[.5,.47,.44],barriga:[.75,.72,.68],w:.58,h:.6,c:1.3,perna:.72,pescoco:.45,cabeca:.36,orelha:.4})],
 ['camelo','Camelo',80,5.5,2.4,.75,[['couro',2,4],['carne_crua',2,3]],{domar:'banana',montaria:1.8},()=>Q_({cor:[.82,.64,.38],w:.7,h:.7,c:1.5,perna:1.05,pescoco:.75,cabeca:.36,orelha:.1,extra:(g,o)=>g.bola(0,o.perna+o.h+.1,.28,.28,.3,.3,o.cor).bola(0,o.perna+o.h+.1,-.34,.28,.3,.3,o.cor)})],
 ['lhama','Lhama',40,5,1.8,.5,[['la_lhama',2,4]],{domar:'trigo',comida:'trigo'},()=>Q_({cor:[.9,.82,.66],la:[.95,.9,.78],w:.55,h:.55,c:1,perna:.7,pescoco:.7,cabeca:.3,orelha:.3})],
 ['bode','Cabra',30,5,1.3,.5,[['carne_crua',1,3],['couro',1,2],['chifre',0,2]],{comida:'trigo'},()=>Q_({cor:[.8,.78,.72],focinho:[.4,.36,.32],w:.5,h:.52,c:.95,perna:.55,pescoco:.25,cabeca:.32,orelha:.12,corno:true,extraC:(g,o)=>g.caixa(0,o.pescoco-.14,o.cabeca*1.3,.07,.2,.05,[.9,.88,.82])})],
 ['elefante','Elefante',260,4,3,1.3,[['marfim',2,4],['couro',4,7]],{dano:26,comida:'banana'},()=>Q_({cor:[.55,.55,.58],w:1.6,h:1.45,c:2.3,perna:1.15,pescoco:.2,cabeca:.9,orelha:.1,presa:true,extraC:(g,o)=>{g.caixa(0,o.pescoco-.15,o.cabeca*1.55,.26,.7,.26,o.cor).caixa(0,o.pescoco-.65,o.cabeca*1.65,.19,.5,.19,o.cor);for(const s of[-1,1])g.caixa(s*o.cabeca*.78,o.pescoco+.2,o.cabeca*.35,.5,.8,.09,[.5,.48,.52]).caixa(s*.26,o.pescoco-.28,o.cabeca*1.55,.09,.6,.09,[.96,.93,.82])}})],
 ['girafa','Girafa',90,6.5,4,.8,[['couro',3,6],['carne_crua',3,5]],{foge:7},()=>Q_({cor:[.92,.72,.32],w:.66,h:.7,c:1.35,perna:1.5,pescoco:1.9,cabeca:.34,orelha:.2,chifre:false,extra:pintas([.5,.28,.12]),extraC:(g,o)=>{for(let i=0;i<5;i++)g.caixa((i%2?.1:-.1),.3+i*.34,.06,o.cabeca*.78,.16,o.cabeca*.84,[.5,.28,.12]);for(const s of[-1,1])g.caixa(s*.09,o.pescoco+.52,.2,.05,.22,.05,[.4,.25,.1])}})],
 ['zebra','Zebra',50,8,1.7,.6,[['couro',2,4]],{foge:9},()=>Q_({cor:[.94,.93,.9],cauda:[.08,.08,.08],w:.62,h:.66,c:1.4,perna:.78,pescoco:.5,cabeca:.36,orelha:.2,extra:faixas([.07,.07,.08])})],
 ['bufalo','Búfalo',110,5,1.8,.85,[['carne_vaca',3,6],['couro',2,5],['chifre',1,2]],{dano:18},()=>Q_({cor:[.2,.15,.12],w:1.05,h:.95,c:1.7,perna:.6,pescoco:.1,cabeca:.55,orelha:.1,corno:true})],
 ['hipopotamo','Hipopótamo',150,4,1.7,1,[['carne_crua',4,7],['marfim',0,2]],{dano:20,agressivoPerto:6},()=>Q_({cor:[.52,.42,.48],focinho:[.7,.5,.52],w:1.35,h:1,c:2,perna:.45,pescoco:.02,cabeca:.7,orelha:.12})],
 ['rinoceronte','Rinoceronte',180,5.5,1.8,1,[['chifre',2,3],['couro',3,6]],{dano:24,agressivoPerto:5},()=>Q_({cor:[.5,.5,.48],w:1.2,h:1,c:1.9,perna:.55,pescoco:.04,cabeca:.62,orelha:.18,extraC:(g,o)=>g.caixa(0,o.pescoco+.34,o.cabeca*1.6,.14,.4,.14,[.9,.86,.74])})],
 ['alce','Alce',80,7,2.4,.75,[['carne_crua',3,5],['chifre',1,2],['couro',2,3]],{foge:8},()=>Q_({cor:[.35,.24,.16],w:.75,h:.75,c:1.5,perna:1,pescoco:.5,cabeca:.42,orelha:.22,chifre:true,extraC:(g,o)=>{for(const s of[-1,1])g.caixa(s*.42,o.pescoco+.72,.18,.34,.09,.26,[.8,.7,.52])}})],
 ['leao','Leão',90,8,1.5,.7,[['pele',1,2],['carne_crua',2,3]],{dano:19,agressivoPerto:11},()=>Q_({cor:[.82,.62,.3],w:.7,h:.62,c:1.45,perna:.6,pescoco:.2,cabeca:.46,orelha:.14,olho:[1,.7,.1],extraC:(g,o)=>g.bola(0,o.pescoco+.12,.12,.48,.46,.32,[.45,.24,.08],0,.18),extra:(g,o)=>g.caixa(0,o.perna+o.h*.4,-o.c*.7,.09,.09,.55,o.cor)})],
 ['tigre','Tigre',100,8.5,1.4,.7,[['pele',1,3],['carne_crua',2,3]],{dano:21,agressivoPerto:10},()=>Q_({cor:[.93,.5,.12],barriga:[.96,.92,.84],w:.68,h:.6,c:1.5,perna:.55,pescoco:.2,cabeca:.46,orelha:.14,olho:[.7,1,.3],extra:faixas([.08,.05,.03])})],
 ['onca','Onça-pintada',85,9,1.3,.65,[['pele',1,2],['carne_crua',2,3]],{dano:18,agressivoPerto:9},()=>Q_({cor:[.9,.66,.24],barriga:[.95,.9,.8],w:.6,h:.54,c:1.35,perna:.5,pescoco:.2,cabeca:.42,orelha:.13,olho:[.9,.9,.2],extra:pintas([.12,.08,.04])})],
 ['urso_polar','Urso polar',140,6,1.7,.85,[['carne_crua',3,5],['pele',1,2]],{dano:20,agressivoPerto:7},()=>Q_({cor:[.94,.95,.93],focinho:[.8,.8,.78],w:1.05,h:.95,c:1.75,perna:.6,pescoco:.2,cabeca:.5,orelha:.14})],
 ['panda','Panda',70,3.5,1.4,.7,[['couro',1,3]],{comida:'melancia_fatia'},()=>Q_({cor:[.95,.95,.92],escuro:[.08,.08,.08],orelhaC:1,w:.9,h:.8,c:1.25,perna:.42,pescoco:.1,cabeca:.52,orelha:.16,extra:(g,o)=>g.caixa(0,o.perna+o.h/2,o.c*.26,o.w+.03,o.h+.03,o.c*.22,[.08,.08,.08]),extraC:(g,o)=>{for(const s of[-1,1])g.caixa(s*o.cabeca*.38,o.pescoco+o.cabeca*.98,o.cabeca*.35,.15,.17,.1,[.08,.08,.08]).caixa(s*o.cabeca*.34,o.pescoco+o.cabeca*.34,o.cabeca*1.26,.14,.15,.04,[.08,.08,.08])}})],
 ['raposa','Raposa',24,8,.9,.4,[['pele',0,1],['couro',1,1]],{domar:'frutas',foge:7},()=>Q_({cor:[.88,.42,.1],barriga:[.96,.92,.86],cauda:[.95,.9,.82],w:.34,h:.34,c:.85,perna:.34,pescoco:.18,cabeca:.28,orelha:.22,extra:(g,o)=>g.caixa(0,o.perna+o.h*.6,-o.c*.78,.2,.2,.5,o.cor)})],
 ['cachorro','Cachorro',50,7.5,1,.45,[['couro',0,1]],{domar:'osso',dano:9},()=>Q_({cor:[.78,.55,.28],barriga:[.95,.88,.74],w:.4,h:.42,c:.95,perna:.42,pescoco:.2,cabeca:.34,orelha:.2,coleira:[.15,.35,.85],extra:(g,o)=>g.caixa(0,o.perna+o.h,-o.c*.58,.09,.36,.09,o.cor)})],
 ['gato','Gato',20,7,.65,.28,[['linha',0,1]],{domar:'peixe_cru',foge:4},()=>Q_({cor:[.35,.33,.34],barriga:[.9,.88,.85],w:.24,h:.25,c:.55,perna:.24,pescoco:.12,cabeca:.24,orelha:.14,olho:[.5,1,.35],extra:(g,o)=>g.caixa(0,o.perna+o.h+.2,-o.c*.56,.06,.5,.06,o.cor)})],
 ['esquilo','Esquilo',6,7,.45,.2,[['sementes',1,3]],{foge:7},()=>Q_({cor:[.6,.32,.14],barriga:[.9,.78,.6],w:.15,h:.16,c:.28,perna:.1,pescoco:.06,cabeca:.15,orelha:.09,extra:(g,o)=>g.bola(0,.42,-.2,.09,.22,.1,o.cor)})],
 ['rato','Rato',4,5,.3,.15,[],{foge:5},()=>Q_({cor:[.38,.34,.32],w:.13,h:.12,c:.26,perna:.05,pescoco:.02,cabeca:.13,orelha:.1,extra:(g)=>g.caixa(0,.1,-.28,.025,.025,.3,[.85,.55,.55])})],
 ['capivara','Capivara',40,4,.95,.5,[['carne_crua',2,3],['couro',1,2]],{comida:'melancia_fatia'},()=>Q_({cor:[.52,.34,.18],w:.55,h:.5,c:.95,perna:.28,pescoco:.1,cabeca:.38,orelha:.08})],
 ['tatu','Tatu',22,3.5,.6,.35,[['couro',1,2]],{foge:4},()=>Q_({cor:[.6,.5,.4],w:.38,h:.32,c:.6,perna:.14,pescoco:.02,cabeca:.2,orelha:.14,extra:(g,o)=>{for(let i=-2;i<=2;i++)g.caixa(0,o.perna+o.h*.62,i*.11,o.w+.05,o.h*.8,.05,[.44,.35,.28])}})],
 ['preguica','Preguiça',20,.9,.8,.35,[['pele',0,1]],{},()=>Q_({cor:[.5,.42,.3],corCabeca:[.78,.68,.5],w:.4,h:.42,c:.7,perna:.28,pescoco:.12,cabeca:.3,orelha:.04})],
 ['jacare','Jacaré',80,4.5,.7,.7,[['escama',2,5],['carne_crua',2,3]],{dano:17,agressivoPerto:6},()=>Q_({cor:[.25,.38,.18],barriga:[.66,.68,.4],w:.6,h:.3,c:1.7,perna:.18,pescoco:0,cabeca:.34,orelha:.05,olho:[1,.85,.1],extraC:(g,o)=>g.caixa(0,.06,o.cabeca*1.9,.28,.14,.55,o.cor),extra:(g,o)=>{g.caixa(0,o.perna+.1,-o.c*.72,.26,.18,.8,o.cor);for(let i=-3;i<=3;i++)g.caixa(0,o.perna+o.h+.04,i*.22,.1,.1,.1,[.2,.3,.14])}})],
 ['tartaruga','Tartaruga',40,1.2,.6,.45,[['escama',1,2]],{comida:'fibra'},()=>tartarugaCorpo()],
 ['sapo','Sapo',6,2.4,.4,.25,[['veneno',0,1]],{saltita:true},()=>sapoCorpo([.35,.7,.22])],
 ['cobra','Cobra',16,3,.35,.35,[['veneno',1,2],['escama',0,2]],{dano:9,agressivoPerto:3},()=>cobraCorpo([.3,.5,.2],[.7,.66,.2])],
 ['pato','Pato',10,3,.75,.3,[['pena',1,3],['carne_crua',1,1]],{comida:'sementes',bota:'ovo'},()=>ave({cor:[.5,.38,.24],cabeca:[.1,.45,.28],barriga:[.8,.76,.68],bico:[.98,.7,.1],pescoco:.12})],
 ['peru','Peru',18,3.5,1,.35,[['pena',2,5],['carne_crua',2,3]],{bota:'ovo'},()=>ave({cor:[.28,.18,.12],cabeca:[.7,.3,.3],crista:[.85,.15,.15],s:1.4,perna:.24,pescoco:.2})],
 ['pinguim','Pinguim',18,2.4,.9,.3,[['peixe_cru',0,2],['pena',1,2]],{},()=>ave({cor:[.07,.08,.1],asa:[.06,.07,.09],barriga:[.96,.96,.93],s:1.35,pescoco:.2,bico:[1,.6,.1]})],
 ['flamingo','Flamingo',20,3,1.7,.35,[['pena',2,4]],{},()=>ave({cor:[.98,.52,.62],bico:[.15,.1,.12],perna:.75,pescoco:.55})],
 ['coruja','Coruja',12,4,.6,.3,[['pena',1,3]],{voa:3.5},()=>ave({cor:[.45,.32,.2],barriga:[.86,.76,.6],cabeca:[.55,.42,.28],s:1.1,bicoL:.06})],
 ['aguia','Águia',26,7,.6,.4,[['pena',2,5]],{voa:11},()=>ave({cor:[.25,.16,.09],cabeca:[.96,.95,.9],s:1.5})],
 ['papagaio','Papagaio',8,5,.5,.25,[['pena',2,3]],{voa:2.8,domar:'sementes'},()=>ave({cor:[.15,.72,.25],asa:[.15,.35,.9],cabeca:[.95,.8,.1],bico:[.2,.18,.15],crista:[.9,.15,.1]})],
 ['arara','Arara-azul',10,5.5,.6,.3,[['pena',2,4]],{voa:5},()=>ave({cor:[.1,.3,.9],barriga:[.98,.78,.1],bico:[.1,.08,.08],s:1.2,pescoco:.08})],
 ['pombo','Pombo',5,4.5,.45,.2,[['pena',1,2]],{voa:2,foge:5},()=>ave({cor:[.55,.57,.62],cabeca:[.3,.4,.42],s:.75})],
 ['borboleta','Borboleta',1,1.6,.2,.1,[],{voa:1.3,enfeite:true},()=>inseto([1,.6,.1],[.15,.1,.1])],
 ['borboleta_azul','Borboleta azul',1,1.8,.2,.1,[],{voa:1.6,enfeite:true},()=>inseto([.2,.55,1],[.1,.15,.45])],
 ['abelha','Abelha',2,2.4,.2,.12,[['mel',1,1]],{voa:1.4,enfeite:true},()=>({partes:[parte(G_().bola(0,.1,0,.09,.09,.13,[1,.78,.1],0,.05).caixa(0,.1,-.03,.19,.19,.035,[.1,.08,.05]).caixa(0,.1,.06,.18,.18,.03,[.1,.08,.05]),[0,0,0]),...[-1,1].map(l=>parte(G_().caixa(l*.1,0,0,.18,.01,.1,[.85,.93,1]),[l*.03,.19,0],'asa',l))]})],
 ['tubarao','Tubarão',90,6,1.1,.8,[['peixe_cru',3,5],['marfim',0,1]],{dano:18,agressivoPerto:12,aquatico:true},()=>peixeGrande([.42,.48,.55],1,[.9,.92,.92])],
 ['golfinho','Golfinho',50,6.5,.9,.7,[['peixe_cru',2,3]],{aquatico:true},()=>peixeGrande([.4,.55,.75],.75,[.86,.9,.95])],
 ['polvo','Polvo',24,2,1,.5,[['linha',1,3]],{aquatico:true},()=>polvoCorpo([.85,.3,.35])],
 // criaturas hostis
 ['mumia','Múmia',60,2.8,1.95,.45,[['linha',2,4],['ouro',0,2],['moeda',3,9]],{monstro:true,dano:13},()=>humano({pele:[.82,.76,.58],camisa:[.86,.8,.62],calca:[.76,.7,.52],olho:[1,.8,.1],cabelo:[.82,.76,.58],zumbi:true})],
 ['zumbi_gelo','Zumbi do gelo',55,3,1.95,.45,[['b_gelo',1,2],['moeda',2,6]],{monstro:true,dano:12,afunda:true},()=>humano({pele:[.6,.82,.92],camisa:[.25,.4,.6],calca:[.18,.25,.38],olho:[.4,1,1],cabelo:[.85,.95,1],zumbi:true})],
 ['bandido','Bandido',50,4.2,1.95,.45,[['moeda',8,24],['faca',-3,1],['pao',0,2]],{monstro:true,dano:11},()=>humano({pele:[.75,.52,.36],camisa:[.16,.14,.14],calca:[.24,.18,.12],olho:[.08,.05,.03],cabelo:[.5,.1,.08]})],
 ['fantasma','Fantasma',30,3,1.9,.45,[['cristal',0,2],['moeda',3,8]],{monstro:true,dano:9,voa:.6},()=>fantasmaCorpo()],
 ['morcego','Morcego',9,5,.45,.25,[['asa',1,2]],{monstro:true,dano:4,voa:1.8},()=>morcegoCorpo()],
 ['escorpiao','Escorpião',26,4.5,.8,.5,[['veneno',1,2]],{monstro:true,dano:10},()=>corpoAranha([.5,.3,.1],[.7,.45,.15])],
 ['aranha_caverna','Aranha das cavernas',22,6,.8,.45,[['veneno',0,1],['linha',1,2]],{monstro:true,dano:8,pula:true,escala:.75},()=>corpoAranha([.08,.2,.24],[.1,.35,.38])],
 ['gosma_lava','Gosma de lava',44,3,1,.55,[['carvao',1,3],['ouro',0,1]],{monstro:true,dano:13,saltita:true},()=>corpoGosma([1,.42,.08])],
 ['golem_magma','Golem de magma',160,2.4,2.8,.8,[['b_brasa',2,4],['rubi',1,2],['moeda',20,40]],{monstro:true,dano:22,afunda:true},()=>corpoGolem([.2,.14,.13],[.12,.08,.08],[.55,.18,.05],[1,.55,.05])],
 ['lobisomem','Lobisomem',95,6.8,2.2,.6,[['pele',2,3],['moeda',10,25]],{monstro:true,dano:17,escala:1.12},()=>humano({pele:[.3,.24,.2],camisa:[.26,.2,.16],calca:[.22,.17,.14],olho:[1,.75,.05],cabelo:[.2,.15,.12],zumbi:true})]];
function criarAnimais(){for(const[id,,,,,,,,corpo]of NOVOS)CORPOS[id]=corpo()}
for(const[id,n,hp,vel,alt,raio,drops,x]of NOVOS){BICHOS[id]=Object.assign({n,hp,vel,calmo:Math.min(1.6,vel*.3)+.2,alt,raio,drops},x);item('ovo_'+id,'Invocar '+n.toLowerCase(),'ovo',{ic:'ovo',cor:`hsl(${(id.length*71+id.charCodeAt(0)*13)%360} 60% 55%)`,mob:id,pilha:64})}
const FAUNA_NOVA={carvalhal:['esquilo','raposa','cachorro','porco','sapo','coruja','pombo','borboleta','abelha','onca','capivara'],pinheiral:['alce','raposa','coruja','aguia','esquilo','alce'],betulas:['porco','cachorro','gato','pato','peru','borboleta','abelha','papagaio','cavalo'],
 campina:['cavalo','cavalo','cavalo_branco','burro','porco','pato','peru','borboleta','borboleta_azul','abelha','bode','bufalo','lhama'],savana:['leao','zebra','zebra','girafa','girafa','elefante','elefante','rinoceronte','hipopotamo','bufalo','tigre','jacare','arara','flamingo'],neve:['pinguim','pinguim','urso_polar','raposa','alce','bode'],deserto:['camelo','camelo','cobra','tatu','aguia','lhama','rato']};
const TROPICAIS=['panda','preguica','arara','papagaio','capivara','jacare','tartaruga','flamingo','sapo','tigre'];
function sortearFauna(b){const l=[...FAUNA[b]||[],...FAUNA_NOVA[b]||[]];return Math.random()<.09&&b!=='neve'&&b!=='deserto'?qualquer(TROPICAIS):qualquer(l)}
function monstroDaSuperficie(b){const r=Math.random();if(r<.12)return'fantasma';if(r<.17)return'bandido';if(r<.2)return'lobisomem';if(b==='deserto'&&r<.65)return r<.45?'mumia':'escorpiao';if(b==='neve'&&r<.65)return'zumbi_gelo';return r<.5?'zumbi':r<.73?'esqueleto':r<.9?'aranha':'gosma'}
function monstroDaCaverna(y){const l=['zumbi','esqueleto','aranha','gosma','morcego','morcego','aranha_caverna'];if(y<-30)l.push('gosma_lava','golem_magma');return qualquer(l)}
// criaturas voadoras
function pensarVoo(e,dt,d){const def=e.def;if(e.manso&&e.sentado){e.v=0;return}
 const caca=def.monstro&&!e.manso&&!criativo()&&CFG.dif!=='pacifico'&&d<24&&Math.abs(P.y-1-e.y)<12&&!emRefugio(P.x,P.z,.75);
 if(def.monstro&&(CFG.dif==='pacifico'||(!e.fundo&&noite<.3))){e.sumir=true;return}
 let alvoY;
 if(caca){e.h=mira(e,P.x,P.z);e.v=d>def.raio+.6?def.vel:0;alvoY=P.y-def.alt*.7;if(d<def.raio+1.2&&Math.abs(P.y-1-e.y)<1.6&&e.atq<0){e.atq=1.4;e.golpe=1;ferirJogador(def.dano*DIFICULDADES[CFG.dif].dano,e.x,e.z)}}
 else if(e.manso){e.h=mira(e,P.x,P.z);e.v=d>2.5?def.vel:0;if(d>30){e.x=P.x+1;e.z=P.z+1}alvoY=P.y-.2}
 else{if(e.t<0){e.h+=(Math.random()-.5)*2.4;e.v=def.vel*(.35+Math.random()*.4);e.alt0=def.voa*(.5+Math.random()*.9);e.t=1.5+Math.random()*3}if(def.foge&&d<def.foge&&!criativo()){e.h=mira(e,P.x,P.z)+Math.PI;e.v=def.vel}alvoY=(e.fundo?solo(e.x,e.z,e.y+.5):Math.max(altura(e.x,e.z),0))+(e.alt0??def.voa)+Math.sin(tempo*(def.enfeite?5:1.7)+e.max+e.fase)*(def.enfeite?.4:.3)}
 const nx=e.x+Math.sin(e.h)*e.v*dt,nz=e.z+Math.cos(e.h)*e.v*dt,ny=e.y+clamp(alvoY-e.y,-1,1)*dt*def.vel*.5;
 if(def.n==='Fantasma'||!bloqueado(nx,ny+.2,nz)&&!(e.fundo&&solidoT(nx,ny+.2,nz))){e.x=clamp(nx,-M.MEIO+20,M.MEIO-20);e.z=clamp(nz,-M.MEIO+20,M.MEIO-20);e.y=ny}else{e.h+=2.4;e.y+=dt*(e.fundo?-1:1.5)}
 e.voando=true}
// domar, alimentar e montar
function interacaoBicho(e,it){const def=e.def;if(def.montaria&&e.manso&&P.montaria!==e)return['montar',`Montar no ${def.n.toLowerCase()}`,-.5];if(def.domar&&!e.manso&&it?.id===def.domar)return['domar2',`Domar com ${ITENS[def.domar].n.toLowerCase()}`,-.9];
 const c=def.comida||{vaca:'trigo',ovelha:'trigo',galinha:'sementes',coelho:'cenoura'}[e.tipo];if(c&&it?.id===c&&!e.filhote&&!(e.amor>0)&&!(e.cansado>tempo))return['alimentar',`Alimentar ${def.n.toLowerCase()}`,-.8];
 if(e.manso&&def.domar&&e.tipo!=='lobo')return['pet',e.sentado?`Chamar ${def.n.toLowerCase()}`:`Mandar ${def.n.toLowerCase()} esperar`,-.3];return null}
function usarBicho(tipo,e){const def=e.def;P.golpe=1;
 if(tipo==='montar'){P.montaria=e;P.voando=false;P.barco=null;e.sentado=false;P.y=Math.max(P.y,e.y+1.7);som('passo');avisar(CFG.modo==='touch'?'Montado! Use o botão Descer para apear.':'Montado! Shift desce, Ctrl não é necessário.',4)}
 else if(tipo==='domar2'){gastar();if(Math.random()<.55){e.manso=true;e.ch=undefined;e.raiva=0;e.panico=0;e.sentado=!!def.montaria;contar('domou',e.tipo);avisar(`${def.n} domado!`,4);faisca(e.x,e.y+def.alt,e.z,[1,.4,.6],20,.18);som('latido')}else{faisca(e.x,e.y+def.alt,e.z,[.6,.6,.6],8,.15);avisar('Ainda desconfia. Tente de novo.',2.5)}}
 else{gastar();e.amor=25;som('comer',.6);faisca(e.x,e.y+def.alt+.2,e.z,[1,.35,.55],14,.2);
  const par=seres.find(o=>o!==e&&!o.morte&&o.tipo===e.tipo&&o.amor>0&&Math.hypot(o.x-e.x,o.z-e.z)<8);
  if(par){e.amor=par.amor=0;e.cansado=par.cansado=tempo+60;const f=criar(e.tipo,(e.x+par.x)/2,(e.z+par.z)/2,{ch:e.ch,escala:(def.escala||1)*.55,filhote:90,manso:e.manso&&par.manso,y:e.y});f.hp=f.max;avisar(`Nasceu um filhote de ${def.n.toLowerCase()}!`,4);contar('domou','filhote')}else avisar('Alimente outro da mesma espécie por perto para nascer um filhote.',4)}}
function descerMontaria(){const e=P.montaria;if(!e)return;P.montaria=null;e.sentado=true;const[fx,fz]=frente(),x=P.x+fz*1.3,z=P.z-fx*1.3;if(!colideVox(x,pes()+.05,z,.3,1.7)){P.x=x;P.z=z}P.vy=3}
