// ---------- baús e itens ----------
const SAQUE=[[['madeira',4,12],['pedra',3,10],['fibra',3,8],['maca',1,4],['pao',1,3],['atadura',1,2],['tocha',2,6],['flecha',4,12],['moeda',3,12],['faca',1,1],['machado_pedra',1,1],['carvao',1,5],['sementes',2,6],['cenoura',1,4],['batata',1,4],['b_tabuas',8,24],['linha',1,4],['balde',1,1],['vara_pesca',1,1],['pa_pedra',1,1]],
 [['carvao',3,8],['ferro',2,6],['couro',2,5],['pao',2,4],['atadura',1,4],['flecha',8,20],['moeda',10,30],['espada_pedra',1,1],['arco',1,1],['lanca',1,1],['picareta_pedra',1,1],['faca_cacador',1,1],['armadura_couro',1,1],['capacete_couro',1,1],['botas_ferro',1,1],['escudo',1,1],['polvora',1,5],['b_vidro',4,12],['b_lampada',2,6],['isqueiro',1,1],['bussola',1,1],['pocao_velocidade',1,2],['barco',1,1],['b_tnt',1,3]],
 [['lingote',3,8],['ouro',2,6],['cristal',1,3],['diamante',1,2],['esmeralda',1,3],['pocao',1,3],['ensopado',1,2],['flecha',16,30],['moeda',30,80],['espada_ferro',1,1],['machado_guerra',1,1],['picareta_ferro',1,1],['armadura_ferro',1,1],['capacete_ferro',1,1],['calca_ouro',1,1],['besta',1,1],['luneta',1,1],['mapa_tesouro',1,1],['pocao_forca',1,2],['b_tnt',2,5]],
 [['diamante',3,7],['espada_diamante',1,1],['picareta_diamante',1,1],['armadura_diamante',1,1],['capacete_cristal',1,1],['botas_diamante',1,1],['espada_cristal',1,1],['nucleo_golem',1,1],['moeda',80,200],['pocao',2,4],['esmeralda',3,8]]];
const ARMAS_CHAO=[['faca','espada_madeira','machado_madeira','picareta_madeira','pa_madeira','enxada_madeira'],['faca_cacador','espada_pedra','lanca','arco','machado_pedra','picareta_pedra','pa_pedra','vara_pesca','tesoura','escudo'],['espada_ferro','machado_guerra','arco','picareta_ferro','besta','martelo','capacete_ferro','luneta']];
const ITENS_SOLTOS=[['maca',1,3],['pao',1,1],['flecha',4,9],['atadura',1,1],['moeda',3,15],['cenoura',1,3],['batata',1,3],['sementes',2,5],['carvao',2,5],['linha',1,3],['osso',1,3],['pena',2,4],['b_la_vermelha',2,6],['b_lampada',1,2],['polvora',1,3],['couro',1,2],['frutas',2,5]];
const nivelDe=(x,z)=>{const d=Math.hypot(x,z);return d<250?0:d<600?1:2};
function saquear(nivel,n,al=rnd){const l=[],pool=SAQUE[nivel];for(let t=0;l.length<n&&t<40;t++){const[id,a,b]=pool[al()*pool.length|0];if(!l.some(s=>s[0]===id))l.push([id,a+Math.floor(al()*(b-a+1))])}return l}
const pertoCh=()=>ATUAL?ATUAL.k:null;
function addBau(id,x,z,a,itens,y,extra){if(ES.baus[id])itens=ES.baus[id];const b=Object.assign({id,x,z,a,y:y??altura(x,z),itens,aberto:!!ES.baus[id],rar:0,ch:pertoCh()},extra);if(!b.fundo)circulo(x,z,.6,1);M.baus.push(b);return b}
function addChao(id,item,q,x,z,y){if(ES.pegos[id])return;M.chao.push({id,item,q,x,z,y:y??Math.max(altura(x,z),0),pego:false,ch:pertoCh()})}

// ---------- plantas e vegetação ----------
function novoRecurso(tipo,x,z,s,a,listas,tom){const def=RECURSOS[tipo],h=altura(x,z)-.05;if(mexido(x,z)&&!solidoT(x,h-.3,z))return;const l=listas[tipo]||(listas[tipo]=[]),k=l.length/6;l.push(x,h,z,s,a,tom);if(!def){ATUAL?.miudos.push([tipo,k,x,h,z,1]);return}
 const ch=ATUAL,r={id:`${ch.k}:${ch.recursos.length}`,tipo,x,y:h,z,s,a,tom,ch,k,hp:def.hp,morto:false,col:null};ch.recursos.push(r);if(def.raio)r.col=circulo(x,z,def.raio*s,3*s);if(ES.removidos[r.id]){r.morto=true;if(r.col)r.col.morto=true;l[k*6+3]=0}}
function alternarRecurso(r,vivo){r.morto=!vivo;if(r.col)r.col.morto=!vivo;r.hp=RECURSOS[r.tipo].hp;const m=r.ch.itens[r.tipo];if(!m)return;gl.bindBuffer(gl.ARRAY_BUFFER,m.ibuf);gl.bufferSubData(gl.ARRAY_BUFFER,r.k*24+12,new Float32Array([vivo?r.s:0]))}
function recursosPerto(raio=6){const l=[];if(CAV)return l;for(let a=Math.floor((P.x-raio)/BLOCO);a<=Math.floor((P.x+raio)/BLOCO);a++)for(let b=Math.floor((P.z-raio)/BLOCO);b<=Math.floor((P.z+raio)/BLOCO);b++){const ch=M.chunks.get(a+','+b);if(ch)for(const r of ch.recursos)if(!r.morto&&Math.abs(r.x-P.x)<raio+2&&Math.abs(r.z-P.z)<raio+2)l.push(r)}return l}
function vegetar(ch){const x0=ch.cx*BLOCO,z0=ch.cz*BLOCO,listas={},meio=[x0+25,z0+25],regs=vizinhas(...meio),vilas=regs.map(r=>r.vila).filter(Boolean);
 const pertoVila=(x,z,d)=>vilas.some(v=>Math.hypot(v.x-x,v.z-z)<d),perto=(x,z,t,d)=>regs.some(r=>r[t]&&Math.hypot(r[t].x-x,r[t].z-z)<d);
 const espalhar=(qtd,tipoDe,esc)=>{for(let k=0;k<qtd;k++){const x=x0+rnd()*BLOCO,z=z0+rnd()*BLOCO,h=altura(x,z),d=Math.hypot(x,z),s=entre(...esc),a=rnd()*TAU,tom=entre(.84,1.15),sort=rnd(),tipo=tipoDe(x,z,h,d,sort);if(!tipo||Math.max(Math.abs(x),Math.abs(z))>M.MEIO)continue;
  const miudo=tipo==='capim'||tipo==='flor';if(!miudo&&(pertoVila(x,z,34)||d<15||perto(x,z,'caverna',7)))continue;if(miudo&&pertoVila(x,z,13))continue;novoRecurso(tipo,x,z,s,a,listas,tom)}};
 const ok=(h,d)=>h>.7&&h<24&&d>22;
 espalhar(62,(x,z,h,d,r)=>{if(!ok(h,d))return;const b=bioma(x,z),mata=ruido(x*.03+40,z*.03+11);if(b==='deserto')return r<.1?'cacto':null;if(b==='neve')return r<mata*.65?'pinheiro_neve':null;if(b==='savana')return r<.09?'seca':null;if(h>13)return r<.4?'pinheiro':null;
  if(b==='pinheiral')return r<smooth(.2,.75,mata)+.15?'pinheiro':null;if(b==='betulas')return r<.38?(r<.3?'betula':'carvalho'):null;if(b==='campina')return r<.035?'carvalho':null;return r<smooth(.25,.75,mata)*.7?(r%.1<.07?'carvalho':'pinheiro'):null},[.85,1.45]);
 espalhar(6,(x,z,h,d)=>d>18&&h>-2&&h<34?'pedra':null,[.5,1.5]);
 espalhar(18,(x,z,h,d,r)=>{const b=bioma(x,z);return ok(h,d)&&b!=='neve'&&b!=='deserto'?(r<.2?'fruteira':'arbusto'):null},[.6,1.25]);
 espalhar(12,(x,z,h,d,r)=>h>.3&&h<9&&d>12&&r<(h<2?.8:.2)&&bioma(x,z)!=='deserto'?'junco':null,[.7,1.1]);
 espalhar(380,(x,z,h,d,r)=>{const b=bioma(x,z);return h>.35&&h<20&&d>6&&b!=='deserto'&&(b!=='neve'||r<.12)?'capim':null},[.6,1.35]);
 espalhar(34,(x,z,h)=>{const b=bioma(x,z);return h>.5&&h<12&&b!=='neve'&&b!=='deserto'&&ruido(x*.06+70,z*.06)>(b==='campina'?.3:.58)?'flor':null},[.7,1.2]);
 espalhar(8,(x,z,h,d)=>h>.6&&h<14&&d>14&&['carvalhal','pinheiral'].includes(bioma(x,z))?'cogumelo':null,[.8,1.4]);
 espalhar(2,(x,z,h,d,r)=>ok(h,d)&&r<.08&&bioma(x,z)!=='deserto'&&bioma(x,z)!=='neve'?'abobora_pe':null,[.8,1.2]);
 // veios de serras e pedreiras: dependem só da posição da característica
 const veios=(c,raio,qtd,tipo,sal)=>{const guardado=estadoRnd;semearLocal(Math.round(c.x),Math.round(c.z),sal);const l=[];for(let k=0;k<qtd;k++){const a=rnd()*TAU,d=raio*(.1+rnd()*.9);l.push([c.x+Math.cos(a)*d,c.z+Math.sin(a)*d,.75+rnd()*.45,rnd()*TAU])}estadoRnd=guardado;
  for(const[x,z,s,a]of l)if(x>=x0&&x<x0+BLOCO&&z>=z0&&z<z0+BLOCO&&altura(x,z)>.5)novoRecurso(tipo,x,z,s,a,listas,1)};
 for(const r of regs){const s=r.serra;if(s){veios(s,s.r*.85,12,'carvao_no',7);veios(s,s.r*.75,10,'ferro_no',19);veios(s,s.r*.5,6,'ouro_no',31);veios(s,s.r*.3,5,'cristal_no',47);veios(s,s.r*.22,3,'diamante_no',53);veios(s,s.r,14,'pedra',59)}
  const p=r.pedreira;if(p){veios(p,13,7,'pedra',5);veios(p,13,5,'carvao_no',13);veios(p,13,5,'ferro_no',23);if(p.i)veios(p,12,2,'ouro_no',37)}}
 for(const v of vilas){const r=v.roca;for(let i=-2;i<=2;i++)for(let j=-1;j<=1;j++){const[x,z]=girar(r.x,r.z,r.a,i*1.8,j*1.8);if(x>=x0&&x<x0+BLOCO&&z>=z0&&z<z0+BLOCO)novoRecurso('trigo',x,z,1,(i*j)%3,listas,1)}}
 for(const t in listas){ch.itens[t]=instanciar(modelos[t],listas[t])}}

// ---------- estruturas ----------
function construirVila(g,v){const y=v.y;semearLocal(Math.round(v.x),Math.round(v.z),9);
 const por=(geo,lx,lz,a=0,col)=>{const x=v.x+lx,z=v.z+lz;g.junta(geo,x,y,z,a);if(col)circulo(x,z,col,2);return{x,z,ch:pertoCh()}};
 por(GEO.poco,0,0,0,1.35);const f=por(GEO.fogueira,5,2.5,0,.8);M.estacoes.push({tipo:'fogo',...f});M.luzes.push({...f,y:y+1,i:1.5});
 const b=por(GEO.bancada,-5,2.5,.3);paredeCol(b.x,b.z,.8,.55,.3,1.1);M.estacoes.push({tipo:'bancada',...b});
 const bc=por(GEO.banca,1,-7.5);paredeCol(bc.x,bc.z,1.35,.65,0,1.2);por(GEO.bigorna,-7.5,-4,.5,.55);
 for(const[lx,lz]of[[8.5,8.5],[-8.5,8.5],[8.5,-8.5],[-8.5,-8.5]]){const p=por(GEO.poste,lx,lz,0,.2);M.luzes.push({...p,y:y+2.5,i:1.1})}
 const r=v.roca;for(const[lx,lz,ra]of[[-4,-3.8,0],[0,-3.8,0],[4,-3.8,0],[-5.2,-1.8,Math.PI/2],[5.2,-1.8,Math.PI/2],[-5.2,1.2,Math.PI/2],[5.2,1.2,Math.PI/2]]){const[x,z]=girar(r.x,r.z,r.a,lx,lz);g.junta(GEO.cerca,x,y,z,r.a+ra);paredeCol(x,z,1,.12,r.a+ra,1.2)}
 v.casas.forEach((c,k)=>{construirCasa(v,c,y,k);const cama=girar(c.x,c.z,c.a,-1.5,-1.1);g.junta(GEO.cama,cama[0],y+.07,cama[1],c.a);paredeCol(cama[0],cama[1],.68,1.18,c.a,.9);M.camas.push({x:cama[0],z:cama[1],vila:v.i,ch:pertoCh()});
  if(k%2===0){const p=girar(c.x,c.z,c.a,1.7,-1.85);addBau(`V${v.i}:${k}`,p[0],p[1],c.a,saquear(nivelDe(v.x,v.z),inteiro(2,4)),y+.08)}})}
function construirCasa(v,c,y,k){semearLocal(Math.round(c.x),Math.round(c.z),19);const r=Math.round(c.a/(Math.PI/2))&3;
 porPlano(`${Math.floor(v.x/BLOCO)},${Math.floor(v.z/BLOCO)}`,planoCasa(7,7,3,{parede:escolher(['tabuas','tijolo','pedregulho','tijolo_claro','tabuas_betula','calcario','tijolo_calcario']),canto:escolher(['tronco','tronco_escuro','tronco_pinho']),telha:escolher(['telha_vermelha','telha_azul','telha_verde','telha_barro','telhado_madeira','telha_preta']),piso:escolher(['tabuas','tabuas_escuro','parquet','piso_xadrez']),vidro:escolher(['vidro','vidro','vidro_amarelo','vidro_azul_claro'])}),Math.floor(c.x),y,Math.floor(c.z),r)}
function construirAcampamento(g){const y=3;g.junta(GEO.fogueira,0,y,0);g.junta(GEO.tenda,-5,y,-4.5,.35);g.junta(GEO.tronco_banco,3.6,y,1.2,1.4);g.junta(GEO.tronco_banco,-1,y,3.8,.1);
 circulo(0,0,.9,1);circulo(-5,-4.5,1.7,2.4);circulo(3.6,1.2,.8,.7);circulo(-1,3.8,.9,.7);M.estacoes.push({tipo:'fogo',x:0,z:0,ch:pertoCh()});M.luzes.push({x:0,y:4,z:0,i:1.9,ch:pertoCh()});M.camas.push({x:-5,z:-2.4,acampamento:true,ch:pertoCh()});
 addBau('camp',-1.9,-2.6,.55,[['faca',1],['pao',3],['atadura',2],['tocha',4],['b_tabuas',16]]);addChao('camp-espada','espada_madeira',1,8,-6)}
function construirRuina(g,p){semearLocal(Math.round(p.x),Math.round(p.z),11);const{x,z}=p,nivel=Math.min(2,nivelDe(x,z)+1),r=entre(5,7),fase=rnd()*TAU;
 for(let i=0;i<9;i++){if(rnd()<.28||i===0)continue;const a=fase+i/9*TAU,px=x+Math.sin(a)*r,pz=z+Math.cos(a)*r,alt=entre(.35,1),w=new Geo();for(let q=0;q<4;q++){const h=alt*(q%2?2.7:2.1)*entre(.7,1.1);w.caixa(-1.2+q*.8,h/2-.4,0,.76,h+.4,.55,[.46,.48,.44].map(v=>v*entre(.75,1.1)));if(rnd()<.4)w.caixa(-1.2+q*.8,h+.02,0,.8,.1,.6,[.22,.4,.14])}g.junta(w,px,altura(px,pz),pz,a);paredeCol(px,pz,1.6,.3,a,alt*2.2)}
 for(let i=0;i<7;i++){const px=x+entre(-r,r),pz=z+entre(-r,r);g.bola(px,altura(px,pz)+.1,pz,entre(.2,.6),.25,entre(.2,.5),COR.pedra,0,.4)}
 addBau('R'+p.i,x,z,fase,saquear(nivel,inteiro(4,5)),undefined,{rar:1});if(rnd()<.75)addChao('Ra'+p.i,escolher(ARMAS_CHAO[nivel]),1,x+2,z+1)}
function construirEntrada(g,p){const{x,z}=p,d=p.dir||0;semearLocal(Math.round(x),Math.round(z),13);
 const por=(lado,tras,f)=>{const px=x+Math.cos(d)*lado-Math.sin(d)*tras,pz=z-Math.sin(d)*lado-Math.cos(d)*tras;f(px,altura(px,pz),pz)};
 for(let i=0;i<9;i++){const s=i%2?1:-1;por(s*entre(3.6,5.4),entre(-5,3),(px,y,pz)=>{if(!mexido(px,pz)||solidoT(px,y-.4,pz))g.bola(px,y+.3,pz,entre(.6,1.2),entre(.6,1.5),entre(.6,1.2),[.4,.41,.42],0,.3)})}
 for(const s of[-1,1])por(s*3.4,2.5,(px,y,pz)=>{g.junta(GEO.poste,px,y,pz);circulo(px,pz,.2,2);M.luzes.push({x:px,y:y+2.4,z:pz,i:1.1,ch:pertoCh()})})}

// ---------- sorteios aleatórios por pedaço (gravados no salvamento) ----------
function sortear(ch){let s=ES.sorteios[ch.k];const x0=ch.cx*BLOCO,z0=ch.cz*BLOCO;
 if(s===undefined){s=0;const livre=()=>{for(let t=0;t<8;t++){const x=x0+4+Math.random()*42,z=z0+4+Math.random()*42,h=altura(x,z);if(h>.8&&h<24&&Math.hypot(x,z)>35&&!M.refugios.some(r=>Math.hypot(r.x-x,r.z-z)<r.r+6)&&Math.max(Math.abs(x),Math.abs(z))<M.MEIO-40)return[Math.round(x*10)/10,Math.round(z*10)/10]}return null};
  const o={};if(Math.random()<.11){const p=livre();if(p){const q=Math.random(),rar=q<.05?2:q<.27?1:0,nv=rar===2?3:Math.min(2,nivelDe(...p)+rar);o.b=[...p,rar,saquear(nv,rar+2+(Math.random()*2|0),Math.random)]}}
  const itens=[];if(Math.random()<.34)for(let k=0;k<1+(Math.random()*2|0);k++){const p=livre();if(!p)continue;if(Math.random()<.28)itens.push([qualquer(ARMAS_CHAO[nivelDe(...p)]),1,...p]);else{const[id,a,b]=qualquer(ITENS_SOLTOS);itens.push([id,sorte(a,b),...p])}}
  if(itens.length)o.i=itens;if(o.b||o.i)s=o;ES.sorteios[ch.k]=s}
 if(s&&s.b){const[x,z,rar,itens]=s.b;addBau('S'+ch.k,x,z,(x*7)%TAU,itens,undefined,{rar})}
 if(s&&s.i)s.i.forEach(([id,q,x,z],k)=>{if(ITENS[id])addChao(`S${ch.k}:${k}`,id,q,x,z)})}

// ---------- terreno e água do pedaço ----------
function corChao(x,z,h,incl){const b=bioma(x+(ruido(x*.08,z*.08)-.5)*22,z+(ruido(x*.08+33,z*.08)-.5)*22),Pl=CORES_BIOMA[b];let c=mix(Pl[0],Pl[1],ruido(x*.045,z*.045));
 if(b!=='neve'&&b!=='deserto')c=mix(c,[.31,.23,.12],smooth(.6,.82,ruido(x*.09+20,z*.09+5))*.75);c=mix(c,[.4,.4,.37],smooth(.6,1.1,incl));c=mix(c,[.36,.38,.35],smooth(14,22,h));c=mix(c,[.82,.86,.9],smooth(31,40,h));
 c=mix(c,[.72,.63,.42],1-smooth(.35,1.3,h));c=mix(c,[.16,.28,.22],1-smooth(-3,-.1,h));c=mix(c,[.43,.31,.18],1-smooth(5,13,Math.hypot(x,z)));
 for(const r of vizinhas(x,z)){const p=r.pedreira;if(p)c=mix(c,[.42,.38,.32],(1-smooth(8,16,Math.hypot(x-p.x,z-p.z)))*.85);const v=r.vila;if(!v)continue;const d=Math.hypot(x-v.x,z-v.z);if(d>42)continue;c=mix(c,[.5,.39,.23],1-smooth(8,12,d));if(Math.hypot(x-v.roca.x,z-v.roca.z)<5.5)c=[.32,.2,.11];
  for(const k of v.casas){const dx=k.porta[0]-v.x,dz=k.porta[1]-v.z,t=clamp(((x-v.x)*dx+(z-v.z)*dz)/(dx*dx+dz*dz),0,1);const dd=Math.hypot(x-v.x-dx*t,z-v.z-dz*t);if(dd<2.4)c=mix(c,[.55,.44,.28],1-smooth(1.2,2.4,dd))}}
 return c.map(v=>v*(.94+hash(Math.round(x/PASSO),Math.round(z/PASSO))*.12))}
function malhaTerreno(ch){const x0=ch.cx*BLOCO,z0=ch.cz*BLOCO,N=CEL+1,H=alturas(ch.cx,ch.cz),V=[],mapa=document.createElement('canvas');mapa.width=mapa.height=CEL;const gm=mapa.getContext('2d'),im=gm.createImageData(CEL,CEL);
 // oclusão suave sob as árvores
 const sombra=new Float32Array(N*N).fill(1);for(const r of ch.recursos)if(RECURSOS[r.tipo].ferr==='machado'&&r.s>1&&!r.morto){const i=Math.round((r.x-x0)/PASSO),j=Math.round((r.z-z0)/PASSO);for(let a=-1;a<=1;a++)for(let b=-1;b<=1;b++){const q=(j+b)*N+i+a;if(i+a>=0&&i+a<N&&j+b>=0&&j+b<N)sombra[q]=Math.max(.66,sombra[q]*(a||b?.93:.85))}}
 for(let j=0;j<N;j++)for(let i=0;i<N;i++){const x=x0+i*PASSO,z=z0+j*PASSO,h=H[j*N+i],dx=(i<CEL?H[j*N+i+1]:altura(x+PASSO,z))-(i>0?H[j*N+i-1]:altura(x-PASSO,z)),dz=(j<CEL?H[(j+1)*N+i]:altura(x,z+PASSO))-(j>0?H[(j-1)*N+i]:altura(x,z-PASSO)),l=Math.hypot(dx,2*PASSO,dz),c=corChao(x,z,h,Math.hypot(dx,dz)/(2*PASSO)).map(v=>v*sombra[j*N+i]);
  V.push([x,h,z,-dx/l,2*PASSO/l,-dz/l,...c,2]);if(i<CEL&&j<CEL){const m=h<0?[.13,.34,.46]:c.map(v=>v*clamp(1+h*.01,.85,1.15));im.data.set([m[0]*255,m[1]*255,m[2]*255,255],(j*CEL+i)*4)}}
 const d=new Float32Array(CEL*CEL*60);let o=0;for(let j=0;j<CEL;j++)for(let i=0;i<CEL;i++){const a=j*N+i;for(const q of[a,a+N,a+1,a+1,a+N,a+N+1]){d.set(V[q],o);o+=10}}
 ch.chao=malha(d);gm.putImageData(im,0,0);ch.mapa=mapa;
 const w=[];for(let j=0;j<CEL;j++)for(let i=0;i<CEL;i++){const q=j*N+i;if(Math.min(H[q],H[q+1],H[q+N],H[q+N+1])>.15)continue;const x=x0+i*PASSO,z=z0+j*PASSO;
  for(const[a,b]of[[0,0],[0,1],[1,0],[1,0],[0,1],[1,1]])w.push(x+a*PASSO,0,z+b*PASSO,0,1,0,0,0,0,-H[(j+b)*N+i+a])}
 ch.agua=w.length?malha(new Float32Array(w)):null;ch.temAgua=!!w.length}

// ---------- carregar e descarregar ----------
function carregar(cx,cz){const k=cx+','+cz,ch={cx,cz,k,x:cx*BLOCO+25,z:cz*BLOCO+25,cols:[],recursos:[],itens:{},chao:null,agua:null,estrut:null,miudos:[]};M.chunks.set(k,ch);ATUAL=ch;M.vizK=null;
 semearLocal(cx,cz,1);vegetar(ch);const g=new Geo(),dentro=p=>p&&Math.floor(p.x/BLOCO)===cx&&Math.floor(p.z/BLOCO)===cz;
 if(cx===0&&cz===0)construirAcampamento(g);
 for(const r of[...vizinhas(ch.x,ch.z)]){if(dentro(r.vila)){construirVila(g,r.vila);povoarVila(r.vila,k)}if(dentro(r.ruina))construirRuina(g,r.ruina);if(dentro(r.caverna))construirEntrada(g,r.caverna)}
 if(g.v.length)ch.estrut=g.malha();sortear(ch);for(const s of ES.suprimentos)if(dentro({x:s[1],z:s[2]}))addBau(s[0],s[1],s[2],0,s[4],undefined,{rar:s[3]});
 malhaTerreno(ch);ATUAL=null;faunaDoChunk(ch)}
function descarregar(ch){tirarCols(ch.cols);for(const n of['estacoes','luzes','camas','baus','chao','entradas'])M[n]=M[n].filter(o=>o.ch!==ch.k);
 for(const m of[ch.chao,ch.agua,ch.estrut,...Object.values(ch.itens)])if(m)apagarMalha(m);seres=seres.filter(e=>e.ch!==ch.k||e.manso);tirarEstrutura(ch.k);M.chunks.delete(ch.k)}
function atualizarMundo(limite){const R=Math.ceil((CFG.dist+20)/BLOCO),cx=Math.floor(P.x/BLOCO),cz=Math.floor(P.z/BLOCO),falta=[],L=Math.ceil(M.MEIO/BLOCO);
 for(let a=-R;a<=R;a++)for(let b=-R;b<=R;b++){const i=cx+a,j=cz+b;if(a*a+b*b>(R+.5)**2||i<-L||i>=L||j<-L||j>=L||M.chunks.has(i+','+j))continue;falta.push([a*a+b*b,i,j])}
 falta.sort((a,b)=>a[0]-b[0]);const t0=performance.now();for(let n=0;n<falta.length&&n<limite;n++){carregar(falta[n][1],falta[n][2]);if(limite<50&&performance.now()-t0>12)break}
 if(limite<50)for(const ch of[...M.chunks.values()])if(Math.hypot(ch.cx-cx,ch.cz-cz)>R+1.8){descarregar(ch);break}}
