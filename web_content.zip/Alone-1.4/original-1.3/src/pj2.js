// ---------- uso e interação ----------
function alvoUso(){const l=[],it=naMao(),add=(tipo,o,x,z,r,rotulo,peso=0)=>l.push({tipo,o,x,z,r,rotulo,peso}),perto=(o,d=5)=>Math.abs(o.x-P.x)<d&&Math.abs(o.z-P.z)<d&&dist2(o.x,o.z,P.x,P.z)<d;
 for(const e of seres){if(e.morte||P.montaria===e||!perto(e)||Math.abs(e.y-pes())>3)continue;
  if(e.npc)add('npc',e,e.x,e.z,.7,`Falar com ${e.npc.nome}`,-.8);else if(e.tipo==='barco'&&P.barco!==e)add('barco',e,e.x,e.z,1.2,'Entrar no barco',-.4);
  else if(interacaoBicho(e,it)){const[t,r,p]=interacaoBicho(e,it);add(t,e,e.x,e.z,e.def.raio,r,p)}else if(e.manso&&e.tipo==='lobo')add('pet',e,e.x,e.z,.7,e.sentado?'Chamar seu lobo':'Mandar o lobo esperar',-.3);
  else if(e.tipo==='lobo'&&it?.id==='osso'&&!e.manso)add('domar',e,e.x,e.z,.8,'Oferecer um osso',-.9);
  else if(e.tipo==='ovelha'&&it?.id==='tesoura'&&!e.tosada)add('tosar',e,e.x,e.z,.8,'Tosquiar',-.9);else if(e.tipo==='vaca'&&it?.id==='balde')add('ordenhar',e,e.x,e.z,.9,'Ordenhar',-.9)}
 for(const b of M.baus)if(perto(b)&&Math.abs(b.y-pes())<3.5)add('bau',b,b.x,b.z,.7,b.rar>1?'Abrir baú raro':'Abrir baú',-.5);
 for(const c of construcoes)if(perto(c)&&Math.abs(c.y-pes())<3){if(c.tipo==='bau')add('bau',c,c.x,c.z,.7,'Abrir seu baú',-.5);if(c.tipo==='porta')add('porta',c,c.x,c.z,.8,c.aberto?'Fechar porta':'Abrir porta',-.3);if(c.tipo==='farol')add('farol',c,c.x,c.z,1.4,'Farol aceso')}
 for(const c of M.camas)if(perto(c)&&Math.abs(soloTopo(c.x,c.z)-pes())<4)add('cama',c,c.x,c.z,.9,'Dormir',.2);
 for(const s of M.estacoes)if(perto(s))add('estacao',s,s.x,s.z,.8,s.tipo==='bancada'?'Usar mesa de artesanato':'Cozinhar na fogueira',.3);
 for(const p of ES.plantas)if(p.t&&p.i>=1&&perto(p,4))add('colher',p,p.x,p.z,.5,'Colher plantação',-.4);
 if(!it||it.cat!=='cubo')for(const r of recursosPerto())if(RECURSOS[r.tipo].coletar&&Math.abs(r.y-pes())<3.5)add('coletar',r,r.x,r.z,.6,`Colher: ${RECURSOS[r.tipo].n.toLowerCase()}`,.1);
 {const v=portaNaMira();if(v)add('portavox',v,v.x+.5,v.z+.5,.8,(v.v>>10&15)===FM.porta?'Abrir porta':'Fechar porta',-1)}
 const[fx,fz]=frente();let m=null,md=1e9;for(const a of l){const dx=a.x-P.x,dz=a.z-P.z,d=Math.hypot(dx,dz),dot=d?(dx*fx+dz*fz)/d:1;if(d-a.r>2.4||(dot<.6&&d>a.r+.6))continue;const n=d-dot*1.4+a.peso;if(n<md){md=n;m=a}}return m}
function usar(){if(estado!=='jogando')return;if(P.pesca){puxarLinha();return}if(planta){erguerPlanta();return}const a=alvoUso();
 if(!a){if(P.barco&&!naMao()){sairBarco();return}usarItem();return}const o=a.o;
 if(a.tipo==='portavox')alternarPorta(o);else if(['montar','domar2','alimentar'].includes(a.tipo))usarBicho(a.tipo,o);else if(a.tipo==='npc')conversar(o);else if(a.tipo==='bau')abrirBau(o);else if(a.tipo==='cama')dormir(a);else if(a.tipo==='coletar'){P.golpe=1;coletar(o)}else if(a.tipo==='estacao')abrirPainel('criar');
 else if(a.tipo==='porta'){o.aberto=!o.aberto;o.folha.morto=o.aberto;som('porta')}else if(a.tipo==='farol')avisar('O farol brilha sobre o mundo.');
 else if(a.tipo==='barco'){P.barco=o;P.voando=false;som('madeira');avisar('Avance para remar. Pule para sair.',4)}else if(a.tipo==='pet'){o.sentado=!o.sentado;som('latido')}
 else if(a.tipo==='domar'){gastar();P.golpe=1;if(Math.random()<.5){o.manso=true;o.ch=undefined;o.raiva=0;o.corpo=CORPOS.lobo_manso;o.hp=o.max=60;som('latido');contar('domou','lobo');avisar('O lobo agora é seu companheiro!',4)}else{faisca(o.x,o.y+1,o.z,[.6,.6,.6],8,.15);avisar('Ele ainda desconfia. Tente outro osso.',2.5)}}
 else if(a.tipo==='tosar'){P.golpe=1;o.tosada=120;pegar('la',sorte(2,3));som('tesoura')}else if(a.tipo==='ordenhar'){P.golpe=1;trocarItem('balde_leite');som('agua')}
 else if(a.tipo==='colher'){P.golpe=1;if(o.t==='trigo'){pegar('trigo',sorte(2,3));pegar('sementes',sorte(1,2))}else pegar(o.t,sorte(2,4));o.t=null;o.i=0}}
const PLANTIO={sementes:'trigo',cenoura:'cenoura',batata:'batata'};
function pontoLivre(max=6){const v=raioVox([P.x,P.y,P.z],dirOlhar(),max),t=raioTerreno(v?v.t:max);if(t)return{x:t.x,y:t.y,z:t.z};if(v){const x=v.x+v.nx+.5,y=v.y+v.ny,z=v.z+v.nz+.5;return{x,y,z}}return null}
function usarItem(){const it=naMao();if(!it)return;const id=it.id;
 if(it.cat==='cubo'){colocarBloco();return}if(it.cat==='bloco'){colocarObra();return}
 if(PLANTIO[id]){const t=raioTerreno(5),p=t&&ES.plantas.find(p=>!p.t&&dist2(p.x,p.z,t.x,t.z)<.9);if(p){p.t=PLANTIO[id];p.i=0;gastar();P.golpe=1;som('passo');contar('plantou',p.t);return}if(id==='sementes'){avisar('Prepare a terra com uma enxada e plante nela',2.5);return}}
 if(it.cat==='comida'){comer(P.sel);return}
 if(it.cat==='armadura'){equipar(P.sel);return}
 if(it.cat==='ovo'){const p=pontoLivre(10);if(!p){avisar('Mire no chão');return}const e=criar(it.mob,p.x,p.z,{y:p.y+.05,fundo:profundidade(p.x,p.y,p.z)>4});if(it.mob==='golem'){e.manso=true;e.posto={x:p.x,z:p.z}}if(it.mob==='peixe')e.corpo=CORPOS.peixe;gastar();P.golpe=1;som('pegar');return}
 if(id==='tocha'){const c=celulaAlvo();if(!c){avisar('Mire no chão para fixar a tocha',2);return}if(solidoVox(c.x,c.y,c.z))return;const x=c.x+.5,z=c.z+.5,y=solidoVox(c.x,c.y-1,c.z)?c.y:solo(x,z,c.y+1);
  if(construcoes.some(o=>o.tipo==='tocha'&&dist2(o.x,o.z,x,z)<.5&&Math.abs(o.y-y)<.8))return;addConstrucao({tipo:'tocha',x,y,z,a:0});gastar();P.golpe=1;som('fogo');return}
 if(it.ferramenta==='enxada'){const t=raioTerreno(5);if(!t||profundidade(t.x,t.y,t.z)>.8)return;const x=Math.floor(t.x)+.5,z=Math.floor(t.z)+.5,h=altura(x,z);if(h<.5||h>20||['deserto','neve'].includes(bioma(x,z))){avisar('Essa terra não serve para plantar',2);return}
  if(ES.plantas.some(p=>dist2(p.x,p.z,x,z)<.9)||M.vilas.some(v=>dist2(v.x,v.z,x,z)<31)){avisar('Escolha outro lugar',2);return}ES.plantas.push({x,z,t:null,i:0});P.golpe=1;som('passo');faisca(x,h+.2,z,[.4,.28,.15],8,.15);if(Math.random()<.2)pegar('sementes',1);return}
 if(id==='balde'){const v=raioVox([P.x,P.y,P.z],dirOlhar(),5,true);if(v&&ehAgua(v.n)){if(v.n===NB_.agua0)definirBloco(v.x,v.y,v.z,0);trocarItem('balde_agua');som('agua')}else if(raioAguaMar(5)){trocarItem('balde_agua');som('agua')}else avisar('Mire na água',2);return}
 if(id==='balde_agua'){const c=celulaAlvo();if(!c||solidoVox(c.x,c.y,c.z))return;definirBloco(c.x,c.y,c.z,NB_.agua0);trocarItem('balde');som('agua');return}
 if(id==='balde_leite'){P.fome=Math.min(100,P.fome+20);P.efeitos={};trocarItem('balde');som('comer');avisar('Bebeu leite');return}
 if(id==='isqueiro'){const v=raioVox([P.x,P.y,P.z],dirOlhar(),5);P.golpe=1;som('fogo');if(v&&acender(v.x,v.y,v.z)){avisar('Afaste-se!',2);return}const p=pontoLivre(5);if(p)faisca(p.x,p.y+.2,p.z,[1,.6,.1],8,.12);return}
 if(id==='barco'){const w=raioAguaMar(9),v=raioVox([P.x,P.y,P.z],dirOlhar(),7,true);if(!(w||v&&ehAgua(v.n))){avisar('Mire em água aberta',2);return}if(!w){avisar('O barco precisa de um lago ou do mar',2);return}criar('barco',w.x,w.z,{y:0,manso:true,h:P.yaw+Math.PI});gastar();som('agua');return}
 if(id==='nucleo_golem'){const p=pontoLivre(7);if(!p){avisar('Mire no chão');return}criar('golem',p.x,p.z,{y:p.y+.05,manso:true,posto:{x:p.x,z:p.z},fundo:profundidade(p.x,p.y,p.z)>4});gastar();som('golem');faisca(p.x,p.y+1,p.z,[.3,1,.8],24,.3);avisar('Um golem desperta para proteger este lugar',4);return}
 if(id==='vara_pesca'){const w=raioAguaMar(14),v=raioVox([P.x,P.y,P.z],dirOlhar(),12,true),agua=w||(v&&ehAgua(v.n)?{x:v.x+.5,y:v.y+.9,z:v.z+.5}:null);if(!agua){avisar('Lance a linha na água',2);return}P.pesca={x:agua.x,y:agua.y,z:agua.z,t:3+Math.random()*7,fisgou:0,sel:P.sel};P.golpe=1;som('agua',.5);return}
 if(id==='mapa_tesouro'){const p=lugarLivre(P.x,P.z,80,200,22);if(!p)return;P.marca={x:Math.round(p[0]),z:Math.round(p[1])};gastar();avisar(`O X marca o tesouro, a ${Math.round(dist2(...p,P.x,P.z))} m ao ${direcao(P.marca)}.`,6);som('missao',.5);return}
 if(id==='luneta'){P.zoom=!P.zoom;return}
 if(id==='bussola'){avisar(`Posição: ${Math.round(P.x)}, ${Math.round(P.z)}. Acampamento a ${Math.round(Math.hypot(P.x,P.z))} m ao ${direcao({x:0,z:0})}.`,5);return}
 if(id==='relogio'){const h=Math.floor(hora*24),m=Math.floor(hora*1440%60);avisar(`Dia ${dia}, ${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}`,4);return}
 if(id==='martelo'){const o=mirar(construcoes,3,()=>.7);if(o){P.golpe=1;desmontar(o.o)}else avisar('Mire em algo que você construiu',2)}}
function puxarLinha(){const f=P.pesca;P.pesca=null;P.golpe=1;if(f.fisgou<=0){avisar('Você recolheu a linha',1.5);return}const r=Math.random();
 const[id,q]=r<.72?['peixe_cru',1]:r<.82?[qualquer(['linha','osso','couro','b_cascalho']),sorte(1,3)]:r<.93?['moeda',sorte(5,25)]:r<.98?[qualquer(['cristal','esmeralda','pocao_agua']),1]:['mapa_tesouro',1];pegar(id,q);contar('pescou',id);som('agua')}
function sairBarco(){const b=P.barco;if(!b)return;P.barco=null;const[fx,fz]=frente();let x=b.x,z=b.z;for(let d=2.6;d>.5;d-=.5)if(altura(b.x+fx*d,b.z+fz*d)>-.2){x=b.x+fx*d;z=b.z+fz*d;break}P.x=x;P.z=z;P.y=Math.max(altura(x,z),b.y+.3)+1.75;P.vy=4}
function abrirBau(b){if(!b.aberto){b.aberto=true;if(b.id!==undefined)contar('baus',b.id)}if(b.id!==undefined)ES.baus[b.id]=b.itens;som('bau');abrirPainel('bau',b)}
function dormir(a){const o=a.o;if(noite<.5){avisar('Você só consegue dormir à noite');if(o.vila===undefined){P.casa=[o.x,o.z];avisar('Ponto de retorno definido aqui')}return}
 if(seres.some(e=>e.def.monstro&&!e.morte&&!e.fundo&&!e.manso&&dist2(e.x,e.z,P.x,P.z)<14)){avisar('Há monstros por perto. Não dá para dormir.');return}
 if(hora>.5)novaManha();hora=.28;P.vida=Math.min(100,P.vida+40);if(!criativo())P.fome=Math.max(5,P.fome-12);P.casa=[P.x,P.z];seres.forEach(e=>{if(e.def.monstro&&!e.manso)e.sumir=true});avisar(`Bom dia. Dia ${dia}.`);salvar()}
function novaManha(){dia++;contar('noites',dia);for(const id in ES.removidos){if(dia<ES.removidos[id])continue;const[k,n]=id.split(':'),ch=M.chunks.get(k),r=ch&&ch.recursos[+n];if(r&&(dist2(r.x,r.z,P.x,P.z)<35||mexido(r.x,r.z)&&!solidoT(r.x,r.y-.3,r.z)))continue;delete ES.removidos[id];if(r)alternarRecurso(r,true)}
 for(const v of M.vilas){const k=Math.floor(v.x/BLOCO)+','+Math.floor(v.z/BLOCO);if(M.chunks.has(k)&&!seres.some(e=>e.tipo==='golem'&&e.vila===v&&!e.morte)){criar('golem',v.x+3.5,v.z+6.5,{ch:k,vila:v,posto:{x:v.x,z:v.z}});delete ES.cavernas['g'+v.i]}}}

// ---------- baús de suprimentos que surgem pelo mapa ----------
function emChunk(x,z,f){const ch=M.chunks.get(Math.floor(x/BLOCO)+','+Math.floor(z/BLOCO));if(!ch)return;const antes=ATUAL;ATUAL=ch;f(ch);ATUAL=antes}
function cairSuprimento(x,z,rar,motivo){const id=`E${dia}_${Math.random()*1e6|0}`,itens=saquear(Math.min(3,rar+1),3+rar,Math.random);ES.suprimentos.push([id,x,z,rar,itens]);
 while(ES.suprimentos.length>8){const[velho]=ES.suprimentos.shift();delete ES.baus[velho];M.baus=M.baus.filter(b=>b.id!==velho)}
 emChunk(x,z,()=>addBau(id,x,z,0,itens,undefined,{rar}));faisca(x,altura(x,z)+1,z,[1,.9,.3],30,.4);avisar(motivo,6);som('missao',.5)}

// ---------- física do jogador ----------
function nivelAgua(x,y,z){const n=bloco(Math.floor(x),Math.floor(y),Math.floor(z));if(n&&ehAgua(n))return true;const h=altura(x,z);return h<0&&y>h-1&&y<onda(x,z,tempo)&&!solidoVox(Math.floor(x),Math.floor(y),Math.floor(z))&&!solidoT(x,y,z)}
const chaoJogador=(x,z,y)=>{let t=-1e9;for(const[a,b]of[[0,0],[.2,0],[-.2,0],[0,.2],[0,-.2]])t=Math.max(t,solo(x+a,z+b,y));return Math.max(t,chaoVox(x,z,y,.29,Math.max(8,y-t+2)))};
const livre=(x,y,z)=>!colideVox(x,y+.02,z,.3,1.76)&&!colideTerra(x,y+.6,z,.3,1.15);
function moverEixo(nx,nz){const y=pes();if(livre(nx,y,nz)){P.x=nx;P.z=nz;return true}
 if(P.noChao||P.sub)for(const d of[.3,.58])if(livre(nx,y+d,nz)&&livre(P.x,y+d,P.z)){const c=chaoJogador(nx,nz,y+d+.05);if(c>y-.05){P.x=nx;P.z=nz;P.y=Math.max(c,y)+1.7;return true}}return false}
function pularAgora(){if(P.montaria&&P.noChao){P.vy=9.5;return}if(P.barco){sairBarco();return}if(criativo()){const t=performance.now();if(t-(P.ultimoPulo||0)<320){P.voando=!P.voando;P.vy=0;avisar(P.voando?'Voo ligado':'Voo desligado',1.5)}P.ultimoPulo=t}
 if(!P.voando&&P.noChao&&P.sub<.45)P.vy=P.efeitos.salto?11:7.4}
function atualizarJogador(dt){
 let f=entrada.f,l=entrada.l;const m=Math.hypot(f,l);if(m>1){f/=m;l/=m}
 for(const k in P.efeitos)if((P.efeitos[k]-=dt)<=0){delete P.efeitos[k];avisar(`${NOME_EFEITO[k]} acabou`,2)}
 P.correndo=entrada.correr&&m>.1&&(P.fome>5||criativo());if(!criativo())P.voando=false;
 const s=Math.sin(P.yaw),c=Math.cos(P.yaw),L=M.MEIO-22;
 if(P.barco){const b=P.barco;if(b.morte){P.barco=null}else{const v=(P.correndo?12:8)*f,[fx,fz]=frente(),nx=b.x+(fx*v+c*l*3)*dt,nz=b.z+(fz*v-s*l*3)*dt;
   if(altura(nx,nz)<-.35){b.x=clamp(nx,-L,L);b.z=clamp(nz,-L,L)}if(Math.abs(v)>.5){let d=((Math.atan2(fx,fz)-b.h)%TAU+TAU*1.5)%TAU-Math.PI;b.h+=d*Math.min(1,dt*4);if(Math.random()<dt*8)faisca(b.x-fx*1.3,.15,b.z-fz*1.3,[.8,.92,1],2,.12)}
   b.y=onda(b.x,b.z,tempo)-.08;P.x=b.x;P.z=b.z;P.y=b.y+1.45;P.vy=0;P.noChao=true;P.sub=0;P.submerso=false}}
 else{
  const y=pes();let n=0;for(const h of[.15,.9,1.6])if(nivelAgua(P.x,y+h,P.z))n++;const antes=P.sub;P.sub=n/3;P.submerso=nivelAgua(P.x,P.y+.05,P.z);
  if(antes===0&&P.sub>0&&P.vy<-4){faisca(P.x,y+.4,P.z,[.75,.9,1],18,.18);som('mergulho');P.vy*=.45}
  const pulo=entrada.pular,desce=entrada.descer;
  if(P.montaria&&(desce||P.montaria.morte))descerMontaria();const mont=P.montaria?.def.montaria||1;
  const v=(P.voando?(entrada.correr?22:11):(desce&&!P.sub?2.4:P.correndo?9.2:5)*(P.efeitos.veloz?1.45:1)*(1-.42*P.sub)*mont*CFG.velJog);
  const dx=(-s*f+c*l)*v*dt,dz=(-c*f-s*l)*v*dt;let travou=false;
  const passos=Math.ceil(Math.max(Math.abs(dx),Math.abs(dz))/.25)||1;for(let i=0;i<passos;i++){if(dx&&!moverEixo(P.x+dx/passos,P.z))travou=true;if(dz&&!moverEixo(P.x,P.z+dz/passos))travou=true}
  if(!P.voando||pes()<altura(P.x,P.z)+3){let[x,z]=resolver(P.x,P.z,.33,pes()+.2);if((x!==P.x||z!==P.z)&&!colideVox(x,pes()+.02,z,.3,1.76)){P.x=x;P.z=z}}
  for(const e of seres)if(!e.morte&&e!==P.montaria&&!e.def.voa&&e.tipo!=='peixe'&&Math.abs(e.y-pes())<1.5){const ax=P.x-e.x,az=P.z-e.z,d=Math.hypot(ax,az),mi=e.def.raio*(e.escala<1?.6:1)+.22;if(d<mi&&d>.01)moverEixo(e.x+ax/d*mi,e.z+az/d*mi)}
  P.x=clamp(P.x,-L,L);P.z=clamp(P.z,-L,L);
  if(P.voando)P.vy=((pulo?1:0)-(desce?1:0))*9;
  else if(P.sub>0){P.vy-=20*(1-P.sub*1.34)*dt;P.vy*=Math.exp(-3.2*P.sub*dt);if(pulo)P.vy=Math.min(P.vy+30*dt,3.4);if(desce)P.vy=Math.max(P.vy-22*dt,-4);
   if(pulo&&travou&&P.sub<1)P.vy=6.2}
  else{P.vy-=20*dt;if(pulo&&P.noChao&&P.vy<=0)P.vy=P.efeitos.salto?11:7.4}
  if(CFG.modo==='touch'&&travou&&P.noChao&&m>.5&&!P.voando&&CFG.autoPulo&&livre(P.x-s*.6*f+c*.6*l,pes()+1.05,P.z-c*.6*f-s*.6*l))P.vy=7.4;
  P.vy=Math.max(P.vy,-38);let ny=pes()+P.vy*dt;const antesY=pes(),chao=chaoJogador(P.x,P.z,antesY+(P.noChao?.55:.06));
  if(P.vy>0&&(colideVox(P.x,ny,P.z,.3,1.8)||colideTerra(P.x,ny+.6,P.z,.28,1.2))){P.vy=0;ny=antesY}
  if(ny<=chao&&P.vy<=0){if(P.vy<-14&&!P.sub&&CFG.quedaOn)ferirJogador((-P.vy-14)*5);if(!P.noChao&&P.vy<-5)som('passo');ny=chao;P.vy=0;P.noChao=true;if(P.voando&&desce)P.voando=false}
  else if(P.noChao&&P.vy<=0&&antesY-chao<.65&&antesY-chao>0&&!P.sub){ny=chao;P.vy=0}
  else P.noChao=false;
  if(!isFinite(ny))ny=altura(P.x,P.z);if(ny<FUNDO-6){ny=altura(P.x,P.z)+1;P.vy=0}
  // se o chão fechar sobre o jogador, sobe até a saída
  if(!P.voando&&solidoT(P.x,ny+.9,P.z)){ny+=Math.min(.25,dt*6);P.vy=0}P.y=ny+1.7;
  if(m>.1&&(P.noChao||P.sub)){const a=P.passo|0;P.passo+=v*dt*.4;if((P.passo|0)!==a)som(P.sub?'agua':'passo')}
  P.andou+=Math.hypot(dx,dz);
  const b=bloco(Math.floor(P.x),Math.floor(pes()+.2),Math.floor(P.z));if(b&&BLOCOS[b].lava){P.vy*=.8;ferirJogador(30*dt);if(Math.random()<dt*10)faisca(P.x,pes()+.8,P.z,[1,.5,.1],3,.2)}}
 // fôlego
 if(P.submerso&&!criativo()){if(!P.efeitos.folego)P.ar-=dt;if(Math.random()<dt*3)faisca(P.x+frente()[0]*.4,P.y-.15,P.z+frente()[1]*.4,[.85,.95,1],1,.05);if(P.ar<=0){P.ar=0;P.vida-=7*dt;if(Math.random()<dt*2){som('ferido');$('dano').style.opacity=.5}if(P.vida<=0)morrer()}}else P.ar=Math.min(15,P.ar+dt*8);
 P.recarga-=dt;P.golpe=Math.max(0,P.golpe-dt*3.5);if(entrada.atacando)atacar();minerar(dt);
 if(criativo()){P.vida=100;P.fome=100}else{if(CFG.fomeOn)P.fome=Math.max(0,P.fome-dt*(P.correndo?.22:.12)*(CFG.dif==='pacifico'?.5:1));else P.fome=100;
  if(P.fome<=0){P.vida-=dt*1.2;if(P.vida<=0)morrer()}else if(P.fome>50&&P.vida<100&&P.vida>0)P.vida=Math.min(100,P.vida+dt*.9*CFG.regen)}
 atualizarConstrucao(dt);if(profundidade(P.x,pes(),P.z)>6&&(P.proxCam=(P.proxCam||0)-dt)<0){P.proxCam=1;const c=M.camaras.find(c=>c===M.cavernas[c.i]?.fundo&&Math.hypot(c.x-P.x,c.z-P.z)<12&&Math.abs(c.y-pes())<9);if(c&&!stats.cavernas[c.i]){contar('cavernas',c.i);avisar('Você encontrou a câmara funda de uma caverna!',5);som('caverna')}}
 const it=naMao();P.isca=it?{trigo:['ovelha','vaca'],sementes:['galinha'],cenoura:['coelho']}[it.id]:null;if(it?.id!=='luneta')P.zoom=false;
 if(P.pesca){const p=P.pesca;if(p.sel!==P.sel||it?.id!=='vara_pesca'||dist2(p.x,p.z,P.x,P.z)>20)P.pesca=null;else if(p.fisgou>0){if((p.fisgou-=dt)<=0){p.t=3+Math.random()*7;avisar('O peixe escapou…',1.5)}}else if((p.t-=dt)<=0){p.fisgou=1.6;som('mergulho',.6);faisca(p.x,p.y+.1,p.z,[.8,.92,1],12,.14);avisar('Fisgou! Use agora!',1.6)}}
 for(const g of M.chao){if(g.pego)continue;if(g.solto&&(g.vida-=dt)<=0){g.pego=true;continue}if(g.solto){const ch=Math.max(solo(g.x,g.z,g.y+.6),chaoVox(g.x,g.z,g.y+.6,.15));if(altura(g.x,g.z)<0&&ch<0&&g.y>altura(g.x,g.z)-1)g.y=lerp(g.y,onda(g.x,g.z,tempo)-.1,Math.min(1,dt*3));else if(isFinite(ch))g.y=g.y>ch+.05?Math.max(ch,g.y-dt*6):ch}
  if(g.espera>0){g.espera-=dt;continue}if(Math.abs(g.x-P.x)>1.8||Math.abs(g.z-P.z)>1.8)continue;if(dist2(g.x,g.z,P.x,P.z)<1.7&&Math.abs(g.y-pes()-.5)<2){if(g.item!=='moeda'&&!P.inv.some(c=>!c||(c[0]===g.item&&c[1]<ITENS[g.item].pilha))){g.espera=3;avisar('Mochila cheia',2);continue}g.pego=true;if(!g.solto&&g.id)ES.pegos[g.id]=1;pegar(g.item,g.q)}}
 M.chao=M.chao.filter(g=>!g.pego);
 for(const p of ES.plantas)if(p.t&&p.i<1)p.i=Math.min(1,p.i+dt/(chuvaForca>.3?100:160));
 {for(const v of M.vilas)if(!v.descoberta&&Math.abs(v.x-P.x)<34&&dist2(v.x,v.z,P.x,P.z)<34){v.descoberta=true;avisar(`Você descobriu ${v.nome}`,5);som('missao',.6);contar('vilas',v.i)}
  if(P.marca&&dist2(P.marca.x,P.marca.z,P.x,P.z)<7){const{x,z}=P.marca;P.marca=null;cairSuprimento(x,z,2,'Você encontrou o tesouro!')}
  if((P.proxEvento-=dt)<0){P.proxEvento=220+Math.random()*180;const p=lugarLivre(P.x,P.z,40,90,22);if(p&&!semSurgir(...p)&&!criativo())cairSuprimento(p[0],p[1],Math.random()<.12?2:Math.random()<.4?1:0,`Um baú de suprimentos apareceu ao ${direcao({x:p[0],z:p[1]})}!`)}}}

// ---------- mundos salvos ----------
const guardar=(k,v)=>{try{localStorage.setItem(k,v);return true}catch(e){return false}},ler=k=>{try{return JSON.parse(localStorage.getItem(k))}catch(e){return null}};
const lerIndice=()=>{const l=ler('alone.mundos');return Array.isArray(l)?l.filter(m=>m&&typeof m.id==='string'&&TAMANHOS[m.tam]):[]};
const lerSave=id=>{const s=ler('alone.w.'+id);return s&&s.v===4?s:null};
function apagarMundo(id){guardar('alone.mundos',JSON.stringify(lerIndice().filter(m=>m.id!==id)));try{localStorage.removeItem('alone.w.'+id)}catch(e){}}
function dadosSalvos(){const edits=[];for(const[k,n]of M.edits)edits.push(k,n);
 return{v:4,meta:{...META,dif:CFG.dif,dia,quando:Date.now()},hora,dia,P:{x:P.x,y:P.y,z:P.z,yaw:P.yaw,pitch:P.pitch,vida:P.vida,fome:P.fome,sel:P.sel,inv:P.inv,armadura:P.armadura,moedas:P.moedas,casa:P.casa,marca:P.marca,efeitos:P.efeitos,voando:P.voando},
 ES:{...ES,edits},stats,missoes,vilas:M.vilas.filter(v=>v.descoberta).map(v=>v.i),soltos:M.chao.filter(g=>g.solto&&!g.pego).slice(-40).map(g=>[g.item,g.q,+g.x.toFixed(1),+g.z.toFixed(1),+g.y.toFixed(1)]),
 obras:construcoes.map(c=>({tipo:c.tipo,x:c.x,y:c.y,z:c.z,a:c.a,aberto:c.aberto,itens:c.itens})),pets:dadosPets()}}
let avisouEspaco=false,semDisco=null;
function salvar(){if(!emPartida||!comecou||estado==='morto')return;const s=dadosSalvos(),ok=guardar('alone.w.'+META.id,JSON.stringify(s));if(ok){const l=lerIndice().filter(m=>m.id!==META.id);l.unshift(s.meta);guardar('alone.mundos',JSON.stringify(l))}else{semDisco=s;if(!avisouEspaco){avisouEspaco=true;avisar('Este navegador não permitiu salvar o progresso.',6)}}}
const KIT_CRIATIVO=['b_tabuas','b_pedregulho','b_vidro','b_lampada','espada_diamante','picareta_diamante','tocha','b_tnt'];
function iniciarPartida(meta,s){
 emPartida=false;comecou=false;META={id:meta.id,nome:meta.nome,semente:meta.semente,tam:meta.tam,modo:meta.modo,dif:meta.dif};MODO=meta.modo;if(meta.dif)CFG.dif=meta.dif;
 construcoes=[];stats=novasStats();alvoAtual=null;limparSeres();for(const k in CORPOS)if(/^v\d/.test(k)){apagarCorpo(CORPOS[k]);delete CORPOS[k]}
 ES=Object.assign(novoES(),{plantas:[],volta:null},s?JSON.parse(JSON.stringify(s.ES)):{});const edits=ES.edits;ES.edits=[];
 gerarMundo(meta.semente,meta.tam);for(let i=0;i+1<edits.length;i+=2){const[x,y,z]=deVK(edits[i]),v=edits[i+1];if(BLOCOS[v&1023]!==undefined)registrar(x,y,z,v)}planta=null;obraAndando=null;
 P=novoP();hora=.3;dia=1;iniciarMissoes();if(criativo()){KIT_CRIATIVO.forEach((id,i)=>P.inv[i]=[id,ITENS[id].pilha]);P.moedas=999}
 if(s){hora=s.hora;dia=s.dia;Object.assign(P,s.P);const ok=c=>c&&ITENS[c[0]]&&c[1]>0?c:null;P.inv=Array.from({length:36},(_,i)=>ok(s.P.inv[i]));P.armadura=Array.from({length:5},(_,i)=>ok(s.P.armadura?.[i]));P.efeitos=s.P.efeitos||{};
  for(const k in s.stats)Object.assign(stats[k]||(stats[k]={}),s.stats[k]);Object.assign(missoes,s.missoes);for(const i of s.vilas||[])if(M.vilas[i])M.vilas[i].descoberta=true}
 P.montaria=null;atualizarMundo(99);for(const o of s?.obras||[])addConstrucao({...o});if(!s)P.y=soloTopo(P.x,P.z)+1.7;restaurarPets(s?.pets);
 for(const o of s?.soltos||[])soltar(...o);P.corpoSujo=true;terraPronta();atualizarVoxels(999);emPartida=true;atualizarBarra()}
