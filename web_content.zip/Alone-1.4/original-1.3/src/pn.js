// ---------- painéis ----------
let painelTipo=null,painelArg=null,invSel=null,filtroCriar='tudo',abaCatalogo='cubo',buscaTexto='',ofertaVista=null,zoomMapa=false;
const TITULOS={inventario:'Mochila',criar:'Criar',catalogo:'Catálogo criativo',missoes:'Missões',mapa:'Mapa',dialogo:'',loja:'Comércio',bau:'Baú',construir:'Construção'};
function abrirPainel(tipo,arg){if(estado!=='jogando'&&estado!=='painel')return;if(tipo==='criar'&&criativo()&&!arg)tipo='catalogo';estado='painel';painelTipo=tipo;painelArg=arg;invSel=null;ofertaVista=null;soltarControles();if(document.pointerLockElement)document.exitPointerLock();$('painel').hidden=false;$('toque').hidden=true;$('painel').scrollTop=0;desenharPainel()}
function fecharPainel(){if(estado!=='painel')return;$('painel').hidden=true;salvar();jogar()}
function desenharPainel(){const c=$('pCorpo'),rolagem=$('painel').scrollTop;c.textContent='';$('pTitulo').textContent=TITULOS[painelTipo];PAINEIS[painelTipo](c,painelArg);$('painel').scrollTop=rolagem}
const linhaItem=(id,titulo,sub,...botoes)=>{const l=el(`<div class="item"><img alt="" src="${icone(id)}"><div><b>${titulo}</b><small>${sub}</small></div></div>`);l.append(...botoes.filter(Boolean));return l};
const USOS={tesoura:'Use em ovelhas para pegar lã',vara_pesca:'Use na água; use de novo quando fisgar',balde:'Use na água ou numa vaca',balde_agua:'Use para despejar a água',balde_leite:'Use para beber',isqueiro:'Use na dinamite para acendê-la',martelo:'Use para desmontar construções',bussola:'Use para ver sua posição',relogio:'Use para ver a hora',luneta:'Use para aproximar a visão',barco:'Use em um lago ou no mar',mapa_tesouro:'Use para marcar um tesouro no mapa',nucleo_golem:'Use no chão para criar um golem protetor',tocha:'Use para fixar no chão; equipe para iluminar',sementes:'Plante em terra preparada com a enxada',cenoura:'Também pode ser plantada',batata:'Também pode ser plantada',osso:'Ofereça a um lobo para domesticar',trigo:'Atrai ovelhas e vacas'};
const ONDE=['na cabeça','no peito','nas pernas','nos pés','na mão esquerda'];
function descricao(id){const it=ITENS[id],p=[];if(it.cat==='arma'||it.cat==='ferramenta')p.push(`Dano ${it.dano}`);if(it.nivel&&['picareta','machado','pa','enxada'].includes(it.ferramenta))p.push(`${it.ferramenta==='pa'?'pá':it.ferramenta} nível ${it.nivel}`);if(it.comida)p.push(`Fome +${it.comida}`);if(it.cura)p.push(`Vida ${it.cura>0?'+':''}${it.cura}`);if(it.efeito)p.push(`${NOME_EFEITO[it.efeito]} por 90 s`);
 if(it.defesa)p.push(`Protege ${Math.round(it.defesa*100)}% ${ONDE[it.slot]}`);if(id==='escudo')p.push('Reduz golpes pela frente');if(it.cat==='bloco')p.push('Use para colocar');if(it.cat==='cubo')p.push('Bloco de construção: use para colocar');if(it.cat==='ovo')p.push('Use no chão para invocar');if(it.distancia)p.push('Usa flechas');if(it.ferramenta==='pa')p.push('Cava terra e areia do chão');if(it.ferramenta==='enxada')p.push('Prepara a terra para plantar');if(USOS[id])p.push(USOS[id]);return p.join(' · ')||'Material'}
function moverPilha(i,j){const a=P.inv[i],b=P.inv[j];if(a&&b&&a[0]===b[0]){const n=Math.min(a[1],ITENS[a[0]].pilha-b[1]);if(n>0){b[1]+=n;a[1]-=n;if(!a[1])P.inv[i]=null;return}}P.inv[j]=a;P.inv[i]=b}
const CATS={tudo:['Tudo',()=>true],ferr:['Ferramentas',k=>k==='ferramenta'],comb:['Armas e armaduras',k=>['arma','armadura','municao'].includes(k)],cubo:['Blocos',k=>k==='cubo'],obra:['Construções',k=>k==='bloco'],comida:['Comida',k=>k==='comida'],mat:['Materiais',k=>['recurso','dinheiro'].includes(k)]};
const PAINEIS={
 construir(c){const grupo=(t,l)=>{c.append(el(`<h3>${t}</h3>`),fila(...l))},rep=()=>desenharPainel();
  grupo('Forma do bloco (tecla G)',FORMAS.map((f,i)=>f.oculta?null:botao(f.n,()=>{trocarForma(i);rep()},'m'+((P.forma||0)===i?' p':''))).filter(Boolean));
  grupo('Modo de colocar (tecla T)',Object.entries(MODOS_OBRA).map(([k,n])=>botao(n,()=>{P.modoObra=k;rep()},'m'+((P.modoObra||'um')===k?' p':''))));
  c.append(el('<h3>Projetos prontos</h3><p>Escolha, mire no chão e use (E). Gasta materiais no modo sobrevivência. Escadas e telhados giram conforme o lado para onde você olha.</p>'));
  for(const k in PLANTAS){const custo=custoPlano(PLANTAS[k][1]()),txt=Object.entries(custo).map(([id,q])=>criativo()?`${q} ${ITENS[id]?.n||id}`:`${Math.min(tem(id),q)}/${q} ${ITENS[id]?.n||id}`).join(' · ');
   c.append(linhaItem(Object.keys(custo)[0],PLANTAS[k][0],txt,botao('Escolher',()=>{escolherPlanta(k);fecharPainel()},'m p')))}
  if(planta)c.append(fila(botao('Cancelar projeto',()=>{planta=null;rep()},'m')))},
 inventario(c){P.corpoSujo=P.corpoSujo||!corpoJogador;const eq=el('<div class="equip"><canvas class="previa" width="300" height="400" aria-label="Seu personagem"></canvas><div class="slots"></div></div>'),sl=eq.lastElementChild;
  ['Cabeça','Peito','Pernas','Pés','Mão 2'].forEach((n,s)=>{const b=slotEl(P.armadura[s],0,false,n);b.addEventListener('click',()=>{if(invSel!==null&&P.inv[invSel]&&ITENS[P.inv[invSel][0]].slot===s){equipar(invSel);invSel=null}else desequipar(s);desenharPainel()});sl.append(b)});
  c.append(eq,el(`<p style="text-align:center;margin-top:10px">Proteção <b>${Math.round(defesa()*100)}%</b> · Moedas <b>${P.moedas}</b></p>`));
  const grade=(ini,fim,cls='')=>{const g=el(`<div class="grade ${cls}"></div>`);for(let i=ini;i<fim;i++){const s=slotEl(P.inv[i],i<8?i+1:0,invSel===i);s.addEventListener('click',()=>{if(invSel===null){if(P.inv[i])invSel=i}else if(invSel===i)invSel=null;else{moverPilha(invSel,i);invSel=null}atualizarBarra();desenharPainel()});g.append(s)}return g};
  const d=el('<div id="detalhe"></div>'),s=invSel!==null&&P.inv[invSel];
  if(s){const it=ITENS[s[0]];d.append(linhaItem(s[0],`${it.n}${s[1]>1?' × '+s[1]:''}`,descricao(s[0])),fila(
    it.slot!==undefined&&botao('Equipar',()=>{equipar(invSel);invSel=null;desenharPainel()},'m p'),
    it.cat==='comida'&&botao(it.comida?'Comer':'Usar',()=>{comer(invSel);if(!P.inv[invSel])invSel=null;desenharPainel()},'m p'),
    botao('Colocar na mão',()=>{if(invSel>=8)moverPilha(invSel,P.sel);else P.sel=invSel;atualizarBarra();fecharPainel()},'m'),
    botao('Largar',()=>{const[fx,fz]=frente();soltar(s[0],s[1],P.x+fx*2.5,P.z+fz*2.5,pes()+.4);M.chao.at(-1).espera=2;P.inv[invSel]=null;invSel=null;atualizarBarra();desenharPainel()},'m'),
    criativo()&&botao('Apagar',()=>{P.inv[invSel]=null;invSel=null;atualizarBarra();desenharPainel()},'m perigo')))}
  else d.append(el('<p>Toque em um item para ver as opções. Toque em outro espaço para mover.</p>'));
  c.append(d,el('<h3>Barra de itens</h3>'),grade(0,8,'barraG'),el('<h3>Mochila</h3>'),grade(8,36))},
 criar(c){const perto=['bancada','fogo'].filter(e=>M.estacoes.some(s=>s.tipo===e&&dist2(s.x,s.z,P.x,P.z)<5));c.append(el(`<p>${perto.length?'Perto de você: '+perto.map(e=>e==='fogo'?'fogueira':'mesa de artesanato').join(' e ')+'.':'Longe de mesa e fogueira: só receitas simples.'}</p>`),
   fila(...Object.entries(CATS).map(([k,[n]])=>botao(n,()=>{filtroCriar=k;desenharPainel()},'m'+(k===filtroCriar?' p':'')))));
  const busca=el('<input class="campo" type="search" placeholder="Procurar receita" aria-label="Procurar receita" style="max-width:100%;width:100%;box-sizing:border-box;margin:10px 0 4px">'),lista=el('<div></div>');busca.value=buscaTexto;c.append(busca,lista);
  const encher=()=>{lista.textContent='';const q=buscaTexto.toLowerCase(),ordem=r=>podeFazer(r)?0:pertoDe(r.est)?1:2;
   for(const r of RECEITAS.filter(r=>ITENS[r.id]&&CATS[filtroCriar][1](ITENS[r.id].cat)&&ITENS[r.id].n.toLowerCase().includes(q)).sort((a,b)=>ordem(a)-ordem(b))){const ing=Object.entries(r.ing).map(([id,n])=>`<span class="${tem(id)<n?'falta':''}">${ITENS[id].n} ${tem(id)}/${n}</span>`).join(' · ');
    const b=botao('Criar',()=>{fabricar(r);const y=$('painel').scrollTop;encher();$('painel').scrollTop=y},'m'+(podeFazer(r)?' p':''));b.disabled=!podeFazer(r);
    lista.append(linhaItem(r.id,ITENS[r.id].n+(r.qtd>1?` × ${r.qtd}`:''),ing+(pertoDe(r.est)?'':`<br><span class="falta">Precisa estar ${NOME_EST[r.est]}</span>`),b))}
   if(!lista.children.length)lista.append(el('<p>Nenhuma receita encontrada.</p>'))};
  busca.addEventListener('input',()=>{buscaTexto=busca.value;encher()});encher()},
 catalogo(c){const abas={cubo:'Blocos',ferr:'Ferramentas',comb:'Armas e armaduras',obra:'Construções',comida:'Comida',mat:'Materiais',ovo:'Criaturas',mundo:'Mundo'};
  c.append(fila(...Object.entries(abas).map(([k,n])=>botao(n,()=>{abaCatalogo=k;desenharPainel()},'m'+(k===abaCatalogo?' p':''))),botao('Abrir mochila',()=>abrirPainel('inventario'),'m')));
  if(abaCatalogo==='mundo'){const h=t=>c.append(el(`<h3>${t}</h3>`));h('Hora do dia');c.append(fila(...[['Amanhecer',.28],['Meio-dia',.5],['Pôr do sol',.73],['Meia-noite',0]].map(([n,v])=>botao(n,()=>{hora=v;noite=1-smooth(-.22,.12,Math.sin((hora-.25)*TAU));avisar(n)},'m')),botao(ES.tempoParado?'Tempo parado: sim':'Tempo parado: não',()=>{ES.tempoParado=!ES.tempoParado;desenharPainel()},'m'+(ES.tempoParado?' p':''))));
   h('Clima');c.append(fila(...[['Céu limpo',0],['Chuva',.6],['Tempestade',1]].map(([n,v])=>botao(n,()=>{climaAlvo=v;chuvaForca=v;climaT=300;if(v&&!CFG.clima){CFG.clima=true;salvarCfg()}avisar(n)},'m'))));
   h('Viajar para');const perto=l=>l.map(o=>[o,dist2(o.x,o.z,P.x,P.z)]).filter(o=>o[1]>25).sort((a,b)=>a[1]-b[1])[0]?.[0];
   c.append(fila(botao('Acampamento',()=>teleportar(3,7),'m'),...[['Vila',M.vilas],['Caverna',M.cavernas],['Serra',M.serras],['Ruínas',M.ruinas]].map(([n,l])=>botao(n+' mais próxima',()=>{const o=perto(l);if(!o){avisar('Nada encontrado');return}teleportar(o.x+(n==='Vila'?0:3),o.z+(n==='Vila'?12:8))},'m'))),el('<p style="margin-top:12px">Você também pode tocar em qualquer ponto do mapa para viajar até lá.</p>'));return}
  const filtro=abaCatalogo==='ovo'?k=>k==='ovo':CATS[abaCatalogo][1],g=el('<div class="catalogo"></div>'),nome=el('<p style="margin:10px 0 0">Toque num item para colocá-lo no espaço selecionado da barra.</p>');
  for(const it of Object.values(ITENS).filter(it=>filtro(it.cat)&&it.id!=='moeda')){const s=slotEl([it.id,1]);s.addEventListener('click',()=>{let i=P.sel;if(P.inv[i]&&P.inv[i][0]!==it.id){const livre=P.inv.findIndex((v,k)=>k<8&&!v);if(livre>=0)i=livre}P.inv[i]=[it.id,it.pilha];P.sel=i;atualizarBarra();som('pegar',.5);nome.textContent=`${it.n} no espaço ${i+1}. ${descricao(it.id)}`;barra()});s.addEventListener('pointerenter',()=>nome.textContent=`${it.n} · ${descricao(it.id)}`);g.append(s)}
  const minha=el('<div class="grade barraG"></div>'),barra=()=>{minha.textContent='';for(let i=0;i<8;i++){const s=slotEl(P.inv[i],i+1,i===P.sel);s.addEventListener('click',()=>{P.sel=i;atualizarBarra();barra()});minha.append(s)}};barra();c.append(el('<h3>Sua barra</h3>'),minha,nome,el('<h3>Itens</h3>'),g)},
 missoes(c){if(criativo()){c.append(el('<p>No modo criativo não há missões. Mude para sobrevivência no menu de pausa quando quiser jogá-las.</p>'));return}const m=PRINCIPAL[missoes.passo];c.append(el(`<h3>História · ${missoes.passo}/${PRINCIPAL.length}</h3>`));
  if(m)c.append(linhaItem('moeda',m.t,`${m.d}<br>Progresso: ${Math.min(m.v(),m.meta)}/${m.meta} · Recompensa: ${m.premio.map(([i,q])=>q+'× '+ITENS[i].n.toLowerCase()).join(', ')}`,botao(missoes.seguir==='principal'?'Seguindo':'Seguir',()=>{missoes.seguir='principal';desenharPainel()},'m')));
  else c.append(el('<p>História concluída. O farol brilha e o mundo é seu.</p>'));
  c.append(el(`<h3>Pedidos dos moradores · ${missoes.feitas} concluídos</h3>`));if(!missoes.extras.length)c.append(el('<p>Converse com os moradores das vilas para receber pedidos.</p>'));
  for(const e of missoes.extras){const p=e.tipo==='carta'?0:Math.min(progresso(e),e.qtd);c.append(linhaItem(e.premio[0][0],esc(e.titulo),`${e.tipo==='carta'?'Entregue a carta':`${p}/${e.qtd}${p>=e.qtd?' · volte para receber':''}`} · pedido de ${esc(e.nome)}, ${esc(M.vilas[e.vila].nome)}`,
   botao(missoes.seguir===e.id?'Seguindo':'Seguir',()=>{missoes.seguir=e.id;desenharPainel()},'m'),botao('Desistir',()=>{missoes.extras=missoes.extras.filter(o=>o!==e);desenharPainel()},'m')))}
  c.append(el(`<h3>Conquistas · ${Object.keys(missoes.conquistas).length}/${CONQUISTAS.length}</h3>`));for(const[id,n,d,v,meta]of CONQUISTAS)c.append(linhaItem(missoes.conquistas[id]?'ouro':'pedra',n,`${d} · ${missoes.conquistas[id]?'<span style="color:var(--ok)">concluída</span>':`${Math.min(v(),meta)}/${meta}`}`))},
 mapa(c){const cv=el('<canvas id="mapaG" width="720" height="720"></canvas>');c.append(fila(botao('Mundo inteiro',()=>{zoomMapa=false;desenharPainel()},'m'+(zoomMapa?'':' p')),botao('Região',()=>{zoomMapa=true;desenharPainel()},'m'+(zoomMapa?' p':''))),cv,
   el(`<p style="margin-top:10px">Laranja: acampamento · Bege: vilas · Cinza: pedreiras · Roxo: serras · Azul: cavernas · Amarelo: objetivo${criativo()?' · <b>Toque no mapa para viajar</b>':''}</p>`));cv.style.marginTop='10px';desenharMapa(cv,true);
  if(criativo()){cv.style.cursor='crosshair';cv.addEventListener('click',e=>{const r=cv.getBoundingClientRect(),u=(e.clientX-r.left)/r.width-.5,v=(e.clientY-r.top)/r.height-.5,{cx,cz,vao}=vistaMapa();fecharPainel();teleportar(cx+u*vao,cz+v*vao)})}},
 dialogo(c,a){const n=a.e.npc;$('pTitulo').textContent=n.nome;const papel={anciao:'Guarda as histórias',ferreiro:'Ferraria',mercador:'Comércio',fazendeira:'Plantações',cacador:'Caça',aldeao:n.fem?'Moradora':'Morador'}[n.papel];
  c.append(el(`<p>${papel} · ${esc(M.vilas[n.vila].nome)}</p>`),el(`<p id="fala">“${esc(a.texto)}”</p>`));const minha=missoes.extras.find(m=>m.npc===n.id),botoes=[];
  if(ofertaVista)botoes.push(botao('Aceitar',()=>{if(aceitar(ofertaVista))a.texto='Ótimo. Estarei esperando.';ofertaVista=null;a.oferta=null;desenharPainel()},'p'),botao('Agora não',()=>{ofertaVista=null;a.texto='Sem problema.';desenharPainel()}));
  else{botoes.push(botao('Conversar',()=>{a.texto=falaNpc(n);desenharPainel()}));
   if(minha){const pronto=minha.tipo!=='carta'&&progresso(minha)>=minha.qtd;botoes.push(pronto?botao('Entregar pedido',()=>{concluir(minha);a.texto='Você conseguiu! Aqui está sua recompensa.';desenharPainel()},'p'):botao('Sobre o pedido',()=>{a.texto=`${minha.titulo}. Ainda não terminou.`;desenharPainel()}))}
   else if(!criativo())botoes.push(botao('Precisa de ajuda?',()=>{a.oferta=a.oferta||ofertaPara(n);ofertaVista=a.oferta;a.texto=`${ofertaVista.titulo}. Pago ${ofertaVista.premio.map(([i,q])=>q+'× '+ITENS[i].n.toLowerCase()).join(' e ')}.`;desenharPainel()}));
   if(LOJAS[n.papel])botoes.push(botao('Comerciar',()=>abrirPainel('loja',n)));botoes.push(botao('Adeus',fecharPainel))}
  c.append(fila(...botoes))},
 loja(c,n){$('pTitulo').textContent=`Comércio com ${n.nome}`;c.append(el(`<p>Suas moedas: <b>${P.moedas}</b></p>`),el('<h3>Comprar</h3>'));
  for(const[id,q]of LOJAS[n.papel]){const preco=precoCompra(id,q),b=botao(`${preco} moedas`,()=>{if(P.moedas<preco)return;P.moedas-=preco;const r=adicionar(id,q);if(r)soltar(id,r,P.x,P.z,pes());som('moeda');contar('coletado',id,q-r);desenharPainel()},'m p');b.disabled=P.moedas<preco;c.append(linhaItem(id,ITENS[id].n+(q>1?` × ${q}`:''),descricao(id),b))}
  c.append(el('<h3>Vender</h3>'));const meus=[...new Set(P.inv.filter(Boolean).map(s=>s[0]))];if(!meus.length)c.append(el('<p>Sua mochila está vazia.</p>'));
  for(const id of meus){const v=precoVenda(id),vender=q=>{if(criativo())return;q=Math.min(q,tem(id));remover(id,q);P.moedas+=v*q;som('moeda');desenharPainel()};c.append(linhaItem(id,`${ITENS[id].n} × ${tem(id)}`,`${v} ${v>1?'moedas':'moeda'} cada`,botao('Vender 1',()=>vender(1),'m'),tem(id)>1&&botao('Tudo',()=>vender(9999),'m')))}},
 bau(c,b){const tirar=i=>{const[id,q]=b.itens[i],resto=adicionar(id,q),levou=q-resto;if(levou){contar('coletado',id,levou);avisar(`+${levou} ${ITENS[id].n}`,2)}if(resto){b.itens[i]=[id,resto];avisar('Mochila cheia',2)}else b.itens.splice(i,1);som('pegar',.6)};
  const g=el('<div class="grade"></div>');b.itens.forEach((s,i)=>{if(!ITENS[s[0]])return;const e=slotEl(s);e.addEventListener('click',()=>{tirar(i);desenharPainel()});g.append(e)});
  c.append(el('<h3>No baú · toque para pegar</h3>'),b.itens.length?g:el('<p>Vazio.</p>'));if(b.itens.length)c.append(fila(botao('Pegar tudo',()=>{for(let i=b.itens.length-1;i>=0;i--)tirar(i);desenharPainel()},'m p')));
  const meu=el('<div class="grade"></div>');P.inv.forEach((s,i)=>{if(!s)return;const e=slotEl(s);e.addEventListener('click',()=>{if(b.itens.length>=24){avisar('Baú cheio',2);return}b.itens.push([...s]);P.inv[i]=null;atualizarBarra();desenharPainel()});meu.append(e)});c.append(el('<h3>Sua mochila · toque para guardar</h3>'),meu)}};
function teleportar(x,z){P.montaria=null;const L=M.MEIO-30;P.x=clamp(x,-L,L);P.z=clamp(z,-L,L);P.vy=0;P.barco=null;atualizarMundo(99);P.y=Math.max(soloTopo(P.x,P.z),chaoVox(P.x,P.z,altura(P.x,P.z)+20,.3,20),.2)+1.75;for(const e of seres)if(e.manso&&e.tipo==='lobo'&&!e.sentado){e.x=P.x+1;e.z=P.z+1;e.y=pes()}atualizarVoxels(99);avisar('Viagem concluída',2)}

// ---------- mapas e HUD ----------
let mapaRegiao=null;
function vistaMapa(){return zoomMapa?{cx:P.x,cz:P.z,vao:Math.min(700,M.MEIO*2)}:{cx:0,cz:0,vao:M.MEIO*2}}
function imagemRegiao(cx,cz,vao){const chave=`${M.semente}|${M.tam}|${cx>>5}|${cz>>5}`;if(mapaRegiao&&mapaRegiao.chave===chave)return mapaRegiao;const L=240,cv=document.createElement('canvas');cv.width=cv.height=L;const g=cv.getContext('2d'),im=g.createImageData(L,L),p=vao/L,x0=cx-vao/2,z0=cz-vao/2;
 for(let j=0;j<L;j++)for(let i=0;i<L;i++){const x=x0+i*p,z=z0+j*p,h=relevo(x,z);let c;if(h<0)c=mix([.2,.46,.6],[.08,.22,.36],clamp(-h/6,0,1));else{const b=CORES_BIOMA[bioma(x,z)];c=mix(b[0],b[1],.5);c=mix(c,[.45,.45,.42],smooth(14,24,h));c=mix(c,[.85,.88,.9],smooth(30,40,h)).map(v=>v*clamp(.9+h*.012,.9,1.15))}im.data.set([c[0]*255,c[1]*255,c[2]*255,255],(j*L+i)*4)}
 g.putImageData(im,0,0);return mapaRegiao={chave,cv,x0,z0,vao}}
function marcaDisco(g,a,b,r,cor){g.fillStyle=cor;g.strokeStyle='#000a';g.lineWidth=2;g.beginPath();g.arc(a,b,r,0,TAU);g.fill();g.stroke()}
function setaJogador(g,a,b,e){g.translate(a,b);g.rotate(-P.yaw);g.scale(e,e);g.fillStyle='#fff';g.strokeStyle='#000';g.lineWidth=2;g.beginPath();g.moveTo(0,-11);g.lineTo(7,8);g.lineTo(0,4);g.lineTo(-7,8);g.closePath();g.fill();g.stroke()}
function desenharMapa(cv,grande){const g=cv.getContext('2d'),W=cv.width;g.save();g.fillStyle='#0b171c';g.fillRect(0,0,W,W);
 if(CAV&&!grande){const R=24,s=W/(R*2),y=Math.floor(pes()+.4),px=Math.floor(P.x),pz=Math.floor(P.z);for(let a=-R;a<R;a++)for(let b=-R;b<R;b++){const n=bloco(px+a,y,pz+b),chao=bloco(px+a,y-1,pz+b);g.fillStyle=n?(BLOCOS[n].lava?'#ff6a12':BLOCOS[n].agua?'#2c6cc0':BLOCOS[n].id.startsWith('min_')?CORES_BLOCO[BLOCOS[n].id]:'#26313a'):chao&&BLOCOS[chao].lava?'#c84a08':'#8b8478';g.fillRect((a+R)*s,(b+R)*s,s+1,s+1)}
  marcaDisco(g,(CAV.saida.x-P.x)*s+W/2,(CAV.saida.z-P.z)*s+W/2,7,'#7fd6ff');setaJogador(g,W/2,W/2,1);g.restore();return}
 const v=grande?vistaMapa():{cx:P.x,cz:P.z,vao:150},k=W/v.vao,sx=x=>(x-v.cx)*k+W/2,sz=z=>(z-v.cz)*k+W/2,MEIO=M.MEIO;
 if(grande){if(zoomMapa){const r=imagemRegiao(v.cx,v.cz,v.vao);g.drawImage(r.cv,sx(r.x0),sz(r.z0),r.vao*k,r.vao*k)}else g.drawImage(M.imagemMapa,sx(-MEIO),sz(-MEIO),MEIO*2*k,MEIO*2*k)}
 else{g.imageSmoothingEnabled=true;for(const ch of M.chunks.values()){const a=sx(ch.cx*BLOCO),b=sz(ch.cz*BLOCO),t=BLOCO*k;if(a>W||b>W||a+t<0||b+t<0)continue;g.drawImage(ch.mapa,a,b,t+1,t+1)}}
 const e=grande?(zoomMapa||MEIO<800?1.5:.8):1.1,disco=(x,z,r,cor,prende)=>{let a=sx(x)-W/2,b=sz(z)-W/2;const d=Math.hypot(a,b),L=W/2-12;if(prende&&!grande&&d>L){a*=L/d;b*=L/d}marcaDisco(g,a+W/2,b+W/2,r*e,cor)};
 const ve=o=>Math.abs(o.x-v.cx)<v.vao&&Math.abs(o.z-v.cz)<v.vao;
 for(const p of M.pedreiras)if(ve(p)&&(!grande||zoomMapa||MEIO<800))disco(p.x,p.z,4,'#b8b8b0');for(const s of M.serras)if(ve(s))disco(s.x,s.z,4,'#b78cff');for(const c of M.cavernas)if(ve(c))disco(c.x,c.z,4.5,'#58c8ee');for(const t of M.vilas)if(ve(t))disco(t.x,t.z,6,t.descoberta?'#ffe9bd':'#a39674');disco(0,0,6.5,'#ff7a2f');
 for(const c of construcoes)if(!c.cav&&c.tipo!=='tocha'&&ve(c))disco(c.x,c.z,2,'#d9a066');
 if(!grande){for(const s of seres)if(!s.morte&&!s.cav&&dist2(s.x,s.z,P.x,P.z)<75&&(s.def.monstro&&!s.manso||s.npc||s.tipo==='golem'))disco(s.x,s.z,3.2,s.npc?'#7fd6ff':s.tipo==='golem'?'#4fffc0':'#ff4438');for(const b of M.baus)if(!b.aberto&&!b.cav&&b.rar&&ve(b))disco(b.x,b.z,3.5,'#ffd21f')}
 if(P.marca)disco(P.marca.x,P.marca.z,6,'#ff3a3a',true);const al=alvoAtualMissao();disco(al.a.x,al.a.z,5.5,'#ffd21f',true);
 if(grande){g.font='bold 20px sans-serif';g.textAlign='center';g.lineWidth=4;g.strokeStyle='#000c';g.fillStyle='#fff';for(const t of M.vilas){if(!ve(t)||!(t.descoberta||zoomMapa||MEIO<500))continue;const n=t.descoberta?t.nome:'Vila desconhecida';g.strokeText(n,sx(t.x),sz(t.z)-16);g.fillText(n,sx(t.x),sz(t.z)-16)}}
 setaJogador(g,sx(P.x),sz(P.z),grande?1.5:1.1);g.restore()}
const texto=(id,t)=>{const e=$(id);if(e.textContent!==t)e.textContent=t};
let htmlRastreio='',htmlInfo='';
function atualizarHud(){const cr=criativo();$('lVida').hidden=$('lFome').hidden=cr;$('bVida').style.width=clamp(P.vida,0,100)+'%';$('bFome').style.width=clamp(P.fome,0,100)+'%';$('lAr').hidden=cr||P.ar>=15;$('bAr').style.width=clamp(P.ar/15*100,0,100)+'%';
 const vila=!CAV&&M.vilas.find(v=>dist2(v.x,v.z,P.x,P.z)<34),h=hora*24,d=defesa();
 const info=`Dia ${dia} · ${String(h|0).padStart(2,'0')}h ${noite>.6?'(noite)':''}${cr?' · criativo':''}<br>${CAV?'Caverna · fundo '+Math.round(CAV.entrada.y-pes())+' m':vila?esc(vila.nome):NOME_BIOMA[bioma(P.x,P.z)]}<br>X ${Math.round(P.x)} · Z ${Math.round(P.z)}<br>${P.moedas} moedas${d?` · defesa ${Math.round(d*100)}%`:''}`;if(info!==htmlInfo)$('info').innerHTML=htmlInfo=info;
 texto('efeitos',Object.entries(P.efeitos).map(([k,v])=>`${NOME_EFEITO[k]} ${Math.ceil(v)}s`).join(' · '));
 const al=alvoAtualMissao();let t;
 if(cr)t='<b>Modo criativo</b>'+(CFG.dicas?`<span class="desc">${CFG.modo==='touch'?'Abra Criar para o catálogo. Use o botão Voar.':'B abre o catálogo. F ou pulo duplo para voar.'}</span>`:'');
 else{const m=PRINCIPAL[missoes.passo];t=m?`<b>${m.t}</b>${m.meta>1?`${Math.min(m.v(),m.meta)}/${m.meta} `:''}${CFG.dicas?`<span class="desc">${m.d}</span>`:''}`:'<b>Você não está mais sozinho</b>Explore à vontade.';
  const ex=missoes.extras.find(e=>e.id===missoes.seguir)||missoes.extras[0];if(ex)t+=`<b style="margin-top:6px">${esc(ex.titulo)}</b>${ex.tipo==='carta'?'':`${Math.min(progresso(ex),ex.qtd)}/${ex.qtd}`}`}if(t!==htmlRastreio)$('rastreio').innerHTML=htmlRastreio=t;
 $('bussola').hidden=!!CAV;if(!CAV){const dx=al.a.x-P.x,dz=al.a.z-P.z,s=Math.sin(P.yaw),co=Math.cos(P.yaw);$('seta').style.transform=`rotate(${Math.atan2(dx*co-dz*s,-dx*s-dz*co)}rad)`;texto('dist',`${al.nome.length>28?al.nome.slice(0,27)+'…':al.nome} · ${Math.hypot(dx,dz)|0} m`)}
 let nome=null,frac=0;if(alvoAtual){if(alvoAtual.e&&!alvoAtual.e.morte){nome=alvoAtual.e.def.n;frac=alvoAtual.e.hp/alvoAtual.e.max}else if(alvoAtual.r&&!alvoAtual.r.morto){nome=RECURSOS[alvoAtual.r.tipo].n;frac=alvoAtual.r.hp/RECURSOS[alvoAtual.r.tipo].hp}}
 const chefe=CAV&&seres.find(e=>e.def.chefe&&!e.morte&&dist2(e.x,e.z,P.x,P.z)<18);if(!nome&&chefe){nome=chefe.def.n;frac=chefe.hp/chefe.max}
 $('alvo').hidden=!nome;if(nome){texto('alvoNome',nome);$('alvoVida').style.width=clamp(frac*100,0,100)+'%'}
 let dica='';const prev=previsao(),u2=alvoUso(),toque=CFG.modo==='touch',it=naMao();
 if(P.pesca)dica=P.pesca.fisgou>0?(toque?'Fisgou! Toque em Usar':'Fisgou! Botão direito'):'Esperando o peixe…';else if(P.barco)dica=toque?'Pular: sair do barco':'Espaço: sair do barco';
 else if(u2)dica=toque?`Usar: ${u2.rotulo}`:`E · ${u2.rotulo}`;else if(prev)dica=prev.erro||(toque?'Usar coloca · Girar vira':'Botão direito coloca · R gira');
 else{const a=alvoAtaque();if(a&&a.tipo==='vox'){const b=BLOCOS[a.o.n];if(CFG.dicas){const{apto}=tempoBloco(b,it);dica=b.n+(!apto&&!cr?' · precisa de picareta melhor':'')}}else if(a&&a.tipo==='rec'&&CFG.dicas){const r=RECURSOS[a.o.tipo];dica=r.nivel?`${r.n} · precisa de picareta`:r.n}else if(a&&a.tipo==='chao')dica=toque?'Atacar: cavar':'Clique: cavar'}
 texto('dica',dica);
 const touch=CFG.modo==='touch';$('tDescer').hidden=!(touch&&(P.sub>0||P.voando));$('tVoar').hidden=!(touch&&cr);$('tVoar').classList.toggle('on',P.voando);
 desenharMapa($('mapa'),false)}
// nomes flutuando sobre moradores, golens e companheiros
const etiquetas=[];
function atualizarNomes(){const c=$('nomes');let n=0;if(CFG.nomes&&estado==='jogando'){const v=VPatual;for(const e of seres){if(e.morte||e.cav!==!!CAV||!(e.npc||e.tipo==='golem'||e.manso&&e.tipo==='lobo')||Math.abs(e.x-P.x)>13||Math.abs(e.z-P.z)>13)continue;
   const x=e.x,y=e.y+e.def.alt*(e.escala||1)+.28,z=e.z,w=v[3]*x+v[7]*y+v[11]*z+v[15];if(w<.5)continue;const sx=(v[0]*x+v[4]*y+v[8]*z+v[12])/w,sy=(v[1]*x+v[5]*y+v[9]*z+v[13])/w;if(Math.abs(sx)>1||Math.abs(sy)>1)continue;
   let t=etiquetas[n];if(!t){t=etiquetas[n]=document.createElement('span');c.append(t)}t.hidden=false;t.style.left=(sx*50+50)+'%';t.style.top=(50-sy*50)+'%';const nome=e.npc?e.npc.nome+(e.fala>0?' …':''):e.tipo==='golem'?(e.manso?'Seu golem':'Golem da vila'):'Seu lobo';if(t.textContent!==nome)t.textContent=nome;n++}
  if(CFG.camera&&comecou){const y=P.y+.55,x=P.x,z=P.z,w=v[3]*x+v[7]*y+v[11]*z+v[15];if(w>.5){let t=etiquetas[n];if(!t){t=etiquetas[n]=document.createElement('span');c.append(t)}t.hidden=false;t.style.left=((v[0]*x+v[4]*y+v[8]*z+v[12])/w*50+50)+'%';t.style.top=(50-(v[1]*x+v[5]*y+v[9]*z+v[13])/w*50)+'%';if(t.textContent!==SKIN.nick)t.textContent=SKIN.nick;n++}}}
 for(let i=n;i<etiquetas.length;i++)etiquetas[i].hidden=true}
