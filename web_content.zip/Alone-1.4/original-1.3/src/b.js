'use strict';
const $=id=>document.getElementById(id), canvas=$('c');
const gl=canvas.getContext('webgl2',{antialias:true});
if(!gl){$('mCorpo').innerHTML='<h1>Alone</h1><p>Este navegador não tem suporte a WebGL2. Abra o jogo em um navegador atualizado.</p>';throw new Error('sem WebGL2');}
const TAU=Math.PI*2, clamp=(v,a,b)=>v<a?a:v>b?b:v, lerp=(a,b,t)=>a+(b-a)*t;
const smooth=(a,b,v)=>{const t=clamp((v-a)/(b-a),0,1);return t*t*(3-2*t)};
const mix=(a,b,t)=>a.map((v,i)=>lerp(v,b[i],t));
const dist2=(ax,az,bx,bz)=>Math.hypot(ax-bx,az-bz);
// aleatório determinístico (só para a geração do mundo e modelos)
let estadoRnd=1,deslX=0,deslZ=0;
const rnd=()=>{estadoRnd=(estadoRnd+0x6D2B79F5)|0;let t=Math.imul(estadoRnd^estadoRnd>>>15,1|estadoRnd);t^=t+Math.imul(t^t>>>7,61|t);return((t^t>>>14)>>>0)/4294967296};
const entre=(a,b)=>a+rnd()*(b-a), inteiro=(a,b)=>Math.floor(entre(a,b+1)), escolher=l=>l[rnd()*l.length|0];
const sorte=(a,b)=>a+Math.floor(Math.random()*(b-a+1)), qualquer=l=>l[Math.random()*l.length|0];
function semearTexto(txt){let h=2166136261;for(const c of String(txt)){h^=c.charCodeAt(0);h=Math.imul(h,16777619)}estadoRnd=h|0;deslX=Math.floor(rnd()*9000);deslZ=Math.floor(rnd()*9000)}
const hash=(x,y)=>{let h=Math.imul(x+deslX,374761393)^Math.imul(y+deslZ,668265263);h=Math.imul(h^h>>>13,1274126177);return((h^h>>>16)>>>0)/4294967296};
function ruido(x,y){const i=Math.floor(x),j=Math.floor(y),f=x-i,g=y-j,u=f*f*(3-2*f),v=g*g*(3-2*g);
 return lerp(lerp(hash(i,j),hash(i+1,j),u),lerp(hash(i,j+1),hash(i+1,j+1),u),v)}
const fbm=(x,y)=>ruido(x,y)*.57+ruido(x*2.1+9,y*2.1+3)*.29+ruido(x*4.3+1,y*4.3+7)*.14;
// matrizes (coluna principal)
function mul(a,b){const o=new Float32Array(16);for(let c=0;c<4;c++)for(let r=0;r<4;r++)o[c*4+r]=a[r]*b[c*4]+a[4+r]*b[c*4+1]+a[8+r]*b[c*4+2]+a[12+r]*b[c*4+3];return o}
const cadeia=(...m)=>m.reduce(mul);
const T=(x,y,z)=>new Float32Array([1,0,0,0,0,1,0,0,0,0,1,0,x,y,z,1]);
const E=(x,y=x,z=x)=>new Float32Array([x,0,0,0,0,y,0,0,0,0,z,0,0,0,0,1]);
const RX=a=>{const c=Math.cos(a),s=Math.sin(a);return new Float32Array([1,0,0,0,0,c,s,0,0,-s,c,0,0,0,0,1])};
const RY=a=>{const c=Math.cos(a),s=Math.sin(a);return new Float32Array([c,0,-s,0,0,1,0,0,s,0,c,0,0,0,0,1])};
const RZ=a=>{const c=Math.cos(a),s=Math.sin(a);return new Float32Array([c,s,0,0,-s,c,0,0,0,0,1,0,0,0,0,1])};
const persp=(fov,asp,n,f)=>{const t=1/Math.tan(fov/2);return new Float32Array([t/asp,0,0,0,0,t,0,0,0,0,(f+n)/(n-f),-1,0,0,2*f*n/(n-f),0])};
const ID=T(0,0,0);
function programa(vs,fs){const p=gl.createProgram();
 for(const[t,s]of[[gl.VERTEX_SHADER,vs],[gl.FRAGMENT_SHADER,fs]]){const sh=gl.createShader(t);gl.shaderSource(sh,'#version 300 es\nprecision highp float;\n'+s);gl.compileShader(sh);
  if(!gl.getShaderParameter(sh,gl.COMPILE_STATUS))throw new Error(gl.getShaderInfoLog(sh));gl.attachShader(p,sh)}
 gl.linkProgram(p);if(!gl.getProgramParameter(p,gl.LINK_STATUS))throw new Error(gl.getProgramInfoLog(p));
 const u={};for(let i=0;i<gl.getProgramParameter(p,gl.ACTIVE_UNIFORMS);i++){const n=gl.getActiveUniform(p,i).name;u[n.replace('[0]','')]=gl.getUniformLocation(p,n)}
 return{p,u}}
// geometria low-poly: posição, normal, cor, balanço (negativo = brilha à noite)
function Geo(){this.v=[]}
Geo.prototype.tri=function(a,b,c,col,sw=0,centro,n){
 if(!n){const ux=b[0]-a[0],uy=b[1]-a[1],uz=b[2]-a[2],vx=c[0]-a[0],vy=c[1]-a[1],vz=c[2]-a[2];
  n=[uy*vz-uz*vy,uz*vx-ux*vz,ux*vy-uy*vx];const l=Math.hypot(...n)||1;n=n.map(k=>k/l);
  if(centro&&n[0]*((a[0]+b[0]+c[0])/3-centro[0])+n[1]*((a[1]+b[1]+c[1])/3-centro[1])+n[2]*((a[2]+b[2]+c[2])/3-centro[2])<0)n=n.map(k=>-k)}
 const s=Array.isArray(sw)?sw:[sw,sw,sw];[a,b,c].forEach((p,i)=>this.v.push(p[0],p[1],p[2],n[0],n[1],n[2],col[0],col[1],col[2],s[i]));return this};
Geo.prototype.quad=function(a,b,c,d,col,sw,centro,n){this.tri(a,b,c,col,sw,centro,n);return this.tri(a,c,d,col,sw,centro,n)};
Geo.prototype.caixa=function(x,y,z,w,h,d,col,sw=0){const m=[x,y,z],V=i=>[x+(i&1?w:-w)/2,y+(i&2?h:-h)/2,z+(i&4?d:-d)/2];
 [[0,1,3,2],[4,5,7,6],[0,1,5,4],[2,3,7,6],[0,2,6,4],[1,3,7,5]].forEach(([a,b,c,e])=>this.quad(V(a),V(b),V(c),V(e),col,sw,m));return this};
Geo.prototype.tronco=function(x,z,y0,y1,r0,r1,l,col,s0=0,s1=0){const c=[x,(y0+y1)/2,z];
 for(let i=0;i<l;i++){const a=i/l*TAU,b=(i+1)/l*TAU,k=.9+(i%2)*.18,cc=col.map(v=>v*k);
  const p=[x+Math.cos(a)*r0,y0,z+Math.sin(a)*r0],q=[x+Math.cos(b)*r0,y0,z+Math.sin(b)*r0],r=[x+Math.cos(b)*r1,y1,z+Math.sin(b)*r1],s=[x+Math.cos(a)*r1,y1,z+Math.sin(a)*r1];
  this.tri(p,q,r,cc,[s0,s0,s1],c);if(r1>0)this.tri(p,r,s,cc,[s0,s1,s1],c)}return this};
Geo.prototype.bola=function(cx,cy,cz,rx,ry,rz,col,sw=0,jit=.2){const t=1.618;
 const V=[[-1,t,0],[1,t,0],[-1,-t,0],[1,-t,0],[0,-1,t],[0,1,t],[0,-1,-t],[0,1,-t],[t,0,-1],[t,0,1],[-t,0,-1],[-t,0,1]].map(p=>{const k=(1+entre(-jit,jit))/1.902;return[cx+p[0]*k*rx,cy+p[1]*k*ry,cz+p[2]*k*rz]});
 '0,11,5 0,5,1 0,1,7 0,7,10 0,10,11 1,5,9 5,11,4 11,10,2 10,7,6 7,1,8 3,9,4 3,4,2 3,2,6 3,6,8 3,8,9 4,9,5 2,4,11 6,2,10 8,6,7 9,8,1'.split(' ').forEach(f=>{
  const[i,j,k]=f.split(',');const tom=entre(.88,1.12);this.tri(V[i],V[j],V[k],col.map(v=>v*tom),sw,[cx,cy,cz])});return this};
// copia outra geometria girada em Y e transladada
Geo.prototype.junta=function(g,x,y,z,a=0){const c=Math.cos(a),s=Math.sin(a),v=g.v;for(let i=0;i<v.length;i+=10)this.v.push(c*v[i]+s*v[i+2]+x,v[i+1]+y,-s*v[i]+c*v[i+2]+z,c*v[i+3]+s*v[i+5],v[i+4],-s*v[i+3]+c*v[i+5],v[i+6],v[i+7],v[i+8],v[i+9]);return this};
Geo.prototype.malha=function(lista){const m=malha(new Float32Array(this.v));if(lista)lista.push(m);return m};
function atributos(){[[0,3,0],[1,3,12],[2,3,24],[3,1,36]].forEach(([i,n,o])=>{gl.enableVertexAttribArray(i);gl.vertexAttribPointer(i,n,gl.FLOAT,false,40,o)})}
function malha(dados){const vao=gl.createVertexArray();gl.bindVertexArray(vao);const buf=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buf);gl.bufferData(gl.ARRAY_BUFFER,dados,gl.STATIC_DRAW);atributos();gl.bindVertexArray(null);return{vao,buf,n:dados.length/10}}
// variante instanciada que reaproveita os vértices da malha base
function instanciar(base,inst){const vao=gl.createVertexArray();gl.bindVertexArray(vao);gl.bindBuffer(gl.ARRAY_BUFFER,base.buf);atributos();
 const ibuf=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,ibuf);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(inst),gl.DYNAMIC_DRAW);
 [[4,4,0],[5,2,16]].forEach(([i,n,o])=>{gl.enableVertexAttribArray(i);gl.vertexAttribPointer(i,n,gl.FLOAT,false,24,o);gl.vertexAttribDivisor(i,1)});
 gl.bindVertexArray(null);return{vao,ibuf,n:base.n,inst:inst.length/6}}
function apagarMalha(m){gl.deleteVertexArray(m.vao);if(m.buf)gl.deleteBuffer(m.buf);if(m.ibuf)gl.deleteBuffer(m.ibuf)}
const orto=(r,n,f)=>new Float32Array([1/r,0,0,0,0,1/r,0,0,0,0,-2/(f-n),0,0,0,-(f+n)/(f-n),1]);
function olharPara(o,a){let z=[o[0]-a[0],o[1]-a[1],o[2]-a[2]];const n=v=>{const l=Math.hypot(...v)||1;return v.map(k=>k/l)};z=n(z);const x=n([z[2],0,-z[0]]),y=[z[1]*x[2]-z[2]*x[1],z[2]*x[0]-z[0]*x[2],z[0]*x[1]-z[1]*x[0]],d=v=>-(v[0]*o[0]+v[1]*o[1]+v[2]*o[2]);
 return new Float32Array([x[0],y[0],z[0],0,x[1],y[1],z[1],0,x[2],y[2],z[2],0,d(x),d(y),d(z),1])}
// semente numérica para um pedaço do mundo, independente da ordem de geração
const semearLocal=(i,j,sal)=>{estadoRnd=Math.floor(hash(i*7+sal*131,j*13-sal*71)*4294967296)|0;rnd();rnd()};
const rgb=h=>[1,3,5].map(i=>parseInt(h.slice(i,i+2),16)/255);
