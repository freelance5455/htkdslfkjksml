// ---------- configurações da versão 2 ----------
Object.assign(TAMANHOS,{pequeno:[300,'Pequeno'],medio:[700,'Médio'],grande:[2263,'Grande']});
Object.assign(QUALIDADES,{baixo:{res:.7,dist:110,grama:.25,part:false,sombra:0,efeitos:false},medio:{res:1,dist:160,grama:.6,part:true,sombra:1,efeitos:true},alto:{res:1,dist:220,grama:1,part:true,sombra:2,efeitos:true},ultra:{res:1.3,dist:290,grama:1,part:true,sombra:3,efeitos:true}});
Object.assign(CFG_PADRAO,{sombra:1,efeitos:true,dist:160,grama:.6,camera:0,clima:true,nomes:true});
CFG=Object.assign({},CFG_PADRAO,CFG);
try{const s=JSON.parse(localStorage.getItem('alone.cfg'))||{};if(s.sombra===undefined&&s.modo)Object.assign(CFG,QUALIDADES[s.modo==='touch'?'baixo':'medio'],{qualidade:s.modo==='touch'?'baixo':'medio'})}catch(e){}

// ---------- blocos de construção ----------
// [id, nome, texturas (topo, lado, base), dureza, ferramenta, nível, item que solta]
const BLOCOS=[null];const NB_={};
function defB(id,n,tex,dur,ferr,nivel,solta,extra){const t=tex.split(' ');const b=Object.assign({num:BLOCOS.length,id,n,tex:[t[0],t[1]||t[0],t[2]||t[1]||t[0]],dur,ferr,nivel:nivel||0,solta:solta===undefined?'b_'+id:solta,solido:true,opaco:true,luz:0},extra);BLOCOS.push(b);NB_[id]=b.num}
defB('grama','Grama','grama_topo grama_lado terra',.7,'pa',0,'b_terra');defB('terra','Terra','terra',.6,'pa');defB('areia','Areia','areia',.6,'pa');defB('cascalho','Cascalho','cascalho',.7,'pa');defB('neve','Neve','neve',.4,'pa');
defB('pedra','Pedra','pedra',2.2,'picareta',1,'pedra');defB('pedregulho','Pedregulho','pedregulho',2.2,'picareta',1);defB('tijolo_pedra','Tijolo de pedra','tijolo_pedra',2.4,'picareta',1);defB('pedra_polida','Pedra polida','pedra_polida',2.4,'picareta',1);defB('tijolo','Tijolo','tijolo',2,'picareta',1);defB('marmore','Mármore','marmore',2.2,'picareta',1);
defB('tronco','Tronco','tronco_topo tronco_lado tronco_topo',1.4,'machado',0,'madeira');defB('tabuas','Tábuas','tabuas',1.1,'machado');defB('estante','Estante','tabuas estante tabuas',1.2,'machado');defB('folhas','Folhas','folhas',.25,null,0,'b_folhas',{opaco:false});
defB('vidro','Vidro','vidro',.4,null,0,'b_vidro',{opaco:false});defB('palha','Palha','palha',.6,null);defB('gelo','Gelo','gelo',.8,'picareta');
for(const[c,n]of[['branca','branca'],['vermelha','vermelha'],['azul','azul'],['verde','verde'],['amarela','amarela'],['preta','preta'],['roxa','roxa'],['rosa','rosa']])defB('la_'+c,'Lã '+n,'la_'+c,.7,null);
defB('min_carvao','Minério de carvão','min_carvao',2.8,'picareta',1,'carvao');defB('min_ferro','Minério de ferro','min_ferro',3.2,'picareta',2,'ferro');defB('min_ouro','Minério de ouro','min_ouro',3.6,'picareta',3,'ouro');
defB('min_cristal','Minério de cristal','min_cristal',3.8,'picareta',3,'cristal',{luz:.55});defB('min_diamante','Minério de diamante','min_diamante',4.2,'picareta',3,'diamante',{luz:.25});defB('min_esmeralda','Minério de esmeralda','min_esmeralda',4,'picareta',3,'esmeralda',{luz:.25});
defB('bloco_ferro','Bloco de ferro','bloco_ferro',3,'picareta',2);defB('bloco_ouro','Bloco de ouro','bloco_ouro',3,'picareta',2);defB('bloco_cristal','Bloco de cristal','bloco_cristal',3,'picareta',2,'b_bloco_cristal',{luz:.8});defB('bloco_diamante','Bloco de diamante','bloco_diamante',3.5,'picareta',3);
defB('lampada','Lâmpada','lampada',.5,null,0,'b_lampada',{luz:1});defB('abobora','Abóbora','abobora_topo abobora abobora_topo',.9,'machado');defB('obsidiana','Obsidiana','obsidiana',7,'picareta',4);
defB('tnt','Dinamite','tnt_topo tnt_lado tnt_topo',.3,null);defB('rocha_mae','Rocha-mãe','rocha_mae',Infinity,null,9,null);
defB('lava','Lava','lava',Infinity,null,9,null,{solido:false,luz:1,lava:true});
for(let n=0;n<=4;n++)defB('agua'+n,'Água','agua',Infinity,null,9,null,{solido:false,opaco:false,agua:n+1});
const CORES_BLOCO={grama:'#5d9b34',terra:'#8a5a35',areia:'#dcc98a',cascalho:'#8d8780',neve:'#eef4f6',pedra:'#8a8d8c',pedregulho:'#7d807e',tijolo_pedra:'#7f8382',pedra_polida:'#a7aaa8',tijolo:'#a8503a',marmore:'#e6e2da',tronco:'#6e4a28',tabuas:'#b8894e',estante:'#9a6a3a',folhas:'#3f7d2c',vidro:'#bfe6ee',palha:'#d9b54a',gelo:'#a9d6f0',la_branca:'#eeeeea',la_vermelha:'#c23a32',la_azul:'#3558b8',la_verde:'#4a8a32',la_amarela:'#e8c32c',la_preta:'#26262a',la_roxa:'#7c3fae',la_rosa:'#e08aa8',
 bloco_ferro:'#d5dade',bloco_ouro:'#f6c62e',bloco_cristal:'#7fe3ff',bloco_diamante:'#59e8d8',lampada:'#ffe39a',abobora:'#e07f1c',obsidiana:'#231a33',tnt:'#c8362c',rocha_mae:'#38393a',lava:'#ff6a12',min_carvao:'#303033',min_ferro:'#d08a5a',min_ouro:'#ffd23d',min_cristal:'#7fe3ff',min_diamante:'#4ff0d0',min_esmeralda:'#2fcc5a'};
for(const b of BLOCOS)if(b&&!b.agua&&!b.lava)item('b_'+b.id,b.n,'cubo',{ic:'cubo',cor:CORES_BLOCO[b.id],bloco:b.num,pilha:64,valor:b.id.startsWith('bloco_')?60:b.id.startsWith('min_')?10:2});

// ---------- ferramentas, armas e itens novos ----------
const MATS={madeira:['de madeira','#b98a4e',1,'madeira'],pedra:['de pedra','#9aa09a',2,'pedra'],ferro:['de ferro','#cfd6dc',3,'lingote'],diamante:['de diamante','#59e8d8',4,'diamante']};
ITENS.picareta_ferro.nivel=3;
for(const[m,[nm,cor,nv,base]]of Object.entries(MATS)){ferr('pa_'+m,'Pá '+nm,'pa',nv,4+nv*2,cor,8*nv*nv);ferr('enxada_'+m,'Enxada '+nm,'enxada',nv,3+nv,cor,8*nv*nv)}
ferr('picareta_diamante','Picareta de diamante','picareta',4,15,'#59e8d8',180);ferr('machado_diamante','Machado de diamante','machado',4,21,'#59e8d8',180);
arma('espada_diamante','Espada de diamante','espada',50,3.2,.4,'#59e8d8',320);arma('espada_ouro','Espada de ouro','espada',24,2.9,.3,'#ffd23d',110);
item('besta','Besta','arma',{ic:'besta',cor:'#8a5a2a',dano:34,alcance:70,cad:1.25,distancia:true,valor:90});
const util=(id,n,ic,cor,valor,extra)=>item(id,n,'ferramenta',Object.assign({ic,cor,ferramenta:ic,nivel:1,dano:4,valor},extra));
util('tesoura','Tesoura','tesoura','#cfd6dc',20);util('vara_pesca','Vara de pesca','vara','#b98a4e',15);util('balde','Balde','balde','#cfd6dc',25,{pilha:8});util('balde_agua','Balde com água','balde','#3f8fe0',27);util('balde_leite','Balde com leite','balde','#f4f1e6',30);
util('isqueiro','Isqueiro','isqueiro','#cfd6dc',18);util('martelo','Martelo','martelo','#8d949a',25,{dano:14});util('bussola','Bússola','bussola','#d8473c',30);util('relogio','Relógio','relogio','#ffd23d',30);util('luneta','Luneta','luneta','#c9973a',45);
util('barco','Barco','barco','#a8743c',20);util('mapa_tesouro','Mapa do tesouro','mapa','#e6d3a3',60,{pilha:1});util('nucleo_golem','Núcleo de golem','nucleo','#58e0c0',160,{pilha:3});
for(const[id,n,cor]of[['diamante','Diamante','#59e8d8'],['esmeralda','Esmeralda','#2fcc5a']])item(id,n,'recurso',{ic:'cristal',cor,valor:id==='diamante'?70:50});
item('polvora','Pólvora','recurso',{ic:'po',cor:'#555a60',valor:6});item('linha','Linha','recurso',{ic:'fibra',cor:'#eeeeee',valor:2});item('gosma','Gosma','recurso',{ic:'po',cor:'#6fd65a',valor:4});item('sementes','Sementes','recurso',{ic:'semente',cor:'#b9a04a',valor:1});
comida('cenoura','Cenoura','#e8801f','trigo',10,2,4);comida('batata','Batata','#c9a566','pao',6,0,3);comida('batata_assada','Batata assada','#b8803a','pao',26,5,6);comida('peixe_cru','Peixe cru','#7fa8c8','peixe',9,-2,5);comida('peixe_assado','Peixe assado','#c98a4a','peixe',30,10,10);
comida('bife','Bife assado','#7a3a1e','carne',45,14,12);comida('carne_vaca','Carne bovina','#c84a56','carne',12,-3,5);comida('bolo','Bolo','#f0b8c0','bolo',55,18,22);comida('torta','Torta de abóbora','#d88a28','bolo',42,12,16);comida('mel','Mel','#f0a818','pocao',16,8,9);
const pocao=(id,n,cor,efeito,valor)=>item(id,n,'comida',{ic:'pocao',cor,comida:0,cura:0,efeito,valor,pilha:8});
pocao('pocao_velocidade','Poção de velocidade','#5ad8ff','veloz',30);pocao('pocao_salto','Poção de salto','#7dff6a','salto',30);pocao('pocao_agua','Poção de fôlego','#3a6cff','folego',30);pocao('pocao_forca','Poção de força','#ff9a2a','forca',40);
// armaduras por peça: [capacete, peitoral, calça, botas]
const ARMADURAS={couro:['de couro','#a5683a',[.05,.1,.07,.04],'couro'],ferro:['de ferro','#cfd6dc',[.09,.18,.13,.08],'lingote'],ouro:['de ouro','#ffd23d',[.08,.16,.11,.07],'ouro'],cristal:['de cristal','#7fe3ff',[.11,.23,.17,.1],'cristal'],diamante:['de diamante','#3fd8c4',[.13,.27,.2,.12],'diamante']};
const PECAS=[['capacete','Capacete','capacete',4],['armadura','Peitoral','armadura',7],['calca','Calças','calca',6],['botas','Botas','botas',3]];
for(const[m,[nm,cor,def]]of Object.entries(ARMADURAS))PECAS.forEach(([p,n,ic],s)=>item(`${p}_${m}`,`${n} ${nm}`,'armadura',{ic,cor,slot:s,material:m,defesa:def[s],valor:Math.round(def[s]*(m==='couro'?220:m==='diamante'?900:500))}));
item('escudo','Escudo','armadura',{ic:'escudo',cor:'#a8743c',slot:4,defesa:.12,valor:40});ITENS.tocha.slot=4;
const MOBS_OVO=['cervo','coelho','javali','lobo','ovelha','galinha','vaca','urso','zumbi','esqueleto','aranha','gosma','golem','rei_ossos'];
const NOMES_MOB={cervo:'Cervo',coelho:'Coelho',javali:'Javali',lobo:'Lobo',ovelha:'Ovelha',galinha:'Galinha',vaca:'Vaca',urso:'Urso',zumbi:'Zumbi',esqueleto:'Esqueleto',aranha:'Aranha',gosma:'Gosma',golem:'Golem',rei_ossos:'Rei dos Ossos'};
MOBS_OVO.forEach((m,i)=>item('ovo_'+m,'Invocar '+NOMES_MOB[m].toLowerCase(),'ovo',{ic:'ovo',cor:`hsl(${i*47%360} 60% 55%)`,mob:m,pilha:64}));

// ---------- receitas novas ----------
RECEITAS.splice(RECEITAS.findIndex(r=>r.id==='armadura_cristal'),1);
const RC=(id,qtd,ing,est='bancada')=>RECEITAS.push(R(id,qtd,ing,est));
RC('b_tabuas',8,{madeira:2},null);RC('b_tronco',4,{madeira:4},null);RC('b_pedra',4,{pedra:4},null);RC('b_pedregulho',4,{pedra:3});RC('b_tijolo_pedra',4,{pedra:4});RC('b_pedra_polida',4,{pedra:5});RC('b_marmore',4,{pedra:4,la:1});
RC('b_vidro',2,{b_areia:2,carvao:1},'fogo');RC('b_tijolo',4,{b_terra:4,carvao:1},'fogo');RC('b_palha',4,{trigo:4});RC('b_estante',2,{madeira:4,couro:1});RC('b_folhas',8,{fibra:4},null);
RC('b_la_branca',2,{la:1});for(const[c,i]of[['vermelha','frutas'],['azul','cristal'],['verde','fibra'],['amarela','trigo'],['preta','carvao'],['roxa','cogumelo'],['rosa','maca']])RC('b_la_'+c,4,{la:2,[i]:1});
RC('b_lampada',4,{b_vidro:1,carvao:2});RC('b_bloco_ferro',1,{lingote:4});RC('b_bloco_ouro',1,{ouro:4});RC('b_bloco_cristal',1,{cristal:4});RC('b_bloco_diamante',1,{diamante:4});RC('b_tnt',2,{polvora:3,b_areia:2});
for(const[m,[,,,base]]of Object.entries(MATS)){const e=m==='madeira'?null:'bancada';RC('pa_'+m,1,{[base]:m==='madeira'?3:2,madeira:2},e);RC('enxada_'+m,1,{[base]:m==='madeira'?4:2,madeira:2},e)}
RC('picareta_diamante',1,{diamante:3,madeira:3});RC('machado_diamante',1,{diamante:3,madeira:3});RC('espada_diamante',1,{diamante:4,lingote:2});RC('espada_ouro',1,{ouro:4,madeira:2});RC('besta',1,{madeira:6,lingote:2,linha:3});RC('arco',1,{madeira:5,linha:3});
RC('tesoura',1,{lingote:2});RC('vara_pesca',1,{madeira:3,fibra:4},null);RC('balde',1,{lingote:3});RC('isqueiro',1,{lingote:1,pedra:1});RC('martelo',1,{pedra:5,madeira:3});RC('bussola',1,{lingote:2,cristal:1});RC('relogio',1,{ouro:2,cristal:1});RC('luneta',1,{b_vidro:2,ouro:1});
RC('barco',1,{madeira:10});RC('escudo',1,{madeira:6,lingote:1});RC('nucleo_golem',1,{b_bloco_ferro:2,esmeralda:2,cristal:1});
for(const[m,[,,,base]]of Object.entries(ARMADURAS))PECAS.forEach(([p,,,q],s)=>{const id=`${p}_${m}`;if(!RECEITAS.some(r=>r.id===id))RC(id,1,{[base]:q})});
RC('batata_assada',1,{batata:1},'fogo');RC('peixe_assado',1,{peixe_cru:1},'fogo');RC('bife',1,{carne_vaca:1},'fogo');RC('bolo',1,{trigo:3,balde_leite:1,frutas:3},'fogo');RC('torta',1,{b_abobora:1,trigo:2},'fogo');RC('sementes',3,{trigo:1},null);
RC('pocao_velocidade',1,{mel:1,fibra:4,cristal:1},'fogo');RC('pocao_salto',1,{gosma:3,frutas:3},'fogo');RC('pocao_agua',1,{peixe_cru:2,cogumelo:2},'fogo');RC('pocao_forca',1,{polvora:2,esmeralda:1},'fogo');

// ---------- ícones novos ----------
{const anterior=icone;const NOVOS={pa(g,P,O,L,Q,k,c){L([20,54],[40,22],c);P([[34,20],[44,8],[56,18],[48,34]],k)},enxada(g,P,O,L,Q,k,c){L([18,56],[42,12],c);P([[40,8],[60,22],[54,28],[36,18]],k)},
 tesoura(g,P,O,L,Q,k){L([16,12],[44,44],k);L([48,12],[20,44],k);O(16,50,8,'#c33');O(48,50,8,'#c33')},vara(g,P,O,L,Q,k,c){L([8,56],[50,8],c,5);L([50,8],[52,44],'#eee',2);O(52,48,5,'#d33')},
 balde(g,P,O,L,Q,k){P([[12,20],[52,20],[45,54],[19,54]],'#aab2b8');O(32,20,20,k,7)},isqueiro(g,P,O,L,Q,k){Q(16,30,24,24,k);P([[40,6],[54,24],[46,34],[36,26]],'#ff8a2a')},martelo(g,P,O,L,Q,k,c){L([18,56],[38,26],c,8);P([[24,8],[56,28],[46,42],[14,22]],k)},
 bussola(g,P,O,L,Q,k){O(32,32,24,'#ddd');P([[32,12],[38,32],[26,32]],k);P([[32,52],[38,32],[26,32]],'#555')},relogio(g,P,O,L,Q,k){O(32,32,24,k);O(32,32,17,'#fff');L([32,32],[32,20],'#222',3);L([32,32],[43,36],'#222',3)},luneta(g,P,O,L,Q,k){L([10,50],[34,30],k,16);L([34,30],[54,14],'#7a5a22',10)},
 barco(g,P,O,L,Q,k){P([[4,30],[60,30],[48,50],[16,50]],k);L([32,30],[32,8],'#654',4);P([[34,8],[52,24],[34,24]],'#eee')},mapa(g,P,O,L,Q,k){P([[8,14],[24,8],[40,14],[56,8],[56,50],[40,56],[24,50],[8,56]],k);L([22,24],[42,42],'#c22',5);L([42,24],[22,42],'#c22',5)},nucleo(g,P,O,L,Q,k){Q(12,12,40,40,'#777d78');O(32,32,13,k);O(28,28,4,'#fff')},
 capacete(g,P,O,L,Q,k){P([[12,46],[12,26],[22,14],[42,14],[52,26],[52,46],[42,46],[42,32],[22,32],[22,46]],k)},calca(g,P,O,L,Q,k){P([[16,10],[48,10],[52,56],[38,56],[32,28],[26,56],[12,56]],k)},botas(g,P,O,L,Q,k){P([[10,20],[26,20],[26,52],[6,52],[6,40],[10,40]],k);P([[38,20],[54,20],[54,40],[58,40],[58,52],[38,52]],k)},
 escudo(g,P,O,L,Q,k){P([[12,8],[52,8],[52,34],[32,58],[12,34]],k);L([32,12],[32,50],'#dde',5);L([16,26],[48,26],'#dde',5)},ovo(g,P,O,L,Q,k){O(32,34,19,k,24);O(25,26,5,'#fff8');O(40,42,5,'#0004')},semente(g,P,O,L,Q,k){[[20,24],[38,18],[44,40],[24,44],[32,32]].forEach(p=>O(p[0],p[1],5,k,8))},
 peixe(g,P,O,L,Q,k){O(28,32,18,k,12);P([[44,32],[60,18],[60,46]],k);O(20,28,3,'#111')},bolo(g,P,O,L,Q,k){Q(10,30,44,22,k);Q(10,26,44,8,'#fff');for(const x of[20,32,44])O(x,22,4,'#c22')},besta(g,P,O,L,Q,k,c){L([14,52],[46,20],c,8);L([30,10],[56,36],k,6);L([30,10],[40,26],'#eee',2);L([56,36],[40,26],'#eee',2)},po(g,P,O,L,Q,k){[[22,42],[40,42],[31,30],[48,50],[14,50],[32,48]].forEach(p=>O(p[0],p[1],9,k))}};
 icone=function(id){if(cacheIcone[id])return cacheIcone[id];const it=ITENS[id],f=NOVOS[it.ic];if(!f&&it.ic!=='cubo')return anterior(id);const c=document.createElement('canvas');c.width=c.height=64;const g=c.getContext('2d');
  if(it.ic==='cubo'){const b=BLOCOS[it.bloco];g.imageSmoothingEnabled=false;const face=(t,m,sombra)=>{g.setTransform(...m);g.drawImage(texCanvas(t),0,0,16,16,0,0,16,16);if(sombra){g.fillStyle=`rgba(0,0,0,${sombra})`;g.fillRect(0,0,16,16)}};
   face(b.tex[0],[1.7,-.85,1.7,.85,5,18],0);face(b.tex[1],[1.7,.85,0,1.7,5,18],.18);face(b.tex[1],[1.7,-.85,0,1.7,32.2,31.6],.38);return cacheIcone[id]=c.toDataURL()}
  const P=(pts,cor)=>{g.fillStyle=cor;g.beginPath();pts.forEach((p,i)=>g[i?'lineTo':'moveTo'](p[0],p[1]));g.closePath();g.fill();g.strokeStyle='#0009';g.lineWidth=2;g.stroke()};
  const O=(x,y,r,cor,ry=r)=>{g.fillStyle=cor;g.beginPath();g.ellipse(x,y,r,ry,0,0,TAU);g.fill();g.strokeStyle='#0009';g.lineWidth=2;g.stroke()};
  const L=(a,b,cor,w=6)=>{g.strokeStyle=cor;g.lineWidth=w;g.lineCap='round';g.beginPath();g.moveTo(...a);g.lineTo(...b);g.stroke()};const Q=(x,y,w,h,cor)=>P([[x,y],[x+w,y],[x+w,y+h],[x,y+h]],cor);
  f(g,P,O,L,Q,it.cor,'#8a5a2a');return cacheIcone[id]=c.toDataURL()}}
