// ---------- itens ----------
const ITENS={};
function item(id,n,cat,extra){ITENS[id]=Object.assign({id,n,cat,pilha:['ferramenta','arma','armadura'].includes(cat)?1:cat==='municao'?60:30,dano:4,alcance:2.4,cad:.5,valor:1},extra)}
// recursos
item('madeira','Madeira','recurso',{ic:'tronco',cor:'#9a6a35',valor:2});
item('pedra','Pedra','recurso',{ic:'rocha',cor:'#9aa09a',valor:2});
item('carvao','Carvão','recurso',{ic:'rocha',cor:'#2c2c30',valor:4});
item('ferro','Minério de ferro','recurso',{ic:'minerio',cor:'#d08a5a',valor:7});
item('lingote','Lingote de ferro','recurso',{ic:'barra',cor:'#cfd6dc',valor:18});
item('ouro','Ouro','recurso',{ic:'minerio',cor:'#ffd23d',valor:25});
item('cristal','Cristal','recurso',{ic:'cristal',cor:'#7fe3ff',valor:40});
item('fibra','Fibra','recurso',{ic:'fibra',cor:'#9cc45a',valor:1});
item('couro','Couro','recurso',{ic:'couro',cor:'#a5683a',valor:6});
item('la','Lã','recurso',{ic:'nuvem',cor:'#eeeae0',valor:5});
item('pena','Pena','recurso',{ic:'pena',cor:'#e8e8f0',valor:2});
item('osso','Osso','recurso',{ic:'osso',cor:'#e8e2c8',valor:3});
// comidas e cura (comida = fome recuperada, cura = vida)
const comida=(id,n,cor,ic,fome,cura,valor)=>item(id,n,'comida',{ic,cor,comida:fome,cura,valor});
comida('maca','Maçã','#d8382c','fruta',14,3,3);comida('frutas','Frutas silvestres','#8a3fb0','bagas',8,2,2);
comida('cogumelo','Cogumelo','#c4372a','cogumelo',7,0,2);comida('trigo','Trigo','#e3bd4f','trigo',3,0,3);
comida('carne_crua','Carne crua','#d9687a','carne',10,-4,4);comida('carne_assada','Carne assada','#8b4a24','carne',38,12,9);
comida('pao','Pão','#c98f45','pao',28,6,8);comida('ensopado','Ensopado','#b0602a','tigela',60,30,18);
comida('carne_podre','Carne podre','#6d7a3a','carne',9,-12,1);comida('atadura','Atadura','#f0ede0','atadura',0,35,10);
comida('pocao','Poção de vida','#ff4f6a','pocao',0,80,35);
// ferramentas
const ferr=(id,n,tipo,nivel,dano,cor,valor)=>item(id,n,'ferramenta',{ic:tipo,cor,ferramenta:tipo,nivel,dano,alcance:2.7,cad:.55,valor});
ferr('machado_madeira','Machado de madeira','machado',1,7,'#b98a4e',10);ferr('machado_pedra','Machado de pedra','machado',2,10,'#9aa09a',22);ferr('machado_ferro','Machado de ferro','machado',3,15,'#cfd6dc',60);
ferr('picareta_madeira','Picareta de madeira','picareta',1,5,'#b98a4e',10);ferr('picareta_pedra','Picareta de pedra','picareta',2,8,'#9aa09a',22);ferr('picareta_ferro','Picareta de ferro','picareta',3,11,'#cfd6dc',60);
item('tocha','Tocha','ferramenta',{ic:'tocha',cor:'#ffab33',pilha:20,dano:6,valor:3});
// armas
const arma=(id,n,ic,dano,alcance,cad,cor,valor)=>item(id,n,'arma',{ic,cor,dano,alcance,cad,valor});
arma('faca','Faca','faca',11,2.3,.28,'#cfd6dc',18);arma('faca_cacador','Faca de caçador','faca',17,2.4,.28,'#8fe0c8',50);
arma('espada_madeira','Espada de madeira','espada',12,2.8,.5,'#b98a4e',12);arma('espada_pedra','Espada de pedra','espada',17,2.8,.52,'#9aa09a',28);
arma('espada_ferro','Espada de ferro','espada',27,2.9,.48,'#cfd6dc',90);arma('espada_cristal','Espada de cristal','espada',42,3.1,.42,'#7fe3ff',240);
arma('lanca','Lança','lanca',19,4,.75,'#c9c2b0',35);arma('machado_guerra','Machado de guerra','machado',34,2.9,.85,'#a33b30',120);
item('arco','Arco','arma',{ic:'arco',cor:'#a9713a',dano:20,alcance:60,cad:.85,distancia:true,valor:40});
item('flecha','Flecha','municao',{ic:'flecha',cor:'#d8d0b8',valor:1});
// armaduras (defesa = fração do dano bloqueada)
item('armadura_couro','Armadura de couro','armadura',{ic:'armadura',cor:'#a5683a',defesa:.2,valor:45});
item('armadura_ferro','Armadura de ferro','armadura',{ic:'armadura',cor:'#cfd6dc',defesa:.42,valor:130});
item('armadura_cristal','Armadura de cristal','armadura',{ic:'armadura',cor:'#7fe3ff',defesa:.6,valor:320});
// construções
const obraItem=(id,n,cor,ic,valor)=>item(id,n,'bloco',{ic,cor,pilha:20,valor});
obraItem('bancada','Mesa de artesanato','#b57b3e','mesa',8);obraItem('fogueira','Fogueira','#ff7a2f','fogo',6);
obraItem('parede','Parede de madeira','#a8743c','parede',3);obraItem('parede_pedra','Parede de pedra','#9aa09a','parede',4);
obraItem('porta','Porta','#8a5a2a','porta',5);obraItem('piso','Piso','#bd8c52','piso',2);obraItem('cerca','Cerca','#a8743c','cerca',2);
obraItem('poste','Poste com tocha','#ffab33','tocha',5);obraItem('bau','Baú','#9a6a2c','bau',8);obraItem('cama','Cama','#c8453a','cama',14);
obraItem('farol','Farol de sinal','#7fe3ff','farol',200);

// ---------- receitas (est: null = em qualquer lugar) ----------
const R=(id,qtd,ing,est=null)=>({id,qtd,ing,est});
const RECEITAS=[
 R('bancada',1,{madeira:6}),R('tocha',4,{madeira:1,fibra:1}),R('fogueira',1,{madeira:4,pedra:3}),R('atadura',1,{fibra:4}),R('machado_madeira',1,{madeira:4}),
 R('picareta_madeira',1,{madeira:5},'bancada'),R('espada_madeira',1,{madeira:6},'bancada'),R('faca',1,{madeira:2,pedra:3},'bancada'),
 R('machado_pedra',1,{madeira:3,pedra:5},'bancada'),R('picareta_pedra',1,{madeira:3,pedra:6},'bancada'),R('espada_pedra',1,{madeira:3,pedra:7},'bancada'),
 R('lanca',1,{madeira:8,pedra:3,fibra:3},'bancada'),R('arco',1,{madeira:7,fibra:8},'bancada'),R('flecha',8,{madeira:2,pedra:1},'bancada'),R('flecha',12,{osso:2,pena:2},'bancada'),
 R('armadura_couro',1,{couro:8,fibra:4},'bancada'),R('parede',2,{madeira:3},'bancada'),R('parede_pedra',2,{pedra:5},'bancada'),R('porta',1,{madeira:5},'bancada'),R('piso',4,{madeira:3},'bancada'),
 R('cerca',3,{madeira:3},'bancada'),R('poste',2,{madeira:3,carvao:1},'bancada'),R('bau',1,{madeira:10},'bancada'),R('cama',1,{madeira:6,la:3},'bancada'),
 R('lingote',1,{ferro:2,carvao:1},'fogo'),R('machado_ferro',1,{lingote:3,madeira:3},'bancada'),R('picareta_ferro',1,{lingote:3,madeira:3},'bancada'),
 R('espada_ferro',1,{lingote:4,madeira:2},'bancada'),R('armadura_ferro',1,{lingote:8,couro:3},'bancada'),R('machado_guerra',1,{lingote:5,ouro:2,madeira:4},'bancada'),
 R('espada_cristal',1,{cristal:5,lingote:3,ouro:2},'bancada'),R('armadura_cristal',1,{cristal:8,lingote:5,ouro:4},'bancada'),
 R('carne_assada',1,{carne_crua:1},'fogo'),R('pao',1,{trigo:3},'fogo'),R('ensopado',1,{carne_crua:1,cogumelo:2,frutas:2},'fogo'),R('pocao',1,{cogumelo:3,frutas:5,cristal:1},'fogo'),
 R('farol',1,{cristal:4,lingote:5,madeira:20,ouro:2},'bancada')];
const NOME_EST={bancada:'perto de uma mesa de artesanato',fogo:'perto de uma fogueira'};

// ---------- ícones desenhados em canvas ----------
const cacheIcone={};
function icone(id){if(cacheIcone[id])return cacheIcone[id];const it=ITENS[id],c=document.createElement('canvas');c.width=c.height=64;const g=c.getContext('2d'),k=it.cor,cabo='#8a5a2a';
 const P=(pts,cor)=>{g.fillStyle=cor;g.beginPath();pts.forEach((p,i)=>g[i?'lineTo':'moveTo'](p[0],p[1]));g.closePath();g.fill();g.strokeStyle='#0009';g.lineWidth=2;g.stroke()};
 const O=(x,y,r,cor,ry=r)=>{g.fillStyle=cor;g.beginPath();g.ellipse(x,y,r,ry,0,0,TAU);g.fill();g.strokeStyle='#0009';g.lineWidth=2;g.stroke()};
 const L=(a,b,cor,w=6)=>{g.strokeStyle=cor;g.lineWidth=w;g.lineCap='round';g.beginPath();g.moveTo(...a);g.lineTo(...b);g.stroke()};
 const Q=(x,y,w,h,cor)=>P([[x,y],[x+w,y],[x+w,y+h],[x,y+h]],cor);
 ({tronco(){P([[10,40],[40,10],[54,24],[24,54]],k);O(17,47,10,'#d9ac6c')},rocha(){P([[10,44],[18,22],[38,14],[54,30],[50,50],[24,54]],k)},
  minerio(){P([[10,44],[18,22],[38,14],[54,30],[50,50],[24,54]],'#6f756f');[[24,32],[40,28],[34,44]].forEach(p=>O(p[0],p[1],6,k))},
  barra(){P([[10,42],[22,22],[54,22],[44,42]],k);P([[10,42],[44,42],[44,52],[10,52]],'#8f969c')},cristal(){P([[32,6],[46,26],[32,58],[18,26]],k);P([[32,6],[46,26],[32,28]],'#d8f8ff')},
  fibra(){for(let i=0;i<5;i++)L([32,54],[12+i*10,12+Math.abs(2-i)*6],k,5)},couro(){P([[14,14],[26,20],[38,20],[50,14],[46,32],[52,50],[36,44],[28,44],[12,50],[18,32]],k)},
  nuvem(){[[22,36],[34,28],[44,36],[32,40]].forEach(p=>O(p[0],p[1],13,k))},pena(){L([14,52],[48,14],'#888',3);P([[20,46],[24,26],[48,12],[44,34]],k)},
  osso(){L([18,46],[46,18],k,9);[[14,44],[20,50],[44,14],[50,20]].forEach(p=>O(p[0],p[1],6,k))},
  fruta(){O(32,36,18,k);L([32,20],[36,8],cabo,4);O(42,13,7,'#5a9a32',4)},bagas(){[[24,40],[40,40],[32,28],[32,48]].forEach(p=>O(p[0],p[1],9,k))},
  cogumelo(){Q(26,32,12,22,'#eee3c8');P([[8,34],[18,14],[46,14],[56,34]],k);O(24,24,4,'#fff');O(40,28,3,'#fff')},
  trigo(){for(const x of[22,32,42]){L([32,56],[x,16],'#b99534',3);O(x,16,5,k,11)}},carne(){O(36,28,18,k,15);L([22,40],[10,54],'#eee8d8',8)},
  pao(){O(32,34,24,k,15);for(const x of[20,32,44])L([x,26],[x+6,36],'#f0c880',4)},tigela(){O(32,28,22,'#d98c3c',9);P([[10,30],[54,30],[44,50],[20,50]],'#7a4a28')},
  atadura(){O(32,32,20,k);Q(28,18,8,28,'#d8473c');Q(18,28,28,8,'#d8473c')},pocao(){Q(26,8,12,14,'#cfe8ee');O(32,38,18,k);O(25,32,5,'#ffd0d8')},
  machado(){L([18,54],[40,16],cabo);P([[34,10],[56,12],[52,36],[36,24]],k)},picareta(){L([20,54],[38,18],cabo);g.strokeStyle=k;g.lineWidth=9;g.beginPath();g.moveTo(10,24);g.quadraticCurveTo(36,0,58,30);g.stroke()},
  tocha(){L([24,56],[36,28],cabo,8);O(38,20,11,k,14);O(38,23,5,'#ffe9a0',7)},faca(){P([[24,38],[50,8],[48,24],[32,44]],k);L([27,42],[16,54],cabo,8)},
  espada(){P([[22,36],[52,6],[58,6],[58,12],[28,42]],k);L([16,32],[34,50],'#c9a030',6);L([22,43],[11,54],cabo,7)},
  lanca(){L([10,56],[44,22],cabo,5);P([[40,14],[58,6],[50,24],[42,24]],k)},arco(){g.strokeStyle=k;g.lineWidth=7;g.beginPath();g.arc(14,50,40,-1.65,.08);g.stroke();L([11,10],[54,53],'#ddd',2)},
  flecha(){L([12,52],[48,16],cabo,4);P([[44,10],[58,6],[54,20]],'#aab');P([[8,46],[18,46],[12,52],[18,58],[8,56]],k)},
  armadura(){P([[14,14],[26,10],[32,18],[38,10],[50,14],[54,28],[44,28],[44,54],[20,54],[20,28],[10,28]],k)},
  mesa(){Q(8,18,48,14,k);Q(12,32,8,22,cabo);Q(44,32,8,22,cabo);L([18,24],[46,24],'#e0b070',3)},
  fogo(){L([12,52],[52,44],cabo,7);L([12,44],[52,52],cabo,7);P([[32,6],[46,32],[38,44],[24,44],[18,30],[28,32]],k)},
  parede(){Q(8,12,48,42,k);for(const y of[26,40])L([8,y],[56,y],'#0006',3);L([32,12],[32,26],'#0006',3);L([22,26],[22,40],'#0006',3);L([40,40],[40,54],'#0006',3)},
  porta(){Q(18,8,28,50,k);O(39,34,3,'#ffd23d')},piso(){P([[6,40],[24,22],[58,26],[42,48]],k);L([24,43],[42,24],'#0006',2)},
  cerca(){for(const x of[10,28,46])Q(x,14,8,42,k);Q(6,22,52,6,cabo);Q(6,40,52,6,cabo)},bau(){Q(10,26,44,28,k);P([[10,26],[16,14],[48,14],[54,26]],'#b8843c');Q(28,24,8,12,'#ffd23d')},
  cama(){Q(8,32,48,14,k);Q(10,26,14,8,'#fff');Q(8,46,6,10,cabo);Q(50,46,6,10,cabo)},farol(){P([[22,56],[26,24],[38,24],[42,56]],'#8a8f90');P([[32,4],[42,16],[32,28],[22,16]],k)}
 })[it.ic]();
 return cacheIcone[id]=c.toDataURL()}

// ---------- configurações ----------
const CFG_PADRAO={modo:null,qualidade:'medio',res:1,dist:190,grama:.75,part:true,fov:70,brilho:1,fps:false,vMestre:.7,vFx:.8,vAmb:.6,vMus:.35,sens:1,invY:false,dif:'normal',durDia:8,dicas:true};
const QUALIDADES={baixo:{res:.65,dist:120,grama:.3,part:false},medio:{res:1,dist:190,grama:.75,part:true},alto:{res:1.25,dist:270,grama:1,part:true}};
const DIFICULDADES={pacifico:{n:'Pacífico',max:0,dano:0,hp:1},facil:{n:'Fácil',max:4,dano:.6,hp:.8},normal:{n:'Normal',max:7,dano:1,hp:1},dificil:{n:'Difícil',max:12,dano:1.4,hp:1.35}};
const TAMANHOS={pequeno:[200,'Pequeno'],medio:[300,'Médio'],grande:[400,'Grande']};
let CFG={...CFG_PADRAO};
try{Object.assign(CFG,JSON.parse(localStorage.getItem('alone.cfg'))||{})}catch(e){}
const salvarCfg=()=>{try{localStorage.setItem('alone.cfg',JSON.stringify(CFG))}catch(e){}};
item('moeda','Moedas','dinheiro',{ic:'moeda',cor:'#ffd23d',pilha:999});
{const antigo=icone;icone=function(id){if(id!=='moeda')return antigo(id);if(cacheIcone[id])return cacheIcone[id];const c=document.createElement('canvas');c.width=c.height=64;const g=c.getContext('2d');
 for(const[x,y]of[[24,40],[40,40],[32,24]]){g.fillStyle='#ffd23d';g.beginPath();g.arc(x,y,13,0,TAU);g.fill();g.strokeStyle='#7a5600';g.lineWidth=3;g.stroke()}return cacheIcone[id]=c.toDataURL()}}
