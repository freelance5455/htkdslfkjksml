package br.alone.servidor;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/** Opcional: hospeda uma sala a partir de um computador. Uso: java -jar alone-servidor.jar Alone.html [porta] */
public final class ServidorPC {
    public static void main(String[] args) throws Exception {
        final Path html = Paths.get(args.length > 0 ? args[0] : "Alone.html");
        if (!Files.isRegularFile(html)) {
            System.err.println("Arquivo do jogo não encontrado: " + html.toAbsolutePath());
            System.exit(1);
        }
        int porta = args.length > 1 ? Integer.parseInt(args[1]) : 8765;
        Servidor s = new Servidor(() -> Files.readAllBytes(html), () -> System.out.println("Sala encerrada."));
        s.iniciar(porta);
        System.out.println("Servidor do Alone ligado na porta " + s.porta());
        System.out.println("HOST (abra neste computador e escolha Multiplayer > Criar sala):");
        System.out.println("  http://localhost:" + s.porta() + "/#chave=" + s.chave());
        for (String ip : Servidor.enderecos()) System.out.println("CONVIDADOS: http://" + ip + ":" + s.porta() + "/");
        System.out.println("Ctrl+C para desligar.");
        Runtime.getRuntime().addShutdownHook(new Thread(s::parar));
        Thread.currentThread().join();
    }
}
