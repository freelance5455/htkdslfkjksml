package br.alone.jogo;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.util.Log;

import br.alone.R;

/** Serviço em primeiro plano que existe só enquanto a sala está aberta: mantém CPU e Wi-Fi acordados. */
public class ServicoSala extends Service {
    private static final String CANAL = "sala";
    private PowerManager.WakeLock cpu;
    private WifiManager.WifiLock wifi;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(new NotificationChannel(CANAL, getString(R.string.canal_sala), NotificationManager.IMPORTANCE_LOW));
            Intent abrir = new Intent(this, MainActivity.class);
            Notification n = new Notification.Builder(this, CANAL)
                    .setSmallIcon(R.drawable.icone_aviso)
                    .setContentTitle(getString(R.string.sala_titulo))
                    .setContentText(getString(R.string.sala_texto))
                    .setContentIntent(PendingIntent.getActivity(this, 0, abrir, PendingIntent.FLAG_IMMUTABLE))
                    .setOngoing(true)
                    .build();
            if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE);
            else startForeground(1, n);
            if (cpu == null) {
                cpu = getSystemService(PowerManager.class).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "alone:sala");
                cpu.setReferenceCounted(false);
                cpu.acquire(6 * 60 * 60 * 1000L);
                WifiManager w = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
                if (w != null) {
                    @SuppressWarnings("deprecation")
                    WifiManager.WifiLock l = w.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "alone:sala");
                    wifi = l;
                    wifi.setReferenceCounted(false);
                    wifi.acquire();
                }
            }
        } catch (RuntimeException e) {
            Log.e("Alone", "não foi possível manter a sala em primeiro plano", e);
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    /** O jogador fechou o aplicativo pela lista de recentes: a sala não pode continuar. */
    @Override
    public void onTaskRemoved(Intent rootIntent) {
        Ponte.parar(this);
        stopSelf();
    }

    @Override
    public void onDestroy() {
        if (cpu != null && cpu.isHeld()) cpu.release();
        if (wifi != null && wifi.isHeld()) wifi.release();
        cpu = null;
        wifi = null;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
