package br.alone.jogo;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.window.OnBackInvokedDispatcher;

/** Mostra o jogo (assets/index.html) em tela cheia. */
public class MainActivity extends Activity {
    private static final String PAGINA = "file:///android_asset/index.html";
    private WebView web;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle estado) {
        super.onCreate(estado);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        web = new WebView(this);
        web.setBackgroundColor(0xFF000000);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false); // os assets continuam acessíveis
        s.setAllowContentAccess(false);
        s.setTextZoom(100);
        // o jogo abre ws:// na rede local a partir da página embutida
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest pedido) {
                return !PAGINA.equals(pedido.getUrl().toString()); // nunca navega para fora do jogo
            }

            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detalhe) {
                // o sistema encerrou o processo gráfico (pouca memória): fecha a sala e recria a tela
                Ponte.parar(MainActivity.this);
                ((ViewGroup) view.getParent()).removeView(view);
                view.destroy();
                web = null;
                recreate();
                return true;
            }
        });
        // a ponte só é visível para a página embutida, pois a navegação externa é bloqueada
        web.addJavascriptInterface(new Ponte(this), "AloneAndroid");
        setContentView(web);
        web.loadUrl(PAGINA);
        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT, this::voltar);
        }
        telaCheia();
    }

    /** O botão voltar abre/fecha os menus do jogo; só na tela inicial ele sai do aplicativo. */
    private void voltar() {
        if (web == null) { finish(); return; }
        web.evaluateJavascript("window.AloneVoltar ? AloneVoltar() : false", r -> {
            if (!"true".equals(r)) moveTaskToBack(true);
        });
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() { voltar(); }

    @SuppressWarnings("deprecation")
    private void telaCheia() {
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.systemBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean temFoco) {
        super.onWindowFocusChanged(temFoco);
        if (temFoco) telaCheia();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) {
            web.onResume();
            web.resumeTimers();
        }
    }

    @Override
    protected void onPause() {
        // com uma sala aberta o JavaScript do Host precisa continuar (o serviço mantém o processo vivo)
        if (web != null) {
            web.evaluateJavascript("!!(window.REDE_ATIVA && REDE_ATIVA())", r -> {
                if (!"true".equals(r) && web != null && !hasWindowFocus()) web.onPause();
            });
        }
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        Ponte.parar(this);
        if (web != null) {
            ((ViewGroup) web.getParent()).removeView(web);
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
