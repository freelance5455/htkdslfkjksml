package br.alone.servidor;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/** Uma conexão WebSocket (RFC 6455): leitura na thread do chamador, escrita em thread própria. */
final class Conexao {
    private static final int FILA_MAXIMA = 24 * 1024 * 1024;
    private final Socket socket;
    private final DataInputStream entrada;
    private final OutputStream saida;
    private final LinkedBlockingQueue<byte[]> fila = new LinkedBlockingQueue<>();
    private final AtomicInteger bytesNaFila = new AtomicInteger();
    private volatile boolean aberta = true;
    private volatile int limiteMensagem = 16 * 1024;
    /** Preenchido pela sala depois do pedido de entrada. */
    volatile int jogador = 0;

    Conexao(Socket socket, DataInputStream entrada, OutputStream saida) {
        this.socket = socket;
        this.entrada = entrada;
        this.saida = saida;
        Thread t = new Thread(this::escrever, "alone-envio");
        t.setDaemon(true);
        t.start();
    }

    boolean local() { return socket.getInetAddress().isLoopbackAddress(); }

    void permitirGrandes(int limite, int esperaMs) {
        limiteMensagem = limite;
        try { socket.setSoTimeout(esperaMs); } catch (IOException ignorado) { fechar(); }
    }

    /** Lê a próxima mensagem de texto; devolve null quando a conexão termina. */
    String ler() throws IOException {
        ByteArrayOutputStream parcial = null;
        while (aberta) {
            int b0 = entrada.readUnsignedByte(), b1 = entrada.readUnsignedByte();
            boolean fim = (b0 & 0x80) != 0;
            int op = b0 & 0x0f;
            if ((b0 & 0x70) != 0 || (b1 & 0x80) == 0) throw new IOException("quadro inválido");
            long n = b1 & 0x7f;
            if (n == 126) n = entrada.readUnsignedShort();
            else if (n == 127) n = entrada.readLong();
            int acumulado = parcial == null ? 0 : parcial.size();
            if (n < 0 || n + acumulado > limiteMensagem) throw new IOException("mensagem grande demais");
            if (op >= 8 && (n > 125 || !fim)) throw new IOException("controle inválido");
            byte[] mascara = new byte[4];
            entrada.readFully(mascara);
            byte[] dados = new byte[(int) n];
            entrada.readFully(dados);
            for (int k = 0; k < dados.length; k++) dados[k] ^= mascara[k & 3];
            if (op == 8) return null;
            if (op == 9) { enfileirar(quadro(10, dados)); continue; }
            if (op == 10) continue;
            if (op == 1) {
                if (parcial != null) throw new IOException("fragmento fora de ordem");
                if (fim) return new String(dados, StandardCharsets.UTF_8);
                parcial = new ByteArrayOutputStream();
                parcial.write(dados);
            } else if (op == 0 && parcial != null) {
                parcial.write(dados);
                if (fim) return new String(parcial.toByteArray(), StandardCharsets.UTF_8);
            } else throw new IOException("tipo não aceito");
        }
        return null;
    }

    private static byte[] quadro(int op, byte[] d) {
        int cab = d.length < 126 ? 2 : d.length < 65536 ? 4 : 10;
        byte[] q = new byte[cab + d.length];
        q[0] = (byte) (0x80 | op);
        if (cab == 2) q[1] = (byte) d.length;
        else if (cab == 4) { q[1] = 126; q[2] = (byte) (d.length >> 8); q[3] = (byte) d.length; }
        else { q[1] = 127; for (int k = 0; k < 8; k++) q[2 + k] = (byte) ((long) d.length >> (56 - 8 * k)); }
        System.arraycopy(d, 0, q, cab, d.length);
        return q;
    }

    private void enfileirar(byte[] q) {
        if (!aberta) return;
        if (bytesNaFila.addAndGet(q.length) > FILA_MAXIMA) { fechar(); return; }
        fila.add(q);
    }

    void enviar(String texto) { enfileirar(quadro(1, texto.getBytes(StandardCharsets.UTF_8))); }

    /** Para dados que ficam velhos depressa: descarta se o destinatário estiver atrasado. */
    void enviarSeFolga(String texto) { if (fila.size() < 12) enviar(texto); }

    private void escrever() {
        try {
            while (aberta || !fila.isEmpty()) {
                byte[] q = fila.poll(200, TimeUnit.MILLISECONDS);
                if (q == null) continue;
                bytesNaFila.addAndGet(-q.length);
                saida.write(q);
                if (fila.isEmpty()) saida.flush();
            }
            saida.write(quadro(8, new byte[]{3, (byte) 0xe8}));
            saida.flush();
        } catch (IOException | InterruptedException ignorado) {
            // a conexão caiu; o leitor cuida do restante
        } finally {
            aberta = false;
            try { socket.close(); } catch (IOException ignorado) { }
        }
    }

    /** Envia o que falta e fecha. */
    void fechar() { aberta = false; }

    void derrubar() {
        aberta = false;
        try { socket.close(); } catch (IOException ignorado) { }
    }
}
