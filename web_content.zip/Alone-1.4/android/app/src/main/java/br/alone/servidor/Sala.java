package br.alone.servidor;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Estado autoritativo da sala: quem está nela, posições aceitas, itens já recolhidos,
 * baús em uso e validação de todo evento antes de repassá-lo.
 * A simulação das criaturas e do relógio é feita pelo jogo do Host.
 */
final class Sala {
    static final String VERSAO = "1.4";
    static final int MAXIMO = 4;
    private static final long ESPERA_JOGADOR = 30_000, ESPERA_HOST = 6_000;
    private static final double VEL_H = 35, VEL_V = 60;

    private static final class Jogador {
        int id;
        String token, nome = "Viajante";
        Object skin;
        Conexao conexao;
        boolean host, aguardandoBase;
        long caiuEm;
        double x, y, z;
        boolean temPosicao, mudou;
        long posicaoEm, teleporteEm;
        List<Object> estado;
        final Map<String, double[]> baldes = new HashMap<>();
        final List<String> pendentes = new ArrayList<>();
    }

    private final Map<Integer, Jogador> jogadores = new LinkedHashMap<>();
    private final Set<String> recolhidos = new HashSet<>();
    private final Map<String, Integer> travas = new HashMap<>();
    private final SecureRandom acaso = new SecureRandom();
    private final String chaveHost;
    private final Runnable aoEncerrar;
    private String fase = "vazia";
    private Map<String, Object> mundo;
    private int proximoId = 1;
    private double meio = 8000;

    Sala(String chaveHost, Runnable aoEncerrar) {
        this.chaveHost = chaveHost;
        this.aoEncerrar = aoEncerrar;
    }

    synchronized int quantidade() { return jogadores.size(); }

    // ---------- leitura segura dos campos ----------
    private static double num(Object v, double min, double max) {
        if (!(v instanceof Number)) throw new IllegalArgumentException("número esperado");
        double d = ((Number) v).doubleValue();
        if (!(d >= min && d <= max)) throw new IllegalArgumentException("fora do limite");
        return d;
    }

    private static String txt(Object v, int max) {
        if (!(v instanceof String) || ((String) v).length() > max) throw new IllegalArgumentException("texto inválido");
        return (String) v;
    }

    private static List<?> lista(Object v, int max) {
        if (!(v instanceof List) || ((List<?>) v).size() > max) throw new IllegalArgumentException("lista inválida");
        return (List<?>) v;
    }

    private static Map<?, ?> mapa(Object v) {
        if (!(v instanceof Map)) throw new IllegalArgumentException("objeto esperado");
        return (Map<?, ?>) v;
    }

    private static String limparNome(Object v) {
        String n = v instanceof String ? ((String) v).replaceAll("[<>&\"'`\\\\\\p{Cntrl}]", "").trim() : "";
        if (n.length() > 16) n = n.substring(0, 16);
        return n.isEmpty() ? "Viajante" : n;
    }

    private static Object limparSkin(Object v) {
        return v instanceof Map && Json.escrever(v).length() <= 6000 ? v : null;
    }

    /** Balde de fichas: limita a frequência de cada tipo de mensagem. */
    private static boolean permitido(Jogador j, String tipo, double porSegundo, double rajada, double custo) {
        long agora = System.nanoTime();
        double[] b = j.baldes.computeIfAbsent(tipo, k -> new double[]{rajada, agora});
        b[0] = Math.min(rajada, b[0] + (agora - b[1]) / 1e9 * porSegundo);
        b[1] = agora;
        if (b[0] < custo) return false;
        b[0] -= custo;
        return true;
    }

    private String novoToken() {
        byte[] b = new byte[16];
        acaso.nextBytes(b);
        StringBuilder s = new StringBuilder();
        for (byte x : b) s.append(String.format("%02x", x & 255));
        return s.toString();
    }

    private Jogador host() {
        for (Jogador j : jogadores.values()) if (j.host) return j;
        return null;
    }

    private static void enviar(Jogador j, Object msg) {
        if (j != null && j.conexao != null) j.conexao.enviar(Json.escrever(msg));
    }

    private static void erro(Conexao c, String codigo, String texto) {
        c.enviar(Json.escrever(Json.obj("t", "erro", "cod", codigo, "msg", texto)));
        c.fechar();
    }

    private void avisarSala() {
        List<Object> l = new ArrayList<>();
        for (Jogador j : jogadores.values())
            l.add(Json.obj("id", j.id, "nome", j.nome, "skin", j.skin, "host", j.host, "online", j.conexao != null));
        String m = Json.escrever(Json.obj("t", "sala", "jogadores", l, "max", MAXIMO, "fase", fase));
        for (Jogador j : jogadores.values()) if (j.conexao != null) j.conexao.enviar(m);
    }

    // ---------- entrada e saída ----------
    private void entrar(Conexao c, Map<?, ?> m) {
        if (!VERSAO.equals(m.get("v"))) { erro(c, "versao", "Versão do jogo diferente da sala (" + VERSAO + ")."); return; }
        Object token = m.get("token");
        boolean pedeHost = chaveHost.equals(m.get("chave")) && c.local();
        Jogador j = null;
        if (token instanceof String)
            for (Jogador o : jogadores.values()) if (o.token.equals(token)) j = o;
        boolean voltou = j != null;
        if (j == null) {
            Jogador h = host();
            if (pedeHost) {
                if (h != null) { erro(c, "ocupada", "Esta sala já tem um Host."); return; }
                recolhidos.clear();
                travas.clear();
                mundo = null;
                fase = "espera";
            } else if (h == null) { erro(c, "semhost", "Ainda não há uma sala aberta neste endereço."); return; }
            if (jogadores.size() >= MAXIMO) { erro(c, "cheia", "A sala está cheia (" + MAXIMO + " jogadores)."); return; }
            j = new Jogador();
            j.id = proximoId++;
            j.token = novoToken();
            j.host = pedeHost;
            jogadores.put(j.id, j);
        } else if (j.conexao != null) {
            j.conexao.jogador = 0;
            j.conexao.derrubar();
        }
        j.nome = limparNome(m.get("nome"));
        j.skin = limparSkin(m.get("skin"));
        j.conexao = c;
        j.caiuEm = 0;
        j.temPosicao = false;
        j.pendentes.clear();
        c.jogador = j.id;
        c.permitirGrandes(j.host ? 12 * 1024 * 1024 : 64 * 1024, j.host ? 45_000 : 14_000);
        enviar(j, Json.obj("t", "bemvindo", "id", j.id, "token", j.token, "host", j.host, "fase", fase, "mundo", mundo, "voltou", voltou));
        avisarSala();
        if ("jogo".equals(fase) && !j.host) pedirBase(j);
    }

    private void pedirBase(Jogador j) {
        j.aguardandoBase = true;
        j.pendentes.clear();
        enviar(host(), Json.obj("t", "pedirBase", "para", j.id));
    }

    private void remover(Jogador j, String motivo) {
        jogadores.remove(j.id);
        soltarTravas(j.id);
        if (j.conexao != null) { j.conexao.jogador = 0; j.conexao.fechar(); }
        if (j.host) { encerrar(motivo); return; }
        String m = Json.escrever(Json.obj("t", "saiu", "id", j.id, "nome", j.nome));
        for (Jogador o : jogadores.values()) if (o.conexao != null) o.conexao.enviar(m);
        avisarSala();
    }

    private void soltarTravas(int id) { travas.values().removeIf(v -> v == id); }

    synchronized void encerrar(String motivo) {
        if ("vazia".equals(fase) && jogadores.isEmpty()) return;
        String m = Json.escrever(Json.obj("t", "fim", "motivo", motivo));
        for (Jogador o : jogadores.values())
            if (o.conexao != null) { o.conexao.jogador = 0; o.conexao.enviar(m); o.conexao.fechar(); }
        jogadores.clear();
        travas.clear();
        recolhidos.clear();
        mundo = null;
        fase = "vazia";
        if (aoEncerrar != null) aoEncerrar.run();
    }

    synchronized void caiu(Conexao c) {
        Jogador j = jogadores.get(c.jogador);
        if (j == null || j.conexao != c) return;
        j.conexao = null;
        j.caiuEm = System.currentTimeMillis();
        j.aguardandoBase = false;
        j.pendentes.clear();
        soltarTravas(j.id);
        avisarSala();
    }

    // ---------- mensagens ----------
    synchronized void receber(Conexao c, String texto) {
        Object o = Json.ler(texto);
        Map<?, ?> m = mapa(o);
        String t = txt(m.get("t"), 16);
        if (c.jogador == 0) {
            if ("entrar".equals(t)) entrar(c, m);
            return;
        }
        Jogador j = jogadores.get(c.jogador);
        if (j == null || j.conexao != c) return;
        switch (t) {
            case "ping":
                enviar(j, Json.obj("t", "pong", "n", m.get("n")));
                break;
            case "sair":
                remover(j, "host");
                break;
            case "perfil":
                if (!permitido(j, t, 1, 5, 1)) return;
                j.nome = limparNome(m.get("nome"));
                j.skin = limparSkin(m.get("skin"));
                avisarSala();
                break;
            case "iniciar": {
                if (!j.host || !"espera".equals(fase)) return;
                Map<?, ?> w = mapa(m.get("mundo"));
                meio = num(w.get("meio"), 100, 100000);
                mundo = Json.obj("semente", txt(w.get("semente"), 40), "tam", txt(w.get("tam"), 20), "modo", txt(w.get("modo"), 20),
                        "dif", txt(w.get("dif"), 20), "nome", txt(w.get("nome"), 40), "meio", meio);
                fase = "jogo";
                avisarSala();
                for (Jogador g : jogadores.values()) if (!g.host && g.conexao != null) pedirBase(g);
                break;
            }
            case "base": {
                if (!j.host) return;
                Jogador g = jogadores.get((int) num(m.get("para"), 1, 1e9));
                if (g == null || g.conexao == null || !g.aguardandoBase) return;
                enviar(g, Json.obj("t", "base", "mundo", mundo, "dados", mapa(m.get("dados"))));
                for (String p : g.pendentes) g.conexao.enviar(p);
                g.pendentes.clear();
                g.aguardandoBase = false;
                g.temPosicao = false;
                break;
            }
            case "p":
                if ("jogo".equals(fase) && permitido(j, t, 30, 60, 1)) posicao(j, m);
                break;
            case "op":
                if ("jogo".equals(fase)) operacao(j, m);
                break;
            case "pegar": {
                if (!permitido(j, t, 20, 60, 1)) return;
                String id = txt(m.get("id"), 48);
                if (recolhidos.size() < 200_000 && recolhidos.add(id)) paraTodos(Json.obj("t", "pegou", "id", id, "por", j.id), null);
                else enviar(j, Json.obj("t", "negado", "id", id));
                break;
            }
            case "travar": {
                if (!permitido(j, t, 5, 20, 1)) return;
                String id = txt(m.get("id"), 48);
                Integer dono = travas.get(id);
                boolean ok = dono == null || dono == j.id;
                if (ok) travas.put(id, j.id);
                enviar(j, Json.obj("t", "trava", "id", id, "ok", ok));
                break;
            }
            case "destravar":
                travas.remove(txt(m.get("id"), 48), j.id);
                break;
            case "seres":
                if (j.host && "jogo".equals(fase)) {
                    String s = Json.escrever(Json.obj("t", "seres", "ts", System.currentTimeMillis(), "l", lista(m.get("l"), 600)));
                    for (Jogador g : jogadores.values()) if (!g.host && g.conexao != null && !g.aguardandoBase) g.conexao.enviarSeFolga(s);
                }
                break;
            case "tempo":
                if (j.host) paraTodos(Json.obj("t", "tempo", "hora", num(m.get("hora"), 0, 1), "dia", num(m.get("dia"), 1, 1e7),
                        "chuva", num(m.get("chuva"), 0, 1)), j);
                break;
            case "dano":
            case "premio": {
                if (!j.host) return;
                Jogador g = jogadores.get((int) num(m.get("para"), 1, 1e9));
                if (g == null) return;
                if (t.equals("dano")) enviar(g, Json.obj("t", t, "d", num(m.get("d"), 0, 500), "x", num(m.get("x"), -1e6, 1e6), "z", num(m.get("z"), -1e6, 1e6)));
                else enviar(g, Json.obj("t", t, "tipo", txt(m.get("tipo"), 32)));
                break;
            }
            case "atacar":
                if (!j.host && permitido(j, t, 12, 30, 1))
                    enviar(host(), Json.obj("t", t, "de", j.id, "s", num(m.get("s"), 1, 1e12), "d", num(m.get("d"), 0, 200)));
                break;
            case "barco":
                if (!j.host && permitido(j, t, 4, 10, 1))
                    enviar(host(), Json.obj("t", t, "de", j.id, "s", num(m.get("s"), 1, 1e12), "entra", Boolean.TRUE.equals(m.get("entra")),
                            "x", num(m.get("x"), -meio, meio), "z", num(m.get("z"), -meio, meio), "h", num(m.get("h"), -1e4, 1e4)));
                break;
            case "invocar": {
                if (j.host || !permitido(j, t, 1, 5, 1)) return;
                double x = num(m.get("x"), -meio, meio), y = num(m.get("y"), -80, 220), z = num(m.get("z"), -meio, meio);
                if (!perto(j, x, y, z, 24)) return;
                enviar(host(), Json.obj("t", t, "de", j.id, "tipo", txt(m.get("tipo"), 32), "x", x, "y", y, "z", z));
                break;
            }
            case "efeito": {
                if (!permitido(j, t, 25, 60, 1)) return;
                List<?> v = lista(m.get("v"), 8);
                for (Object n : v) num(n, -1e6, 1e6);
                paraTodos(Json.obj("t", t, "de", j.id, "k", txt(m.get("k"), 12), "v", v), j);
                break;
            }
            default:
                // tipo desconhecido: ignorado
        }
    }

    private boolean perto(Jogador j, double x, double y, double z, double raio) {
        if (j.host) return true;
        if (!j.temPosicao) return false;
        double a = x - j.x, b = y - j.y, c = z - j.z;
        return a * a + b * b + c * c <= raio * raio;
    }

    private void posicao(Jogador j, Map<?, ?> m) {
        List<?> e = lista(m.get("e"), 12);
        if (e.size() != 12) throw new IllegalArgumentException("estado incompleto");
        double x = num(e.get(0), -meio, meio), y = num(e.get(1), -90, 240), z = num(e.get(2), -meio, meio);
        num(e.get(3), -1e5, 1e5);
        num(e.get(4), -2, 2);
        num(e.get(5), 0, 80);
        num(e.get(6), 0, 1023);
        num(e.get(7), 0, 1e9);
        txt(e.get(8), 32);
        for (Object a : lista(e.get(9), 5)) if (a != null) txt(a, 32);
        num(e.get(10), 0, 100);
        txt(e.get(11), 24);
        long agora = System.currentTimeMillis();
        if (j.temPosicao) {
            double dt = Math.min(2, Math.max(0.05, (agora - j.posicaoEm) / 1000.0));
            boolean longe = Math.hypot(x - j.x, z - j.z) > VEL_H * dt + 4 || Math.abs(y - j.y) > VEL_V * dt + 6;
            if (longe) {
                // saltos (viagem pelo mapa, renascer) só quando declarados e no máximo um a cada 3 s
                if (Boolean.TRUE.equals(m.get("tp")) && agora - j.teleporteEm > 3000) j.teleporteEm = agora;
                else {
                    enviar(j, Json.obj("t", "corrigir", "x", j.x, "y", j.y, "z", j.z));
                    return;
                }
            }
        }
        j.x = x;
        j.y = y;
        j.z = z;
        j.temPosicao = true;
        j.posicaoEm = agora;
        List<Object> estado = new ArrayList<>();
        estado.add((double) j.id);
        estado.addAll(e);
        j.estado = estado;
        j.mudou = true;
    }

    private void operacao(Jogador j, Map<?, ?> m) {
        String k = txt(m.get("o"), 12);
        Map<String, Object> r = Json.obj("t", "op", "de", j.id, "o", k);
        switch (k) {
            case "bloco": {
                List<?> l = lista(m.get("l"), 2400);
                if (l.size() % 4 != 0) return;
                if (!permitido(j, k, j.host ? 8000 : 1500, j.host ? 40000 : 3000, l.size() / 4.0)) { recusar(j, k, l); return; }
                for (int a = 0; a < l.size(); a += 4) {
                    double x = num(l.get(a), -meio, meio), y = num(l.get(a + 1), -66, 220), z = num(l.get(a + 2), -meio, meio);
                    num(l.get(a + 3), 0, 65535);
                    if (!perto(j, x, y, z, 64)) { recusar(j, k, l); return; }
                }
                r.put("l", l);
                break;
            }
            case "cava": {
                double x = num(m.get("x"), -meio, meio), y = num(m.get("y"), -80, 220), z = num(m.get("z"), -meio, meio);
                double raio = num(m.get("r"), 0.1, 3.6), nivel = num(m.get("n"), 0, 9);
                if (!permitido(j, k, 20, 40, 1) || !perto(j, x, y, z, 40)) return;
                r.put("x", x); r.put("y", y); r.put("z", z); r.put("r", raio); r.put("n", nivel);
                break;
            }
            case "recurso":
                if (!permitido(j, k, 40, 200, 1)) return;
                r.put("id", txt(m.get("id"), 48));
                r.put("dia", num(m.get("dia"), 0, 1e7));
                break;
            case "obra": {
                if (!permitido(j, k, 10, 600, 1)) return;
                String a = txt(m.get("a"), 4);
                Map<?, ?> b = mapa(m.get("obra"));
                txt(b.get("rid"), 48);
                if (!"del".equals(a)) {
                    txt(b.get("tipo"), 24);
                    double x = num(b.get("x"), -meio, meio), y = num(b.get("y"), -80, 220), z = num(b.get("z"), -meio, meio);
                    num(b.get("a"), -100, 100);
                    if (!perto(j, x, y, z, 24)) return;
                }
                r.put("a", a);
                r.put("obra", b);
                break;
            }
            case "bau": {
                String id = txt(m.get("id"), 48);
                Integer dono = travas.get(id);
                if (!permitido(j, k, 20, 60, 1) || dono != null && dono != j.id) return;
                List<?> l = lista(m.get("itens"), 32);
                for (Object item : l) {
                    List<?> par = lista(item, 2);
                    txt(par.get(0), 32);
                    num(par.get(1), 1, 999);
                }
                r.put("id", id);
                r.put("itens", l);
                break;
            }
            case "plantas": {
                if (!permitido(j, k, 5, 15, 1)) return;
                r.put("l", lista(m.get("l"), 600));
                break;
            }
            case "drop": {
                String id = txt(m.get("id"), 48);
                if (!permitido(j, k, 40, 200, 1) || !id.startsWith("p" + j.id + "-")) return;
                double x = num(m.get("x"), -meio, meio), y = num(m.get("y"), -120, 240), z = num(m.get("z"), -meio, meio);
                if (!perto(j, x, y, z, 90)) return;
                r.put("id", id);
                r.put("item", txt(m.get("item"), 32));
                r.put("q", num(m.get("q"), 1, 999));
                r.put("x", x); r.put("y", y); r.put("z", z);
                break;
            }
            case "suprimento": {
                if (!permitido(j, k, 1, 4, 1)) return;
                r.put("s", lista(m.get("s"), 5));
                break;
            }
            default:
                return;
        }
        paraTodos(r, j);
    }

    /** Avisa quem mandou que a alteração não valeu, para o jogo desfazê-la. */
    private void recusar(Jogador j, String tipo, List<?> l) {
        enviar(j, Json.obj("t", "recusado", "o", tipo, "l", l));
    }

    private void paraTodos(Object msg, Jogador menos) {
        String s = Json.escrever(msg);
        for (Jogador g : jogadores.values()) {
            if (g == menos) continue;
            if (g.aguardandoBase) { if (g.pendentes.size() < 20000) g.pendentes.add(s); }
            else if (g.conexao != null) g.conexao.enviar(s);
        }
    }

    /** Chamado 15 vezes por segundo: distribui posições e expira quem caiu. */
    synchronized void tique() {
        long agora = System.currentTimeMillis();
        for (Iterator<Jogador> it = new ArrayList<>(jogadores.values()).iterator(); it.hasNext(); ) {
            Jogador j = it.next();
            if (!jogadores.containsKey(j.id)) continue;
            if (j.conexao == null && agora - j.caiuEm > (j.host ? ESPERA_HOST : ESPERA_JOGADOR)) remover(j, "host");
        }
        boolean algum = false;
        for (Jogador j : jogadores.values()) algum |= j.mudou;
        if (!algum) return;
        for (Jogador d : jogadores.values()) {
            if (d.conexao == null || d.aguardandoBase) continue;
            List<Object> l = new ArrayList<>();
            for (Jogador j : jogadores.values()) if (j != d && j.mudou) l.add(j.estado);
            if (!l.isEmpty()) d.conexao.enviarSeFolga(Json.escrever(Json.obj("t", "ps", "ts", agora, "j", l)));
        }
        for (Jogador j : jogadores.values()) j.mudou = false;
    }
}
