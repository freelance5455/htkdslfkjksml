package br.alone.jogo;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.webkit.JavascriptInterface;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import br.alone.servidor.Json;
import br.alone.servidor.Servidor;

/** Funções que o jogo (window.AloneAndroid) chama para controlar o servidor embutido. */
final class Ponte {
    private static final int PORTA = 8765;
    private static Servidor servidor;
    private final Context app;

    Ponte(Context contexto) { app = contexto.getApplicationContext(); }

    /** Inicia o servidor (ou reaproveita o que já está ligado). Devolve JSON {ok,porta,chave,ips,erro}. */
    @JavascriptInterface
    public String iniciarServidor() {
        synchronized (Ponte.class) {
            try {
                if (servidor == null || !servidor.ativo()) {
                    Servidor novo = new Servidor(this::pagina, () -> encerrouSala());
                    novo.iniciar(PORTA);
                    servidor = novo;
                }
                app.startForegroundService(new Intent(app, ServicoSala.class));
                return Json.escrever(Json.obj("ok", true, "porta", servidor.porta(), "chave", servidor.chave(), "ips", Servidor.enderecos()));
            } catch (Exception e) {
                Log.e("Alone", "falha ao iniciar o servidor", e);
                parar(app);
                return Json.escrever(Json.obj("ok", false, "erro", String.valueOf(e.getMessage())));
            }
        }
    }

    @JavascriptInterface
    public void pararServidor() { parar(app); }

    @JavascriptInterface
    public String enderecos() { return Json.escrever(Servidor.enderecos()); }

    /** A sala acabou (Host saiu): desliga tudo um instante depois, para os avisos chegarem aos clientes. */
    private void encerrouSala() {
        final Servidor atual = servidor;
        new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
            synchronized (Ponte.class) {
                if (atual != null && atual == servidor && atual.jogadores() == 0) parar(app);
            }
        }, 1500);
    }

    static void parar(Context contexto) {
        synchronized (Ponte.class) {
            final Servidor s = servidor;
            servidor = null;
            // fechar sockets não pode acontecer na linha principal
            if (s != null) new Thread(s::parar, "alone-parar").start();
            contexto.stopService(new Intent(contexto, ServicoSala.class));
        }
    }

    private byte[] pagina() throws IOException {
        try (InputStream in = app.getAssets().open("index.html"); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] parte = new byte[16 * 1024];
            for (int n; (n = in.read(parte)) > 0; ) out.write(parte, 0, n);
            return out.toByteArray();
        }
    }
}
