package br.alone.servidor;

import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/** Servidor LAN do Alone: entrega a página do jogo por HTTP e atende WebSocket em /ws. */
public final class Servidor {
    /** Fornece o HTML do jogo para quem entra pelo navegador. */
    public interface Pagina { byte[] ler() throws IOException; }

    private static final int CONEXOES_MAXIMAS = 32;
    private final Pagina pagina;
    private final String chave;
    private final Sala sala;
    private final Set<Socket> sockets = ConcurrentHashMap.newKeySet();
    private ServerSocket escuta;
    private ScheduledExecutorService relogio;
    private volatile boolean ativo;

    public Servidor(Pagina pagina, Runnable aoEncerrarSala) {
        this.pagina = pagina;
        byte[] b = new byte[18];
        new SecureRandom().nextBytes(b);
        this.chave = Base64.getUrlEncoder().withoutPadding().encodeToString(b);
        this.sala = new Sala(chave, aoEncerrarSala);
    }

    /** Segredo que só o aparelho que hospeda conhece. */
    public String chave() { return chave; }

    public int porta() { return escuta == null ? 0 : escuta.getLocalPort(); }

    public int jogadores() { return sala.quantidade(); }

    public boolean ativo() { return ativo; }

    /** Abre a primeira porta livre a partir da desejada. */
    public synchronized int iniciar(int portaDesejada) throws IOException {
        if (ativo) return porta();
        IOException ultimo = null;
        for (int p = portaDesejada; p < portaDesejada + 10; p++) {
            ServerSocket s = new ServerSocket();
            try {
                s.setReuseAddress(true);
                s.bind(new InetSocketAddress(p));
                escuta = s;
                break;
            } catch (IOException e) {
                ultimo = e;
                s.close();
            }
        }
        if (escuta == null) throw ultimo;
        ativo = true;
        Thread t = new Thread(this::aceitar, "alone-aceitar");
        t.setDaemon(true);
        t.start();
        relogio = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread th = new Thread(r, "alone-relogio");
            th.setDaemon(true);
            return th;
        });
        relogio.scheduleAtFixedRate(() -> {
            try { sala.tique(); } catch (RuntimeException e) { System.err.println("tique: " + e); }
        }, 66, 66, TimeUnit.MILLISECONDS);
        return porta();
    }

    public synchronized void parar() {
        if (!ativo) return;
        ativo = false;
        sala.encerrar("host");
        relogio.shutdownNow();
        try { escuta.close(); } catch (IOException ignorado) { }
        escuta = null;
        // dá um instante para o aviso de encerramento sair antes de fechar os sockets
        final List<Socket> abertos = new ArrayList<>(sockets);
        Thread t = new Thread(() -> {
            try { Thread.sleep(500); } catch (InterruptedException ignorado) { }
            for (Socket s : abertos) try { s.close(); } catch (IOException ignorado) { }
        }, "alone-fechar");
        t.start();
    }

    private void aceitar() {
        ServerSocket s = escuta;
        while (ativo) {
            try {
                Socket c = s.accept();
                if (!redeLocal(c.getInetAddress()) || sockets.size() >= CONEXOES_MAXIMAS) { c.close(); continue; }
                sockets.add(c);
                Thread t = new Thread(() -> atender(c), "alone-conexao");
                t.setDaemon(true);
                t.start();
            } catch (IOException e) {
                if (ativo) System.err.println("aceitar: " + e);
            }
        }
    }

    /** Só aceita aparelhos da própria rede. */
    static boolean redeLocal(InetAddress a) {
        if (a.isLoopbackAddress() || a.isSiteLocalAddress() || a.isLinkLocalAddress()) return true;
        byte[] b = a.getAddress();
        if (b.length == 4) return (b[0] & 255) == 100 && (b[1] & 192) == 64;
        return (b[0] & 0xfe) == 0xfc;
    }

    private static String linha(DataInputStream in, int[] resto) throws IOException {
        StringBuilder s = new StringBuilder();
        while (true) {
            int c = in.read();
            if (c < 0 || --resto[0] < 0) throw new IOException("cabeçalho inválido");
            if (c == '\n') return s.toString();
            if (c != '\r') s.append((char) c);
        }
    }

    private void atender(Socket s) {
        Conexao c = null;
        try {
            s.setTcpNoDelay(true);
            s.setSoTimeout(8000);
            DataInputStream in = new DataInputStream(new java.io.BufferedInputStream(s.getInputStream()));
            OutputStream out = new BufferedOutputStream(s.getOutputStream(), 32 * 1024);
            int[] resto = {8192};
            String[] pedido = linha(in, resto).split(" ");
            Map<String, String> cab = new HashMap<>();
            for (String l = linha(in, resto); !l.isEmpty(); l = linha(in, resto)) {
                int p = l.indexOf(':');
                if (p > 0) cab.put(l.substring(0, p).trim().toLowerCase(java.util.Locale.ROOT), l.substring(p + 1).trim());
            }
            if (pedido.length < 2 || !pedido[0].equals("GET")) { responder(out, "405 Method Not Allowed", "text/plain", new byte[0]); return; }
            String caminho = pedido[1].split("\\?")[0];
            if (caminho.equals("/ws")) {
                String k = cab.get("sec-websocket-key");
                if (k == null || !"websocket".equalsIgnoreCase(cab.get("upgrade"))) { responder(out, "400 Bad Request", "text/plain", new byte[0]); return; }
                MessageDigest md = MessageDigest.getInstance("SHA-1");
                String aceite = Base64.getEncoder().encodeToString(md.digest((k + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").getBytes(StandardCharsets.US_ASCII)));
                out.write(("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: " + aceite + "\r\n\r\n").getBytes(StandardCharsets.US_ASCII));
                out.flush();
                c = new Conexao(s, in, out);
                // quem não pede para entrar em poucos segundos é desligado pelo tempo limite
                // uma mensagem inválida é descartada; quem insiste (ou erra antes de entrar) é desligado
                int invalidas = 0;
                for (String m = c.ler(); m != null; m = c.ler()) {
                    try {
                        sala.receber(c, m);
                    } catch (RuntimeException e) {
                        if (c.jogador == 0 || ++invalidas > 25) throw e;
                        System.err.println("mensagem inválida descartada: " + e.getMessage());
                    }
                }
            } else if (caminho.equals("/info")) {
                responder(out, "200 OK", "application/json", Json.escrever(Json.obj("app", "alone", "v", Sala.VERSAO, "jogadores", sala.quantidade(), "max", Sala.MAXIMO, "ips", enderecos())).getBytes(StandardCharsets.UTF_8));
            } else if (caminho.equals("/") || caminho.equals("/index.html")) {
                responder(out, "200 OK", "text/html; charset=utf-8", pagina.ler());
            } else responder(out, "404 Not Found", "text/plain", new byte[0]);
        } catch (IOException e) {
            // queda de conexão ou tempo esgotado: tratado abaixo
        } catch (Exception e) {
            System.err.println("conexão encerrada por dado inválido: " + e);
        } finally {
            sockets.remove(s);
            if (c != null) {
                sala.caiu(c);
                c.fechar();
            } else try { s.close(); } catch (IOException ignorado) { }
        }
    }

    private static void responder(OutputStream out, String estado, String tipo, byte[] corpo) throws IOException {
        out.write(("HTTP/1.1 " + estado + "\r\nContent-Type: " + tipo + "\r\nContent-Length: " + corpo.length
                + "\r\nCache-Control: no-store\r\nX-Content-Type-Options: nosniff\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.US_ASCII));
        out.write(corpo);
        out.flush();
    }

    /** Endereços IPv4 deste aparelho na rede local, com Wi-Fi e roteador do celular primeiro. */
    public static List<String> enderecos() {
        List<String> bons = new ArrayList<>(), outros = new ArrayList<>();
        try {
            for (NetworkInterface n : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!n.isUp() || n.isLoopback()) continue;
                String nome = n.getName().toLowerCase(java.util.Locale.ROOT);
                if (nome.startsWith("rmnet") || nome.startsWith("tun") || nome.startsWith("docker")) continue;
                for (InetAddress a : Collections.list(n.getInetAddresses()))
                    if (a instanceof Inet4Address && redeLocal(a) && !a.isLinkLocalAddress())
                        (nome.startsWith("wlan") || nome.startsWith("ap") || nome.startsWith("swlan") ? bons : outros).add(a.getHostAddress());
            }
        } catch (IOException ignorado) { }
        bons.addAll(outros);
        return bons;
    }
}
