package br.alone.servidor;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Leitor e escritor de JSON sem dependências, com limite de profundidade. */
public final class Json {
    private final String s;
    private int i;
    private static final int PROFUNDIDADE_MAXIMA = 24;

    private Json(String s) { this.s = s; }

    public static Object ler(String texto) {
        Json j = new Json(texto);
        Object v = j.valor(0);
        j.espacos();
        if (j.i != texto.length()) throw new IllegalArgumentException("sobra no JSON");
        return v;
    }

    private void espacos() { while (i < s.length() && s.charAt(i) <= ' ') i++; }

    private char proximo() {
        if (i >= s.length()) throw new IllegalArgumentException("JSON incompleto");
        return s.charAt(i++);
    }

    private Object valor(int nivel) {
        if (nivel > PROFUNDIDADE_MAXIMA) throw new IllegalArgumentException("JSON profundo demais");
        espacos();
        char c = proximo();
        if (c == '{') {
            Map<String, Object> m = new LinkedHashMap<>();
            espacos();
            if (i < s.length() && s.charAt(i) == '}') { i++; return m; }
            while (true) {
                espacos();
                if (proximo() != '"') throw new IllegalArgumentException("chave esperada");
                String k = texto();
                espacos();
                if (proximo() != ':') throw new IllegalArgumentException(": esperado");
                m.put(k, valor(nivel + 1));
                espacos();
                char d = proximo();
                if (d == '}') return m;
                if (d != ',') throw new IllegalArgumentException(", esperada");
            }
        }
        if (c == '[') {
            List<Object> l = new ArrayList<>();
            espacos();
            if (i < s.length() && s.charAt(i) == ']') { i++; return l; }
            while (true) {
                l.add(valor(nivel + 1));
                espacos();
                char d = proximo();
                if (d == ']') return l;
                if (d != ',') throw new IllegalArgumentException(", esperada");
            }
        }
        if (c == '"') return texto();
        i--;
        if (s.startsWith("true", i)) { i += 4; return Boolean.TRUE; }
        if (s.startsWith("false", i)) { i += 5; return Boolean.FALSE; }
        if (s.startsWith("null", i)) { i += 4; return null; }
        int ini = i;
        while (i < s.length() && "+-0123456789.eE".indexOf(s.charAt(i)) >= 0) i++;
        if (ini == i || i - ini > 32) throw new IllegalArgumentException("número inválido");
        double d = Double.parseDouble(s.substring(ini, i));
        if (Double.isNaN(d) || Double.isInfinite(d)) throw new IllegalArgumentException("número inválido");
        return d;
    }

    private String texto() {
        StringBuilder b = new StringBuilder();
        while (true) {
            char c = proximo();
            if (c == '"') return b.toString();
            if (c != '\\') { b.append(c); continue; }
            char e = proximo();
            switch (e) {
                case 'n': b.append('\n'); break;
                case 't': b.append('\t'); break;
                case 'r': b.append('\r'); break;
                case 'b': b.append('\b'); break;
                case 'f': b.append('\f'); break;
                case 'u':
                    if (i + 4 > s.length()) throw new IllegalArgumentException("escape inválido");
                    b.append((char) Integer.parseInt(s.substring(i, i + 4), 16));
                    i += 4;
                    break;
                default: b.append(e);
            }
        }
    }

    public static String escrever(Object v) {
        StringBuilder b = new StringBuilder();
        escrever(b, v);
        return b.toString();
    }

    private static void escrever(StringBuilder b, Object v) {
        if (v == null) b.append("null");
        else if (v instanceof String) citar(b, (String) v);
        else if (v instanceof Boolean) b.append(v);
        else if (v instanceof Number) {
            double d = ((Number) v).doubleValue();
            if (d == Math.rint(d) && Math.abs(d) < 9e15) b.append((long) d);
            else b.append(d);
        } else if (v instanceof Map) {
            b.append('{');
            boolean primeiro = true;
            for (Map.Entry<?, ?> e : ((Map<?, ?>) v).entrySet()) {
                if (!primeiro) b.append(',');
                primeiro = false;
                citar(b, String.valueOf(e.getKey()));
                b.append(':');
                escrever(b, e.getValue());
            }
            b.append('}');
        } else if (v instanceof Iterable) {
            b.append('[');
            boolean primeiro = true;
            for (Object o : (Iterable<?>) v) {
                if (!primeiro) b.append(',');
                primeiro = false;
                escrever(b, o);
            }
            b.append(']');
        } else citar(b, v.toString());
    }

    private static void citar(StringBuilder b, String t) {
        b.append('"');
        for (int k = 0; k < t.length(); k++) {
            char c = t.charAt(k);
            if (c == '"' || c == '\\') b.append('\\').append(c);
            else if (c < 32 || c == 0x2028 || c == 0x2029) b.append(String.format("\\u%04x", (int) c));
            else b.append(c);
        }
        b.append('"');
    }

    /** Monta um objeto a partir de pares chave, valor. */
    public static Map<String, Object> obj(Object... pares) {
        Map<String, Object> m = new LinkedHashMap<>();
        for (int k = 0; k + 1 < pares.length; k += 2) m.put((String) pares[k], pares[k + 1]);
        return m;
    }
}
