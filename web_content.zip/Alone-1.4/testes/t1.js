// entrada de 4 jogadores, recusa do 5º, início da partida
const B=require('./base');
(async()=>{const erros=[],S=await B.servidor(8801),br=[];const url=`http://127.0.0.1:${S.porta}/`;
const nova=async(u,n)=>{const b=await B.navegador();br.push(b);return B.pagina(b,u,n,erros)};
try{
const h=await nova(`http://localhost:${S.porta}/#chave=${S.chave}`,'Anfitriao');
await h.click('text=Multiplayer');await h.click('text=Criar sala');await h.selectOption('#rTam','pequeno');await h.click('button:has-text("Criar sala")');
await h.waitForSelector('#rQtd',{timeout:15000});console.log('host na sala:',await h.textContent('#rQtd'),(await h.textContent('.ipsala')).trim());
const g=[];for(const n of['Bia','Caio','Duda']){const p=await nova(url,n);await p.click('text=Multiplayer');await p.click('text=Entrar em uma sala');await p.click('text=Conectar');await p.waitForSelector('#rQtd',{timeout:15000});g.push(p);console.log(n,'entrou:',await p.textContent('#rQtd'))}
const q=await nova(url,'Quinto');await q.click('text=Multiplayer');await q.click('text=Entrar em uma sala');await q.click('text=Conectar');await q.waitForSelector('#rErro',{timeout:15000});console.log('5º:',await q.textContent('#rErro'));
console.log('lista host:',await h.textContent('#rLista'));
const t0=Date.now();await h.click('text=Iniciar partida');
for(const p of[h,...g])await p.waitForFunction(()=>REDE.pronto&&estado==='jogando',null,{timeout:120000});console.log('todos no jogo em',(Date.now()-t0)/1000,'s');
await B.espera(5000);
for(const p of[h,...g])console.log(p.nick,JSON.stringify(await p.evaluate(()=>({pos:[P.x,P.y,P.z].map(Math.round),outros:[...REDE.remotos.values()].filter(r=>r.visto).map(r=>`${r.nome}@${Math.round(r.e.x)},${Math.round(r.e.z)}${r.e.corpo?'':' SEMCORPO'}`),seres:seres.length,fps:Math.round(tempo),nomes:[...$('nomes').children].length}))));
await h.screenshot({path:'fotos/host.png'});await g[0].screenshot({path:'fotos/g1.png'});
}catch(e){console.log('FALHOU',e.message.split('\n').slice(0,6).join('\n'))}
console.log('ERROS',erros.slice(0,12));for(const b of br)await b.close();S.s.kill()})();
