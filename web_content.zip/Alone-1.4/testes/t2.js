// sincronização, validação, queda/reconexão, saída de convidado, entrada tardia e saída do Host
const B=require('./base');const ok=[],falha=[];const t=(n,c,x='')=>{(c?ok:falha).push(n);console.log(c?'OK   ':'FALHA',n,x)};
(async()=>{const erros=[],S=await B.servidor(8802),br=[];const url=`http://127.0.0.1:${S.porta}/`,E=B.espera;
const nova=async(u,n)=>{const b=await B.navegador();br.push(b);const p=await B.pagina(b,u,n,erros);p.br=b;return p};
const entrar=async n=>{const p=await nova(url,n);await p.click('text=Multiplayer');await p.click('text=Entrar em uma sala');await p.click('text=Conectar');return p};
const pronto=p=>p.waitForFunction(()=>REDE.pronto&&estado==='jogando',null,{timeout:120000});
const ate=async(p,f,a,ms=8000)=>{try{await p.waitForFunction(f,a,{timeout:ms,polling:100});return true}catch(e){return false}};
try{
const h=await nova(`http://localhost:${S.porta}/#chave=${S.chave}`,'Host');
await h.click('text=Multiplayer');await h.click('text=Criar sala');await h.selectOption('#rTam','pequeno');await h.click('button:has-text("Criar sala")');await h.waitForSelector('#rQtd');
await h.click('text=Iniciar partida');t('mínimo de 2 jogadores para iniciar',await h.isVisible('text=mínimo de 2'));
const a=await entrar('Ana'),b=await entrar('Beto');await h.waitForFunction(()=>REDE.sala.jogadores.length===3);await h.click('text=Iniciar partida');
for(const p of[h,a,b])await pronto(p);const todos=[h,a,b];await E(2500);
// movimento simultâneo
const antes=await Promise.all(todos.map(p=>p.evaluate(()=>({id:REDE.id,x:P.x,z:P.z}))));
await Promise.all(todos.map((p,i)=>p.evaluate(i=>{P.yaw=i*2.1},i)));for(const p of todos)await p.keyboard.down('KeyW');await E(1500);for(const p of todos)await p.keyboard.up('KeyW');await E(1200);
const depois=await Promise.all(todos.map(p=>p.evaluate(()=>({id:REDE.id,x:P.x,z:P.z}))));
t('os três andaram',depois.every((d,i)=>Math.hypot(d.x-antes[i].x,d.z-antes[i].z)>.8),depois.map((d,i)=>Math.hypot(d.x-antes[i].x,d.z-antes[i].z).toFixed(1)).join(' '));
let erroMax=0;for(const p of todos){const vistos=await p.evaluate(()=>[...REDE.remotos.values()].map(r=>({id:r.id,x:r.e.x,z:r.e.z})));for(const v of vistos){const d=depois.find(d=>d.id===v.id);erroMax=Math.max(erroMax,Math.hypot(v.x-d.x,v.z-d.z))}}
t('posições iguais em todos os aparelhos',erroMax<.5,'erro máx '+erroMax.toFixed(2)+' m');
// animação / item na mão / direção
await a.evaluate(()=>{P.inv[0]=['espada_ferro',1];P.sel=0;P.yaw=1.25});await a.evaluate(()=>{P.golpe=1});const idA=await a.evaluate(()=>REDE.id);
t('item na mão e direção do personagem',await ate(h,id=>{const r=REDE.remotos.get(id);return r.e.segura==='espada_ferro'&&Math.abs(r.yaw-1.25)<.05},idA),await h.evaluate(id=>{const r=REDE.remotos.get(id);return r.e.segura+' '+r.yaw},idA));
// relógio
await h.evaluate(()=>{hora=.5});t('hora do mundo segue o Host',await ate(b,()=>Math.abs(hora-.5)<.02));
// blocos
const pa=await a.evaluate(()=>{const x=Math.floor(P.x)+3,z=Math.floor(P.z),y=Math.floor(pes())+3;const n=+Object.keys(BLOCOS)[1];definirBloco(x,y,z,n);return{x,y,z,n}});
t('bloco colocado por convidado aparece no Host e no outro',await ate(h,q=>!!M.edits.get(VK(q.x,q.y,q.z)),pa)&&await ate(b,q=>!!M.edits.get(VK(q.x,q.y,q.z)),pa));
await b.evaluate(q=>definirBloco(q.x,q.y,q.z,0),pa);t('bloco removido sincroniza',await ate(a,q=>!M.edits.get(VK(q.x,q.y,q.z)),pa)&&await ate(h,q=>!M.edits.get(VK(q.x,q.y,q.z)),pa));
const longe=await a.evaluate(()=>{const x=Math.floor(P.x)+120,z=Math.floor(P.z),y=30;definirBloco(x,y,z,+Object.keys(BLOCOS)[1]);return{x,y,z}});await E(1500);
t('servidor recusa bloco a 120 m e o convidado desfaz',await a.evaluate(q=>!M.edits.get(VK(q.x,q.y,q.z)),longe)&&await h.evaluate(q=>!M.edits.get(VK(q.x,q.y,q.z)),longe));
// escavação
const cv=await b.evaluate(()=>{const x=P.x+4,z=P.z+4,y=altura(x,z)-.4;cavar(x,y,z,1.6,3);return{x,y:y-.3,z}});
t('buraco cavado por convidado aparece nos outros',await ate(h,q=>!solidoT(q.x,q.y,q.z),cv)&&await ate(a,q=>!solidoT(q.x,q.y,q.z),cv));
// árvore/recurso
const rid=await h.evaluate(()=>{let m,d=1e9;for(const ch of M.chunks.values())for(const r of ch.recursos){const q=Math.hypot(r.x-P.x,r.z-P.z);if(!r.morto&&q<d){d=q;m=r}}derrubar(m,false);return m.id});
const morto=(id)=>{for(const ch of M.chunks.values()){const r=ch.recursos.find(r=>r.id===id);if(r)return r.morto}return false};
t('árvore/recurso derrubado some para todos',await ate(a,morto,rid)&&await ate(b,morto,rid));
// item solto: dois disputam, só um recebe
await E(500);const dr=await h.evaluate(()=>{const x=P.x+9,z=P.z;soltar('moeda',7,x,z);return{x,z,id:M.chao.at(-1).id}});
t('item solto aparece para os outros',await ate(a,q=>M.chao.some(g=>g.id===q.id&&!g.pego),dr)&&await ate(b,q=>M.chao.some(g=>g.id===q.id),dr));
const m0=await Promise.all([a,b].map(p=>p.evaluate(()=>P.moedas)));
await Promise.all([a,b].map(p=>p.evaluate(q=>{P.x=q.x;P.z=q.z;P.y=solo(q.x,q.z,P.y+3)+1.7},dr)));await E(4000);
const m1=await Promise.all([a,b].map(p=>p.evaluate(()=>P.moedas)));const ganhos=m1.map((v,i)=>v-m0[i]);
t('item disputado vai para um único jogador',ganhos[0]+ganhos[1]===7&&(!ganhos[0]||!ganhos[1]),JSON.stringify(ganhos));
t('item some do chão nos três',(await Promise.all(todos.map(p=>p.evaluate(id=>!M.chao.some(g=>g.id===id&&!g.pego),dr.id)))).every(Boolean));
// construção e baú de construção
const ob=await a.evaluate(()=>{const c={tipo:modelos.bau?'bau':'fogueira',x:P.x+2,z:P.z+2,a:0};if(c.tipo==='bau')c.itens=[];addConstrucao(c);return{rid:c.rid,tipo:c.tipo}});
t('construção feita por convidado aparece ('+ob.tipo+')',await ate(h,q=>construcoes.some(c=>c.rid===q.rid),ob)&&await ate(b,q=>construcoes.some(c=>c.rid===q.rid),ob));
// baú do mundo
const bz=await h.evaluate(()=>{const l=M.baus.slice().sort((x,y)=>Math.hypot(x.x-P.x,x.z-P.z)-Math.hypot(y.x-P.x,y.z-P.z));return l[0]&&{id:l[0].id,x:l[0].x,z:l[0].z}});
if(bz){for(const p of todos)await p.evaluate(q=>{P.x=q.x+1.5;P.z=q.z;P.y=solo(P.x,P.z,60)+1.7},bz);await E(3500);
 const abre=p=>p.evaluate(id=>{const b=M.baus.find(b=>b.id===id);if(!b)return false;abrirBau(b);return true},bz.id);
 await abre(a);t('convidado abre baú',await ate(a,()=>estado==='painel'&&painelTipo==='bau'));await abre(b);await E(800);t('segundo jogador não abre baú em uso',await b.evaluate(()=>estado==='jogando'));
 await a.evaluate(()=>{painelArg.itens.splice(0,painelArg.itens.length,['moeda',3])});
 t('conteúdo do baú sincroniza',await ate(h,id=>JSON.stringify(M.baus.find(b=>b.id===id)?.itens)==='[["moeda",3]]',bz.id)&&await ate(b,id=>JSON.stringify(ES.baus[id])==='[["moeda",3]]',bz.id));
 await a.evaluate(()=>fecharPainel());await E(600);await abre(b);t('baú liberado depois de fechado',await ate(b,()=>estado==='painel'));await b.evaluate(()=>fecharPainel())}else console.log('sem baú no mundo');
// volta a ficar juntos
const pos=await h.evaluate(()=>({x:P.x,z:P.z}));await E(3100);
// criaturas
const z=await h.evaluate(()=>{CFG.dif='normal';const e=criar('cervo',P.x+6,P.z+2);e.hp=e.max=60;return{x:e.x,z:e.z}});await E(1500);
const rz=await h.evaluate(()=>seres.find(e=>e.tipo==='cervo'&&e.max===60&&e.rid)?.rid);
t('criatura do Host aparece nos convidados',await ate(a,r=>seres.some(e=>e.rid===r),rz)&&await ate(b,r=>seres.some(e=>e.rid===r),rz));
let dif=99;for(let i=0;i<5;i++){await E(700);const[ph,pb]=await Promise.all([h,b].map(p=>p.evaluate(r=>{const e=seres.find(e=>e.rid===r);return e&&[e.x,e.z]},rz)));if(ph&&pb)dif=Math.min(dif,Math.hypot(ph[0]-pb[0],ph[1]-pb[1]))}
t('posição da criatura coerente',dif<1.5,dif.toFixed(2)+' m');
const hp0=await h.evaluate(r=>seres.find(e=>e.rid===r).hp,rz);await a.evaluate(r=>ferirSer(seres.find(e=>e.rid===r),10,P.x,P.z),rz);
t('golpe do convidado tira vida da criatura no Host',await ate(h,([r,v])=>{const e=seres.find(e=>e.rid===r);return e&&e.hp<v},[rz,hp0]));
const ab0=await a.evaluate(()=>stats.mortos?.cervo||0);for(let i=0;i<8;i++){await a.evaluate(r=>{const e=seres.find(e=>e.rid===r);if(e)ferirSer(e,60,P.x,P.z)},rz);await E(250)}
t('criatura morre para todos',await ate(b,r=>!seres.some(e=>e.rid===r&&!e.morte),rz,6000));
// criatura fere convidado (longe do acampamento, onde há refúgio)
await E(3200);for(const[p,x]of[[b,52],[h,60]])await p.evaluate(x=>{P.x=x;P.z=40;P.y=soloTopo(x,40)+1.8},x);await E(3500);
await h.evaluate(()=>{seres=seres.filter(e=>!e.def.monstro)});const v0=await b.evaluate(()=>{P.vida=100;return P.vida});await E(800);
await h.evaluate(()=>{const r=[...REDE.remotos.values()].find(r=>r.nome==='Beto');hora=0;const e=criar('zumbi',r.e.x+1,r.e.z,{y:r.e.y});e.surge=0});
t('monstro do Host ataca e fere o convidado',await ate(b,v=>P.vida<v,v0,15000),'vida '+await b.evaluate(()=>Math.round(P.vida)));
await h.evaluate(()=>{seres=seres.filter(e=>!e.def.monstro);hora=.4});
const tam=await h.evaluate(()=>{const m=l=>Math.max(0,...l.map(s=>String(s).length));return[m(M.chao.map(g=>g.id||'')),m(M.baus.map(b=>b.id)),m([...M.chunks.values()].flatMap(c=>c.recursos.map(r=>r.id))),m(Object.keys(ITENS))]});t('identificadores dentro dos limites do servidor',tam[0]<=48&&tam[1]<=48&&tam[2]<=48&&tam[3]<=32,JSON.stringify(tam));
// validação no servidor
await E(500);const pb0=await b.evaluate(()=>({id:REDE.id,x:P.x,z:P.z}));
await b.evaluate(()=>{enviarRede({t:'p',e:[P.x+600,pes(),P.z,0,0,0,0,0,'',[],100,'']})});await E(700);
const visto=await h.evaluate(id=>REDE.remotos.get(id).e.x,pb0.id);t('posição impossível é rejeitada',Math.abs(visto-pb0.x)<3,`visto ${visto.toFixed(1)} real ${pb0.x.toFixed(1)}`);
await b.evaluate(()=>{REDE.ws.send('isto não é json');REDE.ws.send('{"t":"p","e":[1]}');REDE.ws.send('{"t":"tempo","hora":0.9,"dia":50,"chuva":0}');REDE.ws.send('{"t":"op","o":"bloco","l":"x"}');REDE.ws.send('[1,2]')});await E(1200);
t('mensagens inválidas ou só-do-Host não afetam a partida',await h.evaluate(()=>dia===1&&hora<.8&&REDE.sala.jogadores.length===3)&&await a.evaluate(()=>dia===1));
// queda de conexão e reconexão
const inv=await a.evaluate(()=>{P.inv[1]=['moeda',1];P.inv[2]=['espada_ferro',1];const id=REDE.id;REDE.ws.close();return id});
t('reconecta sozinho com o mesmo jogador',await ate(a,id=>REDE.ws&&REDE.ws.readyState===1&&REDE.pronto&&REDE.id===id&&estado==='jogando',inv,25000));
t('inventário mantido após reconectar',await a.evaluate(()=>P.inv[2]?.[0]==='espada_ferro'));await E(1500);
t('reconectado continua visível',await h.evaluate(id=>REDE.remotos.get(id)?.visto,inv));
// saída de convidado pelo menu
await b.evaluate(()=>pausar());await b.click('text=Sair da partida');
t('convidado sai; os outros continuam',await ate(h,()=>REDE.remotos.size===1&&REDE.pronto&&estado==='jogando')&&await ate(a,()=>REDE.remotos.size===1&&REDE.pronto));
t('quem saiu volta à tela inicial',await b.isVisible('.inicio'));
// entrada tardia
const c=await entrar('Caio');await pronto(c);await E(2500);
t('entrada com a partida em andamento',await h.evaluate(()=>REDE.remotos.size===2));
t('quem entrou depois recebe o mundo alterado',await c.evaluate(([q,o,r])=>!solidoT(q.x,q.y,q.z)&&construcoes.some(c=>c.rid===o.rid)&&!!ES.removidos[r],[cv,ob,rid]));
// fechar a aba (queda sem aviso)
await c.br.close();t('queda sem aviso aparece como reconectando',await ate(h,()=>REDE.sala.jogadores.some(j=>!j.online),null,15000));
t('jogador caído é removido após a espera',await ate(h,()=>REDE.sala.jogadores.length===2,null,45000));
// Host sai
await h.evaluate(()=>pausar());await h.click('text=Encerrar a partida para todos');
t('convidado recebe aviso de que o Host encerrou',await ate(a,()=>document.getElementById('msgRede')?.textContent.includes('Host encerrou')),await a.evaluate(()=>document.getElementById('msgRede')?.textContent));
await a.screenshot({path:'fotos/fim.png'});await a.click('text=Voltar ao início');t('cliente volta à tela inicial',await a.isVisible('.inicio'));
const d=await entrar('Davi');t('sala fechada não aceita entrada',await ate(d,()=>/não há uma sala/i.test(document.getElementById('rErro')?.textContent||'')));
// nova sala no mesmo servidor
await h.evaluate(()=>telaCriar());await h.selectOption('#rTam','pequeno');await h.click('button:has-text("Criar sala")');t('é possível criar outra sala depois',await ate(h,()=>!!document.getElementById('rQtd')));
}catch(e){falha.push('exceção');console.log('EXCEÇÃO',e.message.split('\n').slice(0,6).join('\n'))}
console.log(`\n${ok.length} OK, ${falha.length} falhas`,falha);console.log('ERROS',erros.filter(e=>!e.includes('ERR_FAILED')&&!e.includes('ERR_CONNECTION')).slice(0,12));console.log(S.log().split('\n').slice(0,20).join('\n'));for(const b of br)await b.close().catch(()=>{});S.s.kill()})();
