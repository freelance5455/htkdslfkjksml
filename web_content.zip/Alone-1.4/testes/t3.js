// ações extras, jogador distante, morte, queda do Host, ponte do app (simulada), file:// e jogo solo
const B=require('./base');const path=require('path');const ok=[],falha=[];const t=(n,c,x='')=>{(c?ok:falha).push(n);console.log(c?'OK   ':'FALHA',n,x)};
(async()=>{const erros=[],S=await B.servidor(8803),br=[];const url=`http://127.0.0.1:${S.porta}/`,E=B.espera;
const nova=async(u,n)=>{const b=await B.navegador();br.push(b);const p=await B.pagina(b,u,n,erros);p.br=b;return p};
const pronto=p=>p.waitForFunction(()=>REDE.pronto&&estado==='jogando',null,{timeout:120000});
const ate=async(p,f,a,ms=9000)=>{try{await p.waitForFunction(f,a,{timeout:ms,polling:100});return true}catch(e){return false}};
const vai=(p,x,z)=>p.evaluate(([x,z])=>{P.x=x;P.z=z;P.y=soloTopo(x,z)+1.8;P.vy=0},[x,z]);
try{
// Host pela ponte do aplicativo (simulada no navegador, usando o mesmo servidor Java)
const hb=await B.navegador();br.push(hb);const h=await B.pagina(hb,url,'Movel',erros);
await h.context().addInitScript(([p,c])=>{window.parou=0;window.AloneAndroid={iniciarServidor:()=>JSON.stringify({ok:true,porta:p,chave:c,ips:['192.168.0.10']}),pararServidor:()=>{window.parou++},enderecos:()=>'["192.168.0.10"]'}},[S.porta,S.chave]);
await h.goto(`http://localhost:${S.porta}/`);await h.click('text=Multiplayer');await h.click('text=Criar sala');await h.selectOption('#rTam','pequeno');await h.selectOption('#rModo','criativo');await h.click('button:has-text("Criar sala")');await h.waitForSelector('#rQtd');
t('fluxo de Host pela ponte do app mostra IP e porta',(await h.textContent('.ipsala')).includes('192.168.0.10 · porta '+S.porta));
// convidado abrindo o arquivo local (como o WebView do app)
const a=await nova('file://'+path.join(__dirname,'..','entrega','Alone.html'),'Arquivo');await a.click('text=Multiplayer');await a.click('text=Entrar em uma sala');await a.fill('#rIp','127.0.0.1');await a.fill('#rPorta',String(S.porta));await a.click('text=Conectar');
t('entrada a partir da página local (file://)',await ate(a,()=>!!document.getElementById('rQtd')));
await a.fill('#rQtd','').catch(()=>{});await h.click('text=Iniciar partida');await pronto(h);await pronto(a);await E(2000);
await h.screenshot({path:'fotos/app-host.png'});
await vai(h,40,30);await vai(a,44,30);await E(3500);
// invocar criatura e barco pelo convidado
const n0=await h.evaluate(()=>seres.filter(e=>e.tipo==='golem').length);
await a.evaluate(()=>{P.inv[0]=['nucleo_golem',1];P.sel=0;P.pitch=-.6;usarItem()});
t('criatura invocada por convidado nasce no Host',await ate(h,n=>seres.filter(e=>e.tipo==='golem').length>n,n0));
t('e aparece para o convidado',await ate(a,()=>seres.some(e=>e.tipo==='golem'&&e.rid)));
// flecha
const alvo=await h.evaluate(()=>{seres=seres.filter(e=>!e.def.monstro&&e.tipo!=='golem');const e=criar('vaca',44,36);e.hp=e.max=200;e.def={...e.def,vel:0,calmo:0};return 1});await E(1500);
await a.evaluate(()=>{const e=seres.find(e=>e.tipo==='vaca'&&e.max===200);const dx=e.x-P.x,dz=e.z-P.z,d=Math.hypot(dx,dz),y=e.y+.8;atirar(P.x+dx/d,y,P.z+dz/d,dx/d*42,.6,dz/d*42,15,true)});
t('flecha do convidado fere a criatura no Host',await ate(h,()=>seres.some(e=>e.tipo==='vaca'&&e.max===200&&e.hp<200)));
// TNT
const tn=await a.evaluate(()=>{const x=Math.floor(P.x)+9,z=Math.floor(P.z),y=Math.floor(soloTopo(x,z))+1;definirBloco(x,y,z,NB_.tnt);return{x,y,z}});await E(700);
await a.evaluate(q=>acender(q.x,q.y,q.z,1),tn);t('explosão abre cratera para os dois',await ate(h,q=>!solidoT(q.x+.5,q.y-1.4,q.z),tn,12000));
// construção: porta aberta
const po=await h.evaluate(()=>{if(!modelos.porta)return null;const c={tipo:'porta',x:P.x+2,z:P.z,a:0};addConstrucao(c);return c.rid});
if(po){await ate(a,r=>construcoes.some(c=>c.rid===r),po);await h.evaluate(r=>{const c=construcoes.find(c=>c.rid===r);P.yaw=-Math.PI/2;c.aberto=!c.aberto;enviarRede({t:'op',o:'obra',a:'upd',obra:dadosObra(c)})},po);t('abrir porta sincroniza',await ate(a,r=>construcoes.find(c=>c.rid===r)?.aberto===true,po))}
// plantação
await h.evaluate(()=>{ES.plantas.push({x:P.x+3,z:P.z+3,t:'trigo',i:.1})});t('plantação sincroniza',await ate(a,()=>ES.plantas.some(p=>p.t==='trigo')));
// morte e retorno
await a.evaluate(()=>{MODO='sobrevivencia';P.vida=1;ferirJogador(50,P.x+1,P.z)});t('convidado morre sem sair da partida',await ate(a,()=>estado==='morto'&&REDE.pronto));await E(1500);
t('os outros veem que ele caiu',await h.evaluate(()=>[...REDE.remotos.values()][0].flags&16));
await E(2200);await a.evaluate(()=>{renascer();if(estado!=='jogando')jogar()});await E(2500);
t('renasce e volta a ser visto no lugar certo',await h.evaluate(()=>{const r=[...REDE.remotos.values()][0];return !(r.flags&16)&&Math.hypot(r.e.x-3,r.e.z-7)<6}),await h.evaluate(()=>{const r=[...REDE.remotos.values()][0];return r.e.x.toFixed(1)+','+r.e.z.toFixed(1)}));
// menu aberto no Host não congela a partida
await h.evaluate(()=>pausar());const h0=await a.evaluate(()=>hora),s0=await h.evaluate(()=>tempo);await E(4000);
t('Host no menu: a partida continua',await h.evaluate(s=>tempo>s+1,s0)&&await a.evaluate(h=>hora!==h,h0));await h.evaluate(()=>jogar());
// convidado longe do Host
await E(1000);await vai(a,-120,-60);await E(12000);
const longe=await h.evaluate(()=>({chunk:M.chunks.has(Math.floor(-120/BLOCO)+','+Math.floor(-60/BLOCO)),seres:seres.filter(e=>Math.hypot(e.x+120,e.z+60)<70).length}));const vistos=await a.evaluate(()=>seres.filter(e=>Math.hypot(e.x-P.x,e.z-P.z)<70).length);
t('Host simula a região do convidado distante',longe.chunk&&longe.seres>0&&vistos>0,JSON.stringify(longe)+' vistos '+vistos);
await a.screenshot({path:'fotos/convidado.png'});
// Host some sem avisar
await h.br?.close();await hb.close();
t('queda do Host encerra a partida nos clientes',await ate(a,()=>document.getElementById('msgRede')?.textContent.includes('Host encerrou')||document.getElementById('msgRede')?.textContent.includes('perdida'),null,25000),await a.evaluate(()=>document.getElementById('msgRede')?.textContent));
// IP errado
await a.evaluate(()=>telaEntrar());await a.fill('#rIp','127.0.0.1');await a.fill('#rPorta','8999');await a.click('text=Conectar');t('endereço errado mostra erro',await ate(a,()=>!!document.getElementById('rErro'),null,15000));
await a.fill('#rIp','oi!!');await a.click('text=Conectar');t('IP inválido é recusado',(await a.textContent('#rErro')).includes('válidos'));
// jogo solo continua funcionando
await a.click('text=Voltar');await a.click('text=Voltar');await a.click('.nav button:has-text("Jogar")').catch(()=>a.click('text=Mundos'));if(await a.isVisible('text=Novo mundo'))await a.click('text=Novo mundo').catch(()=>{});
await a.selectOption('#nTam','pequeno');await a.click('button:has-text("Criar")');await a.waitForFunction(()=>estado==='jogando',null,{timeout:60000});await a.keyboard.down('KeyW');await E(2000);await a.keyboard.up('KeyW');
await a.evaluate(()=>{const x=Math.floor(P.x)+3,z=Math.floor(P.z),y=Math.floor(pes())+3;definirBloco(x,y,z,1);cavar(P.x+5,pes()-.3,P.z,1.4,3);soltar('moeda',2,P.x,P.z);salvar()});await E(2500);
t('jogo solo: andar, construir, cavar, coletar e salvar',await a.evaluate(()=>!REDE.ativo&&P.moedas>=7&&M.edits.size>0&&lerIndice().length>0&&seres.length>0));
await a.evaluate(()=>pausar());t('menu de pausa solo original',await a.isVisible('text=Continuar'));
}catch(e){falha.push('exceção');console.log('EXCEÇÃO',e.message.split('\n').slice(0,6).join('\n'))}
console.log(`\n${ok.length} OK, ${falha.length} falhas`,falha);console.log('ERROS',erros.filter(e=>!e.includes('ERR_FAILED')&&!e.includes('ERR_CONNECTION')).slice(0,12));console.log(S.log().split('\n').filter(l=>/inv/.test(l)).slice(0,20));for(const b of br)await b.close().catch(()=>{});S.s.kill()})();
