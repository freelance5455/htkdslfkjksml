// jogo solo e telas de rede em um celular (emulado), com host e convidado por toque
const B=require('./base');const {devices}=require('playwright');const ok=[],falha=[];const t=(n,c,x='')=>{(c?ok:falha).push(n);console.log(c?'OK   ':'FALHA',n,x)};
(async()=>{const erros=[],S=await B.servidor(8804),br=[];const url=`http://127.0.0.1:${S.porta}/`,E=B.espera;
const ate=async(p,f,a,ms=9000)=>{try{await p.waitForFunction(f,a,{timeout:ms,polling:100});return true}catch(e){return false}};
try{
const b=await B.navegador();br.push(b);const a=await B.pagina(b,url,'Solo',erros);
await a.click('.nav button:has-text("Jogar")');if(!await a.isVisible('#nTam'))await a.click('text=Novo mundo');await a.selectOption('#nTam','pequeno');await a.click('#menu button.p');await a.waitForFunction(()=>estado==='jogando',null,{timeout:60000});
const p0=await a.evaluate(()=>[P.x,P.z]);await a.keyboard.down('KeyW');await E(2000);await a.keyboard.up('KeyW');
await a.evaluate(()=>{const x=Math.floor(P.x)+3,z=Math.floor(P.z),y=Math.floor(pes())+3;definirBloco(x,y,z,1);cavar(P.x+5,pes()-.3,P.z,1.4,3);soltar('moeda',2,P.x,P.z)});await E(2500);
t('jogo solo: andar, construir, cavar, coletar e salvar',await a.evaluate(([x,z])=>{salvar();return !REDE.ativo&&Math.hypot(P.x-x,P.z-z)>1&&P.moedas>=7&&M.edits.size>0&&lerIndice().length===1&&seres.length>0},p0));
await a.evaluate(()=>pausar());t('menu de pausa original no jogo solo',await a.isVisible('text=Continuar'));
await a.evaluate(()=>telaInicial());await a.click('.nav button:has-text("Continuar")');t('continuar mundo salvo',await ate(a,()=>estado==='jogando'&&M.edits.size>0,null,60000));await b.close();
// celulares (toque)
const b2=await B.navegador();br.push(b2);const cel=async n=>{const c=await b2.newContext({...devices['Pixel 7 landscape']});await c.addInitScript(n=>{localStorage.setItem('alone.cfg',JSON.stringify({modo:'touch',qualidade:'baixo',res:.3,dist:60,grama:0,part:false,sombra:0}));localStorage.setItem('alone.skin',JSON.stringify({nick:n}))},n);const p=await c.newPage();p.on('pageerror',e=>erros.push(e.message));await p.route(/fonts\.g/,r=>r.abort());return p};
const h=await cel('CelHost'),g=await cel('CelConv');await h.goto(`http://localhost:${S.porta}/#chave=${S.chave}`);await g.goto(url);
await h.screenshot({path:'fotos/m-inicio.png'});await h.locator('text=Multiplayer').tap();await h.screenshot({path:'fotos/m-multi.png'});await h.locator('text=Criar sala').tap();await h.screenshot({path:'fotos/m-criar.png'});await h.selectOption('#rTam','pequeno');await h.locator('button:has-text("Criar sala")').tap();await h.waitForSelector('#rQtd');
await g.locator('text=Multiplayer').tap();await g.locator('text=Entrar em uma sala').tap();await g.screenshot({path:'fotos/m-entrar.png'});await g.locator('text=Conectar').tap();await g.waitForSelector('#rQtd');await h.waitForFunction(()=>REDE.sala.jogadores.length===2);await h.screenshot({path:'fotos/m-sala.png'});
await h.locator('text=Iniciar partida').tap();for(const p of[h,g])await p.waitForFunction(()=>REDE.pronto&&estado==='jogando',null,{timeout:120000});await E(3000);await g.screenshot({path:'fotos/m-jogo.png'});
t('dois celulares emulados em toque entram na mesma partida',await g.evaluate(()=>REDE.remotos.size===1&&[...REDE.remotos.values()][0].visto));
await g.evaluate(()=>pausar());await g.screenshot({path:'fotos/m-pausa.png'});t('botão voltar do Android: pausa volta ao jogo',await g.evaluate(()=>AloneVoltar()===true&&estado==='jogando'));
t('botão voltar no jogo abre o menu',await g.evaluate(()=>AloneVoltar()===true&&estado==='pausa'));
// trocar de personagem durante a partida
await g.evaluate(()=>{SKIN=skinAleatoria('Novo');gravarSkin();jogar();pausar();jogar()});t('troca de personagem chega aos outros',await ate(h,()=>[...REDE.remotos.values()][0].nome==='Novo'));
}catch(e){falha.push('exceção');console.log('EXCEÇÃO',e.message.split('\n').slice(0,6).join('\n'))}
console.log(`\n${ok.length} OK, ${falha.length} falhas`,falha);console.log('ERROS',erros.filter(e=>!e.includes('ERR_FAILED')&&!e.includes('ERR_CONNECTION')).slice(0,12));for(const b of br)await b.close().catch(()=>{});S.s.kill()})();
