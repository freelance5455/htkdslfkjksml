// ---------- controles ----------
const tecla={};let joy=null,arrasto=null,correrLigado=false,travadoEm=0,travou=false,travaFalhou=false,pausadoEm=0,usandoMouse=false,proxUso=0;
const toques={pular:false,descer:false};
function soltarControles(){for(const k in tecla)tecla[k]=false;entrada.f=entrada.l=0;entrada.atacando=entrada.correr=entrada.pular=entrada.descer=false;toques.pular=toques.descer=false;usandoMouse=false;joy=arrasto=null;$('joy').hidden=true;for(const id of['tAtacar','tPular','tDescer'])$(id).classList.remove('on')}
function travar(){if(CFG.modo!=='pc'||!matchMedia('(pointer:fine)').matches)return;try{const p=canvas.requestPointerLock&&canvas.requestPointerLock();if(p&&p.catch)p.catch(()=>{travaFalhou=true})}catch(e){travaFalhou=true}}
function jogar(){estado='jogando';comecou=true;$('menu').hidden=true;$('painel').hidden=true;mostrarHud(true);soltarControles();iniciarSom();atualizarBarra();aplicarCfg();travar();if(document.activeElement)document.activeElement.blur()}
function pausar(){if(estado!=='jogando')return;estado='pausa';pausadoEm=performance.now();soltarControles();if(document.pointerLockElement)document.exitPointerLock();salvar();mostrarHud(false);telaPausa()}
function pular(){if(estado==='jogando')pularAgora()}
function trocarCamera(){CFG.camera=(CFG.camera+1)%3;salvarCfg();avisar(['Primeira pessoa','Terceira pessoa','Terceira pessoa (de frente)'][CFG.camera],1.5)}
function alternarVoo(){if(!criativo())return;P.voando=!P.voando;P.vy=P.voando?3:0;P.barco=null;avisar(P.voando?'Voo ligado':'Voo desligado',1.5)}
document.addEventListener('pointerlockchange',()=>{if(document.pointerLockElement){travaFalhou=false;travou=true;travadoEm=performance.now()}else if(travou){travou=false;pausar()}});
document.addEventListener('pointerlockerror',()=>travaFalhou=true);
const ATALHO={KeyI:'inventario',Tab:'inventario',KeyB:'criar',KeyJ:'missoes',KeyM:'mapa',KeyH:'construir'};
addEventListener('keydown',e=>{if(['INPUT','SELECT','TEXTAREA'].includes(e.target.tagName)||e.ctrlKey||e.metaKey)return;
 if(estado==='painel'){const igual=ATALHO[e.code]&&(ATALHO[e.code]===painelTipo||ATALHO[e.code]==='criar'&&painelTipo==='catalogo');if(e.code==='Escape'||igual||(e.code==='KeyE'&&['bau','dialogo','criar','catalogo'].includes(painelTipo))){e.preventDefault();fecharPainel()}else if(ATALHO[e.code]){e.preventDefault();abrirPainel(ATALHO[e.code])}return}
 if(estado==='pausa'){if((e.code==='KeyP'||e.code==='Escape')&&performance.now()-pausadoEm>350)jogar();return}
 if(estado!=='jogando')return;if(e.code.startsWith('Arrow')||['Space','Tab','F5'].includes(e.code))e.preventDefault();tecla[e.code]=true;if(e.repeat)return;
 if(e.code==='Space')pular();else if(e.code==='KeyE')usar();else if(ATALHO[e.code])abrirPainel(ATALHO[e.code]);else if(e.code==='KeyR'){rotObra=(rotObra+1)%8}else if(e.code==='KeyQ')largar();else if(e.code==='KeyG')trocarForma();else if(e.code==='KeyT'){const k=Object.keys(MODOS_OBRA);P.modoObra=k[(k.indexOf(P.modoObra||'um')+1)%k.length];avisar('Modo: '+MODOS_OBRA[P.modoObra],1.5)}else if(e.code==='KeyV'||e.code==='F5')trocarCamera();else if(e.code==='KeyF')alternarVoo();else if(e.code==='KeyP'||e.code==='Escape')pausar();else if(/^Digit[1-8]$/.test(e.code))escolherSlot(+e.code[5]-1)});
addEventListener('keyup',e=>tecla[e.code]=false);
addEventListener('blur',soltarControles);
document.addEventListener('visibilitychange',()=>{if(document.hidden){pausar();salvar();if(ac)ac.suspend()}else if(ac)ac.resume()});
addEventListener('pagehide',salvar);
const olhar=(dx,dy,s)=>{const z=P.zoom?.3:1;P.yaw-=dx*s*z*CFG.sens;P.pitch=clamp(P.pitch-dy*s*z*CFG.sens*(CFG.invY?-1:1),-1.5,1.5)};
addEventListener('mousemove',e=>{if(document.pointerLockElement===canvas&&estado==='jogando'&&performance.now()-travadoEm>150&&Math.abs(e.movementX)<250&&Math.abs(e.movementY)<250)olhar(e.movementX,e.movementY,.0023)});
canvas.addEventListener('contextmenu',e=>e.preventDefault());
const botaoDireito=()=>{usandoMouse=true;proxUso=.32;usar()};
canvas.addEventListener('mousedown',e=>{if(CFG.modo!=='pc'||estado!=='jogando'||!document.pointerLockElement)return;if(e.button===0){entrada.atacando=true;atacar()}else if(e.button===2)botaoDireito()});
canvas.addEventListener('pointerdown',e=>{if(estado!=='jogando')return;e.preventDefault();iniciarSom();const r=canvas.getBoundingClientRect(),x=e.clientX-r.left,y=e.clientY-r.top;
 if(CFG.modo==='pc'&&e.pointerType==='mouse'){if(document.pointerLockElement){if(e.button===0){entrada.atacando=true;atacar()}else if(e.button===2)botaoDireito();return}
  if(e.button===2){botaoDireito();return}travar()}
 if(CFG.modo==='touch'&&x<r.width*.45&&!joy){joy={id:e.pointerId,x,y,dx:0,dy:0};const j=$('joy');j.hidden=false;j.style.left=x+'px';j.style.top=y+'px';j.firstElementChild.style.transform=''}
 else arrasto={id:e.pointerId,x:e.clientX,y:e.clientY,andou:0,t:performance.now()};
 try{canvas.setPointerCapture(e.pointerId)}catch(_){}});
canvas.addEventListener('pointermove',e=>{if(joy&&e.pointerId===joy.id){const r=canvas.getBoundingClientRect();let dx=(e.clientX-r.left-joy.x)/50,dy=(e.clientY-r.top-joy.y)/50;const l=Math.hypot(dx,dy);if(l>1.35){dx*=1.35/l;dy*=1.35/l}joy.dx=dx;joy.dy=dy;$('joy').firstElementChild.style.transform=`translate(${dx*34}px,${dy*34}px)`}
 else if(arrasto&&e.pointerId===arrasto.id&&!document.pointerLockElement){const dx=e.clientX-arrasto.x,dy=e.clientY-arrasto.y;arrasto.andou+=Math.abs(dx)+Math.abs(dy);olhar(dx,dy,.005);arrasto.x=e.clientX;arrasto.y=e.clientY}});
for(const ev of['pointerup','pointercancel'])canvas.addEventListener(ev,e=>{if(e.pointerType==='mouse'){entrada.atacando=false;usandoMouse=false}if(joy&&e.pointerId===joy.id){joy=null;$('joy').hidden=true}
 if(arrasto&&e.pointerId===arrasto.id){// sem cursor travado, um clique parado também ataca
  if(CFG.modo==='pc'&&ev==='pointerup'&&e.button===0&&arrasto.andou<6&&(travaFalhou||!matchMedia('(pointer:fine)').matches))atacar();arrasto=null}});
addEventListener('pointerup',e=>{if(e.pointerType==='mouse'){if(e.button===0)entrada.atacando=false;if(e.button===2)usandoMouse=false}});
addEventListener('mouseup',e=>{if(e.button===0)entrada.atacando=false;if(e.button===2)usandoMouse=false});
canvas.addEventListener('wheel',e=>{if(estado==='jogando'){e.preventDefault();escolherSlot(P.sel+Math.sign(e.deltaY))}},{passive:false});
const aoTocar=(id,f)=>$(id).addEventListener('pointerdown',e=>{e.preventDefault();iniciarSom();f()});
const segurar=(id,liga,desliga)=>{aoTocar(id,()=>{if(estado==='jogando'){$(id).classList.add('on');liga()}});for(const ev of['pointerup','pointercancel','pointerleave'])$(id).addEventListener(ev,()=>{$(id).classList.remove('on');desliga()})};
segurar('tAtacar',()=>{entrada.atacando=true;atacar()},()=>entrada.atacando=false);
segurar('tPular',()=>{toques.pular=true;pular()},()=>toques.pular=false);
segurar('tDescer',()=>toques.descer=true,()=>toques.descer=false);
$('tUsar').addEventListener('click',()=>{iniciarSom();usar()});$('tObra').addEventListener('click',()=>abrirPainel('construir'));aoTocar('tCorrer',()=>{correrLigado=!correrLigado;$('tCorrer').classList.toggle('on',correrLigado)});aoTocar('tGirar',()=>rotObra=(rotObra+1)%8);aoTocar('tVoar',alternarVoo);
for(const b of document.querySelectorAll('[data-abrir]'))b.addEventListener('click',()=>{const a=b.dataset.abrir;if(a==='pausa')pausar();else if(a==='camera')trocarCamera();else abrirPainel(a)});
$('pFechar').addEventListener('click',fecharPainel);
function lerEntrada(){let f=(tecla.KeyW||tecla.ArrowUp?1:0)-(tecla.KeyS||tecla.ArrowDown?1:0),l=(tecla.KeyD||tecla.ArrowRight?1:0)-(tecla.KeyA||tecla.ArrowLeft?1:0);
 if(joy){f-=joy.dy;l+=joy.dx}entrada.f=f;entrada.l=l;entrada.pular=!!(tecla.Space||toques.pular);entrada.descer=!!(tecla.KeyC||tecla.KeyX||toques.descer||P.sub&&(tecla.ShiftLeft||tecla.ShiftRight));
 entrada.correr=!!(tecla.ShiftLeft||tecla.ShiftRight||(CFG.modo==='touch'&&(correrLigado||(joy&&Math.hypot(joy.dx,joy.dy)>1.2))))}

// ---------- laço principal ----------
let antes=performance.now(),proxHud=0,proxSalvar=12,proxMissao=1,quadros=0,soma=0;
const calcNoite=()=>1-smooth(-.22,.12,Math.sin((hora-.25)*TAU));
function simular(dt){const h0=hora;if(!ES.tempoParado){hora=(hora+dt/(CFG.durDia*60))%1;if(h0<.27&&hora>=.27)novaManha()}
 noite=calcNoite();lerEntrada();if(usandoMouse&&(proxUso-=dt)<0){proxUso=.24;const it=naMao();if(it&&(it.cat==='cubo'||it.id==='tocha'))usarItem()}
 atualizarMundo(2);if(estado!=='morto')atualizarJogador(dt);if(estado!=='jogando'&&!REDE.ativo)return;atualizarSeres(dt,tempo);atualizarFlechas(dt);atualizarFaiscas(dt);atualizarBombas(dt);nascimentos(dt);fluirAgua(dt);atualizarClima(dt);ambiente();
 faseJog+=dt*Math.min(10,Math.hypot(entrada.f,entrada.l)*(P.correndo?9:5))*1.9;
 if(alvoAtual&&(alvoAtual.t-=dt)<0)alvoAtual=null;
 if((proxMissao-=dt)<0){verificarMissoes();proxMissao=1}if((proxSalvar-=dt)<0){salvar();proxSalvar=15}}
function quadro(agora){requestAnimationFrame(quadro);if(CFG.limFps&&agora-antes<1000/CFG.limFps-1.5)return;const real=Math.min((agora-antes)/1000,.5),dt=Math.min(real,.05);antes=agora;tempo+=dt;
 if(emPartida&&estado!=='carregando'){if(estado==='jogando'){simular(dt);
   soma+=real;if(++quadros>=45){const m=soma/quadros;if(CFG.fps)texto('fps',Math.round(1/m)+' fps');if(m>.034&&escalaAuto>.55)escalaAuto*=.88;else if(m<.019&&escalaAuto<1)escalaAuto=Math.min(1,escalaAuto*1.08);quadros=0;soma=0}}
  else if(REDE.ativo&&REDE.pronto&&estado!=='carregando'){if(!(document.hidden&&REDE.host))simular(dt)}
  else if(!comecou){noite=calcNoite();atualizarMundo(1)}
  atualizarVoxels(3);
  const d=$('dano');if(+d.style.opacity>0)d.style.opacity=Math.max(0,d.style.opacity-dt*1.6);
  desenhar();atualizarNomes();if(estado==='jogando'&&tempo>proxHud){atualizarHud();proxHud=tempo+.12}}}
canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();salvar();estado='carregando';janela('Alone',false,el('<p>O navegador interrompeu os gráficos. Recarregue a página para continuar.</p>'))});
function previaDeFundo(){iniciarPartida({id:'_previa',nome:'Prévia',semente:String(Math.floor(Math.random()*1e6)),tam:'pequeno',modo:'sobrevivencia',dif:CFG.dif},null);hora=.31}
function iniciar(dados){try{criarModelos();criarCorpos();criarModelosFixos();
  if(dados&&dados.save&&dados.save.meta){guardar('alone.w.'+dados.save.meta.id,JSON.stringify(dados.save));const l=lerIndice().filter(m=>m.id!==dados.save.meta.id);l.unshift(dados.save.meta);guardar('alone.mundos',JSON.stringify(l))}
  previaDeFundo();aplicarCfg();if(CFG.modo)telaInicial();else telaDispositivo(telaInicial);requestAnimationFrame(quadro)}
 catch(e){console.error(e);$('mCorpo').innerHTML=`<div class="janela"><h2>Alone</h2><p>Não foi possível iniciar o jogo neste navegador.</p><p>${esc(e.message)}</p></div>`}}
window.claude?.hot?.snapshot(()=>({save:comecou?dadosSalvos():null}));
setTimeout(()=>window.claude?.hot?.ready?window.claude.hot.ready(iniciar):iniciar(window.claude?.hot?.data??{}),30);
