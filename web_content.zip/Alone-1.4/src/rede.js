// ================= MULTIPLAYER LAN (Alone 1.4) =================
// O servidor (Java) valida e repassa; o jogo do Host simula criaturas, relógio, clima e água.
const VERSAO_REDE='1.4',ATRASO_INTERP=130;
Object.assign(REDE,{ws:null,conectado:false,id:0,token:null,sala:null,remotos:new Map(),aplicando:0,carregando:false,tela:null,endereco:null,chave:null,ips:[],porta:8765,fila:null,lote:[],anteriores:new Map(),desvio:null,seq:0,seqSer:1,golpe:0,golpeAnt:0,ping:0,ultimaMsg:0,tentativas:0,saindo:false,usando:false,criandoFantoche:false,fantoches:new Map(),bauAberto:null,bauPedido:null,barco:null,sigPlantas:'',difAntes:null,mundo:null,real:null,proxies:[],alvoNasc:0,pronto:false});
const ponte=()=>window.AloneAndroid||null;
REDE.chaveURL=(/(?:^#|&)chave=([\w-]+)/.exec(location.hash)||[])[1]||null;
const convidado=()=>REDE.ativo&&!REDE.host;
const enviarRede=m=>{const w=REDE.ws;if(w&&w.readyState===1){w.send(JSON.stringify(m));return true}return false};
const publica=()=>REDE.ativo&&!REDE.aplicando&&!REDE.carregando;
const novoId=()=>`p${REDE.id||0}-${Date.now().toString(36)}${(++REDE.seq).toString(36)}`;
const finito=(...v)=>v.every(Number.isFinite);
function aplicando(f){REDE.aplicando++;try{return f()}finally{REDE.aplicando--}}

// ---------- ganchos no jogo original ----------
const _criar=criar;criar=function(tipo,x,z,extra){if(!convidado()||REDE.criandoFantoche)return _criar(tipo,x,z,extra);
 if(REDE.usando&&!REDE.carregando)enviarRede({t:'invocar',tipo,x,y:extra?.y??soloTopo(x,z),z});const e=_criar(tipo,x,z,extra);seres.pop();return e};
const _usarItem=usarItem;usarItem=function(){REDE.usando=true;try{_usarItem()}finally{REDE.usando=false}};
const _usar=usar;usar=function(){const a=REDE.ativo&&estado==='jogando'?alvoUso():null;_usar();if(a&&a.tipo==='porta'&&publica())enviarRede({t:'op',o:'obra',a:'upd',obra:dadosObra(a.o)})};
const _alvoUso=alvoUso;alvoUso=function(){const a=_alvoUso();return a&&convidado()&&['pet','domar','tosar','montar','domar2','alimentar'].includes(a.tipo)?null:a};
const _definirBloco=definirBloco;definirBloco=function(x,y,z,n,f=0,g=0){if(!publica())return _definirBloco(x,y,z,n,f,g);const k=VK(x,y,z);if(!REDE.anteriores.has(k))REDE.anteriores.set(k,M.edits.get(k));_definirBloco(x,y,z,n,f,g);REDE.lote.push(x,y,z,M.edits.get(k)||0)};
const _cavar=cavar;cavar=function(x,y,z,r,n){const avisa=publica(),res=_cavar(x,y,z,r,n);if(avisa)enviarRede({t:'op',o:'cava',x,y,z,r:Math.min(3.5,r),n:Math.max(0,Math.min(9,n||0))});return res};
const _semApoio=semApoio;semApoio=function(x,y,z,r){if(!REDE.aplicando||!REDE.ativo)return _semApoio(x,y,z,r);
 for(const ch of M.chunks.values())for(const m of ch.miudos)if(m[5]&&Math.hypot(m[2]-x,m[4]-z)<r+.4&&!solidoT(m[2],m[3]-.2,m[4])){m[5]=0;const it=ch.itens[m[0]];if(it){gl.bindBuffer(gl.ARRAY_BUFFER,it.ibuf);gl.bufferSubData(gl.ARRAY_BUFFER,m[1]*24+12,new Float32Array([0]))}}};
const _derrubar=derrubar;derrubar=function(r,pega){const antes=r.morto;_derrubar(r,pega);if(!antes&&r.morto&&publica())enviarRede({t:'op',o:'recurso',id:r.id,dia:ES.removidos[r.id]||dia+1})};
const _soltar=soltar;soltar=function(item,q,x,z,y){_soltar(item,q,x,z,y);if(!publica())return;const g=M.chao.at(-1);g.id=novoId();enviarRede({t:'op',o:'drop',id:g.id,item,q,x:g.x,y:Number.isFinite(g.y)?g.y:0,z:g.z})};
const dadosObra=c=>({rid:c.rid,tipo:c.tipo,x:c.x,y:c.y,z:c.z,a:c.a%TAU,aberto:!!c.aberto});
const _addConstrucao=addConstrucao;addConstrucao=function(c){c.rid=c.rid||novoId();const r=_addConstrucao(c);if(publica())enviarRede({t:'op',o:'obra',a:'add',obra:dadosObra(c)});return r};
const _desmontar=desmontar;desmontar=function(c){if(publica())enviarRede({t:'op',o:'obra',a:'del',obra:dadosObra(c)});_desmontar(c)};
function removerObra(c){tirarCols(c.cols);construcoes=construcoes.filter(o=>o!==c);for(const k of['estacoes','luzes','camas'])M[k]=M[k].filter(o=>o.obra!==c)}
const _sortear=sortear;sortear=function(ch){if(!REDE.ativo)return _sortear(ch);let s=2166136261;for(const c of`${M.semente}|${ch.k}`)s=Math.imul(s^c.charCodeAt(0),16777619);const orig=Math.random;
 Math.random=()=>{s=s+0x6D2B79F5|0;let t=Math.imul(s^s>>>15,1|s);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296};try{_sortear(ch)}finally{Math.random=orig}};
const _cairSuprimento=cairSuprimento;cairSuprimento=function(x,z,rar,motivo){_cairSuprimento(x,z,rar,motivo);if(publica())enviarRede({t:'op',o:'suprimento',s:ES.suprimentos.at(-1)})};
const _atirar=atirar;atirar=function(x,y,z,vx,vy,vz,dano,minha){_atirar(x,y,z,vx,vy,vz,dano,minha);if(publica())enviarRede({t:'efeito',k:'flecha',v:[x,y,z,vx,vy,vz]})};
const _explodir=explodir;explodir=function(x,y,z,R=3.2){if(publica())enviarRede({t:'efeito',k:'boom',v:[x,y,z,R]});const p=P;if(REDE.ativo&&P.remoto)P=REDE.real; // os convidados recebem o dano pelo efeito
 try{_explodir(x,y,z,R)}finally{P=p}};
const _fluirAgua=fluirAgua;fluirAgua=function(dt){if(convidado()){filaAgua.clear();return}_fluirAgua(dt)};
const _nascimentos=nascimentos;nascimentos=function(dt){if(convidado())return;if(!REDE.ativo)return _nascimentos(dt);
 const lista=[null,...proxiesRemotos()],alvo=lista[Math.floor(tempo/3)%lista.length];if(!alvo)return _nascimentos(dt);const real=P;P=alvo;try{_nascimentos(dt)}finally{P=real}};
const _dormir=dormir;dormir=function(a){if(convidado()){avisar('Só quem criou a sala pode passar a noite.',3);return}_dormir(a)};
const _ferirJogador=ferirJogador;ferirJogador=function(d,ox,oz){if(REDE.ativo&&P.remoto){if(d>0&&!criativo())enviarRede({t:'dano',para:P.remoto,d:Math.min(500,d),x:ox??P.x,z:oz??P.z});return}_ferirJogador(d,ox,oz)};
const _ferirSer=ferirSer;ferirSer=function(e,dano,ox,oz,quem='jogador'){if(!convidado())return _ferirSer(e,dano,ox,oz,quem);if(e.morte||!e.rid||quem!=='jogador'&&quem!=='tnt'||!(dano>0))return;
 enviarRede({t:'atacar',s:e.rid,d:Math.min(200,dano)});e.flash=.18;faisca(e.x,e.y+e.def.alt*.6,e.z,[.9,.15,.1],6,.18);som('acerto');alvoAtual={e,t:3}};
const _abrirBau=abrirBau;abrirBau=function(b){if(!REDE.ativo)return _abrirBau(b);const k=b.id!==undefined?String(b.id):'o:'+b.rid;REDE.bauPedido={k,b};enviarRede({t:'travar',id:k})};
const _salvar=salvar;salvar=function(){if(convidado()){guardarMochila();return}if(REDE.carregando)return;_salvar()};
const _atualizarSeres=atualizarSeres;atualizarSeres=function(dt,t){if(!REDE.ativo)return _atualizarSeres(dt,t);atualizarRemotos(dt);if(!REDE.host)return atualizarFantoches(dt);
 REDE.real=P;REDE.proxies=proxiesRemotos();try{_atualizarSeres(dt,t)}finally{P=REDE.real}};
REDE.focar=e=>{const real=REDE.real;P=real;if(!real||e===real.montaria||e===real.barco||e.manso)return;let md=Math.hypot(e.x-real.x,e.z-real.z)+Math.abs(e.y-real.y+1.7);
 for(const q of REDE.proxies){const d=Math.hypot(e.x-q.x,e.z-q.z)+Math.abs(e.y-q.y+1.7);if(d<md){md=d;P=q}}};
REDE.desfocar=()=>{if(REDE.real)P=REDE.real};
function proxiesRemotos(){const l=[];for(const r of REDE.remotos.values())if(r.visto&&!(r.flags&16))l.push(Object.assign({},P,{x:r.e.x,y:r.e.y+1.7,z:r.e.z,yaw:r.yaw,pitch:r.e.pitch,vida:r.vida,correndo:r.e.v>6,isca:null,montaria:null,barco:null,efeitos:{},remoto:r.id,noChao:true,sub:0,voando:!!(r.flags&4)}));return l}
REDE.centros=()=>{if(!REDE.ativo||!REDE.host)return[];const l=[];for(const r of REDE.remotos.values())if(r.visto)l.push([Math.floor(r.e.x/BLOCO),Math.floor(r.e.z/BLOCO)]);return l};
REDE.alguemPerto=(e,d)=>[...REDE.remotos.values()].some(r=>r.visto&&Math.hypot(e.x-r.e.x,e.y-r.e.y,e.z-r.e.z)<d);
REDE.flechaAtinge=f=>{for(const r of REDE.remotos.values())if(r.visto&&Math.hypot(r.e.x-f.x,r.e.z-f.z)<.5&&f.y>r.e.y-.05&&f.y<r.e.y+1.95){enviarRede({t:'dano',para:r.id,d:Math.min(500,f.dano),x:f.x-f.vx,z:f.z-f.vz});return true}return false};
REDE.pedirItem=g=>{if(!g.id)g.id=novoId();const a=performance.now();if(g.pedido&&a-g.pedido<1500)return;g.pedido=a;enviarRede({t:'pegar',id:String(g.id)})};

// ---------- interpolação ----------
function ajustarRelogio(ts){const d=Date.now()-ts;REDE.desvio=REDE.desvio===null?d:Math.min(REDE.desvio+.4,d)}
function amostra(buf,t){while(buf.length>2&&buf[1][0]<=t)buf.shift();const a=buf[0],b=buf[1];if(!b||t<=a[0])return a;const k=Math.min(1,(t-a[0])/Math.max(1,b[0]-a[0]));
 if(Math.hypot(b[1]-a[1],b[3]-a[3])>15)return b;let dh=((b[4]-a[4])%TAU+TAU*1.5)%TAU-Math.PI;return[t,lerp(a[1],b[1],k),lerp(a[2],b[2],k),lerp(a[3],b[3],k),a[4]+dh*k]}
const agoraRede=()=>Date.now()-(REDE.desvio||0)-ATRASO_INTERP;
function remoto(id){let r=REDE.remotos.get(id);if(!r){r={id,nome:'Viajante',skin:null,buf:[],visto:false,flags:0,yaw:0,vida:100,chave:'',swing:null,e:{x:0,y:0,z:0,h:0,v:0,fase:0,golpe:0,pitch:0,corpo:null,def:{},segura:null,escudo:null,atirando:false,nado:0,sentadoBarco:false}};REDE.remotos.set(id,r)}return r}
function tirarRemoto(id){const r=REDE.remotos.get(id);if(!r)return;if(r.e.corpo)apagarCorpo(r.e.corpo);r.etiqueta?.remove();REDE.remotos.delete(id);for(const e of seres)if(e.oculto===id)e.oculto=0}
function receberPosicoes(m){ajustarRelogio(m.ts);for(const s of m.j){const[id,x,y,z,yaw,pi,v,f,g,it,ar,vd]=s;if(id===REDE.id||!finito(x,y,z,yaw,pi,v))continue;const r=remoto(id),e=r.e;
 r.buf.push([m.ts,x,y,z,yaw+Math.PI]);if(r.buf.length>40)r.buf.shift();r.yaw=yaw;r.flags=f;r.vida=vd;e.pitch=pi;e.v=v;if(r.swing!==null&&g!==r.swing)e.golpe=1;r.swing=g;
 e.segura=ITENS[it]?it:null;const arm=(Array.isArray(ar)?ar:[]).map(a=>ITENS[a]?a:null);e.escudo=arm[4]||null;r.armadura=arm;
 if(!r.visto){r.visto=true;Object.assign(e,{x,y,z,h:yaw+Math.PI})}}}
function atualizarRemotos(dt){const t=agoraRede();for(const r of REDE.remotos.values()){if(!r.visto||!r.buf.length)continue;const e=r.e,a=amostra(r.buf,t),f=r.flags;e.x=a[1];e.y=a[2];e.z=a[3];e.h=a[4];e.fase+=Math.min(10,e.v)*dt*1.9;e.golpe=Math.max(0,e.golpe-dt*3.5);e.nado=f&1&&e.v>1?1:0;e.sentadoBarco=!!(f&34);e.atirando=!!(f&8);e.morte=f&16?.5:0;
 const chave=JSON.stringify([r.skin,r.armadura]);if(chave!==r.chave){r.chave=chave;if(e.corpo)apagarCorpo(e.corpo);e.corpo=corpoSkin(validarSkin(r.skin),r.armadura||[])}}}
REDE.desenhar=()=>{for(const r of REDE.remotos.values()){if(!r.visto||!r.e.corpo||Math.abs(r.e.x-P.x)>150||Math.abs(r.e.z-P.z)>150)continue;
 if(r.flags&2){desenharMalha(modelos.barco,mul(T(r.e.x,r.e.y+.25,r.e.z),RY(r.e.h)));const y=r.e.y;r.e.y-=.1;desenharSer(r.e,true);r.e.y=y}else desenharSer(r.e,true)}};
const _atualizarNomes=atualizarNomes;atualizarNomes=function(){_atualizarNomes();for(const r of REDE.remotos.values()){let t=r.etiqueta;if(!t){t=r.etiqueta=document.createElement('span');$('nomes').append(t)}let vis=false;
 if(REDE.ativo&&r.visto&&estado==='jogando'&&Math.hypot(r.e.x-P.x,r.e.z-P.z)<45){const v=VPatual,x=r.e.x,y=r.e.y+2.2,z=r.e.z,w=v[3]*x+v[7]*y+v[11]*z+v[15];if(w>.5){const sx=(v[0]*x+v[4]*y+v[8]*z+v[12])/w,sy=(v[1]*x+v[5]*y+v[9]*z+v[13])/w;if(Math.abs(sx)<1&&Math.abs(sy)<1){vis=true;t.style.left=(sx*50+50)+'%';t.style.top=(50-sy*50)+'%';const n=`${r.nome} · ${Math.ceil(r.vida)}♥`;if(t.textContent!==n)t.textContent=n}}}t.hidden=!vis}};

// ---------- criaturas: o Host simula, os convidados exibem ----------
function enviarSeres(){const outros=[...REDE.remotos.values()].filter(r=>r.visto);if(!outros.length)return;const l=[];
 for(const e of seres){if(!e.rid)e.rid=REDE.seqSer++;if(!outros.some(r=>Math.abs(r.e.x-e.x)<130&&Math.abs(r.e.z-e.z)<130))continue;
  if(e.chaveCorpo===undefined||CORPOS[e.chaveCorpo]!==e.corpo)e.chaveCorpo=Object.keys(CORPOS).find(k=>CORPOS[k]===e.corpo)||'';
  const n=v=>Math.round((v||0)*100)/100,f=(e.surge?1:0)|(e.voando?2:0)|(e.tosada?4:0)|(e.manso?8:0)|(e.oculto||P.barco===e?32:0);
  l.push([e.rid,e.tipo,n(e.x),n(e.y),n(e.z),n(e.h),n(e.v),n(e.golpe),n(e.flash),n(e.morte),n(e.escala),Math.ceil(e.hp),Math.ceil(e.max),f,e.chaveCorpo,e.npc?e.npc.id:e.vila?e.vila.i:null]);if(l.length>=300)break}
 enviarRede({t:'seres',l})}
function receberSeres(m){ajustarRelogio(m.ts);if(!REDE.pronto)return;const a=performance.now();
 for(const s of m.l){const[rid,tipo,x,y,z,h,v,golpe,flash,morte,escala,hp,max,f,corpo,ex]=s;if(!BICHOS[tipo]||!finito(x,y,z,h))continue;let e=REDE.fantoches.get(rid);
  if(!e){REDE.criandoFantoche=true;try{e=_criar(tipo,x,z,{y})}finally{REDE.criandoFantoche=false}e.rid=rid;e.buf=[];REDE.fantoches.set(rid,e);if(tipo==='npc'){e.npc=M.npcs.find(n=>n.id===ex);if(e.npc&&!CORPOS[e.npc.id])CORPOS[e.npc.id]=corpoNpc(e.npc)}else if(tipo==='golem'&&ex!==null)e.vila=M.vilas[ex]}
  else if(!seres.includes(e))seres.push(e);
  e.buf.push([m.ts,x,y,z,h]);if(e.buf.length>20)e.buf.shift();e.visto=a;e.v=v;e.golpe=golpe;e.flash=Math.max(e.flash,flash);e.morte=morte?Math.max(e.morte,morte):0;e.escala=escala;e.hp=hp;e.max=max;e.surge=f&1?.4:0;e.voando=!!(f&2);e.manso=!!(f&8);e.oculto=f&32&&!e.meu?1:0;e.corpo=CORPOS[corpo]||(e.npc&&CORPOS[e.npc.id])||CORPOS[tipo]||e.corpo||CORPOS.zumbi}}
function atualizarFantoches(dt){const t=agoraRede(),a=performance.now();
 for(const[rid,e]of REDE.fantoches){if(a-e.visto>1800&&!e.meu||e.morte>=1.4){REDE.fantoches.delete(rid);e.sumir=true;if(P.barco===e)P.barco=null;continue}
  if(!e.meu&&e.buf.length){const q=amostra(e.buf,t);e.x=q[1];e.y=q[2];e.z=q[3];e.h=q[4]}e.flash=Math.max(0,e.flash-dt);e.golpe=Math.max(0,(e.golpe||0)-dt*2.5);if(e.fala>0)e.fala-=dt;if(e.morte)e.morte+=dt;e.fase+=(e.voando?8:(e.v||0)*(e.def.alt<1.1?5:2.4))*dt}
 seres=seres.filter(e=>!e.sumir)}

// ---------- operações recebidas ----------
function aplicarOp(m){aplicando(()=>{
 if(m.o==='bloco'){for(let i=0;i+3<m.l.length;i+=4){const[x,y,z,v]=m.l.slice(i,i+4);if(!finito(x,y,z,v)||v&&!BLOCOS[v&1023])continue;registrar(x,y,z,v);marcar(x,z);if(REDE.host)for(const[a,b,c]of[[0,0,0],[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]])filaAgua.add(VK(x+a,y+b,z+c))}}
 else if(m.o==='cava')cavar(m.x,m.y,m.z,m.r,m.n);
 else if(m.o==='recurso'){ES.removidos[m.id]=m.dia;for(const ch of M.chunks.values()){const r=ch.recursos.find(r=>r.id===m.id);if(r){if(!r.morto)alternarRecurso(r,false);break}}}
 else if(m.o==='obra'){const o=m.obra,c=construcoes.find(c=>c.rid===o.rid);if(m.a==='add'){if(!c&&modelos[o.tipo])addConstrucao({...o})}else if(c){if(m.a==='del')removerObra(c);else{c.aberto=!!o.aberto;if(c.folha)c.folha.morto=c.aberto;som('porta',.5)}}}
 else if(m.o==='bau')aplicarBau(m.id,m.itens);
 else if(m.o==='plantas'){ES.plantas=m.l.filter(p=>p&&finito(p.x,p.z,p.i)&&(p.t===null||['trigo','cenoura','batata'].includes(p.t))).map(p=>({x:p.x,z:p.z,t:p.t,i:p.i}));REDE.sigPlantas=assinaturaPlantas()}
 else if(m.o==='drop'){if(ITENS[m.item]&&!M.chao.some(g=>g.id===m.id))M.chao.push({id:m.id,item:m.item,q:m.q,x:m.x,y:m.y,z:m.z,pego:false,solto:true,espera:.6,vida:240,cav:false})}
 else if(m.o==='suprimento'){const[id,x,z,rar,itens]=m.s;if(finito(x,z)&&Array.isArray(itens)&&!ES.suprimentos.some(s=>s[0]===id)){ES.suprimentos.push([id,x,z,rar,itens]);emChunk(x,z,()=>addBau(id,x,z,0,itens,undefined,{rar}));avisar('Um baú de suprimentos apareceu no mundo.',4)}}})}
function aplicarBau(id,itens){const l=itens.filter(s=>ITENS[s[0]]&&s[1]>0).map(s=>[s[0],s[1]]);let alvo=null;
 if(id.startsWith('o:')){const c=construcoes.find(c=>c.rid===id.slice(2));if(c){c.itens=l;alvo=c}}else{ES.baus[id]=l;const b=M.baus.find(b=>String(b.id)===id);if(b){b.itens=l;b.aberto=true;alvo=b}}
 if(alvo&&estado==='painel'&&painelTipo==='bau'&&painelArg===alvo)desenharPainel()}
const assinaturaPlantas=()=>JSON.stringify((ES.plantas||[]).map(p=>[p.x,p.z,p.t,REDE.host?Math.floor(p.i*4):0]));

// ---------- conexão ----------
function conectar(){const w=new WebSocket(REDE.endereco);REDE.ws=w;REDE.ultimaMsg=performance.now();const limite=setTimeout(()=>{if(w.readyState===0)w.close()},6000);
 w.onopen=()=>{clearTimeout(limite);enviarRede({t:'entrar',v:VERSAO_REDE,nome:SKIN.nick,skin:SKIN,chave:REDE.chave||undefined,token:REDE.token||undefined})};
 w.onmessage=ev=>{if(REDE.ws!==w)return;REDE.ultimaMsg=performance.now();let m;try{m=JSON.parse(ev.data)}catch(e){return}if(REDE.fila&&m.t!=='fim'&&m.t!=='pong'){REDE.fila.push(m);return}try{receberRede(m)}catch(e){console.error('rede',m.t,e)}};
 w.onclose=()=>{clearTimeout(limite);if(REDE.ws!==w||REDE.saindo)return;REDE.ws=null;
  if(REDE.token&&REDE.tentativas<10){REDE.tentativas++;if(REDE.ativo)avisar('Conexão perdida. Reconectando…',2.5);else if(REDE.tela==='sala')telaSala('Reconectando…');setTimeout(()=>{if(REDE.conectado&&!REDE.ws)conectar()},1800)}
  else if(REDE.conectado)encerrarComAviso('A conexão com a sala foi perdida.');
  else telaEntrar(REDE.ultimoErro||'Não consegui entrar. Confira o IP, a porta, se os dois aparelhos estão no mesmo Wi-Fi e se a sala continua aberta.')}}
function receberRede(m){switch(m.t){
 case'bemvindo':REDE.id=m.id;REDE.token=m.token;REDE.host=m.host;REDE.conectado=true;REDE.tentativas=0;REDE.fase=m.fase;REDE.mundo=m.mundo;if(m.voltou)avisar('Reconectado.',2);if(!REDE.ativo)telaSala();break;
 case'erro':REDE.ultimoErro=m.msg;if(REDE.conectado)encerrarComAviso(m.msg);else{const h=!!REDE.chave;desligarRede();h?telaCriar(m.msg):telaEntrar(m.msg)}break;
 case'sala':{const antes=new Set(REDE.remotos.keys());REDE.sala=m;const ids=new Set();for(const j of m.jogadores){if(j.id===REDE.id)continue;ids.add(j.id);const novo=!antes.has(j.id),r=remoto(j.id);r.nome=String(j.nome).slice(0,16);r.skin=j.skin;if(!j.online)r.visto=false;if(novo&&REDE.ativo)avisar(`${r.nome} entrou na partida.`,3)}
   for(const id of antes)if(!ids.has(id))tirarRemoto(id);if(REDE.tela==='sala')telaSala();break}
 case'saiu':avisar(`${m.nome} saiu da partida.`,3);tirarRemoto(m.id);break;
 case'fim':encerrarComAviso('O Host encerrou a partida.');break;
 case'pedirBase':if(REDE.host&&REDE.ativo&&REDE.pronto)enviarRede({t:'base',para:m.para,dados:dadosBase()});else if(REDE.host)setTimeout(()=>{if(REDE.conectado)receberRede(m)},600);break;
 case'base':entrarNoMundoDoHost(m);break;
 case'ps':receberPosicoes(m);break;
 case'seres':if(!REDE.host&&REDE.ativo)receberSeres(m);break;
 case'op':if(REDE.pronto)aplicarOp(m);break;
 case'recusado':if(m.o==='bloco')for(let i=0;i+3<m.l.length;i+=4){const[x,y,z]=m.l.slice(i,i+3),k=VK(x,y,z);if(!REDE.anteriores.has(k))continue;const v=REDE.anteriores.get(k);if(v===undefined){M.edits.delete(k);vchunk(x>>4,z>>4).set.delete(k)}else registrar(x,y,z,v);marcar(x,z)}break;
 case'pegou':{const g=M.chao?.find(g=>g.id===m.id&&!g.pego);if(!/^p\d+-/.test(m.id)&&REDE.pronto)ES.pegos[m.id]=1;if(!g)break;g.pego=true;if(m.por===REDE.id)pegar(g.item,g.q);break}
 case'negado':{const g=M.chao?.find(g=>g.id===m.id);if(g)g.pego=true;break}
 case'trava':{const p=REDE.bauPedido;REDE.bauPedido=null;if(!p||p.k!==m.id)break;if(!m.ok){avisar('Outro jogador está usando este baú.',2.5);break}if(estado!=='jogando'){enviarRede({t:'destravar',id:p.k});break}_abrirBau(p.b);REDE.bauAberto={k:p.k,b:p.b,sig:''};break}
 case'tempo':if(!REDE.host&&REDE.pronto){let n=0;while(dia<m.dia&&n++<30)novaManha();dia=m.dia;hora=m.hora;climaAlvo=m.chuva;climaT=1e9}break;
 case'dano':if(REDE.pronto)_ferirJogador(m.d,m.x,m.z);break;
 case'premio':if(REDE.pronto&&BICHOS[m.tipo]){contar('mortos',m.tipo);avisar(`${BICHOS[m.tipo].n} derrotado`,2)}break;
 case'atacar':{if(!REDE.host||!REDE.pronto)break;const e=seres.find(e=>e.rid===m.s),r=REDE.remotos.get(m.de);if(!e||!r||!r.visto||e.morte||Math.hypot(e.x-r.e.x,e.y-r.e.y,e.z-r.e.z)>70)break;_ferirSer(e,m.d,r.e.x,r.e.z,'tnt');if(e.morte)enviarRede({t:'premio',para:m.de,tipo:e.tipo});break}
 case'invocar':{if(!REDE.host||!REDE.pronto||!BICHOS[m.tipo]||m.tipo==='npc'||BICHOS[m.tipo].chefe)break;const extra={y:m.y,fundo:profundidade(m.x,m.y,m.z)>4};if(m.tipo==='golem'||m.tipo==='barco')Object.assign(extra,{manso:true,posto:{x:m.x,z:m.z}});if(m.tipo==='barco')extra.y=0;const e=criar(m.tipo,m.x,m.z,extra);if(m.tipo==='peixe')e.corpo=CORPOS.peixe;break}
 case'barco':{if(!REDE.host)break;const e=seres.find(e=>e.rid===m.s&&e.tipo==='barco');if(!e)break;if(m.entra)e.oculto=m.de;else{e.oculto=0;e.x=m.x;e.z=m.z;e.h=m.h;e.y=0}break}
 case'efeito':if(REDE.pronto){const v=m.v;if(m.k==='flecha'){_atirar(...v.slice(0,6),0,false);flechas.at(-1).visual=true}else if(m.k==='boom'){const[x,y,z,R]=v;som('explosao');faisca(x,y+.5,z,[1,.55,.1],30,.8);const d=Math.hypot(P.x-x,pes()-y,P.z-z);if(d<R+2.5)_ferirJogador((R+2.5-d)*7,x,z)}else if(m.k==='morreu'){const r=REDE.remotos.get(m.de);if(r)avisar(`${r.nome} caiu.`,3)}}break;
 case'corrigir':if(REDE.pronto){P.x=m.x;P.z=m.z;P.y=m.y+1.7;P.vy=0}break;
 case'pong':REDE.ping=Math.round(performance.now()-m.n);break}}

// ---------- mundo compartilhado ----------
function dadosBase(){const s=dadosSalvos();return{ES:s.ES,hora,dia,obras:construcoes.map(c=>({...dadosObra(c),itens:c.itens})),vilas:s.vilas,soltos:M.chao.filter(g=>g.solto&&!g.pego&&ITENS[g.item]).slice(-200).map(g=>[g.id||(g.id=novoId()),g.item,g.q,g.x,g.y,g.z]),pos:{x:P.x,y:pes(),z:P.z}}}
const chaveMochila=()=>`alone.rede.${REDE.mundo?.semente}.${REDE.mundo?.tam}.${REDE.mundo?.nome}`;
const mochila=()=>({inv:P.inv,armadura:P.armadura,moedas:P.moedas,vida:Math.max(20,P.vida),fome:P.fome,sel:P.sel});
function guardarMochila(){if(REDE.pronto&&!criativo())guardar(chaveMochila(),JSON.stringify(mochila()))}
function entrarNoMundoDoHost(m){const antes=REDE.pronto?{...mochila(),x:P.x,y:P.y,z:P.z,yaw:P.yaw,pitch:P.pitch}:null;REDE.fila=[];REDE.pronto=false;REDE.ativo=true;REDE.carregando=true;REDE.mundo=m.mundo;
 estado='carregando';janela('Alone',false,el(`<p>Entrando no mundo de ${esc(m.mundo.nome)}…</p>`));
 setTimeout(()=>{if(!REDE.conectado)return;try{const w=m.mundo,d=m.dados,meta={id:'_rede',nome:w.nome,semente:w.semente,tam:w.tam,modo:w.modo,dif:w.dif};REDE.difAntes??=CFG.dif;
  const a=REDE.id*1.7,p=novoP(),salvo=antes||ler(chaveMochila());Object.assign(p,{x:d.pos.x+Math.cos(a)*1.6,y:d.pos.y+2.2,z:d.pos.z+Math.sin(a)*1.6});
  if(salvo)Object.assign(p,salvo);else if(w.modo==='criativo'){['b_tabuas','b_pedregulho','b_vidro','b_lampada','espada_diamante','picareta_diamante','tocha','b_tnt'].forEach((id,i)=>p.inv[i]=[id,ITENS[id].pilha]);p.moedas=999}
  REDE.fantoches.clear();aplicando(()=>iniciarPartida(meta,{ES:d.ES,hora:d.hora,dia:d.dia,P:p,stats:{},vilas:d.vilas,obras:d.obras,pets:[],soltos:[]}));
  for(const[id,item,q,x,y,z]of d.soltos)if(ITENS[item])M.chao.push({id,item,q,x,y,z,pego:false,solto:true,espera:.8,vida:240,cav:false});
  limparSeres();ES.tempoParado=true;P.proxEvento=1e12;REDE.sigPlantas=assinaturaPlantas();REDE.carregando=false;REDE.pronto=true;jogar();avisar('Você entrou na partida.',3)}
  catch(e){console.error(e);encerrarComAviso('Não consegui abrir o mundo do Host: '+e.message);return}
  const f=REDE.fila||[];REDE.fila=null;for(const x of f)try{receberRede(x)}catch(e){console.error(e)}},60)}
function iniciarComoHost(){const{meta,save}=REDE.escolha;REDE.ativo=true;REDE.carregando=true;REDE.pronto=false;REDE.tela=null;
 carregarMundo(meta,save,()=>{if(!REDE.conectado)return;for(const g of M.chao)if(g.solto&&!g.id)g.id=novoId();REDE.sigPlantas=assinaturaPlantas();REDE.carregando=false;REDE.pronto=true;jogar();salvar();
  enviarRede({t:'iniciar',mundo:{semente:String(META.semente),tam:META.tam,modo:MODO,dif:CFG.dif,nome:META.nome,meio:M.MEIO}});avisar('Partida iniciada. Outros jogadores podem entrar pelo seu IP.',6)})}
function desligarRede(){const w=REDE.ws;REDE.saindo=true;if(w){if(w.readyState===1)w.send(JSON.stringify({t:'sair'}));w.close()}REDE.ws=null;REDE.saindo=false;
 for(const id of[...REDE.remotos.keys()])tirarRemoto(id);const eraHost=REDE.host;Object.assign(REDE,{ativo:false,host:false,conectado:false,pronto:false,carregando:false,id:0,token:null,sala:null,chave:null,fila:null,lote:[],desvio:null,tela:null,bauAberto:null,bauPedido:null,barco:null,mundo:null,real:null,tentativas:0,aplicando:0});REDE.anteriores.clear();REDE.fantoches.clear();
 if(REDE.difAntes){CFG.dif=REDE.difAntes;REDE.difAntes=null}
 if(eraHost&&ponte())setTimeout(()=>{if(!REDE.conectado&&!REDE.chave)ponte().pararServidor()},400)}
REDE.sair=()=>{const jogava=REDE.ativo;if(REDE.pronto)salvar();desligarRede();if(jogava){emPartida=false;comecou=false;estado='menu';limparSeres();previaDeFundo()}telaInicial()};
function encerrarComAviso(texto){if(REDE.pronto)salvar();const jogava=REDE.ativo;desligarRede();if(document.pointerLockElement)document.exitPointerLock();soltarControles();if(jogava){emPartida=false;comecou=false;estado='menu';previaDeFundo()}telaInicial();
 janela('Partida encerrada',false,el(`<p id="msgRede">${esc(texto)}</p>`),fila(botao('Voltar ao início',telaInicial,'p')))}

// ---------- relógio da rede ----------
let tPos=0,tSer=0,tTempo=0,tPing=0,ultimoEstado='',tEstado=0,xAnt=null,zAnt=null,estavaMorto=false;
function tiqueRede(){if(!REDE.conectado)return;const a=performance.now();
 if(a-tPing>2000){tPing=a;enviarRede({t:'ping',n:a})}if(REDE.ws&&REDE.ws.readyState===1&&a-REDE.ultimaMsg>9000){REDE.ws.close()}
 mostrarInfoRede();if(!REDE.pronto||REDE.fila)return;
 if(P.golpe>REDE.golpeAnt+.4)REDE.golpe++;REDE.golpeAnt=P.golpe;
 const morto=estado==='morto';if(morto&&!estavaMorto)enviarRede({t:'efeito',k:'morreu',v:[]});estavaMorto=morto;
 if(a-tPos>=65){tPos=a;const n=v=>Math.round(v*100)/100,it=naMao(),vel=P.barco?0:Math.min(40,Math.hypot(entrada.f,entrada.l)*(P.voando?11:P.correndo?9:5));
  const f=(P.sub>.9?1:0)|(P.barco?2:0)|(P.voando?4:0)|(it?.distancia&&(entrada.atacando||P.recarga>0)?8:0)|(morto?16:0)|(P.montaria?32:0);
  const e=[n(P.x),n(pes()),n(P.z),n(P.yaw%TAU),n(P.pitch),n(vel),f,REDE.golpe,it?it.id:'',P.armadura.map(c=>c?c[0]:null),Math.max(0,Math.min(100,Math.ceil(P.vida))),''],s=JSON.stringify(e);
  if(s!==ultimoEstado||a-tEstado>600){const tp=xAnt!==null&&Math.hypot(P.x-xAnt,P.z-zAnt)>6;if(finito(P.x,P.y,P.z)){enviarRede({t:'p',e,tp:tp||undefined});ultimoEstado=s;tEstado=a;xAnt=P.x;zAnt=P.z}}}
 while(REDE.lote.length)enviarRede({t:'op',o:'bloco',l:REDE.lote.splice(0,1600)});
 if(REDE.anteriores.size>6000)REDE.anteriores.clear();
 const b=REDE.bauAberto;if(b){const aberto=estado==='painel'&&painelTipo==='bau'&&painelArg===b.b,sig=JSON.stringify(b.b.itens);if(sig!==b.sig){b.sig=sig;enviarRede({t:'op',o:'bau',id:b.k,itens:b.b.itens.slice(0,32)})}if(!aberto){enviarRede({t:'destravar',id:b.k});REDE.bauAberto=null}}
 if(a-tTempo>500){const s=assinaturaPlantas();if(s!==REDE.sigPlantas){REDE.sigPlantas=s;enviarRede({t:'op',o:'plantas',l:ES.plantas.slice(0,600).map(p=>({x:p.x,z:p.z,t:p.t,i:p.i}))})}}
 if(a-tTempo>900){tTempo=a;if(REDE.host)enviarRede({t:'tempo',hora,dia,chuva:Math.max(0,Math.min(1,climaAlvo))})}
 if(REDE.host){if(a-tSer>=95){tSer=a;enviarSeres()}}
 else if(REDE.barco!==P.barco){const v=REDE.barco;if(v){v.meu=false;v.buf=[];enviarRede({t:'barco',s:v.rid,entra:false,x:v.x,z:v.z,h:v.h})}const q=P.barco;if(q&&q.rid){q.meu=true;enviarRede({t:'barco',s:q.rid,entra:true,x:q.x,z:q.z,h:q.h})}REDE.barco=P.barco}}
setInterval(tiqueRede,33);
// com a tela do Host em segundo plano os quadros param; o mundo continua por aqui
setInterval(()=>{if(document.hidden&&REDE.pronto&&REDE.host){for(let i=0;i<4;i++){tempo+=.05;simular(.05)}}},200);
let infoRede=null,tInfo=0;
function mostrarInfoRede(){const a=performance.now();if(a-tInfo<500)return;tInfo=a;if(!infoRede){infoRede=el('<div class="cx" id="redeInfo"></div>');$('hud').append(infoRede)}infoRede.hidden=!REDE.pronto;if(!REDE.pronto)return;
 const n=REDE.sala?.jogadores.length||1;infoRede.textContent=`Rede ${n}/4 · ${REDE.host?(REDE.ips[0]?REDE.ips[0]+':'+REDE.porta:'Host'):REDE.ws?REDE.ping+' ms':'reconectando…'}`}

// ---------- telas ----------
const _tela=tela;tela=function(...n){REDE.tela=null;_tela(...n)};
const _telaInicial=telaInicial;telaInicial=function(){if(REDE.conectado&&REDE.pronto){REDE.sair();return}if(REDE.conectado)desligarRede();_telaInicial()};
const campoRede=(id,rotulo,valor,extra='')=>`<div class="opc"><label for="${id}">${rotulo}</label><input id="${id}" class="campo" value="${esc(valor)}" ${extra}></div>`;
const escolhaLista=(id,rotulo,ops,atual)=>`<div class="opc"><label for="${id}">${rotulo}</label><select id="${id}" class="campo">${Object.entries(ops).map(([k,v])=>`<option value="${esc(k)}"${k===atual?' selected':''}>${esc(v)}</option>`).join('')}</select></div>`;
function campoNick(){const d=el(`<div>${campoRede('rNick','Seu nick',SKIN.nick,'maxlength="16"')}</div>`);d.querySelector('input').addEventListener('input',e=>{SKIN.nick=validarSkin({...SKIN,nick:e.target.value}).nick;gravarSkin()});return d}
function telaMulti(){janela('Multiplayer LAN',false,el('<p>De 2 a 4 jogadores no mesmo Wi-Fi, sem internet. Um aparelho cria a sala e os outros entram pelo IP dele.</p>'),campoNick(),col(botao('Criar sala',()=>telaCriar(),'p'),botao('Entrar em uma sala',()=>telaEntrar(),'p'),botao('Personagem',()=>telaPersonagem('prontos',telaMulti)),botao('Voltar',telaInicial)))}
function telaCriar(erro){
 if(!ponte()&&!REDE.chaveURL){janela('Criar sala',false,el('<p>Para <b>hospedar</b> uma partida use o aplicativo Android do Alone. Navegadores não podem abrir um servidor.</p><p>Num computador, a alternativa é ligar o <b>alone-servidor.jar</b> (precisa de Java) e abrir o endereço que ele mostrar.</p>'),erro?el(`<p class="falta">${esc(erro)}</p>`):null,fila(botao('Entrar em uma sala',()=>telaEntrar(),'p'),botao('Voltar',telaMulti)));return}
 const l=lerIndice(),mundos={novo:'Novo mundo',...Object.fromEntries(l.map(m=>[m.id,`${m.nome} · dia ${m.dia|0}`]))};
 const f=el(`<div>${escolhaLista('rMundo','Mundo',mundos,'novo')}<div id="rNovo">${campoRede('rNome','Nome do mundo','Mundo em rede','maxlength="24"')}${escolhaLista('rModo','Modo',{sobrevivencia:'Sobrevivência',criativo:'Criativo'},'sobrevivencia')}${escolhaLista('rTam','Tamanho',Object.fromEntries(Object.entries(TAMANHOS).map(([k,v])=>[k,v[1]])),'medio')}${escolhaLista('rDif','Dificuldade',Object.fromEntries(Object.entries(DIFICULDADES).map(([k,v])=>[k,v.n])),CFG.dif)}</div></div>`);
 f.querySelector('#rMundo').addEventListener('change',e=>f.querySelector('#rNovo').hidden=e.target.value!=='novo');
 janela('Criar sala',false,f,erro?el(`<p class="falta">${esc(erro)}</p>`):null,fila(botao('Criar sala',()=>{const v=id=>f.querySelector('#'+id).value;let meta,save=null;
  if(v('rMundo')==='novo')meta={id:Date.now().toString(36)+(Math.random()*1e4|0),nome:v('rNome').trim()||'Mundo em rede',semente:String(Math.floor(Math.random()*1e6)),tam:v('rTam'),modo:v('rModo'),dif:v('rDif')};
  else{save=lerSave(v('rMundo'));if(!save){telaCriar('Não encontrei o salvamento desse mundo.');return}meta=save.meta}
  REDE.escolha={meta,save};criarSala()},'p'),botao('Voltar',telaMulti)))}
async function criarSala(){desligarRede();REDE.ultimoErro=null;
 if(ponte()){let r;try{r=JSON.parse(ponte().iniciarServidor())}catch(e){r={ok:false,erro:e.message}}if(!r.ok){telaCriar('Não consegui ligar o servidor: '+r.erro);return}REDE.chave=r.chave;REDE.porta=r.porta;REDE.ips=r.ips;REDE.endereco=`ws://127.0.0.1:${r.porta}/ws`}
 else{REDE.chave=REDE.chaveURL;REDE.porta=+location.port||80;REDE.endereco=`ws://${location.host}/ws`;REDE.ips=[];try{const i=await(await fetch('/info')).json();REDE.ips=i.ips||[]}catch(e){}}
 janela('Criar sala',false,el('<p>Ligando o servidor…</p>'),botao('Cancelar',()=>{desligarRede();telaMulti()}));conectar()}
function telaEntrar(erro){const doServidor=location.protocol==='http:'&&location.hostname,ultimo=ler('alone.rede.ultimo')||{};
 const f=el(`<div>${campoRede('rIp','IP do Host',ultimo.ip||(doServidor?location.hostname:''),'inputmode="decimal" placeholder="192.168.0.10" autocomplete="off"')}${campoRede('rPorta','Porta',ultimo.porta||(doServidor&&location.port)||'8765','inputmode="numeric" maxlength="5"')}</div>`);
 janela('Entrar em uma sala',false,campoNick(),f,erro?el(`<p class="falta" id="rErro" role="alert">${esc(erro)}</p>`):null,fila(botao('Conectar',()=>{let ip=f.querySelector('#rIp').value.trim().replace(/^\w+:\/\//,'').replace(/\/.*$/,''),porta=f.querySelector('#rPorta').value.trim();const par=/^(.*):(\d+)$/.exec(ip);if(par){ip=par[1];porta=par[2]}
  if(!/^[A-Za-z0-9.\-]{3,60}$/.test(ip)||!/^\d{1,5}$/.test(porta)||+porta<1||+porta>65535){telaEntrar('Digite um IP e uma porta válidos, como 192.168.0.10 e 8765.');return}
  if(location.protocol==='https:'){telaEntrar('Esta página segura (https) não pode acessar a rede local. Abra o app ou o endereço do Host.');return}
  desligarRede();REDE.ultimoErro=null;REDE.porta=+porta;REDE.ips=[ip];REDE.endereco=`ws://${ip}:${porta}/ws`;guardar('alone.rede.ultimo',JSON.stringify({ip,porta}));
  janela('Conectando…',false,el(`<p id="rEstado">Procurando a sala em ${esc(ip)}:${esc(porta)}…</p>`),botao('Cancelar',()=>{desligarRede();telaEntrar()}));try{conectar()}catch(e){telaEntrar('Endereço inválido.')}},'p'),botao('Voltar',telaMulti)))}
function telaSala(aviso){const s=REDE.sala,l=s?.jogadores||[];estado='menu';
 const linhas=l.map(j=>`<div class="mundo"><div><b>${esc(j.nome)}${j.id===REDE.id?' (você)':''}</b><small>${j.host?'Host':'Convidado'} · ${j.online?'conectado':'reconectando…'}</small></div></div>`).join('');
 const info=REDE.host?`<p>Peça para os outros entrarem com:</p><p class="ipsala"><b>${REDE.ips.length?REDE.ips.map(i=>`${esc(i)} · porta ${REDE.porta}`).join('<br>'):'Não encontrei um IP de rede local. Ligue o Wi-Fi ou o roteador do celular.'}</b></p><p>No navegador: <b>http://IP:${REDE.porta}</b></p>`:`<p>Conectado a ${esc(REDE.ips[0]||'')}:${REDE.porta} · ${REDE.ping||'…'} ms</p><p>${REDE.fase==='jogo'?'Carregando a partida…':'Aguardando o Host iniciar.'}</p>`;
 janela('Sala de espera',false,el(`<div>${info}<h3 id="rQtd">Jogadores ${l.length}/${s?.max||4}</h3><div id="rLista">${linhas}</div>${aviso?`<p class="falta">${esc(aviso)}</p>`:''}</div>`),
  fila(REDE.host?botao('Iniciar partida',()=>{if((REDE.sala?.jogadores.length||0)<2){telaSala('Espere pelo menos mais um jogador (mínimo de 2).');return}iniciarComoHost()},'p'):null,botao('Personagem',()=>telaPersonagem('prontos',()=>{enviarRede({t:'perfil',nome:SKIN.nick,skin:SKIN});telaSala()})),botao('Sair da sala',()=>{desligarRede();telaMulti()})));REDE.tela='sala'}
const _telaPausa=telaPausa;telaPausa=function(){if(!REDE.ativo)return _telaPausa();enviarRede({t:'perfil',nome:SKIN.nick,skin:SKIN});const l=REDE.sala?.jogadores||[];
 janela('Menu da partida',false,el(`<p>${esc(META.nome)} · ${MODOS[MODO][0]} · dia ${dia} · a partida continua rodando</p>`),el(`<p>${l.map(j=>esc(j.nome)+(j.host?' (Host)':'')).join(' · ')}</p>`),REDE.host?el(`<p>Entrada: <b>${esc(REDE.ips.map(i=>i+':'+REDE.porta).join(' ou ')||'sem IP local')}</b></p>`):null,
  col(botao('Continuar',jogar,'p'),botao('Personagem',()=>telaPersonagem('montar',telaPausa)),botao('Configurações',()=>telaConfig(telaPausa)),botao('Como jogar',()=>telaAjuda(telaPausa)),botao(REDE.host?'Encerrar a partida para todos':'Sair da partida',()=>REDE.sair(),'perigo')))};
window.REDE_ATIVA=()=>REDE.conectado;
// botão "voltar" do Android: devolve false quando o aplicativo pode fechar
window.AloneVoltar=()=>{if(estado==='jogando'){pausar();return true}if(estado==='painel'){fecharPainel();return true}if(estado==='pausa'){jogar();return true}if(document.querySelector('.inicio'))return false;if(estado!=='carregando'&&estado!=='morto')telaInicial();return true};
