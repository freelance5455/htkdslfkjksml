// ---------- modelos de itens (na mão e no chão) ----------
const cacheItem={};
const hexCor=c=>{if(c.startsWith('hsl')){const m=c.match(/[\d.]+/g).map(Number),[h,s,l]=[m[0],m[1]/100,m[2]/100],f=n=>{const k=(n+h/30)%12;return l-s*Math.min(l,1-l)*Math.max(-1,Math.min(k-3,9-k,1))};return[f(0),f(8),f(4)]}return[1,3,5].map(i=>parseInt(c.length<7?c[(i+1)/2]+c[(i+1)/2]:c.slice(i,i+2),16)/255)};
function geoBloco(num){const g=new Geo(),b=BLOCOS[num],n=4,dados=b.tex.map(t=>texCanvas(t).getContext('2d').getImageData(0,0,16,16).data);
 for(let f=0;f<6;f++){const[nm,cs]=FACES[f],d=dados[f===2?0:f===3?2:1],p=(u,v)=>{const a=cs[0],bb=cs[1],dd=cs[3];return[0,1,2].map(i=>a[i]+(bb[i]-a[i])*u+(dd[i]-a[i])*v-(i===1?0:.5))};
  for(let i=0;i<n;i++)for(let j=0;j<n;j++){const q=((15-(j*4+1))*16+i*4+1)*4;if(d[q+3]<90)continue;g.quad(p(i/n,j/n),p((i+1)/n,j/n),p((i+1)/n,(j+1)/n),p(i/n,(j+1)/n),[d[q]/255,d[q+1]/255,d[q+2]/255],b.luz>.5?-.8:0,null,nm)}}return g}
function modeloItem(id){if(cacheItem[id])return cacheItem[id];const it=ITENS[id];if(it.cat==='bloco')return cacheItem[id]={m:modelos[id],esc:id==='farol'?.07:.17};
 const guardado=estadoRnd;semearLocal(id.length*37+id.charCodeAt(0),id.charCodeAt(id.length-1),99);let g=new Geo();const c=hexCor(it.cor),cabo=[.45,.28,.13],t=it.ic,luz=['cristal','diamante'].includes(it.material)||/cristal|diamante/.test(id)?-.25:0;
 if(t==='cubo'){g=geoBloco(it.bloco);estadoRnd=guardado;return cacheItem[id]={m:g.malha(),esc:.34,cubo:true}}
 if(t==='espada')g.caixa(0,.55,0,.09,.8,.03,c,luz).tri([-.045,.95,0],[.045,.95,0],[0,1.1,0],c,luz,null,[0,0,1]).caixa(0,.13,0,.3,.06,.08,[.78,.62,.2]).caixa(0,-.03,0,.07,.26,.07,cabo);
 else if(t==='faca')g.caixa(0,.3,0,.08,.36,.025,c,luz).tri([-.04,.48,0],[.04,.48,0],[.04,.6,0],c,luz,null,[0,0,1]).caixa(0,.02,0,.07,.22,.07,cabo);
 else if(t==='machado')g.caixa(0,.35,0,.07,.9,.07,cabo).caixa(0,.72,-.12,.08,.26,.26,c,luz).caixa(0,.72,-.29,.04,.36,.1,c,luz);
 else if(t==='picareta')g.caixa(0,.35,0,.07,.9,.07,cabo).caixa(0,.8,0,.09,.1,.34,c,luz).caixa(0,.75,-.26,.07,.08,.22,c,luz).caixa(0,.75,.26,.07,.08,.22,c,luz).caixa(0,.67,-.4,.05,.09,.1,c,luz).caixa(0,.67,.4,.05,.09,.1,c,luz);
 else if(t==='pa')g.caixa(0,.35,0,.07,.9,.07,cabo).caixa(0,.88,0,.26,.26,.05,c,luz).caixa(0,1.05,0,.16,.1,.05,c,luz);
 else if(t==='enxada')g.caixa(0,.35,0,.07,.9,.07,cabo).caixa(0,.8,-.14,.08,.07,.34,c,luz).caixa(0,.72,-.3,.08,.16,.06,c,luz);
 else if(t==='martelo')g.caixa(0,.3,0,.08,.8,.08,cabo).caixa(0,.74,0,.18,.2,.42,c);
 else if(t==='lanca')g.caixa(0,.45,0,.06,1.5,.06,cabo).tronco(0,0,1.2,1.5,.1,0,4,c);
 else if(t==='arco'){for(let i=-4;i<=4;i++)g.caixa(0,i*.13+.2,-(16-i*i)*.018,.06,.15,.07,c);g.caixa(0,.2,0,.012,1.1,.012,[.9,.9,.85])}
 else if(t==='besta')g.caixa(0,.35,0,.09,.8,.1,c).caixa(0,.68,0,.75,.08,.07,[.35,.22,.1]).caixa(0,.52,0,.72,.012,.012,[.9,.9,.85]);
 else if(t==='vara')g.caixa(0,.6,0,.045,1.4,.045,cabo).caixa(0,.18,-.07,.1,.1,.08,[.3,.3,.32]);
 else if(t==='tocha')g.caixa(0,.2,0,.08,.6,.08,cabo).caixa(0,.53,0,.14,.1,.14,[.2,.12,.06]).bola(0,.7,0,.11,.17,.11,COR.fogo,-1,.3);
 else if(t==='flecha')g.caixa(0,.3,0,.035,.75,.035,cabo).tronco(0,0,.66,.8,.06,0,4,[.7,.72,.76]).caixa(0,-.04,0,.14,.14,.012,[.9,.9,.9]).caixa(0,-.04,0,.012,.14,.14,[.8,.2,.15]);
 else if(t==='armadura')g.caixa(0,.25,0,.42,.5,.18,c,luz).caixa(-.26,.42,0,.16,.14,.16,c,luz).caixa(.26,.42,0,.16,.14,.16,c,luz);
 else if(t==='capacete')g.caixa(0,.35,0,.38,.14,.36,c,luz).caixa(0,.22,-.17,.38,.18,.04,c,luz).caixa(-.18,.22,0,.04,.18,.36,c,luz).caixa(.18,.22,0,.04,.18,.36,c,luz);
 else if(t==='calca')g.caixa(0,.45,0,.34,.1,.18,c,luz).caixa(-.11,.2,0,.13,.4,.16,c,luz).caixa(.11,.2,0,.13,.4,.16,c,luz);
 else if(t==='botas')for(const s of[-1,1])g.caixa(s*.13,.2,0,.15,.24,.18,c,luz).caixa(s*.13,.11,.1,.15,.08,.16,c,luz);
 else if(t==='escudo')g.caixa(0,.3,0,.5,.55,.07,c).caixa(0,.3,.045,.08,.55,.02,[.8,.82,.86]).caixa(0,.38,.045,.5,.08,.02,[.8,.82,.86]).tri([-.25,.03,0],[.25,.03,0],[0,-.18,0],c,0,null,[0,0,1]);
 else if(t==='tesoura')g.caixa(-.06,.35,0,.05,.6,.03,c).caixa(.06,.35,0,.05,.6,.03,c).bola(-.09,0,0,.08,.08,.03,[.7,.15,.1]).bola(.09,0,0,.08,.08,.03,[.7,.15,.1]);
 else if(t==='balde')g.tronco(0,0,0,.34,.15,.22,8,[.7,.74,.78]).tronco(0,0,.3,.31,.2,0,8,id==='balde'?[.25,.27,.3]:c).caixa(0,.48,0,.44,.025,.025,[.5,.52,.55]);
 else if(t==='barco')g.junta(GEO.barco,0,0,0),g.v.forEach((v,i)=>{if(i%10<3)g.v[i]=v*.2});
 else if(t==='barra')g.caixa(0,.15,0,.45,.14,.2,c);
 else if(t==='cristal')g.tronco(0,0,.05,.3,.04,.14,5,c,-.7,-.7).tronco(0,0,.3,.5,.14,0,5,c,-.8,-.8);
 else if(t==='tronco')g.caixa(0,.15,0,.18,.18,.55,cabo).caixa(0,.15,0,.14,.14,.57,[.82,.62,.36]);
 else if(t==='cogumelo')g.junta(GEO.cogumelo,0,0,0);
 else if(t==='pocao')g.bola(0,.18,0,.19,.18,.19,c,-.3,.05).caixa(0,.4,0,.09,.14,.09,[.8,.9,.95]).caixa(0,.49,0,.11,.06,.11,cabo);
 else if(t==='ovo')g.bola(0,.22,0,.16,.22,.16,c,-.1,.03);
 else if(t==='nucleo')g.caixa(0,.2,0,.34,.34,.34,[.45,.47,.44]).bola(0,.2,0,.24,.24,.24,[.25,.95,.82],-1,.1);
 else{g.bola(0,.2,0,.2,.18,.2,c,0,.2);if(t==='carne')g.caixa(.22,.12,0,.22,.06,.06,[.93,.9,.84]);if(t==='fruta')g.caixa(0,.42,0,.03,.1,.03,cabo)}
 estadoRnd=guardado;return cacheItem[id]={m:g.malha(),esc:1}}
let mFlecha,mBraco,mBoia;
function criarModelosFixos(){mFlecha=new Geo().caixa(0,0,0,.035,.035,.8,[.5,.33,.15]).caixa(0,0,.44,.08,.08,.12,[.75,.76,.8]).caixa(0,0,-.36,.14,.012,.14,[.9,.9,.9]).caixa(0,0,-.36,.012,.14,.14,[.8,.2,.15]).malha();
 mBoia=new Geo().caixa(0,.06,0,.14,.12,.14,[.9,.15,.1]).caixa(0,-.04,0,.12,.09,.12,[.95,.95,.95]).caixa(0,.17,0,.025,.12,.025,[.2,.2,.2]).malha();criarAtlas();criarSombra(4)}
function refazerCorpoJogador(){apagarCorpo(corpoJogador);corpoJogador=corpoSkin(SKIN,P.armadura.map(c=>c&&c[0]));if(mBraco)apagarMalha(mBraco);
 const g=new Geo(),cam=rgb(SKIN.camisa),pele=rgb(SKIN.pele),a=P.armadura[1]&&rgb(ITENS[P.armadura[1][0]].cor);g.caixa(0,-.02,0,.15,.5,.15,cam).caixa(0,-.37,0,.14,.24,.14,pele);if(a)g.caixa(0,.02,0,.18,.46,.18,a);mBraco=g.malha();P.corpoSujo=false}

// ---------- desenho ----------
let escalaAuto=1,chuvaForca=0,raioForca=0,VPatual=ID,camAtual=[0,0,0],uAtual=cena.u,passoSombra=false;
function desenharMalha(m,modelo){gl.uniformMatrix4fv(uAtual.uModel,false,modelo);gl.bindVertexArray(m.vao);gl.drawArrays(gl.TRIANGLES,0,m.n)}
const tinta=(r,g,b,a)=>{if(!passoSombra)gl.uniform4f(uAtual.uTint,r,g,b,a)};
function desenharSer(e,jog){const def=e.def;let base=mul(T(e.x,e.y-(e.surge||0)*1.8,e.z),RY(e.h));if(e.escala&&e.escala!==1)base=mul(base,E(e.escala));
 if(e.morte){const k=Math.min(1,e.morte/.45);base=cadeia(base,T(0,k*.15,0),RZ(k*1.55))}
 if(e.nado)base=cadeia(base,T(0,.9,0),RX(1.25*e.nado),T(0,-.9,0));
 if(e.flash>0)tinta(1,.15,.1,.65);
 const amp=Math.min((e.v||0)*.17,.8),bal=Math.sin(e.fase),golpe=e.golpe||0,s=Math.sin(golpe*Math.PI);
 for(const p of e.corpo.partes){const[px,py,pz]=p.pivo;let m=mul(base,T(px,py,pz));
  if(p.anim==='perna')m=mul(m,RX(e.sentadoBarco?-1.45:Math.sin(e.fase+p.fase)*amp));
  else if(p.anim==='braco'||p.anim==='braco_d'){let a=Math.sin(e.fase+p.fase+Math.PI)*amp*.8;
   if(jog){if(p.anim==='braco_d'){if(e.segura)a=a*.35-.35;if(golpe>0)a=-s*1.6-.35;if(e.atirando)a=-1.5-e.pitch}else if(e.escudo)a=-.7;else if(e.atirando)a=-1.5-e.pitch}
   else if(def.arqueiro&&Math.hypot(e.x-P.x,e.z-P.z)<30)a=-1.5;else if(golpe>0&&p.fase)a=-golpe*1.9;else if(e.npc&&!e.v)a=Math.sin(tempo*1.3+p.fase)*.05;else if(e.tipo==='golem'&&golpe>0)a=-golpe*2.4;
   if(e.sentadoBarco)a=-.9+Math.sin(e.fase*2+p.fase)*.35;m=mul(m,RX(a));if(jog&&e.nado)m=mul(m,RX(-2.2*e.nado+Math.sin(e.fase+p.fase)*1.2*e.nado))}
  else if(p.anim==='frente')m=mul(m,RX(-1.35+bal*.12-golpe*.8*Math.sin(golpe*3)));
  else if(p.anim==='pescoco')m=mul(m,RX(golpe?golpe*.8:(!e.v&&!def.monstro&&!e.manso?(Math.sin(tempo*.5+e.max+e.x*.1)>.3?.9:0):e.sentado?-.2:0)));
  else if(p.anim==='cabeca')m=mul(m,jog?RX(clamp(-e.pitch,-.7,.7)):RX(Math.sin(tempo+e.x)*.05+(e.fala>0?Math.sin(tempo*6+e.x)*.07:0)));
  else if(p.anim==='capa')m=mul(m,RX(Math.min(1.25,.08+(e.v||0)*.13)+Math.sin(tempo*3+e.fase)*.04));
  else if(p.anim==='pata')m=mul(m,cadeia(RY(Math.sin(e.fase*1.8+p.fase)*amp*.6),RZ(Math.max(0,Math.cos(e.fase*1.8+p.fase))*amp*.3*(px>0?1:-1))));
  else if(p.anim==='asa')m=mul(m,RZ(p.fase*Math.sin(tempo*(def.enfeite?22:11)+e.max+e.x*.3)*(e.voando?(def.enfeite?1:.7):.06)));
  else if(p.anim==='cauda')m=mul(m,RY(Math.sin(tempo*7+e.max*e.x)*.5));
  else if(p.anim==='gelatina'){const k=e.vy>1?1.22:e.vy<-2?.85:1+Math.sin(tempo*5+e.x)*.05;m=mul(m,E(1/Math.sqrt(k),k,1/Math.sqrt(k)))}
  desenharMalha(p.m,m);
  if(jog&&p.anim==='braco_d'&&e.segura){const it=modeloItem(e.segura),i=ITENS[e.segura];let t=cadeia(m,T(0,-.68,.06));if(it.cubo)t=cadeia(t,T(0,-.12,.08),E(.28));else if(i.cat==='bloco')t=cadeia(t,T(0,-.15,.12),E(it.esc*.8));else if(i.cat==='arma'||i.cat==='ferramenta')t=cadeia(t,RX(i.distancia?1.57:1.35),E(.72));else t=cadeia(t,T(0,-.1,.05),E(.5));desenharMalha(it.m,t)}
  if(jog&&p.anim==='braco'&&e.escudo){const it=modeloItem(e.escudo);desenharMalha(it.m,e.escudo==='escudo'?cadeia(m,T(.0,-.55,.2),RX(.7),E(.85)):cadeia(m,T(0,-.68,.06),RX(1.35),E(.65)))}}
 if(e.flash>0)tinta(0,0,0,0)}
let faseJog=0;
function bonecoJogador(){const it=naMao(),vel=P.barco?0:Math.min(10,Math.hypot(entrada.f,entrada.l)*(P.correndo?9:5));
 return{x:P.barco?P.barco.x:P.x,y:P.barco?P.barco.y-.35:pes(),z:P.barco?P.barco.z:P.z,h:P.yaw+Math.PI,v:vel,fase:faseJog,golpe:P.golpe,pitch:P.pitch,corpo:corpoJogador,def:{},segura:it?.id,escudo:P.armadura[4]?.[0],atirando:it?.distancia&&(entrada.atacando||P.recarga>0),nado:P.sub>.9&&vel>1?1:0,sentadoBarco:!!P.barco||!!P.montaria}}
function camera3(olho,F,dist){let d=.3;for(;d<dist;d+=.18){const x=olho[0]+F[0]*(d+.25),y=olho[1]+F[1]*(d+.25),z=olho[2]+F[2]*(d+.25);if(solidoVox(Math.floor(x),Math.floor(y),Math.floor(z))||solidoT(x,y,z)||solidoT(x,y-.18,z)||bloqueado(x,y,z))break}return olho.map((v,i)=>v+F[i]*d)}
function listaChunks(cx,cz,r,sy,cy,meio,pit){const l=[];for(const ch of M.chunks.values()){const dx=ch.x-cx,dz=ch.z-cz,d=Math.hypot(dx,dz);if(d>r+36)continue;if(meio&&d>55&&Math.abs(pit)<.8&&(-dx*sy-dz*cy)/d<Math.cos(Math.min(3.1,meio+Math.asin(Math.min(1,40/d)))))continue;l.push([ch,d])}return l}
// desenha tudo o que é opaco; usada tanto na imagem quanto no mapa de sombras
function opacos(vis,cx,cz,alcance,sombraP){gl.vertexAttrib4f(4,0,0,0,1);gl.vertexAttrib2f(5,0,1);gl.uniformMatrix4fv(uAtual.uModel,false,ID);const perto=(o,r)=>Math.abs(o.x-cx)<r&&Math.abs(o.z-cz)<r;
 {gl.uniform1f(uAtual.uFade,0);for(const[ch]of vis){for(const m of[ch.chao,ch.estrut])if(m){gl.bindVertexArray(m.vao);gl.drawArrays(gl.TRIANGLES,0,m.n)}}
  for(const tipo in ALCANCE){const miudo=tipo==='capim'||tipo==='flor';if(sombraP&&(miudo||tipo==='trigo'||tipo==='junco'||tipo==='cogumelo'))continue;const r=alcance*ALCANCE[tipo];gl.uniform1f(uAtual.uFade,sombraP?0:r);
   for(const[ch,d]of vis){const m=ch.itens[tipo];if(!m||d-36>r)continue;const n=miudo?Math.floor(m.inst*CFG.grama):m.inst;if(!n)continue;gl.bindVertexArray(m.vao);gl.drawArraysInstanced(gl.TRIANGLES,0,m.n,n)}}
  gl.uniform1f(uAtual.uFade,0);gl.vertexAttrib4f(4,0,0,0,1);gl.vertexAttrib2f(5,0,1)}
 for(const t of M.tmalhas.values())if(t.deco.length&&Math.abs(t.cx*16+8-cx)<alcance&&Math.abs(t.cz*16+8-cz)<alcance)for(const m of t.deco){gl.bindVertexArray(m.vao);gl.drawArraysInstanced(gl.TRIANGLES,0,m.n,m.inst)}
 gl.vertexAttrib4f(4,0,0,0,1);gl.vertexAttrib2f(5,0,1);
 const maxE=Math.min(alcance,130);
 for(const e of seres){if(e.cav!==!!CAV||e.oculto||!perto(e,maxE))continue;if(e.tipo==='barco'){let m=mul(T(e.x,e.y,e.z),RY(e.h));if(e.morte)m=mul(m,RZ(e.morte));if(e.flash>0)tinta(1,.3,.2,.5);desenharMalha(modelos.barco,m);if(e.flash>0)tinta(0,0,0,0)}else desenharSer(e)}
 if(corpoJogador&&emPartida&&comecou&&CFG.camera&&estado!=='morto')desenharSer(bonecoJogador(),true);
 if(REDE.ativo)REDE.desenhar();
 for(const b of M.baus)if(!!b.cav===!!CAV&&perto(b,110))desenharMalha(b.aberto?modelos.bau_aberto:modelos.bau,mul(T(b.x,b.y,b.z),RY(b.a)));
 for(const o of construcoes){if(!!o.cav!==!!CAV||CAV&&o.cav!==CAV.f.i+1||!perto(o,alcance))continue;const m=mul(T(o.x,o.y,o.z),RY(o.a));if(o.tipo==='porta'){desenharMalha(modelos.batente,m);desenharMalha(modelos.porta,cadeia(m,T(-.72,0,0),RY(o.aberto?1.65:0)))}else desenharMalha(modelos[o.tipo],m)}
 if(!CAV)for(const p of ES.plantas){if(!perto(p,70))continue;const h=altura(p.x,p.z);desenharMalha(modelos.canteiro,T(p.x,h,p.z));if(p.t)desenharMalha(modelos[p.i<.5?'broto':p.t+'_pe'],cadeia(T(p.x,h,p.z),E(1,p.i<.5?.5+p.i*1.4:.4+p.i*.6,1)))}
 for(const b of bombas){const m=modeloItem('b_tnt'),k=1+Math.max(0,.5-b.t)*.5;if(Math.sin(b.t*18)>0)tinta(1,1,1,.7);desenharMalha(m.m,cadeia(T(b.x,b.y+.5,b.z),E(k),T(0,-.5,0)));tinta(0,0,0,0)}
 for(const g of M.chao){if(g.pego||!!g.cav!==!!CAV||!perto(g,55))continue;const it=modeloItem(g.item);desenharMalha(it.m,cadeia(T(g.x,g.y+(it.cubo?.18:.35)+Math.sin(tempo*2+g.x)*.1,g.z),RY(tempo*1.4+g.x),E(it.esc*(ITENS[g.item].cat==='bloco'?1.5:1))))}
 for(const f of flechas)if(perto(f,100))desenharMalha(mFlecha,cadeia(T(f.x,f.y,f.z),RY(Math.atan2(f.vx,f.vz)),RX(-Math.atan2(f.vy,Math.hypot(f.vx,f.vz)))));
 if(P.pesca&&!CAV)desenharMalha(mBoia,T(P.pesca.x,(P.pesca.y<.2?onda(P.pesca.x,P.pesca.z,tempo):P.pesca.y)-(P.pesca.fisgou>0?.15:0),P.pesca.z))}
function voxelsVisiveis(cx,cz,r){const l=[];for(const v of M.vch.values())if(Math.abs(v.cx*16+8-cx)<r+12&&Math.abs(v.cz*16+8-cz)<r+12)l.push(v);return l}
function uniformesLuz(u,c){gl.uniform3fv(u.uEye,c.olho);gl.uniform3fv(u.uSun,c.luzDir);gl.uniform3fv(u.uSunCol,c.corSol);gl.uniform3fv(u.uAmb,c.amb);gl.uniform3fv(u.uChao,c.chaoAmb);gl.uniform3fv(u.uFog,c.fog);gl.uniform1f(u.uDens,c.dens);gl.uniform1f(u.uTime,tempo);gl.uniform1f(u.uNoite,c.noite);gl.uniform4f(u.uTint,0,0,0,0);
 gl.uniform4fv(u.uLuz,c.luzes);gl.uniform1f(u.uTocha,c.tocha);gl.uniform1f(u.uSombra,c.sombra);gl.uniform1f(u.uTexel,1/mapaSombra.tam);gl.uniformMatrix4fv(u.uLuzVP,false,c.luzVP);gl.uniform1i(u.uMapa,1);gl.uniform1f(u.uCav,CFG.luzCav)}
function desenhar(){
 if(emPartida||!comecou)atualizarTerra(6);atualizarMascara();
 if(P.corpoSujo)refazerCorpoJogador();
 const q=CFG.res*Math.min(devicePixelRatio||1,CFG.modo==='touch'?1.35:1.5)*escalaAuto,w=Math.max(1,canvas.clientWidth*q|0),h=Math.max(1,canvas.clientHeight*q|0);if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h}
 desenharPrevia();
 const ang=(hora-.25)*TAU,el=Math.sin(ang),sl=Math.hypot(Math.cos(ang)*.85,el,.45),S=[Math.cos(ang)*.85/sl,el/sl,.45/sl];
 noite=1-smooth(-.22,.12,el);const kc=comecou?smooth(4,11,profundidade(P.x,P.y,P.z)):0,fundo=kc>=1,nt=lerp(noite,1,kc),clar=smooth(.04,.45,el),crep=clamp(1-Math.abs(el-.05)/.32,0,1),br=CFG.brilho,ch=chuvaForca*(1-kc);
 let fog=mix(mix([.035,.06,.12],[.66,.79,.86],1-noite),[.9,.52,.34],crep*.75),topo=mix(mix([.006,.014,.045],[.2,.44,.82],1-noite),[.26,.25,.52],crep*.6);
 const cinza=lerp(.55,.05,noite);fog=mix(fog,[cinza,cinza*1.04,cinza*1.1],ch*.75);topo=mix(topo,[cinza*.7,cinza*.75,cinza*.85],ch*.8);
 const luzDir=el>-.05?S:S.map(v=>-v);let corSol=(el>-.05?mix([1.05,.54,.26],[1.08,.98,.82],clar).map(v=>v*smooth(-.05,.15,el)):[.2,.3,.5].map(v=>v*smooth(.05,.3,-el))).map(v=>v*br*(1-ch*.75));
 let amb=mix([.18,.25,.42],[.5,.6,.74],1-noite).map(v=>v*br*(1-ch*.18)+raioForca),chaoAmb=mix([.08,.09,.14],[.27,.23,.17],1-noite).map(v=>v*br+raioForca*.6);
 let dens=(noite>.5?1.95:1.7)/CFG.dist*(1+ch*.5);
 if(kc>0){fog=mix(fog,[.008,.01,.016],kc);amb=mix(amb,[.2,.21,.27].map(v=>v*br*CFG.luzCav),kc);chaoAmb=mix(chaoAmb,[.12,.11,.12].map(v=>v*br*CFG.luzCav),kc);corSol=corSol.map(v=>v*(1-kc));dens=lerp(dens,.028,kc)}
 // câmera
 const vitrine=!comecou,yawJ=vitrine?tempo*.05:P.yaw,pitJ=vitrine?-.12:P.pitch,modo=vitrine?0:CFG.camera;let yaw=yawJ,pit=pitJ;
 const cabeca=[P.x,P.y+(modo||P.barco||!CFG.balanco?0:Math.sin(P.passo*TAU)*.04)+(vitrine?4:0),P.z];let olho=cabeca;
 if(modo){if(modo===2){yaw+=Math.PI;pit=-pit}const c=Math.cos(pit);olho=camera3([cabeca[0],cabeca[1]+.15,cabeca[2]],[Math.sin(yaw)*c,-Math.sin(pit),Math.cos(yaw)*c],modo===2?3.6:4.4)}
 const sub=altura(olho[0],olho[2])<0&&olho[1]<onda(olho[0],olho[2],tempo)&&altura(olho[0],olho[2])<olho[1]||(()=>{const b=bloco(Math.floor(olho[0]),Math.floor(olho[1]),Math.floor(olho[2]));return ehAgua(b)})();
 const lava=(()=>{const b=bloco(Math.floor(olho[0]),Math.floor(olho[1]),Math.floor(olho[2]));return b&&BLOCOS[b].lava})();
 if(sub){fog=mix([.02,.09,.16],[.06,.3,.42],1-nt*.9);dens=.07}if(lava){fog=[.9,.3,.02];dens=.9}
 const asp=w/h,fovBase=CFG.fov*Math.PI/180*(P.zoom?.28:1)*(P.correndo&&!P.zoom?1.06:1),fov=asp<1?Math.min(1.75,fovBase*1.15):fovBase,tg=Math.tan(fov/2);
 const cp=Math.cos(pit),sp=Math.sin(pit),sy=Math.sin(yaw),cy=Math.cos(yaw),F=[-sy*cp,sp,-cy*cp],R=[cy,0,-sy],U=[sy*sp,cp,cy*sp];
 const proj=persp(fov,asp,.1,800),VP=cadeia(proj,RX(-pit),RY(-yaw),T(-olho[0],-olho[1],-olho[2]));VPatual=VP;camAtual=olho;
 // luzes pontuais mais próximas
 const todas=[],forca=lerp(.2+noite*1.25,1.35,kc);for(const l of M.luzes)if(!!l.cav===!!CAV){const d=dist2(l.x,l.z,P.x,P.z);if(d<75)todas.push([l.x,l.y,l.z,l.i*forca,d])}
 for(const v of voxelsVisiveis(P.x,P.z,50))for(const l of v.luzes)todas.push([l.x,l.y,l.z,l.i*forca,Math.hypot(l.x-P.x,l.z-P.z,(l.y-P.y)*2)]);
 for(const b of bombas)todas.push([b.x,b.y+1,b.z,1.5,0]);
 const naMaoT=naMao()?.id==='tocha'||P.armadura[4]?.[0]==='tocha';if(naMaoT&&modo&&comecou)todas.push([P.x,P.y,P.z,(.4+forca)*1.1,0]);
 todas.sort((a,b)=>a[4]-b[4]);const luzes=new Float32Array(48);todas.slice(0,12).forEach((l,i)=>luzes.set([l[0],l[1],l[2],l[3]*(1+Math.sin(tempo*11+l[0])*.06+Math.sin(tempo*23+l[2]*3)*.04)],i*4));
 const tocha=naMaoT&&!modo?lerp(.35+noite*1.25,1.5,kc)*(1+Math.sin(tempo*13)*.05):.35*kc;
 // mapa de sombras
 const nivel=fundo?0:CFG.sombra,forcaSombra=nivel?smooth(.04,.2,Math.abs(el+.0))*(el>-.05?.92:.6)*(1-ch):0;let luzVP=ID;
 const meioH=Math.atan(tg*asp)+.1,vis=fundo?[]:listaChunks(P.x,P.z,CFG.dist,sy,cy,meioH,pit),vox=voxelsVisiveis(P.x,P.z,fundo?70:CFG.dist);
 gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D_ARRAY,atlas);
 if(forcaSombra>0){const tam=[0,1024,2048,3072][nivel],R2=[0,38,52,66][nivel],s=criarSombra(tam);const alvo=[P.x,P.y-1.5,P.z],base=olharPara(luzDir.map(v=>v*120),[0,0,0]);
  // alinha ao tamanho do texel para a sombra não tremer
  const px=2*R2/tam,lx=base[0]*alvo[0]+base[4]*alvo[1]+base[8]*alvo[2],ly=base[1]*alvo[0]+base[5]*alvo[1]+base[9]*alvo[2],lz=base[2]*alvo[0]+base[6]*alvo[1]+base[10]*alvo[2];
  luzVP=cadeia(orto(R2,1,240),T(-Math.round(lx/px)*px,-Math.round(ly/px)*px,-lz),base);
  gl.activeTexture(gl.TEXTURE1);gl.bindTexture(gl.TEXTURE_2D,null);gl.activeTexture(gl.TEXTURE0);
  gl.bindFramebuffer(gl.FRAMEBUFFER,s.f);gl.viewport(0,0,tam,tam);gl.enable(gl.DEPTH_TEST);gl.depthMask(true);gl.clear(gl.DEPTH_BUFFER_BIT);gl.enable(gl.POLYGON_OFFSET_FILL);gl.polygonOffset(1.5,2);
  gl.useProgram(sombraCena.p);uAtual=sombraCena.u;passoSombra=true;gl.uniformMatrix4fv(uAtual.uVP,false,luzVP);gl.uniform1f(uAtual.uTime,tempo);gl.uniform3fv(uAtual.uEye,olho);gl.uniform1i(uAtual.uMasc,5);
  opacos(vis.filter(v=>v[1]<R2+40),P.x,P.z,R2+10,true);
  gl.useProgram(linhas.p);gl.uniformMatrix4fv(linhas.u.uVP,false,luzVP);for(const t of M.tmalhas.values())if(t.malha&&Math.abs(t.cx*16+8-P.x)<R2+16&&Math.abs(t.cz*16+8-P.z)<R2+16){gl.bindVertexArray(t.malha.vao);gl.drawArrays(gl.TRIANGLES,0,t.malha.n)}
  gl.useProgram(sombraVox.p);gl.uniformMatrix4fv(sombraVox.u.uVP,false,luzVP);gl.uniform1i(sombraVox.u.uAtlas,0);for(const v of vox)if(v.malha&&Math.abs(v.cx*16+8-P.x)<R2+16&&Math.abs(v.cz*16+8-P.z)<R2+16){gl.bindVertexArray(v.malha.vao);gl.drawArrays(gl.TRIANGLES,0,v.malha.n)}
  gl.disable(gl.POLYGON_OFFSET_FILL);passoSombra=false}
 gl.activeTexture(gl.TEXTURE1);gl.bindTexture(gl.TEXTURE_2D,mapaSombra.t);gl.activeTexture(gl.TEXTURE0);
 const efeitos=CFG.efeitos&&criarAlvos(w,h).ok;gl.bindFramebuffer(gl.FRAMEBUFFER,efeitos?alvos.ms:null);gl.viewport(0,0,w,h);
 gl.disable(gl.DEPTH_TEST);gl.disable(gl.BLEND);gl.depthMask(true);gl.clearColor(fog[0],fog[1],fog[2],1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
 if(!fundo&&!sub&&!lava){gl.useProgram(ceu.p);const c=ceu.u;gl.uniform3fv(c.uF,F);gl.uniform3fv(c.uR,R.map(v=>v*tg*asp));gl.uniform3fv(c.uU,U.map(v=>v*tg));gl.uniform3fv(c.uSun,S);gl.uniform3fv(c.uTopo,topo);gl.uniform3fv(c.uFog,fog);
  gl.uniform3fv(c.uGlow,mix([1,.85,.55],[1.1,.45,.2],crep).map(v=>v*(1-noite*.9)));gl.uniform1f(c.uNoite,noite);gl.uniform1f(c.uTime,tempo);gl.uniform1f(c.uNuvens,ch);gl.uniform1f(c.uRaio,raioForca);gl.bindVertexArray(vazioVao);gl.drawArrays(gl.TRIANGLES,0,3)}
 gl.enable(gl.DEPTH_TEST);const amb_={olho,luzDir,corSol,amb,chaoAmb,fog,dens,noite:nt,luzes,tocha,sombra:forcaSombra,luzVP};
 gl.useProgram(cena.p);uAtual=cena.u;uniformesLuz(uAtual,amb_);gl.uniformMatrix4fv(uAtual.uVP,false,VP);gl.uniform1f(uAtual.uAlfa,1);gl.uniform1f(uAtual.uFade,0);gl.uniform1i(uAtual.uMasc,5);
 opacos(vis,P.x,P.z,CFG.dist,false);
 gl.useProgram(terra.p);uniformesLuz(terra.u,amb_);gl.uniformMatrix4fv(terra.u.uVP,false,VP);gl.uniform1i(terra.u.uAtlas,0);for(const t of M.tmalhas.values())if(t.malha){gl.bindVertexArray(t.malha.vao);gl.drawArrays(gl.TRIANGLES,0,t.malha.n)}
 gl.useProgram(voxel.p);let v=voxel.u;uniformesLuz(v,amb_);gl.uniformMatrix4fv(v.uVP,false,VP);gl.uniform1i(v.uAtlas,0);gl.uniform1f(v.uAgua,0);
 for(const c of vox)if(c.malha){gl.bindVertexArray(c.malha.vao);gl.drawArrays(gl.TRIANGLES,0,c.malha.n)}
 gl.enable(gl.BLEND);gl.blendFuncSeparate(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA,gl.ZERO,gl.ONE);gl.depthMask(false);
 if(!fundo){gl.useProgram(mar.p);uniformesLuz(mar.u,amb_);gl.uniformMatrix4fv(mar.u.uVP,false,VP);gl.uniform3fv(mar.u.uTopo,topo);for(const[c]of vis)if(c.agua){gl.bindVertexArray(c.agua.vao);gl.drawArrays(gl.TRIANGLES,0,c.agua.n)}gl.useProgram(voxel.p)}
 gl.useProgram(voxel.p);gl.uniform1f(v.uAgua,1);for(const c of vox)if(c.agua){gl.bindVertexArray(c.agua.vao);gl.drawArrays(gl.TRIANGLES,0,c.agua.n)}gl.uniform1f(v.uAgua,0);
 // marcações de mira, pré-visualização e linha de pesca
 if(estado==='jogando'){const prev=previsao();if(prev){gl.useProgram(cena.p);uAtual=cena.u;gl.uniform1f(uAtual.uAlfa,.55);gl.uniform4f(uAtual.uTint,...(prev.erro?[1,.2,.15]:[.3,.9,1]),.6);gl.vertexAttrib4f(4,0,0,0,1);gl.vertexAttrib2f(5,0,1);desenharMalha(modelos[prev.tipo],mul(T(prev.x,prev.y+.02,prev.z),RY(prev.a)));if(prev.tipo==='porta')desenharMalha(modelos.batente,mul(T(prev.x,prev.y,prev.z),RY(prev.a)));gl.uniform1f(uAtual.uAlfa,1);gl.uniform4f(uAtual.uTint,0,0,0,0)}
  const bl=planta?null:previaBloco();if(bl){const l=[];for(const q of celulasModo(bl))l.push(...cubo(q.x,q.y,q.z));desenharLinhas(VP,l,bl.erro?[1,.25,.2,.9]:[.5,.95,1,.8])}
  if(planta){const o=lugarPlanta();if(o){const l=[];for(const[a,b,c]of o.l){const[i,j]=giraXZ(a,c,o.r);l.push(...cubo(o.x+i,o.y+b,o.z+j,1,-.06))}desenharLinhas(VP,l,o.erro?[1,.35,.25,.55]:[.45,1,.8,.55])}}
  const a=alvoAtaque();if(a&&a.tipo==='terra'){const c=centroCava(a.o),l=[],r=(naMao()?.raio||CFG.escava)*.65,N=18,p=P.quebrando?.p||0;for(let e=0;e<3;e++)for(let i=0;i<N;i++)for(const k of[i,i+1]){const g=k/N*TAU,v=c.slice();v[(e+1)%3]+=Math.cos(g)*r*(1-p*.5);v[(e+2)%3]+=Math.sin(g)*r*(1-p*.5);l.push(...v)}desenharLinhas(VP,l,[.05,.05,.05,.45])}
  if(a&&a.tipo==='vox'){desenharLinhas(VP,cubo(a.o.x,a.o.y,a.o.z),[.02,.02,.02,.85]);const qb=P.quebrando;if(qb){const l=[];let sm=qb.x*7+qb.y*13+qb.z*3;const r=()=>{sm=(sm*9301+49297)%233280;return Math.abs(sm)/233280};
     for(let i=0;i<qb.p*22;i++){const eixo=i%3,lado=r()<.5?-.006:1.006,p0=[r(),r(),r()],p1=p0.map(n=>clamp(n+(r()-.5)*.6,0,1));p0[eixo]=p1[eixo]=lado;l.push(qb.x+p0[0],qb.y+p0[1],qb.z+p0[2],qb.x+p1[0],qb.y+p1[1],qb.z+p1[2])}desenharLinhas(VP,l,[0,0,0,.9])}}
  if(P.pesca){const[fx,fz]=frente(),m=[P.x+fx*.8-fz*.35,P.y-.1,P.z+fz*.8+fx*.35],f=P.pesca,l=[];for(let i=0;i<10;i++)for(const k of[i/10,(i+1)/10])l.push(lerp(m[0],f.x,k),lerp(m[1],f.y+.2,k)-Math.sin(k*Math.PI)*.4,lerp(m[2],f.z,k));desenharLinhas(VP,l,[.92,.95,1,.7])}}
 np=0;if(chuvaForca>.05&&kc<.3&&!sub)chuva(VP,olho,nt);
 particulas();gl.useProgram(pontos.p);gl.blendFuncSeparate(gl.ONE,gl.ONE,gl.ZERO,gl.ONE);gl.uniformMatrix4fv(pontos.u.uVP,false,VP);gl.uniform1f(pontos.u.uAlt,h/(2*tg));
 gl.bindVertexArray(pVao);gl.bindBuffer(gl.ARRAY_BUFFER,pBuf);gl.bufferSubData(gl.ARRAY_BUFFER,0,pDados,0,np*8);gl.drawArrays(gl.POINTS,0,np);gl.depthMask(true);gl.disable(gl.BLEND);
 if(estado==='jogando'&&!modo&&!P.zoom&&CFG.mostrarMao)desenharMao(proj,asp,amb_);
 if(efeitos)posProcesso(w,h,sub?1:0)}
// item na mão, desenhado no espaço da câmera
function desenharMao(proj,asp,a){gl.clear(gl.DEPTH_BUFFER_BIT);gl.useProgram(cena.p);uAtual=cena.u;uniformesLuz(uAtual,{...a,olho:[0,0,0],luzDir:[.4,.8,.45],dens:0,sombra:0,luzes:new Float32Array(48),tocha:a.tocha>.2?.55:.1*a.noite});gl.uniformMatrix4fv(uAtual.uVP,false,proj);gl.vertexAttrib4f(4,0,0,0,1);gl.vertexAttrib2f(5,0,1);
 const it=naMao(),g=P.golpe,bal=CFG.balanco?Math.sin(P.passo*TAU)*.015:0,x=Math.min(.5,.42*asp),s=Math.sin(g*Math.PI),off=P.armadura[4]?.[0];
 if(off&&off!==it?.id){const m=modeloItem(off);desenharMalha(m.m,off==='escudo'?cadeia(T(-x-.12,-.55+bal,-.95),RY(.35),E(.62)):cadeia(T(-x,-.45+bal,-.85),RZ(-.2),RX(-.35),E(.6)))}
 if(!it){desenharMalha(mBraco,cadeia(T(x-s*.2,-.5+bal+s*.1,-.75-s*.25),RZ(.35),RX(-1.15-s*.4)));return}
 const m=modeloItem(it.id);let t;
 if(it.distancia){const puxa=clamp(P.recarga/it.cad,0,1);t=cadeia(T(x*.55,-.25+bal,-.85+puxa*.08),RY(.25),it.id==='besta'?RX(-1.3):RZ(-.25),E(.62))}
 else if(m.cubo)t=cadeia(T(x+.02-s*.2,-.36+bal+s*.1,-.85-s*.15),RY(.65),RX(.12-s*.5),E(.24));
 else if(it.cat==='bloco')t=cadeia(T(x,-.45+bal,-1),RY(.6),E(m.esc*1.1));
 else if(it.cat==='arma'||it.cat==='ferramenta')t=cadeia(T(x-s*.28,-.42+bal+s*.08,-.78-s*.18),RY(-.25),RZ(.18+s*.5),RX(-.35-s*1.25),E(it.ic==='lanca'||it.ic==='vara'?.55:.68));
 else{desenharMalha(mBraco,cadeia(T(x+.06-s*.2,-.55+bal+s*.1,-.78-s*.2),RZ(.35),RX(-1.15-s*.4)));t=cadeia(T(x-.05-s*.2,-.34+bal+s*.12,-.9-s*.2),RY(.7),RX(.25),E(.36))}
 desenharMalha(m.m,t)}
// pré-visualização do personagem nos menus: desenha num canto e copia para o canvas do menu
function desenharPrevia(){const alvo=document.querySelector('canvas.previa');if(!alvo||!alvo.offsetParent||!corpoJogador)return;const pw=Math.min(canvas.width,300),ph=Math.min(canvas.height,Math.round(pw*alvo.height/alvo.width));if(pw<10||ph<10)return;
 gl.bindFramebuffer(gl.FRAMEBUFFER,null);gl.viewport(0,0,pw,ph);gl.enable(gl.SCISSOR_TEST);gl.scissor(0,0,pw,ph);gl.clearColor(0,0,0,0);gl.depthMask(true);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.enable(gl.DEPTH_TEST);gl.disable(gl.BLEND);
 gl.activeTexture(gl.TEXTURE1);gl.bindTexture(gl.TEXTURE_2D,mapaSombra.t);gl.activeTexture(gl.TEXTURE0);gl.useProgram(cena.p);uAtual=cena.u;const perto=alvo.dataset.zoom;
 uniformesLuz(uAtual,{olho:[0,1.2,4],luzDir:[.45,.65,.62],corSol:[.75,.7,.62],amb:[.6,.64,.74],chaoAmb:[.34,.3,.3],fog:[0,0,0],dens:0,noite:0,luzes:new Float32Array(48),tocha:0,sombra:0,luzVP:ID});
 const asp=pw/ph,fov=perto?.3:.62;gl.uniformMatrix4fv(uAtual.uVP,false,cadeia(persp(fov,asp,.1,20),T(0,perto?-1.62:-1.08,-4)));gl.uniform1f(uAtual.uAlfa,1);gl.uniform1f(uAtual.uFade,0);gl.vertexAttrib4f(4,0,0,0,1);gl.vertexAttrib2f(5,0,1);
 desenharSer({x:0,y:0,z:0,h:previaAng??(perto?Math.sin(tempo*.7)*.5:tempo*.7),v:1.4,fase:tempo*3,pitch:0,corpo:corpoJogador,def:{},segura:comecou?naMao()?.id:null,escudo:comecou?P.armadura[4]?.[0]:null,golpe:0},true);
 gl.disable(gl.SCISSOR_TEST);const c=alvo.getContext('2d');c.clearRect(0,0,alvo.width,alvo.height);c.drawImage(canvas,0,canvas.height-ph,pw,ph,0,0,alvo.width,alvo.height)}
let previaAng=null;

// ---------- clima ----------
let climaT=120,climaAlvo=0;
function atualizarClima(dt){if((climaT-=dt)<0){if(climaAlvo>0){climaAlvo=0;climaT=150+Math.random()*260}else{climaAlvo=Math.random()<.45?(Math.random()<.35?1:.6):0;climaT=60+Math.random()*90}}
 if(!CFG.clima||!CFG.chuvaFreq)climaAlvo=0;else if(CFG.chuvaFreq!==1&&climaAlvo===0)climaT-=dt*(CFG.chuvaFreq-1);const alvo=!CAV&&bioma(P.x,P.z)==='deserto'?0:climaAlvo;chuvaForca+=clamp(alvo-chuvaForca,-dt*.12,dt*.12);
 raioForca=Math.max(0,raioForca-dt*2.2);if(chuvaForca>.85&&!CAV&&Math.random()<dt*.07){raioForca=.75;setTimeout(()=>som('trovao',.8),300+Math.random()*1400)}}
const gotas=[];for(let i=0;i<700;i++)gotas.push([Math.random()*40,Math.random()*24,Math.random()*40,.8+Math.random()*.4]);
function chuva(VP,o,nt){const neve=bioma(P.x,P.z)==='neve',n=Math.floor(gotas.length*chuvaForca*(CFG.part?1:.4)),l=[],mod=(v,m)=>((v%m)+m)%m;
 for(let i=0;i<n;i++){const g=gotas[i],x=o[0]+mod(g[0]-o[0],40)-20,z=o[2]+mod(g[2]-o[2],40)-20,y=o[1]+mod(g[1]-tempo*(neve?2:19)*g[3]-o[1],24)-8;if(y<altura(x,z))continue;
  if(neve)ponto(x+Math.sin(tempo+i)*.5,y,z+Math.cos(tempo*.8+i*2)*.5,.09,1,1,1,.8*(1-nt*.5));else l.push(x,y,z,x+.06,y+.65,z+.02)}
 const k=1-nt*.7;desenharLinhas(VP,l,[.7*k,.8*k,.95*k,.38])}
// ---------- partículas ----------
const vaga=[];for(let i=0;i<150;i++)vaga.push([Math.random()*60,.4+Math.random()*3,Math.random()*60,Math.random()*TAU]);
function particulas(){const t=tempo,fogo=(x,y,z,s,n)=>{for(let i=0;i<n;i++){const f=(t*(.7+(i%7)*.09)+i*.137)%1,a=i*2.4,r=(1-f)*.45*s;ponto(x+Math.cos(a)*r+Math.sin(t*3+i)*.08,y+.15+f*1.7*s,z+Math.sin(a)*r,(1-f)*.7*s,1,.55-f*.4,.1,.5*(1-f*.5))}};
 if(!CAV){for(const e of M.estacoes)if(e.tipo==='fogo'&&dist2(e.x,e.z,P.x,P.z)<70)fogo(e.x,e.obra?e.obra.y:altura(e.x,e.z),e.z,1,CFG.part?45:18);
  for(const e of M.entradas)if(dist2(e.x,e.z,P.x,P.z)<60)for(let i=0;i<14;i++){const f=(t*.25+i/14)%1;ponto(e.x+Math.sin(i*2.4)*1.1,e.y+f*2.2,e.z+Math.cos(i*3.1)*1.1,.14,.4,.85,1,.8*(1-f))}}
 for(const l of M.luzes){if(!!l.cav!==!!CAV)continue;const d=dist2(l.x,l.z,P.x,P.z);if(d<90&&!(l.obra?.tipo==='tocha'&&d>40))ponto(l.x,l.y,l.z,l.obra?.tipo==='tocha'?.8:1.6,1,.55,.15,CAV?.16:.2*noite+.04);if(l.obra&&l.obra.tipo==='farol'){for(let i=0;i<60;i++){const f=(t*.08+i/60)%1;ponto(l.x+Math.sin(i*2.4+t)*.5,l.y+f*70,l.z+Math.cos(i*2.4+t)*.5,3.5,.45,.9,1,.8*(1-f))}}}
 if(CAV){const s=CAV.saida;for(let i=0;i<30;i++){const f=(t*.2+i/30)%1;ponto(s.x+Math.sin(i*2.4+t)*.7,s.y+f*3,s.z+Math.cos(i*2.4+t)*.7,.35,.75,.95,1,.9*(1-f))}
  for(const v of voxelsVisiveis(P.x,P.z,30))for(const l of v.luzes)if(l.i<1.5)ponto(l.x,l.y-.2,l.z,.5,.9,.6,.4,.08)}
 if(naMao()?.id==='tocha'&&estado==='jogando'&&!CFG.camera){const[fx,fz]=frente();fogo(P.x+fx*.9-fz*.38,P.y-.5,P.z+fz*.9+fx*.38,.16,6)}
 for(const b of M.baus)if(!b.aberto&&b.rar&&!!b.cav===!!CAV&&dist2(b.x,b.z,P.x,P.z)<70){const cor=b.rar>1?[.75,.45,1]:[1,.82,.3];for(let i=0;i<5;i++){const f=(t*.4+i/5)%1;ponto(b.x+Math.sin(i*2.4+t)*.6,b.y+.3+f*(b.rar>1?5:1.6),b.z+Math.cos(i*2.4+t)*.6,.25,...cor,.9*(1-f))}}
 for(const g of M.chao)if(!g.pego&&!!g.cav===!!CAV&&dist2(g.x,g.z,P.x,P.z)<60){const raro=['arma','ferramenta','armadura'].includes(ITENS[g.item].cat);ponto(g.x,g.y+.5,g.z,raro?1.5:.8,raro?1:.8,raro?.8:.9,raro?.3:1,.24+Math.sin(t*3+g.x)*.08)}
 for(const e of seres)if(e.manso&&e.tipo!=='barco'&&e.cav===!!CAV&&dist2(e.x,e.z,P.x,P.z)<40)ponto(e.x,e.y+e.def.alt+.35,e.z,.16,.35,1,.6,.9);
 if(P.marca&&!CAV&&dist2(P.marca.x,P.marca.z,P.x,P.z)<120){const y=altura(P.marca.x,P.marca.z);for(let i=0;i<30;i++){const f=(t*.15+i/30)%1;ponto(P.marca.x+Math.sin(i*2.4+t)*.4,y+f*14,P.marca.z+Math.cos(i*2.4+t)*.4,1,1,.75,.2,.8*(1-f))}}
 for(const f of faiscas)ponto(f.x,f.y,f.z,f.s,f.cor[0],f.cor[1],f.cor[2],Math.min(1,f.vida*2)*.8);
 if(noite>.15&&CFG.part&&profundidade(P.x,P.y,P.z)<3&&chuvaForca<.2)for(const v of vaga){const x=P.x+((v[0]-P.x)%60+90)%60-30+Math.sin(t*.7+v[3])*1.5,z=P.z+((v[2]-P.z)%60+90)%60-30+Math.cos(t*.5+v[3]*2)*1.5;ponto(x,Math.max(altura(x,z),0)+v[1]+Math.sin(t+v[3])*.4,z,.18,.75,1,.35,noite*Math.max(0,Math.sin(t*2.3+v[3]*5)))}}
