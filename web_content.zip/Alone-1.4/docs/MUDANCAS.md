# Mudanças da 1.3 para a 1.4
O jogo não foi refeito. Gráficos, controles e conteúdo foram mantidos.

## Novo
- `src/rede.js`: telas (criar, entrar, sala de espera), conexão, reconexão, sincronização e interpolação.
- Servidor WebSocket em Java, sem bibliotecas externas, dentro do app.
- Projeto Android (WebView, ponte, serviço em primeiro plano, fluxo de compilação no GitHub).

## Pequenas alterações no jogo original
`b.js` (objeto REDE), `g.js` (criaturas miram o jogador mais próximo; flechas), `w2.js` (Host carrega o
entorno dos convidados), `pj2.js` (coleta de itens), `ct.js` (a partida não pausa em menus), `r2.js` e
`pn.js` (outros jogadores, nomes e minimapa), `ui.js` (botão Multiplayer e versão), `a.html` (estilo).

## Quem decide o quê
- **Servidor:** entrada (máx. 4), identificação, limites de velocidade e alcance, frequência de mensagens,
  quem pega cada item, quem usa cada baú, encerramento da sala.
- **Jogo do Host:** criaturas, dano delas, relógio, clima e água.
- **Cada aparelho:** o próprio movimento e inventário, validados só em parte pelo servidor.
A proteção serve contra dados inválidos e erros; **não é um sistema contra trapaças**.
