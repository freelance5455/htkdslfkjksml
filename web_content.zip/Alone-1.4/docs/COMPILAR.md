# Gerar o APK

## A) Pelo GitHub (sem instalar nada)
1. Crie um repositório no GitHub.
2. Envie o **conteúdo** da pasta `android/` para a raiz dele, incluindo a pasta oculta `.github`.
   Pelo site, se a pasta oculta não subir, crie o arquivo `.github/workflows/apk.yml` e cole o conteúdo.
3. Abra a aba **Actions** > **Gerar APK** > **Run workflow**.
4. Ao terminar, baixe o artefato **Alone-APK**: `Alone.apk` (release) e `Alone-debug.apk`.

## B) Android Studio
1. Instale o Android Studio recente e abra a pasta `android/`.
2. Aceite a instalação do SDK 35 e aguarde o Gradle sincronizar (precisa de internet na primeira vez).
3. **Build > Build APK(s)**. Resultado em `app/build/outputs/apk/debug/`.

## C) Linha de comando (JDK 17+ e Android SDK)
    cd android
    ./gradlew assembleDebug assembleRelease      (Windows: gradlew.bat ...)

## Assinatura
Sem configuração, o release é assinado com a chave de depuração: instala normalmente, mas não serve para a
Play Store, e um APK gerado em outra máquina pode exigir desinstalar o anterior (isso apaga os mundos salvos).
Para usar sua chave:

    keytool -genkeypair -keystore alone.jks -alias alone -keyalg RSA -keysize 2048 -validity 10000

e crie `android/keystore.properties` com `storeFile=alone.jks`, `storePassword=...`, `keyAlias=alone`,
`keyPassword=...`. Guarde esses arquivos e não os publique.

## Versões futuras
1. Altere os arquivos em `src/` e rode `sh montar.sh` (precisa de Node): ele atualiza o HTML do app.
2. Em `android/app/build.gradle` aumente `versionCode` e `versionName`.
3. Se mudar o protocolo de rede, altere a versão em `src/rede.js` (`VERSAO_REDE`) e em `Sala.java` (`VERSAO`).
4. Compile de novo.
