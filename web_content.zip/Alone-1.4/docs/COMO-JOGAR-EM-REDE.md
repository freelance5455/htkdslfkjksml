# Jogar em rede (2 a 4 jogadores, sem internet)
Todos os aparelhos precisam estar na mesma rede Wi-Fi (o roteador não precisa ter internet).
O roteador pessoal (hotspot) de um dos celulares também deve servir.

## Criar sala (Host)
1. No app Android: **Multiplayer > Criar sala**.
2. Escolha um mundo novo ou salvo e toque em **Criar sala**.
3. A sala de espera mostra o **IP** e a **porta** (8765, ou a próxima livre). Passe aos amigos.
4. Com pelo menos 2 jogadores, toque em **Iniciar partida**. Outros podem entrar depois.
5. Mantenha o app do Host aberto na tela durante a partida.

## Entrar
- App: **Multiplayer > Entrar em uma sala**, digite IP e porta, **Conectar**.
- Navegador (PC ou celular): abra `http://IP:PORTA` do Host e faça o mesmo.

## Sair
Convidado sai: os outros continuam. Host sai: a partida acaba e todos voltam à tela inicial.
Se a conexão de um convidado cair, o jogo tenta reconectar sozinho por cerca de 20 s.

## Hospedar por um computador (opcional)
    cd servidor-pc
    java -jar alone-servidor.jar Alone.html 8765
Abra no próprio computador o endereço `http://localhost:8765/#chave=...` exibido e crie a sala.
Os convidados usam `http://IP-DO-COMPUTADOR:8765`. A aba do Host precisa ficar visível.

## Se não conectar
- Confira IP, porta e se é o mesmo Wi-Fi.
- Redes de convidados, de escola ou com "isolamento de clientes" bloqueiam aparelhos entre si.
- No computador, libere o Java no firewall. Desligue VPN.
- O arquivo do jogo não pode ser aberto por um site `https://`.
