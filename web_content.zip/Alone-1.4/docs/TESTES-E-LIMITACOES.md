# O que foi testado (28/11/2026)
Em Chromium automatizado, com cada jogador em um navegador separado, **todos na mesma máquina**
(endereço local), usando o servidor Java deste pacote (em versão de computador). Sem acesso à internet.

| Conjunto | Resultado |
|---|---|
| `t1.js`: Host + 3 convidados entram, 5º recusado, 4 iniciam e se enxergam | passou |
| `t2.js`: 39 verificações | 39 passaram |
| `t3.js`: ações extras e queda do Host | 16 passaram; o trecho final tinha um erro no próprio teste e foi refeito em `t4.js` |
| `t4.js`: jogo solo e celular emulado | 7 passaram |

Cobertura: mínimo 2 e máximo 4; movimento simultâneo (3 jogadores), item na mão e direção; relógio;
blocos, escavação, explosão, árvores, itens disputados, baús, construções, porta, plantação; criaturas,
combate corpo a corpo e flecha, monstro ferindo convidado, invocação; morte e retorno; posição impossível e
mensagens inválidas; queda e reconexão; saída de convidado; entrada tardia; saída e queda do Host; sala
fechada; endereço errado; Host pela ponte do app **simulada**; entrada pela página `file://`.

# NÃO testado
- **Compilação do APK e qualquer execução em Android** (WebView, serviço, permissões, botão voltar real,
  app em segundo plano). Os fontes Android não foram verificados contra o SDK.
- **Aparelhos físicos diferentes em um Wi-Fi real**, firewall, hotspot, descoberta do IP (o ambiente de teste
  não tinha interface de rede local), latência e perda de pacotes.
- Desempenho e consumo em celulares; partidas longas; vazamentos de memória.
- Em rede: barco, animação visual de cada ação, baú de suprimentos, chefes, cavernas, água escorrendo.

# Limitações conhecidas
- Convidados não podem montar, domar, tosar ou alimentar animais, nem passar a noite dormindo.
- Só o Host salva o mundo. O convidado guarda apenas o próprio inventário no seu aparelho.
- Progresso de missões do convidado não é salvo entre partidas.
- Se o Host minimizar o app ou esconder a aba, o Android/navegador pode desacelerar a partida: mantenha-o aberto.
- Não há migração de Host. A conexão não é criptografada; use redes de confiança.
- As fontes visuais vêm do Google Fonts quando há internet; sem internet usa-se a fonte do aparelho.
