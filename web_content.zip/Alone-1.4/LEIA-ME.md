# Alone 1.4 — multiplayer em rede local

## Importante: o APK NÃO está neste pacote
O ambiente em que a versão foi feita não tem o Android SDK. O projeto Android está completo, mas
**nunca foi compilado nem executado em um aparelho**. Para gerar o APK veja `docs/COMPILAR.md`
(há um caminho pelo GitHub, sem instalar nada no computador).

## O que há aqui
| Pasta | Conteúdo |
|---|---|
| `entrega/Alone.html` | jogo pronto para navegador |
| `src/`, `montar.sh` | código-fonte do jogo (`src/rede.js` é o multiplayer) |
| `android/` | projeto Android Studio; o servidor LAN fica em `app/src/main/java/br/alone/servidor/` |
| `servidor-pc/` | opcional: hospedar uma sala por um computador com Java |
| `original-1.3/` | cópia intacta da versão anterior |
| `testes/` | testes automatizados usados |
| `docs/` | compilar, jogar em rede, mudanças, testes e limitações |
