#!/bin/sh
set -e
cd "$(dirname "$0")"
J="src/b.js src/c.js src/c2.js src/c3.js src/d.js src/tx.js src/vx.js src/tr.js src/w.js src/w2.js src/g.js src/an.js src/sk.js src/pj.js src/pj2.js src/cs.js src/h.js src/j.js src/r.js src/r2.js src/ui.js src/pn.js src/ct.js src/rede.js"
cat $J > todo.js
node --check todo.js
{ cat src/a.html; echo '<script>'; cat todo.js; echo '</script>'; } > alone.html
mkdir -p entrega
{ printf '<!doctype html>\n<html lang="pt-BR">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover,user-scalable=no">\n<style>*{box-sizing:border-box}body{margin:0}[hidden]{display:none!important}</style>\n</head>\n<body>\n'; cat alone.html; printf '\n</body>\n</html>\n'; } > entrega/Alone.html
wc -c alone.html entrega/Alone.html
# o aplicativo Android e o servidor de PC usam o mesmo HTML
cp entrega/Alone.html android/app/src/main/assets/index.html
mkdir -p servidor-pc && cp entrega/Alone.html servidor-pc/Alone.html
