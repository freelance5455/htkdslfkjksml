مغامرة بيكسل — مشروع Android لتحويل اللعبة إلى APK

هذا مشروع Android Studio/AndroidIDE يغلّف ملف اللعبة index.html داخل تطبيق أندرويد بملء الشاشة.
لم يتم تضمين APK جاهز؛ يجب بناء المشروع باستخدام AndroidIDE أو Android Studio.

البناء على الهاتف:
1) نزّل AndroidIDE من مصدره الرسمي الموثوق وثبّته.
2) فك ضغط PixelAdventureAndroid.zip داخل مجلد يسهل الوصول إليه.
3) افتح مجلد PixelAdventureAndroid كمشروع في AndroidIDE، وانتظر مزامنة Gradle.
4) إذا طلب تثبيت Android SDK/Build Tools، وافق من داخل AndroidIDE.
5) اختر Build > Assemble Debug (قد تختلف أسماء القوائم حسب الإصدار).
6) بعد نجاح البناء، يكون APK عادةً في app/build/outputs/apk/debug/app-debug.apk.

إذا فشل البناء، أرسل صورة الخطأ كاملة. يحتاج البناء إلى اتصال إنترنت لتنزيل أدوات Gradle/Android عند أول مرة.
