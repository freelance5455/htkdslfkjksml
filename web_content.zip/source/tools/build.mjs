// Builds the single-file web app: dist/index.html (+ README, docs) and the zip.
import fs from 'node:fs';
import path from 'node:path';
const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const read = f => fs.readFileSync(path.join(root, f), 'utf8');
const order = ['jalali.js', 'core.js', 'selftest.js', 'i18n.js', 'ui-core.js', 'view-home.js', 'view-books.js', 'view-docs.js', 'view-reports.js', 'view-settings.js', 'view-eval.js', 'main.js'];
const css = read('src/styles.css');
// "</script" inside inline JS would end the block early — escape it defensively.
const js = order.map(f => `/* ===== ${f} ===== */\n` + read('src/' + f).replace(/<\/script/gi, '<\\/script')).join('\n');
const html = `<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#0e1117">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data: blob:; font-src data:; connect-src 'none'; base-uri 'none'; form-action 'none'">
<meta name="description" content="AccoNova — حسابداری دوطرفه، فارسی/English، تقویم شمسی و میلادی · Double-entry accounting, Persian/English, Jalali and Gregorian calendars">
<title>AccoNova</title>
<style>
${css}
</style>
</head>
<body>
<div id="app"></div>
<div id="printRoot" aria-hidden="true"></div>
<noscript><p style="padding:20px;text-align:center">JavaScript is required · برای اجرای برنامه جاوااسکریپت لازم است.</p></noscript>
<script>
${js}
</script>
</body>
</html>
`;
const out = path.join(root, 'dist');
fs.mkdirSync(out, { recursive: true });
fs.writeFileSync(path.join(out, 'index.html'), html);
console.log('dist/index.html', (html.length / 1024).toFixed(1) + ' KB');
