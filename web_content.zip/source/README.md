Fluxo — fonte HTML do aplicativo financeiro.
As funções de exportar, baixar, compartilhar e importar/restaurar arquivos financeiros foram removidas.
