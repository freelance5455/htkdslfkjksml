
(function(){var K='colorlab_app_login_v1',o=document.getElementById('lgn'),u=document.getElementById('lgu'),p=document.getElementById('lgp'),e=document.getElementById('lge'),h=document.getElementById('lgh'),b=document.getElementById('lgb'),c=null;
try{c=JSON.parse(localStorage.getItem(K)||'null')}catch(x){}
if(sessionStorage&&0){}
function ok(){o.style.display='none';document.body.style.overflow=''}
document.body.style.overflow='hidden';
if(!c){h.textContent='First time: choose your username and password';b.textContent='Save & Login'}
function go(){var a=u.value.trim(),d=p.value;if(!a||!d){e.textContent='Enter username and password';return}
if(!c){try{localStorage.setItem(K,JSON.stringify({u:a,p:d}))}catch(x){}c={u:a,p:d};ok();return}
if(a===c.u&&d===c.p){ok()}else{e.textContent='Wrong username or password'}}
b.onclick=go;p.addEventListener('keydown',function(ev){if(ev.key==='Enter')go()});u.addEventListener('keydown',function(ev){if(ev.key==='Enter')p.focus()});
})();
