
(function(){
var P=/^colorlab_/,C={},idb=null,pend={},tm=null,ran=false,LS=null,pr=Storage.prototype,oG=pr.getItem,oS=pr.setItem,oR=pr.removeItem;
try{LS=window.localStorage}catch(e){}
window.CLSTORE={full:false};
function run(){if(ran)return;ran=true;var t=document.getElementById('clt');if(t)t.style.display='none';var s=document.createElement('script');s.text=document.getElementById('mainjs').textContent;try{document.body.appendChild(s)}catch(e){window.__clerr(e&&e.message)}var qb=window.__qb;if(qb){window.__qb=null;try{openBook(qb)}catch(e){window.__clerr(e&&e.message)}}}
function flush(){tm=null;if(!idb)return;var ks=Object.keys(pend);if(!ks.length)return;try{var tx=idb.transaction('kv','readwrite'),st=tx.objectStore('kv');ks.forEach(function(k){if(pend[k]===null)st.delete(k);else st.put(pend[k],k)});pend={};tx.onabort=tx.onerror=function(){CLSTORE.full=true;var e=document.getElementById('clst');if(e)e.textContent='Storage is full or blocked. Export a backup now.'}}catch(e){CLSTORE.full=true}}
function q(k,v){pend[k]=v;if(!tm)tm=setTimeout(flush,400)}
pr.getItem=function(k){if(idb&&P.test(k))return k in C?C[k]:null;return oG.call(this,k)};
pr.setItem=function(k,v){if(idb&&P.test(k)){C[k]=String(v);q(k,C[k]);return}return oS.call(this,k,v)};
pr.removeItem=function(k){if(idb&&P.test(k)){delete C[k];q(k,null);return}return oR.call(this,k)};
addEventListener('pagehide',flush);document.addEventListener('visibilitychange',function(){if(document.hidden)flush()});
try{navigator.storage&&navigator.storage.persist&&navigator.storage.persist()}catch(e){}
try{var rq=indexedDB.open('colorlab_db',1);
rq.onupgradeneeded=function(){rq.result.createObjectStore('kv')};
rq.onerror=run;
rq.onsuccess=function(){var d=rq.result,tx=d.transaction('kv','readonly'),st=tx.objectStore('kv'),kr=st.getAllKeys(),vr=st.getAll();
tx.oncomplete=function(){kr.result.forEach(function(k,i){C[k]=vr.result[i]});
try{if(LS)for(var i=0;i<LS.length;i++){var k=LS.key(i);if(P.test(k)&&(!(k in C)||ran)){C[k]=oG.call(LS,k);pend[k]=C[k]}}}catch(e){}
idb=d;flush();run()};tx.onerror=run}}catch(e){run()}
setTimeout(run,2000);
var TX=function(m,c){var e=document.getElementById('clst');if(e){e.textContent=m;e.style.color=c||''}};
window.clParts=function(){flush();var o={};Object.keys(C).forEach(function(k){o[k]=C[k]});
if(!idb&&LS){for(var i=0;i<LS.length;i++){var k=LS.key(i);if(P.test(k))o[k]=oG.call(LS,k)}}
['cpairs','cpseed_counter_custom_v2'].forEach(function(k){try{var v=oG.call(LS,k);if(v!==null&&v!==undefined)o[k]=v}catch(e){}});
var id=Date.now().toString(36),date=new Date().toISOString(),LIM=Infinity,parts=[],cur={data:{},frags:[]},sz=0;
function push(){parts.push(cur);cur={data:{},frags:[]};sz=0}
Object.keys(o).forEach(function(k){var v=o[k];if(typeof v!=='string')v=JSON.stringify(v);var L=v.length;
if(L>LIM){if(sz>0)push();var n=Math.ceil(L/LIM);for(var j=0;j<n;j++){cur.frags.push({k:k,i:j,n:n,s:v.slice(j*LIM,(j+1)*LIM)});push()}}
else{if(sz+L>LIM)push();cur.data[k]=v;sz+=L}});
if(sz>0||!parts.length)push();
return parts.map(function(p,i){var fn='ColorLab_Recipe_Backup_'+date.slice(0,10)+(parts.length>1?'_Part'+(i+1)+'of'+parts.length:'')+'.json';
return{fn:fn,blob:new Blob([JSON.stringify({app:'ColorLabRecipe',v:2,id:id,date:date,part:i+1,total:parts.length,data:p.data,frags:p.frags})],{type:'application/json'})}})};
window.clBackup=async function(){try{var ps=clParts(),dl=window.claude&&window.claude.use?await window.claude.use('downloads'):null;
if(!dl){TX('Saving files is not available in this view.');return}
for(var i=0;i<ps.length;i++){TX('Saving Backup '+(i+1)+' of '+ps.length+'...');await dl.save({filename:ps[i].fn,data:ps[i].blob})}
TX('Backup complete: '+ps.length+(ps.length>1?' parts (Backup 1 to Backup '+ps.length+'). Keep all parts together and select them all when importing.':' file with all your data (recipes, dyes, counters, settings). Keep it safe (e.g. in your Google Drive).'),'#4ade80')}catch(e){TX(e&&e.code=='declined'?'Save cancelled.':'Backup failed: '+((e&&e.message)||e))}};
window.clDrive=async function(){var M=function(t,c){['qxm','dm'].forEach(function(id){var e=document.getElementById(id);if(e){e.className='mut';e.style.color=c||'';e.textContent=t}})};try{var ps=clParts(),fls=[];
try{fls=ps.map(function(p){return new File([p.blob],p.fn,{type:'application/json'})})}catch(e){fls=[]}
if(fls.length&&navigator.canShare&&navigator.canShare({files:fls})){try{await navigator.share({files:fls,title:'ColorLab Recipe Backup ('+ps.length+' part'+(ps.length>1?'s':'')+')'});M('Backup ready ('+ps.length+' part'+(ps.length>1?'s':'')+'). In the share list choose Drive (Save to Drive).','#4ade80');return}catch(e){if(e&&e.name=='AbortError'){M('Cancelled.');return}}}
var dl=window.claude&&window.claude.use?await window.claude.use('downloads'):null;if(!dl){M('Saving files is not available in this view.','#f87171');return}
for(var i=0;i<ps.length;i++){M('Saving Backup '+(i+1)+' of '+ps.length+'...');await dl.save({filename:ps[i].fn,data:ps[i].blob})}
M('Backup saved: '+ps.length+' part(s). Now upload them to your Google Drive.','#4ade80')}catch(e){M(e&&e.code=='declined'?'Save cancelled.':'Backup failed: '+((e&&e.message)||e),'#f87171')}};
window.clImport=function(fs){fs=Array.prototype.slice.call(fs||[]);if(!fs.length)return;
Promise.all(fs.map(function(f){return new Promise(function(res,rej){var r=new FileReader();r.onload=function(){res(r.result)};r.onerror=function(){rej(new Error('Cannot read '+f.name))};r.readAsText(f)})})).then(function(txt){try{
var os=txt.map(function(t){return JSON.parse(t)});os.forEach(function(x){if(!x||x.app!=='ColorLabRecipe'||!x.data)throw new Error('This is not a ColorLab backup file.')});
var o;if(os.length==1&&!os[0].part){o=os[0]}else{var id=os[0].id,tot=os[0].total,got={};
os.forEach(function(x){if(x.id!==id||x.total!==tot)throw new Error('These files are from different backups. Select only one backup set.');got[x.part]=x});
var miss=[];for(var q=1;q<=tot;q++)if(!got[q])miss.push('Backup '+q);
if(miss.length)throw new Error('Missing: '+miss.join(', ')+'. Select all '+tot+' parts together.');
o={data:{}};var fr={};for(var q2=1;q2<=tot;q2++){var x2=got[q2];Object.keys(x2.data).forEach(function(k){o.data[k]=x2.data[k]});(x2.frags||[]).forEach(function(g){(fr[g.k]=fr[g.k]||[])[g.i]=g.s})}
Object.keys(fr).forEach(function(k){o.data[k]=fr[k].join('')})}
var ob=['corr','refl','custom','price','ps'],keep=['auth','hdr','lim','prt'],n=0;
Object.keys(o.data).forEach(function(k){if(!P.test(k)&&k!=='cpairs'&&k!=='cpseed_counter_custom_v2')return;var nm=k.replace(/^colorlab_|_v1$/g,''),cur=localStorage.getItem(k),v=o.data[k];
if(ob.indexOf(nm)>=0){var a=JSON.parse(cur||'{}'),b=JSON.parse(v||'{}');v=JSON.stringify(Object.assign({},a,b))}
else if(nm=='his'){var a2=JSON.parse(cur||'[]'),b2=JSON.parse(v||'[]'),seen={};a2.forEach(function(h){seen[h.d+h.p]=1});v=JSON.stringify(b2.filter(function(h){return!seen[h.d+h.p]}).concat(a2).slice(0,5000))}
else if(keep.indexOf(nm)>=0&&cur!==null){return}
localStorage.setItem(k,v);n++});
TX('Imported '+n+' items. Reloading...','#4ade80');flush();setTimeout(function(){location.reload()},900)}catch(e){TX('Import failed: '+((e&&e.message)||e),'#f87171')}}).catch(function(e){TX('Import failed: '+((e&&e.message)||e),'#f87171')})};
window.clBar=function(host){var d=document.createElement('div');d.style.cssText='border-top:1px solid #334155;margin-top:8px;padding-top:8px;font-size:12px';
var B='background:#334155;color:#fff;border:0;border-radius:6px;padding:6px 10px;font-size:12px;margin:4px 6px 4px 0;display:inline-block';
var nh=0,nc=0;try{nh=HIS.length}catch(e){}try{nc=Object.keys(CORR).length}catch(e){}
d.innerHTML='<div>Saved recipes: <b>'+nh+'</b> (latest 20 shown) | Learned lab recipes: <b>'+nc+'</b></div><div id="clus" class="mut"></div><button style="'+B+'" onclick="clBackup()">Export backup</button><label style="'+B+';cursor:pointer">Import backup<input type="file" accept=".json,application/json" multiple style="display:none" onchange="clImport(this.files)"></label><div id="clst" class="mut"></div>';
host.appendChild(d);
try{navigator.storage.estimate().then(function(x){var u=x.usage||0,qt=x.quota||0,e=document.getElementById('clus');if(!e||!qt)return;var pc=u/qt*100;e.textContent='Storage used: '+(u/1048576).toFixed(1)+' MB of '+(qt/1048576).toFixed(0)+' MB';if(pc>80||CLSTORE.full){e.textContent+=' - almost full! Export a backup and free space.';e.style.color='#f87171'}})}catch(e){}
if(CLSTORE.full)TX('Storage is full or blocked. Export a backup now.','#f87171')};
})();
