/* AccoNova main: boot, shell, onboarding, sample data. */
(function (root) {
  "use strict";
  var UI = root.AN_UI, h = UI.h, t = UI.t, AN = root.AN, J = root.AN_J, F = UI.fmt;
  var TABS = ["home", "sales", "purchases", "payments", "journal", "accounts", "contacts", "reports", "settings", "eval"];
  function lsGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function lsSet(k, v) { try { localStorage.setItem(k, v); } catch (e) { } }

  /* ───── boot ───── */
  var storage = null, storageOk = true;
  try { localStorage.setItem("acconova.probe", "1"); localStorage.removeItem("acconova.probe"); storage = localStorage; } catch (e) { storageOk = false; storage = AN.memoryStorage(); }
  UI.store = AN.createStore({ storage: storage });
  UI.storageOk = storageOk;
  var nav = (navigator.language || "en").toLowerCase();
  UI.lang = lsGet("acconova.lang") || (nav.indexOf("fa") === 0 ? "fa" : "en"); if (UI.lang !== "fa" && UI.lang !== "en") UI.lang = "en";
  UI.tab = lsGet("acconova.tab") || "home"; if (TABS.indexOf(UI.tab) < 0) UI.tab = "home";

  function resolveSession() {
    var s = UI.store.session(), users = UI.store.users(), uid = s.uid, cid = s.cid;
    var okCompany = uid && cid && users[uid] && UI.store.listCompaniesFor(uid).some(function (c) { return c.id === cid; });
    if (okCompany) { UI.ctx = { uid: uid, cid: cid }; return; }
    var all = Object.keys(users);
    for (var i = 0; i < all.length; i++) { var cs = UI.store.listCompaniesFor(all[i]); if (cs.length) { UI.ctx = { uid: all[i], cid: cs[0].id }; UI.store.setSession(UI.ctx.uid, UI.ctx.cid); return; } }
    UI.ctx = null;
  }

  UI.go = function (tab, action) {
    UI.tab = tab; UI.pending = null;
    if (tab === "settings" && action) UI.sub.settings = action; else UI.pending = action || null;
    lsSet("acconova.tab", tab); UI.render(); if (window.scrollTo) window.scrollTo(0, 0);
  };
  UI.setLang = function (l) { UI.lang = l; lsSet("acconova.lang", l); UI.render(); };

  /* ───── render ───── */
  UI.render = function () {
    UI.clearTimers();
    document.querySelectorAll("dialog.modal").forEach(function (d) { try { d.close(); } catch (e) { } d.remove(); });
    var d = document.documentElement; d.lang = UI.lang; d.dir = UI.isFa() ? "rtl" : "ltr"; document.title = t("appTitle");
    resolveSession();
    var app = UI.$("app"); UI.clear(app);
    app.appendChild(langBar());
    if (!storageOk) app.appendChild(h("div", { class: "banner warn", text: t("storageBlocked") }));
    if (!UI.ctx) { app.appendChild(onboarding(false)); return; }
    app.appendChild(header());
    app.appendChild(tabsNav());
    var view = h("main", { class: "view", id: "view", tabindex: "-1" }); app.appendChild(view);
    try { UI.views[UI.tab](view); }
    catch (e) { view.appendChild(h("div", { class: "form-error", text: t("viewError") + " " + (e && e.message) })); if (root.console) console.error(e); }
  };

  function langBar() {
    return h("div", { class: "langbar" }, h("div", { class: "seg", role: "group", "aria-label": "Language / زبان" },
      h("button", { type: "button", lang: "fa", "aria-pressed": UI.isFa() ? "true" : "false", onclick: function () { UI.setLang("fa"); } }, "فارسی"),
      h("button", { type: "button", lang: "en", "aria-pressed": UI.isFa() ? "false" : "true", onclick: function () { UI.setLang("en"); } }, "English")));
  }
  function header() {
    var co = UI.co(), uid = UI.ctx.uid, users = UI.store.users(), plan = UI.store.effectivePlan(co);
    var companies = UI.store.listCompaniesFor(uid);
    var cSel = UI.select(companies.map(function (c) { return { value: c.id, label: c.name }; }).concat([{ value: "__new", label: "＋ " + t("newCompany") }]), UI.ctx.cid, function () {
      if (cSel.value === "__new") { cSel.value = UI.ctx.cid; var app = UI.$("app"); UI.clear(app); app.appendChild(langBar()); app.appendChild(onboarding(true)); return; }
      UI.ctx = { uid: uid, cid: cSel.value }; UI.store.setSession(uid, cSel.value); UI.render();
    });
    cSel.setAttribute("aria-label", t("company"));
    var members = Object.keys(co.members).filter(function (m) { return users[m]; });
    var uSel = UI.select(members.map(function (m) { return { value: m, label: users[m].name + " · " + t("role_" + co.members[m].role) }; }), uid, function () { UI.ctx = { uid: uSel.value, cid: UI.ctx.cid }; UI.store.setSession(uSel.value, UI.ctx.cid); UI.render(); });
    uSel.setAttribute("aria-label", t("signedInAs"));
    return h("header", { class: "top" },
      h("div", { class: "brand" }, h("div", { class: "logo", "aria-hidden": "true", html: '<svg viewBox="0 0 24 24" fill="none" stroke="#2a1505" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="3" width="16" height="18" rx="3"/><path d="M8 7h8M8 12h2M12 12h2M16 12h0M8 16h2M12 16h2M16 16h0"/></svg>' }),
        h("div", {}, h("h1", { text: "AccoNova" }), h("p", { class: "muted", text: t("tagline") }))),
      h("div", { class: "ctx" }, h("div", { class: "ctx-item" }, h("label", { class: "muted small", text: t("company") }), cSel), h("div", { class: "ctx-item" }, h("label", { class: "muted small", text: t("signedInAs") }), uSel), UI.badge(t("plan_" + plan), plan === "free" ? "" : "ok")));
  }
  function tabsNav() {
    return h("nav", { class: "tabs", "aria-label": t("navigation") }, TABS.map(function (k) { return h("button", { class: "tab" + (UI.tab === k ? " on" : ""), type: "button", "aria-current": UI.tab === k ? "page" : null, onclick: function () { UI.go(k); } }, t("tab_" + k)); }));
  }

  /* ───── onboarding ───── */
  function onboarding(additional) {
    var fa = UI.isFa(), users = UI.store.users(), uidExisting = UI.ctx && UI.ctx.uid;
    var owner = h("input", { class: "inp", maxlength: 80, value: additional && users[uidExisting] ? users[uidExisting].name : "", disabled: additional, autocomplete: "name" });
    var name = h("input", { class: "inp", maxlength: 120, autocomplete: "organization" });
    var base = UI.select(Object.keys(AN.CURRENCIES).map(function (c) { return { value: c, label: c + " · " + AN.CURRENCIES[c].name[UI.lang] }; }), fa ? "IRR" : "USD");
    var cal = UI.select([{ value: "jalali", label: t("cal_jalali") }, { value: "gregorian", label: t("cal_gregorian") }], fa ? "jalali" : "gregorian");
    var err = h("div", { class: "form-error", role: "alert", hidden: "" });
    function create(sample) {
      try {
        var uid = additional ? uidExisting : UI.store.createUser(owner.value || (sample ? (fa ? "کاربر نمونه" : "Demo user") : ""));
        var cid = UI.store.createCompany(uid, { name: name.value || (sample ? t("sampleCompany") : ""), baseCurrency: base.value, calendar: cal.value });
        UI.ctx = { uid: uid, cid: cid };
        if (sample) seed();
        UI.tab = "home"; UI.render();
      } catch (e) { err.textContent = UI.errMsg(e); err.hidden = false; }
    }
    var card = h("section", { class: "card onboard" }, h("h2", { text: additional ? t("newCompany") : t("welcome") }), h("p", { class: "muted", text: t("onboardIntro") }), err,
      h("div", { class: "form" }, UI.field(t("yourName"), owner), UI.field(t("companyName"), name), UI.field(t("baseCurrency"), base, t("baseCurrencyHint")), UI.field(t("calendar"), cal, t("calendarHint"))),
      h("div", { class: "actions" }, h("button", { class: "btn", type: "button", onclick: function () { create(false); } }, t("createCompany")), h("button", { class: "btn sec", type: "button", onclick: function () { create(true); } }, t("trySample")),
        additional ? h("button", { class: "btn sec", type: "button", onclick: function () { UI.render(); } }, t("cancel")) : null), h("p", { class: "muted small", text: t("localNote") }));
    var wrap = h("div", { class: "onboard-wrap" }, h("div", { class: "brand big" }, h("div", { class: "logo", "aria-hidden": "true", html: '<svg viewBox="0 0 24 24" fill="none" stroke="#2a1505" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="3" width="16" height="18" rx="3"/><path d="M8 7h8M8 12h2M12 12h2M16 12h0M8 16h2M12 16h2M16 16h0"/></svg>' }), h("div", {}, h("h1", { text: "AccoNova" }), h("p", { class: "muted", text: t("tagline") }))), card);
    return wrap;
  }

  /* ───── sample data (so a new user sees a working book immediately) ───── */
  function seed() {
    var s = UI.store, ctx = UI.ctx, co = s.company(ctx), today = s.today(), ago = function (n) { return J.addDaysIso(today, -n); }, ahead = function (n) { return J.addDaysIso(today, n); };
    var big = co.baseCurrency === "IRR" || co.baseCurrency === "IRT" || co.baseCurrency === "JPY", unit = big ? 1 : 100; /* minor units per 1 major unit */
    var M = function (major) { return major * unit; };
    var k = s.postEntry(ctx, { date: ago(55), memo: t("seedCapital"), lines: [{ accountId: co.sys.BANK, debit: M(big ? 500000000 : 50000) }, { accountId: co.sys.CAPITAL, credit: M(big ? 500000000 : 50000) }] }, { idemKey: "seed-cap" });
    var c1 = s.saveContact(ctx, { name: t("seedC1"), type: "customer", email: "info@example.com" }), c2 = s.saveContact(ctx, { name: t("seedC2"), type: "customer" }), v1 = s.saveContact(ctx, { name: t("seedV1"), type: "supplier" });
    var mk = function (kind, c, d, due, desc, qty, price) { var dr = s.saveInvoiceDraft(ctx, { kind: kind, contactId: c.id, date: d, dueDate: due, lines: [{ desc: desc, qty: qty, unitPrice: M(price) }] }); return s.postInvoice(ctx, dr.id, { idemKey: "seed-" + dr.id }).invoice; };
    var i1 = mk("sale", c1, ago(40), ago(10), t("seedS1"), 1000, big ? 120000000 : 1200), i2 = mk("sale", c2, ago(12), ahead(18), t("seedS2"), 2000, big ? 45000000 : 450), i3 = mk("sale", c1, ago(3), ahead(27), t("seedS3"), 1000, big ? 80000000 : 800);
    var b1 = mk("purchase", v1, ago(30), ahead(0), t("seedB1"), 1000, big ? 60000000 : 600);
    s.postPayment(ctx, { kind: "receipt", contactId: c1.id, date: ago(25), amount: i1.total, bankAccountId: co.sys.BANK, ref: "TRX-1001", allocations: [{ invoiceId: i1.id, amount: i1.total }] }, { idemKey: "seed-p1" });
    var half = Math.floor(i2.total / 2); s.postPayment(ctx, { kind: "receipt", contactId: c2.id, date: ago(5), amount: half, bankAccountId: co.sys.BANK, allocations: [{ invoiceId: i2.id, amount: half }] }, { idemKey: "seed-p2" });
    s.postEntry(ctx, { date: ago(20), memo: t("seedRent"), lines: [{ accountId: "A5200", debit: M(big ? 30000000 : 300) }, { accountId: co.sys.BANK, credit: M(big ? 30000000 : 300) }] }, { idemKey: "seed-rent" });
  }

  /* ───── start ───── */
  function start() {
    var toasts = h("div", { id: "toasts", class: "toasts", "aria-live": "polite" }); document.body.appendChild(toasts);
    UI.render();
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start); else start();
})(typeof globalThis !== "undefined" ? globalThis : this);
