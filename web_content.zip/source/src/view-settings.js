/* Settings: company & fiscal periods, currencies, taxes, members, plan & billing simulator, backup, audit, self-test, readiness, privacy. */
(function (root) {
  "use strict";
  var UI = root.AN_UI, h = UI.h, t = UI.t, F = UI.fmt, J = root.AN_J, AN = root.AN;
  var SUBS = ["company", "members", "plan", "backup", "audit", "selftest", "readiness", "privacy"];

  UI.views.settings = function (box) {
    var st = UI.sub.settings = UI.sub.settings || "company";
    var tabs = h("div", { class: "subtabs", role: "tablist" }, SUBS.map(function (s) { return h("button", { class: "subtab" + (st === s ? " on" : ""), type: "button", role: "tab", "aria-selected": st === s ? "true" : "false", onclick: function () { UI.sub.settings = s; UI.render(); } }, t("set_" + s)); }));
    box.appendChild(h("section", { class: "card" }, h("h2", { text: t("tabSettings") }), tabs));
    S[st](box);
  };

  var S = {};
  /* ───────────── company, periods, currencies, taxes ───────────── */
  S.company = function (box) {
    var co = UI.co();
    box.appendChild(h("section", { class: "card" }, h("h3", { text: t("companyInfo") }), h("dl", { class: "meta" },
      h("dt", { text: t("name") }), h("dd", { text: co.name }), h("dt", { text: t("baseCurrency") }), h("dd", { text: co.baseCurrency + " · " + AN.CURRENCIES[co.baseCurrency].name[UI.lang] }),
      h("dt", { text: t("calendar") }), h("dd", { text: co.calendar === "jalali" ? t("cal_jalali") : t("cal_gregorian") }), h("dt", { text: t("createdAt") }), h("dd", { text: F.dateTime(co.createdAt) }),
      h("dt", { text: t("yourRole") }), h("dd", { text: t("role_" + UI.store.roleOf(UI.ctx)) }))));

    /* fiscal periods */
    var years = {}; Object.keys(co.periods).forEach(function (k) { years[co.periods[k].year] = 1; });
    var ylist = Object.keys(years).map(Number).sort(function (a, b) { return b - a; });
    var cy = UI.sub.fy && years[UI.sub.fy] ? UI.sub.fy : UI.store.currentFiscalYear(co);
    var ysel = UI.select(ylist.map(function (y) { return { value: y, label: F.int(y) }; }), cy, function () { UI.sub.fy = Number(ysel.value); UI.render(); });
    var ps = Object.keys(co.periods).map(function (k) { return co.periods[k]; }).filter(function (p) { return p.year === Number(ysel.value); }).sort(function (a, b) { return a.month - b.month; });
    var rows = ps.map(function (p) {
      var btn = "";
      if (p.status === "open" && UI.can("period.close")) btn = h("button", { class: "link", type: "button", onclick: function () { try { UI.store.setPeriodStatus(UI.ctx, p.id, "closed"); UI.render(); } catch (e) { UI.toast(UI.errMsg(e), "err"); } } }, t("closePeriod"));
      if (p.status === "closed" && UI.can("period.reopen")) btn = h("button", { class: "link", type: "button", onclick: function () { try { UI.store.setPeriodStatus(UI.ctx, p.id, "open"); UI.render(); } catch (e) { UI.toast(UI.errMsg(e), "err"); } } }, t("reopenPeriod"));
      return [UI.monthName(co.calendar, p.month), F.date(p.start), F.date(p.end), UI.badge(p.status === "open" ? t("open") : t("closed"), p.status === "open" ? "ok" : "warn"), btn];
    });
    var yBtns = h("div", { class: "actions" });
    if (UI.can("period.close")) {
      yBtns.appendChild(h("button", { class: "btn sec", type: "button", onclick: function () { try { UI.store.ensureFiscalYear(UI.ctx, Math.max.apply(null, ylist) + 1); UI.sub.fy = Math.max.apply(null, ylist) + 1; UI.render(); } catch (e) { UI.toast(UI.errMsg(e), "err"); } } }, UI.icon("plus"), t("addFiscalYear")));
      yBtns.appendChild(h("button", { class: "btn danger", type: "button", onclick: function () { UI.confirm(t("closeYear"), t("closeYearQ", { y: F.int(ysel.value) }), t("closeYear"), true).then(function (ok) { if (!ok) return; try { var r = UI.store.closeFiscalYear(UI.ctx, Number(ysel.value)); UI.toast(t("yearClosedOk")); UI.render(); } catch (e) { UI.toast(UI.errMsg(e), "err"); } }); } }, t("closeYear")));
    }
    box.appendChild(h("section", { class: "card" }, h("div", { class: "toolbar" }, h("h3", { text: t("fiscalPeriods") }), ysel, h("span", { class: "grow" })), UI.table([{ label: t("period") }, { label: t("from") }, { label: t("to") }, { label: t("status") }, { label: "" }], rows), yBtns, h("p", { class: "muted small", text: t("periodsExplain") })));

    /* currencies */
    var plan = UI.store.planOf(co), crow = Object.keys(co.currencies).map(function (c) {
      var rates = co.rates.filter(function (r) { return r.code === c; }).sort(function (a, b) { return a.date < b.date ? 1 : -1; }), last = rates[0];
      return [c + " · " + AN.CURRENCIES[c].name[UI.lang] + (c === co.baseCurrency ? " ★" : ""), c === co.baseCurrency ? "—" : (last ? UI.num(F.num(last.rate / 1e6, { maximumFractionDigits: 6 }) + " (" + F.date(last.date) + ")") : t("noRate"))];
    });
    var cur = h("section", { class: "card" }, h("h3", { text: t("currencies") }), UI.table([{ label: t("currency") }, { label: t("lastRate") }], crow));
    if (UI.can("settings")) {
      if (!plan.multiCurrency) cur.appendChild(h("p", { class: "muted" }, UI.icon("lock"), " ", t("multiCurLocked")));
      else {
        var avail = Object.keys(AN.CURRENCIES).filter(function (c) { return !co.currencies[c]; }), addSel = UI.select(avail.map(function (c) { return { value: c, label: c + " · " + AN.CURRENCIES[c].name[UI.lang] }; }));
        var addBtn = h("button", { class: "btn sec", type: "button", onclick: function () { try { UI.store.addCurrency(UI.ctx, addSel.value); UI.render(); } catch (e) { UI.toast(UI.errMsg(e), "err"); } } }, UI.icon("plus"), t("addCurrency"));
        if (avail.length) cur.appendChild(h("div", { class: "toolbar" }, addSel, addBtn));
        var fcs = Object.keys(co.currencies).filter(function (c) { return c !== co.baseCurrency; });
        if (fcs.length) {
          var rc = UI.select(fcs.map(function (c) { return { value: c, label: c }; })), rd = UI.dateInput(UI.store.today()), rr = UI.rateInput();
          cur.appendChild(h("div", { class: "toolbar wrap" }, UI.field(t("currency"), rc), UI.field(t("date"), rd.el), UI.field(t("rate") + " (" + t("ratePer", { b: F.cur(co.baseCurrency) }) + ")", rr.el), h("div", { class: "field" }, h("label", { html: "&nbsp;" }), h("button", { class: "btn", type: "button", onclick: function () { var d = rd.get(), r = rr.get(); if (!d || !r) { UI.toast(t("e_BAD_RATE"), "err"); return; } try { UI.store.setRate(UI.ctx, rc.value, d, r); UI.toast(t("saved")); UI.render(); } catch (e) { UI.toast(UI.errMsg(e), "err"); } } }, t("saveRate")))));
        }
      }
    }
    box.appendChild(cur);

    /* tax codes */
    var trows = Object.keys(co.taxCodes).map(function (k) { var x = co.taxCodes[k]; return [x.name[UI.lang], F.pct(x.bps)]; });
    var tax = h("section", { class: "card" }, h("h3", { text: t("taxCodes") }), UI.table([{ label: t("name") }, { label: t("rateLbl") }], trows), h("p", { class: "muted small", text: t("taxNote") }));
    if (UI.can("settings")) {
      var tfa = h("input", { class: "inp", placeholder: t("nameFa") }), ten = h("input", { class: "inp", dir: "ltr", placeholder: t("nameEn") }), tr = h("input", { class: "inp num", dir: "ltr", inputmode: "decimal", placeholder: "%" });
      tax.appendChild(h("div", { class: "toolbar wrap" }, UI.field(t("nameFa"), tfa), UI.field(t("nameEn"), ten), UI.field(t("rateLbl") + " %", tr), h("div", { class: "field" }, h("label", { html: "&nbsp;" }), h("button", { class: "btn", type: "button", onclick: function () { var bps = AN.parseMoney(tr.value, 2); if (bps == null) { UI.toast(t("e_BAD_RATE"), "err"); return; } try { UI.store.saveTaxCode(UI.ctx, { name: { fa: tfa.value, en: ten.value }, bps: bps }); UI.toast(t("saved")); UI.render(); } catch (e) { UI.toast(UI.errMsg(e), "err"); } } }, t("addTax")))));
    }
    box.appendChild(tax);
  };

  /* ───────────── members ───────────── */
  S.members = function (box) {
    var co = UI.co(), users = UI.store.users(), plan = UI.store.planOf(co), me = UI.ctx.uid;
    var roles = AN.ROLES;
    var rows = Object.keys(co.members).map(function (uid) {
      var m = co.members[uid], isMe = uid === me, can = UI.can("members.manage") && !isMe;
      var sel = UI.select(roles.map(function (r) { return { value: r, label: t("role_" + r) }; }), m.role, function () { try { UI.store.setMemberRole(UI.ctx, uid, sel.value); UI.toast(t("saved")); UI.render(); } catch (e) { UI.toast(UI.errMsg(e), "err"); sel.value = m.role; } });
      sel.disabled = !can;
      var rm = can ? h("button", { class: "link danger-t", type: "button", onclick: function () { try { UI.store.removeMember(UI.ctx, uid); UI.render(); } catch (e) { UI.toast(UI.errMsg(e), "err"); } } }, t("remove")) : "";
      return [h("span", {}, users[uid] ? users[uid].name : uid, isMe ? h("span", { class: "tag", text: t("you") }) : null), sel, rm];
    });
    box.appendChild(h("section", { class: "card" }, h("h3", { text: t("members") }), h("p", { class: "note", text: t("membersNote") }), UI.table([{ label: t("name") }, { label: t("role") }, { label: "" }], rows),
      h("p", { class: "muted small", text: t("membersLimit", { n: F.int(Object.keys(co.members).length), max: plan.members === Infinity ? "∞" : F.int(plan.members) }) })));
    if (UI.can("members.manage")) {
      var others = Object.keys(users).filter(function (u) { return !co.members[u]; });
      var userSel = UI.select([{ value: "", label: t("newUser") }].concat(others.map(function (u) { return { value: u, label: users[u].name }; })));
      var nameInp = h("input", { class: "inp", maxlength: 80, placeholder: t("userName") }), roleSel = UI.select(["accountant", "viewer", "admin"].map(function (r) { return { value: r, label: t("role_" + r) }; }), "accountant");
      var add = h("button", { class: "btn", type: "button", onclick: function () {
        try { var uid = userSel.value || UI.store.createUser(nameInp.value); UI.store.addMember(UI.ctx, uid, roleSel.value); UI.toast(t("saved")); UI.render(); } catch (e) { UI.toast(UI.errMsg(e), "err"); }
      } }, UI.icon("plus"), t("addMember"));
      box.appendChild(h("section", { class: "card" }, h("h3", { text: t("addMember") }), h("div", { class: "toolbar wrap" }, UI.field(t("existingUser"), userSel), UI.field(t("userName"), nameInp), UI.field(t("role"), roleSel), h("div", { class: "field" }, h("label", { html: "&nbsp;" }), add)), h("p", { class: "muted small", text: t("roleMatrix") })));
    }
  };

  /* ───────────── plan & billing simulator ───────────── */
  S.plan = function (box) {
    var co = UI.co(), eff = UI.store.effectivePlan(co), u = UI.store.usage(co), sub = co.sub, T = root.AN_TEST;
    var cards = h("div", { class: "plans" }, ["free", "pro", "business"].map(function (p) {
      var L = AN.PLANS[p], lim = function (x) { return x === Infinity ? "∞" : F.int(x); };
      return h("div", { class: "plan-card" + (p === eff ? " on" : "") }, h("h3", { text: t("plan_" + p) }), p === eff ? UI.badge(t("current"), "ok") : null,
        h("ul", {}, h("li", { text: t("pl_members", { n: lim(L.members) }) }), h("li", { text: t("pl_invoices", { n: lim(L.invoicesPerMonth) }) }), h("li", { text: t("pl_contacts", { n: lim(L.contacts) }) }), h("li", { text: L.multiCurrency ? t("pl_multicur") : t("pl_nomulticur") }),
          h("li", { text: t("pl_reports", { n: F.int(L.reports.length) }) }), h("li", { text: L.encryptedBackup ? t("pl_encbackup") : t("pl_plainbackup") }), h("li", { text: t("pl_roles", { n: F.int(L.roles.length) }) })));
    }));
    var statusRows = h("dl", { class: "meta" }, h("dt", { text: t("currentPlan") }), h("dd", { text: t("plan_" + eff) }), h("dt", { text: t("subStatus") }), h("dd", { text: t("sub_" + sub.status) + (sub.plan !== eff ? " (" + t("plan_" + sub.plan) + ")" : "") }),
      sub.periodEnd ? [h("dt", { text: t("periodEnd") }), h("dd", { text: F.date(J.isoFrom.apply(null, (function (d) { return [d.getFullYear(), d.getMonth() + 1, d.getDate()]; })(new Date(sub.periodEnd)))) })] : null,
      sub.pending ? [h("dt", { text: t("pendingChange") }), h("dd", { text: t("plan_" + sub.pending.plan) })] : null,
      h("dt", { text: t("usage") }), h("dd", { text: t("usageLine", { m: F.int(u.members), c: F.int(u.contacts), i: F.int(u.invoicesThisMonth) }) }));
    box.appendChild(h("section", { class: "card" }, h("h3", { text: t("plan") }), cards, statusRows, h("p", { class: "note", text: t("limitsNote") })));

    /* simulator */
    var sim = h("section", { class: "card" }, h("h3", { text: t("billingSim") }), h("p", { class: "note", text: t("billingSimNote" ) }));
    if (!UI.can("plan.manage")) { sim.appendChild(h("p", { class: "muted", text: t("ownerOnly") })); box.appendChild(sim); return; }
    var out = h("div", { class: "sim-out", role: "status" });
    function send(ev, tamper) {
      var s = T.signEvent(ev), sig = s.sig; if (tamper) sig = sig.replace(/^./, sig[0] === "a" ? "b" : "a");
      UI.lastEvent = { cid: co.id, raw: s.raw, sig: sig };
      show(UI.store.handleBillingEvent(co.id, s.raw, sig, T.DEMO_SECRET));
    }
    function show(r) { out.textContent = r.ok ? (r.ignored ? t("sim_ignored_" + r.ignored) : t("sim_ok")) : t("sim_rejected_" + r.reason); out.className = "sim-out " + (r.ok && !r.ignored ? "ok" : "warn"); setTimeout(function () { UI.render(); }, 900); }
    function evt(type, data) { return { id: "evt_" + UI.newIdemKey().slice(-10), type: type, created: UI.store.now(), data: data || {} }; }
    var DAY = 864e5, now = UI.store.now();
    var btn = function (label, fn, cls) { return h("button", { class: "btn " + (cls || "sec"), type: "button", onclick: fn }, label); };
    sim.appendChild(h("div", { class: "actions" },
      btn(t("sim_payPro"), function () { send(evt("invoice.paid", { plan: "pro", periodEnd: UI.store.now() + 30 * DAY })); }, ""), btn(t("sim_payBiz"), function () { send(evt("invoice.paid", { plan: "business", periodEnd: UI.store.now() + 30 * DAY })); }, ""),
      btn(t("sim_fail"), function () { send(evt("invoice.payment_failed")); }), btn(t("sim_cancel"), function () { send(evt("subscription.canceled")); }), btn(t("sim_downgrade"), function () { send(evt("subscription.updated", { plan: "free" })); })));
    sim.appendChild(h("div", { class: "actions mt" }, btn(t("sim_replay"), function () { if (!UI.lastEvent || UI.lastEvent.cid !== co.id) { out.textContent = t("sim_nothing"); return; } show(UI.store.handleBillingEvent(co.id, UI.lastEvent.raw, UI.lastEvent.sig, T.DEMO_SECRET)); }),
      btn(t("sim_forged"), function () { send(evt("invoice.paid", { plan: "business", periodEnd: UI.store.now() + 365 * DAY }), true); })));
    sim.appendChild(out); box.appendChild(sim);
  };

  /* ───────────── backup & restore ───────────── */
  S.backup = function (box) {
    var co = UI.co(), plan = UI.store.planOf(co);
    var pass = h("input", { class: "inp", type: "password", autocomplete: "new-password", placeholder: t("passphrase") }), pass2 = h("input", { class: "inp", type: "password", autocomplete: "new-password", placeholder: t("passphraseRepeat") });
    var msg = h("div", { class: "sim-out" });
    var plainBtn = h("button", { class: "btn sec", type: "button", onclick: function () { UI.busy(plainBtn, function () { return UI.store.exportBackup(UI.ctx, {}).then(function (txt) { UI.download(UI.fileName("backup", "json"), txt, "application/json"); UI.toast(t("exported")); }).catch(function (e) { UI.toast(UI.errMsg(e), "err"); }); }); } }, UI.icon("download"), t("exportPlain"));
    var encBtn = h("button", { class: "btn", type: "button", disabled: !plan.encryptedBackup, onclick: function () {
      UI.busy(encBtn, function () {
        if (pass.value !== pass2.value) { msg.textContent = t("passMismatch"); msg.className = "sim-out warn"; return; }
        return UI.store.exportBackup(UI.ctx, { passphrase: pass.value }).then(function (txt) { UI.download(UI.fileName("backup_encrypted", "json"), txt, "application/json"); UI.toast(t("exported")); msg.textContent = ""; }).catch(function (e) { msg.textContent = UI.errMsg(e); msg.className = "sim-out warn"; });
      });
    } }, UI.icon("lock"), t("exportEnc"));
    box.appendChild(h("section", { class: "card" }, h("h3", { text: t("backupExport" ) }), h("p", { class: "note", text: t("backupNote") }), h("div", { class: "actions" }, plainBtn),
      h("h4", { text: t("encBackup") }), plan.encryptedBackup ? null : h("p", { class: "muted" }, UI.icon("lock"), " ", t("encLocked")), h("div", { class: "toolbar wrap" }, UI.field(t("passphrase"), pass), UI.field(t("passphraseRepeat"), pass2), h("div", { class: "field" }, h("label", { html: "&nbsp;" }), encBtn)), msg, h("p", { class: "muted small", text: t("passphraseWarn") })));
    var file = h("input", { type: "file", accept: ".json,application/json", class: "inp" }), ipass = h("input", { class: "inp", type: "password", autocomplete: "off", placeholder: t("passphraseIfEnc") }), imsg = h("div", { class: "sim-out" });
    var imp = h("button", { class: "btn", type: "button", onclick: function () {
      var f = file.files && file.files[0]; if (!f) { imsg.textContent = t("chooseFile"); imsg.className = "sim-out warn"; return; }
      UI.busy(imp, function () { return f.text().then(function (txt) { return UI.store.importBackup(UI.ctx.uid, txt, ipass.value); }).then(function (cid) { UI.ctx = { uid: UI.ctx.uid, cid: cid }; UI.toast(t("restoredOk")); UI.render(); }).catch(function (e) { imsg.textContent = UI.errMsg(e); imsg.className = "sim-out warn"; }); });
    } }, UI.icon("plus"), t("restore"));
    box.appendChild(h("section", { class: "card" }, h("h3", { text: t("restoreTitle") }), h("p", { class: "note", text: t("restoreNote") }), h("div", { class: "toolbar wrap" }, UI.field(t("backupFile"), file), UI.field(t("passphrase"), ipass), h("div", { class: "field" }, h("label", { html: "&nbsp;" }), imp)), imsg));
  };

  /* ───────────── audit & integrity ───────────── */
  S.audit = function (box) {
    var co = UI.co(), users = UI.store.users(), res = h("div", { class: "sim-out" });
    var verify = h("button", { class: "btn", type: "button", onclick: function () { var r = UI.store.verifyIntegrity(UI.ctx); res.className = "sim-out " + (r.ok ? "ok" : "warn"); res.textContent = r.ok ? t("integrityPass", { n: F.int(co.entries.length), a: F.int(co.audit.length) }) : t("integrityFail") + " — " + r.errors.slice(0, 5).join(" · "); } }, UI.icon("check"), t("verifyNow"));
    var rows = co.audit.slice(-150).reverse().map(function (a) { var u = users[a.uid]; return [F.dateTime(a.ts), u ? u.name : (a.uid === "billing" ? t("billingSystem") : a.uid), UI.num(a.action), a.detail || "", h("span", { class: "mono", dir: "ltr", text: a.hash.slice(0, 10) })]; });
    box.appendChild(h("section", { class: "card" }, h("h3", { text: t("auditLog") }), h("p", { class: "note", text: t("auditNote") }), h("div", { class: "actions" }, verify), res, UI.table([{ label: t("time") }, { label: t("user") }, { label: t("action") }, { label: t("detail") }, { label: t("hash") }], rows)));
  };

  /* ───────────── self-test (acceptance checklist, executed for real) ───────────── */
  S.selftest = function (box) {
    var T = root.AN_TEST, list = h("div", { class: "tests" }), sum = h("div", { class: "sim-out" }), runBtn = h("button", { class: "btn", type: "button" }, UI.icon("check"), t("runTests"));
    runBtn.addEventListener("click", function () {
      runBtn.disabled = true; UI.clear(list); sum.textContent = t("running"); sum.className = "sim-out";
      var okN = 0, total = 0;
      T.runAll(function (r, i, n) {
        total++; if (r.ok) okN++;
        var det = h("details", { class: "test " + (r.ok ? "pass" : "fail") }, h("summary", {}, h("span", { class: "tmark", text: r.ok ? "✓" : "✗" }), " ", t("test_" + r.id), h("span", { class: "muted", text: "  " + F.int(r.checks.filter(function (c) { return c.ok; }).length) + "/" + F.int(r.checks.length) + " · " + F.int(r.ms) + " ms" })),
          h("ul", {}, r.checks.map(function (c) { return h("li", { class: c.ok ? "ok" : "bad" }, (c.ok ? "✓ " : "✗ ") + c.name + (c.detail && !c.ok ? " — " + c.detail : "")); })));
        if (!r.ok) det.open = true; list.appendChild(det);
        sum.textContent = t("testsProgress", { i: F.int(i), n: F.int(n) });
      }).then(function () { sum.textContent = t("testsDone", { ok: F.int(okN), n: F.int(total) }); sum.className = "sim-out " + (okN === total ? "ok" : "warn"); runBtn.disabled = false; });
    });
    box.appendChild(h("section", { class: "card" }, h("h3", { text: t("acceptance") }), h("p", { class: "note", text: t("acceptanceNote") }), h("div", { class: "actions" }, runBtn), sum, list));
  };

  /* ───────────── readiness (honest status of the plan's gap table) ───────────── */
  S.readiness = function (box) {
    var rows = [
      ["gap_engine", "done"], ["gap_integrity", "partial"], ["gap_users", "partial"], ["gap_security", "server"], ["gap_billing", "partial"], ["gap_reports", "done"], ["gap_ops", "partial"], ["gap_global", "partial"]
    ].map(function (r) { return [h("b", { text: t(r[0]) }), UI.badge(t("rd_" + r[1]), r[1] === "done" ? "ok" : r[1] === "partial" ? "warn" : "bad"), t(r[0] + "_d")]; });
    box.appendChild(h("section", { class: "card" }, h("h3", { text: t("readiness") }), h("p", { class: "note", text: t("readinessNote") }), UI.table([{ label: t("area") }, { label: t("status") }, { label: t("detail") }], rows)));
  };

  /* ───────────── privacy & data ───────────── */
  S.privacy = function (box) {
    var co = UI.co(), chars = UI.store.sizeChars(), pct = Math.min(100, Math.round(chars / 5000000 * 100));
    box.appendChild(h("section", { class: "card" }, h("h3", { text: t("storageTitle") }), h("div", { class: "meter" }, h("i", { style: "width:" + pct + "%" })), h("p", { class: "muted", text: t("storageUsed", { kb: F.int(Math.round(chars / 1024)), p: F.int(pct) }) }), pct > 70 ? h("p", { class: "form-error", text: t("storageWarn") }) : null, h("p", { class: "note", text: t("storageNote") })));
    box.appendChild(h("section", { class: "card" }, h("h3", { text: t("privacyTitle") }), h("ul", { class: "plain" }, ["pv1", "pv2", "pv3", "pv4"].map(function (k) { return h("li", { text: t(k) }); })), h("p", { class: "muted small", text: t("legalNote") })));
    if (UI.can("company.delete")) {
      var inp = h("input", { class: "inp", placeholder: co.name }), del = h("button", { class: "btn danger", type: "button", onclick: function () {
        try { UI.store.deleteCompany(UI.ctx, inp.value); var next = UI.store.listCompaniesFor(UI.ctx.uid)[0]; UI.ctx = next ? { uid: UI.ctx.uid, cid: next.id } : null; UI.store.setSession(UI.ctx && UI.ctx.uid, UI.ctx && UI.ctx.cid); UI.toast(t("deleted")); UI.render(); } catch (e) { UI.toast(UI.errMsg(e), "err"); }
      } }, t("deleteCompany"));
      box.appendChild(h("section", { class: "card danger-zone" }, h("h3", { text: t("dangerZone") }), h("p", { text: t("deleteCompanyNote", { name: co.name }) }), h("div", { class: "toolbar wrap" }, UI.field(t("typeNameToConfirm"), inp), h("div", { class: "field" }, h("label", { html: "&nbsp;" }), del))));
    }
  };
})(typeof globalThis !== "undefined" ? globalThis : this);
