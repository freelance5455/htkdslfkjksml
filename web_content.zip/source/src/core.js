/* AccoNova core — double-entry accounting engine (no DOM, no network).
   Integer minor units only (no floating point money). All mutations go through `mutate()`:
   validate first, mutate second, persist once. Runs in the browser (global AN) and in Node (module.exports). */
(function (root) {
  "use strict";
  var J = (typeof module === "object" && module.exports) ? require("./jalali.js") : root.AN_J;

  /* ───────────────────────── utils ───────────────────────── */
  function err(code, msg, details) { var e = new Error(msg || code); e.code = code; if (details) e.details = details; return e; }
  function isInt(n) { return typeof n === "number" && Number.isSafeInteger(n); }
  var MAX = 9007199254740991;

  /* SHA-256 (sync) + HMAC — verified against Node crypto in tests */
  var K = (function () {
    var k = [], n = 2, c = 0;
    while (c < 64) { var p = true; for (var i = 2; i * i <= n; i++) if (n % i === 0) { p = false; break; } if (p) { k.push(Math.floor((Math.cbrt(n) % 1) * 4294967296) >>> 0); c++; } n++; }
    return k;
  })();
  var H0 = (function () {
    var h = [], n = 2, c = 0;
    while (c < 8) { var p = true; for (var i = 2; i * i <= n; i++) if (n % i === 0) { p = false; break; } if (p) { h.push(Math.floor((Math.sqrt(n) % 1) * 4294967296) >>> 0); c++; } n++; }
    return h;
  })();
  function utf8(str) {
    var out = [], i, c;
    for (i = 0; i < str.length; i++) {
      c = str.charCodeAt(i);
      if (c >= 0xD800 && c <= 0xDBFF && i + 1 < str.length) { var d = str.charCodeAt(i + 1); if (d >= 0xDC00 && d <= 0xDFFF) { c = 0x10000 + ((c - 0xD800) << 10) + (d - 0xDC00); i++; } }
      if (c < 0x80) out.push(c);
      else if (c < 0x800) out.push(0xC0 | (c >> 6), 0x80 | (c & 63));
      else if (c < 0x10000) out.push(0xE0 | (c >> 12), 0x80 | ((c >> 6) & 63), 0x80 | (c & 63));
      else out.push(0xF0 | (c >> 18), 0x80 | ((c >> 12) & 63), 0x80 | ((c >> 6) & 63), 0x80 | (c & 63));
    }
    return out;
  }
  function sha256Bytes(bytes) {
    var l = bytes.length, w = new Array(64), h = H0.slice(), i, j;
    var msg = bytes.slice(); msg.push(0x80);
    while (msg.length % 64 !== 56) msg.push(0);
    var hi = Math.floor(l / 536870912), lo = (l << 3) >>> 0;
    msg.push((hi >>> 24) & 255, (hi >>> 16) & 255, (hi >>> 8) & 255, hi & 255, (lo >>> 24) & 255, (lo >>> 16) & 255, (lo >>> 8) & 255, lo & 255);
    for (i = 0; i < msg.length; i += 64) {
      for (j = 0; j < 16; j++) w[j] = ((msg[i + 4 * j] << 24) | (msg[i + 4 * j + 1] << 16) | (msg[i + 4 * j + 2] << 8) | msg[i + 4 * j + 3]) >>> 0;
      for (j = 16; j < 64; j++) {
        var s0 = (((w[j - 15] >>> 7) | (w[j - 15] << 25)) ^ ((w[j - 15] >>> 18) | (w[j - 15] << 14)) ^ (w[j - 15] >>> 3)) >>> 0;
        var s1 = (((w[j - 2] >>> 17) | (w[j - 2] << 15)) ^ ((w[j - 2] >>> 19) | (w[j - 2] << 13)) ^ (w[j - 2] >>> 10)) >>> 0;
        w[j] = (w[j - 16] + s0 + w[j - 7] + s1) >>> 0;
      }
      var a = h[0], b = h[1], c = h[2], d = h[3], e = h[4], f = h[5], g = h[6], hh = h[7];
      for (j = 0; j < 64; j++) {
        var S1 = (((e >>> 6) | (e << 26)) ^ ((e >>> 11) | (e << 21)) ^ ((e >>> 25) | (e << 7))) >>> 0;
        var ch = ((e & f) ^ (~e & g)) >>> 0;
        var t1 = (hh + S1 + ch + K[j] + w[j]) >>> 0;
        var S0 = (((a >>> 2) | (a << 30)) ^ ((a >>> 13) | (a << 19)) ^ ((a >>> 22) | (a << 10))) >>> 0;
        var maj = ((a & b) ^ (a & c) ^ (b & c)) >>> 0;
        var t2 = (S0 + maj) >>> 0;
        hh = g; g = f; f = e; e = (d + t1) >>> 0; d = c; c = b; b = a; a = (t1 + t2) >>> 0;
      }
      h[0] = (h[0] + a) >>> 0; h[1] = (h[1] + b) >>> 0; h[2] = (h[2] + c) >>> 0; h[3] = (h[3] + d) >>> 0;
      h[4] = (h[4] + e) >>> 0; h[5] = (h[5] + f) >>> 0; h[6] = (h[6] + g) >>> 0; h[7] = (h[7] + hh) >>> 0;
    }
    var out = []; for (i = 0; i < 8; i++) out.push((h[i] >>> 24) & 255, (h[i] >>> 16) & 255, (h[i] >>> 8) & 255, h[i] & 255);
    return out;
  }
  function toHex(bytes) { var s = ""; for (var i = 0; i < bytes.length; i++) s += (bytes[i] < 16 ? "0" : "") + bytes[i].toString(16); return s; }
  function sha256(str) { return toHex(sha256Bytes(utf8(str))); }
  function hmacSha256(key, msg) {
    var kb = utf8(key); if (kb.length > 64) kb = sha256Bytes(kb);
    while (kb.length < 64) kb.push(0);
    var ipad = kb.map(function (b) { return b ^ 0x36; }), opad = kb.map(function (b) { return b ^ 0x5c; });
    return toHex(sha256Bytes(opad.concat(sha256Bytes(ipad.concat(utf8(msg))))));
  }
  function safeEqual(a, b) { if (typeof a !== "string" || typeof b !== "string" || a.length !== b.length) return false; var r = 0; for (var i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i); return r === 0; }
  function canon(v) {
    if (v === null || typeof v !== "object") return JSON.stringify(v);
    if (Array.isArray(v)) return "[" + v.map(canon).join(",") + "]";
    return "{" + Object.keys(v).sort().map(function (k) { return JSON.stringify(k) + ":" + canon(v[k]); }).join(",") + "}";
  }
  function deepFreeze(o) { if (o && typeof o === "object" && !Object.isFrozen(o)) { Object.freeze(o); Object.keys(o).forEach(function (k) { deepFreeze(o[k]); }); } return o; }
  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  function uid8() {
    var a = "";
    try { var u = new Uint8Array(8); (root.crypto || require("crypto").webcrypto).getRandomValues(u); for (var i = 0; i < u.length; i++) a += (u[i] < 16 ? "0" : "") + u[i].toString(16); return a; } catch (e) { }
    return (Math.random().toString(16).slice(2) + Date.now().toString(16)).slice(0, 16);
  }
  function newId(prefix) { return prefix + "_" + uid8(); }

  /* ───────────────────────── money ───────────────────────── */
  function digitsToLatin(s) {
    return String(s).replace(/[۰-۹]/g, function (c) { return c.charCodeAt(0) - 0x06F0; }).replace(/[٠-٩]/g, function (c) { return c.charCodeAt(0) - 0x0660; });
  }
  function parseMoney(s, decimals) {
    if (typeof s === "number") { if (!isFinite(s)) return null; s = String(s); }
    var t = digitsToLatin(String(s)).replace(/[\s ‌]/g, "").replace(/[,،٬]/g, "").replace(/٫/g, ".");
    if (!/^-?\d+(\.\d+)?$/.test(t)) return null;
    var neg = t.charAt(0) === "-"; if (neg) t = t.slice(1);
    var parts = t.split("."), ip = parts[0], fp = parts[1] || "";
    fp = fp.replace(/0+$/, "");
    if (fp.length > decimals) return null;
    while (fp.length < decimals) fp += "0";
    var big = BigInt(ip + fp);
    if (big > BigInt(MAX)) return null;
    var n = Number(big); return neg ? -n : n;
  }
  function pow10(n) { return BigInt("1" + new Array(n + 1).join("0")); }
  function roundDiv(num, den) { /* BigInt, half away from zero */
    var neg = (num < 0n) !== (den < 0n); if (num < 0n) num = -num; if (den < 0n) den = -den;
    var q = num / den, r = num % den; if (r * 2n >= den) q += 1n; return neg ? -q : q;
  }
  function mulDivRound(a, b, c) { return Number(roundDiv(BigInt(a) * BigInt(b), BigInt(c))); }
  /* convert minor units of a currency (decimals dFrom) into base minor units (decimals dBase) at rate (ppm: base per 1 foreign unit × 1e6) */
  function toBase(amount, dFrom, dBase, ratePpm) {
    if (amount === 0) return 0;
    var num = BigInt(amount) * BigInt(ratePpm) * pow10(dBase), den = 1000000n * pow10(dFrom);
    var r = Number(roundDiv(num, den));
    if (!isSafe(r)) throw err("AMOUNT_TOO_LARGE");
    return r;
  }
  function isSafe(n) { return Number.isSafeInteger(n); }
  function formatMinor(minor, decimals, locale) {
    var neg = minor < 0, a = BigInt(Math.abs(minor)), p = pow10(decimals);
    var ip = a / p, fp = a % p;
    var ipStr = new Intl.NumberFormat(locale || "en-US", { useGrouping: true, maximumFractionDigits: 0 }).format(ip);
    var out = ipStr;
    if (decimals > 0) {
      var f = fp.toString(); while (f.length < decimals) f = "0" + f;
      var dec = (locale || "").indexOf("fa") === 0 ? "٫" : ".";
      var fd = new Intl.NumberFormat(locale || "en-US", { useGrouping: false, minimumIntegerDigits: decimals }).format(BigInt(f));
      out += dec + fd;
    }
    return neg ? "‎-" + out : out;
  }

  /* ───────────────────────── constants ───────────────────────── */
  var TYPES = ["asset", "liability", "equity", "revenue", "expense"];
  var DEBIT_NORMAL = { asset: true, expense: true, liability: false, equity: false, revenue: false };
  var ROLES = ["owner", "admin", "accountant", "viewer"];
  var ROLE_RANK = { viewer: 0, accountant: 1, admin: 2, owner: 3 };
  var PERMS = {
    owner: ["view", "report", "export", "journal.post", "journal.reverse", "doc.manage", "contact.manage", "account.manage", "period.close", "period.reopen", "members.manage", "plan.manage", "company.delete", "backup", "settings"],
    admin: ["view", "report", "export", "journal.post", "journal.reverse", "doc.manage", "contact.manage", "account.manage", "period.close", "period.reopen", "members.manage", "backup", "settings"],
    accountant: ["view", "report", "export", "journal.post", "journal.reverse", "doc.manage", "contact.manage", "account.manage", "period.close", "backup"],
    viewer: ["view", "report", "export"]
  };
  /* Plan limits are placeholders to be set after cost analysis (server, gateway, storage). Enforced in the data layer, not only in the UI. */
  var ALL_REPORTS = ["tb", "gl", "pl", "bs", "ar", "ap"];
  var PLANS = {
    free: { members: 1, invoicesPerMonth: 10, contacts: 20, accounts: 40, multiCurrency: false, reports: ["tb", "gl", "pl"], encryptedBackup: false, roles: ["owner"] },
    pro: { members: 5, invoicesPerMonth: Infinity, contacts: Infinity, accounts: Infinity, multiCurrency: true, reports: ALL_REPORTS, encryptedBackup: true, roles: ["owner", "accountant", "viewer"] },
    business: { members: 25, invoicesPerMonth: Infinity, contacts: Infinity, accounts: Infinity, multiCurrency: true, reports: ALL_REPORTS, encryptedBackup: true, roles: ["owner", "admin", "accountant", "viewer"] }
  };
  var PLAN_RANK = { free: 0, pro: 1, business: 2 };
  var CURRENCIES = {
    IRR: { code: "IRR", decimals: 0, name: { fa: "ریال ایران", en: "Iranian rial" } },
    IRT: { code: "IRT", decimals: 0, name: { fa: "تومان", en: "Toman" } },
    USD: { code: "USD", decimals: 2, name: { fa: "دلار آمریکا", en: "US dollar" } },
    EUR: { code: "EUR", decimals: 2, name: { fa: "یورو", en: "Euro" } },
    GBP: { code: "GBP", decimals: 2, name: { fa: "پوند بریتانیا", en: "Pound sterling" } },
    AED: { code: "AED", decimals: 2, name: { fa: "درهم امارات", en: "UAE dirham" } },
    TRY: { code: "TRY", decimals: 2, name: { fa: "لیر ترکیه", en: "Turkish lira" } },
    AFN: { code: "AFN", decimals: 2, name: { fa: "افغانی", en: "Afghan afghani" } },
    CAD: { code: "CAD", decimals: 2, name: { fa: "دلار کانادا", en: "Canadian dollar" } },
    JPY: { code: "JPY", decimals: 0, name: { fa: "ین ژاپن", en: "Japanese yen" } }
  };
  var DEFAULT_ACCOUNTS = [
    ["1000", "asset", "BANK", "صندوق و بانک", "Cash & bank"],
    ["1100", "asset", "AR", "حساب‌های دریافتنی", "Accounts receivable"],
    ["1200", "asset", "TAXIN", "مالیات بر ارزش افزودهٔ قابل استرداد", "Tax receivable (input)"],
    ["1300", "asset", "", "پیش‌پرداخت‌ها", "Prepayments"],
    ["1500", "asset", "", "دارایی‌های ثابت", "Fixed assets"],
    ["2000", "liability", "AP", "حساب‌های پرداختنی", "Accounts payable"],
    ["2100", "liability", "TAXOUT", "مالیات بر ارزش افزودهٔ پرداختنی", "Tax payable (output)"],
    ["2200", "liability", "", "وام‌ها", "Loans"],
    ["3000", "equity", "CAPITAL", "سرمایه", "Owner's equity"],
    ["3100", "equity", "RE", "سود (زیان) انباشته", "Retained earnings"],
    ["4000", "revenue", "REVENUE", "درآمد فروش", "Sales revenue"],
    ["4100", "revenue", "", "سایر درآمدها", "Other income"],
    ["4900", "revenue", "FX", "سود (زیان) تسعیر ارز تحقق‌یافته", "Realized FX gain (loss)"],
    ["5000", "expense", "COGS", "بهای تمام‌شدهٔ کالای فروش‌رفته", "Cost of goods sold"],
    ["5100", "expense", "EXPENSE", "هزینه‌های عملیاتی", "Operating expenses"],
    ["5200", "expense", "", "اجاره", "Rent"],
    ["5300", "expense", "", "حقوق و دستمزد", "Salaries & wages"],
    ["5400", "expense", "", "هزینه‌های بانکی", "Bank charges"],
    ["9990", "expense", "ROUND", "تفاوت گرد کردن", "Rounding differences"]
  ];

  /* ───────────────────────── store ───────────────────────── */
  function memoryStorage() { var m = {}; return { getItem: function (k) { return Object.prototype.hasOwnProperty.call(m, k) ? m[k] : null; }, setItem: function (k, v) { m[k] = String(v); }, removeItem: function (k) { delete m[k]; } }; }
  function localDate(d) { return J.isoFrom(d.getFullYear(), d.getMonth() + 1, d.getDate()); }

  function createStore(opts) {
    opts = opts || {};
    var storage = opts.storage || memoryStorage(), KEY = opts.key || "acconova.v1";
    var nowFn = opts.now || function () { return Date.now(); };
    var todayFn = opts.today || function () { return localDate(new Date(nowFn())); };
    var S, lastSaved;

    function emptyState() { return { v: 1, users: {}, companies: {}, session: { uid: null, cid: null } }; }
    function load() {
      var raw = null; try { raw = storage.getItem(KEY); } catch (e) { }
      if (!raw) { S = emptyState(); lastSaved = JSON.stringify(S); return; }
      try { S = JSON.parse(raw); if (!S || S.v !== 1) throw 0; } catch (e) { S = emptyState(); }
      Object.keys(S.companies).forEach(function (cid) { S.companies[cid].entries.forEach(deepFreeze); });
      lastSaved = JSON.stringify(S);
    }
    /* Posted entries and audit records are append-only, so their JSON is cached per object: a save only re-serialises what can change. */
    var recCache = new WeakMap();
    function recJson(e) { var j = recCache.get(e); if (!j) { j = JSON.stringify(e); recCache.set(e, j); } return j; }
    function serialize() {
      var marks = {}, n = 0;
      var s = JSON.stringify(S, function (key, value) { if ((key === "entries" || key === "audit") && Array.isArray(value)) { var m = "__LOG_" + (n++) + "__"; marks[m] = value; return m; } return value; });
      Object.keys(marks).forEach(function (m) { var i = s.indexOf('"' + m + '"'); s = s.slice(0, i) + "[" + marks[m].map(recJson).join(",") + "]" + s.slice(i + m.length + 2); });
      return s;
    }
    function save() {
      var s = serialize();
      try { storage.setItem(KEY, s); lastSaved = s; }
      catch (e) { revert(); throw err("STORAGE_FAILED", "Could not save data (storage full or blocked)"); }
    }
    function revert() { S = JSON.parse(lastSaved); Object.keys(S.companies).forEach(function (cid) { S.companies[cid].entries.forEach(deepFreeze); }); }
    load();

    /* ---- access control ---- */
    function company(ctx) {
      if (!ctx || !ctx.cid || !ctx.uid) throw err("NO_SESSION");
      var co = S.companies[ctx.cid]; if (!co) throw err("NO_COMPANY");
      if (!S.users[ctx.uid]) throw err("NO_USER");
      if (!co.members[ctx.uid]) throw err("NOT_MEMBER");
      return co;
    }
    function roleOf(ctx) { return company(ctx).members[ctx.uid].role; }
    function can(ctx, perm) { try { return PERMS[roleOf(ctx)].indexOf(perm) > -1; } catch (e) { return false; } }
    function access(ctx, perm) { var co = company(ctx); if (perm && PERMS[co.members[ctx.uid].role].indexOf(perm) < 0) throw err("FORBIDDEN", "Permission denied: " + perm, { perm: perm }); return co; }
    function mutate(ctx, perm, fn) {
      var co = access(ctx, perm);
      try { var r = fn(co); save(); return r; }
      catch (e) { if (!e.code) { revert(); } throw e; }
    }
    function audit(co, ctx, action, entity, id, detail) {
      var prev = co.audit.length ? co.audit[co.audit.length - 1].hash : "";
      var rec = { seq: co.audit.length + 1, ts: nowFn(), uid: ctx.uid, action: action, entity: entity || "", id: id || "", detail: detail || "", prev: prev };
      rec.hash = sha256(prev + canon({ seq: rec.seq, ts: rec.ts, uid: rec.uid, action: rec.action, entity: rec.entity, id: rec.id, detail: rec.detail }));
      co.audit.push(rec);
    }

    /* ---- plan / subscription ---- */
    function effectivePlan(co, at) {
      at = at == null ? nowFn() : at;
      var s = co.sub, plan = s.plan;
      if (s.pending && s.periodEnd && at >= s.pending.at) plan = s.pending.plan;
      if (plan === "free") return "free";
      if (s.status === "active" || s.status === "trialing") return (s.periodEnd && at > s.periodEnd) ? "free" : plan;
      if (s.status === "past_due") return (s.periodEnd && at <= s.periodEnd + s.graceDays * 864e5) ? plan : "free";
      if (s.status === "canceled") return (s.periodEnd && at <= s.periodEnd) ? plan : "free";
      return "free";
    }
    function planOf(co) { return PLANS[effectivePlan(co)]; }
    function requireFeature(co, feat) { var p = planOf(co); if (!p[feat]) throw err("PLAN_FEATURE", "Not available on your plan: " + feat, { feature: feat, plan: effectivePlan(co) }); }
    function requireReport(co, id) { if (planOf(co).reports.indexOf(id) < 0) throw err("PLAN_FEATURE", "Report not available on your plan", { feature: "report:" + id, plan: effectivePlan(co) }); }
    function usage(co) {
      var m = monthKey(todayFn());
      return {
        plan: effectivePlan(co), limits: planOf(co), members: Object.keys(co.members).length,
        contacts: Object.keys(co.contacts).filter(function (k) { return !co.contacts[k].archived; }).length,
        accounts: Object.keys(co.accounts).length,
        invoicesThisMonth: Object.keys(co.invoices).filter(function (k) { var i = co.invoices[k]; return i.status !== "draft" && i.date.slice(0, 7) === m; }).length
      };
    }
    function monthKey(iso) { return iso.slice(0, 7); }

    /* ---- users & companies ---- */
    function createUser(name) {
      name = String(name || "").trim(); if (!name || name.length > 80) throw err("BAD_NAME");
      var id = newId("u"); S.users[id] = { id: id, name: name, createdAt: nowFn() }; save(); return id;
    }
    function createCompany(uid, o) {
      if (!S.users[uid]) throw err("NO_USER");
      var name = String(o.name || "").trim(); if (!name || name.length > 120) throw err("BAD_NAME");
      var base = o.baseCurrency || "USD"; if (!CURRENCIES[base]) throw err("BAD_CURRENCY");
      var cal = o.calendar === "jalali" ? "jalali" : "gregorian";
      var id = newId("c"), accounts = {}, sys = {};
      DEFAULT_ACCOUNTS.forEach(function (a, i) {
        var aid = "A" + a[0]; accounts[aid] = { id: aid, code: a[0], type: a[1], name: { fa: a[3], en: a[4] }, system: a[2] || "", active: true }; if (a[2]) sys[a[2]] = aid;
      });
      var cur = {}; cur[base] = clone(CURRENCIES[base]);
      var co = {
        id: id, name: name, baseCurrency: base, calendar: cal, createdAt: nowFn(), schema: 1,
        currencies: cur, rates: [], accounts: accounts, sys: sys, periods: {}, entries: [], reversals: {},
        contacts: {}, taxCodes: { T0: { id: "T0", name: { fa: "بدون مالیات", en: "No tax" }, bps: 0 } },
        invoices: {}, payments: {}, members: {}, billingEvents: {}, idem: {}, audit: [],
        counters: { entry: 0, sale: 0, purchase: 0, receipt: 0, payout: 0 },
        sub: { plan: "free", status: "active", periodEnd: null, graceDays: 7, lastEventAt: 0, pending: null }
      };
      co.members[uid] = { uid: uid, role: "owner", addedAt: nowFn() };
      S.companies[id] = co;
      ensureYearInternal(co, currentFiscalYear(co));
      audit(co, { uid: uid }, "company.create", "company", id, name);
      S.session = { uid: uid, cid: id };
      save(); return id;
    }
    function listCompaniesFor(uid) { return Object.keys(S.companies).filter(function (c) { return S.companies[c].members[uid]; }).map(function (c) { return { id: c, name: S.companies[c].name, role: S.companies[c].members[uid].role }; }); }
    function deleteCompany(ctx, confirmName) {
      var co = access(ctx, "company.delete");
      if (String(confirmName) !== co.name) throw err("CONFIRM_MISMATCH");
      delete S.companies[co.id]; if (S.session.cid === co.id) S.session.cid = null; save(); return true;
    }

    /* ---- fiscal periods ---- */
    function fiscalYearOf(co, iso) { var p = J.parseIso(iso); return co.calendar === "jalali" ? J.toJalali(p.y, p.m, p.d).y : p.y; }
    function currentFiscalYear(co) { return fiscalYearOf(co, todayFn()); }
    function periodBounds(co, y, m) {
      if (co.calendar === "jalali") {
        var s = J.toGregorian(y, m, 1), e = J.toGregorian(y, m, J.jalaliMonthLength(y, m));
        return { start: J.isoFrom(s.y, s.m, s.d), end: J.isoFrom(e.y, e.m, e.d) };
      }
      return { start: J.isoFrom(y, m, 1), end: J.isoFrom(y, m, J.gregorianMonthLength(y, m)) };
    }
    function periodId(y, m) { return "P-" + y + "-" + (m < 10 ? "0" : "") + m; }
    function ensureYearInternal(co, y) {
      for (var m = 1; m <= 12; m++) { var id = periodId(y, m); if (!co.periods[id]) { var b = periodBounds(co, y, m); co.periods[id] = { id: id, year: y, month: m, start: b.start, end: b.end, status: "open" }; } }
    }
    function findPeriod(co, iso) {
      var y = fiscalYearOf(co, iso), cy = currentFiscalYear(co);
      if (y < cy - 10 || y > cy + 2) return null;
      ensureYearInternal(co, y);
      var ids = Object.keys(co.periods);
      for (var i = 0; i < ids.length; i++) { var p = co.periods[ids[i]]; if (iso >= p.start && iso <= p.end) return p; }
      return null;
    }
    function setPeriodStatus(ctx, id, status) {
      return mutate(ctx, status === "open" ? "period.reopen" : "period.close", function (co) {
        var p = co.periods[id]; if (!p) throw err("NOT_FOUND");
        if (p.status === status) return p;
        p.status = status; audit(co, ctx, "period." + (status === "open" ? "reopen" : "close"), "period", id, "");
        return p;
      });
    }
    function ensureFiscalYear(ctx, y) { return mutate(ctx, "period.close", function (co) { if (!isInt(y) || y < 1 || y > 3000) throw err("BAD_DATE"); ensureYearInternal(co, y); return true; }); }

    /* ---- currencies & rates ---- */
    function addCurrency(ctx, code) {
      return mutate(ctx, "settings", function (co) {
        requireFeature(co, "multiCurrency");
        if (!CURRENCIES[code]) throw err("BAD_CURRENCY"); if (co.currencies[code]) return false;
        co.currencies[code] = clone(CURRENCIES[code]); audit(co, ctx, "currency.add", "currency", code, ""); return true;
      });
    }
    function setRate(ctx, code, date, ratePpm) {
      return mutate(ctx, "settings", function (co) {
        requireFeature(co, "multiCurrency");
        if (!co.currencies[code] || code === co.baseCurrency) throw err("BAD_CURRENCY");
        if (!J.parseIso(date)) throw err("BAD_DATE"); if (!isInt(ratePpm) || ratePpm <= 0) throw err("BAD_RATE");
        co.rates.push({ code: code, date: date, rate: ratePpm }); audit(co, ctx, "rate.set", "currency", code, date + " " + ratePpm); return true;
      });
    }
    function rateFor(co, code, date) {
      if (code === co.baseCurrency) return 1000000;
      var best = null, bi = -1;
      for (var i = 0; i < co.rates.length; i++) { var r = co.rates[i]; if (r.code === code && r.date <= date && (!best || r.date > best.date || (r.date === best.date && i > bi))) { best = r; bi = i; } }
      return best ? best.rate : null;
    }

    /* ---- accounts ---- */
    function addAccount(ctx, o) {
      return mutate(ctx, "account.manage", function (co) {
        var p = planOf(co); if (Object.keys(co.accounts).length >= p.accounts) throw err("PLAN_LIMIT", "Account limit reached", { limit: "accounts", max: p.accounts });
        var code = String(o.code || "").trim(); if (!/^[0-9A-Za-z.\-]{1,12}$/.test(code)) throw err("BAD_CODE");
        if (Object.keys(co.accounts).some(function (k) { return co.accounts[k].code === code; })) throw err("DUPLICATE_CODE");
        if (TYPES.indexOf(o.type) < 0) throw err("BAD_TYPE");
        var fa = String((o.name && o.name.fa) || "").trim(), en = String((o.name && o.name.en) || "").trim();
        if (!fa && !en) throw err("BAD_NAME"); if (fa.length > 120 || en.length > 120) throw err("BAD_NAME");
        var id = "A" + code; if (co.accounts[id]) throw err("DUPLICATE_CODE");
        co.accounts[id] = { id: id, code: code, type: o.type, name: { fa: fa || en, en: en || fa }, system: "", active: true };
        audit(co, ctx, "account.add", "account", id, code); return co.accounts[id];
      });
    }
    function renameAccount(ctx, id, name) {
      return mutate(ctx, "account.manage", function (co) {
        var a = co.accounts[id]; if (!a) throw err("NOT_FOUND");
        var fa = String(name.fa || "").trim(), en = String(name.en || "").trim(); if (!fa && !en) throw err("BAD_NAME");
        a.name = { fa: fa || en, en: en || fa }; audit(co, ctx, "account.rename", "account", id, ""); return a;
      });
    }
    function setAccountActive(ctx, id, active) {
      return mutate(ctx, "account.manage", function (co) {
        var a = co.accounts[id]; if (!a) throw err("NOT_FOUND");
        if (!active) {
          if (a.system) throw err("SYSTEM_ACCOUNT");
          var b = balances(co, {}, [id])[id]; if (b && (b.debit !== 0 || b.credit !== 0)) throw err("ACCOUNT_IN_USE");
        }
        a.active = !!active; audit(co, ctx, "account.active", "account", id, String(!!active)); return a;
      });
    }

    /* ---- journal ---- */
    function buildEntry(co, input, trusted) {
      var date = input.date; if (!J.parseIso(date)) throw err("BAD_DATE");
      var period = findPeriod(co, date); if (!period) throw err("NO_PERIOD");
      if (period.status !== "open") throw err("PERIOD_CLOSED", "Fiscal period is closed", { period: period.id });
      var cur = input.currency || co.baseCurrency, cdef = co.currencies[cur]; if (!cdef) throw err("BAD_CURRENCY");
      var base = co.currencies[co.baseCurrency], rate = 1000000;
      if (cur !== co.baseCurrency) {
        if (!trusted) requireFeature(co, "multiCurrency"); /* system documents check the plan themselves; voiding must keep working after a downgrade */
        rate = input.rate != null ? input.rate : rateFor(co, cur, date);
        if (!isInt(rate) || rate <= 0) throw err("NO_RATE");
      }
      var memo = String(input.memo || "").trim(); if (memo.length > 300) throw err("MEMO_TOO_LONG");
      var lines = input.lines; if (!Array.isArray(lines) || lines.length < 2 || lines.length > 200) throw err("TOO_FEW_LINES");
      var td = 0, tc = 0, bd = 0, bc = 0, out = [];
      lines.forEach(function (l) {
        var acc = co.accounts[l.accountId]; if (!acc) throw err("ACCOUNT_NOT_FOUND");
        if (!acc.active) throw err("ACCOUNT_INACTIVE");
        var d = l.debit || 0, c = l.credit || 0;
        if (!isInt(d) || !isInt(c) || d < 0 || c < 0) throw err("BAD_AMOUNT");
        var line = { accountId: l.accountId, debit: d, credit: c, baseDebit: 0, baseCredit: 0 };
        if (l.baseOnly) {
          if (!trusted) throw err("BAD_LINE");
          if (d || c) throw err("BAD_LINE");
          var xd = (l.base && l.base.debit) || 0, xc = (l.base && l.base.credit) || 0;
          if (!isInt(xd) || !isInt(xc) || xd < 0 || xc < 0 || (xd > 0) === (xc > 0)) throw err("BAD_LINE");
          line.baseDebit = xd; line.baseCredit = xc; line.baseOnly = true;
        } else {
          if ((d > 0) === (c > 0)) throw err("BAD_LINE", "A line needs exactly one of debit or credit");
          if (l.base) {
            if (!trusted) throw err("BAD_LINE");
            line.baseDebit = d > 0 ? l.base.debit : 0; line.baseCredit = c > 0 ? l.base.credit : 0;
            if (!isInt(line.baseDebit) || !isInt(line.baseCredit)) throw err("BAD_AMOUNT");
          } else {
            line.baseDebit = d > 0 ? toBase(d, cdef.decimals, base.decimals, rate) : 0;
            line.baseCredit = c > 0 ? toBase(c, cdef.decimals, base.decimals, rate) : 0;
          }
        }
        if (l.contactId) { if (!co.contacts[l.contactId]) throw err("CONTACT_NOT_FOUND"); line.contactId = l.contactId; }
        if (l.memo) line.memo = String(l.memo).slice(0, 200);
        td += d; tc += c; bd += line.baseDebit; bc += line.baseCredit;
        if (td > MAX || tc > MAX || bd > MAX || bc > MAX) throw err("AMOUNT_TOO_LARGE");
        out.push(line);
      });
      if (td !== tc) throw err("UNBALANCED", "Debits and credits differ", { debit: td, credit: tc });
      if (td === 0 && bd === 0) throw err("ZERO_ENTRY");
      var diff = bd - bc;
      if (diff !== 0) {
        if (Math.abs(diff) > lines.length || !co.sys.ROUND) throw err("UNBALANCED_BASE", "Base-currency amounts differ", { diff: diff });
        out.push({ accountId: co.sys.ROUND, debit: 0, credit: 0, baseDebit: diff < 0 ? -diff : 0, baseCredit: diff > 0 ? diff : 0, baseOnly: true, memo: "rounding" });
        if (diff > 0) bd += diff; else bc += -diff;
      }
      return { date: date, period: period, currency: cur, rate: rate, memo: memo, lines: out, total: td, baseTotal: bd };
    }
    function commitEntry(co, ctx, built, source) {
      var seq = co.counters.entry + 1, prev = co.entries.length ? co.entries[co.entries.length - 1].hash : "";
      var core = { id: "JE-" + String(seq).padStart(6, "0"), seq: seq, date: built.date, periodId: built.period.id, currency: built.currency, rate: built.rate, memo: built.memo, lines: built.lines, total: built.total, baseTotal: built.baseTotal, source: source, createdBy: ctx.uid, createdAt: nowFn() };
      var e = clone(core); e.prevHash = prev; e.hash = sha256(prev + canon(core));
      deepFreeze(e); co.entries.push(e); co.counters.entry = seq; delete co._idx;
      audit(co, ctx, "entry.post", "entry", e.id, source.type + (built.memo ? ": " + built.memo.slice(0, 60) : ""));
      return e;
    }
    function idemCheck(co, key, fingerprint) {
      if (!key) return null;
      var r = co.idem[key]; if (!r) return null;
      if (r.fp !== fingerprint) throw err("IDEM_CONFLICT", "Idempotency key reused with different data");
      return r;
    }
    function idemSave(co, key, fp, type, id) { if (key) co.idem[key] = { fp: fp, type: type, id: id, at: nowFn() }; }
    function postEntry(ctx, input, o) {
      o = o || {};
      return mutate(ctx, "journal.post", function (co) {
        var fp = sha256(canon({ k: "entry", i: input })), prior = idemCheck(co, o.idemKey, fp);
        if (prior) { var ex = co.entries.filter(function (x) { return x.id === prior.id; })[0]; return { entry: ex, duplicate: true }; }
        var built = buildEntry(co, input, false);
        var e = commitEntry(co, ctx, built, { type: "manual", id: "" });
        idemSave(co, o.idemKey, fp, "entry", e.id);
        return { entry: e, duplicate: false };
      });
    }
    function entryById(co, id) { for (var i = co.entries.length - 1; i >= 0; i--) if (co.entries[i].id === id) return co.entries[i]; return null; }
    function reverseInternal(co, ctx, orig, date, memo, source) {
      var lines = orig.lines.map(function (l) {
        var n = { accountId: l.accountId, debit: l.credit, credit: l.debit, base: { debit: l.baseCredit, credit: l.baseDebit } };
        if (l.baseOnly) { n.baseOnly = true; n.debit = 0; n.credit = 0; }
        if (l.contactId) n.contactId = l.contactId; return n;
      });
      var built = buildEntry(co, { date: date, currency: orig.currency, rate: orig.rate, memo: memo, lines: lines }, true);
      var e = commitEntry(co, ctx, built, source);
      co.reversals[orig.id] = e.id; return e;
    }
    function reverseEntry(ctx, entryId, o) {
      o = o || {};
      return mutate(ctx, "journal.reverse", function (co) {
        var orig = entryById(co, entryId); if (!orig) throw err("NOT_FOUND");
        var fp = sha256(canon({ k: "rev", id: entryId, d: o.date || "" })), prior = idemCheck(co, o.idemKey, fp);
        if (prior) return { entry: entryById(co, prior.id), duplicate: true };
        if (orig.source.type !== "manual") throw err("USE_DOCUMENT_VOID", "Void the originating document instead");
        if (co.reversals[orig.id]) throw err("ALREADY_REVERSED");
        var date = o.date || orig.date;
        var e = reverseInternal(co, ctx, orig, date, ("Reversal of " + orig.id + (o.reason ? ": " + o.reason : "")).slice(0, 300), { type: "reversal", id: orig.id });
        idemSave(co, o.idemKey, fp, "entry", e.id); return { entry: e, duplicate: false };
      });
    }

    /* ---- contacts / tax codes ---- */
    function saveContact(ctx, o) {
      return mutate(ctx, "contact.manage", function (co) {
        var name = String(o.name || "").trim(); if (!name || name.length > 120) throw err("BAD_NAME");
        if (["customer", "supplier", "both"].indexOf(o.type) < 0) throw err("BAD_TYPE");
        var email = String(o.email || "").trim(); if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw err("BAD_EMAIL");
        var c;
        if (o.id) { c = co.contacts[o.id]; if (!c) throw err("NOT_FOUND"); }
        else {
          var p = planOf(co), n = Object.keys(co.contacts).filter(function (k) { return !co.contacts[k].archived; }).length;
          if (n >= p.contacts) throw err("PLAN_LIMIT", "Contact limit reached", { limit: "contacts", max: p.contacts });
          var cid = newId("ct"); c = co.contacts[cid] = { id: cid, createdAt: nowFn() };
        }
        c.name = name; c.type = o.type; c.email = email; c.phone = String(o.phone || "").trim().slice(0, 40); c.taxId = String(o.taxId || "").trim().slice(0, 40); c.archived = !!o.archived;
        audit(co, ctx, o.id ? "contact.update" : "contact.create", "contact", c.id, name); return c;
      });
    }
    function saveTaxCode(ctx, o) {
      return mutate(ctx, "settings", function (co) {
        var fa = String((o.name && o.name.fa) || "").trim(), en = String((o.name && o.name.en) || "").trim(); if (!fa && !en) throw err("BAD_NAME");
        if (!isInt(o.bps) || o.bps < 0 || o.bps > 10000) throw err("BAD_RATE");
        var id = o.id || newId("T"); if (o.id && !co.taxCodes[o.id]) throw err("NOT_FOUND");
        if (o.id === "T0") throw err("SYSTEM_ACCOUNT");
        co.taxCodes[id] = { id: id, name: { fa: fa || en, en: en || fa }, bps: o.bps }; audit(co, ctx, "tax.save", "tax", id, String(o.bps)); return co.taxCodes[id];
      });
    }

    /* ---- invoices ---- */
    function computeInvoice(co, input) {
      var kind = input.kind; if (kind !== "sale" && kind !== "purchase") throw err("BAD_TYPE");
      var contact = co.contacts[input.contactId]; if (!contact) throw err("CONTACT_NOT_FOUND");
      if (contact.archived) throw err("CONTACT_ARCHIVED");
      if (kind === "sale" && contact.type === "supplier") throw err("CONTACT_TYPE");
      if (kind === "purchase" && contact.type === "customer") throw err("CONTACT_TYPE");
      if (!J.parseIso(input.date)) throw err("BAD_DATE"); if (!J.parseIso(input.dueDate)) throw err("BAD_DATE");
      if (input.dueDate < input.date) throw err("DUE_BEFORE_DATE");
      var cur = input.currency || co.baseCurrency, cdef = co.currencies[cur]; if (!cdef) throw err("BAD_CURRENCY");
      var rate = 1000000;
      if (cur !== co.baseCurrency) { requireFeature(co, "multiCurrency"); rate = input.rate != null ? input.rate : rateFor(co, cur, input.date); if (!isInt(rate) || rate <= 0) throw err("NO_RATE"); }
      if (!Array.isArray(input.lines) || input.lines.length < 1 || input.lines.length > 100) throw err("TOO_FEW_LINES");
      var sub = 0, taxT = 0;
      var lines = input.lines.map(function (l) {
        var desc = String(l.desc || "").trim(); if (!desc || desc.length > 200) throw err("BAD_DESC");
        if (!isInt(l.qty) || l.qty <= 0 || l.qty > 1e9) throw err("BAD_QTY");
        if (!isInt(l.unitPrice) || l.unitPrice < 0) throw err("BAD_AMOUNT");
        var tc = co.taxCodes[l.taxCodeId || "T0"]; if (!tc) throw err("TAX_NOT_FOUND");
        var accId = l.accountId || (kind === "sale" ? co.sys.REVENUE : co.sys.EXPENSE), acc = co.accounts[accId]; if (!acc) throw err("ACCOUNT_NOT_FOUND"); if (!acc.active) throw err("ACCOUNT_INACTIVE");
        if (kind === "sale" && acc.type !== "revenue") throw err("ACCOUNT_TYPE");
        if (kind === "purchase" && acc.type !== "expense" && acc.type !== "asset") throw err("ACCOUNT_TYPE");
        var net = mulDivRound(l.qty, l.unitPrice, 1000), tax = mulDivRound(net, tc.bps, 10000);
        sub += net; taxT += tax; if (sub > MAX || taxT > MAX) throw err("AMOUNT_TOO_LARGE");
        return { desc: desc, qty: l.qty, unitPrice: l.unitPrice, taxCodeId: tc.id, accountId: accId, net: net, tax: tax, total: net + tax };
      });
      if (sub + taxT <= 0) throw err("ZERO_ENTRY");
      return { kind: kind, contactId: input.contactId, date: input.date, dueDate: input.dueDate, currency: cur, rate: rate, lines: lines, subtotal: sub, taxTotal: taxT, total: sub + taxT, notes: String(input.notes || "").slice(0, 500) };
    }
    function saveInvoiceDraft(ctx, input) {
      return mutate(ctx, "doc.manage", function (co) {
        var calc = computeInvoice(co, input), inv;
        var id = input.id || newId("inv");
        if (input.id) { inv = co.invoices[input.id]; if (!inv) throw err("NOT_FOUND"); if (inv.status !== "draft") throw err("NOT_DRAFT"); }
        else inv = co.invoices[id] = {};
        Object.keys(inv).forEach(function (k) { delete inv[k]; });
        Object.assign(inv, calc, { id: id, status: "draft", number: "", entryId: "", baseTotal: 0, createdBy: ctx.uid, createdAt: nowFn() });
        audit(co, ctx, "invoice.draft", "invoice", id, calc.kind); return inv;
      });
    }
    function deleteDraft(ctx, id) {
      return mutate(ctx, "doc.manage", function (co) {
        var inv = co.invoices[id]; if (!inv) throw err("NOT_FOUND"); if (inv.status !== "draft") throw err("NOT_DRAFT");
        delete co.invoices[id]; audit(co, ctx, "invoice.draft.delete", "invoice", id, ""); return true;
      });
    }
    function postInvoice(ctx, id, o) {
      o = o || {};
      return mutate(ctx, "doc.manage", function (co) {
        var inv = co.invoices[id]; if (!inv) throw err("NOT_FOUND");
        var fp = sha256(canon({ k: "postinv", id: id })), prior = idemCheck(co, o.idemKey, fp);
        if (prior) return { invoice: co.invoices[prior.id], duplicate: true };
        if (inv.status !== "draft") throw err("NOT_DRAFT", "Invoice is already posted");
        var calc = computeInvoice(co, inv); /* revalidate against current state */
        var p = planOf(co), m = monthKey(calc.date), n = Object.keys(co.invoices).filter(function (k) { var x = co.invoices[k]; return x.status !== "draft" && x.date.slice(0, 7) === m; }).length;
        if (n >= p.invoicesPerMonth) throw err("PLAN_LIMIT", "Monthly invoice limit reached", { limit: "invoicesPerMonth", max: p.invoicesPerMonth });
        var cdef = co.currencies[calc.currency], bdef = co.currencies[co.baseCurrency], lines = [];
        var grouped = {}; calc.lines.forEach(function (l) { grouped[l.accountId] = (grouped[l.accountId] || 0) + l.net; });
        var taxSum = calc.taxTotal, isSale = calc.kind === "sale", ctl = isSale ? co.sys.AR : co.sys.AP, taxAcc = isSale ? co.sys.TAXOUT : co.sys.TAXIN;
        if (isSale) {
          lines.push({ accountId: ctl, debit: calc.total, credit: 0, contactId: calc.contactId });
          Object.keys(grouped).forEach(function (a) { if (grouped[a] > 0) lines.push({ accountId: a, debit: 0, credit: grouped[a] }); });
          if (taxSum > 0) lines.push({ accountId: taxAcc, debit: 0, credit: taxSum });
        } else {
          Object.keys(grouped).forEach(function (a) { if (grouped[a] > 0) lines.push({ accountId: a, debit: grouped[a], credit: 0 }); });
          if (taxSum > 0) lines.push({ accountId: taxAcc, debit: taxSum, credit: 0 });
          lines.push({ accountId: ctl, debit: 0, credit: calc.total, contactId: calc.contactId });
        }
        var built = buildEntry(co, { date: calc.date, currency: calc.currency, rate: calc.rate, memo: (isSale ? "Sales invoice" : "Purchase bill"), lines: lines }, true);
        var seqKey = isSale ? "sale" : "purchase", number = (isSale ? "INV-" : "BILL-") + String(co.counters[seqKey] + 1).padStart(5, "0");
        built.memo = built.memo + " " + number;
        var e = commitEntry(co, ctx, built, { type: "invoice", id: id });
        co.counters[seqKey] += 1;
        var ctlLine = e.lines.filter(function (l) { return l.accountId === ctl && l.contactId === calc.contactId; })[0];
        inv.status = "posted"; inv.number = number; inv.entryId = e.id; inv.baseTotal = isSale ? ctlLine.baseDebit : ctlLine.baseCredit; inv.rate = calc.rate; inv.postedAt = nowFn();
        audit(co, ctx, "invoice.post", "invoice", id, number);
        idemSave(co, o.idemKey, fp, "invoice", id);
        return { invoice: inv, entry: e, duplicate: false };
      });
    }
    function paidInfo(co, inv, asOf) {
      var paid = 0, relieved = 0;
      Object.keys(co.payments).forEach(function (pid) {
        var p = co.payments[pid]; if (p.status !== "posted" || (asOf && p.date > asOf)) return;
        p.allocations.forEach(function (a) { if (a.invoiceId === inv.id) { paid += a.amount; relieved += a.ctlBase; } });
      });
      return { paid: paid, remaining: inv.total - paid, remainingBase: (inv.baseTotal || 0) - relieved };
    }
    function invoiceStatus(co, inv, today) {
      if (inv.status !== "posted") return inv.status;
      var pi = paidInfo(co, inv); if (pi.remaining <= 0) return "paid";
      if (pi.paid > 0) return inv.dueDate < (today || todayFn()) ? "overdue" : "partial";
      return inv.dueDate < (today || todayFn()) ? "overdue" : "open";
    }
    function voidInvoice(ctx, id, o) {
      o = o || {};
      return mutate(ctx, "doc.manage", function (co) {
        var inv = co.invoices[id]; if (!inv) throw err("NOT_FOUND");
        if (inv.status !== "posted") throw err("NOT_POSTED");
        if (paidInfo(co, inv).paid > 0) throw err("HAS_PAYMENTS", "Void the payments first");
        var orig = entryById(co, inv.entryId), date = o.date || inv.date;
        var e = reverseInternal(co, ctx, orig, date, "Void " + inv.number, { type: "void", id: id });
        inv.status = "void"; inv.voidEntryId = e.id; audit(co, ctx, "invoice.void", "invoice", id, inv.number); return { invoice: inv, entry: e };
      });
    }

    /* ---- payments ---- */
    function postPayment(ctx, input, o) {
      o = o || {};
      return mutate(ctx, "doc.manage", function (co) {
        var fp = sha256(canon({ k: "pay", i: input })), prior = idemCheck(co, o.idemKey, fp);
        if (prior) return { payment: co.payments[prior.id], duplicate: true };
        var kind = input.kind; if (kind !== "receipt" && kind !== "payout") throw err("BAD_TYPE");
        var contact = co.contacts[input.contactId]; if (!contact) throw err("CONTACT_NOT_FOUND");
        if (!J.parseIso(input.date)) throw err("BAD_DATE");
        var bank = co.accounts[input.bankAccountId]; if (!bank || bank.type !== "asset" || !bank.active) throw err("BAD_BANK");
        if (bank.system === "AR" || bank.system === "TAXIN") throw err("BAD_BANK");
        var cur = input.currency || co.baseCurrency, cdef = co.currencies[cur]; if (!cdef) throw err("BAD_CURRENCY");
        var rate = 1000000; if (cur !== co.baseCurrency) { requireFeature(co, "multiCurrency"); rate = input.rate != null ? input.rate : rateFor(co, cur, input.date); if (!isInt(rate) || rate <= 0) throw err("NO_RATE"); }
        if (!isInt(input.amount) || input.amount <= 0) throw err("BAD_AMOUNT");
        if (!Array.isArray(input.allocations) || !input.allocations.length) throw err("NO_ALLOCATION");
        var wantKind = kind === "receipt" ? "sale" : "purchase", seen = {}, sumAlloc = 0, allocs = [];
        input.allocations.forEach(function (a) {
          var inv = co.invoices[a.invoiceId]; if (!inv) throw err("NOT_FOUND");
          if (seen[inv.id]) throw err("DUP_ALLOCATION"); seen[inv.id] = 1;
          if (inv.status !== "posted") throw err("NOT_POSTED"); if (inv.kind !== wantKind) throw err("BAD_TYPE");
          if (inv.contactId !== input.contactId) throw err("CONTACT_MISMATCH");
          if (inv.currency !== cur) throw err("CURRENCY_MISMATCH");
          if (!isInt(a.amount) || a.amount <= 0) throw err("BAD_AMOUNT");
          var pi = paidInfo(co, inv); if (a.amount > pi.remaining) throw err("OVERPAY", "Allocation exceeds the open balance", { invoice: inv.number, remaining: pi.remaining });
          var ctlBase = a.amount === pi.remaining ? pi.remainingBase : mulDivRound(pi.remainingBase, a.amount, pi.remaining);
          sumAlloc += a.amount; allocs.push({ invoiceId: inv.id, amount: a.amount, ctlBase: ctlBase });
        });
        if (sumAlloc !== input.amount) throw err("ALLOC_MISMATCH", "Allocations must add up to the payment amount", { amount: input.amount, allocated: sumAlloc });
        var bdef = co.currencies[co.baseCurrency], bankBase = toBase(input.amount, cdef.decimals, bdef.decimals, rate), ctlBaseSum = allocs.reduce(function (s, a) { return s + a.ctlBase; }, 0);
        var isR = kind === "receipt", ctl = isR ? co.sys.AR : co.sys.AP, lines = [];
        if (isR) {
          lines.push({ accountId: bank.id, debit: input.amount, credit: 0, base: { debit: bankBase, credit: 0 } });
          lines.push({ accountId: ctl, debit: 0, credit: input.amount, base: { debit: 0, credit: ctlBaseSum }, contactId: input.contactId });
        } else {
          lines.push({ accountId: ctl, debit: input.amount, credit: 0, base: { debit: ctlBaseSum, credit: 0 }, contactId: input.contactId });
          lines.push({ accountId: bank.id, debit: 0, credit: input.amount, base: { debit: 0, credit: bankBase } });
        }
        var fx = isR ? bankBase - ctlBaseSum : ctlBaseSum - bankBase; /* >0 gain */
        if (fx !== 0) lines.push({ accountId: co.sys.FX, debit: 0, credit: 0, baseOnly: true, base: { debit: fx < 0 ? -fx : 0, credit: fx > 0 ? fx : 0 } });
        var built = buildEntry(co, { date: input.date, currency: cur, rate: rate, memo: (isR ? "Receipt " : "Payment ") + (input.ref || ""), lines: lines }, true);
        var e = commitEntry(co, ctx, built, { type: "payment", id: "" });
        var seqKey = isR ? "receipt" : "payout"; co.counters[seqKey] += 1;
        var pid = newId("pay"), number = (isR ? "RCT-" : "PAY-") + String(co.counters[seqKey]).padStart(5, "0");
        co.payments[pid] = { id: pid, number: number, kind: kind, contactId: input.contactId, date: input.date, currency: cur, rate: rate, amount: input.amount, bankAccountId: bank.id, allocations: allocs, ref: String(input.ref || "").slice(0, 100), status: "posted", entryId: e.id, createdBy: ctx.uid, createdAt: nowFn() };
        audit(co, ctx, "payment.post", "payment", pid, number);
        idemSave(co, o.idemKey, fp, "payment", pid);
        return { payment: co.payments[pid], entry: e, duplicate: false };
      });
    }
    function voidPayment(ctx, id, o) {
      o = o || {};
      return mutate(ctx, "doc.manage", function (co) {
        var p = co.payments[id]; if (!p) throw err("NOT_FOUND"); if (p.status !== "posted") throw err("NOT_POSTED");
        var orig = entryById(co, p.entryId), e = reverseInternal(co, ctx, orig, o.date || p.date, "Void " + p.number, { type: "void", id: id });
        p.status = "void"; p.voidEntryId = e.id; audit(co, ctx, "payment.void", "payment", id, p.number); return { payment: p, entry: e };
      });
    }

    /* ---- fiscal year closing ---- */
    function closeFiscalYear(ctx, year) {
      return mutate(ctx, "period.close", function (co) {
        ensureYearInternal(co, year);
        var ps = Object.keys(co.periods).map(function (k) { return co.periods[k]; }).filter(function (p) { return p.year === year; }).sort(function (a, b) { return a.month - b.month; });
        if (ps.every(function (p) { return p.status === "closed"; })) throw err("YEAR_CLOSED");
        var end = ps[11].end, bal = balances(co, { to: end }), lines = [], net = 0;
        Object.keys(co.accounts).forEach(function (id) {
          var a = co.accounts[id]; if (a.type !== "revenue" && a.type !== "expense") return;
          var b = bal[id] || { debit: 0, credit: 0 }, v = b.debit - b.credit; if (v === 0) return;
          if (v > 0) lines.push({ accountId: id, debit: 0, credit: 0, baseOnly: true, base: { debit: 0, credit: v } }); else lines.push({ accountId: id, debit: 0, credit: 0, baseOnly: true, base: { debit: -v, credit: 0 } });
          net -= v;
        });
        var e = null;
        if (lines.length) {
          if (net > 0) lines.push({ accountId: co.sys.RE, debit: 0, credit: 0, baseOnly: true, base: { debit: 0, credit: net } });
          else if (net < 0) lines.push({ accountId: co.sys.RE, debit: 0, credit: 0, baseOnly: true, base: { debit: -net, credit: 0 } });
          var built = buildEntry(co, { date: end, memo: "Closing entry " + year, lines: lines }, true);
          e = commitEntry(co, ctx, built, { type: "closing", id: String(year) });
        }
        ps.forEach(function (p) { p.status = "closed"; });
        audit(co, ctx, "year.close", "period", String(year), net + ""); return { entry: e, netIncome: net };
      });
    }

    /* ---- members ---- */
    function addMember(ctx, userId, role) {
      return mutate(ctx, "members.manage", function (co) {
        if (!S.users[userId]) throw err("NO_USER"); if (co.members[userId]) throw err("ALREADY_MEMBER");
        if (ROLES.indexOf(role) < 0) throw err("BAD_ROLE");
        var me = roleOf(ctx); if (ROLE_RANK[role] >= ROLE_RANK[me] && me !== "owner") throw err("FORBIDDEN", "Cannot grant a role equal to or above your own");
        var p = planOf(co); if (p.roles.indexOf(role) < 0) throw err("PLAN_FEATURE", "Role not available on your plan", { feature: "role:" + role, plan: effectivePlan(co) });
        if (Object.keys(co.members).length >= p.members) throw err("PLAN_LIMIT", "Member limit reached", { limit: "members", max: p.members });
        co.members[userId] = { uid: userId, role: role, addedAt: nowFn() }; audit(co, ctx, "member.add", "member", userId, role); return true;
      });
    }
    function setMemberRole(ctx, userId, role) {
      return mutate(ctx, "members.manage", function (co) {
        var m = co.members[userId]; if (!m) throw err("NOT_FOUND"); if (ROLES.indexOf(role) < 0) throw err("BAD_ROLE");
        if (userId === ctx.uid) throw err("FORBIDDEN", "You cannot change your own role");
        var me = roleOf(ctx);
        if (me !== "owner") { if (ROLE_RANK[m.role] >= ROLE_RANK[me] || ROLE_RANK[role] >= ROLE_RANK[me]) throw err("FORBIDDEN", "Insufficient privileges"); }
        if (m.role === "owner" && Object.keys(co.members).filter(function (k) { return co.members[k].role === "owner"; }).length < 2) throw err("LAST_OWNER");
        var p = planOf(co); if (p.roles.indexOf(role) < 0 && role !== m.role) throw err("PLAN_FEATURE", "Role not available on your plan", { feature: "role:" + role });
        m.role = role; audit(co, ctx, "member.role", "member", userId, role); return true;
      });
    }
    function removeMember(ctx, userId) {
      return mutate(ctx, "members.manage", function (co) {
        var m = co.members[userId]; if (!m) throw err("NOT_FOUND");
        var me = roleOf(ctx); if (me !== "owner" && ROLE_RANK[m.role] >= ROLE_RANK[me]) throw err("FORBIDDEN");
        if (m.role === "owner" && Object.keys(co.members).filter(function (k) { return co.members[k].role === "owner"; }).length < 2) throw err("LAST_OWNER");
        delete co.members[userId]; audit(co, ctx, "member.remove", "member", userId, ""); return true;
      });
    }

    /* ---- billing (webhook-style, signature-verified) ---- */
    function handleBillingEvent(cid, rawBody, signatureHex, secret) {
      var co = S.companies[cid]; if (!co) throw err("NO_COMPANY");
      var expected = hmacSha256(secret, rawBody);
      if (!safeEqual(expected, String(signatureHex || "").toLowerCase())) return { ok: false, reason: "bad_signature" };
      var ev; try { ev = JSON.parse(rawBody); } catch (e) { return { ok: false, reason: "bad_payload" }; }
      if (!ev || typeof ev.id !== "string" || typeof ev.type !== "string" || !isInt(ev.created)) return { ok: false, reason: "bad_payload" };
      if (co.billingEvents[ev.id]) return { ok: true, ignored: "duplicate" };
      if (ev.created < co.sub.lastEventAt) { co.billingEvents[ev.id] = { at: nowFn(), ignored: true }; save(); return { ok: true, ignored: "stale" }; }
      var d = ev.data || {}, s = co.sub, sys = { uid: "billing" };
      if ((ev.type === "invoice.paid" || ev.type === "subscription.updated") && !PLANS[d.plan]) return { ok: false, reason: "bad_payload" };
      if (ev.type === "invoice.paid") { s.plan = d.plan; s.status = "active"; s.periodEnd = d.periodEnd; s.pending = null; }
      else if (ev.type === "invoice.payment_failed") { s.status = "past_due"; }
      else if (ev.type === "subscription.canceled") { s.status = "canceled"; }
      else if (ev.type === "subscription.updated") {
        if (PLAN_RANK[d.plan] < PLAN_RANK[s.plan] && s.periodEnd && nowFn() < s.periodEnd) s.pending = { plan: d.plan, at: s.periodEnd };
        else { s.plan = d.plan; s.pending = null; }
      } else return { ok: false, reason: "unknown_type" };
      s.lastEventAt = ev.created; co.billingEvents[ev.id] = { at: nowFn(), type: ev.type };
      audit(co, sys, "billing." + ev.type, "subscription", ev.id, s.plan + "/" + s.status);
      save(); return { ok: true };
    }

    /* ───────────── reports ───────────── */
    function balances(co, range, onlyIds) {
      var out = {}, from = range && range.from, to = range && range.to, excludeClosing = range && range.excludeClosing;
      for (var i = 0; i < co.entries.length; i++) {
        var e = co.entries[i]; if ((from && e.date < from) || (to && e.date > to)) continue;
        if (excludeClosing && e.source.type === "closing") continue;
        for (var j = 0; j < e.lines.length; j++) {
          var l = e.lines[j]; if (onlyIds && onlyIds.indexOf(l.accountId) < 0) continue;
          var b = out[l.accountId] || (out[l.accountId] = { debit: 0, credit: 0 }); b.debit += l.baseDebit; b.credit += l.baseCredit;
        }
      }
      return out;
    }
    function sortedAccounts(co) { return Object.keys(co.accounts).map(function (k) { return co.accounts[k]; }).sort(function (a, b) { return a.code < b.code ? -1 : a.code > b.code ? 1 : 0; }); }
    function trialBalance(ctx, asOf) {
      var co = access(ctx, "report"); requireReport(co, "tb");
      var bal = balances(co, { to: asOf }), rows = [], td = 0, tc = 0;
      sortedAccounts(co).forEach(function (a) {
        var b = bal[a.id]; if (!b) return;
        var net = b.debit - b.credit; if (net === 0) return;
        var dr = net > 0 ? net : 0, cr = net < 0 ? -net : 0; td += dr; tc += cr;
        rows.push({ account: a, debit: dr, credit: cr, periodDebit: b.debit, periodCredit: b.credit });
      });
      return { rows: rows, totalDebit: td, totalCredit: tc, balanced: td === tc };
    }
    function generalLedger(ctx, accountId, from, to) {
      var co = access(ctx, "report"); requireReport(co, "gl");
      var acc = co.accounts[accountId]; if (!acc) throw err("NOT_FOUND");
      var open = balances(co, { to: from ? J.addDaysIso(from, -1) : "0000-01-01" }, [accountId])[accountId] || { debit: 0, credit: 0 };
      var sign = DEBIT_NORMAL[acc.type] ? 1 : -1, running = sign * (open.debit - open.credit), opening = running, rows = [], td = 0, tc = 0;
      co.entries.forEach(function (e) {
        if ((from && e.date < from) || (to && e.date > to)) return;
        e.lines.forEach(function (l) {
          if (l.accountId !== accountId) return;
          running += sign * (l.baseDebit - l.baseCredit); td += l.baseDebit; tc += l.baseCredit;
          rows.push({ date: e.date, entryId: e.id, seq: e.seq, memo: e.memo + (l.memo ? " · " + l.memo : ""), debit: l.baseDebit, credit: l.baseCredit, balance: running, contactId: l.contactId || "" });
        });
      });
      rows.sort(function (a, b) { return a.date < b.date ? -1 : a.date > b.date ? 1 : a.seq - b.seq; });
      var r = opening; rows.forEach(function (x) { r += sign * (x.debit - x.credit); x.balance = r; });
      return { account: acc, opening: opening, rows: rows, totalDebit: td, totalCredit: tc, closing: r };
    }
    function profitLoss(ctx, from, to) {
      var co = access(ctx, "report"); requireReport(co, "pl");
      var bal = balances(co, { from: from, to: to, excludeClosing: true }), rev = [], exp = [], tr = 0, te = 0;
      sortedAccounts(co).forEach(function (a) {
        var b = bal[a.id]; if (!b) return;
        if (a.type === "revenue") { var v = b.credit - b.debit; if (v !== 0) { rev.push({ account: a, amount: v }); tr += v; } }
        else if (a.type === "expense") { var w = b.debit - b.credit; if (w !== 0) { exp.push({ account: a, amount: w }); te += w; } }
      });
      return { revenue: rev, expenses: exp, totalRevenue: tr, totalExpenses: te, netIncome: tr - te };
    }
    function balanceSheet(ctx, asOf) {
      var co = access(ctx, "report"); requireReport(co, "bs");
      var bal = balances(co, { to: asOf }), A = [], L = [], E = [], ta = 0, tl = 0, te = 0, earn = 0;
      sortedAccounts(co).forEach(function (a) {
        var b = bal[a.id]; if (!b) return; var net = b.debit - b.credit;
        if (a.type === "asset") { if (net !== 0) { A.push({ account: a, amount: net }); ta += net; } }
        else if (a.type === "liability") { if (net !== 0) { L.push({ account: a, amount: -net }); tl += -net; } }
        else if (a.type === "equity") { if (net !== 0) { E.push({ account: a, amount: -net }); te += -net; } }
        else earn += -net;
      });
      return { assets: A, liabilities: L, equity: E, currentEarnings: earn, totalAssets: ta, totalLiabilities: tl, totalEquity: te + earn, balanced: ta === tl + te + earn };
    }
    function aging(ctx, kind, asOf) {
      var co = access(ctx, "report"); requireReport(co, kind === "sale" ? "ar" : "ap");
      var rows = [], buckets = { current: 0, d30: 0, d60: 0, d90: 0, d90p: 0 }, total = 0;
      Object.keys(co.invoices).forEach(function (k) {
        var inv = co.invoices[k]; if (inv.kind !== kind || inv.status !== "posted" || inv.date > asOf) return;
        var pi = paidInfo(co, inv, asOf); if (pi.remaining <= 0) return;
        var days = J.diffDaysIso(inv.dueDate, asOf), b = days <= 0 ? "current" : days <= 30 ? "d30" : days <= 60 ? "d60" : days <= 90 ? "d90" : "d90p";
        buckets[b] += pi.remainingBase; total += pi.remainingBase;
        rows.push({ invoice: inv, contactId: inv.contactId, remaining: pi.remaining, remainingBase: pi.remainingBase, daysOverdue: Math.max(0, days), bucket: b });
      });
      rows.sort(function (a, b) { return b.daysOverdue - a.daysOverdue; });
      return { rows: rows, buckets: buckets, total: total };
    }
    function kpis(ctx) {
      var co = access(ctx, "view"), bal = balances(co, {}), g = function (sys) { var b = bal[co.sys[sys]] || { debit: 0, credit: 0 }; return b; };
      var today = todayFn(), fy = fiscalYearOf(co, today), ps = Object.keys(co.periods).map(function (k) { return co.periods[k]; }).filter(function (p) { return p.year === fy; }).sort(function (a, b) { return a.month - b.month; });
      var from = ps.length ? ps[0].start : today.slice(0, 4) + "-01-01", to = ps.length ? ps[ps.length - 1].end : today.slice(0, 4) + "-12-31";
      var pl = balances(co, { from: from, to: to, excludeClosing: true }), rev = 0, exp = 0;
      Object.keys(co.accounts).forEach(function (id) { var a = co.accounts[id], b = pl[id]; if (!b) return; if (a.type === "revenue") rev += b.credit - b.debit; else if (a.type === "expense") exp += b.debit - b.credit; });
      var cash = 0; Object.keys(co.accounts).forEach(function (id) { var a = co.accounts[id]; if (a.type === "asset" && a.system === "BANK") { var b = bal[id] || { debit: 0, credit: 0 }; cash += b.debit - b.credit; } });
      return { cash: cash, receivable: g("AR").debit - g("AR").credit, payable: g("AP").credit - g("AP").debit, revenue: rev, expenses: exp, net: rev - exp, entries: co.entries.length, year: fy };
    }

    /* ───────────── integrity ───────────── */
    function verifyCompany(co) {
      var errors = [], prev = "";
      co.entries.forEach(function (e, i) {
        var core = clone(e); delete core.hash; delete core.prevHash;
        if (e.prevHash !== prev) errors.push("entry " + e.id + ": broken chain");
        if (sha256(prev + canon(core)) !== e.hash) errors.push("entry " + e.id + ": content hash mismatch");
        var td = 0, tc = 0, bd = 0, bc = 0; e.lines.forEach(function (l) { td += l.debit; tc += l.credit; bd += l.baseDebit; bc += l.baseCredit; });
        if (td !== tc) errors.push("entry " + e.id + ": unbalanced"); if (bd !== bc) errors.push("entry " + e.id + ": base unbalanced");
        if (e.seq !== i + 1) errors.push("entry " + e.id + ": sequence gap");
        prev = e.hash;
      });
      if (co.counters.entry !== co.entries.length) errors.push("entry counter mismatch");
      var ap = "";
      co.audit.forEach(function (a) {
        if (a.prev !== ap) errors.push("audit #" + a.seq + ": broken chain");
        if (sha256(a.prev + canon({ seq: a.seq, ts: a.ts, uid: a.uid, action: a.action, entity: a.entity, id: a.id, detail: a.detail })) !== a.hash) errors.push("audit #" + a.seq + ": hash mismatch");
        ap = a.hash;
      });
      /* documents must agree with the ledger */
      Object.keys(co.invoices).forEach(function (k) { var inv = co.invoices[k]; if (inv.status === "draft") return; var e = entryById(co, inv.entryId); if (!e) errors.push("invoice " + inv.number + ": missing entry"); });
      return { ok: errors.length === 0, errors: errors };
    }
    function verifyIntegrity(ctx) { return verifyCompany(access(ctx, "view")); }

    /* ───────────── backup / restore ───────────── */
    function b64(bytes) { var s = ""; for (var i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]); return (typeof btoa === "function" ? btoa(s) : Buffer.from(s, "binary").toString("base64")); }
    function unb64(str) { var s = (typeof atob === "function" ? atob(str) : Buffer.from(str, "base64").toString("binary")), o = new Uint8Array(s.length); for (var i = 0; i < s.length; i++) o[i] = s.charCodeAt(i); return o; }
    function subtle() { return (root.crypto && root.crypto.subtle) || require("crypto").webcrypto.subtle; }
    function rnd(n) { var u = new Uint8Array(n); (root.crypto || require("crypto").webcrypto).getRandomValues(u); return u; }
    async function deriveKey(pass, salt, iter) {
      var s = subtle(), km = await s.importKey("raw", new TextEncoder().encode(pass), "PBKDF2", false, ["deriveKey"]);
      return s.deriveKey({ name: "PBKDF2", hash: "SHA-256", salt: salt, iterations: iter }, km, { name: "AES-GCM", length: 256 }, false, ["encrypt", "decrypt"]);
    }
    var PBKDF2_ITER = 310000;
    async function exportBackup(ctx, o) {
      o = o || {};
      var co = access(ctx, "backup");
      if (o.passphrase) requireFeature(co, "encryptedBackup");
      var data = clone(co), body = canon(data);
      var env = { format: "acconova-backup", version: 1, createdAt: nowFn(), company: co.name, sha256: sha256(body), data: data };
      var plain = JSON.stringify(env);
      if (!o.passphrase) return plain;
      if (String(o.passphrase).length < 8) throw err("WEAK_PASSPHRASE");
      var salt = rnd(16), iv = rnd(12), key = await deriveKey(o.passphrase, salt, PBKDF2_ITER);
      var ct = new Uint8Array(await subtle().encrypt({ name: "AES-GCM", iv: iv }, key, new TextEncoder().encode(plain)));
      return JSON.stringify({ format: "acconova-backup-encrypted", version: 1, kdf: "PBKDF2-SHA256", iter: PBKDF2_ITER, cipher: "AES-256-GCM", salt: b64(salt), iv: b64(iv), ct: b64(ct) });
    }
    async function importBackup(uid, text, passphrase) {
      if (!S.users[uid]) throw err("NO_USER");
      var env; try { env = JSON.parse(text); } catch (e) { throw err("BAD_BACKUP"); }
      if (env && env.format === "acconova-backup-encrypted") {
        if (!passphrase) throw err("PASSPHRASE_REQUIRED");
        var iter = env.iter; if (!isInt(iter) || iter < 100000 || iter > 5000000) throw err("BAD_BACKUP");
        try { var key = await deriveKey(passphrase, unb64(env.salt), iter); var pt = await subtle().decrypt({ name: "AES-GCM", iv: unb64(env.iv) }, key, unb64(env.ct)); env = JSON.parse(new TextDecoder().decode(pt)); }
        catch (e) { throw err("WRONG_PASSPHRASE"); }
      }
      if (!env || env.format !== "acconova-backup" || env.version !== 1 || !env.data) throw err("BAD_BACKUP");
      if (sha256(canon(env.data)) !== env.sha256) throw err("BACKUP_TAMPERED");
      var co = env.data;
      if (!co.entries || !co.accounts || !co.members || !co.counters || !co.sub) throw err("BAD_BACKUP");
      var v = verifyCompany(co); if (!v.ok) throw err("BACKUP_INTEGRITY", "Integrity check failed", { errors: v.errors.slice(0, 5) });
      var oldId = co.id, nid = newId("c"); co.id = nid; co.name = co.name + " (restored)";
      co.members = {}; co.members[uid] = { uid: uid, role: "owner", addedAt: nowFn() };
      co.sub = { plan: "free", status: "active", periodEnd: null, graceDays: 7, lastEventAt: 0, pending: null }; co.billingEvents = {}; /* a subscription belongs to billing, never to a backup file */
      co.entries.forEach(deepFreeze);
      S.companies[nid] = co; audit(co, { uid: uid }, "company.restore", "company", nid, "from " + oldId); S.session = { uid: uid, cid: nid }; save(); return nid;
    }
    function exportPlain(ctx) { return exportBackup(ctx, {}); }

    return {
      state: function () { return S; }, save: save, sizeChars: function () { return lastSaved.length; }, serialize: serialize, today: todayFn, now: nowFn,
      setSession: function (uid, cid) { S.session = { uid: uid || null, cid: cid || null }; save(); }, session: function () { return S.session; },
      users: function () { return S.users; }, createUser: createUser, createCompany: createCompany, listCompaniesFor: listCompaniesFor, deleteCompany: deleteCompany,
      company: company, can: can, roleOf: roleOf, effectivePlan: effectivePlan, planOf: planOf, usage: usage,
      ensureFiscalYear: ensureFiscalYear, setPeriodStatus: setPeriodStatus, closeFiscalYear: closeFiscalYear, currentFiscalYear: currentFiscalYear, fiscalYearOf: fiscalYearOf,
      addCurrency: addCurrency, setRate: setRate, rateFor: rateFor,
      addAccount: addAccount, renameAccount: renameAccount, setAccountActive: setAccountActive,
      postEntry: postEntry, reverseEntry: reverseEntry, entryById: entryById,
      saveContact: saveContact, saveTaxCode: saveTaxCode,
      saveInvoiceDraft: saveInvoiceDraft, deleteDraft: deleteDraft, postInvoice: postInvoice, voidInvoice: voidInvoice, invoiceStatus: invoiceStatus, paidInfo: paidInfo,
      postPayment: postPayment, voidPayment: voidPayment,
      addMember: addMember, setMemberRole: setMemberRole, removeMember: removeMember,
      handleBillingEvent: handleBillingEvent,
      accountBalances: function (ctx) { return balances(access(ctx, "view"), {}); }, trialBalance: trialBalance, generalLedger: generalLedger, profitLoss: profitLoss, balanceSheet: balanceSheet, aging: aging, kpis: kpis,
      verifyIntegrity: verifyIntegrity, exportBackup: exportBackup, importBackup: importBackup, exportPlain: exportPlain,
      _raw: function () { return S; }, _reload: load
    };
  }

  /* ───────────────────────── CSV ───────────────────────── */
  function csvCell(v) {
    if (v == null) return "";
    var s = String(v);
    if (typeof v === "string" && /^[=+\-@\t\r]/.test(s)) s = "'" + s; /* spreadsheet formula injection guard */
    if (/[",\n\r]/.test(s)) s = '"' + s.replace(/"/g, '""') + '"';
    return s;
  }
  function toCsv(rows, bom) { return (bom ? "﻿" : "") + rows.map(function (r) { return r.map(csvCell).join(","); }).join("\r\n") + "\r\n"; }

  var API = {
    createStore: createStore, memoryStorage: memoryStorage, sha256: sha256, hmacSha256: hmacSha256, canon: canon, safeEqual: safeEqual,
    parseMoney: parseMoney, formatMinor: formatMinor, mulDivRound: mulDivRound, toBase: toBase, digitsToLatin: digitsToLatin,
    toCsv: toCsv, csvCell: csvCell, PLANS: PLANS, PLAN_RANK: PLAN_RANK, PERMS: PERMS, ROLES: ROLES, CURRENCIES: CURRENCIES, TYPES: TYPES, DEBIT_NORMAL: DEBIT_NORMAL, ALL_REPORTS: ALL_REPORTS, newId: newId
  };
  if (typeof module === "object" && module.exports) module.exports = API; else root.AN = API;
})(typeof globalThis !== "undefined" ? globalThis : this);
