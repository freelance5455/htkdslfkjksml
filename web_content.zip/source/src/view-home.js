/* Home: clock, Jalali/Gregorian calendar, KPIs, receivables watch-list. */
(function (root) {
  "use strict";
  var UI = root.AN_UI, h = UI.h, t = UI.t, F = UI.fmt, J = root.AN_J, AN = root.AN;
  var TZS = [["", "tz_device"], ["Asia/Tehran", "tz_tehran"], ["Asia/Kabul", "tz_kabul"], ["Asia/Dubai", "tz_dubai"], ["Europe/Istanbul", "tz_istanbul"], ["UTC", "tz_utc"], ["Europe/London", "tz_london"], ["Europe/Berlin", "tz_berlin"], ["America/New_York", "tz_ny"], ["America/Los_Angeles", "tz_la"], ["Asia/Kolkata", "tz_india"], ["Asia/Tokyo", "tz_tokyo"]];
  var FA_DOW = ["ش", "ی", "د", "س", "چ", "پ", "ج"], EN_DOW = ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"];
  function lsGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function lsSet(k, v) { try { localStorage.setItem(k, v); } catch (e) { } }

  UI.views.home = function (box) {
    var clk = { tz: lsGet("acconova.tz") || "", h12: lsGet("acconova.h12") === "1" };
    try { new Intl.DateTimeFormat("en", { timeZone: clk.tz || undefined }); } catch (e) { clk.tz = ""; }
    var fa = UI.isFa();

    function dtf(loc, o) { var x = {}; for (var k in o) x[k] = o[k]; if (clk.tz) x.timeZone = clk.tz; return new Intl.DateTimeFormat(loc, x); }
    function parts(f, d) { var o = {}; f.formatToParts(d).forEach(function (p) { o[p.type] = p.value; }); return o; }
    function todayParts(ms) { var p = parts(dtf("en-US-u-ca-gregory-nu-latn", { year: "numeric", month: "numeric", day: "numeric" }), new Date(ms)); return { y: +p.year, m: +p.month, d: +p.day }; }
    function hms(ms) { var p = parts(dtf("en-US-u-nu-latn", { hour: "numeric", minute: "numeric", second: "numeric", hourCycle: "h23" }), new Date(ms)); return { h: (+p.hour) % 24, m: +p.minute, s: +p.second }; }

    /* ── clock card ── */
    var ticks = [];
    for (var i = 0; i < 60; i++) {
      var big = i % 5 === 0, a = i * 6 * Math.PI / 180, r1 = big ? 78 : 84, r2 = 90;
      ticks.push('<line class="tick' + (big ? " big" : "") + '" x1="' + (100 + Math.sin(a) * r1).toFixed(2) + '" y1="' + (100 - Math.cos(a) * r1).toFixed(2) + '" x2="' + (100 + Math.sin(a) * r2).toFixed(2) + '" y2="' + (100 - Math.cos(a) * r2).toFixed(2) + '"/>');
    }
    var svg = h("div", { class: "analog-wrap", html: '<svg class="analog" viewBox="0 0 200 200" role="img" aria-label="' + t("analogClock") + '"><circle class="face" cx="100" cy="100" r="94"/>' + ticks.join("") + '<line class="hh" id="hh" x1="100" y1="100" x2="100" y2="58"/><line class="mh" id="mh" x1="100" y1="100" x2="100" y2="38"/><line class="sh" id="sh" x1="100" y1="112" x2="100" y2="30"/><circle class="pin" cx="100" cy="100" r="5"/></svg>' });
    var digital = h("div", { class: "digital", "aria-hidden": "true" }), dMain = h("div", { class: "date-main" }), dSub1 = h("div", { class: "muted" }), dSub2 = h("div", { class: "muted" }), tzInfo = h("div", { class: "muted small" });
    var tzSel = UI.select(TZS.map(function (z) { return { value: z[0], label: t(z[1]) }; }), clk.tz, function () { clk.tz = tzSel.value; lsSet("acconova.tz", clk.tz); lastDay = ""; paint(); });
    var fmtBtn = h("button", { class: "mini", type: "button", "aria-pressed": clk.h12 ? "true" : "false", onclick: function () { clk.h12 = !clk.h12; lsSet("acconova.h12", clk.h12 ? "1" : "0"); fmtBtn.textContent = clk.h12 ? t("h12") : t("h24"); fmtBtn.setAttribute("aria-pressed", clk.h12 ? "true" : "false"); paint(); } }, clk.h12 ? t("h12") : t("h24"));
    var clockCard = h("section", { class: "card clock-card" }, h("h2", { text: t("clockTitle") }),
      h("div", { class: "clock-grid" }, svg, h("div", {}, digital, dMain, dSub1, dSub2, h("div", { class: "tz-row" }, h("label", { class: "muted", text: t("tzLabel") }), tzSel, fmtBtn), tzInfo)));

    /* ── calendar card ── */
    var cal = { y: 0, m: 0 }, grid = h("div", { class: "cal", role: "grid" }), title = h("button", { class: "cal-title", type: "button", onclick: function () { resetCal(); renderCal(); } });
    var prev = h("button", { class: "nav", type: "button", "aria-label": t("prevMonth"), onclick: function () { shift(-1); } }, fa ? "›" : "‹");
    var next = h("button", { class: "nav", type: "button", "aria-label": t("nextMonth"), onclick: function () { shift(1); } }, fa ? "‹" : "›");
    function nowParts() { return todayParts(Date.now()); }
    function resetCal() { var g = nowParts(); if (fa) { var j = J.toJalali(g.y, g.m, g.d); cal.y = j.y; cal.m = j.m; } else { cal.y = g.y; cal.m = g.m; } }
    function shift(d) { cal.m += d; if (cal.m < 1) { cal.m = 12; cal.y--; } if (cal.m > 12) { cal.m = 1; cal.y++; } renderCal(); }
    function renderCal() {
      UI.clear(grid); var tp = nowParts(), len, first, lead, dows;
      if (fa) {
        len = J.jalaliMonthLength(cal.y, cal.m); first = J.toGregorian(cal.y, cal.m, 1);
        lead = (new Date(Date.UTC(first.y, first.m - 1, first.d)).getUTCDay() + 1) % 7; dows = FA_DOW;
        title.textContent = UI.monthName("jalali", cal.m) + " " + F.int(cal.y);
      } else {
        len = J.gregorianMonthLength(cal.y, cal.m); lead = (new Date(Date.UTC(cal.y, cal.m - 1, 1)).getUTCDay() + 6) % 7; dows = EN_DOW;
        title.textContent = UI.monthName("gregorian", cal.m) + " " + F.int(cal.y);
      }
      dows.forEach(function (n, i) { grid.appendChild(h("div", { class: "dow" + (fa ? (i === 6 ? " hol" : "") : (i >= 5 ? " hol" : "")), role: "columnheader", text: n })); });
      for (var e = 0; e < lead; e++) grid.appendChild(h("div", { class: "d e", "aria-hidden": "true" }));
      for (var d = 1; d <= len; d++) {
        var g = fa ? J.toGregorian(cal.y, cal.m, d) : { y: cal.y, m: cal.m, d: d }, other = fa ? g.d : J.toJalali(g.y, g.m, g.d).d;
        var wd = new Date(Date.UTC(g.y, g.m - 1, g.d)).getUTCDay(), hol = fa ? wd === 5 : (wd === 0 || wd === 6);
        var isToday = g.y === tp.y && g.m === tp.m && g.d === tp.d;
        grid.appendChild(h("div", { class: "d" + (hol ? " hol" : "") + (isToday ? " today" : ""), role: "gridcell", "aria-current": isToday ? "date" : null }, h("b", { text: F.int(d) }), h("small", { text: F.int(other) })));
      }
    }
    var calCard = h("section", { class: "card" }, h("div", { class: "cal-head" }, prev, title, next), grid, h("div", { class: "muted small mt", text: t("calNote") }));

    /* ── ticking ── */
    var lastDay = "";
    function composeDate(ms, loc, wk) { var p = parts(dtf(loc, { weekday: "long", day: "numeric", month: "long", year: "numeric" }), new Date(ms)); return (wk && p.weekday ? p.weekday + (fa ? "، " : ", ") : "") + p.day + " " + p.month + " " + p.year; }
    function paint() {
      var ms = Date.now(), x = hms(ms);
      digital.textContent = dtf(UI.locale(), { hour: "2-digit", minute: "2-digit", second: "2-digit", hourCycle: clk.h12 ? "h12" : "h23" }).format(ms);
      var s = svg.querySelector("#sh"), m = svg.querySelector("#mh"), hh = svg.querySelector("#hh");
      s.setAttribute("transform", "rotate(" + (x.s * 6) + " 100 100)"); m.setAttribute("transform", "rotate(" + (x.m * 6 + x.s * .1).toFixed(2) + " 100 100)"); hh.setAttribute("transform", "rotate(" + ((x.h % 12) * 30 + x.m * .5).toFixed(2) + " 100 100)");
      var tp = todayParts(ms), key = tp.y + "-" + tp.m + "-" + tp.d + clk.tz;
      if (key !== lastDay) {
        lastDay = key; var j = J.toJalali(tp.y, tp.m, tp.d), wk = new Date(Date.UTC(tp.y, tp.m - 1, tp.d)).getUTCDay();
        var FA_WK = ["یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه"], EN_WK = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
        if (fa) {
          dMain.textContent = FA_WK[wk] + "، " + F.int(j.d) + " " + UI.monthName("jalali", j.m) + " " + F.int(j.y);
          dSub1.textContent = t("gregorianLbl") + ": " + composeDate(ms, "fa-IR-u-ca-gregory", false) + "  ·  " + composeDate(ms, "en-US-u-ca-gregory", false);
          dSub2.textContent = "";
        } else {
          dMain.textContent = composeDate(ms, "en-US-u-ca-gregory", true);
          dSub1.textContent = t("persianLbl") + ": " + F.int(j.d) + " " + UI.monthName("jalali", j.m) + " " + F.int(j.y);
          dSub2.textContent = "ISO: " + J.isoFrom(tp.y, tp.m, tp.d);
        }
        var zone = clk.tz || (Intl.DateTimeFormat().resolvedOptions().timeZone || ""), off = "";
        try { off = parts(dtf(UI.locale(), { timeZoneName: "longOffset" }), new Date(ms)).timeZoneName || ""; } catch (e) { }
        tzInfo.textContent = zone + (off ? "  (" + off + ")" : "");
        resetCal(); renderCal();
      }
    }
    function loop() { paint(); UI.timers.push(setTimeout(loop, 1000 - (Date.now() % 1000) + 8)); }

    /* ── KPIs ── */
    var co = UI.co(), k = UI.store.kpis(UI.ctx);
    function kpi(label, minor, cls, tab) { return h("button", { class: "kpi " + (cls || ""), type: "button", onclick: function () { if (tab) UI.go(tab); } }, h("span", { class: "kpi-l", text: label }), h("span", { class: "kpi-v" }, UI.amount(minor, co.baseCurrency))); }
    var kpis = h("div", { class: "kpis" },
      kpi(t("kCash"), k.cash, k.cash < 0 ? "neg" : "", "reports"), kpi(t("kAR"), k.receivable, "", "sales"), kpi(t("kAP"), k.payable, "", "purchases"),
      kpi(t("kRev", { y: F.int(k.year) }), k.revenue, "", "reports"), kpi(t("kExp", { y: F.int(k.year) }), k.expenses, "", "reports"), kpi(t("kNet", { y: F.int(k.year) }), k.net, k.net < 0 ? "neg" : "pos", "reports"));

    /* ── actions & watch-list ── */
    var acts = h("div", { class: "actions" });
    if (UI.can("doc.manage")) { acts.appendChild(h("button", { class: "btn", type: "button", onclick: function () { UI.go("sales", "new"); } }, UI.icon("plus"), t("newSale"))); acts.appendChild(h("button", { class: "btn sec", type: "button", onclick: function () { UI.go("purchases", "new"); } }, UI.icon("plus"), t("newBill"))); acts.appendChild(h("button", { class: "btn sec", type: "button", onclick: function () { UI.go("payments", "new"); } }, UI.icon("plus"), t("newPayment"))); }
    if (UI.can("journal.post")) acts.appendChild(h("button", { class: "btn sec", type: "button", onclick: function () { UI.go("journal", "new"); } }, UI.icon("plus"), t("newEntry")));
    var today = UI.store.today(), open = [];
    Object.keys(co.invoices).forEach(function (id) { var inv = co.invoices[id]; if (inv.status !== "posted") return; var st = UI.store.invoiceStatus(co, inv, today); if (st === "paid") return; var pi = UI.store.paidInfo(co, inv); open.push({ inv: inv, st: st, rem: pi.remaining }); });
    open.sort(function (a, b) { return a.inv.dueDate < b.inv.dueDate ? -1 : 1; });
    var watch = open.length ? UI.table([{ label: t("number") }, { label: t("contact") }, { label: t("due") }, { label: t("status") }, { label: t("remaining"), cls: "end" }],
      open.slice(0, 6).map(function (o) { var c = co.contacts[o.inv.contactId]; return [o.inv.number, c ? c.name : "—", F.date(o.inv.dueDate), UI.badge(t("st_" + o.st), o.st === "overdue" ? "bad" : "warn"), UI.amount(o.rem, o.inv.currency)]; })) : UI.empty(t("noOpenInvoices"));
    var integ = UI.store.verifyIntegrity(UI.ctx);
    var status = h("div", { class: "int-row" }, UI.badge(integ.ok ? t("integrityOk") : t("integrityBad"), integ.ok ? "ok" : "bad"), h("span", { class: "muted small", text: t("entriesCount", { n: F.int(co.entries.length) }) }));

    box.appendChild(h("div", { class: "grid2" }, clockCard, calCard));
    box.appendChild(h("section", { class: "card" }, h("div", { class: "card-head" }, h("h2", { text: t("overview") }), status), kpis, acts));
    box.appendChild(h("section", { class: "card" }, h("h2", { text: t("openInvoices") }), watch));
    resetCal(); loop();
  };
})(typeof globalThis !== "undefined" ? globalThis : this);
