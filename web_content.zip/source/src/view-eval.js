/* Software Evaluator (the original tool, now bilingual and part of AccoNova). */
(function (root) {
  "use strict";
  var UI = root.AN_UI, h = UI.h, F = UI.fmt;
  var SW = [
    { id: "sap", name: "SAP S/4HANA", rating: 4.9, sizes: ["enterprise"], fa: { alt: "ساپ اس/۴ هانا", cat: "سازمانی", str: ["تحلیل لحظه‌ای", "مقیاس‌پذیری جهانی", "زنجیرهٔ تأمین یکپارچه"], target: "شرکت‌های چندملیتی بزرگ" }, en: { cat: "Enterprise", str: ["Real-time analytics", "Global scalability", "Integrated supply chain"], target: "Large multinational corporations" } },
    { id: "ns", name: "Oracle NetSuite", rating: 4.8, sizes: ["mid", "enterprise"], fa: { alt: "اوراکل نت‌سوئیت", cat: "ERP ابری / بازار میانی تا سازمانی", str: ["ERP ابریِ همه‌کاره", "مدیریت مالی", "یکپارچگی با CRM"], target: "کسب‌وکارهای متوسط تا بزرگ در حال رشد" }, en: { cat: "Cloud ERP / Mid-Market to Enterprise", str: ["All-in-one cloud ERP", "Financial management", "CRM integration"], target: "Growing mid-sized to large businesses" } },
    { id: "bc", name: "Microsoft Dynamics 365 Business Central", rating: 4.7, sizes: ["mid"], fa: { alt: "مایکروسافت داینامیکس ۳۶۵ بیزینس سنترال", cat: "بازار میانی", str: ["یکپارچگی عمیق با مایکروسافت آفیس", "قابلیت سفارشی‌سازی", "بینش‌های مبتنی بر هوش مصنوعی"], target: "شرکت‌هایی که در اکوسیستم مایکروسافت کار می‌کنند" }, en: { cat: "Mid-Market", str: ["Deep Microsoft Office integration", "Customizability", "AI insights"], target: "Companies already in the Microsoft ecosystem" } },
    { id: "si", name: "Sage Intacct", rating: 4.7, sizes: ["mid"], fa: { alt: "سیج اینتکت", cat: "بازار میانی", str: ["تجمیع چندشرکتی", "بستن سریع حساب‌ها", "گزارش‌گیری قدرتمند"], target: "کسب‌وکارهای متوسط با ساختار پیچیده" }, en: { cat: "Mid-Market", str: ["Multi-entity consolidation", "Fast close processes", "Strong reporting"], target: "Mid-sized businesses with complex structures" } },
    { id: "xero", name: "Xero", rating: 4.6, sizes: ["small"], fa: { alt: "زیرو", cat: "کسب‌وکار کوچک / فریلنسر", str: ["رابط کاربری ساده", "تطبیق خودکار بانکی", "اکوسیستم گستردهٔ افزونه‌ها"], target: "کسب‌وکارهای کوچک و استارتاپ‌ها" }, en: { cat: "Small Business / Freelancer", str: ["User-friendly interface", "Bank reconciliation automation", "App ecosystem"], target: "Small businesses and startups" } },
    { id: "qbo", name: "QuickBooks Online", rating: 4.5, sizes: ["small"], fa: { alt: "کوییک‌بوکس آنلاین", cat: "کسب‌وکار کوچک / فریلنسر", str: ["پیشرو در بازار کسب‌وکارهای کوچک", "یکپارچگی‌های فراوان با نرم‌افزارهای دیگر", "خدمات حقوق و دستمزد"], target: "کسب‌وکارهای کوچک و فریلنسرها در سراسر جهان" }, en: { cat: "Small Business / Freelancer", str: ["Market leader for SMBs", "Extensive third-party integrations", "Payroll services"], target: "Small businesses and freelancers globally" } }
  ];
  function norm(s) { return String(s).toLowerCase().replace(/[يى]/g, "ی").replace(/ك/g, "ک").replace(/[۰-۹]/g, function (c) { return c.charCodeAt(0) - 0x06F0; }).replace(/[٠-٩]/g, function (c) { return c.charCodeAt(0) - 0x0660; }).replace(/[‌‍ـً-ٰٟ\s\-_.\/]+/g, ""); }

  UI.views.eval = function (box) {
    var t = UI.t, fa = UI.isFa(), L = function (s) { return s[UI.lang]; };
    var rate = function (r) { return fa ? F.num(r, { minimumFractionDigits: 1, maximumFractionDigits: 1 }) + " " + t("ev_of") : F.num(r, { minimumFractionDigits: 1, maximumFractionDigits: 1 }) + "/5"; };
    function bar(r) { return h("div", { class: "bar", role: "img", "aria-label": rate(r) }, h("i", { style: "width:" + (r / 5 * 100).toFixed(0) + "%" })); }
    function nm(s) { return h("span", { class: "ltr", text: s.name }); }
    var st = UI.sub.eval = UI.sub.eval || { size: "small", view: "idle", q: "" };
    var sizeSel = UI.select(["enterprise", "mid", "small"].map(function (k) { return { value: k, label: t("ev_size_" + k) }; }), st.size, function () { st.size = sizeSel.value; if (st.view === "rec") showRec(); });
    var result = h("div", { class: "result", "aria-live": "polite" }), cards = h("div", { class: "sw-cards" });
    var q = h("input", { class: "inp", type: "search", placeholder: t("ev_searchPh"), value: st.q });
    function sorted() { return SW.slice().sort(function (a, b) { return b.rating - a.rating; }); }
    function showRec() {
      st.view = "rec"; UI.clear(result); var list = SW.filter(function (s) { return s.sizes.indexOf(sizeSel.value) > -1; }).sort(function (a, b) { return b.rating - a.rating; }), m = list[0], X = L(m);
      result.appendChild(h("div", { class: "pick" }, h("span", { class: "muted", text: t("ev_suggested") + ":" }), h("strong", {}, nm(m)), UI.badge(t("ev_best") + " · " + rate(m.rating), "ok")));
      if (fa) result.appendChild(h("div", { class: "muted", text: m.fa.alt }));
      result.appendChild(h("p", {}, h("b", { text: t("ev_forW") + ": " }), X.target)); result.appendChild(bar(m.rating)); result.appendChild(h("b", { text: t("ev_strengths") + ":" }));
      result.appendChild(h("ul", {}, X.str.map(function (x) { return h("li", { text: x }); })));
      if (list.length > 1) { var p = h("p", { class: "muted" }, t("ev_also") + ": "); list.slice(1).forEach(function (s, i) { if (i) p.appendChild(document.createTextNode(fa ? "، " : ", ")); p.appendChild(nm(s)); }); result.appendChild(p); }
    }
    function showReport() {
      st.view = "rep"; UI.clear(result);
      result.appendChild(h("strong", { text: t("ev_report") }));
      result.appendChild(UI.table([{ label: "#" }, { label: t("ev_name") }, { label: t("ev_cat") }, { label: t("ev_rating") }], sorted().map(function (s, i) { return [F.int(i + 1), h("span", {}, nm(s), fa ? h("div", { class: "muted small", text: s.fa.alt }) : null), L(s).cat, h("div", {}, h("span", { class: "rate", text: rate(s.rating) }), bar(s.rating))]; })));
    }
    function drawCards(items) {
      UI.clear(cards);
      if (!items.length) { cards.appendChild(h("p", { class: "muted", text: t("ev_none") })); return; }
      items.forEach(function (s) { var X = L(s); cards.appendChild(h("article", { class: "sw" }, h("h3", {}, nm(s)), h("div", { class: "sub muted", text: (fa ? s.fa.alt + " · " : "") + X.cat }), h("div", { class: "rate", text: t("ev_rating") + ": " + rate(s.rating) }), bar(s.rating), h("p", {}, h("b", { text: t("ev_forW") + ": " }), X.target), h("ul", {}, X.str.map(function (x) { return h("li", { text: x }); })))); });
    }
    function search() { st.q = q.value; var n = norm(q.value); drawCards(SW.filter(function (s) { return !n || norm([s.name, s.fa.alt, s.fa.cat, s.en.cat, s.fa.target, s.en.target].concat(s.fa.str, s.en.str).join(" ")).indexOf(n) > -1; })); }
    q.addEventListener("keydown", function (e) { if (e.key === "Enter") { e.preventDefault(); search(); } });
    box.appendChild(h("section", { class: "card" }, h("h2", { text: t("ev_title") }), UI.field(t("ev_size"), sizeSel), h("div", { class: "actions" }, h("button", { class: "btn", type: "button", onclick: showRec }, t("ev_recBtn")), h("button", { class: "btn sec", type: "button", onclick: showReport }, t("ev_repBtn"))), result));
    box.appendChild(h("section", { class: "card" }, h("h2", { text: t("ev_searchTitle") }), UI.field(t("ev_name"), q), h("div", { class: "actions" }, h("button", { class: "btn", type: "button", onclick: search }, t("ev_searchBtn")), h("button", { class: "btn sec", type: "button", onclick: function () { q.value = ""; st.q = ""; drawCards(sorted()); } }, t("ev_allBtn"))), cards, h("p", { class: "muted small mt", text: t("ev_disclaimer") })));
    if (st.view === "rec") showRec(); else if (st.view === "rep") showReport(); else result.textContent = t("ev_idle");
    if (st.q) search(); else drawCards(sorted());
  };
})(typeof globalThis !== "undefined" ? globalThis : this);
