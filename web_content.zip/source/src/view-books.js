/* Books: chart of accounts, journal (entries, reversal), contacts. */
(function (root) {
  "use strict";
  var UI = root.AN_UI, h = UI.h, t = UI.t, F = UI.fmt, J = root.AN_J, AN = root.AN;

  function ppmStr(ppm) { return AN.formatMinor(ppm, 6, "en-US").replace(/,/g, "").replace(/(\.\d*?)0+$/, "$1").replace(/\.$/, ""); }
  UI.ppmStr = ppmStr;
  function activeAccounts(co, types) {
    return Object.keys(co.accounts).map(function (k) { return co.accounts[k]; }).filter(function (a) { return a.active && (!types || types.indexOf(a.type) > -1); }).sort(function (a, b) { return a.code < b.code ? -1 : 1; });
  }
  UI.activeAccounts = activeAccounts;
  UI.accountSelect = function (co, types, value, onchange) {
    var s = h("select", { class: "inp" }, h("option", { value: "", text: "—" }));
    activeAccounts(co, types).forEach(function (a) { s.appendChild(h("option", { value: a.id, text: UI.accountLabel(a) })); });
    if (value) s.value = value; if (onchange) s.addEventListener("change", onchange); return s;
  };
  UI.currencySelect = function (co, value, onchange) {
    var s = h("select", { class: "inp" });
    Object.keys(co.currencies).forEach(function (c) { s.appendChild(h("option", { value: c, text: c + " · " + (AN.CURRENCIES[c] ? AN.CURRENCIES[c].name[UI.lang] : c) })); });
    s.value = value || co.baseCurrency; if (onchange) s.addEventListener("change", onchange); return s;
  };
  UI.rateInput = function (onchange) {
    var inp = h("input", { class: "inp num", type: "text", inputmode: "decimal", dir: "ltr", autocomplete: "off" });
    inp.addEventListener("input", onchange || function () { });
    return { el: inp, get: function () { var v = inp.value.trim(); if (!v) return null; var r = AN.parseMoney(v, 6); return r && r > 0 ? r : null; }, set: function (ppm) { inp.value = ppm ? ppmStr(ppm) : ""; } };
  };

  /* ───────────── accounts ───────────── */
  UI.views.accounts = function (box) {
    var co = UI.co(), bal = UI.store.accountBalances(UI.ctx), types = AN.TYPES;
    var bar = h("div", { class: "toolbar" }, h("h2", { text: t("tabAccounts") }), h("span", { class: "grow" }));
    if (UI.can("account.manage")) bar.appendChild(h("button", { class: "btn", type: "button", onclick: function () { accountForm(); } }, UI.icon("plus"), t("addAccount")));
    box.appendChild(h("section", { class: "card" }, bar));
    types.forEach(function (ty) {
      var accs = Object.keys(co.accounts).map(function (k) { return co.accounts[k]; }).filter(function (a) { return a.type === ty; }).sort(function (a, b) { return a.code < b.code ? -1 : 1; });
      if (!accs.length) return;
      var rows = accs.map(function (a) {
        var b = bal[a.id] || { debit: 0, credit: 0 }, v = (AN.DEBIT_NORMAL[ty] ? 1 : -1) * (b.debit - b.credit);
        var acts = h("span", { class: "row-actions" });
        if (UI.can("account.manage")) {
          acts.appendChild(h("button", { class: "link", type: "button", onclick: function () { renameForm(a); } }, t("rename")));
          if (!a.system) acts.appendChild(h("button", { class: "link", type: "button", onclick: function () { try { UI.store.setAccountActive(UI.ctx, a.id, !a.active); UI.render(); } catch (e) { UI.toast(UI.errMsg(e), "err"); } } }, a.active ? t("deactivate") : t("activate")));
        }
        return { attrs: { class: a.active ? "" : "dim" }, cells: [UI.codeNum(a.code), h("span", {}, UI.accName(a), a.system ? h("span", { class: "tag", text: t("system") }) : null, a.active ? null : UI.badge(t("inactive"), "")), UI.base(v), acts] };
      });
      box.appendChild(h("section", { class: "card" }, h("h3", { text: t("type_" + ty) }), UI.table([{ label: t("code") }, { label: t("accountName") }, { label: t("balance"), cls: "end" }, { label: "" }], rows)));
    });
  };
  UI.base = function (v) { return UI.amount(v, UI.co().baseCurrency); };
  function accountForm() {
    var code = h("input", { class: "inp", dir: "ltr", maxlength: 12 }), type = UI.select(AN.TYPES.map(function (x) { return { value: x, label: t("type_" + x) }; }), "expense");
    var fa = h("input", { class: "inp", maxlength: 120 }), en = h("input", { class: "inp", dir: "ltr", maxlength: 120 });
    var m; var save = h("button", { class: "btn", type: "button", onclick: function () { UI.busy(save, function () { try { UI.store.addAccount(UI.ctx, { code: code.value, type: type.value, name: { fa: fa.value, en: en.value } }); m.close(); UI.toast(t("saved")); UI.render(); } catch (e) { m.error(UI.errMsg(e)); } }); } }, t("save"));
    m = UI.modal({ title: t("addAccount"), body: h("div", { class: "form" }, UI.field(t("code"), code), UI.field(t("accountType"), type), UI.field(t("nameFa"), fa), UI.field(t("nameEn"), en)), footer: [h("button", { class: "btn sec", type: "button", onclick: function () { m.close(); } }, t("cancel")), save] });
  }
  function renameForm(a) {
    var fa = h("input", { class: "inp", value: a.name.fa, maxlength: 120 }), en = h("input", { class: "inp", dir: "ltr", value: a.name.en, maxlength: 120 }), m;
    var save = h("button", { class: "btn", type: "button", onclick: function () { try { UI.store.renameAccount(UI.ctx, a.id, { fa: fa.value, en: en.value }); m.close(); UI.toast(t("saved")); UI.render(); } catch (e) { m.error(UI.errMsg(e)); } } }, t("save"));
    m = UI.modal({ title: t("rename"), body: h("div", { class: "form" }, UI.field(t("nameFa"), fa), UI.field(t("nameEn"), en)), footer: [save] });
  }

  /* ───────────── journal ───────────── */
  UI.views.journal = function (box) {
    var co = UI.co(), st = UI.sub.journal = UI.sub.journal || { q: "", period: "", page: 0 }, PAGE = 25;
    var list = h("div", {}), pager = h("div", { class: "pager" });
    var q = h("input", { class: "inp", type: "search", placeholder: t("searchJournal"), value: st.q, oninput: function () { st.q = q.value; st.page = 0; draw(); } });
    var periods = Object.keys(co.periods).map(function (k) { return co.periods[k]; }).sort(function (a, b) { return a.start < b.start ? -1 : 1; });
    var per = UI.select([{ value: "", label: t("allPeriods") }].concat(periods.map(function (p) { return { value: p.id, label: F.periodName(p) + (p.status === "closed" ? " 🔒" : "") }; })), st.period, function () { st.period = per.value; st.page = 0; draw(); });
    var bar = h("div", { class: "toolbar" }, q, per, h("span", { class: "grow" }));
    if (UI.can("journal.post")) bar.appendChild(h("button", { class: "btn", type: "button", onclick: function () { entryForm(); } }, UI.icon("plus"), t("newEntry")));
    function draw() {
      var needle = st.q.trim().toLowerCase(), rows = co.entries.filter(function (e) { return (!st.period || e.periodId === st.period) && (!needle || (e.id + " " + e.memo + " " + e.date + " " + F.date(e.date)).toLowerCase().indexOf(needle) > -1); }).slice().reverse();
      var pages = Math.max(1, Math.ceil(rows.length / PAGE)); if (st.page >= pages) st.page = pages - 1;
      var slice = rows.slice(st.page * PAGE, st.page * PAGE + PAGE);
      UI.clear(list);
      if (!slice.length) list.appendChild(UI.empty(t("noEntries")));
      else list.appendChild(UI.table([{ label: t("number") }, { label: t("date") }, { label: t("memo") }, { label: t("source") }, { label: t("amount"), cls: "end" }, { label: "" }], slice.map(function (e) {
        var rev = co.reversals[e.id];
        return { attrs: { class: rev ? "dim" : "" }, cells: [UI.num(e.id), F.date(e.date), h("span", {}, e.memo || "—", rev ? UI.badge(t("reversed"), "warn") : null), t("src_" + e.source.type), UI.amount(e.baseTotal, co.baseCurrency), h("button", { class: "link", type: "button", onclick: function () { entryView(e.id); } }, t("view"))] };
      })));
      UI.clear(pager);
      if (pages > 1) { pager.appendChild(h("button", { class: "mini", type: "button", disabled: st.page === 0, onclick: function () { st.page--; draw(); } }, t("prev"))); pager.appendChild(h("span", { class: "muted", text: F.int(st.page + 1) + " / " + F.int(pages) })); pager.appendChild(h("button", { class: "mini", type: "button", disabled: st.page >= pages - 1, onclick: function () { st.page++; draw(); } }, t("next"))); }
    }
    box.appendChild(h("section", { class: "card" }, h("h2", { text: t("tabJournal") }), bar, list, pager)); draw();
    if (UI.pending === "new") { UI.pending = null; entryForm(); }
  };

  function entryView(id) {
    var co = UI.co(), e = UI.store.entryById(co, id); if (!e) return;
    var fx = e.currency !== co.baseCurrency;
    var heads = [{ label: t("account") }, { label: t("debit"), cls: "end" }, { label: t("credit"), cls: "end" }];
    if (fx) heads.push({ label: t("baseDebit"), cls: "end" }, { label: t("baseCredit"), cls: "end" });
    var rows = e.lines.map(function (l) {
      var a = co.accounts[l.accountId], c = l.contactId && co.contacts[l.contactId];
      var cells = [h("span", {}, UI.accountLabel(a), c ? h("span", { class: "tag", text: c.name }) : null, l.baseOnly ? h("span", { class: "tag", text: l.memo === "rounding" ? t("rounding") : t("baseOnly") }) : null),
        l.debit ? UI.amount(l.debit, e.currency) : "", l.credit ? UI.amount(l.credit, e.currency) : ""];
      if (fx) cells.push(l.baseDebit ? UI.amount(l.baseDebit, co.baseCurrency) : "", l.baseCredit ? UI.amount(l.baseCredit, co.baseCurrency) : "");
      return cells;
    });
    var u = UI.store.users()[e.createdBy];
    var meta = h("dl", { class: "meta" },
      h("dt", { text: t("date") }), h("dd", { text: F.date(e.date) }), h("dt", { text: t("period") }), h("dd", { text: F.periodName(co.periods[e.periodId]) }),
      h("dt", { text: t("source") }), h("dd", { text: t("src_" + e.source.type) }), h("dt", { text: t("createdBy") }), h("dd", { text: (u ? u.name : "—") + " · " + F.dateTime(e.createdAt) }),
      fx ? [h("dt", { text: t("currency") }), h("dd", { text: e.currency + " @ " + F.num(e.rate / 1e6, { maximumFractionDigits: 6 }) })] : null,
      h("dt", { text: t("fingerprint") }), h("dd", { class: "mono", dir: "ltr", text: e.hash.slice(0, 16) + "…" }));
    var links = [];
    if (co.reversals[e.id]) links.push(h("p", {}, UI.badge(t("reversed"), "warn"), " ", h("button", { class: "link", type: "button", onclick: function () { m.close(); entryView(co.reversals[e.id]); } }, co.reversals[e.id])));
    if (e.source.type === "reversal") links.push(h("p", {}, t("reversalOf"), " ", h("button", { class: "link", type: "button", onclick: function () { m.close(); entryView(e.source.id); } }, e.source.id)));
    var foot = [h("button", { class: "btn sec", type: "button", onclick: function () { UI.printNode(); } }, UI.icon("print"), t("print"))];
    if (UI.can("journal.reverse") && e.source.type === "manual" && !co.reversals[e.id]) foot.push(h("button", { class: "btn danger", type: "button", onclick: function () { m.close(); reverseForm(e); } }, t("reverse")));
    var m = UI.modal({ title: e.id + " — " + (e.memo || ""), wide: true, body: h("div", { class: "print-area" }, meta, links, UI.table(heads, rows)), footer: foot });
  }
  UI.entryView = entryView;

  function reverseForm(e) {
    var date = UI.dateInput(e.date), reason = h("input", { class: "inp", maxlength: 200 }), idem = UI.newIdemKey(), m;
    var go = h("button", { class: "btn danger", type: "button", onclick: function () { UI.busy(go, function () { var d = date.get(); if (!d) { m.error(t("badDate")); return; } try { UI.store.reverseEntry(UI.ctx, e.id, { date: d, reason: reason.value, idemKey: idem }); m.close(); UI.toast(t("reversedOk")); UI.render(); } catch (er) { m.error(UI.errMsg(er)); } }); } }, t("reverse"));
    m = UI.modal({ title: t("reverse") + " " + e.id, body: h("div", { class: "form" }, h("p", { class: "muted", text: t("reverseExplain") }), UI.field(t("date"), date.el), UI.field(t("reason"), reason)), footer: [h("button", { class: "btn sec", type: "button", onclick: function () { m.close(); } }, t("cancel")), go] });
  }

  function entryForm() {
    var co = UI.co(), plan = UI.store.planOf(co), idem = UI.newIdemKey(), cur = co.baseCurrency, rows = [], m;
    var multi = plan.multiCurrency && Object.keys(co.currencies).length > 1;
    function dec() { return co.currencies[cur].decimals; }
    var date = UI.dateInput(UI.store.today(), function () { autoRate(); }), memo = h("input", { class: "inp", maxlength: 300 });
    var rate = UI.rateInput(), rateWrap = h("div", { class: "field", hidden: "" }, h("label", { text: t("rate") }), rate.el, h("div", { class: "hint", text: t("rateHint") }));
    var curSel = multi ? UI.currencySelect(co, cur, function () { cur = curSel.value; rateWrap.hidden = cur === co.baseCurrency; autoRate(); rows.forEach(function (r) { r.dr.set(r.dr.get()); r.cr.set(r.cr.get()); }); recalc(); }) : null;
    function autoRate() { if (cur !== co.baseCurrency) { var d = date.get(); var r = d && UI.store.rateFor(co, cur, d); rate.set(r || null); } }
    var tbody = h("tbody"), totals = h("div", { class: "totals" }), post = h("button", { class: "btn", type: "button" }, t("post"));
    function addRow(pre) {
      var r = { acc: UI.accountSelect(co, null, pre && pre.accountId, recalc), dr: UI.moneyInput(dec, null, function () { if (r.dr.raw()) r.cr.el.value = ""; recalc(); }), cr: UI.moneyInput(dec, null, function () { if (r.cr.raw()) r.dr.el.value = ""; recalc(); }) };
      r.tr = h("tr", {}, h("td", { "data-label": t("account") }, r.acc), h("td", { "data-label": t("debit") }, r.dr.el), h("td", { "data-label": t("credit") }, r.cr.el), h("td", {}, h("button", { class: "icon-btn", type: "button", "aria-label": t("remove"), onclick: function () { if (rows.length > 2) { rows.splice(rows.indexOf(r), 1); tbody.removeChild(r.tr); recalc(); } } }, UI.icon("x"))));
      rows.push(r); tbody.appendChild(r.tr); return r;
    }
    function state() {
      var sd = 0, sc = 0, valid = [], bad = false;
      rows.forEach(function (r) {
        var d = r.dr.get(), c = r.cr.get(), hasAmt = r.dr.raw() || r.cr.raw();
        if (!r.acc.value && !hasAmt) return;
        if (!r.acc.value || (r.dr.raw() && d == null) || (r.cr.raw() && c == null) || (!(d > 0) === !(c > 0))) { bad = true; return; }
        sd += d || 0; sc += c || 0; valid.push({ accountId: r.acc.value, debit: d || 0, credit: c || 0 });
      });
      return { sd: sd, sc: sc, valid: valid, bad: bad, ok: !bad && valid.length >= 2 && sd === sc && sd > 0 };
    }
    function recalc() {
      var s = state(); UI.curOfForm = cur; UI.clear(totals);
      totals.appendChild(h("div", { class: "tot-row" }, h("span", { text: t("totalDebit") }), UI.amount(s.sd, cur)));
      totals.appendChild(h("div", { class: "tot-row" }, h("span", { text: t("totalCredit") }), UI.amount(s.sc, cur)));
      var diff = s.sd - s.sc;
      totals.appendChild(h("div", { class: "tot-row " + (diff === 0 && s.sd > 0 ? "okc" : "badc") }, h("span", { text: diff === 0 && s.sd > 0 ? t("balancedOk") : t("difference") }), diff === 0 ? "" : UI.amount(Math.abs(diff), cur)));
      post.disabled = !s.ok;
    }
    var body = h("div", { class: "form" }, h("div", { class: "grid-fields" }, UI.field(t("date"), date.el), curSel ? UI.field(t("currency"), curSel) : null, rateWrap), UI.field(t("memo"), memo),
      h("div", { class: "tw" }, h("table", { class: "tbl lines" }, h("thead", {}, h("tr", {}, h("th", { text: t("account") }), h("th", { class: "end", text: t("debit") }), h("th", { class: "end", text: t("credit") }), h("th"))), tbody)),
      h("button", { class: "mini", type: "button", onclick: function () { addRow(); recalc(); } }, UI.icon("plus"), t("addLine")), totals);
    addRow(); addRow(); recalc();
    post.addEventListener("click", function () {
      UI.busy(post, function () {
        var s = state(), d = date.get(); if (!d) { m.error(t("badDate")); return; } if (!s.ok) return;
        var input = { date: d, memo: memo.value, currency: cur, lines: s.valid };
        if (cur !== co.baseCurrency) { var r = rate.get(); if (!r) { m.error(t("e_NO_RATE")); return; } input.rate = r; }
        UI.curOfForm = cur;
        try { var res = UI.store.postEntry(UI.ctx, input, { idemKey: idem }); m.close(); UI.toast(res.duplicate ? t("duplicateIgnored") : t("postedOk", { id: res.entry.id })); UI.render(); } catch (e) { m.error(UI.errMsg(e)); }
      });
    });
    m = UI.modal({ title: t("newEntry"), wide: true, body: body, footer: [h("button", { class: "btn sec", type: "button", onclick: function () { m.close(); } }, t("cancel")), post] });
  }
  UI.entryForm = entryForm;

  /* ───────────── contacts ───────────── */
  UI.views.contacts = function (box) {
    var co = UI.co(), st = UI.sub.contacts = UI.sub.contacts || { f: "all", q: "", archived: false };
    var list = h("div"), q = h("input", { class: "inp", type: "search", placeholder: t("searchContacts"), value: st.q, oninput: function () { st.q = q.value; draw(); } });
    var f = UI.select([{ value: "all", label: t("all") }, { value: "customer", label: t("customers") }, { value: "supplier", label: t("suppliers") }], st.f, function () { st.f = f.value; draw(); });
    var arch = h("label", { class: "chk" }, h("input", { type: "checkbox", checked: st.archived, onchange: function (ev) { st.archived = ev.target.checked; draw(); } }), t("showArchived"));
    var bar = h("div", { class: "toolbar" }, q, f, arch, h("span", { class: "grow" }));
    if (UI.can("contact.manage")) bar.appendChild(h("button", { class: "btn", type: "button", onclick: function () { contactForm(); } }, UI.icon("plus"), t("addContact")));
    function openBal(cid) {
      var ar = 0, ap = 0; Object.keys(co.invoices).forEach(function (k) { var i = co.invoices[k]; if (i.contactId !== cid || i.status !== "posted") return; var p = UI.store.paidInfo(co, i); if (i.kind === "sale") ar += p.remainingBase; else ap += p.remainingBase; }); return { ar: ar, ap: ap };
    }
    function draw() {
      var needle = st.q.trim().toLowerCase();
      var rows = Object.keys(co.contacts).map(function (k) { return co.contacts[k]; }).filter(function (c) { return (st.archived || !c.archived) && (st.f === "all" || c.type === st.f || c.type === "both") && (!needle || (c.name + " " + c.email + " " + c.phone).toLowerCase().indexOf(needle) > -1); }).sort(function (a, b) { return a.name < b.name ? -1 : 1; });
      UI.clear(list);
      if (!rows.length) { list.appendChild(UI.empty(t("noContacts"))); return; }
      list.appendChild(UI.table([{ label: t("name") }, { label: t("type") }, { label: t("contactInfo") }, { label: t("receivable"), cls: "end" }, { label: t("payable"), cls: "end" }, { label: "" }], rows.map(function (c) {
        var b = openBal(c.id);
        return { attrs: { class: c.archived ? "dim" : "" }, cells: [h("span", {}, c.name, c.archived ? UI.badge(t("archived"), "") : null), t("ct_" + c.type), [c.email, c.phone].filter(Boolean).join(" · ") || "—", b.ar ? UI.amount(b.ar, co.baseCurrency) : "", b.ap ? UI.amount(b.ap, co.baseCurrency) : "", UI.can("contact.manage") ? h("button", { class: "link", type: "button", onclick: function () { contactForm(c); } }, t("edit")) : ""] };
      })));
    }
    box.appendChild(h("section", { class: "card" }, h("h2", { text: t("tabContacts") }), bar, list)); draw();
  };
  function contactForm(c) {
    c = c || {}; var name = h("input", { class: "inp", value: c.name || "", maxlength: 120 }), type = UI.select([{ value: "customer", label: t("ct_customer") }, { value: "supplier", label: t("ct_supplier") }, { value: "both", label: t("ct_both") }], c.type || "customer");
    var email = h("input", { class: "inp", type: "email", dir: "ltr", value: c.email || "" }), phone = h("input", { class: "inp", dir: "ltr", value: c.phone || "", maxlength: 40 }), tax = h("input", { class: "inp", dir: "ltr", value: c.taxId || "", maxlength: 40 });
    var arch = h("input", { type: "checkbox", checked: !!c.archived }), m;
    var save = h("button", { class: "btn", type: "button", onclick: function () { UI.busy(save, function () { try { UI.store.saveContact(UI.ctx, { id: c.id, name: name.value, type: type.value, email: email.value, phone: phone.value, taxId: tax.value, archived: arch.checked }); m.close(); UI.toast(t("saved")); UI.render(); } catch (e) { m.error(UI.errMsg(e)); } }); } }, t("save"));
    m = UI.modal({ title: c.id ? t("editContact") : t("addContact"), body: h("div", { class: "form" }, UI.field(t("name"), name), UI.field(t("type"), type), UI.field(t("email"), email), UI.field(t("phone"), phone), UI.field(t("taxId"), tax), c.id ? h("label", { class: "chk" }, arch, t("archived")) : null), footer: [h("button", { class: "btn sec", type: "button", onclick: function () { m.close(); } }, t("cancel")), save] });
  }
  UI.contactForm = contactForm;
})(typeof globalThis !== "undefined" ? globalThis : this);
