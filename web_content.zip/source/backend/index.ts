import { router, json, error, ai } from '@appdeploy/sdk';

type ImagePayload = { data: string; mimeType: string };
type OcrBody = { image?: ImagePayload };
type CardsBody = { notes?: string };
type TutorBody = { notes?: string; question?: string };

function cleanText(value: unknown, max: number): string {
  return typeof value === 'string' ? value.trim().slice(0, max) : '';
}

function parseJsonArray(text: string): Array<{ q: string; a: string }> {
  const start = text.indexOf('[');
  const end = text.lastIndexOf(']');
  if (start < 0 || end < start) return [];
  const parsed: unknown = JSON.parse(text.slice(start, end + 1));
  if (!Array.isArray(parsed)) return [];
  return parsed.slice(0, 30).filter((item): item is { q: string; a: string } =>
    !!item && typeof item === 'object' &&
    typeof (item as { q?: unknown }).q === 'string' &&
    typeof (item as { a?: unknown }).a === 'string'
  ).map((item) => ({ q: item.q.slice(0, 240), a: item.a.slice(0, 600) }));
}

export const handler = router({
  'POST /api/study/ocr': [async ({ body }) => {
    const payload = (body || {}) as OcrBody;
    const image = payload.image;
    if (!image || typeof image.data !== 'string' || image.data.length > 8000000 ||
        !['image/jpeg', 'image/png', 'image/webp'].includes(image.mimeType)) {
      return error('Choose a supported textbook image and try again.', 400);
    }
    try {
      const result = await ai.ocr({
        images: [{ data: image.data, mimeType: image.mimeType }],
        prompt: 'Transcribe the readable textbook page accurately. Preserve headings, definitions, formulas, labels, and bullet points. Do not add facts that are not visible. If text is unclear, mark it as [unclear].',
        maxTokens: 3500,
        thinkingMode: 'FAST'
      });
      const text = result.text.trim().slice(0, 18000);
      if (!text) return error('No readable text was found. Try a brighter, sharper photo.', 422);
      return json({ text });
    } catch {
      return error('Textbook scanning failed. Check your connection and try another photo.', 502);
    }
  }],
  'POST /api/study/cards': [async ({ body }) => {
    const notes = cleanText((body as CardsBody | undefined)?.notes, 12000);
    if (notes.length < 20) return error('Add at least a few lines of notes first.', 400);
    try {
      const result = await ai.generate({
        system: 'You are a careful school study assistant. Use only the supplied notes. Do not add outside facts. Create concise active-recall questions, fill-in-the-blank questions, and definition questions. Return only a JSON array of objects with string keys q and a.',
        prompt: 'Create 8 to 16 useful flashcards from these notes. Avoid copying whole sentences as questions. Ask specific questions and use fill-in-the-blank when appropriate. Notes:\n' + notes,
        schema: { type: 'array', items: { type: 'object', properties: { q: { type: 'string' }, a: { type: 'string' } }, required: ['q', 'a'], additionalProperties: false } },
        maxTokens: 2400,
        temperature: 0.2,
        thinkingMode: 'FAST'
      });
      let cards = Array.isArray((result as { data?: unknown }).data) ? (result as { data: Array<{q:string;a:string}> }).data : [];
      if (!cards.length) cards = parseJsonArray(result.text);
      cards = cards.filter((c) => c && typeof c.q === 'string' && typeof c.a === 'string').slice(0, 30);
      if (!cards.length) return error('Could not make clear flashcards from these notes. Try a shorter section.', 422);
      return json({ cards });
    } catch {
      return error('AI flashcard generation is unavailable right now. You can still use the offline card maker.', 502);
    }
  }],
  'POST /api/study/paper': [async ({ body }) => {
    const payload = (body || {}) as { notes?: string; subject?: string; count?: number; difficulty?: string };
    const notes = cleanText(payload.notes, 14000);
    const subject = cleanText(payload.subject, 100) || 'Study topic';
    const count = Math.max(5, Math.min(15, Number(payload.count) || 10));
    const difficulty = cleanText(payload.difficulty, 20) || 'Mixed';
    if (notes.length < 20) return error('Add or scan textbook notes before generating a paper.', 400);
    try {
      const result = await ai.generate({
        system: 'You are a careful school exam paper setter. Use only the supplied study notes; do not add outside facts. Make clear, age-appropriate questions. Return structured data matching the schema.',
        prompt: 'Create a ' + difficulty + ' practice paper for ' + subject + ' with exactly ' + count + ' questions. Mix short answer, definition, and application questions where the notes support them. Give marks for each question and a concise model answer. Notes:\n' + notes,
        schema: { type: 'object', properties: { title: { type: 'string' }, questions: { type: 'array', minItems: count, maxItems: count, items: { type: 'object', properties: { question: { type: 'string' }, marks: { type: 'integer' }, answer: { type: 'string' } }, required: ['question', 'marks', 'answer'], additionalProperties: false } } }, required: ['title', 'questions'], additionalProperties: false },
        maxTokens: 4200,
        temperature: 0.25,
        thinkingMode: 'FAST'
      });
      const data = (result as { data?: { title?: string; questions?: Array<{ question: string; marks: number; answer: string }> } }).data;
      if (!data || !Array.isArray(data.questions) || !data.questions.length) return error('Could not build a paper from these notes. Try a longer section.', 422);
      return json({ title: cleanText(data.title, 160) || subject + ' Practice Paper', questions: data.questions.slice(0, count).map((q) => ({ question: cleanText(q.question, 500), marks: Math.max(1, Math.min(10, Number(q.marks) || 1)), answer: cleanText(q.answer, 800) })) });
    } catch {
      return error('Question paper generation failed. Check your connection and try again.', 502);
    }
  }],
  'POST /api/study/quiz': [async ({ body }) => {
    const payload = (body || {}) as { notes?: string; topic?: string; count?: number; difficulty?: string };
    const notes = cleanText(payload.notes, 14000);
    const topic = cleanText(payload.topic, 100) || 'Study topic';
    const count = Math.max(5, Math.min(10, Number(payload.count) || 5));
    const difficulty = cleanText(payload.difficulty, 20) || 'Mixed';
    if (notes.length < 20) return error('Add or scan at least a few lines of textbook notes first.', 400);
    try {
      const result = await ai.generate({
        system: 'You are a careful school quiz writer. Use only the supplied notes. Create unambiguous multiple-choice questions with exactly four options, one correct option index from 0 to 3, and a concise explanation grounded in the notes.',
        prompt: 'Create exactly ' + count + ' multiple-choice questions about ' + topic + ' at ' + difficulty + ' difficulty. Do not repeat questions. Notes:\n' + notes,
        schema: { type: 'array', minItems: count, maxItems: count, items: { type: 'object', properties: { question: { type: 'string' }, options: { type: 'array', minItems: 4, maxItems: 4, items: { type: 'string' } }, correctIndex: { type: 'integer' }, explanation: { type: 'string' } }, required: ['question', 'options', 'correctIndex', 'explanation'], additionalProperties: false } },
        maxTokens: 3600,
        temperature: 0.2,
        thinkingMode: 'FAST'
      });
      let questions = Array.isArray((result as { data?: unknown }).data) ? (result as { data: Array<{ question: string; options: string[]; correctIndex: number; explanation: string }> }).data : [];
      if (!questions.length) {
        const start = result.text.indexOf('[');
        const end = result.text.lastIndexOf(']');
        if (start >= 0 && end > start) questions = JSON.parse(result.text.slice(start, end + 1));
      }
      questions = questions.filter((q) => q && typeof q.question === 'string' && Array.isArray(q.options) && q.options.length === 4 && Number.isInteger(q.correctIndex) && q.correctIndex >= 0 && q.correctIndex < 4 && typeof q.explanation === 'string').slice(0, count);
      if (!questions.length) return error('Could not create a clear quiz from these notes. Try a different section.', 422);
      return json({ topic, questions });
    } catch {
      return error('Quiz generation failed. Check your connection and try again.', 502);
    }
  }],
  'POST /api/study/socratic': [async ({ body }) => {
    const payload = (body || {}) as { notes?: string; prompt?: string };
    const notes = cleanText(payload.notes, 12000);
    const prompt = cleanText(payload.prompt, 1200);
    if (!notes || !prompt) return error('Add notes and a topic first.', 400);
    try {
      const result = await ai.generate({
        system: 'You are a Socratic school tutor. Use only the supplied notes. Ask one question or give one small hint at a time. Do not pretend unsupported facts are in the notes. Be kind, concise, and age-appropriate.',
        prompt: 'NOTES:\\n' + notes + '\\n\\nTUTOR TASK:\\n' + prompt,
        maxTokens: 500,
        temperature: 0.3,
        thinkingMode: 'FAST'
      });
      return json({ question: result.text.trim().slice(0, 1800) });
    } catch {
      return error('Socratic tutor is unavailable right now. Check your connection and try again.', 502);
    }
  }],
  'POST /api/study/tutor': [async ({ body }) => {
    const payload = (body || {}) as TutorBody;
    const notes = cleanText(payload.notes, 12000);
    const question = cleanText(payload.question, 700);
    if (!notes || !question) return error('Upload a page or add notes, then ask a question.', 400);
    try {
      const result = await ai.generate({
        system: 'You are a helpful school study tutor. Answer from the provided textbook notes only. Clearly say when the notes do not contain enough information. Explain step by step in age-appropriate language, and never pretend an unsupported fact came from the textbook.',
        prompt: 'TEXTBOOK NOTES:\n' + notes + '\n\nSTUDENT QUESTION:\n' + question + '\n\nGive a clear concise answer grounded in the notes. If useful, finish with one quick check-for-understanding question.',
        maxTokens: 1200,
        temperature: 0.25,
        thinkingMode: 'FAST'
      });
      return json({ answer: result.text.trim().slice(0, 5000) || 'I could not form an answer from those notes. Try asking in a different way.' });
    } catch {
      return error('The tutor is unavailable right now. Check your connection and try again.', 502);
    }
  }]
});