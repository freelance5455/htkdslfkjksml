const CACHE = 'zai-pwa-v1';
const ASET = ['./', './index.html', './manifest.json'];

addEventListener('install', e => {
    e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASET)));
    skipWaiting();
});
addEventListener('activate', e => {
    e.waitUntil(caches.keys().then(k => Promise.all(k.filter(x=>x!==CACHE).map(x=>caches.delete(x)))));
    clients.claim();
});
addEventListener('fetch', e => {
    e.respondWith(caches.match(e.request).then(r => r || fetch(e.request)));
});
