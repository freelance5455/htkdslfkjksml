# Pesquisa de bibliotecas para o Gato Noturno

Pesquisa feita em documentação oficial e páginas dos próprios projetos. A versão atual continua em Canvas 2D puro, sem dependências externas, para abrir localmente e continuar leve no celular. A pesquisa orienta melhorias futuras; não significa que estas bibliotecas já foram integradas.

## Bibliotecas e tecnologias avaliadas

1. **Phaser** — motor de jogos 2D com cenas, entradas para toque/teclado, escala e sistemas de física. É a opção mais completa caso o jogo cresça para fases, inimigos, inventário e progressão RPG. Migração deve ser planejada e feita em etapas, mantendo a versão atual como referência.
   - Cenas: https://docs.phaser.io/phaser/concepts/scenes
   - Entrada: https://docs.phaser.io/phaser/concepts/input
   - Escala: https://docs.phaser.io/phaser/concepts/scale-manager

2. **PixiJS** — renderização 2D acelerada por GPU, sprites e efeitos. Pode ajudar quando houver muitos sprites, animações e partículas; é menos necessário para o desenho simples atual. A documentação recomenda atenção ao custo de efeitos e quantidade de objetos.
   - Renderizadores: https://pixijs.com/8.x/guides/components/renderers
   - Desempenho: https://pixijs.com/7.x/guides/production/performance-tips

3. **Howler.js** — camada de áudio para efeitos, música, volume, cache e compatibilidade entre navegadores. É uma opção futura se o jogo passar a ter música e vários efeitos; atualmente os bipes são gerados pela Web Audio API nativa.
   - Site e documentação: https://howlerjs.com/

4. **Matter.js** — motor de física 2D, útil para colisões e objetos físicos mais elaborados. Para este corredor simples, a física atual é pequena e específica; não há necessidade de adicioná-lo ainda.
   - Site: https://brm.io/matter-js/
   - Código/documentação: https://github.com/liabru/matter-js

5. **Screen Orientation API (nativa do navegador)** — permite tentar bloquear a orientação em `landscape`. O suporte varia e a trava costuma exigir tela cheia e uma ação do usuário. Por isso o jogo não deve ficar preso numa mensagem se o navegador recusar o bloqueio.
   - MDN: https://developer.mozilla.org/en-US/docs/Web/API/ScreenOrientation/lock
   - Guia MDN: https://developer.mozilla.org/en-US/docs/Web/API/CSS_Object_Model/Managing_screen_orientation

## Plano incremental recomendado

- Primeiro corrigir início automático, layout móvel, controles e colisões sem mudar de motor.
- Depois separar responsabilidades em arquivos conectados (`game.js`, `player.js`, `obstacles.js`, `audio.js`, `ui.js`, `styles.css`) mantendo cópia de segurança e comportamento existente.
- Adicionar testes de colisão, reinício, pausa, toque simultâneo e redimensionamento.
- Só então avaliar Phaser para recursos de jogo mais complexos ou PixiJS para maior carga visual. Integrar uma biblioteca exige testar o pacote offline e não deve ser anunciada como concluída antes de estar realmente integrada.

## Limites da versão 3

- O jogo inicia diretamente e o gato foi redesenhado para ficar sempre deitado.
- O bloqueio de orientação horizontal e tela cheia é tentado quando o jogador toca na tela; o navegador pode negar esses recursos.
- Ainda não foi feito teste físico no aparelho Android do usuário. A verificação local do código não substitui teste no celular.
