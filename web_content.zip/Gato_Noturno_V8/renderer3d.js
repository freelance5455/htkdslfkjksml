/* Gato Noturno V8 — renderizador 3D WebGL próprio e offline.
 * Geometria procedural original; não depende de CDN ou download em tempo de jogo.
 * A simulação da versão anterior continua sendo a fonte dos movimentos e colisões.
 */
(function () {
  'use strict';
  const canvas = document.getElementById('game3d');
  if (!canvas) return;
  let gl = null, program = null, vertexBuffer = null;
  let aPosition = -1, aNormal = -1, aUV = -1, uMVP = null, uModel = null, uColor = null, uTexture = null, uUseTexture = null;
  const textureMap = Object.create(null);
  let vertexCount = 0, cameraYaw = 0.42, cameraPitch = 0;
  let dragPointer = null, dragX = 0, dragY = 0, lastTime = 0;
  let starField = [];
  const VERTEX_SHADER = `
    attribute vec3 aPosition;
    attribute vec3 aNormal;
    attribute vec2 aUV;
    uniform mat4 uMVP;
    uniform mat4 uModel;
    varying vec3 vNormal;
    varying vec3 vPosition;
    varying vec2 vUV;
    void main(){
      vec4 world = uModel * vec4(aPosition,1.0);
      vPosition = world.xyz;
      vNormal = normalize(mat3(uModel) * aNormal);
      vUV = aUV;
      gl_Position = uMVP * vec4(aPosition,1.0);
    }
  `;
  const FRAGMENT_SHADER = `
    precision mediump float;
    uniform vec3 uColor;
    uniform sampler2D uTexture;
    uniform float uUseTexture;
    varying vec2 vUV;
    varying vec3 vNormal;
    varying vec3 vPosition;
    void main(){
      vec3 n = normalize(vNormal);
      vec3 light = normalize(vec3(-0.45,0.85,0.55));
      float diffuse = max(dot(n,light),0.0);
      float shade = 0.42 + diffuse * 0.68;
      float fog = clamp((length(vPosition.xz) - 24.0) / 75.0,0.0,0.32);
      vec3 night = vec3(0.025,0.035,0.065);
      vec3 surface = uColor;
      if(uUseTexture > 0.5){vec3 texel=texture2D(uTexture,vUV).rgb;surface*=mix(vec3(0.70),texel,0.60);}
      vec3 color = mix(surface*shade,night,fog);
      gl_FragColor = vec4(color,1.0);
    }
  `;
  function compileShader(type, source) {
    const shader = gl.createShader(type);
    gl.shaderSource(shader, source);
    gl.compileShader(shader);
    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
      const message = gl.getShaderInfoLog(shader) || 'Falha ao compilar shader';
      gl.deleteShader(shader);
      throw new Error(message);
    }
    return shader;
  }
  function buildProgram() {
    const vs = compileShader(gl.VERTEX_SHADER, VERTEX_SHADER);
    const fs = compileShader(gl.FRAGMENT_SHADER, FRAGMENT_SHADER);
    const p = gl.createProgram();
    gl.attachShader(p, vs); gl.attachShader(p, fs); gl.linkProgram(p);
    gl.deleteShader(vs); gl.deleteShader(fs);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p) || 'Falha ao vincular shaders');
    return p;
  }
  function cubeVertices() {
    const faces = [
      { n:[0,0,1], p:[[-.5,-.5,.5],[.5,-.5,.5],[.5,.5,.5],[-.5,.5,.5]], uv:[[0,0],[1,0],[1,1],[0,1]] },
      { n:[0,0,-1],p:[[.5,-.5,-.5],[-.5,-.5,-.5],[-.5,.5,-.5],[.5,.5,-.5]], uv:[[0,0],[1,0],[1,1],[0,1]] },
      { n:[1,0,0], p:[[.5,-.5,.5],[.5,-.5,-.5],[.5,.5,-.5],[.5,.5,.5]], uv:[[0,0],[1,0],[1,1],[0,1]] },
      { n:[-1,0,0],p:[[-.5,-.5,-.5],[-.5,-.5,.5],[-.5,.5,.5],[-.5,.5,-.5]], uv:[[0,0],[1,0],[1,1],[0,1]] },
      { n:[0,1,0], p:[[-.5,.5,.5],[.5,.5,.5],[.5,.5,-.5],[-.5,.5,-.5]], uv:[[0,0],[1,0],[1,1],[0,1]] },
      { n:[0,-1,0],p:[[-.5,-.5,-.5],[.5,-.5,-.5],[.5,-.5,.5],[-.5,-.5,.5]], uv:[[0,0],[1,0],[1,1],[0,1]] }
    ];
    const data=[];
    for(const face of faces){const indices=[0,1,2,0,2,3];for(const i of indices)data.push(...face.p[i],...face.n,...face.uv[i])}
    return new Float32Array(data);
  }
  function init() {
    try {
      gl = canvas.getContext('webgl', { alpha:false, antialias:true, depth:true, powerPreference:'high-performance' }) || canvas.getContext('experimental-webgl');
      if (!gl) throw new Error('WebGL não disponível neste navegador');
      program = buildProgram();
      vertexBuffer = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
      const vertices = cubeVertices(); vertexCount = vertices.length / 8;
      gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW);
      aPosition = gl.getAttribLocation(program,'aPosition');
      aNormal = gl.getAttribLocation(program,'aNormal');
      aUV = gl.getAttribLocation(program,'aUV');
      uMVP = gl.getUniformLocation(program,'uMVP');
      uModel = gl.getUniformLocation(program,'uModel');
      uColor = gl.getUniformLocation(program,'uColor');
      uTexture = gl.getUniformLocation(program,'uTexture');
      uUseTexture = gl.getUniformLocation(program,'uUseTexture');
      gl.enable(gl.DEPTH_TEST); gl.depthFunc(gl.LEQUAL);
      gl.enable(gl.CULL_FACE); gl.cullFace(gl.BACK);
      gl.useProgram(program);
      gl.enableVertexAttribArray(aPosition); gl.enableVertexAttribArray(aNormal); gl.enableVertexAttribArray(aUV);
      gl.vertexAttribPointer(aPosition,3,gl.FLOAT,false,32,0);
      gl.vertexAttribPointer(aNormal,3,gl.FLOAT,false,32,12);
      gl.vertexAttribPointer(aUV,2,gl.FLOAT,false,32,24);
      gl.uniform1i(uTexture,0);
      loadTexture('stone','assets/stone.png');loadTexture('floor','assets/floor.png');loadTexture('fur','assets/fur.png');loadTexture('crystal','assets/crystal.png');
      makeStars(); resize();
      document.body.classList.add('webgl-ready');
      canvas.classList.remove('webgl-unavailable');
      bindCameraControls();
      canvas.addEventListener('webglcontextlost', event => {
        event.preventDefault(); document.body.classList.remove('webgl-ready'); canvas.classList.add('webgl-unavailable');
        console.warn('[Gato Noturno 3D] Contexto WebGL perdido; mostrando renderizador alternativo.');
      });
      window.addEventListener('resize',resize,{passive:true});
      return true;
    } catch (error) {
      console.warn('[Gato Noturno 3D] Renderização 3D indisponível; ativando renderizador alternativo.',error);
      canvas.classList.add('webgl-unavailable');
      document.body.classList.remove('webgl-ready');
      return false;
    }
  }
  function loadTexture(key,url){
    const texture=gl.createTexture();textureMap[key]=texture;gl.bindTexture(gl.TEXTURE_2D,texture);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,1,1,0,gl.RGBA,gl.UNSIGNED_BYTE,new Uint8Array([180,190,210,255]));gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.REPEAT);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.REPEAT);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR_MIPMAP_LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
    const image=new Image();image.onload=()=>{if(!gl)return;gl.bindTexture(gl.TEXTURE_2D,texture);gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,true);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,image);gl.generateMipmap(gl.TEXTURE_2D)};image.onerror=()=>console.warn('[Gato Noturno 3D] Textura não carregada:',url);image.src=url;
  }
  function makeStars() {
    let seed=82371; const random=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296};
    starField=[];
    for(let i=0;i<115;i++)starField.push({x:(random()-.5)*90,y:4+random()*15,z:-9-random()*25,size:.025+random()*.055});
  }
  function resize() {
    if(!gl)return;
    const dpr=Math.min(window.devicePixelRatio||1,1.55);
    const w=Math.max(1,Math.round(canvas.clientWidth*dpr));
    const h=Math.max(1,Math.round(canvas.clientHeight*dpr));
    if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;}
    gl.viewport(0,0,w,h);
  }
  function identity(){return new Float32Array([1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]);}
  function multiply(a,b){const out=new Float32Array(16);for(let c=0;c<4;c++)for(let r=0;r<4;r++)out[c*4+r]=a[0*4+r]*b[c*4+0]+a[1*4+r]*b[c*4+1]+a[2*4+r]*b[c*4+2]+a[3*4+r]*b[c*4+3];return out;}
  function perspective(fovy,aspect,near,far){const f=1/Math.tan(fovy/2),nf=1/(near-far),out=new Float32Array(16);out[0]=f/aspect;out[5]=f;out[10]=(far+near)*nf;out[11]=-1;out[14]=2*far*near*nf;return out;}
  function normalize(v){const l=Math.hypot(v[0],v[1],v[2])||1;return [v[0]/l,v[1]/l,v[2]/l];}
  function cross(a,b){return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];}
  function dot(a,b){return a[0]*b[0]+a[1]*b[1]+a[2]*b[2];}
  function lookAt(eye,center,up){const z=normalize([eye[0]-center[0],eye[1]-center[1],eye[2]-center[2]]),x=normalize(cross(up,z)),y=cross(z,x);return new Float32Array([x[0],y[0],z[0],0,x[1],y[1],z[1],0,x[2],y[2],z[2],0,-dot(x,eye),-dot(y,eye),-dot(z,eye),1]);}
  function modelMatrix(x,y,z,sx,sy,sz){const m=identity();m[0]=sx;m[5]=sy;m[10]=sz;m[12]=x;m[13]=y;m[14]=z;return m;}
  function hexColor(hex){const h=hex.replace('#','');return [parseInt(h.slice(0,2),16)/255,parseInt(h.slice(2,4),16)/255,parseInt(h.slice(4,6),16)/255];}
  let viewProjection=null;
  function box(x,y,z,sx,sy,sz,color,textureName=null){
    const model=modelMatrix(x,y,z,Math.max(.006,sx),Math.max(.006,sy),Math.max(.006,sz));
    gl.uniformMatrix4fv(uModel,false,model);gl.uniformMatrix4fv(uMVP,false,multiply(viewProjection,model));gl.uniform3fv(uColor,hexColor(color));if(textureName&&textureMap[textureName]){gl.uniform1f(uUseTexture,1);gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,textureMap[textureName])}else{gl.uniform1f(uUseTexture,0)}gl.drawArrays(gl.TRIANGLES,0,vertexCount);
  }
  function palette(index){return [
    {ground:'#181e2c',trim:'#78859f',far:'#18243b',accent:'#b4c7f5'},
    {ground:'#10221e',trim:'#568776',far:'#102d28',accent:'#9bc8a7'},
    {ground:'#231b30',trim:'#9081aa',far:'#332343',accent:'#d4b8ee'},
    {ground:'#17243a',trim:'#8398bf',far:'#1c2b45',accent:'#c9d9ff'},
    {ground:'#24182e',trim:'#ab7dad',far:'#35213b',accent:'#edc4f2'}
  ][Math.max(0,Math.min(4,index|0))];}
  function drawCat(b,playerX,playerZ,lift,pal){
    const x=playerX,y=.17+lift,z=playerZ;
    const coat=b.store&&b.store.silverSkin?'#bfc9df':'#f3f4fa';
    const eye='#070910';
    // Corpo comprido, cabeça baixa, patas recolhidas e cauda: postura deitada em 3D.
    box(x-.08,y+.16,z,1.12,.30,.48,coat,'fur');
    box(x+.52,y+.25,z,.43,.36,.42,coat,'fur');
    box(x+.68,y+.48,z-.12,.13,.19,.12,coat,'fur');
    box(x+.68,y+.48,z+.12,.13,.19,.12,coat,'fur');
    box(x+.80,y+.27,z-.115,.055,.055,.055,eye);
    box(x+.80,y+.27,z+.115,.055,.055,.055,eye);
    box(x+.89,y+.20,z,.05,.04,.06,'#d4d8e5');
    box(x-.52,y+.16,z,.42,.12,.13,coat,'fur');
    box(x-.34,y+.055,z-.16,.25,.105,.13,coat,'fur');
    box(x+.34,y+.055,z-.16,.23,.105,.13,coat,'fur');
    box(x-.34,y+.055,z+.16,.25,.105,.13,coat,'fur');
    box(x+.34,y+.055,z+.16,.23,.105,.13,coat,'fur');
    // Marcas discretas no dorso para reforçar o modelo low-poly.
    box(x-.08,y+.32,z,.56,.018,.19,b.store&&b.store.silverSkin?'#e6ecf8':'#d4d8e5');
  }
  function drawObstacle(o,playerX,pal){
    const centerX=(o.x+o.w*.5-90)/35;
    const sx=Math.max(.35,o.w/35),sy=Math.max(.35,o.h/35),z=Number(o.laneZ)||0;
    const centerY=(368-(o.y+o.h*.5))/35;
    const body=(o.type==='big'||o.type==='tower'||o.type==='monolith')?'#171c2a':'#080b13';
    box(centerX,centerY,z,sx,sy,.9,body,'stone');
    box(centerX,centerY+sy*.5+.035,z,sx+.04,.07,.94,pal.trim);
    if(o.type==='monolith'||o.type==='tower'||o.type==='big'){
      for(let i=1;i<Math.min(5,Math.floor(sy*2));i++)box(centerX,centerY-sy*.5+sy*i/Math.min(5,Math.floor(sy*2)),z+.465,sx*.82,.035,.025,pal.accent);
    }
    if(o.type==='spike'){
      box(centerX,sy*.58,z,sx*.55,sy*.78,.78,'#4b5367');
      box(centerX,sy*.94,z,sx*.22,.16,.35,'#aebbd7');
    }
    if(o.type==='double')box(centerX,sy*.5,z,sx*.08,sy*.86,.97,pal.trim);
    if(o.type==='crate'){box(centerX,sy*.5,z+.48,sx*.76,sy*.72,.035,'#4b5367');box(centerX,sy*.5,z+.505,sx*.06,sy*.76,.02,pal.accent)}
  }
  function drawBird(b,playerX,pal){const x=(b.x+b.w*.5-90)/35,y=Math.max(.9,(368-b.y)/40),z=Number(b.laneZ)||0;box(x,y,z,.55,.16,.24,'#e8eaf2');box(x-.12,y+.12,z-.24,.34,.08,.31,pal.trim);box(x-.12,y+.12,z+.24,.34,.08,.31,pal.trim);box(x+.25,y+.015,z,.18,.06,.09,'#b9c4dc');}
  function drawGem(g,pal){const x=(g.x-90)/35,y=Math.max(.3,(368-g.y)/40),z=Number(g.laneZ)||0;box(x,y,z,.22,.30,.22,'#e8f4ff','crystal');box(x,y,z+.13,.09,.16,.035,pal.accent);}
  function drawScenery(playerX,playerZ,b,pal,now){
    const level=b.levelIndex||0,offset=((b.dist||0)*.18)%3;
    // Estrada espessa e laterais, com marcas procedurais em movimento.
    box(playerX+3,-.24,0,62,.45,9,pal.ground,'floor');
    box(playerX+3,-.02,-4.56,62,.06,.10,pal.trim);box(playerX+3,-.02,4.56,62,.06,.10,pal.trim);
    for(let i=-10;i<17;i++){
      const x=playerX+i*3-offset;
      box(x,-.004,0,1.10,.018,.075,pal.trim);
    }
    // Colinas cúbicas e ruínas ao fundo, mudam por fase.
    for(let i=-8;i<10;i++){
      const x=playerX+i*5.8-((b.dist||0)*.035%5.8),h=1.8+Math.abs(Math.sin(i*1.73+level))*3.3;
      box(x,h/2,-7.3,5.4,h,1.1,pal.far,'stone');
      if(level===1||level===3){box(x+1.5,h+.6,-6.8,.28,1.4,.32,pal.trim);box(x-1.25,h*.66,-6.7,.25,.8,.3,pal.trim)}
      if(level===2||level===4){box(x,h+.25,-6.7,3.0,.30,.55,pal.trim);box(x,h+1.0,-6.7,.27,1.25,.3,pal.trim)}
    }
    // Árvores/monólitos ao lado da pista dão profundidade sem carregar texturas externas.
    for(let i=-7;i<9;i++){
      const x=playerX+i*6.3-((b.dist||0)*.06%6.3),h=1.4+Math.abs(Math.sin(i*2.2))*1.8;
      if(level===0||level===1){box(x,h*.35,-5.7,.42,h*.7,.44,'#101a1d','stone');box(x,h,-5.7,1.1,.95,1.0,pal.far);box(x,h+.6,-5.7,.65,.75,.65,pal.trim)}
      else {box(x,h*.5,-5.7,.9,h,.9,pal.far);box(x,h+.18,-5.7,1.0,.15,1.0,pal.trim)}
      box(x,h*.35,5.7,.42,h*.7,.44,'#101a1d');box(x,h,5.7,1.05,.82,.95,pal.far,'stone');
    }
    // Lua blocada e estrelas geradas deterministicamente.
    box(playerX+19,10,-10,1.8,1.8,.4,'#e4e9f8');box(playerX+19.6,10.3,-9.75,1.5,1.5,.42,pal.far);
    const starCount=b.quality==='low'?28:(b.quality==='high'?starField.length:66);for(let si=0;si<starCount;si++){const star=starField[si];box(playerX+star.x,star.y,star.z,star.size,star.size,star.size,'#c8d5f5')};
  }
  function render(){
    if(!gl||!document.body.classList.contains('webgl-ready'))return;
    const bridge=window.GatoNoturnoBridge?window.GatoNoturnoBridge():null;if(!bridge)return;
    resize();const width=canvas.width,height=canvas.height;gl.viewport(0,0,width,height);
    const pal=palette(bridge.levelIndex),cat=bridge.cat;
    const playerX=(cat.x+cat.w*.5-90)/35,playerZ=Number(bridge.playerDepth)||0;
    const lift=Math.max(0,(368-(cat.y+cat.h))/40);
    const forwardX=Math.cos(cameraYaw),forwardZ=Math.sin(cameraYaw);
    const eye=[playerX-forwardX*9,3.8+cameraPitch*7,playerZ-forwardZ*9];
    const target=[playerX+forwardX*2.8,.6+lift*.25,playerZ+forwardZ*2.8];
    const projection=perspective(1.00,Math.max(.5,width/Math.max(1,height)),.1,120);
    const view=lookAt(eye,target,[0,1,0]);viewProjection=multiply(projection,view);
    gl.clearColor(.025,.035,.065,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
    drawScenery(playerX,playerZ,bridge,pal,performance.now());
    for(const o of bridge.obstacles)drawObstacle(o,playerX,pal);
    for(const bird of bridge.birds)drawBird(bird,playerX,pal);
    for(const gem of bridge.gems)if(!gem.got)drawGem(gem,pal);
    drawCat(bridge,playerX,playerZ,lift,pal);
    for(const p of bridge.particles||[])box((p.x-90)/35,Math.max(.1,(368-p.y)/40),playerZ,.065,.065,.065,pal.accent);
    lastTime=performance.now();
  }
  function bindCameraControls(){
    canvas.addEventListener('pointerdown',event=>{
      if(!window.GatoNoturnoBridge||window.GatoNoturnoBridge().state!=='playing')return;
      dragPointer=event.pointerId;dragX=event.clientX;dragY=event.clientY;
      try{canvas.setPointerCapture(event.pointerId)}catch(_){}
    });
    canvas.addEventListener('pointermove',event=>{
      if(dragPointer!==event.pointerId)return;
      const dx=event.clientX-dragX,dy=event.clientY-dragY;dragX=event.clientX;dragY=event.clientY;
      cameraYaw+=dx*.008;cameraPitch=Math.max(-.18,Math.min(.32,cameraPitch-dy*.0035));
      if(window.GatoNoturnoCameraChanged)window.GatoNoturnoCameraChanged(cameraYaw);
    });
    const release=event=>{if(dragPointer===event.pointerId)dragPointer=null};
    canvas.addEventListener('pointerup',release);canvas.addEventListener('pointercancel',release);canvas.addEventListener('lostpointercapture',release);
  }
  if(init())window.GatoNoturno3D={render,rotateCamera:(delta)=>{cameraYaw+=delta},camera:()=>({yaw:cameraYaw,pitch:cameraPitch}),version:'procedural-webgl-1.0'};
  else window.GatoNoturno3D=null;
})();
