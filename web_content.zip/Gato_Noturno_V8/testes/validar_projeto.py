#!/usr/bin/env python3
"""Verificações estáticas para o Gato Noturno V8; não substituem teste no Android."""
from pathlib import Path
import re, collections, subprocess, sys
ROOT = Path(__file__).resolve().parents[1]
REQUIRED = ['index.html','styles.css','game.js','renderer3d.js','assets/stone.png','assets/floor.png','assets/fur.png','assets/crystal.png']
errors=[]; checks=[]
for rel in REQUIRED:
    path=ROOT/rel
    if not path.is_file() or path.stat().st_size == 0: errors.append(f'Arquivo ausente/vazio: {rel}')
    else: checks.append(f'Arquivo OK: {rel} ({path.stat().st_size} bytes)')
html=(ROOT/'index.html').read_text(encoding='utf-8')
css=(ROOT/'styles.css').read_text(encoding='utf-8')
js=(ROOT/'game.js').read_text(encoding='utf-8')
r3=(ROOT/'renderer3d.js').read_text(encoding='utf-8')
ids=re.findall(r'\bid="([^"]+)"',html)
for item,n in collections.Counter(ids).items():
    if n>1: errors.append(f'ID duplicado no HTML: {item}')
refs=re.findall(r'<script[^>]+src="([^"]+)"',html)+re.findall(r'<link[^>]+href="([^"]+)"',html)
for ref in refs:
    if not (ROOT/ref).is_file(): errors.append(f'Referência local ausente: {ref}')
html_ids=set(ids)
for used in set(re.findall(r"\$\('([^']+)'\)",js)) - html_ids - {'levelToast'}:
    errors.append(f'Seletor JS sem elemento HTML: {used}')
expected={
  '3D via WebGL':'getContext(\'webgl\'',
  'fallback 2D':'webgl-unavailable',
  'modelo de gato deitado':'Corpo comprido, cabeça baixa',
  'seletor de música nativo':'type="file"',
  'armazenamento de áudio IndexedDB':'indexedDB.open',
  'bloqueio de paisagem solicitado':'screen.orientation.lock',
  'fallback de paisagem por CSS':'transform:rotate(90deg)',
  'analógico virtual':'id="joystick"',
  'câmera pelo toque':'bindCameraControls',
  'loja com compras persistentes':'function buyUpgrade',
  'escudo funcional':'function handleCollision',
  'saldo persistente':'gatoNoturnoStoreV1',
  'progressão de fases':'const LEVELS',
}
all_text=html+'\n'+css+'\n'+js+'\n'+r3
for label,needle in expected.items():
    if needle not in all_text: errors.append(f'Recurso obrigatório não localizado: {label}')
    else: checks.append(f'Recurso presente: {label}')
functions=len(re.findall(r'\bfunction\s+[\w$]+\s*\(',js))+len(re.findall(r'\bfunction\s+[\w$]+\s*\(',r3))
if functions<30: errors.append(f'Número de funções inferior à meta: {functions}')
else: checks.append(f'Funções declaradas: {functions}')
# Sintaxe JavaScript (estática)
for file in ['game.js','renderer3d.js']:
    result=subprocess.run(['node','--check',str(ROOT/file)],capture_output=True,text=True)
    if result.returncode: errors.append(f'Sintaxe inválida em {file}: {result.stderr.strip()}')
    else: checks.append(f'Sintaxe JS aprovada: {file}')
# Tamanho real de texturas e presença de backup incremental
assets_size=sum((ROOT/'assets'/f).stat().st_size for f in ['stone.png','floor.png','fur.png','crystal.png'] if (ROOT/'assets'/f).exists())
if assets_size < 100_000: errors.append('Texturas do jogo ausentes ou anormalmente pequenas')
else: checks.append(f'Texturas integradas: {assets_size:,} bytes')
backup=ROOT/'backup_v6'
if not all((backup/f).is_file() for f in ['index.html','styles.css','game.js']): errors.append('Backup da versão anterior incompleto')
else: checks.append('Backup dos três arquivos-base da V6 presente')
print('\n'.join(checks))
if errors:
    print('\nFALHAS:'); print('\n'.join(errors)); sys.exit(1)
print('\nRESULTADO: todas as verificações estáticas passaram.')
