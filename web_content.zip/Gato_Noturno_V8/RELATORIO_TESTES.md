# Relatório verificável — Gato Noturno V8

## Aprovado nesta sessão

- `python3 testes/validar_projeto.py`: todas as verificações estáticas passaram.
- `node --check game.js`: sintaxe aprovada.
- `node --check renderer3d.js`: sintaxe aprovada.
- Referências locais HTML/CSS/JS: verificadas.
- IDs duplicados: nenhum detectado.
- Recursos exigidos pelo verificador: presentes (WebGL, fallback 2D, gato 3D deitado, seletor de arquivo, IndexedDB, solicitação de paisagem, analógico, câmera gestual, loja e fases).
- Contagem de funções declaradas em `game.js` e `renderer3d.js`: 118.
- Texturas integradas: `stone.png`, `floor.png`, `fur.png`, `crystal.png`, totalizando 1.138.289 bytes no snapshot medido.
- Backup `backup_v6/` dos três arquivos base: presente.
- Teste de inicialização com DOM simulado: estado inicial `menu`, versão `8.0.0`; chamada de escolher música aciona o seletor simulado; loja passa para estado `shop`; API de compras acessível.

## Não foi possível validar aqui

- Renderização WebGL 3D em navegador real/Android: **não confirmada**.
- Teste headless visual: falhou ao iniciar EGL/DBUS no ambiente de execução; nenhuma captura visual confiável foi produzida.
- Abrir o seletor de arquivos nativo do Android: o smoke test verificou somente a chamada simulada, não a tela real de armazenamento.
- Reprodução e persistência reais de MP3/M4A/OGG/WAV: não testadas no dispositivo.
- Rotação física do aparelho: depende do navegador/sistema; só a solicitação e a alternativa CSS foram verificadas por código.
- Jogabilidade prolongada, latência, consumo de bateria e colisões entre todas as combinações: exige teste no aparelho.

## Limitação honesta

A validação estática comprova sintaxe e presença/integração estrutural de diversos componentes, mas não garante que toda API seja autorizada pelo navegador, que o GPU do dispositivo aceite WebGL ou que um codec de áudio seja suportado. Não declarar esses comportamentos como testados até executar no celular.
