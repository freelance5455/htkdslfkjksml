# Pesquisa técnica para Gato Noturno V8

A pesquisa orienta a implementação Web, a música local, gestos móveis e orientação. Fontes oficiais/primárias consultadas:

## APIs Web usadas pelo projeto

1. **WebGL API (MDN)** — renderização 3D acelerada por GPU dentro do canvas: https://developer.mozilla.org/en-US/docs/Web/API/WebGL_API
2. **WebGLRenderingContext (MDN)** — interface WebGL 1: https://developer.mozilla.org/en-US/docs/Web/API/WebGLRenderingContext
3. **ScreenOrientation.lock (MDN)** — a trava pode não estar disponível ou ser recusada fora dos contextos permitidos: https://developer.mozilla.org/en-US/docs/Web/API/ScreenOrientation/lock
4. **Fullscreen API (MDN)** — `requestFullscreen` está sujeita a suporte e ativação do usuário: https://developer.mozilla.org/en-US/docs/Web/API/Fullscreen_API
5. **File API (MDN)** — campo `input type=file` para o usuário escolher arquivos: https://developer.mozilla.org/en-US/docs/Web/API/File_API/Using_files_from_web_applications
6. **IndexedDB API (MDN)** — armazenamento local de dados/blobs em navegador: https://developer.mozilla.org/en-US/docs/Web/API/IndexedDB_API
7. **HTMLMediaElement (MDN)** — reprodução de arquivos de áudio e eventos de falha: https://developer.mozilla.org/en-US/docs/Web/API/HTMLMediaElement
8. **Pointer Events (MDN)** — eventos de mouse e toque com pointer capture: https://developer.mozilla.org/en-US/docs/Web/API/Pointer_events
9. **setPointerCapture (MDN)** — manter controle do gesto em movimento: https://developer.mozilla.org/en-US/docs/Web/API/Element/setPointerCapture
10. **StorageManager.persist (MDN)** — pedido de armazenamento persistente não é garantia de aceite: https://developer.mozilla.org/en-US/docs/Web/API/StorageManager/persist

## Bibliotecas de jogo avaliadas

11. **Three.js (documentação oficial)** — biblioteca 3D madura; documentação de instalação e renderer: https://threejs.org/manual/#en/installation e https://threejs.org/docs/#api/en/renderers/WebGLRenderer
12. **Phaser (documentação oficial)** — cenas e gerenciamento de entradas: https://docs.phaser.io/phaser/concepts/scenes e https://docs.phaser.io/phaser/concepts/input
13. **PixiJS (documentação oficial)** — renderização gráfica 2D: https://pixijs.com/8.x/guides/components/renderers
14. **Howler.js (site oficial)** — gerenciamento de áudio web: https://howlerjs.com/
15. **Matter.js (site oficial)** — física 2D: https://brm.io/matter-js/

## Decisão tomada

A V8 utiliza WebGL 1 diretamente em `renderer3d.js` com geometria procedural e texturas do próprio pacote. A documentação de Three.js foi considerada, mas não há dependência remota carregada quando o jogo abre: assim, o projeto pode operar sem CDN, evita um pedido externo obrigatório e não precisa reescrever a simulação de imediato. Phaser, PixiJS, Howler.js e Matter.js permanecem opções avaliadas, não bibliotecas que se afirmam integradas ao código atual.

## Ativos do projeto

- `assets/stone.png`: textura para pedra/estruturas.
- `assets/floor.png`: textura da pista.
- `assets/fur.png`: textura de pelagem.
- `assets/crystal.png`: textura de fragmentos.

São recursos utilizados pelo renderizador, não preenchimento aleatório. Os arquivos PNG somam aproximadamente 1,14 MB no tamanho medido.

## Limites

Este documento descreve APIs e opções de arquitetura, não prova por si só compatibilidade em cada navegador. A orientação nativa, reprodução de áudio, IndexedDB e WebGL precisam ser testados no navegador e aparelho de destino.
