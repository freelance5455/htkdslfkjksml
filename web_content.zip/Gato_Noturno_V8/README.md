# Gato Noturno — versão 8 cumulativa (3D WebGL)

Este projeto é uma evolução incremental dos arquivos da V6 enviados pelo usuário. Os três arquivos originais (`index.html`, `styles.css` e `game.js`) estão preservados em `backup_v6/`. A V8 adiciona um renderizador WebGL próprio e offline; não é um projeto iniciado do zero.

## O que há nesta versão

- **Cena 3D real via WebGL 1**: geometria tridimensional com profundidade, perspectiva, sombreamento e texturas. A geometria é gerada pelo código, sem baixar uma engine quando o jogo abre.
- **Gato low-poly deitado**: corpo comprido e baixo, cabeça próxima do chão, orelhas, patas e cauda modelados em 3D. Isso muda a representação no jogo, mas não é uma postura física de personagem humanoide nem tem relação com Minecraft.
- **Câmera por gesto**: arrastar sobre a área visível da cena gira a câmera; o gesto para cima/baixo ajusta a inclinação.
- **Analógico virtual**: movimenta o gato no eixo lateral/de profundidade da pista; o botão grande `↑` salta. Os botões `↶`, `Ⅱ` e `✦` continuam disponíveis para retorno de percurso, pausa e interação.
- **Música do aparelho**: `ESCOLHER ÁUDIO` e o campo de arquivo permitem abrir o seletor nativo. A música escolhida tenta ser guardada no IndexedDB; o navegador pode negar persistência, e a reprodução automática pode exigir um toque explícito.
- **Modo horizontal**: o jogo solicita tela cheia e trava de orientação quando suportado. Quando não dá, aplica uma apresentação girada via CSS em celular retrato. Isso não garante que o sistema operacional inteiro gire.
- **Lobby, configurações, loja, fases, recorde, fragmentos, obstáculos, pássaros, colisões, escudo, melhorias e salvamento de preferências**.
- **Fallback 2D**: se WebGL não iniciar ou perder o contexto, a versão 2D continua como alternativa. Nesse caso o jogo não estará a ser renderizado em 3D.
- Quatro texturas PNG originais integradas para piso, pedra, pelagem e cristais, somando cerca de 1,14 MB. O aumento de tamanho representa recursos usados, não dados artificiais.

## Como abrir no celular

1. Extraia o ZIP completo. **Não mova os arquivos separados para pastas diferentes**: `index.html`, `styles.css`, `game.js`, `renderer3d.js` e `assets/` precisam conservar a estrutura.
2. Abra `index.html` com um navegador moderno que suporte WebGL. Um editor HTML com visualização pode se comportar de forma diferente.
3. No lobby, escolha uma fase e toque em `JOGAR`.
4. Use o analógico no canto inferior esquerdo; o botão `↑` faz o salto. Arraste uma área livre da cena 3D para virar a câmera. No teclado, use setas ou A/D e Espaço/W/↑ para saltar; `P` pausa e `Esc` volta.
5. Para música, abra Configurações, toque em `ESCOLHER ÁUDIO` e selecione um ficheiro compatível. Caso o navegador não abra o seletor, use o campo de arquivo visível logo abaixo do botão. Se o áudio não começar sozinho, pressione `MÚSICA: ON`.

## Sobre a música e o armazenamento

O arquivo de música permanece no armazenamento do navegador via IndexedDB, não é copiado para uma pasta comum acessível pelo usuário. O espaço pode ser limitado ou apagado pelo navegador. Abrir o jogo através de `file://`, de uma pré-visualização embutida ou de um navegador com permissões restritas pode limitar IndexedDB ou WebGL; um servidor local/HTTPS pode funcionar melhor, dependendo do ambiente.

## Sobre a orientação

A aplicação solicita `requestFullscreen()` e `screen.orientation.lock('landscape')` depois de uma ação do usuário. Ambos podem não ser aceitos por todos os navegadores, modos de abertura ou dispositivos. O CSS tenta apresentar a aplicação horizontal mesmo em retrato, mas isso é um fallback visual, não uma garantia de rotação nativa do dispositivo.

## Testes

Execute:

```bash
python3 testes/validar_projeto.py
node --check game.js
node --check renderer3d.js
```

As verificações estáticas e um teste de inicialização com DOM simulado foram aprovados nesta sessão. A renderização WebGL real, o seletor do sistema real, a reprodução de áudio real e os controles em Android físico ainda precisam ser testados no aparelho. O navegador headless deste ambiente falhou ao inicializar EGL/DBUS e não forneceu captura visual, por isso não declaro a execução visual validada.

## Estrutura

- `index.html`: lobby, configurações, loja, controles e canvases.
- `styles.css`: interface responsiva, orientação adaptativa e controles de toque.
- `game.js`: simulação existente, movimentação, colisões, áudio, estado, fases, loja e persistência.
- `renderer3d.js`: renderização WebGL e modelo tridimensional, compartilhando a simulação por uma ponte.
- `assets/`: texturas reais usadas na cena.
- `backup_v6/`: cópias dos arquivos-base antes da expansão 3D.
- `testes/validar_projeto.py`: verificações automatizadas estáticas.
- `PESQUISA_TECNICA_V8.md`: documentação consultada e limites conhecidos.
