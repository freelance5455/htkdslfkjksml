extends Node3D

const BLOCK_SIZE := 1.0
const WORLD_HALF := 6
const REACH := 6.0

var blocks: Dictionary = {} # Vector3i -> block type
var materials: Dictionary = {}
var selected_block := "Трава"
var player: CharacterBody3D
var camera: Camera3D
var hud: CanvasLayer
var menu_panel: PanelContainer
var settings_panel: PanelContainer
var inventory_label: Label
var status_label: Label
var move_state := Vector2.ZERO
var look_touch := -1
var last_touch := Vector2.ZERO
var look_sensitivity := 0.003
var game_started := false
var settings_open := false
var selected_tool := "Кирка"
var day_clock := 0.28
var sun_light: DirectionalLight3D
var world_environment: WorldEnvironment
var sky_material: ProceduralSkyMaterial
var clouds: Node3D

var block_defs := {
	"Трава": Color(0.28, 0.68, 0.22),
	"Земля": Color(0.48, 0.29, 0.14),
	"Камень": Color(0.48, 0.50, 0.53),
	"Дерево": Color(0.42, 0.25, 0.11),
	"Листва": Color(0.13, 0.43, 0.16)
}

func _ready() -> void:
	_make_materials()
	_make_player()
	_make_world()
	_make_atmosphere()
	_make_ui()
	_show_menu()

func _make_materials() -> void:
	for key in block_defs:
		var mat := StandardMaterial3D.new()
		mat.albedo_color = block_defs[key]
		mat.roughness = 1.0
		materials[key] = mat

func _make_player() -> void:
	player = CharacterBody3D.new()
	player.name = "Player"
	add_child(player)
	player.position = Vector3(0.5, 2.0, 5.5)
	var shape := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.32
	capsule.height = 1.7
	shape.shape = capsule
	shape.position.y = 0.85
	player.add_child(shape)

	camera = Camera3D.new()
	camera.position = Vector3(0, 1.5, 0)
	camera.rotation.x = deg_to_rad(-12)
	camera.current = true
	player.add_child(camera)

func _make_world() -> void:
	# A small 12 x 12 grass platform.
	for x in range(-WORLD_HALF, WORLD_HALF):
		for z in range(-WORLD_HALF, WORLD_HALF):
			_add_block(Vector3i(x, 0, z), "Трава")

	# One tree at a corner of the platform.
	for y in range(1, 4):
		_add_block(Vector3i(-5, y, -5), "Дерево")
	for x in range(-6, -3):
		for z in range(-6, -3):
			for y in range(3, 5):
				if not (x == -5 and z == -5 and y == 3):
					_add_block(Vector3i(x, y, z), "Листва")
	_add_block(Vector3i(-5, 5, -5), "Листва")

func _add_block(cell: Vector3i, kind: String) -> void:
	if blocks.has(cell):
		return
	var body := StaticBody3D.new()
	body.name = "Block_" + str(cell.x) + "_" + str(cell.y) + "_" + str(cell.z)
	body.position = Vector3(cell.x, cell.y, cell.z) + Vector3.ONE * 0.5
	body.set_meta("cell", cell)
	body.set_meta("kind", kind)

	var mesh_instance := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = Vector3.ONE
	mesh_instance.mesh = box
	mesh_instance.material_override = materials[kind]
	body.add_child(mesh_instance)

	var collision := CollisionShape3D.new()
	var box_shape := BoxShape3D.new()
	box_shape.size = Vector3.ONE
	collision.shape = box_shape
	body.add_child(collision)

	add_child(body)
	blocks[cell] = {"node": body, "kind": kind}

func _remove_block(cell: Vector3i) -> void:
	if not blocks.has(cell):
		return
	var entry: Dictionary = blocks[cell]
	var kind: String = entry["kind"]
	entry["node"].queue_free()
	blocks.erase(cell)
	# Collected blocks return to the hotbar inventory.
	status_label.text = "Получен блок: " + kind

func _make_atmosphere() -> void:
	# Procedural sky whose colors change through the day.
	world_environment = WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	sky_material = ProceduralSkyMaterial.new()
	sky_material.sky_top_color = Color(0.18, 0.43, 0.78)
	sky_material.sky_horizon_color = Color(0.62, 0.79, 0.94)
	sky_material.ground_bottom_color = Color(0.20, 0.24, 0.30)
	sky_material.ground_horizon_color = Color(0.58, 0.66, 0.70)
	sky.sky_material = sky_material
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.72, 0.78, 0.88)
	env.ambient_light_energy = 0.7
	world_environment.environment = env
	add_child(world_environment)

	sun_light = DirectionalLight3D.new()
	sun_light.rotation = Vector3(deg_to_rad(-45), deg_to_rad(-30), 0)
	sun_light.light_color = Color(1.0, 0.92, 0.78)
	sun_light.light_energy = 1.2
	sun_light.shadow_enabled = true
	add_child(sun_light)

	# Soft low-poly cloud clusters. They are decorative and do not collide.
	clouds = Node3D.new()
	clouds.name = "Clouds"
	add_child(clouds)
	var cloud_mat := StandardMaterial3D.new()
	cloud_mat.albedo_color = Color(0.96, 0.98, 1.0, 0.92)
	cloud_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	cloud_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	for i in range(7):
		var cloud := Node3D.new()
		cloud.position = Vector3(-9.0 + i * 3.1, 9.0 + float(i % 3) * 0.7, -8.0 + float((i * 5) % 15))
		cloud.set_meta("speed", 0.35 + float(i % 3) * 0.08)
		clouds.add_child(cloud)
		for j in range(4):
			var puff := MeshInstance3D.new()
			var sphere := SphereMesh.new()
			sphere.radius = 0.8 if j == 0 else 0.58
			sphere.height = sphere.radius * 1.2
			puff.mesh = sphere
			puff.material_override = cloud_mat
			puff.position = Vector3(float(j) * 0.75 - 1.1, 0.0 if j % 2 == 0 else 0.18, 0.0)
			cloud.add_child(puff)

func _update_day_night(delta: float) -> void:
	day_clock = fposmod(day_clock + delta * 0.006, 1.0)
	var sun_angle := day_clock * TAU
	var daylight := clampf(sin(sun_angle - PI * 0.5) * 0.5 + 0.5, 0.04, 1.0)
	sun_light.rotation = Vector3(deg_to_rad(-15.0 - daylight * 65.0), deg_to_rad(day_clock * 360.0), 0)
	sun_light.light_energy = lerpf(0.08, 1.25, daylight)
	sun_light.light_color = Color(1.0, lerpf(0.55, 0.95, daylight), lerpf(0.48, 0.82, daylight))
	sky_material.sky_top_color = Color(0.015, 0.025, 0.10).lerp(Color(0.18, 0.43, 0.78), daylight)
	sky_material.sky_horizon_color = Color(0.10, 0.08, 0.20).lerp(Color(0.68, 0.82, 0.96), daylight)
	world_environment.environment.ambient_light_energy = lerpf(0.18, 0.8, daylight)
	for cloud in clouds.get_children():
		cloud.position.x += float(cloud.get_meta("speed")) * delta
		if cloud.position.x > 13.0:
			cloud.position.x = -13.0

func _make_ui() -> void:
	hud = CanvasLayer.new()
	add_child(hud)

	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hud.add_child(root)

	# Top status.
	status_label = Label.new()
	status_label.text = "MiniCraft 3D"
	status_label.position = Vector2(18, 12)
	status_label.add_theme_font_size_override("font_size", 22)
	status_label.add_theme_color_override("font_color", Color.WHITE)
	root.add_child(status_label)

	# Hotbar.
	var hotbar := HBoxContainer.new()
	hotbar.position = Vector2(18, 54)
	hotbar.add_theme_constant_override("separation", 6)
	root.add_child(hotbar)
	for kind in block_defs.keys():
		var b := Button.new()
		b.text = kind
		b.custom_minimum_size = Vector2(94, 42)
		b.pressed.connect(_select_block.bind(kind))
		hotbar.add_child(b)

	inventory_label = Label.new()
	inventory_label.text = "Выбрано: " + selected_block
	inventory_label.position = Vector2(18, 102)
	inventory_label.add_theme_color_override("font_color", Color.WHITE)
	root.add_child(inventory_label)

	var tools_row := HBoxContainer.new()
	tools_row.position = Vector2(18, 130)
	tools_row.add_theme_constant_override("separation", 6)
	root.add_child(tools_row)
	for tool_name in ["Кирка", "Лопата"]:
		var tool_button := Button.new()
		tool_button.text = tool_name
		tool_button.custom_minimum_size = Vector2(94, 38)
		tool_button.pressed.connect(_select_tool.bind(tool_name))
		tools_row.add_child(tool_button)

	# On-screen movement pad.
	var pad := GridContainer.new()
	pad.columns = 3
	pad.position = Vector2(22, -148)
	pad.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT)
	pad.add_theme_constant_override("h_separation", 5)
	pad.add_theme_constant_override("v_separation", 5)
	root.add_child(pad)
	_add_pad_spacer(pad)
	_add_move_button(pad, "↑", Vector2(0, -1))
	_add_pad_spacer(pad)
	_add_move_button(pad, "←", Vector2(-1, 0))
	_add_move_button(pad, "↓", Vector2(0, 1))
	_add_move_button(pad, "→", Vector2(1, 0))

	# Action buttons on the right.
	var actions := VBoxContainer.new()
	actions.position = Vector2(-154, -150)
	actions.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
	actions.add_theme_constant_override("separation", 8)
	root.add_child(actions)
	var break_btn := Button.new()
	break_btn.text = "Ломать"
	break_btn.custom_minimum_size = Vector2(132, 56)
	break_btn.pressed.connect(_break_target)
	actions.add_child(break_btn)
	var place_btn := Button.new()
	place_btn.text = "Поставить"
	place_btn.custom_minimum_size = Vector2(132, 56)
	place_btn.pressed.connect(_place_target)
	actions.add_child(place_btn)
	var menu_btn := Button.new()
	menu_btn.text = "Меню"
	menu_btn.custom_minimum_size = Vector2(132, 48)
	menu_btn.pressed.connect(_show_menu)
	actions.add_child(menu_btn)

	# Main menu overlay.
	menu_panel = PanelContainer.new()
	menu_panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	menu_panel.position = Vector2(-170, -205)
	menu_panel.custom_minimum_size = Vector2(340, 410)
	root.add_child(menu_panel)
	var menu_col := VBoxContainer.new()
	menu_col.alignment = BoxContainer.ALIGNMENT_CENTER
	menu_col.add_theme_constant_override("separation", 14)
	menu_panel.add_child(menu_col)
	var title := Label.new()
	title.text = "MINICRAFT 3D"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 30)
	menu_col.add_child(title)
	var play := Button.new()
	play.text = "Играть"
	play.custom_minimum_size = Vector2(260, 52)
	play.pressed.connect(_start_game)
	menu_col.add_child(play)
	var settings := Button.new()
	settings.text = "Настройки"
	settings.custom_minimum_size = Vector2(260, 52)
	settings.pressed.connect(_show_settings)
	menu_col.add_child(settings)
	var save_btn := Button.new()
	save_btn.text = "Сохранить мир"
	save_btn.custom_minimum_size = Vector2(260, 44)
	save_btn.pressed.connect(_save_world)
	menu_col.add_child(save_btn)
	var load_btn := Button.new()
	load_btn.text = "Загрузить мир"
	load_btn.custom_minimum_size = Vector2(260, 44)
	load_btn.pressed.connect(_load_world)
	menu_col.add_child(load_btn)
	var quit := Button.new()
	quit.text = "Выход"
	quit.custom_minimum_size = Vector2(260, 48)
	quit.pressed.connect(func(): get_tree().quit())
	menu_col.add_child(quit)

	settings_panel = PanelContainer.new()
	settings_panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	settings_panel.position = Vector2(-170, -110)
	settings_panel.custom_minimum_size = Vector2(340, 220)
	settings_panel.visible = false
	root.add_child(settings_panel)
	var settings_col := VBoxContainer.new()
	settings_col.alignment = BoxContainer.ALIGNMENT_CENTER
	settings_col.add_theme_constant_override("separation", 12)
	settings_panel.add_child(settings_col)
	var settings_title := Label.new()
	settings_title.text = "Настройки"
	settings_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	settings_title.add_theme_font_size_override("font_size", 26)
	settings_col.add_child(settings_title)
	var sensitivity_text := Label.new()
	sensitivity_text.text = "Чувствительность камеры"
	settings_col.add_child(sensitivity_text)
	var sensitivity := HSlider.new()
	sensitivity.min_value = 0.001
	sensitivity.max_value = 0.008
	sensitivity.step = 0.0005
	sensitivity.value = look_sensitivity
	sensitivity.value_changed.connect(func(v): look_sensitivity = v)
	settings_col.add_child(sensitivity)
	var back := Button.new()
	back.text = "Назад"
	back.pressed.connect(_close_settings)
	settings_col.add_child(back)

func _add_pad_spacer(parent: GridContainer) -> void:
	var spacer := Control.new()
	spacer.custom_minimum_size = Vector2(52, 48)
	parent.add_child(spacer)

func _add_move_button(parent: GridContainer, caption: String, direction: Vector2) -> void:
	var button := Button.new()
	button.text = caption
	button.custom_minimum_size = Vector2(52, 48)
	button.button_down.connect(_set_move.bind(direction))
	button.button_up.connect(_clear_move.bind(direction))
	parent.add_child(button)

func _set_move(direction: Vector2) -> void:
	move_state = direction

func _clear_move(direction: Vector2) -> void:
	if move_state == direction:
		move_state = Vector2.ZERO

func _select_block(kind: String) -> void:
	selected_block = kind
	inventory_label.text = "Выбрано: " + kind

func _select_tool(tool_name: String) -> void:
	selected_tool = tool_name
	status_label.text = "Инструмент: " + selected_tool

func _show_menu() -> void:
	game_started = false
	menu_panel.visible = true
	settings_panel.visible = false
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	if is_instance_valid(player):
		player.velocity = Vector3.ZERO

func _start_game() -> void:
	game_started = true
	menu_panel.visible = false
	settings_panel.visible = false
	status_label.text = "Построй свой мир!"
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED if not OS.has_feature("mobile") else Input.MOUSE_MODE_VISIBLE

func _show_settings() -> void:
	menu_panel.visible = false
	settings_panel.visible = true
	settings_open = true

func _close_settings() -> void:
	settings_panel.visible = false
	menu_panel.visible = true
	settings_open = false

func _process(delta: float) -> void:
	_update_day_night(delta)
	if not game_started:
		return
	var forward := -camera.global_basis.z
	var right := camera.global_basis.x
	forward.y = 0
	right.y = 0
	forward = forward.normalized()
	right = right.normalized()
	var direction := (right * move_state.x + forward * -move_state.y)
	if Input.is_key_pressed(KEY_W): direction += forward
	if Input.is_key_pressed(KEY_S): direction -= forward
	if Input.is_key_pressed(KEY_A): direction -= right
	if Input.is_key_pressed(KEY_D): direction += right
	direction = direction.normalized()
	player.velocity.x = direction.x * 4.5
	player.velocity.z = direction.z * 4.5
	if not player.is_on_floor():
		player.velocity.y -= 18.0 * delta
	else:
		player.velocity.y = -0.2
	if Input.is_key_pressed(KEY_SPACE) and player.is_on_floor():
		player.velocity.y = 6.0
	player.move_and_slide()

func _unhandled_input(event: InputEvent) -> void:
	if not game_started:
		return
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		_rotate_camera(event.relative)
	elif event is InputEventScreenTouch:
		if event.pressed:
			look_touch = event.index
			last_touch = event.position
		elif event.index == look_touch:
			look_touch = -1
	elif event is InputEventScreenDrag and event.index == look_touch:
		var delta := event.position - last_touch
		last_touch = event.position
		_rotate_camera(delta)
	elif event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_ESCAPE:
			_show_menu()
		elif event.keycode == KEY_F:
			_break_target()
		elif event.keycode == KEY_G:
			_place_target()

func _rotate_camera(delta: Vector2) -> void:
	player.rotate_y(-delta.x * look_sensitivity)
	camera.rotate_x(-delta.y * look_sensitivity)
	camera.rotation.x = clamp(camera.rotation.x, deg_to_rad(-80), deg_to_rad(80))

func _save_world() -> void:
	var saved_blocks: Array[Dictionary] = []
	for cell in blocks.keys():
		var kind: String = blocks[cell]["kind"]
		saved_blocks.append({
			"x": cell.x,
			"y": cell.y,
			"z": cell.z,
			"kind": kind
		})
	var file := FileAccess.open("user://minicraft_world.json", FileAccess.WRITE)
	if file == null:
		status_label.text = "Не удалось сохранить мир"
		return
	file.store_string(JSON.stringify({"blocks": saved_blocks}))
	file.close()
	status_label.text = "Мир сохранён!"

func _load_world() -> void:
	if not FileAccess.file_exists("user://minicraft_world.json"):
		status_label.text = "Сохранение пока не найдено"
		return
	var file := FileAccess.open("user://minicraft_world.json", FileAccess.READ)
	if file == null:
		status_label.text = "Не удалось открыть сохранение"
		return
	var parsed = JSON.parse_string(file.get_as_text())
	file.close()
	if typeof(parsed) != TYPE_DICTIONARY or not parsed.has("blocks"):
		status_label.text = "Файл сохранения повреждён"
		return

	for entry in blocks.values():
		entry["node"].queue_free()
	blocks.clear()

	for item in parsed["blocks"]:
		if typeof(item) != TYPE_DICTIONARY:
			continue
		var kind: String = str(item.get("kind", "Трава"))
		if not block_defs.has(kind):
			kind = "Трава"
		var cell := Vector3i(int(item.get("x", 0)), int(item.get("y", 0)), int(item.get("z", 0)))
		_add_block(cell, kind)
	status_label.text = "Мир загружен!"

func _get_target() -> Dictionary:
	var origin := camera.global_position
	var end := origin + (-camera.global_basis.z) * REACH
	var query := PhysicsRayQueryParameters3D.create(origin, end)
	query.exclude = [player.get_rid()]
	return get_world_3d().direct_space_state.intersect_ray(query)

func _break_target() -> void:
	var hit := _get_target()
	if hit.is_empty():
		status_label.text = "Подойди ближе к блоку"
		return
	var node: Object = hit["collider"]
	if node is StaticBody3D and node.has_meta("cell"):
		_remove_block(node.get_meta("cell"))
	status_label.text = selected_tool + ": блок добыт"

func _place_target() -> void:
	var hit := _get_target()
	if hit.is_empty():
		status_label.text = "Наведи на грань блока"
		return
	var node: Object = hit["collider"]
	if not (node is StaticBody3D and node.has_meta("cell")):
		return
	var cell: Vector3i = node.get_meta("cell")
	var normal: Vector3 = hit["normal"]
	var target := cell + Vector3i(roundi(normal.x), roundi(normal.y), roundi(normal.z))
	# Do not place a block inside the player.
	var player_cell := Vector3i(floori(player.global_position.x), floori(player.global_position.y), floori(player.global_position.z))
	if target == player_cell or target == player_cell + Vector3i(0, 1, 0):
		status_label.text = "Здесь нельзя поставить блок"
		return
	_add_block(target, selected_block)
	status_label.text = "Поставлен блок: " + selected_block
