/* ────────────────────────────────
   LOCALIZATION
──────────────────────────────── */
function t(key) {
  return key;
}

function getInvalidIdMessage(rolePrefix, roleLen) {
  return `Your Authren ID must start with ${rolePrefix} followed only by ${roleLen} digits.`;
}

/* ────────────────────────────────
   PASSWORD REQUIREMENTS VALIDATION
──────────────────────────────── */
function validatePassword(pass) {
  const errors = [];
  if (!pass || pass.length < 6) errors.push(t('Password must contain at least 6 characters.'));
  if (!/[A-Za-z]/.test(pass || '')) errors.push(t('Password must contain at least one letter.'));
  if (!/[0-9]/.test(pass || '')) errors.push(t('Password must contain at least one number.'));
  return errors;
}

/* ═══════════════════════════════
   SOFT AURORA BACKGROUND
═══════════════════════════════ */
function initSoftAurora(canvas, opts) {
  const ctx = canvas.getContext('2d');
  let W, H, dpr = Math.min(window.devicePixelRatio || 1, 2);

  function resize() {
    W = canvas.clientWidth = window.innerWidth;
    H = canvas.clientHeight = window.innerHeight;
    canvas.width = W * dpr;
    canvas.height = H * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  resize();
  window.addEventListener('resize', resize);

  let mouseX = 0.5, mouseY = 0.35;
  let targetX = mouseX, targetY = mouseY;
  if (opts.enableMouseInteraction) {
    window.addEventListener('mousemove', e => {
      targetX = e.clientX / window.innerWidth;
      targetY = e.clientY / window.innerHeight;
    });
  }

  function hexToRgb(hex) {
    const h = hex.replace('#', '');
    const n = parseInt(h.length === 3 ? h.split('').map(c => c + c).join('') : h, 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }
  const c1 = hexToRgb(opts.color1);
  const c2 = hexToRgb(opts.color2);
  const lerp = (a, b, t) => a + (b - a) * t;
  const lerpColor = (a, b, t) => [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];

  const NUM_BANDS = 5;
  const NUM_OCTAVES = 3;
  const t0 = performance.now();

  function frame(now) {
    const time = ((now - t0) / 1000) * opts.speed;
    mouseX = lerp(mouseX, targetX, 0.04);
    mouseY = lerp(mouseY, targetY, 0.04);

    ctx.clearRect(0, 0, W, H);
    ctx.globalCompositeOperation = 'lighter';

    for (let b = 0; b < NUM_BANDS; b++) {
      const bandT = b / (NUM_BANDS - 1);
      const bandPhase = b * 1.9 + (opts.layerOffset || 0) * b;
      const colorT = (Math.sin(time * opts.colorSpeed * 0.35 + b * 1.3) + 1) / 2;
      const col = lerpColor(c1, c2, colorT);

      const spread = opts.bandSpread != null ? opts.bandSpread : 1;
      const baseY = H * (0.5 + (bandT - 0.5) * 0.7 * spread)
                    + (mouseY - 0.5) * H * opts.mouseInfluence;

      const step = Math.max(6, Math.floor(8 / dpr));
      ctx.beginPath();
      for (let x = -step; x <= W + step; x += step) {
        let y = baseY;
        let amp = 46 * opts.noiseAmplitude * opts.brightness;
        let freq = (opts.noiseFrequency * 0.0016) / opts.scale;
        for (let o = 0; o < NUM_OCTAVES; o++) {
          const octFreq = freq * Math.pow(2, o);
          const octAmp = amp * Math.pow(0.5 + opts.octaveDecay, o);
          y += Math.sin(x * octFreq + time * (1 + o * 0.25) + bandPhase + o * 2.3) * octAmp;
        }
        const xShift = (mouseX - 0.5) * 60 * opts.mouseInfluence;
        if (x === -step) ctx.moveTo(x + xShift, y);
        else ctx.lineTo(x + xShift, y);
      }

      const thickness = Math.max(8, H * opts.bandHeight * 0.22 * opts.scale);
      const grad = ctx.createLinearGradient(0, baseY - thickness, 0, baseY + thickness);
      const a = Math.min(0.9, 0.32 * opts.brightness);
      grad.addColorStop(0, `rgba(${col[0]|0},${col[1]|0},${col[2]|0},0)`);
      grad.addColorStop(0.5, `rgba(${col[0]|0},${col[1]|0},${col[2]|0},${a})`);
      grad.addColorStop(1, `rgba(${col[0]|0},${col[1]|0},${col[2]|0},0)`);

      ctx.lineWidth = thickness;
      ctx.strokeStyle = grad;
      ctx.filter = 'blur(28px)';
      ctx.stroke();
    }

    ctx.filter = 'none';
    ctx.globalCompositeOperation = 'source-over';
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
}

initSoftAurora(document.getElementById('aurora-bg'), {
  speed: 0.24,
  scale: 1.45,
  brightness: 0.58,
  color1: '#60A5FA',
  color2: '#8B5CF6',
  noiseFrequency: 2.25,
  noiseAmplitude: 0.72,
  bandHeight: 0.42,
  bandSpread: 0.92,
  octaveDecay: 0.1,
  layerOffset: 0,
  colorSpeed: 0.55,
  enableMouseInteraction: true,
  mouseInfluence: 0.12,
});

window.addEventListener('load', () => {
  document.body.classList.add('page-loaded');
  syncRoleIcons();
  setTimeout(() => document.body.classList.add('intro-done'), 1400);
});

/* ────────────────────────────────
   STATE
──────────────────────────────── */
let currentRole = null;
let currentSchoolType = null;
let previousScreen = 'landing';

const ROLES = {
  student:  { icon:'student',  name:'Student',             sub:'Student Dashboard',            idPrefix:'S', idLen:8,  idExample:'S12345678',  accent:'#3B82F6', rgb:'59,130,246',  iconBg:'linear-gradient(180deg, rgba(59,130,246,0.22), rgba(59,130,246,0.08))' },
  guardian: { icon:'guardian', name:'Guardian',            sub:'Guardian Dashboard',           idPrefix:'G', idLen:8,  idExample:'G98765432',  accent:'#22C55E', rgb:'34,197,94',  iconBg:'linear-gradient(180deg, rgba(34,197,94,0.22), rgba(34,197,94,0.08))' },
  teacher:  { icon:'teacher',  name:'Teacher',             sub:'Teacher Dashboard',            idPrefix:'T', idLen:7,  idExample:'T1234567',   accent:'#8B5CF6', rgb:'139,92,246', iconBg:'linear-gradient(180deg, rgba(139,92,246,0.22), rgba(139,92,246,0.08))' },
  head:     { icon:'head',     name:'Head of Institution', sub:'Administration Dashboard',     idPrefix:'H', idLen:7,  idExample:'H4500912',   accent:'#F59E0B', rgb:'245,158,11', iconBg:'linear-gradient(180deg, rgba(245,158,11,0.22), rgba(245,158,11,0.08))' },
  school:   { icon:'school',   name:'School / Institution',sub:'Institution Dashboard',        idPrefix:'I', idLen:7,  idExample:'I7890123',   accent:'#EC4899', rgb:'236,72,153', iconBg:'linear-gradient(180deg, rgba(236,72,153,0.22), rgba(236,72,153,0.08))' },
};

const ROLE_ICONS = {
  student:  `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 7.5 12 3l10 4.5-10 4.5L2 7.5Z"/><path d="M6 9.3V14c0 2 2.7 3.7 6 3.7s6-1.7 6-3.7V9.3"/><path d="M20 9.5v4.7"/></svg>`,
  guardian: `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3 20 6v5c0 5-3.4 8.4-8 10-4.6-1.6-8-5-8-10V6l8-3Z"/><path d="m9.2 11.8 1.9 1.9 3.8-4"/></svg>`,
  teacher:  `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 6h16v10H4z"/><path d="M4 10h16"/><path d="M8 20h8"/><path d="M12 16v4"/></svg>`,
  head:     `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 10V6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v4"/><path d="M4 10h16v8H4z"/><path d="M9 18v-4h6v4"/><path d="M8 14h8"/></svg>`,
  school:   `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 21h18"/><path d="M5 21V7l7-4 7 4v14"/><path d="M9 21v-6h6v6"/></svg>`,
};

function syncRoleIcons() {
  document.querySelectorAll('.rc-icon[data-role]').forEach(el => {
    const role = el.getAttribute('data-role');
    el.innerHTML = ROLE_ICONS[role] || '';
  });
}

/* ────────────────────────────────
   PASSWORD VISIBILITY TOGGLE LOGIC
──────────────────────────────── */
const EYE_CLOSED_SVG = `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>`;
const EYE_OPEN_SVG = `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>`;

function togglePasswordVisibility(inputId, btn) {
  const input = document.getElementById(inputId);
  if (!input) return;
  if (input.type === 'password') {
    input.type = 'text';
    btn.innerHTML = EYE_OPEN_SVG;
  } else {
    input.type = 'password';
    btn.innerHTML = EYE_CLOSED_SVG;
  }
}

function resetPasswordInputs() {
  ['input-pass', 'input-new-pass', 'input-confirm-pass'].forEach(id => {
    const input = document.getElementById(id);
    if (input) input.type = 'password';
  });
  document.querySelectorAll('.toggle-pass-btn').forEach(btn => {
    btn.innerHTML = EYE_CLOSED_SVG;
  });
}

/* ────────────────────────────────
   SCREEN NAVIGATION & LEGAL PAGES
──────────────────────────────── */
function showScreen(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById('screen-'+id).classList.add('active');
}

function openPrivacy() {
  const activeScreen = document.querySelector('.screen.active');
  if (activeScreen && activeScreen.id !== 'screen-privacy' && activeScreen.id !== 'screen-terms' && activeScreen.id !== 'screen-support') {
    previousScreen = activeScreen.id.replace('screen-', '');
  }
  showScreen('privacy');
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function openTerms() {
  const activeScreen = document.querySelector('.screen.active');
  if (activeScreen && activeScreen.id !== 'screen-privacy' && activeScreen.id !== 'screen-terms' && activeScreen.id !== 'screen-support') {
    previousScreen = activeScreen.id.replace('screen-', '');
  }
  showScreen('terms');
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function openSupport() {
  const activeScreen = document.querySelector('.screen.active');
  if (activeScreen && activeScreen.id !== 'screen-privacy' && activeScreen.id !== 'screen-terms' && activeScreen.id !== 'screen-support') {
    previousScreen = activeScreen.id.replace('screen-', '');
  }
  showScreen('support');
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function goBackFromLegal() {
  showScreen(previousScreen || 'landing');
}

function goLanding() {
  if (currentRole === 'guardian' && typeof gdResetFamily === 'function') gdResetFamily();
  currentRole = null;
  currentSchoolType = null;
  document.getElementById('input-id').value = '';
  document.getElementById('input-login-email').value = '';
  document.getElementById('input-pass').value = '';
  document.getElementById('login-err').style.display = 'none';
  resetPasswordInputs();
  showScreen('landing');
}

function usesEmailLogin(role) {
  return role === 'head' || role === 'school';
}

function applyLoginIdentifierMode(role) {
  const idField = document.getElementById('login-id-field');
  const emailField = document.getElementById('login-email-field');
  const sub = document.getElementById('login-role-sub');
  if (usesEmailLogin(role)) {
    idField.style.display = 'none';
    emailField.style.display = 'block';
    sub.textContent = t('Enter your email and password');
  } else {
    idField.style.display = 'block';
    emailField.style.display = 'none';
    sub.textContent = t('Enter your Authren ID and password');
  }
  document.getElementById('input-id').value = '';
  document.getElementById('input-login-email').value = '';
}

function goLogin(role, evt) {
  if (evt && typeof evt.stopPropagation === 'function') evt.stopPropagation();
  currentRole = role;
  currentSchoolType = null;
  const r = ROLES[role];
  const loginIcon = document.getElementById('login-icon');
  loginIcon.innerHTML = ROLE_ICONS[role] || '';
  loginIcon.style.background = r.iconBg;
  loginIcon.style.color = r.accent;
  document.getElementById('login-role-name').textContent = t(r.name);
  document.getElementById('input-id').placeholder = t('e.g.') + ' ' + r.idExample;
  document.getElementById('id-hint').textContent = t('Your ID starts with') + ' "' + r.idPrefix + '" ' + t('followed by') + ' ' + r.idLen + ' ' + t('digits');
  applyLoginIdentifierMode(role);
  resetPasswordInputs();
  showScreen('login');
}

function goSchool(evt) {
  if (evt && typeof evt.stopPropagation === 'function') evt.stopPropagation();
  currentRole = 'school';
  currentSchoolType = null;
  showScreen('assoc');
}

function selectAssociation(type) {
  currentSchoolType = type;
  const r = ROLES['school'];
  const loginIcon = document.getElementById('login-icon');
  loginIcon.innerHTML = ROLE_ICONS['school'] || '';
  loginIcon.style.background = r.iconBg;
  loginIcon.style.color = r.accent;

  let typeLabel = '';
  if (type === 'owner') typeLabel = t('Owner / Proprietor');
  else if (type === 'finance') typeLabel = t('Finance Manager / Accountant');
  else if (type === 'admin') typeLabel = t('Authorized Administrator');

  document.getElementById('login-role-name').textContent = t(r.name) + ' — ' + typeLabel;
  document.getElementById('input-id').placeholder = t('e.g.') + ' ' + r.idExample;
  document.getElementById('id-hint').textContent = t('Your ID starts with') + ' "' + r.idPrefix + '" ' + t('followed by') + ' ' + r.idLen + ' ' + t('digits');
  applyLoginIdentifierMode('school');
  resetPasswordInputs();
  showScreen('login');
}

function doLogin() {
  const pass = document.getElementById('input-pass').value;
  const err = document.getElementById('login-err');
  const r = ROLES[currentRole];

  if (usesEmailLogin(currentRole)) {
    const email = document.getElementById('input-login-email').value.trim();
    if (!email) {
      err.style.display = 'block';
      err.textContent = '❌ ' + t('Email is required.');
      return;
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      err.style.display = 'block';
      err.textContent = '❌ ' + t('Please enter a valid email address.');
      return;
    }
    if (!pass) {
      err.style.display = 'block';
      err.textContent = '❌ ' + t('Password is required.');
      return;
    }
    const passErrors = validatePassword(pass);
    if (passErrors.length > 0) {
      err.style.display = 'block';
      err.textContent = '❌ ' + passErrors.join(' ');
      return;
    }
    err.style.display = 'none';
    loadDashboard(currentRole, email);
    return;
  }

  const id = document.getElementById('input-id').value.trim();

  if (!id) {
    err.style.display = 'block';
    err.textContent = '❌ ' + t('Authren ID is required.');
    return;
  }

  if (!pass) {
    err.style.display = 'block';
    err.textContent = '❌ ' + t('Password is required.');
    return;
  }

  const regex = new RegExp('^' + r.idPrefix + '\\d{' + r.idLen + '}$');

  if (!regex.test(id)) {
    err.style.display = 'block';
    err.textContent = '❌ ' + getInvalidIdMessage(r.idPrefix, r.idLen);
    return;
  }

  const passErrors = validatePassword(pass);
  if (passErrors.length > 0) {
    err.style.display = 'block';
    err.textContent = '❌ ' + passErrors.join(' ');
    return;
  }

  err.style.display = 'none';
  loadDashboard(currentRole, id);
}

/* ────────────────────────────────
   FORGOT PASSWORD FLOW
──────────────────────────────── */
function showForgotPass() {
  resetPasswordInputs();
  document.getElementById('forgot-modal').classList.add('active');
  document.getElementById('forgot-step-1').classList.add('active');
  document.getElementById('forgot-step-2').classList.remove('active');
  document.getElementById('forgot-step-3').classList.remove('active');
  document.getElementById('forgot-step-4').classList.remove('active');
  const modalClose = document.querySelector('.modal-close');
  if (modalClose) modalClose.style.display = 'flex';
  document.getElementById('input-email').value = '';
  document.getElementById('email-err').style.display = 'none';
}

function closeForgotPass() {
  document.getElementById('forgot-modal').classList.remove('active');
  document.getElementById('forgot-step-1').classList.remove('active');
  document.getElementById('forgot-step-2').classList.remove('active');
  document.getElementById('forgot-step-3').classList.remove('active');
  document.getElementById('forgot-step-4').classList.remove('active');
  const modalClose = document.querySelector('.modal-close');
  if (modalClose) modalClose.style.display = 'flex';
  resetPasswordInputs();
}

function submitEmail() {
  const email = document.getElementById('input-email').value.trim();
  const err = document.getElementById('email-err');
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  
  if (!emailRegex.test(email)) {
    err.style.display = 'block';
    return;
  }
  err.style.display = 'none';
  
  document.getElementById('forgot-step-1').classList.remove('active');
  document.getElementById('forgot-step-2').classList.add('active');
  document.getElementById('input-otp').value = '';
  document.getElementById('otp-err').style.display = 'none';
}

function submitOTP() {
  const otp = document.getElementById('input-otp').value.trim();
  const err = document.getElementById('otp-err');
  const otpRegex = /^\d{6}$/;
  
  if (!otpRegex.test(otp)) {
    err.style.display = 'block';
    return;
  }
  err.style.display = 'none';
  
  document.getElementById('forgot-step-2').classList.remove('active');
  document.getElementById('forgot-step-3').classList.add('active');
  document.getElementById('input-new-pass').value = '';
  document.getElementById('input-confirm-pass').value = '';
  document.getElementById('reset-err').style.display = 'none';
}

function submitNewPassword() {
  const newPass = document.getElementById('input-new-pass').value;
  const confirmPass = document.getElementById('input-confirm-pass').value;
  const err = document.getElementById('reset-err');

  if (!newPass && !confirmPass) {
    err.style.display = 'block';
    err.textContent = '❌ ' + t('New password is required.');
    return;
  }

  if (newPass && !confirmPass) {
    err.style.display = 'block';
    err.textContent = '❌ ' + t('Please confirm your new password.');
    return;
  }

  if (!newPass && confirmPass) {
    err.style.display = 'block';
    err.textContent = '❌ ' + t('New password is required.');
    return;
  }

  const passErrors = validatePassword(newPass);
  if (passErrors.length > 0) {
    err.style.display = 'block';
    err.textContent = '❌ ' + passErrors.join(' ');
    return;
  }

  if (newPass !== confirmPass) {
    err.style.display = 'block';
    err.textContent = '❌ ' + t('Passwords do not match.');
    return;
  }

  err.style.display = 'none';

  document.getElementById('forgot-step-3').classList.remove('active');
  document.getElementById('forgot-step-4').classList.add('active');
  
  const modalClose = document.querySelector('.modal-close');
  if (modalClose) modalClose.style.display = 'none';

  setTimeout(() => {
    closeForgotPass();
    if (modalClose) modalClose.style.display = 'flex';
    
    if (currentRole) {
      goLogin(currentRole);
    } else {
      showScreen('login');
    }
  }, 3000);
}

/* ────────────────────────────────
   DASHBOARD LOADER
──────────────────────────────── */
function loadDashboard(role, userId) {
  const r = ROLES[role];
  document.getElementById('sb-avatar').textContent = r.idPrefix + r.idPrefix;
  document.getElementById('sb-name').textContent = getUserName(role);

  let roleDisplay = t(r.name);
  if (role === 'school' && currentSchoolType) {
    if (currentSchoolType === 'owner') roleDisplay += ' — ' + t('Owner / Proprietor');
    else if (currentSchoolType === 'finance') roleDisplay += ' — ' + t('Finance Manager / Accountant');
    else if (currentSchoolType === 'admin') roleDisplay += ' — ' + t('Authorized Administrator');
  }
  document.getElementById('sb-role').textContent = roleDisplay + ' · ' + userId;

  const switcherSlot = document.getElementById('gd-switcher-slot');
  if (role === 'guardian') {
    if (typeof gdInitFamily === 'function') gdInitFamily();
  } else if (switcherSlot) {
    switcherSlot.innerHTML = '';
  }

  buildSidebar(role);
  renderDashboard(role);
  showScreen('dashboard');
}

function getUserName(role) {
  const names = { student:'Youssef Amrani', guardian:'Mr. Amrani (Father)', teacher:'Mr. Bensalem', head:'Dr. Hassan Ouali', school:'Institution Admin' };
  return names[role];
}

/* ────────────────────────────────
   SIDEBAR BUILDER
──────────────────────────────── */
function buildSidebar(role) {
  const nav = document.getElementById('sidebar-nav');

  const navs = {
    student: [
      { section:'Overview' },
      { id:'home',          icon:'grid',    label:'Dashboard' },
      { id:'academics',     icon:'book',    label:'Academics' },
      { id:'attendance',    icon:'check',   label:'Attendance' },
      { id:'timetable',     icon:'calendar',label:'Timetable' },
      { id:'homework',      icon:'edit',    label:'Homework', badge:'3' },
      { id:'exams',         icon:'clock',   label:'Exams' },
      { section:'Insights' },
      { id:'performance',   icon:'chart',   label:'Performance & Analytics' },
      { id:'behavior',      icon:'star',    label:'Behavior & Achievements' },
      { id:'rankings',      icon:'trophy',  label:'Rankings' },
      { id:'orientation',   icon:'compass', label:'Orientation & Future' },
      { id:'history',       icon:'history', label:'History' },
      { section:'Account' },
      { id:'notifications', icon:'bell',    label:'Notifications', badge:'4' },
      { id:'account',       icon:'cog',     label:'Account & Support' },
    ],
    guardian: [
      { section:'Overview' },
      { id:'home',          icon:'grid',    label:'Home' },
      { id:'family',        icon:'users',   label:'Family Overview' },
      { section:'Child Record' },
      { id:'calendar',      icon:'calendar',label:'School Calendar' },
      { id:'grades',        icon:'edit',    label:'Grades & Exams' },
      { id:'homework',      icon:'book',    label:'Homework' },
      { id:'attendance',    icon:'check',   label:'Attendance' },
      { id:'timetable',     icon:'calendar',label:'Timetable' },
      { id:'analytics',     icon:'chart',   label:'Child 360' },
      { id:'payments',      icon:'card',    label:'Payments' },
      { id:'history',       icon:'history', label:'Reports & History' },
      { section:'Family' },
      { id:'messages',      icon:'msg',     label:'Communication' },
      { section:'Account' },
      { id:'account',       icon:'cog',     label:'Profile & Security' },
    ],
    teacher: [
      { section:'Main' },
      { id:'home',          icon:'grid',    label:'Dashboard' },
      { section:'Teaching' },
      { id:'classes',       icon:'users',   label:'Classes' },
      { id:'attendance',    icon:'check',   label:'Attendance' },
      { id:'timetable',     icon:'calendar',label:'Timetable' },
      { id:'grading',       icon:'edit',    label:'Grading' },
      { id:'exams',         icon:'clock',   label:'Exams' },
      { id:'homework',      icon:'book',    label:'Homework' },
      { section:'Insights' },
      { id:'analytics',     icon:'chart',   label:'Analytics' },
      { id:'behavior',      icon:'warn',    label:'Behavior' },
      { id:'reports',       icon:'history', label:'Reports' },
      { section:'Communication' },
      { id:'messages',      icon:'msg',     label:'Communication' },
      { section:'Tools' },
      { id:'ai',            icon:'star',    label:'AI Assistant' },
      { section:'Account' },
      { id:'account',       icon:'cog',     label:'Profile & Security' },
      { id:'support',       icon:'compass', label:'Support' },
    ],
    head: [
      { section:'Overview' },
      { id:'home',          icon:'grid',    label:'School Dashboard' },
      { id:'intelligence',  icon:'star',    label:'School Intelligence' },
      { section:'People' },
      { id:'students',      icon:'users',   label:'Students' },
      { id:'teachers',      icon:'edit',    label:'Teachers' },
      { id:'guardians',     icon:'msg',     label:'Guardians' },
      { id:'classes',       icon:'book',    label:'Classes' },
      { id:'admissions',    icon:'plus',    label:'Admissions' },
      { id:'orientation',   icon:'compass', label:'Orientation' },
      { section:'Academics' },
      { id:'grades',        icon:'chart',   label:'Grades' },
      { id:'exams',         icon:'clock',   label:'Exams' },
      { id:'homework',      icon:'book',    label:'Homework' },
      { id:'academics-analytics', icon:'trophy', label:'Academic Analytics' },
      { section:'Attendance & Behavior' },
      { id:'attendance',    icon:'check',   label:'Attendance' },
      { id:'timetable',     icon:'calendar',label:'Timetable' },
      { id:'behavior',      icon:'warn',    label:'Behavior' },
      { id:'risk',          icon:'bell',    label:'Student Risk' },
      { section:'Communication' },
      { id:'communication', icon:'msg',     label:'Communication' },
      { section:'Finance' },
      { id:'payments',      icon:'card',    label:'Payments' },
      { section:'Calendar' },
      { id:'calendar',      icon:'calendar',label:'School Calendar' },
      { section:'Reporting & Intelligence' },
      { id:'reports',       icon:'history', label:'Reports' },
      { section:'Administration' },
      { id:'accounts',      icon:'cog',     label:'Accounts' },
      { id:'import',        icon:'plus',    label:'Import Data' },
      { id:'documents',     icon:'book',    label:'Documents' },
      { id:'audit',         icon:'history', label:'Audit Log' },
      { id:'config',        icon:'cog',     label:'Institution Settings' },
      { section:'Support' },
      { id:'support',       icon:'compass', label:'Support' },
      { id:'reclamations',  icon:'warn',    label:'Reclamations' },
      { section:'Account' },
      { id:'account',       icon:'cog',     label:'Profile & Security' },
      { id:'subscription',  icon:'card',    label:'Subscription' },
    ],
    school: [
      { section:'Overview' },
      { id:'home',                icon:'grid',    label:'School Dashboard' },
      { id:'pulse',               icon:'star',    label:'School Pulse' },
      { id:'changed',             icon:'history', label:'What Changed?' },
      { id:'problems',            icon:'warn',    label:'Problem Detection' },
      { id:'intelligence',        icon:'compass', label:'School Intelligence' },
      { section:'Analytics' },
      { id:'analytics-basic',     icon:'chart',   label:'Basic School Analytics' },
      { id:'analytics-advanced',  icon:'chart',   label:'Advanced School Analytics' },
      { id:'analytics-schoolwide',icon:'chart',   label:'Advanced School-Wide Analytics' },
      { id:'analytics-complete',  icon:'trophy',  label:'Complete Institution Analytics' },
      { id:'historical-comparisons', icon:'history', label:'Historical Comparisons' },
      { id:'historical-advanced', icon:'history', label:'Advanced Historical Analysis' },
      { section:'Operations' },
      { id:'enrollment',          icon:'plus',    label:'Student Enrollment' },
      { id:'admissions',          icon:'plus',    label:'Admissions' },
      { id:'orientation',         icon:'compass', label:'Orientation' },
      { id:'calendar',            icon:'calendar',label:'School Calendar' },
      { id:'communication',       icon:'msg',     label:'School Communication' },
      { id:'reclamations',        icon:'warn',    label:'Reclamation Management' },
      { section:'Finance' },
      { id:'payments',            icon:'card',    label:'School Payments' },
      { id:'payment-records',     icon:'card',    label:'Payment Records' },
      { id:'payments-advanced',   icon:'card',    label:'Advanced Payments' },
      { id:'payments-infra',      icon:'card',    label:'Advanced Payment Infrastructure' },
      { section:'Data' },
      { id:'data-management',     icon:'book',    label:'Basic Data Management' },
      { id:'import',              icon:'plus',    label:'Bulk Data Import' },
      { id:'accounts',            icon:'cog',     label:'Account Generation' },
      { id:'historical-data',     icon:'history', label:'Historical Data Management' },
      { section:'Reporting' },
      { id:'reports',             icon:'history', label:'Basic Reports' },
      { id:'reports-advanced',    icon:'history', label:'Advanced Reports' },
      { id:'reporting-advanced',  icon:'history', label:'Advanced Reporting' },
      { section:'Administration' },
      { id:'admin-basic',         icon:'cog',     label:'Basic Administration' },
      { id:'admin-advanced',      icon:'cog',     label:'Advanced Administration' },
      { id:'config',              icon:'cog',     label:'Advanced Institution Configuration' },
      { id:'audit',               icon:'history', label:'Audit Logs' },
      { id:'audit-advanced',      icon:'history', label:'Advanced Audit Logs' },
      { id:'subscription',        icon:'card',    label:'Subscription Management' },
      { section:'Institution' },
      { id:'campuses',            icon:'school',  label:'Campus Management' },
      { id:'branding',            icon:'star',    label:'Branding / White Label' },
    ],
  };

  const icons = {
    grid:  `<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>`,
    edit:  `<path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/>`,
    check: `<path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1-2-2h11"/>`,
    book:  `<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>`,
    bell:  `<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>`,
    users: `<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>`,
    warn:  `<path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>`,
    msg:   `<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>`,
    card:  `<rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/>`,
    plus:  `<circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/>`,
    cog:   `<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>`,
    clock: `<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>`,
    chart: `<path d="M3 3v18h18"/><path d="M18.7 8l-5.1 5.1-2.8-2.8L7 14"/>`,
    star:  `<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>`,
    trophy:`<path d="M8 21h8"/><path d="M12 17v4"/><path d="M7 4h10v5a5 5 0 0 1-10 0V4z"/><path d="M7 5H4a3 3 0 0 0 3 5"/><path d="M17 5h3a3 3 0 0 1-3 5"/>`,
    compass:`<circle cx="12" cy="12" r="10"/><polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76"/>`,
    history:`<path d="M3 3v5h5"/><path d="M3.05 13A9 9 0 1 0 6 5.3L3 8"/><path d="M12 7v5l4 2"/>`,
    calendar:`<rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>`,
    school:`<path d="M3 21h18"/><path d="M5 21V7l7-4 7 4v14"/><path d="M9 21v-6h6v6"/>`,
  };

  let html = '';
  navs[role].forEach((item, i) => {
    if (item.section) {
      html += `<div class="nav-section">${t(item.section)}</div>`;
    } else {
      const badgeHTML = item.badge
        ? `<span class="badge" style="${item.badgeRed?'background:var(--red)':item.badgeYellow?'background:var(--yellow);color:#000':''}">${item.badge}</span>`
        : '';
      html += `<div class="nav-item${item.id==='home'?' active':''}" onclick="switchView('${item.id}',this)">
        <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">${icons[item.icon]||''}</svg>
        ${t(item.label)}${badgeHTML}
      </div>`;
    }
  });
  nav.innerHTML = html;
}

/* ────────────────────────────────
   VIEW SWITCHER
──────────────────────────────── */
function switchView(viewId, navEl) {
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  navEl.classList.add('active');
  renderView(currentRole, viewId);
}

function renderDashboard(role) { renderView(role, 'home'); }

function renderView(role, viewId) {
  const titles = {
    home:'Dashboard', grades:'Grades', attendance:'Attendance', family:'Family Overview',
    subjects:'Subjects', announcements:'Announcements', messages:'Messages',
    behavior:role==='student' ? 'Behavior & Achievements' : 'Behavior Reports', payments:'Payment Management',
    register:'Register New Student', students:'Students', settings:'Settings',
    profile:'Institution Profile', subscription:'Subscription & Billing',
    staff:'Staff & Permissions', finance:'Financial Overview',
    academics:'Academics', homework:'Homework', exams:'Exams',
    performance:'Performance & Analytics', rankings:'Rankings',
    orientation:'Orientation & Future', history:'History',
    notifications:'Notifications', account:'Account & Support',
    analytics:'Analytics', achievements:'Achievements', calendar:'School Calendar',
    classes:'Classes', grading:'Grading', ai:'AI Assistant', reports:'Reports', support:'Support',
    intelligence:'School Intelligence', admissions:'Admissions', teachers:'Teachers', guardians:'Guardians',
    'academics-analytics':'Academic Analytics', risk:'Student Risk Indicators', accounts:'Account Generation',
    import:'Import Data', documents:'Documents', audit:'Audit Log', config:'Institution Settings', reclamations:'Reclamations', subscription:'Subscription',
  };
  let pageTitle = titles[viewId] || viewId;
  if (role === 'head' && viewId === 'account') pageTitle = 'Profile & Security';
  if (role === 'head' && viewId === 'home') pageTitle = 'School Dashboard';
  if (role === 'head' && viewId === 'orientation') pageTitle = 'Orientation Center';
  if (role === 'school' && viewId === 'home') pageTitle = 'School Dashboard';
  if (role === 'school' && viewId === 'communication') pageTitle = 'School Communication';
  if (role === 'school' && viewId === 'reclamations') pageTitle = 'Reclamation Management';
  if (role === 'school' && viewId === 'payments') pageTitle = 'School Payments';
  if (role === 'school' && viewId === 'import') pageTitle = 'Bulk Data Import';
  if (role === 'school' && viewId === 'audit') pageTitle = 'Audit Logs';
  if (role === 'school' && viewId === 'config') pageTitle = 'Advanced Institution Configuration';
  if (role === 'school' && viewId === 'subscription') pageTitle = 'Subscription Management';
  if (role === 'school' && viewId === 'reports') pageTitle = 'Basic Reports';
  if (role === 'school' && viewId === 'calendar') pageTitle = 'School Calendar';
  if (role === 'guardian' && viewId === 'account') pageTitle = 'Profile & Security';
  if (role === 'guardian' && viewId === 'grades') pageTitle = 'Grades & Exams';
  if (role === 'guardian' && viewId === 'history') pageTitle = 'Reports & History';
  if (role === 'guardian' && viewId === 'attendance') pageTitle = 'Attendance Center';
  if (role === 'guardian' && viewId === 'messages') pageTitle = 'Communication';
  if (role === 'guardian' && viewId === 'analytics') pageTitle = 'Child 360';
  if (role === 'teacher' && viewId === 'account') pageTitle = 'Profile & Security';
  document.getElementById('page-title').textContent = t(pageTitle);
  document.getElementById('page-sub').textContent = role === 'guardian'
    ? t('Wednesday, 12 March 2026')
    : t('Wednesday, 12 March 2026 — Al Farabi Private School');

  const c = document.getElementById('dash-content');
  c.style.animation = 'none';
  c.offsetHeight;
  c.style.animation = '';

  if (role === 'student') { c.innerHTML = studentView(viewId); if (typeof afterStudentRender === 'function') afterStudentRender(viewId); }
  else if (role === 'guardian') { c.innerHTML = guardianView(viewId); if (typeof gdMountSwitcher === 'function') gdMountSwitcher(); }
  else if (role === 'teacher') c.innerHTML = teacherView(viewId);
  else if (role === 'head') c.innerHTML = headView(viewId);
  else if (role === 'school') c.innerHTML = schoolView(viewId);
  else c.innerHTML = `<div class="card"><div class="card-body" style="color:var(--muted);text-align:center;padding:40px">${t('This section is coming soon.')}</div></div>`;
}

