
/* ════════════════════════════════════════════════════════════
   AUTHREN — ENTITLEMENT LAYER

   PRODUCT DECISION (explicit, not the brief's original "lock with an
   upgrade prompt"): an unentitled feature does not exist in the account
   at all. No lock icons, no "upgrade to unlock" nagging anywhere in a
   role's own navigation. For Student, Guardian, Teacher and Head, a
   feature above the institution's plan is simply absent from the sidebar
   and cannot be reached even by URL/programmatic navigation.

   The one exception is deliberate: the paying customer needs a way to
   discover what a higher plan offers, or upgrades never happen. The
   Institution Owner (and only the Owner) gets a "Plans" page — the same
   catalog already shown on the public pricing page — reached from
   Administration. That page is comparison, not nagging: nothing else in
   the Owner's own nav is locked or hinted at either.

   AUTHREN_FEATURE_KEYS maps every nav item across all five roles to the
   plan tier it first appears in (cumulative — GROWTH includes START,
   etc.). Deny by default: a nav id with no entry here is treated as
   requiring ELITE, so a future nav item is never accidentally exposed to
   every plan by omission.
════════════════════════════════════════════════════════════ */

const AUTHREN_FEATURE_KEYS = {
  /* ── Student ── */
  'student:home':'START', 'student:academics':'START', 'student:attendance':'START',
  'student:timetable':'START', 'student:homework':'START', 'student:exams':'START',
  'student:notifications':'START', 'student:account':'START',
  'student:performance':'COMMAND', 'student:behavior':'GROWTH', 'student:rankings':'COMMAND',
  'student:orientation':'GROWTH', 'student:history':'GROWTH',

  /* ── Guardian ── */
  'guardian:home':'START', 'guardian:family':'START', 'guardian:calendar':'START',
  'guardian:grades':'START', 'guardian:homework':'START', 'guardian:attendance':'START',
  'guardian:timetable':'START', 'guardian:messages':'START', 'guardian:account':'START',
  'guardian:payments':'GROWTH', 'guardian:history':'GROWTH',
  'guardian:analytics':'ELITE',

  /* ── Teacher ── */
  'teacher:home':'START', 'teacher:classes':'START', 'teacher:attendance':'START',
  'teacher:timetable':'START', 'teacher:grading':'START', 'teacher:exams':'START',
  'teacher:homework':'START', 'teacher:messages':'START', 'teacher:account':'START',
  'teacher:support':'START',
  'teacher:analytics':'GROWTH', 'teacher:behavior':'GROWTH', 'teacher:reports':'COMMAND',

  /* ── Head of Institution ── */
  'head:home':'START', 'head:students':'START', 'head:teachers':'START',
  'head:guardians':'START', 'head:classes':'START', 'head:admissions':'START',
  'head:grades':'START', 'head:exams':'START', 'head:homework':'START',
  'head:attendance':'START', 'head:timetable':'START', 'head:behavior':'START',
  'head:calendar':'START', 'head:communication':'START', 'head:support':'START',
  'head:account':'START', 'head:subscription':'START',
  'head:orientation':'GROWTH', 'head:payments':'GROWTH', 'head:reclamations':'GROWTH',
  'head:accounts':'GROWTH', 'head:import':'GROWTH',
  'head:intelligence':'COMMAND', 'head:academics-analytics':'COMMAND', 'head:risk':'COMMAND',
  'head:reports':'COMMAND',
  'head:documents':'ELITE', 'head:audit':'ELITE', 'head:config':'ELITE',

  /* ── School / Institution ── */
  'school:home':'START', 'school:enrollment':'START', 'school:admissions':'START',
  'school:calendar':'START', 'school:communication':'START', 'school:analytics-basic':'START',
  'school:reports':'START', 'school:data-management':'START', 'school:admin-basic':'START',
  'school:subscription':'START', 'school:plans':'START',
  'school:orientation':'GROWTH', 'school:payments':'GROWTH', 'school:payment-records':'GROWTH',
  'school:reclamations':'GROWTH', 'school:import':'GROWTH', 'school:analytics-advanced':'GROWTH',
  'school:pulse':'COMMAND', 'school:changed':'COMMAND', 'school:problems':'COMMAND',
  'school:analytics-schoolwide':'COMMAND', 'school:reports-advanced':'COMMAND',
  'school:historical-comparisons':'COMMAND', 'school:payments-advanced':'COMMAND',
  'school:admin-advanced':'COMMAND',
  'school:intelligence':'ELITE', 'school:analytics-complete':'ELITE',
  'school:historical-advanced':'ELITE', 'school:reporting-advanced':'ELITE',
  'school:payments-infra':'ELITE', 'school:historical-data':'ELITE',
  'school:accounts':'ELITE', 'school:config':'ELITE', 'school:audit':'ELITE',
  'school:audit-advanced':'ELITE', 'school:campuses':'ELITE', 'school:branding':'ELITE',
};

const AUTHREN_TIER_RANK = { START: 0, GROWTH: 1, COMMAND: 2, ELITE: 3 };

/* The institution's current plan, read from whichever role dataset is
   loaded. All five roles share one institution, so this must resolve the
   same value everywhere. */
function authrenCurrentPlanId() {
  if (typeof SCHOOL_DATA !== 'undefined' && SCHOOL_DATA.subscription) return SCHOOL_DATA.subscription.currentPlan;
  if (typeof HEAD_DATA !== 'undefined' && HEAD_DATA.subscription) return HEAD_DATA.subscription.currentPlan;
  return 'START';
}

function authrenMinPlanFor(role, navId) {
  return AUTHREN_FEATURE_KEYS[role + ':' + navId] || 'ELITE';
}

/* Deny by default: an error resolving the current plan is treated as the
   lowest tier, never as unrestricted access. */
function authrenHasFeature(role, navId) {
  const min = authrenMinPlanFor(role, navId);
  const current = authrenCurrentPlanId();
  const minRank = AUTHREN_TIER_RANK[min];
  const curRank = AUTHREN_TIER_RANK[current];
  if (minRank === undefined) return false;
  if (curRank === undefined) return false;
  return curRank >= minRank;
}
