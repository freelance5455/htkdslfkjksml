/* ═══════════════════════════════
   STUDENT VIEWS
═══════════════════════════════ */
/* ══════════════════════════════════════════════════════
   STUDENT EXPERIENCE — DATA
══════════════════════════════════════════════════════ */
/* Each subject carries per-exam detail (examsT1/examsT2) so semester averages,
   "exams left" messaging, missing-point charts and exam tables can all be derived
   from one source of truth instead of a fixed pre-computed score.
   score:null on an exam entry means it has not been taken/graded yet. */
const STUDENT_DATA = {
  /* Identity — links this student to their class in the shared school
     timetable (see js/timetable.js). Matches the guardian record for the
     same child (Grade 10 - A) and the teachers listed under subjects. */
  profile: { name: 'Youssef Amrani', studentId: 'S12345678', class: 'Grade 10 - A' },
  subjects: [
    { id:'math', name:'Mathematics', teacher:'Mr. Bensalem', icon:'🔢', weight:4,
      examsT1:[ {n:1,title:'Quiz 1',score:17.5,date:'Oct 14, 2025'}, {n:2,title:'Test 2',score:18,date:'Nov 20, 2025'}, {n:3,title:'Term 1 Exam',score:18.5,date:'Dec 15, 2025'} ],
      examsT2:[ {n:1,title:'Quiz 1',score:17,date:'Jan 22, 2026'}, {n:2,title:'Test 2',score:17,date:'Feb 19, 2026'}, {n:3,title:'Term 2 Exam',score:null,date:'Mar 26, 2026'} ],
      classAvgT1:15.5, classAvgT2:15.8, rankT1:'#2 / 28', rankT2:'#3 / 28', rankYear:'#2 / 28' },
    { id:'phys', name:'Physics',     teacher:'Ms. Rachidi',  icon:'⚗️', weight:3,
      examsT1:[ {n:1,title:'Quiz 1',score:14.5,date:'Oct 10, 2025'}, {n:2,title:'Test 2',score:15,date:'Nov 18, 2025'}, {n:3,title:'Term 1 Exam',score:15.5,date:'Dec 12, 2025'} ],
      examsT2:[ {n:1,title:'Quiz 1',score:16.5,date:'Jan 20, 2026'}, {n:2,title:'Test 2',score:17.5,date:'Feb 17, 2026'}, {n:3,title:'Term 2 Exam',score:null,date:'Mar 28, 2026'} ],
      classAvgT1:13.6, classAvgT2:14.0, rankT1:'#6 / 28', rankT2:'#4 / 28', rankYear:'#5 / 28' },
    { id:'fr',   name:'French',      teacher:'Mr. Tahiri',   icon:'🇫🇷', weight:3,
      examsT1:[ {n:1,title:'Dictée 1',score:12.5,date:'Oct 8, 2025'}, {n:2,title:'Essay 2',score:13,date:'Nov 14, 2025'}, {n:3,title:'Term 1 Exam',score:13.5,date:'Dec 10, 2025'} ],
      examsT2:[ {n:1,title:'Dictée 3',score:14.5,date:'Jan 16, 2026'}, {n:2,title:'Oral Presentation',score:15.5,date:'Feb 13, 2026'}, {n:3,title:'Term 2 Exam',score:15,date:'Mar 6, 2026'} ],
      classAvgT1:12.8, classAvgT2:13.5, rankT1:'#9 / 28', rankT2:'#7 / 28', rankYear:'#8 / 28' },
    { id:'ar',   name:'Arabic',      teacher:'Ms. Ouali',    icon:'📖', weight:2,
      examsT1:[ {n:1,title:'Quiz 1',score:13.5,date:'Oct 9, 2025'}, {n:2,title:'Grammar Test',score:14,date:'Nov 16, 2025'}, {n:3,title:'Term 1 Exam',score:14.5,date:'Dec 11, 2025'} ],
      examsT2:[ {n:1,title:'Quiz 3',score:15.5,date:'Jan 18, 2026'}, {n:2,title:'Grammar Test',score:16.5,date:'Feb 15, 2026'}, {n:3,title:'Term 2 Exam',score:null,date:'Mar 27, 2026'} ],
      classAvgT1:13.2, classAvgT2:13.8, rankT1:'#7 / 28', rankT2:'#6 / 28', rankYear:'#6 / 28' },
    { id:'en',   name:'English',     teacher:'Mr. Fassi',    icon:'🇬🇧', weight:2,
      examsT1:[ {n:1,title:'Quiz 1',score:18.5,date:'Oct 13, 2025'}, {n:2,title:'Reading Test',score:19,date:'Nov 19, 2025'}, {n:3,title:'Term 1 Exam',score:19.5,date:'Dec 14, 2025'} ],
      examsT2:[ {n:1,title:'Reading Comprehension',score:17.5,date:'Mar 1, 2026'}, {n:2,title:'Quiz 2',score:18.5,date:'Feb 12, 2026'}, {n:3,title:'Term 2 Exam',score:18,date:'Mar 22, 2026'} ],
      classAvgT1:16.5, classAvgT2:16.8, rankT1:'#1 / 28', rankT2:'#2 / 28', rankYear:'#1 / 28' },
    { id:'hist', name:'History',     teacher:'Ms. Bennis',   icon:'🏺', weight:2,
      examsT1:[ {n:1,title:'Quiz 1',score:10.5,date:'Oct 7, 2025'}, {n:2,title:'Chapter 2 Test',score:11,date:'Nov 12, 2025'}, {n:3,title:'Term 1 Exam',score:11.5,date:'Dec 9, 2025'} ],
      examsT2:[ {n:1,title:'Chapter 3 Test',score:11.5,date:'Mar 4, 2026'}, {n:2,title:'Timeline Project',score:null,date:'Mar 25, 2026'}, {n:3,title:'Term 2 Exam',score:null,date:'Apr 1, 2026'} ],
      classAvgT1:11.5, classAvgT2:12.0, rankT1:'#12 / 28', rankT2:'#13 / 28', rankYear:'#12 / 28' },
  ],
  examsUpcoming: [
    { id:'e1', subject:'Physics',     title:'Chapter 5 Test — waves, optics', inDays:6,  time:'09:00' },
    { id:'e2', subject:'Mathematics', title:'Term 3 Exam',                    inDays:13, time:'08:00' },
    { id:'e3', subject:'History',     title:'Chapter 3 Test',                 inDays:20, time:'10:30' },
    { id:'e4', subject:'French',      title:'Oral Presentation',              inDays:27, time:'11:00' },
  ],
  examsPast: [
    { id:'p1', subject:'Mathematics', title:'Chapter 4 Quiz',   date:'Mar 10, 2026', score:17, max:20 },
    { id:'p2', subject:'Physics',     title:'Mid-Term Exam',    date:'Mar 8, 2026',  score:16, max:20 },
    { id:'p3', subject:'French',      title:'Dictée #3',        date:'Mar 6, 2026',  score:14, max:20 },
    { id:'p4', subject:'History',     title:'Chapter 2 Test',   date:'Mar 4, 2026',  score:11, max:20 },
    { id:'p5', subject:'English',     title:'Reading Comprehension', date:'Mar 1, 2026', score:18, max:20 },
    { id:'p6', subject:'Arabic',      title:'Chapter 3 Quiz',   date:'Feb 24, 2026', score:15, max:20 },
  ],
  homework: [
    { id:'h1', subject:'Mathematics', title:'Exercises 12–18, page 54', due:'Tomorrow',        dueDays:1,  status:'pending' },
    { id:'h2', subject:'French',      title:'Essay — "Le voyage"',      due:'In 3 days',        dueDays:3,  status:'pending' },
    { id:'h3', subject:'Physics',     title:'Lab report — optics',      due:'In 5 days',        dueDays:5,  status:'pending' },
    { id:'h4', subject:'English',     title:'Reading — Chapter 7',      due:'Completed Mar 9',  dueDays:-3, status:'done' },
    { id:'h5', subject:'Arabic',      title:'Grammar worksheet',        due:'Completed Mar 6',  dueDays:-6, status:'done' },
    { id:'h6', subject:'History',     title:'Timeline project',         due:'Completed Mar 2',  dueDays:-10,status:'done' },
    { id:'h7', subject:'Mathematics', title:'Worksheet — fractions',    due:'Completed Feb 26', dueDays:-14,status:'done' },
  ],
  attendance: {
    rate: 94, present: 52, absentJustified: 2, absentUnjustified: 1, late: 3,
    streak: 14, bestStreak: 22,
    // 0=none,1=present,2=absent-justified,3=absent-unjustified,4=late
    marchDays: [1,1,1,4,1,1,0,0,1,1,1,1,1,0,0,1,1,3,1,1,0,0,1,1,1,4,1,0,0,0,0],
    monthlyRate: [ {m:'Oct',v:96}, {m:'Nov',v:92}, {m:'Dec',v:95}, {m:'Jan',v:90}, {m:'Feb',v:93}, {m:'Mar',v:94} ],
    // Underlying source of truth for both the Calendar and Absence History
    // views, so the two stay consistent. month is 0-indexed (2 = March).
    absenceLog: [
      { id:'ab1', date:'Mar 26, 2026', day:26, month:2, year:2026, subject:'Physics', status:'late', note:'Arrived 10 minutes late.' },
      { id:'ab2', date:'Mar 18, 2026', day:18, month:2, year:2026, subject:'Arabic',  status:'unjustified', note:null, justificationSubmitted:false, justificationText:'' },
      { id:'ab3', date:'Mar 4, 2026',  day:4,  month:2, year:2026, subject:'Mathematics', status:'late', note:'Bus delay.' },
      { id:'ab4', date:'Feb 21, 2026', day:21, month:1, year:2026, subject:'Physics', status:'justified', note:'Medical appointment.' },
      { id:'ab5', date:'Feb 4, 2026',  day:4,  month:1, year:2026, subject:'History', status:'justified', note:'Family event.' },
    ],
  },
  badges: [
    // Academic Excellence
    { id:'b1', category:'Academic Excellence', name:'Honor Roll',   emoji:'🏅', earned:true,  date:'Feb 20, 2026', desc:'Overall average above 15/20 for the term.' },
    { id:'b7', category:'Academic Excellence', name:'Perfect Score',emoji:'💯', earned:false, desc:'Score 20/20 on any exam.' },
    { id:'b9', category:'Academic Excellence', name:'Subject Master', emoji:'🎓', earned:true, date:'Mar 2, 2026', desc:'Reach a year average above 18/20 in any subject.' },
    { id:'b8', category:'Academic Excellence', name:'Well Rounded', emoji:'🧭', earned:false, desc:'Score above 14/20 in every subject.' },
    // Improvement
    { id:'b4', category:'Improvement', name:'Rising Star',  emoji:'⭐', earned:true,  date:'Jan 30, 2026', desc:'Improved average by 1+ point over one term.' },
    { id:'b10', category:'Improvement', name:'Steady Climb', emoji:'📈', earned:true, date:'Mar 10, 2026', desc:'Positive overall-average trend across 3 consecutive exam periods.' },
    { id:'b11', category:'Improvement', name:'Comeback Kid', emoji:'🔁', earned:false, desc:'Bring a subject average from below 10/20 back above 12/20.' },
    // Attendance
    { id:'b5', category:'Attendance', name:'Streak Master',emoji:'🔥', earned:false, desc:'Reach a 30-day attendance streak.' },
    { id:'b12', category:'Attendance', name:'Perfect Month', emoji:'📅', earned:true, date:'Nov 1, 2025', desc:'Zero absences in a full calendar month.' },
    { id:'b13', category:'Attendance', name:'Always On Time', emoji:'⏰', earned:false, desc:'No late arrivals for a full term.' },
    // Homework Consistency
    { id:'b3', category:'Homework Consistency', name:'Bookworm',     emoji:'📚', earned:true,  date:'Feb 12, 2026', desc:'Completed 10 homework assignments in a row.' },
    { id:'b14', category:'Homework Consistency', name:'Consistency Champion', emoji:'🧩', earned:true, date:'Feb 25, 2026', desc:'30 homework assignments completed without missing a deadline.' },
    { id:'b15', category:'Homework Consistency', name:'Early Bird', emoji:'🌅', earned:true, date:'Jan 18, 2026', desc:'Submitted 5 homework assignments before the deadline.' },
    // Participation
    { id:'b16', category:'Participation', name:'Active Voice', emoji:'🙋', earned:true, date:'Mar 12, 2026', desc:'Participated in class discussion for 10 consecutive sessions.' },
    { id:'b17', category:'Participation', name:'Debate Star', emoji:'🎤', earned:true, date:'Mar 5, 2026', desc:'Recognized for an outstanding contribution in a class debate.' },
    // Positive Behavior
    { id:'b2', category:'Positive Behavior', name:'Perfect Week', emoji:'🎯', earned:true,  date:'Mar 7, 2026', desc:'5 consecutive days present and on time.' },
    { id:'b18', category:'Positive Behavior', name:'Team Player', emoji:'🤝', earned:true, date:'Mar 10, 2026', desc:'Received a positive note for helping classmates.' },
    { id:'b19', category:'Positive Behavior', name:'Leadership Spark', emoji:'🧑‍🏫', earned:true, date:'Feb 22, 2026', desc:'Volunteered to lead a study group.' },
    // Achievement Milestones
    { id:'b6', category:'Achievement Milestones', name:'Top 3', emoji:'🥉', earned:false, desc:'Finish in the top 3 of your class ranking.' },
    { id:'b20', category:'Achievement Milestones', name:'Century Club', emoji:'💫', earned:true, date:'Mar 20, 2026', desc:'Earn 10 badges total.' },
    { id:'b21', category:'Achievement Milestones', name:'Year One Complete', emoji:'🎉', earned:true, date:'Jun 20, 2025', desc:'Completed a full academic year at Authren.' },
    // Personal Goals
    { id:'b22', category:'Personal Goals', name:'Goal Setter', emoji:'🧭', earned:true, date:'Oct 5, 2025', desc:'Created your first personal goal.' },
    { id:'b23', category:'Personal Goals', name:'Goal Getter', emoji:'🏆', earned:false, desc:'Completed a personal goal you set for yourself.' },
    // Academic Consistency
    { id:'b24', category:'Academic Consistency', name:'Reliable Performer', emoji:'🛡️', earned:true, date:'Mar 20, 2026', desc:'Overall average stayed above 12/20 across every exam period this year.' },
    { id:'b25', category:'Academic Consistency', name:'Steady Attendee', emoji:'📌', earned:true, date:'Feb 1, 2026', desc:'Attendance rate stayed at or above 90% for 3 consecutive months.' },
  ],
  goals: [
    { id:'g1', title:'Reach 17/20 overall average', metric:'average', target:17, current:15.4, unit:'/20' },
    { id:'g2', title:'Improve Physics average to 18', metric:'physics', target:18, current:16, unit:'/20' },
    { id:'g3', title:'Keep attendance streak above 20 days', metric:'streak', target:20, current:14, unit:' days' },
  ],
  behaviorLog: [
    { date:'Mar 10, 2026', type:'positive', note:'Helped classmates during group project in Physics.', teacher:'Ms. Rachidi' },
    { date:'Mar 5, 2026',  type:'positive', note:'Excellent participation in class debate.', teacher:'Mr. Tahiri' },
    { date:'Feb 22, 2026', type:'positive', note:'Volunteered to lead the Math study group.', teacher:'Mr. Bensalem' },
    { date:'Feb 14, 2026', type:'note', note:'Talked during quiet study time — reminded of classroom rules.', teacher:'Ms. Bennis' },
  ],
  participation: [ {m:'Oct',v:72},{m:'Nov',v:75},{m:'Dec',v:78},{m:'Jan',v:80},{m:'Feb',v:85},{m:'Mar',v:88} ],
  rankingsMonthly: [
    { name:'Salma Benjelloun', val:18.6 }, { name:'Yassine Kabbaj', val:17.9 }, { name:'Nadia Fassi', val:17.2 },
    { name:'Karim Lahlou', val:16.8 }, { name:'Youssef Amrani (You)', val:15.4, me:true },
    { name:'Rania Tazi', val:15.1 }, { name:'Omar Haddaoui', val:14.8 }, { name:'Sara Mansouri', val:14.2 },
  ],
  rankingsAllTime: [
    { name:'Salma Benjelloun', val:18.1 }, { name:'Nadia Fassi', val:17.6 }, { name:'Yassine Kabbaj', val:17.4 },
    { name:'Youssef Amrani (You)', val:15.9, me:true }, { name:'Karim Lahlou', val:15.7 },
    { name:'Rania Tazi', val:15.0 }, { name:'Omar Haddaoui', val:14.6 },
  ],
  rankingsCategory: {
    attendance:  [ {name:'Nadia Fassi',val:'99%'},{name:'Omar Haddaoui',val:'98%'},{name:'Youssef Amrani (You)',val:'94%',me:true},{name:'Sara Mansouri',val:'93%'},{name:'Karim Lahlou',val:'90%'} ],
    homework:    [ {name:'Salma Benjelloun',val:'100%'},{name:'Youssef Amrani (You)',val:'96%',me:true},{name:'Rania Tazi',val:'94%'},{name:'Yassine Kabbaj',val:'91%'},{name:'Omar Haddaoui',val:'88%'} ],
    improvement: [ {name:'Karim Lahlou',val:'+2.4'},{name:'Youssef Amrani (You)',val:'+1.6',me:true},{name:'Sara Mansouri',val:'+1.2'},{name:'Nadia Fassi',val:'+0.9'},{name:'Omar Haddaoui',val:'+0.5'} ],
    behavior:    [ {name:'Nadia Fassi',val:'12 notes'},{name:'Youssef Amrani (You)',val:'9 notes',me:true},{name:'Salma Benjelloun',val:'8 notes'},{name:'Rania Tazi',val:'7 notes'} ],
  },
  orientationPaths: [
    { id:'sci', tag:'Study Path', name:'Sciences Mathématiques', desc:'A path centered on advanced mathematics and physics — a strong fit given current Math and Physics averages.', match:'Strong match' },
    { id:'eco', tag:'Study Path', name:'Sciences Économiques', desc:'Combines economics, management and mathematics for students interested in business and finance.', match:'Good match' },
    { id:'lit', tag:'Study Path', name:'Lettres Modernes', desc:'Focused on languages and literature — suits strong performance in French and English.', match:'Good match' },
  ],
  orientationPrograms: [
    { id:'pr1', tag:'Post-Bac', name:'CPGE — Classes Préparatoires (MPSI)', desc:'Two-year intensive preparatory program for engineering schools, math/physics focused.' },
    { id:'pr2', tag:'Post-Bac', name:'ENSA — Engineering Cycle', desc:'Five-year integrated engineering program with a common-core first two years.' },
    { id:'pr3', tag:'Post-Bac', name:'Faculté des Sciences — Physics', desc:'University track with a research-oriented physics curriculum.' },
    { id:'pr4', tag:'Post-Bac', name:'ENCG — Business School', desc:'Management and commerce program with an entrance exam after Bac.' },
  ],
  orientationCareers: [
    { id:'c1', tag:'Career Path', name:'Engineering', desc:'Mechanical, civil, industrial or software engineering — aligned with strong Math/Physics results.' },
    { id:'c2', tag:'Career Path', name:'Data & Research', desc:'Data analysis, applied research or academia — benefits from strong quantitative subjects.' },
    { id:'c3', tag:'Career Path', name:'Business & Finance', desc:'Management, finance or entrepreneurship — pairs well with Economics-track studies.' },
  ],
  historyYears: {
    '2025/26': { avg:15.4, attendance:94, rank:'#5 / 28', achievements:4, note:'Current year — Term 2 in progress.' },
    '2024/25': { avg:14.6, attendance:91, rank:'#8 / 27', achievements:3, note:'Completed Grade 2 Bac Sciences with steady improvement.' },
    '2023/24': { avg:13.9, attendance:89, rank:'#11 / 26', achievements:2, note:'First year at Al Farabi Private School.' },
  },
  notifications: [
    { id:'n1', type:'exam',   icon:'🧪', tag:'Upcoming Exam',  title:'Physics — Chapter 5 Test', desc:'Scheduled in 6 days. Topics: waves, optics.', time:'2h ago', unread:true },
    { id:'n2', type:'absence',icon:'⚠️', tag:'Absence Alert',  title:'Unexcused absence recorded', desc:'March 18 — Arabic class. Please provide a justification.', time:'1d ago', unread:true },
    { id:'n3', type:'info',   icon:'📢', tag:'Announcement',   title:'Term 3 exams — March 25–28', desc:'Full exam timetable now available in Exams.', time:'2d ago', unread:true },
    { id:'n4', type:'grade',  icon:'✅', tag:'Grade Released', title:'Math Chapter 4 Quiz — 17/20', desc:'Your result has been posted by Mr. Bensalem.', time:'2d ago', unread:true },
    { id:'n5', type:'badge',  icon:'🎯', tag:'Achievement',    title:'You earned "Perfect Week"', desc:'5 consecutive days present and on time.', time:'5d ago', unread:false },
    { id:'n6', type:'homework',icon:'📝',tag:'Homework Due',   title:'French essay due in 3 days', desc:'"Le voyage" — submit via your teacher.', time:'6d ago', unread:false },
  ],
  account: { email: 'youssef.amrani@student.authren.ma' },
  // Replies received from teachers / the Head of Institution via Contact Support.
  inboxMessages: [
    { id:'im1', sender:'Mr. Bensalem', senderType:'teacher', topic:'Grades / Academics', preview:'Thanks for your question about the last quiz — here is the breakdown...', body:'Thanks for reaching out about the last Math quiz. The two points off were on question 4 (missing units) and question 7 (calculation error). Happy to go over it together after class this week.', date:'Mar 20, 2026', read:false },
    { id:'im2', sender:'Head of Institution', senderType:'head', topic:'Other', preview:'Your request regarding the schedule change has been reviewed...', body:'Your request regarding the schedule change has been reviewed. We are unable to move the Physics exam, but a make-up session can be arranged if needed — please confirm with the school office.', date:'Mar 15, 2026', read:true },
    { id:'im3', sender:'Ms. Rachidi', senderType:'teacher', topic:'Attendance', preview:'Got your note about being late on the 26th — no issue at all.', body:'Got your note about being late on the 26th — no issue at all, thanks for letting me know in advance next time if possible.', date:'Mar 5, 2026', read:true },
  ],
};

/* ═══════════════════════════════
   GRADE / EXAM COMPUTATION HELPERS
   Single source of truth for semester + year stats, derived from
   each subject's examsT1/examsT2 arrays (score:null = not yet taken).
═══════════════════════════════ */
function stExamList(subject, term) { return term === 't1' ? subject.examsT1 : subject.examsT2; }

// { avg, completed, total, left, isComplete } for one subject + one term ('t1'|'t2')
function stSemesterStat(subject, term) {
  const list = stExamList(subject, term);
  const done = list.filter(e => e.score !== null && e.score !== undefined);
  const total = list.length;
  const completed = done.length;
  const avg = completed ? done.reduce((a,e)=>a+e.score,0) / completed : null;
  return { avg, completed, total, left: total - completed, isComplete: completed === total };
}

// Year Score per subject = average of the two semester averages (partial-aware).
function stYearStat(subject) {
  const s1 = stSemesterStat(subject, 't1');
  const s2 = stSemesterStat(subject, 't2');
  const avgs = [s1.avg, s2.avg].filter(v => v !== null);
  const avg = avgs.length ? avgs.reduce((a,b)=>a+b,0) / avgs.length : null;
  return { avg, s1, s2, isComplete: s1.isComplete && s2.isComplete };
}

// Overall (all-subject, weighted) average for a given term ('t1'|'t2'|'year').
// Only subjects with at least one completed exam contribute; isComplete is false
// if ANY subject still has exams pending for that term, so the UI can show
// "Based on completed exams" instead of presenting a partial number as final.
function stOverallStat(term) {
  const subs = STUDENT_DATA.subjects;
  let sum = 0, wsum = 0, allComplete = true;
  subs.forEach(sub => {
    const stat = term === 'year' ? stYearStat(sub) : stSemesterStat(sub, term);
    if (!stat.isComplete) allComplete = false;
    if (stat.avg !== null) { sum += stat.avg * sub.weight; wsum += sub.weight; }
  });
  return { avg: wsum ? sum / wsum : null, isComplete: allComplete };
}

// Back-compat: overall average across the full year, used by widgets that
// don't care which term (dashboard hero stat, calculators, insights).
function stOverallAvg() { const st = stOverallStat('year'); return st.avg || 0; }

/* Attach convenience fields so existing call sites that read s.t1 / s.t2 / s.trend
   keep working while newer code uses stSemesterStat / stYearStat directly. */
STUDENT_DATA.subjects.forEach(s => {
  const st1 = stSemesterStat(s, 't1'), st2 = stSemesterStat(s, 't2'), sy = stYearStat(s);
  s.t1 = st1.avg; s.t2 = st2.avg; s.yearAvg = sy.avg;
  s.trend = s.examsT1.concat(s.examsT2).filter(e=>e.score!==null).map(e=>e.score);
});

const stState = {
  tab: {
    academics:'grades', attendance:'calendar', homework:'list', exams:'upcoming',
    performance:'360', behavior:'behavior', rankings:'monthly', orientation:'paths',
    history:'2025/26', notifications:'all', account:'profile',
  },
  calMonth: 2, calYear: 2026, // March 2026 (0-indexed month=2)
  rankCategory: 'attendance',
  goalDraft: null,
  academicsPeriod: 't1',
  examsSelection: { year:'2025/26', period:null },
  teacherRating: { teacherId:null, ratings:{}, notes:{} },
  supportFlow: { recipientType:null, teacherId:null, topic:null, customTopic:'' },
  pendingEmail: '',
  radarShowStudent: true,
  radarShowClass: true,
};

/* ═══════════════════════════════
   STUDENT VIEW DISPATCHER
═══════════════════════════════ */
function studentView(v) {
  if (v === 'home')          return stDashboard();
  if (v === 'timetable')     return stTimetable();
  if (v === 'academics')     return stAcademics();
  if (v === 'attendance')    return stAttendance();
  if (v === 'homework')      return stHomework();
  if (v === 'exams')         return stExams();
  if (v === 'performance')   return stPerformance();
  if (v === 'behavior')      return stBehavior();
  if (v === 'rankings')      return stRankings();
  if (v === 'orientation')   return stOrientation();
  if (v === 'history')       return stHistory();
  if (v === 'notifications') return stNotifications();
  if (v === 'account')       return stAccount();
  return `<div class="card"><div class="card-body" style="color:var(--muted);text-align:center;padding:40px">${t('This section is coming soon.')}</div></div>`;
}

function afterStudentRender(v) {
  if (v === 'exams') stStartCountdowns();
  if (v === 'home') stStartCountdowns();
  stUpdateNotifDot();
}

/* generic sub-tab renderer: sets state, re-renders only the body */
function stSetTab(section, tabId, bodyFn) {
  stState.tab[section] = tabId;
  document.querySelectorAll('.st-tab[data-section="'+section+'"]').forEach(elm=>{
    elm.classList.toggle('active', elm.dataset.tab === tabId);
  });
  const area = document.getElementById('st-body-' + section);
  if (area) area.innerHTML = bodyFnRegistry[section](tabId);
  if (section === 'exams' && tabId === 'upcoming') stStartCountdowns();
}

const bodyFnRegistry = {};

function stTabsBar(section, tabs) {
  const active = stState.tab[section];
  return `<div class="st-tabs">${tabs.map(tb => `
    <div class="st-tab${tb.id===active?' active':''}" data-section="${section}" data-tab="${tb.id}" onclick="stSetTab('${section}','${tb.id}')">${t(tb.label)}${tb.badge?`<span class="st-tab-badge">${tb.badge}</span>`:''}</div>
  `).join('')}</div>`;
}
/* ═══════════════════════════════
   DASHBOARD
═══════════════════════════════ */
function stDashboard() {
  const overallStat = stOverallStat('year');
  const avg = overallStat.avg != null ? overallStat.avg.toFixed(1) : '—';
  const nextExam = STUDENT_DATA.examsUpcoming[0];
  const pendingHw = STUDENT_DATA.homework.filter(h=>h.status==='pending').length;
  const unreadN = STUDENT_DATA.notifications.filter(n=>n.unread).length;
  const trend = stOverallTrendSeries();
  return `
    <div class="st-grid-4" style="margin-bottom:20px">
      <div class="stat-card blue"><div class="stat-icon blue">📊</div><div class="stat-label">${t('Overall Average')}</div><div class="stat-val">${avg}/20</div><div class="stat-change ${overallStat.isComplete?'up':''}" style="${overallStat.isComplete?'':'color:var(--yellow)'}">${overallStat.isComplete ? t('↑ +0.6 since last term') : t('Based on completed exams')}</div></div>
      <div class="stat-card green"><div class="stat-icon green">📅</div><div class="stat-label">${t('Attendance')}</div><div class="stat-val">${STUDENT_DATA.attendance.rate}%</div><div class="stat-change up">${t('🔥')} ${STUDENT_DATA.attendance.streak}${t('-day streak')}</div></div>
      <div class="stat-card cyan"><div class="stat-icon cyan">🏆</div><div class="stat-label">${t('Class Rank')}</div><div class="stat-val">#5</div><div class="stat-change up">${t('↑ out of 28 students')}</div></div>
      <div class="stat-card purple"><div class="stat-icon purple">📝</div><div class="stat-label">${t('Pending Homework')}</div><div class="stat-val">${pendingHw}</div><div class="stat-change">${t('Due this week')}</div></div>
    </div>
    <div class="grid2">
      <div>
        <div class="card">
          <div class="card-header"><div class="card-title">⏰ ${t('Next Exam')}</div><div class="card-action" onclick="document.querySelector('.nav-item[onclick*=exams]')?.click()">${t('View all →')}</div></div>
          <div class="card-body">
            <div style="font-weight:700;font-size:15px;margin-bottom:4px">${t(nextExam.subject)} — ${t(nextExam.title)}</div>
            <div class="countdown-hero" id="dash-countdown" data-indays="${nextExam.inDays}" style="margin-top:10px"></div>
          </div>
        </div>
        <div class="card" style="margin-top:20px">
          <div class="card-header"><div class="card-title">📈 ${t('Academic Trend')}</div></div>
          <div class="card-body">${stAxisChart(trend.labels, [{name:'',color:'#0a84ff',values:trend.values}], {yMax:20,yStep:5})}
            <div style="font-size:11.5px;color:var(--muted);margin-top:8px">${t('Weighted overall average across all subjects, exam by exam.')}</div>
          </div>
        </div>
        <div class="card" style="margin-top:20px">
          <div class="card-header"><div class="card-title">📚 ${t('My Subjects')}</div></div>
          <div class="card-body"><div class="subjects-grid">
            ${STUDENT_DATA.subjects.map(s=>{
              const y = stYearStat(s);
              const cur = stSemesterStat(s, 't2'); // current in-progress semester
              return `<div class="subject-card"><div class="subj-icon">${s.icon}</div><div class="subj-name">${t(s.name)}</div><div class="subj-teacher">${s.teacher}</div>
                ${!cur.isComplete
                  ? `<div class="subj-avg" style="color:var(--yellow);font-size:12px;font-weight:700">${cur.left===1?t('1 exam left'):`${cur.left} ${t('exams left')}`}</div>`
                  : `<div class="subj-avg" style="color:${stGradeColor(y.avg)}">${y.avg.toFixed(1)}</div>`}
              </div>`;
            }).join('')}
          </div></div>
        </div>
      </div>
      <div>
        <div class="card">
          <div class="card-header"><div class="card-title">🔔 ${t('Notifications')}</div><span class="badge">${unreadN}</span></div>
          <div class="card-body"><div class="notif-list">
            ${STUDENT_DATA.notifications.slice(0,4).map(n=>`
              <div class="notif-item" style="cursor:pointer" onclick="stOpenNotification('${n.id}')">
                <div class="notif-ico">${n.icon}</div>
                <div><div class="notif-tag ${n.type}">${t(n.tag)}</div><div class="notif-title">${t(n.title)}</div><div class="notif-desc">${t(n.desc)}</div><div class="notif-time">${n.time}</div></div>
              </div>`).join('')}
          </div></div>
        </div>
        <div class="card" style="margin-top:20px">
          <div class="card-header"><div class="card-title">🎯 ${t('Personal Goals')}</div></div>
          <div class="card-body" style="display:flex;flex-direction:column;gap:12px">
            ${STUDENT_DATA.goals.slice(0,2).map(g=>stGoalMini(g)).join('')}
          </div>
        </div>
        <div class="card" style="margin-top:20px">
          <div class="card-header"><div class="card-title">🏆 ${t('Class Rank')}</div></div>
          <div class="card-body"><div class="rank-display">
            <div class="rank-number">#5</div>
            <div><div class="rank-of" style="font-size:16px;color:var(--muted)">${t('out of')} <strong style="color:var(--text)">28</strong> ${t('students')}</div>
            <div style="margin-top:6px;font-size:13px;color:var(--muted)">${t('Class 3B — Based on current test averages')}</div></div>
          </div></div>
        </div>
      </div>
    </div>`;
}

function stGoalMini(g) {
  const pct = Math.min(100, Math.round((g.current/g.target)*100));
  return `<div><div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:6px"><span>${t(g.title)}</span><strong>${g.current}${g.unit} / ${g.target}${g.unit}</strong></div>
  <div class="progress-track"><div class="progress-fill ${pct>=100?'green':pct>=60?'':'yellow'}" style="width:${pct}%"></div></div></div>`;
}

function stGradeColor(v){ return v>=16?'var(--green)': v>=12?'var(--accent)': v>=10?'var(--yellow)':'var(--red)'; }

/* ─────────────────────────────────────────────────────────────
   GENERIC AXIS CHART — used everywhere a numerical line chart is
   needed (dashboard trend, subject graphs, progress graphs,
   advanced analysis, student 360...). Real X/Y axes, tick labels,
   gaps for missing (null) values instead of fabricated points.
   series: [{name, color, values}]  values[i] may be null (= not yet taken)
───────────────────────────────────────────────────────────── */
function stAxisChart(xLabels, series, opts) {
  opts = opts || {};
  const yMax = opts.yMax != null ? opts.yMax : 20;
  const yStep = opts.yStep != null ? opts.yStep : 5;
  const suffix = opts.valueSuffix || '';
  const w = opts.width || 340, h = opts.height || 180;
  const padL = 30, padR = 12, padT = 12, padB = 26;
  const plotW = w - padL - padR, plotH = h - padT - padB;
  const n = xLabels.length;
  const xPos = i => n > 1 ? padL + i * (plotW / (n - 1)) : padL + plotW / 2;
  const yPos = v => padT + plotH - (Math.max(0, Math.min(yMax, v)) / yMax) * plotH;

  // Y-axis grid + tick labels
  const ticks = [];
  for (let v = 0; v <= yMax; v += yStep) {
    const y = yPos(v);
    ticks.push(`<line x1="${padL}" y1="${y}" x2="${w-padR}" y2="${y}" stroke="var(--border,#e5e7eb)" stroke-width="1" opacity="0.5"/>`);
    ticks.push(`<text x="${padL-6}" y="${y+3}" font-size="9" fill="var(--muted,#8a8f98)" text-anchor="end">${v}${suffix}</text>`);
  }
  // axis lines
  const axes = `<line x1="${padL}" y1="${padT}" x2="${padL}" y2="${padT+plotH}" stroke="var(--muted,#8a8f98)" stroke-width="1"/>
    <line x1="${padL}" y1="${padT+plotH}" x2="${w-padR}" y2="${padT+plotH}" stroke="var(--muted,#8a8f98)" stroke-width="1"/>`;
  // X-axis labels
  const xLabelsHtml = xLabels.map((lbl,i)=>`<text x="${xPos(i)}" y="${h-6}" font-size="9" fill="var(--muted,#8a8f98)" text-anchor="middle">${lbl}</text>`).join('');

  const showPointLabels = series.length === 1;
  let seriesHtml = '';
  series.forEach(s => {
    const pts = s.values.map((v,i)=> v==null ? null : {x:xPos(i), y:yPos(v), v});
    // connect only consecutive non-null points (real gaps for missing exams)
    let segment = [];
    const segments = [];
    pts.forEach(p => { if (p) segment.push(p); else { if (segment.length>1) segments.push(segment); segment=[]; } });
    if (segment.length>1) segments.push(segment);
    const lines = segments.map(seg => `<polyline points="${seg.map(p=>`${p.x},${p.y}`).join(' ')}" fill="none" stroke="${s.color}" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>`).join('');
    const dots = pts.filter(Boolean).map(p => `<circle cx="${p.x}" cy="${p.y}" r="3.2" fill="${s.color}"><title>${p.v}${suffix}</title></circle>` +
      (showPointLabels ? `<text x="${p.x}" y="${p.y-8}" font-size="9.5" font-weight="700" fill="${s.color}" text-anchor="middle">${p.v}${suffix}</text>` : '')).join('');
    seriesHtml += lines + dots;
  });

  const legend = series.length > 1 ? `<div style="display:flex;gap:14px;flex-wrap:wrap;margin-top:6px;font-size:10.5px;color:var(--muted)">
    ${series.map(s=>`<span style="display:inline-flex;align-items:center;gap:5px"><span style="width:8px;height:8px;border-radius:50%;background:${s.color};display:inline-block"></span>${t(s.name)}</span>`).join('')}
  </div>` : '';

  return `<svg class="axis-chart" viewBox="0 0 ${w} ${h}" width="100%" height="${h}" preserveAspectRatio="xMidYMid meet">
    ${ticks.join('')}${axes}${xLabelsHtml}${seriesHtml}
  </svg>${legend}`;
}

// Back-compat wrapper: any existing call site (vals, color[, xLabels]) now
// automatically gets real numeric X/Y axes instead of a decorative line.
function stTrendChart(vals, color, xLabels) {
  xLabels = xLabels || vals.map((v,i)=>String(i+1));
  return stAxisChart(xLabels, [{name:'', color, values: vals}], {yMax:20, yStep:5});
}

// Real academic-period series for the whole student (used by Dashboard's
// Academic Trend and Advanced Analysis' trajectory): for each exam position
// 1..6 (T1 exam1-3, T2 exam1-3), the weighted overall average across every
// subject that has a score at that position. Skips positions with no data yet.
function stOverallTrendSeries() {
  const subs = STUDENT_DATA.subjects;
  const labels = ['T1·E1','T1·E2','T1·E3','T2·E1','T2·E2','T2·E3'];
  const values = labels.map((_, idx) => {
    const term = idx < 3 ? 'examsT1' : 'examsT2';
    const n = (idx % 3) + 1;
    let sum = 0, wsum = 0;
    subs.forEach(s => {
      const ex = s[term].find(e => e.n === n);
      if (ex && ex.score != null) { sum += ex.score * s.weight; wsum += s.weight; }
    });
    return wsum ? +(sum / wsum).toFixed(2) : null;
  });
  // trim trailing positions with no data at all so the chart doesn't end in a long flat gap
  while (values.length && values[values.length-1] == null) { values.pop(); labels.pop(); }
  return { labels, values };
}

// Per-subject exam-sequence series for a given period ('t1'|'t2'|'year').
// Missing (not-yet-taken) exams are simply omitted — never fabricated.
function stSubjectSeries(subject, period) {
  if (period === 'year') {
    const t1 = subject.examsT1.filter(e=>e.score!=null).map(e=>({n:e.n, score:e.score}));
    const t2 = subject.examsT2.filter(e=>e.score!=null).map(e=>({n:e.n+3, score:e.score}));
    const all = t1.concat(t2);
    return { xLabels: all.map(e=>String(e.n)), values: all.map(e=>e.score) };
  }
  const list = (period === 't2' ? subject.examsT2 : subject.examsT1).filter(e=>e.score!=null);
  return { xLabels: list.map(e=>String(e.n)), values: list.map(e=>e.score) };
}

function stBarChart(items, colorFn, valueSuffix) {
  const max = Math.max(...items.map(i=>i.v), 1);
  valueSuffix = valueSuffix || '';
  return `<div class="mini-bar-chart">${items.map(i=>`
    <div class="mini-bar-col">
      <div class="mini-bar-val">${i.v}${valueSuffix}</div>
      <div class="mini-bar" style="height:${Math.max(6,(i.v/max)*80)}px;${colorFn?`background:${colorFn(i.v)}`:''}"></div>
      <div class="mini-bar-label">${i.m}</div>
    </div>`).join('')}</div>`;
}

// Shared percentage → color-state helper (green/yellow/red) used across
// Attendance, Homework, Participation, Development & Behavior.
function stPctColor(v){ return v>=85?'var(--green)': v>=60?'var(--yellow)':'var(--red)'; }
function stPctGradient(v){ return v>=85?'linear-gradient(180deg,#5fe37f,#2fd158)': v>=60?'linear-gradient(180deg,#ffc257,#ff9f0a)':'linear-gradient(180deg,#ff7a70,#ff453a)'; }
function stPctBadgeClass(v){ return v>=85?'high': v>=60?'mid':'low'; }

/* countdown ticking */
let stCountdownInterval = null;
function stStartCountdowns() {
  if (stCountdownInterval) clearInterval(stCountdownInterval);
  const targets = {};
  document.querySelectorAll('[data-indays]').forEach(el=>{
    const days = parseFloat(el.dataset.indays);
    targets[el.id] = Date.now() + days*86400000;
  });
  function tick() {
    Object.keys(targets).forEach(id=>{
      const el = document.getElementById(id);
      if (!el) return;
      let diff = targets[id] - Date.now();
      if (diff < 0) diff = 0;
      const d = Math.floor(diff/86400000);
      const h = Math.floor((diff%86400000)/3600000);
      const m = Math.floor((diff%3600000)/60000);
      const s = Math.floor((diff%60000)/1000);
      el.innerHTML = `
        <div class="cd-box"><div class="cd-num">${d}</div><div class="cd-lbl">${t('Days')}</div></div>
        <div class="cd-box"><div class="cd-num">${h}</div><div class="cd-lbl">${t('Hrs')}</div></div>
        <div class="cd-box"><div class="cd-num">${m}</div><div class="cd-lbl">${t('Min')}</div></div>
        <div class="cd-box"><div class="cd-num">${s}</div><div class="cd-lbl">${t('Sec')}</div></div>`;
    });
  }
  tick();
  stCountdownInterval = setInterval(tick, 1000);
}

/* ═══════════════════════════════
   ACADEMICS
═══════════════════════════════ */
function stAcademics() {
  const tabs = [
    {id:'grades', label:'Grades'}, {id:'subjects', label:'Subjects'}, {id:'trends', label:'Progress Graphs'},
    {id:'calculators', label:'Calculators'}, {id:'analysis', label:'Advanced Analysis'},
  ];
  bodyFnRegistry.academics = stAcademicsBody;
  return `${stTabsBar('academics', tabs)}<div id="st-body-academics">${stAcademicsBody(stState.tab.academics)}</div>`;
}

// Shared Semester 1 / Semester 2 / Year Score switcher — drives Grades,
// Subjects and Progress Graphs. Re-renders only the current tab body.
function stPeriodBar(section) {
  section = section || 'academics';
  const opts = [ {id:'t1', label:'Semester 1'}, {id:'t2', label:'Semester 2'}, {id:'year', label:'Year Score'} ];
  return `<div class="st-period-bar" style="display:flex;gap:8px;margin-bottom:16px">
    ${opts.map(o=>`<button class="st-btn ${stState.academicsPeriod===o.id?'':'ghost'} sm" onclick="stSetAcademicsPeriod('${o.id}','${section}')">${t(o.label)}</button>`).join('')}
  </div>`;
}
function stSetAcademicsPeriod(period, section) {
  stState.academicsPeriod = period;
  section = section || 'academics';
  if (section === 'performance') {
    const body = document.getElementById('st-body-performance');
    if (body) body.innerHTML = stPerformanceBody(stState.tab.performance);
  } else {
    const body = document.getElementById('st-body-academics');
    if (body) body.innerHTML = stAcademicsBody(stState.tab.academics);
  }
}

// Label + color for a semester cell in a table/card: exact score when the
// semester's exams are all graded, otherwise "N exam(s) left" (never a
// misleading final number).
function stSemesterCell(subject, term) {
  const stat = stSemesterStat(subject, term);
  if (stat.isComplete) return { text: stat.avg.toFixed(1)+'/20', color: stGradeColor(stat.avg), pending:false };
  const label = stat.left===1 ? t('1 exam left') : `${stat.left} ${t('exams left')}`;
  return { text: label, color: 'var(--yellow)', pending:true };
}
function stStatusPill(stat) {
  if (!stat.isComplete) return `<span class="status-pill" style="background:rgba(255,159,10,0.15);color:var(--yellow)">${t('In Progress')}</span>`;
  return stat.avg >= 10
    ? `<span class="status-pill present">${t('Passed')}</span>`
    : `<span class="status-pill absent">${t('At Risk')}</span>`;
}

function stAcademicsBody(tab) {
  if (tab === 'grades') {
    const period = stState.academicsPeriod;
    let head, rows;
    if (period === 'year') {
      head = `<th>${t('Subject')}</th><th>${t('Teacher')}</th><th>${t('Semester 1')}</th><th>${t('Semester 2')}</th><th>${t('Status')}</th><th>${t('Rank in class')}</th>`;
      rows = STUDENT_DATA.subjects.map(s=>{
        const c1 = stSemesterCell(s,'t1'), c2 = stSemesterCell(s,'t2'), y = stYearStat(s);
        return `<tr style="cursor:pointer" onclick="stOpenSubject('${s.id}')"><td>${s.icon} ${t(s.name)}</td><td>${s.teacher}</td>
          <td style="color:${c1.color}">${c1.text}</td><td style="color:${c2.color}">${c2.text}</td>
          <td>${stStatusPill(y)}</td><td>${s.rankYear}</td></tr>`;
      }).join('');
    } else {
      const label = period==='t1' ? t('Semester 1') : t('Semester 2');
      head = `<th>${t('Subject')}</th><th>${t('Teacher')}</th><th>${t('Semester')}</th><th>${t('Status')}</th><th>${t('Rank in class')}</th>`;
      rows = STUDENT_DATA.subjects.map(s=>{
        const c = stSemesterCell(s, period), stat = stSemesterStat(s, period);
        const rank = period==='t1' ? s.rankT1 : s.rankT2;
        return `<tr style="cursor:pointer" onclick="stOpenSubject('${s.id}')"><td>${s.icon} ${t(s.name)}</td><td>${s.teacher}</td>
          <td style="color:${c.color};font-weight:${c.pending?600:400}">${c.text}</td><td>${stStatusPill(stat)}</td><td>${rank}</td></tr>`;
      }).join('');
      head = `<!--${label}-->` + head; // label consumed via card title below
    }
    const titleLabel = period==='t1'?t('Semester 1'):period==='t2'?t('Semester 2'):t('Year Score');
    return `${stPeriodBar()}
      <div class="card"><div class="card-header"><div class="card-title">${t('My Grades')} — ${titleLabel}</div></div>
      <div class="table-wrap"><table>
        <thead><tr>${head.replace(/<!--.*?-->/,'')}</tr></thead>
        <tbody>${rows}</tbody>
      </table></div>
    </div>
    <div class="card" style="margin-top:20px"><div class="card-header"><div class="card-title">🕸️ ${t('Grade Performance Overview')}</div></div>
      <div class="card-body" id="st-radar-wrap">${stRadarChart(period)}</div>
    </div>`;
  }

  if (tab === 'subjects') {
    const period = stState.academicsPeriod;
    return `${stPeriodBar()}<div class="st-grid-3">${STUDENT_DATA.subjects.map(s=>{
      const stat = period==='year' ? stYearStat(s) : stSemesterStat(s, period);
      const series = stSubjectSeries(s, period);
      const cell = period==='year' ? { text: stat.avg!=null? stat.avg.toFixed(1)+'/20':'—', color: stat.avg!=null?stGradeColor(stat.avg):'var(--muted)' } : stSemesterCell(s, period);
      return `
      <div class="card" style="cursor:pointer" onclick="stOpenSubject('${s.id}')">
        <div class="card-body">
          <div style="font-size:26px;margin-bottom:8px">${s.icon}</div>
          <div style="font-weight:700;font-size:14px">${t(s.name)}</div>
          <div style="font-size:11.5px;color:var(--muted);margin-bottom:10px">${s.teacher}</div>
          <div style="font-size:20px;font-weight:800;color:${cell.color}">${cell.text}</div>
          ${!stat.isComplete ? `<div style="font-size:10.5px;color:var(--yellow);margin:2px 0 6px">${t('Based on completed exams')}</div>` : ''}
          ${series.values.length ? stAxisChart(series.xLabels, [{name:'',color:stGradeColor(stat.avg||10),values:series.values}], {yMax:20,yStep:5,height:120}) : `<div style="font-size:11px;color:var(--muted);padding:16px 0">${t('No exams recorded yet for this period.')}</div>`}
        </div>
      </div>`;
    }).join('')}</div>`;
  }

  if (tab === 'trends') {
    const period = stState.academicsPeriod;
    const overall = period==='year' ? stOverallTrendSeries() :
      (()=>{ const s=stOverallTrendSeries(); const off=period==='t2'?3:0; return { labels:s.labels.slice(off,off+3), values:s.values.slice(off,off+3) }; })();
    const combinedSeries = STUDENT_DATA.subjects.map((s,i)=>({ name:s.name, color:STUDENT_COLORS[i%STUDENT_COLORS.length], values: stSubjectSeries(s,period).values }));
    // align combined series to a common x length (year = up to 6 positions, semester = up to 3)
    const maxLen = period==='year' ? 6 : 3;
    const xLabels = Array.from({length:maxLen}, (_,i)=>String(i+1));
    const alignedSeries = STUDENT_DATA.subjects.map((s,i)=>{
      const list = period==='year' ? s.examsT1.concat(s.examsT2.map(e=>({...e,n:e.n+3}))) : (period==='t2'?s.examsT2:s.examsT1);
      const values = xLabels.map((_,idx)=>{ const ex = list.find(e=>e.n===idx+1); return ex && ex.score!=null ? ex.score : null; });
      return { name:s.name, color:STUDENT_COLORS[i%STUDENT_COLORS.length], values };
    });
    return `${stPeriodBar()}
      <div class="card"><div class="card-header"><div class="card-title">${t('Academic Progress — Overall Average')}</div></div>
      <div class="card-body">${overall.values.length ? stAxisChart(overall.labels, [{name:'',color:'#0a84ff',values:overall.values}], {yMax:20,yStep:5}) : `<div style="color:var(--muted);font-size:12px">${t('No completed exams yet for this period.')}</div>`}
      <div style="margin-top:6px;font-size:11.5px;color:var(--muted)">${t('Weighted overall average across all subjects, exam by exam.')}</div></div></div>
      <div class="st-grid-2" style="margin-top:16px">
      ${STUDENT_DATA.subjects.map(s=>{ const series = stSubjectSeries(s,period); return `<div class="card"><div class="card-header"><div class="card-title">${s.icon} ${t(s.name)} — ${t('Subject Performance Graph')}</div></div><div class="card-body">${series.values.length ? stAxisChart(series.xLabels,[{name:'',color:stGradeColor(s.yearAvg||10),values:series.values}],{yMax:20,yStep:5,height:120}) : `<div style="color:var(--muted);font-size:11px">${t('No exams recorded yet.')}</div>`}</div></div>`; }).join('')}
      </div>
      <div class="card" style="margin-top:20px"><div class="card-header"><div class="card-title">📊 ${t('Combined Subject Progress')}</div></div>
      <div class="card-body">${stAxisChart(xLabels, alignedSeries, {yMax:20,yStep:5,height:220})}
      <div style="margin-top:6px;font-size:11.5px;color:var(--muted)">${t('All subjects on one timeline — spot which ones are pulling the overall average up or down.')}</div></div></div>`;
  }

  if (tab === 'calculators') return stCalculators();
  if (tab === 'analysis') return stAdvancedAnalysis();
  return '';
}

const STUDENT_COLORS = ['#0a84ff','#30d158','#ff9f0a','#ff453a','#bf5af2','#64d2ff'];

/* ─────────────────────────────────────────────
   RADAR / POLYGON GRADE-PERFORMANCE CHART
   Center = 0, first ring = 10, outer ring = 20.
   One axis per subject. Student + Class Average
   datasets, each independently toggleable.
───────────────────────────────────────────── */
function stRadarValues(period) {
  return STUDENT_DATA.subjects.map(s => {
    const student = period==='year' ? stYearStat(s).avg : stSemesterStat(s, period).avg;
    const cls = period==='t1' ? s.classAvgT1 : period==='t2' ? s.classAvgT2 : (s.classAvgT1+s.classAvgT2)/2;
    return { name: s.name, student: student==null?0:student, cls };
  });
}
function stRadarChart(period) {
  const data = stRadarValues(period);
  const n = data.length;
  const size = 320, cx = size/2, cy = size/2 + 6, Router = 108;
  const angle = i => -Math.PI/2 + i*(2*Math.PI/n);
  const pt = (i, val) => ({ x: cx + Math.sin(angle(i))*(val/20)*Router, y: cy - Math.cos(angle(i))*(val/20)*Router });
  const ring = val => Array.from({length:n},(_,i)=>{ const p=pt(i,val); return `${p.x},${p.y}`; }).join(' ');
  const axisLines = Array.from({length:n},(_,i)=>{ const p=pt(i,20); return `<line x1="${cx}" y1="${cy}" x2="${p.x}" y2="${p.y}" stroke="var(--border,#e5e7eb)" stroke-width="1"/>`; }).join('');
  const labels = data.map((d,i)=>{ const p=pt(i,20.5+3.5); return `<text x="${p.x}" y="${p.y}" font-size="10" fill="var(--text)" text-anchor="middle" dominant-baseline="middle">${t(d.name)}</text>`; }).join('');
  const studentPts = data.map((d,i)=>pt(i,d.student));
  const clsPts = data.map((d,i)=>pt(i,d.cls));
  const poly = pts => pts.map(p=>`${p.x},${p.y}`).join(' ');
  const dots = (pts, color, vals) => pts.map((p,i)=>`<circle cx="${p.x}" cy="${p.y}" r="3.5" fill="${color}"><title>${t(data[i].name)}: ${vals[i].toFixed(1)}/20</title></circle>`).join('');

  const showStudent = stState.radarShowStudent !== false;
  const showClass = stState.radarShowClass !== false;

  return `
  <div style="display:flex;gap:18px;flex-wrap:wrap;margin-bottom:10px;font-size:12.5px">
    <label style="display:flex;align-items:center;gap:6px;cursor:pointer">
      <input type="checkbox" ${showStudent?'checked':''} onchange="stToggleRadarSeries('student')">
      <span style="width:10px;height:10px;border-radius:50%;background:#0a84ff;display:inline-block"></span>${t('Student Grades')}
    </label>
    <label style="display:flex;align-items:center;gap:6px;cursor:pointer">
      <input type="checkbox" ${showClass?'checked':''} onchange="stToggleRadarSeries('class')">
      <span style="width:10px;height:10px;border-radius:50%;background:#ff9f0a;display:inline-block"></span>${t('Class Average')}
    </label>
  </div>
  <svg viewBox="0 0 ${size} ${size}" width="100%" height="${size}" style="max-width:420px">
    <polygon points="${ring(20)}" fill="none" stroke="var(--border,#e5e7eb)" stroke-width="1.2"/>
    <polygon points="${ring(10)}" fill="none" stroke="var(--border,#e5e7eb)" stroke-width="1"/>
    <circle cx="${cx}" cy="${cy}" r="1.5" fill="var(--muted)"/>
    ${axisLines}
    ${labels}
    ${showClass ? `<polygon points="${poly(clsPts)}" fill="#ff9f0a" fill-opacity="0.12" stroke="#ff9f0a" stroke-width="2"/>${dots(clsPts,'#ff9f0a',data.map(d=>d.cls))}` : ''}
    ${showStudent ? `<polygon points="${poly(studentPts)}" fill="#0a84ff" fill-opacity="0.15" stroke="#0a84ff" stroke-width="2.2"/>${dots(studentPts,'#0a84ff',data.map(d=>d.student))}` : ''}
  </svg>`;
}
function stToggleRadarSeries(which) {
  if (which === 'student') stState.radarShowStudent = stState.radarShowStudent === false ? true : false;
  else stState.radarShowClass = stState.radarShowClass === false ? true : false;
  const wrap = document.getElementById('st-radar-wrap');
  if (wrap) wrap.innerHTML = stRadarChart(stState.academicsPeriod);
}

// Subject detail popup — Semester 1 / Semester 2 / Year Score / Coefficient
// only, plus an independent Year Score graph. Not affected by the page's
// top-level period buttons.
function stOpenSubject(id) {
  const s = STUDENT_DATA.subjects.find(x=>x.id===id);
  const c1 = stSemesterCell(s,'t1'), c2 = stSemesterCell(s,'t2'), y = stYearStat(s);
  const yearSeries = stSubjectSeries(s, 'year');
  stOpenModal(`
    <div class="st-modal-title">${s.icon} ${t(s.name)}</div>
    <div class="st-modal-sub">${s.teacher}</div>
    <div class="info-row"><span>${t('Semester 1')}</span><span style="color:${c1.color}">${c1.text}</span></div>
    <div class="info-row"><span>${t('Semester 2')}</span><span style="color:${c2.color}">${c2.text}</span></div>
    <div class="info-row"><span>${t('Year Score')}</span><span style="color:${y.avg!=null?stGradeColor(y.avg):'var(--muted)'}">${y.avg!=null?y.avg.toFixed(1)+'/20':'—'}</span></div>
    <div class="info-row"><span>${t('Coefficient')}</span><span>${s.weight}</span></div>
    ${!y.isComplete ? `<div style="font-size:11px;color:var(--yellow);margin:6px 0">${t('Based on completed exams')}</div>` : ''}
    <div style="font-weight:700;font-size:13px;margin:16px 0 8px">${t('Year Score — Exam by Exam')}</div>
    ${yearSeries.values.length ? stAxisChart(yearSeries.xLabels, [{name:'',color:stGradeColor(y.avg||10),values:yearSeries.values}], {yMax:20,yStep:5}) : `<div style="font-size:12px;color:var(--muted)">${t('No exams recorded yet.')}</div>`}
  `);
}
/* ═══════════════════════════════
   CALCULATORS
═══════════════════════════════ */
function stCalculators() {
  return `
  <div class="st-grid-2">
    <div class="calc-box">
      <div style="font-weight:700;font-size:14px;margin-bottom:4px">📐 ${t('Grade Calculator')}</div>
      <div style="font-size:11.5px;color:var(--muted);margin-bottom:12px">${t('Enter scores and weights to calculate a current average.')}</div>
      <div id="gc-rows">
        <div class="calc-row"><input class="calc-input gc-score" placeholder="${t('Score /20')}" type="number" min="0" max="20"><input class="calc-input gc-weight" placeholder="${t('Weight')}" type="number" min="1" value="1"></div>
        <div class="calc-row"><input class="calc-input gc-score" placeholder="${t('Score /20')}" type="number" min="0" max="20"><input class="calc-input gc-weight" placeholder="${t('Weight')}" type="number" min="1" value="1"></div>
        <div class="calc-row"><input class="calc-input gc-score" placeholder="${t('Score /20')}" type="number" min="0" max="20"><input class="calc-input gc-weight" placeholder="${t('Weight')}" type="number" min="1" value="1"></div>
      </div>
      <button class="st-btn ghost sm" type="button" onclick="stAddCalcRow()" style="margin-bottom:8px">+ ${t('Add another')}</button><br>
      <button class="st-btn ghost sm" onclick="stCalcGrade()">${t('Calculate Average')}</button>
      <div class="calc-result" id="gc-result" style="display:none"></div>
    </div>

    <div class="calc-box">
      <div style="font-weight:700;font-size:14px;margin-bottom:4px">🔮 ${t('Hypothetical-Score Calculator')}</div>
      <div style="font-size:11.5px;color:var(--muted);margin-bottom:12px">${t('See how a future score would change your overall average.')}</div>
      <div class="calc-row"><span class="calc-label">${t('Current average')}</span><input class="calc-input" id="hc-cur" type="number" value="${stOverallAvg().toFixed(1)}"></div>
      <div class="calc-row"><span class="calc-label">${t('Hypothetical score')}</span><input class="calc-input" id="hc-new" type="number" min="0" max="20" placeholder="/20"></div>
      <div class="calc-row"><span class="calc-label">${t('Weight of new score')}</span><input class="calc-input" id="hc-w" type="number" value="1" min="1"></div>
      <button class="st-btn ghost sm" onclick="stCalcHypothetical()">${t('Simulate')}</button>
      <div class="calc-result" id="hc-result" style="display:none"></div>
    </div>

    <div class="calc-box">
      <div style="font-weight:700;font-size:14px;margin-bottom:4px">🎯 ${t('Target-Average Calculator')}</div>
      <div style="font-size:11.5px;color:var(--muted);margin-bottom:12px">${t('Find the score needed on one remaining assessment to hit a target average.')}</div>
      <div class="calc-row"><span class="calc-label">${t('Current average')}</span><input class="calc-input" id="ta-cur" type="number" value="${stOverallAvg().toFixed(1)}"></div>
      <div class="calc-row"><span class="calc-label">${t('Target average')}</span><input class="calc-input" id="ta-target" type="number" placeholder="/20"></div>
      <div class="calc-row"><span class="calc-label">${t('Weight of remaining item')}</span><input class="calc-input" id="ta-w" type="number" value="1" min="1"></div>
      <button class="st-btn ghost sm" onclick="stCalcTarget()">${t('Calculate Required Score')}</button>
      <div class="calc-result" id="ta-result" style="display:none"></div>
    </div>

    <div class="calc-box">
      <div style="font-weight:700;font-size:14px;margin-bottom:4px">📌 ${t('Required-Score Calculator')}</div>
      <div style="font-size:11.5px;color:var(--muted);margin-bottom:12px">${t('Enter current grades and a desired final average to see exactly what the final exam needs.')}</div>
      <div class="calc-row"><span class="calc-label">${t('Sum of current grades × weight')}</span><input class="calc-input" id="rs-sum" type="number" placeholder="e.g. 48"></div>
      <div class="calc-row"><span class="calc-label">${t('Sum of current weights')}</span><input class="calc-input" id="rs-wsum" type="number" placeholder="e.g. 3"></div>
      <div class="calc-row"><span class="calc-label">${t('Final exam weight')}</span><input class="calc-input" id="rs-fw" type="number" value="2"></div>
      <div class="calc-row"><span class="calc-label">${t('Desired final average')}</span><input class="calc-input" id="rs-target" type="number" placeholder="/20"></div>
      <button class="st-btn ghost sm" onclick="stCalcRequired()">${t('Calculate')}</button>
      <div class="calc-result" id="rs-result" style="display:none"></div>
    </div>
  </div>`;
}

function stAddCalcRow() {
  const wrap = document.getElementById('gc-rows');
  const row = document.createElement('div');
  row.className = 'calc-row';
  row.innerHTML = `<input class="calc-input gc-score" placeholder="${t('Score /20')}" type="number" min="0" max="20"><input class="calc-input gc-weight" placeholder="${t('Weight')}" type="number" min="1" value="1">`;
  wrap.appendChild(row);
}

function stCalcGrade() {
  const scoreEls = document.querySelectorAll('#gc-rows .gc-score');
  const weightEls = document.querySelectorAll('#gc-rows .gc-weight');
  let sum=0, wsum=0, invalid=0, filled=0;
  scoreEls.forEach((el,i)=>{
    const raw = el.value;
    if (raw === '') return; // empty row, skip silently
    const s = parseFloat(raw);
    const w = parseFloat(weightEls[i].value) || 1;
    if (isNaN(s) || s<0 || s>20 || w<=0) { invalid++; return; }
    filled++; sum += s*w; wsum += w;
  });
  const box = document.getElementById('gc-result');
  box.style.display='block';
  if (wsum===0) { box.className='calc-result warn'; box.innerHTML = invalid ? t('Scores must be between 0 and 20 with a positive weight.') : t('Enter at least one score to calculate.'); return; }
  const avg = (sum/wsum).toFixed(2);
  box.className = 'calc-result ' + (avg>=12?'ok':'warn');
  box.innerHTML = `${t('Weighted average')}: <strong>${avg}/20</strong>` + (invalid ? ` <span style="color:var(--yellow);font-size:11px">(${invalid} ${t('invalid row(s) ignored')})</span>` : '');
}

function stCalcHypothetical() {
  const cur = parseFloat(document.getElementById('hc-cur').value)||0;
  const ns = parseFloat(document.getElementById('hc-new').value);
  const w = parseFloat(document.getElementById('hc-w').value)||1;
  const box = document.getElementById('hc-result');
  box.style.display='block';
  if (isNaN(ns)) { box.className='calc-result warn'; box.innerHTML=t('Enter a hypothetical score.'); return; }
  const baseW = 6; // assume ~6 existing weighted assessments as baseline
  const newAvg = ((cur*baseW)+(ns*w))/(baseW+w);
  const delta = (newAvg-cur);
  box.className = 'calc-result ' + (delta>=0?'ok':'warn');
  box.innerHTML = `${t('New estimated average')}: <strong>${newAvg.toFixed(2)}/20</strong> (${delta>=0?'+':''}${delta.toFixed(2)})`;
}

function stCalcTarget() {
  const cur = parseFloat(document.getElementById('ta-cur').value)||0;
  const target = parseFloat(document.getElementById('ta-target').value);
  const w = parseFloat(document.getElementById('ta-w').value)||1;
  const box = document.getElementById('ta-result');
  box.style.display='block';
  if (isNaN(target)) { box.className='calc-result warn'; box.innerHTML=t('Enter a target average.'); return; }
  const baseW = 6;
  const required = (target*(baseW+w) - cur*baseW)/w;
  box.className = 'calc-result ' + (required<=20 && required>=0 ? 'ok':'warn');
  if (required>20) box.innerHTML = `${t('This target is not achievable with one remaining item')} (${t('would require')} ${required.toFixed(1)}/20).`;
  else if (required<0) box.innerHTML = `${t('You have already secured this target average.')}`;
  else box.innerHTML = `${t('Required score')}: <strong>${required.toFixed(1)}/20</strong> ${t('on the remaining item to reach')} ${target}/20.`;
}

function stCalcRequired() {
  const sum = parseFloat(document.getElementById('rs-sum').value);
  const wsum = parseFloat(document.getElementById('rs-wsum').value);
  const fw = parseFloat(document.getElementById('rs-fw').value)||1;
  const target = parseFloat(document.getElementById('rs-target').value);
  const box = document.getElementById('rs-result');
  box.style.display='block';
  if ([sum,wsum,target].some(isNaN)) { box.className='calc-result warn'; box.innerHTML=t('Fill in all fields to calculate.'); return; }
  const required = (target*(wsum+fw) - sum) / fw;
  box.className = 'calc-result ' + (required<=20 && required>=0 ? 'ok':'warn');
  if (required>20) box.innerHTML = `${t('Not achievable — would require')} ${required.toFixed(1)}/20 ${t('on the final exam.')}`;
  else if (required<0) box.innerHTML = `${t('Target already secured regardless of the final exam score.')}`;
  else box.innerHTML = `${t('You need at least')} <strong>${required.toFixed(1)}/20</strong> ${t('on the final exam to reach a')} ${target}/20 ${t('average.')}`;
}

/* ═══════════════════════════════
   ADVANCED ANALYSIS / PREDICTIONS
═══════════════════════════════ */
function stAdvancedAnalysis() {
  const avg = stOverallAvg();
  const trendSeries = stOverallTrendSeries();
  const trend = trendSeries.values;
  const slope = trend.length>1 ? (trend[trend.length-1]-trend[0])/(trend.length-1) : 0;
  const predicted = Math.min(20, Math.max(0, avg + slope*2)).toFixed(1);
  const best = STUDENT_DATA.subjects.reduce((a,b)=> (a.yearAvg > b.yearAvg ? a:b));
  const weakest = STUDENT_DATA.subjects.reduce((a,b)=> (a.yearAvg < b.yearAvg ? a:b));
  return `
  <div class="st-grid-2">
    <div class="card"><div class="card-header"><div class="card-title">🔮 ${t('Performance Prediction')}</div></div>
      <div class="card-body">
        <div style="font-size:26px;font-weight:800;color:var(--accent)">${predicted}/20</div>
        <div style="font-size:12px;color:var(--muted);margin-top:4px">${t('Projected overall average for the end of Term 3, based on current trend and improvement rate.')}</div>
      </div></div>
    <div class="card"><div class="card-header"><div class="card-title">📈 ${t('Improvement-Based Prediction')}</div></div>
      <div class="card-body">
        <div style="font-size:26px;font-weight:800;color:var(--green)">${slope>=0?'+':''}${(slope*2).toFixed(1)}</div>
        <div style="font-size:12px;color:var(--muted);margin-top:4px">${t('Expected further change over the next two exam periods if the current pace continues.')}</div>
      </div></div>
    <div class="card"><div class="card-header"><div class="card-title">🧭 ${t('Academic Trend Analysis')}</div></div>
      <div class="card-body">
        <div style="font-size:13px;line-height:1.7">${t('Your weighted overall average has moved from')} <strong>${trend[0]}/20</strong> ${t('to')} <strong>${trend[trend.length-1]}/20</strong> ${t('across completed exams this year')}. ${t('The strongest subject is')} <strong>${t(best.name)}</strong>, ${t('while')} <strong>${t(weakest.name)}</strong> ${t('has the most room to grow.')}</div>
      </div></div>
    <div class="card"><div class="card-header"><div class="card-title">📐 ${t('Performance Trajectory')}</div></div>
      <div class="card-body">${stAxisChart(trendSeries.labels,[{name:'',color:'#30d158',values:trend}],{yMax:20,yStep:5})}
      <div style="font-size:11.5px;color:var(--muted);margin-top:8px">${t('Based on completed exams only — updates automatically as new grades come in.')}</div></div></div>
  </div>`;
}
/* ═══════════════════════════════
   ATTENDANCE
═══════════════════════════════ */
function stAttendance() {
  const tabs = [
    {id:'calendar', label:'Calendar'}, {id:'stats', label:'Statistics'},
    {id:'history', label:'Absence History'}, {id:'graphs', label:'Graphs & Streak'},
  ];
  bodyFnRegistry.attendance = stAttendanceBody;
  return `${stTabsBar('attendance', tabs)}<div id="st-body-attendance">${stAttendanceBody(stState.tab.attendance)}</div>`;
}

function stCalMonthName(m,y){ return new Date(y,m,1).toLocaleString('en-US',{month:'long'}) + ' ' + y; }

function stFindAbsence(day, month, year, status) {
  return STUDENT_DATA.attendance.absenceLog.find(e=>e.day===day && e.month===month && e.year===year && e.status===status);
}

function stRenderCalendar() {
  const a = STUDENT_DATA.attendance;
  const y = stState.calYear, m = stState.calMonth;
  const firstDow = new Date(y,m,1).getDay();
  const daysInMonth = new Date(y,m+1,0).getDate();
  const statusClass = {0:'',1:'present',2:'absent-j',3:'absent-u',4:'late'};
  const statusLabel = {1:t('Present'),2:t('Justified absence'),3:t('Unjustified absence'),4:t('Late')};
  const hasDayData = (m===2 && y===2026); // day-level detail currently only modeled for March 2026
  let cells = '';
  for (let i=0;i<firstDow;i++) cells += `<div class="cal-cell empty"></div>`;
  for (let d=1; d<=daysInMonth; d++){
    const st = hasDayData ? (a.marchDays[d-1] || 0) : 0;
    const cls = statusClass[st] || '';
    let extra = '', label = statusLabel[st] || t('No data');
    if (st === 3) {
      const rec = stFindAbsence(d, m, y, 'unjustified');
      if (rec && !rec.justificationSubmitted) { extra = ` onclick="stOpenJustify('${rec.id}')" style="cursor:pointer"`; label = t('Unjustified absence — tap to justify'); }
      else if (rec) { label = t('Justification submitted — pending review'); }
    }
    cells += `<div class="cal-cell ${cls}"${extra} title="${label}">${d}</div>`;
  }
  const dows = ['Su','Mo','Tu','We','Th','Fr','Sa'];
  return `
  <div class="card"><div class="card-header">
    <div class="card-title">📅 ${t('Attendance Calendar')}</div>
    <div class="cal-nav"><button onclick="stCalNav(-1)">‹</button><span style="font-size:13px;font-weight:600">${stCalMonthName(m,y)}</span><button onclick="stCalNav(1)">›</button></div>
  </div>
  <div class="card-body">
    <div class="cal-grid" style="margin-bottom:8px">${dows.map(d=>`<div class="cal-dow">${t(d)}</div>`).join('')}</div>
    <div class="cal-grid" id="cal-cells">${cells}</div>
    <div class="cal-legend">
      <span><span class="cal-dot" style="background:rgba(48,209,88,0.4)"></span>${t('Present')}</span>
      <span><span class="cal-dot" style="background:rgba(255,159,10,0.5)"></span>${t('Justified absence')}</span>
      <span><span class="cal-dot" style="background:rgba(255,69,58,0.5)"></span>${t('Unjustified absence')}</span>
      <span><span class="cal-dot" style="background:rgba(191,90,242,0.5)"></span>${t('Late')}</span>
    </div>
    ${!hasDayData ? `<div style="font-size:11px;color:var(--muted);margin-top:10px">${t('Day-by-day detail is available for March 2026.')}</div>` : ''}
  </div></div>`;
}

function stCalNav(dir) {
  stState.calMonth += dir;
  if (stState.calMonth<0){stState.calMonth=11;stState.calYear--;}
  if (stState.calMonth>11){stState.calMonth=0;stState.calYear++;}
  const wrap = document.querySelector('#st-body-attendance .card');
  if (wrap) document.getElementById('st-body-attendance').innerHTML = stAttendanceBody('calendar');
}

function stAttendanceBody(tab) {
  const a = STUDENT_DATA.attendance;
  if (tab === 'calendar') return stRenderCalendar();
  if (tab === 'stats') return `
    <div class="st-grid-4">
      <div class="stat-card green"><div class="stat-icon green">✅</div><div class="stat-label">${t('Attendance Rate')}</div><div class="stat-val" style="color:${stPctColor(a.rate)}">${a.rate}%</div></div>
      <div class="stat-card yellow"><div class="stat-icon yellow">📄</div><div class="stat-label">${t('Justified Absences')}</div><div class="stat-val">${a.absentJustified}</div></div>
      <div class="stat-card red"><div class="stat-icon red">⚠️</div><div class="stat-label">${t('Unjustified Absences')}</div><div class="stat-val">${a.absentUnjustified}</div></div>
      <div class="stat-card purple"><div class="stat-icon purple">⏱️</div><div class="stat-label">${t('Times Late')}</div><div class="stat-val">${a.late}</div></div>
    </div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Term Summary')}</div></div>
      <div class="card-body">
        <div class="info-row"><span>${t('Days present')}</span><span>${a.present}</span></div>
        <div class="info-row"><span>${t('Current streak')}</span><span>${a.streak} ${t('days')}</span></div>
        <div class="info-row"><span>${t('Best streak of all time')}</span><span>${a.bestStreak} ${t('days')}</span></div>
      </div></div>`;
  if (tab === 'history') {
    const pillFor = rec => {
      if (rec.status === 'late') return `<span class="status-pill late">${t('Late')}</span>`;
      if (rec.status === 'justified') return `<span class="status-pill absent" style="background:rgba(255,159,10,0.16);color:var(--yellow)">${t('Justified')}</span>`;
      if (rec.status === 'unjustified' && rec.justificationSubmitted) return `<span class="status-pill absent" style="background:rgba(255,159,10,0.16);color:var(--yellow)">${t('Pending Review')}</span>`;
      return `<span class="status-pill absent">${t('Unjustified')}</span>`;
    };
    const noteFor = rec => {
      if (rec.status === 'unjustified' && !rec.justificationSubmitted) return `<span style="color:var(--accent);cursor:pointer" onclick="stOpenJustify('${rec.id}')">${t('Tap to justify →')}</span>`;
      if (rec.status === 'unjustified' && rec.justificationSubmitted) return t('Submitted — awaiting teacher review');
      return t(rec.note || '—');
    };
    const rows = STUDENT_DATA.attendance.absenceLog.map(rec => {
      const clickable = rec.status === 'unjustified' && !rec.justificationSubmitted;
      return `<tr${clickable?` style="cursor:pointer" onclick="stOpenJustify('${rec.id}')"`:''}><td>${rec.date}</td><td>${t(rec.subject)}</td><td>${pillFor(rec)}</td><td>${noteFor(rec)}</td></tr>`;
    }).join('');
    return `
    <div class="card"><div class="card-header"><div class="card-title">${t('Absence History')}</div></div>
    <div class="table-wrap"><table>
      <thead><tr><th>${t('Date')}</th><th>${t('Class')}</th><th>${t('Status')}</th><th>${t('Note')}</th></tr></thead>
      <tbody>${rows}</tbody>
    </table></div></div>`;
  }
  if (tab === 'graphs') return `
    <div class="card"><div class="card-header"><div class="card-title">📊 ${t('Attendance Rate by Month')}</div></div>
      <div class="card-body">${stBarChart(a.monthlyRate.map(x=>({m:t(x.m),v:x.v})), stPctGradient, '%')}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">🔥 ${t('Attendance Streak')}</div></div>
      <div class="card-body">
        <div style="display:flex;gap:24px;align-items:center">
          <div style="text-align:center"><div style="font-size:34px;font-weight:800;color:var(--accent2)">${a.streak}</div><div style="font-size:11px;color:var(--muted)">${t('Current streak (days)')}</div></div>
          <div style="text-align:center"><div style="font-size:34px;font-weight:800;color:var(--green)">${a.bestStreak}</div><div style="font-size:11px;color:var(--muted)">${t('Best streak of all time (days)')}</div></div>
        </div>
        <div class="progress-track" style="margin-top:14px"><div class="progress-fill green" style="width:${Math.min(100,(a.streak/a.bestStreak)*100)}%"></div></div>
      </div></div>`;
  return '';
}

/* ── Absence justification flow (7.1) ───────────────────────── */
function stOpenJustify(id) {
  const rec = STUDENT_DATA.attendance.absenceLog.find(x=>x.id===id);
  if (!rec) return;
  stOpenModal(`
    <div class="st-modal-title">⚠️ ${t('Justify Absence')}</div>
    <div class="st-modal-sub">${t(rec.subject)} · ${rec.date}</div>
    <div style="font-size:12.5px;color:var(--muted);margin:10px 0 14px;line-height:1.6">${t('This absence is currently marked as unjustified because no justification has been submitted yet. Provide a reason below and your teacher will review it.')}</div>
    <div style="margin-bottom:10px">
      <label style="font-size:12px;font-weight:600;display:block;margin-bottom:6px">${t('Reason for absence')}</label>
      <textarea id="justify-reason" rows="4" style="width:100%;border-radius:10px;border:1px solid var(--border,#333);padding:10px;font-family:inherit;font-size:13px;background:transparent;color:inherit;resize:vertical" placeholder="${t('e.g. Medical appointment, family emergency...')}"></textarea>
    </div>
    <div id="justify-error" style="display:none;color:var(--red);font-size:11.5px;margin-bottom:10px"></div>
    <button class="st-btn" onclick="stSubmitJustification('${id}')">${t('Submit Justification')}</button>
  `);
}
function stSubmitJustification(id) {
  const rec = STUDENT_DATA.attendance.absenceLog.find(x=>x.id===id);
  if (!rec) return;
  const textEl = document.getElementById('justify-reason');
  const text = (textEl.value || '').trim();
  const err = document.getElementById('justify-error');
  if (text.length < 5) { err.style.display='block'; err.textContent = t('Please provide a short explanation before submitting.'); return; }
  rec.justificationSubmitted = true;
  rec.justificationText = text;
  stOpenModal(`
    <div class="st-modal-title">✅ ${t('Justification Submitted')}</div>
    <div style="font-size:13px;color:var(--muted);line-height:1.7;margin-top:8px">${t('Your justification for the')} <strong>${t(rec.subject)}</strong> ${t('absence on')} <strong>${rec.date}</strong> ${t('has been sent to your teacher for review. You will be notified once it has been reviewed.')}</div>
    <button class="st-btn" style="margin-top:16px" onclick="stCloseModal()">${t('Done')}</button>
  `);
  const area = document.getElementById('st-body-attendance');
  if (area) area.innerHTML = stAttendanceBody(stState.tab.attendance);
}

/* ═══════════════════════════════
   HOMEWORK
═══════════════════════════════ */
function stHomework() {
  const tabs = [ {id:'list', label:'All Homework'}, {id:'pending', label:'Pending'}, {id:'completed', label:'Completed'}, {id:'analytics', label:'Analytics'} ];
  bodyFnRegistry.homework = stHomeworkBody;
  return `${stTabsBar('homework', tabs)}<div id="st-body-homework">${stHomeworkBody(stState.tab.homework)}</div>`;
}

function stHomeworkRow(h) {
  return `<div class="notif-full" onclick="stOpenHomework('${h.id}')">
    <div style="width:34px;height:34px;border-radius:9px;background:rgba(10,132,255,0.12);display:flex;align-items:center;justify-content:center;flex-shrink:0">${h.status==='done'?'✅':'📝'}</div>
    <div style="flex:1">
      <div style="font-weight:600;font-size:13px">${t(h.title)}</div>
      <div style="font-size:11.5px;color:var(--muted);margin-top:2px">${t(h.subject)} · ${t(h.due)}</div>
    </div>
    <span class="status-pill ${h.status==='done'?'present':'late'}">${h.status==='done'?t('Completed'):t('Pending')}</span>
  </div>`;
}

function stHomeworkBody(tab) {
  const list = STUDENT_DATA.homework;
  if (tab === 'list') return `<div class="card"><div class="card-body" style="display:flex;flex-direction:column;gap:4px">${list.map(stHomeworkRow).join('')}</div></div>`;
  if (tab === 'pending') return `<div class="card"><div class="card-body" style="display:flex;flex-direction:column;gap:4px">${list.filter(h=>h.status==='pending').map(stHomeworkRow).join('')}</div></div>`;
  if (tab === 'completed') return `<div class="card"><div class="card-body" style="display:flex;flex-direction:column;gap:4px">${list.filter(h=>h.status==='done').map(stHomeworkRow).join('')}</div></div>`;
  if (tab === 'analytics') {
    const done = list.filter(h=>h.status==='done').length;
    const rate = Math.round((done/list.length)*100);
    return `
    <div class="st-grid-3">
      <div class="stat-card green"><div class="stat-icon green">✅</div><div class="stat-label">${t('Completion Rate')}</div><div class="stat-val" style="color:${stPctColor(rate)}">${rate}%</div></div>
      <div class="stat-card blue"><div class="stat-icon blue">📥</div><div class="stat-label">${t('Total Assigned')}</div><div class="stat-val">${list.length}</div></div>
      <div class="stat-card yellow"><div class="stat-icon yellow">⏳</div><div class="stat-label">${t('Currently Pending')}</div><div class="stat-val">${list.filter(h=>h.status==='pending').length}</div></div>
    </div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Completion Trend')}</div></div>
      <div class="card-body">${stBarChart([{m:t('Oct'),v:88},{m:t('Nov'),v:90},{m:t('Dec'),v:85},{m:t('Jan'),v:93},{m:t('Feb'),v:95},{m:t('Mar'),v:96}], stPctGradient, '%')}</div>
      <div style="font-size:11.5px;color:var(--muted);margin-top:8px">${t('Homework completion has stayed consistently high, trending upward this term.')}</div></div></div>`;
  }
  return '';
}

function stOpenHomework(id) {
  const h = STUDENT_DATA.homework.find(x=>x.id===id);
  stOpenModal(`
    <div class="st-modal-title">${t(h.title)}</div>
    <div class="st-modal-sub">${t(h.subject)}</div>
    <div class="info-row"><span>${t('Due')}</span><span>${t(h.due)}</span></div>
    <div class="info-row"><span>${t('Status')}</span><span>${h.status==='done'?t('Completed'):t('Pending')}</span></div>
    <div style="font-size:12.5px;color:var(--muted);margin-top:14px;line-height:1.6">${t('Instructions and attachments provided by your teacher would appear here in the full application.')}</div>
    ${h.status==='pending' ? `<button class="st-btn" style="margin-top:16px" onclick="stMarkHomeworkDone('${h.id}')">${t('Mark as Completed')}</button>` : ''}
  `);
}
function stMarkHomeworkDone(id) {
  const h = STUDENT_DATA.homework.find(x=>x.id===id);
  h.status='done'; h.due = t('Completed today');
  stCloseModal();
  renderView('student', 'homework');
}

/* ═══════════════════════════════
   EXAMS
═══════════════════════════════ */
function stExams() {
  const tabs = [ {id:'upcoming', label:'Upcoming', badge:String(STUDENT_DATA.examsUpcoming.length)}, {id:'calendar', label:'Exam Calendar'}, {id:'history', label:'History & Scores'} ];
  bodyFnRegistry.exams = stExamsBody;
  return `${stTabsBar('exams', tabs)}<div id="st-body-exams">${stExamsBody(stState.tab.exams)}</div>`;
}

function stExamsBody(tab) {
  if (tab === 'upcoming') {
    const next = STUDENT_DATA.examsUpcoming[0];
    return `
    <div class="card"><div class="card-header"><div class="card-title">⏰ ${t('Countdown to Next Exam')}</div></div>
      <div class="card-body"><div style="font-weight:700;margin-bottom:10px">${t(next.subject)} — ${t(next.title)}</div>
      <div class="countdown-hero" id="ex-countdown" data-indays="${next.inDays}"></div></div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Upcoming Exams')}</div></div>
      <div class="card-body" style="display:flex;flex-direction:column;gap:4px">
      ${STUDENT_DATA.examsUpcoming.map(e=>`
        <div class="notif-full" onclick="stOpenExam('${e.id}')">
          <div style="width:34px;height:34px;border-radius:9px;background:rgba(191,90,242,0.14);display:flex;align-items:center;justify-content:center;flex-shrink:0">🧪</div>
          <div style="flex:1"><div style="font-weight:600;font-size:13px">${t(e.subject)} — ${t(e.title)}</div><div style="font-size:11.5px;color:var(--muted)">${t('In')} ${e.inDays} ${t('days')} · ${e.time}</div></div>
          <span class="grade-badge">${e.inDays}${t('d')}</span>
        </div>`).join('')}
      </div></div>`;
  }
  if (tab === 'calendar') {
    return `<div class="card"><div class="card-header"><div class="card-title">🗓️ ${t('Exam Calendar')}</div></div>
      <div class="card-body">
      <div style="display:flex;flex-direction:column;gap:10px">
      ${STUDENT_DATA.examsUpcoming.map(e=>{
        const d=new Date(Date.now()+e.inDays*86400000);
        return `<div style="display:flex;gap:14px;align-items:center;padding:10px;border-radius:10px;background:rgba(255,255,255,0.03)">
          <div style="width:46px;text-align:center"><div style="font-size:18px;font-weight:800">${d.getDate()}</div><div style="font-size:10px;color:var(--muted);text-transform:uppercase">${d.toLocaleString('en-US',{month:'short'})}</div></div>
          <div style="flex:1"><div style="font-weight:600;font-size:13px">${t(e.subject)} — ${t(e.title)}</div><div style="font-size:11px;color:var(--muted)">${e.time}</div></div>
        </div>`;
      }).join('')}
      </div></div></div>`;
  }
  if (tab === 'history') return stExamsHistoryCard();
  return '';
}

/* ── 9. Dynamic Exam Scores selector: Year → Semester 1 / Semester 2 / Full Year,
   with exam columns generated from the underlying per-subject exam data. ───── */
function stExamsHistoryCard() {
  const sel = stState.examsSelection;
  const years = Object.keys(STUDENT_DATA.historyYears);
  return `<div class="card"><div class="card-header"><div class="card-title">🗂️ ${t('Select Period')}</div></div>
    <div class="card-body">
      <div style="margin-bottom:14px">
        <label style="font-size:12px;font-weight:600;display:block;margin-bottom:6px">${t('Academic Year')}</label>
        <select class="calc-input" style="max-width:180px" onchange="stSetExamYear(this.value)">
          ${years.map(y=>`<option value="${y}" ${sel.year===y?'selected':''}>${y}</option>`).join('')}
        </select>
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        ${[['t1','Semester 1'],['t2','Semester 2'],['year','Full Year']].map(([id,label])=>`<button class="st-btn ${sel.period===id?'':'ghost'} sm" onclick="stSetExamPeriod('${id}')">${t(label)}</button>`).join('')}
      </div>
    </div></div>
    <div id="exam-history-table" style="margin-top:16px">${stExamsHistoryTable()}</div>`;
}
function stExamsHistoryTable() {
  const sel = stState.examsSelection;
  if (!sel.period) return `<div class="card"><div class="card-body" style="color:var(--muted);text-align:center;padding:30px;font-size:13px">${t('Choose a semester or the full year to see exam scores.')}</div></div>`;
  if (sel.year !== '2025/26') return `<div class="card"><div class="card-body" style="color:var(--muted);text-align:center;padding:30px;font-size:13px">${t('Detailed exam-by-exam scores are available for the current year only.')}</div></div>`;
  const subs = STUDENT_DATA.subjects;
  const getList = s => sel.period==='year' ? s.examsT1.concat(s.examsT2.map(e=>({n:e.n+3,title:e.title,score:e.score,date:e.date}))) : (sel.period==='t2'?s.examsT2:s.examsT1);
  const maxCols = Math.max(...subs.map(s=>getList(s).length));
  const headerCols = Array.from({length:maxCols},(_,i)=>`<th>${t('Exam')} ${i+1}</th>`).join('');
  const rows = subs.map(s=>{
    const list = getList(s);
    const cells = Array.from({length:maxCols},(_,i)=>{
      const ex = list.find(e=>e.n===i+1);
      if (!ex) return `<td>—</td>`;
      if (ex.score==null) return `<td style="color:var(--yellow)">${t('Pending')}</td>`;
      return `<td><span class="grade-badge ${ex.score>=16?'high':ex.score>=12?'':'mid'}">${ex.score}/20</span></td>`;
    }).join('');
    return `<tr><td>${s.icon} ${t(s.name)}</td>${cells}</tr>`;
  }).join('');
  const label = sel.period==='t1'?t('Semester 1'):sel.period==='t2'?t('Semester 2'):t('Full Year');
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Exam Scores')} — ${sel.year} · ${label}</div></div>
    <div class="table-wrap"><table><thead><tr><th>${t('Subject')}</th>${headerCols}</tr></thead><tbody>${rows}</tbody></table></div></div>`;
}
function stSetExamYear(y) { stState.examsSelection.year = y; const el=document.getElementById('exam-history-table'); if (el) el.innerHTML = stExamsHistoryTable(); }
function stSetExamPeriod(p) { stState.examsSelection.period = p; const area=document.getElementById('st-body-exams'); if (area) area.innerHTML = stExamsBody('history'); }

function stOpenExam(id) {
  const e = STUDENT_DATA.examsUpcoming.find(x=>x.id===id);
  stOpenModal(`
    <div class="st-modal-title">${t(e.subject)} — ${t(e.title)}</div>
    <div class="st-modal-sub">${t('In')} ${e.inDays} ${t('days')} · ${e.time}</div>
    <div class="countdown-hero" id="modal-countdown" data-indays="${e.inDays}"></div>
    <div style="font-size:12.5px;color:var(--muted);margin-top:16px;line-height:1.6">${t('Room and full syllabus details will be published by your teacher closer to the exam date.')}</div>
  `);
  stStartCountdowns();
}
/* ═══════════════════════════════
   PERFORMANCE & ANALYTICS (Student 360)
═══════════════════════════════ */
function stPerformance() {
  const tabs = [ {id:'360', label:'Student 360'}, {id:'subjects', label:'Subject Graphs'}, {id:'development', label:'Development & Behavior'}, {id:'insights', label:'Personalized Insights'} ];
  bodyFnRegistry.performance = stPerformanceBody;
  return `${stTabsBar('performance', tabs)}<div id="st-body-performance">${stPerformanceBody(stState.tab.performance)}</div>`;
}

function stPerformanceBody(tab) {
  const avg = stOverallAvg();
  const participationNow = STUDENT_DATA.participation[STUDENT_DATA.participation.length-1].v;
  const trend = stOverallTrendSeries();
  if (tab === '360') return `
    <div class="st-grid-4" style="margin-bottom:16px">
      <div class="stat-card blue"><div class="stat-icon blue">📊</div><div class="stat-label">${t('Academic')}</div><div class="stat-val">${avg.toFixed(1)}/20</div></div>
      <div class="stat-card green"><div class="stat-icon green">📅</div><div class="stat-label">${t('Attendance')}</div><div class="stat-val" style="color:${stPctColor(STUDENT_DATA.attendance.rate)}">${STUDENT_DATA.attendance.rate}%</div></div>
      <div class="stat-card purple"><div class="stat-icon purple">🙋</div><div class="stat-label">${t('Participation')}</div><div class="stat-val" style="color:${stPctColor(participationNow)}">${participationNow}%</div></div>
      <div class="stat-card cyan"><div class="stat-icon cyan">🏅</div><div class="stat-label">${t('Achievements')}</div><div class="stat-val">${STUDENT_DATA.badges.filter(b=>b.earned).length}</div></div>
    </div>
    <div class="card"><div class="card-header"><div class="card-title">🧭 ${t('Student 360 — Full Performance Profile')}</div></div>
      <div class="card-body">
        <div style="font-size:13px;line-height:1.8">${t('Youssef combines a strong and improving academic average with reliable attendance and consistently positive classroom behavior. Participation has grown steadily this year, and homework completion sits well above the class median.')}</div>
        <div class="st-grid-2" style="margin-top:16px">
          <div><div style="font-size:11.5px;color:var(--muted);margin-bottom:6px">${t('Academic Trend')}</div>${stAxisChart(trend.labels,[{name:'',color:'#0a84ff',values:trend.values}],{yMax:20,yStep:5})}</div>
          <div><div style="font-size:11.5px;color:var(--muted);margin-bottom:6px">${t('Participation Trend')}</div>${stBarChart(STUDENT_DATA.participation.map(x=>({m:t(x.m),v:x.v})), stPctGradient, '%')}</div>
        </div>
      </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">🏆 ${t('Personal Bests')}</div></div>
      <div class="card-body st-grid-3">
        <div><div style="font-size:20px;font-weight:800;color:var(--green)">18.5/20</div><div style="font-size:11px;color:var(--muted)">${t('Highest exam score (English)')}</div></div>
        <div><div style="font-size:20px;font-weight:800;color:var(--accent2)">22 ${t('days')}</div><div style="font-size:11px;color:var(--muted)">${t('Longest attendance streak')}</div></div>
        <div><div style="font-size:20px;font-weight:800;color:${stPctColor(96)}">96%</div><div style="font-size:11px;color:var(--muted)">${t('Best homework completion month')}</div></div>
      </div></div>`;
  if (tab === 'subjects') {
    const period = stState.academicsPeriod;
    return `${stPeriodBar('performance')}<div class="st-grid-2">${STUDENT_DATA.subjects.map(s=>{
      const stat = period==='year' ? stYearStat(s) : stSemesterStat(s, period);
      const series = stSubjectSeries(s, period);
      return `<div class="card"><div class="card-header"><div class="card-title">${s.icon} ${t(s.name)}</div></div>
      <div class="card-body">${series.values.length ? stAxisChart(series.xLabels,[{name:'',color:stGradeColor(stat.avg||10),values:series.values}],{yMax:20,yStep:5}) : `<div style="color:var(--muted);font-size:11px">${t('No exams recorded yet.')}</div>`}
      <div style="font-size:11px;color:var(--muted);margin-top:6px">${t('Coefficient')} ${s.weight} · ${t('Average')} ${stat.avg!=null?stat.avg.toFixed(1)+'/20':'—'}${!stat.isComplete?` · ${t('Based on completed exams')}`:''}</div></div></div>`;
    }).join('')}</div>`;
  }
  if (tab === 'development') return `
    <div class="st-grid-2">
      <div class="card"><div class="card-header"><div class="card-title">😊 ${t('Behavior Graph')}</div></div><div class="card-body">${stBarChart([{m:t('Oct'),v:2},{m:t('Nov'),v:3},{m:t('Dec'),v:1},{m:t('Jan'),v:4},{m:t('Feb'),v:3},{m:t('Mar'),v:4}],()=>'linear-gradient(180deg,#5fe37f,#2fd158)')}<div style="font-size:11px;color:var(--muted);margin-top:6px">${t('Positive behavior notes recorded per month')}</div></div></div>
      <div class="card"><div class="card-header"><div class="card-title">🙋 ${t('Participation Graph')}</div></div><div class="card-body">${stBarChart(STUDENT_DATA.participation.map(x=>({m:t(x.m),v:x.v})), stPctGradient, '%')}</div></div>
    </div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">📈 ${t('Overall Development Analytics')}</div></div>
      <div class="card-body"><div style="font-size:13px;line-height:1.7">${t('Combining academics, attendance, behavior and participation, overall development this year is trending steadily upward — with the sharpest gains in classroom participation')} (<span style="color:${stPctColor(participationNow)};font-weight:700">${participationNow}%</span>) ${t('and Physics performance.')}</div></div></div>`;
  if (tab === 'insights') return stInsights();
  return '';
}

function stInsights() {
  const avg = stOverallAvg();
  const best = STUDENT_DATA.subjects.reduce((a,b)=> ((a.t1+a.t2)/2 > (b.t1+b.t2)/2 ? a:b));
  const weakest = STUDENT_DATA.subjects.reduce((a,b)=> ((a.t1+a.t2)/2 < (b.t1+b.t2)/2 ? a:b));
  const items = [
    { icon:'📈', title:t('Improving fastest in')+' '+t(best.name), desc:t('Average rose from')+' '+best.trend[0]+' '+t('to')+' '+best.trend[best.trend.length-1]+' '+t('this year — the strongest gain of any subject.') },
    { icon:'🎯', title:t('Focus area')+': '+t(weakest.name), desc:t('Currently the lowest average at')+' '+((weakest.t1+weakest.t2)/2).toFixed(1)+'/20 — closing this gap would raise the overall average the most.' },
    { icon:'📅', title:t('Attendance insight'), desc:t('A 14-day attendance streak is currently active — 8 more days would match your personal best of 22.') },
    { icon:'🏅', title:t('Goal progress'), desc:t('The "Reach 17/20 overall average" goal is')+' '+Math.round((avg/17)*100)+'% '+t('complete based on the current average of')+' '+avg.toFixed(1)+'.'},
    { icon:'🙋', title:t('Participation insight'), desc:t('Class participation has climbed from 72% to 88% since October — the most consistent improvement of any tracked metric.') },
  ];
  return `<div class="card"><div class="card-header"><div class="card-title">💡 ${t('Personalized Insights')}</div></div>
    <div class="card-body" style="display:flex;flex-direction:column;gap:14px">
    ${items.map(i=>`<div style="display:flex;gap:12px"><div style="font-size:20px">${i.icon}</div><div><div style="font-weight:700;font-size:13px">${i.title}</div><div style="font-size:12px;color:var(--muted);margin-top:2px;line-height:1.5">${i.desc}</div></div></div>`).join('')}
    </div></div>`;
}

/* ═══════════════════════════════
   BEHAVIOR & ACHIEVEMENTS
═══════════════════════════════ */
function stBehavior() {
  const tabs = [ {id:'behavior', label:'Behavior & Participation'}, {id:'achievements', label:'Achievements & Badges'}, {id:'goals', label:'Personal Goals'} ];
  bodyFnRegistry.behavior = stBehaviorBody;
  return `${stTabsBar('behavior', tabs)}<div id="st-body-behavior">${stBehaviorBody(stState.tab.behavior)}</div>`;
}

function stBehaviorBody(tab) {
  if (tab === 'behavior') return `
    <div class="card"><div class="card-header"><div class="card-title">😊 ${t('Behavior Log')}</div></div>
      <div class="card-body" style="display:flex;flex-direction:column;gap:12px">
      ${STUDENT_DATA.behaviorLog.map(b=>`<div style="display:flex;gap:12px">
        <div style="font-size:18px">${b.type==='positive'?'👍':'📝'}</div>
        <div><div style="font-size:13px">${t(b.note)}</div><div style="font-size:11px;color:var(--muted);margin-top:2px">${b.date} · ${b.teacher}</div></div>
      </div>`).join('')}
      </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">🙋 ${t('Participation Trend')}</div></div>
      <div class="card-body">${stBarChart(STUDENT_DATA.participation.map(x=>({m:t(x.m),v:x.v})))}</div></div>`;
  if (tab === 'achievements') {
    const cats = [...new Set(STUDENT_DATA.badges.map(b=>b.category))];
    const mostRecent = STUDENT_DATA.badges.filter(b=>b.earned).sort((a,b)=>new Date(b.date)-new Date(a.date))[0];
    return `<div class="st-grid-3" style="margin-bottom:16px">
        <div class="stat-card cyan"><div class="stat-icon cyan">🏅</div><div class="stat-label">${t('Badges Earned')}</div><div class="stat-val">${STUDENT_DATA.badges.filter(b=>b.earned).length} / ${STUDENT_DATA.badges.length}</div></div>
        <div class="stat-card blue"><div class="stat-icon blue">🗂️</div><div class="stat-label">${t('Categories')}</div><div class="stat-val">${cats.length}</div></div>
        <div class="stat-card green"><div class="stat-icon green">🆕</div><div class="stat-label">${t('Most Recent')}</div><div class="stat-val" style="font-size:14px">${t(mostRecent.name)}</div></div>
      </div>
      ${cats.map(cat=>{
        const list = STUDENT_DATA.badges.filter(b=>b.category===cat);
        return `<div class="card" style="margin-bottom:16px"><div class="card-header"><div class="card-title">${t(cat)}</div><div class="card-action" style="cursor:default">${list.filter(b=>b.earned).length} / ${list.length}</div></div>
        <div class="card-body"><div class="badge-grid">
        ${list.map(b=>`
          <div class="badge-tile ${b.earned?'':'locked'}" onclick="stOpenBadge('${b.id}')">
            <div class="badge-emoji">${b.emoji}</div>
            <div class="badge-name">${t(b.name)}</div>
            ${b.earned?`<div class="badge-date">${b.date}</div>`:`<div class="badge-date">${t('Locked')}</div>`}
          </div>`).join('')}
        </div></div></div>`;
      }).join('')}
    <div class="card"><div class="card-header"><div class="card-title">📊 ${t('Achievement Analytics')}</div></div>
      <div class="card-body"><div class="info-row"><span>${t('Total earned')}</span><span>${STUDENT_DATA.badges.filter(b=>b.earned).length} / ${STUDENT_DATA.badges.length}</span></div>
      <div class="info-row"><span>${t('Most recent')}</span><span>${t(mostRecent.name)} — ${mostRecent.date}</span></div></div></div>`;
  }
  if (tab === 'goals') return `
    <div class="st-section-head"><h3>🎯 ${t('Personal Goals')}</h3><button class="st-btn sm" onclick="stOpenGoalForm()">${t('+ New Goal')}</button></div>
    <div style="display:flex;flex-direction:column;gap:12px">
    ${STUDENT_DATA.goals.map(g=>{
      const pct = Math.min(100, Math.round((g.current/g.target)*100));
      return `<div class="goal-card">
        <div class="goal-top"><div class="goal-title">${t(g.title)}</div><span class="grade-badge ${pct>=100?'high':''}">${pct}%</span></div>
        <div class="progress-track"><div class="progress-fill ${pct>=100?'green':pct>=60?'':'yellow'}" style="width:${pct}%"></div></div>
        <div class="goal-meta">${t('Current')}: ${g.current}${g.unit} · ${t('Target')}: ${g.target}${g.unit}</div>
        <div style="margin-top:10px;display:flex;gap:8px">
          <input class="calc-input" style="width:90px" type="number" step="0.1" id="goal-upd-${g.id}" placeholder="${t('Update')}">
          <button class="st-btn ghost sm" onclick="stUpdateGoal('${g.id}')">${t('Update Progress')}</button>
        </div>
      </div>`;
    }).join('')}
    </div>`;
  return '';
}

function stOpenBadge(id) {
  const b = STUDENT_DATA.badges.find(x=>x.id===id);
  stOpenModal(`
    <div class="st-modal-title">${b.emoji} ${t(b.name)}</div>
    <div class="st-modal-sub">${t(b.category)} · ${b.earned? (t('Earned on')+' '+b.date) : t('Not yet earned')}</div>
    <div style="font-size:13px;line-height:1.6">${t(b.desc)}</div>
  `);
}

function stOpenGoalForm() {
  stOpenModal(`
    <div class="st-modal-title">${t('Create a Personal Goal')}</div>
    <div class="st-field"><label>${t('Goal title')}</label><input id="ng-title" placeholder="${t('e.g. Reach 16/20 in French')}"></div>
    <div class="st-field"><label>${t('Target value')}</label><input id="ng-target" type="number" placeholder="e.g. 16"></div>
    <div class="st-field"><label>${t('Current value')}</label><input id="ng-current" type="number" placeholder="e.g. 14"></div>
    <button class="st-btn" onclick="stCreateGoal()">${t('Create Goal')}</button>
    <div class="st-inline-msg ok" id="ng-msg">${t('Goal created!')}</div>
  `);
}
function stCreateGoal() {
  const title = document.getElementById('ng-title').value.trim();
  const target = parseFloat(document.getElementById('ng-target').value);
  const current = parseFloat(document.getElementById('ng-current').value)||0;
  if (!title || isNaN(target)) return;
  STUDENT_DATA.goals.push({ id:'g'+(STUDENT_DATA.goals.length+1), title, target, current, unit:'' });
  document.getElementById('ng-msg').classList.add('show');
  setTimeout(()=>{ stCloseModal(); renderView('student','behavior'); }, 700);
}
function stUpdateGoal(id) {
  const g = STUDENT_DATA.goals.find(x=>x.id===id);
  const val = parseFloat(document.getElementById('goal-upd-'+id).value);
  if (isNaN(val)) return;
  g.current = val;
  document.getElementById('st-body-behavior').innerHTML = stBehaviorBody('goals');
}

/* ═══════════════════════════════
   RANKINGS & LEADERBOARDS
═══════════════════════════════ */
function stRankings() {
  const tabs = [ {id:'monthly', label:'Monthly'}, {id:'alltime', label:'All-Time'}, {id:'category', label:'By Category'}, {id:'anonymous', label:'Anonymous Rating'} ];
  bodyFnRegistry.rankings = stRankingsBody;
  return `${stTabsBar('rankings', tabs)}<div id="st-body-rankings">${stRankingsBody(stState.tab.rankings)}</div>`;
}

function stLbList(rows, suffix) {
  return `<div class="card"><div class="card-body">${rows.map((r,i)=>`
    <div class="lb-row ${r.me?'me':''}"><div class="lb-rank ${i===0?'top1':i===1?'top2':i===2?'top3':''}">${i+1}</div><div class="lb-name">${t(r.name)}</div><div class="lb-val">${r.val}${suffix||''}</div></div>
  `).join('')}</div></div>`;
}

function stRankingsBody(tab) {
  if (tab === 'monthly') return `<div style="font-size:12px;color:var(--muted);margin-bottom:10px">${t('Class 3B · March 2026 · Based on current test averages')}</div>${stLbList(STUDENT_DATA.rankingsMonthly,'/20')}`;
  if (tab === 'alltime') return `<div style="font-size:12px;color:var(--muted);margin-bottom:10px">${t('Class 3B · Cumulative since enrollment')}</div>${stLbList(STUDENT_DATA.rankingsAllTime,'/20')}`;
  if (tab === 'category') {
    const cats = [ ['attendance','Attendance'], ['homework','Homework Completion'], ['improvement','Improvement'], ['behavior','Positive Behavior'] ];
    return `<div class="st-tabs" style="margin-bottom:14px">${cats.map(c=>`<div class="st-tab${stState.rankCategory===c[0]?' active':''}" onclick="stSetRankCat('${c[0]}')">${t('Top 10 '+c[1])}</div>`).join('')}</div>
      <div id="rank-cat-list">${stLbList(STUDENT_DATA.rankingsCategory[stState.rankCategory])}</div>`;
  }
  if (tab === 'anonymous') return stTeacherRatingBody();
  return '';
}
function stSetRankCat(cat) { stState.rankCategory = cat; document.getElementById('st-body-rankings').innerHTML = stRankingsBody('category'); }

/* ── 12.2 Anonymous Teacher Rating: teacher select → multi-category
   5-star + note → auto-calculated overall (supports half-stars) → confirm. ── */
const TEACHER_RATING_CATEGORIES = ['Teaching Clarity','Explanation Quality','Organization','Helpfulness','Fairness'];
function stTeacherList() { return STUDENT_DATA.subjects.map(s=>({ id:s.id, name:s.teacher, subject:s.name })); }

function stTeacherRatingBody() {
  const state = stState.teacherRating;
  if (!state.teacherId) {
    return `<div class="card"><div class="card-header"><div class="card-title">🕶️ ${t('Anonymous Teacher Rating')}</div></div>
      <div class="card-body">
        <div style="font-size:12px;color:var(--muted);margin-bottom:14px">${t('Ratings are completely anonymous — your identity is never shared with teachers or staff. Choose a teacher to rate.')}</div>
        <div class="st-grid-3">${stTeacherList().map(tc=>`<div class="card" style="cursor:pointer" onclick="stSelectRatingTeacher('${tc.id}')"><div class="card-body" style="text-align:center;padding:16px 10px">
          <div style="font-size:24px;margin-bottom:6px">👤</div>
          <div style="font-weight:700;font-size:13px">${tc.name}</div>
          <div style="font-size:11px;color:var(--muted)">${t(tc.subject)}</div>
        </div></div>`).join('')}</div>
      </div></div>`;
  }
  const teacher = stTeacherList().find(x=>x.id===state.teacherId);
  return `<div class="card"><div class="card-header"><div class="card-title">🕶️ ${t('Rate')} ${teacher.name}</div><div class="card-action" onclick="stBackToTeacherSelect()">${t('← Change teacher')}</div></div>
    <div class="card-body">
      <div style="font-size:12px;color:var(--muted);margin-bottom:16px">${t('This rating is anonymous —')} ${teacher.name} ${t('will not know it was you.')}</div>
      ${TEACHER_RATING_CATEGORIES.map((c,i)=>`
        <div style="margin-bottom:18px">
          <div style="font-weight:600;font-size:13px;margin-bottom:6px">${t(c)}</div>
          <div style="display:flex;gap:6px;margin-bottom:8px">${[1,2,3,4,5].map(n=>`<span onclick="stSetTeacherRating(${i},${n})" id="tstar-${i}-${n}" style="cursor:pointer;font-size:20px;color:var(--muted)">★</span>`).join('')}</div>
          <textarea id="tnote-${i}" rows="2" placeholder="${t('Optional note for this category...')}" style="width:100%;border-radius:8px;border:1px solid var(--border,#333);padding:8px;font-size:12.5px;background:transparent;color:inherit;resize:vertical"></textarea>
        </div>`).join('')}
      <div id="trate-error" style="display:none;color:var(--red);font-size:11.5px;margin-bottom:10px"></div>
      <button class="st-btn" onclick="stSubmitTeacherRating()">${t('Submit Anonymous Rating')}</button>
    </div></div>`;
}
function stSelectRatingTeacher(id) {
  stState.teacherRating = { teacherId:id, ratings:{}, notes:{} };
  document.getElementById('st-body-rankings').innerHTML = stRankingsBody('anonymous');
}
function stBackToTeacherSelect() {
  stState.teacherRating = { teacherId:null, ratings:{}, notes:{} };
  document.getElementById('st-body-rankings').innerHTML = stRankingsBody('anonymous');
}
function stSetTeacherRating(i, n) {
  stState.teacherRating.ratings[i] = n;
  for (let k=1;k<=5;k++){ const el=document.getElementById(`tstar-${i}-${k}`); if (el) el.style.color = k<=n?'var(--yellow)':'var(--muted)'; }
}
function stSubmitTeacherRating() {
  const ratings = stState.teacherRating.ratings;
  const missing = TEACHER_RATING_CATEGORIES.some((_,i)=> !ratings[i]);
  const err = document.getElementById('trate-error');
  if (missing) { if (err) { err.style.display='block'; err.textContent = t('Please rate every category before submitting.'); } return; }
  const notes = {};
  TEACHER_RATING_CATEGORIES.forEach((_,i)=>{ const el=document.getElementById(`tnote-${i}`); notes[i] = el ? el.value.trim() : ''; });
  stState.teacherRating.notes = notes;
  const vals = TEACHER_RATING_CATEGORIES.map((_,i)=>ratings[i]);
  const avg = vals.reduce((a,b)=>a+b,0) / vals.length;
  const overall = Math.round(avg*2)/2; // half-star precision
  const teacher = stTeacherList().find(x=>x.id===stState.teacherRating.teacherId);
  const area = document.getElementById('st-body-rankings');
  if (area) area.innerHTML = `
    <div class="card"><div class="card-body" style="text-align:center;padding:30px 20px">
      <div style="font-size:34px;margin-bottom:10px">✅</div>
      <div style="font-weight:700;font-size:16px;margin-bottom:6px">${t('Rating Submitted')}</div>
      <div style="font-size:13px;color:var(--muted);margin-bottom:14px">${t('Your anonymous rating for')} <strong>${teacher.name}</strong> ${t('has been recorded. Your identity is never shared with teachers or staff.')}</div>
      <div style="font-size:28px;font-weight:800;color:var(--yellow)">${overall.toFixed(1)} / 5</div>
      <div style="font-size:11px;color:var(--muted);margin-top:4px">${t('Overall rating — calculated automatically from your category scores')}</div>
      <button class="st-btn ghost sm" style="margin-top:18px" onclick="stBackToTeacherSelect()">${t('Rate Another Teacher')}</button>
    </div></div>`;
}
/* ═══════════════════════════════
   ORIENTATION & FUTURE
═══════════════════════════════ */
function stOrientation() {
  const tabs = [ {id:'paths', label:'Study Paths'}, {id:'programs', label:'Post-Bac Programs'}, {id:'careers', label:'Career Paths'}, {id:'compare', label:'Compare'} ];
  bodyFnRegistry.orientation = stOrientationBody;
  return `${stTabsBar('orientation', tabs)}<div id="st-body-orientation">${stOrientationBody(stState.tab.orientation)}</div>`;
}

function stOrientCard(o) {
  return `<div class="orient-card" onclick="stOpenOrient('${o.id}','${o._cat}')">
    <div class="orient-tag">${t(o.tag)}</div>
    <div style="font-weight:700;font-size:14px;margin-bottom:6px">${t(o.name)}</div>
    <div style="font-size:12px;color:var(--muted);line-height:1.5">${t(o.desc)}</div>
    ${o.match?`<div style="margin-top:10px"><span class="grade-badge high">${t(o.match)}</span></div>`:''}
  </div>`;
}

function stOrientationBody(tab) {
  if (tab === 'paths') {
    STUDENT_DATA.orientationPaths.forEach(o=>o._cat='paths');
    return `<div class="st-grid-3">${STUDENT_DATA.orientationPaths.map(stOrientCard).join('')}</div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">🧭 ${t('Advanced Pathway Analysis')}</div></div>
      <div class="card-body"><div style="font-size:13px;line-height:1.7">${t('Based on strong and improving Mathematics and Physics averages, Sciences Mathématiques is the closest match. Sciences Économiques and Lettres Modernes remain solid alternatives given balanced performance in Economics-adjacent and language subjects.')}</div></div></div>`;
  }
  if (tab === 'programs') {
    STUDENT_DATA.orientationPrograms.forEach(o=>o._cat='programs');
    return `<div class="st-grid-2">${STUDENT_DATA.orientationPrograms.map(stOrientCard).join('')}</div>
    <div style="font-size:11px;color:var(--muted);margin-top:14px">${t('Programs shown are for guidance and may vary by admissions cycle.')}</div>`;
  }
  if (tab === 'careers') {
    STUDENT_DATA.orientationCareers.forEach(o=>o._cat='careers');
    return `<div class="st-grid-3">${STUDENT_DATA.orientationCareers.map(stOrientCard).join('')}</div>`;
  }
  if (tab === 'compare') {
    const all = [...STUDENT_DATA.orientationPaths, ...STUDENT_DATA.orientationPrograms];
    return `<div class="card"><div class="card-header"><div class="card-title">⚖️ ${t('Compare Study Paths & Programs')}</div></div>
      <div class="table-wrap"><table><thead><tr><th>${t('Name')}</th><th>${t('Type')}</th><th>${t('Description')}</th></tr></thead>
      <tbody>${all.map(o=>`<tr><td>${t(o.name)}</td><td>${t(o.tag)}</td><td style="font-size:12px;color:var(--muted)">${t(o.desc)}</td></tr>`).join('')}</tbody></table></div></div>`;
  }
  return '';
}

function stOpenOrient(id, cat) {
  const map = { paths:STUDENT_DATA.orientationPaths, programs:STUDENT_DATA.orientationPrograms, careers:STUDENT_DATA.orientationCareers };
  const o = map[cat].find(x=>x.id===id);
  stOpenModal(`
    <div class="st-modal-title">${t(o.name)}</div>
    <div class="st-modal-sub">${t(o.tag)}</div>
    <div style="font-size:13px;line-height:1.7">${t(o.desc)}</div>
    ${o.match?`<div style="margin-top:14px"><span class="grade-badge high">${t(o.match)}</span> ${t('based on current academic profile')}</div>`:''}
  `);
}

/* ═══════════════════════════════
   HISTORY
═══════════════════════════════ */
function stHistory() {
  const years = Object.keys(STUDENT_DATA.historyYears);
  bodyFnRegistry.history = stHistoryBody;
  return `
  <div class="year-tabs">${years.map(y=>`<div class="year-tab${stState.tab.history===y?' active':''}" onclick="stSetYear('${y}')">${y}</div>`).join('')}</div>
  <div id="st-body-history">${stHistoryBody(stState.tab.history)}</div>`;
}
function stSetYear(y) {
  stState.tab.history = y;
  document.querySelectorAll('.year-tab').forEach(el=>el.classList.toggle('active', el.textContent===y));
  document.getElementById('st-body-history').innerHTML = stHistoryBody(y);
}
function stHistoryBody(year) {
  const d = STUDENT_DATA.historyYears[year];
  const years = Object.keys(STUDENT_DATA.historyYears).reverse();
  const avgs = years.map(y=>({m:y, v:STUDENT_DATA.historyYears[y].avg}));
  return `
  <div class="st-grid-4">
    <div class="stat-card blue"><div class="stat-icon blue">📊</div><div class="stat-label">${t('Average')}</div><div class="stat-val">${d.avg}/20</div></div>
    <div class="stat-card green"><div class="stat-icon green">📅</div><div class="stat-label">${t('Attendance')}</div><div class="stat-val">${d.attendance}%</div></div>
    <div class="stat-card cyan"><div class="stat-icon cyan">🏆</div><div class="stat-label">${t('Rank')}</div><div class="stat-val">${d.rank}</div></div>
    <div class="stat-card purple"><div class="stat-icon purple">🏅</div><div class="stat-label">${t('Achievements')}</div><div class="stat-val">${d.achievements}</div></div>
  </div>
  <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Year Notes')}</div></div><div class="card-body"><div style="font-size:13px;line-height:1.6">${t(d.note)}</div></div></div>
  <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">📈 ${t('Full Year-by-Year History')}</div></div>
    <div class="card-body">${stBarChart(avgs)}<div style="font-size:11.5px;color:var(--muted);margin-top:8px">${t('Overall average across every year at this institution — clear upward trend.')}</div></div></div>`;
}

/* ═══════════════════════════════
   NOTIFICATIONS
═══════════════════════════════ */
function stNotifications() {
  const tabs = [ {id:'all', label:'All'}, {id:'unread', label:'Unread', badge:String(STUDENT_DATA.notifications.filter(n=>n.unread).length)}, {id:'grades', label:'Grades'}, {id:'exam', label:'Exams'}, {id:'homework', label:'Homework'} ];
  bodyFnRegistry.notifications = stNotificationsBody;
  return `${stTabsBar('notifications', tabs)}<div id="st-body-notifications">${stNotificationsBody(stState.tab.notifications)}</div>`;
}
function stNotificationsBody(tab) {
  let list = STUDENT_DATA.notifications;
  if (tab === 'unread') list = list.filter(n=>n.unread);
  else if (tab === 'grades') list = list.filter(n=>n.type==='grade');
  else if (tab === 'exam') list = list.filter(n=>n.type==='exam');
  else if (tab === 'homework') list = list.filter(n=>n.type==='homework');
  if (!list.length) return `<div class="card"><div class="card-body" style="text-align:center;color:var(--muted);padding:30px">${t('No notifications here.')}</div></div>`;
  return `<div class="card"><div class="card-body" style="display:flex;flex-direction:column;gap:2px">
    ${list.map(n=>`<div class="notif-full ${n.unread?'unread':''}" onclick="stOpenNotification('${n.id}')">
      ${n.unread?'<div class="dot"></div>':'<div style="width:8px"></div>'}
      <div style="font-size:20px">${n.icon}</div>
      <div style="flex:1"><div class="notif-tag ${n.type}">${t(n.tag)}</div><div style="font-weight:600;font-size:13px;margin-top:2px">${t(n.title)}</div><div style="font-size:12px;color:var(--muted);margin-top:2px">${t(n.desc)}</div><div style="font-size:11px;color:var(--muted);margin-top:4px">${n.time}</div></div>
    </div>`).join('')}
  </div></div>`;
}
function stOpenNotification(id) {
  const n = STUDENT_DATA.notifications.find(x=>x.id===id);
  n.unread = false;
  stOpenModal(`
    <div class="st-modal-title">${n.icon} ${t(n.title)}</div>
    <div class="st-modal-sub">${t(n.tag)} · ${n.time}</div>
    <div style="font-size:13px;line-height:1.6">${t(n.desc)}</div>
  `);
  const activeSection = document.querySelector('.nav-item.active');
  if (activeSection && (activeSection.getAttribute('onclick')||'').includes('notifications')) {
    document.getElementById('st-body-notifications').innerHTML = stNotificationsBody(stState.tab.notifications);
  }
  stUpdateNotifDot();
}

/* ═══════════════════════════════
   14. NOTIFICATION BELL — small dropdown with the latest notifications,
   unread indicators, and a "See all" button that navigates to the
   full Notifications page.
═══════════════════════════════ */
function stUnreadNotifCount() { return STUDENT_DATA.notifications.filter(n=>n.unread).length; }
function stUpdateNotifDot() {
  const dot = document.getElementById('notif-dot');
  if (!dot) return;
  dot.style.display = stUnreadNotifCount() > 0 ? 'block' : 'none';
}
function stRenderNotifPanel() {
  let panel = document.getElementById('notif-panel');
  if (!panel) {
    panel = document.createElement('div');
    panel.id = 'notif-panel';
    panel.className = 'notif-panel';
    const anchor = document.querySelector('.topbar-right');
    (anchor || document.body).appendChild(panel);
  }
  const latest = STUDENT_DATA.notifications.slice(0, 5);
  panel.innerHTML = `
    <div class="notif-panel-header">${t('Notifications')}</div>
    <div class="notif-panel-list">
      ${latest.length ? latest.map(n=>`<div class="notif-panel-row" onclick="stOpenNotifFromPanel('${n.id}')">
        ${n.unread ? '<div class="dot"></div>' : '<div style="width:7px"></div>'}
        <div style="font-size:16px">${n.icon}</div>
        <div style="flex:1;min-width:0">
          <div style="font-weight:600;font-size:12.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${t(n.title)}</div>
          <div style="font-size:11px;color:var(--muted)">${n.time}</div>
        </div>
      </div>`).join('') : `<div style="padding:20px;text-align:center;color:var(--muted);font-size:12px">${t('No notifications yet.')}</div>`}
    </div>
    <div class="notif-panel-footer" onclick="stSeeAllNotifications()">${t('See all')} →</div>
  `;
}
function stToggleNotifPanel(e) {
  if (e) e.stopPropagation();
  stRenderNotifPanel();
  const panel = document.getElementById('notif-panel');
  panel.classList.toggle('open');
}
function stOpenNotifFromPanel(id) {
  stOpenNotification(id);
  stRenderNotifPanel();
}
function stSeeAllNotifications() {
  const panel = document.getElementById('notif-panel');
  if (panel) panel.classList.remove('open');
  stGoTo('notifications');
}

/* ── Generic in-app navigation helper: click the matching sidebar item
   (reusing switchView's own logic) then, if requested, jump straight to
   a specific sub-tab within that page. Used by search and the notif bell. */
function stGoTo(viewId, subTab) {
  const navEl = document.querySelector(`.nav-item[onclick*="'${viewId}'"]`);
  if (navEl) navEl.click(); else if (typeof renderView === 'function') renderView(currentRole, viewId);
  if (subTab && stState.tab && (viewId in stState.tab) && typeof stSetTab === 'function' && bodyFnRegistry[viewId]) {
    stSetTab(viewId, subTab, null);
  }
}

/* ═══════════════════════════════
   15. GLOBAL SEARCH — searches across every Student page + subjects,
   shows a dropdown of matches, and navigates straight to the result.
═══════════════════════════════ */
function stSearchIndex() {
  const pages = [
    { label:t('Dashboard'), sub:t('Overview of your performance'), viewId:'home' },
    { label:t('Academics'), sub:t('Grades, subjects & progress'), viewId:'academics' },
    { label:t('Grades'), sub:t('Academics'), viewId:'academics', subTab:'grades' },
    { label:t('Subjects'), sub:t('Academics'), viewId:'academics', subTab:'subjects' },
    { label:t('Progress Graphs'), sub:t('Academics'), viewId:'academics', subTab:'trends' },
    { label:t('Grade Calculator'), sub:t('Academics'), viewId:'academics', subTab:'calculators' },
    { label:t('Advanced Analysis'), sub:t('Academics'), viewId:'academics', subTab:'analysis' },
    { label:t('Attendance'), sub:t('Calendar & absence history'), viewId:'attendance' },
    { label:t('Attendance Calendar'), sub:t('Attendance'), viewId:'attendance', subTab:'calendar' },
    { label:t('Absence History'), sub:t('Attendance'), viewId:'attendance', subTab:'history' },
    { label:t('Homework'), sub:t('Assignments & analytics'), viewId:'homework' },
    { label:t('Homework Analytics'), sub:t('Homework'), viewId:'homework', subTab:'analytics' },
    { label:t('Exams'), sub:t('Upcoming exams & scores'), viewId:'exams' },
    { label:t('Exam Scores'), sub:t('Exams'), viewId:'exams', subTab:'history' },
    { label:t('Performance & Analytics'), sub:t('Student 360 profile'), viewId:'performance' },
    { label:t('Student 360'), sub:t('Performance & Analytics'), viewId:'performance', subTab:'360' },
    { label:t('Behavior & Achievements'), sub:t('Badges & behavior log'), viewId:'behavior' },
    { label:t('Achievements'), sub:t('Behavior & Achievements'), viewId:'behavior', subTab:'achievements' },
    { label:t('Personal Goals'), sub:t('Behavior & Achievements'), viewId:'behavior', subTab:'goals' },
    { label:t('Rankings'), sub:t('Class rankings & ratings'), viewId:'rankings' },
    { label:t('Anonymous Teacher Rating'), sub:t('Rankings'), viewId:'rankings', subTab:'anonymous' },
    { label:t('Orientation & Future'), sub:t('Study paths & careers'), viewId:'orientation' },
    { label:t('History'), sub:t('Year-by-year record'), viewId:'history' },
    { label:t('Notifications'), sub:t('All notifications'), viewId:'notifications' },
    { label:t('Account & Support'), sub:t('Profile, security & help'), viewId:'account' },
    { label:t('Password & Email'), sub:t('Account & Support'), viewId:'account', subTab:'security' },
    { label:t('Contact Support'), sub:t('Account & Support'), viewId:'account', subTab:'support' },
  ];
  const subjects = STUDENT_DATA.subjects.map(s => ({ label:t(s.name), sub:t('Subject')+' · '+s.teacher, viewId:'academics', subTab:'subjects' }));
  return pages.concat(subjects);
}
let stSearchLastMatches = [];
function stSearchInput(val) {
  const q = (val||'').trim().toLowerCase();
  const box = document.getElementById('search-results');
  if (!box) return;
  if (!q) { box.classList.remove('open'); box.innerHTML=''; return; }
  const matches = stSearchIndex().filter(item =>
    item.label.toLowerCase().includes(q) || (item.sub||'').toLowerCase().includes(q)
  ).slice(0, 8);
  stSearchLastMatches = matches;
  box.innerHTML = matches.length
    ? matches.map((m,i)=>`<div class="search-result-row" onmousedown="stSearchGo(${i})"><div style="font-weight:600;font-size:12.5px">${m.label}</div><div style="font-size:11px;color:var(--muted)">${m.sub||''}</div></div>`).join('')
    : `<div class="search-empty">${t('No results for')} "${val}"</div>`;
  box.classList.add('open');
}
function stSearchGo(i) {
  const m = stSearchLastMatches[i];
  const input = document.getElementById('search-input');
  const box = document.getElementById('search-results');
  if (input) input.value = '';
  if (box) { box.classList.remove('open'); box.innerHTML=''; }
  if (m) stGoTo(m.viewId, m.subTab);
}
function stSearchBlur() {
  const box = document.getElementById('search-results');
  if (box) box.classList.remove('open');
}
document.addEventListener('click', function(e) {
  const panel = document.getElementById('notif-panel');
  const btn = document.getElementById('notif-bell-btn');
  if (panel && panel.classList.contains('open') && !panel.contains(e.target) && (!btn || !btn.contains(e.target))) {
    panel.classList.remove('open');
  }
});

/* ═══════════════════════════════
   ACCOUNT & SUPPORT
═══════════════════════════════ */
function stAccount() {
  const tabs = [ {id:'profile', label:'Profile'}, {id:'settings', label:'Account Settings'}, {id:'security', label:'Password & Email'}, {id:'support', label:'Support'} ];
  bodyFnRegistry.account = stAccountBody;
  return `${stTabsBar('account', tabs)}<div id="st-body-account">${stAccountBody(stState.tab.account)}</div>`;
}

function stAccountBody(tab) {
  if (tab === 'profile') return `
    <div class="card"><div class="card-body" style="display:flex;gap:18px;align-items:center;flex-wrap:wrap">
      <div style="width:64px;height:64px;border-radius:18px;background:linear-gradient(180deg,rgba(59,130,246,0.3),rgba(59,130,246,0.12));display:flex;align-items:center;justify-content:center;font-weight:800;font-size:20px">YA</div>
      <div><div style="font-size:17px;font-weight:800">Youssef Amrani</div><div style="font-size:12.5px;color:var(--muted);margin-top:2px">${t('Student')} · S12345678</div></div>
    </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Personal Information')}</div></div>
      <div class="card-body">
      <div style="font-size:11px;color:var(--muted);margin-bottom:10px">${t('This information is managed by your school and cannot be edited here.')}</div>
      <div class="info-row"><span>${t('Full Name')}</span><span>Youssef Amrani</span></div>
      <div class="info-row"><span>${t('Authren Student ID')}</span><span>S12345678</span></div>
      <div class="info-row"><span>${t('Class')}</span><span>3B</span></div>
      <div class="info-row"><span>${t('School')}</span><span>Al Farabi Private School</span></div>
      <div class="info-row"><span>${t('Academic Year')}</span><span>2025 / 2026</span></div>
      <div class="info-row"><span>${t('Date of Birth')}</span><span>—</span></div>
      <div class="info-row"><span>${t('Guardian')}</span><span>Mr. Amrani (Father)</span></div>
      </div></div>`;
  if (tab === 'settings') return `
    <div style="display:flex;flex-direction:column;gap:10px">
      <div class="account-tile" onclick="stSetTab('account','security',null); document.getElementById('st-body-account').innerHTML=stAccountBody('security')"><div class="account-tile-ico">🔐</div><div class="account-tile-text"><div class="account-tile-title">${t('Password & Email')}</div><div class="account-tile-sub">${t('Manage login credentials')}</div></div></div>
      <div class="account-tile" onclick="stOpenNotifPrefs()"><div class="account-tile-ico">🔔</div><div class="account-tile-text"><div class="account-tile-title">${t('Notification Preferences')}</div><div class="account-tile-sub">${t('Choose what you get notified about')}</div></div></div>
      <div class="account-tile" onclick="stSetTab('account','support',null); document.getElementById('st-body-account').innerHTML=stAccountBody('support')"><div class="account-tile-ico">💬</div><div class="account-tile-text"><div class="account-tile-title">${t('Support Contact')}</div><div class="account-tile-sub">${t('Get help from Authren or your school')}</div></div></div>
    </div>`;
  if (tab === 'security') return `
    <div class="st-grid-2">
      <div class="card"><div class="card-header"><div class="card-title">🔑 ${t('Password Management')}</div></div>
        <div class="card-body">
          <div class="st-field"><label>${t('Current Password')}</label>
            <div class="pass-input-wrap"><input type="password" id="pw-cur" style="padding-right:40px">
              <button type="button" class="toggle-pass-btn" onclick="togglePasswordVisibility('pw-cur', this)" aria-label="Toggle password visibility">${EYE_CLOSED_SVG}</button>
            </div></div>
          <div class="st-field"><label>${t('New Password')}</label>
            <div class="pass-input-wrap"><input type="password" id="pw-new" oninput="stCheckPwStrength()" style="padding-right:40px">
              <button type="button" class="toggle-pass-btn" onclick="togglePasswordVisibility('pw-new', this)" aria-label="Toggle password visibility">${EYE_CLOSED_SVG}</button>
            </div></div>
          <div class="st-field-ok" id="pw-hint" style="display:block;font-size:11px;color:var(--muted)">${t('Minimum 6 characters, with at least 1 letter and 1 number.')}</div>
          <div class="st-field"><label>${t('Confirm New Password')}</label>
            <div class="pass-input-wrap"><input type="password" id="pw-confirm" style="padding-right:40px">
              <button type="button" class="toggle-pass-btn" onclick="togglePasswordVisibility('pw-confirm', this)" aria-label="Toggle password visibility">${EYE_CLOSED_SVG}</button>
            </div></div>
          <button class="st-btn" onclick="stChangePassword()">${t('Update Password')}</button>
          <div class="st-inline-msg ok" id="pw-msg-ok">${t('Password updated successfully.')}</div>
          <div class="st-inline-msg err" id="pw-msg-err"></div>
        </div></div>
      <div class="card"><div class="card-header"><div class="card-title">✉️ ${t('Email Management')}</div></div>
        <div class="card-body">
          <div class="info-row"><span>${t('Current Email')}</span><span id="em-current-val">${STUDENT_DATA.account.email}</span></div>
          <div class="st-field" style="margin-top:12px"><label>${t('New Email')}</label><input type="email" id="em-new"></div>
          <button class="st-btn ghost" onclick="stRequestEmailChange()">${t('Send Verification Code')}</button>
          <div id="em-verify-block" style="display:none;margin-top:12px">
            <div class="st-field"><label>${t('Verification Code')}</label><input id="em-code" placeholder="000000" maxlength="6"></div>
            <button class="st-btn" onclick="stVerifyEmailChange()">${t('Verify & Update Email')}</button>
          </div>
          <div class="st-inline-msg ok" id="em-msg-ok"></div>
          <div class="st-inline-msg err" id="em-msg-err"></div>
        </div></div>
    </div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">🛟 ${t('Password Recovery')}</div></div>
      <div class="card-body">
        <div style="font-size:12.5px;color:var(--muted);margin-bottom:12px">${t('Forgot your password? Start the recovery process here.')}</div>
        <button class="st-btn ghost" onclick="stOpenPasswordRecovery()">${t('Start Password Recovery')}</button>
      </div></div>`;
  if (tab === 'support') return `<div id="sup-body">${stSupportBody()}</div>${stMessagesCard()}
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">📞 ${t('Other Ways to Reach Us')}</div></div>
      <div class="card-body">
        <div class="info-row"><span>${t('Authren Support Email')}</span><span>support@authren.app</span></div>
        <div class="info-row"><span>${t('School Office')}</span><span>+212 5XX-XXXXXX</span></div>
      </div></div>`;
  return '';
}

/* ── 13.5 Contact Support: recipient type → (teacher picker) → topic → message → confirm ── */
function stSupportBody() {
  const f = stState.supportFlow;
  if (!f.recipientType) {
    return `<div class="card"><div class="card-header"><div class="card-title">💬 ${t('Contact Support')}</div></div>
      <div class="card-body">
        <div style="font-size:12.5px;color:var(--muted);margin-bottom:14px">${t('Choose who you would like to contact.')}</div>
        <div style="display:flex;gap:10px;flex-wrap:wrap">
          <button class="st-btn ghost" onclick="stSupportSetRecipient('head')">🏫 ${t('Head of Institution')}</button>
          <button class="st-btn ghost" onclick="stSupportSetRecipient('teacher')">👤 ${t('Teacher')}</button>
        </div>
      </div></div>`;
  }
  if (f.recipientType === 'teacher' && !f.teacherId) {
    return `<div class="card"><div class="card-header"><div class="card-title">💬 ${t('Contact Support')}</div><div class="card-action" onclick="stSupportReset()">${t('← Back')}</div></div>
      <div class="card-body">
        <div style="font-size:12.5px;color:var(--muted);margin-bottom:14px">${t('Choose which teacher to contact.')}</div>
        <div class="st-grid-3">${stTeacherList().map(tc=>`<div class="card" style="cursor:pointer" onclick="stSupportSetTeacher('${tc.id}')"><div class="card-body" style="text-align:center;padding:14px 8px"><div style="font-size:22px">👤</div><div style="font-weight:700;font-size:12.5px;margin-top:4px">${tc.name}</div><div style="font-size:10.5px;color:var(--muted)">${t(tc.subject)}</div></div></div>`).join('')}</div>
      </div></div>`;
  }
  const recipientLabel = f.recipientType==='head' ? t('Head of Institution') : stTeacherList().find(x=>x.id===f.teacherId).name;
  const topics = ['Grades / Academics','Attendance','Behavior','Technical Problem','Other'];
  if (!f.topic) f.topic = topics[0];
  return `<div class="card"><div class="card-header"><div class="card-title">💬 ${t('Message to')} ${recipientLabel}</div><div class="card-action" onclick="stSupportReset()">${t('← Start Over')}</div></div>
    <div class="card-body">
      <div class="st-field"><label>${t('Topic')}</label>
        <select id="sup-topic" onchange="stSupportTopicChange(this.value)">${topics.map(tp=>`<option value="${tp}" ${f.topic===tp?'selected':''}>${t(tp)}</option>`).join('')}</select>
      </div>
      <div class="st-field" id="sup-custom-wrap" style="${f.topic==='Other'?'':'display:none'}"><label>${t('Describe the topic')}</label><input id="sup-custom-topic" value="${f.customTopic||''}"></div>
      <div class="st-field"><label>${t('Message')}</label><textarea id="sup-msg" rows="4" placeholder="${t('Describe your issue...')}"></textarea></div>
      <div id="sup-err" style="display:none;color:var(--red);font-size:11.5px;margin-bottom:8px"></div>
      <button class="st-btn" onclick="stSubmitSupport()">${t('Send Message')}</button>
    </div></div>`;
}
function stSupportSetRecipient(type) { stState.supportFlow = { recipientType:type, teacherId:null, topic:null, customTopic:'' }; stRerenderSupport(); }
function stSupportSetTeacher(id) { stState.supportFlow.teacherId = id; stRerenderSupport(); }
function stSupportTopicChange(v) { stState.supportFlow.topic = v; const wrap=document.getElementById('sup-custom-wrap'); if (wrap) wrap.style.display = v==='Other' ? 'block' : 'none'; }
function stSupportReset() { stState.supportFlow = { recipientType:null, teacherId:null, topic:null, customTopic:'' }; stRerenderSupport(); }
function stRerenderSupport() { const el=document.getElementById('sup-body'); if (el) el.innerHTML = stSupportBody(); }
function stSubmitSupport() {
  const f = stState.supportFlow;
  const topicEl = document.getElementById('sup-topic');
  const topic = topicEl ? topicEl.value : f.topic;
  const custom = document.getElementById('sup-custom-topic');
  const msgEl = document.getElementById('sup-msg');
  const msg = msgEl ? msgEl.value.trim() : '';
  const err = document.getElementById('sup-err');
  if (!msg) { if (err) { err.style.display='block'; err.textContent = t('Please enter a message before sending.'); } return; }
  if (topic==='Other' && custom && !custom.value.trim()) { if (err) { err.style.display='block'; err.textContent = t('Please describe the topic.'); } return; }
  const recipientLabel = f.recipientType==='head' ? t('Head of Institution') : stTeacherList().find(x=>x.id===f.teacherId).name;
  const el = document.getElementById('sup-body');
  if (el) el.innerHTML = `<div class="card"><div class="card-body" style="text-align:center;padding:30px 20px">
    <div style="font-size:34px;margin-bottom:10px">✅</div>
    <div style="font-weight:700;font-size:15px;margin-bottom:6px">${t('Your message has been sent. They will respond soon.')}</div>
    <div style="font-size:12.5px;color:var(--muted)">${t('Sent to')} ${recipientLabel}</div>
    <button class="st-btn ghost sm" style="margin-top:16px" onclick="stSupportReset()">${t('Send Another Message')}</button>
  </div></div>`;
}

/* ── 13.6 Messages & Replies (received from teachers / Head of Institution) ── */
function stMessagesCard() {
  const list = STUDENT_DATA.inboxMessages;
  return `<div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">📥 ${t('Messages & Replies')}</div></div>
    <div class="card-body" style="display:flex;flex-direction:column;gap:2px">
    ${list.map(m=>`<div class="notif-full ${!m.read?'unread':''}" onclick="stOpenInboxMessage('${m.id}')">
      ${!m.read?'<div class="dot"></div>':'<div style="width:8px"></div>'}
      <div style="font-size:20px">${m.senderType==='head'?'🏫':'👤'}</div>
      <div style="flex:1"><div class="notif-tag">${t(m.topic)}</div><div style="font-weight:600;font-size:13px;margin-top:2px">${m.sender}</div><div style="font-size:12px;color:var(--muted);margin-top:2px">${m.preview}</div><div style="font-size:11px;color:var(--muted);margin-top:4px">${m.date} · ${m.read?t('Read'):t('Unread')}</div></div>
    </div>`).join('')}
    </div></div>`;
}
function stOpenInboxMessage(id) {
  const m = STUDENT_DATA.inboxMessages.find(x=>x.id===id);
  m.read = true;
  stOpenModal(`
    <div class="st-modal-title">${m.sender}</div>
    <div class="st-modal-sub">${t(m.topic)} · ${m.date}</div>
    <div style="font-size:13px;line-height:1.7;margin-top:10px">${m.body}</div>
  `);
  const el = document.getElementById('st-body-account');
  if (el && stState.tab.account==='support') el.innerHTML = stAccountBody('support');
}

function stOpenNotifPrefs() {
  stOpenModal(`
    <div class="st-modal-title">${t('Notification Preferences')}</div>
    ${['Grades','Homework Deadlines','Exam Reminders','Attendance Alerts','Announcements'].map((l,i)=>`
      <div style="display:flex;justify-content:space-between;align-items:center;padding:10px 0;border-bottom:0.5px solid var(--separator)">
        <span style="font-size:13px">${t(l)}</span><input type="checkbox" checked style="width:18px;height:18px">
      </div>`).join('')}
    <button class="st-btn" style="margin-top:14px" onclick="stCloseModal()">${t('Save Preferences')}</button>
  `);
}

function stCheckPwStrength() {
  const v = document.getElementById('pw-new').value;
  const ok = v.length>=6 && /[a-zA-Z]/.test(v) && /[0-9]/.test(v);
  document.getElementById('pw-hint').style.color = v.length===0 ? 'var(--muted)' : ok ? 'var(--green)' : 'var(--red)';
}
function stChangePassword() {
  const cur = document.getElementById('pw-cur').value;
  const nw = document.getElementById('pw-new').value;
  const cf = document.getElementById('pw-confirm').value;
  const okBox = document.getElementById('pw-msg-ok'), errBox = document.getElementById('pw-msg-err');
  okBox.classList.remove('show'); errBox.classList.remove('show');
  if (!cur) { errBox.textContent = t('Enter your current password.'); errBox.classList.add('show'); return; }
  if (nw.length<6 || !/[a-zA-Z]/.test(nw) || !/[0-9]/.test(nw)) { errBox.textContent = t('New password must be at least 6 characters with a letter and a number.'); errBox.classList.add('show'); return; }
  if (nw !== cf) { errBox.textContent = t('Passwords do not match.'); errBox.classList.add('show'); return; }
  okBox.classList.add('show');
  document.getElementById('pw-cur').value=''; document.getElementById('pw-new').value=''; document.getElementById('pw-confirm').value='';
}

function stRequestEmailChange() {
  const em = document.getElementById('em-new').value.trim();
  const okBox = document.getElementById('em-msg-ok'), errBox = document.getElementById('em-msg-err');
  okBox.classList.remove('show'); errBox.classList.remove('show');
  if (!/^\S+@\S+\.\S+$/.test(em)) { errBox.textContent=t('Enter a valid email address.'); errBox.classList.add('show'); return; }
  stState.pendingEmail = em;
  document.getElementById('em-verify-block').style.display='block';
  okBox.textContent = t('Verification code sent to ') + em + '.';
  okBox.classList.add('show');
}
function stVerifyEmailChange() {
  const code = document.getElementById('em-code').value;
  const okBox = document.getElementById('em-msg-ok'), errBox = document.getElementById('em-msg-err');
  errBox.classList.remove('show');
  if (code !== '123456') { errBox.textContent = t('Incorrect verification code.'); errBox.classList.add('show'); return; }
  STUDENT_DATA.account.email = stState.pendingEmail;
  const currentValEl = document.getElementById('em-current-val');
  if (currentValEl) currentValEl.textContent = STUDENT_DATA.account.email;
  okBox.textContent = t('Email address updated successfully.');
  okBox.classList.add('show');
  document.getElementById('em-verify-block').style.display='none';
  document.getElementById('em-new').value='';
  document.getElementById('em-code').value='';
}

function stOpenPasswordRecovery() {
  stOpenModal(`
    <div class="st-modal-title">${t('Password Recovery')}</div>
    <div id="pr-step1">
      <div class="st-modal-sub">${t('Enter your Authren Student ID or email to receive a reset code.')}</div>
      <div class="st-field"><input id="pr-id" placeholder="${t('Student ID (S12345678) or email')}"></div>
      <div id="pr-id-err" style="display:none;color:var(--red);font-size:11.5px;margin-bottom:8px"></div>
      <button class="st-btn" onclick="stRecoveryStep2()">${t('Send Reset Code')}</button>
    </div>
    <div id="pr-step2" style="display:none">
      <div class="st-modal-sub">${t('Enter the code we sent to your email.')}</div>
      <div class="st-field"><input id="pr-code" placeholder="000000" maxlength="6"></div>
      <button class="st-btn" onclick="stRecoveryStep3()">${t('Verify Code')}</button>
    </div>
    <div id="pr-step3" style="display:none">
      <div class="st-modal-sub">${t('Choose a new password.')}</div>
      <div class="st-field"><label>${t('New Password')}</label><input type="password" id="pr-newpw"></div>
      <div class="st-field"><label>${t('Confirm Password')}</label><input type="password" id="pr-confirmpw"></div>
      <button class="st-btn" onclick="stRecoveryStep4()">${t('Reset Password')}</button>
      <div class="st-inline-msg err" id="pr-err"></div>
    </div>
    <div id="pr-step4" style="display:none;text-align:center">
      <div style="font-size:36px;margin-bottom:10px">✅</div>
      <div style="font-weight:700;margin-bottom:6px">${t('Password Reset Successfully')}</div>
      <div style="font-size:12.5px;color:var(--muted)">${t('You can now log in with your new password.')}</div>
      <button class="st-btn" style="margin-top:16px" onclick="stCloseModal()">${t('Done')}</button>
    </div>
  `);
}
function stRecoveryStep2(){
  const val = document.getElementById('pr-id').value.trim();
  const err = document.getElementById('pr-id-err');
  const isEmail = /^\S+@\S+\.\S+$/.test(val);
  const isStudentId = /^S\d{8}$/.test(val);
  if (!isEmail && !isStudentId) {
    err.style.display='block'; err.textContent = t('Enter a valid email address or Student ID (format: S12345678).');
    return;
  }
  err.style.display='none';
  document.getElementById('pr-step1').style.display='none'; document.getElementById('pr-step2').style.display='block';
}
function stRecoveryStep3(){
  const code = document.getElementById('pr-code').value;
  if (code !== '123456') return;
  document.getElementById('pr-step2').style.display='none'; document.getElementById('pr-step3').style.display='block';
}
function stRecoveryStep4(){
  const a = document.getElementById('pr-newpw').value, b = document.getElementById('pr-confirmpw').value;
  const err = document.getElementById('pr-err'); err.classList.remove('show');
  if (a.length<6){ err.textContent=t('Password too short.'); err.classList.add('show'); return; }
  if (a!==b){ err.textContent=t('Passwords do not match.'); err.classList.add('show'); return; }
  document.getElementById('pr-step3').style.display='none'; document.getElementById('pr-step4').style.display='block';
}

/* ═══════════════════════════════
   GENERIC MODAL SYSTEM (student)
═══════════════════════════════ */
function stOpenModal(innerHTML) {
  let overlay = document.getElementById('st-modal-overlay');
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.id = 'st-modal-overlay';
    overlay.className = 'st-modal-overlay';
    overlay.onclick = (e) => { if (e.target === overlay) stCloseModal(); };
    document.body.appendChild(overlay);
  }
  overlay.innerHTML = `<div class="st-modal-box"><div class="st-modal-close" onclick="stCloseModal()">✕</div>${innerHTML}</div>`;
  overlay.classList.add('active');
}
function stCloseModal() {
  const overlay = document.getElementById('st-modal-overlay');
  if (overlay) overlay.classList.remove('active');
}



/* ══════════════════════════════════════════════════════
   TIMETABLE — the student's own class schedule.
   Reads the shared school timetable; the student sees their class's
   slice of it, so it always matches what the school published.
══════════════════════════════════════════════════════ */
function stTimetable() {
  const cls = ttClassByName(STUDENT_DATA.profile && STUDENT_DATA.profile.class);
  if (!cls) {
    return `<div class="card"><div class="card-body"><div class="tt-empty">${t('Your class has not been linked to a timetable yet. Please contact your school.')}</div></div></div>`;
  }
  const entries = ttEntriesForClass(cls.id);
  const subjects = Array.from(new Set(entries.map(e => e.subjectId)));
  return `
    <div class="card"><div class="card-header">
        <div class="card-title">${t('My Timetable')}</div>
        <button type="button" class="st-btn ghost sm" onclick="ttPrint()">🖨️ ${t('Print')}</button>
      </div>
      <div class="card-body">
        <div style="font-size:12px;color:var(--muted);margin-bottom:12px">${ttEsc(cls.name)} · ${ttEsc(TT_META.academicYear)} · ${ttEsc(TT_META.term)}</div>
        ${ttRenderGrid(entries, 'class')}
        <div class="tt-legend">
          ${subjects.map(sid => { const sj = ttSubject(sid); return sj ? `<div class="tt-legend-item"><span class="tt-legend-dot" style="background:${sj.color}"></span>${ttEsc(sj.name)}</div>` : ''; }).join('')}
        </div>
      </div></div>
    ${ttRenderSummary(entries, 'class')}`;
}
