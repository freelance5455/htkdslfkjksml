/* ═══════════════════════════════
   GUARDIAN — IDENTITY & SECURITY
═══════════════════════════════ */
const GUARDIAN_DATA = {
  account: {
    name: 'Mr. Karim Amrani',
    relation: 'Father',
    guardianId: 'G98765432',
    email: 'karim.amrani@gmail.com',
    phone: '+212 661-234 567',
    password: 'Passw0rd1',
    conversations: [], // account-level Communication data — no conversations exist yet.
      // Each conversation may optionally carry a `phone` field (the contact's
      // direct number) which powers the Direct Call action on its detail
      // screen; conversations without one simply show no Call action.
    supportTickets: [] // account-level Support request history — no requests submitted yet
  },
  /* Each linked child is fully self-contained: every child-specific module
     (grades, exams, homework, attendance, analytics, payments, achievements,
     orientation, history) reads only from the active child's own record, so
     switching never leaks one child's data into another child's view. */
  children: [
    {
      id: 'c1', name: 'Youssef Amrani', color: '#3B82F6',
      grade: 'Grade 10 - A', school: 'Al Farabi Private School', studentId: 'S12345678',
      kpis: { overallAvg: 15.8, attendanceRate: 96, homeworkDue: 2, alerts: 1 },
      progressHistory: [
        { period:'Sep', avg:14.2 }, { period:'Oct', avg:14.6 }, { period:'Nov', avg:15.0 },
        { period:'Jan', avg:15.3 }, { period:'Feb', avg:15.6 }, { period:'Mar', avg:15.8 },
      ],
      subjects: [
        { name:'Mathematics', avg:16.2, trend:'up', history:[{period:'Sep',avg:14.8},{period:'Dec',avg:15.5},{period:'Mar',avg:16.2}] },
        { name:'Physics', avg:14.5, trend:'down', history:[{period:'Sep',avg:15.8},{period:'Dec',avg:15.0},{period:'Mar',avg:14.5}] },
        { name:'English', avg:17.0, trend:'flat', history:[{period:'Sep',avg:16.8},{period:'Dec',avg:17.1},{period:'Mar',avg:17.0}] },
        { name:'Arabic', avg:15.0, trend:'up', history:[{period:'Sep',avg:13.5},{period:'Dec',avg:14.2},{period:'Mar',avg:15.0}] },
        { name:'History-Geography', avg:13.8, trend:'down', history:[{period:'Sep',avg:15.0},{period:'Dec',avg:14.3},{period:'Mar',avg:13.8}] },
        { name:'SVT', avg:16.5, trend:'up', history:[{period:'Sep',avg:15.0},{period:'Dec',avg:15.8},{period:'Mar',avg:16.5}] },
      ],
      exams: {
        upcoming: [
          { subject:'SVT', title:'Pop Quiz', date:'11 Mar 2026', datetime:'2026-03-11T14:00:00' },
          { subject:'Mathematics', title:'Chapter 6 Test', date:'18 Mar 2026', datetime:'2026-03-18T09:00:00' },
          { subject:'Physics', title:'Midterm Exam', date:'22 Mar 2026', datetime:'2026-03-22T10:30:00' },
        ],
        completed: [
          { subject:'English', title:'Essay Exam', date:'2 Mar 2026', score:17, max:20 },
          { subject:'Arabic', title:'Grammar Quiz', date:'25 Feb 2026', score:15, max:20 },
        ],
      },
      homework: [
        { subject:'Mathematics', title:'Exercises 12-18', due:'15 Mar 2026', status:'pending' },
        { subject:'SVT', title:'Lab report', due:'16 Mar 2026', status:'pending' },
        { subject:'English', title:'Reading response', due:'10 Mar 2026', status:'done' },
        { subject:'Physics', title:'Problem Set 4', due:'8 Mar 2026', status:'pending' },
        { subject:'Arabic', title:'Vocabulary sheet', due:'5 Mar 2026', status:'done' },
        { subject:'History-Geography', title:'Map exercise', due:'19 Mar 2026', status:'pending' },
      ],
      calendar: [
        { id:'y-e1', date:'2026-02-20', type:'meeting', title:'Parent-Teacher Conferences', time:'14:00', location:'Main Hall', details:'Individual 15-minute slots with the homeroom teacher — sign-up sheet posted on the notice board.' },
        { id:'y-e2', date:'2026-03-02', type:'exam', subject:'English', title:'English Essay Exam', time:'09:00', details:'Covers persuasive essay structure from Units 4-6.' },
        { id:'y-e3', date:'2026-03-11', type:'exam', subject:'SVT', title:'SVT Pop Quiz', time:'14:00', details:'Short quiz covering the digestive system chapter.' },
        { id:'y-e4', date:'2026-03-15', type:'deadline', subject:'Mathematics', title:'Exercises 12-18 Due', details:'Submit worked solutions to the homeroom teacher before end of day.' },
        { id:'y-e5', date:'2026-03-18', type:'exam', subject:'Mathematics', title:'Chapter 6 Test', time:'09:00', details:'Covers quadratic equations and factoring.' },
        { id:'y-e6', date:'2026-03-20', type:'holiday', title:'Spring Break Begins', details:'No classes until 30 March. School reopens Monday 30 March.' },
        { id:'y-e7', date:'2026-03-22', type:'exam', subject:'Physics', title:'Physics Midterm Exam', time:'10:30', details:'Covers mechanics and thermodynamics units.' },
        { id:'y-e8', date:'2026-04-03', type:'activity', title:'Science Fair', time:'10:00', location:'Gymnasium', details:"Youssef's class is presenting projects during the afternoon session." },
      ],
      attendance: { rate:96, present:112, absent:3, late:2, justified:2, unjustified:1,
        totalSchoolDays:117, streak:4, bestStreak:21,
        monthlyRate: [ {period:'Sep',rate:98}, {period:'Oct',rate:97}, {period:'Nov',rate:95}, {period:'Jan',rate:94}, {period:'Feb',rate:93}, {period:'Mar',rate:96} ],
        recent: [ {date:'11 Mar', status:'present'}, {date:'10 Mar', status:'present'}, {date:'9 Mar', status:'late'}, {date:'8 Mar', status:'present'}, {date:'7 Mar', status:'absent'} ],
        records: [
          { date:'2026-03-11', status:'present' },
          { date:'2026-03-10', status:'present' },
          { date:'2026-03-09', status:'late', note:'Arrived 15 minutes late.' },
          { date:'2026-03-08', status:'present' },
          { date:'2026-03-07', status:'absent', justification:{ status:'unjustified' } },
          { date:'2026-03-04', status:'present' },
          { date:'2026-03-03', status:'present' },
          { date:'2026-02-26', status:'absent', justification:{ status:'pending', reason:'Family emergency', details:'Youssef had to travel with the family on short notice.', submittedDate:'2026-02-27', file:{ name:'travel-note.pdf', size:184320 } } },
          { date:'2026-02-18', status:'absent', justification:{ status:'justified', reason:'Illness', details:'Fever and flu symptoms, stayed home on doctor\'s advice.', submittedDate:'2026-02-19', reviewedDate:'2026-02-20', file:{ name:'medical-note.pdf', size:241664 } } },
          { date:'2026-02-05', status:'late', note:'Arrived 8 minutes late.' },
        ] },
      payments: { applicable:true, currency:'MAD',
        outstandingBalance:1200, totalPaidThisYear:9000,
        status:'due', // paid | due | overdue | partial
        nextDueDate:'2026-03-30', lastPaymentDate:'2026-02-05',
        history: [
          { id:'pay3', date:'2026-03-30', desc:'Term 3 Tuition', amount:1200, status:'pending' },
          { id:'pay1', date:'2026-02-05', desc:'Term 2 Tuition', amount:4500, status:'paid', method:'Bank Transfer', receiptId:'RCPT-2026-002' },
          { id:'pay0', date:'2025-11-05', desc:'Term 1 Tuition (auto-debit attempt)', amount:4500, status:'failed', method:'Card ending 4471', note:'Card declined by the bank. Resolved via bank transfer on 10 Nov 2025.' },
          { id:'pay2', date:'2025-11-10', desc:'Term 1 Tuition', amount:4500, status:'paid', method:'Bank Transfer', receiptId:'RCPT-2025-011' },
        ],
        receipts: [
          { id:'RCPT-2026-002', date:'2026-02-05', desc:'Term 2 Tuition', amount:4500, currency:'MAD', method:'Bank Transfer', paymentId:'pay1' },
          { id:'RCPT-2025-011', date:'2025-11-10', desc:'Term 1 Tuition', amount:4500, currency:'MAD', method:'Bank Transfer', paymentId:'pay2' },
        ] },
      achievements: [
        { id:'a1', title:'Perfect Attendance — February', icon:'🏅', date:'1 Mar 2026', category:'Attendance', desc:'Awarded for a full month with no unexcused absences or lates.' },
        { id:'a2', title:'Top 10 — Mathematics', icon:'⭐', date:'20 Feb 2026', category:'Academic', desc:'Ranked among the top 10 students in Mathematics for the term.' },
      ],
      orientation: { applicable:true, track:'Science Track (Baccalaureate)', note:'Based on current performance, Youssef is on track for the Science stream. A counselor meeting is recommended before elective selection in May.' },
      reports: [
        { term:'Term 2 · 2025-2026', date:'1 Mar 2026', summary:'Overall average 15.8/20, ranked 6th in class. Strong performance in English and SVT; Physics needs attention.' },
        { term:'Term 1 · 2025-2026', date:'15 Dec 2025', summary:'Overall average 15.1/20. Consistent attendance and steady improvement across the term.' },
      ],
    },
    {
      id: 'c2', name: 'Sarah Amrani', color: '#F59E0B',
      grade: 'Grade 6 - B', school: 'Al Farabi Private School', studentId: 'S23456789',
      kpis: { overallAvg: 17.4, attendanceRate: 99, homeworkDue: 1, alerts: 0 },
      subjects: [
        { name:'Mathematics', avg:18.0, trend:'up' }, { name:'French', avg:16.5, trend:'flat' },
        { name:'Arabic', avg:17.8, trend:'up' }, { name:'Science', avg:17.0, trend:'up' }, { name:'Art', avg:19.0, trend:'flat' },
      ],
      exams: {
        upcoming: [ { subject:'French', title:'Dictée', date:'19 Mar 2026', datetime:'2026-03-19T09:00:00' } ],
        completed: [
          { subject:'Mathematics', title:'Fractions Test', date:'4 Mar 2026', score:18, max:20 },
          { subject:'Science', title:'Unit Quiz', date:'27 Feb 2026', score:17, max:20 },
        ],
      },
      homework: [
        { subject:'French', title:'Vocabulary list 5', due:'17 Mar 2026', status:'pending' },
        { subject:'Arabic', title:'Reading exercise', due:'12 Mar 2026', status:'done' },
        { subject:'Science', title:'Observation journal', due:'9 Mar 2026', status:'pending' },
      ],
      calendar: [
        { id:'s-e1', date:'2026-02-20', type:'meeting', title:'Parent-Teacher Conferences', time:'15:00', location:'Main Hall', details:'Individual 15-minute slots with the homeroom teacher — sign-up sheet posted on the notice board.' },
        { id:'s-e2', date:'2026-03-04', type:'exam', subject:'Mathematics', title:'Fractions Test', time:'09:00', details:'Covers adding, subtracting and comparing fractions.' },
        { id:'s-e3', date:'2026-03-12', type:'deadline', subject:'French', title:'Vocabulary List 5 Due', details:'Hand in the completed vocabulary sheet to the French teacher.' },
        { id:'s-e4', date:'2026-03-19', type:'exam', subject:'French', title:'French Dictée', time:'09:00', details:'Dictation covering this term\'s spelling list.' },
        { id:'s-e5', date:'2026-03-20', type:'holiday', title:'Spring Break Begins', details:'No classes until 30 March. School reopens Monday 30 March.' },
        { id:'s-e6', date:'2026-04-10', type:'activity', title:'Spring Art Showcase', time:'11:00', location:'Art Wing', details:"Sarah's class artwork will be on display for families to visit." },
      ],
      attendance: { rate:99, present:118, absent:1, late:0, justified:1, unjustified:0,
        totalSchoolDays:119, streak:31, bestStreak:31,
        recent: [ {date:'11 Mar', status:'present'}, {date:'10 Mar', status:'present'}, {date:'9 Mar', status:'present'}, {date:'8 Mar', status:'present'}, {date:'7 Mar', status:'present'} ],
        records: [
          { date:'2026-03-11', status:'present' },
          { date:'2026-03-10', status:'present' },
          { date:'2026-03-09', status:'present' },
          { date:'2026-03-08', status:'present' },
          { date:'2026-03-07', status:'present' },
          { date:'2026-01-15', status:'absent', justification:{ status:'justified', reason:'Medical / Dental Appointment', details:'Routine dental check-up scheduled by the family pediatric dentist.', submittedDate:'2026-01-15', reviewedDate:'2026-01-16', file:{ name:'dentist-appointment.pdf', size:98304 } } },
        ] },
      payments: { applicable:false },
      achievements: [
        { id:'a3', title:'Top 10 — Overall Average', icon:'🏆', date:'5 Mar 2026', category:'Academic', desc:'Ranked among the top 10 students in the class for overall average.' },
        { id:'a4', title:'Reading Streak — 30 Days', icon:'📚', date:'22 Feb 2026', category:'Engagement', desc:'Completed 30 consecutive days of the school reading program.' },
      ],
      orientation: { applicable:false, track:'Not applicable yet', note:'Orientation guidance becomes available starting in middle school as subject options open up.' },
      reports: [
        { term:'Term 2 · 2025-2026', date:'1 Mar 2026', summary:'Overall average 17.4/20, ranked 2nd in class. Excellent attendance and consistent effort across all subjects.' },
      ],
    },
  ],
};

const gdState = {
  tab: { account: 'profile', grades: 'subjects', exams: 'upcoming', attendance: 'overview', homework: 'overview', calendar: 'month', threeSixty: 'overview', family: 'overview' },
  currentView: 'home',
  family: { activeChildId: null, loading: true, switcherOpen: false, initialized: false, historyFilter: 'all' },
  phone: { editing:false, saving:false, error:'', success:false, draft:'' },
  password: { saving:false },
  email: { step:'idle', newEmail:'', deliveredTo:'', sending:false, verifying:false, attempts:0, error:'', cooldown:0, expiry:0, _interval:null },
  recovery: { step:1, identifier:'', deliveredTo:'', sending:false, verifying:false, attempts:0, error:'', cooldown:0, expiry:0, resetting:false, _interval:null },
  attendance: {
    calMonth: 2, calYear: 2026, // March 2026 (0-indexed month)
    calSelected: null,
    justify: { open:false, recordDate:null, reason:'', details:'', submitting:false, error:'',
      file: { state:'idle', name:'', size:0, error:'', progress:0 } }
  },
  calendar: {
    calMonth: 2, calYear: 2026, // March 2026 (0-indexed month)
    calSelected: null,
    loadState: 'idle' // idle | loading | error | ready
  },
  comms: {
    // UI-only state for the Communication module. Conversation and support
    // ticket data itself lives in GUARDIAN_DATA.account, not here.
    loadState: 'idle', // idle | loading | error | ready (shared by Conversations + History, same data source)
    screen: 'list', // list | detail
    activeConversationId: null, // id of the selected/open conversation, if any
    activeTab: 'conversations', // conversations | history | support
    convSearch: '',
    convFilter: 'all', // all | unread | open | awaiting
    historySearch: '',
    support: {
      view: 'list', // list | form | submitting | error | success
      category: '',
      description: '',
      errors: {}, // {category?, description?}
      lastSubmitError: ''
    }
  },
  pay: {
    loadState: 'idle', // idle | loading | error | ready — simulated fetch, gated by payments.applicable
    screen: 'overview', // overview | receipt
    activeReceiptId: null
  },
  perf: {
    screen: 'list', // list | subject
    activeSubject: null
  },
  ach: {
    screen: 'list', // list | detail
    activeId: null
  }
};

function gdInitials(name) {
  return name.replace(/^(Mr\.|Mrs\.|Ms\.|Dr\.)\s*/,'').split(' ').filter(Boolean).slice(0,2).map(w=>w[0]).join('').toUpperCase();
}

/* ═══════════════════════════════
   GUARDIAN — MULTI-CHILD FAMILY & CHILD SWITCHER
   Family-account state (who's logged in, which children are linked) lives
   in gdState.family, fully separate from any one child's record — this is
   what will let a future Family Command Center aggregate every child later.
═══════════════════════════════ */
function gdChildren() { return GUARDIAN_DATA.children; }
function gdGetActiveChild() { return gdChildren().find(c => c.id === gdState.family.activeChildId) || null; }

function gdInitFamily() {
  gdState.family.loading = true;
  gdState.family.switcherOpen = false;
  gdMountSwitcher();
  setTimeout(() => {
    gdState.family.loading = false;
    gdState.family.initialized = true;
    if (!gdState.family.activeChildId && gdChildren().length) gdState.family.activeChildId = gdChildren()[0].id;
    gdMountSwitcher();
    if (currentRole === 'guardian') renderView('guardian', gdState.currentView || 'home');
  }, 700);
}
function gdResetFamily() {
  gdState.family.loading = true;
  gdState.family.switcherOpen = false;
  gdState.family.initialized = false;
  gdState.family.activeChildId = null;
}

/* Guard clause every child-scoped view starts with, so loading / empty /
   not-yet-selected states are handled consistently in one place. */
function gdChildGuardClause() {
  if (gdState.family.loading) return gdLoadingCard();
  if (!gdChildren().length) return gdEmptyChildrenState();
  if (!gdGetActiveChild()) return gdLoadingCard();
  return null;
}
function gdLoadingCard() {
  return `<div class="card"><div class="card-body" style="text-align:center;padding:50px 20px;color:var(--muted)">
    <span class="gd-spinner"></span>${t('Loading child records…')}
  </div></div>`;
}
function gdEmptyChildrenState() {
  return `<div class="gd-empty-state">
    <div class="gd-empty-state-ico"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg></div>
    <div class="gd-empty-state-title">${t('No children linked yet')}</div>
    <div class="gd-empty-state-sub">${t('Once your school links a student to your Guardian ID, they will appear here and you can start viewing their grades, attendance, homework and more.')}</div>
    <button class="st-btn ghost" onclick="switchView('messages', document.querySelector('.nav-item'))">${t('Contact your school')}</button>
  </div>`;
}

/* ── Child switcher (topbar) ── */
function gdSwitcherAvatar(c, size) {
  size = size || 32;
  return `<div class="gd-switcher-avatar" style="width:${size}px;height:${size}px;background:${c.color}">${gdInitials(c.name)}</div>`;
}
function gdMountSwitcher() {
  const slot = document.getElementById('gd-switcher-slot');
  if (!slot) return;

  if (gdState.family.loading) {
    slot.innerHTML = `<div class="gd-switcher-skeleton"><div class="gd-skel-circle"></div><div class="gd-skel-line"></div></div>`;
    return;
  }
  const kids = gdChildren();
  if (!kids.length) {
    slot.innerHTML = `<div class="gd-switcher-wrap"><div class="gd-switcher-btn gd-switcher-single"><div class="gd-switcher-avatar" style="background:var(--surface3)">–</div><div class="gd-switcher-info"><div class="gd-switcher-name">${t('No linked children')}</div></div></div></div>`;
    return;
  }
  const active = gdGetActiveChild();
  if (kids.length === 1) {
    slot.innerHTML = `<div class="gd-switcher-wrap"><div class="gd-switcher-btn gd-switcher-single" title="${t('Only one child linked to this account')}">
      ${gdSwitcherAvatar(active)}
      <div class="gd-switcher-info"><div class="gd-switcher-name">${active.name}</div><div class="gd-switcher-sub">${t(active.grade)}</div></div>
    </div></div>`;
    return;
  }
  slot.innerHTML = `<div class="gd-switcher-wrap" id="gd-switcher-wrap">
    <button type="button" class="gd-switcher-btn${gdState.family.switcherOpen?' open':''}" id="gd-switcher-btn" onclick="gdToggleSwitcher(event)" aria-haspopup="true" aria-expanded="${gdState.family.switcherOpen}">
      ${gdSwitcherAvatar(active)}
      <div class="gd-switcher-info"><div class="gd-switcher-name">${active.name}</div><div class="gd-switcher-sub">${t(active.grade)}</div></div>
      <svg class="gd-switcher-caret" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 9 12 15 18 9"/></svg>
    </button>
    <div class="gd-switcher-panel${gdState.family.switcherOpen?' open':''}" id="gd-switcher-panel">
      <div class="gd-switcher-panel-header">${t('Your Children')}</div>
      <div class="gd-switcher-panel-list">
        ${kids.map(c => `<div class="gd-switcher-row${c.id===active.id?' active':''}" onclick="gdSelectChild('${c.id}', event)">
          ${gdSwitcherAvatar(c, 34)}
          <div><div class="gd-switcher-row-name">${c.name}</div><div class="gd-switcher-row-sub">${t(c.grade)}</div></div>
          ${c.id===active.id
            ? `<div class="gd-switcher-row-check"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg></div>`
            : (c.kpis.alerts > 0 ? `<div class="gd-switcher-row-alert">${c.kpis.alerts}</div>` : '')}
        </div>`).join('')}
      </div>
      <div class="gd-switcher-panel-footer">${t('Managing records for')} ${kids.length} ${kids.length===1?t('child'):t('children')}</div>
    </div>
  </div>`;
}
function gdToggleSwitcher(e) {
  if (e) e.stopPropagation();
  gdState.family.switcherOpen = !gdState.family.switcherOpen;
  gdMountSwitcher();
}
function gdSelectChild(id, e) {
  if (e) e.stopPropagation();
  gdState.family.switcherOpen = false;
  if (id === gdState.family.activeChildId) { gdMountSwitcher(); return; }
  gdState.family.activeChildId = id;
  gdMountSwitcher();
  renderView('guardian', gdState.currentView || 'home');
  const c = gdGetActiveChild();
  if (c) gdShowToast(t('Now viewing') + ' ' + c.name);
}
document.addEventListener('click', function(e) {
  const panel = document.getElementById('gd-switcher-panel');
  const btn = document.getElementById('gd-switcher-btn');
  if (panel && panel.classList.contains('open') && !panel.contains(e.target) && (!btn || !btn.contains(e.target))) {
    gdState.family.switcherOpen = false;
    gdMountSwitcher();
  }
});
function gdShowToast(msg) {
  let toast = document.getElementById('gd-toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'gd-toast';
    toast.className = 'gd-toast';
    document.body.appendChild(toast);
  }
  toast.innerHTML = `<span class="gd-toast-check"><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg></span>${msg}`;
  toast.classList.add('show');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => toast.classList.remove('show'), 1800);
}

/* ── Shared "which child" banner shown atop every child-scoped module ── */
function gdChildBanner(c) {
  return `<div class="gd-child-banner">
    ${gdSwitcherAvatar(c, 48).replace('gd-switcher-avatar','gd-child-banner-avatar')}
    <div style="flex:1;min-width:0">
      <div class="gd-child-banner-name">${c.name}</div>
      <div class="gd-child-banner-sub">${t(c.grade)} · ${c.studentId} · ${t(c.school)}</div>
    </div>
    ${gdChildren().length > 1 ? `<button type="button" class="st-btn ghost sm" onclick="gdToggleSwitcher(event)">${t('Switch Child')}</button>` : ''}
  </div>`;
}

/* ── Router: dispatches to the right module for the active child ── */
function guardianView(v) {
  gdState.currentView = v;
  if (v === 'timetable') return gdTimetable();
  if (v === 'account') return gdAccount();
  if (v === 'messages') return gdMessagesView();
  if (v === 'family') return gdFamilyOverview();

  const guard = gdChildGuardClause();
  if (guard) return guard;
  const c = gdGetActiveChild();

  switch (v) {
    case 'home':         return gdChildBanner(c) + gdHome(c);
    case 'calendar':      return gdChildBanner(c) + gdCalendarView(c);
    case 'grades':        return gdChildBanner(c) + gdGrades(c);
    case 'homework':      return gdChildBanner(c) + gdHomeworkView(c);
    case 'attendance':    return gdChildBanner(c) + gdAttendanceView(c);
    case 'analytics':     return gdChildBanner(c) + gdAnalyticsView(c);
    case 'payments':      return gdChildBanner(c) + gdPaymentsView(c);
    case 'achievements':  gdState.tab.threeSixty = 'achievements'; return gdChildBanner(c) + gdAnalyticsView(c);
    case 'orientation':   gdState.tab.threeSixty = 'orientation'; return gdChildBanner(c) + gdAnalyticsView(c);
    case 'history':       return gdChildBanner(c) + gdHistoryView(c);
    default: return `<div class="card"><div class="card-body" style="color:var(--muted);text-align:center;padding:40px">${t('This section is coming soon.')}</div></div>`;
  }
}

/* ── Home ── */
/* ── Family Command Center ──
   Account-level (all linked children), deliberately separate from any
   single child's dashboard/Child 360. Built as tabs within one nav entry
   (Overview/Academics/Attendance so far) rather than a nav item per
   metric. Cross-links into a child's own dashboard always set the active
   child first, so context is preserved rather than landing on the wrong
   child. Comparison views list children in a stable order — never sorted
   by score — since the goal is understanding each child, not ranking. */
function gdFamilyGoToChild(childId, viewId, threeSixtyTab) {
  gdState.family.activeChildId = childId;
  gdMountSwitcher();
  if (threeSixtyTab) gdState.tab.threeSixty = threeSixtyTab;
  switchView(viewId, document.querySelector('.nav-item'));
}
function gdFamilyOverview() {
  const kids = gdChildren();
  if (!kids.length) return gdEmptyChildrenState();
  const tabs = [
    { id:'overview',      label:'Overview' },
    { id:'academics',     label:'Academics' },
    { id:'attendance',    label:'Attendance' },
    { id:'payments',      label:'Payments' },
    { id:'communication', label:'Communication' },
    { id:'history',       label:'History' },
    { id:'orientation',   label:'Orientation' },
    { id:'reports',       label:'Reports' },
  ];
  return `<div class="st-tabs">${tabs.map(tb => `<div class="st-tab gd-tab-fam${tb.id===gdState.tab.family?' active':''}" data-tab="${tb.id}" onclick="gdSetFamilyTab('${tb.id}')">${t(tb.label)}</div>`).join('')}</div>
    <div id="gd-body-family">${gdFamilyBody(gdState.tab.family)}</div>`;
}
function gdSetFamilyTab(tabId) {
  gdState.tab.family = tabId;
  document.querySelectorAll('.gd-tab-fam').forEach(el => el.classList.toggle('active', el.dataset.tab === tabId));
  const body = document.getElementById('gd-body-family');
  if (body) body.innerHTML = gdFamilyBody(tabId);
}
function gdFamilyBody(tab) {
  if (tab === 'academics')     return gdFamilyAcademicsTab();
  if (tab === 'attendance')    return gdFamilyAttendanceTab();
  if (tab === 'payments')      return gdFamilyPaymentsTab();
  if (tab === 'communication') return gdFamilyCommunicationTab();
  if (tab === 'history')       return gdFamilyHistoryTab();
  if (tab === 'orientation')   return gdFamilyOrientationTab();
  if (tab === 'reports')       return gdFamilyReportsTab();
  return gdFamilyOverviewTab();
}
function gdFamilyAvg(arr) {
  if (!arr.length) return null;
  return Math.round((arr.reduce((s, v) => s + v, 0) / arr.length) * 10) / 10;
}
function gdFamilyOverviewTab() {
  const kids = gdChildren();
  const avgAvg = gdFamilyAvg(kids.map(c => c.kpis.overallAvg));
  const avgAtt = gdFamilyAvg(kids.map(c => c.kpis.attendanceRate));
  const totalAlerts = kids.reduce((s, c) => s + (c.kpis.alerts || 0), 0);
  return `
    <div class="gd-stat-row">
      <div class="stat-card"><div class="stat-label">${t('Children Linked')}</div><div class="stat-val">${kids.length}</div><div class="stat-icon blue">👨‍👩‍👧‍👦</div></div>
      <div class="stat-card"><div class="stat-label">${t('Family Average')}</div><div class="stat-val">${avgAvg !== null ? avgAvg + '/20' : '—'}</div><div class="stat-icon green">📊</div></div>
      <div class="stat-card"><div class="stat-label">${t('Avg. Attendance')}</div><div class="stat-val">${avgAtt !== null ? avgAtt + '%' : '—'}</div><div class="stat-icon yellow">✅</div></div>
      <div class="stat-card"><div class="stat-label">${t('Open Alerts')}</div><div class="stat-val">${totalAlerts}</div><div class="stat-icon ${totalAlerts>0?'red':'green'}">🔔</div></div>
    </div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Your Children')}</div></div>
      <div class="card-body">
        ${kids.map(c => `<div class="info-row" style="cursor:pointer;align-items:center" role="button" tabindex="0" onclick="gdFamilyGoToChild('${c.id}','home')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();gdFamilyGoToChild('${c.id}','home')}">
          <span style="display:flex;align-items:center;gap:10px">${gdSwitcherAvatar(c, 34)}<span><div style="font-weight:600">${gdCommsEsc(c.name)}</div><div style="font-size:11.5px;color:var(--muted)">${t(c.grade)}</div></span></span>
          <span style="text-align:right;font-size:12.5px;color:var(--muted)">${c.kpis.overallAvg}/20 · ${c.kpis.attendanceRate}%${c.kpis.alerts ? ` · <span style="color:var(--red)">${c.kpis.alerts} ${t(c.kpis.alerts===1?'alert':'alerts')}</span>` : ''}</span>
        </div>`).join('')}
      </div></div>`;
}
function gdFamilyAcademicsTab() {
  const kids = gdChildren();
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Academic Overview')}</div><span style="font-size:12px;color:var(--muted)">${t('Tap a child for full details')}</span></div>
    <div class="card-body">
      ${kids.map(c => {
        const top = (c.subjects || []).slice().sort((a, b) => b.avg - a.avg)[0];
        return `<div class="info-row" style="cursor:pointer;align-items:center" role="button" tabindex="0" onclick="gdFamilyGoToChild('${c.id}','analytics','performance')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();gdFamilyGoToChild('${c.id}','analytics','performance')}">
          <span style="display:flex;align-items:center;gap:10px">${gdSwitcherAvatar(c, 34)}<span style="font-weight:600">${gdCommsEsc(c.name)}</span></span>
          <span style="text-align:right;font-size:12.5px;color:var(--muted)">${t('Average')}: <b style="color:#fff">${c.kpis.overallAvg}/20</b>${top ? ` · ${t('Strongest')}: ${gdCommsEsc(t(top.name))}` : ''}</span>
        </div>`;
      }).join('') || `<div class="gd-empty-mini">${t('No children linked yet.')}</div>`}
    </div></div>`;
}
function gdFamilyAttendanceTab() {
  const kids = gdChildren();
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Attendance Overview')}</div><span style="font-size:12px;color:var(--muted)">${t('Tap a child for full details')}</span></div>
    <div class="card-body">
      ${kids.map(c => {
        const a = c.attendance || {};
        return `<div class="info-row" style="cursor:pointer;align-items:center" role="button" tabindex="0" onclick="gdFamilyGoToChild('${c.id}','analytics','attendance')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();gdFamilyGoToChild('${c.id}','analytics','attendance')}">
          <span style="display:flex;align-items:center;gap:10px">${gdSwitcherAvatar(c, 34)}<span style="font-weight:600">${gdCommsEsc(c.name)}</span></span>
          <span style="text-align:right;font-size:12.5px;color:var(--muted)">${a.rate != null ? a.rate + '%' : '—'} · 🔥 ${a.streak || 0} ${t((a.streak||0) === 1 ? 'day' : 'days')}</span>
        </div>`;
      }).join('') || `<div class="gd-empty-mini">${t('No children linked yet.')}</div>`}
    </div></div>`;
}

/* Aggregates real per-child payment data (sum of outstanding/paid across
   children where payments are applicable) while keeping every child's own
   figures individually visible and linkable — never blended into a single
   unidentifiable number. */
function gdFamilyPaymentsTab() {
  const kids = gdChildren();
  const applicable = kids.filter(c => c.payments && c.payments.applicable);
  if (!applicable.length) {
    return `<div class="gd-empty-mini">${t('No payment information is applicable for any linked child.')}</div>`;
  }
  const currency = applicable[0].payments.currency || '';
  const totalOutstanding = applicable.reduce((s, c) => s + (c.payments.outstandingBalance || 0), 0);
  const totalPaid = applicable.reduce((s, c) => s + (c.payments.totalPaidThisYear || 0), 0);
  return `
    <div class="gd-pay-stat-row">
      <div class="stat-card"><div class="stat-label">${t('Family Outstanding')}</div><div class="stat-val">${totalOutstanding} ${currency}</div><div class="stat-icon ${totalOutstanding>0?'yellow':'green'}">💰</div></div>
      <div class="stat-card"><div class="stat-label">${t('Family Paid This Year')}</div><div class="stat-val">${totalPaid} ${currency}</div><div class="stat-icon green">✅</div></div>
      <div class="stat-card"><div class="stat-label">${t('Children Billed')}</div><div class="stat-val">${applicable.length}</div><div class="stat-icon blue">👨‍👩‍👧‍👦</div></div>
    </div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('By Child')}</div><span style="font-size:12px;color:var(--muted)">${t('Tap a child for receipts & history')}</span></div>
      <div class="card-body">
        ${kids.map(c => {
          if (!c.payments || !c.payments.applicable) {
            return `<div class="info-row" style="align-items:center;opacity:0.6">
              <span style="display:flex;align-items:center;gap:10px">${gdSwitcherAvatar(c, 34)}<span style="font-weight:600">${gdCommsEsc(c.name)}</span></span>
              <span style="font-size:12.5px;color:var(--muted)">${t('Not applicable')}</span>
            </div>`;
          }
          const p = c.payments;
          return `<div class="info-row" style="cursor:pointer;align-items:center" role="button" tabindex="0" onclick="gdFamilyGoToChild('${c.id}','payments')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();gdFamilyGoToChild('${c.id}','payments')}">
            <span style="display:flex;align-items:center;gap:10px">${gdSwitcherAvatar(c, 34)}<span style="font-weight:600">${gdCommsEsc(c.name)}</span></span>
            <span style="text-align:right;display:flex;align-items:center;gap:10px"><span style="font-size:12.5px;color:var(--muted)">${p.outstandingBalance} ${p.currency}</span><span class="status-pill ${p.status}">${gdPayStatusLabel(p.status)}</span></span>
          </div>`;
        }).join('')}
      </div></div>`;
}

/* Communication in this app is account-wide, not per-child (a school
   message can concern any child) — so this is a real summary of the one
   existing Communication Center, deep-linking into it, rather than a
   second/duplicate conversation system. */
function gdFamilyCommunicationTab() {
  const all = gdGetConversations();
  const unread = all.filter(cv => cv.unread).length;
  const recent = all.slice(0, 5);
  return `
    <div class="gd-stat-row">
      <div class="stat-card"><div class="stat-label">${t('Total Conversations')}</div><div class="stat-val">${all.length}</div><div class="stat-icon blue">💬</div></div>
      <div class="stat-card"><div class="stat-label">${t('Unread')}</div><div class="stat-val">${unread}</div><div class="stat-icon ${unread>0?'yellow':'green'}">✉️</div></div>
    </div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Recent Conversations')}</div><div class="card-action" onclick="switchView('messages', document.querySelector('.nav-item'))">${t('Open Communication')} →</div></div>
      <div class="card-body" style="padding:0">
        ${recent.length
          ? `<div class="gd-conv-list">${recent.map(cv => gdConversationItemRow(cv)).join('').replace(/gdSelectConversation\(/g, 'gdFamilyOpenConversation(')}</div>`
          : `<div class="gd-empty-mini">${t('No conversations yet.')}</div>`}
      </div></div>`;
}
function gdFamilyOpenConversation(id) {
  switchView('messages', document.querySelector('.nav-item'));
  gdSelectConversation(id);
}

/* Merges every child's real report entries into one chronological,
   filterable timeline — each entry stays clearly tagged with its child
   and links back into that child's own History page for full context. */
function gdFamilyHistoryEntries() {
  const kids = gdChildren();
  const merged = [];
  kids.forEach(c => (c.reports || []).forEach(r => merged.push(Object.assign({}, r, { childId: c.id, childName: c.name, childColor: c.color }))));
  return merged.sort((a, b) => new Date(b.date) - new Date(a.date));
}
function gdFamilySetHistoryFilter(childId) {
  gdState.family.historyFilter = childId;
  const el = document.getElementById('gd-body-family');
  if (el) el.innerHTML = gdFamilyHistoryTab();
}
function gdFamilyHistoryTab() {
  const kids = gdChildren();
  const entries = gdFamilyHistoryEntries();
  const filter = gdState.family.historyFilter;
  const filtered = filter === 'all' ? entries : entries.filter(e => e.childId === filter);
  const filterRow = kids.length > 1 ? `<div class="gd-comm-filter-row" style="margin-bottom:14px">
    <div class="gd-comm-filter-chip${filter==='all'?' active':''}" onclick="gdFamilySetHistoryFilter('all')">${t('All')}</div>
    ${kids.map(c => `<div class="gd-comm-filter-chip${filter===c.id?' active':''}" onclick="gdFamilySetHistoryFilter('${c.id}')">${gdCommsEsc(c.name)}</div>`).join('')}
  </div>` : '';
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Family History')}</div></div>
    <div class="card-body">
      ${filterRow}
      ${filtered.length ? filtered.map(e => `<div class="info-row" style="cursor:pointer;align-items:flex-start;flex-direction:column;gap:4px" role="button" tabindex="0" onclick="gdFamilyGoToChild('${e.childId}','history')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();gdFamilyGoToChild('${e.childId}','history')}">
        <div style="display:flex;justify-content:space-between;width:100%;align-items:center">
          <span style="display:flex;align-items:center;gap:8px"><span style="width:8px;height:8px;border-radius:50%;background:${e.childColor};flex-shrink:0"></span><span style="font-weight:700;color:#fff">${gdCommsEsc(e.childName)} — ${t(e.term)}</span></span>
          <span style="color:var(--muted);font-size:11.5px">${e.date}</span>
        </div>
        <div style="font-size:12.5px;color:var(--muted2);line-height:1.5">${gdCommsEsc(t(e.summary))}</div>
      </div>`).join('') : `<div class="gd-empty-mini">${t(entries.length ? 'No history entries for this child.' : 'No historical reports yet.')}</div>`}
    </div></div>`;
}


/* Orientation guidance is inherently personal (built from each child's own
   subjects/track) so it is never merged or averaged across children —
   this is a per-child summary list only, linking into each child's own
   full Orientation tab (Child 360) with context preserved. */
function gdFamilyOrientationTab() {
  const kids = gdChildren();
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Orientation Overview')}</div><span style="font-size:12px;color:var(--muted)">${t('Tap a child for full guidance')}</span></div>
    <div class="card-body">
      ${kids.map(c => {
        const o = c.orientation || {};
        return `<div class="info-row" style="cursor:pointer;align-items:center" role="button" tabindex="0" onclick="gdFamilyGoToChild('${c.id}','analytics','orientation')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();gdFamilyGoToChild('${c.id}','analytics','orientation')}">
          <span style="display:flex;align-items:center;gap:10px">${gdSwitcherAvatar(c, 34)}<span style="font-weight:600">${gdCommsEsc(c.name)}</span></span>
          <span style="text-align:right;font-size:12.5px;color:var(--muted)">${o.applicable ? gdCommsEsc(t(o.track)) : t('Not applicable yet')}</span>
        </div>`;
      }).join('') || `<div class="gd-empty-mini">${t('No children linked yet.')}</div>`}
    </div></div>`;
}

/* A real navigational hub into reports that already exist elsewhere
   (per-child History, Payments, Attendance) rather than a second/duplicate
   reports system — each button is a genuine, working cross-link. */
function gdFamilyReportsTab() {
  const kids = gdChildren();
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Report Center')}</div></div>
    <div class="card-body">
      ${kids.map((c, i) => {
        const latest = (c.reports || [])[0];
        return `<div class="gd-fam-report-row" style="padding:14px 0${i < kids.length - 1 ? ';border-bottom:0.5px solid var(--separator)' : ''}">
          <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">${gdSwitcherAvatar(c, 32)}<span style="font-weight:700;color:#fff">${gdCommsEsc(c.name)}</span></div>
          ${latest ? `<div style="font-size:12.5px;color:var(--muted2);margin-bottom:10px;line-height:1.5"><b style="color:#fff">${t(latest.term)}</b> (${latest.date}) — ${gdCommsEsc(t(latest.summary))}</div>` : `<div class="gd-empty-mini" style="padding:0 0 10px;text-align:left">${t('No reports yet for this child.')}</div>`}
          <div style="display:flex;gap:8px;flex-wrap:wrap">
            <button class="st-btn ghost sm" onclick="gdFamilyGoToChild('${c.id}','history')">${t('Full Academic History')}</button>
            ${c.payments && c.payments.applicable ? `<button class="st-btn ghost sm" onclick="gdFamilyGoToChild('${c.id}','payments')">${t('Payment History')}</button>` : ''}
            <button class="st-btn ghost sm" onclick="gdFamilyGoToChild('${c.id}','attendance')">${t('Attendance Record')}</button>
          </div>
        </div>`;
      }).join('') || `<div class="gd-empty-mini">${t('No children linked yet.')}</div>`}
    </div></div>`;
}

function gdHome(c) {
  const trendArrow = tr => tr==='up' ? '▲' : tr==='down' ? '▼' : '—';
  const trendColor = tr => tr==='up' ? 'var(--green)' : tr==='down' ? 'var(--red)' : 'var(--muted)';
  return `
    <div class="gd-stat-row">
      <div class="stat-card"><div class="stat-label">${t('Overall Average')}</div><div class="stat-val">${c.kpis.overallAvg}/20</div><div class="stat-icon blue">📊</div></div>
      <div class="stat-card"><div class="stat-label">${t('Attendance Rate')}</div><div class="stat-val">${c.kpis.attendanceRate}%</div><div class="stat-icon green">✅</div></div>
      <div class="stat-card"><div class="stat-label">${t('Homework Due')}</div><div class="stat-val">${c.kpis.homeworkDue}</div><div class="stat-icon yellow">📝</div></div>
      <div class="stat-card"><div class="stat-label">${t('Unread Alerts')}</div><div class="stat-val">${c.kpis.alerts}</div><div class="stat-icon red">🔔</div></div>
    </div>
    <div class="st-grid-2">
      <div class="card"><div class="card-header"><div class="card-title">${t('Recent Grades')}</div><div class="card-action" onclick="switchView('grades', document.querySelector('.nav-item'))">${t('See all')} →</div></div>
        <div class="card-body">
          ${c.exams.completed.slice(0,3).map(e => `<div class="info-row"><span>${t(e.subject)} — ${t(e.title)}</span><span>${e.score}/${e.max}</span></div>`).join('') || `<div style="color:var(--muted);font-size:12.5px">${t('No graded exams yet.')}</div>`}
        </div></div>
      <div class="card"><div class="card-header"><div class="card-title">${t('Upcoming Exams')}</div></div>
        <div class="card-body">
          ${c.exams.upcoming.slice(0,3).map(e => `<div class="info-row"><span>${t(e.subject)} — ${t(e.title)}</span><span>${e.date}</span></div>`).join('') || `<div style="color:var(--muted);font-size:12.5px">${t('No upcoming exams scheduled.')}</div>`}
        </div></div>
    </div>
    <div class="st-grid-2" style="margin-top:16px">
      <div class="card"><div class="card-header"><div class="card-title">${t("Today's Homework")}</div><div class="card-action" onclick="switchView('homework', document.querySelector('.nav-item'))">${t('See all')} →</div></div>
        <div class="card-body">
          ${c.homework.filter(h=>h.status==='pending').slice(0,3).map(h => `<div class="info-row"><span>${t(h.subject)} — ${t(h.title)}</span><span>${t('Due')} ${h.due}</span></div>`).join('') || `<div style="color:var(--muted);font-size:12.5px">${t('No pending homework — all caught up.')}</div>`}
        </div></div>
      <div class="card"><div class="card-header"><div class="card-title">${t('Recent Attendance')}</div><div class="card-action" onclick="switchView('attendance', document.querySelector('.nav-item'))">${t('See all')} →</div></div>
        <div class="card-body">
          ${c.attendance.recent.map(a => `<div class="info-row"><span>${a.date}</span><span class="status-pill ${a.status}">${t(a.status)}</span></div>`).join('')}
        </div></div>
    </div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Subject Snapshot')}</div><div class="card-action" onclick="switchView('analytics', document.querySelector('.nav-item'))">${t('View Child 360')} →</div></div>
      <div class="card-body">
        ${c.subjects.map(s => `<div class="info-row"><span>${t(s.name)}</span><span style="color:${trendColor(s.trend)}">${s.avg}/20 ${trendArrow(s.trend)}</span></div>`).join('')}
      </div></div>`;
}

/* ── Grades & Exams ── */
function gdGrades(c) {
  const tabs = [ {id:'subjects', label:'Subjects'}, {id:'exams', label:'Exams'} ];
  return `<div class="st-tabs">${tabs.map(tb=>`<div class="st-tab gd-tab-grades${tb.id===gdState.tab.grades?' active':''}" data-tab="${tb.id}" onclick="gdSetGradesTab('${tb.id}')">${t(tb.label)}</div>`).join('')}</div>
    <div id="gd-body-grades">${gdGradesBody(c, gdState.tab.grades)}</div>`;
}
function gdSetGradesTab(tabId) {
  gdState.tab.grades = tabId;
  document.querySelectorAll('.gd-tab-grades').forEach(el => el.classList.toggle('active', el.dataset.tab === tabId));
  const c = gdGetActiveChild(); if (!c) return;
  const body = document.getElementById('gd-body-grades');
  if (body) body.innerHTML = gdGradesBody(c, tabId);
}
function gdGradesBody(c, tab) {
  const trendArrow = tr => tr==='up' ? '▲' : tr==='down' ? '▼' : '—';
  const trendColor = tr => tr==='up' ? 'var(--green)' : tr==='down' ? 'var(--red)' : 'var(--muted)';
  if (tab === 'subjects') return `<div class="card"><div class="card-header"><div class="card-title">${t('Subject Averages')}</div></div>
    <div class="card-body">
      ${c.subjects.map(s => `<div class="info-row"><span>${t(s.name)}</span><span style="color:${trendColor(s.trend)}">${s.avg}/20 ${trendArrow(s.trend)}</span></div>`).join('')}
    </div></div>`;
  return `${gdExamCountdownSection(c)}
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Upcoming Exams')}</div></div>
      <div class="card-body">
        ${c.exams.upcoming.map(e => `<div class="info-row"><span>${t(e.subject)} — ${t(e.title)}</span><span>${e.date}</span></div>`).join('') || `<div style="color:var(--muted);font-size:12.5px">${t('No upcoming exams scheduled.')}</div>`}
      </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Completed Exams')}</div></div>
      <div class="card-body">
        ${c.exams.completed.map(e => `<div class="info-row"><span>${t(e.subject)} — ${t(e.title)} · ${e.date}</span><span>${e.score}/${e.max}</span></div>`).join('') || `<div style="color:var(--muted);font-size:12.5px">${t('No completed exams yet.')}</div>`}
      </div></div>`;
}

/* ── Exam Countdown ──
   Anchored to a fixed demo instant (not the real device clock, since the demo
   data lives in March 2026) but ticks forward in real time from page load, so
   the countdown genuinely lives-updates while staying consistent with the
   rest of the guardian module's fixed "today". */
const GD_DEMO_NOW_EPOCH = new Date(2026, 2, 11, 8, 30, 0).getTime();
const GD_PAGE_LOAD_REAL = Date.now();
function gdNowMs() { return GD_DEMO_NOW_EPOCH + (Date.now() - GD_PAGE_LOAD_REAL); }
function gdExamCountdownSection(c) {
  const upcoming = c.exams.upcoming.filter(e => e.datetime);
  if (!upcoming.length) return '';
  const sorted = [...upcoming].sort((a,b) => new Date(a.datetime) - new Date(b.datetime));
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Exam Countdown')}</div></div>
    <div class="card-body">
      ${sorted.map(gdCountdownCard).join('')}
    </div></div>`;
}
function gdCountdownCard(e) {
  const target = new Date(e.datetime).getTime();
  const diff = target - gdNowMs();
  const dayKey = e.datetime.slice(0,10);
  const isToday = dayKey === gdAttDateKey(GD_ATT_TODAY.getFullYear(), GD_ATT_TODAY.getMonth(), GD_ATT_TODAY.getDate());
  const passed = diff <= 0;
  const cls = passed ? 'passed' : isToday ? 'today' : '';
  const totalSec = Math.max(0, Math.floor(diff/1000));
  const dd = Math.floor(totalSec/86400), hh = Math.floor((totalSec%86400)/3600), mm = Math.floor((totalSec%3600)/60), ss = totalSec%60;
  const unitsHTML = gdCountdownUnitHTML(dd, hh, mm, ss);
  const rightSide = passed
    ? `<span class="gd-countdown-status-badge passed">${t('Completed')}</span>`
    : isToday
      ? `<span class="gd-countdown-status-badge today">${t('Today')}</span><div class="gd-countdown-units gd-countdown-value" data-target="${e.datetime}">${unitsHTML}</div>`
      : `<div class="gd-countdown-units gd-countdown-value" data-target="${e.datetime}">${unitsHTML}</div>`;
  return `<div class="gd-countdown-card ${cls}">
    <div class="gd-countdown-info">
      <div class="gd-countdown-title">${t(e.subject)} — ${t(e.title)}</div>
      <div class="gd-countdown-sub">${gdAttFmtLong(dayKey)}${e.time?' · '+e.time:''}</div>
    </div>
    ${rightSide}
  </div>`;
}
function gdCountdownUnitHTML(days, hours, mins, secs) {
  return `<div class="gd-countdown-unit"><div class="gd-countdown-unit-num">${days}</div><div class="gd-countdown-unit-label">${t('d')}</div></div>
    <div class="gd-countdown-unit"><div class="gd-countdown-unit-num">${hours}</div><div class="gd-countdown-unit-label">${t('h')}</div></div>
    <div class="gd-countdown-unit"><div class="gd-countdown-unit-num">${mins}</div><div class="gd-countdown-unit-label">${t('m')}</div></div>
    <div class="gd-countdown-unit"><div class="gd-countdown-unit-num">${secs}</div><div class="gd-countdown-unit-label">${t('s')}</div></div>`;
}
setInterval(() => {
  document.querySelectorAll('.gd-countdown-value[data-target]').forEach(el => {
    const target = new Date(el.dataset.target).getTime();
    const diff = target - gdNowMs();
    if (diff <= 0) {
      const card = el.closest('.gd-countdown-card');
      if (card && !card.classList.contains('passed')) {
        const c = gdGetActiveChild();
        if (c) { const body = document.getElementById('gd-body-grades'); if (body) body.innerHTML = gdGradesBody(c, gdState.tab.grades); }
      }
      return;
    }
    const totalSec = Math.floor(diff/1000);
    const days = Math.floor(totalSec/86400);
    const hours = Math.floor((totalSec%86400)/3600);
    const mins = Math.floor((totalSec%3600)/60);
    const secs = totalSec%60;
    el.innerHTML = gdCountdownUnitHTML(days, hours, mins, secs);
  });
}, 1000);

/* ── Homework (Overview + Analytics) ── */
const GD_MONTH_ABBR = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
function gdParseDMY(str) {
  // Parses loosely-formatted display dates like "15 Mar 2026" used across homework/exams.
  if (!str) return null;
  const parts = str.split(' ');
  if (parts.length !== 3) return null;
  const day = parseInt(parts[0], 10);
  const monIdx = GD_MONTH_ABBR.indexOf(parts[1].slice(0,3));
  const year = parseInt(parts[2], 10);
  if (isNaN(day) || monIdx === -1 || isNaN(year)) return null;
  return new Date(year, monIdx, day);
}
function gdHwStatusOf(h) {
  if (h.status === 'done') return 'done';
  const due = gdParseDMY(h.due);
  if (due && due < GD_ATT_TODAY) return 'overdue';
  return 'pending';
}
function gdHwStatusLabel(s) { return s==='done'?t('Done'):s==='overdue'?t('Overdue'):t('Pending'); }

function gdHomeworkView(c) {
  const tabs = [ {id:'overview', label:'Overview'}, {id:'analytics', label:'Analytics'} ];
  return `<div class="st-tabs">${tabs.map(tb=>`<div class="st-tab gd-tab-hw${tb.id===gdState.tab.homework?' active':''}" data-tab="${tb.id}" onclick="gdSetHwTab('${tb.id}')">${t(tb.label)}</div>`).join('')}</div>
    <div id="gd-body-homework">${gdHomeworkBody(c, gdState.tab.homework)}</div>`;
}
function gdSetHwTab(tabId) {
  gdState.tab.homework = tabId;
  document.querySelectorAll('.gd-tab-hw').forEach(el => el.classList.toggle('active', el.dataset.tab === tabId));
  const c = gdGetActiveChild(); if (!c) return;
  const body = document.getElementById('gd-body-homework');
  if (body) body.innerHTML = gdHomeworkBody(c, tabId);
}
function gdHomeworkBody(c, tab) {
  if (!c.homework || !c.homework.length) return gdHwEmptyState();
  return tab === 'analytics' ? gdHomeworkAnalytics(c) : gdHomeworkOverview(c);
}
function gdHwEmptyState() {
  return `<div class="gd-empty-state">
    <div class="gd-empty-state-ico"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg></div>
    <div class="gd-empty-state-title">${t('No homework assigned yet')}</div>
    <div class="gd-empty-state-sub">${t('Homework assignments will appear here as soon as teachers post them for this child.')}</div>
  </div>`;
}
function gdHwItemRow(h) {
  const status = gdHwStatusOf(h);
  return `<div class="gd-hw-item-row">
    <div class="gd-hw-item-body">
      <div class="gd-hw-item-title">${t(h.subject)} — ${t(h.title)}</div>
      <div class="gd-hw-item-sub">${t('Due')} ${h.due}</div>
    </div>
    <span class="status-pill ${status}">${gdHwStatusLabel(status)}</span>
  </div>`;
}
function gdHomeworkOverview(c) {
  const outstanding = c.homework.filter(h => gdHwStatusOf(h) !== 'done').sort((a,b) => (gdParseDMY(a.due)||0) - (gdParseDMY(b.due)||0));
  const completed = c.homework.filter(h => gdHwStatusOf(h) === 'done');
  const upcoming = outstanding.filter(h => gdHwStatusOf(h) === 'pending').slice(0,3);
  return `
    <div class="card"><div class="card-header"><div class="card-title">${t('Upcoming Deadlines')}</div></div>
      <div class="card-body">
        ${upcoming.map(gdHwItemRow).join('') || `<div style="color:var(--muted);font-size:12.5px">${t('No upcoming deadlines — all caught up.')}</div>`}
      </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Outstanding Work')}</div></div>
      <div class="card-body">
        ${outstanding.map(gdHwItemRow).join('') || `<div style="color:var(--muted);font-size:12.5px">${t('Nothing outstanding — great job staying on top of it!')}</div>`}
      </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Completed Work')}</div></div>
      <div class="card-body">
        ${completed.map(gdHwItemRow).join('') || `<div style="color:var(--muted);font-size:12.5px">${t('No completed homework yet.')}</div>`}
      </div></div>`;
}
function gdHomeworkAnalytics(c) {
  const total = c.homework.length;
  const done = c.homework.filter(h => gdHwStatusOf(h) === 'done').length;
  const overdue = c.homework.filter(h => gdHwStatusOf(h) === 'overdue').length;
  const pending = total - done - overdue;
  const pct = total ? Math.round((done/total)*100) : 0;
  const r = 40, circ = 2*Math.PI*r;
  const dash = circ * (pct/100);

  // Subject-level breakdown: completion rate per subject that has homework.
  const bySubject = {};
  c.homework.forEach(h => {
    if (!bySubject[h.subject]) bySubject[h.subject] = { total:0, done:0 };
    bySubject[h.subject].total++;
    if (gdHwStatusOf(h) === 'done') bySubject[h.subject].done++;
  });

  return `
    <div class="card"><div class="card-header"><div class="card-title">${t('Completion Rate')}</div></div>
      <div class="card-body gd-hw-ring-card">
        <svg width="100" height="100" viewBox="0 0 100 100">
          <circle cx="50" cy="50" r="${r}" fill="none" stroke="rgba(255,255,255,0.08)" stroke-width="10"/>
          <circle cx="50" cy="50" r="${r}" fill="none" stroke="var(--green)" stroke-width="10" stroke-linecap="round"
            stroke-dasharray="${dash.toFixed(1)} ${circ.toFixed(1)}" transform="rotate(-90 50 50)"/>
          <text x="50" y="55" text-anchor="middle" class="gd-hw-ring-num">${pct}%</text>
        </svg>
        <div class="gd-hw-ring-stats">
          <div class="gd-hw-ring-stat-row"><span class="gd-hw-ring-dot" style="background:var(--green)"></span>${t('Completed')}: <b style="color:#fff;margin-left:auto">${done}</b></div>
          <div class="gd-hw-ring-stat-row"><span class="gd-hw-ring-dot" style="background:var(--yellow)"></span>${t('Pending')}: <b style="color:#fff;margin-left:auto">${pending}</b></div>
          <div class="gd-hw-ring-stat-row"><span class="gd-hw-ring-dot" style="background:var(--red)"></span>${t('Overdue')}: <b style="color:#fff;margin-left:auto">${overdue}</b></div>
        </div>
      </div></div>
    <div class="gd-stat-row" style="margin-top:16px">
      <div class="stat-card"><div class="stat-label">${t('Total Assigned')}</div><div class="stat-val">${total}</div><div class="stat-icon blue">📝</div></div>
      <div class="stat-card"><div class="stat-label">${t('Outstanding')}</div><div class="stat-val">${total-done}</div><div class="stat-icon yellow">⏳</div></div>
      <div class="stat-card"><div class="stat-label">${t('Completed')}</div><div class="stat-val">${done}</div><div class="stat-icon green">✅</div></div>
      <div class="stat-card"><div class="stat-label">${t('Overdue')}</div><div class="stat-val">${overdue}</div><div class="stat-icon red">⚠️</div></div>
    </div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Subject-Level Overview')}</div></div>
      <div class="card-body">
        ${Object.keys(bySubject).map(sub => {
          const s = bySubject[sub]; const p = Math.round((s.done/s.total)*100);
          return `<div class="gd-hw-subject-row">
            <div class="gd-hw-subject-head"><span>${t(sub)}</span><span><b>${s.done}</b>/${s.total} ${t('completed')}</span></div>
            <div class="progress-track"><div class="progress-fill ${p>=70?'green':p>=40?'yellow':'red'}" style="width:${p}%"></div></div>
          </div>`;
        }).join('') || `<div style="color:var(--muted);font-size:12.5px">${t('No subject data yet.')}</div>`}
      </div></div>`;
}

/* ═══════════════════════════════
   GUARDIAN — ATTENDANCE CENTER
   Overview + chronological absence history + interactive calendar +
   full absence-justification flow (reason, optional document upload,
   validation, submission, pending/justified/unjustified states).
   Everything here reads only from the active child's own attendance
   record, mirroring the rest of the guardian module.
═══════════════════════════════ */
const GD_ATT_TODAY = new Date(2026, 2, 11); // fixed "today" the demo data is anchored to
const GD_ATT_MONTH_NAMES = ['January','February','March','April','May','June','July','August','September','October','November','December'];
const GD_ATT_DOW_NAMES = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
const GD_ATT_UPLOAD_TYPES = ['pdf','jpg','jpeg','png'];
const GD_ATT_UPLOAD_MAX_BYTES = 5 * 1024 * 1024; // 5MB
const GD_ATT_REASONS = ['Illness','Medical / Dental Appointment','Family Emergency','Religious Observance','Transportation Issue','Other'];

function gdAttParseDate(dateStr) { const [y,m,d] = dateStr.split('-').map(Number); return new Date(y, m-1, d); }
function gdAttDateKey(y,m,d) { return `${y}-${String(m+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`; }
function gdAttFmtLong(dateStr) {
  const d = gdAttParseDate(dateStr);
  return `${String(d.getDate()).padStart(2,'0')} ${t(GD_ATT_MONTH_NAMES[d.getMonth()]).slice(0,3)} ${d.getFullYear()}`;
}
function gdAttFmtBytes(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024*1024) return (bytes/1024).toFixed(0) + ' KB';
  return (bytes/(1024*1024)).toFixed(1) + ' MB';
}
function gdAttRecordsDesc(c) { return [...(c.attendance.records||[])].sort((a,b) => b.date.localeCompare(a.date)); }
function gdAttAbsences(c) { return gdAttRecordsDesc(c).filter(r => r.status === 'absent'); }
function gdAttFindRecord(c, dateStr) { return (c.attendance.records||[]).find(r => r.date === dateStr) || null; }
function gdAttJustStatusLabel(status) {
  return status === 'justified' ? t('Justified') : status === 'pending' ? t('Pending Review') : t('Unjustified');
}

function gdAttendanceView(c) {
  const tabs = [ {id:'overview', label:'Overview'}, {id:'history', label:'Absence History'}, {id:'calendar', label:'Calendar'} ];
  return `<div class="st-tabs gd-att-tabs">${tabs.map(tb=>`<div class="st-tab gd-tab-att${tb.id===gdState.tab.attendance?' active':''}" data-tab="${tb.id}" onclick="gdSetAttTab('${tb.id}')">${t(tb.label)}</div>`).join('')}</div>
    <div id="gd-body-attendance">${gdAttendanceBody(c, gdState.tab.attendance)}</div>`;
}
function gdSetAttTab(tabId) {
  gdState.tab.attendance = tabId;
  document.querySelectorAll('.gd-tab-att').forEach(el => el.classList.toggle('active', el.dataset.tab === tabId));
  const c = gdGetActiveChild(); if (!c) return;
  const body = document.getElementById('gd-body-attendance');
  if (body) body.innerHTML = gdAttendanceBody(c, tabId);
}
function gdAttendanceBody(c, tab) {
  if (!c.attendance || !c.attendance.records || !c.attendance.records.length) return gdAttNoRecordsState();
  if (tab === 'history')  return gdAbsenceHistoryView(c);
  if (tab === 'calendar') return gdAttendanceCalendarView(c);
  return gdAttendanceOverview(c);
}
function gdAttNoRecordsState() {
  return `<div class="gd-empty-state">
    <div class="gd-empty-state-ico"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg></div>
    <div class="gd-empty-state-title">${t('No attendance records yet')}</div>
    <div class="gd-empty-state-sub">${t('Attendance records will appear here once the school starts marking daily attendance for this child.')}</div>
  </div>`;
}

/* ── Overview ── */
function gdAttendanceOverview(c) {
  const a = c.attendance;
  const streak = a.streak || 0;
  return `
    <div class="gd-streak-card">
      <div class="gd-streak-flame">${streak > 0 ? '🔥' : '📉'}</div>
      <div>
        <div class="gd-streak-num">${streak} ${streak===1?t('day'):t('days')}</div>
        <div class="gd-streak-label">${t('Current attendance streak')}</div>
      </div>
      <div class="gd-streak-best">${t('Best streak')}<br><b>${a.bestStreak||0} ${(a.bestStreak||0)===1?t('day'):t('days')}</b></div>
    </div>
    <div class="gd-stat-row">
      <div class="stat-card"><div class="stat-label">${t('Attendance Rate')}</div><div class="stat-val">${a.rate}%</div><div class="stat-icon green">✅</div></div>
      <div class="stat-card"><div class="stat-label">${t('Present')}</div><div class="stat-val">${a.present}</div><div class="stat-icon blue">🟢</div></div>
      <div class="stat-card"><div class="stat-label">${t('Absent')}</div><div class="stat-val">${a.absent}</div><div class="stat-icon red">❌</div></div>
      <div class="stat-card"><div class="stat-label">${t('Late')}</div><div class="stat-val">${a.late}</div><div class="stat-icon yellow">⏰</div></div>
    </div>
    <div class="gd-stat-row">
      <div class="stat-card"><div class="stat-label">${t('Justified')}</div><div class="stat-val">${a.justified||0}</div><div class="stat-icon green">📄</div></div>
      <div class="stat-card"><div class="stat-label">${t('Unjustified')}</div><div class="stat-val">${a.unjustified||0}</div><div class="stat-icon red">📋</div></div>
      <div class="stat-card"><div class="stat-label">${t('School Days')}</div><div class="stat-val">${a.totalSchoolDays||'—'}</div><div class="stat-icon cyan">🏫</div></div>
      <div class="stat-card"><div class="stat-label">${t('Pending Review')}</div><div class="stat-val">${gdAttAbsences(c).filter(r=>r.justification && r.justification.status==='pending').length}</div><div class="stat-icon purple">⏳</div></div>
    </div>
    <div class="card"><div class="card-header"><div class="card-title">${t('Recent Days')}</div><div class="card-action" onclick="gdSetAttTab('calendar')">${t('View calendar')} →</div></div>
      <div class="card-body">
        ${gdAttRecordsDesc(c).slice(0,6).map(r => `<div class="info-row"><span>${gdAttFmtLong(r.date)}</span><span class="status-pill ${r.status}">${t(r.status.charAt(0).toUpperCase()+r.status.slice(1))}</span></div>`).join('')}
      </div></div>`;
}

/* ── Absence History ── */
function gdAbsenceHistoryView(c) {
  const absences = gdAttAbsences(c);
  if (!absences.length) return `<div class="card"><div class="card-body">
    <div class="gd-empty-mini">${t('No absences recorded for this child — great attendance!')}</div>
  </div></div>`;
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Absence History')}</div></div>
    <div class="card-body">
      ${absences.map(r => gdAbsenceRow(c, r)).join('')}
    </div></div>`;
}
function gdAbsenceRow(c, r) {
  const j = r.justification || { status:'unjustified' };
  const sub = j.status === 'unjustified'
    ? t('No justification submitted yet')
    : j.status === 'pending'
      ? t('Submitted') + ' ' + gdAttFmtLong(j.submittedDate) + ' · ' + t('Awaiting school review')
      : t('Reviewed') + ' ' + gdAttFmtLong(j.reviewedDate || j.submittedDate);
  const btn = j.status === 'unjustified'
    ? `<button type="button" class="st-btn sm" onclick="gdOpenJustifyModal('${c.id}','${r.date}')">${t('Justify Absence')}</button>`
    : `<button type="button" class="st-btn ghost sm" onclick="gdOpenJustifyModal('${c.id}','${r.date}')">${t('View Details')}</button>`;
  return `<div class="gd-absence-row">
    <div class="gd-absence-date">${gdAttFmtLong(r.date)}</div>
    <div class="gd-absence-mid">
      <div class="gd-absence-reason">${j.reason ? t(j.reason) : t('Absence')}</div>
      <div class="gd-absence-sub">${sub}</div>
    </div>
    <span class="status-pill ${j.status}">${gdAttJustStatusLabel(j.status)}</span>
    <div class="gd-absence-actions">${btn}</div>
  </div>`;
}

/* ── Calendar ── */
function gdAttendanceCalendarView(c) {
  const st = gdState.attendance;
  return `<div class="card"><div class="card-body">
      <div class="gd-cal-header">
        <button type="button" class="gd-cal-nav-btn" onclick="gdCalNav(-1)" aria-label="${t('Previous month')}"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"/></svg></button>
        <div class="gd-cal-title">${t(GD_ATT_MONTH_NAMES[st.calMonth])} ${st.calYear}</div>
        <button type="button" class="gd-cal-nav-btn" onclick="gdCalNav(1)" aria-label="${t('Next month')}"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"/></svg></button>
      </div>
      <div class="gd-cal-grid">
        ${GD_ATT_DOW_NAMES.map(d => `<div class="gd-cal-dow">${t(d)}</div>`).join('')}
        ${gdCalCells(c)}
      </div>
      <div id="gd-cal-detail">${st.calSelected ? gdCalDetail(c, st.calSelected) : ''}</div>
    </div></div>`;
}
function gdCalStatusFor(c, dateStr, dateObj) {
  const rec = gdAttFindRecord(c, dateStr);
  if (rec) return rec.status;
  const dow = dateObj.getDay();
  if (dow === 0 || dow === 6) return 'weekend';
  if (dateObj > GD_ATT_TODAY) return 'future';
  return 'present'; // no exception recorded for a school day implies present
}
function gdCalCells(c) {
  const st = gdState.attendance;
  const firstDow = new Date(st.calYear, st.calMonth, 1).getDay();
  const daysInMonth = new Date(st.calYear, st.calMonth + 1, 0).getDate();
  let html = '';
  for (let i = 0; i < firstDow; i++) html += `<div class="gd-cal-day empty"></div>`;
  for (let d = 1; d <= daysInMonth; d++) {
    const dateObj = new Date(st.calYear, st.calMonth, d);
    const dateStr = gdAttDateKey(st.calYear, st.calMonth, d);
    const status = gdCalStatusFor(c, dateStr, dateObj);
    const isToday = dateStr === gdAttDateKey(GD_ATT_TODAY.getFullYear(), GD_ATT_TODAY.getMonth(), GD_ATT_TODAY.getDate());
    const isSelected = dateStr === st.calSelected;
    html += `<div class="gd-cal-day${isToday?' today':''}${isSelected?' selected':''}" onclick="gdCalSelectDay('${dateStr}')">
      <div class="gd-cal-day-num">${d}</div><div class="gd-cal-dot ${status}"></div>
    </div>`;
  }
  return html;
}
function gdCalNav(delta) {
  const st = gdState.attendance;
  st.calMonth += delta;
  if (st.calMonth < 0) { st.calMonth = 11; st.calYear--; }
  if (st.calMonth > 11) { st.calMonth = 0; st.calYear++; }
  st.calSelected = null;
  const c = gdGetActiveChild(); if (!c) return;
  const body = document.getElementById('gd-body-attendance');
  if (body) body.innerHTML = gdAttendanceCalendarView(c);
}
function gdCalSelectDay(dateStr) {
  gdState.attendance.calSelected = dateStr;
  const c = gdGetActiveChild(); if (!c) return;
  const grid = document.querySelector('#gd-body-attendance .gd-cal-grid');
  if (grid) grid.innerHTML = `${GD_ATT_DOW_NAMES.map(d => `<div class="gd-cal-dow">${t(d)}</div>`).join('')}${gdCalCells(c)}`;
  const detail = document.getElementById('gd-cal-detail');
  if (detail) detail.innerHTML = gdCalDetail(c, dateStr);
}
function gdCalDetail(c, dateStr) {
  const dateObj = gdAttParseDate(dateStr);
  const status = gdCalStatusFor(c, dateStr, dateObj);
  const rec = gdAttFindRecord(c, dateStr);
  let body = '';
  if (status === 'weekend') body = `<div class="gd-absence-sub">${t('Weekend — no school.')}</div>`;
  else if (status === 'future') body = `<div class="gd-absence-sub">${t("This date hasn't happened yet.")}</div>`;
  else if (status === 'present') body = `<div class="gd-absence-sub">${t('Marked present for the full day.')}</div>`;
  else if (status === 'late') body = `<div class="gd-absence-sub">${rec && rec.note ? t(rec.note) : t('Arrived late.')}</div>`;
  else if (status === 'absent') {
    const j = (rec && rec.justification) || { status:'unjustified' };
    const btn = j.status === 'unjustified'
      ? `<button type="button" class="st-btn sm" style="margin-top:10px" onclick="gdOpenJustifyModal('${c.id}','${dateStr}')">${t('Justify Absence')}</button>`
      : `<button type="button" class="st-btn ghost sm" style="margin-top:10px" onclick="gdOpenJustifyModal('${c.id}','${dateStr}')">${t('View Details')}</button>`;
    body = `<span class="status-pill ${j.status}">${gdAttJustStatusLabel(j.status)}</span>${btn}`;
  }
  return `<div class="gd-cal-detail"><div class="gd-cal-detail-date">${gdAttFmtLong(dateStr)}</div>${body}</div>`;
}

/* ── Absence Justification Flow ── */
function gdOpenJustifyModal(childId, dateStr) {
  const c = gdChildren().find(x => x.id === childId);
  if (!c) return;
  const rec = gdAttFindRecord(c, dateStr);
  if (!rec || rec.status !== 'absent') return;
  const j = rec.justification;
  if (j && (j.status === 'justified' || j.status === 'pending')) {
    stOpenModal(gdJustifyReadonlyModalHTML(c, rec));
    return;
  }
  gdState.attendance.justify = { open:true, childId, recordDate:dateStr, reason:'', details:'', submitting:false, error:'',
    file: { state:'idle', name:'', size:0, error:'', progress:0 } };
  stOpenModal(gdJustifyFormModalHTML(c, rec));
}
function gdJustifyReadonlyModalHTML(c, rec) {
  const j = rec.justification;
  return `
    <div class="st-modal-title">${t('Absence Details')}</div>
    <div class="st-modal-sub">${c.name} · ${gdAttFmtLong(rec.date)}</div>
    <span class="status-pill ${j.status}">${gdAttJustStatusLabel(j.status)}</span>
    <div style="margin-top:14px">
      <div class="gd-just-readonly-row"><span>${t('Reason')}</span><span>${t(j.reason)}</span></div>
      <div class="gd-just-readonly-row"><span>${t('Details')}</span><span>${j.details||'—'}</span></div>
      <div class="gd-just-readonly-row"><span>${t('Submitted')}</span><span>${gdAttFmtLong(j.submittedDate)}</span></div>
      ${j.status==='justified' ? `<div class="gd-just-readonly-row"><span>${t('Reviewed')}</span><span>${gdAttFmtLong(j.reviewedDate||j.submittedDate)}</span></div>` : ''}
      ${j.file ? `<div class="gd-just-readonly-row"><span>${t('Attachment')}</span><span>📎 ${j.file.name} (${gdAttFmtBytes(j.file.size)})</span></div>` : `<div class="gd-just-readonly-row"><span>${t('Attachment')}</span><span>${t('None')}</span></div>`}
    </div>
    <button type="button" class="st-btn ghost" style="width:100%;margin-top:16px" onclick="stCloseModal()">${t('Close')}</button>`;
}
function gdJustifyFormModalHTML(c, rec) {
  return `
    <div class="st-modal-title">${t('Justify Absence')}</div>
    <div class="st-modal-sub">${c.name} · ${gdAttFmtLong(rec.date)}</div>
    <div id="gd-just-form-body">${gdJustifyFormBody()}</div>`;
}
function gdJustifyFormBody() {
  const st = gdState.attendance.justify;
  return `
    <div class="st-field">
      <label>${t('Reason')}</label>
      <select id="gd-just-reason">
        <option value="">${t('Select a reason')}</option>
        ${GD_ATT_REASONS.map(r => `<option value="${r}" ${st.reason===r?'selected':''}>${t(r)}</option>`).join('')}
      </select>
    </div>
    <div class="st-field">
      <label>${t('Additional Details')}</label>
      <textarea id="gd-just-details" rows="3" placeholder="${t('Briefly explain the reason for the absence…')}">${st.details||''}</textarea>
    </div>
    <div class="st-field">
      <label>${t('Supporting Document (optional)')}</label>
      ${gdUploadZoneHTML()}
    </div>
    ${st.error ? `<div class="gd-upload-error-box" style="margin-bottom:14px"><div class="gd-upload-error-text">${st.error}</div></div>` : ''}
    <div style="display:flex;gap:10px;margin-top:6px">
      <button type="button" class="st-btn ghost" style="flex:1" onclick="stCloseModal()">${t('Cancel')}</button>
      <button type="button" class="st-btn" id="gd-just-submit-btn" style="flex:1" onclick="gdSubmitJustification()" ${st.submitting?'disabled':''}>${st.submitting?`<span class="gd-spinner"></span>${t('Submitting...')}`:t('Submit Justification')}</button>
    </div>`;
}
function gdRerenderJustifyForm() {
  const body = document.getElementById('gd-just-form-body');
  if (body) body.innerHTML = gdJustifyFormBody();
}

/* ── Supporting document upload ── */
function gdUploadZoneHTML() {
  const f = gdState.attendance.justify.file;
  if (f.state === 'idle') return `
    <div class="gd-upload-zone" onclick="document.getElementById('gd-just-file-input').click()">
      <div class="gd-upload-zone-icon">📎</div>
      <div class="gd-upload-zone-text">${t('Tap to upload a file')}</div>
      <div class="gd-upload-zone-hint">${t('PDF, JPG or PNG · Max 5MB')}</div>
    </div>
    <input type="file" id="gd-just-file-input" accept=".pdf,.jpg,.jpeg,.png" style="display:none" onchange="gdHandleFileSelect(this.files[0])">`;
  if (f.state === 'uploading') return `
    <div class="gd-upload-file">
      <div class="gd-upload-file-ico"><span class="gd-spinner"></span></div>
      <div class="gd-upload-file-info">
        <div class="gd-upload-file-name">${f.name}</div>
        <div class="gd-upload-file-size">${t('Uploading…')}</div>
        <div class="gd-upload-progress-track"><div class="gd-upload-progress-fill" style="width:${f.progress}%"></div></div>
      </div>
    </div>`;
  if (f.state === 'error') return `
    <div class="gd-upload-error-box">
      <div class="gd-upload-error-text">${f.error}</div>
      <button type="button" class="st-btn ghost sm" onclick="gdResetUpload()">${t('Try Again')}</button>
    </div>
    <input type="file" id="gd-just-file-input" accept=".pdf,.jpg,.jpeg,.png" style="display:none" onchange="gdHandleFileSelect(this.files[0])">`;
  // success
  return `
    <div class="gd-upload-file">
      <div class="gd-upload-file-ico">📄</div>
      <div class="gd-upload-file-info">
        <div class="gd-upload-file-name">${f.name}</div>
        <div class="gd-upload-file-size">${gdAttFmtBytes(f.size)} · ${t('Uploaded')}</div>
      </div>
      <div class="gd-upload-file-actions">
        <button type="button" class="gd-upload-icon-btn" title="${t('Replace')}" onclick="document.getElementById('gd-just-file-input-r').click()"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 4v6h-6"/><path d="M1 20v-6h6"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg></button>
        <button type="button" class="gd-upload-icon-btn" title="${t('Remove')}" onclick="gdResetUpload()"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
      </div>
    </div>
    <input type="file" id="gd-just-file-input-r" accept=".pdf,.jpg,.jpeg,.png" style="display:none" onchange="gdHandleFileSelect(this.files[0])">`;
}
function gdHandleFileSelect(file) {
  if (!file) return;
  const ext = file.name.split('.').pop().toLowerCase();
  const f = gdState.attendance.justify.file;
  if (!GD_ATT_UPLOAD_TYPES.includes(ext)) {
    f.state = 'error'; f.error = t('Unsupported file type. Please upload a PDF, JPG or PNG.');
    gdRefreshUploadZone(); return;
  }
  if (file.size > GD_ATT_UPLOAD_MAX_BYTES) {
    f.state = 'error'; f.error = t('File is too large. Maximum size is 5MB.');
    gdRefreshUploadZone(); return;
  }
  f.state = 'uploading'; f.name = file.name; f.size = file.size; f.progress = 0; f.error = '';
  gdRefreshUploadZone();
  const tick = () => {
    f.progress = Math.min(100, f.progress + 20 + Math.round(Math.random()*15));
    if (f.progress >= 100) {
      // Simulated backend acknowledgement — a small, real chance of failure so the
      // failure state is genuinely reachable rather than always resolving to success.
      const failed = Math.random() < 0.12;
      if (failed) {
        f.state = 'error'; f.error = t('Upload failed. Please check your connection and try again.');
      } else {
        f.state = 'success';
      }
      gdRefreshUploadZone();
      return;
    }
    gdRefreshUploadZone();
    setTimeout(tick, 220);
  };
  setTimeout(tick, 220);
}
function gdRefreshUploadZone() {
  // Re-render only the field wrapper that holds the upload zone, so the rest of the
  // form (reason, details already typed) is left untouched.
  const details = document.getElementById('gd-just-details');
  if (details) gdState.attendance.justify.details = details.value;
  const reason = document.getElementById('gd-just-reason');
  if (reason) gdState.attendance.justify.reason = reason.value;
  gdRerenderJustifyForm();
}
function gdResetUpload() {
  gdState.attendance.justify.file = { state:'idle', name:'', size:0, error:'', progress:0 };
  gdRefreshUploadZone();
}

function gdSubmitJustification() {
  const st = gdState.attendance.justify;
  const reason = (document.getElementById('gd-just-reason')||{}).value || '';
  const details = (document.getElementById('gd-just-details')||{}).value || '';
  st.reason = reason; st.details = details;

  if (!reason) { st.error = t('Please select a reason for the absence.'); gdRerenderJustifyForm(); return; }
  if (!details || details.trim().length < 10) { st.error = t('Please add a few more details (at least 10 characters).'); gdRerenderJustifyForm(); return; }
  if (st.file.state === 'uploading') { st.error = t('Please wait for the file upload to finish.'); gdRerenderJustifyForm(); return; }
  if (st.file.state === 'error') { st.error = t('Please resolve the file upload error, or remove the file, before submitting.'); gdRerenderJustifyForm(); return; }
  st.error = '';
  st.submitting = true;
  gdRerenderJustifyForm();

  setTimeout(() => {
    const c = gdChildren().find(x => x.id === st.childId);
    const rec = c && gdAttFindRecord(c, st.recordDate);
    if (rec) {
      rec.justification = {
        status: 'pending',
        reason: st.reason,
        details: st.details,
        submittedDate: gdAttDateKey(GD_ATT_TODAY.getFullYear(), GD_ATT_TODAY.getMonth(), GD_ATT_TODAY.getDate()),
        file: st.file.state === 'success' ? { name: st.file.name, size: st.file.size } : null
      };
      c.attendance.unjustified = Math.max(0, (c.attendance.unjustified||0) - 1);
    }
    st.submitting = false;
    stOpenModal(gdJustifySuccessModalHTML());
    if (c) {
      const body = document.getElementById('gd-body-attendance');
      if (body) body.innerHTML = gdAttendanceBody(c, gdState.tab.attendance);
    }
  }, 900);
}
function gdJustifySuccessModalHTML() {
  return `<div class="gd-just-confirm">
      <div class="gd-just-confirm-ico"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg></div>
      <div style="font-family:var(--font-display);font-size:16px;font-weight:800;margin-bottom:6px">${t('Justification Submitted')}</div>
      <div style="font-size:12.5px;color:var(--muted);line-height:1.5;margin-bottom:18px">${t('Your justification has been sent to the school and is now pending review. You can check its status anytime from Absence History.')}</div>
      <button type="button" class="st-btn" style="width:100%" onclick="stCloseModal()">${t('Done')}</button>
    </div>`;
}

/* ═══════════════════════════════
   GUARDIAN — SCHOOL CALENDAR
   Month-grid calendar with day-level detail + a chronological "Upcoming"
   list, both scoped to the active child's own events. Mirrors the
   Attendance Center's calendar interaction pattern (month nav, selected-day
   detail panel) but for general school events rather than attendance status.
   Demonstrates loading / error / empty / populated states explicitly.
═══════════════════════════════ */
const GD_SC_TYPE_LABELS = { exam:'Exam', holiday:'Holiday', meeting:'Meeting', deadline:'Deadline', activity:'Activity' };

function gdSCEventsForDate(c, dateStr) { return (c.calendar||[]).filter(e => e.date === dateStr); }
function gdSCEventsSorted(c) {
  return [...(c.calendar||[])].sort((a,b) => a.date === b.date ? (a.time||'').localeCompare(b.time||'') : a.date.localeCompare(b.date));
}

function gdCalendarView(c) {
  const tabs = [ {id:'month', label:'Calendar'}, {id:'upcoming', label:'Upcoming'} ];
  if (gdState.calendar.loadState === 'idle') gdCalLoad(c);
  return `<div class="st-tabs">${tabs.map(tb=>`<div class="st-tab gd-tab-sc${tb.id===gdState.tab.calendar?' active':''}" data-tab="${tb.id}" onclick="gdSetSCTab('${tb.id}')">${t(tb.label)}</div>`).join('')}</div>
    <div id="gd-body-calendar">${gdCalendarBody(c, gdState.tab.calendar)}</div>`;
}
function gdSetSCTab(tabId) {
  gdState.tab.calendar = tabId;
  document.querySelectorAll('.gd-tab-sc').forEach(el => el.classList.toggle('active', el.dataset.tab === tabId));
  const c = gdGetActiveChild(); if (!c) return;
  const body = document.getElementById('gd-body-calendar');
  if (body) body.innerHTML = gdCalendarBody(c, tabId);
}
function gdCalLoad(c) {
  gdState.calendar.loadState = 'loading';
  setTimeout(() => {
    gdState.calendar.loadState = Math.random() < 0.08 ? 'error' : 'ready';
    const body = document.getElementById('gd-body-calendar');
    if (body) body.innerHTML = gdCalendarBody(c, gdState.tab.calendar);
  }, 650);
}
function gdCalRetry() {
  gdState.calendar.loadState = 'idle';
  const c = gdGetActiveChild(); if (!c) return;
  const body = document.getElementById('gd-body-calendar');
  if (body) body.innerHTML = gdCalendarBody(c, gdState.tab.calendar);
}
function gdCalendarBody(c, tab) {
  if (gdState.calendar.loadState === 'loading') return gdSCLoadingState();
  if (gdState.calendar.loadState === 'error') return gdSCErrorState();
  if (!c.calendar || !c.calendar.length) return gdSCNoEventsState();
  return tab === 'upcoming' ? gdCalendarUpcomingView(c) : gdCalendarMonthView(c);
}
function gdSCLoadingState() {
  return `<div class="gd-sc-load-state"><span class="gd-spinner"></span>${t('Loading school calendar…')}</div>`;
}
function gdSCErrorState() {
  return `<div class="gd-empty-state">
    <div class="gd-empty-state-ico" style="background:rgba(255,69,58,0.12);color:var(--red)"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg></div>
    <div class="gd-empty-state-title">${t("Couldn't load the school calendar")}</div>
    <div class="gd-empty-state-sub">${t('Something went wrong while fetching this calendar. Please try again.')}</div>
    <button class="st-btn ghost" onclick="gdCalRetry()">${t('Retry')}</button>
  </div>`;
}
function gdSCNoEventsState() {
  return `<div class="gd-empty-state">
    <div class="gd-empty-state-ico"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg></div>
    <div class="gd-empty-state-title">${t('No school events yet')}</div>
    <div class="gd-empty-state-sub">${t('Exams, deadlines, meetings and other school events will show up here once the school publishes them.')}</div>
  </div>`;
}
function gdSCLegend() {
  return `<div class="gd-sc-legend">
    ${Object.keys(GD_SC_TYPE_LABELS).map(k => `<div class="gd-sc-legend-item"><span class="gd-sc-legend-dot" style="background:var(--${k==='exam'?'pink':k==='holiday'?'accent3':k==='meeting'?'accent':k==='deadline'?'yellow':'green'})"></span>${t(GD_SC_TYPE_LABELS[k])}</div>`).join('')}
  </div>`;
}
function gdCalendarMonthView(c) {
  const st = gdState.calendar;
  return `<div class="card"><div class="card-body">
      ${gdSCLegend()}
      <div class="gd-cal-header">
        <button type="button" class="gd-cal-nav-btn" onclick="gdSCNav(-1)" aria-label="${t('Previous month')}"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"/></svg></button>
        <div class="gd-cal-title">${t(GD_ATT_MONTH_NAMES[st.calMonth])} ${st.calYear}</div>
        <button type="button" class="gd-cal-nav-btn" onclick="gdSCNav(1)" aria-label="${t('Next month')}"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"/></svg></button>
      </div>
      <div class="gd-cal-grid">
        ${GD_ATT_DOW_NAMES.map(d => `<div class="gd-cal-dow">${t(d)}</div>`).join('')}
        ${gdSCCells(c)}
      </div>
      <div id="gd-sc-detail">${st.calSelected ? gdSCDetail(c, st.calSelected) : ''}</div>
    </div></div>`;
}
function gdSCCells(c) {
  const st = gdState.calendar;
  const firstDow = new Date(st.calYear, st.calMonth, 1).getDay();
  const daysInMonth = new Date(st.calYear, st.calMonth + 1, 0).getDate();
  let html = '';
  for (let i = 0; i < firstDow; i++) html += `<div class="gd-cal-day empty"></div>`;
  for (let d = 1; d <= daysInMonth; d++) {
    const dateStr = gdAttDateKey(st.calYear, st.calMonth, d);
    const events = gdSCEventsForDate(c, dateStr);
    const isToday = dateStr === gdAttDateKey(GD_ATT_TODAY.getFullYear(), GD_ATT_TODAY.getMonth(), GD_ATT_TODAY.getDate());
    const isSelected = dateStr === st.calSelected;
    const dots = events.slice(0,3).map(e => `<span class="gd-cal-dot ${e.type}"></span>`).join('');
    html += `<div class="gd-cal-day${isToday?' today':''}${isSelected?' selected':''}${events.length?' has-events':''}" onclick="gdSCSelectDay('${dateStr}')">
      <div class="gd-cal-day-num">${d}</div><div class="gd-cal-dots-row">${dots}</div>
    </div>`;
  }
  return html;
}
function gdSCNav(delta) {
  const st = gdState.calendar;
  st.calMonth += delta;
  if (st.calMonth < 0) { st.calMonth = 11; st.calYear--; }
  if (st.calMonth > 11) { st.calMonth = 0; st.calYear++; }
  st.calSelected = null;
  const c = gdGetActiveChild(); if (!c) return;
  const body = document.getElementById('gd-body-calendar');
  if (body) body.innerHTML = gdCalendarMonthView(c);
}
function gdSCSelectDay(dateStr) {
  gdState.calendar.calSelected = dateStr;
  const c = gdGetActiveChild(); if (!c) return;
  const grid = document.querySelector('#gd-body-calendar .gd-cal-grid');
  if (grid) grid.innerHTML = `${GD_ATT_DOW_NAMES.map(d => `<div class="gd-cal-dow">${t(d)}</div>`).join('')}${gdSCCells(c)}`;
  const detail = document.getElementById('gd-sc-detail');
  if (detail) detail.innerHTML = gdSCDetail(c, dateStr);
}
function gdSCEventCard(e) {
  return `<div class="gd-sc-event-card">
    <div class="gd-sc-event-type-bar ${e.type}"></div>
    <div class="gd-sc-event-body">
      <div class="gd-sc-event-title">${e.subject ? t(e.subject)+' — ' : ''}${t(e.title)}</div>
      <div class="gd-sc-event-meta">${e.time ? e.time+' · ' : ''}${e.location ? t(e.location) : gdAttFmtLong(e.date)}</div>
      ${e.details ? `<div class="gd-sc-event-details">${t(e.details)}</div>` : ''}
    </div>
    <span class="gd-sc-event-badge ${e.type}">${t(GD_SC_TYPE_LABELS[e.type]||e.type)}</span>
  </div>`;
}
function gdSCDetail(c, dateStr) {
  const events = gdSCEventsForDate(c, dateStr);
  const body = events.length
    ? events.map(gdSCEventCard).join('')
    : `<div class="gd-absence-sub" style="padding:4px 0">${t('No events scheduled on this day.')}</div>`;
  return `<div class="gd-cal-detail"><div class="gd-cal-detail-date">${gdAttFmtLong(dateStr)}</div>${body}</div>`;
}
function gdCalendarUpcomingView(c) {
  const upcoming = gdSCEventsSorted(c).filter(e => e.date >= gdAttDateKey(GD_ATT_TODAY.getFullYear(), GD_ATT_TODAY.getMonth(), GD_ATT_TODAY.getDate()));
  if (!upcoming.length) return `<div class="card"><div class="card-body">
    <div class="gd-empty-mini">${t('No upcoming school events scheduled right now.')}</div>
  </div></div>`;
  let lastDate = '';
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Upcoming Events')}</div></div>
    <div class="card-body">
      ${upcoming.map(e => {
        const group = e.date !== lastDate ? (lastDate = e.date, `<div class="gd-sc-upcoming-date-group">${gdAttFmtLong(e.date)}</div>`) : '';
        return group + gdSCEventCard(e);
      }).join('')}
    </div></div>`;
}

/* ── Analytics ── */
/* ── Child 360 (Overview / Performance / Attendance / Homework / Behavior /
   Achievements / Orientation) ──
   A single grouped hub connecting the child's major areas, per the "one
   coherent module, not a nav item per metric" requirement. Performance,
   Achievements, Orientation and Homework tabs reuse existing, already-solid
   views rather than duplicating them; Attendance gets a lightweight
   cross-link summary (its full detail already lives on the dedicated
   Attendance page); Behavior is new and gracefully shows "not available"
   since no behavior data/permission model exists yet — real information
   only, never fabricated. */
function gdAnalyticsView(c) {
  const tabs = [
    { id:'overview',     label:'Overview' },
    { id:'performance',  label:'Performance' },
    { id:'attendance',   label:'Attendance' },
    { id:'homework',     label:'Homework' },
    { id:'behavior',     label:'Behavior' },
    { id:'achievements', label:'Achievements' },
    { id:'orientation',  label:'Orientation' },
  ];
  return `<div class="st-tabs">${tabs.map(tb => `<div class="st-tab gd-tab-360${tb.id===gdState.tab.threeSixty?' active':''}" data-tab="${tb.id}" onclick="gdSet360Tab('${tb.id}')">${t(tb.label)}</div>`).join('')}</div>
    <div id="gd-body-360">${gd360Body(c, gdState.tab.threeSixty)}</div>`;
}
function gdSet360Tab(tabId) {
  gdState.tab.threeSixty = tabId;
  document.querySelectorAll('.gd-tab-360').forEach(el => el.classList.toggle('active', el.dataset.tab === tabId));
  const c = gdGetActiveChild(); if (!c) return;
  const body = document.getElementById('gd-body-360');
  if (body) body.innerHTML = gd360Body(c, tabId);
}
function gd360Body(c, tab) {
  if (tab === 'performance')  return gdPerfSummaryTab(c);
  if (tab === 'attendance')   return gd360AttendanceTab(c);
  if (tab === 'homework')     return gdHomeworkAnalytics(c);
  if (tab === 'behavior')     return gd360BehaviorTab(c);
  if (tab === 'achievements') return gdAchievementsView(c);
  if (tab === 'orientation')  return gdOrientationView(c);
  return gd360Overview(c);
}
/* Connective at-a-glance summary tying Academic/Attendance/Homework/Exams/
   Achievements/Orientation together, with quick-links into the relevant
   tab or dedicated page — the actual "360" view, not another stat grid. */
function gd360Overview(c) {
  const hwDone = c.homework.filter(h => gdHwStatusOf(h) === 'done').length;
  const hwTotal = c.homework.length;
  const hwPct = hwTotal ? Math.round((hwDone / hwTotal) * 100) : null;
  const nextExam = (c.exams && c.exams.upcoming && c.exams.upcoming[0]) || null;
  const lastAchievement = (c.achievements && c.achievements[0]) || null;
  const streak = (c.attendance && c.attendance.streak) || 0;

  return `
    <div class="gd-stat-row">
      <div class="stat-card"><div class="stat-label">${t('Overall Average')}</div><div class="stat-val">${c.kpis.overallAvg}/20</div><div class="stat-icon blue">📊</div></div>
      <div class="stat-card"><div class="stat-label">${t('Attendance Rate')}</div><div class="stat-val">${c.kpis.attendanceRate}%</div><div class="stat-icon green">✅</div></div>
      <div class="stat-card"><div class="stat-label">${t('Homework Completion')}</div><div class="stat-val">${hwPct !== null ? hwPct + '%' : '—'}</div><div class="stat-icon yellow">📝</div></div>
      <div class="stat-card"><div class="stat-label">${t('Achievements')}</div><div class="stat-val">${(c.achievements || []).length}</div><div class="stat-icon purple">🏆</div></div>
    </div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Highlights')}</div></div>
      <div class="card-body">
        <div class="info-row"><span>🔥 ${t('Attendance streak')}</span><span>${streak} ${t(streak === 1 ? 'day' : 'days')}</span></div>
        <div class="info-row"><span>📝 ${t('Homework outstanding')}</span><span>${hwTotal - hwDone} / ${hwTotal}</span></div>
        <div class="info-row"><span>📅 ${t('Next exam')}</span><span>${nextExam ? `${t(nextExam.subject)}: ${t(nextExam.title)} — ${nextExam.date}` : t('None scheduled')}</span></div>
        <div class="info-row"><span>🏆 ${t('Latest achievement')}</span><span>${lastAchievement ? t(lastAchievement.title) : t('None yet')}</span></div>
      </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Orientation')}</div><div class="card-action" onclick="gdSet360Tab('orientation')">${t('View orientation')} →</div></div>
      <div class="card-body">
        <div class="info-row"><span>${t('Current Track')}</span><span>${t(c.orientation.track)}</span></div>
      </div></div>`;
}
/* Lightweight cross-link summary — the full Attendance experience (absence
   history, calendar, justification flow) already lives on its own page;
   this tab surfaces the headline numbers here so Child 360 stays connected
   without duplicating that system or wiring up ids that only exist there. */
function gd360AttendanceTab(c) {
  const a = c.attendance;
  if (!a || !a.records || !a.records.length) return gdAttNoRecordsState();
  const streak = a.streak || 0;
  return `
    <div class="gd-streak-card">
      <div class="gd-streak-flame">${streak > 0 ? '🔥' : '📉'}</div>
      <div>
        <div class="gd-streak-num">${streak} ${t(streak === 1 ? 'day' : 'days')}</div>
        <div class="gd-streak-label">${t('Current attendance streak')}</div>
      </div>
      <div class="gd-streak-best">${t('Best streak')}<br><b>${a.bestStreak || 0} ${t((a.bestStreak || 0) === 1 ? 'day' : 'days')}</b></div>
    </div>
    <div class="gd-stat-row">
      <div class="stat-card"><div class="stat-label">${t('Attendance Rate')}</div><div class="stat-val">${a.rate}%</div><div class="stat-icon green">✅</div></div>
      <div class="stat-card"><div class="stat-label">${t('Present')}</div><div class="stat-val">${a.present}</div><div class="stat-icon blue">🟢</div></div>
      <div class="stat-card"><div class="stat-label">${t('Absent')}</div><div class="stat-val">${a.absent}</div><div class="stat-icon red">❌</div></div>
      <div class="stat-card"><div class="stat-label">${t('Late')}</div><div class="stat-val">${a.late}</div><div class="stat-icon yellow">⏰</div></div>
    </div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Attendance Trend')}</div><span style="font-size:12px;color:var(--muted)">${t('Monthly attendance rate')}</span></div>
      <div class="card-body">${gdSvgLineChart((a.monthlyRate || []).map(m => ({ label: m.period, value: m.rate })), { max: 100, unit: '%', ariaLabel: t('Attendance rate over time'), emptyText: t('Not enough historical data yet to show an attendance trend.') })}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-body" style="text-align:center;padding:20px">
      <button class="st-btn ghost sm" onclick="switchView('attendance', document.querySelector('.nav-item'))">${t('View full Attendance Center')} →</button>
    </div></div>`;
}
/* No behavior data/permission model exists in the current frontend/data
   structure. Per the explicit requirement, this is shown honestly rather
   than filled with invented scores or incident data. */
function gd360BehaviorTab(c) {
  return `<div class="gd-empty-state">
    <div class="gd-empty-state-ico"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/></svg></div>
    <div class="gd-empty-state-title">${t('Behavior information unavailable')}</div>
    <div class="gd-empty-state-sub">${t("This school hasn't shared behavior information for this child yet, or it isn't available to guardians for this account.")}</div>
  </div>`;
}
/* ── Performance (subject averages + attendance trend snapshot) ── */
/* ── Performance charts ──
   Reusable SVG helpers. Both use real numeric data only — points/labels are
   never invented, and both render an honest empty state instead of an
   empty/broken chart when there isn't enough data (e.g. Sarah has no
   progressHistory or per-subject history yet). */
function gdSvgLineChart(points, opts) {
  opts = opts || {};
  const max = opts.max || 20;
  if (!points || points.length < 2) {
    return `<div class="gd-empty-mini">${t(opts.emptyText || 'Not enough historical data yet.')}</div>`;
  }
  const w = 600, h = 220, padL = 32, padR = 16, padT = 14, padB = 28;
  const plotW = w - padL - padR, plotH = h - padT - padB;
  const stepX = plotW / (points.length - 1);
  const xAt = i => padL + i * stepX;
  const yAt = v => padT + plotH - (Math.max(0, Math.min(v, max)) / max) * plotH;
  const linePath = points.map((p, i) => `${i === 0 ? 'M' : 'L'}${xAt(i).toFixed(1)},${yAt(p.value).toFixed(1)}`).join(' ');
  const gridLines = [0, 0.25, 0.5, 0.75, 1].map(f => {
    const val = Math.round(max * f);
    const y = yAt(val);
    return `<line x1="${padL}" y1="${y.toFixed(1)}" x2="${w - padR}" y2="${y.toFixed(1)}" stroke="var(--separator)" stroke-width="1"/>
      <text x="${padL - 6}" y="${(y + 3.5).toFixed(1)}" font-size="10" fill="var(--muted)" text-anchor="end">${val}</text>`;
  }).join('');
  const xLabels = points.map((p, i) => `<text x="${xAt(i).toFixed(1)}" y="${h - 8}" font-size="10" fill="var(--muted)" text-anchor="middle">${gdCommsEsc(p.label)}</text>`).join('');
  const dots = points.map((p, i) => `<circle cx="${xAt(i).toFixed(1)}" cy="${yAt(p.value).toFixed(1)}" r="3.5" fill="${opts.color || 'var(--accent)'}"><title>${gdCommsEsc(p.label)}: ${p.value}${opts.unit || ''}</title></circle>`).join('');
  return `<svg viewBox="0 0 ${w} ${h}" style="width:100%;height:auto;display:block" role="img" aria-label="${gdCommsEsc(opts.ariaLabel || '')}">
    ${gridLines}
    <path d="${linePath}" fill="none" stroke="${opts.color || 'var(--accent)'}" stroke-width="2.5"/>
    ${dots}
    ${xLabels}
  </svg>`;
}
function gdSvgSparkline(points, opts) {
  opts = opts || {};
  if (!points || points.length < 2) return '';
  const max = opts.max || 20;
  const w = 90, h = 26, pad = 3;
  const stepX = (w - pad * 2) / (points.length - 1);
  const yAt = v => pad + (h - pad * 2) - (Math.max(0, Math.min(v, max)) / max) * (h - pad * 2);
  const path = points.map((p, i) => `${i === 0 ? 'M' : 'L'}${(pad + i * stepX).toFixed(1)},${yAt(p.value).toFixed(1)}`).join(' ');
  const last = points[points.length - 1];
  const titleText = points.map(p => `${p.label}: ${p.value}`).join(' → ');
  return `<svg viewBox="0 0 ${w} ${h}" style="width:64px;height:20px;vertical-align:middle;flex-shrink:0" role="img"><title>${gdCommsEsc(titleText)}</title>
    <path d="${path}" fill="none" stroke="${opts.color || 'var(--accent)'}" stroke-width="2"/>
    <circle cx="${(pad + (points.length - 1) * stepX).toFixed(1)}" cy="${yAt(last.value).toFixed(1)}" r="2.5" fill="${opts.color || 'var(--accent)'}"/>
  </svg>`;
}
function gdTrendMeta(trend) {
  return { up: { icon: '▲', color: 'var(--green)', label: t('Improving') },
           down: { icon: '▼', color: 'var(--red)', label: t('Declining') },
           flat: { icon: '—', color: 'var(--muted)', label: t('Steady') } }[trend] || null;
}
function gdTrendBadge(trend) {
  const m = gdTrendMeta(trend);
  return m ? `<span style="color:${m.color};font-size:11px;font-weight:700" title="${m.label}">${m.icon}</span>` : '';
}

function gdPerfSummaryTab(c) {
  return `<div id="gd-perf-content">${gdPerfBody(c)}</div>`;
}
function gdPerfBody(c) {
  if (gdState.perf.screen === 'subject') {
    const subject = (c.subjects || []).find(s => s.name === gdState.perf.activeSubject);
    if (!subject) { gdState.perf.screen = 'list'; return gdPerfBody(c); } // stale id (e.g. after switching child) — fall back safely
    return gdPerfSubjectDetail(c, subject);
  }
  return gdPerfProgressCard(c) + gdPerfSubjectsCard(c);
}
function gdPerfProgressCard(c) {
  const points = (c.progressHistory || []).map(p => ({ label: p.period, value: p.avg }));
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Progress Over Time')}</div><span style="font-size:12px;color:var(--muted)">${t('Overall average, out of 20')}</span></div>
    <div class="card-body">${gdSvgLineChart(points, { ariaLabel: t('Overall average over time'), emptyText: t('Not enough historical data yet to show a progress trend.') })}</div></div>`;
}
function gdPerfSubjectRow(c, s) {
  const meta = gdTrendMeta(s.trend);
  const spark = gdSvgSparkline((s.history || []).map(h => ({ label: h.period, value: h.avg })));
  return `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="gdPerfOpenSubject('${gdCommsEsc(s.name)}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();gdPerfOpenSubject('${gdCommsEsc(s.name)}')}">
    <span>${gdCommsEsc(t(s.name))}</span>
    <span style="display:flex;align-items:center;gap:10px">
      ${spark}
      ${meta ? `<span style="color:${meta.color};font-size:11px;font-weight:700" title="${meta.label}">${meta.icon}</span>` : ''}
      <span style="min-width:44px;text-align:right">${s.avg}/20</span>
    </span>
  </div>`;
}
function gdPerfSubjectsCard(c) {
  return `<div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Subject Performance')}</div><span style="font-size:12px;color:var(--muted)">${t('Tap a subject for details')}</span></div>
    <div class="card-body">${(c.subjects || []).map(s => gdPerfSubjectRow(c, s)).join('') || `<div class="gd-empty-mini">${t('No subjects recorded yet.')}</div>`}</div></div>`;
}
function gdPerfOpenSubject(name) {
  gdState.perf.activeSubject = name;
  gdState.perf.screen = 'subject';
  const el = document.getElementById('gd-perf-content');
  if (el) el.innerHTML = gdPerfBody(gdGetActiveChild());
}
function gdPerfBackToList() {
  gdState.perf.screen = 'list';
  const el = document.getElementById('gd-perf-content');
  if (el) el.innerHTML = gdPerfBody(gdGetActiveChild());
}
function gdPerfSubjectDetail(c, s) {
  const meta = gdTrendMeta(s.trend);
  const relatedExams = ((c.exams && c.exams.completed) || []).filter(e => e.subject === s.name);
  const points = (s.history || []).map(h => ({ label: h.period, value: h.avg }));
  return `<div class="card">
    <div class="card-header">
      <div style="display:flex;align-items:center;gap:10px;min-width:0;flex:1">
        <button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="gdPerfBackToList()">${t('← Back')}</button>
        <div class="card-title" style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${gdCommsEsc(t(s.name))}</div>
      </div>
    </div>
    <div class="card-body">
      <div class="gd-pay-stat-row">
        <div class="stat-card"><div class="stat-label">${t('Current Average')}</div><div class="stat-val">${s.avg}/20</div><div class="stat-icon blue">📊</div></div>
        <div class="stat-card"><div class="stat-label">${t('Trend')}</div><div class="stat-val" style="font-size:15px">${meta ? `${meta.icon} ${meta.label}` : '—'}</div><div class="stat-icon ${meta && meta.icon==='▲'?'green':meta&&meta.icon==='▼'?'red':'yellow'}">📈</div></div>
        <div class="stat-card"><div class="stat-label">${t('Exams Recorded')}</div><div class="stat-val">${relatedExams.length}</div><div class="stat-icon purple">📄</div></div>
      </div>
      <div style="margin-top:6px">${gdSvgLineChart(points, { ariaLabel: `${t('Progress in')} ${s.name}`, emptyText: t('Not enough historical data yet for this subject.') })}</div>
      ${relatedExams.length ? `<div style="margin-top:14px">
        <div style="font-size:12.5px;font-weight:600;margin-bottom:8px;color:var(--muted)">${t('Recent Exam Results')}</div>
        ${relatedExams.map(e => `<div class="info-row"><span>${gdCommsEsc(t(e.title))} — ${e.date}</span><span>${e.score}/${e.max}</span></div>`).join('')}
      </div>` : ''}
    </div>
  </div>`;
}

/* ── Payments ──
   Per-child payment visibility. applicable:false means this child has no
   billing relationship (e.g. scholarship) — a fixed fact, not a fetch
   result, so it's checked before any loading simulation. When applicable,
   loading/error are simulated the same way as Calendar/Communication so
   those required states are meaningfully demonstrated rather than assumed
   away. No payment gateway/processing is implemented — visibility only. */
function gdPaymentsView(c) {
  const p = c.payments;
  if (!p || !p.applicable) return gdPayNoInfoState();
  return `<div id="gd-pay-content">${gdPayBody(c)}</div>`;
}
function gdPayNoInfoState() {
  return `<div class="gd-empty-state">
    <div class="gd-empty-state-ico"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg></div>
    <div class="gd-empty-state-title">${t('No payment information')}</div>
    <div class="gd-empty-state-sub">${t('There is no billing relationship associated with this child.')}</div>
  </div>`;
}
function gdPayBody(c) {
  if (gdState.pay.loadState === 'idle') gdPayLoad(c);
  if (gdState.pay.loadState === 'loading') return `<div class="gd-sc-load-state"><span class="gd-spinner"></span>${t('Loading payment information…')}</div>`;
  if (gdState.pay.loadState === 'error') return gdPayErrorState(c);
  if (gdState.pay.screen === 'receipt') {
    const receipt = gdPayFindReceipt(c.payments, gdState.pay.activeReceiptId);
    if (!receipt) { gdState.pay.screen = 'overview'; return gdPayBody(c); } // stale/invalid id (e.g. after switching child) — fall back safely
    return gdPayReceiptView(c.payments, receipt);
  }
  return gdPayOverviewCard(c.payments) + gdPayHistoryCard(c.payments) + gdPayReceiptsCard(c.payments);
}
function gdPayLoad(c) {
  gdState.pay.loadState = 'loading';
  setTimeout(() => {
    gdState.pay.loadState = Math.random() < 0.08 ? 'error' : 'ready';
    const el = document.getElementById('gd-pay-content');
    if (el) el.innerHTML = gdPayBody(c);
  }, 650);
}
function gdPayRetry(c) {
  gdPayLoad(c);
  const el = document.getElementById('gd-pay-content');
  if (el) el.innerHTML = gdPayBody(c);
}
function gdPayErrorState(c) {
  return `<div class="gd-empty-state">
    <div class="gd-empty-state-ico" style="background:rgba(255,69,58,0.12);color:var(--red)"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg></div>
    <div class="gd-empty-state-title">${t("Couldn't load payment information")}</div>
    <div class="gd-empty-state-sub">${t('Something went wrong while fetching billing details. Please try again.')}</div>
    <button class="st-btn ghost" onclick="gdPayRetry(gdGetActiveChild())">${t('Retry')}</button>
  </div>`;
}
function gdPayStatusLabel(status) {
  const labels = { paid: t('Paid'), due: t('Due'), overdue: t('Overdue'), partial: t('Partially Paid'), pending: t('Pending'), failed: t('Failed') };
  return labels[status] || t(status);
}
/* Days between the app's fixed demo "today" (GD_ATT_TODAY, also used by
   Attendance/Homework/Calendar) and an ISO date string. Positive = future,
   negative = past. Kept consistent with the rest of the app rather than
   using the real system clock, since all demo data is anchored to one date. */
function gdPayDaysUntil(dateStr) {
  if (!dateStr) return null;
  const target = new Date(dateStr + 'T00:00:00');
  if (isNaN(target)) return null;
  return Math.round((target - GD_ATT_TODAY) / 86400000);
}
function gdPayDueSubtext(days) {
  if (days === null) return '';
  if (days > 0) return `<div class="stat-change">${t('Due in')} ${days} ${t(days === 1 ? 'day' : 'days')}</div>`;
  if (days === 0) return `<div class="stat-change down">${t('Due today')}</div>`;
  return `<div class="stat-change down">${Math.abs(days)} ${t(Math.abs(days) === 1 ? 'day' : 'days')} ${t('overdue')}</div>`;
}
/* Surfaces the method used for the most recent paid transaction as a
   convenience — real, already-known information, not a stored "default
   payment method" feature. Omitted entirely when no paid transaction with
   a method exists, rather than showing a placeholder. */
function gdPayPreferredMethod(p) {
  const lastPaid = gdPaySortHistory(p.history).find(h => h.status === 'paid' && h.method);
  return lastPaid ? lastPaid.method : null;
}
function gdPayOverviewCard(p) {
  const statusPill = `<span class="status-pill ${p.status}">${gdPayStatusLabel(p.status)}</span>`;
  const days = p.nextDueDate ? gdPayDaysUntil(p.nextDueDate) : null;
  const dueLine = (p.status !== 'paid' && p.nextDueDate)
    ? `<div class="stat-card"><div class="stat-label">${t('Next Due Date')}</div><div class="stat-val" style="font-size:19px">${p.nextDueDate}</div>${gdPayDueSubtext(days)}<div class="stat-icon yellow">📅</div></div>`
    : `<div class="stat-card"><div class="stat-label">${t('Last Payment')}</div><div class="stat-val" style="font-size:19px">${p.lastPaymentDate || '—'}</div><div class="stat-icon blue">📅</div></div>`;
  const overdueBanner = (p.status === 'overdue')
    ? `<div class="st-inline-msg err show">⚠️ ${days !== null && days < 0 ? `${Math.abs(days)} ${t(Math.abs(days) === 1 ? 'day' : 'days')} ${t('overdue')}. ` : ''}${t('Please settle the outstanding balance as soon as possible.')}</div>`
    : '';
  const method = gdPayPreferredMethod(p);
  return `<div class="card">
    <div class="card-header"><div class="card-title">${t('Payment Overview')}</div>${statusPill}</div>
    <div class="card-body">
      ${overdueBanner}
      <div class="gd-pay-stat-row">
        <div class="stat-card"><div class="stat-label">${t('Outstanding Balance')}</div><div class="stat-val">${p.outstandingBalance} ${p.currency}</div><div class="stat-icon ${p.outstandingBalance > 0 ? 'yellow' : 'green'}">💰</div></div>
        <div class="stat-card"><div class="stat-label">${t('Paid This Year')}</div><div class="stat-val">${p.totalPaidThisYear} ${p.currency}</div><div class="stat-icon green">✅</div></div>
        ${dueLine}
      </div>
      ${method ? `<div class="info-row" style="margin-top:14px"><span>${t('Usual Payment Method')}</span><span>${t(method)}</span></div>` : ''}
    </div>
  </div>`;
}
/* Returns a NEW array (never mutates p.history), most recent first.
   Dates are stored as ISO 'YYYY-MM-DD' strings so a plain string compare
   sorts correctly without needing Date parsing. */
function gdPaySortHistory(history) {
  return (history || []).slice().sort((a, b) => (b.date || '').localeCompare(a.date || ''));
}
function gdPayFindReceipt(p, receiptId) {
  if (!receiptId || !p || !p.receipts) return null;
  return p.receipts.find(r => r.id === receiptId) || null;
}
function gdPayHistoryRow(h, p) {
  const receipt = h.receiptId ? gdPayFindReceipt(p, h.receiptId) : null;
  const action = receipt
    ? `<button type="button" class="card-action" style="background:none;border:none;font:inherit;padding:0" onclick="gdPayOpenReceipt('${receipt.id}')">${t('View Receipt')}</button>`
    : `<span style="font-size:11.5px;color:var(--muted)">${t('No receipt')}</span>`;
  return `<div class="info-row" style="align-items:flex-start">
    <span>
      <div>${h.date} — ${t(h.desc)}</div>
      ${h.method ? `<div style="font-size:11px;color:var(--muted);margin-top:2px">${t(h.method)}</div>` : ''}
    </span>
    <span style="text-align:right">
      <div>${h.amount} ${p.currency}</div>
      <div style="margin-top:4px"><span class="status-pill ${h.status}">${gdPayStatusLabel(h.status)}</span></div>
      <div style="margin-top:4px">${action}</div>
    </span>
  </div>`;
}
function gdPayHistoryCard(p) {
  const sorted = gdPaySortHistory(p.history);
  return `<div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Payment History')}</div></div>
    <div class="card-body">
      ${sorted.map(h => gdPayHistoryRow(h, p)).join('') || `<div style="color:var(--muted);font-size:12.5px">${t('No payment history yet.')}</div>`}
    </div></div>`;
}
function gdPayReceiptsCard(p) {
  const receipts = p.receipts || [];
  return `<div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Receipts')}</div></div>
    <div class="card-body">
      ${receipts.length ? receipts.slice().sort((a, b) => (b.date || '').localeCompare(a.date || '')).map(r => `
        <div class="info-row">
          <span>${r.date} — ${t(r.desc)}</span>
          <span><button type="button" class="card-action" style="background:none;border:none;font:inherit;padding:0" onclick="gdPayOpenReceipt('${r.id}')">${t('View')}</button></span>
        </div>`).join('') : `<div style="color:var(--muted);font-size:12.5px">${t('No receipts available yet.')}</div>`}
    </div></div>`;
}
function gdPayOpenReceipt(receiptId) {
  gdState.pay.activeReceiptId = receiptId;
  gdState.pay.screen = 'receipt';
  const el = document.getElementById('gd-pay-content');
  if (el) el.innerHTML = gdPayBody(gdGetActiveChild());
}
function gdPayBackToOverview() {
  gdState.pay.screen = 'overview';
  const el = document.getElementById('gd-pay-content');
  if (el) el.innerHTML = gdPayBody(gdGetActiveChild());
}
function gdPayReceiptView(p, r) {
  return `<div class="card">
    <div class="card-header">
      <div style="display:flex;align-items:center;gap:10px;min-width:0;flex:1">
        <button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="gdPayBackToOverview()">${t('← Back')}</button>
        <div class="card-title" style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${t('Receipt')} ${r.id}</div>
      </div>
    </div>
    <div class="card-body">
      <div class="info-row"><span>${t('Description')}</span><span>${t(r.desc)}</span></div>
      <div class="info-row"><span>${t('Date')}</span><span>${r.date}</span></div>
      <div class="info-row"><span>${t('Amount')}</span><span>${r.amount} ${r.currency}</span></div>
      ${r.method ? `<div class="info-row"><span>${t('Method')}</span><span>${t(r.method)}</span></div>` : ''}
      <div class="info-row"><span>${t('Receipt ID')}</span><span>${r.id}</span></div>
      <button class="st-btn ghost sm" style="margin-top:14px" onclick="window.print()">${t('Print')}</button>
    </div>
  </div>`;
}

/* ── Achievements ── */
/* ── Achievements ──
   "Recent" highlights the latest achievement; "All-Time" is the complete,
   chronologically sorted history (real dates, not fabricated). Tapping any
   badge opens a real detail screen (category + description), matching the
   list/detail pattern already used by Payments receipts and Performance
   subjects, rather than a decorative badge grid with no further context. */
function gdAchSorted(c) {
  return (c.achievements || []).slice().sort((a, b) => new Date(b.date) - new Date(a.date));
}
function gdAchievementsView(c) {
  return `<div id="gd-ach-content">${gdAchBody(c)}</div>`;
}
function gdAchBody(c) {
  const sorted = gdAchSorted(c);
  if (gdState.ach.screen === 'detail') {
    const a = sorted.find(x => x.id === gdState.ach.activeId);
    if (!a) { gdState.ach.screen = 'list'; return gdAchBody(c); } // stale id (e.g. after switching child) — fall back safely
    return gdAchDetail(a);
  }
  if (!sorted.length) {
    return `<div class="gd-empty-state">
      <div class="gd-empty-state-ico"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="5"/><path d="M8.21 13.89 7 23l5-3 5 3-1.21-9.12"/></svg></div>
      <div class="gd-empty-state-title">${t('No achievements yet')}</div>
      <div class="gd-empty-state-sub">${t('Achievements earned by this child will appear here.')}</div>
    </div>`;
  }
  const recent = sorted[0];
  const rest = sorted.slice(1);
  return `
    <div class="card"><div class="card-header"><div class="card-title">${t('Most Recent')}</div></div>
      <div class="card-body">${gdAchTile(recent, true)}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('All-Time Achievements')}</div><span style="font-size:12px;color:var(--muted)">${sorted.length} ${t(sorted.length === 1 ? 'achievement' : 'achievements')}</span></div>
      <div class="card-body"><div class="badge-grid">
        ${sorted.map(a => gdAchTile(a, false)).join('')}
      </div></div></div>`;
}
function gdAchTile(a, large) {
  return `<div class="badge-tile" style="cursor:pointer${large ? ';padding:20px' : ''}" role="button" tabindex="0" onclick="gdAchOpenDetail('${a.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();gdAchOpenDetail('${a.id}')}">
    <div class="badge-emoji"${large ? ' style="font-size:34px"' : ''}>${a.icon}</div>
    <div class="badge-name">${gdCommsEsc(t(a.title))}</div>
    <div class="badge-date">${a.date}</div>
  </div>`;
}
function gdAchOpenDetail(id) {
  gdState.ach.activeId = id;
  gdState.ach.screen = 'detail';
  const el = document.getElementById('gd-ach-content');
  if (el) el.innerHTML = gdAchBody(gdGetActiveChild());
}
function gdAchBackToList() {
  gdState.ach.screen = 'list';
  const el = document.getElementById('gd-ach-content');
  if (el) el.innerHTML = gdAchBody(gdGetActiveChild());
}
function gdAchDetail(a) {
  return `<div class="card">
    <div class="card-header">
      <div style="display:flex;align-items:center;gap:10px;min-width:0;flex:1">
        <button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="gdAchBackToList()">${t('← Back')}</button>
        <div class="card-title" style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${gdCommsEsc(t(a.title))}</div>
      </div>
    </div>
    <div class="card-body" style="text-align:center;padding:28px 20px">
      <div style="font-size:52px;line-height:1">${a.icon}</div>
      <div style="font-size:16px;font-weight:700;color:#fff;margin-top:12px">${gdCommsEsc(t(a.title))}</div>
      <div style="font-size:12px;color:var(--muted);margin-top:4px">${a.date}${a.category ? ` · ${t(a.category)}` : ''}</div>
      ${a.desc ? `<div style="font-size:13px;color:var(--muted2);line-height:1.6;margin-top:16px;max-width:340px;margin-left:auto;margin-right:auto">${gdCommsEsc(t(a.desc))}</div>` : ''}
    </div>
  </div>`;
}

/* ── Orientation ──
   Track + note are the school's own guidance (unchanged). The advanced
   sections below are additive: "strengths" are derived from the child's
   own real subject averages (not fabricated), and program suggestions are
   general, curated guidance keyed off the track — not a personalized
   admissions prediction. Both are gated behind orientation.applicable so
   a child without orientation guidance yet never sees fabricated advice. */
function gdOrientationStrengths(c) {
  return (c.subjects || []).slice().sort((a, b) => b.avg - a.avg).slice(0, 2);
}
function gdOrientationPrograms(track) {
  const t2 = (track || '').toLowerCase();
  const catalog = [
    { match: 'science', fields: ['Engineering', 'Medicine & Health Sciences', 'Computer Science', 'Applied Sciences'] },
    { match: 'literary', fields: ['Law', 'Journalism & Media', 'Languages & Translation', 'Political Science'] },
    { match: 'economics', fields: ['Business & Management', 'Economics', 'Finance', 'International Relations'] },
    { match: 'art', fields: ['Fine Arts', 'Design', 'Architecture', 'Media Production'] },
  ];
  const hit = catalog.find(c => t2.includes(c.match));
  return hit ? hit.fields : [];
}
function gdOrientationView(c) {
  const o = c.orientation;
  const base = `<div class="card"><div class="card-header"><div class="card-title">${t('Orientation & Future')}</div></div>
    <div class="card-body">
      <div class="info-row"><span>${t('Current Track')}</span><span>${t(o.track)}</span></div>
      <div style="margin-top:12px;font-size:13px;color:var(--muted2);line-height:1.6">${t(o.note)}</div>
    </div></div>`;
  if (!o.applicable) return base;

  const strengths = gdOrientationStrengths(c);
  const programs = gdOrientationPrograms(o.track);

  const strengthsCard = strengths.length ? `<div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Academic Strengths')}</div></div>
    <div class="card-body">
      ${strengths.map(s => `<div class="info-row"><span>${gdCommsEsc(t(s.name))}</span><span>${s.avg}/20</span></div>`).join('')}
    </div></div>` : '';

  const programsCard = programs.length ? `<div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Suggested Fields & Programs')}</div></div>
    <div class="card-body">
      <div class="badge-grid">
        ${programs.map(f => `<div class="badge-tile" style="cursor:default"><div class="badge-emoji">🎓</div><div class="badge-name">${t(f)}</div></div>`).join('')}
      </div>
      <div class="st-inline-msg show" style="background:rgba(255,255,255,0.04);color:var(--muted);border:1px solid var(--border);margin-top:14px">
        ${t('These are general suggestions based on the current track, meant to guide a conversation with a school counselor — not a personalized admissions prediction or guarantee.')}
      </div>
    </div></div>` : '';

  return base + strengthsCard + programsCard;
}

/* ── Reports & History ── */
function gdHistoryView(c) {
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Reports & History')}</div></div>
    <div class="card-body">
      ${c.reports.map(r => `<div class="info-row" style="align-items:flex-start;flex-direction:column;gap:4px">
        <div style="display:flex;justify-content:space-between;width:100%"><span style="font-weight:700;color:#fff">${t(r.term)}</span><span style="color:var(--muted)">${r.date}</span></div>
        <div style="font-size:12.5px;color:var(--muted2);line-height:1.5">${t(r.summary)}</div>
      </div>`).join('') || `<div style="color:var(--muted);font-size:12.5px">${t('No historical reports yet.')}</div>`}
    </div></div>`;
}

/* ── Communication Center (family/account-level — not tied to any single
   child; messages are shared across the whole Guardian account) ──
   Reads from GUARDIAN_DATA.account.conversations — the real (currently
   empty) data source — via gdGetConversations(). Loading/error handling
   mirrors the School Calendar module's gdCalLoad/gdCalRetry pattern.
   List ↔ detail navigation (select/open/return) is handled by toggling
   gdState.comms.screen within a single stable container, matching how
   other Guardian modules (e.g. calendar tabs) patch a fixed id rather than
   doing a full page navigation.

   Batch 6B adds, on top of the above without replacing any of it:
   - A Conversations / History / Support tab bar (gdCommsScreen/gdCommsTabBody)
   - Search + status filtering for Conversations, search for History
     (History = conversations whose status is 'resolved'; Conversations =
     everything else, so a guardian never confuses an old, closed thread
     with an active one)
   - A full Support request flow with its own validation/loading/error/
     retry/success states, backed by GUARDIAN_DATA.account.supportTickets
   - A Direct Call action on the conversation detail screen, shown only
     when that conversation carries a usable phone number

   Message history/composer/sending/replies/attachments are still not
   implemented — the detail screen remains identity/context (+ optional
   Call action) only. */
function gdGetConversations() {
  return (GUARDIAN_DATA.account && GUARDIAN_DATA.account.conversations) || [];
}
function gdGetConversationById(id) {
  return gdGetConversations().find(cv => String(cv.id) === String(id)) || null;
}
function gdGetSupportTickets() {
  return (GUARDIAN_DATA.account && GUARDIAN_DATA.account.supportTickets) || [];
}
function gdCommsStatusPill(status) {
  if (!status) return '';
  const knownStatus = { open: t('Open'), awaiting: t('Awaiting Reply'), resolved: t('Resolved') };
  const label = knownStatus[status] || t(status);
  return knownStatus[status]
    ? `<span class="status-pill ${status}">${label}</span>`
    : `<span class="status-pill" style="background:rgba(142,142,147,0.14);color:var(--muted)">${label}</span>`;
}
/* Escapes text reflected back into an HTML attribute or text node (search
   boxes, ticket descriptions) so free-typed user input can never break the
   surrounding markup. */
function gdCommsEsc(str) {
  return String(str == null ? '' : str).replace(/[&<>"']/g, ch => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[ch]));
}
function gdCommsEmptyState(title, sub, iconSvg) {
  return `<div class="gd-empty-state">
    <div class="gd-empty-state-ico">${iconSvg || '<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>'}</div>
    <div class="gd-empty-state-title">${title}</div>
    <div class="gd-empty-state-sub">${sub}</div>
  </div>`;
}

function gdMessagesView() {
  return `<div id="gd-comm-screen">${gdCommsScreen()}</div>`;
}
/* Top-level screen: either the open-conversation detail screen, or the
   tabbed Conversations/History/Support view. The tab bar itself is only
   shown for the latter, matching how the rest of the app keeps a detail
   view free of unrelated chrome. */
function gdCommsScreen() {
  if (gdState.comms.screen === 'detail') return gdCommsDetailScreen();
  const tabs = [
    { id: 'conversations', label: 'Conversations' },
    { id: 'history', label: 'History' },
    { id: 'support', label: 'Support' }
  ];
  return `<div class="st-tabs">${tabs.map(tb => `<div class="st-tab gd-tab-comm${tb.id === gdState.comms.activeTab ? ' active' : ''}" data-tab="${tb.id}" onclick="gdSetCommsTab('${tb.id}')">${t(tb.label)}</div>`).join('')}</div>
  <div id="gd-comm-tabbody">${gdCommsTabBody()}</div>`;
}
function gdSetCommsTab(tabId) {
  gdState.comms.activeTab = tabId;
  document.querySelectorAll('.gd-tab-comm').forEach(el => el.classList.toggle('active', el.dataset.tab === tabId));
  const el = document.getElementById('gd-comm-tabbody');
  if (el) el.innerHTML = gdCommsTabBody();
}
function gdCommsTabBody() {
  if (gdState.comms.activeTab === 'history') return gdCommsHistoryTab();
  if (gdState.comms.activeTab === 'support') return gdCommsSupportTab();
  return gdCommsConversationsTab();
}

/* Conversations + History share one fetch (both read the same
   GUARDIAN_DATA.account.conversations) and one idle/loading/error/ready
   cycle, so loading it once covers both tabs; each tab then filters the
   same resolved data differently. */
function gdCommsLoad() {
  gdState.comms.loadState = 'loading';
  setTimeout(() => {
    gdState.comms.loadState = Math.random() < 0.08 ? 'error' : 'ready';
    if (gdState.comms.activeTab === 'conversations' || gdState.comms.activeTab === 'history') {
      const el = document.getElementById('gd-comm-tabbody');
      if (el) el.innerHTML = gdCommsTabBody();
    }
  }, 650);
}
function gdCommsRetry() {
  gdCommsLoad();
  const el = document.getElementById('gd-comm-tabbody');
  if (el) el.innerHTML = gdCommsTabBody();
}
function gdCommsLoadingState() {
  return `<div class="gd-sc-load-state"><span class="gd-spinner"></span>${t('Loading conversations…')}</div>`;
}
function gdCommsErrorState() {
  return `<div class="gd-empty-state">
    <div class="gd-empty-state-ico" style="background:rgba(255,69,58,0.12);color:var(--red)"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg></div>
    <div class="gd-empty-state-title">${t("Couldn't load your conversations")}</div>
    <div class="gd-empty-state-sub">${t('Something went wrong while fetching Communication. Please try again.')}</div>
    <button class="st-btn ghost" onclick="gdCommsRetry()">${t('Retry')}</button>
  </div>`;
}
function gdCommsCardWrap(title, bodyHtml) {
  return `<div class="card">
    <div class="card-header"><div class="card-title">${title}</div></div>
    <div class="card-body" style="padding:0">${bodyHtml}</div>
  </div>`;
}

/* A conversation counts as "active" (shown in Conversations) unless it has
   been marked resolved, in which case it belongs in History instead — this
   is the one rule that keeps old and current communication from mixing. */
function gdCommsActiveConversations() {
  return gdGetConversations().filter(cv => cv.status !== 'resolved');
}
function gdCommsResolvedConversations() {
  return gdGetConversations().filter(cv => cv.status === 'resolved');
}
function gdCommsMatchesQuery(cv, q) {
  return [cv.name, cv.context, cv.preview].some(f => (f || '').toLowerCase().includes(q));
}

/* ── Conversations tab: search + status filter over the active set ── */
function gdCommsConversationsTab() {
  if (gdState.comms.loadState === 'idle') gdCommsLoad();
  if (gdState.comms.loadState === 'loading') return gdCommsCardWrap(t('Conversations'), gdCommsLoadingState());
  if (gdState.comms.loadState === 'error') return gdCommsCardWrap(t('Conversations'), gdCommsErrorState());
  const filters = [['all', 'All'], ['unread', 'Unread'], ['open', 'Open'], ['awaiting', 'Awaiting Reply']];
  return `<div class="card">
    <div class="card-header"><div class="card-title">${t('Conversations')}</div></div>
    <div class="card-body" style="padding:0">
      <div class="gd-comm-toolbar">
        <input id="gd-conv-search-input" type="text" class="gd-comm-search-input" placeholder="${t('Search conversations…')}" value="${gdCommsEsc(gdState.comms.convSearch)}" oninput="gdCommsSetConvSearch(this.value)" aria-label="${t('Search conversations')}">
        <div class="gd-comm-filter-row">${filters.map(([id, label]) => `<button type="button" class="gd-comm-filter-chip${gdState.comms.convFilter === id ? ' active' : ''}" onclick="gdCommsSetConvFilter('${id}')">${t(label)}</button>`).join('')}</div>
      </div>
      <div id="gd-conv-results">${gdCommsRenderConvResults()}</div>
    </div>
  </div>`;
}
function gdCommsRenderConvResults() {
  const all = gdCommsActiveConversations();
  let list = all;
  const f = gdState.comms.convFilter;
  if (f === 'unread') list = list.filter(cv => cv.unread);
  else if (f === 'open') list = list.filter(cv => cv.status === 'open');
  else if (f === 'awaiting') list = list.filter(cv => cv.status === 'awaiting');
  const q = gdState.comms.convSearch.trim().toLowerCase();
  if (q) list = list.filter(cv => gdCommsMatchesQuery(cv, q));
  if (!all.length) return gdCommsEmptyState(t('No active conversations'), t('Messages between you and the school will appear here, shared across your whole Guardian account and not tied to a single child.'));
  if (!list.length) return gdCommsEmptyState(t('No matching conversations'), t('Nothing matches your current search or filter. Try adjusting them.'));
  return gdConversationList(list);
}
function gdCommsSetConvSearch(val) {
  gdState.comms.convSearch = val;
  const el = document.getElementById('gd-conv-results');
  if (el) el.innerHTML = gdCommsRenderConvResults();
}
function gdCommsSetConvFilter(id) {
  gdState.comms.convFilter = id;
  const el = document.getElementById('gd-comm-tabbody');
  if (el) el.innerHTML = gdCommsTabBody();
}

/* ── History tab: resolved conversations only, with their own search ── */
function gdCommsHistoryTab() {
  if (gdState.comms.loadState === 'idle') gdCommsLoad();
  if (gdState.comms.loadState === 'loading') return gdCommsCardWrap(t('Communication History'), gdCommsLoadingState());
  if (gdState.comms.loadState === 'error') return gdCommsCardWrap(t('Communication History'), gdCommsErrorState());
  return `<div class="card">
    <div class="card-header"><div class="card-title">${t('Communication History')}</div></div>
    <div class="card-body" style="padding:0">
      <div class="gd-comm-toolbar">
        <input id="gd-history-search-input" type="text" class="gd-comm-search-input" placeholder="${t('Search history…')}" value="${gdCommsEsc(gdState.comms.historySearch)}" oninput="gdCommsSetHistorySearch(this.value)" aria-label="${t('Search communication history')}">
      </div>
      <div id="gd-history-results">${gdCommsRenderHistoryResults()}</div>
    </div>
  </div>`;
}
function gdCommsRenderHistoryResults() {
  const resolved = gdCommsResolvedConversations();
  let list = resolved;
  const q = gdState.comms.historySearch.trim().toLowerCase();
  if (q) list = list.filter(cv => gdCommsMatchesQuery(cv, q));
  if (!resolved.length) return gdCommsEmptyState(t('No communication history yet'), t('Conversations are moved here once they are marked resolved, so you can review past communication without mixing it up with what is still active.'));
  if (!list.length) return gdCommsEmptyState(t('No matching history'), t('No past conversations match your search.'));
  return gdConversationList(list);
}
function gdCommsSetHistorySearch(val) {
  gdState.comms.historySearch = val;
  const el = document.getElementById('gd-history-results');
  if (el) el.innerHTML = gdCommsRenderHistoryResults();
}

/* ── Support: request list + full submit flow ──
   list → form → submitting → (error → back to form, nothing is lost) →
   success. A ticket is only ever added to GUARDIAN_DATA.account.supportTickets
   after a *successful* simulated submission — a failed attempt never shows
   as sent and never gets silently upgraded to a fake success. */
function gdCommsSupportTab() {
  const s = gdState.comms.support;
  if (s.view === 'success') return gdCommsSupportSuccess();
  if (s.view === 'form' || s.view === 'submitting' || s.view === 'error') return gdCommsSupportForm();
  return gdCommsSupportList();
}
function gdCommsSupportList() {
  const tickets = gdGetSupportTickets();
  return `<div class="card">
    <div class="card-header"><div class="card-title">${t('Support')}</div><div class="card-action" onclick="gdSupportOpenForm()">+ ${t('New Request')}</div></div>
    <div class="card-body" style="padding:0">
      ${tickets.length ? gdCommsSupportTicketList(tickets) : gdCommsEmptyState(t('No support requests yet'), t('Requests you send to Authren support will appear here so you can track what you have asked about.'))}
    </div>
  </div>`;
}
function gdCommsSupportTicketList(tickets) {
  return `<div class="gd-conv-list">${tickets.map(tk => `
    <div class="gd-conv-item static">
      <div class="gd-conv-avatar" style="background:var(--surface3)">🎫</div>
      <div class="gd-conv-main">
        <div class="gd-conv-top">
          <span class="gd-conv-name">${t(tk.category)}</span>
          <span class="gd-conv-time">${tk.submittedAt || ''}</span>
        </div>
        <div class="gd-conv-bottom">
          <span class="gd-conv-preview">${gdCommsEsc(tk.description)}</span>
          <span class="status-pill" style="background:rgba(10,132,255,0.14);color:var(--accent)">${t('Submitted')}</span>
        </div>
      </div>
    </div>`).join('')}</div>`;
}
function gdSupportOpenForm() {
  gdState.comms.support = { view: 'form', category: '', description: '', errors: {}, lastSubmitError: '' };
  gdSupportRerender();
}
function gdSupportCancel() {
  gdState.comms.support.view = 'list';
  gdSupportRerender();
}
function gdSupportBackToList() {
  gdState.comms.support.view = 'list';
  gdSupportRerender();
}
function gdSupportRerender() {
  const el = document.getElementById('gd-comm-tabbody');
  if (el) el.innerHTML = gdCommsTabBody();
}
const GD_SUPPORT_CATEGORIES = ['General Inquiry', 'Technical Issue', 'Billing Question', 'Student-Related', 'Other'];
function gdCommsSupportForm() {
  const s = gdState.comms.support;
  const submitting = s.view === 'submitting';
  return `<div class="card">
    <div class="card-header"><div class="card-title">${t('New Support Request')}</div><div class="card-action" onclick="gdSupportCancel()">${t('← Back')}</div></div>
    <div class="card-body">
      <div class="st-field">
        <label>${t('Category')}</label>
        <select id="gd-sup-category" ${submitting ? 'disabled' : ''}>
          <option value="">${t('Select a category…')}</option>
          ${GD_SUPPORT_CATEGORIES.map(c => `<option value="${c}" ${s.category === c ? 'selected' : ''}>${t(c)}</option>`).join('')}
        </select>
        ${s.errors.category ? `<div style="font-size:11px;color:var(--red);margin-top:5px">${s.errors.category}</div>` : ''}
      </div>
      <div class="st-field">
        <label>${t('Describe your issue or request')}</label>
        <textarea id="gd-sup-desc" rows="4" placeholder="${t('Tell us what you need help with…')}" ${submitting ? 'disabled' : ''}>${gdCommsEsc(s.description)}</textarea>
        ${s.errors.description ? `<div style="font-size:11px;color:var(--red);margin-top:5px">${s.errors.description}</div>` : ''}
      </div>
      ${s.view === 'error' ? `<div class="st-inline-msg err show">${s.lastSubmitError}</div>` : ''}
      <button type="button" class="st-btn" onclick="gdSupportSubmit()" ${submitting ? 'disabled' : ''}>${submitting ? `<span class="gd-spinner"></span>${t('Submitting…')}` : (s.view === 'error' ? t('Try Again') : t('Submit Request'))}</button>
    </div>
  </div>`;
}
function gdCommsSupportSuccess() {
  return `<div class="card"><div class="card-body" style="text-align:center;padding:36px 20px">
    <div style="font-size:34px;margin-bottom:10px">✅</div>
    <div style="font-weight:700;font-size:15px;margin-bottom:6px">${t('Your request has been submitted.')}</div>
    <div style="font-size:12.5px;color:var(--muted);margin-bottom:18px">${t('Our support team will review it and get back to you.')}</div>
    <button type="button" class="st-btn ghost sm" onclick="gdSupportBackToList()">${t('View My Requests')}</button>
  </div></div>`;
}
function gdSupportSubmit() {
  const s = gdState.comms.support;
  const catEl = document.getElementById('gd-sup-category');
  const descEl = document.getElementById('gd-sup-desc');
  const category = catEl ? catEl.value : s.category;
  const description = descEl ? descEl.value.trim() : s.description.trim();
  s.category = category;
  s.description = description;
  const errors = {};
  if (!category) errors.category = t('Please select a category.');
  if (!description) errors.description = t('Please describe your issue or request.');
  else if (description.length < 10) errors.description = t('Please add a few more details (at least 10 characters).');
  s.errors = errors;
  if (Object.keys(errors).length) { gdSupportRerender(); return; }
  s.view = 'submitting';
  s.lastSubmitError = '';
  gdSupportRerender();
  setTimeout(() => {
    if (Math.random() < 0.1) {
      s.view = 'error';
      s.lastSubmitError = t("Couldn't submit your request. Please check your connection and try again.");
      gdSupportRerender();
      return;
    }
    GUARDIAN_DATA.account.supportTickets.unshift({
      id: 'sup-' + Date.now(),
      category: s.category,
      description: s.description,
      submittedAt: t('Just now')
    });
    s.view = 'success';
    gdSupportRerender();
  }, 800);
}

/* Selection + open/return flow (6A.14–6A.16, unchanged). Selecting a
   conversation opens its identity/context-only detail screen; the
   selected id persists in state so returning to the list shows which
   conversation was last open (existing .selected active-state treatment),
   and each click looks up its own conversation strictly by id so the
   correct context always follows the correct item. Because activeTab is
   never touched while the detail screen is open, returning goes back to
   whichever tab (Conversations or History) the guardian opened it from. */
function gdSelectConversation(id) {
  if (!gdGetConversationById(id)) return;
  gdState.comms.activeConversationId = id;
  gdState.comms.screen = 'detail';
  const wrap = document.getElementById('gd-comm-screen');
  if (wrap) wrap.innerHTML = gdCommsScreen();
}
function gdCommsBackToList() {
  gdState.comms.screen = 'list';
  const wrap = document.getElementById('gd-comm-screen');
  if (wrap) wrap.innerHTML = gdCommsScreen();
}
/* Direct Call (Batch 6B): a plain tel: link so the device's own dialer
   handles the call — Authren never simulates a call happening in-app.
   Renders nothing when the conversation has no phone on file (missing),
   and a short note instead of a broken link when the value on file
   doesn't look like a usable number (invalid/unavailable). */
function gdCommsCallAction(phone) {
  if (!phone) return '';
  const cleaned = String(phone).trim();
  const phoneRegex = /^[+]?[\d][\d\s().-]{6,18}\d$/;
  if (!phoneRegex.test(cleaned)) {
    return `<div style="font-size:11px;color:var(--muted);margin-top:10px">${t('The phone number on file for this contact looks invalid, so calling is unavailable.')}</div>`;
  }
  const dial = cleaned.replace(/[^\d+]/g, '');
  return `<a href="tel:${dial}" class="st-btn ghost sm" style="margin-top:10px;display:inline-flex;align-items:center;gap:6px;text-decoration:none" aria-label="${t('Call')} ${cleaned}">📞 ${t('Call')} ${gdCommsEsc(cleaned)}</a>`;
}
function gdCommsDetailScreen() {
  const cv = gdGetConversationById(gdState.comms.activeConversationId);
  if (!cv) { gdState.comms.screen = 'list'; return gdCommsScreen(); }
  const initials = (cv.initials || (cv.name || '').trim().split(/\s+/).map(w => w[0]).slice(0, 2).join('') || '?').toUpperCase();
  return `<div class="card">
    <div class="card-header">
      <div style="display:flex;align-items:center;gap:10px;min-width:0;flex:1">
        <button type="button" class="st-btn ghost sm gd-comm-back-btn" style="flex-shrink:0" onclick="gdCommsBackToList()" aria-label="${t('Back to conversations')}">${t('← Back')}</button>
        <div class="card-title" style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${cv.name || ''}</div>
      </div>
    </div>
    <div class="card-body">
      <div style="display:flex;align-items:center;gap:14px;padding-bottom:14px;margin-bottom:14px;border-bottom:0.5px solid var(--separator)">
        <div class="gd-conv-avatar gd-conv-avatar-lg" style="flex-shrink:0;background:${cv.color || 'var(--surface3)'}">${initials}</div>
        <div style="min-width:0;flex:1">
          <div style="font-size:15px;font-weight:700;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${cv.name || ''}</div>
          ${cv.context ? `<div style="font-size:12px;color:var(--muted);margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${t(cv.context)}</div>` : ''}
        </div>
        <div style="flex-shrink:0">${gdCommsStatusPill(cv.status)}</div>
      </div>
      <div class="gd-empty-mini">${t('Messaging for this conversation is not available yet.')}</div>
      ${gdCommsCallAction(cv.phone)}
    </div>
  </div>`;
}

/* Renders the conversation-list container for a given array of conversation
   summaries, or the polished empty state when there are none. Every field
   besides name is optional and rendered only when present — nothing is
   fabricated to fill a gap. Items are rendered in the order given, with no
   invented sorting/filtering. Shared by the Conversations tab, the History
   tab, and (defensively) any other future caller — one list renderer, one
   set of row markup, never duplicated. */
function gdConversationList(conversations) {
  if (!conversations || !conversations.length) {
    return gdCommsEmptyState(t('No conversations yet'), t('Messages between you and the school will appear here, shared across your whole Guardian account and not tied to a single child.'));
  }
  return `<div class="gd-conv-list">${conversations.map(gdConversationItemRow).join('')}</div>`;
}

/* Single conversation row. Defensive against missing optional fields
   (context, preview, time, status, unread) so a partially-populated
   record never breaks layout; only `name` is assumed present. Clicking or
   activating a row (Enter/Space, matching the app's established
   interactive-row pattern) opens that conversation's detail screen; the
   row reflects .selected when it is the currently open/last-open one. */
function gdConversationItemRow(cv) {
  const unread = !!cv.unread;
  const selected = String(gdState.comms.activeConversationId) === String(cv.id) && gdState.comms.activeConversationId != null;
  const initials = (cv.initials || (cv.name || '').trim().split(/\s+/).map(w => w[0]).slice(0, 2).join('') || '?').toUpperCase();
  const statusPill = gdCommsStatusPill(cv.status);
  const bottomRow = (cv.preview || statusPill)
    ? `<div class="gd-conv-bottom">
        ${cv.preview ? `<span class="gd-conv-preview">${t(cv.preview)}</span>` : '<span></span>'}
        ${statusPill}
      </div>`
    : '';
  return `<div class="gd-conv-item${unread ? ' unread' : ''}${selected ? ' selected' : ''}" role="button" tabindex="0"
    onclick="gdSelectConversation('${cv.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();gdSelectConversation('${cv.id}')}"
    aria-label="${unread ? t('Unread conversation with') : t('Conversation with')} ${cv.name || ''}">
    <div class="gd-conv-avatar" style="background:${cv.color || 'var(--surface3)'}">${initials}</div>
    <div class="gd-conv-main">
      <div class="gd-conv-top">
        <span class="gd-conv-name">${cv.name || ''}</span>
        ${cv.time ? `<span class="gd-conv-time">${cv.time}</span>` : ''}
      </div>
      ${cv.context ? `<div class="gd-conv-context">${t(cv.context)}</div>` : ''}
      ${bottomRow}
    </div>
    ${unread ? '<div class="gd-conv-unread-dot" aria-hidden="true"></div>' : ''}
  </div>`;
}

/* ── Tabs ── */
function gdAccount() {
  const tabs = [ {id:'profile', label:'Profile'}, {id:'security', label:'Account & Security'} ];
  return `<div class="st-tabs">${tabs.map(tb=>`<div class="st-tab gd-tab${tb.id===gdState.tab.account?' active':''}" data-tab="${tb.id}" onclick="gdSetTab('${tb.id}')">${t(tb.label)}</div>`).join('')}</div><div id="gd-body-account">${gdAccountBody(gdState.tab.account)}</div>`;
}
function gdSetTab(tabId) {
  gdState.tab.account = tabId;
  document.querySelectorAll('.gd-tab').forEach(el => el.classList.toggle('active', el.dataset.tab === tabId));
  const body = document.getElementById('gd-body-account');
  if (body) body.innerHTML = gdAccountBody(tabId);
}

function gdAccountBody(tab) {
  const a = GUARDIAN_DATA.account;

  if (tab === 'profile') return `
    <div class="card"><div class="card-body" style="display:flex;gap:18px;align-items:center;flex-wrap:wrap">
      <div style="width:64px;height:64px;border-radius:18px;background:linear-gradient(180deg,rgba(34,197,94,0.3),rgba(34,197,94,0.12));display:flex;align-items:center;justify-content:center;font-weight:800;font-size:20px">${gdInitials(a.name)}</div>
      <div><div style="font-size:17px;font-weight:800">${a.name}</div><div style="font-size:12.5px;color:var(--muted);margin-top:2px">${t('Guardian')} · ${t(a.relation)} · ${a.guardianId}</div></div>
    </div></div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Guardian Information')}</div></div>
      <div class="card-body">
        <div class="info-row"><span>${t('Full Name')}</span><span>${a.name}</span></div>
        <div class="info-row">
          <span>${t('Authren Guardian ID')}</span>
          <span style="display:flex;align-items:center;gap:8px">
            <span>${a.guardianId}</span>
            <button type="button" class="st-btn ghost sm" id="gd-copy-btn" onclick="gdCopyGuardianId()">${t('Copy')}</button>
          </span>
        </div>
        <div class="info-row"><span>${t('Email')}</span><span>${a.email}</span></div>
        <div class="info-row" id="gd-phone-row">${gdPhoneViewRow()}</div>
      </div></div>

    <div class="account-tile" style="margin-top:16px" onclick="gdSetTab('security')">
      <div class="account-tile-ico">🔐</div>
      <div class="account-tile-text"><div class="account-tile-title">${t('Account & Security')}</div><div class="account-tile-sub">${t('Manage your password, email and phone number')}</div></div>
    </div>`;

  if (tab === 'security') return `
    <div class="st-grid-2">
      <div class="card"><div class="card-header"><div class="card-title">📱 ${t('Phone Number')}</div></div>
        <div class="card-body">
          <div style="font-size:11.5px;color:var(--muted);margin-bottom:10px">${t('Make sure this number is current — the school uses it to reach you.')}</div>
          <div class="info-row" id="gd-phone-row-sec">${gdPhoneViewRow()}</div>
        </div></div>
      <div class="card"><div class="card-header"><div class="card-title">✉️ ${t('Email Management')}</div></div>
        <div class="card-body" id="gd-email-card-body">${gdEmailCardBody()}</div></div>
    </div>

    <div class="st-grid-2" style="margin-top:16px">
      <div class="card"><div class="card-header"><div class="card-title">🔑 ${t('Password Management')}</div></div>
        <div class="card-body">
          <div class="st-field"><label>${t('Current Password')}</label>
            <div class="pass-input-wrap"><input type="password" id="gd-pw-cur" style="padding-right:40px">
              <button type="button" class="toggle-pass-btn" onclick="togglePasswordVisibility('gd-pw-cur', this)" aria-label="Toggle password visibility">${EYE_CLOSED_SVG}</button>
            </div></div>
          <div class="st-field"><label>${t('New Password')}</label>
            <div class="pass-input-wrap"><input type="password" id="gd-pw-new" oninput="gdCheckPwStrength()" style="padding-right:40px">
              <button type="button" class="toggle-pass-btn" onclick="togglePasswordVisibility('gd-pw-new', this)" aria-label="Toggle password visibility">${EYE_CLOSED_SVG}</button>
            </div></div>
          <div id="gd-pw-hint" style="font-size:11px;color:var(--muted);margin:-6px 0 12px">${t('Minimum 6 characters, with at least 1 letter and 1 number.')}</div>
          <div class="st-field"><label>${t('Confirm New Password')}</label>
            <div class="pass-input-wrap"><input type="password" id="gd-pw-confirm" style="padding-right:40px">
              <button type="button" class="toggle-pass-btn" onclick="togglePasswordVisibility('gd-pw-confirm', this)" aria-label="Toggle password visibility">${EYE_CLOSED_SVG}</button>
            </div></div>
          <button class="st-btn" id="gd-pw-submit" onclick="gdChangePassword()">${t('Update Password')}</button>
          <div class="st-inline-msg ok" id="gd-pw-msg-ok">${t('Password updated successfully.')}</div>
          <div class="st-inline-msg err" id="gd-pw-msg-err"></div>
        </div></div>

      <div class="card"><div class="card-header"><div class="card-title">🛟 ${t('Password Recovery')}</div></div>
        <div class="card-body">
          <div style="font-size:12.5px;color:var(--muted);margin-bottom:12px">${t('Forgot your password? Start the guided recovery process to reset it securely.')}</div>
          <button class="st-btn ghost" onclick="gdOpenPasswordRecovery()">${t('Start Password Recovery')}</button>
        </div></div>
    </div>`;

  return '';
}

/* ── Copy Guardian ID ── */
function gdCopyGuardianId() {
  const id = GUARDIAN_DATA.account.guardianId;
  const btn = document.getElementById('gd-copy-btn');
  const confirm = () => {
    if (!btn) return;
    btn.textContent = '✓ ' + t('Copied');
    btn.classList.add('gd-copied');
    setTimeout(() => { if (btn) { btn.textContent = t('Copy'); btn.classList.remove('gd-copied'); } }, 1800);
  };
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(id).then(confirm).catch(confirm);
  } else { confirm(); }
}

/* ── Phone Number: view / edit / save / cancel ── */
function gdPhoneViewRow() {
  const a = GUARDIAN_DATA.account;
  const s = gdState.phone;
  if (!s.editing) {
    return `<span>${t('Phone Number')}</span>
      <span style="display:flex;align-items:center;gap:8px">
        ${s.success ? `<span style="color:var(--green);font-size:11px">✓ ${t('Updated')}</span>` : ''}
        <span>${a.phone}</span>
        <button type="button" class="st-btn ghost sm" onclick="gdEditPhone()">${t('Edit')}</button>
      </span>`;
  }
  return `<div class="gd-edit-row">
      <input id="gd-phone-input" type="tel" inputmode="tel" value="${s.draft}" placeholder="${t('e.g. +212 6XX-XXXXXX')}" ${s.saving?'disabled':''}>
      <button type="button" class="st-btn sm" onclick="gdSavePhone()" ${s.saving?'disabled':''}>${s.saving?`<span class="gd-spinner"></span>${t('Saving...')}`:t('Save')}</button>
      <button type="button" class="st-btn ghost sm" onclick="gdCancelPhoneEdit()" ${s.saving?'disabled':''}>${t('Cancel')}</button>
    </div>
    ${s.error?`<div class="st-inline-msg err show" style="margin-top:8px;width:100%">${s.error}</div>`:''}`;
}
function gdRefreshPhoneRow() {
  const html = gdPhoneViewRow();
  const row1 = document.getElementById('gd-phone-row'); if (row1) row1.innerHTML = html;
  const row2 = document.getElementById('gd-phone-row-sec'); if (row2) row2.innerHTML = html;
}
function gdEditPhone() {
  gdState.phone = { editing:true, saving:false, error:'', success:false, draft: GUARDIAN_DATA.account.phone };
  gdRefreshPhoneRow();
}
function gdCancelPhoneEdit() {
  gdState.phone = { editing:false, saving:false, error:'', success:false, draft:'' };
  gdRefreshPhoneRow();
}
function gdSavePhone() {
  const input = document.getElementById('gd-phone-input');
  const val = input ? input.value.trim() : '';
  const s = gdState.phone;
  s.error = '';
  const phoneRegex = /^[+]?[\d][\d\s().-]{6,18}\d$/;
  if (!val) { s.error = t('Please enter a phone number.'); s.draft = val; gdRefreshPhoneRow(); return; }
  if (!phoneRegex.test(val)) { s.error = t('Enter a valid phone number.'); s.draft = val; gdRefreshPhoneRow(); return; }
  s.draft = val;
  s.saving = true;
  gdRefreshPhoneRow();
  setTimeout(() => {
    GUARDIAN_DATA.account.phone = val;
    s.saving = false;
    s.editing = false;
    s.success = true;
    gdRefreshPhoneRow();
    setTimeout(() => { s.success = false; }, 3000);
  }, 800);
}

/* ── Password change ── */
function gdCheckPwStrength() {
  const v = document.getElementById('gd-pw-new').value;
  const hint = document.getElementById('gd-pw-hint');
  if (!hint) return;
  const ok = v.length>=6 && /[a-zA-Z]/.test(v) && /[0-9]/.test(v);
  hint.style.color = v.length===0 ? 'var(--muted)' : ok ? 'var(--green)' : 'var(--red)';
}
function gdPasswordMessage(type, msg) {
  const okBox = document.getElementById('gd-pw-msg-ok');
  const errBox = document.getElementById('gd-pw-msg-err');
  if (!okBox || !errBox) return;
  okBox.classList.remove('show'); errBox.classList.remove('show');
  if (type === 'ok') okBox.classList.add('show');
  else if (type === 'err') { errBox.textContent = msg; errBox.classList.add('show'); }
}
function gdSetPasswordSaving(v) {
  gdState.password.saving = v;
  const btn = document.getElementById('gd-pw-submit');
  if (btn) { btn.disabled = v; btn.innerHTML = v ? `<span class="gd-spinner"></span>${t('Updating...')}` : t('Update Password'); }
  ['gd-pw-cur','gd-pw-new','gd-pw-confirm'].forEach(id => { const el = document.getElementById(id); if (el) el.disabled = v; });
}
function gdChangePassword() {
  const cur = document.getElementById('gd-pw-cur').value;
  const nw = document.getElementById('gd-pw-new').value;
  const cf = document.getElementById('gd-pw-confirm').value;
  if (!cur) return gdPasswordMessage('err', t('Please enter your current password.'));
  if (cur !== GUARDIAN_DATA.account.password) return gdPasswordMessage('err', t('Current password is incorrect.'));
  if (!nw || !cf) return gdPasswordMessage('err', t('Please fill in both new password fields.'));
  const errs = validatePassword(nw);
  if (errs.length) return gdPasswordMessage('err', errs.join(' '));
  if (nw === cur) return gdPasswordMessage('err', t('New password must be different from your current password.'));
  if (nw !== cf) return gdPasswordMessage('err', t('Passwords do not match.'));

  gdPasswordMessage('', '');
  gdSetPasswordSaving(true);
  setTimeout(() => {
    GUARDIAN_DATA.account.password = nw;
    gdSetPasswordSaving(false);
    document.getElementById('gd-pw-cur').value = '';
    document.getElementById('gd-pw-new').value = '';
    document.getElementById('gd-pw-confirm').value = '';
    const hint = document.getElementById('gd-pw-hint'); if (hint) hint.style.color = 'var(--muted)';
    gdPasswordMessage('ok', '');
  }, 900);
}

/* ── Email change verification ── */
function gdEmailCardBody() {
  const a = GUARDIAN_DATA.account;
  const e = gdState.email;
  let html = `<div class="info-row"><span>${t('Current Email')}</span><span id="gd-email-current">${a.email}</span></div>`;

  if (e.step === 'idle') {
    html += `
      <div class="st-field" style="margin-top:12px"><label>${t('New Email')}</label>
        <input type="email" id="gd-email-new" placeholder="${t('name@example.com')}">
      </div>
      <button class="st-btn ghost" onclick="gdRequestEmailChange()" ${e.sending?'disabled':''}>${e.sending?`<span class="gd-spinner"></span>${t('Sending code...')}`:t('Send Verification Code')}</button>`;
  } else if (e.step === 'otp') {
    const remaining = Math.max(0, Math.ceil((e.expiry - Date.now())/1000));
    html += `
      <div class="st-inline-msg ok show" style="margin-top:12px">${t('Verification code sent to')} ${e.newEmail}.</div>
      <div class="st-field" style="margin-top:8px"><label>${t('Verification Code')}</label>
        <input id="gd-email-otp" placeholder="000000" maxlength="6" inputmode="numeric" ${e.verifying?'disabled':''}></div>
      <div id="gd-email-otp-timer" style="font-size:11px;color:var(--muted);margin:-6px 0 12px">${remaining>0 ? t('Code expires in')+' '+remaining+'s' : t('Code expired. Please resend.')}</div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <button class="st-btn" onclick="gdVerifyEmailOtp()" ${e.verifying?'disabled':''}>${e.verifying?`<span class="gd-spinner"></span>${t('Verifying...')}`:t('Verify & Update Email')}</button>
        <button class="st-btn ghost" id="gd-email-resend" onclick="gdResendEmailOtp()" ${e.cooldown>0?'disabled':''}>${e.cooldown>0? t('Resend in')+' '+e.cooldown+'s' : t('Resend Code')}</button>
        <button class="st-btn ghost" onclick="gdCancelEmailChange()">${t('Cancel')}</button>
      </div>`;
  } else if (e.step === 'done') {
    html += `<div class="st-inline-msg ok show" style="margin-top:12px">${t('Email address updated successfully.')}</div>
      <button class="st-btn ghost sm" style="margin-top:8px" onclick="gdCancelEmailChange()">${t('Change Email Again')}</button>`;
  }

  html += `<div class="st-inline-msg err${e.error?' show':''}" style="margin-top:10px">${e.error||''}</div>`;
  return html;
}
function gdRenderEmailCard() {
  const el = document.getElementById('gd-email-card-body');
  if (el) el.innerHTML = gdEmailCardBody();
  if (gdState.email.step === 'otp') gdStartEmailOtpTimer();
}
function gdStartEmailOtpTimer() {
  clearInterval(gdState.email._interval);
  gdState.email._interval = setInterval(() => {
    const e = gdState.email;
    const timerEl = document.getElementById('gd-email-otp-timer');
    const remaining = Math.max(0, Math.ceil((e.expiry - Date.now())/1000));
    if (timerEl) timerEl.textContent = remaining>0 ? (t('Code expires in')+' '+remaining+'s') : t('Code expired. Please resend.');
    if (e.cooldown > 0) {
      e.cooldown -= 1;
      const btn = document.getElementById('gd-email-resend');
      if (btn) {
        if (e.cooldown > 0) { btn.disabled = true; btn.textContent = t('Resend in')+' '+e.cooldown+'s'; }
        else { btn.disabled = false; btn.textContent = t('Resend Code'); }
      }
    }
    if (remaining<=0 && e.cooldown<=0) clearInterval(e._interval);
  }, 1000);
}
function gdRequestEmailChange() {
  const input = document.getElementById('gd-email-new');
  const val = input ? input.value.trim() : '';
  const e = gdState.email;
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  e.error = '';
  if (!val) { e.error = t('Please enter a new email address.'); gdRenderEmailCard(); return; }
  if (!emailRegex.test(val)) { e.error = t('Enter a valid email address.'); gdRenderEmailCard(); return; }
  if (val.toLowerCase() === GUARDIAN_DATA.account.email.toLowerCase()) { e.error = t('This is already your current email address.'); gdRenderEmailCard(); return; }

  e.sending = true;
  gdRenderEmailCard();
  setTimeout(() => {
    e.sending = false;
    e.newEmail = val;
    e.step = 'otp';
    e.attempts = 0;
    e.expiry = Date.now() + 60000;
    e.cooldown = 30;
    gdRenderEmailCard();
  }, 900);
}
function gdVerifyEmailOtp() {
  const input = document.getElementById('gd-email-otp');
  const code = input ? input.value.trim() : '';
  const e = gdState.email;
  e.error = '';
  if (Date.now() > e.expiry) { e.error = t('This code has expired. Please resend a new code.'); gdRenderEmailCard(); return; }
  if (!/^\d{6}$/.test(code)) { e.error = t('Enter the 6-digit code we sent to your email.'); gdRenderEmailCard(); return; }
  if (code !== '123456') {
    e.attempts += 1;
    e.error = t('Incorrect verification code.') + (e.attempts>=3 ? ' ' + t('Please request a new code if the problem continues.') : '');
    gdRenderEmailCard();
    return;
  }
  e.verifying = true;
  gdRenderEmailCard();
  setTimeout(() => {
    clearInterval(e._interval);
    GUARDIAN_DATA.account.email = e.newEmail;
    e.verifying = false;
    e.step = 'done';
    gdRenderEmailCard();
  }, 700);
}
function gdResendEmailOtp() {
  const e = gdState.email;
  if (e.cooldown > 0) return;
  e.expiry = Date.now() + 60000;
  e.cooldown = 30;
  e.attempts = 0;
  e.error = '';
  gdRenderEmailCard();
}
function gdCancelEmailChange() {
  clearInterval(gdState.email._interval);
  gdState.email = { step:'idle', newEmail:'', deliveredTo:'', sending:false, verifying:false, attempts:0, error:'', cooldown:0, expiry:0, _interval:null };
  gdRenderEmailCard();
}

/* ── Password recovery (modal flow) ── */
function gdOpenPasswordRecovery() {
  gdState.recovery = { step:1, identifier:'', deliveredTo:'', sending:false, verifying:false, attempts:0, error:'', cooldown:0, expiry:0, resetting:false, _interval:null };
  stOpenModal(gdRecoveryModalHTML());
}
function gdRecoveryModalHTML() {
  const r = gdState.recovery;
  if (r.step === 1) return `
    <div class="st-modal-title">${t('Password Recovery')}</div>
    <div class="st-modal-sub">${t('Enter your Authren Guardian ID or the email linked to your account to receive a reset code.')}</div>
    <div class="st-field"><input id="gd-rec-id" placeholder="${t('Guardian ID (G98765432) or email')}" ${r.sending?'disabled':''}></div>
    <div class="st-inline-msg err${r.error?' show':''}">${r.error||''}</div>
    <button class="st-btn" onclick="gdRecoverySendCode()" ${r.sending?'disabled':''}>${r.sending?`<span class="gd-spinner"></span>${t('Sending code...')}`:t('Send Reset Code')}</button>`;

  if (r.step === 2) {
    const remaining = Math.max(0, Math.ceil((r.expiry - Date.now())/1000));
    return `
    <div class="st-modal-title">${t('Enter Verification Code')}</div>
    <div class="st-modal-sub">${t('Enter the code we sent to')} ${r.deliveredTo}.</div>
    <div class="st-field"><input id="gd-rec-otp" placeholder="000000" maxlength="6" inputmode="numeric" ${r.verifying?'disabled':''}></div>
    <div id="gd-rec-timer" style="font-size:11px;color:var(--muted);margin:-6px 0 12px">${remaining>0? t('Code expires in')+' '+remaining+'s' : t('Code expired. Please resend.')}</div>
    <div class="st-inline-msg err${r.error?' show':''}">${r.error||''}</div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px">
      <button class="st-btn" onclick="gdRecoveryVerifyOtp()" ${r.verifying?'disabled':''}>${r.verifying?`<span class="gd-spinner"></span>${t('Verifying...')}`:t('Verify Code')}</button>
      <button class="st-btn ghost" id="gd-rec-resend" onclick="gdRecoveryResend()" ${r.cooldown>0?'disabled':''}>${r.cooldown>0? t('Resend in')+' '+r.cooldown+'s' : t('Resend Code')}</button>
      <button class="st-btn ghost" onclick="gdRecoveryBack(1)">${t('← Back')}</button>
    </div>`;
  }

  if (r.step === 3) return `
    <div class="st-modal-title">${t('Choose a New Password')}</div>
    <div class="st-modal-sub">${t('Your new password must be at least 6 characters, with a letter and a number.')}</div>
    <div class="st-field"><label>${t('New Password')}</label>
      <div class="pass-input-wrap"><input type="password" id="gd-rec-newpw" style="padding-right:40px" ${r.resetting?'disabled':''}>
        <button type="button" class="toggle-pass-btn" onclick="togglePasswordVisibility('gd-rec-newpw', this)" aria-label="Toggle password visibility">${EYE_CLOSED_SVG}</button>
      </div></div>
    <div class="st-field"><label>${t('Confirm New Password')}</label>
      <div class="pass-input-wrap"><input type="password" id="gd-rec-confirmpw" style="padding-right:40px" ${r.resetting?'disabled':''}>
        <button type="button" class="toggle-pass-btn" onclick="togglePasswordVisibility('gd-rec-confirmpw', this)" aria-label="Toggle password visibility">${EYE_CLOSED_SVG}</button>
      </div></div>
    <div class="st-inline-msg err${r.error?' show':''}">${r.error||''}</div>
    <button class="st-btn" onclick="gdRecoveryResetPassword()" ${r.resetting?'disabled':''}>${r.resetting?`<span class="gd-spinner"></span>${t('Resetting...')}`:t('Reset Password')}</button>
    <div style="margin-top:10px"><button class="st-btn ghost sm" onclick="gdRecoveryBack(2)" ${r.resetting?'disabled':''}>${t('← Back')}</button></div>`;

  return `
    <div style="text-align:center">
      <div style="font-size:36px;margin-bottom:10px">✅</div>
      <div style="font-weight:700;margin-bottom:6px">${t('Password Reset Successfully')}</div>
      <div style="font-size:12.5px;color:var(--muted)">${t('For your security, you will be signed out and can log in with your new password.')}</div>
      <button class="st-btn" style="margin-top:16px" onclick="gdRecoveryFinish()">${t('Return to Login')}</button>
    </div>`;
}
function gdRecoveryRerender() {
  const overlay = document.getElementById('st-modal-overlay');
  if (!overlay || !overlay.classList.contains('active')) return;
  const box = overlay.querySelector('.st-modal-box');
  if (box) box.innerHTML = `<div class="st-modal-close" onclick="stCloseModal()">✕</div>${gdRecoveryModalHTML()}`;
  if (gdState.recovery.step === 2) gdRecoveryStartTimer();
}
function gdRecoveryStartTimer() {
  clearInterval(gdState.recovery._interval);
  gdState.recovery._interval = setInterval(() => {
    const r = gdState.recovery;
    const timerEl = document.getElementById('gd-rec-timer');
    const remaining = Math.max(0, Math.ceil((r.expiry - Date.now())/1000));
    if (timerEl) timerEl.textContent = remaining>0 ? (t('Code expires in')+' '+remaining+'s') : t('Code expired. Please resend.');
    if (r.cooldown > 0) {
      r.cooldown -= 1;
      const btn = document.getElementById('gd-rec-resend');
      if (btn) {
        if (r.cooldown > 0) { btn.disabled = true; btn.textContent = t('Resend in')+' '+r.cooldown+'s'; }
        else { btn.disabled = false; btn.textContent = t('Resend Code'); }
      }
    }
    if (remaining<=0 && r.cooldown<=0) clearInterval(r._interval);
  }, 1000);
}
function gdRecoverySendCode() {
  const input = document.getElementById('gd-rec-id');
  const val = input ? input.value.trim() : '';
  const r = gdState.recovery;
  const a = GUARDIAN_DATA.account;
  const isEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val);
  const isGuardianId = /^G\d{8}$/.test(val);
  r.error = '';
  if (!val) { r.error = t('Please enter your Guardian ID or email.'); gdRecoveryRerender(); return; }
  if (!isEmail && !isGuardianId) { r.error = t('Enter a valid email address or Guardian ID (format: G98765432).'); gdRecoveryRerender(); return; }
  if (isEmail && val.toLowerCase() !== a.email.toLowerCase()) { r.error = t('We could not find an account matching that email.'); gdRecoveryRerender(); return; }
  if (isGuardianId && val.toUpperCase() !== a.guardianId) { r.error = t('We could not find an account matching that Guardian ID.'); gdRecoveryRerender(); return; }

  r.identifier = val;
  r.sending = true;
  gdRecoveryRerender();
  setTimeout(() => {
    r.sending = false;
    r.step = 2;
    r.deliveredTo = a.email;
    r.attempts = 0;
    r.expiry = Date.now() + 60000;
    r.cooldown = 30;
    gdRecoveryRerender();
  }, 900);
}
function gdRecoveryVerifyOtp() {
  const input = document.getElementById('gd-rec-otp');
  const code = input ? input.value.trim() : '';
  const r = gdState.recovery;
  r.error = '';
  if (Date.now() > r.expiry) { r.error = t('This code has expired. Please resend a new code.'); gdRecoveryRerender(); return; }
  if (!/^\d{6}$/.test(code)) { r.error = t('Enter the 6-digit code sent to your email.'); gdRecoveryRerender(); return; }
  if (code !== '123456') {
    r.attempts += 1;
    r.error = t('Incorrect code. Please try again.');
    gdRecoveryRerender();
    return;
  }
  r.verifying = true;
  gdRecoveryRerender();
  setTimeout(() => {
    clearInterval(r._interval);
    r.verifying = false;
    r.step = 3;
    gdRecoveryRerender();
  }, 700);
}
function gdRecoveryResend() {
  const r = gdState.recovery;
  if (r.cooldown > 0) return;
  r.expiry = Date.now() + 60000;
  r.cooldown = 30;
  r.attempts = 0;
  r.error = '';
  gdRecoveryRerender();
}
function gdRecoveryBack(step) {
  clearInterval(gdState.recovery._interval);
  gdState.recovery.step = step;
  gdState.recovery.error = '';
  gdRecoveryRerender();
}
function gdRecoveryResetPassword() {
  const a = document.getElementById('gd-rec-newpw').value;
  const b = document.getElementById('gd-rec-confirmpw').value;
  const r = gdState.recovery;
  r.error = '';
  if (!a || !b) { r.error = t('Please fill in both password fields.'); gdRecoveryRerender(); return; }
  const errs = validatePassword(a);
  if (errs.length) { r.error = errs.join(' '); gdRecoveryRerender(); return; }
  if (a !== b) { r.error = t('Passwords do not match.'); gdRecoveryRerender(); return; }

  r.resetting = true;
  gdRecoveryRerender();
  setTimeout(() => {
    GUARDIAN_DATA.account.password = a;
    r.resetting = false;
    r.step = 4;
    gdRecoveryRerender();
  }, 900);
}
function gdRecoveryFinish() {
  clearInterval(gdState.recovery._interval);
  stCloseModal();
  setTimeout(() => { goLogin('guardian'); }, 200);
}



/* ══════════════════════════════════════════════════════
   TIMETABLE — the selected child's class schedule.
   Follows the existing child switcher, so a guardian with more than one
   child sees whichever child is currently active.
══════════════════════════════════════════════════════ */
function gdTimetable() {
  const child = gdGetActiveChild();
  if (!child) {
    return `<div class="card"><div class="card-body"><div class="tt-empty">${t('Select a child to view their timetable.')}</div></div></div>`;
  }
  const cls = ttClassByName(child.grade);
  if (!cls) {
    return `<div class="card"><div class="card-header"><div class="card-title">${t('Timetable')}</div></div>
      <div class="card-body"><div class="tt-empty">${t('No timetable has been published for')} ${ttEsc(child.name)} (${ttEsc(child.grade)}) ${t('yet.')}</div></div></div>`;
  }
  const entries = ttEntriesForClass(cls.id);
  const subjects = Array.from(new Set(entries.map(e => e.subjectId)));
  return `
    <div class="card"><div class="card-header">
        <div class="card-title">${t('Timetable')} — ${ttEsc(child.name)}</div>
        <button type="button" class="st-btn ghost sm" onclick="ttPrint()">🖨️ ${t('Print')}</button>
      </div>
      <div class="card-body">
        <div style="font-size:12px;color:var(--muted);margin-bottom:12px">${ttEsc(cls.name)} · ${ttEsc(TT_META.academicYear)} · ${ttEsc(TT_META.term)}</div>
        ${ttRenderGrid(entries, 'class')}
        <div class="tt-legend">
          ${subjects.map(sid => { const sj = ttSubject(sid); return sj ? `<div class="tt-legend-item"><span class="tt-legend-dot" style="background:${sj.color}"></span>${ttEsc(sj.name)}</div>` : ''; }).join('')}
        </div>
      </div></div>
    ${ttRenderSummary(entries, 'class')}`;
}
