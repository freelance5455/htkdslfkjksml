/* ══════════════════════════════════════════════════════
   HEAD OF INSTITUTION MODULE — DATA
   Built incrementally across a multi-batch implementation, mirroring the
   Guardian/Teacher modules' approach: every batch adds real, working
   functionality — no placeholder screens for features already in scope.
   Data is deliberately interconnected (student -> class -> teacher,
   student -> guardian) rather than a set of disconnected fake datasets.
══════════════════════════════════════════════════════ */
const HEAD_DATA = {
  institution: {
    name: 'Al Farabi Private School',
    type: 'Private School',
    academicYear: '2025-2026',
    currentTerm: 'Term 2',
    address: '24 Avenue Hassan II, Rabat, Morocco',
    phone: '+212 537-123 456',
    email: 'admin@alfarabi.edu',
    foundedYear: 2008,
  },
  adminProfile: { name: 'Dr. Hassan Ouali', title: 'Head of Institution', password: 'Passw0rd1' },
  settings: { passThreshold: 12, attendanceThreshold: 88, logoDataUrl: null },
  teachers: [
    { id:'ht1', teacherId:'T1234567', name:'Mr. Karim Bensalem', subjects:['Mathematics'], classIds:['hc1','hc2','hc4'], email:'karim.bensalem@alfarabi.edu', phone:'+212 662-345 678', status:'active' , joinedDate:'2019-09-01'},
    { id:'ht2', teacherId:'T2345678', name:'Mrs. Salma Idrissi', subjects:['French'], classIds:['hc1','hc3','hc5'], email:'salma.idrissi@alfarabi.edu', phone:'+212 663-456 789', status:'active' , joinedDate:'2021-09-01'},
    { id:'ht3', teacherId:'T3456789', name:'Mr. Youssef Tazi', subjects:['Physics','Sciences'], classIds:['hc3','hc4','hc5'], email:'youssef.tazi@alfarabi.edu', phone:'+212 664-567 890', status:'active' , joinedDate:'2018-09-01'},
    { id:'ht4', teacherId:'T4567890', name:'Mrs. Nadia Alaoui', subjects:['Arabic'], classIds:['hc1','hc2','hc3'], email:'nadia.alaoui@alfarabi.edu', phone:'+212 665-678 901', status:'active' , joinedDate:'2022-09-01'},
    { id:'ht5', teacherId:'T5678901', name:'Mr. Omar Ziani', subjects:['English'], classIds:['hc4','hc5'], email:'omar.ziani@alfarabi.edu', phone:'+212 666-789 012', status:'active' , joinedDate:'2023-09-01'},
    { id:'ht6', teacherId:'T6789012', name:'Mrs. Houda Chraibi', subjects:['History-Geography'], classIds:['hc2','hc3','hc4'], email:'houda.chraibi@alfarabi.edu', phone:'+212 667-890 123', status:'active' , joinedDate:'2020-09-01'},
  ],
  classes: [
    { id:'hc1', name:'Grade 7 - A', level:'Grade 7', capacity:30, homeroomTeacherId:'ht1', schedule:'Mon–Fri, 08:00–15:00', campus:'main' },
    { id:'hc2', name:'Grade 7 - B', level:'Grade 7', capacity:30, homeroomTeacherId:'ht4', schedule:'Mon–Fri, 08:00–15:00', campus:'main' },
    { id:'hc3', name:'Grade 8 - A', level:'Grade 8', capacity:28, homeroomTeacherId:'ht3', schedule:'Mon–Fri, 08:00–15:30', campus:'main' },
    { id:'hc4', name:'Grade 9 - A', level:'Grade 9', capacity:28, homeroomTeacherId:'ht5', schedule:'Mon–Fri, 08:00–16:00', campus:'main' },
    { id:'hc5', name:'Grade 10 - A', level:'Grade 10', capacity:26, homeroomTeacherId:'ht2', schedule:'Mon–Fri, 08:00–16:30', campus:'north' },
  ],
  guardians: [
    { id:'hg01', name:'Mr. Rachid Tahiri', email:'rachid.tahiri@example.com', phone:'+212 661-111 001', studentIds:['hs01'] },
    { id:'hg02', name:'Mrs. Latifa Bennani', email:'latifa.bennani@example.com', phone:'+212 661-111 002', studentIds:['hs02'] },
    { id:'hg03', name:'Mr. Hicham Sabri', email:'hicham.sabri@example.com', phone:'+212 661-111 003', studentIds:['hs03','hs04'] },
    { id:'hg04', name:'Mrs. Naima Kabbaj', email:'naima.kabbaj@example.com', phone:'+212 661-111 004', studentIds:['hs05'] },
    { id:'hg05', name:'Mr. Adil Ghali', email:'adil.ghali@example.com', phone:'+212 661-111 005', studentIds:['hs06'] },
    { id:'hg06', name:'Mrs. Samira Rifai', email:'samira.rifai@example.com', phone:'+212 661-111 006', studentIds:['hs07'] },
    { id:'hg07', name:'Mr. Younes Amrani', email:'younes.amrani@example.com', phone:'+212 661-111 007', studentIds:['hs08'] },
    { id:'hg08', name:'Mrs. Ibtissam Fassi', email:'ibtissam.fassi@example.com', phone:'+212 661-111 008', studentIds:['hs09'] },
    { id:'hg09', name:'Mr. Mehdi Chakir', email:'mehdi.chakir@example.com', phone:'+212 661-111 009', studentIds:['hs10','hs11'] },
    { id:'hg10', name:'Mrs. Karima Zouiten', email:'karima.zouiten@example.com', phone:'+212 661-111 010', studentIds:['hs12'] },
    { id:'hg11', name:'Mr. Anas Belhaj', email:'anas.belhaj@example.com', phone:'+212 661-111 011', studentIds:['hs13'] },
    { id:'hg12', name:'Mrs. Fatiha Ouahabi', email:'fatiha.ouahabi@example.com', phone:'+212 661-111 012', studentIds:['hs14'] },
    { id:'hg13', name:'Mr. Karim Saidi', email:'karim.saidi@example.com', phone:'+212 661-111 013', studentIds:['hs15'] },
    { id:'hg14', name:'Mrs. Widad Lahlou', email:'widad.lahlou@example.com', phone:'+212 661-111 014', studentIds:['hs16'] },
    { id:'hg15', name:'Mr. Reda Haddadi', email:'reda.haddadi@example.com', phone:'+212 661-111 015', studentIds:['hs17'] },
    { id:'hg16', name:'Mrs. Ghita Marrakchi', email:'ghita.marrakchi@example.com', phone:'+212 661-111 016', studentIds:['hs18'] },
    { id:'hg17', name:'Mr. Yassine Berrada', email:'yassine.berrada@example.com', phone:'+212 661-111 017', studentIds:['hs19'] },
    { id:'hg18', name:'Mrs. Meryem Ouazzani', email:'meryem.ouazzani@example.com', phone:'+212 661-111 018', studentIds:['hs20'] },
    { id:'hg19', name:'Mr. Samir El Fassi', email:'samir.elfassi@example.com', phone:'+212 661-111 019', studentIds:['hs21','hs22'] },
    { id:'hg20', name:'Mrs. Aicha Bouzid', email:'aicha.bouzid@example.com', phone:'+212 661-111 020', studentIds:['hs23'] },
    { id:'hg21', name:'Mr. Tarik Cherkaoui', email:'tarik.cherkaoui@example.com', phone:'+212 661-111 021', studentIds:['hs24'] },
    { id:'hg22', name:'Mrs. Loubna Rachidi', email:'loubna.rachidi@example.com', phone:'+212 661-111 022', studentIds:['hs25'] },
    { id:'hg23', name:'Mr. Hamza Ziani', email:'hamza.ziani@example.com', phone:'+212 661-111 023', studentIds:['hs26'] },
    { id:'hg24', name:'Mrs. Sanaa Idrissi', email:'sanaa.idrissi@example.com', phone:'+212 661-111 024', studentIds:['hs27'] },
    { id:'hg25', name:'Mr. Nabil Ouahabi', email:'nabil.ouahabi@example.com', phone:'+212 661-111 025', studentIds:['hs28'] },
    { id:'hg26', name:'Mrs. Zineb Alaoui', email:'zineb.alaoui@example.com', phone:'+212 661-111 026', studentIds:['hs29','hs30'] },
  ],
  students: [
    { id:'hs01', studentId:'S4000001', firstName:'Amine', lastName:'Tahiri', dob:'2013-04-12', gender:'M', classId:'hc1', guardianId:'hg01', enrollmentDate:'2024-09-02', status:'active', avgGrade:15.8, attendanceRate:96, paymentStatus:'paid' },
    { id:'hs02', studentId:'S4000002', firstName:'Salma', lastName:'Bennani', dob:'2013-06-20', gender:'F', classId:'hc1', guardianId:'hg02', enrollmentDate:'2024-09-02', status:'active', avgGrade:17.1, attendanceRate:98, paymentStatus:'paid' },
    { id:'hs03', studentId:'S4000003', firstName:'Hamza', lastName:'Sabri', dob:'2013-01-05', gender:'M', classId:'hc1', guardianId:'hg03', enrollmentDate:'2024-09-02', status:'active', avgGrade:11.4, attendanceRate:87, paymentStatus:'overdue' },
    { id:'hs04', studentId:'S4000004', firstName:'Douae', lastName:'Sabri', dob:'2014-11-15', gender:'F', classId:'hc2', guardianId:'hg03', enrollmentDate:'2024-09-02', status:'active', avgGrade:14.2, attendanceRate:94, paymentStatus:'overdue' },
    { id:'hs05', studentId:'S4000005', firstName:'Yassine', lastName:'Kabbaj', dob:'2013-09-08', gender:'M', classId:'hc1', guardianId:'hg04', enrollmentDate:'2024-09-02', status:'active', avgGrade:9.6, attendanceRate:81, paymentStatus:'partial' },
    { id:'hs06', studentId:'S4000006', firstName:'Nour', lastName:'Ghali', dob:'2013-03-27', gender:'F', classId:'hc1', guardianId:'hg05', enrollmentDate:'2024-09-02', status:'active', avgGrade:16.9, attendanceRate:99, paymentStatus:'paid' },
    { id:'hs07', studentId:'S4000007', firstName:'Karim', lastName:'Rifai', dob:'2013-07-19', gender:'M', classId:'hc2', guardianId:'hg06', enrollmentDate:'2024-09-02', status:'active', avgGrade:13.5, attendanceRate:92, paymentStatus:'paid' },
    { id:'hs08', studentId:'S4000008', firstName:'Ines', lastName:'Amrani', dob:'2014-02-14', gender:'F', classId:'hc2', guardianId:'hg07', enrollmentDate:'2024-09-02', status:'active', avgGrade:8.9, attendanceRate:79, paymentStatus:'overdue' },
    { id:'hs09', studentId:'S4000009', firstName:'Othmane', lastName:'Fassi', dob:'2014-05-30', gender:'M', classId:'hc2', guardianId:'hg08', enrollmentDate:'2024-09-02', status:'active', avgGrade:12.8, attendanceRate:90, paymentStatus:'paid' },
    { id:'hs10', studentId:'S4000010', firstName:'Kenza', lastName:'Chakir', dob:'2014-08-22', gender:'F', classId:'hc2', guardianId:'hg09', enrollmentDate:'2024-09-02', status:'active', avgGrade:15.0, attendanceRate:95, paymentStatus:'paid' },
    { id:'hs11', studentId:'S4000011', firstName:'Sami', lastName:'Chakir', dob:'2012-12-01', gender:'M', classId:'hc3', guardianId:'hg09', enrollmentDate:'2023-09-04', status:'active', avgGrade:14.6, attendanceRate:93, paymentStatus:'paid' },
    { id:'hs12', studentId:'S4000012', firstName:'Zineb', lastName:'Zouiten', dob:'2012-10-11', gender:'F', classId:'hc3', guardianId:'hg10', enrollmentDate:'2023-09-04', status:'active', avgGrade:17.5, attendanceRate:99, paymentStatus:'paid' },
    { id:'hs13', studentId:'S4000013', firstName:'Anas', lastName:'Belhaj', dob:'2012-03-17', gender:'M', classId:'hc3', guardianId:'hg11', enrollmentDate:'2023-09-04', status:'active', avgGrade:10.2, attendanceRate:85, paymentStatus:'partial' },
    { id:'hs14', studentId:'S4000014', firstName:'Fatima Zahra', lastName:'Ouahabi', dob:'2012-06-25', gender:'F', classId:'hc3', guardianId:'hg12', enrollmentDate:'2023-09-04', status:'active', avgGrade:18.0, attendanceRate:100, paymentStatus:'paid' },
    { id:'hs15', studentId:'S4000015', firstName:'Reda', lastName:'Saidi', dob:'2012-09-09', gender:'M', classId:'hc3', guardianId:'hg13', enrollmentDate:'2023-09-04', status:'active', avgGrade:7.8, attendanceRate:76, paymentStatus:'overdue' },
    { id:'hs16', studentId:'S4000016', firstName:'Widad', lastName:'Lahlou', dob:'2012-01-30', gender:'F', classId:'hc3', guardianId:'hg14', enrollmentDate:'2023-09-04', status:'active', avgGrade:13.9, attendanceRate:91, paymentStatus:'paid' },
    { id:'hs17', studentId:'S4000017', firstName:'Bilal', lastName:'Haddadi', dob:'2011-11-14', gender:'M', classId:'hc4', guardianId:'hg15', enrollmentDate:'2022-09-05', status:'active', avgGrade:16.2, attendanceRate:97, paymentStatus:'paid' },
    { id:'hs18', studentId:'S4000018', firstName:'Ghita', lastName:'Marrakchi', dob:'2011-04-02', gender:'F', classId:'hc4', guardianId:'hg16', enrollmentDate:'2022-09-05', status:'active', avgGrade:11.9, attendanceRate:88, paymentStatus:'paid' },
    { id:'hs19', studentId:'S4000019', firstName:'Yassine', lastName:'Berrada', dob:'2011-08-19', gender:'M', classId:'hc4', guardianId:'hg17', enrollmentDate:'2022-09-05', status:'active', avgGrade:9.1, attendanceRate:80, paymentStatus:'overdue' },
    { id:'hs20', studentId:'S4000020', firstName:'Meryem', lastName:'Ouazzani', dob:'2011-12-27', gender:'F', classId:'hc4', guardianId:'hg18', enrollmentDate:'2022-09-05', status:'active', avgGrade:15.4, attendanceRate:95, paymentStatus:'paid' },
    { id:'hs21', studentId:'S4000021', firstName:'Samir', lastName:'El Fassi', dob:'2011-02-08', gender:'M', classId:'hc4', guardianId:'hg19', enrollmentDate:'2022-09-05', status:'active', avgGrade:12.3, attendanceRate:89, paymentStatus:'partial' },
    { id:'hs22', studentId:'S4000022', firstName:'Rim', lastName:'El Fassi', dob:'2013-05-16', gender:'F', classId:'hc1', guardianId:'hg19', enrollmentDate:'2024-09-02', status:'active', avgGrade:14.8, attendanceRate:94, paymentStatus:'partial' },
    { id:'hs23', studentId:'S4000023', firstName:'Adam', lastName:'Bouzid', dob:'2010-10-05', gender:'M', classId:'hc5', guardianId:'hg20', enrollmentDate:'2021-09-06', status:'active', avgGrade:17.8, attendanceRate:99, paymentStatus:'paid' },
    { id:'hs24', studentId:'S4000024', firstName:'Rania', lastName:'Cherkaoui', dob:'2010-07-23', gender:'F', classId:'hc5', guardianId:'hg21', enrollmentDate:'2021-09-06', status:'active', avgGrade:13.1, attendanceRate:90, paymentStatus:'paid' },
    { id:'hs25', studentId:'S4000025', firstName:'Mehdi', lastName:'Rachidi', dob:'2010-03-11', gender:'M', classId:'hc5', guardianId:'hg22', enrollmentDate:'2021-09-06', status:'active', avgGrade:8.4, attendanceRate:77, paymentStatus:'overdue' },
    { id:'hs26', studentId:'S4000026', firstName:'Hiba', lastName:'Ziani', dob:'2010-09-28', gender:'F', classId:'hc5', guardianId:'hg23', enrollmentDate:'2021-09-06', status:'active', avgGrade:16.6, attendanceRate:97, paymentStatus:'paid' },
    { id:'hs27', studentId:'S4000027', firstName:'Karim', lastName:'Idrissi', dob:'2010-01-16', gender:'M', classId:'hc5', guardianId:'hg24', enrollmentDate:'2021-09-06', status:'active', avgGrade:11.0, attendanceRate:86, paymentStatus:'partial' },
    { id:'hs28', studentId:'S4000028', firstName:'Nada', lastName:'Ouahabi', dob:'2010-06-04', gender:'F', classId:'hc5', guardianId:'hg25', enrollmentDate:'2021-09-06', status:'active', avgGrade:14.4, attendanceRate:93, paymentStatus:'paid' },
    { id:'hs29', studentId:'S4000029', firstName:'Ayoub', lastName:'Alaoui', dob:'2013-11-02', gender:'M', classId:'hc2', guardianId:'hg26', enrollmentDate:'2024-09-02', status:'active', avgGrade:10.7, attendanceRate:84, paymentStatus:'partial' },
    { id:'hs30', studentId:'S4000030', firstName:'Lina', lastName:'Alaoui', dob:'2011-05-13', gender:'F', classId:'hc4', guardianId:'hg26', enrollmentDate:'2022-09-05', status:'active', avgGrade:15.9, attendanceRate:96, paymentStatus:'partial' },
  ],
};

/* Deterministic pseudo-random helper (same input always yields the same
   output) so the generated attendance dataset below is stable across
   reloads/tests, yet weighted realistically off each student's own
   attendanceRate — never contradicting the aggregate already shown
   elsewhere in the app. */
function hSeededRandom(str) {
  let hash = 2166136261;
  for (let i = 0; i < str.length; i++) {
    hash ^= str.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return (hash >>> 0) / 4294967296;
}
const H_ATTENDANCE_DAYS = ['2026-02-23','2026-02-24','2026-02-25','2026-02-26','2026-02-27','2026-03-02','2026-03-03','2026-03-04','2026-03-05','2026-03-06','2026-03-09','2026-03-10'];
function hGenerateAttendanceStatus(student, date) {
  const r = hSeededRandom(student.id + date);
  const absenceProb = (100 - student.attendanceRate) / 100;
  if (r < absenceProb * 0.55) {
    const r2 = hSeededRandom(student.id + date + 'x');
    return r2 < 0.25 ? 'excused' : 'absent';
  }
  if (r < absenceProb) return 'late';
  return 'present';
}
HEAD_DATA.attendanceRecords = {}; // { [date]: { [studentId]: 'present'|'absent'|'late'|'excused' } }
H_ATTENDANCE_DAYS.forEach(date => {
  HEAD_DATA.attendanceRecords[date] = {};
  HEAD_DATA.students.forEach(s => { HEAD_DATA.attendanceRecords[date][s.id] = hGenerateAttendanceStatus(s, date); });
});

/* Exam results and homework submissions are generated deterministically
   from each student's own real avgGrade/attendanceRate — never arbitrary
   — so a struggling student's exam scores and submission record honestly
   reflect that, rather than random noise disconnected from their profile. */
function hGenerateExamScore(student, maxScore, examId) {
  const variance = (hSeededRandom(student.id + examId) - 0.5) * 4; // +/-2 points of natural variation
  const raw = (student.avgGrade / 20) * maxScore + variance;
  return Math.max(0, Math.min(maxScore, Math.round(raw * 2) / 2));
}
function hGenerateSubmissionStatus(student, hwId) {
  const missProb = Math.max(0.02, (100 - student.attendanceRate) / 150); // lower attendance -> somewhat likelier to miss homework
  if (hSeededRandom(student.id + hwId) < missProb) return 'missing';
  const lateProb = Math.max(0.03, (100 - student.attendanceRate) / 300);
  if (hSeededRandom(student.id + hwId + 'late') < lateProb) return 'late';
  return 'submitted';
}
HEAD_DATA.exams = [
  { id:'he1', name:'Term 2 Mathematics Test', classId:'hc1', subject:'Mathematics', date:'2026-02-20', time:'09:00', duration:60, maxScore:20, status:'completed', locked:true },
  { id:'he2', name:'Term 2 French Test', classId:'hc2', subject:'French', date:'2026-02-24', time:'10:00', duration:45, maxScore:20, status:'completed', locked:false },
  { id:'he3', name:'Physics Midterm', classId:'hc3', subject:'Physics', date:'2026-03-03', time:'09:00', duration:60, maxScore:20, status:'completed', locked:false },
  { id:'he4', name:'Term 2 English Test', classId:'hc4', subject:'English', date:'2026-03-20', time:'09:00', duration:45, maxScore:20, status:'scheduled', locked:false },
  { id:'he5', name:'Term 2 Final — Grade 10', classId:'hc5', subject:'French', date:'2026-03-25', time:'09:00', duration:90, maxScore:40, status:'scheduled', locked:false },
];
HEAD_DATA.exams.forEach(exam => {
  exam.scores = {};
  if (exam.status === 'completed') {
    hClassStudents(exam.classId).forEach(s => { exam.scores[s.id] = hGenerateExamScore(s, exam.maxScore, exam.id); });
  }
});
HEAD_DATA.homework = [
  { id:'hh1', title:'Algebra Practice Sheet', classId:'hc1', subject:'Mathematics', dueDate:'2026-03-05', status:'published' },
  { id:'hh2', title:'French Grammar Exercises', classId:'hc2', subject:'French', dueDate:'2026-03-06', status:'published' },
  { id:'hh3', title:'Physics Lab Report', classId:'hc3', subject:'Physics', dueDate:'2026-03-08', status:'published' },
  { id:'hh4', title:'English Essay: My Community', classId:'hc4', subject:'English', dueDate:'2026-03-09', status:'published' },
  { id:'hh5', title:'History Timeline Project', classId:'hc5', subject:'History-Geography', dueDate:'2026-03-18', status:'published' },
  { id:'hh6', title:'Arabic Reading Comprehension', classId:'hc1', subject:'Arabic', dueDate:'2026-03-19', status:'published' },
];
HEAD_DATA.homework.forEach(hw => {
  hw.submissions = {};
  hClassStudents(hw.classId).forEach(s => { hw.submissions[s.id] = hGenerateSubmissionStatus(s, hw.id); });
});

HEAD_DATA.announcements = [
  { id:'han1', subject:'Term 2 Report Cards Available', message:'Term 2 report cards are now available. Guardians can review academic progress with their child\'s homeroom teacher during the upcoming parent meetings.', audience:'guardians', audienceClassId:null, sentAt:'2026-03-05T09:00:00', sentBy:'Dr. Hassan Ouali', status:'sent', readRate:78 },
  { id:'han2', subject:'Staff Meeting — Friday', message:'A mandatory staff meeting will be held this Friday at 16:00 in the main conference room to discuss Term 3 planning.', audience:'teachers', audienceClassId:null, sentAt:'2026-03-08T14:00:00', sentBy:'Dr. Hassan Ouali', status:'sent', readRate:100 },
  { id:'han3', subject:'Sports Day Reminder', message:'This is a reminder that our annual Sports Day is scheduled for March 28th. Please ensure students bring appropriate sportswear.', audience:'school', audienceClassId:null, sentAt:'2026-03-09T11:30:00', sentBy:'Dr. Hassan Ouali', status:'sent', readRate:64 },
];
HEAD_DATA.studentHistoryLog = []; // { id, studentId, type, label, date } — administrative events, logged as they actually happen
function hLogStudentHistory(studentId, type, label, date) {
  HEAD_DATA.studentHistoryLog.push({ id:'hist' + Date.now() + Math.random().toString(36).slice(2, 6), studentId, type, label, date: date || tISODate(new Date(2026, 2, 11)) });
}
HEAD_DATA.generatedAccounts = []; // { id, personType, personId, authrenId, tempPassword, status, generatedAt }
/* ONE audit log. hLogAudit writes into the shared AUTHREN_LEDGER.auditLog
   (js/authren-payments.js) — the same log payments, attendance, grades,
   homework and messages already write into — instead of a separate local
   array. HEAD_DATA.auditLog is a live, read-only translation of the
   Head's own entries into the exact shape this file's existing display
   code already expects, so no rendering code below needs to change. */
function hLogAudit(action, objectType, objectLabel, previousValue, newValue) {
  if (typeof authrenLogAudit === 'function') {
    authrenLogAudit('head', HEAD_DATA.adminProfile.name, action, objectType, objectLabel, previousValue, newValue);
  }
}
Object.defineProperty(HEAD_DATA, 'auditLog', {
  get() {
    if (typeof AUTHREN_LEDGER === 'undefined') return [];
    return AUTHREN_LEDGER.auditLog
      .filter(a => a.actorRole === 'head')
      .map(a => {
        const d = new Date(a.at);
        return {
          id: a.id, action: a.action, objectType: a.objectType, objectLabel: a.objectLabel,
          previousValue: a.previousValue, newValue: a.newValue, user: a.actorId,
          date: isNaN(d) ? a.at : tISODate(d),
          time: isNaN(d) ? '' : String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'),
        };
      });
  },
  configurable: true,
});
const H_BEHAVIOR_CATEGORIES = ['Positive Behavior', 'Excellent Participation', 'Disruption', 'Late to Class', 'Conflict with Peer'];
HEAD_DATA.behaviorRecords = [];
HEAD_DATA.students.forEach(s => {
  const r = hSeededRandom(s.id + 'behavior-has');
  if (r > 0.55) return; // ~55% of students have no behavior record this term, which is realistic
  const isPositiveProfile = s.avgGrade >= 14 && s.attendanceRate >= 92;
  const isStrugglingProfile = s.avgGrade < 12 || s.attendanceRate < 88;
  let category;
  const catRoll = hSeededRandom(s.id + 'behavior-cat');
  if (isPositiveProfile) category = catRoll < 0.6 ? 'Positive Behavior' : 'Excellent Participation';
  else if (isStrugglingProfile) category = catRoll < 0.4 ? 'Disruption' : catRoll < 0.75 ? 'Late to Class' : 'Conflict with Peer';
  else category = H_BEHAVIOR_CATEGORIES[Math.floor(catRoll * H_BEHAVIOR_CATEGORIES.length)];
  const dayOffset = Math.floor(hSeededRandom(s.id + 'behavior-date') * H_ATTENDANCE_DAYS.length);
  HEAD_DATA.behaviorRecords.push({ id:'hbh' + s.id, studentId: s.id, category, description:'', date: H_ATTENDANCE_DAYS[dayOffset] || '2026-03-05' });
  // A second record for a subset, to create genuine repeated-incident cases
  if (isStrugglingProfile && hSeededRandom(s.id + 'behavior-second') < 0.5) {
    const dayOffset2 = Math.floor(hSeededRandom(s.id + 'behavior-date2') * H_ATTENDANCE_DAYS.length);
    HEAD_DATA.behaviorRecords.push({ id:'hbh2' + s.id, studentId: s.id, category: catRoll < 0.5 ? 'Disruption' : 'Late to Class', description:'', date: H_ATTENDANCE_DAYS[dayOffset2] || '2026-03-06' });
  }
});
HEAD_DATA.admissions = [
  { id:'had1', firstName:'Selma', lastName:'Naciri', dob:'2014-02-10', gender:'F', appliedLevel:'Grade 7', guardianName:'Mrs. Houria Naciri', guardianEmail:'houria.naciri@example.com', guardianPhone:'+212 662-200 001', submittedDate:'2026-02-15', status:'pending', notes:'', source:'Website' },
  { id:'had2', firstName:'Amir', lastName:'Belkadi', dob:'2013-08-22', gender:'M', appliedLevel:'Grade 8', guardianName:'Mr. Said Belkadi', guardianEmail:'said.belkadi@example.com', guardianPhone:'+212 662-200 002', submittedDate:'2026-02-20', status:'under-review', notes:'Transcript received; awaiting interview.', source:'Referral' },
  { id:'had3', firstName:'Yasmine', lastName:'Fathi', dob:'2012-05-14', gender:'F', appliedLevel:'Grade 9', guardianName:'Mrs. Amina Fathi', guardianEmail:'amina.fathi@example.com', guardianPhone:'+212 662-200 003', submittedDate:'2026-02-10', status:'accepted', notes:'Strong academic record from previous school.', source:'Walk-in' },
  { id:'had4', firstName:'Othman', lastName:'Rguig', dob:'2011-11-03', gender:'M', appliedLevel:'Grade 10', guardianName:'Mr. Jamal Rguig', guardianEmail:'jamal.rguig@example.com', guardianPhone:'+212 662-200 004', submittedDate:'2026-01-28', status:'rejected', notes:'Class capacity full for this level.', source:'Website' },
  { id:'had5', firstName:'Chaimae', lastName:'Ouahbi', dob:'2013-03-19', gender:'F', appliedLevel:'Grade 8', guardianName:'Mrs. Nezha Ouahbi', guardianEmail:'nezha.ouahbi@example.com', guardianPhone:'+212 662-200 005', submittedDate:'2026-03-02', status:'waitlisted', notes:'', source:'Referral' },
  { id:'had6', firstName:'Ilyas', lastName:'Tber', dob:'2014-07-08', gender:'M', appliedLevel:'Grade 7', guardianName:'Mr. Hassan Tber', guardianEmail:'hassan.tber@example.com', guardianPhone:'+212 662-200 006', submittedDate:'2026-03-08', status:'pending', notes:'', source:'Website' },
];
HEAD_DATA.orientations = [
  { id:'hor1', title:'New Grade 7 Families Orientation', date:'2026-03-24', time:'10:00', location:'Main Auditorium', instructions:'Please bring your acceptance letter and a valid ID.', status:'scheduled', participantType:'admissions', participantIds:['had1','had6'], attended:{} },
  { id:'hor2', title:'Mid-Year Transfer Orientation', date:'2026-02-18', time:'09:00', location:'Room 12', instructions:'Campus tour followed by a Q&A session with homeroom teachers.', status:'completed', participantType:'admissions', participantIds:['had3'], attended:{ had3:true } },
];
HEAD_DATA.reclamations = [
  { id:'hrc1', referenceId:'RC-482910', category:'Facilities', subject:'Broken lockers in Grade 8 hallway', description:'Several lockers near the Grade 8 hallway have broken latches and cannot be secured properly.', priority:'medium', status:'new', submittedDate:'2026-03-06', internalNotes:'' },
  { id:'hrc2', referenceId:'RC-773204', category:'Teaching Quality', subject:'Concern about pacing in one class', description:'Some students feel the pace of one of the Term 2 classes has been too fast to keep up with, especially before the recent test.', priority:'medium', status:'in-review', submittedDate:'2026-02-27', internalNotes:'Discussed with the relevant homeroom teacher on 2026-03-01.' },
  { id:'hrc3', referenceId:'RC-119345', category:'Cafeteria', subject:'Limited vegetarian options', description:'The cafeteria menu rarely includes vegetarian options, which is difficult for a few students with dietary restrictions.', priority:'low', status:'resolved', submittedDate:'2026-02-10', internalNotes:'Cafeteria vendor added two vegetarian options starting Term 2 week 3.' },
  { id:'hrc4', referenceId:'RC-560182', category:'Safety', subject:'Poor lighting near the parking area', description:'The lighting near the staff parking area is very dim in the evening, which feels unsafe during late pickups.', priority:'high', status:'new', submittedDate:'2026-03-09', internalNotes:'' },
];
const H_DOCUMENT_CATEGORIES = ['Academic', 'Administrative', 'Financial', 'Legal', 'Health & Safety', 'Other'];
HEAD_DATA.documents = [
  { id:'hdoc1', name:'Term 2 Academic Calendar.pdf', category:'Academic', uploadedDate:'2026-01-15', size:'214 KB', associatedType:'institution', associatedId:null, dataUrl:null },
  { id:'hdoc2', name:'Fire Safety Inspection Report.pdf', category:'Health & Safety', uploadedDate:'2026-02-01', size:'540 KB', associatedType:'institution', associatedId:null, dataUrl:null },
  { id:'hdoc3', name:'Grade 9 - A Class Roster.pdf', category:'Administrative', uploadedDate:'2026-02-20', size:'88 KB', associatedType:'class', associatedId:'hc4', dataUrl:null },
];
HEAD_DATA.campuses = [
  { id:'main', name:'Main Campus', address:'24 Avenue Hassan II, Rabat, Morocco', phone:'+212 537-123 456' },
  { id:'north', name:'North Campus', address:'8 Rue Ibn Sina, Salé, Morocco', phone:'+212 537-987 654' },
];
HEAD_DATA.messageTemplates = [
  { id:'tpl1', name:'Report Card Reminder', subject:'Term Report Cards Available', message:'Dear guardians, term report cards are now available. Please review academic progress with your child\'s homeroom teacher during the upcoming parent meetings.' },
  { id:'tpl2', name:'Staff Meeting Notice', subject:'Upcoming Staff Meeting', message:'A staff meeting has been scheduled. Please make every effort to attend, as important updates for the upcoming term will be discussed.' },
  { id:'tpl3', name:'Event Reminder', subject:'Upcoming School Event', message:'This is a friendly reminder about our upcoming school event. Please check the school calendar for the exact date, time, and location.' },
];
HEAD_DATA.audienceGroups = [
  { id:'grp1', name:'Grade 9 Homeroom Teachers', memberType:'teacher', memberIds:['ht5'] },
];
const H_SUPPORT_CATEGORIES = ['Account', 'Students & Classes', 'Reporting', 'Billing', 'Technical Issue', 'Other'];
const H_FAQS = [
  { id:'faq1', category:'Account', question:'How do I change the administrator profile name?', answer:'Go to Institution Settings, click Edit, and update the Administrator Profile section. This name is used as the sender on new communications and the actor recorded in the audit log.' },
  { id:'faq2', category:'Students & Classes', question:'How do I move a student to a different class?', answer:'Open the student\'s profile and click Edit, or open the destination class and use "Add Student" — either action updates the class immediately and is recorded in the student\'s history.' },
  { id:'faq3', category:'Reporting', question:'What is the difference between Basic and Advanced Reports?', answer:'Basic Reports generate a single-type report (Student, Attendance, Academic, Homework, or Institution Overview). The Advanced Report Builder lets you combine multiple classes and metrics into one custom report, with the option to save the configuration for reuse.' },
  { id:'faq4', category:'Billing', question:'How are outstanding payments calculated?', answer:'Outstanding payments include any record with a "pending" or "overdue" status. You can see the full breakdown in Payments → Advanced Analytics.' },
  { id:'faq5', category:'Account', question:'Can I change the pass/attendance thresholds used for flagging students?', answer:'Yes — under Institution Settings → Grading & Attendance Configuration, you can adjust both thresholds. This immediately affects which students are flagged as "Needing Attention" throughout the app.' },
  { id:'faq6', category:'Technical Issue', question:'Why does a report show "Not enough data to compare"?', answer:'This means the selected period genuinely has no recorded data for that metric — for example, no homework was due in a month you are comparing against. This is shown honestly rather than fabricating a number.' },
];
HEAD_DATA.supportTickets = [];
/* No plan/price list here. The Head sees plan ENTITLEMENT only and reads
   it straight from the canonical catalog (js/plans.js). Pricing and billing
   belong to the School / Institution role. */
/* Entitlement only — billingStatus / renewalDate / invoices deliberately
   absent from the Head's copy. The authoritative subscription record lives
   with the School / Institution role. */
HEAD_DATA.subscription = {
  currentPlan: 'ELITE', // demo institution shows every feature at this stage
  history: [
    { date:'2025-09-01', event:'Subscribed to Authren Growth' },
    { date:'2024-09-01', event:'Subscribed to Authren Start' },
  ],
};
const H_PAYMENT_METHODS = ['Bank Transfer', 'Card ending 4471', 'Cash', 'Check'];
/* ONE LEDGER, ROLE-SCOPED VIEW.
   Every payment row lives in AUTHREN_LEDGER.payments (js/authren-payments.js).
   HEAD_DATA.payments is a live read-only view of the rows belonging to the
   Head's own students, so existing Head screens keep working unchanged and
   totals never pick up another roster's rows.
   A payment recorded by the Institution for one of these students appears
   here immediately, because both roles read the same table. */
Object.defineProperty(HEAD_DATA, 'payments', {
  get() {
    const mine = {};
    (HEAD_DATA.students || []).forEach(st => { mine[st.id] = true; });
    return AUTHREN_LEDGER.payments.filter(p => mine[p.studentId]);
  },
  configurable: true,
});
let hReceiptCounter = 1;
HEAD_DATA.students.forEach(s => {
  const t1Method = H_PAYMENT_METHODS[Math.floor(hSeededRandom(s.id + 't1method') * H_PAYMENT_METHODS.length)];
  authrenSeedPayment({ source:'head',  id:'pay-' + s.id + '-t1', studentId:s.id, date:'2025-11-' + String(5 + Math.floor(hSeededRandom(s.id + 't1day') * 20)).padStart(2, '0'), description:'Term 1 Tuition', amount:4500, currency:'MAD', status:'paid', method:t1Method, receiptId:'RCPT-2025-' + String(hReceiptCounter++).padStart(3, '0') });
  if (s.paymentStatus === 'paid') {
    const method = H_PAYMENT_METHODS[Math.floor(hSeededRandom(s.id + 't2method') * H_PAYMENT_METHODS.length)];
    authrenSeedPayment({ source:'head',  id:'pay-' + s.id + '-t2', studentId:s.id, date:'2026-02-' + String(2 + Math.floor(hSeededRandom(s.id + 't2day') * 20)).padStart(2, '0'), description:'Term 2 Tuition', amount:4500, currency:'MAD', status:'paid', method, receiptId:'RCPT-2026-' + String(hReceiptCounter++).padStart(3, '0') });
  } else if (s.paymentStatus === 'partial') {
    const method = H_PAYMENT_METHODS[Math.floor(hSeededRandom(s.id + 't2method') * H_PAYMENT_METHODS.length)];
    authrenSeedPayment({ source:'head',  id:'pay-' + s.id + '-t2a', studentId:s.id, date:'2026-02-' + String(2 + Math.floor(hSeededRandom(s.id + 't2day') * 20)).padStart(2, '0'), description:'Term 2 Tuition (partial)', amount:2250, currency:'MAD', status:'paid', method, receiptId:'RCPT-2026-' + String(hReceiptCounter++).padStart(3, '0') });
    authrenSeedPayment({ source:'head',  id:'pay-' + s.id + '-t2b', studentId:s.id, date:'2026-03-30', description:'Term 2 Tuition (remaining balance)', amount:2250, currency:'MAD', status:'pending', method:null, receiptId:null });
  } else {
    authrenSeedPayment({ source:'head',  id:'pay-' + s.id + '-t2', studentId:s.id, date:'2026-02-28', description:'Term 2 Tuition', amount:4500, currency:'MAD', status:'overdue', method:null, receiptId:null });
  }
});

HEAD_DATA.events = [
  { id:'hev1', title:'Parent-Teacher Meetings', category:'meeting', date:'2026-03-16', startTime:'14:00', endTime:'18:00', audience:'guardians', description:'Individual meetings between guardians and homeroom teachers to discuss Term 2 progress.' },
  { id:'hev2', title:'Sports Day', category:'event', date:'2026-03-28', startTime:'09:00', endTime:'15:00', audience:'school', description:'Annual inter-class sports competition held on the main field.' },
  { id:'hev3', title:'Term 2 Ends', category:'academic', date:'2026-04-03', startTime:'', endTime:'', audience:'school', description:'Last day of Term 2. Term 3 begins April 20th.' },
  { id:'hev4', title:'Staff Meeting', category:'meeting', date:'2026-03-13', startTime:'16:00', endTime:'17:30', audience:'teachers', description:'Term 3 planning discussion.' },
  { id:'hev5', title:'National Holiday', category:'holiday', date:'2026-03-17', startTime:'', endTime:'', audience:'school', description:'School closed.' },
];

let hState = {
  currentView: 'home',
  tab: { account: 'profile' },
  dashboard: { loadState: 'idle', campus: 'all' },
  intelligence: { tab:'pulse', periodType:'month' },
  students: { search:'', filterClassId:'all', filterLevel:'all', filterStatus:'all', sort:'name', screen:'list', studentId:null, form:null, error:'', saving:false },
  teachers: { tab:'directory', search:'', filterSubject:'all', screen:'list', teacherId:null, form:null, error:'', saving:false, addSubjectDraft:'' },
  guardians: { search:'', screen:'list', guardianId:null, form:null, error:'', saving:false, linkSearch:'' },
  classes: { search:'', screen:'list', classId:null, form:null, error:'', saving:false, addStudentSearch:'' },
  attendance: { tab:'overview', period:'week', customStart:'', customEnd:'', screen:'school', classId:null, studentId:null },
  grades: { tab:'overview', view:'byClass', classId:null },
  exams: { search:'', filterClassId:'all', filterStatus:'all', screen:'list', examId:null, form:null, error:'', saving:false },
  homework: { tab:'overview', filterClassId:'all', filterStatus:'all', screen:'list', hwId:null },
  behavior: { tab:'overview', filterClassId:'all' },
  admissions: { tab:'list', search:'', filterStatus:'all', screen:'list', appId:null, form:null, error:'', saving:false },
  orientation: { tab:'list', screen:'list', orId:null, form:null, error:'', saving:false, addParticipantSearch:'' },
  reclamations: { screen:'list', filterStatus:'all', filterPriority:'all', rcId:null, form:null, error:'', saving:false },
  payments: { tab:'overview', search:'', filterClassId:'all', filterStatus:'all', filterMethod:'all', minAmount:'', maxAmount:'', screen:'list', paymentId:null, studentId:null },
  comms: { tab:'main', screen:'list', announcementId:null, compose: { subject:'', message:'', audience:'school', audienceClassId:null, preview:false }, sending:false, error:'', templateForm:null, groupForm:null, templateError:'', groupError:'', historySearch:'', historyAudienceFilter:'all' },
  calendar: { calMonth:2, calYear:2026, selectedDate:null, screen:'month', eventId:null, form:null, error:'', sources:{ events:true, exams:true, homework:true, orientation:true } },
  reports: { tab:'basic', screen:'form', type:'student', classId:null, studentId:null, studentSearch:'', period:'week', error:'', generatedAt:null },
  advReports: { classIds:[], metrics:['grades','attendance','homework'], startDate:'', endDate:'', screen:'form', error:'', savedConfigs:[] },
  import: { tab:'student', step:1, fileName:'', rawHeaders:[], rawRows:[], mapping:{}, validationRows:[], duplicateActions:{}, result:null, error:'' },
  histImport: { type:'grades', step:1, fileName:'', rawHeaders:[], rawRows:[], mapping:{}, validationRows:[], result:null, error:'' },
  accounts: { screen:'generate', personType:'student', search:'', selected:[], listFilterType:'all', listFilterStatus:'all', sheetSelected:[], sheetPreview:false },
  audit: { search:'', filterAction:'all', filterObjectType:'all' },
  config: { editing:false, saving:false, error:'' },
  documents: { search:'', filterCategory:'all', filterAssociated:'all', screen:'list', docId:null, form:null, error:'' },
  support: { tab:'help', helpSearch:'', helpCategory:'all', expandedFaqId:null, screen:'list', form:null, error:'', submitting:false },
  headAccount: { tab:'profile', editing:false, saving:false, error:'', pwSaving:false, pwError:'', pwSuccess:false },
  subscription: { screen:'main', confirmPlan:null },
};

/* ══════════════════════════════════════════════════════
   COMPUTED HELPERS
   Always derived live from HEAD_DATA — aggregates can never drift out of
   sync with the underlying roster, the same discipline used throughout
   the Guardian/Teacher modules.
══════════════════════════════════════════════════════ */
function hGetClass(classId) { return HEAD_DATA.classes.find(c => c.id === classId) || null; }
function hGetTeacher(teacherId) { return HEAD_DATA.teachers.find(t => t.id === teacherId) || null; }
function hGetStudent(studentId) { return HEAD_DATA.students.find(s => s.id === studentId) || null; }
function hGetGuardian(guardianId) { return HEAD_DATA.guardians.find(g => g.id === guardianId) || null; }
function hClassStudents(classId) { return HEAD_DATA.students.filter(s => s.classId === classId); }
function hCampusClasses(campusId) { return HEAD_DATA.classes.filter(c => c.campus === campusId); }
function hCampusStudents(campusId) { const classIds = hCampusClasses(campusId).map(c => c.id); return HEAD_DATA.students.filter(s => classIds.includes(s.classId)); }
function hCampusTeachers(campusId) { const classIds = hCampusClasses(campusId).map(c => c.id); return HEAD_DATA.teachers.filter(te => te.classIds.some(cid => classIds.includes(cid))); }
function hTeacherClasses(teacherId) {
  const teacher = hGetTeacher(teacherId);
  if (!teacher) return [];
  return HEAD_DATA.classes.filter(c => teacher.classIds.includes(c.id));
}
function hAvg(arr) { return arr.length ? Math.round((arr.reduce((s, v) => s + v, 0) / arr.length) * 10) / 10 : null; }
function hStudentFullName(s) { return `${s.firstName} ${s.lastName}`; }
function hStudentNeedsAttention(s) { return s.avgGrade < HEAD_DATA.settings.passThreshold || s.attendanceRate < HEAD_DATA.settings.attendanceThreshold; }

/* ══════════════════════════════════════════════════════
   VIEW ROUTER
══════════════════════════════════════════════════════ */
function headView(v) {
  hState.currentView = v;
  if (v === 'timetable') return hTimetableView();
  if (v === 'home') return hDashboardView();
  if (v === 'intelligence') return hIntelligenceView();
  if (v === 'academics-analytics') return hAcademicAnalyticsPageView();
  if (v === 'risk') return hStudentRiskView();
  if (v === 'students') return hStudentsView();
  if (v === 'teachers') return hTeachersView();
  if (v === 'guardians') return hGuardiansView();
  if (v === 'classes') return hClassesView();
  if (v === 'attendance') return hAttendanceView();
  if (v === 'grades') return hGradesView();
  if (v === 'exams') return hExamsView();
  if (v === 'homework') return hHomeworkView();
  if (v === 'behavior') return hBehaviorView();
  if (v === 'admissions') return hAdmissionsView();
  if (v === 'orientation') return hOrientationView();
  if (v === 'reclamations') return hReclamationsView();
  if (v === 'payments') return hPaymentsView();
  if (v === 'communication') return hCommsView();
  if (v === 'calendar') return hCalendarView();
  if (v === 'reports') return hReportsView();
  if (v === 'import') return hImportView();
  if (v === 'accounts') return hAccountsView();
  if (v === 'audit') return hAuditView();
  if (v === 'config') return hConfigView();
  if (v === 'documents') return hDocumentsView();
  if (v === 'support') return hSupportView();
  if (v === 'account') return hHeadAccountView();
  if (v === 'subscription') return hSubscriptionView();
  return `<div class="card"><div class="card-body" style="color:var(--muted);text-align:center;padding:40px">${t('This section is coming soon.')}</div></div>`;
}
function hShowToast(msg) { gdShowToast(msg); }

/* ══════════════════════════════════════════════════════
   SCHOOL DASHBOARD
   Shows real, computed school-wide metrics only — cards for modules not
   yet built (admissions, exams, homework, live attendance sessions) are
   added in the batches that implement those modules, rather than
   fabricating numbers with nothing behind them.
══════════════════════════════════════════════════════ */
function hDashboardView() {
  return `<div id="h-dashboard-content">${hDashboardBody()}</div>`;
}
function hDashboardBody() {
  if (hState.dashboard.loadState === 'loading') {
    return `<div class="gd-sc-load-state"><span class="gd-spinner"></span>${t('Loading school dashboard…')}</div>`;
  }
  const inst = HEAD_DATA.institution;
  const campusFilter = hState.dashboard.campus;
  const students = campusFilter === 'all' ? HEAD_DATA.students : hCampusStudents(campusFilter);
  const teachers = campusFilter === 'all' ? HEAD_DATA.teachers : hCampusTeachers(campusFilter);
  const guardians = HEAD_DATA.guardians; // guardians are not tied to a single campus in this data model
  const classes = campusFilter === 'all' ? HEAD_DATA.classes : hCampusClasses(campusFilter);
  const academicAvg = hAvg(students.map(s => s.avgGrade));
  const attendanceAvg = hAvg(students.map(s => s.attendanceRate));
  const outstanding = students.filter(s => s.paymentStatus === 'overdue' || s.paymentStatus === 'partial').length;
  const atRisk = students.filter(hStudentNeedsAttention).length;
  const topAlerts = hDetectImportantChanges().slice(0, 2);
  const topProblems = hDetectProblems().slice(0, 2);

  return `
    <div class="card"><div class="card-body" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px">
      <div style="display:flex;align-items:center;gap:12px">
        ${HEAD_DATA.settings.logoDataUrl ? `<img src="${HEAD_DATA.settings.logoDataUrl}" alt="" style="width:40px;height:40px;border-radius:10px;object-fit:cover">` : ''}
        <div>
          <div style="font-size:16px;font-weight:800">${gdCommsEsc(inst.name)}</div>
          <div style="font-size:12.5px;color:var(--muted);margin-top:2px">${gdCommsEsc(inst.academicYear)} · ${gdCommsEsc(inst.currentTerm)}</div>
        </div>
      </div>
      <select onchange="hSetDashboardCampus(this.value)" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
        <option value="all" ${campusFilter==='all'?'selected':''}>${t('All Campuses')}</option>
        ${HEAD_DATA.campuses.map(c => `<option value="${c.id}" ${c.id===campusFilter?'selected':''}>${gdCommsEsc(c.name)}</option>`).join('')}
      </select>
      <button type="button" class="st-btn ghost sm" id="h-refresh-btn" onclick="hRefreshDashboard()">↻ ${t('Refresh')}</button>
    </div></div>

    ${(topAlerts.length || topProblems.length) ? `<div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${aIcon('target')} ${t('Command Center Summary')}</div><div class="card-action" onclick="authrenGoTo('intelligence')">${t('Full Intelligence')} →</div></div>
      <div class="card-body">
        ${topAlerts.map(a => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="authrenGoTo('${a.route}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();authrenGoTo('${a.route}')}"><span>${aIcon('alert-triangle')} ${t(a.label)}</span><span class="status-pill overdue">${t(a.severity.charAt(0).toUpperCase()+a.severity.slice(1))}</span></div>`).join('')}
        ${topProblems.map(p => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="authrenGoTo('${p.route}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();authrenGoTo('${p.route}')}"><span>${aIcon('alert-triangle')} ${gdCommsEsc(p.title)}</span><span class="status-pill ${p.severity==='high'?'overdue':'awaiting'}">${t(p.severity.charAt(0).toUpperCase()+p.severity.slice(1))}</span></div>`).join('')}
      </div></div>` : ''}

    <div class="gd-stat-row" style="margin-top:16px">
      <div class="stat-card" style="cursor:pointer" onclick="hGoToStudents('all')"><div class="stat-label">${t('Total Students')}</div><div class="stat-val">${students.length}</div><div class="stat-icon blue">${aIcon('graduation-cap')}</div></div>
      <div class="stat-card" style="cursor:pointer" onclick="authrenGoTo('teachers')"><div class="stat-label">${t('Total Teachers')}</div><div class="stat-val">${teachers.length}</div><div class="stat-icon purple">${aIcon('user')}</div></div>
      <div class="stat-card" style="cursor:pointer" onclick="authrenGoTo('guardians')"><div class="stat-label">${t('Total Guardians')}</div><div class="stat-val">${guardians.length}</div><div class="stat-icon green">${aIcon('users')}</div></div>
      <div class="stat-card" style="cursor:pointer" onclick="authrenGoTo('classes')"><div class="stat-label">${t('Total Classes')}</div><div class="stat-val">${classes.length}</div><div class="stat-icon yellow">${aIcon('school')}</div></div>
    </div>
    <div class="gd-stat-row" style="margin-top:16px">
      <div class="stat-card" style="cursor:pointer" onclick="authrenGoTo('grades')"><div class="stat-label">${t('Academic Average')}</div><div class="stat-val">${academicAvg}/20</div><div class="stat-icon green">${aIcon('bar-chart')}</div></div>
      <div class="stat-card" style="cursor:pointer" onclick="authrenGoTo('attendance')"><div class="stat-label">${t('Avg. Attendance Rate')}</div><div class="stat-val">${attendanceAvg}%</div><div class="stat-icon blue">${aIcon('check-circle')}</div></div>
      <div class="stat-card" style="cursor:pointer" onclick="hGoToOutstandingPayments()"><div class="stat-label">${t('Outstanding Payments')}</div><div class="stat-val">${outstanding}</div><div class="stat-icon ${outstanding>0?'yellow':'green'}">${aIcon('credit-card')}</div></div>
      <div class="stat-card" style="cursor:pointer" onclick="hGoToStudents('at-risk')"><div class="stat-label">${t('Students Needing Attention')}</div><div class="stat-val">${atRisk}</div><div class="stat-icon ${atRisk>0?'red':'green'}">${aIcon('alert-triangle')}</div></div>
    </div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Classes Overview')}</div></div>
      <div class="card-body">
        ${classes.map(c => {
          const roster = hClassStudents(c.id);
          const teacher = hGetTeacher(c.homeroomTeacherId);
          const avg = hAvg(roster.map(s => s.avgGrade));
          const att = hAvg(roster.map(s => s.attendanceRate));
          return `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hGoToClassFromDashboard('${c.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hGoToClassFromDashboard('${c.id}')}"><span>${gdCommsEsc(c.name)}<div style="font-size:11px;color:var(--muted);margin-top:2px">${t('Homeroom')}: ${teacher ? gdCommsEsc(teacher.name) : '—'} · ${roster.length}/${c.capacity} ${t('students')}</div></span><span style="text-align:right;font-size:12.5px;color:var(--muted)">${avg !== null ? avg + '/20' : '—'} · ${att !== null ? att + '%' : '—'}</span></div>`;
        }).join('')}
      </div></div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Upcoming Exams')}</div><div class="card-action" onclick="authrenGoTo('exams')">${t('View All')} →</div></div>
      <div class="card-body">
        ${HEAD_DATA.exams.filter(e => hExamStatus(e) === 'scheduled').sort((a,b) => (a.date+a.time).localeCompare(b.date+b.time)).map(e => {
          const cls = hGetClass(e.classId);
          return `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hOpenExamFromDashboard('${e.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hOpenExamFromDashboard('${e.id}')}"><span>${gdCommsEsc(e.name)}<div style="font-size:11px;color:var(--muted)">${cls ? gdCommsEsc(cls.name) : ''} · ${e.date}</div></span><span style="color:var(--muted);font-size:12px">${e.time}</span></div>`;
        }).join('') || `<div class="gd-empty-mini">${t('No upcoming exams scheduled.')}</div>`}
      </div></div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Pending Homework')}</div><div class="card-action" onclick="authrenGoTo('homework')">${t('View All')} →</div></div>
      <div class="card-body">
        ${HEAD_DATA.homework.filter(h => h.dueDate >= tISODate(new Date(2026,2,11))).sort((a,b) => a.dueDate.localeCompare(b.dueDate)).map(h => {
          const cls = hGetClass(h.classId);
          const counts = hHomeworkCounts(h);
          return `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hOpenHomeworkFromDashboard('${h.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hOpenHomeworkFromDashboard('${h.id}')}"><span>${gdCommsEsc(h.title)}<div style="font-size:11px;color:var(--muted)">${cls ? gdCommsEsc(cls.name) : ''} · ${t('Due')} ${h.dueDate}</div></span><span style="color:var(--muted);font-size:12px">${counts.submitted}/${counts.total}</span></div>`;
        }).join('') || `<div class="gd-empty-mini">${t('No pending homework.')}</div>`}
      </div></div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Recent Admissions')}</div><div class="card-action" onclick="authrenGoTo('admissions')">${t('View All')} →</div></div>
      <div class="card-body">
        ${HEAD_DATA.admissions.slice().sort((a,b)=>b.submittedDate.localeCompare(a.submittedDate)).slice(0,4).map(a => { const meta = H_ADMISSION_STATUS_META[a.status]; return `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hOpenAdmissionFromDashboard('${a.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hOpenAdmissionFromDashboard('${a.id}')}"><span>${gdCommsEsc(hAdmissionFullName(a))}<div style="font-size:11px;color:var(--muted)">${gdCommsEsc(t(a.appliedLevel))} · ${a.submittedDate}</div></span><span class="status-pill ${meta.cls}">${t(meta.label)}</span></div>`; }).join('') || `<div class="gd-empty-mini">${t('No applications yet.')}</div>`}
      </div></div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Payment Status Overview')}</div></div>
      <div class="card-body">
        <div class="info-row"><span><span class="status-pill paid">${t('Paid')}</span></span><span>${students.filter(s => s.paymentStatus === 'paid').length} ${t('students')}</span></div>
        <div class="info-row"><span><span class="status-pill partial">${t('Partial')}</span></span><span>${students.filter(s => s.paymentStatus === 'partial').length} ${t('students')}</span></div>
        <div class="info-row"><span><span class="status-pill overdue">${t('Overdue')}</span></span><span>${students.filter(s => s.paymentStatus === 'overdue').length} ${t('students')}</span></div>
      </div></div>`;
}
function hOpenExamFromDashboard(examId) {
  hState.exams.screen = 'detail';
  hState.exams.examId = examId;
  authrenGoTo('exams');
}
function hOpenHomeworkFromDashboard(hwId) {
  hState.homework.screen = 'detail';
  hState.homework.hwId = hwId;
  authrenGoTo('homework');
}
function hOpenAdmissionFromDashboard(id) {
  hState.admissions.screen = 'detail';
  hState.admissions.appId = id;
  authrenGoTo('admissions');
}
function hGoToOutstandingPayments() {
  hState.payments.tab = 'history';
  hState.payments.filterStatus = 'overdue';
  hState.payments.filterClassId = 'all';
  hState.payments.search = '';
  authrenGoTo('payments');
}
function hGoToClassFromDashboard(classId) {
  hState.classes.screen = 'detail';
  hState.classes.classId = classId;
  authrenGoTo('classes');
}
function hGoToStudents(statusFilter) {
  hState.students.screen = 'list';
  hState.students.filterStatus = statusFilter;
  hState.students.filterClassId = 'all';
  hState.students.filterLevel = 'all';
  hState.students.search = '';
  authrenGoTo('students');
}
function hSetDashboardCampus(v) {
  hState.dashboard.campus = v;
  const el = document.getElementById('h-dashboard-content');
  if (el) el.innerHTML = hDashboardBody();
}
function hRefreshDashboard() {
  hState.dashboard.loadState = 'loading';
  const el = document.getElementById('h-dashboard-content');
  if (el) el.innerHTML = hDashboardBody();
  setTimeout(() => {
    hState.dashboard.loadState = 'ready';
    const el2 = document.getElementById('h-dashboard-content');
    if (el2) el2.innerHTML = hDashboardBody();
    hShowToast(t('Dashboard refreshed.'));
  }, 700);
}

/* ══════════════════════════════════════════════════════
   STUDENT MANAGEMENT
══════════════════════════════════════════════════════ */
function hStudentsView() {
  return `<div id="h-students-content">${hStudentsBody()}</div>`;
}
function hStudentsBody() {
  const s = hState.students;
  if (s.screen === 'form') return hStudentFormScreen();
  if (s.screen === 'progress') {
    const student = hGetStudent(s.studentId);
    if (!student) { s.screen = 'list'; return hStudentsBody(); }
    return hStudentProgressScreen(student);
  }
  if (s.screen === 'profile') {
    const student = hGetStudent(s.studentId);
    if (!student) { s.screen = 'list'; return hStudentsBody(); }
    return hStudentProfileScreen(student);
  }
  return hStudentListScreen();
}
function hRefreshStudents() { const el = document.getElementById('h-students-content'); if (el) el.innerHTML = hStudentsBody(); }

/* ── List (search + filters + sort) ── */
function hFilteredStudents() {
  const s = hState.students;
  let list = HEAD_DATA.students.slice();
  if (s.filterClassId !== 'all') list = list.filter(x => x.classId === s.filterClassId);
  if (s.filterLevel !== 'all') list = list.filter(x => { const c = hGetClass(x.classId); return c && c.level === s.filterLevel; });
  if (s.filterStatus === 'at-risk') list = list.filter(hStudentNeedsAttention);
  else if (s.filterStatus !== 'all') list = list.filter(x => x.status === s.filterStatus);
  const q = s.search.trim().toLowerCase();
  if (q) list = list.filter(x => hStudentFullName(x).toLowerCase().includes(q) || x.studentId.toLowerCase().includes(q));
  list.sort((a, b) => {
    if (s.sort === 'grade') return b.avgGrade - a.avgGrade;
    if (s.sort === 'attendance') return b.attendanceRate - a.attendanceRate;
    return hStudentFullName(a).localeCompare(hStudentFullName(b));
  });
  return list;
}
function hStudentListScreen() {
  const s = hState.students;
  const levels = Array.from(new Set(HEAD_DATA.classes.map(c => c.level)));
  const filters = [['all', 'All'], ['at-risk', 'Needs Attention']];
  return `
    <div class="card"><div class="card-header"><div class="card-title">${t('Students')}</div><button class="st-btn sm" onclick="hOpenStudentForm()">+ ${t('Add Student')}</button></div>
      <div class="card-body">
        <input class="gd-comm-search-input" type="text" placeholder="${t('Search by name or student ID...')}" value="${gdCommsEsc(s.search)}" oninput="hSetStudentSearch(this.value)">
        <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:10px">
          <select onchange="hSetStudentClassFilter(this.value)" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
            <option value="all" ${s.filterClassId==='all'?'selected':''}>${t('All Classes')}</option>
            ${HEAD_DATA.classes.map(c => `<option value="${c.id}" ${c.id===s.filterClassId?'selected':''}>${gdCommsEsc(c.name)}</option>`).join('')}
          </select>
          <select onchange="hSetStudentLevelFilter(this.value)" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
            <option value="all" ${s.filterLevel==='all'?'selected':''}>${t('All Levels')}</option>
            ${levels.map(l => `<option value="${l}" ${l===s.filterLevel?'selected':''}>${gdCommsEsc(t(l))}</option>`).join('')}
          </select>
          <select onchange="hSetStudentSort(this.value)" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
            <option value="name" ${s.sort==='name'?'selected':''}>${t('Sort: Name')}</option>
            <option value="grade" ${s.sort==='grade'?'selected':''}>${t('Sort: Grade')}</option>
            <option value="attendance" ${s.sort==='attendance'?'selected':''}>${t('Sort: Attendance')}</option>
          </select>
        </div>
        <div class="gd-comm-filter-row" style="margin-top:10px">${filters.map(([id, label]) => `<div class="gd-comm-filter-chip${s.filterStatus===id?' active':''}" onclick="hSetStudentStatusFilter('${id}')">${t(label)}</div>`).join('')}</div>
      </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Roster')}</div><span style="font-size:12px;color:var(--muted)" id="h-student-count">${hFilteredStudents().length} ${t('of')} ${HEAD_DATA.students.length}</span></div>
      <div class="card-body" id="h-student-list-results">${hStudentListResultsBlock()}</div></div>`;
}
function hStudentListResultsBlock() {
  const list = hFilteredStudents();
  if (!list.length) return `<div class="gd-empty-mini">${t('No students match your search or filters.')}</div>`;
  return list.map(st => {
    const cls = hGetClass(st.classId);
    return `<div class="info-row" style="cursor:pointer;align-items:center" role="button" tabindex="0" onclick="hOpenStudentProfile('${st.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hOpenStudentProfile('${st.id}')}">
      <span style="display:flex;align-items:center;gap:10px;min-width:0">
        <span style="width:32px;height:32px;border-radius:50%;background:var(--surface3);display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;flex-shrink:0">${gdInitials(hStudentFullName(st))}</span>
        <span style="min-width:0"><div style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${gdCommsEsc(hStudentFullName(st))}</div><div style="font-size:11px;color:var(--muted)">${gdCommsEsc(st.studentId)} · ${cls ? gdCommsEsc(cls.name) : '—'}</div></span>
      </span>
      <span style="text-align:right;font-size:12.5px;color:var(--muted);flex-shrink:0">
        ${st.avgGrade}/20 · ${st.attendanceRate}%
        <div style="margin-top:4px"><span class="status-pill ${st.paymentStatus}">${t(st.paymentStatus.charAt(0).toUpperCase()+st.paymentStatus.slice(1))}</span></div>
      </span>
    </div>`;
  }).join('');
}
function hSetStudentSearch(v) { hState.students.search = v; hRefreshStudentListResults(); }
function hSetStudentClassFilter(v) { hState.students.filterClassId = v; hRefreshStudentListResults(); }
function hSetStudentLevelFilter(v) { hState.students.filterLevel = v; hRefreshStudentListResults(); }
function hSetStudentSort(v) { hState.students.sort = v; hRefreshStudentListResults(); }
function hSetStudentStatusFilter(v) {
  hState.students.filterStatus = v;
  hRefreshStudents();
}
function hRefreshStudentListResults() {
  const el = document.getElementById('h-student-list-results');
  if (el) el.innerHTML = hStudentListResultsBlock();
  const countEl = document.getElementById('h-student-count');
  if (countEl) countEl.textContent = `${hFilteredStudents().length} ${t('of')} ${HEAD_DATA.students.length}`;
}

/* ── Student Profile ── */
function hOpenStudentProfile(studentId) {
  hState.students.screen = 'profile';
  hState.students.studentId = studentId;
  hRefreshStudents();
}
function hBackToStudentList() {
  hState.students.screen = 'list';
  hState.students.studentId = null;
  hRefreshStudents();
}
function hStudentProfileScreen(student) {
  const cls = hGetClass(student.classId);
  const guardian = hGetGuardian(student.guardianId);
  const attention = hStudentNeedsAttention(student);
  const age = hCalcAge(student.dob);
  const history = hStudentHistory(student);
  return `<div class="card">
    <div class="card-header">
      <div style="display:flex;align-items:center;gap:10px;min-width:0;flex:1">
        <button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="hBackToStudentList()">${t('← Back')}</button>
        <div class="card-title" style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${gdCommsEsc(hStudentFullName(student))}</div>
      </div>
      <button type="button" class="st-btn ghost sm" onclick="hOpenStudentForm('${student.id}')">${t('Edit')}</button>
    </div>
    <div class="card-body">
      <div style="display:flex;align-items:center;gap:14px;padding-bottom:14px;margin-bottom:14px;border-bottom:0.5px solid var(--separator)">
        <div style="width:52px;height:52px;border-radius:50%;background:var(--surface3);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:16px;flex-shrink:0">${gdInitials(hStudentFullName(student))}</div>
        <div style="min-width:0;flex:1">
          <div style="font-size:15px;font-weight:700;color:var(--color-text)">${gdCommsEsc(hStudentFullName(student))}</div>
          <div style="font-size:12px;color:var(--muted);margin-top:2px">${gdCommsEsc(student.studentId)} · ${cls ? gdCommsEsc(cls.name) : t('Unassigned')}</div>
        </div>
        <span class="status-pill ${attention ? 'overdue' : 'paid'}">${attention ? t('Needs Attention') : t('On Track')}</span>
      </div>

      <div class="gd-pay-stat-row">
        <div class="stat-card"><div class="stat-label">${t('Average Grade')}</div><div class="stat-val">${student.avgGrade}/20</div><div class="stat-icon ${student.avgGrade<12?'red':'green'}">${aIcon('bar-chart')}</div></div>
        <div class="stat-card"><div class="stat-label">${t('Attendance Rate')}</div><div class="stat-val">${student.attendanceRate}%</div><div class="stat-icon ${student.attendanceRate<88?'yellow':'green'}">${aIcon('check-circle')}</div></div>
        <div class="stat-card"><div class="stat-label">${t('Payment Status')}</div><div class="stat-val" style="font-size:15px">${t(student.paymentStatus.charAt(0).toUpperCase()+student.paymentStatus.slice(1))}</div><div class="stat-icon ${student.paymentStatus==='paid'?'green':'yellow'}">${aIcon('credit-card')}</div></div>
      </div>
      <button type="button" class="st-btn ghost sm" style="margin-top:12px" onclick="hOpenStudentProgress('${student.id}')">${aIcon('trending-up')} ${t('View Full Progress')} →</button>

      <div style="margin-top:16px;padding-top:14px;border-top:0.5px solid var(--separator)">
        <div style="font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Student Information')}</div>
        <div class="info-row"><span>${t('Date of Birth')}</span><span>${student.dob} (${age})</span></div>
        <div class="info-row"><span>${t('Gender')}</span><span>${student.gender === 'M' ? t('Male') : t('Female')}</span></div>
        <div class="info-row"><span>${t('Class')}</span><span>${cls ? gdCommsEsc(cls.name) : '—'}</span></div>
        <div class="info-row"><span>${t('Academic Level')}</span><span>${cls ? gdCommsEsc(t(cls.level)) : '—'}</span></div>
        <div class="info-row"><span>${t('Enrollment Date')}</span><span>${student.enrollmentDate}</span></div>
        <div class="info-row"><span>${t('Address')}</span><span>${student.address ? gdCommsEsc(student.address) : '—'}</span></div>
      </div>

      <div style="margin-top:16px;padding-top:14px;border-top:0.5px solid var(--separator)">
        <div style="font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Guardian Information')}</div>
        ${guardian ? `
          <div class="info-row"><span>${t('Name')}</span><span>${gdCommsEsc(guardian.name)}</span></div>
          <div class="info-row"><span>${t('Email')}</span><span>${gdCommsEsc(guardian.email)}</span></div>
          <div class="info-row"><span>${t('Phone')}</span><span>${gdCommsEsc(guardian.phone)}</span></div>
          ${guardian.studentIds.length > 1 ? `<div class="info-row"><span>${t('Other Children')}</span><span>${guardian.studentIds.filter(id => id !== student.id).map(id => { const sib = hGetStudent(id); return sib ? gdCommsEsc(hStudentFullName(sib)) : ''; }).join(', ')}</span></div>` : ''}
        ` : `<div class="gd-empty-mini">${t('No guardian linked.')}</div>`}
      </div>

      <div style="margin-top:16px;padding-top:14px;border-top:0.5px solid var(--separator)">
        <div style="font-size:12.5px;font-weight:600;margin-bottom:8px">${t('History')}</div>
        ${history.length ? history.map(ev => {
          const icon = { enrollment: aIcon('graduation-cap'), class: aIcon('school'), guardian: aIcon('users'), exam: aIcon('edit'), homework: aIcon('book'), attendance: aIcon('calendar'), behavior: aIcon('alert-triangle') }[ev.type] || '•';
          return `<div class="info-row"><span>${icon} ${gdCommsEsc(ev.label)}</span><span style="color:var(--muted);font-size:11.5px">${ev.date}</span></div>`;
        }).join('') : `<div class="gd-empty-mini">${t('No history recorded yet.')}</div>`}
      </div>

      <div style="font-size:11.5px;color:var(--muted);margin-top:16px">${t('Exam results, homework activity, and behavior records all appear in the History timeline above.')}</div>
    </div>
  </div>`;
}
function hCalcAge(dobStr) {
  const dob = new Date(dobStr + 'T00:00:00');
  const today = new Date(2026, 2, 11); // fixed demo "today", consistent with the rest of Authren
  let age = today.getFullYear() - dob.getFullYear();
  const m = today.getMonth() - dob.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < dob.getDate())) age--;
  return age + ' ' + t('years');
}
function hStudentHistory(student) {
  const events = [];
  const hasLoggedEnrollment = HEAD_DATA.studentHistoryLog.some(h => h.studentId === student.id && h.type === 'enrollment');
  if (!hasLoggedEnrollment) events.push({ type:'enrollment', label: t('Enrolled at Al Farabi Private School'), date: student.enrollmentDate });

  HEAD_DATA.studentHistoryLog.filter(h => h.studentId === student.id).forEach(h => events.push({ type: h.type, label: h.label, date: h.date }));

  HEAD_DATA.exams.forEach(exam => {
    if (exam.scores[student.id] !== undefined) events.push({ type:'exam', label: `${t('Exam result')}: ${exam.name} — ${exam.scores[student.id]}/${exam.maxScore}`, date: exam.date });
  });

  HEAD_DATA.homework.forEach(hw => {
    if (hw.submissions[student.id] === 'submitted') events.push({ type:'homework', label: `${t('Homework submitted')}: ${hw.title}`, date: hw.dueDate });
    else if (hw.submissions[student.id] === 'late') events.push({ type:'homework', label: `${t('Homework submitted late')}: ${hw.title}`, date: hw.dueDate });
    else if (hw.dueDate < tISODate(new Date(2026, 2, 11))) events.push({ type:'homework', label: `${t('Homework missing')}: ${hw.title}`, date: hw.dueDate });
  });

  H_ATTENDANCE_DAYS.forEach(date => {
    const status = hAttendanceStatusFor(student.id, date);
    if (status === 'absent' || status === 'excused') events.push({ type:'attendance', label: `${status === 'excused' ? t('Excused absence') : t('Absence recorded')}`, date });
  });

  hStudentBehaviorRecordsH(student.id).forEach(r => events.push({ type:'behavior', label: `${t('Behavior')}: ${t(r.category)}`, date: r.date }));

  return events.sort((a, b) => b.date.localeCompare(a.date));
}

/* ── Add / Edit Student form ── */
function hOpenStudentForm(studentId) {
  if (studentId) {
    const student = hGetStudent(studentId);
    if (!student) return;
    const guardian = hGetGuardian(student.guardianId);
    hState.students.form = {
      mode:'edit', id:student.id, firstName:student.firstName, lastName:student.lastName, studentId:student.studentId,
      dob:student.dob, gender:student.gender, classId:student.classId, address:student.address || '',
      enrollmentDate:student.enrollmentDate, guardianMode:'existing', guardianId:student.guardianId, guardianSearch:'',
      newGuardianName:'', newGuardianEmail:'', newGuardianPhone:'',
    };
  } else {
    hState.students.form = {
      mode:'create', id:null, firstName:'', lastName:'', studentId:'', dob:'', gender:'M',
      classId: HEAD_DATA.classes[0] ? HEAD_DATA.classes[0].id : '', address:'', enrollmentDate: tISODate(new Date(2026, 2, 11)),
      guardianMode:'existing', guardianId:null, guardianSearch:'', newGuardianName:'', newGuardianEmail:'', newGuardianPhone:'',
    };
  }
  hState.students.screen = 'form';
  hState.students.error = '';
  hRefreshStudents();
}
function hCancelStudentForm() {
  hState.students.screen = (hState.students.form && hState.students.form.mode === 'edit') ? 'profile' : 'list';
  hState.students.form = null;
  hState.students.error = '';
  hRefreshStudents();
}
function hSetStudentGuardianMode(mode) {
  hState.students.form.guardianMode = mode;
  hRefreshStudents();
}
function hSetFormGuardianSearch(v) {
  hState.students.form.guardianSearch = v;
  const el = document.getElementById('h-form-guardian-results');
  if (el) el.innerHTML = hFormGuardianResultsBlock();
}
function hFormGuardianResultsBlock() {
  const f = hState.students.form;
  const q = f.guardianSearch.trim().toLowerCase();
  if (!q) return '';
  const results = HEAD_DATA.guardians.filter(g => g.name.toLowerCase().includes(q) || g.email.toLowerCase().includes(q));
  if (!results.length) return `<div class="gd-empty-mini" style="text-align:left;padding:8px 0 0">${t('No guardians match your search.')}</div>`;
  return `<div style="margin-top:8px">${results.map(g => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hSelectFormGuardian('${g.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hSelectFormGuardian('${g.id}')}">
    <span>${gdCommsEsc(g.name)}</span><span style="color:var(--muted);font-size:12px">${gdCommsEsc(g.email)}</span>
  </div>`).join('')}</div>`;
}
function hSelectFormGuardian(id) {
  hState.students.form.guardianId = id;
  hState.students.form.guardianSearch = '';
  hRefreshStudents();
}
function hStudentFormScreen() {
  const f = hState.students.form;
  const err = hState.students.error;
  const selectedGuardian = f.guardianId ? hGetGuardian(f.guardianId) : null;
  return `<div class="card"><div class="card-header"><div class="card-title">${f.mode==='edit'?t('Edit Student'):t('Add Student')}</div></div>
    <div class="card-body">
      <div style="display:flex;gap:10px">
        <div class="st-field" style="flex:1"><label>${t('First Name')}</label><input id="h-st-firstname" value="${gdCommsEsc(f.firstName)}"></div>
        <div class="st-field" style="flex:1"><label>${t('Last Name')}</label><input id="h-st-lastname" value="${gdCommsEsc(f.lastName)}"></div>
      </div>
      <div class="st-field"><label>${t('Student ID')}</label><input id="h-st-studentid" value="${gdCommsEsc(f.studentId)}" placeholder="${t('e.g. S4000031')}" ${f.mode==='edit'?'disabled':''}></div>
      <div style="display:flex;gap:10px">
        <div class="st-field" style="flex:1"><label>${t('Date of Birth')}</label><input id="h-st-dob" type="date" value="${f.dob}"></div>
        <div class="st-field" style="flex:1"><label>${t('Gender')}</label><select id="h-st-gender">
          <option value="M" ${f.gender==='M'?'selected':''}>${t('Male')}</option>
          <option value="F" ${f.gender==='F'?'selected':''}>${t('Female')}</option>
        </select></div>
      </div>
      <div class="st-field"><label>${t('Class')}</label><select id="h-st-class">
        ${HEAD_DATA.classes.map(c => `<option value="${c.id}" ${c.id===f.classId?'selected':''}>${gdCommsEsc(c.name)} — ${gdCommsEsc(t(c.level))}</option>`).join('')}
      </select></div>
      <div class="st-field"><label>${t('Address')}</label><input id="h-st-address" value="${gdCommsEsc(f.address)}" placeholder="${t('Street, city')}"></div>
      <div class="st-field"><label>${t('Enrollment Date')}</label><input id="h-st-enrolldate" type="date" value="${f.enrollmentDate}"></div>

      <div class="st-field">
        <label>${t('Guardian')}</label>
        <div class="gd-comm-filter-row" style="margin-bottom:8px">
          <div class="gd-comm-filter-chip${f.guardianMode==='existing'?' active':''}" onclick="hSetStudentGuardianMode('existing')">${t('Link Existing')}</div>
          <div class="gd-comm-filter-chip${f.guardianMode==='new'?' active':''}" onclick="hSetStudentGuardianMode('new')">${t('Add New')}</div>
        </div>
        ${f.guardianMode === 'existing' ? `
          ${selectedGuardian ? `<div class="info-row"><span>${gdCommsEsc(selectedGuardian.name)}</span><span class="card-action" onclick="hSelectFormGuardian(null)">${t('Change')}</span></div>`
            : `<input class="gd-comm-search-input" type="text" placeholder="${t('Search guardians by name or email...')}" value="${gdCommsEsc(f.guardianSearch)}" oninput="hSetFormGuardianSearch(this.value)"><div id="h-form-guardian-results">${hFormGuardianResultsBlock()}</div>`}
        ` : `
          <input id="h-st-newguardianname" placeholder="${t('Guardian full name')}" value="${gdCommsEsc(f.newGuardianName)}" style="margin-bottom:8px">
          <input id="h-st-newguardianemail" type="email" placeholder="${t('Guardian email')}" value="${gdCommsEsc(f.newGuardianEmail)}" style="margin-bottom:8px">
          <input id="h-st-newguardianphone" placeholder="${t('Guardian phone')}" value="${gdCommsEsc(f.newGuardianPhone)}">
        `}
      </div>

      <div style="display:flex;gap:10px;margin-top:6px">
        <button class="st-btn" onclick="hSaveStudent()" ${hState.students.saving?'disabled':''}>${hState.students.saving ? `<span class="gd-spinner"></span>${t('Saving...')}` : (f.mode==='edit'?t('Save Changes'):t('Create Student'))}</button>
        <button class="st-btn ghost" onclick="hCancelStudentForm()" ${hState.students.saving?'disabled':''}>${t('Cancel')}</button>
      </div>
      ${err ? `<div class="st-inline-msg err show" style="margin-top:12px">${err}</div>` : ''}
    </div></div>`;
}

function hSaveStudent() {
  const f = hState.students.form;
  const firstName = (document.getElementById('h-st-firstname').value || '').trim();
  const lastName = (document.getElementById('h-st-lastname').value || '').trim();
  const studentId = (document.getElementById('h-st-studentid').value || '').trim().toUpperCase();
  const dob = document.getElementById('h-st-dob').value;
  const gender = document.getElementById('h-st-gender').value;
  const classId = document.getElementById('h-st-class').value;
  const address = (document.getElementById('h-st-address').value || '').trim();
  const enrollmentDate = document.getElementById('h-st-enrolldate').value;
  Object.assign(f, { firstName, lastName, studentId, dob, gender, classId, address, enrollmentDate });

  let err = '';
  if (!firstName) err = t('First name is required.');
  else if (!lastName) err = t('Last name is required.');
  else if (!studentId) err = t('Student ID is required.');
  else if (f.mode === 'create' && HEAD_DATA.students.some(s => s.studentId.toUpperCase() === studentId)) err = t('This Student ID is already in use. Please choose a different one.');
  else if (!dob) err = t('Date of birth is required.');
  else if (!classId) err = t('Select a class.');
  else if (!enrollmentDate) err = t('Enrollment date is required.');
  else if (f.guardianMode === 'existing' && !f.guardianId) err = t('Select a guardian, or switch to Add New.');
  else if (f.guardianMode === 'new') {
    const newName = (document.getElementById('h-st-newguardianname').value || '').trim();
    const newEmail = (document.getElementById('h-st-newguardianemail').value || '').trim();
    const newPhone = (document.getElementById('h-st-newguardianphone').value || '').trim();
    f.newGuardianName = newName; f.newGuardianEmail = newEmail; f.newGuardianPhone = newPhone;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!newName) err = t("Enter the new guardian's name.");
    else if (!newEmail || !emailRegex.test(newEmail)) err = t('Enter a valid guardian email.');
    else if (!newPhone) err = t("Enter the new guardian's phone number.");
  }

  hState.students.error = err;
  if (err) { hRefreshStudents(); return; }

  hState.students.saving = true;
  hRefreshStudents();
  setTimeout(() => {
    let guardianId = f.guardianId;
    if (f.guardianMode === 'new') {
      const newGuardian = { id:'hg' + Date.now(), name:f.newGuardianName, email:f.newGuardianEmail, phone:f.newGuardianPhone, studentIds:[] };
      HEAD_DATA.guardians.push(newGuardian);
      guardianId = newGuardian.id;
    }
    if (f.mode === 'edit') {
      const student = hGetStudent(f.id);
      const oldGuardian = hGetGuardian(student.guardianId);
      const oldClassId = student.classId;
      const oldSnapshot = `${student.firstName} ${student.lastName}, ${hGetClass(oldClassId) ? hGetClass(oldClassId).name : t('Unassigned')}`;
      if (oldGuardian && oldGuardian.id !== guardianId) oldGuardian.studentIds = oldGuardian.studentIds.filter(id => id !== student.id);
      Object.assign(student, { firstName, lastName, dob, gender, classId, address, enrollmentDate, guardianId });
      const newGuardianRef = hGetGuardian(guardianId);
      if (newGuardianRef && !newGuardianRef.studentIds.includes(student.id)) newGuardianRef.studentIds.push(student.id);
      if (oldClassId !== classId) {
        const newCls = hGetClass(classId);
        hLogStudentHistory(student.id, 'class', `${t('Class changed to')} ${newCls ? newCls.name : t('Unassigned')}`);
      }
      hLogAudit('Student Edited', 'Student', `${firstName} ${lastName} (${student.studentId})`, oldSnapshot, `${firstName} ${lastName}, ${hGetClass(classId) ? hGetClass(classId).name : t('Unassigned')}`);
      hState.students.screen = 'profile';
      hState.students.studentId = student.id;
      hShowToast(t('Student updated successfully.'));
    } else {
      const newStudent = {
        id:'hs' + Date.now(), studentId, firstName, lastName, dob, gender, classId, guardianId,
        enrollmentDate, status:'active', avgGrade:0, attendanceRate:100, paymentStatus:'paid',
        address, _createdAt: tISODate(new Date(2026, 2, 11)),
      };
      HEAD_DATA.students.push(newStudent);
      const guardianRef = hGetGuardian(guardianId);
      if (guardianRef && !guardianRef.studentIds.includes(newStudent.id)) guardianRef.studentIds.push(newStudent.id);
      hLogStudentHistory(newStudent.id, 'enrollment', t('Student record created'), newStudent._createdAt);
      hLogAudit('Student Created', 'Student', `${firstName} ${lastName} (${studentId})`, '', `${hGetClass(classId) ? hGetClass(classId).name : t('Unassigned')}`);
      hState.students.screen = 'profile';
      hState.students.studentId = newStudent.id;
      hShowToast(t('Student created successfully.'));
    }
    hState.students.saving = false;
    hState.students.form = null;
    hRefreshStudents();
  }, 700);
}

/* ══════════════════════════════════════════════════════
   TEACHER MANAGEMENT
══════════════════════════════════════════════════════ */
function hTeacherWorkload(teacherId) {
  const classes = hTeacherClasses(teacherId);
  const studentCount = classes.reduce((sum, c) => sum + hClassStudents(c.id).length, 0);
  return { classCount: classes.length, studentCount };
}
function hAllSubjects() {
  const seen = {};
  HEAD_DATA.teachers.forEach(te => te.subjects.forEach(s => { seen[s] = true; }));
  return Object.keys(seen);
}
function hTeachersView() {
  const tabs = [ { id:'directory', label:'Directory' }, { id:'analytics', label:'Analytics' } ];
  return `<div class="st-tabs">${tabs.map(tb => `<div class="st-tab gd-tab-htea${tb.id===hState.teachers.tab?' active':''}" data-tab="${tb.id}" onclick="hSetTeachersTab('${tb.id}')">${t(tb.label)}</div>`).join('')}</div>
    <div id="h-teachers-content">${hTeachersTabBody()}</div>`;
}
function hSetTeachersTab(tabId) {
  hState.teachers.tab = tabId;
  document.querySelectorAll('.gd-tab-htea').forEach(el => el.classList.toggle('active', el.dataset.tab === tabId));
  const el = document.getElementById('h-teachers-content');
  if (el) el.innerHTML = hTeachersTabBody();
}
function hTeachersTabBody() {
  return hState.teachers.tab === 'analytics' ? hTeacherAnalyticsTab() : hTeachersBody();
}
function hTeachersBody() {
  const s = hState.teachers;
  if (s.screen === 'form') return hTeacherFormScreen();
  if (s.screen === 'profile') {
    const teacher = hGetTeacher(s.teacherId);
    if (!teacher) { s.screen = 'list'; return hTeachersBody(); }
    return hTeacherProfileScreen(teacher);
  }
  return hTeacherListScreen();
}
function hRefreshTeachers() { const el = document.getElementById('h-teachers-content'); if (el) el.innerHTML = hTeachersBody(); }

function hFilteredTeachers() {
  const s = hState.teachers;
  let list = HEAD_DATA.teachers.slice();
  if (s.filterSubject !== 'all') list = list.filter(te => te.subjects.includes(s.filterSubject));
  const q = s.search.trim().toLowerCase();
  if (q) list = list.filter(te => te.name.toLowerCase().includes(q) || te.teacherId.toLowerCase().includes(q));
  return list.sort((a, b) => a.name.localeCompare(b.name));
}
function hTeacherListScreen() {
  const s = hState.teachers;
  const subjects = hAllSubjects();
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Teachers')}</div><button class="st-btn sm" onclick="hOpenTeacherForm()">+ ${t('Add Teacher')}</button></div>
    <div class="card-body">
      <input class="gd-comm-search-input" type="text" placeholder="${t('Search by name or teacher ID...')}" value="${gdCommsEsc(s.search)}" oninput="hSetTeacherSearch(this.value)">
      <select onchange="hSetTeacherSubjectFilter(this.value)" style="margin-top:10px;background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
        <option value="all" ${s.filterSubject==='all'?'selected':''}>${t('All Subjects')}</option>
        ${subjects.map(sub => `<option value="${sub}" ${sub===s.filterSubject?'selected':''}>${gdCommsEsc(t(sub))}</option>`).join('')}
      </select>
    </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Directory')}</div></div>
      <div class="card-body" id="h-teacher-list-results">${hTeacherListResultsBlock()}</div></div>`;
}
function hTeacherListResultsBlock() {
  const list = hFilteredTeachers();
  if (!list.length) return `<div class="gd-empty-mini">${t('No teachers match your search or filters.')}</div>`;
  return list.map(te => {
    const wl = hTeacherWorkload(te.id);
    return `<div class="info-row" style="cursor:pointer;align-items:center" role="button" tabindex="0" onclick="hOpenTeacherProfile('${te.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hOpenTeacherProfile('${te.id}')}">
      <span style="display:flex;align-items:center;gap:10px;min-width:0">
        <span style="width:32px;height:32px;border-radius:50%;background:var(--surface3);display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;flex-shrink:0">${gdInitials(te.name)}</span>
        <span style="min-width:0"><div style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${gdCommsEsc(te.name)}</div><div style="font-size:11px;color:var(--muted)">${gdCommsEsc(te.teacherId)} · ${te.subjects.map(x => gdCommsEsc(t(x))).join(', ')}</div></span>
      </span>
      <span style="text-align:right;font-size:12.5px;color:var(--muted);flex-shrink:0">${wl.classCount} ${t('classes')} · ${wl.studentCount} ${t('students')}</span>
    </div>`;
  }).join('');
}
function hSetTeacherSearch(v) { hState.teachers.search = v; hRefreshTeacherListResults(); }
function hSetTeacherSubjectFilter(v) { hState.teachers.filterSubject = v; hRefreshTeacherListResults(); }
function hRefreshTeacherListResults() { const el = document.getElementById('h-teacher-list-results'); if (el) el.innerHTML = hTeacherListResultsBlock(); }

/* ── Teacher Profile (with real Assign/Remove Class & Subject actions) ── */
function hOpenTeacherProfile(teacherId) {
  hState.teachers.screen = 'profile';
  hState.teachers.teacherId = teacherId;
  hState.teachers.addSubjectDraft = '';
  hRefreshTeachers();
}
function hBackToTeacherList() {
  hState.teachers.screen = 'list';
  hState.teachers.teacherId = null;
  hRefreshTeachers();
}
function hTeacherProfileScreen(teacher) {
  const wl = hTeacherWorkload(teacher.id);
  const assignedClasses = hTeacherClasses(teacher.id);
  const unassignedClasses = HEAD_DATA.classes.filter(c => !teacher.classIds.includes(c.id));
  return `<div class="card">
    <div class="card-header">
      <div style="display:flex;align-items:center;gap:10px;min-width:0;flex:1">
        <button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="hBackToTeacherList()">${t('← Back')}</button>
        <div class="card-title" style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${gdCommsEsc(teacher.name)}</div>
      </div>
      <button type="button" class="st-btn ghost sm" onclick="hOpenTeacherForm('${teacher.id}')">${t('Edit')}</button>
    </div>
    <div class="card-body" id="h-teacher-profile-body">${hTeacherProfileBody(teacher, wl, assignedClasses, unassignedClasses)}</div>
  </div>`;
}
function hTeacherProfileBody(teacher, wl, assignedClasses, unassignedClasses) {
  return `
    <div style="display:flex;align-items:center;gap:14px;padding-bottom:14px;margin-bottom:14px;border-bottom:0.5px solid var(--separator)">
      <div style="width:52px;height:52px;border-radius:50%;background:var(--surface3);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:16px;flex-shrink:0">${gdInitials(teacher.name)}</div>
      <div style="min-width:0;flex:1">
        <div style="font-size:15px;font-weight:700;color:var(--color-text)">${gdCommsEsc(teacher.name)}</div>
        <div style="font-size:12px;color:var(--muted);margin-top:2px">${gdCommsEsc(teacher.teacherId)}</div>
      </div>
      <span class="status-pill ${teacher.status==='active'?'paid':'resolved'}">${t(teacher.status.charAt(0).toUpperCase()+teacher.status.slice(1))}</span>
    </div>
    <div class="gd-pay-stat-row">
      <div class="stat-card"><div class="stat-label">${t('Classes')}</div><div class="stat-val">${wl.classCount}</div><div class="stat-icon blue">${aIcon('school')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Students')}</div><div class="stat-val">${wl.studentCount}</div><div class="stat-icon purple">${aIcon('users')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Joined')}</div><div class="stat-val" style="font-size:15px">${teacher.joinedDate}</div><div class="stat-icon green">${aIcon('calendar')}</div></div>
    </div>
    <div style="margin-top:16px;padding-top:14px;border-top:0.5px solid var(--separator)">
      <div style="font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Contact Information')}</div>
      <div class="info-row"><span>${t('Email')}</span><span>${gdCommsEsc(teacher.email)}</span></div>
      <div class="info-row"><span>${t('Phone')}</span><span>${gdCommsEsc(teacher.phone)}</span></div>
    </div>
    <div style="margin-top:16px;padding-top:14px;border-top:0.5px solid var(--separator)">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
        <span style="font-size:12.5px;font-weight:600">${t('Subjects')}</span>
      </div>
      <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px">
        ${teacher.subjects.map(sub => `<span style="display:inline-flex;align-items:center;gap:6px;background:var(--surface2);border:1px solid var(--border);border-radius:8px;padding:4px 8px;font-size:11.5px">${gdCommsEsc(t(sub))}${teacher.subjects.length > 1 ? ` <span style="cursor:pointer;color:var(--red)" onclick="hRemoveTeacherSubject('${teacher.id}','${gdCommsEsc(sub).replace(/'/g, "\\'")}')">${aIcon('x')}</span>` : ''}</span>`).join('')}
      </div>
      <div style="display:flex;gap:8px">
        <input id="h-teacher-add-subject" placeholder="${t('New subject name...')}" value="${gdCommsEsc(hState.teachers.addSubjectDraft)}" style="flex:1;background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
        <button type="button" class="st-btn ghost sm" onclick="hAddTeacherSubject('${teacher.id}')">${t('Add Subject')}</button>
      </div>
    </div>
    <div style="margin-top:16px;padding-top:14px;border-top:0.5px solid var(--separator)">
      <div style="font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Assigned Classes')}</div>
      ${assignedClasses.length ? assignedClasses.map(c => `<div class="info-row"><span>${gdCommsEsc(c.name)}<div style="font-size:11px;color:var(--muted)">${hClassStudents(c.id).length} ${t('students')}</div></span><button type="button" class="st-btn ghost sm" onclick="hRemoveTeacherClass('${teacher.id}','${c.id}')">${t('Remove')}</button></div>`).join('') : `<div class="gd-empty-mini">${t('No classes assigned yet.')}</div>`}
      ${unassignedClasses.length ? `<div style="display:flex;gap:8px;margin-top:10px">
        <select id="h-teacher-assign-class" style="flex:1;background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
          ${unassignedClasses.map(c => `<option value="${c.id}">${gdCommsEsc(c.name)}</option>`).join('')}
        </select>
        <button type="button" class="st-btn ghost sm" onclick="hAssignTeacherClass('${teacher.id}')">${t('Assign Class')}</button>
      </div>` : ''}
    </div>
    <div style="font-size:11.5px;color:var(--muted);margin-top:16px">${t('Detailed teaching activity (grade entry, homework, attendance) will appear here once Teacher Analytics is available.')}</div>`;
}
function hRefreshTeacherProfile() {
  const teacher = hGetTeacher(hState.teachers.teacherId);
  if (!teacher) return;
  const wl = hTeacherWorkload(teacher.id);
  const assignedClasses = hTeacherClasses(teacher.id);
  const unassignedClasses = HEAD_DATA.classes.filter(c => !teacher.classIds.includes(c.id));
  const el = document.getElementById('h-teacher-profile-body');
  if (el) el.innerHTML = hTeacherProfileBody(teacher, wl, assignedClasses, unassignedClasses);
}
function hAssignTeacherClass(teacherId) {
  const teacher = hGetTeacher(teacherId);
  const sel = document.getElementById('h-teacher-assign-class');
  if (!teacher || !sel || !sel.value) return;
  if (!teacher.classIds.includes(sel.value)) teacher.classIds.push(sel.value);
  const cls = hGetClass(sel.value);
  hLogAudit('Teacher Assigned', 'Teacher', teacher.name, '', cls ? cls.name : '');
  hRefreshTeacherProfile();
  hShowToast(t('Class assigned successfully.'));
}
function hRemoveTeacherClass(teacherId, classId) {
  const teacher = hGetTeacher(teacherId);
  if (!teacher) return;
  teacher.classIds = teacher.classIds.filter(id => id !== classId);
  hRefreshTeacherProfile();
  hShowToast(t('Class assignment removed.'));
}
function hAddTeacherSubject(teacherId) {
  const teacher = hGetTeacher(teacherId);
  const input = document.getElementById('h-teacher-add-subject');
  const val = input ? input.value.trim() : '';
  hState.teachers.addSubjectDraft = val;
  if (!teacher || !val) return;
  if (teacher.subjects.some(s => s.toLowerCase() === val.toLowerCase())) { hShowToast(t('This teacher already teaches that subject.')); return; }
  teacher.subjects.push(val);
  hState.teachers.addSubjectDraft = '';
  hRefreshTeacherProfile();
  hShowToast(t('Subject added successfully.'));
}
function hRemoveTeacherSubject(teacherId, subject) {
  const teacher = hGetTeacher(teacherId);
  if (!teacher || teacher.subjects.length <= 1) return; // a teacher must keep at least one subject
  teacher.subjects = teacher.subjects.filter(s => s !== subject);
  hRefreshTeacherProfile();
  hShowToast(t('Subject removed.'));
}

/* ── Add / Edit Teacher form ── */
function hOpenTeacherForm(teacherId) {
  if (teacherId) {
    const teacher = hGetTeacher(teacherId);
    if (!teacher) return;
    hState.teachers.form = { mode:'edit', id:teacher.id, name:teacher.name, teacherId:teacher.teacherId, subjects:teacher.subjects.join(', '), email:teacher.email, phone:teacher.phone };
  } else {
    hState.teachers.form = { mode:'create', id:null, name:'', teacherId:'', subjects:'', email:'', phone:'' };
  }
  hState.teachers.screen = 'form';
  hState.teachers.error = '';
  hRefreshTeachers();
}
function hCancelTeacherForm() {
  hState.teachers.screen = (hState.teachers.form && hState.teachers.form.mode === 'edit') ? 'profile' : 'list';
  hState.teachers.form = null;
  hState.teachers.error = '';
  hRefreshTeachers();
}
function hTeacherFormScreen() {
  const f = hState.teachers.form;
  const err = hState.teachers.error;
  return `<div class="card"><div class="card-header"><div class="card-title">${f.mode==='edit'?t('Edit Teacher'):t('Add Teacher')}</div></div>
    <div class="card-body">
      <div class="st-field"><label>${t('Full Name')}</label><input id="h-te-name" value="${gdCommsEsc(f.name)}"></div>
      <div class="st-field"><label>${t('Teacher ID')}</label><input id="h-te-id" value="${gdCommsEsc(f.teacherId)}" placeholder="${t('e.g. T7890123')}" ${f.mode==='edit'?'disabled':''}></div>
      <div class="st-field"><label>${t('Subjects')} (${t('comma-separated')})</label><input id="h-te-subjects" value="${gdCommsEsc(f.subjects)}" placeholder="${t('e.g. Mathematics, Physics')}"></div>
      <div class="st-field"><label>${t('Email')}</label><input id="h-te-email" type="email" value="${gdCommsEsc(f.email)}"></div>
      <div class="st-field"><label>${t('Phone')}</label><input id="h-te-phone" type="tel" value="${gdCommsEsc(f.phone)}"></div>
      <div style="display:flex;gap:10px">
        <button class="st-btn" onclick="hSaveTeacher()" ${hState.teachers.saving?'disabled':''}>${hState.teachers.saving ? `<span class="gd-spinner"></span>${t('Saving...')}` : (f.mode==='edit'?t('Save Changes'):t('Create Teacher'))}</button>
        <button class="st-btn ghost" onclick="hCancelTeacherForm()" ${hState.teachers.saving?'disabled':''}>${t('Cancel')}</button>
      </div>
      ${err ? `<div class="st-inline-msg err show" style="margin-top:12px">${err}</div>` : ''}
    </div></div>`;
}
function hSaveTeacher() {
  const f = hState.teachers.form;
  const name = (document.getElementById('h-te-name').value || '').trim();
  const teacherId = (document.getElementById('h-te-id').value || '').trim().toUpperCase();
  const subjectsRaw = (document.getElementById('h-te-subjects').value || '').trim();
  const email = (document.getElementById('h-te-email').value || '').trim();
  const phone = (document.getElementById('h-te-phone').value || '').trim();
  Object.assign(f, { name, teacherId, subjects:subjectsRaw, email, phone });

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const phoneRegex = /^[+]?[\d][\d\s().-]{6,18}\d$/;
  let err = '';
  if (!name) err = t('Full name is required.');
  else if (!teacherId) err = t('Teacher ID is required.');
  else if (f.mode === 'create' && HEAD_DATA.teachers.some(te => te.teacherId.toUpperCase() === teacherId)) err = t('This Teacher ID is already in use. Please choose a different one.');
  else if (!subjectsRaw) err = t('Enter at least one subject.');
  else if (!email || !emailRegex.test(email)) err = t('Enter a valid email address.');
  else if (!phone || !phoneRegex.test(phone)) err = t('Enter a valid phone number.');

  hState.teachers.error = err;
  if (err) { hRefreshTeachers(); return; }

  hState.teachers.saving = true;
  hRefreshTeachers();
  setTimeout(() => {
    const subjects = subjectsRaw.split(',').map(x => x.trim()).filter(Boolean);
    if (f.mode === 'edit') {
      const teacher = hGetTeacher(f.id);
      Object.assign(teacher, { name, subjects, email, phone });
      hState.teachers.screen = 'profile';
      hState.teachers.teacherId = teacher.id;
      hShowToast(t('Teacher updated successfully.'));
    } else {
      const newTeacher = { id:'ht' + Date.now(), teacherId, name, subjects, classIds:[], email, phone, status:'active', joinedDate: tISODate(new Date(2026, 2, 11)) };
      HEAD_DATA.teachers.push(newTeacher);
      hState.teachers.screen = 'profile';
      hState.teachers.teacherId = newTeacher.id;
      hShowToast(t('Teacher created successfully.'));
    }
    hState.teachers.saving = false;
    hState.teachers.form = null;
    hRefreshTeachers();
  }, 700);
}

/* ══════════════════════════════════════════════════════
   GUARDIAN MANAGEMENT
══════════════════════════════════════════════════════ */
function hGuardianPaymentSummary(guardian) {
  const kids = guardian.studentIds.map(hGetStudent).filter(Boolean);
  if (!kids.length) return null;
  const overdue = kids.filter(s => s.paymentStatus === 'overdue').length;
  const partial = kids.filter(s => s.paymentStatus === 'partial').length;
  return { overdue, partial, paid: kids.length - overdue - partial, total: kids.length };
}
function hGuardiansView() {
  return `<div id="h-guardians-content">${hGuardiansBody()}</div>`;
}
function hGuardiansBody() {
  const s = hState.guardians;
  if (s.screen === 'form') return hGuardianFormScreen();
  if (s.screen === 'profile') {
    const guardian = hGetGuardian(s.guardianId);
    if (!guardian) { s.screen = 'list'; return hGuardiansBody(); }
    return hGuardianProfileScreen(guardian);
  }
  return hGuardianListScreen();
}
function hRefreshGuardians() { const el = document.getElementById('h-guardians-content'); if (el) el.innerHTML = hGuardiansBody(); }

function hFilteredGuardians() {
  const s = hState.guardians;
  let list = HEAD_DATA.guardians.slice();
  const q = s.search.trim().toLowerCase();
  if (q) list = list.filter(g => g.name.toLowerCase().includes(q) || g.email.toLowerCase().includes(q));
  return list.sort((a, b) => a.name.localeCompare(b.name));
}
function hGuardianListScreen() {
  const s = hState.guardians;
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Guardians')}</div><button class="st-btn sm" onclick="hOpenGuardianForm()">+ ${t('Add Guardian')}</button></div>
    <div class="card-body">
      <input class="gd-comm-search-input" type="text" placeholder="${t('Search by name or email...')}" value="${gdCommsEsc(s.search)}" oninput="hSetGuardianSearch(this.value)">
    </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Directory')}</div></div>
      <div class="card-body" id="h-guardian-list-results">${hGuardianListResultsBlock()}</div></div>`;
}
function hGuardianListResultsBlock() {
  const list = hFilteredGuardians();
  if (!list.length) return `<div class="gd-empty-mini">${t('No guardians match your search.')}</div>`;
  return list.map(g => `<div class="info-row" style="cursor:pointer;align-items:center" role="button" tabindex="0" onclick="hOpenGuardianProfile('${g.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hOpenGuardianProfile('${g.id}')}">
    <span style="display:flex;align-items:center;gap:10px;min-width:0">
      <span style="width:32px;height:32px;border-radius:50%;background:var(--surface3);display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;flex-shrink:0">${gdInitials(g.name)}</span>
      <span style="min-width:0"><div style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${gdCommsEsc(g.name)}</div><div style="font-size:11px;color:var(--muted)">${gdCommsEsc(g.email)}</div></span>
    </span>
    <span style="text-align:right;font-size:12.5px;color:var(--muted);flex-shrink:0">${g.studentIds.length} ${t(g.studentIds.length===1?'child':'children')}</span>
  </div>`).join('');
}
function hSetGuardianSearch(v) { hState.guardians.search = v; const el = document.getElementById('h-guardian-list-results'); if (el) el.innerHTML = hGuardianListResultsBlock(); }

/* ── Guardian Profile (real linked-student cross-nav + Link/Unlink) ── */
function hOpenGuardianProfile(guardianId) {
  hState.guardians.screen = 'profile';
  hState.guardians.guardianId = guardianId;
  hState.guardians.linkSearch = '';
  hRefreshGuardians();
}
function hBackToGuardianList() {
  hState.guardians.screen = 'list';
  hState.guardians.guardianId = null;
  hRefreshGuardians();
}
function hGoToStudentFromGuardian(studentId) {
  const student = hGetStudent(studentId);
  if (!student) return;
  hState.students.screen = 'profile';
  hState.students.studentId = studentId;
  authrenGoTo('students');
}
function hGuardianProfileScreen(guardian) {
  return `<div class="card">
    <div class="card-header">
      <div style="display:flex;align-items:center;gap:10px;min-width:0;flex:1">
        <button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="hBackToGuardianList()">${t('← Back')}</button>
        <div class="card-title" style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${gdCommsEsc(guardian.name)}</div>
      </div>
      <button type="button" class="st-btn ghost sm" onclick="hOpenGuardianForm('${guardian.id}')">${t('Edit')}</button>
    </div>
    <div class="card-body" id="h-guardian-profile-body">${hGuardianProfileBody(guardian)}</div>
  </div>`;
}
function hGuardianProfileBody(guardian) {
  const kids = guardian.studentIds.map(hGetStudent).filter(Boolean);
  const paySummary = hGuardianPaymentSummary(guardian);
  const unlinkedStudents = HEAD_DATA.students.filter(s => s.guardianId !== guardian.id);
  const q = hState.guardians.linkSearch.trim().toLowerCase();
  const linkResults = q ? unlinkedStudents.filter(s => hStudentFullName(s).toLowerCase().includes(q) || s.studentId.toLowerCase().includes(q)) : [];
  return `
    <div style="display:flex;align-items:center;gap:14px;padding-bottom:14px;margin-bottom:14px;border-bottom:0.5px solid var(--separator)">
      <div style="width:52px;height:52px;border-radius:50%;background:var(--surface3);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:16px;flex-shrink:0">${gdInitials(guardian.name)}</div>
      <div style="min-width:0;flex:1">
        <div style="font-size:15px;font-weight:700;color:var(--color-text)">${gdCommsEsc(guardian.name)}</div>
        <div style="font-size:12px;color:var(--muted);margin-top:2px">${gdCommsEsc(guardian.email)}</div>
      </div>
    </div>
    <div class="info-row"><span>${t('Phone')}</span><span>${gdCommsEsc(guardian.phone)}</span></div>

    <div style="margin-top:16px;padding-top:14px;border-top:0.5px solid var(--separator)">
      <div style="font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Linked Students')}</div>
      ${kids.length ? kids.map(k => {
        const cls = hGetClass(k.classId);
        return `<div class="info-row" style="align-items:center">
          <span style="cursor:pointer" role="button" tabindex="0" onclick="hGoToStudentFromGuardian('${k.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hGoToStudentFromGuardian('${k.id}')}">${gdCommsEsc(hStudentFullName(k))}<div style="font-size:11px;color:var(--muted)">${cls ? gdCommsEsc(cls.name) : '—'} · ${k.avgGrade}/20</div></span>
          <button type="button" class="st-btn ghost sm" onclick="hUnlinkGuardianStudent('${guardian.id}','${k.id}')">${t('Unlink')}</button>
        </div>`;
      }).join('') : `<div class="gd-empty-mini">${t('No students linked yet.')}</div>`}
      <div style="margin-top:10px">
        <input class="gd-comm-search-input" type="text" placeholder="${t('Search a student to link...')}" value="${gdCommsEsc(hState.guardians.linkSearch)}" oninput="hSetGuardianLinkSearch(this.value)">
        <div id="h-guardian-link-results">${linkResults.length ? linkResults.map(s => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hLinkGuardianStudent('${guardian.id}','${s.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hLinkGuardianStudent('${guardian.id}','${s.id}')}">
          <span>${gdCommsEsc(hStudentFullName(s))}<div style="font-size:11px;color:var(--muted)">${gdCommsEsc(s.studentId)}</div></span><span class="card-action">${t('Link')}</span>
        </div>`).join('') : (q ? `<div class="gd-empty-mini" style="text-align:left;padding:8px 0 0">${t('No students match your search.')}</div>` : '')}</div>
      </div>
    </div>

    ${paySummary ? `<div style="margin-top:16px;padding-top:14px;border-top:0.5px solid var(--separator)">
      <div style="font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Payment Status (Linked Children)')}</div>
      <div class="info-row"><span><span class="status-pill paid">${t('Paid')}</span></span><span>${paySummary.paid} / ${paySummary.total}</span></div>
      <div class="info-row"><span><span class="status-pill partial">${t('Partial')}</span></span><span>${paySummary.partial} / ${paySummary.total}</span></div>
      <div class="info-row"><span><span class="status-pill overdue">${t('Overdue')}</span></span><span>${paySummary.overdue} / ${paySummary.total}</span></div>
    </div>` : ''}
    <div style="font-size:11.5px;color:var(--muted);margin-top:16px">${t('Communication history with this guardian will appear here once the Communication module is available.')}</div>`;
}
function hRefreshGuardianProfile() {
  const guardian = hGetGuardian(hState.guardians.guardianId);
  if (!guardian) return;
  const el = document.getElementById('h-guardian-profile-body');
  if (el) el.innerHTML = hGuardianProfileBody(guardian);
}
function hSetGuardianLinkSearch(v) {
  hState.guardians.linkSearch = v;
  const el = document.getElementById('h-guardian-link-results');
  const guardian = hGetGuardian(hState.guardians.guardianId);
  if (el && guardian) {
    const unlinkedStudents = HEAD_DATA.students.filter(s => s.guardianId !== guardian.id);
    const q = v.trim().toLowerCase();
    const results = q ? unlinkedStudents.filter(s => hStudentFullName(s).toLowerCase().includes(q) || s.studentId.toLowerCase().includes(q)) : [];
    el.innerHTML = results.length ? results.map(s => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hLinkGuardianStudent('${guardian.id}','${s.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hLinkGuardianStudent('${guardian.id}','${s.id}')}">
      <span>${gdCommsEsc(hStudentFullName(s))}<div style="font-size:11px;color:var(--muted)">${gdCommsEsc(s.studentId)}</div></span><span class="card-action">${t('Link')}</span>
    </div>`).join('') : (q ? `<div class="gd-empty-mini" style="text-align:left;padding:8px 0 0">${t('No students match your search.')}</div>` : '');
  }
}
function hLinkGuardianStudent(guardianId, studentId) {
  const guardian = hGetGuardian(guardianId);
  const student = hGetStudent(studentId);
  if (!guardian || !student) return;
  const oldGuardian = hGetGuardian(student.guardianId);
  if (oldGuardian && oldGuardian.id !== guardianId) oldGuardian.studentIds = oldGuardian.studentIds.filter(id => id !== studentId);
  student.guardianId = guardianId;
  if (!guardian.studentIds.includes(studentId)) guardian.studentIds.push(studentId);
  hLogStudentHistory(studentId, 'guardian', `${t('Guardian linked')}: ${guardian.name}`);
  hState.guardians.linkSearch = '';
  hRefreshGuardianProfile();
  hShowToast(t('Student linked successfully.'));
}
function hUnlinkGuardianStudent(guardianId, studentId) {
  const guardian = hGetGuardian(guardianId);
  const student = hGetStudent(studentId);
  if (!guardian) return;
  guardian.studentIds = guardian.studentIds.filter(id => id !== studentId);
  if (student && student.guardianId === guardianId) student.guardianId = null;
  hLogStudentHistory(studentId, 'guardian', `${t('Guardian unlinked')}: ${guardian.name}`);
  hRefreshGuardianProfile();
  hShowToast(t('Student unlinked.'));
}

/* ── Add / Edit Guardian form ── */
function hOpenGuardianForm(guardianId) {
  if (guardianId) {
    const guardian = hGetGuardian(guardianId);
    if (!guardian) return;
    hState.guardians.form = { mode:'edit', id:guardian.id, name:guardian.name, email:guardian.email, phone:guardian.phone };
  } else {
    hState.guardians.form = { mode:'create', id:null, name:'', email:'', phone:'' };
  }
  hState.guardians.screen = 'form';
  hState.guardians.error = '';
  hRefreshGuardians();
}
function hCancelGuardianForm() {
  hState.guardians.screen = (hState.guardians.form && hState.guardians.form.mode === 'edit') ? 'profile' : 'list';
  hState.guardians.form = null;
  hState.guardians.error = '';
  hRefreshGuardians();
}
function hGuardianFormScreen() {
  const f = hState.guardians.form;
  const err = hState.guardians.error;
  return `<div class="card"><div class="card-header"><div class="card-title">${f.mode==='edit'?t('Edit Guardian'):t('Add Guardian')}</div></div>
    <div class="card-body">
      <div class="st-field"><label>${t('Full Name')}</label><input id="h-gu-name" value="${gdCommsEsc(f.name)}"></div>
      <div class="st-field"><label>${t('Email')}</label><input id="h-gu-email" type="email" value="${gdCommsEsc(f.email)}"></div>
      <div class="st-field"><label>${t('Phone')}</label><input id="h-gu-phone" type="tel" value="${gdCommsEsc(f.phone)}"></div>
      ${f.mode === 'create' ? `<div style="font-size:11.5px;color:var(--muted);margin-bottom:12px">${t('You can link students to this guardian from their profile after creating it.')}</div>` : ''}
      <div style="display:flex;gap:10px">
        <button class="st-btn" onclick="hSaveGuardian()" ${hState.guardians.saving?'disabled':''}>${hState.guardians.saving ? `<span class="gd-spinner"></span>${t('Saving...')}` : (f.mode==='edit'?t('Save Changes'):t('Create Guardian'))}</button>
        <button class="st-btn ghost" onclick="hCancelGuardianForm()" ${hState.guardians.saving?'disabled':''}>${t('Cancel')}</button>
      </div>
      ${err ? `<div class="st-inline-msg err show" style="margin-top:12px">${err}</div>` : ''}
    </div></div>`;
}
function hSaveGuardian() {
  const f = hState.guardians.form;
  const name = (document.getElementById('h-gu-name').value || '').trim();
  const email = (document.getElementById('h-gu-email').value || '').trim();
  const phone = (document.getElementById('h-gu-phone').value || '').trim();
  Object.assign(f, { name, email, phone });

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const phoneRegex = /^[+]?[\d][\d\s().-]{6,18}\d$/;
  let err = '';
  if (!name) err = t('Full name is required.');
  else if (!email || !emailRegex.test(email)) err = t('Enter a valid email address.');
  else if (!phone || !phoneRegex.test(phone)) err = t('Enter a valid phone number.');

  hState.guardians.error = err;
  if (err) { hRefreshGuardians(); return; }

  hState.guardians.saving = true;
  hRefreshGuardians();
  setTimeout(() => {
    if (f.mode === 'edit') {
      const guardian = hGetGuardian(f.id);
      Object.assign(guardian, { name, email, phone });
      hState.guardians.screen = 'profile';
      hState.guardians.guardianId = guardian.id;
      hShowToast(t('Guardian updated successfully.'));
    } else {
      const newGuardian = { id:'hg' + Date.now(), name, email, phone, studentIds:[] };
      HEAD_DATA.guardians.push(newGuardian);
      hState.guardians.screen = 'profile';
      hState.guardians.guardianId = newGuardian.id;
      hShowToast(t('Guardian created successfully.'));
    }
    hState.guardians.saving = false;
    hState.guardians.form = null;
    hRefreshGuardians();
  }, 700);
}

/* ══════════════════════════════════════════════════════
   CLASS MANAGEMENT
══════════════════════════════════════════════════════ */
function hClassAvgGrade(classId) { return hAvg(hClassStudents(classId).map(s => s.avgGrade)); }
function hClassAvgAttendance(classId) { return hAvg(hClassStudents(classId).map(s => s.attendanceRate)); }
function hClassesView() {
  return `<div id="h-classes-content">${hClassesBody()}</div>`;
}
function hClassesBody() {
  const s = hState.classes;
  if (s.screen === 'form') return hClassFormScreen();
  if (s.screen === 'detail') {
    const cls = hGetClass(s.classId);
    if (!cls) { s.screen = 'list'; return hClassesBody(); }
    return hClassDetailScreen(cls);
  }
  return hClassListScreen();
}
function hRefreshClasses() { const el = document.getElementById('h-classes-content'); if (el) el.innerHTML = hClassesBody(); }

function hFilteredClasses() {
  const s = hState.classes;
  let list = HEAD_DATA.classes.slice();
  const q = s.search.trim().toLowerCase();
  if (q) list = list.filter(c => c.name.toLowerCase().includes(q) || c.level.toLowerCase().includes(q));
  return list;
}
function hClassListScreen() {
  const s = hState.classes;
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Classes')}</div><button class="st-btn sm" onclick="hOpenClassForm()">+ ${t('Create Class')}</button></div>
    <div class="card-body">
      <input class="gd-comm-search-input" type="text" placeholder="${t('Search by class name or level...')}" value="${gdCommsEsc(s.search)}" oninput="hSetClassSearch(this.value)">
    </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('All Classes')}</div></div>
      <div class="card-body" id="h-class-list-results">${hClassListResultsBlock()}</div></div>`;
}
function hClassListResultsBlock() {
  const list = hFilteredClasses();
  if (!list.length) return `<div class="gd-empty-mini">${t('No classes match your search.')}</div>`;
  return list.map(c => {
    const roster = hClassStudents(c.id);
    const teacher = hGetTeacher(c.homeroomTeacherId);
    return `<div class="info-row" style="cursor:pointer;align-items:center" role="button" tabindex="0" onclick="hOpenClassDetail('${c.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hOpenClassDetail('${c.id}')}">
      <span>${gdCommsEsc(c.name)}<div style="font-size:11px;color:var(--muted);margin-top:2px">${gdCommsEsc(t(c.level))} · ${t('Homeroom')}: ${teacher ? gdCommsEsc(teacher.name) : '—'}</div></span>
      <span style="text-align:right;font-size:12.5px;color:var(--muted)">${roster.length}/${c.capacity} ${t('students')}<div style="margin-top:4px">${hClassAvgGrade(c.id) !== null ? hClassAvgGrade(c.id) + '/20' : '—'} · ${hClassAvgAttendance(c.id) !== null ? hClassAvgAttendance(c.id) + '%' : '—'}</div></span>
    </div>`;
  }).join('');
}
function hSetClassSearch(v) { hState.classes.search = v; const el = document.getElementById('h-class-list-results'); if (el) el.innerHTML = hClassListResultsBlock(); }

/* ── Class Detail (teacher reassignment + roster add/remove) ── */
function hOpenClassDetail(classId) {
  hState.classes.screen = 'detail';
  hState.classes.classId = classId;
  hState.classes.addStudentSearch = '';
  hRefreshClasses();
}
function hBackToClassList() {
  hState.classes.screen = 'list';
  hState.classes.classId = null;
  hRefreshClasses();
}
function hGoToTeacherFromClass(teacherId) {
  hState.teachers.screen = 'profile';
  hState.teachers.teacherId = teacherId;
  authrenGoTo('teachers');
}
function hGoToStudentFromClass(studentId) {
  hState.students.screen = 'profile';
  hState.students.studentId = studentId;
  authrenGoTo('students');
}
function hClassDetailScreen(cls) {
  return `<div class="card">
    <div class="card-header">
      <div style="display:flex;align-items:center;gap:10px;min-width:0;flex:1">
        <button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="hBackToClassList()">${t('← Back')}</button>
        <div class="card-title" style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${gdCommsEsc(cls.name)}</div>
      </div>
      <button type="button" class="st-btn ghost sm" onclick="hOpenClassForm('${cls.id}')">${t('Edit')}</button>
    </div>
    <div class="card-body" id="h-class-detail-body">${hClassDetailBody(cls)}</div>
  </div>`;
}
function hClassDetailBody(cls) {
  const roster = hClassStudents(cls.id);
  const teacher = hGetTeacher(cls.homeroomTeacherId);
  const otherTeachers = HEAD_DATA.teachers.filter(te => te.id !== cls.homeroomTeacherId);
  const unassigned = HEAD_DATA.students.filter(s => s.classId !== cls.id);
  const q = hState.classes.addStudentSearch.trim().toLowerCase();
  const addResults = q ? unassigned.filter(s => hStudentFullName(s).toLowerCase().includes(q) || s.studentId.toLowerCase().includes(q)) : [];
  return `
    <div style="font-size:12.5px;color:var(--muted);margin-bottom:14px">${gdCommsEsc(t(cls.level))} · ${gdCommsEsc(cls.schedule)}</div>
    <div class="gd-pay-stat-row">
      <div class="stat-card"><div class="stat-label">${t('Students')}</div><div class="stat-val">${roster.length}/${cls.capacity}</div><div class="stat-icon blue">${aIcon('users')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Avg. Performance')}</div><div class="stat-val">${hClassAvgGrade(cls.id) !== null ? hClassAvgGrade(cls.id) + '/20' : '—'}</div><div class="stat-icon green">${aIcon('bar-chart')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Avg. Attendance')}</div><div class="stat-val">${hClassAvgAttendance(cls.id) !== null ? hClassAvgAttendance(cls.id) + '%' : '—'}</div><div class="stat-icon yellow">${aIcon('check-circle')}</div></div>
    </div>

    <div style="margin-top:16px;padding-top:14px;border-top:0.5px solid var(--separator)">
      <div style="font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Homeroom Teacher')}</div>
      <div class="info-row"><span style="cursor:${teacher?'pointer':'default'}" ${teacher ? `role="button" tabindex="0" onclick="hGoToTeacherFromClass('${teacher.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hGoToTeacherFromClass('${teacher.id}')}"` : ''}>${teacher ? gdCommsEsc(teacher.name) : t('Unassigned')}</span></div>
      <div style="display:flex;gap:8px;margin-top:8px">
        <select id="h-class-reassign-teacher" style="flex:1;background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
          ${otherTeachers.map(te => `<option value="${te.id}">${gdCommsEsc(te.name)}</option>`).join('')}
        </select>
        <button type="button" class="st-btn ghost sm" onclick="hReassignHomeroomTeacher('${cls.id}')">${t('Assign Teacher')}</button>
      </div>
    </div>

    <div style="margin-top:16px;padding-top:14px;border-top:0.5px solid var(--separator)">
      <div style="font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Student Roster')}</div>
      ${roster.length ? roster.map(s => `<div class="info-row" style="align-items:center">
        <span style="cursor:pointer" role="button" tabindex="0" onclick="hGoToStudentFromClass('${s.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hGoToStudentFromClass('${s.id}')}">${gdCommsEsc(hStudentFullName(s))}<div style="font-size:11px;color:var(--muted)">${s.avgGrade}/20 · ${s.attendanceRate}%</div></span>
        <button type="button" class="st-btn ghost sm" onclick="hRemoveStudentFromClass('${cls.id}','${s.id}')">${t('Remove')}</button>
      </div>`).join('') : `<div class="gd-empty-mini">${t('No students in this class yet.')}</div>`}
      <div style="margin-top:10px">
        <input class="gd-comm-search-input" type="text" placeholder="${t('Search a student to add to this class...')}" value="${gdCommsEsc(hState.classes.addStudentSearch)}" oninput="hSetClassAddStudentSearch(this.value)">
        <div id="h-class-add-results">${addResults.length ? addResults.map(s => { const currentCls = hGetClass(s.classId); return `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hAddStudentToClass('${cls.id}','${s.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hAddStudentToClass('${cls.id}','${s.id}')}">
          <span>${gdCommsEsc(hStudentFullName(s))}<div style="font-size:11px;color:var(--muted)">${gdCommsEsc(s.studentId)} · ${t('Currently')}: ${currentCls ? gdCommsEsc(currentCls.name) : t('Unassigned')}</div></span><span class="card-action">${t('Add')}</span>
        </div>`; }).join('') : (q ? `<div class="gd-empty-mini" style="text-align:left;padding:8px 0 0">${t('No students match your search.')}</div>` : '')}</div>
      </div>
    </div>
    <div style="font-size:11.5px;color:var(--muted);margin-top:16px">${t('Detailed class analytics (grade distribution, attendance trends) will appear here once Academic and Attendance Analytics are available.')}</div>`;
}
function hRefreshClassDetail() {
  const cls = hGetClass(hState.classes.classId);
  if (!cls) return;
  const el = document.getElementById('h-class-detail-body');
  if (el) el.innerHTML = hClassDetailBody(cls);
}
function hReassignHomeroomTeacher(classId) {
  const cls = hGetClass(classId);
  const sel = document.getElementById('h-class-reassign-teacher');
  if (!cls || !sel || !sel.value) return;
  cls.homeroomTeacherId = sel.value;
  hRefreshClassDetail();
  hShowToast(t('Homeroom teacher updated successfully.'));
}
function hSetClassAddStudentSearch(v) {
  hState.classes.addStudentSearch = v;
  const cls = hGetClass(hState.classes.classId);
  if (!cls) return;
  const unassigned = HEAD_DATA.students.filter(s => s.classId !== cls.id);
  const q = v.trim().toLowerCase();
  const addResults = q ? unassigned.filter(s => hStudentFullName(s).toLowerCase().includes(q) || s.studentId.toLowerCase().includes(q)) : [];
  const el = document.getElementById('h-class-add-results');
  if (el) el.innerHTML = addResults.length ? addResults.map(s => {
    const currentCls = hGetClass(s.classId);
    return `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hAddStudentToClass('${cls.id}','${s.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hAddStudentToClass('${cls.id}','${s.id}')}">
      <span>${gdCommsEsc(hStudentFullName(s))}<div style="font-size:11px;color:var(--muted)">${gdCommsEsc(s.studentId)} · ${t('Currently')}: ${currentCls ? gdCommsEsc(currentCls.name) : t('Unassigned')}</div></span><span class="card-action">${t('Add')}</span>
    </div>`;
  }).join('') : (q ? `<div class="gd-empty-mini" style="text-align:left;padding:8px 0 0">${t('No students match your search.')}</div>` : '');
}
function hAddStudentToClass(classId, studentId) {
  const student = hGetStudent(studentId);
  if (!student) return;
  student.classId = classId;
  const cls = hGetClass(classId);
  hLogStudentHistory(studentId, 'class', `${t('Added to class')} ${cls ? cls.name : ''}`);
  hState.classes.addStudentSearch = '';
  hRefreshClassDetail();
  hShowToast(t('Student added to class.'));
}
function hRemoveStudentFromClass(classId, studentId) {
  const student = hGetStudent(studentId);
  if (!student) return;
  student.classId = null;
  const cls = hGetClass(classId);
  hLogStudentHistory(studentId, 'class', `${t('Removed from class')} ${cls ? cls.name : ''}`);
  hRefreshClassDetail();
  hShowToast(t('Student removed from class.'));
}

/* ── Create / Edit Class form ── */
function hOpenClassForm(classId) {
  if (classId) {
    const cls = hGetClass(classId);
    if (!cls) return;
    hState.classes.form = { mode:'edit', id:cls.id, name:cls.name, level:cls.level, capacity:cls.capacity, homeroomTeacherId:cls.homeroomTeacherId, schedule:cls.schedule, campus:cls.campus || 'main' };
  } else {
    hState.classes.form = { mode:'create', id:null, name:'', level:'', capacity:30, homeroomTeacherId: HEAD_DATA.teachers[0] ? HEAD_DATA.teachers[0].id : '', schedule:'Mon–Fri, 08:00–15:00', campus:'main' };
  }
  hState.classes.screen = 'form';
  hState.classes.error = '';
  hRefreshClasses();
}
function hCancelClassForm() {
  hState.classes.screen = (hState.classes.form && hState.classes.form.mode === 'edit') ? 'detail' : 'list';
  hState.classes.form = null;
  hState.classes.error = '';
  hRefreshClasses();
}
function hClassFormScreen() {
  const f = hState.classes.form;
  const err = hState.classes.error;
  return `<div class="card"><div class="card-header"><div class="card-title">${f.mode==='edit'?t('Edit Class'):t('Create Class')}</div></div>
    <div class="card-body">
      <div class="st-field"><label>${t('Class Name')}</label><input id="h-cl-name" value="${gdCommsEsc(f.name)}" placeholder="${t('e.g. Grade 10 - B')}"></div>
      <div class="st-field"><label>${t('Academic Level')}</label><input id="h-cl-level" value="${gdCommsEsc(f.level)}" placeholder="${t('e.g. Grade 10')}"></div>
      <div class="st-field"><label>${t('Capacity')}</label><input id="h-cl-capacity" type="number" min="1" value="${f.capacity}"></div>
      <div class="st-field"><label>${t('Homeroom Teacher')}</label><select id="h-cl-teacher">
        ${HEAD_DATA.teachers.map(te => `<option value="${te.id}" ${te.id===f.homeroomTeacherId?'selected':''}>${gdCommsEsc(te.name)}</option>`).join('')}
      </select></div>
      <div class="st-field"><label>${t('Schedule')}</label><input id="h-cl-schedule" value="${gdCommsEsc(f.schedule)}" placeholder="${t('e.g. Mon–Fri, 08:00–15:00')}"></div>
      <div class="st-field"><label>${t('Campus')}</label><select id="h-cl-campus">
        ${HEAD_DATA.campuses.map(c => `<option value="${c.id}" ${c.id===f.campus?'selected':''}>${gdCommsEsc(c.name)}</option>`).join('')}
      </select></div>
      <div style="display:flex;gap:10px">
        <button class="st-btn" onclick="hSaveClass()" ${hState.classes.saving?'disabled':''}>${hState.classes.saving ? `<span class="gd-spinner"></span>${t('Saving...')}` : (f.mode==='edit'?t('Save Changes'):t('Create Class'))}</button>
        <button class="st-btn ghost" onclick="hCancelClassForm()" ${hState.classes.saving?'disabled':''}>${t('Cancel')}</button>
      </div>
      ${err ? `<div class="st-inline-msg err show" style="margin-top:12px">${err}</div>` : ''}
    </div></div>`;
}
function hSaveClass() {
  const f = hState.classes.form;
  const name = (document.getElementById('h-cl-name').value || '').trim();
  const level = (document.getElementById('h-cl-level').value || '').trim();
  const capacity = Number(document.getElementById('h-cl-capacity').value);
  const homeroomTeacherId = document.getElementById('h-cl-teacher').value;
  const schedule = (document.getElementById('h-cl-schedule').value || '').trim();
  const campus = document.getElementById('h-cl-campus').value;
  Object.assign(f, { name, level, capacity, homeroomTeacherId, schedule, campus });

  let err = '';
  if (!name) err = t('Class name is required.');
  else if (HEAD_DATA.classes.some(c => c.name.toLowerCase() === name.toLowerCase() && c.id !== f.id)) err = t('A class with this name already exists.');
  else if (!level) err = t('Academic level is required.');
  else if (!capacity || capacity <= 0) err = t('Capacity must be greater than 0.');
  else if (f.mode === 'edit') {
    const currentRoster = hClassStudents(f.id).length;
    if (capacity < currentRoster) err = `${t('Capacity cannot be less than the current roster size')} (${currentRoster}).`;
  }
  if (!err && !homeroomTeacherId) err = t('Select a homeroom teacher.');
  if (!err && !schedule) err = t('Schedule is required.');

  hState.classes.error = err;
  if (err) { hRefreshClasses(); return; }

  hState.classes.saving = true;
  hRefreshClasses();
  setTimeout(() => {
    if (f.mode === 'edit') {
      const cls = hGetClass(f.id);
      Object.assign(cls, { name, level, capacity, homeroomTeacherId, schedule, campus });
      hState.classes.screen = 'detail';
      hState.classes.classId = cls.id;
      hShowToast(t('Class updated successfully.'));
    } else {
      const newClass = { id:'hc' + Date.now(), name, level, capacity, homeroomTeacherId, schedule, campus };
      HEAD_DATA.classes.push(newClass);
      hState.classes.screen = 'detail';
      hState.classes.classId = newClass.id;
      hShowToast(t('Class created successfully.'));
    }
    hState.classes.saving = false;
    hState.classes.form = null;
    hRefreshClasses();
  }, 700);
}

/* ══════════════════════════════════════════════════════
   ATTENDANCE (school-wide overview, School -> Class -> Student drill-down)
══════════════════════════════════════════════════════ */
function hAttendancePeriodDays() {
  const a = hState.attendance;
  if (a.period === 'today') return H_ATTENDANCE_DAYS.slice(-1);
  if (a.period === 'week') return H_ATTENDANCE_DAYS.slice(-5);
  if (a.period === 'month') return H_ATTENDANCE_DAYS.slice();
  if (a.period === 'custom' && a.customStart && a.customEnd) {
    return H_ATTENDANCE_DAYS.filter(d => d >= a.customStart && d <= a.customEnd);
  }
  return H_ATTENDANCE_DAYS.slice(-5);
}
function hAttendanceStatusFor(studentId, date) {
  return (HEAD_DATA.attendanceRecords[date] && HEAD_DATA.attendanceRecords[date][studentId]) || null;
}
function hAggregateAttendance(studentIds, days) {
  let present = 0, absent = 0, late = 0, excused = 0, total = 0;
  days.forEach(date => {
    studentIds.forEach(id => {
      const status = hAttendanceStatusFor(id, date);
      if (!status) return;
      total++;
      if (status === 'present') present++;
      else if (status === 'absent') absent++;
      else if (status === 'late') late++;
      else if (status === 'excused') excused++;
    });
  });
  const rate = total ? Math.round(((present + late) / total) * 100) : null;
  return { present, absent, late, excused, total, rate };
}
function hAttendanceView() {
  const tabs = [ { id:'overview', label:'Overview' }, { id:'advanced', label:'Advanced Analytics' } ];
  return `<div class="st-tabs">${tabs.map(tb => `<div class="st-tab gd-tab-hatt${tb.id===hState.attendance.tab?' active':''}" data-tab="${tb.id}" onclick="hSetAttendanceTab('${tb.id}')">${t(tb.label)}</div>`).join('')}</div>
    <div id="h-attendance-content">${hAttendanceTabBody()}</div>`;
}
function hSetAttendanceTab(tabId) {
  hState.attendance.tab = tabId;
  document.querySelectorAll('.gd-tab-hatt').forEach(el => el.classList.toggle('active', el.dataset.tab === tabId));
  const el = document.getElementById('h-attendance-content');
  if (el) el.innerHTML = hAttendanceTabBody();
}
function hAttendanceTabBody() {
  return hState.attendance.tab === 'advanced' ? hAttendanceAdvancedTab() : hAttendanceBody();
}
function hAttendanceBody() {
  const a = hState.attendance;
  if (a.screen === 'student') {
    const student = hGetStudent(a.studentId);
    if (!student) { a.screen = 'class'; return hAttendanceBody(); }
    return hAttendanceStudentScreen(student);
  }
  if (a.screen === 'class') {
    const cls = hGetClass(a.classId);
    if (!cls) { a.screen = 'school'; return hAttendanceBody(); }
    return hAttendanceClassScreen(cls);
  }
  return hAttendanceSchoolScreen();
}
function hRefreshAttendance() { const el = document.getElementById('h-attendance-content'); if (el) el.innerHTML = hAttendanceBody(); }

function hAttendancePeriodSelector() {
  const a = hState.attendance;
  const periods = [['today','Today'],['week','This Week'],['month','This Month'],['custom','Custom']];
  return `<div class="card"><div class="card-body">
    <div class="gd-comm-filter-row">${periods.map(([id,label]) => `<div class="gd-comm-filter-chip${a.period===id?' active':''}" onclick="hSetAttendancePeriod('${id}')">${t(label)}</div>`).join('')}</div>
    ${a.period === 'custom' ? `<div style="display:flex;gap:10px;margin-top:10px;align-items:center">
      <input type="date" id="h-att-custom-start" value="${a.customStart}" min="${H_ATTENDANCE_DAYS[0]}" max="${H_ATTENDANCE_DAYS[H_ATTENDANCE_DAYS.length-1]}" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
      <span style="color:var(--muted);font-size:12px">${t('to')}</span>
      <input type="date" id="h-att-custom-end" value="${a.customEnd}" min="${H_ATTENDANCE_DAYS[0]}" max="${H_ATTENDANCE_DAYS[H_ATTENDANCE_DAYS.length-1]}" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
      <button type="button" class="st-btn ghost sm" onclick="hApplyCustomAttendanceRange()">${t('Apply')}</button>
    </div>` : ''}
  </div></div>`;
}
function hSetAttendancePeriod(period) {
  hState.attendance.period = period;
  hRefreshAttendanceScreen();
}
function hApplyCustomAttendanceRange() {
  const startEl = document.getElementById('h-att-custom-start');
  const endEl = document.getElementById('h-att-custom-end');
  const a = hState.attendance;
  a.customStart = startEl ? startEl.value : '';
  a.customEnd = endEl ? endEl.value : '';
  if (!a.customStart || !a.customEnd) { hShowToast(t('Select both a start and end date.')); return; }
  if (a.customStart > a.customEnd) { hShowToast(t('The start date must be before the end date.')); return; }
  hRefreshAttendanceScreen();
}
function hRefreshAttendanceScreen() {
  const el = document.getElementById('h-attendance-content');
  if (el) el.innerHTML = hAttendanceBody();
}

function hAttendanceSchoolScreen() {
  const days = hAttendancePeriodDays();
  const allIds = HEAD_DATA.students.map(s => s.id);
  const agg = hAggregateAttendance(allIds, days);
  return `${hAttendancePeriodSelector()}
    <div class="gd-stat-row" style="margin-top:16px">
      <div class="stat-card"><div class="stat-label">${t('Attendance Rate')}</div><div class="stat-val">${agg.rate !== null ? agg.rate + '%' : '—'}</div><div class="stat-icon ${agg.rate!==null&&agg.rate<90?'yellow':'green'}">${aIcon('check-circle')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Present')}</div><div class="stat-val">${agg.present}</div><div class="stat-icon green">${aIcon('dot')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Absent')}</div><div class="stat-val">${agg.absent}</div><div class="stat-icon red">${aIcon('x-circle')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Late')}</div><div class="stat-val">${agg.late}</div><div class="stat-icon yellow">${aIcon('clock')}</div></div>
    </div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Excused Absences')}</div></div><div class="card-body"><div class="info-row"><span>${t('Excused')}</span><span>${agg.excused}</span></div></div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('By Class')}</div><span style="font-size:12px;color:var(--muted)">${t('Tap a class to drill down')}</span></div>
      <div class="card-body">
        ${HEAD_DATA.classes.map(c => {
          const roster = hClassStudents(c.id).map(s => s.id);
          const cAgg = hAggregateAttendance(roster, days);
          return `<div class="info-row" style="cursor:pointer;align-items:center" role="button" tabindex="0" onclick="hOpenAttendanceClass('${c.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hOpenAttendanceClass('${c.id}')}">
            <span>${gdCommsEsc(c.name)}</span>
            <span style="text-align:right;font-size:12.5px;color:var(--muted)">${cAgg.rate !== null ? cAgg.rate + '%' : t('No data')}</span>
          </div>`;
        }).join('')}
      </div></div>`;
}
function hOpenAttendanceClass(classId) {
  hState.attendance.screen = 'class';
  hState.attendance.classId = classId;
  hRefreshAttendanceScreen();
}
function hBackToAttendanceSchool() {
  hState.attendance.screen = 'school';
  hState.attendance.classId = null;
  hRefreshAttendanceScreen();
}
function hAttendanceClassScreen(cls) {
  const days = hAttendancePeriodDays();
  const roster = hClassStudents(cls.id);
  const rosterIds = roster.map(s => s.id);
  const agg = hAggregateAttendance(rosterIds, days);
  return `${hAttendancePeriodSelector()}
    <div class="card" style="margin-top:16px"><div class="card-header">
      <div style="display:flex;align-items:center;gap:10px"><button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="hBackToAttendanceSchool()">${t('← Back')}</button><div class="card-title">${gdCommsEsc(cls.name)}</div></div>
    </div>
      <div class="card-body">
        <div class="gd-pay-stat-row">
          <div class="stat-card"><div class="stat-label">${t('Attendance Rate')}</div><div class="stat-val">${agg.rate !== null ? agg.rate + '%' : '—'}</div><div class="stat-icon green">${aIcon('check-circle')}</div></div>
          <div class="stat-card"><div class="stat-label">${t('Absent')}</div><div class="stat-val">${agg.absent}</div><div class="stat-icon red">${aIcon('x-circle')}</div></div>
          <div class="stat-card"><div class="stat-label">${t('Late')}</div><div class="stat-val">${agg.late}</div><div class="stat-icon yellow">${aIcon('clock')}</div></div>
        </div>
      </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Student Breakdown')}</div><span style="font-size:12px;color:var(--muted)">${t('Tap a student to drill down')}</span></div>
      <div class="card-body">
        ${roster.map(s => {
          const sAgg = hAggregateAttendance([s.id], days);
          return `<div class="info-row" style="cursor:pointer;align-items:center" role="button" tabindex="0" onclick="hOpenAttendanceStudent('${s.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hOpenAttendanceStudent('${s.id}')}">
            <span>${gdCommsEsc(hStudentFullName(s))}</span>
            <span style="text-align:right;font-size:12.5px;color:var(--muted)">${sAgg.rate !== null ? sAgg.rate + '%' : t('No data')}</span>
          </div>`;
        }).join('') || `<div class="gd-empty-mini">${t('No students in this class.')}</div>`}
      </div></div>`;
}
function hOpenAttendanceStudent(studentId) {
  hState.attendance.screen = 'student';
  hState.attendance.studentId = studentId;
  hRefreshAttendanceScreen();
}
function hBackToAttendanceClass() {
  hState.attendance.screen = 'class';
  hState.attendance.studentId = null;
  hRefreshAttendanceScreen();
}
function hAttendanceStudentScreen(student) {
  const days = hAttendancePeriodDays();
  const agg = hAggregateAttendance([student.id], days);
  const statusMeta = { present:{cls:'open',label:'Present'}, absent:{cls:'overdue',label:'Absent'}, late:{cls:'awaiting',label:'Late'}, excused:{cls:'resolved',label:'Excused'} };
  return `${hAttendancePeriodSelector()}
    <div class="card" style="margin-top:16px"><div class="card-header">
      <div style="display:flex;align-items:center;gap:10px"><button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="hBackToAttendanceClass()">${t('← Back')}</button><div class="card-title">${gdCommsEsc(hStudentFullName(student))}</div></div>
      <span class="card-action" onclick="hGoToStudentFromClass('${student.id}')">${t('View Profile')} →</span>
    </div>
      <div class="card-body">
        <div class="gd-pay-stat-row">
          <div class="stat-card"><div class="stat-label">${t('Rate (Period)')}</div><div class="stat-val">${agg.rate !== null ? agg.rate + '%' : '—'}</div><div class="stat-icon green">${aIcon('check-circle')}</div></div>
          <div class="stat-card"><div class="stat-label">${t('Overall Rate')}</div><div class="stat-val">${student.attendanceRate}%</div><div class="stat-icon blue">${aIcon('bar-chart')}</div></div>
          <div class="stat-card"><div class="stat-label">${t('Days Recorded')}</div><div class="stat-val">${agg.total}</div><div class="stat-icon purple">${aIcon('calendar')}</div></div>
        </div>
      </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Daily Record')}</div></div>
      <div class="card-body">
        ${days.map(d => {
          const status = hAttendanceStatusFor(student.id, d);
          const meta = status ? statusMeta[status] : null;
          return `<div class="info-row"><span>${d}</span>${meta ? `<span class="status-pill ${meta.cls}">${t(meta.label)}</span>` : `<span style="color:var(--muted)">${t('No record')}</span>`}</div>`;
        }).join('')}
      </div></div>`;
}

/* ══════════════════════════════════════════════════════
   GRADE OVERVIEW (school-wide, drill into class/subject)
══════════════════════════════════════════════════════ */
function hGradeDistribution(studentIds) {
  const buckets = [ { label:'0–8', min:0, max:8, count:0 }, { label:'8–12', min:8, max:12, count:0 }, { label:'12–16', min:12, max:16, count:0 }, { label:'16–20', min:16, max:20.01, count:0 } ];
  studentIds.forEach(id => {
    const s = hGetStudent(id);
    if (!s) return;
    const b = buckets.find(b => s.avgGrade >= b.min && s.avgGrade < b.max);
    if (b) b.count++;
  });
  return buckets;
}
function hSubjectClasses(subject) {
  return HEAD_DATA.classes.filter(c => HEAD_DATA.teachers.some(te => te.subjects.includes(subject) && te.classIds.includes(c.id)));
}
function hGradesView() {
  const tabs = [ { id:'overview', label:'Overview' }, { id:'advanced', label:'Advanced Analytics' } ];
  return `<div class="st-tabs">${tabs.map(tb => `<div class="st-tab gd-tab-hgra${tb.id===hState.grades.tab?' active':''}" data-tab="${tb.id}" onclick="hSetGradesTab('${tb.id}')">${t(tb.label)}</div>`).join('')}</div>
    <div id="h-grades-content">${hGradesTabBody()}</div>`;
}
function hSetGradesTab(tabId) {
  hState.grades.tab = tabId;
  document.querySelectorAll('.gd-tab-hgra').forEach(el => el.classList.toggle('active', el.dataset.tab === tabId));
  const el = document.getElementById('h-grades-content');
  if (el) el.innerHTML = hGradesTabBody();
}
function hGradesTabBody() {
  return hState.grades.tab === 'advanced' ? hAcademicAdvancedTab() : hGradesBody();
}
function hGradesBody() {
  const g = hState.grades;
  if (g.view === 'classDetail') {
    const cls = hGetClass(g.classId);
    if (!cls) { g.view = 'byClass'; return hGradesBody(); }
    return hGradesClassDetailScreen(cls);
  }
  const allIds = HEAD_DATA.students.map(s => s.id);
  const overallAvg = hAvg(HEAD_DATA.students.map(s => s.avgGrade));
  const dist = hGradeDistribution(allIds);
  const maxCount = Math.max(1, ...dist.map(b => b.count));
  const sorted = HEAD_DATA.students.slice().sort((a, b) => b.avgGrade - a.avgGrade);
  const highest = sorted[0];
  const lowest = sorted[sorted.length - 1];
  const atRisk = HEAD_DATA.students.filter(hStudentNeedsAttention);
  const subjects = hAllSubjects();

  return `
    <div class="gd-stat-row">
      <div class="stat-card"><div class="stat-label">${t('Overall Average')}</div><div class="stat-val">${overallAvg}/20</div><div class="stat-icon green">${aIcon('bar-chart')}</div></div>
      <div class="stat-card" style="cursor:pointer" onclick="hGoToStudentFromClass('${highest.id}')"><div class="stat-label">${t('Highest Performer')}</div><div class="stat-val" style="font-size:16px">${gdCommsEsc(hStudentFullName(highest))}</div><div class="stat-icon blue">${aIcon('star')}</div></div>
      <div class="stat-card" style="cursor:pointer" onclick="hGoToStudentFromClass('${lowest.id}')"><div class="stat-label">${t('Lowest Performer')}</div><div class="stat-val" style="font-size:16px">${gdCommsEsc(hStudentFullName(lowest))}</div><div class="stat-icon red">${aIcon('alert-triangle')}</div></div>
    </div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Grade Distribution')}</div></div>
      <div class="card-body">
        ${dist.map(b => `<div style="margin-bottom:10px"><div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:4px"><span>${b.label}</span><span style="color:var(--muted)">${b.count} ${t('students')}</span></div><div class="progress-track"><div class="progress-fill ${b.min>=16?'green':b.min>=12?'yellow':'red'}" style="width:${(b.count/maxCount*100).toFixed(0)}%"></div></div></div>`).join('')}
      </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Average by Class')}</div><span style="font-size:12px;color:var(--muted)">${t('Tap a class to drill down')}</span></div>
      <div class="card-body">
        ${HEAD_DATA.classes.map(c => `<div class="info-row" style="cursor:pointer;align-items:center" role="button" tabindex="0" onclick="hOpenGradesClass('${c.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hOpenGradesClass('${c.id}')}">
          <span>${gdCommsEsc(c.name)}</span><span style="color:var(--muted);font-size:12.5px">${hClassAvgGrade(c.id) !== null ? hClassAvgGrade(c.id) + '/20' : '—'}</span>
        </div>`).join('')}
      </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Average by Subject')}</div></div>
      <div class="card-body">
        ${subjects.map(sub => {
          const classes = hSubjectClasses(sub);
          const avg = hAvg(classes.map(c => hClassAvgGrade(c.id)).filter(v => v !== null));
          return `<div class="info-row"><span>${gdCommsEsc(t(sub))}</span><span style="color:var(--muted);font-size:12.5px">${avg !== null ? avg + '/20' : '—'}</span></div>`;
        }).join('')}
        <div style="font-size:11px;color:var(--muted);margin-top:10px">${t('Subject averages are computed from the classes teaching each subject, based on currently available data.')}</div>
      </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Students Needing Attention')}</div></div>
      <div class="card-body">
        ${atRisk.length ? atRisk.map(s => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hGoToStudentFromClass('${s.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hGoToStudentFromClass('${s.id}')}">
          <span>${gdCommsEsc(hStudentFullName(s))}</span><span style="color:var(--muted);font-size:12.5px">${s.avgGrade}/20</span>
        </div>`).join('') : `<div class="gd-empty-mini">${t('No students currently flagged.')}</div>`}
      </div></div>`;
}
function hOpenGradesClass(classId) {
  hState.grades.view = 'classDetail';
  hState.grades.classId = classId;
  hRefreshGrades();
}
function hBackToGradesOverview() {
  hState.grades.view = 'byClass';
  hState.grades.classId = null;
  hRefreshGrades();
}
function hRefreshGrades() { const el = document.getElementById('h-grades-content'); if (el) el.innerHTML = hGradesBody(); }
function hGradesClassDetailScreen(cls) {
  const roster = hClassStudents(cls.id);
  const dist = hGradeDistribution(roster.map(s => s.id));
  const maxCount = Math.max(1, ...dist.map(b => b.count));
  return `<div class="card"><div class="card-header">
    <div style="display:flex;align-items:center;gap:10px"><button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="hBackToGradesOverview()">${t('← Back')}</button><div class="card-title">${gdCommsEsc(cls.name)}</div></div>
    <span class="card-action" onclick="hGoToClassFromDashboard('${cls.id}')">${t('Manage Class')} →</span>
  </div>
    <div class="card-body">
      <div class="gd-pay-stat-row">
        <div class="stat-card"><div class="stat-label">${t('Avg. Performance')}</div><div class="stat-val">${hClassAvgGrade(cls.id) !== null ? hClassAvgGrade(cls.id) + '/20' : '—'}</div><div class="stat-icon green">${aIcon('bar-chart')}</div></div>
        <div class="stat-card"><div class="stat-label">${t('Students')}</div><div class="stat-val">${roster.length}</div><div class="stat-icon blue">${aIcon('users')}</div></div>
      </div>
      <div style="margin-top:16px;font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Grade Distribution')}</div>
      ${dist.map(b => `<div style="margin-bottom:10px"><div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:4px"><span>${b.label}</span><span style="color:var(--muted)">${b.count} ${t('students')}</span></div><div class="progress-track"><div class="progress-fill ${b.min>=16?'green':b.min>=12?'yellow':'red'}" style="width:${(b.count/maxCount*100).toFixed(0)}%"></div></div></div>`).join('')}
      <div style="margin-top:16px;font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Students (sorted by grade)')}</div>
      ${roster.slice().sort((a,b) => b.avgGrade - a.avgGrade).map(s => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hGoToStudentFromClass('${s.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hGoToStudentFromClass('${s.id}')}">
        <span>${gdCommsEsc(hStudentFullName(s))}</span><span>${s.avgGrade}/20</span>
      </div>`).join('')}
    </div></div>`;
}

/* ══════════════════════════════════════════════════════
   EXAM MANAGEMENT
══════════════════════════════════════════════════════ */
function hGetExam(examId) { return HEAD_DATA.exams.find(e => e.id === examId) || null; }
function hExamStatus(exam) { return exam.date >= tISODate(new Date(2026, 2, 11)) ? 'scheduled' : (exam.status === 'scheduled' ? 'completed' : exam.status); }
function hExamsView() {
  return `<div id="h-exams-content">${hExamsBody()}</div>`;
}
function hExamsBody() {
  const s = hState.exams;
  if (s.screen === 'form') return hExamFormScreen();
  if (s.screen === 'detail') {
    const exam = hGetExam(s.examId);
    if (!exam) { s.screen = 'list'; return hExamsBody(); }
    return hExamDetailScreen(exam);
  }
  return hExamListScreen();
}
function hRefreshExams() { const el = document.getElementById('h-exams-content'); if (el) el.innerHTML = hExamsBody(); }

function hFilteredExams() {
  const s = hState.exams;
  let list = HEAD_DATA.exams.slice();
  if (s.filterClassId !== 'all') list = list.filter(e => e.classId === s.filterClassId);
  if (s.filterStatus !== 'all') list = list.filter(e => hExamStatus(e) === s.filterStatus);
  const q = s.search.trim().toLowerCase();
  if (q) list = list.filter(e => e.name.toLowerCase().includes(q) || e.subject.toLowerCase().includes(q));
  return list.sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time));
}
function hExamListScreen() {
  const s = hState.exams;
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Exams')}</div><button class="st-btn sm" onclick="hOpenExamForm()">+ ${t('Create Exam')}</button></div>
    <div class="card-body">
      <input class="gd-comm-search-input" type="text" placeholder="${t('Search by exam name or subject...')}" value="${gdCommsEsc(s.search)}" oninput="hSetExamSearch(this.value)">
      <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:10px">
        <select onchange="hSetExamClassFilter(this.value)" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
          <option value="all" ${s.filterClassId==='all'?'selected':''}>${t('All Classes')}</option>
          ${HEAD_DATA.classes.map(c => `<option value="${c.id}" ${c.id===s.filterClassId?'selected':''}>${gdCommsEsc(c.name)}</option>`).join('')}
        </select>
        <select onchange="hSetExamStatusFilter(this.value)" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
          <option value="all" ${s.filterStatus==='all'?'selected':''}>${t('All Statuses')}</option>
          <option value="scheduled" ${s.filterStatus==='scheduled'?'selected':''}>${t('Scheduled')}</option>
          <option value="completed" ${s.filterStatus==='completed'?'selected':''}>${t('Completed')}</option>
        </select>
      </div>
    </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('All Exams')}</div></div>
      <div class="card-body" id="h-exam-list-results">${hExamListResultsBlock()}</div></div>`;
}
function hExamListResultsBlock() {
  const list = hFilteredExams();
  if (!list.length) return `<div class="gd-empty-mini">${t('No exams match your search or filters.')}</div>`;
  return list.map(e => {
    const cls = hGetClass(e.classId);
    const status = hExamStatus(e);
    return `<div class="info-row" style="cursor:pointer;align-items:center" role="button" tabindex="0" onclick="hOpenExamDetail('${e.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hOpenExamDetail('${e.id}')}">
      <span>${gdCommsEsc(e.name)}<div style="font-size:11px;color:var(--muted);margin-top:2px">${cls ? gdCommsEsc(cls.name) : ''} · ${e.date} ${e.time}</div></span>
      <span style="text-align:right;font-size:12.5px;color:var(--muted)">
        <span class="status-pill ${status==='scheduled'?'due':'resolved'}">${t(status.charAt(0).toUpperCase()+status.slice(1))}</span>
        ${e.locked ? `<div style="margin-top:4px"><span class="status-pill overdue">${aIcon('lock')} ${t('Locked')}</span></div>` : ''}
      </span>
    </div>`;
  }).join('');
}
function hSetExamSearch(v) { hState.exams.search = v; const el = document.getElementById('h-exam-list-results'); if (el) el.innerHTML = hExamListResultsBlock(); }
function hSetExamClassFilter(v) { hState.exams.filterClassId = v; hRefreshExamListResults(); }
function hSetExamStatusFilter(v) { hState.exams.filterStatus = v; hRefreshExamListResults(); }
function hRefreshExamListResults() { const el = document.getElementById('h-exam-list-results'); if (el) el.innerHTML = hExamListResultsBlock(); }

/* ── Exam Detail (real results + publish/lock) ── */
function hOpenExamDetail(examId) {
  hState.exams.screen = 'detail';
  hState.exams.examId = examId;
  hRefreshExams();
}
function hBackToExamList() {
  hState.exams.screen = 'list';
  hState.exams.examId = null;
  hRefreshExams();
}
function hExamDetailScreen(exam) {
  const cls = hGetClass(exam.classId);
  const status = hExamStatus(exam);
  const roster = hClassStudents(exam.classId);
  const scored = roster.filter(s => exam.scores[s.id] !== undefined);
  const avgScore = hAvg(scored.map(s => exam.scores[s.id]));
  return `<div class="card">
    <div class="card-header">
      <div style="display:flex;align-items:center;gap:10px;min-width:0;flex:1">
        <button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="hBackToExamList()">${t('← Back')}</button>
        <div class="card-title" style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${gdCommsEsc(exam.name)}</div>
      </div>
      <button type="button" class="st-btn ghost sm" onclick="hOpenExamForm('${exam.id}')">${t('Edit')}</button>
    </div>
    <div class="card-body" id="h-exam-detail-body">${hExamDetailBody(exam, cls, status, roster, scored, avgScore)}</div>
  </div>`;
}
function hExamDetailBody(exam, cls, status, roster, scored, avgScore) {
  return `
    <div class="info-row"><span>${t('Class')}</span><span>${cls ? gdCommsEsc(cls.name) : '—'}</span></div>
    <div class="info-row"><span>${t('Subject')}</span><span>${gdCommsEsc(t(exam.subject))}</span></div>
    <div class="info-row"><span>${t('Date & Time')}</span><span>${exam.date} · ${exam.time}</span></div>
    <div class="info-row"><span>${t('Duration')}</span><span>${exam.duration} ${t('minutes')}</span></div>
    <div class="info-row"><span>${t('Maximum Score')}</span><span>${exam.maxScore}</span></div>
    <div class="info-row"><span>${t('Status')}</span><span class="status-pill ${status==='scheduled'?'due':'resolved'}">${t(status.charAt(0).toUpperCase()+status.slice(1))}</span></div>
    ${status === 'completed' ? `
      <div style="margin-top:16px;padding-top:14px;border-top:0.5px solid var(--separator)">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
          <span style="font-size:12.5px;font-weight:600">${t('Results')}</span>
          <span class="status-pill ${exam.locked?'overdue':'awaiting'}">${exam.locked ? aIcon('lock')+' '+t('Locked') : t('Unlocked')}</span>
        </div>
        <div class="gd-pay-stat-row" style="margin-bottom:12px">
          <div class="stat-card"><div class="stat-label">${t('Scored')}</div><div class="stat-val">${scored.length}/${roster.length}</div><div class="stat-icon blue">${aIcon('edit')}</div></div>
          <div class="stat-card"><div class="stat-label">${t('Class Average')}</div><div class="stat-val">${avgScore !== null ? avgScore + '/' + exam.maxScore : '—'}</div><div class="stat-icon green">${aIcon('bar-chart')}</div></div>
        </div>
        ${roster.map(s => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hGoToStudentFromClass('${s.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hGoToStudentFromClass('${s.id}')}">
          <span>${gdCommsEsc(hStudentFullName(s))}</span><span>${exam.scores[s.id] !== undefined ? exam.scores[s.id] + '/' + exam.maxScore : '—'}</span>
        </div>`).join('')}
        <div style="margin-top:12px">
          ${exam.locked
            ? `<button class="st-btn ghost sm" onclick="hConfirmUnlockExamResults('${exam.id}')">${t('Unlock Results')}</button>`
            : `<button class="st-btn ghost sm" onclick="hConfirmPublishLockExam('${exam.id}')">${t('Publish & Lock Results')}</button>`}
        </div>
      </div>` : `<div style="font-size:11.5px;color:var(--muted);margin-top:16px">${t('Results will be available once this exam has taken place.')}</div>`}`;
}
function hRefreshExamDetail() {
  const exam = hGetExam(hState.exams.examId);
  if (!exam) return;
  const cls = hGetClass(exam.classId);
  const status = hExamStatus(exam);
  const roster = hClassStudents(exam.classId);
  const scored = roster.filter(s => exam.scores[s.id] !== undefined);
  const avgScore = hAvg(scored.map(s => exam.scores[s.id]));
  const el = document.getElementById('h-exam-detail-body');
  if (el) el.innerHTML = hExamDetailBody(exam, cls, status, roster, scored, avgScore);
}
function hConfirmPublishLockExam(examId) {
  stOpenModal(`<h3 style="margin-bottom:10px">${t('Publish and lock these results?')}</h3>
    <p style="font-size:13px;color:var(--muted);margin-bottom:18px">${t('Once locked, results become final and visible school-wide. This cannot be edited by teachers unless unlocked again.')}</p>
    <div style="display:flex;gap:10px">
      <button class="st-btn" onclick="hPublishLockExam('${examId}');stCloseModal()">${t('Publish & Lock')}</button>
      <button class="st-btn ghost" onclick="stCloseModal()">${t('Cancel')}</button>
    </div>`);
}
function hPublishLockExam(examId) {
  const exam = hGetExam(examId);
  if (!exam) return;
  exam.locked = true;
  hLogAudit('Exam Results Locked', 'Exam', exam.name, 'Unlocked', 'Locked');
  hRefreshExamDetail();
  hShowToast(t('Results published and locked.'));
}
function hConfirmUnlockExamResults(examId) {
  stOpenModal(`<h3 style="margin-bottom:10px">${t('Unlock these results?')}</h3>
    <p style="font-size:13px;color:var(--muted);margin-bottom:18px">${t('This will allow results for this exam to be edited again.')}</p>
    <div style="display:flex;gap:10px">
      <button class="st-btn" onclick="hUnlockExamResults('${examId}');stCloseModal()">${t('Unlock')}</button>
      <button class="st-btn ghost" onclick="stCloseModal()">${t('Cancel')}</button>
    </div>`);
}
function hUnlockExamResults(examId) {
  const exam = hGetExam(examId);
  if (!exam) return;
  exam.locked = false;
  hRefreshExamDetail();
  hShowToast(t('Results unlocked.'));
}

/* ── Create / Edit Exam form (with scheduling-conflict detection) ── */
function hOpenExamForm(examId) {
  if (examId) {
    const exam = hGetExam(examId);
    if (!exam) return;
    hState.exams.form = { mode:'edit', id:exam.id, name:exam.name, classId:exam.classId, subject:exam.subject, date:exam.date, time:exam.time, duration:exam.duration, maxScore:exam.maxScore };
  } else {
    hState.exams.form = { mode:'create', id:null, name:'', classId: HEAD_DATA.classes[0] ? HEAD_DATA.classes[0].id : '', subject:'', date:'', time:'', duration:60, maxScore:20 };
  }
  hState.exams.screen = 'form';
  hState.exams.error = '';
  hRefreshExams();
}
function hCancelExamForm() {
  hState.exams.screen = (hState.exams.form && hState.exams.form.mode === 'edit') ? 'detail' : 'list';
  hState.exams.form = null;
  hState.exams.error = '';
  hRefreshExams();
}
function hExamFormScreen() {
  const f = hState.exams.form;
  const err = hState.exams.error;
  return `<div class="card"><div class="card-header"><div class="card-title">${f.mode==='edit'?t('Edit Exam'):t('Create Exam')}</div></div>
    <div class="card-body">
      <div class="st-field"><label>${t('Exam Name')}</label><input id="h-ex-name" value="${gdCommsEsc(f.name)}"></div>
      <div class="st-field"><label>${t('Class')}</label><select id="h-ex-class">
        ${HEAD_DATA.classes.map(c => `<option value="${c.id}" ${c.id===f.classId?'selected':''}>${gdCommsEsc(c.name)}</option>`).join('')}
      </select></div>
      <div class="st-field"><label>${t('Subject')}</label><input id="h-ex-subject" value="${gdCommsEsc(f.subject)}" placeholder="${t('e.g. Mathematics')}"></div>
      <div style="display:flex;gap:10px">
        <div class="st-field" style="flex:1"><label>${t('Date')}</label><input id="h-ex-date" type="date" value="${f.date}"></div>
        <div class="st-field" style="flex:1"><label>${t('Time')}</label><input id="h-ex-time" type="time" value="${f.time}"></div>
      </div>
      <div style="display:flex;gap:10px">
        <div class="st-field" style="flex:1"><label>${t('Duration (minutes)')}</label><input id="h-ex-duration" type="number" min="1" value="${f.duration}"></div>
        <div class="st-field" style="flex:1"><label>${t('Maximum Score')}</label><input id="h-ex-maxscore" type="number" min="1" value="${f.maxScore}"></div>
      </div>
      <div style="display:flex;gap:10px">
        <button class="st-btn" onclick="hSaveExam()" ${hState.exams.saving?'disabled':''}>${hState.exams.saving ? `<span class="gd-spinner"></span>${t('Saving...')}` : (f.mode==='edit'?t('Save Changes'):t('Create Exam'))}</button>
        <button class="st-btn ghost" onclick="hCancelExamForm()" ${hState.exams.saving?'disabled':''}>${t('Cancel')}</button>
      </div>
      ${err ? `<div class="st-inline-msg err show" style="margin-top:12px">${err}</div>` : ''}
    </div></div>`;
}
function hSaveExam() {
  const f = hState.exams.form;
  const name = (document.getElementById('h-ex-name').value || '').trim();
  const classId = document.getElementById('h-ex-class').value;
  const subject = (document.getElementById('h-ex-subject').value || '').trim();
  const date = document.getElementById('h-ex-date').value;
  const time = document.getElementById('h-ex-time').value;
  const duration = Number(document.getElementById('h-ex-duration').value);
  const maxScore = Number(document.getElementById('h-ex-maxscore').value);
  Object.assign(f, { name, classId, subject, date, time, duration, maxScore });

  let err = '';
  if (!name) err = t('Exam name is required.');
  else if (!classId) err = t('Select a class.');
  else if (!subject) err = t('Subject is required.');
  else if (!date) err = t('Select a date.');
  else if (!time) err = t('Select a time.');
  else if (!duration || duration <= 0) err = t('Duration must be greater than 0.');
  else if (!maxScore || maxScore <= 0) err = t('Maximum score must be greater than 0.');
  else {
    const parts = time.split(':').map(Number);
    const startMin = parts[0] * 60 + parts[1];
    const endMin = startMin + duration;
    const conflict = HEAD_DATA.exams.find(e => {
      if (e.id === f.id) return false;
      if (e.classId !== classId || e.date !== date) return false;
      const eParts = e.time.split(':').map(Number);
      const eStart = eParts[0] * 60 + eParts[1];
      const eEnd = eStart + e.duration;
      return startMin < eEnd && eStart < endMin;
    });
    if (conflict) err = `${t('This class already has an exam scheduled at an overlapping time')} (${conflict.name}).`;
  }

  hState.exams.error = err;
  if (err) { hRefreshExams(); return; }

  hState.exams.saving = true;
  hRefreshExams();
  setTimeout(() => {
    if (f.mode === 'edit') {
      const exam = hGetExam(f.id);
      Object.assign(exam, { name, classId, subject, date, time, duration, maxScore });
      hState.exams.screen = 'detail';
      hState.exams.examId = exam.id;
      hShowToast(t('Exam updated successfully.'));
    } else {
      const newExam = { id:'he' + Date.now(), name, classId, subject, date, time, duration, maxScore, status: date >= tISODate(new Date(2026, 2, 11)) ? 'scheduled' : 'completed', locked:false, scores:{} };
      HEAD_DATA.exams.push(newExam);
      hLogAudit('Exam Created', 'Exam', name, '', `${hGetClass(classId) ? hGetClass(classId).name : ''} · ${date}`);
      hState.exams.screen = 'detail';
      hState.exams.examId = newExam.id;
      hShowToast(t('Exam created successfully.'));
    }
    hState.exams.saving = false;
    hState.exams.form = null;
    hRefreshExams();
  }, 700);
}

/* ══════════════════════════════════════════════════════
   HOMEWORK OVERVIEW
══════════════════════════════════════════════════════ */
function hGetHomework(hwId) { return HEAD_DATA.homework.find(h => h.id === hwId) || null; }
function hHomeworkStatus(hw, studentId) {
  const explicit = hw.submissions[studentId];
  if (explicit === 'submitted' || explicit === 'late') return explicit;
  if (explicit === 'missing') return hw.dueDate >= tISODate(new Date(2026, 2, 11)) ? 'pending' : 'missing';
  return 'pending';
}
function hHomeworkCounts(hw) {
  const roster = hClassStudents(hw.classId);
  const counts = { submitted:0, late:0, missing:0, pending:0, overdue:0, total:roster.length };
  const today = tISODate(new Date(2026, 2, 11));
  roster.forEach(s => {
    const raw = hw.submissions[s.id];
    if (raw === 'submitted') counts.submitted++;
    else if (raw === 'late') counts.late++;
    else if (hw.dueDate < today) counts.overdue++;
    else counts.pending++;
  });
  return counts;
}
function hHomeworkView() {
  const tabs = [ { id:'overview', label:'Overview' }, { id:'analytics', label:'Analytics' } ];
  return `<div class="st-tabs">${tabs.map(tb => `<div class="st-tab gd-tab-hhw${tb.id===hState.homework.tab?' active':''}" data-tab="${tb.id}" onclick="hSetHomeworkTab('${tb.id}')">${t(tb.label)}</div>`).join('')}</div>
    <div id="h-homework-content">${hHomeworkTabBody()}</div>`;
}
function hSetHomeworkTab(tabId) {
  hState.homework.tab = tabId;
  document.querySelectorAll('.gd-tab-hhw').forEach(el => el.classList.toggle('active', el.dataset.tab === tabId));
  const el = document.getElementById('h-homework-content');
  if (el) el.innerHTML = hHomeworkTabBody();
}
function hHomeworkTabBody() {
  return hState.homework.tab === 'analytics' ? hHomeworkAnalyticsTab() : hHomeworkBody();
}
function hHomeworkBody() {
  const s = hState.homework;
  if (s.screen === 'detail') {
    const hw = hGetHomework(s.hwId);
    if (!hw) { s.screen = 'list'; return hHomeworkBody(); }
    return hHomeworkDetailScreen(hw);
  }
  return hHomeworkListScreen();
}
function hRefreshHomework() { const el = document.getElementById('h-homework-content'); if (el) el.innerHTML = hHomeworkBody(); }

function hFilteredHomework() {
  const s = hState.homework;
  let list = HEAD_DATA.homework.slice();
  if (s.filterClassId !== 'all') list = list.filter(h => h.classId === s.filterClassId);
  const today = tISODate(new Date(2026, 2, 11));
  if (s.filterStatus === 'overdue') list = list.filter(h => h.dueDate < today);
  else if (s.filterStatus === 'upcoming') list = list.filter(h => h.dueDate >= today);
  return list.sort((a, b) => a.dueDate.localeCompare(b.dueDate));
}
function hHomeworkListScreen() {
  const s = hState.homework;
  const today = tISODate(new Date(2026, 2, 11));
  const totalOverdue = HEAD_DATA.homework.filter(h => h.dueDate < today).reduce((sum, h) => sum + hHomeworkCounts(h).overdue, 0);
  const totalPending = HEAD_DATA.homework.reduce((sum, h) => sum + hHomeworkCounts(h).pending, 0);
  const totalSubmitted = HEAD_DATA.homework.reduce((sum, h) => sum + hHomeworkCounts(h).submitted, 0);
  return `
    <div class="gd-stat-row">
      <div class="stat-card"><div class="stat-label">${t('Assigned')}</div><div class="stat-val">${HEAD_DATA.homework.length}</div><div class="stat-icon blue">${aIcon('book')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Submitted')}</div><div class="stat-val">${totalSubmitted}</div><div class="stat-icon green">${aIcon('check-circle')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Pending')}</div><div class="stat-val">${totalPending}</div><div class="stat-icon yellow">${aIcon('clock')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Overdue (missing)')}</div><div class="stat-val">${totalOverdue}</div><div class="stat-icon red">${aIcon('x-circle')}</div></div>
    </div>
    <div class="card" style="margin-top:16px"><div class="card-body">
      <div style="display:flex;gap:10px;flex-wrap:wrap">
        <select onchange="hSetHomeworkClassFilter(this.value)" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
          <option value="all" ${s.filterClassId==='all'?'selected':''}>${t('All Classes')}</option>
          ${HEAD_DATA.classes.map(c => `<option value="${c.id}" ${c.id===s.filterClassId?'selected':''}>${gdCommsEsc(c.name)}</option>`).join('')}
        </select>
        <div class="gd-comm-filter-row">
          ${[['all','All'],['upcoming','Upcoming'],['overdue','Overdue']].map(([id,label]) => `<div class="gd-comm-filter-chip${s.filterStatus===id?' active':''}" onclick="hSetHomeworkStatusFilter('${id}')">${t(label)}</div>`).join('')}
        </div>
      </div>
    </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Homework')}</div></div>
      <div class="card-body" id="h-homework-list-results">${hHomeworkListResultsBlock()}</div></div>`;
}
function hHomeworkListResultsBlock() {
  const list = hFilteredHomework();
  if (!list.length) return `<div class="gd-empty-mini">${t('No homework matches your filters.')}</div>`;
  const today = tISODate(new Date(2026, 2, 11));
  return list.map(hw => {
    const cls = hGetClass(hw.classId);
    const counts = hHomeworkCounts(hw);
    const overdue = hw.dueDate < today;
    return `<div class="info-row" style="cursor:pointer;align-items:center" role="button" tabindex="0" onclick="hOpenHomeworkDetail('${hw.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hOpenHomeworkDetail('${hw.id}')}">
      <span>${gdCommsEsc(hw.title)}<div style="font-size:11px;color:var(--muted);margin-top:2px">${cls ? gdCommsEsc(cls.name) : ''} · ${gdCommsEsc(t(hw.subject))} · ${t('Due')} ${hw.dueDate}</div></span>
      <span style="text-align:right;font-size:12.5px;color:var(--muted)">${counts.submitted}/${counts.total} ${t('submitted')}${overdue && counts.overdue > 0 ? `<div style="margin-top:4px"><span class="status-pill overdue">${counts.overdue} ${t('missing')}</span></div>` : ''}</span>
    </div>`;
  }).join('');
}
function hSetHomeworkClassFilter(v) { hState.homework.filterClassId = v; hRefreshHomeworkListResults(); }
function hSetHomeworkStatusFilter(v) { hState.homework.filterStatus = v; hRefreshHomeworkListResults(); }
function hRefreshHomeworkListResults() { const el = document.getElementById('h-homework-list-results'); if (el) el.innerHTML = hHomeworkListResultsBlock(); }

function hOpenHomeworkDetail(hwId) {
  hState.homework.screen = 'detail';
  hState.homework.hwId = hwId;
  hRefreshHomework();
}
function hBackToHomeworkList() {
  hState.homework.screen = 'list';
  hState.homework.hwId = null;
  hRefreshHomework();
}
function hHomeworkDetailScreen(hw) {
  const cls = hGetClass(hw.classId);
  const roster = hClassStudents(hw.classId);
  const today = tISODate(new Date(2026, 2, 11));
  const overdue = hw.dueDate < today;
  return `<div class="card">
    <div class="card-header">
      <div style="display:flex;align-items:center;gap:10px;min-width:0;flex:1">
        <button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="hBackToHomeworkList()">${t('← Back')}</button>
        <div class="card-title" style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${gdCommsEsc(hw.title)}</div>
      </div>
    </div>
    <div class="card-body">
      <div class="info-row"><span>${t('Class')}</span><span>${cls ? gdCommsEsc(cls.name) : '—'}</span></div>
      <div class="info-row"><span>${t('Subject')}</span><span>${gdCommsEsc(t(hw.subject))}</span></div>
      <div class="info-row"><span>${t('Due Date')}</span><span>${hw.dueDate}</span></div>
      <div style="margin-top:16px;padding-top:14px;border-top:0.5px solid var(--separator)">
        <div style="font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Submission Status')}</div>
        ${roster.map(s => {
          const raw = hw.submissions[s.id];
          const status = raw === 'submitted' || raw === 'late' ? raw : (overdue ? 'missing' : 'pending');
          const meta = { submitted:{cls:'open',label:'Submitted'}, late:{cls:'awaiting',label:'Late'}, missing:{cls:'overdue',label:'Missing'}, pending:{cls:'resolved',label:'Not Due Yet'} }[status];
          return `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hGoToStudentFromClass('${s.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hGoToStudentFromClass('${s.id}')}">
            <span>${gdCommsEsc(hStudentFullName(s))}</span><span class="status-pill ${meta.cls}">${t(meta.label)}</span>
          </div>`;
        }).join('') || `<div class="gd-empty-mini">${t('No students in this class.')}</div>`}
      </div>
    </div>
  </div>`;
}

/* ══════════════════════════════════════════════════════
   COMMUNICATION (school-wide announcements)
══════════════════════════════════════════════════════ */
function hAudienceLabel(announcement) {
  if (announcement.audience === 'school') return t('Entire School');
  if (announcement.audience === 'teachers') return t('All Teachers');
  if (announcement.audience === 'guardians') return t('All Guardians');
  if (announcement.audience === 'students') return t('All Students');
  if (announcement.audience === 'class') { const c = hGetClass(announcement.audienceClassId); return c ? c.name : t('Specific Class'); }
  return announcement.audience;
}
function hAudienceRecipientCount(audience, classId) {
  if (audience === 'school') return HEAD_DATA.students.length + HEAD_DATA.teachers.length + HEAD_DATA.guardians.length;
  if (audience === 'teachers') return HEAD_DATA.teachers.length;
  if (audience === 'guardians') return HEAD_DATA.guardians.length;
  if (audience === 'students') return HEAD_DATA.students.length;
  if (audience === 'class') return hClassStudents(classId).length;
  return 0;
}
function hCommsView() {
  const tabs = [ { id:'main', label:'Compose & History' }, { id:'drafts', label:'Drafts & Scheduled' }, { id:'templates', label:'Templates & Groups' }, { id:'analytics', label:'Analytics' } ];
  return `<div class="st-tabs">${tabs.map(tb => `<div class="st-tab gd-tab-hcom${tb.id===hState.comms.tab?' active':''}" data-tab="${tb.id}" onclick="hSetCommsTab('${tb.id}')">${t(tb.label)}</div>`).join('')}</div>
    <div id="h-comms-content">${hCommsTabBody()}</div>`;
}
function hSetCommsTab(tabId) {
  hState.comms.tab = tabId;
  document.querySelectorAll('.gd-tab-hcom').forEach(el => el.classList.toggle('active', el.dataset.tab === tabId));
  const el = document.getElementById('h-comms-content');
  if (el) el.innerHTML = hCommsTabBody();
}
function hCommsTabBody() {
  if (hState.comms.tab === 'drafts') return hCommsDraftsTab();
  if (hState.comms.tab === 'analytics') return hCommsAnalyticsTab();
  if (hState.comms.tab === 'templates') return hCommsTemplatesTab();
  return hCommsBody();
}
function hCommsBody() {
  const s = hState.comms;
  if (s.screen === 'compose') return hCommsComposeScreen();
  if (s.screen === 'detail') {
    const a = HEAD_DATA.announcements.find(x => x.id === s.announcementId);
    if (!a) { s.screen = 'list'; return hCommsBody(); }
    return hCommsDetailScreen(a);
  }
  return hCommsListScreen();
}
function hRefreshComms() { const el = document.getElementById('h-comms-content'); if (el) el.innerHTML = hCommsBody(); }

function hCommsListScreen() {
  const s = hState.comms;
  let sorted = HEAD_DATA.announcements.filter(a => a.status === 'sent');
  if (s.historyAudienceFilter !== 'all') sorted = sorted.filter(a => a.audience === s.historyAudienceFilter);
  const q = s.historySearch.trim().toLowerCase();
  if (q) sorted = sorted.filter(a => a.subject.toLowerCase().includes(q) || a.message.toLowerCase().includes(q));
  sorted = sorted.sort((a, b) => b.sentAt.localeCompare(a.sentAt));
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Communication History')}</div><button class="st-btn sm" onclick="hOpenComposeAnnouncement()">+ ${t('New Announcement')}</button></div>
    <div class="card-body">
      <div style="font-size:11.5px;color:var(--muted);margin-bottom:12px">${t('Only sent announcements appear here — drafts and scheduled messages are under Drafts & Scheduled.')}</div>
      <input class="gd-comm-search-input" type="text" placeholder="${t('Search sent announcements...')}" value="${gdCommsEsc(s.historySearch)}" oninput="hSetCommsHistorySearch(this.value)">
      <select onchange="hSetCommsHistoryAudienceFilter(this.value)" style="margin-top:10px;background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
        <option value="all" ${s.historyAudienceFilter==='all'?'selected':''}>${t('All Audiences')}</option>
        <option value="school" ${s.historyAudienceFilter==='school'?'selected':''}>${t('Entire School')}</option>
        <option value="class" ${s.historyAudienceFilter==='class'?'selected':''}>${t('Specific Class')}</option>
        <option value="teachers" ${s.historyAudienceFilter==='teachers'?'selected':''}>${t('Teachers')}</option>
        <option value="guardians" ${s.historyAudienceFilter==='guardians'?'selected':''}>${t('Guardians')}</option>
        <option value="students" ${s.historyAudienceFilter==='students'?'selected':''}>${t('Students')}</option>
      </select>
      <div id="h-comms-history-results" style="margin-top:10px">${hCommsHistoryResultsBlock()}</div>
    </div></div>`;
}
function hCommsHistoryResultsBlock() {
  const s = hState.comms;
  let sorted = HEAD_DATA.announcements.filter(a => a.status === 'sent');
  if (s.historyAudienceFilter !== 'all') sorted = sorted.filter(a => a.audience === s.historyAudienceFilter);
  const q = s.historySearch.trim().toLowerCase();
  if (q) sorted = sorted.filter(a => a.subject.toLowerCase().includes(q) || a.message.toLowerCase().includes(q));
  sorted = sorted.sort((a, b) => b.sentAt.localeCompare(a.sentAt));
  if (!sorted.length) return `<div class="gd-empty-state"><div class="gd-empty-state-title">${t('No announcements match')}</div><div class="gd-empty-state-sub">${t('Try a different search or filter.')}</div></div>`;
  return sorted.map(a => `<div class="info-row" style="cursor:pointer;align-items:flex-start" role="button" tabindex="0" onclick="hOpenAnnouncementDetail('${a.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hOpenAnnouncementDetail('${a.id}')}">
    <span>${gdCommsEsc(a.subject)}<div style="font-size:11.5px;color:var(--muted);margin-top:4px;max-width:360px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${gdCommsEsc(a.message)}</div></span>
    <span style="text-align:right;flex-shrink:0"><span class="status-pill open">${hAudienceLabel(a)}</span><div style="font-size:11px;color:var(--muted);margin-top:4px">${a.sentAt.slice(0,10)}</div></span>
  </div>`).join('');
}
function hSetCommsHistorySearch(v) { hState.comms.historySearch = v; const el = document.getElementById('h-comms-history-results'); if (el) el.innerHTML = hCommsHistoryResultsBlock(); }
function hSetCommsHistoryAudienceFilter(v) { hState.comms.historyAudienceFilter = v; const el = document.getElementById('h-comms-history-results'); if (el) el.innerHTML = hCommsHistoryResultsBlock(); }
function hOpenAnnouncementDetail(id) {
  hState.comms.screen = 'detail';
  hState.comms.announcementId = id;
  hRefreshComms();
}
function hBackToCommsList() {
  hState.comms.screen = 'list';
  hState.comms.announcementId = null;
  hRefreshComms();
}
function hCommsDetailScreen(a) {
  return `<div class="card"><div class="card-header">
    <div style="display:flex;align-items:center;gap:10px"><button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="hBackToCommsList()">${t('← Back')}</button><div class="card-title">${gdCommsEsc(a.subject)}</div></div>
  </div>
    <div class="card-body">
      <div class="info-row"><span>${t('Audience')}</span><span>${hAudienceLabel(a)} (${hAudienceRecipientCount(a.audience, a.audienceClassId)} ${t('recipients')})</span></div>
      <div class="info-row"><span>${t('Sent')}</span><span>${a.sentAt.slice(0,10)} · ${a.sentAt.slice(11,16)}</span></div>
      <div class="info-row"><span>${t('Sent By')}</span><span>${gdCommsEsc(a.sentBy)}</span></div>
      <div style="margin-top:14px;padding-top:14px;border-top:0.5px solid var(--separator);font-size:13px;line-height:1.6;white-space:pre-wrap">${gdCommsEsc(a.message)}</div>
    </div></div>`;
}

/* ── Compose (audience selection + real preview + send) ── */
function hOpenComposeAnnouncement() {
  hState.comms.screen = 'compose';
  hState.comms.compose = { subject:'', message:'', audience:'school', audienceClassId: HEAD_DATA.classes[0] ? HEAD_DATA.classes[0].id : null, preview:false };
  hState.comms.error = '';
  hRefreshComms();
}
function hCancelCompose() {
  hState.comms.screen = 'list';
  hRefreshComms();
}
function hSetComposeClass(v) { hState.comms.compose.audienceClassId = v; }
function hSetComposeAudience(v) {
  hState.comms.compose.audience = v;
  hState.comms.compose.preview = false;
  const subjEl = document.getElementById('h-comp-subject');
  const msgEl = document.getElementById('h-comp-message');
  if (subjEl) hState.comms.compose.subject = subjEl.value;
  if (msgEl) hState.comms.compose.message = msgEl.value;
  hRefreshComms();
}
function hCommsComposeScreen() {
  const c = hState.comms.compose;
  const err = hState.comms.error;
  const audiences = [['school','Entire School'],['class','Specific Class'],['teachers','All Teachers'],['guardians','All Guardians'],['students','All Students']];
  return `<div class="card"><div class="card-header">
    <div style="display:flex;align-items:center;gap:10px"><button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="hCancelCompose()">${t('← Back')}</button><div class="card-title">${t('New Announcement')}</div></div>
  </div>
    <div class="card-body">
      <div class="st-field"><label>${t('Audience')}</label><select id="h-comp-audience" onchange="hSetComposeAudience(this.value)">
        ${audiences.map(([id,label]) => `<option value="${id}" ${id===c.audience?'selected':''}>${t(label)}</option>`).join('')}
      </select></div>
      ${c.audience === 'class' ? `<div class="st-field"><label>${t('Class')}</label><select id="h-comp-class" onchange="hSetComposeClass(this.value)">
        ${HEAD_DATA.classes.map(cl => `<option value="${cl.id}" ${cl.id===c.audienceClassId?'selected':''}>${gdCommsEsc(cl.name)}</option>`).join('')}
      </select></div>` : ''}
      <div class="st-field"><label>${t('Subject')}</label><input id="h-comp-subject" value="${gdCommsEsc(c.subject)}"></div>
      <div class="st-field"><label>${t('Message')}</label><textarea id="h-comp-message" rows="5">${gdCommsEsc(c.message)}</textarea></div>
      <div style="margin-bottom:10px">
        <label style="display:flex;align-items:center;gap:8px;font-size:12.5px;color:var(--muted);cursor:pointer"><input type="checkbox" ${c.scheduleMode?'checked':''} onchange="hToggleScheduleMode(this.checked)"> ${t('Schedule for later instead of sending now')}</label>
        ${c.scheduleMode ? `<div style="display:flex;gap:10px;margin-top:8px">
          <input id="h-comp-sched-date" type="date" value="${c.scheduledDate||''}" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
          <input id="h-comp-sched-time" type="time" value="${c.scheduledTime||''}" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
        </div>` : ''}
      </div>
      <div style="display:flex;gap:10px;flex-wrap:wrap">
        <button class="st-btn ghost" onclick="hPreviewAnnouncement()">${t('Preview')}</button>
        <button class="st-btn ghost" onclick="hSaveAnnouncementDraft()">${t('Save as Draft')}</button>
        <button class="st-btn" onclick="${c.scheduleMode ? 'hScheduleAnnouncement()' : 'hSendAnnouncement()'}" ${hState.comms.sending?'disabled':''}>${hState.comms.sending ? `<span class="gd-spinner"></span>${t('Sending...')}` : (c.scheduleMode ? t('Schedule') : t('Send'))}</button>
      </div>
      ${err ? `<div class="st-inline-msg err show" style="margin-top:12px">${err}</div>` : ''}
      <div id="h-comp-preview">${c.preview ? hAnnouncementPreviewBlock(c) : ''}</div>
    </div></div>`;
}
function hAnnouncementPreviewBlock(c) {
  const recipientCount = hAudienceRecipientCount(c.audience, c.audienceClassId);
  const audienceLabel = c.audience === 'class' ? (hGetClass(c.audienceClassId) ? hGetClass(c.audienceClassId).name : t('Specific Class')) : { school:t('Entire School'), teachers:t('All Teachers'), guardians:t('All Guardians'), students:t('All Students') }[c.audience];
  return `<div class="card" style="margin-top:14px;background:var(--surface2)"><div class="card-header"><div class="card-title">${t('Preview')}</div></div>
    <div class="card-body">
      <div style="font-size:11.5px;color:var(--muted);margin-bottom:8px">${t('To')}: ${audienceLabel} (${recipientCount} ${t('recipients')})</div>
      <div style="font-weight:700;font-size:14px;margin-bottom:8px">${gdCommsEsc(c.subject) || `<span style="color:var(--muted)">${t('(No subject)')}</span>`}</div>
      <div style="font-size:13px;line-height:1.6;white-space:pre-wrap">${gdCommsEsc(c.message) || `<span style="color:var(--muted)">${t('(No message)')}</span>`}</div>
    </div></div>`;
}
function hPreviewAnnouncement() {
  const c = hState.comms.compose;
  c.subject = (document.getElementById('h-comp-subject').value || '').trim();
  c.message = (document.getElementById('h-comp-message').value || '').trim();
  if (c.audience === 'class') { const sel = document.getElementById('h-comp-class'); if (sel) c.audienceClassId = sel.value; }
  c.preview = true;
  const el = document.getElementById('h-comp-preview');
  if (el) el.innerHTML = hAnnouncementPreviewBlock(c);
}
function hSendAnnouncement() {
  const c = hState.comms.compose;
  c.subject = (document.getElementById('h-comp-subject').value || '').trim();
  c.message = (document.getElementById('h-comp-message').value || '').trim();
  if (c.audience === 'class') { const sel = document.getElementById('h-comp-class'); if (sel) c.audienceClassId = sel.value; }

  let err = '';
  if (!c.subject) err = t('Subject is required.');
  else if (!c.message) err = t('Message is required.');
  else if (c.audience === 'class' && !c.audienceClassId) err = t('Select a class.');

  hState.comms.error = err;
  if (err) { hRefreshComms(); return; }

  hState.comms.sending = true;
  hRefreshComms();
  setTimeout(() => {
    const newAnnouncement = {
      id:'han' + Date.now(), subject:c.subject, message:c.message, audience:c.audience,
      audienceClassId: c.audience === 'class' ? c.audienceClassId : null,
      sentAt: new Date(2026, 2, 11, 12, 0).toISOString(), sentBy: HEAD_DATA.adminProfile.name, status:'sent',
      readRate: Math.round(40 + hSeededRandom('han' + Date.now()) * 55),
    };
    HEAD_DATA.announcements.unshift(newAnnouncement);
    hLogAudit('Communication Sent', 'Announcement', newAnnouncement.subject, '', hAudienceLabel(newAnnouncement));
    hState.comms.sending = false;
    hState.comms.screen = 'detail';
    hState.comms.announcementId = newAnnouncement.id;
    hRefreshComms();
    hShowToast(t('Announcement sent successfully.'));
  }, 700);
}

/* ══════════════════════════════════════════════════════
   SCHOOL CALENDAR (month view, reusing Guardian's existing .gd-cal-*
   CSS grid — already loaded globally — with real create/edit/delete)
══════════════════════════════════════════════════════ */
const H_EVENT_CATEGORIES = ['academic', 'meeting', 'event', 'holiday'];
function hGetEvent(eventId) { return HEAD_DATA.events.find(e => e.id === eventId) || null; }
function hEventsForDate(dateStr) { return HEAD_DATA.events.filter(e => e.date === dateStr); }
function hAudienceLabelSimple(audience) { return { school:t('Entire School'), teachers:t('Teachers'), guardians:t('Guardians'), students:t('Students') }[audience] || audience; }
/* Unified real entries across every relevant real data source — Advanced
   Calendar shows Exams, Homework deadlines, and Orientation alongside
   manually-created events, rather than being a second disconnected
   calendar. Each entry links back to its actual source record. */
function hAllCalendarEntriesForDate(dateStr) {
  const src = hState.calendar.sources;
  const entries = [];
  if (src.events) hEventsForDate(dateStr).forEach(e => entries.push({ srcType:'event', id:e.id, title:e.title, category:e.category, time:e.startTime, endTime:e.endTime }));
  if (src.exams) HEAD_DATA.exams.filter(e => e.date === dateStr).forEach(e => entries.push({ srcType:'exam', id:e.id, title:e.name, category:'exam', time:e.time, endTime:'' }));
  if (src.homework) HEAD_DATA.homework.filter(h => h.dueDate === dateStr).forEach(h => entries.push({ srcType:'homework', id:h.id, title:`${t('Due')}: ${h.title}`, category:'deadline', time:'', endTime:'' }));
  if (src.orientation) HEAD_DATA.orientations.filter(o => o.date === dateStr).forEach(o => entries.push({ srcType:'orientation', id:o.id, title:o.title, category:'activity', time:o.time, endTime:'' }));
  return entries;
}
function hToggleCalendarSource(source) {
  hState.calendar.sources[source] = !hState.calendar.sources[source];
  const el = document.getElementById('h-calendar-content');
  if (el) el.innerHTML = hCalendarMonthView();
}
function hOpenCalendarEntry(srcType, id) {
  if (srcType === 'event') { hOpenEventDetail(id); return; }
  if (srcType === 'exam') { hState.exams.screen = 'detail'; hState.exams.examId = id; authrenGoTo('exams'); return; }
  if (srcType === 'homework') { hState.homework.screen = 'detail'; hState.homework.hwId = id; authrenGoTo('homework'); return; }
  if (srcType === 'orientation') { hState.orientation.screen = 'detail'; hState.orientation.orId = id; authrenGoTo('orientation'); return; }
}
function hCalendarView() {
  return `<div id="h-calendar-content">${hCalendarMonthView()}</div>`;
}
function hCalendarSourceFilters() {
  const src = hState.calendar.sources;
  const options = [['events','Events'],['exams','Exams'],['homework','Homework'],['orientation','Orientation']];
  return `<div class="gd-comm-filter-row" style="margin-bottom:12px">${options.map(([id,label]) => `<div class="gd-comm-filter-chip${src[id]?' active':''}" onclick="hToggleCalendarSource('${id}')">${t(label)}</div>`).join('')}</div>`;
}
function hCalendarMonthView() {
  const st = hState.calendar;
  return `<div class="card"><div class="card-header"><div class="card-title">${t('School Calendar')}</div><button class="st-btn sm" onclick="hOpenEventForm()">+ ${t('Create Event')}</button></div>
    <div class="card-body">
      ${hCalendarSourceFilters()}
      <div class="gd-cal-header">
        <button type="button" class="gd-cal-nav-btn" onclick="hCalNav(-1)" aria-label="${t('Previous month')}"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="15 18 9 12 15 6"/></svg></button>
        <div class="gd-cal-title">${t(GD_ATT_MONTH_NAMES[st.calMonth])} ${st.calYear}</div>
        <button type="button" class="gd-cal-nav-btn" onclick="hCalNav(1)" aria-label="${t('Next month')}"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="9 18 15 12 9 6"/></svg></button>
      </div>
      <div class="gd-cal-grid">
        ${GD_ATT_DOW_NAMES.map(d => `<div class="gd-cal-dow">${t(d)}</div>`).join('')}
        ${hCalCells()}
      </div>
      <div id="h-cal-detail" style="margin-top:14px">${st.selectedDate ? hCalDetail(st.selectedDate) : ''}</div>
    </div></div>`;
}
function hCalCells() {
  const st = hState.calendar;
  const firstDow = new Date(st.calYear, st.calMonth, 1).getDay();
  const daysInMonth = new Date(st.calYear, st.calMonth + 1, 0).getDate();
  let html = '';
  for (let i = 0; i < firstDow; i++) html += `<div class="gd-cal-day empty"></div>`;
  for (let d = 1; d <= daysInMonth; d++) {
    const dateStr = gdAttDateKey(st.calYear, st.calMonth, d);
    const entries = hAllCalendarEntriesForDate(dateStr);
    const isToday = dateStr === '2026-03-11';
    const isSelected = dateStr === st.selectedDate;
    const dots = entries.slice(0, 3).map(e => `<span class="gd-cal-dot ${e.category}"></span>`).join('');
    html += `<div class="gd-cal-day${isToday?' today':''}${isSelected?' selected':''}${entries.length?' has-events':''}" onclick="hCalSelectDay('${dateStr}')">
      <div class="gd-cal-day-num">${d}</div><div class="gd-cal-dots-row">${dots}</div>
    </div>`;
  }
  return html;
}
function hCalNav(delta) {
  const st = hState.calendar;
  st.calMonth += delta;
  if (st.calMonth < 0) { st.calMonth = 11; st.calYear--; }
  if (st.calMonth > 11) { st.calMonth = 0; st.calYear++; }
  st.selectedDate = null;
  const el = document.getElementById('h-calendar-content');
  if (el) el.innerHTML = hCalendarMonthView();
}
function hCalSelectDay(dateStr) {
  hState.calendar.selectedDate = dateStr;
  const grid = document.querySelector('#h-calendar-content .gd-cal-grid');
  if (grid) grid.innerHTML = `${GD_ATT_DOW_NAMES.map(d => `<div class="gd-cal-dow">${t(d)}</div>`).join('')}${hCalCells()}`;
  const detail = document.getElementById('h-cal-detail');
  if (detail) detail.innerHTML = hCalDetail(dateStr);
}
function hCalDetail(dateStr) {
  const entries = hAllCalendarEntriesForDate(dateStr);
  if (!entries.length) return `<div class="gd-empty-mini">${t('No events on this day.')}</div>`;
  return entries.map(e => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hOpenCalendarEntry('${e.srcType}','${e.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hOpenCalendarEntry('${e.srcType}','${e.id}')}">
    <span>${gdCommsEsc(e.title)}<div style="font-size:11px;color:var(--muted)">${e.time ? e.time + (e.endTime ? '–' + e.endTime : '') : t('All day')}</div></span>
    <span class="status-pill ${e.category==='holiday'?'resolved':e.category==='meeting'?'awaiting':e.category==='exam'?'overdue':e.category==='deadline'?'awaiting':'open'}">${t(e.category.charAt(0).toUpperCase()+e.category.slice(1))}</span>
  </div>`).join('');
}

/* ── Event Detail (with Edit/Delete) ── */
function hOpenEventDetail(eventId) {
  hState.calendar.screen = 'detail';
  hState.calendar.eventId = eventId;
  const el = document.getElementById('h-calendar-content');
  if (el) el.innerHTML = hEventDetailScreen(hGetEvent(eventId));
}
function hBackToCalendarMonth() {
  hState.calendar.screen = 'month';
  hState.calendar.eventId = null;
  const el = document.getElementById('h-calendar-content');
  if (el) el.innerHTML = hCalendarMonthView();
}
function hEventDetailScreen(event) {
  if (!event) return hCalendarMonthView();
  return `<div class="card"><div class="card-header">
    <div style="display:flex;align-items:center;gap:10px;min-width:0;flex:1"><button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="hBackToCalendarMonth()">${t('← Back')}</button><div class="card-title" style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${gdCommsEsc(event.title)}</div></div>
    <button type="button" class="st-btn ghost sm" onclick="hOpenEventForm('${event.id}')">${t('Edit')}</button>
  </div>
    <div class="card-body">
      <div class="info-row"><span>${t('Category')}</span><span class="status-pill ${event.category==='holiday'?'resolved':event.category==='meeting'?'awaiting':'open'}">${t(event.category.charAt(0).toUpperCase()+event.category.slice(1))}</span></div>
      <div class="info-row"><span>${t('Date')}</span><span>${event.date}</span></div>
      <div class="info-row"><span>${t('Time')}</span><span>${event.startTime ? event.startTime + (event.endTime ? '–' + event.endTime : '') : t('All day')}</span></div>
      <div class="info-row"><span>${t('Audience')}</span><span>${hAudienceLabelSimple(event.audience)}</span></div>
      ${event.description ? `<div style="margin-top:14px;padding-top:14px;border-top:0.5px solid var(--separator);font-size:13px;line-height:1.6;color:var(--muted2)">${gdCommsEsc(event.description)}</div>` : ''}
      <button class="st-btn ghost sm" style="margin-top:16px;color:var(--red)" onclick="hConfirmDeleteEvent('${event.id}')">${t('Delete Event')}</button>
    </div></div>`;
}
function hConfirmDeleteEvent(eventId) {
  const event = hGetEvent(eventId);
  if (!event) return;
  stOpenModal(`<h3 style="margin-bottom:10px">${t('Delete this event?')}</h3>
    <p style="font-size:13px;color:var(--muted);margin-bottom:18px">"${gdCommsEsc(event.title)}" ${t('will be permanently removed from the calendar. This cannot be undone.')}</p>
    <div style="display:flex;gap:10px">
      <button class="st-btn" style="background:var(--red)" onclick="hDeleteEvent('${eventId}');stCloseModal()">${t('Delete')}</button>
      <button class="st-btn ghost" onclick="stCloseModal()">${t('Cancel')}</button>
    </div>`);
}
function hDeleteEvent(eventId) {
  HEAD_DATA.events = HEAD_DATA.events.filter(e => e.id !== eventId);
  hBackToCalendarMonth();
  hShowToast(t('Event deleted.'));
}

/* ── Create / Edit Event form ── */
function hOpenEventForm(eventId) {
  if (eventId) {
    const event = hGetEvent(eventId);
    if (!event) return;
    hState.calendar.form = { mode:'edit', id:event.id, title:event.title, category:event.category, date:event.date, startTime:event.startTime, endTime:event.endTime, audience:event.audience, description:event.description || '' };
  } else {
    hState.calendar.form = { mode:'create', id:null, title:'', category:'event', date: hState.calendar.selectedDate || '2026-03-11', startTime:'', endTime:'', audience:'school', description:'' };
  }
  hState.calendar.screen = 'form';
  hState.calendar.error = '';
  const el = document.getElementById('h-calendar-content');
  if (el) el.innerHTML = hEventFormScreen();
}
function hCancelEventForm() {
  const wasEdit = hState.calendar.form && hState.calendar.form.mode === 'edit';
  const editedId = hState.calendar.form ? hState.calendar.form.id : null;
  hState.calendar.form = null;
  hState.calendar.error = '';
  const el = document.getElementById('h-calendar-content');
  if (wasEdit) { hState.calendar.screen = 'detail'; hState.calendar.eventId = editedId; if (el) el.innerHTML = hEventDetailScreen(hGetEvent(editedId)); }
  else { hState.calendar.screen = 'month'; if (el) el.innerHTML = hCalendarMonthView(); }
}
function hEventFormScreen() {
  const f = hState.calendar.form;
  const err = hState.calendar.error;
  const audiences = [['school','Entire School'],['teachers','Teachers'],['guardians','Guardians'],['students','Students']];
  return `<div class="card"><div class="card-header"><div class="card-title">${f.mode==='edit'?t('Edit Event'):t('Create Event')}</div></div>
    <div class="card-body">
      <div class="st-field"><label>${t('Event Title')}</label><input id="h-ev-title" value="${gdCommsEsc(f.title)}"></div>
      <div class="st-field"><label>${t('Category')}</label><select id="h-ev-category">
        ${H_EVENT_CATEGORIES.map(cat => `<option value="${cat}" ${cat===f.category?'selected':''}>${t(cat.charAt(0).toUpperCase()+cat.slice(1))}</option>`).join('')}
      </select></div>
      <div class="st-field"><label>${t('Date')}</label><input id="h-ev-date" type="date" value="${f.date}"></div>
      <div style="display:flex;gap:10px">
        <div class="st-field" style="flex:1"><label>${t('Start Time')} (${t('optional')})</label><input id="h-ev-start" type="time" value="${f.startTime}"></div>
        <div class="st-field" style="flex:1"><label>${t('End Time')} (${t('optional')})</label><input id="h-ev-end" type="time" value="${f.endTime}"></div>
      </div>
      <div class="st-field"><label>${t('Audience')}</label><select id="h-ev-audience">
        ${audiences.map(([id,label]) => `<option value="${id}" ${id===f.audience?'selected':''}>${t(label)}</option>`).join('')}
      </select></div>
      <div class="st-field"><label>${t('Description')}</label><textarea id="h-ev-description" rows="3">${gdCommsEsc(f.description)}</textarea></div>
      <div style="display:flex;gap:10px">
        <button class="st-btn" onclick="hSaveEvent()">${f.mode==='edit'?t('Save Changes'):t('Create Event')}</button>
        <button class="st-btn ghost" onclick="hCancelEventForm()">${t('Cancel')}</button>
      </div>
      ${err ? `<div class="st-inline-msg err show" style="margin-top:12px">${err}</div>` : ''}
    </div></div>`;
}
function hSaveEvent() {
  const f = hState.calendar.form;
  const title = (document.getElementById('h-ev-title').value || '').trim();
  const category = document.getElementById('h-ev-category').value;
  const date = document.getElementById('h-ev-date').value;
  const startTime = document.getElementById('h-ev-start').value;
  const endTime = document.getElementById('h-ev-end').value;
  const audience = document.getElementById('h-ev-audience').value;
  const description = (document.getElementById('h-ev-description').value || '').trim();
  Object.assign(f, { title, category, date, startTime, endTime, audience, description });

  let err = '';
  if (!title) err = t('Event title is required.');
  else if (!date) err = t('Select a date.');
  else if (startTime && endTime && endTime <= startTime) err = t('End time must be after start time.');

  hState.calendar.error = err;
  const el = document.getElementById('h-calendar-content');
  if (err) { if (el) el.innerHTML = hEventFormScreen(); return; }

  if (f.mode === 'edit') {
    const event = hGetEvent(f.id);
    Object.assign(event, { title, category, date, startTime, endTime, audience, description });
    hState.calendar.screen = 'detail';
    hState.calendar.eventId = event.id;
    if (el) el.innerHTML = hEventDetailScreen(event);
    hShowToast(t('Event updated successfully.'));
  } else {
    const newEvent = { id:'hev' + Date.now(), title, category, date, startTime, endTime, audience, description };
    HEAD_DATA.events.push(newEvent);
    hState.calendar.screen = 'detail';
    hState.calendar.eventId = newEvent.id;
    hState.calendar.selectedDate = date;
    if (el) el.innerHTML = hEventDetailScreen(newEvent);
    hShowToast(t('Event created successfully.'));
  }
  hState.calendar.form = null;
}

/* ══════════════════════════════════════════════════════
   BASIC REPORTS
   Report types are limited to what real, existing data can genuinely
   populate (Student, Attendance, Academic, Homework). Behavior/Payment/
   Admissions report types will be added once those modules exist,
   rather than shown as empty or fabricated now.
══════════════════════════════════════════════════════ */
const H_REPORT_TYPES = [
  { id:'student', label:'Student Report', scope:'student' },
  { id:'attendance', label:'Attendance Report', scope:'class' },
  { id:'academic', label:'Academic Report', scope:'class' },
  { id:'homework', label:'Homework Report', scope:'class' },
  { id:'institution', label:'Institution Overview Report', scope:'none' },
];
function hReportTypeMeta(id) { return H_REPORT_TYPES.find(x => x.id === id) || H_REPORT_TYPES[0]; }
function hReportsView() {
  const tabs = [ { id:'basic', label:'Basic Reports' }, { id:'advanced', label:'Advanced Report Builder' } ];
  return `<div class="st-tabs">${tabs.map(tb => `<div class="st-tab gd-tab-hrep${tb.id===hState.reports.tab?' active':''}" data-tab="${tb.id}" onclick="hSetReportsTab('${tb.id}')">${t(tb.label)}</div>`).join('')}</div>
    <div id="h-reports-content">${hReportsTabBody()}</div>`;
}
function hSetReportsTab(tabId) {
  hState.reports.tab = tabId;
  document.querySelectorAll('.gd-tab-hrep').forEach(el => el.classList.toggle('active', el.dataset.tab === tabId));
  const el = document.getElementById('h-reports-content');
  if (el) el.innerHTML = hReportsTabBody();
}
function hReportsTabBody() {
  return hState.reports.tab === 'advanced' ? hAdvReportsBody() : hReportsBody();
}
function hReportsBody() {
  const r = hState.reports;
  return r.screen === 'preview' ? hReportPreviewScreen() : hReportFormScreen();
}
function hRefreshReports() { const el = document.getElementById('h-reports-content'); if (el) el.innerHTML = hReportsBody(); }

function hReportFormScreen() {
  const r = hState.reports;
  const meta = hReportTypeMeta(r.type);
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Generate a Report')}</div></div>
    <div class="card-body">
      <div class="st-field"><label>${t('Report Type')}</label><select id="h-rep-type" onchange="hSetReportType(this.value)">
        ${H_REPORT_TYPES.map(rt => `<option value="${rt.id}" ${rt.id===r.type?'selected':''}>${t(rt.label)}</option>`).join('')}
      </select></div>
      ${meta.scope === 'class' ? `
        <div class="st-field"><label>${t('Class')}</label><select id="h-rep-class">
          <option value="all" ${r.classId==='all'||!r.classId?'selected':''}>${t('All Classes')}</option>
          ${HEAD_DATA.classes.map(c => `<option value="${c.id}" ${c.id===r.classId?'selected':''}>${gdCommsEsc(c.name)}</option>`).join('')}
        </select></div>
        ${r.type === 'attendance' ? `<div class="st-field"><label>${t('Period')}</label><select id="h-rep-period">
          <option value="week" ${r.period==='week'?'selected':''}>${t('This Week')}</option>
          <option value="month" ${r.period==='month'?'selected':''}>${t('This Month')}</option>
        </select></div>` : ''}
      ` : meta.scope === 'student' ? `
        <div class="st-field"><label>${t('Student')}</label>
          ${r.studentId ? (() => { const st = hGetStudent(r.studentId); return `<div class="info-row"><span>${st ? gdCommsEsc(hStudentFullName(st)) : t('Unknown student')}</span><span class="card-action" onclick="hSetReportStudent(null)">${t('Change')}</span></div>`; })()
            : `<input class="gd-comm-search-input" type="text" placeholder="${t('Search by name or student ID...')}" value="${gdCommsEsc(r.studentSearch)}" oninput="hSetReportStudentSearch(this.value)"><div id="h-rep-student-results">${hReportStudentResultsBlock()}</div>`}
        </div>` : `<div style="font-size:11.5px;color:var(--muted);margin-bottom:12px">${t('This report combines every tracked domain — no additional scope needed.')}</div>`}
      <button class="st-btn" onclick="hGenerateReport()">${t('Generate Report')}</button>
      ${r.error ? `<div class="st-inline-msg err show" style="margin-top:12px">${r.error}</div>` : ''}
    </div></div>`;
}
function hSetReportType(v) { hState.reports.type = v; hState.reports.error = ''; hRefreshReports(); }
function hSetReportStudentSearch(v) {
  hState.reports.studentSearch = v;
  const el = document.getElementById('h-rep-student-results');
  if (el) el.innerHTML = hReportStudentResultsBlock();
}
function hReportStudentResultsBlock() {
  const q = hState.reports.studentSearch.trim().toLowerCase();
  if (!q) return '';
  const results = HEAD_DATA.students.filter(s => hStudentFullName(s).toLowerCase().includes(q) || s.studentId.toLowerCase().includes(q));
  if (!results.length) return `<div class="gd-empty-mini" style="text-align:left;padding:8px 0 0">${t('No students match your search.')}</div>`;
  return `<div style="margin-top:8px">${results.map(s => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hSetReportStudent('${s.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hSetReportStudent('${s.id}')}">
    <span>${gdCommsEsc(hStudentFullName(s))}</span><span style="color:var(--muted);font-size:12px">${gdCommsEsc(s.studentId)}</span>
  </div>`).join('')}</div>`;
}
function hSetReportStudent(id) { hState.reports.studentId = id; hState.reports.studentSearch = ''; hRefreshReports(); }

/* ── Generation + Preview (real content, reusing existing computed helpers) ── */
function hGenerateReport() {
  const r = hState.reports;
  const meta = hReportTypeMeta(r.type);
  if (meta.scope === 'class') {
    const classEl = document.getElementById('h-rep-class');
    r.classId = classEl ? classEl.value : 'all';
    if (r.type === 'attendance') { const periodEl = document.getElementById('h-rep-period'); if (periodEl) r.period = periodEl.value; }
  } else if (meta.scope === 'student' && !r.studentId) {
    r.error = t('Select a student first.');
    hRefreshReports();
    return;
  }
  r.error = '';
  r.screen = 'preview';
  r.generatedAt = tISODate(new Date(2026, 2, 11));
  hRefreshReports();
}
function hBackToReportForm() {
  hState.reports.screen = 'form';
  hRefreshReports();
}
function hReportPreviewScreen() {
  const r = hState.reports;
  const meta = hReportTypeMeta(r.type);
  const body = r.type === 'student' ? hReportStudentBody(r)
    : r.type === 'attendance' ? hReportAttendanceBody(r)
    : r.type === 'academic' ? hReportAcademicBody(r)
    : r.type === 'institution' ? hReportInstitutionBody(r)
    : hReportHomeworkBody(r);
  return `<div class="card">
    <div class="card-header">
      <div style="display:flex;align-items:center;gap:10px"><button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="hBackToReportForm()">${t('← Back')}</button><div class="card-title">${t(meta.label)}</div></div>
      <button type="button" class="st-btn ghost sm" onclick="window.print()">${aIcon('printer')} ${t('Print / Download')}</button>
    </div>
    <div class="card-body">
      <div style="font-size:11.5px;color:var(--muted);margin-bottom:14px">${t('Generated')} ${r.generatedAt} · ${HEAD_DATA.institution.name}</div>
      ${body}
    </div></div>`;
}
function hReportStudentBody(r) {
  const student = hGetStudent(r.studentId);
  if (!student) return `<div class="gd-empty-mini">${t('Student not found.')}</div>`;
  const cls = hGetClass(student.classId);
  const guardian = hGetGuardian(student.guardianId);
  const history = hStudentHistory(student);
  return `
    <div style="font-size:14px;font-weight:700;margin-bottom:10px">${gdCommsEsc(hStudentFullName(student))} — ${gdCommsEsc(student.studentId)}</div>
    <div class="info-row"><span>${t('Class')}</span><span>${cls ? gdCommsEsc(cls.name) : '—'}</span></div>
    <div class="info-row"><span>${t('Average Grade')}</span><span>${student.avgGrade}/20</span></div>
    <div class="info-row"><span>${t('Attendance Rate')}</span><span>${student.attendanceRate}%</span></div>
    <div class="info-row"><span>${t('Payment Status')}</span><span>${t(student.paymentStatus.charAt(0).toUpperCase()+student.paymentStatus.slice(1))}</span></div>
    <div class="info-row"><span>${t('Guardian')}</span><span>${guardian ? gdCommsEsc(guardian.name) : '—'}</span></div>
    <div style="margin-top:14px;font-size:12.5px;font-weight:600;margin-bottom:8px">${t('History')}</div>
    ${history.length ? history.map(ev => `<div class="info-row"><span>${gdCommsEsc(ev.label)}</span><span style="color:var(--muted);font-size:11.5px">${ev.date}</span></div>`).join('') : `<div class="gd-empty-mini">${t('No history recorded yet.')}</div>`}`;
}
function hReportAttendanceBody(r) {
  const days = r.period === 'month' ? H_ATTENDANCE_DAYS.slice() : H_ATTENDANCE_DAYS.slice(-5);
  const classes = r.classId === 'all' ? HEAD_DATA.classes : [hGetClass(r.classId)].filter(Boolean);
  return `<div style="font-size:12.5px;color:var(--muted);margin-bottom:12px">${t('Period')}: ${r.period === 'month' ? t('This Month') : t('This Week')} (${days.length} ${t('school days')})</div>
    ${classes.map(c => {
      const roster = hClassStudents(c.id).map(s => s.id);
      const agg = hAggregateAttendance(roster, days);
      return `<div class="info-row"><span>${gdCommsEsc(c.name)}</span><span>${agg.rate !== null ? agg.rate + '%' : '—'} (${agg.present} ${t('present')}, ${agg.absent} ${t('absent')}, ${agg.late} ${t('late')})</span></div>`;
    }).join('')}`;
}
function hReportAcademicBody(r) {
  const classes = r.classId === 'all' ? HEAD_DATA.classes : [hGetClass(r.classId)].filter(Boolean);
  const overallAvg = r.classId === 'all' ? hAvg(HEAD_DATA.students.map(s => s.avgGrade)) : hClassAvgGrade(r.classId);
  return `<div class="info-row"><span>${t('Overall Average')}</span><span>${overallAvg}/20</span></div>
    <div style="margin-top:14px;font-size:12.5px;font-weight:600;margin-bottom:8px">${t('By Class')}</div>
    ${classes.map(c => `<div class="info-row"><span>${gdCommsEsc(c.name)}</span><span>${hClassAvgGrade(c.id) !== null ? hClassAvgGrade(c.id) + '/20' : '—'}</span></div>`).join('')}`;
}
function hReportHomeworkBody(r) {
  const list = r.classId === 'all' ? HEAD_DATA.homework : HEAD_DATA.homework.filter(h => h.classId === r.classId);
  if (!list.length) return `<div class="gd-empty-mini">${t('No homework matches this selection.')}</div>`;
  return list.map(hw => {
    const cls = hGetClass(hw.classId);
    const counts = hHomeworkCounts(hw);
    return `<div class="info-row"><span>${gdCommsEsc(hw.title)}<div style="font-size:11px;color:var(--muted)">${cls ? gdCommsEsc(cls.name) : ''} · ${t('Due')} ${hw.dueDate}</div></span><span>${counts.submitted}/${counts.total} ${t('submitted')}</span></div>`;
  }).join('');
}
function hReportInstitutionBody() {
  const academicAvg = hAvg(HEAD_DATA.students.map(s => s.avgGrade));
  const attendanceAvg = hAvg(HEAD_DATA.students.map(s => s.attendanceRate));
  const hwCounts = HEAD_DATA.homework.reduce((acc, h) => { const c = hHomeworkCounts(h); acc.sub += c.submitted + c.late; acc.total += c.total; return acc; }, { sub:0, total:0 });
  const homeworkRate = hwCounts.total ? Math.round((hwCounts.sub / hwCounts.total) * 100) : null;
  const negativeIncidents = HEAD_DATA.behaviorRecords.filter(r => !hIsPositiveBehavior(r.category)).length;
  const totalCollected = HEAD_DATA.payments.filter(p => p.status === 'paid').reduce((s, p) => s + p.amount, 0);
  const totalOutstanding = HEAD_DATA.payments.filter(p => p.status !== 'paid').reduce((s, p) => s + p.amount, 0);
  const admissionsByStatus = {};
  HEAD_DATA.admissions.forEach(a => { admissionsByStatus[a.status] = (admissionsByStatus[a.status] || 0) + 1; });
  const sentAnnouncements = HEAD_DATA.announcements.filter(a => a.status === 'sent').length;

  return `
    <div style="font-size:13px;font-weight:700;margin-bottom:10px">${t('Institution-Wide Overview')}</div>
    <div class="info-row"><span>${t('Total Students')}</span><span>${HEAD_DATA.students.length}</span></div>
    <div class="info-row"><span>${t('Total Teachers')}</span><span>${HEAD_DATA.teachers.length}</span></div>
    <div class="info-row"><span>${t('Total Classes')}</span><span>${HEAD_DATA.classes.length}</span></div>
    <div style="margin-top:14px;font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Attendance')}</div>
    <div class="info-row"><span>${t('Overall Rate')}</span><span>${attendanceAvg}%</span></div>
    <div style="margin-top:14px;font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Academics')}</div>
    <div class="info-row"><span>${t('Overall Average')}</span><span>${academicAvg}/20</span></div>
    <div style="margin-top:14px;font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Homework')}</div>
    <div class="info-row"><span>${t('Completion Rate')}</span><span>${homeworkRate !== null ? homeworkRate + '%' : '—'}</span></div>
    <div style="margin-top:14px;font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Behavior')}</div>
    <div class="info-row"><span>${t('Negative Incidents')}</span><span>${negativeIncidents}</span></div>
    <div style="margin-top:14px;font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Payments')}</div>
    <div class="info-row"><span>${t('Collected')}</span><span>${hCurrency(totalCollected)}</span></div>
    <div class="info-row"><span>${t('Outstanding')}</span><span>${hCurrency(totalOutstanding)}</span></div>
    <div style="margin-top:14px;font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Admissions')}</div>
    ${Object.keys(admissionsByStatus).map(st => `<div class="info-row"><span>${t(H_ADMISSION_STATUS_META[st].label)}</span><span>${admissionsByStatus[st]}</span></div>`).join('')}
    <div style="margin-top:14px;font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Communication')}</div>
    <div class="info-row"><span>${t('Announcements Sent')}</span><span>${sentAnnouncements}</span></div>`;
}

/* ══════════════════════════════════════════════════════
   BULK STUDENT IMPORT (6-step wizard: Upload -> Mapping -> Validation ->
   Duplicate Detection -> Preview -> Import)
══════════════════════════════════════════════════════ */
const H_IMPORT_FIELDS = [
  { id:'firstName', label:'First Name', required:true },
  { id:'lastName', label:'Last Name', required:true },
  { id:'studentId', label:'Student ID', required:true },
  { id:'dob', label:'Date of Birth (YYYY-MM-DD)', required:true },
  { id:'gender', label:'Gender (M/F)', required:true },
  { id:'className', label:'Class Name', required:true },
  { id:'guardianName', label:'Guardian Name', required:true },
  { id:'guardianEmail', label:'Guardian Email', required:true },
  { id:'guardianPhone', label:'Guardian Phone', required:true },
  { id:'address', label:'Address', required:false },
];
function hParseCSV(text) {
  const lines = text.split(/\r\n|\n/).filter(l => l.trim() !== '');
  const parseLine = (line) => {
    const result = [];
    let cur = '', inQuotes = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (inQuotes) {
        if (ch === '"') { if (line[i + 1] === '"') { cur += '"'; i++; } else inQuotes = false; }
        else cur += ch;
      } else {
        if (ch === '"') inQuotes = true;
        else if (ch === ',') { result.push(cur); cur = ''; }
        else cur += ch;
      }
    }
    result.push(cur);
    return result.map(x => x.trim());
  };
  if (!lines.length) return { headers: [], rows: [] };
  const headers = parseLine(lines[0]);
  const rows = lines.slice(1).map(parseLine);
  return { headers, rows };
}
function hGuessMapping(headers) {
  const mapping = {};
  const normalize = s => s.toLowerCase().replace(/[^a-z]/g, '');
  H_IMPORT_FIELDS.forEach(f => {
    const target = normalize(f.id);
    const idx = headers.findIndex(h => normalize(h) === target || normalize(h).includes(target));
    if (idx !== -1) mapping[f.id] = idx;
  });
  return mapping;
}
function hImportView() {
  const tabs = [ { id:'student', label:'Student Import' }, { id:'historical', label:'Historical Data Import' } ];
  return `<div class="st-tabs">${tabs.map(tb => `<div class="st-tab gd-tab-himp${tb.id===hState.import.tab?' active':''}" data-tab="${tb.id}" onclick="hSetImportTab('${tb.id}')">${t(tb.label)}</div>`).join('')}</div>
    <div id="h-import-content">${hImportTabBody()}</div>`;
}
function hSetImportTab(tabId) {
  hState.import.tab = tabId;
  document.querySelectorAll('.gd-tab-himp').forEach(el => el.classList.toggle('active', el.dataset.tab === tabId));
  const el = document.getElementById('h-import-content');
  if (el) el.innerHTML = hImportTabBody();
}
function hImportTabBody() {
  return hState.import.tab === 'historical' ? hHistImportBody() : hImportBody();
}
function hImportBody() {
  const step = hState.import.step;
  if (step === 1) return hImportStep1();
  if (step === 2) return hImportStep2();
  if (step === 3) return hImportStep3();
  if (step === 4) return hImportStep4();
  if (step === 5) return hImportStep5();
  return hImportStep6();
}
function hRefreshImport() { const el = document.getElementById('h-import-content'); if (el) el.innerHTML = hImportBody(); }
function hImportStepper() {
  const step = hState.import.step;
  const labels = ['Upload', 'Mapping', 'Validation', 'Duplicates', 'Preview', 'Import'];
  return `<div style="display:flex;gap:4px;flex-wrap:wrap;margin-bottom:16px">
    ${labels.map((l, i) => `<div class="status-pill ${i+1===step?'due':i+1<step?'paid':'resolved'}" style="font-size:10.5px">${i+1}. ${t(l)}</div>`).join('')}
  </div>`;
}

/* ── Step 1: Upload ── */
function hImportStep1() {
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Bulk Student Import')}</div></div>
    <div class="card-body">
      ${hImportStepper()}
      <div style="font-size:12.5px;color:var(--muted);margin-bottom:14px">${t('Upload a CSV file with one row per student. The first row must contain column headers.')}</div>
      <input type="file" id="h-import-file" accept=".csv" onchange="hHandleImportFile(this)" style="margin-bottom:10px">
      ${hState.import.error ? `<div class="st-inline-msg err show">${hState.import.error}</div>` : ''}
    </div></div>`;
}
function hHandleImportFile(input) {
  const file = input.files && input.files[0];
  if (!file) return;
  if (!file.name.toLowerCase().endsWith('.csv')) {
    hState.import.error = t('Please upload a .csv file.');
    hRefreshImport();
    return;
  }
  const reader = new FileReader();
  reader.onload = function(e) {
    hProcessImportFileText(e.target.result, file.name);
  };
  reader.onerror = function() {
    hState.import.error = t('Could not read this file. Please try again.');
    hRefreshImport();
  };
  reader.readAsText(file);
}
function hProcessImportFileText(text, fileName) {
  const parsed = hParseCSV(text);
  if (!parsed.headers.length || !parsed.rows.length) {
    hState.import.error = t('This file appears to be empty or invalid.');
    hRefreshImport();
    return;
  }
  hState.import.fileName = fileName;
  hState.import.rawHeaders = parsed.headers;
  hState.import.rawRows = parsed.rows;
  hState.import.mapping = hGuessMapping(parsed.headers);
  hState.import.error = '';
  hState.import.step = 2;
  hRefreshImport();
}

/* ── Step 2: Data Mapping ── */
function hImportStep2() {
  const im = hState.import;
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Bulk Student Import')}</div></div>
    <div class="card-body">
      ${hImportStepper()}
      <div style="font-size:12.5px;color:var(--muted);margin-bottom:14px">${t('Map each Authren field to a column from your file')} (${gdCommsEsc(im.fileName)}, ${im.rawRows.length} ${t('rows')}).</div>
      ${H_IMPORT_FIELDS.map(f => `<div class="st-field"><label>${t(f.label)}${f.required?' *':''}</label><select id="h-imp-map-${f.id}" onchange="hSetImportMapping('${f.id}', this.value)">
        <option value="">${t('-- Not Mapped --')}</option>
        ${im.rawHeaders.map((h, i) => `<option value="${i}" ${im.mapping[f.id]===i?'selected':''}>${gdCommsEsc(h)}</option>`).join('')}
      </select></div>`).join('')}
      <div style="display:flex;gap:10px">
        <button class="st-btn" onclick="hProceedToValidation()">${t('Next: Validate')}</button>
        <button class="st-btn ghost" onclick="hRestartImport()">${t('Start Over')}</button>
      </div>
      ${im.error ? `<div class="st-inline-msg err show" style="margin-top:12px">${im.error}</div>` : ''}
    </div></div>`;
}
function hSetImportMapping(fieldId, value) {
  if (value === '') delete hState.import.mapping[fieldId];
  else hState.import.mapping[fieldId] = Number(value);
}
function hProceedToValidation() {
  const im = hState.import;
  const missing = H_IMPORT_FIELDS.filter(f => f.required && im.mapping[f.id] === undefined);
  if (missing.length) {
    im.error = `${t('Please map all required fields')}: ${missing.map(f => t(f.label)).join(', ')}.`;
    hRefreshImport();
    return;
  }
  im.error = '';
  hRunImportValidation();
  im.step = 3;
  hRefreshImport();
}
function hRestartImport() {
  hState.import = { step:1, fileName:'', rawHeaders:[], rawRows:[], mapping:{}, validationRows:[], duplicateActions:{}, result:null, error:'' };
  hRefreshImport();
}

/* ── Step 3: Validation ── */
function hExtractImportRowData(row) {
  const im = hState.import;
  const data = {};
  H_IMPORT_FIELDS.forEach(f => {
    const idx = im.mapping[f.id];
    data[f.id] = idx !== undefined ? (row[idx] || '').trim() : '';
  });
  return data;
}
function hValidateImportRowData(data) {
  const errors = [];
  if (!data.firstName) errors.push(t('Missing first name'));
  if (!data.lastName) errors.push(t('Missing last name'));
  if (!data.studentId) errors.push(t('Missing student ID'));
  if (!data.dob) errors.push(t('Missing date of birth'));
  else if (!/^\d{4}-\d{2}-\d{2}$/.test(data.dob)) errors.push(t('Invalid date of birth format (expected YYYY-MM-DD)'));
  if (!data.gender) errors.push(t('Missing gender'));
  else if (!['M', 'F'].includes(data.gender.toUpperCase())) errors.push(t('Invalid gender (expected M or F)'));
  if (!data.className) errors.push(t('Missing class'));
  else if (!HEAD_DATA.classes.some(c => c.name.toLowerCase() === data.className.toLowerCase())) errors.push(`${t('Class not found')}: "${data.className}"`);
  if (!data.guardianName) errors.push(t('Missing guardian name'));
  if (!data.guardianEmail) errors.push(t('Missing guardian email'));
  else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.guardianEmail)) errors.push(t('Invalid guardian email format'));
  if (!data.guardianPhone) errors.push(t('Missing guardian phone'));
  return errors;
}
function hRunImportValidation() {
  const im = hState.import;
  const seenInFile = {};
  im.validationRows = im.rawRows.map((row, i) => {
    const data = hExtractImportRowData(row);
    const errors = hValidateImportRowData(data);
    const existsAlready = data.studentId && HEAD_DATA.students.some(s => s.studentId.toUpperCase() === data.studentId.toUpperCase());
    const dupInFile = data.studentId && seenInFile[data.studentId.toUpperCase()] !== undefined;
    if (data.studentId) { if (seenInFile[data.studentId.toUpperCase()] === undefined) seenInFile[data.studentId.toUpperCase()] = i; }
    return { rowIndex:i, data, errors, isDuplicateExisting: !!existsAlready, isDuplicateInFile: !!dupInFile, firstOccurrenceIndex: dupInFile ? seenInFile[data.studentId.toUpperCase()] : null };
  });
  im.duplicateActions = {};
  im.validationRows.filter(r => r.isDuplicateExisting || r.isDuplicateInFile).forEach(r => { im.duplicateActions[r.rowIndex] = 'skip'; });
}
function hImportStep3() {
  const im = hState.import;
  const validRows = im.validationRows.filter(r => !r.errors.length);
  const errorRows = im.validationRows.filter(r => r.errors.length);
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Bulk Student Import')}</div></div>
    <div class="card-body">
      ${hImportStepper()}
      <div class="gd-pay-stat-row" style="margin-bottom:14px">
        <div class="stat-card"><div class="stat-label">${t('Total Rows')}</div><div class="stat-val">${im.validationRows.length}</div><div class="stat-icon blue">${aIcon('file-text')}</div></div>
        <div class="stat-card"><div class="stat-label">${t('Valid')}</div><div class="stat-val">${validRows.length}</div><div class="stat-icon green">${aIcon('check-circle')}</div></div>
        <div class="stat-card"><div class="stat-label">${t('Errors')}</div><div class="stat-val">${errorRows.length}</div><div class="stat-icon red">${aIcon('x-circle')}</div></div>
      </div>
      ${errorRows.length ? `<div style="font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Rows with Errors')}</div>
        ${errorRows.map(r => `<div class="info-row" style="align-items:flex-start"><span>${t('Row')} ${r.rowIndex + 2}: ${gdCommsEsc(r.data.firstName)} ${gdCommsEsc(r.data.lastName)}<div style="font-size:11px;color:var(--red);margin-top:2px">${r.errors.map(e => gdCommsEsc(e)).join('; ')}</div></span></div>`).join('')}` : `<div class="gd-empty-mini">${t('No validation errors found.')}</div>`}
      <div style="display:flex;gap:10px;margin-top:14px">
        <button class="st-btn" onclick="hProceedToDuplicates()" ${!validRows.length?'disabled':''}>${t('Next: Duplicate Detection')}</button>
        <button class="st-btn ghost" onclick="hState.import.step=2;hRefreshImport()">${t('← Back')}</button>
        <button class="st-btn ghost" onclick="hRestartImport()">${t('Start Over')}</button>
      </div>
      ${!validRows.length ? `<div class="st-inline-msg err show" style="margin-top:12px">${t('No valid rows to import. Please fix your file and re-upload.')}</div>` : ''}
    </div></div>`;
}
function hProceedToDuplicates() {
  hState.import.step = 4;
  hRefreshImport();
}

/* ── Step 4: Duplicate Detection ── */
function hImportDuplicateRows() {
  return hState.import.validationRows.filter(r => !r.errors.length && (r.isDuplicateExisting || r.isDuplicateInFile));
}
function hImportStep4() {
  const im = hState.import;
  const dupes = hImportDuplicateRows();
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Bulk Student Import')}</div></div>
    <div class="card-body">
      ${hImportStepper()}
      ${dupes.length ? `
        <div style="font-size:12.5px;color:var(--muted);margin-bottom:14px">${t('These rows match an existing student ID. Choose how to handle each one.')}</div>
        ${dupes.map(r => {
          const action = im.duplicateActions[r.rowIndex] || 'skip';
          const options = r.isDuplicateExisting ? [['skip','Skip'],['replace','Replace Existing'],['keep','Keep Both']] : [['skip','Skip'],['keep','Keep Both']];
          return `<div class="card" style="margin-bottom:10px;background:var(--surface2)"><div class="card-body">
            <div style="font-weight:600;font-size:13px">${gdCommsEsc(r.data.firstName)} ${gdCommsEsc(r.data.lastName)} — ${gdCommsEsc(r.data.studentId)}</div>
            <div style="font-size:11px;color:var(--muted);margin-bottom:8px">${r.isDuplicateExisting ? t('Matches an existing student in the system') : t('Duplicate Student ID within this file')}</div>
            <select onchange="hSetDuplicateAction(${r.rowIndex}, this.value)" style="background:var(--surface3);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:6px 10px;font-size:12.5px">
              ${options.map(([id,label]) => `<option value="${id}" ${action===id?'selected':''}>${t(label)}</option>`).join('')}
            </select>
          </div></div>`;
        }).join('')}
      ` : `<div class="gd-empty-mini">${t('No duplicate Student IDs detected.')}</div>`}
      <div style="display:flex;gap:10px;margin-top:14px">
        <button class="st-btn" onclick="hProceedToPreview()">${t('Next: Preview')}</button>
        <button class="st-btn ghost" onclick="hState.import.step=3;hRefreshImport()">${t('← Back')}</button>
        <button class="st-btn ghost" onclick="hRestartImport()">${t('Start Over')}</button>
      </div>
    </div></div>`;
}
function hSetDuplicateAction(rowIndex, action) {
  hState.import.duplicateActions[rowIndex] = action;
}
function hProceedToPreview() {
  hState.import.step = 5;
  hRefreshImport();
}

/* ── Shared row-resolution logic (used identically by Preview and Import,
     so the preview is always an exact, accurate representation) ── */
function hImportRowsToProcess() {
  const im = hState.import;
  const result = [];
  const usedIds = new Set(HEAD_DATA.students.map(s => s.studentId.toUpperCase()));
  im.validationRows.filter(r => !r.errors.length).forEach(r => {
    let effectiveId = r.data.studentId;
    let action = 'create';
    if (r.isDuplicateExisting || r.isDuplicateInFile) {
      action = im.duplicateActions[r.rowIndex] || 'skip';
      if (action === 'skip') return;
      if (action === 'keep') {
        let suffix = 2;
        let candidate = `${r.data.studentId}-${suffix}`;
        while (usedIds.has(candidate.toUpperCase())) { suffix++; candidate = `${r.data.studentId}-${suffix}`; }
        effectiveId = candidate;
      }
    }
    usedIds.add(effectiveId.toUpperCase());
    result.push({ rowIndex: r.rowIndex, data: r.data, action, effectiveId });
  });
  return result;
}
function hResolveClassByName(name) {
  return HEAD_DATA.classes.find(c => c.name.toLowerCase() === name.toLowerCase()) || null;
}
function hResolveOrCreateGuardian(data) {
  const existing = HEAD_DATA.guardians.find(g => g.email.toLowerCase() === data.guardianEmail.toLowerCase());
  if (existing) return existing;
  const newGuardian = { id:'hg' + Date.now() + Math.random().toString(36).slice(2, 5), name: data.guardianName, email: data.guardianEmail, phone: data.guardianPhone, studentIds:[] };
  HEAD_DATA.guardians.push(newGuardian);
  return newGuardian;
}

/* ── Step 5: Preview ── */
function hImportStep5() {
  const rows = hImportRowsToProcess();
  const skippedCount = hImportDuplicateRows().filter(r => (hState.import.duplicateActions[r.rowIndex] || 'skip') === 'skip').length;
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Bulk Student Import')}</div></div>
    <div class="card-body">
      ${hImportStepper()}
      <div style="font-size:12.5px;color:var(--muted);margin-bottom:14px">${t('This is exactly what will be imported')}: ${rows.length} ${t('students')}${skippedCount ? `, ${skippedCount} ${t('skipped')}` : ''}.</div>
      ${rows.length ? rows.map(r => {
        const cls = hResolveClassByName(r.data.className);
        return `<div class="info-row"><span>${gdCommsEsc(r.data.firstName)} ${gdCommsEsc(r.data.lastName)} — ${gdCommsEsc(r.effectiveId)}<div style="font-size:11px;color:var(--muted)">${cls ? gdCommsEsc(cls.name) : '—'} · ${gdCommsEsc(r.data.guardianName)}</div></span><span class="status-pill ${r.action==='replace'?'awaiting':'open'}">${t(r.action==='replace'?'Replace':r.action==='keep'?'New Record':'Create')}</span></div>`;
      }).join('') : `<div class="gd-empty-mini">${t('Nothing to import.')}</div>`}
      <div style="display:flex;gap:10px;margin-top:14px">
        <button class="st-btn" onclick="hRunImport()" ${!rows.length?'disabled':''}>${t('Import Students')}</button>
        <button class="st-btn ghost" onclick="hState.import.step=4;hRefreshImport()">${t('← Back')}</button>
        <button class="st-btn ghost" onclick="hRestartImport()">${t('Start Over')}</button>
      </div>
    </div></div>`;
}

/* ── Step 6: Import (actually creates the data) + Result ── */
function hRunImport() {
  const rows = hImportRowsToProcess();
  let created = 0, replaced = 0;
  rows.forEach(r => {
    const cls = hResolveClassByName(r.data.className);
    const guardian = hResolveOrCreateGuardian(r.data);
    if (r.action === 'replace') {
      const existing = HEAD_DATA.students.find(s => s.studentId.toUpperCase() === r.data.studentId.toUpperCase());
      if (existing) {
        const oldGuardian = hGetGuardian(existing.guardianId);
        if (oldGuardian && oldGuardian.id !== guardian.id) oldGuardian.studentIds = oldGuardian.studentIds.filter(id => id !== existing.id);
        Object.assign(existing, {
          firstName: r.data.firstName, lastName: r.data.lastName, dob: r.data.dob, gender: r.data.gender.toUpperCase(),
          classId: cls ? cls.id : existing.classId, guardianId: guardian.id, address: r.data.address || existing.address,
        });
        if (!guardian.studentIds.includes(existing.id)) guardian.studentIds.push(existing.id);
        hLogStudentHistory(existing.id, 'class', t('Record updated via bulk import'));
        replaced++;
        return;
      }
    }
    const newStudent = {
      id:'hs' + Date.now() + Math.random().toString(36).slice(2, 5), studentId: r.effectiveId,
      firstName: r.data.firstName, lastName: r.data.lastName, dob: r.data.dob, gender: r.data.gender.toUpperCase(),
      classId: cls ? cls.id : null, guardianId: guardian.id, enrollmentDate: tISODate(new Date(2026, 2, 11)),
      status:'active', avgGrade:0, attendanceRate:100, paymentStatus:'paid', address: r.data.address || '',
      _createdAt: tISODate(new Date(2026, 2, 11)),
    };
    HEAD_DATA.students.push(newStudent);
    if (!guardian.studentIds.includes(newStudent.id)) guardian.studentIds.push(newStudent.id);
    hLogStudentHistory(newStudent.id, 'enrollment', t('Imported via bulk import'));
    created++;
  });
  const totalRows = hState.import.validationRows.length;
  const errorCount = hState.import.validationRows.filter(r => r.errors.length).length;
  const skippedCount = hImportDuplicateRows().filter(r => (hState.import.duplicateActions[r.rowIndex] || 'skip') === 'skip').length;
  hState.import.result = { created, replaced, errorCount, skippedCount, totalRows };
  hLogAudit('Import Completed', 'Bulk Import', 'Student Import', '', `${created} ${t('created')}, ${replaced} ${t('replaced')}`);
  hState.import.step = 6;
  hRefreshImport();
  hShowToast(t('Import completed successfully.'));
}
function hImportStep6() {
  const r = hState.import.result;
  if (!r) { hState.import.step = 1; return hImportBody(); }
  return `<div class="card"><div class="card-body" style="text-align:center;padding:30px 20px">
    <div style="font-size:34px;margin-bottom:10px">${aIcon('check-circle')}</div>
    <div style="font-weight:700;font-size:16px;margin-bottom:14px">${t('Import Complete')}</div>
    <div class="gd-pay-stat-row">
      <div class="stat-card"><div class="stat-label">${t('Created')}</div><div class="stat-val">${r.created}</div><div class="stat-icon green">${aIcon('plus')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Replaced')}</div><div class="stat-val">${r.replaced}</div><div class="stat-icon blue">${aIcon('refresh')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Skipped')}</div><div class="stat-val">${r.skippedCount}</div><div class="stat-icon yellow">${aIcon('skip-forward')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Errors')}</div><div class="stat-val">${r.errorCount}</div><div class="stat-icon red">${aIcon('x-circle')}</div></div>
    </div>
    <div style="display:flex;gap:10px;justify-content:center;margin-top:18px">
      <button class="st-btn" onclick="authrenGoTo('students')">${t('View Students')}</button>
      <button class="st-btn ghost" onclick="hRestartImport()">${t('Import Another File')}</button>
    </div>
  </div></div>`;
}

/* ══════════════════════════════════════════════════════
   HISTORICAL-DATA IMPORT (Previous Grades / Previous Attendance)
   A more compact 4-step flow (Type+Upload -> Mapping -> Validate & Preview
   -> Import) since duplicate-handling concerns differ from the student
   roster import above. Imported records write directly into the SAME
   real data (HEAD_DATA.exams / HEAD_DATA.attendanceRecords) already
   powering Grade Overview, Attendance, and Student History — so imports
   are immediately visible everywhere, not a separate disconnected store.
══════════════════════════════════════════════════════ */
const H_HIST_TYPES = [
  { id:'grades', label:'Previous Grades', fields: [
    { id:'studentId', label:'Student ID', required:true },
    { id:'examName', label:'Exam Name', required:true },
    { id:'subject', label:'Subject', required:true },
    { id:'className', label:'Class Name', required:true },
    { id:'date', label:'Date (YYYY-MM-DD)', required:true },
    { id:'score', label:'Score', required:true },
    { id:'maxScore', label:'Max Score', required:true },
  ]},
  { id:'attendance', label:'Previous Attendance', fields: [
    { id:'studentId', label:'Student ID', required:true },
    { id:'date', label:'Date (YYYY-MM-DD)', required:true },
    { id:'status', label:'Status (present/absent/late/excused)', required:true },
  ]},
];
function hHistTypeMeta(id) { return H_HIST_TYPES.find(x => x.id === id) || H_HIST_TYPES[0]; }
function hHistImportBody() {
  const step = hState.histImport.step;
  if (step === 2) return hHistStep2();
  if (step === 3) return hHistStep3();
  if (step === 4) return hHistStep4();
  return hHistStep1();
}
function hRefreshHistImport() { const el = document.getElementById('h-import-content'); if (el) el.innerHTML = hHistImportBody(); }
function hHistStepper() {
  const step = hState.histImport.step;
  const labels = ['Type & Upload', 'Mapping', 'Validate & Preview', 'Import'];
  return `<div style="display:flex;gap:4px;flex-wrap:wrap;margin-bottom:16px">${labels.map((l, i) => `<div class="status-pill ${i+1===step?'due':i+1<step?'paid':'resolved'}" style="font-size:10.5px">${i+1}. ${t(l)}</div>`).join('')}</div>`;
}
function hHistStep1() {
  const hi = hState.histImport;
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Historical Data Import')}</div></div>
    <div class="card-body">
      ${hHistStepper()}
      <div class="st-field"><label>${t('Data Type')}</label><select id="h-hist-type" onchange="hSetHistType(this.value)">
        ${H_HIST_TYPES.map(ty => `<option value="${ty.id}" ${ty.id===hi.type?'selected':''}>${t(ty.label)}</option>`).join('')}
      </select></div>
      <div style="font-size:12.5px;color:var(--muted);margin-bottom:14px">${t('Upload a CSV file with one row per record.')}</div>
      <input type="file" id="h-hist-file" accept=".csv" onchange="hHandleHistFile(this)">
      ${hi.error ? `<div class="st-inline-msg err show" style="margin-top:10px">${hi.error}</div>` : ''}
    </div></div>`;
}
function hSetHistType(v) { hState.histImport.type = v; }
function hHandleHistFile(input) {
  const file = input.files && input.files[0];
  if (!file) return;
  if (!file.name.toLowerCase().endsWith('.csv')) { hState.histImport.error = t('Please upload a .csv file.'); hRefreshHistImport(); return; }
  const reader = new FileReader();
  reader.onload = function(e) { hProcessHistFileText(e.target.result, file.name); };
  reader.onerror = function() { hState.histImport.error = t('Could not read this file. Please try again.'); hRefreshHistImport(); };
  reader.readAsText(file);
}
function hProcessHistFileText(text, fileName) {
  const parsed = hParseCSV(text);
  if (!parsed.headers.length || !parsed.rows.length) { hState.histImport.error = t('This file appears to be empty or invalid.'); hRefreshHistImport(); return; }
  hState.histImport.fileName = fileName;
  hState.histImport.rawHeaders = parsed.headers;
  hState.histImport.rawRows = parsed.rows;
  const fields = hHistTypeMeta(hState.histImport.type).fields;
  const normalize = s => s.toLowerCase().replace(/[^a-z]/g, '');
  const mapping = {};
  fields.forEach(f => {
    const idx = parsed.headers.findIndex(h => normalize(h) === normalize(f.id) || normalize(h).includes(normalize(f.id)));
    if (idx !== -1) mapping[f.id] = idx;
  });
  hState.histImport.mapping = mapping;
  hState.histImport.error = '';
  hState.histImport.step = 2;
  hRefreshHistImport();
}

/* ── Historical Import Step 2: Mapping ── */
function hHistStep2() {
  const hi = hState.histImport;
  const fields = hHistTypeMeta(hi.type).fields;
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Historical Data Import')}</div></div>
    <div class="card-body">
      ${hHistStepper()}
      <div style="font-size:12.5px;color:var(--muted);margin-bottom:14px">${gdCommsEsc(hi.fileName)} · ${hi.rawRows.length} ${t('rows')}</div>
      ${fields.map(f => `<div class="st-field"><label>${t(f.label)}${f.required?' *':''}</label><select id="h-hmap-${f.id}" onchange="hSetHistMapping('${f.id}', this.value)">
        <option value="">${t('-- Not Mapped --')}</option>
        ${hi.rawHeaders.map((h, i) => `<option value="${i}" ${hi.mapping[f.id]===i?'selected':''}>${gdCommsEsc(h)}</option>`).join('')}
      </select></div>`).join('')}
      <div style="display:flex;gap:10px">
        <button class="st-btn" onclick="hProceedToHistValidation()">${t('Next: Validate')}</button>
        <button class="st-btn ghost" onclick="hRestartHistImport()">${t('Start Over')}</button>
      </div>
      ${hi.error ? `<div class="st-inline-msg err show" style="margin-top:12px">${hi.error}</div>` : ''}
    </div></div>`;
}
function hSetHistMapping(fieldId, value) {
  if (value === '') delete hState.histImport.mapping[fieldId];
  else hState.histImport.mapping[fieldId] = Number(value);
}
function hRestartHistImport() {
  hState.histImport = { type:'grades', step:1, fileName:'', rawHeaders:[], rawRows:[], mapping:{}, validationRows:[], result:null, error:'' };
  hRefreshHistImport();
}

/* ── Historical Import Step 3: Validate & Preview (combined) ── */
function hExtractHistRowData(row, fields) {
  const hi = hState.histImport;
  const data = {};
  fields.forEach(f => { const idx = hi.mapping[f.id]; data[f.id] = idx !== undefined ? (row[idx] || '').trim() : ''; });
  return data;
}
function hValidateHistRow(type, data) {
  const errors = [];
  if (!data.studentId) errors.push(t('Missing student ID'));
  else if (!HEAD_DATA.students.some(s => s.studentId.toUpperCase() === data.studentId.toUpperCase())) errors.push(`${t('Student ID not found')}: "${data.studentId}"`);
  if (!data.date) errors.push(t('Missing date'));
  else if (!/^\d{4}-\d{2}-\d{2}$/.test(data.date)) errors.push(t('Invalid date format (expected YYYY-MM-DD)'));
  if (type === 'grades') {
    if (!data.examName) errors.push(t('Missing exam name'));
    if (!data.subject) errors.push(t('Missing subject'));
    if (!data.className) errors.push(t('Missing class'));
    else if (!hResolveClassByName(data.className)) errors.push(`${t('Class not found')}: "${data.className}"`);
    if (!data.score) errors.push(t('Missing score'));
    else if (isNaN(Number(data.score))) errors.push(t('Score must be a number'));
    if (!data.maxScore) errors.push(t('Missing max score'));
    else if (isNaN(Number(data.maxScore))) errors.push(t('Max score must be a number'));
    if (data.score && data.maxScore && !isNaN(Number(data.score)) && !isNaN(Number(data.maxScore)) && Number(data.score) > Number(data.maxScore)) errors.push(t('Score cannot exceed max score'));
  } else {
    if (!data.status) errors.push(t('Missing status'));
    else if (!['present', 'absent', 'late', 'excused'].includes(data.status.toLowerCase())) errors.push(t('Invalid status (expected present, absent, late, or excused)'));
  }
  return errors;
}
function hProceedToHistValidation() {
  const hi = hState.histImport;
  const fields = hHistTypeMeta(hi.type).fields;
  const missing = fields.filter(f => f.required && hi.mapping[f.id] === undefined);
  if (missing.length) { hi.error = `${t('Please map all required fields')}: ${missing.map(f => t(f.label)).join(', ')}.`; hRefreshHistImport(); return; }
  hi.error = '';
  hi.validationRows = hi.rawRows.map((row, i) => {
    const data = hExtractHistRowData(row, fields);
    return { rowIndex:i, data, errors: hValidateHistRow(hi.type, data) };
  });
  hi.step = 3;
  hRefreshHistImport();
}
function hHistStep3() {
  const hi = hState.histImport;
  const validRows = hi.validationRows.filter(r => !r.errors.length);
  const errorRows = hi.validationRows.filter(r => r.errors.length);
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Historical Data Import')}</div></div>
    <div class="card-body">
      ${hHistStepper()}
      <div class="gd-pay-stat-row" style="margin-bottom:14px">
        <div class="stat-card"><div class="stat-label">${t('Total Rows')}</div><div class="stat-val">${hi.validationRows.length}</div><div class="stat-icon blue">${aIcon('file-text')}</div></div>
        <div class="stat-card"><div class="stat-label">${t('Valid')}</div><div class="stat-val">${validRows.length}</div><div class="stat-icon green">${aIcon('check-circle')}</div></div>
        <div class="stat-card"><div class="stat-label">${t('Errors')}</div><div class="stat-val">${errorRows.length}</div><div class="stat-icon red">${aIcon('x-circle')}</div></div>
      </div>
      ${errorRows.length ? `<div style="font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Rows with Errors')}</div>
        ${errorRows.map(r => `<div class="info-row" style="align-items:flex-start"><span>${t('Row')} ${r.rowIndex + 2}<div style="font-size:11px;color:var(--red);margin-top:2px">${r.errors.map(e => gdCommsEsc(e)).join('; ')}</div></span></div>`).join('')}` : ''}
      <div style="font-size:12.5px;font-weight:600;margin:14px 0 8px">${t('Preview — exactly what will be imported')}</div>
      ${validRows.length ? validRows.map(r => {
        const student = HEAD_DATA.students.find(s => s.studentId.toUpperCase() === r.data.studentId.toUpperCase());
        const label = hi.type === 'grades' ? `${r.data.examName} — ${r.data.score}/${r.data.maxScore}` : `${t(r.data.status.charAt(0).toUpperCase()+r.data.status.slice(1).toLowerCase())}`;
        return `<div class="info-row"><span>${student ? gdCommsEsc(hStudentFullName(student)) : gdCommsEsc(r.data.studentId)}<div style="font-size:11px;color:var(--muted)">${r.data.date}</div></span><span style="color:var(--muted);font-size:12.5px">${gdCommsEsc(label)}</span></div>`;
      }).join('') : `<div class="gd-empty-mini">${t('No valid rows to import.')}</div>`}
      <div style="display:flex;gap:10px;margin-top:14px">
        <button class="st-btn" onclick="hRunHistImport()" ${!validRows.length?'disabled':''}>${t('Import')}</button>
        <button class="st-btn ghost" onclick="hState.histImport.step=2;hRefreshHistImport()">${t('← Back')}</button>
        <button class="st-btn ghost" onclick="hRestartHistImport()">${t('Start Over')}</button>
      </div>
    </div></div>`;
}

/* ── Historical Import: actual execution + Step 4 result ──
   Writes directly into the SAME HEAD_DATA.exams / attendanceRecords /
   H_ATTENDANCE_DAYS already used everywhere else, so imported history
   is immediately visible in Grade Overview, Attendance, and Student
   History — not a disconnected side-store. ── */
function hRunHistImport() {
  const hi = hState.histImport;
  const validRows = hi.validationRows.filter(r => !r.errors.length);
  let importedCount = 0;

  if (hi.type === 'grades') {
    const examGroups = {};
    validRows.forEach(r => {
      const key = `${r.data.examName}|${r.data.className}|${r.data.date}`;
      if (!examGroups[key]) examGroups[key] = { name:r.data.examName, subject:r.data.subject, className:r.data.className, date:r.data.date, maxScore:Number(r.data.maxScore), rows:[] };
      examGroups[key].rows.push(r);
    });
    Object.values(examGroups).forEach(group => {
      const cls = hResolveClassByName(group.className);
      const newExam = { id:'he' + Date.now() + Math.random().toString(36).slice(2, 5), name: group.name, classId: cls ? cls.id : null, subject: group.subject, date: group.date, time:'09:00', duration:60, maxScore: group.maxScore, status:'completed', locked:false, scores:{} };
      group.rows.forEach(r => {
        const student = HEAD_DATA.students.find(s => s.studentId.toUpperCase() === r.data.studentId.toUpperCase());
        if (student) { newExam.scores[student.id] = Number(r.data.score); importedCount++; }
      });
      HEAD_DATA.exams.push(newExam);
    });
  } else {
    validRows.forEach(r => {
      const student = HEAD_DATA.students.find(s => s.studentId.toUpperCase() === r.data.studentId.toUpperCase());
      if (!student) return;
      if (!H_ATTENDANCE_DAYS.includes(r.data.date)) { H_ATTENDANCE_DAYS.push(r.data.date); H_ATTENDANCE_DAYS.sort(); }
      if (!HEAD_DATA.attendanceRecords[r.data.date]) HEAD_DATA.attendanceRecords[r.data.date] = {};
      HEAD_DATA.attendanceRecords[r.data.date][student.id] = r.data.status.toLowerCase();
      importedCount++;
    });
  }

  hi.result = { importedCount, totalRows: hi.validationRows.length, errorCount: hi.validationRows.length - validRows.length, type: hi.type };
  hLogAudit('Import Completed', 'Historical Import', hi.type === 'grades' ? t('Previous Grades') : t('Previous Attendance'), '', `${importedCount} ${t('records')}`);
  hi.step = 4;
  hRefreshHistImport();
  hShowToast(t('Historical data imported successfully.'));
}
function hHistStep4() {
  const r = hState.histImport.result;
  if (!r) { hState.histImport.step = 1; return hHistImportBody(); }
  return `<div class="card"><div class="card-body" style="text-align:center;padding:30px 20px">
    <div style="font-size:34px;margin-bottom:10px">${aIcon('check-circle')}</div>
    <div style="font-weight:700;font-size:16px;margin-bottom:14px">${t('Import Complete')}</div>
    <div class="gd-pay-stat-row">
      <div class="stat-card"><div class="stat-label">${t('Records Imported')}</div><div class="stat-val">${r.importedCount}</div><div class="stat-icon green">${aIcon('plus')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Total Rows')}</div><div class="stat-val">${r.totalRows}</div><div class="stat-icon blue">${aIcon('file-text')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Errors')}</div><div class="stat-val">${r.errorCount}</div><div class="stat-icon red">${aIcon('x-circle')}</div></div>
    </div>
    <div style="display:flex;gap:10px;justify-content:center;margin-top:18px">
      <button class="st-btn" onclick="authrenGoTo('${r.type==='grades'?'grades':'attendance'}')">${t('View')} ${r.type==='grades'?t('Grades'):t('Attendance')}</button>
      <button class="st-btn ghost" onclick="hRestartHistImport()">${t('Import Another File')}</button>
    </div>
  </div></div>`;
}

/* ══════════════════════════════════════════════════════
   ACCOUNTS: Generation + Temporary Credentials + Downloadable Sheets
══════════════════════════════════════════════════════ */
function hAccountPersonName(personType, personId) {
  if (personType === 'student') { const s = hGetStudent(personId); return s ? hStudentFullName(s) : t('Unknown'); }
  if (personType === 'teacher') { const te = hGetTeacher(personId); return te ? te.name : t('Unknown'); }
  const g = hGetGuardian(personId); return g ? g.name : t('Unknown');
}
function hAccountPersonRealId(personType, personId) {
  if (personType === 'student') { const s = hGetStudent(personId); return s ? s.studentId : '—'; }
  if (personType === 'teacher') { const te = hGetTeacher(personId); return te ? te.teacherId : '—'; }
  const g = hGetGuardian(personId); return g && g.authrenId ? g.authrenId : '—';
}
function hAllPeopleOfType(personType) {
  if (personType === 'student') return HEAD_DATA.students;
  if (personType === 'teacher') return HEAD_DATA.teachers;
  return HEAD_DATA.guardians;
}
function hPersonHasAccount(personType, personId) {
  return HEAD_DATA.generatedAccounts.some(a => a.personType === personType && a.personId === personId);
}
function hGenerateTempPassword() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
  let pw = '';
  for (let i = 0; i < 8; i++) pw += chars[Math.floor(Math.random() * chars.length)];
  return pw;
}
function hAccountsView() {
  const tabs = [ { id:'generate', label:'Generate Accounts' }, { id:'list', label:'Account List' }, { id:'sheets', label:'Account Sheets' } ];
  return `<div class="st-tabs">${tabs.map(tb => `<div class="st-tab gd-tab-hacc${tb.id===hState.accounts.screen?' active':''}" data-tab="${tb.id}" onclick="hSetAccountsTab('${tb.id}')">${t(tb.label)}</div>`).join('')}</div>
    <div id="h-accounts-content">${hAccountsBody()}</div>`;
}
function hSetAccountsTab(tabId) {
  hState.accounts.screen = tabId;
  document.querySelectorAll('.gd-tab-hacc').forEach(el => el.classList.toggle('active', el.dataset.tab === tabId));
  const el = document.getElementById('h-accounts-content');
  if (el) el.innerHTML = hAccountsBody();
}
function hAccountsBody() {
  const s = hState.accounts.screen;
  if (s === 'list') return hAccountListScreen();
  if (s === 'sheets') return hAccountSheetsScreen();
  return hAccountGenerateScreen();
}
function hRefreshAccounts() { const el = document.getElementById('h-accounts-content'); if (el) el.innerHTML = hAccountsBody(); }

/* ── Generate Accounts ── */
function hAccountGenerateScreen() {
  const a = hState.accounts;
  const types = [['student','Students'],['teacher','Teachers'],['guardian','Guardians']];
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Generate Accounts')}</div></div>
    <div class="card-body">
      <div class="gd-comm-filter-row" style="margin-bottom:12px">${types.map(([id,label]) => `<div class="gd-comm-filter-chip${a.personType===id?' active':''}" onclick="hSetAccountPersonType('${id}')">${t(label)}</div>`).join('')}</div>
      <input class="gd-comm-search-input" type="text" placeholder="${t('Search by name...')}" value="${gdCommsEsc(a.search)}" oninput="hSetAccountSearch(this.value)">
      <div id="h-acc-gen-results" style="margin-top:10px">${hAccountGenResultsBlock()}</div>
      <button class="st-btn" style="margin-top:12px" onclick="hGenerateSelectedAccounts()" ${!a.selected.length?'disabled':''}>${t('Generate Accounts')} (${a.selected.length})</button>
    </div></div>`;
}
function hAccountGenResultsBlock() {
  const a = hState.accounts;
  const people = hAllPeopleOfType(a.personType).filter(p => !hPersonHasAccount(a.personType, p.id));
  const q = a.search.trim().toLowerCase();
  const nameOf = p => a.personType === 'student' ? hStudentFullName(p) : p.name;
  const filtered = q ? people.filter(p => nameOf(p).toLowerCase().includes(q)) : people;
  if (!filtered.length) return `<div class="gd-empty-mini">${t('No eligible people found — everyone in this group may already have an account.')}</div>`;
  return filtered.map(p => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hToggleAccountSelect('${p.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hToggleAccountSelect('${p.id}')}">
    <span><input type="checkbox" ${a.selected.includes(p.id)?'checked':''} style="margin-right:8px;pointer-events:none">${gdCommsEsc(nameOf(p))}</span>
  </div>`).join('');
}
function hSetAccountPersonType(v) {
  hState.accounts.personType = v;
  hState.accounts.selected = [];
  hState.accounts.search = '';
  hRefreshAccounts();
}
function hSetAccountSearch(v) {
  hState.accounts.search = v;
  const el = document.getElementById('h-acc-gen-results');
  if (el) el.innerHTML = hAccountGenResultsBlock();
}
function hToggleAccountSelect(personId) {
  const a = hState.accounts;
  if (a.selected.includes(personId)) a.selected = a.selected.filter(id => id !== personId);
  else a.selected.push(personId);
  hRefreshAccounts();
}
function hGenerateSelectedAccounts() {
  const a = hState.accounts;
  const created = [];
  a.selected.forEach(personId => {
    if (a.personType === 'guardian') {
      const guardian = hGetGuardian(personId);
      if (guardian && !guardian.authrenId) guardian.authrenId = 'G' + String(Math.floor(10000000 + Math.random() * 89999999));
    }
    const account = { id:'acc' + Date.now() + Math.random().toString(36).slice(2, 5), personType:a.personType, personId, authrenId: hAccountPersonRealId(a.personType, personId), tempPassword: hGenerateTempPassword(), status:'generated', generatedAt: tISODate(new Date(2026, 2, 11)) };
    HEAD_DATA.generatedAccounts.push(account);
    created.push(account);
  });
  a.selected = [];
  if (created.length) hLogAudit('Account Generated', 'Account', `${created.length} ${a.personType}(s)`, '', created.map(c => c.authrenId).join(', '));
  hRefreshAccounts();
  hShowToast(`${created.length} ${t('account(s) generated successfully.')}`);
}

/* ── Account List (credential management) ── */
function hAccountListScreen() {
  const a = hState.accounts;
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Account List')}</div></div>
    <div class="card-body">
      <div style="display:flex;gap:10px;flex-wrap:wrap">
        <select onchange="hSetAccListTypeFilter(this.value)" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
          <option value="all" ${a.listFilterType==='all'?'selected':''}>${t('All Types')}</option>
          <option value="student" ${a.listFilterType==='student'?'selected':''}>${t('Students')}</option>
          <option value="teacher" ${a.listFilterType==='teacher'?'selected':''}>${t('Teachers')}</option>
          <option value="guardian" ${a.listFilterType==='guardian'?'selected':''}>${t('Guardians')}</option>
        </select>
        <select onchange="hSetAccListStatusFilter(this.value)" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
          <option value="all" ${a.listFilterStatus==='all'?'selected':''}>${t('All Statuses')}</option>
          <option value="generated" ${a.listFilterStatus==='generated'?'selected':''}>${t('Generated')}</option>
          <option value="distributed" ${a.listFilterStatus==='distributed'?'selected':''}>${t('Distributed')}</option>
          <option value="activated" ${a.listFilterStatus==='activated'?'selected':''}>${t('Activated')}</option>
        </select>
      </div>
      <div id="h-acc-list-results" style="margin-top:12px">${hAccountListResultsBlock()}</div>
    </div></div>`;
}
function hFilteredAccounts() {
  const a = hState.accounts;
  let list = HEAD_DATA.generatedAccounts.slice();
  if (a.listFilterType !== 'all') list = list.filter(x => x.personType === a.listFilterType);
  if (a.listFilterStatus !== 'all') list = list.filter(x => x.status === a.listFilterStatus);
  return list.sort((x, y) => y.generatedAt.localeCompare(x.generatedAt));
}
function hAccountListResultsBlock() {
  const list = hFilteredAccounts();
  if (!list.length) return `<div class="gd-empty-mini">${t('No accounts match your filters.')}</div>`;
  const statusMeta = { generated:{cls:'due',label:'Generated'}, distributed:{cls:'awaiting',label:'Distributed'}, activated:{cls:'paid',label:'Activated'} };
  return list.map(acc => {
    const meta = statusMeta[acc.status];
    return `<div class="card" style="margin-bottom:10px;background:var(--surface2)"><div class="card-body">
      <div style="display:flex;justify-content:space-between;align-items:flex-start">
        <div>
          <div style="font-weight:600;font-size:13px">${gdCommsEsc(hAccountPersonName(acc.personType, acc.personId))}</div>
          <div style="font-size:11px;color:var(--muted);margin-top:2px">${t(acc.personType.charAt(0).toUpperCase()+acc.personType.slice(1))} · ${gdCommsEsc(acc.authrenId)}</div>
        </div>
        <span class="status-pill ${meta.cls}">${t(meta.label)}</span>
      </div>
      <div style="font-size:12px;color:var(--muted);margin-top:8px">${t('Temporary Password')}: <span style="font-family:monospace;color:var(--color-text)">${gdCommsEsc(acc.tempPassword)}</span></div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px">
        <button type="button" class="st-btn ghost sm" onclick="hConfirmRegeneratePassword('${acc.id}')">${t('Regenerate Password')}</button>
        ${acc.status === 'generated' ? `<button type="button" class="st-btn ghost sm" onclick="hMarkAccountStatus('${acc.id}','distributed')">${t('Mark as Distributed')}</button>` : ''}
        ${acc.status !== 'activated' ? `<button type="button" class="st-btn ghost sm" onclick="hMarkAccountStatus('${acc.id}','activated')">${t('Mark as Activated')}</button>` : ''}
      </div>
    </div></div>`;
  }).join('');
}
function hSetAccListTypeFilter(v) { hState.accounts.listFilterType = v; const el = document.getElementById('h-acc-list-results'); if (el) el.innerHTML = hAccountListResultsBlock(); }
function hSetAccListStatusFilter(v) { hState.accounts.listFilterStatus = v; const el = document.getElementById('h-acc-list-results'); if (el) el.innerHTML = hAccountListResultsBlock(); }
function hConfirmRegeneratePassword(accountId) {
  stOpenModal(`<h3 style="margin-bottom:10px">${t('Regenerate temporary password?')}</h3>
    <p style="font-size:13px;color:var(--muted);margin-bottom:18px">${t('The current temporary password will no longer be valid.')}</p>
    <div style="display:flex;gap:10px">
      <button class="st-btn" onclick="hRegeneratePassword('${accountId}');stCloseModal()">${t('Regenerate')}</button>
      <button class="st-btn ghost" onclick="stCloseModal()">${t('Cancel')}</button>
    </div>`);
}
function hRegeneratePassword(accountId) {
  const acc = HEAD_DATA.generatedAccounts.find(a => a.id === accountId);
  if (!acc) return;
  acc.tempPassword = hGenerateTempPassword();
  const el = document.getElementById('h-acc-list-results');
  if (el) el.innerHTML = hAccountListResultsBlock();
  hShowToast(t('Temporary password regenerated.'));
}
function hMarkAccountStatus(accountId, status) {
  const acc = HEAD_DATA.generatedAccounts.find(a => a.id === accountId);
  if (!acc) return;
  acc.status = status;
  const el = document.getElementById('h-acc-list-results');
  if (el) el.innerHTML = hAccountListResultsBlock();
  hShowToast(status === 'distributed' ? t('Marked as distributed.') : t('Marked as activated.'));
}

/* ── Downloadable Account Sheets ── */
function hAccountSheetsScreen() {
  const a = hState.accounts;
  if (a.sheetSelected.length && a.sheetPreview) return hAccountSheetPreview();
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Account Sheets')}</div></div>
    <div class="card-body">
      <div style="font-size:12.5px;color:var(--muted);margin-bottom:12px">${t('Select the accounts to include in a printable sheet.')}</div>
      ${HEAD_DATA.generatedAccounts.length ? HEAD_DATA.generatedAccounts.map(acc => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hToggleSheetSelect('${acc.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hToggleSheetSelect('${acc.id}')}">
        <span><input type="checkbox" ${a.sheetSelected.includes(acc.id)?'checked':''} style="margin-right:8px;pointer-events:none">${gdCommsEsc(hAccountPersonName(acc.personType, acc.personId))}<span style="color:var(--muted);font-size:11.5px"> · ${t(acc.personType.charAt(0).toUpperCase()+acc.personType.slice(1))}</span></span>
      </div>`).join('') : `<div class="gd-empty-mini">${t('No accounts have been generated yet.')}</div>`}
      <button class="st-btn" style="margin-top:12px" onclick="hGenerateAccountSheet()" ${!a.sheetSelected.length?'disabled':''}>${t('Generate Account Sheet')} (${a.sheetSelected.length})</button>
    </div></div>`;
}
function hToggleSheetSelect(accountId) {
  const a = hState.accounts;
  if (a.sheetSelected.includes(accountId)) a.sheetSelected = a.sheetSelected.filter(id => id !== accountId);
  else a.sheetSelected.push(accountId);
  hRefreshAccounts();
}
function hGenerateAccountSheet() {
  hState.accounts.sheetPreview = true;
  hRefreshAccounts();
}
function hAccountSheetPreview() {
  const a = hState.accounts;
  const accounts = HEAD_DATA.generatedAccounts.filter(acc => a.sheetSelected.includes(acc.id));
  return `<div class="card"><div class="card-header">
    <div style="display:flex;align-items:center;gap:10px"><button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="hBackToAccountSheetSelection()">${t('← Back')}</button><div class="card-title">${t('Account Sheet Preview')}</div></div>
    <button type="button" class="st-btn ghost sm" onclick="window.print()">${aIcon('printer')} ${t('Print / Download')}</button>
  </div>
    <div class="card-body">
      <div style="font-size:11.5px;color:var(--muted);margin-bottom:14px">${gdCommsEsc(HEAD_DATA.institution.name)} · ${tISODate(new Date(2026, 2, 11))}</div>
      ${accounts.map(acc => `<div class="info-row"><span>${gdCommsEsc(hAccountPersonName(acc.personType, acc.personId))}<div style="font-size:11px;color:var(--muted)">${t(acc.personType.charAt(0).toUpperCase()+acc.personType.slice(1))} · ${gdCommsEsc(acc.authrenId)}</div></span><span style="font-family:monospace">${gdCommsEsc(acc.tempPassword)}</span></div>`).join('')}
    </div></div>`;
}
function hBackToAccountSheetSelection() {
  hState.accounts.sheetPreview = false;
  hRefreshAccounts();
}

/* ══════════════════════════════════════════════════════
   ADVANCED ATTENDANCE ANALYTICS
══════════════════════════════════════════════════════ */
function hAttendanceByDayOfWeek() {
  const dowNames = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
  const buckets = {};
  H_ATTENDANCE_DAYS.forEach(date => {
    const dow = new Date(date + 'T00:00:00').getDay();
    if (!buckets[dow]) buckets[dow] = { present:0, total:0 };
    HEAD_DATA.students.forEach(s => {
      const status = hAttendanceStatusFor(s.id, date);
      if (!status) return;
      buckets[dow].total++;
      if (status === 'present' || status === 'late') buckets[dow].present++;
    });
  });
  return [1, 2, 3, 4, 5].filter(d => buckets[d]).map(d => ({ label: t(dowNames[d]), rate: Math.round((buckets[d].present / buckets[d].total) * 100) }));
}
function hAttendanceByMonth() {
  const buckets = {};
  H_ATTENDANCE_DAYS.forEach(date => {
    const month = date.slice(0, 7);
    if (!buckets[month]) buckets[month] = { present:0, total:0 };
    HEAD_DATA.students.forEach(s => {
      const status = hAttendanceStatusFor(s.id, date);
      if (!status) return;
      buckets[month].total++;
      if (status === 'present' || status === 'late') buckets[month].present++;
    });
  });
  return Object.keys(buckets).sort().map(m => ({ label: m, rate: Math.round((buckets[m].present / buckets[m].total) * 100) }));
}
function hStudentsWithRepeatedAbsences() {
  return HEAD_DATA.students.map(s => {
    const count = H_ATTENDANCE_DAYS.filter(d => { const st = hAttendanceStatusFor(s.id, d); return st === 'absent' || st === 'excused'; }).length;
    return { student:s, count };
  }).filter(x => x.count >= 2).sort((a, b) => b.count - a.count);
}
function hAttendanceAdvancedTab() {
  const allIds = HEAD_DATA.students.map(s => s.id);
  const trendPoints = H_ATTENDANCE_DAYS.map(d => {
    const agg = hAggregateAttendance(allIds, [d]);
    return { label: d.slice(5), value: agg.rate !== null ? agg.rate : 0 };
  });
  const absencePoints = H_ATTENDANCE_DAYS.map(d => {
    const agg = hAggregateAttendance(allIds, [d]);
    return { label: d.slice(5), value: agg.total ? Math.round((agg.absent / agg.total) * 100) : 0 };
  });
  const latePoints = H_ATTENDANCE_DAYS.map(d => {
    const agg = hAggregateAttendance(allIds, [d]);
    return { label: d.slice(5), value: agg.total ? Math.round((agg.late / agg.total) * 100) : 0 };
  });
  const classComparison = HEAD_DATA.classes.map(c => ({ cls:c, rate: hAggregateAttendance(hClassStudents(c.id).map(s => s.id), H_ATTENDANCE_DAYS).rate })).sort((a, b) => (b.rate || 0) - (a.rate || 0));
  const sortedStudents = HEAD_DATA.students.map(s => ({ student:s, rate: hAggregateAttendance([s.id], H_ATTENDANCE_DAYS).rate })).sort((a, b) => (b.rate || 0) - (a.rate || 0));
  const byDay = hAttendanceByDayOfWeek();
  const byMonth = hAttendanceByMonth();
  const repeated = hStudentsWithRepeatedAbsences();

  return `
    <div class="card"><div class="card-header"><div class="card-title">${t('Attendance Rate Trend')}</div></div>
      <div class="card-body">${gdSvgLineChart(trendPoints, { max:100, unit:'%', ariaLabel:t('Attendance trend'), emptyText:t('No data available.') })}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Absence Rate Trend')}</div></div>
      <div class="card-body">${gdSvgLineChart(absencePoints, { max:100, unit:'%', ariaLabel:t('Absence trend'), emptyText:t('No data available.') })}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Late Rate Trend')}</div></div>
      <div class="card-body">${gdSvgLineChart(latePoints, { max:100, unit:'%', ariaLabel:t('Late trend'), emptyText:t('No data available.') })}</div></div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Class Comparison')}</div></div>
      <div class="card-body">${classComparison.map(x => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hOpenAttendanceClass('${x.cls.id}');hSetAttendanceTab('overview')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hOpenAttendanceClass('${x.cls.id}');hSetAttendanceTab('overview')}"><span>${gdCommsEsc(x.cls.name)}</span><span style="color:var(--muted)">${x.rate !== null ? x.rate + '%' : '—'}</span></div>`).join('')}</div></div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Student Comparison')}</div><span style="font-size:12px;color:var(--muted)">${t('Highest and lowest')}</span></div>
      <div class="card-body">
        ${sortedStudents.slice(0, 3).map(x => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hGoToStudentFromClass('${x.student.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hGoToStudentFromClass('${x.student.id}')}"><span>${aIcon('dot')} ${gdCommsEsc(hStudentFullName(x.student))}</span><span style="color:var(--muted)">${x.rate}%</span></div>`).join('')}
        ${sortedStudents.slice(-3).reverse().map(x => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hGoToStudentFromClass('${x.student.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hGoToStudentFromClass('${x.student.id}')}"><span>${aIcon('dot')} ${gdCommsEsc(hStudentFullName(x.student))}</span><span style="color:var(--muted)">${x.rate}%</span></div>`).join('')}
      </div></div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Attendance by Day of Week')}</div></div>
      <div class="card-body">${byDay.map(d => `<div class="info-row"><span>${d.label}</span><span style="color:var(--muted)">${d.rate}%</span></div>`).join('')}</div></div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Attendance by Month')}</div></div>
      <div class="card-body">${byMonth.map(m => `<div class="info-row"><span>${m.label}</span><span style="color:var(--muted)">${m.rate}%</span></div>`).join('')}</div></div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Students with Repeated Absences')}</div><span style="font-size:12px;color:var(--muted)">${t('2 or more')}</span></div>
      <div class="card-body">${repeated.length ? repeated.map(x => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hGoToStudentFromClass('${x.student.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hGoToStudentFromClass('${x.student.id}')}"><span>${gdCommsEsc(hStudentFullName(x.student))}</span><span style="color:var(--red)">${x.count} ${t('absences')}</span></div>`).join('') : `<div class="gd-empty-mini">${t('No students with repeated absences.')}</div>`}</div></div>`;
}

/* ══════════════════════════════════════════════════════
   ADVANCED ACADEMIC ANALYTICS
══════════════════════════════════════════════════════ */
function hStudentExamHistoryH(studentId) {
  return HEAD_DATA.exams.filter(e => e.scores[studentId] !== undefined).map(e => ({ name:e.name, date:e.date, score:e.scores[studentId], maxScore:e.maxScore })).sort((a, b) => a.date.localeCompare(b.date));
}
function hStudentGradeTrendH(studentId) {
  const history = hStudentExamHistoryH(studentId);
  if (history.length < 2) return null;
  const firstPct = (history[0].score / history[0].maxScore) * 100;
  const lastPct = (history[history.length - 1].score / history[history.length - 1].maxScore) * 100;
  return Math.round(lastPct - firstPct);
}
function hAcademicAdvancedTab() {
  const allExamDates = Array.from(new Set(HEAD_DATA.exams.filter(e => Object.keys(e.scores).length).map(e => e.date))).sort();
  const trendPoints = allExamDates.map(date => {
    const examsOnDate = HEAD_DATA.exams.filter(e => e.date === date && Object.keys(e.scores).length);
    const pcts = [];
    examsOnDate.forEach(e => Object.values(e.scores).forEach(sc => pcts.push((sc / e.maxScore) * 100)));
    return { label: date.slice(5), value: pcts.length ? Math.round(hAvg(pcts)) : 0 };
  });
  const classAverages = HEAD_DATA.classes.map(c => ({ cls:c, avg: hClassAvgGrade(c.id) })).filter(x => x.avg !== null);
  const topGroups = classAverages.filter(x => x.avg >= 14).sort((a, b) => b.avg - a.avg);
  const underGroups = classAverages.filter(x => x.avg < 12).sort((a, b) => a.avg - b.avg);
  const progressions = HEAD_DATA.students.map(s => ({ student:s, trend: hStudentGradeTrendH(s.id) })).filter(x => x.trend !== null);
  const improving = progressions.filter(x => x.trend > 0).sort((a, b) => b.trend - a.trend).slice(0, 5);
  const declining = progressions.filter(x => x.trend < 0).sort((a, b) => a.trend - b.trend).slice(0, 5);

  const cutoff = '2026-01-01';
  const previousScores = [], currentScores = [];
  HEAD_DATA.exams.forEach(e => Object.values(e.scores).forEach(sc => { const pct = (sc / e.maxScore) * 100; (e.date < cutoff ? previousScores : currentScores).push(pct); }));
  const previousAvg = previousScores.length ? Math.round(hAvg(previousScores)) : null;
  const currentAvg = currentScores.length ? Math.round(hAvg(currentScores)) : null;

  const subjectProgressions = hAllSubjects().map(sub => {
    const exams = HEAD_DATA.exams.filter(e => e.subject === sub && Object.keys(e.scores).length).sort((a, b) => a.date.localeCompare(b.date));
    const points = exams.map(e => Math.round(hAvg(Object.values(e.scores).map(sc => (sc / e.maxScore) * 100))));
    return { subject:sub, points, trend: points.length >= 2 ? points[points.length - 1] - points[0] : null };
  });
  const classProgressions = HEAD_DATA.classes.map(c => {
    const exams = HEAD_DATA.exams.filter(e => e.classId === c.id && Object.keys(e.scores).length).sort((a, b) => a.date.localeCompare(b.date));
    const points = exams.map(e => Math.round(hAvg(Object.values(e.scores).map(sc => (sc / e.maxScore) * 100))));
    return { cls:c, points, trend: points.length >= 2 ? points[points.length - 1] - points[0] : null };
  });

  return `
    <div class="card"><div class="card-header"><div class="card-title">${t('Average Trend Over Time')}</div></div>
      <div class="card-body">${gdSvgLineChart(trendPoints, { max:100, unit:'%', ariaLabel:t('Average trend'), emptyText:t('Not enough graded exams yet.') })}</div></div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Top-Performing Classes')}</div><span style="font-size:12px;color:var(--muted)">${t('Average of 14/20 or higher')}</span></div>
      <div class="card-body">${topGroups.length ? topGroups.map(x => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hOpenGradesClass('${x.cls.id}');hSetGradesTab('overview')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hOpenGradesClass('${x.cls.id}');hSetGradesTab('overview')}"><span>${gdCommsEsc(x.cls.name)}</span><span style="color:var(--green)">${x.avg}/20</span></div>`).join('') : `<div class="gd-empty-mini">${t('No classes currently meet this threshold.')}</div>`}</div></div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Underperforming Classes')}</div><span style="font-size:12px;color:var(--muted)">${t('Average below 12/20')}</span></div>
      <div class="card-body">${underGroups.length ? underGroups.map(x => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hOpenGradesClass('${x.cls.id}');hSetGradesTab('overview')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hOpenGradesClass('${x.cls.id}');hSetGradesTab('overview')}"><span>${gdCommsEsc(x.cls.name)}</span><span style="color:var(--red)">${x.avg}/20</span></div>`).join('') : `<div class="gd-empty-mini">${t('No classes currently below this threshold.')}</div>`}</div></div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Student Progression')}</div><span style="font-size:12px;color:var(--muted)">${t('Based on graded exam history')}</span></div>
      <div class="card-body">
        ${improving.length || declining.length ? `
          ${improving.map(x => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hGoToStudentFromClass('${x.student.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hGoToStudentFromClass('${x.student.id}')}"><span>▲ ${gdCommsEsc(hStudentFullName(x.student))}</span><span style="color:var(--green)">+${x.trend}%</span></div>`).join('')}
          ${declining.map(x => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hGoToStudentFromClass('${x.student.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hGoToStudentFromClass('${x.student.id}')}"><span>▼ ${gdCommsEsc(hStudentFullName(x.student))}</span><span style="color:var(--red)">${x.trend}%</span></div>`).join('')}
        ` : `<div class="gd-empty-mini">${t('Not enough graded history yet to compute progression.')}</div>`}
      </div></div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Progression by Subject')}</div></div>
      <div class="card-body">${subjectProgressions.map(sp => `<div class="info-row"><span>${gdCommsEsc(t(sp.subject))}</span><span style="color:${sp.trend===null?'var(--muted)':sp.trend<0?'var(--red)':'var(--green)'}">${sp.trend===null ? t('Not enough data') : (sp.trend>=0?'+':'') + sp.trend + '%'}</span></div>`).join('')}</div></div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Progression by Class')}</div></div>
      <div class="card-body">${classProgressions.map(cp => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hOpenGradesClass('${cp.cls.id}');hSetGradesTab('overview')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hOpenGradesClass('${cp.cls.id}');hSetGradesTab('overview')}"><span>${gdCommsEsc(cp.cls.name)}</span><span style="color:${cp.trend===null?'var(--muted)':cp.trend<0?'var(--red)':'var(--green)'}">${cp.trend===null ? t('Not enough data') : (cp.trend>=0?'+':'') + cp.trend + '%'}</span></div>`).join('')}</div></div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Historical Comparison')}</div></div>
      <div class="card-body">
        <div class="info-row"><span>${t('Before')} ${cutoff}</span><span>${previousAvg !== null ? previousAvg + '%' : t('No data')}</span></div>
        <div class="info-row"><span>${t('From')} ${cutoff}</span><span>${currentAvg !== null ? currentAvg + '%' : t('No data')}</span></div>
        ${previousAvg !== null && currentAvg !== null ? `<div style="font-size:11.5px;color:${currentAvg>=previousAvg?'var(--green)':'var(--red)'};margin-top:6px">${currentAvg>=previousAvg?'▲':'▼'} ${Math.abs(currentAvg-previousAvg)}% ${currentAvg>=previousAvg?t('improvement'):t('decline')}</div>` : ''}
      </div></div>`;
}

/* ══════════════════════════════════════════════════════
   HOMEWORK ANALYTICS
══════════════════════════════════════════════════════ */
function hHomeworkClassCompletionRate(classId) {
  const list = HEAD_DATA.homework.filter(h => h.classId === classId);
  if (!list.length) return null;
  let submitted = 0, total = 0;
  list.forEach(h => { const c = hHomeworkCounts(h); submitted += c.submitted + c.late; total += c.total; });
  return total ? Math.round((submitted / total) * 100) : null;
}
function hHomeworkSubjectCompletionRate(subject) {
  const list = HEAD_DATA.homework.filter(h => h.subject === subject);
  if (!list.length) return null;
  let submitted = 0, total = 0;
  list.forEach(h => { const c = hHomeworkCounts(h); submitted += c.submitted + c.late; total += c.total; });
  return total ? Math.round((submitted / total) * 100) : null;
}
function hStudentsWithMostMissingHomework() {
  return HEAD_DATA.students.map(s => {
    const missingCount = HEAD_DATA.homework.filter(h => hHomeworkStatus(h, s.id) === 'missing').length;
    return { student:s, count: missingCount };
  }).filter(x => x.count > 0).sort((a, b) => b.count - a.count).slice(0, 8);
}
function hHomeworkAnalyticsTab() {
  const allCounts = HEAD_DATA.homework.reduce((acc, h) => {
    const c = hHomeworkCounts(h);
    acc.submitted += c.submitted; acc.late += c.late; acc.missing += c.overdue; acc.pending += c.pending; acc.total += c.total;
    return acc;
  }, { submitted:0, late:0, missing:0, pending:0, total:0 });
  const completionRate = allCounts.total ? Math.round(((allCounts.submitted + allCounts.late) / allCounts.total) * 100) : null;
  const subjects = Array.from(new Set(HEAD_DATA.homework.map(h => h.subject)));
  const trendStudents = hStudentsWithMostMissingHomework();

  return `
    <div class="gd-stat-row">
      <div class="stat-card"><div class="stat-label">${t('Completion Rate')}</div><div class="stat-val">${completionRate !== null ? completionRate + '%' : '—'}</div><div class="stat-icon green">${aIcon('check-circle')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Submitted')}</div><div class="stat-val">${allCounts.submitted}</div><div class="stat-icon blue">${aIcon('inbox')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Late')}</div><div class="stat-val">${allCounts.late}</div><div class="stat-icon yellow">${aIcon('clock')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Missing')}</div><div class="stat-val">${allCounts.missing}</div><div class="stat-icon red">${aIcon('x-circle')}</div></div>
    </div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Completion Rate by Class')}</div></div>
      <div class="card-body">${HEAD_DATA.classes.map(c => { const rate = hHomeworkClassCompletionRate(c.id); return `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hSetHomeworkClassFilter('${c.id}');hSetHomeworkTab('overview')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hSetHomeworkClassFilter('${c.id}');hSetHomeworkTab('overview')}"><span>${gdCommsEsc(c.name)}</span><span style="color:var(--muted)">${rate !== null ? rate + '%' : t('No homework yet')}</span></div>`; }).join('')}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Completion Rate by Subject')}</div></div>
      <div class="card-body">${subjects.map(sub => { const rate = hHomeworkSubjectCompletionRate(sub); return `<div class="info-row"><span>${gdCommsEsc(t(sub))}</span><span style="color:var(--muted)">${rate !== null ? rate + '%' : '—'}</span></div>`; }).join('')}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Student Trends')}</div><span style="font-size:12px;color:var(--muted)">${t('Most missing homework')}</span></div>
      <div class="card-body">${trendStudents.length ? trendStudents.map(x => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hGoToStudentFromClass('${x.student.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hGoToStudentFromClass('${x.student.id}')}"><span>${gdCommsEsc(hStudentFullName(x.student))}</span><span style="color:var(--red)">${x.count} ${t('missing')}</span></div>`).join('') : `<div class="gd-empty-mini">${t('No students with missing homework.')}</div>`}</div></div>`;
}

/* ══════════════════════════════════════════════════════
   BEHAVIOR ANALYTICS
══════════════════════════════════════════════════════ */
const H_POSITIVE_BEHAVIOR_CATEGORIES = ['Positive Behavior', 'Excellent Participation'];
function hIsPositiveBehavior(category) { return H_POSITIVE_BEHAVIOR_CATEGORIES.includes(category); }
function hStudentBehaviorRecordsH(studentId) { return HEAD_DATA.behaviorRecords.filter(r => r.studentId === studentId); }
function hBehaviorView() {
  const tabs = [ { id:'overview', label:'Overview' }, { id:'advanced', label:'Advanced Analytics' } ];
  return `<div class="st-tabs">${tabs.map(tb => `<div class="st-tab gd-tab-hbeh${tb.id===hState.behavior.tab?' active':''}" data-tab="${tb.id}" onclick="hSetBehaviorTab('${tb.id}')">${t(tb.label)}</div>`).join('')}</div>
    <div id="h-behavior-content">${hBehaviorTabBody()}</div>`;
}
function hSetBehaviorTab(tabId) {
  hState.behavior.tab = tabId;
  document.querySelectorAll('.gd-tab-hbeh').forEach(el => el.classList.toggle('active', el.dataset.tab === tabId));
  const el = document.getElementById('h-behavior-content');
  if (el) el.innerHTML = hBehaviorTabBody();
}
function hBehaviorTabBody() {
  return hState.behavior.tab === 'advanced' ? hBehaviorAdvancedTab() : hBehaviorBody();
}
function hBehaviorBody() {
  const filterClassId = hState.behavior.filterClassId;
  const studentIds = filterClassId === 'all' ? HEAD_DATA.students.map(s => s.id) : hClassStudents(filterClassId).map(s => s.id);
  const records = HEAD_DATA.behaviorRecords.filter(r => studentIds.includes(r.studentId));
  const positive = records.filter(r => hIsPositiveBehavior(r.category));
  const negative = records.filter(r => !hIsPositiveBehavior(r.category));

  const categoryCounts = {};
  records.forEach(r => { categoryCounts[r.category] = (categoryCounts[r.category] || 0) + 1; });

  const byMonth = {};
  records.forEach(r => { const m = r.date.slice(0, 7); byMonth[m] = (byMonth[m] || 0) + 1; });

  const classComparison = HEAD_DATA.classes.map(c => {
    const ids = hClassStudents(c.id).map(s => s.id);
    const negCount = HEAD_DATA.behaviorRecords.filter(r => ids.includes(r.studentId) && !hIsPositiveBehavior(r.category)).length;
    return { cls:c, negCount };
  }).sort((a, b) => b.negCount - a.negCount);

  const perStudentNeg = {};
  negative.forEach(r => { perStudentNeg[r.studentId] = (perStudentNeg[r.studentId] || 0) + 1; });
  const studentComparison = Object.keys(perStudentNeg).map(id => ({ student: hGetStudent(id), count: perStudentNeg[id] })).filter(x => x.student).sort((a, b) => b.count - a.count);
  const repeated = studentComparison.filter(x => x.count >= 2);

  return `
    <div class="card"><div class="card-body">
      <select onchange="hSetBehaviorClassFilter(this.value)" style="background:var(--surface2);border:1px solid var(--border);border-radius:10px;color:var(--color-text);padding:9px 12px;font-size:13px">
        <option value="all" ${filterClassId==='all'?'selected':''}>${t('All Classes')}</option>
        ${HEAD_DATA.classes.map(c => `<option value="${c.id}" ${c.id===filterClassId?'selected':''}>${gdCommsEsc(c.name)}</option>`).join('')}
      </select>
    </div></div>
    <div class="gd-stat-row" style="margin-top:16px">
      <div class="stat-card"><div class="stat-label">${t('Positive Behavior')}</div><div class="stat-val">${positive.length}</div><div class="stat-icon green">${aIcon('star')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Negative Incidents')}</div><div class="stat-val">${negative.length}</div><div class="stat-icon red">${aIcon('alert-triangle')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Total Records')}</div><div class="stat-val">${records.length}</div><div class="stat-icon blue">${aIcon('clipboard')}</div></div>
    </div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('By Category')}</div></div>
      <div class="card-body">${Object.keys(categoryCounts).length ? Object.keys(categoryCounts).map(cat => `<div class="info-row"><span>${gdCommsEsc(t(cat))}</span><span style="color:var(--muted)">${categoryCounts[cat]}</span></div>`).join('') : `<div class="gd-empty-mini">${t('No behavior records for this selection.')}</div>`}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Incident Frequency by Month')}</div></div>
      <div class="card-body">${Object.keys(byMonth).length ? Object.keys(byMonth).sort().map(m => `<div class="info-row"><span>${m}</span><span style="color:var(--muted)">${byMonth[m]}</span></div>`).join('') : `<div class="gd-empty-mini">${t('No records to show a trend for.')}</div>`}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Class Comparison')}</div><span style="font-size:12px;color:var(--muted)">${t('Negative incidents')}</span></div>
      <div class="card-body">${classComparison.map(x => `<div class="info-row"><span>${gdCommsEsc(x.cls.name)}</span><span style="color:${x.negCount>0?'var(--red)':'var(--muted)'}">${x.negCount}</span></div>`).join('')}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Student Comparison')}</div><span style="font-size:12px;color:var(--muted)">${t('Most negative incidents')}</span></div>
      <div class="card-body">${studentComparison.length ? studentComparison.slice(0, 8).map(x => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hGoToStudentFromClass('${x.student.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hGoToStudentFromClass('${x.student.id}')}"><span>${gdCommsEsc(hStudentFullName(x.student))}</span><span style="color:var(--red)">${x.count}</span></div>`).join('') : `<div class="gd-empty-mini">${t('No negative incidents for this selection.')}</div>`}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Repeated Incidents')}</div><span style="font-size:12px;color:var(--muted)">${t('2 or more negative records')}</span></div>
      <div class="card-body">${repeated.length ? repeated.map(x => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hGoToStudentFromClass('${x.student.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hGoToStudentFromClass('${x.student.id}')}"><span>${gdCommsEsc(hStudentFullName(x.student))}</span><span style="color:var(--red)">${x.count} ${t('records')}</span></div>`).join('') : `<div class="gd-empty-mini">${t('No repeated incidents detected.')}</div>`}</div></div>`;
}
function hSetBehaviorClassFilter(v) {
  hState.behavior.filterClassId = v;
  const el = document.getElementById('h-behavior-content');
  if (el) el.innerHTML = hBehaviorBody();
}

/* ══════════════════════════════════════════════════════
   ADVANCED REPORT BUILDER
   Multi-class, multi-metric combined reports with saved configurations
   — building on the SAME real computed helpers already proven in Grades,
   Attendance, and Homework, rather than a second parallel implementation.
══════════════════════════════════════════════════════ */
const H_ADV_METRICS = [ ['grades','Average Grade'], ['attendance','Attendance Rate'], ['homework','Homework Completion'], ['behavior','Negative Behavior Incidents'] ];
function hAdvReportsBody() {
  const ar = hState.advReports;
  return ar.screen === 'preview' ? hAdvReportPreview() : hAdvReportForm();
}
function hRefreshAdvReports() { const el = document.getElementById('h-reports-content'); if (el) el.innerHTML = hAdvReportsBody(); }
function hAdvReportForm() {
  const ar = hState.advReports;
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Advanced Report Builder')}</div>${ar.savedConfigs.length ? `<div class="card-action" onclick="hShowSavedReportConfigs()">${t('Saved Configurations')} (${ar.savedConfigs.length})</div>` : ''}</div>
    <div class="card-body">
      <div style="font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Classes')}</div>
      ${HEAD_DATA.classes.map(c => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hToggleAdvReportClass('${c.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hToggleAdvReportClass('${c.id}')}"><span><input type="checkbox" ${ar.classIds.includes(c.id)?'checked':''} style="margin-right:8px;pointer-events:none">${gdCommsEsc(c.name)}</span></div>`).join('')}
      <div style="font-size:12.5px;font-weight:600;margin:14px 0 8px">${t('Metrics')}</div>
      ${H_ADV_METRICS.map(([id,label]) => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hToggleAdvReportMetric('${id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hToggleAdvReportMetric('${id}')}"><span><input type="checkbox" ${ar.metrics.includes(id)?'checked':''} style="margin-right:8px;pointer-events:none">${t(label)}</span></div>`).join('')}
      <div style="display:flex;gap:10px;margin-top:14px">
        <div class="st-field" style="flex:1"><label>${t('Start Date')} (${t('optional')})</label><input id="h-adv-start" type="date" value="${ar.startDate}"></div>
        <div class="st-field" style="flex:1"><label>${t('End Date')} (${t('optional')})</label><input id="h-adv-end" type="date" value="${ar.endDate}"></div>
      </div>
      <button class="st-btn" onclick="hGenerateAdvReport()">${t('Generate Report')}</button>
      ${ar.error ? `<div class="st-inline-msg err show" style="margin-top:12px">${ar.error}</div>` : ''}
    </div></div>`;
}
function hToggleAdvReportClass(classId) {
  const ar = hState.advReports;
  if (ar.classIds.includes(classId)) ar.classIds = ar.classIds.filter(id => id !== classId);
  else ar.classIds.push(classId);
  hRefreshAdvReports();
}
function hToggleAdvReportMetric(metricId) {
  const ar = hState.advReports;
  if (ar.metrics.includes(metricId)) ar.metrics = ar.metrics.filter(id => id !== metricId);
  else ar.metrics.push(metricId);
  hRefreshAdvReports();
}

function hGenerateAdvReport() {
  const ar = hState.advReports;
  const startEl = document.getElementById('h-adv-start');
  const endEl = document.getElementById('h-adv-end');
  ar.startDate = startEl ? startEl.value : '';
  ar.endDate = endEl ? endEl.value : '';

  if (!ar.classIds.length) { ar.error = t('Select at least one class.'); hRefreshAdvReports(); return; }
  if (!ar.metrics.length) { ar.error = t('Select at least one metric.'); hRefreshAdvReports(); return; }
  if (ar.startDate && ar.endDate && ar.startDate > ar.endDate) { ar.error = t('Start date must be before end date.'); hRefreshAdvReports(); return; }
  ar.error = '';
  ar.screen = 'preview';
  ar.generatedAt = tISODate(new Date(2026, 2, 11));
  hRefreshAdvReports();
}
function hAdvReportAttendanceDays() {
  const ar = hState.advReports;
  if (!ar.startDate || !ar.endDate) return H_ATTENDANCE_DAYS;
  return H_ATTENDANCE_DAYS.filter(d => d >= ar.startDate && d <= ar.endDate);
}
function hAdvReportMetricValue(metricId, classId) {
  if (metricId === 'grades') { const v = hClassAvgGrade(classId); return v !== null ? v + '/20' : '—'; }
  if (metricId === 'attendance') { const v = hAggregateAttendance(hClassStudents(classId).map(s => s.id), hAdvReportAttendanceDays()).rate; return v !== null ? v + '%' : '—'; }
  if (metricId === 'homework') { const v = hHomeworkClassCompletionRate(classId); return v !== null ? v + '%' : '—'; }
  if (metricId === 'behavior') { const ids = hClassStudents(classId).map(s => s.id); return HEAD_DATA.behaviorRecords.filter(r => ids.includes(r.studentId) && !hIsPositiveBehavior(r.category)).length; }
  return '—';
}
function hAdvReportPreview() {
  const ar = hState.advReports;
  const classes = ar.classIds.map(hGetClass).filter(Boolean);
  return `<div class="card">
    <div class="card-header">
      <div style="display:flex;align-items:center;gap:10px"><button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="hBackToAdvReportForm()">${t('← Back')}</button><div class="card-title">${t('Combined Report')}</div></div>
      <div style="display:flex;gap:8px">
        <button type="button" class="st-btn ghost sm" onclick="hSaveAdvReportConfig()">${t('Save Configuration')}</button>
        <button type="button" class="st-btn ghost sm" onclick="window.print()">${aIcon('printer')} ${t('Print')}</button>
      </div>
    </div>
    <div class="card-body">
      <div style="font-size:11.5px;color:var(--muted);margin-bottom:14px">${t('Generated')} ${ar.generatedAt}${ar.startDate && ar.endDate ? ` · ${ar.startDate} → ${ar.endDate}` : ''}</div>
      ${classes.map(c => `<div class="card" style="margin-bottom:10px;background:var(--surface2)"><div class="card-body">
        <div style="font-weight:600;font-size:13px;margin-bottom:8px">${gdCommsEsc(c.name)}</div>
        ${ar.metrics.map(m => `<div class="info-row"><span>${t(H_ADV_METRICS.find(x => x[0]===m)[1])}</span><span>${hAdvReportMetricValue(m, c.id)}</span></div>`).join('')}
      </div></div>`).join('')}
    </div></div>`;
}
function hBackToAdvReportForm() {
  hState.advReports.screen = 'form';
  hRefreshAdvReports();
}
function hSaveAdvReportConfig() {
  const ar = hState.advReports;
  ar.savedConfigs.push({ id:'arc' + Date.now(), classIds: ar.classIds.slice(), metrics: ar.metrics.slice(), startDate: ar.startDate, endDate: ar.endDate, savedAt: tISODate(new Date(2026, 2, 11)) });
  hShowToast(t('Report configuration saved.'));
}
function hShowSavedReportConfigs() {
  const ar = hState.advReports;
  const el = document.getElementById('h-reports-content');
  if (el) el.innerHTML = `<div class="card"><div class="card-header">
    <div style="display:flex;align-items:center;gap:10px"><button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="hRefreshAdvReports()">${t('← Back')}</button><div class="card-title">${t('Saved Configurations')}</div></div>
    </div>
    <div class="card-body">
      ${ar.savedConfigs.map(cfg => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hLoadAdvReportConfig('${cfg.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hLoadAdvReportConfig('${cfg.id}')}">
        <span>${cfg.classIds.length} ${t('classes')} · ${cfg.metrics.length} ${t('metrics')}</span><span style="color:var(--muted);font-size:12px">${cfg.savedAt}</span>
      </div>`).join('') || `<div class="gd-empty-mini">${t('No saved configurations yet.')}</div>`}
    </div></div>`;
}
function hLoadAdvReportConfig(configId) {
  const ar = hState.advReports;
  const cfg = ar.savedConfigs.find(c => c.id === configId);
  if (!cfg) return;
  ar.classIds = cfg.classIds.slice();
  ar.metrics = cfg.metrics.slice();
  ar.startDate = cfg.startDate;
  ar.endDate = cfg.endDate;
  ar.screen = 'preview';
  ar.generatedAt = tISODate(new Date(2026, 2, 11));
  hRefreshAdvReports();
  hShowToast(t('Configuration loaded.'));
}

/* ══════════════════════════════════════════════════════
   ADMISSIONS CENTER
══════════════════════════════════════════════════════ */
function hGetAdmission(id) { return HEAD_DATA.admissions.find(a => a.id === id) || null; }
function hAdmissionFullName(a) { return `${a.firstName} ${a.lastName}`; }
function hAdmissionsView() {
  const tabs = [ { id:'list', label:'Applications' }, { id:'analytics', label:'Advanced Analytics' } ];
  return `<div class="st-tabs">${tabs.map(tb => `<div class="st-tab gd-tab-hadm${tb.id===hState.admissions.tab?' active':''}" data-tab="${tb.id}" onclick="hSetAdmissionsTab('${tb.id}')">${t(tb.label)}</div>`).join('')}</div>
    <div id="h-admissions-content">${hAdmissionsTabBody()}</div>`;
}
function hSetAdmissionsTab(tabId) {
  hState.admissions.tab = tabId;
  document.querySelectorAll('.gd-tab-hadm').forEach(el => el.classList.toggle('active', el.dataset.tab === tabId));
  const el = document.getElementById('h-admissions-content');
  if (el) el.innerHTML = hAdmissionsTabBody();
}
function hAdmissionsTabBody() {
  return hState.admissions.tab === 'analytics' ? hAdmissionsAdvancedTab() : hAdmissionsBody();
}
function hAdmissionsBody() {
  const s = hState.admissions;
  if (s.screen === 'form') return hAdmissionFormScreen();
  if (s.screen === 'detail') { const a = hGetAdmission(s.appId); if (!a) { s.screen = 'list'; return hAdmissionsBody(); } return hAdmissionDetailScreen(a); }
  return hAdmissionListScreen();
}
function hRefreshAdmissions() { const el = document.getElementById('h-admissions-content'); if (el) el.innerHTML = hAdmissionsBody(); }
const H_ADMISSION_STATUS_META = { pending:{cls:'due',label:'Pending'}, 'under-review':{cls:'awaiting',label:'Under Review'}, accepted:{cls:'paid',label:'Accepted'}, rejected:{cls:'overdue',label:'Rejected'}, waitlisted:{cls:'resolved',label:'Waitlisted'} };
function hFilteredAdmissions() {
  const s = hState.admissions;
  let list = HEAD_DATA.admissions.slice();
  if (s.filterStatus !== 'all') list = list.filter(a => a.status === s.filterStatus);
  const q = s.search.trim().toLowerCase();
  if (q) list = list.filter(a => hAdmissionFullName(a).toLowerCase().includes(q));
  return list.sort((a, b) => b.submittedDate.localeCompare(a.submittedDate));
}
function hAdmissionListScreen() {
  const s = hState.admissions;
  const statuses = [['all','All'],['pending','Pending'],['under-review','Under Review'],['accepted','Accepted'],['waitlisted','Waitlisted'],['rejected','Rejected']];
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Admissions')}</div><button class="st-btn sm" onclick="hOpenAdmissionForm()">+ ${t('New Application')}</button></div>
    <div class="card-body">
      <input class="gd-comm-search-input" type="text" placeholder="${t('Search applicants...')}" value="${gdCommsEsc(s.search)}" oninput="hSetAdmissionSearch(this.value)">
      <div class="gd-comm-filter-row" style="margin-top:10px">${statuses.map(([id,label]) => `<div class="gd-comm-filter-chip${s.filterStatus===id?' active':''}" onclick="hSetAdmissionStatusFilter('${id}')">${t(label)}</div>`).join('')}</div>
    </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Applications')}</div></div>
      <div class="card-body" id="h-admission-list-results">${hAdmissionListResultsBlock()}</div></div>`;
}
function hAdmissionListResultsBlock() {
  const list = hFilteredAdmissions();
  if (!list.length) return `<div class="gd-empty-mini">${t('No applications match your search or filters.')}</div>`;
  return list.map(a => { const meta = H_ADMISSION_STATUS_META[a.status]; return `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hOpenAdmissionDetail('${a.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hOpenAdmissionDetail('${a.id}')}">
    <span>${gdCommsEsc(hAdmissionFullName(a))}<div style="font-size:11px;color:var(--muted)">${gdCommsEsc(t(a.appliedLevel))} · ${a.submittedDate}</div></span><span class="status-pill ${meta.cls}">${t(meta.label)}</span>
  </div>`; }).join('');
}
function hSetAdmissionSearch(v) { hState.admissions.search = v; const el = document.getElementById('h-admission-list-results'); if (el) el.innerHTML = hAdmissionListResultsBlock(); }
function hSetAdmissionStatusFilter(v) { hState.admissions.filterStatus = v; hRefreshAdmissions(); }

/* ── Admission Detail (status changes + notes + create-student integration) ── */
function hOpenAdmissionDetail(id) { hState.admissions.screen = 'detail'; hState.admissions.appId = id; hRefreshAdmissions(); }
function hBackToAdmissionList() { hState.admissions.screen = 'list'; hState.admissions.appId = null; hRefreshAdmissions(); }
function hAdmissionDetailScreen(a) {
  const meta = H_ADMISSION_STATUS_META[a.status];
  return `<div class="card"><div class="card-header">
    <div style="display:flex;align-items:center;gap:10px;min-width:0;flex:1"><button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="hBackToAdmissionList()">${t('← Back')}</button><div class="card-title" style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${gdCommsEsc(hAdmissionFullName(a))}</div></div>
  </div>
    <div class="card-body" id="h-admission-detail-body">${hAdmissionDetailBody(a, meta)}</div>
  </div>`;
}
function hAdmissionDetailBody(a, meta) {
  const statusActions = [['pending','Mark Pending'],['under-review','Mark Under Review'],['accepted','Accept'],['waitlisted','Waitlist'],['rejected','Reject']].filter(([id]) => id !== a.status);
  return `
    <div class="info-row"><span>${t('Status')}</span><span class="status-pill ${meta.cls}">${t(meta.label)}</span></div>
    <div class="info-row"><span>${t('Date of Birth')}</span><span>${a.dob}</span></div>
    <div class="info-row"><span>${t('Gender')}</span><span>${a.gender === 'M' ? t('Male') : t('Female')}</span></div>
    <div class="info-row"><span>${t('Applied For')}</span><span>${gdCommsEsc(t(a.appliedLevel))}</span></div>
    <div class="info-row"><span>${t('Source')}</span><span>${gdCommsEsc(t(a.source || 'Unknown'))}</span></div>
    <div class="info-row"><span>${t('Submitted')}</span><span>${a.submittedDate}</span></div>
    <div style="margin-top:14px;padding-top:14px;border-top:0.5px solid var(--separator)">
      <div style="font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Guardian Information')}</div>
      <div class="info-row"><span>${t('Name')}</span><span>${gdCommsEsc(a.guardianName)}</span></div>
      <div class="info-row"><span>${t('Email')}</span><span>${gdCommsEsc(a.guardianEmail)}</span></div>
      <div class="info-row"><span>${t('Phone')}</span><span>${gdCommsEsc(a.guardianPhone)}</span></div>
    </div>
    <div style="margin-top:14px;padding-top:14px;border-top:0.5px solid var(--separator)">
      <div style="font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Internal Notes')}</div>
      <textarea id="h-adm-notes" rows="3" placeholder="${t('Add internal notes about this application...')}">${gdCommsEsc(a.notes)}</textarea>
      <button type="button" class="st-btn ghost sm" style="margin-top:8px" onclick="hSaveAdmissionNotes('${a.id}')">${t('Save Notes')}</button>
    </div>
    <div style="margin-top:14px;padding-top:14px;border-top:0.5px solid var(--separator)">
      <div style="font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Change Status')}</div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        ${statusActions.map(([id, label]) => `<button type="button" class="st-btn ghost sm" onclick="hConfirmAdmissionStatusChange('${a.id}','${id}')">${t(label)}</button>`).join('')}
      </div>
      ${a.status === 'accepted' ? `<button type="button" class="st-btn sm" style="margin-top:10px" onclick="hCreateStudentFromAdmission('${a.id}')">${t('Create Student Record')} →</button>` : ''}
    </div>`;
}
function hRefreshAdmissionDetail() {
  const a = hGetAdmission(hState.admissions.appId);
  if (!a) return;
  const el = document.getElementById('h-admission-detail-body');
  if (el) el.innerHTML = hAdmissionDetailBody(a, H_ADMISSION_STATUS_META[a.status]);
}
function hSaveAdmissionNotes(id) {
  const a = hGetAdmission(id);
  const el = document.getElementById('h-adm-notes');
  if (!a || !el) return;
  a.notes = el.value.trim();
  hShowToast(t('Notes saved.'));
}
function hConfirmAdmissionStatusChange(id, newStatus) {
  const a = hGetAdmission(id);
  if (!a) return;
  const label = H_ADMISSION_STATUS_META[newStatus].label;
  stOpenModal(`<h3 style="margin-bottom:10px">${t('Change status to')} ${t(label)}?</h3>
    <p style="font-size:13px;color:var(--muted);margin-bottom:18px">${gdCommsEsc(hAdmissionFullName(a))} — ${t('this will update the application list and dashboard metrics.')}</p>
    <div style="display:flex;gap:10px">
      <button class="st-btn" onclick="hSetAdmissionStatus('${id}','${newStatus}');stCloseModal()">${t('Confirm')}</button>
      <button class="st-btn ghost" onclick="stCloseModal()">${t('Cancel')}</button>
    </div>`);
}
function hSetAdmissionStatus(id, newStatus) {
  const a = hGetAdmission(id);
  if (!a) return;
  a.status = newStatus;
  hRefreshAdmissionDetail();
  hShowToast(`${t('Status updated to')} ${t(H_ADMISSION_STATUS_META[newStatus].label)}.`);
}
function hCreateStudentFromAdmission(id) {
  const a = hGetAdmission(id);
  if (!a) return;
  hState.students.form = {
    mode:'create', id:null, firstName:a.firstName, lastName:a.lastName, studentId:'', dob:a.dob, gender:a.gender,
    classId: HEAD_DATA.classes.find(c => c.level === a.appliedLevel) ? HEAD_DATA.classes.find(c => c.level === a.appliedLevel).id : (HEAD_DATA.classes[0] ? HEAD_DATA.classes[0].id : ''),
    address:'', enrollmentDate: tISODate(new Date(2026, 2, 11)), guardianMode:'new', guardianId:null, guardianSearch:'',
    newGuardianName:a.guardianName, newGuardianEmail:a.guardianEmail, newGuardianPhone:a.guardianPhone,
  };
  hState.students.screen = 'form';
  hState.students.error = '';
  authrenGoTo('students');
  hShowToast(t('Application details pre-filled — finish creating the student record.'));
}

/* ── New Application form ── */
function hOpenAdmissionForm() {
  hState.admissions.form = { firstName:'', lastName:'', dob:'', gender:'M', appliedLevel: HEAD_DATA.classes[0] ? HEAD_DATA.classes[0].level : 'Grade 7', guardianName:'', guardianEmail:'', guardianPhone:'', source:'Website' };
  hState.admissions.screen = 'form';
  hState.admissions.error = '';
  hRefreshAdmissions();
}
function hCancelAdmissionForm() { hState.admissions.screen = 'list'; hState.admissions.form = null; hState.admissions.error = ''; hRefreshAdmissions(); }
function hAdmissionFormScreen() {
  const f = hState.admissions.form;
  const err = hState.admissions.error;
  const levels = Array.from(new Set(HEAD_DATA.classes.map(c => c.level)));
  return `<div class="card"><div class="card-header"><div class="card-title">${t('New Application')}</div></div>
    <div class="card-body">
      <div style="display:flex;gap:10px">
        <div class="st-field" style="flex:1"><label>${t('First Name')}</label><input id="h-adm-firstname" value="${gdCommsEsc(f.firstName)}"></div>
        <div class="st-field" style="flex:1"><label>${t('Last Name')}</label><input id="h-adm-lastname" value="${gdCommsEsc(f.lastName)}"></div>
      </div>
      <div style="display:flex;gap:10px">
        <div class="st-field" style="flex:1"><label>${t('Date of Birth')}</label><input id="h-adm-dob" type="date" value="${f.dob}"></div>
        <div class="st-field" style="flex:1"><label>${t('Gender')}</label><select id="h-adm-gender">
          <option value="M" ${f.gender==='M'?'selected':''}>${t('Male')}</option>
          <option value="F" ${f.gender==='F'?'selected':''}>${t('Female')}</option>
        </select></div>
      </div>
      <div class="st-field"><label>${t('Applying For')}</label><select id="h-adm-level">
        ${levels.map(l => `<option value="${l}" ${l===f.appliedLevel?'selected':''}>${gdCommsEsc(t(l))}</option>`).join('')}
      </select></div>
      <div class="st-field"><label>${t('Guardian Name')}</label><input id="h-adm-guardianname" value="${gdCommsEsc(f.guardianName)}"></div>
      <div class="st-field"><label>${t('Guardian Email')}</label><input id="h-adm-guardianemail" type="email" value="${gdCommsEsc(f.guardianEmail)}"></div>
      <div class="st-field"><label>${t('Guardian Phone')}</label><input id="h-adm-guardianphone" type="tel" value="${gdCommsEsc(f.guardianPhone)}"></div>
      <div class="st-field"><label>${t('How did they hear about us?')}</label><select id="h-adm-source">
        ${['Website','Referral','Walk-in','Social Media'].map(s => `<option value="${s}" ${s===f.source?'selected':''}>${t(s)}</option>`).join('')}
      </select></div>
      <div style="display:flex;gap:10px">
        <button class="st-btn" onclick="hSaveAdmission()" ${hState.admissions.saving?'disabled':''}>${hState.admissions.saving ? `<span class="gd-spinner"></span>${t('Saving...')}` : t('Submit Application')}</button>
        <button class="st-btn ghost" onclick="hCancelAdmissionForm()" ${hState.admissions.saving?'disabled':''}>${t('Cancel')}</button>
      </div>
      ${err ? `<div class="st-inline-msg err show" style="margin-top:12px">${err}</div>` : ''}
    </div></div>`;
}
function hSaveAdmission() {
  const f = hState.admissions.form;
  const firstName = (document.getElementById('h-adm-firstname').value || '').trim();
  const lastName = (document.getElementById('h-adm-lastname').value || '').trim();
  const dob = document.getElementById('h-adm-dob').value;
  const gender = document.getElementById('h-adm-gender').value;
  const appliedLevel = document.getElementById('h-adm-level').value;
  const guardianName = (document.getElementById('h-adm-guardianname').value || '').trim();
  const guardianEmail = (document.getElementById('h-adm-guardianemail').value || '').trim();
  const guardianPhone = (document.getElementById('h-adm-guardianphone').value || '').trim();
  const source = document.getElementById('h-adm-source').value;
  Object.assign(f, { firstName, lastName, dob, gender, appliedLevel, guardianName, guardianEmail, guardianPhone, source });

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  let err = '';
  if (!firstName) err = t("Applicant's first name is required.");
  else if (!lastName) err = t("Applicant's last name is required.");
  else if (!dob) err = t('Date of birth is required.');
  else if (!guardianName) err = t("Guardian's name is required.");
  else if (!guardianEmail || !emailRegex.test(guardianEmail)) err = t('Enter a valid guardian email.');
  else if (!guardianPhone) err = t("Guardian's phone number is required.");

  hState.admissions.error = err;
  if (err) { hRefreshAdmissions(); return; }

  hState.admissions.saving = true;
  hRefreshAdmissions();
  setTimeout(() => {
    const newApp = { id:'had' + Date.now(), firstName, lastName, dob, gender, appliedLevel, guardianName, guardianEmail, guardianPhone, submittedDate: tISODate(new Date(2026, 2, 11)), status:'pending', notes:'', source };
    HEAD_DATA.admissions.push(newApp);
    hState.admissions.saving = false;
    hState.admissions.form = null;
    hState.admissions.screen = 'detail';
    hState.admissions.appId = newApp.id;
    hRefreshAdmissions();
    hShowToast(t('Application submitted successfully.'));
  }, 700);
}

/* ══════════════════════════════════════════════════════
   ORIENTATION CENTER
══════════════════════════════════════════════════════ */
function hGetOrientation(id) { return HEAD_DATA.orientations.find(o => o.id === id) || null; }
function hOrientationParticipantName(id) { const a = hGetAdmission(id); return a ? hAdmissionFullName(a) : t('Unknown'); }
function hOrientationView() {
  const tabs = [ { id:'list', label:'Sessions' }, { id:'analytics', label:'Advanced Analytics' } ];
  return `<div class="st-tabs">${tabs.map(tb => `<div class="st-tab gd-tab-hori${tb.id===hState.orientation.tab?' active':''}" data-tab="${tb.id}" onclick="hSetOrientationTab('${tb.id}')">${t(tb.label)}</div>`).join('')}</div>
    <div id="h-orientation-content">${hOrientationTabBody()}</div>`;
}
function hSetOrientationTab(tabId) {
  hState.orientation.tab = tabId;
  document.querySelectorAll('.gd-tab-hori').forEach(el => el.classList.toggle('active', el.dataset.tab === tabId));
  const el = document.getElementById('h-orientation-content');
  if (el) el.innerHTML = hOrientationTabBody();
}
function hOrientationTabBody() {
  return hState.orientation.tab === 'analytics' ? hOrientationAdvancedTab() : hOrientationBody();
}
function hOrientationBody() {
  const s = hState.orientation;
  if (s.screen === 'form') return hOrientationFormScreen();
  if (s.screen === 'detail') { const o = hGetOrientation(s.orId); if (!o) { s.screen = 'list'; return hOrientationBody(); } return hOrientationDetailScreen(o); }
  return hOrientationListScreen();
}
function hRefreshOrientation() { const el = document.getElementById('h-orientation-content'); if (el) el.innerHTML = hOrientationBody(); }
const H_ORIENTATION_STATUS_META = { scheduled:{cls:'due',label:'Scheduled'}, completed:{cls:'paid',label:'Completed'}, cancelled:{cls:'overdue',label:'Cancelled'} };
function hOrientationListScreen() {
  const sorted = HEAD_DATA.orientations.slice().sort((a, b) => b.date.localeCompare(a.date));
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Orientation Sessions')}</div><button class="st-btn sm" onclick="hOpenOrientationForm()">+ ${t('Create Orientation Event')}</button></div>
    <div class="card-body">
      ${sorted.length ? sorted.map(o => { const meta = H_ORIENTATION_STATUS_META[o.status]; return `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hOpenOrientationDetail('${o.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hOpenOrientationDetail('${o.id}')}">
        <span>${gdCommsEsc(o.title)}<div style="font-size:11px;color:var(--muted)">${o.date} · ${o.time} · ${gdCommsEsc(o.location)}</div></span><span class="status-pill ${meta.cls}">${t(meta.label)}</span>
      </div>`; }).join('') : `<div class="gd-empty-mini">${t('No orientation sessions scheduled yet.')}</div>`}
    </div></div>`;
}

/* ── Orientation Detail (participants + attendance tracking + status) ── */
function hOpenOrientationDetail(id) { hState.orientation.screen = 'detail'; hState.orientation.orId = id; hState.orientation.addParticipantSearch = ''; hRefreshOrientation(); }
function hBackToOrientationList() { hState.orientation.screen = 'list'; hState.orientation.orId = null; hRefreshOrientation(); }
function hOrientationDetailScreen(o) {
  return `<div class="card"><div class="card-header">
    <div style="display:flex;align-items:center;gap:10px;min-width:0;flex:1"><button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="hBackToOrientationList()">${t('← Back')}</button><div class="card-title" style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${gdCommsEsc(o.title)}</div></div>
    <button type="button" class="st-btn ghost sm" onclick="hOpenOrientationForm('${o.id}')">${t('Edit')}</button>
  </div>
    <div class="card-body" id="h-orientation-detail-body">${hOrientationDetailBody(o)}</div>
  </div>`;
}
function hOrientationDetailBody(o) {
  const meta = H_ORIENTATION_STATUS_META[o.status];
  const eligible = HEAD_DATA.admissions.filter(a => !o.participantIds.includes(a.id));
  const q = hState.orientation.addParticipantSearch.trim().toLowerCase();
  const results = q ? eligible.filter(a => hAdmissionFullName(a).toLowerCase().includes(q)) : [];
  return `
    <div class="info-row"><span>${t('Status')}</span><span class="status-pill ${meta.cls}">${t(meta.label)}</span></div>
    <div class="info-row"><span>${t('Date & Time')}</span><span>${o.date} · ${o.time}</span></div>
    <div class="info-row"><span>${t('Location')}</span><span>${gdCommsEsc(o.location)}</span></div>
    ${o.instructions ? `<div style="margin-top:10px;font-size:13px;color:var(--muted2);line-height:1.5">${gdCommsEsc(o.instructions)}</div>` : ''}
    <div style="margin-top:14px;padding-top:14px;border-top:0.5px solid var(--separator)">
      <div style="font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Participants')}</div>
      ${o.participantIds.length ? o.participantIds.map(id => `<div class="info-row" style="align-items:center">
        <span style="cursor:pointer" role="button" tabindex="0" onclick="hOpenAdmissionDetail('${id}');authrenGoTo('admissions')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hOpenAdmissionDetail('${id}');authrenGoTo('admissions')}">${gdCommsEsc(hOrientationParticipantName(id))}</span>
        <span style="display:flex;gap:8px;align-items:center">
          <label style="display:flex;align-items:center;gap:6px;font-size:11.5px;color:var(--muted)"><input type="checkbox" ${o.attended[id]?'checked':''} onchange="hToggleOrientationAttendance('${o.id}','${id}')"> ${t('Attended')}</label>
          <button type="button" class="st-btn ghost sm" onclick="hRemoveOrientationParticipant('${o.id}','${id}')">${t('Remove')}</button>
        </span>
      </div>`).join('') : `<div class="gd-empty-mini">${t('No participants assigned yet.')}</div>`}
      <div style="margin-top:10px">
        <input class="gd-comm-search-input" type="text" placeholder="${t('Search applicants to add...')}" value="${gdCommsEsc(hState.orientation.addParticipantSearch)}" oninput="hSetOrientationAddSearch(this.value)">
        <div id="h-or-add-results">${results.length ? results.map(a => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hAddOrientationParticipant('${o.id}','${a.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hAddOrientationParticipant('${o.id}','${a.id}')}">
          <span>${gdCommsEsc(hAdmissionFullName(a))}</span><span class="card-action">${t('Add')}</span>
        </div>`).join('') : (q ? `<div class="gd-empty-mini" style="text-align:left;padding:8px 0 0">${t('No applicants match your search.')}</div>` : '')}</div>
      </div>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:14px">
      ${o.status !== 'completed' ? `<button type="button" class="st-btn ghost sm" onclick="hSetOrientationStatus('${o.id}','completed')">${t('Mark Completed')}</button>` : ''}
      ${o.status !== 'cancelled' ? `<button type="button" class="st-btn ghost sm" style="color:var(--red)" onclick="hSetOrientationStatus('${o.id}','cancelled')">${t('Cancel Session')}</button>` : ''}
      ${o.status !== 'scheduled' ? `<button type="button" class="st-btn ghost sm" onclick="hSetOrientationStatus('${o.id}','scheduled')">${t('Reopen')}</button>` : ''}
    </div>`;
}
function hRefreshOrientationDetail() { const o = hGetOrientation(hState.orientation.orId); if (!o) return; const el = document.getElementById('h-orientation-detail-body'); if (el) el.innerHTML = hOrientationDetailBody(o); }
function hSetOrientationAddSearch(v) { hState.orientation.addParticipantSearch = v; hRefreshOrientationDetail(); }
function hAddOrientationParticipant(orId, admissionId) {
  const o = hGetOrientation(orId);
  if (!o || o.participantIds.includes(admissionId)) return;
  o.participantIds.push(admissionId);
  hState.orientation.addParticipantSearch = '';
  hRefreshOrientationDetail();
  hShowToast(t('Participant added.'));
}
function hRemoveOrientationParticipant(orId, admissionId) {
  const o = hGetOrientation(orId);
  if (!o) return;
  o.participantIds = o.participantIds.filter(id => id !== admissionId);
  delete o.attended[admissionId];
  hRefreshOrientationDetail();
  hShowToast(t('Participant removed.'));
}
function hToggleOrientationAttendance(orId, admissionId) {
  const o = hGetOrientation(orId);
  if (!o) return;
  o.attended[admissionId] = !o.attended[admissionId];
  hShowToast(o.attended[admissionId] ? t('Marked as attended.') : t('Attendance unmarked.'));
}
function hSetOrientationStatus(orId, status) {
  const o = hGetOrientation(orId);
  if (!o) return;
  o.status = status;
  hRefreshOrientationDetail();
  hShowToast(`${t('Status updated to')} ${t(H_ORIENTATION_STATUS_META[status].label)}.`);
}

/* ── Create / Edit Orientation form ── */
function hOpenOrientationForm(id) {
  if (id) {
    const o = hGetOrientation(id);
    if (!o) return;
    hState.orientation.form = { mode:'edit', id:o.id, title:o.title, date:o.date, time:o.time, location:o.location, instructions:o.instructions };
  } else {
    hState.orientation.form = { mode:'create', id:null, title:'', date:'', time:'', location:'', instructions:'' };
  }
  hState.orientation.screen = 'form';
  hState.orientation.error = '';
  hRefreshOrientation();
}
function hCancelOrientationForm() {
  const wasEdit = hState.orientation.form && hState.orientation.form.mode === 'edit';
  const editedId = hState.orientation.form ? hState.orientation.form.id : null;
  hState.orientation.form = null;
  hState.orientation.error = '';
  if (wasEdit) { hState.orientation.screen = 'detail'; hState.orientation.orId = editedId; } else { hState.orientation.screen = 'list'; }
  hRefreshOrientation();
}
function hOrientationFormScreen() {
  const f = hState.orientation.form;
  const err = hState.orientation.error;
  return `<div class="card"><div class="card-header"><div class="card-title">${f.mode==='edit'?t('Edit Orientation Event'):t('Create Orientation Event')}</div></div>
    <div class="card-body">
      <div class="st-field"><label>${t('Title')}</label><input id="h-or-title" value="${gdCommsEsc(f.title)}"></div>
      <div style="display:flex;gap:10px">
        <div class="st-field" style="flex:1"><label>${t('Date')}</label><input id="h-or-date" type="date" value="${f.date}"></div>
        <div class="st-field" style="flex:1"><label>${t('Time')}</label><input id="h-or-time" type="time" value="${f.time}"></div>
      </div>
      <div class="st-field"><label>${t('Location')}</label><input id="h-or-location" value="${gdCommsEsc(f.location)}"></div>
      <div class="st-field"><label>${t('Instructions')}</label><textarea id="h-or-instructions" rows="3">${gdCommsEsc(f.instructions)}</textarea></div>
      <div style="display:flex;gap:10px">
        <button class="st-btn" onclick="hSaveOrientation()">${f.mode==='edit'?t('Save Changes'):t('Create Event')}</button>
        <button class="st-btn ghost" onclick="hCancelOrientationForm()">${t('Cancel')}</button>
      </div>
      ${err ? `<div class="st-inline-msg err show" style="margin-top:12px">${err}</div>` : ''}
      ${f.mode === 'create' ? `<div style="font-size:11.5px;color:var(--muted);margin-top:12px">${t('You can assign participants from the event detail page after creating it.')}</div>` : ''}
    </div></div>`;
}
function hSaveOrientation() {
  const f = hState.orientation.form;
  const title = (document.getElementById('h-or-title').value || '').trim();
  const date = document.getElementById('h-or-date').value;
  const time = document.getElementById('h-or-time').value;
  const location = (document.getElementById('h-or-location').value || '').trim();
  const instructions = (document.getElementById('h-or-instructions').value || '').trim();
  Object.assign(f, { title, date, time, location, instructions });

  let err = '';
  if (!title) err = t('Title is required.');
  else if (!date) err = t('Select a date.');
  else if (!time) err = t('Select a time.');
  else if (!location) err = t('Location is required.');

  hState.orientation.error = err;
  if (err) { hRefreshOrientation(); return; }

  if (f.mode === 'edit') {
    const o = hGetOrientation(f.id);
    Object.assign(o, { title, date, time, location, instructions });
    hState.orientation.screen = 'detail';
    hState.orientation.orId = o.id;
    hShowToast(t('Orientation event updated successfully.'));
  } else {
    const newOr = { id:'hor' + Date.now(), title, date, time, location, instructions, status:'scheduled', participantType:'admissions', participantIds:[], attended:{} };
    HEAD_DATA.orientations.push(newOr);
    hState.orientation.screen = 'detail';
    hState.orientation.orId = newOr.id;
    hShowToast(t('Orientation event created successfully.'));
  }
  hState.orientation.form = null;
  hRefreshOrientation();
}

/* ══════════════════════════════════════════════════════
   ANONYMOUS RECLAMATION SYSTEM
   The interface makes it explicit, wherever a reclamation is shown, that
   no submitter identity is collected or displayed — only a reference ID.
══════════════════════════════════════════════════════ */
const H_RECLAMATION_CATEGORIES = ['Facilities', 'Teaching Quality', 'Cafeteria', 'Safety', 'Bullying/Conduct', 'Administrative', 'Other'];
const H_RC_STATUS_META = { new:{cls:'due',label:'New'}, 'in-review':{cls:'awaiting',label:'In Review'}, resolved:{cls:'paid',label:'Resolved'} };
const H_RC_PRIORITY_META = { low:{cls:'resolved',label:'Low'}, medium:{cls:'awaiting',label:'Medium'}, high:{cls:'overdue',label:'High'} };
function hGetReclamation(id) { return HEAD_DATA.reclamations.find(r => r.id === id) || null; }
function hAnonymityBanner() {
  return `<div style="background:rgba(203,213,225,0.1);border:1px solid rgba(203,213,225,0.3);border-radius:10px;padding:10px 12px;font-size:11.5px;color:var(--muted2);margin-bottom:14px">${aIcon('eye-off')} ${t('This system is fully anonymous. No submitter identity is collected or displayed — only an anonymous reference ID.')}</div>`;
}
function hReclamationsView() {
  return `<div id="h-reclamations-content">${hReclamationsBody()}</div>`;
}
function hReclamationsBody() {
  const s = hState.reclamations;
  if (s.screen === 'form') return hReclamationFormScreen();
  if (s.screen === 'detail') { const r = hGetReclamation(s.rcId); if (!r) { s.screen = 'list'; return hReclamationsBody(); } return hReclamationDetailScreen(r); }
  return hReclamationListScreen();
}
function hRefreshReclamations() { const el = document.getElementById('h-reclamations-content'); if (el) el.innerHTML = hReclamationsBody(); }
function hFilteredReclamations() {
  const s = hState.reclamations;
  let list = HEAD_DATA.reclamations.slice();
  if (s.filterStatus !== 'all') list = list.filter(r => r.status === s.filterStatus);
  if (s.filterPriority !== 'all') list = list.filter(r => r.priority === s.filterPriority);
  return list.sort((a, b) => b.submittedDate.localeCompare(a.submittedDate));
}
function hReclamationListScreen() {
  const s = hState.reclamations;
  const statuses = [['all','All'],['new','New'],['in-review','In Review'],['resolved','Resolved']];
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Reclamations')}</div><button class="st-btn sm" onclick="hOpenReclamationForm()">+ ${t('Submit New')}</button></div>
    <div class="card-body">
      ${hAnonymityBanner()}
      <div class="gd-comm-filter-row">${statuses.map(([id,label]) => `<div class="gd-comm-filter-chip${s.filterStatus===id?' active':''}" onclick="hSetReclamationStatusFilter('${id}')">${t(label)}</div>`).join('')}</div>
      <select onchange="hSetReclamationPriorityFilter(this.value)" style="margin-top:10px;background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
        <option value="all" ${s.filterPriority==='all'?'selected':''}>${t('All Priorities')}</option>
        <option value="high" ${s.filterPriority==='high'?'selected':''}>${t('High')}</option>
        <option value="medium" ${s.filterPriority==='medium'?'selected':''}>${t('Medium')}</option>
        <option value="low" ${s.filterPriority==='low'?'selected':''}>${t('Low')}</option>
      </select>
    </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Submissions')}</div></div>
      <div class="card-body" id="h-rc-list-results">${hReclamationListResultsBlock()}</div></div>`;
}
function hReclamationListResultsBlock() {
  const list = hFilteredReclamations();
  if (!list.length) return `<div class="gd-empty-mini">${t('No reclamations match your filters.')}</div>`;
  return list.map(r => { const sm = H_RC_STATUS_META[r.status]; const pm = H_RC_PRIORITY_META[r.priority]; return `<div class="info-row" style="cursor:pointer;align-items:flex-start" role="button" tabindex="0" onclick="hOpenReclamationDetail('${r.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hOpenReclamationDetail('${r.id}')}">
    <span>${gdCommsEsc(r.subject)}<div style="font-size:11px;color:var(--muted);margin-top:2px">${gdCommsEsc(r.referenceId)} · ${gdCommsEsc(t(r.category))} · ${r.submittedDate}</div></span>
    <span style="text-align:right"><span class="status-pill ${sm.cls}">${t(sm.label)}</span><div style="margin-top:4px"><span class="status-pill ${pm.cls}">${t(pm.label)}</span></div></span>
  </div>`; }).join('');
}
function hSetReclamationStatusFilter(v) { hState.reclamations.filterStatus = v; hRefreshReclamations(); }
function hSetReclamationPriorityFilter(v) { hState.reclamations.filterPriority = v; const el = document.getElementById('h-rc-list-results'); if (el) el.innerHTML = hReclamationListResultsBlock(); }

/* ── Reclamation Detail (status/priority change + internal notes) ── */
function hOpenReclamationDetail(id) { hState.reclamations.screen = 'detail'; hState.reclamations.rcId = id; hRefreshReclamations(); }
function hBackToReclamationList() { hState.reclamations.screen = 'list'; hState.reclamations.rcId = null; hRefreshReclamations(); }
function hReclamationDetailScreen(r) {
  return `<div class="card"><div class="card-header">
    <div style="display:flex;align-items:center;gap:10px;min-width:0;flex:1"><button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="hBackToReclamationList()">${t('← Back')}</button><div class="card-title" style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${gdCommsEsc(r.referenceId)}</div></div>
  </div>
    <div class="card-body" id="h-rc-detail-body">${hReclamationDetailBody(r)}</div>
  </div>`;
}
function hReclamationDetailBody(r) {
  const sm = H_RC_STATUS_META[r.status];
  const pm = H_RC_PRIORITY_META[r.priority];
  return `
    ${hAnonymityBanner()}
    <div class="info-row"><span>${t('Category')}</span><span>${gdCommsEsc(t(r.category))}</span></div>
    <div class="info-row"><span>${t('Submitted')}</span><span>${r.submittedDate}</span></div>
    <div class="info-row"><span>${t('Status')}</span><span class="status-pill ${sm.cls}">${t(sm.label)}</span></div>
    <div class="info-row"><span>${t('Priority')}</span><span class="status-pill ${pm.cls}">${t(pm.label)}</span></div>
    <div style="margin-top:14px;padding-top:14px;border-top:0.5px solid var(--separator)">
      <div style="font-weight:700;font-size:14px;margin-bottom:6px">${gdCommsEsc(r.subject)}</div>
      <div style="font-size:13px;line-height:1.6;color:var(--muted2)">${gdCommsEsc(r.description)}</div>
    </div>
    <div style="margin-top:14px;padding-top:14px;border-top:0.5px solid var(--separator)">
      <div style="font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Change Status')}</div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        ${['new','in-review','resolved'].filter(id => id !== r.status).map(id => `<button type="button" class="st-btn ghost sm" onclick="hSetReclamationStatus('${r.id}','${id}')">${t('Mark')} ${t(H_RC_STATUS_META[id].label)}</button>`).join('')}
      </div>
      <div style="font-size:12.5px;font-weight:600;margin:12px 0 8px">${t('Change Priority')}</div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        ${['low','medium','high'].filter(id => id !== r.priority).map(id => `<button type="button" class="st-btn ghost sm" onclick="hSetReclamationPriority('${r.id}','${id}')">${t(H_RC_PRIORITY_META[id].label)}</button>`).join('')}
      </div>
    </div>
    <div style="margin-top:14px;padding-top:14px;border-top:0.5px solid var(--separator)">
      <div style="font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Internal Notes')}</div>
      <textarea id="h-rc-notes" rows="3" placeholder="${t('Add internal notes (not visible to the submitter)...')}">${gdCommsEsc(r.internalNotes)}</textarea>
      <button type="button" class="st-btn ghost sm" style="margin-top:8px" onclick="hSaveReclamationNotes('${r.id}')">${t('Save Notes')}</button>
    </div>`;
}
function hRefreshReclamationDetail() { const r = hGetReclamation(hState.reclamations.rcId); if (!r) return; const el = document.getElementById('h-rc-detail-body'); if (el) el.innerHTML = hReclamationDetailBody(r); }
function hSetReclamationStatus(id, status) {
  const r = hGetReclamation(id);
  if (!r) return;
  r.status = status;
  hRefreshReclamationDetail();
  hShowToast(`${t('Status updated to')} ${t(H_RC_STATUS_META[status].label)}.`);
}
function hSetReclamationPriority(id, priority) {
  const r = hGetReclamation(id);
  if (!r) return;
  r.priority = priority;
  hRefreshReclamationDetail();
  hShowToast(`${t('Priority updated to')} ${t(H_RC_PRIORITY_META[priority].label)}.`);
}
function hSaveReclamationNotes(id) {
  const r = hGetReclamation(id);
  const el = document.getElementById('h-rc-notes');
  if (!r || !el) return;
  r.internalNotes = el.value.trim();
  hShowToast(t('Notes saved.'));
}

/* ── Submit New (anonymous) ── */
function hOpenReclamationForm() {
  hState.reclamations.form = { category: H_RECLAMATION_CATEGORIES[0], subject:'', description:'', priority:'medium' };
  hState.reclamations.screen = 'form';
  hState.reclamations.error = '';
  hRefreshReclamations();
}
function hCancelReclamationForm() { hState.reclamations.screen = 'list'; hState.reclamations.form = null; hState.reclamations.error = ''; hRefreshReclamations(); }
function hReclamationFormScreen() {
  const f = hState.reclamations.form;
  const err = hState.reclamations.error;
  if (f.submittedReference) {
    return `<div class="card"><div class="card-body" style="text-align:center;padding:30px 20px">
      <div style="font-size:34px;margin-bottom:10px">${aIcon('check-circle')}</div>
      <div style="font-weight:700;font-size:16px;margin-bottom:8px">${t('Submission Received')}</div>
      <div style="font-size:12.5px;color:var(--muted);margin-bottom:14px">${t('Your anonymous reference ID')}:</div>
      <div style="font-family:monospace;font-size:18px;font-weight:700;color:var(--accent);margin-bottom:18px">${gdCommsEsc(f.submittedReference)}</div>
      <button class="st-btn" onclick="hCancelReclamationForm()">${t('Done')}</button>
    </div></div>`;
  }
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Submit a Reclamation')}</div></div>
    <div class="card-body">
      ${hAnonymityBanner()}
      <div class="st-field"><label>${t('Category')}</label><select id="h-rc-category">
        ${H_RECLAMATION_CATEGORIES.map(c => `<option value="${c}" ${c===f.category?'selected':''}>${t(c)}</option>`).join('')}
      </select></div>
      <div class="st-field"><label>${t('Subject')}</label><input id="h-rc-subject" value="${gdCommsEsc(f.subject)}"></div>
      <div class="st-field"><label>${t('Description')}</label><textarea id="h-rc-description" rows="4">${gdCommsEsc(f.description)}</textarea></div>
      <div class="st-field"><label>${t('Priority')}</label><select id="h-rc-priority">
        <option value="low" ${f.priority==='low'?'selected':''}>${t('Low')}</option>
        <option value="medium" ${f.priority==='medium'?'selected':''}>${t('Medium')}</option>
        <option value="high" ${f.priority==='high'?'selected':''}>${t('High')}</option>
      </select></div>
      <div style="display:flex;gap:10px">
        <button class="st-btn" onclick="hSubmitReclamation()" ${hState.reclamations.saving?'disabled':''}>${hState.reclamations.saving ? `<span class="gd-spinner"></span>${t('Submitting...')}` : t('Submit Anonymously')}</button>
        <button class="st-btn ghost" onclick="hCancelReclamationForm()" ${hState.reclamations.saving?'disabled':''}>${t('Cancel')}</button>
      </div>
      ${err ? `<div class="st-inline-msg err show" style="margin-top:12px">${err}</div>` : ''}
    </div></div>`;
}
function hSubmitReclamation() {
  const f = hState.reclamations.form;
  const category = document.getElementById('h-rc-category').value;
  const subject = (document.getElementById('h-rc-subject').value || '').trim();
  const description = (document.getElementById('h-rc-description').value || '').trim();
  const priority = document.getElementById('h-rc-priority').value;
  Object.assign(f, { category, subject, description, priority });

  let err = '';
  if (!subject) err = t('Subject is required.');
  else if (!description) err = t('Description is required.');

  hState.reclamations.error = err;
  if (err) { hRefreshReclamations(); return; }

  hState.reclamations.saving = true;
  hRefreshReclamations();
  setTimeout(() => {
    const referenceId = 'RC-' + String(Math.floor(100000 + Math.random() * 899999));
    const newRc = { id:'hrc' + Date.now(), referenceId, category, subject, description, priority, status:'new', submittedDate: tISODate(new Date(2026, 2, 11)), internalNotes:'' };
    HEAD_DATA.reclamations.push(newRc);
    hState.reclamations.saving = false;
    f.submittedReference = referenceId;
    hRefreshReclamations();
  }, 700);
}

/* ══════════════════════════════════════════════════════
   ADVANCED COMMUNICATION — Drafts, Scheduling, Analytics
══════════════════════════════════════════════════════ */
function hToggleScheduleMode(checked) {
  const c = hState.comms.compose;
  c.subject = (document.getElementById('h-comp-subject').value || '');
  c.message = (document.getElementById('h-comp-message').value || '');
  c.scheduleMode = checked;
  hRefreshComms();
}
function hReadComposeFields() {
  const c = hState.comms.compose;
  c.subject = (document.getElementById('h-comp-subject').value || '').trim();
  c.message = (document.getElementById('h-comp-message').value || '').trim();
  if (c.audience === 'class') { const sel = document.getElementById('h-comp-class'); if (sel) c.audienceClassId = sel.value; }
}
function hSaveAnnouncementDraft() {
  const c = hState.comms.compose;
  hReadComposeFields();
  if (!c.subject && !c.message) { hState.comms.error = t('Enter a subject or message before saving a draft.'); hRefreshComms(); return; }
  hState.comms.error = '';
  const draft = {
    id:'han' + Date.now(), subject:c.subject, message:c.message, audience:c.audience,
    audienceClassId: c.audience === 'class' ? c.audienceClassId : null,
    sentAt: tISODate(new Date(2026, 2, 11)) + 'T00:00:00', sentBy: HEAD_DATA.adminProfile.name, status:'draft',
  };
  HEAD_DATA.announcements.unshift(draft);
  hState.comms.screen = 'list';
  hState.comms.tab = 'drafts';
  document.querySelectorAll('.gd-tab-hcom').forEach(el => el.classList.toggle('active', el.dataset.tab === 'drafts'));
  const draftEl = document.getElementById('h-comms-content');
  if (draftEl) draftEl.innerHTML = hCommsTabBody();
  hShowToast(t('Draft saved.'));
}
function hScheduleAnnouncement() {
  const c = hState.comms.compose;
  hReadComposeFields();
  const dateEl = document.getElementById('h-comp-sched-date');
  const timeEl = document.getElementById('h-comp-sched-time');
  const scheduledDate = dateEl ? dateEl.value : '';
  const scheduledTime = timeEl ? timeEl.value : '';

  let err = '';
  if (!c.subject) err = t('Subject is required.');
  else if (!c.message) err = t('Message is required.');
  else if (c.audience === 'class' && !c.audienceClassId) err = t('Select a class.');
  else if (!scheduledDate || !scheduledTime) err = t('Select a date and time to schedule for.');
  else if (`${scheduledDate}T${scheduledTime}` <= '2026-03-11T12:00') err = t('Scheduled time must be in the future.');

  hState.comms.error = err;
  if (err) { hRefreshComms(); return; }

  const scheduled = {
    id:'han' + Date.now(), subject:c.subject, message:c.message, audience:c.audience,
    audienceClassId: c.audience === 'class' ? c.audienceClassId : null,
    sentAt: `${scheduledDate}T${scheduledTime}:00`, sentBy: HEAD_DATA.adminProfile.name, status:'scheduled',
  };
  HEAD_DATA.announcements.unshift(scheduled);
  hState.comms.screen = 'list';
  hState.comms.tab = 'drafts';
  document.querySelectorAll('.gd-tab-hcom').forEach(el => el.classList.toggle('active', el.dataset.tab === 'drafts'));
  const schedEl = document.getElementById('h-comms-content');
  if (schedEl) schedEl.innerHTML = hCommsTabBody();
  hShowToast(t('Announcement scheduled successfully.'));
}

/* ── Drafts & Scheduled tab ── */
function hCommsDraftsTab() {
  const drafts = HEAD_DATA.announcements.filter(a => a.status === 'draft').sort((a, b) => b.sentAt.localeCompare(a.sentAt));
  const scheduled = HEAD_DATA.announcements.filter(a => a.status === 'scheduled').sort((a, b) => a.sentAt.localeCompare(b.sentAt));
  return `
    <div class="card"><div class="card-header"><div class="card-title">${t('Scheduled Messages')}</div></div>
      <div class="card-body">${scheduled.length ? scheduled.map(a => `<div class="card" style="margin-bottom:10px;background:var(--surface2)"><div class="card-body">
        <div style="font-weight:600;font-size:13px">${gdCommsEsc(a.subject)}</div>
        <div style="font-size:11px;color:var(--muted);margin:4px 0 8px">${hAudienceLabel(a)} · ${t('Scheduled for')} ${a.sentAt.slice(0,10)} ${a.sentAt.slice(11,16)}</div>
        <div style="display:flex;gap:8px">
          <button type="button" class="st-btn ghost sm" onclick="hSendScheduledNow('${a.id}')">${t('Send Now')}</button>
          <button type="button" class="st-btn ghost sm" style="color:var(--red)" onclick="hCancelScheduled('${a.id}')">${t('Cancel')}</button>
        </div>
      </div></div>`).join('') : `<div class="gd-empty-mini">${t('No scheduled messages.')}</div>`}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Drafts')}</div></div>
      <div class="card-body">${drafts.length ? drafts.map(a => `<div class="card" style="margin-bottom:10px;background:var(--surface2)"><div class="card-body">
        <div style="font-weight:600;font-size:13px">${gdCommsEsc(a.subject) || `<span style="color:var(--muted)">${t('(No subject)')}</span>`}</div>
        <div style="font-size:11px;color:var(--muted);margin:4px 0 8px">${hAudienceLabel(a)}</div>
        <div style="display:flex;gap:8px">
          <button type="button" class="st-btn ghost sm" onclick="hResumeDraft('${a.id}')">${t('Resume Editing')}</button>
          <button type="button" class="st-btn ghost sm" style="color:var(--red)" onclick="hDeleteDraft('${a.id}')">${t('Delete')}</button>
        </div>
      </div></div>`).join('') : `<div class="gd-empty-mini">${t('No saved drafts.')}</div>`}</div></div>`;
}
function hRefreshCommsDrafts() { const el = document.getElementById('h-comms-content'); if (el) el.innerHTML = hCommsDraftsTab(); }
function hSendScheduledNow(id) {
  const a = HEAD_DATA.announcements.find(x => x.id === id);
  if (!a) return;
  a.status = 'sent';
  a.sentAt = new Date(2026, 2, 11, 12, 0).toISOString();
  a.readRate = Math.round(40 + hSeededRandom(id + 'now') * 55);
  hRefreshCommsDrafts();
  hShowToast(t('Announcement sent now.'));
}
function hCancelScheduled(id) {
  HEAD_DATA.announcements = HEAD_DATA.announcements.filter(a => a.id !== id);
  hRefreshCommsDrafts();
  hShowToast(t('Scheduled message cancelled.'));
}
function hResumeDraft(id) {
  const a = HEAD_DATA.announcements.find(x => x.id === id);
  if (!a) return;
  HEAD_DATA.announcements = HEAD_DATA.announcements.filter(x => x.id !== id);
  hState.comms.compose = { subject:a.subject, message:a.message, audience:a.audience, audienceClassId:a.audienceClassId, preview:false };
  hState.comms.screen = 'compose';
  hState.comms.tab = 'main';
  hState.comms.error = '';
  hRefreshComms();
}
function hDeleteDraft(id) {
  HEAD_DATA.announcements = HEAD_DATA.announcements.filter(a => a.id !== id);
  hRefreshCommsDrafts();
  hShowToast(t('Draft deleted.'));
}

/* ── Communication Analytics tab ── */
function hCommsAnalyticsTab() {
  const sent = HEAD_DATA.announcements.filter(a => a.status === 'sent');
  const audienceCounts = {};
  sent.forEach(a => { audienceCounts[a.audience] = (audienceCounts[a.audience] || 0) + 1; });
  const avgReadRate = sent.length ? Math.round(hAvg(sent.map(a => a.readRate || 0))) : null;
  const byMonth = {};
  sent.forEach(a => { const m = a.sentAt.slice(0, 7); byMonth[m] = (byMonth[m] || 0) + 1; });
  return `
    <div class="gd-stat-row">
      <div class="stat-card"><div class="stat-label">${t('Total Sent')}</div><div class="stat-val">${sent.length}</div><div class="stat-icon blue">${aIcon('mail')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Avg. Read Rate')}</div><div class="stat-val">${avgReadRate !== null ? avgReadRate + '%' : '—'}</div><div class="stat-icon green">${aIcon('eye')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Drafts')}</div><div class="stat-val">${HEAD_DATA.announcements.filter(a=>a.status==='draft').length}</div><div class="stat-icon yellow">${aIcon('edit')}</div></div>
    </div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('By Audience')}</div></div>
      <div class="card-body">${Object.keys(audienceCounts).length ? Object.keys(audienceCounts).map(aud => `<div class="info-row"><span>${aud === 'class' ? t('Specific Class') : hAudienceLabelSimple(aud)}</span><span style="color:var(--muted)">${audienceCounts[aud]}</span></div>`).join('') : `<div class="gd-empty-mini">${t('No announcements sent yet.')}</div>`}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Sent Over Time')}</div></div>
      <div class="card-body">${Object.keys(byMonth).length ? Object.keys(byMonth).sort().map(m => `<div class="info-row"><span>${m}</span><span style="color:var(--muted)">${byMonth[m]}</span></div>`).join('') : `<div class="gd-empty-mini">${t('No data yet.')}</div>`}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Read Rate by Announcement')}</div></div>
      <div class="card-body">${sent.length ? sent.map(a => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hOpenAnnouncementDetail('${a.id}');hSetCommsTab('main')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hOpenAnnouncementDetail('${a.id}');hSetCommsTab('main')}"><span>${gdCommsEsc(a.subject)}</span><span style="color:var(--muted)">${a.readRate || 0}%</span></div>`).join('') : `<div class="gd-empty-mini">${t('No sent announcements yet.')}</div>`}</div></div>`;
}

/* ══════════════════════════════════════════════════════
   SCHOOL PAYMENTS (Overview + Payment History + Receipts)
══════════════════════════════════════════════════════ */
function hCurrency(amount) { return amount.toLocaleString() + ' MAD'; }
const H_PAYMENT_STATUS_META = { paid:{cls:'paid',label:'Paid'}, pending:{cls:'partial',label:'Pending'}, overdue:{cls:'overdue',label:'Overdue'} };
function hPaymentsView() {
  const tabs = [ { id:'overview', label:'Overview' }, { id:'history', label:'Payment History' }, { id:'analytics', label:'Advanced Analytics' } ];
  return `<div class="st-tabs">${tabs.map(tb => `<div class="st-tab gd-tab-hpay${tb.id===hState.payments.tab?' active':''}" data-tab="${tb.id}" onclick="hSetPaymentsTab('${tb.id}')">${t(tb.label)}</div>`).join('')}</div>
    <div id="h-payments-content">${hPaymentsTabBody()}</div>`;
}
function hSetPaymentsTab(tabId) {
  hState.payments.tab = tabId;
  document.querySelectorAll('.gd-tab-hpay').forEach(el => el.classList.toggle('active', el.dataset.tab === tabId));
  const el = document.getElementById('h-payments-content');
  if (el) el.innerHTML = hPaymentsTabBody();
}
function hPaymentsTabBody() {
  const s = hState.payments;
  if (s.tab === 'history') return hPaymentsBody();
  if (s.tab === 'analytics') return hPaymentAdvancedTab();
  if (s.screen === 'studentHistory') { const st = hGetStudent(s.studentId); if (!st) { s.screen = 'overview'; } else return hStudentPaymentHistoryScreen(st); }
  return hPaymentsOverviewScreen();
}
function hRefreshPayments() { const el = document.getElementById('h-payments-content'); if (el) el.innerHTML = hPaymentsTabBody(); }
function hPaymentsOverviewScreen() {
  const totalCollected = HEAD_DATA.payments.filter(p => p.status === 'paid').reduce((sum, p) => sum + p.amount, 0);
  const outstanding = HEAD_DATA.payments.filter(p => p.status === 'pending' || p.status === 'overdue').reduce((sum, p) => sum + p.amount, 0);
  const paidStudents = HEAD_DATA.students.filter(s => s.paymentStatus === 'paid').length;
  const overdueStudents = HEAD_DATA.students.filter(s => s.paymentStatus === 'overdue').length;
  const recent = HEAD_DATA.payments.filter(p => p.status === 'paid').slice().sort((a, b) => b.date.localeCompare(a.date)).slice(0, 6);
  return `
    <div class="gd-stat-row">
      <div class="stat-card"><div class="stat-label">${t('Total Collected')}</div><div class="stat-val" style="font-size:16px">${hCurrency(totalCollected)}</div><div class="stat-icon green">${aIcon('dollar-sign')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Outstanding')}</div><div class="stat-val" style="font-size:16px">${hCurrency(outstanding)}</div><div class="stat-icon yellow">${aIcon('clock')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Paid Students')}</div><div class="stat-val">${paidStudents}</div><div class="stat-icon blue">${aIcon('check-circle')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Overdue Students')}</div><div class="stat-val">${overdueStudents}</div><div class="stat-icon red">${aIcon('x-circle')}</div></div>
    </div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Recent Payments')}</div><div class="card-action" onclick="hSetPaymentsTab('history')">${t('View All')} →</div></div>
      <div class="card-body">${recent.length ? recent.map(p => { const st = hGetStudent(p.studentId); return `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hOpenReceipt('${p.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hOpenReceipt('${p.id}')}"><span>${st ? gdCommsEsc(hStudentFullName(st)) : '—'}<div style="font-size:11px;color:var(--muted)">${gdCommsEsc(p.description)} · ${p.date}</div></span><span>${hCurrency(p.amount)}</span></div>`; }).join('') : `<div class="gd-empty-mini">${t('No payments recorded yet.')}</div>`}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Student Payment Status')}</div></div>
      <div class="card-body">${HEAD_DATA.students.map(s => { const meta = { paid:{cls:'paid',label:'Paid'}, partial:{cls:'partial',label:'Partial'}, overdue:{cls:'overdue',label:'Overdue'} }[s.paymentStatus]; return `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hOpenStudentPaymentHistory('${s.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hOpenStudentPaymentHistory('${s.id}')}"><span>${gdCommsEsc(hStudentFullName(s))}</span><span class="status-pill ${meta.cls}">${t(meta.label)}</span></div>`; }).join('')}</div></div>`;
}
function hOpenStudentPaymentHistory(studentId) {
  hState.payments.screen = 'studentHistory';
  hState.payments.studentId = studentId;
  hRefreshPayments();
}
function hBackToPaymentsOverview() {
  hState.payments.screen = 'overview';
  hState.payments.studentId = null;
  hRefreshPayments();
}
function hStudentPaymentHistoryScreen(student) {
  const records = HEAD_DATA.payments.filter(p => p.studentId === student.id).sort((a, b) => b.date.localeCompare(a.date));
  return `<div class="card"><div class="card-header">
    <div style="display:flex;align-items:center;gap:10px"><button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="hBackToPaymentsOverview()">${t('← Back')}</button><div class="card-title">${gdCommsEsc(hStudentFullName(student))}</div></div>
  </div>
    <div class="card-body">
      ${records.map(p => { const meta = H_PAYMENT_STATUS_META[p.status]; return `<div class="info-row" style="cursor:${p.status==='paid'?'pointer':'default'}" ${p.status==='paid'?`role="button" tabindex="0" onclick="hOpenReceipt('${p.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hOpenReceipt('${p.id}')}"`:''}>
        <span>${gdCommsEsc(p.description)}<div style="font-size:11px;color:var(--muted)">${p.date}${p.method?' · '+gdCommsEsc(p.method):''}</div></span>
        <span style="text-align:right">${hCurrency(p.amount)}<div style="margin-top:4px"><span class="status-pill ${meta.cls}">${t(meta.label)}</span></div></span>
      </div>`; }).join('') || `<div class="gd-empty-mini">${t('No payment records for this student.')}</div>`}
    </div></div>`;
}

/* ── Payment History (searchable / filterable) ── */
function hFilteredPayments() {
  const s = hState.payments;
  let list = HEAD_DATA.payments.slice();
  if (s.filterClassId !== 'all') { const ids = hClassStudents(s.filterClassId).map(x => x.id); list = list.filter(p => ids.includes(p.studentId)); }
  if (s.filterStatus !== 'all') list = list.filter(p => p.status === s.filterStatus);
  if (s.filterMethod !== 'all') list = list.filter(p => p.method === s.filterMethod);
  if (s.minAmount !== '') list = list.filter(p => p.amount >= Number(s.minAmount));
  if (s.maxAmount !== '') list = list.filter(p => p.amount <= Number(s.maxAmount));
  const q = s.search.trim().toLowerCase();
  if (q) list = list.filter(p => { const st = hGetStudent(p.studentId); return st && hStudentFullName(st).toLowerCase().includes(q); });
  return list.sort((a, b) => b.date.localeCompare(a.date));
}
function hPaymentsBody() {
  const s = hState.payments;
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Payment History')}</div></div>
    <div class="card-body">
      <input class="gd-comm-search-input" type="text" placeholder="${t('Search by student name...')}" value="${gdCommsEsc(s.search)}" oninput="hSetPaymentSearch(this.value)">
      <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:10px">
        <select onchange="hSetPaymentClassFilter(this.value)" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
          <option value="all" ${s.filterClassId==='all'?'selected':''}>${t('All Classes')}</option>
          ${HEAD_DATA.classes.map(c => `<option value="${c.id}" ${c.id===s.filterClassId?'selected':''}>${gdCommsEsc(c.name)}</option>`).join('')}
        </select>
        <select onchange="hSetPaymentStatusFilter(this.value)" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
          <option value="all" ${s.filterStatus==='all'?'selected':''}>${t('All Statuses')}</option>
          <option value="paid" ${s.filterStatus==='paid'?'selected':''}>${t('Paid')}</option>
          <option value="pending" ${s.filterStatus==='pending'?'selected':''}>${t('Pending')}</option>
          <option value="overdue" ${s.filterStatus==='overdue'?'selected':''}>${t('Overdue')}</option>
        </select>
        <select onchange="hSetPaymentMethodFilter(this.value)" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
          <option value="all" ${s.filterMethod==='all'?'selected':''}>${t('All Methods')}</option>
          ${H_PAYMENT_METHODS.map(m => `<option value="${m}" ${m===s.filterMethod?'selected':''}>${gdCommsEsc(m)}</option>`).join('')}
        </select>
      </div>
      <div style="display:flex;gap:10px;margin-top:10px;align-items:center">
        <input id="h-pay-min" type="number" placeholder="${t('Min amount')}" value="${s.minAmount}" oninput="hSetPaymentAmountRange()" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px;width:110px">
        <span style="color:var(--muted);font-size:12px">${t('to')}</span>
        <input id="h-pay-max" type="number" placeholder="${t('Max amount')}" value="${s.maxAmount}" oninput="hSetPaymentAmountRange()" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px;width:110px">
      </div>
    </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Records')}</div><span style="font-size:12px;color:var(--muted)" id="h-pay-count">${hFilteredPayments().length} ${t('of')} ${HEAD_DATA.payments.length}</span></div>
      <div class="card-body" id="h-payment-list-results">${hPaymentListResultsBlock()}</div></div>`;
}
function hPaymentListResultsBlock() {
  const list = hFilteredPayments();
  if (!list.length) return `<div class="gd-empty-mini">${t('No payment records match your filters.')}</div>`;
  return list.map(p => { const st = hGetStudent(p.studentId); const meta = H_PAYMENT_STATUS_META[p.status]; return `<div class="info-row" style="cursor:${p.status==='paid'?'pointer':'default'}" ${p.status==='paid'?`role="button" tabindex="0" onclick="hOpenReceipt('${p.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hOpenReceipt('${p.id}')}"`:''}>
    <span>${st ? gdCommsEsc(hStudentFullName(st)) : '—'}<div style="font-size:11px;color:var(--muted)">${gdCommsEsc(p.description)} · ${p.date}${p.method?' · '+gdCommsEsc(p.method):''}</div></span>
    <span style="text-align:right">${hCurrency(p.amount)}<div style="margin-top:4px"><span class="status-pill ${meta.cls}">${t(meta.label)}</span></div></span>
  </div>`; }).join('');
}
function hRefreshPaymentListResults() {
  const el = document.getElementById('h-payment-list-results');
  if (el) el.innerHTML = hPaymentListResultsBlock();
  const countEl = document.getElementById('h-pay-count');
  if (countEl) countEl.textContent = `${hFilteredPayments().length} ${t('of')} ${HEAD_DATA.payments.length}`;
}
function hSetPaymentSearch(v) { hState.payments.search = v; hRefreshPaymentListResults(); }
function hSetPaymentClassFilter(v) { hState.payments.filterClassId = v; hRefreshPaymentListResults(); }
function hSetPaymentStatusFilter(v) { hState.payments.filterStatus = v; hRefreshPaymentListResults(); }
function hSetPaymentMethodFilter(v) { hState.payments.filterMethod = v; hRefreshPaymentListResults(); }
function hSetPaymentAmountRange() {
  const minEl = document.getElementById('h-pay-min');
  const maxEl = document.getElementById('h-pay-max');
  hState.payments.minAmount = minEl ? minEl.value : '';
  hState.payments.maxAmount = maxEl ? maxEl.value : '';
  hRefreshPaymentListResults();
}

/* ══════════════════════════════════════════════════════
   RECEIPTS
══════════════════════════════════════════════════════ */
function hOpenReceipt(paymentId) {
  hState.payments.screen = 'receipt';
  hState.payments.paymentId = paymentId;
  const el = document.getElementById('h-payments-content');
  if (el) el.innerHTML = hReceiptScreen();
}
function hBackFromReceipt() {
  hState.payments.screen = hState.payments.studentId ? 'studentHistory' : 'overview';
  hState.payments.paymentId = null;
  hRefreshPayments();
}
function hReceiptScreen() {
  const p = HEAD_DATA.payments.find(x => x.id === hState.payments.paymentId);
  if (!p || p.status !== 'paid') return hPaymentsTabBody();
  const student = hGetStudent(p.studentId);
  const cls = student ? hGetClass(student.classId) : null;
  return `<div class="card">
    <div class="card-header">
      <div style="display:flex;align-items:center;gap:10px"><button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="hBackFromReceipt()">${t('← Back')}</button><div class="card-title">${t('Receipt')}</div></div>
      <button type="button" class="st-btn ghost sm" onclick="window.print()">${aIcon('printer')} ${t('Print / Download')}</button>
    </div>
    <div class="card-body">
      <div style="text-align:center;padding-bottom:16px;margin-bottom:16px;border-bottom:0.5px dashed var(--separator)">
        ${HEAD_DATA.settings.logoDataUrl ? `<img src="${HEAD_DATA.settings.logoDataUrl}" alt="" style="width:48px;height:48px;border-radius:10px;object-fit:cover;margin-bottom:8px">` : ''}
        <div style="font-weight:800;font-size:15px">${gdCommsEsc(HEAD_DATA.institution.name)}</div>
        <div style="font-size:11.5px;color:var(--muted)">${gdCommsEsc(HEAD_DATA.institution.address)}</div>
      </div>
      <div class="info-row"><span>${t('Receipt Number')}</span><span style="font-family:monospace">${gdCommsEsc(p.receiptId)}</span></div>
      <div class="info-row"><span>${t('Date')}</span><span>${p.date}</span></div>
      <div class="info-row"><span>${t('Student')}</span><span>${student ? gdCommsEsc(hStudentFullName(student)) : '—'}</span></div>
      <div class="info-row"><span>${t('Class')}</span><span>${cls ? gdCommsEsc(cls.name) : '—'}</span></div>
      <div class="info-row"><span>${t('Description')}</span><span>${gdCommsEsc(p.description)}</span></div>
      <div class="info-row"><span>${t('Payment Method')}</span><span>${gdCommsEsc(p.method)}</span></div>
      <div class="info-row" style="border-top:0.5px solid var(--separator);margin-top:10px;padding-top:10px"><span style="font-weight:700">${t('Amount Paid')}</span><span style="font-weight:700;font-size:15px">${hCurrency(p.amount)}</span></div>
      <div style="font-size:11px;color:var(--muted);margin-top:16px;text-align:center">${t('This is an official receipt issued by')} ${gdCommsEsc(HEAD_DATA.institution.name)}.</div>
    </div></div>`;
}

/* ══════════════════════════════════════════════════════
   STUDENT PROGRESS ANALYTICS (per-student visual timeline)
══════════════════════════════════════════════════════ */
function hOpenStudentProgress(studentId) {
  hState.students.screen = 'progress';
  hState.students.studentId = studentId;
  hRefreshStudents();
}
function hBackToStudentProfile() {
  hState.students.screen = 'profile';
  hRefreshStudents();
}
function hStudentAttendanceWeeklyTrend(studentId) {
  const weeks = [];
  for (let i = 0; i < H_ATTENDANCE_DAYS.length; i += 5) weeks.push(H_ATTENDANCE_DAYS.slice(i, i + 5));
  return weeks.filter(w => w.length).map((w, i) => {
    const agg = hAggregateAttendance([studentId], w);
    return { label: 'W' + (i + 1), value: agg.rate !== null ? agg.rate : 0 };
  });
}
function hStudentProgressScreen(student) {
  const cls = hGetClass(student.classId);
  const examHistory = hStudentExamHistoryH(student.id);
  const gradePoints = examHistory.map(h => ({ label: h.date.slice(5), value: Math.round((h.score / h.maxScore) * 100) }));
  const attendancePoints = hStudentAttendanceWeeklyTrend(student.id);
  const homeworkForClass = HEAD_DATA.homework.filter(h => h.classId === student.classId).sort((a, b) => a.dueDate.localeCompare(b.dueDate));
  const behaviorRecs = hStudentBehaviorRecordsH(student.id).sort((a, b) => a.date.localeCompare(b.date));
  const trend = hStudentGradeTrendH(student.id);
  const cutoff = '2026-01-01';
  const beforeScores = examHistory.filter(h => h.date < cutoff).map(h => (h.score / h.maxScore) * 100);
  const afterScores = examHistory.filter(h => h.date >= cutoff).map(h => (h.score / h.maxScore) * 100);

  return `<div class="card">
    <div class="card-header">
      <div style="display:flex;align-items:center;gap:10px;min-width:0;flex:1"><button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="hBackToStudentProfile()">${t('← Back')}</button><div class="card-title" style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${t('Progress')}: ${gdCommsEsc(hStudentFullName(student))}</div></div>
    </div>
    <div class="card-body">
      <div style="font-size:12px;color:var(--muted);margin-bottom:14px">${cls ? gdCommsEsc(cls.name) : ''}</div>

      <div style="font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Academic Progression')}</div>
      ${gdSvgLineChart(gradePoints, { max:100, unit:'%', ariaLabel:t('Academic progression'), emptyText:t('Not enough graded assessments yet.') })}
      ${trend !== null ? `<div style="font-size:11.5px;color:${trend<0?'var(--red)':'var(--green)'};margin-top:6px">${trend>=0?'▲':'▼'} ${Math.abs(trend)}% ${trend<0?t('decline since first assessment'):t('improvement since first assessment')}</div>` : ''}

      <div style="font-size:12.5px;font-weight:600;margin:18px 0 8px">${t('Attendance Progression')}</div>
      ${gdSvgLineChart(attendancePoints, { max:100, unit:'%', ariaLabel:t('Attendance progression'), emptyText:t('No attendance data yet.') })}

      <div style="margin-top:18px;padding-top:14px;border-top:0.5px solid var(--separator)">
        <div style="font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Homework Progression')}</div>
        ${homeworkForClass.length ? homeworkForClass.map(h => {
          const status = hHomeworkStatus(h, student.id);
          const meta = { submitted:{cls:'open',label:'Submitted'}, late:{cls:'awaiting',label:'Late'}, missing:{cls:'overdue',label:'Missing'}, pending:{cls:'resolved',label:'Not Due Yet'} }[status];
          return `<div class="info-row"><span>${gdCommsEsc(h.title)}<div style="font-size:11px;color:var(--muted)">${h.dueDate}</div></span><span class="status-pill ${meta.cls}">${t(meta.label)}</span></div>`;
        }).join('') : `<div class="gd-empty-mini">${t('No homework assigned yet.')}</div>`}
      </div>

      <div style="margin-top:18px;padding-top:14px;border-top:0.5px solid var(--separator)">
        <div style="font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Behavior Progression')}</div>
        ${behaviorRecs.length ? behaviorRecs.map(r => `<div class="info-row"><span>${gdCommsEsc(t(r.category))}</span><span style="color:var(--muted);font-size:11.5px">${r.date}</span></div>`).join('') : `<div class="gd-empty-mini">${t('No behavior records yet.')}</div>`}
      </div>

      <div style="margin-top:18px;padding-top:14px;border-top:0.5px solid var(--separator)">
        <div style="font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Payment Status')}</div>
        <div class="info-row"><span>${t('Current Status')}</span><span class="status-pill ${student.paymentStatus}">${t(student.paymentStatus.charAt(0).toUpperCase()+student.paymentStatus.slice(1))}</span></div>
        <button type="button" class="st-btn ghost sm" style="margin-top:8px" onclick="hOpenStudentPaymentHistory('${student.id}');authrenGoTo('payments')">${t('View Full Payment History')} →</button>
      </div>

      <div style="margin-top:18px;padding-top:14px;border-top:0.5px solid var(--separator)">
        <div style="font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Historical Comparison')}</div>
        <div class="info-row"><span>${t('Before')} ${cutoff}</span><span>${beforeScores.length ? Math.round(hAvg(beforeScores)) + '%' : t('No data')}</span></div>
        <div class="info-row"><span>${t('From')} ${cutoff}</span><span>${afterScores.length ? Math.round(hAvg(afterScores)) + '%' : t('No data')}</span></div>
      </div>
    </div></div>`;
}

/* ══════════════════════════════════════════════════════
   SCHOOL INTELLIGENCE — Pulse, What Changed?, Important Changes
   All three tabs are built on the SAME deterministic, transparent
   calculations over real data — never an opaque score. Reasoning
   is always shown alongside the numbers.
══════════════════════════════════════════════════════ */
function hIntelligenceView() {
  const tabs = [ { id:'pulse', label:'School Pulse' }, { id:'changed', label:'What Changed?' }, { id:'alerts', label:'Important Changes' }, { id:'performance', label:'Performance Overview' }, { id:'problems', label:'Problem Detection' }, { id:'insights', label:'Combined Insights' }, { id:'forecast', label:'Forecasting' } ];
  return `<div class="st-tabs">${tabs.map(tb => `<div class="st-tab gd-tab-hint${tb.id===hState.intelligence.tab?' active':''}" data-tab="${tb.id}" onclick="hSetIntelligenceTab('${tb.id}')">${t(tb.label)}</div>`).join('')}</div>
    <div id="h-intelligence-content">${hIntelligenceTabBody()}</div>`;
}
function hSetIntelligencePeriodType(periodType) {
  hState.intelligence.periodType = periodType;
  const el = document.getElementById('h-intelligence-content');
  if (el) el.innerHTML = hIntelligenceTabBody();
}
function hSetIntelligenceTab(tabId) {
  hState.intelligence.tab = tabId;
  document.querySelectorAll('.gd-tab-hint').forEach(el => el.classList.toggle('active', el.dataset.tab === tabId));
  const el = document.getElementById('h-intelligence-content');
  if (el) el.innerHTML = hIntelligenceTabBody();
}
function hIntelligenceTabBody() {
  if (hState.intelligence.tab === 'changed') return hWhatChangedTab();
  if (hState.intelligence.tab === 'alerts') return hImportantChangesTab();
  if (hState.intelligence.tab === 'performance') return hPerformanceOverviewTab();
  if (hState.intelligence.tab === 'problems') return hProblemDetectionTab();
  if (hState.intelligence.tab === 'insights') return hCombinedInsightsTab();
  if (hState.intelligence.tab === 'forecast') return hForecastingTab();
  return hSchoolPulseTab();
}

/* Shared month-over-month comparison — "current" = March 2026 (the most
   recent month with data, up to "today"), "previous" = February 2026 —
   feeding both What Changed? and Important Changes so the two views can
   never disagree with each other. */
const H_PERIOD_TYPES = [ ['month','This Month vs Last Month'], ['term','Current Term vs Previous Term'], ['year','Current Year vs Previous Year'] ];
function hPeriodPredicates(periodType) {
  if (periodType === 'term') {
    const termCutoff = '2026-01-01';
    return { isCurrent: d => d >= termCutoff, isPrevious: d => d < termCutoff, curLabel:t('Current Term'), prevLabel:t('Previous Term') };
  }
  if (periodType === 'year') {
    return { isCurrent: d => d.startsWith('2026'), isPrevious: d => d.startsWith('2025'), curLabel:'2026', prevLabel:'2025' };
  }
  return { isCurrent: d => d.startsWith('2026-03'), isPrevious: d => d.startsWith('2026-02'), curLabel:t('Mar 2026'), prevLabel:t('Feb 2026') };
}
function hComputePeriodComparison(periodType) {
  const { isCurrent, isPrevious } = hPeriodPredicates(periodType);
  const allIds = HEAD_DATA.students.map(s => s.id);

  const curAttDays = H_ATTENDANCE_DAYS.filter(isCurrent);
  const prevAttDays = H_ATTENDANCE_DAYS.filter(isPrevious);
  const curAttRate = curAttDays.length ? hAggregateAttendance(allIds, curAttDays).rate : null;
  const prevAttRate = prevAttDays.length ? hAggregateAttendance(allIds, prevAttDays).rate : null;

  const curScores = [], prevScores = [];
  HEAD_DATA.exams.forEach(e => Object.values(e.scores).forEach(sc => { const pct = (sc / e.maxScore) * 100; if (isCurrent(e.date)) curScores.push(pct); else if (isPrevious(e.date)) prevScores.push(pct); }));
  const curAcademic = curScores.length ? Math.round(hAvg(curScores)) : null;
  const prevAcademic = prevScores.length ? Math.round(hAvg(prevScores)) : null;

  let curHwSub = 0, curHwTotal = 0, prevHwSub = 0, prevHwTotal = 0;
  HEAD_DATA.homework.forEach(h => { const c = hHomeworkCounts(h); const submitted = c.submitted + c.late; if (isCurrent(h.dueDate)) { curHwSub += submitted; curHwTotal += c.total; } else if (isPrevious(h.dueDate)) { prevHwSub += submitted; prevHwTotal += c.total; } });
  const curHomework = curHwTotal ? Math.round((curHwSub / curHwTotal) * 100) : null;
  const prevHomework = prevHwTotal ? Math.round((prevHwSub / prevHwTotal) * 100) : null;

  const curBehavior = HEAD_DATA.behaviorRecords.filter(r => !hIsPositiveBehavior(r.category) && isCurrent(r.date)).length;
  const prevBehavior = HEAD_DATA.behaviorRecords.filter(r => !hIsPositiveBehavior(r.category) && isPrevious(r.date)).length;
  const behaviorHasData = H_ATTENDANCE_DAYS.some(isCurrent) || H_ATTENDANCE_DAYS.some(isPrevious);

  const curPayments = HEAD_DATA.payments.filter(p => p.status === 'paid' && isCurrent(p.date)).reduce((s, p) => s + p.amount, 0);
  const prevPayments = HEAD_DATA.payments.filter(p => p.status === 'paid' && isPrevious(p.date)).reduce((s, p) => s + p.amount, 0);

  const curAdmissions = HEAD_DATA.admissions.filter(a => isCurrent(a.submittedDate)).length;
  const prevAdmissions = HEAD_DATA.admissions.filter(a => isPrevious(a.submittedDate)).length;

  return [
    { id:'attendance', label:'Attendance Rate', current:curAttRate, previous:prevAttRate, unit:'%', higherIsBetter:true, route:'attendance' },
    { id:'academic', label:'Academic Performance', current:curAcademic, previous:prevAcademic, unit:'%', higherIsBetter:true, route:'grades' },
    { id:'homework', label:'Homework Completion', current:curHomework, previous:prevHomework, unit:'%', higherIsBetter:true, route:'homework' },
    { id:'behavior', label:'Negative Behavior Incidents', current:behaviorHasData?curBehavior:null, previous:behaviorHasData?prevBehavior:null, unit:'', higherIsBetter:false, route:'behavior' },
    { id:'payments', label:'Payment Collection', current:curPayments, previous:prevPayments, unit:'MAD', higherIsBetter:true, route:'payments' },
    { id:'admissions', label:'New Admissions', current:curAdmissions, previous:prevAdmissions, unit:'', higherIsBetter:true, route:'admissions' },
  ];
}
function hComputeMonthComparison() { return hComputePeriodComparison('month'); }

/* ── School Pulse ── */
function hPulseIndicator(value, good, warn, higherIsBetter) {
  if (value === null) return { level:'neutral', icon: aIcon('dot'), label:'No data' };
  const isGood = higherIsBetter ? value >= good : value <= good;
  const isWarn = higherIsBetter ? value >= warn : value <= warn;
  if (isGood) return { level:'good', icon: aIcon('dot'), label:'Healthy' };
  if (isWarn) return { level:'warn', icon: aIcon('dot'), label:'Needs Attention' };
  return { level:'bad', icon: aIcon('dot'), label:'At Risk' };
}
function hPulseCard(title, value, unit, indicator, route, detail) {
  return `<div class="card" style="cursor:pointer" role="button" tabindex="0" onclick="authrenGoTo('${route}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();authrenGoTo('${route}')}"><div class="card-body">
    <div style="display:flex;justify-content:space-between;align-items:center">
      <div>
        <div style="font-size:12px;color:var(--muted)">${t(title)}</div>
        <div style="font-size:20px;font-weight:800;margin-top:2px">${value !== null ? value + unit : '—'}</div>
      </div>
      <div style="text-align:right">
        <div style="font-size:20px">${indicator.icon}</div>
        <div style="font-size:10.5px;color:var(--muted)">${t(indicator.label)}</div>
      </div>
    </div>
    ${detail ? `<div style="font-size:11px;color:var(--muted);margin-top:8px">${detail}</div>` : ''}
  </div></div>`;
}
function hSchoolPulseTab() {
  const academicAvg = hAvg(HEAD_DATA.students.map(s => s.avgGrade));
  const attendanceAvg = hAvg(HEAD_DATA.students.map(s => s.attendanceRate));
  const totalHwCounts = HEAD_DATA.homework.reduce((acc, h) => { const c = hHomeworkCounts(h); acc.sub += c.submitted + c.late; acc.total += c.total; return acc; }, { sub:0, total:0 });
  const homeworkRate = totalHwCounts.total ? Math.round((totalHwCounts.sub / totalHwCounts.total) * 100) : null;
  const negativeIncidents = HEAD_DATA.behaviorRecords.filter(r => !hIsPositiveBehavior(r.category)).length;
  const totalDue = HEAD_DATA.payments.reduce((s, p) => s + p.amount, 0);
  const totalOutstanding = HEAD_DATA.payments.filter(p => p.status !== 'paid').reduce((s, p) => s + p.amount, 0);
  const outstandingPct = totalDue ? Math.round((totalOutstanding / totalDue) * 100) : 0;
  const openReclamations = HEAD_DATA.reclamations.filter(r => r.status !== 'resolved').length;
  const pendingAdmissions = HEAD_DATA.admissions.filter(a => a.status === 'pending' || a.status === 'under-review').length;
  const announcementsSent = HEAD_DATA.announcements.filter(a => a.status === 'sent').length;
  const alertCount = hDetectImportantChanges().length;
  const riskCount = HEAD_DATA.students.filter(s => hComputeStudentRisk(s).level !== 'none').length;
  const classAvgs = HEAD_DATA.classes.map(c => ({ cls:c, avg: hClassAvgGrade(c.id) })).filter(x => x.avg !== null).sort((a, b) => b.avg - a.avg);
  const highPerforming = classAvgs.slice(0, 3);
  const needsAttention = classAvgs.slice(-3).reverse().filter(x => x.avg < 14);

  return `
    <div style="font-size:12px;color:var(--muted);margin-bottom:14px">${t('A real-time snapshot of institutional health, computed transparently from current data. Tap any card to explore.')}</div>
    <div class="gd-stat-row">
      ${hPulseCard('Academic Performance', academicAvg, '/20', hPulseIndicator(academicAvg, 14, 11, true), 'grades')}
      ${hPulseCard('Attendance Rate', attendanceAvg, '%', hPulseIndicator(attendanceAvg, 90, 80, true), 'attendance')}
      ${hPulseCard('Homework Completion', homeworkRate, '%', hPulseIndicator(homeworkRate, 85, 70, true), 'homework')}
      ${hPulseCard('Negative Behavior', negativeIncidents, '', hPulseIndicator(negativeIncidents, 5, 15, false), 'behavior')}
    </div>
    <div class="gd-stat-row" style="margin-top:16px">
      ${hPulseCard('Outstanding Payments', outstandingPct, '%', hPulseIndicator(outstandingPct, 10, 25, false), 'payments', hCurrency(totalOutstanding) + ' ' + t('outstanding'))}
      ${hPulseCard('Open Reclamations', openReclamations, '', hPulseIndicator(openReclamations, 2, 5, false), 'reclamations')}
      ${hPulseCard('Pending Admissions', pendingAdmissions, '', { level:'neutral', icon: aIcon('clipboard'), label:t('Informational') }, 'admissions')}
      ${hPulseCard('Announcements Sent', announcementsSent, '', { level:'neutral', icon: aIcon('mail'), label:t('Informational') }, 'communication')}
    </div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Trends, Alerts & Risks')}</div></div>
      <div class="card-body">
        <div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hSetIntelligenceTab('changed')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hSetIntelligenceTab('changed')}"><span>${aIcon('trending-up')} ${t('Trends (What Changed?)')}</span><span class="card-action">${t('View')} →</span></div>
        <div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hSetIntelligenceTab('alerts')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hSetIntelligenceTab('alerts')}"><span>${aIcon('alert-triangle')} ${t('Important Changes')}</span><span class="status-pill ${alertCount>0?'overdue':'paid'}">${alertCount}</span></div>
        <div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="authrenGoTo('risk')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();authrenGoTo('risk')}"><span>${aIcon('alert-triangle')} ${t('Students at Risk')}</span><span class="status-pill ${riskCount>0?'awaiting':'paid'}">${riskCount}</span></div>
      </div></div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('High-Performing Classes')}</div></div>
      <div class="card-body">${highPerforming.length ? highPerforming.map(x => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hOpenGradesClass('${x.cls.id}');authrenGoTo('grades')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hOpenGradesClass('${x.cls.id}');authrenGoTo('grades')}"><span>${gdCommsEsc(x.cls.name)}</span><span style="color:var(--green)">${x.avg}/20</span></div>`).join('') : `<div class="gd-empty-mini">${t('No data yet.')}</div>`}</div></div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Areas Requiring Attention')}</div></div>
      <div class="card-body">${needsAttention.length ? needsAttention.map(x => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hOpenGradesClass('${x.cls.id}');authrenGoTo('grades')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hOpenGradesClass('${x.cls.id}');authrenGoTo('grades')}"><span>${gdCommsEsc(x.cls.name)}</span><span style="color:var(--red)">${x.avg}/20</span></div>`).join('') : `<div class="gd-empty-mini">${t('No classes currently need attention.')}</div>`}</div></div>`;
}

/* ── What Changed? ── */
function hFormatMetricValue(v, unit) { if (v === null) return t('No data'); return unit === 'MAD' ? hCurrency(v) : v + unit; }
function hAffectedPopulationLabel(id) {
  if (id === 'attendance' || id === 'academic') return `${HEAD_DATA.students.length} ${t('students')}`;
  if (id === 'homework') return `${HEAD_DATA.homework.length} ${t('homework items')}`;
  if (id === 'behavior') { const ids = new Set(HEAD_DATA.behaviorRecords.map(r => r.studentId)); return `${ids.size} ${t('students with records')}`; }
  if (id === 'payments') return `${HEAD_DATA.students.length} ${t('students')}`;
  if (id === 'admissions') return `${HEAD_DATA.classes.length} ${t('grade levels')}`;
  return '';
}
function hWhatChangedTab() {
  const periodType = hState.intelligence.periodType;
  const comparisons = hComputePeriodComparison(periodType);
  const { curLabel, prevLabel } = hPeriodPredicates(periodType);
  const withData = comparisons.filter(c => c.current !== null && c.previous !== null);
  const withoutData = comparisons.filter(c => c.current === null || c.previous === null);
  withData.sort((a, b) => {
    const magA = a.previous ? Math.abs((a.current - a.previous) / (a.previous || 1)) : Math.abs(a.current - a.previous);
    const magB = b.previous ? Math.abs((b.current - b.previous) / (b.previous || 1)) : Math.abs(b.current - b.previous);
    return magB - magA;
  });
  const sortedComparisons = [...withData, ...withoutData];
  return `
    <div class="gd-comm-filter-row" style="margin-bottom:12px">${H_PERIOD_TYPES.map(([id,label]) => `<div class="gd-comm-filter-chip${periodType===id?' active':''}" onclick="hSetIntelligencePeriodType('${id}')">${t(label)}</div>`).join('')}</div>
    <div style="font-size:12px;color:var(--muted);margin-bottom:14px">${t('Comparing')} ${prevLabel} (${t('previous')}) ${t('to')} ${curLabel} (${t('current')}) — ${t('sorted by importance (magnitude of change)')}.</div>
    ${sortedComparisons.map(c => {
      if (c.current === null || c.previous === null) {
        return `<div class="card" style="margin-bottom:10px;cursor:pointer" role="button" tabindex="0" onclick="authrenGoTo('${c.route}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();authrenGoTo('${c.route}')}"><div class="card-body">
          <div style="font-weight:600;font-size:13px">${t(c.label)}</div>
          <div style="font-size:11.5px;color:var(--muted);margin-top:4px">${t('Not enough data in both periods to compare.')} (${prevLabel}: ${hFormatMetricValue(c.previous, c.unit)} · ${curLabel}: ${hFormatMetricValue(c.current, c.unit)})</div>
        </div></div>`;
      }
      const delta = c.current - c.previous;
      const improved = c.higherIsBetter ? delta >= 0 : delta <= 0;
      const arrow = delta > 0 ? '▲' : delta < 0 ? '▼' : '—';
      return `<div class="card" style="margin-bottom:10px;cursor:pointer" role="button" tabindex="0" onclick="authrenGoTo('${c.route}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();authrenGoTo('${c.route}')}"><div class="card-body">
        <div style="display:flex;justify-content:space-between;align-items:center">
          <div style="font-weight:600;font-size:13px">${t(c.label)}</div>
          <div style="color:${improved?'var(--green)':'var(--red)'};font-weight:700;font-size:13px">${arrow} ${c.unit==='MAD' ? hCurrency(Math.abs(delta)) : Math.abs(delta) + c.unit}</div>
        </div>
        <div style="font-size:11.5px;color:var(--muted);margin-top:4px">${prevLabel}: ${hFormatMetricValue(c.previous, c.unit)} → ${curLabel}: ${hFormatMetricValue(c.current, c.unit)}</div>
        <div style="font-size:11px;color:var(--muted);margin-top:4px">${t('Affected')}: ${hAffectedPopulationLabel(c.id)}</div>
      </div></div>`;
    }).join('')}`;
}

/* ── Important-Change Detection ── */
const H_CHANGE_THRESHOLDS = { attendance:5, academic:5, homework:10, behavior:3, payments:2000, admissions:3 };
function hDetectImportantChanges() {
  const comparisons = hComputeMonthComparison();
  const alerts = [];
  comparisons.forEach(c => {
    if (c.current === null || c.previous === null) return;
    const delta = c.current - c.previous;
    const threshold = H_CHANGE_THRESHOLDS[c.id];
    if (Math.abs(delta) < threshold) return;
    const isGoodDirection = c.higherIsBetter ? delta > 0 : delta < 0;
    // Admissions: both directions are noteworthy. Other metrics: only the "bad" direction is an alert.
    if (c.id !== 'admissions' && isGoodDirection) return;
    const magnitude = Math.abs(delta) / threshold;
    const severity = magnitude >= 2.5 ? 'high' : magnitude >= 1.5 ? 'medium' : 'low';
    alerts.push({ ...c, delta, severity });
  });
  return alerts.sort((a, b) => ({ high:0, medium:1, low:2 }[a.severity] - { high:0, medium:1, low:2 }[b.severity]));
}
function hChangeExplanation(c, delta) {
  const dir = delta > 0 ? t('increased') : t('decreased');
  const amount = c.unit === 'MAD' ? hCurrency(Math.abs(delta)) : Math.abs(delta) + c.unit;
  return `${t(c.label)} ${dir} ${t('by')} ${amount} ${t('compared to the previous month')}.`;
}
function hImportantChangesTab() {
  const alerts = hDetectImportantChanges();
  const severityMeta = { high:{cls:'overdue',label:'High'}, medium:{cls:'awaiting',label:'Medium'}, low:{cls:'resolved',label:'Low'} };
  return `
    <div style="font-size:12px;color:var(--muted);margin-bottom:14px">${t('Automatically detected using fixed, transparent thresholds over the same month-over-month data as What Changed?')}</div>
    ${alerts.length ? alerts.map(a => { const sm = severityMeta[a.severity]; return `<div class="card" style="margin-bottom:10px;cursor:pointer" role="button" tabindex="0" onclick="authrenGoTo('${a.route}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();authrenGoTo('${a.route}')}"><div class="card-body">
      <div style="display:flex;justify-content:space-between;align-items:flex-start">
        <div style="font-weight:700;font-size:13px">${t(a.label)}</div>
        <span class="status-pill ${sm.cls}">${t(sm.label)}</span>
      </div>
      <div style="font-size:12px;color:var(--muted2);margin-top:6px">${hChangeExplanation(a, a.delta)}</div>
      <div style="font-size:11px;color:var(--muted);margin-top:6px">${t('Threshold for flagging')}: ${a.unit==='MAD'?hCurrency(H_CHANGE_THRESHOLDS[a.id]):H_CHANGE_THRESHOLDS[a.id]+a.unit}</div>
    </div></div>`; }).join('') : `<div class="gd-empty-state"><div class="gd-empty-state-title">${t('No significant changes detected')}</div><div class="gd-empty-state-sub">${t('All tracked metrics are within normal month-over-month variation.')}</div></div>`}`;
}

/* ══════════════════════════════════════════════════════
   ACADEMIC ANALYTICS (dedicated quick-access page — reuses the SAME
   real computations already proven in Grade Overview's Advanced tab,
   rather than a second parallel implementation)
══════════════════════════════════════════════════════ */
function hAcademicAnalyticsPageView() {
  const overallAvg = hAvg(HEAD_DATA.students.map(s => s.avgGrade));
  const dist = hGradeDistribution(HEAD_DATA.students.map(s => s.id));
  const maxCount = Math.max(1, ...dist.map(b => b.count));
  const subjects = hAllSubjects();
  return `
    <div class="gd-stat-row">
      <div class="stat-card"><div class="stat-label">${t('Overall Average')}</div><div class="stat-val">${overallAvg}/20</div><div class="stat-icon green">${aIcon('bar-chart')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Classes')}</div><div class="stat-val">${HEAD_DATA.classes.length}</div><div class="stat-icon blue">${aIcon('school')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Subjects')}</div><div class="stat-val">${subjects.length}</div><div class="stat-icon purple">${aIcon('book')}</div></div>
    </div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Grade Distribution')}</div></div>
      <div class="card-body">${dist.map(b => `<div style="margin-bottom:10px"><div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:4px"><span>${b.label}</span><span style="color:var(--muted)">${b.count} ${t('students')}</span></div><div class="progress-track"><div class="progress-fill ${b.min>=16?'green':b.min>=12?'yellow':'red'}" style="width:${(b.count/maxCount*100).toFixed(0)}%"></div></div></div>`).join('')}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('By Class')}</div></div>
      <div class="card-body">${HEAD_DATA.classes.map(c => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hOpenGradesClass('${c.id}');authrenGoTo('grades')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hOpenGradesClass('${c.id}');authrenGoTo('grades')}"><span>${gdCommsEsc(c.name)}</span><span style="color:var(--muted)">${hClassAvgGrade(c.id) !== null ? hClassAvgGrade(c.id) + '/20' : '—'}</span></div>`).join('')}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('By Subject')}</div></div>
      <div class="card-body">${subjects.map(sub => { const classes = hSubjectClasses(sub); const avg = hAvg(classes.map(c => hClassAvgGrade(c.id)).filter(v => v !== null)); return `<div class="info-row"><span>${gdCommsEsc(t(sub))}</span><span style="color:var(--muted)">${avg !== null ? avg + '/20' : '—'}</span></div>`; }).join('')}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Full Academic Analytics')}</div><div class="card-action" onclick="authrenGoTo('grades');hSetGradesTab('advanced')">${t('Open')} →</div></div>
      <div class="card-body"><div style="font-size:11.5px;color:var(--muted)">${t('Trends, top/underperforming classes, student progression, and historical comparison are available in the full Academic Analytics view under Grades.')}</div></div></div>`;
}

/* ── School-Wide Performance Analytics (Performance Overview) ──
   Consolidates real summaries from every domain module into one view,
   reusing their existing computed helpers rather than recomputing. ── */
function hTeacherActivitySummary(teacherId) {
  const teacher = hGetTeacher(teacherId);
  if (!teacher) return null;
  const classIds = teacher.classIds;
  const homeworkCount = HEAD_DATA.homework.filter(h => classIds.includes(h.classId)).length;
  const examsGraded = HEAD_DATA.exams.filter(e => classIds.includes(e.classId) && Object.keys(e.scores).length > 0).length;
  const studentCount = classIds.reduce((sum, cid) => sum + hClassStudents(cid).length, 0);
  const classAvgs = classIds.map(cid => hClassAvgGrade(cid)).filter(v => v !== null);
  const academicOutcome = classAvgs.length ? Math.round(hAvg(classAvgs) * 10) / 10 : null;
  return { classCount: classIds.length, studentCount, homeworkCount, examsGraded, academicOutcome };
}
function hPerformanceOverviewTab() {
  const academicAvg = hAvg(HEAD_DATA.students.map(s => s.avgGrade));
  const attendanceAvg = hAvg(HEAD_DATA.students.map(s => s.attendanceRate));
  const hwCounts = HEAD_DATA.homework.reduce((acc, h) => { const c = hHomeworkCounts(h); acc.sub += c.submitted + c.late; acc.total += c.total; return acc; }, { sub:0, total:0 });
  const homeworkRate = hwCounts.total ? Math.round((hwCounts.sub / hwCounts.total) * 100) : null;
  const negativeIncidents = HEAD_DATA.behaviorRecords.filter(r => !hIsPositiveBehavior(r.category)).length;
  const totalCollected = HEAD_DATA.payments.filter(p => p.status === 'paid').reduce((s, p) => s + p.amount, 0);
  const totalDue = HEAD_DATA.payments.reduce((s, p) => s + p.amount, 0);
  const collectionRate = totalDue ? Math.round((totalCollected / totalDue) * 100) : null;
  const admissionsByStatus = {};
  HEAD_DATA.admissions.forEach(a => { admissionsByStatus[a.status] = (admissionsByStatus[a.status] || 0) + 1; });

  return `
    <div style="font-size:12px;color:var(--muted);margin-bottom:14px">${t('Institution-wide performance across every tracked domain.')}</div>
    <div class="card"><div class="card-header"><div class="card-title">${t('Academic')}</div><div class="card-action" onclick="authrenGoTo('academics-analytics')">${t('Open')} →</div></div>
      <div class="card-body"><div class="info-row"><span>${t('Overall Average')}</span><span>${academicAvg}/20</span></div></div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Attendance')}</div><div class="card-action" onclick="authrenGoTo('attendance')">${t('Open')} →</div></div>
      <div class="card-body"><div class="info-row"><span>${t('Overall Rate')}</span><span>${attendanceAvg}%</span></div></div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Homework')}</div><div class="card-action" onclick="authrenGoTo('homework')">${t('Open')} →</div></div>
      <div class="card-body"><div class="info-row"><span>${t('Completion Rate')}</span><span>${homeworkRate !== null ? homeworkRate + '%' : '—'}</span></div></div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Behavior')}</div><div class="card-action" onclick="authrenGoTo('behavior')">${t('Open')} →</div></div>
      <div class="card-body"><div class="info-row"><span>${t('Negative Incidents')}</span><span>${negativeIncidents}</span></div></div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Payments')}</div><div class="card-action" onclick="authrenGoTo('payments')">${t('Open')} →</div></div>
      <div class="card-body"><div class="info-row"><span>${t('Collection Rate')}</span><span>${collectionRate}%</span></div></div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Admissions')}</div><div class="card-action" onclick="authrenGoTo('admissions')">${t('Open')} →</div></div>
      <div class="card-body">${Object.keys(admissionsByStatus).map(st => `<div class="info-row"><span>${t(H_ADMISSION_STATUS_META[st].label)}</span><span style="color:var(--muted)">${admissionsByStatus[st]}</span></div>`).join('')}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Teacher Activity')}</div><div class="card-action" onclick="authrenGoTo('teachers');hSetTeachersTab('analytics')">${t('Open')} →</div></div>
      <div class="card-body">${HEAD_DATA.teachers.slice(0, 3).map(te => { const s = hTeacherActivitySummary(te.id); return `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hOpenTeacherProfile('${te.id}');authrenGoTo('teachers')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hOpenTeacherProfile('${te.id}');authrenGoTo('teachers')}"><span>${gdCommsEsc(te.name)}<div style="font-size:11px;color:var(--muted)">${s.classCount} ${t('classes')} · ${s.studentCount} ${t('students')}</div></span><span style="color:var(--muted);font-size:12px">${s.homeworkCount} ${t('homework')} · ${s.examsGraded} ${t('graded')}</span></div>`; }).join('')}
      <div style="font-size:11px;color:var(--muted);margin-top:8px">${t('Full workload breakdown by teacher, class, and subject is available in Teacher Analytics.')}</div></div></div>`;
}

/* ── Problem Detection ──
   Identifies concrete institutional problems from current-state
   thresholds (distinct from Important Changes' month-over-month deltas)
   — each with a title, severity, affected group, metric, explanation,
   and a recommended area to inspect. ── */
function hDetectProblems() {
  const problems = [];
  HEAD_DATA.classes.forEach(c => {
    const roster = hClassStudents(c.id).map(s => s.id);
    const attRate = hAggregateAttendance(roster, H_ATTENDANCE_DAYS).rate;
    if (attRate !== null && attRate < 85) {
      const prevDays = H_ATTENDANCE_DAYS.filter(d => d.startsWith('2026-02'));
      const prevAttRate = prevDays.length ? hAggregateAttendance(roster, prevDays).rate : null;
      problems.push({ title:`${t('Unusually Low Attendance')}: ${c.name}`, severity: attRate < 75 ? 'high' : 'medium', affectedGroup:c.name, metric:`${attRate}%`, previousValue: prevAttRate !== null ? `${prevAttRate}%` : null, explanation:`${c.name} ${t('has an attendance rate of')} ${attRate}%, ${t('below the expected 85% threshold.')}`, route:'attendance' });
    }
    const avgGrade = hClassAvgGrade(c.id);
    if (avgGrade !== null && avgGrade < 12) {
      problems.push({ title:`${t('Low Academic Performance')}: ${c.name}`, severity: avgGrade < 10 ? 'high' : 'medium', affectedGroup:c.name, metric:`${avgGrade}/20`, explanation:`${c.name} ${t('has an average grade of')} ${avgGrade}/20, ${t('below the expected 12/20 threshold.')}`, route:'grades' });
    }
    const negCount = HEAD_DATA.behaviorRecords.filter(r => roster.includes(r.studentId) && !hIsPositiveBehavior(r.category)).length;
    if (negCount >= 3) {
      problems.push({ title:`${t('Elevated Behavior Incidents')}: ${c.name}`, severity: negCount >= 6 ? 'high' : 'medium', affectedGroup:c.name, metric:`${negCount} ${t('incidents')}`, explanation:`${c.name} ${t('has')} ${negCount} ${t('negative behavior incidents recorded this term.')}`, route:'behavior' });
    }
    const overdueCount = roster.filter(id => { const s = hGetStudent(id); return s && s.paymentStatus === 'overdue'; }).length;
    if (roster.length && overdueCount / roster.length >= 0.3) {
      problems.push({ title:`${t('Payment Collection Issue')}: ${c.name}`, severity: overdueCount / roster.length >= 0.5 ? 'high' : 'medium', affectedGroup:c.name, metric:`${overdueCount}/${roster.length} ${t('overdue')}`, explanation:`${Math.round(overdueCount/roster.length*100)}% ${t('of students in')} ${c.name} ${t('have overdue payments.')}`, route:'payments' });
    }
  });
  const repeatedAbsences = hStudentsWithRepeatedAbsences();
  if (repeatedAbsences.length) {
    problems.push({ title:t('Students with Repeated Absences'), severity: repeatedAbsences.length >= 5 ? 'high' : 'medium', affectedGroup:`${repeatedAbsences.length} ${t('students')}`, metric:`${repeatedAbsences.length}`, explanation:`${repeatedAbsences.length} ${t('students have 2 or more recorded absences this term.')}`, route:'attendance' });
  }
  HEAD_DATA.homework.forEach(h => {
    const c = hHomeworkCounts(h);
    const rate = c.total ? Math.round(((c.submitted + c.late) / c.total) * 100) : null;
    if (rate !== null && rate < 70 && h.dueDate < tISODate(new Date(2026, 2, 11))) {
      problems.push({ title:`${t('Low Homework Completion')}: ${h.title}`, severity: rate < 50 ? 'high' : 'medium', affectedGroup: hGetClass(h.classId) ? hGetClass(h.classId).name : '', metric:`${rate}%`, explanation:`"${h.title}" ${t('has a completion rate of only')} ${rate}%.`, route:'homework' });
    }
  });
  return problems.sort((a, b) => ({ high:0, medium:1, low:2 }[a.severity] - { high:0, medium:1, low:2 }[b.severity]));
}
function hProblemDetectionTab() {
  const problems = hDetectProblems();
  const severityMeta = { high:{cls:'overdue',label:'High'}, medium:{cls:'awaiting',label:'Medium'}, low:{cls:'resolved',label:'Low'} };
  return `
    <div style="font-size:12px;color:var(--muted);margin-bottom:14px">${t('Detected using fixed thresholds against current data — each problem shows its metric and recommended area to inspect.')}</div>
    ${problems.length ? problems.map(p => { const sm = severityMeta[p.severity]; return `<div class="card" style="margin-bottom:10px;cursor:pointer" role="button" tabindex="0" onclick="authrenGoTo('${p.route}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();authrenGoTo('${p.route}')}"><div class="card-body">
      <div style="display:flex;justify-content:space-between;align-items:flex-start">
        <div style="font-weight:700;font-size:13px">${gdCommsEsc(p.title)}</div>
        <span class="status-pill ${sm.cls}">${t(sm.label)}</span>
      </div>
      <div style="font-size:12px;color:var(--muted2);margin-top:6px">${gdCommsEsc(p.explanation)}</div>
      <div style="font-size:11px;color:var(--muted);margin-top:6px">${t('Affected')}: ${gdCommsEsc(p.affectedGroup)} · ${t('Current')}: ${gdCommsEsc(p.metric)}${p.previousValue ? ` · ${t('Previous')}: ${gdCommsEsc(p.previousValue)}` : ''} · ${t('Inspect')}: ${t(p.route.charAt(0).toUpperCase()+p.route.slice(1))}</div>
    </div></div>`; }).join('') : `<div class="gd-empty-state"><div class="gd-empty-state-title">${t('No problems detected')}</div><div class="gd-empty-state-sub">${t('All classes and metrics are currently within expected thresholds.')}</div></div>`}`;
}

/* ══════════════════════════════════════════════════════
   STUDENT RISK INDICATORS (multi-signal, explainable scoring)
══════════════════════════════════════════════════════ */
function hComputeStudentRisk(student) {
  const reasons = [];
  const absenceCount = H_ATTENDANCE_DAYS.filter(d => { const st = hAttendanceStatusFor(student.id, d); return st === 'absent' || st === 'excused'; }).length;
  if (absenceCount >= 2) reasons.push({ type:'attendance', label:`${t('Repeated absences')} (${absenceCount})` });

  if (student.avgGrade < 12) reasons.push({ type:'grades', label:`${t('Low average grade')} (${student.avgGrade}/20)` });
  const trend = hStudentGradeTrendH(student.id);
  if (trend !== null && trend < -5) reasons.push({ type:'grades', label:`${t('Declining grade trend')} (${trend}%)` });

  const missingHw = HEAD_DATA.homework.filter(h => h.classId === student.classId && hHomeworkStatus(h, student.id) === 'missing').length;
  if (missingHw >= 1) reasons.push({ type:'homework', label:`${t('Missing homework')} (${missingHw})` });

  const negBehavior = hStudentBehaviorRecordsH(student.id).filter(r => !hIsPositiveBehavior(r.category)).length;
  if (negBehavior >= 2) reasons.push({ type:'behavior', label:`${t('Repeated behavior incidents')} (${negBehavior})` });

  const signalTypes = new Set(reasons.map(r => r.type)).size;
  const level = signalTypes >= 3 ? 'high' : signalTypes === 2 ? 'medium' : signalTypes === 1 ? 'low' : 'none';
  return { level, reasons, signalTypes };
}
function hStudentRiskView() {
  const risks = HEAD_DATA.students.map(s => ({ student:s, risk: hComputeStudentRisk(s) })).filter(x => x.risk.level !== 'none');
  const levelOrder = { high:0, medium:1, low:2 };
  risks.sort((a, b) => levelOrder[a.risk.level] - levelOrder[b.risk.level]);
  const levelMeta = { high:{cls:'overdue',label:'High Risk'}, medium:{cls:'awaiting',label:'Medium Risk'}, low:{cls:'resolved',label:'Low Risk'} };
  const counts = { high:0, medium:0, low:0 };
  risks.forEach(r => counts[r.risk.level]++);

  return `
    <div class="gd-stat-row">
      <div class="stat-card"><div class="stat-label">${t('High Risk')}</div><div class="stat-val">${counts.high}</div><div class="stat-icon red">${aIcon('dot')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Medium Risk')}</div><div class="stat-val">${counts.medium}</div><div class="stat-icon yellow">${aIcon('dot')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Low Risk')}</div><div class="stat-val">${counts.low}</div><div class="stat-icon blue">${aIcon('dot')}</div></div>
    </div>
    <div style="font-size:11.5px;color:var(--muted);margin:14px 0">${t('Risk level reflects how many DIFFERENT warning signals combine for a student — attendance, grades, homework, and behavior. Multiple combined signals raise the risk level.')}</div>
    <div class="card"><div class="card-header"><div class="card-title">${t('Flagged Students')}</div></div>
      <div class="card-body">${risks.length ? risks.map(r => { const meta = levelMeta[r.risk.level]; return `<div class="card" style="margin-bottom:10px;background:var(--surface2);cursor:pointer" role="button" tabindex="0" onclick="hGoToStudentFromClass('${r.student.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hGoToStudentFromClass('${r.student.id}')}"><div class="card-body">
        <div style="display:flex;justify-content:space-between;align-items:center">
          <div style="font-weight:600;font-size:13px">${gdCommsEsc(hStudentFullName(r.student))}</div>
          <span class="status-pill ${meta.cls}">${t(meta.label)}</span>
        </div>
        <div style="font-size:11.5px;color:var(--muted);margin-top:6px">${r.risk.reasons.map(x => gdCommsEsc(x.label)).join(' · ')}</div>
      </div></div>`; }).join('') : `<div class="gd-empty-state"><div class="gd-empty-state-title">${t('No students currently flagged')}</div><div class="gd-empty-state-sub">${t('No combined warning signals detected across the roster.')}</div></div>`}</div></div>`;
}

/* ══════════════════════════════════════════════════════
   TEACHER ANALYTICS (sections 43+44 — Classes, Students, Workload,
   Homework/Grade-entry activity, Academic outcomes; plus Workload by
   Class and by Subject)
══════════════════════════════════════════════════════ */
function hTeacherAnalyticsTab() {
  const teacherRows = HEAD_DATA.teachers.map(te => ({ teacher:te, summary: hTeacherActivitySummary(te.id) })).sort((a, b) => b.summary.studentCount - a.summary.studentCount);
  const classWorkload = HEAD_DATA.classes.map(c => {
    const hwCount = HEAD_DATA.homework.filter(h => h.classId === c.id).length;
    const examCount = HEAD_DATA.exams.filter(e => e.classId === c.id).length;
    return { cls:c, hwCount, examCount, studentCount: hClassStudents(c.id).length };
  }).sort((a, b) => (b.hwCount + b.examCount) - (a.hwCount + a.examCount));
  const subjectWorkload = hAllSubjects().map(sub => {
    const teachersForSubject = HEAD_DATA.teachers.filter(te => te.subjects.includes(sub));
    const classesForSubject = hSubjectClasses(sub);
    const hwCount = HEAD_DATA.homework.filter(h => h.subject === sub).length;
    const examCount = HEAD_DATA.exams.filter(e => e.subject === sub).length;
    return { subject:sub, teacherCount: teachersForSubject.length, classCount: classesForSubject.length, hwCount, examCount };
  });

  return `
    <div class="card"><div class="card-header"><div class="card-title">${t('Workload by Teacher')}</div></div>
      <div class="card-body">${teacherRows.map(r => `<div class="card" style="margin-bottom:10px;background:var(--surface2);cursor:pointer" role="button" tabindex="0" onclick="hOpenTeacherProfile('${r.teacher.id}');hSetTeachersTab('directory')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hOpenTeacherProfile('${r.teacher.id}');hSetTeachersTab('directory')}"><div class="card-body">
        <div style="font-weight:600;font-size:13px">${gdCommsEsc(r.teacher.name)}</div>
        <div style="font-size:11px;color:var(--muted);margin-top:2px">${r.summary.classCount} ${t('classes')} · ${r.summary.studentCount} ${t('students')}</div>
        <div style="display:flex;gap:14px;margin-top:8px;font-size:11.5px;color:var(--muted2)">
          <span>${aIcon('book')} ${r.summary.homeworkCount} ${t('homework')}</span>
          <span>${aIcon('edit')} ${r.summary.examsGraded} ${t('graded')}</span>
          <span>${aIcon('bar-chart')} ${r.summary.academicOutcome !== null ? r.summary.academicOutcome + '/20' : t('No data')}</span>
        </div>
      </div></div>`).join('')}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Workload by Class')}</div></div>
      <div class="card-body">${classWorkload.map(w => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hGoToClassFromDashboard('${w.cls.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hGoToClassFromDashboard('${w.cls.id}')}"><span>${gdCommsEsc(w.cls.name)}<div style="font-size:11px;color:var(--muted)">${w.studentCount} ${t('students')}</div></span><span style="color:var(--muted);font-size:12px">${w.hwCount} ${t('homework')} · ${w.examCount} ${t('exams')}</span></div>`).join('')}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Workload by Subject')}</div></div>
      <div class="card-body">${subjectWorkload.map(w => `<div class="info-row"><span>${gdCommsEsc(t(w.subject))}<div style="font-size:11px;color:var(--muted)">${w.teacherCount} ${t('teacher(s)')} · ${w.classCount} ${t('class(es)')}</div></span><span style="color:var(--muted);font-size:12px">${w.hwCount} ${t('homework')} · ${w.examCount} ${t('exams')}</span></div>`).join('')}</div></div>`;
}

/* ── Advanced Behavioral Analytics (trend chart + historical comparison) ── */
function hBehaviorAdvancedTab() {
  const dailyCounts = {};
  HEAD_DATA.behaviorRecords.forEach(r => { if (!hIsPositiveBehavior(r.category)) dailyCounts[r.date] = (dailyCounts[r.date] || 0) + 1; });
  const trendPoints = H_ATTENDANCE_DAYS.map(d => ({ label: d.slice(5), value: dailyCounts[d] || 0 }));
  const maxVal = Math.max(1, ...trendPoints.map(p => p.value));

  const cutoff = '2026-03-01';
  const beforeCount = HEAD_DATA.behaviorRecords.filter(r => !hIsPositiveBehavior(r.category) && r.date < cutoff).length;
  const afterCount = HEAD_DATA.behaviorRecords.filter(r => !hIsPositiveBehavior(r.category) && r.date >= cutoff).length;
  const hasBothPeriods = H_ATTENDANCE_DAYS.some(d => d < cutoff) && H_ATTENDANCE_DAYS.some(d => d >= cutoff);

  return `
    <div class="card"><div class="card-header"><div class="card-title">${t('Negative Incident Trend')}</div></div>
      <div class="card-body">
        ${trendPoints.some(p => p.value > 0) ? trendPoints.map(p => `<div style="margin-bottom:8px"><div style="display:flex;justify-content:space-between;font-size:11.5px;margin-bottom:3px"><span>${p.label}</span><span style="color:var(--muted)">${p.value}</span></div><div class="progress-track"><div class="progress-fill ${p.value>0?'red':'green'}" style="width:${(p.value/maxVal*100).toFixed(0)}%"></div></div></div>`).join('') : `<div class="gd-empty-mini">${t('No negative incidents recorded in this period.')}</div>`}
      </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Historical Comparison')}</div></div>
      <div class="card-body">
        ${hasBothPeriods ? `
          <div class="info-row"><span>${t('Before')} ${cutoff}</span><span>${beforeCount} ${t('incidents')}</span></div>
          <div class="info-row"><span>${t('From')} ${cutoff}</span><span>${afterCount} ${t('incidents')}</span></div>
          <div style="font-size:11.5px;color:${afterCount<=beforeCount?'var(--green)':'var(--red)'};margin-top:6px">${afterCount<=beforeCount?'▼':'▲'} ${Math.abs(afterCount-beforeCount)} ${t('incidents')} ${afterCount<=beforeCount?t('fewer'):t('more')} ${t('in the most recent period')}</div>
        ` : `<div class="gd-empty-mini">${t('Not enough data spanning both periods to compare.')}</div>`}
      </div></div>`;
}

/* ── Advanced Payment Analytics ── */
function hPaymentAdvancedTab() {
  const byMonthCollected = {};
  const byMonthOverdue = {};
  HEAD_DATA.payments.forEach(p => {
    const m = p.date.slice(0, 7);
    if (p.status === 'paid') byMonthCollected[m] = (byMonthCollected[m] || 0) + p.amount;
    if (p.status === 'overdue') byMonthOverdue[m] = (byMonthOverdue[m] || 0) + p.amount;
  });
  const classComparison = HEAD_DATA.classes.map(c => {
    const ids = hClassStudents(c.id).map(s => s.id);
    const classPayments = HEAD_DATA.payments.filter(p => ids.includes(p.studentId));
    const total = classPayments.reduce((s, p) => s + p.amount, 0);
    const collected = classPayments.filter(p => p.status === 'paid').reduce((s, p) => s + p.amount, 0);
    return { cls:c, rate: total ? Math.round((collected / total) * 100) : null };
  }).sort((a, b) => (b.rate || 0) - (a.rate || 0));
  const methodCounts = {};
  HEAD_DATA.payments.filter(p => p.status === 'paid').forEach(p => { methodCounts[p.method] = (methodCounts[p.method] || 0) + 1; });
  const totalOutstanding = HEAD_DATA.payments.filter(p => p.status === 'pending' || p.status === 'overdue').reduce((s, p) => s + p.amount, 0);
  const totalOverdue = HEAD_DATA.payments.filter(p => p.status === 'overdue').reduce((s, p) => s + p.amount, 0);
  const totalPending = HEAD_DATA.payments.filter(p => p.status === 'pending').reduce((s, p) => s + p.amount, 0);

  const cur = '2026-03', prev = '2026-02';
  const curCollected = byMonthCollected[cur] || 0, prevCollected = byMonthCollected[prev] || 0;

  return `
    <div class="card"><div class="card-header"><div class="card-title">${t('Collection Trend by Month')}</div></div>
      <div class="card-body">${Object.keys(byMonthCollected).sort().map(m => `<div class="info-row"><span>${m}</span><span style="color:var(--green)">${hCurrency(byMonthCollected[m])}</span></div>`).join('') || `<div class="gd-empty-mini">${t('No data yet.')}</div>`}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Outstanding Balances')}</div></div>
      <div class="card-body">
        <div class="info-row"><span>${t('Total Outstanding')}</span><span>${hCurrency(totalOutstanding)}</span></div>
        <div class="info-row"><span>${t('Pending')}</span><span>${hCurrency(totalPending)}</span></div>
        <div class="info-row"><span>${t('Overdue')}</span><span style="color:var(--red)">${hCurrency(totalOverdue)}</span></div>
      </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Overdue Trend by Month')}</div></div>
      <div class="card-body">${Object.keys(byMonthOverdue).length ? Object.keys(byMonthOverdue).sort().map(m => `<div class="info-row"><span>${m}</span><span style="color:var(--red)">${hCurrency(byMonthOverdue[m])}</span></div>`).join('') : `<div class="gd-empty-mini">${t('No overdue amounts recorded.')}</div>`}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Class Comparison')}</div><span style="font-size:12px;color:var(--muted)">${t('Collection rate')}</span></div>
      <div class="card-body">${classComparison.map(c => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="authrenGoTo('payments');hSetPaymentsTab('history');hSetPaymentClassFilter('${c.cls.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hSetPaymentsTab('history');hSetPaymentClassFilter('${c.cls.id}')}"><span>${gdCommsEsc(c.cls.name)}</span><span style="color:var(--muted)">${c.rate !== null ? c.rate + '%' : '—'}</span></div>`).join('')}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Payment Method Distribution')}</div></div>
      <div class="card-body">${Object.keys(methodCounts).length ? Object.keys(methodCounts).map(m => `<div class="info-row"><span>${gdCommsEsc(m)}</span><span style="color:var(--muted)">${methodCounts[m]}</span></div>`).join('') : `<div class="gd-empty-mini">${t('No paid transactions yet.')}</div>`}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Historical Comparison')}</div></div>
      <div class="card-body">
        <div class="info-row"><span>${t('Feb 2026 Collected')}</span><span>${hCurrency(prevCollected)}</span></div>
        <div class="info-row"><span>${t('Mar 2026 Collected')}</span><span>${hCurrency(curCollected)}</span></div>
        ${prevCollected || curCollected ? `<div style="font-size:11.5px;color:${curCollected>=prevCollected?'var(--green)':'var(--red)'};margin-top:6px">${curCollected>=prevCollected?'▲':'▼'} ${hCurrency(Math.abs(curCollected-prevCollected))} ${curCollected>=prevCollected?t('increase'):t('decrease')}</div>` : ''}
      </div></div>`;
}

/* ── Advanced Admissions Analytics ── */
function hAdmissionsAdvancedTab() {
  const total = HEAD_DATA.admissions.length;
  const statusCounts = {};
  HEAD_DATA.admissions.forEach(a => { statusCounts[a.status] = (statusCounts[a.status] || 0) + 1; });
  const accepted = statusCounts.accepted || 0;
  const conversionRate = total ? Math.round((accepted / total) * 100) : null;
  const byMonth = {};
  HEAD_DATA.admissions.forEach(a => { const m = a.submittedDate.slice(0, 7); byMonth[m] = (byMonth[m] || 0) + 1; });
  const bySource = {};
  HEAD_DATA.admissions.forEach(a => { const src = a.source || t('Unknown'); bySource[src] = (bySource[src] || 0) + 1; });

  const cur = '2026-03', prev = '2026-02';
  const curCount = HEAD_DATA.admissions.filter(a => a.submittedDate.startsWith(cur)).length;
  const prevCount = HEAD_DATA.admissions.filter(a => a.submittedDate.startsWith(prev)).length;

  return `
    <div class="gd-stat-row">
      <div class="stat-card"><div class="stat-label">${t('Total Applications')}</div><div class="stat-val">${total}</div><div class="stat-icon blue">${aIcon('clipboard')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Conversion Rate')}</div><div class="stat-val">${conversionRate !== null ? conversionRate + '%' : '—'}</div><div class="stat-icon green">${aIcon('check-circle')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Accepted')}</div><div class="stat-val">${accepted}</div><div class="stat-icon purple">${aIcon('graduation-cap')}</div></div>
    </div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('By Status')}</div></div>
      <div class="card-body">${Object.keys(statusCounts).map(st => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hSetAdmissionsTab('list');hSetAdmissionStatusFilter('${st}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hSetAdmissionsTab('list');hSetAdmissionStatusFilter('${st}')}"><span>${t(H_ADMISSION_STATUS_META[st].label)}</span><span style="color:var(--muted)">${statusCounts[st]}</span></div>`).join('')}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Applications by Month')}</div></div>
      <div class="card-body">${Object.keys(byMonth).sort().map(m => `<div class="info-row"><span>${m}</span><span style="color:var(--muted)">${byMonth[m]}</span></div>`).join('')}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('By Source')}</div></div>
      <div class="card-body">${Object.keys(bySource).map(src => `<div class="info-row"><span>${gdCommsEsc(t(src))}</span><span style="color:var(--muted)">${bySource[src]}</span></div>`).join('')}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Historical Comparison')}</div></div>
      <div class="card-body">
        <div class="info-row"><span>${t('Feb 2026')}</span><span>${prevCount} ${t('applications')}</span></div>
        <div class="info-row"><span>${t('Mar 2026')}</span><span>${curCount} ${t('applications')}</span></div>
      </div></div>`;
}

/* ── Advanced Orientation Analytics ── */
function hOrientationAdvancedTab() {
  const total = HEAD_DATA.orientations.length;
  const upcoming = HEAD_DATA.orientations.filter(o => o.status === 'scheduled').length;
  const statusCounts = {};
  HEAD_DATA.orientations.forEach(o => { statusCounts[o.status] = (statusCounts[o.status] || 0) + 1; });

  const completedSessions = HEAD_DATA.orientations.filter(o => o.status === 'completed');
  let totalParticipants = 0, totalAttended = 0;
  HEAD_DATA.orientations.forEach(o => { totalParticipants += o.participantIds.length; });
  completedSessions.forEach(o => { o.participantIds.forEach(pid => { if (o.attended[pid]) totalAttended++; }); });
  const completedParticipantCount = completedSessions.reduce((s, o) => s + o.participantIds.length, 0);
  const attendanceRate = completedParticipantCount ? Math.round((totalAttended / completedParticipantCount) * 100) : null;

  const allParticipantIds = new Set();
  HEAD_DATA.orientations.forEach(o => o.participantIds.forEach(pid => allParticipantIds.add(pid)));
  const followUpAccepted = Array.from(allParticipantIds).filter(pid => { const a = hGetAdmission(pid); return a && a.status === 'accepted'; }).length;

  return `
    <div class="gd-stat-row">
      <div class="stat-card"><div class="stat-label">${t('Total Sessions')}</div><div class="stat-val">${total}</div><div class="stat-icon blue">${aIcon('calendar')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Upcoming')}</div><div class="stat-val">${upcoming}</div><div class="stat-icon yellow">${aIcon('clock')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Total Participants')}</div><div class="stat-val">${totalParticipants}</div><div class="stat-icon purple">${aIcon('users')}</div></div>
    </div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Session Status')}</div></div>
      <div class="card-body">${Object.keys(statusCounts).map(st => `<div class="info-row"><span>${t(H_ORIENTATION_STATUS_META[st].label)}</span><span style="color:var(--muted)">${statusCounts[st]}</span></div>`).join('')}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Attendance Rate')}</div><span style="font-size:12px;color:var(--muted)">${t('Completed sessions only')}</span></div>
      <div class="card-body">${attendanceRate !== null ? `<div class="info-row"><span>${t('Attended')}</span><span>${totalAttended}/${completedParticipantCount} (${attendanceRate}%)</span></div>` : `<div class="gd-empty-mini">${t('No completed sessions yet to compute attendance from.')}</div>`}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Follow-up Status')}</div><span style="font-size:12px;color:var(--muted)">${t('Participants later accepted')}</span></div>
      <div class="card-body"><div class="info-row"><span>${t('Accepted After Orientation')}</span><span>${followUpAccepted}/${allParticipantIds.size}</span></div></div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Upcoming Events')}</div></div>
      <div class="card-body">${HEAD_DATA.orientations.filter(o => o.status === 'scheduled').sort((a,b) => a.date.localeCompare(b.date)).map(o => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hSetOrientationTab('list');hOpenOrientationDetail('${o.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hSetOrientationTab('list');hOpenOrientationDetail('${o.id}')}"><span>${gdCommsEsc(o.title)}<div style="font-size:11px;color:var(--muted)">${o.date}</div></span><span style="color:var(--muted);font-size:12px">${o.participantIds.length} ${t('participants')}</span></div>`).join('') || `<div class="gd-empty-mini">${t('No upcoming sessions.')}</div>`}</div></div>`;
}

/* ══════════════════════════════════════════════════════
   ADVANCED AUDIT FUNCTIONALITY
   Records real actions as they happen across Students, Teachers, Exams,
   Communication, Imports, and Account Generation — with search/filter.
══════════════════════════════════════════════════════ */
const H_AUDIT_ACTIONS = ['Student Created', 'Student Edited', 'Teacher Assigned', 'Exam Created', 'Exam Results Locked', 'Communication Sent', 'Import Completed', 'Account Generated'];
function hAuditView() {
  return `<div id="h-audit-content">${hAuditBody()}</div>`;
}
function hAuditBody() {
  const s = hState.audit;
  const objectTypes = Array.from(new Set(HEAD_DATA.auditLog.map(a => a.objectType)));
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Audit Log')}</div></div>
    <div class="card-body">
      <input class="gd-comm-search-input" type="text" placeholder="${t('Search by affected object...')}" value="${gdCommsEsc(s.search)}" oninput="hSetAuditSearch(this.value)">
      <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:10px">
        <select onchange="hSetAuditActionFilter(this.value)" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
          <option value="all" ${s.filterAction==='all'?'selected':''}>${t('All Actions')}</option>
          ${H_AUDIT_ACTIONS.map(a => `<option value="${a}" ${a===s.filterAction?'selected':''}>${t(a)}</option>`).join('')}
        </select>
        <select onchange="hSetAuditObjectTypeFilter(this.value)" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
          <option value="all" ${s.filterObjectType==='all'?'selected':''}>${t('All Object Types')}</option>
          ${objectTypes.map(ot => `<option value="${ot}" ${ot===s.filterObjectType?'selected':''}>${gdCommsEsc(ot)}</option>`).join('')}
        </select>
      </div>
    </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Recorded Actions')}</div><span style="font-size:12px;color:var(--muted)" id="h-audit-count">${hFilteredAudit().length} ${t('of')} ${HEAD_DATA.auditLog.length}</span></div>
      <div class="card-body" id="h-audit-list-results">${hAuditListResultsBlock()}</div></div>`;
}
function hFilteredAudit() {
  const s = hState.audit;
  let list = HEAD_DATA.auditLog.slice();
  if (s.filterAction !== 'all') list = list.filter(a => a.action === s.filterAction);
  if (s.filterObjectType !== 'all') list = list.filter(a => a.objectType === s.filterObjectType);
  const q = s.search.trim().toLowerCase();
  if (q) list = list.filter(a => a.objectLabel.toLowerCase().includes(q));
  return list;
}
function hAuditListResultsBlock() {
  const list = hFilteredAudit();
  if (!list.length) return `<div class="gd-empty-mini">${t('No audit records match your search or filters.')}</div>`;
  return list.map(a => `<div class="card" style="margin-bottom:10px;background:var(--surface2)"><div class="card-body">
    <div style="display:flex;justify-content:space-between;align-items:flex-start">
      <div style="font-weight:600;font-size:13px">${t(a.action)}</div>
      <span style="font-size:11px;color:var(--muted)">${a.date} · ${a.time}</span>
    </div>
    <div style="font-size:12px;color:var(--muted2);margin-top:4px">${gdCommsEsc(a.objectType)}: ${gdCommsEsc(a.objectLabel)}</div>
    ${a.previousValue || a.newValue ? `<div style="font-size:11px;color:var(--muted);margin-top:6px">${a.previousValue ? `${t('Previous')}: ${gdCommsEsc(a.previousValue)} · ` : ''}${a.newValue ? `${t('New')}: ${gdCommsEsc(a.newValue)}` : ''}</div>` : ''}
    <div style="font-size:11px;color:var(--muted);margin-top:4px">${t('By')}: ${gdCommsEsc(a.user)}</div>
  </div></div>`).join('');
}
function hSetAuditSearch(v) { hState.audit.search = v; hRefreshAuditResults(); }
function hSetAuditActionFilter(v) { hState.audit.filterAction = v; hRefreshAuditResults(); }
function hSetAuditObjectTypeFilter(v) { hState.audit.filterObjectType = v; hRefreshAuditResults(); }
function hRefreshAuditResults() {
  const el = document.getElementById('h-audit-list-results');
  if (el) el.innerHTML = hAuditListResultsBlock();
  const countEl = document.getElementById('h-audit-count');
  if (countEl) countEl.textContent = `${hFilteredAudit().length} ${t('of')} ${HEAD_DATA.auditLog.length}`;
}

/* ══════════════════════════════════════════════════════
   COMBINED INSIGHTS (Full School Intelligence, section 52)
   Explicit, transparent cross-domain rules — e.g. "Attendance down +
   repeated absences -> attendance warning" — with the reasoning always
   shown alongside the real numbers behind it. No opaque scoring.
══════════════════════════════════════════════════════ */
function hComputeCombinedInsights() {
  const insights = [];
  const monthComp = hComputeMonthComparison();
  const att = monthComp.find(c => c.id === 'attendance');
  const academic = monthComp.find(c => c.id === 'academic');
  const homework = monthComp.find(c => c.id === 'homework');
  const payments = monthComp.find(c => c.id === 'payments');
  const repeated = hStudentsWithRepeatedAbsences();

  if (att.current !== null && att.previous !== null && att.current < att.previous && repeated.length > 0) {
    insights.push({
      title:t('Attendance Warning'), route:'attendance',
      rule:t('Attendance is declining AND multiple students have repeated absences'),
      evidence:`${t('Attendance')}: ${att.previous}% → ${att.current}% · ${repeated.length} ${t('students with 2+ absences')}`,
    });
  }
  if (academic.current !== null && academic.previous !== null && academic.current < academic.previous && homework.current !== null && homework.previous !== null && homework.current < homework.previous) {
    insights.push({
      title:t('Academic Risk'), route:'grades',
      rule:t('Average grades are declining AND homework completion is also declining'),
      evidence:`${t('Academic Performance')}: ${academic.previous}% → ${academic.current}% · ${t('Homework Completion')}: ${homework.previous}% → ${homework.current}%`,
    });
  }
  if (payments.current !== null && payments.previous !== null && payments.current < payments.previous) {
    insights.push({
      title:t('Financial Warning'), route:'payments',
      rule:t('Payment collection has decreased compared to the previous month'),
      evidence:`${t('Collected')}: ${hCurrency(payments.previous)} → ${hCurrency(payments.current)}`,
    });
  }
  return insights;
}
function hCombinedInsightsTab() {
  const insights = hComputeCombinedInsights();
  return `
    <div style="font-size:12px;color:var(--muted);margin-bottom:14px">${t('Deterministic rules connecting multiple real data sources — each insight states exactly which condition triggered it and the real numbers behind it. Never an unexplained score.')}</div>
    ${insights.length ? insights.map(i => `<div class="card" style="margin-bottom:10px;cursor:pointer" role="button" tabindex="0" onclick="authrenGoTo('${i.route}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();authrenGoTo('${i.route}')}"><div class="card-body">
      <div style="font-weight:700;font-size:13px">${gdCommsEsc(i.title)}</div>
      <div style="font-size:12px;color:var(--muted2);margin-top:6px">${t('Rule')}: ${gdCommsEsc(i.rule)}</div>
      <div style="font-size:11.5px;color:var(--muted);margin-top:6px">${gdCommsEsc(i.evidence)}</div>
    </div></div>`).join('') : `<div class="gd-empty-state"><div class="gd-empty-state-title">${t('No combined warning conditions currently met')}</div><div class="gd-empty-state-sub">${t('None of the tracked cross-domain rules are currently triggered by real data.')}</div></div>`}`;
}

/* ══════════════════════════════════════════════════════
   SCHOOL FORECASTING (section 56)
   Simple, transparent linear extrapolation from the real recent
   month-over-month trend — explicitly labeled as an estimate, never
   presented as an external prediction service.
══════════════════════════════════════════════════════ */
function hComputeForecasts() {
  const comp = hComputeMonthComparison();
  return comp.map(c => {
    if (c.current === null || c.previous === null) return { ...c, forecast:null };
    const delta = c.current - c.previous;
    let forecast = c.current + delta;
    if (c.unit === '%') forecast = Math.max(0, Math.min(100, Math.round(forecast)));
    else if (c.unit === 'MAD') forecast = Math.max(0, Math.round(forecast));
    else forecast = Math.max(0, Math.round(forecast));
    return { ...c, forecast };
  });
}
function hForecastingTab() {
  const forecasts = hComputeForecasts();
  return `
    <div style="background:rgba(217,119,6,0.1);border:1px solid rgba(217,119,6,0.3);border-radius:10px;padding:10px 12px;font-size:11.5px;color:var(--muted2);margin-bottom:14px">${aIcon('alert-triangle')} ${t('These are simple estimates based on the recent month-over-month trend in the available frontend data — not external prediction services. Treat them as a rough planning signal only.')}</div>
    ${forecasts.map(f => {
      if (f.forecast === null) return `<div class="card" style="margin-bottom:10px"><div class="card-body">
        <div style="font-weight:600;font-size:13px">${t(f.label)}</div>
        <div style="font-size:11.5px;color:var(--muted);margin-top:4px">${t('Not enough historical data yet to estimate a trend.')}</div>
      </div></div>`;
      return `<div class="card" style="margin-bottom:10px;cursor:pointer" role="button" tabindex="0" onclick="authrenGoTo('${f.route}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();authrenGoTo('${f.route}')}"><div class="card-body">
        <div style="font-weight:600;font-size:13px">${t(f.label)}</div>
        <div style="display:flex;gap:14px;margin-top:6px;font-size:12px;color:var(--muted)">
          <span>${t('Feb')}: ${hFormatMetricValue(f.previous, f.unit)}</span>
          <span>${t('Mar')}: ${hFormatMetricValue(f.current, f.unit)}</span>
          <span style="color:var(--yellow)">${t('Est. Apr')}: ${hFormatMetricValue(f.forecast, f.unit)}</span>
        </div>
      </div></div>`;
    }).join('')}`;
}

/* ══════════════════════════════════════════════════════
   ADVANCED ADMINISTRATION / INSTITUTION CONFIGURATION
   Settings that genuinely change frontend behavior: institution profile
   (shown on the Dashboard header and every Receipt) and the admin
   profile (used as the real sender name on new Communications and the
   real actor on new Audit entries) — rather than decorative toggles
   with no effect. Centralizes links to Accounts, Import, and Audit,
   which already exist as their own full modules.
══════════════════════════════════════════════════════ */
function hConfigView() {
  return `<div id="h-config-content">${hConfigBody()}</div>`;
}
function hConfigBody() {
  return hState.config.editing ? hConfigEditForm() : hConfigDisplayScreen();
}
function hConfigDisplayScreen() {
  const inst = HEAD_DATA.institution;
  const admin = HEAD_DATA.adminProfile;
  const settings = HEAD_DATA.settings;
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Institution Settings')}</div><button class="st-btn ghost sm" onclick="hOpenConfigEdit()">${t('Edit')}</button></div>
    <div class="card-body">
      <div style="font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Institution Profile')}</div>
      ${settings.logoDataUrl ? `<div style="margin-bottom:10px"><img src="${settings.logoDataUrl}" alt="${t('Institution logo')}" style="width:64px;height:64px;border-radius:14px;object-fit:cover"></div>` : ''}
      <div class="info-row"><span>${t('Name')}</span><span>${gdCommsEsc(inst.name)}</span></div>
      <div class="info-row"><span>${t('Type')}</span><span>${gdCommsEsc(inst.type)}</span></div>
      <div class="info-row"><span>${t('Address')}</span><span>${gdCommsEsc(inst.address)}</span></div>
      <div class="info-row"><span>${t('Phone')}</span><span>${gdCommsEsc(inst.phone)}</span></div>
      <div class="info-row"><span>${t('Email')}</span><span>${gdCommsEsc(inst.email)}</span></div>
      <div class="info-row"><span>${t('Academic Year')}</span><span>${gdCommsEsc(inst.academicYear)}</span></div>
      <div class="info-row"><span>${t('Current Term')}</span><span>${gdCommsEsc(inst.currentTerm)}</span></div>
      <div style="font-size:12.5px;font-weight:600;margin:16px 0 8px">${t('Administrator Profile')}</div>
      <div style="font-size:11px;color:var(--muted);margin-bottom:8px">${t('Used as the sender name on new communications and the recorded actor on new audit entries.')}</div>
      <div class="info-row"><span>${t('Name')}</span><span>${gdCommsEsc(admin.name)}</span></div>
      <div class="info-row"><span>${t('Title')}</span><span>${gdCommsEsc(admin.title)}</span></div>
    </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Grading & Attendance Configuration')}</div></div>
      <div class="card-body">
        <div style="font-size:11px;color:var(--muted);margin-bottom:8px">${t('These thresholds determine which students are flagged as "Needing Attention" throughout the app — Students, Grade Overview, Problem Detection, and the Dashboard all use these live.')}</div>
        <div class="info-row"><span>${t('Pass / Attention Threshold')}</span><span>${settings.passThreshold}/20</span></div>
        <div class="info-row"><span>${t('Attendance Threshold')}</span><span>${settings.attendanceThreshold}%</span></div>
      </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Campuses')}</div></div>
      <div class="card-body">
        <div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hSetDashboardCampus('all');authrenGoTo('home')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hSetDashboardCampus('all');authrenGoTo('home')}"><span>${t('All Campuses')}</span><span style="color:var(--muted);font-size:12px">${HEAD_DATA.students.length} ${t('students')}</span></div>
        ${HEAD_DATA.campuses.map(c => { const students = hCampusStudents(c.id); const teachers = hCampusTeachers(c.id); const classes = hCampusClasses(c.id); return `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hSetDashboardCampus('${c.id}');authrenGoTo('home')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hSetDashboardCampus('${c.id}');authrenGoTo('home')}">
          <span>${gdCommsEsc(c.name)}<div style="font-size:11px;color:var(--muted)">${gdCommsEsc(c.address)}</div></span>
          <span style="text-align:right;color:var(--muted);font-size:12px">${students.length} ${t('students')}<div style="margin-top:2px">${teachers.length} ${t('teachers')} · ${classes.length} ${t('classes')}</div></span>
        </div>`; }).join('')}
      </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Administration')}</div></div>
      <div class="card-body">
        <div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="authrenGoTo('accounts')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();authrenGoTo('accounts')}"><span>${aIcon('user')} ${t('Account Generation')}</span><span class="card-action">${t('Open')} →</span></div>
        <div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="authrenGoTo('import')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();authrenGoTo('import')}"><span>${aIcon('inbox')} ${t('Import Tools')}</span><span class="card-action">${t('Open')} →</span></div>
        <div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="authrenGoTo('audit')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();authrenGoTo('audit')}"><span>${aIcon('file-text')} ${t('Audit Log')}</span><span class="card-action">${t('Open')} →</span></div>
      </div></div>`;
}
function hHandleLogoFile(input) {
  const file = input.files && input.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = function(e) {
    HEAD_DATA.settings.logoDataUrl = e.target.result;
    const el = document.getElementById('h-config-content');
    if (el) el.innerHTML = hConfigBody();
    hShowToast(t('Logo updated — preview shown below.'));
  };
  reader.readAsDataURL(file);
}
function hOpenConfigEdit() {
  hState.config.editing = true;
  hState.config.error = '';
  const el = document.getElementById('h-config-content');
  if (el) el.innerHTML = hConfigBody();
}
function hCancelConfigEdit() {
  hState.config.editing = false;
  const el = document.getElementById('h-config-content');
  if (el) el.innerHTML = hConfigBody();
}
function hConfigEditForm() {
  const inst = HEAD_DATA.institution;
  const admin = HEAD_DATA.adminProfile;
  const err = hState.config.error;
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Edit Institution Settings')}</div></div>
    <div class="card-body">
      <div style="font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Institution Profile')}</div>
      <div class="st-field"><label>${t('Logo')} (${t('optional')})</label>
        ${HEAD_DATA.settings.logoDataUrl ? `<img src="${HEAD_DATA.settings.logoDataUrl}" alt="" style="width:48px;height:48px;border-radius:10px;object-fit:cover;margin-bottom:8px;display:block">` : ''}
        <input type="file" id="h-cfg-logo" accept="image/*" onchange="hHandleLogoFile(this)">
      </div>
      <div class="st-field"><label>${t('Name')}</label><input id="h-cfg-name" value="${gdCommsEsc(inst.name)}"></div>
      <div class="st-field"><label>${t('Address')}</label><input id="h-cfg-address" value="${gdCommsEsc(inst.address)}"></div>
      <div class="st-field"><label>${t('Phone')}</label><input id="h-cfg-phone" value="${gdCommsEsc(inst.phone)}"></div>
      <div class="st-field"><label>${t('Email')}</label><input id="h-cfg-email" type="email" value="${gdCommsEsc(inst.email)}"></div>
      <div class="st-field"><label>${t('Academic Year')}</label><input id="h-cfg-year" value="${gdCommsEsc(inst.academicYear)}"></div>
      <div class="st-field"><label>${t('Current Term')}</label><input id="h-cfg-term" value="${gdCommsEsc(inst.currentTerm)}"></div>
      <div style="font-size:12.5px;font-weight:600;margin:16px 0 8px">${t('Administrator Profile')}</div>
      <div class="st-field"><label>${t('Name')}</label><input id="h-cfg-adminname" value="${gdCommsEsc(admin.name)}"></div>
      <div class="st-field"><label>${t('Title')}</label><input id="h-cfg-admintitle" value="${gdCommsEsc(admin.title)}"></div>
      <div style="font-size:12.5px;font-weight:600;margin:16px 0 8px">${t('Grading & Attendance Configuration')}</div>
      <div class="st-field"><label>${t('Pass / Attention Threshold (out of 20)')}</label><input id="h-cfg-passthreshold" type="number" min="0" max="20" value="${HEAD_DATA.settings.passThreshold}"></div>
      <div class="st-field"><label>${t('Attendance Threshold (%)')}</label><input id="h-cfg-attthreshold" type="number" min="0" max="100" value="${HEAD_DATA.settings.attendanceThreshold}"></div>
      <div style="display:flex;gap:10px">
        <button class="st-btn" onclick="hSaveConfig()" ${hState.config.saving?'disabled':''}>${hState.config.saving ? `<span class="gd-spinner"></span>${t('Saving...')}` : t('Save Changes')}</button>
        <button class="st-btn ghost" onclick="hCancelConfigEdit()" ${hState.config.saving?'disabled':''}>${t('Cancel')}</button>
      </div>
      ${err ? `<div class="st-inline-msg err show" style="margin-top:12px">${err}</div>` : ''}
    </div></div>`;
}
function hSaveConfig() {
  const name = (document.getElementById('h-cfg-name').value || '').trim();
  const address = (document.getElementById('h-cfg-address').value || '').trim();
  const phone = (document.getElementById('h-cfg-phone').value || '').trim();
  const email = (document.getElementById('h-cfg-email').value || '').trim();
  const academicYear = (document.getElementById('h-cfg-year').value || '').trim();
  const currentTerm = (document.getElementById('h-cfg-term').value || '').trim();
  const adminName = (document.getElementById('h-cfg-adminname').value || '').trim();
  const adminTitle = (document.getElementById('h-cfg-admintitle').value || '').trim();
  const passThreshold = Number(document.getElementById('h-cfg-passthreshold').value);
  const attendanceThreshold = Number(document.getElementById('h-cfg-attthreshold').value);

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  let err = '';
  if (!name) err = t('Institution name is required.');
  else if (!email || !emailRegex.test(email)) err = t('Enter a valid institution email.');
  else if (!adminName) err = t("Administrator name is required.");
  else if (isNaN(passThreshold) || passThreshold < 0 || passThreshold > 20) err = t('Pass threshold must be between 0 and 20.');
  else if (isNaN(attendanceThreshold) || attendanceThreshold < 0 || attendanceThreshold > 100) err = t('Attendance threshold must be between 0 and 100.');

  hState.config.error = err;
  if (err) { const el = document.getElementById('h-config-content'); if (el) el.innerHTML = hConfigBody(); return; }

  hState.config.saving = true;
  const el0 = document.getElementById('h-config-content'); if (el0) el0.innerHTML = hConfigBody();
  setTimeout(() => {
    const oldName = HEAD_DATA.institution.name;
    Object.assign(HEAD_DATA.institution, { name, address, phone, email, academicYear, currentTerm });
    Object.assign(HEAD_DATA.adminProfile, { name:adminName, title:adminTitle });
    const oldPassThreshold = HEAD_DATA.settings.passThreshold;
    Object.assign(HEAD_DATA.settings, { passThreshold, attendanceThreshold });
    hLogAudit('Configuration Changed', 'Institution Settings', name, oldName, name);
    if (oldPassThreshold !== passThreshold) hLogAudit('Configuration Changed', 'Grading Threshold', 'Pass Threshold', oldPassThreshold + '/20', passThreshold + '/20');
    hState.config.saving = false;
    hState.config.editing = false;
    const el = document.getElementById('h-config-content'); if (el) el.innerHTML = hConfigBody();
    hShowToast(t('Institution settings updated successfully.'));
  }, 700);
}

/* ══════════════════════════════════════════════════════
   ADVANCED DOCUMENT MANAGEMENT (section 60)
   Real file upload via the File API, genuine categorization, search/
   filter, and association with students/classes/institution areas.
══════════════════════════════════════════════════════ */
function hGetDocument(id) { return HEAD_DATA.documents.find(d => d.id === id) || null; }
function hDocumentAssociationLabel(doc) {
  if (doc.associatedType === 'student') { const s = hGetStudent(doc.associatedId); return s ? hStudentFullName(s) : t('Unknown student'); }
  if (doc.associatedType === 'class') { const c = hGetClass(doc.associatedId); return c ? c.name : t('Unknown class'); }
  if (doc.associatedType === 'institution') return t('Institution-wide');
  return t('Unassociated');
}
function hDocumentsView() {
  return `<div id="h-documents-content">${hDocumentsBody()}</div>`;
}
function hDocumentsBody() {
  const s = hState.documents;
  if (s.screen === 'form') return hDocumentUploadForm();
  if (s.screen === 'detail') { const d = hGetDocument(s.docId); if (!d) { s.screen = 'list'; return hDocumentsBody(); } return hDocumentDetailScreen(d); }
  return hDocumentListScreen();
}
function hRefreshDocuments() { const el = document.getElementById('h-documents-content'); if (el) el.innerHTML = hDocumentsBody(); }
function hFilteredDocuments() {
  const s = hState.documents;
  let list = HEAD_DATA.documents.slice();
  if (s.filterCategory !== 'all') list = list.filter(d => d.category === s.filterCategory);
  if (s.filterAssociated !== 'all') list = list.filter(d => d.associatedType === s.filterAssociated);
  const q = s.search.trim().toLowerCase();
  if (q) list = list.filter(d => d.name.toLowerCase().includes(q));
  return list.sort((a, b) => b.uploadedDate.localeCompare(a.uploadedDate));
}
function hDocumentListScreen() {
  const s = hState.documents;
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Document Center')}</div><button class="st-btn sm" onclick="hOpenDocumentForm()">+ ${t('Upload Document')}</button></div>
    <div class="card-body">
      <input class="gd-comm-search-input" type="text" placeholder="${t('Search documents...')}" value="${gdCommsEsc(s.search)}" oninput="hSetDocumentSearch(this.value)">
      <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:10px">
        <select onchange="hSetDocumentCategoryFilter(this.value)" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
          <option value="all" ${s.filterCategory==='all'?'selected':''}>${t('All Categories')}</option>
          ${H_DOCUMENT_CATEGORIES.map(c => `<option value="${c}" ${c===s.filterCategory?'selected':''}>${t(c)}</option>`).join('')}
        </select>
        <select onchange="hSetDocumentAssociatedFilter(this.value)" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
          <option value="all" ${s.filterAssociated==='all'?'selected':''}>${t('All Associations')}</option>
          <option value="student" ${s.filterAssociated==='student'?'selected':''}>${t('Student')}</option>
          <option value="class" ${s.filterAssociated==='class'?'selected':''}>${t('Class')}</option>
          <option value="institution" ${s.filterAssociated==='institution'?'selected':''}>${t('Institution')}</option>
        </select>
      </div>
    </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Documents')}</div><span style="font-size:12px;color:var(--muted)" id="h-doc-count">${hFilteredDocuments().length} ${t('of')} ${HEAD_DATA.documents.length}</span></div>
      <div class="card-body" id="h-doc-list-results">${hDocumentListResultsBlock()}</div></div>`;
}
function hDocumentListResultsBlock() {
  const list = hFilteredDocuments();
  if (!list.length) return `<div class="gd-empty-mini">${t('No documents match your search or filters.')}</div>`;
  return list.map(d => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hOpenDocumentDetail('${d.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hOpenDocumentDetail('${d.id}')}">
    <span>${aIcon('file-text')} ${gdCommsEsc(d.name)}<div style="font-size:11px;color:var(--muted)">${gdCommsEsc(t(d.category))} · ${gdCommsEsc(hDocumentAssociationLabel(d))} · ${d.uploadedDate}</div></span><span style="color:var(--muted);font-size:12px">${gdCommsEsc(d.size)}</span>
  </div>`).join('');
}
function hSetDocumentSearch(v) { hState.documents.search = v; hRefreshDocumentListResults(); }
function hSetDocumentCategoryFilter(v) { hState.documents.filterCategory = v; hRefreshDocumentListResults(); }
function hSetDocumentAssociatedFilter(v) { hState.documents.filterAssociated = v; hRefreshDocumentListResults(); }
function hRefreshDocumentListResults() {
  const el = document.getElementById('h-doc-list-results');
  if (el) el.innerHTML = hDocumentListResultsBlock();
  const countEl = document.getElementById('h-doc-count');
  if (countEl) countEl.textContent = `${hFilteredDocuments().length} ${t('of')} ${HEAD_DATA.documents.length}`;
}

/* ── Upload Document (real File API) ── */
function hOpenDocumentForm() {
  hState.documents.form = { fileName:'', dataUrl:null, size:'', category:H_DOCUMENT_CATEGORIES[0], associatedType:'none', associatedId:null };
  hState.documents.screen = 'form';
  hState.documents.error = '';
  hRefreshDocuments();
}
function hCancelDocumentForm() { hState.documents.screen = 'list'; hState.documents.form = null; hState.documents.error = ''; hRefreshDocuments(); }
function hFormatFileSize(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return Math.round(bytes / 1024) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
}
function hHandleDocumentFile(input) {
  const file = input.files && input.files[0];
  if (!file) return;
  const f = hState.documents.form;
  f.size = hFormatFileSize(file.size);
  const reader = new FileReader();
  reader.onload = function(e) {
    f.fileName = file.name;
    f.dataUrl = e.target.result;
    hState.documents.error = '';
    const el = document.getElementById('h-documents-content');
    if (el) el.innerHTML = hDocumentsBody();
  };
  reader.onerror = function() {
    hState.documents.error = t('Could not read this file. Please try again.');
    const el = document.getElementById('h-documents-content');
    if (el) el.innerHTML = hDocumentsBody();
  };
  reader.readAsDataURL(file);
}
function hDocumentUploadForm() {
  const f = hState.documents.form;
  const err = hState.documents.error;
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Upload Document')}</div></div>
    <div class="card-body">
      <input type="file" id="h-doc-file" onchange="hHandleDocumentFile(this)" style="margin-bottom:12px">
      ${f.fileName ? `<div class="info-row"><span>${gdCommsEsc(f.fileName)}</span><span style="color:var(--muted)">${gdCommsEsc(f.size)}</span></div>` : ''}
      <div class="st-field"><label>${t('Category')}</label><select id="h-doc-category">
        ${H_DOCUMENT_CATEGORIES.map(c => `<option value="${c}" ${c===f.category?'selected':''}>${t(c)}</option>`).join('')}
      </select></div>
      <div class="st-field"><label>${t('Associate With')}</label><select id="h-doc-assoctype" onchange="hSetDocAssocType(this.value)">
        <option value="none" ${f.associatedType==='none'?'selected':''}>${t('Nothing (unassociated)')}</option>
        <option value="institution" ${f.associatedType==='institution'?'selected':''}>${t('Institution-wide')}</option>
        <option value="class" ${f.associatedType==='class'?'selected':''}>${t('A Class')}</option>
        <option value="student" ${f.associatedType==='student'?'selected':''}>${t('A Student')}</option>
      </select></div>
      ${f.associatedType === 'class' ? `<div class="st-field"><label>${t('Class')}</label><select id="h-doc-assocclass">
        ${HEAD_DATA.classes.map(c => `<option value="${c.id}">${gdCommsEsc(c.name)}</option>`).join('')}
      </select></div>` : ''}
      ${f.associatedType === 'student' ? `<div class="st-field"><label>${t('Student')}</label>
        ${f.associatedId ? (() => { const st = hGetStudent(f.associatedId); return `<div class="info-row"><span>${st ? gdCommsEsc(hStudentFullName(st)) : ''}</span><span class="card-action" onclick="hSetDocAssocStudent(null)">${t('Change')}</span></div>`; })()
          : `<input class="gd-comm-search-input" type="text" placeholder="${t('Search students...')}" oninput="hSetDocStudentSearch(this.value)"><div id="h-doc-student-results"></div>`}
      </div>` : ''}
      <div style="display:flex;gap:10px">
        <button class="st-btn" onclick="hSaveDocument()">${t('Upload')}</button>
        <button class="st-btn ghost" onclick="hCancelDocumentForm()">${t('Cancel')}</button>
      </div>
      ${err ? `<div class="st-inline-msg err show" style="margin-top:12px">${err}</div>` : ''}
    </div></div>`;
}
function hSetDocAssocType(v) {
  hState.documents.form.associatedType = v;
  hState.documents.form.associatedId = null;
  const el = document.getElementById('h-documents-content');
  if (el) el.innerHTML = hDocumentsBody();
}
function hSetDocStudentSearch(v) {
  const q = v.trim().toLowerCase();
  const el = document.getElementById('h-doc-student-results');
  if (!el) return;
  if (!q) { el.innerHTML = ''; return; }
  const results = HEAD_DATA.students.filter(s => hStudentFullName(s).toLowerCase().includes(q));
  el.innerHTML = results.length ? results.map(s => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hSetDocAssocStudent('${s.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hSetDocAssocStudent('${s.id}')}">
    <span>${gdCommsEsc(hStudentFullName(s))}</span><span class="card-action">${t('Select')}</span>
  </div>`).join('') : `<div class="gd-empty-mini" style="text-align:left;padding:8px 0 0">${t('No students match your search.')}</div>`;
}
function hSetDocAssocStudent(id) {
  hState.documents.form.associatedId = id;
  const el = document.getElementById('h-documents-content');
  if (el) el.innerHTML = hDocumentsBody();
}
function hSaveDocument() {
  const f = hState.documents.form;
  const category = document.getElementById('h-doc-category').value;
  Object.assign(f, { category });
  let associatedId = null;
  if (f.associatedType === 'class') { const sel = document.getElementById('h-doc-assocclass'); associatedId = sel ? sel.value : null; }
  else if (f.associatedType === 'student') associatedId = f.associatedId;

  let err = '';
  if (!f.fileName) err = t('Select a file to upload.');
  else if (f.associatedType === 'student' && !associatedId) err = t('Select a student to associate this document with.');

  hState.documents.error = err;
  if (err) { const el = document.getElementById('h-documents-content'); if (el) el.innerHTML = hDocumentsBody(); return; }

  const newDoc = { id:'hdoc' + Date.now(), name:f.fileName, category, uploadedDate: tISODate(new Date(2026, 2, 11)), size:f.size, associatedType: f.associatedType === 'none' ? null : f.associatedType, associatedId, dataUrl:f.dataUrl };
  HEAD_DATA.documents.push(newDoc);
  hState.documents.screen = 'detail';
  hState.documents.docId = newDoc.id;
  hState.documents.form = null;
  hRefreshDocuments();
  hShowToast(t('Document uploaded successfully.'));
}

/* ── Document Detail (real download + delete) ── */
function hOpenDocumentDetail(id) { hState.documents.screen = 'detail'; hState.documents.docId = id; hRefreshDocuments(); }
function hBackToDocumentList() { hState.documents.screen = 'list'; hState.documents.docId = null; hRefreshDocuments(); }
function hDocumentDetailScreen(d) {
  return `<div class="card"><div class="card-header">
    <div style="display:flex;align-items:center;gap:10px;min-width:0;flex:1"><button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="hBackToDocumentList()">${t('← Back')}</button><div class="card-title" style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${gdCommsEsc(d.name)}</div></div>
  </div>
    <div class="card-body">
      <div class="info-row"><span>${t('Category')}</span><span>${gdCommsEsc(t(d.category))}</span></div>
      <div class="info-row"><span>${t('Uploaded')}</span><span>${d.uploadedDate}</span></div>
      <div class="info-row"><span>${t('Size')}</span><span>${gdCommsEsc(d.size)}</span></div>
      <div class="info-row"><span>${t('Associated With')}</span><span>${gdCommsEsc(hDocumentAssociationLabel(d))}</span></div>
      <div style="display:flex;gap:10px;margin-top:14px">
        ${d.dataUrl ? `<a href="${d.dataUrl}" download="${gdCommsEsc(d.name)}" class="st-btn sm" style="text-decoration:none;display:inline-flex;align-items:center">${aIcon('download')} ${t('Download')}</a>` : `<span style="font-size:11.5px;color:var(--muted)">${t('No downloadable file stored for this seeded document.')}</span>`}
        <button type="button" class="st-btn ghost sm" style="color:var(--red)" onclick="hConfirmDeleteDocument('${d.id}')">${t('Delete')}</button>
      </div>
    </div></div>`;
}
function hConfirmDeleteDocument(id) {
  const d = hGetDocument(id);
  if (!d) return;
  stOpenModal(`<h3 style="margin-bottom:10px">${t('Delete this document?')}</h3>
    <p style="font-size:13px;color:var(--muted);margin-bottom:18px">"${gdCommsEsc(d.name)}" ${t('will be permanently removed. This cannot be undone.')}</p>
    <div style="display:flex;gap:10px">
      <button class="st-btn" style="background:var(--red)" onclick="hDeleteDocument('${id}');stCloseModal()">${t('Delete')}</button>
      <button class="st-btn ghost" onclick="stCloseModal()">${t('Cancel')}</button>
    </div>`);
}
function hDeleteDocument(id) {
  HEAD_DATA.documents = HEAD_DATA.documents.filter(d => d.id !== id);
  hBackToDocumentList();
  hShowToast(t('Document deleted.'));
}

/* ── Advanced Communication Management: Templates & Audience Groups ── */
function hCommsTemplatesTab() {
  const c = hState.comms;
  return `
    <div class="card"><div class="card-header"><div class="card-title">${t('Message Templates')}</div></div>
      <div class="card-body">
        ${HEAD_DATA.messageTemplates.map(tpl => `<div class="card" style="margin-bottom:10px;background:var(--surface2)"><div class="card-body">
          <div style="font-weight:600;font-size:13px">${gdCommsEsc(tpl.name)}</div>
          <div style="font-size:11.5px;color:var(--muted);margin-top:4px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${gdCommsEsc(tpl.subject)}</div>
          <div style="display:flex;gap:8px;margin-top:8px">
            <button type="button" class="st-btn ghost sm" onclick="hUseTemplate('${tpl.id}')">${t('Use')}</button>
            <button type="button" class="st-btn ghost sm" onclick="hOpenTemplateForm('${tpl.id}')">${t('Edit')}</button>
            <button type="button" class="st-btn ghost sm" style="color:var(--red)" onclick="hDeleteTemplate('${tpl.id}')">${t('Delete')}</button>
          </div>
        </div></div>`).join('') || `<div class="gd-empty-mini">${t('No templates yet.')}</div>`}
        ${c.templateForm ? hTemplateFormBlock() : `<button class="st-btn ghost sm" onclick="hOpenTemplateForm()">+ ${t('New Template')}</button>`}
      </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Audience Groups')}</div></div>
      <div class="card-body">
        ${HEAD_DATA.audienceGroups.map(g => `<div class="info-row"><span>${gdCommsEsc(g.name)}<div style="font-size:11px;color:var(--muted)">${g.memberIds.length} ${t(g.memberType + '(s)')}</div></span><button type="button" class="st-btn ghost sm" onclick="hDeleteAudienceGroup('${g.id}')">${t('Delete')}</button></div>`).join('') || `<div class="gd-empty-mini">${t('No saved audience groups yet.')}</div>`}
        ${c.groupForm ? hGroupFormBlock() : `<button class="st-btn ghost sm" onclick="hOpenGroupForm()">+ ${t('New Group')}</button>`}
      </div></div>`;
}
function hRefreshCommsTemplates() { const el = document.getElementById('h-comms-content'); if (el) el.innerHTML = hCommsTemplatesTab(); }

/* ── Template CRUD ── */
function hOpenTemplateForm(id) {
  const c = hState.comms;
  if (id) { const tpl = HEAD_DATA.messageTemplates.find(x => x.id === id); c.templateForm = { mode:'edit', id, name:tpl.name, subject:tpl.subject, message:tpl.message }; }
  else c.templateForm = { mode:'create', id:null, name:'', subject:'', message:'' };
  c.templateError = '';
  hRefreshCommsTemplates();
}
function hCancelTemplateForm() { hState.comms.templateForm = null; hState.comms.templateError = ''; hRefreshCommsTemplates(); }
function hTemplateFormBlock() {
  const f = hState.comms.templateForm;
  const err = hState.comms.templateError;
  return `<div class="card" style="margin-top:10px;background:var(--surface2)"><div class="card-body">
    <div class="st-field"><label>${t('Template Name')}</label><input id="h-tpl-name" value="${gdCommsEsc(f.name)}"></div>
    <div class="st-field"><label>${t('Subject')}</label><input id="h-tpl-subject" value="${gdCommsEsc(f.subject)}"></div>
    <div class="st-field"><label>${t('Message')}</label><textarea id="h-tpl-message" rows="4">${gdCommsEsc(f.message)}</textarea></div>
    <div style="display:flex;gap:10px">
      <button class="st-btn sm" onclick="hSaveTemplate()">${f.mode==='edit'?t('Save Changes'):t('Create Template')}</button>
      <button class="st-btn ghost sm" onclick="hCancelTemplateForm()">${t('Cancel')}</button>
    </div>
    ${err ? `<div class="st-inline-msg err show" style="margin-top:10px">${err}</div>` : ''}
  </div></div>`;
}
function hSaveTemplate() {
  const f = hState.comms.templateForm;
  const name = (document.getElementById('h-tpl-name').value || '').trim();
  const subject = (document.getElementById('h-tpl-subject').value || '').trim();
  const message = (document.getElementById('h-tpl-message').value || '').trim();
  Object.assign(f, { name, subject, message });

  let err = '';
  if (!name) err = t('Template name is required.');
  else if (!subject) err = t('Subject is required.');
  else if (!message) err = t('Message is required.');
  hState.comms.templateError = err;
  if (err) { hRefreshCommsTemplates(); return; }

  if (f.mode === 'edit') { const tpl = HEAD_DATA.messageTemplates.find(x => x.id === f.id); Object.assign(tpl, { name, subject, message }); hShowToast(t('Template updated.')); }
  else { HEAD_DATA.messageTemplates.push({ id:'tpl' + Date.now(), name, subject, message }); hShowToast(t('Template created.')); }
  hState.comms.templateForm = null;
  hRefreshCommsTemplates();
}
function hDeleteTemplate(id) {
  HEAD_DATA.messageTemplates = HEAD_DATA.messageTemplates.filter(x => x.id !== id);
  hRefreshCommsTemplates();
  hShowToast(t('Template deleted.'));
}
function hUseTemplate(id) {
  const tpl = HEAD_DATA.messageTemplates.find(x => x.id === id);
  if (!tpl) return;
  hState.comms.compose = { subject:tpl.subject, message:tpl.message, audience:'school', audienceClassId:null, preview:false };
  hState.comms.screen = 'compose';
  hState.comms.tab = 'main';
  hState.comms.error = '';
  document.querySelectorAll('.gd-tab-hcom').forEach(el => el.classList.toggle('active', el.dataset.tab === 'main'));
  const el = document.getElementById('h-comms-content');
  if (el) el.innerHTML = hCommsTabBody();
  hShowToast(t('Template loaded into Compose.'));
}

/* ── Audience Group CRUD ── */
function hOpenGroupForm() {
  hState.comms.groupForm = { name:'', memberType:'teacher', selectedIds:[] };
  hState.comms.groupError = '';
  hRefreshCommsTemplates();
}
function hCancelGroupForm() { hState.comms.groupForm = null; hState.comms.groupError = ''; hRefreshCommsTemplates(); }
function hSetGroupMemberType(v) {
  hState.comms.groupForm.memberType = v;
  hState.comms.groupForm.selectedIds = [];
  hRefreshCommsTemplates();
}
function hToggleGroupMember(id) {
  const f = hState.comms.groupForm;
  if (f.selectedIds.includes(id)) f.selectedIds = f.selectedIds.filter(x => x !== id);
  else f.selectedIds.push(id);
  hRefreshCommsTemplates();
}
function hGroupFormBlock() {
  const f = hState.comms.groupForm;
  const err = hState.comms.groupError;
  const people = f.memberType === 'teacher' ? HEAD_DATA.teachers : HEAD_DATA.guardians;
  return `<div class="card" style="margin-top:10px;background:var(--surface2)"><div class="card-body">
    <div class="st-field"><label>${t('Group Name')}</label><input id="h-grp-name" value="${gdCommsEsc(f.name)}"></div>
    <div class="st-field"><label>${t('Member Type')}</label><select onchange="hSetGroupMemberType(this.value)">
      <option value="teacher" ${f.memberType==='teacher'?'selected':''}>${t('Teachers')}</option>
      <option value="guardian" ${f.memberType==='guardian'?'selected':''}>${t('Guardians')}</option>
    </select></div>
    <div style="font-size:11.5px;color:var(--muted);margin:8px 0">${t('Select members')} (${f.selectedIds.length} ${t('selected')})</div>
    ${people.map(p => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hToggleGroupMember('${p.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hToggleGroupMember('${p.id}')}"><span><input type="checkbox" ${f.selectedIds.includes(p.id)?'checked':''} style="margin-right:8px;pointer-events:none">${gdCommsEsc(p.name)}</span></div>`).join('')}
    <div style="display:flex;gap:10px;margin-top:10px">
      <button class="st-btn sm" onclick="hSaveAudienceGroup()">${t('Save Group')}</button>
      <button class="st-btn ghost sm" onclick="hCancelGroupForm()">${t('Cancel')}</button>
    </div>
    ${err ? `<div class="st-inline-msg err show" style="margin-top:10px">${err}</div>` : ''}
  </div></div>`;
}
function hSaveAudienceGroup() {
  const f = hState.comms.groupForm;
  const name = (document.getElementById('h-grp-name').value || '').trim();
  f.name = name;
  let err = '';
  if (!name) err = t('Group name is required.');
  else if (!f.selectedIds.length) err = t('Select at least one member.');
  hState.comms.groupError = err;
  if (err) { hRefreshCommsTemplates(); return; }

  HEAD_DATA.audienceGroups.push({ id:'grp' + Date.now(), name, memberType:f.memberType, memberIds:f.selectedIds.slice() });
  hState.comms.groupForm = null;
  hRefreshCommsTemplates();
  hShowToast(t('Audience group saved.'));
}
function hDeleteAudienceGroup(id) {
  HEAD_DATA.audienceGroups = HEAD_DATA.audienceGroups.filter(g => g.id !== id);
  hRefreshCommsTemplates();
  hShowToast(t('Audience group deleted.'));
}

/* ══════════════════════════════════════════════════════
   SUPPORT (section 64)
══════════════════════════════════════════════════════ */
function hSupportView() {
  const tabs = [ { id:'help', label:'Help Center' }, { id:'contact', label:'Contact Support' } ];
  return `<div class="st-tabs">${tabs.map(tb => `<div class="st-tab gd-tab-hsup${tb.id===hState.support.tab?' active':''}" data-tab="${tb.id}" onclick="hSetSupportTab('${tb.id}')">${t(tb.label)}</div>`).join('')}</div>
    <div id="h-support-content">${hSupportBody()}</div>`;
}
function hSetSupportTab(tabId) {
  hState.support.tab = tabId;
  document.querySelectorAll('.gd-tab-hsup').forEach(el => el.classList.toggle('active', el.dataset.tab === tabId));
  const el = document.getElementById('h-support-content');
  if (el) el.innerHTML = hSupportBody();
}
function hSupportBody() {
  return hState.support.tab === 'contact' ? hContactSupportTab() : hHelpCenterTab();
}
function hHelpCenterTab() {
  const s = hState.support;
  const q = s.helpSearch.trim().toLowerCase();
  let faqs = H_FAQS.slice();
  if (s.helpCategory !== 'all') faqs = faqs.filter(f => f.category === s.helpCategory);
  if (q) faqs = faqs.filter(f => f.question.toLowerCase().includes(q) || f.answer.toLowerCase().includes(q));
  const categories = Array.from(new Set(H_FAQS.map(f => f.category)));
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Help Center')}</div></div>
    <div class="card-body">
      <input class="gd-comm-search-input" type="text" placeholder="${t('Search help articles...')}" value="${gdCommsEsc(s.helpSearch)}" oninput="hSetHelpSearch(this.value)">
      <div class="gd-comm-filter-row" style="margin-top:10px">
        <div class="gd-comm-filter-chip${s.helpCategory==='all'?' active':''}" onclick="hSetHelpCategory('all')">${t('All')}</div>
        ${categories.map(c => `<div class="gd-comm-filter-chip${s.helpCategory===c?' active':''}" onclick="hSetHelpCategory('${c}')">${t(c)}</div>`).join('')}
      </div>
      <div id="h-help-results" style="margin-top:12px">${hHelpResultsBlock()}</div>
    </div></div>`;
}
function hHelpResultsBlock() {
  const s = hState.support;
  const q = s.helpSearch.trim().toLowerCase();
  let faqs = H_FAQS.slice();
  if (s.helpCategory !== 'all') faqs = faqs.filter(f => f.category === s.helpCategory);
  if (q) faqs = faqs.filter(f => f.question.toLowerCase().includes(q) || f.answer.toLowerCase().includes(q));
  if (!faqs.length) return `<div class="gd-empty-state"><div class="gd-empty-state-title">${t('No matching articles')}</div><div class="gd-empty-state-sub">${t('Try a different search, or')} <span class="card-action" onclick="hSetSupportTab('contact')">${t('contact support')}</span>.</div></div>`;
  return faqs.map(f => `<div class="card" style="margin-bottom:8px;background:var(--surface2)"><div class="card-body" style="cursor:pointer" onclick="hToggleFaq('${f.id}')">
    <div style="display:flex;justify-content:space-between;align-items:center">
      <div style="font-weight:600;font-size:13px">${gdCommsEsc(f.question)}</div>
      <span style="color:var(--muted)">${s.expandedFaqId===f.id?'−':'+'}</span>
    </div>
    ${s.expandedFaqId===f.id ? `<div style="font-size:12.5px;color:var(--muted2);margin-top:8px;line-height:1.5">${gdCommsEsc(f.answer)}</div>` : ''}
  </div></div>`).join('');
}
function hSetHelpSearch(v) { hState.support.helpSearch = v; const el = document.getElementById('h-help-results'); if (el) el.innerHTML = hHelpResultsBlock(); }
function hSetHelpCategory(v) { hState.support.helpCategory = v; hRefreshSupport(); }
function hToggleFaq(id) { hState.support.expandedFaqId = hState.support.expandedFaqId === id ? null : id; const el = document.getElementById('h-help-results'); if (el) el.innerHTML = hHelpResultsBlock(); }
function hRefreshSupport() { const el = document.getElementById('h-support-content'); if (el) el.innerHTML = hSupportBody(); }

/* ── Contact Support (real ticket history, honest submission simulation) ── */
function hContactSupportTab() {
  const s = hState.support;
  if (s.screen === 'form') return hSupportFormScreen();
  return `<div class="card"><div class="card-header"><div class="card-title">${t('My Support Requests')}</div><button class="st-btn sm" onclick="hOpenSupportForm()">+ ${t('New Request')}</button></div>
    <div class="card-body">
      ${HEAD_DATA.supportTickets.length ? HEAD_DATA.supportTickets.slice().sort((a,b)=>b.submittedDate.localeCompare(a.submittedDate)).map(tk => `<div class="info-row"><span>${gdCommsEsc(tk.subject)}<div style="font-size:11px;color:var(--muted)">${gdCommsEsc(t(tk.category))} · ${tk.submittedDate}</div></span><span class="status-pill ${tk.status==='resolved'?'paid':'due'}">${t(tk.status.charAt(0).toUpperCase()+tk.status.slice(1))}</span></div>`).join('') : `<div class="gd-empty-mini">${t('No support requests submitted yet.')}</div>`}
    </div></div>`;
}
function hOpenSupportForm() {
  hState.support.form = { category:H_SUPPORT_CATEGORIES[0], subject:'', description:'' };
  hState.support.screen = 'form';
  hState.support.error = '';
  hRefreshSupport();
}
function hCancelSupportForm() { hState.support.screen = 'list'; hState.support.form = null; hState.support.error = ''; hRefreshSupport(); }
function hSupportFormScreen() {
  const f = hState.support.form;
  const err = hState.support.error;
  return `<div class="card"><div class="card-header"><div class="card-title">${t('New Support Request')}</div></div>
    <div class="card-body">
      <div class="st-field"><label>${t('Category')}</label><select id="h-sup-category">
        ${H_SUPPORT_CATEGORIES.map(c => `<option value="${c}" ${c===f.category?'selected':''}>${t(c)}</option>`).join('')}
      </select></div>
      <div class="st-field"><label>${t('Subject')}</label><input id="h-sup-subject" value="${gdCommsEsc(f.subject)}"></div>
      <div class="st-field"><label>${t('Description')}</label><textarea id="h-sup-description" rows="4">${gdCommsEsc(f.description)}</textarea></div>
      <div style="display:flex;gap:10px">
        <button class="st-btn" onclick="hSubmitSupportRequest()" ${hState.support.submitting?'disabled':''}>${hState.support.submitting ? `<span class="gd-spinner"></span>${t('Submitting...')}` : t('Submit Request')}</button>
        <button class="st-btn ghost" onclick="hCancelSupportForm()" ${hState.support.submitting?'disabled':''}>${t('Cancel')}</button>
      </div>
      ${err ? `<div class="st-inline-msg err show" style="margin-top:12px">${err}</div>` : ''}
    </div></div>`;
}
function hSubmitSupportRequest() {
  const f = hState.support.form;
  const category = document.getElementById('h-sup-category').value;
  const subject = (document.getElementById('h-sup-subject').value || '').trim();
  const description = (document.getElementById('h-sup-description').value || '').trim();
  Object.assign(f, { category, subject, description });

  let err = '';
  if (!subject) err = t('Subject is required.');
  else if (!description || description.length < 10) err = t('Please provide a description of at least 10 characters.');

  hState.support.error = err;
  if (err) { hRefreshSupport(); return; }

  hState.support.submitting = true;
  hRefreshSupport();
  setTimeout(() => {
    hState.support.submitting = false;
    if (Math.random() < 0.12) {
      hState.support.error = t('Something went wrong submitting your request. Please try again.');
      hRefreshSupport();
      return;
    }
    HEAD_DATA.supportTickets.push({ id:'hsup' + Date.now(), category, subject, description, status:'open', submittedDate: tISODate(new Date(2026, 2, 11)) });
    hState.support.screen = 'list';
    hState.support.form = null;
    hRefreshSupport();
    hShowToast(t('Support request submitted successfully.'));
  }, 800);
}

/* ══════════════════════════════════════════════════════
   ACCOUNT & SECURITY (section 65)
══════════════════════════════════════════════════════ */
const H_SESSIONS = [
  { id:'sess1', device:'Chrome on macOS', location:'Rabat, Morocco', current:true, lastActive:'Active now' },
  { id:'sess2', device:'Safari on iPhone', location:'Rabat, Morocco', current:false, lastActive:'2 days ago' },
];
function hHeadAccountView() {
  const tabs = [ { id:'profile', label:'Profile' }, { id:'security', label:'Security' } ];
  return `<div class="st-tabs">${tabs.map(tb => `<div class="st-tab gd-tab-hacc2${tb.id===hState.headAccount.tab?' active':''}" data-tab="${tb.id}" onclick="hSetHeadAccountTab('${tb.id}')">${t(tb.label)}</div>`).join('')}</div>
    <div id="h-account-content">${hHeadAccountBody()}</div>`;
}
function hSetHeadAccountTab(tabId) {
  hState.headAccount.tab = tabId;
  document.querySelectorAll('.gd-tab-hacc2').forEach(el => el.classList.toggle('active', el.dataset.tab === tabId));
  const el = document.getElementById('h-account-content');
  if (el) el.innerHTML = hHeadAccountBody();
}
function hHeadAccountBody() {
  return hState.headAccount.tab === 'security' ? hHeadSecurityTab() : hHeadProfileTab();
}
function hRefreshHeadAccount() { const el = document.getElementById('h-account-content'); if (el) el.innerHTML = hHeadAccountBody(); }
function hHeadProfileTab() {
  const admin = HEAD_DATA.adminProfile;
  const s = hState.headAccount;
  if (s.editing) return hHeadProfileEditForm();
  return `<div class="card"><div class="card-body" style="display:flex;gap:16px;align-items:center">
      <div style="width:56px;height:56px;border-radius:16px;background:linear-gradient(180deg,rgba(217,119,6,0.3),rgba(217,119,6,0.1));display:flex;align-items:center;justify-content:center;font-weight:800;font-size:18px">${gdInitials(admin.name)}</div>
      <div style="flex:1"><div style="font-size:16px;font-weight:800">${gdCommsEsc(admin.name)}</div><div style="font-size:12.5px;color:var(--muted)">${gdCommsEsc(admin.title)} · ${gdCommsEsc(HEAD_DATA.institution.name)}</div></div>
      <button type="button" class="st-btn ghost sm" onclick="hOpenHeadProfileEdit()">${t('Edit')}</button>
    </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Contact Information')}</div></div>
      <div class="card-body">
        <div class="info-row"><span>${t('Institution Email')}</span><span>${gdCommsEsc(HEAD_DATA.institution.email)}</span></div>
        <div class="info-row"><span>${t('Institution Phone')}</span><span>${gdCommsEsc(HEAD_DATA.institution.phone)}</span></div>
      </div></div>`;
}
function hOpenHeadProfileEdit() { hState.headAccount.editing = true; hState.headAccount.error = ''; hRefreshHeadAccount(); }
function hCancelHeadProfileEdit() { hState.headAccount.editing = false; hRefreshHeadAccount(); }
function hHeadProfileEditForm() {
  const admin = HEAD_DATA.adminProfile;
  const err = hState.headAccount.error;
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Edit Profile')}</div></div>
    <div class="card-body">
      <div class="st-field"><label>${t('Name')}</label><input id="h-acc-name" value="${gdCommsEsc(admin.name)}"></div>
      <div class="st-field"><label>${t('Title')}</label><input id="h-acc-title" value="${gdCommsEsc(admin.title)}"></div>
      <div style="display:flex;gap:10px">
        <button class="st-btn" onclick="hSaveHeadProfile()" ${hState.headAccount.saving?'disabled':''}>${hState.headAccount.saving ? `<span class="gd-spinner"></span>${t('Saving...')}` : t('Save Changes')}</button>
        <button class="st-btn ghost" onclick="hCancelHeadProfileEdit()" ${hState.headAccount.saving?'disabled':''}>${t('Cancel')}</button>
      </div>
      ${err ? `<div class="st-inline-msg err show" style="margin-top:12px">${err}</div>` : ''}
    </div></div>`;
}
function hSaveHeadProfile() {
  const name = (document.getElementById('h-acc-name').value || '').trim();
  const title = (document.getElementById('h-acc-title').value || '').trim();
  if (!name) { hState.headAccount.error = t('Name is required.'); hRefreshHeadAccount(); return; }
  hState.headAccount.saving = true;
  hRefreshHeadAccount();
  setTimeout(() => {
    Object.assign(HEAD_DATA.adminProfile, { name, title });
    hState.headAccount.saving = false;
    hState.headAccount.editing = false;
    hRefreshHeadAccount();
    hShowToast(t('Profile updated successfully.'));
  }, 600);
}

/* ── Security tab (change password + sessions + logout) ── */
function hHeadSecurityTab() {
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Change Password')}</div></div>
    <div class="card-body">
      <div class="st-field"><label>${t('Current Password')}</label>
        <div class="pass-input-wrap"><input type="password" id="h-pw-cur" style="padding-right:40px">
          <button type="button" class="toggle-pass-btn" onclick="togglePasswordVisibility('h-pw-cur', this)" aria-label="Toggle password visibility">${EYE_CLOSED_SVG}</button>
        </div></div>
      <div class="st-field"><label>${t('New Password')}</label>
        <div class="pass-input-wrap"><input type="password" id="h-pw-new" style="padding-right:40px">
          <button type="button" class="toggle-pass-btn" onclick="togglePasswordVisibility('h-pw-new', this)" aria-label="Toggle password visibility">${EYE_CLOSED_SVG}</button>
        </div></div>
      <div style="font-size:11px;color:var(--muted);margin:-6px 0 12px">${t('Minimum 6 characters, with at least 1 letter and 1 number.')}</div>
      <div class="st-field"><label>${t('Confirm New Password')}</label>
        <div class="pass-input-wrap"><input type="password" id="h-pw-confirm" style="padding-right:40px">
          <button type="button" class="toggle-pass-btn" onclick="togglePasswordVisibility('h-pw-confirm', this)" aria-label="Toggle password visibility">${EYE_CLOSED_SVG}</button>
        </div></div>
      <button class="st-btn" id="h-pw-submit" onclick="hChangeHeadPassword()" ${hState.headAccount.pwSaving?'disabled':''}>${hState.headAccount.pwSaving ? `<span class="gd-spinner"></span>${t('Updating...')}` : t('Update Password')}</button>
      ${hState.headAccount.pwSuccess ? `<div class="st-inline-msg ok show" style="margin-top:10px">${t('Password updated successfully.')}</div>` : ''}
      ${hState.headAccount.pwError ? `<div class="st-inline-msg err show" style="margin-top:10px">${hState.headAccount.pwError}</div>` : ''}
    </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Active Sessions')}</div></div>
      <div class="card-body">
        ${H_SESSIONS.map(sess => `<div class="info-row"><span>${gdCommsEsc(sess.device)}${sess.current?` <span class="status-pill paid">${t('This device')}</span>`:''}<div style="font-size:11px;color:var(--muted)">${gdCommsEsc(sess.location)} · ${gdCommsEsc(sess.lastActive)}</div></span>${!sess.current?`<button type="button" class="st-btn ghost sm" onclick="hLogOutSession('${sess.id}')">${t('Log Out')}</button>`:''}</span></div>`).join('')}
      </div></div>
    <div class="card" style="margin-top:16px"><div class="card-body">
      <button type="button" class="st-btn ghost sm" style="color:var(--red)" onclick="hConfirmHeadLogout()">${t('Log Out of This Account')}</button>
    </div></div>`;
}
function hChangeHeadPassword() {
  const cur = document.getElementById('h-pw-cur').value;
  const nw = document.getElementById('h-pw-new').value;
  const cf = document.getElementById('h-pw-confirm').value;
  hState.headAccount.pwSuccess = false;
  if (!cur) { hState.headAccount.pwError = t('Please enter your current password.'); hRefreshHeadAccount(); return; }
  if (cur !== HEAD_DATA.adminProfile.password) { hState.headAccount.pwError = t('Current password is incorrect.'); hRefreshHeadAccount(); return; }
  if (!nw || !cf) { hState.headAccount.pwError = t('Please fill in both new password fields.'); hRefreshHeadAccount(); return; }
  const errs = validatePassword(nw);
  if (errs.length) { hState.headAccount.pwError = errs.join(' '); hRefreshHeadAccount(); return; }
  if (nw !== cf) { hState.headAccount.pwError = t('Passwords do not match.'); hRefreshHeadAccount(); return; }
  if (nw === cur) { hState.headAccount.pwError = t('New password must be different from your current password.'); hRefreshHeadAccount(); return; }

  hState.headAccount.pwError = '';
  hState.headAccount.pwSaving = true;
  hRefreshHeadAccount();
  setTimeout(() => {
    HEAD_DATA.adminProfile.password = nw;
    hState.headAccount.pwSaving = false;
    hState.headAccount.pwSuccess = true;
    hRefreshHeadAccount();
    setTimeout(() => { hState.headAccount.pwSuccess = false; }, 3000);
  }, 700);
}
function hLogOutSession(id) {
  const idx = H_SESSIONS.findIndex(s => s.id === id);
  if (idx === -1) return;
  H_SESSIONS.splice(idx, 1);
  hRefreshHeadAccount();
  hShowToast(t('Session logged out.'));
}
function hConfirmHeadLogout() {
  stOpenModal(`<h3 style="margin-bottom:10px">${t('Log out of this account?')}</h3>
    <p style="font-size:13px;color:var(--muted);margin-bottom:18px">${t("You'll need to sign in again to access the Head of Institution dashboard.")}</p>
    <div style="display:flex;gap:10px">
      <button class="st-btn" style="background:var(--red)" onclick="stCloseModal();goLogin('head')">${t('Log Out')}</button>
      <button class="st-btn ghost" onclick="stCloseModal()">${t('Cancel')}</button>
    </div>`);
}

/* ══════════════════════════════════════════════════════
   SUBSCRIPTION MANAGEMENT (section 66)
   No real payment integration exists — plan changes are clearly
   simulated state transitions, never presented as a real transaction.
══════════════════════════════════════════════════════ */
function hSubscriptionView() {
  return `<div id="h-subscription-content">${hSubscriptionBody()}</div>`;
}
function hSubscriptionBody() {
  /* ENTITLEMENT-ONLY VIEW.
     The Head did not purchase the subscription and does not see the
     institution's commercial billing — no price, no invoices, no billing
     status, no renewal charge, no plan-change control. What the Head DOES
     need is to know which plan the institution is on, so that a locked
     feature is explained rather than being an unexplained dead end.
     Money lives on the School / Institution role (Owner, and Finance
     Manager for viewing). */
  const sub = HEAD_DATA.subscription;
  const currentId = sub.currentPlan;
  const order = AUTHREN_PLAN_ORDER;
  const current = authrenPlan(currentId);
  const included = authrenPlanFeatures(currentId);
  const higher = order.slice(order.indexOf(currentId) + 1);

  return `
    <div class="card"><div class="card-header"><div class="card-title">${t('Your Institution\'s Plan')}</div></div>
      <div class="card-body">
        <div class="info-row"><span>${t('Current plan')}</span><span style="font-weight:700">${gdCommsEsc(current ? current.name : currentId)}</span></div>
        <div style="font-size:12px;color:var(--muted);margin-top:10px;line-height:1.55">
          ${t('This shows what your institution\'s plan unlocks. Billing, invoices and plan changes are handled by your School / Institution account (Owner).')}
        </div>
      </div></div>

    <div class="card" style="margin-top:16px"><div class="card-header">
        <div class="card-title">${t('Included in your plan')}</div>
        <span style="font-size:12px;color:var(--muted)">${included.length} ${t('features')}</span>
      </div>
      <div class="card-body">
        ${included.map(f => `<div style="font-size:12.5px;color:var(--muted2);margin-bottom:5px">${aIcon('check')} ${gdCommsEsc(f)}</div>`).join('')}
      </div></div>

    ${higher.length ? `<div class="card" style="margin-top:16px"><div class="card-header">
        <div class="card-title">${t('Available on higher plans')}</div>
      </div>
      <div class="card-body">
        <div style="font-size:12px;color:var(--muted);margin-bottom:12px">${t('If you need one of these, contact your institution owner.')}</div>
        ${higher.map(id => {
          const plan = authrenPlan(id);
          const adds = plan ? plan.features : [];
          return `<div style="margin-bottom:14px">
            <div style="font-weight:700;font-size:13px;margin-bottom:6px">${gdCommsEsc(plan ? plan.name : id)}</div>
            ${adds.map(f => `<div style="font-size:11.5px;color:var(--muted);margin-bottom:4px">+ ${gdCommsEsc(f)}</div>`).join('')}
          </div>`;
        }).join('')}
      </div></div>` : ''}`;
}
function hRefreshSubscription() { const el = document.getElementById('h-subscription-content'); if (el) el.innerHTML = hSubscriptionBody(); }


/* ══════════════════════════════════════════════════════
   TIMETABLES (Head of Institution)
   Three tabs: browse by class, browse by teacher, and the automatic
   generator. The generator enforces every hard constraint and reports
   honestly when a valid timetable cannot be produced.
══════════════════════════════════════════════════════ */
hState.timetable = { tab: 'class', classId: TT_CLASSES[0].id, teacherId: TT_TEACHERS[0].id, loadClassId: TT_CLASSES[0].id, genResult: null, generating: false };

function hTimetableView() {
  const tt = hState.timetable;
  const tabs = [ ['class', 'By Class'], ['teacher', 'By Teacher'], ['generate', 'Generate'] ];
  return `<div class="st-tabs">${tabs.map(([id, label]) =>
      `<div class="st-tab h-tab-tt${tt.tab === id ? ' active' : ''}" data-tab="${id}" onclick="hSetTimetableTab('${id}')">${t(label)}</div>`
    ).join('')}</div>
    <div id="h-tt-content">${hTimetableBody()}</div>`;
}

function hSetTimetableTab(tab) {
  hState.timetable.tab = tab;
  document.querySelectorAll('.h-tab-tt').forEach(el => el.classList.toggle('active', el.dataset.tab === tab));
  const el = document.getElementById('h-tt-content');
  if (el) el.innerHTML = hTimetableBody();
}

function hTimetableBody() {
  const tt = hState.timetable;
  if (tt.tab === 'teacher') return hTimetableByTeacher();
  if (tt.tab === 'generate') return hTimetableGenerator();
  return hTimetableByClass();
}

function hTimetableByClass() {
  const tt = hState.timetable;
  const cls = ttClass(tt.classId);
  const entries = cls ? ttEntriesForClass(cls.id) : [];
  const subjects = Array.from(new Set(entries.map(e => e.subjectId)));
  return `
    <div class="card"><div class="card-header">
        <div class="card-title">${t('Class Timetable')}</div>
        <button type="button" class="st-btn ghost sm" onclick="ttPrint()">${aIcon('printer')} ${t('Print')}</button>
      </div>
      <div class="card-body">
        <div class="tt-toolbar">
          <select onchange="hSetTimetableClass(this.value)">
            ${TT_CLASSES.map(c => `<option value="${c.id}" ${c.id === tt.classId ? 'selected' : ''}>${ttEsc(c.name)}</option>`).join('')}
          </select>
          <span style="font-size:12px;color:var(--muted)">${entries.length} ${t('periods/week')} · ${ttEsc(TT_META.academicYear)} · ${ttEsc(TT_META.term)}</span>
        </div>
        ${ttRenderGrid(entries, 'class')}
        <div class="tt-legend">
          ${subjects.map(sid => { const sj = ttSubject(sid); return sj ? `<div class="tt-legend-item"><span class="tt-legend-dot" style="background:${sj.color}"></span>${ttEsc(sj.name)}</div>` : ''; }).join('')}
        </div>
      </div></div>
    ${ttRenderSummary(entries, 'class')}`;
}

function hSetTimetableClass(classId) {
  hState.timetable.classId = classId;
  const el = document.getElementById('h-tt-content');
  if (el) el.innerHTML = hTimetableBody();
}

function hTimetableByTeacher() {
  const tt = hState.timetable;
  const teacher = ttTeacher(tt.teacherId);
  const entries = teacher ? ttEntriesForTeacher(teacher.id) : [];
  const totalSlots = ttAllSlots().length;
  const classes = Array.from(new Set(entries.map(e => e.classId)));
  return `
    <div class="card"><div class="card-header">
        <div class="card-title">${t('Teacher Timetable')}</div>
        <button type="button" class="st-btn ghost sm" onclick="ttPrint()">${aIcon('printer')} ${t('Print')}</button>
      </div>
      <div class="card-body">
        <div class="tt-toolbar">
          <select onchange="hSetTimetableTeacher(this.value)">
            ${TT_TEACHERS.map(te => `<option value="${te.id}" ${te.id === tt.teacherId ? 'selected' : ''}>${ttEsc(te.name)}</option>`).join('')}
          </select>
          <span style="font-size:12px;color:var(--muted)">${entries.length} ${t('periods/week')} · ${totalSlots - entries.length} ${t('free slots')}</span>
        </div>
        ${ttRenderGrid(entries, 'teacher')}
        <div class="tt-legend">
          ${classes.map(cid => { const c = ttClass(cid); return c ? `<div class="tt-legend-item"><span class="tt-legend-dot" style="background:var(--accent)"></span>${ttEsc(c.name)}</div>` : ''; }).join('')}
        </div>
      </div></div>
    ${ttRenderSummary(entries, 'teacher')}
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Teaching Load — All Teachers')}</div></div>
      <div class="card-body">
        ${TT_TEACHERS.map(te => {
          const n = ttEntriesForTeacher(te.id).length;
          return `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="hSetTimetableTeacher('${te.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();hSetTimetableTeacher('${te.id}')}">
            <span>${ttEsc(te.name)}<div style="font-size:11px;color:var(--muted)">${te.subjectIds.map(sid => ttSubject(sid) ? ttSubject(sid).name : sid).join(', ')}</div></span>
            <span>${n} ${t('periods/week')}</span></div>`;
        }).join('')}
      </div></div>`;
}

function hSetTimetableTeacher(teacherId) {
  hState.timetable.teacherId = teacherId;
  hState.timetable.tab = 'teacher';
  document.querySelectorAll('.h-tab-tt').forEach(el => el.classList.toggle('active', el.dataset.tab === 'teacher'));
  const el = document.getElementById('h-tt-content');
  if (el) el.innerHTML = hTimetableBody();
}

function hTimetableGenerator() {
  const tt = hState.timetable;
  const capacity = ttCapacityReport();
  const res = tt.genResult;
  return `
    <div class="card"><div class="card-header"><div class="card-title">${t('Automatic Timetable Generator')}</div></div>
      <div class="card-body">
        <div class="tt-gen-note">
          ${t('The generator builds a full school timetable that satisfies every one of these rules. If it cannot satisfy them all, it tells you why instead of producing a broken timetable.')}
          <ul style="margin:8px 0 0;padding-inline-start:18px">
            <li>${t('No class, teacher or room is ever double-booked')}</li>
            <li>${t('Science, computer and sport lessons use the correct specialised rooms')}</li>
            <li>${t('Each class receives exactly its required weekly periods per subject')}</li>
            <li>${t('Teachers only teach subjects they are qualified for')}</li>
            <li>${t('No more than 2 consecutive periods of the same subject')}</li>
            <li>${t('Saturdays are morning-only')}</li>
          </ul>
        </div>

        <div style="font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Weekly hours per subject')}</div>
        <div class="tt-toolbar">
          <select onchange="hSetLoadEditorClass(this.value)">
            ${TT_CLASSES.map(c => `<option value="${c.id}" ${c.id === tt.loadClassId ? 'selected' : ''}>${ttEsc(c.name)}</option>`).join('')}
          </select>
        </div>
        <div id="h-tt-load-editor">${hTimetableLoadEditor()}</div>

        <div style="font-size:12.5px;font-weight:600;margin:16px 0 8px">${t('Required weekly load per class')}</div>
        ${capacity.map(c => `<div class="info-row"><span>${ttEsc(c.className)}</span>
          <span style="color:${c.fits ? 'var(--muted)' : 'var(--red)'}">${c.required} / ${c.available} ${t('slots')}</span></div>`).join('')}

        <div id="h-tt-conflicts">${hTimetableConflictReport()}</div>

        <button class="st-btn" style="margin-top:14px" onclick="hRunTimetableGenerator()" ${tt.generating ? 'disabled' : ''}>
          ${tt.generating ? `<span class="gd-spinner"></span>${t('Generating...')}` : t('Generate Timetable')}
        </button>
        ${TT_META.generatedAt ? `<div style="font-size:11.5px;color:var(--muted);margin-top:8px">${t('Current timetable generated on')} ${ttEsc(TT_META.generatedAt)}</div>` : ''}

        ${res ? (res.ok
          ? `<div class="tt-gen-note tt-gen-ok" style="margin-top:14px">${aIcon('check-circle')} ${t('Timetable generated and verified.')} ${res.placed} ${t('lessons placed across')} ${TT_CLASSES.length} ${t('classes, with no conflicts.')}<br>
             <span style="font-size:11.5px">${t('All students, guardians and teachers now see this timetable.')}</span></div>`
          : `<div class="tt-gen-note tt-gen-err" style="margin-top:14px">${aIcon('alert-triangle')} ${t('Could not generate a valid timetable.')}<br><span style="font-size:11.5px">${ttEsc(res.message)}</span></div>`
        ) : ''}
      </div></div>`;
}

function hRunTimetableGenerator() {
  hState.timetable.generating = true;
  const el = document.getElementById('h-tt-content');
  if (el) el.innerHTML = hTimetableBody();
  setTimeout(() => {
    const res = ttGenerateTimetable();
    if (res.ok) {
      /* Only publish a timetable that independently validates — never
         show a conflicted timetable as if it were correct. */
      const check = ttValidate(res.entries);
      if (check.ok) {
        TT_ENTRIES = res.entries;
        TT_META.generatedAt = AUTHREN_NOW_ISO; // one shared clock — SCH_TODAY_HEAD() deleted (was hardcoded 6 months in the future)
        hState.timetable.genResult = res;
      } else {
        hState.timetable.genResult = { ok: false, message: t('The generated timetable failed validation and was not published.') };
      }
    } else {
      hState.timetable.genResult = res;
    }
    hState.timetable.generating = false;
    const el2 = document.getElementById('h-tt-content');
    if (el2) el2.innerHTML = hTimetableBody();
    if (typeof hShowToast === 'function') {
      hShowToast(hState.timetable.genResult.ok ? t('Timetable generated successfully.') : t('Timetable generation failed.'));
    }
  }, 600);
}



/* ══════════════════════════════════════════════════════
   TIMETABLE — WEEKLY HOURS PER SUBJECT (Head only)
   The head defines how many periods per week each class gets for each
   subject. The generator then has to satisfy exactly that. Teachers
   cannot change this; their timetable view is read-only.
══════════════════════════════════════════════════════ */
function hSetLoadEditorClass(classId) {
  hState.timetable.loadClassId = classId;
  const el = document.getElementById('h-tt-content');
  if (el) el.innerHTML = hTimetableBody();
}

function hTimetableLoadEditor() {
  const cls = ttClass(hState.timetable.loadClassId) || TT_CLASSES[0];
  const slots = ttAllSlots().length;
  const total = Object.values(cls.weeklyLoad).reduce((a, b) => a + b, 0);
  const over = total > slots;
  return `
    <div style="font-size:11.5px;color:var(--muted);margin-bottom:8px">
      ${ttEsc(cls.name)} — ${total} ${t('of')} ${slots} ${t('weekly slots used')}
      ${over ? `<span style="color:var(--red)"> · ${t('over capacity')}</span>` : ''}
    </div>
    ${TT_SUBJECTS.map(sj => {
      const hours = cls.weeklyLoad[sj.id] || 0;
      const qualified = ttTeachersForSubject(sj.id).length;
      return `<div class="info-row">
        <span>${sj.icon} ${ttEsc(sj.name)}
          <div style="font-size:11px;color:${qualified ? 'var(--muted)' : 'var(--red)'}">
            ${qualified ? qualified + ' ' + t('qualified teacher(s)') : t('No qualified teacher — cannot be scheduled')}
          </div></span>
        <span style="display:flex;align-items:center;gap:8px">
          <button type="button" class="st-btn ghost sm" onclick="hAdjustLoad('${sj.id}',-1)" ${hours <= 0 ? 'disabled' : ''}>−</button>
          <span style="min-width:22px;text-align:center">${hours}</span>
          <button type="button" class="st-btn ghost sm" onclick="hAdjustLoad('${sj.id}',1)">+</button>
        </span>
      </div>`;
    }).join('')}`;
}

function hAdjustLoad(subjectId, delta) {
  const cls = ttClass(hState.timetable.loadClassId) || TT_CLASSES[0];
  const current = cls.weeklyLoad[subjectId] || 0;
  const next = current + delta;
  if (next < 0) return;
  if (next === 0) delete cls.weeklyLoad[subjectId];
  else cls.weeklyLoad[subjectId] = next;
  /* Changing the required load invalidates any previously generated
     timetable, so clear the stale success message. */
  hState.timetable.genResult = null;
  const el = document.getElementById('h-tt-content');
  if (el) el.innerHTML = hTimetableBody();
}

/* ══════════════════════════════════════════════════════
   TIMETABLE — CONFLICT CHECKS (Head only)
   Checked BEFORE generating, so the head sees exactly what would stop a
   valid timetable being produced instead of only getting a failure.
══════════════════════════════════════════════════════ */
function hTimetableConflicts() {
  const problems = [];
  const slots = ttAllSlots().length;

  TT_CLASSES.forEach(c => {
    const total = Object.values(c.weeklyLoad).reduce((a, b) => a + b, 0);
    if (total > slots) {
      problems.push({ severity:'blocking', label: c.name + ' — ' + t('requires') + ' ' + total + ' ' + t('periods but only') + ' ' + slots + ' ' + t('slots exist') });
    }
    Object.keys(c.weeklyLoad).forEach(sid => {
      const sj = ttSubject(sid);
      const teachers = ttTeachersForSubject(sid);
      if (!teachers.length) {
        problems.push({ severity:'blocking', label: c.name + ' — ' + (sj ? sj.name : sid) + ': ' + t('no qualified teacher') });
      }
      const req = TT_ROOM_REQUIREMENT[sid];
      if (req && !TT_ROOMS.some(r => r.type === req)) {
        problems.push({ severity:'blocking', label: c.name + ' — ' + (sj ? sj.name : sid) + ': ' + t('no suitable room available') });
      }
    });
  });

  /* Teacher capacity: total demand for a subject vs. how many periods the
     qualified teachers can physically cover. */
  const demand = {};
  TT_CLASSES.forEach(c => Object.keys(c.weeklyLoad).forEach(sid => {
    demand[sid] = (demand[sid] || 0) + c.weeklyLoad[sid];
  }));
  Object.keys(demand).forEach(sid => {
    const capacity = ttTeachersForSubject(sid).length * slots;
    if (capacity && demand[sid] > capacity) {
      const sj = ttSubject(sid);
      problems.push({ severity:'blocking', label: (sj ? sj.name : sid) + ': ' + t('needs') + ' ' + demand[sid] + ' ' + t('periods but qualified teachers can only cover') + ' ' + capacity });
    }
  });

  /* Specialised-room capacity across the whole school */
  Object.keys(TT_ROOM_REQUIREMENT).forEach(sid => {
    if (!demand[sid]) return;
    const rooms = TT_ROOMS.filter(r => r.type === TT_ROOM_REQUIREMENT[sid]).length;
    const capacity = rooms * slots;
    if (demand[sid] > capacity) {
      const sj = ttSubject(sid);
      problems.push({ severity:'blocking', label: (sj ? sj.name : sid) + ': ' + t('needs') + ' ' + demand[sid] + ' ' + t('periods but matching rooms only provide') + ' ' + capacity });
    }
  });

  /* Advisory: a class using nearly every slot leaves no flexibility */
  TT_CLASSES.forEach(c => {
    const total = Object.values(c.weeklyLoad).reduce((a, b) => a + b, 0);
    if (total <= slots && total > slots * 0.92) {
      problems.push({ severity:'warning', label: c.name + ' — ' + t('uses almost every available slot, leaving little scheduling flexibility') });
    }
  });

  return problems;
}

function hTimetableConflictReport() {
  const problems = hTimetableConflicts();
  const blocking = problems.filter(p => p.severity === 'blocking');
  const warnings = problems.filter(p => p.severity === 'warning');
  if (!problems.length) {
    return `<div class="tt-gen-note tt-gen-ok" style="margin-top:14px">${aIcon('check-circle')} ${t('No conflicts detected. These settings can produce a valid timetable.')}</div>`;
  }
  return `
    ${blocking.length ? `<div class="tt-gen-note tt-gen-err" style="margin-top:14px">
      <strong>${aIcon('alert-triangle')} ${blocking.length} ${t('blocking conflict(s)')}</strong>
      <ul style="margin:8px 0 0;padding-inline-start:18px">
        ${blocking.map(p => `<li>${ttEsc(p.label)}</li>`).join('')}
      </ul></div>` : ''}
    ${warnings.length ? `<div class="tt-gen-note" style="margin-top:10px">
      <strong>${warnings.length} ${t('advisory')}</strong>
      <ul style="margin:8px 0 0;padding-inline-start:18px">
        ${warnings.map(p => `<li>${ttEsc(p.label)}</li>`).join('')}
      </ul></div>` : ''}`;
}
