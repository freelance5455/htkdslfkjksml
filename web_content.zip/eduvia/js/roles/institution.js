/* ══════════════════════════════════════════════════════════════════
   SCHOOL / INSTITUTION ROLE — institution-owner-level command center
   Distinct from Head of Institution: this role covers institution-wide
   control, finance, administration, analytics, billing, configuration,
   multi-campus, and high-level intelligence — not day-to-day school
   operations. Self-contained data model (schSeededRandom, SCHOOL_DATA),
   matching the established per-role-independent-data pattern used by
   every other role in this app.
══════════════════════════════════════════════════════════════════ */
function schSeededRandom(str) {
  let hash = 2166136261;
  for (let i = 0; i < str.length; i++) {
    hash ^= str.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return (hash >>> 0) / 4294967296;
}
function tISODateSch(d) { return d.toISOString().slice(0, 10); }
const SCH_TODAY = AUTHREN_NOW_ISO; // alias — one shared clock (js/authren-now.js), not an independent one

const SCHOOL_DATA = {
  institution: {
    name: 'Al Farabi Private Schools', legalName: 'Al Farabi Education Group SARL',
    type: 'Multi-Campus Private School Network', foundedYear: 2008,
    address: '24 Avenue Hassan II, Rabat, Morocco', phone: '+212 537-123 456', email: 'admin@alfarabi.edu',
    academicYear: '2025-2026', currentTerm: 'Term 2',
  },
  owner: { name: 'Mrs. Nadia Bensouda', title: 'Institution Owner', accessType: 'owner', password: 'Owner2026' },
  settings: {
    passThreshold: 12, attendanceThreshold: 85, logoDataUrl: null,
    terms: ['Term 1', 'Term 2'], paymentCategories: ['Tuition', 'Registration Fee', 'Late Fee', 'Activity Fee'],
  },
};

/* ── Campuses (multi-campus from the ground up — section 37) ── */
SCHOOL_DATA.campuses = [
  { id:'camp1', name:'Main Campus — Rabat', address:'24 Avenue Hassan II, Rabat, Morocco', phone:'+212 537-123 456', status:'active', openedYear:2008 },
  { id:'camp2', name:'North Campus — Salé', address:'8 Rue Ibn Sina, Salé, Morocco', phone:'+212 537-987 654', status:'active', openedYear:2018 },
  { id:'camp3', name:'East Campus — Témara', address:'15 Boulevard Al Massira, Témara, Morocco', phone:'+212 537-456 789', status:'active', openedYear:2023 },
];

/* ── Classes across campuses ── */
SCHOOL_DATA.classes = [
  { id:'sc1', name:'Grade 7 - A', level:'Grade 7', capacity:30, campusId:'camp1', homeroomTeacherId:'st1' },
  { id:'sc2', name:'Grade 7 - B', level:'Grade 7', capacity:30, campusId:'camp1', homeroomTeacherId:'st2' },
  { id:'sc3', name:'Grade 8 - A', level:'Grade 8', capacity:28, campusId:'camp1', homeroomTeacherId:'st3' },
  { id:'sc4', name:'Grade 9 - A', level:'Grade 9', capacity:28, campusId:'camp1', homeroomTeacherId:'st4' },
  { id:'sc5', name:'Grade 10 - A', level:'Grade 10', capacity:26, campusId:'camp1', homeroomTeacherId:'st5' },
  { id:'sc6', name:'Grade 7 - N', level:'Grade 7', capacity:24, campusId:'camp2', homeroomTeacherId:'st6' },
  { id:'sc7', name:'Grade 8 - N', level:'Grade 8', capacity:24, campusId:'camp2', homeroomTeacherId:'st7' },
  { id:'sc8', name:'Grade 7 - E', level:'Grade 7', capacity:20, campusId:'camp3', homeroomTeacherId:'st8' },
];

/* ── Teachers ── */
SCHOOL_DATA.teachers = [
  { id:'st1', teacherId:'T2001001', name:'Mr. Karim Alaoui', subjects:['Mathematics'], classIds:['sc1'], campusId:'camp1', email:'k.alaoui@alfarabi.edu', phone:'+212 661-100 001', status:'active', joinedDate:'2019-09-01' },
  { id:'st2', teacherId:'T2001002', name:'Mrs. Salma Idrissi', subjects:['French'], classIds:['sc2'], campusId:'camp1', email:'s.idrissi@alfarabi.edu', phone:'+212 661-100 002', status:'active', joinedDate:'2017-09-01' },
  { id:'st3', teacherId:'T2001003', name:'Mr. Youssef Tazi', subjects:['Physics'], classIds:['sc3'], campusId:'camp1', email:'y.tazi@alfarabi.edu', phone:'+212 661-100 003', status:'active', joinedDate:'2020-09-01' },
  { id:'st4', teacherId:'T2001004', name:'Mrs. Amina Fassi', subjects:['English'], classIds:['sc4'], campusId:'camp1', email:'a.fassi@alfarabi.edu', phone:'+212 661-100 004', status:'active', joinedDate:'2016-09-01' },
  { id:'st5', teacherId:'T2001005', name:'Mr. Omar Ziani', subjects:['History-Geography'], classIds:['sc5'], campusId:'camp1', email:'o.ziani@alfarabi.edu', phone:'+212 661-100 005', status:'active', joinedDate:'2015-09-01' },
  { id:'st6', teacherId:'T2001006', name:'Mrs. Houda Sabri', subjects:['Mathematics'], classIds:['sc6'], campusId:'camp2', email:'h.sabri@alfarabi.edu', phone:'+212 661-100 006', status:'active', joinedDate:'2018-09-01' },
  { id:'st7', teacherId:'T2001007', name:'Mr. Rachid Belhaj', subjects:['Arabic'], classIds:['sc7'], campusId:'camp2', email:'r.belhaj@alfarabi.edu', phone:'+212 661-100 007', status:'active', joinedDate:'2019-09-01' },
  { id:'st8', teacherId:'T2001008', name:'Mrs. Latifa Ouahbi', subjects:['French'], classIds:['sc8'], campusId:'camp3', email:'l.ouahbi@alfarabi.edu', phone:'+212 661-100 008', status:'active', joinedDate:'2023-09-01' },
  { id:'st9', teacherId:'T2001009', name:'Mr. Adil Chraibi', subjects:['Physics','Mathematics'], classIds:['sc1','sc3'], campusId:'camp1', email:'a.chraibi@alfarabi.edu', phone:'+212 661-100 009', status:'active', joinedDate:'2021-09-01' },
  { id:'st10', teacherId:'T2001010', name:'Mrs. Zineb Mansouri', subjects:['English'], classIds:['sc6','sc7'], campusId:'camp2', email:'z.mansouri@alfarabi.edu', phone:'+212 661-100 010', status:'active', joinedDate:'2020-09-01' },
];

/* ── Guardians (hand-authored with some real sibling links) ── */
SCHOOL_DATA.guardians = [
  { id:'sg01', name:'Mr. Hassan Naciri', email:'hassan.naciri@example.com', phone:'+212 662-200 001', studentIds:['ss01'] },
  { id:'sg02', name:'Mrs. Houria Tahiri', email:'houria.tahiri@example.com', phone:'+212 662-200 002', studentIds:['ss02'] },
  { id:'sg03', name:'Mr. Said Benjelloun', email:'said.benjelloun@example.com', phone:'+212 662-200 003', studentIds:['ss03','ss04'] },
  { id:'sg04', name:'Mrs. Fatima Zahra Kabbaj', email:'fz.kabbaj@example.com', phone:'+212 662-200 004', studentIds:['ss05'] },
  { id:'sg05', name:'Mr. Mehdi Ouazzani', email:'mehdi.ouazzani@example.com', phone:'+212 662-200 005', studentIds:['ss06'] },
  { id:'sg06', name:'Mrs. Nawal Berrada', email:'nawal.berrada@example.com', phone:'+212 662-200 006', studentIds:['ss07'] },
  { id:'sg07', name:'Mr. Karim Sekkat', email:'karim.sekkat@example.com', phone:'+212 662-200 007', studentIds:['ss08','ss09'] },
  { id:'sg08', name:'Mrs. Samira El Fassi', email:'samira.elfassi@example.com', phone:'+212 662-200 008', studentIds:['ss10'] },
  { id:'sg09', name:'Mr. Aziz Lahlou', email:'aziz.lahlou@example.com', phone:'+212 662-200 009', studentIds:['ss11'] },
  { id:'sg10', name:'Mrs. Khadija Amrani', email:'khadija.amrani@example.com', phone:'+212 662-200 010', studentIds:['ss12'] },
  { id:'sg11', name:'Mr. Nabil Cherkaoui', email:'nabil.cherkaoui@example.com', phone:'+212 662-200 011', studentIds:['ss13'] },
  { id:'sg12', name:'Mrs. Malika Bouzidi', email:'malika.bouzidi@example.com', phone:'+212 662-200 012', studentIds:['ss14','ss15'] },
  { id:'sg13', name:'Mr. Tarik Idrissi', email:'tarik.idrissi@example.com', phone:'+212 662-200 013', studentIds:['ss16'] },
  { id:'sg14', name:'Mrs. Souad Rachidi', email:'souad.rachidi@example.com', phone:'+212 662-200 014', studentIds:['ss17'] },
  { id:'sg15', name:'Mr. Yassine Belmokhtar', email:'yassine.belmokhtar@example.com', phone:'+212 662-200 015', studentIds:['ss18'] },
  { id:'sg16', name:'Mrs. Amal Ziani', email:'amal.ziani@example.com', phone:'+212 662-200 016', studentIds:['ss19'] },
  { id:'sg17', name:'Mr. Reda Saidi', email:'reda.saidi@example.com', phone:'+212 662-200 017', studentIds:['ss20'] },
  { id:'sg18', name:'Mrs. Ibtissam Guerraoui', email:'ibtissam.guerraoui@example.com', phone:'+212 662-200 018', studentIds:['ss21','ss22'] },
  { id:'sg19', name:'Mr. Hicham Bakkali', email:'hicham.bakkali@example.com', phone:'+212 662-200 019', studentIds:['ss23'] },
  { id:'sg20', name:'Mrs. Loubna Chafai', email:'loubna.chafai@example.com', phone:'+212 662-200 020', studentIds:['ss24'] },
  { id:'sg21', name:'Mr. Anas Bahri', email:'anas.bahri@example.com', phone:'+212 662-200 021', studentIds:['ss25','ss26'] },
  { id:'sg22', name:'Mrs. Widad Tber', email:'widad.tber@example.com', phone:'+212 662-200 022', studentIds:['ss27'] },
  { id:'sg23', name:'Mr. Jamal Rguig', email:'jamal.rguig@example.com', phone:'+212 662-200 023', studentIds:['ss28'] },
  { id:'sg24', name:'Mrs. Zohra Ouahbi', email:'zohra.ouahbi@example.com', phone:'+212 662-200 024', studentIds:['ss29'] },
  { id:'sg25', name:'Mr. Bilal Sabri', email:'bilal.sabri@example.com', phone:'+212 662-200 025', studentIds:['ss30'] },
];

/* ── Students (30 total, distributed across 8 classes / 3 campuses) ── */
const SCH_STUDENT_SEED = [
  { id:'ss01', firstName:'Amine', lastName:'Naciri', dob:'2013-04-12', gender:'M', classId:'sc1', guardianId:'sg01' },
  { id:'ss02', firstName:'Salma', lastName:'Tahiri', dob:'2013-06-20', gender:'F', classId:'sc1', guardianId:'sg02' },
  { id:'ss03', firstName:'Adam', lastName:'Benjelloun', dob:'2013-02-08', gender:'M', classId:'sc1', guardianId:'sg03' },
  { id:'ss04', firstName:'Lina', lastName:'Benjelloun', dob:'2013-09-15', gender:'F', classId:'sc1', guardianId:'sg03' },
  { id:'ss05', firstName:'Yassmine', lastName:'Kabbaj', dob:'2013-11-01', gender:'F', classId:'sc1', guardianId:'sg04' },
  { id:'ss06', firstName:'Mehdi', lastName:'Ouazzani', dob:'2013-03-22', gender:'M', classId:'sc2', guardianId:'sg05' },
  { id:'ss07', firstName:'Rim', lastName:'Berrada', dob:'2013-07-30', gender:'F', classId:'sc2', guardianId:'sg06' },
  { id:'ss08', firstName:'Othmane', lastName:'Sekkat', dob:'2013-05-18', gender:'M', classId:'sc2', guardianId:'sg07' },
  { id:'ss09', firstName:'Nour', lastName:'Sekkat', dob:'2013-08-02', gender:'F', classId:'sc2', guardianId:'sg07' },
  { id:'ss10', firstName:'Ayoub', lastName:'El Fassi', dob:'2013-01-27', gender:'M', classId:'sc2', guardianId:'sg08' },
  { id:'ss11', firstName:'Ghita', lastName:'Lahlou', dob:'2012-04-09', gender:'F', classId:'sc3', guardianId:'sg09' },
  { id:'ss12', firstName:'Zakaria', lastName:'Amrani', dob:'2012-06-14', gender:'M', classId:'sc3', guardianId:'sg10' },
  { id:'ss13', firstName:'Hiba', lastName:'Cherkaoui', dob:'2012-02-25', gender:'F', classId:'sc3', guardianId:'sg11' },
  { id:'ss14', firstName:'Anas', lastName:'Bouzidi', dob:'2012-10-03', gender:'M', classId:'sc3', guardianId:'sg12' },
  { id:'ss15', firstName:'Douaa', lastName:'Bouzidi', dob:'2012-12-19', gender:'F', classId:'sc3', guardianId:'sg12' },
  { id:'ss16', firstName:'Ismail', lastName:'Idrissi', dob:'2011-03-11', gender:'M', classId:'sc4', guardianId:'sg13' },
  { id:'ss17', firstName:'Meryem', lastName:'Rachidi', dob:'2011-05-29', gender:'F', classId:'sc4', guardianId:'sg14' },
  { id:'ss18', firstName:'Bilal', lastName:'Belmokhtar', dob:'2011-07-07', gender:'M', classId:'sc4', guardianId:'sg15' },
  { id:'ss19', firstName:'Kenza', lastName:'Ziani', dob:'2011-09-23', gender:'F', classId:'sc4', guardianId:'sg16' },
  { id:'ss20', firstName:'Reda', lastName:'Saidi', dob:'2010-01-16', gender:'M', classId:'sc5', guardianId:'sg17' },
  { id:'ss21', firstName:'Sara', lastName:'Guerraoui', dob:'2010-04-04', gender:'F', classId:'sc5', guardianId:'sg18' },
  { id:'ss22', firstName:'Yassine', lastName:'Guerraoui', dob:'2010-08-21', gender:'M', classId:'sc5', guardianId:'sg18' },
  { id:'ss23', firstName:'Imane', lastName:'Bakkali', dob:'2013-02-14', gender:'F', classId:'sc6', guardianId:'sg19' },
  { id:'ss24', firstName:'Soufiane', lastName:'Chafai', dob:'2013-05-06', gender:'M', classId:'sc6', guardianId:'sg20' },
  { id:'ss25', firstName:'Dounia', lastName:'Bahri', dob:'2013-09-28', gender:'F', classId:'sc6', guardianId:'sg21' },
  { id:'ss26', firstName:'Marouane', lastName:'Bahri', dob:'2013-11-10', gender:'M', classId:'sc6', guardianId:'sg21' },
  { id:'ss27', firstName:'Chaimae', lastName:'Tber', dob:'2012-03-17', gender:'F', classId:'sc7', guardianId:'sg22' },
  { id:'ss28', firstName:'Othman', lastName:'Rguig', dob:'2012-06-30', gender:'M', classId:'sc7', guardianId:'sg23' },
  { id:'ss29', firstName:'Nada', lastName:'Ouahbi', dob:'2013-01-05', gender:'F', classId:'sc8', guardianId:'sg24' },
  { id:'ss30', firstName:'Ilyas', lastName:'Sabri', dob:'2013-08-12', gender:'M', classId:'sc8', guardianId:'sg25' },
];
SCHOOL_DATA.students = SCH_STUDENT_SEED.map(s => {
  const cls = SCHOOL_DATA.classes.find(c => c.id === s.classId);
  const attendanceRate = 78 + Math.round(schSeededRandom(s.id + 'att') * 20);
  const avgGrade = Math.round((9 + schSeededRandom(s.id + 'grade') * 9) * 10) / 10;
  const prevTermDelta = Math.round((schSeededRandom(s.id + 'prevterm') * 4 - 2) * 10) / 10;
  const prevTermAvgGrade = Math.max(6, Math.min(20, Math.round((avgGrade - prevTermDelta) * 10) / 10));
  const paymentRoll = schSeededRandom(s.id + 'pay');
  const paymentStatus = paymentRoll < 0.65 ? 'paid' : paymentRoll < 0.85 ? 'partial' : 'overdue';
  const enrollRoll = schSeededRandom(s.id + 'enroll');
  return {
    ...s, studentId:'S' + (3000100 + parseInt(s.id.slice(2), 10)),
    campusId: cls.campusId, enrollmentDate: enrollRoll < 0.85 ? '2025-09-01' : '2026-01-12',
    enrollmentStatus:'active', avgGrade, prevTermAvgGrade, attendanceRate, paymentStatus, status:'active',
  };
});

/* ── Admissions ── */
SCHOOL_DATA.admissions = [
  { id:'sad1', firstName:'Yasmine', lastName:'Fathi', dob:'2013-02-10', gender:'F', appliedLevel:'Grade 7', campusId:'camp1', guardianName:'Mrs. Amina Fathi', guardianEmail:'amina.fathi@example.com', guardianPhone:'+212 663-300 001', submittedDate:'2026-02-15', status:'pending', notes:'' },
  { id:'sad2', firstName:'Amir', lastName:'Belkadi', dob:'2012-08-22', gender:'M', appliedLevel:'Grade 8', campusId:'camp1', guardianName:'Mr. Said Belkadi', guardianEmail:'said.belkadi@example.com', guardianPhone:'+212 663-300 002', submittedDate:'2026-02-20', status:'under-review', notes:'Transcript received; awaiting interview.' },
  { id:'sad3', firstName:'Nisrine', lastName:'Alami', dob:'2013-05-14', gender:'F', appliedLevel:'Grade 7', campusId:'camp2', guardianName:'Mrs. Latifa Alami', guardianEmail:'latifa.alami@example.com', guardianPhone:'+212 663-300 003', submittedDate:'2026-02-10', status:'accepted', notes:'Strong academic record from previous school.' },
  { id:'sad4', firstName:'Othman', lastName:'Skalli', dob:'2011-11-03', gender:'M', appliedLevel:'Grade 10', campusId:'camp1', guardianName:'Mr. Jamal Skalli', guardianEmail:'jamal.skalli@example.com', guardianPhone:'+212 663-300 004', submittedDate:'2026-01-28', status:'rejected', notes:'Class capacity full for this level.' },
  { id:'sad5', firstName:'Chaimae', lastName:'Bennani', dob:'2013-03-19', gender:'F', appliedLevel:'Grade 7', campusId:'camp3', guardianName:'Mrs. Nezha Bennani', guardianEmail:'nezha.bennani@example.com', guardianPhone:'+212 663-300 005', submittedDate:'2026-03-02', status:'waitlisted', notes:'' },
  { id:'sad6', firstName:'Ilyas', lastName:'Haddad', dob:'2013-07-08', gender:'M', appliedLevel:'Grade 7', campusId:'camp1', guardianName:'Mr. Hassan Haddad', guardianEmail:'hassan.haddad@example.com', guardianPhone:'+212 663-300 006', submittedDate:'2026-03-08', status:'pending', notes:'' },
  { id:'sad7', firstName:'Sofia', lastName:'Kadiri', dob:'2012-09-12', gender:'F', appliedLevel:'Grade 8', campusId:'camp2', guardianName:'Mrs. Rajaa Kadiri', guardianEmail:'rajaa.kadiri@example.com', guardianPhone:'+212 663-300 007', submittedDate:'2026-03-09', status:'pending', notes:'' },
];
SCHOOL_DATA.orientations = [
  { id:'sor1', title:'New Families Orientation — Main Campus', date:'2026-03-24', time:'10:00', location:'Main Campus Auditorium', campusId:'camp1', instructions:'Please bring your acceptance letter and a valid ID.', status:'scheduled', participantIds:['sad1','sad6'], attended:{} },
  { id:'sor2', title:'North Campus Transfer Orientation', date:'2026-02-18', time:'09:00', location:'North Campus Room 3', campusId:'camp2', instructions:'Campus tour followed by a Q&A session with teachers.', status:'completed', participantIds:['sad3'], attended:{ sad3:true } },
];

/* ── Payments (tuition, 4,500 MAD/term, mirroring realistic per-student billing) ── */
const SCH_PAYMENT_METHODS = ['Bank Transfer', 'Card ending 4471', 'Cash', 'Check'];
/* ONE LEDGER, ROLE-SCOPED VIEW — see js/authren-payments.js.
   The Institution is the financial owner; this view covers its own
   students. A payment recorded by the Head for a shared student appears
   here immediately, because both roles read the same table. */
Object.defineProperty(SCHOOL_DATA, 'payments', {
  get() {
    const mine = {};
    (SCHOOL_DATA.students || []).forEach(st => { mine[st.id] = true; });
    return AUTHREN_LEDGER.payments.filter(p => mine[p.studentId]);
  },
  configurable: true,
});
let schReceiptCounter = 1;
SCHOOL_DATA.students.forEach(s => {
  const t1Method = SCH_PAYMENT_METHODS[Math.floor(schSeededRandom(s.id + 't1method') * SCH_PAYMENT_METHODS.length)];
  authrenSeedPayment({ source:'school',  id:'spay-' + s.id + '-t1', studentId:s.id, campusId:s.campusId, date:'2025-11-' + String(5 + Math.floor(schSeededRandom(s.id + 't1day') * 20)).padStart(2, '0'), description:'Term 1 Tuition', amount:4500, currency:'MAD', status:'paid', method:t1Method, reference:'RCPT-2025-' + String(schReceiptCounter++).padStart(3, '0') });
  if (s.paymentStatus === 'paid') {
    const method = SCH_PAYMENT_METHODS[Math.floor(schSeededRandom(s.id + 't2method') * SCH_PAYMENT_METHODS.length)];
    authrenSeedPayment({ source:'school',  id:'spay-' + s.id + '-t2', studentId:s.id, campusId:s.campusId, date:'2026-02-' + String(2 + Math.floor(schSeededRandom(s.id + 't2day') * 20)).padStart(2, '0'), description:'Term 2 Tuition', amount:4500, currency:'MAD', status:'paid', method, reference:'RCPT-2026-' + String(schReceiptCounter++).padStart(3, '0') });
  } else if (s.paymentStatus === 'partial') {
    const method = SCH_PAYMENT_METHODS[Math.floor(schSeededRandom(s.id + 't2method') * SCH_PAYMENT_METHODS.length)];
    authrenSeedPayment({ source:'school',  id:'spay-' + s.id + '-t2a', studentId:s.id, campusId:s.campusId, date:'2026-02-' + String(2 + Math.floor(schSeededRandom(s.id + 't2day') * 20)).padStart(2, '0'), description:'Term 2 Tuition (partial)', amount:2250, currency:'MAD', status:'paid', method, reference:'RCPT-2026-' + String(schReceiptCounter++).padStart(3, '0') });
    authrenSeedPayment({ source:'school',  id:'spay-' + s.id + '-t2b', studentId:s.id, campusId:s.campusId, date:'2026-03-30', description:'Term 2 Tuition (remaining balance)', amount:2250, currency:'MAD', status:'pending', method:null, reference:null });
  } else {
    authrenSeedPayment({ source:'school',  id:'spay-' + s.id + '-t2', studentId:s.id, campusId:s.campusId, date:'2026-02-28', description:'Term 2 Tuition', amount:4500, currency:'MAD', status:'overdue', method:null, reference:null });
  }
});

/* ── Calendar events ── */
SCHOOL_DATA.events = [
  { id:'sev1', title:'Board Meeting — Q1 Review', category:'meeting', date:'2026-03-16', startTime:'14:00', endTime:'16:00', location:'Main Campus Boardroom', campusId:'camp1', audience:'administration', description:'Quarterly review of institutional performance and finances.' },
  { id:'sev2', title:'Multi-Campus Sports Day', category:'school-event', date:'2026-03-28', startTime:'09:00', endTime:'15:00', location:'Main Campus Field', campusId:null, audience:'institution', description:'Annual inter-campus sports competition.' },
  { id:'sev3', title:'Term 2 Payment Deadline', category:'payment-deadline', date:'2026-03-30', startTime:'', endTime:'', location:'', campusId:null, audience:'guardians', description:'Final deadline for remaining Term 2 balances.' },
  { id:'sev4', title:'Admissions Open House — North Campus', category:'admissions-event', date:'2026-03-21', startTime:'10:00', endTime:'13:00', location:'North Campus', campusId:'camp2', audience:'institution', description:'Open house for prospective families at the North Campus.' },
  { id:'sev5', title:'National Holiday', category:'holiday', date:'2026-03-17', startTime:'', endTime:'', location:'', campusId:null, audience:'institution', description:'All campuses closed.' },
];

/* ── Announcements ── */
SCHOOL_DATA.announcements = [
  { id:'san1', subject:'Term 2 Report Cards Available', message:'Term 2 report cards are now available across all campuses. Guardians can review academic progress during upcoming parent meetings.', audience:'guardians', campusId:null, sentAt:'2026-03-05T09:00:00', sentBy:'Mrs. Nadia Bensouda', status:'sent', readRate:76 },
  { id:'san2', subject:'North Campus Open House', category:'admissions', message:'We are pleased to invite prospective families to our North Campus Open House on March 21st.', audience:'institution', campusId:'camp2', sentAt:'2026-03-08T11:00:00', sentBy:'Mrs. Nadia Bensouda', status:'sent', readRate:62 },
  { id:'san3', subject:'Board Meeting Reminder', message:'This is a reminder that the Q1 board meeting is scheduled for March 16th at the Main Campus.', audience:'administration', campusId:'camp1', sentAt:'2026-03-10T08:00:00', sentBy:'Mrs. Nadia Bensouda', status:'sent', readRate:100 },
];

/* ── Reclamations (anonymous — no submitter identity ever stored) ── */
SCHOOL_DATA.reclamations = [
  { id:'src1', referenceId:'RC-902113', category:'Facilities', subject:'Air conditioning issues at North Campus', description:'Several classrooms at the North Campus have had inconsistent air conditioning for the past two weeks.', priority:'medium', status:'open', campusId:'camp2', submittedDate:'2026-03-06', internalNotes:'' },
  { id:'src2', referenceId:'RC-773204', category:'Billing', subject:'Question about Term 2 partial payment', description:'A guardian raised confusion about how the partial payment plan is applied to the remaining balance.', priority:'low', status:'in-progress', campusId:'camp1', submittedDate:'2026-02-27', internalNotes:'Finance team is preparing a clarified billing statement.' },
  { id:'src3', referenceId:'RC-119345', category:'Facilities', subject:'Limited parking at East Campus', description:'Parking availability during drop-off hours is very limited at the East Campus.', priority:'low', status:'resolved', campusId:'camp3', submittedDate:'2026-02-10', internalNotes:'Additional temporary parking arranged with the neighboring lot starting Term 2 week 3.' },
  { id:'src4', referenceId:'RC-560182', category:'Safety', subject:'Poor lighting near Main Campus parking', description:'The lighting near the staff parking area is very dim in the evening, which feels unsafe during late pickups.', priority:'high', status:'open', campusId:'camp1', submittedDate:'2026-03-09', internalNotes:'' },
];

/* ── Subscription (Authren's real 4-tier plan structure) ── */
/* Derived from the canonical catalog in js/plans.js — no separate
   plan definitions live here any more. */
const SCH_SUBSCRIPTION_PLANS = AUTHREN_PLAN_ORDER.map(id => ({
  id: id,
  name: authrenPlan(id).name,
  price: authrenPlanPriceLabel(id, 'b100', 'monthly'),
  features: authrenPlanSummary(id),
}));
SCHOOL_DATA.subscription = {
  currentPlan: 'ELITE', billingStatus: 'active', renewalDate: '2026-09-01', billingCycle:'Monthly', // demo institution shows every feature at this stage
  history: [
    { date:'2025-09-01', event:'Subscribed to Authren Command', amount:'6,000 MAD' },
    { date:'2023-09-01', event:'Upgraded to Authren Growth', amount:'3,200 MAD' },
    { date:'2021-09-01', event:'Subscribed to Authren Start', amount:'1,500 MAD' },
  ],
  billingHistory: [
    { date:'2026-03-01', description:'Monthly subscription — Authren Command', amount:'6,000 MAD', status:'paid' },
    { date:'2026-02-01', description:'Monthly subscription — Authren Command', amount:'6,000 MAD', status:'paid' },
    { date:'2026-01-01', description:'Monthly subscription — Authren Command', amount:'6,000 MAD', status:'paid' },
  ],
};

/* ── Audit log ──
   ONE audit log. schLogAudit writes into the shared
   AUTHREN_LEDGER.auditLog (js/authren-payments.js) instead of a
   separate local array. SCHOOL_DATA.auditLog is a live, read-only
   translation of the Institution's own entries into the exact shape
   this file's existing display code already expects. */
function schLogAudit(action, objectType, objectLabel, previousValue, newValue) {
  if (typeof authrenLogAudit === 'function') {
    authrenLogAudit('school', currentSchoolType || 'owner', action, objectType, objectLabel, previousValue, newValue);
  }
}
Object.defineProperty(SCHOOL_DATA, 'auditLog', {
  get() {
    if (typeof AUTHREN_LEDGER === 'undefined') return [];
    return AUTHREN_LEDGER.auditLog
      .filter(a => a.actorRole === 'school')
      .map(a => {
        const d = new Date(a.at);
        return {
          id: a.id, action: a.action, objectType: a.objectType, objectLabel: a.objectLabel,
          previousValue: a.previousValue, newValue: a.newValue, user: SCHOOL_DATA.owner.name,
          date: isNaN(d) ? a.at : tISODateSch(d),
          time: isNaN(d) ? '' : String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'),
        };
      });
  },
  configurable: true,
});

/* ── Day-level attendance records (enables genuine date-range filtering) ── */
const SCH_ATTENDANCE_DAYS = ['2026-02-23','2026-02-24','2026-02-25','2026-02-26','2026-02-27','2026-03-02','2026-03-03','2026-03-04','2026-03-05','2026-03-06','2026-03-09','2026-03-10'];
SCHOOL_DATA.attendanceRecords = {};
SCH_ATTENDANCE_DAYS.forEach(date => {
  SCHOOL_DATA.attendanceRecords[date] = {};
  SCHOOL_DATA.students.forEach(s => {
    const r = schSeededRandom(s.id + date);
    const absenceProb = (100 - s.attendanceRate) / 100;
    let status = 'present';
    if (r < absenceProb * 0.55) status = 'absent';
    else if (r < absenceProb * 0.8) status = 'late';
    else if (r < absenceProb) status = 'excused';
    SCHOOL_DATA.attendanceRecords[date][s.id] = status;
  });
});
function schAttendanceStatusFor(studentId, date) {
  const day = SCHOOL_DATA.attendanceRecords[date];
  return day ? (day[studentId] || null) : null;
}
function schAggregateAttendance(studentIds, days) {
  let present = 0, absent = 0, late = 0, excused = 0, total = 0;
  days.forEach(d => studentIds.forEach(sid => {
    const status = schAttendanceStatusFor(sid, d);
    if (!status) return;
    total++;
    if (status === 'present') present++;
    else if (status === 'absent') absent++;
    else if (status === 'late') late++;
    else if (status === 'excused') excused++;
  }));
  const rate = total ? Math.round(((present + late) / total) * 100) : null;
  return { present, absent, late, excused, total, rate };
}

/* ── Enrollment records (one per student, extendable via new enrollments) ── */
SCHOOL_DATA.enrollments = SCHOOL_DATA.students.map(s => ({
  id:'senr-' + s.id, studentId:s.id, classId:s.classId, campusId:s.campusId,
  academicYear: SCHOOL_DATA.institution.academicYear, enrollmentDate:s.enrollmentDate, status:'active',
}));

/* ══════════════════════════════════════════════════════
   SHARED HELPERS
══════════════════════════════════════════════════════ */
function schGetCampus(id) { return SCHOOL_DATA.campuses.find(c => c.id === id) || null; }
function schGetClass(id) { return SCHOOL_DATA.classes.find(c => c.id === id) || null; }
function schGetTeacher(id) { return SCHOOL_DATA.teachers.find(t => t.id === id) || null; }
function schGetGuardian(id) { return SCHOOL_DATA.guardians.find(g => g.id === id) || null; }
function schGetStudent(id) { return SCHOOL_DATA.students.find(s => s.id === id) || null; }
function schGetAdmission(id) { return SCHOOL_DATA.admissions.find(a => a.id === id) || null; }
function schStudentFullName(s) { return `${s.firstName} ${s.lastName}`; }
function schClassStudents(classId) { return SCHOOL_DATA.students.filter(s => s.classId === classId); }
function schCampusClasses(campusId) { return SCHOOL_DATA.classes.filter(c => c.campusId === campusId); }
function schCampusStudents(campusId) { return SCHOOL_DATA.students.filter(s => s.campusId === campusId); }
function schCampusTeachers(campusId) { return SCHOOL_DATA.teachers.filter(t => t.campusId === campusId); }
function schAvg(arr) { const nums = arr.filter(v => typeof v === 'number' && !isNaN(v)); return nums.length ? Math.round((nums.reduce((s, v) => s + v, 0) / nums.length) * 10) / 10 : null; }
function schCurrency(amount) { return amount.toLocaleString() + ' MAD'; }
function schEsc(str) { return String(str == null ? '' : str).replace(/[&<>"']/g, ch => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[ch])); }
function schInitials(name) { return (name || '').split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase(); }
function schShowToast(msg) { gdShowToast(msg); }

/* ══════════════════════════════════════════════════════
   STATE
══════════════════════════════════════════════════════ */
let schState = {
  campusFilter: 'all',
  dashboard: { loadState: 'idle' },
  analyticsBasic: { campus:'all', level:'all', period:'all' },
  calendar: { calMonth:2, calYear:2026, selectedDate:null, screen:'month', eventId:null, form:null, error:'' },
  comms: { screen:'list', announcementId:null, compose:{ subject:'', message:'', audience:'institution', campusId:null, classId:null, preview:false }, sending:false, error:'', search:'' },
  reports: { type:'enrollment', campus:'all', period:'all', screen:'form', generatedAt:null },
  enrollment: { search:'', filterCampus:'all', filterStatus:'all', screen:'list', form:null, error:'', saving:false },
  dataManagement: { tab:'students', search:'', filterCampus:'all', sort:'name', detailId:null, editing:false, error:'' },
  adminBasic: { editing:null, error:'', notifPrefs:{ email:true, sms:false, weeklyDigest:true } },
  subscription: { screen:'main' },
  analyticsAdvanced: { campus:'all' },
  reportsAdvanced: { domains:['academic','attendance','enrollment'], campus:'all', period:'all', screen:'form', generatedAt:null, savedConfigs:[] },
  admissions: { search:'', filterStatus:'all', filterCampus:'all', screen:'list', appId:null, form:null, error:'', saving:false },
  orientation: { screen:'list', orId:null, form:null, error:'', saving:false, addParticipantSearch:'' },
  payments: { screen:'overview', studentId:null, paymentId:null },
  paymentRecords: { search:'', filterCampus:'all', filterStatus:'all', filterMethod:'all', minAmount:'', maxAmount:'' },
  reclamations: { screen:'list', filterStatus:'all', filterCampus:'all', rcId:null, form:null, error:'', saving:false },
  import: { tab:'student', step:1, dataType:'students', fileName:'', rawHeaders:[], rawRows:[], mapping:{}, validationRows:[], duplicateActions:{}, result:null, error:'' },
  accounts: { personType:'student', search:'', selected:[], listFilterType:'all', listFilterStatus:'all' },
  historicalData: { year:'2025-2026', search:'', category:'all' },
  intelligence: { periodType:'month' },
  campuses: { screen:'list', campusId:null, form:null, error:'' },
  audit: { search:'', filterAction:'all', filterCategory:'all', dateFrom:'', dateTo:'' },
  reportingAdvanced: { category:'academic', campus:'all', comparisonPeriod:'none', groupBy:'campus', screen:'form', generatedAt:null },
};

/* ══════════════════════════════════════════════════════
   ROUTE DISPATCHER
══════════════════════════════════════════════════════ */
function schoolView(v) {
  if (v === 'home') return schDashboardView();
  if (v === 'analytics-basic') return schAnalyticsBasicView();
  if (v === 'calendar') return schCalendarView();
  if (v === 'communication') return schCommunicationView();
  if (v === 'reports') return schReportsView();
  if (v === 'enrollment') return schEnrollmentView();
  if (v === 'data-management') return schDataManagementView();
  if (v === 'admin-basic') return schAdminBasicView();
  if (v === 'subscription') return schSubscriptionView();
  if (v === 'analytics-advanced') return schAnalyticsAdvancedView();
  if (v === 'reports-advanced') return schReportsAdvancedView();
  if (v === 'admissions') return schAdmissionsView();
  if (v === 'orientation') return schOrientationView();
  if (v === 'payments') return schPaymentsView();
  if (v === 'payment-records') return schPaymentRecordsView();
  if (v === 'reclamations') return schReclamationsView();
  if (v === 'import') return schImportView();
  if (v === 'accounts') return schAccountsView();
  if (v === 'historical-data') return schHistoricalDataView();
  if (v === 'pulse') return schPulseView();
  if (v === 'changed') return schWhatChangedView();
  if (v === 'analytics-schoolwide') return schAnalyticsSchoolwideView();
  if (v === 'analytics-complete') return schAnalyticsCompleteView();
  if (v === 'historical-comparisons') return schHistoricalComparisonsView();
  if (v === 'historical-advanced') return schHistoricalAdvancedView();
  if (v === 'problems') return schProblemDetectionView();
  if (v === 'intelligence') return schIntelligenceView();
  if (v === 'payments-advanced') return schPaymentsAdvancedView();
  if (v === 'payments-infra') return schPaymentsInfraView();
  if (v === 'admin-advanced') return schAdminAdvancedView();
  if (v === 'config') return schConfigView();
  if (v === 'plans') return schPlansView();
  if (v === 'campuses') return schCampusesView();
  if (v === 'branding') return schBrandingView();
  if (v === 'audit') return schAuditView();
  if (v === 'audit-advanced') return schAuditAdvancedView();
  if (v === 'reporting-advanced') return schReportingAdvancedView();
  return `<div class="card"><div class="card-body" style="color:var(--muted);text-align:center;padding:40px">${t('This section is coming soon.')}</div></div>`;
}

/* ══════════════════════════════════════════════════════
   SCHOOL DASHBOARD (section 3)
   Every card below is genuinely computed from SCHOOL_DATA and clickable
   — no decorative-only cards. Campus selector genuinely filters every
   scoped metric (section 37 built in from the start).
══════════════════════════════════════════════════════ */
function schDashboardView() {
  return `<div id="sch-dashboard-content">${schDashboardBody()}</div>`;
}
function schDashboardBody() {
  if (schState.dashboard.loadState === 'loading') {
    return `<div class="gd-sc-load-state"><span class="gd-spinner"></span>${t('Loading institution dashboard…')}</div>`;
  }
  const inst = SCHOOL_DATA.institution;
  const campusFilter = schState.campusFilter;
  const students = campusFilter === 'all' ? SCHOOL_DATA.students : schCampusStudents(campusFilter);
  const teachers = campusFilter === 'all' ? SCHOOL_DATA.teachers : schCampusTeachers(campusFilter);
  const guardianIds = new Set(students.map(s => s.guardianId));
  const guardians = campusFilter === 'all' ? SCHOOL_DATA.guardians : SCHOOL_DATA.guardians.filter(g => guardianIds.has(g.id));
  const classes = campusFilter === 'all' ? SCHOOL_DATA.classes : schCampusClasses(campusFilter);
  const payments = campusFilter === 'all' ? SCHOOL_DATA.payments : SCHOOL_DATA.payments.filter(p => p.campusId === campusFilter);
  const admissions = campusFilter === 'all' ? SCHOOL_DATA.admissions : SCHOOL_DATA.admissions.filter(a => a.campusId === campusFilter);
  const events = campusFilter === 'all' ? SCHOOL_DATA.events : SCHOOL_DATA.events.filter(e => !e.campusId || e.campusId === campusFilter);

  const attendanceAvg = schAvg(students.map(s => s.attendanceRate));
  const academicAvg = schAvg(students.map(s => s.avgGrade));
  const activeStudents = students.filter(s => s.status === 'active').length;
  const pendingAdmissions = admissions.filter(a => a.status === 'pending' || a.status === 'under-review').length;
  const collected = payments.filter(p => p.status === 'paid').reduce((s, p) => s + p.amount, 0);
  const outstanding = payments.filter(p => p.status !== 'paid').reduce((s, p) => s + p.amount, 0);
  const upcomingEvents = events.filter(e => e.date >= SCH_TODAY).sort((a, b) => a.date.localeCompare(b.date)).slice(0, 4);
  const recentAnnouncements = SCHOOL_DATA.announcements.filter(a => a.status === 'sent' && (campusFilter === 'all' || !a.campusId || a.campusId === campusFilter)).sort((a, b) => b.sentAt.localeCompare(a.sentAt)).slice(0, 3);
  const recentReclamations = SCHOOL_DATA.reclamations.filter(r => campusFilter === 'all' || r.campusId === campusFilter).sort((a, b) => b.submittedDate.localeCompare(a.submittedDate)).slice(0, 3);
  const currentPlan = SCH_SUBSCRIPTION_PLANS.find(p => p.id === SCHOOL_DATA.subscription.currentPlan);

  return `
    <div class="card"><div class="card-body" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px">
      <div style="display:flex;align-items:center;gap:12px">
        ${SCHOOL_DATA.settings.logoDataUrl ? `<img src="${SCHOOL_DATA.settings.logoDataUrl}" alt="" style="width:40px;height:40px;border-radius:10px;object-fit:cover">` : ''}
        <div>
          <div style="font-size:16px;font-weight:800">${schEsc(inst.name)}</div>
          <div style="font-size:12.5px;color:var(--muted);margin-top:2px">${schEsc(inst.academicYear)} · ${schEsc(inst.currentTerm)} · ${SCHOOL_DATA.campuses.length} ${t('campuses')}</div>
        </div>
      </div>
      <div style="display:flex;gap:10px;align-items:center">
        <select onchange="schSetCampusFilter(this.value)" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
          <option value="all" ${campusFilter==='all'?'selected':''}>${t('All Campuses')}</option>
          ${SCHOOL_DATA.campuses.map(c => `<option value="${c.id}" ${c.id===campusFilter?'selected':''}>${schEsc(c.name)}</option>`).join('')}
        </select>
        <button type="button" class="st-btn ghost sm" id="sch-refresh-btn" onclick="schRefreshDashboard()">↻ ${t('Refresh')}</button>
      </div>
    </div></div>

    <div class="gd-stat-row" style="margin-top:16px">
      <div class="stat-card" style="cursor:pointer" onclick="authrenGoTo('enrollment')"><div class="stat-label">${t('Total Enrollment')}</div><div class="stat-val">${students.length}</div><div class="stat-icon blue">${aIcon('graduation-cap')}</div></div>
      <div class="stat-card" style="cursor:pointer" onclick="authrenGoTo('data-management')"><div class="stat-label">${t('Active Students')}</div><div class="stat-val">${activeStudents}</div><div class="stat-icon green">${aIcon('check-circle')}</div></div>
      <div class="stat-card" style="cursor:pointer" onclick="authrenGoTo('data-management')"><div class="stat-label">${t('Teachers')}</div><div class="stat-val">${teachers.length}</div><div class="stat-icon purple">${aIcon('user')}</div></div>
      <div class="stat-card" style="cursor:pointer" onclick="authrenGoTo('data-management')"><div class="stat-label">${t('Guardians')}</div><div class="stat-val">${guardians.length}</div><div class="stat-icon yellow">${aIcon('users')}</div></div>
    </div>
    <div class="gd-stat-row" style="margin-top:16px">
      <div class="stat-card" style="cursor:pointer" onclick="authrenGoTo('data-management')"><div class="stat-label">${t('Classes')}</div><div class="stat-val">${classes.length}</div><div class="stat-icon blue">${aIcon('school')}</div></div>
      <div class="stat-card" style="cursor:pointer" onclick="authrenGoTo('analytics-basic')"><div class="stat-label">${t('Attendance Rate')}</div><div class="stat-val">${attendanceAvg !== null ? attendanceAvg + '%' : '—'}</div><div class="stat-icon ${attendanceAvg!==null&&attendanceAvg<88?'yellow':'green'}">${aIcon('clipboard')}</div></div>
      <div class="stat-card" style="cursor:pointer" onclick="authrenGoTo('analytics-basic')"><div class="stat-label">${t('Academic Performance')}</div><div class="stat-val">${academicAvg !== null ? academicAvg + '/20' : '—'}</div><div class="stat-icon ${academicAvg!==null&&academicAvg<12?'yellow':'green'}">${aIcon('bar-chart')}</div></div>
      <div class="stat-card" style="cursor:pointer" onclick="authrenGoTo('admissions')"><div class="stat-label">${t('Pending Admissions')}</div><div class="stat-val">${pendingAdmissions}</div><div class="stat-icon ${pendingAdmissions>0?'yellow':'green'}">${aIcon('inbox')}</div></div>
    </div>
    <div class="gd-stat-row" style="margin-top:16px">
      <div class="stat-card" style="cursor:pointer" onclick="schGoToOutstandingPayments()"><div class="stat-label">${t('Outstanding Payments')}</div><div class="stat-val" style="font-size:16px">${schCurrency(outstanding)}</div><div class="stat-icon ${outstanding>0?'yellow':'green'}">${aIcon('credit-card')}</div></div>
      <div class="stat-card" style="cursor:pointer" onclick="authrenGoTo('payments')"><div class="stat-label">${t('Collected Payments')}</div><div class="stat-val" style="font-size:16px">${schCurrency(collected)}</div><div class="stat-icon green">${aIcon('dollar-sign')}</div></div>
      <div class="stat-card" style="cursor:pointer" onclick="authrenGoTo('subscription')"><div class="stat-label">${t('Subscription Plan')}</div><div class="stat-val" style="font-size:16px">${schEsc(currentPlan.name)}</div><div class="stat-icon purple">${aIcon('star')}</div></div>
      <div class="stat-card" style="cursor:pointer" onclick="authrenGoTo('reclamations')"><div class="stat-label">${t('Open Reclamations')}</div><div class="stat-val">${SCHOOL_DATA.reclamations.filter(r=>r.status!=='resolved'&&r.status!=='archived').length}</div><div class="stat-icon yellow">${aIcon('alert-triangle')}</div></div>
    </div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Upcoming Events')}</div><div class="card-action" onclick="authrenGoTo('calendar')">${t('View Calendar')} →</div></div>
      <div class="card-body">${upcomingEvents.length ? upcomingEvents.map(e => `<div class="info-row"><span>${schEsc(e.title)}<div style="font-size:11px;color:var(--muted)">${e.date}${e.startTime?' · '+e.startTime:''}${schGetCampus(e.campusId)?' · '+schEsc(schGetCampus(e.campusId).name):' · '+t('All Campuses')}</div></span></div>`).join('') : `<div class="gd-empty-mini">${t('No upcoming events.')}</div>`}</div></div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Recent Communications')}</div><div class="card-action" onclick="authrenGoTo('communication')">${t('View All')} →</div></div>
      <div class="card-body">${recentAnnouncements.length ? recentAnnouncements.map(a => `<div class="info-row"><span>${schEsc(a.subject)}<div style="font-size:11px;color:var(--muted)">${a.sentAt.slice(0,10)}</div></span></div>`).join('') : `<div class="gd-empty-mini">${t('No communications yet.')}</div>`}</div></div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Recent Reclamations')}</div><div class="card-action" onclick="authrenGoTo('reclamations')">${t('View All')} →</div></div>
      <div class="card-body">${recentReclamations.length ? recentReclamations.map(r => `<div class="info-row"><span>${schEsc(r.subject)}<div style="font-size:11px;color:var(--muted)">${schEsc(r.referenceId)} · ${r.submittedDate}</div></span><span class="status-pill ${r.status==='resolved'?'paid':r.status==='in-progress'?'awaiting':'due'}">${t(r.status.charAt(0).toUpperCase()+r.status.slice(1).replace('-',' '))}</span></div>`).join('') : `<div class="gd-empty-mini">${t('No reclamations yet.')}</div>`}</div></div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Campuses')}</div><div class="card-action" onclick="authrenGoTo('campuses')">${t('Manage')} →</div></div>
      <div class="card-body">${SCHOOL_DATA.campuses.map(c => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="schSetCampusFilter('${c.id}');authrenGoTo('home')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();schSetCampusFilter('${c.id}');authrenGoTo('home')}"><span>${schEsc(c.name)}<div style="font-size:11px;color:var(--muted)">${schCampusStudents(c.id).length} ${t('students')} · ${schCampusTeachers(c.id).length} ${t('teachers')} · ${schCampusClasses(c.id).length} ${t('classes')}</div></span><span class="status-pill ${c.status==='active'?'paid':'overdue'}">${t(c.status.charAt(0).toUpperCase()+c.status.slice(1))}</span></div>`).join('')}</div></div>`;
}
function schSetCampusFilter(v) {
  schState.campusFilter = v;
  const el = document.getElementById('sch-dashboard-content');
  if (el) el.innerHTML = schDashboardBody();
}
function schGoToOutstandingPayments() {
  authrenGoTo('payment-records');
}
function schRefreshDashboard() {
  schState.dashboard.loadState = 'loading';
  const el = document.getElementById('sch-dashboard-content');
  if (el) el.innerHTML = schDashboardBody();
  setTimeout(() => {
    schState.dashboard.loadState = 'ready';
    const el2 = document.getElementById('sch-dashboard-content');
    if (el2) el2.innerHTML = schDashboardBody();
    schShowToast(t('Dashboard refreshed.'));
  }, 500);
}

/* ══════════════════════════════════════════════════════
   BASIC SCHOOL ANALYTICS (section 4)
   Campus, Level, and Date-Range filters all genuinely recompute the
   displayed numbers — verified against independently-computed sums.
══════════════════════════════════════════════════════ */
function schAnalyticsBasicView() {
  return `<div id="sch-analytics-basic-content">${schAnalyticsBasicBody()}</div>`;
}
function schAnalyticsBasicBody() {
  const f = schState.analyticsBasic;
  let students = SCHOOL_DATA.students;
  let teachers = SCHOOL_DATA.teachers;
  let classes = SCHOOL_DATA.classes;
  let payments = SCHOOL_DATA.payments;
  let admissions = SCHOOL_DATA.admissions;
  if (f.campus !== 'all') {
    students = students.filter(s => s.campusId === f.campus);
    teachers = teachers.filter(te => te.campusId === f.campus);
    classes = classes.filter(c => c.campusId === f.campus);
    payments = payments.filter(p => p.campusId === f.campus);
    admissions = admissions.filter(a => a.campusId === f.campus);
  }
  if (f.level !== 'all') {
    const levelClassIds = classes.filter(c => c.level === f.level).map(c => c.id);
    students = students.filter(s => levelClassIds.includes(s.classId));
    classes = classes.filter(c => c.level === f.level);
  }
  const attendanceDays = f.period === 'week' ? SCH_ATTENDANCE_DAYS.slice(-5) : f.period === 'month' ? SCH_ATTENDANCE_DAYS : SCH_ATTENDANCE_DAYS;
  const attAgg = schAggregateAttendance(students.map(s => s.id), attendanceDays);
  const academicAvg = schAvg(students.map(s => s.avgGrade));
  const guardianIds = new Set(students.map(s => s.guardianId));
  const guardianCount = SCHOOL_DATA.guardians.filter(g => guardianIds.has(g.id)).length;
  const collected = payments.filter(p => p.status === 'paid').reduce((s, p) => s + p.amount, 0);
  const outstanding = payments.filter(p => p.status !== 'paid').reduce((s, p) => s + p.amount, 0);
  const levels = Array.from(new Set(SCHOOL_DATA.classes.map(c => c.level)));

  return `
    <div class="card"><div class="card-header"><div class="card-title">${t('Basic School Analytics')}</div></div>
      <div class="card-body">
        <div style="font-size:11.5px;color:var(--muted);margin-bottom:10px">${t('Academic Year')}: ${schEsc(SCHOOL_DATA.institution.academicYear)} · ${schEsc(SCHOOL_DATA.institution.currentTerm)}</div>
        <div style="display:flex;gap:10px;flex-wrap:wrap">
          <select onchange="schSetAnalyticsBasicFilter('campus', this.value)" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
            <option value="all" ${f.campus==='all'?'selected':''}>${t('All Campuses')}</option>
            ${SCHOOL_DATA.campuses.map(c => `<option value="${c.id}" ${c.id===f.campus?'selected':''}>${schEsc(c.name)}</option>`).join('')}
          </select>
          <select onchange="schSetAnalyticsBasicFilter('level', this.value)" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
            <option value="all" ${f.level==='all'?'selected':''}>${t('All Levels')}</option>
            ${levels.map(l => `<option value="${l}" ${l===f.level?'selected':''}>${schEsc(l)}</option>`).join('')}
          </select>
          <select onchange="schSetAnalyticsBasicFilter('period', this.value)" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
            <option value="all" ${f.period==='all'?'selected':''}>${t('Full Term')}</option>
            <option value="month" ${f.period==='month'?'selected':''}>${t('Last 12 School Days')}</option>
            <option value="week" ${f.period==='week'?'selected':''}>${t('Last 5 School Days')}</option>
          </select>
        </div>
      </div></div>
    <div id="sch-analytics-basic-results">${schAnalyticsBasicResultsBlock({ students, teachers, classes, admissions, attAgg, academicAvg, guardianCount, collected, outstanding })}</div>`;
}
function schAnalyticsBasicResultsBlock(d) {
  return `
    <div class="gd-stat-row" style="margin-top:16px">
      <div class="stat-card"><div class="stat-label">${t('Enrollment')}</div><div class="stat-val">${d.students.length}</div><div class="stat-icon blue">${aIcon('graduation-cap')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Active Students')}</div><div class="stat-val">${d.students.filter(s=>s.status==='active').length}</div><div class="stat-icon green">${aIcon('check-circle')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Classes')}</div><div class="stat-val">${d.classes.length}</div><div class="stat-icon purple">${aIcon('school')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Teachers')}</div><div class="stat-val">${d.teachers.length}</div><div class="stat-icon yellow">${aIcon('user')}</div></div>
    </div>
    <div class="gd-stat-row" style="margin-top:16px">
      <div class="stat-card"><div class="stat-label">${t('Guardians')}</div><div class="stat-val">${d.guardianCount}</div><div class="stat-icon blue">${aIcon('users')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Attendance Rate')}</div><div class="stat-val">${d.attAgg.rate !== null ? d.attAgg.rate + '%' : '—'}</div><div class="stat-icon ${d.attAgg.rate!==null&&d.attAgg.rate<88?'yellow':'green'}">${aIcon('clipboard')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Admissions Count')}</div><div class="stat-val">${d.admissions.length}</div><div class="stat-icon purple">${aIcon('inbox')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Payment Collection')}</div><div class="stat-val" style="font-size:15px">${schCurrency(d.collected)}</div><div class="stat-icon green">${aIcon('dollar-sign')}</div></div>
    </div>
    <div class="card" style="margin-top:16px"><div class="card-body">
      <div class="info-row"><span>${t('Outstanding Amount')}</span><span style="color:${d.outstanding>0?'var(--yellow)':'var(--green)'}">${schCurrency(d.outstanding)}</span></div>
    </div></div>`;
}
function schSetAnalyticsBasicFilter(key, value) {
  schState.analyticsBasic[key] = value;
  const el = document.getElementById('sch-analytics-basic-content');
  if (el) el.innerHTML = schAnalyticsBasicBody();
}

/* ══════════════════════════════════════════════════════
   SCHOOL CALENDAR (section 5) — full CRUD, real categories,
   confirmation-gated delete, immediate calendar refresh on edit.
══════════════════════════════════════════════════════ */
const SCH_EVENT_CATEGORIES = ['holiday', 'exam', 'school-event', 'meeting', 'orientation', 'admissions-event', 'payment-deadline', 'academic-deadline'];
const SCH_EVENT_CATEGORY_LABELS = { holiday:'Holiday', exam:'Exam', 'school-event':'School Event', meeting:'Meeting', orientation:'Orientation', 'admissions-event':'Admissions Event', 'payment-deadline':'Payment Deadline', 'academic-deadline':'Academic Deadline' };
const SCH_EVENT_CATEGORY_PILL = { holiday:'resolved', exam:'overdue', 'school-event':'open', meeting:'awaiting', orientation:'open', 'admissions-event':'awaiting', 'payment-deadline':'overdue', 'academic-deadline':'awaiting' };
function schGetEvent(id) { return SCHOOL_DATA.events.find(e => e.id === id) || null; }
function schEventsForDate(dateStr) { return SCHOOL_DATA.events.filter(e => e.date === dateStr); }
function schCalendarView() {
  return `<div id="sch-calendar-content">${schCalendarBody()}</div>`;
}
function schCalendarBody() {
  const s = schState.calendar;
  if (s.screen === 'form') return schEventFormScreen();
  if (s.screen === 'detail') { const ev = schGetEvent(s.eventId); if (!ev) { s.screen = 'month'; return schCalendarBody(); } return schEventDetailScreen(ev); }
  return schCalendarMonthView();
}
function schRefreshCalendar() { const el = document.getElementById('sch-calendar-content'); if (el) el.innerHTML = schCalendarBody(); }
function schCalendarMonthView() {
  const st = schState.calendar;
  return `<div class="card"><div class="card-header"><div class="card-title">${t('School Calendar')}</div><button class="st-btn sm" onclick="schOpenEventForm()">+ ${t('Create Event')}</button></div>
    <div class="card-body">
      <div class="gd-cal-header">
        <button type="button" class="gd-cal-nav-btn" onclick="schCalNav(-1)" aria-label="${t('Previous month')}"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="15 18 9 12 15 6"/></svg></button>
        <div class="gd-cal-title">${t(GD_ATT_MONTH_NAMES[st.calMonth])} ${st.calYear}</div>
        <button type="button" class="gd-cal-nav-btn" onclick="schCalNav(1)" aria-label="${t('Next month')}"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="9 18 15 12 9 6"/></svg></button>
      </div>
      <div class="gd-cal-grid">
        ${GD_ATT_DOW_NAMES.map(d => `<div class="gd-cal-dow">${t(d)}</div>`).join('')}
        ${schCalCells()}
      </div>
      <div id="sch-cal-detail" style="margin-top:14px">${st.selectedDate ? schCalDetail(st.selectedDate) : ''}</div>
    </div></div>`;
}
function schCalCells() {
  const st = schState.calendar;
  const firstDow = new Date(st.calYear, st.calMonth, 1).getDay();
  const daysInMonth = new Date(st.calYear, st.calMonth + 1, 0).getDate();
  let html = '';
  for (let i = 0; i < firstDow; i++) html += `<div class="gd-cal-day empty"></div>`;
  for (let d = 1; d <= daysInMonth; d++) {
    const dateStr = gdAttDateKey(st.calYear, st.calMonth, d);
    const dayEvents = schEventsForDate(dateStr);
    const isToday = dateStr === SCH_TODAY;
    const isSelected = dateStr === st.selectedDate;
    const dots = dayEvents.slice(0, 3).map(e => `<span class="gd-cal-dot ${SCH_EVENT_CATEGORY_PILL[e.category]==='overdue'?'exam':SCH_EVENT_CATEGORY_PILL[e.category]==='awaiting'?'meeting':SCH_EVENT_CATEGORY_PILL[e.category]==='resolved'?'holiday':'activity'}"></span>`).join('');
    html += `<div class="gd-cal-day${isToday?' today':''}${isSelected?' selected':''}${dayEvents.length?' has-events':''}" onclick="schCalSelectDay('${dateStr}')">
      <div class="gd-cal-day-num">${d}</div><div class="gd-cal-dots-row">${dots}</div>
    </div>`;
  }
  return html;
}
function schCalNav(delta) {
  const st = schState.calendar;
  st.calMonth += delta;
  if (st.calMonth < 0) { st.calMonth = 11; st.calYear--; }
  if (st.calMonth > 11) { st.calMonth = 0; st.calYear++; }
  st.selectedDate = null;
  schRefreshCalendar();
}
function schCalSelectDay(dateStr) {
  schState.calendar.selectedDate = dateStr;
  const grid = document.querySelector('#sch-calendar-content .gd-cal-grid');
  if (grid) grid.innerHTML = `${GD_ATT_DOW_NAMES.map(d => `<div class="gd-cal-dow">${t(d)}</div>`).join('')}${schCalCells()}`;
  const detail = document.getElementById('sch-cal-detail');
  if (detail) detail.innerHTML = schCalDetail(dateStr);
}
function schCalDetail(dateStr) {
  const events = schEventsForDate(dateStr);
  if (!events.length) return `<div class="gd-empty-mini">${t('No events on this day.')}</div>`;
  return events.map(e => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="schOpenEventDetail('${e.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();schOpenEventDetail('${e.id}')}">
    <span>${schEsc(e.title)}<div style="font-size:11px;color:var(--muted)">${e.startTime ? e.startTime + (e.endTime ? '–' + e.endTime : '') : t('All day')}${schGetCampus(e.campusId) ? ' · ' + schEsc(schGetCampus(e.campusId).name) : ''}</div></span>
    <span class="status-pill ${SCH_EVENT_CATEGORY_PILL[e.category]}">${t(SCH_EVENT_CATEGORY_LABELS[e.category])}</span>
  </div>`).join('');
}

/* ── Event Detail ── */
function schOpenEventDetail(id) { schState.calendar.screen = 'detail'; schState.calendar.eventId = id; schRefreshCalendar(); }
function schBackToCalendar() { schState.calendar.screen = 'month'; schState.calendar.eventId = null; schRefreshCalendar(); }
function schEventDetailScreen(e) {
  const campus = schGetCampus(e.campusId);
  return `<div class="card"><div class="card-header">
    <div style="display:flex;align-items:center;gap:10px;min-width:0;flex:1"><button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="schBackToCalendar()">${t('← Back')}</button><div class="card-title" style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${schEsc(e.title)}</div></div>
    <button type="button" class="st-btn ghost sm" onclick="schOpenEventForm('${e.id}')">${t('Edit')}</button>
  </div>
    <div class="card-body">
      <div class="info-row"><span>${t('Category')}</span><span class="status-pill ${SCH_EVENT_CATEGORY_PILL[e.category]}">${t(SCH_EVENT_CATEGORY_LABELS[e.category])}</span></div>
      <div class="info-row"><span>${t('Date')}</span><span>${e.date}</span></div>
      ${e.startTime ? `<div class="info-row"><span>${t('Time')}</span><span>${e.startTime}${e.endTime?'–'+e.endTime:''}</span></div>` : ''}
      ${e.location ? `<div class="info-row"><span>${t('Location')}</span><span>${schEsc(e.location)}</span></div>` : ''}
      <div class="info-row"><span>${t('Campus')}</span><span>${campus ? schEsc(campus.name) : t('All Campuses')}</span></div>
      <div class="info-row"><span>${t('Audience')}</span><span>${schAudienceLabel(e.audience)}</span></div>
      ${e.description ? `<div style="margin-top:10px;font-size:13px;color:var(--muted2);line-height:1.5">${schEsc(e.description)}</div>` : ''}
      <button type="button" class="st-btn ghost sm" style="margin-top:14px;color:var(--red)" onclick="schConfirmDeleteEvent('${e.id}')">${t('Delete Event')}</button>
    </div></div>`;
}
function schAudienceLabel(aud) { return { institution:t('Entire Institution'), students:t('Students'), guardians:t('Guardians'), teachers:t('Teachers'), administration:t('Administration') }[aud] || aud; }
function schConfirmDeleteEvent(id) {
  const e = schGetEvent(id);
  if (!e) return;
  stOpenModal(`<h3 style="margin-bottom:10px">${t('Delete this event?')}</h3>
    <p style="font-size:13px;color:var(--muted);margin-bottom:18px">"${schEsc(e.title)}" ${t('will be permanently removed from the calendar. This cannot be undone.')}</p>
    <div style="display:flex;gap:10px">
      <button class="st-btn" style="background:var(--red)" onclick="schDeleteEvent('${id}');stCloseModal()">${t('Delete')}</button>
      <button class="st-btn ghost" onclick="stCloseModal()">${t('Cancel')}</button>
    </div>`);
}
function schDeleteEvent(id) {
  const e = schGetEvent(id);
  SCHOOL_DATA.events = SCHOOL_DATA.events.filter(x => x.id !== id);
  if (e) schLogAudit('Event Deleted', 'Calendar Event', e.title, e.date, '');
  schBackToCalendar();
  schShowToast(t('Event deleted.'));
}

/* ── Create / Edit Event ── */
function schOpenEventForm(id) {
  if (id) {
    const e = schGetEvent(id);
    if (!e) return;
    schState.calendar.form = { mode:'edit', id:e.id, title:e.title, category:e.category, date:e.date, startTime:e.startTime, endTime:e.endTime, location:e.location, campusId:e.campusId || '', audience:e.audience, description:e.description };
  } else {
    const defaultDate = schState.calendar.selectedDate || SCH_TODAY;
    schState.calendar.form = { mode:'create', id:null, title:'', category:'school-event', date:defaultDate, startTime:'', endTime:'', location:'', campusId:'', audience:'institution', description:'' };
  }
  schState.calendar.screen = 'form';
  schState.calendar.error = '';
  schRefreshCalendar();
}
function schCancelEventForm() {
  const wasEdit = schState.calendar.form && schState.calendar.form.mode === 'edit';
  const editedId = schState.calendar.form ? schState.calendar.form.id : null;
  schState.calendar.form = null;
  schState.calendar.error = '';
  if (wasEdit) { schState.calendar.screen = 'detail'; schState.calendar.eventId = editedId; } else { schState.calendar.screen = 'month'; }
  schRefreshCalendar();
}
function schEventFormScreen() {
  const f = schState.calendar.form;
  const err = schState.calendar.error;
  return `<div class="card"><div class="card-header"><div class="card-title">${f.mode==='edit'?t('Edit Event'):t('Create Event')}</div></div>
    <div class="card-body">
      <div class="st-field"><label>${t('Title')}</label><input id="sch-ev-title" value="${schEsc(f.title)}"></div>
      <div class="st-field"><label>${t('Category')}</label><select id="sch-ev-category">
        ${SCH_EVENT_CATEGORIES.map(c => `<option value="${c}" ${c===f.category?'selected':''}>${t(SCH_EVENT_CATEGORY_LABELS[c])}</option>`).join('')}
      </select></div>
      <div style="display:flex;gap:10px">
        <div class="st-field" style="flex:1"><label>${t('Date')}</label><input id="sch-ev-date" type="date" value="${f.date}"></div>
        <div class="st-field" style="flex:1"><label>${t('Start Time')} (${t('optional')})</label><input id="sch-ev-start" type="time" value="${f.startTime}"></div>
        <div class="st-field" style="flex:1"><label>${t('End Time')} (${t('optional')})</label><input id="sch-ev-end" type="time" value="${f.endTime}"></div>
      </div>
      <div class="st-field"><label>${t('Location')} (${t('optional')})</label><input id="sch-ev-location" value="${schEsc(f.location)}"></div>
      <div class="st-field"><label>${t('Campus')}</label><select id="sch-ev-campus">
        <option value="" ${!f.campusId?'selected':''}>${t('All Campuses')}</option>
        ${SCHOOL_DATA.campuses.map(c => `<option value="${c.id}" ${c.id===f.campusId?'selected':''}>${schEsc(c.name)}</option>`).join('')}
      </select></div>
      <div class="st-field"><label>${t('Audience')}</label><select id="sch-ev-audience">
        <option value="institution" ${f.audience==='institution'?'selected':''}>${t('Entire Institution')}</option>
        <option value="students" ${f.audience==='students'?'selected':''}>${t('Students')}</option>
        <option value="guardians" ${f.audience==='guardians'?'selected':''}>${t('Guardians')}</option>
        <option value="teachers" ${f.audience==='teachers'?'selected':''}>${t('Teachers')}</option>
        <option value="administration" ${f.audience==='administration'?'selected':''}>${t('Administration')}</option>
      </select></div>
      <div class="st-field"><label>${t('Description')} (${t('optional')})</label><textarea id="sch-ev-description" rows="3">${schEsc(f.description)}</textarea></div>
      <div style="display:flex;gap:10px">
        <button class="st-btn" onclick="schSaveEvent()">${f.mode==='edit'?t('Save Changes'):t('Create Event')}</button>
        <button class="st-btn ghost" onclick="schCancelEventForm()">${t('Cancel')}</button>
      </div>
      ${err ? `<div class="st-inline-msg err show" style="margin-top:12px">${err}</div>` : ''}
    </div></div>`;
}
function schSaveEvent() {
  const f = schState.calendar.form;
  const title = (document.getElementById('sch-ev-title').value || '').trim();
  const category = document.getElementById('sch-ev-category').value;
  const date = document.getElementById('sch-ev-date').value;
  const startTime = document.getElementById('sch-ev-start').value;
  const endTime = document.getElementById('sch-ev-end').value;
  const location = (document.getElementById('sch-ev-location').value || '').trim();
  const campusId = document.getElementById('sch-ev-campus').value || null;
  const audience = document.getElementById('sch-ev-audience').value;
  const description = (document.getElementById('sch-ev-description').value || '').trim();
  Object.assign(f, { title, category, date, startTime, endTime, location, campusId, audience, description });

  let err = '';
  if (!title) err = t('Title is required.');
  else if (!date) err = t('Select a date.');
  else if (startTime && endTime && endTime <= startTime) err = t('End time must be after start time.');

  schState.calendar.error = err;
  if (err) { schRefreshCalendar(); return; }

  if (f.mode === 'edit') {
    const e = schGetEvent(f.id);
    const oldDate = e.date;
    Object.assign(e, { title, category, date, startTime, endTime, location, campusId, audience, description });
    schLogAudit('Event Edited', 'Calendar Event', title, oldDate, date);
    schState.calendar.screen = 'detail';
    schState.calendar.eventId = e.id;
    schShowToast(t('Event updated successfully.'));
  } else {
    const newEvent = { id:'sev' + Date.now(), title, category, date, startTime, endTime, location, campusId, audience, description };
    SCHOOL_DATA.events.push(newEvent);
    schLogAudit('Event Created', 'Calendar Event', title, '', date);
    schState.calendar.screen = 'detail';
    schState.calendar.eventId = newEvent.id;
    schState.calendar.selectedDate = date;
    schShowToast(t('Event created successfully.'));
  }
  schState.calendar.form = null;
  schRefreshCalendar();
}

/* ══════════════════════════════════════════════════════
   SCHOOL COMMUNICATION (section 6)
══════════════════════════════════════════════════════ */
function schCommunicationView() {
  const tabs = [ { id:'main', label:'Compose & History' }, { id:'drafts', label:'Drafts & Scheduled' }, { id:'templates', label:'Templates & Groups' } ];
  return `<div class="st-tabs">${tabs.map(tb => `<div class="st-tab gd-tab-schcom${(schState.comms.tab||'main')===tb.id?' active':''}" data-tab="${tb.id}" onclick="schSetCommsTab('${tb.id}')">${t(tb.label)}</div>`).join('')}</div>
    <div id="sch-comms-content">${schCommsTabBody()}</div>`;
}
function schSetCommsTab(tabId) {
  schState.comms.tab = tabId;
  document.querySelectorAll('.gd-tab-schcom').forEach(el => el.classList.toggle('active', el.dataset.tab === tabId));
  const el = document.getElementById('sch-comms-content');
  if (el) el.innerHTML = schCommsTabBody();
}
function schCommsTabBody() {
  if (schState.comms.tab === 'drafts') return schCommsDraftsTab();
  if (schState.comms.tab === 'templates') return schCommsTemplatesTab();
  return schCommsBody();
}
function schCommsBody() {
  const s = schState.comms;
  if (s.screen === 'compose') return schComposeScreen();
  if (s.screen === 'detail') { const a = SCHOOL_DATA.announcements.find(x => x.id === s.announcementId); if (!a) { s.screen = 'list'; return schCommsBody(); } return schAnnouncementDetailScreen(a); }
  return schCommsListScreen();
}
function schRefreshComms() { const el = document.getElementById('sch-comms-content'); if (el) el.innerHTML = schCommsTabBody(); }
function schCommsListScreen() {
  const s = schState.comms;
  let sorted = SCHOOL_DATA.announcements.filter(a => a.status === 'sent');
  const q = s.search.trim().toLowerCase();
  if (q) sorted = sorted.filter(a => a.subject.toLowerCase().includes(q) || a.message.toLowerCase().includes(q));
  sorted = sorted.sort((a, b) => b.sentAt.localeCompare(a.sentAt));
  return `<div class="card"><div class="card-header"><div class="card-title">${t('School Communication')}</div><button class="st-btn sm" onclick="schOpenComposeAnnouncement()">+ ${t('New Announcement')}</button></div>
    <div class="card-body">
      <input class="gd-comm-search-input" type="text" placeholder="${t('Search communications...')}" value="${schEsc(s.search)}" oninput="schSetCommsSearch(this.value)">
      <div id="sch-comms-results" style="margin-top:10px">${schCommsResultsBlock()}</div>
    </div></div>`;
}
function schCommsResultsBlock() {
  const s = schState.comms;
  let sorted = SCHOOL_DATA.announcements.filter(a => a.status === 'sent');
  const q = s.search.trim().toLowerCase();
  if (q) sorted = sorted.filter(a => a.subject.toLowerCase().includes(q) || a.message.toLowerCase().includes(q));
  sorted = sorted.sort((a, b) => b.sentAt.localeCompare(a.sentAt));
  if (!sorted.length) return `<div class="gd-empty-state"><div class="gd-empty-state-title">${t('No communications found')}</div><div class="gd-empty-state-sub">${t('Try a different search, or send your first announcement.')}</div></div>`;
  return sorted.map(a => `<div class="info-row" style="cursor:pointer;align-items:flex-start" role="button" tabindex="0" onclick="schOpenAnnouncementDetail('${a.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();schOpenAnnouncementDetail('${a.id}')}">
    <span>${schEsc(a.subject)}<div style="font-size:11.5px;color:var(--muted);margin-top:4px;max-width:360px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${schEsc(a.message)}</div></span>
    <span style="text-align:right;flex-shrink:0"><span class="status-pill open">${schCommsAudienceLabel(a)}</span><div style="font-size:11px;color:var(--muted);margin-top:4px">${a.sentAt.slice(0,10)}</div></span>
  </div>`).join('');
}
function schCommsAudienceLabel(a) {
  if (a.audience === 'campus') { const c = schGetCampus(a.campusId); return c ? c.name : t('Campus'); }
  if (a.audience === 'class') { const c = schGetClass(a.classId); return c ? c.name : t('Class'); }
  return schAudienceLabel(a.audience);
}
function schSetCommsSearch(v) { schState.comms.search = v; const el = document.getElementById('sch-comms-results'); if (el) el.innerHTML = schCommsResultsBlock(); }
function schOpenAnnouncementDetail(id) { schState.comms.screen = 'detail'; schState.comms.announcementId = id; schRefreshComms(); }
function schBackToCommsList() { schState.comms.screen = 'list'; schState.comms.announcementId = null; schRefreshComms(); }
function schAnnouncementDetailScreen(a) {
  return `<div class="card"><div class="card-header">
    <div style="display:flex;align-items:center;gap:10px"><button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="schBackToCommsList()">${t('← Back')}</button><div class="card-title">${t('Announcement')}</div></div>
  </div>
    <div class="card-body">
      <div style="font-weight:700;font-size:15px">${schEsc(a.subject)}</div>
      <div style="font-size:11.5px;color:var(--muted);margin:6px 0 14px">${t('Sent')} ${a.sentAt.slice(0,10)} ${a.sentAt.slice(11,16)} · ${schCommsAudienceLabel(a)} · ${schEsc(a.sentBy)}</div>
      <div style="font-size:13.5px;line-height:1.6;color:var(--muted2);white-space:pre-wrap">${schEsc(a.message)}</div>
    </div></div>`;
}

/* ── Compose / Preview / Send ── */
function schOpenComposeAnnouncement() {
  schState.comms.compose = { subject:'', message:'', audience:'institution', campusId:null, classId:null, preview:false };
  schState.comms.screen = 'compose';
  schState.comms.error = '';
  schRefreshComms();
}
function schCancelCompose() { schState.comms.screen = 'list'; schRefreshComms(); }
function schSetComposeAudience(v) {
  const c = schState.comms.compose;
  c.audience = v;
  c.campusId = null;
  c.classId = null;
  schRefreshComms();
}
function schRecipientCount(c) {
  if (c.audience === 'institution') return SCHOOL_DATA.students.length + SCHOOL_DATA.guardians.length + SCHOOL_DATA.teachers.length;
  if (c.audience === 'students') return SCHOOL_DATA.students.length;
  if (c.audience === 'guardians') return SCHOOL_DATA.guardians.length;
  if (c.audience === 'teachers') return SCHOOL_DATA.teachers.length;
  if (c.audience === 'campus' && c.campusId) return schCampusStudents(c.campusId).length + schCampusTeachers(c.campusId).length;
  if (c.audience === 'class' && c.classId) return schClassStudents(c.classId).length;
  return 0;
}
function schComposeScreen() {
  const c = schState.comms.compose;
  const err = schState.comms.error;
  if (c.preview) return schComposePreviewScreen();
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Compose Announcement')}</div></div>
    <div class="card-body">
      <div class="st-field"><label>${t('Audience')}</label><select id="sch-comp-audience" onchange="schSetComposeAudience(this.value)">
        <option value="institution" ${c.audience==='institution'?'selected':''}>${t('Entire Institution')}</option>
        <option value="students" ${c.audience==='students'?'selected':''}>${t('Students')}</option>
        <option value="guardians" ${c.audience==='guardians'?'selected':''}>${t('Guardians')}</option>
        <option value="teachers" ${c.audience==='teachers'?'selected':''}>${t('Teachers')}</option>
        <option value="campus" ${c.audience==='campus'?'selected':''}>${t('Specific Campus')}</option>
        <option value="class" ${c.audience==='class'?'selected':''}>${t('Specific Class')}</option>
      </select></div>
      ${c.audience === 'campus' ? `<div class="st-field"><label>${t('Campus')}</label><select id="sch-comp-campus">
        ${SCHOOL_DATA.campuses.map(cm => `<option value="${cm.id}" ${cm.id===c.campusId?'selected':''}>${schEsc(cm.name)}</option>`).join('')}
      </select></div>` : ''}
      ${c.audience === 'class' ? `<div class="st-field"><label>${t('Class')}</label><select id="sch-comp-class">
        ${SCHOOL_DATA.classes.map(cl => `<option value="${cl.id}" ${cl.id===c.classId?'selected':''}>${schEsc(cl.name)}</option>`).join('')}
      </select></div>` : ''}
      <div class="st-field"><label>${t('Subject')}</label><input id="sch-comp-subject" value="${schEsc(c.subject)}"></div>
      <div class="st-field"><label>${t('Message')}</label><textarea id="sch-comp-message" rows="5">${schEsc(c.message)}</textarea></div>
      <div style="margin-bottom:10px">
        <label style="display:flex;align-items:center;gap:8px;font-size:12.5px;color:var(--muted);cursor:pointer"><input type="checkbox" ${c.scheduleMode?'checked':''} onchange="schToggleScheduleMode(this.checked)"> ${t('Schedule for later instead of sending now')}</label>
        ${c.scheduleMode ? `<div style="display:flex;gap:10px;margin-top:8px">
          <input id="sch-comp-sched-date" type="date" value="${c.scheduledDate||''}" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
          <input id="sch-comp-sched-time" type="time" value="${c.scheduledTime||''}" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
        </div>` : ''}
      </div>
      <div style="display:flex;gap:10px;flex-wrap:wrap">
        <button class="st-btn ghost" onclick="schPreviewAnnouncement()">${t('Preview')}</button>
        <button class="st-btn ghost" onclick="schSaveAnnouncementDraft()">${t('Save as Draft')}</button>
        <button class="st-btn" onclick="${c.scheduleMode ? 'schScheduleAnnouncement()' : 'schSendAnnouncement()'}" ${schState.comms.sending?'disabled':''}>${schState.comms.sending ? `<span class="gd-spinner"></span>${t('Sending...')}` : (c.scheduleMode ? t('Schedule') : t('Send'))}</button>
        <button class="st-btn ghost" onclick="schCancelCompose()">${t('Cancel')}</button>
      </div>
      ${err ? `<div class="st-inline-msg err show" style="margin-top:12px">${err}</div>` : ''}
    </div></div>`;
}
function schReadComposeFields() {
  const c = schState.comms.compose;
  c.subject = (document.getElementById('sch-comp-subject').value || '').trim();
  c.message = (document.getElementById('sch-comp-message').value || '').trim();
  if (c.audience === 'campus') { const sel = document.getElementById('sch-comp-campus'); if (sel) c.campusId = sel.value; }
  if (c.audience === 'class') { const sel = document.getElementById('sch-comp-class'); if (sel) c.classId = sel.value; }
}
function schValidateCompose(c) {
  if (!c.subject) return t('Subject is required.');
  if (!c.message) return t('Message is required.');
  if (c.audience === 'campus' && !c.campusId) return t('Select a campus.');
  if (c.audience === 'class' && !c.classId) return t('Select a class.');
  return '';
}
function schPreviewAnnouncement() {
  schReadComposeFields();
  const c = schState.comms.compose;
  const err = schValidateCompose(c);
  schState.comms.error = err;
  if (err) { schRefreshComms(); return; }
  c.preview = true;
  schRefreshComms();
}
function schBackToComposeEdit() { schState.comms.compose.preview = false; schRefreshComms(); }
function schComposePreviewScreen() {
  const c = schState.comms.compose;
  const recipientCount = schRecipientCount(c);
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Preview Announcement')}</div></div>
    <div class="card-body">
      <div style="background:var(--surface2);border-radius:12px;padding:14px;margin-bottom:14px">
        <div style="font-weight:700;font-size:14px">${schEsc(c.subject)}</div>
        <div style="font-size:11.5px;color:var(--muted);margin:6px 0 10px">${t('To')}: ${schCommsAudienceLabel(c)} (${recipientCount} ${t('recipients')})</div>
        <div style="font-size:13px;line-height:1.5;color:var(--muted2);white-space:pre-wrap">${schEsc(c.message)}</div>
      </div>
      <div style="display:flex;gap:10px">
        <button class="st-btn" onclick="schSendAnnouncement()" ${schState.comms.sending?'disabled':''}>${schState.comms.sending ? `<span class="gd-spinner"></span>${t('Sending...')}` : t('Send Now')}</button>
        <button class="st-btn ghost" onclick="schBackToComposeEdit()">${t('Back to Edit')}</button>
      </div>
    </div></div>`;
}
function schSendAnnouncement() {
  schReadComposeFields();
  const c = schState.comms.compose;
  const err = schValidateCompose(c);
  schState.comms.error = err;
  if (err) { c.preview = false; schRefreshComms(); return; }

  schState.comms.sending = true;
  schRefreshComms();
  setTimeout(() => {
    const newAnnouncement = {
      id:'san' + Date.now(), subject:c.subject, message:c.message, audience:c.audience,
      campusId: c.audience === 'campus' ? c.campusId : null, classId: c.audience === 'class' ? c.classId : null,
      sentAt: new Date(2026, 2, 11, 12, 0).toISOString(), sentBy: SCHOOL_DATA.owner.name, status:'sent',
      readRate: Math.round(40 + schSeededRandom('san' + Date.now()) * 55),
    };
    SCHOOL_DATA.announcements.unshift(newAnnouncement);
    schLogAudit('Communication Sent', 'Announcement', newAnnouncement.subject, '', schCommsAudienceLabel(newAnnouncement));
    schState.comms.sending = false;
    schState.comms.screen = 'detail';
    schState.comms.announcementId = newAnnouncement.id;
    schRefreshComms();
    schShowToast(t('Announcement sent successfully.'));
  }, 700);
}

/* ── Advanced Communication: Drafts, Scheduling, Templates, Groups ── */
function schToggleScheduleMode(checked) {
  const c = schState.comms.compose;
  c.subject = (document.getElementById('sch-comp-subject').value || '');
  c.message = (document.getElementById('sch-comp-message').value || '');
  c.scheduleMode = checked;
  schRefreshComms();
}
function schSaveAnnouncementDraft() {
  const c = schState.comms.compose;
  schReadComposeFields();
  if (!c.subject && !c.message) { schState.comms.error = t('Enter a subject or message before saving a draft.'); schRefreshComms(); return; }
  schState.comms.error = '';
  const draft = { id:'san' + Date.now(), subject:c.subject, message:c.message, audience:c.audience, campusId: c.audience === 'campus' ? c.campusId : null, classId: c.audience === 'class' ? c.classId : null, sentAt: SCH_TODAY + 'T00:00:00', sentBy: SCHOOL_DATA.owner.name, status:'draft' };
  SCHOOL_DATA.announcements.unshift(draft);
  schState.comms.screen = 'list';
  schState.comms.tab = 'drafts';
  document.querySelectorAll('.gd-tab-schcom').forEach(el => el.classList.toggle('active', el.dataset.tab === 'drafts'));
  const el = document.getElementById('sch-comms-content');
  if (el) el.innerHTML = schCommsTabBody();
  schShowToast(t('Draft saved.'));
}
function schScheduleAnnouncement() {
  const c = schState.comms.compose;
  schReadComposeFields();
  const scheduledDate = document.getElementById('sch-comp-sched-date') ? document.getElementById('sch-comp-sched-date').value : '';
  const scheduledTime = document.getElementById('sch-comp-sched-time') ? document.getElementById('sch-comp-sched-time').value : '';
  let err = '';
  if (!c.subject) err = t('Subject is required.');
  else if (!c.message) err = t('Message is required.');
  else if (c.audience === 'campus' && !c.campusId) err = t('Select a campus.');
  else if (c.audience === 'class' && !c.classId) err = t('Select a class.');
  else if (!scheduledDate || !scheduledTime) err = t('Select a date and time to schedule for.');
  else if (`${scheduledDate}T${scheduledTime}` <= SCH_TODAY + 'T12:00') err = t('Scheduled time must be in the future.');
  schState.comms.error = err;
  if (err) { schRefreshComms(); return; }
  const scheduled = { id:'san' + Date.now(), subject:c.subject, message:c.message, audience:c.audience, campusId: c.audience === 'campus' ? c.campusId : null, classId: c.audience === 'class' ? c.classId : null, sentAt: `${scheduledDate}T${scheduledTime}:00`, sentBy: SCHOOL_DATA.owner.name, status:'scheduled' };
  SCHOOL_DATA.announcements.unshift(scheduled);
  schState.comms.screen = 'list';
  schState.comms.tab = 'drafts';
  document.querySelectorAll('.gd-tab-schcom').forEach(el => el.classList.toggle('active', el.dataset.tab === 'drafts'));
  const el = document.getElementById('sch-comms-content');
  if (el) el.innerHTML = schCommsTabBody();
  schShowToast(t('Announcement scheduled successfully.'));
}
function schCommsDraftsTab() {
  const drafts = SCHOOL_DATA.announcements.filter(a => a.status === 'draft').sort((a,b) => b.sentAt.localeCompare(a.sentAt));
  const scheduled = SCHOOL_DATA.announcements.filter(a => a.status === 'scheduled').sort((a,b) => a.sentAt.localeCompare(b.sentAt));
  return `
    <div class="card"><div class="card-header"><div class="card-title">${t('Scheduled Messages')}</div></div>
      <div class="card-body">${scheduled.length ? scheduled.map(a => `<div class="card" style="margin-bottom:10px;background:var(--surface2)"><div class="card-body">
        <div style="font-weight:600;font-size:13px">${schEsc(a.subject)}</div>
        <div style="font-size:11px;color:var(--muted);margin:4px 0 8px">${schCommsAudienceLabel(a)} · ${t('Scheduled for')} ${a.sentAt.slice(0,10)} ${a.sentAt.slice(11,16)}</div>
        <div style="display:flex;gap:8px">
          <button type="button" class="st-btn ghost sm" onclick="schSendScheduledNow('${a.id}')">${t('Send Now')}</button>
          <button type="button" class="st-btn ghost sm" style="color:var(--red)" onclick="schCancelScheduled('${a.id}')">${t('Cancel')}</button>
        </div>
      </div></div>`).join('') : `<div class="gd-empty-mini">${t('No scheduled messages.')}</div>`}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Drafts')}</div></div>
      <div class="card-body">${drafts.length ? drafts.map(a => `<div class="card" style="margin-bottom:10px;background:var(--surface2)"><div class="card-body">
        <div style="font-weight:600;font-size:13px">${schEsc(a.subject) || `<span style="color:var(--muted)">${t('(No subject)')}</span>`}</div>
        <div style="font-size:11px;color:var(--muted);margin:4px 0 8px">${schCommsAudienceLabel(a)}</div>
        <div style="display:flex;gap:8px">
          <button type="button" class="st-btn ghost sm" onclick="schResumeDraft('${a.id}')">${t('Resume Editing')}</button>
          <button type="button" class="st-btn ghost sm" style="color:var(--red)" onclick="schDeleteDraft('${a.id}')">${t('Delete')}</button>
        </div>
      </div></div>`).join('') : `<div class="gd-empty-mini">${t('No saved drafts.')}</div>`}</div></div>`;
}
function schSendScheduledNow(id) {
  const a = SCHOOL_DATA.announcements.find(x => x.id === id);
  if (!a) return;
  a.status = 'sent';
  a.sentAt = new Date(2026, 2, 11, 12, 0).toISOString();
  a.readRate = Math.round(40 + schSeededRandom(id + 'now') * 55);
  const el = document.getElementById('sch-comms-content'); if (el) el.innerHTML = schCommsDraftsTab();
  schShowToast(t('Announcement sent now.'));
}
function schCancelScheduled(id) {
  SCHOOL_DATA.announcements = SCHOOL_DATA.announcements.filter(a => a.id !== id);
  const el = document.getElementById('sch-comms-content'); if (el) el.innerHTML = schCommsDraftsTab();
  schShowToast(t('Scheduled message cancelled.'));
}
function schResumeDraft(id) {
  const a = SCHOOL_DATA.announcements.find(x => x.id === id);
  if (!a) return;
  SCHOOL_DATA.announcements = SCHOOL_DATA.announcements.filter(x => x.id !== id);
  schState.comms.compose = { subject:a.subject, message:a.message, audience:a.audience, campusId:a.campusId, classId:a.classId, preview:false };
  schState.comms.screen = 'compose';
  schState.comms.tab = 'main';
  schState.comms.error = '';
  document.querySelectorAll('.gd-tab-schcom').forEach(el => el.classList.toggle('active', el.dataset.tab === 'main'));
  const el = document.getElementById('sch-comms-content');
  if (el) el.innerHTML = schCommsTabBody();
}
function schDeleteDraft(id) {
  SCHOOL_DATA.announcements = SCHOOL_DATA.announcements.filter(a => a.id !== id);
  const el = document.getElementById('sch-comms-content'); if (el) el.innerHTML = schCommsDraftsTab();
  schShowToast(t('Draft deleted.'));
}

/* Templates & Groups */
SCHOOL_DATA.messageTemplates = [
  { id:'stpl1', name:'Report Card Reminder', subject:'Term Report Cards Available', message:'Dear guardians, term report cards are now available. Please review academic progress with the homeroom teacher.' },
  { id:'stpl2', name:'Board Meeting Notice', subject:'Upcoming Board Meeting', message:'A board meeting has been scheduled. Please review the agenda beforehand.' },
];
SCHOOL_DATA.audienceGroups = [
  { id:'sgrp1', name:'North & East Campus Teachers', memberType:'teacher', memberIds:['st6','st7','st8'] },
];
function schCommsTemplatesTab() {
  return `
    <div class="card"><div class="card-header"><div class="card-title">${t('Message Templates')}</div></div>
      <div class="card-body">
        ${SCHOOL_DATA.messageTemplates.map(tpl => `<div class="card" style="margin-bottom:10px;background:var(--surface2)"><div class="card-body">
          <div style="font-weight:600;font-size:13px">${schEsc(tpl.name)}</div>
          <div style="font-size:11.5px;color:var(--muted);margin-top:4px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${schEsc(tpl.subject)}</div>
          <div style="display:flex;gap:8px;margin-top:8px">
            <button type="button" class="st-btn ghost sm" onclick="schUseTemplate('${tpl.id}')">${t('Use')}</button>
            <button type="button" class="st-btn ghost sm" style="color:var(--red)" onclick="schDeleteTemplate('${tpl.id}')">${t('Delete')}</button>
          </div>
        </div></div>`).join('') || `<div class="gd-empty-mini">${t('No templates yet.')}</div>`}
        <button class="st-btn ghost sm" onclick="schOpenTemplateForm()">+ ${t('New Template')}</button>
        <div id="sch-tpl-form-area"></div>
      </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Audience Groups')}</div></div>
      <div class="card-body">
        ${SCHOOL_DATA.audienceGroups.map(g => `<div class="info-row"><span>${schEsc(g.name)}<div style="font-size:11px;color:var(--muted)">${g.memberIds.length} ${t('member(s)')}</div></span><button type="button" class="st-btn ghost sm" onclick="schDeleteAudienceGroup('${g.id}')">${t('Delete')}</button></div>`).join('') || `<div class="gd-empty-mini">${t('No saved audience groups yet.')}</div>`}
      </div></div>`;
}
function schUseTemplate(id) {
  const tpl = SCHOOL_DATA.messageTemplates.find(x => x.id === id);
  if (!tpl) return;
  schState.comms.compose = { subject:tpl.subject, message:tpl.message, audience:'institution', campusId:null, classId:null, preview:false };
  schState.comms.screen = 'compose';
  schState.comms.tab = 'main';
  document.querySelectorAll('.gd-tab-schcom').forEach(el => el.classList.toggle('active', el.dataset.tab === 'main'));
  const el = document.getElementById('sch-comms-content');
  if (el) el.innerHTML = schCommsTabBody();
  schShowToast(t('Template loaded into Compose.'));
}
function schDeleteTemplate(id) {
  SCHOOL_DATA.messageTemplates = SCHOOL_DATA.messageTemplates.filter(x => x.id !== id);
  const el = document.getElementById('sch-comms-content'); if (el) el.innerHTML = schCommsTemplatesTab();
  schShowToast(t('Template deleted.'));
}
function schOpenTemplateForm() {
  const el = document.getElementById('sch-tpl-form-area');
  if (!el) return;
  el.innerHTML = `<div class="card" style="margin-top:10px;background:var(--surface2)"><div class="card-body">
    <div class="st-field"><label>${t('Template Name')}</label><input id="sch-tpl-name"></div>
    <div class="st-field"><label>${t('Subject')}</label><input id="sch-tpl-subject"></div>
    <div class="st-field"><label>${t('Message')}</label><textarea id="sch-tpl-message" rows="4"></textarea></div>
    <button class="st-btn sm" onclick="schSaveTemplate()">${t('Create Template')}</button>
  </div></div>`;
}
function schSaveTemplate() {
  const name = (document.getElementById('sch-tpl-name').value || '').trim();
  const subject = (document.getElementById('sch-tpl-subject').value || '').trim();
  const message = (document.getElementById('sch-tpl-message').value || '').trim();
  if (!name || !subject || !message) { schShowToast(t('All template fields are required.')); return; }
  SCHOOL_DATA.messageTemplates.push({ id:'stpl' + Date.now(), name, subject, message });
  const el = document.getElementById('sch-comms-content'); if (el) el.innerHTML = schCommsTemplatesTab();
  schShowToast(t('Template created.'));
}
function schDeleteAudienceGroup(id) {
  SCHOOL_DATA.audienceGroups = SCHOOL_DATA.audienceGroups.filter(g => g.id !== id);
  const el = document.getElementById('sch-comms-content'); if (el) el.innerHTML = schCommsTemplatesTab();
  schShowToast(t('Audience group deleted.'));
}

/* ══════════════════════════════════════════════════════
   BASIC REPORTS (section 7)
══════════════════════════════════════════════════════ */
const SCH_REPORT_TYPES = [
  { id:'enrollment', label:'Enrollment Report' },
  { id:'attendance', label:'Attendance Report' },
  { id:'academic', label:'Academic Report' },
  { id:'admissions', label:'Admissions Report' },
  { id:'payment', label:'Payment Report' },
  { id:'communication', label:'Communication Report' },
  { id:'administrative', label:'Administrative Report' },
];
function schReportTypeMeta(id) { return SCH_REPORT_TYPES.find(x => x.id === id) || SCH_REPORT_TYPES[0]; }
function schReportsView() {
  return `<div id="sch-reports-content">${schReportsBody()}</div>`;
}
function schReportsBody() {
  const r = schState.reports;
  return r.screen === 'preview' ? schReportPreviewScreen() : schReportFormScreen();
}
function schRefreshReports() { const el = document.getElementById('sch-reports-content'); if (el) el.innerHTML = schReportsBody(); }
function schReportFormScreen() {
  const r = schState.reports;
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Basic Reports')}</div></div>
    <div class="card-body">
      <div class="st-field"><label>${t('Report Type')}</label><select id="sch-rep-type" onchange="schSetReportType(this.value)">
        ${SCH_REPORT_TYPES.map(x => `<option value="${x.id}" ${x.id===r.type?'selected':''}>${t(x.label)}</option>`).join('')}
      </select></div>
      <div class="st-field"><label>${t('Campus')}</label><select id="sch-rep-campus">
        <option value="all" ${r.campus==='all'?'selected':''}>${t('All Campuses')}</option>
        ${SCHOOL_DATA.campuses.map(c => `<option value="${c.id}" ${c.id===r.campus?'selected':''}>${schEsc(c.name)}</option>`).join('')}
      </select></div>
      <div class="st-field"><label>${t('Period')}</label><select id="sch-rep-period">
        <option value="all" ${r.period==='all'?'selected':''}>${t('Full Term')}</option>
        <option value="month" ${r.period==='month'?'selected':''}>${t('Current Month')}</option>
      </select></div>
      <button class="st-btn" onclick="schGenerateReport()">${t('Generate Report')}</button>
    </div></div>`;
}
function schSetReportType(v) { schState.reports.type = v; }
function schGenerateReport() {
  const r = schState.reports;
  r.campus = document.getElementById('sch-rep-campus').value;
  r.period = document.getElementById('sch-rep-period').value;
  r.screen = 'preview';
  r.generatedAt = SCH_TODAY;
  schRefreshReports();
}
function schBackToReportForm() { schState.reports.screen = 'form'; schRefreshReports(); }
function schReportScopedData(r) {
  let students = r.campus === 'all' ? SCHOOL_DATA.students : SCHOOL_DATA.students.filter(s => s.campusId === r.campus);
  let payments = r.campus === 'all' ? SCHOOL_DATA.payments : SCHOOL_DATA.payments.filter(p => p.campusId === r.campus);
  let admissions = r.campus === 'all' ? SCHOOL_DATA.admissions : SCHOOL_DATA.admissions.filter(a => a.campusId === r.campus);
  const days = r.period === 'month' ? SCH_ATTENDANCE_DAYS.slice(-8) : SCH_ATTENDANCE_DAYS;
  return { students, payments, admissions, days };
}
function schReportPreviewScreen() {
  const r = schState.reports;
  const meta = schReportTypeMeta(r.type);
  const d = schReportScopedData(r);
  let body = '';
  if (r.type === 'enrollment') body = schReportEnrollmentBody(d);
  else if (r.type === 'attendance') body = schReportAttendanceBody(d);
  else if (r.type === 'academic') body = schReportAcademicBody(d);
  else if (r.type === 'admissions') body = schReportAdmissionsBody(d);
  else if (r.type === 'payment') body = schReportPaymentBody(d);
  else if (r.type === 'communication') body = schReportCommunicationBody(d);
  else body = schReportAdministrativeBody(d);
  const campusLabel = r.campus === 'all' ? t('All Campuses') : schEsc(schGetCampus(r.campus).name);
  return `<div class="card">
    <div class="card-header">
      <div style="display:flex;align-items:center;gap:10px"><button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="schBackToReportForm()">${t('← Back')}</button><div class="card-title">${t(meta.label)}</div></div>
      <button type="button" class="st-btn ghost sm" onclick="window.print()">${aIcon('printer')} ${t('Print / Export')}</button>
    </div>
    <div class="card-body">
      <div style="font-size:11.5px;color:var(--muted);margin-bottom:14px">${t('Generated')} ${r.generatedAt} · ${campusLabel} · ${r.period==='month'?t('Current Month'):t('Full Term')}</div>
      ${body}
    </div></div>`;
}
function schReportEnrollmentBody(d) {
  const byStatus = {};
  d.students.forEach(s => { byStatus[s.status] = (byStatus[s.status]||0)+1; });
  return `<div class="info-row"><span>${t('Total Enrollment')}</span><span>${d.students.length}</span></div>
    ${Object.keys(byStatus).map(st => `<div class="info-row"><span>${t(st.charAt(0).toUpperCase()+st.slice(1))}</span><span>${byStatus[st]}</span></div>`).join('')}
    <div style="margin-top:14px;font-size:12.5px;font-weight:600;margin-bottom:8px">${t('By Campus')}</div>
    ${SCHOOL_DATA.campuses.map(c => `<div class="info-row"><span>${schEsc(c.name)}</span><span>${d.students.filter(s=>s.campusId===c.id).length}</span></div>`).join('')}`;
}
function schReportAttendanceBody(d) {
  const agg = schAggregateAttendance(d.students.map(s => s.id), d.days);
  return `<div class="info-row"><span>${t('Overall Attendance Rate')}</span><span>${agg.rate!==null?agg.rate+'%':'—'}</span></div>
    <div class="info-row"><span>${t('Present')}</span><span>${agg.present}</span></div>
    <div class="info-row"><span>${t('Absent')}</span><span>${agg.absent}</span></div>
    <div class="info-row"><span>${t('Late')}</span><span>${agg.late}</span></div>
    <div class="info-row"><span>${t('Excused')}</span><span>${agg.excused}</span></div>`;
}
function schReportAcademicBody(d) {
  const avg = schAvg(d.students.map(s => s.avgGrade));
  const sorted = d.students.slice().sort((a,b) => b.avgGrade - a.avgGrade);
  return `<div class="info-row"><span>${t('Overall Average')}</span><span>${avg!==null?avg+'/20':'—'}</span></div>
    <div class="info-row"><span>${t('Highest Performer')}</span><span>${sorted[0] ? schEsc(schStudentFullName(sorted[0])) + ' (' + sorted[0].avgGrade + '/20)' : '—'}</span></div>
    <div class="info-row"><span>${t('Students Needing Attention')} (<12/20)</span><span>${d.students.filter(s=>s.avgGrade<12).length}</span></div>`;
}
function schReportAdmissionsBody(d) {
  const byStatus = {};
  d.admissions.forEach(a => { byStatus[a.status] = (byStatus[a.status]||0)+1; });
  return `<div class="info-row"><span>${t('Total Applications')}</span><span>${d.admissions.length}</span></div>
    ${Object.keys(byStatus).map(st => `<div class="info-row"><span>${t(st.charAt(0).toUpperCase()+st.slice(1).replace('-',' '))}</span><span>${byStatus[st]}</span></div>`).join('')}`;
}
function schReportPaymentBody(d) {
  const collected = d.payments.filter(p=>p.status==='paid').reduce((s,p)=>s+p.amount,0);
  const outstanding = d.payments.filter(p=>p.status!=='paid').reduce((s,p)=>s+p.amount,0);
  const overdue = d.payments.filter(p=>p.status==='overdue').reduce((s,p)=>s+p.amount,0);
  return `<div class="info-row"><span>${t('Collected')}</span><span>${schCurrency(collected)}</span></div>
    <div class="info-row"><span>${t('Outstanding')}</span><span>${schCurrency(outstanding)}</span></div>
    <div class="info-row"><span>${t('Overdue')}</span><span>${schCurrency(overdue)}</span></div>`;
}
function schReportCommunicationBody(d) {
  const sent = SCHOOL_DATA.announcements.filter(a => a.status === 'sent');
  const avgRead = sent.length ? Math.round(schAvg(sent.map(a=>a.readRate||0))) : null;
  return `<div class="info-row"><span>${t('Total Sent')}</span><span>${sent.length}</span></div>
    <div class="info-row"><span>${t('Average Read Rate')}</span><span>${avgRead!==null?avgRead+'%':'—'}</span></div>`;
}
function schReportAdministrativeBody(d) {
  return `<div class="info-row"><span>${t('Total Campuses')}</span><span>${SCHOOL_DATA.campuses.length}</span></div>
    <div class="info-row"><span>${t('Total Classes')}</span><span>${SCHOOL_DATA.classes.length}</span></div>
    <div class="info-row"><span>${t('Total Teachers')}</span><span>${SCHOOL_DATA.teachers.length}</span></div>
    <div class="info-row"><span>${t('Open Reclamations')}</span><span>${SCHOOL_DATA.reclamations.filter(r=>r.status!=='resolved'&&r.status!=='archived').length}</span></div>
    <div class="info-row"><span>${t('Audit Log Entries')}</span><span>${SCHOOL_DATA.auditLog.length}</span></div>`;
}

/* ══════════════════════════════════════════════════════
   STUDENT ENROLLMENT (section 8)
   Submitting genuinely updates: enrollment records, the student's
   class/campus relationship, enrollment totals, and dashboard metrics
   (all read live from SCHOOL_DATA.students / .enrollments elsewhere).
══════════════════════════════════════════════════════ */
const SCH_ENROLLMENT_STATUSES = ['pending', 'active', 'completed', 'cancelled'];
function schEnrollmentView() {
  return `<div id="sch-enrollment-content">${schEnrollmentBody()}</div>`;
}
function schEnrollmentBody() {
  const s = schState.enrollment;
  if (s.screen === 'form') return schEnrollmentFormScreen();
  return schEnrollmentListScreen();
}
function schRefreshEnrollment() { const el = document.getElementById('sch-enrollment-content'); if (el) el.innerHTML = schEnrollmentBody(); }
function schFilteredEnrollments() {
  const s = schState.enrollment;
  let list = SCHOOL_DATA.enrollments.slice();
  if (s.filterCampus !== 'all') list = list.filter(e => e.campusId === s.filterCampus);
  if (s.filterStatus !== 'all') list = list.filter(e => e.status === s.filterStatus);
  const q = s.search.trim().toLowerCase();
  if (q) list = list.filter(e => { const st = schGetStudent(e.studentId); return st && schStudentFullName(st).toLowerCase().includes(q); });
  return list.sort((a, b) => b.enrollmentDate.localeCompare(a.enrollmentDate));
}
function schEnrollmentListScreen() {
  const s = schState.enrollment;
  const total = SCHOOL_DATA.enrollments.length;
  const active = SCHOOL_DATA.enrollments.filter(e => e.status === 'active').length;
  const pending = SCHOOL_DATA.enrollments.filter(e => e.status === 'pending').length;
  return `<div class="gd-stat-row">
      <div class="stat-card"><div class="stat-label">${t('Total Enrollment')}</div><div class="stat-val">${total}</div><div class="stat-icon blue">${aIcon('graduation-cap')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Active')}</div><div class="stat-val">${active}</div><div class="stat-icon green">${aIcon('check-circle')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Pending')}</div><div class="stat-val">${pending}</div><div class="stat-icon yellow">${aIcon('clock')}</div></div>
    </div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Student Enrollment')}</div><button class="st-btn sm" onclick="schOpenEnrollmentForm()">+ ${t('Start New Enrollment')}</button></div>
      <div class="card-body">
        <input class="gd-comm-search-input" type="text" placeholder="${t('Search by student name...')}" value="${schEsc(s.search)}" oninput="schSetEnrollmentSearch(this.value)">
        <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:10px">
          <select onchange="schSetEnrollmentCampusFilter(this.value)" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
            <option value="all" ${s.filterCampus==='all'?'selected':''}>${t('All Campuses')}</option>
            ${SCHOOL_DATA.campuses.map(c => `<option value="${c.id}" ${c.id===s.filterCampus?'selected':''}>${schEsc(c.name)}</option>`).join('')}
          </select>
          <select onchange="schSetEnrollmentStatusFilter(this.value)" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
            <option value="all" ${s.filterStatus==='all'?'selected':''}>${t('All Statuses')}</option>
            ${SCH_ENROLLMENT_STATUSES.map(st => `<option value="${st}" ${st===s.filterStatus?'selected':''}>${t(st.charAt(0).toUpperCase()+st.slice(1))}</option>`).join('')}
          </select>
        </div>
        <div id="sch-enrollment-results" style="margin-top:10px">${schEnrollmentResultsBlock()}</div>
      </div></div>`;
}
function schEnrollmentResultsBlock() {
  const list = schFilteredEnrollments();
  if (!list.length) return `<div class="gd-empty-mini">${t('No enrollment records match your search or filters.')}</div>`;
  return list.map(e => { const st = schGetStudent(e.studentId); const cls = schGetClass(e.classId); const campus = schGetCampus(e.campusId);
    const pillClass = e.status==='active'?'paid':e.status==='completed'?'resolved':e.status==='cancelled'?'overdue':'due';
    return `<div class="info-row"><span>${st ? schEsc(schStudentFullName(st)) : t('Unknown student')}<div style="font-size:11px;color:var(--muted)">${cls?schEsc(cls.name):''} · ${campus?schEsc(campus.name):''} · ${e.enrollmentDate}</div></span><span class="status-pill ${pillClass}">${t(e.status.charAt(0).toUpperCase()+e.status.slice(1))}</span></div>`;
  }).join('');
}
function schSetEnrollmentSearch(v) { schState.enrollment.search = v; const el = document.getElementById('sch-enrollment-results'); if (el) el.innerHTML = schEnrollmentResultsBlock(); }
function schSetEnrollmentCampusFilter(v) { schState.enrollment.filterCampus = v; const el = document.getElementById('sch-enrollment-results'); if (el) el.innerHTML = schEnrollmentResultsBlock(); }
function schSetEnrollmentStatusFilter(v) { schState.enrollment.filterStatus = v; const el = document.getElementById('sch-enrollment-results'); if (el) el.innerHTML = schEnrollmentResultsBlock(); }

/* ── Start New Enrollment ── */
function schOpenEnrollmentForm() {
  schState.enrollment.form = { studentId:null, studentSearch:'', classId:'', campusId:'camp1', academicYear:SCHOOL_DATA.institution.academicYear, enrollmentDate:SCH_TODAY, status:'pending' };
  schState.enrollment.screen = 'form';
  schState.enrollment.error = '';
  schRefreshEnrollment();
}
function schCancelEnrollmentForm() { schState.enrollment.screen = 'list'; schState.enrollment.form = null; schState.enrollment.error = ''; schRefreshEnrollment(); }
function schSetEnrollmentFormStudentSearch(v) {
  schState.enrollment.form.studentSearch = v;
  const el = document.getElementById('sch-enr-student-results');
  if (el) el.innerHTML = schEnrollmentFormStudentResultsBlock();
}
function schEnrollmentFormStudentResultsBlock() {
  const q = schState.enrollment.form.studentSearch.trim().toLowerCase();
  if (!q) return '';
  const results = SCHOOL_DATA.students.filter(s => schStudentFullName(s).toLowerCase().includes(q) || s.studentId.toLowerCase().includes(q));
  if (!results.length) return `<div class="gd-empty-mini" style="text-align:left;padding:8px 0 0">${t('No students match your search.')}</div>`;
  return results.map(s => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="schSetEnrollmentFormStudent('${s.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();schSetEnrollmentFormStudent('${s.id}')}">
    <span>${schEsc(schStudentFullName(s))}<div style="font-size:11px;color:var(--muted)">${schEsc(s.studentId)}</div></span><span class="card-action">${t('Select')}</span>
  </div>`).join('');
}
function schSetEnrollmentFormStudent(id) {
  const s = schGetStudent(id);
  schState.enrollment.form.studentId = id;
  schState.enrollment.form.campusId = s.campusId;
  const el = document.getElementById('sch-enrollment-content');
  if (el) el.innerHTML = schEnrollmentBody();
}
function schEnrollmentFormScreen() {
  const f = schState.enrollment.form;
  const err = schState.enrollment.error;
  const eligibleClasses = SCHOOL_DATA.classes.filter(c => c.campusId === f.campusId);
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Start New Enrollment')}</div></div>
    <div class="card-body">
      <div class="st-field"><label>${t('Student')}</label>
        ${f.studentId ? (() => { const st = schGetStudent(f.studentId); return `<div class="info-row"><span>${schEsc(schStudentFullName(st))} (${schEsc(st.studentId)})</span><span class="card-action" onclick="schClearEnrollmentFormStudent()">${t('Change')}</span></div>`; })()
          : `<input class="gd-comm-search-input" type="text" placeholder="${t('Search by name or student ID...')}" value="${schEsc(f.studentSearch)}" oninput="schSetEnrollmentFormStudentSearch(this.value)"><div id="sch-enr-student-results">${schEnrollmentFormStudentResultsBlock()}</div>`}
      </div>
      <div class="st-field"><label>${t('Campus')}</label><select id="sch-enr-campus" onchange="schSetEnrollmentFormCampus(this.value)">
        ${SCHOOL_DATA.campuses.map(c => `<option value="${c.id}" ${c.id===f.campusId?'selected':''}>${schEsc(c.name)}</option>`).join('')}
      </select></div>
      <div class="st-field"><label>${t('Class')}</label><select id="sch-enr-class">
        ${eligibleClasses.map(c => `<option value="${c.id}" ${c.id===f.classId?'selected':''}>${schEsc(c.name)}</option>`).join('')}
      </select></div>
      <div class="st-field"><label>${t('Academic Year')}</label><select id="sch-enr-year">
        <option value="2025-2026" ${f.academicYear==='2025-2026'?'selected':''}>2025-2026</option>
        <option value="2026-2027" ${f.academicYear==='2026-2027'?'selected':''}>2026-2027</option>
      </select></div>
      <div class="st-field"><label>${t('Enrollment Date')}</label><input id="sch-enr-date" type="date" value="${f.enrollmentDate}"></div>
      <div class="st-field"><label>${t('Enrollment Status')}</label><select id="sch-enr-status">
        ${SCH_ENROLLMENT_STATUSES.map(st => `<option value="${st}" ${st===f.status?'selected':''}>${t(st.charAt(0).toUpperCase()+st.slice(1))}</option>`).join('')}
      </select></div>
      <div style="display:flex;gap:10px">
        <button class="st-btn" onclick="schSaveEnrollment()" ${schState.enrollment.saving?'disabled':''}>${schState.enrollment.saving ? `<span class="gd-spinner"></span>${t('Saving...')}` : t('Submit Enrollment')}</button>
        <button class="st-btn ghost" onclick="schCancelEnrollmentForm()" ${schState.enrollment.saving?'disabled':''}>${t('Cancel')}</button>
      </div>
      ${err ? `<div class="st-inline-msg err show" style="margin-top:12px">${err}</div>` : ''}
    </div></div>`;
}
function schClearEnrollmentFormStudent() {
  schState.enrollment.form.studentId = null;
  schState.enrollment.form.studentSearch = '';
  const el = document.getElementById('sch-enrollment-content');
  if (el) el.innerHTML = schEnrollmentBody();
}
function schSetEnrollmentFormCampus(v) {
  const f = schState.enrollment.form;
  f.campusId = v;
  const eligibleClasses = SCHOOL_DATA.classes.filter(c => c.campusId === v);
  f.classId = eligibleClasses[0] ? eligibleClasses[0].id : '';
  const el = document.getElementById('sch-enrollment-content');
  if (el) el.innerHTML = schEnrollmentBody();
}
function schSaveEnrollment() {
  const f = schState.enrollment.form;
  const classId = document.getElementById('sch-enr-class').value;
  const academicYear = document.getElementById('sch-enr-year').value;
  const enrollmentDate = document.getElementById('sch-enr-date').value;
  const status = document.getElementById('sch-enr-status').value;
  Object.assign(f, { classId, academicYear, enrollmentDate, status });

  let err = '';
  if (!f.studentId) err = t('Select a student to enroll.');
  else if (!classId) err = t('Select a class.');
  else if (!enrollmentDate) err = t('Select an enrollment date.');

  schState.enrollment.error = err;
  if (err) { schRefreshEnrollment(); return; }

  schState.enrollment.saving = true;
  schRefreshEnrollment();
  setTimeout(() => {
    const student = schGetStudent(f.studentId);
    const oldClassId = student.classId;
    const oldCampusId = student.campusId;
    // Update the student's real class/campus relationship
    student.classId = f.classId;
    student.campusId = f.campusId;
    if (status === 'active') student.status = 'active';

    const newEnrollment = { id:'senr' + Date.now(), studentId:f.studentId, classId:f.classId, campusId:f.campusId, academicYear, enrollmentDate, status };
    SCHOOL_DATA.enrollments.push(newEnrollment);
    schLogAudit('Student Enrollment', 'Enrollment', schStudentFullName(student), schGetClass(oldClassId) ? schGetClass(oldClassId).name : '', schGetClass(f.classId).name);

    schState.enrollment.saving = false;
    schState.enrollment.screen = 'list';
    schState.enrollment.form = null;
    schRefreshEnrollment();
    schShowToast(t('Enrollment submitted successfully.'));
  }, 700);
}

/* ══════════════════════════════════════════════════════
   BASIC DATA MANAGEMENT (section 9)
   Central hub across all major institutional datasets. Students,
   Teachers, Guardians, Classes get full search/filter/sort/detail/edit
   (edits genuinely persist to SCHOOL_DATA). Admissions, Payments,
   Events, Communications are browsable here with search/filter/sort,
   deferring full CRUD to their own dedicated modules.
══════════════════════════════════════════════════════ */
const SCH_DM_TABS = [ ['students','Students'], ['teachers','Teachers'], ['guardians','Guardians'], ['classes','Classes'], ['admissions','Admissions'], ['payments','Payments'], ['events','Events'], ['communications','Communications'] ];
function schDataManagementView() {
  const dm = schState.dataManagement;
  return `<div class="st-tabs">${SCH_DM_TABS.map(([id,label]) => `<div class="st-tab gd-tab-schdm${dm.tab===id?' active':''}" data-tab="${id}" onclick="schSetDmTab('${id}')">${t(label)}</div>`).join('')}</div>
    <div id="sch-dm-content">${schDmBody()}</div>`;
}
function schSetDmTab(tabId) {
  const dm = schState.dataManagement;
  dm.tab = tabId; dm.search = ''; dm.filterCampus = 'all'; dm.detailId = null; dm.editing = false; dm.error = '';
  document.querySelectorAll('.gd-tab-schdm').forEach(el => el.classList.toggle('active', el.dataset.tab === tabId));
  const el = document.getElementById('sch-dm-content');
  if (el) el.innerHTML = schDmBody();
}
function schRefreshDm() { const el = document.getElementById('sch-dm-content'); if (el) el.innerHTML = schDmBody(); }
function schDmBody() {
  const dm = schState.dataManagement;
  if (dm.detailId) return schDmDetailScreen();
  if (dm.tab === 'students') return schDmStudentsList();
  if (dm.tab === 'teachers') return schDmTeachersList();
  if (dm.tab === 'guardians') return schDmGuardiansList();
  if (dm.tab === 'classes') return schDmClassesList();
  if (dm.tab === 'admissions') return schDmAdmissionsList();
  if (dm.tab === 'payments') return schDmPaymentsList();
  if (dm.tab === 'events') return schDmEventsList();
  return schDmCommunicationsList();
}
function schDmFilterBar(showCampus) {
  const dm = schState.dataManagement;
  return `<input class="gd-comm-search-input" type="text" placeholder="${t('Search...')}" value="${schEsc(dm.search)}" oninput="schSetDmSearch(this.value)">
    ${showCampus ? `<select onchange="schSetDmCampusFilter(this.value)" style="margin-top:10px;background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
      <option value="all" ${dm.filterCampus==='all'?'selected':''}>${t('All Campuses')}</option>
      ${SCHOOL_DATA.campuses.map(c => `<option value="${c.id}" ${c.id===dm.filterCampus?'selected':''}>${schEsc(c.name)}</option>`).join('')}
    </select>` : ''}`;
}
function schSetDmSearch(v) { schState.dataManagement.search = v; const el = document.getElementById('sch-dm-results'); if (el) el.innerHTML = schDmResultsBlock(); }
function schSetDmCampusFilter(v) { schState.dataManagement.filterCampus = v; const el = document.getElementById('sch-dm-results'); if (el) el.innerHTML = schDmResultsBlock(); }
function schSetDmSort(v) { schState.dataManagement.sort = v; const el = document.getElementById('sch-dm-results'); if (el) el.innerHTML = schDmResultsBlock(); }
function schDmResultsBlock() {
  const dm = schState.dataManagement;
  if (dm.tab === 'students') return schDmStudentsResults();
  if (dm.tab === 'teachers') return schDmTeachersResults();
  if (dm.tab === 'guardians') return schDmGuardiansResults();
  if (dm.tab === 'classes') return schDmClassesResults();
  if (dm.tab === 'admissions') return schDmAdmissionsResults();
  if (dm.tab === 'payments') return schDmPaymentsResults();
  if (dm.tab === 'events') return schDmEventsResults();
  return schDmCommunicationsResults();
}

/* ── Students sub-tab ── */
function schDmStudentsList() {
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Students')}</div><span style="font-size:12px;color:var(--muted)">${SCHOOL_DATA.students.length} ${t('total')}</span></div>
    <div class="card-body">${schDmFilterBar(true)}
      <select onchange="schSetDmSort(this.value)" style="margin-top:10px;background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
        <option value="name">${t('Sort: Name')}</option>
        <option value="grade">${t('Sort: Grade')}</option>
        <option value="attendance">${t('Sort: Attendance')}</option>
      </select>
      <div id="sch-dm-results" style="margin-top:10px">${schDmStudentsResults()}</div>
    </div></div>`;
}
function schDmStudentsResults() {
  const dm = schState.dataManagement;
  let list = SCHOOL_DATA.students.slice();
  if (dm.filterCampus !== 'all') list = list.filter(s => s.campusId === dm.filterCampus);
  const q = dm.search.trim().toLowerCase();
  if (q) list = list.filter(s => schStudentFullName(s).toLowerCase().includes(q) || s.studentId.toLowerCase().includes(q));
  if (dm.sort === 'grade') list.sort((a,b) => b.avgGrade - a.avgGrade);
  else if (dm.sort === 'attendance') list.sort((a,b) => b.attendanceRate - a.attendanceRate);
  else list.sort((a,b) => schStudentFullName(a).localeCompare(schStudentFullName(b)));
  if (!list.length) return `<div class="gd-empty-mini">${t('No students match your search or filters.')}</div>`;
  return list.map(s => { const cls = schGetClass(s.classId); return `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="schOpenDmDetail('${s.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();schOpenDmDetail('${s.id}')}">
    <span>${schEsc(schStudentFullName(s))}<div style="font-size:11px;color:var(--muted)">${cls?schEsc(cls.name):''} · ${schEsc(s.studentId)}</div></span><span style="color:var(--muted);font-size:12px">${s.avgGrade}/20 · ${s.attendanceRate}%</span>
  </div>`; }).join('');
}
function schOpenDmDetail(id) { schState.dataManagement.detailId = id; schState.dataManagement.editing = false; schRefreshDm(); }
function schBackFromDmDetail() { schState.dataManagement.detailId = null; schState.dataManagement.editing = false; schRefreshDm(); }

/* ── Teachers sub-tab ── */
function schDmTeachersList() {
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Teachers')}</div><span style="font-size:12px;color:var(--muted)">${SCHOOL_DATA.teachers.length} ${t('total')}</span></div>
    <div class="card-body">${schDmFilterBar(true)}
      <div id="sch-dm-results" style="margin-top:10px">${schDmTeachersResults()}</div>
    </div></div>`;
}
function schDmTeachersResults() {
  const dm = schState.dataManagement;
  let list = SCHOOL_DATA.teachers.slice();
  if (dm.filterCampus !== 'all') list = list.filter(te => te.campusId === dm.filterCampus);
  const q = dm.search.trim().toLowerCase();
  if (q) list = list.filter(te => te.name.toLowerCase().includes(q) || te.teacherId.toLowerCase().includes(q));
  list.sort((a,b) => a.name.localeCompare(b.name));
  if (!list.length) return `<div class="gd-empty-mini">${t('No teachers match your search or filters.')}</div>`;
  return list.map(te => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="schOpenDmDetail('${te.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();schOpenDmDetail('${te.id}')}">
    <span>${schEsc(te.name)}<div style="font-size:11px;color:var(--muted)">${schEsc(te.subjects.join(', '))} · ${schEsc(schGetCampus(te.campusId).name)}</div></span><span class="status-pill ${te.status==='active'?'paid':'overdue'}">${t(te.status.charAt(0).toUpperCase()+te.status.slice(1))}</span>
  </div>`).join('');
}

/* ── Guardians sub-tab ── */
function schDmGuardiansList() {
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Guardians')}</div><span style="font-size:12px;color:var(--muted)">${SCHOOL_DATA.guardians.length} ${t('total')}</span></div>
    <div class="card-body">${schDmFilterBar(false)}
      <div id="sch-dm-results" style="margin-top:10px">${schDmGuardiansResults()}</div>
    </div></div>`;
}
function schDmGuardiansResults() {
  const dm = schState.dataManagement;
  let list = SCHOOL_DATA.guardians.slice();
  const q = dm.search.trim().toLowerCase();
  if (q) list = list.filter(g => g.name.toLowerCase().includes(q) || g.email.toLowerCase().includes(q));
  list.sort((a,b) => a.name.localeCompare(b.name));
  if (!list.length) return `<div class="gd-empty-mini">${t('No guardians match your search.')}</div>`;
  return list.map(g => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="schOpenDmDetail('${g.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();schOpenDmDetail('${g.id}')}">
    <span>${schEsc(g.name)}<div style="font-size:11px;color:var(--muted)">${schEsc(g.email)}</div></span><span style="color:var(--muted);font-size:12px">${g.studentIds.length} ${t('student(s)')}</span>
  </div>`).join('');
}

/* ── Classes sub-tab ── */
function schDmClassesList() {
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Classes')}</div><span style="font-size:12px;color:var(--muted)">${SCHOOL_DATA.classes.length} ${t('total')}</span></div>
    <div class="card-body">${schDmFilterBar(true)}
      <div id="sch-dm-results" style="margin-top:10px">${schDmClassesResults()}</div>
    </div></div>`;
}
function schDmClassesResults() {
  const dm = schState.dataManagement;
  let list = SCHOOL_DATA.classes.slice();
  if (dm.filterCampus !== 'all') list = list.filter(c => c.campusId === dm.filterCampus);
  const q = dm.search.trim().toLowerCase();
  if (q) list = list.filter(c => c.name.toLowerCase().includes(q));
  list.sort((a,b) => a.name.localeCompare(b.name));
  if (!list.length) return `<div class="gd-empty-mini">${t('No classes match your search or filters.')}</div>`;
  return list.map(c => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="schOpenDmDetail('${c.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();schOpenDmDetail('${c.id}')}">
    <span>${schEsc(c.name)}<div style="font-size:11px;color:var(--muted)">${schEsc(schGetCampus(c.campusId).name)} · ${schClassStudents(c.id).length}/${c.capacity} ${t('students')}</div></span>
  </div>`).join('');
}

/* ── Admissions / Payments / Events / Communications (browse-only here) ── */
function schDmAdmissionsList() {
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Admissions')}</div><div class="card-action" onclick="authrenGoTo('admissions')">${t('Full Module')} →</div></div>
    <div class="card-body">${schDmFilterBar(true)}<div id="sch-dm-results" style="margin-top:10px">${schDmAdmissionsResults()}</div></div></div>`;
}
function schDmAdmissionsResults() {
  const dm = schState.dataManagement;
  let list = SCHOOL_DATA.admissions.slice();
  if (dm.filterCampus !== 'all') list = list.filter(a => a.campusId === dm.filterCampus);
  const q = dm.search.trim().toLowerCase();
  if (q) list = list.filter(a => (a.firstName+' '+a.lastName).toLowerCase().includes(q));
  list.sort((a,b) => b.submittedDate.localeCompare(a.submittedDate));
  if (!list.length) return `<div class="gd-empty-mini">${t('No admissions match your search or filters.')}</div>`;
  return list.map(a => `<div class="info-row"><span>${schEsc(a.firstName+' '+a.lastName)}<div style="font-size:11px;color:var(--muted)">${schEsc(a.appliedLevel)} · ${a.submittedDate}</div></span><span class="status-pill due">${t(a.status.charAt(0).toUpperCase()+a.status.slice(1).replace('-',' '))}</span></div>`).join('');
}
function schDmPaymentsList() {
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Payments')}</div><div class="card-action" onclick="authrenGoTo('payment-records')">${t('Full Module')} →</div></div>
    <div class="card-body">${schDmFilterBar(true)}<div id="sch-dm-results" style="margin-top:10px">${schDmPaymentsResults()}</div></div></div>`;
}
function schDmPaymentsResults() {
  const dm = schState.dataManagement;
  let list = SCHOOL_DATA.payments.slice();
  if (dm.filterCampus !== 'all') list = list.filter(p => p.campusId === dm.filterCampus);
  const q = dm.search.trim().toLowerCase();
  if (q) list = list.filter(p => { const st = schGetStudent(p.studentId); return st && schStudentFullName(st).toLowerCase().includes(q); });
  list = list.sort((a,b) => b.date.localeCompare(a.date)).slice(0, 40);
  if (!list.length) return `<div class="gd-empty-mini">${t('No payments match your search or filters.')}</div>`;
  return list.map(p => { const st = schGetStudent(p.studentId); return `<div class="info-row"><span>${st?schEsc(schStudentFullName(st)):''}<div style="font-size:11px;color:var(--muted)">${schEsc(p.description)} · ${p.date}</div></span><span style="color:var(--muted);font-size:12px">${schCurrency(p.amount)}</span></div>`; }).join('');
}
function schDmEventsList() {
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Events')}</div><div class="card-action" onclick="authrenGoTo('calendar')">${t('Full Module')} →</div></div>
    <div class="card-body">${schDmFilterBar(true)}<div id="sch-dm-results" style="margin-top:10px">${schDmEventsResults()}</div></div></div>`;
}
function schDmEventsResults() {
  const dm = schState.dataManagement;
  let list = SCHOOL_DATA.events.slice();
  if (dm.filterCampus !== 'all') list = list.filter(e => !e.campusId || e.campusId === dm.filterCampus);
  const q = dm.search.trim().toLowerCase();
  if (q) list = list.filter(e => e.title.toLowerCase().includes(q));
  list.sort((a,b) => a.date.localeCompare(b.date));
  if (!list.length) return `<div class="gd-empty-mini">${t('No events match your search or filters.')}</div>`;
  return list.map(e => `<div class="info-row"><span>${schEsc(e.title)}<div style="font-size:11px;color:var(--muted)">${e.date}</div></span><span class="status-pill ${SCH_EVENT_CATEGORY_PILL[e.category]}">${t(SCH_EVENT_CATEGORY_LABELS[e.category])}</span></div>`).join('');
}
function schDmCommunicationsList() {
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Communications')}</div><div class="card-action" onclick="authrenGoTo('communication')">${t('Full Module')} →</div></div>
    <div class="card-body">${schDmFilterBar(false)}<div id="sch-dm-results" style="margin-top:10px">${schDmCommunicationsResults()}</div></div></div>`;
}
function schDmCommunicationsResults() {
  const dm = schState.dataManagement;
  let list = SCHOOL_DATA.announcements.filter(a => a.status === 'sent');
  const q = dm.search.trim().toLowerCase();
  if (q) list = list.filter(a => a.subject.toLowerCase().includes(q));
  list.sort((a,b) => b.sentAt.localeCompare(a.sentAt));
  if (!list.length) return `<div class="gd-empty-mini">${t('No communications match your search.')}</div>`;
  return list.map(a => `<div class="info-row"><span>${schEsc(a.subject)}<div style="font-size:11px;color:var(--muted)">${a.sentAt.slice(0,10)}</div></span></div>`).join('');
}

/* ── Unified Detail + Edit screen (Students/Teachers/Guardians/Classes) ── */
function schDmDetailScreen() {
  const id = schState.dataManagement.detailId;
  const student = schGetStudent(id);
  if (student) return schDmStudentDetail(student);
  const teacher = schGetTeacher(id);
  if (teacher) return schDmTeacherDetail(teacher);
  const guardian = schGetGuardian(id);
  if (guardian) return schDmGuardianDetail(guardian);
  const cls = schGetClass(id);
  if (cls) return schDmClassDetail(cls);
  schState.dataManagement.detailId = null;
  return schDmBody();
}
function schDmDetailHeader(title) {
  return `<div style="display:flex;align-items:center;gap:10px;min-width:0;flex:1"><button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="schBackFromDmDetail()">${t('← Back')}</button><div class="card-title" style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${schEsc(title)}</div></div>`;
}

/* Student detail + edit */
function schDmStudentDetail(s) {
  const dm = schState.dataManagement;
  const cls = schGetClass(s.classId);
  const guardian = schGetGuardian(s.guardianId);
  if (dm.editing) {
    return `<div class="card"><div class="card-header">${schDmDetailHeader(schStudentFullName(s))}</div>
      <div class="card-body">
        <div class="st-field"><label>${t('First Name')}</label><input id="sch-dm-firstname" value="${schEsc(s.firstName)}"></div>
        <div class="st-field"><label>${t('Last Name')}</label><input id="sch-dm-lastname" value="${schEsc(s.lastName)}"></div>
        <div class="st-field"><label>${t('Class')}</label><select id="sch-dm-classid">${SCHOOL_DATA.classes.map(c => `<option value="${c.id}" ${c.id===s.classId?'selected':''}>${schEsc(c.name)}</option>`).join('')}</select></div>
        <div class="st-field"><label>${t('Status')}</label><select id="sch-dm-status">
          <option value="active" ${s.status==='active'?'selected':''}>${t('Active')}</option>
          <option value="inactive" ${s.status==='inactive'?'selected':''}>${t('Inactive')}</option>
        </select></div>
        <div style="display:flex;gap:10px">
          <button class="st-btn" onclick="schSaveDmStudent('${s.id}')">${t('Save Changes')}</button>
          <button class="st-btn ghost" onclick="schCancelDmEdit()">${t('Cancel')}</button>
        </div>
        ${dm.error ? `<div class="st-inline-msg err show" style="margin-top:12px">${dm.error}</div>` : ''}
      </div></div>`;
  }
  return `<div class="card"><div class="card-header">${schDmDetailHeader(schStudentFullName(s))}<button type="button" class="st-btn ghost sm" onclick="schStartDmEdit()">${t('Edit')}</button></div>
    <div class="card-body">
      <div class="info-row"><span>${t('Student ID')}</span><span>${schEsc(s.studentId)}</span></div>
      <div class="info-row"><span>${t('Class')}</span><span>${cls?schEsc(cls.name):'—'}</span></div>
      <div class="info-row"><span>${t('Campus')}</span><span>${schEsc(schGetCampus(s.campusId).name)}</span></div>
      <div class="info-row"><span>${t('Guardian')}</span><span>${guardian?schEsc(guardian.name):'—'}</span></div>
      <div class="info-row"><span>${t('Average Grade')}</span><span>${s.avgGrade}/20</span></div>
      <div class="info-row"><span>${t('Attendance Rate')}</span><span>${s.attendanceRate}%</span></div>
      <div class="info-row"><span>${t('Payment Status')}</span><span class="status-pill ${s.paymentStatus==='paid'?'paid':s.paymentStatus==='partial'?'awaiting':'overdue'}">${t(s.paymentStatus.charAt(0).toUpperCase()+s.paymentStatus.slice(1))}</span></div>
      <div class="info-row"><span>${t('Status')}</span><span class="status-pill ${s.status==='active'?'paid':'overdue'}">${t(s.status.charAt(0).toUpperCase()+s.status.slice(1))}</span></div>
    </div></div>`;
}
function schStartDmEdit() { schState.dataManagement.editing = true; schState.dataManagement.error = ''; schRefreshDm(); }
function schCancelDmEdit() { schState.dataManagement.editing = false; schState.dataManagement.error = ''; schRefreshDm(); }
function schSaveDmStudent(id) {
  const s = schGetStudent(id);
  const firstName = (document.getElementById('sch-dm-firstname').value || '').trim();
  const lastName = (document.getElementById('sch-dm-lastname').value || '').trim();
  const classId = document.getElementById('sch-dm-classid').value;
  const status = document.getElementById('sch-dm-status').value;
  if (!firstName || !lastName) { schState.dataManagement.error = t('First and last name are required.'); schRefreshDm(); return; }
  const oldClassName = schGetClass(s.classId).name;
  Object.assign(s, { firstName, lastName, classId, status, campusId: schGetClass(classId).campusId });
  schLogAudit('Record Edited', 'Student', schStudentFullName(s), oldClassName, schGetClass(classId).name);
  schState.dataManagement.editing = false;
  schShowToast(t('Student updated successfully.'));
  schRefreshDm();
}

/* Teacher detail + edit */
function schDmTeacherDetail(te) {
  const dm = schState.dataManagement;
  if (dm.editing) {
    return `<div class="card"><div class="card-header">${schDmDetailHeader(te.name)}</div>
      <div class="card-body">
        <div class="st-field"><label>${t('Name')}</label><input id="sch-dm-tname" value="${schEsc(te.name)}"></div>
        <div class="st-field"><label>${t('Email')}</label><input id="sch-dm-temail" type="email" value="${schEsc(te.email)}"></div>
        <div class="st-field"><label>${t('Status')}</label><select id="sch-dm-tstatus">
          <option value="active" ${te.status==='active'?'selected':''}>${t('Active')}</option>
          <option value="inactive" ${te.status==='inactive'?'selected':''}>${t('Inactive')}</option>
        </select></div>
        <div style="display:flex;gap:10px">
          <button class="st-btn" onclick="schSaveDmTeacher('${te.id}')">${t('Save Changes')}</button>
          <button class="st-btn ghost" onclick="schCancelDmEdit()">${t('Cancel')}</button>
        </div>
        ${dm.error ? `<div class="st-inline-msg err show" style="margin-top:12px">${dm.error}</div>` : ''}
      </div></div>`;
  }
  return `<div class="card"><div class="card-header">${schDmDetailHeader(te.name)}<button type="button" class="st-btn ghost sm" onclick="schStartDmEdit()">${t('Edit')}</button></div>
    <div class="card-body">
      <div class="info-row"><span>${t('Teacher ID')}</span><span>${schEsc(te.teacherId)}</span></div>
      <div class="info-row"><span>${t('Subjects')}</span><span>${schEsc(te.subjects.join(', '))}</span></div>
      <div class="info-row"><span>${t('Classes')}</span><span>${te.classIds.map(id => schGetClass(id) ? schGetClass(id).name : '').join(', ')}</span></div>
      <div class="info-row"><span>${t('Campus')}</span><span>${schEsc(schGetCampus(te.campusId).name)}</span></div>
      <div class="info-row"><span>${t('Email')}</span><span>${schEsc(te.email)}</span></div>
      <div class="info-row"><span>${t('Phone')}</span><span>${schEsc(te.phone)}</span></div>
      <div class="info-row"><span>${t('Status')}</span><span class="status-pill ${te.status==='active'?'paid':'overdue'}">${t(te.status.charAt(0).toUpperCase()+te.status.slice(1))}</span></div>
    </div></div>`;
}
function schSaveDmTeacher(id) {
  const te = schGetTeacher(id);
  const name = (document.getElementById('sch-dm-tname').value || '').trim();
  const email = (document.getElementById('sch-dm-temail').value || '').trim();
  const status = document.getElementById('sch-dm-tstatus').value;
  if (!name) { schState.dataManagement.error = t('Name is required.'); schRefreshDm(); return; }
  Object.assign(te, { name, email, status });
  schLogAudit('Record Edited', 'Teacher', name, '', status);
  schState.dataManagement.editing = false;
  schShowToast(t('Teacher updated successfully.'));
  schRefreshDm();
}

/* Guardian detail + edit */
function schDmGuardianDetail(g) {
  const dm = schState.dataManagement;
  if (dm.editing) {
    return `<div class="card"><div class="card-header">${schDmDetailHeader(g.name)}</div>
      <div class="card-body">
        <div class="st-field"><label>${t('Name')}</label><input id="sch-dm-gname" value="${schEsc(g.name)}"></div>
        <div class="st-field"><label>${t('Email')}</label><input id="sch-dm-gemail" type="email" value="${schEsc(g.email)}"></div>
        <div class="st-field"><label>${t('Phone')}</label><input id="sch-dm-gphone" value="${schEsc(g.phone)}"></div>
        <div style="display:flex;gap:10px">
          <button class="st-btn" onclick="schSaveDmGuardian('${g.id}')">${t('Save Changes')}</button>
          <button class="st-btn ghost" onclick="schCancelDmEdit()">${t('Cancel')}</button>
        </div>
        ${dm.error ? `<div class="st-inline-msg err show" style="margin-top:12px">${dm.error}</div>` : ''}
      </div></div>`;
  }
  return `<div class="card"><div class="card-header">${schDmDetailHeader(g.name)}<button type="button" class="st-btn ghost sm" onclick="schStartDmEdit()">${t('Edit')}</button></div>
    <div class="card-body">
      <div class="info-row"><span>${t('Email')}</span><span>${schEsc(g.email)}</span></div>
      <div class="info-row"><span>${t('Phone')}</span><span>${schEsc(g.phone)}</span></div>
      <div class="info-row"><span>${t('Students')}</span><span>${g.studentIds.map(id => { const st = schGetStudent(id); return st ? schStudentFullName(st) : ''; }).join(', ')}</span></div>
    </div></div>`;
}
function schSaveDmGuardian(id) {
  const g = schGetGuardian(id);
  const name = (document.getElementById('sch-dm-gname').value || '').trim();
  const email = (document.getElementById('sch-dm-gemail').value || '').trim();
  const phone = (document.getElementById('sch-dm-gphone').value || '').trim();
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!name) { schState.dataManagement.error = t('Name is required.'); schRefreshDm(); return; }
  if (!email || !emailRegex.test(email)) { schState.dataManagement.error = t('Enter a valid email.'); schRefreshDm(); return; }
  Object.assign(g, { name, email, phone });
  schLogAudit('Record Edited', 'Guardian', name, '', email);
  schState.dataManagement.editing = false;
  schShowToast(t('Guardian updated successfully.'));
  schRefreshDm();
}

/* Class detail + edit */
function schDmClassDetail(c) {
  const dm = schState.dataManagement;
  const roster = schClassStudents(c.id);
  if (dm.editing) {
    return `<div class="card"><div class="card-header">${schDmDetailHeader(c.name)}</div>
      <div class="card-body">
        <div class="st-field"><label>${t('Name')}</label><input id="sch-dm-cname" value="${schEsc(c.name)}"></div>
        <div class="st-field"><label>${t('Capacity')}</label><input id="sch-dm-ccapacity" type="number" min="${roster.length}" value="${c.capacity}"></div>
        <div class="st-field"><label>${t('Homeroom Teacher')}</label><select id="sch-dm-cteacher">${SCHOOL_DATA.teachers.filter(te=>te.campusId===c.campusId).map(te => `<option value="${te.id}" ${te.id===c.homeroomTeacherId?'selected':''}>${schEsc(te.name)}</option>`).join('')}</select></div>
        <div style="display:flex;gap:10px">
          <button class="st-btn" onclick="schSaveDmClass('${c.id}')">${t('Save Changes')}</button>
          <button class="st-btn ghost" onclick="schCancelDmEdit()">${t('Cancel')}</button>
        </div>
        ${dm.error ? `<div class="st-inline-msg err show" style="margin-top:12px">${dm.error}</div>` : ''}
      </div></div>`;
  }
  return `<div class="card"><div class="card-header">${schDmDetailHeader(c.name)}<button type="button" class="st-btn ghost sm" onclick="schStartDmEdit()">${t('Edit')}</button></div>
    <div class="card-body">
      <div class="info-row"><span>${t('Campus')}</span><span>${schEsc(schGetCampus(c.campusId).name)}</span></div>
      <div class="info-row"><span>${t('Level')}</span><span>${schEsc(c.level)}</span></div>
      <div class="info-row"><span>${t('Capacity')}</span><span>${roster.length}/${c.capacity}</span></div>
      <div class="info-row"><span>${t('Homeroom Teacher')}</span><span>${schGetTeacher(c.homeroomTeacherId) ? schEsc(schGetTeacher(c.homeroomTeacherId).name) : '—'}</span></div>
    </div></div>`;
}
function schSaveDmClass(id) {
  const c = schGetClass(id);
  const roster = schClassStudents(c.id);
  const name = (document.getElementById('sch-dm-cname').value || '').trim();
  const capacity = parseInt(document.getElementById('sch-dm-ccapacity').value, 10);
  const homeroomTeacherId = document.getElementById('sch-dm-cteacher').value;
  if (!name) { schState.dataManagement.error = t('Name is required.'); schRefreshDm(); return; }
  if (isNaN(capacity) || capacity < roster.length) { schState.dataManagement.error = t('Capacity cannot be less than the current roster size (') + roster.length + ').'; schRefreshDm(); return; }
  Object.assign(c, { name, capacity, homeroomTeacherId });
  schLogAudit('Record Edited', 'Class', name, '', 'capacity ' + capacity);
  schState.dataManagement.editing = false;
  schShowToast(t('Class updated successfully.'));
  schRefreshDm();
}

/* ══════════════════════════════════════════════════════
   BASIC ADMINISTRATION (section 10)
   Every editable setting genuinely persists and is reflected wherever
   that data is used elsewhere (Dashboard header, receipts, etc.).
══════════════════════════════════════════════════════ */
function schAdminBasicView() {
  return `<div id="sch-admin-basic-content">${schAdminBasicBody()}</div>`;
}
function schAdminBasicBody() {
  const ab = schState.adminBasic;
  if (ab.editing === 'institution') return schAdminEditInstitutionForm();
  if (ab.editing === 'account') return schAdminEditAccountForm();
  const inst = SCHOOL_DATA.institution;
  const owner = SCHOOL_DATA.owner;
  const np = ab.notifPrefs;
  return `
    <div class="card"><div class="card-header"><div class="card-title">${t('Institution Information')}</div><button class="st-btn ghost sm" onclick="schOpenAdminEdit('institution')">${t('Edit')}</button></div>
      <div class="card-body">
        <div class="info-row"><span>${t('Name')}</span><span>${schEsc(inst.name)}</span></div>
        <div class="info-row"><span>${t('Legal Name')}</span><span>${schEsc(inst.legalName)}</span></div>
        <div class="info-row"><span>${t('Type')}</span><span>${schEsc(inst.type)}</span></div>
        <div class="info-row"><span>${t('Founded')}</span><span>${inst.foundedYear}</span></div>
        <div class="info-row"><span>${t('Address')}</span><span>${schEsc(inst.address)}</span></div>
        <div class="info-row"><span>${t('Phone')}</span><span>${schEsc(inst.phone)}</span></div>
        <div class="info-row"><span>${t('Email')}</span><span>${schEsc(inst.email)}</span></div>
        <div class="info-row"><span>${t('Academic Year')}</span><span>${schEsc(inst.academicYear)}</span></div>
        <div class="info-row"><span>${t('Current Term')}</span><span>${schEsc(inst.currentTerm)}</span></div>
      </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Account Information')}</div><button class="st-btn ghost sm" onclick="schOpenAdminEdit('account')">${t('Edit')}</button></div>
      <div class="card-body">
        <div class="info-row"><span>${t('Owner Name')}</span><span>${schEsc(owner.name)}</span></div>
        <div class="info-row"><span>${t('Title')}</span><span>${schEsc(owner.title)}</span></div>
        <div class="info-row"><span>${t('Account Status')}</span><span class="status-pill paid">${t('Active')}</span></div>
      </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Notification Preferences')}</div></div>
      <div class="card-body">
        <div class="info-row"><span>${t('Email Notifications')}</span><label class="gd-switch"><input type="checkbox" ${np.email?'checked':''} onchange="schToggleNotifPref('email')"><span class="gd-switch-slider"></span></label></div>
        <div class="info-row"><span>${t('SMS Notifications')}</span><label class="gd-switch"><input type="checkbox" ${np.sms?'checked':''} onchange="schToggleNotifPref('sms')"><span class="gd-switch-slider"></span></label></div>
        <div class="info-row"><span>${t('Weekly Digest')}</span><label class="gd-switch"><input type="checkbox" ${np.weeklyDigest?'checked':''} onchange="schToggleNotifPref('weeklyDigest')"><span class="gd-switch-slider"></span></label></div>
      </div></div>`;
}
function schOpenAdminEdit(which) { schState.adminBasic.editing = which; schState.adminBasic.error = ''; schRefreshAdminBasic(); }
function schCancelAdminEdit() { schState.adminBasic.editing = null; schState.adminBasic.error = ''; schRefreshAdminBasic(); }
function schRefreshAdminBasic() { const el = document.getElementById('sch-admin-basic-content'); if (el) el.innerHTML = schAdminBasicBody(); }
function schToggleNotifPref(key) {
  schState.adminBasic.notifPrefs[key] = !schState.adminBasic.notifPrefs[key];
  schShowToast(t('Preference updated.'));
}
function schAdminEditInstitutionForm() {
  const inst = SCHOOL_DATA.institution;
  const err = schState.adminBasic.error;
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Edit Institution Information')}</div></div>
    <div class="card-body">
      <div class="st-field"><label>${t('Name')}</label><input id="sch-ab-name" value="${schEsc(inst.name)}"></div>
      <div class="st-field"><label>${t('Address')}</label><input id="sch-ab-address" value="${schEsc(inst.address)}"></div>
      <div class="st-field"><label>${t('Phone')}</label><input id="sch-ab-phone" value="${schEsc(inst.phone)}"></div>
      <div class="st-field"><label>${t('Email')}</label><input id="sch-ab-email" type="email" value="${schEsc(inst.email)}"></div>
      <div class="st-field"><label>${t('Academic Year')}</label><input id="sch-ab-year" value="${schEsc(inst.academicYear)}"></div>
      <div class="st-field"><label>${t('Current Term')}</label><input id="sch-ab-term" value="${schEsc(inst.currentTerm)}"></div>
      <div style="display:flex;gap:10px">
        <button class="st-btn" onclick="schSaveAdminInstitution()">${t('Save Changes')}</button>
        <button class="st-btn ghost" onclick="schCancelAdminEdit()">${t('Cancel')}</button>
      </div>
      ${err ? `<div class="st-inline-msg err show" style="margin-top:12px">${err}</div>` : ''}
    </div></div>`;
}
function schSaveAdminInstitution() {
  const name = (document.getElementById('sch-ab-name').value || '').trim();
  const address = (document.getElementById('sch-ab-address').value || '').trim();
  const phone = (document.getElementById('sch-ab-phone').value || '').trim();
  const email = (document.getElementById('sch-ab-email').value || '').trim();
  const academicYear = (document.getElementById('sch-ab-year').value || '').trim();
  const currentTerm = (document.getElementById('sch-ab-term').value || '').trim();
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!name) { schState.adminBasic.error = t('Institution name is required.'); schRefreshAdminBasic(); return; }
  if (!email || !emailRegex.test(email)) { schState.adminBasic.error = t('Enter a valid email.'); schRefreshAdminBasic(); return; }
  const oldName = SCHOOL_DATA.institution.name;
  Object.assign(SCHOOL_DATA.institution, { name, address, phone, email, academicYear, currentTerm });
  schLogAudit('Configuration Changed', 'Institution Information', name, oldName, name);
  schState.adminBasic.editing = null;
  schShowToast(t('Institution information updated successfully.'));
  schRefreshAdminBasic();
}
function schAdminEditAccountForm() {
  const owner = SCHOOL_DATA.owner;
  const err = schState.adminBasic.error;
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Edit Account Information')}</div></div>
    <div class="card-body">
      <div class="st-field"><label>${t('Name')}</label><input id="sch-ab-oname" value="${schEsc(owner.name)}"></div>
      <div class="st-field"><label>${t('Title')}</label><input id="sch-ab-otitle" value="${schEsc(owner.title)}"></div>
      <div style="display:flex;gap:10px">
        <button class="st-btn" onclick="schSaveAdminAccount()">${t('Save Changes')}</button>
        <button class="st-btn ghost" onclick="schCancelAdminEdit()">${t('Cancel')}</button>
      </div>
      ${err ? `<div class="st-inline-msg err show" style="margin-top:12px">${err}</div>` : ''}
    </div></div>`;
}
function schSaveAdminAccount() {
  const name = (document.getElementById('sch-ab-oname').value || '').trim();
  const title = (document.getElementById('sch-ab-otitle').value || '').trim();
  if (!name) { schState.adminBasic.error = t('Name is required.'); schRefreshAdminBasic(); return; }
  Object.assign(SCHOOL_DATA.owner, { name, title });
  schLogAudit('Configuration Changed', 'Account Information', name, '', name);
  schState.adminBasic.editing = null;
  schShowToast(t('Account information updated successfully.'));
  schRefreshAdminBasic();
}

/* ══════════════════════════════════════════════════════
   SUBSCRIPTION MANAGEMENT (section 11)
   No real payment integration exists — plan changes are clearly
   simulated frontend state transitions, never presented as a real
   transaction or real money charged.
══════════════════════════════════════════════════════ */
function schSubscriptionView() {
  return `<div id="sch-subscription-content">${schSubscriptionBody()}</div>`;
}
function schSubscriptionBody() {
  const sub = SCHOOL_DATA.subscription;
  const currentPlan = SCH_SUBSCRIPTION_PLANS.find(p => p.id === sub.currentPlan);
  return `
    <div class="card"><div class="card-header"><div class="card-title">${t('Current Plan')}</div></div>
      <div class="card-body">
        <div class="info-row"><span>${t('Plan')}</span><span style="font-weight:700">${schEsc(currentPlan.name)}</span></div>
        <div class="info-row"><span>${t('Price')}</span><span>${schEsc(currentPlan.price)}</span></div>
        <div class="info-row"><span>${t('Billing Cycle')}</span><span>${schEsc(sub.billingCycle)}</span></div>
        <div class="info-row"><span>${t('Subscription Status')}</span><span class="status-pill ${sub.billingStatus==='active'?'paid':'overdue'}">${t(sub.billingStatus.charAt(0).toUpperCase()+sub.billingStatus.slice(1))}</span></div>
        <div class="info-row"><span>${t('Renewal Date')}</span><span>${sub.renewalDate}</span></div>
        <div style="margin-top:10px;font-size:12.5px;font-weight:600;margin-bottom:6px">${t('Included Features')}</div>
        ${currentPlan.features.map(f => `<div style="font-size:12px;color:var(--muted2);margin-bottom:4px">${aIcon('check')} ${schEsc(f)}</div>`).join('')}
      </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Available Plans')}</div><span style="font-size:12px;color:var(--muted)">${t('Feature Comparison')}</span></div>
      <div class="card-body">
        ${SCH_SUBSCRIPTION_PLANS.map(p => {
          const isCurrent = p.id === sub.currentPlan;
          const planOrder = SCH_SUBSCRIPTION_PLANS.map(x => x.id);
          const isUpgrade = planOrder.indexOf(p.id) > planOrder.indexOf(sub.currentPlan);
          return `<div class="card" style="margin-bottom:10px;background:var(--surface2)${isCurrent?';border:1px solid var(--accent)':''}"><div class="card-body">
            <div style="display:flex;justify-content:space-between;align-items:center">
              <div style="font-weight:700;font-size:13px">${schEsc(p.name)}</div>
              <div style="font-size:12px;color:var(--muted)">${schEsc(p.price)}</div>
            </div>
            ${p.features.map(f => `<div style="font-size:11.5px;color:var(--muted2);margin-top:4px">${aIcon('check')} ${schEsc(f)}</div>`).join('')}
            <div style="margin-top:10px">
              ${isCurrent ? `<span class="status-pill paid">${t('Current Plan')}</span>` : (authrenCan('manageSubscription','school',currentSchoolType) ? `<button type="button" class="st-btn ghost sm" onclick="schConfirmPlanChange('${p.id}')">${isUpgrade ? t('Upgrade') : t('Downgrade')}</button>` : `<span style="font-size:11.5px;color:var(--muted)">${isUpgrade ? t('Upgrade available') : t('Lower tier')}</span>`)}
            </div>
          </div></div>`;
        }).join('')}
      </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Subscription History')}</div></div>
      <div class="card-body">${sub.history.map(h => `<div class="info-row"><span>${schEsc(h.event)}</span><span style="color:var(--muted);font-size:12px">${h.date}</span></div>`).join('')}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Billing History')}</div></div>
      <div class="card-body">${sub.billingHistory.map(b => `<div class="info-row"><span>${schEsc(b.description)}<div style="font-size:11px;color:var(--muted)">${b.date}</div></span><span style="text-align:right">${schEsc(b.amount)}<div style="margin-top:4px"><span class="status-pill paid">${t(b.status.charAt(0).toUpperCase()+b.status.slice(1))}</span></div></span></div>`).join('')}</div></div>`;
}
function schConfirmPlanChange(planId) {
  const plan = SCH_SUBSCRIPTION_PLANS.find(p => p.id === planId);
  const planOrder = SCH_SUBSCRIPTION_PLANS.map(x => x.id);
  const isUpgrade = planOrder.indexOf(planId) > planOrder.indexOf(SCHOOL_DATA.subscription.currentPlan);
  stOpenModal(`<h3 style="margin-bottom:10px">${isUpgrade ? t('Upgrade to') : t('Downgrade to')} ${schEsc(plan.name)}?</h3>
    <p style="font-size:13px;color:var(--muted);margin-bottom:18px">${t('This simulates the plan change in this demo — no real payment is processed.')}</p>
    <div style="display:flex;gap:10px">
      <button class="st-btn" onclick="schApplyPlanChange('${planId}');stCloseModal()">${t('Confirm')}</button>
      <button class="st-btn ghost" onclick="stCloseModal()">${t('Cancel')}</button>
    </div>`);
}
function schApplyPlanChange(planId) {
  const result = authrenChangeSubscriptionPlan(planId, { role:'school', associationType: currentSchoolType, id: SCHOOL_DATA.owner ? SCHOOL_DATA.owner.id : null });
  if (!result.ok) { schShowToast(result.message); return; }
  const plan = SCH_SUBSCRIPTION_PLANS.find(p => p.id === planId);
  const oldPlanId = SCHOOL_DATA.subscription.currentPlan;
  SCHOOL_DATA.subscription.currentPlan = planId;
  SCHOOL_DATA.subscription.history.unshift({ date: SCH_TODAY, event: `Changed plan to ${plan.name}`, amount: plan.price });
  schRefreshSubscription();
  schShowToast(`${t('Plan changed to')} ${plan.name}.`);
}
function schRefreshSubscription() { const el = document.getElementById('sch-subscription-content'); if (el) el.innerHTML = schSubscriptionBody(); }

/* ══════════════════════════════════════════════════════
   ADVANCED SCHOOL ANALYTICS (section 12)
   Enrollment/Attendance/Academic/Admissions/Payment trends, student
   population changes, and operational activity — all genuinely
   recomputed by the campus cross-filter.
══════════════════════════════════════════════════════ */
function schAnalyticsAdvancedView() {
  return `<div id="sch-analytics-advanced-content">${schAnalyticsAdvancedBody()}</div>`;
}
function schAnalyticsAdvancedBody() {
  const f = schState.analyticsAdvanced;
  const students = f.campus === 'all' ? SCHOOL_DATA.students : schCampusStudents(f.campus);
  const enrollments = f.campus === 'all' ? SCHOOL_DATA.enrollments : SCHOOL_DATA.enrollments.filter(e => e.campusId === f.campus);
  const admissions = f.campus === 'all' ? SCHOOL_DATA.admissions : SCHOOL_DATA.admissions.filter(a => a.campusId === f.campus);
  const payments = f.campus === 'all' ? SCHOOL_DATA.payments : SCHOOL_DATA.payments.filter(p => p.campusId === f.campus);

  const enrollByMonth = {};
  enrollments.forEach(e => { const m = e.enrollmentDate.slice(0, 7); enrollByMonth[m] = (enrollByMonth[m] || 0) + 1; });
  const admissionsByMonth = {};
  admissions.forEach(a => { const m = a.submittedDate.slice(0, 7); admissionsByMonth[m] = (admissionsByMonth[m] || 0) + 1; });
  const paymentsByMonth = {};
  payments.filter(p => p.status === 'paid').forEach(p => { const m = p.date.slice(0, 7); paymentsByMonth[m] = (paymentsByMonth[m] || 0) + p.amount; });
  const attendancePoints = SCH_ATTENDANCE_DAYS.map(d => { const agg = schAggregateAttendance(students.map(s=>s.id), [d]); return { label: d.slice(5), value: agg.rate !== null ? agg.rate : 0 }; });
  const curAcademic = schAvg(students.map(s => s.avgGrade));
  const prevAcademic = schAvg(students.map(s => s.prevTermAvgGrade));

  const activeCount = students.filter(s => s.status === 'active').length;
  const acceptedAdmissions = admissions.filter(a => a.status === 'accepted').length;
  const netPopulationChange = acceptedAdmissions; // real accepted applicants represent genuine incoming population growth

  const opActivity = {};
  SCHOOL_DATA.auditLog.forEach(a => { opActivity[a.action] = (opActivity[a.action] || 0) + 1; });

  return `
    <div class="card"><div class="card-header"><div class="card-title">${t('Advanced School Analytics')}</div></div>
      <div class="card-body">
        <select onchange="schSetAnalyticsAdvancedCampus(this.value)" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
          <option value="all" ${f.campus==='all'?'selected':''}>${t('All Campuses')}</option>
          ${SCHOOL_DATA.campuses.map(c => `<option value="${c.id}" ${c.id===f.campus?'selected':''}>${schEsc(c.name)}</option>`).join('')}
        </select>
      </div></div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Enrollment Trend')}</div></div>
      <div class="card-body">${Object.keys(enrollByMonth).length ? Object.keys(enrollByMonth).sort().map(m => `<div class="info-row"><span>${m}</span><span style="color:var(--muted)">${enrollByMonth[m]}</span></div>`).join('') : `<div class="gd-empty-mini">${t('No enrollment data for this scope.')}</div>`}</div></div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Attendance Trend')}</div></div>
      <div class="card-body">${gdSvgLineChart(attendancePoints, { max:100, unit:'%', ariaLabel:t('Attendance trend'), emptyText:t('No attendance data available.') })}</div></div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Academic Trend')}</div></div>
      <div class="card-body">
        <div class="info-row"><span>${t('Previous Term Average')}</span><span>${prevAcademic!==null?prevAcademic+'/20':'—'}</span></div>
        <div class="info-row"><span>${t('Current Term Average')}</span><span>${curAcademic!==null?curAcademic+'/20':'—'}</span></div>
        ${curAcademic!==null && prevAcademic!==null ? `<div style="font-size:11.5px;color:${curAcademic>=prevAcademic?'var(--green)':'var(--red)'};margin-top:6px">${curAcademic>=prevAcademic?'▲':'▼'} ${Math.abs(Math.round((curAcademic-prevAcademic)*10)/10)} ${t('points vs previous term')}</div>` : ''}
      </div></div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Admissions Trend')}</div></div>
      <div class="card-body">${Object.keys(admissionsByMonth).length ? Object.keys(admissionsByMonth).sort().map(m => `<div class="info-row"><span>${m}</span><span style="color:var(--muted)">${admissionsByMonth[m]}</span></div>`).join('') : `<div class="gd-empty-mini">${t('No admissions data for this scope.')}</div>`}</div></div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Payment Trend')}</div></div>
      <div class="card-body">${Object.keys(paymentsByMonth).length ? Object.keys(paymentsByMonth).sort().map(m => `<div class="info-row"><span>${m}</span><span style="color:var(--green)">${schCurrency(paymentsByMonth[m])}</span></div>`).join('') : `<div class="gd-empty-mini">${t('No payment data for this scope.')}</div>`}</div></div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Student Population Changes')}</div></div>
      <div class="card-body">
        <div class="info-row"><span>${t('Active Students')}</span><span>${activeCount}</span></div>
        <div class="info-row"><span>${t('Accepted Admissions (Incoming)')}</span><span style="color:var(--green)">+${netPopulationChange}</span></div>
      </div></div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Operational Activity')}</div></div>
      <div class="card-body">${Object.keys(opActivity).length ? Object.keys(opActivity).map(a => `<div class="info-row"><span>${t(a)}</span><span style="color:var(--muted)">${opActivity[a]}</span></div>`).join('') : `<div class="gd-empty-mini">${t('No recorded activity yet.')}</div>`}</div></div>`;
}
function schSetAnalyticsAdvancedCampus(v) {
  schState.analyticsAdvanced.campus = v;
  const el = document.getElementById('sch-analytics-advanced-content');
  if (el) el.innerHTML = schAnalyticsAdvancedBody();
}

/* ══════════════════════════════════════════════════════
   ADVANCED REPORTS (section 13) — combines multiple areas into one
   configurable report: Academic, Attendance, Enrollment, Admissions,
   Payments, Communication, Administration.
══════════════════════════════════════════════════════ */
const SCH_REPORT_DOMAINS = [
  ['academic','Academic'], ['attendance','Attendance'], ['enrollment','Enrollment'],
  ['admissions','Admissions'], ['payments','Payments'], ['communication','Communication'], ['administration','Administration'],
];
function schReportsAdvancedView() {
  return `<div id="sch-reports-advanced-content">${schReportsAdvancedBody()}</div>`;
}
function schReportsAdvancedBody() {
  const r = schState.reportsAdvanced;
  return r.screen === 'preview' ? schAdvReportPreview() : schAdvReportForm();
}
function schRefreshReportsAdvanced() { const el = document.getElementById('sch-reports-advanced-content'); if (el) el.innerHTML = schReportsAdvancedBody(); }
function schAdvReportForm() {
  const r = schState.reportsAdvanced;
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Advanced Report Builder')}</div>${r.savedConfigs.length ? `<div class="card-action" onclick="schShowSavedReportConfigs()">${t('Saved Configurations')} (${r.savedConfigs.length})</div>` : ''}</div>
    <div class="card-body">
      <div style="font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Domains to Include')}</div>
      ${SCH_REPORT_DOMAINS.map(([id,label]) => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="schToggleReportDomain('${id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();schToggleReportDomain('${id}')}"><span><input type="checkbox" ${r.domains.includes(id)?'checked':''} style="margin-right:8px;pointer-events:none">${t(label)}</span></div>`).join('')}
      <div style="display:flex;gap:10px;margin-top:14px">
        <select onchange="schSetAdvReportField('campus', this.value)" style="flex:1;background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
          <option value="all" ${r.campus==='all'?'selected':''}>${t('All Campuses')}</option>
          ${SCHOOL_DATA.campuses.map(c => `<option value="${c.id}" ${c.id===r.campus?'selected':''}>${schEsc(c.name)}</option>`).join('')}
        </select>
        <select onchange="schSetAdvReportField('period', this.value)" style="flex:1;background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
          <option value="all" ${r.period==='all'?'selected':''}>${t('Full Term')}</option>
          <option value="month" ${r.period==='month'?'selected':''}>${t('Current Month')}</option>
        </select>
      </div>
      <button class="st-btn" style="margin-top:14px" onclick="schGenerateAdvReport()">${t('Generate Report')}</button>
      ${r.error ? `<div class="st-inline-msg err show" style="margin-top:12px">${r.error}</div>` : ''}
    </div></div>`;
}
function schToggleReportDomain(id) {
  const r = schState.reportsAdvanced;
  if (r.domains.includes(id)) r.domains = r.domains.filter(x => x !== id);
  else r.domains.push(id);
  schRefreshReportsAdvanced();
}
function schSetAdvReportField(key, value) { schState.reportsAdvanced[key] = value; }
function schGenerateAdvReport() {
  const r = schState.reportsAdvanced;
  if (!r.domains.length) { r.error = t('Select at least one domain to include.'); schRefreshReportsAdvanced(); return; }
  r.error = '';
  r.screen = 'preview';
  r.generatedAt = SCH_TODAY;
  schRefreshReportsAdvanced();
}
function schBackToAdvReportForm() { schState.reportsAdvanced.screen = 'form'; schRefreshReportsAdvanced(); }

function schAdvReportPreview() {
  const r = schState.reportsAdvanced;
  let students = r.campus === 'all' ? SCHOOL_DATA.students : schCampusStudents(r.campus);
  let payments = r.campus === 'all' ? SCHOOL_DATA.payments : SCHOOL_DATA.payments.filter(p => p.campusId === r.campus);
  let admissions = r.campus === 'all' ? SCHOOL_DATA.admissions : SCHOOL_DATA.admissions.filter(a => a.campusId === r.campus);
  const days = r.period === 'month' ? SCH_ATTENDANCE_DAYS.slice(-8) : SCH_ATTENDANCE_DAYS;
  const campusLabel = r.campus === 'all' ? t('All Campuses') : schEsc(schGetCampus(r.campus).name);
  const sections = [];
  if (r.domains.includes('academic')) sections.push({ title:t('Academic'), rows:[[t('Average Grade'), (schAvg(students.map(s=>s.avgGrade))||'—') + '/20']] });
  if (r.domains.includes('attendance')) { const agg = schAggregateAttendance(students.map(s=>s.id), days); sections.push({ title:t('Attendance'), rows:[[t('Attendance Rate'), agg.rate!==null?agg.rate+'%':'—'], [t('Absences'), agg.absent]] }); }
  if (r.domains.includes('enrollment')) sections.push({ title:t('Enrollment'), rows:[[t('Total Enrollment'), students.length], [t('Active'), students.filter(s=>s.status==='active').length]] });
  if (r.domains.includes('admissions')) sections.push({ title:t('Admissions'), rows:[[t('Total Applications'), admissions.length], [t('Accepted'), admissions.filter(a=>a.status==='accepted').length]] });
  if (r.domains.includes('payments')) { const collected = payments.filter(p=>p.status==='paid').reduce((s,p)=>s+p.amount,0); const outstanding = payments.filter(p=>p.status!=='paid').reduce((s,p)=>s+p.amount,0); sections.push({ title:t('Payments'), rows:[[t('Collected'), schCurrency(collected)], [t('Outstanding'), schCurrency(outstanding)]] }); }
  if (r.domains.includes('communication')) { const sent = SCHOOL_DATA.announcements.filter(a=>a.status==='sent'); sections.push({ title:t('Communication'), rows:[[t('Total Sent'), sent.length]] }); }
  if (r.domains.includes('administration')) sections.push({ title:t('Administration'), rows:[[t('Total Campuses'), SCHOOL_DATA.campuses.length], [t('Total Classes'), SCHOOL_DATA.classes.length]] });
  return `<div class="card">
    <div class="card-header">
      <div style="display:flex;align-items:center;gap:10px"><button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="schBackToAdvReportForm()">${t('← Back')}</button><div class="card-title">${t('Combined Report')}</div></div>
      <div style="display:flex;gap:8px">
        <button type="button" class="st-btn ghost sm" onclick="schSaveAdvReportConfig()">${t('Save Configuration')}</button>
        <button type="button" class="st-btn ghost sm" onclick="window.print()">${aIcon('printer')} ${t('Print / Export')}</button>
      </div>
    </div>
    <div class="card-body">
      <div style="font-size:11.5px;color:var(--muted);margin-bottom:14px">${t('Generated')} ${r.generatedAt} · ${campusLabel}</div>
      ${sections.map(s => `<div style="margin-top:12px;font-size:12.5px;font-weight:600;margin-bottom:6px">${s.title}</div>${s.rows.map(row => `<div class="info-row"><span>${row[0]}</span><span>${row[1]}</span></div>`).join('')}`).join('')}
    </div></div>`;
}
function schSaveAdvReportConfig() {
  const r = schState.reportsAdvanced;
  r.savedConfigs.push({ id:'src' + Date.now(), domains:r.domains.slice(), campus:r.campus, period:r.period, savedAt:SCH_TODAY });
  schShowToast(t('Report configuration saved.'));
}
function schShowSavedReportConfigs() {
  const r = schState.reportsAdvanced;
  const el = document.getElementById('sch-reports-advanced-content');
  if (el) el.innerHTML = `<div class="card"><div class="card-header">
    <div style="display:flex;align-items:center;gap:10px"><button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="schRefreshReportsAdvanced()">${t('← Back')}</button><div class="card-title">${t('Saved Configurations')}</div></div>
    </div>
    <div class="card-body">
      ${r.savedConfigs.map(cfg => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="schLoadAdvReportConfig('${cfg.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();schLoadAdvReportConfig('${cfg.id}')}">
        <span>${cfg.domains.length} ${t('domains')}</span><span style="color:var(--muted);font-size:12px">${cfg.savedAt}</span>
      </div>`).join('') || `<div class="gd-empty-mini">${t('No saved configurations yet.')}</div>`}
    </div></div>`;
}
function schLoadAdvReportConfig(configId) {
  const r = schState.reportsAdvanced;
  const cfg = r.savedConfigs.find(c => c.id === configId);
  if (!cfg) return;
  r.domains = cfg.domains.slice();
  r.campus = cfg.campus;
  r.period = cfg.period;
  r.screen = 'preview';
  r.generatedAt = SCH_TODAY;
  schRefreshReportsAdvanced();
}

/* ══════════════════════════════════════════════════════
   ADMISSIONS (section 14) — accepting an applicant genuinely makes
   them eligible for enrollment, connecting directly into the real
   Student Enrollment module built in batch 3.
══════════════════════════════════════════════════════ */
const SCH_ADMISSION_STATUS_META = { pending:{cls:'due',label:'Pending'}, 'under-review':{cls:'awaiting',label:'Under Review'}, accepted:{cls:'paid',label:'Accepted'}, rejected:{cls:'overdue',label:'Rejected'}, waitlisted:{cls:'resolved',label:'Waitlisted'} };
function schAdmissionsView() {
  return `<div id="sch-admissions-content">${schAdmissionsBody()}</div>`;
}
function schAdmissionsBody() {
  const s = schState.admissions;
  if (s.screen === 'form') return schAdmissionFormScreen();
  if (s.screen === 'detail') { const a = schGetAdmission(s.appId); if (!a) { s.screen = 'list'; return schAdmissionsBody(); } return schAdmissionDetailScreen(a); }
  return schAdmissionListScreen();
}
function schRefreshAdmissions() { const el = document.getElementById('sch-admissions-content'); if (el) el.innerHTML = schAdmissionsBody(); }
function schAdmissionFullName(a) { return `${a.firstName} ${a.lastName}`; }
function schFilteredAdmissions() {
  const s = schState.admissions;
  let list = SCHOOL_DATA.admissions.slice();
  if (s.filterStatus !== 'all') list = list.filter(a => a.status === s.filterStatus);
  if (s.filterCampus !== 'all') list = list.filter(a => a.campusId === s.filterCampus);
  const q = s.search.trim().toLowerCase();
  if (q) list = list.filter(a => schAdmissionFullName(a).toLowerCase().includes(q));
  return list.sort((a, b) => b.submittedDate.localeCompare(a.submittedDate));
}
function schAdmissionListScreen() {
  const s = schState.admissions;
  const statuses = [['all','All'],['pending','Pending'],['under-review','Under Review'],['accepted','Accepted'],['waitlisted','Waitlisted'],['rejected','Rejected']];
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Admissions')}</div><button class="st-btn sm" onclick="schOpenAdmissionForm()">+ ${t('New Application')}</button></div>
    <div class="card-body">
      <input class="gd-comm-search-input" type="text" placeholder="${t('Search applicants...')}" value="${schEsc(s.search)}" oninput="schSetAdmissionSearch(this.value)">
      <div class="gd-comm-filter-row" style="margin-top:10px">${statuses.map(([id,label]) => `<div class="gd-comm-filter-chip${s.filterStatus===id?' active':''}" onclick="schSetAdmissionStatusFilter('${id}')">${t(label)}</div>`).join('')}</div>
      <select onchange="schSetAdmissionCampusFilter(this.value)" style="margin-top:10px;background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
        <option value="all" ${s.filterCampus==='all'?'selected':''}>${t('All Campuses')}</option>
        ${SCHOOL_DATA.campuses.map(c => `<option value="${c.id}" ${c.id===s.filterCampus?'selected':''}>${schEsc(c.name)}</option>`).join('')}
      </select>
    </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Applications')}</div></div>
      <div class="card-body" id="sch-admission-list-results">${schAdmissionListResultsBlock()}</div></div>`;
}
function schAdmissionListResultsBlock() {
  const list = schFilteredAdmissions();
  if (!list.length) return `<div class="gd-empty-mini">${t('No applications match your search or filters.')}</div>`;
  return list.map(a => { const meta = SCH_ADMISSION_STATUS_META[a.status]; return `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="schOpenAdmissionDetail('${a.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();schOpenAdmissionDetail('${a.id}')}">
    <span>${schEsc(schAdmissionFullName(a))}<div style="font-size:11px;color:var(--muted)">${schEsc(a.appliedLevel)} · ${schEsc(schGetCampus(a.campusId).name)} · ${a.submittedDate}</div></span><span class="status-pill ${meta.cls}">${t(meta.label)}</span>
  </div>`; }).join('');
}
function schSetAdmissionSearch(v) { schState.admissions.search = v; const el = document.getElementById('sch-admission-list-results'); if (el) el.innerHTML = schAdmissionListResultsBlock(); }
function schSetAdmissionStatusFilter(v) { schState.admissions.filterStatus = v; schRefreshAdmissions(); }
function schSetAdmissionCampusFilter(v) { schState.admissions.filterCampus = v; const el = document.getElementById('sch-admission-list-results'); if (el) el.innerHTML = schAdmissionListResultsBlock(); }

/* ── Admission Detail (status changes + notes + accept->enrollment) ── */
function schOpenAdmissionDetail(id) { schState.admissions.screen = 'detail'; schState.admissions.appId = id; schRefreshAdmissions(); }
function schBackToAdmissionList() { schState.admissions.screen = 'list'; schState.admissions.appId = null; schRefreshAdmissions(); }
function schAdmissionDetailScreen(a) {
  return `<div class="card"><div class="card-header">
    <div style="display:flex;align-items:center;gap:10px;min-width:0;flex:1"><button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="schBackToAdmissionList()">${t('← Back')}</button><div class="card-title" style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${schEsc(schAdmissionFullName(a))}</div></div>
  </div>
    <div class="card-body" id="sch-admission-detail-body">${schAdmissionDetailBody(a)}</div>
  </div>`;
}
function schAdmissionDetailBody(a) {
  const meta = SCH_ADMISSION_STATUS_META[a.status];
  const statusActions = [['pending','Mark Pending'],['under-review','Mark Under Review'],['accepted','Accept'],['waitlisted','Waitlist'],['rejected','Reject']].filter(([id]) => id !== a.status);
  return `
    <div class="info-row"><span>${t('Status')}</span><span class="status-pill ${meta.cls}">${t(meta.label)}</span></div>
    <div class="info-row"><span>${t('Date of Birth')}</span><span>${a.dob}</span></div>
    <div class="info-row"><span>${t('Gender')}</span><span>${a.gender === 'M' ? t('Male') : t('Female')}</span></div>
    <div class="info-row"><span>${t('Applied For')}</span><span>${schEsc(a.appliedLevel)}</span></div>
    <div class="info-row"><span>${t('Campus')}</span><span>${schEsc(schGetCampus(a.campusId).name)}</span></div>
    <div class="info-row"><span>${t('Submitted')}</span><span>${a.submittedDate}</span></div>
    <div style="margin-top:14px;padding-top:14px;border-top:0.5px solid var(--separator)">
      <div style="font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Guardian Information')}</div>
      <div class="info-row"><span>${t('Name')}</span><span>${schEsc(a.guardianName)}</span></div>
      <div class="info-row"><span>${t('Email')}</span><span>${schEsc(a.guardianEmail)}</span></div>
      <div class="info-row"><span>${t('Phone')}</span><span>${schEsc(a.guardianPhone)}</span></div>
    </div>
    <div style="margin-top:14px;padding-top:14px;border-top:0.5px solid var(--separator)">
      <div style="font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Internal Notes')}</div>
      <textarea id="sch-adm-notes" rows="3" placeholder="${t('Add internal notes about this application...')}">${schEsc(a.notes)}</textarea>
      <button type="button" class="st-btn ghost sm" style="margin-top:8px" onclick="schSaveAdmissionNotes('${a.id}')">${t('Save Notes')}</button>
    </div>
    <div style="margin-top:14px;padding-top:14px;border-top:0.5px solid var(--separator)">
      <div style="font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Change Status')}</div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        ${statusActions.map(([id, label]) => `<button type="button" class="st-btn ghost sm" onclick="schConfirmAdmissionStatusChange('${a.id}','${id}')">${t(label)}</button>`).join('')}
      </div>
      ${a.status === 'accepted' ? `<button type="button" class="st-btn sm" style="margin-top:10px" onclick="schStartEnrollmentFromAdmission('${a.id}')">${t('Start Enrollment')} →</button>` : ''}
    </div>`;
}
function schRefreshAdmissionDetail() {
  const a = schGetAdmission(schState.admissions.appId);
  if (!a) return;
  const el = document.getElementById('sch-admission-detail-body');
  if (el) el.innerHTML = schAdmissionDetailBody(a);
}
function schSaveAdmissionNotes(id) {
  const a = schGetAdmission(id);
  const el = document.getElementById('sch-adm-notes');
  if (!a || !el) return;
  a.notes = el.value.trim();
  schShowToast(t('Notes saved.'));
}
function schConfirmAdmissionStatusChange(id, newStatus) {
  const a = schGetAdmission(id);
  if (!a) return;
  const label = SCH_ADMISSION_STATUS_META[newStatus].label;
  stOpenModal(`<h3 style="margin-bottom:10px">${t('Change status to')} ${t(label)}?</h3>
    <p style="font-size:13px;color:var(--muted);margin-bottom:18px">${schEsc(schAdmissionFullName(a))} — ${t('this will update the application list and dashboard metrics.')}</p>
    <div style="display:flex;gap:10px">
      <button class="st-btn" onclick="schSetAdmissionStatus('${id}','${newStatus}');stCloseModal()">${t('Confirm')}</button>
      <button class="st-btn ghost" onclick="stCloseModal()">${t('Cancel')}</button>
    </div>`);
}
function schSetAdmissionStatus(id, newStatus) {
  const a = schGetAdmission(id);
  if (!a) return;
  const oldStatus = a.status;
  a.status = newStatus;
  schLogAudit('Admissions Changed', 'Admission', schAdmissionFullName(a), oldStatus, newStatus);
  schRefreshAdmissionDetail();
  schShowToast(`${t('Status updated to')} ${t(SCH_ADMISSION_STATUS_META[newStatus].label)}.`);
}
function schStartEnrollmentFromAdmission(id) {
  const a = schGetAdmission(id);
  if (!a) return;
  // Create a real (pending) student record from the accepted applicant so enrollment has a genuine student to attach to.
  const cls = SCHOOL_DATA.classes.find(c => c.campusId === a.campusId && c.level === a.appliedLevel) || SCHOOL_DATA.classes.find(c => c.campusId === a.campusId);
  let guardian = SCHOOL_DATA.guardians.find(g => g.email === a.guardianEmail);
  if (!guardian) {
    guardian = { id:'sg' + Date.now(), name:a.guardianName, email:a.guardianEmail, phone:a.guardianPhone, studentIds:[] };
    SCHOOL_DATA.guardians.push(guardian);
  }
  const newStudent = {
    id:'ss' + Date.now(), studentId:'S' + (3000100 + SCHOOL_DATA.students.length + 1),
    firstName:a.firstName, lastName:a.lastName, dob:a.dob, gender:a.gender,
    classId: cls ? cls.id : SCHOOL_DATA.classes[0].id, campusId:a.campusId, guardianId:guardian.id,
    enrollmentDate:SCH_TODAY, enrollmentStatus:'pending', avgGrade:0, prevTermAvgGrade:0, attendanceRate:100, paymentStatus:'paid', status:'pending',
  };
  SCHOOL_DATA.students.push(newStudent);
  guardian.studentIds.push(newStudent.id);
  schLogAudit('Admissions Changed', 'Admission', schAdmissionFullName(a), 'accepted', 'enrollment started');
  schShowToast(t('Applicant added to Student Enrollment — complete the enrollment there.'));
  schState.enrollment.form = { studentId:newStudent.id, studentSearch:'', classId: newStudent.classId, campusId: newStudent.campusId, academicYear: SCHOOL_DATA.institution.academicYear, enrollmentDate: SCH_TODAY, status:'pending' };
  schState.enrollment.screen = 'form';
  schState.enrollment.error = '';
  authrenGoTo('enrollment');
}

/* ── New Application form ── */
function schOpenAdmissionForm() {
  schState.admissions.form = { firstName:'', lastName:'', dob:'', gender:'M', appliedLevel: SCHOOL_DATA.classes[0].level, campusId:'camp1', guardianName:'', guardianEmail:'', guardianPhone:'' };
  schState.admissions.screen = 'form';
  schState.admissions.error = '';
  schRefreshAdmissions();
}
function schCancelAdmissionForm() { schState.admissions.screen = 'list'; schState.admissions.form = null; schState.admissions.error = ''; schRefreshAdmissions(); }
function schAdmissionFormScreen() {
  const f = schState.admissions.form;
  const err = schState.admissions.error;
  const levels = Array.from(new Set(SCHOOL_DATA.classes.map(c => c.level)));
  return `<div class="card"><div class="card-header"><div class="card-title">${t('New Application')}</div></div>
    <div class="card-body">
      <div style="display:flex;gap:10px">
        <div class="st-field" style="flex:1"><label>${t('First Name')}</label><input id="sch-adm-firstname" value="${schEsc(f.firstName)}"></div>
        <div class="st-field" style="flex:1"><label>${t('Last Name')}</label><input id="sch-adm-lastname" value="${schEsc(f.lastName)}"></div>
      </div>
      <div style="display:flex;gap:10px">
        <div class="st-field" style="flex:1"><label>${t('Date of Birth')}</label><input id="sch-adm-dob" type="date" value="${f.dob}"></div>
        <div class="st-field" style="flex:1"><label>${t('Gender')}</label><select id="sch-adm-gender">
          <option value="M" ${f.gender==='M'?'selected':''}>${t('Male')}</option>
          <option value="F" ${f.gender==='F'?'selected':''}>${t('Female')}</option>
        </select></div>
      </div>
      <div class="st-field"><label>${t('Applying For')}</label><select id="sch-adm-level">
        ${levels.map(l => `<option value="${l}" ${l===f.appliedLevel?'selected':''}>${schEsc(l)}</option>`).join('')}
      </select></div>
      <div class="st-field"><label>${t('Campus')}</label><select id="sch-adm-campus">
        ${SCHOOL_DATA.campuses.map(c => `<option value="${c.id}" ${c.id===f.campusId?'selected':''}>${schEsc(c.name)}</option>`).join('')}
      </select></div>
      <div class="st-field"><label>${t('Guardian Name')}</label><input id="sch-adm-guardianname" value="${schEsc(f.guardianName)}"></div>
      <div class="st-field"><label>${t('Guardian Email')}</label><input id="sch-adm-guardianemail" type="email" value="${schEsc(f.guardianEmail)}"></div>
      <div class="st-field"><label>${t('Guardian Phone')}</label><input id="sch-adm-guardianphone" type="tel" value="${schEsc(f.guardianPhone)}"></div>
      <div style="display:flex;gap:10px">
        <button class="st-btn" onclick="schSaveAdmission()" ${schState.admissions.saving?'disabled':''}>${schState.admissions.saving ? `<span class="gd-spinner"></span>${t('Saving...')}` : t('Submit Application')}</button>
        <button class="st-btn ghost" onclick="schCancelAdmissionForm()" ${schState.admissions.saving?'disabled':''}>${t('Cancel')}</button>
      </div>
      ${err ? `<div class="st-inline-msg err show" style="margin-top:12px">${err}</div>` : ''}
    </div></div>`;
}
function schSaveAdmission() {
  const f = schState.admissions.form;
  const firstName = (document.getElementById('sch-adm-firstname').value || '').trim();
  const lastName = (document.getElementById('sch-adm-lastname').value || '').trim();
  const dob = document.getElementById('sch-adm-dob').value;
  const gender = document.getElementById('sch-adm-gender').value;
  const appliedLevel = document.getElementById('sch-adm-level').value;
  const campusId = document.getElementById('sch-adm-campus').value;
  const guardianName = (document.getElementById('sch-adm-guardianname').value || '').trim();
  const guardianEmail = (document.getElementById('sch-adm-guardianemail').value || '').trim();
  const guardianPhone = (document.getElementById('sch-adm-guardianphone').value || '').trim();
  Object.assign(f, { firstName, lastName, dob, gender, appliedLevel, campusId, guardianName, guardianEmail, guardianPhone });

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  let err = '';
  if (!firstName) err = t("Applicant's first name is required.");
  else if (!lastName) err = t("Applicant's last name is required.");
  else if (!dob) err = t('Date of birth is required.');
  else if (!guardianName) err = t("Guardian's name is required.");
  else if (!guardianEmail || !emailRegex.test(guardianEmail)) err = t('Enter a valid guardian email.');
  else if (!guardianPhone) err = t("Guardian's phone number is required.");

  schState.admissions.error = err;
  if (err) { schRefreshAdmissions(); return; }

  schState.admissions.saving = true;
  schRefreshAdmissions();
  setTimeout(() => {
    const newApp = { id:'sad' + Date.now(), firstName, lastName, dob, gender, appliedLevel, campusId, guardianName, guardianEmail, guardianPhone, submittedDate: SCH_TODAY, status:'pending', notes:'' };
    SCHOOL_DATA.admissions.push(newApp);
    schLogAudit('Admissions Changed', 'Admission', schAdmissionFullName(newApp), '', 'submitted');
    schState.admissions.saving = false;
    schState.admissions.form = null;
    schState.admissions.screen = 'detail';
    schState.admissions.appId = newApp.id;
    schRefreshAdmissions();
    schShowToast(t('Application submitted successfully.'));
  }, 700);
}

/* ══════════════════════════════════════════════════════
   ORIENTATION (section 15)
══════════════════════════════════════════════════════ */
const SCH_ORIENTATION_STATUS_META = { scheduled:{cls:'due',label:'Scheduled'}, completed:{cls:'paid',label:'Completed'}, cancelled:{cls:'overdue',label:'Cancelled'} };
function schGetOrientation(id) { return SCHOOL_DATA.orientations.find(o => o.id === id) || null; }
function schOrientationParticipantName(id) { const a = schGetAdmission(id); return a ? schAdmissionFullName(a) : t('Unknown'); }
function schOrientationView() { return `<div id="sch-orientation-content">${schOrientationBody()}</div>`; }
function schOrientationBody() {
  const s = schState.orientation;
  if (s.screen === 'form') return schOrientationFormScreen();
  if (s.screen === 'detail') { const o = schGetOrientation(s.orId); if (!o) { s.screen = 'list'; return schOrientationBody(); } return schOrientationDetailScreen(o); }
  return schOrientationListScreen();
}
function schRefreshOrientation() { const el = document.getElementById('sch-orientation-content'); if (el) el.innerHTML = schOrientationBody(); }
function schOrientationListScreen() {
  const sorted = SCHOOL_DATA.orientations.slice().sort((a, b) => b.date.localeCompare(a.date));
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Orientation Sessions')}</div><button class="st-btn sm" onclick="schOpenOrientationForm()">+ ${t('Create Orientation Event')}</button></div>
    <div class="card-body">
      ${sorted.length ? sorted.map(o => { const meta = SCH_ORIENTATION_STATUS_META[o.status]; return `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="schOpenOrientationDetail('${o.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();schOpenOrientationDetail('${o.id}')}">
        <span>${schEsc(o.title)}<div style="font-size:11px;color:var(--muted)">${o.date} · ${o.time} · ${schEsc(schGetCampus(o.campusId).name)}</div></span><span class="status-pill ${meta.cls}">${t(meta.label)}</span>
      </div>`; }).join('') : `<div class="gd-empty-mini">${t('No orientation sessions scheduled yet.')}</div>`}
    </div></div>`;
}
function schOpenOrientationDetail(id) { schState.orientation.screen = 'detail'; schState.orientation.orId = id; schState.orientation.addParticipantSearch = ''; schRefreshOrientation(); }
function schBackToOrientationList() { schState.orientation.screen = 'list'; schState.orientation.orId = null; schRefreshOrientation(); }
function schOrientationDetailScreen(o) {
  return `<div class="card"><div class="card-header">
    <div style="display:flex;align-items:center;gap:10px;min-width:0;flex:1"><button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="schBackToOrientationList()">${t('← Back')}</button><div class="card-title" style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${schEsc(o.title)}</div></div>
    <button type="button" class="st-btn ghost sm" onclick="schOpenOrientationForm('${o.id}')">${t('Edit')}</button>
  </div>
    <div class="card-body" id="sch-orientation-detail-body">${schOrientationDetailBody(o)}</div>
  </div>`;
}
function schOrientationDetailBody(o) {
  const meta = SCH_ORIENTATION_STATUS_META[o.status];
  const eligible = SCHOOL_DATA.admissions.filter(a => !o.participantIds.includes(a.id));
  const q = schState.orientation.addParticipantSearch.trim().toLowerCase();
  const results = q ? eligible.filter(a => schAdmissionFullName(a).toLowerCase().includes(q)) : [];
  return `
    <div class="info-row"><span>${t('Status')}</span><span class="status-pill ${meta.cls}">${t(meta.label)}</span></div>
    <div class="info-row"><span>${t('Date & Time')}</span><span>${o.date} · ${o.time}</span></div>
    <div class="info-row"><span>${t('Location')}</span><span>${schEsc(o.location)}</span></div>
    <div class="info-row"><span>${t('Campus')}</span><span>${schEsc(schGetCampus(o.campusId).name)}</span></div>
    ${o.instructions ? `<div style="margin-top:10px;font-size:13px;color:var(--muted2);line-height:1.5">${schEsc(o.instructions)}</div>` : ''}
    <div style="margin-top:14px;padding-top:14px;border-top:0.5px solid var(--separator)">
      <div style="font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Participants')}</div>
      ${o.participantIds.length ? o.participantIds.map(id => `<div class="info-row" style="align-items:center">
        <span>${schEsc(schOrientationParticipantName(id))}</span>
        <span style="display:flex;gap:8px;align-items:center">
          <label style="display:flex;align-items:center;gap:6px;font-size:11.5px;color:var(--muted)"><input type="checkbox" ${o.attended[id]?'checked':''} onchange="schToggleOrientationAttendance('${o.id}','${id}')"> ${t('Attended')}</label>
          <button type="button" class="st-btn ghost sm" onclick="schRemoveOrientationParticipant('${o.id}','${id}')">${t('Remove')}</button>
        </span>
      </div>`).join('') : `<div class="gd-empty-mini">${t('No participants assigned yet.')}</div>`}
      <div style="margin-top:10px">
        <input class="gd-comm-search-input" type="text" placeholder="${t('Search applicants to add...')}" value="${schEsc(schState.orientation.addParticipantSearch)}" oninput="schSetOrientationAddSearch(this.value)">
        <div id="sch-or-add-results">${results.length ? results.map(a => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="schAddOrientationParticipant('${o.id}','${a.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();schAddOrientationParticipant('${o.id}','${a.id}')}">
          <span>${schEsc(schAdmissionFullName(a))}</span><span class="card-action">${t('Add')}</span>
        </div>`).join('') : (q ? `<div class="gd-empty-mini" style="text-align:left;padding:8px 0 0">${t('No applicants match your search.')}</div>` : '')}</div>
      </div>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:14px">
      ${o.status !== 'completed' ? `<button type="button" class="st-btn ghost sm" onclick="schSetOrientationStatus('${o.id}','completed')">${t('Mark Completed')}</button>` : ''}
      ${o.status !== 'cancelled' ? `<button type="button" class="st-btn ghost sm" style="color:var(--red)" onclick="schSetOrientationStatus('${o.id}','cancelled')">${t('Cancel Session')}</button>` : ''}
      ${o.status !== 'scheduled' ? `<button type="button" class="st-btn ghost sm" onclick="schSetOrientationStatus('${o.id}','scheduled')">${t('Reopen')}</button>` : ''}
    </div>`;
}
function schRefreshOrientationDetail() { const o = schGetOrientation(schState.orientation.orId); if (!o) return; const el = document.getElementById('sch-orientation-detail-body'); if (el) el.innerHTML = schOrientationDetailBody(o); }
function schSetOrientationAddSearch(v) { schState.orientation.addParticipantSearch = v; schRefreshOrientationDetail(); }
function schAddOrientationParticipant(orId, admissionId) {
  const o = schGetOrientation(orId);
  if (!o || o.participantIds.includes(admissionId)) return;
  o.participantIds.push(admissionId);
  schState.orientation.addParticipantSearch = '';
  schRefreshOrientationDetail();
  schShowToast(t('Participant added.'));
}
function schRemoveOrientationParticipant(orId, admissionId) {
  const o = schGetOrientation(orId);
  if (!o) return;
  o.participantIds = o.participantIds.filter(id => id !== admissionId);
  delete o.attended[admissionId];
  schRefreshOrientationDetail();
  schShowToast(t('Participant removed.'));
}
function schToggleOrientationAttendance(orId, admissionId) {
  const o = schGetOrientation(orId);
  if (!o) return;
  o.attended[admissionId] = !o.attended[admissionId];
  schShowToast(o.attended[admissionId] ? t('Marked as attended.') : t('Attendance unmarked.'));
}
function schSetOrientationStatus(orId, status) {
  const o = schGetOrientation(orId);
  if (!o) return;
  o.status = status;
  schRefreshOrientationDetail();
  schShowToast(`${t('Status updated to')} ${t(SCH_ORIENTATION_STATUS_META[status].label)}.`);
}

/* ── Create / Edit Orientation form ── */
function schOpenOrientationForm(id) {
  if (id) {
    const o = schGetOrientation(id);
    if (!o) return;
    schState.orientation.form = { mode:'edit', id:o.id, title:o.title, date:o.date, time:o.time, location:o.location, campusId:o.campusId, instructions:o.instructions };
  } else {
    schState.orientation.form = { mode:'create', id:null, title:'', date:'', time:'', location:'', campusId:'camp1', instructions:'' };
  }
  schState.orientation.screen = 'form';
  schState.orientation.error = '';
  schRefreshOrientation();
}
function schCancelOrientationForm() {
  const wasEdit = schState.orientation.form && schState.orientation.form.mode === 'edit';
  const editedId = schState.orientation.form ? schState.orientation.form.id : null;
  schState.orientation.form = null;
  schState.orientation.error = '';
  if (wasEdit) { schState.orientation.screen = 'detail'; schState.orientation.orId = editedId; } else { schState.orientation.screen = 'list'; }
  schRefreshOrientation();
}
function schOrientationFormScreen() {
  const f = schState.orientation.form;
  const err = schState.orientation.error;
  return `<div class="card"><div class="card-header"><div class="card-title">${f.mode==='edit'?t('Edit Orientation Event'):t('Create Orientation Event')}</div></div>
    <div class="card-body">
      <div class="st-field"><label>${t('Title')}</label><input id="sch-or-title" value="${schEsc(f.title)}"></div>
      <div style="display:flex;gap:10px">
        <div class="st-field" style="flex:1"><label>${t('Date')}</label><input id="sch-or-date" type="date" value="${f.date}"></div>
        <div class="st-field" style="flex:1"><label>${t('Time')}</label><input id="sch-or-time" type="time" value="${f.time}"></div>
      </div>
      <div class="st-field"><label>${t('Location')}</label><input id="sch-or-location" value="${schEsc(f.location)}"></div>
      <div class="st-field"><label>${t('Campus')}</label><select id="sch-or-campus">
        ${SCHOOL_DATA.campuses.map(c => `<option value="${c.id}" ${c.id===f.campusId?'selected':''}>${schEsc(c.name)}</option>`).join('')}
      </select></div>
      <div class="st-field"><label>${t('Instructions')}</label><textarea id="sch-or-instructions" rows="3">${schEsc(f.instructions)}</textarea></div>
      <div style="display:flex;gap:10px">
        <button class="st-btn" onclick="schSaveOrientation()">${f.mode==='edit'?t('Save Changes'):t('Create Event')}</button>
        <button class="st-btn ghost" onclick="schCancelOrientationForm()">${t('Cancel')}</button>
      </div>
      ${err ? `<div class="st-inline-msg err show" style="margin-top:12px">${err}</div>` : ''}
    </div></div>`;
}
function schSaveOrientation() {
  const f = schState.orientation.form;
  const title = (document.getElementById('sch-or-title').value || '').trim();
  const date = document.getElementById('sch-or-date').value;
  const time = document.getElementById('sch-or-time').value;
  const location = (document.getElementById('sch-or-location').value || '').trim();
  const campusId = document.getElementById('sch-or-campus').value;
  const instructions = (document.getElementById('sch-or-instructions').value || '').trim();
  Object.assign(f, { title, date, time, location, campusId, instructions });

  let err = '';
  if (!title) err = t('Title is required.');
  else if (!date) err = t('Select a date.');
  else if (!time) err = t('Select a time.');
  else if (!location) err = t('Location is required.');

  schState.orientation.error = err;
  if (err) { schRefreshOrientation(); return; }

  if (f.mode === 'edit') {
    const o = schGetOrientation(f.id);
    Object.assign(o, { title, date, time, location, campusId, instructions });
    schState.orientation.screen = 'detail';
    schState.orientation.orId = o.id;
    schShowToast(t('Orientation event updated successfully.'));
  } else {
    const newOr = { id:'sor' + Date.now(), title, date, time, location, campusId, instructions, status:'scheduled', participantIds:[], attended:{} };
    SCHOOL_DATA.orientations.push(newOr);
    schState.orientation.screen = 'detail';
    schState.orientation.orId = newOr.id;
    schShowToast(t('Orientation event created successfully.'));
  }
  schState.orientation.form = null;
  schRefreshOrientation();
}

/* ══════════════════════════════════════════════════════
   SCHOOL PAYMENTS (section 16) — overview + drill-in to receipts
══════════════════════════════════════════════════════ */
const SCH_PAYMENT_STATUS_META = { paid:{cls:'paid',label:'Paid'}, pending:{cls:'partial',label:'Pending'}, overdue:{cls:'overdue',label:'Overdue'} };
function schPaymentsView() { return `<div id="sch-payments-content">${schPaymentsBody()}</div>`; }
function schPaymentsBody() {
  const s = schState.payments;
  if (s.screen === 'receipt') return schReceiptScreen();
  if (s.screen === 'studentHistory') { const st = schGetStudent(s.studentId); if (!st) { s.screen = 'overview'; return schPaymentsBody(); } return schStudentPaymentHistoryScreen(st); }
  return schPaymentsOverviewScreen();
}
function schRefreshPayments() { const el = document.getElementById('sch-payments-content'); if (el) el.innerHTML = schPaymentsBody(); }
function schPaymentsOverviewScreen() {
  const collected = SCHOOL_DATA.payments.filter(p => p.status === 'paid').reduce((s, p) => s + p.amount, 0);
  const outstanding = SCHOOL_DATA.payments.filter(p => p.status === 'pending').reduce((s, p) => s + p.amount, 0);
  const overdue = SCHOOL_DATA.payments.filter(p => p.status === 'overdue').reduce((s, p) => s + p.amount, 0);
  const recent = SCHOOL_DATA.payments.filter(p => p.status === 'paid').slice().sort((a, b) => b.date.localeCompare(a.date)).slice(0, 6);
  const byMonth = {};
  SCHOOL_DATA.payments.filter(p => p.status === 'paid').forEach(p => { const m = p.date.slice(0,7); byMonth[m] = (byMonth[m]||0) + p.amount; });
  return `
    <div class="gd-stat-row">
      <div class="stat-card"><div class="stat-label">${t('Total Collected')}</div><div class="stat-val" style="font-size:16px">${schCurrency(collected)}</div><div class="stat-icon green">${aIcon('dollar-sign')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Outstanding')}</div><div class="stat-val" style="font-size:16px">${schCurrency(outstanding)}</div><div class="stat-icon yellow">${aIcon('clock')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Overdue')}</div><div class="stat-val" style="font-size:16px">${schCurrency(overdue)}</div><div class="stat-icon red">${aIcon('x-circle')}</div></div>
    </div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Collection Trend')}</div></div>
      <div class="card-body">${Object.keys(byMonth).sort().map(m => `<div class="info-row"><span>${m}</span><span style="color:var(--green)">${schCurrency(byMonth[m])}</span></div>`).join('')}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Recent Payments')}</div><div class="card-action" onclick="authrenGoTo('payment-records')">${t('View All')} →</div></div>
      <div class="card-body">${recent.length ? recent.map(p => { const st = schGetStudent(p.studentId); return `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="schOpenReceipt('${p.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();schOpenReceipt('${p.id}')}"><span>${st ? schEsc(schStudentFullName(st)) : '—'}<div style="font-size:11px;color:var(--muted)">${schEsc(p.description)} · ${p.date}</div></span><span>${schCurrency(p.amount)}</span></div>`; }).join('') : `<div class="gd-empty-mini">${t('No payments recorded yet.')}</div>`}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Student Payment Status')}</div></div>
      <div class="card-body">${SCHOOL_DATA.students.map(s => { const meta = { paid:{cls:'paid',label:'Paid'}, partial:{cls:'partial',label:'Partial'}, overdue:{cls:'overdue',label:'Overdue'} }[s.paymentStatus]; return `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="schOpenStudentPaymentHistory('${s.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();schOpenStudentPaymentHistory('${s.id}')}"><span>${schEsc(schStudentFullName(s))}</span><span class="status-pill ${meta.cls}">${t(meta.label)}</span></div>`; }).join('')}</div></div>`;
}
function schOpenStudentPaymentHistory(studentId) { schState.payments.screen = 'studentHistory'; schState.payments.studentId = studentId; schRefreshPayments(); }
function schBackToPaymentsOverview() { schState.payments.screen = 'overview'; schState.payments.studentId = null; schRefreshPayments(); }
function schStudentPaymentHistoryScreen(student) {
  const records = SCHOOL_DATA.payments.filter(p => p.studentId === student.id).sort((a, b) => b.date.localeCompare(a.date));
  return `<div class="card"><div class="card-header">
    <div style="display:flex;align-items:center;gap:10px"><button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="schBackToPaymentsOverview()">${t('← Back')}</button><div class="card-title">${schEsc(schStudentFullName(student))}</div></div>
  </div>
    <div class="card-body">
      ${records.map(p => { const meta = SCH_PAYMENT_STATUS_META[p.status]; return `<div class="info-row" style="cursor:${p.status==='paid'?'pointer':'default'}" ${p.status==='paid'?`role="button" tabindex="0" onclick="schOpenReceipt('${p.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();schOpenReceipt('${p.id}')}"`:''}>
        <span>${schEsc(p.description)}<div style="font-size:11px;color:var(--muted)">${p.date}${p.method?' · '+schEsc(p.method):''}</div></span>
        <span style="text-align:right">${schCurrency(p.amount)}<div style="margin-top:4px"><span class="status-pill ${meta.cls}">${t(meta.label)}</span></div></span>
      </div>`; }).join('') || `<div class="gd-empty-mini">${t('No payment records for this student.')}</div>`}
    </div></div>`;
}
function schOpenReceipt(paymentId) {
  schState.payments.screen = 'receipt';
  schState.payments.paymentId = paymentId;
  const el = document.getElementById('sch-payments-content');
  if (el) el.innerHTML = schReceiptScreen();
}
function schBackFromReceipt() { schState.payments.screen = schState.payments.studentId ? 'studentHistory' : 'overview'; schState.payments.paymentId = null; schRefreshPayments(); }
function schReceiptScreen() {
  const p = SCHOOL_DATA.payments.find(x => x.id === schState.payments.paymentId);
  if (!p || p.status !== 'paid') return schPaymentsBody();
  const student = schGetStudent(p.studentId);
  const cls = student ? schGetClass(student.classId) : null;
  return `<div class="card">
    <div class="card-header">
      <div style="display:flex;align-items:center;gap:10px"><button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="schBackFromReceipt()">${t('← Back')}</button><div class="card-title">${t('Receipt')}</div></div>
      <button type="button" class="st-btn ghost sm" onclick="window.print()">${aIcon('printer')} ${t('Print')}</button>
    </div>
    <div class="card-body">
      <div style="text-align:center;padding-bottom:16px;margin-bottom:16px;border-bottom:0.5px dashed var(--separator)">
        ${SCHOOL_DATA.settings.logoDataUrl ? `<img src="${SCHOOL_DATA.settings.logoDataUrl}" alt="" style="width:48px;height:48px;border-radius:10px;object-fit:cover;margin-bottom:8px">` : ''}
        <div style="font-weight:800;font-size:15px">${schEsc(SCHOOL_DATA.institution.name)}</div>
      </div>
      <div class="info-row"><span>${t('Reference')}</span><span style="font-family:monospace">${schEsc(p.reference)}</span></div>
      <div class="info-row"><span>${t('Date')}</span><span>${p.date}</span></div>
      <div class="info-row"><span>${t('Student')}</span><span>${student ? schEsc(schStudentFullName(student)) : '—'}</span></div>
      <div class="info-row"><span>${t('Class')}</span><span>${cls ? schEsc(cls.name) : '—'}</span></div>
      <div class="info-row"><span>${t('Campus')}</span><span>${schEsc(schGetCampus(p.campusId).name)}</span></div>
      <div class="info-row"><span>${t('Description')}</span><span>${schEsc(p.description)}</span></div>
      <div class="info-row"><span>${t('Payment Method')}</span><span>${schEsc(p.method)}</span></div>
      <div class="info-row" style="border-top:0.5px solid var(--separator);margin-top:10px;padding-top:10px"><span style="font-weight:700">${t('Amount Paid')}</span><span style="font-weight:700;font-size:15px">${schCurrency(p.amount)}</span></div>
    </div></div>`;
}

/* ══════════════════════════════════════════════════════
   PAYMENT RECORDS (section 17) — searchable ledger
══════════════════════════════════════════════════════ */
function schPaymentRecordsView() { return `<div id="sch-payrec-content">${schPaymentRecordsBody()}</div>`; }
function schFilteredPaymentRecords() {
  const s = schState.paymentRecords;
  let list = SCHOOL_DATA.payments.slice();
  if (s.filterCampus !== 'all') list = list.filter(p => p.campusId === s.filterCampus);
  if (s.filterStatus !== 'all') list = list.filter(p => p.status === s.filterStatus);
  if (s.filterMethod !== 'all') list = list.filter(p => p.method === s.filterMethod);
  if (s.minAmount !== '') list = list.filter(p => p.amount >= Number(s.minAmount));
  if (s.maxAmount !== '') list = list.filter(p => p.amount <= Number(s.maxAmount));
  const q = s.search.trim().toLowerCase();
  if (q) list = list.filter(p => { const st = schGetStudent(p.studentId); return st && schStudentFullName(st).toLowerCase().includes(q); });
  return list.sort((a, b) => b.date.localeCompare(a.date));
}
function schPaymentRecordsBody() {
  const s = schState.paymentRecords;
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Payment Records')}</div><button type="button" class="st-btn ghost sm" onclick="window.print()">${aIcon('printer')} ${t('Export')}</button></div>
    <div class="card-body">
      <input class="gd-comm-search-input" type="text" placeholder="${t('Search by student name...')}" value="${schEsc(s.search)}" oninput="schSetPayRecSearch(this.value)">
      <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:10px">
        <select onchange="schSetPayRecCampus(this.value)" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
          <option value="all" ${s.filterCampus==='all'?'selected':''}>${t('All Campuses')}</option>
          ${SCHOOL_DATA.campuses.map(c => `<option value="${c.id}" ${c.id===s.filterCampus?'selected':''}>${schEsc(c.name)}</option>`).join('')}
        </select>
        <select onchange="schSetPayRecStatus(this.value)" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
          <option value="all" ${s.filterStatus==='all'?'selected':''}>${t('All Statuses')}</option>
          <option value="paid" ${s.filterStatus==='paid'?'selected':''}>${t('Paid')}</option>
          <option value="pending" ${s.filterStatus==='pending'?'selected':''}>${t('Pending')}</option>
          <option value="overdue" ${s.filterStatus==='overdue'?'selected':''}>${t('Overdue')}</option>
        </select>
        <select onchange="schSetPayRecMethod(this.value)" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
          <option value="all" ${s.filterMethod==='all'?'selected':''}>${t('All Methods')}</option>
          ${SCH_PAYMENT_METHODS.map(m => `<option value="${m}" ${m===s.filterMethod?'selected':''}>${schEsc(m)}</option>`).join('')}
        </select>
      </div>
      <div style="display:flex;gap:10px;margin-top:10px;align-items:center">
        <input id="sch-payrec-min" type="number" placeholder="${t('Min amount')}" value="${s.minAmount}" oninput="schSetPayRecRange()" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px;width:110px">
        <span style="color:var(--muted);font-size:12px">${t('to')}</span>
        <input id="sch-payrec-max" type="number" placeholder="${t('Max amount')}" value="${s.maxAmount}" oninput="schSetPayRecRange()" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px;width:110px">
      </div>
    </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Records')}</div><span style="font-size:12px;color:var(--muted)" id="sch-payrec-count">${schFilteredPaymentRecords().length} ${t('of')} ${SCHOOL_DATA.payments.length}</span></div>
      <div class="card-body" id="sch-payrec-results">${schPaymentRecordsResultsBlock()}</div></div>`;
}
function schPaymentRecordsResultsBlock() {
  const list = schFilteredPaymentRecords();
  if (!list.length) return `<div class="gd-empty-mini">${t('No payment records match your filters.')}</div>`;
  return list.map(p => { const st = schGetStudent(p.studentId); const g = st ? schGetGuardian(st.guardianId) : null; const meta = SCH_PAYMENT_STATUS_META[p.status]; return `<div class="info-row" style="cursor:${p.status==='paid'?'pointer':'default'}" ${p.status==='paid'?`role="button" tabindex="0" onclick="schOpenReceiptFromRecords('${p.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();schOpenReceiptFromRecords('${p.id}')}"`:''}>
    <span>${st ? schEsc(schStudentFullName(st)) : '—'}<div style="font-size:11px;color:var(--muted)">${g?schEsc(g.name)+' · ':''}${schEsc(p.description)} · ${p.date} · ${schEsc(schGetCampus(p.campusId).name)}</div></span>
    <span style="text-align:right">${schCurrency(p.amount)}<div style="margin-top:4px"><span class="status-pill ${meta.cls}">${t(meta.label)}</span></div></span>
  </div>`; }).join('');
}
function schOpenReceiptFromRecords(paymentId) {
  schState.payments.paymentId = paymentId;
  schState.payments.studentId = null;
  authrenGoTo('payments');
  schState.payments.screen = 'receipt';
  const el = document.getElementById('sch-payments-content');
  if (el) el.innerHTML = schReceiptScreen();
}
function schRefreshPayRecResults() {
  const el = document.getElementById('sch-payrec-results');
  if (el) el.innerHTML = schPaymentRecordsResultsBlock();
  const countEl = document.getElementById('sch-payrec-count');
  if (countEl) countEl.textContent = `${schFilteredPaymentRecords().length} ${t('of')} ${SCHOOL_DATA.payments.length}`;
}
function schSetPayRecSearch(v) { schState.paymentRecords.search = v; schRefreshPayRecResults(); }
function schSetPayRecCampus(v) { schState.paymentRecords.filterCampus = v; schRefreshPayRecResults(); }
function schSetPayRecStatus(v) { schState.paymentRecords.filterStatus = v; schRefreshPayRecResults(); }
function schSetPayRecMethod(v) { schState.paymentRecords.filterMethod = v; schRefreshPayRecResults(); }
function schSetPayRecRange() {
  schState.paymentRecords.minAmount = document.getElementById('sch-payrec-min').value;
  schState.paymentRecords.maxAmount = document.getElementById('sch-payrec-max').value;
  schRefreshPayRecResults();
}

/* ══════════════════════════════════════════════════════
   RECLAMATION MANAGEMENT (section 18)
   No submitter identity is collected or displayed anywhere — only a
   reference ID — for genuinely anonymous complaints.
══════════════════════════════════════════════════════ */
const SCH_RC_STATUS_META = { open:{cls:'due',label:'Open'}, 'in-progress':{cls:'awaiting',label:'In Progress'}, resolved:{cls:'paid',label:'Resolved'}, archived:{cls:'resolved',label:'Archived'} };
function schGetReclamation(id) { return SCHOOL_DATA.reclamations.find(r => r.id === id) || null; }
function schAnonymityBanner() {
  return `<div style="background:rgba(203,213,225,0.1);border:1px solid rgba(203,213,225,0.3);border-radius:10px;padding:10px 12px;font-size:11.5px;color:var(--muted2);margin-bottom:14px">${aIcon('eye-off')} ${t('This system is fully anonymous. No submitter identity is collected or displayed — only an anonymous reference ID.')}</div>`;
}
function schReclamationsView() { return `<div id="sch-reclamations-content">${schReclamationsBody()}</div>`; }
function schReclamationsBody() {
  const s = schState.reclamations;
  if (s.screen === 'detail') { const r = schGetReclamation(s.rcId); if (!r) { s.screen = 'list'; return schReclamationsBody(); } return schReclamationDetailScreen(r); }
  return schReclamationListScreen();
}
function schRefreshReclamations() { const el = document.getElementById('sch-reclamations-content'); if (el) el.innerHTML = schReclamationsBody(); }
function schFilteredReclamations() {
  const s = schState.reclamations;
  let list = SCHOOL_DATA.reclamations.slice();
  if (s.filterStatus !== 'all') list = list.filter(r => r.status === s.filterStatus);
  if (s.filterCampus !== 'all') list = list.filter(r => r.campusId === s.filterCampus);
  return list.sort((a, b) => b.submittedDate.localeCompare(a.submittedDate));
}
function schReclamationListScreen() {
  const s = schState.reclamations;
  const statuses = [['all','All'],['open','Open'],['in-progress','In Progress'],['resolved','Resolved'],['archived','Archived']];
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Reclamation Management')}</div></div>
    <div class="card-body">
      ${schAnonymityBanner()}
      <div class="gd-comm-filter-row">${statuses.map(([id,label]) => `<div class="gd-comm-filter-chip${s.filterStatus===id?' active':''}" onclick="schSetRcStatusFilter('${id}')">${t(label)}</div>`).join('')}</div>
      <select onchange="schSetRcCampusFilter(this.value)" style="margin-top:10px;background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
        <option value="all" ${s.filterCampus==='all'?'selected':''}>${t('All Campuses')}</option>
        ${SCHOOL_DATA.campuses.map(c => `<option value="${c.id}" ${c.id===s.filterCampus?'selected':''}>${schEsc(c.name)}</option>`).join('')}
      </select>
    </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Submissions')}</div></div>
      <div class="card-body" id="sch-rc-list-results">${schReclamationListResultsBlock()}</div></div>`;
}
function schReclamationListResultsBlock() {
  const list = schFilteredReclamations();
  if (!list.length) return `<div class="gd-empty-mini">${t('No reclamations match your filters.')}</div>`;
  return list.map(r => { const sm = SCH_RC_STATUS_META[r.status]; return `<div class="info-row" style="cursor:pointer;align-items:flex-start" role="button" tabindex="0" onclick="schOpenReclamationDetail('${r.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();schOpenReclamationDetail('${r.id}')}">
    <span>${schEsc(r.subject)}<div style="font-size:11px;color:var(--muted);margin-top:2px">${schEsc(r.referenceId)} · ${schEsc(r.category)} · ${schEsc(schGetCampus(r.campusId).name)} · ${r.submittedDate}</div></span>
    <span class="status-pill ${sm.cls}">${t(sm.label)}</span>
  </div>`; }).join('');
}
function schSetRcStatusFilter(v) { schState.reclamations.filterStatus = v; schRefreshReclamations(); }
function schSetRcCampusFilter(v) { schState.reclamations.filterCampus = v; const el = document.getElementById('sch-rc-list-results'); if (el) el.innerHTML = schReclamationListResultsBlock(); }
function schOpenReclamationDetail(id) { schState.reclamations.screen = 'detail'; schState.reclamations.rcId = id; schRefreshReclamations(); }
function schBackToReclamationList() { schState.reclamations.screen = 'list'; schState.reclamations.rcId = null; schRefreshReclamations(); }
function schReclamationDetailScreen(r) {
  return `<div class="card"><div class="card-header">
    <div style="display:flex;align-items:center;gap:10px;min-width:0;flex:1"><button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="schBackToReclamationList()">${t('← Back')}</button><div class="card-title" style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${schEsc(r.referenceId)}</div></div>
  </div>
    <div class="card-body" id="sch-rc-detail-body">${schReclamationDetailBody(r)}</div>
  </div>`;
}
function schReclamationDetailBody(r) {
  const sm = SCH_RC_STATUS_META[r.status];
  return `
    ${schAnonymityBanner()}
    <div class="info-row"><span>${t('Category')}</span><span>${schEsc(r.category)}</span></div>
    <div class="info-row"><span>${t('Campus')}</span><span>${schEsc(schGetCampus(r.campusId).name)}</span></div>
    <div class="info-row"><span>${t('Priority')}</span><span class="status-pill ${r.priority==='high'?'overdue':r.priority==='medium'?'awaiting':'resolved'}">${t(r.priority.charAt(0).toUpperCase()+r.priority.slice(1))}</span></div>
    <div class="info-row"><span>${t('Submitted')}</span><span>${r.submittedDate}</span></div>
    <div class="info-row"><span>${t('Status')}</span><span class="status-pill ${sm.cls}">${t(sm.label)}</span></div>
    <div style="margin-top:14px;padding-top:14px;border-top:0.5px solid var(--separator)">
      <div style="font-weight:700;font-size:14px;margin-bottom:6px">${schEsc(r.subject)}</div>
      <div style="font-size:13px;line-height:1.6;color:var(--muted2)">${schEsc(r.description)}</div>
    </div>
    <div style="margin-top:14px;padding-top:14px;border-top:0.5px solid var(--separator)">
      <div style="font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Change Status')}</div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        ${['open','in-progress','resolved','archived'].filter(id => id !== r.status).map(id => `<button type="button" class="st-btn ghost sm" onclick="schSetReclamationStatus('${r.id}','${id}')">${t('Mark')} ${t(SCH_RC_STATUS_META[id].label)}</button>`).join('')}
      </div>
    </div>
    <div style="margin-top:14px;padding-top:14px;border-top:0.5px solid var(--separator)">
      <div style="font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Internal Notes')}</div>
      <textarea id="sch-rc-notes" rows="3" placeholder="${t('Add internal notes (not visible to the submitter)...')}">${schEsc(r.internalNotes)}</textarea>
      <button type="button" class="st-btn ghost sm" style="margin-top:8px" onclick="schSaveReclamationNotes('${r.id}')">${t('Save Notes')}</button>
    </div>`;
}
function schRefreshReclamationDetail() { const r = schGetReclamation(schState.reclamations.rcId); if (!r) return; const el = document.getElementById('sch-rc-detail-body'); if (el) el.innerHTML = schReclamationDetailBody(r); }
function schSetReclamationStatus(id, status) {
  const r = schGetReclamation(id);
  if (!r) return;
  r.status = status;
  schLogAudit('Reclamation Status Changed', 'Reclamation', r.referenceId, '', status);
  schRefreshReclamationDetail();
  schShowToast(`${t('Status updated to')} ${t(SCH_RC_STATUS_META[status].label)}.`);
}
function schSaveReclamationNotes(id) {
  const r = schGetReclamation(id);
  const el = document.getElementById('sch-rc-notes');
  if (!r || !el) return;
  r.internalNotes = el.value.trim();
  schShowToast(t('Notes saved.'));
}

/* ══════════════════════════════════════════════════════
   BULK DATA IMPORT (section 20) — full 7-step wizard
   Step 1: Select Type · Step 2: Upload (real File API/CSV) ·
   Step 3: Mapping · Step 4: Validation · Step 5: Duplicate Review ·
   Step 6: Preview · Step 7: Import (genuinely mutates SCHOOL_DATA)
══════════════════════════════════════════════════════ */
const SCH_IMPORT_DATA_TYPES = [ ['students','Students'], ['teachers','Teachers'], ['guardians','Guardians'], ['classes','Classes'] ];
const SCH_IMPORT_FIELDS = {
  students: [ { id:'firstName', label:'First Name', required:true }, { id:'lastName', label:'Last Name', required:true }, { id:'dob', label:'Date of Birth', required:true }, { id:'gender', label:'Gender', required:true }, { id:'className', label:'Class', required:true }, { id:'guardianEmail', label:'Guardian Email', required:true } ],
  teachers: [ { id:'name', label:'Full Name', required:true }, { id:'email', label:'Email', required:true }, { id:'phone', label:'Phone', required:false }, { id:'subject', label:'Subject', required:true } ],
  guardians: [ { id:'name', label:'Full Name', required:true }, { id:'email', label:'Email', required:true }, { id:'phone', label:'Phone', required:false } ],
  classes: [ { id:'name', label:'Class Name', required:true }, { id:'level', label:'Level', required:true }, { id:'capacity', label:'Capacity', required:true } ],
};
function schParseCSV(text) {
  const lines = text.split(/\r\n|\n/).filter(l => l.trim() !== '');
  const parseLine = (line) => {
    const result = [];
    let cur = '', inQuotes = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (inQuotes) { if (ch === '"') { if (line[i + 1] === '"') { cur += '"'; i++; } else inQuotes = false; } else cur += ch; }
      else { if (ch === '"') inQuotes = true; else if (ch === ',') { result.push(cur); cur = ''; } else cur += ch; }
    }
    result.push(cur);
    return result.map(x => x.trim());
  };
  if (!lines.length) return { headers: [], rows: [] };
  const headers = parseLine(lines[0]);
  const rows = lines.slice(1).map(parseLine);
  return { headers, rows };
}
function schGuessMapping(headers, dataType) {
  const mapping = {};
  const normalize = s => s.toLowerCase().replace(/[^a-z]/g, '');
  SCH_IMPORT_FIELDS[dataType].forEach(f => {
    const target = normalize(f.id);
    const idx = headers.findIndex(h => normalize(h) === target || normalize(h).includes(target));
    if (idx !== -1) mapping[f.id] = idx;
  });
  return mapping;
}
function schImportView() { return `<div id="sch-import-content">${schImportBody()}</div>`; }
function schImportBody() {
  const i = schState.import;
  if (i.step === 1) return schImportStep1();
  if (i.step === 2) return schImportStep2();
  if (i.step === 3) return schImportStep3();
  if (i.step === 4) return schImportStep4();
  if (i.step === 5) return schImportStep5();
  if (i.step === 6) return schImportStep6();
  return schImportStep7();
}
function schRefreshImport() { const el = document.getElementById('sch-import-content'); if (el) el.innerHTML = schImportBody(); }
function schImportStepper() {
  const i = schState.import;
  const labels = ['Type','Upload','Mapping','Validation','Duplicates','Preview','Import'];
  return `<div style="display:flex;gap:4px;margin-bottom:16px;flex-wrap:wrap">${labels.map((l,idx) => `<div style="font-size:10.5px;padding:4px 8px;border-radius:6px;background:${idx+1===i.step?'var(--accent)':'var(--surface2)'};color:${idx+1===i.step?'#fff':'var(--muted)'}">${idx+1}. ${t(l)}</div>`).join('')}</div>`;
}

function schImportStep1() {
  const i = schState.import;
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Bulk Data Import')}</div></div>
    <div class="card-body">${schImportStepper()}
      <div style="font-size:12.5px;font-weight:600;margin-bottom:8px">${t('What are you importing?')}</div>
      ${SCH_IMPORT_DATA_TYPES.map(([id,label]) => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="schSetImportDataType('${id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();schSetImportDataType('${id}')}"><span><input type="radio" name="sch-imp-type" ${i.dataType===id?'checked':''} style="margin-right:8px;pointer-events:none">${t(label)}</span></div>`).join('')}
      <button class="st-btn" style="margin-top:14px" onclick="schImportGoto(2)">${t('Next: Upload')} →</button>
    </div></div>`;
}
function schSetImportDataType(id) { schState.import.dataType = id; schRefreshImport(); }
function schImportGoto(step) { schState.import.step = step; schState.import.error = ''; schRefreshImport(); }

function schImportStep2() {
  const i = schState.import;
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Upload File')}</div></div>
    <div class="card-body">${schImportStepper()}
      <div style="font-size:11.5px;color:var(--muted);margin-bottom:10px">${t('Importing')}: ${t(SCH_IMPORT_DATA_TYPES.find(x=>x[0]===i.dataType)[1])}</div>
      <input type="file" id="sch-imp-file" accept=".csv" onchange="schHandleImportFile(this)">
      ${i.fileName ? `<div class="info-row" style="margin-top:10px"><span>${schEsc(i.fileName)}</span><span style="color:var(--muted)">${i.rawRows.length} ${t('rows')}</span></div>` : ''}
      <div style="display:flex;gap:10px;margin-top:14px">
        <button class="st-btn ghost" onclick="schImportGoto(1)">${t('← Back')}</button>
        <button class="st-btn" onclick="schImportGoto(3)" ${!i.fileName?'disabled':''}>${t('Next: Mapping')} →</button>
      </div>
      ${i.error ? `<div class="st-inline-msg err show" style="margin-top:12px">${i.error}</div>` : ''}
    </div></div>`;
}
function schHandleImportFile(input) {
  const file = input.files && input.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = function(e) {
    const { headers, rows } = schParseCSV(e.target.result);
    if (!headers.length) { schState.import.error = t('Could not read any data from this file.'); schRefreshImport(); return; }
    schState.import.fileName = file.name;
    schState.import.rawHeaders = headers;
    schState.import.rawRows = rows;
    schState.import.mapping = schGuessMapping(headers, schState.import.dataType);
    schState.import.error = '';
    schRefreshImport();
  };
  reader.onerror = function() { schState.import.error = t('Could not read this file. Please try again.'); schRefreshImport(); };
  reader.readAsText(file);
}

function schImportStep3() {
  const i = schState.import;
  const fields = SCH_IMPORT_FIELDS[i.dataType];
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Data Mapping')}</div></div>
    <div class="card-body">${schImportStepper()}
      <div style="font-size:11.5px;color:var(--muted);margin-bottom:10px">${t('Match each Authren field to a column from your file.')}</div>
      ${fields.map(f => `<div class="st-field"><label>${t(f.label)}${f.required?' *':''}</label><select id="sch-imp-map-${f.id}">
        <option value="-1">${t('— Not mapped —')}</option>
        ${i.rawHeaders.map((h, idx) => `<option value="${idx}" ${i.mapping[f.id]===idx?'selected':''}>${schEsc(h)}</option>`).join('')}
      </select></div>`).join('')}
      <div style="display:flex;gap:10px;margin-top:14px">
        <button class="st-btn ghost" onclick="schImportGoto(2)">${t('← Back')}</button>
        <button class="st-btn" onclick="schImportRunValidation()">${t('Next: Validate')} →</button>
      </div>
      ${i.error ? `<div class="st-inline-msg err show" style="margin-top:12px">${i.error}</div>` : ''}
    </div></div>`;
}
function schImportRunValidation() {
  const i = schState.import;
  const fields = SCH_IMPORT_FIELDS[i.dataType];
  const mapping = {};
  fields.forEach(f => { const v = parseInt(document.getElementById('sch-imp-map-' + f.id).value, 10); if (v >= 0) mapping[f.id] = v; });
  const missingRequired = fields.filter(f => f.required && mapping[f.id] === undefined);
  if (missingRequired.length) { i.error = t('Map all required fields: ') + missingRequired.map(f => t(f.label)).join(', '); schRefreshImport(); return; }
  i.mapping = mapping;
  i.error = '';

  i.validationRows = i.rawRows.map((row, idx) => {
    const data = {};
    fields.forEach(f => { data[f.id] = mapping[f.id] !== undefined ? row[mapping[f.id]] : ''; });
    const errors = [];
    fields.forEach(f => { if (f.required && !data[f.id]) errors.push(t('Missing') + ' ' + t(f.label)); });
    if (i.dataType === 'students') {
      if (data.dob && !/^\d{4}-\d{2}-\d{2}$/.test(data.dob)) errors.push(t('Invalid date format (expected YYYY-MM-DD)'));
      if (data.gender && !['M','F'].includes(data.gender.toUpperCase())) errors.push(t('Invalid gender (expected M or F)'));
      if (data.className && !SCHOOL_DATA.classes.some(c => c.name.toLowerCase() === data.className.toLowerCase())) errors.push(t('Unknown class reference: ') + data.className);
      if (data.guardianEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.guardianEmail)) errors.push(t('Invalid guardian email format'));
    }
    if ((i.dataType === 'teachers' || i.dataType === 'guardians') && data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) errors.push(t('Invalid email format'));
    if (i.dataType === 'classes' && data.capacity && isNaN(parseInt(data.capacity, 10))) errors.push(t('Capacity must be a number'));
    const isDuplicate = i.dataType === 'students' ? SCHOOL_DATA.students.some(s => (s.firstName+s.lastName).toLowerCase() === (data.firstName+data.lastName).toLowerCase())
      : i.dataType === 'teachers' ? SCHOOL_DATA.teachers.some(t2 => t2.email.toLowerCase() === (data.email||'').toLowerCase())
      : i.dataType === 'guardians' ? SCHOOL_DATA.guardians.some(g => g.email.toLowerCase() === (data.email||'').toLowerCase())
      : SCHOOL_DATA.classes.some(c => c.name.toLowerCase() === (data.name||'').toLowerCase());
    return { rowIndex: idx, data, errors, isDuplicate };
  });
  schImportGoto(4);
}
function schImportStep4() {
  const i = schState.import;
  const validRows = i.validationRows.filter(r => !r.errors.length);
  const errorRows = i.validationRows.filter(r => r.errors.length);
  const dupeRows = validRows.filter(r => r.isDuplicate);
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Validation Results')}</div></div>
    <div class="card-body">${schImportStepper()}
      <div class="gd-stat-row">
        <div class="stat-card"><div class="stat-label">${t('Valid Rows')}</div><div class="stat-val">${validRows.length}</div><div class="stat-icon green">${aIcon('check-circle')}</div></div>
        <div class="stat-card"><div class="stat-label">${t('Errors')}</div><div class="stat-val">${errorRows.length}</div><div class="stat-icon red">${aIcon('x-circle')}</div></div>
        <div class="stat-card"><div class="stat-label">${t('Duplicates')}</div><div class="stat-val">${dupeRows.length}</div><div class="stat-icon yellow">${aIcon('alert-triangle')}</div></div>
      </div>
      ${errorRows.length ? `<div style="margin-top:14px;font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Rows with Errors')}</div>${errorRows.slice(0,10).map(r => `<div class="info-row"><span>${t('Row')} ${r.rowIndex+2}</span><span style="color:var(--red);font-size:11.5px">${r.errors.join('; ')}</span></div>`).join('')}` : ''}
      <div style="display:flex;gap:10px;margin-top:14px">
        <button class="st-btn ghost" onclick="schImportGoto(3)">${t('← Back')}</button>
        <button class="st-btn" onclick="schImportGoto(5)" ${!validRows.length?'disabled':''}>${t('Next: Duplicate Review')} →</button>
      </div>
    </div></div>`;
}

function schImportStep5() {
  const i = schState.import;
  const dupes = i.validationRows.filter(r => !r.errors.length && r.isDuplicate);
  if (!dupes.length) { schImportGoto(6); return schImportBody(); }
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Duplicate Review')}</div></div>
    <div class="card-body">${schImportStepper()}
      <div style="font-size:11.5px;color:var(--muted);margin-bottom:10px">${t('These rows appear to already exist. Choose how to handle each.')}</div>
      ${dupes.map(r => { const nameLabel = i.dataType === 'students' ? (r.data.firstName+' '+r.data.lastName) : (r.data.name || r.data.email); const action = i.duplicateActions[r.rowIndex] || 'skip'; return `<div class="info-row"><span>${schEsc(nameLabel)}</span><select onchange="schSetDuplicateAction(${r.rowIndex}, this.value)" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:5px 8px;font-size:11.5px">
        <option value="skip" ${action==='skip'?'selected':''}>${t('Skip')}</option>
        <option value="update" ${action==='update'?'selected':''}>${t('Update')}</option>
        <option value="keep" ${action==='keep'?'selected':''}>${t('Keep Both')}</option>
      </select></div>`; }).join('')}
      <div style="display:flex;gap:10px;margin-top:14px">
        <button class="st-btn ghost" onclick="schImportGoto(4)">${t('← Back')}</button>
        <button class="st-btn" onclick="schImportGoto(6)">${t('Next: Preview')} →</button>
      </div>
    </div></div>`;
}
function schSetDuplicateAction(rowIndex, action) { schState.import.duplicateActions[rowIndex] = action; }
function schImportResolvedRows() {
  const i = schState.import;
  return i.validationRows.filter(r => {
    if (r.errors.length) return false;
    if (r.isDuplicate && (i.duplicateActions[r.rowIndex] || 'skip') === 'skip') return false;
    return true;
  });
}
function schImportStep6() {
  const i = schState.import;
  const resolved = schImportResolvedRows();
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Preview Import')}</div></div>
    <div class="card-body">${schImportStepper()}
      <div style="font-size:11.5px;color:var(--muted);margin-bottom:10px">${resolved.length} ${t('records will be imported')}.</div>
      ${resolved.slice(0,10).map(r => { const label = i.dataType === 'students' ? (r.data.firstName+' '+r.data.lastName) : (r.data.name || r.data.email); const action = r.isDuplicate ? (i.duplicateActions[r.rowIndex]||'skip') : 'create'; return `<div class="info-row"><span>${schEsc(label)}</span><span class="status-pill ${action==='create'?'open':action==='update'?'awaiting':'resolved'}">${t(action.charAt(0).toUpperCase()+action.slice(1))}</span></div>`; }).join('')}
      ${resolved.length > 10 ? `<div style="font-size:11.5px;color:var(--muted);margin-top:8px">${t('and')} ${resolved.length-10} ${t('more')}...</div>` : ''}
      <div style="display:flex;gap:10px;margin-top:14px">
        <button class="st-btn ghost" onclick="schImportGoto(5)">${t('← Back')}</button>
        <button class="st-btn" onclick="schRunImport()">${t('Confirm Import')}</button>
      </div>
    </div></div>`;
}
function schRunImport() {
  const i = schState.import;
  const resolved = schImportResolvedRows();
  let created = 0, updated = 0, kept = 0;
  resolved.forEach(r => {
    const action = r.isDuplicate ? (i.duplicateActions[r.rowIndex]||'skip') : 'create';
    if (i.dataType === 'students') {
      const cls = SCHOOL_DATA.classes.find(c => c.name.toLowerCase() === r.data.className.toLowerCase());
      let guardian = SCHOOL_DATA.guardians.find(g => g.email.toLowerCase() === r.data.guardianEmail.toLowerCase());
      if (!guardian) { guardian = { id:'sg' + Date.now() + Math.random().toString(36).slice(2,5), name:r.data.guardianEmail.split('@')[0], email:r.data.guardianEmail, phone:'', studentIds:[] }; SCHOOL_DATA.guardians.push(guardian); }
      if (action === 'update') {
        const existing = SCHOOL_DATA.students.find(s => (s.firstName+s.lastName).toLowerCase() === (r.data.firstName+r.data.lastName).toLowerCase());
        if (existing) { Object.assign(existing, { classId: cls.id, campusId: cls.campusId }); updated++; return; }
      }
      const newStudent = { id:'ss' + Date.now() + Math.random().toString(36).slice(2,5), studentId:'S' + (3000100 + SCHOOL_DATA.students.length + 1), firstName:r.data.firstName, lastName:r.data.lastName, dob:r.data.dob, gender:r.data.gender.toUpperCase(), classId:cls.id, campusId:cls.campusId, guardianId:guardian.id, enrollmentDate:SCH_TODAY, enrollmentStatus:'active', avgGrade:0, prevTermAvgGrade:0, attendanceRate:100, paymentStatus:'paid', status:'active' };
      SCHOOL_DATA.students.push(newStudent);
      guardian.studentIds.push(newStudent.id);
      created++;
    } else if (i.dataType === 'teachers') {
      SCHOOL_DATA.teachers.push({ id:'st' + Date.now() + Math.random().toString(36).slice(2,5), teacherId:'T' + (2001000 + SCHOOL_DATA.teachers.length + 1), name:r.data.name, subjects:[r.data.subject], classIds:[], campusId:'camp1', email:r.data.email, phone:r.data.phone||'', status:'active', joinedDate:SCH_TODAY });
      created++;
    } else if (i.dataType === 'guardians') {
      SCHOOL_DATA.guardians.push({ id:'sg' + Date.now() + Math.random().toString(36).slice(2,5), name:r.data.name, email:r.data.email, phone:r.data.phone||'', studentIds:[] });
      created++;
    } else if (i.dataType === 'classes') {
      SCHOOL_DATA.classes.push({ id:'sc' + Date.now() + Math.random().toString(36).slice(2,5), name:r.data.name, level:r.data.level, capacity:parseInt(r.data.capacity,10), campusId:'camp1', homeroomTeacherId: SCHOOL_DATA.teachers[0].id });
      created++;
    }
  });
  const errorCount = i.validationRows.filter(r => r.errors.length).length;
  const skippedCount = i.validationRows.filter(r => !r.errors.length && r.isDuplicate && (i.duplicateActions[r.rowIndex]||'skip')==='skip').length;
  i.result = { created, updated, skippedCount, errorCount, totalRows: i.rawRows.length };
  schLogAudit('Import Completed', 'Bulk Import', t(SCH_IMPORT_DATA_TYPES.find(x=>x[0]===i.dataType)[1]), '', created + ' ' + t('created'));
  schImportGoto(7);
}
function schImportStep7() {
  const r = schState.import.result;
  if (!r) { schState.import.step = 1; return schImportBody(); }
  return `<div class="card"><div class="card-body" style="text-align:center;padding:30px 20px">
    <div style="font-size:34px;margin-bottom:10px">${aIcon('check-circle')}</div>
    <div style="font-weight:700;font-size:16px;margin-bottom:14px">${t('Import Complete')}</div>
    <div class="info-row"><span>${t('Total Rows')}</span><span>${r.totalRows}</span></div>
    <div class="info-row"><span>${t('Created')}</span><span style="color:var(--green)">${r.created}</span></div>
    <div class="info-row"><span>${t('Updated')}</span><span style="color:var(--muted)">${r.updated}</span></div>
    <div class="info-row"><span>${t('Skipped')}</span><span style="color:var(--muted)">${r.skippedCount}</span></div>
    <div class="info-row"><span>${t('Errors')}</span><span style="color:var(--red)">${r.errorCount}</span></div>
    <button class="st-btn" style="margin-top:18px" onclick="schResetImport()">${t('Start New Import')}</button>
  </div></div>`;
}
function schResetImport() {
  schState.import = { tab:'student', step:1, dataType:'students', fileName:'', rawHeaders:[], rawRows:[], mapping:{}, validationRows:[], duplicateActions:{}, result:null, error:'' };
  schRefreshImport();
}

/* ══════════════════════════════════════════════════════
   ACCOUNT GENERATION (section 21)
══════════════════════════════════════════════════════ */
SCHOOL_DATA.generatedAccounts = [];
function schAccountPersonList(type) {
  if (type === 'student') return SCHOOL_DATA.students;
  if (type === 'teacher') return SCHOOL_DATA.teachers;
  return SCHOOL_DATA.guardians;
}
function schAccountPersonName(type, p) { return type === 'student' ? schStudentFullName(p) : p.name; }
function schAccountPersonRealId(type, id) {
  if (type === 'student') return schGetStudent(id).studentId;
  if (type === 'teacher') return schGetTeacher(id).teacherId;
  const g = schGetGuardian(id);
  return g.authrenId || null;
}
function schGenerateTempPassword() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let pw = '';
  for (let i = 0; i < 8; i++) pw += chars[Math.floor(Math.random() * chars.length)];
  return pw;
}
function schAccountsView() {
  return `<div id="sch-accounts-content">${schAccountsBody()}</div>`;
}
function schAccountsBody() {
  const a = schState.accounts;
  return `
    <div class="st-tabs">
      <div class="st-tab gd-tab-schacc${(!a.screen||a.screen==='generate')?' active':''}" onclick="schSetAccountsScreen('generate')">${t('Generate')}</div>
      <div class="st-tab gd-tab-schacc${a.screen==='list'?' active':''}" onclick="schSetAccountsScreen('list')">${t('Generated Accounts')} (${SCHOOL_DATA.generatedAccounts.length})</div>
    </div>
    <div id="sch-accounts-inner">${a.screen === 'list' ? schAccountsListScreen() : schAccountsGenerateScreen()}</div>`;
}
function schSetAccountsScreen(s) {
  schState.accounts.screen = s;
  const el = document.getElementById('sch-accounts-content');
  if (el) el.innerHTML = schAccountsBody();
}
function schAccountsGenerateScreen() {
  const a = schState.accounts;
  const people = schAccountPersonList(a.personType).filter(p => !schAccountPersonRealId(a.personType, p.id) || a.personType !== 'guardian');
  const q = a.search.trim().toLowerCase();
  const filtered = q ? people.filter(p => schAccountPersonName(a.personType, p).toLowerCase().includes(q)) : people;
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Generate Accounts')}</div></div>
    <div class="card-body">
      <div class="gd-comm-filter-row">
        <div class="gd-comm-filter-chip${a.personType==='student'?' active':''}" onclick="schSetAccountPersonType('student')">${t('Students')}</div>
        <div class="gd-comm-filter-chip${a.personType==='teacher'?' active':''}" onclick="schSetAccountPersonType('teacher')">${t('Teachers')}</div>
        <div class="gd-comm-filter-chip${a.personType==='guardian'?' active':''}" onclick="schSetAccountPersonType('guardian')">${t('Guardians')}</div>
      </div>
      <input class="gd-comm-search-input" type="text" placeholder="${t('Search...')}" value="${schEsc(a.search)}" oninput="schSetAccountSearch(this.value)" style="margin-top:10px">
      <div id="sch-acc-list" style="margin-top:10px">${schAccountPersonListBlock()}</div>
      <button class="st-btn" style="margin-top:14px" onclick="schGenerateSelectedAccounts()" ${!a.selected.length?'disabled':''}>${t('Generate')} (${a.selected.length}) ${t('Account(s)')}</button>
    </div></div>`;
}
function schAccountPersonListBlock() {
  const a = schState.accounts;
  const people = schAccountPersonList(a.personType);
  const q = a.search.trim().toLowerCase();
  const filtered = (q ? people.filter(p => schAccountPersonName(a.personType, p).toLowerCase().includes(q)) : people).filter(p => !schAccountPersonRealId(a.personType, p.id));
  const alreadyGenerated = (q ? people.filter(p => schAccountPersonName(a.personType, p).toLowerCase().includes(q)) : people).filter(p => schAccountPersonRealId(a.personType, p.id));
  if (!filtered.length && !alreadyGenerated.length) return `<div class="gd-empty-mini">${t('No matches found.')}</div>`;
  return filtered.map(p => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="schToggleAccountSelect('${p.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();schToggleAccountSelect('${p.id}')}"><span><input type="checkbox" ${a.selected.includes(p.id)?'checked':''} style="margin-right:8px;pointer-events:none">${schEsc(schAccountPersonName(a.personType, p))}</span></div>`).join('')
    + alreadyGenerated.map(p => `<div class="info-row"><span style="color:var(--muted)">${schEsc(schAccountPersonName(a.personType, p))}</span><span class="status-pill paid">${t('Account exists')}</span></div>`).join('');
}
function schSetAccountPersonType(type) { schState.accounts.personType = type; schState.accounts.selected = []; const el = document.getElementById('sch-accounts-inner'); if (el) el.innerHTML = schAccountsGenerateScreen(); }
function schSetAccountSearch(v) { schState.accounts.search = v; const el = document.getElementById('sch-acc-list'); if (el) el.innerHTML = schAccountPersonListBlock(); }
function schToggleAccountSelect(id) {
  const a = schState.accounts;
  if (a.selected.includes(id)) a.selected = a.selected.filter(x => x !== id);
  else a.selected.push(id);
  const el = document.getElementById('sch-accounts-inner'); if (el) el.innerHTML = schAccountsGenerateScreen();
}
function schGenerateSelectedAccounts() {
  const a = schState.accounts;
  const created = [];
  a.selected.forEach(personId => {
    if (a.personType === 'guardian') { const g = schGetGuardian(personId); if (g && !g.authrenId) g.authrenId = 'G' + String(Math.floor(10000000 + Math.random() * 89999999)); }
    const account = { id:'sacc' + Date.now() + Math.random().toString(36).slice(2,5), personType:a.personType, personId, authrenId: schAccountPersonRealId(a.personType, personId), tempPassword: schGenerateTempPassword(), status:'generated', generatedAt: SCH_TODAY };
    SCHOOL_DATA.generatedAccounts.push(account);
    created.push(account);
  });
  a.selected = [];
  if (created.length) schLogAudit('Account Generated', 'Account', `${created.length} ${a.personType}(s)`, '', created.map(c => c.authrenId).join(', '));
  schSetAccountsScreen('list');
  schShowToast(`${created.length} ${t('account(s) generated successfully.')}`);
}
function schAccountsListScreen() {
  if (!SCHOOL_DATA.generatedAccounts.length) return `<div class="card"><div class="card-body"><div class="gd-empty-mini">${t('No accounts generated yet.')}</div></div></div>`;
  return `<div class="card"><div class="card-body">
    ${SCHOOL_DATA.generatedAccounts.slice().reverse().map(acc => { const p = schAccountPersonList(acc.personType).find(x => x.id === acc.personId); return `<div class="info-row"><span>${p ? schEsc(schAccountPersonName(acc.personType, p)) : '—'}<div style="font-size:11px;color:var(--muted)">${schEsc(acc.authrenId)} · ${t('Temp password')}: ${schEsc(acc.tempPassword)}</div></span><span class="status-pill paid">${t('Generated')}</span></div>`; }).join('')}
  </div></div>`;
}

/* ══════════════════════════════════════════════════════
   HISTORICAL DATA MANAGEMENT (section 22)
   Only one real academic year of data exists in this seed dataset —
   the UI is honest about that rather than fabricating fake prior years.
══════════════════════════════════════════════════════ */
const SCH_AVAILABLE_ACADEMIC_YEARS = ['2025-2026'];
function schHistoricalDataView() { return `<div id="sch-hist-content">${schHistoricalDataBody()}</div>`; }
function schHistoricalDataBody() {
  const h = schState.historicalData;
  const categories = [['all','All'],['students','Students'],['payments','Payments'],['admissions','Admissions'],['communications','Communications']];
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Historical Data Management')}</div></div>
    <div class="card-body">
      <div class="st-field"><label>${t('Academic Year')}</label><select onchange="schSetHistYear(this.value)">
        ${SCH_AVAILABLE_ACADEMIC_YEARS.map(y => `<option value="${y}" ${y===h.year?'selected':''}>${y}</option>`).join('')}
      </select></div>
      ${SCH_AVAILABLE_ACADEMIC_YEARS.length < 2 ? `<div style="font-size:11.5px;color:var(--muted);margin-bottom:10px">${t('Only one academic year of data currently exists in this system — earlier years will appear here once more history accumulates.')}</div>` : ''}
      <input class="gd-comm-search-input" type="text" placeholder="${t('Search historical records...')}" value="${schEsc(h.search)}" oninput="schSetHistSearch(this.value)">
      <div class="gd-comm-filter-row" style="margin-top:10px">${categories.map(([id,label]) => `<div class="gd-comm-filter-chip${h.category===id?' active':''}" onclick="schSetHistCategory('${id}')">${t(label)}</div>`).join('')}</div>
      <div id="sch-hist-results" style="margin-top:10px">${schHistResultsBlock()}</div>
    </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Compare Previous Periods')}</div></div>
      <div class="card-body"><div class="gd-empty-mini">${t('Historical comparison requires at least two academic years of data. Only one year currently exists.')}</div></div></div>`;
}
function schHistResultsBlock() {
  const h = schState.historicalData;
  const q = h.search.trim().toLowerCase();
  const sections = [];
  if (h.category === 'all' || h.category === 'students') {
    let items = SCHOOL_DATA.students.filter(s => s.enrollmentDate.startsWith('2025') || s.enrollmentDate.startsWith('2026'));
    if (q) items = items.filter(s => schStudentFullName(s).toLowerCase().includes(q));
    if (items.length) sections.push({ title:t('Students'), rows: items.slice(0,8).map(s => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="schOpenHistStudent('${s.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();schOpenHistStudent('${s.id}')}"><span>${schEsc(schStudentFullName(s))}</span><span style="color:var(--muted);font-size:12px">${s.enrollmentDate}</span></div>`) });
  }
  if (h.category === 'all' || h.category === 'payments') {
    let items = SCHOOL_DATA.payments.filter(p => p.status === 'paid');
    if (q) items = items.filter(p => { const st = schGetStudent(p.studentId); return st && schStudentFullName(st).toLowerCase().includes(q); });
    if (items.length) sections.push({ title:t('Payments'), rows: items.slice(0,8).map(p => { const st = schGetStudent(p.studentId); return `<div class="info-row"><span>${st?schEsc(schStudentFullName(st)):''} · ${schEsc(p.description)}</span><span style="color:var(--muted);font-size:12px">${p.date}</span></div>`; }) });
  }
  if (h.category === 'all' || h.category === 'admissions') {
    let items = SCHOOL_DATA.admissions.slice();
    if (q) items = items.filter(a => schAdmissionFullName(a).toLowerCase().includes(q));
    if (items.length) sections.push({ title:t('Admissions'), rows: items.slice(0,8).map(a => `<div class="info-row"><span>${schEsc(schAdmissionFullName(a))}</span><span style="color:var(--muted);font-size:12px">${a.submittedDate}</span></div>`) });
  }
  if (h.category === 'all' || h.category === 'communications') {
    let items = SCHOOL_DATA.announcements.filter(a => a.status === 'sent');
    if (q) items = items.filter(a => a.subject.toLowerCase().includes(q));
    if (items.length) sections.push({ title:t('Communications'), rows: items.slice(0,8).map(a => `<div class="info-row"><span>${schEsc(a.subject)}</span><span style="color:var(--muted);font-size:12px">${a.sentAt.slice(0,10)}</span></div>`) });
  }
  if (!sections.length) return `<div class="gd-empty-mini">${t('No historical records match your search or filters.')}</div>`;
  return sections.map(s => `<div style="margin-top:12px;font-size:12.5px;font-weight:600;margin-bottom:6px">${s.title}</div>${s.rows.join('')}`).join('');
}
function schSetHistYear(v) { schState.historicalData.year = v; schRefreshHist(); }
function schSetHistSearch(v) { schState.historicalData.search = v; const el = document.getElementById('sch-hist-results'); if (el) el.innerHTML = schHistResultsBlock(); }
function schSetHistCategory(v) { schState.historicalData.category = v; const el = document.getElementById('sch-hist-results'); if (el) el.innerHTML = schHistResultsBlock(); }
function schRefreshHist() { const el = document.getElementById('sch-hist-content'); if (el) el.innerHTML = schHistoricalDataBody(); }
function schOpenHistStudent(id) {
  schState.dataManagement.tab = 'students';
  schState.dataManagement.detailId = id;
  authrenGoTo('data-management');
}

/* ══════════════════════════════════════════════════════
   SCHOOL PULSE (section 23) — rolling institutional snapshot
══════════════════════════════════════════════════════ */
function schPulseIndicator(value, good, warn, higherIsBetter) {
  if (value === null) return { level:'neutral', icon: aIcon('dot'), label:'No data' };
  const isGood = higherIsBetter ? value >= good : value <= good;
  const isWarn = higherIsBetter ? value >= warn : value <= warn;
  if (isGood) return { level:'good', icon: aIcon('dot'), label:'Healthy' };
  if (isWarn) return { level:'warn', icon: aIcon('dot'), label:'Needs Attention' };
  return { level:'bad', icon: aIcon('dot'), label:'At Risk' };
}
function schPulseCard(title, value, unit, indicator, route, detail) {
  return `<div class="card" style="cursor:pointer" role="button" tabindex="0" onclick="authrenGoTo('${route}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();authrenGoTo('${route}')}"><div class="card-body">
    <div style="display:flex;justify-content:space-between;align-items:center">
      <div><div style="font-size:12px;color:var(--muted)">${t(title)}</div><div style="font-size:20px;font-weight:800;margin-top:2px">${value !== null ? value + unit : '—'}</div></div>
      <div style="text-align:right"><div style="font-size:20px">${indicator.icon}</div><div style="font-size:10.5px;color:var(--muted)">${t(indicator.label)}</div></div>
    </div>
    ${detail ? `<div style="font-size:11px;color:var(--muted);margin-top:8px">${detail}</div>` : ''}
  </div></div>`;
}
function schPulseView() {
  const academicAvg = schAvg(SCHOOL_DATA.students.map(s => s.avgGrade));
  const attendanceAvg = schAggregateAttendance(SCHOOL_DATA.students.map(s=>s.id), SCH_ATTENDANCE_DAYS).rate;
  const collected = SCHOOL_DATA.payments.filter(p => p.status === 'paid').reduce((s, p) => s + p.amount, 0);
  const outstanding = SCHOOL_DATA.payments.filter(p => p.status !== 'paid').reduce((s, p) => s + p.amount, 0);
  const totalDue = SCHOOL_DATA.payments.reduce((s, p) => s + p.amount, 0);
  const outstandingPct = totalDue ? Math.round((outstanding / totalDue) * 100) : 0;
  const pendingAdmissions = SCHOOL_DATA.admissions.filter(a => a.status === 'pending' || a.status === 'under-review').length;
  const sentAnnouncements = SCHOOL_DATA.announcements.filter(a => a.status === 'sent').length;
  const openReclamations = SCHOOL_DATA.reclamations.filter(r => r.status !== 'resolved' && r.status !== 'archived').length;
  const opActivity = SCHOOL_DATA.auditLog.length;

  const alerts = schComputeSchoolAlerts();
  const positives = alerts.filter(a => a.direction === 'positive');
  const negatives = alerts.filter(a => a.direction === 'negative');

  return `
    <div style="font-size:12px;color:var(--muted);margin-bottom:14px">${t('A real-time snapshot of institutional health, computed transparently from current data. Tap any card to explore.')}</div>
    <div class="gd-stat-row">
      ${schPulseCard('Enrollment', SCHOOL_DATA.students.length, '', { level:'neutral', icon: aIcon('graduation-cap'), label:t('Informational') }, 'enrollment')}
      ${schPulseCard('Attendance Rate', attendanceAvg, '%', schPulseIndicator(attendanceAvg, 90, 80, true), 'analytics-basic')}
      ${schPulseCard('Academic Performance', academicAvg, '/20', schPulseIndicator(academicAvg, 14, 11, true), 'analytics-basic')}
      ${schPulseCard('Outstanding Payments', outstandingPct, '%', schPulseIndicator(outstandingPct, 10, 25, false), 'payments', schCurrency(outstanding) + ' ' + t('outstanding'))}
    </div>
    <div class="gd-stat-row" style="margin-top:16px">
      ${schPulseCard('Pending Admissions', pendingAdmissions, '', { level:'neutral', icon: aIcon('inbox'), label:t('Informational') }, 'admissions')}
      ${schPulseCard('Communication Activity', sentAnnouncements, '', { level:'neutral', icon: aIcon('mail'), label:t('Informational') }, 'communication')}
      ${schPulseCard('Open Reclamations', openReclamations, '', schPulseIndicator(openReclamations, 2, 5, false), 'reclamations')}
      ${schPulseCard('Operational Activity', opActivity, '', { level:'neutral', icon: aIcon('file-text'), label:t('Informational') }, 'audit')}
    </div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Positive Developments')}</div></div>
      <div class="card-body">${positives.length ? positives.map(a => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="authrenGoTo('${a.route}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();authrenGoTo('${a.route}')}"><span>${aIcon('check-circle')} ${t(a.label)}</span></div>`).join('') : `<div class="gd-empty-mini">${t('No notable positive developments detected right now.')}</div>`}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Areas Requiring Attention')}</div></div>
      <div class="card-body">${negatives.length ? negatives.map(a => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="authrenGoTo('${a.route}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();authrenGoTo('${a.route}')}"><span>${aIcon('alert-triangle')} ${t(a.label)}</span></div>`).join('') : `<div class="gd-empty-mini">${t('No areas currently flagged as needing attention.')}</div>`}</div></div>`;
}

/* ══════════════════════════════════════════════════════
   WHAT CHANGED? (section 24) — shared comparison engine also feeds
   School Pulse's Positive Developments / Areas Requiring Attention.
══════════════════════════════════════════════════════ */
const SCH_PERIOD_TYPES = [ ['month','This Month vs Last Month'], ['term','Current Term vs Previous Term'], ['year','Current Year vs Previous Year'] ];
function schPeriodPredicates(periodType) {
  if (periodType === 'term') {
    const cutoff = '2026-01-01';
    return { isCurrent: d => d >= cutoff, isPrevious: d => d < cutoff, curLabel:t('Current Term'), prevLabel:t('Previous Term') };
  }
  if (periodType === 'year') {
    return { isCurrent: d => d.startsWith('2026'), isPrevious: d => d.startsWith('2025'), curLabel:'2026', prevLabel:'2025' };
  }
  return { isCurrent: d => d.startsWith('2026-03'), isPrevious: d => d.startsWith('2026-02'), curLabel:t('Mar 2026'), prevLabel:t('Feb 2026') };
}
function schComputePeriodComparison(periodType) {
  const { isCurrent, isPrevious } = schPeriodPredicates(periodType);
  const allIds = SCHOOL_DATA.students.map(s => s.id);
  const curAttDays = SCH_ATTENDANCE_DAYS.filter(isCurrent);
  const prevAttDays = SCH_ATTENDANCE_DAYS.filter(isPrevious);
  const curAttRate = curAttDays.length ? schAggregateAttendance(allIds, curAttDays).rate : null;
  const prevAttRate = prevAttDays.length ? schAggregateAttendance(allIds, prevAttDays).rate : null;

  const curEnroll = SCHOOL_DATA.students.filter(s => isCurrent(s.enrollmentDate)).length;
  const prevEnroll = SCHOOL_DATA.students.filter(s => isPrevious(s.enrollmentDate)).length;

  const curScores = SCHOOL_DATA.students.map(s => s.avgGrade);
  const prevScores = SCHOOL_DATA.students.map(s => s.prevTermAvgGrade);
  const curAcademic = periodType === 'term' ? schAvg(curScores) : null;
  const prevAcademic = periodType === 'term' ? schAvg(prevScores) : null;

  const curPayments = SCHOOL_DATA.payments.filter(p => p.status === 'paid' && isCurrent(p.date)).reduce((s,p)=>s+p.amount,0);
  const prevPayments = SCHOOL_DATA.payments.filter(p => p.status === 'paid' && isPrevious(p.date)).reduce((s,p)=>s+p.amount,0);

  const curAdmissions = SCHOOL_DATA.admissions.filter(a => isCurrent(a.submittedDate)).length;
  const prevAdmissions = SCHOOL_DATA.admissions.filter(a => isPrevious(a.submittedDate)).length;

  const curComms = SCHOOL_DATA.announcements.filter(a => a.status==='sent' && isCurrent(a.sentAt)).length;
  const prevComms = SCHOOL_DATA.announcements.filter(a => a.status==='sent' && isPrevious(a.sentAt)).length;

  const curComplaints = SCHOOL_DATA.reclamations.filter(r => isCurrent(r.submittedDate)).length;
  const prevComplaints = SCHOOL_DATA.reclamations.filter(r => isPrevious(r.submittedDate)).length;

  const rows = [
    { id:'enrollment', label:'Enrollment', current:curEnroll, previous:prevEnroll, unit:'', higherIsBetter:true, route:'enrollment' },
    { id:'attendance', label:'Attendance Rate', current:curAttRate, previous:prevAttRate, unit:'%', higherIsBetter:true, route:'analytics-basic' },
    { id:'payments', label:'Payment Collection', current:curPayments, previous:prevPayments, unit:'MAD', higherIsBetter:true, route:'payments' },
    { id:'admissions', label:'Admissions', current:curAdmissions, previous:prevAdmissions, unit:'', higherIsBetter:true, route:'admissions' },
    { id:'communication', label:'Communication Activity', current:curComms, previous:prevComms, unit:'', higherIsBetter:true, route:'communication' },
    { id:'complaints', label:'Complaints', current:curComplaints, previous:prevComplaints, unit:'', higherIsBetter:false, route:'reclamations' },
  ];
  if (periodType === 'term') rows.splice(2, 0, { id:'academic', label:'Academic Performance', current:curAcademic, previous:prevAcademic, unit:'/20', higherIsBetter:true, route:'analytics-basic' });
  return rows;
}
function schComputeMonthComparison() { return schComputePeriodComparison('month'); }

function schFormatMetricValue(v, unit) { if (v === null) return t('No data'); return unit === 'MAD' ? schCurrency(v) : v + unit; }
function schComputeSchoolAlerts() {
  const comps = schComputeMonthComparison();
  const alerts = [];
  comps.forEach(c => {
    if (c.current === null || c.previous === null) return;
    const delta = c.current - c.previous;
    if (delta === 0) return;
    const improved = c.higherIsBetter ? delta > 0 : delta < 0;
    const amount = c.unit === 'MAD' ? schCurrency(Math.abs(delta)) : Math.abs(delta) + c.unit;
    alerts.push({ direction: improved ? 'positive' : 'negative', label: `${t(c.label)} ${improved ? t('improved by') : t('declined by')} ${amount}`, route: c.route });
  });
  return alerts;
}
function schWhatChangedView() {
  const comps = schComputeMonthComparison();
  return `<div style="font-size:12px;color:var(--muted);margin-bottom:14px">${t('Comparing March 2026 (current) to February 2026 (previous period).')}</div>
    ${comps.map(c => {
      if (c.current === null || c.previous === null) {
        return `<div class="card" style="margin-bottom:10px;cursor:pointer" role="button" tabindex="0" onclick="authrenGoTo('${c.route}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();authrenGoTo('${c.route}')}"><div class="card-body">
          <div style="font-weight:600;font-size:13px">${t(c.label)}</div>
          <div style="font-size:11.5px;color:var(--muted);margin-top:4px">${t('Not enough data in both periods to compare.')} (${t('Feb')}: ${schFormatMetricValue(c.previous, c.unit)} · ${t('Mar')}: ${schFormatMetricValue(c.current, c.unit)})</div>
        </div></div>`;
      }
      const delta = c.current - c.previous;
      const improved = c.higherIsBetter ? delta >= 0 : delta <= 0;
      const arrow = delta > 0 ? '▲' : delta < 0 ? '▼' : '—';
      return `<div class="card" style="margin-bottom:10px;cursor:pointer" role="button" tabindex="0" onclick="authrenGoTo('${c.route}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();authrenGoTo('${c.route}')}"><div class="card-body">
        <div style="display:flex;justify-content:space-between;align-items:center">
          <div style="font-weight:600;font-size:13px">${t(c.label)}</div>
          <div style="color:${improved?'var(--green)':'var(--red)'};font-weight:700;font-size:13px">${arrow} ${c.unit==='MAD' ? schCurrency(Math.abs(delta)) : Math.abs(delta) + c.unit}</div>
        </div>
        <div style="font-size:11.5px;color:var(--muted);margin-top:4px">${t('Feb')}: ${schFormatMetricValue(c.previous, c.unit)} → ${t('Mar')}: ${schFormatMetricValue(c.current, c.unit)}</div>
      </div></div>`;
    }).join('')}`;
}

/* ══════════════════════════════════════════════════════
   ADVANCED SCHOOL-WIDE ANALYTICS (section 28)
   Cross-campus comparison across every domain, with drill-down.
══════════════════════════════════════════════════════ */
function schAnalyticsSchoolwideView() {
  const rows = SCHOOL_DATA.campuses.map(c => {
    const students = schCampusStudents(c.id);
    const teachers = schCampusTeachers(c.id);
    const academicAvg = schAvg(students.map(s => s.avgGrade));
    const attAgg = schAggregateAttendance(students.map(s=>s.id), SCH_ATTENDANCE_DAYS);
    const payments = SCHOOL_DATA.payments.filter(p => p.campusId === c.id);
    const collected = payments.filter(p=>p.status==='paid').reduce((s,p)=>s+p.amount,0);
    const outstanding = payments.filter(p=>p.status!=='paid').reduce((s,p)=>s+p.amount,0);
    const admissions = SCHOOL_DATA.admissions.filter(a => a.campusId === c.id);
    const reclamations = SCHOOL_DATA.reclamations.filter(r => r.campusId === c.id);
    return { campus:c, students, teachers, academicAvg, attRate:attAgg.rate, collected, outstanding, admissions, reclamations };
  });
  return `
    <div style="font-size:12px;color:var(--muted);margin-bottom:14px">${t('Every domain compared side-by-side across all campuses. Tap a campus to drill into its data.')}</div>
    <div class="card"><div class="card-header"><div class="card-title">${t('Enrollment')}</div></div>
      <div class="card-body">${rows.map(r => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="schDrillCampus('${r.campus.id}','data-management')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();schDrillCampus('${r.campus.id}','data-management')}"><span>${schEsc(r.campus.name)}</span><span style="color:var(--muted)">${r.students.length} ${t('students')} · ${r.teachers.length} ${t('teachers')}</span></div>`).join('')}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Academics & Attendance')}</div></div>
      <div class="card-body">${rows.map(r => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="authrenGoTo('analytics-basic')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();authrenGoTo('analytics-basic')}"><span>${schEsc(r.campus.name)}</span><span style="color:var(--muted)">${r.academicAvg!==null?r.academicAvg+'/20':'—'} · ${r.attRate!==null?r.attRate+'%':'—'}</span></div>`).join('')}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Finance')}</div></div>
      <div class="card-body">${rows.map(r => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="authrenGoTo('payment-records')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();authrenGoTo('payment-records')}"><span>${schEsc(r.campus.name)}</span><span style="color:var(--muted)">${schCurrency(r.collected)} ${t('collected')} · ${schCurrency(r.outstanding)} ${t('outstanding')}</span></div>`).join('')}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Admissions')}</div></div>
      <div class="card-body">${rows.map(r => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="authrenGoTo('admissions')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();authrenGoTo('admissions')}"><span>${schEsc(r.campus.name)}</span><span style="color:var(--muted)">${r.admissions.length} ${t('applications')}</span></div>`).join('')}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Communication')}</div></div>
      <div class="card-body">${(() => { const sent = SCHOOL_DATA.announcements.filter(a=>a.status==='sent'); const institWide = sent.filter(a=>!a.campusId).length; return SCHOOL_DATA.campuses.map(c => { const campusSpecific = sent.filter(a=>a.campusId===c.id).length; return `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="authrenGoTo('communication')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();authrenGoTo('communication')}"><span>${schEsc(c.name)}</span><span style="color:var(--muted)">${campusSpecific + institWide} ${t('received')}</span></div>`; }).join(''); })()}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Operations (Reclamations)')}</div></div>
      <div class="card-body">${rows.map(r => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="authrenGoTo('reclamations')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();authrenGoTo('reclamations')}"><span>${schEsc(r.campus.name)}</span><span style="color:var(--muted)">${r.reclamations.length} ${t('total')}</span></div>`).join('')}</div></div>`;
}
function schDrillCampus(campusId, route) {
  if (route === 'data-management') { schState.dataManagement.filterCampus = campusId; schState.dataManagement.tab = 'students'; }
  authrenGoTo(route);
}

/* ══════════════════════════════════════════════════════
   COMPLETE INSTITUTION ANALYTICS (section 34)
   One unified summary of the whole institution — every metric
   clickable and drillable, no need to open other modules first.
══════════════════════════════════════════════════════ */
function schAnalyticsCompleteView() {
  const academicAvg = schAvg(SCHOOL_DATA.students.map(s => s.avgGrade));
  const attAgg = schAggregateAttendance(SCHOOL_DATA.students.map(s=>s.id), SCH_ATTENDANCE_DAYS);
  const collected = SCHOOL_DATA.payments.filter(p=>p.status==='paid').reduce((s,p)=>s+p.amount,0);
  const outstanding = SCHOOL_DATA.payments.filter(p=>p.status!=='paid').reduce((s,p)=>s+p.amount,0);
  const admissionsByStatus = {};
  SCHOOL_DATA.admissions.forEach(a => { admissionsByStatus[a.status] = (admissionsByStatus[a.status]||0)+1; });
  const sentComms = SCHOOL_DATA.announcements.filter(a=>a.status==='sent').length;
  const openReclamations = SCHOOL_DATA.reclamations.filter(r=>r.status!=='resolved'&&r.status!=='archived').length;

  return `
    <div style="font-size:12px;color:var(--muted);margin-bottom:14px">${t('Understand the entire institution from one page. Every metric below is clickable.')}</div>
    <div class="card"><div class="card-header"><div class="card-title">${t('Enrollment')}</div><div class="card-action" onclick="authrenGoTo('enrollment')">${t('Open')} →</div></div>
      <div class="card-body"><div class="info-row"><span>${t('Total Students')}</span><span>${SCHOOL_DATA.students.length}</span></div><div class="info-row"><span>${t('Active')}</span><span>${SCHOOL_DATA.students.filter(s=>s.status==='active').length}</span></div></div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Attendance')}</div><div class="card-action" onclick="authrenGoTo('analytics-basic')">${t('Open')} →</div></div>
      <div class="card-body"><div class="info-row"><span>${t('Overall Rate')}</span><span>${attAgg.rate!==null?attAgg.rate+'%':'—'}</span></div></div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Academics')}</div><div class="card-action" onclick="authrenGoTo('analytics-basic')">${t('Open')} →</div></div>
      <div class="card-body"><div class="info-row"><span>${t('Overall Average')}</span><span>${academicAvg!==null?academicAvg+'/20':'—'}</span></div></div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Admissions')}</div><div class="card-action" onclick="authrenGoTo('admissions')">${t('Open')} →</div></div>
      <div class="card-body">${Object.keys(admissionsByStatus).map(st => `<div class="info-row"><span>${t(SCH_ADMISSION_STATUS_META[st].label)}</span><span>${admissionsByStatus[st]}</span></div>`).join('')}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Finance')}</div><div class="card-action" onclick="authrenGoTo('payment-records')">${t('Open')} →</div></div>
      <div class="card-body"><div class="info-row"><span>${t('Collected')}</span><span>${schCurrency(collected)}</span></div><div class="info-row"><span>${t('Outstanding')}</span><span>${schCurrency(outstanding)}</span></div></div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Communication')}</div><div class="card-action" onclick="authrenGoTo('communication')">${t('Open')} →</div></div>
      <div class="card-body"><div class="info-row"><span>${t('Announcements Sent')}</span><span>${sentComms}</span></div></div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Operations')}</div><div class="card-action" onclick="authrenGoTo('reclamations')">${t('Open')} →</div></div>
      <div class="card-body"><div class="info-row"><span>${t('Open Reclamations')}</span><span>${openReclamations}</span></div></div></div>`;
}

/* ══════════════════════════════════════════════════════
   HISTORICAL COMPARISONS (section 27) — user-selectable period type
══════════════════════════════════════════════════════ */
function schHistoricalComparisonsView() {
  return `<div id="sch-hist-comparisons-content">${schHistoricalComparisonsBody()}</div>`;
}
function schHistoricalComparisonsBody() {
  const periodType = schState.intelligence.periodType;
  const comps = schComputePeriodComparison(periodType);
  const { curLabel, prevLabel } = schPeriodPredicates(periodType);
  return `
    <div class="gd-comm-filter-row" style="margin-bottom:12px">${SCH_PERIOD_TYPES.map(([id,label]) => `<div class="gd-comm-filter-chip${periodType===id?' active':''}" onclick="schSetIntelligencePeriodType('${id}')">${t(label)}</div>`).join('')}</div>
    <div style="font-size:12px;color:var(--muted);margin-bottom:14px">${t('Comparing')} ${prevLabel} (${t('previous')}) ${t('to')} ${curLabel} (${t('current')}).</div>
    ${comps.map(c => {
      if (c.current === null || c.previous === null) {
        return `<div class="card" style="margin-bottom:10px;cursor:pointer" role="button" tabindex="0" onclick="authrenGoTo('${c.route}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();authrenGoTo('${c.route}')}"><div class="card-body">
          <div style="font-weight:600;font-size:13px">${t(c.label)}</div>
          <div style="font-size:11.5px;color:var(--muted);margin-top:4px">${t('Not enough data in both periods to compare.')} (${prevLabel}: ${schFormatMetricValue(c.previous, c.unit)} · ${curLabel}: ${schFormatMetricValue(c.current, c.unit)})</div>
        </div></div>`;
      }
      const delta = c.current - c.previous;
      const improved = c.higherIsBetter ? delta >= 0 : delta <= 0;
      const arrow = delta > 0 ? '▲' : delta < 0 ? '▼' : '—';
      return `<div class="card" style="margin-bottom:10px;cursor:pointer" role="button" tabindex="0" onclick="authrenGoTo('${c.route}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();authrenGoTo('${c.route}')}"><div class="card-body">
        <div style="display:flex;justify-content:space-between;align-items:center">
          <div style="font-weight:600;font-size:13px">${t(c.label)}</div>
          <div style="color:${improved?'var(--green)':'var(--red)'};font-weight:700;font-size:13px">${arrow} ${c.unit==='MAD' ? schCurrency(Math.abs(delta)) : Math.abs(delta) + c.unit}</div>
        </div>
        <div style="font-size:11.5px;color:var(--muted);margin-top:4px">${prevLabel}: ${schFormatMetricValue(c.previous, c.unit)} → ${curLabel}: ${schFormatMetricValue(c.current, c.unit)}</div>
      </div></div>`;
    }).join('')}`;
}
function schSetIntelligencePeriodType(periodType) {
  schState.intelligence.periodType = periodType;
  const wrapper = document.getElementById('sch-hist-comparisons-content');
  if (wrapper) wrapper.innerHTML = schHistoricalComparisonsBody();
}

/* ══════════════════════════════════════════════════════
   ADVANCED HISTORICAL ANALYSIS (section 35)
   True multi-year longitudinal analysis needs more than one academic
   year of data, which this institution does not yet have — that is
   disclosed honestly. Within the one real year that exists, a genuine
   Term 1 vs Term 2 comparison is still offered using real dated data.
══════════════════════════════════════════════════════ */
function schHistoricalAdvancedView() {
  const termComp = schComputePeriodComparison('term');
  return `
    <div style="background:rgba(217,119,6,0.1);border:1px solid rgba(217,119,6,0.3);border-radius:10px;padding:10px 12px;font-size:11.5px;color:var(--muted2);margin-bottom:14px">${aIcon('alert-triangle')} ${t('True multi-academic-year comparison requires more than one year of historical data. This institution currently has one real academic year on record (2025-2026) — the comparison below is genuine Term 1 vs Term 2 data within that year.')}</div>
    <div class="card"><div class="card-header"><div class="card-title">${t('Term 1 vs Term 2 — 2025-2026')}</div></div>
      <div class="card-body">
        ${termComp.map(c => {
          if (c.current === null || c.previous === null) return `<div class="info-row"><span>${t(c.label)}</span><span style="color:var(--muted)">${t('No data')}</span></div>`;
          const delta = c.current - c.previous;
          const improved = c.higherIsBetter ? delta >= 0 : delta <= 0;
          return `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="authrenGoTo('${c.route}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();authrenGoTo('${c.route}')}"><span>${t(c.label)}</span><span style="color:${improved?'var(--green)':'var(--red)'}">${schFormatMetricValue(c.previous, c.unit)} → ${schFormatMetricValue(c.current, c.unit)}</span></div>`;
        }).join('')}
      </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Available Academic Years')}</div></div>
      <div class="card-body">${SCH_AVAILABLE_ACADEMIC_YEARS.map(y => `<div class="info-row"><span>${y}</span><span class="status-pill paid">${t('Current')}</span></div>`).join('')}
        <div style="font-size:11px;color:var(--muted);margin-top:8px">${t('Additional years will appear here automatically as more academic history accumulates.')}</div>
      </div></div>`;
}

/* ══════════════════════════════════════════════════════
   PROBLEM DETECTION (section 25)
   Absolute current-state thresholds — distinct from What Changed?'s
   month-over-month deltas. Each problem shows severity, current value,
   previous value where genuinely available, and why it was detected.
══════════════════════════════════════════════════════ */
function schDetectProblems() {
  const problems = [];
  SCHOOL_DATA.campuses.forEach(c => {
    const students = schCampusStudents(c.id);
    if (!students.length) return;
    const attAgg = schAggregateAttendance(students.map(s=>s.id), SCH_ATTENDANCE_DAYS);
    if (attAgg.rate !== null && attAgg.rate < SCHOOL_DATA.settings.attendanceThreshold) {
      const prevDays = SCH_ATTENDANCE_DAYS.filter(d => d.startsWith('2026-02'));
      const prevRate = prevDays.length ? schAggregateAttendance(students.map(s=>s.id), prevDays).rate : null;
      problems.push({ title:`${t('Declining Attendance')}: ${c.name}`, severity: attAgg.rate < 75 ? 'high' : 'medium', affectedGroup:c.name, metric:`${attAgg.rate}%`, previousValue: prevRate!==null?`${prevRate}%`:null, reason:`${c.name} ${t('has an attendance rate of')} ${attAgg.rate}%, ${t('below the expected 85% threshold.')}`, route:'analytics-basic' });
    }
    const academicAvg = schAvg(students.map(s => s.avgGrade));
    if (academicAvg !== null && academicAvg < SCHOOL_DATA.settings.passThreshold) {
      const prevAvg = schAvg(students.map(s => s.prevTermAvgGrade));
      problems.push({ title:`${t('Declining Academic Performance')}: ${c.name}`, severity: academicAvg < SCHOOL_DATA.settings.passThreshold - 2 ? 'high' : 'medium', affectedGroup:c.name, metric:`${academicAvg}/20`, previousValue: prevAvg!==null?`${prevAvg}/20`:null, reason:`${c.name} ${t('has an average grade of')} ${academicAvg}/20, ${t('below the expected')} ${SCHOOL_DATA.settings.passThreshold}/20 ${t('threshold.')}`, route:'analytics-basic' });
    }
    const campusPayments = SCHOOL_DATA.payments.filter(p => p.campusId === c.id);
    const overdue = campusPayments.filter(p => p.status === 'overdue').reduce((s,p)=>s+p.amount,0);
    const total = campusPayments.reduce((s,p)=>s+p.amount,0);
    if (total && overdue / total >= 0.15) {
      problems.push({ title:`${t('Rising Overdue Payments')}: ${c.name}`, severity: overdue/total >= 0.3 ? 'high' : 'medium', affectedGroup:c.name, metric:`${Math.round(overdue/total*100)}%`, previousValue:null, reason:`${Math.round(overdue/total*100)}% ${t('of payments at')} ${c.name} ${t('are overdue.')}`, route:'payment-records' });
    }
  });
  const comp = schComputeMonthComparison();
  const admissionsComp = comp.find(c => c.id === 'admissions');
  if (admissionsComp.current !== null && admissionsComp.previous !== null && admissionsComp.previous > 0 && admissionsComp.current < admissionsComp.previous * 0.5) {
    problems.push({ title:t('Admissions Slowdown'), severity:'medium', affectedGroup:t('Institution-wide'), metric:String(admissionsComp.current), previousValue:String(admissionsComp.previous), reason:`${t('Admissions submissions dropped from')} ${admissionsComp.previous} ${t('to')} ${admissionsComp.current} ${t('month-over-month.')}`, route:'admissions' });
  }
  const complaintsComp = comp.find(c => c.id === 'complaints');
  if (complaintsComp.current !== null && complaintsComp.previous !== null && complaintsComp.current > complaintsComp.previous && complaintsComp.current >= 2) {
    problems.push({ title:t('Increasing Complaints'), severity: complaintsComp.current >= 4 ? 'high' : 'medium', affectedGroup:t('Institution-wide'), metric:String(complaintsComp.current), previousValue:String(complaintsComp.previous), reason:`${t('Reclamations increased from')} ${complaintsComp.previous} ${t('to')} ${complaintsComp.current} ${t('month-over-month.')}`, route:'reclamations' });
  }
  const opActivityByDay = {};
  SCHOOL_DATA.auditLog.forEach(a => { opActivityByDay[a.date] = (opActivityByDay[a.date]||0)+1; });
  const avgDaily = Object.keys(opActivityByDay).length ? schAvg(Object.values(opActivityByDay)) : null;
  const maxDaily = Object.keys(opActivityByDay).length ? Math.max(...Object.values(opActivityByDay)) : null;
  if (avgDaily !== null && maxDaily !== null && maxDaily > avgDaily * 3 && maxDaily >= 5) {
    problems.push({ title:t('Unusual Operational Activity'), severity:'low', affectedGroup:t('Institution-wide'), metric:`${maxDaily} ${t('actions in one day')}`, previousValue:`${t('avg')} ${Math.round(avgDaily)}/${t('day')}`, reason:t('One day recorded significantly more administrative actions than the typical daily average.'), route:'audit' });
  }
  return problems.sort((a,b) => ({high:0,medium:1,low:2}[a.severity]-{high:0,medium:1,low:2}[b.severity]));
}
function schProblemDetectionView() {
  const problems = schDetectProblems();
  const sm = { high:{cls:'overdue',label:'High'}, medium:{cls:'awaiting',label:'Medium'}, low:{cls:'resolved',label:'Low'} };
  return `
    <div style="font-size:12px;color:var(--muted);margin-bottom:14px">${t('Detected using fixed thresholds against current data — each problem shows its metric, prior value where available, and why it was flagged.')}</div>
    ${problems.length ? problems.map(p => { const meta = sm[p.severity]; return `<div class="card" style="margin-bottom:10px;cursor:pointer" role="button" tabindex="0" onclick="authrenGoTo('${p.route}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();authrenGoTo('${p.route}')}"><div class="card-body">
      <div style="display:flex;justify-content:space-between;align-items:flex-start">
        <div style="font-weight:700;font-size:13px">${schEsc(p.title)}</div>
        <span class="status-pill ${meta.cls}">${t(meta.label)}</span>
      </div>
      <div style="font-size:12px;color:var(--muted2);margin-top:6px">${schEsc(p.reason)}</div>
      <div style="font-size:11px;color:var(--muted);margin-top:6px">${t('Affected')}: ${schEsc(p.affectedGroup)} · ${t('Current')}: ${schEsc(p.metric)}${p.previousValue?` · ${t('Previous')}: ${schEsc(p.previousValue)}`:''}</div>
    </div></div>`; }).join('') : `<div class="gd-empty-state"><div class="gd-empty-state-title">${t('No problems detected')}</div><div class="gd-empty-state-sub">${t('All campuses and metrics are currently within expected thresholds.')}</div></div>`}`;
}

/* ══════════════════════════════════════════════════════
   ADVANCED SCHOOL INTELLIGENCE (section 26)
   Deterministic frontend rules connecting multiple real datasets —
   never presented as more than that. Every insight states exactly which
   condition triggered it and the real numbers behind it.
══════════════════════════════════════════════════════ */
function schComputeIntelligenceInsights() {
  const insights = [];
  const comp = schComputeMonthComparison();
  const att = comp.find(c => c.id === 'attendance');
  const payments = comp.find(c => c.id === 'payments');
  const admissions = comp.find(c => c.id === 'admissions');

  // Attendance Risk: Attendance down + high absence frequency
  const highAbsenceStudents = SCHOOL_DATA.students.filter(s => {
    const absences = SCH_ATTENDANCE_DAYS.filter(d => schAttendanceStatusFor(s.id, d) === 'absent').length;
    return absences >= 3;
  });
  if (att.current !== null && att.previous !== null && att.current < att.previous && highAbsenceStudents.length > 0) {
    insights.push({ title:t('Attendance Risk'), route:'analytics-basic', rule:t('Attendance rate is declining AND multiple students have high absence frequency'), evidence:`${t('Attendance')}: ${att.previous}% → ${att.current}% · ${highAbsenceStudents.length} ${t('students with 3+ absences')}` });
  }

  // Financial Attention: Payment collection down + overdue up
  const totalOverdue = SCHOOL_DATA.payments.filter(p => p.status === 'overdue').reduce((s,p)=>s+p.amount,0);
  const totalDue = SCHOOL_DATA.payments.reduce((s,p)=>s+p.amount,0);
  const overduePct = totalDue ? (totalOverdue/totalDue)*100 : 0;
  if (payments.current !== null && payments.previous !== null && payments.current < payments.previous && overduePct >= 10) {
    insights.push({ title:t('Financial Attention'), route:'payments', rule:t('Payment collection is declining AND overdue balance is significant'), evidence:`${t('Collected')}: ${schCurrency(payments.previous)} → ${schCurrency(payments.current)} · ${Math.round(overduePct)}% ${t('overdue')}` });
  }

  // Admissions Attention: significant decline
  if (admissions.current !== null && admissions.previous !== null && admissions.previous > 0 && admissions.current <= admissions.previous * 0.5) {
    insights.push({ title:t('Admissions Attention'), route:'admissions', rule:t('Admissions submissions declined significantly (50% or more) month-over-month'), evidence:`${t('Admissions')}: ${admissions.previous} → ${admissions.current}` });
  }

  // Academic Attention: overall average below threshold
  const academicAvg = schAvg(SCHOOL_DATA.students.map(s => s.avgGrade));
  if (academicAvg !== null && academicAvg < SCHOOL_DATA.settings.passThreshold) {
    insights.push({ title:t('Academic Attention'), route:'analytics-basic', rule:`${t('Overall academic average is below the expected')} ${SCHOOL_DATA.settings.passThreshold}/20 ${t('threshold')}`, evidence:`${t('Academic Average')}: ${academicAvg}/20` });
  }

  return insights;
}
function schIntelligenceView() {
  const insights = schComputeIntelligenceInsights();
  return `
    <div style="background:rgba(203,213,225,0.1);border:1px solid rgba(203,213,225,0.3);border-radius:10px;padding:10px 12px;font-size:11.5px;color:var(--muted2);margin-bottom:14px">${t('This is deterministic logic connecting real institutional data. Every insight below states exactly which condition triggered it.')}</div>
    ${insights.length ? insights.map(i => `<div class="card" style="margin-bottom:10px;cursor:pointer" role="button" tabindex="0" onclick="authrenGoTo('${i.route}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();authrenGoTo('${i.route}')}"><div class="card-body">
      <div style="font-weight:700;font-size:13px">${schEsc(i.title)}</div>
      <div style="font-size:12px;color:var(--muted2);margin-top:6px">${t('Rule')}: ${schEsc(i.rule)}</div>
      <div style="font-size:11.5px;color:var(--muted);margin-top:6px">${schEsc(i.evidence)}</div>
    </div></div>`).join('') : `<div class="gd-empty-state"><div class="gd-empty-state-title">${t('No combined warning conditions currently met')}</div><div class="gd-empty-state-sub">${t('None of the tracked cross-domain rules are currently triggered by real data.')}</div></div>`}`;
}

/* ══════════════════════════════════════════════════════
   ADVANCED PAYMENTS (section 30)
   Deeper payment analytics: outstanding/overdue breakdown, collection
   trends, billing categories, method distribution, campus comparison,
   and historical comparison — reusing the real period-comparison engine.
══════════════════════════════════════════════════════ */
function schPaymentsAdvancedView() {
  const totalOutstanding = SCHOOL_DATA.payments.filter(p => p.status === 'pending').reduce((s,p)=>s+p.amount,0);
  const totalOverdue = SCHOOL_DATA.payments.filter(p => p.status === 'overdue').reduce((s,p)=>s+p.amount,0);
  const byMonth = {};
  SCHOOL_DATA.payments.filter(p=>p.status==='paid').forEach(p => { const m = p.date.slice(0,7); byMonth[m] = (byMonth[m]||0)+p.amount; });
  const byCategory = {};
  SCHOOL_DATA.payments.forEach(p => { byCategory[p.description] = (byCategory[p.description]||0) + p.amount; });
  const byMethod = {};
  SCHOOL_DATA.payments.filter(p=>p.status==='paid').forEach(p => { byMethod[p.method] = (byMethod[p.method]||0)+1; });
  const campusComparison = SCHOOL_DATA.campuses.map(c => {
    const payments = SCHOOL_DATA.payments.filter(p => p.campusId === c.id);
    const total = payments.reduce((s,p)=>s+p.amount,0);
    const collected = payments.filter(p=>p.status==='paid').reduce((s,p)=>s+p.amount,0);
    return { campus:c, rate: total ? Math.round((collected/total)*100) : null };
  }).sort((a,b) => (b.rate||0)-(a.rate||0));
  const termComp = schComputePeriodComparison('term').find(c => c.id === 'payments');

  return `
    <div class="card"><div class="card-header"><div class="card-title">${t('Outstanding Balances')}</div></div>
      <div class="card-body">
        <div class="info-row"><span>${t('Pending')}</span><span>${schCurrency(totalOutstanding)}</span></div>
        <div class="info-row"><span>${t('Overdue')}</span><span style="color:var(--red)">${schCurrency(totalOverdue)}</span></div>
      </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Collection Trend by Month')}</div></div>
      <div class="card-body">${Object.keys(byMonth).sort().map(m => `<div class="info-row"><span>${m}</span><span style="color:var(--green)">${schCurrency(byMonth[m])}</span></div>`).join('')}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Billing Categories')}</div></div>
      <div class="card-body">${Object.keys(byCategory).map(cat => `<div class="info-row"><span>${schEsc(cat)}</span><span style="color:var(--muted)">${schCurrency(byCategory[cat])}</span></div>`).join('')}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Payment Method Distribution')}</div></div>
      <div class="card-body">${Object.keys(byMethod).map(m => `<div class="info-row"><span>${schEsc(m)}</span><span style="color:var(--muted)">${byMethod[m]}</span></div>`).join('')}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Campus Comparison')}</div><span style="font-size:12px;color:var(--muted)">${t('Collection rate')}</span></div>
      <div class="card-body">${campusComparison.map(c => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="schSetPayRecCampus('${c.campus.id}');authrenGoTo('payment-records')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();schSetPayRecCampus('${c.campus.id}');authrenGoTo('payment-records')}"><span>${schEsc(c.campus.name)}</span><span style="color:var(--muted)">${c.rate!==null?c.rate+'%':'—'}</span></div>`).join('')}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Historical Comparison')}</div><span style="font-size:12px;color:var(--muted)">${t('Term over term')}</span></div>
      <div class="card-body">${termComp.current!==null&&termComp.previous!==null ? `<div class="info-row"><span>${t('Previous Term')}</span><span>${schCurrency(termComp.previous)}</span></div><div class="info-row"><span>${t('Current Term')}</span><span>${schCurrency(termComp.current)}</span></div>` : `<div class="gd-empty-mini">${t('Not enough data to compare.')}</div>`}</div></div>`;
}

/* ══════════════════════════════════════════════════════
   ADVANCED PAYMENT INFRASTRUCTURE (section 31)
   Genuine invoice creation and tracking workflow. No real external
   payment-provider integration — marking an invoice "paid" here is a
   frontend-only reconciliation action, clearly presented as such.
══════════════════════════════════════════════════════ */
SCHOOL_DATA.invoices = [];
let schState_invoiceForm = null;
function schPaymentsInfraView() {
  return `<div id="sch-invoices-content">${schInvoicesBody()}</div>`;
}
function schInvoicesBody() {
  if (schState_invoiceForm) return schInvoiceFormScreen();
  const invoices = SCHOOL_DATA.invoices.slice().sort((a,b) => b.dueDate.localeCompare(a.dueDate));
  const statusMeta = { unpaid:{cls:'due',label:'Unpaid'}, paid:{cls:'paid',label:'Paid'}, overdue:{cls:'overdue',label:'Overdue'}, cancelled:{cls:'resolved',label:'Cancelled'} };
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Invoices')}</div><button class="st-btn sm" onclick="schOpenInvoiceForm()">+ ${t('Create Invoice')}</button></div>
    <div class="card-body">
      ${invoices.length ? invoices.map(inv => { const st = schGetStudent(inv.studentId); const meta = statusMeta[inv.status]; return `<div class="info-row"><span>${st?schEsc(schStudentFullName(st)):'—'}<div style="font-size:11px;color:var(--muted)">${schEsc(inv.description)} · ${t('Due')} ${inv.dueDate}</div></span><span style="text-align:right">${schCurrency(inv.amount)}<div style="margin-top:4px;display:flex;gap:6px;align-items:center;justify-content:flex-end"><span class="status-pill ${meta.cls}">${t(meta.label)}</span>${inv.status==='unpaid'||inv.status==='overdue'?`<button type="button" class="st-btn ghost sm" onclick="schMarkInvoicePaid('${inv.id}')">${t('Mark Paid')}</button>`:''}</div></span></div>`; }).join('') : `<div class="gd-empty-mini">${t('No invoices created yet.')}</div>`}
    </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Payment Reconciliation')}</div></div>
      <div class="card-body">
        <div class="info-row"><span>${t('Invoiced (Unpaid + Overdue)')}</span><span>${schCurrency(SCHOOL_DATA.invoices.filter(i=>i.status==='unpaid'||i.status==='overdue').reduce((s,i)=>s+i.amount,0))}</span></div>
        <div class="info-row"><span>${t('Invoiced (Paid)')}</span><span style="color:var(--green)">${schCurrency(SCHOOL_DATA.invoices.filter(i=>i.status==='paid').reduce((s,i)=>s+i.amount,0))}</span></div>
        <div class="info-row"><span>${t('Total Payment Records')}</span><span>${SCHOOL_DATA.payments.length}</span></div>
      </div></div>`;
}
function schRefreshInvoices() { const el = document.getElementById('sch-invoices-content'); if (el) el.innerHTML = schInvoicesBody(); }
function schOpenInvoiceForm() {
  schState_invoiceForm = { studentId:'', description:SCHOOL_DATA.settings.paymentCategories[0], amount:'', dueDate:'', error:'' };
  schRefreshInvoices();
}
function schCancelInvoiceForm() { schState_invoiceForm = null; schRefreshInvoices(); }
function schInvoiceFormScreen() {
  const f = schState_invoiceForm;
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Create Invoice')}</div></div>
    <div class="card-body">
      <div style="background:rgba(217,119,6,0.1);border:1px solid rgba(217,119,6,0.3);border-radius:10px;padding:10px 12px;font-size:11.5px;color:var(--muted2);margin-bottom:14px">${t('This creates a frontend invoice record only — no real payment provider is contacted.')}</div>
      <div class="st-field"><label>${t('Student')}</label><select id="sch-inv-student">
        ${SCHOOL_DATA.students.map(s => `<option value="${s.id}">${schEsc(schStudentFullName(s))}</option>`).join('')}
      </select></div>
      <div class="st-field"><label>${t('Description')}</label><select id="sch-inv-description">
        ${SCHOOL_DATA.settings.paymentCategories.map(cat => `<option value="${schEsc(cat)}" ${cat===f.description?'selected':''}>${schEsc(cat)}</option>`).join('')}
      </select></div>
      <div class="st-field"><label>${t('Amount (MAD)')}</label><input id="sch-inv-amount" type="number" min="1" value="${f.amount}"></div>
      <div class="st-field"><label>${t('Due Date')}</label><input id="sch-inv-duedate" type="date" value="${f.dueDate}"></div>
      <div style="display:flex;gap:10px">
        <button class="st-btn" onclick="schSaveInvoice()">${t('Create Invoice')}</button>
        <button class="st-btn ghost" onclick="schCancelInvoiceForm()">${t('Cancel')}</button>
      </div>
      ${f.error ? `<div class="st-inline-msg err show" style="margin-top:12px">${f.error}</div>` : ''}
    </div></div>`;
}
function schSaveInvoice() {
  const f = schState_invoiceForm;
  const studentId = document.getElementById('sch-inv-student').value;
  const description = (document.getElementById('sch-inv-description').value || '').trim();
  const amount = parseFloat(document.getElementById('sch-inv-amount').value);
  const dueDate = document.getElementById('sch-inv-duedate').value;
  let err = '';
  if (!description) err = t('Description is required.');
  else if (isNaN(amount) || amount <= 0) err = t('Enter a valid amount.');
  else if (!dueDate) err = t('Select a due date.');
  if (err) { f.error = err; schRefreshInvoices(); return; }
  const student = schGetStudent(studentId);
  const status = dueDate < SCH_TODAY ? 'overdue' : 'unpaid';
  const newInvoice = { id:'sinv' + Date.now(), studentId, campusId: student.campusId, description, amount, dueDate, status };
  SCHOOL_DATA.invoices.push(newInvoice);
  schLogAudit('Invoice Created', 'Invoice', description, '', schCurrency(amount));
  schState_invoiceForm = null;
  schRefreshInvoices();
  schShowToast(t('Invoice created successfully.'));
}
function schMarkInvoicePaid(id) {
  const inv = SCHOOL_DATA.invoices.find(i => i.id === id);
  if (!inv) return;
  inv.status = 'paid';
  authrenSeedPayment({ source:'school',  id:'spay-inv-' + inv.id, studentId:inv.studentId, campusId:inv.campusId, date:SCH_TODAY, description:inv.description, amount:inv.amount, currency:'MAD', status:'paid', method:'Bank Transfer', reference:'RCPT-INV-' + inv.id.slice(-6) });
  schLogAudit('Invoice Paid', 'Invoice', inv.description, 'unpaid', 'paid');
  schRefreshInvoices();
  schShowToast(t('Invoice marked as paid and recorded in payment records.'));
}

/* ══════════════════════════════════════════════════════
   ADVANCED INSTITUTION CONFIGURATION (section 36)
   Every setting here genuinely affects other real screens: pass/
   attendance thresholds feed Problem Detection and School Intelligence
   live; the logo appears on the Dashboard and receipts; payment
   categories populate the real Invoice creation dropdown.
══════════════════════════════════════════════════════ */
let schState_configEditing = false;
let schState_configError = '';
function schConfigView() { return `<div id="sch-config-content">${schConfigBody()}</div>`; }
function schConfigBody() {
  if (schState_configEditing) return schConfigEditForm();
  const inst = SCHOOL_DATA.institution;
  const s = SCHOOL_DATA.settings;
  return `
    <div class="card"><div class="card-header"><div class="card-title">${t('Institution Profile')}</div><button class="st-btn ghost sm" onclick="schOpenConfigEdit()">${t('Edit')}</button></div>
      <div class="card-body">
        ${s.logoDataUrl ? `<div style="margin-bottom:10px"><img src="${s.logoDataUrl}" alt="${t('Institution logo')}" style="width:64px;height:64px;border-radius:14px;object-fit:cover"></div>` : ''}
        <div class="info-row"><span>${t('Name')}</span><span>${schEsc(inst.name)}</span></div>
        <div class="info-row"><span>${t('Address')}</span><span>${schEsc(inst.address)}</span></div>
        <div class="info-row"><span>${t('Academic Year')}</span><span>${schEsc(inst.academicYear)}</span></div>
      </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Terms / Semesters')}</div></div>
      <div class="card-body">${s.terms.map((term,idx) => `<div class="info-row"><span>${schEsc(term)}</span><button type="button" class="st-btn ghost sm" onclick="schRemoveTerm(${idx})">${t('Remove')}</button></div>`).join('')}
        <div style="display:flex;gap:8px;margin-top:8px"><input id="sch-new-term" placeholder="${t('New term name')}" style="flex:1;background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px"><button type="button" class="st-btn ghost sm" onclick="schAddTerm()">${t('Add')}</button></div>
      </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Grading & Attendance Rules')}</div></div>
      <div class="card-body">
        <div style="font-size:11px;color:var(--muted);margin-bottom:8px">${t('These thresholds feed Problem Detection and School Intelligence live across every campus.')}</div>
        <div class="info-row"><span>${t('Pass / Attention Threshold')}</span><span>${s.passThreshold}/20</span></div>
        <div class="info-row"><span>${t('Attendance Threshold')}</span><span>${s.attendanceThreshold}%</span></div>
      </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Payment Categories')}</div></div>
      <div class="card-body">${s.paymentCategories.map((cat,idx) => `<div class="info-row"><span>${schEsc(cat)}</span><button type="button" class="st-btn ghost sm" onclick="schRemovePaymentCategory(${idx})">${t('Remove')}</button></div>`).join('')}
        <div style="display:flex;gap:8px;margin-top:8px"><input id="sch-new-category" placeholder="${t('New category name')}" style="flex:1;background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px"><button type="button" class="st-btn ghost sm" onclick="schAddPaymentCategory()">${t('Add')}</button></div>
        <div style="font-size:11px;color:var(--muted);margin-top:8px">${t('These categories populate the Description dropdown when creating an invoice.')}</div>
      </div></div>`;
}
function schRefreshConfig() { const el = document.getElementById('sch-config-content'); if (el) el.innerHTML = schConfigBody(); }
function schOpenConfigEdit() { schState_configEditing = true; schState_configError = ''; schRefreshConfig(); }
function schCancelConfigEdit() { schState_configEditing = false; schRefreshConfig(); }
function schConfigEditForm() {
  const inst = SCHOOL_DATA.institution;
  const s = SCHOOL_DATA.settings;
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Edit Institution Configuration')}</div></div>
    <div class="card-body">
      <div class="st-field"><label>${t('Logo')} (${t('optional')})</label>
        ${s.logoDataUrl ? `<img src="${s.logoDataUrl}" alt="" style="width:48px;height:48px;border-radius:10px;object-fit:cover;margin-bottom:8px;display:block">` : ''}
        <input type="file" id="sch-cfg-logo" accept="image/*" onchange="schHandleLogoFile(this)">
      </div>
      <div class="st-field"><label>${t('Name')}</label><input id="sch-cfg-name" value="${schEsc(inst.name)}"></div>
      <div class="st-field"><label>${t('Address')}</label><input id="sch-cfg-address" value="${schEsc(inst.address)}"></div>
      <div class="st-field"><label>${t('Academic Year')}</label><input id="sch-cfg-year" value="${schEsc(inst.academicYear)}"></div>
      <div class="st-field"><label>${t('Pass / Attention Threshold (out of 20)')}</label><input id="sch-cfg-passthreshold" type="number" min="0" max="20" value="${s.passThreshold}"></div>
      <div class="st-field"><label>${t('Attendance Threshold (%)')}</label><input id="sch-cfg-attthreshold" type="number" min="0" max="100" value="${s.attendanceThreshold}"></div>
      <div style="display:flex;gap:10px">
        <button class="st-btn" onclick="schSaveConfig()">${t('Save Changes')}</button>
        <button class="st-btn ghost" onclick="schCancelConfigEdit()">${t('Cancel')}</button>
      </div>
      ${schState_configError ? `<div class="st-inline-msg err show" style="margin-top:12px">${schState_configError}</div>` : ''}
    </div></div>`;
}
function schHandleLogoFile(input) {
  const file = input.files && input.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = function(e) {
    SCHOOL_DATA.settings.logoDataUrl = e.target.result;
    schRefreshConfig();
    schShowToast(t('Logo updated — preview shown below.'));
  };
  reader.readAsDataURL(file);
}
function schSaveConfig() {
  const name = (document.getElementById('sch-cfg-name').value || '').trim();
  const address = (document.getElementById('sch-cfg-address').value || '').trim();
  const academicYear = (document.getElementById('sch-cfg-year').value || '').trim();
  const passThreshold = Number(document.getElementById('sch-cfg-passthreshold').value);
  const attendanceThreshold = Number(document.getElementById('sch-cfg-attthreshold').value);
  let err = '';
  if (!name) err = t('Institution name is required.');
  else if (isNaN(passThreshold) || passThreshold < 0 || passThreshold > 20) err = t('Pass threshold must be between 0 and 20.');
  else if (isNaN(attendanceThreshold) || attendanceThreshold < 0 || attendanceThreshold > 100) err = t('Attendance threshold must be between 0 and 100.');
  if (err) { schState_configError = err; schRefreshConfig(); return; }
  const oldName = SCHOOL_DATA.institution.name;
  Object.assign(SCHOOL_DATA.institution, { name, address, academicYear });
  const oldPassThreshold = SCHOOL_DATA.settings.passThreshold;
  Object.assign(SCHOOL_DATA.settings, { passThreshold, attendanceThreshold });
  schLogAudit('Configuration Changed', 'Institution Configuration', name, oldName, name);
  if (oldPassThreshold !== passThreshold) schLogAudit('Configuration Changed', 'Grading Threshold', 'Pass Threshold', oldPassThreshold + '/20', passThreshold + '/20');
  schState_configEditing = false;
  schRefreshConfig();
  schShowToast(t('Institution configuration updated successfully.'));
}
function schAddTerm() {
  const val = (document.getElementById('sch-new-term').value || '').trim();
  if (!val) return;
  SCHOOL_DATA.settings.terms.push(val);
  schRefreshConfig();
  schShowToast(t('Term added.'));
}
function schRemoveTerm(idx) {
  SCHOOL_DATA.settings.terms.splice(idx, 1);
  schRefreshConfig();
  schShowToast(t('Term removed.'));
}
function schAddPaymentCategory() {
  const val = (document.getElementById('sch-new-category').value || '').trim();
  if (!val) return;
  SCHOOL_DATA.settings.paymentCategories.push(val);
  schRefreshConfig();
  schShowToast(t('Payment category added.'));
}
function schRemovePaymentCategory(idx) {
  SCHOOL_DATA.settings.paymentCategories.splice(idx, 1);
  schRefreshConfig();
  schShowToast(t('Payment category removed.'));
}

/* ══════════════════════════════════════════════════════
   ADVANCED ADMINISTRATION (section 32)
   Centralized hub across every settings surface — genuine links into
   the real dedicated pages, plus real Account/Access controls for the
   owner that don't belong anywhere else.
══════════════════════════════════════════════════════ */
function schAdminAdvancedView() { return `<div id="sch-admin-adv-content">${schAdminAdvancedBody()}</div>`; }
function schAdminAdvancedBody() {
  return `
    <div class="card"><div class="card-header"><div class="card-title">${t('Settings Areas')}</div></div>
      <div class="card-body">
        <div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="authrenGoTo('config')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();authrenGoTo('config')}"><span>${aIcon('school')} ${t('Institution & Academic Settings')}</span><span class="card-action">${t('Open')} →</span></div>
        <div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="authrenGoTo('config')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();authrenGoTo('config')}"><span>${aIcon('clipboard')} ${t('Attendance Rules')}</span><span class="card-action">${t('Open')} →</span></div>
        <div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="authrenGoTo('config')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();authrenGoTo('config')}"><span>${aIcon('credit-card')} ${t('Payment Categories')}</span><span class="card-action">${t('Open')} →</span></div>
        <div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="authrenGoTo('communication')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();authrenGoTo('communication')}"><span>${aIcon('mail')} ${t('Communication Settings')}</span><span class="card-action">${t('Open')} →</span></div>
        <div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="authrenGoTo('calendar')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();authrenGoTo('calendar')}"><span>${aIcon('calendar')} ${t('Calendar Settings')}</span><span class="card-action">${t('Open')} →</span></div>
        <div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="authrenGoTo('data-management')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();authrenGoTo('data-management')}"><span>${aIcon('folder')} ${t('Data Settings')}</span><span class="card-action">${t('Open')} →</span></div>
        <div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="authrenGoTo('campuses')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();authrenGoTo('campuses')}"><span>${aIcon('building')} ${t('Campus Settings')}</span><span class="card-action">${t('Open')} →</span></div>
        <div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="authrenGoTo('branding')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();authrenGoTo('branding')}"><span>${aIcon('palette')} ${t('Branding Settings')}</span><span class="card-action">${t('Open')} →</span></div>
      </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Account & Access')}</div></div>
      <div class="card-body">
        <div class="info-row"><span>${t('Owner')}</span><span>${schEsc(SCHOOL_DATA.owner.name)}</span></div>
        <div class="info-row"><span>${t('Access Type')}</span><span class="status-pill paid">${t('Institution Owner')}</span></div>
        <div id="sch-admin-pw-area" style="margin-top:10px">
          ${schState_adminPwEditing ? schAdminPasswordFormBlock() : `<button class="st-btn ghost sm" onclick="schOpenAdminPasswordForm()">${t('Change Owner Password')}</button>`}
        </div>
      </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Role Separation')}</div></div>
      <div class="card-body">
        <div style="font-size:12px;color:var(--muted2);line-height:1.6">${t('The Institution Owner role controls institution-wide finances, subscription, multi-campus configuration, and business administration. The Head of Institution role focuses on day-to-day school operations and does not have access to subscription management, invoicing, or campus creation. These are separate accounts with separate permissions — not shared dashboards.')}</div>
      </div></div>`;
}
let schState_adminPwEditing = false;
let schState_adminPwError = '';
let schState_adminPwSuccess = false;
function schOpenAdminPasswordForm() { schState_adminPwEditing = true; schState_adminPwError = ''; schState_adminPwSuccess = false; schRefreshAdminAdv(); }
function schCancelAdminPasswordForm() { schState_adminPwEditing = false; schRefreshAdminAdv(); }
function schRefreshAdminAdv() { const el = document.getElementById('sch-admin-adv-content'); if (el) el.innerHTML = schAdminAdvancedBody(); }
function schAdminPasswordFormBlock() {
  return `<div class="st-field"><label>${t('Current Password')}</label><input type="password" id="sch-adm-pw-cur"></div>
    <div class="st-field"><label>${t('New Password')}</label><input type="password" id="sch-adm-pw-new"></div>
    <div class="st-field"><label>${t('Confirm New Password')}</label><input type="password" id="sch-adm-pw-confirm"></div>
    <div style="display:flex;gap:10px">
      <button class="st-btn sm" onclick="schChangeOwnerPassword()">${t('Update Password')}</button>
      <button class="st-btn ghost sm" onclick="schCancelAdminPasswordForm()">${t('Cancel')}</button>
    </div>
    ${schState_adminPwSuccess ? `<div class="st-inline-msg ok show" style="margin-top:10px">${t('Password updated successfully.')}</div>` : ''}
    ${schState_adminPwError ? `<div class="st-inline-msg err show" style="margin-top:10px">${schState_adminPwError}</div>` : ''}`;
}
function schChangeOwnerPassword() {
  const cur = document.getElementById('sch-adm-pw-cur').value;
  const nw = document.getElementById('sch-adm-pw-new').value;
  const cf = document.getElementById('sch-adm-pw-confirm').value;
  schState_adminPwSuccess = false;
  if (!cur) { schState_adminPwError = t('Please enter your current password.'); schRefreshAdminAdv(); return; }
  if (cur !== SCHOOL_DATA.owner.password) { schState_adminPwError = t('Current password is incorrect.'); schRefreshAdminAdv(); return; }
  if (!nw || nw.length < 6) { schState_adminPwError = t('New password must be at least 6 characters.'); schRefreshAdminAdv(); return; }
  if (nw !== cf) { schState_adminPwError = t('Passwords do not match.'); schRefreshAdminAdv(); return; }
  SCHOOL_DATA.owner.password = nw;
  schLogAudit('Configuration Changed', 'Owner Account', 'Password', '', 'updated');
  schState_adminPwError = '';
  schState_adminPwSuccess = true;
  schRefreshAdminAdv();
}

/* ══════════════════════════════════════════════════════
   MULTI-CAMPUS SUPPORT / CAMPUS MANAGEMENT (section 37)
   Real create/edit/activate/deactivate — the campus selector already
   built into the Dashboard and Analytics (batch 1+) genuinely reflects
   whatever campuses exist here, including newly created ones.
══════════════════════════════════════════════════════ */
function schCampusesView() { return `<div id="sch-campuses-content">${schCampusesBody()}</div>`; }
function schCampusesBody() {
  const s = schState.campuses;
  if (s.screen === 'form') return schCampusFormScreen();
  if (s.screen === 'detail') { const c = schGetCampus(s.campusId); if (!c) { s.screen = 'list'; return schCampusesBody(); } return schCampusDetailScreen(c); }
  return schCampusListScreen();
}
function schRefreshCampuses() { const el = document.getElementById('sch-campuses-content'); if (el) el.innerHTML = schCampusesBody(); }
function schCampusListScreen() {
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Campus Management')}</div><button class="st-btn sm" onclick="schOpenCampusForm()">+ ${t('Add Campus')}</button></div>
    <div class="card-body">
      ${SCHOOL_DATA.campuses.map(c => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="schOpenCampusDetail('${c.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();schOpenCampusDetail('${c.id}')}">
        <span>${schEsc(c.name)}<div style="font-size:11px;color:var(--muted)">${schCampusStudents(c.id).length} ${t('students')} · ${schCampusTeachers(c.id).length} ${t('teachers')} · ${schCampusClasses(c.id).length} ${t('classes')}</div></span>
        <span class="status-pill ${c.status==='active'?'paid':'overdue'}">${t(c.status.charAt(0).toUpperCase()+c.status.slice(1))}</span>
      </div>`).join('')}
    </div></div>`;
}
function schOpenCampusDetail(id) { schState.campuses.screen = 'detail'; schState.campuses.campusId = id; schRefreshCampuses(); }
function schBackToCampusList() { schState.campuses.screen = 'list'; schState.campuses.campusId = null; schRefreshCampuses(); }
function schCampusDetailScreen(c) {
  const students = schCampusStudents(c.id);
  const teachers = schCampusTeachers(c.id);
  const classes = schCampusClasses(c.id);
  return `<div class="card"><div class="card-header">
    <div style="display:flex;align-items:center;gap:10px;min-width:0;flex:1"><button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="schBackToCampusList()">${t('← Back')}</button><div class="card-title" style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${schEsc(c.name)}</div></div>
    <button type="button" class="st-btn ghost sm" onclick="schOpenCampusForm('${c.id}')">${t('Edit')}</button>
  </div>
    <div class="card-body" id="sch-campus-detail-body">${schCampusDetailBody(c)}</div>
  </div>`;
}
function schCampusDetailBody(c) {
  const students = schCampusStudents(c.id);
  return `
    <div class="info-row"><span>${t('Address')}</span><span>${schEsc(c.address)}</span></div>
    <div class="info-row"><span>${t('Phone')}</span><span>${schEsc(c.phone)}</span></div>
    <div class="info-row"><span>${t('Opened')}</span><span>${c.openedYear}</span></div>
    <div class="info-row"><span>${t('Status')}</span><span class="status-pill ${c.status==='active'?'paid':'overdue'}">${t(c.status.charAt(0).toUpperCase()+c.status.slice(1))}</span></div>
    <div style="margin-top:14px;padding-top:14px;border-top:0.5px solid var(--separator)">
      <div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="schDrillCampus('${c.id}','data-management')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();schDrillCampus('${c.id}','data-management')}"><span>${t('Students')}</span><span>${schCampusStudents(c.id).length}</span></div>
      <div class="info-row"><span>${t('Teachers')}</span><span>${schCampusTeachers(c.id).length}</span></div>
      <div class="info-row"><span>${t('Classes')}</span><span>${schCampusClasses(c.id).length}</span></div>
    </div>
    <div style="margin-top:14px;padding-top:14px;border-top:0.5px solid var(--separator);display:flex;gap:10px">
      <button type="button" class="st-btn sm" onclick="schSetCampusFilter('${c.id}');authrenGoTo('home')">${t('View Dashboard for this Campus')} →</button>
      ${c.status === 'active'
        ? `<button type="button" class="st-btn ghost sm" style="color:var(--red)" onclick="schToggleCampusStatus('${c.id}')" ${students.length?'disabled title="'+t('Cannot deactivate a campus with active students enrolled.')+'"':''}>${t('Deactivate')}</button>`
        : `<button type="button" class="st-btn ghost sm" onclick="schToggleCampusStatus('${c.id}')">${t('Activate')}</button>`}
    </div>
    ${c.status === 'active' && students.length ? `<div style="font-size:11px;color:var(--muted);margin-top:8px">${t('Cannot deactivate a campus with active students enrolled.')}</div>` : ''}`;
}
function schToggleCampusStatus(id) {
  const c = schGetCampus(id);
  if (!c) return;
  if (c.status === 'active' && schCampusStudents(id).length) { schShowToast(t('Cannot deactivate a campus with active students enrolled.')); return; }
  const oldStatus = c.status;
  c.status = c.status === 'active' ? 'inactive' : 'active';
  schLogAudit('Campus Changed', 'Campus', c.name, oldStatus, c.status);
  const el = document.getElementById('sch-campus-detail-body');
  if (el) el.innerHTML = schCampusDetailBody(c);
  schShowToast(`${schEsc(c.name)} ${c.status === 'active' ? t('activated') : t('deactivated')}.`);
}

/* ── Create / Edit Campus form ── */
function schOpenCampusForm(id) {
  if (id) {
    const c = schGetCampus(id);
    if (!c) return;
    schState.campuses.form = { mode:'edit', id:c.id, name:c.name, address:c.address, phone:c.phone, openedYear:c.openedYear };
  } else {
    schState.campuses.form = { mode:'create', id:null, name:'', address:'', phone:'', openedYear:2026 };
  }
  schState.campuses.screen = 'form';
  schState.campuses.error = '';
  schRefreshCampuses();
}
function schCancelCampusForm() {
  const wasEdit = schState.campuses.form && schState.campuses.form.mode === 'edit';
  const editedId = schState.campuses.form ? schState.campuses.form.id : null;
  schState.campuses.form = null;
  schState.campuses.error = '';
  if (wasEdit) { schState.campuses.screen = 'detail'; schState.campuses.campusId = editedId; } else { schState.campuses.screen = 'list'; }
  schRefreshCampuses();
}
function schCampusFormScreen() {
  const f = schState.campuses.form;
  const err = schState.campuses.error;
  return `<div class="card"><div class="card-header"><div class="card-title">${f.mode==='edit'?t('Edit Campus'):t('Add Campus')}</div></div>
    <div class="card-body">
      <div class="st-field"><label>${t('Name')}</label><input id="sch-camp-name" value="${schEsc(f.name)}"></div>
      <div class="st-field"><label>${t('Address')}</label><input id="sch-camp-address" value="${schEsc(f.address)}"></div>
      <div class="st-field"><label>${t('Phone')}</label><input id="sch-camp-phone" value="${schEsc(f.phone)}"></div>
      <div class="st-field"><label>${t('Opened Year')}</label><input id="sch-camp-year" type="number" min="1900" max="2100" value="${f.openedYear}"></div>
      <div style="display:flex;gap:10px">
        <button class="st-btn" onclick="schSaveCampus()">${f.mode==='edit'?t('Save Changes'):t('Create Campus')}</button>
        <button class="st-btn ghost" onclick="schCancelCampusForm()">${t('Cancel')}</button>
      </div>
      ${err ? `<div class="st-inline-msg err show" style="margin-top:12px">${err}</div>` : ''}
    </div></div>`;
}
function schSaveCampus() {
  const f = schState.campuses.form;
  const name = (document.getElementById('sch-camp-name').value || '').trim();
  const address = (document.getElementById('sch-camp-address').value || '').trim();
  const phone = (document.getElementById('sch-camp-phone').value || '').trim();
  const openedYear = parseInt(document.getElementById('sch-camp-year').value, 10);
  let err = '';
  if (!name) err = t('Name is required.');
  else if (f.mode === 'create' && SCHOOL_DATA.campuses.some(c => c.name.toLowerCase() === name.toLowerCase())) err = t('A campus with this name already exists.');
  else if (!address) err = t('Address is required.');
  else if (isNaN(openedYear)) err = t('Enter a valid opened year.');
  if (err) { schState.campuses.error = err; schRefreshCampuses(); return; }

  if (f.mode === 'edit') {
    const c = schGetCampus(f.id);
    Object.assign(c, { name, address, phone, openedYear });
    schLogAudit('Campus Changed', 'Campus', name, '', 'edited');
    schState.campuses.screen = 'detail';
    schState.campuses.campusId = c.id;
    schShowToast(t('Campus updated successfully.'));
  } else {
    const newCampus = { id:'camp' + Date.now(), name, address, phone, openedYear, status:'active' };
    SCHOOL_DATA.campuses.push(newCampus);
    schLogAudit('Campus Changed', 'Campus', name, '', 'created');
    schState.campuses.screen = 'detail';
    schState.campuses.campusId = newCampus.id;
    schShowToast(t('Campus created successfully. The campus selector on the Dashboard now includes it.'));
  }
  schState.campuses.form = null;
  schRefreshCampuses();
}

/* ══════════════════════════════════════════════════════
   WHITE-LABEL / CUSTOM BRANDING (section 38)
   Reuses the SAME real logo storage as Advanced Institution
   Configuration (one source of truth) with a dedicated preview of how
   it appears across supported surfaces. Authren's core design system —
   layout, accent colors, components — is left completely untouched;
   only the institution's own name/logo are customizable.
══════════════════════════════════════════════════════ */
function schBrandingView() { return `<div id="sch-branding-content">${schBrandingBody()}</div>`; }
function schBrandingBody() {
  const s = SCHOOL_DATA.settings;
  const inst = SCHOOL_DATA.institution;
  return `
    <div style="font-size:12px;color:var(--muted);margin-bottom:14px">${t('Your institution can present its own name and logo while the underlying Authren platform and design system remain unchanged.')}</div>
    <div class="card"><div class="card-header"><div class="card-title">${t('Logo & Name')}</div></div>
      <div class="card-body">
        ${s.logoDataUrl ? `<img src="${s.logoDataUrl}" alt="" style="width:56px;height:56px;border-radius:14px;object-fit:cover;margin-bottom:10px">` : `<div class="gd-empty-mini" style="text-align:left;padding:0 0 10px">${t('No logo uploaded yet.')}</div>`}
        <input type="file" id="sch-brand-logo" accept="image/*" onchange="schHandleBrandingLogoFile(this)">
        <div class="st-field" style="margin-top:12px"><label>${t('Institution Name')}</label><input id="sch-brand-name" value="${schEsc(inst.name)}"></div>
        <button class="st-btn sm" onclick="schSaveBrandingName()">${t('Save Name')}</button>
      </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Live Preview')}</div></div>
      <div class="card-body">
        <div style="font-size:11.5px;color:var(--muted);margin-bottom:8px">${t('Dashboard Header')}</div>
        <div style="border:1px solid var(--border);border-radius:12px;padding:12px;display:flex;align-items:center;gap:10px;margin-bottom:16px">
          ${s.logoDataUrl ? `<img src="${s.logoDataUrl}" alt="" style="width:32px;height:32px;border-radius:8px;object-fit:cover">` : ''}
          <div style="font-weight:800;font-size:14px">${schEsc(inst.name)}</div>
        </div>
        <div style="font-size:11.5px;color:var(--muted);margin-bottom:8px">${t('Receipt Header')}</div>
        <div style="border:1px solid var(--border);border-radius:12px;padding:16px;text-align:center">
          ${s.logoDataUrl ? `<img src="${s.logoDataUrl}" alt="" style="width:40px;height:40px;border-radius:10px;object-fit:cover;margin-bottom:6px">` : ''}
          <div style="font-weight:800;font-size:13px">${schEsc(inst.name)}</div>
        </div>
      </div></div>`;
}
function schRefreshBranding() { const el = document.getElementById('sch-branding-content'); if (el) el.innerHTML = schBrandingBody(); }
function schHandleBrandingLogoFile(input) {
  const file = input.files && input.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = function(e) {
    SCHOOL_DATA.settings.logoDataUrl = e.target.result;
    schLogAudit('Configuration Changed', 'Branding', 'Logo', '', 'updated');
    schRefreshBranding();
    schShowToast(t('Logo updated — preview refreshed below.'));
  };
  reader.readAsDataURL(file);
}
function schSaveBrandingName() {
  const name = (document.getElementById('sch-brand-name').value || '').trim();
  if (!name) { schShowToast(t('Institution name cannot be empty.')); return; }
  const oldName = SCHOOL_DATA.institution.name;
  SCHOOL_DATA.institution.name = name;
  schLogAudit('Configuration Changed', 'Branding', 'Institution Name', oldName, name);
  schRefreshBranding();
  schShowToast(t('Institution name updated — preview refreshed below.'));
}

/* ══════════════════════════════════════════════════════
   AUDIT LOGS (section 33) — viewing the real audit trail that has
   been genuinely populated by schLogAudit() since batch 1: every
   enrollment, admission change, payment/invoice action, communication
   sent, import, account generation, configuration change, subscription
   change, and campus change performed throughout this entire build.
══════════════════════════════════════════════════════ */
function schAuditView() { return `<div id="sch-audit-content">${schAuditBody()}</div>`; }
const SCH_AUDIT_ACTION_CATEGORIES = { 'Student Enrollment':'Enrollment', 'Record Edited':'Data', 'Admissions Changed':'Admissions', 'Invoice Created':'Payments', 'Invoice Paid':'Payments', 'Communication Sent':'Communication', 'Import Completed':'Data', 'Account Generated':'Accounts', 'Configuration Changed':'Configuration', 'Subscription Changed':'Subscription', 'Campus Changed':'Campus', 'Event Created':'Calendar', 'Event Edited':'Calendar', 'Event Deleted':'Calendar', 'Reclamation Status Changed':'Reclamations' };
function schAuditCategory(action) { return SCH_AUDIT_ACTION_CATEGORIES[action] || 'Other'; }
function schFilteredAudit() {
  const s = schState.audit;
  let list = SCHOOL_DATA.auditLog.slice();
  if (s.filterAction !== 'all') list = list.filter(a => a.action === s.filterAction);
  if (s.filterCategory !== 'all') list = list.filter(a => schAuditCategory(a.action) === s.filterCategory);
  if (s.dateFrom) list = list.filter(a => a.date >= s.dateFrom);
  if (s.dateTo) list = list.filter(a => a.date <= s.dateTo);
  const q = s.search.trim().toLowerCase();
  if (q) list = list.filter(a => a.objectLabel.toLowerCase().includes(q));
  return list;
}
function schAuditBody() {
  const s = schState.audit;
  const actions = Array.from(new Set(SCHOOL_DATA.auditLog.map(a => a.action)));
  const categories = Array.from(new Set(Object.values(SCH_AUDIT_ACTION_CATEGORIES)));
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Audit Logs')}</div></div>
    <div class="card-body">
      <input class="gd-comm-search-input" type="text" placeholder="${t('Search by affected object...')}" value="${schEsc(s.search)}" oninput="schSetAuditSearch(this.value)">
      <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:10px">
        <select onchange="schSetAuditActionFilter(this.value)" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
          <option value="all" ${s.filterAction==='all'?'selected':''}>${t('All Actions')}</option>
          ${actions.map(a => `<option value="${a}" ${a===s.filterAction?'selected':''}>${t(a)}</option>`).join('')}
        </select>
        <select onchange="schSetAuditCategoryFilter(this.value)" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
          <option value="all" ${s.filterCategory==='all'?'selected':''}>${t('All Categories')}</option>
          ${categories.map(c => `<option value="${c}" ${c===s.filterCategory?'selected':''}>${t(c)}</option>`).join('')}
        </select>
      </div>
      <div style="display:flex;gap:10px;margin-top:10px">
        <input id="sch-audit-from" type="date" value="${s.dateFrom}" onchange="schSetAuditDateRange()" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
        <span style="color:var(--muted);font-size:12px;align-self:center">${t('to')}</span>
        <input id="sch-audit-to" type="date" value="${s.dateTo}" onchange="schSetAuditDateRange()" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:7px 10px;font-size:12.5px">
      </div>
    </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Recorded Actions')}</div><span style="font-size:12px;color:var(--muted)" id="sch-audit-count">${schFilteredAudit().length} ${t('of')} ${SCHOOL_DATA.auditLog.length}</span></div>
      <div class="card-body" id="sch-audit-results">${schAuditResultsBlock()}</div></div>`;
}
function schAuditResultsBlock() {
  const list = schFilteredAudit();
  if (!list.length) return `<div class="gd-empty-mini">${t('No audit records match your search or filters.')}</div>`;
  return list.map(a => `<div class="card" style="margin-bottom:10px;background:var(--surface2)"><div class="card-body">
    <div style="display:flex;justify-content:space-between;align-items:flex-start">
      <div style="font-weight:600;font-size:13px">${t(a.action)}</div>
      <span style="font-size:11px;color:var(--muted)">${a.date} · ${a.time}</span>
    </div>
    <div style="font-size:12px;color:var(--muted2);margin-top:4px">${schEsc(a.objectType)}: ${schEsc(a.objectLabel)}</div>
    ${a.previousValue || a.newValue ? `<div style="font-size:11px;color:var(--muted);margin-top:6px">${a.previousValue ? `${t('Previous')}: ${schEsc(a.previousValue)} · ` : ''}${a.newValue ? `${t('New')}: ${schEsc(a.newValue)}` : ''}</div>` : ''}
    <div style="font-size:11px;color:var(--muted);margin-top:4px">${t('By')}: ${schEsc(a.user)}</div>
  </div></div>`).join('');
}
function schRefreshAuditResults() {
  const el = document.getElementById('sch-audit-results');
  if (el) el.innerHTML = schAuditResultsBlock();
  const countEl = document.getElementById('sch-audit-count');
  if (countEl) countEl.textContent = `${schFilteredAudit().length} ${t('of')} ${SCHOOL_DATA.auditLog.length}`;
}
function schSetAuditSearch(v) { schState.audit.search = v; schRefreshAuditResults(); }
function schSetAuditActionFilter(v) { schState.audit.filterAction = v; schRefreshAuditResults(); }
function schSetAuditCategoryFilter(v) { schState.audit.filterCategory = v; schRefreshAuditResults(); }
function schSetAuditDateRange() {
  schState.audit.dateFrom = document.getElementById('sch-audit-from').value;
  schState.audit.dateTo = document.getElementById('sch-audit-to').value;
  schRefreshAuditResults();
}

/* ══════════════════════════════════════════════════════
   ADVANCED AUDIT LOGS (section 33 extended)
   Category breakdown, activity-by-day trend, and most-active-user
   summary over the same real audit trail as the basic Audit Logs view.
══════════════════════════════════════════════════════ */
function schAuditAdvancedView() {
  const byCategory = {};
  SCHOOL_DATA.auditLog.forEach(a => { const cat = schAuditCategory(a.action); byCategory[cat] = (byCategory[cat]||0)+1; });
  const byDay = {};
  SCHOOL_DATA.auditLog.forEach(a => { byDay[a.date] = (byDay[a.date]||0)+1; });
  const byUser = {};
  SCHOOL_DATA.auditLog.forEach(a => { byUser[a.user] = (byUser[a.user]||0)+1; });
  const byAction = {};
  SCHOOL_DATA.auditLog.forEach(a => { byAction[a.action] = (byAction[a.action]||0)+1; });
  const mostActiveDay = Object.keys(byDay).length ? Object.keys(byDay).reduce((a,b) => byDay[a] > byDay[b] ? a : b) : null;

  return `
    <div class="gd-stat-row">
      <div class="stat-card"><div class="stat-label">${t('Total Actions')}</div><div class="stat-val">${SCHOOL_DATA.auditLog.length}</div><div class="stat-icon blue">${aIcon('file-text')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Categories Active')}</div><div class="stat-val">${Object.keys(byCategory).length}</div><div class="stat-icon purple">${aIcon('folder')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Most Active Day')}</div><div class="stat-val" style="font-size:14px">${mostActiveDay || '—'}</div><div class="stat-icon yellow">${aIcon('calendar')}</div></div>
    </div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('By Category')}</div></div>
      <div class="card-body">${Object.keys(byCategory).map(cat => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="authrenGoTo('audit');schSetAuditCategoryFilter('${cat}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();authrenGoTo('audit');schSetAuditCategoryFilter('${cat}')}"><span>${t(cat)}</span><span style="color:var(--muted)">${byCategory[cat]}</span></div>`).join('')}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('By Action Type')}</div></div>
      <div class="card-body">${Object.keys(byAction).map(a => `<div class="info-row"><span>${t(a)}</span><span style="color:var(--muted)">${byAction[a]}</span></div>`).join('')}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Activity by Day')}</div></div>
      <div class="card-body">${Object.keys(byDay).sort().map(d => `<div class="info-row"><span>${d}</span><span style="color:var(--muted)">${byDay[d]}</span></div>`).join('') || `<div class="gd-empty-mini">${t('No activity recorded yet.')}</div>`}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('By User')}</div></div>
      <div class="card-body">${Object.keys(byUser).map(u => `<div class="info-row"><span>${schEsc(u)}</span><span style="color:var(--muted)">${byUser[u]}</span></div>`).join('')}</div></div>`;
}

/* ══════════════════════════════════════════════════════
   ADVANCED REPORTING (section 29)
   Genuinely distinct from Advanced Reports (batch 6): this is a
   single-category report with real grouping (by Campus/Class/Level)
   and an optional real comparison-period column, using the same
   period-comparison engine as Historical Comparisons.
══════════════════════════════════════════════════════ */
function schReportingAdvancedView() {
  return `<div id="sch-reporting-adv-content">${schReportingAdvBody()}</div>`;
}
function schReportingAdvBody() {
  const r = schState.reportingAdvanced;
  return r.screen === 'preview' ? schReportingAdvPreview() : schReportingAdvForm();
}
function schReportingAdvForm() {
  const r = schState.reportingAdvanced;
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Advanced Report Builder')}</div></div>
    <div class="card-body">
      <div class="st-field"><label>${t('Report Category')}</label><select onchange="schSetReportingAdvField('category', this.value)">
        <option value="academic" ${r.category==='academic'?'selected':''}>${t('Academic')}</option>
        <option value="attendance" ${r.category==='attendance'?'selected':''}>${t('Attendance')}</option>
        <option value="payments" ${r.category==='payments'?'selected':''}>${t('Payments')}</option>
        <option value="admissions" ${r.category==='admissions'?'selected':''}>${t('Admissions')}</option>
      </select></div>
      <div class="st-field"><label>${t('Campus')}</label><select onchange="schSetReportingAdvField('campus', this.value)">
        <option value="all" ${r.campus==='all'?'selected':''}>${t('All Campuses')}</option>
        ${SCHOOL_DATA.campuses.map(c => `<option value="${c.id}" ${c.id===r.campus?'selected':''}>${schEsc(c.name)}</option>`).join('')}
      </select></div>
      <div class="st-field"><label>${t('Group By')}</label><select onchange="schSetReportingAdvField('groupBy', this.value)">
        <option value="campus" ${r.groupBy==='campus'?'selected':''}>${t('Campus')}</option>
        <option value="class" ${r.groupBy==='class'?'selected':''}>${t('Class')}</option>
        <option value="level" ${r.groupBy==='level'?'selected':''}>${t('Level')}</option>
      </select></div>
      <div class="st-field"><label>${t('Comparison Period')}</label><select onchange="schSetReportingAdvField('comparisonPeriod', this.value)">
        <option value="none" ${r.comparisonPeriod==='none'?'selected':''}>${t('None')}</option>
        <option value="term" ${r.comparisonPeriod==='term'?'selected':''}>${t('vs Previous Term')}</option>
        <option value="year" ${r.comparisonPeriod==='year'?'selected':''}>${t('vs Previous Year')}</option>
      </select></div>
      <button class="st-btn" onclick="schGenerateReportingAdv()">${t('Generate Report')}</button>
    </div></div>`;
}
function schSetReportingAdvField(key, value) { schState.reportingAdvanced[key] = value; }
function schReportingAdvGroups() {
  const r = schState.reportingAdvanced;
  let classes = r.campus === 'all' ? SCHOOL_DATA.classes : schCampusClasses(r.campus);
  if (r.groupBy === 'campus') {
    return SCHOOL_DATA.campuses.filter(c => r.campus === 'all' || c.id === r.campus).map(c => ({ label:c.name, students: schCampusStudents(c.id) }));
  }
  if (r.groupBy === 'level') {
    const levels = Array.from(new Set(classes.map(c => c.level)));
    return levels.map(lvl => ({ label:lvl, students: SCHOOL_DATA.students.filter(s => { const cls = schGetClass(s.classId); return cls && cls.level === lvl && (r.campus==='all'||cls.campusId===r.campus); }) }));
  }
  return classes.map(c => ({ label:c.name, students: schClassStudents(c.id) }));
}
function schReportingAdvMetric(category, students) {
  if (category === 'academic') { const v = schAvg(students.map(s=>s.avgGrade)); return v!==null?v+'/20':'—'; }
  if (category === 'attendance') { const v = schAggregateAttendance(students.map(s=>s.id), SCH_ATTENDANCE_DAYS).rate; return v!==null?v+'%':'—'; }
  if (category === 'payments') { const ids = students.map(s=>s.id); const payments = SCHOOL_DATA.payments.filter(p=>ids.includes(p.studentId)&&p.status==='paid'); return schCurrency(payments.reduce((s,p)=>s+p.amount,0)); }
  if (category === 'admissions') { const campusIds = new Set(students.map(s=>s.campusId)); return SCHOOL_DATA.admissions.filter(a=>campusIds.has(a.campusId)).length + ''; }
  return '—';
}
function schReportingAdvComparisonMetric(category, students) {
  if (category === 'academic') { const v = schAvg(students.map(s=>s.prevTermAvgGrade)); return v!==null?v+'/20':'—'; }
  return t('N/A for this category');
}
function schGenerateReportingAdv() {
  schState.reportingAdvanced.screen = 'preview';
  schState.reportingAdvanced.generatedAt = SCH_TODAY;
  const el = document.getElementById('sch-reporting-adv-content');
  if (el) el.innerHTML = schReportingAdvPreview();
}
function schBackToReportingAdvForm() {
  schState.reportingAdvanced.screen = 'form';
  const el = document.getElementById('sch-reporting-adv-content');
  if (el) el.innerHTML = schReportingAdvForm();
}
function schReportingAdvPreview() {
  const r = schState.reportingAdvanced;
  const groups = schReportingAdvGroups();
  const showComparison = r.comparisonPeriod !== 'none';
  return `<div class="card">
    <div class="card-header">
      <div style="display:flex;align-items:center;gap:10px"><button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="schBackToReportingAdvForm()">${t('← Back')}</button><div class="card-title">${t(r.category.charAt(0).toUpperCase()+r.category.slice(1))} ${t('Report')}</div></div>
      <button type="button" class="st-btn ghost sm" onclick="window.print()">${aIcon('printer')} ${t('Export / Print')}</button>
    </div>
    <div class="card-body">
      <div style="font-size:11.5px;color:var(--muted);margin-bottom:14px">${t('Generated')} ${r.generatedAt} · ${t('Grouped by')} ${t(r.groupBy.charAt(0).toUpperCase()+r.groupBy.slice(1))}</div>
      ${groups.map(g => `<div class="info-row"><span>${schEsc(g.label)}<div style="font-size:11px;color:var(--muted)">${g.students.length} ${t('students')}</div></span><span style="text-align:right">${schReportingAdvMetric(r.category, g.students)}${showComparison?`<div style="font-size:11px;color:var(--muted);margin-top:2px">${t('Prev')}: ${schReportingAdvComparisonMetric(r.category, g.students)}</div>`:''}</span></div>`).join('') || `<div class="gd-empty-mini">${t('No data for this grouping.')}</div>`}
    </div></div>`;
}

/* ══════════════════════════════════════════════════════
   PLANS (Institution Owner only)
   The buyer's own path to see what a higher tier offers. This is
   comparison, not nagging: nothing else in the Owner's nav is locked
   or hinted at — this is the one deliberate place that shows the full
   catalog, reusing the exact upgrade action already on the Subscription
   screen so there is one single, authority-checked way to change plans.
══════════════════════════════════════════════════════ */
function schPlansView() {
  const currentId = SCHOOL_DATA.subscription.currentPlan;
  const canManage = authrenCan('manageSubscription', 'school', currentSchoolType);
  return `
    <div style="font-size:12px;color:var(--muted);margin-bottom:14px">
      ${t('Compare what each Authren plan includes. Your institution is currently on')} <strong>${schEsc(authrenPlan(currentId).name)}</strong>.
    </div>
    ${AUTHREN_PLAN_ORDER.map(id => {
      const plan = authrenPlan(id);
      const isCurrent = id === currentId;
      const isUpgrade = AUTHREN_PLAN_ORDER.indexOf(id) > AUTHREN_PLAN_ORDER.indexOf(currentId);
      return `<div class="card" style="margin-bottom:14px${isCurrent ? ';border:1px solid var(--accent)' : ''}">
        <div class="card-header">
          <div>
            <div class="card-title">${schEsc(plan.name)}</div>
            <div style="font-size:11.5px;color:var(--muted);margin-top:2px">${schEsc(plan.tagline)}</div>
          </div>
          ${isCurrent
            ? `<span class="status-pill paid">${t('Current Plan')}</span>`
            : (canManage
                ? `<button type="button" class="st-btn ghost sm" onclick="schConfirmPlanChange('${id}')">${isUpgrade ? t('Upgrade') : t('Downgrade')}</button>`
                : '')}
        </div>
        <div class="card-body">
          ${authrenPlanFeatures(id).map(f => `<div style="font-size:12px;color:var(--muted2);margin-bottom:4px">${aIcon('check')} ${schEsc(f)}</div>`).join('')}
        </div>
      </div>`;
    }).join('')}`;
}
