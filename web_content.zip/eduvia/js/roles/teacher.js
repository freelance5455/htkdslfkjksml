/* ══════════════════════════════════════════════════════
   TEACHER MODULE — DATA
   Built incrementally across a multi-batch implementation. Every batch
   adds real, working functionality — no placeholder screens are left for
   features already in scope. Sections of the spec not yet reached simply
   don't have a nav entry yet, rather than a "coming soon" stub.
══════════════════════════════════════════════════════ */
const TEACHER_DATA = {
  account: {
    name: 'Mr. Karim Bensalem',
    teacherId: 'T1234567',
    /* Links this account to its entry in the shared school timetable */
    timetableTeacherId: 'p-bensalem-karim', // canonical registry id (see js/authren-identity.js)
    email: 'karim.bensalem@alfarabi.edu',
    phone: '+212 662-345 678',
    password: 'Passw0rd1',
    institution: 'Al Farabi Private School',
    subjects: ['Mathematics', 'Physics'],
    yearsExperience: 8,
    bio: 'Mathematics and Physics teacher focused on building strong problem-solving foundations and clear, structured lessons.',
  },
  classes: [
    { id:'cl1', name:'Grade 9 - A',  subject:'Mathematics' },
    { id:'cl2', name:'Grade 9 - B',  subject:'Mathematics' },
    { id:'cl3', name:'Grade 10 - A', subject:'Physics' },
  ],
  // Per-student roster — the single source of truth for class rosters and
  // aggregate stats (studentCount/avgPerformance/attendanceRate on a class
  // are always computed from this list, never hardcoded separately).
  students: [
    { id:'st01', studentId:'S30000001', name:'Amine Tazi',        classId:'cl1', avgGrade:16.5, attendanceRate:97 },
    { id:'st02', studentId:'S30000002', name:'Leila Kabbaj',      classId:'cl1', avgGrade:11.8, attendanceRate:88 },
    { id:'st03', studentId:'S30000003', name:'Omar Cherkaoui',    classId:'cl1', avgGrade:15.8, attendanceRate:96 },
    { id:'st04', studentId:'S30000004', name:'Salma Idrissi',     classId:'cl1', avgGrade:13.4, attendanceRate:92 },
    { id:'st05', studentId:'S30000005', name:'Yassine Bouzid',    classId:'cl1', avgGrade:9.6,  attendanceRate:81 },
    { id:'st06', studentId:'S30000006', name:'Nour El Fassi',     classId:'cl1', avgGrade:17.2, attendanceRate:99 },
    { id:'st07', studentId:'S30000007', name:'Karim Ziani',       classId:'cl1', avgGrade:12.9, attendanceRate:90 },
    { id:'st08', studentId:'S30000008', name:'Hiba Rachidi',      classId:'cl1', avgGrade:14.6, attendanceRate:94 },
    { id:'st09', studentId:'S30000009', name:'Adam Benslimane',   classId:'cl2', avgGrade:13.1, attendanceRate:91 },
    { id:'st10', studentId:'S30000010', name:'Rim Alaoui',        classId:'cl2', avgGrade:15.0, attendanceRate:95 },
    { id:'st11', studentId:'S30000011', name:'Mehdi Saadi',       classId:'cl2', avgGrade:10.4, attendanceRate:85 },
    { id:'st12', studentId:'S30000012', name:'Zineb Ouahabi',     classId:'cl2', avgGrade:14.9, attendanceRate:93 },
    { id:'st13', studentId:'S30000013', name:'Bilal Haddadi',     classId:'cl2', avgGrade:16.0, attendanceRate:98 },
    { id:'st14', studentId:'S30000014', name:'Ines Bennani',      classId:'cl2', avgGrade:8.7,  attendanceRate:79 },
    { id:'st15', studentId:'S30000015', name:'Othmane Lahlou',    classId:'cl2', avgGrade:12.3, attendanceRate:89 },
    { id:'st16', studentId:'S30000016', name:'Kenza Berrada',     classId:'cl3', avgGrade:14.4, attendanceRate:97 },
    /* The Student role's own logged-in character. This is the one real,
       cross-role connected student in this demo — the Teacher, Student and
       Guardian roles genuinely share this one person's real records. */
    { id:'st-youssef', studentId:'S12345678', name:'Youssef Amrani', classId:'cl3', avgGrade:15.8, attendanceRate:94 },
    { id:'st17', studentId:'S30000017', name:'Sami Ghali',        classId:'cl3', avgGrade:13.7, attendanceRate:95 },
    { id:'st18', studentId:'S30000018', name:'Douae Marrakchi',   classId:'cl3', avgGrade:11.2, attendanceRate:87 },
    { id:'st19', studentId:'S30000019', name:'Anas El Amrani',    classId:'cl3', avgGrade:15.5, attendanceRate:98 },
    { id:'st20', studentId:'S30000020', name:'Fatima Zahra Sabri',classId:'cl3', avgGrade:17.8, attendanceRate:99 },
    { id:'st21', studentId:'S30000021', name:'Reda Tahiri',       classId:'cl3', avgGrade:10.9, attendanceRate:84 },
  ],
  attendanceRecords: { // key `${classId}|${date}` -> { [studentId]: 'present'|'absent'|'late' }
    'cl1|2026-02-16': { st01:'present', st02:'present', st03:'present', st04:'present', st05:'absent', st06:'present', st07:'present', st08:'present' },
    'cl1|2026-02-23': { st01:'present', st02:'present', st03:'present', st04:'late',    st05:'absent', st06:'present', st07:'present', st08:'present' },
    'cl1|2026-03-02': { st01:'present', st02:'absent',  st03:'present', st04:'present', st05:'absent', st06:'present', st07:'late',    st08:'present' },
    'cl1|2026-03-09': { st01:'present', st02:'present', st03:'present', st04:'present', st05:'present', st06:'present', st07:'present', st08:'present' },
    'cl2|2026-02-24': { st09:'present', st10:'present', st11:'absent', st12:'present', st13:'present', st14:'absent', st15:'present' },
    'cl2|2026-03-03': { st09:'present', st10:'present', st11:'late',   st12:'present', st13:'present', st14:'absent', st15:'present' },
    'cl3|2026-02-27': { st16:'present', st17:'present', st18:'absent', st19:'present', st20:'present', st21:'late' },
  },
  exams: [
    { id:'ex1', classId:'cl1', subject:'Mathematics', name:'Chapter 3 Test', maxScore:20, date:'2026-02-20', time:'09:00', duration:60, instructions:'Covers linear equations and inequalities. Calculators are not permitted.', locked:true, published:false,
      scores:{ st01:16, st02:10, st03:15.5, st04:12, st05:8, st06:18, st07:11, st08:14 } },
    { id:'ex2', classId:'cl1', subject:'Mathematics', name:'Chapter 4 Quiz', maxScore:20, date:'2026-03-05', time:'09:00', duration:30, instructions:'Short quiz on quadratic functions.', locked:false, published:false,
      scores:{ st01:17, st06:19 } },
    { id:'ex3', classId:'cl2', subject:'Mathematics', name:'Chapter 3 Test', maxScore:20, date:'2026-02-21', time:'11:00', duration:60, instructions:'Covers linear equations and inequalities. Calculators are not permitted.', locked:false, published:false,
      scores:{} },
    { id:'ex4', classId:'cl3', subject:'Physics', name:'Forces Unit Test', maxScore:20, date:'2026-02-25', time:'14:00', duration:45, instructions:'Covers Newton\'s laws and free-body diagrams.', locked:true, published:true,
      scores:{ st16:14, st17:13.5, 'st-youssef':15 } },
    { id:'ex5', classId:'cl1', subject:'Mathematics', name:'Term 2 Final Exam', maxScore:40, date:'2026-03-20', time:'09:00', duration:90, instructions:'Comprehensive exam covering all Term 2 chapters. Bring your own calculator and geometry set.', locked:false, published:false,
      scores:{} },
  ],
  homework: [
    { id:'hw1', classId:'cl1', subject:'Mathematics', title:'Worksheet 5: Quadratics', description:'Practice problems on solving quadratic equations.', dueDate:'2026-03-08', instructions:'Show all work. Submit as a PDF or a clear photo of your handwritten work.', attachments:[{ name:'worksheet5.pdf', size:245000 }], status:'published', createdAt:'2026-03-01',
      submissions:{ st01:'submitted', st02:'submitted', st03:'submitted', st06:'submitted', st07:'late' } },
    { id:'hw2', classId:'cl1', subject:'Mathematics', title:'Reading: Chapter 5', description:'Read chapter 5 and answer the review questions.', dueDate:'2026-03-18', instructions:'Answer questions 1-10 in your notebook.', attachments:[], status:'published', createdAt:'2026-03-09',
      submissions:{} },
    { id:'hw3', classId:'cl2', subject:'Mathematics', title:'Worksheet 5: Quadratics', description:'Practice problems on solving quadratic equations.', dueDate:'2026-03-08', instructions:'Show all work.', attachments:[{ name:'worksheet5.pdf', size:245000 }], status:'published', createdAt:'2026-03-01',
      submissions:{ st09:'submitted', st10:'submitted' } },
    { id:'hw4', classId:'cl3', subject:'Physics', title:'Lab Report: Forces', description:"Write up your findings from last week's experiment.", instructions:'Include hypothesis, method, results and conclusion.', dueDate:'2026-03-15', attachments:[], status:'draft', createdAt:'2026-03-10',
      submissions:{} },
  ],
  behaviorRecords: [
    { id:'bh1', studentId:'st05', category:'Disruption', description:'Talked during the lesson and distracted nearby students.', date:'2026-03-04' },
    { id:'bh2', studentId:'st06', category:'Positive Behavior', description:'Helped a classmate understand the homework during group work.', date:'2026-03-06' },
    { id:'bh3', studentId:'st05', category:'Late to Class', description:'Arrived 15 minutes late without a note.', date:'2026-03-09' },
  ],
  participationRecords: [
    { id:'pt1', studentId:'st01', type:'Excellent', date:'2026-03-09', note:'Answered several questions and led the group discussion.' },
    { id:'pt2', studentId:'st05', type:'Passive', date:'2026-03-09', note:'' },
    { id:'pt3', studentId:'st06', type:'Active', date:'2026-03-02', note:'' },
  ],
  conversations: [
    /* The one real, cross-role connected thread — see js/authren-messages.js.
       Everything below this entry remains the teacher's own separate demo
       conversations, unconnected to any other role. */
    { id:'th-bensalem-amrani', type:'guardian', name:'Mr. Karim Amrani (Father)', context:'Guardian of Youssef Amrani', studentId:'st-youssef', unread:false, status:'open', shared:true,
      messages:[] },
    { id:'tc1', type:'guardian', name:'Mrs. Tazi (Mother)', context:'Guardian of Amine Tazi', studentId:'st01', unread:true, status:'open',
      messages:[
        { from:'them', text:"Hello, I wanted to check on Amine's progress in Mathematics this term.", date:'2026-03-10', time:'9:00 AM' },
        { from:'them', text:"Also, will there be a make-up session for Friday's quiz?", date:'2026-03-10', time:'9:02 AM' },
      ] },
    { id:'tc2', type:'guardian', name:'Mr. Bouzid (Father)', context:'Guardian of Yassine Bouzid', studentId:'st05', unread:false, status:'awaiting',
      messages:[
        { from:'me', text:'Hi Mr. Bouzid, I wanted to flag that Yassine was late to class today and seemed distracted. Could we schedule a quick call?', date:'2026-03-09', time:'2:15 PM' },
      ] },
    { id:'tc3', type:'school', name:'Dr. Hassan Ouali', context:'Head of Institution', studentId:null, unread:false, status:'resolved',
      messages:[
        { from:'them', text:'Please submit your Term 2 grade summaries by Friday.', date:'2026-03-05', time:'8:30 AM' },
        { from:'me', text:'Understood, I will have them ready by Thursday.', date:'2026-03-05', time:'8:45 AM' },
      ] },
    { id:'tc4', type:'school', name:'Front Office', context:'School Administration', studentId:null, unread:true, status:'open',
      messages:[
        { from:'them', text:'We need an updated supply list for the Physics lab by next week.', date:'2026-03-11', time:'11:00 AM' },
      ] },
  ],
  supportTickets: [], // no fabricated support-request history
  savedReports: [], // saved/generated report snapshots
};

/* Populate the one real, shared conversation (js/authren-messages.js)
   into the teacher's local view, converting to the legacy message shape
   the existing UI already renders. Every other conversation is
   untouched local demo data. */
if (typeof authrenMessagesForThread === 'function') {
  const sharedConv = TEACHER_DATA.conversations.find(c => c.shared);
  if (sharedConv) {
    const acct = TEACHER_DATA.account || {};
    sharedConv.messages = authrenMessagesForThread(sharedConv.id).map(m => ({
      from: (m.fromRole === 'teacher') ? 'me' : 'them',
      text: m.body,
      date: m.sentAt.slice(0, 10),
      time: m.sentAt.slice(11, 16),
      attachments: m.attachments || [],
    }));
    const unread = authrenThreadUnreadCount(sharedConv.id, 'teacher', acct.timetableTeacherId || 'p-bensalem-karim');
    sharedConv.unread = unread > 0;
  }
}
const T_SCHOOL_STAFF = [
  { id:'staff1', name:'Dr. Hassan Ouali', role:'Head of Institution' },
  { id:'staff2', name:'Front Office', role:'School Administration' },
  { id:'staff3', name:'IT Support', role:'Technical Support' },
];
const T_FAQS = [
  { id:'f1', category:'Grading', question:'How do I lock official scores?', answer:'Open Grading, select the class and assessment, then click "Lock Official Scores" once all scores are entered. This prevents further edits unless you unlock it again.' },
  { id:'f2', category:'Attendance', question:'Can I change attendance after saving it?', answer:'Yes. Reopen the Attendance page for that class and date, change any student\'s status, then save again to update the record.' },
  { id:'f3', category:'Homework', question:'How do I see which students have not submitted?', answer:'Open the homework item and go to the Submissions tab. Students who have not submitted are marked Missing once the due date has passed, and Not Due Yet beforehand.' },
  { id:'f4', category:'Communication', question:'How do I message a guardian?', answer:'Go to Communication, click New Message, choose Guardian, then search for the student. The message is sent to that student\'s guardian.' },
  { id:'f5', category:'Account', question:'How do I update my profile information?', answer:'Go to Profile & Security and click Edit Profile. Update your details and click Save Changes.' },
  { id:'f6', category:'Exams', question:'What happens if I schedule two exams at the same time?', answer:'Authren checks for scheduling conflicts within the same class and will warn you if a new exam overlaps an existing one for that class.' },
];
const T_SUPPORT_CATEGORIES = ['Technical Issue', 'Account', 'Grading', 'Attendance', 'Communication', 'Other'];
const T_RATING_CATEGORIES = ['Administrative Support', 'Facilities & Resources', 'Communication from Leadership', 'Work Environment', 'Professional Development'];

let tState = {
  currentView: 'home',
  tab: { account: 'profile' },
  profile: { editing:false, saving:false, error:'', success:false, draft:null },
  phone: { editing:false, saving:false, error:'', success:false, draft:'' },
  password: { saving:false },
  email: { step:'idle', newEmail:'', deliveredTo:'', sending:false, verifying:false, attempts:0, error:'', cooldown:0, expiry:0, _interval:null },
  recovery: { step:1, identifier:'', deliveredTo:'', sending:false, verifying:false, attempts:0, error:'', cooldown:0, expiry:0, resetting:false, _interval:null },
  classesNav: { screen:'list', classId:null, studentId:null, classTab:'overview' },
  classSearch: '',
  globalStudentSearch: '',
  studentListState: { search:'', sort:'name', filter:'all' },
  attendance: { classId:null, date:null, draft:{}, dirty:false, saving:false, error:'' },
  grading: { classId:null, examId:null, search:'', draftScores:{}, rowErrors:{}, savingAll:false, error:'' },
  exams: { screen:'list', filterClassId:'all', examId:null, form:null, saving:false, error:'' },
  homework: { screen:'list', filterClassId:'all', filterStatus:'all', search:'', hwId:null, form:null, saving:false, error:'', subScreen:'details' },
  analytics: { tab:'overview', classId:null, subject:null, attClassId:null, studentId:null, studentSearch:'', behaviorClassId:null, intelClassId:null },
  behavior: { tab:'behavior', studentId:null, studentSearch:'', form:null, error:'', saving:false },
  comms: { screen:'list', loadState:'idle', search:'', filter:'all', convId:null,
    compose: { open:false, recipientType:'guardian', studentSearch:'', studentId:null, staffId:null, text:'', attachments:[], error:'', sending:false },
    reply: { text:'', attachments:[], error:'', sending:false } },
  support: { tab:'help', helpSearch:'', helpCategory:'all', expandedFaqId:null,
    screen:'list', form:null, error:'', submitting:false, lastError:'' },
  rating: { screen:'form', ratings:{}, notes:{}, error:'' },
  reports: { screen:'form', type:'class-performance', classId:null, studentId:null, studentSearch:'', period:'term', loadState:'idle', error:'', viewingId:null },
};

/* ══════════════════════════════════════════════════════
   COMPUTED CLASS/STUDENT STATS
   Always derived live from TEACHER_DATA.students — a class's roster size
   and averages can never drift out of sync with the actual student list.
══════════════════════════════════════════════════════ */
function tClassStudents(classId) {
  return TEACHER_DATA.students.filter(s => s.classId === classId);
}
function tClassStudentCount(classId) { return tClassStudents(classId).length; }
function tAvg(arr) { return arr.length ? Math.round((arr.reduce((s, v) => s + v, 0) / arr.length) * 10) / 10 : null; }
function tClassAvgPerformance(classId) { return tAvg(tClassStudents(classId).map(s => s.avgGrade)); }
function tClassAttendanceRate(classId) { return tAvg(tClassStudents(classId).map(s => s.attendanceRate)); }
function tGetClass(classId) { return TEACHER_DATA.classes.find(c => c.id === classId) || null; }
function tGetStudent(studentId) { return TEACHER_DATA.students.find(s => s.id === studentId) || null; }
/* A simple, transparent "needs attention" signal used for list badges — not
   a hidden score, just a plain threshold on the two numbers already shown. */
function tStudentNeedsAttention(s) { return s.avgGrade < 12 || s.attendanceRate < 90; }

/* ══════════════════════════════════════════════════════
   VIEW ROUTER
══════════════════════════════════════════════════════ */
function teacherView(v) {
  tState.currentView = v;
  if (v === 'timetable') return tTimetableView();
  if (v === 'home')    return tHome();
  if (v === 'classes') return tClassesView();
  if (v === 'attendance') return tAttendanceView();
  if (v === 'grading') return tGradingView();
  if (v === 'exams') return tExamsView();
  if (v === 'homework') return tHomeworkView();
  if (v === 'analytics') return tAnalyticsView();
  if (v === 'behavior') return tBehaviorView();
  if (v === 'messages') return tCommsView();
  if (v === 'support') return tSupportView();
  if (v === 'reports') return tReportsView();
  if (v === 'account') return tAccount();
  return `<div class="card"><div class="card-body" style="color:var(--muted);text-align:center;padding:40px">${t('This section is coming soon.')}</div></div>`;
}

function tShowToast(msg) { gdShowToast(msg); }

/* ══════════════════════════════════════════════════════
   DASHBOARD
══════════════════════════════════════════════════════ */
function tHome() {
  const classes = TEACHER_DATA.classes;
  const totalStudents = TEACHER_DATA.students.length;
  const perfList = classes.map(c => tClassAvgPerformance(c.id)).filter(v => v !== null);
  const attList = classes.map(c => tClassAttendanceRate(c.id)).filter(v => v !== null);
  const avgPerf = tAvg(perfList);
  const avgAtt = tAvg(attList);
  const a = TEACHER_DATA.account;

  return `
    <div class="card"><div class="card-body" style="display:flex;gap:16px;align-items:center;flex-wrap:wrap">
      <div style="width:56px;height:56px;border-radius:16px;background:linear-gradient(180deg,rgba(30,64,175,0.85),rgba(23,37,84,0.85));display:flex;align-items:center;justify-content:center;font-weight:800;font-size:18px;color:#fff">${gdInitials(a.name)}</div>
      <div>
        <div style="font-size:16px;font-weight:800">${t('Welcome back')}, ${gdCommsEsc(a.name)}</div>
        <div style="font-size:12.5px;color:var(--muted);margin-top:2px">${gdCommsEsc(a.institution)} · ${a.subjects.map(s => gdCommsEsc(t(s))).join(', ')}</div>
      </div>
    </div></div>

    <div class="gd-stat-row" style="margin-top:16px">
      <div class="stat-card"><div class="stat-label">${t('Classes')}</div><div class="stat-val">${classes.length}</div><div class="stat-icon blue">${aIcon('school')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Total Students')}</div><div class="stat-val">${totalStudents}</div><div class="stat-icon purple">${aIcon('users')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Avg. Performance')}</div><div class="stat-val">${avgPerf !== null ? avgPerf + '/20' : '—'}</div><div class="stat-icon green">${aIcon('bar-chart')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Avg. Attendance')}</div><div class="stat-val">${avgAtt !== null ? avgAtt + '%' : '—'}</div><div class="stat-icon yellow">${aIcon('check-circle')}</div></div>
    </div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Your Classes')}</div><div class="card-action" onclick="authrenGoTo('classes')">${t('View all classes')} →</div></div>
      <div class="card-body">
        ${classes.map(c => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="tGoToClass('${c.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();tGoToClass('${c.id}')}">
          <span>${gdCommsEsc(c.name)}<div style="font-size:11.5px;color:var(--muted);margin-top:2px">${gdCommsEsc(t(c.subject))} · ${tClassStudentCount(c.id)} ${t(tClassStudentCount(c.id) === 1 ? 'student' : 'students')}</div></span>
          <span style="text-align:right;font-size:12.5px;color:var(--muted)">${tClassAvgPerformance(c.id)}/20 · ${tClassAttendanceRate(c.id)}%</span>
        </div>`).join('') || `<div class="gd-empty-mini">${t('No classes assigned yet.')}</div>`}
      </div></div>`;
}
function tGoToClass(classId) {
  tOpenClass(classId);
  authrenGoTo('classes');
}

/* ══════════════════════════════════════════════════════
   CLASS & STUDENT MANAGEMENT
   In-page screen states (list -> detail -> student) within the single
   'classes' nav entry, matching the established pattern elsewhere in
   Authren rather than adding a nav item per drill-down level.
══════════════════════════════════════════════════════ */
function tClassesView() {
  return `<div id="t-classes-content">${tClassesBody()}</div>`;
}
function tClassesBody() {
  const nav = tState.classesNav;
  if (nav.screen === 'student') {
    const student = tGetStudent(nav.studentId);
    if (!student) { nav.screen = 'detail'; return tClassesBody(); } // stale id — fall back safely
    return tStudentDetailScreen(student);
  }
  if (nav.screen === 'detail') {
    const cls = tGetClass(nav.classId);
    if (!cls) { nav.screen = 'list'; return tClassesBody(); }
    return tClassDetailScreen(cls);
  }
  return tClassListScreen();
}
function tRefreshClasses() {
  const el = document.getElementById('t-classes-content');
  if (el) el.innerHTML = tClassesBody();
}

/* ── Class List ── */
function tClassListScreen() {
  return `
    <div class="card"><div class="card-header"><div class="card-title">${t('Find a Student')}</div></div>
      <div class="card-body">
        <input class="gd-comm-search-input" type="text" placeholder="${t('Search by name or student ID...')}" value="${gdCommsEsc(tState.globalStudentSearch)}" oninput="tSetGlobalStudentSearch(this.value)">
        <div id="t-student-search-results">${tGlobalSearchResultsBlock()}</div>
      </div></div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Your Classes')}</div></div>
      <div class="card-body">
        <input class="gd-comm-search-input" type="text" placeholder="${t('Search classes by name or subject...')}" value="${gdCommsEsc(tState.classSearch)}" oninput="tSetClassSearch(this.value)">
        <div id="t-class-list-results" style="margin-top:12px">${tClassListResultsBlock()}</div>
      </div></div>`;
}
function tGlobalSearchResultsBlock() {
  const q = tState.globalStudentSearch.trim().toLowerCase();
  if (!q) return '';
  const results = TEACHER_DATA.students.filter(s => s.name.toLowerCase().includes(q) || s.studentId.toLowerCase().includes(q));
  if (!results.length) return `<div class="gd-empty-mini" style="text-align:left;padding:14px 0 0">${t('No students match your search.')}</div>`;
  return `<div style="margin-top:12px">${results.map(s => {
    const cls = tGetClass(s.classId);
    return `<div class="info-row" style="cursor:pointer;align-items:center" role="button" tabindex="0" onclick="tOpenStudentFromSearch('${s.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();tOpenStudentFromSearch('${s.id}')}">
      <span>${gdCommsEsc(s.name)}<div style="font-size:11.5px;color:var(--muted);margin-top:2px">${gdCommsEsc(s.studentId)} · ${cls ? gdCommsEsc(cls.name) : t('Unknown class')}</div></span>
      <span style="font-size:12.5px;color:var(--muted)">${s.avgGrade}/20</span>
    </div>`;
  }).join('')}</div>`;
}
function tClassListResultsBlock() {
  const classQ = tState.classSearch.trim().toLowerCase();
  const classes = TEACHER_DATA.classes.filter(c => !classQ || c.name.toLowerCase().includes(classQ) || c.subject.toLowerCase().includes(classQ));
  if (!classes.length) return `<div class="gd-empty-mini">${t('No classes match your search.')}</div>`;
  return classes.map(c => `<div class="info-row" style="cursor:pointer;align-items:center" role="button" tabindex="0" onclick="tOpenClass('${c.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();tOpenClass('${c.id}')}">
    <span>${gdCommsEsc(c.name)}<div style="font-size:11.5px;color:var(--muted);margin-top:2px">${gdCommsEsc(t(c.subject))} · ${tClassStudentCount(c.id)} ${t(tClassStudentCount(c.id) === 1 ? 'student' : 'students')}</div></span>
    <span style="text-align:right;font-size:12.5px;color:var(--muted)">${tClassAvgPerformance(c.id)}/20 · ${tClassAttendanceRate(c.id)}%</span>
  </div>`).join('');
}
function tSetClassSearch(v) { tState.classSearch = v; const el = document.getElementById('t-class-list-results'); if (el) el.innerHTML = tClassListResultsBlock(); }
function tSetGlobalStudentSearch(v) { tState.globalStudentSearch = v; const el = document.getElementById('t-student-search-results'); if (el) el.innerHTML = tGlobalSearchResultsBlock(); }

function tOpenClass(classId) {
  tState.classesNav = { screen:'detail', classId, studentId:null, classTab:'overview' };
  tState.studentListState = { search:'', sort:'name', filter:'all' };
  tRefreshClasses();
}
function tOpenStudentFromSearch(studentId) {
  const student = tGetStudent(studentId);
  if (!student) return;
  tState.classesNav = { screen:'student', classId: student.classId, studentId, classTab:'students' };
  tRefreshClasses();
}
function tBackToClassList() {
  tState.classesNav = { screen:'list', classId:null, studentId:null, classTab:'overview' };
  tRefreshClasses();
}
function tBackToClassDetail() {
  tState.classesNav.screen = 'detail';
  tState.classesNav.studentId = null;
  tRefreshClasses();
}
function tOpenStudent(studentId) {
  tState.classesNav.screen = 'student';
  tState.classesNav.studentId = studentId;
  tRefreshClasses();
}

/* ── Class Detail (Overview / Students) ── */
function tClassDetailScreen(cls) {
  const tabs = [ { id:'overview', label:'Overview' }, { id:'students', label:'Students' } ];
  return `<div class="card">
    <div class="card-header">
      <div style="display:flex;align-items:center;gap:10px;min-width:0;flex:1">
        <button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="tBackToClassList()">${t('← Back')}</button>
        <div class="card-title" style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${gdCommsEsc(cls.name)}</div>
      </div>
    </div>
    <div class="card-body" style="padding-bottom:0">
      <div style="font-size:12.5px;color:var(--muted);margin-bottom:14px">${gdCommsEsc(t(cls.subject))} · ${tClassStudentCount(cls.id)} ${t(tClassStudentCount(cls.id) === 1 ? 'student' : 'students')}</div>
      <div class="st-tabs">${tabs.map(tb => `<div class="st-tab gd-tab-tclass${tb.id===tState.classesNav.classTab?' active':''}" data-tab="${tb.id}" onclick="tSetClassTab('${tb.id}')">${t(tb.label)}</div>`).join('')}</div>
    </div>
    <div class="card-body" style="padding-top:14px" id="t-class-tab-body">${tClassTabBody(cls)}</div>
  </div>`;
}
function tSetClassTab(tabId) {
  tState.classesNav.classTab = tabId;
  document.querySelectorAll('.gd-tab-tclass').forEach(el => el.classList.toggle('active', el.dataset.tab === tabId));
  const el = document.getElementById('t-class-tab-body');
  if (el) el.innerHTML = tClassTabBody(tGetClass(tState.classesNav.classId));
}
function tClassTabBody(cls) {
  if (tState.classesNav.classTab === 'students') return tStudentListBlock(cls);
  return tClassOverviewTab(cls);
}
function tClassOverviewTab(cls) {
  return `<div class="gd-pay-stat-row">
    <div class="stat-card"><div class="stat-label">${t('Students')}</div><div class="stat-val">${tClassStudentCount(cls.id)}</div><div class="stat-icon blue">${aIcon('users')}</div></div>
    <div class="stat-card"><div class="stat-label">${t('Avg. Performance')}</div><div class="stat-val">${tClassAvgPerformance(cls.id)}/20</div><div class="stat-icon green">${aIcon('bar-chart')}</div></div>
    <div class="stat-card"><div class="stat-label">${t('Avg. Attendance')}</div><div class="stat-val">${tClassAttendanceRate(cls.id)}%</div><div class="stat-icon yellow">${aIcon('check-circle')}</div></div>
  </div>
  <div style="margin-top:16px;display:flex;gap:10px;flex-wrap:wrap">
    <button class="st-btn ghost sm" onclick="tGoToAttendanceForClass('${cls.id}')">${t('Take Attendance')} →</button>
    <button class="st-btn ghost sm" onclick="tGoToGradingForClass('${cls.id}')">${t('Grade Assessments')} →</button>
    <button class="st-btn ghost sm" onclick="tGoToExamsForClass('${cls.id}')">${t('View Exams')} →</button>
    <button class="st-btn ghost sm" onclick="tGoToHomeworkForClass('${cls.id}')">${t('View Homework')} →</button>
  </div>`;
}

/* ── Student List (within a class) ── */
function tStudentListBlock(cls) {
  const s = tState.studentListState;
  const filters = [ ['all', 'All'], ['attention', 'Needs Attention'] ];
  return `
    <div class="gd-comm-toolbar" style="padding:0 0 12px;border-bottom:none">
      <input class="gd-comm-search-input" type="text" placeholder="${t('Search students by name or ID...')}" value="${gdCommsEsc(s.search)}" oninput="tSetStudentListSearch(this.value)">
      <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">
        <div class="gd-comm-filter-row">${filters.map(([id, label]) => `<div class="gd-comm-filter-chip${s.filter===id?' active':''}" onclick="tSetStudentListFilter('${id}')">${t(label)}</div>`).join('')}</div>
        <select onchange="tSetStudentListSort(this.value)" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);font-size:12px;padding:6px 10px">
          <option value="name" ${s.sort==='name'?'selected':''}>${t('Sort: Name')}</option>
          <option value="grade" ${s.sort==='grade'?'selected':''}>${t('Sort: Grade')}</option>
          <option value="attendance" ${s.sort==='attendance'?'selected':''}>${t('Sort: Attendance')}</option>
        </select>
      </div>
    </div>
    <div id="t-student-list-results">${tStudentListResultsBlock(cls)}</div>`;
}
function tStudentListResultsBlock(cls) {
  const s = tState.studentListState;
  let list = tClassStudents(cls.id);
  const q = s.search.trim().toLowerCase();
  if (q) list = list.filter(st => st.name.toLowerCase().includes(q) || st.studentId.toLowerCase().includes(q));
  if (s.filter === 'attention') list = list.filter(tStudentNeedsAttention);
  list = list.slice().sort((a, b) => {
    if (s.sort === 'grade') return b.avgGrade - a.avgGrade;
    if (s.sort === 'attendance') return b.attendanceRate - a.attendanceRate;
    return a.name.localeCompare(b.name);
  });
  if (!list.length) return `<div class="gd-empty-mini">${t('No students match your search or filter.')}</div>`;
  return list.map(st => `<div class="info-row" style="cursor:pointer;align-items:center" role="button" tabindex="0" onclick="tOpenStudent('${st.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();tOpenStudent('${st.id}')}">
    <span style="display:flex;align-items:center;gap:10px">
      <span style="width:32px;height:32px;border-radius:50%;background:var(--surface3);display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;flex-shrink:0">${gdInitials(st.name)}</span>
      <span>${gdCommsEsc(st.name)}<div style="font-size:11px;color:var(--muted)">${gdCommsEsc(st.studentId)}</div></span>
    </span>
    <span style="text-align:right;font-size:12.5px;color:var(--muted)">
      ${st.avgGrade}/20 · ${st.attendanceRate}%
      ${tStudentNeedsAttention(st) ? `<div style="margin-top:4px"><span class="status-pill overdue">${t('Needs Attention')}</span></div>` : ''}
    </span>
  </div>`).join('');
}
function tRefreshStudentTab() {
  const el = document.getElementById('t-class-tab-body');
  if (el) el.innerHTML = tStudentListBlock(tGetClass(tState.classesNav.classId));
}
function tSetStudentListSearch(v) { tState.studentListState.search = v; const el = document.getElementById('t-student-list-results'); if (el) el.innerHTML = tStudentListResultsBlock(tGetClass(tState.classesNav.classId)); }
function tSetStudentListFilter(v) { tState.studentListState.filter = v; tRefreshStudentTab(); }
function tSetStudentListSort(v) { tState.studentListState.sort = v; tRefreshStudentTab(); }

/* ── Student Detail (Basic Student Information) ──
   Deeper drill-down (grades, homework, attendance history, behavior) links
   in here as those modules are completed in later batches. */
function tStudentDetailScreen(student) {
  const cls = tGetClass(student.classId);
  const attention = tStudentNeedsAttention(student);
  const trend = tStudentExamTrend(student.id);
  const examHistory = tStudentExamHistory(student.id);
  const classHw = cls ? TEACHER_DATA.homework.filter(h => h.classId === cls.id && h.status === 'published') : [];
  const hwDone = classHw.filter(h => ['submitted', 'late'].includes(tSubmissionStatus(h, student.id))).length;
  const behaviorRecs = tStudentBehaviorRecords(student.id);
  const participationRecs = tStudentParticipationRecords(student.id);

  return `<div class="card">
    <div class="card-header">
      <div style="display:flex;align-items:center;gap:10px;min-width:0;flex:1">
        <button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="tBackToClassDetail()">${t('← Back')}</button>
        <div class="card-title" style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${gdCommsEsc(student.name)}</div>
      </div>
    </div>
    <div class="card-body">
      <div style="display:flex;align-items:center;gap:14px;padding-bottom:14px;margin-bottom:14px;border-bottom:0.5px solid var(--separator)">
        <div style="width:52px;height:52px;border-radius:50%;background:var(--surface3);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:16px;flex-shrink:0">${gdInitials(student.name)}</div>
        <div style="min-width:0;flex:1">
          <div style="font-size:15px;font-weight:700;color:var(--color-text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${gdCommsEsc(student.name)}</div>
          <div style="font-size:12px;color:var(--muted);margin-top:2px">${gdCommsEsc(student.studentId)} · ${cls ? gdCommsEsc(cls.name) : t('Unknown class')}</div>
        </div>
        <span class="status-pill ${attention ? 'overdue' : 'paid'}">${attention ? t('Needs Attention') : t('On Track')}</span>
      </div>
      <div class="gd-pay-stat-row">
        <div class="stat-card"><div class="stat-label">${t('Average Grade')}</div><div class="stat-val">${student.avgGrade}/20</div><div class="stat-icon ${student.avgGrade < 12 ? 'red' : 'green'}">${aIcon('bar-chart')}</div></div>
        <div class="stat-card"><div class="stat-label">${t('Attendance Rate')}</div><div class="stat-val">${student.attendanceRate}%</div><div class="stat-icon ${student.attendanceRate < 90 ? 'yellow' : 'green'}">${aIcon('check-circle')}</div></div>
        <div class="stat-card"><div class="stat-label">${t('Homework Done')}</div><div class="stat-val">${classHw.length ? `${hwDone}/${classHw.length}` : '—'}</div><div class="stat-icon blue">${aIcon('book')}</div></div>
      </div>

      <div style="margin-top:16px;padding-top:14px;border-top:0.5px solid var(--separator)">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
          <span style="font-size:12.5px;font-weight:600">${t('Recent Assessments')}</span>
          <span class="card-action" onclick="tGoToStudentAnalytics('${student.id}')">${t('View Full Progress')} →</span>
        </div>
        ${examHistory.length ? examHistory.slice(-3).reverse().map(h => `<div class="info-row"><span>${gdCommsEsc(h.name)}<div style="font-size:11px;color:var(--muted)">${h.date}</div></span><span>${h.score}/${h.maxScore}</span></div>`).join('') : `<div class="gd-empty-mini">${t('No graded assessments yet.')}</div>`}
        ${trend !== null ? `<div style="font-size:11.5px;color:${trend < 0 ? 'var(--red)' : trend > 0 ? 'var(--green)' : 'var(--muted)'};margin-top:6px">${trend > 0 ? '▲' : trend < 0 ? '▼' : '—'} ${Math.abs(trend)}% ${trend < 0 ? t('decline since first assessment — possible improvement area') : trend > 0 ? t('improvement since first assessment') : t('no change since first assessment')}</div>` : ''}
      </div>

      <div style="margin-top:16px;padding-top:14px;border-top:0.5px solid var(--separator)">
        <div style="font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Homework Status')}</div>
        ${classHw.length ? classHw.slice(0, 4).map(h => {
          const status = tSubmissionStatus(h, student.id);
          const meta = { submitted:{ cls:'open', label:t('Submitted') }, late:{ cls:'awaiting', label:t('Late') }, missing:{ cls:'overdue', label:t('Missing') }, pending:{ cls:'resolved', label:t('Not Due Yet') } }[status];
          return `<div class="info-row"><span>${gdCommsEsc(h.title)}<div style="font-size:11px;color:var(--muted)">${t('Due')} ${h.dueDate}</div></span><span class="status-pill ${meta.cls}">${meta.label}</span></div>`;
        }).join('') : `<div class="gd-empty-mini">${t('No homework assigned yet.')}</div>`}
      </div>

      <div style="margin-top:16px;padding-top:14px;border-top:0.5px solid var(--separator)">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
          <span style="font-size:12.5px;font-weight:600">${t('Behavior & Participation')}</span>
          <span class="card-action" onclick="tGoToBehaviorForStudent('${student.id}')">${t('Full History')} →</span>
        </div>
        ${(behaviorRecs.length + participationRecs.length) ? `
          <div class="info-row"><span>${t('Behavior Records')}</span><span>${behaviorRecs.length}</span></div>
          <div class="info-row"><span>${t('Participation Records')}</span><span>${participationRecs.length}</span></div>
          ${behaviorRecs[0] ? `<div style="font-size:11.5px;color:var(--muted);margin-top:6px">${t('Most recent')}: ${gdCommsEsc(t(behaviorRecs[0].category))} (${behaviorRecs[0].date})</div>` : ''}
        ` : `<div class="gd-empty-mini">${t('No behavior or participation records yet.')}</div>`}
      </div>

      <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:16px">
        <button class="st-btn ghost sm" onclick="tGoToMessageGuardian('${student.id}')">${t('Message Guardian')} →</button>
      </div>
    </div>
  </div>`;
}

/* ══════════════════════════════════════════════════════
   ATTENDANCE
══════════════════════════════════════════════════════ */
const T_TODAY = AUTHREN_NOW; // alias — one shared clock (js/authren-now.js), not an independent one
function tISODate(d) { return d.toISOString().slice(0, 10); }
function tFormatDateLabel(iso) {
  const d = new Date(iso + 'T00:00:00');
  return isNaN(d) ? iso : d.toLocaleDateString('en-GB', { day:'numeric', month:'short', year:'numeric' });
}
function tAttendanceKey(classId, date) { return classId + '|' + date; }

function tAttendanceView() {
  if (!tState.attendance.classId && TEACHER_DATA.classes.length) tState.attendance.classId = TEACHER_DATA.classes[0].id;
  if (!tState.attendance.date) tState.attendance.date = tISODate(T_TODAY);
  tLoadAttendanceDraft();
  return `<div id="t-attendance-content">${tAttendanceBody()}</div>`;
}
function tLoadAttendanceDraft() {
  const key = tAttendanceKey(tState.attendance.classId, tState.attendance.date);
  const saved = TEACHER_DATA.attendanceRecords[key];
  tState.attendance.draft = saved ? Object.assign({}, saved) : {};
  tState.attendance.dirty = false;
  tState.attendance.error = '';
}
function tRefreshAttendance() {
  const el = document.getElementById('t-attendance-content');
  if (el) el.innerHTML = tAttendanceBody();
}
function tAttendanceBody() {
  if (!TEACHER_DATA.classes.length) {
    return `<div class="gd-empty-state">
      <div class="gd-empty-state-title">${t('No classes assigned')}</div>
      <div class="gd-empty-state-sub">${t('Attendance will be available once you have an assigned class.')}</div>
    </div>`;
  }
  const cls = tGetClass(tState.attendance.classId);
  const roster = cls ? tClassStudents(cls.id) : [];

  return `
    <div class="card"><div class="card-body" style="display:flex;gap:14px;flex-wrap:wrap;align-items:flex-end">
      <div style="flex:1;min-width:180px">
        <label style="font-size:11.5px;color:var(--muted);display:block;margin-bottom:6px">${t('Class')}</label>
        <select onchange="tSetAttendanceClass(this.value)" style="width:100%;background:var(--surface2);border:1px solid var(--border);border-radius:10px;color:var(--color-text);padding:9px 12px;font-size:13px">
          ${TEACHER_DATA.classes.map(c => `<option value="${c.id}" ${c.id===tState.attendance.classId?'selected':''}>${gdCommsEsc(c.name)} — ${gdCommsEsc(t(c.subject))}</option>`).join('')}
        </select>
      </div>
      <div style="flex:1;min-width:160px">
        <label style="font-size:11.5px;color:var(--muted);display:block;margin-bottom:6px">${t('Date')}</label>
        <input type="date" value="${tState.attendance.date}" onchange="tSetAttendanceDate(this.value)" style="width:100%;background:var(--surface2);border:1px solid var(--border);border-radius:10px;color:var(--color-text);padding:9px 12px;font-size:13px">
      </div>
    </div></div>

    <div class="card" style="margin-top:16px">
      <div class="card-header">
        <div class="card-title">${t('Attendance')} — ${tFormatDateLabel(tState.attendance.date)}</div>
        ${roster.length ? `<button class="st-btn ghost sm" onclick="tConfirmMarkAllPresent()">${t('Mark All Present')}</button>` : ''}
      </div>
      <div class="card-body" id="t-attendance-roster">${tAttendanceRosterBlock(roster)}</div>
    </div>`;
}
function tAttendanceRosterBlock(roster) {
  if (!roster.length) return `<div class="gd-empty-mini">${t('No students in this class.')}</div>`;
  const draft = tState.attendance.draft;
  const statusBtn = (st, val, label) => `<button type="button" class="t-att-btn t-att-${val}${draft[st.id]===val?' active':''}" onclick="tMarkAttendance('${st.id}','${val}')">${label}</button>`;
  const rows = roster.map(st => `<div class="info-row" style="align-items:center">
    <span style="display:flex;align-items:center;gap:10px;min-width:0">
      <span style="width:32px;height:32px;border-radius:50%;background:var(--surface3);display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;flex-shrink:0">${gdInitials(st.name)}</span>
      <span style="min-width:0"><div style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${gdCommsEsc(st.name)}</div><div style="font-size:11px;color:var(--muted)">${gdCommsEsc(st.studentId)}</div></span>
    </span>
    <span style="display:flex;gap:6px;flex-shrink:0">
      ${statusBtn(st, 'present', t('Present'))}
      ${statusBtn(st, 'absent', t('Absent'))}
      ${statusBtn(st, 'late', t('Late'))}
    </span>
  </div>`).join('');
  const unmarkedCount = roster.filter(st => !draft[st.id]).length;
  const s = tState.attendance;
  return `${rows}
    <div style="display:flex;justify-content:space-between;align-items:center;margin-top:16px;flex-wrap:wrap;gap:10px">
      <div style="font-size:11.5px;color:var(--muted)">${unmarkedCount ? `${unmarkedCount} ${t(unmarkedCount === 1 ? 'student' : 'students')} ${t('unmarked')}` : (s.dirty ? t('Unsaved changes') : t('All changes saved'))}</div>
      <div style="display:flex;align-items:center;gap:10px">
        ${s.error ? `<span class="st-inline-msg err show" style="margin:0">${s.error}</span>` : ''}
        <button class="st-btn" onclick="tSaveAttendance()" ${s.saving ? 'disabled' : ''}>${s.saving ? `<span class="gd-spinner"></span>${t('Saving...')}` : t('Save Attendance')}</button>
      </div>
    </div>`;
}
function tSetAttendanceClass(classId) { tState.attendance.classId = classId; tLoadAttendanceDraft(); tRefreshAttendance(); }
function tSetAttendanceDate(dateStr) { tState.attendance.date = dateStr || tISODate(T_TODAY); tLoadAttendanceDraft(); tRefreshAttendance(); }
function tMarkAttendance(studentId, status) {
  tState.attendance.draft[studentId] = status;
  tState.attendance.dirty = true;
  const cls = tGetClass(tState.attendance.classId);
  const el = document.getElementById('t-attendance-roster');
  if (el && cls) el.innerHTML = tAttendanceRosterBlock(tClassStudents(cls.id));
}
function tConfirmMarkAllPresent() {
  const cls = tGetClass(tState.attendance.classId);
  if (!cls) return;
  const roster = tClassStudents(cls.id);
  const hasExisting = roster.some(st => tState.attendance.draft[st.id]);
  if (!hasExisting) { tMarkAllPresent(); return; }
  stOpenModal(`<h3 style="margin-bottom:10px">${t('Mark all present?')}</h3>
    <p style="font-size:13px;color:var(--muted);margin-bottom:18px">${t('This will overwrite the marks already entered for this class and date.')}</p>
    <div style="display:flex;gap:10px">
      <button class="st-btn" onclick="tMarkAllPresent();stCloseModal()">${t('Yes, Mark All Present')}</button>
      <button class="st-btn ghost" onclick="stCloseModal()">${t('Cancel')}</button>
    </div>`);
}
function tMarkAllPresent() {
  const cls = tGetClass(tState.attendance.classId);
  if (!cls) return;
  tClassStudents(cls.id).forEach(st => { tState.attendance.draft[st.id] = 'present'; });
  tState.attendance.dirty = true;
  const el = document.getElementById('t-attendance-roster');
  if (el) el.innerHTML = tAttendanceRosterBlock(tClassStudents(cls.id));
}
function tSaveAttendance() {
  const cls = tGetClass(tState.attendance.classId);
  if (!cls) return;
  const roster = tClassStudents(cls.id);
  const unmarked = roster.filter(st => !tState.attendance.draft[st.id]);
  if (unmarked.length) {
    tState.attendance.error = t('Please mark attendance for all students before saving.');
    const el = document.getElementById('t-attendance-roster');
    if (el) el.innerHTML = tAttendanceRosterBlock(roster);
    return;
  }
  tState.attendance.error = '';
  tState.attendance.saving = true;
  tRefreshAttendance();
  setTimeout(() => {
    const key = tAttendanceKey(tState.attendance.classId, tState.attendance.date);
    TEACHER_DATA.attendanceRecords[key] = Object.assign({}, tState.attendance.draft);
    /* Any student in this roster who carries a real studentId matching a
       cross-role character (currently: Youssef Amrani) also gets a real
       row in the ONE shared attendance table, so the Student and
       Guardian roles genuinely see what was just marked here — not a
       separate, independently fabricated number. */
    if (typeof authrenRecordAttendance === 'function') {
      const acct = (typeof TEACHER_DATA !== 'undefined' && TEACHER_DATA.account) ? TEACHER_DATA.account : {};
      Object.keys(tState.attendance.draft).forEach(localStudentId => {
        const st = tGetStudent(localStudentId);
        if (st && st.studentId === 'S12345678') {
          authrenRecordAttendance(
            { studentId: st.studentId, classId: 'cl-g10a', subjectId: 'phys',
              date: tState.attendance.date, status: tState.attendance.draft[localStudentId] },
            { role: 'teacher', id: acct.timetableTeacherId || 'p-bensalem-karim' }
          );
        }
      });
    }
    tState.attendance.saving = false;
    tState.attendance.dirty = false;
    tRefreshAttendance();
    tShowToast(t('Attendance saved successfully.'));
  }, 700);
}
function tGoToAttendanceForClass(classId) {
  tState.attendance.classId = classId;
  tState.attendance.date = tISODate(T_TODAY);
  authrenGoTo('attendance');
}

/* ══════════════════════════════════════════════════════
   GRADING
══════════════════════════════════════════════════════ */
function tGetExam(examId) { return TEACHER_DATA.exams.find(e => e.id === examId) || null; }
function tClassExams(classId) { return TEACHER_DATA.exams.filter(e => e.classId === classId); }
function tExamEnteredCount(exam) { return Object.keys(exam.scores).length; }
function tValidateScore(val, maxScore) {
  if (val === '' || val === null || val === undefined) return t('Enter a score.');
  const n = Number(val);
  if (isNaN(n)) return t('Enter a valid number.');
  if (n < 0 || n > maxScore) return t('Score must be between 0 and') + ' ' + maxScore + '.';
  return '';
}
function tGradingView() {
  if (!tState.grading.classId && TEACHER_DATA.classes.length) tState.grading.classId = TEACHER_DATA.classes[0].id;
  return '<div id="t-grading-content">' + tGradingBody() + '</div>';
}
function tGradingBody() {
  if (!TEACHER_DATA.classes.length) {
    return '<div class="gd-empty-state"><div class="gd-empty-state-title">' + t('No classes assigned') + '</div><div class="gd-empty-state-sub">' + t('Grading will be available once you have an assigned class.') + '</div></div>';
  }
  if (tState.grading.examId) {
    const exam = tGetExam(tState.grading.examId);
    if (!exam) { tState.grading.examId = null; return tGradingBody(); }
    return tScoreEntryScreen(exam);
  }
  return tGradingListScreen();
}
function tRefreshGrading() { const el = document.getElementById('t-grading-content'); if (el) el.innerHTML = tGradingBody(); }
function tGradingListScreen() {
  const classId = tState.grading.classId;
  const exams = tClassExams(classId);
  let rows = '';
  exams.forEach(function(e) {
    rows += '<div class="info-row" style="cursor:pointer;align-items:center" role="button" tabindex="0" onclick="tOpenExam(\'' + e.id + '\')" onkeydown="if(event.key===\'Enter\'||event.key===\' \'){event.preventDefault();tOpenExam(\'' + e.id + '\')}">'
      + '<span>' + gdCommsEsc(e.name) + '<div style="font-size:11.5px;color:var(--muted);margin-top:2px">' + e.date + ' · ' + t('Max') + ' ' + e.maxScore + '</div></span>'
      + '<span style="text-align:right;font-size:12.5px;color:var(--muted)">' + tExamEnteredCount(e) + '/' + tClassStudentCount(classId) + ' ' + t('entered')
      + (e.locked ? '<div style="margin-top:4px"><span class="status-pill overdue">' + aIcon('lock') + ' ' + t('Locked') + '</span></div>' : '')
      + '</span></div>';
  });
  if (!exams.length) rows = '<div class="gd-empty-mini">' + t('No assessments for this class yet.') + '</div>';
  let opts = '';
  TEACHER_DATA.classes.forEach(function(c) {
    opts += '<option value="' + c.id + '" ' + (c.id===classId?'selected':'') + '>' + gdCommsEsc(c.name) + ' — ' + gdCommsEsc(t(c.subject)) + '</option>';
  });
  return '<div class="card"><div class="card-body">'
    + '<label style="font-size:11.5px;color:var(--muted);display:block;margin-bottom:6px">' + t('Class') + '</label>'
    + '<select onchange="tSetGradingClass(this.value)" style="width:100%;max-width:320px;background:var(--surface2);border:1px solid var(--border);border-radius:10px;color:var(--color-text);padding:9px 12px;font-size:13px">' + opts + '</select>'
    + '</div></div>'
    + '<div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">' + t('Assessments') + '</div></div>'
    + '<div class="card-body">' + rows + '</div></div>';
}
function tSetGradingClass(classId) { tState.grading.classId = classId; tRefreshGrading(); }
function tOpenExam(examId) {
  const exam = tGetExam(examId);
  tState.grading = { classId: tState.grading.classId, examId: examId, search:'', draftScores: exam ? Object.assign({}, exam.scores) : {}, rowErrors:{}, savingAll:false, error:'' };
  tRefreshGrading();
}
function tBackToGradingList() {
  tState.grading.examId = null;
  tState.grading.error = '';
  tRefreshGrading();
}
function tScoreEntryScreen(exam) {
  const cls = tGetClass(exam.classId);
  const enteredCount = Object.keys(tState.grading.draftScores).filter(function(k){ return tState.grading.draftScores[k] !== ''; }).length;
  let footer = '';
  if (!exam.locked) {
    footer = '<div style="display:flex;justify-content:space-between;align-items:center;margin-top:16px;flex-wrap:wrap;gap:10px">'
      + '<div style="font-size:11.5px;color:var(--muted)">' + enteredCount + '/' + tClassStudentCount(exam.classId) + ' ' + t('scored') + '</div>'
      + '<div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">'
      + (tState.grading.error ? '<span class="st-inline-msg err show" style="margin:0">' + tState.grading.error + '</span>' : '')
      + '<button class="st-btn ghost sm" onclick="tConfirmLockExam(\'' + exam.id + '\')" ' + (enteredCount === 0 ? 'disabled' : '') + '>' + t('Lock Official Scores') + '</button>'
      + '<button class="st-btn" onclick="tSaveAllScores(\'' + exam.id + '\')" ' + (tState.grading.savingAll ? 'disabled' : '') + '>' + (tState.grading.savingAll ? '<span class="gd-spinner"></span>' + t('Saving...') : t('Save All Scores')) + '</button>'
      + '</div></div>';
  }
  let lockedNotice = '';
  if (exam.locked) {
    lockedNotice = '<div class="st-inline-msg show" style="background:rgba(15,23,42,0.04);color:var(--muted);border:1px solid var(--border)">' + t("Official scores for this assessment are locked and cannot be edited. Unlock to make changes.") + '</div>'
      + '<div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:12px">'
      + '<button class="st-btn ghost sm" onclick="tConfirmUnlockExam(\'' + exam.id + '\')">' + t('Unlock Scores') + '</button>'
      + (exam.published
          ? '<span class="status-pill paid" style="align-self:center">' + aIcon('check') + ' ' + t('Published — visible to students and guardians') + '</span>'
          : '<button class="st-btn sm" onclick="tConfirmPublishExam(\'' + exam.id + '\')">' + t('Publish Results') + '</button>')
      + '</div>';
  }
  return '<div class="card">'
    + '<div class="card-header"><div style="display:flex;align-items:center;gap:10px;min-width:0;flex:1">'
    + '<button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="tBackToGradingList()">' + t('← Back') + '</button>'
    + '<div class="card-title" style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + gdCommsEsc(exam.name) + '</div></div>'
    + (exam.locked ? '<span class="status-pill overdue">' + aIcon('lock') + ' ' + t('Locked') + '</span>' : '')
    + '</div>'
    + '<div class="card-body">'
    + '<div style="font-size:12px;color:var(--muted);margin-bottom:14px">' + (cls ? gdCommsEsc(cls.name) : '') + ' · ' + gdCommsEsc(t(exam.subject)) + ' · ' + t('Max Score') + ': ' + exam.maxScore + ' · ' + exam.date + '</div>'
    + lockedNotice
    + '<input class="gd-comm-search-input" style="margin-top:14px" type="text" placeholder="' + t('Search students by name or ID...') + '" value="' + gdCommsEsc(tState.grading.search) + '" oninput="tSetGradingSearch(this.value)">'
    + '<div id="t-score-rows" style="margin-top:12px">' + tScoreRowsBlock(exam) + '</div>'
    + footer
    + '</div></div>';
}
function tScoreRowsBlock(exam) {
  const q = tState.grading.search.trim().toLowerCase();
  let roster = tClassStudents(exam.classId);
  if (q) roster = roster.filter(function(st){ return st.name.toLowerCase().indexOf(q) !== -1 || st.studentId.toLowerCase().indexOf(q) !== -1; });
  if (!roster.length) return '<div class="gd-empty-mini">' + t('No students match your search.') + '</div>';
  const draft = tState.grading.draftScores;
  const rowErr = tState.grading.rowErrors;
  let out = '';
  roster.forEach(function(st) {
    const val = draft[st.id] !== undefined ? draft[st.id] : '';
    const err = rowErr[st.id];
    let control;
    if (exam.locked) {
      control = '<span style="font-weight:700">' + (val !== '' ? val + '/' + exam.maxScore : '—') + '</span>';
    } else {
      control = '<input type="number" min="0" max="' + exam.maxScore + '" step="0.5" value="' + gdCommsEsc(val) + '" oninput="tDraftScore(\'' + st.id + '\', this.value)" style="width:64px;background:var(--surface2);border:1px solid ' + (err ? 'var(--red)' : 'var(--border)') + ';border-radius:8px;color:var(--color-text);padding:6px 8px;font-size:13px;text-align:center">'
        + '<span style="font-size:11px;color:var(--muted)">/ ' + exam.maxScore + '</span>'
        + '<button type="button" class="st-btn ghost sm" onclick="tSaveOneScore(\'' + exam.id + '\',\'' + st.id + '\')">' + t('Save') + '</button>';
    }
    out += '<div class="info-row" style="align-items:center;flex-wrap:wrap">'
      + '<span style="display:flex;align-items:center;gap:10px;min-width:0">'
      + '<span style="width:32px;height:32px;border-radius:50%;background:var(--surface3);display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;flex-shrink:0">' + gdInitials(st.name) + '</span>'
      + '<span style="min-width:0"><div style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">' + gdCommsEsc(st.name) + '</div><div style="font-size:11px;color:var(--muted)">' + gdCommsEsc(st.studentId) + '</div></span>'
      + '</span>'
      + '<span style="display:flex;align-items:center;gap:8px;flex-shrink:0">' + control + '</span>'
      + (err ? '<div style="width:100%;font-size:11px;color:var(--red);margin-top:4px">' + err + '</div>' : '')
      + '</div>';
  });
  return out;
}
function tSetGradingSearch(v) {
  tState.grading.search = v;
  const exam = tGetExam(tState.grading.examId);
  const el = document.getElementById('t-score-rows');
  if (el && exam) el.innerHTML = tScoreRowsBlock(exam);
}
function tDraftScore(studentId, val) { tState.grading.draftScores[studentId] = val; }
function tSaveOneScore(examId, studentId) {
  const exam = tGetExam(examId);
  if (!exam || exam.locked) return;
  const val = tState.grading.draftScores[studentId];
  const err = tValidateScore(val, exam.maxScore);
  if (err) { tState.grading.rowErrors[studentId] = err; }
  else {
    delete tState.grading.rowErrors[studentId];
    exam.scores[studentId] = Number(val);
    tShowToast(t('Score saved.'));
  }
  tRefreshGrading();
}
function tSaveAllScores(examId) {
  const exam = tGetExam(examId);
  if (!exam || exam.locked) return;
  const roster = tClassStudents(exam.classId);
  const errors = {};
  let hasError = false;
  roster.forEach(function(st) {
    const val = tState.grading.draftScores[st.id];
    if (val === undefined || val === '') return;
    const err = tValidateScore(val, exam.maxScore);
    if (err) { errors[st.id] = err; hasError = true; }
  });
  tState.grading.rowErrors = errors;
  if (hasError) {
    tState.grading.error = t('Fix the highlighted scores before saving.');
    tRefreshGrading();
    return;
  }
  tState.grading.error = '';
  tState.grading.savingAll = true;
  tRefreshGrading();
  setTimeout(function() {
    let savedCount = 0;
    roster.forEach(function(st) {
      const val = tState.grading.draftScores[st.id];
      if (val !== undefined && val !== '') { exam.scores[st.id] = Number(val); savedCount++; }
    });
    tState.grading.savingAll = false;
    tRefreshGrading();
    tShowToast(savedCount ? t('Scores saved successfully.') : t('No new scores to save.'));
  }, 700);
}
function tConfirmLockExam(examId) {
  stOpenModal('<h3 style="margin-bottom:10px">' + t('Lock official scores?') + '</h3>'
    + '<p style="font-size:13px;color:var(--muted);margin-bottom:18px">' + t('Once locked, scores for this assessment cannot be edited unless you unlock them again. Use this to mark scores as final.') + '</p>'
    + '<div style="display:flex;gap:10px"><button class="st-btn" onclick="tLockExam(\'' + examId + '\');stCloseModal()">' + t('Lock Scores') + '</button>'
    + '<button class="st-btn ghost" onclick="stCloseModal()">' + t('Cancel') + '</button></div>');
}
function tLockExam(examId) {
  const exam = tGetExam(examId);
  if (!exam) return;
  exam.locked = true;
  tRefreshGrading();
  tShowToast(t('Scores locked successfully.'));
}
function tConfirmUnlockExam(examId) {
  stOpenModal('<h3 style="margin-bottom:10px">' + t('Unlock scores?') + '</h3>'
    + '<p style="font-size:13px;color:var(--muted);margin-bottom:18px">' + t('This will allow editing previously locked official scores for this assessment.') + '</p>'
    + '<div style="display:flex;gap:10px"><button class="st-btn" onclick="tUnlockExam(\'' + examId + '\');stCloseModal()">' + t('Unlock Scores') + '</button>'
    + '<button class="st-btn ghost" onclick="stCloseModal()">' + t('Cancel') + '</button></div>');
}
function tUnlockExam(examId) {
  const exam = tGetExam(examId);
  if (!exam) return;
  exam.locked = false;
  tRefreshGrading();
  tShowToast(t('Scores unlocked.'));
}
function tConfirmPublishExam(examId) {
  const exam = tGetExam(examId);
  if (!exam || !exam.locked) return;
  stOpenModal('<h3 style="margin-bottom:10px">' + t('Publish results?') + '</h3>'
    + '<p style="font-size:13px;color:var(--muted);margin-bottom:18px">' + t('Once published, students and their guardians in this class will be able to see their scores. This cannot be undone from here.') + '</p>'
    + '<div style="display:flex;gap:10px"><button class="st-btn" onclick="tPublishExam(\'' + examId + '\');stCloseModal()">' + t('Publish Results') + '</button>'
    + '<button class="st-btn ghost" onclick="stCloseModal()">' + t('Cancel') + '</button></div>');
}
function tPublishExam(examId) {
  const exam = tGetExam(examId);
  if (!exam || !exam.locked) return;
  /* Write into the ONE shared assessments table (js/authren-grades.js) —
     the same table Student and Guardian read from — for whichever
     student in this roster carries a real cross-role studentId
     (currently: Youssef Amrani). Everyone else in this exam's local
     scores stays exactly as it was; there is no connected character to
     publish them to yet. */
  if (typeof authrenPublishAssessment === 'function') {
    const cls = tGetClass(exam.classId);
    const subjectId = (typeof AUTHREN_REGISTRY !== 'undefined') ? AUTHREN_REGISTRY.subjectIdForName(exam.subject) : null;
    const registryClassId = (cls && cls.name === 'Grade 10 - A' && exam.subject === 'Physics') ? 'cl-g10a' : null;
    if (subjectId && registryClassId) {
      /* Translate local roster ids to their real cross-role studentId
         where one exists (currently: Youssef Amrani), so the shared
         table is keyed the same way the Student and Guardian roles look
         records up — the same fix already made for attendance. Local
         ids with no real counterpart are kept as-is so the teacher's own
         published record still reflects the whole class. */
      const translatedScores = {};
      Object.keys(exam.scores).forEach(localId => {
        const st = tGetStudent(localId);
        translatedScores[(st && st.studentId) ? st.studentId : localId] = exam.scores[localId];
      });
      authrenPublishAssessment(
        { id: exam.id, classId: registryClassId, subjectId: subjectId, teacherId: (TEACHER_DATA.account || {}).timetableTeacherId,
          title: exam.name, date: exam.date, maxScore: exam.maxScore, locked: true, scores: translatedScores },
        { role: 'teacher', id: (TEACHER_DATA.account || {}).timetableTeacherId }
      );
    }
  }
  exam.published = true;
  tRefreshGrading();
  tShowToast(t('Results published. Students and guardians can now see their scores.'));
}
function tGoToGradingForClass(classId) {
  tState.grading.classId = classId;
  tState.grading.examId = null;
  authrenGoTo('grading');
}

/* ══════════════════════════════════════════════════════
   EXAMS — Creation & Scheduling
   Reads/writes the same TEACHER_DATA.exams array Grading uses, so a newly
   created or rescheduled exam is immediately available there too.
══════════════════════════════════════════════════════ */
function tExamStatus(exam) { return exam.date >= tISODate(T_TODAY) ? 'upcoming' : 'past'; }
function tExamsView() {
  return `<div id="t-exams-content">${tExamsBody()}</div>`;
}
function tExamsBody() {
  const st = tState.exams;
  if (st.screen === 'form') return tExamFormScreen();
  if (st.screen === 'detail') {
    const exam = tGetExam(st.examId);
    if (!exam) { st.screen = 'list'; return tExamsBody(); }
    return tExamDetailScreen(exam);
  }
  return tExamsListScreen();
}
function tRefreshExams() { const el = document.getElementById('t-exams-content'); if (el) el.innerHTML = tExamsBody(); }

function tExamsListScreen() {
  const st = tState.exams;
  let exams = TEACHER_DATA.exams.slice();
  if (st.filterClassId !== 'all') exams = exams.filter(e => e.classId === st.filterClassId);
  exams.sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time));
  return `
    <div class="card"><div class="card-body" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px">
      <select onchange="tSetExamsFilter(this.value)" style="background:var(--surface2);border:1px solid var(--border);border-radius:10px;color:var(--color-text);padding:9px 12px;font-size:13px">
        <option value="all" ${st.filterClassId==='all'?'selected':''}>${t('All Classes')}</option>
        ${TEACHER_DATA.classes.map(c => `<option value="${c.id}" ${c.id===st.filterClassId?'selected':''}>${gdCommsEsc(c.name)}</option>`).join('')}
      </select>
      <button class="st-btn" onclick="tOpenExamForm('create')">+ ${t('New Exam')}</button>
    </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Exams')}</div></div>
      <div class="card-body">
        ${exams.length ? exams.map(e => {
          const cls = tGetClass(e.classId);
          const status = tExamStatus(e);
          return `<div class="info-row" style="cursor:pointer;align-items:center" role="button" tabindex="0" onclick="tOpenExamDetail('${e.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();tOpenExamDetail('${e.id}')}">
            <span>${gdCommsEsc(e.name)}<div style="font-size:11.5px;color:var(--muted);margin-top:2px">${cls ? gdCommsEsc(cls.name) : ''} · ${e.date} ${e.time}</div></span>
            <span style="text-align:right;font-size:12.5px;color:var(--muted)">
              <span class="status-pill ${status==='upcoming'?'due':'resolved'}">${status==='upcoming'?t('Upcoming'):t('Past')}</span>
              ${e.locked ? `<div style="margin-top:4px"><span class="status-pill overdue">${aIcon('lock')} ${t('Locked')}</span></div>` : ''}
            </span>
          </div>`;
        }).join('') : `<div class="gd-empty-mini">${t('No exams scheduled yet.')}</div>`}
      </div></div>`;
}
function tSetExamsFilter(v) { tState.exams.filterClassId = v; tRefreshExams(); }

function tOpenExamForm(mode, examId) {
  if (mode === 'edit') {
    const exam = tGetExam(examId);
    if (!exam) return;
    tState.exams.examId = examId;
    tState.exams.form = { mode:'edit', id:exam.id, name:exam.name, classId:exam.classId, date:exam.date, time:exam.time, duration:exam.duration, maxScore:exam.maxScore, instructions:exam.instructions || '' };
  } else {
    tState.exams.form = { mode:'create', id:null, name:'', classId: TEACHER_DATA.classes[0] ? TEACHER_DATA.classes[0].id : '', date:'', time:'', duration:60, maxScore:20, instructions:'' };
  }
  tState.exams.screen = 'form';
  tState.exams.error = '';
  tRefreshExams();
}
function tCancelExamForm() {
  tState.exams.screen = (tState.exams.form && tState.exams.form.mode === 'edit') ? 'detail' : 'list';
  tState.exams.form = null;
  tState.exams.error = '';
  tRefreshExams();
}
function tSaveExamForm() {
  const f = tState.exams.form;
  const name = (document.getElementById('t-exam-name').value || '').trim();
  const classId = document.getElementById('t-exam-class').value;
  const date = document.getElementById('t-exam-date').value;
  const time = document.getElementById('t-exam-time').value;
  const duration = Number(document.getElementById('t-exam-duration').value);
  const maxScore = Number(document.getElementById('t-exam-maxscore').value);
  const instructions = (document.getElementById('t-exam-instructions').value || '').trim();
  Object.assign(f, { name, classId, date, time, duration, maxScore, instructions });

  let err = '';
  if (!name) err = t('Exam name is required.');
  else if (!classId) err = t('Select a class.');
  else if (!date) err = t('Select a date.');
  else if (!time) err = t('Select a time.');
  else if (!duration || duration <= 0) err = t('Duration must be greater than 0.');
  else if (!maxScore || maxScore <= 0) err = t('Maximum score must be greater than 0.');
  else {
    const parts = time.split(':').map(Number);
    const startMin = parts[0] * 60 + parts[1];
    const endMin = startMin + duration;
    const conflict = TEACHER_DATA.exams.find(e => {
      if (e.id === f.id) return false;
      if (e.classId !== classId || e.date !== date) return false;
      const eParts = e.time.split(':').map(Number);
      const eStart = eParts[0] * 60 + eParts[1];
      const eEnd = eStart + e.duration;
      return startMin < eEnd && eStart < endMin;
    });
    if (conflict) err = `${t('This class already has an exam scheduled at an overlapping time')} (${conflict.name}).`;
  }

  tState.exams.error = err;
  if (err) { tRefreshExams(); return; }

  tState.exams.saving = true;
  tRefreshExams();
  setTimeout(() => {
    const cls = tGetClass(classId);
    if (f.mode === 'edit') {
      const exam = tGetExam(f.id);
      Object.assign(exam, { name, classId, subject: cls ? cls.subject : exam.subject, date, time, duration, maxScore, instructions });
      tState.exams.screen = 'detail';
      tState.exams.examId = f.id;
      tShowToast(t('Exam updated successfully.'));
    } else {
      const newExam = { id:'ex' + Date.now(), classId, subject: cls ? cls.subject : '', name, date, time, duration, maxScore, instructions, locked:false, published:false, scores:{} };
      TEACHER_DATA.exams.push(newExam);
      tState.exams.screen = 'detail';
      tState.exams.examId = newExam.id;
      tShowToast(t('Exam created successfully.'));
    }
    tState.exams.saving = false;
    tState.exams.form = null;
    tRefreshExams();
  }, 700);
}

function tOpenExamDetail(examId) {
  tState.exams.screen = 'detail';
  tState.exams.examId = examId;
  tRefreshExams();
}
function tBackToExamsList() {
  tState.exams.screen = 'list';
  tState.exams.examId = null;
  tRefreshExams();
}
function tExamDetailScreen(exam) {
  const cls = tGetClass(exam.classId);
  const status = tExamStatus(exam);
  return `<div class="card">
    <div class="card-header">
      <div style="display:flex;align-items:center;gap:10px;min-width:0;flex:1">
        <button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="tBackToExamsList()">${t('← Back')}</button>
        <div class="card-title" style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${gdCommsEsc(exam.name)}</div>
      </div>
      <button type="button" class="st-btn ghost sm" onclick="tOpenExamForm('edit','${exam.id}')">${t('Edit')}</button>
    </div>
    <div class="card-body">
      <div class="info-row"><span>${t('Class')}</span><span>${cls ? gdCommsEsc(cls.name) : '—'}</span></div>
      <div class="info-row"><span>${t('Subject')}</span><span>${gdCommsEsc(t(exam.subject))}</span></div>
      <div class="info-row"><span>${t('Date & Time')}</span><span>${exam.date} · ${exam.time}</span></div>
      <div class="info-row"><span>${t('Duration')}</span><span>${exam.duration} ${t('minutes')}</span></div>
      <div class="info-row"><span>${t('Maximum Score')}</span><span>${exam.maxScore}</span></div>
      <div class="info-row"><span>${t('Status')}</span><span class="status-pill ${status==='upcoming'?'due':'resolved'}">${status==='upcoming'?t('Upcoming'):t('Past')}</span></div>
      ${exam.locked ? `<div class="info-row"><span>${t('Scores')}</span><span class="status-pill overdue">${aIcon('lock')} ${t('Locked')}</span></div>` : ''}
      ${exam.instructions ? `<div style="margin-top:14px"><div style="font-size:11.5px;color:var(--muted);margin-bottom:6px">${t('Instructions')}</div><div style="font-size:13px;color:var(--muted2);line-height:1.6">${gdCommsEsc(exam.instructions)}</div></div>` : ''}
      <button type="button" class="st-btn ghost sm" style="margin-top:16px" onclick="tGoToExamGrading('${exam.id}')">${t('Grade This Exam')} →</button>
    </div>
  </div>`;
}
function tGoToExamGrading(examId) {
  const exam = tGetExam(examId);
  if (!exam) return;
  tState.grading.classId = exam.classId; // ensure back-navigation in Grading lands on the correct class, not whichever was last selected there
  tOpenExam(examId);
  authrenGoTo('grading');
}
function tGoToExamsForClass(classId) {
  tState.exams.filterClassId = classId;
  tState.exams.screen = 'list';
  authrenGoTo('exams');
}

/* ══════════════════════════════════════════════════════
   HOMEWORK — Creation, Tracking, Advanced Management, Attachments
══════════════════════════════════════════════════════ */
function tGetHomework(hwId) { return TEACHER_DATA.homework.find(h => h.id === hwId) || null; }
function tClassHomework(classId) { return TEACHER_DATA.homework.filter(h => h.classId === classId); }
/* Real submission status per student: 'submitted' or 'late' come from the
   data itself; 'missing' vs 'pending' is computed from whether the due
   date has actually passed, never guessed. */
function tSubmissionStatus(hw, studentId) {
  const explicit = hw.submissions[studentId];
  if (explicit) return explicit;
  return hw.dueDate < tISODate(T_TODAY) ? 'missing' : 'pending';
}
function tHomeworkSubmissionCounts(hw) {
  const roster = tClassStudents(hw.classId);
  const counts = { submitted:0, late:0, missing:0, pending:0, total:roster.length };
  roster.forEach(st => { counts[tSubmissionStatus(hw, st.id)]++; });
  return counts;
}
function tHomeworkStatusLabel(status) {
  return { published:t('Published'), draft:t('Draft'), archived:t('Archived') }[status] || status;
}
function tHomeworkStatusPillClass(status) {
  return { published:'open', draft:'awaiting', archived:'resolved' }[status] || '';
}

function tHomeworkView() {
  return `<div id="t-homework-content">${tHomeworkBody()}</div>`;
}
function tHomeworkBody() {
  const st = tState.homework;
  if (st.screen === 'form') return tHomeworkFormScreen();
  if (st.screen === 'detail') {
    const hw = tGetHomework(st.hwId);
    if (!hw) { st.screen = 'list'; return tHomeworkBody(); }
    return tHomeworkDetailScreen(hw);
  }
  return tHomeworkListScreen();
}
function tRefreshHomework() { const el = document.getElementById('t-homework-content'); if (el) el.innerHTML = tHomeworkBody(); }

function tHomeworkListScreen() {
  const st = tState.homework;
  let list = TEACHER_DATA.homework.slice();
  if (st.filterClassId !== 'all') list = list.filter(h => h.classId === st.filterClassId);
  if (st.filterStatus !== 'all') list = list.filter(h => h.status === st.filterStatus);
  const q = st.search.trim().toLowerCase();
  if (q) list = list.filter(h => h.title.toLowerCase().includes(q));
  list.sort((a, b) => a.dueDate.localeCompare(b.dueDate));

  const filters = [['all', 'All'], ['published', 'Published'], ['draft', 'Draft'], ['archived', 'Archived']];
  return `
    <div class="card"><div class="card-body">
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;margin-bottom:12px">
        <select onchange="tSetHomeworkClassFilter(this.value)" style="background:var(--surface2);border:1px solid var(--border);border-radius:10px;color:var(--color-text);padding:9px 12px;font-size:13px">
          <option value="all" ${st.filterClassId==='all'?'selected':''}>${t('All Classes')}</option>
          ${TEACHER_DATA.classes.map(c => `<option value="${c.id}" ${c.id===st.filterClassId?'selected':''}>${gdCommsEsc(c.name)}</option>`).join('')}
        </select>
        <button class="st-btn" onclick="tOpenHomeworkForm('create')">+ ${t('New Homework')}</button>
      </div>
      <input class="gd-comm-search-input" type="text" placeholder="${t('Search homework by title...')}" value="${gdCommsEsc(st.search)}" oninput="tSetHomeworkSearch(this.value)">
      <div class="gd-comm-filter-row" style="margin-top:10px">${filters.map(([id, label]) => `<div class="gd-comm-filter-chip${st.filterStatus===id?' active':''}" onclick="tSetHomeworkStatusFilter('${id}')">${t(label)}</div>`).join('')}</div>
    </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Homework')}</div></div>
      <div id="t-homework-list-results" class="card-body">${tHomeworkListResultsBlock(list)}</div></div>`;
}
function tHomeworkListResultsBlock(list) {
  if (!list.length) return `<div class="gd-empty-mini">${t('No homework matches your search or filters.')}</div>`;
  return list.map(hw => {
    const cls = tGetClass(hw.classId);
    const counts = tHomeworkSubmissionCounts(hw);
    return `<div class="info-row" style="cursor:pointer;align-items:center" role="button" tabindex="0" onclick="tOpenHomeworkDetail('${hw.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();tOpenHomeworkDetail('${hw.id}')}">
      <span>${gdCommsEsc(hw.title)}<div style="font-size:11.5px;color:var(--muted);margin-top:2px">${cls ? gdCommsEsc(cls.name) : ''} · ${t('Due')} ${hw.dueDate}</div></span>
      <span style="text-align:right;font-size:12.5px;color:var(--muted)">
        <span class="status-pill ${tHomeworkStatusPillClass(hw.status)}">${tHomeworkStatusLabel(hw.status)}</span>
        <div style="margin-top:4px">${counts.submitted + counts.late}/${counts.total} ${t('submitted')}</div>
      </span>
    </div>`;
  }).join('');
}
function tSetHomeworkClassFilter(v) { tState.homework.filterClassId = v; tRefreshHomeworkListResults(); }
function tSetHomeworkStatusFilter(v) { tState.homework.filterStatus = v; tRefreshHomework(); }
function tSetHomeworkSearch(v) { tState.homework.search = v; tRefreshHomeworkListResults(); }
function tRefreshHomeworkListResults() {
  const st = tState.homework;
  let list = TEACHER_DATA.homework.slice();
  if (st.filterClassId !== 'all') list = list.filter(h => h.classId === st.filterClassId);
  if (st.filterStatus !== 'all') list = list.filter(h => h.status === st.filterStatus);
  const q = st.search.trim().toLowerCase();
  if (q) list = list.filter(h => h.title.toLowerCase().includes(q));
  list.sort((a, b) => a.dueDate.localeCompare(b.dueDate));
  const el = document.getElementById('t-homework-list-results');
  if (el) el.innerHTML = tHomeworkListResultsBlock(list);
}
function tOpenHomeworkDetail(hwId) {
  tState.homework.screen = 'detail';
  tState.homework.hwId = hwId;
  tState.homework.subScreen = 'details';
  tRefreshHomework();
}
function tBackToHomeworkList() {
  tState.homework.screen = 'list';
  tState.homework.hwId = null;
  tRefreshHomework();
}
function tSetHomeworkSubScreen(which) {
  tState.homework.subScreen = which;
  const el = document.getElementById('t-hw-subscreen');
  if (el) el.innerHTML = tHomeworkSubScreenBlock(tGetHomework(tState.homework.hwId));
}
function tHomeworkDetailScreen(hw) {
  const cls = tGetClass(hw.classId);
  const tabs = [ { id:'details', label:'Details' }, { id:'submissions', label:'Submissions' } ];
  return `<div class="card">
    <div class="card-header">
      <div style="display:flex;align-items:center;gap:10px;min-width:0;flex:1">
        <button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="tBackToHomeworkList()">${t('← Back')}</button>
        <div class="card-title" style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${gdCommsEsc(hw.title)}</div>
      </div>
      <span class="status-pill ${tHomeworkStatusPillClass(hw.status)}">${tHomeworkStatusLabel(hw.status)}</span>
    </div>
    <div class="card-body" style="padding-bottom:0">
      <div style="font-size:12.5px;color:var(--muted);margin-bottom:14px">${cls ? gdCommsEsc(cls.name) : ''} · ${gdCommsEsc(t(hw.subject))} · ${t('Due')} ${hw.dueDate}</div>
      <div class="st-tabs">${tabs.map(tb => `<div class="st-tab gd-tab-thw${tb.id===tState.homework.subScreen?' active':''}" data-tab="${tb.id}" onclick="tSetHomeworkSubScreen('${tb.id}')">${t(tb.label)}</div>`).join('')}</div>
    </div>
    <div class="card-body" style="padding-top:14px" id="t-hw-subscreen">${tHomeworkSubScreenBlock(hw)}</div>
  </div>`;
}
function tHomeworkSubScreenBlock(hw) {
  if (tState.homework.subScreen === 'submissions') return tHomeworkSubmissionsBlock(hw);
  return tHomeworkDetailsBlock(hw);
}
function tHomeworkDetailsBlock(hw) {
  const canPublishToggle = hw.status !== 'archived';
  return `
    ${hw.description ? `<div style="margin-bottom:14px"><div style="font-size:11.5px;color:var(--muted);margin-bottom:6px">${t('Description')}</div><div style="font-size:13px;color:var(--muted2);line-height:1.6">${gdCommsEsc(hw.description)}</div></div>` : ''}
    ${hw.instructions ? `<div style="margin-bottom:14px"><div style="font-size:11.5px;color:var(--muted);margin-bottom:6px">${t('Instructions')}</div><div style="font-size:13px;color:var(--muted2);line-height:1.6">${gdCommsEsc(hw.instructions)}</div></div>` : ''}
    <div style="margin-bottom:14px">
      <div style="font-size:11.5px;color:var(--muted);margin-bottom:6px">${t('Attachments')}</div>
      ${hw.attachments.length ? hw.attachments.map(a => `<div class="info-row"><span>${aIcon('paperclip')} ${gdCommsEsc(a.name)}</span><span style="color:var(--muted)">${tFormatFileSize(a.size)}</span></div>`).join('') : `<div class="gd-empty-mini" style="text-align:left;padding:0">${t('No attachments.')}</div>`}
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <button class="st-btn ghost sm" onclick="tOpenHomeworkForm('edit','${hw.id}')">${t('Edit')}</button>
      <button class="st-btn ghost sm" onclick="tDuplicateHomework('${hw.id}')">${t('Duplicate')}</button>
      ${canPublishToggle ? (hw.status === 'published'
        ? `<button class="st-btn ghost sm" onclick="tConfirmUnpublishHomework('${hw.id}')">${t('Unpublish')}</button>`
        : `<button class="st-btn ghost sm" onclick="tPublishHomework('${hw.id}')">${t('Publish')}</button>`) : ''}
      ${hw.status !== 'archived'
        ? `<button class="st-btn ghost sm" onclick="tConfirmArchiveHomework('${hw.id}')">${t('Archive')}</button>`
        : `<button class="st-btn ghost sm" onclick="tUnarchiveHomework('${hw.id}')">${t('Restore')}</button>`}
      <button class="st-btn ghost sm" style="color:var(--red)" onclick="tConfirmDeleteHomework('${hw.id}')">${t('Delete')}</button>
    </div>`;
}
function tFormatFileSize(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return Math.round(bytes / 1024) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
}
function tHomeworkSubmissionsBlock(hw) {
  const roster = tClassStudents(hw.classId);
  const rows = roster.map(st => {
    const status = tSubmissionStatus(hw, st.id);
    const meta = { submitted:{ cls:'open', label:t('Submitted') }, late:{ cls:'awaiting', label:t('Late') }, missing:{ cls:'overdue', label:t('Missing') }, pending:{ cls:'resolved', label:t('Not Due Yet') } }[status];
    return `<div class="info-row" style="align-items:center">
      <span style="display:flex;align-items:center;gap:10px">
        <span style="width:28px;height:28px;border-radius:50%;background:var(--surface3);display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:700;flex-shrink:0">${gdInitials(st.name)}</span>
        ${gdCommsEsc(st.name)}
      </span>
      <span class="status-pill ${meta.cls}">${meta.label}</span>
    </div>`;
  }).join('');
  const counts = tHomeworkSubmissionCounts(hw);
  return `<div class="gd-pay-stat-row" style="margin-bottom:14px">
      <div class="stat-card"><div class="stat-label">${t('Submitted')}</div><div class="stat-val">${counts.submitted + counts.late}</div><div class="stat-icon green">${aIcon('check-circle')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Missing')}</div><div class="stat-val">${counts.missing}</div><div class="stat-icon red">${aIcon('x-circle')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Not Due Yet')}</div><div class="stat-val">${counts.pending}</div><div class="stat-icon yellow">${aIcon('clock')}</div></div>
    </div>
    ${rows || `<div class="gd-empty-mini">${t('No students in this class.')}</div>`}`;
}

/* ── Advanced Homework Management: publish/unpublish, archive, delete, duplicate ── */
function tPublishHomework(hwId) {
  const hw = tGetHomework(hwId);
  if (!hw) return;
  hw.status = 'published';
  /* Write into the ONE shared homework table (js/authren-homework.js),
     translating local roster ids to real cross-role studentIds where
     one exists (currently: Youssef Amrani) — the same fix already made
     for attendance and grades. */
  if (typeof authrenPublishHomework === 'function') {
    const cls = tGetClass(hw.classId);
    const subjectId = (typeof AUTHREN_REGISTRY !== 'undefined') ? AUTHREN_REGISTRY.subjectIdForName(hw.subject) : null;
    const registryClassId = (cls && cls.name === 'Grade 10 - A' && hw.subject === 'Physics') ? 'cl-g10a' : null;
    if (subjectId && registryClassId) {
      const translatedSubmissions = {};
      const roster = tClassStudents(hw.classId);
      roster.forEach(st => {
        const key = st.studentId || st.id;
        translatedSubmissions[key] = hw.submissions[st.id] || 'pending';
      });
      authrenPublishHomework(
        { id: hw.id, classId: registryClassId, subjectId: subjectId, teacherId: (TEACHER_DATA.account || {}).timetableTeacherId,
          title: hw.title, description: hw.description, instructions: hw.instructions,
          dueDate: hw.dueDate, attachments: hw.attachments, createdAt: hw.createdAt,
          submissions: translatedSubmissions },
        { role: 'teacher', id: (TEACHER_DATA.account || {}).timetableTeacherId }
      );
    }
  }
  tRefreshHomework();
  tShowToast(t('Homework published.'));
}
function tConfirmUnpublishHomework(hwId) {
  stOpenModal(`<h3 style="margin-bottom:10px">${t('Unpublish this homework?')}</h3>
    <p style="font-size:13px;color:var(--muted);margin-bottom:18px">${t('Students will no longer see this homework until you publish it again.')}</p>
    <div style="display:flex;gap:10px">
      <button class="st-btn" onclick="tUnpublishHomework('${hwId}');stCloseModal()">${t('Unpublish')}</button>
      <button class="st-btn ghost" onclick="stCloseModal()">${t('Cancel')}</button>
    </div>`);
}
function tUnpublishHomework(hwId) {
  const hw = tGetHomework(hwId);
  if (!hw) return;
  hw.status = 'draft';
  if (typeof authrenSetHomeworkStatus === 'function') {
    authrenSetHomeworkStatus(hwId, 'unpublished', { role: 'teacher', id: (TEACHER_DATA.account || {}).timetableTeacherId });
  }
  tRefreshHomework();
  tShowToast(t('Homework unpublished.'));
}
function tConfirmArchiveHomework(hwId) {
  stOpenModal(`<h3 style="margin-bottom:10px">${t('Archive this homework?')}</h3>
    <p style="font-size:13px;color:var(--muted);margin-bottom:18px">${t('Archived homework is hidden from active lists but can be restored later.')}</p>
    <div style="display:flex;gap:10px">
      <button class="st-btn" onclick="tArchiveHomework('${hwId}');stCloseModal()">${t('Archive')}</button>
      <button class="st-btn ghost" onclick="stCloseModal()">${t('Cancel')}</button>
    </div>`);
}
function tArchiveHomework(hwId) {
  const hw = tGetHomework(hwId);
  if (!hw) return;
  hw.status = 'archived';
  if (typeof authrenSetHomeworkStatus === 'function') {
    authrenSetHomeworkStatus(hwId, 'archived', { role: 'teacher', id: (TEACHER_DATA.account || {}).timetableTeacherId });
  }
  tRefreshHomework();
  tShowToast(t('Homework archived.'));
}
function tUnarchiveHomework(hwId) {
  const hw = tGetHomework(hwId);
  if (!hw) return;
  hw.status = 'draft';
  tRefreshHomework();
  tShowToast(t('Homework restored to drafts.'));
}
function tConfirmDeleteHomework(hwId) {
  stOpenModal(`<h3 style="margin-bottom:10px">${t('Delete this homework?')}</h3>
    <p style="font-size:13px;color:var(--muted);margin-bottom:18px">${t('This will permanently delete the homework and its submission records. This cannot be undone.')}</p>
    <div style="display:flex;gap:10px">
      <button class="st-btn" style="background:var(--red)" onclick="tDeleteHomework('${hwId}');stCloseModal()">${t('Delete')}</button>
      <button class="st-btn ghost" onclick="stCloseModal()">${t('Cancel')}</button>
    </div>`);
}
function tDeleteHomework(hwId) {
  TEACHER_DATA.homework = TEACHER_DATA.homework.filter(h => h.id !== hwId);
  if (typeof AUTHREN_HOMEWORK !== 'undefined') {
    AUTHREN_HOMEWORK.records = AUTHREN_HOMEWORK.records.filter(r => r.id !== hwId);
  }
  tBackToHomeworkList();
  tShowToast(t('Homework deleted.'));
}
function tDuplicateHomework(hwId) {
  const hw = tGetHomework(hwId);
  if (!hw) return;
  const copy = Object.assign({}, hw, {
    id: 'hw' + Date.now(),
    title: hw.title + ' ' + t('(Copy)'),
    status: 'draft',
    createdAt: tISODate(T_TODAY),
    attachments: hw.attachments.map(a => Object.assign({}, a)),
    submissions: {},
  });
  TEACHER_DATA.homework.push(copy);
  tOpenHomeworkDetail(copy.id);
  tShowToast(t('Homework duplicated as a new draft.'));
}

/* ── Create / Edit form (with real frontend attachment handling) ── */
const T_MAX_ATTACHMENT_SIZE = 10 * 1024 * 1024; // 10MB
function tOpenHomeworkForm(mode, hwId) {
  if (mode === 'edit') {
    const hw = tGetHomework(hwId);
    if (!hw) return;
    tState.homework.hwId = hwId;
    tState.homework.form = { mode:'edit', id:hw.id, title:hw.title, classId:hw.classId, description:hw.description || '', dueDate:hw.dueDate, instructions:hw.instructions || '', attachments: hw.attachments.map(a => Object.assign({}, a)) };
  } else {
    tState.homework.form = { mode:'create', id:null, title:'', classId: TEACHER_DATA.classes[0] ? TEACHER_DATA.classes[0].id : '', description:'', dueDate:'', instructions:'', attachments:[] };
  }
  tState.homework.screen = 'form';
  tState.homework.error = '';
  tRefreshHomework();
}
function tCancelHomeworkForm() {
  tState.homework.screen = (tState.homework.form && tState.homework.form.mode === 'edit') ? 'detail' : 'list';
  tState.homework.form = null;
  tState.homework.error = '';
  tRefreshHomework();
}
function tHomeworkFormScreen() {
  const f = tState.homework.form;
  const err = tState.homework.error;
  return `<div class="card"><div class="card-header"><div class="card-title">${f.mode==='edit'?t('Edit Homework'):t('New Homework')}</div></div>
    <div class="card-body">
      <div class="st-field"><label>${t('Title')}</label><input id="t-hw-title" value="${gdCommsEsc(f.title)}"></div>
      <div class="st-field"><label>${t('Class')}</label><select id="t-hw-class">${TEACHER_DATA.classes.map(c => `<option value="${c.id}" ${c.id===f.classId?'selected':''}>${gdCommsEsc(c.name)} — ${gdCommsEsc(t(c.subject))}</option>`).join('')}</select></div>
      <div class="st-field"><label>${t('Description')}</label><textarea id="t-hw-description" rows="2">${gdCommsEsc(f.description)}</textarea></div>
      <div class="st-field"><label>${t('Due Date')}</label><input id="t-hw-duedate" type="date" value="${f.dueDate}"></div>
      <div class="st-field"><label>${t('Instructions')}</label><textarea id="t-hw-instructions" rows="3">${gdCommsEsc(f.instructions)}</textarea></div>
      <div class="st-field">
        <label>${t('Attachments')}</label>
        <div id="t-hw-attachments">${tHomeworkAttachmentsBlock()}</div>
        <input id="t-hw-file-input" type="file" multiple style="display:none" onchange="tAddHomeworkAttachments(this.files)">
        <button type="button" class="st-btn ghost sm" style="margin-top:8px" onclick="document.getElementById('t-hw-file-input').click()">+ ${t('Add Attachment')}</button>
      </div>
      <div style="display:flex;gap:10px;margin-top:6px">
        <button class="st-btn" onclick="tSaveHomeworkForm()" ${tState.homework.saving ? 'disabled' : ''}>${tState.homework.saving ? `<span class="gd-spinner"></span>${t('Saving...')}` : (f.mode==='edit'?t('Save Changes'):t('Save as Draft'))}</button>
        ${f.mode !== 'edit' ? `<button class="st-btn ghost" onclick="tSaveHomeworkForm(true)" ${tState.homework.saving ? 'disabled' : ''}>${t('Publish')}</button>` : ''}
        <button class="st-btn ghost" onclick="tCancelHomeworkForm()" ${tState.homework.saving ? 'disabled' : ''}>${t('Cancel')}</button>
      </div>
      ${err ? `<div class="st-inline-msg err show" style="margin-top:12px">${err}</div>` : ''}
    </div></div>`;
}
function tHomeworkAttachmentsBlock() {
  const f = tState.homework.form;
  if (!f.attachments.length) return `<div class="gd-empty-mini" style="text-align:left;padding:6px 0">${t('No attachments added yet.')}</div>`;
  return f.attachments.map((a, i) => `<div class="info-row"><span>${aIcon('paperclip')} ${gdCommsEsc(a.name)}<span style="color:var(--muted);margin-left:6px">${tFormatFileSize(a.size)}</span></span><button type="button" class="st-btn ghost sm" onclick="tRemoveHomeworkAttachment(${i})">${t('Remove')}</button></div>`).join('');
}
function tAddHomeworkAttachments(fileList) {
  const f = tState.homework.form;
  let error = '';
  Array.from(fileList).forEach(file => {
    if (file.size > T_MAX_ATTACHMENT_SIZE) { error = `${t('Some files were not added because they exceed the 10MB limit.')}`; return; }
    f.attachments.push({ name: file.name, size: file.size });
  });
  tState.homework.error = error;
  document.getElementById('t-hw-attachments').innerHTML = tHomeworkAttachmentsBlock();
  if (error) tRefreshHomework();
}
function tRemoveHomeworkAttachment(index) {
  tState.homework.form.attachments.splice(index, 1);
  const el = document.getElementById('t-hw-attachments');
  if (el) el.innerHTML = tHomeworkAttachmentsBlock();
}
function tSaveHomeworkForm(publish) {
  const f = tState.homework.form;
  const title = (document.getElementById('t-hw-title').value || '').trim();
  const classId = document.getElementById('t-hw-class').value;
  const description = (document.getElementById('t-hw-description').value || '').trim();
  const dueDate = document.getElementById('t-hw-duedate').value;
  const instructions = (document.getElementById('t-hw-instructions').value || '').trim();
  Object.assign(f, { title, classId, description, dueDate, instructions });

  let err = '';
  if (!title) err = t('Homework title is required.');
  else if (!classId) err = t('Select a class.');
  else if (!dueDate) err = t('Select a due date.');

  tState.homework.error = err;
  if (err) { tRefreshHomework(); return; }

  tState.homework.saving = true;
  tRefreshHomework();
  setTimeout(() => {
    const cls = tGetClass(classId);
    if (f.mode === 'edit') {
      const hw = tGetHomework(f.id);
      Object.assign(hw, { title, classId, subject: cls ? cls.subject : hw.subject, description, dueDate, instructions, attachments: f.attachments });
      tState.homework.screen = 'detail';
      tState.homework.hwId = f.id;
      tShowToast(t('Homework updated successfully.'));
    } else {
      const newHw = { id:'hw' + Date.now(), classId, subject: cls ? cls.subject : '', title, description, dueDate, instructions, attachments: f.attachments, status: publish ? 'published' : 'draft', createdAt: tISODate(T_TODAY), submissions:{} };
      TEACHER_DATA.homework.push(newHw);
      tState.homework.screen = 'detail';
      tState.homework.hwId = newHw.id;
      tState.homework.subScreen = 'details';
      tShowToast(publish ? t('Homework created and published.') : t('Homework saved as draft.'));
    }
    tState.homework.saving = false;
    tState.homework.form = null;
    tRefreshHomework();
  }, 700);
}
function tGoToHomeworkForClass(classId) {
  tState.homework.filterClassId = classId;
  tState.homework.screen = 'list';
  authrenGoTo('homework');
}

/* ══════════════════════════════════════════════════════
   ANALYTICS — Student Progress, Class, Subject, Attendance
   Reuses the SVG chart helpers already built for Guardian
   (gdSvgLineChart/gdSvgSparkline) rather than duplicating chart code.
══════════════════════════════════════════════════════ */
function tAnalyticsView() {
  const tabs = [
    { id:'overview',   label:'Overview' },
    { id:'classes',    label:'Classes' },
    { id:'subjects',   label:'Subjects' },
    { id:'attendance', label:'Attendance' },
    { id:'students',   label:'Students' },
    { id:'behavior',   label:'Behavior' },
    { id:'intelligence', label:'Class Intelligence' },
    { id:'teacher',    label:'Teacher' },
  ];
  return `<div class="st-tabs">${tabs.map(tb => `<div class="st-tab gd-tab-tan${tb.id===tState.analytics.tab?' active':''}" data-tab="${tb.id}" onclick="tSetAnalyticsTab('${tb.id}')">${t(tb.label)}</div>`).join('')}</div>
    <div id="t-analytics-body">${tAnalyticsBody()}</div>`;
}
function tSetAnalyticsTab(tabId) {
  tState.analytics.tab = tabId;
  document.querySelectorAll('.gd-tab-tan').forEach(el => el.classList.toggle('active', el.dataset.tab === tabId));
  const el = document.getElementById('t-analytics-body');
  if (el) el.innerHTML = tAnalyticsBody();
}
function tAnalyticsBody() {
  const tab = tState.analytics.tab;
  if (tab === 'classes')    return tClassAnalyticsTab();
  if (tab === 'subjects')   return tSubjectAnalyticsTab();
  if (tab === 'attendance') return tAttendanceAnalyticsTab();
  if (tab === 'students')   return tStudentAnalyticsTab();
  if (tab === 'behavior')   return tBehaviorAnalyticsTab();
  if (tab === 'intelligence') return tClassIntelligenceTab();
  if (tab === 'teacher')    return tTeacherAnalyticsTab();
  return tAnalyticsOverviewTab();
}

/* ── Class Analytics ── */
function tClassGradeDistribution(classId) {
  const buckets = [ { label:'0–8',  min:0,  max:8,  count:0 }, { label:'8–12', min:8,  max:12, count:0 }, { label:'12–16', min:12, max:16, count:0 }, { label:'16–20', min:16, max:20.01, count:0 } ];
  tClassStudents(classId).forEach(st => {
    const b = buckets.find(b => st.avgGrade >= b.min && st.avgGrade < b.max);
    if (b) b.count++;
  });
  return buckets;
}
function tClassProgressPoints(classId) {
  return tClassExams(classId).slice().sort((a, b) => a.date.localeCompare(b.date)).map(e => {
    const scores = Object.values(e.scores);
    if (!scores.length) return null;
    const avgPct = Math.round(scores.reduce((s, v) => s + (v / e.maxScore) * 100, 0) / scores.length);
    return { label: e.date.slice(5), value: avgPct };
  }).filter(Boolean);
}
function tClassHomeworkRate(classId) {
  const items = TEACHER_DATA.homework.filter(h => h.classId === classId && h.status !== 'draft' && h.status !== 'archived');
  if (!items.length) return null;
  const rates = items.map(h => {
    const c = tHomeworkSubmissionCounts(h);
    return c.total ? ((c.submitted + c.late) / c.total) * 100 : 0;
  });
  return Math.round(tAvg(rates));
}
function tSetClassAnalyticsClass(v) { tState.analytics.classId = v; const el = document.getElementById('t-analytics-body'); if (el) el.innerHTML = tAnalyticsBody(); }
function tClassAnalyticsTab() {
  if (!tState.analytics.classId && TEACHER_DATA.classes.length) tState.analytics.classId = TEACHER_DATA.classes[0].id;
  const classId = tState.analytics.classId;
  const cls = tGetClass(classId);
  if (!cls) return `<div class="gd-empty-mini">${t('No classes assigned yet.')}</div>`;
  const dist = tClassGradeDistribution(classId);
  const maxCount = Math.max(1, ...dist.map(b => b.count));
  const progressPoints = tClassProgressPoints(classId);
  const hwRate = tClassHomeworkRate(classId);
  return `
    <div class="card"><div class="card-body">
      <select onchange="tSetClassAnalyticsClass(this.value)" style="background:var(--surface2);border:1px solid var(--border);border-radius:10px;color:var(--color-text);padding:9px 12px;font-size:13px">
        ${TEACHER_DATA.classes.map(c => `<option value="${c.id}" ${c.id===classId?'selected':''}>${gdCommsEsc(c.name)} — ${gdCommsEsc(t(c.subject))}</option>`).join('')}
      </select>
    </div></div>
    <div class="gd-pay-stat-row" style="margin-top:16px">
      <div class="stat-card"><div class="stat-label">${t('Avg. Performance')}</div><div class="stat-val">${tClassAvgPerformance(classId)}/20</div><div class="stat-icon green">${aIcon('bar-chart')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Avg. Attendance')}</div><div class="stat-val">${tClassAttendanceRate(classId)}%</div><div class="stat-icon blue">${aIcon('check-circle')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Homework Completion')}</div><div class="stat-val">${hwRate !== null ? hwRate + '%' : '—'}</div><div class="stat-icon yellow">${aIcon('book')}</div></div>
    </div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Grade Distribution')}</div></div>
      <div class="card-body">
        ${dist.map(b => `<div style="margin-bottom:12px">
          <div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:5px"><span>${b.label}</span><span style="color:var(--muted)">${b.count} ${t(b.count===1?'student':'students')}</span></div>
          <div class="progress-track"><div class="progress-fill ${b.min>=16?'green':b.min>=12?'yellow':'red'}" style="width:${(b.count/maxCount*100).toFixed(0)}%"></div></div>
        </div>`).join('')}
      </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Progress Over Time')}</div><span style="font-size:12px;color:var(--muted)">${t('Class average per assessment')}</span></div>
      <div class="card-body">${gdSvgLineChart(progressPoints, { max:100, unit:'%', ariaLabel:t('Class progress over time'), emptyText:t('Not enough graded assessments yet to show a trend.') })}</div></div>`;
}

/* ── Subject Analytics (aggregates across every class that shares a subject) ── */
function tAllSubjects() {
  const seen = {};
  TEACHER_DATA.classes.forEach(c => { seen[c.subject] = true; });
  return Object.keys(seen);
}
function tSubjectClasses(subject) { return TEACHER_DATA.classes.filter(c => c.subject === subject); }
function tSetSubjectAnalytics(v) { tState.analytics.subject = v; const el = document.getElementById('t-analytics-body'); if (el) el.innerHTML = tAnalyticsBody(); }
function tSubjectAnalyticsTab() {
  const subjects = tAllSubjects();
  if (!tState.analytics.subject && subjects.length) tState.analytics.subject = subjects[0];
  const subject = tState.analytics.subject;
  if (!subject) return `<div class="gd-empty-mini">${t('No subjects assigned yet.')}</div>`;
  const classes = tSubjectClasses(subject);
  const studentIds = classes.flatMap(c => tClassStudents(c.id).map(s => s.id));
  const avgPerf = tAvg(classes.map(c => tClassAvgPerformance(c.id)).filter(v => v !== null));
  const avgAtt = tAvg(classes.map(c => tClassAttendanceRate(c.id)).filter(v => v !== null));
  const exams = TEACHER_DATA.exams.filter(e => classes.some(c => c.id === e.classId));
  return `
    <div class="card"><div class="card-body">
      <select onchange="tSetSubjectAnalytics(this.value)" style="background:var(--surface2);border:1px solid var(--border);border-radius:10px;color:var(--color-text);padding:9px 12px;font-size:13px">
        ${subjects.map(s => `<option value="${gdCommsEsc(s)}" ${s===subject?'selected':''}>${gdCommsEsc(t(s))}</option>`).join('')}
      </select>
    </div></div>
    <div class="gd-pay-stat-row" style="margin-top:16px">
      <div class="stat-card"><div class="stat-label">${t('Avg. Performance')}</div><div class="stat-val">${avgPerf !== null ? avgPerf + '/20' : '—'}</div><div class="stat-icon green">${aIcon('bar-chart')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Avg. Attendance')}</div><div class="stat-val">${avgAtt !== null ? avgAtt + '%' : '—'}</div><div class="stat-icon blue">${aIcon('check-circle')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Students')}</div><div class="stat-val">${studentIds.length}</div><div class="stat-icon purple">${aIcon('users')}</div></div>
    </div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Classes Teaching')} ${gdCommsEsc(t(subject))}</div></div>
      <div class="card-body">
        ${classes.map(c => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="tGoToClass('${c.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();tGoToClass('${c.id}')}">
          <span>${gdCommsEsc(c.name)}</span><span style="color:var(--muted);font-size:12.5px">${tClassAvgPerformance(c.id)}/20 · ${tClassAttendanceRate(c.id)}%</span>
        </div>`).join('')}
      </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Assessments in')} ${gdCommsEsc(t(subject))}</div></div>
      <div class="card-body">
        ${exams.length ? exams.map(e => `<div class="info-row"><span>${gdCommsEsc(e.name)}</span><span style="color:var(--muted);font-size:12.5px">${e.date}</span></div>`).join('') : `<div class="gd-empty-mini">${t('No assessments recorded for this subject yet.')}</div>`}
      </div></div>`;
}

/* ── Attendance Analytics (from real saved sessions — see batch 3's attendanceRecords) ── */
function tClassAttendanceSessions(classId) {
  return Object.keys(TEACHER_DATA.attendanceRecords)
    .filter(k => k.indexOf(classId + '|') === 0)
    .map(k => ({ date: k.split('|')[1], statuses: TEACHER_DATA.attendanceRecords[k] }))
    .sort((a, b) => a.date.localeCompare(b.date));
}
function tSetAttendanceAnalyticsClass(v) { tState.analytics.attClassId = v; const el = document.getElementById('t-analytics-body'); if (el) el.innerHTML = tAnalyticsBody(); }
function tAttendanceAnalyticsTab() {
  if (!tState.analytics.attClassId && TEACHER_DATA.classes.length) tState.analytics.attClassId = TEACHER_DATA.classes[0].id;
  const classId = tState.analytics.attClassId;
  const cls = tGetClass(classId);
  if (!cls) return `<div class="gd-empty-mini">${t('No classes assigned yet.')}</div>`;
  const sessions = tClassAttendanceSessions(classId);
  const roster = tClassStudents(classId);
  const points = sessions.map(s => {
    const vals = Object.values(s.statuses);
    const presentCount = vals.filter(v => v === 'present' || v === 'late').length;
    return { label: s.date.slice(5), value: vals.length ? Math.round((presentCount / vals.length) * 100) : 0 };
  });
  let totalMarks = 0, absentMarks = 0, lateMarks = 0;
  sessions.forEach(s => { Object.values(s.statuses).forEach(v => { totalMarks++; if (v === 'absent') absentMarks++; if (v === 'late') lateMarks++; }); });
  const absenceRate = totalMarks ? Math.round((absentMarks / totalMarks) * 100) : null;
  const lateRate = totalMarks ? Math.round((lateMarks / totalMarks) * 100) : null;
  const breakdown = roster.map(st => {
    let absences = 0, lates = 0;
    sessions.forEach(s => { const v = s.statuses[st.id]; if (v === 'absent') absences++; else if (v === 'late') lates++; });
    return { student: st, absences, lates };
  });
  return `
    <div class="card"><div class="card-body">
      <select onchange="tSetAttendanceAnalyticsClass(this.value)" style="background:var(--surface2);border:1px solid var(--border);border-radius:10px;color:var(--color-text);padding:9px 12px;font-size:13px">
        ${TEACHER_DATA.classes.map(c => `<option value="${c.id}" ${c.id===classId?'selected':''}>${gdCommsEsc(c.name)}</option>`).join('')}
      </select>
    </div></div>
    <div class="gd-pay-stat-row" style="margin-top:16px">
      <div class="stat-card"><div class="stat-label">${t('Sessions Recorded')}</div><div class="stat-val">${sessions.length}</div><div class="stat-icon blue">${aIcon('calendar')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Absence Rate')}</div><div class="stat-val">${absenceRate !== null ? absenceRate + '%' : '—'}</div><div class="stat-icon red">${aIcon('x-circle')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Late Rate')}</div><div class="stat-val">${lateRate !== null ? lateRate + '%' : '—'}</div><div class="stat-icon yellow">${aIcon('clock')}</div></div>
    </div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Attendance Trend')}</div><span style="font-size:12px;color:var(--muted)">${t('% present per recorded session')}</span></div>
      <div class="card-body">${gdSvgLineChart(points, { max:100, unit:'%', ariaLabel:t('Attendance trend'), emptyText:t('No attendance has been recorded for this class yet.') })}</div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Student Breakdown')}</div><span style="font-size:12px;color:var(--muted)">${t('Official rate · recorded absences/lates')}</span></div>
      <div class="card-body">
        ${breakdown.map(row => `<div class="info-row"><span>${gdCommsEsc(row.student.name)}</span><span style="text-align:right;font-size:12px;color:var(--muted)">${row.student.attendanceRate}% · ${row.absences} ${t('absences')}, ${row.lates} ${t('late')}</span></div>`).join('') || `<div class="gd-empty-mini">${t('No students in this class.')}</div>`}
      </div></div>`;
}

/* ── Student Analytics / Progress Graphs (real exam-score history) ── */
function tStudentExamHistory(studentId) {
  return TEACHER_DATA.exams
    .filter(e => e.scores[studentId] !== undefined)
    .map(e => ({ date: e.date, name: e.name, score: e.scores[studentId], maxScore: e.maxScore }))
    .sort((a, b) => a.date.localeCompare(b.date));
}
function tSetStudentAnalyticsSearch(v) {
  tState.analytics.studentSearch = v;
  const el = document.getElementById('t-analytics-student-results');
  if (el) el.innerHTML = tStudentAnalyticsResultsBlock();
}
function tStudentAnalyticsResultsBlock() {
  const q = tState.analytics.studentSearch.trim().toLowerCase();
  if (!q) return '';
  const results = TEACHER_DATA.students.filter(s => s.name.toLowerCase().includes(q) || s.studentId.toLowerCase().includes(q));
  if (!results.length) return `<div class="gd-empty-mini" style="text-align:left;padding:12px 0 0">${t('No students match your search.')}</div>`;
  return `<div style="margin-top:10px">${results.map(s => {
    const cls = tGetClass(s.classId);
    return `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="tSelectAnalyticsStudent('${s.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();tSelectAnalyticsStudent('${s.id}')}">
      <span>${gdCommsEsc(s.name)}<div style="font-size:11px;color:var(--muted)">${cls ? gdCommsEsc(cls.name) : ''}</div></span><span style="color:var(--muted);font-size:12.5px">${s.avgGrade}/20</span>
    </div>`;
  }).join('')}</div>`;
}
function tSelectAnalyticsStudent(studentId) {
  tState.analytics.studentId = studentId;
  tState.analytics.studentSearch = '';
  const el = document.getElementById('t-analytics-body');
  if (el) el.innerHTML = tAnalyticsBody();
}
function tGoToStudentAnalytics(studentId) {
  tState.analytics.studentId = studentId;
  tState.analytics.tab = 'students';
  authrenGoTo('analytics');
}
function tStudentAnalyticsTab() {
  const student = tState.analytics.studentId ? tGetStudent(tState.analytics.studentId) : null;
  const searchBox = `<div class="card"><div class="card-header"><div class="card-title">${t('Find a Student')}</div></div>
    <div class="card-body">
      <input class="gd-comm-search-input" type="text" placeholder="${t('Search by name or student ID...')}" value="${gdCommsEsc(tState.analytics.studentSearch)}" oninput="tSetStudentAnalyticsSearch(this.value)">
      <div id="t-analytics-student-results">${tStudentAnalyticsResultsBlock()}</div>
    </div></div>`;
  if (!student) {
    return searchBox + `<div class="gd-empty-state" style="margin-top:16px"><div class="gd-empty-state-title">${t('No student selected')}</div><div class="gd-empty-state-sub">${t('Search for a student above to see their progress.')}</div></div>`;
  }
  const history = tStudentExamHistory(student.id);
  const points = history.map(h => ({ label: h.date.slice(5), value: Math.round((h.score / h.maxScore) * 100) }));
  const cls = tGetClass(student.classId);
  return searchBox + `
    <div class="card" style="margin-top:16px"><div class="card-header"><div style="display:flex;align-items:center;gap:10px"><span style="width:32px;height:32px;border-radius:50%;background:var(--surface3);display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700">${gdInitials(student.name)}</span><div class="card-title">${gdCommsEsc(student.name)}</div></div></div>
      <div class="card-body">
        <div style="font-size:12px;color:var(--muted);margin-bottom:14px">${cls ? gdCommsEsc(cls.name) : ''} · ${gdCommsEsc(student.studentId)}</div>
        <div class="gd-pay-stat-row">
          <div class="stat-card"><div class="stat-label">${t('Current Average')}</div><div class="stat-val">${student.avgGrade}/20</div><div class="stat-icon ${student.avgGrade<12?'red':'green'}">${aIcon('bar-chart')}</div></div>
          <div class="stat-card"><div class="stat-label">${t('Attendance')}</div><div class="stat-val">${student.attendanceRate}%</div><div class="stat-icon ${student.attendanceRate<90?'yellow':'green'}">${aIcon('check-circle')}</div></div>
          <div class="stat-card"><div class="stat-label">${t('Assessments')}</div><div class="stat-val">${history.length}</div><div class="stat-icon purple">${aIcon('edit')}</div></div>
        </div>
      </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Grade Progression')}</div><span style="font-size:12px;color:var(--muted)">${t('Score per assessment, as a percentage')}</span></div>
      <div class="card-body">${gdSvgLineChart(points, { max:100, unit:'%', ariaLabel:t('Grade progression'), emptyText:t('Not enough graded assessments yet for this student.') })}</div></div>
    ${history.length ? `<div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Assessment History')}</div></div>
      <div class="card-body">${history.map(h => `<div class="info-row"><span>${gdCommsEsc(h.name)}<div style="font-size:11px;color:var(--muted)">${h.date}</div></span><span>${h.score}/${h.maxScore}</span></div>`).join('')}</div></div>` : ''}`;
}

/* ── Advanced Behavior Analytics ── */
function tSetBehaviorAnalyticsClass(v) { tState.analytics.behaviorClassId = v; const el = document.getElementById('t-analytics-body'); if (el) el.innerHTML = tAnalyticsBody(); }
function tBehaviorAnalyticsTab() {
  const classId = tState.analytics.behaviorClassId || 'all';
  const studentIds = classId === 'all' ? TEACHER_DATA.students.map(s => s.id) : tClassStudents(classId).map(s => s.id);
  const behaviorRecs = TEACHER_DATA.behaviorRecords.filter(r => studentIds.includes(r.studentId));
  const participationRecs = TEACHER_DATA.participationRecords.filter(r => studentIds.includes(r.studentId));

  const behaviorCounts = {};
  behaviorRecs.forEach(r => { behaviorCounts[r.category] = (behaviorCounts[r.category] || 0) + 1; });
  const participationCounts = {};
  participationRecs.forEach(r => { participationCounts[r.type] = (participationCounts[r.type] || 0) + 1; });

  const perStudent = {};
  behaviorRecs.forEach(r => { perStudent[r.studentId] = (perStudent[r.studentId] || 0) + 1; });
  const flagged = Object.keys(perStudent).filter(id => perStudent[id] >= 2).map(id => ({ student: tGetStudent(id), count: perStudent[id] })).filter(x => x.student);

  return `
    <div class="card"><div class="card-body">
      <select onchange="tSetBehaviorAnalyticsClass(this.value)" style="background:var(--surface2);border:1px solid var(--border);border-radius:10px;color:var(--color-text);padding:9px 12px;font-size:13px">
        <option value="all" ${classId==='all'?'selected':''}>${t('All Classes')}</option>
        ${TEACHER_DATA.classes.map(c => `<option value="${c.id}" ${c.id===classId?'selected':''}>${gdCommsEsc(c.name)}</option>`).join('')}
      </select>
    </div></div>
    <div class="gd-pay-stat-row" style="margin-top:16px">
      <div class="stat-card"><div class="stat-label">${t('Behavior Records')}</div><div class="stat-val">${behaviorRecs.length}</div><div class="stat-icon yellow">${aIcon('alert-triangle')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Participation Records')}</div><div class="stat-val">${participationRecs.length}</div><div class="stat-icon blue">${aIcon('user-check')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Students Flagged')}</div><div class="stat-val">${flagged.length}</div><div class="stat-icon red">${aIcon('refresh')}</div></div>
    </div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Behavior by Category')}</div></div>
      <div class="card-body">
        ${Object.keys(behaviorCounts).length ? Object.keys(behaviorCounts).map(cat => `<div class="info-row"><span>${gdCommsEsc(t(cat))}</span><span style="color:var(--muted)">${behaviorCounts[cat]}</span></div>`).join('') : `<div class="gd-empty-mini">${t('No behavior records for this selection yet.')}</div>`}
      </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Participation by Type')}</div></div>
      <div class="card-body">
        ${Object.keys(participationCounts).length ? Object.keys(participationCounts).map(ty => `<div class="info-row"><span>${gdCommsEsc(t(ty))}</span><span style="color:var(--muted)">${participationCounts[ty]}</span></div>`).join('') : `<div class="gd-empty-mini">${t('No participation records for this selection yet.')}</div>`}
      </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Recurring Behavior Pattern')}</div><span style="font-size:12px;color:var(--muted)">${t('2 or more records')}</span></div>
      <div class="card-body">
        ${flagged.length ? flagged.map(f => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="tGoToStudentFromAnalytics('${f.student.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();tGoToStudentFromAnalytics('${f.student.id}')}">
          <span>${gdCommsEsc(f.student.name)}</span><span style="color:var(--muted);font-size:12.5px">${f.count} ${t('records')}</span>
        </div>`).join('') : `<div class="gd-empty-mini">${t('No recurring behavior patterns detected.')}</div>`}
      </div></div>`;
}
/* Cross-navigation from any Analytics list into Class Detail's student
   view, preserving the correct class/student context. */
function tGoToStudentFromAnalytics(studentId) {
  const student = tGetStudent(studentId);
  if (!student) return;
  tState.classesNav = { screen:'student', classId: student.classId, studentId, classTab:'students' };
  authrenGoTo('classes');
}

/* ── Advanced Class Intelligence (also covers Advanced Improvement Tracking) ──
   A curated, actionable view rather than raw stats — highlights who needs
   attention and why, with drill-down into the actual student record. */
function tSetClassIntelligence(v) { tState.analytics.intelClassId = v; const el = document.getElementById('t-analytics-body'); if (el) el.innerHTML = tAnalyticsBody(); }
function tStudentExamTrend(studentId) {
  const history = tStudentExamHistory(studentId);
  if (history.length < 2) return null;
  const firstPct = (history[0].score / history[0].maxScore) * 100;
  const lastPct = (history[history.length - 1].score / history[history.length - 1].maxScore) * 100;
  return Math.round(lastPct - firstPct);
}
function tIntelInsightRow(student, detail) {
  return `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="tGoToStudentFromAnalytics('${student.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();tGoToStudentFromAnalytics('${student.id}')}">
    <span>${gdCommsEsc(student.name)}</span><span style="color:var(--muted);font-size:12.5px">${detail}</span>
  </div>`;
}
function tClassIntelligenceTab() {
  if (!tState.analytics.intelClassId && TEACHER_DATA.classes.length) tState.analytics.intelClassId = TEACHER_DATA.classes[0].id;
  const classId = tState.analytics.intelClassId;
  const cls = tGetClass(classId);
  if (!cls) return `<div class="gd-empty-mini">${t('No classes assigned yet.')}</div>`;
  const roster = tClassStudents(classId);

  const topPerformers = roster.slice().sort((a, b) => b.avgGrade - a.avgGrade).slice(0, 3);
  const needsAttention = roster.filter(tStudentNeedsAttention);
  const attendanceConcerns = roster.filter(s => s.attendanceRate < 90);

  const classHw = TEACHER_DATA.homework.filter(h => h.classId === classId && h.status === 'published' && h.dueDate < tISODate(T_TODAY));
  const missingIds = new Set();
  classHw.forEach(h => roster.forEach(s => { if (tSubmissionStatus(h, s.id) === 'missing') missingIds.add(s.id); }));
  const homeworkConcerns = roster.filter(s => missingIds.has(s.id));

  const behaviorCountByStudent = {};
  TEACHER_DATA.behaviorRecords.filter(r => roster.some(s => s.id === r.studentId)).forEach(r => { behaviorCountByStudent[r.studentId] = (behaviorCountByStudent[r.studentId] || 0) + 1; });
  const behaviorPatterns = roster.filter(s => (behaviorCountByStudent[s.id] || 0) >= 2);

  const improvementOpportunities = roster.map(s => ({ student:s, trend: tStudentExamTrend(s.id) })).filter(x => x.trend !== null && x.trend < 0);

  return `
    <div class="card"><div class="card-body">
      <select onchange="tSetClassIntelligence(this.value)" style="background:var(--surface2);border:1px solid var(--border);border-radius:10px;color:var(--color-text);padding:9px 12px;font-size:13px">
        ${TEACHER_DATA.classes.map(c => `<option value="${c.id}" ${c.id===classId?'selected':''}>${gdCommsEsc(c.name)} — ${gdCommsEsc(t(c.subject))}</option>`).join('')}
      </select>
    </div></div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${aIcon('star')} ${t('Top Performers')}</div></div>
      <div class="card-body">${topPerformers.map(s => tIntelInsightRow(s, s.avgGrade + '/20')).join('') || `<div class="gd-empty-mini">${t('No students in this class.')}</div>`}</div></div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${aIcon('alert-triangle')} ${t('Needs Attention')}</div><span style="font-size:12px;color:var(--muted)">${t('Low grade or attendance')}</span></div>
      <div class="card-body">${needsAttention.length ? needsAttention.map(s => tIntelInsightRow(s, `${s.avgGrade}/20 · ${s.attendanceRate}%`)).join('') : `<div class="gd-empty-mini">${t('No students currently flagged.')}</div>`}</div></div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${aIcon('calendar')} ${t('Attendance Concerns')}</div><span style="font-size:12px;color:var(--muted)">${t('Below 90%')}</span></div>
      <div class="card-body">${attendanceConcerns.length ? attendanceConcerns.map(s => tIntelInsightRow(s, s.attendanceRate + '%')).join('') : `<div class="gd-empty-mini">${t('No attendance concerns for this class.')}</div>`}</div></div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${aIcon('book')} ${t('Homework Concerns')}</div><span style="font-size:12px;color:var(--muted)">${t('Missing at least one past-due assignment')}</span></div>
      <div class="card-body">${homeworkConcerns.length ? homeworkConcerns.map(s => tIntelInsightRow(s, t('Missing submissions'))).join('') : `<div class="gd-empty-mini">${t('No homework concerns for this class.')}</div>`}</div></div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${aIcon('refresh')} ${t('Behavior/Participation Patterns')}</div></div>
      <div class="card-body">${behaviorPatterns.length ? behaviorPatterns.map(s => tIntelInsightRow(s, `${behaviorCountByStudent[s.id]} ${t('records')}`)).join('') : `<div class="gd-empty-mini">${t('No recurring patterns detected.')}</div>`}</div></div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${aIcon('trending-down')} ${t('Improvement Opportunities')}</div><span style="font-size:12px;color:var(--muted)">${t('Declining trend across assessments')}</span></div>
      <div class="card-body">${improvementOpportunities.length ? improvementOpportunities.map(x => tIntelInsightRow(x.student, `${x.trend}% ${t('trend')}`)).join('') : `<div class="gd-empty-mini">${t('No declining trends detected for this class.')}</div>`}</div></div>`;
}

/* ── Advanced Teacher Analytics ──
   Unifies workload/productivity signals across every Teacher module
   (classes, grading, exams, homework, attendance, communication, support,
   tools) into one coherent view, rather than separate dashboards. */
function tTeacherAnalyticsTab() {
  const totalStudents = TEACHER_DATA.students.length;
  const totalExams = TEACHER_DATA.exams.length;
  const lockedExams = TEACHER_DATA.exams.filter(e => e.locked).length;
  const totalScoresEntered = TEACHER_DATA.exams.reduce((sum, e) => sum + Object.keys(e.scores).length, 0);
  const totalHw = TEACHER_DATA.homework.length;
  const publishedHw = TEACHER_DATA.homework.filter(h => h.status === 'published').length;
  const sessionsRecorded = Object.keys(TEACHER_DATA.attendanceRecords).length;
  const conversationsHandled = TEACHER_DATA.conversations.filter(c => c.messages.some(m => m.from === 'me')).length;
  const supportTickets = TEACHER_DATA.supportTickets.length;
  const behaviorRecs = TEACHER_DATA.behaviorRecords.length + TEACHER_DATA.participationRecords.length;

  return `
    <div class="gd-stat-row">
      <div class="stat-card"><div class="stat-label">${t('Classes')}</div><div class="stat-val">${TEACHER_DATA.classes.length}</div><div class="stat-icon blue">${aIcon('school')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Students')}</div><div class="stat-val">${totalStudents}</div><div class="stat-icon purple">${aIcon('users')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Assessments')}</div><div class="stat-val">${totalExams}</div><div class="stat-icon green">${aIcon('edit')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Homework Items')}</div><div class="stat-val">${totalHw}</div><div class="stat-icon yellow">${aIcon('book')}</div></div>
    </div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Grading Workload')}</div></div>
      <div class="card-body">
        <div class="info-row"><span>${t('Scores Entered')}</span><span>${totalScoresEntered}</span></div>
        <div class="info-row"><span>${t('Assessments Locked')}</span><span>${lockedExams} / ${totalExams}</span></div>
      </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Teaching Activity')}</div></div>
      <div class="card-body">
        <div class="info-row"><span>${t('Homework Published')}</span><span>${publishedHw} / ${totalHw}</span></div>
        <div class="info-row"><span>${t('Attendance Sessions Recorded')}</span><span>${sessionsRecorded}</span></div>
        <div class="info-row"><span>${t('Behavior/Participation Records')}</span><span>${behaviorRecs}</span></div>
      </div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Communication & Support')}</div></div>
      <div class="card-body">
        <div class="info-row"><span>${t('Conversations Replied To')}</span><span>${conversationsHandled} / ${TEACHER_DATA.conversations.length}</span></div>
        <div class="info-row"><span>${t('Support Requests Submitted')}</span><span>${supportTickets}</span></div>
      </div></div>`;
}

/* ══════════════════════════════════════════════════════
   BEHAVIOR & PARTICIPATION
   One nav entry, two tabs, sharing the same student-selection state so
   switching between Behavior and Participation for the same student
   doesn't require re-searching.
══════════════════════════════════════════════════════ */
const T_BEHAVIOR_CATEGORIES = ['Positive Behavior', 'Disruption', 'Excellent Participation', 'Late to Class', 'Conflict with Peer', 'Other'];
const T_PARTICIPATION_TYPES = ['Excellent', 'Active', 'Passive', 'Disruptive', 'Absent from Discussion'];
function tGetBehaviorRecord(id) { return TEACHER_DATA.behaviorRecords.find(r => r.id === id) || null; }
function tGetParticipationRecord(id) { return TEACHER_DATA.participationRecords.find(r => r.id === id) || null; }
function tStudentBehaviorRecords(studentId) { return TEACHER_DATA.behaviorRecords.filter(r => r.studentId === studentId).slice().sort((a, b) => b.date.localeCompare(a.date)); }
function tStudentParticipationRecords(studentId) { return TEACHER_DATA.participationRecords.filter(r => r.studentId === studentId).slice().sort((a, b) => b.date.localeCompare(a.date)); }

function tBehaviorView() {
  const tabs = [ { id:'behavior', label:'Behavior Records' }, { id:'participation', label:'Participation' } ];
  return `<div class="st-tabs">${tabs.map(tb => `<div class="st-tab gd-tab-tbh${tb.id===tState.behavior.tab?' active':''}" data-tab="${tb.id}" onclick="tSetBehaviorTab('${tb.id}')">${t(tb.label)}</div>`).join('')}</div>
    <div id="t-behavior-body">${tBehaviorBody()}</div>`;
}
function tSetBehaviorTab(tabId) {
  tState.behavior.tab = tabId;
  tState.behavior.form = null;
  document.querySelectorAll('.gd-tab-tbh').forEach(el => el.classList.toggle('active', el.dataset.tab === tabId));
  const el = document.getElementById('t-behavior-body');
  if (el) el.innerHTML = tBehaviorBody();
}
function tBehaviorBody() {
  const studentPicker = tBehaviorStudentPicker();
  const student = tState.behavior.studentId ? tGetStudent(tState.behavior.studentId) : null;
  if (!student) {
    return studentPicker + `<div class="gd-empty-state" style="margin-top:16px"><div class="gd-empty-state-title">${t('No student selected')}</div><div class="gd-empty-state-sub">${t('Search for a student above to view or add records.')}</div></div>`;
  }
  return studentPicker + (tState.behavior.tab === 'participation' ? tParticipationPanel(student) : tBehaviorPanel(student));
}
function tBehaviorStudentPicker() {
  const student = tState.behavior.studentId ? tGetStudent(tState.behavior.studentId) : null;
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Student')}</div>${student ? `<div class="card-action" onclick="tClearBehaviorStudent()">${t('Change')}</div>` : ''}</div>
    <div class="card-body">
      ${student
        ? `<div style="display:flex;align-items:center;gap:10px"><span style="width:32px;height:32px;border-radius:50%;background:var(--surface3);display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700">${gdInitials(student.name)}</span><span>${gdCommsEsc(student.name)}<div style="font-size:11px;color:var(--muted)">${gdCommsEsc(student.studentId)}</div></span></div>`
        : `<input class="gd-comm-search-input" type="text" placeholder="${t('Search by name or student ID...')}" value="${gdCommsEsc(tState.behavior.studentSearch)}" oninput="tSetBehaviorStudentSearch(this.value)"><div id="t-behavior-student-results">${tBehaviorStudentResultsBlock()}</div>`}
    </div></div>`;
}
function tBehaviorStudentResultsBlock() {
  const q = tState.behavior.studentSearch.trim().toLowerCase();
  if (!q) return '';
  const results = TEACHER_DATA.students.filter(s => s.name.toLowerCase().includes(q) || s.studentId.toLowerCase().includes(q));
  if (!results.length) return `<div class="gd-empty-mini" style="text-align:left;padding:12px 0 0">${t('No students match your search.')}</div>`;
  return `<div style="margin-top:10px">${results.map(s => {
    const cls = tGetClass(s.classId);
    return `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="tSelectBehaviorStudent('${s.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();tSelectBehaviorStudent('${s.id}')}">
      <span>${gdCommsEsc(s.name)}<div style="font-size:11px;color:var(--muted)">${cls ? gdCommsEsc(cls.name) : ''}</div></span><span style="color:var(--muted);font-size:12px">${gdCommsEsc(s.studentId)}</span>
    </div>`;
  }).join('')}</div>`;
}
function tSetBehaviorStudentSearch(v) { tState.behavior.studentSearch = v; const el = document.getElementById('t-behavior-student-results'); if (el) el.innerHTML = tBehaviorStudentResultsBlock(); }
function tSelectBehaviorStudent(studentId) {
  tState.behavior.studentId = studentId;
  tState.behavior.studentSearch = '';
  tState.behavior.form = null;
  const el = document.getElementById('t-behavior-body');
  if (el) el.innerHTML = tBehaviorBody();
}
function tClearBehaviorStudent() {
  tState.behavior.studentId = null;
  tState.behavior.form = null;
  const el = document.getElementById('t-behavior-body');
  if (el) el.innerHTML = tBehaviorBody();
}
function tGoToBehaviorForStudent(studentId) {
  tState.behavior.studentId = studentId;
  tState.behavior.tab = 'behavior';
  authrenGoTo('behavior');
}

/* ── Behavior Records panel ── */
function tBehaviorPanel(student) {
  if (tState.behavior.form && tState.behavior.form.kind === 'behavior') return tBehaviorFormCard(student);
  const records = tStudentBehaviorRecords(student.id);
  return `<div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Behavior History')}</div><div class="card-action" onclick="tOpenBehaviorForm()">+ ${t('Add Record')}</div></div>
    <div class="card-body">
      ${records.length ? records.map(r => `<div class="info-row" style="align-items:flex-start">
        <span><span class="status-pill ${r.category==='Positive Behavior'||r.category==='Excellent Participation'?'open':r.category==='Other'?'resolved':'overdue'}">${gdCommsEsc(t(r.category))}</span>
          <div style="font-size:12.5px;color:var(--muted2);margin-top:6px;max-width:360px">${gdCommsEsc(r.description)}</div></span>
        <span style="text-align:right;flex-shrink:0">
          <div style="font-size:11px;color:var(--muted)">${r.date}</div>
          <button type="button" class="st-btn ghost sm" style="margin-top:6px" onclick="tOpenBehaviorForm('${r.id}')">${t('Edit')}</button>
        </span>
      </div>`).join('') : `<div class="gd-empty-mini">${t('No behavior records yet for this student.')}</div>`}
    </div></div>`;
}
function tOpenBehaviorForm(recordId) {
  const student = tGetStudent(tState.behavior.studentId);
  if (recordId) {
    const r = tGetBehaviorRecord(recordId);
    if (!r) return;
    const isCustom = T_BEHAVIOR_CATEGORIES.indexOf(r.category) === -1;
    tState.behavior.form = { kind:'behavior', id:r.id, category: isCustom ? 'Other' : r.category, customCategory: isCustom ? r.category : '', description:r.description, date:r.date };
  } else {
    tState.behavior.form = { kind:'behavior', id:null, category:T_BEHAVIOR_CATEGORIES[0], customCategory:'', description:'', date: tISODate(T_TODAY) };
  }
  tState.behavior.error = '';
  const el = document.getElementById('t-behavior-body');
  if (el) el.innerHTML = tBehaviorBody();
}
function tCancelBehaviorForm() {
  tState.behavior.form = null;
  tState.behavior.error = '';
  const el = document.getElementById('t-behavior-body');
  if (el) el.innerHTML = tBehaviorBody();
}
function tOnBehaviorCategoryChange(v) {
  const el = document.getElementById('t-bh-custom-wrap');
  if (el) el.style.display = v === 'Other' ? 'block' : 'none';
}
function tBehaviorFormCard(student) {
  const f = tState.behavior.form;
  const err = tState.behavior.error;
  return `<div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${f.id ? t('Edit Behavior Record') : t('New Behavior Record')}</div></div>
    <div class="card-body">
      <div style="font-size:12px;color:var(--muted);margin-bottom:12px">${t('For')} ${gdCommsEsc(student.name)}</div>
      <div class="st-field"><label>${t('Category')}</label>
        <select id="t-bh-category" onchange="tOnBehaviorCategoryChange(this.value)">
          ${T_BEHAVIOR_CATEGORIES.map(c => `<option value="${c}" ${c===f.category?'selected':''}>${t(c)}</option>`).join('')}
        </select>
      </div>
      <div id="t-bh-custom-wrap" class="st-field" style="display:${f.category==='Other'?'block':'none'}"><label>${t('Specify Category')}</label><input id="t-bh-custom-category" value="${gdCommsEsc(f.customCategory)}"></div>
      <div class="st-field"><label>${t('Description')}</label><textarea id="t-bh-description" rows="3">${gdCommsEsc(f.description)}</textarea></div>
      <div class="st-field"><label>${t('Date')}</label><input id="t-bh-date" type="date" value="${f.date}"></div>
      <div style="display:flex;gap:10px">
        <button class="st-btn" onclick="tSaveBehaviorRecord()" ${tState.behavior.saving ? 'disabled' : ''}>${tState.behavior.saving ? `<span class="gd-spinner"></span>${t('Saving...')}` : t('Save')}</button>
        <button class="st-btn ghost" onclick="tCancelBehaviorForm()" ${tState.behavior.saving ? 'disabled' : ''}>${t('Cancel')}</button>
      </div>
      ${err ? `<div class="st-inline-msg err show" style="margin-top:12px">${err}</div>` : ''}
    </div></div>`;
}
function tSaveBehaviorRecord() {
  const f = tState.behavior.form;
  const category = document.getElementById('t-bh-category').value;
  const customCategory = (document.getElementById('t-bh-custom-category') ? document.getElementById('t-bh-custom-category').value : '').trim();
  const description = (document.getElementById('t-bh-description').value || '').trim();
  const date = document.getElementById('t-bh-date').value;
  Object.assign(f, { category, customCategory, description, date });

  let err = '';
  if (category === 'Other' && !customCategory) err = t('Please specify the category.');
  else if (!description) err = t('Description is required.');
  else if (!date) err = t('Select a date.');
  tState.behavior.error = err;
  if (err) { const el = document.getElementById('t-behavior-body'); if (el) el.innerHTML = tBehaviorBody(); return; }

  tState.behavior.saving = true;
  const el0 = document.getElementById('t-behavior-body'); if (el0) el0.innerHTML = tBehaviorBody();
  setTimeout(() => {
    const finalCategory = category === 'Other' ? customCategory : category;
    if (f.id) {
      const r = tGetBehaviorRecord(f.id);
      Object.assign(r, { category: finalCategory, description, date });
      tShowToast(t('Behavior record updated.'));
    } else {
      TEACHER_DATA.behaviorRecords.push({ id:'bh' + Date.now(), studentId: tState.behavior.studentId, category: finalCategory, description, date });
      tShowToast(t('Behavior record saved.'));
    }
    tState.behavior.saving = false;
    tState.behavior.form = null;
    const el = document.getElementById('t-behavior-body');
    if (el) el.innerHTML = tBehaviorBody();
  }, 600);
}

/* ── Participation panel ── */
function tParticipationPanel(student) {
  if (tState.behavior.form && tState.behavior.form.kind === 'participation') return tParticipationFormCard(student);
  const records = tStudentParticipationRecords(student.id);
  return `<div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Participation History')}</div><div class="card-action" onclick="tOpenParticipationForm()">+ ${t('Add Record')}</div></div>
    <div class="card-body">
      ${records.length ? records.map(r => `<div class="info-row" style="align-items:flex-start">
        <span><span class="status-pill ${r.type==='Excellent'||r.type==='Active'?'open':r.type==='Passive'?'awaiting':'overdue'}">${t(r.type)}</span>
          ${r.note ? `<div style="font-size:12.5px;color:var(--muted2);margin-top:6px;max-width:360px">${gdCommsEsc(r.note)}</div>` : ''}</span>
        <span style="text-align:right;flex-shrink:0">
          <div style="font-size:11px;color:var(--muted)">${r.date}</div>
          <button type="button" class="st-btn ghost sm" style="margin-top:6px" onclick="tOpenParticipationForm('${r.id}')">${t('Edit')}</button>
        </span>
      </div>`).join('') : `<div class="gd-empty-mini">${t('No participation records yet for this student.')}</div>`}
    </div></div>`;
}
function tOpenParticipationForm(recordId) {
  if (recordId) {
    const r = tGetParticipationRecord(recordId);
    if (!r) return;
    tState.behavior.form = { kind:'participation', id:r.id, type:r.type, date:r.date, note:r.note || '' };
  } else {
    tState.behavior.form = { kind:'participation', id:null, type:T_PARTICIPATION_TYPES[0], date: tISODate(T_TODAY), note:'' };
  }
  tState.behavior.error = '';
  const el = document.getElementById('t-behavior-body');
  if (el) el.innerHTML = tBehaviorBody();
}
function tParticipationFormCard(student) {
  const f = tState.behavior.form;
  const err = tState.behavior.error;
  return `<div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${f.id ? t('Edit Participation Record') : t('New Participation Record')}</div></div>
    <div class="card-body">
      <div style="font-size:12px;color:var(--muted);margin-bottom:12px">${t('For')} ${gdCommsEsc(student.name)}</div>
      <div class="st-field"><label>${t('Type')}</label><select id="t-pt-type">${T_PARTICIPATION_TYPES.map(ty => `<option value="${ty}" ${ty===f.type?'selected':''}>${t(ty)}</option>`).join('')}</select></div>
      <div class="st-field"><label>${t('Date')}</label><input id="t-pt-date" type="date" value="${f.date}"></div>
      <div class="st-field"><label>${t('Note')} (${t('optional')})</label><textarea id="t-pt-note" rows="2">${gdCommsEsc(f.note)}</textarea></div>
      <div style="display:flex;gap:10px">
        <button class="st-btn" onclick="tSaveParticipationRecord()" ${tState.behavior.saving ? 'disabled' : ''}>${tState.behavior.saving ? `<span class="gd-spinner"></span>${t('Saving...')}` : t('Save')}</button>
        <button class="st-btn ghost" onclick="tCancelBehaviorForm()" ${tState.behavior.saving ? 'disabled' : ''}>${t('Cancel')}</button>
      </div>
      ${err ? `<div class="st-inline-msg err show" style="margin-top:12px">${err}</div>` : ''}
    </div></div>`;
}
function tSaveParticipationRecord() {
  const f = tState.behavior.form;
  const type = document.getElementById('t-pt-type').value;
  const date = document.getElementById('t-pt-date').value;
  const note = (document.getElementById('t-pt-note').value || '').trim();
  Object.assign(f, { type, date, note });

  let err = '';
  if (!date) err = t('Select a date.');
  tState.behavior.error = err;
  if (err) { const el = document.getElementById('t-behavior-body'); if (el) el.innerHTML = tBehaviorBody(); return; }

  tState.behavior.saving = true;
  const el0 = document.getElementById('t-behavior-body'); if (el0) el0.innerHTML = tBehaviorBody();
  setTimeout(() => {
    if (f.id) {
      const r = tGetParticipationRecord(f.id);
      Object.assign(r, { type, date, note });
      tShowToast(t('Participation record updated.'));
    } else {
      TEACHER_DATA.participationRecords.push({ id:'pt' + Date.now(), studentId: tState.behavior.studentId, type, date, note });
      tShowToast(t('Participation record saved.'));
    }
    tState.behavior.saving = false;
    tState.behavior.form = null;
    const el = document.getElementById('t-behavior-body');
    if (el) el.innerHTML = tBehaviorBody();
  }, 600);
}

/* ══════════════════════════════════════════════════════
   COMMUNICATION — one unified center (guardian + school), not
   disconnected systems. Reuses the same visual classes already loaded
   globally from Guardian's Communication Center (gd-conv-*, gd-comm-*)
   for visual consistency, but is implemented with fresh, independent
   Teacher-namespaced functions/state to avoid touching or risking
   Guardian's already-working, tested code.
══════════════════════════════════════════════════════ */
function tCommsView() {
  return `<div id="t-comms-content">${tCommsBody()}</div>`;
}
function tCommsBody() {
  if (tState.comms.loadState === 'idle') tCommsLoad();
  if (tState.comms.loadState === 'loading') return `<div class="gd-sc-load-state"><span class="gd-spinner"></span>${t('Loading conversations…')}</div>`;
  if (tState.comms.loadState === 'error') return tCommsErrorState();
  if (tState.comms.screen === 'compose') return tComposeScreen();
  if (tState.comms.screen === 'detail') {
    const conv = tGetConversation(tState.comms.convId);
    if (!conv) { tState.comms.screen = 'list'; return tCommsBody(); }
    return tCommsDetailScreen(conv);
  }
  return tCommsListScreen();
}
function tCommsLoad() {
  tState.comms.loadState = 'loading';
  setTimeout(() => {
    tState.comms.loadState = Math.random() < 0.08 ? 'error' : 'ready';
    const el = document.getElementById('t-comms-content');
    if (el) el.innerHTML = tCommsBody();
  }, 600);
}
function tCommsRetry() {
  tCommsLoad();
  const el = document.getElementById('t-comms-content');
  if (el) el.innerHTML = tCommsBody();
}
function tCommsErrorState() {
  return `<div class="gd-empty-state">
    <div class="gd-empty-state-ico" style="background:rgba(220,38,38,0.12);color:var(--red)"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg></div>
    <div class="gd-empty-state-title">${t("Couldn't load your conversations")}</div>
    <div class="gd-empty-state-sub">${t('Something went wrong. Please try again.')}</div>
    <button class="st-btn ghost" onclick="tCommsRetry()">${t('Retry')}</button>
  </div>`;
}
function tGetConversation(id) { return TEACHER_DATA.conversations.find(c => String(c.id) === String(id)) || null; }
function tCommsLastMessage(conv) { return conv.messages[conv.messages.length - 1] || null; }

function tCommsListScreen() {
  const s = tState.comms;
  const filters = [['all', 'All'], ['unread', 'Unread'], ['guardian', 'Guardians'], ['school', 'School']];
  return `
    <div class="card"><div class="card-header"><div class="card-title">${t('Conversations')}</div><button class="st-btn sm" onclick="tOpenCompose()">+ ${t('New Message')}</button></div>
      <div class="gd-comm-toolbar">
        <input class="gd-comm-search-input" type="text" placeholder="${t('Search conversations...')}" value="${gdCommsEsc(s.search)}" oninput="tSetCommsSearch(this.value)">
        <div class="gd-comm-filter-row">${filters.map(([id, label]) => `<div class="gd-comm-filter-chip${s.filter===id?' active':''}" onclick="tSetCommsFilter('${id}')">${t(label)}</div>`).join('')}</div>
      </div>
      <div class="card-body" style="padding:0" id="t-comms-list-results">${tCommsListResultsBlock()}</div>
    </div>`;
}
function tCommsFilteredConversations() {
  const s = tState.comms;
  let list = TEACHER_DATA.conversations.slice();
  if (s.filter === 'unread') list = list.filter(c => c.unread);
  else if (s.filter === 'guardian' || s.filter === 'school') list = list.filter(c => c.type === s.filter);
  const q = s.search.trim().toLowerCase();
  if (q) list = list.filter(c => c.name.toLowerCase().includes(q) || (c.context || '').toLowerCase().includes(q) || (tCommsLastMessage(c) && tCommsLastMessage(c).text.toLowerCase().includes(q)));
  return list;
}
function tCommsListResultsBlock() {
  const list = tCommsFilteredConversations();
  if (!TEACHER_DATA.conversations.length) return `<div class="gd-empty-state"><div class="gd-empty-state-title">${t('No conversations yet')}</div><div class="gd-empty-state-sub">${t('Start a new message to a guardian or a member of staff.')}</div></div>`;
  if (!list.length) return `<div class="gd-empty-state"><div class="gd-empty-state-title">${t('No matching conversations')}</div><div class="gd-empty-state-sub">${t('Nothing matches your current search or filter.')}</div></div>`;
  return `<div class="gd-conv-list">${list.map(c => {
    const last = tCommsLastMessage(c);
    return `<div class="gd-conv-item${c.unread ? ' unread' : ''}" role="button" tabindex="0" onclick="tOpenConversation(${c.id})" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();tOpenConversation(${c.id})}" aria-label="${c.unread ? t('Unread conversation with') : t('Conversation with')} ${gdCommsEsc(c.name)}">
      <div class="gd-conv-avatar" style="background:${c.type==='guardian'?'var(--color-primary)':'var(--color-accent)'}">${gdInitials(c.name)}</div>
      <div class="gd-conv-main">
        <div class="gd-conv-top"><span class="gd-conv-name">${gdCommsEsc(c.name)}</span>${last ? `<span class="gd-conv-time">${last.date.slice(5)}</span>` : ''}</div>
        ${c.context ? `<div class="gd-conv-context">${gdCommsEsc(c.context)}</div>` : ''}
        <div class="gd-conv-bottom">${last ? `<span class="gd-conv-preview">${last.from==='me' ? t('You')+': ' : ''}${gdCommsEsc(last.text)}</span>` : '<span></span>'}${tCommsStatusPillLike(c.status)}</div>
      </div>
      ${c.unread ? '<div class="gd-conv-unread-dot" aria-hidden="true"></div>' : ''}
    </div>`;
  }).join('')}</div>`;
}
function tCommsStatusPillLike(status) {
  const known = { open: t('Open'), awaiting: t('Awaiting Reply'), resolved: t('Resolved') };
  const label = known[status];
  return label ? `<span class="status-pill ${status}">${label}</span>` : '';
}
function tSetCommsSearch(v) { tState.comms.search = v; const el = document.getElementById('t-comms-list-results'); if (el) el.innerHTML = tCommsListResultsBlock(); }
function tCommsFilterLabel(v) { return { all:'All', unread:'Unread', guardian:'Guardians', school:'School' }[v]; }
function tSetCommsFilter(v) {
  tState.comms.filter = v;
  document.querySelectorAll('.gd-comm-filter-chip').forEach(el => el.classList.toggle('active', el.textContent === t(tCommsFilterLabel(v))));
  const el = document.getElementById('t-comms-list-results');
  if (el) el.innerHTML = tCommsListResultsBlock();
}

/* ── Conversation Detail / Thread ── */
function tOpenConversation(id) {
  const conv = tGetConversation(id);
  if (!conv) return;
  conv.unread = false;
  tState.comms.screen = 'detail';
  tState.comms.convId = id;
  tState.comms.reply = { text:'', attachments:[], error:'', sending:false };
  const el = document.getElementById('t-comms-content');
  if (el) el.innerHTML = tCommsBody();
}
function tBackToCommsList() {
  tState.comms.screen = 'list';
  tState.comms.convId = null;
  const el = document.getElementById('t-comms-content');
  if (el) el.innerHTML = tCommsBody();
}
function tCommsDetailScreen(conv) {
  return `<div class="card">
    <div class="card-header">
      <div style="display:flex;align-items:center;gap:10px;min-width:0;flex:1">
        <button type="button" class="st-btn ghost sm gd-comm-back-btn" onclick="tBackToCommsList()">${t('← Back')}</button>
        <div>
          <div class="card-title" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${gdCommsEsc(conv.name)}</div>
          ${conv.context ? `<div style="font-size:11px;color:var(--muted)">${gdCommsEsc(conv.context)}</div>` : ''}
        </div>
      </div>
      ${tCommsStatusPillLike(conv.status)}
    </div>
    <div class="card-body">
      <div style="max-height:360px;overflow-y:auto;display:flex;flex-direction:column;gap:10px;padding-bottom:6px">
        ${conv.messages.map(m => `<div style="align-self:${m.from==='me'?'flex-end':'flex-start'};max-width:80%">
          <div style="background:${m.from==='me'?'var(--accent)':'var(--surface2)'};color:${m.from==='me'?'#fff':'inherit'};border-radius:14px;padding:10px 14px;font-size:13px;line-height:1.5">${gdCommsEsc(m.text)}${m.attachments && m.attachments.length ? m.attachments.map(a => `<div style="margin-top:6px;font-size:11.5px;opacity:0.85">${aIcon('paperclip')} ${gdCommsEsc(a.name)}</div>`).join('') : ''}</div>
          <div style="font-size:10.5px;color:var(--muted);margin-top:3px;text-align:${m.from==='me'?'right':'left'}">${m.date} · ${m.time}</div>
        </div>`).join('')}
      </div>
      <div style="border-top:0.5px solid var(--separator);margin-top:12px;padding-top:12px">
        <textarea id="t-reply-text" rows="2" placeholder="${t('Type a message...')}" style="width:100%;background:var(--surface2);border:1px solid var(--border);border-radius:10px;color:var(--color-text);padding:10px 12px;font-size:13px;font-family:inherit" ${tState.comms.reply.sending?'disabled':''}>${gdCommsEsc(tState.comms.reply.text)}</textarea>
        <div id="t-reply-attachments">${tReplyAttachmentsBlock()}</div>
        <div style="display:flex;justify-content:space-between;align-items:center;margin-top:8px;gap:10px;flex-wrap:wrap">
          <div>
            <input id="t-reply-file-input" type="file" multiple style="display:none" onchange="tAddReplyAttachments(this.files)">
            <button type="button" class="st-btn ghost sm" onclick="document.getElementById('t-reply-file-input').click()">${aIcon('paperclip')} ${t('Attach')}</button>
          </div>
          <button class="st-btn sm" onclick="tSendReply(${conv.id})" ${tState.comms.reply.sending ? 'disabled' : ''}>${tState.comms.reply.sending ? `<span class="gd-spinner"></span>${t('Sending...')}` : t('Send')}</button>
        </div>
        ${tState.comms.reply.error ? `<div class="st-inline-msg err show" style="margin-top:10px">${tState.comms.reply.error}</div>` : ''}
      </div>
    </div>
  </div>`;
}
function tReplyAttachmentsBlock() {
  const atts = tState.comms.reply.attachments;
  if (!atts.length) return '';
  return `<div style="margin-top:8px">${atts.map((a, i) => `<span style="display:inline-flex;align-items:center;gap:6px;background:var(--surface2);border:1px solid var(--border);border-radius:8px;padding:4px 8px;font-size:11px;margin:0 6px 6px 0">${aIcon('paperclip')} ${gdCommsEsc(a.name)} <span style="cursor:pointer;color:var(--red)" onclick="tRemoveReplyAttachment(${i})">${aIcon('x')}</span></span>`).join('')}</div>`;
}
function tAddReplyAttachments(fileList) {
  const atts = tState.comms.reply.attachments;
  let error = '';
  Array.from(fileList).forEach(file => {
    if (file.size > T_MAX_ATTACHMENT_SIZE) { error = t('Some files were not added because they exceed the 10MB limit.'); return; }
    atts.push({ name: file.name, size: file.size });
  });
  tState.comms.reply.error = error;
  const el = document.getElementById('t-reply-attachments');
  if (el) el.innerHTML = tReplyAttachmentsBlock();
  if (error) { const body = document.getElementById('t-comms-content'); if (body) body.innerHTML = tCommsBody(); }
}
function tRemoveReplyAttachment(i) {
  tState.comms.reply.attachments.splice(i, 1);
  const el = document.getElementById('t-reply-attachments');
  if (el) el.innerHTML = tReplyAttachmentsBlock();
}
function tSendReply(convId) {
  const conv = tGetConversation(convId);
  if (!conv) return;
  const textEl = document.getElementById('t-reply-text');
  const text = (textEl ? textEl.value : '').trim();
  const attachments = tState.comms.reply.attachments;
  if (!text && !attachments.length) {
    tState.comms.reply.error = t('Write a message or attach a file before sending.');
    const el = document.getElementById('t-comms-content'); if (el) el.innerHTML = tCommsBody();
    return;
  }
  tState.comms.reply.error = '';
  tState.comms.reply.sending = true;
  const el0 = document.getElementById('t-comms-content'); if (el0) el0.innerHTML = tCommsBody();
  setTimeout(() => {
    conv.messages.push({ from:'me', text, date: tISODate(T_TODAY), time: t('Just now'), attachments: attachments.slice() });
    /* The one real, shared conversation also writes into the ONE shared
       messages table, so the guardian on the other side of this thread
       genuinely sees it — not just this local snapshot. */
    if (conv.shared && typeof authrenSendMessage === 'function') {
      const acct = TEACHER_DATA.account || {};
      authrenSendMessage(conv.id, text, { role: 'teacher', id: acct.timetableTeacherId || 'p-bensalem-karim' }, attachments.slice());
    }
    if (conv.status === 'awaiting') conv.status = 'open';
    tState.comms.reply = { text:'', attachments:[], error:'', sending:false };
    const el = document.getElementById('t-comms-content'); if (el) el.innerHTML = tCommsBody();
    tShowToast(t('Message sent.'));
  }, 600);
}

/* ── Compose (new conversation) ── */
function tOpenCompose() {
  tState.comms.screen = 'compose';
  tState.comms.compose = { open:true, recipientType:'guardian', studentSearch:'', studentId:null, staffId:null, text:'', attachments:[], error:'', sending:false };
  const el = document.getElementById('t-comms-content');
  if (el) el.innerHTML = tCommsBody();
}
function tGoToMessageGuardian(studentId) {
  tState.comms.screen = 'compose';
  tState.comms.compose = { open:true, recipientType:'guardian', studentSearch:'', studentId, staffId:null, text:'', attachments:[], error:'', sending:false };
  authrenGoTo('messages');
}
function tCancelCompose() {
  tState.comms.screen = 'list';
  const el = document.getElementById('t-comms-content');
  if (el) el.innerHTML = tCommsBody();
}
function tSetComposeRecipientType(type) {
  tState.comms.compose.recipientType = type;
  tState.comms.compose.studentId = null;
  tState.comms.compose.staffId = null;
  tState.comms.compose.error = '';
  const el = document.getElementById('t-comms-content');
  if (el) el.innerHTML = tCommsBody();
}
function tSetComposeStudentSearch(v) {
  tState.comms.compose.studentSearch = v;
  const el = document.getElementById('t-compose-student-results');
  if (el) el.innerHTML = tComposeStudentResultsBlock();
}
function tComposeStudentResultsBlock() {
  const q = tState.comms.compose.studentSearch.trim().toLowerCase();
  if (!q) return '';
  const results = TEACHER_DATA.students.filter(s => s.name.toLowerCase().includes(q) || s.studentId.toLowerCase().includes(q));
  if (!results.length) return `<div class="gd-empty-mini" style="text-align:left;padding:10px 0 0">${t('No students match your search.')}</div>`;
  return `<div style="margin-top:8px">${results.map(s => {
    const cls = tGetClass(s.classId);
    return `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="tSelectComposeStudent('${s.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();tSelectComposeStudent('${s.id}')}">
      <span>${gdCommsEsc(s.name)}<div style="font-size:11px;color:var(--muted)">${cls ? gdCommsEsc(cls.name) : ''}</div></span><span style="color:var(--muted);font-size:12px">${gdCommsEsc(s.studentId)}</span>
    </div>`;
  }).join('')}</div>`;
}
function tSelectComposeStudent(studentId) {
  tState.comms.compose.studentId = studentId;
  tState.comms.compose.studentSearch = '';
  tState.comms.compose.error = '';
  const el = document.getElementById('t-comms-content');
  if (el) el.innerHTML = tCommsBody();
}
function tSetComposeStaff(staffId) { tState.comms.compose.staffId = staffId; }
function tComposeAttachmentsBlock() {
  const atts = tState.comms.compose.attachments;
  if (!atts.length) return '';
  return `<div style="margin-top:8px">${atts.map((a, i) => `<span style="display:inline-flex;align-items:center;gap:6px;background:var(--surface2);border:1px solid var(--border);border-radius:8px;padding:4px 8px;font-size:11px;margin:0 6px 6px 0">${aIcon('paperclip')} ${gdCommsEsc(a.name)} <span style="cursor:pointer;color:var(--red)" onclick="tRemoveComposeAttachment(${i})">${aIcon('x')}</span></span>`).join('')}</div>`;
}
function tAddComposeAttachments(fileList) {
  const atts = tState.comms.compose.attachments;
  let error = '';
  Array.from(fileList).forEach(file => {
    if (file.size > T_MAX_ATTACHMENT_SIZE) { error = t('Some files were not added because they exceed the 10MB limit.'); return; }
    atts.push({ name: file.name, size: file.size });
  });
  tState.comms.compose.error = error;
  const el = document.getElementById('t-compose-attachments');
  if (el) el.innerHTML = tComposeAttachmentsBlock();
  if (error) { const body = document.getElementById('t-comms-content'); if (body) body.innerHTML = tCommsBody(); }
}
function tRemoveComposeAttachment(i) {
  tState.comms.compose.attachments.splice(i, 1);
  const el = document.getElementById('t-compose-attachments');
  if (el) el.innerHTML = tComposeAttachmentsBlock();
}
function tComposeScreen() {
  const c = tState.comms.compose;
  const selectedStudent = c.studentId ? tGetStudent(c.studentId) : null;
  return `<div class="card">
    <div class="card-header">
      <div style="display:flex;align-items:center;gap:10px;min-width:0;flex:1">
        <button type="button" class="st-btn ghost sm gd-comm-back-btn" onclick="tCancelCompose()">${t('← Back')}</button>
        <div class="card-title">${t('New Message')}</div>
      </div>
    </div>
    <div class="card-body">
      <div class="gd-comm-filter-row" style="margin-bottom:14px">
        <div class="gd-comm-filter-chip${c.recipientType==='guardian'?' active':''}" onclick="tSetComposeRecipientType('guardian')">${t('Guardian')}</div>
        <div class="gd-comm-filter-chip${c.recipientType==='school'?' active':''}" onclick="tSetComposeRecipientType('school')">${t('School Staff')}</div>
      </div>
      ${c.recipientType === 'guardian' ? `
        <div class="st-field"><label>${t('Student')}</label>
          ${selectedStudent
            ? `<div class="info-row"><span>${gdCommsEsc(selectedStudent.name)}<div style="font-size:11px;color:var(--muted)">${t('Guardian of')} ${gdCommsEsc(selectedStudent.name)}</div></span><span class="card-action" onclick="tSelectComposeStudent(null)">${t('Change')}</span></div>`
            : `<input class="gd-comm-search-input" type="text" placeholder="${t('Search students by name or ID...')}" value="${gdCommsEsc(c.studentSearch)}" oninput="tSetComposeStudentSearch(this.value)"><div id="t-compose-student-results">${tComposeStudentResultsBlock()}</div>`}
        </div>`
        : `<div class="st-field"><label>${t('Recipient')}</label><select onchange="tSetComposeStaff(this.value)">
            <option value="">${t('Select a staff member')}</option>
            ${T_SCHOOL_STAFF.map(s => `<option value="${s.id}" ${s.id===c.staffId?'selected':''}>${gdCommsEsc(s.name)} — ${gdCommsEsc(t(s.role))}</option>`).join('')}
          </select></div>`}
      <div class="st-field"><label>${t('Message')}</label><textarea id="t-compose-text" rows="4" placeholder="${t('Type your message...')}">${gdCommsEsc(c.text)}</textarea></div>
      <div class="st-field">
        <label>${t('Attachments')} (${t('optional')})</label>
        <div id="t-compose-attachments">${tComposeAttachmentsBlock()}</div>
        <input id="t-compose-file-input" type="file" multiple style="display:none" onchange="tAddComposeAttachments(this.files)">
        <button type="button" class="st-btn ghost sm" style="margin-top:6px" onclick="document.getElementById('t-compose-file-input').click()">${aIcon('paperclip')} ${t('Add Attachment')}</button>
      </div>
      <div style="display:flex;gap:10px">
        <button class="st-btn" onclick="tSendCompose()" ${c.sending ? 'disabled' : ''}>${c.sending ? `<span class="gd-spinner"></span>${t('Sending...')}` : t('Send')}</button>
        <button class="st-btn ghost" onclick="tCancelCompose()" ${c.sending ? 'disabled' : ''}>${t('Cancel')}</button>
      </div>
      ${c.error ? `<div class="st-inline-msg err show" style="margin-top:12px">${c.error}</div>` : ''}
    </div>
  </div>`;
}
function tSendCompose() {
  const c = tState.comms.compose;
  const text = (document.getElementById('t-compose-text').value || '').trim();
  c.text = text;

  let err = '';
  if (c.recipientType === 'guardian' && !c.studentId) err = t('Select a student to message their guardian.');
  else if (c.recipientType === 'school' && !c.staffId) err = t('Select a staff member.');
  else if (!text && !c.attachments.length) err = t('Write a message or attach a file before sending.');

  c.error = err;
  if (err) { const el = document.getElementById('t-comms-content'); if (el) el.innerHTML = tCommsBody(); return; }

  c.sending = true;
  const el0 = document.getElementById('t-comms-content'); if (el0) el0.innerHTML = tCommsBody();
  setTimeout(() => {
    let name, context, studentId = null;
    if (c.recipientType === 'guardian') {
      const student = tGetStudent(c.studentId);
      name = `${t('Guardian of')} ${student.name}`;
      context = student.name;
      studentId = student.id;
    } else {
      const staff = T_SCHOOL_STAFF.find(s => s.id === c.staffId);
      name = staff.name;
      context = staff.role;
    }
    const newConv = {
      id: Date.now(), type: c.recipientType, name, context, studentId, unread:false, status:'awaiting',
      messages: [{ from:'me', text: c.text, date: tISODate(T_TODAY), time: t('Just now'), attachments: c.attachments.slice() }],
    };
    TEACHER_DATA.conversations.unshift(newConv);
    tState.comms.screen = 'detail';
    tState.comms.convId = newConv.id;
    tState.comms.reply = { text:'', attachments:[], error:'', sending:false };
    const el = document.getElementById('t-comms-content'); if (el) el.innerHTML = tCommsBody();
    tShowToast(t('Message sent.'));
  }, 600);
}

/* ══════════════════════════════════════════════════════
   SUPPORT — Help Center (searchable FAQ) + Contact Support (ticket flow)
══════════════════════════════════════════════════════ */
function tSupportView() {
  const tabs = [ { id:'help', label:'Help Center' }, { id:'contact', label:'Contact Support' }, { id:'rating', label:'Rate Your Experience' } ];
  return `<div class="st-tabs">${tabs.map(tb => `<div class="st-tab gd-tab-tsup${tb.id===tState.support.tab?' active':''}" data-tab="${tb.id}" onclick="tSetSupportTab('${tb.id}')">${t(tb.label)}</div>`).join('')}</div>
    <div id="t-support-body">${tSupportBody()}</div>`;
}
function tSetSupportTab(tabId) {
  tState.support.tab = tabId;
  document.querySelectorAll('.gd-tab-tsup').forEach(el => el.classList.toggle('active', el.dataset.tab === tabId));
  const el = document.getElementById('t-support-body');
  if (el) el.innerHTML = tSupportBody();
}
function tSupportBody() {
  if (tState.support.tab === 'contact') return tContactSupportTab();
  if (tState.support.tab === 'rating') return tRatingTab();
  return tHelpCenterTab();
}

/* ── Help Center ── */
function tFaqCategories() {
  const seen = {};
  T_FAQS.forEach(f => { seen[f.category] = true; });
  return Object.keys(seen);
}
function tFilteredFaqs() {
  const s = tState.support;
  let list = T_FAQS.slice();
  if (s.helpCategory !== 'all') list = list.filter(f => f.category === s.helpCategory);
  const q = s.helpSearch.trim().toLowerCase();
  if (q) list = list.filter(f => f.question.toLowerCase().includes(q) || f.answer.toLowerCase().includes(q));
  return list;
}
function tHelpCenterTab() {
  const cats = tFaqCategories();
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Help Center')}</div></div>
    <div class="gd-comm-toolbar">
      <input class="gd-comm-search-input" type="text" placeholder="${t('Search help articles...')}" value="${gdCommsEsc(tState.support.helpSearch)}" oninput="tSetHelpSearch(this.value)">
      <div class="gd-comm-filter-row">
        <div class="gd-comm-filter-chip${tState.support.helpCategory==='all'?' active':''}" onclick="tSetHelpCategory('all')">${t('All')}</div>
        ${cats.map(c => `<div class="gd-comm-filter-chip${tState.support.helpCategory===c?' active':''}" onclick="tSetHelpCategory('${c}')">${t(c)}</div>`).join('')}
      </div>
    </div>
    <div class="card-body" id="t-help-results">${tHelpResultsBlock()}</div></div>`;
}
function tHelpResultsBlock() {
  const list = tFilteredFaqs();
  if (!list.length) return `<div class="gd-empty-state">
    <div class="gd-empty-state-title">${t('No help articles match your search')}</div>
    <div class="gd-empty-state-sub">${t("Try a different search term, or contact support directly.")}</div>
    <button class="st-btn ghost sm" onclick="tSetSupportTab('contact')">${t('Contact Support')} →</button>
  </div>`;
  return list.map(f => `<div style="border-bottom:0.5px solid var(--separator);padding:12px 0">
    <div style="cursor:pointer;display:flex;justify-content:space-between;align-items:center;gap:10px" role="button" tabindex="0" onclick="tToggleFaq('${f.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();tToggleFaq('${f.id}')}">
      <span style="font-size:13.5px;font-weight:600">${gdCommsEsc(f.question)}</span>
      <span style="color:var(--muted);font-size:12px;flex-shrink:0">${tState.support.expandedFaqId===f.id?'▲':'▼'}</span>
    </div>
    ${tState.support.expandedFaqId === f.id ? `<div style="font-size:13px;color:var(--muted2);line-height:1.6;margin-top:10px">${gdCommsEsc(f.answer)}</div>` : ''}
  </div>`).join('');
}
function tSetHelpSearch(v) { tState.support.helpSearch = v; const el = document.getElementById('t-help-results'); if (el) el.innerHTML = tHelpResultsBlock(); }
function tSetHelpCategory(v) {
  tState.support.helpCategory = v;
  const el = document.getElementById('t-support-body');
  if (el) el.innerHTML = tSupportBody();
}
function tToggleFaq(id) {
  tState.support.expandedFaqId = tState.support.expandedFaqId === id ? null : id;
  const el = document.getElementById('t-help-results');
  if (el) el.innerHTML = tHelpResultsBlock();
}

/* ── Contact Support (ticket flow) ── */
function tContactSupportTab() {
  const s = tState.support;
  if (s.screen === 'form') return tSupportFormCard();
  if (s.screen === 'success') return tSupportSuccessCard();
  const tickets = TEACHER_DATA.supportTickets;
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Your Support Requests')}</div><div class="card-action" onclick="tOpenSupportForm()">+ ${t('New Request')}</div></div>
    <div class="card-body">
      ${tickets.length ? tickets.map(tk => `<div class="info-row" style="align-items:flex-start">
        <span><span class="status-pill open">${gdCommsEsc(t(tk.category))}</span><div style="font-size:12.5px;color:var(--muted2);margin-top:6px;max-width:360px">${gdCommsEsc(tk.description)}</div></span>
        <span style="font-size:11px;color:var(--muted);flex-shrink:0">${tk.date}</span>
      </div>`).join('') : `<div class="gd-empty-state"><div class="gd-empty-state-title">${t('No support requests yet')}</div><div class="gd-empty-state-sub">${t('Submit a request and our team will get back to you.')}</div></div>`}
    </div></div>`;
}
function tOpenSupportForm() {
  tState.support.screen = 'form';
  tState.support.form = { category:T_SUPPORT_CATEGORIES[0], description:'' };
  tState.support.error = '';
  const el = document.getElementById('t-support-body');
  if (el) el.innerHTML = tSupportBody();
}
function tCancelSupportForm() {
  tState.support.screen = 'list';
  tState.support.form = null;
  tState.support.error = '';
  const el = document.getElementById('t-support-body');
  if (el) el.innerHTML = tSupportBody();
}
function tSupportFormCard() {
  const f = tState.support.form;
  const err = tState.support.error;
  return `<div class="card"><div class="card-header"><div class="card-title">${t('New Support Request')}</div></div>
    <div class="card-body">
      <div class="st-field"><label>${t('Category')}</label><select id="t-sup-category">${T_SUPPORT_CATEGORIES.map(c => `<option value="${c}" ${c===f.category?'selected':''}>${t(c)}</option>`).join('')}</select></div>
      <div class="st-field"><label>${t('Describe your issue or request')}</label><textarea id="t-sup-description" rows="4">${gdCommsEsc(f.description)}</textarea></div>
      <div style="display:flex;gap:10px">
        <button class="st-btn" onclick="tSubmitSupportForm()" ${tState.support.submitting ? 'disabled' : ''}>${tState.support.submitting ? `<span class="gd-spinner"></span>${t('Submitting...')}` : t('Submit Request')}</button>
        <button class="st-btn ghost" onclick="tCancelSupportForm()" ${tState.support.submitting ? 'disabled' : ''}>${t('Cancel')}</button>
      </div>
      ${err ? `<div class="st-inline-msg err show" style="margin-top:12px">${err}${tState.support.lastError ? `<div style="margin-top:8px"><button class="st-btn ghost sm" onclick="tSubmitSupportForm()">${t('Try Again')}</button></div>` : ''}</div>` : ''}
    </div></div>`;
}
function tSubmitSupportForm() {
  const f = tState.support.form;
  const category = document.getElementById('t-sup-category').value;
  const description = (document.getElementById('t-sup-description').value || '').trim();
  f.category = category;
  f.description = description;

  if (!description) {
    tState.support.error = t('Please describe your issue or request.');
    tState.support.lastError = '';
    const el = document.getElementById('t-support-body'); if (el) el.innerHTML = tSupportBody();
    return;
  }
  if (description.length < 10) {
    tState.support.error = t('Please provide a bit more detail (at least 10 characters).');
    tState.support.lastError = '';
    const el = document.getElementById('t-support-body'); if (el) el.innerHTML = tSupportBody();
    return;
  }

  tState.support.error = '';
  tState.support.submitting = true;
  const el0 = document.getElementById('t-support-body'); if (el0) el0.innerHTML = tSupportBody();
  setTimeout(() => {
    tState.support.submitting = false;
    if (Math.random() < 0.12) {
      tState.support.error = t("Something went wrong submitting your request. Please try again.");
      tState.support.lastError = tState.support.error;
      const el = document.getElementById('t-support-body'); if (el) el.innerHTML = tSupportBody();
      return;
    }
    TEACHER_DATA.supportTickets.unshift({ id:'sup' + Date.now(), category, description, date: tISODate(T_TODAY) });
    tState.support.screen = 'success';
    tState.support.form = null;
    tState.support.lastError = '';
    const el = document.getElementById('t-support-body'); if (el) el.innerHTML = tSupportBody();
  }, 700);
}
function tSupportSuccessCard() {
  return `<div class="gd-empty-state">
    <div class="gd-empty-state-ico" style="background:rgba(22,163,74,0.12);color:var(--green)"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M20 6L9 17l-5-5"/></svg></div>
    <div class="gd-empty-state-title">${t('Request submitted')}</div>
    <div class="gd-empty-state-sub">${t('Our team has received your request and will get back to you soon.')}</div>
    <button class="st-btn ghost sm" onclick="tBackToSupportList()">${t('View My Requests')}</button>
  </div>`;
}
function tBackToSupportList() {
  tState.support.screen = 'list';
  const el = document.getElementById('t-support-body');
  if (el) el.innerHTML = tSupportBody();
}

/* ── Anonymous School-Experience Rating ──
   The teacher's own anonymous feedback about the school/administration —
   never attributed to them. Not persisted anywhere identifying the
   submitter, matching the same privacy guarantee already established by
   Student's anonymous teacher-rating feature. */
function tRatingTab() {
  const s = tState.rating;
  if (s.screen === 'success') return tRatingSuccessCard();
  return `<div class="card"><div class="card-header"><div class="card-title">${aIcon('eye-off')} ${t('Rate Your Experience')}</div></div>
    <div class="card-body">
      <div style="font-size:12px;color:var(--muted);margin-bottom:16px">${t('This survey is completely anonymous — your identity is never shared with the Head of Institution or administration.')}</div>
      ${T_RATING_CATEGORIES.map((c, i) => `
        <div style="margin-bottom:18px">
          <div style="font-weight:600;font-size:13px;margin-bottom:6px">${t(c)}</div>
          <div style="display:flex;gap:6px;margin-bottom:8px">${[1,2,3,4,5].map(n => `<span onclick="tSetRating(${i},${n})" id="t-rate-star-${i}-${n}" style="cursor:pointer;font-size:20px;color:${(s.ratings[i]||0)>=n?'var(--yellow)':'var(--muted)'}">${aIcon('star')}</span>`).join('')}</div>
          <textarea id="t-rate-note-${i}" rows="2" placeholder="${t('Optional note for this category...')}" style="width:100%;background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--color-text);padding:8px;font-size:12.5px;font-family:inherit;resize:vertical">${gdCommsEsc(s.notes[i] || '')}</textarea>
        </div>`).join('')}
      ${s.error ? `<div class="st-inline-msg err show" style="margin-bottom:12px">${s.error}</div>` : ''}
      <button class="st-btn" onclick="tSubmitRating()">${t('Submit Anonymous Rating')}</button>
    </div></div>`;
}
function tSetRating(i, n) {
  tState.rating.ratings[i] = n;
  for (let k = 1; k <= 5; k++) {
    const el = document.getElementById(`t-rate-star-${i}-${k}`);
    if (el) el.style.color = k <= n ? 'var(--yellow)' : 'var(--muted)';
  }
}
function tSubmitRating() {
  const s = tState.rating;
  const missing = T_RATING_CATEGORIES.some((_, i) => !s.ratings[i]);
  if (missing) {
    s.error = t('Please rate every category before submitting.');
    const el = document.getElementById('t-support-body'); if (el) el.innerHTML = tSupportBody();
    return;
  }
  T_RATING_CATEGORIES.forEach((_, i) => {
    const el = document.getElementById(`t-rate-note-${i}`);
    s.notes[i] = el ? el.value.trim() : '';
  });
  const vals = T_RATING_CATEGORIES.map((_, i) => s.ratings[i]);
  const avg = vals.reduce((a, b) => a + b, 0) / vals.length;
  s.overall = Math.round(avg * 2) / 2; // half-star precision
  s.error = '';
  s.screen = 'success';
  const el = document.getElementById('t-support-body'); if (el) el.innerHTML = tSupportBody();
}
function tRatingSuccessCard() {
  const overall = tState.rating.overall || 0;
  return `<div class="card"><div class="card-body" style="text-align:center;padding:30px 20px">
    <div style="font-size:34px;margin-bottom:10px">${aIcon('check-circle')}</div>
    <div style="font-weight:700;font-size:16px;margin-bottom:6px">${t('Rating Submitted')}</div>
    <div style="font-size:13px;color:var(--muted);margin-bottom:14px">${t('Your anonymous feedback has been recorded. Your identity is never shared with the Head of Institution or administration.')}</div>
    <div style="font-size:28px;font-weight:800;color:var(--yellow)">${overall.toFixed(1)} / 5</div>
    <div style="font-size:11px;color:var(--muted);margin-top:4px">${t('Overall rating — calculated automatically from your category scores')}</div>
    <button class="st-btn ghost sm" style="margin-top:18px" onclick="tRateAgain()">${t('Submit Another Rating')}</button>
  </div></div>`;
}
function tRateAgain() {
  tState.rating = { screen:'form', ratings:{}, notes:{}, error:'' };
  const el = document.getElementById('t-support-body');
  if (el) el.innerHTML = tSupportBody();
}


function tAnalyticsOverviewTab() {
  const classes = TEACHER_DATA.classes;
  const allPerf = classes.map(c => tClassAvgPerformance(c.id)).filter(v => v !== null);
  const allAtt = classes.map(c => tClassAttendanceRate(c.id)).filter(v => v !== null);
  const totalExams = TEACHER_DATA.exams.length;
  const totalHw = TEACHER_DATA.homework.filter(h => h.status !== 'archived').length;
  return `
    <div class="gd-stat-row">
      <div class="stat-card"><div class="stat-label">${t('Overall Performance')}</div><div class="stat-val">${tAvg(allPerf)}/20</div><div class="stat-icon blue">${aIcon('bar-chart')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Overall Attendance')}</div><div class="stat-val">${tAvg(allAtt)}%</div><div class="stat-icon green">${aIcon('check-circle')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Exams Created')}</div><div class="stat-val">${totalExams}</div><div class="stat-icon purple">${aIcon('edit')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Active Homework')}</div><div class="stat-val">${totalHw}</div><div class="stat-icon yellow">${aIcon('book')}</div></div>
    </div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Class Comparison')}</div><span style="font-size:12px;color:var(--muted)">${t('Tap Classes for full details')}</span></div>
      <div class="card-body">
        ${classes.map(c => `<div class="info-row"><span>${gdCommsEsc(c.name)}<div style="font-size:11px;color:var(--muted)">${gdCommsEsc(t(c.subject))}</div></span><span style="text-align:right;font-size:12.5px;color:var(--muted)">${tClassAvgPerformance(c.id)}/20 · ${tClassAttendanceRate(c.id)}%</span></div>`).join('') || `<div class="gd-empty-mini">${t('No classes assigned yet.')}</div>`}
      </div></div>`;
}

function tExamFormScreen() {
  const f = tState.exams.form;
  const err = tState.exams.error;
  return `<div class="card"><div class="card-header"><div class="card-title">${f.mode==='edit'?t('Edit Exam'):t('New Exam')}</div></div>
    <div class="card-body">
      <div class="st-field"><label>${t('Exam Name')}</label><input id="t-exam-name" value="${gdCommsEsc(f.name)}"></div>
      <div class="st-field"><label>${t('Class')}</label><select id="t-exam-class">${TEACHER_DATA.classes.map(c => `<option value="${c.id}" ${c.id===f.classId?'selected':''}>${gdCommsEsc(c.name)} — ${gdCommsEsc(t(c.subject))}</option>`).join('')}</select></div>
      <div style="display:flex;gap:10px">
        <div class="st-field" style="flex:1"><label>${t('Date')}</label><input id="t-exam-date" type="date" value="${f.date}"></div>
        <div class="st-field" style="flex:1"><label>${t('Time')}</label><input id="t-exam-time" type="time" value="${f.time}"></div>
      </div>
      <div style="display:flex;gap:10px">
        <div class="st-field" style="flex:1"><label>${t('Duration (minutes)')}</label><input id="t-exam-duration" type="number" min="1" value="${f.duration}"></div>
        <div class="st-field" style="flex:1"><label>${t('Maximum Score')}</label><input id="t-exam-maxscore" type="number" min="1" value="${f.maxScore}"></div>
      </div>
      <div class="st-field"><label>${t('Instructions / Details')}</label><textarea id="t-exam-instructions" rows="3">${gdCommsEsc(f.instructions)}</textarea></div>
      <div style="display:flex;gap:10px">
        <button class="st-btn" onclick="tSaveExamForm()" ${tState.exams.saving?'disabled':''}>${tState.exams.saving ? `<span class="gd-spinner"></span>${t('Saving...')}` : (f.mode==='edit'?t('Save Changes'):t('Create Exam'))}</button>
        <button class="st-btn ghost" onclick="tCancelExamForm()" ${tState.exams.saving?'disabled':''}>${t('Cancel')}</button>
      </div>
      ${err ? `<div class="st-inline-msg err show" style="margin-top:12px">${err}</div>` : ''}
    </div></div>`;
}

/* ══════════════════════════════════════════════════════
   PROFILE & SECURITY
   Security (password, recovery, email verification) lands in a later
   batch per the module's build order; this page currently presents the
   complete Profile experience only, with no tab bar implying a Security
   section that doesn't exist yet.
══════════════════════════════════════════════════════ */
function tAccount() {
  const tabs = [ { id:'profile', label:'Profile' }, { id:'security', label:'Account & Security' } ];
  return `<div class="st-tabs">${tabs.map(tb => `<div class="st-tab gd-tab-tacc${tb.id===tState.tab.account?' active':''}" data-tab="${tb.id}" onclick="tSetAccountTab('${tb.id}')">${t(tb.label)}</div>`).join('')}</div>
    <div id="t-account-body">${tAccountBody(tState.tab.account)}</div>`;
}
function tSetAccountTab(tabId) {
  tState.tab.account = tabId;
  document.querySelectorAll('.gd-tab-tacc').forEach(el => el.classList.toggle('active', el.dataset.tab === tabId));
  const el = document.getElementById('t-account-body');
  if (el) el.innerHTML = tAccountBody(tabId);
}
function tAccountBody(tab) {
  if (tab === 'security') return tAccountSecurityTab();
  return tAccountProfileTab();
}
function tAccountProfileTab() {
  const a = TEACHER_DATA.account;
  const s = tState.profile;

  if (s.editing) return tProfileEditForm();

  return `
    <div class="card"><div class="card-body" style="display:flex;gap:18px;align-items:center;flex-wrap:wrap">
      <div style="width:64px;height:64px;border-radius:18px;background:linear-gradient(180deg,rgba(30,64,175,0.85),rgba(23,37,84,0.85));color:#fff;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:20px">${gdInitials(a.name)}</div>
      <div style="flex:1;min-width:0">
        <div style="font-size:17px;font-weight:800">${gdCommsEsc(a.name)}</div>
        <div style="font-size:12.5px;color:var(--muted);margin-top:2px">${t('Teacher')} · ${a.subjects.map(x => gdCommsEsc(t(x))).join(', ')} · ${gdCommsEsc(a.institution)}</div>
      </div>
      <button type="button" class="st-btn ghost sm" onclick="tEditProfile()">${t('Edit Profile')}</button>
    </div></div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Teacher Information')}</div></div>
      <div class="card-body">
        <div class="info-row"><span>${t('Full Name')}</span><span>${gdCommsEsc(a.name)}</span></div>
        <div class="info-row">
          <span>${t('Authren Teacher ID')}</span>
          <span style="display:flex;align-items:center;gap:8px">
            <span>${a.teacherId}</span>
            <button type="button" class="st-btn ghost sm" id="t-copy-btn" onclick="tCopyTeacherId()">${t('Copy')}</button>
          </span>
        </div>
        <div class="info-row"><span>${t('Email')}</span><span>${gdCommsEsc(a.email)}</span></div>
        <div class="info-row"><span>${t('Phone')}</span><span>${gdCommsEsc(a.phone)}</span></div>
        <div class="info-row"><span>${t('Subject(s)')}</span><span>${a.subjects.map(x => gdCommsEsc(t(x))).join(', ')}</span></div>
        <div class="info-row"><span>${t('Institution')}</span><span>${gdCommsEsc(a.institution)}</span></div>
        <div class="info-row"><span>${t('Years of Experience')}</span><span>${a.yearsExperience}</span></div>
      </div></div>

    <div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('Classes Taught')}</div></div>
      <div class="card-body">
        ${TEACHER_DATA.classes.map(c => `<div class="info-row"><span>${gdCommsEsc(c.name)}</span><span style="color:var(--muted)">${gdCommsEsc(t(c.subject))} · ${tClassStudentCount(c.id)} ${t(tClassStudentCount(c.id) === 1 ? 'student' : 'students')}</span></div>`).join('') || `<div class="gd-empty-mini">${t('No classes assigned yet.')}</div>`}
      </div></div>

    ${a.bio ? `<div class="card" style="margin-top:16px"><div class="card-header"><div class="card-title">${t('About')}</div></div>
      <div class="card-body"><div style="font-size:13px;color:var(--muted2);line-height:1.6">${gdCommsEsc(a.bio)}</div></div></div>` : ''}`;
}

/* ── Account & Security tab ── */
function tAccountSecurityTab() {
  return `
    <div class="st-grid-2">
      <div class="card"><div class="card-header"><div class="card-title">${aIcon('smartphone')} ${t('Phone Number')}</div></div>
        <div class="card-body">
          <div style="font-size:11.5px;color:var(--muted);margin-bottom:10px">${t('Make sure this number is current — the school uses it to reach you.')}</div>
          <div class="info-row" id="t-phone-row">${tPhoneViewRow()}</div>
        </div></div>
      <div class="card"><div class="card-header"><div class="card-title">${aIcon('mail')} ${t('Email Management')}</div></div>
        <div class="card-body" id="t-email-card-body">${tEmailCardBody()}</div></div>
    </div>
    <div class="st-grid-2" style="margin-top:16px">
      <div class="card"><div class="card-header"><div class="card-title">${aIcon('key')} ${t('Password Management')}</div></div>
        <div class="card-body">
          <div class="st-field"><label>${t('Current Password')}</label>
            <div class="pass-input-wrap"><input type="password" id="t-pw-cur" style="padding-right:40px">
              <button type="button" class="toggle-pass-btn" onclick="togglePasswordVisibility('t-pw-cur', this)" aria-label="Toggle password visibility">${EYE_CLOSED_SVG}</button>
            </div></div>
          <div class="st-field"><label>${t('New Password')}</label>
            <div class="pass-input-wrap"><input type="password" id="t-pw-new" oninput="tCheckPwStrength()" style="padding-right:40px">
              <button type="button" class="toggle-pass-btn" onclick="togglePasswordVisibility('t-pw-new', this)" aria-label="Toggle password visibility">${EYE_CLOSED_SVG}</button>
            </div></div>
          <div id="t-pw-hint" style="font-size:11px;color:var(--muted);margin:-6px 0 12px">${t('Minimum 6 characters, with at least 1 letter and 1 number.')}</div>
          <div class="st-field"><label>${t('Confirm New Password')}</label>
            <div class="pass-input-wrap"><input type="password" id="t-pw-confirm" style="padding-right:40px">
              <button type="button" class="toggle-pass-btn" onclick="togglePasswordVisibility('t-pw-confirm', this)" aria-label="Toggle password visibility">${EYE_CLOSED_SVG}</button>
            </div></div>
          <button class="st-btn" id="t-pw-submit" onclick="tChangePassword()">${t('Update Password')}</button>
          <div class="st-inline-msg ok" id="t-pw-msg-ok">${t('Password updated successfully.')}</div>
          <div class="st-inline-msg err" id="t-pw-msg-err"></div>
        </div></div>
      <div class="card"><div class="card-header"><div class="card-title">${aIcon('life-buoy')} ${t('Password Recovery')}</div></div>
        <div class="card-body">
          <div style="font-size:12.5px;color:var(--muted);margin-bottom:12px">${t('Forgot your password? Start the guided recovery process to reset it securely.')}</div>
          <button class="st-btn ghost" onclick="tOpenPasswordRecovery()">${t('Start Password Recovery')}</button>
        </div></div>
    </div>`;
}

/* ── Phone Number: view / edit / save / cancel ── */
function tPhoneViewRow() {
  const a = TEACHER_DATA.account;
  const s = tState.phone;
  if (!s.editing) {
    return `<span>${t('Phone Number')}</span>
      <span style="display:flex;align-items:center;gap:8px">
        ${s.success ? `<span style="color:var(--green);font-size:11px">${aIcon('check')} ${t('Updated')}</span>` : ''}
        <span>${gdCommsEsc(a.phone)}</span>
        <button type="button" class="st-btn ghost sm" onclick="tEditPhone()">${t('Edit')}</button>
      </span>`;
  }
  return `<div class="gd-edit-row">
      <input id="t-phone-input" type="tel" inputmode="tel" value="${gdCommsEsc(s.draft)}" placeholder="${t('e.g. +212 6XX-XXXXXX')}" ${s.saving?'disabled':''}>
      <button type="button" class="st-btn sm" onclick="tSavePhone()" ${s.saving?'disabled':''}>${s.saving?`<span class="gd-spinner"></span>${t('Saving...')}`:t('Save')}</button>
      <button type="button" class="st-btn ghost sm" onclick="tCancelPhoneEdit()" ${s.saving?'disabled':''}>${t('Cancel')}</button>
    </div>
    ${s.error?`<div class="st-inline-msg err show" style="margin-top:8px;width:100%">${s.error}</div>`:''}`;
}
function tRefreshPhoneRow() {
  const el = document.getElementById('t-phone-row');
  if (el) el.innerHTML = tPhoneViewRow();
}
function tEditPhone() {
  tState.phone = { editing:true, saving:false, error:'', success:false, draft: TEACHER_DATA.account.phone };
  tRefreshPhoneRow();
}
function tCancelPhoneEdit() {
  tState.phone = { editing:false, saving:false, error:'', success:false, draft:'' };
  tRefreshPhoneRow();
}
function tSavePhone() {
  const input = document.getElementById('t-phone-input');
  const val = input ? input.value.trim() : '';
  const s = tState.phone;
  s.error = '';
  const phoneRegex = /^[+]?[\d][\d\s().-]{6,18}\d$/;
  if (!val) { s.error = t('Please enter a phone number.'); s.draft = val; tRefreshPhoneRow(); return; }
  if (!phoneRegex.test(val)) { s.error = t('Enter a valid phone number.'); s.draft = val; tRefreshPhoneRow(); return; }
  s.draft = val;
  s.saving = true;
  tRefreshPhoneRow();
  setTimeout(() => {
    TEACHER_DATA.account.phone = val;
    s.saving = false;
    s.editing = false;
    s.success = true;
    tRefreshPhoneRow();
    setTimeout(() => { s.success = false; }, 3000);
  }, 800);
}

/* ── Password change ── */
function tCheckPwStrength() {
  const v = document.getElementById('t-pw-new').value;
  const hint = document.getElementById('t-pw-hint');
  if (!hint) return;
  const ok = v.length >= 6 && /[a-zA-Z]/.test(v) && /[0-9]/.test(v);
  hint.style.color = v.length === 0 ? 'var(--muted)' : ok ? 'var(--green)' : 'var(--red)';
}
function tPasswordMessage(type, msg) {
  const okBox = document.getElementById('t-pw-msg-ok');
  const errBox = document.getElementById('t-pw-msg-err');
  if (!okBox || !errBox) return;
  okBox.classList.remove('show'); errBox.classList.remove('show');
  if (type === 'ok') okBox.classList.add('show');
  else if (type === 'err') { errBox.textContent = msg; errBox.classList.add('show'); }
}
function tSetPasswordSaving(v) {
  tState.password.saving = v;
  const btn = document.getElementById('t-pw-submit');
  if (btn) { btn.disabled = v; btn.innerHTML = v ? `<span class="gd-spinner"></span>${t('Updating...')}` : t('Update Password'); }
  ['t-pw-cur', 't-pw-new', 't-pw-confirm'].forEach(id => { const el = document.getElementById(id); if (el) el.disabled = v; });
}
function tChangePassword() {
  const cur = document.getElementById('t-pw-cur').value;
  const nw = document.getElementById('t-pw-new').value;
  const cf = document.getElementById('t-pw-confirm').value;
  if (!cur) return tPasswordMessage('err', t('Please enter your current password.'));
  if (cur !== TEACHER_DATA.account.password) return tPasswordMessage('err', t('Current password is incorrect.'));
  if (!nw || !cf) return tPasswordMessage('err', t('Please fill in both new password fields.'));
  const errs = validatePassword(nw);
  if (errs.length) return tPasswordMessage('err', errs.join(' '));
  if (nw === cur) return tPasswordMessage('err', t('New password must be different from your current password.'));
  if (nw !== cf) return tPasswordMessage('err', t('Passwords do not match.'));

  tPasswordMessage('', '');
  tSetPasswordSaving(true);
  setTimeout(() => {
    TEACHER_DATA.account.password = nw;
    tSetPasswordSaving(false);
    document.getElementById('t-pw-cur').value = '';
    document.getElementById('t-pw-new').value = '';
    document.getElementById('t-pw-confirm').value = '';
    const hint = document.getElementById('t-pw-hint'); if (hint) hint.style.color = 'var(--muted)';
    tPasswordMessage('ok', '');
  }, 900);
}

/* ── Email change verification ── */
function tEmailCardBody() {
  const a = TEACHER_DATA.account;
  const e = tState.email;
  let html = `<div class="info-row"><span>${t('Current Email')}</span><span id="t-email-current">${gdCommsEsc(a.email)}</span></div>`;

  if (e.step === 'idle') {
    html += `
      <div class="st-field" style="margin-top:12px"><label>${t('New Email')}</label>
        <input type="email" id="t-email-new" placeholder="${t('name@example.com')}">
      </div>
      <button class="st-btn ghost" onclick="tRequestEmailChange()" ${e.sending?'disabled':''}>${e.sending?`<span class="gd-spinner"></span>${t('Sending code...')}`:t('Send Verification Code')}</button>`;
  } else if (e.step === 'otp') {
    const remaining = Math.max(0, Math.ceil((e.expiry - Date.now()) / 1000));
    html += `
      <div class="st-inline-msg ok show" style="margin-top:12px">${t('Verification code sent to')} ${gdCommsEsc(e.newEmail)}.</div>
      <div class="st-field" style="margin-top:8px"><label>${t('Verification Code')}</label>
        <input id="t-email-otp" placeholder="000000" maxlength="6" inputmode="numeric" ${e.verifying?'disabled':''}></div>
      <div id="t-email-otp-timer" style="font-size:11px;color:var(--muted);margin:-6px 0 12px">${remaining>0 ? t('Code expires in')+' '+remaining+'s' : t('Code expired. Please resend.')}</div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <button class="st-btn" onclick="tVerifyEmailOtp()" ${e.verifying?'disabled':''}>${e.verifying?`<span class="gd-spinner"></span>${t('Verifying...')}`:t('Verify & Update Email')}</button>
        <button class="st-btn ghost" id="t-email-resend" onclick="tResendEmailOtp()" ${e.cooldown>0?'disabled':''}>${e.cooldown>0? t('Resend in')+' '+e.cooldown+'s' : t('Resend Code')}</button>
        <button class="st-btn ghost" onclick="tCancelEmailChange()">${t('Cancel')}</button>
      </div>`;
  } else if (e.step === 'done') {
    html += `<div class="st-inline-msg ok show" style="margin-top:12px">${t('Email address updated successfully.')}</div>
      <button class="st-btn ghost sm" style="margin-top:8px" onclick="tCancelEmailChange()">${t('Change Email Again')}</button>`;
  }

  html += `<div class="st-inline-msg err${e.error?' show':''}" style="margin-top:10px">${e.error||''}</div>`;
  return html;
}
function tRenderEmailCard() {
  const el = document.getElementById('t-email-card-body');
  if (el) el.innerHTML = tEmailCardBody();
  if (tState.email.step === 'otp') tStartEmailOtpTimer();
}
function tStartEmailOtpTimer() {
  clearInterval(tState.email._interval);
  tState.email._interval = setInterval(() => {
    const e = tState.email;
    const timerEl = document.getElementById('t-email-otp-timer');
    const remaining = Math.max(0, Math.ceil((e.expiry - Date.now()) / 1000));
    if (timerEl) timerEl.textContent = remaining > 0 ? (t('Code expires in') + ' ' + remaining + 's') : t('Code expired. Please resend.');
    if (e.cooldown > 0) {
      e.cooldown -= 1;
      const btn = document.getElementById('t-email-resend');
      if (btn) {
        if (e.cooldown > 0) { btn.disabled = true; btn.textContent = t('Resend in') + ' ' + e.cooldown + 's'; }
        else { btn.disabled = false; btn.textContent = t('Resend Code'); }
      }
    }
    if (remaining <= 0 && e.cooldown <= 0) clearInterval(e._interval);
  }, 1000);
}
function tRequestEmailChange() {
  const input = document.getElementById('t-email-new');
  const val = input ? input.value.trim() : '';
  const e = tState.email;
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  e.error = '';
  if (!val) { e.error = t('Please enter a new email address.'); tRenderEmailCard(); return; }
  if (!emailRegex.test(val)) { e.error = t('Enter a valid email address.'); tRenderEmailCard(); return; }
  if (val.toLowerCase() === TEACHER_DATA.account.email.toLowerCase()) { e.error = t('This is already your current email address.'); tRenderEmailCard(); return; }

  e.sending = true;
  tRenderEmailCard();
  setTimeout(() => {
    e.sending = false;
    e.newEmail = val;
    e.step = 'otp';
    e.attempts = 0;
    e.expiry = Date.now() + 60000;
    e.cooldown = 30;
    tRenderEmailCard();
  }, 900);
}
function tVerifyEmailOtp() {
  const input = document.getElementById('t-email-otp');
  const code = input ? input.value.trim() : '';
  const e = tState.email;
  e.error = '';
  if (Date.now() > e.expiry) { e.error = t('This code has expired. Please resend a new code.'); tRenderEmailCard(); return; }
  if (!/^\d{6}$/.test(code)) { e.error = t('Enter the 6-digit code we sent to your email.'); tRenderEmailCard(); return; }
  if (code !== '123456') {
    e.attempts += 1;
    e.error = t('Incorrect verification code.') + (e.attempts >= 3 ? ' ' + t('Please request a new code if the problem continues.') : '');
    tRenderEmailCard();
    return;
  }
  e.verifying = true;
  tRenderEmailCard();
  setTimeout(() => {
    clearInterval(e._interval);
    TEACHER_DATA.account.email = e.newEmail;
    e.verifying = false;
    e.step = 'done';
    tRenderEmailCard();
  }, 700);
}
function tResendEmailOtp() {
  const e = tState.email;
  if (e.cooldown > 0) return;
  e.expiry = Date.now() + 60000;
  e.cooldown = 30;
  e.attempts = 0;
  e.error = '';
  tRenderEmailCard();
}
function tCancelEmailChange() {
  clearInterval(tState.email._interval);
  tState.email = { step:'idle', newEmail:'', deliveredTo:'', sending:false, verifying:false, attempts:0, error:'', cooldown:0, expiry:0, _interval:null };
  tRenderEmailCard();
}

/* ── Password recovery (modal flow) ── */
function tOpenPasswordRecovery() {
  tState.recovery = { step:1, identifier:'', deliveredTo:'', sending:false, verifying:false, attempts:0, error:'', cooldown:0, expiry:0, resetting:false, _interval:null };
  stOpenModal(tRecoveryModalHTML());
}
function tRecoveryModalHTML() {
  const r = tState.recovery;
  if (r.step === 1) return `
    <div class="st-modal-title">${t('Password Recovery')}</div>
    <div class="st-modal-sub">${t('Enter your Authren Teacher ID or the email linked to your account to receive a reset code.')}</div>
    <div class="st-field"><input id="t-rec-id" placeholder="${t('Teacher ID (T1234567) or email')}" ${r.sending?'disabled':''}></div>
    <div class="st-inline-msg err${r.error?' show':''}">${r.error||''}</div>
    <button class="st-btn" onclick="tRecoverySendCode()" ${r.sending?'disabled':''}>${r.sending?`<span class="gd-spinner"></span>${t('Sending code...')}`:t('Send Reset Code')}</button>`;

  if (r.step === 2) {
    const remaining = Math.max(0, Math.ceil((r.expiry - Date.now()) / 1000));
    return `
    <div class="st-modal-title">${t('Enter Verification Code')}</div>
    <div class="st-modal-sub">${t('Enter the code we sent to')} ${gdCommsEsc(r.deliveredTo)}.</div>
    <div class="st-field"><input id="t-rec-otp" placeholder="000000" maxlength="6" inputmode="numeric" ${r.verifying?'disabled':''}></div>
    <div id="t-rec-timer" style="font-size:11px;color:var(--muted);margin:-6px 0 12px">${remaining>0? t('Code expires in')+' '+remaining+'s' : t('Code expired. Please resend.')}</div>
    <div class="st-inline-msg err${r.error?' show':''}">${r.error||''}</div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px">
      <button class="st-btn" onclick="tRecoveryVerifyOtp()" ${r.verifying?'disabled':''}>${r.verifying?`<span class="gd-spinner"></span>${t('Verifying...')}`:t('Verify Code')}</button>
      <button class="st-btn ghost" id="t-rec-resend" onclick="tRecoveryResend()" ${r.cooldown>0?'disabled':''}>${r.cooldown>0? t('Resend in')+' '+r.cooldown+'s' : t('Resend Code')}</button>
      <button class="st-btn ghost" onclick="tRecoveryBack(1)">${t('← Back')}</button>
    </div>`;
  }

  if (r.step === 3) return `
    <div class="st-modal-title">${t('Choose a New Password')}</div>
    <div class="st-modal-sub">${t('Your new password must be at least 6 characters, with a letter and a number.')}</div>
    <div class="st-field"><label>${t('New Password')}</label>
      <div class="pass-input-wrap"><input type="password" id="t-rec-newpw" style="padding-right:40px" ${r.resetting?'disabled':''}>
        <button type="button" class="toggle-pass-btn" onclick="togglePasswordVisibility('t-rec-newpw', this)" aria-label="Toggle password visibility">${EYE_CLOSED_SVG}</button>
      </div></div>
    <div class="st-field"><label>${t('Confirm New Password')}</label>
      <div class="pass-input-wrap"><input type="password" id="t-rec-confirmpw" style="padding-right:40px" ${r.resetting?'disabled':''}>
        <button type="button" class="toggle-pass-btn" onclick="togglePasswordVisibility('t-rec-confirmpw', this)" aria-label="Toggle password visibility">${EYE_CLOSED_SVG}</button>
      </div></div>
    <div class="st-inline-msg err${r.error?' show':''}">${r.error||''}</div>
    <button class="st-btn" onclick="tRecoveryResetPassword()" ${r.resetting?'disabled':''}>${r.resetting?`<span class="gd-spinner"></span>${t('Resetting...')}`:t('Reset Password')}</button>
    <div style="margin-top:10px"><button class="st-btn ghost sm" onclick="tRecoveryBack(2)" ${r.resetting?'disabled':''}>${t('← Back')}</button></div>`;

  return `
    <div style="text-align:center">
      <div style="font-size:36px;margin-bottom:10px">${aIcon('check-circle')}</div>
      <div style="font-weight:700;margin-bottom:6px">${t('Password Reset Successfully')}</div>
      <div style="font-size:12.5px;color:var(--muted)">${t('For your security, you will be signed out and can log in with your new password.')}</div>
      <button class="st-btn" style="margin-top:16px" onclick="tRecoveryFinish()">${t('Return to Login')}</button>
    </div>`;
}
function tRecoveryRerender() {
  const overlay = document.getElementById('st-modal-overlay');
  if (!overlay || !overlay.classList.contains('active')) return;
  const box = overlay.querySelector('.st-modal-box');
  if (box) box.innerHTML = `<div class="st-modal-close" onclick="stCloseModal()">${aIcon('x')}</div>${tRecoveryModalHTML()}`;
  if (tState.recovery.step === 2) tRecoveryStartTimer();
}
function tRecoveryStartTimer() {
  clearInterval(tState.recovery._interval);
  tState.recovery._interval = setInterval(() => {
    const r = tState.recovery;
    const timerEl = document.getElementById('t-rec-timer');
    const remaining = Math.max(0, Math.ceil((r.expiry - Date.now()) / 1000));
    if (timerEl) timerEl.textContent = remaining > 0 ? (t('Code expires in') + ' ' + remaining + 's') : t('Code expired. Please resend.');
    if (r.cooldown > 0) {
      r.cooldown -= 1;
      const btn = document.getElementById('t-rec-resend');
      if (btn) {
        if (r.cooldown > 0) { btn.disabled = true; btn.textContent = t('Resend in') + ' ' + r.cooldown + 's'; }
        else { btn.disabled = false; btn.textContent = t('Resend Code'); }
      }
    }
    if (remaining <= 0 && r.cooldown <= 0) clearInterval(r._interval);
  }, 1000);
}
function tRecoverySendCode() {
  const input = document.getElementById('t-rec-id');
  const val = input ? input.value.trim() : '';
  const r = tState.recovery;
  const a = TEACHER_DATA.account;
  const isEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val);
  const isTeacherId = /^T\d{7}$/.test(val);
  r.error = '';
  if (!val) { r.error = t('Please enter your Teacher ID or email.'); tRecoveryRerender(); return; }
  if (!isEmail && !isTeacherId) { r.error = t('Enter a valid email address or Teacher ID (format: T1234567).'); tRecoveryRerender(); return; }
  if (isEmail && val.toLowerCase() !== a.email.toLowerCase()) { r.error = t('We could not find an account matching that email.'); tRecoveryRerender(); return; }
  if (isTeacherId && val.toUpperCase() !== a.teacherId) { r.error = t('We could not find an account matching that Teacher ID.'); tRecoveryRerender(); return; }

  r.identifier = val;
  r.sending = true;
  tRecoveryRerender();
  setTimeout(() => {
    r.sending = false;
    r.step = 2;
    r.deliveredTo = a.email;
    r.attempts = 0;
    r.expiry = Date.now() + 60000;
    r.cooldown = 30;
    tRecoveryRerender();
  }, 900);
}
function tRecoveryVerifyOtp() {
  const input = document.getElementById('t-rec-otp');
  const code = input ? input.value.trim() : '';
  const r = tState.recovery;
  r.error = '';
  if (Date.now() > r.expiry) { r.error = t('This code has expired. Please resend a new code.'); tRecoveryRerender(); return; }
  if (!/^\d{6}$/.test(code)) { r.error = t('Enter the 6-digit code sent to your email.'); tRecoveryRerender(); return; }
  if (code !== '123456') {
    r.attempts += 1;
    r.error = t('Incorrect code. Please try again.');
    tRecoveryRerender();
    return;
  }
  r.verifying = true;
  tRecoveryRerender();
  setTimeout(() => {
    clearInterval(r._interval);
    r.verifying = false;
    r.step = 3;
    tRecoveryRerender();
  }, 700);
}
function tRecoveryResend() {
  const r = tState.recovery;
  if (r.cooldown > 0) return;
  r.expiry = Date.now() + 60000;
  r.cooldown = 30;
  r.attempts = 0;
  r.error = '';
  tRecoveryRerender();
}
function tRecoveryBack(step) {
  clearInterval(tState.recovery._interval);
  tState.recovery.step = step;
  tState.recovery.error = '';
  tRecoveryRerender();
}
function tRecoveryResetPassword() {
  const a = document.getElementById('t-rec-newpw').value;
  const b = document.getElementById('t-rec-confirmpw').value;
  const r = tState.recovery;
  r.error = '';
  if (!a || !b) { r.error = t('Please fill in both password fields.'); tRecoveryRerender(); return; }
  const errs = validatePassword(a);
  if (errs.length) { r.error = errs.join(' '); tRecoveryRerender(); return; }
  if (a !== b) { r.error = t('Passwords do not match.'); tRecoveryRerender(); return; }

  r.resetting = true;
  tRecoveryRerender();
  setTimeout(() => {
    TEACHER_DATA.account.password = a;
    r.resetting = false;
    r.step = 4;
    tRecoveryRerender();
  }, 900);
}
function tRecoveryFinish() {
  clearInterval(tState.recovery._interval);
  stCloseModal();
  setTimeout(() => { goLogin('teacher'); }, 200);
}

function tEditProfile() {
  const a = TEACHER_DATA.account;
  tState.profile = {
    editing: true, saving: false, error: '', success: false,
    draft: { name: a.name, email: a.email, phone: a.phone, subjects: a.subjects.join(', '), bio: a.bio || '' },
  };
  tRefreshAccountBody();
}
function tCancelEditProfile() {
  tState.profile = { editing: false, saving: false, error: '', success: false, draft: null };
  tRefreshAccountBody();
}
function tRefreshAccountBody() {
  const el = document.getElementById('t-account-body');
  if (el) el.innerHTML = tAccountBody(tState.tab.account);
}
function tProfileEditForm() {
  const s = tState.profile;
  const d = s.draft;
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Edit Profile')}</div></div>
    <div class="card-body">
      <div class="st-field"><label>${t('Full Name')}</label><input id="t-edit-name" value="${gdCommsEsc(d.name)}" ${s.saving ? 'disabled' : ''}></div>
      <div class="st-field"><label>${t('Email')}</label><input id="t-edit-email" type="email" value="${gdCommsEsc(d.email)}" ${s.saving ? 'disabled' : ''}></div>
      <div class="st-field"><label>${t('Phone')}</label><input id="t-edit-phone" type="tel" value="${gdCommsEsc(d.phone)}" ${s.saving ? 'disabled' : ''}></div>
      <div class="st-field"><label>${t('Subject(s)')}</label><input id="t-edit-subjects" value="${gdCommsEsc(d.subjects)}" placeholder="${t('e.g. Mathematics, Physics')}" ${s.saving ? 'disabled' : ''}></div>
      <div class="st-field"><label>${t('About')}</label><textarea id="t-edit-bio" rows="3" ${s.saving ? 'disabled' : ''}>${gdCommsEsc(d.bio)}</textarea></div>
      <div style="display:flex;gap:10px">
        <button class="st-btn" id="t-profile-save" onclick="tSaveProfile()" ${s.saving ? 'disabled' : ''}>${s.saving ? `<span class="gd-spinner"></span>${t('Saving...')}` : t('Save Changes')}</button>
        <button class="st-btn ghost" onclick="tCancelEditProfile()" ${s.saving ? 'disabled' : ''}>${t('Cancel')}</button>
      </div>
      ${s.error ? `<div class="st-inline-msg err show" style="margin-top:12px">${s.error}</div>` : ''}
    </div></div>`;
}
function tSaveProfile() {
  const s = tState.profile;
  const name = (document.getElementById('t-edit-name').value || '').trim();
  const email = (document.getElementById('t-edit-email').value || '').trim();
  const phone = (document.getElementById('t-edit-phone').value || '').trim();
  const subjectsRaw = (document.getElementById('t-edit-subjects').value || '').trim();
  const bio = (document.getElementById('t-edit-bio').value || '').trim();
  s.draft = { name, email, phone, subjects: subjectsRaw, bio };

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const phoneRegex = /^[+]?[\d][\d\s().-]{6,18}\d$/;

  s.error = '';
  if (!name) s.error = t('Full name is required.');
  else if (!email || !emailRegex.test(email)) s.error = t('Enter a valid email address.');
  else if (!phone || !phoneRegex.test(phone)) s.error = t('Enter a valid phone number.');
  else if (!subjectsRaw) s.error = t('Enter at least one subject.');

  if (s.error) { tRefreshAccountBody(); return; }

  s.saving = true;
  tRefreshAccountBody();
  setTimeout(() => {
    const a = TEACHER_DATA.account;
    a.name = name;
    a.email = email;
    a.phone = phone;
    a.subjects = subjectsRaw.split(',').map(x => x.trim()).filter(Boolean);
    a.bio = bio;
    tState.profile = { editing: false, saving: false, error: '', success: true, draft: null };
    tRefreshAccountBody();
    tShowToast(t('Profile updated successfully.'));
    // The sidebar name is set once at login (loadDashboard) and never re-synced —
    // update it directly so the edited name is genuinely reflected everywhere.
    const sbName = document.getElementById('sb-name');
    if (sbName) sbName.textContent = a.name;
  }, 700);
}

/* ── Copy Teacher ID ── */
function tCopyTeacherId() {
  const id = TEACHER_DATA.account.teacherId;
  const btn = document.getElementById('t-copy-btn');
  const confirm = () => {
    if (!btn) return;
    btn.innerHTML = aIcon('check') + ' ' + t('Copied');
    btn.classList.add('gd-copied');
    setTimeout(() => { if (btn) { btn.textContent = t('Copy'); btn.classList.remove('gd-copied'); } }, 1800);
  };
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(id).then(confirm).catch(confirm);
  } else { confirm(); }
}

/* ══════════════════════════════════════════════════════
   ADVANCED REPORTING
   Compiles the SAME underlying data/logic already used by Analytics into
   a formal, scoped, period-filtered report format with save/review —
   rather than a second, disconnected analytics implementation.
══════════════════════════════════════════════════════ */
const T_REPORT_TYPES = [
  { id:'class-performance', label:'Class Performance', scope:'class' },
  { id:'attendance',        label:'Attendance',        scope:'class' },
  { id:'student-progress',  label:'Student Progress',  scope:'student' },
  { id:'behavior',          label:'Behavior & Participation', scope:'class' },
];
function tReportTypeMeta(id) { return T_REPORT_TYPES.find(x => x.id === id) || T_REPORT_TYPES[0]; }
function tReportsView() {
  return `<div id="t-reports-content">${tReportsBody()}</div>`;
}
function tReportsBody() {
  const r = tState.reports;
  if (r.screen === 'saved') return tReportsSavedListScreen();
  if (r.screen === 'view') return tReportViewScreen();
  return tReportFormScreen();
}
function tRefreshReports() { const el = document.getElementById('t-reports-content'); if (el) el.innerHTML = tReportsBody(); }

/* ── Report configuration form ── */
function tReportFormScreen() {
  const r = tState.reports;
  const meta = tReportTypeMeta(r.type);
  return `<div class="card"><div class="card-header"><div class="card-title">${t('Generate a Report')}</div>${TEACHER_DATA.savedReports.length ? `<div class="card-action" onclick="tShowSavedReports()">${t('Saved Reports')} (${TEACHER_DATA.savedReports.length})</div>` : ''}</div>
    <div class="card-body">
      <div class="st-field"><label>${t('Report Type')}</label><select id="t-report-type" onchange="tSetReportType(this.value)">
        ${T_REPORT_TYPES.map(rt => `<option value="${rt.id}" ${rt.id===r.type?'selected':''}>${t(rt.label)}</option>`).join('')}
      </select></div>
      ${meta.scope === 'class' ? `
        <div class="st-field"><label>${t('Class')}</label><select id="t-report-class">
          <option value="">${t('Select a class')}</option>
          ${TEACHER_DATA.classes.map(c => `<option value="${c.id}" ${c.id===r.classId?'selected':''}>${gdCommsEsc(c.name)} — ${gdCommsEsc(t(c.subject))}</option>`).join('')}
        </select></div>` : `
        <div class="st-field"><label>${t('Student')}</label>
          ${r.studentId ? (() => { const st = tGetStudent(r.studentId); return `<div class="info-row"><span>${st ? gdCommsEsc(st.name) : t('Unknown student')}</span><span class="card-action" onclick="tSetReportStudent(null)">${t('Change')}</span></div>`; })()
            : `<input class="gd-comm-search-input" type="text" placeholder="${t('Search by name or student ID...')}" value="${gdCommsEsc(r.studentSearch)}" oninput="tSetReportStudentSearch(this.value)"><div id="t-report-student-results">${tReportStudentResultsBlock()}</div>`}
        </div>`}
      <div class="st-field"><label>${t('Time Period')}</label><select id="t-report-period">
        <option value="term" ${r.period==='term'?'selected':''}>${t('This Term')}</option>
        <option value="all" ${r.period==='all'?'selected':''}>${t('All Time')}</option>
      </select></div>
      <button class="st-btn" onclick="tGenerateReport()" ${r.loadState==='loading'?'disabled':''}>${r.loadState==='loading' ? `<span class="gd-spinner"></span>${t('Generating...')}` : t('Generate Report')}</button>
      ${r.error ? `<div class="st-inline-msg err show" style="margin-top:12px">${r.error}</div>` : ''}
    </div></div>`;
}
function tSetReportType(v) {
  tState.reports.type = v;
  tState.reports.error = '';
  tRefreshReports();
}
function tSetReportStudentSearch(v) {
  tState.reports.studentSearch = v;
  const el = document.getElementById('t-report-student-results');
  if (el) el.innerHTML = tReportStudentResultsBlock();
}
function tReportStudentResultsBlock() {
  const q = tState.reports.studentSearch.trim().toLowerCase();
  if (!q) return '';
  const results = TEACHER_DATA.students.filter(s => s.name.toLowerCase().includes(q) || s.studentId.toLowerCase().includes(q));
  if (!results.length) return `<div class="gd-empty-mini" style="text-align:left;padding:10px 0 0">${t('No students match your search.')}</div>`;
  return `<div style="margin-top:8px">${results.map(s => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="tSetReportStudent('${s.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();tSetReportStudent('${s.id}')}">
    <span>${gdCommsEsc(s.name)}</span><span style="color:var(--muted);font-size:12px">${gdCommsEsc(s.studentId)}</span>
  </div>`).join('')}</div>`;
}
function tSetReportStudent(id) {
  tState.reports.studentId = id;
  tState.reports.studentSearch = '';
  tRefreshReports();
}

/* ── Generation (loading/error simulation, then a real compiled report) ── */
function tGenerateReport() {
  const r = tState.reports;
  const meta = tReportTypeMeta(r.type);
  const classEl = document.getElementById('t-report-class');
  const periodEl = document.getElementById('t-report-period');
  if (classEl) r.classId = classEl.value || null;
  if (periodEl) r.period = periodEl.value;

  if (meta.scope === 'class' && !r.classId) { r.error = t('Select a class first.'); tRefreshReports(); return; }
  if (meta.scope === 'student' && !r.studentId) { r.error = t('Select a student first.'); tRefreshReports(); return; }

  r.error = '';
  r.loadState = 'loading';
  tRefreshReports();
  setTimeout(() => {
    if (Math.random() < 0.08) {
      r.loadState = 'error';
      r.screen = 'view'; // error state renders within the report view, not the form
      tRefreshReports();
      return;
    }
    r.loadState = 'ready';
    r.screen = 'view';
    r.viewingId = null;
    r.generatedAt = tISODate(T_TODAY);
    tRefreshReports();
  }, 900);
}
function tRetryGenerateReport() { tGenerateReport(); }
function tBackToReportForm() {
  tState.reports.screen = 'form';
  tState.reports.loadState = 'idle';
  tState.reports.error = '';
  tRefreshReports();
}

/* ── Report viewer (real compiled content, reusing existing Analytics logic) ── */
function tReportViewScreen() {
  const r = tState.reports;
  if (r.loadState === 'error') {
    return `<div class="gd-empty-state">
      <div class="gd-empty-state-ico" style="background:rgba(220,38,38,0.12);color:var(--red)"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg></div>
      <div class="gd-empty-state-title">${t("Couldn't generate the report")}</div>
      <div class="gd-empty-state-sub">${t('Something went wrong. Please try again.')}</div>
      <button class="st-btn ghost" onclick="tRetryGenerateReport()">${t('Retry')}</button>
    </div>`;
  }
  const meta = tReportTypeMeta(r.type);
  const body = meta.id === 'class-performance' ? tReportClassPerformanceBody(r)
    : meta.id === 'attendance' ? tReportAttendanceBody(r)
    : meta.id === 'student-progress' ? tReportStudentProgressBody(r)
    : tReportBehaviorBody(r);
  return `<div class="card">
    <div class="card-header">
      <div style="display:flex;align-items:center;gap:10px;min-width:0;flex:1">
        <button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="tBackToReportForm()">${t('← Back')}</button>
        <div class="card-title">${t(meta.label)} ${t('Report')}</div>
      </div>
      <button type="button" class="st-btn ghost sm" onclick="tSaveReport()">${t('Save Report')}</button>
    </div>
    <div class="card-body">
      <div style="font-size:11.5px;color:var(--muted);margin-bottom:14px">${t('Generated')} ${r.generatedAt} · ${r.period === 'all' ? t('All Time') : t('This Term')}</div>
      ${body}
    </div></div>`;
}
function tReportClassPerformanceBody(r) {
  const cls = tGetClass(r.classId);
  if (!cls) return `<div class="gd-empty-mini">${t('No data available for this selection.')}</div>`;
  const dist = tClassGradeDistribution(cls.id);
  const maxCount = Math.max(1, ...dist.map(b => b.count));
  const points = tClassProgressPoints(cls.id);
  return `
    <div style="font-size:13px;font-weight:600;margin-bottom:12px">${gdCommsEsc(cls.name)} — ${gdCommsEsc(t(cls.subject))}</div>
    <div class="gd-pay-stat-row">
      <div class="stat-card"><div class="stat-label">${t('Students')}</div><div class="stat-val">${tClassStudentCount(cls.id)}</div><div class="stat-icon blue">${aIcon('users')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Avg. Performance')}</div><div class="stat-val">${tClassAvgPerformance(cls.id)}/20</div><div class="stat-icon green">${aIcon('bar-chart')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Avg. Attendance')}</div><div class="stat-val">${tClassAttendanceRate(cls.id)}%</div><div class="stat-icon yellow">${aIcon('check-circle')}</div></div>
    </div>
    <div style="margin-top:16px;font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Grade Distribution')}</div>
    ${dist.map(b => `<div style="margin-bottom:10px"><div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:4px"><span>${b.label}</span><span style="color:var(--muted)">${b.count}</span></div><div class="progress-track"><div class="progress-fill ${b.min>=16?'green':b.min>=12?'yellow':'red'}" style="width:${(b.count/maxCount*100).toFixed(0)}%"></div></div></div>`).join('')}
    <div style="margin-top:16px;font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Progress Over Time')}</div>
    ${gdSvgLineChart(points, { max:100, unit:'%', ariaLabel:t('Class progress'), emptyText:t('No graded assessments yet for this class.') })}
    <div style="margin-top:16px;font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Roster')}</div>
    ${tClassStudents(cls.id).map(s => `<div class="info-row"><span>${gdCommsEsc(s.name)}</span><span>${s.avgGrade}/20 · ${s.attendanceRate}%</span></div>`).join('')}`;
}
function tReportAttendanceBody(r) {
  const cls = tGetClass(r.classId);
  if (!cls) return `<div class="gd-empty-mini">${t('No data available for this selection.')}</div>`;
  const sessions = tClassAttendanceSessions(cls.id);
  const roster = tClassStudents(cls.id);
  const points = sessions.map(s => {
    const vals = Object.values(s.statuses);
    const presentCount = vals.filter(v => v === 'present' || v === 'late').length;
    return { label: s.date.slice(5), value: vals.length ? Math.round((presentCount / vals.length) * 100) : 0 };
  });
  return `
    <div style="font-size:13px;font-weight:600;margin-bottom:12px">${gdCommsEsc(cls.name)}</div>
    <div class="gd-pay-stat-row">
      <div class="stat-card"><div class="stat-label">${t('Sessions Recorded')}</div><div class="stat-val">${sessions.length}</div><div class="stat-icon blue">${aIcon('calendar')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Class Attendance Rate')}</div><div class="stat-val">${tClassAttendanceRate(cls.id)}%</div><div class="stat-icon green">${aIcon('check-circle')}</div></div>
    </div>
    <div style="margin-top:16px;font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Attendance Trend')}</div>
    ${gdSvgLineChart(points, { max:100, unit:'%', ariaLabel:t('Attendance trend'), emptyText:t('No attendance has been recorded for this class yet.') })}
    <div style="margin-top:16px;font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Student Breakdown')}</div>
    ${roster.map(s => `<div class="info-row"><span>${gdCommsEsc(s.name)}</span><span>${s.attendanceRate}%</span></div>`).join('')}`;
}
function tReportStudentProgressBody(r) {
  const student = tGetStudent(r.studentId);
  if (!student) return `<div class="gd-empty-mini">${t('No data available for this selection.')}</div>`;
  const cls = tGetClass(student.classId);
  const history = tStudentExamHistory(student.id);
  const points = history.map(h => ({ label: h.date.slice(5), value: Math.round((h.score / h.maxScore) * 100) }));
  return `
    <div style="font-size:13px;font-weight:600;margin-bottom:12px">${gdCommsEsc(student.name)} · ${cls ? gdCommsEsc(cls.name) : ''}</div>
    <div class="gd-pay-stat-row">
      <div class="stat-card"><div class="stat-label">${t('Average Grade')}</div><div class="stat-val">${student.avgGrade}/20</div><div class="stat-icon green">${aIcon('bar-chart')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Attendance')}</div><div class="stat-val">${student.attendanceRate}%</div><div class="stat-icon yellow">${aIcon('check-circle')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Assessments')}</div><div class="stat-val">${history.length}</div><div class="stat-icon purple">${aIcon('edit')}</div></div>
    </div>
    <div style="margin-top:16px;font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Grade Progression')}</div>
    ${gdSvgLineChart(points, { max:100, unit:'%', ariaLabel:t('Grade progression'), emptyText:t('Not enough graded assessments yet for this student.') })}
    ${history.length ? `<div style="margin-top:16px;font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Assessment History')}</div>
    ${history.map(h => `<div class="info-row"><span>${gdCommsEsc(h.name)}<div style="font-size:11px;color:var(--muted)">${h.date}</div></span><span>${h.score}/${h.maxScore}</span></div>`).join('')}` : ''}`;
}
function tReportBehaviorBody(r) {
  const cls = tGetClass(r.classId);
  if (!cls) return `<div class="gd-empty-mini">${t('No data available for this selection.')}</div>`;
  const studentIds = tClassStudents(cls.id).map(s => s.id);
  const behaviorRecs = TEACHER_DATA.behaviorRecords.filter(x => studentIds.includes(x.studentId));
  const participationRecs = TEACHER_DATA.participationRecords.filter(x => studentIds.includes(x.studentId));
  const behaviorCounts = {};
  behaviorRecs.forEach(x => { behaviorCounts[x.category] = (behaviorCounts[x.category] || 0) + 1; });
  return `
    <div style="font-size:13px;font-weight:600;margin-bottom:12px">${gdCommsEsc(cls.name)}</div>
    <div class="gd-pay-stat-row">
      <div class="stat-card"><div class="stat-label">${t('Behavior Records')}</div><div class="stat-val">${behaviorRecs.length}</div><div class="stat-icon yellow">${aIcon('alert-triangle')}</div></div>
      <div class="stat-card"><div class="stat-label">${t('Participation Records')}</div><div class="stat-val">${participationRecs.length}</div><div class="stat-icon blue">${aIcon('user-check')}</div></div>
    </div>
    <div style="margin-top:16px;font-size:12.5px;font-weight:600;margin-bottom:8px">${t('Behavior by Category')}</div>
    ${Object.keys(behaviorCounts).length ? Object.keys(behaviorCounts).map(cat => `<div class="info-row"><span>${gdCommsEsc(t(cat))}</span><span>${behaviorCounts[cat]}</span></div>`).join('') : `<div class="gd-empty-mini">${t('No behavior records for this class yet.')}</div>`}`;
}

/* ── Save / Saved Reports ── */
function tSaveReport() {
  const r = tState.reports;
  const meta = tReportTypeMeta(r.type);
  let label = t(meta.label);
  if (meta.scope === 'class') { const c = tGetClass(r.classId); if (c) label += ' — ' + c.name; }
  else { const s = tGetStudent(r.studentId); if (s) label += ' — ' + s.name; }
  TEACHER_DATA.savedReports.unshift({ id:'rep' + Date.now(), label, type:r.type, classId:r.classId, studentId:r.studentId, period:r.period, createdAt:r.generatedAt });
  tShowToast(t('Report saved.'));
}
function tShowSavedReports() {
  tState.reports.screen = 'saved';
  tRefreshReports();
}
function tReportsSavedListScreen() {
  const reports = TEACHER_DATA.savedReports;
  return `<div class="card"><div class="card-header">
    <div style="display:flex;align-items:center;gap:10px"><button type="button" class="st-btn ghost sm gd-pay-back-btn" onclick="tBackToReportForm()">${t('← Back')}</button><div class="card-title">${t('Saved Reports')}</div></div>
    </div>
    <div class="card-body">
      ${reports.length ? reports.map(rp => `<div class="info-row" style="cursor:pointer" role="button" tabindex="0" onclick="tOpenSavedReport('${rp.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();tOpenSavedReport('${rp.id}')}">
        <span>${gdCommsEsc(rp.label)}</span><span style="color:var(--muted);font-size:12px">${rp.createdAt}</span>
      </div>`).join('') : `<div class="gd-empty-mini">${t('No saved reports yet.')}</div>`}
    </div></div>`;
}
function tOpenSavedReport(id) {
  const rp = TEACHER_DATA.savedReports.find(x => x.id === id);
  if (!rp) return;
  tState.reports.type = rp.type;
  tState.reports.classId = rp.classId;
  tState.reports.studentId = rp.studentId;
  tState.reports.period = rp.period;
  tState.reports.generatedAt = rp.createdAt;
  tState.reports.loadState = 'ready';
  tState.reports.screen = 'view';
  tRefreshReports();
}


/* ══════════════════════════════════════════════════════
   TIMETABLE — this teacher's own teaching schedule.
   Cells show the class being taught (rather than the teacher's own
   name, which would be redundant here) plus the room.
══════════════════════════════════════════════════════ */
function tTimetableView() {
  const acct = TEACHER_DATA.account || {};
  /* C4 — the canonical teacherId is stored directly; name-matching kept
     only as a fallback for a record predating this migration. */
  const teacher = ttTeacher(acct.timetableTeacherId) || ttTeacherByName(acct.name);
  if (!teacher) {
    return `<div class="card"><div class="card-body"><div class="tt-empty">${t('Your teaching schedule has not been published yet.')}</div></div></div>`;
  }
  const entries = ttEntriesForTeacher(teacher.id);
  const classes = Array.from(new Set(entries.map(e => e.classId)));
  const freeSlots = ttAllSlots().length - entries.length;
  return `
    <div class="card"><div class="card-header">
        <div class="card-title">${t('My Teaching Schedule')}</div>
        <button type="button" class="st-btn ghost sm" onclick="ttPrint()">${aIcon('printer')} ${t('Print')}</button>
      </div>
      <div class="card-body">
        <div style="font-size:12px;color:var(--muted);margin-bottom:12px">${ttEsc(teacher.name)} · ${entries.length} ${t('periods/week')} · ${freeSlots} ${t('free slots')} · ${ttEsc(TT_META.academicYear)} · ${ttEsc(TT_META.term)}</div>
        ${ttRenderGrid(entries, 'teacher')}
        <div class="tt-legend">
          ${classes.map(cid => { const c = ttClass(cid); return c ? `<div class="tt-legend-item"><span class="tt-legend-dot" style="background:var(--accent)"></span>${ttEsc(c.name)}</div>` : ''; }).join('')}
        </div>
      </div></div>
    ${ttRenderSummary(entries, 'teacher')}`;
}
