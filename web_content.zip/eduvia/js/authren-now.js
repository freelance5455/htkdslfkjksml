/* ────────────────────────────────
   AUTHREN_NOW — the single "today" every module anchors to.
   The demo dataset is built around Term 2 of 2025-2026.

   Loaded first, before every other script, because several modules
   (the shared attendance table among them) need it at their own
   top-level load time, not just inside a later function call.
──────────────────────────────── */
const AUTHREN_NOW = new Date(2026, 2, 11);   // 11 March 2026
const AUTHREN_NOW_ISO = '2026-03-11';
const AUTHREN_DAY_NAMES = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
const AUTHREN_MONTH_NAMES = ['January','February','March','April','May','June','July','August','September','October','November','December'];
function authrenFormatToday() {
  return AUTHREN_DAY_NAMES[AUTHREN_NOW.getDay()] + ', ' + AUTHREN_NOW.getDate() + ' '
       + AUTHREN_MONTH_NAMES[AUTHREN_NOW.getMonth()] + ' ' + AUTHREN_NOW.getFullYear();
}
/* Institution name, resolved from whichever role dataset is loaded.
   Replaced by AUTHREN_DB.institution.name when the shared store lands. */
function authrenInstitutionName() {
  if (typeof SCHOOL_DATA !== 'undefined' && SCHOOL_DATA.institution && SCHOOL_DATA.institution.name) return SCHOOL_DATA.institution.name;
  if (typeof HEAD_DATA !== 'undefined' && HEAD_DATA.institution && HEAD_DATA.institution.name) return HEAD_DATA.institution.name;
  return '';
}
