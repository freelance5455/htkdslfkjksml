/* ════════════════════════════════════════════════════════════
   AUTHREN — TIMETABLES (shared module)

   One canonical timetable model used by every role, so a change made
   by the Head of Institution is the same timetable a student, guardian
   and teacher see. Roles differ only in which slice they are shown:

     Student  → their own class
     Guardian → their selected child's class
     Teacher  → their own teaching schedule
     Head     → any class, any teacher, plus the auto-generator

   Everything below is frontend state. Persisting a generated timetable
   is a BACKEND responsibility; the frontend holds the model, the
   constraints and the resulting states.
════════════════════════════════════════════════════════════ */

/* ─── Structure: days & periods ─── */
const TT_DAYS = [
  { id: 'mon', label: 'Monday',    short: 'Mon' },
  { id: 'tue', label: 'Tuesday',   short: 'Tue' },
  { id: 'wed', label: 'Wednesday', short: 'Wed' },
  { id: 'thu', label: 'Thursday',  short: 'Thu' },
  { id: 'fri', label: 'Friday',    short: 'Fri' },
  { id: 'sat', label: 'Saturday',  short: 'Sat' },
];

/* Typical Moroccan private-school day: morning block, lunch, afternoon
   block. Saturday is a morning-only day (handled by TT_SAT_PERIODS). */
const TT_PERIODS = [
  { id: 'p1', start: '08:00', end: '09:00' },
  { id: 'p2', start: '09:00', end: '10:00' },
  { id: 'br1', start: '10:00', end: '10:15', isBreak: true, label: 'Break' },
  { id: 'p3', start: '10:15', end: '11:15' },
  { id: 'p4', start: '11:15', end: '12:15' },
  { id: 'lunch', start: '12:15', end: '14:00', isBreak: true, label: 'Lunch' },
  { id: 'p5', start: '14:00', end: '15:00' },
  { id: 'p6', start: '15:00', end: '16:00' },
  { id: 'br2', start: '16:00', end: '16:15', isBreak: true, label: 'Break' },
  { id: 'p7', start: '16:15', end: '17:15' },
];

/* Teaching periods only (breaks excluded) */
const TT_TEACHING_PERIODS = TT_PERIODS.filter(p => !p.isBreak);
/* Saturday runs mornings only */
const TT_SAT_PERIOD_IDS = ['p1', 'p2', 'p3', 'p4'];

function ttIsTeachingSlot(dayId, periodId) {
  const p = TT_PERIODS.find(x => x.id === periodId);
  if (!p || p.isBreak) return false;
  if (dayId === 'sat') return TT_SAT_PERIOD_IDS.includes(periodId);
  return true;
}
function ttPeriod(periodId) { return TT_PERIODS.find(p => p.id === periodId) || null; }
function ttDay(dayId) { return TT_DAYS.find(d => d.id === dayId) || null; }
function ttPeriodLabel(periodId) {
  const p = ttPeriod(periodId);
  return p ? p.start + ' – ' + p.end : '';
}

/* ─── Reference data ─── */
const TT_SUBJECTS = [
  { id: 'math',  name: 'Mathematics',    icon: aIcon('hash'), color: 'var(--color-primary)' },
  { id: 'phys',  name: 'Physics',        icon: aIcon('flask'), color: 'var(--color-accent)' },
  { id: 'svt',   name: 'Life & Earth Sciences', icon: aIcon('leaf'), color: 'var(--color-primary-dark)' },
  { id: 'ar',    name: 'Arabic',         icon: aIcon('book-open'), color: 'var(--color-text-muted)' },
  { id: 'fr',    name: 'French',         icon: aIcon('message'), color: 'var(--color-accent)' },
  { id: 'en',    name: 'English',        icon: aIcon('message'), color: 'var(--color-primary)' },
  { id: 'hist',  name: 'History & Geography', icon: aIcon('landmark-2'), color: 'var(--color-text-muted2)' },
  { id: 'islam', name: 'Islamic Education', icon: aIcon('landmark-2'), color: 'var(--color-primary-dark)' },
  { id: 'philo', name: 'Philosophy',     icon: aIcon('sparkles'), color: 'var(--color-text-muted)' },
  { id: 'sport', name: 'Physical Education', icon: aIcon('target'), color: 'var(--color-accent)' },
  { id: 'info',  name: 'Computer Science', icon: aIcon('monitor'), color: 'var(--color-primary)' },
];
function ttSubject(id) { return TT_SUBJECTS.find(s => s.id === id) || null; }

/* ROOMS, TEACHERS and CLASSES now come from the one shared registry
   (js/authren-registry.js) instead of this file's own separate copies —
   the single biggest source of the cross-role inconsistencies found
   during the correction audit (a class's teacher disagreeing with the
   same class's teacher on another screen, etc.). The generator and
   renderers below are UNCHANGED; only where the data comes from moved. */
const TT_ROOMS = AUTHREN_REGISTRY.rooms;
function ttRoom(id) { return AUTHREN_REGISTRY.rooms.find(r => r.id === id) || null; }

/* Subjects that require a specialised room */
const TT_ROOM_REQUIREMENT = { phys: 'lab', svt: 'lab', info: 'it', sport: 'sport' };

const TT_TEACHERS = AUTHREN_REGISTRY.teachers;
function ttTeacher(id) { return AUTHREN_REGISTRY.teacher(id); }
function ttTeachersForSubject(subjectId) {
  return AUTHREN_REGISTRY.teachersForSubject(subjectId);
}
function ttTeachersForSubjectAtCampus(subjectId, campusId) {
  return AUTHREN_REGISTRY.teachersForSubject(subjectId).filter(t => t.campusId === campusId);
}

const TT_CLASSES = AUTHREN_REGISTRY.classes;
function ttClass(id) { return AUTHREN_REGISTRY.class(id); }
/* C4 — kept only as a display-name fallback for legacy records that have
   not yet been migrated to a stored classId; every NEW reference should
   use ttClass(id) directly, never this. */
function ttClassByName(name) { return AUTHREN_REGISTRY.classByName(name); }

/* ─── Live timetable entries ───
   Each entry is one lesson in one slot:
   { id, classId, subjectId, teacherId, roomId, dayId, periodId } */
let TT_ENTRIES = [];
let TT_META = { generatedAt: null, academicYear: '2025-2026', term: 'Term 2' };

/* ─── Lookups ─── */
function ttEntriesForClass(classId) { return TT_ENTRIES.filter(e => e.classId === classId); }
function ttEntriesForTeacher(teacherId) { return TT_ENTRIES.filter(e => e.teacherId === teacherId); }
function ttEntryAt(entries, dayId, periodId) {
  return entries.find(e => e.dayId === dayId && e.periodId === periodId) || null;
}
function ttTeacherByName(name) {
  if (!name) return null;
  const n = String(name).trim().toLowerCase();
  return TT_TEACHERS.find(t => t.name.toLowerCase() === n) || null;
}

/* ════════════════════════════════════════════════════════════
   AUTO-GENERATOR

   Constraint-satisfaction with backtracking. Hard constraints, all of
   which are genuinely enforced (never silently violated):
     1. A class cannot be in two places at once.
     2. A teacher cannot be in two places at once.
     3. A room cannot host two classes at once.
     4. Lab/IT/sport subjects must use a room of the matching type.
     5. Each class gets exactly its required weekly periods per subject.
     6. No more than 2 consecutive periods of the same subject.
     7. A subject appears at most twice on the same day for a class.

   If the generator cannot satisfy everything, it reports the failure
   honestly rather than returning a partial timetable presented as valid.
════════════════════════════════════════════════════════════ */

function ttAllSlots() {
  const slots = [];
  TT_DAYS.forEach(d => {
    TT_TEACHING_PERIODS.forEach(p => {
      if (ttIsTeachingSlot(d.id, p.id)) slots.push({ dayId: d.id, periodId: p.id });
    });
  });
  return slots;
}

function ttCapacityReport() {
  const slotsPerClass = ttAllSlots().length;
  return TT_CLASSES.map(c => {
    const required = Object.values(c.weeklyLoad).reduce((a, b) => a + b, 0);
    return { classId: c.id, className: c.name, required, available: slotsPerClass, fits: required <= slotsPerClass };
  });
}

function ttRoomCandidates(subjectId, cls) {
  const size = cls.studentCount || cls.capacity || 0;
  const req = TT_ROOM_REQUIREMENT[subjectId];
  /* A room belongs to one physical campus. A class can only ever use a
     room at its own campus — sharing a room pool across campuses was
     never physically realistic and was also the actual cause of the
     generator timing out once the merge grew from 5 classes (all one
     campus) to 12 (three campuses): every class was needlessly competing
     for rooms it could never really use. */
  if (req) return TT_ROOMS.filter(r => r.type === req && r.capacity >= size && r.campusId === cls.campusId);
  const home = ttRoom(cls.homeroomRoomId);
  const homeOk = home && home.capacity >= size && home.campusId === cls.campusId;
  const others = TT_ROOMS.filter(r => r.type === 'standard' && r.id !== cls.homeroomRoomId && r.capacity >= size && r.campusId === cls.campusId);
  return homeOk ? [home].concat(others) : others;
}

function ttGenerateTimetable(options) {
  const opts = options || {};
  const seedClasses = opts.classIds ? TT_CLASSES.filter(c => opts.classIds.includes(c.id)) : TT_CLASSES;

  /* Feasibility check before attempting to solve */
  const capacity = ttCapacityReport().filter(r => seedClasses.some(c => c.id === r.classId));
  const overloaded = capacity.filter(r => !r.fits);
  if (overloaded.length) {
    return {
      ok: false,
      reason: 'overloaded',
      message: 'These classes require more weekly periods than the school week has slots: '
        + overloaded.map(o => o.className + ' (' + o.required + '/' + o.available + ')').join(', '),
      entries: [],
    };
  }

  const slots = ttAllSlots();
  const classBusy = {};    // classId -> "day|period" -> true
  const teacherBusy = {};  // teacherId -> "day|period" -> true
  const roomBusy = {};     // roomId -> "day|period" -> true
  const teacherLoad = {};  // teacherId -> total periods assigned so far
  const result = [];
  let idCounter = 1;

  function teacherIsAvailable(teacher, dayId, periodId) {
    const unavailable = teacher.unavailableSlots || [];
    return !unavailable.some(u => u.dayId === dayId && u.periodId === periodId);
  }
  function teacherHasCapacity(teacher) {
    const cap = teacher.maxWeeklyPeriods;
    if (cap == null) return true;
    return (teacherLoad[teacher.id] || 0) < cap;
  }

  const key = (d, p) => d + '|' + p;

  /* E1 — TEACHING ASSIGNMENT IS COMPUTED ONCE, BEFORE ANY SLOT IS PLACED.
     Exactly one teacher per (class, subject) for the whole week. Without
     this, the slot-placement search below could (and did, when tested)
     give Grade 10-A Math to one teacher for some periods and a different
     qualified teacher for others — genuinely two different teachers
     "teaching" the same class the same subject in the same week. Real
     school staffing does not work that way, and the very first correction
     the institution ever asked for named exactly this failure.

     Assignment is greedy load-balancing: for each class×subject requiring
     a teacher, pick whichever qualified, same-campus teacher currently
     carries the least committed load. This spreads work sensibly without
     needing its own backtracking search — capacity is still a HARD limit,
     enforced below, so an assignment that would overload every candidate
     fails generation honestly rather than being forced through. */
  const teachingAssignments = {}; // "classId|subjectId" -> teacherId
  const assignedLoad = {};        // teacherId -> periods committed so far

  const classSubjectPairs = [];
  seedClasses.forEach(cls => {
    Object.keys(cls.weeklyLoad).forEach(subjectId => {
      if (cls.weeklyLoad[subjectId] > 0) classSubjectPairs.push({ cls, subjectId, periods: cls.weeklyLoad[subjectId] });
    });
  });
  /* Assign scarcest subjects first, same reasoning as the lesson ordering
     below: committing the hard cases early avoids painting a common
     subject's assignment into a corner. */
  classSubjectPairs.sort((a, b) => {
    const ra = ttTeachersForSubjectAtCampus(a.subjectId, a.cls.campusId).length;
    const rb = ttTeachersForSubjectAtCampus(b.subjectId, b.cls.campusId).length;
    return ra - rb;
  });

  let assignmentFailure = null;
  classSubjectPairs.forEach(pair => {
    if (assignmentFailure) return;
    const candidates = ttTeachersForSubjectAtCampus(pair.subjectId, pair.cls.campusId);
    if (!candidates.length) {
      assignmentFailure = pair.cls.name + ' — ' + AUTHREN_REGISTRY.subjectName(pair.subjectId) + ': no qualified teacher at this campus';
      return;
    }
    /* Prefer whichever candidate can actually still fit these periods;
       among those, the least-loaded so far. */
    const fitting = candidates.filter(t => {
      const cap = t.maxWeeklyPeriods;
      return cap == null || (assignedLoad[t.id] || 0) + pair.periods <= cap;
    });
    const pool = fitting.length ? fitting : candidates;
    pool.sort((a, b) => (assignedLoad[a.id] || 0) - (assignedLoad[b.id] || 0));
    const chosen = pool[0];
    teachingAssignments[pair.cls.id + '|' + pair.subjectId] = chosen.id;
    assignedLoad[chosen.id] = (assignedLoad[chosen.id] || 0) + pair.periods;
  });

  if (assignmentFailure) {
    return {
      ok: false,
      reason: 'no-assignment',
      message: 'Could not assign a teacher to every class and subject: ' + assignmentFailure
        + '. Add a qualified teacher at that campus, or reduce the weekly load for that subject.',
      entries: [],
    };
  }

  /* Build the full list of lessons that must be placed, hardest first
     (specialised-room subjects and heavy loads are most constrained). Each
     lesson already knows its one assigned teacher — placement below only
     ever searches day/period/room for it, never a different teacher. */
  const lessons = [];
  seedClasses.forEach(cls => {
    Object.keys(cls.weeklyLoad).forEach(subjectId => {
      const teacherId = teachingAssignments[cls.id + '|' + subjectId];
      for (let i = 0; i < cls.weeklyLoad[subjectId]; i++) {
        lessons.push({ classId: cls.id, subjectId: subjectId, teacherId: teacherId });
      }
    });
  });
  function subjectScarcity(subjectId) {
    const teacherCount = ttTeachersForSubject(subjectId).length || 1;
    const req = TT_ROOM_REQUIREMENT[subjectId];
    const roomCount = req ? TT_ROOMS.filter(r => r.type === req).length || 1 : 99;
    return teacherCount * roomCount;
  }
  const scarcityCache = {};
  lessons.sort((a, b) => {
    scarcityCache[a.subjectId] = scarcityCache[a.subjectId] ?? subjectScarcity(a.subjectId);
    scarcityCache[b.subjectId] = scarcityCache[b.subjectId] ?? subjectScarcity(b.subjectId);
    if (scarcityCache[a.subjectId] !== scarcityCache[b.subjectId]) return scarcityCache[a.subjectId] - scarcityCache[b.subjectId];
    return a.subjectId.localeCompare(b.subjectId);
  });

  /* Deterministic shuffle so results are stable but well distributed */
  function ttSeededOrder(arr, seedStr) {
    let h = 2166136261;
    for (let i = 0; i < seedStr.length; i++) { h ^= seedStr.charCodeAt(i); h = Math.imul(h, 16777619); }
    return arr.slice().sort((a, b) => {
      const ha = Math.imul(h ^ (a.dayId + a.periodId).length, 2654435761) % 1000;
      const hb = Math.imul(h ^ (b.dayId + b.periodId).length, 2654435761) % 1000;
      return ha - hb;
    });
  }

  function sameSubjectOnDay(classId, dayId, subjectId) {
    return result.filter(e => e.classId === classId && e.dayId === dayId && e.subjectId === subjectId).length;
  }
  function consecutiveRun(classId, dayId, periodId, subjectId) {
    const order = TT_TEACHING_PERIODS.map(p => p.id).filter(pid => ttIsTeachingSlot(dayId, pid));
    const idx = order.indexOf(periodId);
    let run = 1;
    for (let i = idx - 1; i >= 0; i--) {
      const e = result.find(x => x.classId === classId && x.dayId === dayId && x.periodId === order[i]);
      if (e && e.subjectId === subjectId) run++; else break;
    }
    for (let i = idx + 1; i < order.length; i++) {
      const e = result.find(x => x.classId === classId && x.dayId === dayId && x.periodId === order[i]);
      if (e && e.subjectId === subjectId) run++; else break;
    }
    return run;
  }

  const MAX_SEARCH_NODES = 300000;
  let nodesExplored = 0;
  let nodeLimitHit = false;

  function place(index) {
    if (nodeLimitHit) return false;
    if (++nodesExplored > MAX_SEARCH_NODES) { nodeLimitHit = true; return false; }
    if (index >= lessons.length) return true;
    const lesson = lessons[index];
    const cls = ttClass(lesson.classId);
    /* E1 — the teacher is fixed by the assignment phase above, never
       chosen here. Placement only searches day/period/room for it. */
    const teacher = ttTeacher(lesson.teacherId);
    if (!teacher) return false;
    const rooms = ttRoomCandidates(lesson.subjectId, cls);
    const orderedSlots = ttSeededOrder(slots, lesson.classId + lesson.subjectId + index);

    for (let s = 0; s < orderedSlots.length; s++) {
      const slot = orderedSlots[s];
      const k = key(slot.dayId, slot.periodId);

      if (classBusy[lesson.classId] && classBusy[lesson.classId][k]) continue;
      if (sameSubjectOnDay(lesson.classId, slot.dayId, lesson.subjectId) >= 2) continue;
      if (teacherBusy[teacher.id] && teacherBusy[teacher.id][k]) continue;
      if (!teacherIsAvailable(teacher, slot.dayId, slot.periodId)) continue;
      if (!teacherHasCapacity(teacher)) continue;

      for (let r = 0; r < rooms.length; r++) {
        const room = rooms[r];
        if (roomBusy[room.id] && roomBusy[room.id][k]) continue;

        /* Tentatively place */
        const entry = {
          id: 'tt' + (idCounter++),
          classId: lesson.classId, subjectId: lesson.subjectId,
          teacherId: teacher.id, roomId: room.id,
          dayId: slot.dayId, periodId: slot.periodId,
        };
        result.push(entry);
        if (consecutiveRun(lesson.classId, slot.dayId, slot.periodId, lesson.subjectId) > 2) {
          result.pop(); idCounter--; continue;
        }
        classBusy[lesson.classId] = classBusy[lesson.classId] || {}; classBusy[lesson.classId][k] = true;
        teacherBusy[teacher.id] = teacherBusy[teacher.id] || {}; teacherBusy[teacher.id][k] = true;
        roomBusy[room.id] = roomBusy[room.id] || {}; roomBusy[room.id][k] = true;
        teacherLoad[teacher.id] = (teacherLoad[teacher.id] || 0) + 1;

        if (place(index + 1)) return true;

        /* Backtrack */
        result.pop(); idCounter--;
        delete classBusy[lesson.classId][k];
        delete teacherBusy[teacher.id][k];
        delete roomBusy[room.id][k];
        teacherLoad[teacher.id]--;
      }
    }
    return false;
  }

  const solved = place(0);
  if (!solved) {
    if (nodeLimitHit) {
      return {
        ok: false,
        reason: 'search-limit',
        message: 'This configuration is too constrained to solve within a reasonable effort budget. Try reducing a subject\'s weekly load, adding a teacher for a scarce subject, or adding a specialised room — the same steps that resolve a normal conflict.',
        entries: [],
      };
    }
    return {
      ok: false,
      reason: 'unsatisfiable',
      message: 'Could not build a timetable that satisfies every constraint with the current teachers, rooms and subject loads. Try reducing a subject load, adding a teacher for an over-subscribed subject, or adding a specialised room.',
      entries: [],
    };
  }
  return { ok: true, entries: result, placed: result.length };
}

/* Validate an arbitrary entry set — used to prove a generated timetable
   is genuinely conflict-free rather than assuming it. */
function ttValidate(entries) {
  const problems = [];
  const seen = { class: {}, teacher: {}, room: {} };
  entries.forEach(e => {
    const k = e.dayId + '|' + e.periodId;
    [['class', e.classId], ['teacher', e.teacherId], ['room', e.roomId]].forEach(pair => {
      const kind = pair[0], id = pair[1];
      seen[kind][id] = seen[kind][id] || {};
      if (seen[kind][id][k]) {
        problems.push({ kind: kind, id: id, dayId: e.dayId, periodId: e.periodId });
      }
      seen[kind][id][k] = true;
    });
    if (!ttIsTeachingSlot(e.dayId, e.periodId)) {
      problems.push({ kind: 'slot', id: e.id, dayId: e.dayId, periodId: e.periodId });
    }
    const req = TT_ROOM_REQUIREMENT[e.subjectId];
    if (req) {
      const room = ttRoom(e.roomId);
      if (!room || room.type !== req) problems.push({ kind: 'room-type', id: e.id, dayId: e.dayId, periodId: e.periodId });
    }
    const teacher = ttTeacher(e.teacherId);
    if (!teacher || !teacher.subjectIds.includes(e.subjectId)) {
      problems.push({ kind: 'teacher-subject', id: e.id, dayId: e.dayId, periodId: e.periodId });
    }
    /* E2 — a teacher must never be placed into a slot they marked unavailable. */
    if (teacher && (teacher.unavailableSlots || []).some(u => u.dayId === e.dayId && u.periodId === e.periodId)) {
      problems.push({ kind: 'teacher-unavailable', id: e.id, dayId: e.dayId, periodId: e.periodId });
    }
    /* E3 — a class must never be placed into a room smaller than it. */
    const cls = ttClass(e.classId);
    const room = ttRoom(e.roomId);
    if (cls && room) {
      const size = cls.studentCount || cls.capacity || 0;
      if (room.capacity < size) problems.push({ kind: 'room-capacity', id: e.id, dayId: e.dayId, periodId: e.periodId });
    }
  });
  /* E2 — no teacher may exceed their weekly period cap across the whole draft. */
  const loadByTeacher = {};
  entries.forEach(e => { loadByTeacher[e.teacherId] = (loadByTeacher[e.teacherId] || 0) + 1; });
  Object.keys(loadByTeacher).forEach(tid => {
    const teacher = ttTeacher(tid);
    if (teacher && teacher.maxWeeklyPeriods != null && loadByTeacher[tid] > teacher.maxWeeklyPeriods) {
      problems.push({ kind: 'teacher-overload', id: tid, got: loadByTeacher[tid], max: teacher.maxWeeklyPeriods });
    }
  });
  /* E1 — a class must never be taught the same subject by more than one
     teacher across the week. This is the exact defect the correction
     brief opened with (Grade 10-A Physics taught by two different
     teachers) and the one this validator originally failed to catch. */
  const teacherPerClassSubject = {};
  entries.forEach(e => {
    const k = e.classId + '|' + e.subjectId;
    teacherPerClassSubject[k] = teacherPerClassSubject[k] || new Set();
    teacherPerClassSubject[k].add(e.teacherId);
  });
  Object.keys(teacherPerClassSubject).forEach(k => {
    if (teacherPerClassSubject[k].size > 1) {
      problems.push({ kind: 'multiple-teachers', id: k, teachers: Array.from(teacherPerClassSubject[k]) });
    }
  });

  /* Load completeness */
  TT_CLASSES.forEach(c => {
    if (!entries.some(e => e.classId === c.id)) return;
    Object.keys(c.weeklyLoad).forEach(sid => {
      const got = entries.filter(e => e.classId === c.id && e.subjectId === sid).length;
      if (got !== c.weeklyLoad[sid]) {
        problems.push({ kind: 'load', id: c.id + '/' + sid, expected: c.weeklyLoad[sid], got: got });
      }
    });
  });
  return { ok: problems.length === 0, problems: problems };
}

/* Build the default timetable on load so every role has something real
   to display immediately. */
function ttEnsureTimetable() {
  if (TT_ENTRIES.length) return;
  const res = ttGenerateTimetable();
  if (res.ok) {
    TT_ENTRIES = res.entries;
    TT_META.generatedAt = '2026-09-01';
  }
}

/* ════════════════════════════════════════════════════════════
   SHARED RENDERING
   `mode` decides what each cell emphasises:
     'class'   → subject, teacher, room   (student / guardian / head-by-class)
     'teacher' → subject, class, room     (teacher / head-by-teacher)
════════════════════════════════════════════════════════════ */

function ttEsc(str) {
  return String(str == null ? '' : str).replace(/[&<>"']/g, ch => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[ch]));
}

function ttCellHtml(entry, mode) {
  if (!entry) return '<div class="tt-cell tt-cell-free"></div>';
  const subj = ttSubject(entry.subjectId);
  const room = ttRoom(entry.roomId);
  const secondary = mode === 'teacher'
    ? (ttClass(entry.classId) ? ttClass(entry.classId).name : '')
    : (ttTeacher(entry.teacherId) ? ttTeacher(entry.teacherId).name : '');
  return `<div class="tt-cell" style="--tt-accent:${subj ? subj.color : '#888'}" role="button" tabindex="0"
      onclick="ttOpenEntry('${entry.id}','${mode}')"
      onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();ttOpenEntry('${entry.id}','${mode}')}">
    <div class="tt-cell-subject">${subj ? subj.icon + ' ' + ttEsc(subj.name) : ''}</div>
    <div class="tt-cell-meta">${ttEsc(secondary)}</div>
    <div class="tt-cell-room">${room ? ttEsc(room.name) : ''}</div>
  </div>`;
}

function ttRenderGrid(entries, mode) {
  if (!entries || !entries.length) {
    return `<div class="tt-empty">${t('No timetable has been published yet.')}</div>`;
  }
  let html = '<div class="tt-scroll"><table class="tt-grid"><thead><tr><th class="tt-time-head">' + t('Time') + '</th>';
  TT_DAYS.forEach(d => { html += '<th>' + t(d.label) + '</th>'; });
  html += '</tr></thead><tbody>';

  TT_PERIODS.forEach(p => {
    if (p.isBreak) {
      html += `<tr class="tt-break-row"><td class="tt-time">${p.start} – ${p.end}</td>
        <td colspan="${TT_DAYS.length}" class="tt-break-cell">${t(p.label)}</td></tr>`;
      return;
    }
    html += `<tr><td class="tt-time">${p.start}<span>${p.end}</span></td>`;
    TT_DAYS.forEach(d => {
      if (!ttIsTeachingSlot(d.id, p.id)) {
        html += '<td class="tt-closed"></td>';
        return;
      }
      html += '<td>' + ttCellHtml(ttEntryAt(entries, d.id, p.id), mode) + '</td>';
    });
    html += '</tr>';
  });
  html += '</tbody></table></div>';

  /* Narrow screens: the same lessons as a day-by-day list, so the timetable
     reflows instead of scrolling sideways. Both forms carry identical
     content; CSS shows whichever suits the viewport. */
  html += ttRenderDayList(entries, mode);
  return html;
}

function ttRenderDayList(entries, mode) {
  let html = '<div class="tt-daylist">';
  TT_DAYS.forEach(d => {
    const dayEntries = TT_TEACHING_PERIODS
      .filter(p => ttIsTeachingSlot(d.id, p.id))
      .map(p => ({ period: p, entry: ttEntryAt(entries, d.id, p.id) }))
      .filter(x => x.entry);
    html += '<div class="tt-day-block"><div class="tt-day-head">' + t(ttDay(d.id).label) + '</div>';
    if (!dayEntries.length) {
      html += '<div class="tt-day-free">' + t('No lessons') + '</div>';
    } else {
      dayEntries.forEach(x => {
        const e = x.entry;
        const subj = ttSubject(e.subjectId);
        const room = ttRoom(e.roomId);
        const secondary = mode === 'teacher'
          ? (ttClass(e.classId) ? ttClass(e.classId).name : '')
          : (ttTeacher(e.teacherId) ? ttTeacher(e.teacherId).name : '');
        html += `<div class="tt-day-row" style="--tt-accent:${subj ? subj.color : '#888'}" role="button" tabindex="0"
            onclick="ttOpenEntry('${e.id}','${mode}')"
            onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();ttOpenEntry('${e.id}','${mode}')}">
          <div class="tt-day-time">${x.period.start}<span>${x.period.end}</span></div>
          <div class="tt-day-info">
            <div class="tt-day-subject">${subj ? subj.icon + ' ' + ttEsc(subj.name) : ''}</div>
            <div class="tt-day-meta">${ttEsc(secondary)}${room ? ' · ' + ttEsc(room.name) : ''}</div>
          </div>
        </div>`;
      });
    }
    html += '</div>';
  });
  html += '</div>';
  return html;
}

/* Weekly summary: total periods and per-subject breakdown */
function ttRenderSummary(entries, mode) {
  if (!entries || !entries.length) return '';
  const bySubject = {};
  entries.forEach(e => { bySubject[e.subjectId] = (bySubject[e.subjectId] || 0) + 1; });
  const rows = Object.keys(bySubject)
    .sort((a, b) => bySubject[b] - bySubject[a])
    .map(sid => {
      const s = ttSubject(sid);
      const extra = mode === 'teacher'
        ? Array.from(new Set(entries.filter(e => e.subjectId === sid).map(e => {
            const c = ttClass(e.classId); return c ? c.name : '';
          }))).join(', ')
        : (() => {
            const tIds = Array.from(new Set(entries.filter(e => e.subjectId === sid).map(e => e.teacherId)));
            return tIds.map(id => ttTeacher(id) ? ttTeacher(id).name : '').join(', ');
          })();
      return `<div class="info-row"><span>${s ? s.icon + ' ' + ttEsc(s.name) : ttEsc(sid)}
        <div style="font-size:11px;color:var(--muted)">${ttEsc(extra)}</div></span>
        <span>${bySubject[sid]} ${t('periods/week')}</span></div>`;
    }).join('');
  return `<div class="card" style="margin-top:16px"><div class="card-header">
      <div class="card-title">${t('Weekly Summary')}</div>
      <span style="font-size:12px;color:var(--muted)">${entries.length} ${t('periods/week')}</span>
    </div><div class="card-body">${rows}</div></div>`;
}

/* Lesson detail — shows every attribute of a slot */
function ttOpenEntry(entryId, mode) {
  const e = TT_ENTRIES.find(x => x.id === entryId);
  if (!e) return;
  const subj = ttSubject(e.subjectId);
  const cls = ttClass(e.classId);
  const teacher = ttTeacher(e.teacherId);
  const room = ttRoom(e.roomId);
  const day = ttDay(e.dayId);
  const html = `
    <h3 style="margin-bottom:12px">${subj ? subj.icon + ' ' + ttEsc(subj.name) : ''}</h3>
    <div class="info-row"><span>${t('Class')}</span><span>${cls ? ttEsc(cls.name) : '—'}</span></div>
    <div class="info-row"><span>${t('Teacher')}</span><span>${teacher ? ttEsc(teacher.name) : '—'}</span></div>
    <div class="info-row"><span>${t('Room')}</span><span>${room ? ttEsc(room.name) : '—'}</span></div>
    <div class="info-row"><span>${t('Day')}</span><span>${day ? t(day.label) : '—'}</span></div>
    <div class="info-row"><span>${t('Time')}</span><span>${ttPeriodLabel(e.periodId)}</span></div>
    <div class="info-row"><span>${t('Academic Year')}</span><span>${ttEsc(TT_META.academicYear)} · ${ttEsc(TT_META.term)}</span></div>
    <button class="st-btn ghost" style="margin-top:16px" onclick="stCloseModal()">${t('Close')}</button>`;
  stOpenModal(html);
}

/* Print/export the currently displayed timetable */
function ttPrint() { window.print(); }

ttEnsureTimetable();
