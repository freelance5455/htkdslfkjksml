/* ════════════════════════════════════════════════════════════
   AUTHREN — TIMETABLES (shared module)

   One canonical timetable model used by every role, so a change made
   by the Head of Institution is the same timetable a student, guardian
   and teacher see. Roles differ only in which slice they are shown:

     Student  → their own class
     Guardian → their selected child's class
     Teacher  → their own teaching schedule
     Head     → any class, any teacher, plus the auto-generator

   Everything below is frontend state. Persisting a generated timetable
   is a BACKEND responsibility; the frontend holds the model, the
   constraints and the resulting states.
════════════════════════════════════════════════════════════ */

/* ─── Structure: days & periods ─── */
const TT_DAYS = [
  { id: 'mon', label: 'Monday',    short: 'Mon' },
  { id: 'tue', label: 'Tuesday',   short: 'Tue' },
  { id: 'wed', label: 'Wednesday', short: 'Wed' },
  { id: 'thu', label: 'Thursday',  short: 'Thu' },
  { id: 'fri', label: 'Friday',    short: 'Fri' },
  { id: 'sat', label: 'Saturday',  short: 'Sat' },
];

/* Typical Moroccan private-school day: morning block, lunch, afternoon
   block. Saturday is a morning-only day (handled by TT_SAT_PERIODS). */
const TT_PERIODS = [
  { id: 'p1', start: '08:00', end: '09:00' },
  { id: 'p2', start: '09:00', end: '10:00' },
  { id: 'br1', start: '10:00', end: '10:15', isBreak: true, label: 'Break' },
  { id: 'p3', start: '10:15', end: '11:15' },
  { id: 'p4', start: '11:15', end: '12:15' },
  { id: 'lunch', start: '12:15', end: '14:00', isBreak: true, label: 'Lunch' },
  { id: 'p5', start: '14:00', end: '15:00' },
  { id: 'p6', start: '15:00', end: '16:00' },
  { id: 'br2', start: '16:00', end: '16:15', isBreak: true, label: 'Break' },
  { id: 'p7', start: '16:15', end: '17:15' },
];

/* Teaching periods only (breaks excluded) */
const TT_TEACHING_PERIODS = TT_PERIODS.filter(p => !p.isBreak);
/* Saturday runs mornings only */
const TT_SAT_PERIOD_IDS = ['p1', 'p2', 'p3', 'p4'];

function ttIsTeachingSlot(dayId, periodId) {
  const p = TT_PERIODS.find(x => x.id === periodId);
  if (!p || p.isBreak) return false;
  if (dayId === 'sat') return TT_SAT_PERIOD_IDS.includes(periodId);
  return true;
}
function ttPeriod(periodId) { return TT_PERIODS.find(p => p.id === periodId) || null; }
function ttDay(dayId) { return TT_DAYS.find(d => d.id === dayId) || null; }
function ttPeriodLabel(periodId) {
  const p = ttPeriod(periodId);
  return p ? p.start + ' – ' + p.end : '';
}

/* ─── Reference data ─── */
const TT_SUBJECTS = [
  { id: 'math',  name: 'Mathematics',    icon: '🔢', color: '#3B82F6' },
  { id: 'phys',  name: 'Physics',        icon: '⚗️', color: '#8B5CF6' },
  { id: 'svt',   name: 'Life & Earth Sciences', icon: '🌱', color: '#10B981' },
  { id: 'ar',    name: 'Arabic',         icon: '📖', color: '#F59E0B' },
  { id: 'fr',    name: 'French',         icon: '🇫🇷', color: '#EF4444' },
  { id: 'en',    name: 'English',        icon: '🇬🇧', color: '#06B6D4' },
  { id: 'hist',  name: 'History & Geography', icon: '🏺', color: '#A16207' },
  { id: 'islam', name: 'Islamic Education', icon: '🕌', color: '#14B8A6' },
  { id: 'philo', name: 'Philosophy',     icon: '💭', color: '#6366F1' },
  { id: 'sport', name: 'Physical Education', icon: '⚽', color: '#84CC16' },
  { id: 'info',  name: 'Computer Science', icon: '💻', color: '#0EA5E9' },
];
function ttSubject(id) { return TT_SUBJECTS.find(s => s.id === id) || null; }

const TT_ROOMS = [
  { id: 'r101', name: 'Room 101', type: 'standard' },
  { id: 'r102', name: 'Room 102', type: 'standard' },
  { id: 'r103', name: 'Room 103', type: 'standard' },
  { id: 'r104', name: 'Room 104', type: 'standard' },
  { id: 'r105', name: 'Room 105', type: 'standard' },
  { id: 'lab1', name: 'Science Lab 1', type: 'lab' },
  { id: 'lab2', name: 'Science Lab 2', type: 'lab' },
  { id: 'itlab', name: 'Computer Lab', type: 'it' },
  { id: 'gym',  name: 'Gymnasium', type: 'sport' },
];
function ttRoom(id) { return TT_ROOMS.find(r => r.id === id) || null; }

/* Subjects that require a specialised room */
const TT_ROOM_REQUIREMENT = { phys: 'lab', svt: 'lab', info: 'it', sport: 'sport' };

const TT_TEACHERS = [
  { id: 't1',  name: 'Mr. Karim Bensalem', subjectIds: ['math', 'phys'] },
  { id: 't2',  name: 'Ms. Rachidi',  subjectIds: ['phys'] },
  { id: 't3',  name: 'Mr. Tahiri',   subjectIds: ['fr'] },
  { id: 't4',  name: 'Ms. Ouali',    subjectIds: ['ar'] },
  { id: 't5',  name: 'Mr. Fassi',    subjectIds: ['en'] },
  { id: 't6',  name: 'Ms. Bennis',   subjectIds: ['hist'] },
  { id: 't7',  name: 'Mr. Alaoui',   subjectIds: ['svt'] },
  { id: 't8',  name: 'Ms. Chraibi',  subjectIds: ['islam', 'philo'] },
  { id: 't9',  name: 'Mr. Idrissi',  subjectIds: ['sport'] },
  { id: 't10', name: 'Ms. Sabri',    subjectIds: ['info'] },
  { id: 't11', name: 'Mr. Kadiri',   subjectIds: ['math'] },
  { id: 't12', name: 'Ms. Alami',    subjectIds: ['fr', 'en'] },
];
function ttTeacher(id) { return TT_TEACHERS.find(t => t.id === id) || null; }
function ttTeachersForSubject(subjectId) {
  return TT_TEACHERS.filter(t => t.subjectIds.includes(subjectId));
}

/* Weekly period load per subject, per class. This is the requirement the
   generator has to satisfy exactly. */
const TT_CLASSES = [
  { id: 'g9a',  name: 'Grade 9 - A',  level: 'Grade 9',  homeroom: 'r101',
    load: { math:5, phys:3, svt:3, ar:4, fr:4, en:3, hist:3, islam:2, sport:2, info:1 } },
  { id: 'g9b',  name: 'Grade 9 - B',  level: 'Grade 9',  homeroom: 'r102',
    load: { math:5, phys:3, svt:3, ar:4, fr:4, en:3, hist:3, islam:2, sport:2, info:1 } },
  { id: 'g10a', name: 'Grade 10 - A', level: 'Grade 10', homeroom: 'r103',
    load: { math:6, phys:4, svt:3, ar:3, fr:4, en:3, hist:2, islam:2, philo:2, sport:2, info:1 } },
  { id: 'g10b', name: 'Grade 10 - B', level: 'Grade 10', homeroom: 'r104',
    load: { math:6, phys:4, svt:3, ar:3, fr:4, en:3, hist:2, islam:2, philo:2, sport:2, info:1 } },
  { id: 'g11a', name: 'Grade 11 - A', level: 'Grade 11', homeroom: 'r105',
    load: { math:6, phys:4, svt:4, ar:2, fr:3, en:3, hist:2, islam:1, philo:2, sport:2, info:1 } },
];
function ttClass(id) { return TT_CLASSES.find(c => c.id === id) || null; }
function ttClassByName(name) {
  if (!name) return null;
  const n = String(name).trim().toLowerCase();
  return TT_CLASSES.find(c => c.name.toLowerCase() === n) || null;
}

/* ─── Live timetable entries ───
   Each entry is one lesson in one slot:
   { id, classId, subjectId, teacherId, roomId, dayId, periodId } */
let TT_ENTRIES = [];
let TT_META = { generatedAt: null, academicYear: '2025-2026', term: 'Term 2' };

/* ─── Lookups ─── */
function ttEntriesForClass(classId) { return TT_ENTRIES.filter(e => e.classId === classId); }
function ttEntriesForTeacher(teacherId) { return TT_ENTRIES.filter(e => e.teacherId === teacherId); }
function ttEntryAt(entries, dayId, periodId) {
  return entries.find(e => e.dayId === dayId && e.periodId === periodId) || null;
}
function ttTeacherByName(name) {
  if (!name) return null;
  const n = String(name).trim().toLowerCase();
  return TT_TEACHERS.find(t => t.name.toLowerCase() === n) || null;
}

/* ════════════════════════════════════════════════════════════
   AUTO-GENERATOR

   Constraint-satisfaction with backtracking. Hard constraints, all of
   which are genuinely enforced (never silently violated):
     1. A class cannot be in two places at once.
     2. A teacher cannot be in two places at once.
     3. A room cannot host two classes at once.
     4. Lab/IT/sport subjects must use a room of the matching type.
     5. Each class gets exactly its required weekly periods per subject.
     6. No more than 2 consecutive periods of the same subject.
     7. A subject appears at most twice on the same day for a class.

   If the generator cannot satisfy everything, it reports the failure
   honestly rather than returning a partial timetable presented as valid.
════════════════════════════════════════════════════════════ */

function ttAllSlots() {
  const slots = [];
  TT_DAYS.forEach(d => {
    TT_TEACHING_PERIODS.forEach(p => {
      if (ttIsTeachingSlot(d.id, p.id)) slots.push({ dayId: d.id, periodId: p.id });
    });
  });
  return slots;
}

function ttCapacityReport() {
  const slotsPerClass = ttAllSlots().length;
  return TT_CLASSES.map(c => {
    const required = Object.values(c.load).reduce((a, b) => a + b, 0);
    return { classId: c.id, className: c.name, required, available: slotsPerClass, fits: required <= slotsPerClass };
  });
}

function ttRoomCandidates(subjectId, cls) {
  const req = TT_ROOM_REQUIREMENT[subjectId];
  if (req) return TT_ROOMS.filter(r => r.type === req);
  /* Non-specialised subjects prefer the class's homeroom. */
  const home = ttRoom(cls.homeroom);
  const others = TT_ROOMS.filter(r => r.type === 'standard' && r.id !== cls.homeroom);
  return home ? [home].concat(others) : others;
}

function ttGenerateTimetable(options) {
  const opts = options || {};
  const seedClasses = opts.classIds ? TT_CLASSES.filter(c => opts.classIds.includes(c.id)) : TT_CLASSES;

  /* Feasibility check before attempting to solve */
  const capacity = ttCapacityReport().filter(r => seedClasses.some(c => c.id === r.classId));
  const overloaded = capacity.filter(r => !r.fits);
  if (overloaded.length) {
    return {
      ok: false,
      reason: 'overloaded',
      message: 'These classes require more weekly periods than the school week has slots: '
        + overloaded.map(o => o.className + ' (' + o.required + '/' + o.available + ')').join(', '),
      entries: [],
    };
  }

  const slots = ttAllSlots();
  const classBusy = {};   // classId -> "day|period" -> true
  const teacherBusy = {}; // teacherId -> "day|period" -> true
  const roomBusy = {};    // roomId -> "day|period" -> true
  const result = [];
  let idCounter = 1;

  const key = (d, p) => d + '|' + p;

  /* Build the full list of lessons that must be placed, hardest first
     (specialised-room subjects and heavy loads are most constrained). */
  const lessons = [];
  seedClasses.forEach(cls => {
    Object.keys(cls.load).forEach(subjectId => {
      for (let i = 0; i < cls.load[subjectId]; i++) {
        lessons.push({ classId: cls.id, subjectId: subjectId });
      }
    });
  });
  lessons.sort((a, b) => {
    const aSpec = TT_ROOM_REQUIREMENT[a.subjectId] ? 0 : 1;
    const bSpec = TT_ROOM_REQUIREMENT[b.subjectId] ? 0 : 1;
    if (aSpec !== bSpec) return aSpec - bSpec;
    return a.subjectId.localeCompare(b.subjectId);
  });

  /* Deterministic shuffle so results are stable but well distributed */
  function ttSeededOrder(arr, seedStr) {
    let h = 2166136261;
    for (let i = 0; i < seedStr.length; i++) { h ^= seedStr.charCodeAt(i); h = Math.imul(h, 16777619); }
    return arr.slice().sort((a, b) => {
      const ha = Math.imul(h ^ (a.dayId + a.periodId).length, 2654435761) % 1000;
      const hb = Math.imul(h ^ (b.dayId + b.periodId).length, 2654435761) % 1000;
      return ha - hb;
    });
  }

  function sameSubjectOnDay(classId, dayId, subjectId) {
    return result.filter(e => e.classId === classId && e.dayId === dayId && e.subjectId === subjectId).length;
  }
  function consecutiveRun(classId, dayId, periodId, subjectId) {
    const order = TT_TEACHING_PERIODS.map(p => p.id).filter(pid => ttIsTeachingSlot(dayId, pid));
    const idx = order.indexOf(periodId);
    let run = 1;
    for (let i = idx - 1; i >= 0; i--) {
      const e = result.find(x => x.classId === classId && x.dayId === dayId && x.periodId === order[i]);
      if (e && e.subjectId === subjectId) run++; else break;
    }
    for (let i = idx + 1; i < order.length; i++) {
      const e = result.find(x => x.classId === classId && x.dayId === dayId && x.periodId === order[i]);
      if (e && e.subjectId === subjectId) run++; else break;
    }
    return run;
  }

  function place(index) {
    if (index >= lessons.length) return true;
    const lesson = lessons[index];
    const cls = ttClass(lesson.classId);
    const candidateTeachers = ttTeachersForSubject(lesson.subjectId);
    if (!candidateTeachers.length) return false;
    const rooms = ttRoomCandidates(lesson.subjectId, cls);
    const orderedSlots = ttSeededOrder(slots, lesson.classId + lesson.subjectId + index);

    for (let s = 0; s < orderedSlots.length; s++) {
      const slot = orderedSlots[s];
      const k = key(slot.dayId, slot.periodId);

      if (classBusy[lesson.classId] && classBusy[lesson.classId][k]) continue;
      if (sameSubjectOnDay(lesson.classId, slot.dayId, lesson.subjectId) >= 2) continue;

      for (let t = 0; t < candidateTeachers.length; t++) {
        const teacher = candidateTeachers[t];
        if (teacherBusy[teacher.id] && teacherBusy[teacher.id][k]) continue;

        for (let r = 0; r < rooms.length; r++) {
          const room = rooms[r];
          if (roomBusy[room.id] && roomBusy[room.id][k]) continue;

          /* Tentatively place */
          const entry = {
            id: 'tt' + (idCounter++),
            classId: lesson.classId, subjectId: lesson.subjectId,
            teacherId: teacher.id, roomId: room.id,
            dayId: slot.dayId, periodId: slot.periodId,
          };
          result.push(entry);
          if (consecutiveRun(lesson.classId, slot.dayId, slot.periodId, lesson.subjectId) > 2) {
            result.pop(); idCounter--; continue;
          }
          classBusy[lesson.classId] = classBusy[lesson.classId] || {}; classBusy[lesson.classId][k] = true;
          teacherBusy[teacher.id] = teacherBusy[teacher.id] || {}; teacherBusy[teacher.id][k] = true;
          roomBusy[room.id] = roomBusy[room.id] || {}; roomBusy[room.id][k] = true;

          if (place(index + 1)) return true;

          /* Backtrack */
          result.pop(); idCounter--;
          delete classBusy[lesson.classId][k];
          delete teacherBusy[teacher.id][k];
          delete roomBusy[room.id][k];
        }
      }
    }
    return false;
  }

  const solved = place(0);
  if (!solved) {
    return {
      ok: false,
      reason: 'unsatisfiable',
      message: 'Could not build a timetable that satisfies every constraint with the current teachers, rooms and subject loads. Try reducing a subject load, adding a teacher for an over-subscribed subject, or adding a specialised room.',
      entries: [],
    };
  }
  return { ok: true, entries: result, placed: result.length };
}

/* Validate an arbitrary entry set — used to prove a generated timetable
   is genuinely conflict-free rather than assuming it. */
function ttValidate(entries) {
  const problems = [];
  const seen = { class: {}, teacher: {}, room: {} };
  entries.forEach(e => {
    const k = e.dayId + '|' + e.periodId;
    [['class', e.classId], ['teacher', e.teacherId], ['room', e.roomId]].forEach(pair => {
      const kind = pair[0], id = pair[1];
      seen[kind][id] = seen[kind][id] || {};
      if (seen[kind][id][k]) {
        problems.push({ kind: kind, id: id, dayId: e.dayId, periodId: e.periodId });
      }
      seen[kind][id][k] = true;
    });
    if (!ttIsTeachingSlot(e.dayId, e.periodId)) {
      problems.push({ kind: 'slot', id: e.id, dayId: e.dayId, periodId: e.periodId });
    }
    const req = TT_ROOM_REQUIREMENT[e.subjectId];
    if (req) {
      const room = ttRoom(e.roomId);
      if (!room || room.type !== req) problems.push({ kind: 'room-type', id: e.id, dayId: e.dayId, periodId: e.periodId });
    }
    const teacher = ttTeacher(e.teacherId);
    if (!teacher || !teacher.subjectIds.includes(e.subjectId)) {
      problems.push({ kind: 'teacher-subject', id: e.id, dayId: e.dayId, periodId: e.periodId });
    }
  });
  /* Load completeness */
  TT_CLASSES.forEach(c => {
    if (!entries.some(e => e.classId === c.id)) return;
    Object.keys(c.load).forEach(sid => {
      const got = entries.filter(e => e.classId === c.id && e.subjectId === sid).length;
      if (got !== c.load[sid]) {
        problems.push({ kind: 'load', id: c.id + '/' + sid, expected: c.load[sid], got: got });
      }
    });
  });
  return { ok: problems.length === 0, problems: problems };
}

/* Build the default timetable on load so every role has something real
   to display immediately. */
function ttEnsureTimetable() {
  if (TT_ENTRIES.length) return;
  const res = ttGenerateTimetable();
  if (res.ok) {
    TT_ENTRIES = res.entries;
    TT_META.generatedAt = '2026-09-01';
  }
}

/* ════════════════════════════════════════════════════════════
   SHARED RENDERING
   `mode` decides what each cell emphasises:
     'class'   → subject, teacher, room   (student / guardian / head-by-class)
     'teacher' → subject, class, room     (teacher / head-by-teacher)
════════════════════════════════════════════════════════════ */

function ttEsc(str) {
  return String(str == null ? '' : str).replace(/[&<>"']/g, ch => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[ch]));
}

function ttCellHtml(entry, mode) {
  if (!entry) return '<div class="tt-cell tt-cell-free"></div>';
  const subj = ttSubject(entry.subjectId);
  const room = ttRoom(entry.roomId);
  const secondary = mode === 'teacher'
    ? (ttClass(entry.classId) ? ttClass(entry.classId).name : '')
    : (ttTeacher(entry.teacherId) ? ttTeacher(entry.teacherId).name : '');
  return `<div class="tt-cell" style="--tt-accent:${subj ? subj.color : '#888'}" role="button" tabindex="0"
      onclick="ttOpenEntry('${entry.id}','${mode}')"
      onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();ttOpenEntry('${entry.id}','${mode}')}">
    <div class="tt-cell-subject">${subj ? subj.icon + ' ' + ttEsc(subj.name) : ''}</div>
    <div class="tt-cell-meta">${ttEsc(secondary)}</div>
    <div class="tt-cell-room">${room ? ttEsc(room.name) : ''}</div>
  </div>`;
}

function ttRenderGrid(entries, mode) {
  if (!entries || !entries.length) {
    return `<div class="tt-empty">${t('No timetable has been published yet.')}</div>`;
  }
  let html = '<div class="tt-scroll"><table class="tt-grid"><thead><tr><th class="tt-time-head">' + t('Time') + '</th>';
  TT_DAYS.forEach(d => { html += '<th>' + t(d.label) + '</th>'; });
  html += '</tr></thead><tbody>';

  TT_PERIODS.forEach(p => {
    if (p.isBreak) {
      html += `<tr class="tt-break-row"><td class="tt-time">${p.start} – ${p.end}</td>
        <td colspan="${TT_DAYS.length}" class="tt-break-cell">${t(p.label)}</td></tr>`;
      return;
    }
    html += `<tr><td class="tt-time">${p.start}<span>${p.end}</span></td>`;
    TT_DAYS.forEach(d => {
      if (!ttIsTeachingSlot(d.id, p.id)) {
        html += '<td class="tt-closed"></td>';
        return;
      }
      html += '<td>' + ttCellHtml(ttEntryAt(entries, d.id, p.id), mode) + '</td>';
    });
    html += '</tr>';
  });
  html += '</tbody></table></div>';
  return html;
}

/* Weekly summary: total periods and per-subject breakdown */
function ttRenderSummary(entries, mode) {
  if (!entries || !entries.length) return '';
  const bySubject = {};
  entries.forEach(e => { bySubject[e.subjectId] = (bySubject[e.subjectId] || 0) + 1; });
  const rows = Object.keys(bySubject)
    .sort((a, b) => bySubject[b] - bySubject[a])
    .map(sid => {
      const s = ttSubject(sid);
      const extra = mode === 'teacher'
        ? Array.from(new Set(entries.filter(e => e.subjectId === sid).map(e => {
            const c = ttClass(e.classId); return c ? c.name : '';
          }))).join(', ')
        : (() => {
            const tIds = Array.from(new Set(entries.filter(e => e.subjectId === sid).map(e => e.teacherId)));
            return tIds.map(id => ttTeacher(id) ? ttTeacher(id).name : '').join(', ');
          })();
      return `<div class="info-row"><span>${s ? s.icon + ' ' + ttEsc(s.name) : ttEsc(sid)}
        <div style="font-size:11px;color:var(--muted)">${ttEsc(extra)}</div></span>
        <span>${bySubject[sid]} ${t('periods/week')}</span></div>`;
    }).join('');
  return `<div class="card" style="margin-top:16px"><div class="card-header">
      <div class="card-title">${t('Weekly Summary')}</div>
      <span style="font-size:12px;color:var(--muted)">${entries.length} ${t('periods/week')}</span>
    </div><div class="card-body">${rows}</div></div>`;
}

/* Lesson detail — shows every attribute of a slot */
function ttOpenEntry(entryId, mode) {
  const e = TT_ENTRIES.find(x => x.id === entryId);
  if (!e) return;
  const subj = ttSubject(e.subjectId);
  const cls = ttClass(e.classId);
  const teacher = ttTeacher(e.teacherId);
  const room = ttRoom(e.roomId);
  const day = ttDay(e.dayId);
  const html = `
    <h3 style="margin-bottom:12px">${subj ? subj.icon + ' ' + ttEsc(subj.name) : ''}</h3>
    <div class="info-row"><span>${t('Class')}</span><span>${cls ? ttEsc(cls.name) : '—'}</span></div>
    <div class="info-row"><span>${t('Teacher')}</span><span>${teacher ? ttEsc(teacher.name) : '—'}</span></div>
    <div class="info-row"><span>${t('Room')}</span><span>${room ? ttEsc(room.name) : '—'}</span></div>
    <div class="info-row"><span>${t('Day')}</span><span>${day ? t(day.label) : '—'}</span></div>
    <div class="info-row"><span>${t('Time')}</span><span>${ttPeriodLabel(e.periodId)}</span></div>
    <div class="info-row"><span>${t('Academic Year')}</span><span>${ttEsc(TT_META.academicYear)} · ${ttEsc(TT_META.term)}</span></div>
    <button class="st-btn ghost" style="margin-top:16px" onclick="stCloseModal()">${t('Close')}</button>`;
  stOpenModal(html);
}

/* Print/export the currently displayed timetable */
function ttPrint() { window.print(); }

ttEnsureTimetable();
