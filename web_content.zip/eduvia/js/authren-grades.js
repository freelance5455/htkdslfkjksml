/* ════════════════════════════════════════════════════════════
   AUTHREN — SHARED GRADES / ASSESSMENTS

   ONE assessment record set, following the exact pattern already
   proven for attendance (js/authren-attendance.js) and payments
   (js/authren-payments.js). The teacher's publish action is the ONLY
   write path; every role's view of a student's grade is a read over
   this same table — never a separately fabricated number.

   LIFECYCLE (per the correction brief): scores entered → locked
   (final, teacher can no longer edit) → PUBLISHED by the assigned
   teacher (decided here, for consistency with how homework already
   works in this same file — the teacher who owns the class publishes
   it themselves) → visible to that class's students and guardians.
   An assessment that is not published is invisible to students and
   guardians, full stop, even if every score has been entered.

   HONEST SCOPE NOTE — same as attendance: the Teacher role's roster,
   the Student role's own identity, and the Guardian role's children
   are still three separately-authored casts that do not, in general,
   refer to the same people. The one genuine exception, again, is
   Youssef Amrani (S12345678) in Mr. Bensalem's real Grade 10-A Physics
   class — the one subject where a real teacher-to-student connection
   exists. His other five subjects (Math, French, Arabic, English,
   History) have no connected teacher character in this build and keep
   their existing demo numbers until that connection exists too.
════════════════════════════════════════════════════════════ */

const AUTHREN_ASSESSMENTS = {
  records: [], // { id, classId, subjectId, teacherId, title, date, maxScore, status, scores:{studentId:score} }
};

/* status: 'draft' | 'scores-entered' | 'locked' | 'published' */
function authrenAssessmentsForStudent(studentId) {
  return AUTHREN_ASSESSMENTS.records.filter(r => r.status === 'published' && r.scores[studentId] != null);
}

/* The ONLY write path — called when a teacher publishes an exam whose
   scores are locked. Refuses to publish anything not locked first, and
   refuses a second, redundant publish. Always audited with the real
   actor, matching the attendance and payment ledgers. */
function authrenPublishAssessment(examSnapshot, actor) {
  const a = actor || {};
  if (!examSnapshot.locked) {
    return { ok: false, message: 'Scores must be locked before an assessment can be published.' };
  }
  const existing = AUTHREN_ASSESSMENTS.records.find(r => r.id === examSnapshot.id);
  const record = {
    id: examSnapshot.id,
    classId: examSnapshot.classId,
    subjectId: examSnapshot.subjectId,
    teacherId: a.id || examSnapshot.teacherId || null,
    title: examSnapshot.title,
    date: examSnapshot.date,
    maxScore: examSnapshot.maxScore,
    status: 'published',
    scores: Object.assign({}, examSnapshot.scores),
    publishedAt: (typeof AUTHREN_NOW !== 'undefined' ? AUTHREN_NOW.toISOString() : null),
  };
  if (existing) Object.assign(existing, record);
  else AUTHREN_ASSESSMENTS.records.push(record);

  if (typeof authrenLogAudit === 'function') {
    authrenLogAudit(a.role || 'teacher', a.id, 'Assessment Published', 'Assessment',
      examSnapshot.title, '', Object.keys(examSnapshot.scores).length + ' scores');
  }
  return { ok: true, record: existing || record };
}

function authrenUnpublishAssessment(examId, actor) {
  const a = actor || {};
  const rec = AUTHREN_ASSESSMENTS.records.find(r => r.id === examId);
  if (!rec) return { ok: false, message: 'Assessment was never published.' };
  rec.status = 'unpublished';
  if (typeof authrenLogAudit === 'function') {
    authrenLogAudit(a.role || 'teacher', a.id, 'Assessment Unpublished', 'Assessment', rec.title, 'published', 'unpublished');
  }
  return { ok: true, record: rec };
}

/* ── Derived, never stored ── */
function authrenSubjectAverage(studentId, subjectId) {
  const rows = authrenAssessmentsForStudent(studentId).filter(r => r.subjectId === subjectId);
  if (!rows.length) return null;
  const pct = rows.map(r => (r.scores[studentId] / r.maxScore) * 20);
  return Math.round((pct.reduce((a, b) => a + b, 0) / pct.length) * 10) / 10;
}
function authrenLatestScore(studentId, subjectId) {
  const rows = authrenAssessmentsForStudent(studentId).filter(r => r.subjectId === subjectId).sort((a, b) => b.date.localeCompare(a.date));
  return rows[0] || null;
}

/* Seed Youssef's one real, connected assessment: the Physics "Forces
   Unit Test" his real teacher, Mr. Bensalem, already had in progress
   (ex4 in TEACHER_DATA.exams). Published here exactly as the teacher's
   own publish action would do it — proving the lifecycle, not
   bypassing it. */
(function seedYoussefAssessment() {
  authrenPublishAssessment(
    {
      id: 'ex4', classId: 'cl-g10a', subjectId: 'phys', teacherId: 'p-bensalem-karim',
      title: 'Forces Unit Test', date: '2026-02-25', maxScore: 20,
      locked: true, scores: { 'st16': 14, 'st17': 13.5, 'S12345678': 15 },
    },
    { role: 'teacher', id: 'p-bensalem-karim' }
  );
})();
