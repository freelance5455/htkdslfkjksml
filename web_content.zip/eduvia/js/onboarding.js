/* ════════════════════════════════
   PHASE 1 — GET STARTED & ONBOARDING
════════════════════════════════ */

/* ════════════════════════════════
   AUTHREN PRICING CONFIGURATION
   Single source of truth for all pricing. Nothing below should be
   hard-coded into UI elements — read it through the helper functions.

   Structured as a regional price book so additional regions/currencies
   can be added later without touching UI code (see PREPARED-FOR-LATER
   notes). Morocco is the only live region today.
════════════════════════════════ */

const AUTHREN_PRICE_BOOKS = {
  MA: {
    region: 'MA',
    currency: 'MAD',
    currencyLabel: 'MAD',
    /* Dimension 2 — student bands. `prices` keyed by plan (Dimension 1). */
    studentBands: [
      { id: 'b100',  label: 'Up to 100 students',      labelShort: '≤ 100',       max: 100,  prices: { START: 249,  GROWTH: 399,  COMMAND: 549,  ELITE: 749  } },
      { id: 'b250',  label: '101 – 250 students',      labelShort: '101–250',     max: 250,  prices: { START: 399,  GROWTH: 599,  COMMAND: 849,  ELITE: 1149 } },
      { id: 'b450',  label: '251 – 450 students',      labelShort: '251–450',     max: 450,  prices: { START: 599,  GROWTH: 899,  COMMAND: 1249, ELITE: 1649 } },
      { id: 'b700',  label: '451 – 700 students',      labelShort: '451–700',     max: 700,  prices: { START: 849,  GROWTH: 1249, COMMAND: 1749, ELITE: 2299 } },
      { id: 'b1000', label: '701 – 1,000 students',    labelShort: '701–1,000',   max: 1000, prices: { START: 1099, GROWTH: 1599, COMMAND: 2249, ELITE: 2999 } },
      { id: 'bmax',  label: 'More than 1,000 students', labelShort: '1,000+',     max: null, custom: true, prices: null },
    ],
    /* Small-growth add-on so a school slightly over its band is not forced
       into a much more expensive tier. */
    overagePack: { students: 50, pricePerMonth: 99 },
  },
  /* PREPARED FOR LATER: additional regions (EU, US, GCC…) get their own
     price book here. Regional pricing is deliberately NOT a currency
     conversion of the MA book. Not built now. */
};

const AUTHREN_PRICING = {
  activeRegion: 'MA',
  popularPlan: 'GROWTH',
  planOrder: ['START', 'GROWTH', 'COMMAND', 'ELITE'],
  billingCycles: {
    monthly: { id: 'monthly', label: 'Monthly',  months: 12, paidMonths: 12 },
    annual:  { id: 'annual',  label: 'Annual',   months: 12, paidMonths: 10, freeMonths: 2 },
  },
  trial: { days: 30, creditCardRequired: false },
  setupIncluded: true,
  minimumContract: false,
};

function authrenPriceBook() {
  return AUTHREN_PRICE_BOOKS[AUTHREN_PRICING.activeRegion];
}
function authrenBands() {
  return authrenPriceBook().studentBands;
}
function authrenGetBand(bandId) {
  return authrenBands().find(b => b.id === bandId) || authrenBands()[0];
}
function authrenCurrency() {
  return authrenPriceBook().currencyLabel;
}
function authrenOveragePack() {
  return authrenPriceBook().overagePack;
}

/* Returns the resolved price for a plan at a given band and billing cycle.
   { custom: true } means "contact sales" — never render it as a fixed price. */
function authrenPlanPrice(planKey, bandId, cycleId) {
  const band = authrenGetBand(bandId);
  if (band.custom || !band.prices) return { custom: true };
  const monthly = band.prices[planKey];
  if (monthly == null) return { custom: true };
  const cycle = AUTHREN_PRICING.billingCycles[cycleId] || AUTHREN_PRICING.billingCycles.monthly;
  if (cycle.id === 'annual') {
    const annualTotal = monthly * cycle.paidMonths;
    return {
      custom: false,
      cycle: 'annual',
      monthlyListPrice: monthly,
      perMonth: Math.round(annualTotal / cycle.months),
      annualTotal: annualTotal,
      freeMonths: cycle.freeMonths,
      savings: monthly * cycle.months - annualTotal,
    };
  }
  return { custom: false, cycle: 'monthly', monthlyListPrice: monthly, perMonth: monthly, dueToday: monthly };
}

/* Amount charged at checkout for the selected cycle. */
function authrenDueToday(planKey, bandId, cycleId) {
  const p = authrenPlanPrice(planKey, bandId, cycleId);
  if (p.custom) return null;
  return p.cycle === 'annual' ? p.annualTotal : p.perMonth;
}

const PLAN_DATA = {
  START:  { name: 'AUTHREN START' },
  GROWTH: { name: 'AUTHREN GROWTH' },
  COMMAND:{ name: 'AUTHREN COMMAND' },
  ELITE:  { name: 'AUTHREN ELITE' },
};


const COUNTRIES = [["AF", "Afghanistan"], ["AL", "Albania"], ["DZ", "Algeria"], ["AD", "Andorra"], ["AO", "Angola"], ["AG", "Antigua and Barbuda"], ["AR", "Argentina"], ["AM", "Armenia"], ["AU", "Australia"], ["AT", "Austria"], ["AZ", "Azerbaijan"], ["BS", "Bahamas"], ["BH", "Bahrain"], ["BD", "Bangladesh"], ["BB", "Barbados"], ["BY", "Belarus"], ["BE", "Belgium"], ["BZ", "Belize"], ["BJ", "Benin"], ["BT", "Bhutan"], ["BO", "Bolivia"], ["BA", "Bosnia and Herzegovina"], ["BW", "Botswana"], ["BR", "Brazil"], ["BN", "Brunei"], ["BG", "Bulgaria"], ["BF", "Burkina Faso"], ["BI", "Burundi"], ["CV", "Cabo Verde"], ["KH", "Cambodia"], ["CM", "Cameroon"], ["CA", "Canada"], ["CF", "Central African Republic"], ["TD", "Chad"], ["CL", "Chile"], ["CN", "China"], ["CO", "Colombia"], ["KM", "Comoros"], ["CG", "Congo"], ["CD", "Congo (DRC)"], ["CR", "Costa Rica"], ["CI", "Côte d'Ivoire"], ["HR", "Croatia"], ["CU", "Cuba"], ["CY", "Cyprus"], ["CZ", "Czechia"], ["DK", "Denmark"], ["DJ", "Djibouti"], ["DM", "Dominica"], ["DO", "Dominican Republic"], ["EC", "Ecuador"], ["EG", "Egypt"], ["SV", "El Salvador"], ["GQ", "Equatorial Guinea"], ["ER", "Eritrea"], ["EE", "Estonia"], ["SZ", "Eswatini"], ["ET", "Ethiopia"], ["FJ", "Fiji"], ["FI", "Finland"], ["FR", "France"], ["GA", "Gabon"], ["GM", "Gambia"], ["GE", "Georgia"], ["DE", "Germany"], ["GH", "Ghana"], ["GR", "Greece"], ["GD", "Grenada"], ["GT", "Guatemala"], ["GN", "Guinea"], ["GW", "Guinea-Bissau"], ["GY", "Guyana"], ["HT", "Haiti"], ["HN", "Honduras"], ["HU", "Hungary"], ["IS", "Iceland"], ["IN", "India"], ["ID", "Indonesia"], ["IR", "Iran"], ["IQ", "Iraq"], ["IE", "Ireland"], ["IL", "Israel"], ["IT", "Italy"], ["JM", "Jamaica"], ["JP", "Japan"], ["JO", "Jordan"], ["KZ", "Kazakhstan"], ["KE", "Kenya"], ["KI", "Kiribati"], ["KP", "Korea (North)"], ["KR", "Korea (South)"], ["KW", "Kuwait"], ["KG", "Kyrgyzstan"], ["LA", "Laos"], ["LV", "Latvia"], ["LB", "Lebanon"], ["LS", "Lesotho"], ["LR", "Liberia"], ["LY", "Libya"], ["LI", "Liechtenstein"], ["LT", "Lithuania"], ["LU", "Luxembourg"], ["MG", "Madagascar"], ["MW", "Malawi"], ["MY", "Malaysia"], ["MV", "Maldives"], ["ML", "Mali"], ["MT", "Malta"], ["MH", "Marshall Islands"], ["MR", "Mauritania"], ["MU", "Mauritius"], ["MX", "Mexico"], ["FM", "Micronesia"], ["MD", "Moldova"], ["MC", "Monaco"], ["MN", "Mongolia"], ["ME", "Montenegro"], ["MA", "Morocco"], ["MZ", "Mozambique"], ["MM", "Myanmar"], ["NA", "Namibia"], ["NR", "Nauru"], ["NP", "Nepal"], ["NL", "Netherlands"], ["NZ", "New Zealand"], ["NI", "Nicaragua"], ["NE", "Niger"], ["NG", "Nigeria"], ["MK", "North Macedonia"], ["NO", "Norway"], ["OM", "Oman"], ["PK", "Pakistan"], ["PW", "Palau"], ["PS", "Palestine"], ["PA", "Panama"], ["PG", "Papua New Guinea"], ["PY", "Paraguay"], ["PE", "Peru"], ["PH", "Philippines"], ["PL", "Poland"], ["PT", "Portugal"], ["QA", "Qatar"], ["RO", "Romania"], ["RU", "Russia"], ["RW", "Rwanda"], ["KN", "Saint Kitts and Nevis"], ["LC", "Saint Lucia"], ["VC", "Saint Vincent and the Grenadines"], ["WS", "Samoa"], ["SM", "San Marino"], ["ST", "São Tomé and Príncipe"], ["SA", "Saudi Arabia"], ["SN", "Senegal"], ["RS", "Serbia"], ["SC", "Seychelles"], ["SL", "Sierra Leone"], ["SG", "Singapore"], ["SK", "Slovakia"], ["SI", "Slovenia"], ["SB", "Solomon Islands"], ["SO", "Somalia"], ["ZA", "South Africa"], ["SS", "South Sudan"], ["ES", "Spain"], ["LK", "Sri Lanka"], ["SD", "Sudan"], ["SR", "Suriname"], ["SE", "Sweden"], ["CH", "Switzerland"], ["SY", "Syria"], ["TW", "Taiwan"], ["TJ", "Tajikistan"], ["TZ", "Tanzania"], ["TH", "Thailand"], ["TL", "Timor-Leste"], ["TG", "Togo"], ["TO", "Tonga"], ["TT", "Trinidad and Tobago"], ["TN", "Tunisia"], ["TR", "Turkey"], ["TM", "Turkmenistan"], ["TV", "Tuvalu"], ["UG", "Uganda"], ["UA", "Ukraine"], ["AE", "United Arab Emirates"], ["GB", "United Kingdom"], ["US", "United States"], ["UY", "Uruguay"], ["UZ", "Uzbekistan"], ["VU", "Vanuatu"], ["VA", "Vatican City"], ["VE", "Venezuela"], ["VN", "Vietnam"], ["YE", "Yemen"], ["ZM", "Zambia"], ["ZW", "Zimbabwe"]];

let selectedPlan = null;
let selectedBand = 'b100';
let selectedCycle = 'monthly';
let registrationData = null;
let resendCooldown = 0;

/* ─── PLANS SCREEN — DYNAMIC PRICING ─── */
function setStudentBand(bandId) {
  selectedBand = bandId;
  saveOnboardingState();
  renderPlanPricing();
}

function setBillingCycle(cycleId) {
  selectedCycle = cycleId;
  saveOnboardingState();
  renderPlanPricing();
}

function renderPlanPricing() {
  const band = authrenGetBand(selectedBand);
  const cur = authrenCurrency();
  const isAnnual = selectedCycle === 'annual';

  /* Billing toggle state */
  document.querySelectorAll('.billing-toggle-btn').forEach(b => {
    b.classList.toggle('active', b.dataset.cycle === selectedCycle);
  });
  /* Band selector state */
  const bandSelect = document.getElementById('student-band-select');
  if (bandSelect && bandSelect.value !== selectedBand) bandSelect.value = selectedBand;

  AUTHREN_PRICING.planOrder.forEach(planKey => {
    const priceEl = document.getElementById('plan-price-' + planKey);
    const noteEl = document.getElementById('plan-price-note-' + planKey);
    const btnEl = document.getElementById('plan-choose-' + planKey);
    if (!priceEl) return;

    const p = authrenPlanPrice(planKey, selectedBand, selectedCycle);

    if (p.custom) {
      priceEl.innerHTML = '<span class="plan-price-custom">' + t('Contact Sales') + '</span>';
      if (noteEl) noteEl.textContent = t('Custom pricing for large institutions.');
      if (btnEl) {
        btnEl.textContent = t('Contact Sales');
        btnEl.setAttribute('data-custom', 'true');
      }
      return;
    }

    priceEl.innerHTML = p.perMonth + ' <span>' + cur + ' / ' + t('month') + '</span>';
    if (noteEl) {
      noteEl.textContent = isAnnual
        ? t('Billed annually') + ' — ' + p.annualTotal + ' ' + cur + ' · ' + p.freeMonths + ' ' + t('months free')
        : t('Billed monthly. Cancel anytime.');
    }
    if (btnEl) {
      btnEl.textContent = t('Choose this plan');
      btnEl.removeAttribute('data-custom');
    }
  });

  /* Overage pack note */
  const packEl = document.getElementById('overage-pack-note');
  if (packEl) {
    const pack = authrenOveragePack();
    packEl.textContent = t('Slightly over your band? Add a') + ' +' + pack.students + ' '
      + t('student pack for') + ' ' + pack.pricePerMonth + ' ' + cur + '/' + t('month')
      + ' ' + t('instead of moving up a full tier.');
  }
}


function populateStudentBandSelect() {
  const sel = document.getElementById('student-band-select');
  if (!sel) return;
  sel.innerHTML = authrenBands()
    .map(b => '<option value="' + b.id + '">' + t(b.label) + '</option>')
    .join('');
  sel.value = selectedBand;
}

function initPricingUI() {
  populateStudentBandSelect();
  renderPlanPricing();
}

function initPhase1() {
  // Restore state from localStorage if exists
  const saved = localStorage.getItem('authren_onboarding');
  if (saved) {
    try {
      const state = JSON.parse(saved);
      if (state.plan) selectedPlan = state.plan;
      if (state.band) selectedBand = state.band;
      if (state.cycle) selectedCycle = state.cycle;
      if (state.registration) registrationData = state.registration;
      if (state.accountCreated) {
        /* J4 — the funnel is finished. Do not resurrect a stale
           confirmation screen on a later visit; clear it and land on the
           landing page. */
        clearOnboardingState();
        return;
      }
      if (state.verified && !state.accountCreated) {
        /* The password is intentionally not persisted (J3), so a resumed
           funnel always returns to the password step. */
        showScreen('password');
        return;
      }
      if (state.registration && !state.verified) {
        if (registrationData && registrationData.type) {
          showScreen('institution-type');
          fillInstitutionTypeFromData();
        } else {
          showScreen('register');
          if (registrationData) fillRegisterFormFromData();
        }
        return;
      }
    } catch(e) {}
  }
}

function saveOnboardingState() {
  const state = {};
  if (selectedPlan) state.plan = selectedPlan;
  state.band = selectedBand;
  state.cycle = selectedCycle;
  if (registrationData) {
    /* J3 — the password is held in memory for this session only and is
       never written to localStorage, where it previously survived an
       abandoned funnel indefinitely. */
    const { pass, ...safeRegistration } = registrationData;
    state.registration = safeRegistration;
  }
  const prev = JSON.parse(localStorage.getItem('authren_onboarding') || '{}');
  state.verified = !!prev.verified;
  state.accountCreated = !!prev.accountCreated;
  localStorage.setItem('authren_onboarding', JSON.stringify(state));
}

function clearOnboardingState() {
  localStorage.removeItem('authren_onboarding');
  selectedPlan = null;
  registrationData = null;
}

/* ─── GET STARTED ─── */
function goGetStarted() {
  showScreen('plans');
  initPricingUI();
}

/* ─── FEATURE PAGES ─── */
function openFeatures(plan) {
  showScreen('features-' + plan);
}

let openFeatureId = null;
function toggleFeatureExplain(uid) {
  const item = document.getElementById('item-' + uid);
  if (!item) return;
  const isOpen = item.classList.contains('open');
  if (openFeatureId && openFeatureId !== uid) {
    const prev = document.getElementById('item-' + openFeatureId);
    if (prev) prev.classList.remove('open');
  }
  if (isOpen) {
    item.classList.remove('open');
    openFeatureId = null;
  } else {
    item.classList.add('open');
    openFeatureId = uid;
  }
}

function switchFeaturesTab(plan, category, btn) {
  const container = document.getElementById('screen-features-' + plan);
  container.querySelectorAll('.features-tab').forEach(t => t.classList.remove('active'));
  container.querySelectorAll('.features-section').forEach(s => s.classList.remove('active'));
  btn.classList.add('active');
  document.getElementById('features-' + plan + '-' + category).classList.add('active');
}

/* ─── PLAN SELECTION ─── */
function choosePlan(plan) {
  const price = authrenPlanPrice(plan, selectedBand, selectedCycle);
  /* Above the top band, plans are custom-quoted — route to sales instead of
     pushing the customer into a checkout with no published price. */
  if (price.custom) { openContactSales(plan); return; }
  selectedPlan = plan;
  saveOnboardingState();
  showScreen('register');
  updateRegisterPlanBadge();
  document.getElementById('reg-err').style.display = 'none';
}

function openContactSales(plan) {
  const band = authrenGetBand(selectedBand);
  const subject = encodeURIComponent('Authren — Custom pricing request (' + (PLAN_DATA[plan] ? PLAN_DATA[plan].name : '') + ')');
  const body = encodeURIComponent(
    'Hello Authren team,\n\nWe would like a custom quote.\n\nPlan of interest: ' +
    (PLAN_DATA[plan] ? PLAN_DATA[plan].name : '') +
    '\nApproximate number of students: ' + band.label +
    '\nInstitution name: \nCity: \nContact person: \n\nThank you.'
  );
  window.location.href = 'mailto:hello@authren.com?subject=' + subject + '&body=' + body;
}

function planPriceLabel(plan, bandId, cycleId) {
  const p = authrenPlanPrice(plan, bandId, cycleId);
  const cur = authrenCurrency();
  if (p.custom) return t('Custom pricing');
  if (p.cycle === 'annual') return p.perMonth + ' ' + cur + ' / ' + t('month') + ' — ' + t('billed annually');
  return p.perMonth + ' ' + cur + ' / ' + t('month');
}

function updateRegisterPlanBadge() {
  const badge = document.getElementById('register-plan-badge');
  const p = PLAN_DATA[selectedPlan];
  if (badge && p) {
    badge.textContent = p.name + ' — ' + planPriceLabel(selectedPlan, selectedBand, selectedCycle);
  }
}

/* ─── COUNTRY SEARCHABLE SELECT ─── */
function flagEmoji(code) {
  if (!code || code.length !== 2) return '';
  const base = 127397;
  return String.fromCodePoint(...code.toUpperCase().split('').map(c => c.charCodeAt(0) + base));
}

function renderCountryDropdown(filterText) {
  const dd = document.getElementById('country-dropdown');
  if (!dd) return;
  const q = (filterText || '').trim().toLowerCase();
  const matches = q
    ? COUNTRIES.filter(c => c[1].toLowerCase().includes(q))
    : COUNTRIES;
  if (matches.length === 0) {
    dd.innerHTML = '<div class="country-empty">' + t('No countries found.') + '</div>';
  } else {
    dd.innerHTML = matches.slice(0, 60).map(c =>
      '<div class="country-option" onclick="selectCountry(\'' + c[0] + '\', \'' + c[1].replace(/'/g, "\\'") + '\')">' +
      '<span class="country-flag">' + flagEmoji(c[0]) + '</span><span>' + c[1] + '</span></div>'
    ).join('');
  }
}

function filterCountries() {
  const input = document.getElementById('reg-country-search');
  showCountryDropdown();
  renderCountryDropdown(input.value);
  document.getElementById('reg-country').value = '';
}

function showCountryDropdown() {
  renderCountryDropdown(document.getElementById('reg-country-search').value);
  document.getElementById('country-dropdown').classList.add('open');
}

function selectCountry(code, name) {
  document.getElementById('reg-country').value = code;
  document.getElementById('reg-country-search').value = name;
  document.getElementById('country-dropdown').classList.remove('open');
}

document.addEventListener('click', function(e) {
  const wrap = document.getElementById('country-select-wrap');
  if (wrap && !wrap.contains(e.target)) {
    const dd = document.getElementById('country-dropdown');
    if (dd) dd.classList.remove('open');
  }
});

/* ─── EMAIL TYPE ─── */

function getSelectedEmailType() {
  const el = document.querySelector('input[name="email-type"]:checked');
  return el ? el.value : 'personal';
}

/* ─── INSTITUTION TYPE (COUNTRY-DEPENDENT) ─── */
const BAC_COUNTRY_CODES = ['MA', 'DZ', 'TN', 'FR', 'SN', 'CI', 'CM', 'LB'];

const INSTITUTION_TYPES_BAC = [
  { value: 'primary', label: 'Primary School' },
  { value: 'middle', label: 'Middle School / College' },
  { value: 'high', label: 'High School' },
  { value: 'middle_high', label: 'Combined Middle & High School' },
  { value: 'bac_track', label: 'School — 7th Grade to 2nd Baccalaureate' },
  { value: 'university', label: 'Private University / Higher Education' },
  { value: 'academy', label: 'Private Academy / Training Institution' },
  { value: 'other', label: 'Other Private Educational Institution' },
];

const INSTITUTION_TYPES_STANDARD = [
  { value: 'primary', label: 'Primary School' },
  { value: 'middle', label: 'Middle School / College' },
  { value: 'high', label: 'High School' },
  { value: 'middle_high', label: 'Combined Middle & High School' },
  { value: 'secondary', label: 'Secondary School' },
  { value: 'university', label: 'Private University / Higher Education' },
  { value: 'academy', label: 'Private Academy / Training Institution' },
  { value: 'other', label: 'Other Private Educational Institution' },
];

/* ────────────────────────────────
   J5 — THE INSTITUTION TYPE MUST DRIVE BEHAVIOUR
   The type was collected at signup and then read by nothing. These
   helpers give the rest of the product one place to ask what the chosen
   type implies. Level sets and term vocabulary are consumed by the
   academic screens; guardiansRequired is consumed wherever a student
   record is created.
──────────────────────────────── */
const AUTHREN_INSTITUTION_TYPE_RULES = {
  primary:     { levels: ['Grade 1','Grade 2','Grade 3','Grade 4','Grade 5','Grade 6'],
                 terms: ['Term 1','Term 2','Term 3'], guardiansRequired: true },
  middle:      { levels: ['Grade 7','Grade 8','Grade 9'],
                 terms: ['Term 1','Term 2'], guardiansRequired: true },
  high:        { levels: ['Grade 10','Grade 11','Grade 12'],
                 terms: ['Term 1','Term 2'], guardiansRequired: true },
  middle_high: { levels: ['Grade 7','Grade 8','Grade 9','Grade 10','Grade 11','Grade 12'],
                 terms: ['Term 1','Term 2'], guardiansRequired: true },
  bac_track:   { levels: ['Grade 7','Grade 8','Grade 9','Tronc Commun','1st Bac','2nd Bac'],
                 terms: ['Term 1','Term 2'], guardiansRequired: true },
  secondary:   { levels: ['Year 7','Year 8','Year 9','Year 10','Year 11'],
                 terms: ['Term 1','Term 2','Term 3'], guardiansRequired: true },
  university:  { levels: ['Year 1','Year 2','Year 3','Year 4','Year 5'],
                 terms: ['Semester 1','Semester 2'], guardiansRequired: false },
  academy:     { levels: ['Level 1','Level 2','Level 3'],
                 terms: ['Session 1','Session 2'], guardiansRequired: false },
  other:       { levels: ['Level 1','Level 2','Level 3'],
                 terms: ['Term 1','Term 2'], guardiansRequired: true },
};

/* The institution's chosen type, persisted across the funnel. */
function authrenInstitutionType() {
  if (registrationData && registrationData.type) return registrationData.type;
  try {
    const st = JSON.parse(localStorage.getItem('authren_onboarding') || '{}');
    if (st.registration && st.registration.type) return st.registration.type;
  } catch (e) {}
  return 'bac_track';
}
function authrenTypeRules(type) {
  return AUTHREN_INSTITUTION_TYPE_RULES[type || authrenInstitutionType()]
      || AUTHREN_INSTITUTION_TYPE_RULES.bac_track;
}
function authrenLevelsForType(type)  { return authrenTypeRules(type).levels.slice(); }
function authrenTermsForType(type)   { return authrenTypeRules(type).terms.slice(); }
/* A university or training academy enrols adults — a guardian link must be
   optional there, not mandatory. */
function authrenGuardiansRequired(type) { return authrenTypeRules(type).guardiansRequired; }

function getInstitutionTypeOptions(countryCode) {
  return BAC_COUNTRY_CODES.includes(countryCode) ? INSTITUTION_TYPES_BAC : INSTITUTION_TYPES_STANDARD;
}

function populateInstitutionTypeSelect() {
  const select = document.getElementById('reg-type-select');
  const options = getInstitutionTypeOptions(registrationData ? registrationData.country : '');
  select.innerHTML = '<option value="" data-i18n="Select type">' + t('Select type') + '</option>' +
    options.map(o => '<option value="' + o.value + '" data-i18n="' + o.label + '">' + t(o.label) + '</option>').join('');

  const badge = document.getElementById('institution-type-country-badge');
  if (badge && registrationData && registrationData.country) {
    const c = COUNTRIES.find(c => c[0] === registrationData.country);
    badge.textContent = c ? (t('Country') + ': ' + c[1]) : '';
  }
}

function showInstitutionTypeScreen() {
  showScreen('institution-type');
  populateInstitutionTypeSelect();
  document.getElementById('reg-type-select').value = (registrationData && registrationData.type) || '';
  document.getElementById('reg-type-err').style.display = 'none';
}

function fillInstitutionTypeFromData() {
  populateInstitutionTypeSelect();
  if (registrationData && registrationData.type) {
    document.getElementById('reg-type-select').value = registrationData.type;
  }
}

function goBackToRegisterInfo() {
  showScreen('register');
  fillRegisterFormFromData();
  document.getElementById('reg-err').style.display = 'none';
}

function submitInstitutionType() {
  const type = document.getElementById('reg-type-select').value;
  const err = document.getElementById('reg-type-err');
  if (!type) { err.innerHTML = aIcon('x-circle') + ' ' + t('Please select an institution type.'); err.style.display = 'block'; return; }
  err.style.display = 'none';
  registrationData.type = type;
  saveOnboardingState();
  showVerifyScreen();
}

/* ─── INSTITUTION INFO (STEP 1) ─── */
function fillRegisterFormFromData() {
  if (!registrationData) return;
  document.getElementById('reg-name').value = registrationData.name || '';
  document.getElementById('reg-city').value = registrationData.city || '';
  document.getElementById('reg-email').value = registrationData.email || '';
  if (registrationData.country) {
    const c = COUNTRIES.find(c => c[0] === registrationData.country);
    if (c) selectCountry(c[0], c[1]);
  }
  if (registrationData.emailType) {
    const radio = document.querySelector('input[name="email-type"][value="' + registrationData.emailType + '"]');
    if (radio) radio.checked = true;
  }
}

function submitInstitutionInfo() {
  const name = document.getElementById('reg-name').value.trim();
  const country = document.getElementById('reg-country').value;
  const city = document.getElementById('reg-city').value.trim();
  const emailType = getSelectedEmailType();
  const email = document.getElementById('reg-email').value.trim();
  const err = document.getElementById('reg-err');

  if (!name) { err.innerHTML = aIcon('x-circle') + ' ' + t('Institution name is required.'); err.style.display = 'block'; return; }
  if (!country) { err.innerHTML = aIcon('x-circle') + ' ' + t('Please select a country.'); err.style.display = 'block'; return; }
  if (!city) { err.innerHTML = aIcon('x-circle') + ' ' + t('City is required.'); err.style.display = 'block'; return; }
  if (!email) { err.innerHTML = aIcon('x-circle') + ' ' + t('Email is required.'); err.style.display = 'block'; return; }
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) { err.innerHTML = aIcon('x-circle') + ' ' + t('Please enter a valid email address.'); err.style.display = 'block'; return; }

  err.style.display = 'none';

  const previousType = (registrationData && registrationData.country === country) ? registrationData.type : undefined;
  registrationData = { name, country, city, type: previousType, emailType, email, plan: selectedPlan };
  saveOnboardingState();
  showInstitutionTypeScreen();
}

/* ─── VERIFICATION (STEP 2) ─── */
function showVerifyScreen() {
  showScreen('verify');
  const emailText = document.getElementById('verify-email-text');
  if (registrationData && registrationData.email) {
    emailText.textContent = registrationData.email;
  }
  document.querySelectorAll('.otp-digit').forEach(i => i.value = '');
  document.getElementById('verify-err').style.display = 'none';
  resendCooldown = 0;
  updateResendButton();
  const boxes = document.querySelectorAll('.otp-digit');
  if (boxes[0]) boxes[0].focus();
}

function handleOtpInput(input, index) {
  input.value = input.value.replace(/\D/g, '').slice(0, 1);
  if (input.value && index < 5) {
    const next = document.querySelectorAll('.otp-digit')[index + 1];
    if (next) next.focus();
  }
}

function handleOtpKeydown(event, index) {
  if (event.key === 'Backspace' && !event.target.value && index > 0) {
    const prev = document.querySelectorAll('.otp-digit')[index - 1];
    if (prev) prev.focus();
  }
}

function getEnteredOTP() {
  let otp = '';
  document.querySelectorAll('.otp-digit').forEach(i => otp += i.value);
  return otp;
}

function verifyOTP() {
  const entered = getEnteredOTP();
  const err = document.getElementById('verify-err');
  if (entered.length !== 6) {
    err.innerHTML = aIcon('x-circle') + ' ' + t('Please enter the complete 6-digit code.');
    err.style.display = 'block';
    return;
  }
  err.style.display = 'none';
  const state = JSON.parse(localStorage.getItem('authren_onboarding') || '{}');
  state.verified = true;
  localStorage.setItem('authren_onboarding', JSON.stringify(state));
  showPasswordScreen();
}

function resendOTP() {
  if (resendCooldown > 0) return;
  document.getElementById('verify-err').style.display = 'none';
  resendCooldown = 60;
  updateResendButton();
  const interval = setInterval(() => {
    resendCooldown--;
    updateResendButton();
    if (resendCooldown <= 0) clearInterval(interval);
  }, 1000);
}

function updateResendButton() {
  const btn = document.getElementById('resend-btn');
  const timer = document.getElementById('resend-timer');
  if (resendCooldown > 0) {
    btn.disabled = true;
    timer.style.display = 'inline';
    timer.textContent = '(' + resendCooldown + 's)';
  } else {
    btn.disabled = false;
    timer.style.display = 'none';
  }
}

function changeEmail() {
  showScreen('register');
  fillRegisterFormFromData();
  document.getElementById('reg-err').style.display = 'none';
}

/* ─── PASSWORD (STEP 3) ─── */
function showPasswordScreen() {
  showScreen('password');
  document.getElementById('pass-pass').value = '';
  document.getElementById('pass-confirm').value = '';
  document.getElementById('terms-check').checked = false;
  document.getElementById('pass-err').style.display = 'none';
  updatePasswordHints();
  updateCreateBtnState();
}

function updatePasswordHints() {
  const pass = document.getElementById('pass-pass').value;
  const hint = document.getElementById('pass-hint');
  if (!pass) {
    hint.className = 'pass-hint';
    hint.textContent = t('Minimum 6 characters, with at least 1 letter and 1 number.');
    return;
  }
  const errors = validatePassword(pass);
  if (errors.length === 0) {
    hint.className = 'pass-hint valid';
    hint.innerHTML = aIcon('check') + ' ' + t('Password meets requirements.');
  } else {
    hint.className = 'pass-hint invalid';
    hint.textContent = errors.join(' ');
  }
}

function updateCreateBtnState() {
  const btn = document.getElementById('create-account-btn');
  const terms = document.getElementById('terms-check');
  if (btn && terms) btn.disabled = !terms.checked;
}

function submitPassword() {
  const pass = document.getElementById('pass-pass').value;
  const confirm = document.getElementById('pass-confirm').value;
  const terms = document.getElementById('terms-check').checked;
  const err = document.getElementById('pass-err');

  if (!pass) { err.innerHTML = aIcon('x-circle') + ' ' + t('Password is required.'); err.style.display = 'block'; return; }
  const passErrors = validatePassword(pass);
  if (passErrors.length > 0) { err.innerHTML = aIcon('x-circle') + ' ' + passErrors.join(' '); err.style.display = 'block'; return; }
  if (!confirm) { err.innerHTML = aIcon('x-circle') + ' ' + t('Please confirm your password.'); err.style.display = 'block'; return; }
  if (pass !== confirm) { err.innerHTML = aIcon('x-circle') + ' ' + t('Passwords do not match.'); err.style.display = 'block'; return; }
  if (!terms) { err.innerHTML = aIcon('x-circle') + ' ' + t('Please agree to the Terms and Privacy Policy.'); err.style.display = 'block'; return; }

  err.style.display = 'none';
  registrationData.pass = pass;
  saveOnboardingState();

  /* J1 — "30 days free, no credit card required" must mean exactly that.
     A trial signup skips the review/payment screen entirely and creates a
     trial subscription instead. The paid funnel below is unchanged. */
  if (trialIntent) { completeTrialSignup(); return; }

  showReviewScreen();
}

/* ─── PAYMENT (STEP 4) ─── */
let currentPaymentMethod = 'card';

function showReviewScreen() {
  showScreen('review');
  const planKey = registrationData ? registrationData.plan : selectedPlan;
  const p = PLAN_DATA[planKey];
  if (p) {
    const price = authrenPlanPrice(planKey, selectedBand, selectedCycle);
    const cur = authrenCurrency();
    const band = authrenGetBand(selectedBand);
    document.getElementById('review-plan-name').textContent = p.name;

    const priceEl = document.getElementById('review-plan-price');
    const billingEl = document.getElementById('review-plan-billing');
    const bandEl = document.getElementById('review-plan-band');
    const savingsEl = document.getElementById('review-plan-savings');
    const totalEl = document.getElementById('payment-total');

    if (price.custom) {
      priceEl.innerHTML = t('Custom pricing');
      if (billingEl) billingEl.textContent = t('Our team will prepare your quote.');
      if (totalEl) totalEl.textContent = '—';
    } else {
      priceEl.innerHTML = price.perMonth + ' <span>' + cur + ' / ' + t('month') + '</span>';
      if (billingEl) {
        billingEl.textContent = price.cycle === 'annual'
          ? t('Annual billing') + ' — ' + price.annualTotal + ' ' + cur + ' ' + t('per year')
          : t('Monthly billing');
      }
      if (totalEl) totalEl.textContent = (price.cycle === 'annual' ? price.annualTotal : price.perMonth) + ' ' + cur;
    }
    if (bandEl) bandEl.textContent = band.label;
    if (savingsEl) {
      if (!price.custom && price.cycle === 'annual' && price.savings > 0) {
        savingsEl.style.display = '';
        savingsEl.innerHTML = aIcon('check') + ' ' + t('You save') + ' ' + price.savings + ' ' + cur + ' — ' + price.freeMonths + ' ' + t('months free');
      } else {
        savingsEl.style.display = 'none';
      }
    }
  }
  document.getElementById('pay-card-number').value = '';
  document.getElementById('pay-card-expiry').value = '';
  document.getElementById('pay-card-cvc').value = '';
  document.getElementById('pay-card-name').value = '';
  document.getElementById('payment-err').style.display = 'none';
  selectPaymentMethod('card');
}

function changePlanFromReview() {
  showScreen('plans');
  initPricingUI();
}

function selectPaymentMethod(method) {
  currentPaymentMethod = method;
  document.querySelectorAll('.payment-method-tab').forEach(b => b.classList.remove('active'));
  document.getElementById('pm-tab-' + method).classList.add('active');
  document.getElementById('payment-panel-card').style.display = method === 'card' ? 'block' : 'none';
  document.getElementById('payment-panel-paypal').style.display = method === 'paypal' ? 'block' : 'none';
  document.getElementById('payment-panel-wallet').style.display = method === 'wallet' ? 'block' : 'none';
  const transferPanel = document.getElementById('payment-panel-transfer');
  if (transferPanel) transferPanel.style.display = method === 'transfer' ? 'block' : 'none';
  const btn = document.getElementById('payment-submit-btn');
  if (method === 'card') btn.textContent = t('Pay and Create Account →');
  else if (method === 'paypal') btn.textContent = t('Continue with PayPal →');
  else if (method === 'transfer') btn.textContent = t('Request Bank Transfer Details →');
  else btn.textContent = t('Pay with Apple Pay / Google Pay →');
  document.getElementById('payment-err').style.display = 'none';
}

function formatCardNumber(input) {
  const digits = input.value.replace(/\D/g, '').slice(0, 16);
  input.value = digits.replace(/(.{4})/g, '$1 ').trim();
}

function formatCardExpiry(input) {
  const digits = input.value.replace(/\D/g, '').slice(0, 4);
  input.value = digits.length >= 3 ? digits.slice(0, 2) + '/' + digits.slice(2) : digits;
}

function validateCardFields() {
  const number = document.getElementById('pay-card-number').value.replace(/\s/g, '');
  const expiry = document.getElementById('pay-card-expiry').value.trim();
  const cvc = document.getElementById('pay-card-cvc').value.trim();
  const name = document.getElementById('pay-card-name').value.trim();

  if (!/^\d{13,19}$/.test(number)) return t('Please enter a valid card number.');

  const expMatch = /^(\d{2})\/(\d{2})$/.exec(expiry);
  if (!expMatch) return t('Please enter a valid expiration date (MM/YY).');
  const month = parseInt(expMatch[1], 10);
  const year = parseInt(expMatch[2], 10) + 2000;
  if (month < 1 || month > 12) return t('Please enter a valid expiration date (MM/YY).');
  const expDate = new Date(year, month);
  if (expDate <= new Date()) return t('This card has expired.');

  if (!/^\d{3,4}$/.test(cvc)) return t('Please enter a valid CVC.');
  if (!name) return t('Cardholder name is required.');
  return null;
}

function submitPayment() {
  const err = document.getElementById('payment-err');
  err.style.display = 'none';

  if (currentPaymentMethod === 'card') {
    const cardError = validateCardFields();
    if (cardError) {
      err.innerHTML = aIcon('x-circle') + ' ' + cardError;
      err.style.display = 'block';
      return;
    }
  }

  const btn = document.getElementById('payment-submit-btn');
  const originalLabel = btn.textContent;
  btn.disabled = true;
  btn.textContent = t('Processing…');

  // Frontend-only mock: no real payment provider is contacted here.
  setTimeout(() => {
    const state = JSON.parse(localStorage.getItem('authren_onboarding') || '{}');
    state.accountCreated = true;
    localStorage.setItem('authren_onboarding', JSON.stringify(state));
    btn.disabled = false;
    btn.textContent = originalLabel;
    showSuccessScreen();
  }, 900);
}

/* ─── FREE TRIAL COMPLETION (J1) ─── */
const AUTHREN_TRIAL_DAYS = (typeof AUTHREN_PRICING !== 'undefined' && AUTHREN_PRICING.trial)
  ? AUTHREN_PRICING.trial.days : 30;
let trialEndsAt = null;

function authrenTrialEndDate() {
  const base = (typeof AUTHREN_NOW !== 'undefined') ? new Date(AUTHREN_NOW.getTime()) : new Date();
  base.setDate(base.getDate() + AUTHREN_TRIAL_DAYS);
  return base;
}

function completeTrialSignup() {
  const end = authrenTrialEndDate();
  trialEndsAt = end.toISOString().slice(0, 10);
  const state = JSON.parse(localStorage.getItem('authren_onboarding') || '{}');
  state.accountCreated = true;
  state.isTrial = true;
  state.trialEndsAt = trialEndsAt;
  localStorage.setItem('authren_onboarding', JSON.stringify(state));
  showSuccessScreen();
}

/* ─── SUCCESS ─── */
function showSuccessScreen() {
  showScreen('success');
  if (!registrationData) return;
  document.getElementById('success-name').textContent = registrationData.name;
  document.getElementById('success-email').textContent = registrationData.email;

  const planId = registrationData.plan;
  const plan = PLAN_DATA[planId];
  const el = document.getElementById('success-plan');
  if (!el) return;

  if (trialIntent || trialEndsAt) {
    /* J1 — state the trial end date rather than a price. */
    el.textContent = (plan ? plan.name : '—') + ' — '
      + AUTHREN_TRIAL_DAYS + ' ' + t('day free trial, ends') + ' ' + (trialEndsAt || '');
    return;
  }

  /* J2 — PLAN_DATA carries only a name, so the old code printed
     "(undefined)". Resolve the real figure through the price book. */
  const price = authrenPlanPrice(planId, selectedBand, selectedCycle);
  let priceLabel;
  if (!plan) { priceLabel = '—'; }
  else if (price.custom) { priceLabel = t('Custom pricing'); }
  else if (price.cycle === 'annual') {
    priceLabel = price.perMonth + ' ' + authrenCurrency() + '/' + t('month')
               + ' — ' + t('billed annually') + ' (' + price.annualTotal + ' ' + authrenCurrency() + ')';
  } else {
    priceLabel = price.perMonth + ' ' + authrenCurrency() + '/' + t('month');
  }
  el.textContent = plan ? plan.name + ' (' + priceLabel + ')' : '—';
}

function finishOnboarding() {
  const institutionEmail = registrationData ? registrationData.email : '';
  clearOnboardingState();
  document.getElementById('reg-name').value = '';
  document.getElementById('reg-email').value = '';
  document.getElementById('reg-country').value = '';
  document.getElementById('reg-country-search').value = '';
  document.getElementById('reg-city').value = '';
  document.getElementById('reg-type-select').value = '';
  document.getElementById('pass-pass').value = '';
  document.getElementById('pass-confirm').value = '';
  document.getElementById('terms-check').checked = false;
  document.getElementById('pay-card-number').value = '';
  document.getElementById('pay-card-expiry').value = '';
  document.getElementById('pay-card-cvc').value = '';
  document.getElementById('pay-card-name').value = '';
  document.querySelectorAll('.otp-digit').forEach(i => i.value = '');
  document.getElementById('reg-err').style.display = 'none';
  document.getElementById('reg-type-err').style.display = 'none';
  document.getElementById('verify-err').style.display = 'none';
  document.getElementById('pass-err').style.display = 'none';
  document.getElementById('payment-err').style.display = 'none';
  goToInstitutionLogin(institutionEmail);
}

/* Sends the institution administrator to the school/institution login
   screen (email + password) after account creation, per the required
   post-creation flow. */
function goToInstitutionLogin(email) {
  currentRole = 'school';
  currentSchoolType = null;
  const r = ROLES['school'];
  const loginIcon = document.getElementById('login-icon');
  loginIcon.innerHTML = ROLE_ICONS['school'] || '';
  loginIcon.style.background = r.iconBg;
  loginIcon.style.color = r.accent;
  document.getElementById('login-role-name').textContent = t(r.name);
  applyLoginIdentifierMode('school');
  resetPasswordInputs();
  if (email) document.getElementById('input-login-email').value = email;
  document.getElementById('login-err').style.display = 'none';
  showScreen('login');
}

// Initialize Phase 1 state on load

/* ─── FREE TRIAL / DEMO ───
   The trial is intended to be a real, isolated institution environment, not a
   fake demo account: the school signs up normally and is simply not charged
   during the trial window. Trial provisioning, expiry enforcement and any data
   policy afterwards are BACKEND responsibilities — the frontend only carries
   the intent and the resulting states. */
let trialIntent = false;

function startFreeTrial() {
  trialIntent = true;
  /* Default a trialling school to the most popular plan so they experience a
     representative product; they can still change plan before/after checkout. */
  selectedPlan = AUTHREN_PRICING.popularPlan;
  saveOnboardingState();
  showScreen('register');
  updateRegisterPlanBadge();
  const err = document.getElementById('reg-err');
  if (err) err.style.display = 'none';
}

function requestDemo() {
  const band = authrenGetBand(selectedBand);
  const subject = encodeURIComponent('Authren — Demo request');
  const body = encodeURIComponent(
    'Hello Authren team,\n\nWe would like to schedule a demo.\n\nInstitution name: \nCity: \nApproximate number of students: ' +
    band.label + '\nContact person: \nPhone / WhatsApp: \nPreferred time: \n\nThank you.'
  );
  window.location.href = 'mailto:hello@authren.com?subject=' + subject + '&body=' + body;
}

initPhase1();
initPricingUI();

