/* ════════════════════════════════════════════════════════════
   AUTHREN — SHARED MESSAGES

   ONE messages table, following the exact pattern already proven for
   attendance, grades and homework. A Teacher→Guardian thread and a
   Guardian→Teacher thread are THE SAME THREAD seen from two sides —
   never two independent, disconnected copies of "the conversation."

   HONEST SCOPE NOTE — same as the other shared tables: the Teacher's
   and Guardian's own conversation lists are still separately-authored
   casts of fictional threads. The one genuine connection is the real
   thread between Mr. Bensalem (Youssef's real teacher) and Mr. Karim
   Amrani (Youssef's real guardian) — added here for the first time,
   since GUARDIAN_DATA.account.conversations was previously an empty
   array with no send/reply UI behind it at all (a defect, not a
   simplification — the correction brief named this one specifically).
════════════════════════════════════════════════════════════ */

const AUTHREN_MESSAGES = {
  threads: [], // { id, studentId, teacherId, guardianId, subjectId, participants:[{role,id,name}], readBy:{role_id: lastReadMessageId} }
  messages: [], // { id, threadId, fromRole, fromId, fromName, body, sentAt, attachments }
};

function authrenThreadsForParticipant(role, id) {
  return AUTHREN_MESSAGES.threads.filter(th => th.participants.some(p => p.role === role && p.id === id));
}
function authrenMessagesForThread(threadId) {
  return AUTHREN_MESSAGES.messages.filter(m => m.threadId === threadId).sort((a, b) => a.sentAt.localeCompare(b.sentAt));
}

/* The ONLY write path for a new message in an existing thread. */
function authrenSendMessage(threadId, body, actor, attachments) {
  const a = actor || {};
  const thread = AUTHREN_MESSAGES.threads.find(th => th.id === threadId);
  if (!thread) return { ok: false, message: 'Thread not found.' };
  if (!body || !body.trim()) return { ok: false, message: 'Write a message before sending.' };
  const participant = thread.participants.find(p => p.role === a.role && p.id === a.id);
  if (!participant) return { ok: false, message: 'You are not a participant in this conversation.' };
  const msg = {
    id: 'msg-' + (AUTHREN_MESSAGES.messages.length + 1) + '-' + Math.random().toString(36).slice(2, 6),
    threadId: threadId, fromRole: a.role, fromId: a.id, fromName: participant.name,
    body: body.trim(), sentAt: (typeof AUTHREN_NOW !== 'undefined' ? AUTHREN_NOW.toISOString() : new Date().toISOString()),
    attachments: attachments || [],
  };
  AUTHREN_MESSAGES.messages.push(msg);
  /* Sending marks the sender's own read pointer current; other
     participants' unread state is derived at read time (see
     authrenThreadUnreadCount), never stored redundantly. */
  thread.readBy = thread.readBy || {};
  thread.readBy[a.role + '_' + a.id] = msg.id;
  if (typeof authrenLogAudit === 'function') {
    authrenLogAudit(a.role, a.id, 'Message Sent', 'Message', 'Thread ' + threadId, '', body.trim().slice(0, 40));
  }
  return { ok: true, message: msg };
}

function authrenMarkThreadRead(threadId, role, id) {
  const thread = AUTHREN_MESSAGES.threads.find(th => th.id === threadId);
  if (!thread) return;
  const msgs = authrenMessagesForThread(threadId);
  if (!msgs.length) return;
  thread.readBy = thread.readBy || {};
  thread.readBy[role + '_' + id] = msgs[msgs.length - 1].id;
}
/* Read state is per participant — a guardian reading a thread never
   marks it read for the teacher, and vice versa. */
function authrenThreadUnreadCount(threadId, role, id) {
  const thread = AUTHREN_MESSAGES.threads.find(th => th.id === threadId);
  if (!thread) return 0;
  const msgs = authrenMessagesForThread(threadId);
  const lastRead = (thread.readBy || {})[role + '_' + id];
  if (!lastRead) return msgs.filter(m => !(m.fromRole === role && m.fromId === id)).length;
  const idx = msgs.findIndex(m => m.id === lastRead);
  return msgs.slice(idx + 1).filter(m => !(m.fromRole === role && m.fromId === id)).length;
}

/* Create the ONE real, genuinely connected thread: Mr. Bensalem (Youssef's
   real teacher) and Mr. Karim Amrani (Youssef's real guardian). Previously
   GUARDIAN_DATA.account.conversations was an empty array with no
   send/reply capability behind it at all — this is a real fix, not a
   simplification of something that already worked. */
(function seedYoussefThread() {
  const threadId = 'th-bensalem-amrani';
  AUTHREN_MESSAGES.threads.push({
    id: threadId, studentId: 'S12345678', teacherId: 'p-bensalem-karim', guardianId: 'G98765432', subjectId: 'phys',
    participants: [
      { role: 'teacher', id: 'p-bensalem-karim', name: 'Mr. Karim Bensalem' },
      { role: 'guardian', id: 'G98765432', name: 'Mr. Karim Amrani' },
    ],
    readBy: {},
  });
  authrenSendMessage(threadId, "Hello Mr. Amrani, Youssef did well on the Forces Unit Test — 15/20. I wanted to flag that he was a few minutes late to two recent classes; nothing serious, just wanted you aware.", { role: 'teacher', id: 'p-bensalem-karim' });
})();
