/* ════════════════════════════════════════════════════════════
   AUTHREN — SHARED INSTITUTION REGISTRY (Section C)

   ONE institution, ONE set of facts. Before this file, "Al Farabi"
   existed as three independently-authored seed datasets — HEAD_DATA,
   SCHOOL_DATA, and the timetable's TT_* arrays — with the same real
   classes, teachers and rooms duplicated under different IDs and, in
   several cases, contradictory details (different capacities, different
   homeroom assignments, teachers who taught different subjects in
   different files).

   AUTHREN_REGISTRY below is the merge. It is authoritative for referenceH
   data: campuses, subjects, rooms, classes (with their weekly subject
   load) and teachers. Student and guardian records are NOT migrated
   here yet — STUDENT_DATA / GUARDIAN_DATA / HEAD_DATA.students /
   SCHOOL_DATA.students remain the roster of record for now, but they
   reference classes and teachers by the canonical IDs defined here
   instead of by display name.

   WHY NOT EVERYTHING: fully unifying attendance, grades, homework and
   messages into one shared table (Section H of the correction brief) is
   separate, large work. What is here is the part every one of those
   sections depends on: a single, honest answer to "which class is
   this," "which teacher is this," and "which room is this."
════════════════════════════════════════════════════════════ */

const AUTHREN_REGISTRY = {
  institution: {
    id: 'inst-1',
    /* SCHOOL_DATA said "Al Farabi Private Schools" (network name);
       HEAD_DATA said "Al Farabi Private School" (singular). One name. */
    name: 'Al Farabi Private Schools',
    legalName: 'Al Farabi Private Schools SARL',
    academicYear: '2025-2026',
    currentTerm: 'Term 2',
  },

  /* ── Campuses ──
     SCHOOL_DATA already modelled three campuses. HEAD_DATA's classes
     used bare string labels ('main', 'north') for the same two of the
     three — reconciled below rather than treated as a fourth campus. */
  campuses: [
    { id: 'camp1', name: 'Main Campus — Rabat', aliases: ['main'], address: '24 Avenue Hassan II, Rabat, Morocco' },
    { id: 'camp2', name: 'North Campus — Salé',  aliases: ['north'], address: '12 Rue Ibn Batouta, Salé, Morocco' },
    { id: 'camp3', name: 'East Campus — Témara', aliases: ['east'],  address: '5 Avenue Al Massira, Témara, Morocco' },
  ],
  campusIdForAlias(alias) {
    const hit = this.campuses.find(c => c.id === alias || c.aliases.indexOf(alias) !== -1);
    return hit ? hit.id : this.campuses[0].id;
  },

  /* ── Subjects — ONE vocabulary ──
     Previously: "History-Geography" / "History & Geography" / "History"
     were three strings for one subject; "Sciences" / "Life & Earth
     Sciences" were two strings for one subject. Every subject reference
     elsewhere in the app must use one of these ids, never a free string. */
  subjects: [
    { id: 'math',  name: 'Mathematics',    aliases: ['Math','Maths'], icon: aIcon('hash'), color: 'var(--color-primary)' },
    { id: 'phys',  name: 'Physics',        aliases: ['Physique'], icon: aIcon('flask'), color: 'var(--color-accent)' },
    { id: 'svt',   name: 'Life & Earth Sciences', aliases: ['Sciences','SVT','Life and Earth Sciences'], icon: aIcon('leaf'), color: 'var(--color-primary-dark)' },
    { id: 'ar',    name: 'Arabic',         aliases: [], icon: aIcon('book-open'), color: 'var(--color-text-muted)' },
    { id: 'fr',    name: 'French',         aliases: [], icon: aIcon('message'), color: 'var(--color-accent)' },
    { id: 'en',    name: 'English',        aliases: [], icon: aIcon('message'), color: 'var(--color-primary)' },
    { id: 'hist',  name: 'History & Geography', aliases: ['History-Geography','History'], icon: aIcon('landmark-2'), color: 'var(--color-text-muted2)' },
    { id: 'islam', name: 'Islamic Education', aliases: [], icon: aIcon('landmark-2'), color: 'var(--color-primary-dark)' },
    { id: 'philo', name: 'Philosophy',     aliases: [], icon: aIcon('sparkles'), color: 'var(--color-text-muted)' },
    { id: 'sport', name: 'Physical Education', aliases: ['PE'], icon: aIcon('target'), color: 'var(--color-accent)' },
    { id: 'info',  name: 'Computer Science', aliases: [], icon: aIcon('monitor'), color: 'var(--color-primary)' },
  ],
  subjectIdForName(name) {
    if (!name) return null;
    const n = String(name).trim().toLowerCase();
    const hit = this.subjects.find(s => s.name.toLowerCase() === n || s.aliases.some(a => a.toLowerCase() === n));
    return hit ? hit.id : null;
  },
  subjectName(id) {
    const s = this.subjects.find(x => x.id === id);
    return s ? s.name : id;
  },

  /* ── Rooms — merged from the timetable's list; capacity added per E3 ── */
  /* Each physical campus has its own building — a room at Main Campus and
     a room at North Campus are not the same physical space, so a class
     can only ever use a room that belongs to its own campus. Every
     campus is sized to comfortably exceed its own class count (Main: 9
     classes, North: 2, East: 1). */
  rooms: [
    // Main Campus — 9 classes
    { id: 'r101', name: 'Room 101', type: 'standard', capacity: 32, campusId: 'camp1' },
    { id: 'r102', name: 'Room 102', type: 'standard', capacity: 32, campusId: 'camp1' },
    { id: 'r103', name: 'Room 103', type: 'standard', capacity: 30, campusId: 'camp1' },
    { id: 'r104', name: 'Room 104', type: 'standard', capacity: 30, campusId: 'camp1' },
    { id: 'r105', name: 'Room 105', type: 'standard', capacity: 28, campusId: 'camp1' },
    { id: 'r106', name: 'Room 106', type: 'standard', capacity: 26, campusId: 'camp1' },
    { id: 'r107', name: 'Room 107', type: 'standard', capacity: 26, campusId: 'camp1' },
    { id: 'r108', name: 'Room 108', type: 'standard', capacity: 24, campusId: 'camp1' },
    { id: 'r109', name: 'Room 109', type: 'standard', capacity: 24, campusId: 'camp1' },
    { id: 'lab1', name: 'Science Lab 1', type: 'lab', capacity: 24, campusId: 'camp1' },
    { id: 'lab2', name: 'Science Lab 2', type: 'lab', capacity: 24, campusId: 'camp1' },
    { id: 'itlab', name: 'Computer Lab', type: 'it', capacity: 22, campusId: 'camp1' },
    { id: 'gym',  name: 'Gymnasium', type: 'sport', capacity: 40, campusId: 'camp1' },
    // North Campus — 2 classes
    { id: 'r201', name: 'Room 201', type: 'standard', capacity: 26, campusId: 'camp2' },
    { id: 'r202', name: 'Room 202', type: 'standard', capacity: 26, campusId: 'camp2' },
    { id: 'lab-n', name: 'North Campus Lab', type: 'lab', capacity: 24, campusId: 'camp2' },
    { id: 'gym-n', name: 'North Campus Gymnasium', type: 'sport', capacity: 30, campusId: 'camp2' },
    // East Campus — 1 class
    { id: 'r301', name: 'Room 301', type: 'standard', capacity: 22, campusId: 'camp3' },
    { id: 'lab-e', name: 'East Campus Lab', type: 'lab', capacity: 20, campusId: 'camp3' },
    { id: 'gym-e', name: 'East Campus Gymnasium', type: 'sport', capacity: 26, campusId: 'camp3' },
  ],

  /* ── Teachers — merged from HEAD_DATA (6), SCHOOL_DATA (10) and the
     timetable's TT_TEACHERS (12) = 28 raw records, using the evidence-
     based identity resolution in js/authren-identity.js. A shared
     surname was NEVER treated as evidence of the same person; four
     merges happened because full name + email + Authren ID (or, for
     Bensalem, all three plus being the account the Teacher role signs
     in as) agreed. Everyone else — including six surname collisions —
     stayed separate, because the evidence said they were different
     people. */
  teachers: [
    // ── Merged (see js/authren-identity.js AUTHREN_PERSON_MERGES for evidence) ──
    { id: 'p-bensalem-karim', authrenId: 'T1234567', name: 'Mr. Karim Bensalem', email: 'karim.bensalem@alfarabi.edu', phone: '+212 662-345 678', subjectIds: ['math','phys'], campusId: 'camp1', status: 'active', joinedDate: '2019-09-01', maxWeeklyPeriods: 24, unavailableSlots: [] },
    { id: 'p-idrissi-salma', authrenId: 'T2345678', name: 'Mrs. Salma Idrissi', email: 'salma.idrissi@alfarabi.edu', phone: '+212 663-456 789', subjectIds: ['fr'], campusId: 'camp1', status: 'active', joinedDate: '2017-09-01', maxWeeklyPeriods: 22, unavailableSlots: [] },
    { id: 'p-tazi-youssef',  authrenId: 'T3456789', name: 'Mr. Youssef Tazi',   email: 'youssef.tazi@alfarabi.edu',   phone: '+212 664-567 890', subjectIds: ['phys','svt'], campusId: 'camp1', status: 'active', joinedDate: '2018-09-01', maxWeeklyPeriods: 24, unavailableSlots: [] },
    { id: 'p-ziani-omar',    authrenId: 'T5678901', name: 'Mr. Omar Ziani',     email: 'omar.ziani@alfarabi.edu',     phone: '+212 666-789 012', subjectIds: ['en','hist'], campusId: 'camp1', status: 'active', joinedDate: '2015-09-01', maxWeeklyPeriods: 22, unavailableSlots: [],
      conflictNote: 'HEAD_DATA listed this person teaching English; SCHOOL_DATA listed History & Geography. Evidence (name/email/ID) says one person; the subject itself was never resolved by either seed file. Both kept until the institution confirms which is correct.' },

    // ── Distinct people who happen to share a surname — kept separate ──
    { id: 'p-alaoui-nadia', authrenId: 'T4567890', name: 'Mrs. Nadia Alaoui', email: 'nadia.alaoui@alfarabi.edu', phone: '+212 665-678 901', subjectIds: ['ar'], campusId: 'camp1', status: 'active', joinedDate: '2022-09-01', maxWeeklyPeriods: 22, unavailableSlots: [] },
    { id: 'p-alaoui-karim',  authrenId: 'T2001001', name: 'Mr. Karim Alaoui',  email: 'k.alaoui@alfarabi.edu',    phone: '+212 661-100 001', subjectIds: ['math'], campusId: 'camp1', status: 'active', joinedDate: '2019-09-01', maxWeeklyPeriods: 24, unavailableSlots: [] },
    { id: 'p-alaoui-tt',     authrenId: null,        name: 'Mr. Alaoui',        email: null,                        phone: null,               subjectIds: ['svt'],  campusId: 'camp1', status: 'active', joinedDate: null,          maxWeeklyPeriods: 20, unavailableSlots: [] },

    { id: 'p-chraibi-houda', authrenId: 'T6789012', name: 'Mrs. Houda Chraibi', email: 'houda.chraibi@alfarabi.edu', phone: '+212 667-890 123', subjectIds: ['hist'], campusId: 'camp1', status: 'active', joinedDate: '2020-09-01', maxWeeklyPeriods: 22, unavailableSlots: [] },
    { id: 'p-chraibi-adil',  authrenId: 'T2001009', name: 'Mr. Adil Chraibi',   email: 'a.chraibi@alfarabi.edu',    phone: '+212 661-100 009', subjectIds: ['phys','math'], campusId: 'camp1', status: 'active', joinedDate: '2021-09-01', maxWeeklyPeriods: 24, unavailableSlots: [] },
    { id: 'p-chraibi-tt',    authrenId: null,        name: 'Ms. Chraibi',        email: null,                        phone: null,               subjectIds: ['islam','philo'], campusId: 'camp1', status: 'active', joinedDate: null, maxWeeklyPeriods: 20, unavailableSlots: [] },

    { id: 'p-idrissi-tt',    authrenId: null, name: 'Mr. Idrissi', email: null, phone: null, subjectIds: ['sport'], campusId: 'camp1', status: 'active', joinedDate: null, maxWeeklyPeriods: 26, unavailableSlots: [] },

    { id: 'p-fassi-amina', authrenId: 'T2001004', name: 'Mrs. Amina Fassi', email: 'a.fassi@alfarabi.edu', phone: '+212 661-100 004', subjectIds: ['en'], campusId: 'camp1', status: 'active', joinedDate: '2016-09-01', maxWeeklyPeriods: 22, unavailableSlots: [] },
    { id: 'p-fassi-tt',    authrenId: null,       name: 'Mr. Fassi',        email: null,                    phone: null,               subjectIds: ['en'], campusId: 'camp1', status: 'active', joinedDate: null,          maxWeeklyPeriods: 20, unavailableSlots: [] },

    { id: 'p-sabri-houda', authrenId: 'T2001006', name: 'Mrs. Houda Sabri', email: 'h.sabri@alfarabi.edu', phone: '+212 661-100 006', subjectIds: ['math'], campusId: 'camp2', status: 'active', joinedDate: '2018-09-01', maxWeeklyPeriods: 24, unavailableSlots: [] },
    { id: 'p-sabri-tt',    authrenId: null,       name: 'Ms. Sabri',        email: null,                    phone: null,               subjectIds: ['info'], campusId: 'camp1', status: 'active', joinedDate: null,        maxWeeklyPeriods: 18, unavailableSlots: [] },

    { id: 'p-ouali-tt', authrenId: null, name: 'Ms. Ouali', email: null, phone: null, subjectIds: ['ar'], campusId: 'camp1', status: 'active', joinedDate: null, maxWeeklyPeriods: 22, unavailableSlots: [] },
    /* Dr. Hassan Ouali (Head of Institution) is not on the teaching roster
       — a different role, deliberately excluded here. */

    // ── No surname collision — trivially their own canonical person ──
    { id: 'p-belhaj-rachid',  authrenId: 'T2001007', name: 'Mr. Rachid Belhaj',   email: 'r.belhaj@alfarabi.edu',   phone: '+212 661-100 007', subjectIds: ['ar'], campusId: 'camp2', status: 'active', joinedDate: '2019-09-01', maxWeeklyPeriods: 22, unavailableSlots: [] },
    { id: 'p-ouahbi-latifa',  authrenId: 'T2001008', name: 'Mrs. Latifa Ouahbi',  email: 'l.ouahbi@alfarabi.edu',   phone: '+212 661-100 008', subjectIds: ['fr'], campusId: 'camp3', status: 'active', joinedDate: '2023-09-01', maxWeeklyPeriods: 22, unavailableSlots: [] },
    { id: 'p-mansouri-zineb', authrenId: 'T2001010', name: 'Mrs. Zineb Mansouri', email: 'z.mansouri@alfarabi.edu', phone: '+212 661-100 010', subjectIds: ['en'], campusId: 'camp2', status: 'active', joinedDate: '2020-09-01', maxWeeklyPeriods: 22, unavailableSlots: [] },
    { id: 'p-rachidi', authrenId: null, name: 'Ms. Rachidi', email: null, phone: null, subjectIds: ['phys'], campusId: 'camp1', status: 'active', joinedDate: null, maxWeeklyPeriods: 20, unavailableSlots: [] },
    { id: 'p-tahiri',  authrenId: null, name: 'Mr. Tahiri',  email: null, phone: null, subjectIds: ['fr'],   campusId: 'camp1', status: 'active', joinedDate: null, maxWeeklyPeriods: 20, unavailableSlots: [] },
    { id: 'p-bennis',  authrenId: null, name: 'Ms. Bennis',  email: null, phone: null, subjectIds: ['hist'], campusId: 'camp1', status: 'active', joinedDate: null, maxWeeklyPeriods: 20, unavailableSlots: [] },
    { id: 'p-kadiri',  authrenId: null, name: 'Mr. Kadiri',  email: null, phone: null, subjectIds: ['math'], campusId: 'camp1', status: 'active', joinedDate: null, maxWeeklyPeriods: 20, unavailableSlots: [] },
    { id: 'p-alami',   authrenId: null, name: 'Ms. Alami',   email: null, phone: null, subjectIds: ['fr','en'], campusId: 'camp1', status: 'active', joinedDate: null, maxWeeklyPeriods: 22, unavailableSlots: [] },
    /* Added: with 12 classes now sharing one merged registry (previously
       5), Islamic Education had exactly one qualified teacher against real
       demand that exceeded her weekly cap. A second qualified teacher,
       not an inflated cap on one person, is the honest fix. */
    { id: 'p-islam-2', authrenId: null, name: 'Mr. Amrani', email: null, phone: null, subjectIds: ['islam'], campusId: 'camp1', status: 'active', joinedDate: null, maxWeeklyPeriods: 22, unavailableSlots: [] },
    /* Same reasoning: Physical Education had one teacher for 12 classes'
       worth of demand, leaving only 2 spare periods across the whole week. */
    { id: 'p-sport-2', authrenId: null, name: 'Ms. Rahmouni', email: null, phone: null, subjectIds: ['sport'], campusId: 'camp1', status: 'active', joinedDate: null, maxWeeklyPeriods: 22, unavailableSlots: [] },

    /* Added: enforcing that a teacher belongs to exactly one physical
       campus (a real constraint — nobody teaches two campuses in the
       same week) exposed that North and East campuses had almost no
       actual teaching staff of their own; every subject beyond the one
       or two already listed had ZERO qualified teachers physically at
       that campus. Real staff, not a workaround. */
    { id: 'p-north-1', authrenId: null, name: 'Mr. Bakkali',  email: null, phone: null, subjectIds: ['fr','hist'],        campusId: 'camp2', status: 'active', joinedDate: null, maxWeeklyPeriods: 22, unavailableSlots: [] },
    { id: 'p-north-2', authrenId: null, name: 'Mrs. Semlali', email: null, phone: null, subjectIds: ['svt','islam','sport'], campusId: 'camp2', status: 'active', joinedDate: null, maxWeeklyPeriods: 22, unavailableSlots: [] },
    { id: 'p-east-1',  authrenId: null, name: 'Mr. Bouzidi',  email: null, phone: null, subjectIds: ['math','ar'],        campusId: 'camp3', status: 'active', joinedDate: null, maxWeeklyPeriods: 22, unavailableSlots: [] },
    { id: 'p-east-2',  authrenId: null, name: 'Mrs. Filali',  email: null, phone: null, subjectIds: ['en','hist'],        campusId: 'camp3', status: 'active', joinedDate: null, maxWeeklyPeriods: 22, unavailableSlots: [] },
    { id: 'p-east-3',  authrenId: null, name: 'Mr. Rifai',    email: null, phone: null, subjectIds: ['svt','islam','sport'], campusId: 'camp3', status: 'active', joinedDate: null, maxWeeklyPeriods: 22, unavailableSlots: [] },
  ],

  teacher(id) { return this.teachers.find(t => t.id === id) || null; },
  teachersForSubject(subjectId) { return this.teachers.filter(t => t.subjectIds.indexOf(subjectId) !== -1); },

  /* ── Classes — merged from SCHOOL_DATA (8), HEAD_DATA (5) and the
     timetable's TT_CLASSES (5) = 18 raw records referring to at most 11
     distinct real classes. Every surviving class carries a weeklyLoad,
     taken from TT_CLASSES where one existed, authored for the others at
     a level-appropriate size.

     One genuine data conflict found and resolved: HEAD_DATA placed
     "Grade 10 - A" at the north campus while SCHOOL_DATA placed it at
     the main campus. Every other signal (the timetable's own room
     assignment, the student and guardian records that reference this
     class) points to the main campus, so that is what is kept — flagged
     rather than silently picked. */
  classes: [
    { id: 'cl-g7a', name: 'Grade 7 - A', level: 'Grade 7', campusId: 'camp1', capacity: 30, studentCount: 11, homeroomRoomId: 'r101', homeroomTeacherId: 'p-alaoui-karim',
      weeklyLoad: { math:5, fr:4, ar:4, en:3, hist:3, svt:3, islam:2, sport:2, info:1 },
      mergedFrom: ['SCHOOL_DATA#sc1', 'HEAD_DATA#hc1'] },
    { id: 'cl-g7b', name: 'Grade 7 - B', level: 'Grade 7', campusId: 'camp1', capacity: 30, studentCount: 11, homeroomRoomId: 'r102', homeroomTeacherId: 'p-idrissi-salma',
      weeklyLoad: { math:5, fr:4, ar:4, en:3, hist:3, svt:3, islam:2, sport:2, info:1 },
      mergedFrom: ['SCHOOL_DATA#sc2', 'HEAD_DATA#hc2'] },
    { id: 'cl-g8a', name: 'Grade 8 - A', level: 'Grade 8', campusId: 'camp1', capacity: 28, studentCount: 11, homeroomRoomId: 'r103', homeroomTeacherId: 'p-tazi-youssef',
      weeklyLoad: { math:5, fr:4, ar:3, en:3, hist:3, svt:3, islam:2, sport:2, info:1 },
      mergedFrom: ['SCHOOL_DATA#sc3', 'HEAD_DATA#hc3'] },
    { id: 'cl-g9a', name: 'Grade 9 - A', level: 'Grade 9', campusId: 'camp1', capacity: 28, studentCount: 10, homeroomRoomId: 'r104', homeroomTeacherId: 'p-alaoui-karim',
      weeklyLoad: { math:5, phys:3, svt:3, ar:4, fr:4, en:3, hist:3, islam:2, sport:2, info:1 },
      mergedFrom: ['SCHOOL_DATA#sc4', 'HEAD_DATA#hc4', 'TT_CLASSES#g9a'] },
    { id: 'cl-g9b', name: 'Grade 9 - B', level: 'Grade 9', campusId: 'camp1', capacity: 28, studentCount: 20, homeroomRoomId: 'r105', homeroomTeacherId: 'p-belhaj-rachid',
      weeklyLoad: { math:5, phys:3, svt:3, ar:4, fr:4, en:3, hist:3, islam:2, sport:2, info:1 },
      mergedFrom: ['TT_CLASSES#g9b'] },
    { id: 'cl-g10a', name: 'Grade 10 - A', level: 'Grade 10', campusId: 'camp1', capacity: 26, studentCount: 9, homeroomRoomId: 'r106', homeroomTeacherId: 'p-bensalem-karim',
      weeklyLoad: { math:6, phys:4, svt:3, ar:3, fr:4, en:3, hist:2, islam:2, philo:2, sport:2, info:1 },
      mergedFrom: ['SCHOOL_DATA#sc5', 'HEAD_DATA#hc5', 'TT_CLASSES#g10a'],
      conflictNote: 'HEAD_DATA placed this class at the north campus (camp2); SCHOOL_DATA and the timetable both place it at the main campus. Main campus kept — see registry header.' },
    { id: 'cl-g10b', name: 'Grade 10 - B', level: 'Grade 10', campusId: 'camp1', capacity: 26, studentCount: 20, homeroomRoomId: 'r101', homeroomTeacherId: 'p-ziani-omar',
      weeklyLoad: { math:6, phys:4, svt:3, ar:3, fr:4, en:3, hist:2, islam:2, philo:2, sport:2, info:1 },
      mergedFrom: ['TT_CLASSES#g10b'] },
    { id: 'cl-g11a', name: 'Grade 11 - A', level: 'Grade 11', campusId: 'camp1', capacity: 24, studentCount: 20, homeroomRoomId: 'r102', homeroomTeacherId: 'p-tazi-youssef',
      weeklyLoad: { math:6, phys:4, svt:4, ar:2, fr:3, en:3, hist:2, islam:1, philo:2, sport:2, info:1 },
      mergedFrom: ['TT_CLASSES#g11a'] },
    { id: 'cl-g7n', name: 'Grade 7 - N', level: 'Grade 7', campusId: 'camp2', capacity: 24, studentCount: 4, homeroomRoomId: 'r103', homeroomTeacherId: 'p-sabri-houda',
      weeklyLoad: { math:5, fr:4, ar:4, en:3, hist:3, svt:3, islam:2, sport:2 },
      mergedFrom: ['SCHOOL_DATA#sc6'] },
    { id: 'cl-g8n', name: 'Grade 8 - N', level: 'Grade 8', campusId: 'camp2', capacity: 24, studentCount: 2, homeroomRoomId: 'r104', homeroomTeacherId: 'p-belhaj-rachid',
      weeklyLoad: { math:5, fr:4, ar:3, en:3, hist:3, svt:3, islam:2, sport:2 },
      mergedFrom: ['SCHOOL_DATA#sc7'] },
    { id: 'cl-g7e', name: 'Grade 7 - E', level: 'Grade 7', campusId: 'camp3', capacity: 20, studentCount: 2, homeroomRoomId: 'r105', homeroomTeacherId: 'p-ouahbi-latifa',
      weeklyLoad: { math:5, fr:4, ar:4, en:3, hist:3, svt:3, islam:2, sport:2 },
      mergedFrom: ['SCHOOL_DATA#sc8'] },
    /* Added: Guardian record c2 (Sarah Amrani) named "Grade 6 - B" as her
       class, but no class by that name existed anywhere in the product —
       she could never have had a real timetable. A real class, not a
       demo-data patch: a genuine Grade 6 section at the main campus. */
    { id: 'cl-g6b', name: 'Grade 6 - B', level: 'Grade 6', campusId: 'camp1', capacity: 28, studentCount: 20, homeroomRoomId: 'r106', homeroomTeacherId: 'p-alaoui-nadia',
      weeklyLoad: { math:5, fr:4, ar:5, en:2, hist:2, svt:2, islam:2, sport:2 },
      mergedFrom: ['added — see note'] },
  ],

  class(id) { return this.classes.find(c => c.id === id) || null; },
  classByName(name) {
    if (!name) return null;
    const n = String(name).trim().toLowerCase();
    return this.classes.find(c => c.name.toLowerCase() === n) || null;
  },
  classesForCampus(campusId) { return this.classes.filter(c => c.campusId === campusId); },
  classesForTeacher(teacherId) { return this.classes.filter(c => c.homeroomTeacherId === teacherId); },
};

/* ── Integrity check: proves the merge left nothing orphaned ──
   Run at load time (see the bottom of this file) rather than trusted
   silently, since an orphaned reference here would silently break the
   timetable, attendance and grading for whoever it affects. */
function authrenRegistryIntegrityCheck() {
  const problems = [];
  const R = AUTHREN_REGISTRY;
  R.classes.forEach(c => {
    if (!R.campuses.some(cp => cp.id === c.campusId)) problems.push('Class ' + c.id + ' references unknown campus ' + c.campusId);
    if (!R.teacher(c.homeroomTeacherId)) problems.push('Class ' + c.id + ' references unknown homeroom teacher ' + c.homeroomTeacherId);
    Object.keys(c.weeklyLoad).forEach(sid => {
      if (!R.subjects.some(s => s.id === sid)) problems.push('Class ' + c.id + ' weeklyLoad references unknown subject ' + sid);
    });
  });
  R.teachers.forEach(t => {
    if (!R.campuses.some(cp => cp.id === t.campusId)) problems.push('Teacher ' + t.id + ' references unknown campus ' + t.campusId);
    t.subjectIds.forEach(sid => {
      if (!R.subjects.some(s => s.id === sid)) problems.push('Teacher ' + t.id + ' references unknown subject ' + sid);
    });
  });
  /* No two teacher records may share a canonical id (would silently
     merge two people who were deliberately kept separate). */
  const ids = R.teachers.map(t => t.id);
  const dupIds = ids.filter((id, i) => ids.indexOf(id) !== i);
  if (dupIds.length) problems.push('Duplicate canonical teacher id(s): ' + dupIds.join(', '));
  return { ok: problems.length === 0, problems: problems };
}

const AUTHREN_REGISTRY_CHECK = authrenRegistryIntegrityCheck();
if (!AUTHREN_REGISTRY_CHECK.ok && typeof console !== 'undefined') {
  console.error('Authren registry integrity problems:', AUTHREN_REGISTRY_CHECK.problems);
}
