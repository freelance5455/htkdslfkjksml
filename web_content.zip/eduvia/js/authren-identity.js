/* ════════════════════════════════════════════════════════════
   AUTHREN — PEOPLE IDENTITY RESOLUTION

   Decides which records across the separate role datasets refer to the
   SAME REAL PERSON, ahead of the shared-store migration.

   RULE (corrected): a shared surname is NOT evidence of identity.
   Two different people may legitimately share a surname. A merge
   requires clear identifying evidence — a matching stable ID, or a
   matching full name combined with corroborating detail (email, phone,
   subject, title/gender).

   Anything that only shares a surname stays as TWO SEPARATE PEOPLE.

   Every downstream reference (class, teaching assignment, timetable,
   grade, message, payment) must point at a canonical id below, never at
   a display name.
════════════════════════════════════════════════════════════ */

/* ── Confirmed same person — merged, with the evidence that justifies it ── */
const AUTHREN_PERSON_MERGES = [
  {
    canonicalId: 'p-bensalem-karim',
    name: 'Mr. Karim Bensalem',
    sources: ['HEAD_DATA.teachers#ht1', 'TEACHER_DATA.account', 'TT_TEACHERS#t1'],
    evidence: 'Identical Authren teacher ID (T1234567), identical email (karim.bensalem@alfarabi.edu), identical phone (+212 662-345 678) and identical full name. This is also the account the Teacher role signs in as.',
    resolve: { subjects: ['math', 'phys'], note: 'Head record listed Mathematics only; the account and timetable both teach Physics too. Union kept.' },
  },
  {
    canonicalId: 'p-idrissi-salma',
    name: 'Mrs. Salma Idrissi',
    sources: ['HEAD_DATA.teachers#ht2', 'SCHOOL_DATA.teachers#st2'],
    evidence: 'Identical full name and title, identical subject (French), same email domain with the same naming convention (salma.idrissi / s.idrissi).',
    resolve: { subjects: ['fr'], conflict: 'joinedDate differs (2021-09-01 vs 2017-09-01) and teacherId differs (T2345678 vs T2001002) — artifacts of the two datasets being authored separately. Take the earlier joinedDate; keep one teacherId.' },
  },
  {
    canonicalId: 'p-tazi-youssef',
    name: 'Mr. Youssef Tazi',
    sources: ['HEAD_DATA.teachers#ht3', 'SCHOOL_DATA.teachers#st3'],
    evidence: 'Identical full name and title, overlapping subject (Physics), same email convention (youssef.tazi / y.tazi).',
    resolve: { subjects: ['phys', 'svt'], note: 'Head record adds Sciences; union kept.' },
  },
  {
    canonicalId: 'p-ziani-omar',
    name: 'Mr. Omar Ziani',
    sources: ['HEAD_DATA.teachers#ht5', 'SCHOOL_DATA.teachers#st5'],
    evidence: 'Identical full name and title, same email convention (omar.ziani / o.ziani).',
    resolve: { subjects: ['en', 'hist'], conflict: 'Subjects disagree outright (English vs History-Geography). Union kept pending a decision by the institution; flag in the migration report rather than silently choosing one.' },
  },
];

/* ── Shared surname, DIFFERENT PEOPLE — must never be merged ──
   Each group lists records that a naive "one person per surname" rule
   would have collapsed incorrectly. */
const AUTHREN_DISTINCT_PEOPLE = [
  {
    surname: 'Alaoui',
    people: [
      { canonicalId: 'p-alaoui-nadia', name: 'Mrs. Nadia Alaoui', source: 'HEAD_DATA.teachers#ht4', subject: 'Arabic' },
      { canonicalId: 'p-alaoui-karim', name: 'Mr. Karim Alaoui',  source: 'SCHOOL_DATA.teachers#st1', subject: 'Mathematics' },
      { canonicalId: 'p-alaoui-tt',    name: 'Mr. Alaoui',        source: 'TT_TEACHERS#t7', subject: 'Life & Earth Sciences' },
    ],
    reason: 'Different first names, different titles/gender, different subjects, different emails and different Authren IDs. Nadia and Karim are plainly two people. The timetable record has no first name and teaches a third subject, so there is not enough evidence to attach it to either — it stays its own person until the institution confirms otherwise.',
  },
  {
    surname: 'Chraibi',
    people: [
      { canonicalId: 'p-chraibi-houda', name: 'Mrs. Houda Chraibi', source: 'HEAD_DATA.teachers#ht6', subject: 'History-Geography' },
      { canonicalId: 'p-chraibi-adil',  name: 'Mr. Adil Chraibi',   source: 'SCHOOL_DATA.teachers#st9', subject: 'Physics, Mathematics' },
      { canonicalId: 'p-chraibi-tt',    name: 'Ms. Chraibi',        source: 'TT_TEACHERS#t8', subject: 'Islamic Education, Philosophy' },
    ],
    reason: 'Houda and Adil differ in first name, title/gender and subject — two people. The timetable record teaches neither of their subjects, so it is not safely attachable to either.',
  },
  {
    surname: 'Idrissi',
    people: [
      { canonicalId: 'p-idrissi-salma', name: 'Mrs. Salma Idrissi', source: 'merged (see AUTHREN_PERSON_MERGES)', subject: 'French' },
      { canonicalId: 'p-idrissi-tt',    name: 'Mr. Idrissi',        source: 'TT_TEACHERS#t9', subject: 'Physical Education' },
    ],
    reason: 'Different title/gender and a completely different subject. Merging these would have put a French teacher in charge of PE.',
  },
  {
    surname: 'Fassi',
    people: [
      { canonicalId: 'p-fassi-amina', name: 'Mrs. Amina Fassi', source: 'SCHOOL_DATA.teachers#st4', subject: 'English' },
      { canonicalId: 'p-fassi-tt',    name: 'Mr. Fassi',        source: 'TT_TEACHERS#t5', subject: 'English' },
    ],
    reason: 'Same subject, but different title/gender — a woman and a man. Same subject is not identity.',
  },
  {
    surname: 'Sabri',
    people: [
      { canonicalId: 'p-sabri-houda', name: 'Mrs. Houda Sabri', source: 'SCHOOL_DATA.teachers#st6', subject: 'Mathematics' },
      { canonicalId: 'p-sabri-tt',    name: 'Ms. Sabri',        source: 'TT_TEACHERS#t10', subject: 'Computer Science' },
    ],
    reason: 'No first name on the timetable record and a different subject — insufficient evidence to merge.',
  },
  {
    surname: 'Ouali',
    people: [
      { canonicalId: 'p-ouali-hassan', name: 'Dr. Hassan Ouali', source: 'HEAD_DATA (Head of Institution)', subject: '—' },
      { canonicalId: 'p-ouali-tt',     name: 'Ms. Ouali',        source: 'TT_TEACHERS#t4', subject: 'Arabic' },
    ],
    reason: 'One is the Head of Institution, the other an Arabic teacher; different titles and different roles entirely.',
  },
];

/* Helper for the migration: returns the canonical id for a source record
   reference such as 'HEAD_DATA.teachers#ht1', or null when the record is
   its own canonical person. */
function authrenCanonicalPersonId(sourceRef) {
  const merged = AUTHREN_PERSON_MERGES.find(m => m.sources.indexOf(sourceRef) !== -1);
  if (merged) return merged.canonicalId;
  for (let i = 0; i < AUTHREN_DISTINCT_PEOPLE.length; i++) {
    const hit = AUTHREN_DISTINCT_PEOPLE[i].people.find(p => p.source === sourceRef);
    if (hit) return hit.canonicalId;
  }
  return null;
}

/* Guard used by the migration and by tests: proves that no two DISTINCT
   people were collapsed into one canonical id. */
function authrenIdentityIntegrityCheck() {
  const problems = [];
  const seen = {};
  AUTHREN_DISTINCT_PEOPLE.forEach(group => {
    group.people.forEach(p => {
      if (seen[p.canonicalId]) {
        problems.push('Distinct person reuses canonical id: ' + p.canonicalId);
      }
      seen[p.canonicalId] = true;
    });
  });
  AUTHREN_PERSON_MERGES.forEach(m => {
    if (!m.evidence || m.evidence.length < 20) {
      problems.push('Merge without stated evidence: ' + m.canonicalId);
    }
    if (m.sources.length < 2) {
      problems.push('Merge with fewer than two sources: ' + m.canonicalId);
    }
  });
  return { ok: problems.length === 0, problems: problems };
}
