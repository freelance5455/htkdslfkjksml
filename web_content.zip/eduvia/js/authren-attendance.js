/* ════════════════════════════════════════════════════════════
   AUTHREN — SHARED ATTENDANCE

   ONE attendance record set, following the exact pattern already
   proven for payments (js/authren-payments.js): the teacher's save is
   the ONLY write path, and every role's view of a student's attendance
   is a read over the same table — never a separate, independently
   fabricated number.

   HONEST SCOPE NOTE: the Teacher role's roster (TEACHER_DATA.students),
   the Student role's own identity, and the Guardian role's children are
   still three separately-authored casts of fictional students that do
   not, in general, refer to the same people (Section C's full student-
   roster unification is separate, larger work, not done here).

   The ONE genuine exception — added specifically to make this real —
   is Youssef Amrani (studentId S12345678): the Student role's own
   logged-in character, who now also has a real seat in his real
   teacher's (Mr. Karim Bensalem, Grade 10-A Physics) roster, and is
   the Guardian role's child c1. For this one student, attendance is
   now genuinely one shared fact across three roles. Every other
   student in each role's roster keeps its existing local demo data
   until the full roster merge happens.
════════════════════════════════════════════════════════════ */

const AUTHREN_ATTENDANCE = {
  records: [], // { id, studentId, classId, subjectId, date, status, justification, recordedByTeacherId, recordedAt }
};

/* present | absent | late | excused. 'excused' means a guardian
   justification for an 'absent' record has been accepted. */
function authrenAttendanceKey(studentId, date) { return studentId + '|' + date; }

function authrenAttendanceForStudent(studentId) {
  return AUTHREN_ATTENDANCE.records.filter(r => r.studentId === studentId);
}

/* The ONLY write path. Called by the teacher's save action (and, once,
   by the seed data below to establish Youssef's real history). Always
   audited with the real actor. */
function authrenRecordAttendance(row, actor) {
  const a = actor || {};
  if (!row || !row.studentId || !row.date) {
    return { ok: false, message: 'A studentId and date are required to record attendance.' };
  }
  const existing = AUTHREN_ATTENDANCE.records.find(r => r.studentId === row.studentId && r.date === row.date);
  if (existing) {
    const prev = existing.status;
    Object.assign(existing, { status: row.status, classId: row.classId, subjectId: row.subjectId, recordedByTeacherId: a.id || row.recordedByTeacherId, recordedAt: row.recordedAt });
    if (typeof authrenLogAudit === 'function' && prev !== row.status) {
      authrenLogAudit(a.role || 'teacher', a.id, 'Attendance Changed', 'Attendance', row.studentId + ' — ' + row.date, prev, row.status);
    }
    return { ok: true, record: existing };
  }
  const rec = {
    id: 'att-' + (AUTHREN_ATTENDANCE.records.length + 1) + '-' + Math.random().toString(36).slice(2, 6),
    studentId: row.studentId, classId: row.classId, subjectId: row.subjectId,
    date: row.date, status: row.status, justification: null,
    recordedByTeacherId: a.id || row.recordedByTeacherId || null,
    recordedAt: row.recordedAt || (typeof AUTHREN_NOW !== 'undefined' ? AUTHREN_NOW.toISOString() : null),
  };
  AUTHREN_ATTENDANCE.records.push(rec);
  if (typeof authrenLogAudit === 'function') {
    authrenLogAudit(a.role || 'teacher', a.id, 'Attendance Recorded', 'Attendance', row.studentId + ' — ' + row.date, '', row.status);
  }
  return { ok: true, record: rec };
}

/* A guardian's justification request, and the school's acceptance of it.
   Acceptance must name an approver who is not the submitter (the
   correction brief's "no self-approval" rule) — a guardian can request,
   only the school side (teacher or head) can accept. */
function authrenRequestJustification(studentId, date, text, actor) {
  const rec = AUTHREN_ATTENDANCE.records.find(r => r.studentId === studentId && r.date === date);
  if (!rec) return { ok: false, message: 'No attendance record found for that date.' };
  if (rec.status !== 'absent') return { ok: false, message: 'Only an absence can be justified.' };
  rec.justification = { text: text, status: 'pending', requestedBy: (actor && actor.role) || 'guardian', requestedAt: (typeof AUTHREN_NOW !== 'undefined' ? AUTHREN_NOW.toISOString() : null) };
  return { ok: true, record: rec };
}
function authrenAcceptJustification(studentId, date, actor) {
  const a = actor || {};
  if (a.role === 'guardian') return { ok: false, message: 'A guardian cannot approve their own justification request.' };
  const rec = AUTHREN_ATTENDANCE.records.find(r => r.studentId === studentId && r.date === date);
  if (!rec || !rec.justification) return { ok: false, message: 'No pending justification for that date.' };
  rec.justification.status = 'accepted';
  rec.justification.acceptedBy = { role: a.role, id: a.id || null };
  rec.status = 'excused';
  if (typeof authrenLogAudit === 'function') {
    authrenLogAudit(a.role, a.id, 'Justification Accepted', 'Attendance', studentId + ' — ' + date, 'absent', 'excused');
  }
  return { ok: true, record: rec };
}

/* ── Everything below is DERIVED, never stored — the point of this file.
   Any screen that used to read a hand-picked literal (rate: 94, ...)
   computes it from the real records instead. ── */
function authrenAttendanceSummary(studentId) {
  const rows = authrenAttendanceForStudent(studentId);
  const present = rows.filter(r => r.status === 'present').length;
  const late = rows.filter(r => r.status === 'late').length;
  const excused = rows.filter(r => r.status === 'excused').length;
  const absentUnjustified = rows.filter(r => r.status === 'absent').length;
  const total = rows.length;
  const rate = total ? Math.round(((present + late + excused) / total) * 1000) / 10 : null;
  return { total, present, late, excused, absentUnjustified, rate };
}

/* Current present/late streak, most recent day first. */
function authrenAttendanceStreak(studentId) {
  const rows = authrenAttendanceForStudent(studentId).slice().sort((a, b) => b.date.localeCompare(a.date));
  let streak = 0;
  for (let i = 0; i < rows.length; i++) {
    if (rows[i].status === 'present' || rows[i].status === 'late') streak++;
    else break;
  }
  return streak;
}

/* Seed Youssef's real attendance history for the term, not just the
   handful of exceptional days — 5 negative records alone would compute
   an honest number (80%) that LOOKS like a term-long rate while actually
   representing 5 cherry-picked days, which is its own kind of dishonesty.
   Term 2 runs 2026-01-05 to 2026-03-27 in this seed data; every real
   school day (Mon–Sat) is recorded as present, except the specific days
   below, which carry their real status. Recorded "by" his real teacher. */
(function seedYoussefAttendance() {
  const teacherId = 'p-bensalem-karim';
  const classId = 'cl-g10a';
  const subjectId = 'phys';
  const exceptions = {
    '2026-03-26': 'late',
    '2026-03-18': 'absent',
    '2026-03-04': 'late',
    '2026-02-21': 'absent',
    '2026-02-04': 'absent',
  };
  const start = new Date(2026, 0, 5);   // 2026-01-05
  const end = new Date(2026, 2, 27);    // 2026-03-27 (today, in this seed data)
  for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
    if (d.getDay() === 0) continue; // no school on Sunday
    const iso = d.toISOString().slice(0, 10);
    const status = exceptions[iso] || 'present';
    authrenRecordAttendance(
      { studentId: 'S12345678', classId, subjectId, date: iso, status, recordedByTeacherId: teacherId, recordedAt: iso + 'T09:00:00' },
      { role: 'teacher', id: teacherId }
    );
  }
  /* The Feb 21 and Feb 4 absences were already justified in the existing
     student-side demo data — carry that forward as real accepted
     justifications rather than dropping the detail. */
  authrenRequestJustification('S12345678', '2026-02-21', 'Medical appointment.', { role: 'guardian', id: 'g-amrani' });
  authrenAcceptJustification('S12345678', '2026-02-21', { role: 'teacher', id: teacherId });
  authrenRequestJustification('S12345678', '2026-02-04', 'Family event.', { role: 'guardian', id: 'g-amrani' });
  authrenAcceptJustification('S12345678', '2026-02-04', { role: 'teacher', id: teacherId });
})();
