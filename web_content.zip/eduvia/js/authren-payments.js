/* ════════════════════════════════════════════════════════════
   AUTHREN — PAYMENT AUTHORITY AND SHARED LEDGER

   ONE payment ledger. Both the School/Institution role and the Head of
   Institution write through the functions here, so a payment recorded by
   one is immediately visible to the other, and every write is audited
   with the real actor.

   AUTHORITY MODEL
   ---------------
   School / Institution — FINANCIAL OWNER
     Owns invoices, billing configuration, payment categories, the
     ledger itself, receipts, financial analytics, payment
     infrastructure, and the commercial subscription. Only the
     Institution (association type "owner") changes the subscription or
     the institution-level financial configuration.

   Head of Institution — OPERATIONAL ENTRY AND VIEW
     May view a student's payment status and history, record a student's
     actual fee payment, and view or generate the resulting receipt.
     May NOT touch the subscription, billing configuration, payment
     infrastructure, or any institution-wide financial setting.

   NOTE ON SCOPE: the Head and Institution role files still carry their
   own student rosters, so their seeded payment rows are tagged by source
   here rather than key-merged. Unifying the student identities is the
   shared-store migration's job; the single write path, the single audit
   trail and the authority rules are live now.
════════════════════════════════════════════════════════════ */

const AUTHREN_LEDGER = {
  payments: [],
  auditLog: [],
};

/* ── Authority matrix ── */
const AUTHREN_FINANCIAL_AUTHORITY = {
  /* Institution-level financial configuration and commercial billing */
  manageSubscription:   { school: ['owner'],                          head: false },
  manageBillingConfig:  { school: ['owner'],                          head: false },
  managePaymentCategories: { school: ['owner'],                       head: false },
  managePaymentInfra:   { school: ['owner', 'finance'],               head: false },
  manageInvoices:       { school: ['owner', 'finance'],               head: false },
  viewFinancialAnalytics:{ school: ['owner', 'finance'],              head: true  },
  /* Operational fee entry */
  recordStudentPayment: { school: ['owner', 'finance'],               head: true  },
  viewStudentPayments:  { school: ['owner', 'finance', 'admin'],      head: true  },
  viewReceipt:          { school: ['owner', 'finance', 'admin'],      head: true  },
  viewSubscription:     { school: ['owner', 'finance', 'admin'],      head: true  },
};

/* Deny by default: an unknown capability is refused. */
function authrenCan(capability, actorRole, associationType) {
  const rule = AUTHREN_FINANCIAL_AUTHORITY[capability];
  if (!rule) return false;
  if (actorRole === 'head') return rule.head === true;
  if (actorRole === 'school') {
    if (!Array.isArray(rule.school)) return false;
    return rule.school.indexOf(associationType || 'owner') !== -1;
  }
  return false;
}

/* ── Audit ── */
function authrenLogAudit(actorRole, actorId, action, objectType, objectLabel, previousValue, newValue) {
  const now = (typeof AUTHREN_NOW !== 'undefined') ? AUTHREN_NOW : new Date();
  AUTHREN_LEDGER.auditLog.unshift({
    id: 'aud-' + (AUTHREN_LEDGER.auditLog.length + 1) + '-' + Math.random().toString(36).slice(2, 6),
    at: now.toISOString ? now.toISOString() : String(now),
    actorRole: actorRole || 'unknown',
    actorId: actorId || null,
    action: action,
    objectType: objectType,
    objectLabel: objectLabel || '',
    previousValue: previousValue == null ? '' : String(previousValue),
    newValue: newValue == null ? '' : String(newValue),
  });
  return AUTHREN_LEDGER.auditLog[0];
}

/* ── Ledger reads ── */
function authrenAllPayments() { return AUTHREN_LEDGER.payments; }

function authrenPaymentsForStudent(studentId) {
  return AUTHREN_LEDGER.payments.filter(p => p.studentId === studentId);
}
function authrenPaymentsForStudents(studentIds) {
  const set = {};
  (studentIds || []).forEach(id => { set[id] = true; });
  return AUTHREN_LEDGER.payments.filter(p => set[p.studentId]);
}
function authrenPaymentById(id) {
  return AUTHREN_LEDGER.payments.find(p => p.id === id) || null;
}
/* A student's payment status is DERIVED from the ledger, never stored. */
function authrenStudentPaymentStatus(studentId) {
  const rows = authrenPaymentsForStudent(studentId);
  if (!rows.length) return 'paid';
  if (rows.some(p => p.status === 'overdue')) return 'overdue';
  if (rows.some(p => p.status === 'pending')) return 'partial';
  return 'paid';
}
function authrenFinancialTotals(studentIds) {
  const rows = studentIds ? authrenPaymentsForStudents(studentIds) : AUTHREN_LEDGER.payments;
  const sum = st => rows.filter(p => p.status === st).reduce((a, p) => a + p.amount, 0);
  return { collected: sum('paid'), pending: sum('pending'), overdue: sum('overdue'), count: rows.length };
}

/* ── Ledger writes — the ONLY write path ── */
let authrenReceiptCounter = 1;
function authrenNextReceiptId(dateStr) {
  const year = (dateStr || '2026-01-01').slice(0, 4);
  return 'RCPT-' + year + '-' + String(authrenReceiptCounter++).padStart(3, '0');
}

/* Seeding path: used by the role files' deterministic generators. Does not
   audit (these are historical fixtures, not actions taken in-session). */
function authrenSeedPayment(row) {
  AUTHREN_LEDGER.payments.push(row);
  return row;
}

/* Recording a real fee payment. Permitted for the Head (operational) and
   for Institution owner/finance. Always audited with the real actor. */
function authrenRecordPayment(payment, actor) {
  const a = actor || {};
  if (!authrenCan('recordStudentPayment', a.role, a.associationType)) {
    return { ok: false, reason: 'not-permitted',
             message: 'This account is not permitted to record student payments.' };
  }
  const row = {
    id: payment.id || ('pay-' + Date.now() + '-' + Math.random().toString(36).slice(2, 5)),
    studentId: payment.studentId,
    campusId: payment.campusId || null,
    date: payment.date,
    description: payment.description,
    amount: payment.amount,
    currency: payment.currency || 'MAD',
    status: payment.status || 'paid',
    method: payment.method || null,
    receiptId: payment.receiptId || (payment.status === 'overdue' || payment.status === 'pending'
                 ? null : authrenNextReceiptId(payment.date)),
    recordedBy: { role: a.role, id: a.id || null },
    source: payment.source || null,
  };
  AUTHREN_LEDGER.payments.push(row);
  authrenLogAudit(a.role, a.id, 'Payment Recorded', 'Payment',
    row.description + ' — ' + row.amount + ' ' + row.currency, '', row.status);
  return { ok: true, payment: row };
}

function authrenUpdatePaymentStatus(paymentId, newStatus, actor) {
  const a = actor || {};
  if (!authrenCan('recordStudentPayment', a.role, a.associationType)) {
    return { ok: false, reason: 'not-permitted',
             message: 'This account is not permitted to change payment status.' };
  }
  const row = authrenPaymentById(paymentId);
  if (!row) return { ok: false, reason: 'not-found', message: 'Payment not found.' };
  const prev = row.status;
  row.status = newStatus;
  if (newStatus === 'paid' && !row.receiptId) row.receiptId = authrenNextReceiptId(row.date);
  row.recordedBy = { role: a.role, id: a.id || null };
  authrenLogAudit(a.role, a.id, 'Payment Status Changed', 'Payment', row.description, prev, newStatus);
  return { ok: true, payment: row };
}

/* Institution-only: billing configuration and commercial subscription. */
function authrenChangeSubscriptionPlan(newPlanId, actor) {
  const a = actor || {};
  if (!authrenCan('manageSubscription', a.role, a.associationType)) {
    return { ok: false, reason: 'not-permitted',
             message: 'Only the School / Institution account (Owner) can change the subscription plan.' };
  }
  authrenLogAudit(a.role, a.id, 'Subscription Changed', 'Subscription', newPlanId, '', newPlanId);
  return { ok: true, planId: newPlanId };
}
