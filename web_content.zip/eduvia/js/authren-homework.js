/* ════════════════════════════════════════════════════════════
   AUTHREN — SHARED HOMEWORK

   ONE homework record set, following the exact pattern already proven
   for attendance (js/authren-attendance.js) and grades
   (js/authren-grades.js). The teacher's publish action is the ONLY
   write path for a homework's existence; a student's own "mark done"
   is the ONLY write path for their submission status. Every role's
   view of a class's homework, and a student's completion of it, is a
   read over this same table.

   HONEST SCOPE NOTE — same as attendance and grades: the Teacher,
   Student and Guardian roles still each carry their own separately-
   authored cast of fictional homework. The one genuine connection is
   Mr. Bensalem's real Grade 10-A Physics homework (hw4, "Lab Report:
   Forces") and Youssef Amrani (S12345678), the one student wired
   across all three roles in this build.
════════════════════════════════════════════════════════════ */

const AUTHREN_HOMEWORK = {
  records: [], // { id, classId, subjectId, teacherId, title, description, instructions, dueDate, attachments, status, createdAt, submissions:{studentId:status} }
};

/* status: 'draft' | 'published' | 'archived'.
   submission status per student: 'pending' | 'submitted' | 'late' | 'done'. */
function authrenHomeworkForStudent(studentId) {
  return AUTHREN_HOMEWORK.records.filter(r => r.status === 'published' && (studentId in r.submissions));
}

/* The ONLY write path for a homework's existence — called when the
   teacher publishes (or unpublishes/archives) it. */
function authrenPublishHomework(hwSnapshot, actor) {
  const a = actor || {};
  const existing = AUTHREN_HOMEWORK.records.find(r => r.id === hwSnapshot.id);
  const record = {
    id: hwSnapshot.id, classId: hwSnapshot.classId, subjectId: hwSnapshot.subjectId,
    teacherId: a.id || hwSnapshot.teacherId || null,
    title: hwSnapshot.title, description: hwSnapshot.description || '', instructions: hwSnapshot.instructions || '',
    dueDate: hwSnapshot.dueDate, attachments: hwSnapshot.attachments || [],
    status: 'published', createdAt: hwSnapshot.createdAt || null,
    submissions: Object.assign({}, hwSnapshot.submissions || {}),
  };
  if (existing) Object.assign(existing, record);
  else AUTHREN_HOMEWORK.records.push(record);

  if (typeof authrenLogAudit === 'function') {
    authrenLogAudit(a.role || 'teacher', a.id, 'Homework Published', 'Homework', hwSnapshot.title, '', 'published');
  }
  return { ok: true, record: existing || record };
}
function authrenSetHomeworkStatus(hwId, status, actor) {
  const a = actor || {};
  const rec = AUTHREN_HOMEWORK.records.find(r => r.id === hwId);
  if (!rec) return { ok: false, message: 'Homework was never published.' };
  const prev = rec.status;
  rec.status = status;
  if (typeof authrenLogAudit === 'function' && prev !== status) {
    authrenLogAudit(a.role || 'teacher', a.id, 'Homework ' + status.charAt(0).toUpperCase() + status.slice(1), 'Homework', rec.title, prev, status);
  }
  return { ok: true, record: rec };
}

/* The ONLY write path for a student's own submission — a student
   marking their own homework done, visible to the teacher afterward. */
function authrenMarkHomeworkDone(hwId, studentId, actor) {
  const a = actor || {};
  const rec = AUTHREN_HOMEWORK.records.find(r => r.id === hwId);
  if (!rec) return { ok: false, message: 'Homework not found.' };
  rec.submissions[studentId] = 'done';
  if (typeof authrenLogAudit === 'function') {
    authrenLogAudit(a.role || 'student', a.id || studentId, 'Homework Marked Done', 'Homework', rec.title, '', 'done');
  }
  return { ok: true, record: rec };
}

/* Seed Mr. Bensalem's one real, connected homework — hw4 in
   TEACHER_DATA.homework, currently a draft — as already published,
   so opening the Student or Guardian role shows it immediately. The
   teacher-side draft can still be independently published again from
   the UI to prove the live path, same as grades. */
(function seedYoussefHomework() {
  authrenPublishHomework(
    {
      id: 'hw4', classId: 'cl-g10a', subjectId: 'phys', teacherId: 'p-bensalem-karim',
      title: 'Lab Report: Forces', description: "Write up your findings from last week's experiment.",
      instructions: 'Include hypothesis, method, results and conclusion.',
      dueDate: '2026-03-15', attachments: [], createdAt: '2026-03-10',
      submissions: { 'S12345678': 'pending' },
    },
    { role: 'teacher', id: 'p-bensalem-karim' }
  );
})();
