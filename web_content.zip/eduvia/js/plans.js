/* ════════════════════════════════════════════════════════════
   AUTHREN — CANONICAL PLAN CATALOG
   SINGLE SOURCE OF TRUTH for plan names, features and pricing.

   Before this file existed the same four plans were defined in four
   different places (the public pricing page, the onboarding price book,
   the Head subscription screen and the Institution subscription screen)
   and they disagreed on names, prices and features. Everything now
   reads from here.

   Loaded before every other script so all roles can use it.
════════════════════════════════════════════════════════════ */

const AUTHREN_PLAN_ORDER = ['START', 'GROWTH', 'COMMAND', 'ELITE'];

/* Feature lists are cumulative: each tier inherits everything below it.
   Every entry here corresponds to a feature that genuinely exists in the
   product — nothing is listed that the app cannot do. */
const AUTHREN_PLANS = {
  START: {
    id: 'START',
    name: 'AUTHREN START',
    tagline: 'Core school management',
    features: [
      'Student profile & Authren ID',
      'Grades, exams & attendance',
      'Class & teacher timetables',
      'Automatic timetable builder & conflict checks',
      'Multi-child guardian account',
      'Teacher class & grade management',
      'Head dashboard & enrollment',
      'School calendar & basic reports',
      'Homework tracking',
      'Basic communication',
      'Password recovery & security',
      'Subscription management',
    ],
  },
  GROWTH: {
    id: 'GROWTH',
    name: 'AUTHREN GROWTH',
    tagline: 'For growing institutions',
    inherits: 'START',
    features: [
      'Complete student history',
      'Advanced attendance & streaks',
      'Academic progress graphs',
      'Grade calculator & target average',
      'Anonymous rating system',
      'Orientation & study-path guidance',
      'Bulk data import (Excel/CSV)',
      'School payments & receipts',
      'Anonymous reclamation system',
      'Absence justification & uploads',
    ],
  },
  COMMAND: {
    id: 'COMMAND',
    name: 'AUTHREN COMMAND',
    tagline: 'Full institutional insight',
    inherits: 'GROWTH',
    features: [
      'Student 360 & full performance profile',
      'School Pulse & What Changed?',
      'Performance prediction & trend analysis',
      'All-time leaderboards & Top 10 rankings',
      'Advanced orientation & career guidance',
      'Problem detection & risk indicators',
      'Advanced school-wide analytics',
      'Advanced reports & historical comparisons',
    ],
  },
  ELITE: {
    id: 'ELITE',
    name: 'AUTHREN ELITE',
    tagline: 'Multi-campus & white label',
    inherits: 'COMMAND',
    features: [
      'Complete family command center',
      'Cross-child academic overview',
      'Advanced school forecasting',
      'Full school intelligence center',
      'Advanced institution reporting',
      'Multi-campus architecture',
      'White-label / custom branding',
      'Advanced document management',
      'Advanced audit & administration',
    ],
  },
};

function authrenPlan(planId) {
  return AUTHREN_PLANS[planId] || null;
}

/* Full cumulative feature list for a tier (its own features plus every
   tier it inherits from). */
function authrenPlanFeatures(planId) {
  const plan = authrenPlan(planId);
  if (!plan) return [];
  const inherited = plan.inherits ? authrenPlanFeatures(plan.inherits) : [];
  return inherited.concat(plan.features);
}

/* Short list used on the in-app subscription screens: the "Everything in
   X" line plus this tier's own additions, so those screens stay
   consistent with the public pricing page without repeating 40 lines. */
function authrenPlanSummary(planId) {
  const plan = authrenPlan(planId);
  if (!plan) return [];
  const prefix = plan.inherits
    ? ['Everything in ' + (authrenPlan(plan.inherits) || {}).name]
    : [];
  return prefix.concat(plan.features);
}

/* Price for a tier at the institution's current student band and billing
   cycle. Delegates to the price book in onboarding.js so there is still
   only one pricing engine; falls back gracefully if that file has not
   loaded (e.g. a role screen opened without the onboarding flow). */
function authrenPlanPriceLabel(planId, bandId, cycleId) {
  if (typeof authrenPlanPrice !== 'function') return '';
  const p = authrenPlanPrice(planId, bandId || 'b100', cycleId || 'monthly');
  const cur = (typeof authrenCurrency === 'function') ? authrenCurrency() : 'MAD';
  if (!p || p.custom) return 'Custom pricing';
  return p.perMonth + ' ' + cur + '/mo';
}
