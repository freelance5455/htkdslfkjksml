GERADOR DE SENSI XITADA 🎯
Projeto Android WebView atualizado para tema vermelho e preto.
Campos: marca, modelo do celular e estilo de jogo. RAM e taxa de atualização removidas.
Para gerar APK: abrir a pasta no Android Studio e usar Build > Build APK(s).
