MAH: COMPLETE CHRONICLE - ANDROID PROJECT

This is an Android Studio project that wraps the offline Mah HTML game in a native Android WebView.
The game is bundled at app/src/main/assets/index.html. It does not require internet permission.

BUILDING
1. Open this folder in Android Studio on a computer.
2. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
3. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The debug APK will normally appear at app/build/outputs/apk/debug/app-debug.apk.
5. Copy that APK to the phone and install it. Android may ask you to allow installs from the file manager you used.

NOTES
- This ZIP is source code, not an APK.
- Requires Android Gradle Plugin 8.7.3 and a compatible Gradle 8.9 installation/wrapper.
- Minimum Android version is Android 6.0 (API 23).
- The app loads the bundled HTML locally. Game saves use the WebView's local storage.
- No network permission is declared.
