// End-to-end smoke test in demo mode (no Qwen key, no connectors configured).
// Run with: npm test
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';

const PORT = 3900 + Math.floor(Math.random() * 90);
const TOKEN = 'test-token';
const BASE = `http://127.0.0.1:${PORT}`;
const dataFile = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'jarvis-test-')), 'store.json');

// Pre-seed an already-approved post that is due, to exercise the scheduler.
const dueId = '00000000-0000-4000-8000-000000000001';
fs.writeFileSync(
  dataFile,
  JSON.stringify({
    approvals: [
      {
        id: dueId, kind: 'social_post', summary: 'FACEBOOK: scheduled hello', payload: { platform: 'facebook', text: 'scheduled hello' },
        runAt: new Date(Date.now() - 1000).toISOString(), status: 'approved', result: null, createdAt: new Date().toISOString(),
      },
    ],
  }),
);

const env = { ...process.env, PORT: String(PORT), JARVIS_TOKEN: TOKEN, JARVIS_DATA_FILE: dataFile, JARVIS_TICK_MS: '200' };
for (const k of ['QWEN_API_KEY', 'FACEBOOK_PAGE_ID', 'FACEBOOK_PAGE_TOKEN', 'X_ACCESS_TOKEN', 'SHOPIFY_SHOP', 'SHOPIFY_ACCESS_TOKEN']) delete env[k];

const child = spawn(process.execPath, [new URL('../src/index.js', import.meta.url).pathname], { env, stdio: ['ignore', 'pipe', 'inherit'] });
let passed = 0;
const step = async (name, fn) => { await fn(); passed++; console.log('  ok  ' + name); };

async function call(method, p, { body, token = TOKEN, raw } = {}) {
  const res = await fetch(BASE + p, {
    method,
    headers: { ...(token ? { Authorization: 'Bearer ' + token } : {}), 'Content-Type': 'application/json' },
    body: raw !== undefined ? raw : body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  let json = null;
  try { json = JSON.parse(text); } catch {}
  return { status: res.status, json, text };
}

async function waitForServer() {
  await new Promise((resolve, reject) => {
    const t = setTimeout(() => reject(new Error('server did not start')), 8000);
    child.stdout.on('data', (d) => { if (String(d).includes('Jarvis server on')) { clearTimeout(t); resolve(); } });
    child.on('exit', (c) => reject(new Error('server exited early with code ' + c)));
  });
}

try {
  await waitForServer();

  await step('health check needs no token', async () => {
    assert.equal((await call('GET', '/healthz', { token: null })).status, 200);
  });

  await step('API rejects missing and wrong tokens', async () => {
    assert.equal((await call('GET', '/api/status', { token: null })).status, 401);
    assert.equal((await call('GET', '/api/status', { token: 'nope' })).status, 401);
  });

  await step('status reports demo mode and no connectors', async () => {
    const r = await call('GET', '/api/status');
    assert.equal(r.status, 200);
    assert.equal(r.json.mode, 'demo');
    assert.deepEqual(r.json.connectors, { facebook: false, x: false, shopify: false });
  });

  await step('scheduler publishes an approved post once it is due', async () => {
    let item;
    for (let i = 0; i < 30; i++) {
      item = (await call('GET', '/api/approvals')).json.approvals.find((a) => a.id === dueId);
      if (item.status !== 'approved') break;
      await new Promise((r) => setTimeout(r, 100));
    }
    assert.equal(item.status, 'done');
    assert.equal(item.result.dryRun, true);
  });

  let approvalId;
  await step('chat queues a post for approval instead of posting', async () => {
    const r = await call('POST', '/api/chat', { body: { text: 'post hello world on facebook', sessionId: 't1' } });
    assert.equal(r.status, 200, r.text);
    assert.equal(r.json.newApprovals.length, 1);
    assert.match(r.json.reply, /not|approval|waiting/i);
    approvalId = r.json.newApprovals[0].id;
    const pending = (await call('GET', '/api/approvals?status=pending')).json.approvals;
    assert.ok(pending.some((a) => a.id === approvalId));
  });

  await step('approving runs the post (dry run without credentials)', async () => {
    const r = await call('POST', `/api/approvals/${approvalId}/approve`, { body: {} });
    assert.equal(r.status, 200, r.text);
    assert.equal(r.json.approval.status, 'done');
    assert.equal(r.json.approval.result.dryRun, true);
    assert.equal((await call('POST', `/api/approvals/${approvalId}/approve`, { body: {} })).status, 409);
  });

  await step('rejecting works and cannot be undone', async () => {
    const q = await call('POST', '/api/chat', { body: { text: 'post second thing on facebook', sessionId: 't2' } });
    const id = q.json.newApprovals[0].id;
    const r = await call('POST', `/api/approvals/${id}/reject`, { body: {} });
    assert.equal(r.json.approval.status, 'rejected');
    assert.equal((await call('POST', `/api/approvals/${id}/approve`, { body: {} })).status, 409);
  });

  await step('X posts over 280 characters are refused before queuing', async () => {
    const r = await call('POST', '/api/chat', { body: { text: `post ${'a'.repeat(300)} on x`, sessionId: 't3' } });
    assert.equal(r.json.newApprovals.length, 0);
    assert.match(r.json.reply, /280/);
  });

  await step('phone actions are sent only to the Android client', async () => {
    const phone = await call('POST', '/api/chat', { body: { text: 'open YouTube', sessionId: 't4', client: 'android' } });
    assert.deepEqual(phone.json.deviceActions, [{ action: 'open_app', target: 'YouTube', text: null, direction: null }]);
    const web = await call('POST', '/api/chat', { body: { text: 'open YouTube', sessionId: 't5', client: 'web' } });
    assert.equal(web.json.deviceActions.length, 0);
    assert.match(web.json.reply, /phone/i);
  });

  await step('shop tools degrade gracefully when Shopify is not configured', async () => {
    const r = await call('POST', '/api/chat', { body: { text: 'show my orders', sessionId: 't6' } });
    assert.equal(r.status, 200, r.text);
    assert.ok(r.json.reply.length > 0);
  });

  await step('bad input is rejected cleanly', async () => {
    assert.equal((await call('POST', '/api/chat', { raw: '{not json' })).status, 400);
    assert.equal((await call('POST', '/api/chat', { body: { text: '   ' } })).status, 400);
  });

  await step('dashboard is served and path traversal is blocked', async () => {
    const page = await call('GET', '/', { token: null });
    assert.equal(page.status, 200);
    assert.match(page.text, /<title>Jarvis<\/title>/);
    const evil = await call('GET', '/..%2f..%2fsrc%2fconfig.js', { token: null });
    assert.notEqual(evil.status, 200);
  });

  console.log(`\n${passed} checks passed`);
} catch (err) {
  console.error('\nFAILED after ' + passed + ' checks:\n', err);
  process.exitCode = 1;
} finally {
  child.kill();
}
