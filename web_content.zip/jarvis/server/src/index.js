import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { config, connectorStatus } from './config.js';
import { llmIsLive } from './llm.js';
import { runAgent } from './agent.js';
import { listApprovals, getApproval, updateApproval } from './store.js';
import { executeApproval } from './tools.js';

const PUBLIC_DIR = fileURLToPath(new URL('../public/', import.meta.url));
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
};

function sendJson(res, status, body) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(body));
}

class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.statusCode = status;
  }
}

async function readJson(req, limit = 100_000) {
  let size = 0;
  const chunks = [];
  for await (const chunk of req) {
    size += chunk.length;
    if (size > limit) throw new HttpError(413, 'Request body too large');
    chunks.push(chunk);
  }
  if (size === 0) return {};
  try {
    return JSON.parse(Buffer.concat(chunks).toString('utf8'));
  } catch {
    throw new HttpError(400, 'Invalid JSON');
  }
}

function tokenOk(provided) {
  const a = Buffer.from(String(provided || ''));
  const b = Buffer.from(config.token);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

function requireAuth(req) {
  const header = req.headers.authorization || '';
  const provided = header.startsWith('Bearer ') ? header.slice(7) : '';
  if (!tokenOk(provided)) throw new HttpError(401, 'Unauthorized');
}

function serveStatic(req, res, pathname) {
  let rel;
  try {
    rel = pathname === '/' ? 'index.html' : decodeURIComponent(pathname.slice(1));
  } catch {
    throw new HttpError(400, 'Bad path');
  }
  const full = path.resolve(PUBLIC_DIR, rel);
  if (!full.startsWith(PUBLIC_DIR)) throw new HttpError(403, 'Forbidden');
  fs.readFile(full, (err, data) => {
    if (err) return sendJson(res, 404, { error: 'Not found' });
    res.writeHead(200, {
      'Content-Type': MIME[path.extname(full).toLowerCase()] || 'application/octet-stream',
      'X-Content-Type-Options': 'nosniff',
    });
    res.end(req.method === 'HEAD' ? undefined : data);
  });
}

async function runItem(item) {
  try {
    const result = await executeApproval(item);
    updateApproval(item.id, { status: 'done', result });
  } catch (err) {
    updateApproval(item.id, { status: 'failed', result: { error: String(err.message || err) } });
  }
  return getApproval(item.id);
}

async function handleApi(req, res, url) {
  requireAuth(req);
  const p = url.pathname;

  if (req.method === 'GET' && p === '/api/status') {
    return sendJson(res, 200, {
      mode: llmIsLive() ? 'live' : 'demo',
      model: llmIsLive() ? config.llm.model : null,
      connectors: connectorStatus(),
    });
  }

  if (req.method === 'POST' && p === '/api/chat') {
    const body = await readJson(req);
    const text = String(body.text || '').trim();
    if (!text) throw new HttpError(400, 'text is required');
    const sessionId = String(body.sessionId || 'default').slice(0, 64);
    const client = body.client === 'android' ? 'android' : 'web';
    try {
      return sendJson(res, 200, await runAgent({ sessionId, text, client }));
    } catch (err) {
      console.error(err);
      throw new HttpError(502, String(err.message || err));
    }
  }

  if (req.method === 'GET' && p === '/api/approvals') {
    const status = url.searchParams.get('status') || undefined;
    return sendJson(res, 200, { approvals: listApprovals(status).slice(0, 50) });
  }

  const m = p.match(/^\/api\/approvals\/([\w-]+)\/(approve|reject)$/);
  if (req.method === 'POST' && m) {
    const [, id, action] = m;
    const item = getApproval(id);
    if (!item) throw new HttpError(404, 'Not found');
    if (item.status !== 'pending') throw new HttpError(409, `Already ${item.status}`);
    if (action === 'reject') {
      return sendJson(res, 200, { approval: updateApproval(id, { status: 'rejected' }) });
    }
    updateApproval(id, { status: 'approved' });
    const due = !item.runAt || Date.parse(item.runAt) <= Date.now();
    return sendJson(res, 200, { approval: due ? await runItem(item) : getApproval(id) });
  }

  throw new HttpError(404, 'Not found');
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://localhost');
    if (req.method === 'GET' && url.pathname === '/healthz') return sendJson(res, 200, { ok: true });
    if (url.pathname.startsWith('/api/')) return await handleApi(req, res, url);
    if (req.method === 'GET' || req.method === 'HEAD') return serveStatic(req, res, url.pathname);
    throw new HttpError(404, 'Not found');
  } catch (err) {
    if (!(err instanceof HttpError)) console.error(err);
    if (!res.headersSent) sendJson(res, err.statusCode || 500, { error: err.statusCode ? err.message : 'Server error' });
  }
});

// Scheduler: publishes approved items once their scheduled time arrives.
let ticking = false;
async function tick() {
  if (ticking) return;
  ticking = true;
  try {
    for (const item of listApprovals('approved')) {
      if (item.runAt && Date.parse(item.runAt) <= Date.now()) await runItem(item);
    }
  } finally {
    ticking = false;
  }
}
setInterval(tick, config.tickMs).unref();

server.listen(config.port, () => {
  console.log(`Jarvis server on http://localhost:${config.port}`);
  console.log(`Mode: ${llmIsLive() ? `live (${config.llm.model})` : 'demo (set QWEN_API_KEY for real Qwen3)'}`);
  if (config.tokenWasGenerated) {
    console.log(`Access token (set JARVIS_TOKEN to make it permanent): ${config.token}`);
  }
});
