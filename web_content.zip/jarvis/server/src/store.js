import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { config } from './config.js';

// Tiny JSON-file store for approvals. Swap for a real database if you scale this up.
let state = { approvals: [] };

function load() {
  try {
    state = JSON.parse(fs.readFileSync(config.dataFile, 'utf8'));
    if (!Array.isArray(state.approvals)) state.approvals = [];
  } catch {
    state = { approvals: [] };
  }
}

function save() {
  fs.mkdirSync(path.dirname(config.dataFile), { recursive: true });
  fs.writeFileSync(config.dataFile, JSON.stringify(state, null, 2));
}

load();

export function addApproval({ kind, summary, payload, runAt = null }) {
  const item = {
    id: crypto.randomUUID(),
    kind,
    summary,
    payload,
    runAt, // ISO string or null (null = run as soon as approved)
    status: 'pending', // pending | approved | rejected | done | failed
    result: null,
    createdAt: new Date().toISOString(),
  };
  state.approvals.push(item);
  save();
  return item;
}

export function listApprovals(status) {
  const items = status ? state.approvals.filter((a) => a.status === status) : state.approvals;
  return items.slice().reverse();
}

export function getApproval(id) {
  return state.approvals.find((a) => a.id === id) || null;
}

export function updateApproval(id, patch) {
  const item = getApproval(id);
  if (!item) return null;
  Object.assign(item, patch);
  save();
  return item;
}
