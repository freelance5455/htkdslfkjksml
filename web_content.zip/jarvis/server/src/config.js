import crypto from 'node:crypto';

const env = process.env;

function parseJson(text, fallback) {
  if (!text) return fallback;
  try {
    return JSON.parse(text);
  } catch {
    console.warn('Ignoring invalid JSON in environment variable');
    return fallback;
  }
}

// Access token the dashboard and the phone must send. Set JARVIS_TOKEN yourself in production.
const generatedToken = crypto.randomBytes(16).toString('hex');

export const config = {
  port: Number(env.PORT || 3000),
  tickMs: Number(env.JARVIS_TICK_MS || 30_000), // how often the scheduler checks for due posts
  token: env.JARVIS_TOKEN || generatedToken,
  tokenWasGenerated: !env.JARVIS_TOKEN,
  dataFile: env.JARVIS_DATA_FILE || new URL('../data/store.json', import.meta.url).pathname,

  // Qwen3 through any OpenAI-compatible endpoint.
  // Defaults target Alibaba Cloud Model Studio (international). For OpenRouter use
  // QWEN_BASE_URL=https://openrouter.ai/api/v1 and QWEN_MODEL=qwen/qwen3-235b-a22b
  // Check the exact model name in your provider's console.
  llm: {
    apiKey: env.QWEN_API_KEY || '',
    baseUrl: (env.QWEN_BASE_URL || 'https://dashscope-intl.aliyuncs.com/compatible-mode/v1').replace(/\/$/, ''),
    model: env.QWEN_MODEL || 'qwen3-235b-a22b',
    // Qwen3 hybrid-thinking models on DashScope need enable_thinking=false for non-streaming calls.
    extraBody: parseJson(env.QWEN_EXTRA_BODY, { enable_thinking: false }),
  },

  facebook: {
    pageId: env.FACEBOOK_PAGE_ID || '',
    pageToken: env.FACEBOOK_PAGE_TOKEN || '',
  },
  x: {
    // OAuth 2.0 user-context access token with tweet.write scope
    accessToken: env.X_ACCESS_TOKEN || '',
  },
  shopify: {
    shop: env.SHOPIFY_SHOP || '', // e.g. my-store.myshopify.com
    accessToken: env.SHOPIFY_ACCESS_TOKEN || '',
    apiVersion: env.SHOPIFY_API_VERSION || '2024-10',
  },
};

export function connectorStatus() {
  return {
    facebook: Boolean(config.facebook.pageId && config.facebook.pageToken),
    x: Boolean(config.x.accessToken),
    shopify: Boolean(config.shopify.shop && config.shopify.accessToken),
  };
}
