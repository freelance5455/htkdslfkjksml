import { config } from './config.js';

export function llmIsLive() {
  return Boolean(config.llm.apiKey);
}

function stripThinking(text) {
  return (text || '').replace(/<think>[\s\S]*?<\/think>/g, '').trim();
}

// Sends messages (+ tool definitions) to Qwen3 and returns the assistant message.
export async function chatCompletion({ messages, tools }) {
  if (!llmIsLive()) return mockCompletion(messages);

  const res = await fetch(`${config.llm.baseUrl}/chat/completions`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${config.llm.apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: config.llm.model,
      messages,
      tools,
      tool_choice: 'auto',
      temperature: 0.6,
      ...config.llm.extraBody,
    }),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(`Qwen API error ${res.status}: ${JSON.stringify(data).slice(0, 400)}`);
  }
  const msg = data?.choices?.[0]?.message;
  if (!msg) throw new Error('Qwen API returned no message');
  return { ...msg, content: stripThinking(msg.content) };
}

// Offline stand-in used when QWEN_API_KEY is not set, so the whole pipeline can be tried
// without a key. It understands a few fixed phrasings and is NOT an AI model.
function mockCompletion(messages) {
  const last = messages[messages.length - 1];

  if (last.role === 'tool') {
    let detail = '';
    try {
      const r = JSON.parse(last.content);
      detail = r.error || r.note || (r.queued ? 'It is queued for your approval.' : 'Done.');
    } catch {
      detail = 'Done.';
    }
    return { role: 'assistant', content: detail };
  }

  const text = (last.content || '').trim();
  let m = text.match(/post\s+(.+?)\s+(?:on|to)\s+(facebook|x|twitter)\b/i);
  if (m) {
    return toolCall('social_post', { platform: m[2].toLowerCase() === 'facebook' ? 'facebook' : 'x', text: m[1] });
  }
  m = text.match(/^open\s+(.+)$/i);
  if (m) return toolCall('phone_action', { action: 'open_app', target: m[1] });
  if (/orders?/i.test(text)) return toolCall('shop_list_orders', { status: 'open', limit: 5 });

  return {
    role: 'assistant',
    content:
      'I am running in demo mode because no Qwen API key is set. Add QWEN_API_KEY and I will understand normal language. For now try: post hello world on facebook, open YouTube, or show my orders.',
  };
}

function toolCall(name, args) {
  return {
    role: 'assistant',
    content: '',
    tool_calls: [
      { id: `mock_${Date.now()}`, type: 'function', function: { name, arguments: JSON.stringify(args) } },
    ],
  };
}
