import { chatCompletion } from './llm.js';
import { toolDefinitions, runTool } from './tools.js';

const SYSTEM_PROMPT = `You are Jarvis, a personal assistant for one owner. You manage their social media accounts, their dropshipping store and their digital marketing, and when the request comes from their Android phone you can operate apps on it.

Rules:
- Your replies are spoken aloud. Keep them short, natural and free of markdown, lists and emojis.
- Publishing a post or changing a price always goes through the approval queue. After queuing, say it is waiting for approval. Never say something was posted or changed unless a tool result says so.
- If a request is missing something you need (which platform, what text, which product), ask one short question instead of guessing.
- For marketing work (captions, ad copy, campaign plans, content calendars) write the content yourself and, when asked to publish, queue it with social_post.
- Only use phone_action when the owner clearly wants something done on the phone.
- If a tool returns an error, tell the owner plainly what went wrong.`;

const sessions = new Map(); // sessionId -> messages (without the system prompt)
const MAX_HISTORY = 24;
const MAX_STEPS = 5;

export async function runAgent({ sessionId, text, client }) {
  const history = sessions.get(sessionId) || [];
  history.push({ role: 'user', content: text });

  const ctx = { client, deviceActions: [], newApprovals: [] };
  let reply = '';

  for (let step = 0; step < MAX_STEPS; step++) {
    const messages = [{ role: 'system', content: SYSTEM_PROMPT }, ...history];
    const msg = await chatCompletion({ messages, tools: toolDefinitions });
    history.push(msg);

    if (!msg.tool_calls || msg.tool_calls.length === 0) {
      reply = msg.content || '';
      break;
    }

    for (const call of msg.tool_calls) {
      let args = {};
      try {
        args = JSON.parse(call.function.arguments || '{}');
      } catch {
        args = {};
      }
      let result;
      try {
        result = await runTool(call.function.name, args, ctx);
      } catch (err) {
        result = { error: String(err.message || err) };
      }
      history.push({ role: 'tool', tool_call_id: call.id, content: JSON.stringify(result) });
    }
  }

  if (!reply) reply = 'Sorry, I could not finish that. Please try again.';

  // Keep history bounded, and never start it on an orphaned tool message.
  let trimmed = history.slice(-MAX_HISTORY);
  while (trimmed.length && trimmed[0].role !== 'user') trimmed = trimmed.slice(1);
  sessions.set(sessionId, trimmed);

  return { reply, deviceActions: ctx.deviceActions, newApprovals: ctx.newApprovals };
}
