import { config } from '../config.js';

// Publishes a text post to a Facebook Page using the Graph API.
// Needs FACEBOOK_PAGE_ID and a Page access token with pages_manage_posts.
export async function postToFacebook({ text }) {
  const { pageId, pageToken } = config.facebook;
  if (!pageId || !pageToken) {
    return { dryRun: true, note: 'Facebook is not configured, nothing was posted.' };
  }
  const res = await fetch(`https://graph.facebook.com/v21.0/${encodeURIComponent(pageId)}/feed`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ message: text, access_token: pageToken }),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(`Facebook error ${res.status}: ${JSON.stringify(data)}`);
  return { posted: true, id: data.id };
}
