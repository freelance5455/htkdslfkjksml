import { config } from '../config.js';

function base() {
  const { shop, accessToken, apiVersion } = config.shopify;
  if (!shop || !accessToken) return null;
  return {
    url: `https://${shop}/admin/api/${apiVersion}`,
    headers: { 'X-Shopify-Access-Token': accessToken, 'Content-Type': 'application/json' },
  };
}

async function call(method, pathAndQuery, body) {
  const b = base();
  if (!b) return { dryRun: true, note: 'Shopify is not configured.' };
  const res = await fetch(b.url + pathAndQuery, {
    method,
    headers: b.headers,
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(`Shopify error ${res.status}: ${JSON.stringify(data)}`);
  return data;
}

export async function listOrders({ status = 'open', limit = 10 } = {}) {
  const data = await call('GET', `/orders.json?status=${encodeURIComponent(status)}&limit=${Number(limit) || 10}`);
  if (data.dryRun) return data;
  return {
    orders: (data.orders || []).map((o) => ({
      id: o.id,
      name: o.name,
      total: o.total_price,
      currency: o.currency,
      paid: o.financial_status,
      fulfilled: o.fulfillment_status || 'unfulfilled',
      createdAt: o.created_at,
    })),
  };
}

export async function listProducts({ limit = 10 } = {}) {
  const data = await call('GET', `/products.json?limit=${Number(limit) || 10}`);
  if (data.dryRun) return data;
  return {
    products: (data.products || []).map((p) => ({
      id: p.id,
      title: p.title,
      status: p.status,
      variants: (p.variants || []).map((v) => ({ id: v.id, title: v.title, price: v.price, inventory: v.inventory_quantity })),
    })),
  };
}

export async function setVariantPrice({ variantId, price }) {
  const data = await call('PUT', `/variants/${encodeURIComponent(variantId)}.json`, {
    variant: { id: Number(variantId), price: String(price) },
  });
  if (data.dryRun) return data;
  return { updated: true, variantId, price: data.variant?.price };
}
