import { config } from '../config.js';

// Publishes a post on X using the v2 API (POST /2/tweets).
// Needs an OAuth 2.0 user-context access token with the tweet.write scope.
export async function postToX({ text }) {
  const { accessToken } = config.x;
  if (!accessToken) {
    return { dryRun: true, note: 'X is not configured, nothing was posted.' };
  }
  if (text.length > 280) {
    throw new Error(`Post is ${text.length} characters, X allows 280 on standard accounts.`);
  }
  const res = await fetch('https://api.x.com/2/tweets', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ text }),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(`X error ${res.status}: ${JSON.stringify(data)}`);
  return { posted: true, id: data?.data?.id };
}
