import { addApproval } from './store.js';
import { postToFacebook } from './connectors/facebook.js';
import { postToX } from './connectors/x.js';
import { listOrders, listProducts, setVariantPrice } from './connectors/shopify.js';

// Tool definitions in OpenAI function-calling format (Qwen3 supports this).
export const toolDefinitions = [
  {
    type: 'function',
    function: {
      name: 'social_post',
      description:
        'Queue a social media post for the owner to approve. Nothing is published until the owner approves it. Optionally schedule it for later.',
      parameters: {
        type: 'object',
        properties: {
          platform: { type: 'string', enum: ['facebook', 'x'] },
          text: { type: 'string', description: 'Final post text. X posts must be 280 characters or fewer.' },
          publish_at: { type: 'string', description: 'Optional ISO 8601 time to publish, e.g. 2026-10-22T09:00:00+01:00' },
        },
        required: ['platform', 'text'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'shop_list_orders',
      description: 'List recent Shopify orders for the dropshipping store.',
      parameters: {
        type: 'object',
        properties: {
          status: { type: 'string', enum: ['open', 'closed', 'any'] },
          limit: { type: 'integer' },
        },
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'shop_list_products',
      description: 'List products and variants (with ids, prices and stock) in the Shopify store.',
      parameters: { type: 'object', properties: { limit: { type: 'integer' } } },
    },
  },
  {
    type: 'function',
    function: {
      name: 'shop_set_price',
      description: 'Queue a price change for one product variant. Needs owner approval before it is applied.',
      parameters: {
        type: 'object',
        properties: {
          variant_id: { type: 'string' },
          price: { type: 'string', description: 'New price as a decimal string, e.g. "19.99"' },
        },
        required: ['variant_id', 'price'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'phone_action',
      description:
        'Do something on the owner\'s Android phone. Only works when the request comes from the phone app. Actions: open_app (target = app name), click_text (target = visible text), type_text (text), scroll (direction up or down), back, home.',
      parameters: {
        type: 'object',
        properties: {
          action: { type: 'string', enum: ['open_app', 'click_text', 'type_text', 'scroll', 'back', 'home'] },
          target: { type: 'string' },
          text: { type: 'string' },
          direction: { type: 'string', enum: ['up', 'down'] },
        },
        required: ['action'],
      },
    },
  },
];

// ctx collects side effects the caller needs to know about.
export async function runTool(name, args, ctx) {
  switch (name) {
    case 'social_post': {
      const { platform, text, publish_at: publishAt } = args;
      if (!['facebook', 'x'].includes(platform)) return { error: 'Unsupported platform. Use facebook or x.' };
      if (!text || !text.trim()) return { error: 'Post text is empty.' };
      if (platform === 'x' && text.length > 280) {
        return { error: `That is ${text.length} characters, X allows 280. Shorten it and try again.` };
      }
      let runAt = null;
      if (publishAt) {
        const t = Date.parse(publishAt);
        if (Number.isNaN(t)) return { error: 'publish_at is not a valid ISO 8601 time.' };
        runAt = new Date(t).toISOString();
      }
      const item = addApproval({
        kind: 'social_post',
        summary: `${platform.toUpperCase()}${runAt ? ` at ${runAt}` : ''}: ${text.slice(0, 140)}`,
        payload: { platform, text },
        runAt,
      });
      ctx.newApprovals.push(item);
      return { queued: true, approvalId: item.id, note: 'Waiting for the owner to approve. It has NOT been posted.' };
    }
    case 'shop_list_orders':
      return listOrders(args);
    case 'shop_list_products':
      return listProducts(args);
    case 'shop_set_price': {
      if (!args.variant_id || !args.price || Number.isNaN(Number(args.price))) {
        return { error: 'variant_id and a numeric price are required.' };
      }
      const item = addApproval({
        kind: 'shop_set_price',
        summary: `Set variant ${args.variant_id} price to ${args.price}`,
        payload: { variantId: args.variant_id, price: args.price },
      });
      ctx.newApprovals.push(item);
      return { queued: true, approvalId: item.id, note: 'Waiting for the owner to approve. Price NOT changed yet.' };
    }
    case 'phone_action': {
      if (ctx.client !== 'android') {
        return { error: 'No phone connected to this request. Phone actions only work from the Android app.' };
      }
      ctx.deviceActions.push({
        action: args.action,
        target: args.target || null,
        text: args.text || null,
        direction: args.direction || null,
      });
      return { sentToPhone: true };
    }
    default:
      return { error: `Unknown tool ${name}` };
  }
}

// Runs an approved item. Called when the owner approves, or by the scheduler when its time comes.
export async function executeApproval(item) {
  switch (item.kind) {
    case 'social_post':
      return item.payload.platform === 'x' ? postToX(item.payload) : postToFacebook(item.payload);
    case 'shop_set_price':
      return setVariantPrice(item.payload);
    default:
      throw new Error(`Unknown approval kind ${item.kind}`);
  }
}
