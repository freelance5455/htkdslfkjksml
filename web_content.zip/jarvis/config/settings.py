from functools import lru_cache
from pathlib import Path
from pydantic import Field, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_prefix="JARVIS_", extra="ignore")
    app_name: str = "JARVIS"
    env: str = "development"
    host: str = "127.0.0.1"
    port: int = 8000
    database_path: str = "./data/jarvis.db"
    allowed_roots: str = "./workspace"
    memory_enabled: bool = True
    ai_provider: str = "openai"
    ai_base_url: str = "https://api.openai.com/v1"
    ai_api_key: SecretStr = SecretStr("")
    access_token: SecretStr = SecretStr("")
    ai_model: str = ""
    ai_timeout_seconds: float = 45
    fish_audio_api_key: SecretStr = SecretStr("")
    fish_audio_model_id: str = ""
    web_search_api_key: SecretStr = SecretStr("")
    weather_api_key: SecretStr = SecretStr("")
    wake_word_enabled: bool = False

    def allowed_root_paths(self) -> list[Path]:
        paths = [Path(p).expanduser().resolve() for p in self.allowed_roots.split(",") if p.strip()]
        return paths

@lru_cache
def get_settings() -> Settings:
    return Settings()
