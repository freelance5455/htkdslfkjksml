"""Provider adapters. OpenAI uses the Responses API; secrets stay server-side."""
from abc import ABC, abstractmethod
from collections.abc import AsyncIterator
import json
import httpx
from config.settings import get_settings

class AIProvider(ABC):
    @abstractmethod
    async def complete(self, messages: list[dict]) -> str: ...
    async def stream(self, messages: list[dict]) -> AsyncIterator[str]:
        yield await self.complete(messages)

class OpenAIResponsesProvider(AIProvider):
    """OpenAI Responses API adapter using HTTPX to keep dependencies light."""
    def _config(self):
        cfg = get_settings()
        key = cfg.ai_api_key.get_secret_value()
        if not key or not cfg.ai_model:
            raise RuntimeError("Configure JARVIS_AI_API_KEY and JARVIS_AI_MODEL in your .env file.")
        return cfg, key

    @staticmethod
    def _input(messages: list[dict]) -> list[dict]:
        # Responses API accepts role/content message items.
        return [{"role": m["role"], "content": m["content"]} for m in messages if m.get("role") in {"system", "user", "assistant"}]

    @staticmethod
    def _extract_text(data: dict) -> str:
        if isinstance(data.get("output_text"), str) and data["output_text"]:
            return data["output_text"]
        parts = []
        for item in data.get("output", []):
            if item.get("type") == "message":
                for content in item.get("content", []):
                    if content.get("type") == "output_text":
                        parts.append(content.get("text", ""))
        return "".join(parts).strip()

    async def complete(self, messages: list[dict]) -> str:
        cfg, key = self._config()
        url = cfg.ai_base_url.rstrip("/") + "/responses"
        headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
        payload = {"model": cfg.ai_model, "input": self._input(messages)}
        async with httpx.AsyncClient(timeout=cfg.ai_timeout_seconds) as client:
            response = await client.post(url, headers=headers, json=payload)
            response.raise_for_status()
        data = response.json()
        text = self._extract_text(data)
        if not text:
            raise RuntimeError("The AI provider returned no text output.")
        return text

    async def stream(self, messages: list[dict]) -> AsyncIterator[str]:
        cfg, key = self._config()
        url = cfg.ai_base_url.rstrip("/") + "/responses"
        headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
        payload = {"model": cfg.ai_model, "input": self._input(messages), "stream": True}
        async with httpx.AsyncClient(timeout=cfg.ai_timeout_seconds) as client:
            async with client.stream("POST", url, headers=headers, json=payload) as response:
                response.raise_for_status()
                async for line in response.aiter_lines():
                    if not line.startswith("data: "):
                        continue
                    raw = line[6:]
                    if raw == "[DONE]":
                        break
                    try:
                        event = json.loads(raw)
                    except json.JSONDecodeError:
                        continue
                    if event.get("type") == "response.output_text.delta":
                        delta = event.get("delta", "")
                        if delta:
                            yield delta


def get_ai_provider() -> AIProvider:
    provider = get_settings().ai_provider
    if provider in {"openai", "openai_compatible"}:
        return OpenAIResponsesProvider()
    raise RuntimeError(f"Unsupported AI provider adapter: {provider}")
