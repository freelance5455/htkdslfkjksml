"""Shared-token authentication for trusted devices on a private LAN."""
import hmac
from fastapi import Header, HTTPException, WebSocket
from config.settings import get_settings


def verify_token(token: str | None) -> bool:
    expected = get_settings().access_token.get_secret_value()
    return bool(expected and token and hmac.compare_digest(expected, token))


async def require_auth(authorization: str | None = Header(default=None)) -> None:
    token = authorization[7:].strip() if authorization and authorization.lower().startswith("bearer ") else None
    if not verify_token(token):
        raise HTTPException(status_code=401, detail="JARVIS access token is missing or invalid.", headers={"WWW-Authenticate": "Bearer"})


async def authenticate_websocket(ws: WebSocket) -> bool:
    try:
        payload = await ws.receive_json()
    except Exception:
        return False
    return payload.get("type") == "auth" and verify_token(str(payload.get("token", "")))
