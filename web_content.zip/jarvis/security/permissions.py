from enum import Enum

class Risk(str, Enum):
    LOW = "low"
    CONFIRM = "confirm"
    DENY = "deny"

CONFIRM_ACTIONS = {"file.delete", "script.execute", "app.launch", "message.send", "calendar.create"}

def risk_for(action: str) -> Risk:
    if action in CONFIRM_ACTIONS:
        return Risk.CONFIRM
    if action.startswith(("system.read", "file.read", "web.search", "note.read")):
        return Risk.LOW
    return Risk.CONFIRM
