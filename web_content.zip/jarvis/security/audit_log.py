import json, logging
from datetime import datetime, timezone

logger = logging.getLogger("jarvis.audit")

def record_action(action: str, outcome: str, details: dict | None = None) -> None:
    # Do not include secrets, file contents, or raw user credentials in audit details.
    logger.info(json.dumps({"time": datetime.now(timezone.utc).isoformat(), "action": action,
                            "outcome": outcome, "details": details or {}}, default=str))
