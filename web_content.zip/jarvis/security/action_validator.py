from pathlib import Path
from config.settings import get_settings

class PermissionError(Exception):
    pass

def resolve_allowed_path(user_path: str) -> Path:
    candidate = Path(user_path).expanduser().resolve()
    roots = get_settings().allowed_root_paths()
    if not any(candidate == root or root in candidate.parents for root in roots):
        raise PermissionError("Path is outside JARVIS approved directories.")
    return candidate
