/* =========================================================
   J.A.R.V.I.S.
   Voice + Camera + Motion System
========================================================= */


/* =========================================================
   ELEMENTS
========================================================= */

const video =
    document.getElementById("webcam");

const canvas =
    document.getElementById("motion_canvas");

const ctx =
    canvas.getContext("2d", {
        willReadFrequently: true
    });

const camStatus =
    document.getElementById("system-status");

const voiceStatus =
    document.getElementById("voice-status");

const activateButton =
    document.getElementById("activate-btn");

const cameraOnButton =
    document.getElementById("camera-on");

const cameraOffButton =
    document.getElementById("camera-off");


/* =========================================================
   CAMERA
========================================================= */

let localStream = null;

let isCamOn = false;

let previousFrame = null;

let gestureCooldown = false;

const motionThreshold = 35;


/* =========================================================
   VOICE
========================================================= */

let recognition = null;

let isListening = false;

let jarvisReady = false;

let waitingForCommand = false;

let commandTimeout = null;

let recognitionRestart = null;


/* =========================================================
   ACTIVATE JARVIS
========================================================= */

activateButton.addEventListener(
    "click",
    async () => {

        /*
            This button provides the user gesture
            mobile browsers require.
        */

        activateButton.disabled = true;

        activateButton.innerText =
            "[ INITIALIZING... ]";

        voiceStatus.innerText =
            "JARVIS: REQUESTING MICROPHONE...";


        try {

            /*
                Ask for microphone permission.
            */

            const mic =
                await navigator.mediaDevices
                    .getUserMedia({
                        audio: true
                    });


            /*
                We only needed the stream
                to obtain permission.
            */

            mic.getTracks().forEach(
                track => track.stop()
            );


            initializeRecognition();


        } catch (error) {

            console.error(error);

            voiceStatus.innerText =
                "JARVIS: MICROPHONE ACCESS DENIED";

            activateButton.disabled = false;

            activateButton.innerText =
                "[ ACTIVATE JARVIS ]";
        }
    }
);


/* =========================================================
   INITIALIZE SPEECH RECOGNITION
========================================================= */

function initializeRecognition() {

    const SpeechRecognition =
        window.SpeechRecognition ||
        window.webkitSpeechRecognition;


    if (!SpeechRecognition) {

        voiceStatus.innerText =
            "JARVIS: SPEECH RECOGNITION UNSUPPORTED";

        activateButton.disabled = false;

        activateButton.innerText =
            "[ UNSUPPORTED ]";

        return;
    }


    recognition =
        new SpeechRecognition();


    recognition.continuous = true;

    recognition.interimResults = false;

    recognition.lang = "en-US";


    recognition.onstart = () => {

        isListening = true;

        jarvisReady = true;

        activateButton.innerText =
            "[ JARVIS ACTIVE ]";

        activateButton.style.opacity =
            "0.6";

        voiceStatus.style.color =
            "var(--mic-glow)";

        voiceStatus.innerText =
            "JARVIS: LISTENING...";
    };


    recognition.onresult = event => {

        const result =
            event.results[
                event.results.length - 1
            ];


        if (!result.isFinal)
            return;


        let text =
            result[0]
                .transcript
                .trim()
                .toLowerCase();


        console.log(
            "JARVIS HEARD:",
            text
        );


        /* =========================================
           WAKE WORD
        ========================================= */

        if (
            /\bjarvis\b/i.test(text)
        ) {

            /*
                Remove "Jarvis".
            */

            const command =
                text
                    .replace(
                        /\bjarvis\b/gi,
                        ""
                    )
                    .trim();


            waitingForCommand = true;


            /*
                "Jarvis search YouTube"
                can be handled immediately.
            */

            if (command.length > 0) {

                clearTimeout(
                    commandTimeout
                );

                handleVoiceCommand(
                    command
                );

                waitingForCommand = false;

                return;
            }


            /*
                User only said "Jarvis".
            */

            voiceStatus.innerText =
                "JARVIS: YES?";

            speak(
                "Yes?"
            );


            clearTimeout(
                commandTimeout
            );


            commandTimeout =
                setTimeout(() => {

                    waitingForCommand =
                        false;

                    voiceStatus.innerText =
                        "JARVIS: LISTENING...";

                }, 7000);


            return;
        }


        /* =========================================
           COMMAND AFTER "JARVIS"
        ========================================= */

        if (
            waitingForCommand
        ) {

            clearTimeout(
                commandTimeout
            );

            waitingForCommand =
                false;

            handleVoiceCommand(
                text
            );
        }
    };


    recognition.onerror = event => {

        console.log(
            "Speech error:",
            event.error
        );


        if (
            event.error ===
            "not-allowed"
        ) {

            voiceStatus.innerText =
                "JARVIS: MICROPHONE PERMISSION DENIED";

            return;
        }


        if (
            event.error ===
            "network"
        ) {

            voiceStatus.innerText =
                "JARVIS: SPEECH NETWORK ERROR";

            return;
        }
    };


    recognition.onend = () => {

        isListening = false;


        /*
            Restart automatically.

            This means you don't have to
            press the button again.
        */

        clearTimeout(
            recognitionRestart
        );


        recognitionRestart =
            setTimeout(() => {

                if (
                    jarvisReady
                ) {

                    startRecognition();
                }

            }, 500);
    };


    startRecognition();
}


/* =========================================================
   START RECOGNITION
========================================================= */

function startRecognition() {

    if (
        !recognition ||
        isListening
    )
        return;


    try {

        recognition.start();

    } catch (error) {

        console.log(
            "Recognition already running."
        );
    }
}


/* =========================================================
   VOICE COMMAND HANDLER
========================================================= */

function handleVoiceCommand(
    command
) {

    command =
        command
            .trim()
            .toLowerCase();


    voiceStatus.style.color =
        "var(--jarvis-glow)";

    voiceStatus.innerText =
        "JARVIS: " + command;


    /* =========================================
       SEARCH
    ========================================= */

    if (
        command.startsWith("search ")
        ||
        command.startsWith("search for ")
        ||
        command.startsWith("look up ")
    ) {

        const query =
            command
                .replace(
                    /^search for /,
                    ""
                )
                .replace(
                    /^search /,
                    ""
                )
                .replace(
                    /^look up /,
                    ""
                )
                .trim();


        if (!query)
            return;


        speak(
            "Searching for " +
            query
        );


        const url =
            "https://www.google.com/search?q=" +
            encodeURIComponent(query);


        /*
            Using location instead of window.open
            is more reliable on mobile browsers.
        */

        setTimeout(() => {

            window.location.href =
                url;

        }, 500);


        return;
    }


    /* =========================================
       YOUTUBE
    ========================================= */

    if (
        command.includes(
            "open youtube"
        )
    ) {

        speak(
            "Opening YouTube."
        );


        setTimeout(() => {

            window.location.href =
                "https://youtube.com";

        }, 500);


        return;
    }


    /* =========================================
       SCHOOLOGY
    ========================================= */

    if (
        command.includes(
            "open schoology"
        )
    ) {

        speak(
            "Opening Schoology."
        );


        setTimeout(() => {

            window.location.href =
                "https://corunna.schoology.com";

        }, 500);


        return;
    }


    /* =========================================
       GOOGLE CLASSROOM
    ========================================= */

    if (
        command.includes(
            "open google classroom"
        )
    ) {

        speak(
            "Opening Google Classroom."
        );


        setTimeout(() => {

            window.location.href =
                "https://classroom.google.com/";

        }, 500);


        return;
    }


    /* =========================================
       POWERSCHOOL
    ========================================= */

    if (
        command.includes(
            "open powerschool"
        )
    ) {

        speak(
            "Opening PowerSchool."
        );


        setTimeout(() => {

            window.location.href =
                "https://ps.corunna.k12.mi.us/guardian/home.html";

        }, 500);


        return;
    }


    /* =========================================
       HOME
    ========================================= */

    if (
        command.includes(
            "open home page"
        )
    ) {

        speak(
            "Opening home page."
        );


        setTimeout(() => {

            window.location.href =
                "https://www.corunna.k12.mi.us/";

        }, 500);


        return;
    }


    /* =========================================
       TOP
    ========================================= */

    if (
        command.includes(
            "go to top"
        )
    ) {

        speak(
            "Returning to the top."
        );


        document
            .getElementById(
                "top-anchor"
            )
            .scrollIntoView({
                behavior: "smooth"
            });


        return;
    }


    /* =========================================
       BOTTOM
    ========================================= */

    if (
        command.includes(
            "go to bottom"
        )
    ) {

        speak(
            "Navigating to the bottom."
        );


        document
            .getElementById(
                "bottom-anchor"
            )
            .scrollIntoView({
                behavior: "smooth"
            });


        return;
    }


    /* =========================================
       CAMERA ON
    ========================================= */

    if (
        command.includes(
            "camera on"
        )
        ||
        command.includes(
            "turn camera on"
        )
        ||
        command.includes(
            "open camera"
        )
    ) {

        speak(
            "Camera activating."
        );


        startCamera();


        return;
    }


    /* =========================================
       CAMERA OFF
    ========================================= */

    if (
        command.includes(
            "camera off"
        )
        ||
        command.includes(
            "turn camera off"
        )
        ||
        command.includes(
            "close camera"
        )
    ) {

        speak(
            "Camera shutting down."
        );


        stopCamera();


        return;
    }


    /* =========================================
       UNKNOWN
    ========================================= */

    speak(
        "I did not recognize that command."
    );


    voiceStatus.innerText =
        "JARVIS: COMMAND NOT RECOGNIZED";
}


/* =========================================================
   TEXT TO SPEECH
========================================================= */

function speak(text) {

    if (
        !window.speechSynthesis
    )
        return;


    speechSynthesis.cancel();


    const utterance =
        new SpeechSynthesisUtterance(
            text
        );


    const voices =
        speechSynthesis.getVoices();


    const preferred = [

        "Google UK English Male",

        "Microsoft George",

        "Microsoft Guy Online (Natural) - English (United States)",

        "Microsoft Ryan Online (Natural) - English (United Kingdom)",

        "Alex",

        "Daniel",

        "Arthur"

    ];


    let voice = null;


    for (
        const preferredName
        of preferred
    ) {

        voice =
            voices.find(
                v =>
                    v.name
                        .toLowerCase()
                        .includes(
                            preferredName
                                .toLowerCase()
                        )
            );


        if (voice)
            break;
    }


    if (!voice) {

        voice =
            voices.find(
                v =>
                    v.lang
                        .toLowerCase()
                        .startsWith("en")
                    &&
                    /male|george|guy|daniel|alex|arthur/i
                        .test(
                            v.name
                        )
            );
    }


    if (!voice) {

        voice =
            voices.find(
                v =>
                    v.lang ===
                    "en-US"
            );
    }


    if (voice) {

        utterance.voice =
            voice;
    }


    utterance.lang =
        "en-US";

    utterance.rate =
        0.88;

    utterance.pitch =
        0.65;

    utterance.volume =
        1;


    speechSynthesis.speak(
        utterance
    );
}


/* =========================================================
   CAMERA BUTTONS
========================================================= */

cameraOnButton.addEventListener(
    "click",
    startCamera
);


cameraOffButton.addEventListener(
    "click",
    stopCamera
);


/* =========================================================
   START CAMERA
========================================================= */

async function startCamera() {

    if (isCamOn)
        return;


    if (
        !navigator.mediaDevices ||
        !navigator.mediaDevices.getUserMedia
    ) {

        camStatus.innerText =
            "CAM_STATUS: UNSUPPORTED";

        return;
    }


    camStatus.innerText =
        "CAM_STATUS: REQUESTING CAMERA...";


    try {

        localStream =
            await navigator.mediaDevices
                .getUserMedia({
                    video: {
                        width: 320,
                        height: 240
                    }
                });


        video.srcObject =
            localStream;


        await video.play();


        isCamOn = true;


        video.style.opacity =
            "0.4";


        camStatus.innerText =
            "CAM_STATUS: ACTIVE";


        requestAnimationFrame(
            processFrame
        );


    } catch (error) {

        console.error(error);


        camStatus.innerText =
            "CAM_STATUS: CAMERA BLOCKED";
    }
}


/* =========================================================
   STOP CAMERA
========================================================= */

function stopCamera() {

    if (!localStream)
        return;


    localStream
        .getTracks()
        .forEach(
            track =>
                track.stop()
        );


    localStream = null;

    video.srcObject = null;

    isCamOn = false;

    previousFrame = null;


    ctx.clearRect(
        0,
        0,
        canvas.width,
        canvas.height
    );


    video.style.opacity =
        "0";


    camStatus.innerText =
        "CAM_STATUS: OFFLINE";
}


/* =========================================================
   MOTION TRACKING
========================================================= */

function processFrame() {

    if (!isCamOn)
        return;


    if (
        video.readyState !==
        video.HAVE_ENOUGH_DATA
    ) {

        requestAnimationFrame(
            processFrame
        );

        return;
    }


    canvas.width =
        video.videoWidth;

    canvas.height =
        video.videoHeight;


    ctx.drawImage(
        video,
        0,
        0,
        canvas.width,
        canvas.height
    );


    const frame =
        ctx.getImageData(
            0,
            0,
            canvas.width,
            canvas.height
        );


    const data =
        frame.data;


    if (previousFrame) {

        let motion =
            0;


        /*
            Sample every 4 pixels.
        */

        for (
            let i = 0;
            i < data.length;
            i += 16
        ) {

            const difference =
                Math.abs(
                    data[i] -
                    previousFrame[i]
                )
                +
                Math.abs(
                    data[i + 1] -
                    previousFrame[i + 1]
                )
                +
                Math.abs(
                    data[i + 2] -
                    previousFrame[i + 2]
                );


            if (
                difference >
                motionThreshold * 3
            ) {

                motion++;
            }
        }


        /*
            Display motion points.
        */

        if (
            motion > 100 &&
            !gestureCooldown
        ) {

            gestureCooldown =
                true;


            camStatus.innerText =
                "CAM_STATUS: MOTION DETECTED";


            setTimeout(() => {

                gestureCooldown =
                    false;


                if (isCamOn) {

                    camStatus.innerText =
                        "CAM_STATUS: ACTIVE";
                }

            }, 700);
        }
    }


    previousFrame =
        new Uint8ClampedArray(
            data
        );


    requestAnimationFrame(
        processFrame
    );
}


/* =========================================================
   SPEECH VOICE LOADING
========================================================= */

if (
    window.speechSynthesis
) {

    speechSynthesis.onvoiceschanged =
        () => {

            speechSynthesis
                .getVoices();

        };
}