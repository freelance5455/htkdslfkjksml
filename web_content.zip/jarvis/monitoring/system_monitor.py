import platform, time, psutil

def snapshot() -> dict:
    boot = psutil.boot_time()
    try:
        battery = psutil.sensors_battery() if hasattr(psutil, "sensors_battery") else None
    except (OSError, RuntimeError):
        battery = None
    return {
        "os": platform.platform(), "cpu_percent": psutil.cpu_percent(interval=None),
        "ram_percent": psutil.virtual_memory().percent,
        "disk_percent": psutil.disk_usage("/").percent,
        "battery": None if battery is None else {"percent": battery.percent, "plugged_in": battery.power_plugged},
        "network": {"available": psutil.net_if_stats() and any(v.isup for v in psutil.net_if_stats().values())},
        "uptime_seconds": max(0, int(time.time() - boot)),
        "process_count": len(psutil.pids()),
    }
