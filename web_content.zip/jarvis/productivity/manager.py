from memory.database import connect

class ProductivityManager:
    def add_reminder(self, title: str, due_at: str | None = None) -> dict:
        with connect() as db:
            cur = db.execute("INSERT INTO reminders(title,due_at) VALUES(?,?)", (title.strip(), due_at))
            return {"id": cur.lastrowid, "title": title.strip(), "due_at": due_at, "completed": False}

    def list_reminders(self) -> list[dict]:
        with connect() as db:
            return [dict(r) for r in db.execute("SELECT * FROM reminders ORDER BY completed,due_at,id").fetchall()]

    def complete_reminder(self, reminder_id: int) -> bool:
        with connect() as db:
            cur = db.execute("UPDATE reminders SET completed=1 WHERE id=?", (reminder_id,))
            return cur.rowcount > 0

    def add_note(self, title: str, content: str) -> dict:
        with connect() as db:
            cur = db.execute("INSERT INTO notes(title,content) VALUES(?,?)", (title.strip(), content))
            return {"id": cur.lastrowid, "title": title.strip()}

    def list_notes(self) -> list[dict]:
        with connect() as db:
            return [dict(r) for r in db.execute("SELECT id,title,created_at,updated_at FROM notes ORDER BY updated_at DESC").fetchall()]

    def add_task(self, title: str, details: str = "", due_at: str | None = None) -> dict:
        with connect() as db:
            cur = db.execute("INSERT INTO tasks(title,details,due_at) VALUES(?,?,?)", (title.strip(), details, due_at))
            return {"id": cur.lastrowid, "title": title.strip(), "due_at": due_at, "completed": False}

    def list_tasks(self) -> list[dict]:
        with connect() as db:
            return [dict(r) for r in db.execute("SELECT * FROM tasks ORDER BY completed,due_at,id").fetchall()]

    def complete_task(self, task_id: int) -> bool:
        with connect() as db:
            cur = db.execute("UPDATE tasks SET completed=1 WHERE id=?", (task_id,))
            return cur.rowcount > 0
