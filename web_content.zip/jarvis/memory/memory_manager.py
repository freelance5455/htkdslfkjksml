from memory.database import connect
from config.settings import get_settings

class MemoryManager:
    def add(self, content: str, tag: str = "") -> int:
        if not get_settings().memory_enabled:
            raise RuntimeError("Long-term memory is disabled in configuration.")
        with connect() as db:
            cur = db.execute("INSERT INTO memories(content, tag) VALUES (?, ?)", (content.strip(), tag.strip()))
            return int(cur.lastrowid)

    def search(self, query: str, limit: int = 10) -> list[dict]:
        if not get_settings().memory_enabled or not query.strip(): return []
        with connect() as db:
            rows = db.execute("SELECT m.id,m.content,m.tag,m.created_at FROM memories_fts f JOIN memories m ON m.id=f.rowid WHERE memories_fts MATCH ? ORDER BY rank LIMIT ?", (query, min(max(limit,1),50))).fetchall()
            return [dict(r) for r in rows]

    def delete(self, memory_id: int) -> bool:
        with connect() as db:
            cur = db.execute("DELETE FROM memories WHERE id=?", (memory_id,))
            return cur.rowcount > 0
