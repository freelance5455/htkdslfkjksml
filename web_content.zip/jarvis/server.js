// Servidor do Jarvis: serve o app e conversa com Claude, ChatGPT, Grok e Gemini.
// Sem dependências: precisa só do Node 18+ (fetch embutido).
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC = path.join(__dirname, "public");

// Lê um arquivo .env local, se existir (útil para testar no computador).
try {
  const env = fs.readFileSync(path.join(__dirname, ".env"), "utf8");
  for (const line of env.split("\n")) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
  }
} catch {}

const E = process.env;
const PORT = Number(E.PORT || 8080);
const APP_PASSWORD = E.APP_PASSWORD || "";

// Modelos: troque pelas variáveis de ambiente se algum nome mudar.
const MODELS = {
  claude: E.CLAUDE_MODEL || "claude-sonnet-5-5",
  chatgpt: E.OPENAI_MODEL || "gpt-5",
  grok: E.GROK_MODEL || "grok-4",
  gemini: E.GEMINI_MODEL || "gemini-2.5-flash",
};

const SYSTEM =
  "Você é o JARVIS, um assistente pessoal de voz, educado, elegante, com leve humor britânico. " +
  "Chame o usuário de 'senhor' ou 'senhora' só às vezes. Responda em português do Brasil, em no máximo 3 frases curtas, " +
  "sem listas, sem markdown e sem emojis, porque sua resposta será lida em voz alta.";

const TIMEOUT = 40000;

async function post(url, headers, body) {
  const r = await fetch(url, {
    method: "POST",
    headers: { "content-type": "application/json", ...headers },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(TIMEOUT),
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data?.error?.message || data?.error || `HTTP ${r.status}`);
  return data;
}

const providers = {
  claude: {
    key: () => E.ANTHROPIC_API_KEY,
    async ask(messages, system = SYSTEM) {
      const d = await post(
        "https://api.anthropic.com/v1/messages",
        { "x-api-key": E.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01" },
        { model: MODELS.claude, max_tokens: 600, system, messages }
      );
      return d.content?.map((c) => c.text || "").join("").trim();
    },
  },
  chatgpt: {
    key: () => E.OPENAI_API_KEY,
    async ask(messages, system = SYSTEM) {
      const d = await post(
        "https://api.openai.com/v1/chat/completions",
        { authorization: `Bearer ${E.OPENAI_API_KEY}` },
        { model: MODELS.chatgpt, messages: [{ role: "system", content: system }, ...messages] }
      );
      return d.choices?.[0]?.message?.content?.trim();
    },
  },
  grok: {
    key: () => E.XAI_API_KEY,
    async ask(messages, system = SYSTEM) {
      const d = await post(
        "https://api.x.ai/v1/chat/completions",
        { authorization: `Bearer ${E.XAI_API_KEY}` },
        { model: MODELS.grok, messages: [{ role: "system", content: system }, ...messages] }
      );
      return d.choices?.[0]?.message?.content?.trim();
    },
  },
  gemini: {
    key: () => E.GEMINI_API_KEY,
    async ask(messages, system = SYSTEM) {
      const d = await post(
        `https://generativelanguage.googleapis.com/v1beta/models/${MODELS.gemini}:generateContent`,
        { "x-goog-api-key": E.GEMINI_API_KEY },
        {
          systemInstruction: { parts: [{ text: system }] },
          contents: messages.map((m) => ({
            role: m.role === "assistant" ? "model" : "user",
            parts: [{ text: m.content }],
          })),
        }
      );
      return d.candidates?.[0]?.content?.parts?.map((p) => p.text || "").join("").trim();
    },
  },
};

const active = () => Object.keys(providers).filter((n) => providers[n].key());

async function ask(history, question) {
  const messages = [...history.slice(-8), { role: "user", content: question }];
  const names = active();
  if (!names.length) throw new Error("Nenhuma chave de API configurada no servidor.");

  const results = await Promise.allSettled(names.map((n) => providers[n].ask(messages)));
  const answers = {};
  const errors = {};
  results.forEach((r, i) => {
    if (r.status === "fulfilled" && r.value) answers[names[i]] = r.value;
    else errors[names[i]] = r.reason?.message || "sem resposta";
  });

  const got = Object.keys(answers);
  if (!got.length) throw new Error("Todas as IAs falharam: " + JSON.stringify(errors));
  if (got.length === 1) return { answer: answers[got[0]], answers, errors };

  // Um sintetizador (Claude se tiver, senão a primeira que respondeu) junta tudo.
  const synth = got.includes("claude") ? "claude" : got[0];
  const joined = got.map((n) => `[${n.toUpperCase()}]\n${answers[n]}`).join("\n\n");
  const prompt =
    `Pergunta do usuário: ${question}\n\nRespostas de várias IAs:\n\n${joined}\n\n` +
    "Combine o melhor das respostas em uma única resposta final, correta e natural. " +
    "Se houver divergência importante, mencione de forma breve. Máximo de 3 frases.";
  try {
    const final = await providers[synth].ask([{ role: "user", content: prompt }]);
    return { answer: final || answers[synth], answers, errors };
  } catch {
    return { answer: answers[synth], answers, errors };
  }
}

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json",
  ".webmanifest": "application/manifest+json",
  ".svg": "image/svg+xml",
  ".png": "image/png",
};

function json(res, code, obj) {
  res.writeHead(code, { "content-type": "application/json" });
  res.end(JSON.stringify(obj));
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, "http://x");

  if (url.pathname === "/api/status") {
    return json(res, 200, { ias: active(), senha: !!APP_PASSWORD });
  }

  if (url.pathname === "/api/ask" && req.method === "POST") {
    if (APP_PASSWORD && req.headers["x-jarvis-key"] !== APP_PASSWORD) {
      return json(res, 401, { error: "Senha incorreta." });
    }
    let raw = "";
    for await (const c of req) {
      raw += c;
      if (raw.length > 50000) return json(res, 413, { error: "Mensagem grande demais." });
    }
    try {
      const { question, history } = JSON.parse(raw || "{}");
      if (!question || typeof question !== "string") return json(res, 400, { error: "Pergunta vazia." });
      const clean = Array.isArray(history)
        ? history.filter((m) => m && ["user", "assistant"].includes(m.role) && typeof m.content === "string")
        : [];
      return json(res, 200, await ask(clean, question.slice(0, 2000)));
    } catch (e) {
      return json(res, 500, { error: e.message });
    }
  }

  // Arquivos estáticos
  let file = url.pathname === "/" ? "/index.html" : decodeURIComponent(url.pathname);
  const full = path.normalize(path.join(PUBLIC, file));
  if (!full.startsWith(PUBLIC) || !fs.existsSync(full) || fs.statSync(full).isDirectory()) {
    res.writeHead(404);
    return res.end("Não encontrado");
  }
  res.writeHead(200, { "content-type": MIME[path.extname(full)] || "application/octet-stream" });
  fs.createReadStream(full).pipe(res);
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`Jarvis no ar na porta ${PORT}. IAs ativas: ${active().join(", ") || "nenhuma"}`);
});
