"""JARVIS backend: auth, streaming LLM brain, tool loop, confirmation gate, desktop-agent relay, journal."""
import asyncio, json, os, sqlite3, uuid
import anthropic
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, Header
from fastapi.staticfiles import StaticFiles

TOKEN = os.environ["JARVIS_TOKEN"]            # long random string you choose
MODEL = os.getenv("JARVIS_MODEL", "claude-haiku-5-5")
client = anthropic.AsyncAnthropic()           # reads ANTHROPIC_API_KEY
app = FastAPI(title="JARVIS")
agent = {"ws": None, "pending": {}}           # one connected desktop agent
db = sqlite3.connect("jarvis.db", check_same_thread=False)
db.execute("create table if not exists journal(id integer primary key, ts text default current_timestamp, data text)")

SYSTEM = ("You are JARVIS, a concise, professional assistant. Reply in the user's language (English or Hindi), in one or two short sentences. "
          "Use tools for device actions; never claim success unless the tool result says ok. "
          "Trading analysis is educational only: explain bias and levels, never promise outcomes, never place trades.")
SENSITIVE = {"open_app", "type_text", "click", "hotkey"}
TOOLS = [
 {"name": "desktop_action", "description": "Control the user's computer via the desktop agent. "
  "actions: open_app{name}, type_text{text}, click{x,y}, scroll{amount}, hotkey{keys:[..]}, read_screen{} (OCR).",
  "input_schema": {"type": "object", "properties": {"action": {"type": "string"}, "args": {"type": "object"}}, "required": ["action"]}},
 {"name": "trade_risk", "description": "Position size and reward:risk. instrument: fx|xau|crypto.",
  "input_schema": {"type": "object", "properties": {"instrument": {"type": "string"}, "balance": {"type": "number"},
   "risk_pct": {"type": "number"}, "entry": {"type": "number"}, "stop": {"type": "number"}, "target": {"type": "number"}},
   "required": ["instrument", "balance", "risk_pct", "entry", "stop", "target"]}},
]

def trade_risk(instrument, balance, risk_pct, entry, stop, target):
    risk, d = balance * risk_pct / 100, abs(entry - stop)
    if d == 0: return {"ok": False, "error": "stop equals entry"}
    size = {"fx": risk / (d / 0.0001 * 10), "xau": risk / (d * 100)}.get(instrument, risk / d)
    return {"ok": True, "risk_usd": round(risk, 2), "size": round(size, 4), "rr": round(abs(target - entry) / d, 2)}

async def call_agent(action, args):
    ws = agent["ws"]
    if not ws: return {"ok": False, "error": "desktop agent not connected"}
    rid = uuid.uuid4().hex; fut = asyncio.get_running_loop().create_future(); agent["pending"][rid] = fut
    try:
        await ws.send_json({"id": rid, "action": action, "args": args})
        return await asyncio.wait_for(fut, 20)
    except Exception as e:
        return {"ok": False, "error": f"agent failed: {e!r}"}
    finally: agent["pending"].pop(rid, None)

async def run_tool(ws, confirms, name, inp):
    if name == "trade_risk": return trade_risk(**inp)
    action, args = inp["action"], inp.get("args", {})
    if action in SENSITIVE:
        cid = uuid.uuid4().hex; fut = asyncio.get_running_loop().create_future(); confirms[cid] = fut
        await ws.send_json({"type": "confirm", "id": cid, "summary": f"Allow JARVIS to {action} {json.dumps(args)}?"})
        try: ok = await asyncio.wait_for(fut, 60)
        except asyncio.TimeoutError: ok = False
        if not ok: return {"ok": False, "error": "user declined"}
    return await call_agent(action, args)

async def brain(ws, history, confirms):
    for _ in range(8):                                   # bounded multistep loop
        async with client.messages.stream(model=MODEL, max_tokens=400, system=SYSTEM, tools=TOOLS, messages=history) as s:
            async for t in s.text_stream: await ws.send_json({"type": "token", "text": t})
            msg = await s.get_final_message()
        history.append({"role": "assistant", "content": msg.content})
        if msg.stop_reason != "tool_use": break
        results = []
        for b in msg.content:
            if b.type == "tool_use":
                r = await run_tool(ws, confirms, b.name, b.input)
                results.append({"type": "tool_result", "tool_use_id": b.id, "content": json.dumps(r), "is_error": not r.get("ok", True)})
        history.append({"role": "user", "content": results})
    await ws.send_json({"type": "done"})

@app.websocket("/ws")
async def chat(ws: WebSocket, token: str = ""):
    if token != TOKEN: return await ws.close(code=4401)
    await ws.accept(); history, confirms, task = [], {}, None
    try:
        while True:
            m = json.loads(await ws.receive_text())
            if m["type"] == "user" and not (task and not task.done()):
                history.append({"role": "user", "content": m["text"]})
                async def go():
                    try: await brain(ws, history, confirms)
                    except Exception as e: await ws.send_json({"type": "error", "text": f"Brain error: {e}"})
                task = asyncio.create_task(go())
            elif m["type"] == "confirm_reply" and m["id"] in confirms: confirms.pop(m["id"]).set_result(bool(m["ok"]))
            elif m["type"] == "stop":
                task and task.cancel()
                if agent["ws"]: await agent["ws"].send_json({"action": "stop"})
    except WebSocketDisconnect:
        task and task.cancel()

@app.websocket("/agent")
async def agent_link(ws: WebSocket, token: str = ""):
    if token != TOKEN: return await ws.close(code=4401)
    await ws.accept(); agent["ws"] = ws
    try:
        while True:
            m = await ws.receive_json(); f = agent["pending"].get(m.get("id"))
            if f and not f.done(): f.set_result(m["result"])
    except WebSocketDisconnect: agent["ws"] = None

@app.get("/journal")
def journal_list(authorization: str = Header("")):
    if authorization != f"Bearer {TOKEN}": raise HTTPException(401)
    return [{"id": i, "ts": t, **json.loads(d)} for i, t, d in db.execute("select * from journal order by id desc")]

@app.post("/journal")
def journal_add(entry: dict, authorization: str = Header("")):
    if authorization != f"Bearer {TOKEN}": raise HTTPException(401)
    db.execute("insert into journal(data) values(?)", (json.dumps(entry),)); db.commit(); return {"ok": True}

app.mount("/", StaticFiles(directory=os.path.join(os.path.dirname(__file__), "static"), html=True))
