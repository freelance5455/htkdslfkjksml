package com.jarvis.assistant

import android.content.Context
import android.content.Intent

/** Carries out [DeviceAction]s on the phone. Blocking (it pauses between steps), so run it off the main thread. */
class ActionExecutor(private val context: Context) {

    fun run(actions: List<DeviceAction>) {
        for (a in actions) {
            when (a.action) {
                "open_app" -> {
                    if (openApp(a.target.orEmpty())) Thread.sleep(1500)
                }
                "click_text" -> {
                    a.target?.let { JarvisAccessibilityService.instance?.clickText(it) }
                    Thread.sleep(700)
                }
                "type_text" -> {
                    a.text?.let { JarvisAccessibilityService.instance?.typeText(it) }
                    Thread.sleep(500)
                }
                "scroll" -> {
                    JarvisAccessibilityService.instance?.scroll(a.direction != "up")
                    Thread.sleep(500)
                }
                "back" -> JarvisAccessibilityService.instance?.back()
                "home" -> JarvisAccessibilityService.instance?.home()
            }
        }
    }

    private fun openApp(name: String): Boolean {
        if (name.isBlank()) return false
        val pm = context.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
        val wanted = name.lowercase().trim()
        val match = apps.firstOrNull { it.first.lowercase() == wanted }
            ?: apps.firstOrNull { it.first.lowercase().contains(wanted) }
            ?: apps.firstOrNull { wanted.contains(it.first.lowercase()) }
            ?: return false
        val intent = pm.getLaunchIntentForPackage(match.second)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) ?: return false
        // Starting from the accessibility service's context is the most reliable way to open an app from the background.
        val starter: Context = JarvisAccessibilityService.instance ?: context
        return try {
            starter.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }
}
