package com.jarvis.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.util.TypedValue
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

/** Setup screen: enter the server details, grant the permissions, start or stop Jarvis. */
class MainActivity : AppCompatActivity() {

    private lateinit var settings: Settings
    private lateinit var urlField: EditText
    private lateinit var tokenField: EditText
    private lateinit var keyField: EditText
    private lateinit var statusView: TextView

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (hasMic()) {
                JarvisService.start(this)
            } else {
                toast("Jarvis needs the microphone permission to hear you.")
            }
            refresh()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = Settings(this)

        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(32))
        }
        column.addView(text("Jarvis", 26f, bold = true))
        column.addView(text("Say \"Jarvis\" and talk. It keeps listening in the background while this is running.", 14f))

        urlField = field("Server address, e.g. https://jarvis.example.com", settings.serverUrl, InputType.TYPE_TEXT_VARIATION_URI)
        tokenField = field("Access token (JARVIS_TOKEN on your server)", settings.token, InputType.TYPE_TEXT_VARIATION_PASSWORD)
        keyField = field("Picovoice access key (free, console.picovoice.ai)", settings.picovoiceKey, InputType.TYPE_TEXT_VARIATION_PASSWORD)
        column.addView(urlField)
        column.addView(tokenField)
        column.addView(keyField)

        column.addView(button("Start Jarvis") { startClicked() })
        column.addView(button("Stop Jarvis") { JarvisService.stop(this); refresh() })

        column.addView(text("One-time setup", 16f, bold = true).apply { setPadding(0, dp(18), 0, 0) })
        column.addView(button("1. Turn on accessibility control") {
            startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        column.addView(button("2. Allow display over other apps") {
            startActivity(
                Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")),
            )
        })
        column.addView(button("3. Keep running in the background") {
            startActivity(Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })

        statusView = text("", 14f).apply { setPadding(0, dp(18), 0, 0) }
        column.addView(statusView)

        setContentView(ScrollView(this).apply { addView(column) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onPause() {
        saveFields()
        super.onPause()
    }

    private fun startClicked() {
        saveFields()
        if (settings.picovoiceKey.isBlank()) {
            toast("Add your Picovoice access key first.")
            return
        }
        val needed = mutableListOf<String>()
        if (!hasMic()) needed += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            needed += Manifest.permission.POST_NOTIFICATIONS
        }
        if (needed.isEmpty()) {
            JarvisService.start(this)
            refresh()
        } else {
            permissionLauncher.launch(needed.toTypedArray())
        }
    }

    private fun saveFields() {
        settings.serverUrl = urlField.text.toString()
        settings.token = tokenField.text.toString()
        settings.picovoiceKey = keyField.text.toString()
    }

    private fun refresh() {
        fun yn(v: Boolean) = if (v) "yes" else "no"
        statusView.text = buildString {
            appendLine("Jarvis running: ${yn(JarvisService.running)}")
            appendLine("Microphone allowed: ${yn(hasMic())}")
            appendLine("Accessibility control on: ${yn(JarvisAccessibilityService.instance != null)}")
            append("Display over other apps: ${yn(android.provider.Settings.canDrawOverlays(this@MainActivity))}")
        }
    }

    private fun hasMic() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun text(value: String, sizeSp: Float, bold: Boolean = false) = TextView(this).apply {
        text = value
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, dp(4), 0, dp(4))
    }

    private fun field(hintText: String, value: String, variation: Int) = EditText(this).apply {
        hint = hintText
        setText(value)
        inputType = InputType.TYPE_CLASS_TEXT or variation
        isSingleLine = true
    }

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
    }
}
