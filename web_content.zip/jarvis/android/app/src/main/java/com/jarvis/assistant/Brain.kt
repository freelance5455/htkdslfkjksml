package com.jarvis.assistant

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.text.DateFormat
import java.util.Date
import java.util.concurrent.TimeUnit

data class DeviceAction(val action: String, val target: String?, val text: String?, val direction: String?)
data class BrainResult(val reply: String, val actions: List<DeviceAction> = emptyList())

/**
 * Plug an on-device Qwen3 in here (for example a small Qwen3 model through llama.cpp, MLC LLM or
 * MediaPipe). It is used as the offline fallback when the server cannot be reached. It cannot use the
 * server's tools (posting, Shopify), so keep it for simple conversation.
 */
fun interface LocalModel {
    fun generate(prompt: String): String?
}

/**
 * Hybrid routing, cheapest first:
 *  1. Rules on the phone for quick commands ("open YouTube", "go back", "what time is it"). No network, instant.
 *  2. The Jarvis server, which runs Qwen3 in the cloud with all the tools. Used for everything else.
 *  3. The optional on-device [LocalModel] when the server is unreachable.
 *
 * Blocking: call from a background thread.
 */
class Brain(private val settings: Settings, private val localModel: LocalModel? = null) {
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    fun think(text: String): BrainResult {
        LocalIntents.tryHandle(text)?.let { return it }
        return askServer(text)
    }

    private fun askServer(text: String): BrainResult {
        val url = settings.serverUrl
        val token = settings.token
        if (url.isBlank() || token.isBlank()) {
            return BrainResult("Please open the Jarvis app and set the server address and access token first.")
        }
        val body = JSONObject()
            .put("text", text)
            .put("sessionId", settings.sessionId)
            .put("client", "android")
            .toString()
            .toRequestBody("application/json".toMediaType())
        val request = Request.Builder()
            .url("$url/api/chat")
            .header("Authorization", "Bearer $token")
            .post(body)
            .build()
        return try {
            http.newCall(request).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                val json = runCatching { JSONObject(raw) }.getOrNull()
                when {
                    response.code == 401 -> BrainResult("The server did not accept my access token.")
                    !response.isSuccessful ->
                        BrainResult("The server had a problem. ${json?.optString("error").orEmpty()}".trim())
                    json == null -> BrainResult("I got an answer I could not read.")
                    else -> parse(json)
                }
            }
        } catch (e: IOException) {
            offlineFallback(text)
        }
    }

    private fun offlineFallback(text: String): BrainResult {
        val local = runCatching { localModel?.generate(text) }.getOrNull()
        return if (!local.isNullOrBlank()) BrainResult(local)
        else BrainResult("I can't reach my server right now. Quick commands like opening apps still work.")
    }

    private fun parse(json: JSONObject): BrainResult {
        val actions = mutableListOf<DeviceAction>()
        val arr = json.optJSONArray("deviceActions")
        if (arr != null) {
            for (i in 0 until arr.length()) {
                val a = arr.getJSONObject(i)
                actions += DeviceAction(
                    action = a.optString("action"),
                    target = a.optString("target").takeIf { it.isNotBlank() && it != "null" },
                    text = a.optString("text").takeIf { it.isNotBlank() && it != "null" },
                    direction = a.optString("direction").takeIf { it.isNotBlank() && it != "null" },
                )
            }
        }
        return BrainResult(json.optString("reply"), actions)
    }
}

/** Instant, offline handling of simple phone commands. */
object LocalIntents {
    fun tryHandle(raw: String): BrainResult? {
        val t = raw.trim().trimEnd('.', '!', '?').lowercase()
        if (t.isEmpty()) return null

        // Only short phrases are treated as quick commands. Longer requests go to Qwen3 on the server.
        Regex("^(?:open|launch)\\s+(?:the\\s+)?(.+?)(?:\\s+app)?$").find(t)?.let {
            val app = it.groupValues[1]
            if (app.split(' ').size <= 3) {
                return BrainResult("Opening $app.", listOf(DeviceAction("open_app", app, null, null)))
            }
        }
        Regex("^(?:click|tap)\\s+(?:on\\s+)?(.+)$").find(t)?.let {
            val label = it.groupValues[1]
            if (label.split(' ').size <= 4) {
                return BrainResult("Okay.", listOf(DeviceAction("click_text", label, null, null)))
            }
        }
        return when (t) {
            "go back", "back" -> BrainResult("Going back.", listOf(DeviceAction("back", null, null, null)))
            "go home", "home", "home screen", "go to the home screen" ->
                BrainResult("Going home.", listOf(DeviceAction("home", null, null, null)))
            "scroll down" -> BrainResult("", listOf(DeviceAction("scroll", null, null, "down")))
            "scroll up" -> BrainResult("", listOf(DeviceAction("scroll", null, null, "up")))
            "stop", "cancel", "never mind", "nevermind" -> BrainResult("Okay.")
            "what time is it", "what's the time", "what is the time" ->
                BrainResult("It is ${DateFormat.getTimeInstance(DateFormat.SHORT).format(Date())}.")
            else -> null
        }
    }
}
