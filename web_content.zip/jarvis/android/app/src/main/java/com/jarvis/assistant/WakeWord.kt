package com.jarvis.assistant

import ai.picovoice.porcupine.Porcupine
import ai.picovoice.porcupine.PorcupineException
import ai.picovoice.porcupine.PorcupineManager
import ai.picovoice.porcupine.PorcupineManagerCallback
import android.content.Context

/**
 * Always-on "Jarvis" detection that runs fully on the phone (Picovoice Porcupine, built-in JARVIS keyword).
 * Needs a free access key from console.picovoice.ai. Holds the microphone while running, so stop() it
 * before using the speech recognizer and start() it again afterwards.
 */
class WakeWord(
    private val context: Context,
    private val accessKey: String,
    private val onWake: () -> Unit,
) {
    private var manager: PorcupineManager? = null

    /** Returns null on success, or a short error message. */
    fun start(): String? = try {
        if (manager == null) {
            manager = PorcupineManager.Builder()
                .setAccessKey(accessKey)
                .setKeyword(Porcupine.BuiltInKeyword.JARVIS)
                .setSensitivity(0.7f)
                .build(context, PorcupineManagerCallback { onWake() })
        }
        manager?.start()
        null
    } catch (e: PorcupineException) {
        e.message ?: "Wake word engine failed to start"
    }

    fun stop() {
        try {
            manager?.stop()
        } catch (_: PorcupineException) {
        }
    }

    fun release() {
        try {
            manager?.stop()
            manager?.delete()
        } catch (_: PorcupineException) {
        }
        manager = null
    }
}
