package com.jarvis.assistant

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * The always-on part of Jarvis. Runs as a foreground service (with a visible notification, which Android
 * requires for anything that keeps the microphone open in the background):
 *
 *   wake word "Jarvis" -> beep -> listen -> Brain (rules / Qwen3 server) -> speak reply + run phone actions -> wake word again
 */
class JarvisService : Service() {

    companion object {
        private const val CHANNEL_ID = "jarvis"
        private const val NOTIFICATION_ID = 1
        private const val ACTION_STOP = "com.jarvis.assistant.STOP"

        @Volatile
        var running = false
            private set

        fun start(context: Context) {
            ContextCompat.startForegroundService(context, Intent(context, JarvisService::class.java))
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, JarvisService::class.java))
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private val worker: ExecutorService = Executors.newSingleThreadExecutor()

    private lateinit var settings: Settings
    private lateinit var listener: Listener
    private lateinit var speaker: Speaker
    private lateinit var brain: Brain
    private lateinit var executor: ActionExecutor
    private lateinit var wakeWord: WakeWord

    private var busy = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        settings = Settings(this)
        listener = Listener(this)
        speaker = Speaker(this)
        brain = Brain(settings) // pass a LocalModel here to enable the on-device offline fallback
        executor = ActionExecutor(this)
        wakeWord = WakeWord(this, settings.picovoiceKey) { main.post { onWake() } }

        createChannel()
        val notification = buildNotification("Starting...")
        if (Build.VERSION.SDK_INT >= 30) {
            ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        running = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startWakeWord()
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        wakeWord.release()
        listener.cancel()
        speaker.shutdown()
        worker.shutdownNow()
        super.onDestroy()
    }

    // ---- conversation loop (all of this runs on the main thread except Brain and ActionExecutor) ----

    private fun startWakeWord() {
        if (settings.picovoiceKey.isBlank()) {
            updateNotification("Add your Picovoice key in the Jarvis app")
            return
        }
        val error = wakeWord.start()
        updateNotification(if (error == null) "Say \"Jarvis\"" else "Wake word error: $error")
    }

    private fun onWake() {
        if (busy) return
        busy = true
        wakeWord.stop() // free the microphone for the speech recognizer
        beep()
        updateNotification("Listening...")
        main.postDelayed({ listener.listen { text -> onHeard(text) } }, 250)
    }

    private fun onHeard(text: String?) {
        if (text.isNullOrBlank()) {
            speaker.speak("I didn't catch that.") { finish() }
            return
        }
        updateNotification("Thinking...")
        worker.execute {
            val result = try {
                brain.think(text)
            } catch (e: Exception) {
                BrainResult("Something went wrong on my side.")
            }
            main.post { respond(result) }
        }
    }

    private fun respond(result: BrainResult) {
        if (result.actions.isNotEmpty()) worker.execute { executor.run(result.actions) }
        if (result.reply.isBlank()) finish() else speaker.speak(result.reply) { finish() }
    }

    private fun finish() {
        busy = false
        startWakeWord()
    }

    // ---- notification and beep ----

    private fun createChannel() {
        val channel = NotificationChannel(CHANNEL_ID, "Jarvis", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(text: String) = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.ic_btn_speak_now)
        .setContentTitle("Jarvis")
        .setContentText(text)
        .setOngoing(true)
        .setContentIntent(
            PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE),
        )
        .addAction(
            0,
            "Stop",
            PendingIntent.getService(
                this, 1, Intent(this, JarvisService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE,
            ),
        )
        .build()

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification(text))
    }

    private fun beep() {
        try {
            val tone = ToneGenerator(AudioManager.STREAM_MUSIC, 80)
            tone.startTone(ToneGenerator.TONE_PROP_BEEP, 120)
            main.postDelayed({ tone.release() }, 400)
        } catch (_: RuntimeException) {
            // No beep is fine.
        }
    }
}
