package com.jarvis.assistant

import android.content.Context
import java.util.UUID

/** Small wrapper around SharedPreferences. Values stay on the phone, in the app's private storage. */
class Settings(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    var serverUrl: String
        get() = prefs.getString("serverUrl", "").orEmpty()
        set(value) = prefs.edit().putString("serverUrl", value.trim().trimEnd('/')).apply()

    var token: String
        get() = prefs.getString("token", "").orEmpty()
        set(value) = prefs.edit().putString("token", value.trim()).apply()

    /** Free key from console.picovoice.ai, needed by the wake word engine. */
    var picovoiceKey: String
        get() = prefs.getString("picovoiceKey", "").orEmpty()
        set(value) = prefs.edit().putString("picovoiceKey", value.trim()).apply()

    /** One conversation id per install so the server keeps context between requests. */
    val sessionId: String
        get() {
            val existing = prefs.getString("sessionId", null)
            if (existing != null) return existing
            val created = UUID.randomUUID().toString()
            prefs.edit().putString("sessionId", created).apply()
            return created
        }
}
