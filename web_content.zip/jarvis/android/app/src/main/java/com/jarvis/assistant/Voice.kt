package com.jarvis.assistant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.UUID

/** One-shot speech-to-text using Android's built-in recognizer. Call only from the main thread. */
class Listener(private val context: Context) {
    private var recognizer: SpeechRecognizer? = null

    /** Calls [onResult] once with the best transcript, or null if nothing was understood. */
    fun listen(onResult: (String?) -> Unit) {
        cancel()
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onResult(null)
            return
        }
        val r = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer = r
        var delivered = false
        fun deliver(text: String?) {
            if (delivered) return
            delivered = true
            if (recognizer === r) recognizer = null
            r.destroy()
            onResult(text)
        }
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                deliver(results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull())
            }

            override fun onError(error: Int) = deliver(null)
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        r.startListening(intent)
    }

    fun cancel() {
        recognizer?.let {
            it.cancel()
            it.destroy()
        }
        recognizer = null
    }
}

/** Text-to-speech. [speak] reports back on the main thread when the sentence has finished. */
class Speaker(context: Context) {
    private val main = Handler(Looper.getMainLooper())
    private var ready = false
    private var queued: Pair<String, () -> Unit>? = null

    private val tts: TextToSpeech

    init {
        tts = TextToSpeech(context.applicationContext) { status -> onEngineReady(status == TextToSpeech.SUCCESS) }
    }

    private fun onEngineReady(success: Boolean) {
        ready = success
        val waiting = queued
        queued = null
        if (waiting == null) {
            if (success) tts.language = Locale.getDefault()
            return
        }
        if (success) {
            tts.language = Locale.getDefault()
            speak(waiting.first, waiting.second)
        } else {
            waiting.second()
        }
    }

    fun speak(text: String, onDone: () -> Unit) {
        if (!ready) {
            // Engine still starting (or failed). Hold the sentence until it is ready.
            queued = text to onDone
            return
        }
        val id = UUID.randomUUID().toString()
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                if (utteranceId == id) main.post(onDone)
            }

            @Deprecated("Required override on older API levels")
            override fun onError(utteranceId: String?) {
                if (utteranceId == id) main.post(onDone)
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                if (utteranceId == id) main.post(onDone)
            }
        })
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
    }

    fun shutdown() {
        tts.stop()
        tts.shutdown()
    }
}
