$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (-not (Test-Path '.env')) {
    Copy-Item '.env.example' '.env'
    Write-Host 'Created .env from .env.example. Add your OpenAI API key and a strong JARVIS_ACCESS_TOKEN, then run this script again.' -ForegroundColor Yellow
    exit 0
}
$envText = Get-Content '.env' -Raw
if ($envText -match 'JARVIS_ACCESS_TOKEN=REPLACE_WITH_A_LONG_RANDOM_TOKEN' -or $envText -notmatch '(?m)^JARVIS_ACCESS_TOKEN=.+') {
    $bytes = New-Object byte[] 48
    $rng = [Security.Cryptography.RandomNumberGenerator]::Create()
    $rng.GetBytes($bytes)
    $rng.Dispose()
    $token = [Convert]::ToBase64String($bytes).TrimEnd('=').Replace('+','-').Replace('/','_')
    if ($envText -match '(?m)^JARVIS_ACCESS_TOKEN=.*$') {
        $envText = [regex]::Replace($envText, '(?m)^JARVIS_ACCESS_TOKEN=.*$', "JARVIS_ACCESS_TOKEN=$token")
    } else {
        $envText += "`r`nJARVIS_ACCESS_TOKEN=$token`r`n"
    }
    Set-Content '.env' $envText -NoNewline
    Write-Host "Generated access token and saved it in .env. Keep it private." -ForegroundColor Green
}
if (-not (Test-Path '.venv')) { py -3 -m venv .venv }
& '.venv\Scripts\python.exe' -m pip install -r requirements.txt
$ips = Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -notlike '127.*' -and $_.PrefixOrigin -ne 'WellKnown' }
Write-Host ''
Write-Host 'JARVIS is starting. On your phone, open one of these addresses while connected to the same Wi-Fi:' -ForegroundColor Cyan
foreach ($ip in $ips) { Write-Host "  http://$($ip.IPAddress):8000/mobile/" }
Write-Host 'Use the access token stored in the JARVIS_ACCESS_TOKEN line of your .env file.' -ForegroundColor Yellow
Write-Host 'Press Ctrl+C to stop JARVIS.'
$env:JARVIS_HOST = '0.0.0.0'
& '.venv\Scripts\python.exe' -m uvicorn main:app --host 0.0.0.0 --port 8000
