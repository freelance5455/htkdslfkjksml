"""Runs on the user's PC/Mac. Executes approved actions. Move the mouse to a screen corner to abort (pyautogui failsafe)."""
import asyncio, json, os, subprocess, sys, websockets
import pyautogui, pytesseract
pyautogui.FAILSAFE = True
URL, TOKEN = os.environ["JARVIS_URL"], os.environ["JARVIS_TOKEN"]   # e.g. ws://localhost:8000
halt = False

def do(action, a):
    if action == "open_app":
        if sys.platform == "win32": subprocess.Popen(["cmd", "/c", "start", "", a["name"]])
        elif sys.platform == "darwin": subprocess.Popen(["open", "-a", a["name"]])
        else: subprocess.Popen([a["name"]])
    elif action == "type_text": pyautogui.write(a["text"], interval=0.02)
    elif action == "click": pyautogui.click(a["x"], a["y"])
    elif action == "scroll": pyautogui.scroll(int(a["amount"]))
    elif action == "hotkey": pyautogui.hotkey(*a["keys"])
    elif action == "read_screen": return {"ok": True, "text": pytesseract.image_to_string(pyautogui.screenshot())[:4000]}
    else: return {"ok": False, "error": f"unknown action {action}"}
    return {"ok": True}

async def main():
    global halt
    async with websockets.connect(f"{URL}/agent?token={TOKEN}") as ws:
        print("JARVIS agent connected")
        async for raw in ws:
            m = json.loads(raw)
            if m["action"] == "stop": halt = True; continue
            halt = False
            try: res = await asyncio.to_thread(do, m["action"], m.get("args", {}))
            except Exception as e: res = {"ok": False, "error": repr(e)}
            await ws.send(json.dumps({"id": m.get("id"), "result": res}))
asyncio.run(main())
