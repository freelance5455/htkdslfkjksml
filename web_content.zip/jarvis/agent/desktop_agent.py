"""Runs on the user's PC/Mac. Executes approved actions. Move the mouse to a screen corner to abort (pyautogui failsafe)."""
import asyncio, json, os, subprocess, sys, websockets
import pyautogui, pytesseract
pyautogui.FAILSAFE = True
URL, TOKEN = os.environ["JARVIS_URL"], os.environ["JARVIS_TOKEN"]   # e.g. ws://localhost:8000
halt = False

OVERLAY = os.path.join(os.path.dirname(os.path.abspath(__file__)), "overlay.py")

def find(text):
    img = pyautogui.screenshot(); k = img.width / pyautogui.size().width
    d = pytesseract.image_to_data(img, output_type=pytesseract.Output.DICT)
    words = [w.lower().strip(".,:;!?()[]") for w in d["text"]]; want = text.lower().split(); out = []
    for i in range(len(words) - len(want) + 1):
        if words[i:i + len(want)] == want:
            j = range(i, i + len(want)); x = min(d["left"][n] for n in j); y = min(d["top"][n] for n in j)
            out.append({"x": x / k, "y": y / k, "w": (max(d["left"][n] + d["width"][n] for n in j) - x) / k,
                        "h": (max(d["top"][n] + d["height"][n] for n in j) - y) / k})
    return out

def show(shapes, secs):
    if sys.platform not in ("win32", "darwin"): return {"ok": False, "error": "screen marking supports Windows and macOS only"}
    subprocess.Popen([sys.executable, OVERLAY, json.dumps(shapes), str(secs)]); return {"ok": True}

def do(action, a):
    if action == "open_app":
        if sys.platform == "win32": subprocess.Popen(["cmd", "/c", "start", "", a["name"]])
        elif sys.platform == "darwin": subprocess.Popen(["open", "-a", a["name"]])
        else: subprocess.Popen([a["name"]])
    elif action == "type_text": pyautogui.write(a["text"], interval=0.02)
    elif action == "click": pyautogui.click(a["x"], a["y"])
    elif action == "scroll": pyautogui.scroll(int(a["amount"]))
    elif action == "hotkey": pyautogui.hotkey(*a["keys"])
    elif action == "read_screen": return {"ok": True, "text": pytesseract.image_to_string(pyautogui.screenshot())[:4000]}
    elif action == "find_text": return {"ok": True, "matches": find(a["text"])[:10]}
    elif action == "mark": return show(a["shapes"], a.get("seconds", 6))
    elif action == "mark_text":
        ms = find(a["text"])[:5]
        if not ms: return {"ok": False, "error": "text not found on screen"}
        return {**show([{"type": "box", **m, "label": a.get("label", "")} for m in ms], a.get("seconds", 6)), "marked": len(ms)}
    else: return {"ok": False, "error": f"unknown action {action}"}
    return {"ok": True}

async def main():
    global halt
    async with websockets.connect(f"{URL}/agent?token={TOKEN}") as ws:
        print("JARVIS agent connected")
        async for raw in ws:
            m = json.loads(raw)
            if m["action"] == "stop": halt = True; continue
            halt = False
            try: res = await asyncio.to_thread(do, m["action"], m.get("args", {}))
            except Exception as e: res = {"ok": False, "error": repr(e)}
            await ws.send(json.dumps({"id": m.get("id"), "result": res}))
asyncio.run(main())
