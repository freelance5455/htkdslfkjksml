"""Draws red marks over the whole screen for a few seconds. Click anywhere to dismiss."""
import sys, json, tkinter as tk
shapes, secs = json.loads(sys.argv[1]), float(sys.argv[2])
r = tk.Tk(); r.overrideredirect(True); r.attributes("-topmost", True)
W, H = r.winfo_screenwidth(), r.winfo_screenheight(); r.geometry(f"{W}x{H}+0+0")
bg = "black"
if sys.platform == "win32": r.attributes("-transparentcolor", bg)
else: r.attributes("-transparent", True); bg = "systemTransparent"; r.config(bg=bg)
c = tk.Canvas(r, width=W, height=H, bg=bg, highlightthickness=0); c.pack()
for s in shapes:
    x, y, w, h = s["x"], s["y"], s.get("w", 0), s.get("h", 0); t = s.get("type", "box"); col = "#ff2a2a"
    if t == "circle": c.create_oval(x - 8, y - 8, x + w + 8, y + h + 8, outline=col, width=4)
    elif t == "arrow": c.create_line(x, y, x + w, y + h, fill=col, width=4, arrow=tk.LAST)
    else: c.create_rectangle(x - 6, y - 6, x + w + 6, y + h + 6, outline=col, width=4)
    if s.get("label"): c.create_text(x, max(y - 14, 12), text=s["label"], fill=col, font=("Arial", 16, "bold"), anchor="sw")
r.bind("<Button-1>", lambda e: r.destroy()); r.after(int(secs * 1000), r.destroy); r.mainloop()
