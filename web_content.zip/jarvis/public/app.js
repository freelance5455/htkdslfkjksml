const $ = (id) => document.getElementById(id);
const orb = $("orb"), statusEl = $("status"), logEl = $("log"), iasEl = $("ias");
const store = {
  get: (k, d) => { try { return localStorage.getItem(k) ?? d; } catch { return d; } },
  set: (k, v) => { try { localStorage.setItem(k, v); } catch {} },
};

let history = [];
let recog = null;
let enabled = false;   // escuta ligada pelo usuário
let awake = false;     // ouviu "Jarvis" e espera o comando
let busy = false;      // pensando ou falando
let awakeTimer = null;

function setState(cls, text) {
  orb.className = cls || "";
  statusEl.textContent = text;
}
function addMsg(cls, text) {
  const d = document.createElement("div");
  d.className = "msg " + cls;
  d.textContent = text;
  logEl.appendChild(d);
  logEl.scrollTop = logEl.scrollHeight;
}

/* ---------- Voz (síntese) ---------- */
let voices = [];
function loadVoices() {
  voices = speechSynthesis.getVoices();
  const sel = $("voice");
  sel.innerHTML = "";
  const sorted = [...voices].sort((a, b) => score(b) - score(a));
  for (const v of sorted) {
    const o = document.createElement("option");
    o.value = v.name;
    o.textContent = `${v.name} (${v.lang})`;
    sel.appendChild(o);
  }
  const saved = store.get("voice", "");
  if (saved && voices.some((v) => v.name === saved)) sel.value = saved;
}
// Prefere vozes masculinas em pt-BR; depois en-GB masculinas.
function score(v) {
  const n = v.name.toLowerCase();
  let s = 0;
  if (v.lang.toLowerCase().startsWith("pt-br")) s += 5;
  if (/male|masculin|daniel|ricardo|antonio|felipe|google português/.test(n) && !/female|feminin/.test(n)) s += 3;
  if (v.lang.toLowerCase() === "en-gb") s += 1;
  return s;
}
speechSynthesis.onvoiceschanged = loadVoices;
loadVoices();

function speak(text) {
  return new Promise((resolve) => {
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    const v = voices.find((x) => x.name === $("voice").value);
    if (v) { u.voice = v; u.lang = v.lang; } else u.lang = "pt-BR";
    u.pitch = Number($("pitch").value);
    u.rate = Number($("rate").value);
    u.onend = u.onerror = () => resolve();
    speechSynthesis.speak(u);
  });
}

/* ---------- Perguntar às IAs ---------- */
async function ask(question) {
  if (busy) return;
  busy = true;
  stopRecog();
  addMsg("you", question);
  setState("thinking", "Consultando as IAs…");
  try {
    const r = await fetch("/api/ask", {
      method: "POST",
      headers: { "content-type": "application/json", "x-jarvis-key": store.get("pass", "") },
      body: JSON.stringify({ question, history }),
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.error || "Erro " + r.status);
    history.push({ role: "user", content: question }, { role: "assistant", content: d.answer });
    history = history.slice(-12);
    addMsg("bot", d.answer);
    setState("speaking", "Falando…");
    await speak(d.answer);
  } catch (e) {
    addMsg("err", e.message);
    setState("", e.message);
    await speak("Desculpe, houve um problema. " + (e.message.includes("Senha") ? "A senha está incorreta." : ""));
  }
  busy = false;
  awake = false;
  if (enabled) startRecog(); else setState("", "Toque no círculo para ativar");
}

/* ---------- Reconhecimento de voz ---------- */
const SR = window.SpeechRecognition || window.webkitSpeechRecognition;

function stopRecog() {
  if (recog) { recog.onend = null; try { recog.abort(); } catch {} recog = null; }
}
function sleepAgain() { awake = false; clearTimeout(awakeTimer); if (enabled && !busy) setState("listening", 'Diga "Jarvis"…'); }

function startRecog() {
  if (!SR) { setState("", "Este navegador não tem reconhecimento de voz. Use o Chrome."); return; }
  stopRecog();
  recog = new SR();
  recog.lang = "pt-BR";
  recog.continuous = true;
  recog.interimResults = false;
  recog.onresult = (ev) => {
    const text = ev.results[ev.results.length - 1][0].transcript.trim();
    if (!text || busy) return;
    const m = text.match(/\b(j[aá]r?vis|jarbis|gervis|j[áa]rvez)\b[\s,.!?:-]*(.*)$/i);
    if (m) {
      const rest = m[2].trim();
      if (rest) return ask(rest);
      awake = true;
      setState("awake", "Pois não? Estou ouvindo…");
      speak("Pois não?").then(() => { if (enabled && !busy) startRecog(); });
      clearTimeout(awakeTimer);
      awakeTimer = setTimeout(sleepAgain, 10000);
    } else if (awake) {
      clearTimeout(awakeTimer);
      ask(text);
    }
  };
  recog.onerror = (e) => {
    if (e.error === "not-allowed" || e.error === "service-not-allowed") {
      enabled = false;
      setState("", "Permita o microfone nas configurações do navegador.");
    }
  };
  // O Chrome encerra a escuta de tempos em tempos; reinicia sozinho.
  recog.onend = () => { if (enabled && !busy) setTimeout(startRecog, 300); };
  try { recog.start(); } catch {}
  if (!awake) setState("listening", 'Diga "Jarvis"…');
}

orb.onclick = () => {
  if (enabled) {
    enabled = false; awake = false; stopRecog(); speechSynthesis.cancel();
    setState("", "Toque no círculo para ativar");
  } else {
    enabled = true;
    startRecog();
  }
};

$("form").onsubmit = (e) => {
  e.preventDefault();
  const q = $("text").value.trim();
  if (q) { $("text").value = ""; ask(q); }
};

/* ---------- Configurações ---------- */
$("cfg").onclick = () => $("dlg").showModal();
$("close").onclick = () => $("dlg").close();
$("pass").value = store.get("pass", "");
$("pass").oninput = () => store.set("pass", $("pass").value);
$("voice").onchange = () => store.set("voice", $("voice").value);
for (const [id, out, def] of [["pitch", "pv", "0.8"], ["rate", "rv", "0.95"]]) {
  $(id).value = store.get(id, def);
  $(out).textContent = $(id).value;
  $(id).oninput = () => { $(out).textContent = $(id).value; store.set(id, $(id).value); };
}
$("test").onclick = () => speak("Boa noite. Todos os sistemas estão operacionais.");

fetch("/api/status").then((r) => r.json()).then((s) => {
  const nomes = { claude: "Claude", chatgpt: "ChatGPT", grok: "Grok", gemini: "Gemini" };
  iasEl.textContent = s.ias.length ? "IAs ativas: " + s.ias.map((n) => nomes[n]).join(" · ") : "Nenhuma IA configurada no servidor";
  if (s.senha && !store.get("pass", "")) $("dlg").showModal();
}).catch(() => { iasEl.textContent = "Servidor indisponível"; });

if ("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js").catch(() => {});
