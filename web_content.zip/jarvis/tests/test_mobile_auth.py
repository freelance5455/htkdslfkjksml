from fastapi.testclient import TestClient
from config.settings import get_settings
from main import app


def test_mobile_page_is_public_and_served():
    with TestClient(app) as client:
        response = client.get('/mobile/')
        assert response.status_code == 200
        assert 'JARVIS' in response.text


def test_api_rejects_missing_token():
    with TestClient(app) as client:
        response = client.get('/api/system/status')
        assert response.status_code == 401


def test_api_accepts_configured_token(monkeypatch):
    cfg = get_settings()
    monkeypatch.setattr(cfg, 'access_token', type(cfg.access_token)('test-token-123'))
    with TestClient(app) as client:
        response = client.get('/api/system/status', headers={'Authorization': 'Bearer test-token-123'})
        assert response.status_code == 200

def test_mobile_assets_and_manifest_are_available():
    with TestClient(app) as client:
        assert client.get('/mobile/manifest.webmanifest').status_code == 200
        assert client.get('/mobile/assets/icon.svg').status_code == 200
        assert client.get('/mobile/sw.js').status_code == 200
