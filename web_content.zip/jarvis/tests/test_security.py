import pytest
from security.action_validator import resolve_allowed_path, PermissionError

def test_rejects_path_outside_allowed_roots(monkeypatch, tmp_path):
    from config.settings import get_settings
    cfg = get_settings()
    monkeypatch.setattr(cfg, "allowed_roots", str(tmp_path / "safe"))
    with pytest.raises(PermissionError):
        resolve_allowed_path(str(tmp_path / "outside" / "secret.txt"))

def test_accepts_path_inside_allowed_roots(monkeypatch, tmp_path):
    from config.settings import get_settings
    cfg = get_settings()
    root = tmp_path / "safe"
    monkeypatch.setattr(cfg, "allowed_roots", str(root))
    assert resolve_allowed_path(str(root / "notes.txt")) == (root / "notes.txt").resolve()
