# JARVIS Assistant (No LLM/SLM)

A beginner-friendly Android starter app with a futuristic dark UI, rule-based command matching, built-in mini-lessons, device-local chat history, Android text-to-speech, optional speech input, calculator, date/time, and optional browser search.

## Important limitations
- This is not ChatGPT and does not use an LLM/SLM. It only answers supported commands and built-in lessons.
- Android speech recognition availability and offline behavior depend on the speech service and language packs installed on the device. `EXTRA_PREFER_OFFLINE` is a preference, not a guarantee.
- Online search opens the device browser and sends the search query to the selected provider.
- Chat history uses WebView local storage and is stored in the app's local data. Clearing app data/uninstalling the app removes it.

## Build APK
1. Install Android Studio and its Android SDK (API 35 or compatible).
2. Open this `JarvisAssistant` folder in Android Studio.
3. Allow Gradle sync to complete.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location. For a debug build it is usually `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer the APK to your Android phone and install it. You may need to allow installation from that file manager.

No API keys, cloud database, or LLM/SLM are included.
