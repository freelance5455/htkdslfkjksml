# JARVIS

backend/  FastAPI: auth, streaming LLM, tool loop, confirmation gate, journal, serves the UI
agent/    desktop agent (Windows/macOS/Linux): open apps, type, click, scroll, OCR
backend/static/index.html  the interface (voice, wake word, animation, risk calculator)

## Run
    cd backend && pip install -r requirements.txt
    export ANTHROPIC_API_KEY=...  JARVIS_TOKEN=$(openssl rand -hex 24)
    uvicorn main:app --host 0.0.0.0 --port 8000
Open http://localhost:8000 (voice needs HTTPS off-localhost: use a tunnel or reverse proxy).

    cd agent && pip install -r requirements.txt   # also install the Tesseract OCR program
    JARVIS_URL=ws://localhost:8000 JARVIS_TOKEN=<same token> python desktop_agent.py

## Status (untested end to end: written without network access)
Implemented: token auth, streamed replies, multistep tool loop, per-action confirmation, emergency stop, desktop actions, OCR, trade risk tool, journal API.
Not built: Android/iOS apps, vision analysis of chart screenshots, backtesting, broker APIs, cloud sync, neural TTS voice, Hindi tuning, tests.
macOS needs Accessibility and Screen Recording permission for the agent. Android/iOS need native apps (AccessibilityService on Android; iOS blocks cross-app control).

## Answers, web and screen marking
- Any question: the brain answers directly and uses built-in web search for current facts (a search engine, not Google itself).
- "Mark the Submit button": the agent OCRs the screen, finds the text and draws red boxes for 6 seconds (Windows/macOS; click to dismiss).
- Marking over other apps on a phone needs a native Android app with overlay permission (not built).
