# Jarvis

A personal AI assistant that uses **Qwen3** as its brain. Talk to it by voice, and it can run your social media, your dropshipping store and your marketing, and operate apps on your Android phone.

```
jarvis/
  server/    the brain: Qwen3 tool-calling agent, social + Shopify connectors, approval queue, scheduler, web dashboard
  android/   the phone app: "Jarvis" wake word, voice in/out, background service, control of other apps
```

## What it does

| You want | How Jarvis does it |
|---|---|
| Talk to it | Phone: Android speech recognition + text-to-speech. Browser: Web Speech API. |
| Wake word "Jarvis" | Phone: Picovoice Porcupine (built-in "Jarvis" keyword, runs on the phone). Browser: listens while the tab is open. |
| Run in the background like MacroDroid | Android foreground service with a notification. |
| Operate third-party apps | Android Accessibility Service: open apps, tap by visible text, type, scroll, back, home. |
| Social media | Queue posts (optionally scheduled) to Facebook Pages and X through their official APIs. |
| Dropshipping | Shopify Admin API: list orders and products, change prices. |
| Digital marketing | Qwen3 writes captions, ad copy, campaign plans and content calendars, then queues them as posts. |
| Hybrid Qwen3 | Quick commands are handled by rules on the phone, everything else goes to Qwen3 in the cloud, and an optional on-device model is the offline fallback. |

**Anything that publishes or changes money-related data waits for your approval.** Jarvis queues it, you tap Approve in the dashboard, then it goes out. Scheduled posts go out at their time once approved.

## What you need to supply

- A Qwen API key (Alibaba Cloud Model Studio or OpenRouter). Without one the server runs in demo mode with a few canned commands.
- A free Picovoice access key for the phone wake word: console.picovoice.ai
- Credentials for each account you want connected (all optional): see `server/.env.example`.

## 1. Run the server

Needs Node 18 or newer. There are no dependencies to install.

```
cd server
cp .env.example .env     # then export the values, or set them in your host's dashboard
JARVIS_TOKEN=choose-a-long-secret node src/index.js
```

Open http://localhost:3000, enter the token, and chat. `npm test` runs the end-to-end test (demo mode, no keys needed).

### Deploy it (AppDeploy or any Node host)

Upload the `server/` folder, set the start command to `node src/index.js`, and add the environment variables from `.env.example`. It listens on `PORT`. Give it a persistent disk, or set `JARVIS_DATA_FILE` to a path on one, otherwise the approval queue resets on each restart. You must use HTTPS: browsers only allow the microphone on HTTPS pages, and the phone app only talks to HTTPS servers.

## 2. Connect your accounts

- **Qwen3**: set `QWEN_API_KEY`. Check the exact model name in your provider's console and set `QWEN_MODEL` if it differs from the default.
- **Facebook Page**: `FACEBOOK_PAGE_ID` and a Page access token with `pages_manage_posts`.
- **X**: an OAuth 2.0 user access token with `tweet.write`. These expire, so you will need to refresh it.
- **Shopify**: create a custom app in your store admin and give it `read_orders`, `read_products`, `write_products`.

The dashboard header shows which are connected. Unconfigured connectors do a harmless dry run.

## 3. Build the Android app

1. Install Android Studio and open the `android/` folder. Accept the Gradle prompts.
2. Plug in your phone (USB debugging on) and press Run.
3. In the app, enter the server address, the access token and your Picovoice key, then tap **Start Jarvis**.
4. Do the three one-time setup buttons: turn on accessibility control (Settings > Accessibility > Jarvis), allow display over other apps (needed to open apps from the background), and exempt Jarvis from battery optimisation (so the phone does not kill it). Some phone brands (Xiaomi, Oppo, Samsung and others) have their own extra "autostart" and "background" switches to allow too.
5. Say **"Jarvis"**, wait for the beep, then speak.

Try: "open YouTube", "go back", "what time is it", "write a Facebook post about our new phone case and queue it for tomorrow 9am", "show my open orders".

## Honest limits

- **The Android app has not been compiled or run.** I wrote it without an Android SDK available, so expect a few small fixes on the first build (dependency versions, especially `porcupine-android`, are the likeliest). The server and dashboard are tested.
- **The real Qwen call is untested.** The tool-calling loop is tested with a stand-in model. The first call to the real API may need a small tweak for your provider's model name or options (`QWEN_EXTRA_BODY`).
- **On-device Qwen3 is a plug-in, not bundled.** Phone models are big and need a runtime (llama.cpp, MLC LLM or MediaPipe). `Brain.kt` has a `LocalModel` interface ready for it. Until you plug one in, quick commands run on-device by rules and everything else needs internet.
- **It does not "become" a trained model.** Qwen3 is used as-is; Jarvis is the app, tools and prompts around it.
- **Background limits.** Android 14+ does not let a microphone service start itself at boot, so open the app once after a restart. Phone makers can still kill background apps despite the settings above.
- **Accessibility control** works across most apps, but apps that block it (banking apps, some secure screens) will not respond. Google Play restricts this permission for non-accessibility apps, so this build is for personal sideloading, not the Play Store.
- **Use official APIs for social media.** Having Jarvis tap through Instagram or TikTok screens can break their terms and get accounts banned. Instagram and TikTok connectors are not included because their posting APIs need app review.
- **Browser wake word** only works while the dashboard tab is open and in the foreground, and needs Chrome, Edge or Safari.
- Never put your access token or API keys in a public place. Anyone with the token can use your Jarvis.
