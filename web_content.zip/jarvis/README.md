# JARVIS — Windows Engine + Android Remote

A modular personal-assistant backend with a mobile web interface. The Windows PC runs the AI/backend and approved local tools; an Android phone connects over the same trusted Wi-Fi network. The mobile UI is served by the Windows backend, so you do not need to install a separate Android app for this stage.

## Requirements
- Windows 10/11 and Python 3.11+
- Android phone with a modern browser (Chrome recommended)
- Both devices on the same trusted private Wi-Fi network
- OpenAI API key and a supported model name (required for AI chat)

## 1. Configure on Windows

1. Extract the project folder.
2. Copy `.env.example` to `.env`.
3. Open `.env` in Notepad.
4. Set `JARVIS_AI_API_KEY` to your OpenAI API key and `JARVIS_AI_MODEL` to a model enabled for your API account.
5. Replace `JARVIS_ACCESS_TOKEN` with a long random secret. The Windows launcher can generate one if the placeholder is still present.
6. Keep `.env` private; never send it to anyone or upload it to GitHub.

Example settings (use your own values):

```dotenv
JARVIS_HOST=0.0.0.0
JARVIS_PORT=8000
JARVIS_AI_PROVIDER=openai
JARVIS_AI_BASE_URL=https://api.openai.com/v1
JARVIS_AI_API_KEY=your_openai_api_key_here
JARVIS_AI_MODEL=your_available_model_name
JARVIS_ACCESS_TOKEN=replace_with_a_long_random_secret
JARVIS_ALLOWED_ROOTS=./workspace
```

## 2. Start JARVIS

Double-click `start_jarvis_windows.ps1` (or run it from PowerShell):

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\start_jarvis_windows.ps1
```

The script creates a virtual environment, installs dependencies, prints the PC's local network addresses, and starts the server. If Windows Firewall asks, allow Python on **Private networks only**. Do not allow public-network access.

## 3. Connect your Android phone

1. Connect your phone to the same Wi-Fi network as the PC.
2. On the phone, open the address printed by the startup script, ending in `/mobile/`. Example: `http://192.168.1.20:8000/mobile/` (your address will differ).
3. Enter the JARVIS access token from the `JARVIS_ACCESS_TOKEN` line in your Windows `.env` file.
4. Tap **Connect**. You can then chat and check PC system status.
5. Add the page to your phone's home screen from the browser menu for app-like access.

If it cannot connect, check that both devices are on the same Wi-Fi, Windows is awake, the server window is still running, and the Private-network firewall rule permits port 8000. Some guest Wi-Fi networks isolate connected devices.

## Mobile voice notes

The mobile page uses the browser's Web Speech recognition (when available) and Android's speech synthesis. Browser support varies. Microphone recognition generally requires a secure browser context; plain HTTP on a private LAN may allow chat but may not expose speech recognition. A later deployment step can add local HTTPS certificates for a smoother installable PWA and microphone experience.

## API
- `GET /health` — basic health check (no token)
- `GET /mobile/` — mobile interface
- `GET /api/system/status` — authenticated PC metrics
- `POST /api/chat` — authenticated OpenAI chat
- `POST /api/files/folders`, `POST /api/files/text`, `GET /api/files/text` — authenticated allowlisted file operations
- `GET/POST /api/reminders`, `GET/POST /api/tasks`, `GET/POST /api/notes` — authenticated productivity storage
- `WS /ws` — authenticated WebSocket; first JSON message must be `{"type":"auth","token":"YOUR_TOKEN"}`

## Security boundaries
- The access token is a shared bearer secret. Anyone who has it can use the protected API; do not share it.
- This setup is intended for a trusted private LAN only. It uses HTTP by default, so the token is not encrypted in transit. Do not use it on public Wi-Fi or expose port 8000 to the public internet. Use HTTPS/VPN for access outside the home network.
- Keep `JARVIS_ALLOWED_ROOTS` narrow. File tools cannot escape those roots.
- No arbitrary shell command endpoint is exposed. Do not add unrestricted command execution without a separate permission/confirmation design.
- The mobile browser stores the access token in its local storage until you clear it using the app's **Clear saved details** control.

## Current implementation status
- Implemented: OpenAI Responses API chat adapter, persistent conversation history, SQLite memory foundation, system metrics, allowlisted file operations, reminders/tasks/notes API, audit logging foundation, mobile web interface, token-authenticated HTTP/WebSocket API, Windows launcher.
- Still to build: verified Fish Audio TTS adapter, robust speech-to-text service, wake-word listener, streaming UI, HTTPS pairing/certificate flow, device-specific token management, richer Windows app automation with confirmations, web research and calendar/weather integrations.

## Fish Audio
The supplied Fish Audio URL appears to identify a voice/model, not an API key. Its model ID is present in `.env.example` as a reference only. Add a real Fish Audio API key to `JARVIS_FISH_AUDIO_API_KEY` when you have one; provider-specific TTS has not yet been implemented or verified.
