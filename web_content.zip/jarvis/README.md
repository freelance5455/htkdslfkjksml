# J.A.R.V.I.S. — assistente de voz com Claude, ChatGPT, Grok e Gemini

Você diz "Jarvis, ..." e o app pergunta às quatro IAs ao mesmo tempo. O Claude junta as respostas e o Jarvis fala o resultado.

## Como funciona

- `server.js`: servidor (sem dependências, só Node 18+). Guarda as chaves e conversa com as IAs.
- `public/`: o app do celular (instalável, com reconhecimento de voz e fala).

As chaves ficam **só no servidor**. Nunca coloque chaves dentro do app.

## Passo 1 — Colocar o servidor no ar (precisa ser público para o celular acessar)

Use qualquer hospedagem que rode Node, por exemplo Render, Railway ou Fly.io:

1. Suba esta pasta para um repositório no GitHub.
2. Crie um serviço web na hospedagem apontando para o repositório.
   - Comando de build: vazio
   - Comando de start: `npm start`
3. Cadastre estas variáveis de ambiente no painel da hospedagem:
   - `ANTHROPIC_API_KEY` (Claude)
   - `OPENAI_API_KEY` (ChatGPT)
   - `XAI_API_KEY` (Grok)
   - `GEMINI_API_KEY` (Gemini)
   - `APP_PASSWORD` (uma senha sua; **obrigatória na prática**, senão qualquer pessoa com o link gasta seus créditos)
4. Abra o endereço que a hospedagem der (precisa ser `https://`, senão o microfone não funciona).

Para testar no computador: copie `.env.example` para `.env`, preencha, rode `npm start` e abra `http://localhost:8080`.

## Passo 2 — Usar no celular

1. Abra o endereço no **Chrome** do Android.
2. Digite a senha (⚙ no canto) e permita o microfone.
3. Menu do Chrome → **Instalar app** (ou "Adicionar à tela inicial").
4. Abra o Jarvis, toque no círculo e diga "Jarvis, que horas são?".

## Passo 3 — Gerar o APK (opcional)

1. Entre em `pwabuilder.com`, cole o endereço do seu servidor e escolha **Android**.
2. Baixe o pacote, que contém o APK. Instale no celular permitindo "fontes desconhecidas".

## Limites importantes

- A escuta pela palavra "Jarvis" só funciona com o app **aberto e a tela ligada**. Para escutar com a tela apagada seria preciso um app Android nativo.
- A voz usa as vozes do próprio celular. Em ⚙ você escolhe a voz e ajusta tom e velocidade. Não é a voz do ator do filme.
- Cada pergunta consulta as quatro IAs, então custa mais que usar uma só. Para economizar, deixe vazia a chave das que não quiser.
- Se algum modelo mudar de nome, defina `CLAUDE_MODEL`, `OPENAI_MODEL`, `GROK_MODEL` ou `GEMINI_MODEL`.
