from pathlib import Path
from security.action_validator import resolve_allowed_path
from security.audit_log import record_action

class FileManager:
    def create_folder(self, path: str) -> str:
        target = resolve_allowed_path(path)
        target.mkdir(parents=True, exist_ok=True)
        record_action("file.mkdir", "success", {"path": str(target)})
        return str(target)

    def create_text_file(self, path: str, content: str) -> str:
        target = resolve_allowed_path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        record_action("file.create", "success", {"path": str(target)})
        return str(target)

    def read_text_file(self, path: str) -> str:
        target = resolve_allowed_path(path)
        if not target.is_file() or target.stat().st_size > 2_000_000:
            raise ValueError("File does not exist, is not a file, or exceeds the 2 MB read limit.")
        record_action("file.read", "success", {"path": str(target)})
        return target.read_text(encoding="utf-8")
