"""Small allowlist launcher. No shell command strings are accepted."""
import os
import platform
import subprocess
from security.audit_log import record_action

APP_ALLOWLIST = {
    "notepad": ["notepad.exe"],
    "calculator": ["calc.exe"],
    "paint": ["mspaint.exe"],
    "file explorer": ["explorer.exe"],
    "settings": ["cmd", "/c", "start", "ms-settings:"],
}

class WindowsAppLauncher:
    def launch(self, app_name: str) -> dict:
        if platform.system() != "Windows":
            raise RuntimeError("Application launching is only enabled on Windows hosts.")
        key = app_name.strip().lower()
        if key not in APP_ALLOWLIST:
            raise ValueError(f"'{app_name}' is not in the approved application list.")
        args = APP_ALLOWLIST[key]
        if key == "settings":
            os.startfile("ms-settings:")
        else:
            subprocess.Popen(args, shell=False, close_fds=True)
        record_action("app.launch", "success", {"app": key})
        return {"launched": key}
