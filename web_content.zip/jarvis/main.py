from contextlib import asynccontextmanager
from pathlib import Path
import ipaddress
from fastapi import Depends, FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from config.settings import get_settings
from memory.database import initialize
from core.assistant import Assistant
from monitoring.system_monitor import snapshot
from automation.file_manager import FileManager
from productivity.manager import ProductivityManager
from security.audit_log import record_action
from security.auth import require_auth, authenticate_websocket

BASE_DIR = Path(__file__).resolve().parent

@asynccontextmanager
async def lifespan(app: FastAPI):
    cfg = get_settings()
    # A LAN-bound server must never start without a shared device token.
    try:
        is_loopback = ipaddress.ip_address(cfg.host).is_loopback
    except ValueError:
        is_loopback = cfg.host.lower() == "localhost"
    if not is_loopback and not cfg.access_token.get_secret_value():
        raise RuntimeError("Set JARVIS_ACCESS_TOKEN before binding JARVIS to a network interface.")
    initialize()
    for root in cfg.allowed_root_paths():
        root.mkdir(parents=True, exist_ok=True)
    yield

app = FastAPI(title="JARVIS API", version="0.2.0", lifespan=lifespan)
assistant = Assistant()
files = FileManager()
productivity = ProductivityManager()
app.mount("/mobile/assets", StaticFiles(directory=BASE_DIR / "mobile"), name="mobile-assets")

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=12000)
class FolderRequest(BaseModel):
    path: str = Field(min_length=1, max_length=1000)
class FileRequest(BaseModel):
    path: str = Field(min_length=1, max_length=1000)
    content: str = Field(max_length=1_000_000)
class ReminderRequest(BaseModel):
    title: str = Field(min_length=1, max_length=300)
    due_at: str | None = Field(default=None, max_length=80)
class TaskRequest(BaseModel):
    title: str = Field(min_length=1, max_length=300)
    details: str = Field(default="", max_length=4000)
    due_at: str | None = Field(default=None, max_length=80)
class NoteRequest(BaseModel):
    title: str = Field(min_length=1, max_length=300)
    content: str = Field(max_length=20000)

@app.get("/health")
async def health():
    return {"status": "ok", "app": get_settings().app_name, "version": "0.2.0"}

@app.get("/mobile/")
async def mobile_home():
    return FileResponse(BASE_DIR / "mobile" / "index.html")

@app.get("/mobile/manifest.webmanifest")
async def mobile_manifest():
    return FileResponse(BASE_DIR / "mobile" / "manifest.webmanifest", media_type="application/manifest+json")

@app.get("/mobile/sw.js")
async def mobile_service_worker():
    return FileResponse(BASE_DIR / "mobile" / "sw.js", media_type="application/javascript", headers={"Service-Worker-Allowed": "/"})

@app.get("/api/system/status", dependencies=[Depends(require_auth)])
async def system_status():
    return snapshot()

@app.post("/api/chat", dependencies=[Depends(require_auth)])
async def chat(req: ChatRequest):
    try:
        return {"response": await assistant.reply(req.message)}
    except Exception as exc:
        record_action("ai.chat", "failed", {"error_type": type(exc).__name__})
        # Avoid returning provider internals or request metadata to remote clients.
        raise HTTPException(status_code=503, detail="JARVIS could not reach its AI provider. Check the Windows server configuration and logs.") from exc

@app.post("/api/files/folders", dependencies=[Depends(require_auth)])
async def create_folder(req: FolderRequest):
    try:
        return {"path": files.create_folder(req.path)}
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

@app.post("/api/files/text", dependencies=[Depends(require_auth)])
async def create_file(req: FileRequest):
    try:
        return {"path": files.create_text_file(req.path, req.content)}
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

@app.get("/api/files/text", dependencies=[Depends(require_auth)])
async def read_file(path: str):
    try:
        return {"content": files.read_text_file(path)}
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

@app.get("/api/reminders", dependencies=[Depends(require_auth)])
async def list_reminders():
    return productivity.list_reminders()

@app.post("/api/reminders", dependencies=[Depends(require_auth)])
async def add_reminder(req: ReminderRequest):
    return productivity.add_reminder(req.title, req.due_at)

@app.get("/api/tasks", dependencies=[Depends(require_auth)])
async def list_tasks():
    return productivity.list_tasks()

@app.post("/api/tasks", dependencies=[Depends(require_auth)])
async def add_task(req: TaskRequest):
    return productivity.add_task(req.title, req.details, req.due_at)

@app.post("/api/notes", dependencies=[Depends(require_auth)])
async def add_note(req: NoteRequest):
    return productivity.add_note(req.title, req.content)

@app.get("/api/notes", dependencies=[Depends(require_auth)])
async def list_notes():
    return productivity.list_notes()

@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    await ws.accept()
    if not await authenticate_websocket(ws):
        await ws.close(code=1008, reason="Authentication required")
        return
    try:
        await ws.send_json({"type": "connection", "status": "connected"})
        while True:
            payload = await ws.receive_json()
            if payload.get("type") == "chat":
                try:
                    answer = await assistant.reply(str(payload.get("message", "")))
                    await ws.send_json({"type": "assistant_response", "text": answer})
                except Exception:
                    await ws.send_json({"type": "error", "message": "JARVIS could not reach its AI provider."})
            elif payload.get("type") == "system_status":
                await ws.send_json({"type": "system_status", "data": snapshot()})
            else:
                await ws.send_json({"type": "error", "message": "Unsupported event type"})
    except WebSocketDisconnect:
        pass
