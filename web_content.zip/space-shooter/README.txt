Space Shooter - jeu web (HTML/CSS/JS, aucune dépendance)
Ouvre index.html dans ton navigateur, ou héberge le dossier tel quel.
Contrôles : flèches / WASD (ZQSD) ou souris / doigt. Le tir est automatique.
