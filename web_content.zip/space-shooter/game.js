const cv = document.getElementById('game'), ctx = cv.getContext('2d');
const W = cv.width, H = cv.height;
const menu = document.getElementById('menu'), bestEl = document.getElementById('best');
let best = +(localStorage.getItem('ss_best') || 0);
bestEl.textContent = 'Meilleur score : ' + best;

let player, bullets, enemies, particles, stars, score, lives, time, spawnT, running = false, shootT;
const keys = {};
addEventListener('keydown', e => keys[e.key.toLowerCase()] = true);
addEventListener('keyup', e => keys[e.key.toLowerCase()] = false);

function pointer(e) {
  const r = cv.getBoundingClientRect(), t = e.touches ? e.touches[0] : e;
  if (!player) return;
  player.tx = (t.clientX - r.left) / r.width * W;
  player.ty = (t.clientY - r.top) / r.height * H - 40;
}
cv.addEventListener('mousemove', pointer);
cv.addEventListener('touchstart', pointer, {passive:true});
cv.addEventListener('touchmove', e => { e.preventDefault(); pointer(e); }, {passive:false});

function reset() {
  player = {x: W/2, y: H-80, tx: null, ty: null, r: 14, inv: 0};
  bullets = []; enemies = []; particles = [];
  stars = Array.from({length: 70}, () => ({x: Math.random()*W, y: Math.random()*H, s: .5+Math.random()*2}));
  score = 0; lives = 3; time = 0; spawnT = 0; shootT = 0;
}
function boom(x, y, c) {
  for (let i = 0; i < 14; i++) {
    const a = Math.random()*6.28, v = 1+Math.random()*4;
    particles.push({x, y, vx: Math.cos(a)*v, vy: Math.sin(a)*v, l: 30, c});
  }
}
function spawn() {
  const big = Math.random() < .2;
  enemies.push({x: 30+Math.random()*(W-60), y: -30, r: big?24:14, hp: big?4:1,
    vy: (big?.8:1.4)+time/4000, vx: (Math.random()-.5)*1.5, big});
}
function update() {
  time++;
  // déplacement
  const sp = 5;
  if (keys['arrowleft']||keys['a']||keys['q']) {player.x -= sp; player.tx = null;}
  if (keys['arrowright']||keys['d']) {player.x += sp; player.tx = null;}
  if (keys['arrowup']||keys['w']||keys['z']) {player.y -= sp; player.ty = null;}
  if (keys['arrowdown']||keys['s']) {player.y += sp; player.ty = null;}
  if (player.tx != null) {
    player.x += (player.tx - player.x) * .25;
    player.y += (player.ty - player.y) * .25;
  }
  player.x = Math.max(player.r, Math.min(W-player.r, player.x));
  player.y = Math.max(player.r, Math.min(H-player.r, player.y));
  if (player.inv > 0) player.inv--;
  // tir auto
  if (--shootT <= 0) { bullets.push({x: player.x, y: player.y-16}); shootT = 10; }
  bullets.forEach(b => b.y -= 9);
  bullets = bullets.filter(b => b.y > -10);
  // ennemis
  if (--spawnT <= 0) { spawn(); spawnT = Math.max(15, 55 - time/60); }
  enemies.forEach(e => {
    e.y += e.vy; e.x += e.vx;
    if (e.x < e.r || e.x > W-e.r) e.vx *= -1;
  });
  // collisions balles / ennemis
  for (const e of enemies) for (const b of bullets) {
    if (!b.dead && Math.hypot(e.x-b.x, e.y-b.y) < e.r+4) {
      b.dead = true; e.hp--;
      if (e.hp <= 0) { e.dead = true; score += e.big ? 50 : 10; boom(e.x, e.y, e.big?'#fa4':'#f66'); }
    }
  }
  bullets = bullets.filter(b => !b.dead);
  // collisions joueur / ennemis
  for (const e of enemies) {
    if (!e.dead && player.inv === 0 && Math.hypot(e.x-player.x, e.y-player.y) < e.r+player.r-2) {
      e.dead = true; lives--; player.inv = 90; boom(player.x, player.y, '#6cf');
      if (lives <= 0) return gameOver();
    }
  }
  enemies = enemies.filter(e => !e.dead && e.y < H+40);
  particles.forEach(p => {p.x += p.vx; p.y += p.vy; p.l--;});
  particles = particles.filter(p => p.l > 0);
  stars.forEach(s => {s.y += s.s; if (s.y > H) {s.y = 0; s.x = Math.random()*W;}});
}
function draw() {
  ctx.fillStyle = '#05060f'; ctx.fillRect(0, 0, W, H);
  ctx.fillStyle = '#fff';
  stars.forEach(s => ctx.fillRect(s.x, s.y, s.s, s.s));
  // joueur
  if (player.inv % 10 < 5) {
    ctx.fillStyle = '#6cf'; ctx.beginPath();
    ctx.moveTo(player.x, player.y-player.r-4);
    ctx.lineTo(player.x+player.r, player.y+player.r);
    ctx.lineTo(player.x, player.y+player.r-6);
    ctx.lineTo(player.x-player.r, player.y+player.r);
    ctx.closePath(); ctx.fill();
  }
  ctx.fillStyle = '#ff6';
  bullets.forEach(b => ctx.fillRect(b.x-2, b.y-8, 4, 12));
  enemies.forEach(e => {
    ctx.fillStyle = e.big ? '#fa4' : '#f66';
    ctx.beginPath(); ctx.arc(e.x, e.y, e.r, 0, 6.28); ctx.fill();
    ctx.fillStyle = '#300';
    ctx.beginPath(); ctx.arc(e.x, e.y, e.r/3, 0, 6.28); ctx.fill();
  });
  particles.forEach(p => {ctx.globalAlpha = p.l/30; ctx.fillStyle = p.c; ctx.fillRect(p.x, p.y, 3, 3);});
  ctx.globalAlpha = 1;
  ctx.fillStyle = '#fff'; ctx.font = '18px system-ui';
  ctx.textAlign = 'left'; ctx.fillText('Score : ' + score, 12, 26);
  ctx.textAlign = 'right'; ctx.fillText('♥'.repeat(lives), W-12, 26);
}
function loop() {
  if (!running) return;
  update();
  if (running) { draw(); requestAnimationFrame(loop); }
}
function gameOver() {
  running = false;
  if (score > best) { best = score; try { localStorage.setItem('ss_best', best); } catch(e){} }
  bestEl.textContent = 'Score : ' + score + ' · Meilleur : ' + best;
  document.querySelector('#menu h1').textContent = 'GAME OVER';
  document.getElementById('start').textContent = 'Rejouer';
  menu.classList.remove('hidden');
}
document.getElementById('start').onclick = () => {
  menu.classList.add('hidden'); reset(); running = true; loop();
};
reset(); draw();
