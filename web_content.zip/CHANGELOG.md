# Changelog

## v10 — maintenance and handoff improvements
- Bumped the service-worker cache namespace so deployed clients can pick up this asset set.
- Corrected the fallback setup screen's outdated database/role instructions.
- Added `CLAUDE.md` with concise architecture, security guardrails, deployment notes and audit findings to reduce repeated context gathering.
- No production Supabase schema, data, auth settings, or policies were changed.

## v10 — platform quality pass

- Fixed a malformed body-background CSS rule so the intended subtle background pattern applies correctly.
- Added a keyboard-accessible skip link and main-content landmarks for the setup, sign-in, and signed-in screens.
- Added defensive Netlify security headers, including a Content Security Policy tailored to the current Supabase, Google Fonts, jsDelivr, and Turnstile dependencies.
- Added the main stylesheet and 512px app icon to the service-worker precache, and bumped the cache namespace so existing clients refresh.
- Removed the signed-in email/role console log to avoid unnecessarily exposing account details in browser developer tools.
- Kept the Supabase browser configuration public by design; no service-role key or database secret was added to the frontend.

- Improved artwork preview handling to reuse and revoke temporary object URLs, preventing avoidable memory leaks when users select or replace large cover images.
- Escaped signed artwork URLs before placing them in HTML attributes.
- Added `BACKEND-SECURITY-REVIEW.md` and `QA-CHECKLIST.md` so unresolved database review items and release tests are explicit rather than implied to be fixed.


## v12 — usability and privacy refinement

- Corrected literal newline characters in the document head/body markup.
- Made the sign-in screen and setup screen use a valid main landmark for keyboard navigation.
- Removed the internal Supabase user UUID from the normal settings screen; the signed-in email remains visible.
- Updated the setup fallback text so it points to the existing Supabase project and migration workflow rather than an outdated schema file.
- Bumped the service-worker cache namespace so returning visitors receive the updated files.


## v13 — RouteNote-aware manual handoff

- Made the lack of RouteNote API integration explicit in the release wizard and label handoff.
- Clarified that portal store/territory selections are planning preferences and must be selected again in RouteNote.
- Added a downloadable plain-text RouteNote handoff sheet with release/track metadata and a manual submission checklist.
- Added official RouteNote support references and a documented manual workflow.
- Corrected the artwork picker to accept JPG only, matching its validation, and clarified exact 3000 × 3000 px artwork guidance.
- Added track-title length and duplicate-title checks and made distributor metadata warnings clearer.
- Label status history now records that the release was manually entered into RouteNote and submitted for moderation.


## v14 — artist-facing language separation

- Removed distributor-specific references from artist-facing release steps and status messaging.
- Reframed store/territory selections as artist preferences for label review.
- Replaced distributor-specific handoff UI wording with neutral release-processing language.
- Kept the distributor's operational workflow in an internal staff document and internal handoff sheet.


## v15 — frontend/backend alignment

- Updated the live Supabase release-sent notification trigger to use generic “Release processing started” language and avoid distributor-specific wording in artist notifications.
- Revoked direct API execution grants for that trigger-only function while preserving its database-trigger behavior.
- Corrected the internal handoff text builder to produce real line breaks in downloaded staff sheets.
- Updated the service-worker cache namespace so deployed clients fetch the v15 assets.
- Corrected database documentation to match the live schema, including `release_stats`, role enum values, and actual storage bucket visibility.
- Recorded the live Supabase changes and remaining advisor review items; no broad RLS or storage policy changes were made.


## v16 — coordinated security and regression pass

- Restricted direct API execution for ten trigger-only `SECURITY DEFINER` helpers; verified `anon` and `authenticated` cannot execute those helpers directly while database triggers remain attached.
- Tightened `release_events` inserts so a signed-in user can add activity only for a release they own, administer, or can access through band membership.
- Verified `can_see_release` remains unavailable to `anon` and available to authenticated policy evaluation.
- Re-ran Supabase security advisors: trigger-only function warnings were reduced; remaining findings are intentional user-facing RPCs (including invite lookup) and disabled leaked-password protection, which still needs enabling in Supabase Auth settings.
- Bumped the service-worker cache namespace to `imposed-v15` so deployed clients refresh the updated assets.
- Expanded QA guidance to distinguish static checks from role-based end-to-end tests that require real test accounts.

## v17 — Multi-language foundation
- Added a language picker in the main navigation and account settings, with English, Spanish, French, German, Portuguese and Polish.
- Added exact-phrase translations for supported navigation, sign-in, account, status and common action labels. Newly rendered UI text is localized when it matches a supported phrase.
- Improved language switching so switching between languages and back to English restores the original UI text instead of getting stuck in the first translation.
- Added browser-language detection for first visits and local persistence for signed-out users.

## v18 — Persistent language preference and safe localization
- Added `profiles.preferred_language` in the live Supabase project as a nullable, constrained column. Existing profile rows remain valid; no existing release, user, or auth data was changed.
- Syncs a signed-in user's language choice to their own profile and restores it at next login; local browser preference remains available before login and if sync fails. Dates and number formatting follow the selected locale.
- Expanded supported translations and documented the feature in the database notes and QA checklist.
- Updated the service-worker cache namespace to `imposed-v18` so installed clients fetch the new localization and persistence code.
- This is still a supported-label localization layer, not a claim that every long-form screen, validation message, email, or system error is translated. Run the role-based deploy-preview checklist before production.

## v20 — Full visual redesign and Turnstile key confirmation
- Replaced the bright Spotify-green visual language with a dark slate/ink interface and restrained antique-gold accents across the portal.
- Restyled navigation, page surfaces, metric cards, release rows, forms, buttons, chips, builder steps, profile cards, notifications and mobile layouts while preserving existing view markup and workflows.
- Refreshed the actual authentication screen and used the supplied Imposed Entertainment logo artwork in the brand panel.
- Confirmed the user-provided public Cloudflare Turnstile site key in `config.js`; added Cloudflare host allowances to the Netlify Content Security Policy and bumped the service-worker cache version to avoid serving stale v18 assets.
- Static JS syntax, TOML parsing and ZIP integrity are checked before delivery. A live Turnstile challenge and authenticated end-to-end browser session still require testing on the deployed hostname and correct Supabase secret configuration.

## v21 — Real interface redesign (2026-10-17)
- Replaced the horizontal navigation bar with a persistent desktop workspace sidebar, grouped workspace and account navigation, and a responsive mobile header/menu.
- Rebuilt the visual system around an editorial paper-and-ink palette with cobalt/indigo actions, restrained semantic status colors, stronger typography, more useful spacing, clearer metric hierarchy, and structured cards/forms.
- Redesigned the actual sign-in screen as an indigo editorial welcome panel paired with a bright, high-contrast form card; uses the project's real uploaded water/flower artwork.
- Switched the Turnstile widget theme to light to suit the bright login form, retaining verification enforcement and the supplied public site key.
- Bumped the service-worker cache to `imposed-v21` to avoid reusing v20's cached assets.
- Validation: JavaScript syntax checks and ZIP integrity; browser screenshot/render test could not complete in this environment. Live authentication and Turnstile still require deploy-preview verification with the matching Supabase secret and allowed hostname.

## v22 — Music creator workspace redesign

- Replaced the previous editorial cobalt/white visual direction with an original music-workspace aesthetic: studio graphite surfaces, ember-coral primary actions, electric-violet secondary accents, artwork-friendly panels, and denser release-management layouts.
- Reworked workspace navigation, cards, status chips, forms, release builder, upload areas, login panel, and responsive mobile styling while retaining the existing application rendering and data flows.
- Updated browser theme color and service-worker cache namespace to `imposed-v22` to reduce stale-style reuse.
- No Supabase schema or authentication-flow changes in this UI-only release.
- Validation: JavaScript syntax, Netlify config syntax, ZIP integrity and key/config presence checked. A complete browser-rendered end-to-end test was not available in this environment.

## v23 — Discography, stats and a reliability pass

**New**
- Discography page (sidebar and mobile menu). Artists see every release they have, drafts included, grouped as Changes requested, Drafts, In review and Live, with filters and search. Label members see every artist's releases grouped by artist.
- Drafts are reachable again: Continue editing, Delete draft (owner only, drafts only, uploaded files removed best-effort).
- Changes Requested releases can now be edited and resubmitted. Before this the artist saw the label's note but had no way to act on it.
- Per-release Stats card: totals, per-period chart and platform rows. The label adds stats (`release_stats`: period, platform, streams, listeners, saves; re-saving the same release/period/platform replaces it). Artists read them. Stats CSV export.
- Request update (artist, on submitted/approved/live releases) posts a comment and an activity event the label is notified about. Reopen for edits (label) moves a release back to Changes Requested.
- Four-step progress strip (Files, Details, Review, Live) and cover thumbnails on release cards and dashboard rows. Back links return to where you came from.

**Fixed**
- Artists never see distributor wording: the internal "Sent to distributor" status now reads "Processing" for artists (label still sees the real status).
- Missing Notifications and Discover icons in the sidebar and mobile menu. Avatar button did nothing; it now opens your public page.
- Token refresh (switching back to the tab) reloaded the app and wiped half-written comments and form text. Background refreshes no longer re-render while someone is typing.
- To-do card had no padding. Artwork rules said "JPG / PNG, minimum" while validation requires an exact 3000 x 3000 JPG; now consistent.
- Removed implementation wording from user-facing copy (Supabase, profiles table, "real database record", "fabricated artists").
- Mobile menu now includes Discography and Sign out.
- Service worker is now network-first so a deploy is visible on the first reload (cache namespace `imposed-v23`).
- User-entered titles and artist names on the new screens are excluded from the language layer so a release called "Live" is never translated.

**Not changed**
- `release_stats` already existed with admin-only writes, so the stats feature needed no schema change.

**Database hardening (applied live 2026-10-18, migration `20261018120000_harden_release_status_rules.sql`)**
- Release status rules are now enforced by the database, not just the UI: artists can only edit Draft or Changes Requested releases, only move them Draft to Submitted, can only create Drafts and only delete their own Drafts. Label admins are unrestricted. Details and the 13 verification checks are in `BACKEND-SECURITY-REVIEW.md`.

**Validation**
- JavaScript syntax checks on every file.
- 42 end-to-end checks run in headless Chromium against an in-memory fake Supabase (real boot code and click handlers): discography sections and permissions, draft edit/delete, edit and resubmit, request update, label stats add/replace/delete/validation, back navigation, token-refresh behaviour, mobile menu and overflow, language switching, label view. Key fixes were mutation-tested to confirm the checks fail without them.
- Not run here: live Supabase, Google sign-in and Turnstile. Use the QA checklist on a deploy preview.


## v24 — audit fixes and label-standard metadata
- Artist-facing messages no longer name the distributor (audio/title checks); activity timeline shows "processing started" to artists.
- Added: language of lyrics, previously-released + original date, per-track explicit flag, featured artists, songwriters/composers, and a mandatory rights declaration. Included in metadata JSON, label detail page, handoff sheet and copy-all.
- Label can now Reject a submitted release with a reason (status existed but had no button).
- "Sent to distributor" status gets a colour; Settings shows a readable role.
- Requires migration `20261018150000_add_release_metadata_fields.sql` applied first. Cache bumped to v24.

## v25 — persistence, storage safety, polish
- Refresh/back keeps your page (hash routes: #/settings, #/release/<id> etc.).
- Free-plan safety: 50 MB per audio file, 150 MB per artist (set ARTIST_QUOTA_MB in config.js), usage meter in Settings, orphaned/replaced audio, artwork and profile pictures are deleted, profile pictures capped at 2 MB.
- Track saving now inserts new rows before removing old ones (no more lost tracklist on failure).
- Draft saves no longer spam the activity timeline; data-load failures now show a message.
- Quota is enforced in the browser only; for hard enforcement add a Storage policy.

## v26 — features, visual refresh, translations
- Duplicate a release as a new draft (metadata and track list, no audio/ISRC) for artists.
- Label can set a UPC on any release; artists see it on the release page. Needs migration `20261018160000_add_release_upc.sql`.
- Visual refresh: tighter type, rounder softer cards, clearer buttons and focus states, subtle page transition.
- Translations (ES, FR, DE, PT, PL) for the new v24-v26 labels.
