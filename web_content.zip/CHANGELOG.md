# Pocket APK Studio v0.10.0

- Added an offline Build Doctor for pasted Gradle/Android Studio/GitHub Actions logs.
- Added deterministic classifiers for common SDK/JDK/Gradle/plugin/namespace/manifest/resource/Kotlin/dependency/network/duplicate-class/memory/variant/wrapper errors.
- Build Doctor keeps the full log in memory only; exported diagnostics include matched categories and shortened redacted excerpts, not the raw pasted log.
- Added self-tests for JDK/namespace classification and synthetic-token redaction.
- Updated generated Kotlin Gradle Plugin template to 2.4.21 and setup-java action to v6 based on current official docs.
- Existing ZIP inspector, local asset audit, sandbox preview, source audit, templates, build profile and source/CI export retained.

This release does not compile APKs inside the HTML app. CI workflow generation is not evidence a cloud build was run.
