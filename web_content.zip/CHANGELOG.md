# CHANGELOG - مفكرة جني

## 0.3.1 (first pass, web app)
- Default addressee changed from "صديقي" to "أبا يزيد" (3 places in index.html:
  initial settings, greeting, and the name fallback on save).
  Note: users who already saved a name keep it. Only the default changes.

## Not changed in this pass (see TEST_REPORT.md)
- No Android project (Gradle, AndroidManifest, Capacitor config) was added.
- No native TextToSpeech, SpeechRecognizer, or Room storage.
- No speaker verification. Speech-to-text does not identify the speaker.
- Storage keys (janni.v1, janni-audio) were not touched.
