# Histórico de versões — Fluxo

Gerado pelo Fluxo Dev.

## 1.0.0 — 2026-10-11T15:43:26.157Z

- **Projeto inicial**
- Integração de compartilhamento nativo e seletor de arquivos para restauração.

