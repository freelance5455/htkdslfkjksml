# Changelog
## 1.0.0-phase1
- Interactive province map: 96 Voronoi cells (61 land provinces, 7 nations), sea, coasts, country borders.
- Zoom/pan with touch drag, pinch, wheel, buttons; fit-map; Political and Terrain map modes.
- Nation select, country colours, flags (generated), capitals (stars), country and province labels.
- Top bar: date, treasury (+/day), manpower (+/day), steel, coal, oil, food; pause/play and 5 speeds.
- Province panel (terrain, population, income, manpower, infrastructure, fort, resources, neighbours) and Country panel.
- Daily income/manpower/resource growth from owned provinces; monthly food upkeep.
- Save/load: autosave each game month + 3 manual slots; survives page reload.

## 2.0.0-phase2
- 6 unit types (infantry, militia, cavalry, artillery, engineers, light tanks) with gold, manpower, equipment, training time, speed/attack/defense/organization.
- Equipment stockpiles (rifles, horses, guns, vehicles) with an interim monthly arsenal until factories (Phase 4).
- Recruitment queue (max 8): resources paid up front, cancel refunds, units deploy at their province and join a friendly army there.
- Armies (max 9 units): select, move along shortest route (terrain, infrastructure, slowest unit), halt, merge, detach, disband.
- Generals: 5 per nation, skill 1-5 and trait; auto-assigned, changeable; skill boosts army attack/defense.
- Unit strength, organization and morale; org drops while marching, recovers in own territory.
- Army banners with flags and unit counts on the map, route lines, animated marching; Army Command screen.
- Every nation starts with 3 armies near its capital. Phase 1 saves still load.
- Movement is limited to your own provinces until war and borders are handled in Phase 3.

## 3.0.0-phase3
- War declarations (Country tab) and ceasefires (AI accepts if beaten, weaker, capital lost, or after 90 days; 30-day truce afterwards).
- Armies may enter enemy provinces while at war; they stop on arrival and keep a campaign goal.
- Battles: daily combat rounds between attackers and the province owner's armies. Firepower uses unit attack/defense, strength, organization, morale, generals, supply, terrain, fortifications and a technology hook (Phase 7). Engineers halve fortification bonuses.
- Casualties, morale and organization losses; a side below 25% organization breaks and retreats toward home (or is destroyed if cornered).
- Occupation: holding a province unopposed (8 days + 4 per fort level, +4 for capitals) transfers ownership; borders redraw immediately; income, manpower and resources follow.
- Capital capture: 25% of the treasury is seized and the loser's capital moves to its most populated province. Eliminated nations are removed; if you are eliminated the game ends.
- Fortifications up to level 3 (gold + time, faster with engineers) with +15% defense per level.
- Reinforcements: units in your own territory regain men from your manpower pool for a little gold.
- Basic enemy responses (recruit, attack weak adjacent provinces, retake lost ground, cover threatened borders) for nations at war.
- Map: battle markers, occupation progress shading, fort badges, war badge in the top bar; event log tab in Army Command.
- Old saves still load.

## 3.0.1-phase3-fix
- Fix: declaring war did nothing on Android. window.confirm() is blocked or auto-cancelled in many HTML-to-APK WebViews, so the confirmation always failed. Replaced with an in-game confirmation box (also used for Disband).
- Fix: the Declare war button sat at the bottom of the Country panel, off-screen on phones. War status and buttons are now at the top of the Country tab, and foreign provinces show a Declare war button at the top of the Province tab.

## 4.0.0-phase4
- Province buildings: civilian factories, military factories, shipyards (coastal), infrastructure, railways, ports. Building slots depend on population (capitals get more). Buildings change hands with conquered provinces.
- Construction queue: civilian factories supply construction points per day (consumer goods take a share, depending on tax policy); gold is paid up front; cancel refunds gold. Up to 12 projects.
- Equipment production: military factories are assigned to Rifles, Artillery guns and Vehicles lines. Each line consumes steel, coal, oil and rubber; a shortage of any input slows the whole line. Horses breed on farmland. The old free monthly arsenal is gone.
- Recruiting and reinforcing units now draw on the equipment stockpile (reinforcements also need equipment).
- New resource: rubber. Resources now come from provinces every day; food is eaten by population and armies.
- Budget: taxes minus army upkeep and industry upkeep = net income per day. Tax policy Low / Normal / High.
- Shortages: starving halves manpower growth and drains morale; an empty treasury drains morale. Warnings on the top bar and in the Industry panel.
- Trade: buy and sell resources at drifting prices, limited per month by ports and shipyards.
- Railways and infrastructure speed army movement.
- Other nations run a basic economy autopilot (assign factories, build, buy scarce resources).
- Fix: tab and button handlers in the Army Command and Industry screens could be overwritten whenever the province panel refreshed (every game day while time runs). Handlers are now scoped to their own panels.
- Old saves still load (they start with default buildings and rubber).

## 5.0.0-phase5
- New 🤝 Diplomacy screen (Nations / Inbox / Treaties / Wars) plus a Diplomacy button in every Country tab.
- Relations (-100..100) between all nations, seeded from government type and borders; drift to neutral over time; Improve relations (30 gold) and Gifts.
- Treaties: Non-aggression pact (1 year), Alliance (max 3), Military access, Trade agreement (max 3: +3 gold/day and +80 trade capacity each), Guarantee of independence. Each proposal shows a likelihood hint; AI judges by opinion, reputation, shared enemies and borders.
- Allies and guarantors are called to arms when a partner is attacked; the attacker's AI allies usually join, the player gets a call-to-arms offer. Allied armies may enter each other's land, supply and fight side by side.
- Declaring war on an ally or pact partner is blocked until you cancel the treaty (costs reputation and relations). Aggression raises your reputation as an aggressor, which lowers how others see you and fades over time.
- Peace talks replace the old ceasefire: war score from occupation, losses and army strength; demand provinces, concede provinces, pay or receive gold; the AI accepts when the terms fit the war situation (war must last 14+ days).
- Inbox: AI nations propose treaties and peace to the player; AI-vs-AI wars now end by negotiation.
- Old saves load (they start with fresh relations and no treaties).

## 6.0.0-phase6
- New 🕵 Intelligence screen (Agency / Operations / Intel / Reports).
- Agency: up to 12 agents (level 1–5), trained in 15 days for gold and manpower; agents have skill 1–5 and gain experience.
- Spy networks: infiltrating a nation builds your network (0–100%) over time; it decays without an agent. Counter-intelligence slows it and catches agents.
- Operations: infiltrate, steal war plans (full intel for 60 days), propaganda, sow discord, incite unrest (-40% manpower, -10% income for 60 days), sabotage industry, assassinate general. Success depends on network, agent skill, target counter-intelligence and difficulty; failures can lose or expose agents (relations and reputation damage).
- Fog of war: foreign armies are visible only near your territory or allies', or with a network of 50%+ (or stolen plans). Foreign statistics in the Country tab are hidden (?), approximate (~) or exact depending on your intel.
- AI nations run their own espionage against enemies and rivals, build counter-intelligence, and you are told when their agents are exposed. Unnoticed attacks show as unknown saboteurs.
- Old saves load (fresh agencies).

## 6.1.0-phase6 (user request)
- Covert annexation without war: new province operations. Agitate province raises discontent (+30, neighbours +10); Incite revolution makes a province with discontent 40+ that borders your land join you (network 60%+; capitals need 85% and discontent 70+). Annexing every province of a nation eliminates it.
- Discontent per province (also rises while a nation starves or is broke); shown on the Operations tab and a new 🕵 Operations here button in foreign province panels.
- Failures lose discontent and may expose you (relations and reputation damage). The AI does not run province operations yet.

## 7.0.0-phase7
- New 🔬 Research screen (Research / Doctrine / Researched). Research points come from civilian factories and provinces; 2 slots (3 with 20+ civilian factories); points are split between active projects; stopped projects keep their progress.
- 30 technologies in 8 branches (Infantry, Armor, Artillery, Industry, Logistics & State, Fortification, Intelligence, Doctrine) with prerequisites: unit attack/defense, equipment output, resource production, construction speed, tax, manpower, trade capacity, army speed, supply, reinforcement rate, siege, spy success and counter-intelligence.
- Fortification levels 2 and 3 now require Fortifications II / III.
- Four doctrines (Mass Assault, Mobile Warfare, Superior Firepower, Fortress Defense); the first choice is free, switching costs 300 gold and 60 days. Doctrinal Studies raise the doctrine level, which strengthens the bonus.
- Allies researching the same technology speed you up by 25%.
- New spy operation: Steal technology (60% of a tech's cost as progress). The AI uses it too.
- AI nations research along war or economy priorities and pick a doctrine by government type; nations start with different technologies.
- The old placeholder tech hook is replaced by real per-unit modifiers. Old saves load (fresh research).

## 7.1.0-phase7 (food fix, user report)
- Problem: some nations (Valdoria, Ostrava) ran a permanent food deficit and starved within 1–3 months, and food could only be bought. Food could not be produced.
- New building: Farm Estates (3 levels per province): +2 food per level before the production rate. Build it in Construction or from a province's Build… button.
- New technologies: Agricultural Methods (+15% food) and Mechanized Farming (+20% food).
- Balance: base food production 0.6 -> 0.7 per point and population food use pop/70000 -> pop/80000, so no nation starts in deficit except Ostrava (slight).
- The Industry overview now warns about a food deficit before starvation and says how to fix it. AI nations build farms when in deficit and research agriculture early.
- Old saves load (farms start at 0).

## 8.0.0-phase8
- New ai.js replaces the basic enemy logic of Phase 3 (removed from war.js). Every non-player nation now plays the whole game.
- Personalities from government type plus a deterministic twist (Warmonger / Expansionist / Balanced / Defensive / Peaceful); visible under Diplomacy → nation (details need intel 50%+).
- War decisions: neighbours it can beat (own plus allied strength against the target's plus allies and guarantors), hatred, opportunism against nations already at war, reputation cost, readiness (gold, manpower, food, army). No wars during the grace period, no second front while losing, cooldown between wars, big nations tire of conquest and others are pushed to resent runaway powers.
- Operations: picks the most valuable weakly-defended enemy province, gathers armies at a staging province, strikes when its firepower beats the defenders (or after waiting), retakes lost land, retreats weak armies, merges stacks.
- Standing armies with composition targets (infantry, artillery, cavalry, tanks, engineers, militia) recruited at the front.
- Economy: tax policy follows the treasury, factory lines follow equipment shortages, surplus sold, border provinces fortified, infrastructure/rail/ports built at the front.
- Diplomacy: alliances against stronger neighbours, appeasement pacts by cautious nations.
- Difficulty (Menu → AI difficulty): Easy (grace 240 days, rarely attacks, AI income 90%), Normal (150 days), Hard (90 days, more aggressive, AI income 115%).
- A war declared on you pauses the game with a message; allies' wars are announced too.
- Old saves load (AI personalities start fresh, difficulty Normal).

## 9.0.0-phase9
- Scenario system: start screen chooser; new scenario "Old World 1936" (45 nations, 347 provinces, polygon coastlines, historic starting relations, new governments Communist State and Absolute Monarchy). Original fictional scenario unchanged.
- Sea zones (9 in Empires, ~59 in Old World) generated from the map, each with ports and neighbours; 8 straits that close to nations at war with the controller; every coastal province is a port.
- Navy: 5 ship types, fleets, shipbuilding queue (needs Port + Shipyard), upkeep, repairs in port, supply of beachheads.
- Naval combat per sea zone each day (submarine first strike, escorts, retreat to nearest port), zone dominance, naval gunfire support for landings.
- Blockades reduce province tax (up to 45%) and trade capacity (up to 85%).
- Amphibious warfare: load armies into transports, sail, land on friendly or enemy coast (assault penalty for 8 days), one-click ⛴ Sail from the army panel.
- Naval tech branch (nav1-nav6): naval attack/defence, anti-submarine, speed, convoy protection.
- Naval AI: builds ships, merges and repairs fleets, contests zones, blockades, escorts invasions; war planner can choose overseas targets.
- Map: 5 modes (Political, Terrain, Diplomacy, Naval, Economy), sea-zone borders and names, fleet banners, blockade and battle markers, legend.
- UI: Navy screen (Fleets, Build, Queue, Overview), fleet panel, sea-zone panel, port block in the province panel, scenario chooser, help text.
- Saves store scenario, fleets, cargo and ship queue; Phase 1-8 saves load as the Empires scenario.
- Fix: economy census tolerates a game state without fleets during creation.

## 9.1.0-phase9 (map fix)
- Bug report: "the map is not correct". Root cause: Old World coastlines were hand-drawn rough polygons and provinces were whole Voronoi cells, so continents looked like blobs (Africa, Americas, Europe wrong); the projection also distorted shapes and the map cut off Alaska, Patagonia, Kamchatka and Greenland.
- Coastlines now come from Natural Earth 1:50m land data (public domain), simplified, in the new file js/landdata.js (~115 KB, offline).
- Miller projection; world extended to lon -168..180, lat -56..76 (adds Alaska, Greenland, Iceland, Patagonia, Kamchatka, New Zealand area).
- Provinces are drawn clipped to the real coastline; taps use the same mask (land taps pick a province, sea taps pick a sea zone). Province area, population and labels use the true land area.
- Every capital city gets its own province on the city (Copenhagen on Zealand, etc.); country names are placed on a real province of that country.
- 377 land provinces, 64 sea zones. Saves made with 9.0.0 on the Old World map cannot be loaded (the map changed); Empires saves are unaffected.

## 9.2.0-phase9 (flags)
- Old World nations now use their real flags of c. 1936, drawn in code by the new js/flags.js (44 flags, no image files): Union Jack, tricolours, Nordic crosses, US stars and stripes, Rising Sun, Brazil, Greece, Canada's Red Ensign, Australia's Southern Cross, etc.
- Where the real 1936 flag carried a political emblem (Germany's swastika flag, Italy's royal arms), a plain historical design is used instead: Germany shows the black-white-red tricolour, Italy the plain green-white-red tricolour. Complex coats of arms (Portugal, Mexico, Persia, Afghanistan, Saudi Arabia, Mongolia, Soviet emblem) are simplified shapes.
- The fictional Empires scenario keeps its original generated flags. Flag icons are sharper (72x48).

## 10.0.0 (final release)
- Campaign system: Campaign and Sandbox modes, Domination / Alliance / end-date victory with grades, Defeat screen, score and ranking (js/campaign.js, js/campaign-ui.js).
- National goals: 8 goal kinds, three active at a time, deadlines, rewards, 🎯 screen.
- Events: 15 random events (every nation, AI auto-resolves) and 7 dated historical headlines for the Old World scenario; scaled to each nation's size; popup with previewed effects; saved with the game (js/events.js).
- Performance: tech effects cached (was the hottest function), war-score no longer scans armies per province, naval logic no longer depends on map.js (G.nodePos moved to naval.js). About 35% less CPU per game day on the Old World map (11.3 -> 8.3 ms/day in Node).
- Menu: Historical events toggle, Credits. Help text updated.
- Packaging: original app icon (assets/icon-192.png, icon-512.png), manifest.webmanifest, README with APK steps, BALANCE.md, TESTING.md, NOTICE.md.
- Saves from Phase 1-9 (Empires map) still load; they open in Sandbox mode.
