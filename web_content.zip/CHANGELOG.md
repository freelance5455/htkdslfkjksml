# Changelog

## v0.1.0 — First practical MVP
- Created the Pocket APK Studio project workspace for an ApkForge-compatible HTML wrapper.
- Added local ZIP inspection and project-type detection.
- Added output for inspection reports, build plans, and static web bundles.
- Added safety boundaries and clear native-build limitations.
