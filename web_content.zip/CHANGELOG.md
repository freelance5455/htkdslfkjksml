# Changelog

## Atualização de interface
- Mantida a configuração inicial de idioma e moeda com sugestão automática regional.
- Removidas as funções de exportação/ download de relatórios, backup e arquivos.
- Removida a restauração/importação de arquivos e a interface de compartilhamento/salvamento.
- Tutorial revisado para focar em registrar movimentações e analisar resultados.
