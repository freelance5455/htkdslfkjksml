# v1.1.0

- Painel do dono com todas as contas.
- Botão Alterar senha ao lado de cada conta.
- Formulário para alterar Nick, Nick permanente, email e senha.
- É obrigatório alterar pelo menos um campo.
- Botões Cancelar e Salvar.
- Informações da conta mostradas abaixo.
- Senhas nunca são exibidas e são armazenadas com bcrypt.
- O dono pode redefinir uma senha esquecida.


## v1.2.0

- Painel administrativo ganhou personalização de cores.
- Campo de cor principal.
- Campo de fundo.
- Campo de cartões.
- Campo de textos.
- Suporte a nomes de cores CSS e HEX.
- Upload do ícone da página inicial.
- Prévia do ícone antes de salvar.
- Botão azul "Salvar personalização".
- Configurações persistentes no banco JSON.

## v1.3.0
- Aba 5: Conexões.
- Usuário escolhe foto e link para exibir no perfil.
- Dono possui "Ver conexões".
- Cada conexão mostra foto, Nick e link.
- Botão "Proibir links automaticamente".
- Ao restringir, o link atual desaparece.
- Área ＋ de restrição.
- Lista de restringidos com botão "Retirar restrição".
