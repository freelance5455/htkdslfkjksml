# 4.1.0 — Phase 1 + 2 (Settings, Appearance, Dashboard customization)
NEW: src/core/profile/prefsService.js, src/modules/dashboard/dashPrefs.js, src/pages/settingsPanels.js
CHANGED: tokens.css, globals.css, Settings.js, Dashboard.js, main.js, backupService.js, canvasChart.js, celebrate.js, sw.js (cache life-guide-v11), page chart colours
- Settings split into 9 categories; Appearance (theme, 6 accents, font, density, cards, corners, animation); Accessibility; App behaviour
- Home: show/hide/reorder sections, Comfortable (1 column) or Compact (2 columns), choose vitals/charts, 3 daily priorities, restore defaults
- Preferences and Home arrangement are saved in the backup; restore validates first and rolls back on failure

# Life Guide 4.0 (from Personal OS 3.0) — same structure, same six tabs

## Fixed
- Pomodoro timer no longer resets when Android unloads the app; it resumes (or logs the finished session) on return.
- Lock screen now covers the app instead of restarting it; wrong-PIN delay; lock timing choice; recovery question; blank cover in recent apps.

## New
- Renamed to Life Guide. Animations (page rise-in, tap feedback, confetti on wins, animated bars/rings), reduced-motion respected.
- About the Developer: photo, story, why, motto, optional contact links (all editable, on-device).
- Body → Weight: 80 → 60 kg goal, weekly weigh-in day, trend, pace, ETA, waist, chart.
- Discipline → Mastery: your own skills with days/minutes/type/reminder time, Today's Mastery on Home, streaks (never-miss-twice, by week), charts.
- Mind → Study: your own subjects (add/rename/delete, optional exam dates), Exam mode (revision timetable + coach/suggestions).
- Weekly Review: "Suggested focus for next week" from your numbers.
- Quick-add "+" button on every page.
- Reminders (Settings): wake-up, priorities, Anki, evening check-in, wind-down, Weekly Review, weigh-in, prayer, Mastery — ring with app closed in the Capacitor build.
- Share backup (WhatsApp / Drive / email) button; Capacitor bridge with web fallbacks.

## Files
Created: src/core/native/bridge.js, src/core/notifications/reminderService.js, src/components/layout/{celebrate,quickAdd}.js, src/modules/body/weight/{weightService,weightUI}.js, src/modules/mastery/{masteryService,masteryUI}.js, src/modules/mind/subjects/{subjectsService,subjectsUI}.js, package.json, capacitor.config.json, scripts/copy-www.mjs, CAPACITOR_SETUP.md
Modified: main.js, router.js, db.js (v3), pinLock.js, pomodoroService.js, Settings.js, AboutPage.js, Dashboard.js, BodyPage.js, DisciplinePage.js, MindPage.js, coach.js, suggestionEngine.js, studyService.js, backupService.js, profileService.js, xpEngine.js, globals.css, index.html, manifest, sw.js
