# صافرة (Safara)

تطبيق مباريات كرة القدم: واجهة ويب/أندرويد + خادم Node مع قاعدة SQLite + مزامنة تلقائية من API-Football.

## التشغيل
```bash
export FOOTBALL_API_KEY=مفتاحك_من_api-football.com
export ADMIN_TOKEN=كلمة_سر_طويلة
node server.js          # يتطلب Node 22.5+، بلا أي حزم npm
```
- الواجهة: http://localhost:3000 · لوحة التحكم: http://localhost:3000/admin
- الاختبار: `npm test`

## كيف يعمل
- مزامنة كاملة كل 6 ساعات (من −3 إلى +7 أيام)، وتحديث مباشر كل 60 ثانية عند وجود مباريات قيد اللعب.
- الأهداف والبطاقات والتبديلات والإحصائيات تُجلب عند فتح المباراة وتُخزَّن مؤقتاً.
- الأوقات بتوقيت العراق (UTC+3). ما لا يوفره المزوّد لا يُعرض.
- ضبط الاستهلاك: `FULL_SYNC_MINUTES`, `LIVE_POLL_SECONDS`, `DAYS_BACK`, `DAYS_AHEAD`. الخطة المجانية 100 طلب/يوم فقط، فارفع الفاصل أو اشترِ خطة أعلى.
- `DB_PATH` لتغيير مكان قاعدة البيانات. على الاستضافة استعمل قرصاً دائماً (Volume).

## APK
1. انشر الخادم على استضافة HTTPS (Render / Railway / VPS).
2. ضع رابطه في `public/config.js` (`window.API_BASE`).
3. ثم:
```bash
npm install
npx cap add android
npx cap sync android
cd android && ./gradlew assembleDebug
# الملف: android/app/build/outputs/apk/debug/app-debug.apk
```
يلزم JDK 17 وAndroid SDK.
