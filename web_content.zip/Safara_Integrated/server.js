'use strict';
// Safara backend. No npm dependencies: Node 22+ (http, fetch, node:sqlite).
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');

const C = {
  port: +process.env.PORT || 3000,
  dbPath: process.env.DB_PATH || path.join(__dirname, 'safara.db'),
  apiKey: process.env.FOOTBALL_API_KEY || '',
  apiBase: (process.env.PROVIDER_URL || 'https://v3.football.api-sports.io').replace(/\/$/, ''),
  admin: process.env.ADMIN_TOKEN || '',
  fullEveryMin: +process.env.FULL_SYNC_MINUTES || 360, // full window sync
  liveEverySec: +process.env.LIVE_POLL_SECONDS || 60,
  daysBack: +process.env.DAYS_BACK || 3,
  daysAhead: +process.env.DAYS_AHEAD || 7,
};
const TZ = 3 * 3600; // Iraq (Asia/Baghdad) is UTC+3, no DST

const db = new DatabaseSync(C.dbPath);
db.exec(`
CREATE TABLE IF NOT EXISTS matches(
  id TEXT PRIMARY KEY, ext_id INTEGER, source TEXT NOT NULL,
  league_id INTEGER, league TEXT, country TEXT, league_logo TEXT,
  home TEXT NOT NULL, away TEXT NOT NULL, home_logo TEXT, away_logo TEXT,
  ts INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'NS', elapsed INTEGER,
  hg INTEGER, ag INTEGER, stream_url TEXT, manual INTEGER DEFAULT 0, hidden INTEGER DEFAULT 0, updated INTEGER);
CREATE INDEX IF NOT EXISTS ix_ts ON matches(ts);
CREATE TABLE IF NOT EXISTS details(match_id TEXT PRIMARY KEY, events TEXT, stats TEXT, updated INTEGER);
CREATE TABLE IF NOT EXISTS state(k TEXT PRIMARY KEY, v TEXT);`);

const now = () => Math.floor(Date.now() / 1000);
const getS = k => { const r = db.prepare('SELECT v FROM state WHERE k=?').get(k); return r ? JSON.parse(r.v) : null; };
const setS = (k, v) => db.prepare('INSERT INTO state(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v').run(k, JSON.stringify(v));
const dayStr = ts => new Date((ts + TZ) * 1000).toISOString().slice(0, 10); // Iraq calendar day
const dayStart = s => Math.floor(Date.parse(s + 'T00:00:00Z') / 1000) - TZ;

// ---------- provider (API-Football v3 format) ----------
async function api(p) {
  if (!C.apiKey) throw new Error('FOOTBALL_API_KEY غير مضبوط');
  const r = await fetch(C.apiBase + p, { headers: { 'x-apisports-key': C.apiKey } });
  if (!r.ok) throw new Error('Provider HTTP ' + r.status);
  const j = await r.json();
  const errs = j.errors && (Array.isArray(j.errors) ? j.errors : Object.values(j.errors));
  if (errs && errs.length) throw new Error('Provider: ' + JSON.stringify(j.errors));
  setS('calls', { day: dayStr(now()), n: ((getS('calls') || {}).day === dayStr(now()) ? getS('calls').n : 0) + 1 });
  return j.response || [];
}
const up = db.prepare(`INSERT INTO matches(id,ext_id,source,league_id,league,country,league_logo,home,away,home_logo,away_logo,ts,status,elapsed,hg,ag,updated)
VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
ON CONFLICT(id) DO UPDATE SET league_id=excluded.league_id,league=excluded.league,country=excluded.country,league_logo=excluded.league_logo,
home=excluded.home,away=excluded.away,home_logo=excluded.home_logo,away_logo=excluded.away_logo,ts=excluded.ts,status=excluded.status,
elapsed=excluded.elapsed,hg=excluded.hg,ag=excluded.ag,updated=excluded.updated WHERE matches.manual=0`);
function store(list) {
  db.exec('BEGIN');
  try {
    for (const f of list) up.run('api-' + f.fixture.id, f.fixture.id, 'api', f.league.id, f.league.name, f.league.country, f.league.logo,
      f.teams.home.name, f.teams.away.name, f.teams.home.logo, f.teams.away.logo, f.fixture.timestamp, f.fixture.status.short,
      f.fixture.status.elapsed, f.goals.home, f.goals.away, now());
    db.exec('COMMIT');
  } catch (e) { db.exec('ROLLBACK'); throw e; }
  return list.length;
}
async function fullSync(back = C.daysBack, ahead = C.daysAhead) {
  const log = { at: now(), ok: true, n: 0, err: null };
  try {
    for (let d = -back; d <= ahead; d++) log.n += store(await api('/fixtures?timezone=UTC&date=' + dayStr(now() + d * 86400)));
  } catch (e) { log.ok = false; log.err = e.message; }
  setS('lastFull', log); return log;
}
const LIVE = ['1H', 'HT', '2H', 'ET', 'BT', 'P', 'LIVE', 'INT'];
async function livePoll() {
  const t = now();
  const maybe = db.prepare("SELECT 1 FROM matches WHERE ts BETWEEN ? AND ? AND status NOT IN ('FT','AET','PEN','CANC','PST','ABD','AWD','WO')").get(t - 4 * 3600, t + 600);
  if (!maybe) return;
  const log = { at: t, ok: true, n: 0, err: null };
  try { log.n = store(await api('/fixtures?live=all')); } catch (e) { log.ok = false; log.err = e.message; }
  setS('lastLive', log);
}
async function loadDetails(m) {
  const d = db.prepare('SELECT * FROM details WHERE match_id=?').get(m.id);
  const live = LIVE.includes(m.status);
  if (d && now() - d.updated < (live ? 45 : 86400)) return { events: JSON.parse(d.events), stats: JSON.parse(d.stats) };
  if (!m.ext_id || !C.apiKey) return { events: d ? JSON.parse(d.events) : [], stats: d ? JSON.parse(d.stats) : [] };
  const [ev, st] = await Promise.all([api('/fixtures/events?fixture=' + m.ext_id), api('/fixtures/statistics?fixture=' + m.ext_id)]);
  const events = ev.map(e => ({ min: e.time.elapsed, extra: e.time.extra, team: e.team.name, player: e.player.name, assist: e.assist && e.assist.name, type: e.type, detail: e.detail }));
  const stats = st.map(s => ({ team: s.team.name, items: s.statistics.map(x => ({ k: x.type, v: x.value })) }));
  db.prepare('INSERT INTO details VALUES(?,?,?,?) ON CONFLICT(match_id) DO UPDATE SET events=excluded.events,stats=excluded.stats,updated=excluded.updated')
    .run(m.id, JSON.stringify(events), JSON.stringify(stats), now());
  return { events, stats };
}

// ---------- http ----------
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.json': 'application/json', '.png': 'image/png', '.svg': 'image/svg+xml' };
const send = (res, code, obj) => { res.writeHead(code, { 'content-type': 'application/json; charset=utf-8', 'access-control-allow-origin': '*', 'access-control-allow-headers': 'authorization,content-type', 'access-control-allow-methods': 'GET,POST,PUT,DELETE,OPTIONS' }); res.end(JSON.stringify(obj)); };
const body = req => new Promise((ok, no) => { let b = ''; req.on('data', c => { b += c; if (b.length > 1e6) req.destroy(); }); req.on('end', () => { try { ok(b ? JSON.parse(b) : {}); } catch (e) { no(e); } }); });
const isAdmin = req => C.admin && (req.headers.authorization || '') === 'Bearer ' + C.admin;
const clean = r => ({ id: r.id, league: r.league, country: r.country, leagueLogo: r.league_logo, leagueId: r.league_id, home: r.home, away: r.away, homeLogo: r.home_logo, awayLogo: r.away_logo, ts: r.ts, status: r.status, elapsed: r.elapsed, hg: r.hg, ag: r.ag, stream: r.stream_url, manual: !!r.manual, hidden: !!r.hidden });

async function route(req, res) {
  const u = new URL(req.url, 'http://x'); const p = u.pathname;
  if (req.method === 'OPTIONS') return send(res, 204, {});
  if (p === '/api/matches' && req.method === 'GET') {
    const date = u.searchParams.get('date'), q = (u.searchParams.get('q') || '').trim();
    const adm = isAdmin(req) && u.searchParams.get('all') === '1';
    let sql = 'SELECT * FROM matches WHERE ' + (adm ? '1=1' : 'hidden=0'); const a = [];
    if (date) { const s = dayStart(date); sql += ' AND ts>=? AND ts<?'; a.push(s, s + 86400); }
    if (q) { sql += ' AND (home LIKE ? OR away LIKE ? OR league LIKE ?)'; a.push(...Array(3).fill('%' + q + '%')); }
    sql += ' ORDER BY league, ts LIMIT 1500';
    const rows = db.prepare(sql).all(...a).map(clean);
    return send(res, 200, { matches: rows, lastSync: (getS('lastFull') || {}).at || null, providerReady: !!C.apiKey });
  }
  let m = p.match(/^\/api\/match\/([\w-]+)$/);
  if (m && req.method === 'GET') {
    const r = db.prepare('SELECT * FROM matches WHERE id=?').get(m[1]); if (!r) return send(res, 404, { error: 'غير موجودة' });
    let d = { events: [], stats: [] }, note = null;
    try { d = await loadDetails(r); } catch (e) { note = e.message; }
    return send(res, 200, { match: clean(r), ...d, note });
  }
  if (p.startsWith('/api/admin/')) {
    if (!C.admin) return send(res, 503, { error: 'ADMIN_TOKEN غير مضبوط على الخادم' });
    if (!isAdmin(req)) return send(res, 401, { error: 'رمز غير صحيح' });
    if (p === '/api/admin/status') return send(res, 200, { providerKey: !!C.apiKey, provider: C.apiBase, calls: getS('calls'), lastFull: getS('lastFull'), lastLive: getS('lastLive'),
      total: db.prepare('SELECT COUNT(*) c FROM matches').get().c, leagues: db.prepare('SELECT league,country,COUNT(*) n FROM matches GROUP BY league_id,league ORDER BY n DESC').all() });
    if (p === '/api/admin/sync' && req.method === 'POST') { const b = await body(req); return send(res, 200, await fullSync(+b.back || C.daysBack, +b.ahead || C.daysAhead)); }
    if (p === '/api/admin/matches' && req.method === 'POST') {
      const b = await body(req); if (!b.home || !b.away || !b.ts) return send(res, 400, { error: 'الفريقان والوقت مطلوبة' });
      const id = 'm-' + Date.now();
      db.prepare('INSERT INTO matches(id,source,league,country,home,away,ts,status,hg,ag,stream_url,manual,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?,1,?)')
        .run(id, 'manual', b.league || '', b.country || '', b.home, b.away, +b.ts, b.status || 'NS', b.hg ?? null, b.ag ?? null, b.stream || null, now());
      return send(res, 201, { id });
    }
    m = p.match(/^\/api\/admin\/matches\/([\w-]+)$/);
    if (m && req.method === 'PUT') {
      const b = await body(req); const f = { home: 'home', away: 'away', league: 'league', country: 'country', ts: 'ts', status: 'status', hg: 'hg', ag: 'ag', stream: 'stream_url', hidden: 'hidden' };
      const sets = [], a = []; for (const k in f) if (k in b) { sets.push(f[k] + '=?'); a.push(typeof b[k] === 'boolean' ? +b[k] : b[k]); }
      if (!sets.length) return send(res, 400, { error: 'لا تغييرات' });
      db.prepare('UPDATE matches SET ' + sets.join(',') + ',manual=1,updated=? WHERE id=?').run(...a, now(), m[1]); return send(res, 200, { ok: true });
    }
    if (m && req.method === 'DELETE') { db.prepare('DELETE FROM matches WHERE id=?').run(m[1]); db.prepare('DELETE FROM details WHERE match_id=?').run(m[1]); return send(res, 200, { ok: true }); }
    return send(res, 404, { error: 'مسار غير معروف' });
  }
  // static files
  const rel = p === '/' ? '/index.html' : p === '/admin' ? '/admin.html' : p;
  const fp = path.join(__dirname, 'public', path.normalize(rel).replace(/^(\.\.[\/\\])+/, ''));
  if (!fp.startsWith(path.join(__dirname, 'public')) || !fs.existsSync(fp) || fs.statSync(fp).isDirectory()) return send(res, 404, { error: 'not found' });
  res.writeHead(200, { 'content-type': MIME[path.extname(fp)] || 'application/octet-stream' }); fs.createReadStream(fp).pipe(res);
}

const server = http.createServer((req, res) => route(req, res).catch(e => send(res, 500, { error: e.message })));
if (require.main === module) {
  server.listen(C.port, () => console.log('Safara on :' + C.port + (C.apiKey ? '' : '  (تنبيه: FOOTBALL_API_KEY غير مضبوط، لن يتم الجلب)') + (C.admin ? '' : '  (ADMIN_TOKEN غير مضبوط)')));
  if (C.apiKey) { fullSync(); setInterval(fullSync, C.fullEveryMin * 60e3); setInterval(livePoll, C.liveEverySec * 1e3); }
}
module.exports = { server, fullSync, livePoll };
