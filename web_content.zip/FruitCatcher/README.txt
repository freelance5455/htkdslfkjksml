FRUIT CATCHER — Beginner Android game prototype

Files:
- index.html: complete playable game prototype.

Try it:
1. Open index.html in a modern web browser.
2. Tap PLAY NOW.
3. Drag your finger/mouse left and right to move the basket.
4. Catch fruit for 60 seconds. Best score is saved in the browser.

Important:
This is a working browser prototype, not yet an Android APK/AAB.
To publish on Google Play, the game must be packaged as an Android app, tested on devices, and meet current Play Console policies. Do not upload this HTML file directly to Play Console.
