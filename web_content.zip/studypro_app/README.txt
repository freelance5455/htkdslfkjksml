STUDYPRO STARTER APP

This is a responsive installable web-app prototype for StudyPro.

Included working features:
- Responsive dashboard for phone and desktop
- Notes saved locally in the browser
- Five-question sample quiz with scoring
- Focus timer (25 minutes) and local study-time tracking
- Premium screen and demo-only purchase prompt
- Clearly marked placeholder ad space
- PWA manifest and basic service worker for hosting

IMPORTANT LIMITATIONS:
- This is NOT a compiled Android APK/AAB yet.
- Ads are placeholders only; no ad network is connected.
- Premium is a demo screen only; no real payments are processed.
- No user accounts, cloud sync, or remote database.
- Progress/notes are stored only in the current browser on this device.
- Before public release, integrate Google Play Billing for digital purchases, an approved ads SDK (with child/teen and consent policies as applicable), privacy policy, and test on devices.

RUN ON PC:
Open index.html in a modern browser. For install/PWA behavior, host the folder over HTTPS or use a local web server.

RUN ON ANDROID:
For a quick preview, transfer index.html and open it in a browser. For installable PWA behavior, host the files over HTTPS and use Chrome's Add to Home screen. This ZIP itself does not install as an APK.

NEXT PRODUCTION STEPS:
1. Add original syllabus-aligned notes and quiz content.
2. Add secure login and cloud database if needed.
3. Build Android wrapper/native Flutter version.
4. Integrate and test real ads and Play Billing.
5. Add privacy policy, data safety details, age/content settings, and Play Store listing.
