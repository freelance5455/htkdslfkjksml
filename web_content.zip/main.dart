
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:async';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(const SwiftHustleApp());
}

// --- Models ---

enum UserTier { rookie, risingStar, elite, premium }

class UserStats {
  int jobsCompleted;
  int jobsPostedCount;
  double averageRating;
  UserTier currentTier;

  UserStats({
    required this.jobsCompleted,
    required this.jobsPostedCount,
    required this.averageRating,
    required this.currentTier,
  });
}

class UserProfile {
  String id;
  String fullName;
  String email;
  bool isAdmin;
  bool isVerified;
  bool isAvailable;
  double walletBalance;
  double escrowBalance;
  String? selfieUrl;
  String? idUrl;

  UserProfile({
    required this.id,
    required this.fullName,
    required this.email,
    this.isAdmin = false,
    this.isVerified = false,
    this.isAvailable = false,
    this.walletBalance = 0.0,
    this.escrowBalance = 0.0,
    this.selfieUrl,
    this.idUrl,
  });
}

class Transaction {
  String id;
  String userName;
  String label;
  double amount;
  DateTime timestamp;
  bool isPaid;
  String method;

  Transaction({
    required this.id,
    required this.userName,
    required this.label,
    required this.amount,
    required this.timestamp,
    this.isPaid = false,
    this.method = 'PayShap',
  });
}

class Gig {
  final String id;
  final String title;
  final double price;
  final String category;
  final String imageUrl;

  Gig({required this.id, required this.title, required this.price, required this.category, required this.imageUrl});
}

// --- App Root ---

class SwiftHustleApp extends StatelessWidget {
  const SwiftHustleApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SwiftHustle SA',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Inter',
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF1B263B),
          primary: const Color(0xFF1B263B),
          secondary: const Color(0xFF50C878), // Specified Emerald Green
        ),
      ),
      home: const RootScreen(),
    );
  }
}

class RootScreen extends StatefulWidget {
  const RootScreen({super.key});

  @override
  State<RootScreen> createState() => _RootScreenState();
}

class _RootScreenState extends State<RootScreen> with SingleTickerProviderStateMixin {
  int _currentIndex = 0;
  bool _isHustler = true;
  bool _showAchievement = false;

  late UserProfile currentUser;
  late UserStats userStats;
  List<Transaction> transactions = [];
  List<UserProfile> pendingVerifications = [];
  List<Gig> mockGigs = [];

  @override
  void initState() {
    super.initState();
    _initializeMockData();
  }

  void _initializeMockData() {
    currentUser = UserProfile(
      id: 'admin_01',
      fullName: 'Mandla Zulu',
      email: 'admin@swifthustle.co.za',
      isAdmin: true,
      isVerified: true,
      walletBalance: 2450.0,
      escrowBalance: 1200.0,
    );

    userStats = UserStats(
      jobsCompleted: 12,
      jobsPostedCount: 3,
      averageRating: 4.8,
      currentTier: UserTier.elite,
    );

    transactions = [
      Transaction(id: 't1', userName: 'Mandla Zulu', label: 'Withdrawal', amount: 500.0, timestamp: DateTime.now(), isPaid: true),
      Transaction(id: 't2', userName: 'Sabelo M.', label: 'Withdrawal', amount: 1200.0, timestamp: DateTime.now(), isPaid: false),
    ];

    pendingVerifications = [
      UserProfile(id: 'v1', fullName: 'Sabelo Mkhize', email: 'sabelo@mail.com', selfieUrl: 'https://i.pravatar.cc/300?img=11', idUrl: 'https://via.placeholder.com/600x400?text=SA+ID+FRONT'),
      UserProfile(id: 'v2', fullName: 'Lerato Modise', email: 'lerato@mail.com', selfieUrl: 'https://i.pravatar.cc/300?img=5', idUrl: 'https://via.placeholder.com/600x400?text=SA+ID+FRONT'),
    ];

    mockGigs = [
      Gig(id: '1', title: 'Garden Maintenance', price: 450, category: 'General', imageUrl: 'https://picsum.photos/seed/garden/200'),
      Gig(id: '2', title: 'Electrician Needed', price: 800, category: 'Electrical', imageUrl: 'https://picsum.photos/seed/electric/200'),
      Gig(id: '3', title: 'Office Relocation', price: 1200, category: 'General', imageUrl: 'https://picsum.photos/seed/move/200'),
      Gig(id: '4', title: 'Mail Pickup', price: 150, category: 'Errands', imageUrl: 'https://picsum.photos/seed/mail/200'),
      Gig(id: '5', title: 'Leaking Tap Fix', price: 550, category: 'Plumbing', imageUrl: 'https://picsum.photos/seed/plumb/200'),
      Gig(id: '6', title: 'Car Wash', price: 100, category: 'General', imageUrl: 'https://picsum.photos/seed/car/200'),
    ];
  }

  void _checkInstantPayoutUnlock() {
    if (!_isHustler && userStats.jobsPostedCount >= 5 && currentUser.isVerified) {
      setState(() {
        _showAchievement = true;
      });
      HapticFeedback.heavyImpact();
    }
  }

  void _completeJob() {
    setState(() {
      userStats.jobsPostedCount += 1;
      _checkInstantPayoutUnlock();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          IndexedStack(
            index: _currentIndex,
            children: [
              _buildRadarView(),
              _buildChatView(),
              _buildWalletView(),
              _buildAccountView(),
            ],
          ),
          if (_showAchievement) _buildAchievementOverlay(),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) => setState(() => _currentIndex = index),
        type: BottomNavigationBarType.fixed,
        selectedItemColor: _isHustler ? const Color(0xFFD4AF37) : const Color(0xFF1B263B),
        unselectedItemColor: Colors.grey,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.radar), label: 'Radar'),
          BottomNavigationBarItem(icon: Icon(Icons.chat_bubble_outline), label: 'Chat'),
          BottomNavigationBarItem(icon: Icon(Icons.account_balance_wallet_outlined), label: 'Wallet'),
          BottomNavigationBarItem(icon: Icon(Icons.person_outline), label: 'Account'),
        ],
      ),
    );
  }

  // --- View Builders ---

  Widget _buildRadarView() {
    const emeraldGreen = Color(0xFF50C878);

    return Stack(
      children: [
        // Map Content Layer
        Container(
          width: double.infinity,
          height: double.infinity,
          color: const Color(0xFFF8FAFC),
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.location_on, 
                  size: 64, 
                  color: _isHustler ? const Color(0xFFD4AF37) : const Color(0xFF1B263B)
                ),
                const SizedBox(height: 16),
                const Text('Map View Integration Placeholder', style: TextStyle(fontWeight: FontWeight.bold)),
                const Text('Real-time Gig Radar Active', style: TextStyle(color: Colors.grey)),
              ],
            ),
          ),
        ),

        // Task 2: Draggable Gig List
        DraggableScrollableSheet(
          initialChildSize: 0.4,
          minChildSize: 0.1,
          maxChildSize: 0.9,
          builder: (BuildContext context, ScrollController scrollController) {
            return Container(
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(32),
                  topRight: Radius.circular(32),
                ),
                boxShadow: [
                  BoxShadow(color: Colors.black12, blurRadius: 10, spreadRadius: 2),
                ],
              ),
              child: Column(
                children: [
                  // Task: Grey rounded drag handle
                  const SizedBox(height: 12),
                  Container(
                    width: 40,
                    height: 5,
                    decoration: BoxDecoration(
                      color: Colors.grey.shade300,
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    "NEARBY GIGS",
                    style: TextStyle(fontSize: 10, fontWeight: FontWeight.w900, color: Colors.blueGrey, letterSpacing: 1),
                  ),
                  const SizedBox(height: 8),
                  Expanded(
                    child: ListView.builder(
                      controller: scrollController, // Task: Ensure drag-down works
                      itemCount: mockGigs.length,
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                      itemBuilder: (context, index) {
                        final gig = mockGigs[index];
                        return Container(
                          margin: const EdgeInsets.only(bottom: 12),
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: Colors.grey.shade100),
                          ),
                          child: Row(
                            children: [
                              ClipRRect(
                                borderRadius: BorderRadius.circular(12),
                                child: Image.network(gig.imageUrl, width: 50, height: 50, fit: BoxFit.cover),
                              ),
                              const SizedBox(width: 16),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(gig.title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                                    Text(gig.category, style: const TextStyle(fontSize: 10, color: Colors.grey)),
                                  ],
                                ),
                              ),
                              Text(
                                "R ${gig.price}",
                                style: const TextStyle(fontWeight: FontWeight.w900, color: emeraldGreen),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            );
          },
        ),

        // Task 1: Fixed Button Overlap - Action Buttons positioned at bottom right with SafeArea and Padding
        Positioned(
          bottom: 24,
          right: 20,
          child: SafeArea(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                FloatingActionButton.extended(
                  onPressed: _completeJob,
                  heroTag: 'radar_action_fab',
                  backgroundColor: emeraldGreen, // Task: Use 0xFF50C878
                  elevation: 8,
                  label: Text(
                    _isHustler ? "ADD SERVICE" : "POST JOB",
                    style: const TextStyle(
                      color: Colors.white, 
                      fontWeight: FontWeight.w900, 
                      fontSize: 12,
                      letterSpacing: 1.2
                    ),
                  ),
                  icon: const Icon(Icons.add, color: Colors.white),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildChatView() {
    return Scaffold(
      appBar: AppBar(title: const Text("Messages", style: TextStyle(fontWeight: FontWeight.w900))),
      body: ListView.builder(
        itemCount: 3,
        itemBuilder: (context, index) => ListTile(
          leading: CircleAvatar(backgroundColor: Colors.blue.shade100),
          title: Text("Contact $index"),
          subtitle: const Text("Is the job still available?"),
          trailing: const Text("10:45 AM", style: TextStyle(fontSize: 10)),
        ),
      ),
    );
  }

  Widget _buildWalletView() {
    bool instantUnlocked = userStats.jobsPostedCount >= 5 && currentUser.isVerified;
    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text("Wallet", style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900, color: Color(0xFF1B263B))),
              const SizedBox(height: 24),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(32),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [Color(0xFF1B263B), Color(0xFF2C3E50)]),
                  borderRadius: BorderRadius.circular(32),
                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 20)],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text("Available Balance", style: TextStyle(color: Colors.white54, fontWeight: FontWeight.bold)),
                    Text("R ${currentUser.walletBalance.toStringAsFixed(2)}", style: const TextStyle(color: Colors.white, fontSize: 36, fontWeight: FontWeight.w900)),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24), border: Border.all(color: Colors.grey.shade200)),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Row(
                      children: [
                        Icon(Icons.lock_outline, color: Colors.amber),
                        SizedBox(width: 12),
                        Text("Escrow Vault", style: TextStyle(fontWeight: FontWeight.bold)),
                      ],
                    ),
                    Text("R ${currentUser.escrowBalance.toStringAsFixed(2)}", style: const TextStyle(fontWeight: FontWeight.w900)),
                    if (!_isHustler)
                      ElevatedButton(
                        onPressed: instantUnlocked ? () {} : null,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: instantUnlocked ? const Color(0xFFD4AF37) : Colors.grey.shade200,
                          foregroundColor: instantUnlocked ? Colors.white : Colors.grey,
                        ),
                        child: Text(instantUnlocked ? "Instant Release" : "Locked"),
                      ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAccountView() {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              height: 200,
              width: double.infinity,
              decoration: BoxDecoration(color: _isHustler ? const Color(0xFFD4AF37) : const Color(0xFF1B263B)),
              child: SafeArea(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const CircleAvatar(radius: 40, backgroundImage: NetworkImage('https://i.pravatar.cc/300')),
                    const SizedBox(height: 8),
                    Text(currentUser.fullName, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 20)),
                  ],
                ),
              ),
            ),
            if (!_isHustler) _buildTrustMeter(),
            ListTile(
              leading: const Icon(Icons.sync_alt),
              title: Text("Switch to ${_isHustler ? 'Employer' : 'Hustler'} Mode"),
              onTap: () => setState(() => _isHustler = !_isHustler),
            ),
            const Divider(),
            const ListTile(leading: Icon(Icons.security), title: Text("Security & Safety")),
            const ListTile(leading: Icon(Icons.logout, color: Colors.red), title: Text("Sign Out", style: TextStyle(color: Colors.red))),
          ],
        ),
      ),
    );
  }

  Widget _buildTrustMeter() {
    double progress = userStats.jobsPostedCount / 5;
    bool isDone = userStats.jobsPostedCount >= 5;
    return Container(
      margin: const EdgeInsets.all(24),
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(32), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10)]),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text("Trust Meter Progress", style: TextStyle(fontWeight: FontWeight.w900, fontSize: 12)),
              Icon(isDone ? Icons.bolt : Icons.lock, color: isDone ? Colors.amber : Colors.grey, size: 16),
            ],
          ),
          const SizedBox(height: 12),
          LinearProgressIndicator(value: progress.clamp(0.0, 1.0), backgroundColor: Colors.grey.shade100, color: const Color(0xFFD4AF37), minHeight: 8),
          const SizedBox(height: 8),
          Text("Step ${userStats.jobsPostedCount} of 5 to Instant Payouts", style: const TextStyle(fontSize: 10, color: Colors.grey, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget _buildAchievementOverlay() {
    return GestureDetector(
      onTap: () => setState(() => _showAchievement = false),
      child: Container(
        color: const Color(0xFF1B263B).withOpacity(0.95),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const AnimatedBolt(),
              const SizedBox(height: 32),
              const Text("INSTANT PAYOUTS UNLOCKED!", style: TextStyle(color: Color(0xFFD4AF37), fontSize: 24, fontWeight: FontWeight.w900, fontStyle: FontStyle.italic)),
              const SizedBox(height: 16),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 48.0),
                child: Text(
                  "Congratulations! You are now a Trusted Employer. You can now release funds to Hustlers instantly via PayShap & RTC.",
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white70),
                ),
              ),
              const SizedBox(height: 48),
              ElevatedButton(
                onPressed: () => setState(() => _showAchievement = false),
                style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF10B981), foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(horizontal: 64, vertical: 20)),
                child: const Text("LET'S GO!", style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 2)),
              )
            ],
          ),
        ),
      ),
    );
  }
}

// --- Specialized Components ---

class AnimatedBolt extends StatefulWidget {
  const AnimatedBolt({super.key});

  @override
  State<AnimatedBolt> createState() => _AnimatedBoltState();
}

class _AnimatedBoltState extends State<AnimatedBolt> with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(seconds: 1))..repeat(reverse: true);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ScaleTransition(
      scale: Tween(begin: 1.0, end: 1.2).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut)),
      child: Container(
        width: 120,
        height: 120,
        decoration: BoxDecoration(color: const Color(0xFFD4AF37), borderRadius: BorderRadius.circular(40), boxShadow: const [BoxShadow(color: Color(0x66D4AF37), blurRadius: 40, spreadRadius: 10)]),
        child: const Icon(Icons.bolt, size: 80, color: Colors.white),
      ),
    );
  }
}

// --- Admin Command Center ---

class AdminPanelScreen extends StatefulWidget {
  final List<UserProfile> verifications;
  final List<Transaction> transactions;

  const AdminPanelScreen({super.key, required this.verifications, required this.transactions});

  @override
  State<AdminPanelScreen> createState() => _AdminPanelScreenState();
}

class _AdminPanelScreenState extends State<AdminPanelScreen> {
  int _activeTab = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0B0F19),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1B263B),
        foregroundColor: Colors.white,
        title: const Text("ADMIN COMMAND CENTER", style: TextStyle(fontWeight: FontWeight.w900, fontSize: 14, letterSpacing: 1)),
      ),
      body: Column(
        children: [
          _buildGodViewStats(),
          Row(
            children: [
              _tabButton(0, "Stats"),
              _tabButton(1, "Verifications"),
              _tabButton(2, "Withdrawals"),
            ],
          ),
          Expanded(
            child: IndexedStack(
              index: _activeTab,
              children: [
                _buildStatsTab(),
                _buildVerificationsTab(),
                _buildWithdrawalsTab(),
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget _tabButton(int index, String label) {
    bool active = _activeTab == index;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _activeTab = index),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 16),
          decoration: BoxDecoration(border: Border(bottom: BorderSide(color: active ? const Color(0xFFD4AF37) : Colors.transparent, width: 3))),
          child: Text(label, textAlign: TextAlign.center, style: TextStyle(color: active ? Colors.white : Colors.white38, fontWeight: FontWeight.bold, fontSize: 12)),
        ),
      ),
    );
  }

  Widget _buildGodViewStats() {
    return Container(
      padding: const EdgeInsets.all(20),
      color: Colors.black26,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _statItem("Active Gigs", "42", Colors.emerald),
          _statItem("Online Users", "128", Colors.blue),
          _statItem("Revenue", "R 4.2k", const Color(0xFFD4AF37)),
        ],
      ),
    );
  }

  Widget _statItem(String label, String val, Color color) {
    return Column(
      children: [
        Text(label, style: const TextStyle(color: Colors.white38, fontSize: 10, fontWeight: FontWeight.bold)),
        Text(val, style: TextStyle(color: color, fontSize: 20, fontWeight: FontWeight.w900)),
      ],
    );
  }

  Widget _buildStatsTab() {
    return const Center(child: Text("Live Platform Analytics...", style: TextStyle(color: Colors.white24)));
  }

  Widget _buildVerificationsTab() {
    return ListView.builder(
      itemCount: widget.verifications.length,
      padding: const EdgeInsets.all(16),
      itemBuilder: (context, index) {
        final user = widget.verifications[index];
        return Card(
          color: const Color(0xFF1B263B),
          child: ListTile(
            leading: CircleAvatar(backgroundImage: NetworkImage(user.selfieUrl!)),
            title: Text(user.fullName, style: const TextStyle(color: Colors.white)),
            subtitle: const Text("Verification Pending", style: TextStyle(color: Colors.white38)),
            trailing: const Icon(Icons.chevron_right, color: Colors.white24),
            onTap: () => _showVerifyDialog(user),
          ),
        );
      },
    );
  }

  void _showVerifyDialog(UserProfile user) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1B263B),
        title: Text(user.fullName, style: const TextStyle(color: Colors.white)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                Expanded(child: Image.network(user.selfieUrl!, height: 150, fit: BoxFit.cover)),
                const SizedBox(width: 8),
                Expanded(child: Image.network(user.idUrl!, height: 150, fit: BoxFit.cover)),
              ],
            ),
            const SizedBox(height: 16),
            const Text("Comparison: Selfie vs SA ID Photo", style: TextStyle(color: Colors.white54, fontSize: 10)),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text("Reject", style: TextStyle(color: Colors.red))),
          ElevatedButton(onPressed: () => Navigator.pop(context), style: ElevatedButton.styleFrom(backgroundColor: Colors.emerald), child: const Text("Approve")),
        ],
      ),
    );
  }

  Widget _buildWithdrawalsTab() {
    return ListView.builder(
      itemCount: widget.transactions.length,
      padding: const EdgeInsets.all(16),
      itemBuilder: (context, index) {
        final tx = widget.transactions[index];
        if (tx.isPaid) return const SizedBox.shrink();
        return Container(
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(color: const Color(0xFF1B263B), borderRadius: BorderRadius.circular(20)),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(tx.userName, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                  Text("R ${tx.amount}", style: const TextStyle(color: Color(0xFFD4AF37), fontWeight: FontWeight.w900)),
                ],
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("💰 Payout Request Marked as Paid!")));
                  },
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.emerald, foregroundColor: Colors.white),
                  child: const Text("Mark as Paid"),
                ),
              )
            ],
          ),
        );
      },
    );
  }
}
