package it.albanternova.cantieri;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.pdf.PdfDocument;
import android.print.*;
import android.webkit.*;
import android.view.*;
import android.widget.*;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import androidx.core.content.FileProvider;
import java.io.*;
import java.util.Base64;

public class MainActivity extends Activity {
 WebView main;
 @Override public void onCreate(Bundle b){super.onCreate(b);main=new WebView(this);configure(main);setContentView(main);main.loadUrl("file:///android_asset/index.html");}
 void configure(WebView w){WebSettings s=w.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(true);s.setDefaultTextEncodingName("UTF-8");w.setWebViewClient(new WebViewClient());w.setWebChromeClient(new WebChromeClient(){@Override public boolean onJsAlert(WebView view,String url,String message,JsResult result){new AlertDialog.Builder(MainActivity.this).setMessage(message).setPositiveButton("OK",(d,v)->result.confirm()).show();return true;}});w.addJavascriptInterface(new Bridge(),"ATAndroid");}
 class Bridge {
  @JavascriptInterface public void sharePdf(String b64,String filename){new Thread(()->{try{byte[] bytes=Base64.getDecoder().decode(b64);File f=writePdf(bytes,filename);runOnUiThread(()->share(f));}catch(Exception ex){error(ex);}}).start();}
  @JavascriptInterface public void shareHtml(String html,String filename){runOnUiThread(()->renderPdf(html,filename));}
 }
 File writePdf(byte[] bytes,String name)throws IOException{File dir=new File(getCacheDir(),"pdf");if(!dir.exists()&&!dir.mkdirs())throw new IOException("Cartella PDF non disponibile");String safe=name.replaceAll("[^a-zA-Z0-9._-]","_");if(!safe.toLowerCase().endsWith(".pdf"))safe+=".pdf";File f=new File(dir,safe);try(FileOutputStream out=new FileOutputStream(f)){out.write(bytes);}return f;}
 void renderPdf(String html,String filename){WebView printView=new WebView(this);WebSettings s=printView.getSettings();s.setJavaScriptEnabled(false);s.setDefaultTextEncodingName("UTF-8");printView.setWebViewClient(new WebViewClient(){@Override public void onPageFinished(WebView v,String url){v.postDelayed(()->writePrintedPdf(v,filename),650);}});printView.loadDataWithBaseURL("file:///android_asset/",html,"text/html","UTF-8",null);}
 void writePrintedPdf(WebView v,String filename){PrintDocumentAdapter adapter=v.createPrintDocumentAdapter(filename);PrintAttributes attrs=new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setResolution(new PrintAttributes.Resolution("pdf","PDF",300,300)).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build();adapter.onStart();adapter.onLayout(null,attrs,new android.os.CancellationSignal(),new PrintDocumentAdapter.LayoutResultCallback(){@Override public void onLayoutFinished(PrintDocumentInfo info,boolean changed){try{File dir=new File(getCacheDir(),"pdf");dir.mkdirs();File f=new File(dir,filename.replaceAll("[^a-zA-Z0-9._-]","_"));if(!f.getName().endsWith(".pdf"))f=new File(dir,f.getName()+".pdf");final File output=f;ParcelFileDescriptor fd=ParcelFileDescriptor.open(f,ParcelFileDescriptor.MODE_CREATE|ParcelFileDescriptor.MODE_TRUNCATE|ParcelFileDescriptor.MODE_READ_WRITE);adapter.onWrite(new PageRange[]{PageRange.ALL_PAGES},fd,new android.os.CancellationSignal(),new PrintDocumentAdapter.WriteResultCallback(){@Override public void onWriteFinished(PageRange[] pages){try{fd.close();}catch(Exception ignored){}adapter.onFinish();share(output);v.destroy();}@Override public void onWriteFailed(CharSequence e){try{fd.close();}catch(Exception ignored){}error(new Exception(String.valueOf(e)));}});}catch(Exception e){error(e);}}@Override public void onLayoutFailed(CharSequence error){error(new Exception(String.valueOf(error)));}},null);}
 void share(File f){try{Uri uri=FileProvider.getUriForFile(this,getPackageName()+".files",f);Intent send=new Intent(Intent.ACTION_SEND);send.setType("application/pdf");send.putExtra(Intent.EXTRA_STREAM,uri);send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(send,"Condividi PDF"));}catch(Exception e){error(e);}}
 void error(Exception e){runOnUiThread(()->Toast.makeText(this,"PDF: "+e.getMessage(),Toast.LENGTH_LONG).show());}
 @Override public void onBackPressed(){if(main.canGoBack())main.goBack();else super.onBackPressed();}
}
