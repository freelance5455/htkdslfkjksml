# Deployment-Anleitung für Netlify

## Voraussetzungen

- Die Datei `vorlese-app-pro-v3-piper-fixed.zip`
- Ein Netlify-Konto
- Für den ersten Piper-Test eine Internetverbindung

## Variante A: ZIP direkt hochladen

1. Öffne dein Netlify-Projekt.
2. Öffne den Bereich für manuelle Deployments.
3. Wähle die ZIP-Datei aus oder ziehe sie in das Upload-Feld.
4. Warte, bis der Status **Published** erscheint.
5. Öffne die veröffentlichte Adresse.
6. Prüfe, ob **V3 PIPER · TESTED BUILD** angezeigt wird.
7. Füge einen kurzen deutschen Text ein.
8. Wähle **Piper Deutsch – Thorsten (offline)** und drücke **Start**.
9. Lass die Seite beim ersten Modelldownload geöffnet.

Die ZIP enthält `_redirects`. Diese Datei leitet Anfragen unter `/piper-model/*` serverseitig an das Piper-Modellverzeichnis weiter. Dadurch fragt der Browser das Modell über dieselbe Netlify-Origin an.

## Variante B: GitHub mit automatischen Tests

1. Entpacke die ZIP in ein neues GitHub-Repository.
2. Übertrage alle Dateien einschließlich `.github`, `_redirects` und `netlify.toml`.
3. Verbinde das Repository mit Netlify.
4. Verwende für die Veröffentlichung das Repository-Stammverzeichnis. Ein Build-Befehl ist nicht erforderlich.
5. Prüfe unter **Actions**, ob der Workflow **CI** erfolgreich ist.
6. Öffne danach den Workflow **Live Piper**.
7. Wähle **Run workflow** und trage die vollständige veröffentlichte Netlify-Adresse als `live_url` ein.
8. Der Workflow prüft zuerst die echte Online-Synthese und danach mit demselben Browserprofil eine weitere Synthese bei blockiertem Netzwerk.
9. Lade bei einem Fehler das Artefakt `live-piper-report` herunter und lies `live-report.json`.

## Prüfen der Modellweiterleitung

Öffne nach dem Deployment im Browser diesen Pfad relativ zu deiner App-Adresse:

```text
/piper-model/de/de_DE/thorsten/medium/de_DE-thorsten-medium.onnx.json
```

Erwartet wird eine JSON-Konfiguration und keine HTML-Fehlerseite. Wird `404`, `403` oder eine Anmeldeseite angezeigt, ist die Modellweiterleitung nicht einsatzbereit.

## Offline-Prüfung auf dem Zielgerät

1. Starte Piper online und warte, bis wirklich Sprache erzeugt wurde.
2. Stoppe die Wiedergabe.
3. Schließe die Seite nicht und aktiviere den Flugmodus beziehungsweise trenne das Netzwerk.
4. Starte denselben oder einen neuen kurzen Text erneut.
5. Sprache muss ohne neuen Modelldownload erzeugt werden.
6. Schließe danach den Browser vollständig, öffne die App weiterhin offline erneut und wiederhole den Test.

Der automatisierte Live-Test prüft die Offline-Synthese im selben persistenten Browserprofil. Das vollständige Schließen und erneute Öffnen auf einem konkreten Mobilgerät bleibt ein manueller Freigabetest.

## Aktualisierung und Cache

Wenn nach einer neuen Bereitstellung noch eine alte Version angezeigt wird:

1. Schließe die App vollständig.
2. Öffne die Netlify-Adresse erneut.
3. Lade die Seite neu.
4. Lösche nur bei Bedarf die Website-Daten dieser Netlify-Adresse. Dabei kann auch das gespeicherte Piper-Modell entfernt werden und muss anschließend erneut geladen werden.

## Freigabekriterien

- GitHub-Workflow **CI** ist grün.
- Workflow **Live Piper** bestätigt Online und Offline.
- Die Modell-JSON ist über `/piper-model/...` erreichbar.
- Piper ist auf dem Zielgerät hörbar.
- Pause, Weiter und Stopp funktionieren.
- Eine Gerätestimme funktioniert als Fallback.


## Ergebnis der lokalen Netlify-Prüfung

Netlify CLI 23.11.1 wurde lokal gestartet. Die CLI meldete einen lokalen Server, brach in dieser isolierten Umgebung beim Vorbereiten des Edge-Proxys jedoch mit `fetch failed` ab. Daher wurde hier keine erfolgreiche Modell-JSON-Antwort über den laufenden Proxy bestätigt.

`tests/redirect_config_test.py` bestätigt zusätzlich deterministisch, dass `_redirects`, `netlify.toml`, der Piper-Basispfad `/piper-model` und die `:splat`-Ersetzung übereinstimmen. Das ersetzt nicht den Test auf der veröffentlichten Netlify-Adresse.

Lokaler Test im Projektordner:

```bash
npm install --save-dev netlify-cli
npx netlify dev --dir . --port 8888
```

In einem zweiten Terminal:

```bash
curl -i http://localhost:8888/piper-model/de/de_DE/thorsten/medium/de_DE-thorsten-medium.onnx.json
```

Erwartet werden HTTP 200 und eine JSON-Konfiguration.
