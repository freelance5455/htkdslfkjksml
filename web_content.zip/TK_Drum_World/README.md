# TK DRUM WORLD — Starter App

A mobile-friendly drum library and rhythm-maker starter project.

## Included features
- 28 example instruments grouped by region
- Search and region filters
- Playable synthesized demo sounds
- Load a sound file you have rights to use for the selected drum (WAV/MP3/OGG supported by the browser)
- 16-step rhythm sequencer with eight drum lanes
- Tempo, swing, random beat, clear, play and stop controls
- Save patterns for the current session and export/import patterns as JSON
- Capacitor configuration for building an Android project

## Important sound note
The included demo tones are synthesized approximations, not authentic recordings of the listed traditional instruments. To get original sounds, use high-quality recordings that you own or are licensed to use. Choose recordings with clean starts, low background noise, and appropriate playing techniques. Cultural instruments can have several different playing styles; use reliable sources and name the recordings accurately.

## Try it in a browser
1. Unzip the project.
2. Open `www/index.html` in a modern browser. Some browser audio features may require a local server.
3. For a local server, install Node.js, open a terminal in this folder and run:
   `npm install`
   `npm start`
4. Open the local address printed by the server.

## Build an Android APK (requires a computer)
Prerequisites: Node.js LTS, Android Studio, Android SDK, and a supported Java version for your installed Android Gradle tooling.

1. Unzip the project and open a terminal in the `TK_Drum_World` folder.
2. Run:
   `npm install`
3. Add the Android native project:
   `npx cap add android`
4. Copy the web app into the native project:
   `npx cap sync android`
5. Open Android Studio:
   `npx cap open android`
6. In Android Studio, wait for Gradle sync to finish. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
7. Android Studio will show the location of the APK when the build finishes.

If `npx cap add android` says the Android platform already exists, skip that command and run `npx cap sync android`.

## Adding more authentic instruments
- Add entries to the `drums` array in `www/index.html`.
- Each entry has: name, region, origin, emoji/icon, and a demo sound type.
- For the current prototype, a user can load one sample per selected instrument during that session.
- For a production app, place properly licensed audio files in the app's asset folder and implement a curated sample manifest. Keep a record of the source and license for every recording.
- For high-quality low-latency playback, consider using short WAV/OGG samples and test on the target Android phone.

## Current limitations
- No bundled authentic sample library (copyright/licensing matters).
- Saved patterns are session-only in this starter; export JSON to preserve them.
- Audio samples loaded from the picker are session-only.
- This starter does not yet record a final mixed audio file, offer multitrack editing, or sync to cloud accounts.
- The instrument list is a starting collection, not literally every drum in the world. Expand it thoughtfully and verify names, origins, and cultural context.
