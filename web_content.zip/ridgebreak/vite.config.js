import { defineConfig } from 'vite';
// base './' makes asset paths relative so the bundle works inside the Capacitor WebView.
export default defineConfig({ base: './', build: { outDir: 'dist', target: 'es2019', chunkSizeWarningLimit: 900 } });
