# RIDGEBREAK: WINTER FRONT (1944)
Single-player, fully offline, mobile-first WW2 first-person shooter. One map (**Frostline Village**), territory control (5 flags A–E), bots on both sides, heavy physics, procedural war audio. Built with Three.js + Vite and packaged for Android with Capacitor. No servers, no multiplayer, no network permission needed.

Art direction follows your reference sheets: US Infantry (M41 jacket, M1 helmet, Thompson / M1 Garand) vs Fallschirmjäger (jump smock, M38 helmet, K98k), Walther P38, M2 HMG, and the snowy low-poly village map. Your sheets are shipped as menu art and a **Field Manual** screen (`public/img/`). The 3D models are built from primitives to match them (the 2D sprite sheets themselves are reference only).

## Run in a browser (test)
```bash
npm install
npm run dev          # LAN URL printed -> open on your phone (same Wi-Fi) to test touch controls
```
(Keyboard works too on desktop: WASD, mouse, LMB fire, RMB aim, R, G, Q, E, Shift, C, Space.)

## Build the APK
Needs Node 18+, JDK 17, Android Studio.
```bash
npm install
npm run build
npx cap add android        # once
npx cap sync android       # after every web change  (or: npm run android:sync)
npx cap open android
```
Android Studio: `Build > Build APK(s)` (debug, unsigned) → `android/app/build/outputs/apk/debug/app-debug.apk`, or `Build > Generate Signed Bundle / APK` for a release. Keep your keystore private.

Recommended after `cap add android`:
1. **Landscape lock** — `AndroidManifest.xml`, on `<activity>`: `android:screenOrientation="sensorLandscape"`.
2. **Immersive fullscreen** — in `MainActivity.java` `onCreate` after `super.onCreate`: 
```java
WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
```
(with imports `android.view.View`, `androidx.core.view.WindowCompat`)
3. **Permissions:** none required. You may delete the default `INTERNET` permission line.
4. Change `appId` in `capacitor.config.json` and `applicationId` in `android/app/build.gradle`; replace launcher icons in `res/mipmap-*`.

## How to play
Floating joystick (left), drag the right half to look (the FIRE button also steers). AIM / DUCK / RUN are toggles. USE appears next to an M2 Browning emplacement. Capture and hold flags A–E: each owned flag gives +1 point/second; first to 200 or the higher score at 8:00 wins. Pick side (US / German), primary weapon (Thompson, M1 Garand, K98k) and a spawn point (home base or a flag you hold). Sidearm: Walther P38. 2 grenades.

## What's in the game
- **Weapons:** Thompson (drum, full-auto), M1 Garand (8 rounds, clip *ping* when empty), K98k (bolt cycle, 2-shot kills), P38, M2 HMG (mountable, overheats). Recoil, sway, bob, ADS zoom, reload animation, ejected casings, tracers, muzzle flash.
- **Physics:** ragdolls (each body part tumbles and bounces), explosive fuel drums that chain-react, crates/drums you can shove or blow across the field, grenades that bounce, explosion knock-back on soldiers, fall damage, stamina-limited sprint, landing dip, crater decals.
- **Bots:** see-and-react AI with reaction time, strafing, cover seeking when wounded, flag capture, grenades, stuck recovery; three skill levels. 4v4 up to 16v16.
- **Graphics:** low-poly snow village, merged vertex-coloured models, instanced pine forest, painted roads, sky dome, fog, falling snow, particle smoke/fire/debris (single draw call), optional shadows (High).
- **Audio (procedural):** distinct gunshots per weapon, positional pan + distance filtering + reverb, bullet whizz/suppression, explosions, footsteps in snow, wind, distant artillery, menu/battle music.
- **Menus:** boot/loading, main menu, briefing & loadout (with your art), Field Manual, settings (sensitivity, sound, music, graphics, bot count, skill), pause, results with stats.

## Files
`index.html`, `src/main.js` (boot, menus, HUD bridge), `game.js` (match, player controller, weapons, damage, capture, grenades), `bots.js` (AI), `world.js` (map, collision), `models.js` (soldiers, weapons, props), `physics.js` (props, ragdolls, casings), `fx.js` (particles, decals, snow), `audio.js`, `input.js` (touch), `weapons.js` (stats), `settings.js`.

## Performance tips
Graphics → Low renders at 0.6× resolution without shadows. Medium (default) is 0.85×. High adds shadows and a denser forest. If a phone struggles: Low + 4v4 or 8v8. Forest density and shadow-map size apply on next launch.


## v3 upgrade: graphics, heavy physics, particles, settings
**Graphics**
- Time of day (Day / Dusk / Night) and weather (Clear / Snowfall / Blizzard) with matching sky gradient, sun/moon glow, drifting clouds, night stars, fog and light colour.
- Optional **bloom** post-processing (High preset), vignette/grade, brightness slider, dynamic point-lights for explosions and muzzle flashes.
- Snow ground grain texture + drift colour variation, snow drifts against walls, woodpiles, lamp posts, shrubs, chimney smoke, wind-swaying pines.
- More detailed soldiers (faces, helmet nets/straps, packs, canteens, belts, goggles).

**Heavy physics** (`physics.js`)
- Props are real rigid bodies: every vertex is a contact point, so barrels roll, crates tip and settle on corners; friction, restitution, spin from off-centre hits; prop-vs-prop collisions (barrels bowl into crates); fast props **crush** soldiers.
- Fuel barrels ignite when damaged, jet around while burning, then cook off; leave burning fuel that damages anyone standing in it.
- Verlet **ragdolls** with joints (head, shoulders, hips, hands, gun), reacting to later explosions.
- Instanced **debris** (splinters, metal, earth, snow, shrapnel) that bounce, settle and fade; heavier shell casings; grenades bounce off props and shove them.

**Particles** (`fx.js`)
- Two GPU layers (alpha smoke + additive fire/sparks), rotating noisy sprites, wind-driven smoke, ground-bouncing sparks and chips, shockwave rings, embers, persistent fires, per-surface bullet impacts, fully GPU-animated wind-blown snow.

**Settings** (Menu or Pause > Settings, applies instantly)
Controls (sensitivity, FOV, invert Y, bob, shake) · Audio · Graphics (preset, resolution scale, brightness, time of day, weather, shadows, bloom, dynamic lights, vignette, FPS) · Physics & FX (physics intensity Light/Normal/Heavy/Extreme, particle density, debris, ragdoll quality) · Match. "Auto" follows the preset; Reset to defaults button.

## Note
The v3 changes were syntax-checked and the physics (props, ragdoll, debris) smoke-tested headlessly, but not run in a browser/GPU. Playtest with `npm run dev` before the APK and send me anything that misbehaves.
