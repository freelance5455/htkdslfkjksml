// ---- INPUT: unifies touch (floating joystick + look zone + buttons) and desktop (WASD + pointer lock). ----
export const isTouch = ('ontouchstart' in window) || navigator.maxTouchPoints > 0;
export function createInput(canvas) {
  const s = {
    moveX: 0, moveY: 0, fire: false, ads: false, crouch: false, sprint: false, sens: 1,
    _lx: 0, _ly: 0, _ev: {}, _k: {}, _tj: { x: 0, y: 0 },
    take(n) { const v = this._ev[n]; this._ev[n] = false; return !!v; },          // one-shot events: jump, reload, grenade, swap
    consumeLook() { const r = { dx: this._lx, dy: this._ly }; this._lx = this._ly = 0; return r; },
    poll() {                                                                       // merge keyboard + joystick into moveX/moveY
      const k = this._k; let x = (k.KeyD || k.ArrowRight ? 1 : 0) - (k.KeyA || k.ArrowLeft ? 1 : 0), y = (k.KeyW || k.ArrowUp ? 1 : 0) - (k.KeyS || k.ArrowDown ? 1 : 0);
      x += this._tj.x; y += this._tj.y; const l = Math.hypot(x, y); if (l > 1) { x /= l; y /= l; } this.moveX = x; this.moveY = y;
    },
    reset() { this.fire = this.ads = this.crouch = this.sprint = false; this._k = {}; this._ev = {}; this._tj.x = this._tj.y = 0; this._lx = this._ly = 0; document.querySelectorAll('.btn.on').forEach(b => b.classList.remove('on')); },
  };
  // ---- desktop ----
  addEventListener('keydown', e => {
    if (e.repeat) return; s._k[e.code] = true;
    if (e.code === 'Space') s._ev.jump = true; else if (e.code === 'KeyR') s._ev.reload = true; else if (e.code === 'KeyG') s._ev.grenade = true; else if (e.code === 'KeyQ') s._ev.swap = true; else if (e.code === 'KeyE') s._ev.use = true;
    else if (e.code === 'ShiftLeft') s.sprint = true; else if (e.code === 'KeyC' || e.code === 'ControlLeft') s.crouch = true;
  });
  addEventListener('keyup', e => { s._k[e.code] = false; if (e.code === 'ShiftLeft') s.sprint = false; if (e.code === 'KeyC' || e.code === 'ControlLeft') s.crouch = false; });
  addEventListener('mousedown', e => { if (document.pointerLockElement !== canvas) return; if (e.button === 0) s.fire = true; if (e.button === 2) s.ads = true; });
  addEventListener('mouseup', e => { if (e.button === 0) s.fire = false; if (e.button === 2) s.ads = false; });
  addEventListener('mousemove', e => { if (document.pointerLockElement === canvas) { s._lx += e.movementX * 0.0022 * s.sens; s._ly += e.movementY * 0.0022 * s.sens; } });
  addEventListener('wheel', () => { if (document.pointerLockElement === canvas) s._ev.swap = true; });
  addEventListener('contextmenu', e => e.preventDefault());
  // ---- touch ----
  if (isTouch) {
    const $ = id => document.getElementById(id), P = { passive: false };
    const joyZone = $('joyZone'), base = $('joyBase'), knob = $('joyKnob'), lookZone = $('lookZone'), R = 55;
    let joyId = null, o = { x: 0, y: 0 };
    joyZone.addEventListener('touchstart', e => {
      e.preventDefault(); if (joyId !== null) return; const t = e.changedTouches[0]; joyId = t.identifier; o = { x: t.clientX, y: t.clientY };
      base.style.left = o.x + 'px'; base.style.top = o.y + 'px'; base.style.display = 'block'; knob.style.transform = 'translate(0,0)';
    }, P);
    joyZone.addEventListener('touchmove', e => {
      e.preventDefault(); for (const t of e.changedTouches) if (t.identifier === joyId) {
        let dx = t.clientX - o.x, dy = t.clientY - o.y; const l = Math.hypot(dx, dy); if (l > R) { dx *= R / l; dy *= R / l; }
        knob.style.transform = `translate(${dx}px,${dy}px)`; s._tj.x = dx / R; s._tj.y = -dy / R;
      }
    }, P);
    const joyEnd = e => { for (const t of e.changedTouches) if (t.identifier === joyId) { joyId = null; s._tj.x = s._tj.y = 0; base.style.display = 'none'; s.sprint = false; $('bSprint').classList.remove('on'); } };
    joyZone.addEventListener('touchend', joyEnd, P); joyZone.addEventListener('touchcancel', joyEnd, P);
    // look: drag anywhere on the right side; the FIRE button also steers so you can aim while shooting
    const lookTracker = (el) => {
      let id = null, lp = null;
      el.addEventListener('touchstart', e => { const t = e.changedTouches[0]; if (id === null) { id = t.identifier; lp = { x: t.clientX, y: t.clientY }; } }, P);
      el.addEventListener('touchmove', e => {
        e.preventDefault(); for (const t of e.changedTouches) if (t.identifier === id) { s._lx += (t.clientX - lp.x) * 0.0045 * s.sens; s._ly += (t.clientY - lp.y) * 0.0045 * s.sens; lp = { x: t.clientX, y: t.clientY }; }
      }, P);
      const end = e => { for (const t of e.changedTouches) if (t.identifier === id) id = null; };
      el.addEventListener('touchend', end, P); el.addEventListener('touchcancel', end, P);
    };
    lookTracker(lookZone);
    document.querySelectorAll('.btn').forEach(el => {
      const a = el.dataset.act; if (a === 'fire') lookTracker(el);
      el.addEventListener('touchstart', e => {
        e.preventDefault(); e.stopPropagation();
        if (a === 'fire') { s.fire = true; el.classList.add('on'); }
        else if (a === 'ads') { s.ads = !s.ads; el.classList.toggle('on', s.ads); }
        else if (a === 'crouch') { s.crouch = !s.crouch; el.classList.toggle('on', s.crouch); }
        else if (a === 'sprint') { s.sprint = !s.sprint; el.classList.toggle('on', s.sprint); }
        else s._ev[a] = true;
      }, P);
      const up = () => { if (a === 'fire') { s.fire = false; el.classList.remove('on'); } };
      el.addEventListener('touchend', up, P); el.addEventListener('touchcancel', up, P);
    });
  }
  return s;
}
