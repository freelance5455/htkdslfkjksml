import * as THREE from 'three';
import { terrainH } from './world.js';
// ---- FX: two GPU point layers (alpha-blended smoke/dust + additive fire/sparks), GPU snow, shockwaves, light flashes, decals, fires. ----
export const WIND = { x: 1.6, z: .5, gust: 0 };
export const COL = {
  snow: [.95, .97, 1, .75], snow2: [.92, .95, 1, .55], dust: [.55, .5, .45, .6], wood: [.45, .32, .2, 1], fire: [1, .65, .2, .95], fire2: [.35, .12, .05, 0], flame: [1, .8, .3, .9], flame2: [.9, .2, .05, 0],
  smoke: [.2, .2, .22, .72], smoke2: [.5, .52, .55, 0], spark: [1, .85, .4, 1], spark2: [1, .4, .1, 0], gun: [.75, .75, .72, .3], gun2: [.8, .8, .8, 0], earth: [.3, .25, .2, 1], clear: [1, 1, 1, 0],
  flash: [1, .95, .7, 1], flash2: [1, .5, .15, 0], ember: [1, .55, .15, 1], ember2: [.8, .2, .05, 0], dirt: [.26, .21, .17, .85], dirt2: [.4, .36, .32, 0], ice: [.85, .93, 1, 1], steam: [.9, .92, .95, .35],
};
const rnd = a => (Math.random() - .5) * 2 * a, R = Math.random;

const VERT = 'attribute float aSize;attribute vec4 aColor;attribute float aRot;attribute float aKind;uniform float uScale;varying vec4 vC;varying float vK;varying float vR;' +
  'void main(){vC=aColor;vK=aKind;vR=aRot;vec4 mv=modelViewMatrix*vec4(position,1.0);float nf=smoothstep(.25,2.2,-mv.z);vC.a*=nf;gl_PointSize=min(aSize*uScale/max(-mv.z,.1),420.0);gl_Position=projectionMatrix*mv;}';
const FRAG = 'varying vec4 vC;varying float vK;varying float vR;void main(){vec2 p=gl_PointCoord-.5;float c=cos(vR),s=sin(vR);p=vec2(c*p.x-s*p.y,s*p.x+c*p.y);float d=length(p)*2.;float a;' +
  'if(vK<.5){a=1.-smoothstep(.1,1.,d);}' +
  'else if(vK<1.5){float n=.5+.25*sin(p.x*17.+vR*3.)+.25*sin(p.y*13.-vR*5.)*sin(p.x*7.+2.);a=(1.-smoothstep(.2,1.,d+(n-.5)*.6))*(.75+.25*n);}' +
  'else{a=pow(max(0.,1.-d),2.2)+(1.-smoothstep(0.,.3,d))*.7;}' +
  'if(a<.01)discard;gl_FragColor=vec4(vC.rgb,vC.a*a);}';

class Layer {
  constructor(scene, max, additive, uScale) {
    this.max = max; this.next = 0; const A = n => new Float32Array(n);
    Object.assign(this, { pos: A(max * 3), vel: A(max * 3), col: A(max * 4), c0: A(max * 4), c1: A(max * 4), size: A(max), s0: A(max), s1: A(max), life: A(max), mx: A(max), grav: A(max), drag: A(max), rot: A(max), spin: A(max), kind: A(max), bounce: A(max), wf: A(max) });
    const g = new THREE.BufferGeometry(), dyn = (a, n) => new THREE.BufferAttribute(a, n).setUsage(THREE.DynamicDrawUsage);
    this.ap = dyn(this.pos, 3); this.ac = dyn(this.col, 4); this.as = dyn(this.size, 1); this.ar = dyn(this.rot, 1); this.ak = dyn(this.kind, 1);
    g.setAttribute('position', this.ap); g.setAttribute('aColor', this.ac); g.setAttribute('aSize', this.as); g.setAttribute('aRot', this.ar); g.setAttribute('aKind', this.ak);
    this.mat = new THREE.ShaderMaterial({ uniforms: { uScale }, transparent: true, depthWrite: false, blending: additive ? THREE.AdditiveBlending : THREE.NormalBlending, vertexShader: VERT, fragmentShader: FRAG });
    this.points = new THREE.Points(g, this.mat); this.points.frustumCulled = false; this.points.renderOrder = additive ? 3 : 2; scene.add(this.points);
  }
  emit(x, y, z, vx, vy, vz, life, s0, s1, c0, c1, grav, drag, kind, bounce, wf, spin) {
    const i = this.next; this.next = (i + 1) % this.max; const p = i * 3, c = i * 4;
    this.pos[p] = x; this.pos[p + 1] = y; this.pos[p + 2] = z; this.vel[p] = vx; this.vel[p + 1] = vy; this.vel[p + 2] = vz;
    this.life[i] = this.mx[i] = life; this.s0[i] = s0; this.s1[i] = s1; this.grav[i] = grav; this.drag[i] = drag; this.kind[i] = kind; this.bounce[i] = bounce; this.wf[i] = wf; this.rot[i] = R() * 6.28; this.spin[i] = spin;
    for (let k = 0; k < 4; k++) { this.c0[c + k] = c0[k]; this.c1[c + k] = c1[k]; }
  }
  update(dt) {
    const wx = WIND.x * (1 + WIND.gust), wz = WIND.z * (1 + WIND.gust);
    for (let i = 0; i < this.max; i++) {
      if (this.life[i] <= 0) continue; this.life[i] -= dt; const p = i * 3, c = i * 4;
      if (this.life[i] <= 0) { this.size[i] = 0; this.col[c + 3] = 0; continue; }
      const t = 1 - this.life[i] / this.mx[i], d = Math.max(0, 1 - this.drag[i] * dt), wf = this.wf[i];
      this.vel[p] *= d; this.vel[p + 1] = this.vel[p + 1] * d - this.grav[i] * dt; this.vel[p + 2] *= d;
      this.pos[p] += (this.vel[p] + wx * wf) * dt; this.pos[p + 1] += this.vel[p + 1] * dt; this.pos[p + 2] += (this.vel[p + 2] + wz * wf) * dt;
      if (this.bounce[i] > 0) { const gy = terrainH(this.pos[p], this.pos[p + 2]) + .04; if (this.pos[p + 1] < gy) { this.pos[p + 1] = gy; this.vel[p + 1] = Math.abs(this.vel[p + 1]) > 1.5 ? -this.vel[p + 1] * this.bounce[i] : 0; this.vel[p] *= .6; this.vel[p + 2] *= .6; } }
      this.rot[i] += this.spin[i] * dt; this.size[i] = this.s0[i] + (this.s1[i] - this.s0[i]) * t;
      for (let k = 0; k < 4; k++) this.col[c + k] = this.c0[c + k] + (this.c1[c + k] - this.c0[c + k]) * t;
    }
    this.ap.needsUpdate = this.ac.needsUpdate = this.as.needsUpdate = this.ar.needsUpdate = this.ak.needsUpdate = true;
  }
}

export class Particles {
  constructor(scene, mul = 1, lights = true) {
    this.q = mul; this.uScale = { value: 600 };
    this.alpha = new Layer(scene, Math.round(1400 * mul), false, this.uScale); this.add = new Layer(scene, Math.round(1600 * mul), true, this.uScale);
    // shockwave rings (pooled)
    const rg = new THREE.RingGeometry(.86, 1, 48); rg.rotateX(-Math.PI / 2); this.rings = [];
    for (let i = 0; i < 4; i++) { const m = new THREE.Mesh(rg, new THREE.MeshBasicMaterial({ color: 0xffe2b0, transparent: true, opacity: 0, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide })); m.visible = false; m.renderOrder = 4; scene.add(m); this.rings.push({ m, t: 9, R: 1 }); } this.ri = 0;
    // pooled dynamic lights (always present so shaders never recompile mid-fight)
    this.lights = []; for (let i = 0; i < 3; i++) { const l = new THREE.PointLight(0xffa860, 0, 70, 2); l.position.set(0, -50, 0); scene.add(l); this.lights.push({ l, base: 0, t: 1, dur: 1 }); } this.li = 0; this.lightsOn = lights; this.setLights(lights);
    this.fires = [];
  }
  n(k) { return Math.max(1, Math.round(k * this.q)); }
  setLights(on) { this.lightsOn = on; for (const L of this.lights) L.l.visible = on; }
  /** Backwards-compatible emitter. Spark/fire colours automatically go to the additive layer. */
  emit(x, y, z, vx, vy, vz, life, s0, s1, c0, c1, grav = 0, drag = 0, kind = 0, bounce = 0, wf = 0, add = false, spin = 0) {
    if (c0 === COL.spark) { add = true; if (!kind) kind = 2; } else if (c0 === COL.fire || c0 === COL.flame || c0 === COL.flash || c0 === COL.ember) add = true; else if (c0 === COL.gun && !kind) { kind = 1; wf = 1; }
    (add ? this.add : this.alpha).emit(x, y, z, vx, vy, vz, life, s0, s1, c0, c1, grav, drag, kind, bounce, wf, spin);
  }
  update(dt) {
    this.alpha.update(dt); this.add.update(dt);
    for (const r of this.rings) { if (r.t > .6) { r.m.visible = false; continue; } r.t += dt; const k = r.t / .6, e = 1 - Math.pow(1 - k, 3); r.m.scale.setScalar(Math.max(.1, r.R * e)); r.m.material.opacity = (1 - k) * .55; }
    for (const L of this.lights) { if (L.t >= L.dur) { L.l.intensity = 0; continue; } L.t += dt; const k = 1 - L.t / L.dur; L.l.intensity = this.lightsOn ? L.base * k * k : 0; }
    for (let i = this.fires.length - 1; i >= 0; i--) {
      const f = this.fires[i]; f.t += dt; if (f.t > f.life) { this.fires.splice(i, 1); continue; } const fade = Math.min(1, (f.life - f.t) / 2), s = f.s * fade; f.acc += dt * 26 * this.q * (.4 + .6 * fade);
      while (f.acc >= 1) { f.acc--; const a = R() * 6.28, r = R() * .5 * s; this.emit(f.x + Math.cos(a) * r, f.y, f.z + Math.sin(a) * r, rnd(.4), 1.6 + R() * 1.6, rnd(.4), .5 + R() * .4, .5 * s + .1, .08, COL.flame, COL.flame2, -2.2, 1, 0, 0, .4, true, rnd(2));
        if (R() < .28) this.emit(f.x + rnd(.3 * s), f.y + .5, f.z + rnd(.3 * s), rnd(.5), 1.2 + R() * 1.4, rnd(.5), 1.8 + R() * 1.4, .45 * s + .1, 1.7 * s + .3, COL.smoke, COL.smoke2, -1, .6, 1, 0, 1, false, rnd(1)); if (R() < .1) this.emit(f.x, f.y + .6, f.z, rnd(1.5), 2 + R() * 2, rnd(1.5), 1.4 + R(), .1, .02, COL.ember, COL.ember2, -.5, .5, 2, 0, 1, true); }
    }
  }
  setScale(h, fov) { this.uScale.value = h * 0.5 / Math.tan(fov * Math.PI / 360); }
  rnd(a) { return rnd(a); }
  light(x, y, z, intensity, dur = .35, color = 0xffa860) { const L = this.lights[this.li++ % this.lights.length]; L.l.position.set(x, y, z); L.l.color.setHex(color); L.base = intensity; L.t = 0; L.dur = dur; }
  shock(x, y, z, Rr) { const r = this.rings[this.ri++ % this.rings.length]; r.m.position.set(x, terrainH(x, z) + .2, z); r.R = Rr; r.t = 0; r.m.visible = true; }
  addFire(x, y, z, life = 8, s = 1) { if (this.fires.length > 12) this.fires.shift(); this.fires.push({ x, y, z, life, s, t: 0, acc: 0 }); }

  // ---- emitters ----
  puff(x, y, z, col = COL.snow, n = 6, pow = 2.5) { n = this.n(n); for (let i = 0; i < n; i++) this.emit(x, y, z, rnd(pow), Math.random() * pow, rnd(pow), .5 + R() * .6, .22, .8 + R() * .5, col, [col[0], col[1], col[2], 0], 3, 2, 1, 0, .4, false, rnd(2)); }
  chips(x, y, z, col, n = 6) { n = this.n(n); for (let i = 0; i < n; i++) this.emit(x, y, z, rnd(4), 2 + R() * 4, rnd(4), .9, .12, .09, col, col, 18, .5, 0, .35); }
  muzzle(x, y, z, dx, dy, dz) {
    this.emit(x + dx * .3, y + dy * .3, z + dz * .3, dx * 2, dy * 2, dz * 2, .055, .3 + R() * .15, .08, COL.flash, COL.flash2, 0, 0, 0, 0, 0, true, rnd(8));
    for (let i = 0; i < this.n(3); i++) this.emit(x, y, z, dx * 14 + rnd(3), dy * 14 + rnd(3), dz * 14 + rnd(3), .1 + R() * .08, .09, .02, COL.spark, COL.spark2, 6, 1);
    this.emit(x + dx, y + dy, z + dz, dx * 1.5, dy * 1.5 + .4, dz * 1.5, .9 + R() * .5, .1, .65, COL.gun, COL.gun2, -.3, 1.5, 1, 0, 1, false, rnd(2));
    if (this.lightsOn) this.light(x, y, z, 55, .07, 0xffc880);
  }
  /** Bullet impact: surface type decides sparks / splinters / dust / snow. n = surface normal (optional). */
  impact(x, y, z, type = 'snow', nx = 0, ny = 1, nz = 0) {
    const sp = (k, pw) => { for (let i = 0; i < this.n(k); i++) this.emit(x, y, z, nx * pw + rnd(pw * .7), ny * pw + R() * pw * .8, nz * pw + rnd(pw * .7), .25 + R() * .3, .07, .02, COL.spark, COL.spark2, 22, .4, 2, .3); };
    if (type === 'snow') { this.puff(x, y + .05, z, COL.snow, 6, 2.2); for (let i = 0; i < this.n(4); i++) this.emit(x, y, z, rnd(2.5), 1.5 + R() * 3, rnd(2.5), .7, .07, .05, COL.ice, COL.ice, 16, .4, 0, .3); }
    else if (type === 'wood') { this.chips(x, y, z, [.55, .38, .22, 1], 6); this.puff(x, y, z, COL.dust, 3, 1.6); }
    else if (type === 'metal') { sp(9, 7); this.puff(x, y, z, COL.gun, 2, 1); }
    else { sp(4, 5); this.puff(x, y, z, COL.dust, 4, 2); this.chips(x, y, z, [.5, .5, .5, 1], 3); }
  }
  /** Muzzle-gas / heat haze style wisp, used for hot barrels and casings. */
  wisp(x, y, z) { this.emit(x, y, z, rnd(.2), .5 + R() * .5, rnd(.2), 1.2, .06, .35, COL.steam, [1, 1, 1, 0], -.2, .8, 1, 0, 1); }
  blast(x, y, z, s = 1) {
    const n = k => this.n(k);
    this.emit(x, y + .4 * s, z, 0, 0, 0, .14, 3 * s, 8 * s, COL.flash, COL.flash2, 0, 0, 0, 0, 0, true);
    for (let i = 0; i < n(18); i++) this.emit(x + rnd(.7 * s), y + rnd(.4 * s), z + rnd(.7 * s), rnd(5 * s), 1 + R() * 5 * s, rnd(5 * s), .45 + R() * .6, 1.6 * s, 4.4 * s, COL.fire, COL.fire2, -3, 1.8, 0, 0, .3, true, rnd(2));
    for (let i = 0; i < n(16); i++) this.emit(x + rnd(s), y + .6, z + rnd(s), rnd(3.2 * s), 1.6 + R() * 3.4, rnd(3.2 * s), 2.6 + R() * 2.4, 2 * s, 8 * s, COL.smoke, COL.smoke2, -.9, .9, 1, 0, 1, false, rnd(1.2));
    for (let i = 0; i < n(10); i++) this.emit(x + rnd(.5 * s), y, z + rnd(.5 * s), rnd(2.2 * s), 6 + R() * 6 * s, rnd(2.2 * s), 1.2 + R(), 1.1 * s, 3.8 * s, COL.dirt, COL.dirt2, 8, 1.2, 1, 0, .6, false, rnd(1));
    for (let i = 0; i < n(30); i++) this.emit(x, y, z, rnd(15 * s), 3 + R() * 13 * s, rnd(15 * s), .5 + R() * .8, .2, .04, COL.spark, COL.spark2, 24, .3, 2, .35);
    for (let i = 0; i < n(14); i++) this.emit(x, y, z, rnd(9 * s), 4 + R() * 9 * s, rnd(9 * s), 1.4, .2, .18, COL.earth, COL.earth, 24, .2, 0, .3);
    const ring = n(22); for (let i = 0; i < ring; i++) { const a = i / ring * 6.283, sp = (9 + R() * 5) * s; this.emit(x + Math.cos(a) * .8 * s, y + .25, z + Math.sin(a) * .8 * s, Math.cos(a) * sp, .5 + R() * 1.2, Math.sin(a) * sp, .9 + R() * .5, .6 * s, 3.2 * s, COL.snow2, COL.clear, 0, 2.6, 1, 0, .3, false, rnd(1)); }
    for (let i = 0; i < n(14); i++) this.emit(x + rnd(2 * s), y + R() * 2 * s, z + rnd(2 * s), rnd(3 * s), 2 + R() * 4, rnd(3 * s), 1.6 + R() * 1.8, .12, .02, COL.ember, COL.ember2, -1.6, .8, 2, 0, 1, true);
    this.shock(x, y, z, 9 * s); if (this.lightsOn) this.light(x, y + 1.5, z, 600 * s, .45, 0xffa050);
  }
}

// ---- Decals: soft scorch craters with a pushed-up snow rim, and tiny bullet-scuff marks ----
function craterTex() {
  const c = document.createElement('canvas'); c.width = c.height = 128; const x = c.getContext('2d'), g = x.createRadialGradient(64, 64, 0, 64, 64, 64);
  g.addColorStop(0, 'rgba(8,8,10,.92)'); g.addColorStop(.45, 'rgba(22,20,20,.8)'); g.addColorStop(.72, 'rgba(60,54,48,.5)'); g.addColorStop(.84, 'rgba(245,248,255,.4)'); g.addColorStop(1, 'rgba(255,255,255,0)'); x.fillStyle = g; x.fillRect(0, 0, 128, 128);
  for (let i = 0; i < 70; i++) { const a = R() * 6.28, r = 20 + R() * 40; x.fillStyle = `rgba(10,10,10,${.15 + R() * .25})`; x.beginPath(); x.arc(64 + Math.cos(a) * r, 64 + Math.sin(a) * r, 1 + R() * 3, 0, 6.28); x.fill(); }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}
export class Decals {
  constructor(scene, n = 24) {
    this.i = 0; this.list = []; const geo = new THREE.CircleGeometry(1, 20); geo.rotateX(-Math.PI / 2); const tex = craterTex();
    for (let k = 0; k < n; k++) { const m = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ map: tex, transparent: true, opacity: .9, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -3, polygonOffsetUnits: -3, fog: true })); m.visible = false; scene.add(m); this.list.push(m); }
  }
  add(x, z, r) {
    const m = this.list[this.i++ % this.list.length]; let y = terrainH(x, z); for (let k = 0; k < 4; k++) { const a = k * 1.571; y = Math.max(y, terrainH(x + Math.cos(a) * r * .8, z + Math.sin(a) * r * .8)); }
    m.position.set(x, y + .07, z); m.scale.setScalar(r); m.rotation.y = R() * 6.28; m.visible = true;
  }
  clear() { this.list.forEach(m => m.visible = false); }
}

// ---- Snow: fully GPU-animated flakes wrapped around the camera (no per-frame CPU cost), wind-driven, with weather presets ----
export class Snow {
  constructor(scene, n, uScale) {
    this.n = n; this.max = n; this.t = 0; const seed = new Float32Array(n * 3), pos = new Float32Array(n * 3); for (let i = 0; i < n * 3; i++) seed[i] = R();
    const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(pos, 3)); g.setAttribute('aSeed', new THREE.BufferAttribute(seed, 3)); g.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e5);
    this.u = { uTime: { value: 0 }, uCam: { value: new THREE.Vector3() }, uWind: { value: new THREE.Vector2(1.6, .5) }, uFall: { value: 1 }, uSize: { value: .07 }, uAlpha: { value: .85 }, uBox: { value: new THREE.Vector3(46, 26, 46) }, uScale: uScale || { value: 600 } };
    this.mat = new THREE.ShaderMaterial({ uniforms: this.u, transparent: true, depthWrite: false,
      vertexShader: 'attribute vec3 aSeed;uniform float uTime,uFall,uSize;uniform vec3 uCam,uBox;uniform vec2 uWind;uniform float uScale;varying float vA;' +
        'void main(){vec3 p=aSeed*uBox;float f=(1.1+aSeed.z*1.7)*uFall;p.x+=(uWind.x+sin(uTime*.6+aSeed.y*30.)*.5)*uTime+sin(uTime*1.3+aSeed.x*40.)*.35;p.z+=(uWind.y+cos(uTime*.5+aSeed.x*30.)*.5)*uTime+cos(uTime*1.1+aSeed.z*40.)*.35;p.y-=f*uTime;' +
        'vec3 rel=mod(p-uCam+uBox*.5,uBox);vec3 w=vec3(uCam.x+rel.x-uBox.x*.5,uCam.y-uBox.y*.5+rel.y,uCam.z+rel.z-uBox.z*.5);vec4 mv=viewMatrix*vec4(w,1.);' +
        'float d=-mv.z;vA=smoothstep(.4,1.8,d)*(1.-smoothstep(uBox.x*.3,uBox.x*.5,d));gl_PointSize=clamp((.6+aSeed.z)*uSize*uScale/max(d,.1),1.,28.);gl_Position=projectionMatrix*mv;}',
      fragmentShader: 'uniform float uAlpha;varying float vA;void main(){float d=length(gl_PointCoord-.5)*2.;float a=(1.-smoothstep(.2,1.,d))*vA*uAlpha;if(a<.01)discard;gl_FragColor=vec4(.96,.98,1.,a);}' });
    this.pts = new THREE.Points(g, this.mat); this.pts.frustumCulled = false; this.pts.renderOrder = 5; scene.add(this.pts);
  }
  /** preset: {amount 0..1, fall, size, alpha} */
  setWeather(w) { this.pts.visible = w.amount > 0; this.pts.geometry.setDrawRange(0, Math.round(this.max * w.amount)); this.u.uFall.value = w.fall; this.u.uSize.value = w.size; this.u.uAlpha.value = w.alpha; }
  update(dt, cam, t) { this.t += dt; this.u.uTime.value = this.t; this.u.uCam.value.copy(cam.position); this.u.uWind.value.set(WIND.x * (1 + WIND.gust), WIND.z * (1 + WIND.gust)); }
}
Particles.prototype.dispose = function (scene) {
  for (const L of [this.alpha, this.add]) { scene.remove(L.points); L.points.geometry.dispose(); L.mat.dispose(); }
  for (const r of this.rings) { scene.remove(r.m); r.m.material.dispose(); } for (const L of this.lights) scene.remove(L.l);
};
