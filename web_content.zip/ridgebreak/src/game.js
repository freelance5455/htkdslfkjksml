import * as THREE from 'three';
import { WEAPONS, FACTIONS } from './weapons.js';
import { buildSoldier, buildViewmodel, buildHMG, weaponGeo } from './models.js';
import { BASES, POINT_DEFS, HMG_DEFS, terrainH, groundAt, blockedAt, resolveXZ, colliders } from './world.js';
import { Particles, Decals, Snow, COL, WIND } from './fx.js';
import { Props, Casings, Ragdolls, Debris } from './physics.js';
import { resolved } from './settings.js';
import { sfx, ambient } from './audio.js';
import { updateBot } from './bots.js';

export const TEAMS = [{ css: '#86c45a', hex: 0x5aa03c }, { css: '#d6483a', hex: 0xc93b2e }];
const CAP_R = 9, SCORE_LIMIT = 200, MATCH_TIME = 480, GRAV = 22, V3 = THREE.Vector3;
const NAMES = ['Ash', 'Birch', 'Cinder', 'Dune', 'Ember', 'Flint', 'Gale', 'Hawk', 'Iris', 'Jet', 'Kite', 'Lark', 'Moss', 'Nox', 'Oak', 'Pike', 'Quill', 'Rook', 'Sage', 'Tarn', 'Vale', 'Wren', 'Yarrow', 'Zinc', 'Brock', 'Colt', 'Dutch', 'Finn', 'Gus', 'Hank', 'Ike', 'Jack'];
export const rand = (a, b) => a + Math.random() * (b - a), clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const SPH = [[1.62, .25, true], [1.15, .42, false], [.55, .4, false]];
function rayActor(o, d, p, maxT) {
  let bt = maxT, head = false, hit = false;
  for (const [h, r, hd] of SPH) { const cx = p.x - o.x, cy = p.y + h - o.y, cz = p.z - o.z, tca = cx * d.x + cy * d.y + cz * d.z; if (tca < 0) continue; const d2 = cx * cx + cy * cy + cz * cz - tca * tca; if (d2 > r * r) continue; const t = tca - Math.sqrt(r * r - d2); if (t < bt) { bt = t; head = hd; hit = true; } }
  return hit ? { t: bt, head } : null;
}
const nadeGeo = new THREE.SphereGeometry(.14, 6, 5), nadeMat = new THREE.MeshLambertMaterial({ color: 0x3b4a2a }), boomGeo = new THREE.SphereGeometry(1, 10, 8);

export class Game {
  constructor({ scene, camera, world, settings, input, ui }) {
    Object.assign(this, { scene, camera, world, settings, input, ui }); camera.rotation.order = 'YXZ'; scene.add(camera);
    this.running = false; this.paused = false; this.t = 0; this.bots = []; this.actors = []; this.grenades = []; this.fxm = [];
    this.phys = resolved(settings); this.decals = new Decals(scene, 28); this.smokeT = 0; this.fireT = 0; this.gustAmp = .6; this.buildSystems();
    this.props = new Props(this); this.rag = new Ragdolls(this); this.botGroup = new THREE.Group(); scene.add(this.botGroup);
    this.player = { isPlayer: true, team: 0, pos: new V3(), vx: 0, vz: 0, vy: 0, onGround: true, yaw: 0, pitch: 0, hp: 100, alive: false, crouch: 0, lastHurt: -99, regenT: 0, mount: null, stam: 100, landV: 0 };
    this.facs = ['allies', 'axis']; this.diff = { acc: 1, react: 1, dmg: 1 };
    this.tr = []; this.tri = 0; for (let i = 0; i < 24; i++) { const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(6), 3)); const l = new THREE.Line(g, new THREE.LineBasicMaterial({ color: 0xffe9a0, transparent: true })); l.frustumCulled = false; l.visible = false; scene.add(l); this.tr.push(l); }
    this.buildPoints(); this.buildHmgs(); this.mapCtx = ui.minimap.getContext('2d');
    Object.assign(this, { hudT: 0, mapT: 0, scores: [0, 0], time: MATCH_TIME, stats: { kills: 0, deaths: 0, captures: 0, heads: 0 }, loadout: ['garand', 'p38'], slot: 0, ammo: {}, nades: 2, adsT: 0, kick: 0, reloading: false, reloadT: 0, fireCd: 0, fireLatch: false, flashT: 0, shake: 0, vm: null, deathT: 0, sw: { x: 0, y: 0 }, dip: 0, stepD: 0, suppress: 0, artT: 12, hmgCd: 0, boltPending: false, autoReload: false, nearHmg: null, sprinting: false });
  }
  /** (Re)build every system whose capacity depends on settings: particles, snow, debris, casings. */
  buildSystems() {
    const sc = this.scene, ph = this.phys;
    if (this.fx) { this.fx.dispose(sc); sc.remove(this.snow.pts); sc.remove(this.debris.m); sc.remove(this.casings.m); }
    this.fx = new Particles(sc, ph.particleMul, ph.dynLights); this.snow = new Snow(sc, ph.snowN, this.fx.uScale); this.debris = new Debris(this, ph.debrisN); this.casings = new Casings(sc, ph.casingN);
    this.fx.setScale(innerHeight * (this.renderScale || 1), this.camera.fov);
  }
  /** Called whenever the player changes a setting: weather, time of day, particle/physics budgets, lights. */
  applySettings() {
    const s = this.settings, ph = resolved(s), old = this.phys, rebuild = ph.particleMul !== old.particleMul || ph.debrisN !== old.debrisN || ph.casingN !== old.casingN || ph.snowN !== old.snowN;
    this.phys = ph; if (rebuild) this.buildSystems(); this.fx.setLights(ph.dynLights);
    this.env = this.world.applyEnv(s.timeOfDay, s.weather); this.snow.setWeather(this.env.snow); this.gustAmp = s.weather === 'blizzard' ? 1.7 : s.weather === 'snow' ? .6 : .3;
    return this.env;
  }
  /** Runs in menus and in matches: wind/gusts, snow, chimney smoke, particle simulation. */
  updateAmbient(dt, t, cam) {
    this.world.update(t, Math.max(0, Math.sin(t * .37) * Math.sin(t * .91)) * this.gustAmp); this.snow.update(dt, cam, t); this.fx.update(dt);
    this.smokeT -= dt; if (this.smokeT <= 0) { this.smokeT = .22 / this.fx.q; const c = cam.position;
      for (const m of this.world.smokers) { const dx = m[0] - c.x, dz = m[2] - c.z; if (dx * dx + dz * dz > 19600) continue; this.fx.emit(m[0] + rand(-.15, .15), m[1], m[2] + rand(-.15, .15), rand(-.1, .1), rand(.8, 1.5), rand(-.1, .1), rand(3, 4.5), .3, rand(1.6, 2.6), [.62, .64, .68, .5], [.72, .74, .78, 0], -.15, .4, 1, 0, 1.2, false, rand(-1, 1)); } }
  }
  /** Burning wrecks hurt anyone standing in them. */
  fireDamage(dt) {
    this.fireT -= dt; if (this.fireT > 0 || !this.fx.fires.length) return; this.fireT = .3;
    for (const f of this.fx.fires) { if (f.life - f.t < 2) continue; for (const a of this.actors) if (a.alive && Math.abs(a.pos.y - f.y) < 2 && Math.hypot(a.pos.x - f.x, a.pos.z - f.z) < 1.6 * f.s) { this.cause = 'Fire'; this.applyDamage(a, 5, null, false, new V3(0, 2, 0)); this.cause = null; } }
  }
  curId() { return this.loadout[this.slot]; } curW() { return WEAPONS[this.curId()]; }
  /** Positional sound: pan from direction relative to the camera, volume/low-pass/reverb from distance. */
  snd(name, pos, vol = 1, maxD = 180) {
    const c = this.camera.position, dx = pos.x - c.x, dz = pos.z - c.z, d = Math.hypot(dx, pos.y - c.y, dz), att = clamp(1 - d / maxD, 0, 1); if (att < .03) return;
    const yw = this.camera.rotation.y; sfx(name, { vol: vol * Math.pow(att, 1.4), pan: d > 1 ? (dx * Math.cos(yw) - dz * Math.sin(yw)) / d : 0, dist: clamp(d / maxD, 0, 1) });
  }

  // ================= CAPTURE POINTS =================
  buildPoints() {
    this.points = POINT_DEFS.map(d => {
      const y = terrainH(d.x, d.z), grp = new THREE.Group(); grp.position.set(d.x, y, d.z);
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(.1, .12, 7, 6), new THREE.MeshLambertMaterial({ color: 0xdddddd })); pole.position.y = 3.5; grp.add(pole);
      const banner = new THREE.Mesh(new THREE.BoxGeometry(2, 1.2, .06), new THREE.MeshLambertMaterial({ color: 0xcccccc })); banner.position.set(1.05, 1.2, 0); grp.add(banner);
      const ring = new THREE.Mesh(new THREE.RingGeometry(CAP_R - .5, CAP_R, 48), new THREE.MeshBasicMaterial({ color: 0xcccccc, transparent: true, opacity: .6, depthWrite: false, side: THREE.DoubleSide })); ring.rotation.x = -Math.PI / 2; ring.position.y = .2; grp.add(ring);
      const cv = document.createElement('canvas'); cv.width = cv.height = 64; const cx = cv.getContext('2d'); cx.font = 'bold 46px Impact, sans-serif'; cx.textAlign = 'center'; cx.fillStyle = '#fff'; cx.strokeStyle = '#000'; cx.lineWidth = 6; cx.strokeText(d.id, 32, 48); cx.fillText(d.id, 32, 48);
      const label = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(cv), depthWrite: false })); label.scale.set(3, 3, 1); label.position.y = 9; grp.add(label);
      this.scene.add(grp); return { ...d, y, owner: -1, progress: 0, contested: false, banner, ring };
    });
  }
  /** Capture logic: units of ONE team inside the ring push progress toward that team (+1 = player's team). Both present = contested. */
  updatePoints(dt) {
    this.points.forEach((p, i) => {
      let n0 = 0, n1 = 0; for (const a of this.actors) if (a.alive && Math.hypot(a.pos.x - p.x, a.pos.z - p.z) < CAP_R) a.team ? n1++ : n0++;
      p.contested = n0 > 0 && n1 > 0;
      if (!p.contested && (n0 || n1)) {
        const dir = n0 ? 1 : -1, n = Math.min(n0 || n1, 4), prev = p.owner; p.progress = clamp(p.progress + dir * n * .06 * dt, -1, 1);
        if (p.progress >= 1) p.owner = 0; else if (p.progress <= -1) p.owner = 1; else if ((p.owner === 0 && p.progress <= 0) || (p.owner === 1 && p.progress >= 0)) p.owner = -1;
        if (p.owner !== prev && p.owner >= 0) { this.ui.msg(`${p.owner ? 'Enemy' : 'Your team'} captured ${p.name}`, TEAMS[p.owner].css); sfx('flag', { vol: .8 }); if (p.owner === 0 && Math.hypot(this.player.pos.x - p.x, this.player.pos.z - p.z) < CAP_R) this.stats.captures++; }
      }
      const pr = p.progress; p.banner.material.color.setHex(pr > .001 ? TEAMS[0].hex : pr < -.001 ? TEAMS[1].hex : 0xcccccc); p.banner.position.y = 1.2 + 4.2 * Math.abs(pr); p.banner.rotation.y = Math.sin(this.t * 3 + i) * .12;
      p.ring.material.color.setHex(p.owner >= 0 ? TEAMS[p.owner].hex : 0xcccccc);
    });
    this.scoreT = (this.scoreT || 0) + dt; if (this.scoreT >= 1) { this.scoreT -= 1; for (const p of this.points) if (p.owner >= 0) this.scores[p.owner]++; }
  }
  spawnOptions() { return [{ id: 'base', label: 'Home base' }, ...this.points.filter(p => p.owner === 0).map(p => ({ id: p.id, label: p.name }))]; }

  // ================= M2 HMG EMPLACEMENTS =================
  buildHmgs() {
    this.hmgs = HMG_DEFS.map(h => {
      const y = terrainH(h.x, h.z), root = new THREE.Group(); root.position.set(h.x, y, h.z); const { base, gun } = buildHMG(); const yaw = Math.atan2(-(-5 - h.x), -(5 - h.z)) ; base.rotation.y = yaw; gun.rotation.y = yaw; root.add(base, gun); this.scene.add(root);
      return { x: h.x, z: h.z, y, yaw, base, gun, heat: 0, over: false };
    });
  }
  toggleMount() {
    const p = this.player; if (p.mount) { const e = p.mount; p.mount = null; p.pos.set(e.x + Math.sin(e.yaw) * 1.6, e.y, e.z + Math.cos(e.yaw) * 1.6); sfx('use'); return; }
    let best = null, bd = 9; for (const e of this.hmgs) { const d = (e.x - p.pos.x) ** 2 + (e.z - p.pos.z) ** 2; if (d < bd) { bd = d; best = e; } }
    if (best) { p.mount = best; p.yaw = best.yaw; p.pitch = 0; p.vx = p.vz = 0; sfx('use'); this.vm.visible = false; this.input.sprint = false; }
  }

  // ================= MATCH FLOW =================
  start() {
    const s = this.settings, f0 = s.faction || 'allies'; this.facs = [f0, f0 === 'allies' ? 'axis' : 'allies'];
    this.diff = [{ acc: 1.8, react: 1.5, dmg: .7 }, { acc: 1, react: 1, dmg: 1 }, { acc: .65, react: .7, dmg: 1.3 }][s.difficulty ?? 1];
    for (const b of this.bots) { if (b.model.userData.rag) this.rag.reset(b.model); this.botGroup.remove(b.model); } this.bots = [];
    this.grenades.forEach(g => this.scene.remove(g.mesh)); this.grenades = []; this.props.clear(); this.decals.clear(); this.debris.clear(); this.fx.fires.length = 0;
    for (const sp of this.world.propSpots) this.props.add(sp.type, sp.x, sp.z, Math.random() * 6.28);
    this.hmgs.forEach(h => { h.heat = 0; h.over = false; });
    this.world.baseBanners.forEach((b, i) => b.material.color.setHex(TEAMS[i].hex));
    this.scores = [0, 0]; this.time = MATCH_TIME; this.scoreT = 0; this.stats = { kills: 0, deaths: 0, captures: 0, heads: 0 }; this.t = 0; this.artT = rand(10, 20);
    this.points.forEach(p => { p.owner = -1; p.progress = 0; p.contested = false; });
    const n = s.botsPerTeam;
    for (let team = 0; team < 2; team++) for (let i = 0; i < (team === 0 ? n - 1 : n); i++) {
      const pool = FACTIONS[this.facs[team]].bots, wp = pool[(Math.random() * pool.length) | 0];
      const b = { isBot: true, team, name: NAMES[this.bots.length % NAMES.length], pos: new V3(), vx: 0, vz: 0, vy: 0, onGround: true, yaw: 0, hp: 100, alive: false, wp, model: buildSoldier(this.facs[team], wp), respawn: 0, deadT: 0, lastHurt: -99, stepD: 0 };
      this.botGroup.add(b.model); this.bots.push(b); this.spawnBot(b);
    }
    this.actors = [this.player, ...this.bots]; this.player.alive = false; this.player.mount = null; this.running = true; this.paused = false; ambient(true);
  }
  finish() {
    this.running = false; if (this.vm) this.vm.visible = false; this.camera.fov = this.settings.fov || 75; this.camera.updateProjectionMatrix(); ambient(false);
    const [a, b] = this.scores; this.ui.onEnd({ winner: a > b ? 0 : b > a ? 1 : -1, scores: this.scores.slice(), stats: { ...this.stats } });
  }
  spawnBot(b) {
    if (b.model.userData.rag) this.rag.reset(b.model);
    const own = this.points.filter(p => p.owner === b.team), at = own.length && Math.random() < .35 ? own[(Math.random() * own.length) | 0] : BASES[b.team], r = at === BASES[b.team] ? 14 : 5;
    b.pos.set(at.x + rand(-r, r), 0, at.z + rand(-r, r)); resolveXZ(b.pos, .4, 0); b.pos.y = groundAt(b.pos.x, b.pos.z); b.vx = b.vz = b.vy = 0;
    const pool = FACTIONS[this.facs[b.team]].bots; b.wp = pool[(Math.random() * pool.length) | 0]; b.model.userData.gun.geometry = weaponGeo(b.wp);
    Object.assign(b, { hp: 100, alive: true, fireCd: 1, burst: 1, react: 0, think: rand(0, .4), target: null, goalPoint: null, goalT: 0, strafe: 1, strafeT: 0, unstick: 0, unstickDir: 1, stuckN: 0, lx: b.pos.x, lz: b.pos.z, mode: 'move', coverPos: null, grenCd: rand(8, 20), deadT: 0, moving: false });
    b.yaw = Math.atan2(b.pos.x, b.pos.z); b.model.visible = true; b.model.scale.y = 1; b.model.position.copy(b.pos);
  }
  spawnPlayer(primary, spawnId) {
    const p = this.player; this.loadout = [primary, 'p38']; this.slot = 0; this.ammo = {}; for (const id of this.loadout) this.ammo[id] = { mag: WEAPONS[id].mag, reserve: WEAPONS[id].reserve };
    this.nades = 2; const pt = this.points.find(q => q.id === spawnId), at = pt || BASES[0], r = pt ? 4 : 10;
    p.pos.set(at.x + rand(-r, r), 0, at.z + rand(-r, r)); resolveXZ(p.pos, .4, 0); p.pos.y = groundAt(p.pos.x, p.pos.z);
    Object.assign(p, { hp: 100, alive: true, vx: 0, vz: 0, vy: 0, onGround: true, yaw: Math.atan2(p.pos.x, p.pos.z), pitch: 0, crouch: 0, regenT: 0, mount: null, stam: 100 });
    this.reloading = false; this.adsT = 0; this.autoReload = false; this.boltPending = false; this.input.reset(); this.setViewmodel(); this.paused = false; this.deathShown = false;
  }
  setViewmodel() { if (this.vm) this.camera.remove(this.vm); this.vm = buildViewmodel(this.curId(), this.facs[0]); this.camera.add(this.vm); this.vm.visible = !this.player.mount; }

  // ================= MAIN UPDATE =================
  update(dt) {
    if (!this.running || this.paused) return;
    this.t += dt; this.time -= dt; this.input.poll(); this.updatePlayer(dt);
    for (const b of this.bots) updateBot(this, b, dt);
    this.updatePoints(dt); this.updateGrenades(dt); this.props.update(dt); this.debris.update(dt); this.casings.update(dt); this.rag.update(dt); this.updateAmbient(dt, this.t, this.camera); this.fireDamage(dt);
    for (let i = this.fxm.length - 1; i >= 0; i--) { const f = this.fxm[i]; f.t += dt; f.m.scale.setScalar(f.s * (.4 + f.t * 6)); f.m.material.opacity = Math.max(0, .9 - f.t * 2.5); if (f.t > .4) { this.scene.remove(f.m); f.m.material.dispose(); this.fxm.splice(i, 1); } }
    for (const l of this.tr) if (l.visible) { l.ttl -= dt; l.material.opacity = Math.max(0, l.ttl / .08); if (l.ttl <= 0) l.visible = false; }
    this.suppress = Math.max(0, this.suppress - dt * 1.2); this.shake = Math.max(0, this.shake - dt * 1.5); this.dip *= Math.exp(-8 * dt);
    this.artT -= dt; if (this.artT <= 0) { this.artT = rand(14, 30); const a = rand(0, 6.28), r = rand(90, 150), pp = new V3(this.player.pos.x + Math.cos(a) * r, 0, this.player.pos.z + Math.sin(a) * r); pp.x = clamp(pp.x, -130, 130); pp.z = clamp(pp.z, -130, 130); pp.y = terrainH(pp.x, pp.z); this.fx.blast(pp.x, pp.y + 1, pp.z, 1.6); this.snd('boom', pp, .9, 400); const d = pp.distanceTo(this.player.pos); if (d < 120) this.shake = Math.max(this.shake, .35); }
    this.hudT -= dt; if (this.hudT <= 0) { this.hudT = .1; this.updateHud(); } this.mapT -= dt; if (this.mapT <= 0) { this.mapT = .125; this.drawMap(); }
    const pp = this.player.pos; const so = this.world.sunOffset; this.world.sun.position.set(pp.x + so.x, so.y, pp.z + so.z); this.world.sun.target.position.set(pp.x, 0, pp.z);
    if (this.time <= 0 || this.scores[0] >= SCORE_LIMIT || this.scores[1] >= SCORE_LIMIT) this.finish();
  }

  // ================= PLAYER CONTROLLER =================
  updatePlayer(dt) {
    const p = this.player, inp = this.input, cam = this.camera, look = inp.consumeLook();
    if (!p.alive) { // death cam: collapse to the ground, then offer the loadout screen
      this.deathT -= dt; p.pitch += (-.9 - p.pitch) * Math.min(1, dt * 3); cam.position.set(p.pos.x, p.pos.y + .35, p.pos.z); cam.rotation.set(p.pitch, p.yaw, .3);
      if (this.vm) this.vm.visible = false; if (this.deathT <= 0 && !this.deathShown) { this.deathShown = true; this.ui.showLoadout(); } return;
    }
    if (inp.take('use')) this.toggleMount();
    // find a nearby HMG for the HUD prompt
    this.nearHmg = null; if (!p.mount) for (const e of this.hmgs) if ((e.x - p.pos.x) ** 2 + (e.z - p.pos.z) ** 2 < 9) this.nearHmg = e;
    if (p.mount) return this.updateMounted(dt, look);
    this.vm.visible = true; const w = this.curW(), a = this.ammo[this.curId()];
    const iy = this.settings.invertY ? -1 : 1; p.yaw -= look.dx * (1 - .5 * this.adsT); p.pitch = clamp(p.pitch - iy * look.dy * (1 - .5 * this.adsT), -1.45, 1.45);
    this.sw.x += (clamp(look.dx * 9, -.12, .12) - this.sw.x) * Math.min(1, dt * 10); this.sw.y += (clamp(look.dy * 9, -.12, .12) - this.sw.y) * Math.min(1, dt * 10);
    if (inp.take('swap')) { this.slot ^= 1; this.reloading = false; this.boltPending = false; this.setViewmodel(); sfx('reload'); }
    if (inp.take('reload')) this.startReload(); if (inp.take('grenade')) this.throwGrenade();
    if (this.reloading) { this.reloadT -= dt; if (this.reloadT <= 0) this.finishReload(); }
    this.fireCd -= dt; if (this.autoReload && this.fireCd <= 0) { this.autoReload = false; this.startReload(); }
    if (this.boltPending && this.fireCd < 60 / w.rpm * .5) { this.boltPending = false; sfx('bolt'); this.kick = -.6; }
    // movement: inertia + stamina based sprint
    const mx = inp.moveX, mz = inp.moveY, moving = Math.hypot(mx, mz) > .1;
    this.sprinting = inp.sprint && mz > .3 && !inp.fire && !inp.ads && p.crouch < .5 && p.stam > 3 && p.onGround;
    p.stam = clamp(p.stam + (this.sprinting ? -20 : 14) * dt, 0, 100); if (p.stam <= 0.5) inp.sprint = false;
    this.adsT += ((inp.ads && !this.sprinting && !this.reloading ? 1 : 0) - this.adsT) * Math.min(1, dt * 12);
    p.crouch += ((inp.crouch ? 1 : 0) - p.crouch) * Math.min(1, dt * 10);
    const speed = 4.6 * (this.sprinting ? 1.55 : 1) * (1 - .5 * p.crouch) * (1 - .4 * this.adsT), s = Math.sin(p.yaw), c = Math.cos(p.yaw), k = Math.min(1, dt * (p.onGround ? 9 : 2));
    p.vx += ((-s * mz + c * mx) * speed - p.vx) * k; p.vz += ((-c * mz - s * mx) * speed - p.vz) * k;
    if (inp.take('jump') && p.onGround) { p.vy = 7.4; p.onGround = false; p.stam = Math.max(0, p.stam - 8); }
    this.moveActor(p, p.vx * dt, p.vz * dt, dt);
    if (p.landV) { if (p.landV > 6) { sfx('land', { vol: Math.min(1, p.landV / 12) }); this.dip = Math.min(.3, p.landV * .02); } p.landV = 0; }
    const sp = Math.hypot(p.vx, p.vz); if (p.onGround && sp > 1) { this.stepD += sp * dt; if (this.stepD > (this.sprinting ? 2.2 : 1.7)) { this.stepD = 0; sfx('step', { vol: p.crouch > .5 ? .3 : this.sprinting ? .9 : .6 }); } }
    if (inp.fire) { if (w.auto || !this.fireLatch) { this.fireLatch = true; this.playerFire(); } } else this.fireLatch = false;
    p.regenT -= dt; if (p.regenT <= 0 && p.hp < 100) p.hp = Math.min(100, p.hp + 7 * dt);
    // camera
    const eye = 1.65 - .55 * p.crouch - this.dip, bobT = this.t * (this.sprinting ? 12 : 8), bob = p.onGround ? Math.sin(bobT) * .025 * Math.min(1, sp / 4) * (this.settings.bob ?? 1) : 0, sh = this.shake * (this.settings.shake ?? 1);
    cam.position.set(p.pos.x, p.pos.y + eye + bob, p.pos.z);
    cam.rotation.set(p.pitch + (Math.random() - .5) * sh * .05, p.yaw + (Math.random() - .5) * sh * .05, Math.cos(bobT * .5) * .004 * Math.min(1, sp / 4) + (this.sprinting ? Math.sin(bobT * .5) * .01 : 0));
    const fov = (this.settings.fov || 75) / (1 + (w.zoom - 1) * this.adsT) + (this.sprinting ? 4 : 0); if (Math.abs(fov - cam.fov) > .05) { cam.fov = fov; cam.updateProjectionMatrix(); this.fx.setScale(innerHeight * (this.renderScale || 1), fov); }
    // viewmodel: hip<->ADS pose, bob, recoil kick, reload dip, sway, sprint tilt
    const k2 = this.adsT, vb = Math.sin(bobT) * .012 * Math.min(1, sp / 4) * (1 - k2), dip = this.reloading ? .2 * Math.sin(Math.PI * (1 - this.reloadT / w.reload)) : 0;
    this.kick = this.kick > 0 ? Math.max(0, this.kick - dt * 9) : Math.min(0, this.kick + dt * 5);
    this.vm.position.set(.2 * (1 - k2) + vb - this.sw.x * .3, -.23 * (1 - k2) - .105 * k2 + Math.abs(vb) - dip + this.sw.y * .3 - (this.sprinting ? .05 : 0), -.46 + .1 * k2 + this.kick * .06);
    this.vm.rotation.set(this.kick * .09 + (this.sprinting ? .3 : 0) + dip * 1.2 + this.sw.y * .5, (this.sprinting ? .45 : 0) + this.sw.x * .5, this.kick * .02 + (this.sprinting ? -.15 : 0));
    this.flashT -= dt; this.vm.userData.flash.visible = this.flashT > 0; if (this.flashT > 0) this.vm.userData.flash.rotation.z = Math.random() * 6;
  }
  updateMounted(dt, look) {
    const p = this.player, e = p.mount, cam = this.camera, rel = (a => { while (a > Math.PI) a -= 6.283; while (a < -Math.PI) a += 6.283; return a; })(p.yaw - e.yaw - look.dx * .7);
    p.yaw = e.yaw + clamp(rel, -1.0, 1.0); p.pitch = clamp(p.pitch - (this.settings.invertY ? -1 : 1) * look.dy * .7, -.35, .45);
    p.pos.set(e.x + Math.sin(e.yaw) * 1.2, e.y, e.z + Math.cos(e.yaw) * 1.2); e.gun.rotation.set(p.pitch, p.yaw, 0, 'YXZ');
    this.hmgCd -= dt; e.heat = Math.max(0, e.heat - (e.over ? 14 : 22) * dt); if (e.over && e.heat < 35) e.over = false;
    const sh = this.shake * (this.settings.shake ?? 1); cam.position.set(e.x + Math.sin(p.yaw) * 1.1, e.y + 1.75, e.z + Math.cos(p.yaw) * 1.1); cam.rotation.set(p.pitch + (Math.random() - .5) * sh * .06, p.yaw + (Math.random() - .5) * sh * .06, 0);
    const mf = Math.round((this.settings.fov || 75) * .83); if (Math.abs(cam.fov - mf) > .1) { cam.fov = mf; cam.updateProjectionMatrix(); this.fx.setScale(innerHeight * (this.renderScale || 1), mf); }
    if (this.input.fire && this.hmgCd <= 0 && !e.over) {
      this.hmgCd = 60 / 540; e.heat += 6.5; if (e.heat >= 100) { e.over = true; this.ui.msg('M2 overheated', '#e8a23a'); }
      const cp = Math.cos(p.pitch), sp = .008 + e.heat * .0004, d = new V3(-Math.sin(p.yaw) * cp + (Math.random() - .5) * sp * 2, Math.sin(p.pitch) + (Math.random() - .5) * sp * 2, -Math.cos(p.yaw) * cp + (Math.random() - .5) * sp * 2).normalize();
      const r = this.hitscan(cam.position, d, 260, p), end = cam.position.clone().addScaledVector(d, r.t), mz = e.gun.localToWorld(new V3(0, .02, -1.25));
      this.tracer(mz, end); this.resolveHit(p, r, d, end, 38, true, 'M2 Browning'); sfx('m2', { vol: 1 }); this.shake = Math.max(this.shake, .25); p.pitch += .004; this.fx.muzzle(mz.x, mz.y, mz.z, d.x * .5, d.y * .5, d.z * .5); this.fx.emit(mz.x, mz.y, mz.z, 0, 0, 0, .05, .7, .2, COL.spark, COL.spark2);
      if (Math.random() < .5) this.casings.eject(e.gun.localToWorld(new V3(.12, .0, -.1)), new V3(Math.cos(p.yaw), 0, -Math.sin(p.yaw)), new V3(0, 1, 0));
    }
  }
  /** Shared physics for player and bots: slide against colliders, gravity, step onto low cover, snap down slopes, fall damage. */
  moveActor(a, dx, dz, dt) {
    const was = a.onGround; a.pos.x += dx; a.pos.z += dz; resolveXZ(a.pos, .4, a.pos.y); a.vy -= GRAV * dt; const vy0 = a.vy; a.pos.y += a.vy * dt; const g = groundAt(a.pos.x, a.pos.z, a.pos.y);
    if (a.pos.y <= g || (was && a.vy <= 0 && a.pos.y - g < .5)) { a.pos.y = g; a.vy = 0; a.onGround = true; if (!was && vy0 < -6) { a.landV = -vy0; if (-vy0 > 13) this.applyDamage(a, (-vy0 - 13) * 8, null, false, new V3()); } } else a.onGround = false;
  }

  // ================= WEAPONS =================
  playerFire() {
    const p = this.player, w = this.curW(), a = this.ammo[this.curId()], cam = this.camera;
    if (this.reloading || this.fireCd > 0 || this.sprinting) return;
    if (a.mag <= 0) { sfx('empty'); this.fireCd = .3; if (a.reserve > 0) this.startReload(); return; }
    a.mag--; this.fireCd = 60 / w.rpm;
    const sp = (this.adsT > .5 ? w.adsSpread : w.spread) * (p.crouch > .5 ? .7 : 1) * (p.onGround ? 1 : 2.5) * (1 + Math.hypot(p.vx, p.vz) * .08), cp = Math.cos(p.pitch);
    const d = new V3(-Math.sin(p.yaw) * cp + (Math.random() - .5) * 2 * sp, Math.sin(p.pitch) + (Math.random() - .5) * 2 * sp, -Math.cos(p.yaw) * cp + (Math.random() - .5) * 2 * sp).normalize();
    const r = this.hitscan(cam.position, d, w.range, p), end = cam.position.clone().addScaledVector(d, r.t), mz = cam.localToWorld(new V3(.14, -.12, -1));
    this.tracer(mz, end); this.resolveHit(p, r, d, end, w.dmg * Math.max(.5, 1 - r.t / (w.range * 1.5)), true, w.name);
    this.kick = 1; p.pitch += w.recoil * (1 - .4 * this.adsT) * (.7 + Math.random() * .6); p.yaw += (Math.random() - .5) * w.recoil * .6; this.shake = Math.max(this.shake, w.recoil * 9);
    sfx(w.sfx); this.flashT = .05; this.fx.muzzle(mz.x, mz.y, mz.z, d.x * .3, d.y * .3, d.z * .3);
    if (w.eject && !w.bolt) this.casings.eject(cam.localToWorld(new V3(.12, -.06, -.45)), new V3(Math.cos(p.yaw), 0, -Math.sin(p.yaw)), new V3(0, 1, 0));
    if (w.bolt) { this.boltPending = true; this.casings.eject(cam.localToWorld(new V3(.12, -.06, -.3)), new V3(Math.cos(p.yaw), 0, -Math.sin(p.yaw)), new V3(0, 1, 0)); }
    if (w.ping && a.mag === 0) setTimeout(() => sfx('ping', { vol: .8 }), 100);
    if (a.mag === 0 && a.reserve > 0) this.autoReload = true;
  }
  startReload() { const w = this.curW(), a = this.ammo[this.curId()]; if (this.reloading || !a || a.mag === w.mag || a.reserve <= 0 || !this.player.alive || this.player.mount) return; this.reloading = true; this.reloadT = w.reload; sfx('reload'); setTimeout(() => sfx('magin'), w.reload * 700); }
  finishReload() { const w = this.curW(), a = this.ammo[this.curId()], take = Math.min(w.mag - a.mag, a.reserve); a.mag += take; a.reserve -= take; this.reloading = false; if (w.bolt) sfx('bolt'); }
  throwGrenade() {
    const p = this.player; if (this.nades <= 0 || !p.alive || p.mount) return; this.nades--; sfx('pin'); const cp = Math.cos(p.pitch), f = new V3(-Math.sin(p.yaw) * cp, Math.sin(p.pitch), -Math.cos(p.yaw) * cp);
    this.spawnGrenade(this.camera.position.clone().addScaledVector(f, .6), f.multiplyScalar(17).add(new V3(p.vx * .5, 4.5, p.vz * .5)), p);
  }
  /** Hitscan: march in 1 m steps to the wall distance, then test enemy hit spheres (head/chest/legs) and physics props in front of it. */
  hitscan(o, d, range, shooter) {
    let tw = range; for (let t = 1; t < range; t += 1) if (blockedAt(o.x + d.x * t, o.y + d.y * t, o.z + d.z * t)) { tw = t; break; }
    let bt = tw, hit = null;
    for (const a of this.actors) { if (!a.alive || a.team === shooter.team) continue; const r = rayActor(o, d, a.pos, bt); if (r) { bt = r.t; hit = { actor: a, head: r.head }; } }
    for (const pr of this.props.list) { const cx = pr.pos.x - o.x, cy = pr.c.y - o.y, cz = pr.pos.z - o.z, tca = cx * d.x + cy * d.y + cz * d.z; if (tca < 0 || tca > bt) continue; const d2 = cx * cx + cy * cy + cz * cz - tca * tca, rr = Math.max(pr.rad, pr.h * .5) * .9; if (d2 < rr * rr) { const t = tca - Math.sqrt(rr * rr - d2); if (t < bt) { bt = Math.max(0, t); hit = { prop: pr }; } } }
    return { t: bt, hit };
  }
  los(ax, ay, az, bx, by, bz) { const dx = bx - ax, dy = by - ay, dz = bz - az, n = Math.ceil(Math.hypot(dx, dy, dz) / 1.5); for (let i = 1; i < n; i++) { const f = i / n; if (blockedAt(ax + dx * f, ay + dy * f, az + dz * f)) return false; } return true; }
  tracer(a, b) { const l = this.tr[this.tri++ % 24], p = l.geometry.attributes.position; p.setXYZ(0, a.x, a.y, a.z); p.setXYZ(1, b.x, b.y, b.z); p.needsUpdate = true; l.ttl = .08; l.visible = true; l.material.opacity = 1; }
  /** Apply the result of a shot: actor damage (+ragdoll impulse), prop damage/impulse, or a surface impact puff. */
  resolveHit(shooter, r, d, end, dmg, loud, wname) {
    const h = r.hit;
    if (h && h.actor) { const head = h.head, imp = d.clone().multiplyScalar(3 + dmg * .06); imp.y += head ? 2.5 : 1; this.cause = wname; this.applyDamage(h.actor, dmg * (head ? 2 : 1), shooter, head, imp); this.cause = null; if (shooter.isPlayer) { this.ui.hit(head); sfx(head ? 'headshot' : 'hit'); } this.fx.puff(end.x, end.y, end.z, COL.dust, 2, 1.2); }
    else if (h && h.prop) { this.props.damage(h.prop, dmg, shooter); if (this.props.list.includes(h.prop)) this.props.hit(h.prop, d, end, dmg); this.fx.impact(end.x, end.y, end.z, h.prop.type === 'crate' ? 'wood' : 'metal', -d.x * .4, .5, -d.z * .4); if (shooter.isPlayer) this.ui.hit(false); }
    else if (loud || end.distanceTo(this.camera.position) < 80) { const snowy = end.y < terrainH(end.x, end.z) + .6; this.fx.impact(end.x, end.y, end.z, snowy ? 'snow' : 'stone', -d.x * .4, snowy ? 1 : .5, -d.z * .4); if (snowy && this.phys.physics !== 'light' && Math.random() < .4) this.debris.burst(end, 'snow', 2, 2.5); }
  }
  applyDamage(t, dmg, by, head, imp) {
    if (!t.alive) return; t.hp -= dmg; t.lastHurt = this.t;
    if (t.isPlayer) { t.regenT = 5; let ang = 0; if (by && by.pos) { const vx = by.pos.x - t.pos.x, vz = by.pos.z - t.pos.z; ang = Math.atan2(vx * Math.cos(t.yaw) - vz * Math.sin(t.yaw), -vx * Math.sin(t.yaw) - vz * Math.cos(t.yaw)); } this.ui.damage(ang); sfx('hurt'); this.shake = Math.max(this.shake, .5); }
    else if (by && by.isPlayer && !t.target) t.react = Math.min(t.react, .2);
    if (t.hp <= 0) this.kill(t, by, head, imp);
  }
  kill(t, by, head, imp) {
    t.alive = false; t.hp = 0; imp = imp || new V3(0, 2, 0);
    if (t.isPlayer) { this.stats.deaths++; this.deathT = 3; t.mount = null; this.input.reset(); } else { t.respawn = 6 + Math.random() * 3; t.deadT = 0; this.rag.start(t.model, imp); }
    if (by && by.isPlayer && !t.isPlayer) { this.stats.kills++; if (head) this.stats.heads++; }
    const nm = x => x ? (x.isPlayer ? 'You' : x.name) : 'Accident', col = x => x ? TEAMS[x.team].css : '#fff', wn = this.cause || (by ? (by.isPlayer ? this.curW().name : by.wp ? WEAPONS[by.wp].name : '') : 'Fall');
    this.ui.feed(`<span style="color:${col(by)}">${nm(by)}</span> <i>${wn}${head ? ' ◎' : ''}</i> <span style="color:${col(t)}">${nm(t)}</span>`);
  }

  // ================= GRENADES & EXPLOSIONS =================
  spawnGrenade(pos, vel, owner) { const mesh = new THREE.Mesh(nadeGeo, nadeMat); mesh.position.copy(pos); this.scene.add(mesh); this.grenades.push({ mesh, pos: pos.clone(), vel, fuse: 2.8, owner }); }
  updateGrenades(dt) {
    for (let i = this.grenades.length - 1; i >= 0; i--) {
      const g = this.grenades[i], p = g.pos, v = g.vel; g.fuse -= dt; v.y -= GRAV * dt; const nx = p.x + v.x * dt, nz = p.z + v.z * dt;
      if (blockedAt(nx, p.y, p.z)) { v.x *= -.4; this.snd('thud', p, .4, 40); } else p.x = nx; if (blockedAt(p.x, p.y, nz)) v.z *= -.4; else p.z = nz;
      p.y += v.y * dt; const gy = groundAt(p.x, p.z, p.y) + .14; if (p.y < gy) { p.y = gy; if (v.y < -2) { v.y *= -.38; this.snd('thud', p, .4, 40); } else v.y = 0; v.x *= .65; v.z *= .65; }
      for (const pr of this.props.list) { const dx = p.x - pr.c.x, dz = p.z - pr.c.z, rr = pr.rad + .14; if (dx * dx + dz * dz < rr * rr && Math.abs(p.y - pr.c.y) < pr.h / 2 + .1) { const dd = Math.hypot(dx, dz) || .01, nx = dx / dd, nz = dz / dd, vn = v.x * nx + v.z * nz; if (vn < 0) { this.props.push(pr, new V3(nx * vn * .5, 0, nz * vn * .5), p); v.x -= 1.5 * vn * nx; v.z -= 1.5 * vn * nz; v.multiplyScalar(.6); this.snd('thud', p, .5, 40); } p.x = pr.c.x + nx * rr; p.z = pr.c.z + nz * rr; } }
      g.mesh.position.copy(p); g.mesh.rotation.x += dt * 8; g.mesh.rotation.z += dt * 5; this.fx.emit(p.x, p.y, p.z, 0, .2, 0, .5, .12, .25, COL.gun, COL.gun2);
      if (g.fuse <= 0) { this.explosion(p, g.owner, 8, 140); this.scene.remove(g.mesh); this.grenades.splice(i, 1); }
    }
  }
  /** Explosion: fireball/smoke/debris FX, crater decal, falloff damage with line-of-sight, knockback on soldiers, impulses + damage on props. */
  explosion(pos, owner, R = 8, maxDmg = 140) {
    this.fx.blast(pos.x, pos.y, pos.z, R / 8); this.decals.add(pos.x, pos.z, R * .4); const m = new THREE.Mesh(boomGeo, new THREE.MeshBasicMaterial({ color: 0xffb040, transparent: true })); m.position.copy(pos); this.scene.add(m); this.fxm.push({ m, t: 0, s: R * .35 });
    this.snd('boom', pos, 1.5, 320); const dc = pos.distanceTo(this.camera.position); if (dc < 22) this.shake = Math.max(this.shake, 1 - dc / 22); if (dc < 9) sfx('ring', { vol: .9 });
    const hv = this.phys.physics === 'light' ? .5 : this.phys.physics === 'extreme' ? 1.8 : 1; this.debris.burst(pos, 'earth', Math.round(12 * hv * R / 8), 9 * R / 8); this.debris.burst(pos, 'snow', Math.round(10 * hv * R / 8), 7 * R / 8); this.debris.burst(pos, 'shrap', Math.round(8 * hv), 16); this.debris.blast(pos, R * 1.5, 14); this.rag.impulse(pos, R * 1.6, 24 * hv);
    this.cause = owner && owner.isPlayer ? 'Explosion' : 'Grenade';
    for (const a of [...this.actors]) {
      if (!a.alive || (owner && a.team === owner.team && a !== owner)) continue; const ctr = new V3(a.pos.x, a.pos.y + 1, a.pos.z), d = ctr.distanceTo(pos); if (d > R || !this.los(pos.x, pos.y + .4, pos.z, ctr.x, ctr.y, ctr.z)) continue;
      const k = 1 - d / R, dir = ctr.sub(pos).normalize(); a.vx += dir.x * k * 12; a.vz += dir.z * k * 12; a.vy = Math.max(a.vy, k * 8); a.onGround = false;
      this.applyDamage(a, maxDmg * k, owner, false, new V3(dir.x * (4 + 14 * k), 4 + 8 * k, dir.z * (4 + 14 * k)));
    }
    this.cause = null; this.props.impulse(pos, R * 1.4, 18 * hv, owner); this.props.damageArea(pos, R, maxDmg, owner);
  }

  // ================= HUD =================
  updateHud() {
    const p = this.player, w = this.curW(), a = this.ammo[this.curId()] || { mag: 0, reserve: 0 }, m = Math.max(0, Math.ceil(this.time)), e = p.mount;
    this.ui.hud({ time: `${(m / 60) | 0}:${String(m % 60).padStart(2, '0')}`, s0: this.scores[0], s1: this.scores[1], hp: Math.ceil(p.hp), ammo: e ? `HEAT ${Math.round(e.heat)}%` : this.reloading ? 'reloading…' : `${a.mag} / ${a.reserve}`, wname: e ? 'M2 Browning HMG' : w.name, nades: `${FACTIONS[this.facs[0]].nade} ×${this.nades}`, stam: p.stam, heat: e ? e.heat : -1, prompt: this.nearHmg ? 'Man the M2 Browning' : null, supp: this.suppress });
    this.points.forEach((q, i) => this.ui.chip(i, q.id, q.owner, q.progress, q.contested));
  }
  drawMap() {
    const c = this.mapCtx, W = 128, S = W / 290, X = x => W / 2 + x * S, Z = z => W / 2 + z * S, p = this.player; c.clearRect(0, 0, W, W);
    for (const q of this.points) { c.fillStyle = q.owner < 0 ? '#aab' : TEAMS[q.owner].css; c.beginPath(); c.arc(X(q.x), Z(q.z), 6, 0, 6.283); c.fill(); c.fillStyle = '#000'; c.font = 'bold 9px sans-serif'; c.textAlign = 'center'; c.fillText(q.id, X(q.x), Z(q.z) + 3); }
    c.fillStyle = '#e8c04a'; for (const h of this.hmgs) c.fillRect(X(h.x) - 2, Z(h.z) - 2, 4, 4);
    for (const b of this.bots) if (b.alive && (b.team === 0 || Math.hypot(b.pos.x - p.pos.x, b.pos.z - p.pos.z) < 50)) { c.fillStyle = TEAMS[b.team].css; c.fillRect(X(b.pos.x) - 1.5, Z(b.pos.z) - 1.5, 3, 3); }
    if (p.alive) { c.save(); c.translate(X(p.pos.x), Z(p.pos.z)); c.rotate(-p.yaw); c.fillStyle = '#fff'; c.beginPath(); c.moveTo(0, -5); c.lineTo(3.5, 4); c.lineTo(-3.5, 4); c.fill(); c.restore(); }
  }
}
