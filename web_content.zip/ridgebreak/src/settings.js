// Persistent settings in localStorage (offline-safe, wrapped in try/catch for restricted WebViews).
const KEY = 'ridgebreak.settings.v3';
export const defaults = {
  // controls
  sens: 1, invertY: false, fov: 75, bob: 1, shake: 1,
  // audio
  volume: .8, music: .5,
  // graphics
  quality: 'medium', resScale: 1, shadows: 'auto', bloom: 'auto', dynLights: 'auto', particles: 'auto', weather: 'snow', timeOfDay: 'day', brightness: 1, vignette: true, fps: false,
  // physics
  physics: 'high', debris: 'auto', ragdoll: 'auto',
  // match
  botsPerTeam: 8, difficulty: 1, faction: 'allies', primary: 'garand',
};
export function loadSettings() {
  try {
    const old = JSON.parse(localStorage.getItem('ridgebreak.settings.v2') || '{}'), cur = JSON.parse(localStorage.getItem(KEY) || '{}');
    return { ...defaults, ...old, ...cur };
  } catch { return { ...defaults }; }
}
export function saveSettings(s) { try { localStorage.setItem(KEY, JSON.stringify(s)); } catch { /* ignore */ } }

/** Resolve 'auto' options from the quality preset so every system reads one concrete value. */
export function resolved(s) {
  const q = s.quality, pick = (v, lo, md, hi) => v === 'auto' ? ({ low: lo, medium: md, high: hi }[q] ?? md) : v;
  const phys = s.physics || 'high';
  return {
    shadows: pick(s.shadows, 'off', 'off', 'on') === 'on',
    bloom: pick(s.bloom, 'off', 'off', 'on') === 'on',
    dynLights: pick(s.dynLights, 'off', 'on', 'on') === 'on',
    particleMul: { low: .4, medium: 1, high: 2, ultra: 3 }[pick(s.particles, 'low', 'medium', 'high')] ?? 1,
    debrisN: { off: 0, low: 60, medium: 160, high: 320 }[pick(s.debris, 'low', 'medium', 'high')] ?? 160,
    casingN: { off: 0, low: 30, medium: 80, high: 160 }[pick(s.debris, 'low', 'medium', 'high')] ?? 80,
    ragdoll: pick(s.ragdoll, 'simple', 'full', 'full'),
    physics: phys, // 'light' | 'normal' | 'high' | 'extreme'
    physIter: { light: 1, normal: 2, high: 3, extreme: 5 }[phys] ?? 3,
    snowN: { low: 500, medium: 1400, high: 2800 }[q] ?? 1400,
  };
}
