import * as THREE from 'three';
import { groundAt, terrainH, resolveXZ } from './world.js';
import { propGeo, vcMat } from './models.js';
import { COL } from './fx.js';
// ---- PHYSICS: self-contained rigid bodies (props), verlet ragdolls, instanced debris and shell casings. No engine needed. ----
const V3 = THREE.Vector3, Q = THREE.Quaternion, G = 22, rnd = a => (Math.random() - .5) * 2 * a, R = Math.random;
const _a = new V3(), _b = new V3(), _c = new V3(), _n = new V3(), _r = new V3(), _vp = new V3(), _rn = new V3(), _dq = new Q(), _m4 = new THREE.Matrix4(), _tmp = new V3();

// type -> collision shape. cyl: radius r, height h.  box: half extents hx (x/z) and hy (y).
const PD = {
  fuel: { r: .45, h: .95, hp: 20, mass: 1, shape: 'cyl', mu: .45 }, drum: { r: .45, h: .95, hp: 60, mass: 1.3, shape: 'cyl', mu: .45 }, crate: { r: .62, h: .9, hp: 90, mass: 2.2, shape: 'box', hx: .52, hy: .45, mu: .75 },
};
function localPoints(d) {
  const pts = [];
  if (d.shape === 'cyl') { for (const y of [-d.h / 2, d.h / 2]) { pts.push(new V3(0, y, 0)); for (let k = 0; k < 8; k++) { const a = k / 8 * 6.283; pts.push(new V3(Math.cos(a) * d.r, y, Math.sin(a) * d.r)); } } }
  else for (const sx of [-1, 1]) for (const sy of [-1, 1]) for (const sz of [-1, 1]) pts.push(new V3(sx * d.hx, sy * d.hy, sz * d.hx));
  return pts;
}
const PTS = { fuel: localPoints(PD.fuel), drum: localPoints(PD.drum), crate: localPoints(PD.crate) };
const terrainNormal = (x, z, out) => { const e = .6; return out.set(terrainH(x - e, z) - terrainH(x + e, z), 2 * e, terrainH(x, z - e) - terrainH(x, z + e)).normalize(); };

/** Two-body (or body vs static when b is null) impulse at contact point. Isotropic inertia: dω = r × J / I. */
function solveContact(a, b, n, pa, pb, e, mu) {
  _r.subVectors(pa, a.c); _vp.crossVectors(a.w, _r).add(a.v);
  let rb = null; if (b) { rb = _b.subVectors(pb, b.c); _vp.sub(_c.crossVectors(b.w, rb).add(b.v)); }
  const vn = _vp.dot(n); if (vn >= 0) return 0;
  _rn.crossVectors(_r, n); let den = a.invM + _rn.lengthSq() / a.I; let rbn = null; if (b) { rbn = new V3().crossVectors(rb, n); den += b.invM + rbn.lengthSq() / b.I; }
  const j = -(1 + e) * vn / den; a.v.addScaledVector(n, j * a.invM); a.w.addScaledVector(_rn, j / a.I); if (b) { b.v.addScaledVector(n, -j * b.invM); b.w.addScaledVector(rbn, -j / b.I); }
  // Coulomb friction along the tangent
  const vt = _tmp.copy(_vp).addScaledVector(n, -vn), tl = vt.length(); if (tl > 1e-4) {
    vt.multiplyScalar(1 / tl); const rt = new V3().crossVectors(_r, vt); let dt = a.invM + rt.lengthSq() / a.I, rbt = null; if (b) { rbt = new V3().crossVectors(rb, vt); dt += b.invM + rbt.lengthSq() / b.I; }
    const jt = Math.min(tl / dt, mu * j); a.v.addScaledVector(vt, -jt * a.invM); a.w.addScaledVector(rt, -jt / a.I); if (b) { b.v.addScaledVector(vt, jt * b.invM); b.w.addScaledVector(rbt, jt / b.I); }
  }
  return j;
}

export class Props {
  constructor(game) { this.g = game; this.list = []; this.lp = new V3(); this.carry = 0; }
  clear() { for (const p of this.list) this.g.scene.remove(p.mesh); this.list = []; }
  add(type, x, z, yaw = 0) {
    const d = PD[type], mesh = new THREE.Mesh(propGeo(type), vcMat); mesh.castShadow = true; this.g.scene.add(mesh);
    const m = d.mass, I = d.shape === 'cyl' ? m * (3 * d.r * d.r + d.h * d.h) / 12 * 1.3 : m * (d.hx * d.hx + d.hy * d.hy) / 3 * 1.3;
    const p = { type, mesh, ...d, rad: d.shape === 'cyl' ? d.r : d.hx * 1.15, c: new V3(x, groundAt(x, z) + d.h / 2, z), v: new V3(), w: new V3(), q: new Q().setFromAxisAngle(new V3(0, 1, 0), yaw), invM: 1 / m, I, asleep: true, still: 0, hp0: d.hp, explosive: type === 'fuel', burning: false, by: null, cd: 0, air: false };
    p.pos = new V3(); this.sync(p); this.list.push(p);
  }
  sync(p) { _c.set(0, p.h / 2, 0).applyQuaternion(p.q); p.mesh.position.copy(p.c).sub(_c); p.mesh.quaternion.copy(p.q); p.pos.set(p.c.x, p.c.y - p.h / 2, p.c.z); }
  center(p, o) { return o.copy(p.c); }
  /** Apply a linear impulse J (momentum units) at a world point: changes velocity AND spin. */
  push(p, J, at) { p.v.addScaledVector(J, p.invM); if (at) { _r.subVectors(at, p.c); p.w.addScaledVector(_c.crossVectors(_r, J), 1 / p.I); } p.asleep = false; p.still = 0; }
  update(dt) {
    const sub = this.g.phys.physIter > 2 ? 2 : 1, h = dt / sub, list = this.list;
    for (const p of list) {
      if (p.cd > 0) p.cd -= dt;
      if (p.burning) this.burn(p, dt);
      // actors shove props; fast props hurt actors
      for (const a of this.g.actors) {
        if (!a.alive) continue; const dx = p.c.x - a.pos.x, dz = p.c.z - a.pos.z, rr = p.rad + .4, d2 = dx * dx + dz * dz; if (d2 > rr * rr || Math.abs(a.pos.y + .9 - p.c.y) > p.h / 2 + .9) continue;
        const d = Math.sqrt(d2) || .01, nx = dx / d, nz = dz / d, sp = a.vx * nx + a.vz * nz, spd = p.v.length();
        if (sp > .2) { _n.set(nx * sp * .8, 0, nz * sp * .8); this.push(p, _n, _a.set(a.pos.x, a.pos.y + .9, a.pos.z)); }
        if (d < rr * .75) { p.c.x += nx * (rr - d) * .5; p.c.z += nz * (rr - d) * .5; }
        if (spd > 7 && p.cd <= 0 && this.g.phys.physics !== 'light') { p.cd = .6; const dmg = (spd - 6) * 7 * p.mass; this.g.cause = 'Crushed'; this.g.applyDamage(a, dmg, p.by && p.by.alive !== false ? p.by : null, false, new V3(p.v.x * .6, 3 + spd * .2, p.v.z * .6)); this.g.cause = null; a.vx += p.v.x * .3; a.vz += p.v.z * .3; a.onGround = false; a.vy = Math.max(a.vy, 3); this.g.snd('thud', a.pos, 1, 60); }
      }
      if (p.asleep) continue;
      for (let s = 0; s < sub; s++) this.step(p, h);
      this.sync(p);
    }
    if (this.g.phys.physics !== 'light') this.collideProps();
  }
  step(p, dt) {
    p.v.y -= G * dt; p.c.addScaledVector(p.v, dt); const wl = p.w.length(); if (wl > 1e-4) { _dq.setFromAxisAngle(_a.copy(p.w).divideScalar(wl), wl * dt); p.q.premultiply(_dq).normalize(); }
    // static colliders: bounce off walls/cover
    _b.copy(p.c); resolveXZ(p.c, p.rad, p.c.y - p.h / 2); _n.set(p.c.x - _b.x, 0, p.c.z - _b.z); const pl = _n.length();
    if (pl > 1e-4) { _n.divideScalar(pl); const vn = p.v.dot(_n); if (vn < 0) { p.v.addScaledVector(_n, -(1.3) * vn); p.w.y += rnd(2); if (vn < -4) this.g.snd('thud', p.c, .7, 70); } }
    // ground: every shape vertex is a contact point (so barrels roll, crates tip and settle on corners)
    terrainNormal(p.c.x, p.c.z, _n); const pts = PTS[p.type], iters = this.g.phys.physIter; let touching = 0, hardest = 0;
    for (let it = 0; it < iters; it++) {
      let maxPen = 0; touching = 0;
      for (const lp of pts) {
        _a.copy(lp).applyQuaternion(p.q).add(p.c); const gy = groundAt(_a.x, _a.z, _a.y + .25), pen = gy - _a.y; if (pen < -.002) continue; touching++; if (pen > maxPen) maxPen = pen;
        const j = solveContact(p, null, _n, _a, null, it === 0 ? .22 : 0, p.mu); if (j > hardest) hardest = j;
      }
      if (maxPen > .003) p.c.addScaledVector(_n, maxPen * .6);
    }
    if (hardest > 2.2 * p.mass) this.g.snd('thud', p.c, Math.min(1, hardest * .15), 70);
    p.air = touching === 0; p.w.multiplyScalar(Math.exp((touching ? -1.6 : -.2) * dt)); if (touching) { const f = Math.exp(-.5 * dt); p.v.x *= f; p.v.z *= f; }
    if (touching && p.v.lengthSq() < .05 && p.w.lengthSq() < .12) { p.still += dt; if (p.still > .5) { p.asleep = true; p.v.set(0, 0, 0); p.w.set(0, 0, 0); } } else p.still = 0;
  }
  /** prop-vs-prop: upright-cylinder broadphase, impulse with spin. Lets barrels bowl into crates and chain reactions shove stacks. */
  collideProps() {
    const L = this.list;
    for (let i = 0; i < L.length; i++) for (let j = i + 1; j < L.length; j++) {
      const a = L[i], b = L[j]; if (a.asleep && b.asleep) continue; const dx = b.c.x - a.c.x, dz = b.c.z - a.c.z, rr = a.rad + b.rad; if (Math.abs(dx) > rr || Math.abs(dz) > rr) continue;
      const dxz = Math.hypot(dx, dz), dy = b.c.y - a.c.y, hh = (a.h + b.h) / 2; if (dxz >= rr || Math.abs(dy) >= hh) continue;
      const ph = rr - dxz, pv = hh - Math.abs(dy); if (ph < pv) _n.set(dx / (dxz || 1), 0, dz / (dxz || 1)); else _n.set(0, Math.sign(dy) || 1, 0); const pen = Math.min(ph, pv), tot = a.invM + b.invM;
      a.c.addScaledVector(_n, -pen * a.invM / tot); b.c.addScaledVector(_n, pen * b.invM / tot); _a.copy(a.c).add(b.c).multiplyScalar(.5); a.asleep = b.asleep = false; a.still = b.still = 0;
      const sp = solveContact(a, b, _n, _a, _a, .35, .5); if (sp > .8 * (a.mass + b.mass) * .5) { this.g.snd('thud', _a, Math.min(1, sp * .2), 60); if (!a.by) a.by = b.by; if (!b.by) b.by = a.by; }
      this.sync(a); this.sync(b);
    }
  }
  burn(p, dt) {
    const fx = this.g.fx, top = _a.set(0, p.h / 2, 0).applyQuaternion(p.q).add(p.c); p.hp -= dt * 7; this.carry += dt * 38 * fx.q;
    while (this.carry >= 1) { this.carry--; fx.emit(top.x + rnd(.15), top.y, top.z + rnd(.15), rnd(.6), 2 + R() * 3, rnd(.6), .45 + R() * .3, .35, .08, COL.flame, COL.flame2, -2, 1, 0, 0, .4, true, rnd(2)); if (R() < .3) fx.emit(top.x, top.y + .3, top.z, rnd(.6), 1.5 + R() * 2, rnd(.6), 1.8, .3, 1.6, COL.smoke, COL.smoke2, -1, .6, 1, 0, 1, false, rnd(1)); }
    if (p.asleep && R() < dt * 2) { p.asleep = false; } // flame jet thrusts the can around
    if (!p.asleep) { p.v.y += 5 * dt; p.v.x += rnd(6) * dt; p.v.z += rnd(6) * dt; p.w.x += rnd(10) * dt; p.w.z += rnd(10) * dt; }
    if (p.hp <= 0) this.destroy(p, p.by);
  }
  /** Explosion / blast impulse applied off-centre so props tumble. */
  impulse(origin, radius, power, by) {
    for (const p of this.list) {
      const d = _a.copy(p.c).distanceTo(origin); if (d > radius) continue; const k = (1 - d / radius) * power, dir = _b.copy(p.c).sub(origin).normalize(); dir.y += .55; dir.normalize();
      _c.copy(dir).multiplyScalar(k * p.mass); _r.set(p.c.x + rnd(.35), p.c.y + rnd(.4), p.c.z + rnd(.35)); this.push(p, _c, _r); if (by) p.by = by;
    }
  }
  hit(p, d, at, dmg) { _c.copy(d).multiplyScalar(dmg * .07); this.push(p, _c, at); }
  damage(p, amount, by) {
    p.hp -= amount; p.asleep = false; if (by) p.by = by; if (p.hp > 0) { if (p.explosive && !p.burning && p.hp < p.hp0 * .6) { p.burning = true; this.g.snd('thud', p.c, .5, 40); } return; }
    this.destroy(p, by);
  }
  destroy(p, by) {
    const i = this.list.indexOf(p); if (i < 0) return; this.list.splice(i, 1); this.g.scene.remove(p.mesh); const c = p.c.clone(), db = this.g.debris;
    if (p.explosive) { db.burst(c, 'metal', 10, 9); this.g.explosion(c, by, 7, 115); this.g.fx.addFire(c.x, terrainH(c.x, c.z) + .1, c.z, 9, 1.3); }
    else if (p.type === 'crate') { db.burst(c, 'wood', 16, 6); this.g.fx.chips(c.x, c.y, c.z, [.5, .36, .2, 1], 10); this.g.fx.puff(c.x, c.y, c.z, COL.dust, 6, 2.5); this.g.snd('thud', c, 1, 80); }
    else { db.burst(c, 'metal', 9, 7); this.g.fx.impact(c.x, c.y, c.z, 'metal'); this.g.snd('thud', c, 1, 80); }
  }
  damageArea(origin, radius, dmg, by) { for (const p of [...this.list]) { if (!this.list.includes(p)) continue; const d = p.c.distanceTo(origin); if (d < radius) this.damage(p, dmg * (1 - d / radius), by); } }
}

// ---- Debris: instanced chunks (splinters, metal, earth, snow) that tumble, bounce and settle, then shrink away ----
const KC = { wood: [[.55, .38, .22], [.42, .29, .17], [.62, .5, .32]], metal: [[.36, .38, .41], [.5, .27, .15], [.22, .23, .25]], earth: [[.3, .25, .2], [.36, .31, .26]], snow: [[.95, .97, 1], [.85, .9, .96]], shrap: [[.2, .2, .22], [.3, .28, .25]] };
const KS = { wood: [.34, .05, .09], metal: [.2, .03, .16], earth: [.14, .12, .14], snow: [.16, .14, .16], shrap: [.1, .03, .06] };
export class Debris {
  constructor(game, n) {
    this.g = game; this.n = n; this.i = 0; this.on = n > 0; this.items = []; this.m = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), new THREE.MeshLambertMaterial({ color: 0xffffff }), Math.max(1, n)); this.m.frustumCulled = false; this.m.castShadow = false; game.scene.add(this.m);
    const z = new THREE.Matrix4().makeScale(0, 0, 0), col = new THREE.Color(1, 1, 1); for (let k = 0; k < n; k++) { this.items.push({ p: new V3(), v: new V3(), q: new Q(), w: new V3(), s: new V3(), live: false, rest: 0, scale: 1 }); this.m.setMatrixAt(k, z); this.m.setColorAt(k, col); } this.mat = new THREE.Matrix4(); this.sc = new V3();
  }
  burst(pos, kind, count, power, dir) {
    if (!this.on) return; const cols = KC[kind], sz = KS[kind], k = Math.max(1, Math.round(count * (this.g.phys.physics === 'light' ? .5 : this.g.phys.physics === 'extreme' ? 1.6 : 1))), col = new THREE.Color();
    for (let j = 0; j < k; j++) {
      const idx = this.i++ % this.n, d = this.items[idx], c = cols[(R() * cols.length) | 0], f = .6 + R() * .9; col.setRGB(c[0], c[1], c[2]); this.m.setColorAt(idx, col);
      d.p.set(pos.x + rnd(.3), pos.y + rnd(.2), pos.z + rnd(.3)); d.v.set(rnd(power), 2 + R() * power * .9, rnd(power)); if (dir) d.v.addScaledVector(dir, power * .6);
      d.q.set(R() - .5, R() - .5, R() - .5, R() - .5).normalize(); d.w.set(rnd(12), rnd(12), rnd(12)); d.s.set(sz[0] * f, sz[1] * f, sz[2] * f * (.7 + R() * .6)); d.live = true; d.rest = 0; d.scale = 1; d.kind = kind;
    }
    this.m.instanceColor.needsUpdate = true;
  }
  update(dt) {
    if (!this.on) return; let any = false;
    for (let k = 0; k < this.n; k++) {
      const d = this.items[k]; if (!d.live) continue; any = true;
      if (d.rest < 1.5) {
        d.v.y -= G * dt; d.p.addScaledVector(d.v, dt); _dq.setFromAxisAngle(_a.copy(d.w).normalize(), d.w.length() * dt); if (d.w.lengthSq() > 1e-6) d.q.premultiply(_dq).normalize(); _b.copy(d.p); resolveXZ(d.p, .08, d.p.y - .1); if (d.p.x !== _b.x || d.p.z !== _b.z) { d.v.x *= -.3; d.v.z *= -.3; }
        const gy = groundAt(d.p.x, d.p.z, d.p.y) + d.s.y * .5; if (d.p.y < gy) { d.p.y = gy; if (d.v.y < -2.5) { d.v.y *= -.32; d.w.multiplyScalar(.6); } else d.v.y = 0; const f = Math.exp(-6 * dt); d.v.x *= f; d.v.z *= f; d.w.multiplyScalar(Math.exp(-5 * dt)); }
        if (d.v.lengthSq() < .04 && d.w.lengthSq() < .3 && d.p.y <= gy + .02) d.rest += dt; else d.rest = 0;
      } else d.rest += dt;
      if (d.rest > 9) { d.scale = Math.max(0, 1 - (d.rest - 9)); if (d.scale <= 0) { d.live = false; this.m.setMatrixAt(k, this.mat.makeScale(0, 0, 0)); continue; } }
      this.m.setMatrixAt(k, this.mat.compose(d.p, d.q, this.sc.copy(d.s).multiplyScalar(d.scale)));
    }
    if (any) this.m.instanceMatrix.needsUpdate = true;
  }
  clear() { for (let k = 0; k < this.n; k++) { this.items[k].live = false; this.m.setMatrixAt(k, this.mat.makeScale(0, 0, 0)); } this.m.instanceMatrix.needsUpdate = true; }
  blast(pos, R_, power) { // shockwave kicks nearby loose chunks
    for (const d of this.items) { if (!d.live) continue; const dd = d.p.distanceTo(pos); if (dd > R_) continue; const k = (1 - dd / R_) * power; _a.copy(d.p).sub(pos).normalize(); d.v.addScaledVector(_a, k).y += k * .6; d.w.set(rnd(10), rnd(10), rnd(10)); d.rest = 0; }
  }
}

// ---- Shell casings: ejected brass bounces and rolls ----
export class Casings {
  constructor(scene, n = 80) { this.n = n; this.i = 0; this.s = []; this.on = n > 0; this.m = new THREE.InstancedMesh(new THREE.CylinderGeometry(.008, .008, .05, 6).rotateX(Math.PI / 2), new THREE.MeshLambertMaterial({ color: 0xc9a84e }), Math.max(1, n)); this.m.frustumCulled = false; scene.add(this.m);
    const z = new THREE.Matrix4().makeScale(0, 0, 0); for (let k = 0; k < n; k++) { this.s.push({ p: new V3(), v: new V3(), r: new V3(), rot: new V3(), rest: true }); this.m.setMatrixAt(k, z); } this.mat = new THREE.Matrix4(); this.e = new THREE.Euler(); this.qq = new Q(); this.sc = new V3(1, 1, 1); }
  eject(pos, right, up) { if (!this.on) return; const c = this.s[this.i++ % this.n]; c.p.copy(pos); c.v.copy(right).multiplyScalar(2 + R()).addScaledVector(up, 1.5 + R()); c.v.x += rnd(.4); c.v.z += rnd(.4); c.r.set(rnd(25), rnd(25), rnd(25)); c.rest = false; c.rot.set(R() * 6, R() * 6, R() * 6); c.t = 0; }
  update(dt) {
    if (!this.on) return; let any = false;
    for (let k = 0; k < this.n; k++) { const c = this.s[k]; if (c.rest) continue; any = true; c.t += dt; c.v.y -= 20 * dt; c.p.addScaledVector(c.v, dt); c.rot.addScaledVector(c.r, dt);
      const gy = groundAt(c.p.x, c.p.z, c.p.y) + .01; if (c.p.y < gy) { c.p.y = gy; if (c.v.y < -1) { c.v.y *= -.4; c.v.x *= .55; c.v.z *= .55; c.r.multiplyScalar(.45); } else { c.rest = true; c.rot.x = c.rot.z = 0; c.p.y -= .008; } }
      this.m.setMatrixAt(k, this.mat.compose(c.p, this.qq.setFromEuler(this.e.set(c.rot.x, c.rot.y, c.rot.z)), this.sc)); }
    if (any) this.m.instanceMatrix.needsUpdate = true;
  }
}

// ---- Ragdolls: 13-point verlet skeleton per corpse (head, neck, shoulders, pelvis, hips, feet, hands, gun) + distance joints. The body meshes follow the skeleton. ----
const REST = [[0, 1.72, 0], [0, 1.5, 0], [-.36, 1.45, 0], [.36, 1.45, 0], [0, .9, 0], [-.12, .88, 0], [.12, .88, 0], [-.12, .05, 0], [.12, .05, 0], [-.2, 1.25, -.52], [.25, 1.2, -.5], [.2, 1.25, .05], [.2, 1.25, -.75]];
const RAD = [.15, .1, .1, .1, .13, .1, .1, .07, .07, .06, .06, .06, .06];
const LINKS = [[0, 1], [0, 2], [0, 3], [1, 2], [1, 3], [2, 3], [1, 4], [2, 4], [3, 4], [4, 5], [4, 6], [5, 6], [2, 6], [3, 5], [1, 5], [1, 6], [5, 7], [6, 8], [2, 9], [3, 10], [10, 11], [10, 12], [11, 12], [4, 7], [4, 8]];
const STEP = 1 / 60;
function orientY(obj, pos, y, xHint) { _c.crossVectors(xHint, y); if (_c.lengthSq() < 1e-6) _c.set(0, 0, 1).cross(y); _c.normalize(); _a.crossVectors(y, _c).normalize(); _m4.makeBasis(_a, y, _c); obj.quaternion.setFromRotationMatrix(_m4); obj.position.copy(pos); }
export class Ragdolls {
  constructor(game) { this.g = game; this.list = []; }
  start(model, imp) {
    const u = model.userData; if (u.rag) return; u.rag = true; model.updateMatrixWorld(true); const g = this.g, n = REST.length, full = g.phys.ragdoll === 'full';
    const rd = { model, parts: u.parts, x: new Float32Array(n * 3), p: new Float32Array(n * 3), len: LINKS.map(() => 0), asleep: false, t: 0, quiet: 0, iters: full ? 6 : 3 };
    for (let i = 0; i < n; i++) { _a.set(...REST[i]); model.localToWorld(_a); rd.x.set([_a.x, _a.y, _a.z], i * 3); const k = i === 4 || i === 1 ? 1 : .6 + R() * .6; rd.p.set([_a.x - (imp.x * k + rnd(1.2)) * STEP, _a.y - (imp.y * k + 1.5 + R() * 1.5) * STEP, _a.z - (imp.z * k + rnd(1.2)) * STEP], i * 3); }
    LINKS.forEach(([a, b], i) => { rd.len[i] = Math.hypot(rd.x[a * 3] - rd.x[b * 3], rd.x[a * 3 + 1] - rd.x[b * 3 + 1], rd.x[a * 3 + 2] - rd.x[b * 3 + 2]); });
    for (const p of u.parts) g.scene.attach(p); this.list.push(rd); this.pose(rd);
  }
  reset(model) {
    const u = model.userData; this.list = this.list.filter(r => r.model !== model);
    u.parts.forEach((p, i) => { model.add(p); p.position.copy(u.rest[i].pos); p.quaternion.copy(u.rest[i].quat); p.scale.set(1, 1, 1); p.visible = true; }); u.rag = false;
    u.armL.rotation.set(1.4, 0, -.35); u.armR.rotation.set(1.15, 0, .15);
  }
  hide(model) { const u = model.userData; u.parts.forEach(p => p.visible = false); this.list = this.list.filter(r => r.model !== model); }
  impulse(origin, radius, power) {
    for (const rd of this.list) for (let i = 0; i < REST.length; i++) { const k = i * 3, dx = rd.x[k] - origin.x, dy = rd.x[k + 1] - origin.y, dz = rd.x[k + 2] - origin.z, d = Math.hypot(dx, dy, dz); if (d > radius || d < .01) continue; const f = (1 - d / radius) * power * STEP * (.7 + R() * .6); rd.p[k] -= dx / d * f; rd.p[k + 1] -= (dy / d + .5) * f; rd.p[k + 2] -= dz / d * f; rd.asleep = false; rd.quiet = 0; }
  }
  update(dt) {
    for (const rd of this.list) {
      if (rd.asleep) continue; rd.t += dt; rd.acc = Math.min((rd.acc || 0) + dt, STEP * 3); while (rd.acc >= STEP) { rd.acc -= STEP; this.step(rd); } this.pose(rd);
      if (rd.t > 10) rd.asleep = true;
    }
  }
  step(rd) {
    const n = REST.length, x = rd.x, p = rd.p, damp = .992; let move = 0;
    for (let i = 0; i < n; i++) { const k = i * 3, vx = (x[k] - p[k]) * damp, vy = (x[k + 1] - p[k + 1]) * damp, vz = (x[k + 2] - p[k + 2]) * damp; p[k] = x[k]; p[k + 1] = x[k + 1]; p[k + 2] = x[k + 2]; x[k] += vx; x[k + 1] += vy - G * STEP * STEP; x[k + 2] += vz; move += vx * vx + vy * vy + vz * vz; }
    for (let it = 0; it < rd.iters; it++) {
      LINKS.forEach(([a, b], li) => { const ia = a * 3, ib = b * 3, dx = x[ib] - x[ia], dy = x[ib + 1] - x[ia + 1], dz = x[ib + 2] - x[ia + 2], d = Math.hypot(dx, dy, dz) || 1e-5, f = (d - rd.len[li]) / d * .5; x[ia] += dx * f; x[ia + 1] += dy * f; x[ia + 2] += dz * f; x[ib] -= dx * f; x[ib + 1] -= dy * f; x[ib + 2] -= dz * f; });
      for (let i = 0; i < n; i++) {
        const k = i * 3; _tmp.set(x[k], x[k + 1], x[k + 2]); resolveXZ(_tmp, RAD[i], _tmp.y - RAD[i]); x[k] = _tmp.x; x[k + 2] = _tmp.z;
        const gy = groundAt(x[k], x[k + 2], x[k + 1]) + RAD[i] * .8; if (x[k + 1] < gy) { const vy = x[k + 1] - p[k + 1]; x[k + 1] = gy; if (it === 0) { p[k + 1] = gy + vy * .25; if (vy < -.12) this.g.snd('thud', _tmp.set(x[k], gy, x[k + 2]), Math.min(.6, -vy * 2.5), 40); } else p[k + 1] = gy; p[k] += (x[k] - p[k]) * .35; p[k + 2] += (x[k + 2] - p[k + 2]) * .35; }
      }
    }
    if (move < 6e-5 * n) { rd.quiet += STEP; if (rd.quiet > .8) rd.asleep = true; } else rd.quiet = 0;
  }
  pose(rd) {
    const u = rd.model.userData, x = rd.x, P = i => _tmp.set(x[i * 3], x[i * 3 + 1], x[i * 3 + 2]), v = i => new V3(x[i * 3], x[i * 3 + 1], x[i * 3 + 2]);
    const neck = v(1), pel = v(4), sL = v(2), sR = v(3), right = sR.clone().sub(sL).normalize(), up = neck.clone().sub(pel).normalize(), parts = rd.parts;
    orientY(parts[0], pel.clone().add(neck).multiplyScalar(.5).addScaledVector(up, -.1), up, right);
    const head = v(0); orientY(parts[1], head, head.clone().sub(neck).normalize(), right);
    orientY(parts[2], v(5), v(5).sub(v(7)).normalize(), right); orientY(parts[3], v(6), v(6).sub(v(8)).normalize(), right);
    orientY(parts[4], sL, sL.clone().sub(v(9)).normalize(), right); orientY(parts[5], sR, sR.clone().sub(v(10)).normalize(), right);
    const gA = v(11), gB = v(12), z = gA.clone().sub(gB).normalize(), xx = new V3().crossVectors(up, z).normalize(), yy = new V3().crossVectors(z, xx).normalize(); _m4.makeBasis(xx, yy, z); parts[6].quaternion.setFromRotationMatrix(_m4); parts[6].position.copy(gA).addScaledVector(z, -.38);
  }
}
