import * as THREE from 'three';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';
import { loadSettings, saveSettings, defaults, resolved } from './settings.js';
import { initAudio, setVolumes, music, sfx } from './audio.js';
import { buildWorld } from './world.js';
import { createInput, isTouch } from './input.js';
import { Game, TEAMS } from './game.js';
import { WEAPONS, FACTIONS } from './weapons.js';

const $ = id => document.getElementById(id), settings = loadSettings(), tick = () => new Promise(r => setTimeout(r, 40));
const canvas = $('c'), renderer = new THREE.WebGLRenderer({ canvas, antialias: false, powerPreference: 'high-performance' });
renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.05; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
const scene = new THREE.Scene(), camera = new THREE.PerspectiveCamera(75, 1, .1, 360); let world, game, input;
if (isTouch) document.body.classList.add('touch');
const bar = (f, m) => { $('bootbar').style.width = f * 100 + '%'; $('bootmsg').textContent = m; };
let screenOpen = true;
function show(id) { document.querySelectorAll('.screen').forEach(s => s.classList.toggle('show', s.id === id)); screenOpen = !!id; }

// ---- graphics: render scale, shadows, bloom, exposure. Size changes are cheap; full apply also rebuilds particle/snow/debris budgets. ----
let composer = null, useBloom = false;
function applySize() {
  const dpr = window.devicePixelRatio || 1, q = settings.quality, ratio = Math.max(.3, Math.min(2, Math.min(dpr, { low: .6, medium: .85, high: 1.5 }[q] || .85) * (settings.resScale || 1)));
  renderer.setPixelRatio(ratio); renderer.setSize(innerWidth, innerHeight, false); camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix();
  if (composer) { composer.setPixelRatio(ratio); composer.setSize(innerWidth, innerHeight); }
  if (game) { game.renderScale = ratio; game.fx.setScale(innerHeight * ratio, camera.fov); } return ratio;
}
function applyQuality() {
  applySize(); const R = resolved(settings);
  if (renderer.shadowMap.enabled !== R.shadows) { renderer.shadowMap.enabled = R.shadows; scene.traverse(o => { if (o.material) o.material.needsUpdate = true; }); }
  if (world) world.sun.castShadow = R.shadows;
  useBloom = R.bloom; if (useBloom && !composer) { composer = new EffectComposer(renderer); composer.addPass(new RenderPass(scene, camera)); composer.addPass(new UnrealBloomPass(new THREE.Vector2(innerWidth, innerHeight), .45, .55, 1.0)); composer.addPass(new OutputPass()); applySize(); }
  const env = game ? game.applySettings() : null; renderer.toneMappingExposure = (env ? env.expo : 1.05) * (settings.brightness || 1);
  document.body.classList.toggle('vig', !!settings.vignette); document.body.classList.toggle('night', settings.timeOfDay === 'night'); $('fps').style.display = settings.fps ? 'block' : 'none';
  if (input) { input.sens = settings.sens; } setVolumes({ master: settings.volume, music: settings.music });
}
addEventListener('resize', applySize);

// ---- HUD bridge: Game calls these ----
let el, chips = [], msgT, vigT, hitT, dirT;
function buildUi() {
  el = { sc0: $('sc0'), sc1: $('sc1'), timer: $('timer'), hp: $('hpbar').firstElementChild, hpt: $('hptxt'), ammo: $('ammotxt'), wn: $('wname'), nd: $('nades'), msg: $('msg'), vig: $('vig'), hit: $('hitm'), feed: $('feed'), st: $('stbar').firstElementChild, heat: $('heatbar'), prompt: $('prompt'), supp: $('supp'), dir: $('dmgdir') };
  for (let i = 0; i < 5; i++) { const c = document.createElement('div'); c.className = 'chip'; c.innerHTML = '<i></i><span></span>'; $('chips').appendChild(c); chips.push(c); }
}
const ui = {
  minimap: $('mini'),
  hud(d) { el.sc0.textContent = d.s0; el.sc1.textContent = d.s1; el.timer.textContent = d.time; el.hp.style.width = d.hp + '%'; el.hp.style.background = d.hp < 35 ? '#c4412f' : '#86c45a'; el.hpt.textContent = d.hp; el.ammo.textContent = d.ammo; el.wn.textContent = d.wname; el.nd.textContent = d.nades; el.st.style.width = d.stam + '%';
    el.heat.style.display = d.heat >= 0 ? 'block' : 'none'; if (d.heat >= 0) el.heat.firstElementChild.style.width = d.heat + '%'; el.prompt.style.display = d.prompt ? 'block' : 'none'; el.prompt.textContent = d.prompt ? (isTouch ? 'Tap USE: ' : 'Press E: ') + d.prompt : ''; document.body.classList.toggle('canuse', !!d.prompt); el.supp.style.opacity = d.supp; },
  chip(i, id, owner, prog, cont) { const c = chips[i], b = c.firstElementChild; c.children[1].textContent = id; b.style.background = prog > .001 ? TEAMS[0].css : prog < -.001 ? TEAMS[1].css : '#999'; b.style.height = Math.abs(prog) * 100 + '%'; c.style.borderColor = owner >= 0 ? TEAMS[owner].css : '#aaa'; c.classList.toggle('c', cont); },
  msg(t, col) { el.msg.textContent = t; el.msg.style.color = col; el.msg.style.opacity = 1; clearTimeout(msgT); msgT = setTimeout(() => el.msg.style.opacity = 0, 2200); },
  feed(html) { const d = document.createElement('div'); d.innerHTML = html; el.feed.appendChild(d); setTimeout(() => d.remove(), 4500); while (el.feed.children.length > 5) el.feed.firstChild.remove(); },
  hit(head) { el.hit.classList.add('on'); el.hit.classList.toggle('head', head); clearTimeout(hitT); hitT = setTimeout(() => el.hit.classList.remove('on'), 90); },
  damage(ang) { el.vig.style.opacity = 1; clearTimeout(vigT); vigT = setTimeout(() => el.vig.style.opacity = 0, 250); el.dir.style.transform = `rotate(${ang}rad)`; el.dir.classList.add('on'); clearTimeout(dirT); dirT = setTimeout(() => el.dir.classList.remove('on'), 700); },
  showLoadout() { document.exitPointerLock && document.exitPointerLock(); fillLoadout(); show('s-loadout'); },
  onEnd(r) {
    document.exitPointerLock && document.exitPointerLock(); document.body.classList.remove('playing'); music.start('menu'); const nm = i => FACTIONS[game.facs[i]].name;
    $('resTitle').textContent = r.winner === 0 ? 'VICTORY' : r.winner === 1 ? 'DEFEAT' : 'STALEMATE'; $('resScore').textContent = `${nm(0)} ${r.scores[0]} — ${r.scores[1]} ${nm(1)}`;
    const S = r.stats, kd = S.deaths ? (S.kills / S.deaths).toFixed(2) : S.kills.toFixed(2); $('resStats').innerHTML = [['Kills', S.kills], ['Deaths', S.deaths], ['Headshots', S.heads], ['Flags taken', S.captures], ['K/D', kd]].map(([k, v]) => `<div><b>${v}</b><span>${k}</span></div>`).join(''); show('s-results');
  },
};

// ---- settings screen: built from one schema so every option has the same behaviour (save + apply live) ----
const pct = v => Math.round(v * 100) + '%', AUTO = [['auto', 'Auto (follows preset)'], ['off', 'Off'], ['on', 'On']];
const SCHEMA = {
  Controls: [{ k: 'sens', l: 'Look sensitivity', t: 'range', min: .3, max: 2.5, step: .05, f: v => (+v).toFixed(2) }, { k: 'fov', l: 'Field of view', t: 'range', min: 60, max: 110, step: 1, f: v => v + '°' }, { k: 'invertY', l: 'Invert look Y', t: 'check' }, { k: 'bob', l: 'Camera bob', t: 'range', min: 0, max: 1.5, step: .05, f: pct }, { k: 'shake', l: 'Screen shake', t: 'range', min: 0, max: 1.5, step: .05, f: pct }],
  Audio: [{ k: 'volume', l: 'Sound volume', t: 'range', min: 0, max: 1, step: .05, f: pct }, { k: 'music', l: 'Music volume', t: 'range', min: 0, max: 1, step: .05, f: pct }],
  Graphics: [{ k: 'quality', l: 'Graphics preset', t: 'select', o: [['low', 'Low (fastest)'], ['medium', 'Medium'], ['high', 'High']] }, { k: 'resScale', l: 'Resolution scale', t: 'range', min: .5, max: 1.5, step: .05, f: pct }, { k: 'brightness', l: 'Brightness', t: 'range', min: .6, max: 1.8, step: .05, f: pct },
    { k: 'timeOfDay', l: 'Time of day', t: 'select', o: [['day', 'Day'], ['dusk', 'Dusk'], ['night', 'Night']] }, { k: 'weather', l: 'Weather', t: 'select', o: [['clear', 'Clear'], ['snow', 'Snowfall'], ['blizzard', 'Blizzard']] },
    { k: 'shadows', l: 'Shadows', t: 'select', o: AUTO }, { k: 'bloom', l: 'Bloom glow (post-processing)', t: 'select', o: AUTO }, { k: 'dynLights', l: 'Dynamic explosion & muzzle lights', t: 'select', o: AUTO }, { k: 'vignette', l: 'Vignette', t: 'check' }, { k: 'fps', l: 'Show FPS counter', t: 'check' }],
  'Physics & FX': [{ k: 'physics', l: 'Physics intensity', t: 'select', o: [['light', 'Light (fastest)'], ['normal', 'Normal'], ['high', 'Heavy'], ['extreme', 'Extreme (max debris)']] }, { k: 'particles', l: 'Particle density', t: 'select', o: [['auto', 'Auto (follows preset)'], ['low', 'Low'], ['medium', 'Medium'], ['high', 'High'], ['ultra', 'Ultra']] },
    { k: 'debris', l: 'Debris & shell casings', t: 'select', o: [['auto', 'Auto (follows preset)'], ['off', 'Off'], ['low', 'Low'], ['medium', 'Medium'], ['high', 'High']] }, { k: 'ragdoll', l: 'Ragdoll quality', t: 'select', o: [['auto', 'Auto (follows preset)'], ['simple', 'Simple'], ['full', 'Full']] }],
  Match: [{ k: 'botsPerTeam', l: 'Soldiers per team', t: 'select', o: [[4, '4 v 4'], [8, '8 v 8'], [12, '12 v 12'], [16, '16 v 16']] }, { k: 'difficulty', l: 'Enemy skill', t: 'select', o: [[0, 'Recruit'], [1, 'Regular'], [2, 'Veteran']] }],
};
let curTab = 'Controls', from = 's-menu', applyT = 0;
function showTab(name) {
  curTab = name; [...$('setTabs').children].forEach(b => b.classList.toggle('on', b.textContent === name)); const body = $('setBody'); body.innerHTML = '';
  for (const d of SCHEMA[name]) {
    const row = document.createElement('label'), num = typeof defaults[d.k] === 'number'; let inp;
    if (d.t === 'range') { row.innerHTML = `${d.l}<output></output><input type="range" min="${d.min}" max="${d.max}" step="${d.step}">`; inp = row.querySelector('input'); inp.value = settings[d.k]; const out = row.querySelector('output'), show = () => out.textContent = d.f(inp.value); show(); inp.addEventListener('input', () => { settings[d.k] = +inp.value; show(); queue(); }); }
    else if (d.t === 'select') { row.innerHTML = `${d.l}<select>${d.o.map(([v, t]) => `<option value="${v}">${t}</option>`).join('')}</select>`; inp = row.querySelector('select'); inp.value = settings[d.k]; inp.addEventListener('change', () => { settings[d.k] = num ? +inp.value : inp.value; saveSettings(settings); applyQuality(); if (d.k === 'quality') showTab(curTab); }); }
    else { row.className = 'chk'; row.innerHTML = `${d.l}<input type="checkbox">`; inp = row.querySelector('input'); inp.checked = !!settings[d.k]; inp.addEventListener('change', () => { settings[d.k] = inp.checked; saveSettings(settings); applyQuality(); }); }
    body.appendChild(row);
  }
}
const queue = () => { clearTimeout(applyT); applyT = setTimeout(() => { saveSettings(settings); applyQuality(); }, 60); };
function buildSettings() { const t = $('setTabs'); t.innerHTML = ''; for (const n of Object.keys(SCHEMA)) { const b = document.createElement('button'); b.textContent = n; b.onclick = () => { showTab(n); sfx('click'); }; t.appendChild(b); } showTab(curTab); }

// ---- loadout / deploy ----
let spawnId = 'base';
function fillLoadout() {
  const fc = $('facs'); fc.innerHTML = ''; for (const id of ['allies', 'axis']) { const f = FACTIONS[id], b = document.createElement('button'); b.className = 'card face' + (id === settings.faction ? ' sel' : ''); b.innerHTML = `<div class="paper"><img src="img/${f.img}" alt=""></div><b>${f.name}</b>${f.blurb}`; b.onclick = () => { settings.faction = id; saveSettings(settings); sfx('click'); fillLoadout(); }; fc.appendChild(b); }
  const wc = $('wcards'); wc.innerHTML = ''; for (const id of ['thompson', 'garand', 'k98']) { const w = WEAPONS[id], b = document.createElement('button'); b.className = 'card' + (id === settings.primary ? ' sel' : ''); b.innerHTML = `<div class="paper"><img src="img/${w.img}" alt=""></div><b>${w.name}</b>${w.cls} · ${w.mag} rds · ${w.dmg} dmg`; b.onclick = () => { settings.primary = id; saveSettings(settings); sfx('click'); fillLoadout(); }; wc.appendChild(b); }
  $('sidearm').textContent = `Sidearm: ${WEAPONS.p38.name} · ${FACTIONS[settings.faction].nade} ×2 · M2 Browning emplacements can be manned with USE.`;
  const opts = game.spawnOptions(); if (!opts.some(o => o.id === spawnId)) spawnId = 'base'; const sp = $('spawns'); sp.innerHTML = '';
  for (const o of opts) { const b = document.createElement('button'); b.className = 'card' + (o.id === spawnId ? ' sel' : ''); b.innerHTML = `<b>${o.label}</b>`; b.onclick = () => { spawnId = o.id; fillLoadout(); }; sp.appendChild(b); }
}
function lockPtr() { if (!isTouch && canvas.requestPointerLock) canvas.requestPointerLock(); }
function bind() {
  $('playBtn').onclick = () => { game.running = false; spawnId = 'base'; fillLoadout(); show('s-loadout'); sfx('click'); };
  $('deployBtn').onclick = () => { initAudio(); if (!game.running) game.start(); game.spawnPlayer(settings.primary, spawnId); document.body.classList.add('playing'); show(null); lockPtr(); music.start('battle'); applyQuality(); };
  $('manBtn').onclick = () => show('s-manual'); $('manBack').onclick = () => show('s-menu');
  document.querySelectorAll('.tabs button').forEach(b => b.onclick = () => { document.querySelectorAll('.tabs button').forEach(x => x.classList.toggle('on', x === b)); $('manImg').src = 'img/' + b.dataset.img; });
  buildSettings();
  $('setBtn').onclick = () => { from = 's-menu'; show('s-settings'); }; $('pauseSet').onclick = () => { from = 's-pause'; show('s-settings'); }; $('setBack').onclick = () => show(from);
  $('setReset').onclick = () => { for (const k of Object.keys(defaults)) if (!['faction', 'primary'].includes(k)) settings[k] = defaults[k]; saveSettings(settings); applyQuality(); showTab(curTab); };
  const pause = () => { if (!game.running || game.paused || screenOpen) return; game.paused = true; input.reset(); document.exitPointerLock && document.exitPointerLock(); show('s-pause'); };
  $('pauseBtn').addEventListener('click', pause); $('pauseBtn').addEventListener('touchstart', e => { e.preventDefault(); pause(); }, { passive: false });
  $('resumeBtn').onclick = () => { game.paused = false; show(null); lockPtr(); };
  $('quitBtn').onclick = () => { game.running = false; game.paused = false; if (game.vm) game.vm.visible = false; document.body.classList.remove('playing'); music.start('menu'); show('s-menu'); };
  $('againBtn').onclick = () => { fillLoadout(); show('s-loadout'); }; $('menuBtn').onclick = () => show('s-menu');
  canvas.addEventListener('click', () => { if (game.running && !screenOpen && !document.pointerLockElement) lockPtr(); });
  document.addEventListener('pointerlockchange', () => { if (!document.pointerLockElement) pause(); });
  document.addEventListener('visibilitychange', () => { if (document.hidden) pause(); });
}

// ---- boot: build the world after painting the loading screen, then wait for a tap (audio + fullscreen need a gesture) ----
(async function boot() {
  applyQuality(); bar(.1, 'Raising the ridge…'); await tick();
  world = buildWorld(scene, settings.quality); bar(.55, 'Digging in…'); await tick(); input = createInput(canvas); buildUi();
  game = new Game({ scene, camera, world, settings, input, ui }); applyQuality(); bind(); bar(1, 'Ready');
  const sb = $('startBtn'); sb.style.display = 'block';
  sb.onclick = () => { initAudio(); music.start('menu'); try { document.documentElement.requestFullscreen && document.documentElement.requestFullscreen(); screen.orientation && screen.orientation.lock && screen.orientation.lock('landscape').catch(() => { }); } catch { } $('boot').style.display = 'none'; show('s-menu'); };
  let last = performance.now(), fa = 0, fn = 0;
  renderer.setAnimationLoop(now => {
    const raw = (now - last) / 1000, dt = Math.min(.05, raw); last = now; fa += raw; fn++; if (fa > .5) { if (settings.fps) $('fps').textContent = Math.round(fn / fa) + ' FPS'; fa = fn = 0; }
    if (game.running) game.update(dt);
    else { const a = now * .00004; camera.position.set(Math.cos(a) * 120, 42, Math.sin(a) * 120); camera.lookAt(0, 6, 0); game.updateAmbient(dt, now / 1000, camera); }
    if (useBloom && composer) composer.render(); else renderer.render(scene, camera);
  });
})();
