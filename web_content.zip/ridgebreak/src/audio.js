// ---- AUDIO: fully procedural (no files). Positional pan + distance filtering + convolution reverb, wind ambience, war-drone music. ----
let ctx, master, sfxG, musicG, rev, noise, wind, vols = { master: .8, music: .5 };
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
export function initAudio(v) {
  if (v) vols = { ...vols, ...v };
  if (!ctx) {
    const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return; ctx = new AC();
    master = ctx.createGain(); master.connect(ctx.destination); sfxG = ctx.createGain(); sfxG.connect(master); musicG = ctx.createGain(); musicG.connect(master);
    noise = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate); const d = noise.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    rev = ctx.createConvolver(); const n = ctx.sampleRate * 1.8 | 0, ib = ctx.createBuffer(2, n, ctx.sampleRate); for (let c = 0; c < 2; c++) { const a = ib.getChannelData(c); for (let i = 0; i < n; i++) a[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / n, 2.6); } rev.buffer = ib; rev.connect(master);
  }
  setVolumes(vols); if (ctx.state === 'suspended') ctx.resume();
}
export function setVolumes(v) { vols = { ...vols, ...v }; if (master) { master.gain.value = vols.master; musicG.gain.value = vols.music * .5; } }
function out(pan, dist, vol) {
  const g = ctx.createGain(); g.gain.value = vol; const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 800 + 17000 * Math.pow(1 - dist, 2); g.connect(lp); let last = lp;
  if (ctx.createStereoPanner) { const p = ctx.createStereoPanner(); p.pan.value = clamp(pan, -1, 1); last.connect(p); last = p; }
  last.connect(sfxG); const s = ctx.createGain(); s.gain.value = .12 + dist * .6; last.connect(s); s.connect(rev); return g;
}
function burst(o, dur, f0, f1, type = 'lowpass', vol = 1, delay = 0) {
  const t = ctx.currentTime + delay, s = ctx.createBufferSource(), f = ctx.createBiquadFilter(), g = ctx.createGain(); s.buffer = noise; f.type = type; f.frequency.setValueAtTime(f0, t); f.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
  g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(.001, t + dur); s.connect(f); f.connect(g); g.connect(o); s.start(t, Math.random(), dur + .05);
}
function tone(o, f0, f1, dur, vol = 1, type = 'sine', delay = 0) {
  const t = ctx.currentTime + delay, os = ctx.createOscillator(), g = ctx.createGain(); os.type = type; os.frequency.setValueAtTime(f0, t); os.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
  g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(.001, t + dur); os.connect(g); g.connect(o); os.start(t); os.stop(t + dur + .03);
}
export function sfx(name, { vol = 1, pan = 0, dist = 0 } = {}) {
  if (!ctx || vol < .02) return; const o = out(pan, dist, vol);
  switch (name) {
    case 'thompson': burst(o, .12, 4500, 500, 'lowpass', .9); burst(o, .05, 6000, 2500, 'highpass', .5); tone(o, 150, 55, .1, .8); break;
    case 'garand': burst(o, .22, 5200, 300, 'lowpass', 1); burst(o, .06, 7000, 2000, 'highpass', .6); tone(o, 120, 45, .18, 1); break;
    case 'k98': burst(o, .32, 4600, 220, 'lowpass', 1.1); burst(o, .07, 7000, 1800, 'highpass', .7); tone(o, 95, 38, .28, 1.1); break;
    case 'p38': burst(o, .15, 4800, 600, 'lowpass', .8); burst(o, .04, 6500, 2500, 'highpass', .5); tone(o, 190, 70, .1, .6); break;
    case 'm2': burst(o, .24, 3200, 150, 'lowpass', 1.2); tone(o, 75, 32, .22, 1.3); tone(o, 140, 50, .08, .7); break;
    case 'boom': burst(o, 1.7, 1400, 40, 'lowpass', 1.5); tone(o, 62, 26, 1.3, 1.5); burst(o, 1, 500, 30, 'lowpass', .9, .22); break;
    case 'ping': tone(o, 2350, 2300, .7, .3); tone(o, 3150, 3100, .45, .15); break;
    case 'bolt': tone(o, 700, 400, .04, .35); tone(o, 520, 300, .05, .35, 'square', .14); burst(o, .06, 3000, 900, 'bandpass', .3, .3); break;
    case 'reload': burst(o, .05, 3000, 900, 'bandpass', .5); tone(o, 300, 180, .06, .4, 'square', .05); break;
    case 'magin': burst(o, .07, 2500, 700, 'bandpass', .6); tone(o, 220, 120, .08, .5, 'square'); break;
    case 'click': case 'empty': tone(o, 420, 360, .04, .3, 'square'); break;
    case 'thud': tone(o, 95, 45, .14, .7); burst(o, .1, 700, 150, 'lowpass', .5); break;
    case 'step': burst(o, .08, 2800 + Math.random() * 800, 1100, 'bandpass', .35); break;
    case 'land': burst(o, .15, 900, 200, 'lowpass', .8); tone(o, 80, 40, .12, .5); break;
    case 'hit': tone(o, 1300, 1000, .05, .3); break;
    case 'headshot': tone(o, 1900, 1500, .07, .35); tone(o, 950, 700, .1, .3, 'sine', .04); break;
    case 'hurt': burst(o, .16, 800, 200, 'lowpass', .7); tone(o, 120, 70, .12, .5); break;
    case 'whiz': { const t = ctx.currentTime, s = ctx.createBufferSource(), f = ctx.createBiquadFilter(), g = ctx.createGain(); s.buffer = noise; f.type = 'bandpass'; f.Q.value = 3; f.frequency.setValueAtTime(3200, t); f.frequency.exponentialRampToValueAtTime(900, t + .22); g.gain.setValueAtTime(.001, t); g.gain.linearRampToValueAtTime(.7, t + .05); g.gain.exponentialRampToValueAtTime(.001, t + .25); s.connect(f); f.connect(g); g.connect(o); s.start(t, Math.random(), .3); break; }
    case 'ring': tone(o, 3400, 3300, 1.6, .12); break;
    case 'use': tone(o, 300, 200, .1, .4, 'square'); burst(o, .1, 1500, 400, 'bandpass', .4); break;
    case 'flag': tone(o, 440, 440, .12, .25, 'triangle'); tone(o, 660, 660, .2, .25, 'triangle', .1); break;
    case 'pin': tone(o, 1800, 1200, .05, .3); burst(o, .05, 3500, 1500, 'highpass', .3, .05); break;
  }
}
// ---- wind ambience ----
export function ambient(on) {
  if (!ctx) return; if (!on) { if (wind) { try { wind.s.stop(); wind.l.stop(); } catch { } wind = null; } return; } if (wind) return;
  const s = ctx.createBufferSource(), f = ctx.createBiquadFilter(), g = ctx.createGain(), l = ctx.createOscillator(), lg = ctx.createGain(); s.buffer = noise; s.loop = true; f.type = 'bandpass'; f.frequency.value = 520; f.Q.value = .5; g.gain.value = .07; l.frequency.value = .11; lg.gain.value = .05;
  l.connect(lg); lg.connect(g.gain); s.connect(f); f.connect(g); g.connect(sfxG); s.start(); l.start(); wind = { s, l };
}
// ---- music: slow minor war drone + marching snare (menu) / sparse drone + timpani (battle) ----
let mt, mode, bar = 0; const ROOTS = [110, 87.3, 98, 82.4];
function pad(f, dur, vol) {
  const t = ctx.currentTime, lp = ctx.createBiquadFilter(), g = ctx.createGain(); lp.type = 'lowpass'; lp.frequency.value = 650; g.gain.setValueAtTime(.001, t); g.gain.linearRampToValueAtTime(vol, t + dur * .4); g.gain.linearRampToValueAtTime(.001, t + dur); lp.connect(g); g.connect(musicG);
  for (const d of [-7, 7]) { const o = ctx.createOscillator(); o.type = 'sawtooth'; o.frequency.value = f; o.detune.value = d; o.connect(lp); o.start(t); o.stop(t + dur + .1); }
}
function mbar() {
  if (!ctx || !mode) return; const f = ROOTS[bar++ % 4], menu = mode === 'menu', beat = 2.4 / 4, o = musicG;
  pad(f / 2, 2.6, menu ? .5 : .3); pad(f * 1.5, 2.6, menu ? .25 : .12); if (menu) pad(f * 1.19, 2.6, .18);
  for (let i = 0; i < 4; i++) { if (i % 2 === 0) tone(o, 90, 38, .3, menu ? .8 : .45, 'sine', i * beat); if (menu) { burst(o, .06, 4000, 1500, 'highpass', .14, i * beat + beat / 2); burst(o, .05, 3500, 1500, 'highpass', .08, i * beat + beat * .75); } }
  mt = setTimeout(mbar, 2400);
}
export const music = { start(m) { if (!ctx || mode === m) return; this.stop(); mode = m; bar = 0; mbar(); }, stop() { clearTimeout(mt); mode = null; } };
