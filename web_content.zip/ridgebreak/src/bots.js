import * as THREE from 'three';
import { WEAPONS } from './weapons.js';
import { COL } from './fx.js';
import { terrainH, colliders } from './world.js';
import { animateSoldier } from './models.js';
import { sfx } from './audio.js';
// ---- BOT AI: think ~2.5x/sec (target, goal flag, cover, grenade), act every frame (move, face, shoot). ----
const V3 = THREE.Vector3, rand = (a, b) => a + Math.random() * (b - a), clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const wrap = a => { while (a > Math.PI) a -= 2 * Math.PI; while (a < -Math.PI) a += 2 * Math.PI; return a; };
function think(g, b) {
  const eye = b.pos.y + 1.5; let best = null, bd = 6400;
  for (const a of g.actors) { if (!a.alive || a.team === b.team) continue; const dx = a.pos.x - b.pos.x, dz = a.pos.z - b.pos.z, d2 = dx * dx + dz * dz; if (d2 < bd && g.los(b.pos.x, eye, b.pos.z, a.pos.x, a.pos.y + 1.2, a.pos.z)) { bd = d2; best = a; } }
  if (best && b.target !== best) b.react = rand(.25, .6) * g.diff.react; b.target = best;
  if (b.moving && Math.hypot(b.pos.x - b.lx, b.pos.z - b.lz) < .5) { if (++b.stuckN >= 3) { b.unstick = 1; b.unstickDir = (Math.random() < .5 ? -1 : 1) * 1.3; b.stuckN = 0; } } else b.stuckN = 0; b.lx = b.pos.x; b.lz = b.pos.z;
  if (best && b.hp < 50 && g.t - b.lastHurt < 3) { // wounded under fire: hide behind the nearest tall cover, on the far side from the enemy
    if (b.mode !== 'cover') { let bc = null, bdd = 900; for (const c of colliders) { const cx = (c.x0 + c.x1) / 2, cz = (c.z0 + c.z1) / 2; if (c.top - terrainH(cx, cz) < .9) continue; const dd = (cx - b.pos.x) ** 2 + (cz - b.pos.z) ** 2; if (dd < bdd) { bdd = dd; bc = c; } }
      if (bc) { const cx = (bc.x0 + bc.x1) / 2, cz = (bc.z0 + bc.z1) / 2, ex = cx - best.pos.x, ez = cz - best.pos.z, l = Math.hypot(ex, ez) || 1, off = Math.max(bc.x1 - bc.x0, bc.z1 - bc.z0) / 2 + 1.2; b.coverPos = { x: cx + ex / l * off, z: cz + ez / l * off }; b.mode = 'cover'; } }
  } else b.mode = 'move';
  if (!b.goalPoint || b.goalT <= 0 || (b.goalPoint.owner === b.team && !b.goalPoint.contested)) {
    let c = g.points.filter(p => p.owner !== b.team || p.contested); if (!c.length) c = g.points; let bs = 1e9;
    for (const p of c) { const s = Math.hypot(p.x - b.pos.x, p.z - b.pos.z) + rand(0, 45) - (p.contested ? 25 : 0); if (s < bs) { bs = s; b.goalPoint = p; } } b.goalT = rand(10, 20);
  }
  if (best && b.grenCd <= 0 && bd > 144 && bd < 1024 && Math.random() < .3) { // lob a grenade
    b.grenCd = rand(18, 30); const dx = best.pos.x - b.pos.x, dz = best.pos.z - b.pos.z, d = Math.sqrt(bd), vh = clamp(d * .9, 8, 16), T = d / vh;
    g.spawnGrenade(new V3(b.pos.x, b.pos.y + 1.6, b.pos.z), new V3(dx / d * vh, 11 * T, dz / d * vh), b);
  }
}
function fire(g, b, T, dist) {
  const w = WEAPONS[b.wp], o = new V3(b.pos.x, b.pos.y + 1.5, b.pos.z), sp = (.02 + dist * .0006) * g.diff.acc, d = new V3(T.pos.x, T.pos.y + rand(.8, 1.5), T.pos.z).sub(o).normalize();
  d.x += (Math.random() - .5) * 2 * sp; d.y += (Math.random() - .5) * 2 * sp; d.z += (Math.random() - .5) * 2 * sp; d.normalize();
  const r = g.hitscan(o, d, 90, b); if (--b.burst <= 0) { b.fireCd = (.5 + Math.random() * .8) * (w.bolt ? 2 : 1); b.burst = w.auto ? 5 : 1; } else b.fireCd = 60 / w.rpm * 1.3;
  const end = o.clone().addScaledVector(d, r.t), mz = o.clone().addScaledVector(d, .9), pd = b.pos.distanceTo(g.player.pos);
  g.snd(w.sfx, b.pos, .9, 220); if (pd < 110) { g.tracer(mz, end); g.fx.emit(mz.x, mz.y, mz.z, 0, 0, 0, .05, .6, .2, COL.spark, COL.spark2); }
  g.resolveHit(b, r, d, end, w.botDmg * g.diff.dmg * (r.hit && r.hit.actor && r.hit.actor.isPlayer ? .85 : 1), false, w.name);
  if (g.player.alive && !(r.hit && r.hit.actor === g.player)) { // near miss => bullet whiz + suppression
    const e = g.camera.position, tt = clamp((e.x - o.x) * d.x + (e.y - o.y) * d.y + (e.z - o.z) * d.z, 0, r.t), cx = o.x + d.x * tt, cy = o.y + d.y * tt, cz = o.z + d.z * tt;
    if (tt > 8 && Math.hypot(cx - e.x, cy - e.y, cz - e.z) < 2.4) { g.snd('whiz', new V3(cx, cy, cz), 1, 20); g.suppress = Math.min(1, g.suppress + .4); g.shake = Math.max(g.shake, .15); }
  }
}
export function updateBot(g, b, dt) {
  if (!b.alive) { b.respawn -= dt; b.deadT += dt; if (b.deadT > 9 && b.model.userData.rag === true) { g.rag.hide(b.model); b.model.userData.rag = 'hidden'; } if (b.respawn <= 0) g.spawnBot(b); return; }
  b.think -= dt; b.fireCd -= dt; b.react -= dt; b.goalT -= dt; b.strafeT -= dt; b.unstick -= dt; b.grenCd -= dt;
  if (b.think <= 0) { b.think = .3 + Math.random() * .2; think(g, b); }
  let tx = 0, tz = 0, speed = 4.2, aim = null; const T = b.target;
  if (T && T.alive) {
    const dx = T.pos.x - b.pos.x, dz = T.pos.z - b.pos.z, dist = Math.hypot(dx, dz); aim = Math.atan2(-dx, -dz);
    if (b.strafeT <= 0) { b.strafe = Math.random() < .5 ? -1 : 1; b.strafeT = rand(1, 2.2); }
    if (b.mode === 'cover' && b.coverPos) { tx = b.coverPos.x - b.pos.x; tz = b.coverPos.z - b.pos.z; if (Math.hypot(tx, tz) < 1.2) tx = tz = 0; }
    else if (dist > 38) { tx = dx; tz = dz; } else if (dist < 9) { tx = -dx; tz = -dz; speed = 3; } else { tx = -dz * b.strafe; tz = dx * b.strafe; speed = 2.6; }
    if (b.react <= 0 && b.fireCd <= 0 && dist < 90) fire(g, b, T, dist);
  } else if (b.goalPoint) { const gp = b.goalPoint; tx = gp.x - b.pos.x; tz = gp.z - b.pos.z; const gd = Math.hypot(tx, tz); if (gd < 4) tx = tz = 0; else if (gd < 9) speed = 2; }
  const len = Math.hypot(tx, tz); b.moving = len > .5;
  if (b.moving) { tx /= len; tz /= len; if (b.unstick > 0) { const c = Math.cos(b.unstickDir), s = Math.sin(b.unstickDir), ox = tx; tx = tx * c - tz * s; tz = ox * s + tz * c; if (b.onGround && Math.random() < .1) { b.vy = 7.2; b.onGround = false; } } } else tx = tz = 0;
  const k = Math.min(1, dt * (b.onGround ? 8 : 1)); b.vx += (tx * speed - b.vx) * k; b.vz += (tz * speed - b.vz) * k; g.moveActor(b, b.vx * dt, b.vz * dt, dt);
  const want = aim !== null ? aim : (b.moving ? Math.atan2(-tx, -tz) : b.yaw), df = wrap(want - b.yaw); b.yaw += clamp(df, -6 * dt, 6 * dt);
  const sp = Math.hypot(b.vx, b.vz); b.model.position.copy(b.pos); b.model.rotation.y = b.yaw; animateSoldier(b.model, sp, dt);
  b.model.scale.y += ((b.mode === 'cover' && !b.moving ? .8 : 1) - b.model.scale.y) * Math.min(1, dt * 8);
  if (b.onGround && sp > 1.5) { b.stepD += sp * dt; if (b.stepD > 2) { b.stepD = 0; g.snd('step', b.pos, .6, 30); } }
}
