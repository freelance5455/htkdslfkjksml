// ---- WEAPON DATA (historical WW2 arms; stats are game-balance values). Used by the player, bots and the HUD. ----
export const WEAPONS = {
  thompson: { name: 'M1A1 Thompson', cls: 'Submachine gun', desc: 'Fast and fierce at close range. 30-round drum.', dmg: 24, rpm: 650, mag: 30, reserve: 150, spread: .022, adsSpread: .01, zoom: 1.3, recoil: .014, range: 110, auto: true, reload: 2.4, sfx: 'thompson', botDmg: 7, eject: true, img: 'w_thompson.jpg' },
  garand: { name: 'M1 Garand', cls: 'Semi-auto rifle', desc: 'Accurate, hard-hitting. 8-round clip pings when empty.', dmg: 55, rpm: 210, mag: 8, reserve: 64, spread: .003, adsSpread: .0008, zoom: 1.7, recoil: .03, range: 220, auto: false, reload: 2.6, sfx: 'garand', botDmg: 16, eject: true, ping: true, img: 'w_garand.jpg' },
  k98: { name: 'Karabiner 98k', cls: 'Bolt-action rifle', desc: 'Long range, 2-shot kills. Cycle the bolt after each shot.', dmg: 90, rpm: 48, mag: 5, reserve: 40, spread: .002, adsSpread: .0004, zoom: 2.1, recoil: .05, range: 260, auto: false, reload: 3.0, sfx: 'k98', botDmg: 30, bolt: true, img: 'w_k98.jpg' },
  p38: { name: 'Walther P38', cls: 'Sidearm', desc: 'Reliable 9mm pistol. Press SWAP to draw.', dmg: 30, rpm: 260, mag: 8, reserve: 48, spread: .012, adsSpread: .005, zoom: 1.25, recoil: .02, range: 80, auto: false, reload: 1.5, sfx: 'p38', botDmg: 9, eject: true, img: 'w_p38.jpg' },
};
export const FACTIONS = {
  allies: { name: 'US Infantry', blurb: 'M41 jacket, M1 helmet. Fast on their feet, light on armour.', nade: 'Mk 2 grenade', img: 'p_allies.jpg', bots: ['thompson', 'garand'] },
  axis: { name: 'Fallschirmjäger', blurb: 'Jump smock, M38 helmet. Long-range rifles, heavy recoil.', nade: 'Stielhandgranate', img: 'p_axis.jpg', bots: ['k98', 'k98', 'thompson'] },
};
