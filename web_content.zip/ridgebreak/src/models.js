import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
// ---- MODELS: every mesh is built from coloured primitives merged into ONE geometry (vertex colours) => few draw calls, high detail. ----
const V3 = THREE.Vector3, _c = new THREE.Color(), _q = new THREE.Quaternion(), _e = new THREE.Euler(), _m = new THREE.Matrix4(), H = Math.PI / 2;
export function part(geo, color, x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0, sx = 1, sy = 1, sz = 1) {
  const g = geo.index ? geo.toNonIndexed() : geo.clone(), n = g.attributes.position.count, a = new Float32Array(n * 3); _c.set(color);
  for (let i = 0; i < n; i++) { a[i * 3] = _c.r; a[i * 3 + 1] = _c.g; a[i * 3 + 2] = _c.b; }
  g.setAttribute('color', new THREE.BufferAttribute(a, 3));
  g.applyMatrix4(_m.compose(new V3(x, y, z), _q.setFromEuler(_e.set(rx, ry, rz)), new V3(sx, sy, sz))); return g;
}
export const BX = (w, h, d, c, ...a) => part(new THREE.BoxGeometry(w, h, d), c, ...a);
export const CY = (rt, rb, h, s, c, ...a) => part(new THREE.CylinderGeometry(rt, rb, h, s), c, ...a);
export const SP = (r, c, ...a) => part(new THREE.SphereGeometry(r, 8, 6), c, ...a);
export const CO = (r, h, s, c, ...a) => part(new THREE.ConeGeometry(r, h, s, 1, true), c, ...a);
export const MG = l => mergeGeometries(l);
export const vcMat = new THREE.MeshLambertMaterial({ vertexColors: true, flatShading: true });

// ---------- weapons (local space: -Z = forward, origin near the grip) ----------
const ST = 0x3b3f43, DK = 0x23272a, WD = 0x7b4a24, WDD = 0x5a3519;
const WG = {
  thompson: () => MG([BX(.07, .1, .4, ST, 0, 0, -.05), CY(.018, .018, .34, 6, DK, 0, .012, -.42, H), CY(.034, .034, .17, 8, ST, 0, .012, -.3, H), BX(.05, .03, .08, DK, 0, .035, -.62), BX(.05, .13, .06, WD, 0, -.11, -.27), BX(.05, .12, .06, WD, 0, -.1, .1, .25), BX(.055, .1, .3, WD, 0, -.025, .36, -.08), CY(.085, .085, .06, 12, DK, 0, -.14, -.06, 0, 0, H), BX(.02, .03, .04, DK, .045, .02, -.1)]),
  garand: () => MG([BX(.052, .085, .5, WDD, 0, -.02, .3), BX(.05, .06, .55, WD, 0, -.005, -.22), BX(.045, .03, .5, WD, 0, .04, -.22), BX(.045, .065, .22, ST, 0, .03, 0), CY(.011, .011, .45, 6, DK, 0, .035, -.65, H), BX(.01, .03, .01, DK, 0, .07, -.86), BX(.012, .02, .02, DK, 0, .065, .02), BX(.04, .04, .18, ST, 0, -.045, -.05)]),
  k98: () => MG([BX(.05, .08, .5, WD, 0, -.025, .3), BX(.045, .055, .7, WD, 0, -.01, -.3), BX(.04, .05, .18, ST, 0, .02, 0), CY(.01, .01, .6, 6, DK, 0, .03, -.75, H), CY(.006, .006, .1, 6, ST, .045, .02, .03, 0, 0, H), SP(.014, ST, .1, .02, .03), BX(.01, .03, .01, DK, 0, .062, -1.03)]),
  p38: () => MG([BX(.03, .04, .2, ST, 0, .03, -.08), BX(.034, .1, .05, DK, 0, -.05, .0, .2), CY(.009, .009, .08, 6, DK, 0, .03, -.22, H), BX(.01, .03, .06, ST, 0, -.02, -.03), BX(.036, .045, .05, WDD, 0, .02, .04)]),
};
const wc = {}; export const weaponGeo = id => wc[id] || (wc[id] = WG[id]());
const GRIP = { thompson: { l: [0, -.1, -.27], r: [0, -.09, .1], mz: -.68 }, garand: { l: [0, -.01, -.34], r: [0, -.03, .08], mz: -.9 }, k98: { l: [0, -.01, -.42], r: [0, -.03, .1], mz: -1.07 }, p38: { l: [0, -.07, -.02], r: [0, -.06, .02], mz: -.27 } };

// ---------- factions ----------
export const FAC = {
  allies: { name: 'US Infantry', jacket: 0x7a7648, jacketD: 0x5e5c38, pants: 0x5b4630, helm: 0x4e5a35, boot: 0x2c2218, gaiter: 0x8f8b66, web: 0x6a6540, skin: 0xd2a07a },
  axis: { name: 'Fallschirmjäger', jacket: 0x6f7a55, jacketD: 0x46583a, pants: 0x4b5448, helm: 0x59645a, boot: 0x1b1b1b, gaiter: 0x4b5448, web: 0x1f1f1f, skin: 0xd2a07a },
};
const SG = {};
function soldierGeos(fac) {
  if (SG[fac]) return SG[fac]; const f = FAC[fac], A = fac === 'allies';
  const torso = [BX(.6, .7, .34, f.jacket, 0, 1.18, 0), BX(.62, .26, .35, f.jacketD, 0, .9, 0), BX(.64, .06, .36, f.web, 0, .82, 0), BX(.1, .62, .36, f.web, -.17, 1.18, 0), BX(.1, .62, .36, f.web, .17, 1.18, 0),
    BX(.14, .13, .1, f.web, -.2, .93, -.2), BX(.14, .13, .1, f.web, .2, .93, -.2), BX(.42, .42, .16, f.jacketD, 0, 1.2, .25), BX(.24, .1, .22, f.jacket, 0, 1.55, 0), BX(.18, .12, .1, f.jacketD, 0, .92, .2), BX(.05, .05, .04, 0xb09a4a, 0, .83, -.19), BX(.5, .09, .06, f.web, 0, 1.28, -.18, 0, 0, .0), CY(.07, .07, .16, 8, A ? 0x7d7a52 : 0x3d4438, .3, .76, .12), BX(.12, .22, .05, 0x4a4a3a, -.3, .7, .12, 0, 0, .1), BX(.5, .12, .14, A ? 0x6a6038 : 0x4a4a42, 0, 1.52, .36), BX(.08, .35, .08, 0x55482e, .26, 1.34, .36, 0, 0, .3)];
  if (!A) torso.push(BX(.22, .24, .36, f.jacketD, .15, 1.3, 0), BX(.2, .2, .36, f.jacketD, -.18, 1.05, 0), BX(.64, .2, .36, f.jacket, 0, .72, 0)); // camo patches + smock skirt
  const helm = A ? [SP(.2, f.helm, 0, 1.82, 0, 0, 0, 0, 1.15, .78, 1.25), CY(.24, .24, .03, 10, f.helm, 0, 1.76, -.01), BX(.3, .03, .3, 0x3a4528, 0, 1.97, 0)]
    : [SP(.2, f.helm, 0, 1.82, 0, 0, 0, 0, 1.08, .82, 1.2), CY(.2, .24, .06, 10, f.helm, 0, 1.76, .02), BX(.04, .03, .3, 0x3c463e, 0, 1.97, 0)];
  const head = [BX(.26, .28, .26, f.skin, 0, 1.68, 0), BX(.05, .07, .05, 0xc08c68, 0, 1.66, -.15), BX(.05, .03, .02, 0x2a2420, -.06, 1.72, -.14), BX(.05, .03, .02, 0x2a2420, .06, 1.72, -.14), BX(.27, .06, .27, 0x3a352c, 0, 1.58, 0, .12, 0, 0), BX(.28, .035, .27, f.web, 0, 1.76, 0), ...helm, ...(A ? [BX(.03, .16, .03, 0x3a3a2c, -.12, 1.74, -.08), BX(.03, .16, .03, 0x3a3a2c, .12, 1.74, -.08), BX(.3, .03, .3, 0x6b7a4a, 0, 1.955, 0, 0, .6, 0)] : [BX(.34, .02, .34, 0x8a8a6a, 0, 1.968, 0, 0, .78, 0), BX(.3, .05, .06, 0x1a1a1a, 0, 1.78, -.14), CY(.03, .03, .05, 6, 0x4a5a6a, -.08, 1.78, -.17, H), CY(.03, .03, .05, 6, 0x4a5a6a, .08, 1.78, -.17, H)])];
  const leg = [BX(.22, .6, .26, f.pants, 0, -.3, 0), BX(.23, .2, .27, f.gaiter, 0, -.62, 0), BX(.25, .16, .36, f.boot, 0, -.77, -.05)];
  const arm = [BX(.16, .55, .16, f.jacket, 0, -.28, 0), BX(.12, .12, .12, f.skin, 0, -.6, 0)];
  return SG[fac] = { torso: MG(torso).translate(0, -1.1, 0), head: MG(head).translate(0, -1.7, 0), leg: MG(leg), arm: MG(arm) };
}
export function buildSoldier(fac, weapon) {
  const G = soldierGeos(fac), g = new THREE.Group();
  const mesh = (geo, x, y, z) => { const m = new THREE.Mesh(geo, vcMat); m.position.set(x, y, z); m.castShadow = true; g.add(m); return m; };
  const torso = mesh(G.torso, 0, 1.1, 0), head = mesh(G.head, 0, 1.7, 0), legL = mesh(G.leg, -.12, .85, 0), legR = mesh(G.leg, .12, .85, 0), armL = mesh(G.arm, -.38, 1.48, 0), armR = mesh(G.arm, .38, 1.48, 0), gun = mesh(weaponGeo(weapon), .08, 1.3, -.32);
  armL.rotation.set(1.4, 0, -.35); armR.rotation.set(1.15, 0, .15);
  const parts = [torso, head, legL, legR, armL, armR, gun];
  g.userData = { legL, legR, armL, armR, torso, head, gun, parts, ph: 0, rag: false, rest: parts.map(p => ({ pos: p.position.clone(), quat: p.quaternion.clone() })) };
  return g;
}
export function animateSoldier(g, speed, dt) {
  const u = g.userData; u.ph += speed * dt * 2.1; const a = Math.sin(u.ph) * Math.min(1, speed / 3) * .85;
  u.legL.rotation.x = a; u.legR.rotation.x = -a; if (u.head) u.head.position.y = 1.7 + Math.abs(Math.sin(u.ph)) * .035 * Math.min(1, speed / 3); u.torso.position.y = 1.1 + Math.abs(Math.sin(u.ph)) * .03 * Math.min(1, speed / 3);
}

// ---------- first-person viewmodel (weapon + sleeves + hands + muzzle flash) ----------
const armG = {}, flashMat = new THREE.MeshBasicMaterial({ color: 0xffd36b, transparent: true, opacity: .95, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide });
export function buildViewmodel(id, fac) {
  const f = FAC[fac], g = new THREE.Group(), gr = GRIP[id]; g.add(new THREE.Mesh(weaponGeo(id), vcMat));
  const ag = armG[fac] || (armG[fac] = MG([BX(.085, .085, .46, f.jacket, 0, 0, .26), BX(.095, .095, .12, f.skin, 0, 0, -.01), BX(.1, .1, .05, f.jacketD, 0, 0, .06)]));
  [[gr.l, -.18], [gr.r, .22]].forEach(([p, ry]) => { const a = new THREE.Mesh(ag, vcMat); a.position.set(...p); a.rotation.set(.42, ry, 0); g.add(a); });
  const fl = new THREE.Group(); fl.position.set(0, .02, gr.mz);
  for (const r of [0, H]) { const q = new THREE.Mesh(new THREE.PlaneGeometry(.3, .3), flashMat); q.rotation.z = r; q.position.z = -.06; fl.add(q); }
  const side = new THREE.Mesh(new THREE.PlaneGeometry(.3, .3), flashMat); side.rotation.y = H; fl.add(side); fl.visible = false; g.add(fl); g.userData.flash = fl; g.userData.mz = gr.mz; return g;
}

// ---------- M2 HMG emplacement ----------
export function buildHMG() {
  const base = new THREE.Mesh(MG([...[0, 2.1, 4.2].map(a => CY(.03, .03, 1.1, 5, ST, Math.sin(a) * .42, .52, Math.cos(a) * .42, Math.cos(a) * .5, 0, Math.sin(a) * -.5)), CY(.06, .06, .5, 8, DK, 0, 1.0, 0), BX(.22, .08, .26, ST, 0, 1.06, 0)]), vcMat);
  const gun = new THREE.Group(); gun.position.y = 1.2;
  gun.add(new THREE.Mesh(MG([BX(.2, .18, .62, ST, 0, 0, 0), CY(.05, .05, .6, 10, DK, 0, .02, -.6, H), CY(.025, .025, .35, 6, ST, 0, .02, -1.05, H), BX(.2, .03, .04, DK, 0, .04, .36), BX(.03, .12, .03, DK, -.08, .0, .38), BX(.03, .12, .03, DK, .08, 0, .38), BX(.28, .2, .14, 0x4d5530, -.26, -.06, -.02), BX(.03, .04, .22, 0xb59a42, -.14, -.02, -.02), BX(.04, .06, .08, ST, 0, .12, -.2)]), vcMat));
  base.castShadow = true; gun.children[0].castShadow = true; return { base, gun };
}

// ---------- dynamic props ----------
const PG = {};
export function propGeo(type) {
  if (PG[type]) return PG[type];
  if (type === 'crate') return PG[type] = MG([BX(1, .9, 1, 0x8a6236, 0, .45, 0), BX(1.04, .1, 1.04, 0x5e4122, 0, .08, 0), BX(1.04, .1, 1.04, 0x5e4122, 0, .82, 0), BX(.1, .92, 1.04, 0x5e4122, .45, .45, 0), BX(.1, .92, 1.04, 0x5e4122, -.45, .45, 0), BX(.5, .12, 1.02, 0xb0905a, 0, .45, 0, 0, 0, .8)]);
  const c = type === 'fuel' ? 0xa8372a : 0x56603a;
  return PG[type] = MG([CY(.42, .42, .95, 10, c, 0, .475, 0), CY(.44, .44, .06, 10, 0x2b2b2b, 0, .2, 0), CY(.44, .44, .06, 10, 0x2b2b2b, 0, .75, 0), CY(.3, .3, .03, 8, 0x1c1c1c, 0, .96, 0), ...(type === 'fuel' ? [BX(.2, .02, .02, 0xe8c04a, 0, .5, .43), BX(.02, .2, .02, 0xe8c04a, 0, .5, .43)] : [])]);
}
