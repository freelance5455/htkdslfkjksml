import * as THREE from 'three';
import { BX, CY, CO, SP, MG, vcMat } from './models.js';
import { WIND } from './fx.js';
// ---- WORLD: "Frostline Village" — one snowy winter map: village, farms, sawmill, pine forests, roads, ridgeline. ----
export const HALF = 140;
const WT = { value: 0 };
export const BASES = [new THREE.Vector3(100, 0, 95), new THREE.Vector3(-100, 0, -95)];
export const POINT_DEFS = [{ id: 'A', name: 'Mill Farm', x: 72, z: 52 }, { id: 'B', name: 'Logging Road', x: 35, z: -45 }, { id: 'C', name: 'Village Square', x: -5, z: 5 }, { id: 'D', name: 'Sawmill', x: -35, z: 45 }, { id: 'E', name: 'Orchard Farm', x: -72, z: -52 }];
export const HMG_DEFS = [{ x: 26, z: -34 }, { x: -26, z: 34 }];
const ROADS = [[[100, 95], [72, 52], [40, 20], [-5, 5], [-40, -20], [-72, -52], [-100, -95]], [[35, -45], [10, -20], [-5, 5], [-20, 30], [-35, 45]], [[-5, 5], [-5, -40], [-20, -90], [-50, -140]], [[-5, 5], [20, 60], [60, 110], [75, 140]]];
let seed = 20240; const rnd = () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0; let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
const FLAT = [...BASES.map(b => [b.x, b.z, 24]), ...POINT_DEFS.map(p => [p.x, p.z, 18]), [-5, 5, 34], ...HMG_DEFS.map(h => [h.x, h.z, 8])];
export function roadDist(x, z) {
  let best = 1e9; for (const r of ROADS) for (let i = 0; i < r.length - 1; i++) {
    const [ax, az] = r[i], [bx, bz] = r[i + 1], dx = bx - ax, dz = bz - az, t = Math.max(0, Math.min(1, ((x - ax) * dx + (z - az) * dz) / (dx * dx + dz * dz))); best = Math.min(best, Math.hypot(x - ax - dx * t, z - az - dz * t));
  } return best;
}
export function terrainH(x, z) {
  const h = 5 * Math.sin(x * .03 + 1) * Math.cos(z * .028) + 2.6 * Math.sin(x * .07) * Math.sin(z * .06 + 2) + 1.2 * Math.sin((x + z) * .13);
  let f = 1; for (const s of FLAT) { const t = Math.min(1, Math.max(0, (Math.hypot(x - s[0], z - s[1]) - s[2]) / 16)); f = Math.min(f, t * t * (3 - 2 * t)); } return h * f;
}
// ---- collision grid (coarse 10 m cells of AABBs) ----
const CELL = 10, grid = new Map(), EMPTY = []; export const colliders = [];
const gk = (cx, cz) => (cx + 40) * 100 + (cz + 40);
function addCollider(x0, x1, z0, z1, top) {
  const c = { x0, x1, z0, z1, top }; colliders.push(c);
  for (let cx = Math.floor((x0 - 1) / CELL); cx <= Math.floor((x1 + 1) / CELL); cx++) for (let cz = Math.floor((z0 - 1) / CELL); cz <= Math.floor((z1 + 1) / CELL); cz++) { const k = gk(cx, cz); let a = grid.get(k); if (!a) grid.set(k, a = []); a.push(c); }
}
const near = (x, z) => grid.get(gk(Math.floor(x / CELL), Math.floor(z / CELL))) || EMPTY;
export function groundAt(x, z, footY = 1e9) { let g = terrainH(x, z); for (const c of near(x, z)) if (x >= c.x0 && x <= c.x1 && z >= c.z0 && z <= c.z1 && c.top <= footY + .5 && c.top > g) g = c.top; return g; }
export function blockedAt(x, y, z) { if (y < terrainH(x, z)) return true; for (const c of near(x, z)) if (x >= c.x0 && x <= c.x1 && z >= c.z0 && z <= c.z1 && y < c.top) return true; return false; }
export function resolveXZ(p, r, footY) {
  for (const c of near(p.x, p.z)) {
    if (c.top <= footY + .5) continue; const cx = Math.max(c.x0, Math.min(p.x, c.x1)), cz = Math.max(c.z0, Math.min(p.z, c.z1)), dx = p.x - cx, dz = p.z - cz, d2 = dx * dx + dz * dz; if (d2 >= r * r) continue;
    if (d2 > 1e-8) { const d = Math.sqrt(d2), k = (r - d) / d; p.x += dx * k; p.z += dz * k; }
    else { const l = p.x - c.x0, rr = c.x1 - p.x, t = p.z - c.z0, b = c.z1 - p.z, m = Math.min(l, rr, t, b); if (m === l) p.x = c.x0 - r; else if (m === rr) p.x = c.x1 + r; else if (m === t) p.z = c.z0 - r; else p.z = c.z1 + r; }
  }
  p.x = Math.max(-HALF, Math.min(HALF, p.x)); p.z = Math.max(-HALF, Math.min(HALF, p.z));
}
const H = Math.PI / 2, SNOW = 0xf1f5f9;
export function buildWorld(scene, quality) {
  const hemi = new THREE.HemisphereLight(0xe2ecf8, 0x8b97aa, .95), sun = new THREE.DirectionalLight(0xfff0d6, 1.2), fill = new THREE.DirectionalLight(0x9db6dc, .28); scene.add(hemi, fill);
  scene.background = new THREE.Color(0xc5d0dc); scene.fog = new THREE.Fog(0xc5d0dc, 70, 330);
  const sunOffset = new THREE.Vector3(-90, 70, 50); sun.position.copy(sunOffset); fill.position.set(80, 30, -60);
  const sm = { low: 512, medium: 1024, high: 2048 }[quality] || 1024; sun.shadow.mapSize.set(sm, sm); sun.shadow.bias = -.0006; sun.shadow.normalBias = .03; const sc = sun.shadow.camera; sc.left = sc.bottom = -60; sc.right = sc.top = 60; sc.near = 10; sc.far = 300; scene.add(sun, sun.target);
  // sky dome (vertex gradient + sun-side glow), sun/moon discs, drifting clouds, night stars
  const SKR = 450, sk = new THREE.SphereGeometry(SKR, 24, 14), sp = sk.attributes.position, sc2 = new Float32Array(sp.count * 3); sk.setAttribute('color', new THREE.BufferAttribute(sc2, 3));
  const skyMesh = new THREE.Mesh(sk, new THREE.MeshBasicMaterial({ vertexColors: true, side: THREE.BackSide, fog: false, depthWrite: false })); skyMesh.renderOrder = -10; scene.add(skyMesh);
  const glow = (a, b) => { const cv = document.createElement('canvas'); cv.width = cv.height = 128; const x = cv.getContext('2d'), g = x.createRadialGradient(64, 64, 0, 64, 64, 64); g.addColorStop(0, a); g.addColorStop(.18, a); g.addColorStop(.5, b); g.addColorStop(1, 'rgba(255,255,255,0)'); x.fillStyle = g; x.fillRect(0, 0, 128, 128); const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; return t; };
  const sunSpr = new THREE.Sprite(new THREE.SpriteMaterial({ map: glow('rgba(255,248,225,1)', 'rgba(255,220,150,.35)'), fog: false, depthWrite: false, transparent: true, blending: THREE.AdditiveBlending })); sunSpr.scale.set(150, 150, 1); sunSpr.renderOrder = -9; scene.add(sunSpr);
  const moonSpr = new THREE.Sprite(new THREE.SpriteMaterial({ map: glow('rgba(225,235,255,1)', 'rgba(150,170,220,.25)'), fog: false, depthWrite: false, transparent: true })); moonSpr.scale.set(60, 60, 1); moonSpr.renderOrder = -9; scene.add(moonSpr);
  const cloudTex = (() => { const cv = document.createElement('canvas'); cv.width = 256; cv.height = 128; const x = cv.getContext('2d'); for (let i = 0; i < 26; i++) { const cx = 40 + rnd() * 176, cy = 44 + rnd() * 40, r = 18 + rnd() * 34, g = x.createRadialGradient(cx, cy, 0, cx, cy, r); g.addColorStop(0, 'rgba(255,255,255,.55)'); g.addColorStop(1, 'rgba(255,255,255,0)'); x.fillStyle = g; x.fillRect(0, 0, 256, 128); } const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; return t; })();
  const clouds = new THREE.Group(), cloudMats = []; for (let i = 0; i < 12; i++) { const m = new THREE.SpriteMaterial({ map: cloudTex, fog: false, depthWrite: false, transparent: true, opacity: .55 }), spr = new THREE.Sprite(m), a = i / 12 * 6.283 + rnd() * .3, el = .16 + rnd() * .22; spr.position.set(Math.cos(a) * Math.cos(el) * 400, Math.sin(el) * 400, Math.sin(a) * Math.cos(el) * 400); spr.scale.set(190 + rnd() * 120, 70 + rnd() * 30, 1); spr.renderOrder = -8; clouds.add(spr); cloudMats.push(m); } scene.add(clouds);
  const starPos = new Float32Array(420 * 3); for (let i = 0; i < 420; i++) { const a = rnd() * 6.283, el = .1 + rnd() * 1.4, r = 430; starPos.set([Math.cos(a) * Math.cos(el) * r, Math.sin(el) * r, Math.sin(a) * Math.cos(el) * r], i * 3); }
  const sg = new THREE.BufferGeometry(); sg.setAttribute('position', new THREE.BufferAttribute(starPos, 3)); const stars = new THREE.Points(sg, new THREE.PointsMaterial({ color: 0xdde8ff, size: 1.8, sizeAttenuation: false, fog: false, depthWrite: false, transparent: true, opacity: .9 })); stars.renderOrder = -9; scene.add(stars);
  const TOD = {
    day: { top: 0x7f9bbc, hor: 0xd5dde6, fog: 0xc5d0dc, grey: 0xb9c1c9, hs: 0xe2ecf8, hg: 0x8b97aa, hi: .95, sun: 0xfff0d6, si: 1.2, off: [-90, 70, 50], expo: 1.05, fillI: .28 },
    dusk: { top: 0x3e4a7a, hor: 0xf0a374, fog: 0xc9998a, grey: 0x9b8b8a, hs: 0xf0b898, hg: 0x5a5470, hi: .78, sun: 0xff9a4e, si: 1.3, off: [-130, 20, 60], expo: 1.0, fillI: .34 },
    night: { top: 0x050914, hor: 0x1b2a46, fog: 0x131c2e, grey: 0x1b2434, hs: 0x5470a8, hg: 0x1c2438, hi: .8, sun: 0x9ab8ff, si: .55, off: [-60, 85, 30], expo: 1.3, fillI: .2 },
  };
  const WX = { clear: { near: 100, far: 400, wf: 0, snow: { amount: 0, fall: 1, size: .07, alpha: .85 }, wind: [.8, .2], cloud: .35 }, snow: { near: 70, far: 330, wf: .3, snow: { amount: .55, fall: 1, size: .07, alpha: .85 }, wind: [1.6, .5], cloud: .6 }, blizzard: { near: 8, far: 140, wf: .85, snow: { amount: 1, fall: 1.6, size: .095, alpha: .92 }, wind: [9, 3.2], cloud: .9 } };
  const c = new THREE.Color(), cA = new THREE.Color(), cB = new THREE.Color(), cC = new THREE.Color(), sd = new THREE.Vector3();
  function applyEnv(todId = 'day', wxId = 'snow') {
    const T = TOD[todId] || TOD.day, W = WX[wxId] || WX.snow; sd.set(...T.off).normalize(); cC.setHex(T.grey);
    for (let i = 0; i < sp.count; i++) { const x = sp.getX(i), y = sp.getY(i), z = sp.getZ(i); cA.setHex(T.hor).lerp(cB.setHex(T.top), Math.pow(Math.max(0, y / SKR), .6)); const dl = Math.max(0, (x * sd.x + y * sd.y + z * sd.z) / SKR); if (todId !== 'night') cA.lerp(cB.setHex(T.sun), Math.pow(dl, 10) * .6); cA.lerp(cC, W.wf * (.7 - .5 * Math.max(0, y / SKR))); sc2[i * 3] = cA.r; sc2[i * 3 + 1] = cA.g; sc2[i * 3 + 2] = cA.b; }
    sk.attributes.color.needsUpdate = true; cA.setHex(T.fog).lerp(cC, W.wf); scene.background = cA.clone(); scene.fog.color.copy(cA); scene.fog.near = W.near; scene.fog.far = W.far;
    hemi.color.setHex(T.hs); hemi.groundColor.setHex(T.hg); hemi.intensity = T.hi; sun.color.setHex(T.sun); sun.intensity = T.si * (1 - W.wf * .55); fill.intensity = T.fillI; sunOffset.set(...T.off); sun.position.copy(sunOffset);
    sunSpr.position.copy(sd).multiplyScalar(420); sunSpr.visible = todId !== 'night' && W.wf < .6; sunSpr.material.opacity = 1 - W.wf; sunSpr.material.color.setHex(todId === 'dusk' ? 0xff9a5a : 0xffffff);
    moonSpr.position.set(-sd.x * 0 + 150, 330, -250).normalize().multiplyScalar(420); moonSpr.visible = todId === 'night' && W.wf < .6; stars.visible = todId === 'night' && W.wf < .5;
    cloudMats.forEach(m => { m.opacity = W.cloud * (todId === 'night' ? .18 : 1) * .6; m.color.setHex(todId === 'dusk' ? 0xffc0a0 : todId === 'night' ? 0x6070a0 : 0xffffff); });
    WIND.x = W.wind[0]; WIND.z = W.wind[1]; return { snow: W.snow, expo: T.expo, night: todId === 'night' };
  }
  // terrain: snow with packed-snow roads painted into vertex colours
  const geo = new THREE.PlaneGeometry(2 * HALF + 40, 2 * HALF + 40, 120, 120); geo.rotateX(-H);
  const pos = geo.attributes.position, col = new Float32Array(pos.count * 3);
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i), z = pos.getZ(i), h = terrainH(x, z); pos.setY(i, h); const rd = roadDist(x, z), t = 1 - Math.min(1, Math.max(0, (rd - 2.8) / 3)), n = rnd() * .04 + Math.sin(x * .11 + z * .07) * Math.cos(z * .09 - x * .05) * .035 + Math.sin(x * .9 + z * .4) * .012;
    const sn = .74 + n + Math.min(.06, h * .008), r = sn * (1 - t) + .46 * t, g = (sn + .02) * (1 - t) + .47 * t, b = (sn + .05) * (1 - t) + .5 * t; col.set([r, g, b], i * 3);
  }
  geo.setAttribute('color', new THREE.BufferAttribute(col, 3)); geo.computeVertexNormals();
  const gtex = (() => { const cv = document.createElement('canvas'); cv.width = cv.height = 256; const x = cv.getContext('2d'); x.fillStyle = '#e8ecf2'; x.fillRect(0, 0, 256, 256); for (let i = 0; i < 2600; i++) { const v = 205 + rnd() * 50 | 0; x.fillStyle = `rgba(${v},${v + 3},${v + 8},${.25 + rnd() * .4})`; const r = .6 + rnd() * 2.2; x.beginPath(); x.arc(rnd() * 256 + 128, rnd() * 256 + 128, r, 0, 6.283); x.fill(); } for (let i = 0; i < 900; i++) { x.fillStyle = 'rgba(255,255,255,.9)'; x.fillRect(rnd() * 256 + 128, rnd() * 256 + 128, 1, 1); } const t = new THREE.CanvasTexture(cv); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(70, 70); t.anisotropy = 4; t.colorSpace = THREE.SRGBColorSpace; return t; })();
  const ground = new THREE.Mesh(geo, new THREE.MeshLambertMaterial({ vertexColors: true, flatShading: true, map: gtex })); ground.receiveShadow = true; scene.add(ground);
  // ---- buildings (all merged into one mesh) ----
  const P = [], rects = [], smokers = [], walls = [0x8a6a4a, 0x9c8f7a, 0xa8553f, 0x7e8a8f, 0xb09a72];
  const house = (x, z, w, d, h, kind = 'house') => {
    const x0 = x - w / 2, x1 = x + w / 2, z0 = z - d / 2, z1 = z + d / 2, hs = [terrainH(x0, z0), terrainH(x1, z0), terrainH(x0, z1), terrainH(x1, z1)], base = Math.max(...hs), low = Math.min(...hs) - .6, top = base + h;
    const wc = kind === 'barn' ? 0x8f3a2c : kind === 'church' ? 0xc9c2b0 : walls[(rnd() * walls.length) | 0], rh = kind === 'barn' ? 3.4 : kind === 'church' ? 3.5 : 2.7;
    P.push(BX(w, top - low, d, wc, x, (top + low) / 2, z), BX(w + 1.6, .3, d + 1.6, SNOW, x, base + .1, z));
    P.push(CO(.7071, 1, 4, 0x4a3426, x, top + rh / 2 - .05, z, 0, H / 2, 0, w * 1.14, rh, d * 1.14), CO(.7071, 1, 4, SNOW, x, top + rh / 2 + .13, z, 0, H / 2, 0, w * 1.12, rh, d * 1.12));
    const nw = Math.max(1, Math.floor(w / 3.2)), nd = Math.max(1, Math.floor(d / 3.5)), wy = base + h * .55;
    for (let i = 0; i < nw; i++) { const wx = x0 + (i + .5) * w / nw, lit = rnd() < .3 ? 0xe2b95c : 0x2a3441; P.push(BX(1, 1.1, .12, lit, wx, wy, z1 + .02), BX(1.2, .12, .16, SNOW, wx, wy + .62, z1 + .03), BX(1, 1.1, .12, 0x2a3441, wx, wy, z0 - .02)); }
    for (let i = 0; i < nd; i++) { const wz = z0 + (i + .5) * d / nd; P.push(BX(.12, 1.1, 1, 0x2a3441, x1 + .02, wy, wz), BX(.12, 1.1, 1, 0x2a3441, x0 - .02, wy, wz)); }
    P.push(BX(kind === 'barn' ? 3.6 : 1.3, kind === 'barn' ? 3.6 : 2.2, .14, 0x3a2a1e, x, base + (kind === 'barn' ? 1.8 : 1.1), z1 + .04));
    if (kind !== 'barn') { P.push(BX(.8, 2, .8, 0x5a4a44, x + w * .25, top + rh * .75, z), BX(1, .15, 1, SNOW, x + w * .25, top + rh * .75 + 1.05, z)); if (rnd() < .75) smokers.push([x + w * .25, top + rh * .75 + 1.15, z]); }
    if (kind === 'church') { P.push(BX(4, h + 5, 4, wc, x, base + (h + 5) / 2, z0 + 2), BX(4.4, .3, 4.4, SNOW, x, base + h + 5.1, z0 + 2), CO(2.9, 6, 4, 0x3a3a40, x, base + h + 8.1, z0 + 2, 0, H / 2, 0), CO(2.7, 5.8, 4, SNOW, x, base + h + 8.35, z0 + 2, 0, H / 2, 0), BX(.12, 1.4, .12, 0x222222, x, base + h + 11.7, z0 + 2)); }
    addCollider(x0, x1, z0, z1, top); rects.push([x0 - 3, x1 + 3, z0 - 3, z1 + 3]);
  };
  const HOUSES = [[-24, -8, 9, 7, 5], [-22, 16, 8, 8, 5], [12, -6, 8, 7, 5], [14, 18, 9, 7, 5], [-5, -24, 8, 14, 7, 'church'], [0, 34, 10, 7, 5], [-40, 0, 8, 7, 4.5], [30, 5, 8, 8, 5], [84, 40, 12, 9, 6, 'barn'], [58, 66, 9, 7, 5], [-84, -40, 12, 9, 6, 'barn'], [-58, -66, 9, 7, 5], [48, -54, 7, 6, 4], [24, -60, 7, 6, 4], [-48, 54, 7, 6, 4], [-24, 60, 7, 6, 4], [48, -30, 12, 7, 4.5, 'barn'], [-48, 30, 12, 7, 4.5, 'barn'], [-82, 42, 8, 7, 5], [82, -42, 8, 7, 5]];
  HOUSES.forEach(h => house(...h));
  const inRect = (x, z, e = 0) => rects.some(r => x > r[0] - e && x < r[1] + e && z > r[2] - e && z < r[3] + e);
  // ---- set dressing: snow drifts against walls, woodpiles, lamp posts, shrubs ----
  for (let i = 0; i < 70; i++) { const h = HOUSES[(rnd() * HOUSES.length) | 0], side = (rnd() * 4) | 0, ox = side < 2 ? (side ? 1 : -1) * (h[2] / 2 + .6) : (rnd() - .5) * h[2], oz = side >= 2 ? (side === 2 ? 1 : -1) * (h[3] / 2 + .6) : (rnd() - .5) * h[3], x = h[0] + ox, z = h[1] + oz, r = .7 + rnd() * 1.1; if (roadDist(x, z) < 3) continue; P.push(SP(r, SNOW, x, terrainH(x, z) + r * .1, z, 0, rnd() * 3, 0, 1.5 + rnd(), .45 + rnd() * .3, 1)); }
  for (const h of HOUSES.slice(0, 14)) { if (rnd() < .4) continue; const x = h[0] + h[2] / 2 + 1.6, z = h[1] + (rnd() - .5) * h[3] * .6, g = terrainH(x, z); if (roadDist(x, z) < 3.5) continue; for (let r = 0; r < 3; r++) for (let k = 0; k < 4 - r; k++) P.push(CY(.17, .17, 1.6, 7, r % 2 ? 0x6a4a2c : 0x7a5632, x + (k + r * .5) * .36, g + .2 + r * .31, z, H, 0, 0)); P.push(BX(1.7, .1, 1.6, SNOW, x + .6, g + 1.0, z)); addCollider(x - .2, x + 1.5, z - .8, z + .8, g + .95); }
  const LAMPS = [[100, 95], [72, 52], [40, 20], [-5, 5], [-40, -20], [-72, -52], [-100, -95], [35, -45], [-20, 30], [-5, -40], [20, 60]]; for (const [lx, lz] of LAMPS) for (const [dx, dz] of [[3.4, 3.4], [-3.4, -3.4]]) { const x = lx + dx, z = lz + dz, g = terrainH(x, z); if (inRect(x, z)) continue; P.push(CY(.07, .09, 4.2, 6, 0x2e2a26, x, g + 2.1, z), BX(.5, .08, .08, 0x2e2a26, x + .2, g + 4.15, z), BX(.22, .26, .22, 0xffe3a0, x + .42, g + 3.98, z), BX(.34, .06, .34, SNOW, x + .42, g + 4.16, z)); }
  for (let i = 0; i < 60; i++) { const x = (rnd() - .5) * 250, z = (rnd() - .5) * 250, g = terrainH(x, z); if (inRect(x, z, 1) || roadDist(x, z) < 4 || BASES.some(b => Math.hypot(x - b.x, z - b.z) < 14) || POINT_DEFS.some(p => Math.hypot(x - p.x, z - p.z) < 9)) continue; const r = .5 + rnd() * .6; P.push(SP(r, 0x2f4a36, x, g + r * .55, z, 0, 0, 0, 1.3, .8, 1.1), SP(r * .8, SNOW, x, g + r * .95, z, 0, 0, 0, 1.2, .35, 1)); }
  // ---- static cover: sandbags, hedgehogs, hay bales, stone walls, fences ----
  const pieces = [], kinds = ['sand', 'sand', 'hedge', 'hay', 'wall'];
  const cover = (k, x, z, horiz) => {
    if (Math.abs(x) > 130 || Math.abs(z) > 130 || inRect(x, z) || roadDist(x, z) < 3) return; const g = terrainH(x, z); let w, h, d;
    if (k === 'sand') { [w, h, d] = horiz ? [4.6, 1.1, 1.1] : [1.1, 1.1, 4.6]; P.push(BX(w, .55, d, 0xb8a67f, x, g + .27, z), BX(horiz ? w - .6 : w, .55, horiz ? d : d - .6, 0xa8966f, x, g + .82, z), BX(w + .1, .1, d + .1, SNOW, x, g + 1.12, z)); }
    else if (k === 'wall') { [w, h, d] = horiz ? [5, 1.2, .6] : [.6, 1.2, 5]; P.push(BX(w, h, d, 0x8a8780, x, g + h / 2, z), BX(w + .1, .14, d + .1, SNOW, x, g + h + .05, z)); }
    else if (k === 'hay') { w = d = 1.6; h = 1.5; P.push(CY(.8, .8, 1.5, 10, 0xc4a85a, x, g + .75, z, 0, 0, H), BX(1.6, .12, 1.6, SNOW, x, g + 1.5, z)); }
    else { w = d = 1.3; h = 1.3; P.push(BX(2.2, .16, .16, 0x35383a, x, g + .65, z, 0, 0, .78), BX(2.2, .16, .16, 0x35383a, x, g + .65, z, 0, 0, -.78), BX(.16, .16, 2.2, 0x35383a, x, g + .65, z, .78, 0, 0), BX(2.2, .1, .1, SNOW, x, g + 1.4, z)); }
    addCollider(x - w / 2, x + w / 2, z - d / 2, z + d / 2, g + h); pieces.push([x, z]);
  };
  for (const p of POINT_DEFS) for (let i = 0; i < 9; i++) { const a = rnd() * 6.283, r = 5 + rnd() * 9; cover(kinds[(rnd() * 5) | 0], p.x + Math.cos(a) * r, p.z + Math.sin(a) * r, rnd() < .5); }
  for (const b of BASES) for (let i = 0; i < 8; i++) { const a = rnd() * 6.283, r = 9 + rnd() * 10; cover(kinds[(rnd() * 5) | 0], b.x + Math.cos(a) * r, b.z + Math.sin(a) * r, rnd() < .5); }
  for (const h of HMG_DEFS) { const a = Math.atan2(-h.x, h.z); for (let k = -2; k <= 2; k++) if (k) cover('sand', h.x + Math.cos(a) * k * 2.4 + Math.sin(a) * 2.4, h.z + Math.sin(a) * k * 2.4 - Math.cos(a) * 2.4, Math.abs(Math.cos(a)) > .7); }
  for (let i = 0; i < 50; i++) cover(kinds[(rnd() * 5) | 0], (rnd() - .5) * 250, (rnd() - .5) * 250, rnd() < .5);
  // farm fences
  for (const f of [[72, 52], [-72, -52]]) for (let i = -4; i <= 4; i++) { const x = f.x ?? f[0], z = f[1]; P.push(BX(.14, 1, .14, 0x5a4330, x + i * 3 - 5, terrainH(x + i * 3 - 5, z + 14) + .5, z + 14), BX(3, .1, .1, 0x5a4330, x + i * 3 - 3.5, terrainH(x + i * 3 - 3.5, z + 14) + .8, z + 14), BX(3, .12, .1, SNOW, x + i * 3 - 3.5, terrainH(x + i * 3 - 3.5, z + 14) + .9, z + 14)); }
  // base camps: canvas tents + flagpole
  const baseBanners = [];
  BASES.forEach((b, bi) => { for (let k = 0; k < 3; k++) { const a = k * 2.1 + bi, x = b.x + Math.cos(a) * 11, z = b.z + Math.sin(a) * 11, g = terrainH(x, z); P.push(CO(.7071, 1, 4, 0x8c8d68, x, g + 1.6, z, 0, H / 2, 0, 5, 3.2, 4), CO(.7071, 1, 4, SNOW, x, g + 1.8, z, 0, H / 2, 0, 4.8, 3, 3.8)); addCollider(x - 2, x + 2, z - 1.6, z + 1.6, g + 1.4); }
    P.push(CY(.1, .1, 8, 6, 0xdddddd, b.x, 4, b.z)); const bm = new THREE.Mesh(new THREE.BoxGeometry(2.4, 1.5, .08), new THREE.MeshLambertMaterial({ color: 0x5aa03c })); bm.position.set(b.x + 1.3, 7, b.z); scene.add(bm); baseBanners.push(bm); });
  const bm = new THREE.Mesh(MG(P), vcMat); bm.castShadow = bm.receiveShadow = true; scene.add(bm);
  // ---- pine forests: ONE instanced mesh. Clusters follow the reference map (big woods W/N/NE/SE, light cover in the open). ----
  const W = SNOW, pine = MG([CY(.18, .28, 1.8, 5, 0x4a3524, 0, .9, 0), CO(1.9, 2.8, 6, 0x2a473a, 0, 2.5, 0), CO(1.78, 2.5, 6, W, 0, 2.72, 0), CO(1.45, 2.4, 6, 0x2f4d3f, 0, 3.8, 0), CO(1.35, 2.1, 6, W, 0, 3.98, 0), CO(1.0, 2.0, 6, 0x355644, 0, 5.0, 0), CO(.92, 1.7, 6, W, 0, 5.18, 0)]);
  const nT = { low: 200, medium: 340, high: 520 }[quality] || 340, CL = [[-100, -60, 30], [-30, -118, 34], [100, -110, 30], [-120, 50, 24], [125, 5, 26], [110, 95, 18], [-20, 100, 20], [60, -90, 22], [-60, 110, 18], [8, -75, 14]], spots = [];
  for (let t = 0; t < 3000 && spots.length < nT; t++) {
    const cl = CL[(rnd() * CL.length) | 0], a = rnd() * 6.283, r = Math.sqrt(rnd()) * cl[2] * (rnd() < .85 ? 1 : 3), x = cl[0] + Math.cos(a) * r, z = cl[1] + Math.sin(a) * r;
    if (Math.abs(x) > 134 || Math.abs(z) > 134 || BASES.some(b => Math.hypot(x - b.x, z - b.z) < 28) || POINT_DEFS.some(p => Math.hypot(x - p.x, z - p.z) < 16) || HMG_DEFS.some(h => Math.hypot(x - h.x, z - h.z) < 8) || roadDist(x, z) < 5 || inRect(x, z, 2) || pieces.some(p => Math.abs(p[0] - x) < 3 && Math.abs(p[1] - z) < 3)) continue; spots.push([x, z, .8 + rnd() * .7]);
  }
  const treeMat = vcMat.clone(); treeMat.onBeforeCompile = sh => { sh.uniforms.uWT = WT; sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nuniform float uWT;').replace('#include <begin_vertex>', '#include <begin_vertex>\nfloat ph=instanceMatrix[3].x*.15+instanceMatrix[3].z*.11;float swy=smoothstep(1.5,6.,position.y);transformed.x+=(sin(uWT*1.4+ph)*.12+sin(uWT*3.1+ph*2.)*.035)*swy;transformed.z+=cos(uWT*1.1+ph)*.08*swy;'); };
  const trees = new THREE.InstancedMesh(pine, treeMat, spots.length), mtx = new THREE.Matrix4(), q = new THREE.Quaternion(), sv = new THREE.Vector3(), pv = new THREE.Vector3();
  spots.forEach(([x, z, s], i) => { mtx.compose(pv.set(x, terrainH(x, z) - .1, z), q.setFromAxisAngle(new THREE.Vector3(0, 1, 0), rnd() * 6.28), sv.set(s, s * (.9 + rnd() * .3), s)); trees.setMatrixAt(i, mtx); trees.setColorAt(i, c.setScalar(.82 + rnd() * .18)); addCollider(x - .4, x + .4, z - .4, z + .4, terrainH(x, z) + 30); });
  trees.castShadow = true; scene.add(trees);
  // ridgeline of snowy mountains (decor)
  const mt = []; for (let i = 0; i < 22; i++) { const a = i / 22 * 6.283, h = 55 + rnd() * 70, r = 50 + rnd() * 30, x = Math.cos(a) * 260, z = Math.sin(a) * 260; mt.push(CO(r, h, 5, 0x77828f, x, h / 2 - 8, z), CO(r * .55, h * .45, 5, SNOW, x, h * .78 - 8, z)); }
  scene.add(new THREE.Mesh(MG(mt), new THREE.MeshLambertMaterial({ vertexColors: true, flatShading: true })));
  // dynamic-prop spawn spots (barrels/crates) for physics
  const propSpots = []; for (const p of POINT_DEFS) { for (let i = 0; i < 3; i++) { const a = rnd() * 6.283, r = 4 + rnd() * 8; propSpots.push({ type: i === 0 ? 'fuel' : 'drum', x: p.x + Math.cos(a) * r, z: p.z + Math.sin(a) * r }); } for (let i = 0; i < 3; i++) { const a = rnd() * 6.283, r = 4 + rnd() * 9; propSpots.push({ type: 'crate', x: p.x + Math.cos(a) * r, z: p.z + Math.sin(a) * r }); } }
  for (const b of BASES) for (let i = 0; i < 4; i++) propSpots.push({ type: i < 2 ? 'crate' : 'fuel', x: b.x + (rnd() - .5) * 26, z: b.z + (rnd() - .5) * 26 });
  const world = { sun, sunOffset, ground, baseBanners, smokers, applyEnv, update(t, gust) { WT.value = t; WIND.gust = gust; }, propSpots: propSpots.filter(s => !inRect(s.x, s.z) && roadDist(s.x, s.z) > 2.5) };
  return world;
}
