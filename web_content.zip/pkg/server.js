'use strict';
/*
  Resume44 server (no npm packages needed, Node 18+).
  - Serves the app at /            (public/index.html)
  - Serves the admin at /admin     (public/admin.html)  -> every admin API call needs a signed admin token
  - /api/ai proxies to Anthropic so your API key never reaches the browser
*/
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = +process.env.PORT || 3000;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');
const PUBLIC = path.join(__dirname, 'public');
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || ''; // only if the app is hosted on a different domain
const AI_KEY = process.env.ANTHROPIC_API_KEY || '';
const AI_MODEL = process.env.AI_MODEL || 'claude-sonnet-5-5';
const ADMIN_USER = process.env.ADMIN_USER || 'admin';
const MAX_EVENTS = 100000;

/* ---------- tiny JSON database ---------- */
fs.mkdirSync(DATA_DIR, { recursive: true });
let db = { users: [], events: [], templates: [], secret: '', admin: null };
try { db = Object.assign(db, JSON.parse(fs.readFileSync(DB_FILE, 'utf8'))); } catch (e) {}
let dirty = false;
const save = () => { dirty = true; };
function flush() {
  if (!dirty) return;
  dirty = false;
  const tmp = DB_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db));
  fs.renameSync(tmp, DB_FILE);
}
setInterval(flush, 2000).unref();
['SIGINT', 'SIGTERM'].forEach(s => process.on(s, () => { flush(); process.exit(0); }));

/* ---------- passwords and tokens ---------- */
const hashPw = (pw, salt) => crypto.scryptSync(String(pw), salt, 64).toString('hex');
const same = (a, b) => { a = Buffer.from(String(a)); b = Buffer.from(String(b)); return a.length === b.length && crypto.timingSafeEqual(a, b); };
if (!db.secret) { db.secret = crypto.randomBytes(32).toString('hex'); save(); }

(function setupAdmin() {
  let pw = process.env.ADMIN_PASSWORD || '';
  if (pw) {
    if (pw.length < 10) { console.error('ADMIN_PASSWORD must be at least 10 characters.'); process.exit(1); }
    const salt = crypto.randomBytes(16).toString('hex');
    db.admin = { user: ADMIN_USER, salt, hash: hashPw(pw, salt) };
    save();
  } else if (!db.admin) {
    pw = crypto.randomBytes(9).toString('base64url');
    const salt = crypto.randomBytes(16).toString('hex');
    db.admin = { user: ADMIN_USER, salt, hash: hashPw(pw, salt) };
    save();
    console.log('\n  No ADMIN_PASSWORD set. A one-time admin login was created:');
    console.log('  username: ' + ADMIN_USER + '\n  password: ' + pw + '\n  Set ADMIN_PASSWORD to choose your own.\n');
  }
})();

function sign(payload) {
  const b = Buffer.from(JSON.stringify(payload)).toString('base64url');
  return b + '.' + crypto.createHmac('sha256', db.secret).update(b).digest('base64url');
}
function verify(tok) {
  if (!tok || typeof tok !== 'string') return null;
  const [b, s] = tok.split('.');
  if (!b || !s) return null;
  const good = crypto.createHmac('sha256', db.secret).update(b).digest('base64url');
  if (!same(s, good)) return null;
  try {
    const p = JSON.parse(Buffer.from(b, 'base64url').toString());
    return p.exp > Date.now() ? p : null;
  } catch (e) { return null; }
}
const bearer = req => { const h = req.headers.authorization || ''; return h.startsWith('Bearer ') ? h.slice(7) : ''; };
const userOf = req => { const p = verify(bearer(req)); return p && p.role === 'user' ? db.users.find(u => u.id === p.sub) || null : null; };
const isAdmin = req => { const p = verify(bearer(req)); return !!(p && p.role === 'admin'); };

/* ---------- rate limiting ---------- */
const hits = new Map();
function limited(key, max, win) {
  const now = Date.now();
  const a = (hits.get(key) || []).filter(t => now - t < win);
  if (a.length >= max) { hits.set(key, a); return true; }
  a.push(now); hits.set(key, a); return false;
}
setInterval(() => { const n = Date.now(); for (const [k, a] of hits) if (!a.length || n - a[a.length - 1] > 3600e3) hits.delete(k); }, 600e3).unref();
const ipOf = req => {
  const x = process.env.TRUST_PROXY === '1' && req.headers['x-forwarded-for'];
  return (x ? String(x).split(',')[0].trim() : req.socket.remoteAddress) || '?';
};

/* ---------- helpers ---------- */
function readBody(req, limit) {
  return new Promise((res, rej) => {
    let n = 0; const ch = [];
    req.on('data', c => { n += c.length; if (n > limit) { rej(Object.assign(new Error('too big'), { status: 413 })); req.destroy(); } else ch.push(c); });
    req.on('end', () => { try { res(ch.length ? JSON.parse(Buffer.concat(ch).toString()) : {}); } catch (e) { rej(Object.assign(new Error('bad json'), { status: 400 })); } });
    req.on('error', rej);
  });
}
function send(res, code, obj, headers) {
  res.writeHead(code, Object.assign({ 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }, headers || {}));
  res.end(JSON.stringify(obj));
}
const str = (v, n) => String(v == null ? '' : v).trim().slice(0, n);
const uid = () => crypto.randomBytes(6).toString('hex');
const EMAIL = /^[^\s@]{1,64}@[^\s@]{1,190}\.[^\s@]{2,}$/;

const HEADS = ['text', 'underline', 'bar', 'tint', 'marker'];
const FLAGS = ['fresher', 'photo', 'eduTable', 'skillsCheck', 'nameLine', 'thick', 'caps', 'profile', 'declaration'];
function cleanTheme(t) {
  t = t || {};
  const o = {
    accent: /^#[0-9a-f]{6}$/i.test(t.accent || '') ? t.accent : '#1d5be0',
    head: HEADS.includes(t.head) ? t.head : 'underline',
    font: t.font === 'serif' ? 'serif' : 'sans',
    align: t.align === 'center' ? 'center' : 'left'
  };
  FLAGS.forEach(k => { o[k] = !!t[k]; });
  return o;
}
const BUILTIN = { modern: 'Modern Blue', classic: 'Classic Serif', bar: 'Highlight Bar', tint: 'Soft Highlight', marker: 'Marker', fresher: 'Fresher Classic', fresherBar: 'Fresher Highlight', fresherTint: 'Fresher Soft', fresherMarker: 'Fresher Marker', custom: 'Custom theme', shared: 'Shared by friends' };
const EVENT_TYPES = new Set(['visit', 'resume_created', 'resume_uploaded', 'resume_edited', 'resume_saved', 'pdf_download', 'pdf_failed', 'image_upload', 'upload_failed', 'ats_check', 'ai_request', 'ai_failed', 'template_used', 'error']);
const ERROR_TYPES = new Set(['error', 'pdf_failed', 'ai_failed', 'upload_failed']);

/* ---------- statistics ---------- */
function computeStats() {
  const ev = db.events, now = Date.now();
  const tot = {};
  for (const e of ev) tot[e.type] = (tot[e.type] || 0) + 1;
  const dayKey = t => new Date(t).toISOString().slice(0, 10);
  const wkKey = t => { const d = new Date(t); d.setUTCDate(d.getUTCDate() - ((d.getUTCDay() + 6) % 7)); return d.toISOString().slice(0, 10); };
  const moKey = t => new Date(t).toISOString().slice(0, 7);
  const keys = {
    day: Array.from({ length: 30 }, (_, i) => dayKey(now - (29 - i) * 864e5)),
    week: Array.from({ length: 12 }, (_, i) => wkKey(now - (11 - i) * 7 * 864e5)),
    month: Array.from({ length: 12 }, (_, i) => { const d = new Date(); return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() - (11 - i), 1)).toISOString().slice(0, 7); })
  };
  const fn = { day: dayKey, week: wkKey, month: moKey };
  const B = {};
  for (const g of Object.keys(keys)) { B[g] = {}; keys[g].forEach(k => { B[g][k] = { act: new Set(), ev: 0, nu: 0 }; }); }
  const actors = new Set();
  for (const e of ev) {
    if (e.type === 'error') continue;
    const a = e.u ? 'u:' + e.u : 'd:' + e.d;
    actors.add(a);
    for (const g of Object.keys(keys)) { const b = B[g][fn[g](e.t)]; if (b) { b.act.add(a); b.ev++; } }
  }
  for (const u of db.users) for (const g of Object.keys(keys)) { const b = B[g][fn[g](u.created)]; if (b) b.nu++; }
  const series = g => keys[g].map(k => ({ k, active: B[g][k].act.size, events: B[g][k].ev, newUsers: B[g][k].nu }));
  const pop = {};
  for (const e of ev) if (e.type === 'template_used' && e.meta && e.meta.tpl) pop[e.meta.tpl] = (pop[e.meta.tpl] || 0) + 1;
  const popular = Object.entries(pop).map(([id, count]) => {
    let name = BUILTIN[id];
    if (!name && id.startsWith('t:')) { const t = db.templates.find(x => x.id === id.slice(2)); name = t ? t.name + ' (admin)' : 'Deleted template'; }
    return { id, name: name || id, count };
  }).sort((a, b) => b.count - a.count).slice(0, 10);
  return {
    generated: now, timezone: 'UTC', aiConfigured: !!AI_KEY,
    totals: {
      users: db.users.length, visitors: actors.size,
      resumesCreated: tot.resume_created || 0, resumesUploaded: tot.resume_uploaded || 0,
      resumesEdited: tot.resume_edited || 0, resumesSaved: tot.resume_saved || 0,
      pdfDownloads: tot.pdf_download || 0, pdfFailed: tot.pdf_failed || 0,
      imageUploads: tot.image_upload || 0, uploadFailed: tot.upload_failed || 0,
      atsChecks: tot.ats_check || 0, aiRequests: tot.ai_request || 0, aiFailed: tot.ai_failed || 0, errors: tot.error || 0
    },
    daily: series('day'), weekly: series('week'), monthly: series('month'),
    popular,
    recentUsers: db.users.slice(-10).reverse().map(u => ({ id: u.id, name: u.name, email: u.email, created: u.created }))
  };
}
function eventView(e) {
  const u = e.u ? db.users.find(x => x.id === e.u) : null;
  return { t: e.t, type: e.type, who: u ? u.name + ' <' + u.email + '>' : 'Visitor ' + String(e.d || '?').slice(0, 6), meta: e.meta || {} };
}

/* ---------- API ---------- */
async function api(req, res, u, p, m) {
  const ip = ipOf(req);
  const admin = p.startsWith('/api/admin/');

  if (p === '/api/health' && m === 'GET') return send(res, 200, { ok: true, ai: !!AI_KEY });

  /* public templates curated by the admin */
  if (p === '/api/templates' && m === 'GET') {
    return send(res, 200, { templates: db.templates.filter(t => t.published).map(t => ({ id: t.id, name: t.name, desc: t.desc, type: t.type, theme: t.theme })) });
  }

  if (p === '/api/register' && m === 'POST') {
    if (limited('reg:' + ip, 10, 3600e3)) return send(res, 429, { error: 'Too many sign-ups from this network. Try again later.' });
    const b = await readBody(req, 20e3);
    const name = str(b.name, 60), email = str(b.email, 254).toLowerCase(), pw = String(b.password || '');
    if (!name) return send(res, 400, { error: 'Please enter your name.' });
    if (!EMAIL.test(email)) return send(res, 400, { error: 'Please enter a valid email.' });
    if (pw.length < 8 || pw.length > 200) return send(res, 400, { error: 'Password must be at least 8 characters.' });
    if (db.users.some(x => x.email === email)) return send(res, 409, { error: 'That email is already registered. Try logging in.' });
    const salt = crypto.randomBytes(16).toString('hex');
    const user = { id: uid(), name, email, salt, hash: hashPw(pw, salt), created: Date.now(), last: Date.now() };
    db.users.push(user); save();
    return send(res, 200, { token: sign({ role: 'user', sub: user.id, exp: Date.now() + 30 * 864e5 }), user: { id: user.id, name, email } });
  }

  if (p === '/api/login' && m === 'POST') {
    if (limited('login:' + ip, 10, 900e3)) return send(res, 429, { error: 'Too many attempts. Try again in a few minutes.' });
    const b = await readBody(req, 20e3);
    const user = db.users.find(x => x.email === str(b.email, 254).toLowerCase());
    const ok = user && same(hashPw(b.password || '', user.salt), user.hash);
    if (!ok) return send(res, 401, { error: 'Email or password is not correct.' });
    user.last = Date.now(); save();
    return send(res, 200, { token: sign({ role: 'user', sub: user.id, exp: Date.now() + 30 * 864e5 }), user: { id: user.id, name: user.name, email: user.email } });
  }

  if (p === '/api/me' && m === 'GET') {
    const user = userOf(req);
    return user ? send(res, 200, { user: { id: user.id, name: user.name, email: user.email } }) : send(res, 401, { error: 'Please log in.' });
  }

  if (p === '/api/event' && m === 'POST') {
    if (limited('ev:' + ip, 120, 60e3)) return send(res, 429, { error: 'slow down' });
    const b = await readBody(req, 8e3);
    if (!EVENT_TYPES.has(b.type)) return send(res, 400, { error: 'bad type' });
    const user = userOf(req);
    const meta = {};
    if (b.meta && typeof b.meta === 'object') Object.keys(b.meta).slice(0, 8).forEach(k => { meta[str(k, 24)] = str(b.meta[k], 120); });
    db.events.push({ t: Date.now(), type: b.type, u: user ? user.id : null, d: str(b.device, 40).replace(/[^\w-]/g, ''), meta });
    if (db.events.length > MAX_EVENTS) db.events.splice(0, db.events.length - MAX_EVENTS);
    if (user) user.last = Date.now();
    save();
    return send(res, 200, { ok: true });
  }

  if (p === '/api/ai' && m === 'POST') {
    const user = userOf(req);
    if (limited('ai:' + (user ? user.id : ip), user ? 80 : 30, 3600e3)) return send(res, 429, { error: 'rate' });
    if (!AI_KEY) return send(res, 503, { error: 'no_key' });
    const b = await readBody(req, 8e6);
    const prompt = str(b.prompt, 12000);
    if (!prompt) return send(res, 400, { error: 'empty' });
    const image = typeof b.image === 'string' && b.image.length < 7e6 && /^[A-Za-z0-9+/=]+$/.test(b.image) ? b.image : '';
    const content = image ? [{ type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data: image } }, { type: 'text', text: prompt }] : prompt;
    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-api-key': AI_KEY, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({ model: AI_MODEL, max_tokens: Math.min(+b.max_tokens || 1000, 2000), system: str(b.system, 4000) || undefined, messages: [{ role: 'user', content }] }),
        signal: AbortSignal.timeout(45000)
      });
      const d = await r.json();
      if (!r.ok) { console.error('Anthropic error', r.status, JSON.stringify(d).slice(0, 300)); return send(res, 502, { error: 'upstream', status: r.status }); }
      const text = (d.content || []).filter(c => c.type === 'text').map(c => c.text).join('\n').trim();
      return text ? send(res, 200, { text }) : send(res, 502, { error: 'empty' });
    } catch (e) { console.error('AI call failed', e.message); return send(res, 502, { error: 'upstream' }); }
  }

  /* ----- admin ----- */
  if (p === '/api/admin/login' && m === 'POST') {
    if (limited('adm:' + ip, 8, 900e3)) return send(res, 429, { error: 'Too many attempts. Try again in 15 minutes.' });
    const b = await readBody(req, 5e3);
    const a = db.admin;
    const ok = a && same(str(b.username, 80), a.user) && same(hashPw(b.password || '', a.salt), a.hash);
    if (!ok) { await new Promise(r => setTimeout(r, 700)); return send(res, 401, { error: 'Wrong username or password.' }); }
    return send(res, 200, { token: sign({ role: 'admin', exp: Date.now() + 12 * 3600e3 }) });
  }
  if (admin) {
    if (!isAdmin(req)) return send(res, 401, { error: 'Admin login required.' });
    if (p === '/api/admin/stats' && m === 'GET') return send(res, 200, computeStats());
    if (p === '/api/admin/users' && m === 'GET') {
      const per = {};
      for (const e of db.events) if (e.u) { const o = per[e.u] || (per[e.u] = { resumes: 0, pdfs: 0, uploads: 0, ats: 0, ai: 0 }); if (e.type === 'resume_created') o.resumes++; else if (e.type === 'pdf_download') o.pdfs++; else if (e.type === 'image_upload') o.uploads++; else if (e.type === 'ats_check') o.ats++; else if (e.type === 'ai_request') o.ai++; }
      return send(res, 200, { users: db.users.slice().reverse().map(x => Object.assign({ id: x.id, name: x.name, email: x.email, created: x.created, last: x.last }, per[x.id] || { resumes: 0, pdfs: 0, uploads: 0, ats: 0, ai: 0 })) });
    }
    if (p === '/api/admin/activity' && m === 'GET') {
      const type = u.searchParams.get('type'), n = Math.min(+u.searchParams.get('limit') || 100, 300);
      const list = db.events.filter(e => !type || e.type === type).slice(-n).reverse().map(eventView);
      return send(res, 200, { events: list });
    }
    if (p === '/api/admin/errors' && m === 'GET') {
      const list = db.events.filter(e => ERROR_TYPES.has(e.type)).slice(-200).reverse().map(eventView);
      return send(res, 200, { events: list });
    }
    if (p === '/api/admin/templates' && m === 'GET') return send(res, 200, { templates: db.templates });
    if (p === '/api/admin/templates' && m === 'POST') {
      const b = await readBody(req, 20e3);
      const name = str(b.name, 40);
      if (!name) return send(res, 400, { error: 'Template name is required.' });
      const t = { id: uid(), name, desc: str(b.desc, 120), type: b.type === 'cv' ? 'cv' : 'resume', theme: cleanTheme(b.theme), published: !!b.published, created: Date.now(), updated: Date.now() };
      db.templates.push(t); save();
      return send(res, 200, { template: t });
    }
    const tm = p.match(/^\/api\/admin\/templates\/([a-f0-9]{12})$/);
    if (tm) {
      const t = db.templates.find(x => x.id === tm[1]);
      if (!t) return send(res, 404, { error: 'Not found' });
      if (m === 'PUT') {
        const b = await readBody(req, 20e3);
        const name = str(b.name, 40);
        if (!name) return send(res, 400, { error: 'Template name is required.' });
        Object.assign(t, { name, desc: str(b.desc, 120), type: b.type === 'cv' ? 'cv' : 'resume', theme: cleanTheme(b.theme), published: !!b.published, updated: Date.now() });
        save(); return send(res, 200, { template: t });
      }
      if (m === 'DELETE') { db.templates = db.templates.filter(x => x.id !== t.id); save(); return send(res, 200, { ok: true }); }
    }
  }
  return send(res, 404, { error: 'Not found' });
}

/* ---------- static pages ---------- */
function page(res, file, extra) {
  fs.readFile(path.join(PUBLIC, file), (err, buf) => {
    if (err) { res.writeHead(404); return res.end('Not found'); }
    res.writeHead(200, Object.assign({ 'Content-Type': 'text/html; charset=utf-8', 'X-Content-Type-Options': 'nosniff' }, extra || {}));
    res.end(buf);
  });
}

http.createServer(async (req, res) => {
  try {
    const u = new URL(req.url, 'http://x'), p = u.pathname, m = req.method;
    const origin = req.headers.origin;
    if (p.startsWith('/api/') && !p.startsWith('/api/admin/') && ALLOWED_ORIGIN && origin === ALLOWED_ORIGIN) {
      res.setHeader('Access-Control-Allow-Origin', origin);
      res.setHeader('Vary', 'Origin');
      res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
      res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    }
    if (m === 'OPTIONS') { res.writeHead(204); return res.end(); }
    if (p.startsWith('/api/')) return await api(req, res, u, p, m);
    if (p === '/' || p === '/index.html') return page(res, 'index.html');
    if (p === '/admin' || p === '/admin/') {
      return page(res, 'admin.html', {
        'Cache-Control': 'no-store', 'X-Frame-Options': 'DENY', 'X-Robots-Tag': 'noindex, nofollow',
        'Content-Security-Policy': "default-src 'self'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'"
      });
    }
    if (p === '/robots.txt') { res.writeHead(200, { 'Content-Type': 'text/plain' }); return res.end('User-agent: *\nDisallow: /admin\n'); }
    res.writeHead(404); res.end('Not found');
  } catch (e) {
    if (e.status) return send(res, e.status, { error: e.message });
    console.error(e);
    send(res, 500, { error: 'Server error' });
  }
}).listen(PORT, () => console.log('Resume44 running on http://localhost:' + PORT + '  (admin: /admin)  AI ' + (AI_KEY ? 'enabled' : 'NOT configured')));
