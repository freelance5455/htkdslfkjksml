# Resume44 (app + admin + server)

No npm packages needed. Node 18 or newer.

## Run it
```
ANTHROPIC_API_KEY=sk-ant-...  ADMIN_USER=admin  ADMIN_PASSWORD='choose-a-long-password'  node server.js
```
- App:   http://localhost:3000/
- Admin: http://localhost:3000/admin   (only way in; there is no link to it inside the app)

If you do not set ADMIN_PASSWORD, a one-time password is printed in the server log on first start.

## Environment variables
| Name | Purpose |
|---|---|
| ANTHROPIC_API_KEY | Turns on AI features. Stays on the server, never sent to browsers. |
| AI_MODEL | Optional. Default `claude-sonnet-5-5`. |
| ADMIN_USER / ADMIN_PASSWORD | Admin login (password min 10 characters). |
| PORT | Default 3000. |
| DATA_DIR | Where db.json is stored. Use a persistent disk when deploying. |
| TRUST_PROXY | Set to `1` when behind a proxy/host (Render, Railway, Nginx) so rate limits use the real IP. |
| ALLOWED_ORIGIN | Only if the app HTML is hosted on a different domain than the server. |

## Deploy
Use any host that runs Node (Render, Railway, Fly.io, a VPS). Requirements:
1. HTTPS (hosts above give it free). Admin login must never run over plain HTTP.
2. A persistent disk for DATA_DIR, otherwise data is lost on redeploy.
3. Set the env variables above.

## Why AI said "unavailable"
Browsers cannot call the Claude API directly without an API key, and a key placed in HTML can be copied by anyone.
The server's `/api/ai` holds the key and calls Claude for the app.

## What the dashboard counts
Counts only (no resume text): visits, resumes created / saved / edited, resume photos uploaded, image uploads,
PDF downloads (counted when the user taps a save option), ATS checks, AI requests, template use, and errors.
"Registered users" are people who made an account (optional in the app). Anonymous visitors are counted by device.
Resume content stays on the user's device. AI prompts pass through your server to Claude but are not stored.
Tell users what you track (a short privacy notice) and check your local privacy law (GDPR, India DPDP, etc.).

## Limits to know
- Data is a single JSON file (up to 100,000 recent events). Fine for early stages; move to Postgres when you grow.
- Daily/weekly/monthly buckets use UTC.
- A "PDF download" means the user tapped save/share/open. Browsers do not tell a page whether a file really reached the device.
