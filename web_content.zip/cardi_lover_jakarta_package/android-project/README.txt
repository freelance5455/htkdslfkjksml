CARDI LOVER'S JAKARTA — Android project

This is source code, NOT a prebuilt APK. The current environment has no Android SDK/build tools, so it cannot compile the APK here.

Build through GitHub Actions:
1. Extract this ZIP on a computer and create a GitHub repository.
2. Upload the contents of this folder (including .github/workflows/build-apk.yml) to the repository's main branch.
3. Open the repository's Actions tab and run “Build CARDI LOVER'S JAKARTA APK” (or wait for the push build to finish).
4. Open the completed workflow run, download the artifact named cardi-lover-jakarta-apk, and extract app-debug.apk.
5. Transfer the APK to the Android phone and install it. Android may ask permission to install unknown apps.

The Android app wraps app/src/main/assets/index.html in a WebView. POS records are stored locally on that device in WebView storage; this is not cloud sync.
