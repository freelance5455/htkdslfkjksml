import fs from 'node:fs';
import path from 'node:path';
import { execSync } from 'node:child_process';

const distIndexPath = path.resolve('dist', 'index.html');
const distDir = path.resolve('dist');
const publicDir = path.resolve('public');

if (!fs.existsSync(distIndexPath)) {
  console.error('dist/index.html not found! Run vite build first.');
  process.exit(1);
}

let html = fs.readFileSync(distIndexPath, 'utf-8');

// 1. CRITICAL FIX: Completely REMOVE the protocol bridge redirect from the compiled bundle!
// In the compiled bundle, having a script that redirects to `./dist/index.html` causes an infinite loop
// or net::ERR_FILE_NOT_FOUND when loaded in Android APKs because the APK loads from the asset root.
html = html.replace(/<!--\s*APK & Local File Protocol Bridge[\s\S]*?<\/script>/gi, '');
html = html.replace(/<script>[\s\S]*?window\.location\.replace\(['"]\.\/dist\/index\.html['"]\);[\s\S]*?<\/script>/gi, '');

// 2. Transform `<script type="module" crossorigin>` into a clean universal classic script: `<script>`
// In Android WebViews (file:/// protocol), `type="module"` triggers strict browser CORS and blocks execution.
// A plain `<script>` runs anywhere with zero restrictions.
html = html.replace(/<script\s+type=["']module["']\s+crossorigin>/gi, '<script>');
html = html.replace(/<script\s+type=["']module["']>/gi, '<script>');
html = html.replace(/<script\s+crossorigin>/gi, '<script>');

// 3. Remove modulepreload links that trigger CORS warnings in file:// mode
html = html.replace(/<link\s+rel=["']modulepreload["'][^>]*>/gi, '');

// 4. Ensure all link tags (icons, manifest) use relative paths (./)
html = html.replace(/href=["']\/([^"']+)["']/gi, 'href="./$1"');

// 5. Inject safe WebView environment shim and storage polyfill right after <head>
const webViewShim = `
    <!-- Android WebView & Offline Environment Shim -->
    <script>
      (function() {
        window.__IS_APK_STANDALONE__ = true;
        // 1. Safe localStorage: Prevents SecurityError crash in Android WebViews with restricted storage
        try {
          var testKey = '__apk_st_check__';
          window.localStorage.setItem(testKey, '1');
          window.localStorage.removeItem(testKey);
        } catch (e) {
          console.warn('WebView localStorage unavailable; activating in-memory storage fallback.');
          var _mem = {};
          try {
            Object.defineProperty(window, 'localStorage', {
              value: {
                getItem: function(k) { return _mem.hasOwnProperty(k) ? _mem[k] : null; },
                setItem: function(k, v) { _mem[k] = String(v); },
                removeItem: function(k) { delete _mem[k]; },
                clear: function() { _mem = {}; },
                get length() { return Object.keys(_mem).length; },
                key: function(i) { return Object.keys(_mem)[i] || null; }
              },
              writable: true,
              configurable: true
            });
          } catch (err) {}
        }
        // 2. Safe matchMedia polyfill for older WebViews
        if (typeof window.matchMedia !== 'function') {
          window.matchMedia = function(query) {
            return {
              matches: false,
              media: query,
              onchange: null,
              addListener: function() {},
              removeListener: function() {},
              addEventListener: function() {},
              removeEventListener: function() {},
              dispatchEvent: function() { return false; }
            };
          };
        }
      })();
    </script>
`;

html = html.replace(/<head>/i, `<head>${webViewShim}`);

// 6. Write final sanitized HTML to dist/index.html and dist/app.html
fs.writeFileSync(distIndexPath, html, 'utf-8');
fs.writeFileSync(path.resolve(distDir, 'app.html'), html, 'utf-8');

// 7. Also copy to public/index-apk.html so dev server can serve it to client if requested
fs.writeFileSync(path.resolve(publicDir, 'index-apk.html'), html, 'utf-8');

// 8. Copy public assets into dist
const assetsToCopy = [
  'manifest.json',
  'icon.svg',
  'pwa-192x192.png',
  'pwa-512x512.png',
  'pwa-maskable-512x512.png',
  'apple-touch-icon.png',
];

for (const file of assetsToCopy) {
  const src = path.join(publicDir, file);
  const dest = path.join(distDir, file);
  if (fs.existsSync(src)) {
    fs.copyFileSync(src, dest);
  }
}

console.log('✅ post-build-apk: Successfully sanitized dist/index.html & dist/app.html:');
console.log('   - Removed protocol bridge redirect (prevented white screen bug)');
console.log('   - Converted to universal classic script (zero CORS)');
console.log('   - Injected WebView localStorage & matchMedia polyfill');

// 9. Automatically build the ready-to-use APK zip
try {
  execSync('node scripts/create-apk-zip.js', { stdio: 'inherit' });
} catch (e) {
  console.warn('Notice: Could not automatically generate APK zip during post-build:', e.message);
}
