import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';

function createCRC32Table() {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) {
      if (c & 1) {
        c = 0xedb88320 ^ (c >>> 1);
      } else {
        c = c >>> 1;
      }
    }
    table[n] = c;
  }
  return table;
}

const crcTable = createCRC32Table();
function crc32(buf) {
  let crc = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    crc = crcTable[(crc ^ buf[i]) & 0xff] ^ (crc >>> 8);
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function createChunk(type, data) {
  const typeBuf = Buffer.from(type, 'ascii');
  const lenBuf = Buffer.alloc(4);
  lenBuf.writeUInt32BE(data.length, 0);

  const body = Buffer.concat([typeBuf, data]);
  const crcVal = crc32(body);
  const crcBuf = Buffer.alloc(4);
  crcBuf.writeUInt32BE(crcVal, 0);

  return Buffer.concat([lenBuf, body, crcBuf]);
}

function generateIconPNG(width, height, isMaskable = false) {
  // Raw scanlines: width * 4 (RGBA) + 1 filter byte per line
  const rawScanlines = Buffer.alloc((width * 4 + 1) * height);
  const cx = width / 2;
  const cy = height / 2;
  const radius = Math.min(width, height) * (isMaskable ? 0.45 : 0.46);
  const innerRadius = radius * 0.72;

  let offset = 0;
  for (let y = 0; y < height; y++) {
    rawScanlines[offset++] = 0; // Filter: None
    for (let x = 0; x < width; x++) {
      const dx = x - cx;
      const dy = y - cy;
      const dist = Math.sqrt(dx * dx + dy * dy);

      let r, g, b, a;
      if (isMaskable) {
        // Full bleed teal background
        r = 15; g = 118; b = 110; a = 255;
      } else {
        // Rounded squircle / circular badge
        if (dist <= radius) {
          r = 15; g = 118; b = 110; a = 255;
        } else if (dist <= radius + 1.5) {
          const alpha = Math.max(0, Math.min(1, radius + 1.5 - dist));
          r = 15; g = 118; b = 110; a = Math.round(alpha * 255);
        } else {
          r = 0; g = 0; b = 0; a = 0;
        }
      }

      // Draw stylized DNA / hourglass / star symbol in center
      if (a > 0) {
        const symbolDist = Math.sqrt(dx * dx + dy * dy);
        // Golden accent ring or inner star
        if (symbolDist < innerRadius && symbolDist > innerRadius - (width * 0.04)) {
          r = 251; g = 191; b = 36; // Amber gold
          a = 255;
        } else if (Math.abs(dx) < width * 0.08 && Math.abs(dy) < height * 0.28) {
          // Center bar
          r = 255; g = 255; b = 255; a = 255;
        } else if (Math.abs(dy) < height * 0.08 && Math.abs(dx) < width * 0.28) {
          // Cross bar
          r = 255; g = 255; b = 255; a = 255;
        } else if (Math.abs(Math.abs(dx) - Math.abs(dy)) < width * 0.06 && symbolDist < innerRadius * 0.85) {
          // Diagonal diamond
          r = 240; g = 253; b = 250; a = 255;
        }
      }

      rawScanlines[offset++] = r;
      rawScanlines[offset++] = g;
      rawScanlines[offset++] = b;
      rawScanlines[offset++] = a;
    }
  }

  // PNG Signature
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  // IHDR Chunk
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; // 8 bit depth
  ihdr[9] = 6; // Color type 6 (RGBA)
  ihdr[10] = 0; // Compression deflate
  ihdr[11] = 0; // Filter adaptive
  ihdr[12] = 0; // No interlace
  const ihdrChunk = createChunk('IHDR', ihdr);

  // IDAT Chunk
  const compressed = zlib.deflateSync(rawScanlines, { level: 9 });
  const idatChunk = createChunk('IDAT', compressed);

  // IEND Chunk
  const iendChunk = createChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

const publicDir = path.resolve('public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

// Generate PNGs
fs.writeFileSync(path.join(publicDir, 'pwa-192x192.png'), generateIconPNG(192, 192, false));
fs.writeFileSync(path.join(publicDir, 'pwa-512x512.png'), generateIconPNG(512, 512, false));
fs.writeFileSync(path.join(publicDir, 'pwa-maskable-512x512.png'), generateIconPNG(512, 512, true));
fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), generateIconPNG(180, 180, false));

// Generate icon.svg
const svgContent = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="100%" height="100%">
  <defs>
    <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0d9488" />
      <stop offset="100%" stop-color="#0f766e" />
    </linearGradient>
    <linearGradient id="goldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#fde047" />
      <stop offset="100%" stop-color="#f59e0b" />
    </linearGradient>
  </defs>
  <rect width="512" height="512" rx="128" fill="url(#bgGrad)" />
  <circle cx="256" cy="256" r="180" fill="none" stroke="url(#goldGrad)" stroke-width="14" stroke-dasharray="8 8" opacity="0.8" />
  <g transform="translate(256, 256) scale(1.15)">
    <!-- DNA / Science / Medical symbol -->
    <path d="M-60,-120 C0,-60 0,60 60,120 M60,-120 C0,-60 0,60 -60,120" stroke="#ffffff" stroke-width="18" stroke-linecap="round" fill="none" />
    <circle cx="0" cy="0" r="28" fill="url(#goldGrad)" />
    <line x1="-35" y1="-60" x2="35" y2="-60" stroke="#fef08a" stroke-width="10" stroke-linecap="round" />
    <line x1="-35" y1="60" x2="35" y2="60" stroke="#fef08a" stroke-width="10" stroke-linecap="round" />
  </g>
</svg>`;
fs.writeFileSync(path.join(publicDir, 'icon.svg'), svgContent, 'utf-8');

console.log('PWA icons successfully generated in /public!');
