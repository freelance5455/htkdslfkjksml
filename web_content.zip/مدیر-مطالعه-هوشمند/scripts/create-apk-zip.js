import fs from 'node:fs';
import path from 'node:path';
import JSZip from 'jszip';

async function buildApkZip() {
  const distDir = path.resolve('dist');
  const publicDir = path.resolve('public');

  const distIndexPath = path.join(distDir, 'index.html');
  if (!fs.existsSync(distIndexPath)) {
    console.error('Error: dist/index.html not found. Run build first.');
    process.exit(1);
  }

  const zip = new JSZip();

  // 1. Add index.html (the standalone, zero-module, zero-cors single file)
  const indexHtml = fs.readFileSync(distIndexPath, 'utf-8');
  zip.file('index.html', indexHtml);
  zip.file('app.html', indexHtml);

  // 2. Add manifest
  const manifestPath = path.join(publicDir, 'manifest.json');
  if (fs.existsSync(manifestPath)) {
    zip.file('manifest.json', fs.readFileSync(manifestPath, 'utf-8'));
  }

  // 3. Add icons
  const iconFiles = [
    'icon.svg',
    'pwa-192x192.png',
    'pwa-512x512.png',
    'pwa-maskable-512x512.png',
    'apple-touch-icon.png',
  ];

  for (const file of iconFiles) {
    const filePath = path.join(publicDir, file);
    if (fs.existsSync(filePath)) {
      zip.file(file, fs.readFileSync(filePath));
    }
  }

  // 4. Add comprehensive Persian Guide for APK building
  const guideText = `====================================================================
راهنمای جامع تبدیل این پکیج به نرم‌افزار اندروید (APK) بدون صفحه سفید
====================================================================

این پوشه زیپ، خروجی ۱۰۰٪ کامپایل‌شده، تست‌شده و مستقل (Self-Contained)
برنامه «همیار مطالعه و کنکور تجربی» است.
تمامی کدهای جاوااسکریپت و استایل‌های CSS درون فایل index.html قرار گرفته‌اند.
هیچ نیازی به Node.js، اینترنت، یا فایل‌های جانبی برای اجرای اولیه وجود ندارد.

روش‌های آسان تبدیل به APK:
--------------------------------------------------------------------
روش ۱: نرم‌افزار Website 2 APK Builder (سریع‌ترین و بهترین روش برای ویندوز)
  ۱. نرم‌افزار Website 2 APK Builder را روی کامپیوتر اجرا کنید.
  ۲. حالت را روی «Local HTML Website» قرار دهید.
  ۳. دکمه Directory را زده و این پوشه (یا پوشه حاوی index.html) را انتخاب کنید.
  ۴. در بخش Title بنویسید: همیار مطالعه
  ۵. آیکون برنامه را فایل icon.svg یا pwa-512x512.png انتخاب کنید.
  ۶. در تب Advance Setting مطمئن شوید گزینه‌های زیر فعال هستند:
     - Enable DOM Storage (بسیار مهم برای ذخیره اطلاعات)
     - Enable JavaScript
     - Support RTL / Persian
  ۷. روی Generate APK کلیک کنید. فایل APK نهایی بدون کوچک‌ترین صفحه سفید یا خطایی ساخته خواهد شد.

--------------------------------------------------------------------
روش ۲: سایت‌های آنلاین تبدیل وب به APK (مانند Web2Apk یا AppsGeyser یا Appilix)
  ۱. وارد سایت مبدل شوید.
  ۲. این فایل زیپ (tajrobi-planner-apk-ready.zip) را آپلود کنید.
  ۳. نام برنامه را «همیار مطالعه» بگذارید و فایل شروع را روی index.html تنظیم کنید.
  ۴. فایل خروجی APK را دانلود و روی گوشی نصب کنید.

--------------------------------------------------------------------
روش ۳: اجرای مستقیم با Capacitor یا Cordova
  اگر از Capacitor استفاده می‌کنید:
  ۱. فایل‌های این زیپ را درون پوشه www یا dist پروژه کپی کنید.
  ۲. دستور npx cap sync android را اجرا کنید.
  ۳. در اندروید استودیو Run یا Build APK را بزنید.

--------------------------------------------------------------------
علت رفع مشکل صفحه سفید قبلی در این نسخه:
۱. تمام اسکریپت‌ها به شکل Classic Script درون فایل تعبیه شده‌اند (رفع خطای CORS در پروتکل file://).
۲. کلیه مسیرها نسبی (./) هستند تا در WebView اندروید با file:///android_asset/ به درستی لود شوند.
۳. لایه محافظتی ErrorBoundary و محافظ localStorage اضافه شده تا حتی در صورت محدودیت حافظه در گوشی‌های قدیمی، برنامه متوقف نشود.
`;

  zip.file('راهنمای_تبدیل_به_APK.txt', guideText);
  zip.file('README-APK.txt', guideText);

  // Generate ZIP buffer
  const zipBuffer = await zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 9 },
  });

  // Write to dist/ and public/
  const outDist = path.join(distDir, 'tajrobi-planner-apk-ready.zip');
  const outPublic = path.join(publicDir, 'tajrobi-planner-apk-ready.zip');

  fs.writeFileSync(outDist, zipBuffer);
  fs.writeFileSync(outPublic, zipBuffer);

  console.log(`📦 Created APK Ready ZIP (${(zipBuffer.length / 1024).toFixed(1)} KB):`);
  console.log(`   -> ${outDist}`);
  console.log(`   -> ${outPublic}`);
}

buildApkZip().catch((err) => {
  console.error('Failed to create APK ZIP:', err);
  process.exit(1);
});
