import React, { useState } from 'react';
import { CompensationTask, TajrobiSubject } from '../types';
import {
  TAJROBI_SUBJECTS_INFO,
  toFaDigits,
} from '../utils/tajrobiData';
import {
  Play,
  CheckCircle2,
  Trash2,
  Plus,
  Zap,
  BookOpen,
} from 'lucide-react';

interface CompensationViewProps {
  compensations: CompensationTask[];
  onStartCompensationInTimer: (
    subject: TajrobiSubject,
    topic: string,
    remainingMins: number,
    bookSource: string,
    compId: string
  ) => void;
  onToggleResolve: (id: string) => void;
  onDeleteCompensation: (id: string) => void;
  onAddManualCompensation: (task: Omit<CompensationTask, 'id' | 'resolved' | 'date'>) => void;
}

export const CompensationView: React.FC<CompensationViewProps> = ({
  compensations,
  onStartCompensationInTimer,
  onToggleResolve,
  onDeleteCompensation,
  onAddManualCompensation,
}) => {
  const [showAddForm, setShowAddForm] = useState(false);
  const [subject, setSubject] = useState<TajrobiSubject>('زیست‌شناسی');
  const [topic, setTopic] = useState('');
  const [bookSource, setBookSource] = useState(
    TAJROBI_SUBJECTS_INFO['زیست‌شناسی'].popularBooks[0] || 'کتاب درسی'
  );
  const [plannedMinutes, setPlannedMinutes] = useState(90);
  const [completedMinutes, setCompletedMinutes] = useState(30);

  const activeCompensations = compensations.filter((c) => !c.resolved);
  const resolvedCompensations = compensations.filter((c) => c.resolved);

  const totalDeficitMinutes = activeCompensations.reduce((acc, c) => acc + c.remainingMinutes, 0);
  const totalDeficitHours = Math.round((totalDeficitMinutes / 60) * 10) / 10;

  const handleSubmitNew = (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic.trim()) return;

    const remaining = Math.max(5, plannedMinutes - completedMinutes);
    onAddManualCompensation({
      subject,
      topic: topic.trim(),
      bookSource: bookSource || 'کتاب درسی',
      plannedMinutes,
      completedMinutes,
      remainingMinutes: remaining,
      notes: `کسری مطالعه از کتاب «${bookSource}» — ${toFaDigits(remaining)} دقیقه باقی‌مانده`,
    });

    setTopic('');
    setShowAddForm(false);
  };

  return (
    <div className="space-y-6">
      {/* Header and Deficit Summary */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <h2 className="text-lg font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              <Zap className="w-5 h-5 text-amber-500" />
              <span>ایستگاه جبران عقب‌افتادگی‌ها (پارت‌های نصفه‌مانده)</span>
            </h2>
            <p className="text-xs text-slate-600 dark:text-slate-400">
              هر زمان تایم مطالعه‌ات نصفه بماند یا درسی از برنامه عقب بیفتد، اینجا ثبت می‌شود تا بعداً جبرانش کنی.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="px-4 py-2 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 text-amber-900 dark:text-amber-200 text-xs font-extrabold tabular-nums">
              مجموع کسری عقب‌افتاده: {toFaDigits(totalDeficitHours)} ساعت ({toFaDigits(totalDeficitMinutes)} دقیقه)
            </div>

            <button
              type="button"
              onClick={() => setShowAddForm((p) => !p)}
              className="px-3.5 py-2 rounded-2xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold flex items-center gap-1.5 transition cursor-pointer shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>ثبت دستی پارت نصفه‌مانده</span>
            </button>
          </div>
        </div>
      </div>

      {/* Manual Add Form */}
      {showAddForm && (
        <form
          onSubmit={handleSubmitNew}
          className="bg-white dark:bg-slate-900 rounded-2xl border-2 border-teal-500 p-5 space-y-4 shadow-sm"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-900 dark:text-white">
              ➕ ثبت پارت نصفه‌مانده جدید برای جبران
            </span>
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="text-xs text-slate-400 hover:text-slate-700"
            >
              انصراف ✕
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">
                درس تجربی:
              </label>
              <select
                value={subject}
                onChange={(e) => {
                  const s = e.target.value as TajrobiSubject;
                  setSubject(s);
                  setBookSource(TAJROBI_SUBJECTS_INFO[s].popularBooks[0] || 'کتاب درسی');
                }}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-bold"
              >
                {(Object.keys(TAJROBI_SUBJECTS_INFO) as TajrobiSubject[]).map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">
                کتاب منبع:
              </label>
              <input
                type="text"
                value={bookSource}
                onChange={(e) => setBookSource(e.target.value)}
                placeholder="مثلاً: خیلی سبز جامع"
                className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">
                مبحث مطالعه:
              </label>
              <input
                type="text"
                required
                placeholder="مثلاً: گوارش و جذب مواد"
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs"
              />
            </div>

            <div className="flex gap-2">
              <div className="w-1/2">
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">
                  برنامه‌ریزی (دقیقه):
                </label>
                <input
                  type="number"
                  min={15}
                  max={300}
                  value={plannedMinutes}
                  onChange={(e) => setPlannedMinutes(Number(e.target.value) || 90)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs tabular-nums text-center"
                />
              </div>

              <div className="w-1/2">
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">
                  خوانده‌شده:
                </label>
                <input
                  type="number"
                  min={0}
                  max={plannedMinutes}
                  value={completedMinutes}
                  onChange={(e) => setCompletedMinutes(Number(e.target.value) || 0)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs tabular-nums text-center"
                />
              </div>
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              className="px-5 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold cursor-pointer"
            >
              افزودن به ایستگاه جبرانی
            </button>
          </div>
        </form>
      )}

      {/* Active Incomplete Tasks List */}
      <div className="space-y-3">
        <h3 className="text-sm font-extrabold text-slate-800 dark:text-slate-200">
          لیست پارت‌های نیازمند جبران ({toFaDigits(activeCompensations.length)} پارت)
        </h3>

        {activeCompensations.length === 0 ? (
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-8 text-center space-y-2">
            <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto" />
            <div className="text-sm font-bold text-slate-800 dark:text-slate-200">
              هیچ پارت عقب‌افتاده یا نصفه‌مانده‌ای نداری!
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              عالیه! برنامه مطالعه‌ات کاملاً به‌روز است. اگر روزی درسی نصفه ماند، مستقیم به این بخش اضافه می‌شود.
            </p>
          </div>
        ) : (
          activeCompensations.map((comp) => {
            const subjInfo = TAJROBI_SUBJECTS_INFO[comp.subject];

            return (
              <div
                key={comp.id}
                className="bg-white dark:bg-slate-900 rounded-2xl border border-amber-300/80 dark:border-amber-800/80 p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                <div className="space-y-1.5 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className={`px-2.5 py-1 rounded-lg text-xs font-extrabold ${subjInfo.badgeColor}`}>
                      {comp.subject}
                    </span>
                    {comp.bookSource && (
                      <span className="text-xs font-bold text-teal-700 dark:text-teal-400 bg-teal-50 dark:bg-teal-950/60 px-2 py-0.5 rounded-md flex items-center gap-1">
                        <BookOpen className="w-3 h-3" />
                        <span>{comp.bookSource}</span>
                      </span>
                    )}
                    <h4 className="text-sm font-extrabold text-slate-900 dark:text-white">
                      {comp.topic}
                    </h4>
                  </div>

                  <div className="flex flex-wrap items-center gap-3 text-xs text-slate-600 dark:text-slate-400 tabular-nums">
                    <span>برنامه‌ریزی: {toFaDigits(comp.plannedMinutes)} دقیقه</span>
                    <span aria-hidden="true">·</span>
                    <span>خوانده‌شده: {toFaDigits(comp.completedMinutes)} دقیقه</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-extrabold text-amber-700 dark:text-amber-300 text-sm">
                      ⚠️ کسری باقی‌مانده: {toFaDigits(comp.remainingMinutes)} دقیقه
                    </span>
                  </div>

                  {comp.notes && (
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">
                      {comp.notes}
                    </p>
                  )}
                </div>

                {/* Action Buttons */}
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() =>
                      onStartCompensationInTimer(
                        comp.subject,
                        `[جبرانی] ${comp.topic}`,
                        comp.remainingMinutes,
                        comp.bookSource || 'کتاب درسی',
                        comp.id
                      )
                    }
                    className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs font-extrabold flex items-center gap-1.5 shadow-xs transition cursor-pointer"
                    title="تنظیم خودکار تایمر معکوس روی زمان باقی‌مانده و شروع مطالعه"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>شروع جبران ({toFaDigits(comp.remainingMinutes)} دقیقه)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => onToggleResolve(comp.id)}
                    className="px-3 py-2.5 rounded-xl border border-emerald-300 dark:border-emerald-700 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 text-xs font-bold flex items-center gap-1 transition cursor-pointer"
                    title="علامت‌گذاری به عنوان جبران‌شده"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>تکمیل شد</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => onDeleteCompensation(comp.id)}
                    className="p-2.5 rounded-xl text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition cursor-pointer"
                    title="حذف"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Completed / Resolved Section */}
      {resolvedCompensations.length > 0 && (
        <div className="space-y-2 pt-4">
          <h4 className="text-xs font-bold text-slate-500 dark:text-slate-400">
            پارت‌های جبران‌شده اخیر ({toFaDigits(resolvedCompensations.length)})
          </h4>
          <div className="space-y-2 opacity-75">
            {resolvedCompensations.map((rc) => (
              <div
                key={rc.id}
                className="bg-slate-100 dark:bg-slate-800/60 rounded-xl p-3 flex items-center justify-between text-xs"
              >
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span className="line-through text-slate-600 dark:text-slate-400">
                    {rc.subject}: {rc.topic} ({toFaDigits(rc.remainingMinutes)} دقیقه جبران شد)
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => onDeleteCompensation(rc.id)}
                  className="text-slate-400 hover:text-rose-500"
                >
                  حذف
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
