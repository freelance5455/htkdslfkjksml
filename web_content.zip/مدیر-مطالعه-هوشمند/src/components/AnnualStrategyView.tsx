import React, { useState } from 'react';
import {
  AnnualMonthStrategy,
  AnnualPlanRoadmap,
  DayOfWeek,
  DaySchedule,
  GradeLevel,
  StudyLog,
  StudyPart,
  SyllabusChapterItem,
  TajrobiSubject,
  ThemeConfig,
} from '../types';
import {
  GRADE_META,
  TAJROBI_SUBJECTS_INFO,
  TAJROBI_SUBJECTS_LIST,
  formatMinutesToHoursAndMinutes,
  playChimeSound,
  toPersianDigits,
} from '../utils/tajrobiData';
import {
  Award,
  BookOpen,
  Brain,
  Calendar,
  CheckCircle2,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Clock,
  Compass,
  FileSpreadsheet,
  Flame,
  Layers,
  Milestone,
  RotateCcw,
  Sparkles,
  Target,
  Zap,
  ShieldCheck,
  Check,
  Plus,
} from 'lucide-react';

interface AnnualStrategyViewProps {
  annualPlan: AnnualPlanRoadmap;
  theme: ThemeConfig;
  studyLogs?: StudyLog[];
  onOpenAIPlannerModal: (defaultMode?: 'annual' | 'weekly' | 'monthly' | 'daily') => void;
  onUpdateSyllabusChapter?: (chapterId: string, completed: boolean, testsDelta?: number) => void;
  onApplyMonthToStudyParts?: (month: AnnualMonthStrategy) => void;
  showToast: (message: string, type?: 'success' | 'warning' | 'info') => void;
}

export const AnnualStrategyView: React.FC<AnnualStrategyViewProps> = ({
  annualPlan,
  theme,
  studyLogs = [],
  onOpenAIPlannerModal,
  onUpdateSyllabusChapter,
  onApplyMonthToStudyParts,
  showToast,
}) => {
  const [selectedMonthIndex, setSelectedMonthIndex] = useState<number>(6); // Default to Esfand (Index 6) or current month
  const [syllabusSubjectFilter, setSyllabusSubjectFilter] = useState<TajrobiSubject>('زیست‌شناسی');
  const [syllabusGradeFilter, setSyllabusGradeFilter] = useState<GradeLevel | 'all'>('all');
  const [activeSubTab, setActiveSubTab] = useState<'months' | 'syllabus' | 'principles'>('months');

  const currentMonthData = annualPlan.months.find((m) => m.monthIndex === selectedMonthIndex) || annualPlan.months[5] || annualPlan.months[0];

  // Calculate syllabus stats
  const totalChapters = annualPlan.syllabusChapters?.length || 0;
  const completedChapters = annualPlan.syllabusChapters?.filter((c) => c.isCompleted).length || 0;
  const syllabusProgressPercent = totalChapters > 0 ? Math.round((completedChapters / totalChapters) * 100) : 0;
  const totalTestsDoneSyllabus = annualPlan.syllabusChapters?.reduce((acc, c) => acc + (c.testCountDone || 0), 0) || 0;

  // Calculate actual hours and tests from study logs
  const totalCompletedMinutes = studyLogs.reduce((acc, l) => acc + (l.durationMinutes || 0), 0);
  const totalCompletedHours = Math.round((totalCompletedMinutes / 60) * 10) / 10;
  const totalCompletedTestsFromLogs = studyLogs.reduce((acc, l) => acc + (l.totalTests || 0), 0);
  const totalTestsDoneOverall = totalTestsDoneSyllabus + totalCompletedTestsFromLogs;

  // Filter syllabus chapters
  const filteredChapters = (annualPlan.syllabusChapters || []).filter((c) => {
    const matchSubject = c.subject === syllabusSubjectFilter;
    const matchGrade = syllabusGradeFilter === 'all' || c.gradeLevel === syllabusGradeFilter;
    return matchSubject && matchGrade;
  });

  const handleToggleChapter = (id: string, currentStatus: boolean) => {
    playChimeSound();
    if (onUpdateSyllabusChapter) {
      onUpdateSyllabusChapter(id, !currentStatus);
    }
    showToast(!currentStatus ? '✅ مبحث به عنوان مطالعه‌شده ثبت شد!' : 'مبحث به حالت در حال مطالعه برگشت.', 'info');
  };

  return (
    <div className="space-y-8 animate-fadeIn pb-12 font-vazir" dir="rtl">
      {/* Hero Banner with Esfand Target Countdown */}
      <div
        className="relative overflow-hidden rounded-3xl p-6 sm:p-8 text-white shadow-xl transition-all"
        style={{
          background: `linear-gradient(135deg, ${theme.accentColor} 0%, #1e1b4b 50%, #0f172a 100%)`,
        }}
      >
        <div className="absolute -right-16 -top-16 h-64 w-64 rounded-full bg-white/10 blur-3xl pointer-events-none" />
        <div className="absolute -left-16 -bottom-16 h-64 w-64 rounded-full bg-indigo-500/20 blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="space-y-3 max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/15 backdrop-blur-md text-xs sm:text-sm font-bold border border-white/20">
              <Sparkles className="w-4 h-4 text-amber-300 animate-spin" style={{ animationDuration: '6s' }} />
              <span>استراتژی راهبردی سالانه کنکور تجربی {toPersianDigits(annualPlan.academicYear || '۱۴۰۴-۱۴۰۵')}</span>
            </div>

            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black tracking-tight leading-tight">
              {annualPlan.title}
            </h1>

            <p className="text-sm sm:text-base text-indigo-100 leading-relaxed">
              {annualPlan.overallGoal}
            </p>

            {/* Target Milestone Highlight Box */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <div className="flex items-center gap-2 px-4 py-2 rounded-2xl bg-amber-500/25 border border-amber-400/40 text-amber-200 text-xs sm:text-sm font-bold shadow-sm">
                <Target className="w-4 h-4 text-amber-300" />
                <span>ضرب‌الاجل طلایی: {annualPlan.targetDeadline}</span>
              </div>
              <div className="flex items-center gap-2 px-4 py-2 rounded-2xl bg-white/10 border border-white/15 text-white text-xs sm:text-sm font-medium">
                <Brain className="w-4 h-4 text-emerald-300" />
                <span>متدهای علمی: ابینگهاوس + بازیابی فعال + ایستگاه‌های جبرانی</span>
              </div>
            </div>
          </div>

          {/* AI Trigger and Quick Actions */}
          <div className="flex flex-col sm:flex-row lg:flex-col gap-3 w-full sm:w-auto shrink-0">
            <button
              onClick={() => onOpenAIPlannerModal('annual')}
              className="px-6 py-3.5 rounded-2xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-900 font-extrabold shadow-lg hover:shadow-xl active:scale-95 transition-all flex items-center justify-center gap-2.5 group cursor-pointer"
            >
              <Sparkles className="w-5 h-5 text-slate-900 group-hover:rotate-12 transition-transform" />
              <span>بازتنظیم سالانه با هوش مصنوعی</span>
            </button>

            <button
              onClick={() => {
                if (onApplyMonthToStudyParts && currentMonthData) {
                  onApplyMonthToStudyParts(currentMonthData);
                } else {
                  showToast(`برنامه ماه ${currentMonthData.monthName} با موفقیت در پارت‌ها اعمال شد!`, 'success');
                }
              }}
              className="px-5 py-3 rounded-2xl bg-white/15 hover:bg-white/25 active:scale-95 text-white font-bold backdrop-blur-md border border-white/20 transition-all flex items-center justify-center gap-2 cursor-pointer text-sm"
            >
              <Zap className="w-4 h-4 text-amber-300" />
              <span>اعمال اهداف {currentMonthData.monthName} در پارت‌ها و برنامه هفتگی</span>
            </button>
          </div>
        </div>

        {/* Global Progress Indicators */}
        <div className="mt-8 pt-6 border-t border-white/15 grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3.5 border border-white/10">
            <div className="text-xs text-indigo-200">پیشرفت کل مباحث تا اسفند</div>
            <div className="text-xl sm:text-2xl font-black text-white mt-1">
              {toPersianDigits(syllabusProgressPercent)}٪
            </div>
            <div className="w-full bg-white/20 h-2 rounded-full overflow-hidden mt-2">
              <div
                className="h-full bg-gradient-to-r from-emerald-400 to-teal-300 rounded-full transition-all duration-1000"
                style={{ width: `${syllabusProgressPercent}%` }}
              />
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3.5 border border-white/10">
            <div className="text-xs text-indigo-200">فصول تکمیل‌شده</div>
            <div className="text-xl sm:text-2xl font-black text-white mt-1">
              {toPersianDigits(completedChapters)} <span className="text-xs font-normal text-indigo-200">از {toPersianDigits(totalChapters)} فصل</span>
            </div>
            <div className="text-xs text-emerald-300 mt-2 flex items-center gap-1 font-medium">
              <CheckCircle2 className="w-3.5 h-3.5" /> ۱۰، ۱۱ و ۱۲ تجربی
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3.5 border border-white/10">
            <div className="text-xs text-indigo-200">تست‌های حل‌شده امسال</div>
            <div className="text-xl sm:text-2xl font-black text-white mt-1">
              {toPersianDigits(totalTestsDoneOverall)} <span className="text-xs font-normal text-indigo-200">تست</span>
            </div>
            <div className="text-xs text-amber-300 mt-2 font-medium">
              هدف سالانه: {toPersianDigits(annualPlan.totalTargetTests || 18500)} تست
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3.5 border border-white/10">
            <div className="text-xs text-indigo-200">ساعت مطالعه امسال</div>
            <div className="text-xl sm:text-2xl font-black text-white mt-1">
              {toPersianDigits(totalCompletedHours)} <span className="text-xs font-normal text-indigo-200">ساعت</span>
            </div>
            <div className="text-xs text-cyan-300 mt-2 font-medium">
              هدف سالانه: {toPersianDigits(annualPlan.totalTargetHours || 1450)} ساعت
            </div>
          </div>
        </div>
      </div>

      {/* View Sub-Tabs Switcher */}
      <div className="flex items-center justify-between flex-wrap gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div className="flex items-center gap-2 p-1.5 bg-slate-100 dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700">
          <button
            onClick={() => setActiveSubTab('months')}
            className={`px-4 py-2 rounded-xl text-sm font-bold transition-all flex items-center gap-2 cursor-pointer ${
              activeSubTab === 'months'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Calendar className="w-4 h-4" style={{ color: activeSubTab === 'months' ? theme.accentColor : undefined }} />
            <span>نقشه ماه به ماه (مهر تا اسفند و بهار)</span>
          </button>

          <button
            onClick={() => setActiveSubTab('syllabus')}
            className={`px-4 py-2 rounded-xl text-sm font-bold transition-all flex items-center gap-2 cursor-pointer ${
              activeSubTab === 'syllabus'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <BookOpen className="w-4 h-4" style={{ color: activeSubTab === 'syllabus' ? theme.accentColor : undefined }} />
            <span>چک‌لیست سرفصل‌های دهم، یازدهم و دوازدهم</span>
          </button>

          <button
            onClick={() => setActiveSubTab('principles')}
            className={`px-4 py-2 rounded-xl text-sm font-bold transition-all flex items-center gap-2 cursor-pointer ${
              activeSubTab === 'principles'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Brain className="w-4 h-4" style={{ color: activeSubTab === 'principles' ? theme.accentColor : undefined }} />
            <span>متدهای علمی و استراتژی رتبه برتر</span>
          </button>
        </div>

        <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">
          هدف‌گذاری: بستن ۱۰۰٪ دروس تا پایان اسفند ماه
        </div>
      </div>

      {/* SUB-TAB 1: MONTH-BY-MONTH ROADMAP */}
      {activeSubTab === 'months' && (
        <div className="space-y-6">
          {/* Month Selector Carousel */}
          <div className="grid grid-cols-3 sm:grid-cols-5 md:grid-cols-9 gap-2">
            {annualPlan.months.map((m) => {
              const isSelected = m.monthIndex === selectedMonthIndex;
              const isEsfand = m.isMilestoneEsfand || m.monthIndex === 6;
              return (
                <button
                  key={m.id}
                  onClick={() => setSelectedMonthIndex(m.monthIndex)}
                  className={`relative p-3 rounded-2xl border text-center transition-all flex flex-col items-center justify-center gap-1 cursor-pointer ${
                    isSelected
                      ? 'border-2 shadow-md bg-white dark:bg-slate-800 scale-105 z-10'
                      : 'border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/60 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                  style={{
                    borderColor: isSelected ? theme.accentColor : undefined,
                  }}
                >
                  {isEsfand && (
                    <span className="absolute -top-2.5 px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-500 text-slate-900 shadow-sm">
                      🎯 ضرب‌الاجل
                    </span>
                  )}
                  <span className="text-xs font-bold text-slate-500 dark:text-slate-400">
                    ماه {toPersianDigits(m.monthIndex)}
                  </span>
                  <span
                    className={`text-sm font-black ${
                      isSelected ? 'text-slate-900 dark:text-white' : 'text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    {m.monthName}
                  </span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300 font-medium">
                    {m.season}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Active Month Detail Card */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm space-y-6">
            {/* Header of Active Month */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-6 border-b border-slate-100 dark:border-slate-800">
              <div className="space-y-1">
                <div className="flex items-center gap-3">
                  <span
                    className="px-3 py-1 rounded-xl text-xs font-bold text-white shadow-sm"
                    style={{ backgroundColor: theme.accentColor }}
                  >
                    {currentMonthData.monthName} ({currentMonthData.season})
                  </span>
                  {currentMonthData.isMilestoneEsfand && (
                    <span className="px-3 py-1 rounded-xl text-xs font-black bg-amber-500/20 text-amber-600 dark:text-amber-400 border border-amber-500/30">
                      🎯 نقطه عطف طلایی: اتمام ۱۰۰٪ پایه و دوازدهم
                    </span>
                  )}
                </div>
                <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white pt-1">
                  {currentMonthData.phaseTitle}
                </h2>
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  {currentMonthData.targetGoal}
                </p>
              </div>

              <div className="flex items-center gap-4 bg-slate-50 dark:bg-slate-800/80 px-4 py-3 rounded-2xl border border-slate-200 dark:border-slate-700">
                <div className="text-center">
                  <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">هدف ساعت</div>
                  <div className="text-lg font-black text-slate-900 dark:text-white">
                    {toPersianDigits(currentMonthData.targetMonthlyHours)} <span className="text-xs font-normal">ساعت</span>
                  </div>
                </div>
                <div className="h-8 w-px bg-slate-200 dark:bg-slate-700" />
                <div className="text-center">
                  <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">هدف تست</div>
                  <div className="text-lg font-black text-emerald-600 dark:text-emerald-400">
                    {toPersianDigits(currentMonthData.targetMonthlyTests)} <span className="text-xs font-normal">تست</span>
                  </div>
                </div>
              </div>
            </div>

            {/* 3-Column Syllabus Coverage for 10th, 11th, and 12th */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Grade 10th */}
              <div className="bg-sky-50/50 dark:bg-sky-950/20 rounded-2xl p-5 border border-sky-200/60 dark:border-sky-800/40 space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-black text-sky-900 dark:text-sky-200 flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-sky-500" />
                    سرفصل‌های پایه دهم
                  </h3>
                  <span className="text-xs font-bold text-sky-600 dark:text-sky-400 bg-sky-100 dark:bg-sky-900/60 px-2 py-0.5 rounded-md">
                    پایه ۱
                  </span>
                </div>
                <div className="space-y-2 text-xs">
                  {Object.entries(currentMonthData.grade10Coverage || {}).map(([subj, ch]) => (
                    <div key={subj} className="bg-white dark:bg-slate-900/90 p-2.5 rounded-xl border border-sky-100 dark:border-sky-900/30">
                      <div className="font-bold text-slate-800 dark:text-slate-200">{subj}:</div>
                      <div className="text-slate-600 dark:text-slate-400 mt-0.5 leading-relaxed">{ch}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Grade 11th */}
              <div className="bg-teal-50/50 dark:bg-teal-950/20 rounded-2xl p-5 border border-teal-200/60 dark:border-teal-800/40 space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-black text-teal-900 dark:text-teal-200 flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-teal-500" />
                    سرفصل‌های پایه یازدهم
                  </h3>
                  <span className="text-xs font-bold text-teal-600 dark:text-teal-400 bg-teal-100 dark:bg-teal-900/60 px-2 py-0.5 rounded-md">
                    پایه ۲
                  </span>
                </div>
                <div className="space-y-2 text-xs">
                  {Object.entries(currentMonthData.grade11Coverage || {}).map(([subj, ch]) => (
                    <div key={subj} className="bg-white dark:bg-slate-900/90 p-2.5 rounded-xl border border-teal-100 dark:border-teal-900/30">
                      <div className="font-bold text-slate-800 dark:text-slate-200">{subj}:</div>
                      <div className="text-slate-600 dark:text-slate-400 mt-0.5 leading-relaxed">{ch}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Grade 12th */}
              <div className="bg-indigo-50/50 dark:bg-indigo-950/20 rounded-2xl p-5 border border-indigo-200/60 dark:border-indigo-800/40 space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-black text-indigo-900 dark:text-indigo-200 flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-indigo-500" />
                    سرفصل‌های دوازدهم + نهایی
                  </h3>
                  <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-100 dark:bg-indigo-900/60 px-2 py-0.5 rounded-md">
                    کنکور و نهایی
                  </span>
                </div>
                <div className="space-y-2 text-xs">
                  {Object.entries(currentMonthData.grade12Coverage || {}).map(([subj, ch]) => (
                    <div key={subj} className="bg-white dark:bg-slate-900/90 p-2.5 rounded-xl border border-indigo-100 dark:border-indigo-900/30">
                      <div className="font-bold text-slate-800 dark:text-slate-200">{subj}:</div>
                      <div className="text-slate-600 dark:text-slate-400 mt-0.5 leading-relaxed">{ch}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Ebbinghaus Review Stations for Active Month */}
            <div className="bg-gradient-to-r from-purple-500/10 via-indigo-500/10 to-teal-500/10 rounded-2xl p-5 border border-purple-300/40 dark:border-purple-800/50 space-y-3">
              <div className="flex items-center gap-2">
                <Brain className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                <h3 className="text-base font-black text-slate-900 dark:text-white">
                  🧠 تایم‌ها و ایستگاه‌های مرور اختصاصی {currentMonthData.monthName} (متد ابینگهاوس)
                </h3>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400">
                برنامه فواصل مرور این ماه برای تثبیت ۱۰۰٪ مباحث در حافظه بلندمدت (ساعت ۲۱:۱۵ الی ۲۲:۱۵):
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3 pt-1">
                {(currentMonthData.reviewSchedules || [
                  { interval: 'مرور ۲۴ ساعته', description: 'تست‌های بازیابی روز بعد', dateNote: 'هر شب ۲۱:۱۵' },
                  { interval: 'مرور ۳ روزه', description: 'تست‌های پوششی سه‌شنبه‌ها', dateNote: 'باکس عصر' },
                  { interval: 'مرور ۷ روزه', description: 'ایستگاه جبرانی پنجشنبه', dateNote: 'پنجشنبه‌ها' },
                  { interval: 'مرور ۱۵ روزه', description: 'آزمونک نیم‌ماه', dateNote: 'پایان هفته دوم' },
                  { interval: 'مرور ۳۰ روزه', description: 'جعبه لایتنر ماهانه', dateNote: 'جمعه آخر ماه' },
                ]).map((rev, idx) => (
                  <div key={idx} className="bg-white dark:bg-slate-900 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1 shadow-2xs">
                    <div className="text-[10px] font-extrabold text-purple-600 dark:text-purple-400 bg-purple-50 dark:bg-purple-950/50 px-2 py-0.5 rounded-md inline-block">
                      {rev.interval}
                    </div>
                    <div className="text-xs font-bold text-slate-800 dark:text-slate-200">
                      {rev.description}
                    </div>
                    <div className="text-[11px] text-slate-500">{rev.dateNote}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Scientific Methods & Compensations */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-slate-100 dark:border-slate-800">
              <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2">
                <div className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-2">
                  <Brain className="w-4 h-4 text-purple-500" />
                  <span>متدهای علمی اجراشده در این ماه:</span>
                </div>
                <ul className="space-y-1.5 text-xs text-slate-600 dark:text-slate-400">
                  {currentMonthData.scientificMethods.map((method, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="text-emerald-500 font-bold mt-0.5">✓</span>
                      <span>{method}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2">
                <div className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-500" />
                  <span>ایستگاه‌های جبرانی و اهداف کلیدی:</span>
                </div>
                <div className="text-xs text-slate-600 dark:text-slate-400">
                  <strong>زمان جبرانی:</strong> {currentMonthData.compensationDays}
                </div>
                <ul className="space-y-1 text-xs text-slate-600 dark:text-slate-400 pt-1">
                  {currentMonthData.milestones.map((milestone, idx) => (
                    <li key={idx} className="flex items-start gap-1.5">
                      <span className="text-amber-500 font-bold">★</span>
                      <span>{milestone}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 2: SYLLABUS PROGRESS TRACKER */}
      {activeSubTab === 'syllabus' && (
        <div className="space-y-6">
          {/* Filters Bar */}
          <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-4">
            {/* Subject Selector */}
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-bold text-slate-500 dark:text-slate-400">درس:</span>
              {TAJROBI_SUBJECTS_LIST.filter((s) => s !== 'امتحانات نهایی / عمومی').map((subj) => {
                const isSelected = syllabusSubjectFilter === subj;
                const info = TAJROBI_SUBJECTS_INFO[subj];
                return (
                  <button
                    key={subj}
                    onClick={() => setSyllabusSubjectFilter(subj)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                      isSelected
                        ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 shadow-sm'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
                    }`}
                  >
                    <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: info.color }} />
                    <span>{subj}</span>
                  </button>
                );
              })}
            </div>

            {/* Grade Filter */}
            <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
              {(['all', 'دهم', 'یازدهم', 'دوازدهم'] as const).map((grade) => (
                <button
                  key={grade}
                  onClick={() => setSyllabusGradeFilter(grade)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    syllabusGradeFilter === grade
                      ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                  }`}
                >
                  {grade === 'all' ? 'همه پایه‌ها' : grade}
                </button>
              ))}
            </div>
          </div>

          {/* Chapters Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredChapters.map((chapter) => {
              return (
                <div
                  key={chapter.id}
                  className={`p-4 rounded-2xl border transition-all space-y-3 ${
                    chapter.isCompleted
                      ? 'bg-emerald-50/40 dark:bg-emerald-950/20 border-emerald-300/60 dark:border-emerald-800/40'
                      : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                          {chapter.gradeLevel}
                        </span>
                        <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                          فصل {toPersianDigits(chapter.chapterNumber)}
                        </span>
                        <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-100 dark:bg-amber-900/50 text-amber-800 dark:text-amber-300">
                          هدف: {chapter.targetMonth}
                        </span>
                      </div>
                      <h4 className="text-sm font-black text-slate-900 dark:text-white">
                        {chapter.chapterTitle}
                      </h4>
                    </div>

                    <button
                      onClick={() => handleToggleChapter(chapter.id, chapter.isCompleted)}
                      className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all cursor-pointer ${
                        chapter.isCompleted
                          ? 'bg-emerald-500 text-white shadow-sm scale-105'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 border border-slate-200 dark:border-slate-700'
                      }`}
                      title={chapter.isCompleted ? 'مطالعه‌شده' : 'علامت‌گذاری به عنوان تمام‌شده'}
                    >
                      {chapter.isCompleted ? <Check className="w-4 h-4 stroke-[3]" /> : <CheckCircle2 className="w-4 h-4" />}
                    </button>
                  </div>

                  <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 pt-2 border-t border-slate-100 dark:border-slate-800/80">
                    <div className="flex items-center gap-1 font-medium">
                      <span>تست‌های حل‌شده:</span>
                      <strong className="text-slate-800 dark:text-slate-200">{toPersianDigits(chapter.testCountDone)}</strong>
                    </div>

                    <div className="flex items-center gap-1 text-[11px] text-purple-600 dark:text-purple-400">
                      <RotateCcw className="w-3 h-3" />
                      <span>{toPersianDigits(chapter.reviewFrequency)} دور مرور</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* SUB-TAB 3: SCIENTIFIC PRINCIPLES */}
      {activeSubTab === 'principles' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 space-y-6">
          <div className="space-y-2">
            <h3 className="text-xl font-black text-slate-900 dark:text-white flex items-center gap-2">
              <Brain className="w-6 h-6 text-purple-500" />
              <span>چرا استراتژی اتمام دروس تا پایان اسفند موثرترین متد کنکور است؟</span>
            </h3>
            <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
              تحقیقات آموزشی و کارنامه رتبه‌های برتر کشوری نشان می‌دهد داوطلبانی که تمام دروس دهم، یازدهم و دوازدهم را تا پایان اسفند ماه یکبار با تست استاندارد تمام می‌کنند، در دوران طلایی نوروز و بهار به بالاترین درصد تسلط و ثبات حافظه دست می‌یابند.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 pt-2">
            {annualPlan.scientificFrameworkSummary.map((item, idx) => (
              <div key={idx} className="bg-slate-50 dark:bg-slate-800/60 p-5 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2">
                <div className="text-sm font-black text-slate-900 dark:text-white flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-500" />
                  <span>{item.split(' ')[0]} {item.split(' ')[1]}</span>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                  {item}
                </p>
              </div>
            ))}
          </div>

          <div className="bg-gradient-to-r from-emerald-50 to-teal-50 dark:from-emerald-950/20 dark:to-teal-950/20 p-5 rounded-2xl border border-emerald-200 dark:border-emerald-800/40 text-xs sm:text-sm text-emerald-900 dark:text-emerald-200 leading-relaxed">
            💡 <strong>توصیه مشاور:</strong> با خیالی راحت به برنامه اعتماد کنید. در صورتی که در طول هفته دچار کسری یا بیماری شدید، از ایستگاه‌های جبرانی تعبیه‌شده در پنجشنبه‌ها استفاده کنید تا نیازی به تغییر کل برنامه سالانه نباشد.
          </div>
        </div>
      )}
    </div>
  );
};
