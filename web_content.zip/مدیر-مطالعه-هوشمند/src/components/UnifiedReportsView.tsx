import React, { useState } from 'react';
import { StudyLog, TajrobiSubject, ThemeConfig } from '../types';
import {
  TAJROBI_SUBJECTS_INFO,
  TAJROBI_SUBJECTS_LIST,
  calculateStreak,
  formatMinutesToHoursAndMinutes,
  toPersianDigits,
} from '../utils/tajrobiData';
import {
  BarChart2,
  Calendar,
  Clock,
  Award,
  CheckCircle2,
  TrendingUp,
  Brain,
  Target,
  FileText,
  Trash2,
  Filter,
} from 'lucide-react';

interface UnifiedReportsViewProps {
  logs: StudyLog[];
  theme: ThemeConfig;
}

export const UnifiedReportsView: React.FC<UnifiedReportsViewProps> = ({ logs, theme }) => {
  const [selectedSubTab, setSelectedSubTab] = useState<'charts' | 'history' | 'advisor'>('charts');
  const [selectedSubjectFilter, setSelectedSubjectFilter] = useState<string>('all');

  // Overall Statistics
  const totalStudyMinutes = logs.reduce((acc, l) => acc + l.durationMinutes, 0);
  const totalTests = logs.reduce((acc, l) => acc + l.totalTests, 0);
  const totalCorrect = logs.reduce((acc, l) => acc + l.correctTests, 0);
  const averageAccuracy = totalTests > 0 ? Math.round((totalCorrect / totalTests) * 100) : 0;
  const streakDays = calculateStreak(logs);

  // Subject Breakdown
  const subjectStats: Record<
    TajrobiSubject,
    { minutes: number; tests: number; correct: number; count: number }
  > = {
    'زیست‌شناسی': { minutes: 0, tests: 0, correct: 0, count: 0 },
    'شیمی': { minutes: 0, tests: 0, correct: 0, count: 0 },
    'فیزیک': { minutes: 0, tests: 0, correct: 0, count: 0 },
    'ریاضی تجربی': { minutes: 0, tests: 0, correct: 0, count: 0 },
    'زمین‌شناسی': { minutes: 0, tests: 0, correct: 0, count: 0 },
    'امتحانات نهایی / عمومی': { minutes: 0, tests: 0, correct: 0, count: 0 },
  };

  logs.forEach((log) => {
    if (subjectStats[log.subject]) {
      subjectStats[log.subject].minutes += log.durationMinutes;
      subjectStats[log.subject].tests += log.totalTests;
      subjectStats[log.subject].correct += log.correctTests;
      subjectStats[log.subject].count += 1;
    }
  });

  // Filtered Logs
  const filteredLogs = logs.filter((log) =>
    selectedSubjectFilter === 'all' ? true : log.subject === selectedSubjectFilter
  );

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Summary Stat Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400">مجموع ساعت مطالعه</span>
            <Clock className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tabular-nums">
              {toPersianDigits((totalStudyMinutes / 60).toFixed(1))}
            </span>
            <span className="text-xs font-bold text-slate-500">ساعت</span>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400">مجموع تست‌ها</span>
            <Target className="w-4 h-4 text-blue-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tabular-nums">
              {toPersianDigits(totalTests)}
            </span>
            <span className="text-xs font-bold text-slate-500">تست</span>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400">میانگین درصد پاسخگویی</span>
            <Award className="w-4 h-4 text-amber-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tabular-nums">
              {toPersianDigits(averageAccuracy)}٪
            </span>
            <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400">دقت تست</span>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400">زنجیره استمرار</span>
            <TrendingUp className="w-4 h-4 text-rose-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tabular-nums">
              {toPersianDigits(streakDays)}
            </span>
            <span className="text-xs font-bold text-slate-500">روز پیوسته 🔥</span>
          </div>
        </div>
      </div>

      {/* Sub-tab Navigation */}
      <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-2">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setSelectedSubTab('charts')}
            className={`px-4 py-2 rounded-xl text-xs font-extrabold transition cursor-pointer flex items-center gap-1.5 ${
              selectedSubTab === 'charts'
                ? `${theme.activeNavTab} shadow-xs`
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            <BarChart2 className="w-3.5 h-3.5" />
            <span>نمودار تفکیک دروس</span>
          </button>

          <button
            type="button"
            onClick={() => setSelectedSubTab('history')}
            className={`px-4 py-2 rounded-xl text-xs font-extrabold transition cursor-pointer flex items-center gap-1.5 ${
              selectedSubTab === 'history'
                ? `${theme.activeNavTab} shadow-xs`
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>سوابق و کارنامه ({toPersianDigits(logs.length)})</span>
          </button>

          <button
            type="button"
            onClick={() => setSelectedSubTab('advisor')}
            className={`px-4 py-2 rounded-xl text-xs font-extrabold transition cursor-pointer flex items-center gap-1.5 ${
              selectedSubTab === 'advisor'
                ? `${theme.activeNavTab} shadow-xs`
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            <Brain className="w-3.5 h-3.5" />
            <span>تحلیل مشاوره‌ای و کیفیت</span>
          </button>
        </div>
      </div>

      {/* Sub-Tab 1: Subject Breakdown Charts */}
      {selectedSubTab === 'charts' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {TAJROBI_SUBJECTS_LIST.map((subj) => {
            const stat = subjectStats[subj];
            const info = TAJROBI_SUBJECTS_INFO[subj];
            const percentage =
              totalStudyMinutes > 0 ? Math.round((stat.minutes / totalStudyMinutes) * 100) : 0;
            const accuracy =
              stat.tests > 0 ? Math.round((stat.correct / stat.tests) * 100) : 0;

            return (
              <div
                key={subj}
                className="bg-white dark:bg-slate-900 rounded-2xl p-4 sm:p-5 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span
                      className="w-3.5 h-3.5 rounded-full inline-block"
                      style={{ backgroundColor: info?.color || '#059669' }}
                    />
                    <h4 className="font-extrabold text-sm text-slate-900 dark:text-white">
                      {subj}
                    </h4>
                  </div>
                  <span className="text-xs font-black text-slate-700 dark:text-slate-300 tabular-nums">
                    {formatMinutesToHoursAndMinutes(stat.minutes)}
                  </span>
                </div>

                {/* Progress bar */}
                <div className="w-full bg-slate-100 dark:bg-slate-800 h-2.5 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-300"
                    style={{
                      width: `${percentage}%`,
                      backgroundColor: info?.color || '#059669',
                    }}
                  />
                </div>

                <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-100 dark:border-slate-800 text-center text-xs">
                  <div>
                    <span className="text-[10px] text-slate-400 block">سهم از کل</span>
                    <span className="font-extrabold text-slate-800 dark:text-slate-200 tabular-nums">
                      {toPersianDigits(percentage)}٪
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block">تعداد تست</span>
                    <span className="font-extrabold text-slate-800 dark:text-slate-200 tabular-nums">
                      {toPersianDigits(stat.tests)}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block">درصد پاسخگویی</span>
                    <span className="font-extrabold text-emerald-600 dark:text-emerald-400 tabular-nums">
                      {toPersianDigits(accuracy)}٪
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Sub-Tab 2: History & Logs */}
      {selectedSubTab === 'history' && (
        <div className="space-y-4">
          {/* Subject Filter */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
            <span className="text-xs font-bold text-slate-500 shrink-0 flex items-center gap-1">
              <Filter className="w-3.5 h-3.5" /> فیلتر:
            </span>
            <button
              type="button"
              onClick={() => setSelectedSubjectFilter('all')}
              className={`px-3 py-1 rounded-xl text-xs font-bold transition cursor-pointer ${
                selectedSubjectFilter === 'all'
                  ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
              }`}
            >
              همه ({toPersianDigits(logs.length)})
            </button>
            {TAJROBI_SUBJECTS_LIST.map((subj) => (
              <button
                key={subj}
                type="button"
                onClick={() => setSelectedSubjectFilter(subj)}
                className={`px-3 py-1 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap ${
                  selectedSubjectFilter === subj
                    ? 'bg-emerald-600 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                }`}
              >
                {subj}
              </button>
            ))}
          </div>

          {/* Logs List */}
          {filteredLogs.length === 0 ? (
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-8 border border-slate-200 dark:border-slate-800 text-center">
              <p className="text-xs text-slate-500">هیچ سابقه مطالعاتی برای این فیلتر ثبت نشده است.</p>
            </div>
          ) : (
            <div className="space-y-2.5">
              {filteredLogs.map((log) => {
                const info = TAJROBI_SUBJECTS_INFO[log.subject];

                return (
                  <div
                    key={log.id}
                    className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-2xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
                  >
                    <div className="flex items-start sm:items-center gap-3">
                      <div
                        className="w-10 h-10 rounded-xl flex items-center justify-center text-white text-xs font-bold shrink-0"
                        style={{ backgroundColor: info?.color || '#059669' }}
                      >
                        {log.subject.slice(0, 3)}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-extrabold text-sm text-slate-900 dark:text-white">
                            {log.subject}
                          </span>
                          <span className="text-[10px] text-slate-400 tabular-nums">
                            {log.jalaliDate} · {log.timestamp}
                          </span>
                        </div>
                        <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5 font-medium">
                          {log.topic} {log.bookSource && `· منبع: ${log.bookSource}`}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 self-end sm:self-center text-xs font-bold tabular-nums">
                      <div className="text-right">
                        <span className="text-[10px] text-slate-400 block font-normal">مدت زمان</span>
                        <span className="text-slate-800 dark:text-slate-200 font-extrabold">
                          {formatMinutesToHoursAndMinutes(log.durationMinutes)}
                        </span>
                      </div>

                      {log.totalTests > 0 && (
                        <div className="text-right border-r border-slate-200 dark:border-slate-700 pr-3">
                          <span className="text-[10px] text-slate-400 block font-normal">تست و دقت</span>
                          <span className="text-emerald-600 dark:text-emerald-400 font-extrabold">
                            {toPersianDigits(log.correctTests)}/{toPersianDigits(log.totalTests)} ({toPersianDigits(log.accuracyPercentage)}٪)
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Sub-Tab 3: Advisory Insights */}
      {selectedSubTab === 'advisor' && (
        <div className="space-y-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-4">
            <h3 className="font-extrabold text-sm sm:text-base text-slate-900 dark:text-white flex items-center gap-2">
              <Brain className="w-4 h-4 text-purple-500" />
              <span>اصول علمی مطالعه و رتبه‌سازی در کنکور تجربی</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div className="p-4 rounded-xl bg-emerald-50/60 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/60 space-y-1.5">
                <span className="text-xs font-black text-emerald-800 dark:text-emerald-300">
                  ۱. بازیابی فعال (Active Recall)
                </span>
                <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                  قبل از بازخوانی جزوه، ۱۰ تا ۱۵ دقیقه تست آزمایشی بزنید تا نقاط تاریک حافظه مشخص شود.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-blue-50/60 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800/60 space-y-1.5">
                <span className="text-xs font-black text-blue-800 dark:text-blue-300">
                  ۲. یادگیری درهم‌تنیده (Interleaving)
                </span>
                <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                  مطالعه یک درس را بیش از ۲.۵ ساعت متوالی ادامه ندهید. دروس محاسباتی و مفهومی را یک‌درمیان بخوانید.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-amber-50/60 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/60 space-y-1.5">
                <span className="text-xs font-black text-amber-800 dark:text-amber-300">
                  ۳. جبران کسری‌ها در آخر هفته
                </span>
                <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                  پارت‌هایی که در طول هفته ناقص مانده‌اند را در تایم‌های اختصاصی جبرانی پنجشنبه عصر بخوانید.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
