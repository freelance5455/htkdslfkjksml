import React, { useState } from 'react';
import {
  DayOfWeek,
  GradeLevel,
  Priority,
  StudyPart,
  TajrobiSubject,
  ThemeConfig,
  TopicMemoryItem,
} from '../types';
import {
  DAYS_OF_WEEK,
  GRADE_LEVELS,
  GRADE_META,
  PRIORITY_LABELS,
  TAJROBI_SUBJECTS_INFO,
  TAJROBI_SUBJECTS_LIST,
  detectGradeFromText,
  getTodayPersianDayOfWeek,
  toPersianDigits,
} from '../utils/tajrobiData';
import { AIStudyPlannerModal } from './AIStudyPlannerModal';
import {
  Plus,
  Filter,
  CheckCircle2,
  Clock,
  BookOpen,
  Play,
  Trash2,
  Check,
  AlertCircle,
  Tag,
  Bot,
  Sparkles,
  Pencil,
  RotateCcw,
  Edit3,
} from 'lucide-react';

interface StudyPartsViewProps {
  parts: StudyPart[];
  theme?: ThemeConfig;
  topicMemories?: TopicMemoryItem[];
  onSaveTopicMemory?: (memories: TopicMemoryItem[]) => void;
  onAddPart: (part: Omit<StudyPart, 'id' | 'createdAt'>) => void;
  onAddMultipleParts?: (parts: Array<Omit<StudyPart, 'id' | 'createdAt'>>) => void;
  onUpdatePart?: (updatedPart: StudyPart) => void;
  onResetOnlyParts?: () => void;
  onToggleComplete: (id: string) => void;
  onDeletePart: (id: string) => void;
  onStartInTimer: (part: StudyPart) => void;
  showToast?: (message: string, type?: 'success' | 'warning' | 'info') => void;
}

export const StudyPartsView: React.FC<StudyPartsViewProps> = ({
  parts,
  theme,
  topicMemories = [],
  onSaveTopicMemory,
  onAddPart,
  onAddMultipleParts,
  onUpdatePart,
  onResetOnlyParts,
  onToggleComplete,
  onDeletePart,
  onStartInTimer,
  showToast,
}) => {
  const todayDay = getTodayPersianDayOfWeek();

  // Filters
  const [selectedDay, setSelectedDay] = useState<string>('all');
  const [selectedSubject, setSelectedSubject] = useState<string>('all');
  const [selectedGrade, setSelectedGrade] = useState<GradeLevel | 'all'>('all');
  const [selectedStatus, setSelectedStatus] = useState<'all' | 'pending' | 'completed'>('all');

  // AI Modal
  const [showAIModal, setShowAIModal] = useState<boolean>(false);

  // Edit Part Modal
  const [editingPart, setEditingPart] = useState<StudyPart | null>(null);

  // Reset Parts Only Modal
  const [showResetOnlyPartsModal, setShowResetOnlyPartsModal] = useState<boolean>(false);

  // New Part Form State
  const [showAddForm, setShowAddForm] = useState<boolean>(false);
  const [category, setCategory] = useState<TajrobiSubject>('زیست‌شناسی');
  const [gradeLevel, setGradeLevel] = useState<GradeLevel>('دهم');
  const [courseName, setCourseName] = useState<string>('زیست دهم');
  const [topic, setTopic] = useState<string>('');
  const [bookSource, setBookSource] = useState<string>('خیلی سبز جامع');
  const [estimatedMinutes, setEstimatedMinutes] = useState<number>(90);
  const [scheduledTime, setScheduledTime] = useState<string>('08:00');
  const [testCount, setTestCount] = useState<number>(30);
  const [priority, setPriority] = useState<Priority>('high');
  const [dayOfWeek, setDayOfWeek] = useState<DayOfWeek>(todayDay);

  // Form submit
  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic.trim()) return;

    onAddPart({
      category,
      gradeLevel,
      courseName: courseName || `${category} پایه ${gradeLevel}`,
      topic,
      bookSource,
      estimatedMinutes,
      actualMinutes: 0,
      scheduledTime,
      completed: false,
      testCount,
      priority,
      dayOfWeek,
    });

    setTopic('');
    setShowAddForm(false);
  };

  // Save edited part
  const handleSaveEditedPart = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPart || !editingPart.topic.trim()) return;

    if (onUpdatePart) {
      onUpdatePart(editingPart);
    }
    setEditingPart(null);
  };

  // Filter logic
  const filteredParts = parts.filter((part) => {
    if (selectedDay !== 'all' && part.dayOfWeek !== selectedDay) return false;
    if (selectedSubject !== 'all' && part.category !== selectedSubject) return false;
    if (selectedGrade !== 'all') {
      const partGrade = part.gradeLevel || detectGradeFromText(part.topic);
      if (partGrade !== selectedGrade) return false;
    }
    if (selectedStatus === 'pending' && part.completed) return false;
    if (selectedStatus === 'completed' && !part.completed) return false;
    return true;
  });

  const handleApplyAIParts = (newParts: Array<Omit<StudyPart, 'id' | 'createdAt'>>) => {
    if (onAddMultipleParts) {
      onAddMultipleParts(newParts);
    } else {
      newParts.forEach((p) => onAddPart(p));
    }
  };

  return (
    <div className="space-y-6 animate-fade-slide">
      {/* Top Header & Add Button */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-teal-600" />
            <span>مدیریت پارت‌های درسی کنکور تجربی</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            تعریف مبحث، بودجه‌بندی زمانی، ویرایش عنوان، پاکسازی اختصاصی پارت‌ها و تایمر مطالعه
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* AI Button */}
          <button
            type="button"
            onClick={() => setShowAIModal(true)}
            className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white text-xs font-black flex items-center justify-center gap-2 transition cursor-pointer shadow-xs"
          >
            <Bot className="w-4 h-4" />
            <span>🤖 برنامه‌ریزی با هوش مصنوعی</span>
          </button>

          {/* Reset Only Parts Button */}
          {onResetOnlyParts && (
            <button
              type="button"
              onClick={() => setShowResetOnlyPartsModal(true)}
              className="px-3.5 py-2.5 rounded-2xl border border-amber-300 dark:border-amber-700/80 bg-amber-50 dark:bg-amber-950/40 text-amber-900 dark:text-amber-200 hover:bg-amber-100 text-xs font-bold flex items-center justify-center gap-1.5 transition cursor-pointer shadow-2xs"
            >
              <RotateCcw className="w-4 h-4 text-amber-600" />
              <span>🧹 بازنشانی فقط پارت‌ها</span>
            </button>
          )}

          {/* Manual Add Button */}
          <button
            type="button"
            onClick={() => setShowAddForm(!showAddForm)}
            className="px-4 py-2.5 rounded-2xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-black flex items-center justify-center gap-2 transition cursor-pointer shadow-xs"
          >
            <Plus className="w-4 h-4" />
            <span>{showAddForm ? 'بستن فرم' : '+ پارت درسی دستی'}</span>
          </button>
        </div>
      </div>

      {/* Add New Part Modal / Collapsible Form */}
      {showAddForm && (
        <form
          onSubmit={handleFormSubmit}
          className="bg-white dark:bg-slate-900 rounded-3xl border-2 border-teal-500/40 p-6 shadow-md space-y-4 animate-fade-in"
        >
          <h3 className="text-sm font-black text-slate-900 dark:text-white pb-2 border-b border-slate-100 dark:border-slate-800">
            افزودن پارت درسی هدفمند
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Subject */}
            <div>
              <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1.5">
                درس رشته تجربی:
              </label>
              <select
                value={category}
                onChange={(e) => {
                  const newCat = e.target.value as TajrobiSubject;
                  setCategory(newCat);
                  const info = TAJROBI_SUBJECTS_INFO[newCat];
                  if (info.popularBooks[0]) setBookSource(info.popularBooks[0]);
                }}
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
              >
                {TAJROBI_SUBJECTS_LIST.map((subj) => (
                  <option key={subj} value={subj}>
                    {subj} ({TAJROBI_SUBJECTS_INFO[subj].coefficient})
                  </option>
                ))}
              </select>
            </div>

            {/* Grade Level */}
            <div>
              <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1.5">
                پایه تحصیلی:
              </label>
              <select
                value={gradeLevel}
                onChange={(e) => setGradeLevel(e.target.value as GradeLevel)}
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
              >
                {GRADE_LEVELS.map((gr) => (
                  <option key={gr} value={gr}>
                    پایه {gr}
                  </option>
                ))}
              </select>
            </div>

            {/* Day of week */}
            <div>
              <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1.5">
                روز مطالعه:
              </label>
              <select
                value={dayOfWeek}
                onChange={(e) => setDayOfWeek(e.target.value as DayOfWeek)}
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
              >
                {DAYS_OF_WEEK.map((d) => (
                  <option key={d} value={d}>
                    {d} {d === todayDay ? '(امروز)' : ''}
                  </option>
                ))}
              </select>
            </div>

            {/* Priority */}
            <div>
              <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1.5">
                اولویت پارت:
              </label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as Priority)}
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
              >
                <option value="high">اولویت بالا (ضروری)</option>
                <option value="medium">اولویت متوسط</option>
                <option value="low">اولویت پایین (مرور)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Topic */}
            <div className="lg:col-span-2">
              <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1.5">
                مبحث یا گفتار درس:
              </label>
              <input
                type="text"
                placeholder="مثال: گردش مواد در قلب و نوار قلب یا استوکیومتری"
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                required
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
              />
            </div>

            {/* Book source */}
            <div>
              <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1.5">
                منبع و کتاب تست:
              </label>
              <input
                type="text"
                value={bookSource}
                onChange={(e) => setBookSource(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
              />
            </div>

            {/* Scheduled Time & Test count */}
            <div className="flex gap-2">
              <div className="flex-1">
                <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1.5">
                  ساعت:
                </label>
                <input
                  type="time"
                  value={scheduledTime}
                  onChange={(e) => setScheduledTime(e.target.value)}
                  className="w-full px-2 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-center"
                />
              </div>
              <div className="flex-1">
                <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1.5">
                  تست هدف:
                </label>
                <input
                  type="number"
                  min={0}
                  max={200}
                  value={testCount}
                  onChange={(e) => setTestCount(Number(e.target.value))}
                  className="w-full px-2 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-center font-bold"
                />
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-xs font-bold cursor-pointer"
            >
              انصراف
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold cursor-pointer"
            >
              ذخیره و ثبت پارت
            </button>
          </div>
        </form>
      )}

      {/* Filter Bar */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-3">
          <span className="font-extrabold text-slate-600 dark:text-slate-400 flex items-center gap-1">
            <Filter className="w-3.5 h-3.5" /> فیلترها:
          </span>

          {/* Day */}
          <select
            value={selectedDay}
            onChange={(e) => setSelectedDay(e.target.value)}
            className="px-2.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-bold"
          >
            <option value="all">تمام روزهای هفته</option>
            {DAYS_OF_WEEK.map((d) => (
              <option key={d} value={d}>
                {d}
              </option>
            ))}
          </select>

          {/* Subject */}
          <select
            value={selectedSubject}
            onChange={(e) => setSelectedSubject(e.target.value)}
            className="px-2.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-bold"
          >
            <option value="all">تمام دروس</option>
            {TAJROBI_SUBJECTS_LIST.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>

          {/* Grade Level */}
          <select
            value={selectedGrade}
            onChange={(e) => setSelectedGrade(e.target.value as GradeLevel | 'all')}
            className="px-2.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-bold"
          >
            <option value="all">تمام پایه‌ها (دهم/یازدهم/دوازدهم/جامع)</option>
            {GRADE_LEVELS.map((g) => (
              <option key={g} value={g}>
                پایه {g}
              </option>
            ))}
          </select>

          {/* Status */}
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value as any)}
            className="px-2.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-bold"
          >
            <option value="all">همه وضعیت‌ها</option>
            <option value="pending">در انتظار مطالعه</option>
            <option value="completed">تکمیل شده</option>
          </select>
        </div>

        <div className="text-slate-500 font-bold tabular-nums">
          نمایش {toPersianDigits(filteredParts.length)} پارت از {toPersianDigits(parts.length)}
        </div>
      </div>

      {/* Parts List */}
      <div className="space-y-3">
        {filteredParts.length === 0 ? (
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-10 border border-slate-200 dark:border-slate-800 text-center">
            <BookOpen className="w-12 h-12 mx-auto text-slate-300 dark:text-slate-600 mb-3" />
            <h4 className="font-extrabold text-slate-700 dark:text-slate-300 text-sm">
              هیچ پارتی با فیلترهای انتخابی یافت نشد
            </h4>
            <p className="text-xs text-slate-500 mt-1">
              می‌توانید با دستیار هوش مصنوعی یک برنامه جدید بنویسید یا فیلترها را ریست کنید.
            </p>
            <div className="mt-4 flex items-center justify-center gap-2">
              <button
                type="button"
                onClick={() => setShowAIModal(true)}
                className="px-4 py-2 rounded-xl bg-purple-600 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                <Bot className="w-4 h-4" />
                <span>برنامه‌ریزی هوش مصنوعی</span>
              </button>
            </div>
          </div>
        ) : (
          filteredParts.map((part) => {
            const subjectInfo = TAJROBI_SUBJECTS_INFO[part.category];
            const pLabel = PRIORITY_LABELS[part.priority];
            const partGrade = part.gradeLevel || detectGradeFromText(part.topic);
            const gradeMeta = GRADE_META[partGrade];

            return (
              <div
                key={part.id}
                className={`bg-white dark:bg-slate-900 rounded-2xl p-4 sm:p-5 border transition flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-2xs ${
                  pLabel.borderClass
                } ${part.completed ? 'opacity-70 bg-emerald-50/20 dark:bg-emerald-950/10' : ''}`}
              >
                <div className="flex items-start sm:items-center gap-3 w-full sm:w-auto">
                  {/* Completion Toggle checkbox */}
                  <button
                    type="button"
                    onClick={() => onToggleComplete(part.id)}
                    className={`w-7 h-7 rounded-xl flex items-center justify-center transition shrink-0 cursor-pointer ${
                      part.completed
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'border-2 border-slate-300 dark:border-slate-700 hover:border-emerald-500 text-transparent'
                    }`}
                  >
                    <Check className="w-4 h-4 stroke-[3]" />
                  </button>

                  {/* Details */}
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <span
                        className="text-[10px] font-bold px-2 py-0.5 rounded-md text-white"
                        style={{ backgroundColor: subjectInfo?.color || '#0d9488' }}
                      >
                        {part.category}
                      </span>

                      {gradeMeta && (
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${gradeMeta.badgeClass}`}>
                          {gradeMeta.shortLabel}
                        </span>
                      )}

                      <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                        {part.dayOfWeek} · ساعت {toPersianDigits(part.scheduledTime)}
                      </span>

                      <span className={`text-[10px] font-bold ${pLabel.badgeClass}`}>
                        {pLabel.label}
                      </span>
                    </div>

                    <h4
                      className={`font-extrabold text-sm text-slate-900 dark:text-white mt-1 ${
                        part.completed ? 'line-through text-slate-400 dark:text-slate-500' : ''
                      }`}
                    >
                      {part.topic}
                    </h4>

                    <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 dark:text-slate-400 mt-1">
                      <span>منبع: {part.bookSource}</span>
                      <span>·</span>
                      <span>مدت: {toPersianDigits(part.estimatedMinutes)} دقیقه</span>
                      {part.testCount > 0 && (
                        <>
                          <span>·</span>
                          <span className="text-emerald-600 dark:text-emerald-400 font-bold">
                            هدف: {toPersianDigits(part.testCount)} تست
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                  <button
                    type="button"
                    onClick={() => onStartInTimer(part)}
                    className="px-3.5 py-2 rounded-xl bg-teal-50 dark:bg-teal-950/60 hover:bg-teal-100 dark:hover:bg-teal-900 text-teal-700 dark:text-teal-300 text-xs font-black flex items-center gap-1.5 transition cursor-pointer border border-teal-200 dark:border-teal-800"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>مطالعه با تایمر</span>
                  </button>

                  {/* Edit Part Button */}
                  <button
                    type="button"
                    onClick={() => setEditingPart(part)}
                    className="p-2 rounded-xl text-slate-400 hover:text-teal-600 hover:bg-teal-50 dark:hover:bg-teal-950/50 transition cursor-pointer"
                    title="ویرایش عنوان و مشخصات پارت"
                  >
                    <Pencil className="w-4 h-4" />
                  </button>

                  <button
                    type="button"
                    onClick={() => onDeletePart(part.id)}
                    className="p-2 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/50 transition cursor-pointer"
                    title="حذف پارت"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Edit Part Modal Dialog */}
      {editingPart && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
          <form
            onSubmit={handleSaveEditedPart}
            className="w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl border border-teal-500/40 p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto"
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-sm font-black text-slate-900 dark:text-white flex items-center gap-2">
                <Edit3 className="w-4 h-4 text-teal-600" />
                <span>ویرایش پارت درسی</span>
              </h3>
              <button
                type="button"
                onClick={() => setEditingPart(null)}
                className="text-slate-400 hover:text-slate-600 text-xs font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Category */}
              <div>
                <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">
                  درس:
                </label>
                <select
                  value={editingPart.category}
                  onChange={(e) =>
                    setEditingPart({ ...editingPart, category: e.target.value as TajrobiSubject })
                  }
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                >
                  {TAJROBI_SUBJECTS_LIST.map((subj) => (
                    <option key={subj} value={subj}>
                      {subj}
                    </option>
                  ))}
                </select>
              </div>

              {/* Grade Level */}
              <div>
                <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">
                  پایه تحصیلی:
                </label>
                <select
                  value={editingPart.gradeLevel || 'دهم'}
                  onChange={(e) =>
                    setEditingPart({ ...editingPart, gradeLevel: e.target.value as GradeLevel })
                  }
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                >
                  {GRADE_LEVELS.map((gr) => (
                    <option key={gr} value={gr}>
                      پایه {gr}
                    </option>
                  ))}
                </select>
              </div>

              {/* Topic / Title */}
              <div className="sm:col-span-2">
                <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">
                  عنوان و مبحث پارت درسی:
                </label>
                <input
                  type="text"
                  value={editingPart.topic}
                  onChange={(e) => setEditingPart({ ...editingPart, topic: e.target.value })}
                  required
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                />
              </div>

              {/* Book source */}
              <div>
                <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">
                  منبع و کتاب تست:
                </label>
                <input
                  type="text"
                  value={editingPart.bookSource}
                  onChange={(e) => setEditingPart({ ...editingPart, bookSource: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                />
              </div>

              {/* Day of Week */}
              <div>
                <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">
                  روز مطالعه:
                </label>
                <select
                  value={editingPart.dayOfWeek}
                  onChange={(e) =>
                    setEditingPart({ ...editingPart, dayOfWeek: e.target.value as DayOfWeek })
                  }
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                >
                  {DAYS_OF_WEEK.map((d) => (
                    <option key={d} value={d}>
                      {d}
                    </option>
                  ))}
                </select>
              </div>

              {/* Scheduled Time */}
              <div>
                <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">
                  ساعت شروع:
                </label>
                <input
                  type="time"
                  value={editingPart.scheduledTime}
                  onChange={(e) => setEditingPart({ ...editingPart, scheduledTime: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-center"
                />
              </div>

              {/* Target Tests */}
              <div>
                <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">
                  تعداد تست هدف:
                </label>
                <input
                  type="number"
                  min={0}
                  max={300}
                  value={editingPart.testCount}
                  onChange={(e) =>
                    setEditingPart({ ...editingPart, testCount: Number(e.target.value) || 0 })
                  }
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-center"
                />
              </div>

              {/* Estimated minutes */}
              <div>
                <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">
                  زمان پیش‌بینی‌شده (دقیقه):
                </label>
                <input
                  type="number"
                  min={15}
                  max={300}
                  value={editingPart.estimatedMinutes}
                  onChange={(e) =>
                    setEditingPart({ ...editingPart, estimatedMinutes: Number(e.target.value) || 90 })
                  }
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-center"
                />
              </div>

              {/* Priority */}
              <div>
                <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">
                  اولویت:
                </label>
                <select
                  value={editingPart.priority}
                  onChange={(e) =>
                    setEditingPart({ ...editingPart, priority: e.target.value as Priority })
                  }
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                >
                  <option value="high">اولویت بالا</option>
                  <option value="medium">اولویت متوسط</option>
                  <option value="low">اولویت پایین</option>
                </select>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setEditingPart(null)}
                className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-xs font-bold cursor-pointer"
              >
                انصراف
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold cursor-pointer"
              >
                ذخیره تغییرات پارت
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Reset Only Parts Confirmation Modal */}
      {showResetOnlyPartsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
          <div className="relative w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl border-2 border-amber-400 p-6 shadow-2xl space-y-4 text-center">
            <div className="w-14 h-14 rounded-2xl bg-amber-100 dark:bg-amber-950/80 text-amber-600 dark:text-amber-400 flex items-center justify-center mx-auto">
              <RotateCcw className="w-7 h-7" />
            </div>

            <div className="space-y-1.5">
              <h3 className="text-base font-black text-slate-900 dark:text-white">
                پاکسازی و بازنشانی فقط پارت‌های مطالعه
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                آیا از پاکسازی تمام پارت‌های درسی اطمینان دارید؟
                <br />
                <strong className="text-amber-600 dark:text-amber-400 font-bold block mt-1">
                  💡 تمام گزارش‌های گذشته، سوابق تایمر، کارنامه‌ها و آزمون‌ها دست‌نخورده باقی می‌مانند.
                </strong>
              </p>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  if (onResetOnlyParts) {
                    onResetOnlyParts();
                  }
                  setShowResetOnlyPartsModal(false);
                }}
                className="flex-1 py-2.5 rounded-2xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs cursor-pointer shadow-md"
              >
                بله، پاکسازی فقط پارت‌ها
              </button>
              <button
                type="button"
                onClick={() => setShowResetOnlyPartsModal(false)}
                className="px-4 py-2.5 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold text-xs cursor-pointer"
              >
                انصراف
              </button>
            </div>
          </div>
        </div>
      )}

      {/* AI Study Planner Modal */}
      <AIStudyPlannerModal
        isOpen={showAIModal}
        onClose={() => setShowAIModal(false)}
        theme={theme || {
          id: 'emerald',
          name: 'سبز زمردی',
          englishName: 'Emerald',
          badge: 'تجربی',
          accentColor: '#059669',
          primaryBtn: 'bg-emerald-600 hover:bg-emerald-700 text-white',
          ringColor: 'ring-emerald-500',
          badgeBg: 'bg-emerald-100',
          headerGrad: 'from-emerald-600 to-teal-700',
          activeNavTab: 'bg-emerald-600 text-white',
          borderAccent: 'border-emerald-500',
          subtleBg: 'bg-emerald-50',
          cardGlow: '',
        }}
        topicMemories={topicMemories}
        onSaveTopicMemory={onSaveTopicMemory}
        onApplyPlanToParts={handleApplyAIParts}
        showToast={showToast || (() => {})}
      />
    </div>
  );
};
