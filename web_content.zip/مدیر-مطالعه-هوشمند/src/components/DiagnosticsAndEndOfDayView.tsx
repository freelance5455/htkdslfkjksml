import React, { useState } from 'react';
import {
  DailyDiagnosticReport,
  DayOfWeek,
  StudyLog,
  StudyPart,
} from '../types';
import {
  analyzePlanWithGlobalMethods,
  getTodayJalali,
  getTodayPersianDayOfWeek,
  toPersianDigits,
} from '../utils/tajrobiData';
import {
  Sparkles,
  AlertTriangle,
  CheckCircle2,
  Brain,
  Moon,
  Clock,
  Send,
  Zap,
  Star,
  Check,
} from 'lucide-react';

interface DiagnosticsAndEndOfDayViewProps {
  parts: StudyPart[];
  logs: StudyLog[];
  todayReports: DailyDiagnosticReport[];
  dailyTestGoal: number;
  onSaveNightlyReport: (report: DailyDiagnosticReport) => void;
  onSwitchTab: (tab: any) => void;
}

export const DiagnosticsAndEndOfDayView: React.FC<DiagnosticsAndEndOfDayViewProps> = ({
  parts,
  logs,
  todayReports,
  dailyTestGoal,
  onSaveNightlyReport,
  onSwitchTab,
}) => {
  const todayDay = getTodayPersianDayOfWeek();
  const analysis = analyzePlanWithGlobalMethods(parts, logs, todayDay);

  const todayISO = new Date().toISOString().slice(0, 10);
  const todayLogs = logs.filter((l) => l.date === todayISO);
  const todayParts = parts.filter((p) => p.dayOfWeek === todayDay);

  const todayMinutes = todayLogs.reduce((acc, l) => acc + l.durationMinutes, 0);
  const todayTests = todayLogs.reduce((acc, l) => acc + l.totalTests, 0);
  const todayCorrect = todayLogs.reduce((acc, l) => acc + l.correctTests, 0);
  const todayAccuracy = todayTests > 0 ? Math.round((todayCorrect / todayTests) * 100) : 0;

  const incompleteParts = todayParts.filter((p) => !p.completed);

  // Nightly debrief form state
  const existingReport = todayReports.find((r) => r.date === todayISO);
  const [focusRating, setFocusRating] = useState<number>(existingReport?.selfFocusRating || 8);
  const [nightNotes, setNightNotes] = useState<string>(
    existingReport?.nightNotes ||
      'تمرکز پارت‌های صبح عالی بود، فردا پارت جبرانی را در اولین فرصت می‌خوانم.'
  );
  const [isSaved, setIsSaved] = useState<boolean>(!!existingReport);

  const handleSaveNightly = (e: React.FormEvent) => {
    e.preventDefault();
    const report: DailyDiagnosticReport = {
      date: todayISO,
      jalaliDate: getTodayJalali(),
      qualityScore: analysis.score,
      flaws: analysis.flaws,
      activeRecallRatio: analysis.activeRecallRatio,
      interleavingScore: analysis.interleavingScore,
      selfFocusRating: focusRating,
      nightNotes: nightNotes.trim(),
    };
    onSaveNightlyReport(report);
    setIsSaved(true);
  };

  return (
    <div className="space-y-6 animate-fade-slide">
      {/* Header Banner */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <h2 className="text-lg font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              <Brain className="w-5 h-5 text-teal-600" />
              <span>آسیب‌شناسی علمی برنامه با روش‌های جهانی + گزارش پایان روز</span>
            </h2>
            <p className="text-xs text-slate-600 dark:text-slate-400">
              ارزیابی هوشمند برنامه شما بر اساس ۵ متد علمی یادگیری (ابینگهاوس، بازیابی فعال دُنلوسکی، تمرین درهم‌تنیده هاروارد و ریتم پومودورو)
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="px-4 py-2 rounded-2xl bg-teal-50 dark:bg-teal-950/40 border border-teal-300 dark:border-teal-700 text-teal-900 dark:text-teal-200 text-xs font-black tabular-nums">
              نمره سلامت علمی برنامه: {toPersianDigits(analysis.score)} از ۱۰۰
            </div>
          </div>
        </div>
      </div>

      {/* 3 Metric Cards for Scientific Learning Health */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Metric 1: Active Recall Ratio */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs">
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 dark:text-slate-400">
            <span>نسبت بازیابی فعال (Active Recall)</span>
            <Sparkles className="w-4 h-4 text-teal-600" />
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white tabular-nums mt-2">
            {toPersianDigits(analysis.activeRecallRatio)}٪
          </div>
          <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            {analysis.activeRecallRatio >= 50 ? 'رعایت نسبت طلایی تست به مطالعه (تثبیت بالا)' : 'غلبه مطالعه انفعالی بر حل تست'}
          </div>
        </div>

        {/* Metric 2: Interleaving Diversity */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs">
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 dark:text-slate-400">
            <span>تنوع شناختی (Interleaved Practice)</span>
            <Brain className="w-4 h-4 text-purple-600" />
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white tabular-nums mt-2">
            {toPersianDigits(analysis.interleavingScore)}٪
          </div>
          <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            ترکیب متعادل دروس محاسباتی (ریاضی/فیزیک) با مفهومی (زیست/شیمی)
          </div>
        </div>

        {/* Metric 3: Today's Test Accuracy */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs">
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 dark:text-slate-400">
            <span>دقت تستی امروز (Accuracy)</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400 tabular-nums mt-2">
            {toPersianDigits(todayAccuracy)}٪
          </div>
          <div className="text-xs text-slate-500 dark:text-slate-400 mt-1 tabular-nums">
            {toPersianDigits(todayCorrect)} درست از {toPersianDigits(todayTests)} تست
          </div>
        </div>
      </div>

      {/* Diagnosed Flaws List (اشکالات برنامه با روش‌های جهانی) */}
      <div className="space-y-4">
        <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-500" />
          <span>آسیب‌شناسی علمی: اشکالات شناسایی‌شده در برنامه امروز ({toPersianDigits(analysis.flaws.length)} مورد)</span>
        </h3>

        {analysis.flaws.length === 0 ? (
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-emerald-300 dark:border-emerald-800 p-6 flex items-center gap-3 shadow-xs">
            <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0" />
            <div>
              <div className="font-extrabold text-sm text-slate-900 dark:text-white">
                هیچ نقص اساسی در برنامه امروز یافت نشد!
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">
                برنامه شما با اصول جهانی یادگیری (تکرار فاصله‌دار، تنوع بین‌درسی و آزمون‌محوری) کاملاً هماهنگ است.
              </p>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            {analysis.flaws.map((flaw, idx) => (
              <div
                key={idx}
                className="bg-white dark:bg-slate-900 rounded-2xl border border-amber-300/80 dark:border-amber-800/80 p-5 shadow-xs space-y-2.5"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="text-xs font-black text-amber-800 dark:text-amber-300 bg-amber-100 dark:bg-amber-900/40 px-2.5 py-1 rounded-lg">
                    متد علمی: {flaw.principle}
                  </span>
                  <span className="text-[11px] font-bold text-rose-600 dark:text-rose-400">
                    {flaw.severity === 'high' ? '⚠️ اولویت اصلاح: بالا' : 'اولویت اصلاح: متوسط'}
                  </span>
                </div>

                <div className="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-100 leading-relaxed">
                  <strong>اشکال برنامه: </strong>
                  {flaw.issue}
                </div>

                <div className="text-xs text-teal-800 dark:text-teal-200 bg-teal-50 dark:bg-teal-950/50 p-3 rounded-xl border border-teal-200 dark:border-teal-800/60 leading-relaxed">
                  <strong>راه‌حل استاندارد جهانی: </strong>
                  {flaw.globalSolution}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* End-of-Day Review Card (گزارش و جمع‌بندی پایان روز) */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-5">
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Moon className="w-5 h-5 text-indigo-500" />
            <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
              گزارش و تحلیل خودکار پایان روز (Nightly Debrief)
            </h3>
          </div>
          <span className="text-xs text-slate-500 dark:text-slate-400 tabular-nums">
            تاریخ امروز: {getTodayJalali()}
          </span>
        </div>

        {/* Day Performance Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60">
            <span className="text-xs text-slate-500 block">زمان کل مطالعه امروز:</span>
            <span className="text-lg font-black text-slate-900 dark:text-white tabular-nums mt-1 block">
              {toPersianDigits(todayMinutes)} دقیقه
            </span>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60">
            <span className="text-xs text-slate-500 block">تست‌های حل‌شده:</span>
            <span className="text-lg font-black text-slate-900 dark:text-white tabular-nums mt-1 block">
              {toPersianDigits(todayTests)} تست
            </span>
            <span className="text-[10px] text-slate-400">
              هدف: {toPersianDigits(dailyTestGoal)}
            </span>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60">
            <span className="text-xs text-slate-500 block">درصد پاسخگویی درست:</span>
            <span className="text-lg font-black text-emerald-600 dark:text-emerald-400 tabular-nums mt-1 block">
              {toPersianDigits(todayAccuracy)}٪
            </span>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60">
            <span className="text-xs text-slate-500 block">پارت‌های نصفه‌مانده:</span>
            <span className={`text-lg font-black tabular-nums mt-1 block ${incompleteParts.length > 0 ? 'text-amber-600' : 'text-emerald-600'}`}>
              {toPersianDigits(incompleteParts.length)} پارت
            </span>
          </div>
        </div>

        {/* Catch-up reminder if any incomplete */}
        {incompleteParts.length > 0 && (
          <div className="p-3.5 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 flex items-center justify-between text-xs">
            <span className="text-amber-900 dark:text-amber-200 font-bold">
              ⚠️ امروز {toPersianDigits(incompleteParts.length)} پارت نصفه‌مانده داری که به ایستگاه جبرانی فرستاده شده‌اند.
            </span>
            <button
              onClick={() => onSwitchTab('compensations')}
              className="px-3 py-1 bg-amber-500 hover:bg-amber-600 text-white rounded-lg font-bold transition cursor-pointer"
            >
              مشاهده جبرانی‌ها
            </button>
          </div>
        )}

        {/* Nightly Feedback Submission Form */}
        <form onSubmit={handleSaveNightly} className="space-y-4 pt-2">
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5 flex items-center gap-1.5">
              <Star className="w-4 h-4 text-amber-500 fill-amber-400" />
              <span>خودارزیابی کیفیت تمرکز امروز (از ۱۰):</span>
            </label>
            <div className="flex items-center gap-3">
              <input
                type="range"
                min={1}
                max={10}
                value={focusRating}
                onChange={(e) => {
                  setFocusRating(Number(e.target.value));
                  setIsSaved(false);
                }}
                className="w-full max-w-xs accent-teal-600"
              />
              <span className="text-base font-black text-teal-600 dark:text-teal-400 tabular-nums">
                {toPersianDigits(focusRating)} از ۱۰
              </span>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
              یادداشت شبانه و تعهد برای فردا:
            </label>
            <textarea
              rows={2}
              value={nightNotes}
              onChange={(e) => {
                setNightNotes(e.target.value);
                setIsSaved(false);
              }}
              placeholder="امروز چه چیزی تمرکزم را گرفت؟ فردا کدام پارت را اول وقت تمام می‌کنم؟"
              className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white"
            />
          </div>

          <div className="flex justify-end pt-1">
            <button
              type="submit"
              className={`px-5 py-2.5 rounded-2xl text-xs font-black flex items-center gap-2 transition cursor-pointer shadow-xs ${
                isSaved
                  ? 'bg-emerald-600 text-white'
                  : 'bg-teal-600 hover:bg-teal-700 text-white'
              }`}
            >
              {isSaved ? <Check className="w-4 h-4" /> : <Send className="w-4 h-4" />}
              <span>{isSaved ? 'گزارش پایان روز ثبت شد ✅' : 'ثبت و ذخیره گزارش پایان روز'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
