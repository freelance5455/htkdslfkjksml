import React from 'react';
import {
  ActiveTab,
  AppState,
  StudyPart,
  TajrobiSubject,
} from '../types';
import {
  ACTIVITY_META,
  PRIORITY_LABELS,
  TAJROBI_SUBJECTS_INFO,
  TAJROBI_SUBJECTS_LIST,
  calculateDaysUntilExam,
  calculateLevelInfo,
  calculateStreak,
  detectGradeFromText,
  formatMinutesToHoursAndMinutes,
  getTodayISO,
  getTodayJalali,
  getTodayPersianDayOfWeek,
  toPersianDigits,
} from '../utils/tajrobiData';
import {
  Play,
  CheckCircle2,
  Clock,
  Flame,
  Award,
  AlertTriangle,
  ArrowRight,
  TrendingUp,
  Brain,
  Zap,
  Calendar,
  Hourglass,
  Check,
  Scale,
  Target,
} from 'lucide-react';

interface DashboardViewProps {
  state: AppState;
  onNavigateTab: (tab: ActiveTab) => void;
  onStartStudyPart: (part: StudyPart) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  state,
  onNavigateTab,
  onStartStudyPart,
}) => {
  const todayDay = getTodayPersianDayOfWeek();
  const todayISO = getTodayISO();

  // Filter parts for today
  const matchingTodayParts = state.parts.filter((p) => !p.dayOfWeek || p.dayOfWeek === todayDay);
  const todayParts = matchingTodayParts.length > 0 ? matchingTodayParts : state.parts;
  const completedParts = todayParts.filter((p) => p.completed);
  const pendingParts = todayParts.filter((p) => !p.completed);

  // Today study logs
  const todayLogs = state.studyLogs.filter((l) => l.date === todayISO);
  const totalStudyMinutesToday = todayLogs.reduce((acc, l) => acc + l.durationMinutes, 0);
  const totalTestsToday = todayLogs.reduce((acc, l) => acc + l.totalTests, 0);
  const correctTestsToday = todayLogs.reduce((acc, l) => acc + l.correctTests, 0);
  const testAccuracyToday =
    totalTestsToday > 0 ? Math.round((correctTestsToday / totalTestsToday) * 100) : 0;

  // Wasted hours from 1.5h blocks
  const wastedBlocks = state.blocks.filter((b) => b.activityType === 'wasted');
  const wastedHours = wastedBlocks.length * 1.5;

  // Active compensations
  const activeCompensations = state.compensations.filter((c) => !c.resolved);

  // Streak & Level Info
  const streak = calculateStreak(state.studyLogs);
  const levelInfo = calculateLevelInfo(state.xp);

  // Exam Countdown
  const konkurExam = state.exams.find((e) => e.type === 'konkur') || state.exams[0];
  const daysToKonkur = konkurExam ? calculateDaysUntilExam(konkurExam.targetDate) : 200;

  return (
    <div className="space-y-6 animate-fade-slide">
      {/* Welcome & Motivational Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-linear-to-l from-teal-800 via-teal-700 to-emerald-800 text-white p-6 sm:p-8 shadow-lg">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="flex flex-wrap items-center gap-2 text-xs font-bold text-teal-200">
              <span className="px-3 py-1 rounded-full bg-teal-900/60 border border-teal-500/40">
                📅 {getTodayJalali()}
              </span>
              <span className="px-3 py-1 rounded-full bg-amber-500/30 text-amber-200 border border-amber-400/40 flex items-center gap-1">
                <Flame className="w-3.5 h-3.5 text-amber-400" />
                {toPersianDigits(streak)} روز پیوستگی مطالعه
              </span>
            </div>

            <h2 className="text-xl sm:text-2xl font-black tracking-tight leading-snug">
              سلام داوطلب پرتلاش تجربی! آماده‌ای امروز یک گام به رتبه برتر نزدیک‌تر بشی؟
            </h2>

            <p className="text-xs sm:text-sm text-teal-100 font-medium leading-relaxed">
              روزشمار کنکور: <strong className="text-amber-300 font-extrabold">{toPersianDigits(daysToKonkur)} روز</strong> تا سرنوشت‌سازترین آزمون. امروز با تمرکز روی زیست و شیمی رکورد بزن!
            </p>
          </div>

          {/* Quick Launch Study Button */}
          <div className="shrink-0 flex flex-col sm:flex-row gap-3">
            <button
              type="button"
              onClick={() => onNavigateTab('timer')}
              className="px-6 py-3.5 rounded-2xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-sm sm:text-base flex items-center justify-center gap-2 transition transform active:scale-95 shadow-md cursor-pointer"
            >
              <Play className="w-5 h-5 fill-slate-950" />
              <span>شروع مطالعه با تایمر معکوس</span>
            </button>
          </div>
        </div>
      </div>

      {/* Gamification Level & XP Progress Card */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-teal-50 dark:bg-teal-950/60 border border-teal-200 dark:border-teal-800 flex items-center justify-center text-teal-700 dark:text-teal-300 font-black text-lg">
              <Award className="w-6 h-6" />
            </div>
            <div>
              <div className="text-xs font-bold text-slate-500 dark:text-slate-400">
                سطح {toPersianDigits(levelInfo.level)}
              </div>
              <div className="text-base font-black text-slate-900 dark:text-white">
                {levelInfo.title}
              </div>
            </div>
          </div>

          <div className="text-xs font-extrabold text-teal-700 dark:text-teal-400 tabular-nums">
            {toPersianDigits(state.xp)} XP کسب‌شده · {toPersianDigits(levelInfo.nextLevelXp - state.xp)} امتیاز تا ارتقا به سطح بعد
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-slate-100 dark:bg-slate-800 h-3 rounded-full overflow-hidden">
          <div
            className="bg-linear-to-l from-teal-500 to-emerald-400 h-full rounded-full transition-all duration-700"
            style={{ width: `${levelInfo.progressPercent}%` }}
          />
        </div>
      </div>

      {/* 4 Top Primary Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Today's Parts */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs">
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 dark:text-slate-400">
            <span>پارت‌های امروز</span>
            <CheckCircle2 className="w-4 h-4 text-teal-600" />
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white tabular-nums mt-2">
            {toPersianDigits(completedParts.length)} <span className="text-sm font-bold text-slate-400">از {toPersianDigits(todayParts.length)}</span>
          </div>
          <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
            {todayParts.length > 0
              ? `${toPersianDigits(Math.round((completedParts.length / todayParts.length) * 100))}٪ تکمیل‌شده`
              : 'پارتی برای امروز ثبت نشده'}
          </div>
        </div>

        {/* Card 2: Today's Study Time */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs">
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 dark:text-slate-400">
            <span>زمان مطالعه امروز</span>
            <Clock className="w-4 h-4 text-teal-600" />
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white tabular-nums mt-2">
            {formatMinutesToHoursAndMinutes(totalStudyMinutesToday)}
          </div>
          <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
            هدف هفتگی: {toPersianDigits(Math.round(state.settings.weeklyStudyMinutesGoal / 60))} ساعت
          </div>
        </div>

        {/* Card 3: Today's Tests & Accuracy */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs">
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 dark:text-slate-400">
            <span>تست و دقت پاسخ</span>
            <TrendingUp className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white tabular-nums mt-2">
            {toPersianDigits(totalTestsToday)} <span className="text-sm font-bold text-emerald-600">({toPersianDigits(testAccuracyToday)}٪)</span>
          </div>
          <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 tabular-nums">
            هدف روزانه: {toPersianDigits(state.settings.dailyTestGoal)} تست
          </div>
        </div>

        {/* Card 4: Wasted Time & Compensations */}
        <div
          onClick={() => onNavigateTab(wastedHours > 0 ? 'blocks' : 'compensations')}
          className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs cursor-pointer hover:border-amber-400 transition"
        >
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 dark:text-slate-400">
            <span>تایم پرتی و جبرانی</span>
            <Hourglass className="w-4 h-4 text-rose-500" />
          </div>
          <div className="text-2xl font-black tabular-nums mt-2 flex items-baseline gap-2">
            <span className={wastedHours > 2 ? 'text-rose-600' : 'text-slate-900 dark:text-white'}>
              {toPersianDigits(wastedHours)}h پرتی
            </span>
          </div>
          <div className="text-[11px] text-amber-700 dark:text-amber-400 font-bold mt-1">
            ⚡ {toPersianDigits(activeCompensations.length)} پارت در ایستگاه جبرانی
          </div>
        </div>
      </div>

      {/* Main Two-Column Section: Today's Parts & Tajrobi Subject Status */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Column 1 & 2: Today's Study Parts */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-teal-600" />
              <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                پارت‌های برنامه‌ریزی‌شده امروز ({todayDay})
              </h3>
            </div>
            <button
              type="button"
              onClick={() => onNavigateTab('parts')}
              className="text-xs font-bold text-teal-600 hover:text-teal-700 flex items-center gap-1 cursor-pointer"
            >
              <span>مشاهده و ویرایش همه</span>
              <ArrowRight className="w-3.5 h-3.5 rotate-180" />
            </button>
          </div>

          {todayParts.length === 0 ? (
            <div className="text-center py-10 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-2xl p-6">
              <p className="text-sm font-bold text-slate-500">برای امروز پارتی اضافه نشده است.</p>
              <button
                type="button"
                onClick={() => onNavigateTab('parts')}
                className="mt-3 px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold transition cursor-pointer"
              >
                + اضافه کردن پارت درسی
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {todayParts.map((part) => {
                const info = TAJROBI_SUBJECTS_INFO[part.category];
                return (
                  <div
                    key={part.id}
                    className={`p-4 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                      part.completed
                        ? 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 opacity-80'
                        : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-teal-400'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <div className="space-y-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <span
                            className="px-2 py-0.5 rounded-md text-[11px] font-black"
                            style={{ backgroundColor: info.color + '22', color: info.color }}
                          >
                            {part.category}
                          </span>
                          <span className={`text-xs font-black ${part.completed ? 'line-through text-slate-400 dark:text-slate-500' : 'text-slate-900 dark:text-white'}`}>
                            {part.topic}
                          </span>
                          <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400">
                            ({part.bookSource})
                          </span>
                          {part.completed && (
                            <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300">
                              تکمیل‌شده
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-3 text-[11px] text-slate-500 dark:text-slate-400 tabular-nums">
                          <span>⏱ {toPersianDigits(part.estimatedMinutes)} دقیقه</span>
                          <span>·</span>
                          <span>🎯 {toPersianDigits(part.testCount)} تست</span>
                          {part.scheduledTime && (
                            <>
                              <span>·</span>
                              <span>ساعت {toPersianDigits(part.scheduledTime)}</span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Action button: Start in Timer */}
                    {!part.completed && (
                      <button
                        type="button"
                        onClick={() => onStartStudyPart(part)}
                        className="px-3.5 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold flex items-center justify-center gap-1.5 transition cursor-pointer shrink-0 shadow-xs"
                      >
                        <Play className="w-3.5 h-3.5 fill-white" />
                        <span>شروع در تایمر</span>
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Column 3: Tajrobi Subject Coefficients & Scientific Tips */}
        <div className="space-y-4">
          {/* Scientific Quick Flaw Warning */}
          <div
            onClick={() => onNavigateTab('diagnostics')}
            className="bg-teal-50/70 dark:bg-teal-950/40 rounded-3xl border border-teal-200 dark:border-teal-800 p-5 shadow-xs cursor-pointer hover:border-teal-400 transition space-y-2"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-black text-teal-800 dark:text-teal-300 flex items-center gap-1.5">
                <Brain className="w-4 h-4 text-teal-600" />
                آسیب‌شناسی علمی روزانه
              </span>
              <span className="text-[10px] font-bold bg-teal-600 text-white px-2 py-0.5 rounded-full">
                بررسی روش‌های جهانی
              </span>
            </div>
            <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed font-medium">
              برنامه امروز شما بر مبنای قوانین ابینگهاوس، بازیابی فعال دُنلوسکی و ریتم پومودورو رصد می‌شود. برای مشاهده ایرادات برنامه و گزارش شبانه کلیک کنید.
            </p>
          </div>

          {/* Quick Tajrobi Coefficients */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs space-y-3">
            <h4 className="text-xs font-black text-slate-900 dark:text-white flex items-center gap-1.5">
              <span>ضرایب سرنوشت‌ساز کنکور تجربی</span>
            </h4>
            <div className="space-y-2 text-xs">
              {TAJROBI_SUBJECTS_LIST.slice(0, 4).map((subj) => {
                const info = TAJROBI_SUBJECTS_INFO[subj];
                return (
                  <div
                    key={subj}
                    className="flex items-center justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-800/60"
                  >
                    <span className="font-extrabold text-slate-800 dark:text-slate-200">
                      {subj}
                    </span>
                    <span
                      className="font-bold text-[11px] px-2 py-0.5 rounded-md"
                      style={{ backgroundColor: info.color + '22', color: info.color }}
                    >
                      {info.coefficient}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Grade Balance Mini Card */}
          <div
            onClick={() => onNavigateTab('charts')}
            className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs cursor-pointer hover:border-purple-400 transition space-y-3"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-black text-slate-900 dark:text-white flex items-center gap-1.5">
                <Scale className="w-4 h-4 text-purple-600" />
                تعادل مطالعه پایه‌ها (دهم/یازدهم/دوازدهم)
              </span>
              <span className="text-[10px] text-teal-600 font-bold hover:underline">
                نمودار کامل ←
              </span>
            </div>

            <div className="space-y-2 text-xs font-bold">
              <div className="flex items-center justify-between text-slate-700 dark:text-slate-300">
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-teal-500" /> پایه دهم
                </span>
                <span className="tabular-nums font-black text-teal-700 dark:text-teal-400">
                  {toPersianDigits(
                    (
                      state.studyLogs
                        .filter((l) => (l.gradeLevel || detectGradeFromText(l.topic)) === 'دهم')
                        .reduce((a, b) => a + b.durationMinutes, 0) / 60
                    ).toFixed(1)
                  )}h
                </span>
              </div>

              <div className="flex items-center justify-between text-slate-700 dark:text-slate-300">
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-purple-500" /> پایه یازدهم
                </span>
                <span className="tabular-nums font-black text-purple-700 dark:text-purple-400">
                  {toPersianDigits(
                    (
                      state.studyLogs
                        .filter((l) => (l.gradeLevel || detectGradeFromText(l.topic)) === 'یازدهم')
                        .reduce((a, b) => a + b.durationMinutes, 0) / 60
                    ).toFixed(1)
                  )}h
                </span>
              </div>

              <div className="flex items-center justify-between text-slate-700 dark:text-slate-300">
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-blue-500" /> پایه دوازدهم
                </span>
                <span className="tabular-nums font-black text-blue-700 dark:text-blue-400">
                  {toPersianDigits(
                    (
                      state.studyLogs
                        .filter((l) => (l.gradeLevel || detectGradeFromText(l.topic)) === 'دوازدهم')
                        .reduce((a, b) => a + b.durationMinutes, 0) / 60
                    ).toFixed(1)
                  )}h
                </span>
              </div>
            </div>
          </div>

          {/* Annual Strategy Card Target Esfand */}
          <div
            onClick={() => onNavigateTab('annual')}
            className="bg-gradient-to-br from-amber-500/10 via-amber-500/5 to-slate-900/40 rounded-3xl border border-amber-500/30 p-5 shadow-xs cursor-pointer hover:border-amber-400 transition space-y-2.5"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-black text-amber-800 dark:text-amber-300 flex items-center gap-1.5">
                <Target className="w-4 h-4 text-amber-500" />
                استراتژی سالانه: اتمام تا ۲۹ اسفند
              </span>
              <span className="text-[10px] font-bold bg-amber-500 text-slate-950 px-2 py-0.5 rounded-full">
                نقشه راه ←
              </span>
            </div>
            <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed font-medium">
              برنامه بستن تمام دروس پایه دهم و یازدهم و کل دوازدهم تا پایان اسفند با تست استاندارد و مرورهای فاصله‌دار علمی ابینگهاوس.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
