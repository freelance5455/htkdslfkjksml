import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { downloadApkReadyZip, downloadApkStandaloneHtml } from '../utils/apkDownloader';
import {
  Download,
  Smartphone,
  CheckCircle,
  Sparkles,
  X,
  Share2,
  PlusSquare,
  FileArchive,
  FileCode,
  ShieldCheck,
  Cpu,
  Layers,
  HelpCircle,
  ExternalLink,
} from 'lucide-react';

interface PWAInstallGuideProps {
  isOpen: boolean;
  onClose: () => void;
  defaultTab?: 'apk' | 'pwa' | 'ios' | 'pc';
}

export const PWAInstallGuideModal: React.FC<PWAInstallGuideProps> = ({
  isOpen,
  onClose,
  defaultTab = 'apk',
}) => {
  const { isInstallable, install } = usePWAInstall();
  const [activeTab, setActiveTab] = useState<'apk' | 'pwa' | 'ios' | 'pc'>(defaultTab);
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  if (!isOpen) return null;

  const handleDownloadZip = async () => {
    setIsDownloading(true);
    try {
      await downloadApkReadyZip();
      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 4000);
    } catch (e) {
      console.error(e);
    } finally {
      setIsDownloading(false);
    }
  };

  const handleDownloadHtml = async () => {
    setIsDownloading(true);
    try {
      await downloadApkStandaloneHtml();
      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 4000);
    } catch (e) {
      console.error(e);
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in"
      dir="rtl"
    >
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-xl w-full p-6 shadow-2xl space-y-5 max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-teal-50 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400 flex items-center justify-center">
              <FileArchive className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-1.5">
                <span>دانلود و ساخت اپلیکیشن (APK & PWA)</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-extrabold">
                  نسخه اصلاح‌شده
                </span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                پکیج تست‌شده و سازگار با تمام مبدل‌های اندروید و وب‌ویو (بدون صفحه سفید)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1.5 rounded-xl cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-slate-100 dark:bg-slate-800 text-xs font-bold">
          <button
            onClick={() => setActiveTab('apk')}
            className={`flex-1 py-2 rounded-xl transition cursor-pointer text-center flex items-center justify-center gap-1.5 ${
              activeTab === 'apk'
                ? 'bg-white dark:bg-slate-700 text-teal-700 dark:text-teal-300 shadow-xs font-black'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <FileArchive className="w-3.5 h-3.5" />
            <span>📦 دانلود ZIP مخصوص APK</span>
          </button>
          <button
            onClick={() => setActiveTab('pwa')}
            className={`flex-1 py-2 rounded-xl transition cursor-pointer text-center flex items-center justify-center gap-1.5 ${
              activeTab === 'pwa'
                ? 'bg-white dark:bg-slate-700 text-teal-700 dark:text-teal-300 shadow-xs font-black'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>📱 نصب در گوشی (PWA)</span>
          </button>
          <button
            onClick={() => setActiveTab('ios')}
            className={`flex-1 py-2 rounded-xl transition cursor-pointer text-center ${
              activeTab === 'ios'
                ? 'bg-white dark:bg-slate-700 text-teal-700 dark:text-teal-300 shadow-xs font-black'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            🍏 آیفون (iOS)
          </button>
          <button
            onClick={() => setActiveTab('pc')}
            className={`flex-1 py-2 rounded-xl transition cursor-pointer text-center ${
              activeTab === 'pc'
                ? 'bg-white dark:bg-slate-700 text-teal-700 dark:text-teal-300 shadow-xs font-black'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            💻 ویندوز / مک
          </button>
        </div>

        {/* Tab 1: APK Download & Guide */}
        {activeTab === 'apk' && (
          <div className="space-y-4">
            {/* Primary Download Card */}
            <div className="p-4 rounded-3xl bg-linear-to-br from-teal-600 via-teal-700 to-emerald-800 text-white shadow-lg space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-2xl bg-white/15 backdrop-blur-xs">
                    <FileArchive className="w-5 h-5 text-amber-300" />
                  </div>
                  <div>
                    <h4 className="text-sm font-black">پکیج زیپ اختصاصی برای ساخت APK</h4>
                    <p className="text-[11px] text-teal-100">
                      شامل فایل کامپایل‌شده، بدون اسکریپت ماژولار و با مسیرهای کاملاً نسبی
                    </p>
                  </div>
                </div>
                <span className="text-[10px] font-extrabold px-2.5 py-1 rounded-full bg-emerald-400 text-emerald-950">
                  آماده اجرا
                </span>
              </div>

              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={handleDownloadZip}
                  disabled={isDownloading}
                  className="flex-1 py-3 px-4 rounded-2xl bg-white hover:bg-teal-50 text-teal-900 font-black text-xs flex items-center justify-center gap-2 shadow-md cursor-pointer transition active:scale-98 disabled:opacity-50"
                >
                  <Download className="w-4 h-4 text-teal-700" />
                  <span>
                    {isDownloading
                      ? 'در حال آماده‌سازی و دانلود...'
                      : 'دانلود مستقیم فایل ZIP آماده برای APK'}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={handleDownloadHtml}
                  disabled={isDownloading}
                  className="py-3 px-3 rounded-2xl bg-teal-800/80 hover:bg-teal-800 text-teal-100 font-bold text-xs flex items-center justify-center gap-1.5 border border-white/20 cursor-pointer transition"
                  title="دانلود فایل تک‌فایلی index.html"
                >
                  <FileCode className="w-4 h-4" />
                  <span>دانلود index.html تک‌فایلی</span>
                </button>
              </div>

              {downloadSuccess && (
                <div className="p-2.5 rounded-xl bg-emerald-400/25 border border-emerald-400/40 text-center text-xs font-bold text-white flex items-center justify-center gap-1.5 animate-fade-in">
                  <CheckCircle className="w-4 h-4 text-emerald-300" />
                  <span>فایل زیپ با موفقیت در پوشه Downloads دانلود شد! 🎉</span>
                </div>
              )}
            </div>

            {/* Why the white screen happened and how it is fixed */}
            <div className="p-3.5 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 text-xs text-amber-900 dark:text-amber-200 space-y-1.5">
              <div className="font-black flex items-center gap-1.5 text-amber-800 dark:text-amber-300">
                <ShieldCheck className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                <span>علت بروز صفحه سفید قبلی و اصلاحات اعمال‌شده:</span>
              </div>
              <ul className="list-disc list-inside space-y-1 text-slate-700 dark:text-slate-300 text-[11px] leading-relaxed pr-1">
                <li>
                  <strong>حذف ریدایرکت اشتباه:</strong> اسکریپت ارجاع به <code className="text-amber-600 dark:text-amber-400">./dist/index.html</code> که در وب‌ویو باعث خطای ۴۰۴ می‌شد، کاملاً حذف شد.
                </li>
                <li>
                  <strong>حذف خطای CORS در پروتکل file://:</strong> تمامی اسکریپت‌ها از حالت ماژولار (<code className="text-amber-600 dark:text-amber-400">type=&quot;module&quot;</code>) به اسکریپت استاندارد کلاسیک تبدیل شدند تا اندروید آن‌ها را مسدود نکند.
                </li>
                <li>
                  <strong>سازگاری با وب‌ویو قدیمی:</strong> لایه محافظ برای حافظه محلی (<code className="text-amber-600 dark:text-amber-400">localStorage</code>) تعبیه شد تا در صورت محدودیت حافظه، برنامه دچار کرش یا صفحه سفید نشود.
                </li>
                <li>
                  <strong>تجمیع ۱۰۰٪ کدها:</strong> کلیه کدهای React، استایل‌های Tailwind و فونت‌های پیش‌فرض در خود فایل تعبیه شده‌اند و آفلاین اجرا می‌شوند.
                </li>
              </ul>
            </div>

            {/* Step-by-Step APK Guide */}
            <div className="space-y-3 text-xs">
              <h4 className="font-black text-slate-900 dark:text-white flex items-center gap-1.5">
                <Cpu className="w-4 h-4 text-teal-600" />
                <span>روش تبدیل فایل دانلود شده به APK در نرم‌افزار Website 2 APK Builder:</span>
              </h4>

              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2">
                <ol className="list-decimal list-inside space-y-2 text-slate-700 dark:text-slate-300 leading-relaxed text-[11px]">
                  <li>
                    فایل زیپ <strong>tajrobi-planner-apk-ready.zip</strong> را از دکمه بالا دانلود و آن را از حالت فشرده (Extract) خارج کنید.
                  </li>
                  <li>
                    نرم‌افزار <strong>Website 2 APK Builder</strong> را باز کرده و در بخش Web Type گزینه <strong>Local Website Folder</strong> را انتخاب کنید.
                  </li>
                  <li>
                    دکمه <strong>Directory</strong> را زده و پوشه استخراج‌شده (که فایل <code>index.html</code> درون آن است) را انتخاب کنید.
                  </li>
                  <li>
                    در تب <strong>Advance Setting</strong>، حتماً تیک گزینه <strong>Enable DOM Storage</strong> و <strong>Enable JavaScript</strong> را فعال نگه دارید.
                  </li>
                  <li>
                    دکمه <strong>Generate APK</strong> را بزنید؛ فایل APK بدون هیچ صفحه سفیدی تولید شده و روی گوشی اجرا می‌شود.
                  </li>
                </ol>
              </div>

              {/* Online APK Builders */}
              <div className="p-3 rounded-2xl bg-slate-100 dark:bg-slate-800 text-[11px] text-slate-600 dark:text-slate-400 flex items-center justify-between">
                <span>همچنین می‌توانید همین فایل ZIP را در سایت‌های آنلاین مثل <strong>Web2Apk</strong> یا <strong>AppsGeyser</strong> مستقیماً آپلود کنید.</span>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: PWA Install */}
        {activeTab === 'pwa' && (
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-teal-50/70 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800 text-xs text-teal-900 dark:text-teal-200 space-y-2">
              <p className="font-extrabold flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-teal-600" />
                ساده‌ترین روش: نصب استاندارد به عنوان اپلیکیشن (PWA)
              </p>
              <p className="leading-relaxed text-slate-700 dark:text-slate-300">
                این برنامه به صورت استاندارد PWA (Progressive Web App) طراحی شده است. یعنی به محض نصب، نوار مرورگر حذف شده، آیکون اختصاصی روی صفحه گوشی شما قرار می‌گیرد و به صورت آفلاین مانند یک برنامه بومی کار می‌کند.
              </p>
            </div>

            {isInstallable && (
              <button
                type="button"
                onClick={async () => {
                  const res = await install();
                  if (res) onClose();
                }}
                className="w-full py-3.5 rounded-2xl bg-teal-600 hover:bg-teal-700 text-white font-black text-sm flex items-center justify-center gap-2 shadow-md cursor-pointer transition active:scale-98"
              >
                <Download className="w-5 h-5" />
                <span>نصب فوری اپلیکیشن روی این دستگاه</span>
              </button>
            )}

            <div className="space-y-2 text-xs">
              <h4 className="font-black text-slate-900 dark:text-white">مراحل نصب در مرورگر Chrome / Samsung Internet:</h4>
              <ol className="list-decimal list-inside space-y-1.5 text-slate-600 dark:text-slate-300 pr-1 leading-relaxed">
                <li>منوی سه نقطه (⋮) بالای مرورگر را باز کنید.</li>
                <li>گزینه <strong>«نصب برنامه» (Install App)</strong> یا <strong>«افزودن به صفحه اصلی» (Add to Home Screen)</strong> را بزنید.</li>
                <li>تأیید را بزنید؛ آیکون برنامه در منوی برنامه‌های گوشی قرار خواهد گرفت.</li>
              </ol>
            </div>
          </div>
        )}

        {/* Tab 3: iOS */}
        {activeTab === 'ios' && (
          <div className="space-y-3.5 text-xs text-slate-700 dark:text-slate-300">
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2">
              <h4 className="font-black text-slate-900 dark:text-white text-sm">
                نصب روی آیفون و آیپد (iOS):
              </h4>
              <p className="leading-relaxed">
                در سیستم‌عامل iOS شرکت اپل، برنامه‌های وب از طریق مرورگر Safari مستقیماً به اپلیکیشن هوم‌اسکرین تبدیل می‌شوند:
              </p>
            </div>

            <div className="space-y-2.5">
              <div className="flex items-start gap-2.5 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                <div className="w-7 h-7 rounded-xl bg-blue-100 dark:bg-blue-900/60 text-blue-600 dark:text-blue-300 flex items-center justify-center shrink-0">
                  <Share2 className="w-4 h-4" />
                </div>
                <div>
                  <strong className="text-slate-900 dark:text-white block">مرحله ۱:</strong>
                  لینک برنامه را در Safari باز کرده و دکمه <strong>Share (اشتراک‌گذاری)</strong> در نوار پایین را لمس کنید.
                </div>
              </div>

              <div className="flex items-start gap-2.5 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                <div className="w-7 h-7 rounded-xl bg-teal-100 dark:bg-teal-900/60 text-teal-600 dark:text-teal-300 flex items-center justify-center shrink-0">
                  <PlusSquare className="w-4 h-4" />
                </div>
                <div>
                  <strong className="text-slate-900 dark:text-white block">مرحله ۲:</strong>
                  به پایین اسکرول کرده و گزینه <strong>Add to Home Screen (افزودن به صفحه اصلی)</strong> را انتخاب کنید.
                </div>
              </div>

              <div className="flex items-start gap-2.5 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                <div className="w-7 h-7 rounded-xl bg-emerald-100 dark:bg-emerald-900/60 text-emerald-600 dark:text-emerald-300 flex items-center justify-center shrink-0">
                  <CheckCircle className="w-4 h-4" />
                </div>
                <div>
                  <strong className="text-slate-900 dark:text-white block">مرحله ۳:</strong>
                  دکمه <strong>Add</strong> در گوشه بالا را بزنید. آیکون برنامه در هوم‌اسکرین آیفون ظاهر خواهد شد.
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 4: PC */}
        {activeTab === 'pc' && (
          <div className="space-y-3.5 text-xs text-slate-700 dark:text-slate-300">
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2">
              <h4 className="font-black text-slate-900 dark:text-white text-sm">
                نصب در ویندوز، لینوکس و مک:
              </h4>
              <p className="leading-relaxed">
                در مرورگر Chrome یا Edge روی کامپیوتر، در نوار آدرس یک آیکون مانیتور یا نصب (Install) وجود دارد. با کلیک روی آن، این برنامه به صورت یک نرم‌افزار دسکتاپ مستقل با پنجره جداگانه روی دسکتاپ و استارت‌منو نصب می‌شود.
              </p>
            </div>
          </div>
        )}

        {/* Footer Actions */}
        <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <button
            type="button"
            onClick={handleDownloadZip}
            className="text-xs font-bold text-teal-600 dark:text-teal-400 hover:underline flex items-center gap-1 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>دانلود tajrobi-planner-apk-ready.zip</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 font-bold text-xs cursor-pointer"
          >
            بستن
          </button>
        </div>
      </div>
    </div>
  );
};

export const PWAInstallHeaderButton: React.FC<{ onOpenGuide: () => void }> = ({ onOpenGuide }) => {
  return (
    <div className="flex items-center gap-1.5">
      <button
        type="button"
        onClick={onOpenGuide}
        className="px-3 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-extrabold text-xs flex items-center gap-1.5 transition cursor-pointer shadow-xs active:scale-98"
        title="دانلود فایل ZIP آماده برای APK و راهنمای نصب"
      >
        <FileArchive className="w-3.5 h-3.5" />
        <span>دانلود ZIP مخصوص APK</span>
      </button>
    </div>
  );
};
