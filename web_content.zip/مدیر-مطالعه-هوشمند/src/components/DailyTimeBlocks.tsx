import React from 'react';
import { ActivityType, TajrobiSubject, TimeBlock } from '../types';
import {
  ACTIVITY_META,
  TAJROBI_SUBJECTS_INFO,
  toFaDigits,
} from '../utils/tajrobiData';
import {
  Clock,
  Play,
  CheckCircle,
  HelpCircle,
} from 'lucide-react';

interface DailyTimeBlocksProps {
  blocks: TimeBlock[];
  onUpdateBlock: (updated: TimeBlock) => void;
  onSendToTimer: (subject: TajrobiSubject, topic: string) => void;
}

export const DailyTimeBlocks: React.FC<DailyTimeBlocksProps> = ({
  blocks,
  onUpdateBlock,
  onSendToTimer,
}) => {
  // Summary counts for quick stats at the top of the planner
  const studyBlocksCount = blocks.filter((b) => b.activityType === 'study' || b.activityType === 'compensation').length;
  const wastedBlocksCount = blocks.filter((b) => b.activityType === 'wasted').length;
  const sleepBlocksCount = blocks.filter((b) => b.activityType === 'sleep').length;

  const totalStudyHours = studyBlocksCount * 1.5;
  const totalWastedHours = wastedBlocksCount * 1.5;
  const totalSleepHours = sleepBlocksCount * 1.5;

  return (
    <div className="space-y-6">
      {/* Top Planner Overview Bar */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              <Clock className="w-5 h-5 text-teal-600" />
              <span>تقسیم‌بندی ۲۴ ساعته روز به بلوک‌های ۱.۵ ساعته (۱۶ بلوک)</span>
            </h2>
            <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
              کل شبانه‌روز شما به ۱۶ تایم ۹۰ دقیقه‌ای استاندارد کنکور تقسیم شده است. نوع فعالیت هر پارت را مشخص کنید:
            </p>
          </div>

          {/* Quick Summary Pill Badges */}
          <div className="flex flex-wrap items-center gap-2 text-xs tabular-nums">
            <span className="px-3 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 font-bold">
              مطالعه تجربی: {toFaDigits(totalStudyHours)} ساعت ({toFaDigits(studyBlocksCount)} بلوک)
            </span>
            <span className="px-3 py-1.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-300 font-bold">
              تایم پرتی: {toFaDigits(totalWastedHours)} ساعت ({toFaDigits(wastedBlocksCount)} بلوک)
            </span>
            <span className="px-3 py-1.5 rounded-xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800 text-indigo-800 dark:text-indigo-300 font-bold">
              خواب: {toFaDigits(totalSleepHours)} ساعت
            </span>
          </div>
        </div>
      </div>

      {/* 16 Blocks List */}
      <div className="space-y-3">
        {blocks.map((block) => {
          const meta = ACTIVITY_META[block.activityType];
          const isStudy = block.activityType === 'study' || block.activityType === 'compensation';
          const isWasted = block.activityType === 'wasted';

          return (
            <div
              key={block.id}
              className={`rounded-2xl border p-4 sm:p-5 transition bg-white dark:bg-slate-900 ${
                isWasted
                  ? 'border-rose-300 dark:border-rose-800 bg-rose-50/20 dark:bg-rose-950/20'
                  : isStudy
                  ? 'border-emerald-200 dark:border-emerald-800/80 shadow-xs'
                  : 'border-slate-200 dark:border-slate-800'
              }`}
            >
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                {/* Time range + Block Number Badge */}
                <div className="flex items-center gap-3 shrink-0">
                  <div className="w-8 h-8 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center font-bold text-xs text-slate-700 dark:text-slate-300 tabular-nums">
                    {toFaDigits(block.blockNumber ?? block.id)}
                  </div>
                  <div className="tabular-nums font-bold text-sm sm:text-base text-slate-800 dark:text-slate-200 whitespace-nowrap">
                    {block.startTime && block.endTime
                      ? `${toFaDigits(block.startTime)} تا ${toFaDigits(block.endTime)}`
                      : toFaDigits(block.timeRange)}
                  </div>
                  <span className="text-[11px] text-slate-500 dark:text-slate-400">
                    (۱.۵ ساعت)
                  </span>
                </div>

                {/* Activity Type Selector */}
                <div className="flex flex-wrap items-center gap-1.5 shrink-0">
                  {(Object.keys(ACTIVITY_META) as ActivityType[]).map((actKey) => {
                    const act = ACTIVITY_META[actKey];
                    const isSelected = block.activityType === actKey;
                    return (
                      <button
                        key={actKey}
                        type="button"
                        onClick={() =>
                          onUpdateBlock({
                            ...block,
                            activityType: actKey,
                            subject: actKey === 'study' && !block.subject ? 'زیست‌شناسی' : block.subject,
                          })
                        }
                        className={`px-2.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1 transition cursor-pointer ${
                          isSelected
                            ? act.badge + ' ring-1 ring-black/10 dark:ring-white/20 font-bold shadow-xs'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
                        }`}
                      >
                        <span>{act.icon}</span>
                        <span>{act.label}</span>
                      </button>
                    );
                  })}
                </div>

                {/* Topic / Note & Subject Selector */}
                <div className="flex-1 flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                  {isStudy ? (
                    <>
                      <select
                        value={block.subject || 'زیست‌شناسی'}
                        onChange={(e) =>
                          onUpdateBlock({
                            ...block,
                            subject: e.target.value as TajrobiSubject,
                          })
                        }
                        className="px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-bold text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-teal-500"
                      >
                        {(Object.keys(TAJROBI_SUBJECTS_INFO) as TajrobiSubject[]).map((s) => (
                          <option key={s} value={s}>
                            {s}
                          </option>
                        ))}
                      </select>

                      <input
                        type="text"
                        placeholder="مبحث و فصل مطالعه (مثلاً: تست گوارش)"
                        value={block.topic || ''}
                        onChange={(e) => onUpdateBlock({ ...block, topic: e.target.value })}
                        className="flex-1 px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-teal-500"
                      />

                      <div className="flex items-center gap-1 shrink-0">
                        <span className="text-[11px] text-slate-500">تست:</span>
                        <input
                          type="number"
                          placeholder="۰"
                          value={block.testCount ?? ''}
                          onChange={(e) => onUpdateBlock({ ...block, testCount: Number(e.target.value) || 0 })}
                          className="w-14 px-2 py-1 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-center font-bold tabular-nums"
                        />
                      </div>
                    </>
                  ) : isWasted ? (
                    <div className="flex-1 flex items-center gap-2">
                      <span className="text-xs text-rose-700 dark:text-rose-400 font-bold shrink-0">
                        دلیل هدررفت:
                      </span>
                      <input
                        type="text"
                        placeholder="مثلاً: اینستاگرام، تعلل، تماس تلفنی طولانی..."
                        value={block.topic || ''}
                        onChange={(e) => onUpdateBlock({ ...block, topic: e.target.value })}
                        className="flex-1 px-3 py-1.5 rounded-xl border border-rose-300 dark:border-rose-700 bg-rose-50/50 dark:bg-rose-950/40 text-xs text-rose-900 dark:text-rose-100"
                      />
                    </div>
                  ) : (
                    <input
                      type="text"
                      placeholder="توضیحات اختیاری (مثلاً: خواب بعدازظهر یا کلاس شیمی)"
                      value={block.topic || ''}
                      onChange={(e) => onUpdateBlock({ ...block, topic: e.target.value })}
                      className="flex-1 px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-700 dark:text-slate-300"
                    />
                  )}
                </div>

                {/* Quick Start Timer Button for study blocks */}
                {isStudy && (
                  <button
                    type="button"
                    onClick={() => onSendToTimer(block.subject || 'زیست‌شناسی', block.topic || '')}
                    className="shrink-0 px-3 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
                    title="انتقال این پارت ۱.۵ ساعته به تایمر معکوس برای مطالعه"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>شروع تایمر این بلوک</span>
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
