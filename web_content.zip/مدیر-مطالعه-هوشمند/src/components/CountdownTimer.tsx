import React, { useEffect, useState } from 'react';
import { CompensationTask, GradeLevel, StudyLog, TajrobiSubject } from '../types';
import {
  TAJROBI_SUBJECTS_INFO,
  detectGradeFromText,
  getCurrentJalaliMonth,
  getTodayJalali,
  playChimeSound,
  toFaDigits,
} from '../utils/tajrobiData';
import {
  Play,
  Pause,
  RotateCcw,
  CheckCircle2,
  AlertCircle,
  Clock,
  Sparkles,
  BookOpen,
} from 'lucide-react';

interface CountdownTimerProps {
  onSessionComplete: (log: StudyLog) => void;
  onSendToCompensation: (task: Omit<CompensationTask, 'id' | 'resolved' | 'date'>) => void;
  initialSubject?: TajrobiSubject;
  initialMinutes?: number;
  initialTopic?: string;
  initialBook?: string;
  initialTargetTests?: number;
}

export const CountdownTimer: React.FC<CountdownTimerProps> = ({
  onSessionComplete,
  onSendToCompensation,
  initialSubject = 'زیست‌شناسی',
  initialMinutes = 90,
  initialTopic = '',
  initialBook = '',
  initialTargetTests = 30,
}) => {
  const [subject, setSubject] = useState<TajrobiSubject>(initialSubject);
  const [topic, setTopic] = useState<string>(initialTopic);
  const [bookSource, setBookSource] = useState<string>(
    initialBook || TAJROBI_SUBJECTS_INFO['زیست‌شناسی'].popularBooks[0] || 'کتاب درسی'
  );
  const [plannedMinutes, setPlannedMinutes] = useState<number>(initialMinutes);
  const [secondsLeft, setSecondsLeft] = useState<number>(initialMinutes * 60);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [isPaused, setIsPaused] = useState<boolean>(false);

  // Test accuracy logging - uses exact target test count of the part
  const [totalTests, setTotalTests] = useState<number>(initialTargetTests || 30);
  const [correctTests, setCorrectTests] = useState<number>(0);
  const [wrongTests, setWrongTests] = useState<number>(0);
  const [hasManuallyEnteredTests, setHasManuallyEnteredTests] = useState<boolean>(false);
  const [testValidationError, setTestValidationError] = useState<string | null>(null);
  const [showFinishedAlert, setShowFinishedAlert] = useState<boolean>(false);

  // Reset test numbers to clean zero
  const handleResetTestNumbers = () => {
    setCorrectTests(0);
    setWrongTests(0);
    setHasManuallyEnteredTests(false);
    setTestValidationError(null);
  };

  // Sync if parent updates initial props (e.g. from clicking "شروع پارت در تایمر")
  useEffect(() => {
    if (initialSubject) {
      setSubject(initialSubject);
      if (!initialBook) {
        setBookSource(TAJROBI_SUBJECTS_INFO[initialSubject].popularBooks[0] || 'کتاب درسی');
      }
    }
    if (initialMinutes) {
      setPlannedMinutes(initialMinutes);
      if (!isRunning) {
        setSecondsLeft(initialMinutes * 60);
      }
    }
    if (initialTopic) setTopic(initialTopic);
    if (initialBook) setBookSource(initialBook);
    if (initialTargetTests && initialTargetTests > 0) {
      setTotalTests(initialTargetTests);
      setCorrectTests(0);
      setWrongTests(0);
      setHasManuallyEnteredTests(false);
    }
  }, [initialSubject, initialMinutes, initialTopic, initialBook, initialTargetTests, isRunning]);

  // Countdown timer tick
  useEffect(() => {
    if (!isRunning || isPaused) return;

    const timer = setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setIsRunning(false);
          setIsPaused(false);
          playChimeSound();
          setShowFinishedAlert(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isRunning, isPaused]);

  const handlePresetSelect = (mins: number) => {
    if (isRunning) return;
    setPlannedMinutes(mins);
    setSecondsLeft(mins * 60);
  };

  const handleStart = () => {
    if (secondsLeft === 0) {
      setSecondsLeft(plannedMinutes * 60);
    }
    setIsRunning(true);
    setIsPaused(false);
    setShowFinishedAlert(false);
    setTestValidationError(null);
  };

  const handlePause = () => {
    setIsPaused((prev) => !prev);
  };

  const handleReset = () => {
    setIsRunning(false);
    setIsPaused(false);
    setSecondsLeft(plannedMinutes * 60);
    setShowFinishedAlert(false);
    setTestValidationError(null);
  };

  // Submit session with mandatory manual test verification
  const handleSaveAndCompleteSession = (isTimerFullComplete: boolean = true) => {
    if (!hasManuallyEnteredTests) {
      setTestValidationError('⚠️ خطا: لطفاً تعداد تست‌های درست و غلط را به‌صورت دستی وارد کنید!');
      return;
    }

    if (correctTests + wrongTests > totalTests) {
      setTestValidationError('⚠️ خطا: مجموع تست‌های درست و غلط نمی‌تواند بیشتر از کل تست‌ها باشد.');
      return;
    }

    setTestValidationError(null);
    const elapsedMinutes = isTimerFullComplete
      ? plannedMinutes
      : Math.max(1, Math.round((plannedMinutes * 60 - secondsLeft) / 60));

    const blank = Math.max(0, totalTests - correctTests - wrongTests);
    const accuracy = totalTests > 0 ? Math.round((correctTests / totalTests) * 100) : 0;
    const detectedGrade = detectGradeFromText(topic + ' ' + bookSource);

    onSessionComplete({
      id: 'log-' + Date.now(),
      subject,
      gradeLevel: detectedGrade,
      topic: topic || 'مطالعه ثبت‌شده',
      bookSource: bookSource || 'کتاب درسی',
      durationMinutes: elapsedMinutes,
      totalTests: Number(totalTests) || 0,
      correctTests: Number(correctTests) || 0,
      wrongTests: Number(wrongTests) || 0,
      blankTests: blank,
      accuracyPercentage: accuracy,
      completedFully: isTimerFullComplete,
      date: new Date().toISOString().slice(0, 10),
      jalaliDate: getTodayJalali(),
      monthLabel: getCurrentJalaliMonth(),
      timestamp: new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }),
    });

    handleReset();
  };

  // User finished early but considers it complete
  const handleFinishEarlyComplete = () => {
    handleSaveAndCompleteSession(false);
  };

  // Critical User Requirement: "تایم مطالعه ام نصفه موند تو انو تو یه بخش جبرانی ها بگه"
  const handleIncompleteStudySendToCompensation = () => {
    const elapsedSecs = plannedMinutes * 60 - secondsLeft;
    const elapsedMins = Math.floor(elapsedSecs / 60);
    const deficitMins = Math.max(5, plannedMinutes - elapsedMins);
    const detectedGrade = detectGradeFromText(topic + ' ' + bookSource);

    onSendToCompensation({
      subject,
      gradeLevel: detectedGrade,
      topic: topic || 'پارت مطالعه بدون عنوان',
      bookSource: bookSource || 'کتاب درسی',
      plannedMinutes,
      completedMinutes: elapsedMins,
      remainingMinutes: deficitMins,
      notes: `از ${toFaDigits(plannedMinutes)} دقیقه برنامه‌ریزی کتاب «${bookSource}»، ${toFaDigits(
        elapsedMins
      )} دقیقه خوانده شد و ${toFaDigits(deficitMins)} دقیقه کسری باقی ماند.`,
    });

    // Also record the elapsed portion in logs
    if (elapsedMins > 0) {
      const blank = Math.max(0, totalTests - correctTests - wrongTests);
      const accuracy = totalTests > 0 ? Math.round((correctTests / totalTests) * 100) : 0;

      onSessionComplete({
        id: 'log-' + Date.now(),
        subject,
        gradeLevel: detectedGrade,
        topic: topic ? topic + ' (نصفه‌کاره)' : 'مطالعه نصفه‌کاره',
        bookSource: bookSource || 'کتاب درسی',
        durationMinutes: elapsedMins,
        totalTests: Number(totalTests) || 0,
        correctTests: Number(correctTests) || 0,
        wrongTests: Number(wrongTests) || 0,
        blankTests: blank,
        accuracyPercentage: accuracy,
        completedFully: false,
        date: new Date().toISOString().slice(0, 10),
        jalaliDate: getTodayJalali(),
        monthLabel: getCurrentJalaliMonth(),
        timestamp: new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }),
      });
    }

    handleReset();
  };

  const mins = Math.floor(secondsLeft / 60);
  const secs = secondsLeft % 60;
  const progressPercent = Math.min(
    100,
    Math.max(0, ((plannedMinutes * 60 - secondsLeft) / (plannedMinutes * 60)) * 100)
  );

  const currentSubjectInfo = TAJROBI_SUBJECTS_INFO[subject];

  return (
    <div className="space-y-6">
      {/* Finished Celebration Banner */}
      {showFinishedAlert && (
        <div className="p-5 rounded-2xl bg-gradient-to-r from-teal-600 to-emerald-600 text-white shadow-lg space-y-3 animate-fade-in border-2 border-emerald-300">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <Sparkles className="w-6 h-6 shrink-0 text-amber-300 animate-spin" style={{ animationDuration: '4s' }} />
              <div>
                <div className="font-extrabold text-base">خسته نباشی قهرمان! تایم مطالعه معکوس کامل شد 🎉</div>
                <div className="text-xs text-teal-100 mt-0.5">
                  {toFaDigits(plannedMinutes)} دقیقه مطالعه «{subject}» به پایان رسید. لطفاً تعداد تست‌های درست و غلط را به‌صورت دستی وارد کرده و دکمه زیر را برای ثبت در کارنامه بزنید:
                </div>
              </div>
            </div>
            <button
              onClick={() => setShowFinishedAlert(false)}
              className="px-2.5 py-1 bg-white/20 hover:bg-white/30 rounded-lg text-xs font-bold transition cursor-pointer"
            >
              ✕
            </button>
          </div>

          <div className="flex justify-end pt-1">
            <button
              type="button"
              onClick={() => handleSaveAndCompleteSession(true)}
              className="px-6 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-900 font-extrabold text-xs rounded-xl shadow-md transition cursor-pointer flex items-center gap-2"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>تأیید و ثبت در کارنامه ماهانه</span>
            </button>
          </div>
        </div>
      )}

      {/* Main Countdown Timer Card */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-xs">
        {/* Subject Selection Pills */}
        <div className="mb-6">
          <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-2">
            انتخاب درس رشته تجربی:
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
            {(Object.keys(TAJROBI_SUBJECTS_INFO) as TajrobiSubject[]).map((subj) => {
              const isSelected = subject === subj;
              const info = TAJROBI_SUBJECTS_INFO[subj];
              return (
                <button
                  key={subj}
                  type="button"
                  disabled={isRunning}
                  onClick={() => {
                    setSubject(subj);
                    setBookSource(info.popularBooks[0] || 'کتاب درسی');
                  }}
                  className={`p-3 rounded-2xl border text-center transition cursor-pointer ${
                    isSelected
                      ? 'border-teal-600 bg-teal-50/80 dark:bg-teal-950/60 dark:border-teal-500 font-extrabold shadow-xs'
                      : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-slate-50/50 dark:bg-slate-800/40 text-slate-700 dark:text-slate-300'
                  } ${isRunning ? 'opacity-60 cursor-not-allowed' : ''}`}
                >
                  <div className="text-sm font-bold">{subj}</div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                    {info.coefficient}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Book Source & Topic Selection */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
          <div>
            <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1 flex items-center gap-1.5">
              <BookOpen className="w-3.5 h-3.5 text-teal-600" />
              <span>کدام کتاب منبع مطالعه / تست است؟</span>
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={bookSource}
                onChange={(e) => setBookSource(e.target.value)}
                disabled={isRunning}
                placeholder="مثلاً خیلی سبز جامع یا مبتکران"
                className="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm focus:ring-2 focus:ring-teal-500 focus:outline-none"
              />
              <select
                disabled={isRunning}
                onChange={(e) => e.target.value && setBookSource(e.target.value)}
                className="px-2 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 text-xs font-bold text-slate-700 dark:text-slate-200 shrink-0"
              >
                <option value="">کتاب‌های معروف</option>
                {currentSubjectInfo.popularBooks.map((b) => (
                  <option key={b} value={b}>
                    {b}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">
              مبحث یا فصل در حال مطالعه:
            </label>
            <input
              type="text"
              placeholder="مثلاً: گوارش و جذب مواد (دهم) یا حرکت‌شناسی"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              disabled={isRunning}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm focus:ring-2 focus:ring-teal-500 focus:outline-none"
            />
          </div>
        </div>

        {/* Validation Error Banner */}
        {testValidationError && (
          <div className="p-3.5 mb-4 rounded-2xl bg-rose-50 dark:bg-rose-950/60 border-2 border-rose-400 text-rose-800 dark:text-rose-200 text-xs font-black flex items-center justify-between gap-2 animate-shake">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{testValidationError}</span>
            </div>
            <button
              onClick={() => setTestValidationError(null)}
              className="text-rose-500 hover:text-rose-700 text-xs font-bold"
            >
              ✕
            </button>
          </div>
        )}

        {/* Test Performance Logging Area (Total, Correct, Wrong) */}
        <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 mb-6 space-y-3">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <span className="text-xs font-extrabold text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
              <span>📊 ثبت دستی عملکرد تستی پارت (الزامی):</span>
            </span>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={handleResetTestNumbers}
                className="text-[11px] font-bold text-rose-600 dark:text-rose-400 hover:underline flex items-center gap-1 cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" />
                <span>بازنشانی تعداد تست‌ها</span>
              </button>
              <span className="text-xs font-black text-teal-600 dark:text-teal-400 tabular-nums">
                درصد صحت: {toFaDigits(totalTests > 0 ? Math.round((correctTests / totalTests) * 100) : 0)}٪
              </span>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-[11px] font-bold text-slate-500 mb-1">کل تست‌ها:</label>
              <input
                type="number"
                min={0}
                max={300}
                value={totalTests}
                onChange={(e) => {
                  setTotalTests(Number(e.target.value) || 0);
                  setTestValidationError(null);
                }}
                className="w-full px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-bold text-center tabular-nums"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-emerald-600 mb-1">تست‌های درست ✅:</label>
              <input
                type="number"
                min={0}
                max={300}
                value={correctTests}
                onChange={(e) => {
                  setCorrectTests(Number(e.target.value) || 0);
                  setHasManuallyEnteredTests(true);
                  setTestValidationError(null);
                }}
                className="w-full px-3 py-1.5 rounded-xl border-2 border-emerald-400 dark:border-emerald-700 bg-emerald-50/60 dark:bg-emerald-950/40 text-xs font-black text-center tabular-nums text-emerald-700 dark:text-emerald-300"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-rose-600 mb-1">تست‌های غلط ❌:</label>
              <input
                type="number"
                min={0}
                max={300}
                value={wrongTests}
                onChange={(e) => {
                  setWrongTests(Number(e.target.value) || 0);
                  setHasManuallyEnteredTests(true);
                  setTestValidationError(null);
                }}
                className="w-full px-3 py-1.5 rounded-xl border-2 border-rose-400 dark:border-rose-700 bg-rose-50/60 dark:bg-rose-950/40 text-xs font-black text-center tabular-nums text-rose-700 dark:text-rose-300"
              />
            </div>
          </div>

          {!hasManuallyEnteredTests && (
            <p className="text-[11px] text-amber-600 dark:text-amber-400 font-bold">
              * وارد کردن تعداد تست‌های درست و غلط به‌صورت دستی برای ثبت پایانی الزامی است.
            </p>
          )}
        </div>

        {/* Preset Time Buttons */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-slate-600 dark:text-slate-300">
              مدت زمان پارت معکوس:
            </span>
            <span className="text-xs text-teal-600 dark:text-teal-400 font-bold">
              بلوک استاندارد کنکور: ۱.۵ ساعت (۹۰ دقیقه)
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {[
              { label: '۹۰ دقیقه (۱.۵ ساعت استاندارد)', mins: 90, highlight: true },
              { label: '۷۵ دقیقه', mins: 75, highlight: false },
              { label: '۶۰ دقیقه (۱ ساعت)', mins: 60, highlight: false },
              { label: '۴۵ دقیقه', mins: 45, highlight: false },
              { label: '۳۰ دقیقه (مرور سریع)', mins: 30, highlight: false },
            ].map((preset) => (
              <button
                key={preset.mins}
                type="button"
                disabled={isRunning}
                onClick={() => handlePresetSelect(preset.mins)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
                  plannedMinutes === preset.mins
                    ? 'bg-teal-600 text-white shadow-xs'
                    : preset.highlight
                    ? 'bg-teal-50 dark:bg-teal-950/40 text-teal-700 dark:text-teal-300 border border-teal-300 dark:border-teal-700'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
                } ${isRunning ? 'opacity-60 cursor-not-allowed' : ''}`}
              >
                {preset.label}
              </button>
            ))}
          </div>
        </div>

        {/* Digital Countdown Display Area */}
        <div className="my-8 flex flex-col items-center justify-center">
          <div className="relative flex flex-col items-center justify-center p-8 rounded-3xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 w-full max-w-md shadow-inner">
            <div className="text-xs font-bold text-slate-500 dark:text-slate-400 mb-2 flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-teal-600" />
              <span>
                زمان معکوس {subject} ({bookSource}):
              </span>
            </div>

            {/* Huge Digital Countdown Numbers */}
            <div className="text-6xl sm:text-7xl font-extrabold font-mono tracking-tight text-slate-900 dark:text-white tabular-nums my-2">
              {toFaDigits(String(mins).padStart(2, '0'))}:{toFaDigits(String(secs).padStart(2, '0'))}
            </div>

            {/* Visual Progress Bar */}
            <div className="w-full bg-slate-200 dark:bg-slate-700 h-2.5 rounded-full overflow-hidden mt-3">
              <div
                className="bg-teal-600 dark:bg-teal-500 h-full transition-all duration-500 rounded-full"
                style={{ width: `${progressPercent}%` }}
              />
            </div>

            <div className="flex items-center justify-between w-full mt-2 text-[11px] text-slate-500 dark:text-slate-400 tabular-nums">
              <span>{toFaDigits(Math.round(progressPercent))}٪ سپری شده</span>
              <span>کل پارت: {toFaDigits(plannedMinutes)} دقیقه</span>
            </div>
          </div>
        </div>

        {/* Big Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
          {!isRunning ? (
            <button
              type="button"
              onClick={handleStart}
              className="w-full sm:w-auto px-8 py-3.5 rounded-2xl bg-teal-600 hover:bg-teal-700 text-white font-extrabold text-base flex items-center justify-center gap-2 shadow-md transition cursor-pointer"
            >
              <Play className="w-5 h-5 fill-current" />
              <span>شروع مطالعه معکوس</span>
            </button>
          ) : (
            <>
              <button
                type="button"
                onClick={handlePause}
                className="w-full sm:w-auto px-6 py-3 rounded-2xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-xs transition cursor-pointer"
              >
                <Pause className="w-4 h-4" />
                <span>{isPaused ? 'ادامه مطالعه' : 'توقف موقت'}</span>
              </button>

              <button
                type="button"
                onClick={handleFinishEarlyComplete}
                className="w-full sm:w-auto px-6 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-xs transition cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>پایان و ثبت در کارنامه</span>
              </button>
            </>
          )}

          {/* Reset button if not running but modified */}
          {!isRunning && secondsLeft !== plannedMinutes * 60 && (
            <button
              type="button"
              onClick={handleReset}
              className="w-full sm:w-auto px-5 py-3 rounded-2xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-sm font-semibold flex items-center justify-center gap-2 cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>بازنشانی به {toFaDigits(plannedMinutes)} دقیقه</span>
            </button>
          )}
        </div>

        {/* Crucial Incomplete Study Option */}
        {isRunning && (
          <div className="mt-6 pt-5 border-t border-slate-100 dark:border-slate-800 text-center">
            <button
              type="button"
              onClick={handleIncompleteStudySendToCompensation}
              className="px-5 py-2.5 rounded-xl border border-amber-300 dark:border-amber-700 bg-amber-50 dark:bg-amber-950/40 text-amber-900 dark:text-amber-200 hover:bg-amber-100 text-xs font-bold transition flex items-center justify-center gap-2 mx-auto cursor-pointer"
            >
              <AlertCircle className="w-4 h-4 text-amber-600" />
              <span>
                مطالعه نصفه موند؟ (توقف و ارسال زمان باقی‌مانده به «ایستگاه جبرانی‌ها»)
              </span>
            </button>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1.5">
              با زدن این دکمه، دقیقاً کسری دقایق باقی‌مانده در لیست جبرانی ذخیره می‌شود تا بعداً کاملش کنی.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
