import React from 'react';
import { ActivityType, TajrobiSubject, TimeBlock } from '../types';
import {
  ACTIVITY_META,
  TAJROBI_SUBJECTS_INFO,
  toFaDigits,
} from '../utils/tajrobiData';
import {
  AlertTriangle,
  Flame,
  CheckCircle,
  Lightbulb,
  TrendingDown,
  Hourglass,
} from 'lucide-react';

interface WastedTimeChartProps {
  blocks: TimeBlock[];
}

export const WastedTimeChart: React.FC<WastedTimeChartProps> = ({ blocks }) => {
  // Aggregate hours and blocks
  const activityHours: Record<ActivityType, number> = {
    study: 0,
    wasted: 0,
    sleep: 0,
    school: 0,
    school_class: 0,
    rest: 0,
    personal: 0,
    compensation: 0,
  };

  blocks.forEach((b) => {
    activityHours[b.activityType] = (activityHours[b.activityType] || 0) + 1.5;
  });

  const totalStudyAndComp = activityHours.study + activityHours.compensation;
  const totalWasted = activityHours.wasted;
  const totalSleep = activityHours.sleep;
  const totalSchool = activityHours.school_class + activityHours.school;
  const totalPersonal = activityHours.personal + activityHours.rest;

  const wakingHours = Math.max(1, 24 - totalSleep);
  const wastedPercentOfWaking = Math.round((totalWasted / wakingHours) * 100);
  const studyPercentOfWaking = Math.round((totalStudyAndComp / wakingHours) * 100);

  // Subject breakdown for study blocks
  const subjectHours: Partial<Record<TajrobiSubject, number>> = {};
  blocks.forEach((b) => {
    if ((b.activityType === 'study' || b.activityType === 'compensation') && b.subject) {
      const subj = b.subject as TajrobiSubject;
      subjectHours[subj] = (subjectHours[subj] || 0) + 1.5;
    }
  });

  // Wasted blocks list
  const wastedBlocks = blocks.filter((b) => b.activityType === 'wasted');

  return (
    <div className="space-y-6">
      {/* Top Banner Alert on Wasted Time */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <h2 className="text-lg font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              <Hourglass className="w-5 h-5 text-rose-500" />
              <span>تحلیل ۲۴ ساعته روز و نمودار میزان «تایم پرتی»</span>
            </h2>
            <p className="text-xs text-slate-600 dark:text-slate-400">
              مشاهده سهم دقیق هدررفت وقت در مقایسه با ساعت مطالعه مفید تجربی و خواب
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span
              className={`px-4 py-2 rounded-2xl text-xs font-extrabold tabular-nums border ${
                totalWasted === 0
                  ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                  : totalWasted <= 1.5
                  ? 'bg-amber-50 text-amber-800 border-amber-300'
                  : 'bg-rose-50 text-rose-800 border-rose-300 dark:bg-rose-950/40 dark:text-rose-200'
              }`}
            >
              {totalWasted === 0
                ? 'آفرین! صفر ساعت پرتی 🎉'
                : `میزان پرتی: ${toFaDigits(totalWasted)} ساعت (${toFaDigits(wastedPercentOfWaking)}٪ از ساعات بیداری)`}
            </span>
          </div>
        </div>
      </div>

      {/* 4 Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Wasted Card */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-rose-200 dark:border-rose-800/80 p-5 shadow-xs">
          <div className="flex items-center justify-between text-xs font-bold text-rose-600 dark:text-rose-400">
            <span>تایم پرتی و هدررفت</span>
            <AlertTriangle className="w-4 h-4 text-rose-500" />
          </div>
          <div className="text-2xl font-extrabold text-rose-600 dark:text-rose-400 tabular-nums mt-2">
            {toFaDigits(totalWasted)} ساعت
          </div>
          <div className="text-xs text-slate-500 dark:text-slate-400 mt-1 tabular-nums">
            {toFaDigits(wastedBlocks.length)} بلوک ۱.۵ ساعته از شبانه‌روز
          </div>
        </div>

        {/* Study Card */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-emerald-200 dark:border-emerald-800/80 p-5 shadow-xs">
          <div className="flex items-center justify-between text-xs font-bold text-emerald-600 dark:text-emerald-400">
            <span>مطالعه مفید تجربی</span>
            <Flame className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-2xl font-extrabold text-emerald-600 dark:text-emerald-400 tabular-nums mt-2">
            {toFaDigits(totalStudyAndComp)} ساعت
          </div>
          <div className="text-xs text-slate-500 dark:text-slate-400 mt-1 tabular-nums">
            {toFaDigits(studyPercentOfWaking)}٪ از کل ساعات بیداری مفید
          </div>
        </div>

        {/* Sleep Card */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-indigo-200 dark:border-indigo-800/80 p-5 shadow-xs">
          <div className="flex items-center justify-between text-xs font-bold text-indigo-600 dark:text-indigo-400">
            <span>خواب و استراحت</span>
            <CheckCircle className="w-4 h-4 text-indigo-500" />
          </div>
          <div className="text-2xl font-extrabold text-indigo-600 dark:text-indigo-400 tabular-nums mt-2">
            {toFaDigits(totalSleep)} ساعت
          </div>
          <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            {totalSleep >= 7 && totalSleep <= 8.5 ? 'میزان خواب ایده‌آل کنکوری' : 'نیازمند تنظیم ساعت خواب'}
          </div>
        </div>

        {/* School & Personal Card */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-blue-200 dark:border-blue-800/80 p-5 shadow-xs">
          <div className="flex items-center justify-between text-xs font-bold text-blue-600 dark:text-blue-400">
            <span>مدرسه، کلاس و امور شخصی</span>
            <Hourglass className="w-4 h-4 text-blue-500" />
          </div>
          <div className="text-2xl font-extrabold text-blue-600 dark:text-blue-400 tabular-nums mt-2">
            {toFaDigits(totalSchool + totalPersonal)} ساعت
          </div>
          <div className="text-xs text-slate-500 dark:text-slate-400 mt-1 tabular-nums">
            شامل {toFaDigits(totalSchool)} ساعت مدرسه + {toFaDigits(totalPersonal)} ساعت استراحت/غذا
          </div>
        </div>
      </div>

      {/* Visual 24-Hour Progress Breakdown Bar */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 space-y-4 shadow-xs">
        <h3 className="text-sm font-extrabold text-slate-900 dark:text-white">
          نمودار میله‌ای پیوسته ۲۴ ساعت شبانه‌روز
        </h3>

        <div className="w-full h-8 bg-slate-100 dark:bg-slate-800 rounded-2xl overflow-hidden flex shadow-inner">
          {totalStudyAndComp > 0 && (
            <div
              style={{ width: `${(totalStudyAndComp / 24) * 100}%` }}
              className="bg-emerald-500 h-full flex items-center justify-center text-[11px] font-bold text-white tabular-nums px-1"
              title={`مطالعه تجربی: ${toFaDigits(totalStudyAndComp)} ساعت`}
            >
              مطالعه {toFaDigits(totalStudyAndComp)}h
            </div>
          )}

          {totalWasted > 0 && (
            <div
              style={{ width: `${(totalWasted / 24) * 100}%` }}
              className="bg-rose-500 h-full flex items-center justify-center text-[11px] font-bold text-white tabular-nums px-1 animate-pulse"
              title={`تایم پرتی: ${toFaDigits(totalWasted)} ساعت`}
            >
              پرتی {toFaDigits(totalWasted)}h
            </div>
          )}

          {totalSchool > 0 && (
            <div
              style={{ width: `${(totalSchool / 24) * 100}%` }}
              className="bg-blue-500 h-full flex items-center justify-center text-[11px] font-bold text-white tabular-nums px-1"
              title={`مدرسه و کلاس: ${toFaDigits(totalSchool)} ساعت`}
            >
              مدرسه {toFaDigits(totalSchool)}h
            </div>
          )}

          {totalPersonal > 0 && (
            <div
              style={{ width: `${(totalPersonal / 24) * 100}%` }}
              className="bg-purple-400 h-full flex items-center justify-center text-[11px] font-bold text-white tabular-nums px-1"
              title={`امور شخصی و غذا: ${toFaDigits(totalPersonal)} ساعت`}
            >
              شخصی {toFaDigits(totalPersonal)}h
            </div>
          )}

          {totalSleep > 0 && (
            <div
              style={{ width: `${(totalSleep / 24) * 100}%` }}
              className="bg-indigo-500 h-full flex items-center justify-center text-[11px] font-bold text-white tabular-nums px-1"
              title={`خواب شبانه: ${toFaDigits(totalSleep)} ساعت`}
            >
              خواب {toFaDigits(totalSleep)}h
            </div>
          )}
        </div>

        {/* Legend */}
        <div className="flex flex-wrap items-center justify-between gap-3 text-xs text-slate-600 dark:text-slate-400 pt-2 border-t border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-emerald-500" />
            <span>مطالعه تجربی ({toFaDigits(totalStudyAndComp)} ساعت)</span>
          </div>

          <div className="flex items-center gap-1.5 font-bold text-rose-600 dark:text-rose-400">
            <span className="w-3 h-3 rounded-full bg-rose-500" />
            <span>تایم پرتی ({toFaDigits(totalWasted)} ساعت)</span>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-blue-500" />
            <span>مدرسه و کلاس ({toFaDigits(totalSchool)} ساعت)</span>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-purple-400" />
            <span>امور شخصی ({toFaDigits(totalPersonal)} ساعت)</span>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-indigo-500" />
            <span>خواب ({toFaDigits(totalSleep)} ساعت)</span>
          </div>
        </div>
      </div>

      {/* Two Column Section: Wasted Time Details & Smart Advice */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Wasted Blocks Breakdown */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 space-y-4 shadow-xs">
          <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
            <TrendingDown className="w-4 h-4 text-rose-500" />
            <span>جزئیات بلوک‌های پرتی روز ({toFaDigits(wastedBlocks.length)} بلوک)</span>
          </h3>

          {wastedBlocks.length === 0 ? (
            <p className="text-xs text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 p-4 rounded-2xl">
              تبریک! هیچ بلوک پرتی ثبت نشده است. تمام وقت بیداری خود را هدفمند سپری کرده‌اید.
            </p>
          ) : (
            <div className="space-y-2.5">
              {wastedBlocks.map((wb) => (
                <div
                  key={wb.id}
                  className="p-3.5 rounded-2xl bg-rose-50/50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900/60 flex items-center justify-between text-xs"
                >
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-rose-700 dark:text-rose-300 tabular-nums">
                      بلوک {toFaDigits(wb.blockNumber ?? wb.id)}: {wb.startTime && wb.endTime ? `${toFaDigits(wb.startTime)} تا ${toFaDigits(wb.endTime)}` : toFaDigits(wb.timeRange)}
                    </span>
                    <span className="text-slate-500 dark:text-slate-400">·</span>
                    <span className="text-slate-700 dark:text-slate-200 font-medium">
                      {wb.topic || 'بدون ثبت علت (فضای مجازی یا تعلل)'}
                    </span>
                  </div>
                  <span className="font-bold text-rose-600 dark:text-rose-400 shrink-0 tabular-nums">
                    ۱.۵ ساعت پرتی
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Smart Motivational Advice for Tajrobi Student */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 space-y-4 shadow-xs">
          <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
            <Lightbulb className="w-4 h-4 text-amber-500" />
            <span>راهکار مشاوره‌ای برای مهار تایم پرتی رشته تجربی</span>
          </h3>

          <div className="space-y-3 text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
            <div className="p-3.5 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/60">
              <strong className="block text-amber-900 dark:text-amber-200 mb-1">
                معادله تبدیل تایم پرتی به رتبه کنکور:
              </strong>
              اگر {toFaDigits(totalWasted)} ساعت تایم پرتی امروز را به نصف کاهش دهی، روزانه حداقل ۱ پارت کامل تست زیست‌شناسی یا شیمی اضافه می‌کنی؛ یعنی ماهانه بیش از ۱,۲۰۰ تست بیشتر از رقبا!
            </div>

            <p>
              <strong>نکته طلایی برای زیست‌شناسی:</strong> زمان‌هایی که خسته‌ای و وسوسه گوشی به سراغت می‌آید، به جای گشتن در اینستاگرام، شکل‌های کتاب درسی زیست‌شناسی دهم یا یازدهم را به مدت ۲۰ دقیقه ورق بزن و زیرنویس‌ها را مرور کن.
            </p>

            <p>
              <strong>پیشگیری از پرتی بعدازظهر:</strong> تایم ساعت ۱۸:۰۰ تا ۲۰:۰۰ پرخطرترین ساعت روز برای دانش‌آموزان تجربی است. این بازه را با یک درس حل‌کردنی مثل <strong>فیزیک یا ریاضی تجربی</strong> پر کن تا خواب‌آلودگی از سرت بپرد.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
