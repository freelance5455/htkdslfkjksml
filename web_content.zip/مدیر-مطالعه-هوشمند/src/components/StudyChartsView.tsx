import React, { useState } from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  PointElement,
  LineElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from 'chart.js';
import { Bar, Line, Doughnut } from 'react-chartjs-2';
import { GradeLevel, StudyLog, TajrobiSubject, TimeBlock } from '../types';
import {
  ACADEMIC_MONTHS,
  GRADE_LEVELS,
  GRADE_META,
  TAJROBI_SUBJECTS_INFO,
  TAJROBI_SUBJECTS_LIST,
  detectGradeFromText,
  formatISOToJalaliShort,
  formatMinutesToHoursAndMinutes,
  getOffsetDateISO,
  toPersianDigits,
} from '../utils/tajrobiData';
import {
  BarChart3,
  PieChart,
  TrendingUp,
  Scale,
  Calendar,
  Layers,
  Sparkles,
  AlertCircle,
  CheckCircle2,
} from 'lucide-react';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  PointElement,
  LineElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

interface StudyChartsViewProps {
  logs: StudyLog[];
  blocks: TimeBlock[];
}

export const StudyChartsView: React.FC<StudyChartsViewProps> = ({ logs }) => {
  const [activeChartTab, setActiveChartTab] = useState<'monthly' | 'grades' | 'weekly' | 'subjects'>('monthly');

  // 1. MONTHLY DATA (پیشرفت تحصیلی ماهانه)
  // Calculate study hours, test count, and average accuracy for each academic month
  const monthlyMetrics = ACADEMIC_MONTHS.map((month) => {
    const monthLogs = logs.filter((l) => l.monthLabel === month);
    const totalMinutes = monthLogs.reduce((acc, l) => acc + l.durationMinutes, 0);
    const totalHours = Number((totalMinutes / 60).toFixed(1));
    const totalTests = monthLogs.reduce((acc, l) => acc + l.totalTests, 0);
    const correctTests = monthLogs.reduce((acc, l) => acc + l.correctTests, 0);
    const accuracy = totalTests > 0 ? Math.round((correctTests / totalTests) * 100) : 0;

    return {
      month,
      totalHours,
      totalTests,
      accuracy,
      logCount: monthLogs.length,
    };
  });

  // Filter months that have data, or show standard active months
  const activeMonthsData = monthlyMetrics.filter((m) => m.logCount > 0 || ['مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی'].includes(m.month));

  const monthlyChartData = {
    labels: activeMonthsData.map((m) => m.month),
    datasets: [
      {
        type: 'bar' as const,
        label: 'ساعت مطالعه ماهانه',
        data: activeMonthsData.map((m) => m.totalHours),
        backgroundColor: '#0f766e',
        borderRadius: 8,
        yAxisID: 'yHours',
      },
      {
        type: 'bar' as const,
        label: 'تعداد تست حل‌شده',
        data: activeMonthsData.map((m) => m.totalTests),
        backgroundColor: '#3b82f6',
        borderRadius: 8,
        yAxisID: 'yTests',
      },
      {
        type: 'line' as const,
        label: 'درصد دقت آزمون‌ها (٪)',
        data: activeMonthsData.map((m) => (m.accuracy > 0 ? m.accuracy : null)),
        borderColor: '#10b981',
        backgroundColor: 'rgba(16, 185, 129, 0.2)',
        borderWidth: 3,
        pointRadius: 5,
        pointBackgroundColor: '#10b981',
        tension: 0.3,
        yAxisID: 'yAccuracy',
      },
    ],
  };

  // 2. GRADE BALANCE DATA (تعادل مطالعه دهم، یازدهم، دوازدهم و عمومی‌ها)
  const gradeHours: Record<GradeLevel, number> = {
    'دهم': 0,
    'یازدهم': 0,
    'دوازدهم': 0,
    'جامع': 0,
    'عمومی و نهایی': 0,
  };

  const gradeTests: Record<GradeLevel, number> = {
    'دهم': 0,
    'یازدهم': 0,
    'دوازدهم': 0,
    'جامع': 0,
    'عمومی و نهایی': 0,
  };

  logs.forEach((log) => {
    const grade: GradeLevel = log.gradeLevel || detectGradeFromText(log.topic + ' ' + (log.bookSource || ''));
    if (gradeHours[grade] !== undefined) {
      gradeHours[grade] += log.durationMinutes / 60;
      gradeTests[grade] += log.totalTests;
    }
  });

  const totalAllGradeHours = Object.values(gradeHours).reduce((a, b) => a + b, 0) || 1;

  const gradeBalanceChartData = {
    labels: GRADE_LEVELS.map((g) => GRADE_META[g].label),
    datasets: [
      {
        label: 'ساعت مطالعه',
        data: GRADE_LEVELS.map((g) => Number(gradeHours[g].toFixed(1))),
        backgroundColor: GRADE_LEVELS.map((g) => GRADE_META[g].color),
        borderWidth: 2,
        borderColor: '#ffffff',
      },
    ],
  };

  // 3. WEEKLY TREND (7 روز اخیر)
  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const daysAgo = 6 - i;
    const iso = getOffsetDateISO(daysAgo);
    return {
      iso,
      jalali: formatISOToJalaliShort(iso),
    };
  });

  const dailyStudyHours = last7Days.map((day) => {
    const dayLogs = logs.filter((l) => l.date === day.iso);
    const mins = dayLogs.reduce((acc, l) => acc + l.durationMinutes, 0);
    return Number((mins / 60).toFixed(1));
  });

  const dailyTests = last7Days.map((day) => {
    const dayLogs = logs.filter((l) => l.date === day.iso);
    return dayLogs.reduce((acc, l) => acc + l.totalTests, 0);
  });

  const weeklyChartData = {
    labels: last7Days.map((d) => d.jalali),
    datasets: [
      {
        label: 'ساعت مطالعه روزانه',
        data: dailyStudyHours,
        backgroundColor: '#0f766e',
        borderRadius: 8,
      },
      {
        label: 'تعداد تست',
        data: dailyTests,
        backgroundColor: '#f59e0b',
        borderRadius: 8,
      },
    ],
  };

  // 4. SUBJECT BREAKDOWN (توزیع بین دروس)
  const subjectHours: Record<TajrobiSubject, number> = {
    'زیست‌شناسی': 0,
    'شیمی': 0,
    'فیزیک': 0,
    'ریاضی تجربی': 0,
    'زمین‌شناسی': 0,
    'امتحانات نهایی / عمومی': 0,
  };

  logs.forEach((log) => {
    if (subjectHours[log.subject] !== undefined) {
      subjectHours[log.subject] += log.durationMinutes / 60;
    }
  });

  const subjectChartData = {
    labels: TAJROBI_SUBJECTS_LIST,
    datasets: [
      {
        data: TAJROBI_SUBJECTS_LIST.map((s) => Number(subjectHours[s].toFixed(1))),
        backgroundColor: TAJROBI_SUBJECTS_LIST.map((s) => TAJROBI_SUBJECTS_INFO[s].color),
        borderWidth: 2,
        borderColor: '#ffffff',
      },
    ],
  };

  // Recommended golden ratio comparison for grades
  const dehPercent = Math.round((gradeHours['دهم'] / totalAllGradeHours) * 100);
  const yazdehPercent = Math.round((gradeHours['یازدهم'] / totalAllGradeHours) * 100);
  const davazdahPercent = Math.round((gradeHours['دوازدهم'] / totalAllGradeHours) * 100);

  return (
    <div className="space-y-6 animate-fade-slide">
      {/* Top Banner with Navigation Tabs for Charts */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-teal-600" />
            <span>مرکز آمار و تحلیل نمودارهای پیشرفت تجربی</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            بررسی پیشرفت تحصیلی ماهانه، تعادل دهم/یازدهم/دوازدهم، رشد تست‌زنی و دقت درصدی
          </p>
        </div>

        {/* Sub-Tabs Selector */}
        <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 overflow-x-auto no-scrollbar">
          {[
            { id: 'monthly' as const, label: '📈 پیشرفت ماهانه', icon: <TrendingUp className="w-3.5 h-3.5" /> },
            { id: 'grades' as const, label: '⚖️ تعادل پایه‌ها (دهم/یازدهم/دوازدهم)', icon: <Scale className="w-3.5 h-3.5" /> },
            { id: 'weekly' as const, label: '📅 روند ۷ روزه', icon: <Calendar className="w-3.5 h-3.5" /> },
            { id: 'subjects' as const, label: '📚 توزیع دروس', icon: <Layers className="w-3.5 h-3.5" /> },
          ].map((tab) => {
            const isActive = activeChartTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveChartTab(tab.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-black flex items-center gap-1.5 transition whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-teal-600 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {tab.icon}
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 1. MONTHLY PROGRESS VIEW */}
      {activeChartTab === 'monthly' && (
        <div className="space-y-6 animate-fade-in">
          {/* Top Monthly Stat Pills */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs">
              <span className="text-xs font-bold text-slate-500">کل ساعات ثبت‌شده:</span>
              <div className="text-2xl font-black text-slate-900 dark:text-white tabular-nums mt-1">
                {formatMinutesToHoursAndMinutes(logs.reduce((acc, l) => acc + l.durationMinutes, 0))}
              </div>
              <span className="text-[11px] text-teal-600 font-bold mt-1 block">روند رو به رشد</span>
            </div>

            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs">
              <span className="text-xs font-bold text-slate-500">کل تست‌های حل‌شده:</span>
              <div className="text-2xl font-black text-blue-600 dark:text-blue-400 tabular-nums mt-1">
                {toPersianDigits(logs.reduce((acc, l) => acc + l.totalTests, 0))} تست
              </div>
              <span className="text-[11px] text-slate-400 font-bold mt-1 block">بانک تست آزمایشی</span>
            </div>

            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs">
              <span className="text-xs font-bold text-slate-500">میانگین دقت تستی:</span>
              <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400 tabular-nums mt-1">
                {toPersianDigits(
                  Math.round(
                    logs.reduce((acc, l) => acc + l.accuracyPercentage, 0) / (logs.length || 1)
                  )
                )}٪
              </div>
              <span className="text-[11px] text-emerald-600 font-bold mt-1 block">تثبیت تسلط مفهومی</span>
            </div>

            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs">
              <span className="text-xs font-bold text-slate-500">ماه جاری:</span>
              <div className="text-2xl font-black text-purple-600 dark:text-purple-400 tabular-nums mt-1">
                مهر ۱۴۰۵
              </div>
              <span className="text-[11px] text-slate-400 font-bold mt-1 block">شروع پرانرژی سال تحصیلی</span>
            </div>
          </div>

          {/* Monthly Progress Chart Card */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
              <div>
                <h3 className="text-sm font-black text-slate-900 dark:text-white flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-teal-600" />
                  <span>نمودار پیشرفت تحصیلی ماه به ماه در طول سال کنکور</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  مقایسه ساعات مطالعه، حجم تست‌های حل‌شده و درصد دقت در ماه‌های مختلف سال
                </p>
              </div>

              <div className="flex items-center gap-2 text-xs font-bold">
                <span className="flex items-center gap-1 text-teal-700 dark:text-teal-400">
                  <span className="w-3 h-3 rounded-sm bg-teal-700 inline-block" /> ساعت مطالعه
                </span>
                <span className="flex items-center gap-1 text-blue-600 dark:text-blue-400">
                  <span className="w-3 h-3 rounded-sm bg-blue-500 inline-block" /> تعداد تست
                </span>
                <span className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
                  <span className="w-3 h-1 bg-emerald-500 inline-block" /> درصد درستی (دقت)
                </span>
              </div>
            </div>

            <div className="h-80 w-full flex items-center justify-center pt-2">
              <Bar
                data={monthlyChartData as any}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    legend: { display: false },
                    tooltip: {
                      callbacks: {
                        label: (ctx) => {
                          if (ctx.dataset.label?.includes('دقت')) {
                            return `${ctx.dataset.label}: ${toPersianDigits(ctx.raw as number)}٪`;
                          }
                          if (ctx.dataset.label?.includes('ساعت')) {
                            return `${ctx.dataset.label}: ${toPersianDigits(ctx.raw as number)} ساعت`;
                          }
                          return `${ctx.dataset.label}: ${toPersianDigits(ctx.raw as number)} تست`;
                        },
                      },
                    },
                  },
                  scales: {
                    x: {
                      grid: { display: false },
                    },
                    yHours: {
                      type: 'linear',
                      position: 'left',
                      beginAtZero: true,
                      title: { display: true, text: 'ساعت مطالعه ماهانه' },
                    },
                    yTests: {
                      type: 'linear',
                      position: 'right',
                      beginAtZero: true,
                      grid: { drawOnChartArea: false },
                      title: { display: true, text: 'تعداد تست' },
                    },
                    yAccuracy: {
                      type: 'linear',
                      position: 'right',
                      min: 0,
                      max: 100,
                      grid: { drawOnChartArea: false },
                      title: { display: true, text: 'دقت (٪)' },
                    },
                  },
                }}
              />
            </div>
          </div>
        </div>
      )}

      {/* 2. GRADE BALANCE VIEW (تعادل مطالعه پایه‌ها) */}
      {activeChartTab === 'grades' && (
        <div className="space-y-6 animate-fade-in">
          {/* Golden Balance Warning / Status */}
          <div className="bg-linear-to-r from-teal-50 via-purple-50 to-blue-50 dark:from-slate-900 dark:via-purple-950/30 dark:to-slate-900 rounded-3xl border border-teal-200 dark:border-teal-800 p-6 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Scale className="w-5 h-5 text-teal-600" />
                <h3 className="text-sm font-black text-slate-900 dark:text-white">
                  وضعیت تعادل مطالعه پایه‌ها (دهم، یازدهم، دوازدهم)
                </h3>
              </div>
              <span className="text-xs font-black px-3 py-1 rounded-full bg-teal-600 text-white">
                فرمول استاندارد رتبه‌های برتر
              </span>
            </div>

            <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed font-medium">
              طبق الگوریتم مطالعه داوطلبان تجربی، توازن بهینه برای نیم‌سال اول عبارت است از: <strong>۴۰٪ دوازدهم</strong> (پیشروی با مدرسه و امتحانات نهایی)، <strong>۳۰٪ یازدهم</strong> و <strong>۳۰٪ دهم</strong> (تثبیت پایه‌های پایه).
            </p>

            {/* Percentage Comparison Bars */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
              <div className="p-3 rounded-2xl bg-white dark:bg-slate-800/80 border border-teal-200 dark:border-teal-800">
                <div className="flex justify-between text-xs font-bold mb-1">
                  <span>پایه دهم</span>
                  <span className="text-teal-700 dark:text-teal-300 tabular-nums">{toPersianDigits(dehPercent)}٪ (هدف: ۳۰٪)</span>
                </div>
                <div className="w-full bg-slate-100 dark:bg-slate-700 h-2 rounded-full overflow-hidden">
                  <div className="bg-teal-500 h-full rounded-full" style={{ width: `${Math.min(100, dehPercent * 2)}%` }} />
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-white dark:bg-slate-800/80 border border-purple-200 dark:border-purple-800">
                <div className="flex justify-between text-xs font-bold mb-1">
                  <span>پایه یازدهم</span>
                  <span className="text-purple-700 dark:text-purple-300 tabular-nums">{toPersianDigits(yazdehPercent)}٪ (هدف: ۳۰٪)</span>
                </div>
                <div className="w-full bg-slate-100 dark:bg-slate-700 h-2 rounded-full overflow-hidden">
                  <div className="bg-purple-500 h-full rounded-full" style={{ width: `${Math.min(100, yazdehPercent * 2)}%` }} />
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-white dark:bg-slate-800/80 border border-blue-200 dark:border-blue-800">
                <div className="flex justify-between text-xs font-bold mb-1">
                  <span>پایه دوازدهم</span>
                  <span className="text-blue-700 dark:text-blue-300 tabular-nums">{toPersianDigits(davazdahPercent)}٪ (هدف: ۴۰٪)</span>
                </div>
                <div className="w-full bg-slate-100 dark:bg-slate-700 h-2 rounded-full overflow-hidden">
                  <div className="bg-blue-500 h-full rounded-full" style={{ width: `${Math.min(100, davazdahPercent * 2)}%` }} />
                </div>
              </div>
            </div>
          </div>

          {/* Charts Row */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Doughnut Chart */}
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-4">
              <h3 className="text-sm font-black text-slate-900 dark:text-white flex items-center justify-between">
                <span>سهم ساعات مطالعه پایه‌های تحصیلی</span>
                <PieChart className="w-4 h-4 text-teal-600" />
              </h3>

              <div className="h-64 flex items-center justify-center">
                <Doughnut
                  data={gradeBalanceChartData}
                  options={{
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                      legend: { position: 'bottom' },
                    },
                  }}
                />
              </div>
            </div>

            {/* Grade Breakdown Cards */}
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-3">
              <h3 className="text-sm font-black text-slate-900 dark:text-white flex items-center gap-2">
                <Layers className="w-4 h-4 text-teal-600" />
                <span>آمار تفکیکی هر پایه</span>
              </h3>

              <div className="space-y-2.5">
                {GRADE_LEVELS.map((g) => {
                  const meta = GRADE_META[g];
                  const hours = gradeHours[g];
                  const tests = gradeTests[g];
                  const percent = Math.round((hours / totalAllGradeHours) * 100);

                  return (
                    <div
                      key={g}
                      className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/80 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-2.5">
                        <span
                          className="w-3.5 h-3.5 rounded-full shrink-0"
                          style={{ backgroundColor: meta.color }}
                        />
                        <div>
                          <div className="text-xs font-black text-slate-900 dark:text-white">
                            {meta.label}
                          </div>
                          <div className="text-[11px] text-slate-500">
                            {toPersianDigits(tests)} تست حل‌شده
                          </div>
                        </div>
                      </div>

                      <div className="text-left font-black tabular-nums">
                        <span className="text-sm text-slate-900 dark:text-white block">
                          {toPersianDigits(hours.toFixed(1))} ساعت
                        </span>
                        <span className="text-[11px] text-teal-600 block">
                          {toPersianDigits(percent)}٪ از کل
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 3. WEEKLY VIEW (روند ۷ روزه) */}
      {activeChartTab === 'weekly' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-4 animate-fade-in">
          <h3 className="text-sm font-black text-slate-900 dark:text-white flex items-center justify-between">
            <span>عملکرد روزانه ۷ روز گذشته (ساعت مطالعه و تست‌ها)</span>
            <span className="text-xs text-teal-600 font-bold">هفته جاری</span>
          </h3>

          <div className="h-72 flex items-center justify-center">
            <Bar
              data={weeklyChartData}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                  legend: { position: 'bottom' },
                },
                scales: {
                  y: {
                    beginAtZero: true,
                    ticks: {
                      callback: (v) => toPersianDigits(v),
                    },
                  },
                },
              }}
            />
          </div>
        </div>
      )}

      {/* 4. SUBJECTS DISTRIBUTION VIEW (توزیع دروس) */}
      {activeChartTab === 'subjects' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 animate-fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-4">
            <h3 className="text-sm font-black text-slate-900 dark:text-white flex items-center justify-between">
              <span>توزیع ساعات مطالعه بین دروس تجربی</span>
              <PieChart className="w-4 h-4 text-teal-600" />
            </h3>

            <div className="h-64 flex items-center justify-center">
              <Doughnut
                data={subjectChartData}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    legend: { position: 'bottom' },
                  },
                }}
              />
            </div>
          </div>

          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-3">
            <h3 className="text-sm font-black text-slate-900 dark:text-white">
              ضرایب و ساعات دروس تجربی
            </h3>

            <div className="space-y-2">
              {TAJROBI_SUBJECTS_LIST.map((subj) => {
                const info = TAJROBI_SUBJECTS_INFO[subj];
                const hours = subjectHours[subj];

                return (
                  <div
                    key={subj}
                    className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 flex items-center justify-between text-xs"
                  >
                    <div className="flex items-center gap-2">
                      <span className="w-3 h-3 rounded-full" style={{ backgroundColor: info.color }} />
                      <strong className="text-slate-800 dark:text-slate-200">{subj}</strong>
                      <span className="text-[10px] text-slate-500">({info.coefficient})</span>
                    </div>

                    <span className="font-black text-slate-900 dark:text-white tabular-nums">
                      {formatMinutesToHoursAndMinutes(hours * 60)}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
