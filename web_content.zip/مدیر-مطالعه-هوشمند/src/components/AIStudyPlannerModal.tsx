import React, { useState } from 'react';
import {
  AnnualPlanRoadmap,
  DayOfWeek,
  DaySchedule,
  GradeLevel,
  MonthlyPlanRoadmap,
  StudyPart,
  TajrobiSubject,
  ThemeConfig,
  TopicMemoryItem,
  WeeklySlot,
} from '../types';
import {
  DAYS_OF_WEEK,
  EBBINGHAUS_INTERVALS,
  GRADE_META,
  TAJROBI_SUBJECTS_INFO,
  TAJROBI_SUBJECTS_LIST,
  WEEKLY_TEMPLATES,
  formatMinutesToHoursAndMinutes,
  getOffsetDateISO,
  getTodayISO,
  getTodayPersianDayOfWeek,
  playChimeSound,
  toPersianDigits,
} from '../utils/tajrobiData';
import {
  GeneratedPlanResult,
  calculateNextEbbinghausDate,
  generateComprehensiveAIPlan,
} from '../utils/aiStudyPlanner';
import {
  Bot,
  Sparkles,
  Loader2,
  CheckCircle2,
  Calendar,
  Layers,
  Zap,
  Brain,
  Clock,
  School,
  BookOpen,
  Plus,
  Trash2,
  RotateCcw,
  Check,
  Award,
  AlertCircle,
  HelpCircle,
  Target,
  Compass,
} from 'lucide-react';

interface AIStudyPlannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  theme: ThemeConfig;
  defaultPlanType?: 'annual' | 'weekly' | 'monthly' | 'daily';
  topicMemories?: TopicMemoryItem[];
  onSaveTopicMemory?: (newMemories: TopicMemoryItem[]) => void;
  onApplyPlanToParts: (newParts: Array<Omit<StudyPart, 'id' | 'createdAt'>>) => void;
  onApplyWeeklySchedule?: (schedule: Record<DayOfWeek, DaySchedule>) => void;
  onApplyMonthlyPlan?: (plan: MonthlyPlanRoadmap) => void;
  onApplyAnnualPlan?: (plan: AnnualPlanRoadmap) => void;
  showToast: (message: string, type?: 'success' | 'warning' | 'info') => void;
}

export const AIStudyPlannerModal: React.FC<AIStudyPlannerModalProps> = ({
  isOpen,
  onClose,
  theme,
  defaultPlanType = 'annual',
  topicMemories = [],
  onSaveTopicMemory,
  onApplyPlanToParts,
  onApplyWeeklySchedule,
  onApplyMonthlyPlan,
  onApplyAnnualPlan,
  showToast,
}) => {
  const todayDay = getTodayPersianDayOfWeek();

  // Mode: 'plan' | 'memory'
  const [activeMode, setActiveMode] = useState<'plan' | 'memory'>('plan');

  // Plan Type: 'annual' | 'weekly' | 'monthly' | 'daily'
  const [planType, setPlanType] = useState<'annual' | 'weekly' | 'monthly' | 'daily'>(defaultPlanType);
  const [selectedDay, setSelectedDay] = useState<DayOfWeek>(todayDay);

  // School Settings
  const [isSchoolDay, setIsSchoolDay] = useState<boolean>(true);
  const [schoolHours, setSchoolHours] = useState<string>('07:30 - 13:30');

  // User prompts
  const [userPrompt, setUserPrompt] = useState<string>('');
  const [studiedTopicsPrompt, setStudiedTopicsPrompt] = useState<string>('');

  // Local Topic Memories
  const [localMemories, setLocalMemories] = useState<TopicMemoryItem[]>(topicMemories);
  const [newTopicSubject, setNewTopicSubject] = useState<TajrobiSubject>('زیست‌شناسی');
  const [newTopicGrade, setNewTopicGrade] = useState<GradeLevel>('دوازدهم');
  const [newTopicName, setNewTopicName] = useState<string>('');

  // Generation state
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [generatedResult, setGeneratedResult] = useState<GeneratedPlanResult | null>(null);

  if (!isOpen) return null;

  const quickPrompts = [
    {
      title: '🎯 استراتژی سالانه: اتمام کل پایه و دوازدهم تا پایان اسفند',
      type: 'annual' as const,
      text: 'یک استراتژی سالانه کامل بنویس که تا پایان اسفند ماه تمام درس‌های تخصصی دهم و یازدهم و کل دوازدهم یکبار همراه با تست‌زنی و مرورهای علمی بسته شوند و برای بهار آماده جمع‌بندی باشم.',
    },
    {
      title: '🏫 برنامه هفتگی با مدرسه (شنبه تا چهارشنبه)',
      type: 'weekly' as const,
      text: 'شنبه تا چهارشنبه ۷:۳۰ تا ۱۳:۳۰ در مدرسه‌ام. برای عصرها روزی ۵ تا ۶ ساعت مطالعه مفید با زیست دوازدهم، مسائل شیمی و فیزیک حرکت‌شناسی و پنجشنبه/جمعه آزمون جامع و جبرانی بنویس.',
    },
    {
      title: '🧠 برنامه با مرور خودکار ابینگهاوس (حافظه مبحثی)',
      type: 'weekly' as const,
      text: 'مباحث رونویسی زیست، استوکیومتری شیمی و حرکت‌شناسی فیزیک را خوانده‌ام. در برنامه هفتگی به صورت خودکار پارت‌های مرور ۱ روزه، ۳ روزه، ۱ هفته و ۱ ماه بعد را قرار بده.',
    },
    {
      title: '🗺️ نقشه راهبردی ۴ هفته‌ای ماهانه (Monthly)',
      type: 'monthly' as const,
      text: 'برنامه ماهانه راهبردی برای جمع‌بندی ۵۰ درصد زیست دوازدهم، شیمی یازدهم و روتین عمومی نهایی به همراه آزمون‌های ۲ هفته‌ای.',
    },
    {
      title: '🏖️ برنامه روز تعطیل و جمعه (فول‌تایم ۱۰ ساعت)',
      type: 'daily' as const,
      text: 'روز تعطیل هستم، برنامه فشرده ۱۰ ساعته با پارت طلایی صبح زیست، شیمی و فیزیک و تست‌های زمان‌دار.',
    },
  ];

  // Add new topic to memory
  const handleAddNewTopicMemory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTopicName.trim()) return;

    const { nextDate } = calculateNextEbbinghausDate(1);
    const newMem: TopicMemoryItem = {
      id: 'mem-' + Date.now(),
      subject: newTopicSubject,
      gradeLevel: newTopicGrade,
      topic: newTopicName.trim(),
      firstStudiedDate: getTodayISO(),
      lastStudiedDate: getTodayISO(),
      reviewLevel: 1, // Level 1: Day 1
      nextReviewDate: nextDate,
      nextReviewJalali: 'فردا',
      masteryScore: 60,
      totalTestsDone: 30,
      totalStudyMinutes: 90,
      notes: 'ثبت خودکار برای زنجیره مرور ابینگهاوس',
      isOverdue: false,
    };

    const updated = [newMem, ...localMemories];
    setLocalMemories(updated);
    if (onSaveTopicMemory) {
      onSaveTopicMemory(updated);
    }
    setNewTopicName('');
    showToast(`مبحث «${newMem.topic}» به حافظه هوشمند اضافه شد. مرور فردا تنظیم شد!`, 'success');
  };

  const handleGenerate = async () => {
    setIsLoading(true);
    setGeneratedResult(null);

    try {
      const result = await generateComprehensiveAIPlan({
        planType,
        userPrompt: userPrompt.trim() || (planType === 'annual' ? 'اتمام کل مباحث دهم و یازدهم و دوازدهم تا پایان اسفند با متدهای علمی' : 'برنامه استاندارد کنکور تجربی با ریتم مدرسه'),
        targetDay: selectedDay,
        schoolHours,
        isSchoolDay,
        dailyTestGoal: 100,
        topicMemories: localMemories,
        studiedTopicsPrompt,
      });

      setGeneratedResult(result);
      playChimeSound();
      showToast(`برنامه ${planType === 'annual' ? 'استراتژیک سالانه' : planType === 'weekly' ? 'هفتگی' : planType === 'monthly' ? 'ماهانه' : 'امروز'} با موفقیت تولید شد!`, 'success');
    } catch (err) {
      showToast('خطا در تولید برنامه هوش مصنوعی', 'warning');
    } finally {
      setIsLoading(false);
    }
  };

  const handleApplyPlan = () => {
    if (!generatedResult) return;

    const partsToCreate: Array<Omit<StudyPart, 'id' | 'createdAt'>> = [];

    if (generatedResult.planType === 'annual' && generatedResult.annualPlan) {
      if (onApplyAnnualPlan) {
        onApplyAnnualPlan(generatedResult.annualPlan);
      }
      if (onApplyWeeklySchedule) {
        onApplyWeeklySchedule(generatedResult.weeklySchedule || WEEKLY_TEMPLATES[0].schedule);
      }

      // Generate parts across days of week for annual strategy
      DAYS_OF_WEEK.forEach((day) => {
        partsToCreate.push({
          category: 'زیست‌شناسی',
          gradeLevel: 'دوازدهم',
          courseName: 'زیست دوازدهم (مفهومی + تست)',
          topic: 'پروتئین‌سازی و همانندسازی دِنا (برنامه سالانه)',
          bookSource: 'خیلی سبز جامع زیست‌شناسی',
          estimatedMinutes: 120,
          actualMinutes: 0,
          scheduledTime: '15:15',
          completed: false,
          testCount: 35,
          priority: 'high',
          dayOfWeek: day,
        });

        partsToCreate.push({
          category: 'شیمی',
          gradeLevel: 'یازدهم',
          courseName: 'شیمی (مسائل و مفاهیم)',
          topic: 'استوکیومتری و واکنش‌های شیمیایی (برنامه سالانه)',
          bookSource: 'مبتکران شیمی',
          estimatedMinutes: 105,
          actualMinutes: 0,
          scheduledTime: '17:30',
          completed: false,
          testCount: 30,
          priority: 'high',
          dayOfWeek: day,
        });

        partsToCreate.push({
          category: 'فیزیک',
          gradeLevel: 'دوازدهم',
          courseName: 'فیزیک (حرکت و دینامیک)',
          topic: 'معادلات حرکت و شتاب ثابت (برنامه سالانه)',
          bookSource: 'خیلی سبز فیزیک',
          estimatedMinutes: 90,
          actualMinutes: 0,
          scheduledTime: '19:30',
          completed: false,
          testCount: 25,
          priority: 'medium',
          dayOfWeek: day,
        });

        partsToCreate.push({
          category: 'زیست‌شناسی',
          gradeLevel: 'دوازدهم',
          courseName: '🧠 تایم مرور اختصاصی ابینگهاوس (سالانه)',
          topic: `مرور فواصل ابینگهاوس و تست‌های نشان‌دار (${day})`,
          bookSource: 'جعبه لایتنر + جزوه',
          estimatedMinutes: 60,
          actualMinutes: 0,
          scheduledTime: '21:15',
          completed: false,
          testCount: 20,
          priority: 'high',
          dayOfWeek: day,
        });
      });
    } else if (generatedResult.planType === 'weekly' && generatedResult.weeklySchedule) {
      if (onApplyWeeklySchedule) {
        onApplyWeeklySchedule(generatedResult.weeklySchedule);
      }

      Object.entries(generatedResult.weeklySchedule).forEach(([dayName, daySched]) => {
        (daySched.slots || []).forEach((slot) => {
          if (slot.activityType === 'study' || slot.activityType === 'compensation') {
            partsToCreate.push({
              category: slot.subject || 'زیست‌شناسی',
              gradeLevel: slot.gradeLevel || 'دوازدهم',
              courseName: slot.title || `${slot.subject} (${slot.gradeLevel || 'دوازدهم'})`,
              topic: slot.topic || slot.title,
              bookSource: 'کتاب درسی + کتاب تست',
              estimatedMinutes: 90,
              actualMinutes: 0,
              scheduledTime: slot.startTime || '15:15',
              completed: false,
              testCount: slot.targetTests || 30,
              priority: slot.isImportant ? 'high' : 'medium',
              dayOfWeek: dayName as DayOfWeek,
            });
          }
        });
      });
    } else if (generatedResult.planType === 'monthly' && generatedResult.monthlyPlan) {
      if (onApplyMonthlyPlan) {
        onApplyMonthlyPlan(generatedResult.monthlyPlan);
      }
      if (onApplyWeeklySchedule) {
        onApplyWeeklySchedule(WEEKLY_TEMPLATES[0].schedule);
      }

      DAYS_OF_WEEK.forEach((day) => {
        partsToCreate.push({
          category: 'زیست‌شناسی',
          gradeLevel: 'دوازدهم',
          courseName: 'زیست دوازدهم (برنامه راهبردی ماهانه)',
          topic: `جمع‌بندی و تست‌زنی مباحث ${generatedResult.monthlyPlan?.monthName || 'ماهانه'}`,
          bookSource: 'برنامه راهبردی ماهانه',
          estimatedMinutes: 110,
          actualMinutes: 0,
          scheduledTime: '15:15',
          completed: false,
          testCount: 35,
          priority: 'high',
          dayOfWeek: day,
        });

        partsToCreate.push({
          category: 'شیمی',
          gradeLevel: 'یازدهم',
          courseName: 'شیمی (برنامه راهبردی ماهانه)',
          topic: 'مسائل و آلی شیمی یازدهم',
          bookSource: 'کتاب تست شیمی',
          estimatedMinutes: 100,
          actualMinutes: 0,
          scheduledTime: '17:30',
          completed: false,
          testCount: 30,
          priority: 'high',
          dayOfWeek: day,
        });

        partsToCreate.push({
          category: 'زیست‌شناسی',
          gradeLevel: 'دوازدهم',
          courseName: '🧠 تایم مرور اختصاصی ابینگهاوس (ماهانه)',
          topic: `مرور پوششی فواصل ابینگهاوس ماه ${generatedResult.monthlyPlan?.monthName || ''}`,
          bookSource: 'جعبه لایتنر ابینگهاوس',
          estimatedMinutes: 60,
          actualMinutes: 0,
          scheduledTime: '21:15',
          completed: false,
          testCount: 20,
          priority: 'high',
          dayOfWeek: day,
        });
      });
    }

    if (generatedResult.dailyParts && generatedResult.dailyParts.length > 0) {
      generatedResult.dailyParts.forEach((dp) => {
        partsToCreate.push({
          category: dp.subject,
          gradeLevel: dp.gradeLevel,
          courseName: `${dp.subject} ${dp.gradeLevel ? `(${dp.gradeLevel})` : ''}`,
          topic: dp.topic,
          bookSource: dp.bookSource || 'کتاب تست استاندارد',
          estimatedMinutes: dp.estimatedMinutes || 90,
          actualMinutes: 0,
          scheduledTime: dp.startTime || '15:15',
          completed: false,
          testCount: dp.testCount || 30,
          priority: dp.priority || 'high',
          dayOfWeek: selectedDay || todayDay,
        });
      });
    }

    if (partsToCreate.length > 0) {
      onApplyPlanToParts(partsToCreate);
      showToast(`برنامه با موفقیت اعمال شد و ${toPersianDigits(partsToCreate.length)} پارت مطالعه در تمامی روزها لود گردید! 🚀`, 'success');
    } else {
      showToast('برنامه ذخیره گردید 🗺️', 'success');
    }

    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-md animate-fadeIn overflow-y-auto"
      dir="rtl"
    >
      <div
        className="relative w-full max-w-3xl bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl p-5 sm:p-7 space-y-5 my-auto max-h-[92vh] flex flex-col font-vazir"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4 shrink-0">
          <div className="flex items-center gap-3">
            <div
              className="w-12 h-12 rounded-2xl flex items-center justify-center text-white shadow-md"
              style={{ backgroundColor: theme.accentColor }}
            >
              <Bot className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg sm:text-xl font-black text-slate-900 dark:text-white">
                  برنامه‌ریز و مشاور ارشد هوش مصنوعی
                </h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">
                  Gemini AI
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                استراتژی سالانه تا اسفند، برنامه هفتگی هماهنگ با مدرسه و مرورهای خودکار ابینگهاوس
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 flex items-center justify-center transition-colors cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* Top Mode Selector Tabs */}
        <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-2 shrink-0">
          <button
            type="button"
            onClick={() => setActiveMode('plan')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-black transition-all flex items-center gap-2 cursor-pointer ${
              activeMode === 'plan'
                ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>تدوین و تولید برنامه (سالانه / هفتگی / روزانه)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveMode('memory')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-black transition-all flex items-center gap-2 cursor-pointer ${
              activeMode === 'memory'
                ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Brain className="w-4 h-4 text-purple-400" />
            <span>حافظه مبحثی و زنجیره مرور ({toPersianDigits(localMemories.length)})</span>
          </button>
        </div>

        {/* Scrollable Content Body */}
        <div className="overflow-y-auto space-y-4 pr-1 flex-1">
          {/* Mode 1: AI Planner */}
          {activeMode === 'plan' && (
            <>
              {/* Plan Type Selector */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                  افق زمانی برنامه‌ریزی:
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <button
                    type="button"
                    onClick={() => setPlanType('annual')}
                    className={`p-3 rounded-2xl border text-center transition-all flex flex-col items-center justify-center gap-1 cursor-pointer ${
                      planType === 'annual'
                        ? 'border-2 shadow-sm font-extrabold bg-amber-50 dark:bg-amber-950/20 text-amber-900 dark:text-amber-200'
                        : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50'
                    }`}
                    style={{
                      borderColor: planType === 'annual' ? '#f59e0b' : undefined,
                    }}
                  >
                    <Target className="w-4 h-4 text-amber-500" />
                    <span className="text-xs">🗺️ سالانه (تا اسفند)</span>
                    <span className="text-[10px] text-slate-400">بستن کل پایه + ۱۲</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPlanType('weekly')}
                    className={`p-3 rounded-2xl border text-center transition-all flex flex-col items-center justify-center gap-1 cursor-pointer ${
                      planType === 'weekly'
                        ? 'border-2 shadow-sm font-extrabold bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white'
                        : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50'
                    }`}
                    style={{
                      borderColor: planType === 'weekly' ? theme.accentColor : undefined,
                    }}
                  >
                    <Calendar className="w-4 h-4 text-emerald-500" />
                    <span className="text-xs">📅 هفتگی (۷ روزه)</span>
                    <span className="text-[10px] text-slate-400">هماهنگ با مدرسه</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPlanType('monthly')}
                    className={`p-3 rounded-2xl border text-center transition-all flex flex-col items-center justify-center gap-1 cursor-pointer ${
                      planType === 'monthly'
                        ? 'border-2 shadow-sm font-extrabold bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white'
                        : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50'
                    }`}
                    style={{
                      borderColor: planType === 'monthly' ? theme.accentColor : undefined,
                    }}
                  >
                    <Layers className="w-4 h-4 text-purple-500" />
                    <span className="text-xs">🗓️ ماهانه (۴ هفته)</span>
                    <span className="text-[10px] text-slate-400">نقشه راهبردی</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPlanType('daily')}
                    className={`p-3 rounded-2xl border text-center transition-all flex flex-col items-center justify-center gap-1 cursor-pointer ${
                      planType === 'daily'
                        ? 'border-2 shadow-sm font-extrabold bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white'
                        : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50'
                    }`}
                    style={{
                      borderColor: planType === 'daily' ? theme.accentColor : undefined,
                    }}
                  >
                    <Zap className="w-4 h-4 text-cyan-500" />
                    <span className="text-xs">⚡ پارت‌های امروز</span>
                    <span className="text-[10px] text-slate-400">روزانه و فوری</span>
                  </button>
                </div>
              </div>

              {/* School and Day Settings for Weekly/Daily */}
              {(planType === 'weekly' || planType === 'daily') && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                      <School className="w-3.5 h-3.5 text-blue-500" />
                      ساعت حضور در مدرسه:
                    </label>
                    <select
                      value={schoolHours}
                      onChange={(e) => setSchoolHours(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                    >
                      <option value="07:30 - 13:30">صبح تا ظهر (۰۷:۳۰ الی ۱۳:۳۰)</option>
                      <option value="07:30 - 14:30">تمام‌وقت مدرسه (۰۷:۳۰ الی ۱۴:۳۰)</option>
                      <option value="07:00 - 12:30">نیمه‌وقت مدرسه (۰۷:۰۰ الی ۱۲:۳۰)</option>
                      <option value="none">بدون مدرسه (فارغ‌التحصیل / روز تعطیل)</option>
                    </select>
                  </div>

                  {planType === 'daily' && (
                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                        روز هدف:
                      </label>
                      <select
                        value={selectedDay}
                        onChange={(e) => setSelectedDay(e.target.value as DayOfWeek)}
                        className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                      >
                        {DAYS_OF_WEEK.map((day) => (
                          <option key={day} value={day}>
                            {day}
                          </option>
                        ))}
                      </select>
                    </div>
                  )}
                </div>
              )}

              {/* Quick Preset Prompts */}
              <div className="space-y-1.5">
                <span className="text-[11px] font-bold text-slate-600 dark:text-slate-400 block">
                  نمونه دستورات آماده و استاندارد:
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {quickPrompts.map((qp, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => {
                        setPlanType(qp.type);
                        setUserPrompt(qp.text);
                      }}
                      className="text-right p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:border-slate-300 bg-slate-50/70 dark:bg-slate-800/40 text-xs font-medium text-slate-700 dark:text-slate-300 transition-colors flex items-start gap-2 cursor-pointer"
                    >
                      <span className="text-amber-500 font-bold shrink-0">✦</span>
                      <div className="space-y-0.5">
                        <strong className="block text-slate-900 dark:text-white">{qp.title}</strong>
                        <span className="line-clamp-2 text-[11px] text-slate-500">{qp.text}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* User Prompt Input */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                  دستور و توضیحات شما به هوش مصنوعی (اختیاری):
                </label>
                <textarea
                  value={userPrompt}
                  onChange={(e) => setUserPrompt(e.target.value)}
                  placeholder={
                    planType === 'annual'
                      ? 'مثلاً: می‌خواهم تمام درس‌های دهم و یازدهم و کل دوازدهم تا اسفند تمام شوند و در ریاضی تست‌های بیشتری کار کنم...'
                      : 'شرایط روز، امتحانات پیش‌رو، مباحث مورد نظرتان را بنویسید...'
                  }
                  rows={2}
                  className="w-full px-3.5 py-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                />
              </div>

              {/* Generate Trigger Button */}
              <button
                type="button"
                onClick={handleGenerate}
                disabled={isLoading}
                className={`w-full py-3.5 rounded-2xl ${theme.primaryBtn} text-white font-extrabold text-sm sm:text-base flex items-center justify-center gap-2 shadow-lg active:scale-98 transition-all cursor-pointer ${
                  isLoading ? 'opacity-80 cursor-wait' : ''
                }`}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    <span>در حال تدوین استراتژی علمی با Gemini AI...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-5 h-5 text-amber-300" />
                    <span>
                      تولید{' '}
                      {planType === 'annual'
                        ? 'استراتژی سالانه تا اسفند'
                        : planType === 'weekly'
                        ? 'برنامه هفتگی با مدرسه'
                        : planType === 'monthly'
                        ? 'نقشه ماهانه'
                        : 'برنامه امروز'}
                    </span>
                  </>
                )}
              </button>

              {/* Generated Result Preview */}
              {generatedResult && (
                <div className="mt-4 p-4.5 rounded-2xl bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-800/40 space-y-3.5 animate-fadeIn">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-emerald-900 dark:text-emerald-200 flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      پیش‌نمایش برنامه تولیدشده هوش مصنوعی:
                    </span>
                    <span className="text-[11px] font-bold text-emerald-700 dark:text-emerald-300">
                      مجموع: {toPersianDigits(generatedResult.totalHours)} ساعت مطالعه | {toPersianDigits(generatedResult.totalTests)} تست
                    </span>
                  </div>

                  <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed bg-white dark:bg-slate-900 p-3 rounded-xl border border-emerald-100 dark:border-emerald-900/30">
                    {generatedResult.summary}
                  </p>

                  {generatedResult.advice && (
                    <div className="text-xs text-amber-900 dark:text-amber-200 bg-amber-50/80 dark:bg-amber-950/30 p-2.5 rounded-xl border border-amber-200 dark:border-amber-800/30 flex items-start gap-2">
                      <Sparkles className="w-3.5 h-3.5 text-amber-500 shrink-0 mt-0.5" />
                      <span>{generatedResult.advice}</span>
                    </div>
                  )}

                  {/* Annual Roadmap Preview */}
                  {generatedResult.planType === 'annual' && generatedResult.annualPlan && (
                    <div className="space-y-2">
                      <span className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
                        فازهای استراتژی سالانه (اتمام ۱۰۰٪ مباحث تا ۲۹ اسفند):
                      </span>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-56 overflow-y-auto">
                        {generatedResult.annualPlan.months.map((m) => (
                          <div
                            key={m.id}
                            className={`p-3 rounded-2xl border ${
                              m.isMilestoneEsfand
                                ? 'bg-amber-50/90 dark:bg-amber-950/30 border-amber-300 dark:border-amber-700'
                                : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
                            }`}
                          >
                            <div className="flex items-center justify-between">
                              <strong className="text-xs font-black text-slate-900 dark:text-white">
                                {m.monthName} ({m.season})
                              </strong>
                              {m.isMilestoneEsfand && (
                                <span className="text-[10px] font-black text-amber-600 bg-amber-100 dark:bg-amber-900/60 px-2 py-0.5 rounded-md">
                                  🎯 اتمام ۱۰۰٪ دروس
                                </span>
                              )}
                            </div>
                            <p className="text-[11px] text-slate-600 dark:text-slate-400 mt-1 line-clamp-2">
                              {m.phaseTitle} — {m.targetGoal}
                            </p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Weekly Schedule Preview */}
                  {generatedResult.planType === 'weekly' && generatedResult.weeklySchedule && (
                    <div className="space-y-2">
                      <span className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
                        جدول برنامه ۷ روزه هفته:
                      </span>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-56 overflow-y-auto">
                        {DAYS_OF_WEEK.map((day) => {
                          const dSched = generatedResult.weeklySchedule?.[day];
                          if (!dSched) return null;
                          const studySlots = dSched.slots.filter((s) => s.activityType === 'study');

                          return (
                            <div
                              key={day}
                              className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700"
                            >
                              <div className="flex items-center justify-between">
                                <span className="text-xs font-black text-slate-900 dark:text-white">
                                  {day} {dSched.dayType === 'school' ? '🏫 مدرسه' : '🏖️ تعطیل'}
                                </span>
                                <span className="text-[10px] font-bold text-slate-500">
                                  {toPersianDigits(studySlots.length)} پارت
                                </span>
                              </div>
                              <p className="text-[11px] text-slate-500 mt-1 line-clamp-1">
                                {dSched.titleNotes || studySlots.map((s) => s.subject).join('، ')}
                              </p>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* Monthly Roadmap Preview */}
                  {generatedResult.planType === 'monthly' && generatedResult.monthlyPlan && (
                    <div className="space-y-2">
                      <span className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
                        عناوین ۴ هفته نقشه راهبردی ماهانه:
                      </span>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {generatedResult.monthlyPlan.weeks.map((w) => (
                          <div
                            key={w.weekNumber}
                            className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                          >
                            <span className="text-xs font-black text-slate-900 dark:text-white block">
                              {w.title}
                            </span>
                            <p className="text-[11px] text-slate-500 mt-0.5">{w.focusGoal}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </>
          )}

          {/* Mode 2: Topic Memory & Leitner Spaced Repetition */}
          {activeMode === 'memory' && (
            <div className="space-y-4">
              {/* Form to Add Studied Topic */}
              <form
                onSubmit={handleAddNewTopicMemory}
                className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-3"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-slate-900 dark:text-white flex items-center gap-1.5">
                    <Plus className="w-4 h-4 text-emerald-600" />
                    ثبت مبحث جدید در حافظه هوشمند برای تنظیم خودکار مرورها
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-400 mb-1">
                      درس اختصاصی:
                    </label>
                    <select
                      value={newTopicSubject}
                      onChange={(e) => setNewTopicSubject(e.target.value as TajrobiSubject)}
                      className="w-full px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                    >
                      {TAJROBI_SUBJECTS_LIST.map((s) => (
                        <option key={s} value={s}>
                          {s}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-400 mb-1">
                      پایه تحصیلی:
                    </label>
                    <select
                      value={newTopicGrade}
                      onChange={(e) => setNewTopicGrade(e.target.value as GradeLevel)}
                      className="w-full px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                    >
                      <option value="دوازدهم">دوازدهم</option>
                      <option value="یازدهم">یازدهم</option>
                      <option value="دهم">دهم</option>
                      <option value="جامع">جامع</option>
                      <option value="عمومی و نهایی">عمومی و نهایی</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-400 mb-1">
                      عنوان مبحث یا فصل:
                    </label>
                    <input
                      type="text"
                      value={newTopicName}
                      onChange={(e) => setNewTopicName(e.target.value)}
                      placeholder="مثال: رونویسی و ترجمه ژنتیک"
                      className="w-full px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                      required
                    />
                  </div>
                </div>

                <div className="flex justify-end pt-1">
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black cursor-pointer shadow-xs"
                  >
                    + افزودن به حافظه مبحثی و تنظیم مرورها
                  </button>
                </div>
              </form>

              {/* Memory List with Ebbinghaus Levels */}
              <div className="space-y-2">
                <span className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
                  مباحث ثبت‌شده و جدول مرورهای ابینگهاوس ({toPersianDigits(localMemories.length)} مبحث):
                </span>
                {localMemories.map((mem) => {
                  const subjectInfo = TAJROBI_SUBJECTS_INFO[mem.subject];
                  const currentInterval = EBBINGHAUS_INTERVALS[mem.reviewLevel - 1] || EBBINGHAUS_INTERVALS[0];

                  return (
                    <div
                      key={mem.id}
                      className="p-3.5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-2xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-2.5">
                        <span
                          className="w-3 h-8 rounded-full"
                          style={{ backgroundColor: subjectInfo?.color || '#059669' }}
                        />
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="font-extrabold text-xs text-slate-900 dark:text-white">
                              {mem.subject}
                            </span>
                            <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
                              پایه {mem.gradeLevel}
                            </span>
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300">
                              {currentInterval.badge}
                            </span>
                          </div>
                          <h4 className="font-bold text-xs text-slate-800 dark:text-slate-200 mt-0.5">
                            {mem.topic}
                          </h4>
                        </div>
                      </div>

                      <div className="flex items-center gap-3 self-end sm:self-center text-xs font-bold tabular-nums">
                        <div className="text-left">
                          <span className="text-[10px] text-slate-400 block font-normal">موعد مرور بعدی</span>
                          <span className="text-emerald-600 dark:text-emerald-400 font-extrabold">
                            {mem.nextReviewJalali || mem.nextReviewDate}
                          </span>
                        </div>
                        <div className="text-left">
                          <span className="text-[10px] text-slate-400 block font-normal">تثبیت</span>
                          <span className="text-purple-600 dark:text-purple-400 font-extrabold">
                            {toPersianDigits(mem.masteryScore)}٪
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer Actions */}
        <div className="flex items-center justify-between gap-2 pt-3 mt-3 border-t border-slate-100 dark:border-slate-800 shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-xs font-bold cursor-pointer"
          >
            بستن
          </button>

          {activeMode === 'plan' && generatedResult && (
            <button
              type="button"
              onClick={handleApplyPlan}
              className={`px-5 py-2.5 rounded-xl ${theme.primaryBtn} text-xs font-black flex items-center gap-2 shadow-md cursor-pointer`}
            >
              <Zap className="w-4 h-4 fill-current" />
              <span>
                {generatedResult.planType === 'annual'
                  ? '🗺️ اعمال و ذخیره استراتژی سالانه تا اسفند'
                  : generatedResult.planType === 'weekly'
                  ? '⚡ اعمال در کل جدول ۷ روزه برنامه هفتگی'
                  : generatedResult.planType === 'monthly'
                  ? '🗺️ ذخیره نقشه راهبردی ماهانه'
                  : '⚡ اعمال مستقیم در پارت‌های امروز و شروع'}
              </span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
