import React, { useEffect, useState } from 'react';
import { ExamCountdownItem } from '../types';
import { calculateCountdownDetails, toFaDigits } from '../utils/tajrobiData';
import {
  Calendar,
  Clock,
  Plus,
  Trash2,
  Sparkles,
  Award,
  AlertCircle,
} from 'lucide-react';

interface ExamsCountdownViewProps {
  exams: ExamCountdownItem[];
  onAddExam: (exam: ExamCountdownItem) => void;
  onDeleteExam: (id: string) => void;
}

export const ExamsCountdownView: React.FC<ExamsCountdownViewProps> = ({
  exams,
  onAddExam,
  onDeleteExam,
}) => {
  // Live ticker that updates every second
  const [, setTick] = useState(0);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDate, setNewDate] = useState('2027-04-24T08:00');
  const [newJalali, setNewJalali] = useState('اردیبهشت ۱۴۰۶');
  const [newType, setNewType] = useState<'konkur' | 'final_exam' | 'mock_exam'>('konkur');
  const [newDescription, setNewDescription] = useState('');

  useEffect(() => {
    const timer = setInterval(() => {
      setTick((t) => t + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    onAddExam({
      id: 'exam-' + Date.now(),
      title: newTitle.trim(),
      targetDate: newDate,
      targetJalali: newJalali.trim() || 'تاریخ تعیین‌شده',
      type: newType,
      description: newDescription.trim(),
      color: newType === 'konkur' ? '#0f766e' : newType === 'final_exam' ? '#0284c7' : '#d97706',
    });

    setNewTitle('');
    setShowAddModal(false);
  };

  return (
    <div className="space-y-6">
      {/* Header and Add Exam Button */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <h2 className="text-lg font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              <Calendar className="w-5 h-5 text-teal-600" />
              <span>روزشمار معکوس کنکور سراسری، امتحانات نهایی و آزمون‌ها</span>
            </h2>
            <p className="text-xs text-slate-600 dark:text-slate-400">
              شمارش دقیق روز، ساعت، دقیقه و ثانیه تا موعد کنکور تجربی نوبت اول و دوم و امتحانات نهایی
            </p>
          </div>

          <button
            type="button"
            onClick={() => setShowAddModal(true)}
            className="px-4 py-2.5 rounded-2xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-extrabold flex items-center gap-1.5 transition cursor-pointer self-start sm:self-auto shadow-xs"
          >
            <Plus className="w-4 h-4" />
            <span>افزودن تاریخ آزمون جدید</span>
          </button>
        </div>
      </div>

      {/* Countdown Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {exams.map((exam) => {
          const { days, hours, minutes, seconds, isPast } = calculateCountdownDetails(exam.targetDate);

          const isKonkur = exam.type === 'konkur';
          const isFinal = exam.type === 'final_exam';

          return (
            <div
              key={exam.id}
              className={`bg-white dark:bg-slate-900 rounded-3xl border p-6 shadow-xs relative overflow-hidden transition ${
                isKonkur
                  ? 'border-teal-300 dark:border-teal-700/80 bg-teal-50/20 dark:bg-teal-950/20'
                  : isFinal
                  ? 'border-sky-300 dark:border-sky-700/80 bg-sky-50/20 dark:bg-sky-950/20'
                  : 'border-slate-200 dark:border-slate-800'
              }`}
            >
              {/* Type Badge */}
              <div className="flex items-center justify-between mb-3">
                <span
                  className={`px-3 py-1 rounded-xl text-xs font-black ${
                    isKonkur
                      ? 'bg-teal-100 text-teal-800 dark:bg-teal-900/60 dark:text-teal-300'
                      : isFinal
                      ? 'bg-sky-100 text-sky-800 dark:bg-sky-900/60 dark:text-sky-300'
                      : 'bg-amber-100 text-amber-800 dark:bg-amber-900/60 dark:text-amber-300'
                  }`}
                >
                  {isKonkur
                    ? '🎯 کنکور سراسری تجربی'
                    : isFinal
                    ? '📚 امتحانات نهایی (سوابق ۵۰-۶۰٪)'
                    : '📝 آزمون آزمایشی'}
                </span>

                <button
                  type="button"
                  onClick={() => onDeleteExam(exam.id)}
                  className="text-slate-400 hover:text-rose-500 transition cursor-pointer p-1"
                  title="حذف"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

              <h3 className="text-base font-extrabold text-slate-900 dark:text-white leading-snug">
                {exam.title}
              </h3>

              <div className="text-xs text-slate-500 dark:text-slate-400 font-bold mt-1">
                موعد برگزاری: {exam.targetJalali}
              </div>

              {/* Digital Countdown Box */}
              {isPast ? (
                <div className="my-5 p-4 rounded-2xl bg-slate-100 dark:bg-slate-800 text-center font-bold text-xs text-slate-500">
                  این آزمون برگزار شده است.
                </div>
              ) : (
                <div className="my-5 grid grid-cols-4 gap-2 text-center">
                  <div className="p-3 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs">
                    <div className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tabular-nums">
                      {toFaDigits(days)}
                    </div>
                    <div className="text-[10px] text-slate-500 font-bold mt-0.5">روز</div>
                  </div>

                  <div className="p-3 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs">
                    <div className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tabular-nums">
                      {toFaDigits(hours)}
                    </div>
                    <div className="text-[10px] text-slate-500 font-bold mt-0.5">ساعت</div>
                  </div>

                  <div className="p-3 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs">
                    <div className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tabular-nums">
                      {toFaDigits(minutes)}
                    </div>
                    <div className="text-[10px] text-slate-500 font-bold mt-0.5">دقیقه</div>
                  </div>

                  <div className="p-3 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs ring-1 ring-teal-500/30">
                    <div className="text-2xl sm:text-3xl font-black text-teal-600 dark:text-teal-400 tabular-nums">
                      {toFaDigits(seconds)}
                    </div>
                    <div className="text-[10px] text-teal-600 dark:text-teal-400 font-bold mt-0.5">ثانیه</div>
                  </div>
                </div>
              )}

              {exam.description && (
                <p className="text-xs text-slate-600 dark:text-slate-400 bg-white/70 dark:bg-slate-800/60 p-3 rounded-2xl border border-slate-100 dark:border-slate-800 leading-relaxed">
                  💡 {exam.description}
                </p>
              )}
            </div>
          );
        })}
      </div>

      {/* Add Exam Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 max-w-md w-full p-6 space-y-4 shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                ➕ افزودن آزمون یا امتحان جدید
              </h3>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="text-xs text-slate-400 hover:text-slate-700"
              >
                بستن ✕
              </button>
            </div>

            <form onSubmit={handleAddSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">
                  عنوان آزمون یا امتحان:
                </label>
                <input
                  type="text"
                  required
                  placeholder="مثلاً: آزمون قلم‌چی یا امتحان نهایی زیست‌شناسی"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">
                  نوع رویداد:
                </label>
                <select
                  value={newType}
                  onChange={(e) => setNewType(e.target.value as 'konkur' | 'final_exam' | 'mock_exam')}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-bold"
                >
                  <option value="konkur">کنکور سراسری</option>
                  <option value="final_exam">امتحان نهایی (معدل دوازدهم)</option>
                  <option value="mock_exam">آزمون آزمایشی (سنجش / ماز / قلم‌چی)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">
                  تاریخ و ساعت برگزاری:
                </label>
                <input
                  type="datetime-local"
                  required
                  value={newDate}
                  onChange={(e) => setNewDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs tabular-nums"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">
                  توضیح تاریخ شمسی (جهت نمایش):
                </label>
                <input
                  type="text"
                  placeholder="مثلاً: ۱۵ اسفند ۱۴۰۵"
                  value={newJalali}
                  onChange={(e) => setNewJalali(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">
                  نکته یا هدف ترازی:
                </label>
                <input
                  type="text"
                  placeholder="مثلاً: هدف درصد زیست بالای ۷۰ و شیمی بالای ۶۰"
                  value={newDescription}
                  onChange={(e) => setNewDescription(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 text-xs font-bold cursor-pointer"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-extrabold cursor-pointer"
                >
                  ثبت روزشمار
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
