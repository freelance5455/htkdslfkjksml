import React, { useState } from 'react';
import { GradeLevel, TajrobiSubject, ThemeConfig, TopicMemoryItem } from '../types';
import {
  DAYS_OF_WEEK,
  EBBINGHAUS_INTERVALS,
  GRADE_LEVELS,
  GRADE_META,
  TAJROBI_SUBJECTS_INFO,
  TAJROBI_SUBJECTS_LIST,
  calculateDaysUntilExam,
  detectGradeFromText,
  formatISOToJalaliShort,
  getOffsetDateISO,
  getTodayISO,
  getTodayJalali,
  toPersianDigits,
} from '../utils/tajrobiData';
import { calculateNextEbbinghausDate } from '../utils/aiStudyPlanner';
import {
  Brain,
  Sparkles,
  Plus,
  Trash2,
  CheckCircle2,
  Clock,
  RotateCcw,
  Check,
  TrendingUp,
  AlertCircle,
  HelpCircle,
  ArrowRight,
  Filter,
} from 'lucide-react';

interface TopicMemoryViewProps {
  topicMemories: TopicMemoryItem[];
  theme: ThemeConfig;
  onUpdateMemories: (memories: TopicMemoryItem[]) => void;
  onStartReviewInTimer: (subject: TajrobiSubject, topic: string) => void;
  showToast: (message: string, type?: 'success' | 'warning' | 'info') => void;
}

export const TopicMemoryView: React.FC<TopicMemoryViewProps> = ({
  topicMemories,
  theme,
  onUpdateMemories,
  onStartReviewInTimer,
  showToast,
}) => {
  const todayISO = getTodayISO();

  // Filters
  const [selectedSubject, setSelectedSubject] = useState<string>('all');
  const [selectedLevel, setSelectedLevel] = useState<number | 'all'>('all');
  const [showAddForm, setShowAddForm] = useState<boolean>(false);

  // New Memory Form
  const [newSubject, setNewSubject] = useState<TajrobiSubject>('زیست‌شناسی');
  const [newGrade, setNewGrade] = useState<GradeLevel>('دوازدهم');
  const [newTopic, setNewTopic] = useState<string>('');
  const [newInitialLevel, setNewInitialLevel] = useState<number>(1);
  const [newNotes, setNewNotes] = useState<string>('');

  // Add new topic
  const handleAddTopic = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTopic.trim()) return;

    const { nextDate } = calculateNextEbbinghausDate(newInitialLevel);
    const newMem: TopicMemoryItem = {
      id: 'mem-' + Date.now(),
      subject: newSubject,
      gradeLevel: newGrade,
      topic: newTopic.trim(),
      firstStudiedDate: todayISO,
      lastStudiedDate: todayISO,
      reviewLevel: newInitialLevel,
      nextReviewDate: nextDate,
      nextReviewJalali: newInitialLevel === 1 ? 'فردا' : `${toPersianDigits(newInitialLevel * 3)} روز بعد`,
      masteryScore: newInitialLevel === 1 ? 50 : newInitialLevel * 18,
      totalTestsDone: 30,
      totalStudyMinutes: 90,
      notes: newNotes.trim() || undefined,
      isOverdue: false,
    };

    onUpdateMemories([newMem, ...topicMemories]);
    setShowAddForm(false);
    setNewTopic('');
    setNewNotes('');
    showToast(`مبحث «${newMem.topic}» با موفقیت در حافظه مبحثی ذخیره شد ✨`, 'success');
  };

  // Advance level after review completion
  const handleAdvanceLevel = (id: string) => {
    const updated = topicMemories.map((m) => {
      if (m.id === id) {
        const nextLvl = Math.min(5, m.reviewLevel + 1);
        const { nextDate } = calculateNextEbbinghausDate(nextLvl);
        return {
          ...m,
          reviewLevel: nextLvl,
          lastStudiedDate: todayISO,
          nextReviewDate: nextDate,
          nextReviewJalali: nextLvl === 5 ? 'تثبیت دائم (ماهانه)' : `${toPersianDigits(nextLvl * 4)} روز بعد`,
          masteryScore: Math.min(100, m.masteryScore + 15),
        };
      }
      return m;
    });

    onUpdateMemories(updated);
    showToast('مرور ثبت شد و مبحث به سطح بعدی ابینگهاوس ارتقا یافت! 🚀', 'success');
  };

  // Delete
  const handleDelete = (id: string) => {
    onUpdateMemories(topicMemories.filter((m) => m.id !== id));
    showToast('مبحث از حافظه حذف شد.', 'info');
  };

  // Filtered list
  const filteredMemories = topicMemories.filter((m) => {
    if (selectedSubject !== 'all' && m.subject !== selectedSubject) return false;
    if (selectedLevel !== 'all' && m.reviewLevel !== selectedLevel) return false;
    return true;
  });

  const dueReviewsCount = topicMemories.filter((m) => m.nextReviewDate <= todayISO).length;
  const masteredCount = topicMemories.filter((m) => m.reviewLevel === 5).length;

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Banner */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 mb-2">
            <Brain className="w-3.5 h-3.5 text-emerald-500" />
            <span>سامانه حافظه مبحثی و منحنی ابینگهاوس (Spaced Repetition)</span>
          </div>
          <h2 className="text-lg sm:text-xl font-black text-slate-900 dark:text-white">
            بانک حافظه مبحثی و مرورهای علمی کنکور
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-2xl leading-relaxed">
            مباحثی که مطالعه کرده‌اید را اینجا ثبت کنید تا هوش مصنوعی طبق فواصل ۱ روز، ۳ روز، ۱ هفته، ۲ هفته و ۱ ماه بعد، به صورت خودکار در برنامه‌های هفتگی و روزانه شما مرور بگذارد.
          </p>
        </div>

        <button
          type="button"
          onClick={() => setShowAddForm(!showAddForm)}
          className={`px-5 py-2.5 rounded-2xl ${theme.primaryBtn} text-xs font-black flex items-center justify-center gap-2 transition cursor-pointer shadow-xs`}
        >
          <Plus className="w-4 h-4" />
          <span>{showAddForm ? 'بستن فرم' : '+ ثبت مبحث جدید در حافظه'}</span>
        </button>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-2xs">
          <span className="text-xs font-bold text-slate-500">کل مباحث در حافظه</span>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="text-2xl font-black text-slate-900 dark:text-white tabular-nums">
              {toPersianDigits(topicMemories.length)}
            </span>
            <span className="text-xs text-slate-400">مبحث</span>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-2xs">
          <span className="text-xs font-bold text-slate-500">موعد مرور امروز</span>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="text-2xl font-black text-rose-600 dark:text-rose-400 tabular-nums">
              {toPersianDigits(dueReviewsCount)}
            </span>
            <span className="text-xs text-rose-500">مرور لازم 🔥</span>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-2xs">
          <span className="text-xs font-bold text-slate-500">تثبیت دائم (سطح ۵)</span>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="text-2xl font-black text-emerald-600 dark:text-emerald-400 tabular-nums">
              {toPersianDigits(masteredCount)}
            </span>
            <span className="text-xs text-emerald-500">مبحث مسلط ✨</span>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-2xs">
          <span className="text-xs font-bold text-slate-500">روش علمی</span>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="text-base font-black text-purple-600 dark:text-purple-400">
              ۵ مرحله‌ای
            </span>
            <span className="text-[10px] text-slate-400">ابینگهاوس</span>
          </div>
        </div>
      </div>

      {/* Add Form */}
      {showAddForm && (
        <form
          onSubmit={handleAddTopic}
          className="bg-white dark:bg-slate-900 rounded-3xl border-2 border-emerald-500/50 p-6 shadow-md space-y-4 animate-fade-in"
        >
          <h3 className="text-sm font-black text-slate-900 dark:text-white pb-2 border-b border-slate-100 dark:border-slate-800">
            ثبت مبحث جدید در حافظه هوشمند برای تنظیم خودکار مرورهای فاصله‌دار
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">
                درس:
              </label>
              <select
                value={newSubject}
                onChange={(e) => setNewSubject(e.target.value as TajrobiSubject)}
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
              >
                {TAJROBI_SUBJECTS_LIST.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">
                پایه تحصیلی:
              </label>
              <select
                value={newGrade}
                onChange={(e) => setNewGrade(e.target.value as GradeLevel)}
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
              >
                {GRADE_LEVELS.map((g) => (
                  <option key={g} value={g}>
                    پایه {g}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">
                مرحله اولیه مرور:
              </label>
              <select
                value={newInitialLevel}
                onChange={(e) => setNewInitialLevel(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
              >
                {EBBINGHAUS_INTERVALS.map((int) => (
                  <option key={int.level} value={int.level}>
                    {int.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">
              عنوان دقیق مبحث و فصل:
            </label>
            <input
              type="text"
              value={newTopic}
              onChange={(e) => setNewTopic(e.target.value)}
              placeholder="مثال: فصل ۲ زیست دوازدهم (رونویسی و پروتئین‌سازی)"
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-slate-100 placeholder-slate-400 font-bold"
              required
            />
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-xs font-bold cursor-pointer"
            >
              انصراف
            </button>
            <button
              type="submit"
              className={`px-5 py-2 rounded-xl ${theme.primaryBtn} text-xs font-black cursor-pointer`}
            >
              ثبت در حافظه مبحثی
            </button>
          </div>
        </form>
      )}

      {/* Filter Bar */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-2.5">
          <span className="font-extrabold text-slate-600 dark:text-slate-400 flex items-center gap-1">
            <Filter className="w-3.5 h-3.5" /> فیلتر درس:
          </span>
          <select
            value={selectedSubject}
            onChange={(e) => setSelectedSubject(e.target.value)}
            className="px-2.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-bold"
          >
            <option value="all">تمام دروس</option>
            {TAJROBI_SUBJECTS_LIST.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
        </div>

        <div className="text-slate-500 font-bold tabular-nums">
          نمایش {toPersianDigits(filteredMemories.length)} از {toPersianDigits(topicMemories.length)} مبحث
        </div>
      </div>

      {/* Topics List */}
      <div className="space-y-3">
        {filteredMemories.map((mem) => {
          const subjectInfo = TAJROBI_SUBJECTS_INFO[mem.subject];
          const isDue = mem.nextReviewDate <= todayISO;
          const currentInterval = EBBINGHAUS_INTERVALS[mem.reviewLevel - 1] || EBBINGHAUS_INTERVALS[0];

          return (
            <div
              key={mem.id}
              className={`bg-white dark:bg-slate-900 rounded-2xl p-4 sm:p-5 border transition flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-2xs ${
                isDue
                  ? 'border-2 border-rose-500 bg-rose-50/20 dark:bg-rose-950/10'
                  : 'border-slate-200 dark:border-slate-800'
              }`}
            >
              <div className="flex items-start sm:items-center gap-3 w-full sm:w-auto">
                <div
                  className="w-10 h-10 rounded-2xl flex items-center justify-center text-white text-xs font-bold shrink-0 shadow-xs"
                  style={{ backgroundColor: subjectInfo?.color || '#059669' }}
                >
                  {mem.subject.slice(0, 3)}
                </div>

                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-extrabold text-sm text-slate-900 dark:text-white">
                      {mem.topic}
                    </span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold">
                      پایه {mem.gradeLevel}
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300">
                      {currentInterval.badge} ({currentInterval.days} روزه)
                    </span>
                    {isDue && (
                      <span className="text-[10px] font-black px-2 py-0.5 rounded bg-rose-500 text-white animate-pulse">
                        🔥 موعد مرور امروز!
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-3 text-xs text-slate-500 dark:text-slate-400 mt-1">
                    <span>موعد مرور بعدی: <strong className="text-slate-800 dark:text-slate-200">{mem.nextReviewJalali || mem.nextReviewDate}</strong></span>
                    <span>·</span>
                    <span>میزان تسلط و تثبیت: <strong className="text-emerald-600 dark:text-emerald-400">{toPersianDigits(mem.masteryScore)}٪</strong></span>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                <button
                  type="button"
                  onClick={() => onStartReviewInTimer(mem.subject, `مرور ابینگهاوس: ${mem.topic}`)}
                  className="px-3.5 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 hover:bg-emerald-100 text-emerald-700 dark:text-emerald-300 text-xs font-bold flex items-center gap-1 transition cursor-pointer border border-emerald-200 dark:border-emerald-800"
                >
                  <span>▶️ شروع مرور در تایمر</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleAdvanceLevel(mem.id)}
                  className="px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold flex items-center gap-1 transition cursor-pointer"
                  title="تایید مرور و ارتقا به سطح بعدی"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>تکمیل مرور ✓</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleDelete(mem.id)}
                  className="p-1.5 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/50 transition cursor-pointer"
                  title="حذف از حافظه"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
