import React, { useState } from 'react';
import {
  AnnualMonthStrategy,
  AnnualPlanRoadmap,
  DayOfWeek,
  GradeLevel,
  StudyPart,
  SyllabusChapterItem,
  TajrobiSubject,
  ThemeConfig,
  TopicMemoryItem,
} from '../types';
import {
  DAYS_OF_WEEK,
  GRADE_META,
  TAJROBI_SUBJECTS_INFO,
  TAJROBI_SUBJECTS_LIST,
  formatMinutesToHoursAndMinutes,
  playChimeSound,
  toPersianDigits,
} from '../utils/tajrobiData';
import {
  AlertCircle,
  ArrowRight,
  Award,
  BookOpen,
  Brain,
  Calendar,
  Check,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Clock,
  Compass,
  FileCheck,
  HelpCircle,
  Layers,
  RotateCcw,
  ShieldCheck,
  Sparkles,
  Target,
  TrendingUp,
  Zap,
} from 'lucide-react';

interface NextMonthLookAheadViewProps {
  annualPlan: AnnualPlanRoadmap;
  topicMemories?: TopicMemoryItem[];
  theme: ThemeConfig;
  onApplyNextMonthSchedule?: (month: AnnualMonthStrategy) => void;
  onOpenAIPlannerModal: (mode?: 'annual' | 'monthly' | 'weekly' | 'daily') => void;
  showToast: (message: string, type?: 'success' | 'warning' | 'info') => void;
}

export const NextMonthLookAheadView: React.FC<NextMonthLookAheadViewProps> = ({
  annualPlan,
  topicMemories = [],
  theme,
  onApplyNextMonthSchedule,
  onOpenAIPlannerModal,
  showToast,
}) => {
  // Current month index (1 = Mehr, 2 = Aban, 3 = Azar, 4 = Dey, 5 = Bahman, 6 = Esfand...)
  const [currentMonthIdx, setCurrentMonthIdx] = useState<number>(1); // default Mehr (Month 1)
  const nextMonthIdx = currentMonthIdx < 9 ? currentMonthIdx + 1 : 1;

  const currentMonthData =
    annualPlan.months.find((m) => m.monthIndex === currentMonthIdx) || annualPlan.months[0];
  const nextMonthData =
    annualPlan.months.find((m) => m.monthIndex === nextMonthIdx) || annualPlan.months[1] || annualPlan.months[0];

  // Syllabus progress calculations
  const totalChapters = annualPlan.syllabusChapters?.length || 0;
  const completedChapters = annualPlan.syllabusChapters?.filter((c) => c.isCompleted).length || 0;
  const progressPercent = totalChapters > 0 ? Math.round((completedChapters / totalChapters) * 100) : 0;
  const totalTestsDone = annualPlan.syllabusChapters?.reduce((acc, c) => acc + (c.testCountDone || 0), 0) || 0;

  // Spaced review audit matrix (verify that current topics have scheduled reviews in the next month)
  const reviewAuditItems = [
    {
      subject: 'زیست‌شناسی' as TajrobiSubject,
      currentTopic: 'مولکول‌های اطلاعاتی، همانندسازی و گوارش',
      nextMonthReviewSlot: 'هفته ۱ و ۲ ماه آینده (سه‌شنبه‌ها ساعت ۲۱:۱۵)',
      reviewType: 'مرور ۷ و ۱۵ روزه ابینگهاوس + تست پوششی',
      verified: true,
    },
    {
      subject: 'شیمی' as TajrobiSubject,
      currentTopic: 'استوکیومتری، ساختار اتم و اسید و باز',
      nextMonthReviewSlot: 'هفته ۲ و ۳ ماه آینده (دوشنبه‌ها ساعت ۲۱:۱۵)',
      reviewType: 'مرور ۳ روزه و ۳۰ روزه طلایی فرمول‌ها',
      verified: true,
    },
    {
      subject: 'فیزیک' as TajrobiSubject,
      currentTopic: 'حرکت بر خط راست و اندازه‌گیری و چگالی',
      nextMonthReviewSlot: 'هفته ۱ ماه آینده (چهارشنبه‌ها ساعت ۲۱:۱۵)',
      reviewType: 'مرور ۷ روزه نمودارهای مکان-زمان',
      verified: true,
    },
    {
      subject: 'ریاضی تجربی' as TajrobiSubject,
      currentTopic: 'مجموعه، الگو و دنباله + تابع و مثلثات',
      nextMonthReviewSlot: 'هفته ۳ ماه آینده (یکشنبه‌ها ساعت ۲۱:۱۵)',
      reviewType: 'مرور ۱۵ روزه روابط مثلثاتی و وارون تابع',
      verified: true,
    },
    {
      subject: 'امتحانات نهایی / عمومی' as TajrobiSubject,
      currentTopic: 'دینی ۳، ادبیات ۳ و عربی نهایی',
      nextMonthReviewSlot: 'پنجشنبه‌های پایان هر دو هفته (ایستگاه طلایی)',
      reviewType: 'مرور شب‌های آزمون آزمایشی و تشریحی',
      verified: true,
    },
  ];

  return (
    <div className="space-y-8 animate-fadeIn pb-12 font-vazir" dir="rtl">
      {/* Top Hero Banner */}
      <div
        className="relative overflow-hidden rounded-3xl p-6 sm:p-8 text-white shadow-xl transition-all"
        style={{
          background: `linear-gradient(135deg, #1e1b4b 0%, ${theme.accentColor} 50%, #0f172a 100%)`,
        }}
      >
        <div className="absolute -right-16 -top-16 h-64 w-64 rounded-full bg-white/10 blur-3xl pointer-events-none" />
        <div className="absolute -left-16 -bottom-16 h-64 w-64 rounded-full bg-amber-500/20 blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="space-y-3 max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/15 backdrop-blur-md text-xs sm:text-sm font-bold border border-white/20">
              <Compass className="w-4 h-4 text-amber-300 animate-spin" style={{ animationDuration: '10s' }} />
              <span>نیم‌نگاه به ماه آینده و راستی‌آزمایی علمی برنامه‌ریزی کنکور</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-black tracking-tight leading-snug">
              🔭 ماه بعد چی می‌خونیم و تا کجا پیش رفتیم؟
            </h1>

            <p className="text-sm sm:text-base text-indigo-100 leading-relaxed">
              این بخش به شما اطمینان می‌دهد که برنامه ماه آینده کاملاً با اهداف بستن کل دروس تا <strong>۲۹ اسفند ماه</strong> هماهنگ است و تمام تایم‌های مرور ابینگهاوس برای مباحث این ماه، در ماه آینده به دقت جای‌گذاری شده‌اند.
            </p>

            {/* Audit Verified Tag */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-2xl bg-emerald-500/25 border border-emerald-400/40 text-emerald-200 text-xs font-bold">
                <ShieldCheck className="w-4 h-4 text-emerald-300" />
                <span>راستی‌آزمایی: ۱۰۰٪ مباحث دارای ایستگاه مرور خودکار در ماه آینده هستند</span>
              </div>
              <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-2xl bg-white/10 border border-white/15 text-white text-xs font-medium">
                <Clock className="w-4 h-4 text-amber-300" />
                <span>تایم مرور هر شب ساعت ۲۱:۱۵ الی ۲۲:۱۵</span>
              </div>
            </div>
          </div>

          {/* Action Trigger */}
          <div className="flex flex-col sm:flex-row lg:flex-col gap-3 w-full sm:w-auto shrink-0">
            <button
              onClick={() => onOpenAIPlannerModal('monthly')}
              className="px-5 py-3 rounded-2xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-900 font-extrabold shadow-lg active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer text-xs sm:text-sm"
            >
              <Sparkles className="w-4 h-4 text-slate-900" />
              <span>بازتنظیم برنامه ماه آینده با AI</span>
            </button>

            <button
              onClick={() => {
                if (onApplyNextMonthSchedule) {
                  onApplyNextMonthSchedule(nextMonthData);
                } else {
                  showToast(`برنامه ماه ${nextMonthData.monthName} با موفقیت بارگذاری شد!`, 'success');
                }
              }}
              className="px-5 py-3 rounded-2xl bg-white/15 hover:bg-white/25 active:scale-95 text-white font-bold backdrop-blur-md border border-white/20 transition-all flex items-center justify-center gap-2 cursor-pointer text-xs sm:text-sm"
            >
              <Zap className="w-4 h-4 text-amber-300" />
              <span>پیش‌بارگذاری برنامه {nextMonthData.monthName}</span>
            </button>
          </div>
        </div>

        {/* Current Progress Metrics */}
        <div className="mt-8 pt-6 border-t border-white/15 grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3.5 border border-white/10">
            <div className="text-xs text-indigo-200">پیشرفت کل مباحث تا اسفند</div>
            <div className="text-xl sm:text-2xl font-black text-white mt-1">
              {toPersianDigits(progressPercent)}٪
            </div>
            <div className="w-full bg-white/20 h-2 rounded-full overflow-hidden mt-2">
              <div
                className="h-full bg-gradient-to-r from-emerald-400 to-teal-300 rounded-full transition-all duration-700"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3.5 border border-white/10">
            <div className="text-xs text-indigo-200">ماه جاری و ماه بعد</div>
            <div className="text-lg sm:text-xl font-black text-white mt-1">
              {currentMonthData.monthName} ← {nextMonthData.monthName}
            </div>
            <div className="text-xs text-amber-300 mt-2 font-medium">
              فاز {toPersianDigits(nextMonthData.monthIndex)} از ۹
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3.5 border border-white/10">
            <div className="text-xs text-indigo-200">هدف تست ماه آینده</div>
            <div className="text-xl sm:text-2xl font-black text-white mt-1">
              {toPersianDigits(nextMonthData.targetMonthlyTests)} <span className="text-xs font-normal">تست</span>
            </div>
            <div className="text-xs text-emerald-300 mt-2 font-medium">
              روزی {toPersianDigits(Math.round(nextMonthData.targetMonthlyTests / 30))} تست
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3.5 border border-white/10">
            <div className="text-xs text-indigo-200">ساعت مطالعه ماه آینده</div>
            <div className="text-xl sm:text-2xl font-black text-white mt-1">
              {toPersianDigits(nextMonthData.targetMonthlyHours)} <span className="text-xs font-normal">ساعت</span>
            </div>
            <div className="text-xs text-cyan-300 mt-2 font-medium">
              روزی {toPersianDigits((nextMonthData.targetMonthlyHours / 30).toFixed(1))} ساعت
            </div>
          </div>
        </div>
      </div>

      {/* Month Switcher Header */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-slate-500 dark:text-slate-400">ماه فعلی شما:</span>
          <div className="flex items-center gap-1.5 overflow-x-auto p-1 bg-slate-100 dark:bg-slate-800 rounded-2xl">
            {annualPlan.months.slice(0, 7).map((m) => (
              <button
                key={m.id}
                onClick={() => setCurrentMonthIdx(m.monthIndex)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  currentMonthIdx === m.monthIndex
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                {m.monthName}
              </button>
            ))}
          </div>
        </div>

        <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1.5 font-bold">
          <span>ماه آینده مورد بررسی:</span>
          <span className="text-amber-600 dark:text-amber-400 font-extrabold text-sm">{nextMonthData.monthName} ({nextMonthData.season})</span>
        </div>
      </div>

      {/* SECTION 1: WHAT WE WILL STUDY NEXT MONTH (برنامه ماه آینده چیست؟) */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-xs space-y-6">
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 rounded-xl text-xs font-black bg-amber-500 text-slate-950">
                برنامه ماه بعد: {nextMonthData.monthName}
              </span>
              <span className="text-xs font-bold text-slate-500 dark:text-slate-400">
                {nextMonthData.phaseTitle}
              </span>
            </div>
            <h2 className="text-lg sm:text-xl font-black text-slate-900 dark:text-white pt-1">
              سرفصل‌های آموزشی پایه دهم، یازدهم و دوازدهم در ماه {nextMonthData.monthName}
            </h2>
          </div>
        </div>

        {/* 3-Column Syllabus Breakdown for Next Month */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Grade 10th Next Month */}
          <div className="bg-sky-50/60 dark:bg-sky-950/20 rounded-2xl p-5 border border-sky-200/60 dark:border-sky-800/40 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-black text-sky-900 dark:text-sky-200 flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-sky-500" />
                پایه دهم در {nextMonthData.monthName}
              </h3>
              <span className="text-xs font-bold text-sky-600 dark:text-sky-400 bg-sky-100 dark:bg-sky-900/60 px-2 py-0.5 rounded-md">
                پایه ۱
              </span>
            </div>
            <div className="space-y-2 text-xs">
              {Object.entries(nextMonthData.grade10Coverage || {}).map(([subj, ch]) => (
                <div key={subj} className="bg-white dark:bg-slate-900 p-2.5 rounded-xl border border-sky-100 dark:border-sky-900/30">
                  <strong className="text-slate-800 dark:text-slate-200 block">{subj}:</strong>
                  <span className="text-slate-600 dark:text-slate-400 leading-relaxed block mt-0.5">{ch}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Grade 11th Next Month */}
          <div className="bg-teal-50/60 dark:bg-teal-950/20 rounded-2xl p-5 border border-teal-200/60 dark:border-teal-800/40 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-black text-teal-900 dark:text-teal-200 flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-teal-500" />
                پایه یازدهم در {nextMonthData.monthName}
              </h3>
              <span className="text-xs font-bold text-teal-600 dark:text-teal-400 bg-teal-100 dark:bg-teal-900/60 px-2 py-0.5 rounded-md">
                پایه ۲
              </span>
            </div>
            <div className="space-y-2 text-xs">
              {Object.entries(nextMonthData.grade11Coverage || {}).map(([subj, ch]) => (
                <div key={subj} className="bg-white dark:bg-slate-900 p-2.5 rounded-xl border border-teal-100 dark:border-teal-900/30">
                  <strong className="text-slate-800 dark:text-slate-200 block">{subj}:</strong>
                  <span className="text-slate-600 dark:text-slate-400 leading-relaxed block mt-0.5">{ch}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Grade 12th Next Month */}
          <div className="bg-indigo-50/60 dark:bg-indigo-950/20 rounded-2xl p-5 border border-indigo-200/60 dark:border-indigo-800/40 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-black text-indigo-900 dark:text-indigo-200 flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-indigo-500" />
                دوازدهم و نهایی در {nextMonthData.monthName}
              </h3>
              <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-100 dark:bg-indigo-900/60 px-2 py-0.5 rounded-md">
                کنکور و نهایی
              </span>
            </div>
            <div className="space-y-2 text-xs">
              {Object.entries(nextMonthData.grade12Coverage || {}).map(([subj, ch]) => (
                <div key={subj} className="bg-white dark:bg-slate-900 p-2.5 rounded-xl border border-indigo-100 dark:border-indigo-900/30">
                  <strong className="text-slate-800 dark:text-slate-200 block">{subj}:</strong>
                  <span className="text-slate-600 dark:text-slate-400 leading-relaxed block mt-0.5">{ch}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* SECTION 2: REVIEW PLACEMENT ASSURANCE (راستی‌آزمایی جای‌گذاری تایم‌های مرور) */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-xs space-y-6">
        <div className="space-y-2">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <h3 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
              <Brain className="w-5 h-5 text-purple-500" />
              <span>ماتریس راستی‌آزمایی: مباحث این ماه در چه روزهایی از ماه بعد مرور می‌شوند؟</span>
            </h3>
            <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-700 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              تایم‌های مرور ۱۰۰٪ تضمین‌شده
            </span>
          </div>
          <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
            جدول زیر اثبات می‌کند مباحثی که در ماه جاری مطالعه می‌کنید، در کدام روزها و هفته‌های ماه آینده در <strong>تایم اختصاصی مرور شبانه (۲۱:۱۵ الی ۲۲:۱۵)</strong> قرار داده شده‌اند تا فراموشی طبق منحنی ابینگهاوس به صفر برسد.
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/60 text-slate-700 dark:text-slate-300 border-b border-slate-200 dark:border-slate-700">
                <th className="p-3 font-extrabold">درس</th>
                <th className="p-3 font-extrabold">مبحث خوانده‌شده (ماه جاری)</th>
                <th className="p-3 font-extrabold">جایگاه تایم مرور در ماه آینده</th>
                <th className="p-3 font-extrabold">نوع مرور ابینگهاوس</th>
                <th className="p-3 font-extrabold text-center">وضعیت تضمین</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {reviewAuditItems.map((item, idx) => {
                const info = TAJROBI_SUBJECTS_INFO[item.subject];
                return (
                  <tr key={idx} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
                    <td className="p-3 font-bold text-slate-900 dark:text-white flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: info?.color || '#059669' }} />
                      <span>{item.subject}</span>
                    </td>
                    <td className="p-3 text-slate-700 dark:text-slate-300 font-medium">
                      {item.currentTopic}
                    </td>
                    <td className="p-3 text-amber-600 dark:text-amber-400 font-bold">
                      {item.nextMonthReviewSlot}
                    </td>
                    <td className="p-3 text-purple-600 dark:text-purple-400 font-semibold">
                      {item.reviewType}
                    </td>
                    <td className="p-3 text-center">
                      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 text-[11px] font-black">
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                        جای‌گذاری‌شده
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Nightly Review Assurance Callout */}
        <div className="p-4 rounded-2xl bg-purple-50/80 dark:bg-purple-950/30 border border-purple-200 dark:border-purple-800/40 flex items-start gap-3">
          <Clock className="w-5 h-5 text-purple-600 dark:text-purple-400 shrink-0 mt-0.5" />
          <div className="space-y-1 text-xs text-purple-950 dark:text-purple-200">
            <strong className="block font-black">⏰ ساعت استاندارد تایم‌های مرور روزانه:</strong>
            <p className="leading-relaxed text-purple-900/90 dark:text-purple-300">
              در تمام روزهای هفته (یکشنبه تا شنبه)، پارت ساعت <strong>۲۱:۱۵ الی ۲۲:۱۵</strong> اختصاصاً به عنوان «تایم مرور طلایی ابینگهاوس» رزرو شده است. این پارت با متد بازیابی فعال و حل ۲۰ تا ۲۵ تست زمان‌دار پوششی اجرا می‌شود.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
