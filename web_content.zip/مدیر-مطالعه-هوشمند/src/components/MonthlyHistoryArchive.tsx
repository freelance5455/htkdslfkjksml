import React, { useState } from 'react';
import { GradeLevel, StudyLog, TajrobiSubject } from '../types';
import {
  ACADEMIC_MONTHS,
  GRADE_LEVELS,
  GRADE_META,
  TAJROBI_SUBJECTS_INFO,
  TAJROBI_SUBJECTS_LIST,
  detectGradeFromText,
  getCurrentJalaliMonth,
  getOffsetDateISO,
  getTodayISO,
  getTodayJalali,
  toFaDigits,
} from '../utils/tajrobiData';
import {
  BookOpen,
  CheckCircle2,
  XCircle,
  Percent,
  Search,
  Plus,
  Trash2,
  Filter,
  Scale,
  Calendar,
  Layers,
  ArrowUpDown,
} from 'lucide-react';

interface MonthlyHistoryArchiveProps {
  logs: StudyLog[];
  onAddManualLog: (log: Omit<StudyLog, 'id'>) => void;
  onDeleteLog: (id: string) => void;
}

export const MonthlyHistoryArchive: React.FC<MonthlyHistoryArchiveProps> = ({
  logs,
  onAddManualLog,
  onDeleteLog,
}) => {
  // Advanced Filter states
  const [selectedMonth, setSelectedMonth] = useState<string>('all');
  const [selectedGrade, setSelectedGrade] = useState<GradeLevel | 'all'>('all');
  const [selectedSubject, setSelectedSubject] = useState<TajrobiSubject | 'all'>('all');
  const [timePreset, setTimePreset] = useState<'all' | 'this_week' | 'last_week' | 'this_month'>('all');
  const [accuracyPreset, setAccuracyPreset] = useState<'all' | 'high' | 'medium' | 'low'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [showAddModal, setShowAddModal] = useState<boolean>(false);

  // Form states for manual log creation
  const [formSubject, setFormSubject] = useState<TajrobiSubject>('زیست‌شناسی');
  const [formGrade, setFormGrade] = useState<GradeLevel>('دهم');
  const [formTopic, setFormTopic] = useState<string>('');
  const [formBook, setFormBook] = useState<string>('خیلی سبز جامع زیست‌شناسی');
  const [formDuration, setFormDuration] = useState<number>(90);
  const [formTotalTests, setFormTotalTests] = useState<number>(40);
  const [formCorrectTests, setFormCorrectTests] = useState<number>(32);
  const [formWrongTests, setFormWrongTests] = useState<number>(5);
  const [formMonth, setFormMonth] = useState<string>(getCurrentJalaliMonth());
  const [formNotes, setFormNotes] = useState<string>('');

  // Extract all distinct months available in logs
  const monthsInLogs = Array.from(new Set(logs.map((l) => l.monthLabel))).filter(Boolean);

  // Today & week offset ISOs
  const todayISO = getTodayISO();
  const sevenDaysAgoISO = getOffsetDateISO(7);
  const fourteenDaysAgoISO = getOffsetDateISO(14);
  const currentMonthName = getCurrentJalaliMonth();

  // Filter logs with all advanced criteria
  const filteredLogs = logs.filter((log) => {
    // 1. Time preset filter (هفته جاری، هفته قبل، ماه جاری)
    if (timePreset === 'this_week') {
      if (log.date < sevenDaysAgoISO) return false;
    } else if (timePreset === 'last_week') {
      if (log.date < fourteenDaysAgoISO || log.date >= sevenDaysAgoISO) return false;
    } else if (timePreset === 'this_month') {
      if (log.monthLabel !== currentMonthName && log.date < getOffsetDateISO(30)) return false;
    }

    // 2. Month-by-month filter
    if (selectedMonth !== 'all' && log.monthLabel !== selectedMonth) return false;

    // 3. Grade filter (دهم، یازدهم، دوازدهم، جامع، عمومی)
    const logGrade = log.gradeLevel || detectGradeFromText(log.topic + ' ' + (log.bookSource || ''));
    if (selectedGrade !== 'all' && logGrade !== selectedGrade) return false;

    // 4. Subject filter
    if (selectedSubject !== 'all' && log.subject !== selectedSubject) return false;

    // 5. Accuracy filter (درصد درستی تست)
    if (accuracyPreset === 'high' && log.accuracyPercentage < 80) return false;
    if (accuracyPreset === 'medium' && (log.accuracyPercentage < 50 || log.accuracyPercentage >= 80)) return false;
    if (accuracyPreset === 'low' && log.accuracyPercentage >= 50) return false;

    // 6. Search Query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      const matchTopic = log.topic.toLowerCase().includes(q);
      const matchBook = log.bookSource.toLowerCase().includes(q);
      const matchSubj = log.subject.toLowerCase().includes(q);
      if (!matchTopic && !matchBook && !matchSubj) return false;
    }

    return true;
  });

  // Calculate statistics for filtered view
  const totalTests = filteredLogs.reduce((acc, l) => acc + l.totalTests, 0);
  const totalCorrect = filteredLogs.reduce((acc, l) => acc + l.correctTests, 0);
  const totalWrong = filteredLogs.reduce((acc, l) => acc + l.wrongTests, 0);
  const overallAccuracy =
    totalTests > 0 ? Math.round((totalCorrect / totalTests) * 100) : 0;
  const totalMinutes = filteredLogs.reduce((acc, l) => acc + l.durationMinutes, 0);
  const totalHours = Math.round((totalMinutes / 60) * 10) / 10;

  const distinctTopicsCount = new Set(filteredLogs.map((l) => l.topic)).size;
  const distinctBooksCount = new Set(filteredLogs.map((l) => l.bookSource)).size;

  const handleCreateLog = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTopic.trim()) return;

    const blank = Math.max(0, formTotalTests - (formCorrectTests + formWrongTests));
    const accuracy =
      formTotalTests > 0 ? Math.round((formCorrectTests / formTotalTests) * 100) : 0;

    onAddManualLog({
      subject: formSubject,
      gradeLevel: formGrade,
      topic: formTopic.trim(),
      bookSource: formBook.trim() || 'کتاب تستی',
      durationMinutes: formDuration,
      totalTests: formTotalTests,
      correctTests: formCorrectTests,
      wrongTests: formWrongTests,
      blankTests: blank,
      accuracyPercentage: accuracy,
      completedFully: true,
      date: getTodayISO(),
      jalaliDate: getTodayJalali(),
      monthLabel: formMonth,
      timestamp: new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }),
      notes: formNotes.trim() || undefined,
    });

    setFormTopic('');
    setShowAddModal(false);
  };

  return (
    <div className="space-y-6 animate-fade-slide">
      {/* Top Banner */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-teal-600" />
            <span>کارنامه جامع مباحث، کتاب‌ها و درصد تست‌ها</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            آرشیو کامل تست‌ها با امکان فیلتر ماه به ماه، هفته به هفته و تفکیک پایه‌های دهم، یازدهم و دوازدهم
          </p>
        </div>

        <button
          type="button"
          onClick={() => setShowAddModal(true)}
          className="px-4 py-2.5 rounded-2xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-black flex items-center justify-center gap-2 transition cursor-pointer shadow-xs"
        >
          <Plus className="w-4 h-4" />
          <span>+ ثبت گزارش دستی مطالعه و تست</span>
        </button>
      </div>

      {/* Advanced Filter Box (فیلترهای گسترده ماه، هفته، پایه دهم/یازدهم/دوازدهم) */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs space-y-4">
        {/* Quick Time Preset Buttons */}
        <div className="flex flex-wrap items-center gap-2 pb-3 border-b border-slate-100 dark:border-slate-800">
          <span className="text-xs font-bold text-slate-500 flex items-center gap-1">
            <Calendar className="w-3.5 h-3.5 text-teal-600" />
            <span>بازه زمانی:</span>
          </span>

          {[
            { id: 'all' as const, label: 'همه زمان‌ها' },
            { id: 'this_week' as const, label: 'این هفته' },
            { id: 'last_week' as const, label: 'هفته گذشته' },
            { id: 'this_month' as const, label: 'ماه جاری (' + currentMonthName + ')' },
          ].map((preset) => (
            <button
              key={preset.id}
              type="button"
              onClick={() => setTimePreset(preset.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                timePreset === preset.id
                  ? 'bg-teal-600 text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              {preset.label}
            </button>
          ))}
        </div>

        {/* Filter Dropdowns Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Grade Filter (پایه دهم، یازدهم، دوازدهم) */}
          <div>
            <label className="text-[11px] font-bold text-slate-500 dark:text-slate-400 block mb-1">
              پایه تحصیلی:
            </label>
            <select
              value={selectedGrade}
              onChange={(e) => setSelectedGrade(e.target.value as any)}
              className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-800 dark:text-slate-200"
            >
              <option value="all">همه پایه‌ها (دهم، یازدهم، دوازدهم)</option>
              {GRADE_LEVELS.map((g) => (
                <option key={g} value={g}>
                  {GRADE_META[g].label}
                </option>
              ))}
            </select>
          </div>

          {/* Month Filter */}
          <div>
            <label className="text-[11px] font-bold text-slate-500 dark:text-slate-400 block mb-1">
              ماه تحصیلی (ماه به ماه):
            </label>
            <select
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-800 dark:text-slate-200"
            >
              <option value="all">همه ماه‌ها</option>
              {ACADEMIC_MONTHS.map((m) => (
                <option key={m} value={m}>
                  {m} {m === currentMonthName ? '(ماه جاری)' : ''}
                </option>
              ))}
            </select>
          </div>

          {/* Subject Filter */}
          <div>
            <label className="text-[11px] font-bold text-slate-500 dark:text-slate-400 block mb-1">
              درس رشته تجربی:
            </label>
            <select
              value={selectedSubject}
              onChange={(e) => setSelectedSubject(e.target.value as any)}
              className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-800 dark:text-slate-200"
            >
              <option value="all">همه درس‌ها</option>
              {TAJROBI_SUBJECTS_LIST.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>

          {/* Accuracy Filter */}
          <div>
            <label className="text-[11px] font-bold text-slate-500 dark:text-slate-400 block mb-1">
              دامنه درصد دقت:
            </label>
            <select
              value={accuracyPreset}
              onChange={(e) => setAccuracyPreset(e.target.value as any)}
              className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-800 dark:text-slate-200"
            >
              <option value="all">همه درصدها</option>
              <option value="high">تست‌های عالی (۸۰٪ به بالا)</option>
              <option value="medium">تست‌های متوسط (۵۰٪ تا ۸۰٪)</option>
              <option value="low">نیازمند تحلیل و مرور غلط‌ها (زیر ۵۰٪)</option>
            </select>
          </div>
        </div>

        {/* Search Input */}
        <div className="relative">
          <Search className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="جستجو در مباحث، نام کتاب‌ها (خیلی سبز، مبتکران، IQ...) یا نکات..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pr-10 pl-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-800 dark:text-slate-200 focus:outline-teal-500"
          />
        </div>
      </div>

      {/* Aggregate Statistics Header for Filtered Data */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 shadow-xs">
          <span className="text-slate-500 text-xs font-bold">زمان مطالعه فیلترشده:</span>
          <div className="text-xl font-black text-slate-900 dark:text-white tabular-nums mt-1">
            {toFaDigits(totalHours)} ساعت
          </div>
          <span className="text-[11px] text-slate-400">{toFaDigits(distinctTopicsCount)} مبحث متمایز</span>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 shadow-xs">
          <span className="text-slate-500 text-xs font-bold">تعداد کل تست‌ها:</span>
          <div className="text-xl font-black text-blue-600 dark:text-blue-400 tabular-nums mt-1">
            {toFaDigits(totalTests)} تست
          </div>
          <span className="text-[11px] text-slate-400">از {toFaDigits(distinctBooksCount)} کتاب منبع</span>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 shadow-xs">
          <span className="text-slate-500 text-xs font-bold">تست‌های درست و غلط:</span>
          <div className="text-xl font-black text-slate-900 dark:text-white tabular-nums mt-1 flex items-baseline gap-1.5">
            <span className="text-emerald-600">{toFaDigits(totalCorrect)} درست</span>
            <span className="text-slate-400 text-xs">/</span>
            <span className="text-rose-600 text-sm">{toFaDigits(totalWrong)} غلط</span>
          </div>
          <span className="text-[11px] text-slate-400">پاسخ‌های صحیح</span>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 shadow-xs">
          <span className="text-slate-500 text-xs font-bold">میانگین دقت پاسخگویی:</span>
          <div className="text-xl font-black text-emerald-600 dark:text-emerald-400 tabular-nums mt-1">
            {toFaDigits(overallAccuracy)}٪
          </div>
          <span className="text-[11px] text-slate-400">شاخص تسلط علمی</span>
        </div>
      </div>

      {/* Filtered Logs List */}
      <div className="space-y-3">
        {filteredLogs.length === 0 ? (
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-12 text-center text-slate-500">
            <p className="font-bold text-sm">هیچ گزارشی با فیلترهای انتخابی پیدا نشد.</p>
            <p className="text-xs text-slate-400 mt-1">
              فیلترهای ماه، پایه تحصیلی یا دامنه دقت را تغییر دهید یا گزارش جدید ثبت کنید.
            </p>
          </div>
        ) : (
          filteredLogs.map((log) => {
            const subjInfo = TAJROBI_SUBJECTS_INFO[log.subject];
            const grade: GradeLevel =
              log.gradeLevel || detectGradeFromText(log.topic + ' ' + (log.bookSource || ''));
            const gradeMeta = GRADE_META[grade];

            return (
              <div
                key={log.id}
                className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 sm:p-5 shadow-xs hover:border-teal-400 transition space-y-3"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800/80 pb-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <span
                      className="px-2.5 py-1 rounded-xl text-xs font-black"
                      style={{ backgroundColor: subjInfo.color + '22', color: subjInfo.color }}
                    >
                      {log.subject}
                    </span>

                    {/* Grade Level Badge */}
                    <span
                      className={`px-2 py-0.5 rounded-lg text-[11px] font-black ${gradeMeta.badgeClass}`}
                    >
                      پایه {gradeMeta.shortLabel}
                    </span>

                    <span className="text-xs font-bold text-slate-500 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-md">
                      {log.monthLabel || 'مهر'}
                    </span>

                    <h4 className="text-sm font-black text-slate-900 dark:text-white">
                      {log.topic}
                    </h4>
                  </div>

                  <div className="flex items-center gap-3 text-xs text-slate-400 tabular-nums self-end sm:self-center">
                    <span>📅 {log.jalaliDate}</span>
                    <span>⏱ {toFaDigits(log.durationMinutes)} دقیقه</span>
                    <button
                      type="button"
                      onClick={() => onDeleteLog(log.id)}
                      className="p-1 rounded text-slate-400 hover:text-rose-600 transition cursor-pointer"
                      title="حذف گزارش"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs tabular-nums">
                  <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50">
                    <span className="text-[11px] text-slate-500 block">منبع کتاب:</span>
                    <strong className="text-slate-800 dark:text-slate-200 block truncate mt-0.5">
                      {log.bookSource}
                    </strong>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50">
                    <span className="text-[11px] text-slate-500 block">تست‌های حل‌شده:</span>
                    <strong className="text-blue-600 dark:text-blue-400 block mt-0.5">
                      {toFaDigits(log.totalTests)} تست
                    </strong>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50">
                    <span className="text-[11px] text-slate-500 block">درست / غلط / نزده:</span>
                    <strong className="text-slate-800 dark:text-slate-200 block mt-0.5">
                      <span className="text-emerald-600">{toFaDigits(log.correctTests)}</span> /{' '}
                      <span className="text-rose-600">{toFaDigits(log.wrongTests)}</span> /{' '}
                      <span className="text-slate-400">{toFaDigits(log.blankTests || 0)}</span>
                    </strong>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50">
                    <span className="text-[11px] text-slate-500 block">درصد دقت:</span>
                    <strong
                      className={`block mt-0.5 font-black text-sm ${
                        log.accuracyPercentage >= 80
                          ? 'text-emerald-600'
                          : log.accuracyPercentage >= 50
                          ? 'text-amber-600'
                          : 'text-rose-600'
                      }`}
                    >
                      {toFaDigits(log.accuracyPercentage)}٪
                    </strong>
                  </div>
                </div>

                {log.notes && (
                  <div className="text-xs text-slate-600 dark:text-slate-300 bg-teal-50/50 dark:bg-teal-950/30 p-2.5 rounded-xl border border-teal-100 dark:border-teal-900/40">
                    <strong>نکته تستی: </strong>
                    {log.notes}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Manual Entry Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <form
            onSubmit={handleCreateLog}
            className="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4 animate-fade-in"
          >
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="text-base font-black text-slate-900 dark:text-white">
                ثبت گزارش مطالعه و تست‌زنی گذشته
              </h3>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-slate-600 text-lg cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">
                  درس:
                </label>
                <select
                  value={formSubject}
                  onChange={(e) => {
                    const s = e.target.value as TajrobiSubject;
                    setFormSubject(s);
                    if (TAJROBI_SUBJECTS_INFO[s].popularBooks[0]) {
                      setFormBook(TAJROBI_SUBJECTS_INFO[s].popularBooks[0]);
                    }
                  }}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                >
                  {TAJROBI_SUBJECTS_LIST.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">
                  پایه تحصیلی:
                </label>
                <select
                  value={formGrade}
                  onChange={(e) => setFormGrade(e.target.value as GradeLevel)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                >
                  {GRADE_LEVELS.map((g) => (
                    <option key={g} value={g}>
                      {GRADE_META[g].label}
                    </option>
                  ))}
                </select>
              </div>

              <div className="col-span-2">
                <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">
                  نام مبحث یا فصل:
                </label>
                <input
                  type="text"
                  placeholder="مثال: ژنتیک مندلی و شجره‌نامه"
                  value={formTopic}
                  onChange={(e) => setFormTopic(e.target.value)}
                  required
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">
                  کتاب منبع تست:
                </label>
                <input
                  type="text"
                  value={formBook}
                  onChange={(e) => setFormBook(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">
                  ماه مطالعه:
                </label>
                <select
                  value={formMonth}
                  onChange={(e) => setFormMonth(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                >
                  {ACADEMIC_MONTHS.map((m) => (
                    <option key={m} value={m}>
                      {m}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">
                  مدت مطالعه (دقیقه):
                </label>
                <input
                  type="number"
                  min={10}
                  max={300}
                  value={formDuration}
                  onChange={(e) => setFormDuration(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">
                  تعداد کل تست:
                </label>
                <input
                  type="number"
                  min={0}
                  max={300}
                  value={formTotalTests}
                  onChange={(e) => setFormTotalTests(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">
                  تست‌های درست:
                </label>
                <input
                  type="number"
                  min={0}
                  max={formTotalTests}
                  value={formCorrectTests}
                  onChange={(e) => setFormCorrectTests(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-emerald-600"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">
                  تست‌های غلط:
                </label>
                <input
                  type="number"
                  min={0}
                  max={formTotalTests}
                  value={formWrongTests}
                  onChange={(e) => setFormWrongTests(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-rose-600"
                />
              </div>

              <div className="col-span-2">
                <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">
                  نکات تستی یا اشکالات مبحث (اختیاری):
                </label>
                <input
                  type="text"
                  placeholder="نکات مهم، علت غلط زدن تست‌ها..."
                  value={formNotes}
                  onChange={(e) => setFormNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-500 hover:bg-slate-100 transition cursor-pointer"
              >
                انصراف
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-black transition cursor-pointer shadow-xs"
              >
                ثبت در کارنامه
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
