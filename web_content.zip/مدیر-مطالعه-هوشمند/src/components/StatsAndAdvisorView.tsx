import React from 'react';
import { AppState, TajrobiSubject } from '../types';
import {
  TAJROBI_SUBJECTS_INFO,
  TAJROBI_SUBJECTS_LIST,
  calculateStreak,
  formatISOToJalaliShort,
  formatMinutesToHoursAndMinutes,
  getOffsetDateISO,
  toPersianDigits,
} from '../utils/tajrobiData';
import {
  Award,
  Flame,
  Lightbulb,
  Sparkles,
  TrendingUp,
  AlertCircle,
  CheckCircle2,
} from 'lucide-react';

interface StatsAndAdvisorViewProps {
  state: AppState;
}

export const StatsAndAdvisorView: React.FC<StatsAndAdvisorViewProps> = ({ state }) => {
  const streak = calculateStreak(state.studyLogs);

  // 7 Days Stats Table
  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const daysAgo = 6 - i;
    const iso = getOffsetDateISO(daysAgo);
    const dayLogs = state.studyLogs.filter((l) => l.date === iso);
    const totalMinutes = dayLogs.reduce((acc, l) => acc + l.durationMinutes, 0);
    const totalTests = dayLogs.reduce((acc, l) => acc + l.totalTests, 0);
    const correctTests = dayLogs.reduce((acc, l) => acc + l.correctTests, 0);
    const accuracy = totalTests > 0 ? Math.round((correctTests / totalTests) * 100) : 0;

    return {
      iso,
      jalali: formatISOToJalaliShort(iso),
      totalMinutes,
      totalTests,
      correctTests,
      accuracy,
    };
  });

  // Most & Least studied subjects
  const subjectTotals: Record<TajrobiSubject, number> = {
    'زیست‌شناسی': 0,
    'شیمی': 0,
    'فیزیک': 0,
    'ریاضی تجربی': 0,
    'زمین‌شناسی': 0,
    'امتحانات نهایی / عمومی': 0,
  };

  state.studyLogs.forEach((log) => {
    if (subjectTotals[log.subject] !== undefined) {
      subjectTotals[log.subject] += log.durationMinutes;
    }
  });

  const sortedSubjects = (Object.keys(subjectTotals) as TajrobiSubject[]).sort(
    (a, b) => subjectTotals[b] - subjectTotals[a]
  );
  const mostStudied = sortedSubjects[0];
  const leastStudied = sortedSubjects[sortedSubjects.length - 1];

  return (
    <div className="space-y-6 animate-fade-slide">
      {/* Top Banner */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
            <Award className="w-5 h-5 text-teal-600" />
            <span>آمار پیشرفته و مشاور هوشمند کنکور تجربی</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            جدول عملکرد ۷ روز اخیر، تحلیل تعادل دروس و توصیه‌های تخصصی برای جهش تراز
          </p>
        </div>

        <div className="flex items-center gap-2 px-4 py-2 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-700 text-amber-900 dark:text-amber-200 text-xs font-black">
          <Flame className="w-4 h-4 text-amber-500" />
          <span>پیوستگی مطالعه: {toPersianDigits(streak)} روز متوالی</span>
        </div>
      </div>

      {/* 2 Focus Cards: Most and Least Studied */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Most Studied */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-emerald-300 dark:border-emerald-800/80 p-5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-slate-500">بیشترین درس مطالعه‌شده:</span>
            <div className="text-lg font-black text-slate-900 dark:text-white mt-1">
              {mostStudied}
            </div>
            <span className="text-xs text-emerald-600 font-bold">
              {formatMinutesToHoursAndMinutes(subjectTotals[mostStudied])}
            </span>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-emerald-50 dark:bg-emerald-950 flex items-center justify-center text-emerald-600">
            <CheckCircle2 className="w-6 h-6" />
          </div>
        </div>

        {/* Least Studied */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-amber-300 dark:border-amber-800/80 p-5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-slate-500">کم‌ترین درس مطالعه‌شده (نیاز به توجه):</span>
            <div className="text-lg font-black text-slate-900 dark:text-white mt-1">
              {leastStudied}
            </div>
            <span className="text-xs text-amber-600 font-bold">
              {formatMinutesToHoursAndMinutes(subjectTotals[leastStudied])}
            </span>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-amber-50 dark:bg-amber-950 flex items-center justify-center text-amber-600">
            <AlertCircle className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* 7 Days Performance Table */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-4">
        <h3 className="text-sm font-black text-slate-900 dark:text-white">
          کارنامه تفکیکی عملکرد ۷ روز اخیر
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-700 text-slate-400 font-bold">
                <th className="pb-3 pr-2">تاریخ</th>
                <th className="pb-3">زمان مطالعه</th>
                <th className="pb-3">تعداد تست</th>
                <th className="pb-3">تست درست</th>
                <th className="pb-3">درصد پاسخگویی</th>
                <th className="pb-3">ارزیابی کیفی</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-bold">
              {last7Days.map((day) => (
                <tr key={day.iso} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition">
                  <td className="py-3 pr-2 tabular-nums font-black text-slate-800 dark:text-slate-200">
                    {day.jalali}
                  </td>
                  <td className="py-3 tabular-nums">
                    {formatMinutesToHoursAndMinutes(day.totalMinutes)}
                  </td>
                  <td className="py-3 tabular-nums">
                    {toPersianDigits(day.totalTests)} تست
                  </td>
                  <td className="py-3 tabular-nums text-emerald-600">
                    {toPersianDigits(day.correctTests)}
                  </td>
                  <td className="py-3 tabular-nums">
                    <span
                      className={`px-2 py-0.5 rounded-md ${
                        day.accuracy >= 75
                          ? 'bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-300'
                          : day.accuracy >= 50
                          ? 'bg-amber-100 dark:bg-amber-900/40 text-amber-700 dark:text-amber-300'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
                      }`}
                    >
                      {toPersianDigits(day.accuracy)}٪
                    </span>
                  </td>
                  <td className="py-3">
                    {day.totalMinutes >= 360 ? (
                      <span className="text-emerald-600 font-extrabold">عالی و استاندارد ⭐</span>
                    ) : day.totalMinutes >= 180 ? (
                      <span className="text-teal-600 font-bold">متوسط</span>
                    ) : (
                      <span className="text-slate-400 font-medium">کم‌تر از هدف</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Smart Advisor & Coaching Tips */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-4">
        <h3 className="text-sm font-black text-slate-900 dark:text-white flex items-center gap-2">
          <Lightbulb className="w-4 h-4 text-amber-500" />
          <span>توصیه‌های مشاور هوشمند اختصاصی رشته تجربی</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 rounded-2xl bg-teal-50/60 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800/60 space-y-2">
            <span className="text-xs font-black text-teal-800 dark:text-teal-300 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-teal-600" />
              قانون طلایی زیست‌شناسی (ضریب ۱۲)
            </span>
            <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed font-medium">
              هر روز باید حداقل یک پارت زیست در برنامه‌تان باشد. مطالعه خط به خط کتاب درسی به همراه تحلیل تمام گزینه‌های تست‌های سال‌های اخیر ضامن درصد بالای ۷۰ است.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-blue-50/60 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800/60 space-y-2">
            <span className="text-xs font-black text-blue-800 dark:text-blue-300 flex items-center gap-1.5">
              <TrendingUp className="w-3.5 h-3.5 text-blue-600" />
              تکنیک زمان‌های نقصانی و تست زمان‌دار
            </span>
            <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed font-medium">
              در حل تست‌های فیزیک و شیمی، از همین حالا تست زمان‌دار بزنید. برای هر تست شیمی محاسباتی حداکثر ۷۵ ثانیه زمان اختصاص دهید.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-purple-50/60 dark:bg-purple-950/40 border border-purple-200 dark:border-purple-800/60 space-y-2">
            <span className="text-xs font-black text-purple-800 dark:text-purple-300 flex items-center gap-1.5">
              <Award className="w-3.5 h-3.5 text-purple-600" />
              امتحانات نهایی را دست‌کم نگیرید!
            </span>
            <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed font-medium">
              تأثیر قطعی ۵۰ تا ۶۰ درصدی سوابق تحصیلی یعنی بیست شدن در دروس عمومی (فارسی، عربی، زبان، دینی) به اندازه تراز ۸۰۰۰ کنکور ارزش دارد.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
