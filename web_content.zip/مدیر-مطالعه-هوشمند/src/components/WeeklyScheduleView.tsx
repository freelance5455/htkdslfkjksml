import React, { useState } from 'react';
import {
  ActivityType,
  DayOfWeek,
  DaySchedule,
  GradeLevel,
  StudyPart,
  TajrobiSubject,
  ThemeConfig,
  TopicMemoryItem,
  WeeklyScheduleTemplate,
  WeeklySlot,
} from '../types';
import {
  DAYS_OF_WEEK,
  GRADE_META,
  TAJROBI_SUBJECTS_INFO,
  TAJROBI_SUBJECTS_LIST,
  WEEKLY_TEMPLATES,
  formatMinutesToHoursAndMinutes,
  getTodayPersianDayOfWeek,
  playChimeSound,
  toPersianDigits,
} from '../utils/tajrobiData';
import { AIStudyPlannerModal } from './AIStudyPlannerModal';
import {
  Calendar,
  Clock,
  Plus,
  Play,
  Trash2,
  Zap,
  Sparkles,
  BookOpen,
  ArrowRight,
  Layers,
  CheckCircle2,
  Award,
  HelpCircle,
  Bot,
} from 'lucide-react';

interface WeeklyScheduleViewProps {
  schedule: Record<DayOfWeek, DaySchedule>;
  theme: ThemeConfig;
  topicMemories?: TopicMemoryItem[];
  onSaveTopicMemory?: (memories: TopicMemoryItem[]) => void;
  onUpdateSchedule: (newSchedule: Record<DayOfWeek, DaySchedule>) => void;
  onStartInTimer: (subject: TajrobiSubject, topic: string, durationMinutes: number) => void;
  onSyncDayToParts: (slots: WeeklySlot[]) => void;
  showToast: (message: string, type?: 'success' | 'warning' | 'info') => void;
}

export const WeeklyScheduleView: React.FC<WeeklyScheduleViewProps> = ({
  schedule,
  theme,
  topicMemories = [],
  onSaveTopicMemory,
  onUpdateSchedule,
  onStartInTimer,
  onSyncDayToParts,
  showToast,
}) => {
  const todayPersian = getTodayPersianDayOfWeek();
  const [selectedDay, setSelectedDay] = useState<DayOfWeek>(todayPersian);
  const [showAddSlotModal, setShowAddSlotModal] = useState(false);
  const [showAIPlannerModal, setShowAIPlannerModal] = useState(false);

  // New Slot Form State
  const [newStartTime, setNewStartTime] = useState('16:00');
  const [newEndTime, setNewEndTime] = useState('17:30');
  const [newTitle, setNewTitle] = useState('');
  const [newActivityType, setNewActivityType] = useState<ActivityType>('study');
  const [newSubject, setNewSubject] = useState<TajrobiSubject>('زیست‌شناسی');
  const [newGradeLevel, setNewGradeLevel] = useState<GradeLevel>('دوازدهم');
  const [newTopic, setNewTopic] = useState('');
  const [newTargetTests, setNewTargetTests] = useState<number>(30);
  const [newIsImportant, setNewIsImportant] = useState(false);

  // Current day schedule & slots
  const currentDaySchedule = schedule[selectedDay] || {
    day: selectedDay,
    dayType: selectedDay === 'پنجشنبه' || selectedDay === 'جمعه' ? 'holiday' : 'school',
    slots: [],
  };
  const currentSlots = currentDaySchedule.slots || [];

  // Calculate total planned study time for selected day
  const calculateSlotMinutes = (start: string, end: string): number => {
    try {
      const [sh, sm] = start.split(':').map(Number);
      const [eh, em] = end.split(':').map(Number);
      let diff = eh * 60 + em - (sh * 60 + sm);
      if (diff < 0) diff += 24 * 60;
      return Math.max(0, diff);
    } catch {
      return 90;
    }
  };

  const studySlots = currentSlots.filter((s) => s.activityType === 'study');
  const totalStudyMinutesSelectedDay = studySlots.reduce(
    (sum, s) => sum + calculateSlotMinutes(s.startTime, s.endTime),
    0
  );
  const totalTargetTestsSelectedDay = studySlots.reduce(
    (sum, s) => sum + (s.targetTests || 0),
    0
  );

  // Calculate weekly total hours per subject
  const weeklySubjectMinutes: Record<TajrobiSubject, number> = {
    'زیست‌شناسی': 0,
    'شیمی': 0,
    'فیزیک': 0,
    'ریاضی تجربی': 0,
    'زمین‌شناسی': 0,
    'امتحانات نهایی / عمومی': 0,
  };

  let totalWeeklyStudyMinutes = 0;
  Object.values(schedule).forEach((day) => {
    day.slots?.forEach((slot) => {
      if (slot.activityType === 'study' && slot.subject) {
        const mins = calculateSlotMinutes(slot.startTime, slot.endTime);
        weeklySubjectMinutes[slot.subject] = (weeklySubjectMinutes[slot.subject] || 0) + mins;
        totalWeeklyStudyMinutes += mins;
      }
    });
  });

  // Apply Template
  const handleApplyTemplate = (tpl: WeeklyScheduleTemplate) => {
    onUpdateSchedule(tpl.schedule);
    playChimeSound();
    showToast(`برنامه هفتگی «${tpl.title}» اعمال شد ✨`, 'success');
  };

  // Add new slot to current day
  const handleAddSlot = (e: React.FormEvent) => {
    e.preventDefault();
    const finalTitle =
      newTitle.trim() ||
      (newActivityType === 'study'
        ? `${newSubject} (${newTopic || 'مطالعه و تست'})`
        : newActivityType === 'school'
        ? 'مدرسه و کلاس'
        : newActivityType === 'rest'
        ? 'استراحت و ناهار'
        : 'فعالیت روزانه');

    const newSlot: WeeklySlot = {
      id: 'slot-' + Date.now(),
      startTime: newStartTime,
      endTime: newEndTime,
      title: finalTitle,
      activityType: newActivityType,
      subject: newActivityType === 'study' ? newSubject : undefined,
      gradeLevel: newActivityType === 'study' ? newGradeLevel : undefined,
      topic: newActivityType === 'study' ? newTopic || 'مباحث برنامه' : undefined,
      targetTests: newActivityType === 'study' ? Number(newTargetTests) : undefined,
      isImportant: newIsImportant,
    };

    const updatedSlots = [...currentSlots, newSlot].sort((a, b) =>
      a.startTime.localeCompare(b.startTime)
    );

    const updatedSchedule: Record<DayOfWeek, DaySchedule> = {
      ...schedule,
      [selectedDay]: {
        ...currentDaySchedule,
        slots: updatedSlots,
      },
    };

    onUpdateSchedule(updatedSchedule);
    setShowAddSlotModal(false);
    showToast(`اسلات جدید به روز ${selectedDay} افزوده شد.`, 'success');

    // Reset Form
    setNewTitle('');
    setNewTopic('');
  };

  // Delete Slot
  const handleDeleteSlot = (slotId: string) => {
    const updatedSlots = currentSlots.filter((s) => s.id !== slotId);
    const updatedSchedule: Record<DayOfWeek, DaySchedule> = {
      ...schedule,
      [selectedDay]: {
        ...currentDaySchedule,
        slots: updatedSlots,
      },
    };
    onUpdateSchedule(updatedSchedule);
    showToast('اسلات حذف شد.', 'info');
  };

  // Transfer today's slots to Study Parts
  const handleSyncToTodayParts = () => {
    if (currentSlots.length === 0) {
      showToast('برای این روز برنامه‌ای ثبت نشده است.', 'warning');
      return;
    }
    const studyOnly = currentSlots.filter((s) => s.activityType === 'study');
    if (studyOnly.length === 0) {
      showToast('هیچ پارت مطالعاتی در برنامه این روز وجود ندارد.', 'warning');
      return;
    }
    playChimeSound();
    onSyncDayToParts(studyOnly);
    showToast(
      `⚡ تعداد ${toPersianDigits(studyOnly.length)} پارت با موفقیت به پارت‌های روزانه اضافه شد. آماده مطالعه باشید!`,
      'success'
    );
  };

  // Handle AI generated plan for a day
  const handleApplyAIWeeklySlots = (day: DayOfWeek, slots: WeeklySlot[]) => {
    const updatedSchedule: Record<DayOfWeek, DaySchedule> = {
      ...schedule,
      [day]: {
        day,
        dayType: day === 'پنجشنبه' || day === 'جمعه' ? 'holiday' : 'school',
        slots,
      },
    };
    onUpdateSchedule(updatedSchedule);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Banner: Templates & AI Planner & 1-Click Action */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm relative overflow-hidden">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800 mb-2">
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              <span>برنامه‌های هفتگی و روتین‌های استاندارد کنکور</span>
            </div>
            <h2 className="text-lg sm:text-xl font-black text-slate-900 dark:text-white">
              برنامه هفتگی آماده + هوش مصنوعی مشاور
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1 max-w-2xl leading-relaxed">
              می‌توانید از برنامه‌های آماده استفاده کنید یا شرایط روز و ساعات مدرسه خود را به هوش مصنوعی بگویید تا برنامه دقیق تولید کرده و مستقیماً به پارت‌های درسی منتقل کند.
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-2.5 w-full sm:w-auto">
            {/* AI Assistant Button */}
            <button
              type="button"
              onClick={() => setShowAIPlannerModal(true)}
              className="w-full sm:w-auto px-4 py-3 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white text-xs font-black flex items-center justify-center gap-2 shadow-md hover:scale-[1.02] active:scale-95 transition cursor-pointer"
            >
              <Bot className="w-4 h-4" />
              <span>🤖 برنامه‌ریزی با هوش مصنوعی</span>
            </button>

            {/* 1-Click Sync Button */}
            <button
              type="button"
              onClick={handleSyncToTodayParts}
              className={`w-full sm:w-auto px-5 py-3 rounded-2xl ${theme.primaryBtn} text-xs font-black flex items-center justify-center gap-2 shadow-md hover:scale-[1.02] active:scale-95 transition cursor-pointer`}
            >
              <Zap className="w-4 h-4 fill-current" />
              <span>انتقال برنامه «{selectedDay}» به پارت‌ها</span>
            </button>
          </div>
        </div>

        {/* Ready-made templates selector cards */}
        <div className="mt-5 pt-5 border-t border-slate-100 dark:border-slate-800 grid grid-cols-1 md:grid-cols-3 gap-3">
          {WEEKLY_TEMPLATES.map((tpl) => (
            <div
              key={tpl.id}
              className="bg-slate-50 dark:bg-slate-800/60 rounded-2xl p-4 border border-slate-200 dark:border-slate-700/60 flex flex-col justify-between hover:border-emerald-500/50 transition duration-150"
            >
              <div>
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-white dark:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-600">
                    {tpl.badge}
                  </span>
                  <BookOpen className="w-4 h-4 text-emerald-500" />
                </div>
                <h4 className="font-extrabold text-sm text-slate-900 dark:text-white mt-2">
                  {tpl.title}
                </h4>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                  {tpl.description}
                </p>
              </div>

              <div className="mt-3 pt-3 border-t border-slate-200 dark:border-slate-700/60 flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => handleApplyTemplate(tpl)}
                  className="w-full py-1.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>بارگذاری این برنامه</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Day Selector Navigation (Saturday to Friday) */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-2 border border-slate-200 dark:border-slate-800 shadow-xs">
        <div className="grid grid-cols-7 gap-1.5 sm:gap-2">
          {DAYS_OF_WEEK.map((day) => {
            const isSelected = selectedDay === day;
            const isToday = todayPersian === day;
            const daySlots = schedule[day]?.slots || [];
            const studyCount = daySlots.filter((s) => s.activityType === 'study').length;

            return (
              <button
                key={day}
                type="button"
                onClick={() => setSelectedDay(day)}
                className={`py-2.5 px-1 sm:px-3 rounded-xl text-center transition cursor-pointer flex flex-col items-center justify-center relative ${
                  isSelected
                    ? `${theme.activeNavTab} font-black shadow-xs`
                    : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 font-bold'
                }`}
              >
                {isToday && (
                  <span className="absolute -top-1.5 right-1.5 px-1 rounded text-[9px] font-black bg-rose-500 text-white leading-tight shadow-xs">
                    امروز
                  </span>
                )}
                <span className="text-xs sm:text-sm">{day}</span>
                <span
                  className={`text-[10px] mt-0.5 ${
                    isSelected ? 'text-white/80' : 'text-slate-400 dark:text-slate-500'
                  }`}
                >
                  {toPersianDigits(studyCount)} پارت
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Selected Day Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Schedule Timeline (2 Cols) */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-700 dark:text-slate-300 font-black text-sm">
                📅
              </div>
              <div>
                <h3 className="font-extrabold text-sm sm:text-base text-slate-900 dark:text-white flex items-center gap-2">
                  <span>برنامه روز {selectedDay}</span>
                  {selectedDay === todayPersian && (
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 font-bold">
                      روز جاری
                    </span>
                  )}
                </h3>
                <span className="text-xs text-slate-500 dark:text-slate-400">
                  {toPersianDigits(studySlots.length)} پارت تخصصی ·{' '}
                  {formatMinutesToHoursAndMinutes(totalStudyMinutesSelectedDay)} مطالعه مفید
                  {totalTargetTestsSelectedDay > 0 && ` · ${toPersianDigits(totalTargetTestsSelectedDay)} تست هدف`}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setShowAIPlannerModal(true)}
                className="px-3 py-2 rounded-xl bg-purple-50 hover:bg-purple-100 dark:bg-purple-950/60 dark:hover:bg-purple-900 text-purple-700 dark:text-purple-300 text-xs font-bold flex items-center gap-1.5 border border-purple-200 dark:border-purple-800 transition cursor-pointer"
              >
                <Bot className="w-4 h-4" />
                <span>برنامه‌ریزی هوشمند</span>
              </button>

              <button
                type="button"
                onClick={() => setShowAddSlotModal(true)}
                className={`px-3 py-2 rounded-xl ${theme.primaryBtn} text-xs font-bold flex items-center gap-1.5 shadow-xs transition cursor-pointer`}
              >
                <Plus className="w-4 h-4" />
                <span>افزودن پارت</span>
              </button>
            </div>
          </div>

          {/* Slots List */}
          {currentSlots.length === 0 ? (
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-10 border border-slate-200 dark:border-slate-800 text-center">
              <Calendar className="w-12 h-12 mx-auto text-slate-300 dark:text-slate-600 mb-3" />
              <h4 className="font-extrabold text-slate-700 dark:text-slate-300 text-sm">
                هیچ اسلاتی برای روز {selectedDay} تعریف نشده است
              </h4>
              <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                می‌توانید با دستیار هوش مصنوعی برنامه بنویسید یا از الگوهای آماده استفاده کنید.
              </p>
              <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
                <button
                  type="button"
                  onClick={() => setShowAIPlannerModal(true)}
                  className="px-4 py-2 rounded-xl bg-purple-600 text-white text-xs font-bold flex items-center gap-1 cursor-pointer shadow-xs"
                >
                  <Bot className="w-3.5 h-3.5" />
                  برنامه‌ریزی با هوش مصنوعی
                </button>
                <button
                  type="button"
                  onClick={() => handleApplyTemplate(WEEKLY_TEMPLATES[0])}
                  className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-bold flex items-center gap-1 cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  برنامه روزهای با مدرسه
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-2.5">
              {currentSlots.map((slot) => {
                const duration = calculateSlotMinutes(slot.startTime, slot.endTime);
                const isStudy = slot.activityType === 'study';
                const subjectInfo = slot.subject ? TAJROBI_SUBJECTS_INFO[slot.subject] : null;

                return (
                  <div
                    key={slot.id}
                    className={`rounded-2xl p-4 border transition duration-150 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 ${
                      isStudy
                        ? 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 shadow-2xs'
                        : 'bg-slate-50/70 dark:bg-slate-800/40 border-slate-200/60 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    <div className="flex items-start sm:items-center gap-3 w-full sm:w-auto">
                      {/* Time Badge */}
                      <div className="px-2.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-center shrink-0">
                        <span className="text-xs font-extrabold text-slate-800 dark:text-slate-200 tabular-nums block">
                          {toPersianDigits(slot.startTime)} - {toPersianDigits(slot.endTime)}
                        </span>
                        <span className="text-[10px] text-slate-500 font-bold block">
                          {toPersianDigits(duration)} دقیقه
                        </span>
                      </div>

                      {/* Details */}
                      <div>
                        <div className="flex flex-wrap items-center gap-1.5">
                          {isStudy && slot.subject && (
                            <span
                              className="text-[10px] font-bold px-2 py-0.5 rounded-md text-white"
                              style={{ backgroundColor: subjectInfo?.color || '#059669' }}
                            >
                              {slot.subject}
                            </span>
                          )}
                          {isStudy && slot.gradeLevel && (
                            <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                              پایه {slot.gradeLevel}
                            </span>
                          )}
                          {slot.isImportant && (
                            <span className="text-[10px] font-black text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/60 px-1.5 py-0.5 rounded">
                              ⭐ اولویت بالا
                            </span>
                          )}
                          {!isStudy && (
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300">
                              {slot.activityType === 'school'
                                ? 'مدرسه'
                                : slot.activityType === 'rest'
                                ? 'استراحت'
                                : 'عمومی'}
                            </span>
                          )}
                        </div>

                        <h4 className="font-extrabold text-sm text-slate-900 dark:text-white mt-1">
                          {slot.title}
                        </h4>

                        {slot.topic && isStudy && (
                          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                            مبحث: {slot.topic}
                            {slot.targetTests ? ` · هدف: ${toPersianDigits(slot.targetTests)} تست` : ''}
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                      {isStudy && (
                        <button
                          type="button"
                          onClick={() =>
                            onStartInTimer(
                              slot.subject || 'زیست‌شناسی',
                              slot.topic || slot.title,
                              duration
                            )
                          }
                          className="px-3 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 hover:bg-emerald-100 dark:hover:bg-emerald-900 text-emerald-700 dark:text-emerald-300 text-xs font-bold flex items-center gap-1 transition cursor-pointer border border-emerald-200 dark:border-emerald-800"
                          title="شروع مستقیم این مبحث در تایمر"
                        >
                          <Play className="w-3.5 h-3.5 fill-current" />
                          <span>مطالعه با تایمر</span>
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() => handleDeleteSlot(slot.id)}
                        className="p-1.5 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/50 transition cursor-pointer"
                        title="حذف اسلات"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Weekly Subject Balance Card (1 Col) */}
        <div className="space-y-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs">
            <h3 className="font-extrabold text-sm sm:text-base text-slate-900 dark:text-white flex items-center gap-2">
              <Award className="w-4 h-4 text-amber-500" />
              <span>توازن ساعات دروس در کل هفته</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              مجموع برنامه‌ریزی هفتگی: {formatMinutesToHoursAndMinutes(totalWeeklyStudyMinutes)}
            </p>

            <div className="space-y-3 mt-4">
              {TAJROBI_SUBJECTS_LIST.map((subj) => {
                const mins = weeklySubjectMinutes[subj] || 0;
                const percent =
                  totalWeeklyStudyMinutes > 0
                    ? Math.round((mins / totalWeeklyStudyMinutes) * 100)
                    : 0;
                const info = TAJROBI_SUBJECTS_INFO[subj];

                return (
                  <div key={subj} className="space-y-1">
                    <div className="flex items-center justify-between text-xs font-bold">
                      <span className="text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                        <span
                          className="w-2.5 h-2.5 rounded-full inline-block"
                          style={{ backgroundColor: info?.color || '#059669' }}
                        />
                        {subj}
                      </span>
                      <span className="text-slate-500 dark:text-slate-400 tabular-nums">
                        {toPersianDigits(mins > 0 ? (mins / 60).toFixed(1) : '0')} ساعت ({toPersianDigits(percent)}%)
                      </span>
                    </div>
                    <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-300"
                        style={{
                          width: `${percent}%`,
                          backgroundColor: info?.color || '#059669',
                        }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="mt-5 p-3 rounded-xl bg-purple-50 dark:bg-purple-950/40 border border-purple-200 dark:border-purple-800/60 text-xs text-purple-900 dark:text-purple-300 leading-relaxed">
              🤖 <strong>دستیار هوش مصنوعی:</strong> برای بهینه‌سازی برنامه و تطبیق با امتحانات نهایی و آزمون‌های آزمایشی، کافی است دکمه «برنامه‌ریزی با هوش مصنوعی» را بزنید.
            </div>
          </div>
        </div>
      </div>

      {/* AI Study Planner Modal */}
      <AIStudyPlannerModal
        isOpen={showAIPlannerModal}
        onClose={() => setShowAIPlannerModal(false)}
        theme={theme}
        topicMemories={topicMemories}
        onSaveTopicMemory={onSaveTopicMemory}
        onApplyPlanToParts={(parts) => {
          onSyncDayToParts(
            parts.map((p, idx) => ({
              id: 'slot-ai-' + Date.now() + '-' + idx,
              startTime: p.scheduledTime || '16:00',
              endTime: '17:30',
              title: p.courseName,
              activityType: 'study',
              subject: p.category,
              gradeLevel: p.gradeLevel,
              topic: p.topic,
              targetTests: p.testCount,
              isImportant: p.priority === 'high',
            }))
          );
        }}
        onApplyWeeklySchedule={onUpdateSchedule}
        showToast={showToast}
      />

      {/* Add Slot Modal */}
      {showAddSlotModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 max-w-lg w-full shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3 mb-4">
              <h3 className="font-extrabold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <Plus className="w-4 h-4 text-emerald-500" />
                افزودن پارت / اسلات به روز {selectedDay}
              </h3>
              <button
                onClick={() => setShowAddSlotModal(false)}
                className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-slate-800 dark:hover:text-white flex items-center justify-center text-xs"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddSlot} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    زمان شروع
                  </label>
                  <input
                    type="time"
                    value={newStartTime}
                    onChange={(e) => setNewStartTime(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-800 dark:text-slate-200 text-center"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    زمان پایان
                  </label>
                  <input
                    type="time"
                    value={newEndTime}
                    onChange={(e) => setNewEndTime(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-800 dark:text-slate-200 text-center"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  نوع فعالیت
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'study' as const, label: '📚 پارت مطالعه' },
                    { id: 'school' as const, label: '🏫 مدرسه / کلاس' },
                    { id: 'rest' as const, label: '☕ استراحت / ناهار' },
                  ].map((t) => (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() => setNewActivityType(t.id)}
                      className={`py-2 px-2 rounded-xl text-xs font-bold border transition cursor-pointer ${
                        newActivityType === t.id
                          ? 'bg-emerald-500 text-white border-emerald-600'
                          : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                      }`}
                    >
                      {t.label}
                    </button>
                  ))}
                </div>
              </div>

              {newActivityType === 'study' && (
                <>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                        درس اختصاصی
                      </label>
                      <select
                        value={newSubject}
                        onChange={(e) => setNewSubject(e.target.value as TajrobiSubject)}
                        className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-800 dark:text-slate-200"
                      >
                        {TAJROBI_SUBJECTS_LIST.map((s) => (
                          <option key={s} value={s}>
                            {s}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                        پایه تحصیلی
                      </label>
                      <select
                        value={newGradeLevel}
                        onChange={(e) => setNewGradeLevel(e.target.value as GradeLevel)}
                        className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-800 dark:text-slate-200"
                      >
                        <option value="دوازدهم">دوازدهم</option>
                        <option value="یازدهم">یازدهم</option>
                        <option value="دهم">دهم</option>
                        <option value="جامع">جامع</option>
                        <option value="عمومی و نهایی">عمومی و نهایی</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      مبحث و فصل درس
                    </label>
                    <input
                      type="text"
                      value={newTopic}
                      onChange={(e) => setNewTopic(e.target.value)}
                      placeholder="مثال: فصل ۳ ژنتیک و تقسیم یاخته / استوکیومتری"
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-200 placeholder-slate-400"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3 items-center">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                        تعداد تست هدف
                      </label>
                      <input
                        type="number"
                        min="0"
                        max="200"
                        value={newTargetTests}
                        onChange={(e) => setNewTargetTests(Number(e.target.value))}
                        className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-800 dark:text-slate-200"
                      />
                    </div>
                    <div className="pt-5">
                      <label className="inline-flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={newIsImportant}
                          onChange={(e) => setNewIsImportant(e.target.checked)}
                          className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500"
                        />
                        <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
                          ⭐ پارت با اولویت بالا
                        </span>
                      </label>
                    </div>
                  </div>
                </>
              )}

              {newActivityType !== 'study' && (
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    عنوان فعالیت
                  </label>
                  <input
                    type="text"
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    placeholder="مثال: حضور در مدرسه، استراحت، کلاس کنکور"
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-200"
                  />
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddSlotModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-xs font-bold cursor-pointer"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  className={`px-5 py-2 rounded-xl ${theme.primaryBtn} text-xs font-black cursor-pointer`}
                >
                  افزودن اسلات
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
