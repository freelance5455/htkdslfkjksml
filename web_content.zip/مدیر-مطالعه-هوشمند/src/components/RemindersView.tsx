import React, { useState } from 'react';
import {
  DayOfWeek,
  ReminderCategory,
  StudyReminder,
  ThemeConfig,
} from '../types';
import {
  DAYS_OF_WEEK,
  REMINDER_CATEGORIES_META,
  getDefaultReminders,
  playChimeSound,
  toPersianDigits,
} from '../utils/tajrobiData';
import {
  Bell,
  Clock,
  Plus,
  Trash2,
  Volume2,
  VolumeX,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  RotateCcw,
} from 'lucide-react';

interface RemindersViewProps {
  reminders: StudyReminder[];
  theme: ThemeConfig;
  onUpdateReminders: (reminders: StudyReminder[]) => void;
  onShowToast: (message: string, type?: 'success' | 'warning' | 'info') => void;
}

export const RemindersView: React.FC<RemindersViewProps> = ({
  reminders,
  theme,
  onUpdateReminders,
  onShowToast,
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newTime, setNewTime] = useState('07:30');
  const [newCategory, setNewCategory] = useState<ReminderCategory>('study');
  const [newDescription, setNewDescription] = useState('');
  const [newSoundEnabled, setNewSoundEnabled] = useState(true);
  const [newRepeatDays, setNewRepeatDays] = useState<DayOfWeek[]>([...DAYS_OF_WEEK]);

  // Toggle enable
  const handleToggleEnable = (id: string) => {
    const updated = reminders.map((r) =>
      r.id === id ? { ...r, enabled: !r.enabled } : r
    );
    onUpdateReminders(updated);
  };

  // Toggle sound
  const handleToggleSound = (id: string) => {
    const updated = reminders.map((r) =>
      r.id === id ? { ...r, soundEnabled: !r.soundEnabled } : r
    );
    onUpdateReminders(updated);
    playChimeSound();
  };

  // Delete
  const handleDelete = (id: string) => {
    const updated = reminders.filter((r) => r.id !== id);
    onUpdateReminders(updated);
    onShowToast('یادآور حذف شد.', 'info');
  };

  // Reset to defaults
  const handleResetDefaults = () => {
    const defaults = getDefaultReminders();
    onUpdateReminders(defaults);
    onShowToast('یادآورهای استاندارد کنکور بازنشانی شدند.', 'success');
  };

  // Add new
  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const newReminder: StudyReminder = {
      id: 'rem-' + Date.now(),
      title: newTitle.trim(),
      time: newTime,
      category: newCategory,
      description: newDescription.trim() || undefined,
      enabled: true,
      soundEnabled: newSoundEnabled,
      repeatDays: newRepeatDays.length > 0 ? newRepeatDays : [...DAYS_OF_WEEK],
    };

    onUpdateReminders([...reminders, newReminder]);
    setShowAddModal(false);
    setNewTitle('');
    setNewDescription('');
    onShowToast(`یادآور «${newReminder.title}» تنظیم شد ⏰`, 'success');
  };

  const toggleDaySelection = (day: DayOfWeek) => {
    if (newRepeatDays.includes(day)) {
      setNewRepeatDays(newRepeatDays.filter((d) => d !== day));
    } else {
      setNewRepeatDays([...newRepeatDays, day]);
    }
  };

  const activeCount = reminders.filter((r) => r.enabled).length;

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Banner */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-2xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800 mb-2">
            <Sparkles className="w-3.5 h-3.5 text-purple-500" />
            <span>سامانه هوشمند هشدار و یادآوری پارت‌های کنکور</span>
          </div>
          <h2 className="text-lg sm:text-xl font-black text-slate-900 dark:text-white">
            یادآورها و هشدارهای صوتی مطالعه
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            {toPersianDigits(activeCount)} یادآور فعال از مجموع {toPersianDigits(reminders.length)} هشدار تنظیم‌شده
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleResetDefaults}
            className="px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-xs font-bold flex items-center gap-1.5 transition cursor-pointer hover:bg-slate-200"
            title="بازنشانی به هشدارهای پیشنهادی کنکور"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>پیش‌فرض‌ها</span>
          </button>

          <button
            type="button"
            onClick={() => setShowAddModal(true)}
            className={`px-4 py-2.5 rounded-xl ${theme.primaryBtn} text-xs font-black flex items-center gap-2 shadow-xs transition cursor-pointer`}
          >
            <Plus className="w-4 h-4" />
            <span>افزودن یادآور جدید</span>
          </button>
        </div>
      </div>

      {/* Reminders List */}
      <div className="space-y-3">
        {reminders.map((rem) => {
          const catMeta = REMINDER_CATEGORIES_META[rem.category] || REMINDER_CATEGORIES_META.study;

          return (
            <div
              key={rem.id}
              className={`rounded-2xl p-4.5 border transition flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 ${
                rem.enabled
                  ? 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 shadow-2xs'
                  : 'bg-slate-50/60 dark:bg-slate-800/30 border-slate-200/50 dark:border-slate-800/50 opacity-60'
              }`}
            >
              <div className="flex items-start sm:items-center gap-3.5 w-full sm:w-auto">
                <div className="px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-center shrink-0">
                  <span className="text-base font-black text-slate-900 dark:text-white tabular-nums block">
                    {toPersianDigits(rem.time)}
                  </span>
                  <span className="text-[10px] text-slate-500 font-bold block">
                    {catMeta.icon} {catMeta.label.slice(0, 7)}
                  </span>
                </div>

                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="font-extrabold text-sm text-slate-900 dark:text-white">
                      {rem.title}
                    </h4>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${catMeta.badgeClass}`}
                    >
                      {catMeta.label}
                    </span>
                  </div>

                  {rem.description && (
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 font-medium leading-relaxed">
                      {rem.description}
                    </p>
                  )}

                  <div className="flex items-center gap-1 mt-2">
                    <span className="text-[10px] text-slate-400">تکرار در روزهای:</span>
                    <span className="text-[10px] font-bold text-slate-600 dark:text-slate-300">
                      {rem.repeatDays.length === 7 ? 'همه روزها' : rem.repeatDays.join('، ')}
                    </span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                {/* Sound Toggle */}
                <button
                  type="button"
                  onClick={() => handleToggleSound(rem.id)}
                  className={`p-2 rounded-xl border transition cursor-pointer ${
                    rem.soundEnabled
                      ? 'bg-emerald-50 text-emerald-600 border-emerald-200 dark:bg-emerald-950/60 dark:border-emerald-800'
                      : 'bg-slate-100 text-slate-400 border-slate-200 dark:bg-slate-800 dark:border-slate-700'
                  }`}
                  title={rem.soundEnabled ? 'زنگ صوتی فعال است' : 'زنگ صوتی بی‌صدا'}
                >
                  {rem.soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
                </button>

                {/* Enable Switch */}
                <button
                  type="button"
                  onClick={() => handleToggleEnable(rem.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                    rem.enabled
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {rem.enabled ? 'فعال' : 'غیرفعال'}
                </button>

                {/* Delete */}
                <button
                  type="button"
                  onClick={() => handleDelete(rem.id)}
                  className="p-2 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/50 transition cursor-pointer"
                  title="حذف یادآور"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 max-w-lg w-full shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3 mb-4">
              <h3 className="font-extrabold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <Bell className="w-4 h-4 text-purple-500" />
                افزودن یادآور و هشدار مطالعه
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-slate-800 dark:hover:text-white flex items-center justify-center text-xs"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  عنوان یادآور
                </label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="مثال: شروع پارت طلایی زیست دوازدهم"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-200 font-bold"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    ساعت هشدار
                  </label>
                  <input
                    type="time"
                    value={newTime}
                    onChange={(e) => setNewTime(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-800 dark:text-slate-200 text-center"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    دسته‌بندی
                  </label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as ReminderCategory)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-800 dark:text-slate-200"
                  >
                    {Object.entries(REMINDER_CATEGORIES_META).map(([key, meta]) => (
                      <option key={key} value={key}>
                        {meta.icon} {meta.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  توضیحات و نکات مطالعه (اختیاری)
                </label>
                <textarea
                  value={newDescription}
                  onChange={(e) => setNewDescription(e.target.value)}
                  placeholder="مثال: بررسی شکل‌های فصل ۴ و حل ۲۰ تست زمان‌دار..."
                  rows={2}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-200"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  روزهای تکرار
                </label>
                <div className="grid grid-cols-7 gap-1">
                  {DAYS_OF_WEEK.map((day) => {
                    const isSelected = newRepeatDays.includes(day);
                    return (
                      <button
                        key={day}
                        type="button"
                        onClick={() => toggleDaySelection(day)}
                        className={`py-1.5 rounded-lg text-[10px] font-bold transition cursor-pointer ${
                          isSelected
                            ? 'bg-purple-600 text-white shadow-xs'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                        }`}
                      >
                        {day}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="pt-2">
                <label className="inline-flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={newSoundEnabled}
                    onChange={(e) => setNewSoundEnabled(e.target.checked)}
                    className="w-4 h-4 rounded text-purple-600 focus:ring-purple-500"
                  />
                  <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
                    پخش زنگ ملایم پیانو هنگام رسیدن زمان
                  </span>
                </label>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-xs font-bold cursor-pointer"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  className={`px-5 py-2 rounded-xl ${theme.primaryBtn} text-xs font-black cursor-pointer`}
                >
                  ذخیره یادآور
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
