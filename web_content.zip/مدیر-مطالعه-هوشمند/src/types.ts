export type TajrobiSubject =
  | 'زیست‌شناسی'
  | 'شیمی'
  | 'فیزیک'
  | 'ریاضی تجربی'
  | 'زمین‌شناسی'
  | 'امتحانات نهایی / عمومی';

export type Priority = 'high' | 'medium' | 'low';

export type GradeLevel = 'دهم' | 'یازدهم' | 'دوازدهم' | 'جامع' | 'عمومی و نهایی';

export type DayOfWeek =
  | 'شنبه'
  | 'یکشنبه'
  | 'دوشنبه'
  | 'سه‌شنبه'
  | 'چهارشنبه'
  | 'پنجشنبه'
  | 'جمعه';

export type ActiveTab =
  | 'dashboard'
  | 'schedule'
  | 'annual'
  | 'lookAhead'
  | 'parts'
  | 'timer'
  | 'memory'
  | 'reports'
  | 'settings'
  | 'reminders'
  | 'compensations'
  | 'charts'
  | 'history'
  | 'blocks'
  | 'stats'
  | 'exams'
  | 'diagnostics'
  | 'notes';

export type ActivityType =
  | 'study'
  | 'sleep'
  | 'school'
  | 'school_class'
  | 'wasted'
  | 'rest'
  | 'personal'
  | 'compensation';

export interface TimeBlock {
  id: number;
  blockNumber?: number;
  startTime?: string;
  endTime?: string;
  timeRange: string; // e.g. "06:00 - 07:30"
  label: string;
  activityType: ActivityType;
  subject?: TajrobiSubject;
  topic?: string;
  note?: string;
  testCount?: number;
}

export interface StudyPart {
  id: string;
  category: TajrobiSubject;
  gradeLevel?: GradeLevel;
  courseName: string;
  topic: string;
  bookSource: string;
  estimatedMinutes: number;
  actualMinutes: number;
  scheduledTime: string; // "HH:MM"
  completed: boolean;
  testCount: number;
  correctTests?: number;
  wrongTests?: number;
  priority: Priority;
  dayOfWeek: DayOfWeek;
  createdAt: string;
  lastStudiedDate?: string;
}

export interface CompensationTask {
  id: string;
  subject: TajrobiSubject;
  gradeLevel?: GradeLevel;
  topic: string;
  bookSource?: string;
  plannedMinutes: number;
  completedMinutes: number;
  remainingMinutes: number; // deficit
  date: string;
  resolved: boolean;
  notes?: string;
}

export interface StudyLog {
  id: string;
  partId?: string;
  subject: TajrobiSubject;
  gradeLevel?: GradeLevel;
  topic: string;
  bookSource: string;
  durationMinutes: number;
  totalTests: number;
  correctTests: number;
  wrongTests: number;
  blankTests: number;
  accuracyPercentage: number;
  completedFully: boolean;
  date: string;         // ISO YYYY-MM-DD
  jalaliDate: string;   // e.g. "۱۴ مهر ۱۴۰۵"
  monthLabel: string;   // e.g. "مهر", "آبان", "آذر", ...
  timestamp: string;
  startedLate?: boolean;
  notes?: string;
}

export interface ExamCountdownItem {
  id: string;
  title: string;
  targetDate: string; // ISO date string YYYY-MM-DD
  targetJalali: string;
  type: 'konkur' | 'final_exam' | 'mock_exam';
  description?: string;
  color: string;
}

export interface DiagnosticFlaw {
  principle: string;
  issue: string;
  globalSolution: string;
  severity: 'high' | 'medium' | 'low';
}

export interface DailyDiagnosticReport {
  date: string;
  jalaliDate: string;
  qualityScore: number;
  flaws: DiagnosticFlaw[];
  activeRecallRatio: number;
  interleavingScore: number;
  selfFocusRating?: number;
  nightNotes?: string;
}

export interface DailyNote {
  id: string;
  title: string;
  content: string;
  date: string;
  important: boolean;
  done: boolean;
}

export type AppTheme = 'emerald' | 'sapphire' | 'amber' | 'violet' | 'rose' | 'cyan';

export interface ThemeConfig {
  id: AppTheme;
  name: string;
  englishName: string;
  badge: string;
  accentColor: string;
  primaryBtn: string;
  ringColor: string;
  badgeBg: string;
  headerGrad: string;
  activeNavTab: string;
  borderAccent: string;
  subtleBg: string;
  cardGlow: string;
}

export type ReminderCategory = 'study' | 'test' | 'review' | 'sleep' | 'health' | 'diagnostic';

export interface StudyReminder {
  id: string;
  title: string;
  time: string;           // "HH:MM"
  category: ReminderCategory;
  description?: string;
  enabled: boolean;
  soundEnabled: boolean;
  repeatDays: DayOfWeek[];
  gradeLevel?: GradeLevel;
  subject?: TajrobiSubject;
  lastTriggeredDate?: string;
}

export interface WeeklySlot {
  id: string;
  startTime: string;      // "07:30"
  endTime: string;        // "09:00"
  title: string;
  activityType: ActivityType;
  subject?: TajrobiSubject;
  gradeLevel?: GradeLevel;
  topic?: string;
  targetTests?: number;
  isImportant?: boolean;
}

export interface DaySchedule {
  day: DayOfWeek;
  dayType: 'school' | 'holiday' | 'exam_prep';
  titleNotes?: string;
  slots: WeeklySlot[];
}

export interface WeeklyScheduleTemplate {
  id: string;
  title: string;
  badge: string;
  description: string;
  targetAudience: string;
  sampleDayType: 'school' | 'holiday' | 'exam_prep';
  schedule: Record<DayOfWeek, DaySchedule>;
}

export interface TopicMemoryItem {
  id: string;
  subject: TajrobiSubject;
  gradeLevel: GradeLevel;
  topic: string;
  firstStudiedDate: string; // ISO date YYYY-MM-DD
  lastStudiedDate: string;  // ISO date
  reviewLevel: number;      // 1 (Day 1), 2 (Day 3), 3 (Day 7), 4 (Day 15), 5 (Day 30 - Mastered)
  nextReviewDate: string;   // ISO date YYYY-MM-DD
  nextReviewJalali: string; // e.g. "۱۵ مهر"
  masteryScore: number;     // 0 - 100%
  totalTestsDone: number;
  totalStudyMinutes: number;
  notes?: string;
  isOverdue?: boolean;
}

export interface MonthlyPlanWeek {
  weekNumber: number; // 1, 2, 3, 4
  title: string;
  focusGoal: string;
  targetHours: number;
  targetTests: number;
  subjectsSummary: Record<TajrobiSubject, string>;
  keyMilestones: string[];
  scheduledReviews: Array<{ topic: string; subject: TajrobiSubject; intervalDays: number; dateNote: string }>;
}

export interface MonthlyPlanRoadmap {
  id: string;
  monthName: string;
  targetGoal: string;
  schoolHoursPerDay: number;
  dailyAvailableHours: number;
  weeks: MonthlyPlanWeek[];
  spacedReviewTopics: string[];
}

export interface SyllabusChapterItem {
  id: string;
  subject: TajrobiSubject;
  gradeLevel: GradeLevel;
  chapterNumber: number;
  chapterTitle: string;
  isCompleted: boolean;
  testCountDone: number;
  targetMonth: string; // e.g. "مهر", "آبان", "اسفند"
  reviewFrequency: number;
}

export interface AnnualMonthStrategy {
  id: string;
  monthIndex: number; // 1 to 9 (Mehr to Khordad/Tir)
  monthName: string;   // مهر, آبان, آذر, دی, بهمن, اسفند, فروردین, اردیبهشت, خرداد
  season: 'پاییز' | 'زمستان' | 'بهار' | 'جمع‌بندی';
  phaseTitle: string; // e.g. "فاز ۱: استارت پایه و دوازدهم", "فاز پایانی تا اسفند: اتمام ۱۰۰٪ کل دروس"
  targetGoal: string;
  isMilestoneEsfand?: boolean;
  targetMonthlyHours: number;
  targetMonthlyTests: number;
  grade10Coverage: Record<string, string>; // subject -> chapters covered
  grade11Coverage: Record<string, string>; // subject -> chapters covered
  grade12Coverage: Record<string, string>; // subject -> chapters covered
  scientificMethods: string[];            // e.g. ['مرور ابینگهاوس روز ۱، ۳ و ۷', 'بازیابی فعال تستی', 'اینترلیوینگ شیمی/ریاضی']
  compensationDays: string;              // e.g. 'پنجشنبه‌های پایان هر دو هفته'
  milestones: string[];
  reviewSchedules?: Array<{ interval: string; description: string; dateNote: string }>;
}

export interface AnnualPlanRoadmap {
  id: string;
  title: string;
  academicYear: string;
  targetDeadline: string; // "۲۹ اسفند ماه - اتمام کل مباحث پایه و دوازدهم"
  overallGoal: string;
  studentLevel: 'starter' | 'intermediate' | 'advanced';
  totalTargetTests: number;
  totalTargetHours: number;
  months: AnnualMonthStrategy[];
  scientificFrameworkSummary: string[];
  syllabusChapters: SyllabusChapterItem[];
}

export interface UserSettings {
  studentName: string;
  examTitle: string;
  examDate: string;
  dailyTestGoal: number;
  weeklyStudyMinutesGoal: number;
  notificationsEnabled: boolean;
  darkMode: boolean;
  countdownMode: boolean;
  theme: AppTheme;
  weekStartDay?: DayOfWeek; // 'یکشنبه' by default
  tabOrder?: ActiveTab[];
}

export interface AppState {
  activeTab: ActiveTab;
  currentTab?: ActiveTab;
  parts: StudyPart[];
  blocks: TimeBlock[];
  compensations: CompensationTask[];
  studyLogs: StudyLog[];
  exams: ExamCountdownItem[];
  notes: DailyNote[];
  diagnosticReports: DailyDiagnosticReport[];
  settings: UserSettings;
  reminders: StudyReminder[];
  weeklySchedule: Record<DayOfWeek, DaySchedule>;
  topicMemories?: TopicMemoryItem[];
  monthlyPlan?: MonthlyPlanRoadmap;
  annualPlan?: AnnualPlanRoadmap;
  xp: number;
}

export interface ToastMessage {
  id: string;
  title: string;
  description?: string;
  type: 'success' | 'warning' | 'info' | 'error';
}
