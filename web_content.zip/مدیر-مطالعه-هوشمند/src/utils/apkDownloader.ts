import JSZip from 'jszip';

/**
 * Downloads the ready-to-use APK-compatible ZIP bundle.
 * This ZIP contains the completely inlined, non-module, zero-CORS index.html,
 * manifest, icons, and Persian instructions for Website 2 APK and Web2Apk builders.
 */
export async function downloadApkReadyZip(): Promise<boolean> {
  const zipUrl = './tajrobi-planner-apk-ready.zip';

  try {
    const res = await fetch(zipUrl, { method: 'HEAD' });
    if (res.ok) {
      const a = document.createElement('a');
      a.href = zipUrl;
      a.download = 'tajrobi-planner-apk-ready.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      return true;
    }
  } catch (err) {
    console.warn('Direct zip fetch failed, falling back to dynamic zip packaging:', err);
  }

  // Fallback: Generate ZIP dynamically in browser using JSZip
  try {
    const zip = new JSZip();

    // 1. Fetch the standalone HTML
    let htmlContent = '';
    try {
      const htmlRes = await fetch('./index-apk.html');
      if (htmlRes.ok) {
        htmlContent = await htmlRes.text();
      }
    } catch {
      // ignore
    }

    if (!htmlContent) {
      try {
        const htmlRes = await fetch('./dist/index.html');
        if (htmlRes.ok) {
          htmlContent = await htmlRes.text();
        }
      } catch {
        // ignore
      }
    }

    if (!htmlContent) {
      // If unable to fetch compiled bundle, extract clean HTML from current DOM
      htmlContent = document.documentElement.outerHTML;
    }

    // Clean up any remaining module/CORS tags
    htmlContent = htmlContent.replace(/<script\s+type=["']module["']\s+crossorigin>/gi, '<script>');
    htmlContent = htmlContent.replace(/<script\s+type=["']module["']>/gi, '<script>');
    htmlContent = htmlContent.replace(/<link\s+rel=["']modulepreload["'][^>]*>/gi, '');

    zip.file('index.html', htmlContent);
    zip.file('app.html', htmlContent);

    // 2. Fetch manifest if available
    try {
      const manifestRes = await fetch('./manifest.json');
      if (manifestRes.ok) {
        zip.file('manifest.json', await manifestRes.text());
      }
    } catch {
      // ignore
    }

    // 3. Add Persian guide
    const guide = `راهنمای ساخت APK بدون صفحه سفید:
۱. این فایل زیپ حاوی فایل index.html مستقل و کامپایل‌شده است.
۲. در نرم‌افزار Website 2 APK Builder حالت Local HTML Website را انتخاب کنید.
۳. این پوشه را انتخاب کرده و مطمئن شوید DOM Storage فعال است.
۴. کلید Generate APK را بزنید تا برنامه با سرعت و بدون صفحه سفید اجرا شود.`;

    zip.file('راهنمای_تبدیل_به_APK.txt', guide);

    const blob = await zip.generateAsync({ type: 'blob' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'tajrobi-planner-apk-ready.zip';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 10000);
    return true;
  } catch (err) {
    console.error('Failed to create APK ZIP in browser:', err);
    // Last resort fallback: direct link trigger
    const a = document.createElement('a');
    a.href = './tajrobi-planner-apk-ready.zip';
    a.download = 'tajrobi-planner-apk-ready.zip';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    return true;
  }
}

/**
 * Downloads just the standalone compiled HTML file (index.html)
 */
export async function downloadApkStandaloneHtml(): Promise<boolean> {
  try {
    let htmlContent = '';
    const res = await fetch('./index-apk.html');
    if (res.ok) {
      htmlContent = await res.text();
    } else {
      const distRes = await fetch('./dist/index.html');
      if (distRes.ok) {
        htmlContent = await distRes.text();
      }
    }

    if (!htmlContent) {
      htmlContent = document.documentElement.outerHTML;
    }

    const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'index.html';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 10000);
    return true;
  } catch (err) {
    console.error('Failed to download standalone HTML:', err);
    window.open('./index-apk.html', '_blank');
    return false;
  }
}
