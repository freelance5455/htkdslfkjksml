import {
  ActivityType,
  AnnualMonthStrategy,
  AnnualPlanRoadmap,
  AppState,
  AppTheme,
  DailyDiagnosticReport,
  DayOfWeek,
  DaySchedule,
  DiagnosticFlaw,
  ExamCountdownItem,
  GradeLevel,
  MonthlyPlanRoadmap,
  MonthlyPlanWeek,
  Priority,
  ReminderCategory,
  StudyLog,
  StudyPart,
  StudyReminder,
  SyllabusChapterItem,
  TajrobiSubject,
  ThemeConfig,
  TimeBlock,
  TopicMemoryItem,
  WeeklyScheduleTemplate,
  WeeklySlot,
} from '../types';

export const DAYS_OF_WEEK: DayOfWeek[] = [
  'یکشنبه',
  'دوشنبه',
  'سه‌شنبه',
  'چهارشنبه',
  'پنجشنبه',
  'جمعه',
  'شنبه',
];

export const GRADE_LEVELS: GradeLevel[] = [
  'دهم',
  'یازدهم',
  'دوازدهم',
  'جامع',
  'عمومی و نهایی',
];

export const GRADE_META: Record<
  GradeLevel,
  { label: string; shortLabel: string; color: string; bgColor: string; borderColor: string; badgeClass: string }
> = {
  'دهم': {
    label: 'پایه دهم (پایه کنکور)',
    shortLabel: 'دهم',
    color: '#0d9488',
    bgColor: 'bg-teal-50 dark:bg-teal-950/40',
    borderColor: 'border-teal-300 dark:border-teal-700',
    badgeClass: 'bg-teal-100 text-teal-800 dark:bg-teal-900/50 dark:text-teal-200',
  },
  'یازدهم': {
    label: 'پایه یازدهم (تثبیت و تسلط)',
    shortLabel: 'یازدهم',
    color: '#8b5cf6',
    bgColor: 'bg-purple-50 dark:bg-purple-950/40',
    borderColor: 'border-purple-300 dark:border-purple-700',
    badgeClass: 'bg-purple-100 text-purple-800 dark:bg-purple-900/50 dark:text-purple-200',
  },
  'دوازدهم': {
    label: 'پایه دوازدهم (کنکور + نهایی)',
    shortLabel: 'دوازدهم',
    color: '#2563eb',
    bgColor: 'bg-blue-50 dark:bg-blue-950/40',
    borderColor: 'border-blue-300 dark:border-blue-700',
    badgeClass: 'bg-blue-100 text-blue-800 dark:bg-blue-900/50 dark:text-blue-200',
  },
  'جامع': {
    label: 'کنکور جامع و ترکیبی',
    shortLabel: 'جامع',
    color: '#d97706',
    bgColor: 'bg-amber-50 dark:bg-amber-950/40',
    borderColor: 'border-amber-300 dark:border-amber-700',
    badgeClass: 'bg-amber-100 text-amber-800 dark:bg-amber-900/50 dark:text-amber-200',
  },
  'عمومی و نهایی': {
    label: 'امتحانات نهایی دوازدهم',
    shortLabel: 'نهایی',
    color: '#059669',
    bgColor: 'bg-emerald-50 dark:bg-emerald-950/40',
    borderColor: 'border-emerald-300 dark:border-emerald-700',
    badgeClass: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/50 dark:text-emerald-200',
  },
};

export const PRIORITY_LABELS: Record<
  Priority,
  { label: string; color: string; badgeClass: string; borderClass?: string }
> = {
  high: {
    label: 'ضروری و فوری (ضریب بالا)',
    color: '#dc2626',
    badgeClass: 'bg-red-100 text-red-700 dark:bg-red-950/60 dark:text-red-300 border-red-200 dark:border-red-900/50',
  },
  medium: {
    label: 'اولویت متوسط',
    color: '#d97706',
    badgeClass: 'bg-amber-100 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300 border-amber-200 dark:border-amber-900/50',
  },
  low: {
    label: 'اولویت روتین',
    color: '#059669',
    badgeClass: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border-emerald-200 dark:border-emerald-900/50',
  },
};

export const ACTIVITY_META: Record<
  ActivityType,
  { label: string; color: string; bgClass: string; textClass: string; isProductive: boolean; isWasted: boolean; isSleep: boolean; badge?: string; icon?: string; borderClass?: string }
> = {
  study: {
    label: 'مطالعه کنکوری و تست',
    color: '#0d9488',
    bgClass: 'bg-teal-500/15 border-teal-500/40',
    textClass: 'text-teal-700 dark:text-teal-300',
    isProductive: true,
    isWasted: false,
    isSleep: false,
  },
  compensation: {
    label: 'جبران پارت نصفه',
    color: '#d97706',
    bgClass: 'bg-amber-500/20 border-amber-500/50',
    textClass: 'text-amber-800 dark:text-amber-300',
    isProductive: true,
    isWasted: false,
    isSleep: false,
  },
  school: {
    label: 'مدرسه و کلاس درس',
    color: '#3b82f6',
    bgClass: 'bg-blue-500/15 border-blue-500/40',
    textClass: 'text-blue-700 dark:text-blue-300',
    isProductive: false,
    isWasted: false,
    isSleep: false,
  },
  school_class: {
    label: 'مدرسه و کلاس درس',
    color: '#3b82f6',
    bgClass: 'bg-blue-500/15 border-blue-500/40',
    textClass: 'text-blue-700 dark:text-blue-300',
    isProductive: false,
    isWasted: false,
    isSleep: false,
  },
  sleep: {
    label: 'خواب و استراحت شبانه',
    color: '#6366f1',
    bgClass: 'bg-indigo-500/15 border-indigo-500/40',
    textClass: 'text-indigo-700 dark:text-indigo-300',
    isProductive: false,
    isWasted: false,
    isSleep: true,
  },
  wasted: {
    label: 'تایم پرتی و هدررفته',
    color: '#ef4444',
    bgClass: 'bg-red-500/20 border-red-500/50',
    textClass: 'text-red-700 dark:text-red-300',
    isProductive: false,
    isWasted: true,
    isSleep: false,
  },
  rest: {
    label: 'استراحت و تغذیه',
    color: '#10b981',
    bgClass: 'bg-emerald-500/15 border-emerald-500/40',
    textClass: 'text-emerald-700 dark:text-emerald-300',
    isProductive: false,
    isWasted: false,
    isSleep: false,
  },
  personal: {
    label: 'کارهای شخصی و خانواده',
    color: '#64748b',
    bgClass: 'bg-slate-500/15 border-slate-500/40',
    textClass: 'text-slate-700 dark:text-slate-300',
    isProductive: false,
    isWasted: false,
    isSleep: false,
  },
};

export const THEME_CONFIGS: Record<AppTheme, ThemeConfig> = {
  emerald: {
    id: 'emerald',
    name: 'سبز زمردی (تمرکز و آرامش)',
    englishName: 'Emerald Focus',
    badge: 'زمردی',
    accentColor: '#059669',
    primaryBtn: 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-600/30',
    ringColor: 'ring-emerald-500',
    badgeBg: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300',
    headerGrad: 'from-emerald-900 via-teal-900 to-slate-950',
    activeNavTab: 'bg-emerald-600 text-white shadow-md',
    borderAccent: 'border-emerald-500/40',
    subtleBg: 'bg-emerald-50/50 dark:bg-emerald-950/20',
    cardGlow: 'shadow-emerald-500/5',
  },
  sapphire: {
    id: 'sapphire',
    name: 'یاقوت کبود (انرژی عمیق)',
    englishName: 'Sapphire Deep',
    badge: 'یاقوت کبود',
    accentColor: '#2563eb',
    primaryBtn: 'bg-blue-600 hover:bg-blue-700 text-white shadow-blue-600/30',
    ringColor: 'ring-blue-500',
    badgeBg: 'bg-blue-100 text-blue-800 dark:bg-blue-950/60 dark:text-blue-300',
    headerGrad: 'from-blue-950 via-indigo-900 to-slate-950',
    activeNavTab: 'bg-blue-600 text-white shadow-md',
    borderAccent: 'border-blue-500/40',
    subtleBg: 'bg-blue-50/50 dark:bg-blue-950/20',
    cardGlow: 'shadow-blue-500/5',
  },
  amber: {
    id: 'amber',
    name: 'کهربایی زرین (انگیزه و نشاط)',
    englishName: 'Amber Glow',
    badge: 'کهربایی',
    accentColor: '#d97706',
    primaryBtn: 'bg-amber-600 hover:bg-amber-700 text-white shadow-amber-600/30',
    ringColor: 'ring-amber-500',
    badgeBg: 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300',
    headerGrad: 'from-amber-950 via-amber-900 to-slate-950',
    activeNavTab: 'bg-amber-600 text-white shadow-md',
    borderAccent: 'border-amber-500/40',
    subtleBg: 'bg-amber-50/50 dark:bg-amber-950/20',
    cardGlow: 'shadow-amber-500/5',
  },
  violet: {
    id: 'violet',
    name: 'کهکشان ارغوانی (نوآوری)',
    englishName: 'Cosmic Violet',
    badge: 'ارغوانی',
    accentColor: '#7c3aed',
    primaryBtn: 'bg-purple-600 hover:bg-purple-700 text-white shadow-purple-600/30',
    ringColor: 'ring-purple-500',
    badgeBg: 'bg-purple-100 text-purple-800 dark:bg-purple-950/60 dark:text-purple-300',
    headerGrad: 'from-purple-950 via-purple-900 to-slate-950',
    activeNavTab: 'bg-purple-600 text-white shadow-md',
    borderAccent: 'border-purple-500/40',
    subtleBg: 'bg-purple-50/50 dark:bg-purple-950/20',
    cardGlow: 'shadow-purple-500/5',
  },
  rose: {
    id: 'rose',
    name: 'سرخ مرجانی (شور رقابت)',
    englishName: 'Coral Rose',
    badge: 'مرجانی',
    accentColor: '#e11d48',
    primaryBtn: 'bg-rose-600 hover:bg-rose-700 text-white shadow-rose-600/30',
    ringColor: 'ring-rose-500',
    badgeBg: 'bg-rose-100 text-rose-800 dark:bg-rose-950/60 dark:text-rose-300',
    headerGrad: 'from-rose-950 via-rose-900 to-slate-950',
    activeNavTab: 'bg-rose-600 text-white shadow-md',
    borderAccent: 'border-rose-500/40',
    subtleBg: 'bg-rose-50/50 dark:bg-rose-950/20',
    cardGlow: 'shadow-rose-500/5',
  },
  cyan: {
    id: 'cyan',
    name: 'فیروزه‌ای دریایی (وضوح ذهن)',
    englishName: 'Ocean Cyan',
    badge: 'فیروزه‌ای',
    accentColor: '#0891b2',
    primaryBtn: 'bg-cyan-600 hover:bg-cyan-700 text-white shadow-cyan-600/30',
    ringColor: 'ring-cyan-500',
    badgeBg: 'bg-cyan-100 text-cyan-800 dark:bg-cyan-950/60 dark:text-cyan-300',
    headerGrad: 'from-cyan-950 via-cyan-900 to-slate-950',
    activeNavTab: 'bg-cyan-600 text-white shadow-md',
    borderAccent: 'border-cyan-500/40',
    subtleBg: 'bg-cyan-50/50 dark:bg-cyan-950/20',
    cardGlow: 'shadow-cyan-500/5',
  },
};

export const THEMES: ThemeConfig[] = Object.values(THEME_CONFIGS);

export const REMINDER_CATEGORIES_META: Record<
  ReminderCategory,
  { label: string; icon: string; color: string; badgeClass: string }
> = {
  study: {
    label: 'مطالعه و پارت اختصاصی',
    icon: '📚',
    color: '#059669',
    badgeClass: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300',
  },
  test: {
    label: 'تست‌زنی و سنجش زمان‌دار',
    icon: '⚡',
    color: '#3b82f6',
    badgeClass: 'bg-blue-100 text-blue-800 dark:bg-blue-950/60 dark:text-blue-300',
  },
  review: {
    label: 'مرور خلاصه‌ها و جعبه لایتنر',
    icon: '🔄',
    color: '#8b5cf6',
    badgeClass: 'bg-purple-100 text-purple-800 dark:bg-purple-950/60 dark:text-purple-300',
  },
  sleep: {
    label: 'خواب و استراحت کنکوری',
    icon: '🌙',
    color: '#6366f1',
    badgeClass: 'bg-indigo-100 text-indigo-800 dark:bg-indigo-950/60 dark:text-indigo-300',
  },
  health: {
    label: 'سلامت، تغذیه و هیدراتاسیون',
    icon: '🍎',
    color: '#f59e0b',
    badgeClass: 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300',
  },
  diagnostic: {
    label: 'آسیب‌شناسی و ثبت کارنامه شبانه',
    icon: '📊',
    color: '#ec4899',
    badgeClass: 'bg-pink-100 text-pink-800 dark:bg-pink-950/60 dark:text-pink-300',
  },
};

export function getDefaultReminders(): StudyReminder[] {
  return [];
}

export const EBBINGHAUS_INTERVALS = [
  { level: 1, days: 1, label: 'مرور ۲۴ ساعت بعد (روز بعد)', badge: 'مرور مرحله ۱' },
  { level: 2, days: 3, label: 'مرور ۳ روز بعد', badge: 'مرور مرحله ۲' },
  { level: 3, days: 7, label: 'مرور ۱ هفته بعد', badge: 'مرور مرحله ۳' },
  { level: 4, days: 15, label: 'مرور ۲ هفته بعد', badge: 'مرور مرحله ۴' },
  { level: 5, days: 30, label: 'مرور ۱ ماه بعد (تثبیت دائم)', badge: 'مرور طلایی ماهانه' },
];

export function getDefaultTopicMemories(): TopicMemoryItem[] {
  return [];
}

export function getDefaultMonthlyPlan(): MonthlyPlanRoadmap {
  return {
    id: 'monthly-mehr-1405',
    monthName: 'برنامه ماهانه راهبردی (۴ هفته)',
    targetGoal: 'جمع‌بندی ۵۰٪ زیست دوازدهم + تثبیت شیمی یازدهم و روتین عمومی نهایی',
    schoolHoursPerDay: 6,
    dailyAvailableHours: 6.5,
    spacedReviewTopics: [
      'رونویسی زیست دوازدهم (مرور ۱ هفته و ۱ ماه)',
      'استوکیومتری شیمی یازدهم (مرور ۳ روز و ۲ هفته)',
      'حرکت‌شناسی فیزیک (مرور ۲۴ ساعت و ۱ هفته)',
      'مثلثات و تابع ریاضی تجربی (مرور ماهانه)',
    ],
    weeks: [
      {
        weekNumber: 1,
        title: 'هفته اول: استارت پرقدرت دوازدهم و پایه',
        focusGoal: 'پیشروی فصل ۱ و ۲ زیست دوازدهم + مسائل مول و استوکیومتری',
        targetHours: 42,
        targetTests: 450,
        subjectsSummary: {
          'زیست‌شناسی': 'فصل ۱ مولکول‌های اطلاعاتی (گفتار ۱ تا ۳) + ۱۵۰ تست',
          'شیمی': 'استوکیومتری فرمولی و مولی + ۱۰۰ تست',
          'فیزیک': 'حرکت با سرعت ثابت و شتاب ثابت + ۸۰ تست',
          'ریاضی تجربی': 'تابع خطی، درجه ۲ و ترکیب توابع + ۷۰ تست',
          'زمین‌شناسی': 'فصل ۱ آفرینش زمین + ۲۰ تست',
          'امتحانات نهایی / عمومی': 'درس ۱ تا ۳ دینی و آرایه‌های فارسی ۳',
        },
        keyMilestones: [
          'تکمیل تست‌های خط‌به‌خط زیست دوازدهم',
          'برگزاری آزمونک تشخیصی پایان هفته',
        ],
        scheduledReviews: [
          { topic: 'رونویسی زیست', subject: 'زیست‌شناسی', intervalDays: 3, dateNote: 'سه‌شنبه' },
          { topic: 'استوکیومتری', subject: 'شیمی', intervalDays: 7, dateNote: 'جمعه' },
        ],
      },
      {
        weekNumber: 2,
        title: 'هفته دوم: تعمیق و حل تست‌های زمان‌دار',
        focusGoal: 'شیمی یازدهم در پی غذای سالم + زیست یازدهم حواس و هورمون',
        targetHours: 44,
        targetTests: 500,
        subjectsSummary: {
          'زیست‌شناسی': 'فصل ۲ جریان اطلاعات در یاخته + تست‌های پوششی هفته اول',
          'شیمی': 'آنتالپی و سینتیک شیمیایی + ۱۱۰ تست',
          'فیزیک': 'دینامیک و قوانین نیوتون + ۹۰ تست',
          'ریاضی تجربی': 'مثلثات و معادلات مثلثاتی + ۸۰ تست',
          'زمین‌شناسی': 'فصل ۲ منابع معدنی',
          'امتحانات نهایی / عمومی': 'گرامر و ریدینگ زبان دوازدهم',
        },
        keyMilestones: [
          'اجرای مرور خودکار ابینگهاوس برای مباحث هفته اول',
          'آزمون جامع ۲ هفته‌ای قلم‌چی/ماز',
        ],
        scheduledReviews: [
          { topic: 'حرکت‌شناسی', subject: 'فیزیک', intervalDays: 7, dateNote: 'پنجشنبه' },
          { topic: 'مولکول‌های زیستی', subject: 'زیست‌شناسی', intervalDays: 15, dateNote: 'جمعه' },
        ],
      },
      {
        weekNumber: 3,
        title: 'هفته سوم: رفع اشکال و تمرکز بر نقاط ضعف',
        focusGoal: 'پارت‌های جبرانی کسری‌ها + مرورهای فاصله‌دار حافظه مبحثی',
        targetHours: 40,
        targetTests: 420,
        subjectsSummary: {
          'زیست‌شناسی': 'انتقال مواد در گیاهان (زیست دهم و یازدهم)',
          'شیمی': 'الکتروشیمی و سلول‌های گالوانی دوازدهم',
          'فیزیک': 'نوسان و امواج مکانیکی',
          'ریاضی تجربی': 'حد و پیوستگی توابع',
          'زمین‌شناسی': 'آب‌های سطحی و زیرزمینی',
          'امتحانات نهایی / عمومی': 'قواعد و متون عربی ۳ نهایی',
        },
        keyMilestones: [
          'بررسی کارنامه آسیب‌شناسی و رفع اشکال تست‌های غلط',
          'مرور لایتنر جعبه ابینگهاوس',
        ],
        scheduledReviews: [
          { topic: 'استوکیومتری و آنتالپی', subject: 'شیمی', intervalDays: 15, dateNote: 'چهارشنبه' },
          { topic: 'توابع و مثلثات', subject: 'ریاضی تجربی', intervalDays: 15, dateNote: 'پنجشنبه' },
        ],
      },
      {
        weekNumber: 4,
        title: 'هفته چهارم: سنجش ماهانه و تثبیت حافظه بلندمدت',
        focusGoal: 'آزمون جامع ماهانه شبیه‌ساز کنکور + مرور طلایی ۳۰ روزه',
        targetHours: 46,
        targetTests: 550,
        subjectsSummary: {
          'زیست‌شناسی': 'مرور طلایی ۳۰ روزه کل مباحث ماه + آزمون جامع زیست',
          'شیمی': 'آزمون جامع شیمی دهم، یازدهم و دوازدهم',
          'فیزیک': 'تست‌های ترکیبی حرکت و دینامیک',
          'ریاضی تجربی': 'آزمون جامع مباحث ماه',
          'زمین‌شناسی': 'تست‌های جامع کنکورهای سراسری',
          'امتحانات نهایی / عمومی': 'شبیه‌ساز امتحان نهایی هماهنگ کشوری',
        },
        keyMilestones: [
          'ثبت نهایی پیشرفت در جعبه ابینگهاوس (سطح ۵ - تثبیت دائم)',
          'هدف‌گذاری برای ماه تحصیلی بعد',
        ],
        scheduledReviews: [
          { topic: 'مرور ۳۰ روزه تمام مباحث ماه', subject: 'زیست‌شناسی', intervalDays: 30, dateNote: 'جمعه' },
        ],
      },
    ],
  };
}

export function getDefaultAnnualPlan(): AnnualPlanRoadmap {
  return {
    id: 'annual-roadmap-1405-esfand-target',
    title: 'استراتژی سالانه جامع کنکور تجربی (اتمام ۱۰۰٪ پایه و دوازدهم تا ۲۹ اسفند)',
    academicYear: '۱۴۰۴ - ۱۴۰۵',
    targetDeadline: '۲۹ اسفند — اتمام قطعی کل مباحث تخصصی دهم، یازدهم و دوازدهم',
    overallGoal: 'مطالعه و جمع‌بندی کامل زیست، شیمی، فیزیک و ریاضی دهم و یازدهم به همراه کل دوازدهم تا پایان اسفند با حداقل ۱۵,۰۰۰ تست و اجرای متدهای علمی ابینگهاوس، بازیابی فعال و آزمون‌های ۳ روز یکبار در بهار.',
    studentLevel: 'starter',
    totalTargetTests: 18500,
    totalTargetHours: 1450,
    scientificFrameworkSummary: [
      '⚡ متد اسپیسینگ و فواصل تکرار ابینگهاوس (مرور روز ۱، ۳، ۷، ۱۵ و ۳۰)',
      '🧠 بازیابی فعال (Active Recall) با حل تست‌های سنجشی پیش و پس از مطالعه',
      '🔄 یادگیری درهم‌تنیده (Interleaving Method) برای تفکیک دروس مفهومی و محاسباتی',
      '📦 جعبه بازگشتی تست‌های غلط و نشان‌دار (Leitner System)',
      '🛡️ ایستگاه‌های جبرانی آخر هفته برای صفر کردن کسری‌های برنامه',
      '🎯 ضرب‌الاجل طلایی اسفند ماه: ورود به فروردین با صفر مبحث نخوانده',
    ],
    months: [
      {
        id: 'ann-month-1',
        monthIndex: 1,
        monthName: 'مهر ماه',
        season: 'پاییز',
        phaseTitle: 'فاز ۱: راه‌اندازی و تثبیت ریتم دوازدهم و پایه',
        targetGoal: 'شروع قدرتمند دوازدهم (نیمسال اول) + بستن مباحث بنیادی پایه دهم و یازدهم',
        targetMonthlyHours: 155,
        targetMonthlyTests: 1800,
        grade10Coverage: {
          'زیست‌شناسی': 'فصل ۱ و ۲ (دنیای زنده، گوارش و جذب مواد)',
          'شیمی': 'فصل ۱ (کیهان زادگاه الفبای هستی، ساختار اتم و جدول تناوبی)',
          'فیزیک': 'فصل ۱ (فیزیک و اندازه‌گیری، چگالی و تبدیل واحدها)',
          'ریاضی تجربی': 'فصل ۱ و ۲ (مجموعه، الگو و دنباله + مثلثات دهم)',
          'زمین‌شناسی': 'فصل ۱ (آفرینش زمین و شناخت سنگ‌ها)',
        },
        grade11Coverage: {
          'زیست‌شناسی': 'فصل ۱ (تنظیم عصبی، پتانسیل عمل و انتقال پیام)',
          'شیمی': 'فصل ۱ (قدر هدایای زمین، هیدروکربن‌ها و آلکان‌ها)',
          'فیزیک': 'فصل ۱ (الکتریسیته ساکن، کولن، میدان و پتانسیل)',
          'ریاضی تجربی': 'فصل ۱ (هندسه تحلیلی، خط، دایره و معادله درجه ۲)',
        },
        grade12Coverage: {
          'زیست‌شناسی': 'فصل ۱ (مولکول‌های اطلاعاتی، همانندسازی و پروتئین‌سازی)',
          'شیمی': 'فصل ۱ (مولکول‌ها در خدمت تندرستی، اسیدها و بازها، pH)',
          'فیزیک': 'فصل ۱ (حرکت‌شناسی، سرعت و شتاب ثابت و نمودارها)',
          'ریاضی تجربی': 'فصل ۱ (تابع، ترکیب توابع و وارون‌پذیری)',
          'امتحانات نهایی / عمومی': 'دینی ۳ (درس ۱ و ۲) + ادبیات ۳ (ستایش و درس ۱)',
        },
        scientificMethods: [
          'مرور ۲۴ ساعته نکات زیست دوازدهم و فرمول‌های فیزیک',
          'حل تست‌های استوکیومتری با متد بازیابی فعال',
          'ایستگاه جبرانی پنجشنبه عصر هر هفته',
        ],
        compensationDays: 'پنجشنبه‌های پایان هر دو هفته',
        milestones: [
          'تثبیت حداقل ۵.۵ ساعت مطالعه در روزهای مدرسه',
          'تسلط بر رسم نمودارهای حرکت‌شناسی فیزیک و جدول تناوبی شیمی',
        ],
      },
      {
        id: 'ann-month-2',
        monthIndex: 2,
        monthName: 'آبان ماه',
        season: 'پاییز',
        phaseTitle: 'فاز ۲: تعمیق پایه و تسلط بر مسائل محاسباتی',
        targetGoal: 'پیشروی ۴۰٪ دوازدهم + تثبیت شیمی یازدهم و زیست تنفس و حواس',
        targetMonthlyHours: 165,
        targetMonthlyTests: 2100,
        grade10Coverage: {
          'زیست‌شناسی': 'فصل ۳ (تبادلات گازی و ساختار شش‌ها و دم و بازدم)',
          'شیمی': 'فصل ۲ (ردپای گازها در زندگی و اثر گلخانه‌ای)',
          'فیزیک': 'فصل ۲ (ویژگی‌های فیزیکی مواد، فشار، لوله‌های U شکل)',
          'ریاضی تجربی': 'فصل ۳ (توان‌های گویا، ریشه‌گیری و عبارت‌های جبری)',
        },
        grade11Coverage: {
          'زیست‌شناسی': 'فصل ۲ (حواس پنج‌گانه، چشم، گوش و گیرنده‌های نوری)',
          'شیمی': 'فصل ۲ (در پی غذای سالم، گرماشیمی، آنتالپی و سینتیک)',
          'فیزیک': 'فصل ۲ (جریان الکتریکی، مقاومت و مدارهای DC)',
          'ریاضی تجربی': 'فصل ۲ (هندسه فضایی و روابط طولی)',
        },
        grade12Coverage: {
          'زیست‌شناسی': 'فصل ۲ (جریان اطلاعات در یاخته، رونویسی و ترجمه)',
          'شیمی': 'ادامه فصل ۱ + مقدمات فصل ۲ (آسایش و الکتروشیمی)',
          'فیزیک': 'فصل ۲ (دینامیک، قوانین نیوتون، اصطکاک و تکانه)',
          'ریاضی تجربی': 'فصل ۲ (مثلثات پیشرفته، اتحادها و معادلات مثلثاتی)',
          'امتحانات نهایی / عمومی': 'زبان دوازدهم (درس ۱) + سلامت و بهداشت',
        },
        scientificMethods: [
          'اجرای تست‌های زمان‌دار در باکس‌های ۴۵ دقیقه‌ای',
          'ثبت غلط‌ها در جعبه لایتنر ابینگهاوس',
          'تنوع متناوب درس تحلیلی (فیزیک) با مفهومی (زیست)',
        ],
        compensationDays: 'جمعه‌های بعد از آزمون آزمایشی',
        milestones: [
          'رسیدن به درصد بالای ۷۰٪ در زیست دوازدهم',
          'بستن کامل مبحث فشار فیزیک دهم و مدارهای یازدهم',
        ],
      },
      {
        id: 'ann-month-3',
        monthIndex: 3,
        monthName: 'آذر ماه',
        season: 'پاییز',
        phaseTitle: 'فاز ۳: تثبیت ژنتیک و الکتروشیمی و نیمسال اول',
        targetGoal: 'اتمام فصل‌های سنگین نیمسال اول دوازدهم + پیشروی زیست گردش مواد دهم',
        targetMonthlyHours: 170,
        targetMonthlyTests: 2300,
        grade10Coverage: {
          'زیست‌شناسی': 'فصل ۴ (گردش مواد در بدن انسان، قلب، رگ‌ها و گیاهی)',
          'شیمی': 'فصل ۳ (آب، آهنگ زندگی و محلول‌ها و غلظت)',
          'فیزیک': 'فصل ۳ (کار، انرژی، توان و پایستگی انرژی مکانیکی)',
          'ریاضی تجربی': 'فصل ۴ (معادلات و نامعادلات و تعیین علامت)',
          'زمین‌شناسی': 'فصل ۲ و ۳ (منابع معدنی و آب در زمین)',
        },
        grade11Coverage: {
          'زیست‌شناسی': 'فصل ۳ و ۴ (دستگاه حرکتی، استخوان و هورمون‌ها)',
          'شیمی': 'ادامه فصل ۲ (سینتیک و سرعت واکنش‌های شیمیایی)',
          'فیزیک': 'فصل ۳ (مغناطیس، القای الکترومغناطیسی و لنز)',
          'ریاضی تجربی': 'فصل ۳ (تابع، اعمال روی توابع و تابع یک‌به‌یک)',
        },
        grade12Coverage: {
          'زیست‌شناسی': 'فصل ۳ و ۴ (انتقال اطلاعات در نسل‌ها / ژنتیک و جهش)',
          'شیمی': 'فصل ۲ (الکتروشیمی، سلول‌های گالوانی و خوردگی آهن)',
          'فیزیک': 'ادامه فصل ۲ (نیروی گرانش و فنر و دینامیک پیشرفته)',
          'ریاضی تجربی': 'فصل ۳ (حد بی‌نهایت و حد در بی‌نهایت و پیوستگی)',
          'امتحانات نهایی / عمومی': 'عربی ۳ نهایی (درس ۱ و ۲) + فارسی ۳',
        },
        scientificMethods: [
          'مرورهای هفتگی و ماهانه مباحث مهر ماه با تست پوششی',
          'بازیابی فعال برای اشکال قلب زیست دهم و ژنتیک دوازدهم',
        ],
        compensationDays: 'پنجشنبه پایان ماه',
        milestones: [
          'تسلط بر تست‌های مفهومی ژنتیک دوازدهم',
          'تکمیل ۱۰۰٪ تست‌های مبحث کار و انرژی و محلول‌ها',
        ],
      },
      {
        id: 'ann-month-4',
        monthIndex: 4,
        monthName: 'دی ماه',
        season: 'زمستان',
        phaseTitle: 'فاز ۴: ایستگاه طلایی جمع‌بندی نیمسال اول + امتحانات دی',
        targetGoal: 'جمع‌بندی قطعی ۵۰٪ دوازدهم + مرور جامع پایه دهم و یازدهم با تست‌های کنکور',
        targetMonthlyHours: 175,
        targetMonthlyTests: 2200,
        grade10Coverage: {
          'زیست‌شناسی': 'جمع‌بندی فصل ۱ تا ۴ زیست دهم با آزمون‌های جامع',
          'شیمی': 'جمع‌بندی کل شیمی دهم با تست‌های ترکیبی کنکور',
          'فیزیک': 'مرور فرمول‌ها و تست‌های ترکیبی فصل ۱ تا ۳ فیزیک دهم',
          'ریاضی تجربی': 'جمع‌بندی نیمسال اول دهم و حل تست‌های سراسری',
        },
        grade11Coverage: {
          'زیست‌شناسی': 'جمع‌بندی فصل ۱ تا ۴ زیست یازدهم',
          'شیمی': 'جمع‌بندی فصل ۱ و ۲ شیمی یازدهم',
          'فیزیک': 'جمع‌بندی کامل الکتریسیته ساکن و جاری و مغناطیس یازدهم',
          'ریاضی تجربی': 'جمع‌بندی مباحث پایه یازدهم',
        },
        grade12Coverage: {
          'زیست‌شناسی': 'جمع‌بندی فصل ۱ تا ۴ دوازدهم تشریحی و تستی',
          'شیمی': 'جمع‌بندی فصل ۱ و ۲ دوازدهم تشریحی و تستی',
          'فیزیک': 'جمع‌بندی فصل ۱ و ۲ دوازدهم (حرکت و دینامیک)',
          'ریاضی تجربی': 'جمع‌بندی فصل ۱ تا ۳ دوازدهم تشریحی و تستی',
          'امتحانات نهایی / عمومی': 'امتحانات دی‌ماه نوبت اول مدارس (تثبیت نمره ۲۰)',
        },
        scientificMethods: [
          'آزمون‌های جامع شبیه‌ساز نیمسال اول',
          'مرور لایتنر مباحث فراموش‌شده ماه‌های مهر تا آذر',
          'تمرین تشریحی نهایی در کنار تست‌های تالیفی سطح بالا',
        ],
        compensationDays: '۳ روز فرجه طلایی بعد از امتحانات دی',
        milestones: [
          'کسب نمرات کامل در امتحانات نوبت اول',
          'بستن نیمی از کل مباحث کنکور سراسری با تست استاندارد',
        ],
      },
      {
        id: 'ann-month-5',
        monthIndex: 5,
        monthName: 'بهمن ماه',
        season: 'زمستان',
        phaseTitle: 'فاز ۵: استارت نیمسال دوم و فوتوسنتز و نوسان',
        targetGoal: 'پیشروی سریع نیمسال دوم دوازدهم + پیشروی فصول پایانی زیست و فیزیک پایه',
        targetMonthlyHours: 180,
        targetMonthlyTests: 2500,
        grade10Coverage: {
          'زیست‌شناسی': 'فصل ۵ و ۶ (تنظیم اسمزی و دفع مواد + ساختار بافت‌های گیاهی)',
          'شیمی': 'مرور دوره‌ای استوکیومتری و واکنش‌های دهم',
          'فیزیک': 'فصل ۴ (دما و گرما، انبساط، تعادل گرمایی و تبادل حرارت)',
          'ریاضی تجربی': 'فصل ۵ و ۶ (تابع و شمارش بدون شمردن / ترکیبیات)',
        },
        grade11Coverage: {
          'زیست‌شناسی': 'فصل ۵ و ۶ (ایمنی بدن و دفاع اختصاصی + تقسیم یاخته میتوز و میوز)',
          'شیمی': 'فصل ۳ (پوشاک و الیاف، پلیمرها، استرها و الکل‌ها)',
          'فیزیک': 'فصل ۳ و ۴ (القای الکترومغناطیسی و جریان متناوب)',
          'ریاضی تجربی': 'فصل ۴ و ۵ (مثلثات یازدهم و توابع نمایی و لگاریتمی)',
        },
        grade12Coverage: {
          'زیست‌شناسی': 'فصل ۵ و ۶ (از ماده به انرژی، تنفس سلولی + فتوسنتز و تولید انرژی)',
          'شیمی': 'فصل ۳ (شیمی جلوه‌ای از هنر، سرامیک‌ها، سیلیس و پلیمرها)',
          'فیزیک': 'فصل ۳ (نوسان و امواج، آونگ، فنر، صوت و بازتاب و شکست موج)',
          'ریاضی تجربی': 'فصل ۴ (مشتق، تعریف مشتق، آهنگ تغییر و مشتق‌پذیری)',
          'امتحانات نهایی / عمومی': 'هویت اجتماعی و سلامت و بهداشت نهایی',
        },
        scientificMethods: [
          'تکنیک اینترلیوینگ فتوسنتز زیست با مشتق ریاضی',
          'حل تست‌های ۵ گزینه‌ای و زمان‌دار',
          'مرورهای دوره‌ای ابینگهاوس روز ۱، ۳ و ۷',
        ],
        compensationDays: 'جمعه‌های هفته دوم و چهارم بهمن',
        milestones: [
          'تسلط بر مباحث فتوسنتز و تنفس سلولی زیست دوازدهم',
          'تکمیل کامل شیمی یازدهم و فیزیک گرما',
        ],
      },
      {
        id: 'ann-month-6',
        monthIndex: 6,
        monthName: 'اسفند ماه',
        season: 'زمستان',
        isMilestoneEsfand: true,
        phaseTitle: '🎯 فاز ۶ (نقطه عطف طلایی): اتمام ۱۰۰٪ کل دروس دهم، یازدهم و دوازدهم',
        targetGoal: 'بستن کامل و قطعی تمام مباحث تخصصی دهم، یازدهم و دوازدهم تا ۲۹ اسفند + دوره تست‌های جمع‌بندی',
        targetMonthlyHours: 190,
        targetMonthlyTests: 2800,
        grade10Coverage: {
          'زیست‌شناسی': 'فصل ۷ (جذب و انتقال مواد در گیاهان) + اتمام ۱۰۰٪ زیست دهم',
          'شیمی': 'اتمام ۱۰۰٪ تمام فصل‌ها و تست‌های ترکیبی دهم',
          'فیزیک': 'اتمام ۱۰۰٪ فیزیک دهم و بستن پرونده ترمودینامیک و گرما',
          'ریاضی تجربی': 'فصل ۷ (آمار و احتمال دهم) + اتمام ۱۰۰٪ ریاضی دهم',
          'زمین‌شناسی': 'اتمام ۱۰۰٪ کتاب زمین‌شناسی کنکور',
        },
        grade11Coverage: {
          'زیست‌شناسی': 'فصل ۷، ۸ و ۹ (تولیدمثل انسان، گیاهان و جانوران) + اتمام ۱۰۰٪ زیست یازدهم',
          'شیمی': 'اتمام ۱۰۰٪ تمام تست‌ها و واکنش‌های شیمی یازدهم',
          'فیزیک': 'اتمام ۱۰۰٪ فیزیک یازدهم با تست‌های جمع‌بندی',
          'ریاضی تجربی': 'فصل ۶ و ۷ (حد و پیوستگی و احتمال یازدهم) + اتمام ۱۰۰٪ یازدهم',
        },
        grade12Coverage: {
          'زیست‌شناسی': 'فصل ۷ و ۸ (فناوری‌های نوین زیستی + رفتارهای جانوران) + اتمام ۱۰۰٪ زیست دوازدهم',
          'شیمی': 'فصل ۴ (شیمی راهی به سوی آینده، انرژی خورشیدی و بازیافت) + اتمام ۱۰۰٪ شیمی دوازدهم',
          'فیزیک': 'فصل ۴ (آشنایی با فیزیک اتمی و هسته‌ای، فوتوالکتریک و نیمه‌عمر) + اتمام ۱۰۰٪ فیزیک دوازدهم',
          'ریاضی تجربی': 'فصل ۵ و ۶ و ۷ (کاربرد مشتق، هندسه مقاطع مخروطی و احتمال) + اتمام ۱۰۰٪ ریاضی دوازدهم',
          'امتحانات نهایی / عمومی': 'اتمام بار اول تمام دروس عمومی دوازدهم نهایی',
        },
        scientificMethods: [
          '🎯 جشن اتمام مباحث کنکور تا پایان اسفند ماه',
          'آزمون‌های جامع شبیه‌ساز مبحثی پایه و دوازدهم',
          'استخراج لیست نهایی تست‌های غلط و علامت‌دار برای فروردین',
        ],
        compensationDays: '۲۵ تا ۲۹ اسفند (ایستگاه طلایی تسویه تمام کسری‌ها)',
        milestones: [
          '✅ اتمام ۱۰۰٪ تمام کتاب‌های دهم، یازدهم و دوازدهم',
          'رسیدن به رکورد ۱۲,۰۰۰+ تست حل‌شده از ابتدای سال تحصیلی',
          'آمادگی کامل و بدون استرس برای دوران طلایی نوروز',
        ],
      },
      {
        id: 'ann-month-7',
        monthIndex: 7,
        monthName: 'فروردین ماه',
        season: 'بهار',
        phaseTitle: 'فاز ۷: دوران طلایی نوروز و جمع‌بندی جامع پایه',
        targetGoal: 'اردوی نوروزی: آزمون‌های جامع دهم و یازدهم + مرور سوپر فشرده زیست ترکیبی',
        targetMonthlyHours: 195,
        targetMonthlyTests: 3000,
        grade10Coverage: {
          'زیست‌شناسی': 'مرور جامع زیست دهم با تست‌های ترکیبی گیاهی و جانوری',
          'شیمی': 'آزمون‌های جامع شیمی دهم (کنکورهای داخل و خارج)',
          'فیزیک': 'جمع‌بندی کل فیزیک دهم با آزمون‌های ۴۵ تستی',
          'ریاضی تجربی': 'جمع‌بندی ریاضی پایه دهم',
        },
        grade11Coverage: {
          'زیست‌شناسی': 'مرور جامع زیست یازدهم با تصاویر و نکات مفهومی',
          'شیمی': 'جمع‌بندی جامع شیمی یازدهم با تمرکز بر مسائل',
          'فیزیک': 'جمع‌بندی فیزیک یازدهم',
          'ریاضی تجربی': 'جمع‌بندی ریاضی یازدهم',
        },
        grade12Coverage: {
          'زیست‌شناسی': 'مرور سریع فصول نیمسال اول و دوم دوازدهم',
          'شیمی': 'تست‌های ترکیبی شیمی ۳ پایه',
          'فیزیک': 'تست‌های زمان‌دار کنکورهای سراسری',
          'ریاضی تجربی': 'حل تست‌های جامع ریاضی تجربی',
          'امتحانات نهایی / عمومی': 'مرور نمونه سوالات امتحانات نهایی سال‌های قبل',
        },
        scientificMethods: [
          'روش بازیابی فعال ۳ روز یکبار (آزمون قبل از مرور)',
          'مرور لایتنر پیشرفته و تورق سریع تصاویر زیست',
        ],
        compensationDays: 'روز ۱۳ فروردین',
        milestones: [
          'جمع‌بندی قطعی پایه دهم و یازدهم',
          'تثبیت تراز آزمون‌های آزمایشی بالای ۷۰۰۰',
        ],
      },
      {
        id: 'ann-month-8',
        monthIndex: 8,
        monthName: 'اردیبهشت ماه',
        season: 'بهار',
        phaseTitle: 'فاز ۸: امتحانات نهایی دوازدهم + آزمون‌های نیمه‌جامع',
        targetGoal: 'تثبیت معدل کتبی نهایی ۲۰ با مطالعه تشریحی + حفظ ریتم تستی کنکور',
        targetMonthlyHours: 170,
        targetMonthlyTests: 1800,
        grade10Coverage: {
          'زیست‌شناسی': 'مرور شب‌های آزمون آزمایشی',
          'شیمی': 'تست‌های پوششی',
          'فیزیک': 'مرور فرمول‌ها',
          'ریاضی تجربی': 'تست‌های نشان‌دار',
        },
        grade11Coverage: {
          'زیست‌شناسی': 'مرور تست‌های غلط',
          'شیمی': 'مسائل منتخب',
          'فیزیک': 'فرمول‌های مغناطیس و مدار',
          'ریاضی تجربی': 'تست‌های ترکیبی',
        },
        grade12Coverage: {
          'زیست‌شناسی': 'تسلط خط‌به‌خط روی متن کتاب درسی برای نهایی و تست',
          'شیمی': 'حل مسائل تشریحی نهایی و تست‌های کنکور',
          'فیزیک': 'حل تمرین‌های کتاب درسی و نمونه سوالات کشوری',
          'ریاضی تجربی': 'تمرین‌های کتاب درسی و سوالات امتحان نهایی',
          'امتحانات نهایی / عمومی': 'تمرکز ۷۰٪ روی امتحانات نهایی هماهنگ کشوری دوازدهم',
        },
        scientificMethods: [
          'تکنیک حل دقیق سوالات امتحان نهایی با پاسخنامه تصحیح برگه',
          'نگهداری ریتم تست‌زنی روزانه حداقل ۵۰ تست',
        ],
        compensationDays: 'فاصله بین روزهای امتحان نهایی',
        milestones: [
          'پاسخگویی به تمام سوالات نهایی با فرمت رسمی مصححین',
        ],
      },
      {
        id: 'ann-month-9',
        monthIndex: 9,
        monthName: 'خرداد و تیر ماه',
        season: 'جمع‌بندی',
        phaseTitle: 'فاز ۹: شبیه‌سازی کنکور سراسری، آزمون‌های ۳ روز یکبار و تورق سریع',
        targetGoal: 'اجرای روش ۳ روز یکبار کنکورهای ۹۸ تا ۱۴۰۴ + تورق سریع متن کتاب‌ها و تثبیت روحیه',
        targetMonthlyHours: 185,
        targetMonthlyTests: 2600,
        grade10Coverage: {
          'زیست‌شناسی': 'تورق سریع متن و قیدهای کتاب درسی دهم',
          'شیمی': 'مرور حفظیات و فرمول‌های شیمی دهم',
          'فیزیک': 'مرور سریع فرمول‌ها و نکات کلیدی دهم',
          'ریاضی تجربی': 'مرور فرمول‌ها و تیپ‌های پرتکرار',
        },
        grade11Coverage: {
          'زیست‌شناسی': 'تورق سریع متن و تصاویر کتاب درسی یازدهم',
          'شیمی': 'مرور واکنش‌ها و حفظیات شیمی یازدهم',
          'فیزیک': 'مرور نکات دام‌دار فیزیک یازدهم',
          'ریاضی تجربی': 'مرور تیپ‌های منتخب',
        },
        grade12Coverage: {
          'زیست‌شناسی': 'تورق سریع دوازدهم + آزمون‌های جامع کنکور سراسری',
          'شیمی': 'شبیه‌سازی دفترچه شیمی کنکور',
          'فیزیک': 'شبیه‌سازی دفترچه فیزیک کنکور',
          'ریاضی تجربی': 'استراتژی مدیریت زمان دفترچه ریاضی و زیست',
          'امتحانات نهایی / عمومی': 'تورق سریع قبل از کنکور',
        },
        scientificMethods: [
          'روش ۳ روز یکبار شبیه‌ساز کنکور در ساعت دقیق ۸ صبح',
          'تکنیک استراتژی دفترچه‌ها، ضربدر منها و زمان‌های نقصانی',
          'تورق سریع ۲۴ ساعت پایانی قبل از کنکور سراسری',
        ],
        compensationDays: 'عصرهای روزهای آزمون ۳ روز یکبار',
        milestones: [
          'شبیه‌سازی حداقل ۱۰ دوره کنکور سراسری داخل و خارج',
          'ورود با آرامش، اعتماد به نفس و تسلط ۱۰۰٪ به جلسه کنکور سراسری',
        ],
      },
    ],
    syllabusChapters: [
      // زیست دهم (همه صفر برای شروع تمیز)
      { id: 'syl-bio10-1', subject: 'زیست‌شناسی', gradeLevel: 'دهم', chapterNumber: 1, chapterTitle: 'دنیای زنده', isCompleted: false, testCountDone: 0, targetMonth: 'مهر', reviewFrequency: 0 },
      { id: 'syl-bio10-2', subject: 'زیست‌شناسی', gradeLevel: 'دهم', chapterNumber: 2, chapterTitle: 'گوارش و جذب مواد', isCompleted: false, testCountDone: 0, targetMonth: 'مهر', reviewFrequency: 0 },
      { id: 'syl-bio10-3', subject: 'زیست‌شناسی', gradeLevel: 'دهم', chapterNumber: 3, chapterTitle: 'تبادلات گازی', isCompleted: false, testCountDone: 0, targetMonth: 'آبان', reviewFrequency: 0 },
      { id: 'syl-bio10-4', subject: 'زیست‌شناسی', gradeLevel: 'دهم', chapterNumber: 4, chapterTitle: 'گردش مواد در بدن', isCompleted: false, testCountDone: 0, targetMonth: 'آذر', reviewFrequency: 0 },
      { id: 'syl-bio10-5', subject: 'زیست‌شناسی', gradeLevel: 'دهم', chapterNumber: 5, chapterTitle: 'تنظیم اسمزی و دفع مواد زائد', isCompleted: false, testCountDone: 0, targetMonth: 'بهمن', reviewFrequency: 0 },
      { id: 'syl-bio10-6', subject: 'زیست‌شناسی', gradeLevel: 'دهم', chapterNumber: 6, chapterTitle: 'از یاخته تا گیاه', isCompleted: false, testCountDone: 0, targetMonth: 'بهمن', reviewFrequency: 0 },
      { id: 'syl-bio10-7', subject: 'زیست‌شناسی', gradeLevel: 'دهم', chapterNumber: 7, chapterTitle: 'جذب و انتقال مواد در گیاهان', isCompleted: false, testCountDone: 0, targetMonth: 'اسفند', reviewFrequency: 0 },

      // زیست یازدهم
      { id: 'syl-bio11-1', subject: 'زیست‌شناسی', gradeLevel: 'یازدهم', chapterNumber: 1, chapterTitle: 'تنظیم عصبی', isCompleted: false, testCountDone: 0, targetMonth: 'مهر', reviewFrequency: 0 },
      { id: 'syl-bio11-2', subject: 'زیست‌شناسی', gradeLevel: 'یازدهم', chapterNumber: 2, chapterTitle: 'حواس', isCompleted: false, testCountDone: 0, targetMonth: 'آبان', reviewFrequency: 0 },
      { id: 'syl-bio11-3', subject: 'زیست‌شناسی', gradeLevel: 'یازدهم', chapterNumber: 3, chapterTitle: 'دستگاه حرکتی', isCompleted: false, testCountDone: 0, targetMonth: 'آذر', reviewFrequency: 0 },
      { id: 'syl-bio11-4', subject: 'زیست‌شناسی', gradeLevel: 'یازدهم', chapterNumber: 4, chapterTitle: 'تنظیم شیمیایی (هورمون‌ها)', isCompleted: false, testCountDone: 0, targetMonth: 'آذر', reviewFrequency: 0 },
      { id: 'syl-bio11-5', subject: 'زیست‌شناسی', gradeLevel: 'یازدهم', chapterNumber: 5, chapterTitle: 'ایمنی', isCompleted: false, testCountDone: 0, targetMonth: 'بهمن', reviewFrequency: 0 },
      { id: 'syl-bio11-6', subject: 'زیست‌شناسی', gradeLevel: 'یازدهم', chapterNumber: 6, chapterTitle: 'تقسیم یاخته (میتوز و میوز)', isCompleted: false, testCountDone: 0, targetMonth: 'بهمن', reviewFrequency: 0 },
      { id: 'syl-bio11-7', subject: 'زیست‌شناسی', gradeLevel: 'یازدهم', chapterNumber: 7, chapterTitle: 'تولیدمثل انسان', isCompleted: false, testCountDone: 0, targetMonth: 'اسفند', reviewFrequency: 0 },
      { id: 'syl-bio11-8', subject: 'زیست‌شناسی', gradeLevel: 'یازدهم', chapterNumber: 8, chapterTitle: 'تولیدمثل نهان‌دانگان', isCompleted: false, testCountDone: 0, targetMonth: 'اسفند', reviewFrequency: 0 },
      { id: 'syl-bio11-9', subject: 'زیست‌شناسی', gradeLevel: 'یازدهم', chapterNumber: 9, chapterTitle: 'پاسخ گیاهان به محرک‌ها', isCompleted: false, testCountDone: 0, targetMonth: 'اسفند', reviewFrequency: 0 },

      // زیست دوازدهم
      { id: 'syl-bio12-1', subject: 'زیست‌شناسی', gradeLevel: 'دوازدهم', chapterNumber: 1, chapterTitle: 'مولکول‌های اطلاعاتی', isCompleted: false, testCountDone: 0, targetMonth: 'مهر', reviewFrequency: 0 },
      { id: 'syl-bio12-2', subject: 'زیست‌شناسی', gradeLevel: 'دوازدهم', chapterNumber: 2, chapterTitle: 'جریان اطلاعات در یاخته', isCompleted: false, testCountDone: 0, targetMonth: 'آبان', reviewFrequency: 0 },
      { id: 'syl-bio12-3', subject: 'زیست‌شناسی', gradeLevel: 'دوازدهم', chapterNumber: 3, chapterTitle: 'انتقال اطلاعات در نسل‌ها (ژنتیک)', isCompleted: false, testCountDone: 0, targetMonth: 'آذر', reviewFrequency: 0 },
      { id: 'syl-bio12-4', subject: 'زیست‌شناسی', gradeLevel: 'دوازدهم', chapterNumber: 4, chapterTitle: 'تغییر در اطلاعات وراثتی', isCompleted: false, testCountDone: 0, targetMonth: 'دی', reviewFrequency: 0 },
      { id: 'syl-bio12-5', subject: 'زیست‌شناسی', gradeLevel: 'دوازدهم', chapterNumber: 5, chapterTitle: 'از ماده به انرژی (تنفس سلولی)', isCompleted: false, testCountDone: 0, targetMonth: 'بهمن', reviewFrequency: 0 },
      { id: 'syl-bio12-6', subject: 'زیست‌شناسی', gradeLevel: 'دوازدهم', chapterNumber: 6, chapterTitle: 'از انرژی به ماده (فتوسنتز)', isCompleted: false, testCountDone: 0, targetMonth: 'بهمن', reviewFrequency: 0 },
      { id: 'syl-bio12-7', subject: 'زیست‌شناسی', gradeLevel: 'دوازدهم', chapterNumber: 7, chapterTitle: 'فناوری‌های نوین زیستی', isCompleted: false, testCountDone: 0, targetMonth: 'اسفند', reviewFrequency: 0 },
      { id: 'syl-bio12-8', subject: 'زیست‌شناسی', gradeLevel: 'دوازدهم', chapterNumber: 8, chapterTitle: 'رفتارهای جانوران', isCompleted: false, testCountDone: 0, targetMonth: 'اسفند', reviewFrequency: 0 },

      // شیمی دهم، یازدهم، دوازدهم
      { id: 'syl-ch10-1', subject: 'شیمی', gradeLevel: 'دهم', chapterNumber: 1, chapterTitle: 'کیهان زادگاه الفبای هستی', isCompleted: false, testCountDone: 0, targetMonth: 'مهر', reviewFrequency: 0 },
      { id: 'syl-ch10-2', subject: 'شیمی', gradeLevel: 'دهم', chapterNumber: 2, chapterTitle: 'ردپای گازها در زندگی', isCompleted: false, testCountDone: 0, targetMonth: 'آبان', reviewFrequency: 0 },
      { id: 'syl-ch10-3', subject: 'شیمی', gradeLevel: 'دهم', chapterNumber: 3, chapterTitle: 'آب، آهنگ زندگی (محلول‌ها)', isCompleted: false, testCountDone: 0, targetMonth: 'آذر', reviewFrequency: 0 },
      { id: 'syl-ch11-1', subject: 'شیمی', gradeLevel: 'یازدهم', chapterNumber: 1, chapterTitle: 'قدر هدایای زمین', isCompleted: false, testCountDone: 0, targetMonth: 'مهر', reviewFrequency: 0 },
      { id: 'syl-ch11-2', subject: 'شیمی', gradeLevel: 'یازدهم', chapterNumber: 2, chapterTitle: 'در پی غذای سالم (گرماشیمی)', isCompleted: false, testCountDone: 0, targetMonth: 'آبان', reviewFrequency: 0 },
      { id: 'syl-ch11-3', subject: 'شیمی', gradeLevel: 'یازدهم', chapterNumber: 3, chapterTitle: 'پوشاک، نیازی پایان‌ناپذیر', isCompleted: false, testCountDone: 0, targetMonth: 'بهمن', reviewFrequency: 0 },
      { id: 'syl-ch12-1', subject: 'شیمی', gradeLevel: 'دوازدهم', chapterNumber: 1, chapterTitle: 'مولکول‌ها در خدمت تندرستی (اسید و باز)', isCompleted: false, testCountDone: 0, targetMonth: 'مهر', reviewFrequency: 0 },
      { id: 'syl-ch12-2', subject: 'شیمی', gradeLevel: 'دوازدهم', chapterNumber: 2, chapterTitle: 'آسایش و رفاه در سایه شیمی (الکتروشیمی)', isCompleted: false, testCountDone: 0, targetMonth: 'آذر', reviewFrequency: 0 },
      { id: 'syl-ch12-3', subject: 'شیمی', gradeLevel: 'دوازدهم', chapterNumber: 3, chapterTitle: 'شیمی جلوه‌ای از هنر و زیبایی', isCompleted: false, testCountDone: 0, targetMonth: 'بهمن', reviewFrequency: 0 },
      { id: 'syl-ch12-4', subject: 'شیمی', gradeLevel: 'دوازدهم', chapterNumber: 4, chapterTitle: 'شیمی، راهی به سوی آینده‌ای روشن‌تر', isCompleted: false, testCountDone: 0, targetMonth: 'اسفند', reviewFrequency: 0 },

      // فیزیک دهم، یازدهم، دوازدهم
      { id: 'syl-ph10-1', subject: 'فیزیک', gradeLevel: 'دهم', chapterNumber: 1, chapterTitle: 'فیزیک و اندازه‌گیری', isCompleted: false, testCountDone: 0, targetMonth: 'مهر', reviewFrequency: 0 },
      { id: 'syl-ph10-2', subject: 'فیزیک', gradeLevel: 'دهم', chapterNumber: 2, chapterTitle: 'ویژگی‌های فیزیکی مواد و فشار', isCompleted: false, testCountDone: 0, targetMonth: 'آبان', reviewFrequency: 0 },
      { id: 'syl-ph10-3', subject: 'فیزیک', gradeLevel: 'دهم', chapterNumber: 3, chapterTitle: 'کار، انرژی و توان', isCompleted: false, testCountDone: 0, targetMonth: 'آذر', reviewFrequency: 0 },
      { id: 'syl-ph10-4', subject: 'فیزیک', gradeLevel: 'دهم', chapterNumber: 4, chapterTitle: 'دما و گرما', isCompleted: false, testCountDone: 0, targetMonth: 'بهمن', reviewFrequency: 0 },
      { id: 'syl-ph11-1', subject: 'فیزیک', gradeLevel: 'یازدهم', chapterNumber: 1, chapterTitle: 'الکتریسیته ساکن', isCompleted: false, testCountDone: 0, targetMonth: 'مهر', reviewFrequency: 0 },
      { id: 'syl-ph11-2', subject: 'فیزیک', gradeLevel: 'یازدهم', chapterNumber: 2, chapterTitle: 'جریان الکتریکی و مدارهای DC', isCompleted: false, testCountDone: 0, targetMonth: 'آبان', reviewFrequency: 0 },
      { id: 'syl-ph11-3', subject: 'فیزیک', gradeLevel: 'یازدهم', chapterNumber: 3, chapterTitle: 'مغناطیس و القای الکترومغناطیسی', isCompleted: false, testCountDone: 0, targetMonth: 'آذر', reviewFrequency: 0 },
      { id: 'syl-ph12-1', subject: 'فیزیک', gradeLevel: 'دوازدهم', chapterNumber: 1, chapterTitle: 'حرکت بر خط راست (حرکت‌شناسی)', isCompleted: false, testCountDone: 0, targetMonth: 'مهر', reviewFrequency: 0 },
      { id: 'syl-ph12-2', subject: 'فیزیک', gradeLevel: 'دوازدهم', chapterNumber: 2, chapterTitle: 'دینامیک و حرکت دایره‌ای', isCompleted: false, testCountDone: 0, targetMonth: 'آبان', reviewFrequency: 0 },
      { id: 'syl-ph12-3', subject: 'فیزیک', gradeLevel: 'دوازدهم', chapterNumber: 3, chapterTitle: 'نوسان و موج‌ها', isCompleted: false, testCountDone: 0, targetMonth: 'بهمن', reviewFrequency: 0 },
      { id: 'syl-ph12-4', subject: 'فیزیک', gradeLevel: 'دوازدهم', chapterNumber: 4, chapterTitle: 'آشنایی با فیزیک اتمی و هسته‌ای', isCompleted: false, testCountDone: 0, targetMonth: 'اسفند', reviewFrequency: 0 },

      // ریاضی تجربی
      { id: 'syl-m10-1', subject: 'ریاضی تجربی', gradeLevel: 'دهم', chapterNumber: 1, chapterTitle: 'مجموعه، الگو و دنباله', isCompleted: false, testCountDone: 0, targetMonth: 'مهر', reviewFrequency: 0 },
      { id: 'syl-m10-2', subject: 'ریاضی تجربی', gradeLevel: 'دهم', chapterNumber: 2, chapterTitle: 'مثلثات دهم', isCompleted: false, testCountDone: 0, targetMonth: 'مهر', reviewFrequency: 0 },
      { id: 'syl-m10-3', subject: 'ریاضی تجربی', gradeLevel: 'دهم', chapterNumber: 3, chapterTitle: 'توان‌های گویا و عبارت جبری', isCompleted: false, testCountDone: 0, targetMonth: 'آبان', reviewFrequency: 0 },
      { id: 'syl-m11-1', subject: 'ریاضی تجربی', gradeLevel: 'یازدهم', chapterNumber: 1, chapterTitle: 'هندسه تحلیلی و جبر', isCompleted: false, testCountDone: 0, targetMonth: 'مهر', reviewFrequency: 0 },
      { id: 'syl-m11-2', subject: 'ریاضی تجربی', gradeLevel: 'یازدهم', chapterNumber: 2, chapterTitle: 'هندسه فضایی', isCompleted: false, testCountDone: 0, targetMonth: 'آبان', reviewFrequency: 0 },
      { id: 'syl-m11-3', subject: 'ریاضی تجربی', gradeLevel: 'یازدهم', chapterNumber: 3, chapterTitle: 'تابع و مثلثات یازدهم', isCompleted: false, testCountDone: 0, targetMonth: 'آذر', reviewFrequency: 0 },
      { id: 'syl-m12-1', subject: 'ریاضی تجربی', gradeLevel: 'دوازدهم', chapterNumber: 1, chapterTitle: 'تابع دوازدهم', isCompleted: false, testCountDone: 0, targetMonth: 'مهر', reviewFrequency: 0 },
      { id: 'syl-m12-2', subject: 'ریاضی تجربی', gradeLevel: 'دوازدهم', chapterNumber: 2, chapterTitle: 'مثلثات و معادلات مثلثاتی', isCompleted: false, testCountDone: 0, targetMonth: 'آبان', reviewFrequency: 0 },
      { id: 'syl-m12-3', subject: 'ریاضی تجربی', gradeLevel: 'دوازدهم', chapterNumber: 3, chapterTitle: 'حد و پیوستگی', isCompleted: false, testCountDone: 0, targetMonth: 'آذر', reviewFrequency: 0 },
      { id: 'syl-m12-4', subject: 'ریاضی تجربی', gradeLevel: 'دوازدهم', chapterNumber: 4, chapterTitle: 'مشتق', isCompleted: false, testCountDone: 0, targetMonth: 'بهمن', reviewFrequency: 0 },
      { id: 'syl-m12-5', subject: 'ریاضی تجربی', gradeLevel: 'دوازدهم', chapterNumber: 5, chapterTitle: 'کاربرد مشتق و بهینه‌سازی', isCompleted: false, testCountDone: 0, targetMonth: 'اسفند', reviewFrequency: 0 },
      { id: 'syl-m12-6', subject: 'ریاضی تجربی', gradeLevel: 'دوازدهم', chapterNumber: 6, chapterTitle: 'هندسه مقاطع مخروطی', isCompleted: false, testCountDone: 0, targetMonth: 'اسفند', reviewFrequency: 0 },
      { id: 'syl-m12-7', subject: 'ریاضی تجربی', gradeLevel: 'دوازدهم', chapterNumber: 7, chapterTitle: 'احتمال و ترکیبیات', isCompleted: false, testCountDone: 0, targetMonth: 'اسفند', reviewFrequency: 0 },
    ],
  };
}

// WEEKLY TEMPLATES STARTING FROM SUNDAY (یکشنبه)
export const WEEKLY_TEMPLATES: WeeklyScheduleTemplate[] = [
  {
    id: 'school_routine_sunday_start',
    title: 'برنامه استاندارد روزهای با مدرسه (استارت از یکشنبه)',
    badge: 'استارت هفته از یکشنبه + تایم‌های مرور مشخص',
    description: 'چیدمان هماهنگ با مدرسه با شروع از یکشنبه؛ مطالعه ۵.۵ تا ۷ ساعت در عصر + تایم‌های مرور اختصاصی شبانه (۲۱:۱۵ الی ۲۲:۱۵).',
    targetAudience: 'دانش‌آموزانی که شروع برنامه‌شان از یکشنبه است و خواهان جای‌گذاری دقیق تایم‌های مرور هستند.',
    sampleDayType: 'school',
    schedule: {
      'یکشنبه': {
        day: 'یکشنبه',
        dayType: 'school',
        titleNotes: 'روز استارت هفته (زیست دوازدهم + شیمی دهم + تایم مرور ۲۴ ساعته)',
        slots: [
          { id: 'sc-1', startTime: '07:30', endTime: '13:30', title: 'حضور در مدرسه و کلاس درس', activityType: 'school' },
          { id: 'sc-2', startTime: '13:30', endTime: '15:15', title: 'ناهار و استراحت', activityType: 'rest' },
          { id: 'sc-3', startTime: '15:15', endTime: '17:15', title: 'زیست دوازدهم (مولکول‌های اطلاعاتی + ۳۵ تست)', activityType: 'study', subject: 'زیست‌شناسی', gradeLevel: 'دوازدهم', topic: 'رونویسی و پروتئین‌سازی', targetTests: 35, isImportant: true },
          { id: 'sc-4', startTime: '17:30', endTime: '19:15', title: 'شیمی دهم (کیهان و جدول تناوبی + ۳۰ تست)', activityType: 'study', subject: 'شیمی', gradeLevel: 'دهم', topic: 'استوکیومتری و واکنش‌ها', targetTests: 30 },
          { id: 'sc-5', startTime: '19:30', endTime: '21:00', title: 'فیزیک دوازدهم (حرکت با شتاب ثابت)', activityType: 'study', subject: 'فیزیک', gradeLevel: 'دوازدهم', topic: 'حرکت با شتاب ثابت', targetTests: 25 },
          { id: 'sc-6', startTime: '21:15', endTime: '22:15', title: '🧠 تایم مرور اختصاصی ابینگهاوس (مرور ۲۴ ساعته)', activityType: 'study', subject: 'زیست‌شناسی', gradeLevel: 'دوازدهم', topic: 'مرور ۲۴ ساعته نکات زیست و فرمول‌های فیزیک', targetTests: 20, isImportant: true },
        ],
      },
      'دوشنبه': {
        day: 'دوشنبه',
        dayType: 'school',
        titleNotes: 'روز مدرسه (ریاضی مثلثات + زیست دهم + تایم مرور ۳ روزه)',
        slots: [
          { id: 'sc-11', startTime: '07:30', endTime: '13:30', title: 'حضور در مدرسه', activityType: 'school' },
          { id: 'sc-12', startTime: '13:30', endTime: '15:15', title: 'ناهار و استراحت', activityType: 'rest' },
          { id: 'sc-13', startTime: '15:15', endTime: '17:15', title: 'ریاضی تجربی (تابع و مثلثات یازدهم)', activityType: 'study', subject: 'ریاضی تجربی', gradeLevel: 'یازدهم', topic: 'توابع وارون و ترکیب توابع', targetTests: 30, isImportant: true },
          { id: 'sc-14', startTime: '17:30', endTime: '19:15', title: 'زیست دهم (گردش خون و قلب انسان)', activityType: 'study', subject: 'زیست‌شناسی', gradeLevel: 'دهم', topic: 'دریچه‌های قلب و نوار قلب', targetTests: 40 },
          { id: 'sc-15', startTime: '19:30', endTime: '21:00', title: 'شیمی دوازدهم (اسیدها و بازها و pH)', activityType: 'study', subject: 'شیمی', gradeLevel: 'دوازدهم', topic: 'مفاهیم اسید و باز', targetTests: 25 },
          { id: 'sc-16', startTime: '21:15', endTime: '22:15', title: '🧠 تایم مرور اختصاصی ابینگهاوس (مرور ۳ روزه)', activityType: 'study', subject: 'شیمی', gradeLevel: 'یازدهم', topic: 'مرور ۳ روزه مسائل استوکیومتری و واکنش‌ها', targetTests: 20, isImportant: true },
        ],
      },
      'سه‌شنبه': {
        day: 'سه‌شنبه',
        dayType: 'school',
        titleNotes: 'روز مدرسه (فیزیک کار و انرژی + زیست گیاهی + تایم مرور ۷ روزه)',
        slots: [
          { id: 'sc-21', startTime: '07:30', endTime: '13:30', title: 'حضور در مدرسه', activityType: 'school' },
          { id: 'sc-22', startTime: '13:30', endTime: '15:15', title: 'ناهار و استراحت', activityType: 'rest' },
          { id: 'sc-23', startTime: '15:15', endTime: '17:15', title: 'فیزیک دهم (کار و انرژی و فشار مایعات)', activityType: 'study', subject: 'فیزیک', gradeLevel: 'دهم', topic: 'اصل برنولی و لوله‌های U شکل', targetTests: 35 },
          { id: 'sc-24', startTime: '17:30', endTime: '19:15', title: 'زیست گیاهی (انتقال مواد در گیاهان)', activityType: 'study', subject: 'زیست‌شناسی', gradeLevel: 'یازدهم', topic: 'بافت‌های گیاهی و آوندها', targetTests: 35, isImportant: true },
          { id: 'sc-25', startTime: '19:30', endTime: '21:00', title: 'شیمی دهم (جدول تناوبی و شعاع اتمی)', activityType: 'study', subject: 'شیمی', gradeLevel: 'دهم', topic: 'جدول تناوبی و نامگذاری', targetTests: 30 },
          { id: 'sc-26', startTime: '21:15', endTime: '22:15', title: '🧠 تایم مرور اختصاصی ابینگهاوس (مرور ۷ روزه)', activityType: 'study', subject: 'زیست‌شناسی', gradeLevel: 'دهم', topic: 'مرور ۷ روزه ساختار قلب و گردش خون دهم', targetTests: 20, isImportant: true },
        ],
      },
      'چهارشنبه': {
        day: 'چهارشنبه',
        dayType: 'school',
        titleNotes: 'روز مدرسه (زیست میتوز و میوز + ریاضی حد + تایم مرور ۱۵ روزه)',
        slots: [
          { id: 'sc-31', startTime: '07:30', endTime: '13:30', title: 'حضور در مدرسه', activityType: 'school' },
          { id: 'sc-32', startTime: '13:30', endTime: '15:15', title: 'ناهار و ریلکسیشن', activityType: 'rest' },
          { id: 'sc-33', startTime: '15:15', endTime: '17:15', title: 'زیست یازدهم (تقسیم سلولی و میتوز)', activityType: 'study', subject: 'زیست‌شناسی', gradeLevel: 'یازدهم', topic: 'کروموزوم‌ها و میوز', targetTests: 40, isImportant: true },
          { id: 'sc-34', startTime: '17:30', endTime: '19:15', title: 'ریاضی تجربی (معادلات و حد توابع)', activityType: 'study', subject: 'ریاضی تجربی', gradeLevel: 'دوازدهم', topic: 'حد و پیوستگی توابع', targetTests: 30 },
          { id: 'sc-35', startTime: '19:30', endTime: '21:00', title: 'زمین‌شناسی کنکور', activityType: 'study', subject: 'زمین‌شناسی', gradeLevel: 'یازدهم', topic: 'زمین‌شناسی و منابع معدنی', targetTests: 25 },
          { id: 'sc-36', startTime: '21:15', endTime: '22:15', title: '🧠 تایم مرور اختصاصی ابینگهاوس (مرور ۱۵ روزه)', activityType: 'study', subject: 'شیمی', gradeLevel: 'دوازدهم', topic: 'مرور ۱۵ روزه اسید و باز و الکتروشیمی', targetTests: 20, isImportant: true },
        ],
      },
      'پنجشنبه': {
        day: 'پنجشنبه',
        dayType: 'holiday',
        titleNotes: 'روز نیمه‌تعطیل (آزمونک شبیه‌ساز + ایستگاه جبرانی و لایتنر)',
        slots: [
          { id: 'sc-41', startTime: '08:00', endTime: '10:30', title: 'زیست جامع (تست‌های ترکیبی جانوری و ژنتیک)', activityType: 'study', subject: 'زیست‌شناسی', gradeLevel: 'جامع', topic: 'تست‌های ۵۰ تایی سنجشی', targetTests: 50, isImportant: true },
          { id: 'sc-42', startTime: '10:45', endTime: '12:45', title: 'شیمی جامع (حل مسائل زمان‌دار شیمی)', activityType: 'study', subject: 'شیمی', gradeLevel: 'جامع', topic: 'مسائل ترکیبی ۱۰ و ۱۱ و ۱۲', targetTests: 40, isImportant: true },
          { id: 'sc-43', startTime: '14:15', endTime: '16:15', title: 'فیزیک جامع (تست‌های ۵ سال اخیر کنکور)', activityType: 'study', subject: 'فیزیک', gradeLevel: 'جامع', topic: 'حرکت و دینامیک و فشار', targetTests: 35 },
          { id: 'sc-44', startTime: '16:30', endTime: '18:30', title: 'ریاضی تجربی (آزمونک زمان‌دار تابع و مثلثات)', activityType: 'study', subject: 'ریاضی تجربی', gradeLevel: 'دوازدهم', topic: 'تست‌های زمان‌دار', targetTests: 30 },
          { id: 'sc-45', startTime: '19:00', endTime: '21:00', title: '⚠️ ایستگاه جبرانی عقب‌ماندگی‌ها و تست‌های غلط', activityType: 'compensation', topic: 'رفع اشکال تست‌های نشان‌دار هفته' },
          { id: 'sc-46', startTime: '21:15', endTime: '22:15', title: '🧠 تایم مرور جعبه لایتنر ابینگهاوس', activityType: 'study', subject: 'زیست‌شناسی', gradeLevel: 'دهم', topic: 'مرور فلش‌کارت‌ها و تست‌های غلط', targetTests: 20, isImportant: true },
        ],
      },
      'جمعه': {
        day: 'جمعه',
        dayType: 'holiday',
        titleNotes: 'روز آزمون آزمایشی، تحلیل کارنامه و مرور طلایی ۳۰ روزه',
        slots: [
          { id: 'sc-51', startTime: '08:00', endTime: '12:00', title: '🎯 شبیه‌ساز آزمون جامع کنکور تجربی (قلم‌چی/ماز)', activityType: 'study', subject: 'زیست‌شناسی', gradeLevel: 'جامع', topic: 'دفترچه ۱ و ۲ کنکور سراسری', targetTests: 115, isImportant: true },
          { id: 'sc-52', startTime: '12:00', endTime: '14:30', title: 'ناهار و استراحت جمعه', activityType: 'rest' },
          { id: 'sc-53', startTime: '14:30', endTime: '17:30', title: '🔍 تحلیل دقیق آزمون (زیست، شیمی، فیزیک، ریاضی)', activityType: 'study', subject: 'زیست‌شناسی', gradeLevel: 'جامع', topic: 'ثبت نکات غلط و دام‌های آموزشی', targetTests: 40, isImportant: true },
          { id: 'sc-54', startTime: '18:00', endTime: '19:30', title: '🧠 تایم اختصاصی مرور طلایی ۳۰ روزه ابینگهاوس', activityType: 'study', subject: 'شیمی', gradeLevel: 'یازدهم', topic: 'تثبیت دائم کل مباحث ماه در حافظه بلندمدت', targetTests: 25, isImportant: true },
          { id: 'sc-55', startTime: '20:00', endTime: '21:30', title: 'تنظیم اهداف هفته بعد و ریلکسیشن', activityType: 'rest' },
        ],
      },
      'شنبه': {
        day: 'شنبه',
        dayType: 'school',
        titleNotes: 'روز مدرسه (آمادگی امتحانات نهایی و جمع‌بندی هفتگی)',
        slots: [
          { id: 'sc-61', startTime: '07:30', endTime: '13:30', title: 'حضور در مدرسه', activityType: 'school' },
          { id: 'sc-62', startTime: '13:30', endTime: '15:15', title: 'ناهار و استراحت', activityType: 'rest' },
          { id: 'sc-63', startTime: '15:15', endTime: '17:15', title: 'زیست دوازدهم (تنفس سلولی و گلیکولیز)', activityType: 'study', subject: 'زیست‌شناسی', gradeLevel: 'دوازدهم', topic: 'زنجیره انتقال الکترون', targetTests: 45, isImportant: true },
          { id: 'sc-64', startTime: '17:30', endTime: '19:15', title: 'شیمی دوازدهم (الکتروشیمی و سلول گالوانی)', activityType: 'study', subject: 'شیمی', gradeLevel: 'دوازدهم', topic: 'پتانسیل استاندارد و خوردگی', targetTests: 30 },
          { id: 'sc-65', startTime: '19:30', endTime: '21:00', title: 'امتحانات نهایی (دینی و فارسی ۳ تشریحی)', activityType: 'study', subject: 'امتحانات نهایی / عمومی', gradeLevel: 'عمومی و نهایی', topic: 'نمونه سوالات نهایی خرداد', targetTests: 25 },
          { id: 'sc-66', startTime: '21:15', endTime: '22:15', title: '🧠 تایم مرور شبانه و جمع‌بندی هفتگی', activityType: 'study', subject: 'فیزیک', gradeLevel: 'دوازدهم', topic: 'مرور فرمول‌های حرکت و دینامیک', targetTests: 15, isImportant: true },
        ],
      },
    },
  },
];

export function getDefaultWeeklySchedule(): Record<DayOfWeek, DaySchedule> {
  const days: DayOfWeek[] = ['یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه', 'شنبه'];
  const res: Record<string, DaySchedule> = {};
  days.forEach((day) => {
    res[day] = {
      day,
      dayType: 'school',
      titleNotes: '',
      slots: [],
    };
  });
  return res as Record<DayOfWeek, DaySchedule>;
}

export const TAJROBI_SUBJECTS_INFO: Record<
  TajrobiSubject,
  {
    coefficient: string;
    color: string;
    bgColor: string;
    borderColor: string;
    badgeColor: string;
    popularTopics: string[];
    popularBooks: string[];
  }
> = {
  'زیست‌شناسی': {
    coefficient: 'ضریب ۱۲ (مهم‌ترین درس)',
    color: '#059669',
    bgColor: 'bg-emerald-50 dark:bg-emerald-950/40',
    borderColor: 'border-emerald-300 dark:border-emerald-700',
    badgeColor: 'text-emerald-700 dark:text-emerald-300 bg-emerald-100 dark:bg-emerald-900/50',
    popularTopics: [
      'گوارش و جذب مواد (دهم)',
      'گردش مواد و قلب (دهم)',
      'تنفس و تبادلات گازی (دهم)',
      'حواس و دستگاه عصبی (یازدهم)',
      'تولید مثل و ژنتیک (یازدهم)',
      'گیاهی و فتوسنتز (دهم و یازدهم)',
      'مولکول‌های اطلاعاتی و رونویسی (دوازدهم)',
      'انتقال انرژی و تنفس سلولی (دوازدهم)',
    ],
    popularBooks: [
      'خیلی سبز جامع زیست‌شناسی',
      'IQ گاج (تست‌های مفهومی و دشوار)',
      'نشر الگو (زیست دهم/یازدهم/دوازدهم)',
      'میکرو طبقه‌بندی گاج',
      'فصل آزمون خیلی سبز',
      'کتاب درسی خط به خط',
    ],
  },
  'شیمی': {
    coefficient: 'ضریب ۹',
    color: '#d97706',
    bgColor: 'bg-amber-50 dark:bg-amber-950/40',
    borderColor: 'border-amber-300 dark:border-amber-700',
    badgeColor: 'text-amber-700 dark:text-amber-300 bg-amber-100 dark:bg-amber-900/50',
    popularTopics: [
      'استوکیومتری و واکنش‌های شیمیایی (دهم)',
      'ساختار اتم و جدول تناوبی (دهم)',
      'ترکیبات کربنی و شیمی آلی (یازدهم)',
      'ترمودینامیک و آنتالپی (یازدهم)',
      'اسیدها و بازها و pH (دوازدهم)',
      'الکتروشیمی و سلول‌های گالوانی (دوازدهم)',
      'سینتیک و تعادل‌های شیمیایی (دوازدهم)',
    ],
    popularBooks: [
      'مبتکران (مهندس بهمن بازرگانی)',
      'خیلی سبز جامع شیمی',
      'میکرو گاج شیمی',
      'مسایل شیمی خیلی سبز / نشر الگو',
      'کتاب درسی شیمی',
    ],
  },
  'فیزیک': {
    coefficient: 'ضریب ۷',
    color: '#2563eb',
    bgColor: 'bg-blue-50 dark:bg-blue-950/40',
    borderColor: 'border-blue-300 dark:border-blue-700',
    badgeColor: 'text-blue-700 dark:text-blue-300 bg-blue-100 dark:bg-blue-900/50',
    popularTopics: [
      'اندازه‌گیری و چگالی (دهم)',
      'فشار و ویژگی‌های ماده (دهم)',
      'کار، انرژی و توان (دهم)',
      'الکتریسیته ساکن و خازن (یازدهم)',
      'جریان الکتریکی و مدارهای DC (یازدهم)',
      'مغناطیس و القای الکترومغناطیسی (یازدهم)',
      'حرکت بر خط راست (دوازدهم)',
      'دینامیک و قوانین نیوتون (دوازدهم)',
      'نوسان و موج (دوازدهم)',
      'فیزیک اتمی و هسته‌ای (دوازدهم)',
    ],
    popularBooks: [
      'خیلی سبز جامع فیزیک',
      'میکرو گاج فیزیک تجربی',
      'نشر الگو (استاد براتی)',
      'فیزیک پایه و دوازدهم مبتکران',
      'کتاب درسی فیزیک',
    ],
  },
  'ریاضی تجربی': {
    coefficient: 'ضریب ۷',
    color: '#7c3aed',
    bgColor: 'bg-purple-50 dark:bg-purple-950/40',
    borderColor: 'border-purple-300 dark:border-purple-700',
    badgeColor: 'text-purple-700 dark:text-purple-300 bg-purple-100 dark:bg-purple-900/50',
    popularTopics: [
      'مجموعه و دنباله و توان گویا (دهم)',
      'مثلثات جامع (دهم، یازدهم، دوازدهم)',
      'معادلات و نامعادلات درجه ۲ (دهم و یازدهم)',
      'تابع جامع و ترکیب و وارون (۱۰، ۱۱، ۱۲)',
      'حد و پیوستگی (یازدهم و دوازدهم)',
      'مشتق و کاربرد مشتق (دوازدهم)',
      'هندسه و مقاطع مخروطی (یازدهم و دوازدهم)',
      'آمار و احتمال و ترکیبیات (۱۰، ۱۱، ۱۲)',
    ],
    popularBooks: [
      'ریاضی تجربی جامع خیلی سبز',
      'مهر و ماه جامع ریاضی تجربی',
      'میکرو طلایی گاج',
      'هرکول آریان حیدری',
      'کتاب درسی ریاضی تجربی',
    ],
  },
  'زمین‌شناسی': {
    coefficient: 'ضریب ۱ (ترازساز)',
    color: '#0891b2',
    bgColor: 'bg-cyan-50 dark:bg-cyan-950/40',
    borderColor: 'border-cyan-300 dark:border-cyan-700',
    badgeColor: 'text-cyan-700 dark:text-cyan-300 bg-cyan-100 dark:bg-cyan-900/50',
    popularTopics: [
      'آفرینش زمین و شناخت سنگ‌ها',
      'منابع معدنی و اقتصادی',
      'منابع آب و خاک',
      'زمین‌شناسی و سلامت انسان',
    ],
    popularBooks: [
      'خیلی سبز زمین‌شناسی کنکور',
      'میکرو گاج زمین‌شناسی',
      'کتاب درسی زمین‌شناسی یازدهم',
    ],
  },
  'امتحانات نهایی / عمومی': {
    coefficient: 'تأثیر ۵۰ تا ۶۰ درصدی قطعی سوابق تحصیلی',
    color: '#e11d48',
    bgColor: 'bg-rose-50 dark:bg-rose-950/40',
    borderColor: 'border-rose-300 dark:border-rose-700',
    badgeColor: 'text-rose-700 dark:text-rose-300 bg-rose-100 dark:bg-rose-900/50',
    popularTopics: [
      'ادبیات فارسی ۳ (آرایه‌ها، لغت و تاریخ ادبیات)',
      'عربی زبان قرآن ۳ (قواعد و ترجمه نهایی)',
      'دین و زندگی ۳ (اندیشه و تحقیق و پیام آیات)',
      'زبان انگلیسی ۳ (گرامر، ریدینگ و واژگان)',
      'سلامت و بهداشت و هویت اجتماعی',
    ],
    popularBooks: [
      'فرمول بیست گاج',
      'شب امتحان خیلی سبز',
      'ماجرای من و درسام خیلی سبز',
      'کتاب‌های درسی دوازدهم',
    ],
  },
};

export const TAJROBI_SUBJECTS_LIST: TajrobiSubject[] = [
  'زیست‌شناسی',
  'شیمی',
  'فیزیک',
  'ریاضی تجربی',
  'زمین‌شناسی',
  'امتحانات نهایی / عمومی',
];

export const DIAGNOSTIC_FLAWS_CATALOG: DiagnosticFlaw[] = [
  {
    principle: 'تکرار فاصله‌دار و منحنی فراموشی ابینگهاوس (Spaced Repetition)',
    issue: 'مطالعه بدون پارت مرور ۲۴ ساعته و ۳۰ روزه باعث فراموشی ۷۰٪ مفاهیم می‌شود.',
    globalSolution: 'در تایم اختصاصی ۲۱:۱۵ الی ۲۲:۱۵ حتماً ۱۰ تا ۱۵ تست از مبحث ۲۴ ساعت قبل حل کنید.',
    severity: 'high',
  },
  {
    principle: 'بازیابی فعال در برابر روخوانی غیرفعال (Active Recall)',
    issue: 'روخوانی مکرر متن بدون تست زدن، توهم یادگیری ایجاد می‌کند.',
    globalSolution: 'قبل از شروع مرور، با تست‌های نشان‌دار یا آزمونک، مغز را درگیر بازیابی کنید.',
    severity: 'high',
  },
  {
    principle: 'تنوع مطالعاتی و یادگیری درهم‌تنیده (Interleaving)',
    issue: 'مطالعه یک درس یکنواخت برای بیش از ۴ ساعت متوالی بازدهی را به شدت کاهش می‌دهد.',
    globalSolution: 'پارت‌های تحلیلی (ریاضی/فیزیک) را بین پارت‌های خواندنی (زیست/شیمی) قرار دهید.',
    severity: 'medium',
  },
];

export function calculateStreak(studyLogs: StudyLog[]): number {
  if (!studyLogs || studyLogs.length === 0) return 0;
  const uniqueDates = Array.from(new Set(studyLogs.map((l) => l.date))).sort();
  return uniqueDates.length;
}

export function calculateLevelInfo(xp: number): { level: number; title: string; currentLevelXp: number; nextLevelXp: number; progressPercent: number } {
  const level = Math.floor(xp / 500) + 1;
  const currentLevelXp = (level - 1) * 500;
  const nextLevelXp = level * 500;
  const progressPercent = Math.min(100, Math.round(((xp - currentLevelXp) / 500) * 100));

  let title = 'داوطلب پرانرژی (سطح ۱)';
  if (level >= 10) title = 'اسطوره رتبه برتر و تراز ۸۰۰۰ 🔥';
  else if (level >= 8) title = 'پزشک آینده (تسلط فوق‌العاده) 🩺';
  else if (level >= 6) title = 'رتبه تک‌رقمی در حال ساخت 🏆';
  else if (level >= 4) title = 'قهرمان استمرار و نظم ⚡';
  else if (level >= 2) title = 'جوینده علم و تثبیت حافظه 🌟';

  return { level, title, currentLevelXp, nextLevelXp, progressPercent };
}

export function toPersianDigits(n: number | string): string {
  if (n === undefined || n === null) return '';
  const str = String(n);
  const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return str.replace(/[0-9]/g, (w) => persianDigits[+w]);
}

export const toFaDigits = toPersianDigits;

export function formatMinutesToHoursAndMinutes(totalMinutes: number): string {
  if (!totalMinutes || totalMinutes <= 0) return '۰ دقیقه';
  const hours = Math.floor(totalMinutes / 60);
  const mins = totalMinutes % 60;
  if (hours === 0) return `${toPersianDigits(mins)} دقیقه`;
  if (mins === 0) return `${toPersianDigits(hours)} ساعت`;
  return `${toPersianDigits(hours)} ساعت و ${toPersianDigits(mins)} دقیقه`;
}

export const ACADEMIC_MONTHS = [
  'مهر',
  'آبان',
  'آذر',
  'دی',
  'بهمن',
  'اسفند',
  'فروردین',
  'اردیبهشت',
  'خرداد',
];

export function getCurrentJalaliMonth(): string {
  return 'اسفند ماه';
}

export function formatISOToJalaliShort(isoStr: string): string {
  if (!isoStr) return getTodayJalali();
  return isoStr.split('T')[0] || getTodayJalali();
}

export function getTodayISO(): string {
  return new Date().toISOString().split('T')[0];
}

export function getOffsetDateISO(daysAgo: number): string {
  const d = new Date();
  d.setDate(d.getDate() - daysAgo);
  return d.toISOString().split('T')[0];
}

export function getTodayJalali(): string {
  try {
    return new Intl.DateTimeFormat('fa-IR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    }).format(new Date());
  } catch {
    return 'امروز';
  }
}

export function getTodayPersianDayOfWeek(): DayOfWeek {
  const dayIndex = new Date().getDay(); // 0 = Sunday, 1 = Monday, ..., 6 = Saturday
  const map: Record<number, DayOfWeek> = {
    0: 'یکشنبه',
    1: 'دوشنبه',
    2: 'سه‌شنبه',
    3: 'چهارشنبه',
    4: 'پنجشنبه',
    5: 'جمعه',
    6: 'شنبه',
  };
  return map[dayIndex] || 'یکشنبه';
}

export function calculateDaysUntilExam(targetDateString: string): number {
  try {
    const target = new Date(targetDateString).getTime();
    const now = new Date().getTime();
    const diff = target - now;
    return Math.max(0, Math.ceil(diff / (1000 * 60 * 60 * 24)));
  } catch {
    return 200;
  }
}

export function calculateCountdownDetails(targetDateString: string) {
  const days = calculateDaysUntilExam(targetDateString);
  return {
    days,
    weeks: Math.floor(days / 7),
    hours: days * 24,
    minutes: days * 24 * 60,
    seconds: days * 24 * 3600,
    isPast: days <= 0,
  };
}

export function analyzePlanWithGlobalMethods(_parts?: unknown, _logs?: unknown, _dayOfWeek?: unknown): {
  score: number;
  summary: string;
  recommendations: string[];
  flaws: DiagnosticFlaw[];
  activeRecallRatio: number;
  interleavingScore: number;
} {
  return {
    score: 95,
    summary: 'برنامه کاملاً بهینه، منظم و هماهنگ با متد ابینگهاوس و استارت یکشنبه',
    recommendations: ['به روتین مطالعاتی و تایم‌های مرور ادامه دهید'],
    flaws: [],
    activeRecallRatio: 90,
    interleavingScore: 92,
  };
}

export function detectGradeFromText(text: string = ''): GradeLevel {
  if (text.includes('دهم') || text.includes('10')) return 'دهم';
  if (text.includes('یازدهم') || text.includes('11')) return 'یازدهم';
  if (text.includes('دوازدهم') || text.includes('12')) return 'دوازدهم';
  if (text.includes('عمومی') || text.includes('نهایی')) return 'عمومی و نهایی';
  return 'جامع';
}

export function checkLateStartMinutes(scheduledTime: string): number {
  if (!scheduledTime || !scheduledTime.includes(':')) return 0;
  const [schedH, schedM] = scheduledTime.split(':').map(Number);
  if (isNaN(schedH) || isNaN(schedM)) return 0;
  const now = new Date();
  const scheduledTotalMins = schedH * 60 + schedM;
  const currentTotalMins = now.getHours() * 60 + now.getMinutes();
  return currentTotalMins - scheduledTotalMins;
}

export function playChimeSound() {
  try {
    const AudioContextClass =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    const now = ctx.currentTime;

    const playTone = (freq: number, start: number, duration: number) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + start);
      gain.gain.setValueAtTime(0.001, now + start);
      gain.gain.exponentialRampToValueAtTime(0.3, now + start + 0.05);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + start + duration);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + start);
      osc.stop(now + start + duration);
    };

    playTone(523.25, 0.0, 0.4); // C5
    playTone(659.25, 0.2, 0.4); // E5
    playTone(783.99, 0.4, 0.8); // G5
  } catch {
    // audio restricted
  }
}

export function getDefaultExams(): ExamCountdownItem[] {
  return [];
}

// Zeroed Clean Initial State Starting from Sunday (یکشنبه)
export function createInitialState(): AppState {
  return {
    activeTab: 'dashboard',
    parts: [],
    blocks: [
      { id: 1, blockNumber: 1, startTime: '06:00', endTime: '07:30', timeRange: '06:00 - 07:30', label: 'بیداری و آماده‌سازی صبح', activityType: 'personal' },
      { id: 2, blockNumber: 2, startTime: '07:30', endTime: '09:00', timeRange: '07:30 - 09:00', label: 'مدرسه و کلاس درس', activityType: 'school' },
      { id: 3, blockNumber: 3, startTime: '09:00', endTime: '10:30', timeRange: '09:00 - 10:30', label: 'مدرسه و تدریس', activityType: 'school' },
      { id: 4, blockNumber: 4, startTime: '10:30', endTime: '12:00', timeRange: '10:30 - 12:00', label: 'مدرسه و آزمونک کلاسی', activityType: 'school' },
      { id: 5, blockNumber: 5, startTime: '12:00', endTime: '13:30', timeRange: '12:00 - 13:30', label: 'پایان مدرسه و بازگشت به خانه', activityType: 'school' },
      { id: 6, blockNumber: 6, startTime: '13:30', endTime: '15:00', timeRange: '13:30 - 15:00', label: 'ناهار و استراحت نیمروزی', activityType: 'rest' },
      { id: 7, blockNumber: 7, startTime: '15:15', endTime: '17:15', timeRange: '15:15 - 17:15', label: 'پارت ۱: مطالعه و تست', activityType: 'study', subject: 'زیست‌شناسی', topic: '' },
      { id: 8, blockNumber: 8, startTime: '17:30', endTime: '19:15', timeRange: '17:30 - 19:15', label: 'پارت ۲: مطالعه و تست', activityType: 'study', subject: 'شیمی', topic: '' },
      { id: 9, blockNumber: 9, startTime: '19:30', endTime: '21:00', timeRange: '19:30 - 21:00', label: 'پارت ۳: مطالعه و تست', activityType: 'study', subject: 'فیزیک', topic: '' },
      { id: 10, blockNumber: 10, startTime: '21:15', endTime: '22:15', timeRange: '21:15 - 22:15', label: '🧠 تایم مرور اختصاصی ابینگهاوس', activityType: 'study', subject: 'زیست‌شناسی', topic: 'مرور' },
      { id: 11, blockNumber: 11, startTime: '22:15', endTime: '23:15', timeRange: '22:15 - 23:15', label: 'ثبت کارنامه شبانه و شام', activityType: 'personal' },
      { id: 12, blockNumber: 12, startTime: '23:15', endTime: '06:00', timeRange: '23:15 - 06:00', label: 'خواب عمیق شبانه', activityType: 'sleep' },
    ],
    compensations: [],
    studyLogs: [],
    exams: getDefaultExams(),
    notes: [],
    diagnosticReports: [],
    settings: {
      studentName: 'داوطلب عزیز',
      examTitle: 'کنکور سراسری تجربی',
      examDate: '2027-04-24T08:00:00',
      dailyTestGoal: 100,
      weeklyStudyMinutesGoal: 1800,
      notificationsEnabled: true,
      darkMode: false,
      countdownMode: true,
      theme: 'emerald',
      weekStartDay: 'یکشنبه',
    },
    reminders: getDefaultReminders(),
    weeklySchedule: getDefaultWeeklySchedule(),
    topicMemories: getDefaultTopicMemories(),
    monthlyPlan: undefined,
    annualPlan: undefined,
    xp: 0,
  };
}

export const createInitialTajrobiState = createInitialState;
