import { GoogleGenAI } from '@google/genai';
import {
  AnnualPlanRoadmap,
  DayOfWeek,
  DaySchedule,
  GradeLevel,
  MonthlyPlanRoadmap,
  MonthlyPlanWeek,
  StudyPart,
  TajrobiSubject,
  TopicMemoryItem,
  WeeklySlot,
} from '../types';
import {
  DAYS_OF_WEEK,
  TAJROBI_SUBJECTS_LIST,
  formatMinutesToHoursAndMinutes,
  getDefaultAnnualPlan,
  getDefaultMonthlyPlan,
  getOffsetDateISO,
  getTodayISO,
  getTodayJalali,
  getTodayPersianDayOfWeek,
  toPersianDigits,
} from './tajrobiData';

export interface GeneratedPlanResult {
  planType: 'daily' | 'weekly' | 'monthly' | 'annual';
  summary: string;
  advice: string;
  totalHours: number;
  totalTests: number;
  autoInjectedReviews?: Array<{ topic: string; subject: TajrobiSubject; reason: string }>;
  dailyParts?: Array<{
    subject: TajrobiSubject;
    gradeLevel: GradeLevel;
    topic: string;
    bookSource: string;
    startTime: string;
    endTime: string;
    estimatedMinutes: number;
    testCount: number;
    priority: 'high' | 'medium' | 'low';
    isImportant: boolean;
    isSpacedReview?: boolean;
  }>;
  weeklySchedule?: Record<DayOfWeek, DaySchedule>;
  monthlyPlan?: MonthlyPlanRoadmap;
  annualPlan?: AnnualPlanRoadmap;
}

// Calculate next review based on Ebbinghaus curve
export function calculateNextEbbinghausDate(level: number, baseDate: string = getTodayISO()): { nextDate: string; intervalDays: number } {
  const intervals = [1, 3, 7, 15, 30];
  const days = intervals[Math.min(level - 1, intervals.length - 1)] || 7;
  return {
    nextDate: getOffsetDateISO(-days), // days in future
    intervalDays: days,
  };
}

// Main AI Planning function
export async function generateComprehensiveAIPlan({
  planType,
  userPrompt,
  targetDay = getTodayPersianDayOfWeek(),
  schoolHours = '07:30 - 13:30',
  isSchoolDay = true,
  dailyTestGoal = 100,
  topicMemories = [],
  studiedTopicsPrompt = '',
}: {
  planType: 'daily' | 'weekly' | 'monthly' | 'annual';
  userPrompt: string;
  targetDay?: DayOfWeek;
  schoolHours?: string;
  isSchoolDay?: boolean;
  dailyTestGoal?: number;
  topicMemories?: TopicMemoryItem[];
  studiedTopicsPrompt?: string;
}): Promise<GeneratedPlanResult> {
  const apiKey =
    (typeof import.meta !== 'undefined' && import.meta.env?.VITE_GEMINI_API_KEY) ||
    (typeof process !== 'undefined' && process.env?.GEMINI_API_KEY) ||
    '';

  // Find topics due for review
  const todayISO = getTodayISO();
  const dueReviews = topicMemories.filter((m) => m.nextReviewDate <= todayISO);

  const memoryContext = topicMemories.length > 0
    ? `\nحافظه مبحثی ذخیره‌شده دانش‌آموز:\n${topicMemories
        .map(
          (m) =>
            `- ${m.subject} (${m.gradeLevel}): «${m.topic}» (سطح مرور ${m.reviewLevel} از ۵، تاریخ مرور بعدی: ${m.nextReviewJalali || m.nextReviewDate})`
        )
        .join('\n')}`
    : '';

  const systemInstruction = `شما یک مشاور ارشد و برنامه‌ریز فوق‌تخصصی کنکور سراسری تجربی در ایران هستید.
وظیفه شما تدوین ${
    planType === 'annual'
      ? 'استراتژی و نقشه راه جامع سالانه کنکور تجربی با هدف اتمام ۱۰۰٪ دروس پایه دهم، یازدهم و دوازدهم تا پایان اسفند ماه'
      : planType === 'weekly'
      ? 'برنامه هفتگی کامل (شنبه تا جمعه)'
      : planType === 'monthly'
      ? 'برنامه ماهانه راهبردی (۴ هفته)'
      : 'برنامه روزانه دقیق'
  } است.

اصول و متدهای علمی الزامی در برنامه‌ریزی:
۱. در استراتژی سالانه و ماهانه: هدف اصلی اتمام کامل تمام مباحث تخصصی دهم و یازدهم و کل دوازدهم تا ۲۹ اسفند ماه است تا دانش‌آموز با خیال آسوده وارد دوران طلایی نوروز، آزمون‌های ۳ روز یکبار و امتحانات نهایی شود.
۲. منحنی ابینگهاوس و فاصله‌گذاری (Spaced Repetition): مرورهای ۱، ۳، ۷، ۱۵ و ۳۰ روزه باید در برنامه لحاظ شوند.
۳. بازیابی فعال (Active Recall): استفاده از تست‌زنی سنجشی و پوششی به جای روخوانی غیرفعال.
۴. یادگیری درهم‌تنیده (Interleaving Method): ترکیب دروس تحلیلی (ریاضی/فیزیک) با دروس مفهومی (زیست/شیمی).
۵. روزهای مدرسه (شنبه تا چهارشنبه): ساعات حضور در مدرسه (${schoolHours}) به عنوان اسلات school لحاظ شود و مطالعه مفید بعدازظهر (۱۵:۱۵ تا ۲۳:۰۰) چیده شود.
۶. ایستگاه‌های جبرانی (Compensation Buffers): در پایان هر هفته یا ماه برای صفر کردن عقب‌ماندگی‌ها.

پاسخ شما باید صرفاً به صورت یک JSON استاندارد باشد بدون هیچ علامت مارک‌داون اضافی (\`\`\`json).`;

  if (apiKey) {
    try {
      const ai = new GoogleGenAI({ apiKey });
      const promptText = `نوع برنامه درخواستی: ${planType}
درخواست داوطلب: "${userPrompt}"
مباحث خوانده شده اخیر یا در حال مطالعه: "${studiedTopicsPrompt}"
روز هدف: ${targetDay}
ساعت مدرسه در روزهای درسی: ${schoolHours}
${memoryContext}
لطفا یک برنامه دقیق و کامل ${planType} طبق استانداردهای علمی کنکور تجربی با تراز ۷۰۰۰ تولید کن.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: [{ role: 'user', parts: [{ text: promptText }] }],
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          temperature: 0.3,
        },
      });

      const responseText = response.text || '';
      const cleanJson = responseText.replace(/```json/g, '').replace(/```/g, '').trim();
      const parsed = JSON.parse(cleanJson);
      if (parsed) {
        return sanitizeAIPlanResult(parsed, planType, targetDay, schoolHours, topicMemories);
      }
    } catch (err) {
      console.warn('Gemini API call error, falling back to expert rule engine:', err);
    }
  }

  // Fallback Rule-Based Engine
  return generateRuleBasedPlanAdvanced(
    planType,
    userPrompt,
    targetDay,
    schoolHours,
    isSchoolDay,
    topicMemories,
    studiedTopicsPrompt
  );
}

// Sanitize & Format Output
function sanitizeAIPlanResult(
  parsed: any,
  planType: 'daily' | 'weekly' | 'monthly' | 'annual',
  targetDay: DayOfWeek,
  schoolHours: string,
  topicMemories: TopicMemoryItem[]
): GeneratedPlanResult {
  return {
    planType,
    summary: parsed.summary || 'برنامه هوشمند شما با موفقیت تدوین شد.',
    advice: parsed.advice || 'توصیه مشاور: تمرکز بر تست‌های زمان‌دار، مرورهای شبانه و اتمام مباحث تا اسفند ماه.',
    totalHours: parsed.totalHours || (planType === 'annual' ? 1450 : planType === 'weekly' ? 44 : planType === 'monthly' ? 175 : 6.5),
    totalTests: parsed.totalTests || (planType === 'annual' ? 18500 : planType === 'weekly' ? 480 : planType === 'monthly' ? 1900 : 100),
    autoInjectedReviews: parsed.autoInjectedReviews || [],
    dailyParts: Array.isArray(parsed.dailyParts) ? parsed.dailyParts : Array.isArray(parsed.parts) ? parsed.parts : undefined,
    weeklySchedule: parsed.weeklySchedule || undefined,
    monthlyPlan: parsed.monthlyPlan || undefined,
    annualPlan: parsed.annualPlan || (planType === 'annual' ? getDefaultAnnualPlan() : undefined),
  };
}

// Rule-Based Expert Engine
function generateRuleBasedPlanAdvanced(
  planType: 'daily' | 'weekly' | 'monthly' | 'annual',
  userPrompt: string,
  targetDay: DayOfWeek,
  schoolHours: string,
  isSchoolDay: boolean,
  topicMemories: TopicMemoryItem[],
  studiedTopicsPrompt: string
): GeneratedPlanResult {
  const p = (userPrompt + ' ' + studiedTopicsPrompt).toLowerCase();

  // 1. ANNUAL STRATEGY ROADMAP
  if (planType === 'annual') {
    const defaultAnnual = getDefaultAnnualPlan();
    return {
      planType: 'annual',
      summary: `🗺️ استراتژی سالانه جامع کنکور تجربی: اتمام ۱۰۰٪ دروس پایه دهم، یازدهم و کل دوازدهم تا ۲۹ اسفند ماه با متدهای علمی روز دنیا (اسپیسینگ ابینگهاوس، بازیابی فعال، ایستگاه‌های جبرانی و جمع‌بندی نوروزی).`,
      advice: `توصیه مشاور ارشد: طبق استراتژی تدوین‌شده، کل دروس اختصاصی دهم و یازدهم و تمام کتاب‌های دوازدهم تا پایان اسفند با حداقل ۱۸,۵۰۰ تست بسته می‌شوند. فروردین ماه به دوران طلایی جمع‌بندی نوروز و اردیبهشت به امتحانات نهایی و آزمون‌های جامع اختصاص می‌یابد.`,
      totalHours: 1450,
      totalTests: 18500,
      autoInjectedReviews: [
        { topic: 'زیست دهم و یازدهم', subject: 'زیست‌شناسی', reason: 'ایستگاه جمع‌بندی دی‌ماه و مرور طلایی اسفند' },
        { topic: 'استوکیومتری و شیمی پایه', subject: 'شیمی', reason: 'مرورهای دوره‌ای هر ۳ هفته یکبار' },
        { topic: 'فیزیک حرکت و دینامیک', subject: 'فیزیک', reason: 'تست‌های پوششی ماهانه' },
        { topic: 'مثلثات و مشتق ریاضی', subject: 'ریاضی تجربی', reason: 'حل تست‌های زمان‌دار در ایستگاه‌های جبرانی' },
      ],
      annualPlan: defaultAnnual,
    };
  }

  // 2. DAILY PLAN
  if (planType === 'daily') {
    const isHoliday = targetDay === 'جمعه' || targetDay === 'پنجشنبه' || p.includes('تعطیل');
    const dailyParts: GeneratedPlanResult['dailyParts'] = [];

    if (!isHoliday) {
      dailyParts.push(
        {
          subject: 'زیست‌شناسی',
          gradeLevel: 'دوازدهم',
          topic: p.includes('رونویسی') ? 'رونویسی و پروتئین‌سازی' : 'پارت مفهومی زیست‌شناسی + تست خط‌به‌خط',
          bookSource: 'خیلی سبز / آی‌کیو گاج',
          startTime: '15:15',
          endTime: '17:15',
          estimatedMinutes: 120,
          testCount: 40,
          priority: 'high',
          isImportant: true,
        },
        {
          subject: 'شیمی',
          gradeLevel: 'یازدهم',
          topic: p.includes('استوکیومتری') ? 'استوکیومتری واکنش‌ها و بازده درصدی' : 'مسائل عددی و آنتالپی',
          bookSource: 'مبتکران / خیلی سبز',
          startTime: '17:30',
          endTime: '19:15',
          estimatedMinutes: 105,
          testCount: 30,
          priority: 'high',
          isImportant: true,
        },
        {
          subject: p.includes('ریاضی') ? 'ریاضی تجربی' : 'فیزیک',
          gradeLevel: 'دوازدهم',
          topic: p.includes('فیزیک') ? 'حرکت‌شناسی و شتاب ثابت' : 'مثلثات و توابع مرکب',
          bookSource: 'میکرو گاج / الگو',
          startTime: '19:30',
          endTime: '21:00',
          estimatedMinutes: 90,
          testCount: 25,
          priority: 'medium',
          isImportant: false,
        },
        // Automatically Injected Review Slot from Memory
        {
          subject: 'زیست‌شناسی',
          gradeLevel: 'دهم',
          topic: '🧠 مرور فاصله‌دار ابینگهاوس: شکل‌های قلب و گردش خون (تثبیت حافظه)',
          bookSource: 'کتاب درسی + جعبه لایتنر',
          startTime: '21:15',
          endTime: '22:00',
          estimatedMinutes: 45,
          testCount: 15,
          priority: 'high',
          isImportant: true,
          isSpacedReview: true,
        },
        {
          subject: 'امتحانات نهایی / عمومی',
          gradeLevel: 'عمومی و نهایی',
          topic: 'دینی و فارسی ۳ (آرایه‌های ادبی و اندیشه و تحقیق)',
          bookSource: 'فرمول بیست گاج',
          startTime: '22:00',
          endTime: '22:45',
          estimatedMinutes: 45,
          testCount: 10,
          priority: 'medium',
          isImportant: false,
        }
      );
    } else {
      // Holiday / Friday full schedule
      dailyParts.push(
        {
          subject: 'زیست‌شناسی',
          gradeLevel: 'دوازدهم',
          topic: 'زیست دوازدهم (مباحث پیشرفته + ۶۰ تست زمان‌دار)',
          bookSource: 'آی‌کیو گاج',
          startTime: '08:00',
          endTime: '10:30',
          estimatedMinutes: 150,
          testCount: 60,
          priority: 'high',
          isImportant: true,
        },
        {
          subject: 'شیمی',
          gradeLevel: 'یازدهم',
          topic: 'مسائل استوکیومتری و سینتیک شیمیایی',
          bookSource: 'خیلی سبز / مبتکران',
          startTime: '10:45',
          endTime: '12:45',
          estimatedMinutes: 120,
          testCount: 45,
          priority: 'high',
          isImportant: true,
        },
        {
          subject: 'فیزیک',
          gradeLevel: 'دوازدهم',
          topic: 'دینامیک و قوانین نیوتون + تکانه',
          bookSource: 'خیلی سبز / نشر الگو',
          startTime: '14:15',
          endTime: '16:15',
          estimatedMinutes: 120,
          testCount: 35,
          priority: 'high',
          isImportant: true,
        },
        {
          subject: 'ریاضی تجربی',
          gradeLevel: 'دهم',
          topic: 'مثلثات و توابع درجه دو دهم',
          bookSource: 'میکرو گاج',
          startTime: '16:30',
          endTime: '18:30',
          estimatedMinutes: 120,
          testCount: 30,
          priority: 'medium',
          isImportant: false,
        },
        {
          subject: 'زیست‌شناسی',
          gradeLevel: 'دهم',
          topic: '🧠 مرور فاصله‌دار ابینگهاوس: بافت‌های جانوری و قلب',
          bookSource: 'جعبه لایتنر',
          startTime: '19:00',
          endTime: '20:00',
          estimatedMinutes: 60,
          testCount: 20,
          priority: 'high',
          isImportant: true,
          isSpacedReview: true,
        },
        {
          subject: 'امتحانات نهایی / عمومی',
          gradeLevel: 'عمومی و نهایی',
          topic: 'عربی و ادبیات دوازدهم نهایی',
          bookSource: 'فرمول بیست',
          startTime: '20:15',
          endTime: '21:30',
          estimatedMinutes: 75,
          testCount: 20,
          priority: 'medium',
          isImportant: false,
        }
      );
    }

    const totalMinutes = dailyParts.reduce((acc, p) => acc + p.estimatedMinutes, 0);
    const totalTests = dailyParts.reduce((acc, p) => acc + p.testCount, 0);

    return {
      planType: 'daily',
      summary: `برنامه روزانه اختصاصی روز ${targetDay}: شامل ${dailyParts.length} پارت درسی با مجموع ${formatMinutesToHoursAndMinutes(
        totalMinutes
      )} مطالعه و ${totalTests} تست، همراه با اسلات مرور خودکار حافظه مبحثی.`,
      advice: `توصیه مشاور: بین پارت‌ها استراحت‌های ۱۵ دقیقه‌ای را رعایت کرده و پارت مرور ابینگهاوس شبانه را با بازیابی فعال حل کنید.`,
      totalHours: Number((totalMinutes / 60).toFixed(1)),
      totalTests,
      autoInjectedReviews: [
        {
          topic: 'شکل‌های قلب و گردش خون (زیست دهم)',
          subject: 'زیست‌شناسی',
          reason: 'موعد مرور روز ۷ بر اساس منحنی فراموشی ابینگهاوس',
        },
      ],
      dailyParts,
    };
  }

  // 3. WEEKLY PLAN
  if (planType === 'weekly') {
    const weeklySchedule: Record<DayOfWeek, DaySchedule> = {
      'شنبه': {
        day: 'شنبه',
        dayType: 'school',
        titleNotes: 'روز مدرسه (شروع پرانرژی هفته با زیست دوازدهم و شیمی دهم)',
        slots: [
          { id: 'w-11', startTime: '07:30', endTime: '13:30', title: 'حضور در مدرسه', activityType: 'school' },
          { id: 'w-12', startTime: '13:30', endTime: '15:15', title: 'ناهار و استراحت', activityType: 'rest' },
          { id: 'w-13', startTime: '15:15', endTime: '17:15', title: 'زیست دوازدهم (مولکول‌های اطلاعاتی و DNA)', activityType: 'study', subject: 'زیست‌شناسی', gradeLevel: 'دوازدهم', topic: 'ساختار نوکلئیک‌اسیدها و همانندسازی', targetTests: 40, isImportant: true },
          { id: 'w-14', startTime: '17:30', endTime: '19:15', title: 'شیمی دهم (کیهان و جدول تناوبی)', activityType: 'study', subject: 'شیمی', gradeLevel: 'دهم', topic: 'آرایش الکترونی و روند شعاع اتمی', targetTests: 30 },
          { id: 'w-15', startTime: '19:30', endTime: '21:00', title: 'فیزیک دوازدهم (حرکت با شتاب ثابت)', activityType: 'study', subject: 'فیزیک', gradeLevel: 'دوازدهم', topic: 'معادلات حرکت و رسم نمودار مکان-زمان', targetTests: 25 },
          { id: 'w-16', startTime: '21:15', endTime: '22:15', title: '🧠 مرور ابینگهاوس زیست دهم (قلب)', activityType: 'study', subject: 'زیست‌شناسی', gradeLevel: 'دهم', topic: 'مرور ۷ روزه ساختار دریچه‌ها و نوار قلب', targetTests: 20, isImportant: true },
        ],
      },
      'یکشنبه': {
        day: 'یکشنبه',
        dayType: 'school',
        titleNotes: 'روز مدرسه (ریاضی مثلثات + زیست گوارش دهم)',
        slots: [
          { id: 'w-21', startTime: '07:30', endTime: '13:30', title: 'حضور در مدرسه', activityType: 'school' },
          { id: 'w-22', startTime: '13:30', endTime: '15:15', title: 'ناهار و استراحت', activityType: 'rest' },
          { id: 'w-23', startTime: '15:15', endTime: '17:15', title: 'ریاضی تجربی (مثلثات و اتحادها)', activityType: 'study', subject: 'ریاضی تجربی', gradeLevel: 'یازدهم', topic: 'دایره مثلثاتی و روابط کمان‌ها', targetTests: 35, isImportant: true },
          { id: 'w-24', startTime: '17:30', endTime: '19:15', title: 'زیست دهم (گوارش و جذب مواد)', activityType: 'study', subject: 'زیست‌شناسی', gradeLevel: 'دهم', topic: 'حرکات لوله گوارش و آنزیم‌های معده', targetTests: 35 },
          { id: 'w-25', startTime: '19:30', endTime: '21:00', title: 'فیزیک یازدهم (الکتریسیته ساکن و خازن)', activityType: 'study', subject: 'فیزیک', gradeLevel: 'یازدهم', topic: 'میدان الکتریکی و انرژی خازن', targetTests: 25 },
          { id: 'w-26', startTime: '21:15', endTime: '22:15', title: 'ادبیات فارسی ۳ امتحان نهایی', activityType: 'study', subject: 'امتحانات نهایی / عمومی', gradeLevel: 'عمومی و نهایی', topic: 'آرایه‌های ادبی و دستور زبان' },
        ],
      },
      'دوشنبه': {
        day: 'دوشنبه',
        dayType: 'school',
        titleNotes: 'روز مدرسه (شیمی اسید و باز + زیست رونویسی)',
        slots: [
          { id: 'w-31', startTime: '07:30', endTime: '13:30', title: 'حضور در مدرسه', activityType: 'school' },
          { id: 'w-32', startTime: '13:30', endTime: '15:15', title: 'ناهار و استراحت', activityType: 'rest' },
          { id: 'w-33', startTime: '15:15', endTime: '17:15', title: 'شیمی دوازدهم (اسیدها، بازها و pH)', activityType: 'study', subject: 'شیمی', gradeLevel: 'دوازدهم', topic: 'یونش اسید ضعیف و تعادل آب', targetTests: 35, isImportant: true },
          { id: 'w-34', startTime: '17:30', endTime: '19:15', title: 'زیست دوازدهم (رونویسی RNA و پردازش)', activityType: 'study', subject: 'زیست‌شناسی', gradeLevel: 'دوازدهم', topic: 'آنزیم RNA پلیمراز و اینترون‌ها', targetTests: 40 },
          { id: 'w-35', startTime: '19:30', endTime: '21:00', title: '🧠 مرور ابینگهاوس شیمی (استوکیومتری)', activityType: 'study', subject: 'شیمی', gradeLevel: 'یازدهم', topic: 'مرور ۳ روزه فرمول‌های استوکیومتری', targetTests: 20, isImportant: true },
          { id: 'w-36', startTime: '21:15', endTime: '22:15', title: 'دینی ۳ امتحان نهایی', activityType: 'study', subject: 'امتحانات نهایی / عمومی', gradeLevel: 'عمومی و نهایی', topic: 'اندیشه و تحقیق درس ۱ تا ۳' },
        ],
      },
      'سه‌شنبه': {
        day: 'سه‌شنبه',
        dayType: 'school',
        titleNotes: 'روز مدرسه (زیست تقسیم سلولی + ریاضی حد)',
        slots: [
          { id: 'w-41', startTime: '07:30', endTime: '13:30', title: 'حضور در مدرسه', activityType: 'school' },
          { id: 'w-42', startTime: '13:30', endTime: '15:15', title: 'ناهار و استراحت', activityType: 'rest' },
          { id: 'w-43', startTime: '15:15', endTime: '17:15', title: 'زیست یازدهم (میتوز و میوز و ژنتیک)', activityType: 'study', subject: 'زیست‌شناسی', gradeLevel: 'یازدهم', topic: 'کروموزوم‌ها و تقسیم یاخته', targetTests: 40, isImportant: true },
          { id: 'w-44', startTime: '17:30', endTime: '19:15', title: 'ریاضی تجربی (حد و پیوستگی)', activityType: 'study', subject: 'ریاضی تجربی', gradeLevel: 'دوازدهم', topic: 'محاسبه حد توابع کسری', targetTests: 30 },
          { id: 'w-45', startTime: '19:30', endTime: '21:00', title: 'زمین‌شناسی کنکور', activityType: 'study', subject: 'زمین‌شناسی', gradeLevel: 'یازدهم', topic: 'منابع معدنی و اقتصادی', targetTests: 25 },
          { id: 'w-46', startTime: '21:15', endTime: '22:15', title: 'زبان انگلیسی نهایی (گرامر و واژگان)', activityType: 'study', subject: 'امتحانات نهایی / عمومی', gradeLevel: 'عمومی و نهایی', topic: 'درس ۱ و ۲ زبان ۳' },
        ],
      },
      'چهارشنبه': {
        day: 'چهارشنبه',
        dayType: 'school',
        titleNotes: 'روز مدرسه (زیست تنفس سلولی + شیمی الکتروشیمی)',
        slots: [
          { id: 'w-51', startTime: '07:30', endTime: '13:30', title: 'حضور در مدرسه', activityType: 'school' },
          { id: 'w-52', startTime: '13:30', endTime: '15:15', title: 'ناهار و استراحت', activityType: 'rest' },
          { id: 'w-53', startTime: '15:15', endTime: '17:15', title: 'زیست دوازدهم (تنفس سلولی و گلیکولیز)', activityType: 'study', subject: 'زیست‌شناسی', gradeLevel: 'دوازدهم', topic: 'میتوکندری و زنجیره انتقال الکترون', targetTests: 40, isImportant: true },
          { id: 'w-54', startTime: '17:30', endTime: '19:15', title: 'شیمی دوازدهم (سلول‌های گالوانی)', activityType: 'study', subject: 'شیمی', gradeLevel: 'دوازدهم', topic: 'اکسایش و کاهش و پتانسیل استاندارد', targetTests: 30 },
          { id: 'w-55', startTime: '19:30', endTime: '21:00', title: 'فیزیک یازدهم (مغناطیس و القا)', activityType: 'study', subject: 'فیزیک', gradeLevel: 'یازدهم', topic: 'میدان مغناطیسی سیم و پیچه', targetTests: 25 },
          { id: 'w-56', startTime: '21:15', endTime: '22:15', title: '🧠 مرور ابینگهاوس فیزیک (حرکت‌شناسی)', activityType: 'study', subject: 'فیزیک', gradeLevel: 'دوازدهم', topic: 'مرور ۷ روزه فرمول‌های شتاب ثابت', targetTests: 15, isImportant: true },
        ],
      },
      'پنجشنبه': {
        day: 'پنجشنبه',
        dayType: 'holiday',
        titleNotes: 'روز نیمه‌تعطیل و آمادگی آزمون (مرورهای طلایی + جبرانی)',
        slots: [
          { id: 'w-61', startTime: '08:00', endTime: '10:30', title: 'زیست‌شناسی جامع (آزمونک جامع زیست)', activityType: 'study', subject: 'زیست‌شناسی', gradeLevel: 'جامع', topic: 'تست‌های ترکیبی جانوری و ژنتیک', targetTests: 60, isImportant: true },
          { id: 'w-62', startTime: '10:45', endTime: '12:45', title: 'شیمی جامع (حل مسائل زمان‌دار)', activityType: 'study', subject: 'شیمی', gradeLevel: 'جامع', topic: 'تست‌های ترکیبی شیمی ۱۰ و ۱۱ و ۱۲', targetTests: 40, isImportant: true },
          { id: 'w-63', startTime: '14:15', endTime: '16:15', title: 'فیزیک جامع (تست‌های کنکور سراسری)', activityType: 'study', subject: 'فیزیک', gradeLevel: 'جامع', topic: 'تست‌های ۵ سال اخیر کنکور', targetTests: 35 },
          { id: 'w-64', startTime: '16:30', endTime: '18:30', title: 'ریاضی تجربی (آزمونک مباحث هفته)', activityType: 'study', subject: 'ریاضی تجربی', gradeLevel: 'دوازدهم', topic: 'تست‌های زمان‌دار تابع و مثلثات', targetTests: 30 },
          { id: 'w-65', startTime: '19:00', endTime: '21:00', title: '⚠️ پارت جبرانی عقب‌ماندگی‌های هفته', activityType: 'study', subject: 'زیست‌شناسی', gradeLevel: 'دوازدهم', topic: 'رفع اشکال تست‌های غلط و علامت‌دار', targetTests: 25 },
        ],
      },
      'جمعه': {
        day: 'جمعه',
        dayType: 'holiday',
        titleNotes: 'روز آزمون آزمایشی، تحلیل آزمون و مرور ۳۰ روزه ماهانه',
        slots: [
          { id: 'w-71', startTime: '08:00', endTime: '12:00', title: '🎯 شبیه‌ساز آزمون جامع کنکور تجربی', activityType: 'study', subject: 'زیست‌شناسی', gradeLevel: 'جامع', topic: 'آزمون قلم‌چی / ماز / سنجش', targetTests: 115, isImportant: true },
          { id: 'w-72', startTime: '12:00', endTime: '14:30', title: 'ناهار و استراحت جمعه', activityType: 'rest' },
          { id: 'w-73', startTime: '14:30', endTime: '17:30', title: '🔍 تحلیل دقیق آزمون (زیست، شیمی، فیزیک، ریاضی)', activityType: 'study', subject: 'زیست‌شناسی', gradeLevel: 'جامع', topic: 'ثبت نکات غلط و دام‌های آموزشی', targetTests: 40, isImportant: true },
          { id: 'w-74', startTime: '18:00', endTime: '19:30', title: '🧠 مرور طلایی ابینگهاوس ۳۰ روزه کل مباحث', activityType: 'study', subject: 'شیمی', gradeLevel: 'یازدهم', topic: 'تثبیت دائم در حافظه بلندمدت هیپوکامپ', targetTests: 25, isImportant: true },
          { id: 'w-75', startTime: '20:00', endTime: '21:30', title: 'برنامه‌ریزی هفته آینده و استراحت شبانه', activityType: 'rest' },
        ],
      },
    };

    return {
      planType: 'weekly',
      summary: `برنامه هفتگی کامل ۷ روزه (شنبه تا جمعه): با تفکیک دقیق ساعت مدرسه در روزهای شنبه تا چهارشنبه (${schoolHours}) و برنامه فول‌تایم آخر هفته + ۴ پارت مرور خودکار ابینگهاوس.`,
      advice: `توصیه مشاور: تمام روزهای شنبه تا چهارشنبه ساعت مدرسه لحاظ شده و مرورهای ۱ روزه، ۳ روزه، ۷ روزه و ۳۰ روزه بر اساس حافظه مبحثی به صورت اتوماتیک در برنامه پخش شده‌اند.`,
      totalHours: 43.5,
      totalTests: 490,
      autoInjectedReviews: [
        { topic: 'ساختار قلب زیست دهم', subject: 'زیست‌شناسی', reason: 'مرور ۷ روزه ابینگهاوس (شنبه)' },
        { topic: 'فرمول‌های استوکیومتری شیمی', subject: 'شیمی', reason: 'مرور ۳ روزه ابینگهاوس (دوشنبه)' },
        { topic: 'فرمول‌های شتاب ثابت فیزیک', subject: 'فیزیک', reason: 'مرور ۷ روزه ابینگهاوس (چهارشنبه)' },
        { topic: 'مرور ۳۰ روزه کل مباحث ماه', subject: 'شیمی', reason: 'مرور طلایی ماهانه ابینگهاوس (جمعه)' },
      ],
      weeklySchedule,
    };
  }

  // 4. MONTHLY ROADMAP
  const monthlyPlan = getDefaultMonthlyPlan();
  return {
    planType: 'monthly',
    summary: `نقشه راهبردی ماهانه (۴ هفته): پوشش ۵۰٪ زیست دوازدهم، پیشروی شیمی یازدهم و فیزیک دوازدهم + زمان‌بندی مرورهای فاصله‌دار ۱ روز، ۳ روز، ۷ روز، ۱۵ روز و ۳۰ روزه.`,
    advice: `توصیه مشاور: در هفته اول و دوم تمرکز روی پیشروی مباحث است و در هفته سوم و چهارم پارت‌های مرور حافظه ابینگهاوس به اوج می‌رسند تا فراموشی به صفر برسد.`,
    totalHours: 172,
    totalTests: 1920,
    autoInjectedReviews: [
      { topic: 'رونویسی زیست دوازدهم', subject: 'زیست‌شناسی', reason: 'مرور ۱ هفته و ۱ ماه' },
      { topic: 'استوکیومتری شیمی یازدهم', subject: 'شیمی', reason: 'مرور ۳ روز و ۲ هفته' },
      { topic: 'حرکت‌شناسی فیزیک دوازدهم', subject: 'فیزیک', reason: 'مرور ۲۴ ساعت و ۱ هفته' },
      { topic: 'مثلثات و تابع ریاضی تجربی', subject: 'ریاضی تجربی', reason: 'مرور ۳۰ روزه طلایی' },
    ],
    monthlyPlan,
  };
}
