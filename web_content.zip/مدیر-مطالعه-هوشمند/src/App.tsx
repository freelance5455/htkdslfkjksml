import React, { useEffect, useState } from 'react';
import {
  ActiveTab,
  AnnualMonthStrategy,
  AnnualPlanRoadmap,
  AppState,
  AppTheme,
  CompensationTask,
  DailyDiagnosticReport,
  DailyNote,
  DayOfWeek,
  DaySchedule,
  ExamCountdownItem,
  MonthlyPlanRoadmap,
  StudyLog,
  StudyPart,
  StudyReminder,
  TajrobiSubject,
  TimeBlock,
  TopicMemoryItem,
  UserSettings,
  WeeklySlot,
} from './types';
import {
  DAYS_OF_WEEK,
  THEMES,
  THEME_CONFIGS,
  WEEKLY_TEMPLATES,
  calculateDaysUntilExam,
  createInitialTajrobiState,
  getDefaultAnnualPlan,
  getDefaultMonthlyPlan,
  getDefaultReminders,
  getDefaultTopicMemories,
  getDefaultWeeklySchedule,
  getTodayISO,
  getTodayJalali,
  getTodayPersianDayOfWeek,
  playChimeSound,
  toPersianDigits,
} from './utils/tajrobiData';
import { CountdownTimer } from './components/CountdownTimer';
import { DashboardView } from './components/DashboardView';
import { StudyPartsView } from './components/StudyPartsView';
import { WeeklyScheduleView } from './components/WeeklyScheduleView';
import { AnnualStrategyView } from './components/AnnualStrategyView';
import { RemindersView } from './components/RemindersView';
import { TopicMemoryView } from './components/TopicMemoryView';
import { DailyTimeBlocks } from './components/DailyTimeBlocks';
import { CompensationView } from './components/CompensationView';
import { StudyChartsView } from './components/StudyChartsView';
import { StatsAndAdvisorView } from './components/StatsAndAdvisorView';
import { MonthlyHistoryArchive } from './components/MonthlyHistoryArchive';
import { ExamsCountdownView } from './components/ExamsCountdownView';
import { DiagnosticsAndEndOfDayView } from './components/DiagnosticsAndEndOfDayView';
import { NotesAndBackupView } from './components/NotesAndBackupView';
import { SettingsView } from './components/SettingsView';
import { AIStudyPlannerModal } from './components/AIStudyPlannerModal';
import { PWAInstallGuideModal, PWAInstallHeaderButton } from './components/PWAInstallModal';
import {
  LayoutDashboard,
  CalendarDays,
  CheckSquare,
  Timer,
  Bell,
  Clock,
  AlertTriangle,
  BarChart2,
  TrendingUp,
  FolderArchive,
  Hourglass,
  Stethoscope,
  FileText,
  Settings,
  Download,
  Moon,
  Sun,
  Play,
  CheckCircle,
  Palette,
  RotateCcw,
  Sparkles,
  Brain,
  Target,
  Bot,
  Compass,
  Move,
  ArrowLeft,
  ArrowRight,
} from 'lucide-react';

const STORAGE_KEY = 'tajrobi_study_planner_state_v8';

export default function App() {
  const [state, setState] = useState<AppState>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (
          parsed &&
          Array.isArray(parsed.parts) &&
          Array.isArray(parsed.studyLogs)
        ) {
          if (!Array.isArray(parsed.blocks)) {
            parsed.blocks = createInitialTajrobiState().blocks;
          }
          if (!Array.isArray(parsed.compensations)) {
            parsed.compensations = createInitialTajrobiState().compensations;
          }
          if (!Array.isArray(parsed.exams)) {
            parsed.exams = createInitialTajrobiState().exams;
          }
          if (!Array.isArray(parsed.notes)) {
            parsed.notes = createInitialTajrobiState().notes;
          }
          if (!Array.isArray(parsed.diagnosticReports)) {
            parsed.diagnosticReports = createInitialTajrobiState().diagnosticReports;
          }
          if (!Array.isArray(parsed.reminders)) {
            parsed.reminders = getDefaultReminders();
          }
          if (!parsed.weeklySchedule) {
            parsed.weeklySchedule = getDefaultWeeklySchedule();
          }
          if (!Array.isArray(parsed.topicMemories)) {
            parsed.topicMemories = getDefaultTopicMemories();
          }
          if (!parsed.monthlyPlan) {
            parsed.monthlyPlan = getDefaultMonthlyPlan();
          }
          if (!parsed.annualPlan) {
            parsed.annualPlan = getDefaultAnnualPlan();
          }
          if (!parsed.settings) {
            parsed.settings = createInitialTajrobiState().settings;
          }
          if (!parsed.settings.theme) {
            parsed.settings.theme = 'emerald';
          }
          return parsed;
        }
      }
    } catch {
      // fallback
    }
    return createInitialTajrobiState();
  });

  // Current Theme
  const currentTheme = THEME_CONFIGS[state.settings?.theme || 'emerald'] || THEME_CONFIGS.emerald;
  const [showThemePicker, setShowThemePicker] = useState(false);

  // AI Planner Modal State
  const [isAIPlannerOpen, setIsAIPlannerOpen] = useState<boolean>(false);
  const [aiPlannerDefaultMode, setAIPlannerDefaultMode] = useState<'annual' | 'weekly' | 'monthly' | 'daily'>('annual');

  // Reset Confirm Modal State
  const [showResetConfirmModal, setShowResetConfirmModal] = useState<boolean>(false);

  // Tab Reorder Customizer Modal State
  const [showTabReorderModal, setShowTabReorderModal] = useState<boolean>(false);

  // PWA Install Guide Modal State
  const [isPWAInstallModalOpen, setIsPWAInstallModalOpen] = useState<boolean>(false);

  // Active Alert for reminders
  const [activeAlertReminder, setActiveAlertReminder] = useState<StudyReminder | null>(null);

  // Prefill timer when jumping from parts, blocks or weekly schedule
  const [timerInitialSubject, setTimerInitialSubject] = useState<TajrobiSubject>('زیست‌شناسی');
  const [timerInitialMinutes, setTimerInitialMinutes] = useState<number>(90);
  const [timerInitialTopic, setTimerInitialTopic] = useState<string>('');
  const [timerInitialBook, setTimerInitialBook] = useState<string>('');
  const [timerInitialTargetTests, setTimerInitialTargetTests] = useState<number>(30);

  // Toast notification
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'warning' | 'info' } | null>(null);

  const showToast = (message: string, type: 'success' | 'warning' | 'info' = 'success') => {
    setToast({ message, type });
    setTimeout(() => {
      setToast(null);
    }, 4000);
  };

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {
      // ignore
    }
  }, [state]);

  // Dark mode toggle
  useEffect(() => {
    if (state.settings?.darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [state.settings?.darkMode]);

  // Background Smart Reminder Trigger Check (every 25 seconds)
  useEffect(() => {
    const checkReminders = () => {
      if (!state.reminders || state.reminders.length === 0) return;
      const now = new Date();
      const hours = String(now.getHours()).padStart(2, '0');
      const minutes = String(now.getMinutes()).padStart(2, '0');
      const currentTime = `${hours}:${minutes}`;
      const todayISO = getTodayISO();
      const currentDayPersian = getTodayPersianDayOfWeek();

      state.reminders.forEach((rem) => {
        if (
          rem.enabled &&
          rem.time === currentTime &&
          rem.repeatDays.includes(currentDayPersian) &&
          rem.lastTriggeredDate !== `${todayISO}-${currentTime}`
        ) {
          if (rem.soundEnabled) {
            playChimeSound();
          }
          setActiveAlertReminder(rem);
          showToast(`🔔 یادآور مطالعه: ${rem.title}`, 'info');

          setState((prev) => ({
            ...prev,
            reminders: prev.reminders.map((r) =>
              r.id === rem.id ? { ...r, lastTriggeredDate: `${todayISO}-${currentTime}` } : r
            ),
          }));
        }
      });
    };

    checkReminders();
    const interval = setInterval(checkReminders, 25000);
    return () => clearInterval(interval);
  }, [state.reminders]);

  // Navigation tab state
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');

  // Open AI Modal Helper
  const handleOpenAIPlanner = (mode: 'annual' | 'weekly' | 'monthly' | 'daily' = 'annual') => {
    setAIPlannerDefaultMode(mode);
    setIsAIPlannerOpen(true);
  };

  // Handlers for Study Parts
  const handleAddPart = (part: Omit<StudyPart, 'id' | 'createdAt'>) => {
    const newPart: StudyPart = {
      ...part,
      id: 'part-' + Date.now(),
      createdAt: new Date().toISOString(),
    };
    setState((prev) => ({
      ...prev,
      parts: [newPart, ...prev.parts],
      xp: prev.xp + 15,
    }));
    showToast(`پارت «${newPart.courseName}» اضافه شد (+۱۵ XP)`, 'success');
  };

  const handleAddMultipleParts = (partsToAdd: Array<Omit<StudyPart, 'id' | 'createdAt'>>) => {
    const newParts: StudyPart[] = partsToAdd.map((p, idx) => ({
      ...p,
      id: 'part-multi-' + Date.now() + '-' + idx,
      createdAt: new Date().toISOString(),
    }));
    setState((prev) => ({
      ...prev,
      parts: [...newParts, ...prev.parts],
      xp: prev.xp + newParts.length * 20,
    }));
    setActiveTab('parts');
    showToast(`${toPersianDigits(newParts.length)} پارت هوشمند به برنامه اضافه شد! (+${toPersianDigits(newParts.length * 20)} XP)`, 'success');
  };

  const handleTogglePartComplete = (id: string) => {
    playChimeSound();
    setState((prev) => {
      const part = prev.parts.find((p) => p.id === id);
      const isNowCompleted = !part?.completed;
      const xpGain = isNowCompleted ? 30 : -30;

      return {
        ...prev,
        parts: prev.parts.map((p) => (p.id === id ? { ...p, completed: isNowCompleted } : p)),
        xp: Math.max(0, prev.xp + xpGain),
      };
    });
  };

  const handleDeletePart = (id: string) => {
    setState((prev) => ({
      ...prev,
      parts: prev.parts.filter((p) => p.id !== id),
    }));
    showToast('پارت با موفقیت حذف شد.', 'info');
  };

  const handleUpdatePart = (updatedPart: StudyPart) => {
    setState((prev) => ({
      ...prev,
      parts: prev.parts.map((p) => (p.id === updatedPart.id ? updatedPart : p)),
    }));
    showToast(`عنوان و مشخصات پارت «${updatedPart.topic}» ویرایش شد ✏️`, 'success');
  };

  const handleResetOnlyParts = () => {
    setState((prev) => ({
      ...prev,
      parts: [],
    }));
    showToast('لیست پارت‌های مطالعه صفر و پاکسازی شد. سایر گزارش‌ها و آزمون‌ها حفظ گردیدند 🧹', 'info');
  };

  const handleStartStudyPart = (part: StudyPart) => {
    setTimerInitialSubject(part.category);
    setTimerInitialMinutes(part.estimatedMinutes);
    setTimerInitialTopic(part.topic);
    setTimerInitialBook(part.bookSource);
    setTimerInitialTargetTests(part.testCount || 30);
    setActiveTab('timer');
    showToast(`تایمر برای «${part.topic}» با هدف ${toPersianDigits(part.testCount || 30)} تست تنظیم شد.`, 'info');
  };

  // Handlers for Countdown Timer session completion
  const handleSessionComplete = (log: Omit<StudyLog, 'id' | 'timestamp'>) => {
    const newLog: StudyLog = {
      ...log,
      id: 'log-' + Date.now(),
      timestamp: new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }),
    };

    const xpEarned = Math.round(log.durationMinutes * 1.5) + (log.correctTests || 0) * 4;

    setState((prev) => {
      // Mark matching part as completed if any
      const updatedParts = prev.parts.map((p) => {
        if (p.category === log.subject && p.topic.includes(log.topic.slice(0, 10)) && !p.completed) {
          return { ...p, completed: true, actualMinutes: log.durationMinutes };
        }
        return p;
      });

      return {
        ...prev,
        studyLogs: [newLog, ...prev.studyLogs],
        parts: updatedParts,
        xp: prev.xp + xpEarned,
      };
    });

    showToast(`جلسه با موفقیت ثبت شد! (+${toPersianDigits(xpEarned)} XP) 🎉`, 'success');
  };

  // Handler for Timer Deficit -> Send to Compensations
  const handleSendToCompensation = (task: Omit<CompensationTask, 'id' | 'resolved' | 'date'>) => {
    const newTask: CompensationTask = {
      ...task,
      id: 'comp-' + Date.now(),
      date: getTodayJalali(),
      resolved: false,
    };
    setState((prev) => ({
      ...prev,
      compensations: [newTask, ...prev.compensations],
    }));
    showToast(`کسری مطالعه به ایستگاه جبرانی منتقل شد (⚠️ ${toPersianDigits(task.remainingMinutes)} دقیقه)`, 'warning');
  };

  // Handlers for Compensations
  const handleStartCompensationInTimer = (
    subject: TajrobiSubject,
    topic: string,
    remainingMins: number,
    bookSource: string,
    compId: string
  ) => {
    setTimerInitialSubject(subject);
    setTimerInitialMinutes(remainingMins);
    setTimerInitialTopic(`جبرانی: ${topic}`);
    setTimerInitialBook(bookSource || 'ایستگاه جبرانی');
    setActiveTab('timer');
    showToast(`تایمر برای جبران «${topic}» تنظیم شد.`, 'info');
  };

  const handleToggleResolveCompensation = (id: string) => {
    playChimeSound();
    setState((prev) => ({
      ...prev,
      compensations: prev.compensations.map((c) =>
        c.id === id ? { ...c, resolved: !c.resolved } : c
      ),
      xp: prev.xp + 40,
    }));
    showToast('وضعیت ایستگاه جبرانی به‌روزرسانی شد (+۴۰ XP) ✨', 'success');
  };

  const handleDeleteCompensation = (id: string) => {
    setState((prev) => ({
      ...prev,
      compensations: prev.compensations.filter((c) => c.id !== id),
    }));
    showToast('وظیفه جبرانی حذف شد.', 'info');
  };

  const handleAddManualCompensation = (task: Omit<CompensationTask, 'id' | 'resolved' | 'date'>) => {
    const newTask: CompensationTask = {
      ...task,
      id: 'comp-' + Date.now(),
      date: getTodayJalali(),
      resolved: false,
    };
    setState((prev) => ({
      ...prev,
      compensations: [newTask, ...prev.compensations],
    }));
    showToast('وظیفه جبرانی جدید اضافه شد.', 'success');
  };

  // Handlers for 1.5h Time Blocks
  const handleUpdateBlock = (updatedBlock: TimeBlock) => {
    setState((prev) => ({
      ...prev,
      blocks: prev.blocks.map((b) => (b.id === updatedBlock.id ? updatedBlock : b)),
    }));
    showToast(`بلاک ساعت ${updatedBlock.timeRange} ذخیره شد.`, 'success');
  };

  const handleSendBlockToTimer = (subject: TajrobiSubject, topic: string) => {
    setTimerInitialSubject(subject);
    setTimerInitialMinutes(90);
    setTimerInitialTopic(topic);
    setActiveTab('timer');
    showToast(`تایمر برای «${topic}» تنظیم شد.`, 'info');
  };

  // Handlers for Weekly Schedule
  const handleUpdateSchedule = (newSchedule: Record<DayOfWeek, DaySchedule>) => {
    setState((prev) => ({
      ...prev,
      weeklySchedule: newSchedule,
    }));
    showToast('برنامه هفتگی با موفقیت به‌روزرسانی شد.', 'success');
  };

  const handleStartWeeklySlotInTimer = (subject: TajrobiSubject, topic: string, durationMinutes: number) => {
    setTimerInitialSubject(subject);
    setTimerInitialMinutes(durationMinutes);
    setTimerInitialTopic(topic);
    setActiveTab('timer');
    showToast(`تایمر برای «${topic}» تنظیم شد.`, 'info');
  };

  const calcMinutes = (start: string, end: string): number => {
    try {
      const [sh, sm] = start.split(':').map(Number);
      const [eh, em] = end.split(':').map(Number);
      let diff = eh * 60 + em - (sh * 60 + sm);
      if (diff < 0) diff += 24 * 60;
      return Math.max(15, diff);
    } catch {
      return 90;
    }
  };

  // 1-Click transfer from Weekly Schedule into Study Parts
  const handleSyncWeeklyDayToParts = (slots: WeeklySlot[]) => {
    const todayPersian = getTodayPersianDayOfWeek();
    const newParts: StudyPart[] = slots.map((s, idx) => ({
      id: 'part-sync-' + Date.now() + '-' + idx,
      category: s.subject || 'زیست‌شناسی',
      gradeLevel: s.gradeLevel || 'دوازدهم',
      courseName: s.title,
      topic: s.topic || s.title,
      bookSource: 'برنامه روتین هفتگی',
      estimatedMinutes: calcMinutes(s.startTime, s.endTime),
      actualMinutes: 0,
      scheduledTime: s.startTime,
      completed: false,
      testCount: s.targetTests || 30,
      priority: s.isImportant ? 'high' : 'medium',
      dayOfWeek: todayPersian,
      createdAt: new Date().toISOString(),
    }));

    setState((prev) => ({
      ...prev,
      parts: [...newParts, ...prev.parts],
      xp: prev.xp + newParts.length * 20,
    }));
    setActiveTab('parts');
  };

  // Handlers for Reminders
  const handleUpdateReminders = (newReminders: StudyReminder[]) => {
    setState((prev) => ({
      ...prev,
      reminders: newReminders,
    }));
  };

  // Handlers for Topic Memories & Spaced Repetition
  const handleUpdateTopicMemories = (newMemories: TopicMemoryItem[]) => {
    setState((prev) => ({
      ...prev,
      topicMemories: newMemories,
    }));
  };

  const handleApplyMonthlyPlan = (newPlan: MonthlyPlanRoadmap) => {
    const todayPersian = getTodayPersianDayOfWeek();
    const reviewPart: StudyPart = {
      id: 'part-rev-' + Date.now(),
      category: 'شیمی',
      gradeLevel: 'یازدهم',
      courseName: `🧠 تایم مرور ماه ${newPlan.monthName}`,
      topic: `مرور پوششی و بازیابی فعال مباحث ${newPlan.monthName} (ابینگهاوس)`,
      bookSource: 'جعبه لایتنر ابینگهاوس',
      estimatedMinutes: 60,
      actualMinutes: 0,
      scheduledTime: '21:15',
      completed: false,
      testCount: 20,
      priority: 'high',
      dayOfWeek: todayPersian,
      createdAt: getTodayISO(),
    };
    setState((prev) => ({
      ...prev,
      monthlyPlan: newPlan,
      parts: [reviewPart, ...prev.parts],
    }));
    showToast(`نقشه راهبردی ${newPlan.monthName} ثبت شد و پارت مرور ابینگهاوس به برنامه اضافه گردید 🗺️`, 'success');
  };

  // Handlers for Annual Strategy (Target Esfand)
  const handleUpdateAnnualPlan = (newPlan: AnnualPlanRoadmap) => {
    const newParts: StudyPart[] = [];

    // Populate study parts for ALL days of the week from annual plan roadmap
    DAYS_OF_WEEK.forEach((day, dayIndex) => {
      newParts.push({
        id: `part-ann-${Date.now()}-${dayIndex}-1`,
        category: 'زیست‌شناسی',
        gradeLevel: 'دوازدهم',
        courseName: 'زیست‌شناسی دوازدهم (کنکور + مفهومی)',
        topic: 'پروتئین‌سازی و ژنتیک (استراتژی سالانه تا اسفند)',
        bookSource: 'خیلی سبز جامع زیست‌شناسی',
        estimatedMinutes: 120,
        actualMinutes: 0,
        scheduledTime: '15:15',
        completed: false,
        testCount: 35,
        priority: 'high',
        dayOfWeek: day,
        createdAt: getTodayISO(),
      });

      newParts.push({
        id: `part-ann-${Date.now()}-${dayIndex}-2`,
        category: 'شیمی',
        gradeLevel: 'یازدهم',
        courseName: 'شیمی یازدهم (مسائل و مفاهیم)',
        topic: 'استوکیومتری و واکنش‌های شیمیایی (استراتژی سالانه)',
        bookSource: 'مبتکران / خیلی سبز شیمی',
        estimatedMinutes: 105,
        actualMinutes: 0,
        scheduledTime: '17:30',
        completed: false,
        testCount: 30,
        priority: 'high',
        dayOfWeek: day,
        createdAt: getTodayISO(),
      });

      newParts.push({
        id: `part-ann-${Date.now()}-${dayIndex}-3`,
        category: 'فیزیک',
        gradeLevel: 'دوازدهم',
        courseName: 'فیزیک دوازدهم (حرکت‌شناسی)',
        topic: 'معادلات حرکت و شتاب ثابت (استراتژی سالانه)',
        bookSource: 'خیلی سبز فیزیک',
        estimatedMinutes: 90,
        actualMinutes: 0,
        scheduledTime: '19:30',
        completed: false,
        testCount: 25,
        priority: 'medium',
        dayOfWeek: day,
        createdAt: getTodayISO(),
      });

      newParts.push({
        id: `part-ann-${Date.now()}-${dayIndex}-4`,
        category: 'زیست‌شناسی',
        gradeLevel: 'دوازدهم',
        courseName: '🧠 تایم مرور اختصاصی ابینگهاوس (سالانه)',
        topic: `مرور ۲۴ ساعته و ۳ روزه ابینگهاوس (${day})`,
        bookSource: 'جعبه لایتنر + جزوه',
        estimatedMinutes: 60,
        actualMinutes: 0,
        scheduledTime: '21:15',
        completed: false,
        testCount: 20,
        priority: 'high',
        dayOfWeek: day,
        createdAt: getTodayISO(),
      });
    });

    setState((prev) => ({
      ...prev,
      annualPlan: newPlan,
      weeklySchedule: WEEKLY_TEMPLATES[0].schedule,
      parts: [...newParts, ...prev.parts],
      xp: prev.xp + 250,
    }));

    showToast('استراتژی سالانه تا ۲۹ اسفند ذخیره شد! پارت‌های درسی و برنامه هفتگی روتین در تمام روزهای هفته بارگذاری شدند 🗺️✨ (+۲۵۰ XP)', 'success');
  };

  const handleUpdateSyllabusChapter = (chapterId: string, completed: boolean) => {
    setState((prev) => {
      if (!prev.annualPlan) return prev;
      const updatedChapters = (prev.annualPlan.syllabusChapters || []).map((ch) =>
        ch.id === chapterId ? { ...ch, isCompleted: completed, testCountDone: completed ? Math.max(ch.testCountDone, 150) : ch.testCountDone } : ch
      );
      return {
        ...prev,
        annualPlan: {
          ...prev.annualPlan,
          syllabusChapters: updatedChapters,
        },
        xp: completed ? prev.xp + 50 : prev.xp,
      };
    });
  };

  const handleApplyAnnualMonthToStudyParts = (month: AnnualMonthStrategy) => {
    const newParts: StudyPart[] = [];

    DAYS_OF_WEEK.forEach((day, dayIdx) => {
      // Add 12th subjects for each day
      Object.entries(month.grade12Coverage || {}).forEach(([subj, topic], idx) => {
        newParts.push({
          id: `part-month-${Date.now()}-${dayIdx}-${idx}`,
          category: subj as TajrobiSubject,
          gradeLevel: 'دوازدهم',
          courseName: `${subj} (دوازدهم)`,
          topic: topic,
          bookSource: `برنامه راهبردی ماه ${month.monthName}`,
          estimatedMinutes: 105,
          actualMinutes: 0,
          scheduledTime: idx === 0 ? '15:15' : '19:30',
          completed: false,
          testCount: 35,
          priority: 'high',
          dayOfWeek: day,
          createdAt: getTodayISO(),
        });
      });

      // Add base 11th/10th subjects
      const g11Entries = Object.entries(month.grade11Coverage || {});
      if (g11Entries.length > 0) {
        const [subj, topic] = g11Entries[0];
        newParts.push({
          id: `part-month-base-${Date.now()}-${dayIdx}`,
          category: subj as TajrobiSubject,
          gradeLevel: 'یازدهم',
          courseName: `${subj} (پایه یازدهم)`,
          topic: topic,
          bookSource: `برنامه راهبردی ماه ${month.monthName}`,
          estimatedMinutes: 90,
          actualMinutes: 0,
          scheduledTime: '17:30',
          completed: false,
          testCount: 30,
          priority: 'high',
          dayOfWeek: day,
          createdAt: getTodayISO(),
        });
      }

      // Add Ebbinghaus review station
      newParts.push({
        id: `part-month-rev-${Date.now()}-${dayIdx}`,
        category: 'زیست‌شناسی',
        gradeLevel: 'دوازدهم',
        courseName: `🧠 تایم مرور اختصاصی ${month.monthName} (ابینگهاوس)`,
        topic: `ایستگاه مرور ابینگهاوس ماه ${month.monthName} (${day})`,
        bookSource: 'جعبه لایتنر ابینگهاوس',
        estimatedMinutes: 60,
        actualMinutes: 0,
        scheduledTime: '21:15',
        completed: false,
        testCount: 20,
        priority: 'high',
        dayOfWeek: day,
        createdAt: getTodayISO(),
      });
    });

    setState((prev) => ({
      ...prev,
      weeklySchedule: WEEKLY_TEMPLATES[0].schedule,
      parts: [...newParts, ...prev.parts],
    }));

    setActiveTab('parts');
    showToast(`برنامه اهداف ماه ${month.monthName} در پارت‌های مطالعه و برنامه هفتگی روتین بارگذاری شد! 🚀`, 'success');
  };

  const handleStartTopicReviewInTimer = (subject: TajrobiSubject, topic: string) => {
    setTimerInitialSubject(subject);
    setTimerInitialMinutes(60);
    setTimerInitialTopic(topic);
    setTimerInitialBook('مرور حافظه ابینگهاوس');
    setActiveTab('timer');
    showToast(`تایمر برای «${topic}» تنظیم شد 🧠`, 'info');
  };

  // Handlers for Manual Logs
  const handleAddManualLog = (log: Omit<StudyLog, 'id'>) => {
    const newLog: StudyLog = {
      ...log,
      id: 'log-' + Date.now(),
    };
    setState((prev) => ({
      ...prev,
      studyLogs: [newLog, ...prev.studyLogs],
      xp: prev.xp + log.durationMinutes * 2 + log.correctTests * 5,
    }));
    showToast('گزارش مطالعه دستی ثبت شد.', 'success');
  };

  const handleDeleteLog = (id: string) => {
    setState((prev) => ({
      ...prev,
      studyLogs: prev.studyLogs.filter((l) => l.id !== id),
    }));
    showToast('سابقه مطالعه حذف شد.', 'info');
  };

  // Handlers for Exams
  const handleAddExam = (exam: ExamCountdownItem) => {
    setState((prev) => ({
      ...prev,
      exams: [...prev.exams, exam],
    }));
    showToast(`آزمون «${exam.title}» اضافه شد.`, 'success');
  };

  const handleDeleteExam = (id: string) => {
    setState((prev) => ({
      ...prev,
      exams: prev.exams.filter((e) => e.id !== id),
    }));
    showToast('آزمون حذف شد.', 'info');
  };

  // Handlers for Diagnostics
  const handleSaveNightlyReport = (report: DailyDiagnosticReport) => {
    setState((prev) => ({
      ...prev,
      diagnosticReports: [report, ...prev.diagnosticReports.filter((r) => r.date !== report.date)],
      xp: prev.xp + 100,
    }));
    showToast('کارنامه و گزارش آسیب‌شناسی شبانه ثبت شد (+۱۰۰ XP) ✨', 'success');
  };

  // Handlers for Daily Notes
  const handleAddNote = (note: Omit<DailyNote, 'id'>) => {
    const newNote: DailyNote = {
      ...note,
      id: 'note-' + Date.now(),
      date: note.date || getTodayJalali(),
    };
    setState((prev) => ({
      ...prev,
      notes: [newNote, ...prev.notes],
    }));
    showToast('یادداشت جدید ذخیره شد.', 'success');
  };

  const handleToggleNoteDone = (id: string) => {
    setState((prev) => ({
      ...prev,
      notes: prev.notes.map((n) => (n.id === id ? { ...n, done: !n.done } : n)),
    }));
  };

  const handleToggleNoteImportant = (id: string) => {
    setState((prev) => ({
      ...prev,
      notes: prev.notes.map((n) => (n.id === id ? { ...n, important: !n.important } : n)),
    }));
  };

  const handleDeleteNote = (id: string) => {
    setState((prev) => ({
      ...prev,
      notes: prev.notes.filter((n) => n.id !== id),
    }));
    showToast('یادداشت حذف شد.', 'info');
  };

  // Handlers for Settings & Theme change
  const handleUpdateSettings = (newSettings: Partial<UserSettings>) => {
    setState((prev) => ({
      ...prev,
      settings: { ...prev.settings, ...newSettings },
    }));
    showToast('تنظیمات ذخیره شد.', 'success');
  };

  const handleResetAllData = () => {
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {}
    const fresh = createInitialTajrobiState();
    setState(fresh);
    setActiveTab('dashboard');
    showToast('تمام اطلاعات و داده‌ها با موفقیت صفر و بازنشانی شدند 🔄', 'success');
  };

  // Quick stats
  const mainExam = state.exams.find((e) => e.type === 'konkur') || state.exams[0];
  const daysToKonkur = mainExam ? calculateDaysUntilExam(mainExam.targetDate) : 200;
  const activeCompensationsCount = state.compensations.filter((c) => !c.resolved).length;
  const activeRemindersCount = state.reminders ? state.reminders.filter((r) => r.enabled).length : 0;
  const activeMemoriesCount = state.topicMemories ? state.topicMemories.length : 0;

  // Complete Raw List of Navigation Tabs
  const rawNavTabs = [
    {
      id: 'dashboard' as const,
      label: 'داشبورد',
      icon: <LayoutDashboard className="w-4 h-4" />,
    },
    {
      id: 'annual' as const,
      label: '🗺️ استراتژی سالانه (تا اسفند)',
      icon: <Target className="w-4 h-4 text-amber-500" />,
    },
    {
      id: 'schedule' as const,
      label: '📅 برنامه هفتگی و روتین',
      icon: <CalendarDays className="w-4 h-4 text-emerald-500" />,
    },
    {
      id: 'parts' as const,
      label: '🎯 پارت‌های مطالعه',
      icon: <CheckSquare className="w-4 h-4 text-teal-500" />,
    },
    {
      id: 'timer' as const,
      label: '⏱ تایمر معکوس',
      icon: <Timer className="w-4 h-4 text-sky-500" />,
    },
    {
      id: 'memory' as const,
      label: `🧠 حافظه مبحثی و مرورها ${activeMemoriesCount > 0 ? `(${toPersianDigits(activeMemoriesCount)})` : ''}`,
      icon: <Brain className="w-4 h-4 text-purple-500" />,
    },
    {
      id: 'reminders' as const,
      label: `🔔 یادآورها ${activeRemindersCount > 0 ? `(${toPersianDigits(activeRemindersCount)})` : ''}`,
      icon: <Bell className="w-4 h-4 text-rose-500" />,
    },
    {
      id: 'blocks' as const,
      label: '⏳ بلاک‌های روزانه',
      icon: <Clock className="w-4 h-4 text-indigo-500" />,
    },
    {
      id: 'compensations' as const,
      label: `⚠️ جبرانی ${activeCompensationsCount > 0 ? `(${toPersianDigits(activeCompensationsCount)})` : ''}`,
      icon: <AlertTriangle className="w-4 h-4 text-amber-500" />,
    },
    {
      id: 'charts' as const,
      label: '📈 نمودارهای تحلیلی',
      icon: <BarChart2 className="w-4 h-4 text-blue-500" />,
    },
    {
      id: 'stats' as const,
      label: '🎯 مشاور و آمار',
      icon: <TrendingUp className="w-4 h-4 text-cyan-500" />,
    },
    {
      id: 'history' as const,
      label: '📁 بایگانی ماهانه',
      icon: <FolderArchive className="w-4 h-4 text-emerald-500" />,
    },
    {
      id: 'exams' as const,
      label: '⏳ روزشمار کنکور',
      icon: <Hourglass className="w-4 h-4 text-red-500" />,
    },
    {
      id: 'diagnostics' as const,
      label: '🩺 آسیب‌شناسی شبانه',
      icon: <Stethoscope className="w-4 h-4 text-teal-500" />,
    },
    {
      id: 'notes' as const,
      label: '📝 نکات و پشتیبان',
      icon: <FileText className="w-4 h-4 text-yellow-500" />,
    },
    {
      id: 'settings' as const,
      label: '⚙️ تنظیمات و تم‌ها',
      icon: <Settings className="w-4 h-4 text-slate-500" />,
    },
  ];

  const defaultTabIds: ActiveTab[] = rawNavTabs.map((t) => t.id);
  const currentTabOrder: ActiveTab[] =
    state.settings?.tabOrder && state.settings.tabOrder.length > 0
      ? state.settings.tabOrder
      : defaultTabIds;

  // Build sorted navTabs list according to custom user order
  const navTabs = currentTabOrder
    .map((id) => rawNavTabs.find((t) => t.id === id))
    .filter((t): t is (typeof rawNavTabs)[0] => Boolean(t));

  // Handler for reordering tab order
  const handleMoveTabOrder = (tabId: ActiveTab, direction: 'prev' | 'next') => {
    const order = [...currentTabOrder];
    const idx = order.indexOf(tabId);
    if (idx === -1) return;
    const targetIdx = direction === 'prev' ? idx - 1 : idx + 1;
    if (targetIdx < 0 || targetIdx >= order.length) return;

    const temp = order[idx];
    order[idx] = order[targetIdx];
    order[targetIdx] = temp;

    handleUpdateSettings({ tabOrder: order });
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-vazir antialiased transition-colors duration-200" dir="rtl">
      {/* Toast Floating Notification */}
      {toast && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 animate-bounce-short">
          <div
            className={`px-5 py-3 rounded-2xl shadow-xl border text-xs sm:text-sm font-black flex items-center gap-2 backdrop-blur-md ${
              toast.type === 'success'
                ? 'bg-emerald-600/95 text-white border-emerald-400/40 shadow-emerald-500/20'
                : toast.type === 'warning'
                ? 'bg-amber-600/95 text-white border-amber-400/40 shadow-amber-500/20'
                : 'bg-slate-900/95 text-white border-slate-700 shadow-slate-900/40'
            }`}
          >
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>{toast.message}</span>
          </div>
        </div>
      )}

      {/* Global AI Study Planner Modal */}
      <AIStudyPlannerModal
        isOpen={isAIPlannerOpen}
        onClose={() => setIsAIPlannerOpen(false)}
        theme={currentTheme}
        defaultPlanType={aiPlannerDefaultMode}
        topicMemories={state.topicMemories || getDefaultTopicMemories()}
        onSaveTopicMemory={handleUpdateTopicMemories}
        onApplyPlanToParts={handleAddMultipleParts}
        onApplyWeeklySchedule={handleUpdateSchedule}
        onApplyMonthlyPlan={handleApplyMonthlyPlan}
        onApplyAnnualPlan={handleUpdateAnnualPlan}
        showToast={showToast}
      />

      {/* Smart Trigger Alert Popup */}
      {activeAlertReminder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
          <div className="relative w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl border border-purple-300 dark:border-purple-800 p-6 shadow-2xl space-y-4 text-center">
            <div className="w-16 h-16 rounded-full bg-purple-100 dark:bg-purple-900/60 text-purple-600 dark:text-purple-300 flex items-center justify-center mx-auto animate-pulse">
              <Bell className="w-8 h-8" />
            </div>
            <div className="space-y-1">
              <span className="text-xs font-bold text-purple-600 dark:text-purple-400 bg-purple-50 dark:bg-purple-950/60 px-3 py-1 rounded-full">
                🔔 زنگ هشدار هوشمند مطالعه ({activeAlertReminder.time})
              </span>
              <h3 className="text-lg font-black text-slate-900 dark:text-white pt-2">
                {activeAlertReminder.title}
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-400">
                {activeAlertReminder.description || 'زمان اجرای برنامه و پارت مطالعاتی فرا رسیده است.'}
              </p>
            </div>
            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  setActiveAlertReminder(null);
                  setActiveTab('timer');
                }}
                className={`flex-1 py-3 rounded-2xl ${currentTheme.primaryBtn} text-white font-black text-xs sm:text-sm cursor-pointer shadow-md`}
              >
                ▶️ ورود به تایمر مطالعه
              </button>
              <button
                type="button"
                onClick={() => setActiveAlertReminder(null)}
                className="px-4 py-3 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold text-xs cursor-pointer"
              >
                متوجه شدم
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Top Application Header */}
      <header className="sticky top-0 z-30 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 shadow-2xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-3">
          {/* Logo & Brand */}
          <div className="flex items-center gap-3">
            <div
              className="w-9 h-9 rounded-2xl flex items-center justify-center text-white font-black text-lg shadow-xs transition"
              style={{ backgroundColor: currentTheme.accentColor }}
            >
              🧬
            </div>
            <div>
              <h1 className="text-base sm:text-lg font-black text-slate-900 dark:text-white leading-tight">
                همیار مطالعه و کنکور تجربی
              </h1>
              <span className="text-[10px] font-bold block" style={{ color: currentTheme.accentColor }}>
                استراتژی سالانه تا اسفند، برنامه هفتگی و حافظه ابینگهاوس
              </span>
            </div>
          </div>

          {/* Konkur & Today Date */}
          <div className="hidden md:flex items-center gap-3 text-xs font-bold text-slate-600 dark:text-slate-300 tabular-nums">
            <span>📅 {getTodayJalali()}</span>
            <span aria-hidden="true">·</span>
            <span className="font-bold flex items-center gap-1" style={{ color: currentTheme.accentColor }}>
              <span>⏳ {toPersianDigits(daysToKonkur)} روز تا کنکور سراسری</span>
            </span>
          </div>

          {/* Quick Header Actions */}
          <div className="flex items-center gap-2">
            {/* AI Planner Button */}
            <button
              type="button"
              onClick={() => handleOpenAIPlanner('annual')}
              className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-black text-xs flex items-center gap-1.5 shadow-md active:scale-95 transition cursor-pointer"
            >
              <Bot className="w-4 h-4 text-slate-950" />
              <span>هوش مصنوعی</span>
            </button>

            {/* Quick Theme Switcher */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowThemePicker(!showThemePicker)}
                className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition cursor-pointer flex items-center gap-1.5 text-xs font-bold"
                title="تغییر تم رنگی"
              >
                <span
                  className="w-3.5 h-3.5 rounded-full inline-block shadow-xs"
                  style={{ backgroundColor: currentTheme.accentColor }}
                />
                <span className="hidden lg:inline">{currentTheme.badge}</span>
              </button>

              {showThemePicker && (
                <div className="absolute left-0 top-12 z-50 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-3 shadow-xl w-56 animate-fade-in space-y-1.5">
                  <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2 mb-1">
                    <span className="text-xs font-bold text-slate-800 dark:text-white flex items-center gap-1.5">
                      <Palette className="w-3.5 h-3.5 text-purple-500" />
                      انتخاب تم رنگی
                    </span>
                    <button onClick={() => setShowThemePicker(false)} className="text-slate-400 text-xs cursor-pointer">✕</button>
                  </div>
                  {THEMES.map((th) => (
                    <button
                      key={th.id}
                      type="button"
                      onClick={() => {
                        handleUpdateSettings({ theme: th.id });
                        setShowThemePicker(false);
                        showToast(`تم «${th.name}» فعال شد ✨`, 'success');
                      }}
                      className={`w-full p-2 rounded-xl text-xs font-bold flex items-center justify-between transition cursor-pointer ${
                        (state.settings?.theme || 'emerald') === th.id
                          ? 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white font-black'
                          : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800/60'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span className="w-3 h-3 rounded-full" style={{ backgroundColor: th.accentColor }} />
                        <span>{th.name}</span>
                      </div>
                      {(state.settings?.theme || 'emerald') === th.id && (
                        <CheckCircle className="w-3.5 h-3.5 text-emerald-500" />
                      )}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Dark Mode Button */}
            <button
              type="button"
              onClick={() => handleUpdateSettings({ darkMode: !state.settings?.darkMode })}
              className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition cursor-pointer"
              title="تغییر تم تاریک/روشن"
            >
              {state.settings?.darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
            </button>

            {/* PWA Install Button */}
            <PWAInstallHeaderButton onOpenGuide={() => setIsPWAInstallModalOpen(true)} />
          </div>
        </div>
      </header>

      {/* Navigation Tabs Bar */}
      <div className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 shadow-2xs sticky top-16 z-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <nav className="flex items-center gap-2 overflow-x-auto py-2.5 no-scrollbar">
            {navTabs.map((tab) => {
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveTab(tab.id)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-extrabold flex items-center gap-1.5 transition whitespace-nowrap cursor-pointer ${
                    isActive
                      ? currentTheme.activeNavTab
                      : 'bg-slate-100 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                  }`}
                >
                  {tab.icon}
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </nav>
        </div>
      </div>

      {/* Main Content Viewport */}
      <main className="max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 flex-1 pb-24">
        {activeTab === 'dashboard' && (
          <DashboardView
            state={state}
            onNavigateTab={setActiveTab}
            onStartStudyPart={handleStartStudyPart}
          />
        )}

        {activeTab === 'annual' && (
          <AnnualStrategyView
            annualPlan={state.annualPlan || getDefaultAnnualPlan()}
            theme={currentTheme}
            studyLogs={state.studyLogs}
            onOpenAIPlannerModal={handleOpenAIPlanner}
            onUpdateSyllabusChapter={handleUpdateSyllabusChapter}
            onApplyMonthToStudyParts={handleApplyAnnualMonthToStudyParts}
            showToast={showToast}
          />
        )}

        {activeTab === 'schedule' && (
          <WeeklyScheduleView
            schedule={state.weeklySchedule || getDefaultWeeklySchedule()}
            theme={currentTheme}
            topicMemories={state.topicMemories || getDefaultTopicMemories()}
            onSaveTopicMemory={handleUpdateTopicMemories}
            onUpdateSchedule={handleUpdateSchedule}
            onStartInTimer={handleStartWeeklySlotInTimer}
            onSyncDayToParts={handleSyncWeeklyDayToParts}
            showToast={showToast}
          />
        )}

        {activeTab === 'parts' && (
          <StudyPartsView
            parts={state.parts}
            theme={currentTheme}
            topicMemories={state.topicMemories || getDefaultTopicMemories()}
            onSaveTopicMemory={handleUpdateTopicMemories}
            onAddPart={handleAddPart}
            onAddMultipleParts={handleAddMultipleParts}
            onUpdatePart={handleUpdatePart}
            onResetOnlyParts={handleResetOnlyParts}
            onToggleComplete={handleTogglePartComplete}
            onDeletePart={handleDeletePart}
            onStartInTimer={handleStartStudyPart}
            showToast={showToast}
          />
        )}

        {activeTab === 'timer' && (
          <CountdownTimer
            initialSubject={timerInitialSubject}
            initialMinutes={timerInitialMinutes}
            initialTopic={timerInitialTopic}
            initialBook={timerInitialBook}
            initialTargetTests={timerInitialTargetTests}
            onSessionComplete={handleSessionComplete}
            onSendToCompensation={handleSendToCompensation}
          />
        )}

        {activeTab === 'memory' && (
          <TopicMemoryView
            topicMemories={state.topicMemories || getDefaultTopicMemories()}
            theme={currentTheme}
            onUpdateMemories={handleUpdateTopicMemories}
            onStartReviewInTimer={handleStartTopicReviewInTimer}
            showToast={showToast}
          />
        )}

        {activeTab === 'reminders' && (
          <RemindersView
            reminders={state.reminders || getDefaultReminders()}
            theme={currentTheme}
            onUpdateReminders={handleUpdateReminders}
            onShowToast={showToast}
          />
        )}

        {activeTab === 'blocks' && (
          <DailyTimeBlocks
            blocks={state.blocks}
            onUpdateBlock={handleUpdateBlock}
            onSendToTimer={handleSendBlockToTimer}
          />
        )}

        {activeTab === 'compensations' && (
          <CompensationView
            compensations={state.compensations}
            onStartCompensationInTimer={handleStartCompensationInTimer}
            onToggleResolve={handleToggleResolveCompensation}
            onDeleteCompensation={handleDeleteCompensation}
            onAddManualCompensation={handleAddManualCompensation}
          />
        )}

        {activeTab === 'charts' && (
          <StudyChartsView
            logs={state.studyLogs}
            blocks={state.blocks}
          />
        )}

        {activeTab === 'stats' && (
          <StatsAndAdvisorView
            state={state}
          />
        )}

        {activeTab === 'history' && (
          <MonthlyHistoryArchive
            logs={state.studyLogs}
            onAddManualLog={handleAddManualLog}
            onDeleteLog={handleDeleteLog}
          />
        )}

        {activeTab === 'exams' && (
          <ExamsCountdownView
            exams={state.exams}
            onAddExam={handleAddExam}
            onDeleteExam={handleDeleteExam}
          />
        )}

        {activeTab === 'diagnostics' && (
          <DiagnosticsAndEndOfDayView
            parts={state.parts}
            logs={state.studyLogs}
            todayReports={state.diagnosticReports}
            dailyTestGoal={state.settings?.dailyTestGoal || 100}
            onSaveNightlyReport={handleSaveNightlyReport}
            onSwitchTab={setActiveTab}
          />
        )}

        {activeTab === 'notes' && (
          <NotesAndBackupView
            state={state}
            onAddNote={handleAddNote}
            onToggleNoteDone={handleToggleNoteDone}
            onToggleNoteImportant={handleToggleNoteImportant}
            onDeleteNote={handleDeleteNote}
            onRestoreState={(newState) => {
              setState(newState);
              showToast('اطلاعات با موفقیت بازیابی شد.', 'success');
            }}
            onOpenPWAInstallGuide={() => setIsPWAInstallModalOpen(true)}
            onShowToast={showToast}
          />
        )}

        {activeTab === 'settings' && (
          <SettingsView
            settings={state.settings}
            onUpdateSettings={handleUpdateSettings}
            onResetAllData={() => setShowResetConfirmModal(true)}
            onResetOnlyParts={handleResetOnlyParts}
            onOpenTabCustomizer={() => setShowTabReorderModal(true)}
            onOpenPWAInstallGuide={() => setIsPWAInstallModalOpen(true)}
            onShowToast={showToast}
          />
        )}
      </main>

      {/* Floating Bottom Quick Action: "▶️ شروع مطالعه در تایمر" */}
      {activeTab !== 'timer' && (
        <div className="fixed bottom-5 left-1/2 -translate-x-1/2 z-40 max-w-sm w-full px-4 animate-fade-in">
          <button
            type="button"
            onClick={() => setActiveTab('timer')}
            className={`w-full py-3.5 px-6 rounded-2xl ${currentTheme.primaryBtn} active:scale-98 text-white font-black text-sm shadow-xl flex items-center justify-center gap-2.5 transition cursor-pointer border border-white/20 ring-4 ${currentTheme.ringColor}/20`}
          >
            <Play className="w-5 h-5 fill-white" />
            <span>▶️ شروع مطالعه (تایمر معکوس)</span>
          </button>
        </div>
      )}

      {/* Tab Reorder Customizer Modal */}
      {showTabReorderModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 max-w-lg w-full shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2 text-slate-900 dark:text-white font-extrabold text-base">
                <Move className="w-5 h-5 text-purple-600" />
                <span>مدیریت و جابجایی ترتیب تب‌های بالای صفحه</span>
              </div>
              <button
                onClick={() => setShowTabReorderModal(false)}
                className="text-slate-400 hover:text-slate-600 text-xs font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              می‌توانید ترتیب نمایش تب‌های بالای صفحه را به دلخواه تغییر دهید. با کلیک روی فلش‌های ➡️ و ⬅️ موقعیت هر تب جابجا می‌شود:
            </p>

            <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
              {navTabs.map((tab, index) => (
                <div
                  key={tab.id}
                  className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 text-xs font-bold"
                >
                  <div className="flex items-center gap-2">
                    <span className="text-slate-400 text-[10px] tabular-nums w-4">
                      {toPersianDigits(index + 1)}.
                    </span>
                    {tab.icon}
                    <span className="text-slate-800 dark:text-slate-200">{tab.label}</span>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      disabled={index === 0}
                      onClick={() => handleMoveTabOrder(tab.id, 'prev')}
                      className={`p-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 hover:bg-slate-100 transition cursor-pointer ${
                        index === 0 ? 'opacity-40 cursor-not-allowed' : ''
                      }`}
                      title="انتقال به راست/جلوتر"
                    >
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      disabled={index === navTabs.length - 1}
                      onClick={() => handleMoveTabOrder(tab.id, 'next')}
                      className={`p-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 hover:bg-slate-100 transition cursor-pointer ${
                        index === navTabs.length - 1 ? 'opacity-40 cursor-not-allowed' : ''
                      }`}
                      title="انتقال به چپ/عقب‌تر"
                    >
                      <ArrowLeft className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800">
              <button
                type="button"
                onClick={() => {
                  handleUpdateSettings({ tabOrder: undefined });
                  showToast('ترتیب تب‌ها به حالت پیش‌فرض بازگشت.', 'info');
                }}
                className="px-3 py-2 rounded-xl text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-xs font-bold transition cursor-pointer flex items-center gap-1"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>پیش‌فرض</span>
              </button>

              <button
                type="button"
                onClick={() => setShowTabReorderModal(false)}
                className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold transition cursor-pointer"
              >
                تأیید و بستن
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reset Confirmation Modal */}
      {showResetConfirmModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 max-w-md w-full shadow-2xl space-y-4 text-right">
            <div className="flex items-center gap-2.5 text-rose-600 dark:text-rose-400 font-extrabold text-base">
              <AlertTriangle className="w-6 h-6 shrink-0 text-rose-500" />
              <span>تأیید بازنشانی کامل اطلاعات</span>
            </div>
            <p className="text-xs font-semibold text-slate-600 dark:text-slate-300 leading-relaxed">
              آیا از بازنشانی کامل داده‌ها اطمینان دارید؟ با تایید، تمام پارت‌های مطالعه، یادداشت‌ها، کارنامه‌ها و سوابق پاکسازی شده و برنامه به حالت اولیه‌ صفر باز می‌گردد.
            </p>
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowResetConfirmModal(false)}
                className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-bold transition cursor-pointer"
              >
                انصراف
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowResetConfirmModal(false);
                  handleResetAllData();
                }}
                className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-extrabold transition cursor-pointer shadow-md flex items-center gap-1.5"
              >
                <RotateCcw className="w-4 h-4" />
                <span>بله، بازنشانی تمام داده‌ها</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* PWA Install Guide Modal */}
      <PWAInstallGuideModal
        isOpen={isPWAInstallModalOpen}
        onClose={() => setIsPWAInstallModalOpen(false)}
      />

      {/* Footer */}
      <footer className="border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 py-4 text-center text-xs text-slate-500 dark:text-slate-400">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>ویژه داوطلبان کنکور سراسری تجربی · تم انتخابی: {currentTheme.name}</span>
          <button
            type="button"
            onClick={() => setShowResetConfirmModal(true)}
            className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 flex items-center gap-1 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>بازنشانی به داده‌های اولیه</span>
          </button>
        </div>
      </footer>
    </div>
  );
}
