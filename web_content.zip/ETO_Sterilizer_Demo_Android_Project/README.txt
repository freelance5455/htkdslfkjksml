ETO Sterilizer Demo Android Studio Project

This ZIP contains Android app source code and the HMI demo bundled as a local HTML asset.
It is NOT a compiled APK. Android SDK/Gradle build tools were not available in the
current environment, so no APK has been fabricated or mislabeled.

Open this folder in Android Studio, allow Gradle sync/SDK installation, then select:
Build > Build Bundle(s) / APK(s) > Build APK(s).

Output is typically app/build/outputs/apk/debug/app-debug.apk.

SAFETY: Demo only. It does not communicate with a PLC and must not be used to
operate a real ETO sterilizer. Real PLC integration and validation are separate work.
