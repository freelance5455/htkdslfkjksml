ETO STERILIZER DEMO — ANDROID PROJECT
=====================================

Zaroori baat:
- Yeh Android Studio project/source hai, ready-made APK file nahi.
- Is environment mein Android SDK/Gradle build tools available nahi thay,
  is liye main APK build hone ka ghalat dawa nahi kar raha.
- App landscape/full-screen mode mein demo HMI kholti hai.
- Yeh DEMO ONLY hai: PLC se connect nahi hoti aur koi real machine control nahi karti.
- Displayed values/controls ko live sterilizer ke liye istemal na karein.

APK banane ka asaan tareeqa:
1. Computer par Android Studio install karein.
2. ZIP extract karein.
3. Android Studio > Open > extracted "ETO_Sterilizer_Demo_Android_Project" folder.
4. Gradle sync complete hone dein. Agar SDK install karne ka prompt aaye to install karein.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Build complete hone par "locate" par click karein. APK aam tor par:
   app/build/outputs/apk/debug/app-debug.apk
7. APK phone mein copy karein, phir install karein. Android par zarurat ho to
   Settings mein is source se app install karne ki permission allow karein.

Agar sirf phone hai aur computer nahi:
Android Studio ke baghair APK banana mushkil ho sakta hai. Aap bata dein ke
aap ke paas computer/laptop hai ya sirf mobile; main us hisaab se agla tareeqa
guide kar dunga.

App details:
Package: com.eto.sterilizerdemo
Version: 1.0
Minimum Android: Android 6.0 (API 23)
Orientation: Landscape
