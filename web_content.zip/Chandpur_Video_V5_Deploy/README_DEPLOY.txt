Chandpur Video - Firebase Hosting Deploy Package

1) Upload this folder to Cloud Shell.
2) Open Terminal.
3) Run:
   cd Chandpur_Video_V5_Deploy
   firebase login --no-localhost
   firebase use chandpur-video
   firebase deploy --only hosting

Hosting site:
https://chandpur-video.web.app/

Note:
- Email/Password Authentication and Firestore are configured in the Firebase project.
- Firebase Storage currently requires the Blaze billing plan in this project, so video-file upload may not work until a storage solution is enabled.
