export const firebaseConfig = {
  apiKey: "AIzaSyALF-algcga75134Zeh5yHzfR-VO3bxbxs",
  authDomain: "chandpur-video.firebaseapp.com",
  projectId: "chandpur-video",
  storageBucket: "chandpur-video.firebasestorage.app",
  messagingSenderId: "384927224368",
  appId: "1:384927224368:web:e46756eaf1f3ba8faa53f5",
  measurementId: "G-FCJBEP3B3G"
};
