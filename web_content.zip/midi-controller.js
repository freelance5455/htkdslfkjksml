// =====================================================================
// JUZISOUND MIDI CONTROLLER & KORG Pa600 INTEGRATION
// Web MIDI API Dispatcher with Breath & Pedal Harmonizer Toggle
// =====================================================================

class JuzisoundMidiController {
  constructor(audioEngine, harmonizer) {
    this.audio = audioEngine;
    this.harmonizer = harmonizer;

    this.midiAccess = null;
    this.selectedInput = null;
    this.selectedOutput = null;

    // Режими на изход
    this.outputToInternalAudio = true; // Звук от телефона
    this.outputToKorgMidi = true;      // Връщане на MIDI терци към Korg Pa600
    this.korgHarmonizerChannel = 2;    // Изпращане към Upper 2 (MIDI Ch 2) или Ch 1

    // Състояние на педала (CC#64)
    this.pedalMode = 'sustain';        // 'sustain' (обикновен състейн) или 'toggle_terca' (педалът пуска/спира терцата!)

    // Активно следене на изпратените към Korg хармонизирани ноти за коректен Note Off
    this.activeHarmonizedNotes = new Map(); // inputMidiNote -> [harmonizedMidiNotes]

    // Callback за визуално обновяване на интерфейса
    this.onNoteEvent = null;           // (note, isHarmonized, isOn) => {}
    this.onStatusChange = null;        // (msg) => {}
    this.onDeviceListChange = null;    // (inputs, outputs) => {}

    this.initMidi();
  }

  // Запитване за Web MIDI достъп
  async initMidi() {
    if (!navigator.requestMIDIAccess) {
      if (this.onStatusChange) this.onStatusChange('Браузърът не поддържа Web MIDI API. Използвай Chrome на Android/PC.');
      return;
    }

    try {
      this.midiAccess = await navigator.requestMIDIAccess({ sysex: true });
      if (this.onStatusChange) this.onStatusChange('MIDI ядрото е готово!');

      this.updateDeviceLists();

      // Слушане за включване / изключване на USB кабели в движение
      this.midiAccess.onstatechange = (e) => {
        this.updateDeviceLists();
      };
    } catch (err) {
      if (this.onStatusChange) this.onStatusChange('Няма достъп до MIDI: ' + err.message);
    }
  }

  // Обновяване на списъка с устройства (Korg Pa600, USB MIDI, Breath Controller)
  updateDeviceLists() {
    if (!this.midiAccess) return;

    const inputs = Array.from(this.midiAccess.inputs.values());
    const outputs = Array.from(this.midiAccess.outputs.values());

    // Автоматично избиране на Korg Pa ако бъде открит по име
    let korgInput = inputs.find(i => i.name.toLowerCase().includes('korg') || i.name.toLowerCase().includes('pa600'));
    let korgOutput = outputs.find(o => o.name.toLowerCase().includes('korg') || o.name.toLowerCase().includes('pa600'));

    if (!this.selectedInput && inputs.length > 0) {
      this.selectInput(korgInput || inputs[0]);
    }

    if (!this.selectedOutput && outputs.length > 0) {
      this.selectOutput(korgOutput || outputs[0]);
    }

    if (this.onDeviceListChange) {
      this.onDeviceListChange(inputs, outputs, this.selectedInput, this.selectedOutput);
    }
  }

  selectInput(inputDevice) {
    if (this.selectedInput) {
      this.selectedInput.onmidimessage = null;
    }
    this.selectedInput = inputDevice;
    if (this.selectedInput) {
      this.selectedInput.onmidimessage = (msg) => this.handleIncomingMidi(msg);
      if (this.onStatusChange) this.onStatusChange('Вход: ' + this.selectedInput.name);
    }
  }

  selectOutput(outputDevice) {
    this.selectedOutput = outputDevice;
    if (this.selectedOutput && this.onStatusChange) {
      this.onStatusChange('Изход: ' + this.selectedOutput.name);
    }
  }

  // Главен обработчик на MIDI съобщения в реално време
  handleIncomingMidi(event) {
    const data = event.data;
    const status = data[0];
    const messageType = status & 0xF0;
    const channel = status & 0x0F;
    const data1 = data[1];
    const data2 = data[2];

    switch (messageType) {
      case 0x90: { // Note On (или Note Off при velocity = 0)
        const note = data1;
        const velocity = data2;
        if (velocity > 0) {
          this.handleNoteOn(note, velocity, channel);
        } else {
          this.handleNoteOff(note, channel);
        }
        break;
      }

      case 0x80: { // Note Off
        this.handleNoteOff(data1, channel);
        break;
      }

      case 0xE0: { // Pitch Bend
        // 14-bit стойност: 0 .. 16383, център = 8192
        const rawBend = (data2 << 7) | data1;
        const normalized = (rawBend - 8192) / 8192;
        
        // Аудио процесор
        if (this.audio) {
          this.audio.setPitchBend(normalized);
        }

        // Препредаване на Pitch Bend към втория глас на Korg Pa600
        if (this.outputToKorgMidi && this.selectedOutput) {
          const targetStatus = 0xE0 | (this.korgHarmonizerChannel - 1);
          this.selectedOutput.send([targetStatus, data1, data2]);
        }
        break;
      }

      case 0xB0: { // Control Change (CC)
        const ccNumber = data1;
        const ccValue = data2;

        // CC#11 (Expression) или CC#2 (Breath Controller)
        if (ccNumber === 11 || ccNumber === 2) {
          const breathNorm = ccValue / 127;
          if (this.audio) this.audio.setBreath(breathNorm);
        }
        // CC#1 (Modulation Wheel - Vibrato)
        else if (ccNumber === 1) {
          // vibrato modulation
        }
        // CC#64 (Sustain / Damper Pedal)
        else if (ccNumber === 64) {
          if (this.pedalMode === 'toggle_terca') {
            // Натискане на педала включва терцата, отпускането я спира (или превключва)
            if (ccValue >= 64) {
              this.harmonizer.enabled = !this.harmonizer.enabled;
              if (this.onStatusChange) {
                this.onStatusChange('Терца: ' + (this.harmonizer.enabled ? 'ВКЛЮЧЕНА (ON)' : 'ИЗКЛЮЧЕНА (OFF)'));
              }
            }
          }
        }
        break;
      }
    }
  }

  // Обработка на изсвирена нота (Note On)
  handleNoteOn(note, velocity, inChannel) {
    // 1. Възпроизвеждане на главния соло звук от телефона
    const detune = this.harmonizer.getDetuneCents(note);
    if (this.outputToInternalAudio && this.audio) {
      this.audio.noteOn(note, velocity, false, detune);
    }

    if (this.onNoteEvent) this.onNoteEvent(note, false, true);

    // 2. Изчисляване на интелигентната етно терция
    const harmNotes = this.harmonizer.getHarmonizedNote(note);

    if (harmNotes && harmNotes.length > 0) {
      this.activeHarmonizedNotes.set(note, harmNotes);

      for (const harmNote of harmNotes) {
        const harmDetune = this.harmonizer.getDetuneCents(harmNote);

        // Възпроизвеждане на втория глас от телефона
        if (this.outputToInternalAudio && this.audio) {
          this.audio.noteOn(harmNote, velocity, true, harmDetune);
        }

        // Изпращане на втория глас обратно към Korg Pa600 (напр. Upper 2)
        if (this.outputToKorgMidi && this.selectedOutput) {
          const targetStatus = 0x90 | (this.korgHarmonizerChannel - 1);
          this.selectedOutput.send([targetStatus, harmNote, velocity]);
        }

        if (this.onNoteEvent) this.onNoteEvent(harmNote, true, true);
      }
    }
  }

  // Обработка на отпусната нота (Note Off)
  handleNoteOff(note, inChannel) {
    // 1. Спиране на соло нотата в телефона
    if (this.outputToInternalAudio && this.audio) {
      this.audio.noteOff(note);
    }

    if (this.onNoteEvent) this.onNoteEvent(note, false, false);

    // 2. Спиране на хармонизираната терца
    if (this.activeHarmonizedNotes.has(note)) {
      const harmNotes = this.activeHarmonizedNotes.get(note);
      for (const harmNote of harmNotes) {
        if (this.outputToInternalAudio && this.audio) {
          this.audio.noteOff(harmNote);
        }

        // Изпращане на Note Off към Korg-а
        if (this.outputToKorgMidi && this.selectedOutput) {
          const targetStatus = 0x80 | (this.korgHarmonizerChannel - 1);
          this.selectedOutput.send([targetStatus, harmNote, 0]);
        }

        if (this.onNoteEvent) this.onNoteEvent(harmNote, true, false);
      }
      this.activeHarmonizedNotes.delete(note);
    }
  }

  // Изпращане на SysEx за четвърт тонове към Korg Pa600
  sendQuarterTonesToKorg() {
    if (this.selectedOutput && this.harmonizer) {
      const sysex = this.harmonizer.generateKorgSysExTune();
      try {
        this.selectedOutput.send(sysex);
        if (this.onStatusChange) this.onStatusChange('Korg Pa четвърт тонове обновени!');
      } catch (e) {
        console.warn('SysEx грешка:', e);
      }
    }
  }

  // Спиране на всички ноти (Panic)
  panic() {
    if (this.audio) this.audio.allNotesOff();
    if (this.selectedOutput) {
      for (let ch = 0; ch < 16; ch++) {
        this.selectedOutput.send([0xB0 | ch, 123, 0]); // All Notes Off
        this.selectedOutput.send([0xB0 | ch, 120, 0]); // All Sound Off
      }
    }
    this.activeHarmonizedNotes.clear();
  }
}

window.JuzisoundMidiController = JuzisoundMidiController;
