# Ashraf HVAC Engineer Pro

Android project wrapper for the HVAC Engineer Pro learning/reference app.

Package: com.ashraf.hvacengineerpro
App name: Ashraf HVAC Engineer Pro
Version: 1.0

Open this project in Android Studio and build an APK:
Build > Build APK(s)

The HTML content is bundled locally in app/src/main/assets, so the core app works offline.
