# Ashraf HVAC Engineer Pro — Content Roadmap

## Learning sequence
Beginner → Fundamentals → Technician → Site Engineer → HVAC Design → AutoCAD → Revit/BIM → QA/QC → TAB/Commissioning → Gulf Professional → Interview.

## Ventilation — full coverage
- Supply, return, outdoor/fresh and exhaust air
- ACH, CFM, CMH, L/s and unit conversions
- Outdoor-air/ventilation calculations
- Toilet exhaust
- Kitchen and commercial-kitchen exhaust
- Basement/car-park ventilation and CO-control concepts
- Stair/lobby ventilation
- Smoke-exhaust concepts and fire/smoke dampers
- FAHU/AHU/FCU/ERV/HRV concepts
- Fans, static pressure and pressure-loss calculations
- Louvers, filters, dampers and VCDs
- Duct sizing and balancing

## Building-by-building design
Villa/apartment: room heat load, split/cassette/ductable/VRF, fresh air and toilet/kitchen exhaust.

Office/showroom/retail: zoning, AHU/FCU/VRF, fresh air, return air, ducting, controls and schedules.

Hotel: guest rooms, corridors, kitchens, toilets, public areas, ventilation and hot/humid climate considerations.

Mall: large AHUs/FAHUs, tenant areas, food court, toilets, car park, smoke-control concepts, controls/BMS and TAB.

Hospital: OT, ICU, isolation, wards, emergency, labs, pharmacy, CSSD and other critical spaces; pressure relationships, outdoor air, exhaust, filtration and commissioning. Exact values must follow the adopted healthcare standard, authority requirements and project specification.

Industrial/laboratory: process exhaust, make-up air, contamination-control concepts and specialist systems according to project requirements.

## Professional workflow
Architectural drawing → space schedule → design criteria → heat load → ventilation → system selection → equipment selection → airflow → duct/piping sizing → pressure-loss → controls → drawings → BOQ → specifications → shop/coordinated/as-built drawings → installation → QA/QC → TAB → commissioning → handover/O&M.

## Core reference hierarchy
Project specification/local authority code → adopted international standard → manufacturer data → engineering judgement.
