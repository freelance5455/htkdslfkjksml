Trading Plan Guard AI v1.3.10 — उपयोग निर्देश

1. index.html को Chrome में खोलें। Android पर Files/Downloads में फाइल पर टैप करके Chrome चुनें।
2. पहले Daily Rules भरें और Save Rules दबाएँ।
3. यह Paper Trading prototype है। यह Groww से कनेक्ट नहीं होता और कोई असली ऑर्डर नहीं भेजता।
4. डेटा उसी ब्राउज़र के local storage में रह सकता है। ब्राउज़र डेटा साफ करने पर रिकॉर्ड मिट सकते हैं; नियमित Backup JSON डाउनलोड करें।
5. यह APK नहीं है और इंटरनेट पर प्रकाशित वेबसाइट भी नहीं है। ZIP में उपलब्ध HTML ऐप और निर्देश हैं।
6. लाइव ट्रेडिंग, Groww API, सुरक्षित सर्वर/लॉगिन, और वास्तविक Android APK अभी बने/सत्यापित नहीं हैं।
