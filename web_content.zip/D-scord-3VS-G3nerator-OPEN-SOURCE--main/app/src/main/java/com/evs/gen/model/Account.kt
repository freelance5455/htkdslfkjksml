package com.evs.gen.model

data class Account(
    val email: String,
    val username: String,
    val displayName: String,
    val password: String,
    var token: String = "",
    val createdAt: Long = System.currentTimeMillis()
) {
    override fun toString() = "$email:$password:$username"
}
