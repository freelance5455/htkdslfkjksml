package com.evs.gen.util

import android.content.Context
import com.evs.gen.model.Account
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class AccountManager(context: Context) {
    private val prefs = context.getSharedPreferences("evs_gen_prefs", Context.MODE_PRIVATE)
    private val gson = Gson()

    fun saveAccount(account: Account) {
        val list = getAccounts().toMutableList()
        list.add(account)
        prefs.edit().putString("accounts", gson.toJson(list)).apply()
    }

    fun getAccounts(): List<Account> {
        val json = prefs.getString("accounts", "[]") ?: "[]"
        val type = object : TypeToken<List<Account>>() {}.type
        return gson.fromJson(json, type) ?: emptyList()
    }

    fun clearAccounts() = prefs.edit().remove("accounts").apply()

    fun getCount() = getAccounts().size

    fun exportAll() = getAccounts().joinToString("\n") { it.toString() }
}
