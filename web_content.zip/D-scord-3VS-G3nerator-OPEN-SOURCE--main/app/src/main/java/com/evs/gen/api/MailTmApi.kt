package com.evs.gen.api

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import kotlin.random.Random

class MailTmApi {
    private val client = OkHttpClient()
    private val JSON = "application/json; charset=utf-8".toMediaType()
    private val BASE = "https://api.mail.tm"
    private val PREFERRED = listOf("mailto.plus","fexpost.com","fexbox.org","mailpoof.com")

    var email: String = ""
        private set
    private var mailPass: String = ""
    var token: String = ""
        private set

    suspend fun createAccount(): String = withContext(Dispatchers.IO) {
        val domain = getBestDomain()
        val prefixes = listOf("user","acc","gen","tmp","mail","inbox","box","new")
        val local = prefixes.random() + (1000 + Random.nextInt(9000))
        email = "$local@$domain"
        mailPass = (1..12).map { "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"[Random.nextInt(62)] }.joinToString("")

        val body = JSONObject().apply {
            put("address", email)
            put("password", mailPass)
        }.toString().toRequestBody(JSON)

        val accReq = Request.Builder().url("$BASE/accounts").post(body).build()
        val accResp = client.newCall(accReq).execute()
        if (!accResp.isSuccessful) throw Exception("Account creation failed: ${accResp.code}")
        accResp.close()

        val tokBody = JSONObject().apply {
            put("address", email)
            put("password", mailPass)
        }.toString().toRequestBody(JSON)

        val tokReq = Request.Builder().url("$BASE/token").post(tokBody).build()
        val tokResp = client.newCall(tokReq).execute()
        if (!tokResp.isSuccessful) throw Exception("Token failed: ${tokResp.code}")
        val tokJson = JSONObject(tokResp.body!!.string())
        tokResp.close()
        token = tokJson.getString("token")
        email
    }

    private fun getBestDomain(): String {
        val req = Request.Builder().url("$BASE/domains").build()
        val resp = client.newCall(req).execute()
        if (!resp.isSuccessful) throw Exception("Domains failed: ${resp.code}")
        val json = JSONObject(resp.body!!.string())
        resp.close()
        val members = json.getJSONArray("hydra:member")
        val available = (0 until members.length()).map { members.getJSONObject(it).getString("domain") }
        return PREFERRED.firstOrNull { it in available } ?: available.random()
    }

    suspend fun pollInbox(maxAttempts: Int = 20): String? = withContext(Dispatchers.IO) {
        repeat(maxAttempts) {
            Thread.sleep(3000)
            val req = Request.Builder()
                .url("$BASE/messages")
                .header("Authorization", "Bearer $token")
                .build()
            val resp = client.newCall(req).execute()
            if (resp.isSuccessful) {
                val json = JSONObject(resp.body!!.string())
                resp.close()
                val members = json.getJSONArray("hydra:member")
                if (members.length() > 0) {
                    val msgId = members.getJSONObject(0).getString("id")
                    return@withContext getMessageBody(msgId)
                }
            } else resp.close()
        }
        null
    }

    private fun getMessageBody(id: String): String {
        val req = Request.Builder()
            .url("$BASE/messages/$id")
            .header("Authorization", "Bearer $token")
            .build()
        val resp = client.newCall(req).execute()
        val body = resp.body!!.string()
        resp.close()
        val json = JSONObject(body)
        return json.optString("html", json.optString("text", ""))
    }
}
