package com.evs.gen.util

import kotlin.random.Random

object NameGenerator {
    private val ADJECTIVES = listOf(
        "dark","silent","swift","cold","night","iron","steel","void",
        "neon","cyber","ghost","shadow","storm","fire","ice",
        "black","red","blue","crimson","silver","golden","wild","dead"
    )
    private val NOUNS = listOf(
        "wolf","eagle","viper","raven","titan","hunter","blade","storm",
        "claw","fang","hawk","lynx","cobra","panther","dragon","reaper",
        "shadow","ghost","void","nova","apex","nexus","core","byte"
    )
    private val CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$"

    fun generateDisplayName(): String {
        val adj = ADJECTIVES.random().replaceFirstChar { it.uppercase() }
        val noun = NOUNS.random().replaceFirstChar { it.uppercase() }
        return adj + noun
    }

    fun generateUsername(displayName: String): String {
        return displayName.lowercase() + (100 + Random.nextInt(9900))
    }

    fun generatePassword(): String {
        return (1..14).map { CHARS[Random.nextInt(CHARS.length)] }.joinToString("")
    }

    fun randomDay() = Random.nextInt(1, 29)
    fun randomMonth() = Random.nextInt(1, 13)
    fun randomYear() = Random.nextInt(1994, 2007)
}
