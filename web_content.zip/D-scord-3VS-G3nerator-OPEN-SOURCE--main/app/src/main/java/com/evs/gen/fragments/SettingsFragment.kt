package com.evs.gen.fragments

import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.evs.gen.databinding.FragmentSettingsBinding

class SettingsFragment : Fragment() {
    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        val prefs = requireContext().getSharedPreferences("evs_settings", 0)
        binding.etDelay.setText(prefs.getInt("delay_ms", 400).toString())
        binding.switchProxy.isChecked = prefs.getBoolean("use_proxy", false)
        binding.etProxy.setText(prefs.getString("proxy", ""))
        binding.etProxy.isEnabled = binding.switchProxy.isChecked
        binding.switchProxy.setOnCheckedChangeListener { _, c -> binding.etProxy.isEnabled = c }
        binding.btnSaveSettings.setOnClickListener {
            prefs.edit()
                .putInt("delay_ms", binding.etDelay.text.toString().toIntOrNull() ?: 400)
                .putBoolean("use_proxy", binding.switchProxy.isChecked)
                .putString("proxy", binding.etProxy.text.toString())
                .apply()
            Toast.makeText(context, "Saved", Toast.LENGTH_SHORT).show()
        }
        return binding.root
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
