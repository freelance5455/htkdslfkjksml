package com.evs.gen

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.evs.gen.fragments.*
import com.evs.gen.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val generateFragment = GenerateFragment()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, generateFragment)
            .commit()

        binding.bottomNav.setOnItemSelectedListener { item ->
            val fragment = when (item.itemId) {
                R.id.nav_generate -> generateFragment
                R.id.nav_accounts -> AccountsFragment()
                R.id.nav_tools -> ToolsFragment()
                R.id.nav_settings -> SettingsFragment()
                else -> InfoFragment()
            }
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, fragment)
                .commit()
            true
        }
    }
}
