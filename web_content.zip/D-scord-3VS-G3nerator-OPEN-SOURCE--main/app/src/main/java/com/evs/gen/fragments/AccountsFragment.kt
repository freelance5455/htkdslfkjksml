package com.evs.gen.fragments

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.*
import com.evs.gen.R
import com.evs.gen.model.Account
import com.evs.gen.util.AccountManager
import com.evs.gen.databinding.FragmentAccountsBinding

class AccountsFragment : Fragment() {
    private var _binding: FragmentAccountsBinding? = null
    private val binding get() = _binding!!
    private lateinit var accountManager: AccountManager

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentAccountsBinding.inflate(inflater, container, false)
        accountManager = AccountManager(requireContext())
        binding.recyclerAccounts.layoutManager = LinearLayoutManager(context)
        loadAccounts()
        binding.btnExport.setOnClickListener {
            val text = accountManager.exportAll()
            if (text.isBlank()) { Toast.makeText(context, "No accounts", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            val cb = requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cb.setPrimaryClip(ClipData.newPlainText("accounts", text))
            Toast.makeText(context, "Copied to clipboard", Toast.LENGTH_SHORT).show()
        }
        binding.btnClearAll.setOnClickListener {
            accountManager.clearAccounts()
            loadAccounts()
            Toast.makeText(context, "Cleared", Toast.LENGTH_SHORT).show()
        }
        return binding.root
    }

    override fun onResume() { super.onResume(); loadAccounts() }

    private fun loadAccounts() {
        val accounts = accountManager.getAccounts()
        if (accounts.isEmpty()) {
            binding.tvEmpty.visibility = View.VISIBLE
            binding.recyclerAccounts.visibility = View.GONE
        } else {
            binding.tvEmpty.visibility = View.GONE
            binding.recyclerAccounts.visibility = View.VISIBLE
            binding.recyclerAccounts.adapter = Adapter(accounts)
        }
    }

    inner class Adapter(private val list: List<Account>) : RecyclerView.Adapter<Adapter.VH>() {
        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val email: TextView = v.findViewById(R.id.tvEmail)
            val user: TextView = v.findViewById(R.id.tvUsername)
            val pass: TextView = v.findViewById(R.id.tvPassword)
        }
        override fun onCreateViewHolder(p: ViewGroup, t: Int) = VH(LayoutInflater.from(p.context).inflate(R.layout.item_account, p, false))
        override fun getItemCount() = list.size
        override fun onBindViewHolder(h: VH, i: Int) {
            val a = list[i]
            h.email.text = a.email
            h.user.text = "@${a.username}"
            h.pass.text = a.password
            h.itemView.setOnLongClickListener {
                val cb = h.itemView.context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cb.setPrimaryClip(ClipData.newPlainText("acc", a.toString()))
                Toast.makeText(h.itemView.context, "Copied", Toast.LENGTH_SHORT).show()
                true
            }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
