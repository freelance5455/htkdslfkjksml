package com.evs.gen.fragments

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.evs.gen.util.NameGenerator
import com.evs.gen.databinding.FragmentToolsBinding

class ToolsFragment : Fragment() {
    private var _binding: FragmentToolsBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentToolsBinding.inflate(inflater, container, false)
        binding.btnGenUsername.setOnClickListener {
            val d = NameGenerator.generateDisplayName()
            binding.etToolOutput.setText("$d\n${NameGenerator.generateUsername(d)}")
        }
        binding.btnGenPassword.setOnClickListener {
            binding.etToolOutput.setText((1..10).joinToString("\n") { NameGenerator.generatePassword() })
        }
        binding.btnCopyOutput.setOnClickListener {
            val t = binding.etToolOutput.text.toString()
            if (t.isNotEmpty()) {
                val cb = requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cb.setPrimaryClip(ClipData.newPlainText("out", t))
                Toast.makeText(context, "Copied", Toast.LENGTH_SHORT).show()
            }
        }
        return binding.root
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
