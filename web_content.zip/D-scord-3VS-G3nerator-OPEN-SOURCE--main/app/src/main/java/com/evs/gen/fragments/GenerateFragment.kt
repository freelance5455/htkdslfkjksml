package com.evs.gen.fragments

import android.annotation.SuppressLint
import android.os.Bundle
import android.text.Html
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.*
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.evs.gen.R
import com.evs.gen.api.MailTmApi
import com.evs.gen.model.Account
import com.evs.gen.util.AccountManager
import com.evs.gen.util.NameGenerator
import com.evs.gen.databinding.FragmentGenerateBinding
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class GenerateFragment : Fragment() {

    private var _binding: FragmentGenerateBinding? = null
    private val binding get() = _binding!!

    private lateinit var accountManager: AccountManager
    private var mailApi = MailTmApi()

    private var isRunning = false
    private var isPaused = false

    private var currentEmail = ""
    private var currentUsername = ""
    private var currentDisplayName = ""
    private var currentPassword = ""

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentGenerateBinding.inflate(inflater, container, false)
        accountManager = AccountManager(requireContext())
        setupWebView()
        setupButtons()
        updateGenCount()
        return binding.root
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        binding.webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            userAgentString = "Mozilla/5.0 (Linux; Android 10; Pixel 4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
        }
        binding.webView.addJavascriptInterface(JsBridge(), "Android")
        binding.webView.webChromeClient = WebChromeClient()
        binding.webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                if (url.contains("discord.com/register") && isRunning && !isPaused) {
                    log("[i] Page loaded, starting automation...", "#888888")
                    view.postDelayed({ injectAutomation() }, 1500)
                }
            }
        }
        binding.webView.loadUrl("https://discord.com/register")
    }

    private fun setupButtons() {
        binding.btnRegister.setOnClickListener { startGeneration() }
        binding.btnPause.setOnClickListener { togglePause() }
        binding.btnStop.setOnClickListener { stopGeneration() }
        binding.tvClearConsole.setOnClickListener { binding.tvConsole.text = "" }
    }

    private fun startGeneration() {
        if (isRunning) return
        isRunning = true
        isPaused = false
        log("[i] Starting generation...", "#888888")
        log("[i] Evs GEN v1.0", "#888888")

        mailApi = MailTmApi()
        lifecycleScope.launch {
            try {
                val email = mailApi.createAccount()
                currentEmail = email
                log("[+] Domain ready: @${email.split("@")[1]}", "#00ff88")
                log("[+] Generated email: $email", "#00ff88")

                currentDisplayName = NameGenerator.generateDisplayName()
                currentUsername = NameGenerator.generateUsername(currentDisplayName)
                currentPassword = NameGenerator.generatePassword()

                activity?.runOnUiThread {
                    binding.webView.loadUrl("https://discord.com/register")
                }
            } catch (e: Exception) {
                log("[!] Email error: ${e.message}", "#ff4444")
                isRunning = false
            }
        }
    }

    private fun injectAutomation() {
        if (!isRunning || isPaused) return
        val dob = Triple(NameGenerator.randomDay(), NameGenerator.randomMonth(), NameGenerator.randomYear())
        val js = buildJs(currentEmail, currentDisplayName, currentUsername, currentPassword, dob)
        binding.webView.evaluateJavascript(js, null)
    }

    private fun buildJs(email: String, display: String, username: String, password: String, dob: Triple<Int,Int,Int>): String {
        val e = email.replace("'", "\\'")
        val d = display.replace("'", "\\'")
        val u = username.replace("'", "\\'")
        val p = password.replace("'", "\\'")
        return """javascript:(async function() {
  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
  function setVal(el, v) {
    const s = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value').set;
    s.call(el, v);
    el.dispatchEvent(new Event('input', {bubbles:true}));
    el.dispatchEvent(new Event('change', {bubbles:true}));
  }
  await sleep(1000);
  const emailEl = document.querySelector('input[type="email"]') || document.querySelector('input[name="email"]');
  if (emailEl) { setVal(emailEl, '$e'); Android.log('[+] Email entered: $e', '#00ff88'); }
  await sleep(400);
  const texts = document.querySelectorAll('input[type="text"], input:not([type])');
  if (texts[0]) { setVal(texts[0], '$d'); Android.log('[+] Display name entered: $d', '#00ff88'); }
  await sleep(400);
  if (texts[1]) { setVal(texts[1], '$u'); Android.log('[+] Username entered: $u', '#00ff88'); }
  await sleep(400);
  const passEl = document.querySelector('input[type="password"]');
  if (passEl) { setVal(passEl, '$p'); Android.log('[+] Password entered', '#00ff88'); }
  await sleep(600);
  const selects = document.querySelectorAll('select');
  if (selects.length >= 3) {
    selects[0].value = '${dob.second}'; selects[0].dispatchEvent(new Event('change',{bubbles:true}));
    await sleep(300);
    selects[1].value = '${dob.first}'; selects[1].dispatchEvent(new Event('change',{bubbles:true}));
    await sleep(300);
    selects[2].value = '${dob.third}'; selects[2].dispatchEvent(new Event('change',{bubbles:true}));
    Android.log('[+] DOB entered', '#00ff88');
  } else {
    Android.log('[i] DOB controls resolved by position fallback', '#888888');
    const dobEls = document.querySelectorAll('[class*="dateOfBirth"] [class*="inputDefault"],[class*="date"] [class*="select"]');
    if (dobEls[0]) {
      dobEls[0].click(); await sleep(500);
      const opts = document.querySelectorAll('[class*="option"]');
      if (opts.length > 0) { opts[Math.min(${dob.second - 1}, opts.length-1)].click(); Android.log('[+] Month selected', '#00ff88'); }
      else { Android.log('[!] Month: menu empty - retrying', '#ffaa00'); }
    }
  }
  await sleep(500);
  Android.log('[i] Waiting for captcha - solve it manually then tap Continue', '#888888');
  Android.onComplete('$e','$u','$d','$p');
})();"""
    }

    private fun togglePause() {
        isPaused = !isPaused
        binding.btnPause.text = if (isPaused) "RESUME" else "PAUSE"
        log(if (isPaused) "[i] Paused" else "[i] Resumed", "#888888")
    }

    private fun stopGeneration() {
        isRunning = false
        isPaused = false
        binding.btnPause.text = "PAUSE"
        log("[i] Stopped", "#ff4444")
        binding.webView.loadUrl("https://discord.com/register")
    }

    fun log(message: String, color: String) {
        activity?.runOnUiThread {
            val ts = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
            val formatted = "<font color='$color'>$ts ${Html.escapeHtml(message)}</font><br>"
            binding.tvConsole.append(Html.fromHtml(formatted, Html.FROM_HTML_MODE_COMPACT))
            binding.consoleScroll.post { binding.consoleScroll.fullScroll(View.FOCUS_DOWN) }
        }
    }

    private fun updateGenCount() {
        binding.tvGenCount.text = "Generated: ${accountManager.getCount()}"
    }

    inner class JsBridge {
        @JavascriptInterface
        fun log(msg: String, color: String) = this@GenerateFragment.log(msg, color)

        @JavascriptInterface
        fun onComplete(email: String, username: String, displayName: String, password: String) {
            activity?.runOnUiThread {
                binding.webView.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, url: String) {
                        if (url.contains("/app") || url.contains("/channels/@me")) {
                            val acc = Account(email, username, displayName, password)
                            accountManager.saveAccount(acc)
                            log("[+] Account created: $email", "#00ff88")
                            updateGenCount()
                        }
                    }
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
