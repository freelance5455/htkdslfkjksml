Proxy & VPN Android WebView taslamasy

Bu taslama Android Studio-da açylýan başlangyç taslama.
APK-ni şu ýerde göni kompile edip bermek mümkin bolmady, ýöne taslama çeşme faýllary taýýar.

APK döretmek:
1. Taslamany Android Studio-da aç.
2. Gradle sync tamamlanýança garaş.
3. Build > Build Bundle(s) / APK(s) > Build APK(s) saýla.
4. APK app/build/outputs/apk/debug/ içinde bolar.

Bellik:
- Häzirki HTML demo maglumatlary diňe bir enjamyň localStorage ammarynda saklaýar.
- Ähli ulanyjylara maglumat ýaýratmak üçin Firebase Auth + Firestore goşulmaly.
- Häzirki admin panel demo maksatly; howpsuz admin hasaby däl.
- MTProto baglanyşygy Telegram-a geçmek üçin düzülen.
