/* JOSTECH — MANUEL 08 : ROBOTIQUE NIVEAU 2 */
registerLessonDetail(8, 2, "rob-2-1-1", {
  title: "Leçon 1 : Microcontrôleurs Arduino, ADC, PWM et Évitement d'Obstacles",
  duration: "45 min (Manuel complet)",
  objectives: [
    "Différencier un microcontrôleur (Arduino/ESP32) d'un micro-ordinateur (Raspberry Pi).",
    "Maîtriser les signaux numériques (HIGH/LOW), la conversion analogique ADC et la modulation PWM.",
    "Programmer un robot autonome complet évitant les obstacles grâce à un capteur ultrason."
  ],
  prerequisites: ["Niveau 1 — Robotique et bases du langage C/C++."],
  sections: [
    {
      type: "theory",
      title: "1. Microcontrôleur vs Micro-ordinateur & Signaux ADC / PWM",
      text: "Un microcontrôleur (Arduino Uno, ESP32) n'a pas de système d'exploitation lourd : il démarre en quelques millisecondes, consomme très peu d'énergie et pilote directement le matériel en temps réel. Un micro-ordinateur (Raspberry Pi) tourne sous Linux et sert plutôt aux tâches lourdes (caméra, IA, serveur Web).\n\n• Entrée Analogique (ADC) : convertit une tension continue (ex. 0 V à 5 V d'un capteur) en entier binaire. Sur un ADC 10 bits, 0 V donne 0 et 5 V donne 1023 (2^10 - 1).\n• Sortie PWM (Pulse Width Modulation) : comme une broche numérique ne sort que 0 V ou 5 V, elle clignote des milliers de fois par seconde : avec un rapport cyclique (Duty Cycle) de 50 %, la puissance moyenne transmise au moteur vaut 50 % !"
    },
    {
      type: "code",
      lang: "C++ Arduino — Robot autonome anti-obstacle (HC-SR04)",
      code: [
        "const int TRIG = 9, ECHO = 10, M_GAUCHE = 5, M_DROITE = 6;",
        "void setup() {",
        "  pinMode(TRIG, OUTPUT); pinMode(ECHO, INPUT);",
        "  pinMode(M_GAUCHE, OUTPUT); pinMode(M_DROITE, OUTPUT);",
        "}",
        "long lireDistanceCm() {",
        "  digitalWrite(TRIG, LOW); delayMicroseconds(2);",
        "  digitalWrite(TRIG, HIGH); delayMicroseconds(10); digitalWrite(TRIG, LOW);",
        "  long duree = pulseIn(ECHO, HIGH, 30000); // Temps aller-retour en µs",
        "  return duree * 0.034 / 2;                // Vitesse son = 0,034 cm/µs",
        "}",
        "void loop() {",
        "  long dist = lireDistanceCm();",
        "  if (dist > 0 && dist < 25) { // Obstacle proche (< 25 cm) → Tourner",
        "    analogWrite(M_GAUCHE, 180); analogWrite(M_DROITE, 0);",
        "  } else {                     // Voie libre → Avancer à 80 % PWM",
        "    analogWrite(M_GAUCHE, 200); analogWrite(M_DROITE, 200);",
        "  }",
        "}"
      ].join("\n")
    },
    {
      type: "warning",
      title: "Piège logique : la vitesse du son et les rebonds",
      text: "1) N'oubliez jamais de diviser par 2 le temps mesuré par le capteur ultrason : l'onde sonore fait un ALLER vers l'obstacle puis un RETOUR vers le capteur !\n2) Un PWM de 0 à 255 s'écrit sur 8 bits (analogWrite), alors qu'analogRead lit sur 10 bits (0 à 1023) : utilisez map(val, 0, 1023, 0, 255) pour convertir."
    }
  ],
  exercises: [
    {
      title: "Exercice 1 — Calcul d'écholocalisation ultrason",
      question: "Le capteur ultrason mesure un temps aller-retour de 2 000 microsecondes (2 ms). Sachant que le son parcourt 0,034 cm par microseconde dans l'air, à quelle distance exacte se trouve le mur ?",
      solution: "Distance = (2000 × 0,034) / 2 = 68 / 2 = 34 cm !"
    },
    {
      title: "Exercice 2 — Conversion ADC 10 bits",
      question: "Un capteur de température sort 1,25 V sur une carte Arduino 5 V dotée d'un ADC 10 bits (0 à 1023). Quelle valeur entière approx. renvoie analogRead() ?",
      solution: "1,25 V représente le quart de 5 V (1/4). Donc 1023 × 0,25 ≈ 256."
    }
  ],
  summary: "Les microcontrôleurs pilotent le réel grâce aux entrées analogiques ADC (0-1023) et aux sorties PWM (0-255), permettant d'intégrer des capteurs comme l'ultrason dans une boucle de navigation autonome.",
  references: ["Arduino Language Reference (arduino.cc).", "Blum, J. — Exploring Arduino."]
});