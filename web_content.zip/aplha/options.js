(async function () {
const $ = (sel) => document.querySelector(sel);
let state = {};
let suppressPush = false;
const deviceId = await ALPHA_LICENSE.getDeviceId();
$('#deviceId').textContent = deviceId;
const dot = $('#statusDot'), label = $('#statusLabel');
dot.classList.add('approved');
label.textContent = 'Ready';
function withActiveTab(cb) {
chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
if (tabs && tabs[0]) cb(tabs[0].id);
});
}
function pushState(partial) {
state = Object.assign({}, state, partial);
try { chrome.storage.local.set({ ambState: state }); } catch (_) {}
withActiveTab((tabId) => {
chrome.tabs.sendMessage(tabId, { type: 'AMB_QUICK_SET', value: partial }, () => {
if (chrome.runtime.lastError) {  }
});
});
}
function bindRange(id, key, fmt) {
const el = $('#' + id), valEl = $('#' + id + 'Val');
el.addEventListener('input', () => {
const v = parseFloat(el.value);
if (valEl) valEl.textContent = fmt(v);
if (!suppressPush) pushState({ [key]: v });
});
}
function bindToggle(id, key) {
$('#' + id).addEventListener('change', (e) => { if (!suppressPush) pushState({ [key]: e.target.checked }); });
}
bindRange('boost', 'volumeBoost', (v) => v.toFixed(0) + 'x');
bindToggle('autoGainToggle', 'autoGainEnabled');
bindRange('bass', 'eq90', (v) => (v > 0 ? '+' : '') + v);
bindRange('treble', 'eq10k', (v) => (v > 0 ? '+' : '') + v);
bindToggle('voiceFilterToggle', 'voiceFilterEnabled');
$('#eqShowToggle').addEventListener('change', (e) => {
if (!suppressPush) pushState({ eqHidden: !e.target.checked });
});
['eq90', 'eq350', 'eq800', 'eq2k', 'eq7k', 'eq10k'].forEach((id) => {
bindRange(id, id, (v) => (v > 0 ? '+' : '') + v);
});
bindToggle('gateEnabled', 'gateEnabled');
bindRange('gateThreshold', 'gateThreshold', (v) => v + 'dB');
bindToggle('heavyEnabled', 'heavyEnabled');
bindRange('heavyDrive', 'heavyDrive', (v) => v.toFixed(0) + '/1000');
bindToggle('echoEnabled', 'echoEnabled');
bindRange('echoDelay', 'echoDelay', (v) => v.toFixed(0) + 'ms');
{ const mixEl = $('#echoMix'), mixVal = $('#echoMixVal');
mixEl.addEventListener('input', () => {
const v = parseFloat(mixEl.value);
mixVal.textContent = v.toFixed(0) + '%';
if (!suppressPush) pushState({ echoMix: v / 100 });
});
}
document.querySelectorAll('#modeGrid button').forEach((btn) => {
btn.addEventListener('click', () => {
withActiveTab((tabId) => {
chrome.tabs.sendMessage(tabId, { type: 'AMB_QUICK_MODE', name: btn.dataset.mode }, () => {
if (chrome.runtime.lastError) {  }
});
});
});
});
document.querySelectorAll('#voiceGrid button').forEach((btn) => {
btn.addEventListener('click', () => {
withActiveTab((tabId) => {
chrome.tabs.sendMessage(tabId, { type: 'AMB_QUICK_VOICE', name: btn.dataset.voice }, () => {
if (chrome.runtime.lastError) {  }
});
});
document.querySelectorAll('#voiceGrid button').forEach((b) => b.style.borderColor = (b === btn ? '#f0c14b' : ''));
});
});
function hydrateUI() {
suppressPush = true;
const boost = state.volumeBoost ?? 40;
$('#boost').value = boost; $('#boostVal').textContent = boost.toFixed(0) + 'x';
$('#autoGainToggle').checked = state.autoGainEnabled ?? false;
const bass = state.eq90 ?? 0;
$('#bass').value = bass; $('#bassVal').textContent = (bass > 0 ? '+' : '') + bass;
const treble = state.eq10k ?? 0;
$('#treble').value = treble; $('#trebleVal').textContent = (treble > 0 ? '+' : '') + treble;
$('#voiceFilterToggle').checked = state.voiceFilterEnabled ?? true;
$('#eqShowToggle').checked = !(state.eqHidden ?? false);
['eq90', 'eq350', 'eq800', 'eq2k', 'eq7k', 'eq10k'].forEach((id) => {
const v = state[id] ?? 0;
$('#' + id).value = v; $('#' + id + 'Val').textContent = (v > 0 ? '+' : '') + v;
});
$('#gateEnabled').checked = state.gateEnabled ?? false;
const gt = state.gateThreshold ?? -50;
$('#gateThreshold').value = gt; $('#gateThresholdVal').textContent = gt + 'dB';
$('#heavyEnabled').checked = state.heavyEnabled ?? true;
const hd = state.heavyDrive ?? 500;
$('#heavyDrive').value = hd; $('#heavyDriveVal').textContent = hd.toFixed(0) + '/1000';
$('#echoEnabled').checked = state.echoEnabled ?? false;
const ed = state.echoDelay ?? 260;
$('#echoDelay').value = ed; $('#echoDelayVal').textContent = ed.toFixed(0) + 'ms';
const em = Math.round((state.echoMix ?? 0.35) * 100);
$('#echoMix').value = em; $('#echoMixVal').textContent = em + '%';
suppressPush = false;
}
try {
chrome.storage.local.get(['ambState'], (res) => {
state = (res && res.ambState) || {};
hydrateUI();
});
} catch (_) { hydrateUI(); }
})();
