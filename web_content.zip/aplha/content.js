(async function () {
const NS = 'AMB';
if (window.top !== window.self) return;
try {
const s = document.createElement('script');
s.src = chrome.runtime.getURL('inject.js');
s.onload = () => s.remove();
(document.head || document.documentElement).appendChild(s);
} catch (e) {
console.error('[ALPHA] engine injection failed', e);
}
if (window.__ambPanelBuilt) return;
window.__ambPanelBuilt = true;
const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Cinzel:wght@600;800&family=Poppins:wght@400;600;700&display=swap');
:host{ all:initial; position:fixed; top:70px; right:12px; z-index:2147483647;
font-family:'Poppins','Segoe UI',system-ui,-apple-system,sans-serif; }
*{ box-sizing:border-box; }
.bubble{ display:none; width:52px;height:52px;border-radius:50%;
background:radial-gradient(circle at 35% 30%, #f0c14b, #6b4e17 75%); align-items:center; justify-content:center;
font-size:22px; cursor:pointer; color:#1a1408; border:1px solid #f0c14b99;
box-shadow:0 4px 18px rgba(240,193,75,.45); }
.card{ width:280px; border-radius:14px; position:relative; overflow:hidden;
background:#0b0906; border:1px solid #6b4e17; color:#f5e9c8;
box-shadow:0 14px 36px rgba(0,0,0,.7); }
.card::before{ content:''; position:absolute; inset:0; pointer-events:none;
background-image:url('${chrome.runtime.getURL('icons/icon512.png')}'); background-repeat:no-repeat; background-position:center 42%;
background-size:260px; opacity:0.07; z-index:0; }
.card > *{ position:relative; z-index:1; }
.panel-root.closed .card{ display:none; }
.panel-root.closed .bubble{ display:flex; }
.header{ display:flex; align-items:center; gap:6px; padding:11px; border-bottom:1px solid #4a3813;
cursor:grab; touch-action:none; background:linear-gradient(180deg,rgba(240,193,75,.12),transparent); }
.header .crown{ font-size:18px; }
.header .titles{ flex:1; min-width:0; }
.header h1{ margin:0; font-size:13.5px; letter-spacing:1.5px; color:#f0c14b; font-weight:800;
font-family:'Cinzel','Poppins',serif; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; text-transform:uppercase; }
.header .sub{ font-size:8px; color:#a9986c; letter-spacing:.6px; text-transform:uppercase; margin-top:1px; }
.icon-btn{ background:#151008; border:1px solid #4a3813; color:#f5e9c8; width:20px;height:20px;
border-radius:6px; cursor:pointer; font-size:10.5px; display:flex; align-items:center; justify-content:center; }
.icon-btn:hover{ border-color:#f0c14b; color:#f0c14b; }
.enable-switch, .switch{ position:relative; width:32px; height:17px; flex-shrink:0; }
.enable-switch input, .switch input{ opacity:0; width:0; height:0; }
.es-track, .st{ position:absolute; inset:0; background:#4a3813; border-radius:20px; cursor:pointer; transition:.2s; }
.es-track:before, .st:before{ content:""; position:absolute; height:13px; width:13px; left:2px; top:2px;
background:#d8cba3; border-radius:50%; transition:.2s; }
input:checked + .es-track, input:checked + .st{ background:#f0c14b; }
input:checked + .es-track:before, input:checked + .st:before{ transform:translateX(15px); background:#1a1408; }
.tabs{ display:flex; border-bottom:1px solid #4a3813; padding:0 2px; overflow-x:auto; }
.tab{ flex:1; text-align:center; padding:8px 2px; font-size:9px; color:#a9986c; cursor:pointer;
border-bottom:2px solid transparent; font-weight:700; font-family:'Cinzel','Poppins',serif; letter-spacing:.4px; white-space:nowrap; }
.godmenu-btn{ display:flex; align-items:center; gap:4px; background:linear-gradient(135deg,#f0c14b,#6b4e17);
border:1px solid #f0c14b; color:#1a1408; font-size:9px; font-weight:800; font-family:'Cinzel','Poppins',serif;
letter-spacing:.5px; padding:5px 8px; border-radius:7px; cursor:pointer; white-space:nowrap; text-transform:uppercase; }
.godmenu-btn:hover{ filter:brightness(1.08); }
.tab.active{ color:#f0c14b; border-bottom-color:#f0c14b; }
.body{ padding:11px 12px; max-height:360px; overflow-y:auto; }
.panel{ display:none; }
.panel.active{ display:block; }
.status{ display:flex; align-items:center; gap:6px; font-size:9.5px; color:#a9986c; margin-bottom:8px; }
.dot{ width:7px; height:7px; border-radius:50%; background:#5a4d2e; flex-shrink:0; }
.dot.active{ background:#4ade80; }
.dot.error{ background:#ff5b5b; }
.meter{ height:7px; background:#151008; border:1px solid #4a3813; border-radius:5px; overflow:hidden; margin-bottom:12px; }
.meter-fill{ height:100%; width:0%; background:linear-gradient(90deg,#f0c14b,#f5d97a,#fff2c2); transition:width .08s; }
.section-label{ font-size:9.5px; letter-spacing:1px; color:#f0c14b; font-weight:800; margin:10px 0 7px; text-transform:uppercase; }
.section-label:first-child{ margin-top:0; }
.modes{ display:grid; grid-template-columns:repeat(2,1fr); gap:6px; margin-bottom:6px; }
.modes button{ background:#151008; border:1px solid #4a3813; color:#f5e9c8; padding:8px 4px;
border-radius:7px; font-size:9.5px; cursor:pointer; font-weight:700; }
.modes button.active{ background:radial-gradient(circle at 35% 30%,#f0c14b,#6b4e17 75%); border-color:#f0c14b; color:#1a1408; }
.row{ margin-bottom:11px; }
.row label{ display:flex; justify-content:space-between; font-size:10px; color:#a9986c; margin-bottom:5px; }
.row label .val{ color:#f0c14b; font-weight:700; }
input[type=range]{ width:100%; accent-color:#f0c14b; }
.toggle-row{ display:flex; justify-content:space-between; align-items:center; margin-bottom:9px; font-size:10px; }
.eq-grid{ display:flex; justify-content:space-between; gap:5px; margin-bottom:6px; height:130px; }
.eq-band{ display:flex; flex-direction:column; align-items:center; flex:1; }
.eq-band input[type=range]{ writing-mode:vertical-lr; direction:rtl; width:5px; height:88px; accent-color:#f0c14b; }
.eq-band .lbl{ font-size:8px; color:#a9986c; margin-top:4px; }
.eq-band .v{ font-size:8px; color:#f0c14b; }
.eq-band .q{ font-size:7px; color:#6b6248; }
.test-btn{ width:100%; padding:8px; margin-top:4px; border-radius:7px; border:1px solid #4a3813;
background:#151008; color:#f5e9c8; font-size:10.5px; font-weight:700; cursor:pointer; }
.test-btn.on{ background:#f0c14b; border-color:#f0c14b; color:#1a1408; }
.reset-btn{ width:100%; padding:6px; border-radius:6px; border:1px solid #4a3813; background:#151008;
color:#a9986c; font-size:9px; cursor:pointer; margin-top:2px; }
.voice-grid{ display:flex; flex-direction:column; gap:5px; max-height:220px; overflow-y:auto; padding-right:2px; }
.voice-grid button{ display:flex; align-items:center; gap:9px; background:#151008; border:1px solid #4a3813; color:#f5e9c8;
padding:8px 10px; border-radius:8px; font-size:10.5px; cursor:pointer; font-weight:700; text-align:left; }
.voice-grid button .ic{ font-size:15px; flex-shrink:0; width:18px; text-align:center; }
.voice-grid button::after{ content:''; margin-left:auto; width:9px; height:9px; border-radius:50%; border:1px solid #4a3813; }
.voice-grid button.active{ border-color:#f0c14b; background:linear-gradient(90deg,rgba(240,193,75,.16),transparent); color:#f0c14b; }
.voice-grid button.active::after{ background:#f0c14b; border-color:#f0c14b; }
.about p{ font-size:10px; color:#a9986c; line-height:1.6; margin:0 0 8px; }
.about .brand{ color:#f0c14b; font-weight:800; letter-spacing:1px; }
.about code{ display:block; word-break:break-all; font-size:9px; background:#151008;
border:1px solid #4a3813; border-radius:6px; padding:6px; color:#f0c14b; margin-bottom:8px; }
`;
function buildPanel() {
const host = document.createElement('div');
host.id = 'amb-host';
(document.body || document.documentElement).appendChild(host);
const shadow = host.attachShadow({ mode: 'open' });
const style = document.createElement('style');
style.textContent = CSS;
shadow.appendChild(style);
const root = document.createElement('div');
root.className = 'panel-root closed';
root.innerHTML = `
<div class="bubble" id="bubble"><img src="${chrome.runtime.getURL('icons/icon48.png')}" alt="Alpha" style="width:30px;height:30px;display:block;border-radius:50%;"></div>
<div class="card">
<div class="header" id="dragHandle">
<div class="crown"><img src="${chrome.runtime.getURL('icons/icon48.png')}" style="width:20px;height:20px;display:block;" alt="Alpha"></div>
<div class="titles">
<h1>ALPHA</h1>
<div class="sub" id="statusSub">Mic Boost</div>
</div>
<button class="godmenu-btn" id="godMenuQuickBtn">&#128081; God Menu</button>
<label class="enable-switch">
<input type="checkbox" id="enableToggle" checked>
<span class="es-track"></span>
</label>
<div class="icon-btn" id="closeBtn">&#10005;</div>
</div>
<div class="quick-row" style="display:flex;gap:6px;padding:6px 10px;border-bottom:1px solid rgba(255,255,255,0.08);">
<label style="flex:1;display:flex;align-items:center;justify-content:space-between;gap:4px;font-size:9px;color:#e8dcc0;">
<span>&#128737;&#65039; Noise Cancel 300x</span>
<span class="switch"><input type="checkbox" id="ncQuickToggle"><span class="st"></span></span>
</label>
<label style="flex:1;display:flex;align-items:center;justify-content:space-between;gap:4px;font-size:9px;color:#e8dcc0;">
<span>&#127908; Append On My Voice</span>
<span class="switch"><input type="checkbox" id="ownVoiceQuickToggle"><span class="st"></span></span>
</label>
</div>
<div class="tabs">
<div class="tab active" data-tab="boost">BOOST</div>
<div class="tab" data-tab="eq">EQ</div>
<div class="tab" data-tab="voices">GOD MENU</div>
<div class="tab" data-tab="gate">GATE</div>
<div class="tab" data-tab="fx">FX</div>
<div class="tab" data-tab="about">ABOUT</div>
</div>
<div class="body">
<div class="status"><div class="dot" id="statusDot"></div><span id="statusText">Loaded — join a call to activate</span></div>
<div class="meter"><div class="meter-fill" id="meterFill"></div></div>
<div class="panel active" data-panel="boost">
<div class="section-label">Presets</div>
<div class="modes" id="modeGrid">
<button data-mode="Alpha Mode" style="grid-column:1 / span 2;">&#127925; Alpha Mode</button>
<button data-mode="Indoor">Indoor</button>
<button data-mode="Outdoor">Outdoor</button>
<button data-mode="Loudest">Loudest</button>
<button data-mode="God Level">God Level</button>
<button data-mode="King Mode" style="grid-column:1 / span 2;">&#128081; King Mode</button>
<button data-mode="Beast Mode" style="grid-column:1 / span 2;">&#128293; Beast Mode</button>
</div>
<div class="section-label">Volume Boost</div>
<div class="row">
<label>Boost <span class="val" id="boostVal">40x</span></label>
<input type="range" id="boost" min="0" max="2000" step="10">
</div>
<div class="row" style="align-items:center;">
<label>Auto Gain <span class="val" style="font-size:8px;color:#a9986c;">(auto-adjusts, ignores Boost slider)</span></label>
<label class="switch"><input type="checkbox" id="autoGainToggle"><span class="st"></span></label>
</div>
<div class="section-label">Bass &amp; Treble</div>
<div class="row">
<label>Bass <span class="val" id="bassVal">0</span></label>
<input type="range" id="bass" min="-12" max="12" step="1">
</div>
<div class="row">
<label>Treble <span class="val" id="trebleVal">0</span></label>
<input type="range" id="treble" min="-12" max="12" step="1">
</div>
<div class="toggle-row">
<span>Voice Filter</span>
<label class="switch"><input type="checkbox" id="voiceFilterToggle" checked><span class="st"></span></label>
</div>
<button class="test-btn" id="testBtn">&#128266; Test My Mic</button>
</div>
<div class="panel" data-panel="eq">
<div class="toggle-row">
<span>Show Equalizer</span>
<label class="switch"><input type="checkbox" id="eqShowToggle" checked><span class="st"></span></label>
</div>
<div id="eqWrap">
<div class="section-label">6-Band Hz Equalizer</div>
<div class="eq-grid">
<div class="eq-band"><input type="range" id="eq90" min="-12" max="12" step="1" orient="vertical"><span class="lbl">90</span><span class="v" id="eq90Val">0</span><span class="q">Q=0.8</span></div>
<div class="eq-band"><input type="range" id="eq350" min="-12" max="12" step="1" orient="vertical"><span class="lbl">350</span><span class="v" id="eq350Val">0</span><span class="q">Q=0.8</span></div>
<div class="eq-band"><input type="range" id="eq800" min="-12" max="12" step="1" orient="vertical"><span class="lbl">800</span><span class="v" id="eq800Val">0</span><span class="q">Q=0.8</span></div>
<div class="eq-band"><input type="range" id="eq2k" min="-12" max="12" step="1" orient="vertical"><span class="lbl">2000</span><span class="v" id="eq2kVal">0</span><span class="q">Q=0.8</span></div>
<div class="eq-band"><input type="range" id="eq7k" min="-12" max="12" step="1" orient="vertical"><span class="lbl">7000</span><span class="v" id="eq7kVal">0</span><span class="q">Q=0.8</span></div>
<div class="eq-band"><input type="range" id="eq10k" min="-12" max="12" step="1" orient="vertical"><span class="lbl">10000</span><span class="v" id="eq10kVal">0</span><span class="q">Q=0.8</span></div>
</div>
<button class="reset-btn" id="eqResetBtn">Reset EQ</button>
</div>
</div>
<div class="panel" data-panel="voices">
<div class="section-label">God Menu — pick one</div>
<div class="voice-grid" id="voiceGrid">
<button data-voice="Alien"><span class="ic">&#128308;</span>Alien</button>
<button data-voice="Baby"><span class="ic">&#128118;</span>Baby Pitch</button>
<button data-voice="Female"><span class="ic">&#128105;</span>Female Pitch</button>
<button data-voice="Male"><span class="ic">&#128104;</span>Male Pitch</button>
<button data-voice="Robot"><span class="ic">&#129302;</span>Robot</button>
<button data-voice="Helium"><span class="ic">&#128063;&#65039;</span>Helium / High</button>
<button data-voice="Monster"><span class="ic">&#128121;</span>Mutation</button>
<button data-voice="CustomPitch"><span class="ic">&#127925;</span>Custom Pitch</button>
<button data-voice="Radio"><span class="ic">&#128241;</span>Radio</button>
<button data-voice="EchoVoice"><span class="ic">&#127744;</span>Echo</button>
</div>
<button id="customComboBtn" class="test-btn" style="margin-top:8px;">&#10024; Custom Combo</button>
<div id="customComboPanel" style="display:none;margin-top:8px;">
<div class="section-label">Custom Combo (up to 4 layers)</div>
<div class="toggle-row"><span>1. Ring Modulator</span><label class="switch"><input type="checkbox" id="ringOverrideToggle"><span class="st"></span></label></div>
<div class="toggle-row"><span>2. Radio Bandpass</span><label class="switch"><input type="checkbox" id="bandpassOverrideToggle"><span class="st"></span></label></div>
<div class="toggle-row"><span>3. Heavy / Distortion</span><label class="switch"><input type="checkbox" id="comboHeavyToggle"><span class="st"></span></label></div>
<div class="toggle-row"><span>4. Pitch Shift</span><label class="switch"><input type="checkbox" id="comboPitchToggle"><span class="st"></span></label></div>
<div class="row"><label>Pitch <span class="val" id="comboPitchVal">0 st</span></label><input type="range" id="comboPitch" min="-12" max="12" step="1"></div>
</div>
</div>
<div class="panel" data-panel="gate">
<div class="section-label">Noise Gate</div>
<div class="toggle-row">
<span>Enable Gate</span>
<label class="switch"><input type="checkbox" id="gateEnabled"><span class="st"></span></label>
</div>
<div class="row">
<label>Threshold <span class="val" id="gateThresholdVal">-50dB</span></label>
<input type="range" id="gateThreshold" min="-70" max="-20" step="1">
</div>
</div>
<div class="panel" data-panel="fx">
<div class="section-label">Distortion</div>
<div class="toggle-row">
<span>Enable</span>
<label class="switch"><input type="checkbox" id="heavyEnabled" checked><span class="st"></span></label>
</div>
<div class="row">
<label>Drive <span class="val" id="heavyDriveVal">500/1000</span></label>
<input type="range" id="heavyDrive" min="0" max="1000" step="10">
</div>
<div class="section-label">Echo</div>
<div class="toggle-row">
<span>Enable</span>
<label class="switch"><input type="checkbox" id="echoEnabled"><span class="st"></span></label>
</div>
<div class="row">
<label>Delay <span class="val" id="echoDelayVal">260ms</span></label>
<input type="range" id="echoDelay" min="50" max="8000" step="50">
</div>
<div class="row">
<label>Feedback <span class="val" id="echoFeedbackVal">30%</span></label>
<input type="range" id="echoFeedback" min="0" max="70" step="1">
</div>
<div class="row">
<label>Mix <span class="val" id="echoMixVal">35%</span></label>
<input type="range" id="echoMix" min="0" max="100" step="1">
</div>
<div class="section-label">Custom Pitch</div>
<div class="toggle-row">
<span>Enable</span>
<label class="switch"><input type="checkbox" id="pitchEnabled"><span class="st"></span></label>
</div>
<div class="row">
<label>Semitones <span class="val" id="pitchSemitonesVal">-4 st</span></label>
<input type="range" id="pitchSemitones" min="-12" max="12" step="1">
</div>
</div>
<div class="panel" data-panel="about">
<div class="about">
<p><span class="brand">&#128081; ALPHA MIC BOOST</span><br>Mobile Ready — Local Control</p>
<p>Volume boost, 6-band Hz equalizer, noise gate, distortion, echo and a 5-voice voice changer for Discord, Instagram and WhatsApp Web.</p>
<p>Device ID:</p>
<code id="aboutDeviceId">…</code>
<p>Status: <span id="aboutStatus">Ready</span></p>
</div>
</div>
</div>
</div>
`;
shadow.appendChild(root);
const $ = (sel) => shadow.querySelector(sel);
let state = {};
let suppressPush = false;
let testing = false;
function pushState(partial) {
state = Object.assign({}, state, partial);
try {
chrome.storage.local.set({ ambState: state });
} catch (_) {}
window.postMessage({ type: 'AMB_SET_STATE', value: partial }, '*');
}
function bindRange(id, key, fmt) {
const el = $('#' + id), valEl = $('#' + id + 'Val');
el.addEventListener('input', () => {
const v = parseFloat(el.value);
if (valEl) valEl.textContent = fmt(v);
if (!suppressPush) pushState({ [key]: v });
});
}
function bindToggle(id, key) {
$('#' + id).addEventListener('change', (e) => { if (!suppressPush) pushState({ [key]: e.target.checked }); });
}
shadow.querySelectorAll('.tab').forEach((tab) => {
tab.addEventListener('click', () => {
shadow.querySelectorAll('.tab').forEach((t) => t.classList.remove('active'));
shadow.querySelectorAll('.panel').forEach((p) => p.classList.remove('active'));
tab.classList.add('active');
$(`.panel[data-panel="${tab.dataset.tab}"]`).classList.add('active');
});
});
bindRange('boost', 'volumeBoost', (v) => v.toFixed(0) + 'x');
bindToggle('autoGainToggle', 'autoGainEnabled');
bindToggle('ncQuickToggle', 'noiseCancelEnabled');
bindToggle('ownVoiceQuickToggle', 'ownVoiceEnabled');
bindToggle('ringOverrideToggle', 'ringOverride');
bindToggle('bandpassOverrideToggle', 'bandpassOverride');
bindToggle('comboHeavyToggle', 'heavyEnabled');
bindToggle('comboPitchToggle', 'pitchEnabled');
bindRange('comboPitch', 'pitchSemitones', (v) => (v > 0 ? '+' : '') + v + ' st');
$('#customComboBtn').addEventListener('click', () => {
const panel = $('#customComboPanel');
const showing = panel.style.display !== 'none';
panel.style.display = showing ? 'none' : '';
if (!showing) { pushState({ voicePreset: 'Custom' }); highlightVoice('Custom'); }
});
bindRange('bass', 'eq90', (v) => (v > 0 ? '+' : '') + v);
bindRange('treble', 'eq10k', (v) => (v > 0 ? '+' : '') + v);
bindToggle('voiceFilterToggle', 'voiceFilterEnabled');
$('#eqShowToggle').addEventListener('change', (e) => {
$('#eqWrap').style.display = e.target.checked ? '' : 'none';
if (!suppressPush) pushState({ eqHidden: !e.target.checked });
});
shadow.querySelectorAll('#modeGrid button').forEach((btn) => {
btn.addEventListener('click', () => {
window.postMessage({ type: 'AMB_APPLY_MODE', name: btn.dataset.mode }, '*');
highlightMode(btn.dataset.mode);
});
});
function highlightMode(name) {
shadow.querySelectorAll('#modeGrid button').forEach((b) => b.classList.toggle('active', b.dataset.mode === name));
}
shadow.querySelectorAll('#voiceGrid button').forEach((btn) => {
btn.addEventListener('click', () => {
window.postMessage({ type: 'AMB_APPLY_VOICE', name: btn.dataset.voice }, '*');
highlightVoice(btn.dataset.voice);
});
});
function highlightVoice(name) {
shadow.querySelectorAll('#voiceGrid button').forEach((b) => b.classList.toggle('active', b.dataset.voice === name));
}
['eq90', 'eq350', 'eq800', 'eq2k', 'eq7k', 'eq10k'].forEach((id) => {
bindRange(id, id, (v) => (v > 0 ? '+' : '') + v);
});
$('#eqResetBtn').addEventListener('click', () => {
['eq90', 'eq350', 'eq800', 'eq2k', 'eq7k', 'eq10k'].forEach((id) => {
$('#' + id).value = 0;
$('#' + id + 'Val').textContent = '0';
});
$('#bass').value = 0; $('#bassVal').textContent = '0';
$('#treble').value = 0; $('#trebleVal').textContent = '0';
pushState({ eq90: 0, eq350: 0, eq800: 0, eq2k: 0, eq7k: 0, eq10k: 0 });
});
bindToggle('gateEnabled', 'gateEnabled');
bindRange('gateThreshold', 'gateThreshold', (v) => v + 'dB');
bindToggle('heavyEnabled', 'heavyEnabled');
bindRange('heavyDrive', 'heavyDrive', (v) => v.toFixed(0) + '/1000');
bindToggle('echoEnabled', 'echoEnabled');
bindRange('echoDelay', 'echoDelay', (v) => v.toFixed(0) + 'ms');
{ const fbEl = $('#echoFeedback'), fbVal = $('#echoFeedbackVal');
fbEl.addEventListener('input', () => {
const v = parseFloat(fbEl.value);
fbVal.textContent = v.toFixed(0) + '%';
if (!suppressPush) pushState({ echoFeedback: v / 100 });
});
const mixEl = $('#echoMix'), mixVal = $('#echoMixVal');
mixEl.addEventListener('input', () => {
const v = parseFloat(mixEl.value);
mixVal.textContent = v.toFixed(0) + '%';
if (!suppressPush) pushState({ echoMix: v / 100 });
});
}
bindToggle('pitchEnabled', 'pitchEnabled');
bindRange('pitchSemitones', 'pitchSemitones', (v) => v.toFixed(0) + ' st');
$('#enableToggle').addEventListener('change', (e) => {
pushState({ enabled: e.target.checked });
$('#statusSub').textContent = e.target.checked ? 'Mic Boost' : 'Bypassed';
});
$('#testBtn').addEventListener('click', () => {
testing = !testing;
$('#testBtn').classList.toggle('on', testing);
$('#testBtn').textContent = testing ? '\u23F9 Stop Test' : '\uD83D\uDD0A Test My Mic';
window.postMessage({ type: testing ? 'AMB_START_TEST' : 'AMB_STOP_TEST' }, '*');
});
function setPanelClosed(isClosed) {
root.classList.toggle('closed', isClosed);
try { chrome.storage.local.set({ ambPanelClosed: isClosed }); } catch (_) {}
}
$('#closeBtn').addEventListener('click', () => setPanelClosed(true));
$('#bubble').addEventListener('click', () => setPanelClosed(false));
$('#godMenuQuickBtn').addEventListener('click', () => {
setPanelClosed(false);
shadow.querySelectorAll('.tab').forEach((t) => t.classList.remove('active'));
shadow.querySelectorAll('.panel').forEach((p) => p.classList.remove('active'));
const voicesTab = shadow.querySelector('.tab[data-tab="voices"]');
voicesTab.classList.add('active');
$('.panel[data-panel="voices"]').classList.add('active');
});
(function makeDraggable() {
const handle = $('#dragHandle');
let dragging = false, offX = 0, offY = 0;
handle.addEventListener('pointerdown', (e) => {
dragging = true;
const rect = host.getBoundingClientRect();
offX = e.clientX - rect.left;
offY = e.clientY - rect.top;
handle.setPointerCapture(e.pointerId);
});
handle.addEventListener('pointermove', (e) => {
if (!dragging) return;
host.style.left = (e.clientX - offX) + 'px';
host.style.top = (e.clientY - offY) + 'px';
host.style.right = 'auto';
});
handle.addEventListener('pointerup', () => { dragging = false; });
})();
function hydrateUI() {
suppressPush = true;
const boost = state.volumeBoost ?? 40;
$('#boost').value = boost; $('#boostVal').textContent = boost.toFixed(0) + 'x';
$('#autoGainToggle').checked = state.autoGainEnabled ?? false;
const bass = state.eq90 ?? 0;
$('#bass').value = bass; $('#bassVal').textContent = (bass > 0 ? '+' : '') + bass;
const treble = state.eq10k ?? 0;
$('#treble').value = treble; $('#trebleVal').textContent = (treble > 0 ? '+' : '') + treble;
$('#voiceFilterToggle').checked = state.voiceFilterEnabled ?? true;
const eqShown = !(state.eqHidden ?? false);
$('#eqShowToggle').checked = eqShown;
$('#eqWrap').style.display = eqShown ? '' : 'none';
['eq90', 'eq350', 'eq800', 'eq2k', 'eq7k', 'eq10k'].forEach((id) => {
const v = state[id] ?? 0;
$('#' + id).value = v; $('#' + id + 'Val').textContent = (v > 0 ? '+' : '') + v;
});
if (state.voicePreset) highlightVoice(state.voicePreset);
$('#gateEnabled').checked = state.gateEnabled ?? false;
const gt = state.gateThreshold ?? -50;
$('#gateThreshold').value = gt; $('#gateThresholdVal').textContent = gt + 'dB';
$('#heavyEnabled').checked = state.heavyEnabled ?? true;
const hd = state.heavyDrive ?? 500;
$('#heavyDrive').value = hd; $('#heavyDriveVal').textContent = hd.toFixed(0) + '/1000';
$('#echoEnabled').checked = state.echoEnabled ?? false;
const ed = state.echoDelay ?? 260;
$('#echoDelay').value = ed; $('#echoDelayVal').textContent = ed.toFixed(0) + 'ms';
const ef = Math.round((state.echoFeedback ?? 0.3) * 100);
$('#echoFeedback').value = ef; $('#echoFeedbackVal').textContent = ef + '%';
const em = Math.round((state.echoMix ?? 0.35) * 100);
$('#echoMix').value = em; $('#echoMixVal').textContent = em + '%';
$('#pitchEnabled').checked = state.pitchEnabled ?? false;
const ps = state.pitchSemitones ?? -4;
$('#pitchSemitones').value = ps; $('#pitchSemitonesVal').textContent = ps.toFixed(0) + ' st';
$('#ncQuickToggle').checked = state.noiseCancelEnabled ?? false;
$('#ownVoiceQuickToggle').checked = state.ownVoiceEnabled ?? false;
$('#ringOverrideToggle').checked = state.ringOverride ?? false;
$('#bandpassOverrideToggle').checked = state.bandpassOverride ?? false;
$('#comboHeavyToggle').checked = state.heavyEnabled ?? true;
$('#comboPitchToggle').checked = state.pitchEnabled ?? false;
$('#comboPitch').value = ps; $('#comboPitchVal').textContent = (ps > 0 ? '+' : '') + ps + ' st';
$('#customComboPanel').style.display = (state.voicePreset === 'Custom') ? '' : 'none';
$('#enableToggle').checked = state.enabled ?? true;
$('#statusSub').textContent = (state.enabled ?? true) ? 'Mic Boost' : 'Bypassed';
if (state.mode) highlightMode(state.mode);
suppressPush = false;
}
$('#aboutDeviceId').textContent = license.deviceId;
$('#aboutStatus').textContent = license.status === 'approved' ? 'Approved \u2705' : license.status;
try {
chrome.storage.local.get(['ambState', 'ambPanelClosed'], (res) => {
state = (res && res.ambState) || {};
hydrateUI();
const wasClosed = res && res.ambPanelClosed;
root.classList.toggle('closed', wasClosed !== false);
});
} catch (_) { hydrateUI(); }
window.addEventListener('message', (event) => {
if (event.source !== window || !event.data) return;
const d = event.data;
if (d.type === 'AMB_LEVEL') $('#meterFill').style.width = d.level + '%';
if (d.type === 'AMB_PONG') {
if (d.hooked) {
$('#statusDot').classList.remove('error'); $('#statusDot').classList.add('active');
$('#statusText').textContent = 'Live — boost active';
} else {
$('#statusText').textContent = 'Loaded — join a call to activate';
}
}
if (d.type === 'AMB_HOOKED') {
$('#statusDot').classList.remove('error'); $('#statusDot').classList.add('active');
$('#statusText').textContent = 'Live — boost active';
}
if (d.type === 'AMB_ERROR') {
$('#statusDot').classList.add('error'); $('#statusText').textContent = 'Error: ' + d.message;
}
if (d.type === 'AMB_STATE_SYNC') { state = d.value; hydrateUI(); }
});
window.postMessage({ type: 'AMB_PING' }, '*');
window.postMessage({ type: 'AMB_GET_STATE' }, '*');
try {
chrome.runtime.onMessage.addListener((msg) => {
if (msg && msg.type === 'AMB_TOGGLE_PANEL') setPanelClosed(!root.classList.contains('closed'));
if (msg && msg.type === 'AMB_OPEN_GOD_MENU') $('#godMenuQuickBtn').click();
if (msg && msg.type === 'AMB_QUICK_VOICE') {
window.postMessage({ type: 'AMB_APPLY_VOICE', name: msg.name }, '*');
highlightVoice(msg.name);
setPanelClosed(false);
}
if (msg && msg.type === 'AMB_QUICK_SET') {
pushState(msg.value || {});
hydrateUI();
}
if (msg && msg.type === 'AMB_QUICK_MODE') {
window.postMessage({ type: 'AMB_APPLY_MODE', name: msg.name }, '*');
highlightMode(msg.name);
}
});
} catch (_) {}
}
buildPanel();
})();
