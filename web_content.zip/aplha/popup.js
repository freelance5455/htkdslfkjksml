(async function () {
const dot = document.getElementById('statusDot');
const label = document.getElementById('statusLabel');
const codeEl = document.getElementById('deviceId');
const deviceId = await ALPHA_LICENSE.getDeviceId();
codeEl.textContent = deviceId;
dot.classList.add('approved');
label.textContent = 'Ready';

const copyBtn = document.getElementById('copyBtn');
copyBtn.addEventListener('click', () => {
  navigator.clipboard.writeText(deviceId).then(() => {
    const previous = copyBtn.textContent;
    copyBtn.textContent = 'Copied!';
    setTimeout(() => (copyBtn.textContent = previous), 1200);
  });
});

function withActiveTab(cb) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs && tabs[0]) cb(tabs[0].id);
  });
}

document.getElementById('toggleBtn').addEventListener('click', () => {
  withActiveTab((tabId) => {
    chrome.tabs.sendMessage(tabId, { type: 'AMB_TOGGLE_PANEL' }, () => {
      if (chrome.runtime.lastError) { }
    });
  });
});

document.getElementById('godMenuBtn').addEventListener('click', () => {
  withActiveTab((tabId) => {
    chrome.tabs.sendMessage(tabId, { type: 'AMB_OPEN_GOD_MENU' }, () => {
      if (chrome.runtime.lastError) { }
    });
  });
});

document.getElementById('voicesBtn').addEventListener('click', () => {
  const voices = ['None', 'Deep', 'Chipmunk', 'Robot', 'Monster', 'Radio'];
  const choice = prompt('Quick Voice Picker — type one of:\n' + voices.join(', '), 'None');
  if (choice && voices.includes(choice)) {
    withActiveTab((tabId) => {
      chrome.tabs.sendMessage(tabId, { type: 'AMB_QUICK_VOICE', name: choice }, () => {
        if (chrome.runtime.lastError) { }
      });
    });
  }
});

document.getElementById('settingsBtn').addEventListener('click', () => {
  chrome.runtime.openOptionsPage();
});
})();
