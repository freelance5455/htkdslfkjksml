(function () {
if (window.__AMB_ENGINE__) return;
window.__AMB_ENGINE__ = true;
const NS = 'AMB';
const DEFAULT_STATE = {
enabled: true,
voiceFilterEnabled: true,
volumeBoost: 40,
autoGainEnabled: false,
noiseCancelEnabled: false,
ownVoiceEnabled: false,
ringOverride: false,
bandpassOverride: false,
disableAGC: true,
disableNS: false,
eq90: 0, eq350: 0, eq800: 0, eq2k: 0, eq7k: 0, eq10k: 0,
eqHidden: false,
gateEnabled: false,
gateThreshold: -50,
mode: null,
heavyEnabled: true,
heavyDrive: 500,
echoEnabled: false,
echoDelay: 260,
echoFeedback: 0.3,
echoMix: 0.35,
pitchEnabled: false,
pitchSemitones: -4,
voicePreset: 'None',
ringFreq: 30,
bandpassFreq: 1200,
};
const VOICE_PRESETS = {
None:     { pitchEnabled: false, pitchSemitones: 0,  ring: false, bandpass: false },
Deep:     { pitchEnabled: true,  pitchSemitones: -6, ring: false, bandpass: false },
Chipmunk: { pitchEnabled: true,  pitchSemitones: 7,  ring: false, bandpass: false },
Robot:    { pitchEnabled: false, pitchSemitones: 0,  ring: true,  bandpass: false, ringFreq: 35, heavyEnabled: true, heavyDrive: 120, volumeBoost: 300 },
Monster:  { pitchEnabled: true,  pitchSemitones: -9, ring: false, bandpass: false, heavyEnabled: true, heavyDrive: 400, echoEnabled: true, echoMix: 0.25, echoDelay: 180, volumeBoost: 300 },
Radio:    { pitchEnabled: false, pitchSemitones: 0,  ring: false, bandpass: true, bandpassFreq: 1200, heavyEnabled: true, heavyDrive: 200, volumeBoost: 300 },
Alien:    { pitchEnabled: true,  pitchSemitones: 4,  ring: true,  bandpass: false, ringFreq: 55, heavyEnabled: false, volumeBoost: 300 },
Baby:     { pitchEnabled: true,  pitchSemitones: 10, ring: false, bandpass: false, heavyEnabled: false, volumeBoost: 300 },
Female:   { pitchEnabled: true,  pitchSemitones: 3,  ring: false, bandpass: false, heavyEnabled: false, volumeBoost: 300 },
Male:     { pitchEnabled: true,  pitchSemitones: -3, ring: false, bandpass: false, heavyEnabled: true, heavyDrive: 150, volumeBoost: 300 },
Helium:   { pitchEnabled: true,  pitchSemitones: 9,  ring: false, bandpass: false, heavyEnabled: false, volumeBoost: 300 },
CustomPitch: { pitchEnabled: true, pitchSemitones: 0, ring: false, bandpass: false, volumeBoost: 300 },
EchoVoice: { pitchEnabled: false, pitchSemitones: 0, ring: false, bandpass: false, echoEnabled: true, echoMix: 0.35, echoDelay: 280, echoFeedback: 0.3, volumeBoost: 300 },
};
let state = { ...DEFAULT_STATE };
let ctx = null;
let chains = [];
let testChain = null;
function dbToGain(db) { return Math.pow(10, db / 20); }
function boostToGain(v) { return 1 + (Math.max(0, Math.min(2000, v)) / 2000) * 1999; }
function semitonesToRatio(s) { return Math.pow(2, s / 12); }
function ensureCtx() {
if (!ctx) {
const AC = window.AudioContext || window.webkitAudioContext;
ctx = new AC();
}
if (ctx.state === 'suspended') ctx.resume().catch(() => {});
return ctx;
}
function buildEqBand(context, freq, type, q) {
const f = context.createBiquadFilter();
f.type = type;
f.frequency.value = freq;
if (type === 'peaking') f.Q.value = q || 0.8;
f.gain.value = 0;
return f;
}
function buildHeavy(context) {
const shaper = context.createWaveShaper();
shaper.oversample = '2x';
shaper._setDrive = function (drive01) {
const n = 1024;
const curve = new Float32Array(n);
const k = drive01 * 180;
for (let i = 0; i < n; i++) {
const x = (i / (n - 1)) * 2 - 1;
curve[i] = k === 0 ? x : ((1 + k) * x) / (1 + k * Math.abs(x));
}
shaper.curve = curve;
};
shaper._setDrive(0);
const subBass = buildEqBand(context, 90, 'lowshelf');
shaper.connect(subBass);
const makeup = context.createGain();
makeup.gain.value = 1;
subBass.connect(makeup);
return { input: shaper, output: makeup, shaper, subBass, makeup };
}
function buildPitchShifter(context) {
const bufferSize = 2048;
const node = context.createScriptProcessor(bufferSize, 1, 1);
const ringSize = 16384;
const ring = new Float32Array(ringSize);
let writeIdx = 0;
const grain = 2048;
let readA = 0;
let readB = grain / 2;
node._ratio = 1;
function hann(pos) { return 0.5 - 0.5 * Math.cos(2 * Math.PI * pos); }
node.onaudioprocess = (e) => {
const input = e.inputBuffer.getChannelData(0);
const output = e.outputBuffer.getChannelData(0);
const ratio = node._ratio;
for (let i = 0; i < input.length; i++) {
ring[writeIdx] = input[i];
writeIdx = (writeIdx + 1) % ringSize;
const ia = Math.floor(readA) % ringSize;
const ib = Math.floor(readB) % ringSize;
const posA = (readA % grain) / grain;
const posB = (readB % grain) / grain;
const wa = hann(posA);
const wb = hann(posB);
const norm = wa + wb || 1;
output[i] = (ring[ia] * wa + ring[ib] * wb) / norm;
readA += ratio; if (readA >= ringSize) readA -= ringSize;
readB += ratio; if (readB >= ringSize) readB -= ringSize;
}
};
return node;
}
function buildGate(context) {
const bufferSize = 1024;
const node = context.createScriptProcessor(bufferSize, 1, 1);
node._gateEnabled = false;
node._thresholdDb = -50;
node._envelope = 0;
node.onaudioprocess = (e) => {
const input = e.inputBuffer.getChannelData(0);
const output = e.outputBuffer.getChannelData(0);
if (!node._gateEnabled) { output.set(input); return; }
const thresholdLinear = dbToGain(node._thresholdDb);
for (let i = 0; i < input.length; i++) {
const s = input[i];
node._envelope = Math.max(Math.abs(s), node._envelope * 0.995);
const open = node._envelope > thresholdLinear;
output[i] = open ? s : s * 0.05;
}
};
return node;
}
function applyStateToChain(chain) {
if (!chain) return;
const on = state.enabled;
const fxOn = on && state.voiceFilterEnabled;
const t = ctx.currentTime;
if (!state.autoGainEnabled) {
chain.gainNode.gain.setTargetAtTime(on ? boostToGain(state.volumeBoost) : 1, t, 0.05);
}
chain.eq90.gain.setTargetAtTime(fxOn ? state.eq90 : 0, t, 0.05);
chain.eq350.gain.setTargetAtTime(fxOn ? state.eq350 : 0, t, 0.05);
chain.eq800.gain.setTargetAtTime(fxOn ? state.eq800 : 0, t, 0.05);
chain.eq2k.gain.setTargetAtTime(fxOn ? state.eq2k : 0, t, 0.05);
chain.eq7k.gain.setTargetAtTime(fxOn ? state.eq7k : 0, t, 0.05);
chain.eq10k.gain.setTargetAtTime(fxOn ? state.eq10k : 0, t, 0.05);
const heavyOn = fxOn && state.heavyEnabled;
const heavyDrive01 = state.heavyDrive / 100;
chain.heavy.shaper._setDrive(heavyOn ? heavyDrive01 : 0);
chain.heavy.subBass.gain.setTargetAtTime(heavyOn ? 9 : 0, t, 0.05);
chain.heavy.makeup.gain.setTargetAtTime(heavyOn ? 1 + Math.min(heavyDrive01, 10) * 0.15 : 1, t, 0.05);
const pitchOn = fxOn && state.pitchEnabled;
chain.pitchNode._ratio = semitonesToRatio(state.pitchSemitones);
chain.pitchDry.gain.setTargetAtTime(pitchOn ? 0 : 1, t, 0.03);
chain.pitchWet.gain.setTargetAtTime(pitchOn ? 1 : 0, t, 0.03);
const preset = VOICE_PRESETS[state.voicePreset] || VOICE_PRESETS.None;
const customMode = state.voicePreset === 'Custom';
const ringOn = fxOn && (customMode ? !!state.ringOverride : !!preset.ring);
const bpOn = fxOn && (customMode ? !!state.bandpassOverride : !!preset.bandpass);
chain.ringOsc.frequency.setTargetAtTime(state.ringFreq || 30, t, 0.05);
chain.bandpass.frequency.setTargetAtTime(state.bandpassFreq || 1200, t, 0.05);
chain.voiceDry.gain.setTargetAtTime(ringOn || bpOn ? 0 : 1, t, 0.03);
chain.voiceRingWet.gain.setTargetAtTime(ringOn ? 1 : 0, t, 0.03);
chain.voiceBpWet.gain.setTargetAtTime(bpOn ? 1 : 0, t, 0.03);
const echoOn = fxOn && state.echoEnabled;
chain.echoDelay.delayTime.setTargetAtTime(Math.max(0.01, state.echoDelay / 1000), t, 0.05);
chain.echoFeedback.gain.setTargetAtTime(echoOn ? state.echoFeedback : 0, t, 0.05);
chain.echoWet.gain.setTargetAtTime(echoOn ? state.echoMix : 0, t, 0.05);
chain.gate._gateEnabled = (on && state.gateEnabled) || state.noiseCancelEnabled;
chain.gate._thresholdDb = state.noiseCancelEnabled ? -30 : state.gateThreshold;



chain.ncGain.gain.setTargetAtTime(state.noiseCancelEnabled ? boostToGain(300) : 1, t, 0.05);
chain.ownVoiceEq.gain.setTargetAtTime(state.ownVoiceEnabled ? 5 : 0, t, 0.05);
}
function buildChain(sourceStream) {
const context = ensureCtx();
const source = context.createMediaStreamSource(sourceStream);
const ncGain = context.createGain();
const gainNode = context.createGain();
const eq90  = buildEqBand(context, 90, 'lowshelf');
const eq350 = buildEqBand(context, 350, 'peaking', 0.8);
const eq800 = buildEqBand(context, 800, 'peaking', 0.8);
const eq2k  = buildEqBand(context, 2000, 'peaking', 0.8);
const eq7k  = buildEqBand(context, 7000, 'peaking', 0.8);
const eq10k = buildEqBand(context, 10000, 'highshelf');
const heavy = buildHeavy(context);
const pitchIn = context.createGain();
const pitchDry = context.createGain();
const pitchWet = context.createGain();
const pitchOut = context.createGain();
const pitchNode = buildPitchShifter(context);
pitchIn.connect(pitchDry); pitchDry.connect(pitchOut);
pitchIn.connect(pitchNode); pitchNode.connect(pitchWet); pitchWet.connect(pitchOut);
const voiceIn = context.createGain();
const voiceOut = context.createGain();
const voiceDry = context.createGain();
voiceIn.connect(voiceDry); voiceDry.connect(voiceOut);
const ringGain = context.createGain();
ringGain.gain.value = 0;
const ringOsc = context.createOscillator();
ringOsc.type = 'sine';
ringOsc.frequency.value = 30;
ringOsc.connect(ringGain.gain);
const voiceRingWet = context.createGain();
voiceIn.connect(ringGain); ringGain.connect(voiceRingWet); voiceRingWet.connect(voiceOut);
try { ringOsc.start(); } catch (_) {}
const bandpass = context.createBiquadFilter();
bandpass.type = 'bandpass';
bandpass.frequency.value = 1200;
bandpass.Q.value = 1.1;
const voiceBpWet = context.createGain();
voiceIn.connect(bandpass); bandpass.connect(voiceBpWet); voiceBpWet.connect(voiceOut);
const echoIn = context.createGain();
const echoOut = context.createGain();
const echoDelay = context.createDelay(8.0);
const echoFeedback = context.createGain();
const echoWet = context.createGain();
echoIn.connect(echoOut);
echoIn.connect(echoDelay);
echoDelay.connect(echoFeedback);
echoFeedback.connect(echoDelay);
echoDelay.connect(echoWet);
echoWet.connect(echoOut);
const gate = buildGate(context);
const ownVoiceEq = context.createBiquadFilter();
ownVoiceEq.type = 'peaking';
ownVoiceEq.frequency.value = 3000;
ownVoiceEq.Q.value = 1;
ownVoiceEq.gain.value = 0;
const limiter = context.createDynamicsCompressor();
limiter.threshold.value = -12;
limiter.knee.value = 10;
limiter.ratio.value = 20;
limiter.attack.value = 0.001;
limiter.release.value = 0.15;
const analyser = context.createAnalyser();
analyser.fftSize = 512;
const dest = context.createMediaStreamDestination();
source.connect(ncGain);
ncGain.connect(gainNode);
gainNode.connect(eq90);
eq90.connect(eq350);
eq350.connect(eq800);
eq800.connect(eq2k);
eq2k.connect(eq7k);
eq7k.connect(eq10k);
eq10k.connect(heavy.input);
heavy.output.connect(pitchIn);
pitchOut.connect(voiceIn);
voiceOut.connect(echoIn);
echoOut.connect(gate);
gate.connect(ownVoiceEq);
ownVoiceEq.connect(limiter);
limiter.connect(analyser);
analyser.connect(dest);
const chain = {
source, ncGain, gainNode, eq90, eq350, eq800, eq2k, eq7k, eq10k,
heavy, pitchIn, pitchDry, pitchWet, pitchOut, pitchNode,
voiceIn, voiceOut, voiceDry, ringGain, ringOsc, voiceRingWet, bandpass, voiceBpWet,
echoIn, echoOut, echoDelay, echoFeedback, echoWet,
gate, ownVoiceEq, limiter, analyser, dest, sourceStream,
};
applyStateToChain(chain);
return chain;
}
function meterLoop() {
const active = chains[chains.length - 1] || testChain;
if (active && active.analyser) {
const data = new Uint8Array(active.analyser.fftSize);
active.analyser.getByteTimeDomainData(data);
let sum = 0;
for (let i = 0; i < data.length; i++) { const v = (data[i] - 128) / 128; sum += v * v; }
const rms = Math.sqrt(sum / data.length);
const level = Math.min(100, Math.round(rms * 260));
window.postMessage({ type: NS + '_LEVEL', level }, '*');
if (state.autoGainEnabled && state.enabled && active.gainNode) {
const targetRms = 0.3;
const minGain = 1, maxGain = 2000;
if (rms > 0.001) {
const currentGain = active._autoGainValue || active.gainNode.gain.value || 1;
let desired = currentGain * (targetRms / rms);
desired = Math.max(minGain, Math.min(maxGain, desired));
const smoothed = currentGain + (desired - currentGain) * 0.04;
active._autoGainValue = smoothed;
active.gainNode.gain.setTargetAtTime(smoothed, ctx.currentTime, 0.15);
}
}
}
requestAnimationFrame(meterLoop);
}
requestAnimationFrame(meterLoop);
const nativeGUM = navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);
navigator.mediaDevices.getUserMedia = function (constraints) {
const wantsAudio = constraints && constraints.audio;
if (!wantsAudio) return nativeGUM(constraints);
const cleanConstraints = Object.assign({}, constraints, {
audio: Object.assign(
{},
typeof constraints.audio === 'object' ? constraints.audio : {},
{ autoGainControl: !state.disableAGC, noiseSuppression: !state.disableNS }
),
});
return nativeGUM(cleanConstraints).then((rawStream) => {
try {
const chain = buildChain(rawStream);
chains.push(chain);
const outStream = chain.dest.stream;
rawStream.getVideoTracks().forEach((t) => outStream.addTrack(t));
window.postMessage({ type: NS + '_HOOKED' }, '*');
return outStream;
} catch (err) {
window.postMessage({ type: NS + '_ERROR', message: (err && err.message) || 'engine error' }, '*');
return rawStream;
}
});
};
function startTest() {
stopTest();
nativeGUM({ audio: { autoGainControl: !state.disableAGC, noiseSuppression: !state.disableNS } })
.then((raw) => {
testChain = buildChain(raw);
const audioEl = new Audio();
audioEl.srcObject = testChain.dest.stream;
audioEl.autoplay = true;
testChain.audioEl = audioEl;
})
.catch(() => { window.postMessage({ type: NS + '_ERROR', message: 'Mic permission denied' }, '*'); });
}
function stopTest() {
if (testChain) {
testChain.sourceStream.getTracks().forEach((t) => t.stop());
if (testChain.audioEl) { testChain.audioEl.pause(); testChain.audioEl.srcObject = null; }
testChain = null;
}
}
function applyVoicePreset(name) {
const p = VOICE_PRESETS[name];
if (!p) return;
state = Object.assign({}, state, {
voicePreset: name,
pitchEnabled: p.pitchEnabled,
pitchSemitones: p.pitchSemitones,
ringFreq: p.ringFreq || state.ringFreq,
bandpassFreq: p.bandpassFreq || state.bandpassFreq,
});
if (p.heavyEnabled !== undefined) state.heavyEnabled = p.heavyEnabled;
if (p.heavyDrive !== undefined) state.heavyDrive = p.heavyDrive;
if (p.echoEnabled !== undefined) state.echoEnabled = p.echoEnabled;
if (p.echoMix !== undefined) state.echoMix = p.echoMix;
if (p.echoDelay !== undefined) state.echoDelay = p.echoDelay;
if (p.echoFeedback !== undefined) state.echoFeedback = p.echoFeedback;
if (p.volumeBoost !== undefined) state.volumeBoost = p.volumeBoost;
chains.forEach(applyStateToChain);
if (testChain) applyStateToChain(testChain);
window.postMessage({ type: NS + '_STATE_SYNC', value: state }, '*');
}
window.addEventListener('message', (event) => {
if (event.source !== window || !event.data) return;
const d = event.data;
if (d.type === NS + '_SET_STATE') {
state = Object.assign({}, state, d.value);
chains.forEach(applyStateToChain);
if (testChain) applyStateToChain(testChain);
} else if (d.type === NS + '_APPLY_MODE') {
const presets = {
'Alpha Mode': { volumeBoost: 45, autoGainEnabled: true, eq90: -4, eq350: -1, eq800: 3, eq2k: 5, eq7k: 3, eq10k: 0, gateEnabled: true, gateThreshold: -45, heavyEnabled: false, echoEnabled: false, pitchEnabled: false, voicePreset: 'None', voiceFilterEnabled: true, ownVoiceEnabled: true },
Indoor:      { volumeBoost: 30, eq90: -2, eq350: 0, eq800: 2, eq2k: 3, eq7k: 3, eq10k: 1, gateEnabled: false, heavyEnabled: false },
Outdoor:     { volumeBoost: 55, eq90: -6, eq350: -2, eq800: 3, eq2k: 4, eq7k: 4, eq10k: 2, gateEnabled: true, gateThreshold: -42, heavyEnabled: false },
Loudest:     { volumeBoost: 90, eq90: -1, eq350: 1, eq800: 4, eq2k: 5, eq7k: 5, eq10k: 3, gateEnabled: true, gateThreshold: -48, heavyEnabled: true, heavyDrive: 40 },
'God Level': { volumeBoost: 140, eq90: 0, eq350: 2, eq800: 5, eq2k: 6, eq7k: 6, eq10k: 4, gateEnabled: true, gateThreshold: -55, heavyEnabled: true, heavyDrive: 70 },
'King Mode': { volumeBoost: 200, eq90: 2, eq350: 3, eq800: 6, eq2k: 7, eq7k: 7, eq10k: 5, gateEnabled: true, gateThreshold: -55, heavyEnabled: true, heavyDrive: 80 },
'Beast Mode': { volumeBoost: 60, autoGainEnabled: false, eq90: 0, eq350: 0, eq800: 0, eq2k: 0, eq7k: 0, eq10k: 0, gateEnabled: false, heavyEnabled: true, heavyDrive: 550, pitchEnabled: true, pitchSemitones: -6, voicePreset: 'Deep', echoEnabled: true, echoDelay: 150, echoFeedback: 0.15, echoMix: 0.15 },
};
const p = presets[d.name];
if (p) {
state = Object.assign({}, state, p, { mode: d.name });
chains.forEach(applyStateToChain);
window.postMessage({ type: NS + '_STATE_SYNC', value: state }, '*');
}
} else if (d.type === NS + '_APPLY_VOICE') {
applyVoicePreset(d.name);
} else if (d.type === NS + '_GET_STATE') {
window.postMessage({ type: NS + '_STATE_SYNC', value: state }, '*');
} else if (d.type === NS + '_PING') {
window.postMessage({ type: NS + '_PONG', hooked: chains.length > 0 }, '*');
} else if (d.type === NS + '_START_TEST') {
startTest();
} else if (d.type === NS + '_STOP_TEST') {
stopTest();
}
});
})();
