const ALPHA_LICENSE = (function () {
function genUuidV4() {
const b = crypto.getRandomValues(new Uint8Array(16));
b[6] = (b[6] & 0x0f) | 0x40;
b[8] = (b[8] & 0x3f) | 0x80;
const h = Array.from(b).map((x) => x.toString(16).padStart(2, '0'));
return `${h[0]}${h[1]}${h[2]}${h[3]}-${h[4]}${h[5]}-${h[6]}${h[7]}-${h[8]}${h[9]}-${h[10]}${h[11]}${h[12]}${h[13]}${h[14]}${h[15]}`;
}
function getBuyerUuid() {
return new Promise((resolve) => {
try {
chrome.storage.local.get(['alphaBuyerUuid'], (res) => {
if (res && res.alphaBuyerUuid) return resolve(res.alphaBuyerUuid);
const id = genUuidV4();
chrome.storage.local.set({ alphaBuyerUuid: id }, () => resolve(id));
});
} catch (e) {
resolve(genUuidV4());
}
});
}
async function checkStatus() {
const buyerUuid = await getBuyerUuid();
return { deviceId: buyerUuid, status: 'approved', source: 'local' };
}
return { getDeviceId: getBuyerUuid, checkStatus };
})();
