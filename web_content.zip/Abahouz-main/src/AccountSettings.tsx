import { useState } from 'react';
import { invoke } from '@tauri-apps/api/core';

export default function AccountSettings() {
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [message, setMessage] = useState('');
  async function save(event: React.FormEvent) {
    event.preventDefault(); setMessage('');
    try { await invoke('change_password', { currentPassword, newPassword }); setCurrentPassword(''); setNewPassword(''); setMessage('Mot de passe modifié.'); }
    catch (error) { setMessage(String(error)); }
  }
  return <section className="panel"><h3>Mon compte</h3><p className="muted">La session se verrouille après 30 minutes d’inactivité.</p><form className="form-stack" onSubmit={save}><label>Mot de passe actuel<input type="password" autoComplete="current-password" required value={currentPassword} onChange={e => setCurrentPassword(e.target.value)} /></label><label>Nouveau mot de passe<input type="password" autoComplete="new-password" minLength={8} required value={newPassword} onChange={e => setNewPassword(e.target.value)} /></label><button className="primary-button">Modifier le mot de passe</button></form>{message && <p className="success-message" role="status">{message}</p>}</section>;
}
