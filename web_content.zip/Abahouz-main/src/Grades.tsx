import { useEffect, useMemo, useState } from 'react';
import { invoke } from '@tauri-apps/api/core';

type Grade = { id: string; assessment_id: string; student_id: string; score: number; status: string; entered_by: string; entered_at: string; updated_at: string };
type Assessment = { id: string; class_subject_id: string; name: string; assessment_date: string; max_score: number; weight: number; status: string };
type Assignment = { id: string; class_id: string; class_name: string; subject_name: string };
type Enrollment = { id: string; student_id: string; student_name: string; class_id: string; status: string };
type AverageRow = { studentId: string; name: string; average: number | null; count: number; rank: number | null };
type SubjectRow = { subjectId: string; subjectName: string; average: number | null; count: number };

const YEAR_ID = 'year-2026-2027';
const csvCell = (value: string | number) => `"${String(value).replaceAll('"', '""')}"`;

export default function Grades() {
  const [assessments, setAssessments] = useState<Assessment[]>([]);
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [enrollments, setEnrollments] = useState<Enrollment[]>([]);
  const [assessmentId, setAssessmentId] = useState('');
  const [grades, setGrades] = useState<Grade[]>([]);
  const [allGrades, setAllGrades] = useState<Grade[]>([]);
  const [message, setMessage] = useState('');

  useEffect(() => {
    void invoke<Assessment[]>('list_assessments', { classSubjectId: '' }).then(setAssessments).catch(e => setMessage(String(e)));
    void invoke<Assignment[]>('list_assignments').then(setAssignments).catch(e => setMessage(String(e)));
    void invoke<Enrollment[]>('list_enrollments', { academicYearId: YEAR_ID }).then(setEnrollments).catch(e => setMessage(String(e)));
    void invoke<Grade[]>('list_grades').then(setAllGrades).catch(e => setMessage(String(e)));
  }, []);

  const reload = async (id: string) => {
    try {
      setGrades(await invoke<Grade[]>('list_grades', { assessmentId: id }));
      setAllGrades(await invoke<Grade[]>('list_grades'));
    } catch (e) { setMessage(String(e)); }
  };
  useEffect(() => { if (!assessmentId) { setGrades([]); return; } void reload(assessmentId); }, [assessmentId]);

  const selected = assessments.find(a => a.id === assessmentId);
  const assignment = selected ? assignments.find(a => a.id === selected.class_subject_id) : undefined;
  const roster = assignment ? enrollments.filter(e => e.class_id === assignment.class_id) : [];
  const gradeByStudent = useMemo(() => new Map(grades.map(g => [g.student_id, g])), [grades]);
  const drafts = grades.filter(g => g.status === 'draft');
  const classAssessments = useMemo(() => assignment ? assessments.filter(a => assignments.find(x => x.id === a.class_subject_id)?.class_id === assignment.class_id) : [], [assessments, assignments, assignment]);
  const byAssessment = useMemo(() => new Map(classAssessments.map(a => [a.id, a])), [classAssessments]);

  const averages = useMemo<AverageRow[]>(() => {
    if (!assignment) return [];
    const ranked = roster.map(student => {
      const rows = allGrades.filter(g => g.student_id === student.student_id && byAssessment.has(g.assessment_id) && g.status === 'validated');
      const totalWeight = rows.reduce((sum, g) => sum + (byAssessment.get(g.assessment_id)?.weight ?? 0), 0);
      const average = totalWeight ? rows.reduce((sum, g) => { const a = byAssessment.get(g.assessment_id); return sum + (a ? (g.score / a.max_score) * 20 * a.weight : 0); }, 0) / totalWeight : null;
      return { studentId: student.student_id, name: student.student_name, average, count: rows.length, rank: null };
    }).sort((a, b) => (a.average === null ? 1 : b.average === null ? -1 : b.average - a.average || a.name.localeCompare(b.name)));
    let previous: number | null = null, currentRank = 0;
    return ranked.map((row, index) => { if (row.average === null) return row; if (previous === null || row.average !== previous) currentRank = index + 1; previous = row.average; return { ...row, rank: currentRank }; });
  }, [allGrades, byAssessment, assignment, roster]);

  const subjectAverages = useMemo<SubjectRow[]>(() => {
    const grouped = new Map<string, { name: string; rows: { grade: Grade; assessment: Assessment }[] }>();
    classAssessments.forEach(assessment => { const asg = assignments.find(x => x.id === assessment.class_subject_id); if (!asg) return; const item = grouped.get(assessment.class_subject_id) ?? { name: asg.subject_name, rows: [] }; allGrades.filter(g => g.assessment_id === assessment.id && g.status === 'validated').forEach(grade => item.rows.push({ grade, assessment })); grouped.set(assessment.class_subject_id, item); });
    return Array.from(grouped, ([subjectId, item]) => { const totalWeight = item.rows.reduce((sum, row) => sum + row.assessment.weight, 0); const average = totalWeight ? item.rows.reduce((sum, row) => sum + (row.grade.score / row.assessment.max_score) * 20 * row.assessment.weight, 0) / totalWeight : null; return { subjectId, subjectName: item.name, average, count: item.rows.length }; }).sort((a, b) => a.subjectName.localeCompare(b.subjectName));
  }, [allGrades, assignments, classAssessments]);

  const label = (a: Assessment) => { const asg = assignments.find(x => x.id === a.class_subject_id); return `${a.name} · ${asg ? `${asg.class_name} · ${asg.subject_name}` : 'Affectation inconnue'} · ${a.assessment_date} · /${a.max_score}`; };

  function exportCsv() {
    if (!assignment || !averages.length) { setMessage('Aucun résultat à exporter.'); return; }
    const rows = [['Rang', 'Élève', 'Moyenne / 20', 'Évaluations validées'], ...averages.map(row => [row.rank === null ? '' : `${row.rank}`, row.name, row.average === null ? '' : row.average.toFixed(2), `${row.count}`])];
    const csv = '\ufeff' + rows.map(row => row.map(csvCell).join(';')).join('\r\n');
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
    const link = document.createElement('a'); link.href = url; link.download = `edupilot-resultats-${assignment.class_name.replaceAll(' ', '-')}.csv`; link.click(); URL.revokeObjectURL(url);
    setMessage('Export CSV téléchargé.');
  }

  async function save(studentId: string, raw: string) {
    if (!selected || raw.trim() === '') return;
    const score = Number(raw), existing = gradeByStudent.get(studentId);
    if (existing && existing.score === score) return;
    if (!Number.isInteger(score) || score < 0 || score > selected.max_score) { setMessage(`La note doit être un nombre entier entre 0 et ${selected.max_score}.`); return; }
    let reason: string | null = null;
    if (existing?.status === 'validated') { reason = window.prompt('Cette note est validée. Indiquez le motif de la modification :'); if (!reason || !reason.trim()) { setMessage('Modification annulée : un motif est obligatoire pour une note validée.'); await reload(selected.id); return; } }
    try { await invoke<Grade>('save_grade', { input: { assessment_id: selected.id, student_id: studentId, score, reason } }); setMessage('Note enregistrée en brouillon.'); await reload(selected.id); } catch (e) { setMessage(String(e)); }
  }
  async function validateAll() { if (!drafts.length) { setMessage('Aucune note en brouillon à valider.'); return; } if (!window.confirm(`Valider ${drafts.length} note(s) ? Une note validée ne pourra plus être modifiée sans motif.`)) return; try { for (const g of drafts) await invoke('validate_grade', { gradeId: g.id }); setMessage(`${drafts.length} note(s) validée(s).`); await reload(assessmentId); } catch (e) { setMessage(String(e)); } }

  return <section className="panel">
    <div className="toolbar"><div><h3>Saisie des notes</h3><p className="muted">Les élèves affichés sont ceux inscrits dans la classe de l’évaluation (2026-2027).</p></div>{selected && <button className="primary-button" disabled={!drafts.length} onClick={() => void validateAll()}>Valider les brouillons ({drafts.length})</button>}</div>
    <select value={assessmentId} onChange={e => setAssessmentId(e.target.value)}><option value="">Choisir une évaluation</option>{assessments.map(a => <option key={a.id} value={a.id}>{label(a)}</option>)}</select>
    {message && <p className="success-message">{message}</p>}
    {selected && <div className="table-wrap" style={{ marginTop: 16 }}><table><thead><tr><th>Élève</th><th>Note / {selected.max_score}</th><th>Statut</th></tr></thead><tbody>{roster.map(r => { const grade = gradeByStudent.get(r.student_id); return <tr key={r.student_id}><td>{r.student_name}</td><td><input key={`${assessmentId}-${r.student_id}-${grade?.updated_at ?? 'new'}`} type="number" min="0" max={selected.max_score} step="1" defaultValue={grade?.score ?? ''} onBlur={e => void save(r.student_id, e.target.value)} style={{ maxWidth: 110 }} /></td><td>{grade ? (grade.status === 'validated' ? 'Validée' : 'Brouillon') : 'Non saisie'}</td></tr>; })}</tbody></table>{!roster.length && <div className="table-empty">Aucun élève inscrit dans cette classe. Inscrivez d’abord les élèves dans le menu Inscriptions.</div>}</div>}
    {selected && <div className="table-wrap" style={{ marginTop: 24 }}><div className="toolbar"><div><h3>Moyennes et rangs de la classe</h3><p className="muted">Moyenne pondérée sur 20, uniquement avec les notes validées.</p></div><button className="primary-button" onClick={exportCsv}>Exporter CSV</button></div><table><thead><tr><th>Rang</th><th>Élève</th><th>Moyenne / 20</th><th>Évaluations prises en compte</th></tr></thead><tbody>{averages.map(row => <tr key={row.studentId}><td>{row.rank === null ? '—' : `${row.rank}e`}</td><td>{row.name}</td><td>{row.average === null ? '—' : row.average.toFixed(2)}</td><td>{row.count}</td></tr>)}</tbody></table></div>}
    {selected && <div className="table-wrap" style={{ marginTop: 24 }}><h3>Moyennes par matière</h3><p className="muted">Calculées sur 20 à partir des notes validées de la classe sélectionnée.</p><table><thead><tr><th>Matière</th><th>Moyenne / 20</th><th>Notes prises en compte</th></tr></thead><tbody>{subjectAverages.map(row => <tr key={row.subjectId}><td>{row.subjectName}</td><td>{row.average === null ? '—' : row.average.toFixed(2)}</td><td>{row.count}</td></tr>)}</tbody></table>{!subjectAverages.length && <div className="table-empty">Aucune matière évaluée pour cette classe.</div>}</div>}
    {!assessments.length && <div className="table-empty">Aucune évaluation. Créez-en une dans le menu Évaluations.</div>}
  </section>;
}
