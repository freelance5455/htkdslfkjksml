import { useState } from 'react';
import { invoke } from '@tauri-apps/api/core';
import { GraduationCap, LockKeyhole } from 'lucide-react';

type AuthUser = { id: string; username: string; display_name: string };
type LoginResult = { user: AuthUser; session_id: string };

export default function Login({ onLogin }: { onLogin: (user: AuthUser) => void }) {
  const [username, setUsername] = useState('admin@edupilot.local');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true); setError('');
    try {
      const result = await invoke<LoginResult>('login', { username, password });
      onLogin(result.user);
    } catch (reason) {
      setError(String(reason));
    } finally { setBusy(false); }
  }

  return <main className="login-page"><section className="login-card"><div className="brand-mark"><GraduationCap size={28}/></div><p className="eyebrow">GESTION SCOLAIRE HORS LIGNE</p><h1>Bienvenue sur EduPilot</h1><p className="muted">Connexion locale sécurisée.</p><form onSubmit={submit} className="form-stack"><label>Adresse e-mail<input value={username} onChange={e => setUsername(e.target.value)} type="email" autoComplete="username" required/></label><label>Mot de passe<input value={password} onChange={e => setPassword(e.target.value)} type="password" autoComplete="current-password" required/></label>{error && <p className="error" role="alert">{error}</p>}<button className="primary-button" disabled={busy}><LockKeyhole size={17}/> {busy ? 'Vérification…' : 'Se connecter'}</button></form><div className="demo-note"><strong>Compte de démonstration</strong><br/>admin@edupilot.local<br/>Mot de passe communiqué pour le développement</div></section></main>;
}
