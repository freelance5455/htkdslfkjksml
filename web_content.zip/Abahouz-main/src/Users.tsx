import { useEffect, useState } from 'react';
import { invoke } from '@tauri-apps/api/core';

type ManagedUser = { id: string; username: string; display_name: string; status: string; failed_attempts: number; last_login_at?: string; role_code?: string };
type Role = { id: string; code: string; name: string };

type NewUser = { username: string; display_name: string; password: string; role_code: string };

export default function Users() {
  const [users, setUsers] = useState<ManagedUser[]>([]);
  const [roles, setRoles] = useState<Role[]>([]);
  const [message, setMessage] = useState('');
  const [form, setForm] = useState<NewUser>({ username: '', display_name: '', password: '', role_code: 'secretary' });

  async function load() {
    try {
      const [nextUsers, nextRoles] = await Promise.all([
        invoke<ManagedUser[]>('list_users'),
        invoke<Role[]>('list_roles'),
      ]);
      setUsers(nextUsers); setRoles(nextRoles);
      if (!form.role_code && nextRoles[0]) setForm(current => ({ ...current, role_code: nextRoles[0].code }));
    } catch (error) { setMessage(String(error)); }
  }
  useEffect(() => { void load(); }, []);

  async function create() {
    try {
      await invoke('create_user', { input: form });
      setMessage('Utilisateur créé.');
      setForm({ username: '', display_name: '', password: '', role_code: form.role_code });
      await load();
    } catch (error) { setMessage(String(error)); }
  }
  async function unlock(userId: string) {
    try { await invoke('unlock_user', { userId }); setMessage('Compte déverrouillé.'); await load(); }
    catch (error) { setMessage(String(error)); }
  }
  async function reset(userId: string) {
    const password = window.prompt('Nouveau mot de passe, 8 caractères minimum :');
    if (!password) return;
    try { await invoke('reset_password', { userId, newPassword: password }); setMessage('Mot de passe réinitialisé.'); await load(); }
    catch (error) { setMessage(String(error)); }
  }

  return <section className="panel">
    <h3>Utilisateurs et rôles</h3>
    {message && <p className="success-message" role="status">{message}</p>}
    <div className="student-form">
      <input type="email" placeholder="E-mail *" value={form.username} onChange={e => setForm({ ...form, username: e.target.value })} />
      <input placeholder="Nom affiché *" value={form.display_name} onChange={e => setForm({ ...form, display_name: e.target.value })} />
      <input type="password" placeholder="Mot de passe *" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} />
      <select value={form.role_code} onChange={e => setForm({ ...form, role_code: e.target.value })}>{roles.map(role => <option key={role.code} value={role.code}>{role.name}</option>)}</select>
      <button className="primary-button" disabled={!form.username || !form.display_name || !form.password} onClick={() => void create()}>Créer</button>
    </div>
    <div className="table-wrap"><table><thead><tr><th>Utilisateur</th><th>Rôle</th><th>Statut</th><th>Échecs</th><th>Dernière connexion</th><th>Actions</th></tr></thead><tbody>
      {users.map(user => <tr key={user.id}><td>{user.display_name}<br /><small>{user.username}</small></td><td>{user.role_code || '—'}</td><td>{user.status}</td><td>{user.failed_attempts}</td><td>{user.last_login_at || 'Jamais'}</td><td><button className="icon-button" onClick={() => void reset(user.id)}>Réinitialiser</button>{user.failed_attempts > 0 || user.status === 'locked' ? <button className="icon-button" onClick={() => void unlock(user.id)}>Déverrouiller</button> : null}</td></tr>)}
    </tbody></table>{!users.length && <div className="table-empty">Aucun utilisateur.</div>}</div>
  </section>;
}
