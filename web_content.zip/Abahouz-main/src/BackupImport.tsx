import { useState } from 'react';
import { invoke } from '@tauri-apps/api/core';
import { open } from '@tauri-apps/plugin-dialog';

type Backup = { id: string; file_path: string; sha256: string; size_bytes: number; kind: string; integrity_status: string; created_at: string };

export default function BackupImport({ onImported }: { onImported: (backup: Backup) => void }) {
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  async function choose() {
    setMessage(''); setBusy(true);
    try {
      const selected = await open({ multiple: false, directory: false, filters: [{ name: 'Sauvegarde SQLite', extensions: ['sqlite', 'db'] }] });
      if (!selected || Array.isArray(selected)) return;
      const backup = await invoke<Backup>('import_backup', { sourcePath: selected });
      onImported(backup); setMessage('Sauvegarde importée et vérifiée.');
    } catch (error) { setMessage(String(error)); }
    finally { setBusy(false); }
  }
  return <div className="student-form"><button className="primary-button" disabled={busy} onClick={() => void choose()}>{busy ? 'Vérification…' : 'Importer depuis une clé USB'}</button>{message && <span className="muted" role="status">{message}</span>}</div>;
}
