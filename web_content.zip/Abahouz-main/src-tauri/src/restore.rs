use sha2::{Digest, Sha256};
use sqlx::SqlitePool;
use std::{fs, path::{Path, PathBuf}};
use tauri::{AppHandle, Manager};
use uuid::Uuid;

fn sha256_file(path: &Path) -> Result<String, String> { Ok(hex::encode(Sha256::digest(fs::read(path).map_err(|e| e.to_string())?))) }

pub async fn import_external(app: &AppHandle, db: &SqlitePool, source_path: String, actor: String) -> Result<String, String> {
  let source = PathBuf::from(source_path.trim());
  if !source.is_file() { return Err("Le fichier de sauvegarde est introuvable".into()); }
  let source_hash = sha256_file(&source)?;
  let dir = app.path().app_data_dir().map_err(|e| e.to_string())?.join("backups");
  fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
  let id = Uuid::now_v7().to_string();
  let target = dir.join(format!("edupilot-import-{}.sqlite", id));
  fs::copy(&source, &target).map_err(|e| e.to_string())?;
  let options = crate::storage::options(&target)?;
  let check = sqlx::SqlitePool::connect_with(options).await.map_err(|e| e.to_string())?;
  let integrity = crate::storage::integrity_check(&check).await?;
  check.close().await;
  if integrity != "ok" { let _ = fs::remove_file(&target); return Err(format!("Sauvegarde invalide : {integrity}")); }
  let size = fs::metadata(&target).map_err(|e| e.to_string())?.len() as i64;
  sqlx::query("INSERT INTO backups(id,file_path,sha256,size_bytes,kind,integrity_status) VALUES(?,?,?,?,'manual','verified')")
    .bind(&id).bind(target.to_string_lossy().to_string()).bind(&source_hash).bind(size).execute(db).await.map_err(|e| e.to_string())?;
  sqlx::query("INSERT INTO audit_logs(id,actor_id,action,resource,resource_id,details) VALUES(?,?,?,?,?,?)")
    .bind(Uuid::now_v7().to_string()).bind(actor).bind("backup_imported").bind("backups").bind(&id).bind("external_file").execute(db).await.map_err(|e| e.to_string())?;
  Ok(id)
}

pub async fn prepare(app: &AppHandle, db: &SqlitePool, backup_id: String, actor: String) -> Result<String, String> {
  let backup: (String, String, String) = sqlx::query_as("SELECT file_path,sha256,integrity_status FROM backups WHERE id=?").bind(&backup_id).fetch_one(db).await.map_err(|_| "Sauvegarde introuvable".to_string())?;
  if backup.2 != "verified" { return Err("La sauvegarde doit être vérifiée avant restauration".into()); }
  let source = PathBuf::from(&backup.0);
  if !source.is_file() { return Err("Le fichier de sauvegarde est introuvable".into()); }
  if sha256_file(&source)? != backup.1 { return Err("L’empreinte de la sauvegarde ne correspond pas".into()); }
  let dir = app.path().app_data_dir().map_err(|e| e.to_string())?;
  let current = dir.join("edupilot.sqlite"); let pending = dir.join("edupilot.restore.pending.sqlite");
  let safety = dir.join(format!("edupilot-pre-restore-{}.sqlite", Uuid::now_v7()));
  if current.is_file() { fs::copy(&current, &safety).map_err(|e| e.to_string())?; }
  fs::copy(&source, &pending).map_err(|e| e.to_string())?;
  if safety.is_file() { let metadata=fs::metadata(&safety).map_err(|e|e.to_string())?; sqlx::query("INSERT INTO backups(id,file_path,sha256,size_bytes,kind,integrity_status) VALUES(?,?,?,?, 'pre_restore','verified')").bind(Uuid::now_v7().to_string()).bind(safety.to_string_lossy().to_string()).bind(sha256_file(&safety)?).bind(metadata.len() as i64).execute(db).await.map_err(|e|e.to_string())?; }
  sqlx::query("INSERT INTO audit_logs(id,actor_id,action,resource,resource_id,details) VALUES(?,?,?,?,?,?)").bind(Uuid::now_v7().to_string()).bind(actor).bind("restore_prepared").bind("backups").bind(&backup_id).bind(pending.to_string_lossy().to_string()).execute(db).await.map_err(|e|e.to_string())?;
  Ok("Restauration préparée. Fermez puis relancez EduPilot pour l’appliquer.".into())
}
