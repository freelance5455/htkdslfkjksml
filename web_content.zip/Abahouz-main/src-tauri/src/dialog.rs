/// Retourne le plugin de dialogue natif Tauri prêt à être enregistré dans le builder.
pub fn init() -> tauri_plugin_dialog::DialogPlugin {
  tauri_plugin_dialog::init()
}
