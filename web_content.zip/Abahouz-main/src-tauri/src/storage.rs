use sqlx::sqlite::{SqliteConnectOptions, SqliteJournalMode, SqlitePoolOptions, SqliteSynchronous};
use sqlx::SqlitePool;
use std::{path::Path, str::FromStr, time::Duration};

pub fn options(path: &Path) -> Result<SqliteConnectOptions, String> {
  SqliteConnectOptions::from_str(&format!("sqlite:{}", path.display()))
    .map(|options| options.create_if_missing(true).foreign_keys(true).journal_mode(SqliteJournalMode::Wal).synchronous(SqliteSynchronous::Normal).busy_timeout(Duration::from_secs(5)))
    .map_err(|e| e.to_string())
}

pub async fn open(path: &Path, max_connections: u32) -> Result<SqlitePool, String> {
  SqlitePoolOptions::new().max_connections(max_connections).connect_with(options(path)?).await.map_err(|e| e.to_string())
}

pub async fn integrity_check(pool: &SqlitePool) -> Result<String, String> {
  let (result,): (String,) = sqlx::query_as("PRAGMA integrity_check").fetch_one(pool).await.map_err(|e| e.to_string())?;
  Ok(result)
}
