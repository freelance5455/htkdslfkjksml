use sqlx::SqlitePool;
use uuid::Uuid;

/// Vérifie qu'une session est valide et que son utilisateur possède la permission demandée.
/// Retourne l'identifiant de l'utilisateur autorisé. Les refus sont journalisés.
pub async fn require_for_session(pool: &SqlitePool, session_id: &str, resource: &str, action: &str) -> Result<String, String> {
  let session: Option<(String,)> = sqlx::query_as("SELECT u.id FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.id=? AND s.revoked_at IS NULL AND datetime(s.expires_at)>datetime('now') AND u.status='active'")
    .bind(session_id).fetch_optional(pool).await.map_err(|e| e.to_string())?;
  let Some((user_id,)) = session else { return Err("Session expirée ou invalide. Veuillez vous reconnecter.".into()); };
  let allowed: Option<(i64,)> = sqlx::query_as("SELECT 1 FROM user_roles ur JOIN role_permissions rp ON rp.role_id=ur.role_id JOIN permissions p ON p.id=rp.permission_id WHERE ur.user_id=? AND p.resource=? AND p.action=? LIMIT 1")
    .bind(&user_id).bind(resource).bind(action).fetch_optional(pool).await.map_err(|e| e.to_string())?;
  if allowed.is_none() {
    sqlx::query("INSERT INTO audit_logs(id,actor_id,action,resource,resource_id,details) VALUES(?,?,?,?,?,?)")
      .bind(Uuid::now_v7().to_string()).bind(&user_id).bind("access_denied").bind(resource).bind("-").bind(action)
      .execute(pool).await.map_err(|e| e.to_string())?;
    return Err(format!("Accès refusé : vous n'avez pas la permission « {resource}.{action} »."));
  }
  sqlx::query("UPDATE sessions SET last_seen_at=datetime('now') WHERE id=?").bind(session_id).execute(pool).await.map_err(|e| e.to_string())?;
  Ok(user_id)
}

/// Vérifie la permission pour la session active de l'application.
pub async fn require(pool: &SqlitePool, resource: &str, action: &str) -> Result<String, String> {
  let Some(session_id) = crate::auth::current_session_id()? else { return Err("Vous devez être connecté pour effectuer cette action.".into()); };
  require_for_session(pool, &session_id, resource, action).await
}
