use serde::{Deserialize, Serialize};
use sqlx::{sqlite::{SqliteConnectOptions, SqlitePoolOptions}, FromRow, SqlitePool};
use std::str::FromStr;
use tauri::{AppHandle, Manager};
use uuid::Uuid;

#[derive(Debug, Serialize, FromRow)]
pub struct SchoolClass { pub id: String, pub level_id: String, pub level_name: String, pub name: String, pub capacity: Option<i64>, pub status: String }
#[derive(Debug, Serialize, FromRow)]
pub struct Enrollment { pub id: String, pub student_id: String, pub student_name: String, pub class_id: String, pub class_name: String, pub academic_year_id: String, pub status: String }
#[derive(Debug, Deserialize)]
pub struct ClassInput { pub level_name: String, pub name: String, pub capacity: Option<i64> }
#[derive(Debug, Deserialize)]
pub struct EnrollmentInput { pub student_id: String, pub class_id: String, pub academic_year_id: String }

async fn db(app: &AppHandle) -> Result<SqlitePool, String> {
    let path = app.path().app_data_dir().map_err(|e| e.to_string())?.join("edupilot.sqlite");
    let options = SqliteConnectOptions::from_str(&format!("sqlite:{}", path.display())).map_err(|e| e.to_string())?.foreign_keys(true);
    SqlitePoolOptions::new().max_connections(2).connect_with(options).await.map_err(|e| e.to_string())
}

async fn class_by_id(pool: &SqlitePool, id: &str) -> Result<SchoolClass, String> {
    sqlx::query_as::<_, SchoolClass>("SELECT c.id,c.level_id,l.name AS level_name,c.name,c.capacity,c.status FROM classes c JOIN levels l ON l.id=c.level_id WHERE c.id=?").bind(id).fetch_one(pool).await.map_err(|e| e.to_string())
}

#[tauri::command]
pub async fn list_classes(app: AppHandle) -> Result<Vec<SchoolClass>, String> {
    let pool = db(&app).await?;
    crate::authz::require(&pool, "classes", "view").await?;
    sqlx::query_as::<_, SchoolClass>("SELECT c.id,c.level_id,l.name AS level_name,c.name,c.capacity,c.status FROM classes c JOIN levels l ON l.id=c.level_id WHERE c.status='active' ORDER BY l.sort_order,c.name").fetch_all(&pool).await.map_err(|e| e.to_string())
}

#[tauri::command]
pub async fn create_class(app: AppHandle, input: ClassInput) -> Result<SchoolClass, String> {
    let pool = db(&app).await?;
    crate::authz::require(&pool, "classes", "add").await?;
    let level_name = input.level_name.trim(); let class_name = input.name.trim();
    if level_name.is_empty() || class_name.is_empty() { return Err("Le niveau et le nom de la classe sont obligatoires".into()); }
    if input.capacity.is_some_and(|v| v <= 0) { return Err("La capacité doit être supérieure à zéro".into()); }
    let mut tx = pool.begin().await.map_err(|e| e.to_string())?;
    let level_id: Option<(String,)> = sqlx::query_as("SELECT id FROM levels WHERE school_id='local-school' AND name=?").bind(level_name).fetch_optional(&mut *tx).await.map_err(|e| e.to_string())?;
    let level_id = match level_id { Some(v) => v.0, None => { let id=Uuid::now_v7().to_string(); sqlx::query("INSERT INTO levels(id,name,sort_order) VALUES(?,?,0)").bind(&id).bind(level_name).execute(&mut *tx).await.map_err(|e| e.to_string())?; id } };
    let id=Uuid::now_v7().to_string(); sqlx::query("INSERT INTO classes(id,level_id,name,capacity) VALUES(?,?,?,?)").bind(&id).bind(&level_id).bind(class_name).bind(input.capacity).execute(&mut *tx).await.map_err(|e| format!("Cette classe existe déjà ou est invalide : {e}"))?;
    tx.commit().await.map_err(|e| e.to_string())?; class_by_id(&pool, &id).await
}

#[tauri::command]
pub async fn update_class(app: AppHandle, id: String, input: ClassInput) -> Result<SchoolClass, String> {
    let pool = db(&app).await?;
    crate::authz::require(&pool, "classes", "edit").await?;
    let level_name=input.level_name.trim(); let class_name=input.name.trim();
    if level_name.is_empty() || class_name.is_empty() { return Err("Le niveau et le nom de la classe sont obligatoires".into()); }
    if input.capacity.is_some_and(|v| v <= 0) { return Err("La capacité doit être supérieure à zéro".into()); }
    let mut tx=pool.begin().await.map_err(|e| e.to_string())?;
    let level:Option<(String,)>=sqlx::query_as("SELECT id FROM levels WHERE school_id='local-school' AND name=?").bind(level_name).fetch_optional(&mut *tx).await.map_err(|e| e.to_string())?;
    let level_id=match level{Some(v)=>v.0,None=>{let lid=Uuid::now_v7().to_string();sqlx::query("INSERT INTO levels(id,name,sort_order) VALUES(?,?,0)").bind(&lid).bind(level_name).execute(&mut *tx).await.map_err(|e|e.to_string())?;lid}};
    let result=sqlx::query("UPDATE classes SET level_id=?,name=?,capacity=?,updated_at=datetime('now') WHERE id=? AND status='active'").bind(&level_id).bind(class_name).bind(input.capacity).bind(&id).execute(&mut *tx).await.map_err(|e| format!("Modification impossible : {e}"))?;
    if result.rows_affected()==0{return Err("Classe introuvable ou archivée".into())}
    tx.commit().await.map_err(|e|e.to_string())?; class_by_id(&pool,&id).await
}

#[tauri::command]
pub async fn list_enrollments(app: AppHandle, academic_year_id: String) -> Result<Vec<Enrollment>, String> {
    let pool=db(&app).await?;
    crate::authz::require(&pool, "enrollments", "view").await?;
    sqlx::query_as::<_,Enrollment>("SELECT e.id,e.student_id,s.last_name || ' ' || s.first_name AS student_name,e.class_id,c.name AS class_name,e.academic_year_id,e.status FROM enrollments e JOIN students s ON s.id=e.student_id JOIN classes c ON c.id=e.class_id WHERE e.academic_year_id=? AND e.status='active' ORDER BY s.last_name,s.first_name").bind(academic_year_id).fetch_all(&pool).await.map_err(|e| e.to_string())
}

async fn enrollment_by_id(pool:&SqlitePool,id:&str)->Result<Enrollment,String>{sqlx::query_as::<_,Enrollment>("SELECT e.id,e.student_id,s.last_name || ' ' || s.first_name AS student_name,e.class_id,c.name AS class_name,e.academic_year_id,e.status FROM enrollments e JOIN students s ON s.id=e.student_id JOIN classes c ON c.id=e.class_id WHERE e.id=?").bind(id).fetch_one(pool).await.map_err(|e|e.to_string())}

#[tauri::command]
pub async fn create_enrollment(app: AppHandle, input: EnrollmentInput) -> Result<Enrollment, String> {
    let pool=db(&app).await?;
    crate::authz::require(&pool, "enrollments", "add").await?;
    let id=Uuid::now_v7().to_string(); let mut tx=pool.begin().await.map_err(|e| e.to_string())?;
    sqlx::query("INSERT INTO enrollments(id,student_id,academic_year_id,class_id) VALUES(?,?,?,?)").bind(&id).bind(&input.student_id).bind(&input.academic_year_id).bind(&input.class_id).execute(&mut *tx).await.map_err(|e| format!("Inscription impossible : l’élève a peut-être déjà une inscription active pour cette année. {e}"))?;
    tx.commit().await.map_err(|e| e.to_string())?; enrollment_by_id(&pool,&id).await
}

#[tauri::command]
pub async fn change_enrollment_class(app: AppHandle, enrollment_id: String, new_class_id: String) -> Result<Enrollment, String> {
    let pool=db(&app).await?;
    crate::authz::require(&pool, "enrollments", "edit").await?;
    let mut tx=pool.begin().await.map_err(|e|e.to_string())?;
    let current:Option<(String,String,String)>=sqlx::query_as("SELECT student_id,academic_year_id,class_id FROM enrollments WHERE id=? AND status='active'").bind(&enrollment_id).fetch_optional(&mut *tx).await.map_err(|e|e.to_string())?;
    let (student_id,year_id,current_class)=current.ok_or_else(||"Inscription active introuvable".to_string())?;
    if current_class==new_class_id{return Err("L’élève est déjà dans cette classe".into())}
    let exists:Option<(String,)>=sqlx::query_as("SELECT id FROM classes WHERE id=? AND status='active'").bind(&new_class_id).fetch_optional(&mut *tx).await.map_err(|e|e.to_string())?;
    if exists.is_none(){return Err("Nouvelle classe introuvable ou inactive".into())}
    sqlx::query("UPDATE enrollments SET status='cancelled',cancelled_at=datetime('now') WHERE id=?").bind(&enrollment_id).execute(&mut *tx).await.map_err(|e|e.to_string())?;
    let new_id=Uuid::now_v7().to_string();
    sqlx::query("INSERT INTO enrollments(id,student_id,academic_year_id,class_id) VALUES(?,?,?,?)").bind(&new_id).bind(&student_id).bind(&year_id).bind(&new_class_id).execute(&mut *tx).await.map_err(|e|format!("Changement de classe impossible : {e}"))?;
    tx.commit().await.map_err(|e|e.to_string())?; enrollment_by_id(&pool,&new_id).await
}
