use serde::{Deserialize, Serialize};
use sqlx::{sqlite::{SqliteConnectOptions, SqlitePoolOptions}, FromRow, SqlitePool};
use std::str::FromStr;
use tauri::{AppHandle, Manager};
use uuid::Uuid;

#[derive(Debug, Serialize, FromRow)] pub struct Grade { pub id:String,pub assessment_id:String,pub student_id:String,pub score:i64,pub status:String,pub entered_by:String,pub entered_at:String,pub updated_at:String }
#[derive(Debug, Deserialize)] pub struct GradeInput { pub assessment_id:String,pub student_id:String,pub score:i64,pub reason:Option<String> }
async fn db(app:&AppHandle)->Result<SqlitePool,String>{let path=app.path().app_data_dir().map_err(|e|e.to_string())?.join("edupilot.sqlite");let o=SqliteConnectOptions::from_str(&format!("sqlite:{}",path.display())).map_err(|e|e.to_string())?.foreign_keys(true);SqlitePoolOptions::new().max_connections(2).connect_with(o).await.map_err(|e|e.to_string())}
const SELECT_GRADE:&str="SELECT id,assessment_id,student_id,score,status,entered_by,entered_at,updated_at FROM grades";

#[tauri::command]
pub async fn list_grades(app:AppHandle, assessment_id:Option<String>)->Result<Vec<Grade>,String>{
  let p=db(&app).await?;
  crate::authz::require(&p,"grades","view").await?;
  match assessment_id{
    Some(id)=>sqlx::query_as::<_,Grade>(&format!("{SELECT_GRADE} WHERE assessment_id=? AND status!='cancelled' ORDER BY student_id")).bind(id).fetch_all(&p).await.map_err(|e|e.to_string()),
    None=>sqlx::query_as::<_,Grade>(&format!("{SELECT_GRADE} WHERE status!='cancelled' ORDER BY entered_at DESC")).fetch_all(&p).await.map_err(|e|e.to_string())
  }
}

#[tauri::command]
pub async fn save_grade(app:AppHandle,input:GradeInput)->Result<Grade,String>{
  let p=db(&app).await?;
  let actor=crate::authz::require(&p,"grades","edit").await?;
  let max:(i64,)=sqlx::query_as("SELECT max_score FROM assessments WHERE id=? AND status!='locked'").bind(&input.assessment_id).fetch_optional(&p).await.map_err(|e|e.to_string())?.ok_or_else(||"Évaluation introuvable ou verrouillée".to_string())?;
  if input.score<0||input.score>max.0{return Err(format!("La note doit être comprise entre 0 et {}",max.0))}
  let enrolled:Option<(i64,)>=sqlx::query_as("SELECT 1 FROM assessments a JOIN class_subject_assignments csa ON csa.id=a.class_subject_id JOIN enrollments e ON e.class_id=csa.class_id WHERE a.id=? AND e.student_id=? AND e.status='active' LIMIT 1").bind(&input.assessment_id).bind(&input.student_id).fetch_optional(&p).await.map_err(|e|e.to_string())?;
  if enrolled.is_none(){return Err("Cet élève n’est pas inscrit dans la classe de cette évaluation".into())}
  let mut tx=p.begin().await.map_err(|e|e.to_string())?;
  let existing:Option<(String,i64,String)>=sqlx::query_as("SELECT id,score,status FROM grades WHERE assessment_id=? AND student_id=?").bind(&input.assessment_id).bind(&input.student_id).fetch_optional(&mut *tx).await.map_err(|e|e.to_string())?;
  let id=match existing{
    Some((id,old,old_status))=>{
      if old_status=="validated"{
        if input.reason.as_deref().unwrap_or("").trim().is_empty(){return Err("Une note validée exige un motif de modification".into())}
        crate::authz::require(&p,"grades","validate").await.map_err(|_|"Modifier une note validée exige la permission de validation des notes".to_string())?;
      }
      sqlx::query("UPDATE grades SET score=?,status='draft',updated_at=datetime('now') WHERE id=?").bind(input.score).bind(&id).execute(&mut *tx).await.map_err(|e|e.to_string())?;
      sqlx::query("INSERT INTO grade_history(id,grade_id,old_score,new_score,old_status,new_status,actor_id,reason) VALUES(?,?,?,?,?,?,?,?)").bind(Uuid::now_v7().to_string()).bind(&id).bind(old).bind(input.score).bind(old_status).bind("draft").bind(&actor).bind(input.reason).execute(&mut *tx).await.map_err(|e|e.to_string())?;
      id
    },
    None=>{
      let id=Uuid::now_v7().to_string();
      sqlx::query("INSERT INTO grades(id,assessment_id,student_id,score,entered_by) VALUES(?,?,?,?,?)").bind(&id).bind(&input.assessment_id).bind(&input.student_id).bind(input.score).bind(&actor).execute(&mut *tx).await.map_err(|e|e.to_string())?;
      id
    }
  };
  tx.commit().await.map_err(|e|e.to_string())?;
  sqlx::query_as::<_,Grade>(&format!("{SELECT_GRADE} WHERE id=?")).bind(id).fetch_one(&p).await.map_err(|e|e.to_string())
}

#[tauri::command]
pub async fn validate_grade(app:AppHandle,grade_id:String)->Result<Grade,String>{
  let p=db(&app).await?;
  let actor=crate::authz::require(&p,"grades","validate").await?;
  let mut tx=p.begin().await.map_err(|e|e.to_string())?;
  let result=sqlx::query("UPDATE grades SET status='validated',updated_at=datetime('now') WHERE id=? AND status='draft'").bind(&grade_id).execute(&mut *tx).await.map_err(|e|e.to_string())?;
  if result.rows_affected()>0{
    sqlx::query("INSERT INTO audit_logs(id,actor_id,action,resource,resource_id,details) VALUES(?,?,?,?,?,?)").bind(Uuid::now_v7().to_string()).bind(&actor).bind("grade_validated").bind("grades").bind(&grade_id).bind("draft->validated").execute(&mut *tx).await.map_err(|e|e.to_string())?;
  }
  tx.commit().await.map_err(|e|e.to_string())?;
  sqlx::query_as::<_,Grade>(&format!("{SELECT_GRADE} WHERE id=?")).bind(grade_id).fetch_one(&p).await.map_err(|e|e.to_string())
}
