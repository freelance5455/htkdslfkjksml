CREATE TABLE IF NOT EXISTS app_settings (
  key TEXT PRIMARY KEY NOT NULL,
  value TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

INSERT OR IGNORE INTO app_settings (key, value) VALUES ('automatic_backup_enabled', 'false');
INSERT OR IGNORE INTO app_settings (key, value) VALUES ('automatic_backup_interval_hours', '24');
