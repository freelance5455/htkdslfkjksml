CREATE TABLE IF NOT EXISTS academic_years (
  id TEXT PRIMARY KEY NOT NULL,
  school_id TEXT NOT NULL DEFAULT 'local-school',
  name TEXT NOT NULL,
  starts_on TEXT NOT NULL,
  ends_on TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'planned' CHECK (status IN ('planned','active','closed')),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(school_id, name)
);

CREATE TABLE IF NOT EXISTS levels (
  id TEXT PRIMARY KEY NOT NULL,
  school_id TEXT NOT NULL DEFAULT 'local-school',
  name TEXT NOT NULL,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(school_id, name)
);

CREATE TABLE IF NOT EXISTS classes (
  id TEXT PRIMARY KEY NOT NULL,
  school_id TEXT NOT NULL DEFAULT 'local-school',
  level_id TEXT NOT NULL REFERENCES levels(id),
  name TEXT NOT NULL,
  capacity INTEGER CHECK (capacity IS NULL OR capacity > 0),
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','archived')),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(school_id, name)
);

CREATE TABLE IF NOT EXISTS enrollments (
  id TEXT PRIMARY KEY NOT NULL,
  student_id TEXT NOT NULL REFERENCES students(id),
  academic_year_id TEXT NOT NULL REFERENCES academic_years(id),
  class_id TEXT NOT NULL REFERENCES classes(id),
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','cancelled','completed')),
  enrolled_at TEXT NOT NULL DEFAULT (datetime('now')),
  cancelled_at TEXT
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_active_enrollment ON enrollments(student_id, academic_year_id) WHERE status = 'active';
CREATE INDEX IF NOT EXISTS ix_enrollments_class ON enrollments(class_id, status);

INSERT OR IGNORE INTO academic_years(id,name,starts_on,ends_on,status) VALUES ('year-2026-2027','2026-2027','2026-10-01','2027-06-30','active');
