INSERT OR IGNORE INTO roles(id, code, name) VALUES
 ('role-director','director','Directeur'),
 ('role-secretary','secretary','Secrétaire'),
 ('role-accountant','accountant','Comptable'),
 ('role-teacher','teacher','Enseignant'),
 ('role-supervisor','supervisor','Surveillant');

INSERT OR IGNORE INTO permissions(id, resource, action) VALUES
 ('perm-classes-view','classes','view'),('perm-classes-add','classes','add'),('perm-classes-edit','classes','edit'),
 ('perm-enrollments-view','enrollments','view'),('perm-enrollments-add','enrollments','add'),('perm-enrollments-edit','enrollments','edit'),
 ('perm-subjects-view','subjects','view'),('perm-subjects-add','subjects','add'),
 ('perm-teachers-view','teachers','view'),('perm-teachers-add','teachers','add'),
 ('perm-assignments-view','assignments','view'),('perm-assignments-add','assignments','add'),
 ('perm-assessments-view','assessments','view'),('perm-assessments-add','assessments','add'),
 ('perm-backups-view','backups','view'),('perm-backups-add','backups','add');

-- Le super administrateur reçoit toutes les permissions, y compris les nouvelles.
INSERT OR IGNORE INTO role_permissions(role_id, permission_id)
 SELECT 'role-super-admin', id FROM permissions;

-- Le directeur a tout sauf l'administration des utilisateurs.
INSERT OR IGNORE INTO role_permissions(role_id, permission_id)
 SELECT 'role-director', id FROM permissions WHERE NOT (resource='users' AND action='admin');

INSERT OR IGNORE INTO role_permissions(role_id, permission_id)
 SELECT 'role-secretary', id FROM permissions WHERE resource || '.' || action IN (
  'students.view','students.add','students.edit','students.archive',
  'classes.view','enrollments.view','enrollments.add','enrollments.edit',
  'subjects.view','teachers.view','assignments.view');

INSERT OR IGNORE INTO role_permissions(role_id, permission_id)
 SELECT 'role-accountant', id FROM permissions WHERE resource || '.' || action IN (
  'students.view','classes.view','enrollments.view');

INSERT OR IGNORE INTO role_permissions(role_id, permission_id)
 SELECT 'role-teacher', id FROM permissions WHERE resource || '.' || action IN (
  'students.view','classes.view','enrollments.view','subjects.view','assignments.view',
  'assessments.view','assessments.add','grades.view','grades.edit');

INSERT OR IGNORE INTO role_permissions(role_id, permission_id)
 SELECT 'role-supervisor', id FROM permissions WHERE resource || '.' || action IN (
  'students.view','classes.view','enrollments.view');
