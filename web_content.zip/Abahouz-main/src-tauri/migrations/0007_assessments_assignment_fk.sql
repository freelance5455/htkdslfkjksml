PRAGMA foreign_keys = OFF;

CREATE TABLE assessments_new (
  id TEXT PRIMARY KEY NOT NULL,
  class_subject_id TEXT NOT NULL REFERENCES class_subject_assignments(id),
  term_id TEXT,
  name TEXT NOT NULL,
  assessment_date TEXT NOT NULL,
  max_score INTEGER NOT NULL DEFAULT 20 CHECK (max_score > 0),
  weight INTEGER NOT NULL DEFAULT 1 CHECK (weight > 0),
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published','locked')),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

INSERT INTO assessments_new (id,class_subject_id,term_id,name,assessment_date,max_score,weight,status,created_at)
SELECT id,class_subject_id,term_id,name,assessment_date,max_score,weight,status,created_at
FROM assessments
WHERE EXISTS (SELECT 1 FROM class_subject_assignments a WHERE a.id = assessments.class_subject_id);

DROP TABLE assessments;
ALTER TABLE assessments_new RENAME TO assessments;
CREATE INDEX IF NOT EXISTS ix_assessments_subject_date ON assessments(class_subject_id,assessment_date);

PRAGMA foreign_keys = ON;
