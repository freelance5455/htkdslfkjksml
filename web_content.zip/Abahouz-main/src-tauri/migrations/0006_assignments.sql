CREATE TABLE IF NOT EXISTS class_subject_assignments (
  id TEXT PRIMARY KEY NOT NULL,
  class_id TEXT NOT NULL REFERENCES classes(id),
  subject_id TEXT NOT NULL REFERENCES subjects(id),
  teacher_id TEXT REFERENCES teachers(id),
  coefficient INTEGER NOT NULL DEFAULT 1 CHECK (coefficient > 0),
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','archived')),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(class_id, subject_id)
);
CREATE INDEX IF NOT EXISTS ix_assignments_teacher ON class_subject_assignments(teacher_id, status);
CREATE INDEX IF NOT EXISTS ix_assignments_class ON class_subject_assignments(class_id, status);
