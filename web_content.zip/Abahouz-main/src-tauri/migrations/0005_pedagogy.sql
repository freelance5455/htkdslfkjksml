CREATE TABLE IF NOT EXISTS staff (
  id TEXT PRIMARY KEY NOT NULL,
  school_id TEXT NOT NULL DEFAULT 'local-school',
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL,
  phone TEXT,
  email TEXT,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','inactive')),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS teachers (
  id TEXT PRIMARY KEY NOT NULL,
  staff_id TEXT NOT NULL UNIQUE REFERENCES staff(id),
  employee_code TEXT UNIQUE,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS subjects (
  id TEXT PRIMARY KEY NOT NULL,
  school_id TEXT NOT NULL DEFAULT 'local-school',
  name TEXT NOT NULL,
  code TEXT,
  default_coefficient INTEGER NOT NULL DEFAULT 1 CHECK (default_coefficient > 0),
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','archived')),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(school_id,name)
);
CREATE TABLE IF NOT EXISTS class_subjects (
  id TEXT PRIMARY KEY NOT NULL,
  class_id TEXT NOT NULL REFERENCES classes(id),
  subject_id TEXT NOT NULL REFERENCES subjects(id),
  teacher_id TEXT REFERENCES teachers(id),
  coefficient INTEGER NOT NULL DEFAULT 1 CHECK (coefficient > 0),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(class_id,subject_id)
);
CREATE TABLE IF NOT EXISTS assessments (
  id TEXT PRIMARY KEY NOT NULL,
  class_subject_id TEXT NOT NULL REFERENCES class_subjects(id),
  term_id TEXT,
  name TEXT NOT NULL,
  assessment_date TEXT NOT NULL,
  max_score INTEGER NOT NULL DEFAULT 20 CHECK (max_score > 0),
  weight INTEGER NOT NULL DEFAULT 1 CHECK (weight > 0),
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published','locked')),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS ix_assessments_subject_date ON assessments(class_subject_id,assessment_date);
CREATE INDEX IF NOT EXISTS ix_class_subjects_class ON class_subjects(class_id);
