CREATE INDEX IF NOT EXISTS ix_audit_created_at ON audit_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS ix_sessions_active ON sessions(user_id, revoked_at, expires_at);
