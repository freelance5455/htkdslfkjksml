# Migrations SQLite

Les migrations SQL versionnées seront ajoutées avant l’Incrément 2. Aucun schéma métier n’est prétendu disponible dans l’Incrément 1.