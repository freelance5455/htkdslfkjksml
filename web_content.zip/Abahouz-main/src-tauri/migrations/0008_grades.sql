CREATE TABLE IF NOT EXISTS grades (
  id TEXT PRIMARY KEY NOT NULL,
  assessment_id TEXT NOT NULL REFERENCES assessments(id),
  student_id TEXT NOT NULL REFERENCES students(id),
  score INTEGER NOT NULL CHECK (score >= 0),
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','validated','cancelled')),
  entered_by TEXT NOT NULL,
  entered_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(assessment_id, student_id)
);
CREATE INDEX IF NOT EXISTS ix_grades_assessment ON grades(assessment_id, status);
CREATE INDEX IF NOT EXISTS ix_grades_student ON grades(student_id, status);

CREATE TABLE IF NOT EXISTS grade_history (
  id TEXT PRIMARY KEY NOT NULL,
  grade_id TEXT NOT NULL REFERENCES grades(id),
  old_score INTEGER,
  new_score INTEGER,
  old_status TEXT,
  new_status TEXT,
  actor_id TEXT NOT NULL,
  reason TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS ix_grade_history_grade ON grade_history(grade_id, created_at);
