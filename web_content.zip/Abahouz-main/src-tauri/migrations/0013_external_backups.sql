INSERT OR IGNORE INTO permissions(id, resource, action) VALUES ('perm-backups-import','backups','import');
INSERT OR IGNORE INTO role_permissions(role_id, permission_id) SELECT 'role-super-admin', id FROM permissions WHERE resource='backups' AND action='import';
INSERT OR IGNORE INTO role_permissions(role_id, permission_id) SELECT 'role-director', id FROM permissions WHERE resource='backups' AND action='import';
