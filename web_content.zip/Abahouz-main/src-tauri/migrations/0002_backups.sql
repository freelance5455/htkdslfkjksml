CREATE TABLE IF NOT EXISTS backups (
  id TEXT PRIMARY KEY NOT NULL,
  file_path TEXT NOT NULL,
  sha256 TEXT NOT NULL,
  size_bytes INTEGER NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN ('manual', 'pre_restore', 'automatic')),
  integrity_status TEXT NOT NULL DEFAULT 'verified' CHECK (integrity_status IN ('verified', 'failed', 'unknown')),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS ix_backups_created_at ON backups(created_at DESC);
