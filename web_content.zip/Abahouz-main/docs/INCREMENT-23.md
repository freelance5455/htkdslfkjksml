# Incrément 23 · Fiabilité SQLite et vérification des sauvegardes

## Livré

- ouverture SQLite avec `foreign_keys=ON` ;
- mode journal `WAL` ;
- `busy_timeout` de 5 secondes ;
- `synchronous=NORMAL` pour le fonctionnement courant ;
- contrôle `PRAGMA integrity_check` exposé par le diagnostic ;
- commande `verify_database` pour bloquer un diagnostic sur une base corrompue ;
- commande `verify_backup` : vérification de l’empreinte SHA-256 et ouverture de la sauvegarde avec un contrôle d’intégrité ;
- index sur les journaux d’audit et les sessions actives ;
- audit de la vérification des sauvegardes.

## Limites restantes

La restauration sécurisée avec sauvegarde préalable, remplacement atomique et test automatisé après redémarrage reste à implémenter. Le mode `synchronous=FULL` pour les opérations financières sera traité avec le module financier.