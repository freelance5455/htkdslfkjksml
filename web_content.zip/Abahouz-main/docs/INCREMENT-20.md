# Incrément 20 · Gestion des utilisateurs et des comptes

## Livré

- commandes Rust protégées par `users.admin` pour lister les utilisateurs et rôles ;
- création d’un utilisateur avec rôle et mot de passe haché Argon2id ;
- validation minimale du mot de passe et de l’identifiant ;
- réinitialisation administrative du mot de passe ;
- déverrouillage administratif d’un compte après les échecs de connexion ;
- remise à zéro des échecs lors d’une réinitialisation ou d’un déverrouillage ;
- audit des créations, réinitialisations et déverrouillages ;
- commandes Tauri enregistrées : `list_users`, `list_roles`, `create_user`, `reset_password`, `unlock_user`.

## Limite connue

L’écran React de gestion des utilisateurs et rôles reste à ajouter. Les commandes sont disponibles côté Rust, mais ne sont pas encore exposées dans le menu graphique. Le verrouillage automatique après inactivité et la modification du mot de passe par l’utilisateur connecté restent également à faire.