# Installation développeur

## Prérequis

- Node.js 20 ou supérieur ;
- Rust stable MSVC ;
- Microsoft C++ Build Tools sous Windows ;
- WebView2 Runtime sous Windows ;
- dépendances système Tauri 2 adaptées à la plateforme.

## Commandes

```bat
npm install
npm run check
npm run build
npm run tauri dev
```

## Compte de démonstration

- Identifiant : `admin@edupilot.local`
- Mot de passe : `EduPilot-2026`

Ce compte est temporaire et réservé au développement.

## Données locales

La base SQLite `edupilot.sqlite` est créée dans le répertoire de données applicatives de l’utilisateur. L’écran **Diagnostic** confirme que SQLite est initialisée. Ne supprime pas cette base sans sauvegarde.