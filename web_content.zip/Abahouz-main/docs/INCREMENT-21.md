# Incrément 21 · Écran Utilisateurs et rôles

## Livré

- composant React `src/Users.tsx` pour administrer les comptes locaux ;
- écran ajouté au type de navigation et au menu latéral ;
- chargement des utilisateurs et rôles depuis les commandes Rust ;
- création d’un utilisateur avec rôle et mot de passe ;
- réinitialisation administrative du mot de passe ;
- déverrouillage d’un compte ;
- affichage du statut, des échecs de connexion et de la dernière connexion ;
- messages de succès et d’erreur ;
- les commandes restent protégées côté Rust par la permission `users.admin`.

## Limite connue

La modification du mot de passe par l’utilisateur connecté et le verrouillage automatique après inactivité restent à faire.