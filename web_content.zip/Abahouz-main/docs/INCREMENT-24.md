# Incrément 24 · Restauration sécurisée

## Livré

- permission `backups.restore` réservée au super administrateur et au directeur ;
- vérification obligatoire de l’empreinte SHA-256 avant restauration ;
- restauration préparée dans un fichier temporaire, sans écraser la base active ;
- remplacement au prochain démarrage ;
- conservation d’un point de retour de la base précédente ;
- opération auditée dans `audit_logs` ;
- refus des sauvegardes non vérifiées ou introuvables.

## Procédure

1. Vérifier la sauvegarde avec `verify_backup`.
2. Préparer la restauration avec `prepare_restore`.
3. Fermer et relancer EduPilot.
4. Exécuter le diagnostic et vérifier l’intégrité.

## Limite connue

Le bouton graphique de restauration et le test automatisé de redémarrage restent à ajouter.