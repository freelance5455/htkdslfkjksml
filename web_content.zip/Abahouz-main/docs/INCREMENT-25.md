# Incrément 25 · Interface de sauvegarde et restauration

## Livré

- bouton de création d’une sauvegarde locale ;
- affichage du statut d’intégrité et du type de sauvegarde ;
- bouton de vérification SHA-256 et SQLite ;
- bouton de restauration visible uniquement pour une sauvegarde vérifiée ;
- confirmation explicite avant préparation de la restauration ;
- message indiquant que l’application doit être relancée ;
- création préalable du point de retour par le backend.

## Limite connue

Le test automatisé d’un redémarrage complet et la sélection d’un fichier externe depuis une clé USB restent à ajouter.