# Incrément 29 · Initialisation du dialogue natif

## Livré

- helper Rust `src-tauri/src/dialog.rs` pour enregistrer le plugin de dialogue Tauri ;
- encapsulation de l’initialisation native dans une fonction dédiée ;
- préparation du branchement avec le composant `BackupImport`.

## Limite connue

Le helper doit encore être appelé dans `run()` et `BackupImport` doit être inséré dans `Backups()` de `src/App.tsx`. Ces deux modifications seront faites ensemble dans le prochain correctif contrôlé, suivi de `npm install`, `npm run check`, `cargo check` et du lancement Tauri.