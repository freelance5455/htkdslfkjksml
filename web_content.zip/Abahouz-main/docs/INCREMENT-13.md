# Incrément 13 · Moyennes pondérées

## Livré

- chargement de toutes les notes disponibles dans l’écran Notes ;
- calcul des moyennes par élève pour la classe sélectionnée ;
- normalisation des notes sur 20 ;
- prise en compte des coefficients de chaque évaluation ;
- exclusion des notes en brouillon ou annulées ;
- affichage du nombre d’évaluations prises en compte.

## Limites restantes

Les rangs, décisions de conseil, bulletins PDF, export et statistiques globales restent à réaliser. Les moyennes affichées dépendent uniquement des notes validées et ne remplacent pas encore un bulletin officiel.