# Incrément 5 · Durcissement du socle

## Livré

- modification transactionnelle d’un élève côté Rust ;
- audit et événement outbox associés à chaque modification ;
- migration `0003_hardening.sql` ;
- paramètres locaux contrôlés pour activer une sauvegarde automatique et définir son intervalle ;
- intervalle accepté : 1 à 720 heures ;
- contrôle des clés de configuration autorisées ;
- commandes Tauri `get_settings` et `set_setting` ;
- maintien du contrôle d’intégrité SQLite et des empreintes SHA-256.

## Vérification locale

```bat
git pull origin main
npm install
npm run check
npm run build
cd src-tauri
cargo test
cd ..
npm run tauri dev
```

## Limites honnêtes

La planification automatique n’exécute pas encore de tâche en arrière-plan : cet incrément prépare et valide les paramètres, mais le déclencheur devra être branché dans un prochain incrément. L’authentification Argon2id et les permissions Rust complètes restent également à implémenter avant toute utilisation en production.
