# Incrément 14 · Rangs de classe

## Livré

- classement des élèves par moyenne pondérée ;
- rang calculé uniquement pour les élèves ayant au moins une note validée ;
- gestion des ex æquo avec le même rang ;
- tri décroissant par moyenne, puis alphabétique ;
- affichage du rang et du nombre d’évaluations prises en compte.

## Limites restantes

Les décisions de conseil, bulletins PDF, exports, moyennes par matière et statistiques globales restent à réaliser.