# Incrément 16 · Export des résultats

## Livré

- export CSV des résultats de la classe sélectionnée ;
- export du rang, du nom de l’élève, de la moyenne sur 20 et du nombre d’évaluations validées ;
- encodage UTF-8 compatible avec les tableurs ;
- nom de fichier généré automatiquement à partir de la classe ;
- bouton d’export intégré à l’écran Notes.

## Limites restantes

Les bulletins PDF, décisions de conseil et statistiques globales restent à réaliser.