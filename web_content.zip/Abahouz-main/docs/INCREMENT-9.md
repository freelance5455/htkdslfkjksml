# Incrément 9 · Affectations pédagogiques

## Livré

- migration `0006_assignments.sql` ;
- affectation unique d’une matière à une classe ;
- enseignant facultatif sur l’affectation ;
- coefficient contrôlé par SQLite et Rust ;
- commandes locales pour lister et créer les affectations ;
- préparation du parcours Évaluations sans saisie manuelle d’un identifiant arbitraire.

## Limites

L’écran visible des affectations et le remplacement du champ libre dans Évaluations seront branchés dans la suite immédiate. Les notes, moyennes et bulletins PDF restent à venir.
