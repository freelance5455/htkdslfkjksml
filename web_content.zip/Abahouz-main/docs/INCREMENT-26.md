# Incrément 26 · Import de sauvegarde externe

## Livré

- préparation de l’import d’une sauvegarde depuis un chemin externe, notamment une clé USB ;
- copie vers le dossier local EduPilot, sans utiliser directement le fichier amovible ;
- calcul et conservation de l’empreinte SHA-256 ;
- contrôle `PRAGMA integrity_check` avant enregistrement ;
- suppression du fichier importé si le contrôle échoue ;
- audit de l’import ;
- permission dédiée `backups.import` réservée au super administrateur et au directeur.

## Limite connue

La commande d’import doit encore être exposée par le handler Tauri et le sélecteur de fichier graphique doit être ajouté à l’écran Sauvegardes.