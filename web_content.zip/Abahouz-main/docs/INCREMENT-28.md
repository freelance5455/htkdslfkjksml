# Incrément 28 · Sélecteur de sauvegarde externe

## Livré

- composant `src/BackupImport.tsx` utilisant le dialogue natif Tauri ;
- filtre des fichiers `.sqlite` et `.db` ;
- appel de la commande Rust `import_backup` ;
- états de chargement, succès et erreur ;
- permission Tauri `dialog:default` ajoutée dans la capacité principale ;
- dépendances frontend et Rust du plugin de dialogue ajoutées.

## Limite connue

Le composant n’est pas encore inséré dans `Backups()` de `src/App.tsx` et le plugin doit être initialisé dans le builder Tauri. Cette intégration doit être faite dans le prochain correctif avec `npm install`, `cargo check` et `npm run check` avant validation.