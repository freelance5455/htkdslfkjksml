# Incrément 3 · Sauvegarde et restauration

## Livré

- sauvegarde locale avec `VACUUM INTO`, compatible avec SQLite WAL ;
- contrôle `PRAGMA integrity_check` ;
- empreinte SHA-256 ;
- historique des sauvegardes ;
- restauration validée et préparée pour application au prochain démarrage ;
- sauvegarde automatique de l’ancienne base avant remplacement ;
- commandes Tauri pour créer, lister, vérifier et restaurer ;
- migration `0002_backups.sql`.

## Parcours prévu

1. créer une sauvegarde depuis l’interface lorsqu’elle sera exposée ;
2. vérifier son empreinte et son intégrité ;
3. sélectionner une sauvegarde connue ;
4. préparer la restauration ;
5. fermer et relancer EduPilot ;
6. l’ancienne base est conservée avec le suffixe `pre-restore`.

## Limites connues

- l’interface graphique de gestion des sauvegardes sera ajoutée au prochain passage UI ;
- la planification automatique configurable reste à brancher ;
- les tests locaux Windows doivent encore être exécutés par le développeur sur sa machine ;
- la base de démonstration utilise encore une authentification simplifiée.
