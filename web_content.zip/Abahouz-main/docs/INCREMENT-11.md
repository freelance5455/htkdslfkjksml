# Incrément 11 · Saisie des notes

## Livré dans le backend

- migration `0008_grades.sql` ;
- notes liées à une évaluation et à un élève ;
- contrainte d’unicité élève/évaluation ;
- contrôle Rust du barème ;
- états `draft`, `validated`, `cancelled` ;
- historique des changements ;
- motif obligatoire pour modifier une note validée ;
- commandes Tauri `list_grades`, `save_grade` et `validate_grade`.

## Vérification

```bat
git pull origin main
npm install
npm run check
npm run build
cd src-tauri
cargo test
cd ..
npm run tauri dev
```

## Limite actuelle

La grille graphique de saisie des notes n’est pas encore ajoutée au menu. Le backend est prêt, mais l’interface de saisie par élève sera branchée dans le prochain correctif UI afin de ne pas masquer les notes existantes.
