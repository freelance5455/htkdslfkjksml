# Incrément 15 · Moyennes par matière

## Livré

- calcul des moyennes par matière pour la classe sélectionnée ;
- normalisation des notes sur 20 ;
- prise en compte des coefficients des évaluations ;
- exclusion des notes en brouillon ou annulées ;
- affichage du nombre de notes validées prises en compte.

## Limites restantes

Les décisions de conseil, bulletins PDF, exports et statistiques globales restent à réaliser.