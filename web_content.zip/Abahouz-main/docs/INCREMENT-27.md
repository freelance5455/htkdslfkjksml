# Incrément 27 · Commande d’import externe

## Livré

- commande Tauri `import_backup` enregistrée ;
- vérification de la session et de la permission `backups.import` côté Rust ;
- copie d’une sauvegarde externe dans le dossier local EduPilot ;
- contrôle SHA-256 et `PRAGMA integrity_check` avant enregistrement ;
- conservation de l’import dans l’historique des sauvegardes ;
- audit de l’opération.

## Limite connue

Le sélecteur graphique de fichier n’est pas encore ajouté. L’application ne doit pas remplacer `App.tsx` par un extrait : l’intégration UI devra passer par le plugin de dialogue Tauri et ses permissions dédiées, puis être vérifiée avec `npm run check` avant livraison.