# Maintenance EduPilot

## Sauvegarde automatique

Les paramètres `automatic_backup_enabled` et `automatic_backup_interval_hours` sont disponibles dans la base locale. Le déclenchement doit être exécuté par le cycle de démarrage et les événements d’activité avant toute utilisation en production.

## Classes et inscriptions

La contrainte SQL `ux_active_enrollment` bloque les doublons d’inscription active. Ne contournez pas cette contrainte par une modification directe de SQLite : utilisez les opérations métier afin de conserver l’audit et l’outbox.

## Vérification développeur

```bat
npm run check
npm run build
cd src-tauri
cargo test
```
