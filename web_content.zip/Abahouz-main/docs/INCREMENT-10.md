# Incrément 10 · Affectations visibles

## Livré

- écran **Affectations** dans le menu ;
- sélection d’une classe, d’une matière et d’un enseignant facultatif ;
- coefficient contrôlé ;
- liste des affectations existantes ;
- formulaire Évaluations utilisant une affectation réelle ;
- suppression de la saisie libre d’un identifiant d’affectation.

## Limites

La saisie des notes par élève, les validations, moyennes, rangs et bulletins PDF restent à venir.
