# Incrément 30 · Plugin de dialogue Tauri initialisé

## Livré

- module `dialog` enregistré dans le backend Rust ;
- plugin `tauri-plugin-dialog` initialisé dans le builder Tauri ;
- commande `import_backup` conservée et disponible côté backend ;
- aucune modification destructive de `src/App.tsx`.

## Limite connue

Le composant `BackupImport` doit encore être inséré dans l’écran Sauvegardes. Avant cette insertion, vérifier les dépendances avec `npm install`, `npm run check`, `cargo check --manifest-path src-tauri\\Cargo.toml`, puis tester l’application.