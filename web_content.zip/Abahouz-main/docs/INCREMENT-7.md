# Incrément 7 · Socle pédagogique

## Livré dans le schéma et le backend

- enseignants et personnel ;
- matières avec coefficient par défaut ;
- évaluations avec date, barème, poids et statut ;
- commandes locales pour créer et lister enseignants, matières et évaluations ;
- contraintes SQL sur coefficients, poids et barèmes ;
- migration `0005_pedagogy.sql`.

## Limites

La saisie des notes, les affectations visibles classe/matière/enseignant, les moyennes, les validations et les bulletins PDF restent à implémenter dans les incréments suivants.

## Vérification

```bat
git pull origin main
npm install
npm run check
npm run build
cd src-tauri
cargo test
cd ..
npm run tauri dev
```
