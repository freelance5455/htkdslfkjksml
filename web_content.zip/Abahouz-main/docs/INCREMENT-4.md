# Incrément 4 · Interface Sauvegardes

## Livré

- écran Sauvegardes dans le menu local ;
- création manuelle d’une sauvegarde ;
- affichage de la taille, du type, de la date et de l’empreinte SHA-256 ;
- restauration préparée avec confirmation utilisateur ;
- contrôle d’intégrité effectué par le backend ;
- documentation du parcours utilisateur et des limites.

## Utilisation

1. ouvrir **Sauvegardes** ;
2. cliquer sur **Créer une sauvegarde** ;
3. vérifier le statut `Vérifiée` et l’empreinte affichée ;
4. pour restaurer, cliquer sur l’action de la sauvegarde choisie ;
5. confirmer ;
6. fermer puis relancer EduPilot pour appliquer la restauration.

## Limites connues

La planification automatique configurable n’est pas encore exposée dans l’interface. La restauration doit être testée localement avant usage en production.