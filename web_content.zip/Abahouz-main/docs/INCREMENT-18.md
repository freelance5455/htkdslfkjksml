# Incrément 18 · Écran de connexion sécurisé

## Livré

- composant React `src/Login.tsx` dédié à la connexion ;
- appel de la commande Rust `login` au lieu d’une comparaison de mot de passe dans React ;
- états de chargement et d’erreur ;
- champs compatibles avec les gestionnaires de mots de passe ;
- initialisation via `current_user` ;
- déconnexion reliée à la révocation de session Rust ;
- affichage du nom de l’utilisateur connecté dans l’application.

## Limite connue

Les permissions existent dans le schéma mais ne sont pas encore vérifiées par toutes les commandes métier côté Rust. La prochaine étape est donc l’autorisation serveur et l’écran de gestion des utilisateurs et rôles.