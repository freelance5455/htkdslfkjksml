# Incrément 17 · Sécurité locale, utilisateurs, rôles et audit

## Livré

- schéma SQLite des utilisateurs, rôles, permissions, sessions et événements de connexion ;
- hachage des mots de passe avec Argon2id côté Rust ;
- création initiale du compte administrateur de démonstration uniquement si aucun compte correspondant n’existe ;
- vérification des identifiants côté Rust, sans confiance dans le frontend ;
- limitation basique après cinq échecs consécutifs ;
- sessions locales expirant après huit heures et révocables à la déconnexion ;
- rôle `super_admin` et permissions initiales ;
- journalisation des connexions réussies et échouées dans `login_events` et `audit_logs` ;
- commandes Tauri `login`, `logout` et `current_user`.

## Limite connue

L’écran React utilise encore temporairement l’ancien formulaire de démonstration et doit être branché sur les commandes d’authentification dans le prochain correctif UI. Les permissions doivent ensuite être appliquées à chaque commande métier côté Rust, puis complétées par la gestion des utilisateurs, rôles et changements de mot de passe.