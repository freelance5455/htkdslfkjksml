# Incrément 12 · Écran Notes

## Livré

- composant `src/Grades.tsx` intégré au menu principal ;
- sélection d’une évaluation réelle ;
- grille de saisie par élève inscrit dans la classe ;
- contrôle du barème côté interface et côté Rust ;
- sauvegarde en brouillon ;
- validation en masse des brouillons ;
- motif obligatoire pour modifier une note validée ;
- rafraîchissement après sauvegarde et validation.

L’incrément suivant ajoute le calcul des moyennes pondérées par élève.