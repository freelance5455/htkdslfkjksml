# Incrément 1 · Socle exécutable

## Livré

- structure Tauri 2 + React + Vite + TypeScript strict ;
- shell desktop ;
- connexion locale de démonstration ;
- navigation Tableau de bord, Élèves et Diagnostic ;
- interface française ;
- statut local hors ligne ;
- documentation de démarrage ;
- test Rust minimal.

## Compte de démonstration

- Identifiant : `admin@edupilot.local`
- Mot de passe : `EduPilot-2026`

Ce compte est temporaire et réservé au développement.

## Limites

SQLite, les migrations métier, Argon2id, les permissions Rust complètes, l’audit et la persistance des élèves seront implémentés dans les incréments suivants. Aucun test local n’est déclaré exécuté tant que les dépendances ne sont pas installées dans l’environnement de développement.