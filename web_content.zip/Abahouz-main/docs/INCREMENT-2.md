# Incrément 2 · Module Élèves

## Livré

- base SQLite locale persistante dans le répertoire de données EduPilot ;
- migration `0001_init.sql` ;
- liste paginée et recherche par matricule, nom ou téléphone ;
- création d’un élève avec validation des champs obligatoires ;
- archivage et restauration logique ;
- journal d’audit pour les mutations ;
- événement outbox dans la même transaction que la mutation ;
- diagnostic de l’état SQLite ;
- interface française responsive.

## Vérification locale

```bat
npm install
npm run check
npm run build
npm run tauri dev
```

Dans l’application :

1. se connecter avec `admin@edupilot.local` / `EduPilot-2026` ;
2. ouvrir **Élèves** ;
3. cliquer sur **Nouvel élève** ;
4. renseigner matricule, prénom et nom ;
5. enregistrer ;
6. rechercher l’élève ;
7. l’archiver puis activer **Inclure les archivés** ;
8. le restaurer.

## Limites connues

- le compte de démonstration est encore géré côté interface ; l’authentification Argon2id et les autorisations Rust complètes restent à renforcer ;
- l’édition d’un élève sera ajoutée dans un incrément de durcissement ;
- aucune sauvegarde/restauration utilisateur n’est encore livrée ;
- les tests ont été ajoutés au projet mais ne sont pas déclarés exécutés dans cet environnement distant ;
- la recherche utilise `LIKE` pour l’instant, FTS5 sera évalué avec des données de performance.
