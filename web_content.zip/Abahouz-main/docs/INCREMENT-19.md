# Incrément 19 · Autorisations côté Rust

## Livré

- module `src-tauri/src/authz.rs` : vérification de la session active et de la permission `ressource.action` avant chaque opération ;
- toutes les commandes métier vérifient désormais une permission : élèves, classes, inscriptions, matières, enseignants, affectations, évaluations, notes, sauvegardes ;
- un appel direct d’une commande sans session valide est refusé, même si le bouton est visible dans l’interface ;
- chaque refus d’accès est journalisé dans `audit_logs` (`access_denied`) ;
- migration `0010_permissions.sql` : nouvelles permissions et rôles directeur, secrétaire, comptable, enseignant, surveillant ;
- les notes enregistrent le vrai utilisateur (`entered_by`, historique) au lieu de `demo-admin` ;
- modifier une note validée exige un motif **et** la permission `grades.validate` ;
- une note ne peut être saisie que pour un élève inscrit dans la classe de l’évaluation ;
- validation de note, création d’élève et création de sauvegarde auditées ;
- test Rust `permissions_are_enforced_in_rust` sur base SQLite en mémoire.

## Matrice initiale

| Rôle | Principales permissions |
|---|---|
| Super administrateur | Tout |
| Directeur | Tout sauf administration des utilisateurs |
| Secrétaire | Élèves complets, inscriptions, consultation pédagogique |
| Comptable | Consultation élèves, classes, inscriptions (finances à venir) |
| Enseignant | Consultation, création d’évaluations, saisie de notes (sans validation) |
| Surveillant | Consultation élèves, classes, inscriptions |

## Vérification

```bat
git pull --rebase origin main
cargo test --manifest-path src-tauri\Cargo.toml
npm run tauri dev
```

## Limites restantes

- pas encore d’écran de gestion des utilisateurs et rôles ;
- pas de changement de mot de passe ni de verrouillage automatique après inactivité ;
- le déverrouillage après 5 échecs nécessite encore une intervention technique ;
- l’interface n’adapte pas encore le menu aux permissions (la sécurité reste assurée côté Rust).
