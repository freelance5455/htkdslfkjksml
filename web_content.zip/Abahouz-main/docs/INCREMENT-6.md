# Incrément 6 · Classes et inscriptions

## Livré dans le schéma

- années scolaires ;
- niveaux ;
- classes ;
- inscriptions liées aux élèves ;
- contrainte garantissant une seule inscription active par élève et par année ;
- index de recherche des inscriptions ;
- année scolaire de démonstration `2026-2027`.

## Vérification

```bat
git pull origin main
npm install
npm run check
npm run build
cd src-tauri
cargo test
cd ..
npm run tauri dev
```

## Règle métier

Une inscription active existante empêche toute seconde inscription active du même élève pour la même année scolaire. Pour changer de classe, il faut d’abord annuler l’inscription précédente avec un audit, puis créer la nouvelle.

## Limite

Le schéma est posé et migré ; l’écran de gestion Classes/inscriptions et les commandes métier dédiées seront ajoutés dans la suite immédiate avant de considérer le module comme terminé.
