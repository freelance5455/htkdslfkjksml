# EduPilot

Application desktop offline-first de gestion scolaire.

## Socle actuel

- Tauri 2 + React + Vite + TypeScript strict
- Backend local Rust
- SQLite prévu via SQLx et migrations versionnées
- Écran de connexion local de démonstration
- Diagnostic de l’environnement local
- Interface française sans ressource distante au runtime

## Démarrage

Prérequis : Node.js 20+, Rust stable, les dépendances Tauri 2 et SQLite nécessaires à la plateforme.

```bash
npm install
npm run dev
```

Pour lancer Tauri en développement :

```bash
npm run tauri dev
```

Le compte de démonstration est affiché dans l’écran de connexion. Il ne doit pas être utilisé en production.

## Vérification

```bash
npm run check
npm run build
cargo test --manifest-path src-tauri/Cargo.toml
```

La documentation détaillée sera enrichie à chaque incrément dans `docs/`.