# Robera Motorcycle Spare Parts POS

Default password: 1234

Accounts:
- Sales Account 1
- Sales Account 2
- Sales Account 3
- Manager Account 1
- Owner Account

Files:
- index.html
- style.css
- script.js

This is an offline browser-based POS prototype using localStorage.
For an Android APK, place these web files inside an Android WebView project (or convert using a suitable Android wrapper).
