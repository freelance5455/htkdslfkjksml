# برنامج المدير — مشروع Android Studio مستقل

## فتح المشروع
1. فك ضغط ملف المشروع.
2. افتح Android Studio ثم اختر Open.
3. اختر هذا المجلد نفسه الذي يحتوي على `settings.gradle` و`build.gradle`.
4. انتظر Gradle Sync، وثبّت Android SDK 35 إذا طُلب منك.
5. من القائمة اختر Build → Build APK(s).
6. ملف APK المتوقع: `app/build/outputs/apk/debug/app-debug.apk`.

## محتوى النسخة
- الصفحة الرئيسية موجودة في `app/src/main/assets/index.html`.
- اسم الحزمة مستقل: `com.innovation.factoryadmin`.
- هذه نسخة مصدر Android Studio وليست APK جاهزًا. لم يتم بناء APK أو اختباره على جهاز فعلي في بيئة الإنشاء الحالية.

## ملاحظة مهمة
هذه نسخة الإدارة، وتتضمن واجهة إدارة المصنع حسب ملف HTML المرفق. بيانات التطبيق محلية على الجهاز ولا تتزامن تلقائيًا مع هاتف العامل.
