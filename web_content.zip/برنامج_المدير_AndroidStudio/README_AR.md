# برنامج المدير — شركة الابتكار والتطوير

هذه نسخة Android Studio مستقلة، وتفتح لوحة الإدارة من ملف HTML مضمّن داخل APK، دون الاعتماد على رابط `appassets.androidplatform.net` أو اتصال الإنترنت لعرض الصفحة الرئيسية.

## فتح المشروع وبناء APK
1. فك ضغط الملف كاملًا.
2. افتح Android Studio واختر **Open** ثم مجلد `برنامج_المدير_AndroidStudio` الذي يحتوي على `settings.gradle`.
3. انتظر اكتمال Gradle Sync. يلزم JDK 17 و Android SDK 35.
4. اختر **Build → Build APK(s)**.
5. عند اكتمال البناء ستجد الملف عادة في `app/build/outputs/apk/debug/app-debug.apk`.

## التحقق من مصدر الصفحة
الصفحة الرئيسية موجودة في `app/src/main/assets/index.html` ويحمّلها `MainActivity` باستخدام:
`file:///android_asset/index.html`

إذا ظهرت شاشة `appassets.androidplatform.net` فهذا يعني غالبًا أن النسخة التي فُتحت ليست مبنية من هذا المشروع، أو أن أداة تحويل HTML إلى APK الخارجية هي التي تعرض الصفحة. ابنِ APK من المشروع أعلاه بدلًا من رفع HTML إلى تلك الأداة.

## ملاحظات
- هذه حزمة مصدر Android Studio وليست APK مبنيًا ومختبرًا.
- لم أتمكن من تشغيل Gradle أو اختبار APK على جهاز Android في بيئة العمل الحالية.
- بيانات الدخول والإدارة محلية على الجهاز؛ لا توجد مزامنة تلقائية بين الأجهزة.
