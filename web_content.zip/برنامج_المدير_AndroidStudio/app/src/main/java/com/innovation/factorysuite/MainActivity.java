package com.innovation.factorysuite;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.DownloadListener;
import android.webkit.GeolocationPermissions;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceError;
import android.os.Build;
import android.webkit.JavascriptInterface;
import android.util.Base64;
import android.content.Intent;
import android.net.Uri;
import android.content.ContentValues;
import android.provider.MediaStore;
import android.os.Environment;
import android.widget.Toast;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.security.SecureRandom;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.security.spec.KeySpec;
import java.util.Locale;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private WebView web;
    private AuthDb authDb;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        authDb = new AuthDb();
        web = new WebView(this);
        setContentView(web);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setGeolocationEnabled(true);
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                // The app asks Android for location permission separately if GPS features are added.
                callback.invoke(origin, false, false);
            }
        });
        web.addJavascriptInterface(new FileBridge(), "AndroidBridge");
        web.setWebViewClient(new WebViewClient() {
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && request.isForMainFrame()) {
                    view.loadDataWithBaseURL(null,
                        "<meta name='viewport' content='width=device-width, initial-scale=1'><div dir='rtl' style='font-family:sans-serif;padding:24px;color:#222'><h2>تعذر فتح صفحة التطبيق</h2><p>تأكد أن الملف موجود في:</p><code>app/src/main/assets/index.html</code><p>ثم نفّذ Sync Project with Gradle Files وبعدها Build APK.</p><p>رمز الخطأ: " + error.getErrorCode() + "</p></div>",
                        "text/html", "UTF-8", null);
                }
            }
        });
        web.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) ->
            Toast.makeText(this, "استخدم أزرار التصدير داخل التطبيق لحفظ الملف", Toast.LENGTH_LONG).show()
        );
        // Load the bundled HTML directly from the APK. This avoids appassets.androidplatform.net
        // and does not require a network connection to open the manager dashboard.
        web.loadUrl("file:///android_asset/index.html");
    }
    public class FileBridge {
        @JavascriptInterface public String storeGet(String key) { Cursor c=authDb.getReadableDatabase().rawQuery("SELECT v FROM app_kv WHERE k=?",new String[]{key}); if(!c.moveToFirst()){c.close();return null;} String value=c.getString(0);c.close();return value; }
        @JavascriptInterface public void storeSet(String key,String value) { ContentValues v=new ContentValues();v.put("k",key);v.put("v",value==null?"":value);authDb.getWritableDatabase().insertWithOnConflict("app_kv",null,v,SQLiteDatabase.CONFLICT_REPLACE); }
        @JavascriptInterface public void storeRemove(String key) { authDb.getWritableDatabase().delete("app_kv","k=?",new String[]{key}); }
        @JavascriptInterface public void storeClear() { authDb.getWritableDatabase().delete("app_kv",null,null); }
        @JavascriptInterface public int storeLength() { Cursor c=authDb.getReadableDatabase().rawQuery("SELECT COUNT(*) FROM app_kv",null);int n=c.moveToFirst()?c.getInt(0):0;c.close();return n; }
        @JavascriptInterface public String storeKey(int index) { Cursor c=authDb.getReadableDatabase().rawQuery("SELECT k FROM app_kv ORDER BY k LIMIT 1 OFFSET ?",new String[]{String.valueOf(index)});if(!c.moveToFirst()){c.close();return null;}String k=c.getString(0);c.close();return k; }
        @JavascriptInterface public String hasAdmin() { return authDb.hasAdmin() ? "true" : "false"; }
        @JavascriptInterface public String setupAdmin(String username, String password) { return authDb.setupAdmin(username, password); }
        @JavascriptInterface public String login(String username, String password) { return authDb.login(username, password); }
        @JavascriptInterface public String registerRequest(String name, String username, String password, String role) { return authDb.register(name, username, password, role); }
        @JavascriptInterface public String listAccounts() { return authDb.listAccounts(); }
        @JavascriptInterface public String approveRequest(String username, String role) { return authDb.approve(username, role); }
        @JavascriptInterface public String rejectRequest(String username) { return authDb.reject(username); }
        @JavascriptInterface public String toggleAccount(String username) { return authDb.toggle(username); }
        @JavascriptInterface public void saveFile(String name, String mime, String encoded) {
            runOnUiThread(() -> {
                try {
                    byte[] data = Base64.decode(encoded, Base64.DEFAULT);
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, name.replaceAll("[^\\p{L}\\p{N}._-]", "_"));
                    values.put(MediaStore.Downloads.MIME_TYPE, mime == null ? "application/octet-stream" : mime);
                    values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new Exception("تعذر إنشاء الملف");
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                        if (out == null) throw new Exception("تعذر فتح الملف");
                        out.write(data);
                    }
                    Toast.makeText(MainActivity.this, "تم حفظ الملف في Downloads", Toast.LENGTH_LONG).show();
                } catch (Exception ex) {
                    Toast.makeText(MainActivity.this, "فشل حفظ الملف: " + ex.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }
    }
    private class AuthDb extends SQLiteOpenHelper {
        private static final String DB_NAME = "factory_suite_local.db";
        AuthDb() { super(MainActivity.this, DB_NAME, null, 1); }
        @Override public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE app_kv (k TEXT PRIMARY KEY NOT NULL, v TEXT NOT NULL)");
            db.execSQL("CREATE TABLE accounts (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, display_name TEXT NOT NULL, salt TEXT NOT NULL, pass_hash TEXT NOT NULL, role TEXT NOT NULL, status TEXT NOT NULL, created_at TEXT NOT NULL)");
        }
        @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { }
        private String clean(String s) { return s == null ? "" : s.trim(); }
        private String norm(String s) { return clean(s).toLowerCase(Locale.ROOT); }
        private String salt() { byte[] b = new byte[16]; new SecureRandom().nextBytes(b); return android.util.Base64.encodeToString(b, android.util.Base64.NO_WRAP); }
        private String hash(String password, String salt) {
            try {
                byte[] sb = android.util.Base64.decode(salt, android.util.Base64.NO_WRAP);
                KeySpec spec = new PBEKeySpec(password.toCharArray(), sb, 120000, 256);
                byte[] out = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
                return android.util.Base64.encodeToString(out, android.util.Base64.NO_WRAP);
            } catch (Exception e) { return ""; }
        }
        boolean hasAdmin() { Cursor c = getReadableDatabase().rawQuery("SELECT id FROM accounts WHERE role='admin' LIMIT 1", null); boolean yes=c.moveToFirst(); c.close(); return yes; }
        String setupAdmin(String username, String password) {
            String u=norm(username); if (u.isEmpty() || password == null || password.length()<8) return "INVALID";
            if (hasAdmin()) return "EXISTS";
            String sl=salt(); ContentValues v=new ContentValues(); v.put("username",u); v.put("display_name","مدير النظام"); v.put("salt",sl); v.put("pass_hash",hash(password,sl)); v.put("role","admin"); v.put("status","approved"); v.put("created_at",new java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new java.util.Date()));
            try { getWritableDatabase().insertOrThrow("accounts",null,v); return "OK"; } catch(Exception e) { return "ERROR"; }
        }
        String login(String username, String password) {
            Cursor c=getReadableDatabase().rawQuery("SELECT display_name,salt,pass_hash,role,status FROM accounts WHERE username=?",new String[]{norm(username)});
            if(!c.moveToFirst()){c.close();return "INVALID";} String name=c.getString(0), sl=c.getString(1), ph=c.getString(2), role=c.getString(3), status=c.getString(4); c.close();
            if(!hash(password,sl).equals(ph)) return "INVALID"; if("pending".equals(status)) return "PENDING"; if(!"approved".equals(status)) return "DISABLED";
            try { JSONObject o=new JSONObject();o.put("name",name);o.put("role",role);return o.toString(); } catch(Exception e){return "INVALID";}
        }
        String register(String name, String username, String password, String role) {
            String u=norm(username), n=clean(name); if(u.isEmpty()||n.isEmpty()||password==null||password.length()<8) return "INVALID";
            if(!role.equals("production")&&!role.equals("warehouse")&&!role.equals("hr")&&!role.equals("formulation")&&!role.equals("viewer")) role="viewer";
            Cursor c=getReadableDatabase().rawQuery("SELECT id FROM accounts WHERE username=?",new String[]{u}); boolean exists=c.moveToFirst(); c.close(); if(exists)return "DUPLICATE";
            String sl=salt(); ContentValues v=new ContentValues();v.put("username",u);v.put("display_name",n);v.put("salt",sl);v.put("pass_hash",hash(password,sl));v.put("role",role);v.put("status","pending");v.put("created_at",new java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new java.util.Date()));
            try {getWritableDatabase().insertOrThrow("accounts",null,v);return "OK";}catch(Exception e){return "ERROR";}
        }
        String listAccounts() {
            JSONArray pending=new JSONArray(), approved=new JSONArray(); Cursor c=getReadableDatabase().rawQuery("SELECT username,display_name,role,status,created_at FROM accounts ORDER BY id DESC",null);
            while(c.moveToNext()){try{JSONObject o=new JSONObject();o.put("username",c.getString(0));o.put("name",c.getString(1));o.put("role",c.getString(2));o.put("status",c.getString(3));o.put("created",c.getString(4));o.put("enabled","approved".equals(c.getString(3)));if("pending".equals(c.getString(3)))pending.put(o);else approved.put(o);}catch(Exception ignored){}}
            c.close();try{JSONObject out=new JSONObject();out.put("pending",pending);out.put("approved",approved);return out.toString();}catch(Exception e){return "{\"pending\":[],\"approved\":[]}";}
        }
        String approve(String username,String role) {
            if(!role.equals("production")&&!role.equals("warehouse")&&!role.equals("hr")&&!role.equals("formulation")&&!role.equals("viewer"))return "INVALID";
            ContentValues v=new ContentValues();v.put("role",role);v.put("status","approved");int n=getWritableDatabase().update("accounts",v,"username=? AND status='pending'",new String[]{norm(username)});return n>0?"OK":"ERROR";
        }
        String reject(String username) {int n=getWritableDatabase().delete("accounts","username=? AND status='pending'",new String[]{norm(username)});return n>0?"OK":"ERROR";}
        String toggle(String username) {Cursor c=getReadableDatabase().rawQuery("SELECT status,role FROM accounts WHERE username=?",new String[]{norm(username)});if(!c.moveToFirst()){c.close();return "ERROR";}String status=c.getString(0),role=c.getString(1);c.close();if("admin".equals(role))return "DENIED";String next="approved".equals(status)?"disabled":"approved";ContentValues v=new ContentValues();v.put("status",next);int n=getWritableDatabase().update("accounts",v,"username=?",new String[]{norm(username)});return n>0?"OK":"ERROR";}
    }

    @Override public void onBackPressed() { if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
