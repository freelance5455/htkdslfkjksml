import os, json, time, sqlite3, threading
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.request import Request, urlopen

TOKEN=os.environ.get("BOT_TOKEN","").strip()
if not TOKEN: raise SystemExit("لم يتم تعيين BOT_TOKEN. راجع README_AR.txt")
API="https://api.telegram.org/bot"+TOKEN+"/"
DB="vodeka.sqlite3"
db=sqlite3.connect(DB,check_same_thread=False)
db.execute("CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,username TEXT,first_name TEXT,first_seen INTEGER,last_seen INTEGER,blocked INTEGER DEFAULT 0)")
db.execute("CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY AUTOINCREMENT,ts INTEGER,text TEXT)")
db.commit(); lock=threading.RLock(); bot_name="جارٍ الاتصال"

def add_event(msg):
    with lock: db.execute("INSERT INTO events(ts,text) VALUES(?,?)",(int(time.time()),msg)); db.commit()

def call_api(method,params=None):
    req=Request(API+method,data=json.dumps(params or {}).encode(),headers={"Content-Type":"application/json"})
    with urlopen(req,timeout=45) as res: data=json.loads(res.read())
    if not data.get("ok"): raise RuntimeError(data.get("description","Telegram API error"))
    return data["result"]

def save_user(u,blocked=None,start=False):
    now=int(time.time()); uid=int(u["id"])
    with lock:
        old=db.execute("SELECT id FROM users WHERE id=?",(uid,)).fetchone()
        if old is None:
            db.execute("INSERT INTO users VALUES(?,?,?,?,?,?)",(uid,u.get("username"),u.get("first_name"),now,now,int(bool(blocked))))
            add_event("مستخدم جديد: "+(u.get("first_name") or "مستخدم")+" — "+str(uid))
        else:
            db.execute("UPDATE users SET username=?,first_name=?,last_seen=?,blocked=COALESCE(?,blocked) WHERE id=?",
                       (u.get("username"),u.get("first_name"),now,None if blocked is None else int(blocked),uid))
        if blocked is not None: add_event(("حظر البوت: " if blocked else "عاد للتفاعل: ")+str(uid))
        elif start: add_event("بدأ البوت: "+str(uid))
        db.commit()

def poll_updates():
    global bot_name
    me=call_api("getMe"); bot_name="@"+(me.get("username") or me.get("first_name","bot"))
    add_event("بدأت مراقبة "+bot_name)
    offset=None
    while True:
        params={"timeout":30,"allowed_updates":["message","my_chat_member"]}
        if offset is not None: params["offset"]=offset
        try:
            updates=call_api("getUpdates",params)
            for up in updates:
                offset=up["update_id"]+1
                m=up.get("message")
                if m and m.get("chat",{}).get("type")=="private" and m.get("from"):
                    save_user(m["from"],start=str(m.get("text","")).startswith("/start"))
                cm=up.get("my_chat_member",{}); chat=cm.get("chat",{})
                if chat.get("type")=="private":
                    status=cm.get("new_chat_member",{}).get("status")
                    if status in ("kicked","left","member","administrator"):
                        save_user({"id":chat["id"],"username":chat.get("username"),"first_name":chat.get("first_name")},
                                  blocked=status in ("kicked","left"))
        except Exception as e:
            add_event("مشكلة في استقبال التحديثات: "+str(e)); time.sleep(6)

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path=="/api/stats":
            now=int(time.time())
            with lock:
                total=db.execute("SELECT COUNT(*) FROM users").fetchone()[0]
                active=db.execute("SELECT COUNT(*) FROM users WHERE last_seen>=? AND blocked=0",(now-7*86400,)).fetchone()[0]
                blocked=db.execute("SELECT COUNT(*) FROM users WHERE blocked=1").fetchone()[0]
                today=db.execute("SELECT COUNT(*) FROM users WHERE first_seen>=?",(now-86400,)).fetchone()[0]
                rows=db.execute("SELECT ts,text FROM events ORDER BY id DESC LIMIT 25").fetchall()
            ev=[{"time":datetime.fromtimestamp(t).strftime("%d/%m %H:%M"),"text":s} for t,s in rows]
            body=json.dumps({"bot":bot_name,"total":total,"active_7d":active,"blocked":blocked,"today":today,"events":ev},ensure_ascii=False).encode()
            self.send_response(200);self.send_header("Content-Type","application/json; charset=utf-8");self.send_header("Cache-Control","no-store");self.send_header("Content-Length",str(len(body)));self.end_headers();self.wfile.write(body)
        elif self.path in ("/","/index.html"):
            body=open("index.html","rb").read();self.send_response(200);self.send_header("Content-Type","text/html; charset=utf-8");self.send_header("Content-Length",str(len(body)));self.end_headers();self.wfile.write(body)
        else:self.send_error(404)
    def log_message(self,*a):pass

if __name__=="__main__":
    print("BOT VODEKA يعمل على http://127.0.0.1:8080")
    threading.Thread(target=poll_updates,daemon=True).start()
    ThreadingHTTPServer(("127.0.0.1",8080),Handler).serve_forever()
