IP Toolkit V3

Enthält einen sichtbaren Button zum Senden der eigenen öffentlichen IP
an den voreingetragenen Discord-Webhook nach ausdrücklicher Bestätigung.

Sicherheit:
Der Webhook steht im Frontend und kann aus der HTML-Datei ausgelesen werden.
Nach einem Test den Webhook in Discord löschen und neu erstellen.
Die App sendet nur die IP des Geräts, auf dem sie geöffnet wird.