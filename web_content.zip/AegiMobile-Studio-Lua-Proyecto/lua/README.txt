Scripts Lua integrados/importados de AegiMobile Studio.
Los scripts se normalizan al cargar (BOM y saltos CRLF/CR) y se ejecutan mediante Fengari con shim Aegisub.
Los diálogos soportan label/text/edit/intedit/floatedit/textbox/checkbox/dropdown/listbox/color/alpha/slider/radio.
Las dependencias include() deben estar disponibles en lua/ o en la biblioteca importada.
La compatibilidad es parcial: DLL, módulos nativos, wx y APIs de audio/vídeo de escritorio no existen en WebView.
