import { FilePicker } from '@capawesome/capacitor-file-picker';
window.AegiNativeFilePicker = FilePicker;
