const fs = require('fs');
const esbuild = require('esbuild');
fs.mkdirSync('vendor', {recursive:true});
fs.mkdirSync('www/vendor', {recursive:true});
esbuild.buildSync({entryPoints:['src/native-file-picker.js'],outfile:'vendor/capacitor-file-picker.js',bundle:true,platform:'browser',format:'iife',target:['es2020']});
fs.copyFileSync('vendor/capacitor-file-picker.js','www/vendor/capacitor-file-picker.js');
console.log('Capacitor File Picker JS bundle listo en vendor/ y www/vendor/.');
