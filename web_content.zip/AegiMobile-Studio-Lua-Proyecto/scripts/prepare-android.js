const fs = require('fs');
const { spawnSync } = require('child_process');
const npx = process.platform === 'win32' ? 'npx.cmd' : 'npx';
function run(args) {
  const result = spawnSync(npx, args, { stdio: 'inherit', shell: process.platform === 'win32' });
  if (result.error) throw result.error;
  if (result.status !== 0) process.exit(result.status || 1);
}
if (!fs.existsSync('android')) run(['cap', 'add', 'android']);
run(['cap', 'sync', 'android']);
console.log('Android listo con los plugins sincronizados. Abre con: npx cap open android');
