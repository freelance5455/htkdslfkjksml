const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const files = [
  ['fengari-web/dist/fengari-web.min.js', 'fengari-web.min.js'],
  ['jszip/dist/jszip.min.js', 'jszip.min.js']
];
for (const [source, name] of files) {
  const from = path.join(root, 'node_modules', source);
  if (!fs.existsSync(from)) throw new Error(`Falta ${source}. Ejecuta npm install de nuevo.`);
  for (const dir of ['vendor', path.join('www', 'vendor')]) {
    const targetDir = path.join(root, dir);
    fs.mkdirSync(targetDir, { recursive: true });
    fs.copyFileSync(from, path.join(targetDir, name));
  }
}
console.log('AegiMobile: bibliotecas Fengari y JSZip copiadas a vendor/ y www/vendor/.');
