# mxci Chat — Android offline app project

This Android Studio project wraps the supplied `instagram_style_chat.html` archive in a native Android WebView. The HTML is bundled inside the APK at `app/src/main/assets/index.html`; the archive does not need an internet connection to open.

## Build the APK

1. Install Android Studio on a computer.
2. Open this `MxciChat` project folder in Android Studio.
3. Allow Android Studio to install the Android SDK Platform 35 and the Gradle plugin when prompted.
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. When the build finishes, choose **locate**. The APK is at `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer `app-debug.apk` to the Android phone and install it. Android may ask you to allow installs from that file manager.

## Notes

- App name: **mxci Chat**
- Application ID: `com.mxci.chat`
- Minimum Android version: Android 6.0 (API 23)
- No `INTERNET` permission is declared. The bundled chat opens offline. Links to Instagram or other websites will not load inside this offline app.
- The APK built with the debug option is suitable for personal installation/testing. A release APK for distribution should be signed with a private release key.
