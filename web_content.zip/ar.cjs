const fs = require('fs');
const path = require('path');

function pad(str, len) {
  return str.padEnd(len, ' ');
}

function makeHeader(name, size, mode = '100644', mtime = Math.floor(Date.now() / 1000), uid = '0', gid = '0') {
  const nameField = pad(name, 16);
  const mtimeField = pad(String(mtime), 12);
  const uidField = pad(String(uid), 6);
  const gidField = pad(String(gid), 6);
  const modeField = pad(String(mode), 8);
  const sizeField = pad(String(size), 10);
  const magic = '`\n';
  return Buffer.concat([
    Buffer.from(nameField, 'ascii'),
    Buffer.from(mtimeField, 'ascii'),
    Buffer.from(uidField, 'ascii'),
    Buffer.from(gidField, 'ascii'),
    Buffer.from(modeField, 'ascii'),
    Buffer.from(sizeField, 'ascii'),
    Buffer.from(magic, 'ascii'),
  ]);
}

function pack(files, output) {
  const buffers = [Buffer.from('!<arch>\n', 'ascii')];
  for (const f of files) {
    const content = fs.readFileSync(f.path);
    const header = makeHeader(f.name, content.length);
    buffers.push(header);
    buffers.push(content);
    if (content.length % 2 !== 0) {
      buffers.push(Buffer.from('\n', 'ascii'));
    }
  }
  fs.writeFileSync(output, Buffer.concat(buffers));
}

const args = process.argv.slice(2);
if (args.length < 4) {
  console.log("Usage: node ar.js <debian-binary> <control.tar.gz> <data.tar.gz> <output.ipk>");
  process.exit(1);
}

const files = [
  { name: path.basename(args[0]), path: args[0] },
  { name: path.basename(args[1]), path: args[1] },
  { name: path.basename(args[2]), path: args[2] },
];
pack(files, args[3]);
console.log(`Successfully packed into ${args[3]}`);
