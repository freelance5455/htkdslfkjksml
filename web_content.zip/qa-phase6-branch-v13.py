"""Business, debt-overdraft and layout smoke for Loonie Life. Isolated Chromium."""
from pathlib import Path
import json,re
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parent
h=(R/'index.html').read_text('utf-8')
for f in ('curriculum-v6.js','curriculum-v7.js','university-v8.js','inquiry-v9.js','kingdom-v10.js','career-v11.js','life-v12.js','curriculum-v13.js','academy-v13.js'):
 h=h.replace(f'<script src="{f}"></script>','<script>\n'+(R/f).read_text('utf-8')+'\n</script>')
for f in ('university-v8.css','inquiry-v9.css','kingdom-v10.css','career-v11.css','life-v12.css','academy-v13.css'):
 h=h.replace(f'<link rel="stylesheet" href="{f}">','<style>'+ (R/f).read_text('utf-8')+'</style>')
h=re.sub(r'<link rel="preconnect"[^>]*>|<link href="https://fonts.googleapis.com[^>]*>','',h)
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 page=b.new_page(viewport={'width':390,'height':844},device_scale_factor=1,accept_downloads=True)
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.evaluate('''()=>{window.__db={loonieAcademy_v1:JSON.stringify({onboarded:true,done:{},stars:{},careerV11:{projects:{'accounting-1':{passedAt:1710000000000}},active:'accounting'}})};Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>window.__db[k]||null,setItem:(k,v)=>window.__db[k]=String(v),removeItem:k=>delete window.__db[k],clear:()=>{}}});}''')
 page.set_content(h,wait_until='domcontentloaded',timeout=90000)
 def route(name):
  page.evaluate('x=>{document.querySelectorAll(".overlay").forEach(e=>e.remove());location.hash="#"+x;route()}',name)
  assert 'Something went wrong' not in page.locator('#screen').inner_text(),name
  assert page.evaluate('document.documentElement.scrollWidth<=window.innerWidth+1'),name
 route('life12');page.screenshot(path=str(R/'qa-life12-start.png'),full_page=True)
 page.locator('#ll-begin').click()
 route('life12');page.screenshot(path=str(R/'qa-life12-home.png'),full_page=True)
 route('life12-month');page.screenshot(path=str(R/'qa-life12-month.png'),full_page=True)
 # Controlled state for dedicated financial/business side conditions.
 page.evaluate('''()=>{const c=LOONIE_V12.get();c.month=3;c.cash=2200;c.savings=450;c.debt=350;c.experience=25;c.reputation=62;save();}''')
 assert page.evaluate('LOONIE_V12.businessEligible(LOONIE_V12.get())')
 route('life12-business');assert page.locator('[data-biz]').count()==3
 page.locator('[data-biz="shop"]').click()
 assert page.evaluate('LOONIE_V12.get().company.type')=='shop'
 assert page.evaluate('LOONIE_V12.get().cash')==1300
 assert page.evaluate('state.lifeAwardsV12.business')
 route('life12-month');assert page.locator('[data-plan]').count()==9
 page.locator('[data-plan="pricing"]').select_option('premium')
 page.locator('[data-plan="operation"]').select_option('marketing')
 business=page.evaluate('LOONIE_V12.project(LOONIE_V12.get(),LOONIE_V12.get().plan,0)')
 assert business['ok'] and business['summary']['business']['revenue']>0
 page.evaluate('document.querySelectorAll(".overlay").forEach(e=>e.remove())');page.locator('#ll-commit').click()
 last=page.evaluate('LOONIE_V12.get().last')
 assert last['business']['revenue']>0 and last['business']['cost']>0
 assert abs(last['business']['profit']-(last['business']['revenue']-last['business']['cost']))<.001
 c=page.evaluate('LOONIE_V12.get()');assert abs(c['company']['totalProfit']+900-last['business']['profit'])<.001
 route('life12-business');assert 'is operating' in page.locator('#screen').inner_text()
 route('life12');page.screenshot(path=str(R/'qa-life12-business.png'),full_page=True)
 # Large monthly deficit must create debt with zero negative cash; no negative savings.
 page.evaluate('''()=>{const c=LOONIE_V12.get();c.cash=0;c.savings=0;c.debt=5000;c.energy=45;c.company=null;c.plan={...c.plan,housing:'family',food:'fresh',transport:'car',work:'balanced',training:'intensive',save:600,repay:800};save()}''')
 prev=page.evaluate('LOONIE_V12.project(LOONIE_V12.get(),LOONIE_V12.get().plan,0)')
 assert prev['ok'] and prev['summary']['overdraft']>0
 result=page.evaluate('LOONIE_V12.advance(0,LOONIE_V12.get().plan)')
 assert result['ok'] and result['summary']['endingCash']==0 and result['summary']['deposit']==0
 assert result['summary']['endingDebt']>5000
 print('PASS: 3 venture choices, business revenue/costs, 1-time rewards, simulated overdraft',flush=True)
 assert not errors,errors
 b.close()
