import { useCallback, useEffect, useMemo, useState } from 'react';
import { Activity, CheckCircle2, CircleAlert, Download, Info, RefreshCw, ShieldCheck, Trash2, XCircle } from 'lucide-react';
import { clearActivityLog, getActivityLog } from '@/lib/activityLog';

const ICONS = { success: CheckCircle2, warning: CircleAlert, error: XCircle, info: Info };
const COLORS = {
  success: 'text-emerald-400 border-emerald-400/30 bg-emerald-400/10',
  warning: 'text-amber-400 border-amber-400/30 bg-amber-400/10',
  error: 'text-rose-400 border-rose-400/30 bg-rose-400/10',
  info: 'text-primary border-primary/30 bg-primary/10',
};

export default function ActivityLog() {
  const [items, setItems] = useState(() => getActivityLog());
  const [filter, setFilter] = useState('all');
  const [notice, setNotice] = useState('');

  const refresh = useCallback(() => setItems(getActivityLog()), []);
  useEffect(() => {
    window.addEventListener('mj-ai-activity-updated', refresh);
    window.addEventListener('storage', refresh);
    return () => {
      window.removeEventListener('mj-ai-activity-updated', refresh);
      window.removeEventListener('storage', refresh);
    };
  }, [refresh]);

  const filtered = useMemo(() => filter === 'all' ? items : items.filter((item) => item.status === filter), [items, filter]);

  const exportLog = () => {
    const blob = new Blob([JSON.stringify(items, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `mj-ai-activity-${new Date().toISOString().slice(0, 10)}.json`;
    link.click();
    URL.revokeObjectURL(url);
    setNotice('Activity log exported to this device.');
  };

  const clearLog = () => {
    if (!window.confirm('Clear all locally saved MJ AI activity entries on this device?')) return;
    clearActivityLog();
    setItems([]);
    setNotice('Local activity log cleared.');
  };

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="eyebrow mb-2">Transparency center</p>
          <h1 className="font-heading text-2xl font-semibold tracking-tight text-foreground sm:text-3xl">Activity & Trust Log</h1>
          <p className="mt-2 max-w-2xl text-[13px] leading-relaxed text-muted-foreground">See actions recorded by this app, including navigation and task changes. This log is stored locally in this browser; it is not a complete operating-system surveillance feed and does not automatically record every PC or phone activity.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button type="button" onClick={refresh} className="btn-ghost px-3 py-2 text-xs"><RefreshCw className="h-3.5 w-3.5" /> Refresh</button>
          <button type="button" onClick={exportLog} className="btn-ghost px-3 py-2 text-xs"><Download className="h-3.5 w-3.5" /> Export JSON</button>
          <button type="button" onClick={clearLog} className="btn-ghost px-3 py-2 text-xs"><Trash2 className="h-3.5 w-3.5" /> Clear log</button>
        </div>
      </header>

      <div className="grid gap-3 sm:grid-cols-3">
        <div className="panel p-4"><p className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground">Saved entries</p><p className="mt-2 font-heading text-2xl text-foreground">{items.length}</p></div>
        <div className="panel p-4"><p className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground">Successful actions</p><p className="mt-2 font-heading text-2xl text-emerald-400">{items.filter((item) => item.status === 'success').length}</p></div>
        <div className="panel p-4"><p className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground">Storage</p><p className="mt-2 flex items-center gap-2 font-heading text-lg text-foreground"><ShieldCheck className="h-4 w-4 text-primary" /> This browser only</p></div>
      </div>

      {notice ? <p role="status" className="rounded-xl border border-primary/30 bg-primary/10 px-4 py-3 text-[13px] text-foreground/90">{notice}</p> : null}

      <section className="space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 className="font-heading text-sm text-foreground">Recent activity</h2>
          <select className="field max-w-44" value={filter} onChange={(event) => setFilter(event.target.value)} aria-label="Filter activity status">
            <option value="all">All statuses</option><option value="success">Success</option><option value="info">Info</option><option value="warning">Warning</option><option value="error">Error</option>
          </select>
        </div>
        {filtered.length ? filtered.map((item) => {
          const Icon = ICONS[item.status] || Info;
          return <article key={item.id} className="panel flex gap-3 p-4">
            <span className={`mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border ${COLORS[item.status] || COLORS.info}`}><Icon className="h-4 w-4" /></span>
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2"><p className="text-sm font-medium text-foreground">{item.title}</p><span className="chip">{item.category}</span></div>
              {item.detail ? <p className="mt-1 break-words text-[12px] leading-relaxed text-muted-foreground">{item.detail}</p> : null}
              <p className="mt-2 text-[10px] text-muted-foreground">{new Date(item.at).toLocaleString()} · {item.status}</p>
            </div>
          </article>;
        }) : <div className="panel p-8 text-center"><Activity className="mx-auto h-7 w-7 text-primary" /><p className="mt-3 text-sm text-foreground">No activity recorded yet</p><p className="mt-1 text-xs text-muted-foreground">Use the dashboard or create a task; supported actions will appear here.</p></div>}
      </section>
    </div>
  );
}
