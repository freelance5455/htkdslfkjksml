import { useCallback, useEffect, useMemo, useState } from 'react';
import { Bell, CheckCircle2, Clock3, Plus, RefreshCw, Trash2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { recordActivity } from '@/lib/activityLog';

const blank = { title: '', notes: '', due_at: '', priority: 'normal', recurrence: 'none', reminder_enabled: true };

function formatDate(value) {
  if (!value) return 'No due date';
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toLocaleString();
}

function nextOccurrence(value, recurrence) {
  if (!value || recurrence === 'none') return null;
  const date = new Date(value);
  if (recurrence === 'daily') date.setDate(date.getDate() + 1);
  if (recurrence === 'weekly') date.setDate(date.getDate() + 7);
  return date.toISOString();
}

export default function Tasks() {
  const [tasks, setTasks] = useState([]);
  const [form, setForm] = useState(blank);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [notice, setNotice] = useState('');
  const [notifications, setNotifications] = useState(typeof Notification !== 'undefined' ? Notification.permission : 'unsupported');

  const load = useCallback(async () => {
    try {
      const result = await base44.entities.TaskItem.filter({}, { sort: 'due_at', limit: 100 });
      setTasks(result.items || []);
    } catch {
      setNotice('Tasks could not load. Check that the latest app schema is published.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const notifyDueTasks = useCallback(async () => {
    if (typeof Notification === 'undefined' || Notification.permission !== 'granted') return;
    const now = Date.now();
    for (const task of tasks) {
      if (task.status === 'done' || !task.reminder_enabled || !task.due_at) continue;
      const due = new Date(task.due_at).getTime();
      if (Number.isNaN(due) || due > now || (task.last_notified_at && now - new Date(task.last_notified_at).getTime() < 12 * 60 * 60 * 1000)) continue;
      try {
        new Notification('MJ AI reminder', { body: task.title, tag: task.id });
        await base44.entities.TaskItem.update(task.id, { last_notified_at: new Date().toISOString() });
        setTasks((prev) => prev.map((item) => item.id === task.id ? { ...item, last_notified_at: new Date().toISOString() } : item));
      } catch { /* browser or permission may block notifications */ }
    }
  }, [tasks]);

  useEffect(() => {
    notifyDueTasks();
    const id = window.setInterval(notifyDueTasks, 60000);
    return () => window.clearInterval(id);
  }, [notifyDueTasks]);

  const openTasks = useMemo(() => tasks.filter((task) => task.status !== 'done'), [tasks]);
  const completed = tasks.length - openTasks.length;

  const enableNotifications = async () => {
    if (typeof Notification === 'undefined') {
      setNotice('This browser does not support desktop notifications.');
      return;
    }
    const permission = await Notification.requestPermission();
    setNotifications(permission);
    setNotice(permission === 'granted' ? 'Reminders enabled while MJ AI is open.' : 'Notifications were not allowed. You can still use the task list.');
  };

  const createTask = async (event) => {
    event.preventDefault();
    if (!form.title.trim()) return;
    setSaving(true);
    try {
      const created = await base44.entities.TaskItem.create({
        ...form,
        title: form.title.trim().slice(0, 160),
        notes: form.notes.trim().slice(0, 1000),
        due_at: form.due_at ? new Date(form.due_at).toISOString() : '',
        status: 'open',
      });
      setTasks((prev) => [...prev, created]);
      recordActivity({ title: 'Task created', detail: created.title || form.title.trim(), category: 'task', status: 'success' });
      setForm(blank);
      setNotice('Task saved.');
    } catch {
      recordActivity({ title: 'Task creation failed', detail: form.title.trim(), category: 'task', status: 'error' });
      setNotice('Task could not be saved. Please try again.');
    } finally { setSaving(false); }
  };

  const toggleDone = async (task) => {
    try {
      if (task.status !== 'done' && task.recurrence !== 'none' && task.due_at) {
        const nextDue = nextOccurrence(task.due_at, task.recurrence);
        const updated = await base44.entities.TaskItem.update(task.id, { status: 'open', due_at: nextDue, last_notified_at: '' });
        setTasks((prev) => prev.map((item) => item.id === task.id ? updated : item));
        recordActivity({ title: 'Recurring task rescheduled', detail: task.title, category: 'task', status: 'success' });
      } else {
        const updated = await base44.entities.TaskItem.update(task.id, { status: task.status === 'done' ? 'open' : 'done' });
        setTasks((prev) => prev.map((item) => item.id === task.id ? updated : item));
        recordActivity({ title: updated.status === 'done' ? 'Task completed' : 'Task reopened', detail: task.title, category: 'task', status: 'success' });
      }
    } catch { recordActivity({ title: 'Task update failed', detail: task.title, category: 'task', status: 'error' }); setNotice('Could not update this task.'); }
  };

  const deleteTask = async (task) => {
    try {
      await base44.entities.TaskItem.delete(task.id);
      setTasks((prev) => prev.filter((item) => item.id !== task.id));
      recordActivity({ title: 'Task deleted', detail: task.title, category: 'task', status: 'success' });
    } catch { recordActivity({ title: 'Task deletion failed', detail: task.title, category: 'task', status: 'error' }); setNotice('Could not delete this task.'); }
  };

  if (loading) return <div className="h-40 animate-pulse rounded-2xl bg-secondary/20" />;

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="eyebrow mb-2">Task automation</p>
          <h1 className="font-heading text-2xl font-semibold tracking-tight text-foreground sm:text-3xl">Your next move, remembered.</h1>
          <p className="mt-2 max-w-2xl text-[13px] leading-relaxed text-muted-foreground">Create tasks, set due dates, and enable browser reminders. Reminders run while this dashboard is open; they are not a background service when the browser is closed.</p>
        </div>
        <button type="button" onClick={enableNotifications} className="btn-ghost px-4 py-3 text-[13px]">
          <Bell className="h-4 w-4" /> {notifications === 'granted' ? 'Reminders enabled' : 'Enable reminders'}
        </button>
      </header>

      {notice ? <p role="status" className="rounded-xl border border-primary/30 bg-primary/10 px-4 py-3 text-[13px] text-foreground/90">{notice}</p> : null}

      <section className="panel space-y-4 p-5">
        <h2 className="font-heading text-sm text-foreground">Add a task</h2>
        <form onSubmit={createTask} className="grid gap-3 sm:grid-cols-2">
          <input className="field sm:col-span-2" maxLength={160} value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="What needs to get done?" required />
          <textarea className="field min-h-20 sm:col-span-2" maxLength={1000} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} placeholder="Optional notes" />
          <label className="text-[12px] text-muted-foreground">Due date and time
            <input className="field mt-1 w-full" type="datetime-local" value={form.due_at} onChange={(e) => setForm({ ...form, due_at: e.target.value })} />
          </label>
          <label className="text-[12px] text-muted-foreground">Priority
            <select className="field mt-1 w-full" value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value })}>
              <option value="low">Low</option><option value="normal">Normal</option><option value="high">High</option>
            </select>
          </label>
          <label className="text-[12px] text-muted-foreground">Repeat
            <select className="field mt-1 w-full" value={form.recurrence} onChange={(e) => setForm({ ...form, recurrence: e.target.value })}>
              <option value="none">Does not repeat</option><option value="daily">Daily</option><option value="weekly">Weekly</option>
            </select>
          </label>
          <label className="flex items-center gap-2 text-[13px] text-foreground/90">
            <input type="checkbox" checked={form.reminder_enabled} onChange={(e) => setForm({ ...form, reminder_enabled: e.target.checked })} /> Remind me in this browser
          </label>
          <div className="sm:col-span-2">
            <button className="btn-primary px-5 py-3" type="submit" disabled={saving || !form.title.trim()}><Plus className="h-4 w-4" /> {saving ? 'Saving…' : 'Save task'}</button>
          </div>
        </form>
      </section>

      <div className="grid gap-3 sm:grid-cols-3">
        <div className="panel p-4"><p className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground">Open</p><p className="mt-2 font-heading text-2xl text-foreground">{openTasks.length}</p></div>
        <div className="panel p-4"><p className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground">Completed</p><p className="mt-2 font-heading text-2xl text-foreground">{completed}</p></div>
        <div className="panel p-4"><p className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground">Reminder engine</p><p className="mt-2 font-heading text-lg text-foreground">{notifications === 'granted' ? 'Active' : 'Permission needed'}</p></div>
      </div>

      <section className="space-y-3">
        <div className="flex items-center justify-between"><h2 className="font-heading text-sm text-foreground">Task queue</h2><button type="button" className="btn-ghost px-3 py-2 text-xs" onClick={load}><RefreshCw className="h-3.5 w-3.5" /> Refresh</button></div>
        {tasks.length ? tasks.slice().sort((a, b) => Number(a.status === 'done') - Number(b.status === 'done') || (a.due_at || '9999').localeCompare(b.due_at || '9999')).map((task) => (
          <article key={task.id} className={`panel flex flex-wrap items-center gap-3 p-4 ${task.status === 'done' ? 'opacity-60' : ''}`}>
            <button type="button" onClick={() => toggleDone(task)} aria-label={task.status === 'done' ? 'Reopen task' : 'Complete task'} className="rounded-lg border border-border/60 p-2 text-primary">{task.status === 'done' ? <CheckCircle2 className="h-4 w-4" /> : <Clock3 className="h-4 w-4" />}</button>
            <div className="min-w-0 flex-1">
              <p className={`text-sm text-foreground ${task.status === 'done' ? 'line-through' : ''}`}>{task.title}</p>
              {task.notes ? <p className="mt-1 text-xs text-muted-foreground">{task.notes}</p> : null}
              <p className="mt-1 text-[11px] text-muted-foreground">{formatDate(task.due_at)} · {task.priority || 'normal'} priority{task.recurrence && task.recurrence !== 'none' ? ` · repeats ${task.recurrence}` : ''}</p>
            </div>
            <button type="button" onClick={() => deleteTask(task)} className="rounded-lg border border-border/50 p-2 text-muted-foreground hover:text-destructive" aria-label="Delete task"><Trash2 className="h-4 w-4" /></button>
          </article>
        )) : <div className="panel p-8 text-center text-[13px] text-muted-foreground">No tasks yet. Add a task above to get started.</div>}
      </section>
    </div>
  );
}