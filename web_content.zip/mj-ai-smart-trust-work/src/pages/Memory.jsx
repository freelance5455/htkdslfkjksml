import { useMemo, useState } from 'react';
import { Brain, Loader2, Pin, Plus, Trash2 } from 'lucide-react';
import { useAssistant } from '@/lib/AssistantContext';
import { cn } from '@/lib/utils';

const KINDS = [
  { value: 'fact', label: 'Fact' },
  { value: 'preference', label: 'Preference' },
  { value: 'event', label: 'Event' },
];

export default function Memory() {
  const { loading, memories, settings, addMemory, removeMemory, toggleMemoryPin } = useAssistant();
  const [content, setContent] = useState('');
  const [kind, setKind] = useState('fact');
  const [saving, setSaving] = useState(false);

  const sorted = useMemo(
    () => [...memories].sort((a, b) => Number(Boolean(b.pinned)) - Number(Boolean(a.pinned))),
    [memories],
  );

  const submit = async (event) => {
    event.preventDefault();
    const value = content.trim();
    if (!value) return;
    setSaving(true);
    await addMemory({ content: value, kind, source: 'manual' });
    setContent('');
    setSaving(false);
  };

  if (loading || !settings) {
    return <div className="h-40 animate-pulse rounded-2xl bg-secondary/20" />;
  }

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="eyebrow mb-2">Memory circuit</p>
          <h1 className="font-heading text-2xl font-semibold tracking-tight text-foreground sm:text-3xl">It remembers you.</h1>
          <p className="mt-2 max-w-2xl text-[13px] leading-relaxed text-muted-foreground">
            Your name, your day, the things you care about — stored on your account and fed back to your character every time you talk.
          </p>
        </div>
        <div className="panel px-4 py-3">
          <p className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground">Memory permission</p>
          <p className="text-[12px] text-foreground/90">Approval required — MJ AI never saves suggested memories automatically.</p>
        </div>
      </header>

      <form onSubmit={submit} className="panel flex flex-col gap-3 p-5 sm:flex-row sm:items-center">
        <input
          value={content}
          onChange={(event) => setContent(event.target.value)}
          placeholder="Remember that my calls are usually in the morning…"
          className="field"
          aria-label="New memory"
        />
        <select value={kind} onChange={(event) => setKind(event.target.value)} className="field sm:w-40" aria-label="Memory kind">
          {KINDS.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
        <button type="submit" disabled={saving || !content.trim()} className="btn-primary px-5 py-3">
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
          Add
        </button>
      </form>

      <div className="flex items-center gap-3">
        <span className="chip">
          <Brain className="h-3.5 w-3.5" /> {memories.length} memories
        </span>
        <span className="text-[12px] text-muted-foreground">Pinned memories are always handed to your character first.</span>
      </div>

      <div className="grid gap-3 md:grid-cols-2">
        {sorted.map((memory) => (
          <article key={memory.id} className={cn('panel flex flex-col gap-3 p-5', memory.pinned && 'border-primary/40')}>
            <p className="text-[14px] leading-relaxed text-foreground">{memory.content}</p>
            <div className="mt-auto flex items-center gap-2">
              <span className="chip">{memory.kind}</span>
              <span className="chip">{memory.source === 'ai' ? 'captured in conversation' : 'added by you'}</span>
              <button
                type="button"
                onClick={() => toggleMemoryPin(memory)}
                className={cn('ml-auto rounded-lg border border-border/60 p-2 transition hover:text-foreground', memory.pinned ? 'text-primary' : 'text-muted-foreground')}
                aria-label={memory.pinned ? 'Unpin memory' : 'Pin memory'}
              >
                <Pin className="h-3.5 w-3.5" />
              </button>
              <button
                type="button"
                onClick={() => removeMemory(memory.id)}
                className="rounded-lg border border-border/60 p-2 text-muted-foreground transition hover:border-destructive/50 hover:text-destructive"
                aria-label="Delete memory"
              >
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            </div>
          </article>
        ))}
      </div>

      {!memories.length ? (
        <div className="panel flex flex-col items-center gap-3 p-10 text-center">
          <span className="flex h-12 w-12 items-center justify-center rounded-2xl border border-primary/30 bg-primary/10">
            <Brain className="h-5 w-5 text-primary" />
          </span>
          <p className="font-heading text-sm text-foreground">Nothing remembered yet</p>
          <p className="max-w-md text-[13px] text-muted-foreground">
            Add a memory above, or tell your character something durable about yourself. It will ask before saving a suggested memory.
          </p>
        </div>
      ) : null}
    </div>
  );
}