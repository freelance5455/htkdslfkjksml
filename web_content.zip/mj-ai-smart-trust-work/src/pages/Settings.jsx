import { useEffect, useState } from 'react';
import { LogOut, Mic, MonitorSmartphone, ShieldCheck, Sliders, Trash2, Volume2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useAssistant } from '@/lib/AssistantContext';
import AvatarToggle from '@/components/avatar/AvatarToggle';
import Toggle from '@/components/dashboard/Toggle';
import CompanionBadge from '@/components/dashboard/CompanionBadge';

export default function Settings() {
  const { loading, user, settings, activeCharacter, updateSettings, clearHistory, clearMemories } = useAssistant();
  const [wakeWord, setWakeWord] = useState('');
  const [notice, setNotice] = useState('');
  const [availableVoices, setAvailableVoices] = useState([]);
  const [voicePreviewing, setVoicePreviewing] = useState(false);

  useEffect(() => {
    if (typeof window === 'undefined' || !window.speechSynthesis) return undefined;
    const synth = window.speechSynthesis;
    const loadVoices = () => setAvailableVoices(synth.getVoices().map((voice) => ({
      name: voice.name, lang: voice.lang, voiceURI: voice.voiceURI,
    })));
    loadVoices();
    synth.addEventListener?.('voiceschanged', loadVoices);
    return () => synth.removeEventListener?.('voiceschanged', loadVoices);
  }, []);

  if (loading || !settings) {
    return <div className="h-40 animate-pulse rounded-2xl bg-secondary/20" />;
  }

  const flash = (message) => {
    setNotice(message);
    setTimeout(() => setNotice(''), 2400);
  };

  return (
    <div className="space-y-6">
      <header>
        <p className="eyebrow mb-2">Settings circuit</p>
        <h1 className="font-heading text-2xl font-semibold tracking-tight text-foreground sm:text-3xl">Full control over how it behaves.</h1>
        <p className="mt-2 max-w-2xl text-[13px] leading-relaxed text-muted-foreground">
          How it listens, how it sounds, and what it is allowed to remember. Everything here saves to your account immediately.
        </p>
      </header>

      {notice ? <p className="rounded-xl border border-primary/40 bg-primary/10 px-4 py-3 text-[13px] text-foreground/90">{notice}</p> : null}

      <div className="grid gap-5 lg:grid-cols-2">
        <section className="panel space-y-5 p-6">
          <div className="flex items-center gap-3">
            <Sliders className="h-4 w-4 text-primary" />
            <h2 className="font-heading text-sm text-foreground">Avatar core</h2>
          </div>
          <p className="text-[13px] leading-relaxed text-muted-foreground">
            Choose which core Stonic wears. This follows you across the dashboard and overrides the character default.
          </p>
          <AvatarToggle value={settings.avatar_gender} onChange={(value) => updateSettings({ avatar_gender: value })} className="" />
          <div className="border-t border-border/40 pt-4 text-[12px] text-muted-foreground">
            Active character: <span className="text-foreground/90">{activeCharacter?.name || 'none'}</span>
          </div>
        </section>

        <section className="panel space-y-5 p-6">
          <div className="flex items-center gap-3">
            <Sliders className="h-4 w-4 text-primary" />
            <h2 className="font-heading text-sm text-foreground">Interface themes</h2>
          </div>
          <label className="block">
            <span className="text-[12px] uppercase tracking-[0.18em] text-muted-foreground">Choose a theme</span>
            <select className="field mt-2 w-full" value={settings.theme || 'cyber-cyan'} onChange={(event) => updateSettings({ theme: event.target.value })}>
              <option value="cyber-cyan">Cyber Cyan · classic hologram</option>
              <option value="arc-reactor">Arc Reactor · blue steel</option>
              <option value="violet-nebula">Violet Nebula · purple glow</option>
              <option value="emerald-matrix">Emerald Matrix · green terminal</option>
              <option value="solar-gold">Solar Gold · warm amber</option>
              <option value="rose-plasma">Rose Plasma · pink neon</option>
            </select>
            <p className="mt-2 text-[12px] text-muted-foreground">Theme is saved to your account and follows you around the app.</p>
          </label>
        </section>

        <section className="panel space-y-5 p-6">
          <div className="flex items-center gap-3">
            <Mic className="h-4 w-4 text-primary" />
            <h2 className="font-heading text-sm text-foreground">Speech recognition language</h2>
          </div>
          <select className="field w-full" value={settings.speech_language || 'auto'} onChange={(event) => updateSettings({ speech_language: event.target.value })}>
            <option value="auto">Auto · device language</option>
            <option value="hi">Hindi · हिन्दी</option>
            <option value="en">English</option>
          </select>
          <p className="text-[12px] text-muted-foreground">Controls microphone transcription language where your browser supports it.</p>
        </section>

        <section className="panel space-y-5 p-6">
          <div className="flex items-center gap-3">
            <Volume2 className="h-4 w-4 text-primary" />
            <h2 className="font-heading text-sm text-foreground">Voice</h2>
          </div>
          <div className="flex items-center justify-between gap-4">
            <div>
              <p className="text-[13px] text-foreground/90">Speak replies out loud</p>
              <p className="text-[12px] text-muted-foreground">Uses your browser&apos;s speech engine.</p>
            </div>
            <Toggle checked={Boolean(settings.voice_enabled)} onChange={(value) => updateSettings({ voice_enabled: value })} label="Voice replies" className="" />
          </div>
          <label className="block">
            <span className="text-[12px] uppercase tracking-[0.18em] text-muted-foreground">Voice personality</span>
            <select
              className="field mt-2 w-full"
              value={settings.voice_profile || 'mayra'}
              onChange={(event) => {
                const profile = event.target.value;
                const presets = {
                  maya: { speech_rate: 1.0, speech_pitch: 1.12 },
                  mayra: { speech_rate: 0.96, speech_pitch: 1.04 },
                  jarvis: { speech_rate: 0.94, speech_pitch: 0.82 },
                  stonic: { speech_rate: 0.98, speech_pitch: 0.92 },
                  friday: { speech_rate: 1.02, speech_pitch: 1.08 },
                };
                updateSettings({ voice_profile: profile, ...presets[profile] });
              }}
            >
              <option value="maya">Maya · warm, friendly female</option>
              <option value="mayra">Mayra · soft, natural female</option>
              <option value="jarvis">Jarvis · deep, precise assistant</option>
              <option value="stonic">Stonic · calm, confident assistant</option>
              <option value="friday">Friday · crisp, smart female</option>
            </select>
            <p className="mt-2 text-[12px] leading-relaxed text-muted-foreground">These are inspired styles, not exact character voice copies. Choose an installed system voice below for more control.</p>
          </label>
          <label className="block">
            <span className="text-[12px] uppercase tracking-[0.18em] text-muted-foreground">Installed device voice</span>
            <select
              className="field mt-2 w-full"
              value={settings.voice_uri || ''}
              onChange={(event) => updateSettings({ voice_uri: event.target.value })}
            >
              <option value="">Automatic · match language and personality</option>
              {availableVoices.map((voice) => (
                <option key={`${voice.voiceURI}-${voice.lang}`} value={voice.voiceURI}>
                  {voice.name} · {voice.lang}
                </option>
              ))}
            </select>
            <p className="mt-2 text-[12px] text-muted-foreground">{availableVoices.length ? `${availableVoices.length} system voices found on this device.` : 'Voice list loads from your browser or operating system. Install additional voices in Windows language settings if needed.'}</p>
          </label>
          <button
            type="button"
            className="btn-ghost px-4 py-2.5 text-[13px]"
            onClick={() => {
              if (!window.speechSynthesis) { flash('This browser does not support speech output. Try Chrome or Edge.'); return; }
              window.speechSynthesis.cancel();
              const utterance = new SpeechSynthesisUtterance('Hello, I am MJ AI. Namaste! Main aapki kis tarah madad kar sakta hoon?');
              const chosen = availableVoices.find((voice) => voice.voiceURI === settings.voice_uri);
              const nativeVoice = window.speechSynthesis.getVoices().find((voice) => voice.voiceURI === chosen?.voiceURI);
              if (nativeVoice) utterance.voice = nativeVoice;
              utterance.rate = Number(settings.speech_rate || 1);
              utterance.pitch = Number(settings.speech_pitch || 1.05);
              utterance.onstart = () => setVoicePreviewing(true);
              utterance.onend = () => setVoicePreviewing(false);
              utterance.onerror = () => setVoicePreviewing(false);
              window.speechSynthesis.speak(utterance);
            }}
          >
            <Volume2 className="h-4 w-4" /> {voicePreviewing ? 'Preview playing…' : 'Preview selected voice'}
          </button>
          <label className="block">
            <span className="text-[12px] uppercase tracking-[0.18em] text-muted-foreground">Speech rate · {Number(settings.speech_rate).toFixed(2)}</span>
            <input
              type="range"
              min="0.6"
              max="1.6"
              step="0.05"
              value={settings.speech_rate}
              onChange={(event) => updateSettings({ speech_rate: Number(event.target.value) })}
              className="mt-2 w-full accent-[hsl(var(--primary))]"
            />
          </label>
          <label className="block">
            <span className="text-[12px] uppercase tracking-[0.18em] text-muted-foreground">Pitch · {Number(settings.speech_pitch).toFixed(2)}</span>
            <input
              type="range"
              min="0.7"
              max="1.5"
              step="0.05"
              value={settings.speech_pitch}
              onChange={(event) => updateSettings({ speech_pitch: Number(event.target.value) })}
              className="mt-2 w-full accent-[hsl(var(--primary))]"
            />
          </label>
        </section>

        <section className="panel space-y-5 p-6">
          <div className="flex items-center gap-3">
            <Mic className="h-4 w-4 text-primary" />
            <h2 className="font-heading text-sm text-foreground">Listening</h2>
          </div>
          <div className="space-y-3">
            <button
              type="button"
              onClick={() => updateSettings({ listen_mode: 'push' })}
              className={`w-full rounded-xl border px-4 py-3 text-left text-[13px] transition ${settings.listen_mode === 'push' ? 'border-primary/50 bg-primary/10 text-foreground' : 'border-border/60 text-muted-foreground hover:text-foreground'}`}
            >
              Push to talk — hold a press, then speak. Works in this browser.
            </button>
            <div className="rounded-xl border border-border/50 bg-secondary/10 px-4 py-3">
              <div className="flex items-center justify-between gap-3">
                <p className="text-[13px] text-foreground/90">Always listening on the wake word</p>
                <CompanionBadge note="Always-on wake-word listening requires the Windows companion app." />
              </div>
              <p className="mt-2 text-[12px] leading-relaxed text-muted-foreground">
                A browser tab cannot keep the microphone open in the background, so this stays off here. The Windows companion app holds the microphone instead.
              </p>
            </div>
          </div>
          <div>
            <label className="text-[12px] uppercase tracking-[0.18em] text-muted-foreground" htmlFor="wake-word">Wake word</label>
            <div className="mt-2 flex gap-3">
              <input
                id="wake-word"
                className="field"
                value={wakeWord || settings.wake_word || ''}
                onChange={(event) => setWakeWord(event.target.value)}
                placeholder="Hey Stonic"
              />
              <button
                type="button"
                className="btn-ghost px-4 py-3 text-[13px]"
                onClick={async () => {
                  if (!wakeWord.trim()) return;
                  await updateSettings({ wake_word: wakeWord.trim() });
                  setWakeWord('');
                  flash('Wake word saved. The companion app listens for it.');
                }}
              >
                Save
              </button>
            </div>
            <p className="mt-2 text-[12px] text-muted-foreground">Used by the Windows companion app for wake-word listening.</p>
          </div>
        </section>

        <section className="panel space-y-5 p-6">
          <div className="flex items-center gap-3">
            <ShieldCheck className="h-4 w-4 text-primary" />
            <h2 className="font-heading text-sm text-foreground">MJ AI Trust Mode</h2>
          </div>
          <p className="text-[13px] leading-relaxed text-muted-foreground">Honesty, clear uncertainty, privacy protection, source integrity, and a self-check before replies. Trust Mode is enabled by default.</p>
          <div className="flex items-center justify-between gap-4">
            <div>
              <p className="text-[13px] text-foreground/90">Trust Mode</p>
              <p className="text-[12px] text-muted-foreground">Never invent facts or pretend an action succeeded.</p>
            </div>
            <Toggle checked={settings.trust_mode_enabled !== false} onChange={(value) => updateSettings({ trust_mode_enabled: value })} label="Trust Mode" className="" />
          </div>
          <div className="flex items-center justify-between gap-4 border-t border-border/40 pt-4">
            <div>
              <p className="text-[13px] text-foreground/90">Confirm important actions</p>
              <p className="text-[12px] text-muted-foreground">Ask first before consequential actions, data sharing, or irreversible changes.</p>
            </div>
            <Toggle checked={settings.confirm_sensitive_actions !== false} onChange={(value) => updateSettings({ confirm_sensitive_actions: value })} label="Confirm actions" className="" />
          </div>
        </section>

        <section className="panel space-y-5 p-6">
          <div className="flex items-center gap-3">
            <MonitorSmartphone className="h-4 w-4 text-accent" />
            <h2 className="font-heading text-sm text-foreground">Memory &amp; data</h2>
          </div>
          <div className="flex items-center justify-between gap-4">
            <div>
              <p className="text-[13px] text-foreground/90">Live web context</p>
              <p className="text-[12px] text-muted-foreground">Let MJ AI look up current information for news, prices, and recent events.</p>
            </div>
            <Toggle checked={settings.web_search_enabled !== false} onChange={(value) => updateSettings({ web_search_enabled: value })} label="Live web context" className="" />
          </div>
          <div className="border-t border-border/40 pt-4">
            <p className="text-[13px] text-foreground/90">Memory approval required</p>
            <p className="mt-1 text-[12px] text-muted-foreground">MJ AI can suggest useful facts, but saves them only after you choose “Approve &amp; save”. You can also add or delete memories manually.</p>
          </div>
          <div className="flex flex-wrap gap-3 border-t border-border/40 pt-4">
            <button
              type="button"
              className="btn-ghost px-4 py-2.5 text-[13px]"
              onClick={async () => {
                await clearHistory();
                flash('Conversation history cleared.');
              }}
            >
              <Trash2 className="h-4 w-4" /> Clear chat history
            </button>
            <button
              type="button"
              className="btn-ghost px-4 py-2.5 text-[13px]"
              onClick={async () => {
                await clearMemories();
                flash('All memories deleted.');
              }}
            >
              <Trash2 className="h-4 w-4" /> Delete all memories
            </button>
          </div>
        </section>
      </div>

      <section className="panel flex flex-wrap items-center gap-4 p-6">
        <span className="flex h-11 w-11 items-center justify-center rounded-2xl border border-primary/30 bg-primary/10">
          {user?.role === 'admin' ? <ShieldCheck className="h-5 w-5 text-primary" /> : <Mic className="h-5 w-5 text-primary" />}
        </span>
        <div>
          <p className="font-heading text-sm text-foreground">{user?.full_name || 'Signed in'}</p>
          <p className="text-[12px] text-muted-foreground">{user?.email} · {user?.role === 'admin' ? 'Admin — can manage users and all data' : 'User'}</p>
        </div>
        <div className="ml-auto flex items-center gap-3">
          <span className="chip">Project owner · Sk Badal</span>
          <button type="button" onClick={() => base44.auth.logout('/login')} className="btn-ghost px-4 py-2.5 text-[13px]">
            <LogOut className="h-4 w-4" /> Log out
          </button>
        </div>
      </section>
    </div>
  );
}