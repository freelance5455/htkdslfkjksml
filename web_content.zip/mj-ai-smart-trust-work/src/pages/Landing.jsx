import LandingNav from '@/components/landing/LandingNav';
import Hero from '@/components/landing/Hero';
import AvatarShowcase from '@/components/landing/AvatarShowcase';
import VoiceSection from '@/components/landing/VoiceSection';
import SystemCore from '@/components/landing/SystemCore';
import CharactersSection from '@/components/landing/CharactersSection';
import WorldSection from '@/components/landing/WorldSection';
import RemoteSection from '@/components/landing/RemoteSection';
import LoginPanel from '@/components/landing/LoginPanel';
import LandingFooter from '@/components/landing/LandingFooter';

export default function Landing() {
  return (
    <div className="min-h-screen">
      <LandingNav />
      <main>
        <Hero />
        <AvatarShowcase />
        <VoiceSection />
        <SystemCore />
        <CharactersSection />
        <WorldSection />
        <RemoteSection />
        <LoginPanel />
      </main>
      <LandingFooter />
    </div>
  );
}