import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Brain, Puzzle, Settings as SettingsIcon, Sparkles, Scan, ShieldCheck, Waves, Eye, EyeOff } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { invokeFunction } from '@/lib/invoke';
import { useAssistant } from '@/lib/AssistantContext';
import useSpeech from '@/hooks/useSpeech';
import ParticleFigure from '@/components/avatar/ParticleFigure';
import AvatarToggle from '@/components/avatar/AvatarToggle';
import VoiceConsole from '@/components/dashboard/VoiceConsole';
import ChatThread from '@/components/dashboard/ChatThread';
import CircuitStat from '@/components/dashboard/CircuitStat';

const QUICK_PROMPTS = [
  'Who are you, really?',
  'Remember that I am building MJ AI.',
  'What can you actually do right now?',
  'Open my music app for me.',
];

export default function Character() {
  const { loading, user, settings, memories, skills, activeCharacter, setAvatarGender, rememberAiMemories } = useAssistant();
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [researchStatus, setResearchStatus] = useState('');
  const [pendingMemories, setPendingMemories] = useState([]);
  const [memoryNotice, setMemoryNotice] = useState('');
  const [hologramMode, setHologramMode] = useState(true);
  const [hologramDetail, setHologramDetail] = useState('full');
  const busyRef = useRef(false);
  const sendRef = useRef(null);
  const greetedRef = useRef(false);

  const enabledSkills = useMemo(() => {
    const on = settings?.enabled_skills || [];
    return skills.filter((skill) => on.includes(skill.key));
  }, [settings, skills]);

  const speech = useSpeech({
    onFinal: (text) => sendRef.current?.(text),
    rate: settings?.speech_rate ?? 1,
    pitch: settings?.speech_pitch ?? 1.05,
    voiceEnabled: settings?.voice_enabled ?? true,
    voiceProfile: settings?.voice_profile || 'mayra',
    voiceURI: settings?.voice_uri || '',
    language: settings?.speech_language || 'auto',
  });
  const speakRef = useRef(speech.speak);
  speakRef.current = speech.speak;

  useEffect(() => {
    if (!user?.id) return;
    base44.entities.ChatMessage.filter({ created_by_id: user.id }, { sort: 'created_date', limit: 40 })
      .then((page) => setMessages(page.items || []))
      .catch(() => setMessages([]));
  }, [user?.id]);

  const send = useCallback(async (rawText) => {
    const content = (rawText ?? input).trim();
    if (!content || busyRef.current || !settings) return;
    setInput('');
    setError('');
    setResearchStatus('');
    busyRef.current = true;
    setBusy(true);
    try {
      const userMessage = await base44.entities.ChatMessage.create({ role: 'user', content });
      setMessages((prev) => [...prev, userMessage]);

      const history = [...messages, userMessage]
        .slice(-10)
        .map((message) => ({ role: message.role, content: message.content }));

      const data = await invokeFunction('chatWithStonic', {
        message: content,
        character: activeCharacter
          ? {
              name: activeCharacter.name,
              persona: activeCharacter.persona,
              tone: activeCharacter.tone,
              traits: activeCharacter.traits || [],
              instructions: activeCharacter.instructions || '',
              avatar_gender: settings.avatar_gender,
            }
          : { name: 'Stonic', avatar_gender: settings.avatar_gender },
        memories: memories.slice().sort((a, b) => Number(Boolean(b.pinned)) - Number(Boolean(a.pinned))).slice(0, 40).map((memory) => ({ content: memory.content })),
        webSearch: settings.web_search_enabled !== false,
        trustMode: settings.trust_mode_enabled !== false,
        confirmSensitiveActions: settings.confirm_sensitive_actions !== false,
        history,
        skills: enabledSkills.map((skill) => `${skill.name}${skill.mode === 'companion' ? ' (needs companion app)' : ''}`),
      });

      setResearchStatus(data?.researchStatus || '');
      const reply = data?.reply || 'I did not catch that one. Say it again?';
      const assistantMessage = await base44.entities.ChatMessage.create({
        role: 'assistant',
        content: reply,
        character_name: activeCharacter?.name || 'Stonic',
      });
      setMessages((prev) => [...prev, assistantMessage]);
      speakRef.current(reply);
      if (data?.memories?.length) {
        const existing = new Set(memories.map((memory) => String(memory.content || '').trim().toLowerCase()));
        const candidates = data.memories.filter((memory) => {
          const content = String(memory?.content || '').trim();
          return content && !existing.has(content.toLowerCase());
        });
        setPendingMemories((prev) => {
          const seen = new Set(prev.map((memory) => String(memory.content || '').trim().toLowerCase()));
          return [...prev, ...candidates.filter((memory) => !seen.has(String(memory.content || '').trim().toLowerCase()))].slice(-6);
        });
      }
    } catch (err) {
      const text = String(err?.message || '');
      setError(
        /limit of integrations|429/i.test(text)
          ? 'Your workspace AI limit for this month is used up, so Stonic cannot think right now. Upgrade in Plan and billing, or wait for the monthly reset.'
          : 'Stonic could not reach its mind just now. Check your connection and try again.',
      );
    } finally {
      busyRef.current = false;
      setBusy(false);
    }
  }, [input, settings, activeCharacter, memories, messages, enabledSkills, rememberAiMemories]);

  useEffect(() => {
    sendRef.current = send;
  }, [send]);

  const exportConversation = () => {
    const payload = messages.map(({ role, content, created_date }) => ({ role, content, created_date }));
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `mj-ai-chat-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  };

  const startAi = () => {
    setError('');
    if (!greetedRef.current) {
      greetedRef.current = true;
      speakRef.current(activeCharacter?.greeting || 'Stonic online. I am listening.');
    }
    speech.start();
  };

  const status = busy ? 'thinking' : speech.listening ? 'listening' : speech.speaking ? 'speaking' : 'idle';
  const gender = settings?.avatar_gender || 'female';

  if (loading || !settings) {
    return (
      <div className="space-y-4">
        <div className="h-8 w-56 animate-pulse rounded-lg bg-secondary/40" />
        <div className="h-[420px] animate-pulse rounded-2xl bg-secondary/20" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="eyebrow mb-2">The character</p>
          <h1 className="font-heading text-2xl font-semibold tracking-tight text-foreground sm:text-3xl">
            Meet the mind you talk to.
          </h1>
          <p className="mt-2 max-w-2xl text-[13px] leading-relaxed text-muted-foreground">
            Hit Start AI, say something, and watch it think. Four circuits shape who it is — memory, skills, character and settings.
          </p>
          <p className="mt-2 max-w-2xl text-[12px] leading-relaxed text-primary/80">
            Built to be dependable: it aims to be honest, admits uncertainty, and protects your information according to your settings.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button type="button" onClick={exportConversation} disabled={!messages.length} className="btn-ghost px-4 py-2 text-[12px] disabled:opacity-40">Export chat</button>
          <span className="chip border-primary/30 text-primary/90">Trust core · permission-based</span>
          <span className="chip">{activeCharacter?.tagline || 'Living core'}</span>
        </div>
      </header>

      <div className="grid gap-6 xl:grid-cols-[1.2fr_1fr]">
        <div className="space-y-5">
          <div className={`panel holo-stage relative overflow-hidden ${hologramMode ? 'holo-pulse' : ''}`}>
            {hologramMode ? <><div className="holo-grid" aria-hidden="true" /><div className="holo-orbit" aria-hidden="true" /><div className="holo-sweep" aria-hidden="true" /></> : null}
            <ParticleFigure gender={gender} thinking={busy} className={`relative z-[1] h-[360px] w-full sm:h-[430px] ${hologramMode ? 'drop-shadow-[0_0_18px_hsl(var(--primary)/.28)]' : ''}`} />
            <div className="pointer-events-none absolute inset-x-0 top-4 z-[5] flex items-center justify-between gap-2 px-3 sm:px-5">
              <span className="holo-badge inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-[10px] uppercase tracking-[0.15em]"><Scan className="h-3.5 w-3.5" /> {hologramMode ? 'Hologram projection' : 'Avatar view'}</span>
              <span className="holo-badge rounded-full px-3 py-1 text-[10px]">{activeCharacter?.name || 'MJ AI'}</span>
            </div>
            {hologramMode ? <div className="pointer-events-none absolute bottom-14 left-3 z-[5] space-y-1 sm:left-5"><div className="holo-badge flex items-center gap-2 rounded-lg px-2.5 py-1.5 text-[10px]"><Waves className="h-3.5 w-3.5" /> CORE {busy ? 'PROCESSING' : speech.listening ? 'LISTENING' : speech.speaking ? 'SPEAKING' : 'STANDBY'}</div><div className="holo-badge flex items-center gap-2 rounded-lg px-2.5 py-1.5 text-[10px]"><ShieldCheck className="h-3.5 w-3.5" /> TRUST MODE {settings?.trust_mode_enabled === false ? 'OFF' : 'ON'}</div></div> : null}
            <div className="absolute right-3 top-14 z-[5] flex flex-col gap-2 sm:right-5">
              <button type="button" onClick={() => setHologramMode((value) => !value)} className="holo-badge inline-flex min-h-10 items-center justify-center gap-2 rounded-full px-3 text-[11px] transition hover:brightness-125" aria-pressed={hologramMode} title="Toggle hologram effects">{hologramMode ? <Eye className="h-3.5 w-3.5" /> : <EyeOff className="h-3.5 w-3.5" />}{hologramMode ? 'Hologram ON' : 'Hologram OFF'}</button>
              <label className="holo-badge flex min-h-10 items-center gap-2 rounded-full px-3 text-[11px]"><span>Projection</span><select value={hologramDetail} onChange={(event) => setHologramDetail(event.target.value)} className="max-w-[92px] bg-transparent text-[11px] text-foreground outline-none" aria-label="Hologram projection style"><option value="full" className="bg-slate-950">Full</option><option value="soft" className="bg-slate-950">Soft</option><option value="minimal" className="bg-slate-950">Minimal</option></select></label>
            </div>
            <div className={`absolute inset-x-0 bottom-4 z-[5] flex justify-center ${hologramDetail === 'minimal' ? 'opacity-70' : ''}`}><AvatarToggle value={gender} onChange={setAvatarGender} className="" /></div>
            {hologramMode && hologramDetail !== 'minimal' ? <div className={`pointer-events-none absolute inset-x-0 bottom-0 z-[4] h-20 bg-gradient-to-t from-primary/10 to-transparent ${hologramDetail === 'soft' ? 'opacity-50' : ''}`} /> : null}
          </div>

          <VoiceConsole
            status={status}
            supported={speech.supported}
            interim={speech.interim}
            input={input}
            onInput={setInput}
            onSend={() => send()}
            onStart={startAi}
            onToggleMic={() => (speech.listening ? speech.stop() : startAi())}
            onStopSpeaking={speech.stopSpeaking}
            busy={busy}
          />

          <div className="flex flex-wrap gap-2">
            {QUICK_PROMPTS.map((prompt) => (
              <button
                key={prompt}
                type="button"
                onClick={() => send(prompt)}
                disabled={busy}
                className="chip transition hover:border-primary/40 hover:text-foreground disabled:opacity-50"
              >
                {prompt}
              </button>
            ))}
          </div>

          {error ? (
            <p className="rounded-xl border border-destructive/40 bg-destructive/10 px-4 py-3 text-[13px] text-foreground/90">{error}</p>
          ) : null}
          {researchStatus ? (
            <p className="rounded-xl border border-border/60 bg-secondary/20 px-4 py-3 text-[12px] leading-relaxed text-muted-foreground" role="status">
              {researchStatus === 'live_lookup_context_requested'
                ? 'Live web context was requested for this reply. The provider does not confirm which sources were used, so treat current claims as unverified unless the reply gives checkable sources.'
                : researchStatus === 'live_lookup_unavailable'
                  ? 'Live lookup could not be confirmed for this reply. Current facts and prices may be unverified.'
                  : researchStatus === 'live_lookup_disabled'
                    ? 'Live web context is off in Settings. Current facts and prices may be unverified.'
                    : 'Research status is unknown for this reply; current facts may be unverified.'}
            </p>
          ) : null}
        </div>

        <ChatThread
          messages={messages}
          greeting={messages.length ? '' : activeCharacter?.greeting}
          characterName={activeCharacter?.name}
          thinking={busy}
        />
      </div>

      {pendingMemories.length ? (
        <section className="panel space-y-4 p-5" aria-label="Memory approval">
          <div>
            <p className="eyebrow mb-2">Your permission required</p>
            <h2 className="font-heading text-lg font-semibold text-foreground">MJ AI would like to remember</h2>
            <p className="mt-1 text-[13px] text-muted-foreground">Nothing here is saved until you approve it. Dismiss anything you do not want stored.</p>
          </div>
          {memoryNotice ? <p className="text-[12px] text-primary">{memoryNotice}</p> : null}
          <div className="space-y-3">
            {pendingMemories.map((memory, index) => (
              <article key={`${memory.content}-${index}`} className="rounded-xl border border-border/60 p-4">
                <p className="text-[13px] text-foreground">{memory.content}</p>
                <div className="mt-3 flex flex-wrap gap-2">
                  <button type="button" className="btn-primary px-3 py-2 text-[12px]" onClick={async () => {
                    try {
                      await rememberAiMemories([memory]);
                      setPendingMemories((prev) => prev.filter((item) => item !== memory));
                      setMemoryNotice('Approved memory saved.');
                    } catch {
                      setMemoryNotice('Could not save that memory. Please try again.');
                    }
                  }}>Approve &amp; save</button>
                  <button type="button" className="btn-ghost px-3 py-2 text-[12px]" onClick={() => {
                    setPendingMemories((prev) => prev.filter((item) => item !== memory));
                    setMemoryNotice('Dismissed. Nothing was saved.');
                  }}>Dismiss</button>
                </div>
              </article>
            ))}
          </div>
        </section>
      ) : null}

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <CircuitStat
          icon={Brain}
          label="Memory"
          value={`${memories.length} saved`}
          hint="What it remembers about you"
          to="/app/memory"
        />
        <CircuitStat
          icon={Puzzle}
          label="Skills"
          value={`${enabledSkills.length}/${skills.length} on`}
          hint="Web skills work here; PC skills need the companion app"
          to="/app/skills"
        />
        <CircuitStat
          icon={Sparkles}
          label="Character"
          value={activeCharacter?.name || 'Not set'}
          hint="Swap the personality any time"
          to="/app/characters"
        />
        <CircuitStat
          icon={SettingsIcon}
          label="Settings"
          value={settings.voice_enabled ? 'Voice on' : 'Voice off'}
          hint={`Wake word: ${settings.wake_word || 'not set'}`}
          to="/app/settings"
        />
      </div>
    </div>
  );
}