import { useState } from 'react';
import { Check, Loader2, Plus, Trash2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useAssistant } from '@/lib/AssistantContext';
import AvatarToggle from '@/components/avatar/AvatarToggle';
import { cn } from '@/lib/utils';

const PERSONAS = [
  { value: 'tactical', label: 'Tactical' },
  { value: 'mentor', label: 'Mentor' },
  { value: 'friend', label: 'Best friend' },
  { value: 'custom', label: 'Custom' },
];

const EMPTY = {
  name: '',
  tagline: '',
  persona: 'custom',
  avatar_gender: 'female',
  tone: '',
  traits: '',
  greeting: '',
  instructions: '',
};

export default function Characters() {
  const { loading, characters, settings, activeCharacter, setActiveCharacter, reload, user } = useAssistant();
  const [draft, setDraft] = useState(EMPTY);
  const [saving, setSaving] = useState(false);
  const [open, setOpen] = useState(false);

  const create = async (event) => {
    event.preventDefault();
    if (!draft.name.trim()) return;
    setSaving(true);
    const created = await base44.entities.CharacterProfile.create({
      name: draft.name.trim(),
      tagline: draft.tagline.trim() || 'Custom',
      persona: draft.persona,
      avatar_gender: draft.avatar_gender,
      tone: draft.tone.trim() || 'Warm, direct and present.',
      traits: draft.traits.split(',').map((trait) => trait.trim()).filter(Boolean).slice(0, 6),
      greeting: draft.greeting.trim() || 'I am here. Where do we start?',
      instructions: draft.instructions.trim(),
      is_preset: false,
    });
    await setActiveCharacter(created);
    setDraft(EMPTY);
    setOpen(false);
    setSaving(false);
    await reload();
  };

  const remove = async (character) => {
    const wasActive = settings?.active_character_id === character.id;
    await base44.entities.CharacterProfile.delete(character.id);
    if (wasActive) {
      const remaining = characters.filter((item) => item.id !== character.id);
      if (remaining.length) await setActiveCharacter(remaining[0]);
    }
    await reload();
  };

  if (loading) {
    return <div className="h-40 animate-pulse rounded-2xl bg-secondary/20" />;
  }

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="eyebrow mb-2">Character circuit</p>
          <h1 className="font-heading text-2xl font-semibold tracking-tight text-foreground sm:text-3xl">Who it is.</h1>
          <p className="mt-2 max-w-2xl text-[13px] leading-relaxed text-muted-foreground">
            A JARVIS-style tactical mind, a mentor, a best friend — or one you build yourself. Switching a character also switches the voice and the avatar core.
          </p>
        </div>
        <button type="button" onClick={() => setOpen((value) => !value)} className="btn-ghost px-5 py-2.5 text-[13px]">
          <Plus className="h-4 w-4" /> New character
        </button>
      </header>

      {open ? (
        <form onSubmit={create} className="panel grid gap-4 p-5 md:grid-cols-2">
          <div className="md:col-span-2 flex flex-wrap items-center justify-between gap-3">
            <p className="font-heading text-sm text-foreground">Build your own mind</p>
            <AvatarToggle value={draft.avatar_gender} onChange={(value) => setDraft({ ...draft, avatar_gender: value })} className="" />
          </div>
          <input className="field" placeholder="Name" value={draft.name} onChange={(event) => setDraft({ ...draft, name: event.target.value })} aria-label="Character name" />
          <input className="field" placeholder="Tagline (e.g. Wingman)" value={draft.tagline} onChange={(event) => setDraft({ ...draft, tagline: event.target.value })} aria-label="Tagline" />
          <select className="field" value={draft.persona} onChange={(event) => setDraft({ ...draft, persona: event.target.value })} aria-label="Persona">
            {PERSONAS.map((persona) => (
              <option key={persona.value} value={persona.value}>{persona.label}</option>
            ))}
          </select>
          <input className="field" placeholder="Traits, comma separated" value={draft.traits} onChange={(event) => setDraft({ ...draft, traits: event.target.value })} aria-label="Traits" />
          <input className="field md:col-span-2" placeholder="How it speaks" value={draft.tone} onChange={(event) => setDraft({ ...draft, tone: event.target.value })} aria-label="Tone" />
          <input className="field md:col-span-2" placeholder="Greeting line" value={draft.greeting} onChange={(event) => setDraft({ ...draft, greeting: event.target.value })} aria-label="Greeting" />
          <textarea
            className="field md:col-span-2 min-h-[90px]"
            placeholder="Extra instructions — how it should behave with you"
            value={draft.instructions}
            onChange={(event) => setDraft({ ...draft, instructions: event.target.value })}
            aria-label="Instructions"
          />
          <div className="md:col-span-2 flex justify-end gap-3">
            <button type="button" onClick={() => setOpen(false)} className="btn-ghost px-5 py-2.5 text-[13px]">Cancel</button>
            <button type="submit" disabled={saving || !draft.name.trim()} className="btn-primary px-5 py-2.5 text-[13px]">
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />} Save and activate
            </button>
          </div>
        </form>
      ) : null}

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {characters.map((character) => {
          const active = character.id === activeCharacter?.id;
          const mine = character.created_by_id === user?.id && !character.is_preset;
          return (
            <article key={character.id} className={cn('panel flex flex-col gap-4 p-5', active && 'border-primary/50 shadow-[0_0_50px_-24px_hsl(var(--primary)/0.7)]')}>
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h2 className="font-heading text-lg text-foreground">{character.name}</h2>
                  <p className="mt-1 text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
                    {character.tagline || character.persona} · {character.avatar_gender} core
                  </p>
                </div>
                {active ? <span className="chip border-primary/40 text-primary/90">Active</span> : null}
              </div>
              <p className="text-[13px] leading-relaxed text-muted-foreground">{character.tone}</p>
              {character.traits?.length ? (
                <div className="flex flex-wrap gap-2">
                  {character.traits.map((trait) => (
                    <span key={trait} className="chip">{trait}</span>
                  ))}
                </div>
              ) : null}
              <div className="mt-auto flex items-center gap-3 border-t border-border/40 pt-4">
                <button
                  type="button"
                  onClick={() => setActiveCharacter(character)}
                  disabled={active}
                  className={cn('px-4 py-2 text-[13px]', active ? 'chip' : 'btn-primary')}
                >
                  {active ? 'Talking to this one' : 'Activate'}
                </button>
                {mine ? (
                  <button
                    type="button"
                    onClick={() => remove(character)}
                    className="ml-auto rounded-lg border border-border/60 p-2 text-muted-foreground transition hover:border-destructive/50 hover:text-destructive"
                    aria-label={`Delete ${character.name}`}
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                ) : (
                  <span className="ml-auto text-[11px] uppercase tracking-[0.16em] text-muted-foreground">Preset</span>
                )}
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
}