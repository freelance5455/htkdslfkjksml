import { useEffect, useMemo, useState } from 'react';
import { Check, Copy, Phone, QrCode, Smartphone, Wifi, WifiOff } from 'lucide-react';
import { useAssistant } from '@/lib/AssistantContext';
import CompanionBadge from '@/components/dashboard/CompanionBadge';
import { cn } from '@/lib/utils';

const STEPS = [
  { title: 'Download Stonic on your PC', copy: 'Install the Windows companion app and sign in with this same account.' },
  { title: 'Open Settings → Stonic Remote', copy: 'Inside the app, switch Remote on so your PC is reachable.' },
  { title: 'Scan the QR code with your phone', copy: 'Your phone opens the call screen instantly — no second login.' },
];

export default function Remote() {
  const { user, settings } = useAssistant();
  const [copied, setCopied] = useState(false);
  const [qrState, setQrState] = useState('loading');

  useEffect(() => {
    if (qrState !== 'loading') return undefined;
    const timer = setTimeout(() => setQrState((current) => (current === 'loading' ? 'failed' : current)), 4500);
    return () => clearTimeout(timer);
  }, [qrState]);

  const pairingCode = useMemo(() => {
    if (!user?.id) return 'MJAI-0000-0000';
    const compact = user.id.replace(/[^a-z0-9]/gi, '').toUpperCase();
    return `MJAI-${compact.slice(0, 4)}-${compact.slice(-4)}`;
  }, [user?.id]);

  const qrSrc = `https://api.qrserver.com/v1/create-qr-code/?size=220x220&margin=0&color=7df9ff&bgcolor=06121a&data=${encodeURIComponent(`mjai://pair?code=${pairingCode}`)}`;

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(pairingCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
  };

  return (
    <div className="space-y-6">
      <header>
        <p className="eyebrow mb-2">Stonic Remote</p>
        <h1 className="font-heading text-2xl font-semibold tracking-tight text-foreground sm:text-3xl">Stonic, in your pocket.</h1>
        <p className="mt-2 max-w-2xl text-[13px] leading-relaxed text-muted-foreground">
          Step out, pop in your earbuds, and keep the conversation going — the same character, the same voice, while your PC is on and Stonic is open, signed in to the same account.
        </p>
      </header>

      <div className="grid gap-6 lg:grid-cols-[1fr_0.85fr]">
        <ol className="space-y-4">
          {STEPS.map((step, index) => (
            <li key={step.title} className="panel flex items-start gap-5 p-5">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-primary/40 bg-primary/10 font-heading text-sm text-primary">
                {index + 1}
              </span>
              <div>
                <p className="font-heading text-sm text-foreground">{step.title}</p>
                <p className="mt-1.5 text-[13px] leading-relaxed text-muted-foreground">{step.copy}</p>
              </div>
            </li>
          ))}
          <li className="panel-soft flex items-start gap-4 p-5">
            <Phone className="mt-0.5 h-4 w-4 text-accent" />
            <p className="text-[13px] leading-relaxed text-muted-foreground">
              Keep the call screen open on your phone for the whole conversation. Voice runs while your PC stays awake and signed in.
            </p>
          </li>
        </ol>

        <div className="space-y-4">
          <div className="panel flex flex-col items-center gap-5 p-6 text-center">
            <div className="flex items-center gap-2">
              <QrCode className="h-4 w-4 text-primary" />
              <p className="font-heading text-sm tracking-[0.16em] text-foreground">PAIR YOUR PHONE</p>
            </div>

            <div className="relative flex h-[232px] w-[232px] items-center justify-center rounded-2xl border border-border/60 bg-background/60 p-3">
              <img
                src={qrSrc}
                alt="Stonic Remote pairing QR code"
                width={220}
                height={220}
                onLoad={() => setQrState('loaded')}
                onError={() => setQrState('failed')}
                className={cn('h-[208px] w-[208px] rounded-lg transition-opacity', qrState === 'loaded' ? 'opacity-100' : 'opacity-0')}
              />
              {qrState !== 'loaded' ? (
                <p className="absolute inset-0 flex items-center justify-center px-5 text-center text-[12px] leading-relaxed text-muted-foreground">
                  {qrState === 'failed' ? 'No QR image available here — enter the pairing code on your phone instead.' : 'Preparing the pairing QR…'}
                </p>
              ) : null}
            </div>

            <div className="flex w-full items-center gap-3">
              <div className="field flex-1 text-center font-mono tracking-[0.2em]">{pairingCode}</div>
              <button type="button" onClick={copy} className="btn-ghost px-4 py-3 text-[13px]">
                {copied ? <Check className="h-4 w-4 text-primary" /> : <Copy className="h-4 w-4" />}
                {copied ? 'Copied' : 'Copy'}
              </button>
            </div>

            <CompanionBadge note="Pairing is handled by the Windows companion app" />
            <p className="text-[12px] leading-relaxed text-muted-foreground">
              This screen is the real setup step from the MJ AI build. The QR encodes <span className="text-foreground/90">your</span> pairing code, but pairing itself only completes once the Windows companion app on your PC answers the handshake — it is not live in this web build yet, and no call is placed from here.
            </p>
          </div>

          <div className="panel p-5">
            <p className="font-heading text-sm text-foreground">Connection status</p>
            <div className="mt-4 space-y-3">
              <div className="flex items-center gap-3 text-[13px]">
                <WifiOff className="h-4 w-4 text-muted-foreground" />
                <span className="text-foreground/90">PC companion app</span>
                <span className="chip ml-auto">Not connected</span>
              </div>
              <div className="flex items-center gap-3 text-[13px]">
                <Smartphone className="h-4 w-4 text-muted-foreground" />
                <span className="text-foreground/90">Phone</span>
                <span className="chip ml-auto">Not paired</span>
              </div>
              <div className="flex items-center gap-3 text-[13px]">
                <Wifi className="h-4 w-4 text-primary" />
                <span className="text-foreground/90">Wake word</span>
                <span className="chip ml-auto">{settings?.wake_word || 'Hey Stonic'}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}