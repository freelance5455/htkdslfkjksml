import { useMemo } from 'react';
import { Globe, Image as ImageIcon, Mic, MonitorSmartphone, Puzzle, Smartphone, Sparkles } from 'lucide-react';
import { useAssistant } from '@/lib/AssistantContext';
import CompanionBadge from '@/components/dashboard/CompanionBadge';
import Toggle from '@/components/dashboard/Toggle';
import { cn } from '@/lib/utils';

const ICONS = {
  voice_conversation: Mic,
  long_term_memory: Sparkles,
  character_switching: Sparkles,
  world_headlines: Globe,
  visual_generation: ImageIcon,
  remote_calls: Smartphone,
};

export default function Skills() {
  const { loading, skills, settings, toggleSkill } = useAssistant();
  const enabled = settings?.enabled_skills || [];

  const groups = useMemo(() => ({
    web: skills.filter((skill) => skill.mode === 'web'),
    companion: skills.filter((skill) => skill.mode === 'companion'),
  }), [skills]);

  if (loading || !settings) {
    return <div className="h-40 animate-pulse rounded-2xl bg-secondary/20" />;
  }

  const renderSkill = (skill) => {
    const on = enabled.includes(skill.key);
    const Icon = ICONS[skill.key] || Puzzle;
    const isCompanion = skill.mode === 'companion';
    return (
      <article key={skill.id} className={cn('panel flex flex-col gap-4 p-5', isCompanion && 'bg-secondary/10')}>
        <div className="flex items-start gap-4">
          <span className={cn('flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border', isCompanion ? 'border-accent/30 bg-accent/10' : 'border-primary/30 bg-primary/10')}>
            <Icon className={cn('h-4 w-4', isCompanion ? 'text-accent' : 'text-primary')} />
          </span>
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="font-heading text-sm text-foreground">{skill.name}</h3>
              {isCompanion ? <CompanionBadge note={skill.companion_note} /> : <span className="chip border-emerald-400/30 text-emerald-300/90">Works here</span>}
            </div>
            <p className="mt-2 text-[13px] leading-relaxed text-muted-foreground">{skill.description}</p>
            {isCompanion && skill.companion_note ? (
              <p className="mt-2 text-[12px] leading-relaxed text-accent/80">{skill.companion_note}</p>
            ) : null}
          </div>
        </div>
        <div className="mt-auto flex items-center justify-between border-t border-border/40 pt-4">
          <span className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground">{skill.category}</span>
          {isCompanion ? (
            <span className="text-[11px] text-muted-foreground">Switch on in the companion app</span>
          ) : (
            <Toggle checked={on} onChange={() => toggleSkill(skill.key)} label={`Toggle ${skill.name}`} />
          )}
        </div>
      </article>
    );
  };

  return (
    <div className="space-y-8">
      <header>
        <p className="eyebrow mb-2">Skills circuit</p>
        <h1 className="font-heading text-2xl font-semibold tracking-tight text-foreground sm:text-3xl">The everyday things it can do.</h1>
        <p className="mt-2 max-w-2xl text-[13px] leading-relaxed text-muted-foreground">
          Skills marked “Works here” run inside this dashboard right now. Skills marked with the companion badge need the Windows app on your PC — they are listed so you can see what is planned, never to pretend they already run.
        </p>
      </header>

      <section>
        <h2 className="eyebrow mb-4">Works here · {groups.web.filter((skill) => enabled.includes(skill.key)).length}/{groups.web.length} on</h2>
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{groups.web.map(renderSkill)}</div>
      </section>

      <section>
        <h2 className="eyebrow mb-4 flex items-center gap-2">
          <MonitorSmartphone className="h-3.5 w-3.5" /> Needs the Windows companion app · {groups.companion.length} skills
        </h2>
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{groups.companion.map(renderSkill)}</div>
      </section>
    </div>
  );
}