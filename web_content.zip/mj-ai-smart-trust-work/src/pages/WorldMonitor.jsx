import { useEffect, useState } from 'react';
import { Globe, Map, Radio } from 'lucide-react';
import Globe3D from '@/components/globe/Globe3D';
import CommandMap2D from '@/components/globe/CommandMap2D';
import HeadlineFeed from '@/components/globe/HeadlineFeed';
import { CATEGORY_COLORS, CATEGORY_LABELS, HOTSPOTS } from '@/lib/geo';
import { cn } from '@/lib/utils';

const VIEWS = [
  { id: '3d', label: '3D globe', icon: Globe },
  { id: '2d', label: '2D command map', icon: Map },
];

export default function WorldMonitor() {
  const [view, setView] = useState('3d');
  const [selectedId, setSelectedId] = useState('kyiv');
  const [utc, setUtc] = useState(() => new Date().toISOString().slice(11, 19));

  useEffect(() => {
    const timer = setInterval(() => setUtc(new Date().toISOString().slice(11, 19)), 1000);
    return () => clearInterval(timer);
  }, []);

  const selected = HOTSPOTS.find((spot) => spot.id === selectedId) || null;

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="eyebrow mb-2">World Monitor</p>
          <h1 className="font-heading text-2xl font-semibold tracking-tight text-foreground sm:text-3xl">The whole world, on your radar.</h1>
          <p className="mt-2 max-w-2xl text-[13px] leading-relaxed text-muted-foreground">
            Your desktop stops being wallpaper and starts being mission control. Hotspots are curated reference points; headlines arrive live from AI web search.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <span className="chip border-primary/30 text-primary/90">
            <Radio className="h-3.5 w-3.5" /> {utc} UTC
          </span>
          <div className="inline-flex items-center gap-1 rounded-full border border-border/60 bg-secondary/30 p-1">
            {VIEWS.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setView(item.id)}
                className={cn(
                  'inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-[12px] transition duration-300',
                  view === item.id ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground',
                )}
              >
                <item.icon className="h-3.5 w-3.5" /> {item.label}
              </button>
            ))}
          </div>
        </div>
      </header>

      <div className="grid gap-6 xl:grid-cols-[1.4fr_1fr]">
        <div className="space-y-4">
          <div className="panel relative overflow-hidden">
            {view === '3d' ? (
              <Globe3D selectedId={selectedId} onSelect={setSelectedId} className="h-[420px] w-full sm:h-[480px]" />
            ) : (
              <div className="h-[420px] w-full sm:h-[480px]">
                <CommandMap2D selectedId={selectedId} onSelect={setSelectedId} />
              </div>
            )}
            <div className="pointer-events-none absolute left-5 top-5">
              <span className="chip border-primary/30 text-primary/90">{view === '3d' ? 'Orbital view' : 'Command map'} · UTC</span>
            </div>
          </div>

          <div className="panel flex flex-wrap items-center gap-3 px-5 py-4">
            {Object.entries(CATEGORY_LABELS).map(([key, label]) => (
              <span key={key} className="inline-flex items-center gap-2 text-[11px] uppercase tracking-[0.16em] text-muted-foreground">
                <span className="h-2 w-2 rounded-full" style={{ background: CATEGORY_COLORS[key] }} /> {label}
              </span>
            ))}
          </div>

          {selected ? (
            <div className="panel flex flex-wrap items-center gap-4 p-5">
              <span className="h-3 w-3 rounded-full" style={{ background: CATEGORY_COLORS[selected.category] }} />
              <div>
                <p className="font-heading text-sm text-foreground">{selected.name}</p>
                <p className="text-[12px] text-muted-foreground">{selected.country} · {selected.lat.toFixed(1)}°, {selected.lon.toFixed(1)}°</p>
              </div>
              <span className="chip">{CATEGORY_LABELS[selected.category]}</span>
              <span className="text-[13px] text-muted-foreground">{selected.note}</span>
            </div>
          ) : null}
        </div>

        <div className="space-y-4">
          <HeadlineFeed compact />
          <div className="panel p-5">
            <p className="font-heading text-sm text-foreground">What is real here</p>
            <ul className="mt-3 space-y-2 text-[12px] leading-relaxed text-muted-foreground">
              <li>· The 3D globe, hotspot plotting and the 2D map all run live in this dashboard.</li>
              <li>· Headlines come from an AI web search at the moment you refresh them.</li>
              <li>· There is no real-time satellite or military feed behind this build — the hotspot set is curated reference data.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}