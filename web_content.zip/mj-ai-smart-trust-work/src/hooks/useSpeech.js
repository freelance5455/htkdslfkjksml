import { useCallback, useEffect, useRef, useState } from 'react';

const VOICE_STYLES = {
  maya: { gender: 'female', pitch: 1.12, rate: 1.0 },
  mayra: { gender: 'female', pitch: 1.04, rate: 0.96 },
  jarvis: { gender: 'male', pitch: 0.82, rate: 0.94 },
  stonic: { gender: 'male', pitch: 0.92, rate: 0.98 },
  friday: { gender: 'female', pitch: 1.08, rate: 1.02 },
};

function chooseVoice(text, profile, voiceURI) {
  const voices = window.speechSynthesis?.getVoices?.() || [];
  if (!voices.length) return null;
  if (voiceURI) {
    const exactVoice = voices.find((voice) => voice.voiceURI === voiceURI);
    if (exactVoice) return exactVoice;
  }
  const hindiText = /[\u0900-\u097F]/.test(text);
  const langMatches = voices.filter((voice) => hindiText ? /^hi(?:-|$)/i.test(voice.lang) : /^en(?:-|$)/i.test(voice.lang));
  const candidates = langMatches.length ? langMatches : voices;
  const gender = VOICE_STYLES[profile]?.gender || 'female';
  const genderPattern = gender === 'female' ? /female|woman|zira|samantha|karen|susan|heera|neerja|google हिन्दी|google hindi/i : /male|man|david|mark|daniel|alex|ravi|hemant/i;
  return candidates.find((voice) => genderPattern.test(voice.name)) || candidates.find((voice) => voice.default) || candidates[0] || null;
}

export default function useSpeech({ onFinal, rate = 1, pitch = 1.05, voiceEnabled = true, voiceProfile = 'mayra', voiceURI = '', language = 'auto' }) {
  const [supported, setSupported] = useState(false);
  const [listening, setListening] = useState(false);
  const [interim, setInterim] = useState('');
  const [speaking, setSpeaking] = useState(false);
  const recognitionRef = useRef(null);
  const onFinalRef = useRef(onFinal);
  const voiceRef = useRef(voiceEnabled);
  const rateRef = useRef(rate);
  const pitchRef = useRef(pitch);
  const voiceProfileRef = useRef(voiceProfile);
  const languageRef = useRef(language);
  const voiceURIRef = useRef(voiceURI);
  onFinalRef.current = onFinal;
  voiceRef.current = voiceEnabled;
  rateRef.current = rate;
  pitchRef.current = pitch;
  voiceProfileRef.current = voiceProfile;
  languageRef.current = language;
  voiceURIRef.current = voiceURI;

  useEffect(() => {
    const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!Recognition) return undefined;
    const recognition = new Recognition();
    recognition.lang = languageRef.current === 'hi' ? 'hi-IN' : languageRef.current === 'en' ? 'en-US' : (navigator.language || 'en-US');
    recognition.continuous = false;
    recognition.interimResults = true;
    recognition.maxAlternatives = 1;

    recognition.onresult = (event) => {
      let text = '';
      let isFinal = false;
      for (let i = event.resultIndex; i < event.results.length; i += 1) {
        text += event.results[i][0].transcript;
        if (event.results[i].isFinal) isFinal = true;
      }
      const trimmed = text.trim();
      if (isFinal && trimmed) {
        setInterim('');
        onFinalRef.current?.(trimmed);
      } else {
        setInterim(trimmed);
      }
    };
    recognition.onerror = () => {
      setListening(false);
      setInterim('');
    };
    recognition.onend = () => setListening(false);

    recognitionRef.current = recognition;
    setSupported(true);
    return () => {
      try {
        recognition.stop();
      } catch {
        /* already stopped */
      }
      recognitionRef.current = null;
      window.speechSynthesis?.cancel();
    };
  }, []);

  const start = useCallback(() => {
    const recognition = recognitionRef.current;
    if (!recognition) return false;
    try {
      window.speechSynthesis?.cancel();
      recognition.lang = languageRef.current === 'hi' ? 'hi-IN' : languageRef.current === 'en' ? 'en-US' : (navigator.language || 'en-US');
      setInterim('');
      recognition.start();
      setListening(true);
      return true;
    } catch {
      return false;
    }
  }, []);

  const stop = useCallback(() => {
    try {
      recognitionRef.current?.stop();
    } catch {
      /* already stopped */
    }
    setListening(false);
  }, []);

  const speak = useCallback((text) => {
    if (!voiceRef.current || !text || typeof window === 'undefined' || !window.speechSynthesis) return;
    const utterance = new SpeechSynthesisUtterance(text);
    const selectedVoice = chooseVoice(text, voiceProfileRef.current, voiceURIRef.current);
    if (selectedVoice) utterance.voice = selectedVoice;
    utterance.rate = Math.max(0.6, Math.min(1.6, rateRef.current));
    utterance.pitch = Math.max(0.7, Math.min(1.5, pitchRef.current));
    utterance.onend = () => setSpeaking(false);
    utterance.onerror = () => setSpeaking(false);
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utterance);
    setSpeaking(true);
  }, []);

  const stopSpeaking = useCallback(() => {
    window.speechSynthesis?.cancel();
    setSpeaking(false);
  }, []);

  return { supported, listening, interim, speaking, start, stop, speak, stopSpeaking };
}