import { cn } from '@/lib/utils';

const OPTIONS = [
  { value: 'female', label: 'Her', hint: 'Female core' },
  { value: 'male', label: 'Him', hint: 'Male core' },
];

export default function AvatarToggle({ value, onChange, className }) {
  return (
    <div className={cn('inline-flex items-center gap-1 rounded-full border border-border/60 bg-secondary/30 p-1 backdrop-blur', className)}>
      {OPTIONS.map((option) => {
        const active = option.value === value;
        return (
          <button
            key={option.value}
            type="button"
            onClick={() => onChange(option.value)}
            aria-pressed={active}
            className={cn(
              'rounded-full px-4 py-1.5 text-xs font-medium tracking-wide transition duration-300',
              active
                ? 'bg-primary text-primary-foreground shadow-[0_0_30px_-6px_hsl(var(--primary)/0.8)]'
                : 'text-muted-foreground hover:text-foreground',
            )}
          >
            {option.label}
            <span className="ml-2 hidden text-[10px] uppercase tracking-[0.18em] opacity-70 sm:inline">{option.hint}</span>
          </button>
        );
      })}
    </div>
  );
}