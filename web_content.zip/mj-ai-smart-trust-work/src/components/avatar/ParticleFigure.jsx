import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { buildHumanoidPoints } from '@/lib/humanoidPoints';

const VERT = `
attribute vec3 aDir;
attribute float aPhase;
attribute float aAmp;
attribute float aAccent;
uniform float uTime;
uniform float uSize;
uniform float uPixel;
uniform float uEnergy;
varying float vAccent;
varying float vFade;
void main() {
  float breathe = sin(uTime * 1.5 + aPhase * 6.2831);
  float drift = sin(uTime * 0.85 + aPhase * 12.566);
  vec3 p = position + aDir * (breathe * aAmp * (0.5 + uEnergy * 0.85)) + vec3(0.0, drift * aAmp * 0.7, 0.0);
  vec4 mv = modelViewMatrix * vec4(p, 1.0);
  gl_PointSize = clamp(uSize * uPixel * (1.0 / max(0.001, -mv.z)), 1.0, 44.0);
  gl_Position = projectionMatrix * mv;
  vAccent = clamp(aAccent + 0.3 * sin(uTime * 0.6 + aPhase * 4.0), 0.0, 1.0);
  vFade = 0.45 + 0.55 * sin(uTime * 1.05 + aPhase * 9.0);
}`;

const FRAG = `
uniform vec3 uColorA;
uniform vec3 uColorB;
uniform float uOpacity;
varying float vAccent;
varying float vFade;
void main() {
  float d = length(gl_PointCoord - vec2(0.5));
  float a = smoothstep(0.5, 0.03, d) * (0.3 + 0.7 * vFade) * uOpacity;
  if (a < 0.02) discard;
  gl_FragColor = vec4(mix(uColorA, uColorB, vAccent), a);
}`;

function glowTexture(color) {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d');
  const grad = ctx.createRadialGradient(64, 64, 0, 64, 64, 64);
  grad.addColorStop(0, color);
  grad.addColorStop(0.35, 'rgba(125,249,255,0.22)');
  grad.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 128, 128);
  return new THREE.CanvasTexture(canvas);
}

export default function ParticleFigure({
  gender = 'female',
  thinking = false,
  interactive = true,
  showAura = true,
  density = 1,
  pointSize = 15,
  className = '',
}) {
  const hostRef = useRef(null);
  const thinkingRef = useRef(thinking);
  thinkingRef.current = thinking;

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return undefined;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.setClearColor(0x000000, 0);
    const canvas = renderer.domElement;
    canvas.style.width = '100%';
    canvas.style.height = '100%';
    canvas.style.display = 'block';
    canvas.style.cursor = interactive ? 'grab' : 'default';
    host.appendChild(canvas);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(38, 1, 0.1, 30);
    camera.position.set(0, 0.02, 3.05);

    const group = new THREE.Group();
    group.position.y = -0.92;
    scene.add(group);

    const data = buildHumanoidPoints(gender, density);
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(data.positions, 3));
    geometry.setAttribute('aDir', new THREE.Float32BufferAttribute(data.dirs, 3));
    geometry.setAttribute('aPhase', new THREE.Float32BufferAttribute(data.phases, 1));
    geometry.setAttribute('aAmp', new THREE.Float32BufferAttribute(data.amps, 1));
    geometry.setAttribute('aAccent', new THREE.Float32BufferAttribute(data.accents, 1));

    const uniforms = {
      uTime: { value: 0 },
      uSize: { value: pointSize },
      uPixel: { value: renderer.getPixelRatio() },
      uEnergy: { value: 1 },
      uOpacity: { value: 1 },
      uColorA: { value: new THREE.Color('#7df9ff') },
      uColorB: { value: new THREE.Color('#b388ff') },
    };

    const material = new THREE.ShaderMaterial({
      uniforms,
      vertexShader: VERT,
      fragmentShader: FRAG,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });

    const points = new THREE.Points(geometry, material);
    group.add(points);

    let aura = null;
    if (showAura) {
      const auraCount = 700;
      const auraGeo = new THREE.BufferGeometry();
      const pos = new Float32Array(auraCount * 3);
      for (let i = 0; i < auraCount; i++) {
        const rad = 0.55 + Math.random() * 0.75;
        const a = Math.random() * Math.PI * 2;
        pos[i * 3] = Math.cos(a) * rad;
        pos[i * 3 + 1] = 0.2 + Math.random() * 1.9;
        pos[i * 3 + 2] = Math.sin(a) * rad;
      }
      auraGeo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
      const auraMat = new THREE.PointsMaterial({
        size: 0.012,
        color: new THREE.Color('#4fd2ff'),
        transparent: true,
        opacity: 0.5,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        map: glowTexture('rgba(125,249,255,0.9)'),
      });
      aura = new THREE.Points(auraGeo, auraMat);
      group.add(aura);
    }

    const coreTex = glowTexture('rgba(125,249,255,0.75)');
    const core = new THREE.Sprite(new THREE.SpriteMaterial({
      map: coreTex,
      transparent: true,
      opacity: 0.5,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    }));
    core.scale.set(1.7, 1.7, 1);
    core.position.set(0, 0.92, 0);
    group.add(core);

    let yaw = 0;
    let pitch = 0;
    let targetYaw = 0;
    let targetPitch = 0;
    let dragging = false;
    let lastX = 0;
    let lastY = 0;
    let pointerX = 0;
    let pointerY = 0;

    const onPointerDown = (e) => {
      dragging = true;
      lastX = e.clientX;
      lastY = e.clientY;
      canvas.style.cursor = 'grabbing';
    };
    const onPointerMove = (e) => {
      const rect = host.getBoundingClientRect();
      pointerX = ((e.clientX - rect.left) / Math.max(1, rect.width)) * 2 - 1;
      pointerY = ((e.clientY - rect.top) / Math.max(1, rect.height)) * 2 - 1;
      if (!dragging) return;
      targetYaw += (e.clientX - lastX) * 0.006;
      targetPitch = Math.max(-0.35, Math.min(0.35, targetPitch + (e.clientY - lastY) * 0.003));
      lastX = e.clientX;
      lastY = e.clientY;
    };
    const onPointerUp = () => {
      dragging = false;
      canvas.style.cursor = 'grab';
    };
    const onWheel = (e) => {
      if (!interactive) return;
      e.preventDefault();
      camera.position.z = Math.max(2.1, Math.min(4.4, camera.position.z + e.deltaY * 0.0015));
    };

    if (interactive) {
      canvas.addEventListener('pointerdown', onPointerDown);
      window.addEventListener('pointermove', onPointerMove);
      window.addEventListener('pointerup', onPointerUp);
      canvas.addEventListener('wheel', onWheel, { passive: false });
    }

    const resize = () => {
      const w = host.clientWidth || 1;
      const h = host.clientHeight || 1;
      renderer.setSize(w, h, false);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
    };
    resize();
    const observer = new ResizeObserver(resize);
    observer.observe(host);

    const clock = new THREE.Clock();
    let raf = 0;
    let energy = 1;

    const tick = () => {
      const delta = Math.min(clock.getDelta(), 0.05);
      uniforms.uTime.value += delta;
      const targetEnergy = thinkingRef.current ? 2.3 : 1;
      energy += (targetEnergy - energy) * 0.06;
      uniforms.uEnergy.value = energy;

      const spin = thinkingRef.current ? 0.34 : 0.09;
      targetYaw += delta * spin;
      targetPitch += (0 - targetPitch) * 0.004;
      yaw += (targetYaw - yaw) * 0.07;
      pitch += (targetPitch - pitch) * 0.07;
      group.rotation.y = yaw;
      group.rotation.x = pitch;

      camera.position.x += (pointerX * 0.22 - camera.position.x) * 0.04;
      camera.position.y += (0.02 + pointerY * -0.12 - camera.position.y) * 0.04;
      camera.lookAt(0, 0.05, 0);

      if (aura) {
        aura.rotation.y -= delta * 0.12;
        aura.material.opacity = 0.35 + energy * 0.12;
      }
      core.material.opacity = 0.35 + energy * 0.12;

      renderer.render(scene, camera);
      raf = requestAnimationFrame(tick);
    };
    tick();

    return () => {
      cancelAnimationFrame(raf);
      observer.disconnect();
      if (interactive) {
        canvas.removeEventListener('pointerdown', onPointerDown);
        window.removeEventListener('pointermove', onPointerMove);
        window.removeEventListener('pointerup', onPointerUp);
        canvas.removeEventListener('wheel', onWheel);
      }
      geometry.dispose();
      material.dispose();
      coreTex.dispose();
      core.material.dispose();
      if (aura) {
        aura.geometry.dispose();
        aura.material.map?.dispose();
        aura.material.dispose();
      }
      renderer.dispose();
      if (canvas.parentNode === host) host.removeChild(canvas);
    };
  }, [gender, density, interactive, showAura, pointSize]);

  return <div ref={hostRef} className={className} />;
}