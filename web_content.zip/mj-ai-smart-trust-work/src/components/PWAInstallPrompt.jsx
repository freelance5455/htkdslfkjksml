import { useEffect, useState } from 'react';
import { Download, X } from 'lucide-react';

/** Offers the browser's native install flow when the current browser supports it. */
export default function PWAInstallPrompt() {
  const [installEvent, setInstallEvent] = useState(null);
  const [dismissed, setDismissed] = useState(false);
  const [installed, setInstalled] = useState(false);

  useEffect(() => {
    if (typeof window === 'undefined') return undefined;
    const isStandalone = window.matchMedia?.('(display-mode: standalone)').matches || window.navigator.standalone === true;
    if (isStandalone) setInstalled(true);

    const onBeforeInstall = (event) => {
      event.preventDefault();
      setInstallEvent(event);
    };
    const onInstalled = () => {
      setInstalled(true);
      setInstallEvent(null);
    };
    window.addEventListener('beforeinstallprompt', onBeforeInstall);
    window.addEventListener('appinstalled', onInstalled);
    return () => {
      window.removeEventListener('beforeinstallprompt', onBeforeInstall);
      window.removeEventListener('appinstalled', onInstalled);
    };
  }, []);

  if (installed || dismissed || !installEvent) return null;

  const install = async () => {
    try {
      await installEvent.prompt();
      await installEvent.userChoice;
    } finally {
      setInstallEvent(null);
    }
  };

  return (
    <aside className="fixed inset-x-3 bottom-3 z-[100] mx-auto flex max-w-lg items-center gap-3 rounded-2xl border border-primary/30 bg-card/95 p-3 shadow-2xl backdrop-blur-xl sm:inset-x-auto sm:right-5 sm:bottom-5">
      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
        <Download className="h-5 w-5" />
      </div>
      <div className="min-w-0 flex-1">
        <p className="text-sm font-medium text-foreground">Install MJ AI</p>
        <p className="text-xs text-muted-foreground">Add it to your phone or PC home screen.</p>
      </div>
      <button type="button" onClick={install} className="btn-primary px-4 py-2 text-xs">Install</button>
      <button type="button" aria-label="Dismiss install prompt" onClick={() => setDismissed(true)} className="rounded-full p-2 text-muted-foreground hover:text-foreground">
        <X className="h-4 w-4" />
      </button>
    </aside>
  );
}
