import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Loader2, LogIn, LogOut, Lock, Mail, ShieldCheck } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import GoogleIcon from '@/components/GoogleIcon';
import SectionHeading from '@/components/landing/SectionHeading';

const PROMISES = [
  'Your conversations and memories stay tied to your account — never shared.',
  'Stonic tells you the truth, even when the comfortable answer is easier.',
  'Nothing here is sold or advertised at you. Your mind stays yours.',
];

export default function LoginPanel() {
  const [signedIn, setSignedIn] = useState(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    base44.auth.isAuthenticated().then(setSignedIn).catch(() => setSignedIn(false));
  }, []);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError('');
    setLoading(true);
    try {
      await base44.auth.loginViaEmailPassword(email, password);
      window.location.href = '/app';
    } catch (err) {
      setError(err.message || 'That email and password did not match. Try again.');
      setLoading(false);
    }
  };

  return (
    <section id="login" className="border-t border-border/40">
      <div className="mx-auto grid max-w-6xl gap-10 px-5 py-16 sm:py-20 lg:grid-cols-[1fr_400px] lg:items-center">
        <div>
          <SectionHeading
            eyebrow="Access panel"
            title="Sign in to your Stonic."
            copy="One door into everything: the character, the memory, the world monitor and your remote."
          />
          <ul className="mt-7 space-y-3">
            {PROMISES.map((promise) => (
              <li key={promise} className="flex items-start gap-3 text-[13px] leading-relaxed text-muted-foreground">
                <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                <span>{promise}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="panel p-6 sm:p-7">
          {signedIn ? (
            <div className="space-y-5 text-center">
              <span className="mx-auto flex h-11 w-11 items-center justify-center rounded-xl border border-primary/40 bg-primary/10">
                <LogIn className="h-5 w-5 text-primary" />
              </span>
              <div>
                <p className="font-heading text-lg text-foreground">You are already signed in.</p>
                <p className="mt-1 text-[13px] text-muted-foreground">Stonic is waiting in your dashboard.</p>
              </div>
              <Link to="/app" className="btn-primary w-full">
                Open the dashboard
                <ArrowRight className="h-4 w-4" />
              </Link>
              <button
                type="button"
                onClick={() => base44.auth.logout('/')}
                className="inline-flex items-center gap-1.5 text-[12px] text-muted-foreground transition hover:text-foreground"
              >
                <LogOut className="h-3.5 w-3.5" />
                Sign out
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="flex items-center gap-2">
                <LogIn className="h-4 w-4 text-primary" />
                <p className="font-heading text-sm tracking-[0.16em] text-foreground">SIGN IN</p>
              </div>

              <Button
                type="button"
                variant="outline"
                className="w-full"
                onClick={() => base44.auth.loginWithProvider('google', '/app')}
              >
                <GoogleIcon className="mr-2 h-4 w-4" />
                Continue with Google
              </Button>

              <div className="relative py-1">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-border/60" />
                </div>
                <div className="relative flex justify-center">
                  <span className="bg-card px-3 text-[10px] uppercase tracking-[0.2em] text-muted-foreground">or email</span>
                </div>
              </div>

              {error ? (
                <p className="rounded-lg border border-destructive/40 bg-destructive/10 px-3 py-2 text-[12px] text-foreground/90">{error}</p>
              ) : null}

              <div className="space-y-1.5">
                <Label htmlFor="panel-email">Email</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
                  <Input
                    id="panel-email"
                    type="email"
                    autoComplete="email"
                    placeholder="you@example.com"
                    value={email}
                    onChange={(event) => setEmail(event.target.value)}
                    className="h-11 pl-10"
                    required
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <Label htmlFor="panel-password">Password</Label>
                  <Link to="/forgot-password" className="text-[11px] text-primary hover:underline">
                    Forgot password?
                  </Link>
                </div>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
                  <Input
                    id="panel-password"
                    type="password"
                    autoComplete="current-password"
                    placeholder="••••••••"
                    value={password}
                    onChange={(event) => setPassword(event.target.value)}
                    className="h-11 pl-10"
                    required
                  />
                </div>
              </div>

              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Signing in…
                  </>
                ) : (
                  'Sign in'
                )}
              </Button>

              <p className="text-center text-[12px] text-muted-foreground">
                New here?{' '}
                <Link to="/register" className="text-primary hover:underline">
                  Create an account
                </Link>
              </p>
            </form>
          )}
        </div>
      </div>
    </section>
  );
}