import ParticleFigure from '@/components/avatar/ParticleFigure';
import SectionHeading from '@/components/landing/SectionHeading';

const CORES = [
  { gender: 'female', title: 'Stonic — female core', note: 'Warmer tone, lighter frame, longer particle hair.' },
  { gender: 'male', title: 'Stonic — male core', note: 'Deeper tone, broader frame, short particle hair.' },
];

export default function AvatarShowcase() {
  return (
    <section id="character" className="mx-auto max-w-6xl px-5 py-16">
      <SectionHeading
        eyebrow="Same character, two faces"
        title="Keep scrolling — the same Stonic, as her or as him."
        copy="These are not screenshots. Both figures below are the real particle engine, rendered live in your browser. Choose yours inside the app."
      />
      <div className="mt-10 grid gap-6 md:grid-cols-2">
        {CORES.map((core) => (
          <article key={core.gender} className="panel panel-hover overflow-hidden">
            <ParticleFigure gender={core.gender} density={0.7} interactive={false} pointSize={13} className="h-[340px] w-full" />
            <div className="border-t border-border/50 px-6 py-5">
              <h3 className="font-heading text-sm tracking-[0.18em] text-foreground">{core.title.toUpperCase()}</h3>
              <p className="mt-2 text-[13px] leading-relaxed text-muted-foreground">{core.note}</p>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}