import { QrCode, Smartphone } from 'lucide-react';
import SectionHeading from '@/components/landing/SectionHeading';

const STEPS = [
  'Download Stonic on your PC and sign in.',
  'Open Settings → Stonic Remote.',
  'Scan the QR code with your phone.',
];

export default function RemoteSection() {
  return (
    <section id="remote" className="mx-auto max-w-6xl px-5 py-16">
      <SectionHeading
        eyebrow="Stonic Remote"
        title="Stonic, in your pocket."
        copy="Step out, pop in your earbuds, and keep the conversation going — the same character, the same voice, while your PC is on."
      />
      <div className="mt-10 grid gap-6 lg:grid-cols-[1fr_0.8fr]">
        <ol className="flex flex-col gap-4">
          {STEPS.map((step, index) => (
            <li key={step} className="panel flex items-center gap-5 p-5">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-primary/40 bg-primary/10 font-heading text-sm text-primary">
                {index + 1}
              </span>
              <p className="text-sm text-foreground/90">{step}</p>
            </li>
          ))}
        </ol>
        <div className="panel flex flex-col items-center justify-center gap-4 p-8 text-center">
          <span className="flex h-14 w-14 items-center justify-center rounded-2xl border border-accent/30 bg-accent/10">
            <Smartphone className="h-6 w-6 text-accent" />
          </span>
          <p className="font-heading text-sm tracking-[0.16em] text-foreground">PHONE PAIRING</p>
          <p className="text-[13px] leading-relaxed text-muted-foreground">
            Pairing needs the Stonic Windows companion app running and signed in to your account. The dashboard shows the QR screen and setup steps; the pairing link itself is not active in this web build.
          </p>
          <span className="chip">
            <QrCode className="h-3.5 w-3.5" /> Requires companion app
          </span>
        </div>
      </div>
    </section>
  );
}