import SectionHeading from '@/components/landing/SectionHeading';

const PRESETS = [
  { name: 'Tactical Core', tag: 'JARVIS-style', core: 'Him', copy: 'Brief, precise, always two steps ahead. Gives you the read-out, not a pep talk.' },
  { name: 'The Mentor', tag: 'Guide', core: 'Her', copy: 'Patient and structured. Breaks a problem down and walks it with you.' },
  { name: 'Best Friend', tag: 'Companion', core: 'Her', copy: 'Warm, playful, remembers the small stuff and asks about your day.' },
  { name: 'Your Own', tag: 'Custom', core: 'Her or him', copy: 'Write the personality yourself — tone, traits, greeting and instructions.' },
];

export default function CharactersSection() {
  return (
    <section className="mx-auto max-w-6xl px-5 py-16">
      <SectionHeading
        eyebrow="Characters"
        title="A JARVIS-style mind, a mentor, a best friend — or your own."
        copy="Each character carries its own voice, tone and traits, and you can switch the avatar between her and him at any time."
      />
      <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {PRESETS.map((preset) => (
          <article key={preset.name} className="panel panel-hover flex flex-col p-6">
            <span className="chip w-fit border-primary/30 text-primary/90">{preset.tag}</span>
            <h3 className="mt-4 font-heading text-lg font-medium text-foreground">{preset.name}</h3>
            <p className="mt-1 text-[11px] uppercase tracking-[0.2em] text-muted-foreground">{preset.core} core</p>
            <p className="mt-3 text-[13px] leading-relaxed text-muted-foreground">{preset.copy}</p>
          </article>
        ))}
      </div>
    </section>
  );
}