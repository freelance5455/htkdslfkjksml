import { Link } from 'react-router-dom';

const LIVE = [
  'Living particle avatar — her or him',
  'Voice conversation in your browser',
  'Memory, character and settings saved to your account',
  '3D globe + 2D command map + headlines by AI web search',
  'Visual Hub image generation',
];

const COMPANION = [
  'PC control — opening apps, files, volume and media',
  'Continuous background listening and wake word',
  'Stonic Remote phone calls while your PC is on',
];

export default function LandingFooter() {
  return (
    <footer className="border-t border-border/40 px-5 py-14">
      <div className="mx-auto max-w-6xl">
        <div className="grid gap-10 md:grid-cols-3">
          <div>
            <p className="font-heading text-sm tracking-[0.2em] text-foreground">MJ AI</p>
            <p className="mt-3 text-[13px] leading-relaxed text-muted-foreground">
              A character that lives inside your PC. Project owner: <span className="text-foreground/90">Sk Badal</span>.
            </p>
            <Link to="/app" className="btn-ghost mt-6 px-5 py-2.5 text-[13px]">
              Open the dashboard
            </Link>
          </div>
          <div>
            <p className="eyebrow">Works right now</p>
            <ul className="mt-4 space-y-2 text-[13px] text-muted-foreground">
              {LIVE.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </div>
          <div>
            <p className="eyebrow">Needs the Windows companion app</p>
            <ul className="mt-4 space-y-2 text-[13px] text-muted-foreground">
              {COMPANION.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </div>
        </div>
        <p className="mt-12 text-[12px] text-muted-foreground/70">
          MJ AI · Stonic interface build · Web dashboard and companion-app pairing screen. No invented satellite or telemetry feeds.
        </p>
      </div>
    </footer>
  );
}