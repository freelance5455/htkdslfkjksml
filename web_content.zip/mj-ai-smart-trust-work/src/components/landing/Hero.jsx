import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Globe } from 'lucide-react';
import ParticleFigure from '@/components/avatar/ParticleFigure';
import AvatarToggle from '@/components/avatar/AvatarToggle';

const FACTS = [
  { label: 'Living core', value: 'Particle figure' },
  { label: 'Circuits', value: 'Memory · Skills · Character · Settings' },
  { label: 'Platform', value: 'Web dashboard + Windows companion' },
];

export default function Hero() {
  const [gender, setGender] = useState('female');

  return (
    <section className="relative mx-auto max-w-6xl px-5 pb-16 pt-14 sm:pt-20">
      <div className="grid items-center gap-12 lg:grid-cols-[1.05fr_0.95fr]">
        <div>
          <p className="eyebrow mb-4">MJ AI · Owner Sk Badal</p>
          <h1 className="font-heading text-4xl font-semibold leading-[1.05] tracking-tight text-foreground sm:text-6xl">
            Meet <span className="text-primary text-glow">Stonic</span>.
          </h1>
          <p className="mt-5 max-w-xl text-[17px] leading-relaxed text-muted-foreground">
            A character that lives inside your PC — with a voice, a personality, and a memory of you. Talk naturally, watch it think, and let your desktop become mission control.
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-3">
            <Link to="/app" className="btn-primary">
              Start AI <ArrowRight className="h-4 w-4" />
            </Link>
            <a href="#world" className="btn-ghost">
              <Globe className="h-4 w-4" /> Explore World Monitor
            </a>
          </div>
          <dl className="mt-10 grid gap-4 sm:grid-cols-3">
            {FACTS.map((fact) => (
              <div key={fact.label} className="panel-soft px-4 py-3">
                <dt className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground">{fact.label}</dt>
                <dd className="mt-1 text-[13px] text-foreground/90">{fact.value}</dd>
              </div>
            ))}
          </dl>
        </div>

        <div className="relative">
          <div className="panel panel-hover relative overflow-hidden p-4">
            <ParticleFigure
              gender={gender}
              density={0.95}
              className="h-[420px] w-full sm:h-[500px]"
            />
            <div className="pointer-events-none absolute inset-x-0 top-4 flex items-center justify-between px-6">
              <span className="chip border-primary/30 text-primary/90">Living core</span>
              <span className="chip">Drag to rotate · scroll to zoom</span>
            </div>
            <div className="absolute inset-x-0 bottom-4 flex flex-col items-center gap-3 px-6">
              <p className="font-heading text-sm tracking-[0.2em] text-foreground/90">
                STONIC — {gender === 'female' ? 'HER CORE' : 'HIS CORE'}
              </p>
              <AvatarToggle value={gender} onChange={setGender} />
            </div>
          </div>
          <div className="pointer-events-none absolute -inset-6 -z-10 rounded-[2rem] bg-primary/10 blur-3xl" />
        </div>
      </div>
    </section>
  );
}