import { useState } from 'react';
import { Globe, Map, Newspaper } from 'lucide-react';
import Globe3D from '@/components/globe/Globe3D';
import SectionHeading from '@/components/landing/SectionHeading';
import { CATEGORY_COLORS, CATEGORY_LABELS, HOTSPOTS } from '@/lib/geo';

const POINTS = [
  { icon: Globe, title: 'A living 3D globe', copy: 'Spin it, zoom it, watch hotspots light up — drag it with your finger or mouse.' },
  { icon: Map, title: 'A full 2D command map', copy: 'Flip to the detailed picture, live on UTC time, with hotspots plotted per region.' },
  { icon: Newspaper, title: "Today's headlines", copy: 'Top stories pulled into one feed by AI web search — no tab-hopping.' },
];

export default function WorldSection() {
  const [selected, setSelected] = useState('kyiv');
  const spot = HOTSPOTS.find((item) => item.id === selected);

  return (
    <section id="world" className="mx-auto max-w-6xl px-5 py-16">
      <SectionHeading
        eyebrow="World Monitor"
        title="The whole world, on your radar."
        copy="A satellite-style command center built into the dashboard: a 3D globe with active hotspots, a 2D command map, and headlines flowing in around you."
      />
      <div className="mt-10 grid gap-6 lg:grid-cols-[1.25fr_0.75fr]">
        <div className="panel relative overflow-hidden">
          <Globe3D selectedId={selected} onSelect={setSelected} className="h-[420px] w-full" />
          <div className="pointer-events-none absolute left-5 top-5">
            <p className="chip border-primary/30 text-primary/90">Orbital view · UTC</p>
          </div>
          {spot ? (
            <div className="absolute bottom-5 left-5 right-5 flex flex-wrap items-center gap-3 rounded-xl border border-border/60 bg-background/70 px-4 py-3 backdrop-blur">
              <span className="h-2.5 w-2.5 rounded-full" style={{ background: CATEGORY_COLORS[spot.category] }} />
              <span className="font-heading text-sm text-foreground">{spot.name}</span>
              <span className="text-[12px] text-muted-foreground">{spot.country}</span>
              <span className="chip ml-auto">{CATEGORY_LABELS[spot.category]}</span>
              <span className="text-[12px] text-muted-foreground">{spot.note}</span>
            </div>
          ) : null}
        </div>
        <div className="flex flex-col gap-4">
          {POINTS.map((point) => (
            <article key={point.title} className="panel panel-hover flex gap-4 p-5">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-primary/30 bg-primary/10">
                <point.icon className="h-5 w-5 text-primary" />
              </span>
              <div>
                <h3 className="font-heading text-sm text-foreground">{point.title}</h3>
                <p className="mt-1.5 text-[13px] leading-relaxed text-muted-foreground">{point.copy}</p>
              </div>
            </article>
          ))}
          <p className="text-[12px] leading-relaxed text-muted-foreground">
            Hotspots are curated reference points. Headlines come live from AI web search when you open World Monitor. There is no real-time military satellite feed behind this build, and the app never pretends there is.
          </p>
        </div>
      </div>
    </section>
  );
}