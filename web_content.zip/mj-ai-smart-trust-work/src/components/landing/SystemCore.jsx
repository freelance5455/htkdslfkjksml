import { Brain, Puzzle, Sliders, Sparkles } from 'lucide-react';
import SectionHeading from '@/components/landing/SectionHeading';

const CIRCUITS = [
  {
    icon: Brain,
    name: 'Memory',
    copy: 'It remembers you — your name, your day, the things you care about. Saved to your account, never in a shared bucket.',
  },
  {
    icon: Puzzle,
    name: 'Skills',
    copy: 'The everyday things it can do when you ask: live headlines, visual generation, voice conversation. PC control skills stay clearly marked until the companion app is wired in.',
  },
  {
    icon: Sparkles,
    name: 'Character',
    copy: 'Who it is. A tactical JARVIS-style mind, a mentor, a best friend — or one you build yourself.',
  },
  {
    icon: Sliders,
    name: 'Settings',
    copy: 'Full control over how it listens, thinks and behaves: avatar, voice, pace, wake word and memory behaviour.',
  },
];

export default function SystemCore() {
  return (
    <section className="mx-auto max-w-6xl px-5 py-16">
      <SectionHeading
        eyebrow="System core"
        title="Four circuits shape who it is."
        copy="Hit Start AI, say something, and watch it think. Every circuit below is visible and adjustable inside the dashboard."
      />
      <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {CIRCUITS.map((circuit) => (
          <article key={circuit.name} className="panel panel-hover p-6">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl border border-accent/30 bg-accent/10">
              <circuit.icon className="h-5 w-5 text-accent" />
            </span>
            <h3 className="mt-5 font-heading text-base tracking-[0.14em] text-foreground">{circuit.name.toUpperCase()}</h3>
            <p className="mt-3 text-[13px] leading-relaxed text-muted-foreground">{circuit.copy}</p>
          </article>
        ))}
      </div>
    </section>
  );
}