import { Link } from 'react-router-dom';
import { Sparkles } from 'lucide-react';

const LINKS = [
  { label: 'Character', href: '#character' },
  { label: 'World Monitor', href: '#world' },
  { label: 'Remote', href: '#remote' },
  { label: 'Sign in', href: '#login' },
];

export default function LandingNav() {
  return (
    <header className="sticky top-0 z-40 border-b border-border/40 bg-background/70 backdrop-blur-xl">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-5 py-4">
        <Link to="/" className="flex items-center gap-3">
          <span className="relative flex h-9 w-9 items-center justify-center rounded-xl border border-primary/40 bg-primary/10">
            <Sparkles className="h-4 w-4 text-primary" />
          </span>
          <span className="leading-tight">
            <span className="block font-heading text-sm font-semibold tracking-[0.18em] text-foreground">MJ AI</span>
            <span className="block text-[10px] uppercase tracking-[0.22em] text-muted-foreground">by Sk Badal</span>
          </span>
        </Link>
        <nav className="hidden items-center gap-8 md:flex">
          {LINKS.map((link) => (
            <a key={link.href} href={link.href} className="text-sm text-muted-foreground transition hover:text-foreground">
              {link.label}
            </a>
          ))}
        </nav>
        <Link to="/app" className="btn-primary px-5 py-2.5 text-[13px]">
          Open the dashboard
        </Link>
      </div>
    </header>
  );
}