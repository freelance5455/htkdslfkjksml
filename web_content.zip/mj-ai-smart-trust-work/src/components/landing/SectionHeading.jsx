export default function SectionHeading({ eyebrow, title, copy, align = 'left', className = '' }) {
  return (
    <div className={`${align === 'center' ? 'mx-auto max-w-2xl text-center' : 'max-w-2xl'} ${className}`}>
      {eyebrow ? <p className="eyebrow mb-3">{eyebrow}</p> : null}
      <h2 className="font-heading text-3xl font-semibold leading-tight tracking-tight text-foreground sm:text-4xl">{title}</h2>
      {copy ? <p className="mt-4 text-[15px] leading-relaxed text-muted-foreground">{copy}</p> : null}
    </div>
  );
}