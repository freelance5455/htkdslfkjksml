import { useState } from 'react';
import { Mic, Volume2, VolumeX } from 'lucide-react';
import SectionHeading from '@/components/landing/SectionHeading';

const SAMPLE = 'Hello. I am Stonic. I remember you, and I am listening.';

export default function VoiceSection() {
  const [state, setState] = useState('idle');

  const speak = () => {
    if (typeof window === 'undefined' || !window.speechSynthesis) return;
    if (state === 'speaking') {
      window.speechSynthesis.cancel();
      setState('idle');
      return;
    }
    const utterance = new SpeechSynthesisUtterance(SAMPLE);
    utterance.rate = 0.98;
    utterance.pitch = 1.05;
    utterance.onend = () => setState('idle');
    utterance.onerror = () => setState('idle');
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utterance);
    setState('speaking');
  };

  return (
    <section className="mx-auto max-w-6xl px-5 py-16">
      <div className="grid items-center gap-10 lg:grid-cols-2">
        <SectionHeading
          eyebrow="Voice"
          title="Talk naturally — it answers like someone, not something."
          copy="Speech recognition and speech playback run in your own browser, so a conversation works right here. Continuous background listening needs the Windows companion app — this page stays honest about that."
        />
        <div className="panel p-7">
          <div className="flex items-center gap-4">
            <span className="flex h-12 w-12 items-center justify-center rounded-2xl border border-primary/30 bg-primary/10">
              <Mic className="h-5 w-5 text-primary" />
            </span>
            <div>
              <p className="font-heading text-sm text-foreground">Hear the voice</p>
              <p className="text-[12px] text-muted-foreground">Uses your browser's built-in speech engine.</p>
            </div>
          </div>
          <button type="button" onClick={speak} className="btn-primary mt-6 w-full">
            {state === 'speaking' ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
            {state === 'speaking' ? 'Stop the sample' : 'Play a sample line'}
          </button>
          <p className="mt-4 text-[12px] leading-relaxed text-muted-foreground">
            “{SAMPLE}”
          </p>
        </div>
      </div>
    </section>
  );
}