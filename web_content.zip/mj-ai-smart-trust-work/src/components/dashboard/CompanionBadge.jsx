import { MonitorSmartphone } from 'lucide-react';

export default function CompanionBadge({ note, className = '' }) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border border-accent/40 bg-accent/10 px-2.5 py-1 text-[10px] uppercase tracking-[0.16em] text-accent ${className}`}
      title={note || 'This needs the Stonic Windows companion app'}
    >
      <MonitorSmartphone className="h-3 w-3" />
      Companion app
    </span>
  );
}