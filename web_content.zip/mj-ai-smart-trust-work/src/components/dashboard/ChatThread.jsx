import { Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function ChatThread({ messages, greeting, characterName, thinking }) {
  return (
    <div className="panel flex h-full min-h-[420px] flex-col overflow-hidden">
      <div className="flex items-center justify-between border-b border-border/50 px-5 py-4">
        <div>
          <p className="font-heading text-sm text-foreground">{characterName || 'Stonic'}</p>
          <p className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground">Conversation</p>
        </div>
        <span className="chip">{messages.length} saved</span>
      </div>

      <div className="scroll-thin flex-1 space-y-4 overflow-y-auto px-5 py-5">
        {greeting ? (
          <div className="max-w-[85%] rounded-2xl rounded-bl-sm border border-primary/25 bg-primary/10 px-4 py-3 text-[13px] leading-relaxed text-foreground">
            {greeting}
          </div>
        ) : null}

        {messages.map((message) => (
          <div
            key={message.id}
            className={cn(
              'max-w-[85%] px-4 py-3 text-[13px] leading-relaxed',
              message.role === 'user'
                ? 'ml-auto rounded-2xl rounded-br-sm border border-border/60 bg-secondary/40 text-foreground'
                : 'rounded-2xl rounded-bl-sm border border-primary/25 bg-primary/10 text-foreground',
            )}
          >
            {message.content}
          </div>
        ))}

        {thinking ? (
          <div className="flex items-center gap-2 text-[12px] text-muted-foreground">
            <Loader2 className="h-3.5 w-3.5 animate-spin text-primary" /> Stonic is thinking…
          </div>
        ) : null}

        {!messages.length && !greeting ? (
          <p className="text-[13px] text-muted-foreground">No conversation yet. Press Start AI, or type a line below.</p>
        ) : null}
      </div>
    </div>
  );
}