import { Outlet } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { recordActivity } from '@/lib/activityLog';
import Sidebar from '@/components/dashboard/Sidebar';
import TopBar from '@/components/dashboard/TopBar';
import { AssistantProvider } from '@/lib/AssistantContext';

export default function DashboardLayout() {
  const [navOpen, setNavOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const labels = { '/app': 'Assistant dashboard opened', '/app/memory': 'Memory page opened', '/app/tasks': 'Tasks page opened', '/app/skills': 'Skills page opened', '/app/characters': 'AI agents page opened', '/app/world': 'Perlal World monitor opened', '/app/visual': 'Visual hub opened', '/app/remote': 'Remote control page opened', '/app/settings': 'Settings page opened', '/app/activity': 'Activity & Trust Log opened' };
    recordActivity({ title: labels[location.pathname] || 'Dashboard page opened', detail: location.pathname, category: 'navigation', status: 'info' });
  }, [location.pathname]);

  return (
    <AssistantProvider>
      <div className="min-h-screen lg:grid lg:grid-cols-[272px_1fr]">
        <Sidebar open={navOpen} onClose={() => setNavOpen(false)} />
        <div className="flex min-h-screen flex-col">
          <TopBar onMenu={() => setNavOpen(true)} />
          <main className="flex-1 px-4 py-6 sm:px-6 lg:px-8">
            <Outlet />
          </main>
        </div>
      </div>
    </AssistantProvider>
  );
}