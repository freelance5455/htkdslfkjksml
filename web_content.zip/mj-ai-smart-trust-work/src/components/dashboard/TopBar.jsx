import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { LogOut, Menu, ShieldCheck } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useAssistant } from '@/lib/AssistantContext';
import AvatarToggle from '@/components/avatar/AvatarToggle';

function useUtcClock() {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);
  const time = now.toISOString().slice(11, 19);
  const date = now.toISOString().slice(0, 10);
  return { time, date };
}

export default function TopBar({ onMenu }) {
  const { user, settings, setAvatarGender, activeCharacter } = useAssistant();
  const clock = useUtcClock();

  return (
    <header className="sticky top-0 z-30 border-b border-border/40 bg-background/70 backdrop-blur-xl">
      <div className="flex flex-wrap items-center gap-3 px-4 py-3 sm:px-6 lg:px-8">
        <button type="button" onClick={onMenu} className="rounded-lg border border-border/60 p-2 text-muted-foreground hover:text-foreground lg:hidden">
          <Menu className="h-4 w-4" />
        </button>

        <div className="hidden items-center gap-2 sm:flex">
          <span className="chip border-primary/30 text-primary/90">{activeCharacter?.name || 'Stonic'}</span>
          <span className="chip">Owner · Sk Badal</span>
        </div>

        <div className="ml-auto flex items-center gap-3">
          <div className="hidden text-right sm:block">
            <p className="font-mono text-[13px] text-foreground">{clock.time} UTC</p>
            <p className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">{clock.date}</p>
          </div>
          <AvatarToggle value={settings?.avatar_gender || 'female'} onChange={setAvatarGender} />
          <Link to="/app/settings" className="hidden items-center gap-2 rounded-full border border-border/60 px-3 py-2 text-[12px] text-muted-foreground transition hover:text-foreground sm:flex">
            {user?.role === 'admin' ? <ShieldCheck className="h-3.5 w-3.5 text-primary" /> : null}
            {user?.full_name || user?.email || 'Signed in'}
          </Link>
          <button
            type="button"
            onClick={() => base44.auth.logout('/login')}
            className="rounded-full border border-border/60 p-2 text-muted-foreground transition hover:border-destructive/50 hover:text-destructive"
            aria-label="Log out"
          >
            <LogOut className="h-4 w-4" />
          </button>
        </div>
      </div>
    </header>
  );
}