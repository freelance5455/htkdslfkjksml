import { NavLink } from 'react-router-dom';
import {
  Brain,
  CheckSquare,
  Activity,
  Globe,
  Image as ImageIcon,
  LayoutDashboard,
  Puzzle,
  Settings as SettingsIcon,
  Smartphone,
  Sparkles,
  Users,
  X,
} from 'lucide-react';
import { cn } from '@/lib/utils';

export const NAV_ITEMS = [
  { to: '/app', label: 'Character', icon: Sparkles, end: true },
  { to: '/app/memory', label: 'Memory', icon: Brain },
  { to: '/app/tasks', label: 'Tasks & Reminders', icon: CheckSquare },
  { to: '/app/activity', label: 'Activity & Trust Log', icon: Activity },
  { to: '/app/skills', label: 'Skills', icon: Puzzle },
  { to: '/app/characters', label: 'Characters', icon: Users },
  { to: '/app/world', label: 'World Monitor', icon: Globe },
  { to: '/app/visual', label: 'Visual Hub', icon: ImageIcon },
  { to: '/app/remote', label: 'Stonic Remote', icon: Smartphone },
  { to: '/app/settings', label: 'Settings', icon: SettingsIcon },
];

export default function Sidebar({ open, onClose }) {
  return (
    <>
      <button
        type="button"
        aria-label="Close navigation"
        onClick={onClose}
        className={cn(
          'fixed inset-0 z-40 bg-background/70 backdrop-blur-sm transition-opacity lg:hidden',
          open ? 'opacity-100' : 'pointer-events-none opacity-0',
        )}
      />
      <aside
        className={cn(
          'fixed inset-y-0 left-0 z-50 flex w-[272px] flex-col border-r border-border/50 bg-sidebar/95 backdrop-blur-xl transition-transform duration-300 lg:sticky lg:top-0 lg:h-screen lg:translate-x-0',
          open ? 'translate-x-0' : '-translate-x-full',
        )}
      >
        <div className="flex items-center justify-between px-5 py-5">
          <div className="flex items-center gap-3">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl border border-primary/40 bg-primary/10">
              <LayoutDashboard className="h-4 w-4 text-primary" />
            </span>
            <span className="leading-tight">
              <span className="block font-heading text-sm font-semibold tracking-[0.18em] text-foreground">MJ AI</span>
              <span className="block text-[10px] uppercase tracking-[0.22em] text-muted-foreground">by Sk Badal</span>
            </span>
          </div>
          <button type="button" onClick={onClose} className="rounded-lg p-2 text-muted-foreground hover:text-foreground lg:hidden">
            <X className="h-4 w-4" />
          </button>
        </div>

        <nav className="flex flex-1 flex-col gap-1 px-3 pb-6">
          {NAV_ITEMS.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              onClick={onClose}
              className={({ isActive }) =>
                cn(
                  'group flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition duration-300',
                  isActive
                    ? 'border border-primary/30 bg-primary/10 text-foreground'
                    : 'border border-transparent text-muted-foreground hover:border-border/60 hover:bg-secondary/30 hover:text-foreground',
                )
              }
            >
              {({ isActive }) => (
                <>
                  <item.icon className={cn('h-4 w-4', isActive ? 'text-primary' : 'text-muted-foreground group-hover:text-foreground')} />
                  <span>{item.label}</span>
                </>
              )}
            </NavLink>
          ))}
        </nav>

        <div className="px-5 pb-6">
          <p className="text-[11px] leading-relaxed text-muted-foreground">
            PC control, wake-word listening and phone calls need the Windows companion app.
          </p>
        </div>
      </aside>
    </>
  );
}