import { Link } from 'react-router-dom';
import { ArrowUpRight } from 'lucide-react';

export default function CircuitStat({ icon: Icon, label, value, hint, to }) {
  return (
    <Link to={to} className="panel panel-hover group flex flex-col gap-3 p-5">
      <div className="flex items-center justify-between">
        <span className="flex h-9 w-9 items-center justify-center rounded-xl border border-primary/30 bg-primary/10">
          <Icon className="h-4 w-4 text-primary" />
        </span>
        <ArrowUpRight className="h-4 w-4 text-muted-foreground transition group-hover:text-primary" />
      </div>
      <div>
        <p className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground">{label}</p>
        <p className="mt-1 font-heading text-lg text-foreground">{value}</p>
        {hint ? <p className="mt-1 text-[12px] leading-relaxed text-muted-foreground">{hint}</p> : null}
      </div>
    </Link>
  );
}