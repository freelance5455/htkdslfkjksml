import { Loader2, Mic, MicOff, Play, Send, Volume2, VolumeX } from 'lucide-react';
import { cn } from '@/lib/utils';

const STATUS_COPY = {
  idle: 'Idle — press Start AI to begin',
  listening: 'Listening…',
  thinking: 'Thinking…',
  speaking: 'Speaking…',
};

export default function VoiceConsole({
  status,
  supported,
  interim,
  input,
  onInput,
  onSend,
  onStart,
  onToggleMic,
  onStopSpeaking,
  busy,
}) {
  const listening = status === 'listening';

  return (
    <div className="panel p-5">
      <div className="flex flex-wrap items-center gap-3">
        <button type="button" onClick={onStart} disabled={busy} className="btn-primary px-5 py-2.5 text-[13px]">
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />}
          Start AI
        </button>
        <button
          type="button"
          onClick={onToggleMic}
          disabled={!supported || busy}
          className={cn(
            'inline-flex items-center gap-2 rounded-full border px-5 py-2.5 text-[13px] transition duration-300',
            listening ? 'border-primary/60 bg-primary/15 text-foreground' : 'border-border/70 text-muted-foreground hover:text-foreground',
            (!supported || busy) && 'cursor-not-allowed opacity-50',
          )}
          title={supported ? 'Push to talk' : 'Speech recognition needs Chrome or Edge'}
        >
          {listening ? <Mic className="h-4 w-4 text-primary" /> : <MicOff className="h-4 w-4" />}
          {listening ? 'Stop listening' : 'Push to talk'}
        </button>
        {status === 'speaking' ? (
          <button type="button" onClick={onStopSpeaking} className="btn-ghost px-4 py-2.5 text-[13px]">
            <VolumeX className="h-4 w-4" /> Stop voice
          </button>
        ) : (
          <span className="inline-flex items-center gap-2 text-[12px] text-muted-foreground">
            <Volume2 className="h-3.5 w-3.5" /> Replies are spoken in your browser
          </span>
        )}
        <span className="ml-auto flex items-center gap-2 text-[12px] text-muted-foreground">
          <span
            className={cn(
              'h-2 w-2 rounded-full',
              status === 'idle' ? 'bg-muted-foreground' : 'bg-primary shadow-[0_0_12px_hsl(var(--primary))] animate-pulse',
            )}
          />
          {STATUS_COPY[status]}
        </span>
      </div>

      {interim ? <p className="mt-4 text-[13px] italic text-primary/90">“{interim}”</p> : null}

      {!supported ? (
        <p className="mt-4 text-[12px] leading-relaxed text-muted-foreground">
          This browser cannot capture microphone input. Voice recognition works in Chrome and Edge — typing below works everywhere.
        </p>
      ) : null}

      <form
        className="mt-4 flex items-center gap-3"
        onSubmit={(event) => {
          event.preventDefault();
          onSend();
        }}
      >
        <input
          value={input}
          onChange={(event) => onInput(event.target.value)}
          placeholder="Say something to your character…"
          className="field"
          aria-label="Message to your character"
        />
        <button type="submit" disabled={busy || !input.trim()} className="btn-primary px-4 py-3">
          <Send className="h-4 w-4" />
        </button>
      </form>
    </div>
  );
}