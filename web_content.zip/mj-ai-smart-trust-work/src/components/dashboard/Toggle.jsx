import { cn } from '@/lib/utils';

export default function Toggle({ checked, onChange, disabled = false, label, className }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      disabled={disabled}
      onClick={() => !disabled && onChange(!checked)}
      className={cn(
        'relative inline-flex h-6 w-11 shrink-0 items-center rounded-full border transition duration-300',
        checked ? 'border-primary/60 bg-primary/25' : 'border-border/70 bg-secondary/40',
        disabled && 'cursor-not-allowed opacity-40',
        className,
      )}
    >
      <span
        className={cn(
          'absolute h-4 w-4 rounded-full transition duration-300',
          checked ? 'left-6 bg-primary shadow-[0_0_16px_hsl(var(--primary)/0.8)]' : 'left-1 bg-muted-foreground/70',
        )}
      />
    </button>
  );
}