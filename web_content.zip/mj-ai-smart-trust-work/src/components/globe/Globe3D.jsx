import { useEffect, useMemo, useRef } from 'react';
import * as THREE from 'three';
import { CATEGORY_COLORS, HOTSPOTS, buildLandDots, latLonToVec3 } from '@/lib/geo';

const ATMO_VERT = `
varying vec3 vNormal;
varying vec3 vView;
void main() {
  vNormal = normalize(normalMatrix * normal);
  vec4 mv = modelViewMatrix * vec4(position, 1.0);
  vView = normalize(-mv.xyz);
  gl_Position = projectionMatrix * mv;
}`;

const ATMO_FRAG = `
uniform vec3 uColor;
varying vec3 vNormal;
varying vec3 vView;
void main() {
  float f = pow(1.0 - max(dot(vNormal, vView), 0.0), 2.6);
  gl_FragColor = vec4(uColor, f * 0.7);
}`;

function radialTexture(inner, mid) {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d');
  const grad = ctx.createRadialGradient(64, 64, 0, 64, 64, 64);
  grad.addColorStop(0, inner);
  grad.addColorStop(0.4, mid);
  grad.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 128, 128);
  return new THREE.CanvasTexture(canvas);
}

export default function Globe3D({ selectedId = null, onSelect, className = '', autoRotate = true, showLabels = true }) {
  const hostRef = useRef(null);
  const labelLayerRef = useRef(null);
  const selectedRef = useRef(selectedId);
  selectedRef.current = selectedId;
  const onSelectRef = useRef(onSelect);
  onSelectRef.current = onSelect;

  const hotspots = useMemo(() => HOTSPOTS, []);

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return undefined;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.setClearColor(0x000000, 0);
    const canvas = renderer.domElement;
    canvas.style.width = '100%';
    canvas.style.height = '100%';
    canvas.style.display = 'block';
    canvas.style.cursor = 'grab';
    host.appendChild(canvas);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(38, 1, 0.1, 30);
    camera.position.set(0, 0, 3.1);

    const tilt = new THREE.Group();
    tilt.rotation.z = -0.32;
    scene.add(tilt);
    const world = new THREE.Group();
    tilt.add(world);

    const dotTex = radialTexture('rgba(150,245,255,0.95)', 'rgba(80,200,255,0.35)');
    const landGeo = new THREE.BufferGeometry();
    landGeo.setAttribute('position', new THREE.Float32BufferAttribute(buildLandDots(24000), 3));
    const landMat = new THREE.PointsMaterial({
      size: 0.016,
      map: dotTex,
      color: new THREE.Color('#7ff0ff'),
      transparent: true,
      opacity: 0.95,
      sizeAttenuation: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    world.add(new THREE.Points(landGeo, landMat));

    // Graticule
    const gridPoints = [];
    for (let lat = -60; lat <= 60; lat += 20) {
      for (let lon = -180; lon < 180; lon += 4) {
        const a = latLonToVec3(lat, lon, 1.004);
        const b = latLonToVec3(lat, lon + 4, 1.004);
        gridPoints.push(...a, ...b);
      }
    }
    for (let lon = -180; lon < 180; lon += 20) {
      for (let lat = -88; lat < 88; lat += 4) {
        const a = latLonToVec3(lat, lon, 1.004);
        const b = latLonToVec3(lat + 4, lon, 1.004);
        gridPoints.push(...a, ...b);
      }
    }
    const gridGeo = new THREE.BufferGeometry();
    gridGeo.setAttribute('position', new THREE.Float32BufferAttribute(gridPoints, 3));
    const gridMat = new THREE.LineBasicMaterial({ color: 0x2f6d7f, transparent: true, opacity: 0.28 });
    const grid = new THREE.LineSegments(gridGeo, gridMat);
    world.add(grid);

    // Atmosphere
    const atmoMat = new THREE.ShaderMaterial({
      uniforms: { uColor: { value: new THREE.Color('#57d9ff') } },
      vertexShader: ATMO_VERT,
      fragmentShader: ATMO_FRAG,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });
    const atmosphere = new THREE.Mesh(new THREE.SphereGeometry(1.09, 48, 32), atmoMat);
    world.add(atmosphere);

    // Hotspots
    const glowTex = radialTexture('rgba(255,255,255,0.95)', 'rgba(255,255,255,0.25)');
    const markers = hotspots.map((spot) => {
      const position = latLonToVec3(spot.lat, spot.lon, 1.012);
      const color = new THREE.Color(CATEGORY_COLORS[spot.category] || '#7ff0ff');
      const node = new THREE.Mesh(
        new THREE.SphereGeometry(0.012 + spot.level * 0.004, 12, 12),
        new THREE.MeshBasicMaterial({ color }),
      );
      node.position.set(...position);
      node.userData.id = spot.id;
      const halo = new THREE.Sprite(new THREE.SpriteMaterial({
        map: glowTex,
        color,
        transparent: true,
        opacity: 0.75,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      }));
      halo.position.set(...position);
      halo.scale.setScalar(0.12 + spot.level * 0.025);
      world.add(node);
      world.add(halo);
      return { spot, node, halo, position: new THREE.Vector3(...position) };
    });

    const labels = [];
    if (labelLayerRef.current && showLabels) {
      labelLayerRef.current.innerHTML = '';
      hotspots.forEach((spot) => {
        if (spot.level < 2) return;
        const el = document.createElement('div');
        el.textContent = spot.name;
        el.style.cssText = 'position:absolute;transform:translate(-50%,-50%);font-size:10px;letter-spacing:0.12em;text-transform:uppercase;color:rgba(220,246,255,0.72);pointer-events:none;white-space:nowrap;transition:opacity .3s';
        labelLayerRef.current.appendChild(el);
        labels.push({ spot, el });
      });
    }

    let yaw = 0.6;
    let targetYaw = 0.6;
    let pitch = 0.1;
    let targetPitch = 0.1;
    let dragging = false;
    let moved = 0;
    let lastX = 0;
    let lastY = 0;

    const raycaster = new THREE.Raycaster();
    const pointer = new THREE.Vector2();

    const onPointerDown = (e) => {
      dragging = true;
      moved = 0;
      lastX = e.clientX;
      lastY = e.clientY;
      canvas.style.cursor = 'grabbing';
    };
    const onPointerMove = (e) => {
      if (!dragging) return;
      const dx = e.clientX - lastX;
      const dy = e.clientY - lastY;
      moved += Math.abs(dx) + Math.abs(dy);
      targetYaw += dx * 0.006;
      targetPitch = Math.max(-0.9, Math.min(0.9, targetPitch + dy * 0.004));
      lastX = e.clientX;
      lastY = e.clientY;
    };
    const onPointerUp = (e) => {
      dragging = false;
      canvas.style.cursor = 'grab';
      if (moved > 6 || !onSelectRef.current) return;
      const rect = host.getBoundingClientRect();
      pointer.x = ((e.clientX - rect.left) / Math.max(1, rect.width)) * 2 - 1;
      pointer.y = -((e.clientY - rect.top) / Math.max(1, rect.height)) * 2 + 1;
      raycaster.setFromCamera(pointer, camera);
      const hit = raycaster.intersectObjects(markers.map((m) => m.node), false)[0];
      if (hit) onSelectRef.current(hit.object.userData.id);
    };
    const onWheel = (e) => {
      e.preventDefault();
      camera.position.z = Math.max(1.85, Math.min(4.3, camera.position.z + e.deltaY * 0.0016));
    };

    canvas.addEventListener('pointerdown', onPointerDown);
    window.addEventListener('pointermove', onPointerMove);
    window.addEventListener('pointerup', onPointerUp);
    canvas.addEventListener('wheel', onWheel, { passive: false });

    const resize = () => {
      const w = host.clientWidth || 1;
      const h = host.clientHeight || 1;
      renderer.setSize(w, h, false);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
    };
    resize();
    const observer = new ResizeObserver(resize);
    observer.observe(host);

    const clock = new THREE.Clock();
    let raf = 0;

    const tick = () => {
      const delta = Math.min(clock.getDelta(), 0.05);
      const t = clock.elapsedTime;
      if (autoRotate && !dragging) targetYaw += delta * 0.075;
      yaw += (targetYaw - yaw) * 0.08;
      pitch += (targetPitch - pitch) * 0.08;
      world.rotation.y = yaw;
      world.rotation.x = pitch;

      const camDir = new THREE.Vector3();
      camera.getWorldDirection(camDir);

      markers.forEach((marker, index) => {
        const selected = selectedRef.current === marker.spot.id;
        const pulse = 1 + Math.sin(t * 2.4 + index) * 0.28 + (selected ? 0.55 : 0);
        marker.halo.scale.setScalar((0.12 + marker.spot.level * 0.025) * pulse);
        marker.halo.material.opacity = selected ? 1 : 0.62;
        marker.node.scale.setScalar(selected ? 1.7 : 1);

        const worldPos = marker.position.clone().applyMatrix4(world.matrixWorld);
        const facing = worldPos.clone().normalize().dot(camDir) < -0.12;
        const label = labels.find((l) => l.spot.id === marker.spot.id);
        if (label) {
          const projected = worldPos.clone().project(camera);
          const rect = host.getBoundingClientRect();
          const x = (projected.x * 0.5 + 0.5) * rect.width;
          const y = (-projected.y * 0.5 + 0.5) * rect.height;
          label.el.style.left = `${x}px`;
          label.el.style.top = `${y - 14}px`;
          label.el.style.opacity = facing ? '0.85' : '0';
        }
      });

      renderer.render(scene, camera);
      raf = requestAnimationFrame(tick);
    };
    tick();

    return () => {
      cancelAnimationFrame(raf);
      observer.disconnect();
      canvas.removeEventListener('pointerdown', onPointerDown);
      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('pointerup', onPointerUp);
      canvas.removeEventListener('wheel', onWheel);
      landGeo.dispose();
      landMat.dispose();
      dotTex.dispose();
      gridGeo.dispose();
      gridMat.dispose();
      atmoMat.dispose();
      atmosphere.geometry.dispose();
      glowTex.dispose();
      markers.forEach((m) => {
        m.node.geometry.dispose();
        m.node.material.dispose();
        m.halo.material.dispose();
      });
      renderer.dispose();
      if (labelLayerRef.current) labelLayerRef.current.innerHTML = '';
      if (canvas.parentNode === host) host.removeChild(canvas);
    };
  }, [autoRotate, hotspots, showLabels]);

  return (
    <div className={`relative overflow-hidden ${className}`}>
      <div ref={hostRef} className="absolute inset-0" />
      <div ref={labelLayerRef} className="pointer-events-none absolute inset-0" />
    </div>
  );
}