import { useState } from 'react';
import { useEffect, useRef } from 'react';
import { useCallback } from 'react';
import { MapContainer, TileLayer, CircleMarker, Tooltip } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import { CATEGORY_COLORS, HOTSPOTS } from '@/lib/geo';

export default function CommandMap2D({ selectedId, onSelect }) {
  const [ready, setReady] = useState(false);
  const mapRef = useRef(null);

  useEffect(() => {
    const timer = setTimeout(() => setReady(true), 100);
    return () => clearTimeout(timer);
  }, []);

  const handleSelect = useCallback((id) => onSelect?.(id), [onSelect]);

  if (!ready) {
    return <div className="flex h-full items-center justify-center text-[13px] text-muted-foreground">Plotting command map…</div>;
  }

  return (
    <MapContainer
      ref={mapRef}
      center={[22, 12]}
      zoom={2}
      minZoom={2}
      maxZoom={7}
      scrollWheelZoom
      worldCopyJump
      style={{ height: '100%', width: '100%', background: '#06121a' }}
      attributionControl={false}
    >
      <TileLayer
        url="https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Base/MapServer/tile/{z}/{y}/{x}"
        attribution="Tiles &copy; Esri"
      />
      {HOTSPOTS.map((spot) => {
        const color = CATEGORY_COLORS[spot.category] || '#7ff0ff';
        const selected = selectedId === spot.id;
        return (
          <CircleMarker
            key={spot.id}
            center={[spot.lat, spot.lon]}
            radius={selected ? 11 : 4 + spot.level * 2.5}
            pathOptions={{
              color,
              fillColor: color,
              fillOpacity: selected ? 0.85 : 0.45,
              weight: selected ? 2.5 : 1.2,
            }}
            eventHandlers={{ click: () => handleSelect(spot.id) }}
          >
            <Tooltip direction="top" offset={[0, -6]}>
              <span className="text-[11px]">{spot.name} · {spot.note}</span>
            </Tooltip>
          </CircleMarker>
        );
      })}
    </MapContainer>
  );
}