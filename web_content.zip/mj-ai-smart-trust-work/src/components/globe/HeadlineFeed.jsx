import { useCallback, useEffect, useState } from 'react';
import { Loader2, Newspaper, RefreshCw } from 'lucide-react';
import { invokeFunction } from '@/lib/invoke';
import { CATEGORY_COLORS, CATEGORY_LABELS } from '@/lib/geo';

const CACHE_KEY = 'mj_ai_headlines_v1';
const MAX_AGE = 30 * 60 * 1000;

function timeAgo(iso) {
  if (!iso) return 'just now';
  const diff = Date.now() - new Date(iso).getTime();
  const minutes = Math.max(0, Math.round(diff / 60000));
  if (minutes < 1) return 'just now';
  if (minutes < 60) return `${minutes} min ago`;
  return `${Math.round(minutes / 60)} h ago`;
}

export default function HeadlineFeed({ compact = false }) {
  const [headlines, setHeadlines] = useState([]);
  const [fetchedAt, setFetchedAt] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const fetchHeadlines = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const data = await invokeFunction('getWorldHeadlines');
      const list = data?.headlines || [];
      if (!list.length) throw new Error('empty');
      setHeadlines(list);
      setFetchedAt(data.fetched_at || new Date().toISOString());
      localStorage.setItem(CACHE_KEY, JSON.stringify({ list, at: data.fetched_at || new Date().toISOString() }));
    } catch {
      setError('The headline feed could not be reached. Try again in a moment.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    try {
      const cached = JSON.parse(localStorage.getItem(CACHE_KEY) || 'null');
      if (cached?.list?.length && Date.now() - new Date(cached.at).getTime() < MAX_AGE) {
        setHeadlines(cached.list);
        setFetchedAt(cached.at);
        setLoading(false);
        return;
      }
    } catch {
      /* ignore a broken cache */
    }
    fetchHeadlines();
  }, [fetchHeadlines]);

  return (
    <section className="panel flex flex-col overflow-hidden">
      <div className="flex items-center justify-between gap-3 border-b border-border/50 px-5 py-4">
        <div className="flex items-center gap-2">
          <Newspaper className="h-4 w-4 text-primary" />
          <div>
            <p className="font-heading text-sm text-foreground">Today&apos;s headlines</p>
            <p className="text-[11px] text-muted-foreground">AI web search · {fetchedAt ? timeAgo(fetchedAt) : 'loading'}</p>
          </div>
        </div>
        <button type="button" onClick={fetchHeadlines} disabled={loading} className="btn-ghost px-3 py-2 text-[12px]">
          {loading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RefreshCw className="h-3.5 w-3.5" />}
          Refresh
        </button>
      </div>

      <div className={`scroll-thin flex-1 space-y-3 overflow-y-auto px-5 py-5 ${compact ? 'max-h-[420px]' : ''}`}>
        {loading && !headlines.length ? (
          Array.from({ length: 4 }).map((_, index) => (
            <div key={index} className="animate-pulse rounded-xl border border-border/40 bg-secondary/20 p-4">
              <div className="h-3 w-2/3 rounded bg-secondary/60" />
              <div className="mt-3 h-3 w-1/3 rounded bg-secondary/40" />
            </div>
          ))
        ) : null}

        {error ? (
          <div className="rounded-xl border border-destructive/40 bg-destructive/10 p-4 text-[13px] text-foreground/90">
            {error}
          </div>
        ) : null}

        {headlines.map((item, index) => (
          <article key={`${item.title}-${index}`} className="rounded-xl border border-border/50 bg-secondary/15 p-4">
            <div className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full" style={{ background: CATEGORY_COLORS[item.category] || '#7ff0ff' }} />
              <span className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                {CATEGORY_LABELS[item.category] || 'World'}
              </span>
              {item.region ? <span className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground/70">· {item.region}</span> : null}
            </div>
            <h3 className="mt-2 text-[14px] font-medium leading-snug text-foreground">{item.title}</h3>
            {item.summary ? <p className="mt-1.5 text-[12px] leading-relaxed text-muted-foreground">{item.summary}</p> : null}
            <p className="mt-2 text-[11px] text-muted-foreground/80">Source: {item.source}</p>
          </article>
        ))}
      </div>
    </section>
  );
}