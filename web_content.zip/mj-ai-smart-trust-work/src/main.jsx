import React from 'react';
import ReactDOM from 'react-dom/client';
import App from '@/App.jsx';
import PWAInstallPrompt from '@/components/PWAInstallPrompt.jsx';
import '@/index.css';

if (import.meta.env.PROD && 'serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch((error) => {
      console.error('MJ AI offline shell registration failed:', error);
    });
  });
}

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
    <PWAInstallPrompt />
  </React.StrictMode>,
);
