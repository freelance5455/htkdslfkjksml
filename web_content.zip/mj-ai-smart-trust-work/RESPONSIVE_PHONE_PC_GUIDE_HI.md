# MJ AI — Phone + PC Setup (Hindi)

## क्या बदला गया
- Dashboard के लिए cross-device responsive CSS जोड़ी गई है।
- फोन पर horizontal overflow कम करने, बड़े touch targets, safe-area spacing और छोटे स्क्रीन पर padding के सुधार जोड़े गए हैं।
- Reduced-motion accessibility का समर्थन जोड़ा गया है।
- यह web app PC और phone browser में खुलने के लिए है; फोन पर installable PWA/Play Store app या सुरक्षित remote-control pairing अपने-आप इस बदलाव से तैयार नहीं होती।

## PC पर चलाना
1. ZIP Extract करें और `mj-ai-work` फ़ोल्डर खोलें।
2. Node.js का समर्थित संस्करण इंस्टॉल हो।
3. Terminal में चलाएँ:
   ```bash
   npm install
   npm run dev
   ```
4. Terminal में दिखा local URL PC browser में खोलें।
5. Production bundle जाँचने के लिए `npm run build` चलाएँ।

## Phone पर टेस्ट
- फोन और PC एक ही Wi-Fi पर हों।
- Vite dev server को LAN पर उपलब्ध कराने के लिए `npm run dev -- --host 0.0.0.0` चलाएँ।
- PC का स्थानीय IPv4 पता और Vite द्वारा दिखाया गया port फोन के browser में खोलें, जैसे `http://192.168.x.x:5173`। अपना वास्तविक IP इस्तेमाल करें; उदाहरण वाला IP नहीं।
- Windows Firewall अनुमति माँगे तो केवल private network पर अनुमति दें। सार्वजनिक Wi-Fi पर dev server न खोलें।
- Login/auth और API connections को भी जाँचें; कुछ Base44/auth सुविधाएँ configured domain के बिना dev mode में काम नहीं कर सकतीं।

## सुरक्षा सीमा
यह responsive UI update है, पूर्ण native Android app नहीं। फोन से PC को नियंत्रित करने के लिए authenticated pairing, encrypted transport, expiring tokens, explicit user approval और audit log चाहिए। इंटरनेट पर port-forwarding करके companion को सीधे expose न करें। API keys को frontend code या Git में न रखें; backend secrets का उपयोग करें।
