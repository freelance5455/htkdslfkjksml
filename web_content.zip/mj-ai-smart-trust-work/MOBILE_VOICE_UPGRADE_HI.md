# MJ AI — Mobile Control + Better Voice (Hindi Setup)

## Is upgrade mein kya badla

- Settings mein installed browser/Windows voices ki list dikhane ka option.
- Aap ek specific system voice select kar sakte hain; selection `voice_uri` setting mein save hota hai.
- `Preview selected voice` button Hindi + English sample bolta hai.
- Chat/Character speech selected system voice ko use karne ki koshish karta hai; selection unavailable ho to personality/language ke hisaab se fallback voice chunta hai.
- Existing Remote page pairing ko prototype hi batata hai; fake QR ko live/secure pairing nahi maana gaya.

## Voice kaise set karein

1. MJ AI dashboard khol kar **Settings → Voice** par jaayein.
2. `Voice personality` mein Maya/Mayra/Jarvis/Friday mein se style chunein.
3. `Installed device voice` mein Windows/browser ki voice select karein ya `Automatic` chhodein.
4. `Preview selected voice` dabayein. Voice list khaali ho to Chrome/Edge update karein aur Windows Settings → Time & language → Language & region mein speech voices install karein.
5. Hindi speech ke liye `Speech recognition language` ko Hindi par set karein. Microphone use karte waqt browser permission Allow honi chahiye.

## Mobile control: current safe status

Remote screen abhi pairing UI/prototype hai. QR code aur pairing code apne aap secure connection nahi banate. Windows companion jaan-bujhkar `127.0.0.1` par hi sunta hai, isliye phone se seedha connect nahi hoga. Isko `0.0.0.0` par kholna ya router par port forward karna surakshit tareeqa nahi hai.

Real mobile control ke liye agla engineering step ek authenticated relay/backend banana hai:

1. Phone aur PC dono user ke authenticated account se connect hon.
2. PC companion relay ke saath outbound TLS/WebSocket connection banaye; inbound internet port expose na ho.
3. Pairing QR mein short-lived, single-use random token ho — user ID se bana permanent code nahi.
4. Phone par har sensitive action se pehle confirmation ho; app-launch actions allowlist mein rahen.
5. Tokens server-side secrets mein rahen, logs mein nahi; rate limits, expiry aur revoke-pairing control ho.
6. Remote disconnect / revoke button aur activity log ho.

## Security notes

- API keys ko frontend `.env` ke `VITE_*` variables mein mat rakhein. Server-side secrets use karein.
- Is ZIP mein koi API key ya password included nahi hai.
- Voice availability OS/browser par depend karti hai. Yeh installed system voices ka selection hai, kisi proprietary Maya/Jarvis voice ki exact copy nahi.
- Production build is environment mein run/verify nahi kiya gaya; install dependencies and run `npm run build` on the development PC before publishing.
