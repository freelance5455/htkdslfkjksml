# MJ AI Activity & Trust Log Upgrade (Hindi)

## Is update mein kya hai?
- Dashboard mein `Activity & Trust Log` naya page aur sidebar link.
- App navigation aur Tasks page ke create/complete/reopen/reschedule/delete actions ka local log.
- Status: success, info, warning, error.
- Log ko JSON file ke roop mein export karna aur local entries clear karna.
- Browser ke `localStorage` mein adhiktam 300 entries; data isi browser/device par rehta hai.

## Important limitations
- Yeh OS-level ya phone ki har activity ko record nahi karta.
- Do devices ke logs automatically sync nahi hote.
- Browser storage clear hone par log delete ho sakta hai.
- App ke kuch actions log nahi hote jab tak unmein `recordActivity()` integration na ho.
- Is page ko privacy-friendly rakhne ke liye passwords, API keys, aur task notes ka sensitive content log nahi kiya jata; task title hi detail ke roop mein record hota hai.

## Test
```bash
npm run test:chat-safety
npm run build
```
Build environment mein Vite/dependencies missing hon to `npm ci` chalakar phir retry karein. Agar error aaye to uska exact text share karein.
