# MJ AI — Release checklist (Hindi)

- [ ] API keys केवल server secrets में; frontend bundle, git, screenshots और logs में नहीं।
- [ ] `.env` files gitignored हैं; `.env.example` में केवल खाली placeholders हैं।
- [ ] कोई वास्तविक key commit हो गई हो तो उसे तुरंत revoke/rotate करें।
- [ ] संवेदनशील actions पर confirmation और cancel option मौजूद है।
- [ ] Mobile pairing authenticated है; short-lived token और revoke option है।
- [ ] Companion app केवल allowlisted operations स्वीकार करता है; arbitrary shell नहीं।
- [ ] Logs में secrets, tokens, private content redact होते हैं।
- [ ] Memory opt-in है; user review/edit/delete कर सकता है।
- [ ] Provider data-sharing और API cost user को बताई जाती है।
- [ ] Network/API failure पर साफ error दिखता है; fake success नहीं।
- [ ] npm run lint, npm run test:chat-safety और npm run build सफल हुए।
- [ ] Windows companion को standard user permissions पर चलाकर test किया गया।
- [ ] Backup/rollback और recovery instructions मौजूद हैं।

यह checklist है, सुरक्षा प्रमाणपत्र नहीं। हर checkbox वास्तविक परीक्षण के बाद ही टिक करें।
