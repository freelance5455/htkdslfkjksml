# MJ AI अगला अपग्रेड — हिंदी सेटअप गाइड

## अभी प्रोजेक्ट में क्या मौजूद है
- OpenAI server-side integration template (`OPENAI_API_KEY` को server secret में रखना है)
- वेब संदर्भ का विकल्प; उपलब्धता Base44 integration और उसके permissions पर निर्भर है
- ब्राउज़र-आधारित voice reply settings; वास्तविक आवाज़ डिवाइस/ब्राउज़र में उपलब्ध voices पर निर्भर करती है
- Remote page पर PC companion pairing अभी prototype/placeholder है
- `windows-companion/` में local-only Windows bridge prototype जो केवल Notepad, Calculator, Paint और File Explorer खोल सकता है

## चरण 1 — API और वेब रिसर्च
1. Base44 में server-side secret `OPENAI_API_KEY` सेट करें।
2. कोई भी key `VITE_` से शुरू होने वाले frontend environment variable में न रखें।
3. ऐप में Live web context सक्षम रखें। यदि Base44 internet context integration उपलब्ध नहीं है, तो वह feature live search की गारंटी नहीं देता; provider integration की स्थिति जाँचें।
4. छोटे, सामान्य प्रश्न से परीक्षण करें और देखें कि जवाब में स्रोत/अनिश्चितता ईमानदारी से बताई जाती है या नहीं।

## चरण 2 — Voice
1. Settings → Voice में Voice replies चालू करें।
2. Maya/Mayra/Jarvis-जैसे preset केवल rate/pitch शैली हैं, किसी वास्तविक पात्र की आवाज़ की नकल या licensed voice की गारंटी नहीं।
3. यदि डिवाइस में बेहतर आवाज़ चाहिए, तो अलग TTS provider को server-side जोड़ना होगा; API key केवल server secret में रहे।

## चरण 3 — Windows PC control prototype
`windows-companion/README.md` के निर्देशों का पालन करें। यह केवल स्थानीय कंप्यूटर पर चलता है और सीमित ऐप-लॉन्च की अनुमति देता है। इसे इंटरनेट पर expose न करें। अभी web dashboard से end-to-end pairing जुड़ी हुई नहीं है।

## सुरक्षा नियम
- असली API keys ZIP में शामिल नहीं हैं।
- AI को arbitrary shell commands चलाने की अनुमति न दें।
- फाइल हटाने, संदेश भेजने, खरीदारी, या सिस्टम सेटिंग बदलने से पहले स्पष्ट पुष्टि रखें।
- किसी action को सफल तभी कहें जब companion से सफलता का उत्तर मिला हो।
