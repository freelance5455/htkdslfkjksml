# MJ AI Windows Companion (prototype)

This is a local-only starter for a future MJ AI PC-control bridge. It intentionally supports only four allowlisted actions: Notepad, Calculator, Paint, and File Explorer. It does not accept shell commands, arbitrary file paths, or remote network connections.

## Start on Windows

1. Install Python 3.10+ from python.org.
2. Open PowerShell in this folder.
3. Create a long random token and set it for this PowerShell window:

```powershell
$env:MJ_COMPANION_TOKEN = [guid]::NewGuid().ToString() + [guid]::NewGuid().ToString()
python .\mj_companion.py
```

The server listens only on `127.0.0.1:8765`. Keep this terminal open while using it. Do not expose the port through your router or firewall.

## Test status

In a second PowerShell window, use the same token value you set in the first window:

```powershell
$env:MJ_COMPANION_TOKEN = "PASTE_THE_SAME_TOKEN_HERE"
curl.exe -H "Authorization: Bearer $env:MJ_COMPANION_TOKEN" http://127.0.0.1:8765/status
```

## Open an allowlisted app

```powershell
curl.exe -X POST http://127.0.0.1:8765/open `
  -H "Authorization: Bearer $env:MJ_COMPANION_TOKEN" `
  -H "Content-Type: application/json" `
  -d '{"app":"calculator"}'
```

Allowed names: `notepad`, `calculator`, `paint`, `file_explorer`.

## Important limits

- This is a prototype bridge, not a finished integration with the web dashboard. The dashboard must explicitly ask the user to confirm an action and send the token only from a trusted local client before it can use the bridge.
- Do not put the token or provider API keys in frontend source code, `VITE_*` variables, screenshots, or public repositories.
- Browser support depends on the origin and browser security settings. The server only allows local Vite origins by default.
- Do not add arbitrary PowerShell execution, unrestricted file operations, credential access, or silent background monitoring.
