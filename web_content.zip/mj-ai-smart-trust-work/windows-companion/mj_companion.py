"""MJ AI Windows companion prototype: local-only, allowlisted actions.
Run on Windows with Python 3.10+: set MJ_COMPANION_TOKEN to a long random secret first.
This is a prototype, not a production remote-access service.
"""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json, os, secrets, subprocess, platform
from urllib.parse import urlparse

HOST = "127.0.0.1"  # intentionally loopback-only; never bind to 0.0.0.0
PORT = int(os.environ.get("MJ_COMPANION_PORT", "8765"))
TOKEN = os.environ.get("MJ_COMPANION_TOKEN", "")
ALLOWED_ORIGINS = {"http://localhost:5173", "http://127.0.0.1:5173"}

# Explicit allowlist: no shell, no arbitrary paths, no command execution from user text.
APPS = {
    "notepad": ["notepad.exe"],
    "calculator": ["calc.exe"],
    "paint": ["mspaint.exe"],
    "file_explorer": ["explorer.exe"],
}

class Handler(BaseHTTPRequestHandler):
    server_version = "MJCompanion/0.1"

    def log_message(self, fmt, *args):
        # Keep logs useful but avoid printing request bodies or secrets.
        print("[MJ Companion]", fmt % args)

    def _json(self, status, payload):
        data = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        origin = self.headers.get("Origin", "")
        if origin in ALLOWED_ORIGINS:
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Vary", "Origin")
        self.send_header("Access-Control-Allow-Headers", "Authorization, Content-Type")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.end_headers()
        self.wfile.write(data)

    def _authorized(self):
        auth = self.headers.get("Authorization", "")
        supplied = auth.removeprefix("Bearer ") if auth.startswith("Bearer ") else ""
        return bool(TOKEN) and secrets.compare_digest(supplied, TOKEN)

    def do_OPTIONS(self):
        origin = self.headers.get("Origin", "")
        if origin not in ALLOWED_ORIGINS:
            return self._json(403, {"error": "origin not allowed"})
        self._json(204, {})

    def do_GET(self):
        if urlparse(self.path).path != "/status":
            return self._json(404, {"error": "not found"})
        if not self._authorized():
            return self._json(401, {"error": "unauthorized"})
        self._json(200, {"ok": True, "name": "MJ AI Windows Companion", "platform": platform.system(), "actions": sorted(APPS)})

    def do_POST(self):
        if urlparse(self.path).path != "/open":
            return self._json(404, {"error": "not found"})
        if not self._authorized():
            return self._json(401, {"error": "unauthorized"})
        origin = self.headers.get("Origin", "")
        if origin and origin not in ALLOWED_ORIGINS:
            return self._json(403, {"error": "origin not allowed"})
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length < 1 or length > 2048:
                return self._json(400, {"error": "invalid request size"})
            body = json.loads(self.rfile.read(length).decode("utf-8"))
        except Exception:
            return self._json(400, {"error": "invalid JSON"})
        app = body.get("app") if isinstance(body, dict) else None
        if app not in APPS:
            return self._json(400, {"error": "app not allowlisted", "allowed": sorted(APPS)})
        try:
            subprocess.Popen(APPS[app], shell=False, close_fds=True)
        except Exception:
            return self._json(500, {"error": "could not open app"})
        self._json(200, {"ok": True, "opened": app})

if __name__ == "__main__":
    if platform.system() != "Windows":
        raise SystemExit("This companion prototype is intended for Windows.")
    if len(TOKEN) < 32:
        raise SystemExit("Set MJ_COMPANION_TOKEN to a random secret of at least 32 characters before running.")
    print(f"MJ AI Companion listening on http://{HOST}:{PORT}")
    print("Loopback only. Allowlisted actions:", ", ".join(sorted(APPS)))
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
