# MJ AI mobile-control next steps (Hindi)

The current Windows companion is deliberately local-only and allowlisted. Do not expose it directly to Wi-Fi/internet by changing HOST to `0.0.0.0` or by port forwarding.

For real phone-to-PC control, implement a server-side authenticated relay (TLS WebSocket) where the PC initiates the connection outward. Pair with a cryptographically random, short-lived, single-use token, require account authentication on both devices, confirm actions on the phone, expire/revoke sessions, rate-limit requests, and keep only allowlisted actions. Never send API keys or the companion token to browser code.

The dashboard's existing Remote page is a visual pairing prototype until this relay and handshake are implemented and tested. Do not describe it as connected yet.
