# MJ AI — Smart, Honest & Dependable Upgrade (Hindi)

## इस अपडेट में वास्तविक बदलाव
- Chat backend के assistant instructions में trustworthiness और loyalty को ईमानदारी, गोपनीयता, अनुमति और वास्तविक follow-through के रूप में परिभाषित किया गया है।
- अनिश्चित जानकारी को स्पष्ट बताने, स्रोत/लाइव रिसर्च का दावा न गढ़ने और पूरा न हुआ काम पूरा घोषित न करने पर जोर।
- जटिल कामों के लिए छोटा प्लान, उपलब्ध काम पूरा करना, आउटपुट जाँचना और बाकी रुकावटें बताना।
- संवेदनशील/अपरिवर्तनीय कामों के लिए जोखिम बताना और जहाँ जरूरी हो पुष्टि लेना।
- गतिविधि के बारे में attempted, completed, failed और pending स्थितियों को अलग-अलग बताने का नियम।
- मॉडल को exclusive ownership या इंसानी भावनाओं का झूठा दावा करने से रोकना।

## यह क्या नहीं करता
- यह prompt/backend behavior update है; इससे अपने-आप नए API, लगातार background listening, live PC control, वास्तविक 3D hologram या फोन-से-PC remote access नहीं जुड़ते।
- वास्तविक गतिविधि लॉग के लिए action handlers को structured audit events लिखने हेतु अलग से implement करना होगा।
- सभी सुविधाएँ तभी काम करेंगी जब Base44 deployment, secrets और संबंधित integrations सही तरह configured हों।

## PC पर परीक्षण
```bash
npm ci
npm run test:chat-safety
npm run build
```
यदि `npm ci` या build में त्रुटि आए, पूरा error text सुरक्षित रखें और भेजें। API keys को source code या सार्वजनिक ZIP में न रखें।
