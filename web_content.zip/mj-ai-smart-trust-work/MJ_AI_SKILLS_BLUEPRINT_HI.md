# MJ AI — Smart, Trustworthy Skills Blueprint (Hindi)

यह दस्तावेज़ MJ AI को चरणबद्ध तरीके से सक्षम बनाने की योजना है। सूची में **अभी मौजूद**, **सीमित prototype**, और **भविष्य में जोड़ने योग्य** क्षमताओं को अलग रखा गया है। सूची में नाम होने का अर्थ यह नहीं कि हर सुविधा अभी चल रही है।

## MJ AI का भरोसा/ईमानदारी प्रोटोकॉल

1. **सच बोलो:** उत्तर की पुष्टि न हो तो साफ कहो कि निश्चित नहीं हो; स्रोत या अनुमान को तथ्य बनाकर न बताओ।
2. **वादा नहीं, प्रमाण:** किसी फाइल, ऐप, ईमेल या सेटिंग में बदलाव करने का दावा तभी करो जब टूल ने सफलता बताई हो।
3. **मालिक के निर्देश:** उपयोगकर्ता की पसंद और स्पष्ट निर्देश मानो, लेकिन सुरक्षा, कानून, गोपनीयता और सिस्टम की सुरक्षा से ऊपर कोई आदेश नहीं।
4. **अनुमति:** ईमेल भेजना, फाइल मिटाना, भुगतान, इंस्टॉल/अनइंस्टॉल, सिस्टम सेटिंग बदलना, रिमोट एक्सेस चालू करना या डेटा साझा करना—पहले स्पष्ट पुष्टि लो।
5. **निजता:** पासवर्ड, OTP, निजी API key, बैंक विवरण या निजी पहचान को memory में सेव न करो।
6. **नियंत्रण उपयोगकर्ता के पास:** memory देखना/मिटाना, integrations बंद करना, activity log देखना और remote access revoke करना आसान होना चाहिए।
7. **कम से कम अधिकार:** हर skill केवल जरूरी permissions ले। मोबाइल/वेब से arbitrary shell command न चलने दो।
8. **असफलता स्पष्ट करो:** इंटरनेट, API, microphone या companion app उपलब्ध न हो तो दिखाओ कि सुविधा काम नहीं कर रही—नकली success नहीं।
9. **स्रोत दिखाओ:** वेब रिसर्च के निष्कर्ष के साथ स्रोत और तारीख दिखाओ; तथ्य, राय और अनुमान अलग रखो।
10. **मानवीय निर्णय:** बड़े या अपरिवर्तनीय निर्णय उपयोगकर्ता से पुष्टि के बिना न लो।

## Skill catalog

### A. अभी के dashboard में मौजूद/आंशिक रूप से मौजूद (कोड देखकर स्थिति फिर जाँचें)
- बातचीत और चैट UI
- Assistant settings और theme
- Character/avatar चयन
- Skills enable/disable UI
- Memory items देखना, pin करना और हटाना
- Browser speech APIs पर आधारित voice hooks (ब्राउज़र और permissions पर निर्भर)
- Tasks, remote-control dashboard, visual hub और world monitor के UI पेज
- Trust mode तथा sensitive action confirmation के settings fields

### B. Windows companion prototype — सीमित
- Calculator खोलना
- Notepad खोलना
- Paint खोलना
- File Explorer खोलना

यह prototype केवल allowlisted apps के लिए होना चाहिए। इसे arbitrary commands, administrator privileges या internet से आने वाले shell commands न दें।

### C. अगली सुरक्षित सुविधाएँ (implementation आवश्यक)
1. **Web research:** स्रोतों सहित खोज, तारीख/लेखक का संकेत, कई स्रोतों की तुलना।
2. **Document helper:** उपयोगकर्ता द्वारा चुनी फाइल का सारांश, OCR/टेक्स्ट extraction, प्रश्नोत्तर।
3. **Writing assistant:** ईमेल/पत्र/पोस्ट के draft; भेजने से पहले preview और पुष्टि।
4. **Task planner:** checklist, deadline, priority, progress status।
5. **Calendar integration:** केवल OAuth और स्पष्ट अनुमति के बाद event पढ़ना/बनाना।
6. **Email assistant:** खोज/सारांश; send/delete/archive से पहले confirmation।
7. **Voice input:** microphone permission, push-to-talk default, mute indicator।
8. **Text-to-speech:** उपलब्ध सिस्टम voices की सूची, voice preview, speed/pitch controls।
9. **Wake word:** optional, visibly enabled, local privacy indicator; default off।
10. **Conversation context:** current session context; long-term memory opt-in।
11. **Memory manager:** review/edit/delete/export; sensitive-data filters।
12. **Personal preferences:** भाषा, output length, preferred workflow—consent के साथ।
13. **PC app launcher:** allowlist से ही apps खोलना।
14. **File search:** user-selected folders; default read-only।
15. **File operations:** copy/rename/create; delete/overwrite पर confirmation।
16. **Clipboard helper:** केवल user action से clipboard पढ़ना/लिखना।
17. **System status:** CPU/RAM/disk/battery जैसी read-only जानकारी।
18. **Mobile pairing:** QR/token pairing, TLS, short-lived tokens, revoke button।
19. **Remote actions:** authenticated allowlist; हर action का audit log; no public unauthenticated port।
20. **Activity timeline:** समय, skill, result, permission, error—secrets को redact करके।
21. **API health monitor:** provider configured/healthy/error; key कभी UI/log में न दिखे।
22. **Provider fallback:** configured provider fail होने पर user-visible fallback; data sharing policy बताकर।
23. **Rate/cost limits:** daily budget, request limits, usage display।
24. **Offline fallback:** local commands and basic help when internet is unavailable।
25. **Image understanding:** user-selected images; people identity inference नहीं।
26. **Image generation:** configured image provider और cost/availability checks।
27. **Speech transcription:** audio upload/processing से पहले user consent।
28. **Translation:** Hindi/English and more languages, with uncertainty warnings for critical text।
29. **Learning mode:** step-by-step explanations, practice and quizzes।
30. **Coding helper:** code explanation, test generation, patch preview; run commands only with confirmation।
31. **Error diagnosis:** sanitized logs, likely causes, reversible fixes first।
32. **Backup/export:** settings and user-approved data export; encrypted backup option।
33. **Recovery:** restore point before risky updates; rollback guide।
34. **Accessibility:** keyboard navigation, captions, adjustable text size।
35. **Notifications:** user-defined quiet hours and opt-in notifications।
36. **Multi-profile:** separate preferences and memory per authenticated user।
37. **Security dashboard:** connected providers, permissions, active sessions, revoke controls।
38. **Update checker:** signed releases, changelog, rollback support।
39. **Test suite:** unit tests for permission gates, API failures, memory redaction and companion allowlist।
40. **Health check:** microphone, speech engine, internet, provider and companion status.

## Recommended implementation order

**Phase 1 — Trust & stability:** server-side API secrets, error states, memory review/delete, action confirmations, tests.

**Phase 2 — Useful intelligence:** research with citations, document Q&A, task planner, writing drafts, language preferences.

**Phase 3 — Voice:** voice selection and preview, push-to-talk, transcription, speech output; wake word optional.

**Phase 4 — PC companion:** allowlisted app launch, read-only system status, selected-folder search, activity log.

**Phase 5 — Mobile remote control:** authenticated pairing, TLS, short-lived tokens, revocation and audit log. Do not expose a raw shell or unauthenticated port.

**Phase 6 — Integrations:** add only providers that offer a real benefit. Fifteen API keys are not automatically fifteen skills; each needs integration code, permissions, tests, costs and error handling.

## Done means tested

For each skill, record:
- status: `planned`, `prototype`, `implemented`, or `tested`
- required environment variables (names only; never values)
- permissions and confirmation requirements
- success and failure cases
- unit/integration test result
- whether user data leaves the PC and which provider receives it

Do not label a planned or prototype feature as complete.
