# MJ AI — secure API setup

## Connect OpenAI to the chat backend

The `chatWithStonic` server function now uses OpenAI when a server-side `OPENAI_API_KEY` is configured. If web search is enabled, the existing Base44 live-context path is tried first so MJ AI does not lose its current search behavior; OpenAI is the fallback if that path fails. If web search is disabled, OpenAI is used first.

1. Create an API key in your OpenAI developer account. Never paste it into chat, source code, a screenshot, or a `VITE_*` variable.
2. In your Base44 project, open the server/function secrets or environment variables settings and add `OPENAI_API_KEY` with the key as its value.
3. Save the secret and redeploy/publish the app so the server function can read it.
4. Test the Character chat with a simple message. If the key is missing or invalid, the function tries the existing Base44 provider path where possible.

The configured model is `gpt-4.1-mini`. API usage may incur charges and is separate from a ChatGPT subscription.

## Optional provider slots

`.env.example` lists 15 optional provider names for future integrations. These are placeholders only, not active integrations or real API keys. Add each provider only after implementing and testing its server-side integration. Never put private API keys in frontend code or commit real keys to Git.

## Current limitations

- OpenAI is integrated into the `chatWithStonic` backend only. It does not automatically activate the other 14 providers.
- Live web research still depends on the existing Base44 internet-context integration; the OpenAI fallback is instructed not to pretend it searched.
- Browser voice, PC control, and mobile remote pairing require their own supported APIs/companion implementation; an API key alone does not enable them.
