# MJ AI Hologram + Trust Upgrade (Hindi)

## Naye UI features
- Character dashboard par screen-based hologram projection overlay: scanlines, perspective grid, orbital rings aur sweep animation.
- Hologram ON/OFF toggle aur Full / Soft / Minimal projection styles.
- Voice/processing state aur Trust Mode setting ka visual indicator.
- Mobile screens ke liye compact controls; reduced-motion preference ka samman.

## Smart, honest aur dependable behavior
- Dependability ka focus: uncertainty accept kare, permissions respect kare aur sensitive actions se pehle confirmation le.
- Status indicators UI settings dikhate hain; ye apne aap backend security ya real hologram hardware nahi banate.
- Hologram yahan screen-based visual effect hai, physical 3D hologram projector nahi.

## Test
```bash
npm ci
npm run test:chat-safety
npm run build
```
Agar dependency install na ho, terminal ka exact error share karein.
