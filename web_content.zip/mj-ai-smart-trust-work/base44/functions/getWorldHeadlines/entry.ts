import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';

const clip = (value, max) => (typeof value === 'string' ? value.trim().slice(0, max) : '');

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const prompt = `Search the web for the most important global news of the last 24 hours. Pick 8 stories that matter across security/conflict, markets, climate, technology and diplomacy. For each story give a neutral, factual headline (max 90 characters), the publishing source name, one category from the fixed list, the main region or country, and a one-sentence summary (max 160 characters). Do not invent stories, sources or numbers; if you are unsure about a source, use the outlet you actually saw. Return only JSON.`;

    const schema = {
      type: 'object',
      properties: {
        headlines: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              title: { type: 'string' },
              source: { type: 'string' },
              category: { type: 'string', enum: ['conflict', 'markets', 'climate', 'tech', 'diplomacy'] },
              region: { type: 'string' },
              summary: { type: 'string' },
            },
            required: ['title', 'source', 'category', 'summary'],
          },
        },
      },
      required: ['headlines'],
    };

    const result = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt,
      add_context_from_internet: true,
      model: 'gemini_3_flash',
      response_json_schema: schema,
    });

    const allowed = ['conflict', 'markets', 'climate', 'tech', 'diplomacy'];
    const headlines = Array.isArray(result && result.headlines)
      ? result.headlines
          .slice(0, 8)
          .filter((item) => item && typeof item.title === 'string' && item.title.trim())
          .map((item) => ({
            title: clip(item.title, 140),
            source: clip(item.source, 60) || 'Web search',
            category: allowed.includes(item.category) ? item.category : 'diplomacy',
            region: clip(item.region, 60),
            summary: clip(item.summary, 220),
          }))
      : [];

    return Response.json({ headlines, fetched_at: new Date().toISOString() });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}