import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';

const STYLES = {
  cinematic: 'cinematic lighting, dramatic depth of field, film still',
  neon: 'neon-cyan and violet rim light, dark futuristic scene, volumetric glow',
  schematic: 'technical blueprint style, fine cyan linework on deep navy, engineering schematic',
  portrait: 'clean studio portrait lighting, shallow depth of field, editorial quality',
};

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const rawPrompt = typeof body.prompt === 'string' ? body.prompt.trim() : '';
    if (!rawPrompt) return Response.json({ error: 'prompt is required' }, { status: 400 });
    const prompt = rawPrompt.slice(0, 600);
    const style = Object.keys(STYLES).includes(body.style) ? body.style : 'cinematic';

    const result = await base44.asServiceRole.integrations.Core.GenerateImage({
      prompt: `${prompt}. Style direction: ${STYLES[style]}. High detail, no text or watermarks.`,
    });

    const url = result && result.url;
    if (!url) return Response.json({ error: 'Image generation returned nothing' }, { status: 502 });

    return Response.json({ url, style, prompt });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}