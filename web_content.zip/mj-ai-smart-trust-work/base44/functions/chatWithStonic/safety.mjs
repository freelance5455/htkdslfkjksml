export const clip = (value, max) => (typeof value === 'string' ? value.trim().slice(0, max) : '');

const SENSITIVE_PATTERNS = [
  /\bsk-(?:proj-)?[A-Za-z0-9_-]{16,}\b/i,
  /\b(?:api[_ -]?key|access[_ -]?token|refresh[_ -]?token|password|passcode|secret key|private key)\b/i,
  /\b(?:otp|one[- ]time (?:code|password)|verification code|recovery code)\b/i,
  /\b(?:cvv|cvc|credit card number|debit card number|bank account number|routing number)\b/i,
  /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/i,
  /\b\d{12,19}\b/,
];

export function containsSensitiveData(value) {
  const text = clip(value, 5000);
  return SENSITIVE_PATTERNS.some((pattern) => pattern.test(text));
}

export function sanitizeMemories(value, limit = 3) {
  if (!Array.isArray(value)) return [];
  return value
    .slice(0, limit)
    .filter((memory) => memory && typeof memory.content === 'string')
    .map((memory) => ({
      content: clip(memory.content, 240),
      kind: ['fact', 'preference', 'event'].includes(memory.kind) ? memory.kind : 'fact',
    }))
    .filter((memory) => memory.content && !containsSensitiveData(memory.content));
}

export function sanitizeHistory(value) {
  if (!Array.isArray(value)) return [];
  return value.slice(-16).flatMap((turn) => {
    if (!turn || !['user', 'assistant'].includes(turn.role)) return [];
    const content = clip(turn.content, 700);
    return content ? [{ role: turn.role, content }] : [];
  });
}
