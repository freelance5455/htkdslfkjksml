# MJ AI — Phone + PC सेटअप (हिंदी)

## इस पैकेज में क्या है
- React/Vite वेब ऐप, जिसमें desktop और mobile responsive layout है।
- PWA manifest, MJ AI icon, browser-supported install prompt और सीमित offline app-shell cache।
- Offline mode में login, AI chat, cloud memory, web research और remote-control को काम करने वाला न समझें; इनके लिए network/backend जरूरी है।
- Windows companion prototype केवल allowlisted apps (Notepad, Calculator, Paint, File Explorer) खोलता है और localhost पर bind होता है।

## PC पर चलाएँ
1. Node.js LTS इंस्टॉल करें।
2. इस project folder में terminal खोलें।
3. `npm ci` चलाएँ।
4. `.env.example` पढ़ें और Base44 app link/configuration अपने account के अनुसार पूरा करें। कोई secret `VITE_` variable या frontend code में न डालें।
5. `npm run dev` चलाएँ और terminal में दिखा local URL खोलें।
6. Release build के लिए `npm run build` और lint के लिए `npm run lint` चलाएँ।

## Android फोन पर इस्तेमाल
1. PC और फोन को एक ही Wi-Fi पर रखें।
2. LAN पर dev server चलाने के लिए `npm run dev -- --host 0.0.0.0` चलाएँ।
3. terminal में दिखने वाला Network URL फोन के Chrome में खोलें। Development URL आम तौर पर HTTPS नहीं होता, इसलिए PWA install और कुछ browser APIs उपलब्ध न भी हों।
4. असली PWA install के लिए app को HTTPS hosting पर publish करें; फिर Chrome menu में **Install app** या **Add to Home screen** चुनें। iPhone पर Safari के Share menu से **Add to Home Screen** चुनें।

## API और लॉगिन
- इस app में Base44 SDK, authentication और server functions मौजूद हैं। सही Base44 project/environment के बिना login और cloud features काम नहीं करेंगे।
- Provider API keys केवल server-side secret manager में रखें। `VITE_*` variables public browser bundle में दिख सकती हैं।
- `API_KEYS_SETUP.md` में दिए 15 providers के नाम configuration examples हैं; वे सक्रिय integrations या मुफ्त API keys नहीं हैं। हर provider के लिए अलग code, account, billing/limits और testing चाहिए।

## मोबाइल से PC control
- QR/code screen अभी pairing UI है, complete authenticated remote control नहीं।
- Windows companion prototype को केवल localhost पर रखें। Router port-forwarding या public exposure न करें। Remote access के लिए authenticated TLS relay, expiring pairing tokens, device revocation, rate limiting और action confirmations implement/test करना जरूरी है।
- अभी केवल allowlisted local app-launch actions prototype में हैं। Arbitrary shell commands या unrestricted file access न जोड़ें।

## ईमानदार readiness status
- [x] Responsive web UI और PWA manifest/icon
- [x] Browser install prompt (supported browsers only)
- [x] Basic offline app shell (sensitive API/auth responses cache नहीं होते)
- [x] Local Windows companion allowlist prototype
- [ ] Base44 project credentials/link और hosted deployment
- [ ] Live provider API integrations (user-owned keys required)
- [ ] Full mobile-to-PC authenticated remote bridge
- [ ] Native Android APK / signed release build
- [ ] Successful production build and device testing in your own environment
