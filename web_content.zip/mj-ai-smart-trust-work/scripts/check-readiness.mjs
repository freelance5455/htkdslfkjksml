import { existsSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';

const root = process.cwd();
const checks = [
  ['package.json', existsSync(resolve(root, 'package.json'))],
  ['PWA manifest', existsSync(resolve(root, 'public/manifest.json'))],
  ['service worker', existsSync(resolve(root, 'public/sw.js'))],
  ['MJ AI icon', existsSync(resolve(root, 'public/icons/mj-ai.svg'))],
  ['Base44 chat function', existsSync(resolve(root, 'base44/functions/chatWithStonic/entry.ts'))],
  ['Windows companion prototype', existsSync(resolve(root, 'windows-companion/mj_companion.py'))],
  ['Environment template', existsSync(resolve(root, '.env.example'))],
];
let manifestOk = false;
try {
  const manifest = JSON.parse(readFileSync(resolve(root, 'public/manifest.json'), 'utf8'));
  manifestOk = Boolean(manifest.name && manifest.start_url && manifest.display && Array.isArray(manifest.icons) && manifest.icons.length);
} catch {}
checks.push(['Manifest JSON valid', manifestOk]);

console.log('\nMJ AI readiness check (local structure only)\n');
for (const [name, ok] of checks) console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}`);
const depsPresent = existsSync(resolve(root, 'node_modules/vite/bin/vite.js'));
console.log(`${depsPresent ? 'PASS' : 'BLOCKED'}  Vite dependency installed`);
console.log('\nImportant: this check does not verify cloud credentials, live API calls, hosted HTTPS, mobile-to-PC pairing, or a signed Android APK.');
if (checks.some(([, ok]) => !ok)) process.exitCode = 1;
