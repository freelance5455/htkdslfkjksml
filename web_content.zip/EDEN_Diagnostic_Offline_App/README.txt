EDEN Diagnostic Centre - Offline Android App (Starter)

Features:
- Patient entry and editable report test rows
- Local saved patient reports and searchable history
- Booking / appointment register: booking ID, date, time, patient, phone, age, sex,
  requested tests, referring doctor, status, advance, estimated total and notes
- Print / Save as PDF report
- Test catalog editing
- JSON backup and restore (includes bookings)

Use:
1. Extract the ZIP on your Android phone.
2. Open index.html with Chrome or another modern browser.
3. Data is stored in the browser's local storage on the phone.
4. Use Backup tab regularly to download a backup file.
5. For report print/PDF, tap Print / PDF and choose Save as PDF.

Important:
- This is an offline starter web app, not a signed APK yet.
- Enter and verify the lab's own test names, units, reference ranges and prices.
- Do not clear browser storage without exporting a backup.
- Patient data is stored locally; protect the phone and backup files.
