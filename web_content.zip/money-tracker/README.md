# Money Tracker

Pencatat keuangan & tabungan, offline-first, bahasa Indonesia.
Fondasi ini adalah port dari skrip CLI Python (`legacy/money_tracker_cli.py`) menjadi web app mobile
yang siap dibungkus menjadi APK dengan Capacitor.

## Struktur
```
www/index.html      markup (shell, bottom nav, bottom sheet)
www/css/style.css   desain (token warna di :root, dark mode otomatis)
www/js/app.js       seluruh logika & render (vanilla JS, tanpa build step)
docs/               skema data, roadmap
legacy/             skrip Python asli (referensi logika)
AGENTS.md           aturan & tugas untuk AI agent
```

## Jalankan
```
npm install
npm run serve        # buka www/ di browser (mode HP: DevTools > device toolbar)
```
Atau buka `www/index.html` langsung di browser.

## Build APK
```
npm install
npm run cap:add      # sekali saja, membuat folder android/
npm run cap:sync     # setiap kali www/ berubah
npm run cap:open     # buka Android Studio, lalu Build > Build APK
```
Butuh Node 18+, Android Studio, JDK 17.

## Foundation 2.0 (rancangan beta)

Lihat `docs/FOUNDATION_2.md` dan `docs/SECURITY_BACKEND.md` untuk arsitektur offline-sync, kontrol keamanan, API minimal, dan kriteria go/no-go. Skema PostgreSQL awal berada di `backend/schema.sql`. Ini adalah rancangan, bukan backend yang sudah berjalan.
