@echo off
setlocal
cd /d "%~dp0"
echo === Money Tracker: build APK ===
where node >nul 2>nul || (echo Node.js belum terpasang. & pause & exit /b 1)
where npm >nul 2>nul || (echo npm tidak ditemukan. & pause & exit /b 1)
call npm install || (echo Gagal memasang dependensi. & pause & exit /b 1)
if not exist android call npx cap add android
call npx cap sync android || (echo Gagal sinkronisasi Capacitor. & pause & exit /b 1)
if not exist android\gradlew.bat (echo Gradle wrapper tidak ditemukan. Buka folder ini di Android Studio lalu sync project. & pause & exit /b 1)
call android\gradlew.bat -p android assembleDebug || (echo Build gagal. Periksa Android SDK/JDK di Android Studio. & pause & exit /b 1)
echo.
echo APK: android\app\build\outputs\apk\debug\app-debug.apk
pause
