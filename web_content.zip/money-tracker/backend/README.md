# Backend starter specification

This folder contains the initial PostgreSQL schema for the proposed beta backend.
It is a design artifact, not a running server. No server credentials, production
configuration, or deployed service are included.

Recommended implementation order:
1. Create a TypeScript Fastify service with strict request/response schemas.
2. Add migrations for `schema.sql`; create a least-privilege runtime DB role.
3. Implement auth, refresh rotation, logout, and rate limits.
4. Implement transaction CRUD with owner scoping, idempotency, and optimistic versioning.
5. Add integration tests for cross-account access, invalid input, retries, and revocation.
6. Deploy only behind HTTPS with managed secrets, encrypted backups, monitoring, and a restore drill.

Never ship `.env` values or server credentials inside the Android APK.
