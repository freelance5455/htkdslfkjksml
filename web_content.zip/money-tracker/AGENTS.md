# Panduan untuk AI Agent

Kamu melanjutkan pengembangan **Money Tracker**. Baca `README.md` dan `docs/DATA_SCHEMA.md` dulu.

## Aturan
- Stack: HTML + CSS + vanilla JS di `www/`. Jangan tambah framework/bundler kecuali diminta.
- Bahasa UI: Indonesia, kalimat sentence case, tombol berupa kata kerja ("Simpan", "Hapus").
- Mobile-first (lebar ~380px), respect safe-area, dukung dark mode lewat variabel CSS di `:root`.
- Semua warna lewat variabel CSS. Jangan hardcode warna di komponen baru.
- Data: jangan ubah format di `docs/DATA_SCHEMA.md` tanpa migrasi. Data lama harus tetap terbaca.
- Selalu escape teks pengguna (`esc()`) sebelum dimasukkan ke innerHTML.
- Bungkus akses storage dengan try/catch. Aplikasi harus jalan jika storage kosong.
- Uang = integer rupiah. Jangan pakai float.
- Aplikasi harus tetap berfungsi offline.

## Arsitektur saat ini (www/js/app.js)
- State global: `data`, `tab`, `filter`, `jenis`
- `muat()` / `simpan()`: persistensi
- `hitung()`: total & saldo
- `render()`: menggambar tab aktif (home, hist, goal)
- `tambah()`: validasi & simpan transaksi
- Satu listener `click` terdelegasi di `document`

Jika file membesar, pecah `app.js` jadi modul (`storage.js`, `state.js`, `views/`) dengan ES modules.

## Cara bekerja
1. Pilih tugas teratas yang belum selesai dari `docs/ROADMAP.md`.
2. Implementasikan dengan perubahan sekecil mungkin.
3. Uji manual: tambah/hapus transaksi, saldo tidak cukup, ubah target, impor/ekspor, muat ulang halaman.
4. Perbarui `ROADMAP.md` (centang) dan `DATA_SCHEMA.md` bila skema berubah.

## Definition of done
- Tidak ada error di console
- Berfungsi di layar 360px dan mode gelap
- Data lama tetap terbaca
- Dokumen diperbarui
