# Money Tracker — Foundation 2.0

Status: rancangan teknis untuk beta; belum merupakan backend produksi.

## Tujuan
Mempertahankan aplikasi offline-first yang sudah ada, sambil menambahkan jalur aman menuju akun pengguna dan sinkronisasi cloud. Data lama dengan key `keuangan` tetap menjadi sumber migrasi; jangan menghapus atau mengubahnya sebelum migrasi berhasil diverifikasi.

## Arsitektur target

```text
Android APK (Capacitor)
  ├─ UI vanilla JS
  ├─ Local repository (offline cache)
  ├─ Secure token vault (native Android Keystore melalui plugin yang diaudit)
  └─ Sync queue (idempotent outbox)
          │ HTTPS only
          ▼
API Gateway / Fastify API
  ├─ Authentication + session management
  ├─ Authorization (user owns every record)
  ├─ Input validation + rate limiting
  ├─ Audit events (metadata only)
  └─ Service layer
          │
          ▼
PostgreSQL
  ├─ users
  ├─ devices / refresh_sessions
  ├─ transactions
  └─ sync metadata
```

## Prinsip desain
1. Offline-first: pencatatan transaksi tetap dapat dilakukan tanpa jaringan.
2. Server-authoritative identity: setiap data cloud terikat ke `user_id` dari token yang tervalidasi, bukan dari body request.
3. Least privilege: token akses singkat; refresh token dapat dicabut per perangkat.
4. Data minimization: jangan kirim kontak, lokasi, atau data perangkat yang tidak diperlukan.
5. Backward compatibility: impor data versi lama harus melalui validasi dan migrasi eksplisit.
6. No secrets in APK: jangan pernah menaruh API secret, database credential, signing secret, atau private key di `www/` maupun file APK.

## Strategi beta
- Beta tertutup, akun undangan, dan pembatasan pendaftaran.
- Mulai dengan satu region server dan PostgreSQL managed.
- Aktifkan backup terenkripsi harian dan uji restore sebelum menerima data nyata.
- Sediakan ekspor data dan penghapusan akun/data.
- Beri label jelas bahwa beta belum menyediakan jaminan layanan finansial/bank-grade.
- Jangan menghubungkan rekening bank atau memproses pembayaran pada tahap ini.

## Migrasi data lama
1. Baca `localStorage["keuangan"]` dalam mode read-only.
2. Validasi root object, `target`, dan setiap transaksi.
3. Tampilkan pratinjau jumlah transaksi dan total nominal.
4. Setelah pengguna masuk, unggah batch dengan idempotency key.
5. Verifikasi jumlah record dan checksum hasil.
6. Tandai migrasi selesai hanya setelah server mengonfirmasi.
7. Jangan hapus data lokal otomatis; pengguna dapat memilih menyimpan salinan lokal.

## Sinkronisasi
- Setiap transaksi memiliki UUID stabil `client_id`; jangan mengandalkan integer `id` lokal sebagai ID global.
- Operasi create memakai `Idempotency-Key`.
- Server mengembalikan `server_id`, `version`, dan `updated_at`.
- Penghapusan disinkronkan sebagai tombstone agar transaksi tidak muncul kembali.
- Konflik edit memakai optimistic concurrency (`version` / `If-Match`); jangan menerapkan last-write-wins diam-diam untuk nominal.
- Nominal rupiah disimpan sebagai integer `BIGINT`, bukan float.

## Keputusan yang belum boleh dianggap selesai
- Pemilihan penyedia hosting dan wilayah data.
- Kebijakan retensi log dan backup.
- Legal review, privacy notice, dan syarat beta.
- Audit keamanan independen sebelum rilis publik.
