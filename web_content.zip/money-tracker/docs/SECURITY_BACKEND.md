# Rancangan keamanan backend — Money Tracker Beta

## 1. Ruang lingkup dan asumsi
Aplikasi saat ini adalah aplikasi lokal tanpa server. Dokumen ini menetapkan rancangan backend baru; tidak menyatakan bahwa backend sudah tersedia atau bahwa data lokal saat ini terenkripsi.

Data transaksi keuangan bersifat sensitif. Beta sebaiknya menggunakan data uji terlebih dahulu dan tidak meminta kredensial rekening bank.

## 2. Stack yang disarankan
- Runtime: Node.js LTS + TypeScript.
- HTTP: Fastify.
- Validasi: Zod atau JSON Schema yang ketat.
- Database: PostgreSQL.
- Password: Argon2id dengan parameter yang dituning pada server.
- Token: access token berumur 5–10 menit; refresh token acak, rotasi setiap pemakaian, disimpan sebagai hash di database.
- Infrastruktur: HTTPS/TLS, secrets manager, WAF/rate limiting, managed database, backup terenkripsi.

Stack ini rekomendasi, bukan dependency yang sudah dipasang pada APK.

## 3. Kontrol wajib

### Identitas dan sesi
- Verifikasi email atau mekanisme undangan beta sebelum akun aktif.
- Password tidak pernah disimpan plaintext; gunakan Argon2id.
- Pesan login generik agar tidak membocorkan apakah email terdaftar.
- Rate limit login, registrasi, reset password, dan refresh.
- Refresh token terikat ke sesi/perangkat, dirotasi, dan dapat dicabut.
- Logout mencabut refresh session di server.
- Jangan menyimpan refresh token di localStorage/WebView. Gunakan Android Keystore melalui plugin secure-storage yang ditinjau; jika belum tersedia, nonaktifkan login cloud pada build tersebut.

### Otorisasi dan API
- Semua query transaksi wajib dibatasi `user_id` dari principal terautentikasi.
- Abaikan `user_id` dari request body; jangan percaya ID pemilik yang dikirim klien.
- Validasi tipe, panjang, enum, batas nominal, dan ukuran payload.
- Gunakan prepared statements/ORM parameterized; tidak membangun SQL dari input.
- CORS allowlist untuk domain web yang memang dipakai; jangan menganggap CORS sebagai autentikasi.
- API hanya melalui HTTPS; tolak HTTP di production.
- Tambahkan idempotency untuk create/import agar retry jaringan tidak menggandakan transaksi.
- Pagination dengan batas maksimum; jangan mengembalikan semua transaksi tanpa batas.

### Data dan privasi
- TLS saat transit; enkripsi disk/database dan backup saat tersimpan.
- Pertimbangkan enkripsi field sensitif pada level aplikasi bila threat model membutuhkannya; kelola key di KMS, bukan di database atau APK.
- Jangan mencatat password, token, isi transaksi, nominal, atau payload impor ke log.
- Audit log hanya metadata: actor, aksi, waktu, request ID, hasil.
- Batasi akses staf ke data produksi dan catat akses administratif.
- Sediakan ekspor dan penghapusan akun/data sesuai kebijakan privasi yang telah ditinjau.

### Keamanan Android
- Aktifkan Android backup rules yang mengecualikan token dan database sensitif.
- Jangan aktifkan cleartext traffic.
- Gunakan secure storage berbasis Android Keystore untuk token.
- PIN/biometrik lokal adalah pengunci UI, bukan pengganti autentikasi server.
- Jangan menganggap obfuscation APK sebagai perlindungan secret.
- Terapkan Content Security Policy yang sesuai; hindari inline script/eval dan sumber pihak ketiga yang tidak diperlukan.
- Hapus font Google eksternal atau bundel font secara lokal agar UI dapat bekerja offline dan mengurangi koneksi pihak ketiga.

## 4. API minimal (v1)
Semua endpoint di bawah selain health memerlukan autentikasi sesuai kebijakan.

| Method | Endpoint | Keterangan |
|---|---|---|
| GET | `/v1/health` | Liveness sederhana, tanpa detail infrastruktur |
| POST | `/v1/auth/register` | Registrasi beta/undangan |
| POST | `/v1/auth/login` | Login dan penerbitan sesi |
| POST | `/v1/auth/refresh` | Rotasi refresh token |
| POST | `/v1/auth/logout` | Cabut sesi saat ini |
| GET | `/v1/me` | Profil minimal |
| GET | `/v1/transactions?cursor=&limit=` | Daftar transaksi milik pengguna |
| POST | `/v1/transactions` | Buat transaksi, wajib idempotency key |
| PATCH | `/v1/transactions/{id}` | Edit dengan version/If-Match |
| DELETE | `/v1/transactions/{id}` | Soft delete/tombstone |
| PUT | `/v1/settings/goal` | Perbarui target tabungan |

### Bentuk transaksi API
```json
{
  "client_id": "UUID",
  "tanggal": "2026-11-15T02:30:00.000Z",
  "jenis": "pemasukan",
  "jumlah": 100000,
  "keterangan": "Gaji"
}
```
Server menambahkan `id`, `version`, `created_at`, `updated_at`, dan `deleted_at`. Waktu API memakai ISO-8601 UTC; UI dapat menampilkan waktu lokal. `jumlah` harus integer rupiah positif dan berada dalam batas bisnis yang ditetapkan.

## 5. Skema database awal
Lihat `backend/schema.sql`. Terapkan migration tool dan role database terpisah (runtime tidak boleh menjadi superuser). Tambahkan index dan constraint sesuai beban beta.

## 6. Ancaman utama dan mitigasi
| Ancaman | Mitigasi |
|---|---|
| APK dibongkar untuk mencari secret | Tidak ada secret server di APK |
| Pencurian token | Keystore, token singkat, refresh rotation, revocation |
| IDOR / akses transaksi pengguna lain | Filter owner pada setiap query + tes lintas akun |
| SQL injection | Parameterized queries + validasi |
| Brute force login | Rate limit, lockout bertahap, monitoring |
| Replay/retry menggandakan transaksi | Idempotency key unik per pengguna |
| Import JSON berbahaya | Batas ukuran, schema validation, batas jumlah dan nominal |
| Kebocoran log | Redaksi token dan payload; audit metadata saja |
| Kehilangan data | Backup terenkripsi, restore drill, ekspor pengguna |
| Perangkat hilang | Cabut sesi per perangkat; biometrik/lock lokal |

## 7. Kriteria go/no-go beta
- [ ] HTTPS enforced dan tidak ada cleartext traffic.
- [ ] Tidak ada secret di source/APK/repository.
- [ ] Password Argon2id; refresh token di-hash, dirotasi, dan dapat dicabut.
- [ ] Uji IDOR: akun A tidak dapat membaca/mengubah/menghapus data akun B.
- [ ] Uji SQL injection, payload invalid, oversized body, dan rate limit.
- [ ] Import JSON divalidasi sebelum data ditulis.
- [ ] Backup dan pemulihan berhasil diuji.
- [ ] Log tidak memuat token atau data transaksi.
- [ ] Privacy notice, consent beta, ekspor, dan penghapusan data tersedia.
- [ ] Pengujian keamanan perangkat dan API dilakukan sebelum beta publik.

## 8. Batasan
Rancangan ini bukan sertifikasi keamanan atau pengganti penetration test, legal review, dan tinjauan konfigurasi hosting. Jangan menyebut aplikasi "aman sepenuhnya" hanya karena kontrol di atas telah direncanakan.
