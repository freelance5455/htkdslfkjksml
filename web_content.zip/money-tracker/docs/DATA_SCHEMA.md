# Skema data

Disimpan di `localStorage` key `keuangan` sebagai JSON. Format identik dengan `keuangan.json`
milik skrip Python lama (kompatibel untuk impor/ekspor). JANGAN ubah tanpa migrasi.

```json
{
  "target": 5000000,
  "transaksi": [
    {
      "id": 1,
      "tanggal": "2026-11-15 09:30",
      "jenis": "pemasukan",
      "jumlah": 100000,
      "keterangan": "Gaji"
    }
  ]
}
```

- `jenis`: `pemasukan` | `pengeluaran` | `tabungan`
- `jumlah`: integer rupiah > 0 (tanpa desimal)
- `id`: integer unik, naik terus (max id + 1)
- `tanggal`: `YYYY-MM-DD HH:mm` waktu lokal

## Aturan bisnis
- saldo = pemasukan − pengeluaran − tabungan
- pengeluaran & tabungan ditolak jika `jumlah > saldo`
- progres target = min(total tabungan / target, 100%)

## Jika skema berubah
Tambahkan field `"versi": 2` dan fungsi migrasi di `muat()` yang mengubah data lama tanpa kehilangan transaksi.
