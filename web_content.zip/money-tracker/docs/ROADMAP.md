# Roadmap

Urutan prioritas. Kerjakan satu per satu, commit per tugas.

- [ ] 1. Kategori pengeluaran (makan, transport, dll) + field `kategori` (opsional, migrasi aman)
- [ ] 2. Edit transaksi (bukan hanya hapus) + undo setelah hapus
- [ ] 3. Ringkasan per bulan + grafik (SVG inline, tanpa library berat)
- [ ] 4. Beberapa target tabungan (nama + nominal + tenggat)
- [ ] 5. PIN / biometrik kunci aplikasi
- [ ] 6. Font offline (unduh Plus Jakarta Sans ke `www/fonts/`, hapus link Google Fonts)
- [ ] 7. Pindah penyimpanan ke `@capacitor/preferences` atau SQLite agar data tidak hilang saat cache dibersihkan
- [ ] 8. Ekspor CSV, pengingat menabung (local notification)
- [ ] 9. Ikon & splash screen (`@capacitor/assets`)
