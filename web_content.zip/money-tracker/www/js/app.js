const KEY="keuangan";
const J={pemasukan:{l:"Pemasukan",c:"--in",s:"+"},pengeluaran:{l:"Pengeluaran",c:"--out",s:"−"},tabungan:{l:"Tabungan",c:"--sv",s:"→"}};
let data={target:0,transaksi:[]},tab="home",filter=null,jenis="pemasukan";
const $=s=>document.querySelector(s);
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));

function muat(){try{const r=localStorage.getItem(KEY);if(r){const d=JSON.parse(r);if(d&&Array.isArray(d.transaksi))data=d}}catch(e){}}
function simpan(){try{localStorage.setItem(KEY,JSON.stringify(data))}catch(e){}}
const rp=n=>"Rp"+Math.round(n).toLocaleString("id-ID");
function hitung(){const s=j=>data.transaksi.filter(t=>t.jenis===j).reduce((a,t)=>a+t.jumlah,0);
  const masuk=s("pemasukan"),keluar=s("pengeluaran"),tabung=s("tabungan");return{masuk,keluar,tabung,saldo:masuk-keluar-tabung}}
const angka=v=>{const t=String(v).replace(/[.,\s]/g,"");return/^\d+$/.test(t)&&+t>0?+t:null};

function ringSvg(p){const r=40,c=2*Math.PI*r;
  return `<svg viewBox="0 0 100 100" width="92" height="92"><circle cx="50" cy="50" r="${r}" fill="none" stroke="var(--line)" stroke-width="10"/><circle cx="50" cy="50" r="${r}" fill="none" stroke="var(--sv)" stroke-width="10" stroke-linecap="round" stroke-dasharray="${c*p/100} ${c}" transform="rotate(-90 50 50)"/></svg>`}

function rowHtml(t){const j=J[t.jenis];
  return `<div class="row"><span class="dot" style="background:var(${j.c})"></span><div class="t"><div>${esc(t.keterangan)}</div><div class="sub">${esc(t.tanggal)} · ${j.l}</div></div><span class="amt" style="color:var(${j.c})">${j.s}${rp(t.jumlah)}</span><button class="del" data-del="${t.id}" aria-label="Hapus">Hapus</button></div>`}

function render(){
  document.querySelectorAll("nav [data-tab]").forEach(b=>b.setAttribute("aria-current",b.dataset.tab===tab));
  const h=hitung(),m=$("#main");
  const rev=[...data.transaksi].reverse();
  if(tab==="home"){
    const p=data.target>0?Math.min(h.tabung/data.target*100,100):0;
    m.innerHTML=`<div class="hero"><div><h1>Saldo dipegang</h1><div class="big">${rp(h.saldo)}</div>
      <div class="sub">${data.target>0?(h.tabung>=data.target?"Target tercapai 🎉":"Kurang "+rp(data.target-h.tabung)+" ke target"):"Belum ada target tabungan"}</div></div>
      <div class="ring">${ringSvg(p)}<b>${Math.round(p)}%</b></div></div>
      <div class="stats"><div><span>Masuk</span><strong style="color:var(--in)">${rp(h.masuk)}</strong></div><div><span>Keluar</span><strong style="color:var(--out)">${rp(h.keluar)}</strong></div><div><span>Ditabung</span><strong style="color:var(--sv)">${rp(h.tabung)}</strong></div></div>
      <h2>Terbaru</h2>${rev.length?rev.slice(0,5).map(rowHtml).join(""):'<div class="empty">Belum ada transaksi. Tekan + untuk mencatat.</div>'}`;
  }else if(tab==="hist"){
    const l=rev.filter(t=>!filter||t.jenis===filter);
    m.innerHTML=`<h2>Riwayat</h2><div class="chips">${[[null,"Semua"],...Object.entries(J).map(([k,v])=>[k,v.l])].map(([k,l])=>`<button class="chip" data-f="${k}" aria-pressed="${filter===k}">${l}</button>`).join("")}</div>
      ${l.length?l.map(rowHtml).join(""):'<div class="empty">Belum ada data.</div>'}
      <div class="tools"><button class="chip" id="exp">Ekspor JSON</button><button class="chip" id="imp">Impor JSON</button></div>`;
  }else{
    m.innerHTML=`<h2>Target tabungan</h2><p class="sub">Ditabung sejauh ini: ${rp(h.tabung)}${data.target?" dari "+rp(data.target):""}</p>
      <input id="tg" inputmode="numeric" placeholder="Target (Rp)" value="${data.target||""}"><p class="err" id="terr"></p><button class="go" id="stg">Simpan target</button>`;
  }
}

function buka(){jenis="pemasukan";segRender();$("#jml").value="";$("#ket").value="";$("#err").textContent="";$("#sheet").classList.add("on");setTimeout(()=>$("#jml").focus(),50)}
function segRender(){$("#seg").innerHTML=Object.entries(J).map(([k,v])=>`<button data-j="${k}" aria-pressed="${k===jenis}" style="${k===jenis?`background:var(${v.c})`:""}">${v.l}</button>`).join("")}

function tambah(){
  const n=angka($("#jml").value);if(!n){$("#err").textContent="Masukkan angka yang valid (lebih dari 0).";return}
  const {saldo}=hitung();
  if(jenis!=="pemasukan"&&n>saldo){$("#err").textContent="Saldo tidak cukup. Saldo kamu: "+rp(saldo);return}
  const d=new Date(),p=x=>String(x).padStart(2,"0");
  data.transaksi.push({id:Math.max(0,...data.transaksi.map(t=>t.id))+1,tanggal:`${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`,jenis,jumlah:n,keterangan:$("#ket").value.trim()||"-"});
  simpan();$("#sheet").classList.remove("on");render();
}

document.addEventListener("click",e=>{
  const t=e.target;
  if(t.dataset.tab){tab=t.dataset.tab;render()}
  else if(t.id==="fab")buka();
  else if(t.id==="sheet")t.classList.remove("on");
  else if(t.dataset.j){jenis=t.dataset.j;segRender()}
  else if(t.id==="simpan")tambah();
  else if(t.dataset.f!==undefined){filter=t.dataset.f==="null"?null:t.dataset.f;render()}
  else if(t.dataset.del){if(confirm("Hapus transaksi ini?")){data.transaksi=data.transaksi.filter(x=>x.id!==+t.dataset.del);simpan();render()}}
  else if(t.id==="stg"){const n=angka($("#tg").value);if(!n){$("#terr").textContent="Masukkan angka yang valid (lebih dari 0).";return}data.target=n;simpan();tab="home";render()}
  else if(t.id==="exp"){const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:"application/json"}));a.download="keuangan.json";a.click()}
  else if(t.id==="imp"){const i=document.createElement("input");i.type="file";i.accept=".json";i.onchange=()=>{const r=new FileReader();r.onload=()=>{try{const d=JSON.parse(r.result);if(!Array.isArray(d.transaksi))throw 0;data={target:+d.target||0,transaksi:d.transaksi};simpan();render()}catch(x){alert("File tidak valid.")}};r.readAsText(i.files[0])};i.click()}
});
muat();render();
