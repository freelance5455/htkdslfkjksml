#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
command -v node >/dev/null || { echo 'Node.js belum terpasang.'; exit 1; }
command -v npm >/dev/null || { echo 'npm tidak ditemukan.'; exit 1; }
npm install
if [ ! -d android ]; then npx cap add android; fi
npx cap sync android
cd android
./gradlew assembleDebug
echo "APK: app/build/outputs/apk/debug/app-debug.apk"
