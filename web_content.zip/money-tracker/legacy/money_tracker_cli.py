"""
MONEY TRACKER - Pencatat Keuangan & Tabungan
Semua data otomatis tersimpan di file keuangan.json
"""

import json
import os
from datetime import datetime

FILE_DATA = "keuangan.json"


# ---------- Penyimpanan data ----------
def muat_data():
    if os.path.exists(FILE_DATA):
        try:
            with open(FILE_DATA, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            print("File data rusak, memulai data baru.")
    return {"target": 0, "transaksi": []}


def simpan_data(data):
    with open(FILE_DATA, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


# ---------- Helper ----------
def rupiah(n):
    return "Rp{:,.0f}".format(n).replace(",", ".")


def input_angka(pesan):
    while True:
        teks = input(pesan).strip().replace(".", "").replace(",", "")
        if teks.isdigit() and int(teks) > 0:
            return int(teks)
        print("Masukkan angka yang valid (lebih dari 0).")


def hitung(data):
    masuk = sum(t["jumlah"] for t in data["transaksi"] if t["jenis"] == "pemasukan")
    keluar = sum(t["jumlah"] for t in data["transaksi"] if t["jenis"] == "pengeluaran")
    tabung = sum(t["jumlah"] for t in data["transaksi"] if t["jenis"] == "tabungan")
    saldo = masuk - keluar - tabung  # uang yang masih dipegang
    return masuk, keluar, tabung, saldo


# ---------- Fitur ----------
def tambah(data, jenis):
    judul = {"pemasukan": "PEMASUKAN", "pengeluaran": "PENGELUARAN", "tabungan": "MENABUNG"}
    print(f"\n--- {judul[jenis]} ---")
    jumlah = input_angka("Jumlah (Rp): ")
    ket = input("Keterangan: ").strip() or "-"

    _, _, _, saldo = hitung(data)
    if jenis in ("pengeluaran", "tabungan") and jumlah > saldo:
        print(f"Saldo tidak cukup! Saldo kamu: {rupiah(saldo)}")
        return

    data["transaksi"].append({
        "id": max([t["id"] for t in data["transaksi"]], default=0) + 1,
        "tanggal": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "jenis": jenis,
        "jumlah": jumlah,
        "keterangan": ket,
    })
    simpan_data(data)
    print("Tersimpan!")


def lihat_riwayat(data, filter_jenis=None):
    daftar = [t for t in data["transaksi"] if not filter_jenis or t["jenis"] == filter_jenis]
    if not daftar:
        print("\nBelum ada data.")
        return
    print(f"\n{'ID':<4}{'Tanggal':<18}{'Jenis':<13}{'Jumlah':<16}Keterangan")
    print("-" * 65)
    for t in daftar:
        print(f"{t['id']:<4}{t['tanggal']:<18}{t['jenis']:<13}{rupiah(t['jumlah']):<16}{t['keterangan']}")


def ringkasan(data):
    masuk, keluar, tabung, saldo = hitung(data)
    print("\n=========== RINGKASAN ===========")
    print(f"Total pemasukan   : {rupiah(masuk)}")
    print(f"Total pengeluaran : {rupiah(keluar)}")
    print(f"Total tabungan    : {rupiah(tabung)}")
    print(f"Saldo dipegang    : {rupiah(saldo)}")
    if data["target"] > 0:
        persen = min(tabung / data["target"] * 100, 100)
        bar = "#" * int(persen // 5) + "-" * (20 - int(persen // 5))
        print(f"\nTarget tabungan   : {rupiah(data['target'])}")
        print(f"Progres           : [{bar}] {persen:.1f}%")
        sisa = data["target"] - tabung
        print("Target tercapai! 🎉" if sisa <= 0 else f"Kurang           : {rupiah(sisa)}")
    print("=================================")


def atur_target(data):
    data["target"] = input_angka("\nTarget tabungan (Rp): ")
    simpan_data(data)
    print("Target disimpan!")


def hapus(data):
    lihat_riwayat(data)
    if not data["transaksi"]:
        return
    try:
        id_hapus = int(input("\nID yang dihapus (0 = batal): "))
    except ValueError:
        print("ID tidak valid.")
        return
    if id_hapus == 0:
        return
    baru = [t for t in data["transaksi"] if t["id"] != id_hapus]
    if len(baru) == len(data["transaksi"]):
        print("ID tidak ditemukan.")
        return
    data["transaksi"] = baru
    simpan_data(data)
    print("Data dihapus.")


# ---------- Menu utama ----------
def main():
    data = muat_data()
    while True:
        print("\n===== MONEY TRACKER =====")
        print("1. Catat pemasukan")
        print("2. Catat pengeluaran")
        print("3. Menabung")
        print("4. Lihat semua riwayat")
        print("5. Lihat riwayat tabungan")
        print("6. Ringkasan & progres target")
        print("7. Atur target tabungan")
        print("8. Hapus transaksi")
        print("0. Keluar")
        pilih = input("Pilih menu: ").strip()

        if pilih == "1":
            tambah(data, "pemasukan")
        elif pilih == "2":
            tambah(data, "pengeluaran")
        elif pilih == "3":
            tambah(data, "tabungan")
        elif pilih == "4":
            lihat_riwayat(data)
        elif pilih == "5":
            lihat_riwayat(data, "tabungan")
        elif pilih == "6":
            ringkasan(data)
        elif pilih == "7":
            atur_target(data)
        elif pilih == "8":
            hapus(data)
        elif pilih == "0":
            print("Sampai jumpa! Data sudah tersimpan.")
            break
        else:
            print("Menu tidak valid.")


if __name__ == "__main__":
    main()
