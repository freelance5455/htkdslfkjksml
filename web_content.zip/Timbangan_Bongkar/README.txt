TIMBANGAN BONGKAR — GAJAH MADA GROUP
Prototype aplikasi offline berbasis HTML untuk Android/browser.

Dashboard:
- Jumlah kapal bongkar hari ini dan tanggal.
- Rekap masing-masing kapal: jumlah keranjang dan total berat per kapal.
- Tidak menampilkan total berat gabungan semua kapal.

Cara pakai:
1. Ekstrak ZIP.
2. Buka index.html di browser HP/laptop.
3. Data tersimpan lokal pada browser/perangkat yang digunakan.

Catatan: Ini prototype web offline, belum APK Android native.
Untuk APK, perlu tahap packaging/build Android berikutnya.
