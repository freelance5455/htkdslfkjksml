# ANONYMOUX STUDIOS 2.6.2

## Theme system
- Added a final, centralized theme stylesheet so the dashboard, admin console, creative workspaces and realtime shell share the same design tokens.
- Standardized charcoal `#111318`, panel `#171A21`, white `#FFFFFF`, neon green `#A3FF12`, purple `#8B5CF6`, teal `#00D6C9` and blue `#3897FF`.
- Removed remaining legacy red/neon-green shade conflicts from the loaded application stylesheets.
- Preserved dark/light theme switching and corrected the light-theme page background.
- Bumped CSS cache keys to 2.6.2 so browsers fetch the corrected styles.

## Workspace pricing
- Added editable Admin → Models pricing for Image, Video Edit, Realtime, Lip Sync, Voice and AI Agent workspaces.
- Defaults: Image 10 credits/generation; Video 50/generation; Realtime 10/minute (display/planning only); Lip Sync 30/generation; Voice 1 credit/100 characters; private voice clone 100 credits; AI Agent 200 credits per USD of measured provider usage.
- Image/Video defaults are initialized in SQLite settings and continue using atomic server-side wallet reservations, settlement and refunds.
- Lip Sync, Voice and Agent defaults are aligned with their existing server-side billing paths.
- Realtime is explicitly labelled as not yet billed; no credits are deducted until trusted provider session metering and settlement are implemented.
- Added workspace price visibility to Image, Video/Lip Sync and Realtime interfaces.
- Existing wallet balances and historical transactions are unchanged.

## Validation
- PHP syntax check passed for every PHP file in the package.
- All available Python source/contract/regression checks passed.
- The voice idempotency migration runtime test could not run because this build environment does not have the PHP `pdo_sqlite` extension. The project remains configured for PDO SQLite on the target host.


## 2.6.4 pricing and workspace reliability patch
- Image generation default increased to 20 ANON credits per output, including a one-time upgrade of the previous stored default of 10 while preserving other Admin overrides.
- Realtime customer rate changed to 10 ANON credits per provider-billed active second. Settlement uses Decart's returned billed_seconds, with idempotent wallet ledger references and unpaid usage records for retry; no browser-timer estimates are charged.
- Voice cloning now charges before provider creation, refunds confirmed failures, and retains charges only for uncertain provider outcomes to avoid unpaid provider-side models.
- AI Agent session creation is protected against concurrent duplicate starts, provider session IDs are validated, and Agent credit conversion defaults to disabled until Admin configures it.
