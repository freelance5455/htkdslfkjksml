/* =========================================================
   AURELIA BEAUTÉ — Shop Page
   Category / price / rating filters, sorting, mobile filter sheet.
   ========================================================= */

(function () {
  "use strict";

  const grid = document.querySelector("[data-shop-grid]");
  const resultCount = document.querySelector("[data-result-count]");
  const catDesktopWrap = document.querySelector("[data-filter-categories]");
  const catMobileWrap = document.querySelector("[data-filter-categories-mobile]");
  const sortSelect = document.querySelector("[data-sort-select]");
  const params = new URLSearchParams(window.location.search);

  const state = {
    categories: params.get("category") ? [params.get("category")] : [],
    price: "all",
    rating: 0,
    badge: params.get("filter") || null,
    sort: "featured"
  };

  function buildCategoryCheckboxes(wrap, namePrefix) {
    if (!wrap) return;
    wrap.innerHTML = window.CATEGORIES
      .map(
        (c) =>
          '<label class="filter-option"><input type="checkbox" name="' +
          namePrefix +
          '" value="' +
          c +
          '"' +
          (state.categories.includes(c) ? " checked" : "") +
          "> " +
          c +
          "</label>"
      )
      .join("");
    wrap.querySelectorAll("input").forEach((cb) =>
      cb.addEventListener("change", () => {
        const checked = Array.from(wrap.querySelectorAll("input:checked")).map((i) => i.value);
        state.categories = checked;
        syncCategoryCheckboxes(wrap === catDesktopWrap ? catMobileWrap : catDesktopWrap, checked);
        if (wrap === catDesktopWrap) render();
      })
    );
  }

  function syncCategoryCheckboxes(otherWrap, checked) {
    if (!otherWrap) return;
    otherWrap.querySelectorAll("input").forEach((i) => (i.checked = checked.includes(i.value)));
  }

  buildCategoryCheckboxes(catDesktopWrap, "cat-d");
  buildCategoryCheckboxes(catMobileWrap, "cat-m");

  document.querySelectorAll('input[name="price-d"]').forEach((r) =>
    r.addEventListener("change", () => {
      state.price = r.value;
      syncRadios("price-m", r.value);
      render();
    })
  );
  document.querySelectorAll('input[name="rating-d"]').forEach((r) =>
    r.addEventListener("change", () => {
      state.rating = Number(r.value);
      syncRadios("rating-m", r.value);
      render();
    })
  );
  function syncRadios(name, value) {
    document.querySelectorAll('input[name="' + name + '"]').forEach((i) => (i.checked = i.value === value));
  }

  if (sortSelect) {
    sortSelect.addEventListener("change", () => {
      state.sort = sortSelect.value;
      render();
    });
  }

  document.querySelectorAll("[data-clear-filters]").forEach((btn) =>
    btn.addEventListener("click", () => {
      state.categories = [];
      state.price = "all";
      state.rating = 0;
      state.badge = null;
      syncCategoryCheckboxes(catDesktopWrap, []);
      syncCategoryCheckboxes(catMobileWrap, []);
      syncRadios("price-d", "all");
      syncRadios("price-m", "all");
      syncRadios("rating-d", "0");
      syncRadios("rating-m", "0");
      render();
    })
  );

  /* Mobile filter sheet */
  const sheet = document.querySelector(".filter-sheet");
  document.querySelectorAll("[data-open-filter-sheet]").forEach((btn) =>
    btn.addEventListener("click", () => {
      sheet.classList.add("is-open");
      document.body.style.overflow = "hidden";
    })
  );
  document.querySelectorAll("[data-close-filter-sheet]").forEach((btn) =>
    btn.addEventListener("click", () => {
      sheet.classList.remove("is-open");
      document.body.style.overflow = "";
    })
  );
  document.querySelectorAll("[data-apply-filter-sheet]").forEach((btn) =>
    btn.addEventListener("click", () => {
      const checked = Array.from(catMobileWrap.querySelectorAll("input:checked")).map((i) => i.value);
      state.categories = checked;
      syncCategoryCheckboxes(catDesktopWrap, checked);
      const priceChecked = document.querySelector('input[name="price-m"]:checked');
      if (priceChecked) { state.price = priceChecked.value; syncRadios("price-d", priceChecked.value); }
      const ratingChecked = document.querySelector('input[name="rating-m"]:checked');
      if (ratingChecked) { state.rating = Number(ratingChecked.value); syncRadios("rating-d", ratingChecked.value); }
      sheet.classList.remove("is-open");
      document.body.style.overflow = "";
      render();
    })
  );

  function matchesFilters(p) {
    if (state.categories.length && !state.categories.includes(p.category)) return false;
    if (state.badge && p.badge !== state.badge) return false;
    if (state.price !== "all") {
      const [min, max] = state.price.split("-").map(Number);
      const price = p.salePrice || p.price;
      if (price < min || price > max) return false;
    }
    if (state.rating && p.rating < state.rating) return false;
    return true;
  }

  function sortProducts(list) {
    const sorted = list.slice();
    switch (state.sort) {
      case "price-asc":
        sorted.sort((a, b) => (a.salePrice || a.price) - (b.salePrice || b.price));
        break;
      case "price-desc":
        sorted.sort((a, b) => (b.salePrice || b.price) - (a.salePrice || a.price));
        break;
      case "rating":
        sorted.sort((a, b) => b.rating - a.rating);
        break;
      case "name":
        sorted.sort((a, b) => a.name.localeCompare(b.name));
        break;
      default:
        break;
    }
    return sorted;
  }

  function render() {
    const filtered = sortProducts(window.PRODUCTS.filter(matchesFilters));
    window.Aurelia.renderProductList(grid, filtered);
    if (resultCount) resultCount.textContent = filtered.length + (filtered.length === 1 ? " product" : " products");
  }

  render();
})();
