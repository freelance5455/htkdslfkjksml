/* =========================================================
   AURELIA BEAUTÉ — Site Behavior
   Cart + wishlist persist via localStorage for the session.
   Product rendering, search, filters, and micro-interactions.
   ========================================================= */

(function () {
  "use strict";

  const FREE_SHIPPING_THRESHOLD = 75;
  const store = {
    get cart() { return JSON.parse(localStorage.getItem("aurelia_cart") || "[]"); },
    set cart(v) { localStorage.setItem("aurelia_cart", JSON.stringify(v)); },
    get wishlist() { return JSON.parse(localStorage.getItem("aurelia_wishlist") || "[]"); },
    set wishlist(v) { localStorage.setItem("aurelia_wishlist", JSON.stringify(v)); }
  };

  function money(n) { return "$" + n.toFixed(2).replace(/\.00$/, ""); }

  function findProduct(id) {
    return (window.PRODUCTS || []).find((p) => p.id === id);
  }

  /* ---------- Header scroll state ---------- */
  const header = document.querySelector(".site-header");
  function onScroll() {
    if (!header) return;
    header.classList.toggle("is-scrolled", window.scrollY > 8);
  }
  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();

  /* ---------- Mobile nav drawer ---------- */
  const mobileNav = document.querySelector(".mobile-nav");
  document.querySelectorAll("[data-open-nav]").forEach((btn) =>
    btn.addEventListener("click", () => toggleDrawer(mobileNav, true))
  );
  document.querySelectorAll("[data-close-nav]").forEach((btn) =>
    btn.addEventListener("click", () => toggleDrawer(mobileNav, false))
  );

  function toggleDrawer(el, open) {
    if (!el) return;
    el.classList.toggle("is-open", open);
    document.body.style.overflow = open ? "hidden" : "";
  }

  /* ---------- Toast ---------- */
  const toast = document.querySelector(".toast");
  let toastTimer;
  function showToast(msg) {
    if (!toast) return;
    toast.querySelector("span").textContent = msg;
    toast.classList.add("is-visible");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("is-visible"), 2400);
  }

  /* ---------- Cart drawer ---------- */
  const cartDrawer = document.querySelector(".cart-drawer");
  const cartBackdrop = document.querySelector("[data-cart-backdrop]");
  const cartItemsEl = document.querySelector(".cart-items");
  const cartCountEls = document.querySelectorAll("[data-cart-count]");
  const cartSubtotalEl = document.querySelector("[data-cart-subtotal]");
  const shippingTextEl = document.querySelector("[data-shipping-text]");
  const shippingBarFill = document.querySelector(".shipping-bar-fill");

  document.querySelectorAll("[data-open-cart]").forEach((btn) =>
    btn.addEventListener("click", () => { renderCart(); toggleDrawer(cartDrawer, true); toggleBackdrop(true); })
  );
  document.querySelectorAll("[data-close-cart]").forEach((btn) =>
    btn.addEventListener("click", () => { toggleDrawer(cartDrawer, false); toggleBackdrop(false); })
  );
  if (cartBackdrop) cartBackdrop.addEventListener("click", () => {
    toggleDrawer(cartDrawer, false);
    toggleDrawer(mobileNav, false);
    toggleBackdrop(false);
  });

  function toggleBackdrop(open) {
    if (cartBackdrop) cartBackdrop.classList.toggle("is-open", open);
    document.body.style.overflow = open ? "hidden" : "";
  }

  function addToCart(id, qty) {
    qty = qty || 1;
    const cart = store.cart;
    const existing = cart.find((i) => i.id === id);
    if (existing) existing.qty += qty;
    else cart.push({ id, qty });
    store.cart = cart;
    updateCartCount();
    const p = findProduct(id);
    showToast((p ? p.name : "Item") + " added to your bag.");
  }

  function updateQty(id, delta) {
    const cart = store.cart;
    const item = cart.find((i) => i.id === id);
    if (!item) return;
    item.qty += delta;
    const next = cart.filter((i) => i.qty > 0);
    store.cart = next;
    renderCart();
    updateCartCount();
  }

  function removeFromCart(id) {
    store.cart = store.cart.filter((i) => i.id !== id);
    renderCart();
    updateCartCount();
  }

  function updateCartCount() {
    const total = store.cart.reduce((sum, i) => sum + i.qty, 0);
    cartCountEls.forEach((el) => {
      el.textContent = total;
      el.classList.toggle("hidden", total === 0);
    });
  }

  function renderCart() {
    if (!cartItemsEl) return;
    const cart = store.cart;
    if (cart.length === 0) {
      cartItemsEl.innerHTML =
        '<div class="cart-empty">' +
        '<svg width="56" height="56" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.3"><path d="M6 6h15l-1.5 9h-12z"/><circle cx="9" cy="20" r="1"/><circle cx="18" cy="20" r="1"/><path d="M6 6 4 2H2"/></svg>' +
        "<p>Your bag is currently empty.</p>" +
        '<button class="btn btn-primary" data-close-cart>Continue Shopping</button>' +
        "</div>";
      cartItemsEl.querySelector("[data-close-cart]").addEventListener("click", () => {
        toggleDrawer(cartDrawer, false);
        toggleBackdrop(false);
      });
      if (cartSubtotalEl) cartSubtotalEl.textContent = money(0);
      updateShippingIndicator(0);
      return;
    }

    let subtotal = 0;
    cartItemsEl.innerHTML = cart
      .map((item) => {
        const p = findProduct(item.id);
        if (!p) return "";
        const price = p.salePrice || p.price;
        subtotal += price * item.qty;
        return (
          '<div class="cart-item" data-id="' + p.id + '">' +
          '<div class="cart-item-media"><img src="' + p.image + '" alt="' + p.alt + '" loading="lazy"></div>' +
          '<div><p class="cart-item-name">' + p.name + "</p>" +
          '<p class="cart-item-price">' + money(price) + "</p>" +
          '<div class="cart-item-qty">' +
          '<button aria-label="Decrease quantity" data-qty-minus>&minus;</button>' +
          "<span>" + item.qty + "</span>" +
          '<button aria-label="Increase quantity" data-qty-plus>+</button>' +
          "</div></div>" +
          '<button class="cart-item-remove" data-remove>Remove</button>' +
          "</div>"
        );
      })
      .join("");

    cartItemsEl.querySelectorAll(".cart-item").forEach((row) => {
      const id = row.getAttribute("data-id");
      row.querySelector("[data-qty-plus]").addEventListener("click", () => updateQty(id, 1));
      row.querySelector("[data-qty-minus]").addEventListener("click", () => updateQty(id, -1));
      row.querySelector("[data-remove]").addEventListener("click", () => removeFromCart(id));
    });

    if (cartSubtotalEl) cartSubtotalEl.textContent = money(subtotal);
    updateShippingIndicator(subtotal);
  }

  function updateShippingIndicator(subtotal) {
    if (!shippingTextEl || !shippingBarFill) return;
    const remaining = FREE_SHIPPING_THRESHOLD - subtotal;
    const pct = Math.min(100, (subtotal / FREE_SHIPPING_THRESHOLD) * 100);
    shippingBarFill.style.width = pct + "%";
    shippingTextEl.textContent =
      remaining > 0
        ? "You're " + money(remaining) + " away from complimentary shipping."
        : "You've unlocked complimentary shipping.";
  }

  /* ---------- Wishlist ---------- */
  function toggleWishlist(id, btn) {
    let wishlist = store.wishlist;
    const has = wishlist.includes(id);
    wishlist = has ? wishlist.filter((w) => w !== id) : wishlist.concat(id);
    store.wishlist = wishlist;
    if (btn) btn.classList.toggle("is-active", !has);
    if (!has) showToast("Saved to your wishlist.");
  }

  /* ---------- Product card rendering ---------- */
  function starString(rating) {
    const full = Math.round(rating);
    return "★".repeat(full) + "☆".repeat(5 - full);
  }

  function productCardHTML(p) {
    const onSale = !!p.salePrice;
    const badge = p.badge
      ? '<span class="product-badge' + (p.badge === "SALE" ? " sale" : "") + '">' + p.badge + "</span>"
      : "";
    const wishActive = store.wishlist.includes(p.id) ? " is-active" : "";
    return (
      '<article class="product-card" data-id="' + p.id + '" data-category="' + p.category + '" data-price="' + (p.salePrice || p.price) + '" data-rating="' + p.rating + '">' +
      '<div class="product-media">' +
      badge +
      '<button class="wishlist-btn' + wishActive + '" data-wishlist aria-label="Save ' + p.name + ' to wishlist" aria-pressed="' + (wishActive ? "true" : "false") + '">' +
      '<svg viewBox="0 0 24 24"><path d="M12 20s-7-4.35-9.5-8.5C.5 8 2 4.5 5.5 4.5c2 0 3.5 1.2 4.5 2.7C11 5.7 12.5 4.5 14.5 4.5 18 4.5 19.5 8 19.5 11.5 17 15.65 12 20 12 20z"/></svg>' +
      "</button>" +
      '<img src="' + p.image + '" alt="' + p.alt + '" loading="lazy">' +
      '<button class="quick-add" data-quick-add>Quick Add</button>' +
      "</div>" +
      '<div class="product-info">' +
      '<p class="product-category">' + p.category + "</p>" +
      '<h3 class="product-name">' + p.name + "</h3>" +
      '<p class="product-descriptor">' + p.descriptor + "</p>" +
      '<div class="product-rating"><span class="stars">' + starString(p.rating) + "</span><span>(" + p.reviews + ")</span></div>" +
      '<div class="product-price">' +
      (onSale ? '<span class="now on-sale">' + money(p.salePrice) + '</span><span class="was">' + money(p.price) + "</span>" : "<span>" + money(p.price) + "</span>") +
      "</div>" +
      "</div>" +
      "</article>"
    );
  }

  function renderProductList(container, products) {
    if (!container) return;
    if (products.length === 0) {
      container.innerHTML = '<div class="empty-state"><p>No products match those filters yet. Try clearing a filter.</p></div>';
      return;
    }
    container.innerHTML = products.map(productCardHTML).join("");
    wireProductCards(container);
  }

  function wireProductCards(container) {
    container.querySelectorAll("[data-quick-add]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const card = btn.closest(".product-card");
        addToCart(card.getAttribute("data-id"), 1);
      });
    });
    container.querySelectorAll("[data-wishlist]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const card = btn.closest(".product-card");
        toggleWishlist(card.getAttribute("data-id"), btn);
        btn.setAttribute("aria-pressed", btn.classList.contains("is-active") ? "true" : "false");
      });
    });
  }

  /* Render any static product containers on the page */
  document.querySelectorAll("[data-product-source]").forEach((container) => {
    const source = container.getAttribute("data-product-source");
    let list = window.PRODUCTS || [];
    if (source !== "all") list = list.filter((p) => p.badge === source || p.category === source);
    const limit = container.getAttribute("data-limit");
    if (limit) list = list.slice(0, Number(limit));
    renderProductList(container, list);
  });

  updateCartCount();

  /* ---------- Search overlay ---------- */
  const searchOverlay = document.querySelector(".search-overlay");
  const searchInput = document.querySelector("[data-search-input]");
  const searchResults = document.querySelector("[data-search-results]");

  document.querySelectorAll("[data-open-search]").forEach((btn) =>
    btn.addEventListener("click", () => {
      searchOverlay.classList.add("is-open");
      document.body.style.overflow = "hidden";
      setTimeout(() => searchInput && searchInput.focus(), 60);
    })
  );
  document.querySelectorAll("[data-close-search]").forEach((btn) =>
    btn.addEventListener("click", () => {
      searchOverlay.classList.remove("is-open");
      document.body.style.overflow = "";
    })
  );
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      searchOverlay && searchOverlay.classList.remove("is-open");
      toggleDrawer(cartDrawer, false);
      toggleDrawer(mobileNav, false);
      toggleBackdrop(false);
      document.body.style.overflow = "";
    }
  });

  if (searchInput) {
    searchInput.addEventListener("input", () => {
      const q = searchInput.value.trim().toLowerCase();
      if (!q) {
        searchResults.innerHTML = "";
        return;
      }
      const matches = (window.PRODUCTS || []).filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q) ||
          p.descriptor.toLowerCase().includes(q)
      );
      if (matches.length === 0) {
        searchResults.innerHTML = '<p class="search-empty">No products found for &ldquo;' + searchInput.value + '&rdquo;.</p>';
        return;
      }
      searchResults.innerHTML = matches
        .slice(0, 8)
        .map(
          (p) =>
            '<a class="search-result-item" href="shop.html#' + p.id + '">' +
            '<div class="search-result-media"><img src="' + p.image + '" alt="" loading="lazy"></div>' +
            '<div><p class="search-result-name">' + p.name + '</p><p class="search-result-cat">' + p.category + " &middot; " + money(p.salePrice || p.price) + "</p></div>" +
            "</a>"
        )
        .join("");
    });
  }

  /* ---------- Newsletter validation ---------- */
  document.querySelectorAll("[data-newsletter-form]").forEach((form) => {
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const input = form.querySelector("input[type=email]");
      const msg = form.querySelector("[data-newsletter-msg]");
      const value = input.value.trim();
      const validEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
      if (!value) {
        msg.textContent = "Please enter your email address.";
        msg.className = "newsletter-msg error";
      } else if (!validEmail) {
        msg.textContent = "That doesn't look like a valid email — please check and try again.";
        msg.className = "newsletter-msg error";
      } else {
        msg.textContent = "You're on the list. Welcome to Aurelia Beauté.";
        msg.className = "newsletter-msg success";
        form.reset();
      }
    });
  });

  /* ---------- Testimonial carousel ---------- */
  const slides = document.querySelectorAll(".testimonial-slide");
  let slideIndex = 0;
  function showSlide(i) {
    slides.forEach((s, idx) => s.classList.toggle("is-active", idx === i));
  }
  document.querySelectorAll("[data-testimonial-next]").forEach((btn) =>
    btn.addEventListener("click", () => {
      slideIndex = (slideIndex + 1) % slides.length;
      showSlide(slideIndex);
    })
  );
  document.querySelectorAll("[data-testimonial-prev]").forEach((btn) =>
    btn.addEventListener("click", () => {
      slideIndex = (slideIndex - 1 + slides.length) % slides.length;
      showSlide(slideIndex);
    })
  );

  /* ---------- Scroll reveal (single orchestrated pass) ---------- */
  const revealTargets = document.querySelectorAll("[data-reveal]");
  if ("IntersectionObserver" in window && revealTargets.length) {
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.style.opacity = "1";
            entry.target.style.transform = "none";
            io.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12 }
    );
    revealTargets.forEach((el) => {
      el.style.opacity = "0";
      el.style.transform = "translateY(16px)";
      el.style.transition = "opacity 0.6s var(--ease), transform 0.6s var(--ease)";
      io.observe(el);
    });
  }

  /* ---------- Back to top ---------- */
  const backToTop = document.querySelector("[data-back-to-top]");
  if (backToTop) {
    window.addEventListener(
      "scroll",
      () => backToTop.classList.toggle("is-visible", window.scrollY > 900),
      { passive: true }
    );
    backToTop.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));
  }

  /* Expose for shop.js */
  window.Aurelia = {
    store,
    money,
    addToCart,
    renderProductList,
    wireProductCards,
    productCardHTML
  };
})();
