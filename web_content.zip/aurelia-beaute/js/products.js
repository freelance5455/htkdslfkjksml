/* =========================================================
   AURELIA BEAUTÉ — Product Data
   Central source of truth for all product cards, filters,
   and search. Swap in real inventory data here later.
   ========================================================= */

const PRODUCTS = [
  {
    id: "p01",
    name: "Radiance Renewal Serum",
    category: "Skincare",
    descriptor: "Vitamin C + peptide complex for visible glow",
    price: 48,
    salePrice: null,
    rating: 4.8,
    reviews: 312,
    badge: "BESTSELLER",
    image: "https://images.unsplash.com/photo-1611930022073-b7a4ba5fcccd?auto=format&fit=crop&w=800&q=80",
    alt: "Amber glass dropper bottle of Radiance Renewal Serum on a blush backdrop"
  },
  {
    id: "p02",
    name: "Velvet Skin Cream",
    category: "Skincare",
    descriptor: "Rich barrier-repair moisturizer with ceramides",
    price: 42,
    salePrice: null,
    rating: 4.7,
    reviews: 208,
    badge: "",
    image: "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&w=800&q=80",
    alt: "Ivory jar of Velvet Skin Cream with soft studio lighting"
  },
  {
    id: "p03",
    name: "Élan Eau de Parfum",
    category: "Fragrance",
    descriptor: "White tea, amber and soft musk",
    price: 68,
    salePrice: 54,
    rating: 4.9,
    reviews: 176,
    badge: "SALE",
    image: "https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&w=800&q=80",
    alt: "Frosted glass perfume bottle of Élan Eau de Parfum"
  },
  {
    id: "p04",
    name: "Silk Matte Lip Colour",
    category: "Makeup",
    descriptor: "Weightless, long-wear pigment in Dusty Rose",
    price: 29,
    salePrice: null,
    rating: 4.6,
    reviews: 421,
    badge: "NEW",
    image: "https://images.unsplash.com/photo-1586495777744-4413f21062fa?auto=format&fit=crop&w=800&q=80",
    alt: "Rose gold tube of Silk Matte Lip Colour beside a swatch"
  },
  {
    id: "p05",
    name: "Luminous Skin Tint",
    category: "Makeup",
    descriptor: "Sheer, breathable coverage with SPF 25",
    price: 38,
    salePrice: null,
    rating: 4.5,
    reviews: 289,
    badge: "",
    image: "https://images.unsplash.com/photo-1631730359585-38a4935cbec4?auto=format&fit=crop&w=800&q=80",
    alt: "Glass bottle of Luminous Skin Tint with dropper cap"
  },
  {
    id: "p06",
    name: "Botanical Repair Hair Oil",
    category: "Haircare",
    descriptor: "Lightweight shine and split-end defense",
    price: 34,
    salePrice: null,
    rating: 4.7,
    reviews: 154,
    badge: "",
    image: "https://images.unsplash.com/photo-1608248543803-ba4f8c70ae0b?auto=format&fit=crop&w=800&q=80",
    alt: "Amber bottle of Botanical Repair Hair Oil with dried botanicals"
  },
  {
    id: "p07",
    name: "Cloud Cushion Blush",
    category: "Makeup",
    descriptor: "Buildable, dewy flush in Petal",
    price: 26,
    salePrice: null,
    rating: 4.6,
    reviews: 133,
    badge: "NEW",
    image: "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=800&q=80",
    alt: "Compact of Cloud Cushion Blush with mirror open"
  },
  {
    id: "p08",
    name: "Overnight Recovery Mask",
    category: "Skincare",
    descriptor: "Sleep-in treatment with niacinamide",
    price: 44,
    salePrice: 36,
    rating: 4.8,
    reviews: 197,
    badge: "SALE",
    image: "https://images.unsplash.com/photo-1570194065650-d99fb4bedf0a?auto=format&fit=crop&w=800&q=80",
    alt: "Jar of Overnight Recovery Mask with a spatula resting beside it"
  },
  {
    id: "p09",
    name: "Weightless Volumizing Shampoo",
    category: "Haircare",
    descriptor: "Sulfate-free cleanse with rice protein",
    price: 24,
    salePrice: null,
    rating: 4.4,
    reviews: 88,
    badge: "",
    image: "https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=800&q=80",
    alt: "Bottle of Weightless Volumizing Shampoo on tile"
  },
  {
    id: "p10",
    name: "Rose Quartz Facial Roller",
    category: "Beauty Essentials",
    descriptor: "Cooling sculpt-and-glow ritual tool",
    price: 22,
    salePrice: null,
    rating: 4.5,
    reviews: 143,
    badge: "",
    image: "https://images.unsplash.com/photo-1608248597279-f99d160bfcbc?auto=format&fit=crop&w=800&q=80",
    alt: "Rose quartz facial roller resting on a linen cloth"
  },
  {
    id: "p11",
    name: "Soft Focus Setting Powder",
    category: "Makeup",
    descriptor: "Translucent finish that blurs and holds",
    price: 32,
    salePrice: null,
    rating: 4.6,
    reviews: 121,
    badge: "",
    image: "https://images.unsplash.com/photo-1512207736890-6ffd4c9e0e13?auto=format&fit=crop&w=800&q=80",
    alt: "Compact of Soft Focus Setting Powder with a brush"
  },
  {
    id: "p12",
    name: "Golden Hour Eyeshadow Palette",
    category: "Makeup",
    descriptor: "Nine warm neutrals, matte to shimmer",
    price: 46,
    salePrice: null,
    rating: 4.9,
    reviews: 265,
    badge: "BESTSELLER",
    image: "https://images.unsplash.com/photo-1583241800698-9c2e28e7e2b2?auto=format&fit=crop&w=800&q=80",
    alt: "Open Golden Hour Eyeshadow Palette showing nine warm shades"
  }
];

const CATEGORIES = ["Skincare", "Makeup", "Haircare", "Fragrance", "Beauty Essentials"];
