# Aurelia Beauté — Storefront

A responsive, front-end luxury beauty e-commerce site. Static HTML/CSS/JS —
no build step, no dependencies — so it deploys straight to Hostinger (or any
static host) by uploading the files as-is.

## What's included

- `index.html` — homepage: hero, trust strip, category grid, bestsellers
  ("The Edit"), promo banner, brand values, testimonial carousel, Instagram-
  style gallery, newsletter signup, footer.
- `shop.html` — full shop page: category/price/rating filters (desktop
  sidebar + mobile bottom-sheet), sorting, responsive product grid.
- `css/styles.css` — the full design system (color tokens, type scale,
  spacing scale, every component).
- `js/products.js` — the product catalog. Edit this array to add, remove,
  or reprice products; every page reads from it.
- `js/main.js` — shared behavior: sticky header, mobile nav, cart drawer
  (add/remove/qty, free-shipping threshold, localStorage persistence),
  wishlist, search overlay, newsletter validation, testimonial carousel,
  scroll reveal, back-to-top.
- `js/shop.js` — filtering and sorting logic for the shop page.

## Deploying to Hostinger

1. Zip contents (already done) or upload the folder via Hostinger's File
   Manager / FTP into `public_html/`.
2. No build command needed — it's plain HTML/CSS/JS.
3. Point your domain at `public_html/` and it's live.

## Before a real launch

- **Imagery**: every photo currently points to royalty-free stock imagery
  (Unsplash) as a placeholder for the "editorial luxury beauty" art
  direction described in the brief. This environment doesn't have
  photorealistic image generation, so swap these for a commissioned or
  AI-generated campaign shoot before launch — the code already expects one
  consistent image per product/section, so it's a drop-in replacement (just
  update the `image` field in `js/products.js` and the `src` attributes in
  the HTML).
- **Checkout**: the cart is a fully working front-end experience (add,
  remove, quantities, shipping threshold, persists via localStorage) but
  "Checkout" is a placeholder link — wire it to a real payment provider
  (Stripe, PayPal, etc.) when ready.
- **Product detail pages**: this build covers the homepage and shop/listing
  page. A dedicated product-detail template, live account system, and full
  multi-step checkout are the natural next additions.
- **Newsletter**: front-end validated only; connect the form to your email
  provider (Mailchimp, Klaviyo, etc.) to actually collect signups.

## Originality note

"Aurelia Beauté," its wordmark, copy, product names, and pricing are all
original to this build — nothing is copied from any reference brand, logo,
or photography.
