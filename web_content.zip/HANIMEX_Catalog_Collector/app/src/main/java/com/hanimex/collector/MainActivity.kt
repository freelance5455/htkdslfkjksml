package com.hanimex.collector

import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var scanning = false
    private var lastExtracted = "{}"
    private val createZipRequest = 7001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.loadsImagesAutomatically = true
        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                if (scanning && url != null && url.startsWith("https://www.hanimex.net")) {
                    view?.evaluateJavascript(EXTRACT_SCRIPT, null)
                }
            }
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class Bridge {
        @JavascriptInterface fun scan(url: String) {
            runOnUiThread {
                if (!url.startsWith("https://www.hanimex.net/")) {
                    Toast.makeText(this@MainActivity, "استخدم رابطًا من hanimex.net", Toast.LENGTH_LONG).show(); return@runOnUiThread
                }
                scanning = true
                web.loadUrl(url)
            }
        }
        @JavascriptInterface fun onExtracted(json: String) {
            lastExtracted = json
            scanning = false
            runOnUiThread {
                web.loadUrl("file:///android_asset/index.html")
                web.postDelayed({ web.evaluateJavascript("window.receiveExtracted(${JSONObject.quote(json)});", null) }, 500)
            }
        }
        @JavascriptInterface fun exportZip(json: String) {
            lastExtracted = json
            runOnUiThread {
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/zip"
                    putExtra(Intent.EXTRA_TITLE, "HANIMEX_Catalog_Backup.zip")
                }
                startActivityForResult(intent, createZipRequest)
            }
        }
        @JavascriptInterface fun openExternal(url: String) {
            if (url.startsWith("https://")) startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == createZipRequest && resultCode == RESULT_OK && data?.data != null) {
            Thread {
                try {
                    contentResolver.openOutputStream(data.data!!)?.use { out ->
                        ZipOutputStream(out).use { zip ->
                            zip.putNextEntry(ZipEntry("catalog.json"))
                            zip.write(lastExtracted.toByteArray(Charsets.UTF_8))
                            zip.closeEntry()
                            val root = JSONObject(lastExtracted)
                            val imageUrls = linkedSetOf<String>()
                            val rootImages = root.optJSONArray("images") ?: JSONArray()
                            for (i in 0 until rootImages.length()) imageUrls.add(rootImages.optString(i))
                            val records = root.optJSONArray("records") ?: JSONArray()
                            for (r in 0 until records.length()) {
                                val recordImages = records.optJSONObject(r)?.optJSONArray("images") ?: JSONArray()
                                for (j in 0 until recordImages.length()) imageUrls.add(recordImages.optString(j))
                            }
                            var imageIndex = 0
                            for (imageUrl in imageUrls) {
                                if (!imageUrl.startsWith("https://")) continue
                                try {
                                    val conn = URL(imageUrl).openConnection() as HttpURLConnection
                                    conn.connectTimeout = 12000; conn.readTimeout = 15000
                                    conn.setRequestProperty("User-Agent", "Mozilla/5.0 HANIMEXCollector")
                                    conn.inputStream.use { input ->
                                        imageIndex += 1
                                        val ext = when {
                                            imageUrl.substringBefore('?').endsWith(".png", true) -> "png"
                                            imageUrl.substringBefore('?').endsWith(".webp", true) -> "webp"
                                            else -> "jpg"
                                        }
                                        zip.putNextEntry(ZipEntry("images/image_${imageIndex}.$ext"))
                                        input.copyTo(zip)
                                        zip.closeEntry()
                                    }
                                    conn.disconnect()
                                } catch (_: Exception) { }
                            }
                            zip.putNextEntry(ZipEntry("README.txt"))
                            zip.write("HANIMEX Catalog Collector backup. catalog.json contains collected fields; images folder contains images downloaded successfully. Some site images may be omitted if access is restricted.".toByteArray())
                            zip.closeEntry()
                        }
                    }
                    runOnUiThread { Toast.makeText(this, "تم إنشاء النسخة الاحتياطية ZIP", Toast.LENGTH_LONG).show(); web.evaluateJavascript("window.backupDone && window.backupDone()", null) }
                } catch (e: Exception) {
                    runOnUiThread { Toast.makeText(this, "تعذر إنشاء النسخة: ${e.message}", Toast.LENGTH_LONG).show() }
                }
            }.start()
        }
    }

    private val EXTRACT_SCRIPT = """(function(){
      const clean=s=>(s||'').replace(/\\s+/g,' ').trim();
      const title=clean(document.querySelector('meta[property="og:title"]')?.content||document.querySelector('h1')?.innerText||document.title);
      const desc=clean(document.querySelector('meta[name="description"]')?.content||document.querySelector('[itemprop="description"]')?.innerText||'');
      const canonical=document.querySelector('link[rel="canonical"]')?.href||location.href;
      const code=(location.pathname.match(/(?:^|\/)(\d{6,})-/)||location.href.match(/(\d{6,})/ )||[])[1]||'';
      const priceText=clean(document.querySelector('[itemprop="price"]')?.content||document.querySelector('.oe_price .oe_currency_value')?.innerText||document.querySelector('.product_price')?.innerText||'');
      const images=[...new Set([...document.images].map(i=>i.currentSrc||i.src).filter(u=>u&&u.startsWith('http')&&!/logo|icon|payment|placeholder/i.test(u)))];
      const productLinks=[...new Set([...document.querySelectorAll('a[href*="/shop/"]')].map(a=>a.href).filter(u=>/\/shop\//.test(u)))];
      const result={sourceUrl:location.href,canonicalUrl:canonical,title,description:desc,productCode:code,priceText,images,productLinks,scannedAt:new Date().toISOString(),pageType:code?'product':(productLinks.length?'category':'unknown')};
      window.AndroidBridge.onExtracted(JSON.stringify(result));
    })();"""
}
