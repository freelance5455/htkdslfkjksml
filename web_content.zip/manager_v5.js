const $=id=>document.getElementById(id);
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
let allRows=[],circleMap={},teacherProfiles={},profiles={},attendanceMap={};
let selectedTeacherKey=null;
function msg(t,ok=false){const e=$('msg'); if(e){e.textContent=t;e.className=ok?'ok':'error'} let n=$('toast'); if(!n){n=document.createElement('div');n.id='toast';document.body.appendChild(n)} n.textContent=t;n.className='toast '+(ok?'toast-ok':'toast-error');clearTimeout(window.__toastTimer);window.__toastTimer=setTimeout(()=>n.className='toast hidden',3500)}
function rowDate(x){return String(x.report_date||x.date||x.attendance_date||x.created_at||'').slice(0,10)}
function teacherKey(x){return x.teacher_profile_id||('name:'+String(x.teacher_name||profiles[x.teacher_id]?.full_name||profiles[x.teacher_id]?.name||x.teacher_id||'غير محدد'))}
function teacherName(x){
  if(typeof x==='string') return x;
  return String(x.teacher_name||teacherProfiles[x.teacher_profile_id]?.teacher_name||profiles[x.teacher_id]?.full_name||profiles[x.teacher_id]?.name||profiles[x.teacher_id]?.email||'محفظ غير محدد');
}
function teacherGroups(rows){const g={}; rows.forEach(x=>{const k=teacherKey(x);(g[k]??=[]).push(x)});return g}
function presentCount(x){return attendanceMap[String(x.circle_id)+'|'+rowDate(x)]?.size||0}
function filtered(){const m=$('month').value,q=$('search').value.trim().toLowerCase();return allRows.filter(x=>{const d=rowDate(x),t=teacherName(x).toLowerCase(),c=String(circleMap[x.circle_id]||'').toLowerCase();return (!m||d.startsWith(m))&&(!q||t.includes(q)||c.includes(q))})}
async function loadReports(){
  $('status').textContent='جاري تحميل التقارير...';
  $('teachersList').innerHTML='<div class="loading">جاري تحميل بيانات المحفظين والتقارير…</div>';
  $('reports').innerHTML='';
  try{
    let r=await sb.from('daily_reports').select('*').order('created_at',{ascending:false});
    if(r.error){$('status').textContent='خطأ في تحميل التقارير: '+r.error.message;$('teachersList').innerHTML='<div class="empty errorbox">تعذر تحميل التقارير من قاعدة البيانات.<br><small>'+esc(r.error.message)+'</small></div>';return}
    allRows=r.data||[]; circleMap={}; teacherProfiles={}; profiles={}; attendanceMap={};
    const cids=[...new Set(allRows.map(x=>x.circle_id).filter(Boolean))];
    const tids=[...new Set(allRows.map(x=>x.teacher_id).filter(Boolean))];
    const tpids=[...new Set(allRows.map(x=>x.teacher_profile_id).filter(Boolean))];
    if(cids.length){const c=await sb.from('circles').select('id,name').in('id',cids);if(!c.error)(c.data||[]).forEach(x=>circleMap[x.id]=x.name)}
    if(tpids.length){const p=await sb.from('teacher_profiles').select('id,teacher_name,teacher_code').in('id',tpids);if(!p.error)(p.data||[]).forEach(x=>teacherProfiles[x.id]=x)}
    if(tids.length){const p=await sb.from('profiles').select('*').in('id',tids);if(!p.error)(p.data||[]).forEach(x=>profiles[x.id]=x)}
    await loadAttendance(cids);
    render();
  }catch(e){$('status').textContent='خطأ غير متوقع';$('teachersList').innerHTML='<div class="empty errorbox">'+esc(e?.message||e)+'</div>'}
}
async function loadAttendance(cids){
  if(!cids.length)return;
  const a=await sb.from('attendance').select('*').in('circle_id',cids);
  if(a.error){$('status').textContent='تم تحميل التقارير، لكن تعذر حساب الحضور: '+a.error.message;return}
  (a.data||[]).forEach(x=>{const d=String(x.attendance_date||x.date||x.created_at||'').slice(0,10),k=String(x.circle_id)+'|'+d;if(!attendanceMap[k])attendanceMap[k]=new Set();if(String(x.status||'present').toLowerCase()!=='absent')attendanceMap[k].add(x.student_id||x.id)})
}
function render(){
  const rows=filtered(),groups=teacherGroups(rows);
  $('count').textContent=rows.length;
  $('hours').textContent=rows.reduce((s,x)=>s+Number(x.hours||0),0);
  $('teachers').textContent=Object.keys(groups).length;
  $('circles').textContent=new Set(rows.map(x=>x.circle_id).filter(Boolean)).size;
  const dayAttendance={};rows.forEach(x=>{const k=teacherKey(x)+'|'+rowDate(x);dayAttendance[k]=(dayAttendance[k]||0)+presentCount(x)});
  $('students').textContent=Object.values(dayAttendance).reduce((a,b)=>a+b,0);
  $('status').textContent=rows.length?'تم تحميل '+rows.length+' تقرير':'لا توجد تقارير مطابقة';
  const ids=Object.keys(groups);
  $('teachersList').innerHTML=ids.length?ids.map(k=>{
    const rs=groups[k],hours=rs.reduce((s,x)=>s+Number(x.hours||0),0),circles=new Set(rs.map(x=>x.circle_id).filter(Boolean)).size,days=new Set(rs.map(rowDate)).size,name=teacherName(rs[0]),presence=rs.reduce((s,x)=>s+presentCount(x),0);
    return `<article class="teacher-card"><div class="teacher-avatar">${esc(name).trim().slice(0,1)||'م'}</div><div class="teacher-main"><div class="teacher-title"><h3>${esc(name)}</h3><span class="pill">${days} يوم</span></div><div class="teacher-stats"><span><b>${rs.length}</b> تقرير</span><span><b>${hours}</b> ساعة</span><span><b>${circles}</b> حلقات</span><span><b>${presence}</b> حضور</span></div><button class="primary full" data-open-teacher="${esc(k)}">فتح ملف المحفظ</button></div></article>`
  }).join(''):'<div class="empty">لا توجد تقارير حتى الآن.</div>';
  $('reports').innerHTML=rows.length?rows.slice(0,30).map(reportRowHtml).join('')+(rows.length>30?'<div class="muted center">يتم عرض أحدث 30 تقريرًا هنا. افتح ملف المحفظ لرؤية كل تقاريره.</div>':''):'<div class="empty">لا توجد تقارير مطابقة.</div>';
  bindDynamic();
}
function reportRowHtml(x){return `<div class="report-row"><div class="report-date">${esc(rowDate(x))}</div><div class="report-info"><b>${esc(teacherName(x))}</b><span>📚 ${esc(circleMap[x.circle_id]||'غير محددة')}</span><span>⏱ ${esc(x.hours??0)} ساعة</span><span>👥 ${presentCount(x)} حضور</span>${x.notes?`<span>📝 ${esc(x.notes)}</span>`:''}</div><button type="button" class="danger small delete-report" data-id="${esc(x.id||'')}">حذف</button></div>`}
function bindDynamic(){document.querySelectorAll('[data-open-teacher]').forEach(b=>{b.onclick=()=>openTeacher(b.dataset.openTeacher)});}

function openTeacher(key){
  selectedTeacherKey=key;const rows=filtered().filter(x=>teacherKey(x)===key);if(!rows.length)return;
  const name=teacherName(rows[0]),hours=rows.reduce((s,x)=>s+Number(x.hours||0),0),circles=new Set(rows.map(x=>x.circle_id).filter(Boolean)).size,days={};
  rows.forEach(x=>(days[rowDate(x)]??=[]).push(x));
  $('detailTitle').textContent=name;$('detailSubtitle').textContent=`إجمالي ${rows.length} تقرير — ${Object.keys(days).length} يوم`;
  $('detailStats').innerHTML=`<div><b>${rows.length}</b><small>التقارير</small></div><div><b>${Object.keys(days).length}</b><small>الأيام</small></div><div><b>${hours}</b><small>الساعات</small></div><div><b>${circles}</b><small>الحلقات</small></div>`;
  $('detailBody').innerHTML=Object.keys(days).sort().reverse().map(d=>{const rs=days[d],h=rs.reduce((s,x)=>s+Number(x.hours||0),0),p=rs.reduce((s,x)=>s+presentCount(x),0);return `<section class="day-card"><div class="day-head"><div><b>📅 ${esc(d)}</b><span>${rs.length} تقرير حلقة</span></div><div class="day-total"><b>${h} ساعة</b><b>${p} حضور</b></div></div><div class="day-reports">${rs.map(x=>`<div class="detail-report"><div><b>📚 ${esc(circleMap[x.circle_id]||'غير محددة')}</b><small>⏱ ${esc(x.hours??0)} ساعة · 👥 ${presentCount(x)} حضور</small>${x.notes?`<small>📝 ${esc(x.notes)}</small>`:''}</div><button type="button" class="danger small delete-report" data-id="${esc(x.id||'')}">حذف</button></div>`).join('')}</div></section>`}).join('');
  $('detail').classList.remove('hidden');document.body.classList.add('modal-open');bindDetail();
}
function bindDetail(){}
document.addEventListener('click',async e=>{const b=e.target.closest?.('.delete-report');if(!b)return;e.preventDefault();e.stopPropagation();await deleteReport(b.dataset.id,!!b.closest('#detail'))})
function closeDetail(){ $('detail').classList.add('hidden');document.body.classList.remove('modal-open');selectedTeacherKey=null }
async function deleteReport(id,fromDetail=false){
  if(!id){msg('رقم التقرير غير موجود');return}
  msg('جاري حذف التقرير...');
  const r=await sb.from('daily_reports').delete().eq('id',id);
  if(r.error){msg('تعذر حذف التقرير: '+r.error.message);return}
  
  msg('تم حذف التقرير بنجاح',true);
  await loadReports();
  if(fromDetail&&selectedTeacherKey){
    const key=selectedTeacherKey;
    if(filtered().some(x=>teacherKey(x)===key)) openTeacher(key); else closeDetail();
  }
}
async function clearVisible(){
  const rows=filtered();if(!rows.length){msg('لا توجد تقارير لمسحها.');return}
  
  for(const x of rows){const r=await sb.from('daily_reports').delete().eq('id',x.id);if(r.error){msg('تعذر الحذف: '+r.error.message);return}}
  msg('تم حذف التقارير المحددة.',true);await loadReports()
}
function csv(){const rows=filtered(),head=['التاريخ','المحفظ','الحلقة','الساعات','الحضور','الملاحظات'];const lines=[head,...rows.map(x=>[rowDate(x),teacherName(x),circleMap[x.circle_id]||'',x.hours??0,presentCount(x),x.notes||''])].map(a=>a.map(v=>'"'+String(v).replaceAll('"','""')+'"').join(','));const blob=new Blob(['\uFEFF'+lines.join('\n')],{type:'text/csv;charset=utf-8'}),u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download='تقارير_المحفظين.csv';a.click();setTimeout(()=>URL.revokeObjectURL(u),1000)}
async function login(){const email=$('email').value.trim(),password=$('password').value;if(!email||!password){msg('اكتب البريد وكلمة السر');return}msg('جاري الدخول...');const r=await sb.auth.signInWithPassword({email,password});if(r.error){msg(r.error.message);return}const u=r.data.user,p=await sb.from('profiles').select('role').eq('id',u.id).maybeSingle();if(p.error||p.data?.role!=='manager'){msg(p.error?'تعذر قراءة صلاحية الحساب: '+p.error.message:'هذا الحساب ليس حساب مدير');await sb.auth.signOut();return}$('login').classList.add('hidden');$('app').classList.remove('hidden');$('user').textContent=u.email||'المدير';await loadReports()}
async function init(){const s=await sb.auth.getSession();if(s.data?.session?.user){const u=s.data.session.user,p=await sb.from('profiles').select('role').eq('id',u.id).maybeSingle();if(!p.error&&p.data?.role==='manager'){$('login').classList.add('hidden');$('app').classList.remove('hidden');$('user').textContent=u.email||'المدير';await loadReports()}}}
$('loginBtn').onclick=login;$('refresh').onclick=loadReports;$('logout').onclick=async()=>{await sb.auth.signOut();location.reload()};$('month').onchange=render;$('search').oninput=render;$('export').onclick=csv;$('clear').onclick=clearVisible;$('closeDetail').onclick=closeDetail;$('detail').addEventListener('click',e=>{if(e.target===$('detail'))closeDetail()});init();
