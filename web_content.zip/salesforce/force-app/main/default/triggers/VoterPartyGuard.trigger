trigger VoterPartyGuard on Voter__c (before update) {
    // An older client timestamp never overwrites a newer tag (offline sync safety).
    for (Voter__c v : Trigger.new) {
        Voter__c o = Trigger.oldMap.get(v.Id);
        if (v.Party_Updated_At__c != null && o.Party_Updated_At__c != null && v.Party_Updated_At__c < o.Party_Updated_At__c) {
            v.Party__c = o.Party__c; v.Party_Updated_At__c = o.Party_Updated_At__c; v.Updated_By__c = o.Updated_By__c;
        }
    }
}
