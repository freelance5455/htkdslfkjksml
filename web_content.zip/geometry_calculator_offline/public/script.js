const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

const shapes = {
  square: { title: "Persegi", formula: "s × s", fields: [{ id: "s", label: "Panjang sisi" }], calc: v => v.s * v.s },
  rectangle: { title: "Persegi panjang", formula: "p × l", fields: [{ id: "p", label: "Panjang" }, { id: "l", label: "Lebar" }], calc: v => v.p * v.l },
  triangle: { title: "Segitiga", formula: "½ × a × t", fields: [{ id: "a", label: "Alas" }, { id: "t", label: "Tinggi" }], calc: v => 0.5 * v.a * v.t },
  circle: { title: "Lingkaran", formula: "π × r²", fields: [{ id: "r", label: "Jari-jari" }], calc: v => Math.PI * v.r * v.r },
  parallelogram: { title: "Jajar genjang", formula: "a × t", fields: [{ id: "a", label: "Alas" }, { id: "t", label: "Tinggi" }], calc: v => v.a * v.t },
  trapezoid: { title: "Trapesium", formula: "½ × (a + b) × t", fields: [{ id: "a", label: "Sisi sejajar a" }, { id: "b", label: "Sisi sejajar b" }, { id: "t", label: "Tinggi" }], calc: v => 0.5 * (v.a + v.b) * v.t },
  rhombus: { title: "Belah ketupat", formula: "½ × d₁ × d₂", fields: [{ id: "d1", label: "Diagonal 1" }, { id: "d2", label: "Diagonal 2" }], calc: v => 0.5 * v.d1 * v.d2 },
  kite: { title: "Layang-layang", formula: "½ × d₁ × d₂", fields: [{ id: "d1", label: "Diagonal 1" }, { id: "d2", label: "Diagonal 2" }], calc: v => 0.5 * v.d1 * v.d2 }
};

let activeShape = null;
let toastTimer;

function showToast(message) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2300);
}

function formatNumber(value) {
  return new Intl.NumberFormat("id-ID", { maximumFractionDigits: 8 }).format(value);
}

function switchTab(tabName) {
  $$(".tab").forEach(btn => btn.classList.toggle("active", btn.dataset.tab === tabName));
  $("#geometryPanel").classList.toggle("hidden", tabName !== "geometry");
  $("#trigPanel").classList.toggle("hidden", tabName !== "trig");
  $("#historyPanel").classList.toggle("hidden", tabName !== "history");
  if (tabName === "history") loadHistory();
}

$$(".tab").forEach(btn => btn.addEventListener("click", () => switchTab(btn.dataset.tab)));

function selectShape(key) {
  activeShape = key;
  const shape = shapes[key];
  $("#shapeTitle").textContent = shape.title;
  $("#shapeFormula").textContent = shape.formula;
  $("#geometryResult").classList.add("hidden");
  $("#geometryFields").innerHTML = shape.fields.map(field => `
    <div class="field">
      <label for="field-${field.id}">${field.label}</label>
      <input id="field-${field.id}" name="${field.id}" type="number" min="0" step="any" inputmode="decimal" placeholder="Masukkan ${field.label.toLowerCase()}" required>
    </div>
  `).join("");
  $("#shapeScene").classList.add("hidden");
  $("#calculatorScene").classList.remove("hidden");
  window.scrollTo({ top: 0, behavior: "smooth" });
}

$$(".shape-card").forEach(card => card.addEventListener("click", () => selectShape(card.dataset.shape)));
$("#backToShapes").addEventListener("click", () => {
  $("#calculatorScene").classList.add("hidden");
  $("#shapeScene").classList.remove("hidden");
});

const HISTORY_KEY = "geocalc-history-v1";

function readLocalHistory() {
  try {
    const value = JSON.parse(localStorage.getItem(HISTORY_KEY) || "[]");
    return Array.isArray(value) ? value : [];
  } catch {
    return [];
  }
}

async function saveHistory(expression, result, category) {
  const history = readLocalHistory();
  const entry = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`,
    expression,
    result,
    category,
    createdAt: new Date().toISOString()
  };
  history.unshift(entry);
  localStorage.setItem(HISTORY_KEY, JSON.stringify(history.slice(0, 250)));
  // Read-after-write check: only report success if the browser stored the entry.
  const saved = readLocalHistory();
  if (!saved.some(item => item.id === entry.id)) {
    throw new Error("Browser tidak berhasil menyimpan riwayat. Periksa ruang penyimpanan.");
  }
  return entry;
}

$("#geometryForm").addEventListener("submit", async event => {
  event.preventDefault();
  if (!activeShape) return;
  const shape = shapes[activeShape];
  const values = {};
  for (const field of shape.fields) {
    const raw = $(`#field-${field.id}`).value;
    const value = Number(raw);
    if (raw.trim() === "" || !Number.isFinite(value) || value < 0) {
      showToast("Masukkan angka yang valid (minimal 0).");
      return;
    }
    values[field.id] = value;
  }
  const result = shape.calc(values);
  if (!Number.isFinite(result)) {
    showToast("Hasil tidak valid.");
    return;
  }
  const expression = `${shape.title}: ${shape.fields.map(f => `${f.label} ${formatNumber(values[f.id])}`).join(", ")}`;
  $("#geometryResult").innerHTML = `<div class="result-label">HASIL LUAS</div><div class="result-value">${formatNumber(result)} satuan²</div><div class="result-detail">${shape.formula}</div>`;
  $("#geometryResult").classList.remove("hidden");
  const submitButton = $("#geometryForm .primary-button");
  submitButton.disabled = true;
  try {
    await saveHistory(expression, `${formatNumber(result)} satuan²`, "Geometri");
    showToast("✓ Tersimpan di perangkat ini.");
  } catch (error) {
    console.error("GeoCalc history:", error);
    showToast(error.message);
  } finally {
    submitButton.disabled = false;
  }
});

$("#trigForm").addEventListener("submit", async event => {
  event.preventDefault();
  const raw = $("#angleInput").value;
  const angle = Number(raw);
  if (raw.trim() === "" || !Number.isFinite(angle)) {
    showToast("Masukkan sudut yang valid.");
    return;
  }
  const fn = $('input[name="trigFunction"]:checked').value;
  const unit = $("#angleUnit").value;
  const radians = unit === "deg" ? angle * Math.PI / 180 : angle;
  const cosValue = Math.cos(radians);
  if (fn === "tan" && Math.abs(cosValue) < 1e-12) {
    $("#trigResult").innerHTML = `<div class="result-label">HASIL TRIGONOMETRI</div><div class="result-value">Tidak terdefinisi</div><div class="result-detail">tan tidak terdefinisi ketika cos bernilai 0.</div>`;
    $("#trigResult").classList.remove("hidden");
    return;
  }
  const result = Math[fn](radians);
  const expression = `${fn}(${formatNumber(angle)}${unit === "deg" ? "°" : " rad"})`;
  $("#trigResult").innerHTML = `<div class="result-label">HASIL TRIGONOMETRI</div><div class="result-value">${formatNumber(result)}</div><div class="result-detail">${expression}</div>`;
  $("#trigResult").classList.remove("hidden");
  const submitButton = $("#trigForm .primary-button");
  submitButton.disabled = true;
  try {
    await saveHistory(expression, formatNumber(result), "Trigonometri");
    showToast("✓ Tersimpan di perangkat ini.");
  } catch (error) {
    console.error("GeoCalc history:", error);
    showToast(error.message);
  } finally {
    submitButton.disabled = false;
  }
});

async function loadHistory() {
  try {
    const items = readLocalHistory();
    $("#historyStatus").textContent = items.length
      ? `${items.length} catatan tersimpan di browser/perangkat ini.`
      : "Riwayat tersimpan otomatis di browser ini.";
    $("#emptyHistory").classList.toggle("hidden", items.length !== 0);
    $("#historyList").innerHTML = items.map(item => `
      <article class="history-item">
        <div class="history-main">
          <strong>${escapeHtml(item.expression)}</strong>
          <small>${escapeHtml(item.category)} · ${new Date(item.createdAt).toLocaleString("id-ID")}</small>
        </div>
        <div class="history-result">${escapeHtml(item.result)}</div>
        <button class="delete-button" type="button" data-delete="${escapeHtml(item.id)}" aria-label="Hapus riwayat">Hapus</button>
      </article>
    `).join("");
    $$("[data-delete]").forEach(button => button.addEventListener("click", () => deleteHistory(button.dataset.delete)));
  } catch (error) {
    $("#historyStatus").textContent = "Tidak bisa membaca penyimpanan browser. Coba aktifkan penyimpanan situs.";
    $("#historyList").innerHTML = "";
    $("#emptyHistory").classList.add("hidden");
  }
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[char]);
}

async function deleteHistory(id) {
  try {
    const updated = readLocalHistory().filter(item => item.id !== id);
    localStorage.setItem(HISTORY_KEY, JSON.stringify(updated));
    showToast("Riwayat dihapus.");
    loadHistory();
  } catch {
    showToast("Gagal menghapus riwayat browser.");
  }
}

$("#clearHistory").addEventListener("click", () => {
  if (!confirm("Hapus semua riwayat hitungan di browser ini?")) return;
  try {
    localStorage.setItem(HISTORY_KEY, "[]");
    showToast("Semua riwayat dihapus.");
    loadHistory();
  } catch {
    showToast("Gagal menghapus riwayat browser.");
  }
});

const savedTheme = localStorage.getItem("geocalc-theme");
if (savedTheme === "light") document.documentElement.classList.add("light");
$("#themeToggle").addEventListener("click", () => {
  document.documentElement.classList.toggle("light");
  localStorage.setItem("geocalc-theme", document.documentElement.classList.contains("light") ? "light" : "dark");
});

loadHistory();


// Exit: attempt to close the app window. Browsers may block closing tabs they did not open by script.
const exitDialog = $("#exitDialog");
$("#exitButton").addEventListener("click", () => {
  $("#exitFallback").classList.add("hidden");
  exitDialog.classList.remove("hidden");
});
$("#cancelExit").addEventListener("click", () => exitDialog.classList.add("hidden"));
$("#confirmExit").addEventListener("click", () => {
  // A completed calculation is awaited before its history-save promise resolves.
  // The server-side file store keeps session history after this window closes.
  window.close();
  setTimeout(() => {
    if (!document.hidden) {
      $("#exitFallback").classList.remove("hidden");
    }
  }, 250);
});
exitDialog.addEventListener("click", event => {
  if (event.target === exitDialog) exitDialog.classList.add("hidden");
});
