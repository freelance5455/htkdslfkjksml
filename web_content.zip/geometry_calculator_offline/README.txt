PINO OFFLINE — TANPA NPM / TANPA SERVER
==========================================

CARA MEMAKAI
1. Ekstrak ZIP.
2. Buka folder public.
3. Ketuk/klik index.html.
4. Aplikasi langsung berjalan di browser. Tidak perlu install Node.js,
   npm install, npm start, koneksi internet, atau server.

FITUR
- 8 kalkulator luas bangun datar.
- Sin, cos, tan dengan pilihan derajat dan radian.
- Riwayat hitungan otomatis tersimpan di localStorage browser.
- Hapus satu riwayat atau hapus semua.
- Tema gelap/terang.
- Layar kalkulator terpisah setelah memilih bangun.
- Tombol Keluar dengan konfirmasi.

TENTANG RIWAYAT
- Riwayat tetap ada setelah tab/browser ditutup dan dibuka lagi,
  selama data situs/browser tidak dihapus.
- Riwayat tersimpan pada browser dan perangkat yang sama.
- Riwayat tidak otomatis tersinkron ke perangkat atau browser lain.
- Mode private/incognito biasanya menghapus data saat sesi private ditutup.
- Jangan hapus data situs/browser jika ingin mempertahankan riwayat.

TENTANG TOMBOL KELUAR
Browser membatasi halaman web menutup tab yang dibuka manual. Tombol Keluar
akan mencoba menutup tab; jika diblokir, tutup tab secara manual.
Riwayat tetap tersimpan.

CATATAN
Versi ini sengaja memakai penyimpanan lokal browser agar benar-benar bisa
dibuka langsung tanpa npm atau server. Tidak menggunakan session server.
