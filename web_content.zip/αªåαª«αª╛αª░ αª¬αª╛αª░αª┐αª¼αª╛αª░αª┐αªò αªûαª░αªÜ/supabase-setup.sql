-- আমার পারিবারিক খরচ: Supabase schema + Row Level Security
-- Run this entire file in Supabase Dashboard > SQL Editor > New query.
-- Then follow README-বাংলা.txt to create the first admin membership.

create extension if not exists pgcrypto;

create table if not exists public.households (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.household_members (
  id uuid primary key default gen_random_uuid(),
  household_id uuid not null references public.households(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  display_name text not null,
  role text not null default 'member' check (role in ('admin','member')),
  created_at timestamptz not null default now(),
  unique (household_id, user_id)
);

create table if not exists public.expense_entries (
  id uuid primary key,
  household_id uuid not null references public.households(id) on delete cascade,
  created_by uuid not null references auth.users(id) on delete restrict,
  expense_date date not null,
  amount numeric(12,2) not null check (amount > 0),
  expense_type text not null check (expense_type in ('personal','family')),
  category text not null,
  note text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists expense_entries_household_date_idx
  on public.expense_entries(household_id, expense_date desc);
create index if not exists household_members_user_idx
  on public.household_members(user_id);

alter table public.households enable row level security;
alter table public.household_members enable row level security;
alter table public.expense_entries enable row level security;

-- SECURITY DEFINER helpers avoid recursive RLS checks on household_members.
create or replace function public.is_household_member(target_household uuid)
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.household_members m where m.household_id = target_household and m.user_id = auth.uid()) $$;

create or replace function public.is_household_admin(target_household uuid)
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.household_members m where m.household_id = target_household and m.user_id = auth.uid() and m.role = 'admin') $$;

revoke all on function public.is_household_member(uuid) from public;
revoke all on function public.is_household_admin(uuid) from public;
grant execute on function public.is_household_member(uuid) to authenticated;
grant execute on function public.is_household_admin(uuid) to authenticated;

-- Membership and role provisioning is done by the owner in Supabase Dashboard.
drop policy if exists "members can read own household" on public.households;
create policy "members can read own household" on public.households
for select to authenticated using (public.is_household_member(id));

drop policy if exists "members can read household roster" on public.household_members;
create policy "members can read household roster" on public.household_members
for select to authenticated using (public.is_household_member(household_id));

-- Every household member can see the shared family ledger.
drop policy if exists "household members read entries" on public.expense_entries;
create policy "household members read entries" on public.expense_entries
for select to authenticated using (public.is_household_member(household_id));

-- Members can create only entries under their own identity and household.
drop policy if exists "members insert own entries" on public.expense_entries;
create policy "members insert own entries" on public.expense_entries
for insert to authenticated with check (
  created_by = auth.uid() and public.is_household_member(household_id)
);

-- A member can edit/delete their own entries; an admin can edit/delete all household entries.
drop policy if exists "owner or admin update entries" on public.expense_entries;
create policy "owner or admin update entries" on public.expense_entries
for update to authenticated using (
  public.is_household_member(household_id) and (created_by = auth.uid() or public.is_household_admin(household_id))
) with check (
  public.is_household_member(household_id) and (created_by = auth.uid() or public.is_household_admin(household_id))
);

drop policy if exists "owner or admin delete entries" on public.expense_entries;
create policy "owner or admin delete entries" on public.expense_entries
for delete to authenticated using (
  public.is_household_member(household_id) and (created_by = auth.uid() or public.is_household_admin(household_id))
);

grant select on public.households, public.household_members to authenticated;
grant select, insert, update, delete on public.expense_entries to authenticated;
