import { createClient } from 'npm:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: { ...corsHeaders, 'Content-Type': 'application/json' },
});

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405);

  const url = Deno.env.get('SUPABASE_URL');
  const anonKey = Deno.env.get('SUPABASE_ANON_KEY');
  const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  if (!url || !anonKey || !serviceKey) return json({ error: 'Server secrets are not configured' }, 500);

  const authHeader = req.headers.get('Authorization') || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : '';
  if (!token) return json({ error: 'Missing login token' }, 401);

  const callerClient = createClient(url, anonKey, { auth: { persistSession: false, autoRefreshToken: false }, global: { headers: { Authorization: `Bearer ${token}` } } });
  const adminClient = createClient(url, serviceKey, { auth: { persistSession: false, autoRefreshToken: false } });

  const { data: callerData, error: callerError } = await callerClient.auth.getUser(token);
  if (callerError || !callerData.user) return json({ error: 'Invalid or expired login session' }, 401);

  const { data: memberships, error: membershipError } = await adminClient
    .from('household_members')
    .select('household_id,user_id,role')
    .eq('user_id', callerData.user.id)
    .eq('role', 'admin')
    .limit(1);
  if (membershipError || !memberships?.length) return json({ error: 'Admin permission required' }, 403);
  const householdId = memberships[0].household_id;

  let payload: Record<string, unknown>;
  try { payload = await req.json(); } catch { return json({ error: 'Invalid JSON body' }, 400); }
  const action = payload.action;

  if (action === 'list') {
    const { data: members, error } = await adminClient.from('household_members')
      .select('user_id,display_name,role').eq('household_id', householdId).order('created_at');
    if (error) return json({ error: error.message }, 400);
    const users = await Promise.all((members || []).map(async (m) => {
      const { data } = await adminClient.auth.admin.getUserById(m.user_id);
      return { ...m, email: data.user?.email || '' };
    }));
    return json({ users });
  }

  if (action === 'create') {
    const displayName = String(payload.display_name || '').trim();
    const email = String(payload.email || '').trim().toLowerCase();
    const password = String(payload.password || '');
    if (!displayName || !email || password.length < 8) return json({ error: 'নাম, সঠিক ইমেইল এবং কমপক্ষে ৮ অক্ষরের পাসওয়ার্ড দিন' }, 400);

    const { count, error: countError } = await adminClient.from('household_members')
      .select('*', { count: 'exact', head: true }).eq('household_id', householdId);
    if (countError) return json({ error: countError.message }, 400);
    if ((count || 0) >= 5) return json({ error: 'একটি পরিবারে Admin-সহ সর্বোচ্চ ৫টি অ্যাকাউন্ট রাখা যাবে' }, 409);

    const { data: created, error: createError } = await adminClient.auth.admin.createUser({ email, password, email_confirm: true });
    if (createError || !created.user) return json({ error: createError?.message || 'অ্যাকাউন্ট তৈরি হয়নি' }, 400);

    const { error: insertError } = await adminClient.from('household_members').insert({
      household_id: householdId, user_id: created.user.id, display_name: displayName, role: 'member',
    });
    if (insertError) {
      await adminClient.auth.admin.deleteUser(created.user.id);
      return json({ error: insertError.message }, 400);
    }
    return json({ ok: true, user_id: created.user.id });
  }

  if (action === 'update') {
    const userId = String(payload.user_id || '');
    const displayName = String(payload.display_name || '').trim();
    const email = String(payload.email || '').trim().toLowerCase();
    const password = typeof payload.password === 'string' ? payload.password : '';
    if (!userId || !displayName || !email) return json({ error: 'সদস্য, নাম ও ইমেইল প্রয়োজন' }, 400);

    const { data: target, error: targetError } = await adminClient.from('household_members')
      .select('user_id,role').eq('household_id', householdId).eq('user_id', userId).maybeSingle();
    if (targetError || !target) return json({ error: 'এই পরিবারের সদস্য পাওয়া যায়নি' }, 404);
    if (target.role !== 'member') return json({ error: 'Admin অ্যাকাউন্ট এই ফর্ম থেকে পরিবর্তন করা যাবে না' }, 403);
    if (password && password.length < 8) return json({ error: 'পাসওয়ার্ড কমপক্ষে ৮ অক্ষরের হতে হবে' }, 400);

    const authUpdate: { email: string; password?: string; email_confirm: boolean } = { email, email_confirm: true };
    if (password) authUpdate.password = password;
    const { error: authUpdateError } = await adminClient.auth.admin.updateUserById(userId, authUpdate);
    if (authUpdateError) return json({ error: authUpdateError.message }, 400);

    const { error: profileError } = await adminClient.from('household_members')
      .update({ display_name: displayName }).eq('household_id', householdId).eq('user_id', userId);
    if (profileError) return json({ error: profileError.message }, 400);
    return json({ ok: true });
  }

  return json({ error: 'Unknown action' }, 400);
});
