// Public client configuration. Publishable keys are intended for client apps.
// Never place a service_role or secret key in this file.
window.SUPABASE_CONFIG = {
  url: 'https://vrgsapcwpkxvucrcklxe.supabase.co',
  publishableKey: 'sb_publishable_bEw8zKGTWjsE-V0XOqVCKQ_HlSB9r39'
};
