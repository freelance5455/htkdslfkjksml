আমার পারিবারিক খরচ — Supabase Login & Admin সংস্করণ 2.2
=======================================================

এই অ্যাপ ব্যবহারকারীদের Supabase Dashboard-এ যেতে হবে না। পরিবারের সদস্যরা শুধু অ্যাপের Login Screen দেখবেন। Supabase হলো অ্যাপের পেছনের সার্ভার।

অ্যাপের ভিতরে
-------------
- ১টি Admin এবং সর্বোচ্চ ৪টি Member অ্যাকাউন্টের জন্য নকশা করা।
- Admin অ্যাপের ভিতর থেকে Member তৈরি করতে পারবেন; সদস্যের নাম, ইমেইল এবং পাসওয়ার্ড পরিবর্তন করতে পারবেন।
- Member কেবল হিসাব যোগ করবেন এবং নিজের হিসাব সম্পাদনা/মুছবেন। Admin পরিবারের সব হিসাব পরিচালনা করবেন।
- Offline queue এবং অনলাইন হলে sync।
- নতুন ফোনে একই অ্যাকাউন্টে লগইন করলে আগে cloud-এ sync হওয়া ডেটা ফেরত আসবে।

একবারের সার্ভার সেটআপ (অ্যাপ ব্যবহারকারীদের জন্য নয়)
--------------------------------------------------
1. Supabase Dashboard > SQL Editor-এ supabase-setup.sql চালান।
2. Authentication > Users থেকে প্রথম Admin account তৈরি করুন।
3. SQL Editor-এ চালান (ADMIN_EMAIL বদলাবেন):
   with h as (insert into public.households(name) values ('আমার পরিবার') returning id),
   u as (select id from auth.users where email='ADMIN_EMAIL')
   insert into public.household_members(household_id,user_id,display_name,role)
   select h.id,u.id,'পরিবারের Admin','admin' from h cross join u;
4. ZIP-এর `supabase/functions/admin-users/index.ts` হলো Admin Edge Function-এর কোড। Supabase CLI ব্যবহার করে `supabase functions deploy admin-users` চালান; Dashboard-এর Function Editor ব্যবহার করলে একই কোড `admin-users` নামে deploy করুন।
5. Function Secrets-এ SUPABASE_URL, SUPABASE_ANON_KEY, SUPABASE_SERVICE_ROLE_KEY সেট করুন। `verify_jwt = false` থাকলেও Function নিজে Authorization Bearer token যাচাই করে এবং Admin role নিশ্চিত করে। Service role key কেবল Supabase Function secret-এ থাকবে; কখনো www ফোল্ডার, APK বা ফোনে রাখবেন না।
6. Dashboard-এ public sign-up বন্ধ রাখুন। Admin অ্যাপের ভিতর থেকে বাকি Member অ্যাকাউন্ট তৈরি করবেন।

নিরাপত্তা
---------
- Admin API Edge Function-এ caller session যাচাই করে household_members.role='admin' নিশ্চিত করা হয়।
- Service role key শুধু সার্ভার-সাইড Edge Function secret-এ ব্যবহৃত হয়।
- Database Row Level Security (RLS) অবশ্যই চালু রাখতে হবে।
- Publishable key ক্লায়েন্ট অ্যাপে থাকা স্বাভাবিক; এটি একা ডেটাবেসে প্রবেশাধিকার দেয় না, RLS-ই অনুমতি নিয়ন্ত্রণ করে।

গুরুত্বপূর্ণ সীমাবদ্ধতা
---------------------
- Cloud restore কেবল আগে sync হওয়া রেকর্ড ফেরায়। ফোনে থাকা unsynced offline entry অ্যাপ মুছে গেলে হারাতে পারে।
- একসঙ্গে একই রেকর্ড একাধিক ফোনে edit করলে conflict হতে পারে।
- এটি source project, APK নয়। Build ও বাস্তব ডিভাইসে পরীক্ষা আবশ্যক।
- প্রথম Admin account তৈরি ও household-এ যুক্ত করার একবারের কাজটি Dashboard-এ করতে হবে। এরপর সাধারণ সদস্যদের Dashboard লাগবে না।

APK Build
---------
GitHub Actions workflow .github/workflows/android-apk.yml আছে। GitHub-এ project push করে workflow চালিয়ে APK artifact তৈরি করতে হবে।
