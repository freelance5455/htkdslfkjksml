# Everday — Personal Life OS

A private, tablet-friendly personal tracker for routines, habits, physical and mental wellbeing, money/assets, goals, and future plans. Includes a lightweight Android WebView wrapper project.

## Included features
- Daily dashboard and habit check-ins
- Custom habits with time-of-day and optional goal link
- Health logs: sleep, movement, water, weight, nutrition, mood, stress, energy, mindfulness, journal note
- Finance ledger: cash, savings, investments, property, vehicles, debts, income, expenses, savings entries
- Net worth summary (assets minus liabilities)
- Custom goals with time horizon, deadline, measurement, progress, status, and supporting systems
- Future plans with milestones and linked goals
- Weekly reflection, life-balance snapshot, export/import JSON backup
- Local-only storage; no account or bank integration

## Run immediately in a browser
Open `index.html`. Best for day-to-day use: use Chrome on Android and choose **Add to Home screen**. The app stores data in that browser's local storage. Export a backup periodically in Settings.

## Build an Android APK
The Android wrapper source is in `android/`. To build the APK, install Android Studio with Android SDK Platform 35 and JDK 17 or newer, open the `android` folder as a project, allow Gradle sync, then select **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The debug APK will be under `android/app/build/outputs/apk/debug/app-debug.apk`.

This workspace did not have the Android SDK, Gradle, or Android build tools installed, so an APK could not be compiled and verified here. The Android wrapper source is provided instead of a fake or non-installable APK. No network permission is included in the Android app; app data stays on the device. Android WebView local storage is used for persistence.

## Data & privacy
- App records are stored locally in browser/WebView storage.
- Use **Settings → Export backup** to save a JSON backup. Keep it private because it may contain personal health and financial information.
- Import a backup on the same device or another browser instance using Settings.
- Clearing app/browser data can erase records.
- Financial balances are manual records; no account connection, market price feed, trading, or investment advice is included.
