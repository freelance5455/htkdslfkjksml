# Everday — Personal Life OS

A private, tablet-friendly personal tracker for routines, habits, physical and mental wellbeing, money/assets, goals, and future plans. Includes a lightweight Android WebView wrapper project.

## Included features
- Daily dashboard and habit check-ins
- Custom habits with time-of-day and optional goal link
- Health logs: sleep, movement, water, weight, nutrition, mood, stress, energy, mindfulness, journal note
- Finance ledger: cash, savings, investments, property, vehicles, debts, income, expenses, savings entries
- Net worth summary (assets minus liabilities)
- Custom goals with time horizon, deadline, measurement, progress, status, and supporting systems
- Planning calendar inside the Goals tab, with month navigation, dated tasks/appointments/deadlines, optional time and notes, and optional links to goals
- Future plans with milestones and linked goals
- Weekly reflection, life-balance snapshot, export/import JSON backup
- Local-only storage; no account or bank integration

## Run immediately in a browser
Open `index.html`. Best for day-to-day use: use Chrome on Android and choose **Add to Home screen**. The app stores data in that browser's local storage. Export a backup periodically in Settings.

## Android installation status
This package contains the updated web app source. A compiled Android APK has not been built or verified, so do not treat this HTML file as an APK. For installation as a normal Android app, the web app needs to be served from a secure web origin for browser installation, or packaged and built as an Android app.

## Data & privacy
- App records are stored locally in browser/WebView storage.
- Use **Settings → Export backup** to save a JSON backup. Keep it private because it may contain personal health and financial information.
- Import a backup on the same device or another browser instance using Settings.
- Clearing app/browser data can erase records.
- Financial balances are manual records; no account connection, market price feed, trading, or investment advice is included.
