# Everday — Personal Life OS

## Open the app
Open `index.html` in a modern browser. Everday is a local-first web app prototype; it is not a compiled Android APK.

## Goal gallery and attachments
- Each goal has a **Gallery & files** section.
- Select multiple photos or documents from the device's file picker.
- Image thumbnails, filenames, dates and optional captions are shown on the goal card.
- Use **Open** to view a local attachment, or **×** to delete it from this device after confirmation.
- Attachments are stored in the browser's IndexedDB database on the device. Everday does not upload them to a server or sync them to the cloud.
- Browser/site data clearing, uninstalling/resetting the browser, or using a different browser/profile may remove or make the files unavailable. Back up important files separately. The regular JSON backup does not include the attachment binary files yet.

## Habit challenges
- New habits default to a 30-day challenge.
- Set the challenge length to another number of calendar days, or set it to `0` for an ongoing habit.
- Choose a start date. Challenge progress counts the days marked complete during the challenge period.
- After the challenge end date, the habit moves to **Finished challenges** and no longer appears in the active daily checklist.
- Use **Delete** to remove a habit and its completion history. Deletion asks for confirmation and cannot be undone.
- Editing a habit preserves its existing completion history.

## Privacy and backup
App data is stored locally in the browser on this device. Goal attachment metadata is in browser local storage, and attachment file contents are in IndexedDB. There is no cloud upload or account sync. Use the in-app Backup export for ordinary app records; copy important goal photos/documents separately because attachment binaries are not included in the JSON backup yet.

## Limitations
Opening a local HTML file is not the same as installing a native Android app. An APK has not been built as part of this package. Browser support for persistent local file storage can vary, particularly when opening an HTML file directly from a file manager; if attachment saving fails, open it in Chrome and make sure browser storage is not blocked.
