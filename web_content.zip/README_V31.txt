ADI X DATA V31
Withdrawal search by name, mobile, email, UID, status, method and amount.

V31 UPGRADE NOTE
- Uses the complete current Admin app.js controls.
- Telegram destination is stored at settings/telegramDestination.
- A legacy /telegramLink mirror is maintained on save/reset for older User builds.
- Telegram inputs accept https://t.me/username, t.me/username, @username, or a username.
