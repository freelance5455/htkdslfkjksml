// Billeder gemmes separat fra tekst i browserens IndexedDB.
const photoDB = new Promise((resolve,reject)=>{
  const request=indexedDB.open('tlv-service-photos-v1',1);
  request.onupgradeneeded=()=>request.result.createObjectStore('photos',{keyPath:'id'});
  request.onsuccess=()=>resolve(request.result);
  request.onerror=()=>reject(request.error);
});
function photoKey(i){return 'photo:'+plant+':'+week.value+':'+i}
async function photoAction(mode,id,record){
  const db=await photoDB;
  return new Promise((resolve,reject)=>{
    const tx=db.transaction('photos',mode);
    const store=tx.objectStore('photos');
    const req=mode==='readonly'?store.get(id):record?store.put(record):store.delete(id);
    req.onsuccess=()=>resolve(req.result);
    req.onerror=()=>reject(req.error);
  });
}
function addPhotoUI(card,i){
 const wrap=document.createElement('div');wrap.className='photoArea';
 const actions=document.createElement('div');actions.className='photoActions';
 const camera=document.createElement('input');camera.type='file';camera.accept='image/*';camera.setAttribute('capture','environment');camera.hidden=true;
 const gallery=document.createElement('input');gallery.type='file';gallery.accept='image/*';gallery.hidden=true;
 const cameraBtn=document.createElement('button');cameraBtn.type='button';cameraBtn.textContent='📷 Tag foto';cameraBtn.onclick=()=>camera.click();
 const galleryBtn=document.createElement('button');galleryBtn.type='button';galleryBtn.textContent='🖼️ Vælg billede';galleryBtn.onclick=()=>gallery.click();
 const preview=document.createElement('div');preview.className='photoPreview';
 actions.append(cameraBtn,galleryBtn,camera,gallery);wrap.append(actions,preview);card.append(wrap);
 let url=null;
 async function refresh(){
  if(url){URL.revokeObjectURL(url);url=null}
  preview.replaceChildren();
  try{
   const record=await photoAction('readonly',photoKey(i));
   if(!record)return;
   url=URL.createObjectURL(record.blob);
   const img=document.createElement('img');img.src=url;img.alt='Foto til kontrolpunkt '+(i+1);
   const del=document.createElement('button');del.type='button';del.textContent='🗑 Fjern foto';
   del.onclick=async()=>{if(!confirm('Fjern foto fra dette kontrolpunkt?'))return;await photoAction('readwrite',photoKey(i));refresh()};
   preview.append(img,del);
  }catch(e){preview.textContent='Billedlager er ikke tilgængeligt i denne browser.'}
 }
 async function store(input){
  const file=input.files?.[0];if(!file)return;
  try{
   const bitmap=await createImageBitmap(file);
   const scale=Math.min(1,1400/Math.max(bitmap.width,bitmap.height));
   const canvas=document.createElement('canvas');canvas.width=Math.round(bitmap.width*scale);canvas.height=Math.round(bitmap.height*scale);
   canvas.getContext('2d').drawImage(bitmap,0,0,canvas.width,canvas.height);bitmap.close();
   const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/jpeg',.78));
   if(!blob)throw new Error('Kunne ikke behandle billedet');
   await photoAction('readwrite',photoKey(i),{id:photoKey(i),blob,date:new Date().toISOString()});
   refresh();
  }catch(e){alert('Billedet kunne ikke gemmes: '+e.message)}
  input.value='';
 }
 camera.onchange=()=>store(camera);gallery.onchange=()=>store(gallery);
 refresh();
}
