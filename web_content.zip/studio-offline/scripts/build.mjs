// Bundles the app into ONE self-contained dist/index.html (classic inline script, no
// external files) so it also loads from file:// and Android WebViews.
import { build } from 'esbuild';
import { mkdirSync, writeFileSync, cpSync, rmSync } from 'node:fs';

const out = await build({
  entryPoints: ['src/main.tsx'], bundle: true, write: false, minify: true, outdir: 'out',
  format: 'iife', target: 'es2019', jsx: 'automatic', loader: { '.woff2': 'dataurl' },
  define: { 'process.env.NODE_ENV': '"production"' },
});
const file = (ext) => out.outputFiles.find((f) => f.path.endsWith(ext)).text;
rmSync('dist', { recursive: true, force: true });
mkdirSync('dist');
cpSync('public', 'dist', { recursive: true });
writeFileSync('dist/index.html', `<!doctype html><html lang="en"><head><meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover" />
<meta name="theme-color" content="#14030f" /><title>Studio</title>
<style>${file('.css')}</style></head><body><div id="root"></div>
<script>${file('.js').replace(/<\/script/g, '<\\/script')}</script></body></html>`);
