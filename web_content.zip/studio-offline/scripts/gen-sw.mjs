// Generates dist/sw.js after every build, precaching the whole app so it keeps
// working with the network switched off.
import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';

const dist = path.resolve('dist');

async function walk(dir, base = '') {
  const entries = await fs.readdir(dir, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    const rel = path.posix.join(base, entry.name);
    if (entry.isDirectory()) files.push(...(await walk(path.join(dir, entry.name), rel)));
    else files.push(rel);
  }
  return files;
}

const files = (await walk(dist)).filter((file) => file !== 'sw.js');
const assets = ['./', ...files.map((file) => `./${file}`)];
const version = createHash('sha256')
  .update(files.map((file) => `${file}:${file.length}`).join('|'))
  .digest('hex')
  .slice(0, 10);

const worker = `/* Auto-generated. Precache-first service worker for offline use. */
const CACHE = 'studio-${version}';
const ASSETS = ${JSON.stringify(assets)};

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches
      .open(CACHE)
      .then((cache) => cache.addAll(ASSETS))
      .then(() => self.skipWaiting())
      .catch((error) => console.warn('Precache failed', error)),
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((key) => key !== CACHE).map((key) => caches.delete(key))))
      .then(() => self.clients.claim()),
  );
});

self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .then((response) => {
          const copy = response.clone();
          caches.open(CACHE).then((cache) => cache.put('./index.html', copy));
          return response;
        })
        .catch(() => caches.match('./index.html').then((hit) => hit || caches.match('./'))),
    );
    return;
  }

  event.respondWith(
    caches.match(request).then((hit) => {
      if (hit) return hit;
      return fetch(request).then((response) => {
        if (response.ok) {
          const copy = response.clone();
          caches.open(CACHE).then((cache) => cache.put(request, copy));
        }
        return response;
      });
    }),
  );
});
`;

await fs.writeFile(path.join(dist, 'sw.js'), worker);
console.log(`Service worker written with ${assets.length} precached entries (cache studio-${version}).`);
