# Studio — offline design editor

A Canva-style design studio that runs entirely on your own device: posters, social posts,
stories and decks, with templates built around three mood palettes (Club Pink, Court Navy,
Studio Maroon). No accounts, no cloud, no network calls — fonts and icons are bundled, projects
are stored in the browser's local database.

## Run it

```bash
npm install
npm run build
npm start
```

Open http://localhost:4173. That is the whole app; you can switch off Wi-Fi and keep working.

For development with hot reload:

```bash
npm run dev
```

## Use it somewhere with no internet

- **On your laptop:** run `npm start` once and leave the little server running. Everything,
  including saved designs, stays on the machine.
- **Install it as an app:** open the URL in Chrome or Edge and choose "Install app". The service
  worker caches the entire studio, so it opens without a connection after the first load.
- **Carry it on a stick:** copy the repo (or at least `dist/` plus `scripts/serve.mjs`) and run
  `npm start` on any machine with Node. `dist/` is fully self-contained and relative-path safe.

## What you can do

- Start blank at a common size or from one of nine templates.
- Add text (five typefaces), shapes, sticker marks and your own images.
- Drag, resize, rotate, snap to the page centre and edges, reorder, lock and duplicate.
- Set solid colours, gradients and grid/dot backgrounds from the mood palettes.
- Multiple pages per design.
- Export PNG, JPG or WebP at 1×–3×, with optional transparency; also save a `.studio.json`
  project file and import it later.
- Everything autosaves to IndexedDB in this browser. Use the project file for backups.

## Layout of the project

```
src/
  components/   home, editor shell, canvas stage, panels, inspector, export dialog
  data/         templates and sticker icon paths
  lib/          canvas renderer/exporter, IndexedDB, fonts, factories, history hook
  fonts/        locally bundled woff2 files (generated once by scripts/fonts.mjs)
scripts/        font downloader, service-worker generator, static server
```

## Rebuilding the offline cache

`npm run build` regenerates `dist/sw.js` after each build, precaching every hashed asset with a
new cache name. Reload the page twice after deploying a new build so the worker updates.
