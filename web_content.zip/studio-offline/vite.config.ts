import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Relative base so the built app can be served from any folder, including a
// USB stick or a plain static host, without rewriting asset paths.
const previewHost = process.env.STUDIO_ALLOWED_HOST;

export default defineConfig({
  base: './',
  plugins: [react()],
  // A single host may be passed in at launch (for cloud previews). Nothing is
  // hard-coded, and local/LAN development stays on the defaults.
  server: previewHost ? { allowedHosts: [previewHost] } : undefined,
  preview: previewHost ? { allowedHosts: [previewHost] } : undefined,
  build: {
    target: 'es2020',
    assetsInlineLimit: 2048,
  },
});
