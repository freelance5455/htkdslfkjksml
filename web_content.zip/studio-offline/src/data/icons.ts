export type IconDef = {
  id: string;
  name: string;
  d: string;
  vb: number;
  mode: 'fill' | 'stroke';
  stroke?: number;
};

// All icons are single-path so the same definition renders in the DOM editor and
// in the canvas exporter.
export const ICONS: IconDef[] = [
  {
    id: 'sparkle',
    name: 'Sparkle',
    d: 'M50 2 61 39 98 50 61 61 50 98 39 61 2 50 39 39Z',
    vb: 100,
    mode: 'fill',
  },
  {
    id: 'star',
    name: 'Star',
    d: 'M50 3 61.8 35.7 96.5 36.5 69 57.8 79 91.5 50 71.5 21 91.5 31 57.8 3.5 36.5 38.2 35.7Z',
    vb: 100,
    mode: 'fill',
  },
  {
    id: 'heart',
    name: 'Heart',
    d: 'M50 91C20 70 6 53 6 34 6 20 17 9 31 9c8 0 15 4 19 10 4-6 11-10 19-10 14 0 25 11 25 25 0 19-14 36-44 57Z',
    vb: 100,
    mode: 'fill',
  },
  {
    id: 'blob',
    name: 'Blob',
    d: 'M82 28c9 15 11 33 1 45S53 91 37 88 7 70 5 52s8-32 24-38 44-1 53 14Z',
    vb: 100,
    mode: 'fill',
  },
  {
    id: 'bolt',
    name: 'Bolt',
    d: 'M57 3 17 57h25l-9 40 44-56H52Z',
    vb: 100,
    mode: 'fill',
  },
  {
    id: 'asterisk',
    name: 'Asterisk',
    d: 'M44 4h12v32l24-14 6 11-24 14 24 14-6 11-24-14v32H44V58L20 72l-6-11 24-14-24-14 6-11 24 14Z',
    vb: 100,
    mode: 'fill',
  },
  {
    id: 'bubble',
    name: 'Speech',
    d: 'M8 10h84v58H46L24 92V68H8Z',
    vb: 100,
    mode: 'fill',
  },
  {
    id: 'flower',
    name: 'Flower',
    d: 'M50 4c11 0 18 9 18 19 9-5 21-2 25 8s-2 20-11 24c9 4 15 14 11 24s-16 13-25 8c0 10-7 19-18 19s-18-9-18-19c-9 5-21 2-25-8s2-20 11-24c-9-4-15-14-11-24s16-13 25-8c0-10 7-19 18-19Z',
    vb: 100,
    mode: 'fill',
  },
  {
    id: 'arrow',
    name: 'Arrow',
    d: 'M6 18c0-8 7-13 15-13 19 0 33 8 43 24M64 5l26 25-38 5',
    vb: 100,
    mode: 'stroke',
    stroke: 9,
  },
  {
    id: 'squiggle',
    name: 'Squiggle',
    d: 'M5 62c14-38 26-38 40 0s26 38 40 0',
    vb: 100,
    mode: 'stroke',
    stroke: 11,
  },
  {
    id: 'underline',
    name: 'Underline',
    d: 'M5 78c22-52 58-52 90 0',
    vb: 100,
    mode: 'stroke',
    stroke: 10,
  },
  {
    id: 'circle-arrow',
    name: 'Badge arrow',
    d: 'M50 5a45 45 0 1 0 0 90 45 45 0 0 0 0-90ZM32 58c8-14 18-20 30-19M52 27l16 12-16 12',
    vb: 100,
    mode: 'stroke',
    stroke: 6,
  },
  {
    id: 'sun',
    name: 'Sun',
    d: 'M50 28a22 22 0 1 0 0 44 22 22 0 0 0 0-44ZM50 4v12M50 84v12M4 50h12M84 50h12M17 17l9 9M74 74l9 9M83 17l-9 9M26 74l-9 9',
    vb: 100,
    mode: 'stroke',
    stroke: 7,
  },
  {
    id: 'check',
    name: 'Check',
    d: 'M12 52l24 24L88 16',
    vb: 100,
    mode: 'stroke',
    stroke: 12,
  },
  {
    id: 'smile',
    name: 'Smile',
    d: 'M50 6a44 44 0 1 0 0 88 44 44 0 0 0 0-88ZM32 40v6M68 40v6M30 62c5 9 12 13 20 13s15-4 20-13',
    vb: 100,
    mode: 'stroke',
    stroke: 7,
  },
];

export const ICON_MAP: Record<string, IconDef> = Object.fromEntries(
  ICONS.map((icon) => [icon.id, icon]),
);
