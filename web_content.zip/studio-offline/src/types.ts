export type MoodId = 'club' | 'court' | 'studio';

export type FontId = 'display' | 'sans' | 'grotesk' | 'serif' | 'mono';

export type ShapeId =
  | 'rect'
  | 'pill'
  | 'ellipse'
  | 'triangle'
  | 'diamond'
  | 'star'
  | 'line'
  | 'arrow'
  | 'blob';

export type Pattern = 'none' | 'grid' | 'dots';

export type Background = {
  color: string;
  gradient: { from: string; to: string; angle: number } | null;
  pattern: Pattern;
};

export type BaseElement = {
  id: string;
  x: number;
  y: number;
  w: number;
  h: number;
  rotation: number;
  opacity: number;
  locked?: boolean;
};

export type TextElement = BaseElement & {
  type: 'text';
  text: string;
  font: FontId;
  size: number;
  weight: number;
  italic?: boolean;
  lineHeight: number;
  letterSpacing: number;
  color: string;
  align: 'left' | 'center' | 'right';
  uppercase?: boolean;
};

export type ShapeElement = BaseElement & {
  type: 'shape';
  shape: ShapeId;
  fill: string;
  radius: number;
  strokeWidth: number;
};

export type ImageElement = BaseElement & {
  type: 'image';
  src: string;
  fit: 'cover' | 'contain';
  radius: number;
};

export type StickerElement = BaseElement & {
  type: 'sticker';
  icon: string;
  color: string;
  strokeWidth: number;
};

export type DesignElement = TextElement | ShapeElement | ImageElement | StickerElement;

export type Page = {
  id: string;
  background: Background;
  elements: DesignElement[];
};

export type Design = {
  id: string;
  name: string;
  width: number;
  height: number;
  pages: Page[];
  mood: MoodId;
  createdAt: number;
  updatedAt: number;
  thumb?: string;
};

export type PageSize = { id: string; name: string; width: number; height: number; group: string };

export const PAGE_SIZES: PageSize[] = [
  { id: 'ig-post', name: 'Instagram Post', width: 1080, height: 1080, group: 'Social' },
  { id: 'ig-portrait', name: 'Instagram Portrait', width: 1080, height: 1350, group: 'Social' },
  { id: 'story', name: 'Story / Reel', width: 1080, height: 1920, group: 'Social' },
  { id: 'wide', name: 'Facebook / LinkedIn', width: 1200, height: 628, group: 'Social' },
  { id: 'deck', name: 'Presentation 16:9', width: 1920, height: 1080, group: 'Work' },
  { id: 'a4', name: 'Poster A4', width: 1240, height: 1754, group: 'Print' },
  { id: 'letter', name: 'Poster Letter', width: 1275, height: 1650, group: 'Print' },
  { id: 'card', name: 'Business Card', width: 1050, height: 600, group: 'Print' },
];

export const uid = (prefix = 'el') =>
  `${prefix}_${Math.random().toString(36).slice(2, 9)}${Date.now().toString(36).slice(-3)}`;

export const clone = <T,>(value: T): T => JSON.parse(JSON.stringify(value)) as T;

export function elementLabel(element: DesignElement): string {
  if (element.type === 'text') {
    const text = element.text.replace(/\s+/g, ' ').trim();
    return text ? text.slice(0, 28) : 'Text';
  }
  if (element.type === 'shape') return element.shape[0].toUpperCase() + element.shape.slice(1);
  if (element.type === 'image') return 'Image';
  return 'Sticker';
}

export function pageLuminance(background: Background): number {
  const hex = background.gradient ? background.gradient.from : background.color;
  const clean = hex.replace('#', '');
  const full = clean.length === 3 ? clean.split('').map((c) => c + c).join('') : clean;
  const r = parseInt(full.slice(0, 2), 16) / 255;
  const g = parseInt(full.slice(2, 4), 16) / 255;
  const b = parseInt(full.slice(4, 6), 16) / 255;
  const lin = (v: number) => (v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4);
  return 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b);
}

export const readableInk = (background: Background) =>
  pageLuminance(background) > 0.45 ? '#14030f' : '#fefdfe';
