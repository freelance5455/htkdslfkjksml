import type { MoodId } from './types';

export type Swatch = { name: string; hex: string };

export type Mood = {
  id: MoodId;
  name: string;
  subtitle: string;
  swatches: Swatch[];
};

export const MOODS: Mood[] = [
  {
    id: 'club',
    name: 'Club Pink',
    subtitle: 'Raspberry, mellow white, pastel turquoise',
    swatches: [
      { name: 'Raspberry Pink', hex: '#D13CD3' },
      { name: 'Mellow White', hex: '#FEFDFE' },
      { name: 'Pastel Turquoise', hex: '#C7FCD2' },
      { name: 'Ink', hex: '#14030F' },
      { name: 'Soft Blush', hex: '#F6D9F6' },
    ],
  },
  {
    id: 'court',
    name: 'Court Navy',
    subtitle: 'Azure navy, snowy white, coral red',
    swatches: [
      { name: 'Azure Navy', hex: '#3283BE' },
      { name: 'Snowy White', hex: '#FEFDFE' },
      { name: 'Coral Red', hex: '#FD614B' },
      { name: 'Deep Court', hex: '#0B2C46' },
      { name: 'Sky Wash', hex: '#D6EAF7' },
    ],
  },
  {
    id: 'studio',
    name: 'Studio Maroon',
    subtitle: 'Deep maroon, tomato red, neon yellow',
    swatches: [
      { name: 'Deep Maroon', hex: '#250104' },
      { name: 'Tomato Red', hex: '#D71A0B' },
      { name: 'Neon Yellow', hex: '#CDF73D' },
      { name: 'Snowy White', hex: '#FEFDFE' },
      { name: 'Ember', hex: '#7A0A05' },
    ],
  },
];

export const moodById = (id: MoodId): Mood => MOODS.find((mood) => mood.id === id) ?? MOODS[0];

export const DEFAULT_SWATCHES: Swatch[] = [
  ...MOODS[0].swatches,
  ...MOODS[1].swatches,
  ...MOODS[2].swatches,
  { name: 'White', hex: '#FFFFFF' },
  { name: 'Black', hex: '#0A0A0A' },
  { name: 'Grey', hex: '#8A8A8A' },
  { name: 'Mint', hex: '#8CF0C3' },
  { name: 'Lilac', hex: '#BBA7FF' },
];

export const uniqueSwatches = (): Swatch[] => {
  const seen = new Set<string>();
  return DEFAULT_SWATCHES.filter((swatch) => {
    if (seen.has(swatch.hex)) return false;
    seen.add(swatch.hex);
    return true;
  });
};
