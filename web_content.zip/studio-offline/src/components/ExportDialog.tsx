import { useEffect, useState } from 'react';
import type { Design, Page } from '../types';
import { exportPage, exportProject } from '../lib/export';
import type { ExportFormat } from '../lib/export';
import { Segmented } from './controls';

export function ExportDialog({
  design,
  page,
  pageNumber,
  onClose,
}: {
  design: Design;
  page: Page;
  pageNumber: number;
  onClose: () => void;
}) {
  const [format, setFormat] = useState<ExportFormat>('png');
  const [scale, setScale] = useState(2);
  const [transparent, setTransparent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  const run = async () => {
    setBusy(true);
    setError(null);
    setDone(false);
    try {
      await exportPage(design, page, {
        scale,
        format,
        transparent: transparent && format !== 'jpeg',
      });
      setDone(true);
    } catch (exportError) {
      setError(exportError instanceof Error ? exportError.message : 'Export failed');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="modal-backdrop" onPointerDown={(event) => {
      if (event.target === event.currentTarget) onClose();
    }}>
      <div className="modal" role="dialog" aria-modal="true" aria-label="Export design">
        <div className="modal-head">
          <div>
            <span className="eyebrow">Export</span>
            <h2>Make it a file</h2>
          </div>
          <button type="button" className="icon-btn" onClick={onClose} aria-label="Close">
            ×
          </button>
        </div>

        <div className="modal-body">
          <div className="option-block">
            <span className="control-label">Format</span>
            <Segmented
              ariaLabel="Export format"
              value={format}
              options={[
                { value: 'png', label: 'PNG' },
                { value: 'jpeg', label: 'JPG' },
                { value: 'webp', label: 'WebP' },
              ]}
              onChange={(value) => {
                setFormat(value);
                if (value === 'jpeg') setTransparent(false);
              }}
            />
          </div>

          <div className="option-block">
            <span className="control-label">Size</span>
            <Segmented
              ariaLabel="Export size"
              value={String(scale)}
              options={[
                { value: '1', label: '1×' },
                { value: '2', label: '2×' },
                { value: '3', label: '3×' },
              ]}
              onChange={(value) => setScale(Number(value))}
            />
            <p className="modal-note">
              {design.width * scale} × {design.height * scale} px · page {pageNumber} of{' '}
              {design.pages.length}
            </p>
          </div>

          <label className="checkbox-row">
            <input
              type="checkbox"
              checked={transparent}
              disabled={format === 'jpeg'}
              onChange={(event) => setTransparent(event.target.checked)}
            />
            <span>Transparent background (PNG / WebP)</span>
          </label>

          {error ? <p className="panel-error">{error}</p> : null}
          {done ? <p className="panel-success">Saved to your downloads.</p> : null}

          <button type="button" className="primary-btn wide" onClick={run} disabled={busy}>
            {busy ? 'Rendering…' : `Download ${format === 'jpeg' ? 'JPG' : format.toUpperCase()}`}
          </button>

          <div className="modal-divider" />

          <div className="modal-footer-row">
            <div>
              <strong>Project file</strong>
              <p className="modal-note">
                Keep an editable copy on a USB stick or in a folder. All images are embedded.
              </p>
            </div>
            <button type="button" className="ghost-btn" onClick={() => exportProject(design)}>
              Save .json
            </button>
          </div>

          <p className="modal-note fine">
            Everything happens in this browser. No internet connection, account or upload is used.
          </p>
        </div>
      </div>
    </div>
  );
}
