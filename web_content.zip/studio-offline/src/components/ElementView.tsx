import { memo, useEffect, useRef } from 'react';
import type { CSSProperties } from 'react';
import type { DesignElement, ImageElement, ShapeElement, StickerElement, TextElement } from '../types';
import { FONT_STACKS } from '../lib/fonts';
import { ICON_MAP } from '../data/icons';
import { SHAPE_PATHS } from '../lib/shapes';

type TextProps = {
  element: TextElement;
  editing: boolean;
  onInput: (text: string) => void;
  onBlur: () => void;
};

function EditableText({ element, editing, onInput, onBlur }: TextProps) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (editing && ref.current && ref.current.innerText !== element.text) {
      ref.current.innerText = element.text;
      const selection = window.getSelection();
      const range = document.createRange();
      range.selectNodeContents(ref.current);
      selection?.removeAllRanges();
      selection?.addRange(range);
    }
    // Only when entering edit mode: typing must not reset the caret.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [editing]);

  const style: CSSProperties = {
    fontFamily: FONT_STACKS[element.font],
    fontSize: element.size,
    fontWeight: element.weight,
    fontStyle: element.italic ? 'italic' : 'normal',
    lineHeight: element.lineHeight,
    letterSpacing: element.letterSpacing,
    color: element.color,
    textAlign: element.align,
    textTransform: element.uppercase ? 'uppercase' : 'none',
    width: '100%',
    height: '100%',
    whiteSpace: 'pre-wrap',
    overflow: 'visible',
    outline: 'none',
    wordBreak: 'normal',
    cursor: editing ? 'text' : 'inherit',
  };

  return (
    <div
      ref={ref}
      className="el-text"
      style={style}
      contentEditable={editing}
      suppressContentEditableWarning
      spellCheck={false}
      onInput={(event) => onInput(event.currentTarget.innerText)}
      onBlur={onBlur}
    >
      {editing ? undefined : element.text}
    </div>
  );
}

function ShapeView({ element }: { element: ShapeElement }) {
  if (element.shape === 'ellipse') {
    return (
      <div
        style={{
          width: '100%',
          height: '100%',
          background: element.fill,
          borderRadius: '50%',
        }}
      />
    );
  }
  if (element.shape === 'rect' || element.shape === 'pill' || element.shape === 'line') {
    const radius =
      element.shape === 'pill' || element.shape === 'line' ? 9999 : element.radius;
    return (
      <div
        style={{
          width: '100%',
          height: '100%',
          background: element.fill,
          borderRadius: radius,
        }}
      />
    );
  }
  const path = SHAPE_PATHS[element.shape];
  return (
    <svg
      viewBox="0 0 100 100"
      preserveAspectRatio="none"
      width="100%"
      height="100%"
      style={{ display: 'block' }}
      aria-hidden="true"
    >
      <path d={path} fill={element.fill} />
    </svg>
  );
}

function StickerView({ element }: { element: StickerElement }) {
  const icon = ICON_MAP[element.icon];
  if (!icon) return null;
  const stroke = icon.stroke ?? element.strokeWidth;
  return (
    <svg
      viewBox={`0 0 ${icon.vb} ${icon.vb}`}
      preserveAspectRatio="xMidYMid meet"
      width="100%"
      height="100%"
      style={{ display: 'block', overflow: 'visible' }}
      aria-hidden="true"
    >
      <path
        d={icon.d}
        fill={icon.mode === 'fill' ? element.color : 'none'}
        stroke={icon.mode === 'stroke' ? element.color : 'none'}
        strokeWidth={icon.mode === 'stroke' ? stroke : undefined}
        strokeLinecap="round"
        strokeLinejoin="round"
        vectorEffect="non-scaling-stroke"
      />
    </svg>
  );
}

function ImageView({ element }: { element: ImageElement }) {
  return (
    <img
      src={element.src}
      alt=""
      draggable={false}
      style={{
        width: '100%',
        height: '100%',
        objectFit: element.fit,
        borderRadius: element.radius,
        display: 'block',
      }}
    />
  );
}

export const ElementView = memo(function ElementView({
  element,
  editing = false,
  onTextInput,
  onTextBlur,
}: {
  element: DesignElement;
  editing?: boolean;
  onTextInput?: (text: string) => void;
  onTextBlur?: () => void;
}) {
  if (element.type === 'text') {
    return (
      <EditableText
        element={element}
        editing={editing}
        onInput={onTextInput ?? (() => undefined)}
        onBlur={onTextBlur ?? (() => undefined)}
      />
    );
  }
  if (element.type === 'shape') return <ShapeView element={element} />;
  if (element.type === 'sticker') return <StickerView element={element} />;
  return <ImageView element={element} />;
});
