import { useRef } from 'react';
import type { Design, MoodId, PageSize } from '../types';
import { PAGE_SIZES } from '../types';
import { MOODS } from '../palettes';
import { TEMPLATES } from '../data/templates';
import type { Template } from '../data/templates';
import { PagePreview } from './PagePreview';
import { UiIcon } from './UiIcon';

function inkFor(hex: string) {
  const clean = hex.replace('#', '');
  const r = parseInt(clean.slice(0, 2), 16) / 255;
  const g = parseInt(clean.slice(2, 4), 16) / 255;
  const b = parseInt(clean.slice(4, 6), 16) / 255;
  return 0.299 * r + 0.587 * g + 0.114 * b > 0.6 ? '#14030F' : '#FEFDFE';
}

function timeAgo(timestamp: number) {
  const diff = Date.now() - timestamp;
  const minutes = Math.round(diff / 60000);
  if (minutes < 1) return 'just now';
  if (minutes < 60) return `${minutes} min ago`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `${hours} hr ago`;
  const days = Math.round(hours / 24);
  if (days < 7) return `${days} day${days === 1 ? '' : 's'} ago`;
  return new Date(timestamp).toLocaleDateString();
}

export function Home({
  designs,
  mood,
  onMood,
  onOpen,
  onNew,
  onTemplate,
  onDuplicate,
  onDelete,
  onImport,
  canInstall,
  onInstall,
}: {
  designs: Design[] | null;
  mood: MoodId;
  onMood: (mood: MoodId) => void;
  onOpen: (design: Design) => void;
  onNew: (size: PageSize | null) => void;
  onTemplate: (template: Template) => void;
  onDuplicate: (design: Design) => void;
  onDelete: (design: Design) => void;
  onImport: (file: File) => void;
  canInstall: boolean;
  onInstall: () => void;
}) {
  const designsRef = useRef<HTMLElement>(null);
  const templatesRef = useRef<HTMLElement>(null);
  const importRef = useRef<HTMLInputElement>(null);
  const scrollTo = (element: HTMLElement | null) =>
    element?.scrollIntoView({ behavior: 'smooth', block: 'start' });

  return (
    <div className="home">
      <header className="home-header">
        <div className="brand">
          <span className="brand-mark">S</span>
          <span className="brand-name">Studio</span>
        </div>
        <nav>
          <button type="button" onClick={() => scrollTo(designsRef.current)}>
            Your designs
          </button>
          <button type="button" onClick={() => scrollTo(templatesRef.current)}>
            Templates
          </button>
          <span className="offline-badge">Works offline</span>
          {canInstall ? (
            <button type="button" className="ghost-btn small" onClick={onInstall}>
              Install app
            </button>
          ) : null}
          <button
            type="button"
            className="ghost-btn small"
            onClick={() => importRef.current?.click()}
          >
            Import
          </button>
          <input
            ref={importRef}
            type="file"
            accept=".json,application/json"
            hidden
            onChange={(event) => {
              const file = event.target.files?.[0];
              if (file) onImport(file);
              event.target.value = '';
            }}
          />
        </nav>
      </header>

      <section className="hero">
        <div className="hero-copy">
          <span className="eyebrow">Offline design studio</span>
          <h1>
            MAKE
            <br />
            IT LOUD<span className="hero-dot">.</span>
          </h1>
          <p>
            Posters, social posts and decks with real design teeth. Everything runs on this device —
            no internet, no accounts, no uploads.
          </p>
          <div className="hero-actions">
            <button type="button" className="primary-btn" onClick={() => onNew(null)}>
              Start a design
            </button>
            <button
              type="button"
              className="ghost-btn"
              onClick={() => scrollTo(templatesRef.current)}
            >
              Browse templates
            </button>
          </div>
          <div className="hero-sizes">
            {PAGE_SIZES.slice(0, 4).map((size) => (
              <button key={size.id} type="button" onClick={() => onNew(size)}>
                {size.name}
              </button>
            ))}
          </div>
        </div>

        <div className="palette-stack">
          <div className="palette-stack-label">
            <span className="eyebrow">Program mood</span>
            <p>Three palettes straight off the mood board. Pick one and the whole studio shifts.</p>
          </div>
          {MOODS.map((entry, index) => {
            const primary = entry.swatches[0];
            const ink = inkFor(primary.hex);
            return (
              <button
                key={entry.id}
                type="button"
                className={`palette-card${mood === entry.id ? ' is-active' : ''}`}
                style={{ transform: `rotate(${[-2.4, 1.6, -1][index]}deg)` }}
                onClick={() => onMood(entry.id)}
                title={`Use ${entry.name}`}
              >
                <span className="palette-swatch" style={{ background: primary.hex, color: ink }}>
                  <span className="palette-swatch-name">{primary.name}</span>
                  <code>{primary.hex}</code>
                </span>
                <span className="palette-strip">
                  {entry.swatches.slice(1, 4).map((swatch) => (
                    <i key={swatch.hex} style={{ background: swatch.hex }} />
                  ))}
                </span>
                <span className="palette-meta">
                  <strong>{entry.name}</strong>
                  <em>{mood === entry.id ? 'In use' : 'Use mood'}</em>
                </span>
              </button>
            );
          })}
        </div>
      </section>

      <section className="home-section" ref={designsRef}>
        <div className="home-section-head">
          <h2>Your designs</h2>
          <span>{designs?.length ?? 0} saved on this device</span>
        </div>
        {designs === null ? (
          <p className="home-empty">Opening your local library…</p>
        ) : designs.length === 0 ? (
          <div className="home-empty-card">
            <span className="eyebrow">Nothing here yet</span>
            <h3>Your next loud idea starts here.</h3>
            <p>Start blank or take a template. Everything saves automatically, offline.</p>
            <button type="button" className="primary-btn" onClick={() => onNew(null)}>
              Create your first design
            </button>
          </div>
        ) : (
          <div className="design-grid">
            {designs.map((design) => (
              <article className="design-card" key={design.id}>
                <button
                  type="button"
                  className="design-thumb"
                  onClick={() => onOpen(design)}
                  title={`Open ${design.name}`}
                >
                  {design.thumb ? (
                    <img src={design.thumb} alt="" />
                  ) : (
                    <PagePreview
                      design={design}
                      page={design.pages[0]}
                      width={240}
                      className="design-thumb-preview"
                    />
                  )}
                </button>
                <div className="design-info">
                  <div>
                    <h3>{design.name}</h3>
                    <p>
                      {design.width} × {design.height} · {timeAgo(design.updatedAt)}
                    </p>
                  </div>
                  <div className="design-actions">
                    <button
                      type="button"
                      className="icon-btn"
                      title="Duplicate"
                      onClick={() => onDuplicate(design)}
                    >
                      <UiIcon name="duplicate" size={17} />
                    </button>
                    <button
                      type="button"
                      className="icon-btn"
                      title="Delete"
                      onClick={() => onDelete(design)}
                    >
                      <UiIcon name="trash" size={17} />
                    </button>
                  </div>
                </div>
              </article>
            ))}
          </div>
        )}
      </section>

      <section className="home-section" ref={templatesRef}>
        <div className="home-section-head">
          <h2>Templates</h2>
          <span>Bold type, honest grids, three moods</span>
        </div>
        <div className="home-template-grid">
          {TEMPLATES.map((template) => {
            const width = Math.min(200, (252 * template.width) / template.height);
            return (
              <button
                key={template.id}
                type="button"
                className="home-template"
                onClick={() => onTemplate(template)}
              >
                <span className="home-template-frame">
                  <PagePreview
                    design={{ width: template.width, height: template.height }}
                    page={template.build()}
                    width={width}
                  />
                </span>
                <span className="home-template-name">{template.name}</span>
                <span className="home-template-tags">{template.tags.join(' · ')}</span>
              </button>
            );
          })}
        </div>
      </section>

      <section className="home-section" id="sizes">
        <div className="home-section-head">
          <h2>Start at the right size</h2>
          <span>Print or screen, ready to export</span>
        </div>
        <div className="size-grid">
          {PAGE_SIZES.map((size) => (
            <button key={size.id} type="button" className="size-card" onClick={() => onNew(size)}>
              <span className="size-group">{size.group}</span>
              <strong>{size.name}</strong>
              <code>
                {size.width} × {size.height}
              </code>
            </button>
          ))}
        </div>
      </section>

      <footer className="home-footer">
        <div>
          <strong>Studio</strong>
          <p>
            Your work lives in this browser's local database. Export a project file to keep a
            backup, and install the app for offline sessions.
          </p>
        </div>
        <span className="offline-badge">No internet required</span>
      </footer>
    </div>
  );
}
