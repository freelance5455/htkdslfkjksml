import { useState } from 'react';
import type { Design, MoodId, PageSize } from '../types';
import { PAGE_SIZES } from '../types';
import { MOODS } from '../palettes';
import { TEMPLATES } from '../data/templates';
import type { Template } from '../data/templates';
import { PagePreview } from './PagePreview';
import { UiIcon } from './UiIcon';

// size: a PAGE_SIZES id, 'import' (open a project file) or 'custom' (blank default size)
const TILES = [
  { label: 'Education', color: '#d81b7a', icon: 'layers', size: 'a4' },
  { label: 'Presentation', color: '#ff5a00', icon: 'templates', size: 'deck' },
  { label: 'Social media', color: '#ff3b4a', icon: 'sparkle', size: 'ig-post' },
  { label: 'Upload', color: '#e4e4ea', icon: 'upload', size: 'import' },
  { label: 'Doc', color: '#12a4b4', icon: 'text', size: 'letter' },
  { label: 'Whiteboard', color: '#0fa74a', icon: 'shapes', size: 'wide' },
  { label: 'Video', color: '#e94cf0', icon: 'forward', size: 'story' },
  { label: 'Custom size', color: '#e4e4ea', icon: 'plus', size: 'custom' },
  { label: 'Sheet', color: '#1a8cff', icon: 'layers', size: 'letter' },
  { label: 'Code', color: '#a01cb0', icon: 'more', size: 'deck' },
  { label: 'Email', color: '#4a35e0', icon: 'image', size: 'ig-portrait' },
  { label: 'Print Shop', color: '#8e2cf5', icon: 'palette', size: 'card' },
  { label: 'Website', color: '#4a58f0', icon: 'templates', size: 'deck' },
];

const TABS = [
  ['home', 'Home', 'sparkle'],
  ['designs', 'Your Designs', 'layers'],
  ['templates', 'Templates', 'templates'],
] as const;

type Props = {
  designs: Design[] | null;
  mood: MoodId;
  onMood: (mood: MoodId) => void;
  onOpen: (design: Design) => void;
  onNew: (size: PageSize | null) => void;
  onTemplate: (template: Template) => void;
  onDuplicate: (design: Design) => void;
  onDelete: (design: Design) => void;
  onImport: (file: File) => void;
};

export function Home({ designs, mood, onMood, onOpen, onNew, onTemplate, onDuplicate, onDelete, onImport }: Props) {
  const [tab, setTab] = useState<(typeof TABS)[number][0]>('home');
  const [query, setQuery] = useState('');

  const start = (size: string) => {
    if (size === 'import') document.getElementById('hm-import')?.click();
    else onNew(PAGE_SIZES.find((entry) => entry.id === size) ?? null);
  };

  const designCards = (list: Design[]) =>
    list.map((design) => (
      <article className="hm-design" key={design.id}>
        <button type="button" className="hm-thumb" onClick={() => onOpen(design)}>
          {design.thumb ? <img src={design.thumb} alt="" /> : <PagePreview design={design} page={design.pages[0]} width={120} />}
        </button>
        <strong>{design.name}</strong>
        <span className="hm-acts">
          <button type="button" className="icon-btn" title="Duplicate" onClick={() => onDuplicate(design)}>
            <UiIcon name="duplicate" size={16} />
          </button>
          <button type="button" className="icon-btn" title="Delete" onClick={() => onDelete(design)}>
            <UiIcon name="trash" size={16} />
          </button>
        </span>
      </article>
    ));

  return (
    <div className="hm">
      <input
        id="hm-import"
        type="file"
        accept=".json,application/json"
        hidden
        onChange={(event) => {
          const file = event.target.files?.[0];
          if (file) onImport(file);
          event.target.value = '';
        }}
      />
      <main className="hm-main">
        {tab === 'home' && (
          <>
            <h1 className="hm-title">What will you design today?</h1>
            <input
              className="hm-search"
              placeholder="What would you like to create?"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
            />
            <div className="hm-moods">
              {MOODS.map((entry) => (
                <button
                  key={entry.id}
                  type="button"
                  className={`hm-mood${mood === entry.id ? ' is-active' : ''}`}
                  onClick={() => onMood(entry.id)}
                >
                  <span>
                    {entry.swatches.slice(0, 3).map((swatch) => (
                      <i key={swatch.hex} style={{ background: swatch.hex }} />
                    ))}
                  </span>
                  {entry.name}
                </button>
              ))}
            </div>
            {designs && designs.length > 0 && !query && (
              <>
                <div className="hm-head">
                  <h2>Continue designing</h2>
                  <button type="button" onClick={() => setTab('designs')}>See all</button>
                </div>
                <div className="hm-row">{designCards(designs.slice(0, 6))}</div>
              </>
            )}
            <h2 className="hm-head">Choose how to start</h2>
            <div className="hm-tiles">
              {TILES.filter((tile) => tile.label.toLowerCase().includes(query.trim().toLowerCase())).map((tile) => (
                <button key={tile.label} type="button" onClick={() => start(tile.size)}>
                  <span style={{ background: tile.color, color: tile.color === '#e4e4ea' ? 'var(--accent)' : '#fff' }}>
                    <UiIcon name={tile.icon} size={30} />
                  </span>
                  {tile.label}
                </button>
              ))}
            </div>
          </>
        )}
        {tab === 'designs' && (
          <>
            <h1 className="hm-title">Your Designs</h1>
            {designs && designs.length ? <div className="hm-grid">{designCards(designs)}</div> : <p>No designs yet.</p>}
          </>
        )}
        {tab === 'templates' && (
          <>
            <h1 className="hm-title">Templates</h1>
            <div className="hm-grid">
              {TEMPLATES.map((template) => (
                <button key={template.id} type="button" className="hm-tpl" onClick={() => onTemplate(template)}>
                  <PagePreview
                    design={{ width: template.width, height: template.height }}
                    page={template.build()}
                    width={Math.min(150, (190 * template.width) / template.height)}
                  />
                  {template.name}
                </button>
              ))}
            </div>
          </>
        )}
      </main>
      <nav className="hm-nav">
        {TABS.map(([id, label, icon]) => (
          <button key={id} type="button" className={tab === id ? 'is-active' : ''} onClick={() => setTab(id)}>
            <UiIcon name={icon} size={24} />
            {label}
          </button>
        ))}
      </nav>
    </div>
  );
}
