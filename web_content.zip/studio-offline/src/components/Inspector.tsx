import { useRef } from 'react';
import type { Background, Design, DesignElement, MoodId, Page, ShapeId } from '../types';
import { elementLabel } from '../types';
import type { DocApi } from '../lib/useEditorDoc';
import { FONT_OPTIONS } from '../lib/fonts';
import { SHAPE_OPTIONS } from '../lib/shapes';
import { readImageFile } from '../lib/export';
import { BackgroundControls } from './BackgroundControls';
import {
  NumberField,
  RangeField,
  Section,
  Segmented,
  SwatchGrid,
  ToggleRow,
} from './controls';
import { UiIcon } from './UiIcon';

export function Inspector({
  doc,
  page,
  pageIndex,
  selected,
  mood,
  onDelete,
  onDuplicate,
  onLayer,
  onBackground,
}: {
  doc: DocApi;
  page: Page;
  pageIndex: number;
  selected: DesignElement | null;
  mood: MoodId;
  onDelete: () => void;
  onDuplicate: () => void;
  onLayer: (direction: 'front' | 'forward' | 'backward' | 'back') => void;
  onBackground: (background: Background) => void;
}) {
  const replaceRef = useRef<HTMLInputElement>(null);

  const patch = (changes: Partial<DesignElement> | Record<string, unknown>) => {
    if (!selected) return;
    doc.commit((draft) => {
      const targetPage = draft.pages[pageIndex];
      const element = targetPage?.elements.find((candidate) => candidate.id === selected.id);
      if (element) Object.assign(element, changes);
    });
  };

  const livePatch = (changes: Record<string, unknown>) => {
    if (!selected) return;
    doc.update((draft) => {
      const targetPage = draft.pages[pageIndex];
      const element = targetPage?.elements.find((candidate) => candidate.id === selected.id);
      if (element) Object.assign(element, changes);
    });
  };

  const replaceImage = async (file: File | undefined) => {
    if (!file || !selected || selected.type !== 'image') return;
    const { src } = await readImageFile(file);
    patch({ src });
  };

  return (
    <div className="inspector-inner">
      <div className="inspector-title">
        <div>
          <span className="eyebrow">{selected ? selected.type : 'Page'}</span>
          <h2>{selected ? elementLabel(selected) : 'Background'}</h2>
        </div>
        {selected ? (
          <div className="inspector-actions">
            <button type="button" title="Duplicate" onClick={onDuplicate}>
              <UiIcon name="duplicate" size={18} />
            </button>
            <button type="button" title="Delete" onClick={onDelete}>
              <UiIcon name="trash" size={18} />
            </button>
          </div>
        ) : null}
      </div>

      {!selected ? (
        <>
          <Section title="Canvas">
            <div className="meta-row">
              <span>Size</span>
              <strong>
                {doc.design.width} × {doc.design.height} px
              </strong>
            </div>
            <div className="meta-row">
              <span>Mood</span>
              <strong style={{ textTransform: 'capitalize' }}>{mood}</strong>
            </div>
            <div className="meta-row">
              <span>Elements</span>
              <strong>{page.elements.length}</strong>
            </div>
          </Section>
          <Section title="Background">
            <BackgroundControls background={page.background} onChange={onBackground} compact />
          </Section>
          <p className="hint">Select something on the canvas to edit its size, colour and type.</p>
        </>
      ) : (
        <>
          <Section title="Position & size">
            <div className="field-grid">
              <NumberField
                label="X"
                value={selected.x}
                onChange={(value) => patch({ x: value })}
              />
              <NumberField
                label="Y"
                value={selected.y}
                onChange={(value) => patch({ y: value })}
              />
              <NumberField
                label="W"
                value={selected.w}
                min={8}
                onChange={(value) => patch({ w: value })}
              />
              <NumberField
                label="H"
                value={selected.h}
                min={8}
                onChange={(value) => patch({ h: value })}
              />
              <NumberField
                label="Rotate"
                value={selected.rotation}
                suffix="°"
                onChange={(value) => patch({ rotation: value })}
              />
            </div>
            <RangeField
              label="Opacity"
              min={0}
              max={100}
              value={Math.round(selected.opacity * 100)}
              format={(value) => `${value}%`}
              onStart={() => doc.pushHistory(doc.snapshot())}
              onInput={(value) => livePatch({ opacity: value / 100 })}
            />
          </Section>

          {selected.type === 'text' ? (
            <Section title="Type">
              <label className="select-field">
                <span>Font</span>
                <select
                  value={selected.font}
                  onChange={(event) => patch({ font: event.target.value })}
                >
                  {FONT_OPTIONS.map((font) => (
                    <option key={font.id} value={font.id}>
                      {font.label}
                    </option>
                  ))}
                </select>
              </label>
              <div className="field-grid">
                <NumberField
                  label="Size"
                  value={selected.size}
                  min={8}
                  max={800}
                  onChange={(value) => patch({ size: value })}
                />
                <NumberField
                  label="Line"
                  value={selected.lineHeight}
                  min={0.6}
                  max={3}
                  step={0.05}
                  onChange={(value) => patch({ lineHeight: value })}
                />
                <NumberField
                  label="Tracking"
                  value={selected.letterSpacing}
                  min={-20}
                  max={80}
                  step={0.5}
                  onChange={(value) => patch({ letterSpacing: value })}
                />
              </div>
              <div className="control-row">
                <span className="control-label">Weight</span>
                <Segmented
                  ariaLabel="Font weight"
                  value={String(selected.weight)}
                  options={[
                    { value: '400', label: 'Reg' },
                    { value: '500', label: 'Med' },
                    { value: '600', label: 'Semi' },
                    { value: '700', label: 'Bold' },
                    { value: '900', label: 'Black' },
                  ]}
                  onChange={(value) => patch({ weight: Number(value) })}
                />
              </div>
              <div className="control-row">
                <span className="control-label">Align</span>
                <Segmented
                  ariaLabel="Text alignment"
                  value={selected.align}
                  options={[
                    { value: 'left', label: 'Left' },
                    { value: 'center', label: 'Centre' },
                    { value: 'right', label: 'Right' },
                  ]}
                  onChange={(value) => patch({ align: value })}
                />
              </div>
              <ToggleRow
                label="Uppercase"
                checked={!!selected.uppercase}
                onChange={(checked) => patch({ uppercase: checked })}
              />
              <div className="control-row">
                <span className="control-label">Italic</span>
                <ToggleRow
                  label=""
                  checked={!!selected.italic}
                  onChange={(checked) => patch({ italic: checked })}
                />
              </div>
              <div className="sub-label">Colour</div>
              <SwatchGrid
                value={selected.color}
                onChange={(hex) => patch({ color: hex })}
              />
            </Section>
          ) : null}

          {selected.type === 'shape' ? (
            <Section title="Shape">
              <label className="select-field">
                <span>Kind</span>
                <select
                  value={selected.shape}
                  onChange={(event) => patch({ shape: event.target.value as ShapeId })}
                >
                  {SHAPE_OPTIONS.map((shape) => (
                    <option key={shape.id} value={shape.id}>
                      {shape.label}
                    </option>
                  ))}
                </select>
              </label>
              {selected.shape === 'rect' ? (
                <NumberField
                  label="Radius"
                  value={selected.radius}
                  min={0}
                  max={400}
                  onChange={(value) => patch({ radius: value })}
                />
              ) : null}
              <div className="sub-label">Fill</div>
              <SwatchGrid value={selected.fill} onChange={(hex) => patch({ fill: hex })} />
            </Section>
          ) : null}

          {selected.type === 'sticker' ? (
            <Section title="Sticker">
              <div className="sub-label">Colour</div>
              <SwatchGrid value={selected.color} onChange={(hex) => patch({ color: hex })} />
              <NumberField
                label="Stroke"
                value={selected.strokeWidth}
                min={1}
                max={30}
                onChange={(value) => patch({ strokeWidth: value })}
              />
            </Section>
          ) : null}

          {selected.type === 'image' ? (
            <Section title="Image">
              <div className="control-row">
                <span className="control-label">Fit</span>
                <Segmented
                  ariaLabel="Image fit"
                  value={selected.fit}
                  options={[
                    { value: 'cover', label: 'Fill' },
                    { value: 'contain', label: 'Fit' },
                  ]}
                  onChange={(value) => patch({ fit: value })}
                />
              </div>
              <NumberField
                label="Radius"
                value={selected.radius}
                min={0}
                max={400}
                onChange={(value) => patch({ radius: value })}
              />
              <input
                ref={replaceRef}
                type="file"
                accept="image/*"
                hidden
                onChange={(event) => replaceImage(event.target.files?.[0])}
              />
              <button type="button" className="wide-btn" onClick={() => replaceRef.current?.click()}>
                Replace image
              </button>
            </Section>
          ) : null}

          <Section title="Arrange">
            <div className="layer-buttons">
              <button type="button" title="Bring to front" onClick={() => onLayer('front')}>
                <UiIcon name="front" size={18} />
                <span>Front</span>
              </button>
              <button type="button" title="Forward" onClick={() => onLayer('forward')}>
                <UiIcon name="up" size={18} />
                <span>Up</span>
              </button>
              <button type="button" title="Backward" onClick={() => onLayer('backward')}>
                <UiIcon name="down" size={18} />
                <span>Down</span>
              </button>
              <button type="button" title="Send to back" onClick={() => onLayer('back')}>
                <UiIcon name="sendback" size={18} />
                <span>Back</span>
              </button>
            </div>
            <button
              type="button"
              className={`toggle-row${selected.locked ? ' is-on' : ''}`}
              onClick={() => patch({ locked: !selected.locked })}
            >
              <span>Lock element</span>
              <UiIcon name={selected.locked ? 'lock' : 'unlock'} size={18} />
            </button>
          </Section>
        </>
      )}
    </div>
  );
}
