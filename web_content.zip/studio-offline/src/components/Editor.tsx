import { useCallback, useEffect, useRef, useState } from 'react';
import type { Background, Design, DesignElement, MoodId } from '../types';
import { clone, uid } from '../types';
import { duplicateElement } from '../lib/factory';
import { emptyPage } from '../data/templates';
import type { Template } from '../data/templates';
import { useEditorDoc } from '../lib/useEditorDoc';
import { listUploads, saveDesign } from '../lib/idb';
import type { Upload } from '../lib/idb';
import { renderThumbnail } from '../lib/render';
import { Stage } from './Stage';
import { LeftPanel } from './LeftPanel';
import type { LeftTab } from './LeftPanel';
import { Inspector } from './Inspector';
import { ExportDialog } from './ExportDialog';
import { PagePreview } from './PagePreview';
import { UiIcon } from './UiIcon';

const TABS: { id: LeftTab; label: string; icon: string }[] = [
  { id: 'templates', label: 'Templates', icon: 'templates' },
  { id: 'text', label: 'Text', icon: 'text' },
  { id: 'elements', label: 'Elements', icon: 'shapes' },
  { id: 'uploads', label: 'Uploads', icon: 'image' },
  { id: 'background', label: 'Canvas', icon: 'palette' },
];

export function Editor({
  initial,
  onExit,
}: {
  initial: Design;
  onExit: () => void;
}) {
  const doc = useEditorDoc(initial);
  const [pageIndex, setPageIndex] = useState(0);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [tab, setTab] = useState<LeftTab>('templates');
  const [panelOpen, setPanelOpen] = useState(true);
  const [inspectorOpen, setInspectorOpen] = useState(false);
  const [exportOpen, setExportOpen] = useState(false);
  const [uploads, setUploads] = useState<Upload[]>([]);
  const [status, setStatus] = useState<'saving' | 'saved'>('saved');
  const [nameDraft, setNameDraft] = useState(initial.name);

  const designRef = useRef(doc.design);
  designRef.current = doc.design;
  const pages = doc.design.pages;
  const safeIndex = Math.min(pageIndex, pages.length - 1);
  const page = pages[safeIndex];
  const selected = page.elements.find((element) => element.id === selectedId) ?? null;

  useEffect(() => {
    listUploads()
      .then(setUploads)
      .catch(() => setUploads([]));
  }, []);

  const persist = useCallback(async (design: Design) => {
    let thumb = design.thumb;
    try {
      await document.fonts.ready;
      thumb = await renderThumbnail(design, design.pages[0], 480);
    } catch {
      // A design without a thumbnail still saves fine.
    }
    await saveDesign({ ...design, thumb });
  }, []);

  useEffect(() => {
    setStatus('saving');
    const handle = window.setTimeout(async () => {
      try {
        await persist(designRef.current);
        setStatus('saved');
      } catch {
        setStatus('saved');
      }
    }, 800);
    return () => window.clearTimeout(handle);
  }, [doc.design, persist]);

  useEffect(() => {
    setNameDraft(doc.design.name);
  }, [doc.design.name]);

  const commitName = () => {
    const value = nameDraft.trim() || 'Untitled design';
    setNameDraft(value);
    if (value !== doc.design.name) {
      doc.commit((draft) => {
        draft.name = value;
      });
    }
  };

  const exit = async () => {
    try {
      await persist(designRef.current);
    } catch {
      // Never block leaving the editor on a thumbnail failure.
    }
    onExit();
  };

  const addElement = (element: DesignElement) => {
    doc.commit((draft) => {
      const target = draft.pages[safeIndex];
      element.x = Math.round((draft.width - element.w) / 2);
      element.y = Math.round((draft.height - element.h) / 2);
      target.elements.push(element);
    });
    setSelectedId(element.id);
    setEditingId(null);
    setInspectorOpen(true);
  };

  const deleteSelected = () => {
    if (!selectedId) return;
    doc.commit((draft) => {
      const target = draft.pages[safeIndex];
      target.elements = target.elements.filter((element) => element.id !== selectedId);
    });
    setSelectedId(null);
    setEditingId(null);
  };

  const duplicateSelected = () => {
    if (!selected) return;
    const copy = duplicateElement(selected);
    doc.commit((draft) => {
      draft.pages[safeIndex].elements.push(copy);
    });
    setSelectedId(copy.id);
  };

  const moveLayer = (direction: 'front' | 'forward' | 'backward' | 'back') => {
    if (!selectedId) return;
    doc.commit((draft) => {
      const elements = draft.pages[safeIndex].elements;
      const index = elements.findIndex((element) => element.id === selectedId);
      if (index < 0) return;
      const [element] = elements.splice(index, 1);
      let target = index;
      if (direction === 'front') target = elements.length;
      if (direction === 'back') target = 0;
      if (direction === 'forward') target = Math.min(elements.length, index + 1);
      if (direction === 'backward') target = Math.max(0, index - 1);
      elements.splice(target, 0, element);
    });
  };

  const setBackground = (background: Background) => {
    doc.commit((draft) => {
      draft.pages[safeIndex].background = background;
    });
  };

  const applyTemplate = (template: Template) => {
    const blank = pages.length === 1 && pages[0].elements.length === 0;
    if (
      !blank &&
      !window.confirm(
        `Replace this design with the "${template.name}" template? You can undo with ⌘Z.`,
      )
    ) {
      return;
    }
    const templatePage = template.build();
    doc.commit((draft) => {
      draft.width = template.width;
      draft.height = template.height;
      draft.mood = template.mood;
      draft.pages = [templatePage];
    });
    setPageIndex(0);
    setSelectedId(null);
    setEditingId(null);
  };

  const addPage = () => {
    const next = emptyPage(doc.design.mood);
    doc.commit((draft) => {
      draft.pages.splice(safeIndex + 1, 0, next);
    });
    setPageIndex(safeIndex + 1);
    setSelectedId(null);
  };

  const duplicatePage = () => {
    const copy = clone(page);
    copy.id = uid('pg');
    copy.elements = copy.elements.map((element) => ({ ...element, id: uid() }));
    doc.commit((draft) => {
      draft.pages.splice(safeIndex + 1, 0, copy);
    });
    setPageIndex(safeIndex + 1);
    setSelectedId(null);
  };

  const deletePage = () => {
    if (pages.length <= 1) return;
    if (!window.confirm('Delete this page? You can undo with ⌘Z.')) return;
    doc.commit((draft) => {
      draft.pages.splice(safeIndex, 1);
    });
    setPageIndex(Math.max(0, safeIndex - 1));
    setSelectedId(null);
  };

  const nudge = (dx: number, dy: number) => {
    if (!selected) return;
    doc.commit((draft) => {
      const element = draft.pages[safeIndex].elements.find(
        (candidate) => candidate.id === selected.id,
      );
      if (element) {
        element.x += dx;
        element.y += dy;
      }
    });
  };

  useEffect(() => {
    const handler = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      if (target?.closest('input, textarea, select, [contenteditable="true"]')) return;
      const mod = event.metaKey || event.ctrlKey;

      if (mod && event.key.toLowerCase() === 'z') {
        event.preventDefault();
        if (event.shiftKey) doc.redo();
        else doc.undo();
        return;
      }
      if (mod && event.key.toLowerCase() === 'y') {
        event.preventDefault();
        doc.redo();
        return;
      }
      if (mod && event.key.toLowerCase() === 'd') {
        event.preventDefault();
        duplicateSelected();
        return;
      }
      if (mod && event.key.toLowerCase() === 's') {
        event.preventDefault();
        persist(designRef.current).catch(() => undefined);
        return;
      }
      if (event.key === 'Escape') {
        setSelectedId(null);
        setEditingId(null);
        setExportOpen(false);
        return;
      }
      if (!selected) return;
      if (event.key === 'Delete' || event.key === 'Backspace') {
        event.preventDefault();
        deleteSelected();
        return;
      }
      if (event.key === 'Enter' && selected.type === 'text') {
        event.preventDefault();
        setEditingId(selected.id);
        return;
      }
      const step = event.shiftKey ? 10 : 1;
      if (event.key === 'ArrowLeft') {
        event.preventDefault();
        nudge(-step, 0);
      }
      if (event.key === 'ArrowRight') {
        event.preventDefault();
        nudge(step, 0);
      }
      if (event.key === 'ArrowUp') {
        event.preventDefault();
        nudge(0, -step);
      }
      if (event.key === 'ArrowDown') {
        event.preventDefault();
        nudge(0, step);
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  });

  return (
    <div className={`editor${inspectorOpen ? ' show-inspector' : ''}`}>
      <header className="topbar">
        <button type="button" className="icon-btn" onClick={exit} title="Back to your designs">
          <UiIcon name="back" />
        </button>
        <div className="doc-name">
          <input
            value={nameDraft}
            aria-label="Design name"
            onChange={(event) => setNameDraft(event.target.value)}
            onBlur={commitName}
            onKeyDown={(event) => {
              if (event.key === 'Enter') event.currentTarget.blur();
            }}
          />
          <span>
            {doc.design.width} × {doc.design.height} px · Page {safeIndex + 1} of {pages.length}
          </span>
        </div>
        <div className="topbar-spacer" />
        <div className="history-buttons">
          <button
            type="button"
            className="icon-btn"
            onClick={doc.undo}
            disabled={!doc.canUndo}
            title="Undo (⌘Z)"
          >
            <UiIcon name="undo" />
          </button>
          <button
            type="button"
            className="icon-btn"
            onClick={doc.redo}
            disabled={!doc.canRedo}
            title="Redo (⇧⌘Z)"
          >
            <UiIcon name="redo" />
          </button>
        </div>
        <span className={`save-badge ${status}`}>
          <i />
          {status === 'saving' ? 'Saving…' : 'Saved offline'}
        </span>
        <button
          type="button"
          className="ghost-btn small mobile-inspector-toggle"
          onClick={() => setInspectorOpen((open) => !open)}
        >
          {inspectorOpen ? 'Close' : 'Properties'}
        </button>
        <button type="button" className="primary-btn small" onClick={() => setExportOpen(true)}>
          <UiIcon name="download" size={16} />
          Export
        </button>
      </header>

      <div className="editor-body">
        <aside className="rail" aria-label="Tools">
          {TABS.map((item) => (
            <button
              key={item.id}
              type="button"
              className={panelOpen && tab === item.id ? 'is-active' : ''}
              onClick={() => {
                if (tab === item.id) setPanelOpen((open) => !open);
                else {
                  setTab(item.id);
                  setPanelOpen(true);
                }
              }}
            >
              <UiIcon name={item.icon} size={20} />
              <span>{item.label}</span>
            </button>
          ))}
        </aside>

        {panelOpen ? (
          <aside className="panel">
            <button
              type="button"
              className="panel-close icon-btn"
              onClick={() => setPanelOpen(false)}
              aria-label="Close panel"
            >
              <UiIcon name="close" size={18} />
            </button>
            <LeftPanel
              tab={tab}
              design={doc.design}
              page={page}
              pageIndex={safeIndex}
              onAdd={addElement}
              onBackground={setBackground}
              onApplyTemplate={applyTemplate}
              uploads={uploads}
              onUploads={setUploads}
            />
          </aside>
        ) : null}

        <main className="stage-wrap">
          <Stage
            doc={doc}
            page={page}
            selectedId={selectedId}
            onSelect={(id) => {
              setSelectedId(id);
              if (!id) setEditingId(null);
            }}
            editingId={editingId}
            onEdit={setEditingId}
          />
          <div className="page-strip">
            <div className="page-thumbs">
              {pages.map((candidate, index) => (
                <button
                  key={candidate.id}
                  type="button"
                  className={`page-thumb${index === safeIndex ? ' is-active' : ''}`}
                  onClick={() => {
                    setPageIndex(index);
                    setSelectedId(null);
                    setEditingId(null);
                  }}
                  title={`Page ${index + 1}`}
                >
                  <PagePreview
                    design={doc.design}
                    page={candidate}
                    width={Math.min(54, (56 * doc.design.width) / doc.design.height)}
                  />
                  <span className="page-number">{index + 1}</span>
                </button>
              ))}
            </div>
            <div className="page-actions">
              <button type="button" className="icon-btn" onClick={addPage} title="Add page">
                <UiIcon name="plus" size={18} />
              </button>
              <button type="button" className="icon-btn" onClick={duplicatePage} title="Duplicate page">
                <UiIcon name="duplicate" size={18} />
              </button>
              <button
                type="button"
                className="icon-btn"
                onClick={deletePage}
                title="Delete page"
                disabled={pages.length <= 1}
              >
                <UiIcon name="trash" size={18} />
              </button>
            </div>
          </div>
        </main>

        <aside className="inspector">
          <Inspector
            doc={doc}
            page={page}
            pageIndex={safeIndex}
            selected={selected}
            mood={doc.design.mood as MoodId}
            onDelete={deleteSelected}
            onDuplicate={duplicateSelected}
            onLayer={moveLayer}
            onBackground={setBackground}
          />
        </aside>
      </div>

      {exportOpen ? (
        <ExportDialog
          design={doc.design}
          page={page}
          pageNumber={safeIndex + 1}
          onClose={() => setExportOpen(false)}
        />
      ) : null}
    </div>
  );
}
