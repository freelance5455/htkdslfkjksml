import { useEffect, useState } from 'react';
import type { ReactNode } from 'react';
import { uniqueSwatches } from '../palettes';

export function Section({
  title,
  children,
  aside,
}: {
  title: string;
  children: ReactNode;
  aside?: ReactNode;
}) {
  return (
    <section className="section">
      <div className="section-head">
        <h3>{title}</h3>
        {aside}
      </div>
      {children}
    </section>
  );
}

export function SwatchGrid({
  value,
  onChange,
  onCommit,
  columns = 7,
  swatches,
}: {
  value?: string;
  onChange: (hex: string) => void;
  onCommit?: () => void;
  columns?: number;
  swatches?: { name: string; hex: string }[];
}) {
  const list = swatches ?? uniqueSwatches();
  return (
    <div className="swatch-block">
      <div className="swatch-grid" style={{ gridTemplateColumns: `repeat(${columns}, 1fr)` }}>
        {list.map((swatch) => (
          <button
            key={`${swatch.name}-${swatch.hex}`}
            type="button"
            className={`swatch${value?.toLowerCase() === swatch.hex.toLowerCase() ? ' is-active' : ''}`}
            style={{ background: swatch.hex }}
            title={`${swatch.name} ${swatch.hex}`}
            aria-label={`${swatch.name} ${swatch.hex}`}
            onClick={() => {
              onChange(swatch.hex);
              onCommit?.();
            }}
          />
        ))}
      </div>
      <label className="custom-color">
        <span>Custom</span>
        <input
          type="color"
          value={value ?? '#D13CD3'}
          onChange={(event) => onChange(event.target.value)}
          onBlur={() => onCommit?.()}
        />
        <code>{value ?? '#D13CD3'}</code>
      </label>
    </div>
  );
}

export function NumberField({
  label,
  value,
  onChange,
  min,
  max,
  step = 1,
  suffix,
}: {
  label: string;
  value: number;
  onChange: (value: number) => void;
  min?: number;
  max?: number;
  step?: number;
  suffix?: string;
}) {
  const rounded = Math.round(value * 10) / 10;
  const [text, setText] = useState(String(rounded));

  useEffect(() => {
    setText(String(rounded));
  }, [rounded]);

  const commit = () => {
    const parsed = Number(text);
    if (!Number.isFinite(parsed)) {
      setText(String(rounded));
      return;
    }
    let next = parsed;
    if (min !== undefined) next = Math.max(min, next);
    if (max !== undefined) next = Math.min(max, next);
    onChange(next);
  };

  return (
    <label className="num-field">
      <span>{label}</span>
      <div className="num-input">
        <input
          value={text}
          inputMode="decimal"
          onChange={(event) => setText(event.target.value)}
          onBlur={commit}
          onKeyDown={(event) => {
            if (event.key === 'Enter') {
              event.currentTarget.blur();
            }
            if (event.key === 'ArrowUp') {
              event.preventDefault();
              onChange(rounded + step);
            }
            if (event.key === 'ArrowDown') {
              event.preventDefault();
              onChange(rounded - step);
            }
          }}
        />
        {suffix ? <i>{suffix}</i> : null}
      </div>
    </label>
  );
}

export function Segmented<T extends string>({
  options,
  value,
  onChange,
  ariaLabel,
}: {
  options: { value: T; label: ReactNode; title?: string }[];
  value: T;
  onChange: (value: T) => void;
  ariaLabel?: string;
}) {
  return (
    <div className="segmented" role="group" aria-label={ariaLabel}>
      {options.map((option) => (
        <button
          key={option.value}
          type="button"
          className={option.value === value ? 'is-active' : ''}
          title={option.title}
          onClick={() => onChange(option.value)}
        >
          {option.label}
        </button>
      ))}
    </div>
  );
}

export function RangeField({
  label,
  value,
  min,
  max,
  step = 1,
  onInput,
  onStart,
  format,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  onInput: (value: number) => void;
  onStart?: () => void;
  format?: (value: number) => string;
}) {
  return (
    <label className="range-field">
      <span className="range-head">
        <span>{label}</span>
        <em>{format ? format(value) : value}</em>
      </span>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onPointerDown={onStart}
        onChange={(event) => onInput(Number(event.target.value))}
      />
    </label>
  );
}

export function ToggleRow({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (checked: boolean) => void;
}) {
  return (
    <button
      type="button"
      className={`toggle-row${checked ? ' is-on' : ''}`}
      onClick={() => onChange(!checked)}
    >
      <span>{label}</span>
      <span className="toggle-track">
        <span className="toggle-knob" />
      </span>
    </button>
  );
}
