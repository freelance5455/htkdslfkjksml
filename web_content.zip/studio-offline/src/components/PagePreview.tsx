import type { CSSProperties } from 'react';
import type { Design, Page } from '../types';
import { backgroundCss } from '../lib/background';
import { ElementView } from './ElementView';

export function PagePreview({
  design,
  page,
  width,
  className,
  style,
}: {
  design: Pick<Design, 'width' | 'height'>;
  page: Page;
  width: number;
  className?: string;
  style?: CSSProperties;
}) {
  const scale = width / design.width;
  return (
    <div
      className={className}
      style={{
        width,
        height: design.height * scale,
        position: 'relative',
        overflow: 'hidden',
        ...style,
      }}
    >
      <div
        style={{
          width: design.width,
          height: design.height,
          transform: `scale(${scale})`,
          transformOrigin: 'top left',
          position: 'absolute',
          inset: 0,
          ...backgroundCss(page.background),
        }}
      >
        {page.elements.map((element) => (
          <div
            key={element.id}
            style={{
              position: 'absolute',
              left: element.x,
              top: element.y,
              width: element.w,
              height: element.h,
              transform: `rotate(${element.rotation}deg)`,
              opacity: element.opacity,
            }}
          >
            <ElementView element={element} />
          </div>
        ))}
      </div>
    </div>
  );
}
