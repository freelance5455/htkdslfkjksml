import { useCallback, useEffect, useRef, useState } from 'react';
import type { PointerEvent as ReactPointerEvent } from 'react';
import type { Design, DesignElement, Page } from '../types';
import { clone } from '../types';
import { backgroundCss } from '../lib/background';
import type { DocApi } from '../lib/useEditorDoc';
import { ElementView } from './ElementView';

const HANDLES = ['nw', 'n', 'ne', 'e', 'se', 's', 'sw', 'w'] as const;
type Handle = (typeof HANDLES)[number];

type DragState = {
  mode: 'move' | 'resize' | 'rotate';
  handle: Handle | null;
  startX: number;
  startY: number;
  origin: DesignElement;
  snapshot: Design;
  centerClientX: number;
  centerClientY: number;
  startAngle: number;
  moved: boolean;
};

export function Stage({
  doc,
  page,
  selectedId,
  onSelect,
  editingId,
  onEdit,
}: {
  doc: DocApi;
  page: Page;
  selectedId: string | null;
  onSelect: (id: string | null) => void;
  editingId: string | null;
  onEdit: (id: string | null) => void;
}) {
  const design = doc.design;
  const scrollRef = useRef<HTMLDivElement>(null);
  const artboardRef = useRef<HTMLDivElement>(null);
  const [zoom, setZoom] = useState(0.4);
  const zoomRef = useRef(zoom);
  zoomRef.current = zoom;
  const [autoFit, setAutoFit] = useState(true);
  const [guides, setGuides] = useState<{ v: number[]; h: number[] }>({ v: [], h: [] });
  const dragRef = useRef<DragState | null>(null);
  const editSnapshotRef = useRef<Design | null>(null);

  const selected = page.elements.find((element) => element.id === selectedId) ?? null;

  const fit = useCallback(() => {
    const container = scrollRef.current;
    if (!container) return;
    const next = Math.min(
      (container.clientWidth - 104) / design.width,
      (container.clientHeight - 128) / design.height,
      1,
    );
    setZoom(Math.max(0.05, next));
  }, [design.width, design.height]);

  useEffect(() => {
    if (!autoFit) return;
    const frame = requestAnimationFrame(fit);
    return () => cancelAnimationFrame(frame);
  }, [fit, autoFit]);

  useEffect(() => {
    const container = scrollRef.current;
    if (!container) return;
    const observer = new ResizeObserver(() => {
      if (autoFit) fit();
    });
    observer.observe(container);
    return () => observer.disconnect();
  }, [autoFit, fit]);

  const patchElement = (id: string, changes: Partial<DesignElement>) => {
    doc.update((draft) => {
      const index = draft.pages.findIndex((candidate) => candidate.id === page.id);
      if (index < 0) return;
      const element = draft.pages[index].elements.find((candidate) => candidate.id === id);
      if (element) Object.assign(element, changes);
    });
  };

  const beginDrag = (
    event: ReactPointerEvent,
    element: DesignElement,
    mode: DragState['mode'],
    handle: Handle | null = null,
  ) => {
    if (editingId) {
      if (editingId === element.id) return;
      finishEditing();
    }
    if (element.locked && mode !== 'move') return;
    event.stopPropagation();
    event.preventDefault();
    onSelect(element.id);

    const rect = artboardRef.current?.getBoundingClientRect();
    const width = element.w * zoomRef.current;
    const height = element.h * zoomRef.current;
    const left = rect ? rect.left + element.x * zoomRef.current : 0;
    const top = rect ? rect.top + element.y * zoomRef.current : 0;
    const centerClientX = left + width / 2;
    const centerClientY = top + height / 2;

    (event.currentTarget as HTMLElement).setPointerCapture?.(event.pointerId);
    dragRef.current = {
      mode,
      handle,
      startX: event.clientX,
      startY: event.clientY,
      origin: clone(element),
      snapshot: doc.snapshot(),
      centerClientX,
      centerClientY,
      startAngle:
        (Math.atan2(event.clientY - centerClientY, event.clientX - centerClientX) * 180) / Math.PI,
      moved: false,
    };
  };

  const onPointerMove = (event: ReactPointerEvent) => {
    const drag = dragRef.current;
    if (!drag) return;
    event.preventDefault();
    const zoomNow = zoomRef.current;
    let dx = (event.clientX - drag.startX) / zoomNow;
    let dy = (event.clientY - drag.startY) / zoomNow;
    if (Math.abs(dx) > 0.5 || Math.abs(dy) > 0.5) drag.moved = true;
    const origin = drag.origin;

    if (drag.mode === 'move') {
      let x = origin.x + dx;
      let y = origin.y + dy;
      const threshold = 7 / zoomNow;
      const verticalTargets = [0, design.width / 2, design.width];
      const horizontalTargets = [0, design.height / 2, design.height];
      const activeV: number[] = [];
      const activeH: number[] = [];

      for (const edge of [x, x + origin.w / 2, x + origin.w]) {
        for (const target of verticalTargets) {
          if (Math.abs(edge - target) < threshold) {
            x += target - edge;
            activeV.push(target);
          }
        }
      }
      for (const edge of [y, y + origin.h / 2, y + origin.h]) {
        for (const target of horizontalTargets) {
          if (Math.abs(edge - target) < threshold) {
            y += target - edge;
            activeH.push(target);
          }
        }
      }

      setGuides({ v: Array.from(new Set(activeV)), h: Array.from(new Set(activeH)) });
      patchElement(origin.id, { x: Math.round(x), y: Math.round(y) });
      return;
    }

    if (drag.mode === 'resize' && drag.handle) {
      const handle = drag.handle;
      let x = origin.x;
      let y = origin.y;
      let w = origin.w;
      let h = origin.h;

      if (handle.includes('e')) w = Math.max(24, origin.w + dx);
      if (handle.includes('s')) h = Math.max(24, origin.h + dy);
      if (handle.includes('w')) {
        w = Math.max(24, origin.w - dx);
        x = origin.x + origin.w - w;
      }
      if (handle.includes('n')) {
        h = Math.max(24, origin.h - dy);
        y = origin.y + origin.h - h;
      }

      if (event.shiftKey && handle.length === 2) {
        const ratio = origin.w / origin.h;
        h = w / ratio;
        if (handle.includes('n')) y = origin.y + origin.h - h;
      }

      patchElement(origin.id, {
        x: Math.round(x),
        y: Math.round(y),
        w: Math.round(w),
        h: Math.round(h),
      });
      return;
    }

    if (drag.mode === 'rotate') {
      const angle =
        (Math.atan2(event.clientY - drag.centerClientY, event.clientX - drag.centerClientX) * 180) /
        Math.PI;
      let rotation = origin.rotation + (angle - drag.startAngle);
      if (event.shiftKey) rotation = Math.round(rotation / 15) * 15;
      patchElement(origin.id, { rotation: Math.round(rotation) });
    }
  };

  const endDrag = () => {
    const drag = dragRef.current;
    dragRef.current = null;
    setGuides({ v: [], h: [] });
    if (!drag) return;
    if (drag.moved) doc.pushHistory(drag.snapshot);
  };

  const startEditing = (element: DesignElement) => {
    if (element.type !== 'text') return;
    editSnapshotRef.current = doc.snapshot();
    onEdit(element.id);
    onSelect(element.id);
  };

  const finishEditing = () => {
    const snapshot = editSnapshotRef.current;
    editSnapshotRef.current = null;
    onEdit(null);
    if (!snapshot) return;
    const before = snapshot.pages.flatMap((candidate) => candidate.elements).find(
      (element) => element.id === editingId,
    );
    const after = page.elements.find((element) => element.id === editingId);
    if (before?.type === 'text' && after?.type === 'text' && before.text !== after.text) {
      doc.pushHistory(snapshot);
    }
  };

  const changeZoom = (factor: number) => {
    setAutoFit(false);
    setZoom((current) => Math.min(3, Math.max(0.05, current * factor)));
  };

  return (
    <div className="stage-shell">
    <div
      className="stage"
      ref={scrollRef}
      onPointerMove={onPointerMove}
      onPointerUp={endDrag}
      onPointerCancel={endDrag}
      onPointerDown={(event) => {
        if (event.target === event.currentTarget) {
          onSelect(null);
          onEdit(null);
        }
      }}
    >
      <div
        className="artboard"
        ref={artboardRef}
        style={{ width: design.width * zoom, height: design.height * zoom }}
        onPointerDown={(event) => {
          if (event.target === event.currentTarget) {
            onSelect(null);
            onEdit(null);
          }
        }}
      >
        <div
          className="artboard-art"
          style={{
            width: design.width,
            height: design.height,
            transform: `scale(${zoom})`,
            ...backgroundCss(page.background),
          }}
          onPointerDown={(event) => {
            if (event.target === event.currentTarget) {
              onSelect(null);
              onEdit(null);
            }
          }}
        >
          {page.elements.map((element) => (
            <div
              key={element.id}
              className={`element${selectedId === element.id ? ' is-selected' : ''}`}
              style={{
                left: element.x,
                top: element.y,
                width: element.w,
                height: element.h,
                transform: `rotate(${element.rotation}deg)`,
                opacity: element.opacity,
                cursor: element.locked ? 'default' : editingId === element.id ? 'text' : 'move',
              }}
              onPointerDown={(event) => beginDrag(event, element, 'move')}
              onDoubleClick={(event) => {
                event.stopPropagation();
                if (!element.locked) startEditing(element);
              }}
            >
              <ElementView
                element={element}
                editing={editingId === element.id}
                onTextInput={(text) =>
                  doc.update((draft) => {
                    const targetPage = draft.pages.find((candidate) => candidate.id === page.id);
                    const target = targetPage?.elements.find(
                      (candidate) => candidate.id === element.id,
                    );
                    if (target && target.type === 'text') target.text = text;
                  })
                }
                onTextBlur={finishEditing}
              />
            </div>
          ))}
        </div>

        <div
          className="artboard-ui"
          style={{
            width: design.width,
            height: design.height,
            transform: `scale(${zoom})`,
          }}
        >
          {guides.v.map((position) => (
            <div
              key={`v-${position}`}
              className="guide guide-v"
              style={{ left: position, width: 1.5 / zoom }}
            />
          ))}
          {guides.h.map((position) => (
            <div
              key={`h-${position}`}
              className="guide guide-h"
              style={{ top: position, height: 1.5 / zoom }}
            />
          ))}

          {selected && editingId !== selected.id ? (
            <div
              className="selection"
              style={{
                left: selected.x,
                top: selected.y,
                width: selected.w,
                height: selected.h,
                transform: `rotate(${selected.rotation}deg)`,
                ['--z' as string]: zoom,
              }}
            >
              <div className="selection-ring" />
              <div className="selection-tag">{selected.type === 'text' ? 'Text' : selected.type}</div>
              {!selected.locked
                ? HANDLES.map((handle) => (
                    <div
                      key={handle}
                      className={`handle handle-${handle}`}
                      onPointerDown={(event) => beginDrag(event, selected, 'resize', handle)}
                    />
                  ))
                : null}
              {!selected.locked ? (
                <div className="rotate-wrap">
                  <div className="rotate-stem" />
                  <button
                    type="button"
                    className="rotate-handle"
                    aria-label="Rotate"
                    onPointerDown={(event) => beginDrag(event, selected, 'rotate')}
                  />
                </div>
              ) : null}
            </div>
          ) : null}

          {page.elements.length === 0 ? (
            <div className="empty-hint">
              <span>Empty page</span>
              <p>Add text, shapes or an image — or start from a template.</p>
            </div>
          ) : null}
        </div>
      </div>
      </div>

      <div className="zoom-controls">
        <button type="button" onClick={() => changeZoom(1 / 1.15)} aria-label="Zoom out">
          −
        </button>
        <button
          type="button"
          className="zoom-value"
          onClick={() => {
            setAutoFit(true);
            fit();
          }}
          title="Fit to screen"
        >
          {Math.round(zoom * 100)}%
        </button>
        <button type="button" onClick={() => changeZoom(1.15)} aria-label="Zoom in">
          +
        </button>
      </div>
    </div>
  );
}
