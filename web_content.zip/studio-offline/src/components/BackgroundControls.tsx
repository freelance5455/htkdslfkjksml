import type { Background, Pattern } from '../types';
import { MOODS } from '../palettes';
import { SwatchGrid } from './controls';

const PATTERNS: { id: Pattern; label: string }[] = [
  { id: 'none', label: 'Solid' },
  { id: 'grid', label: 'Grid' },
  { id: 'dots', label: 'Dots' },
];

export function BackgroundControls({
  background,
  onChange,
  compact = false,
}: {
  background: Background;
  onChange: (background: Background) => void;
  compact?: boolean;
}) {
  const set = (patch: Partial<Background>) => onChange({ ...background, ...patch });

  return (
    <div className="bg-controls">
      <div className="mood-mini-list">
        {MOODS.map((mood) => (
          <div className="mood-mini" key={mood.id}>
            <span>{mood.name}</span>
            <div className="mood-mini-swatches">
              {mood.swatches.slice(0, 3).map((swatch) => (
                <button
                  key={swatch.hex}
                  type="button"
                  title={`${swatch.name} ${swatch.hex}`}
                  style={{ background: swatch.hex }}
                  onClick={() => set({ color: swatch.hex, gradient: null })}
                />
              ))}
            </div>
          </div>
        ))}
      </div>

      <div className="pattern-row">
        {PATTERNS.map((pattern) => (
          <button
            key={pattern.id}
            type="button"
            className={`pattern-btn${background.pattern === pattern.id ? ' is-active' : ''}`}
            onClick={() => set({ pattern: pattern.id })}
          >
            <span className={`pattern-swatch pattern-${pattern.id}`} />
            {pattern.label}
          </button>
        ))}
      </div>

      <SwatchGrid
        value={background.gradient ? background.gradient.from : background.color}
        columns={compact ? 7 : 8}
        onChange={(hex) => {
          if (background.gradient) set({ gradient: { ...background.gradient, from: hex } });
          else set({ color: hex });
        }}
      />

      <label className="gradient-toggle">
        <input
          type="checkbox"
          checked={!!background.gradient}
          onChange={(event) =>
            set({
              gradient: event.target.checked
                ? { from: background.color, to: '#FEFDFE', angle: 135 }
                : null,
            })
          }
        />
        <span>Gradient</span>
      </label>

      {background.gradient ? (
        <div className="gradient-controls">
          <div className="gradient-stops">
            <label>
              <span>From</span>
              <input
                type="color"
                value={background.gradient.from}
                onChange={(event) =>
                  set({ gradient: { ...background.gradient!, from: event.target.value } })
                }
              />
            </label>
            <label>
              <span>To</span>
              <input
                type="color"
                value={background.gradient.to}
                onChange={(event) =>
                  set({ gradient: { ...background.gradient!, to: event.target.value } })
                }
              />
            </label>
            <button
              type="button"
              className="mini-btn"
              onClick={() =>
                set({
                  gradient: {
                    ...background.gradient!,
                    from: background.gradient!.to,
                    to: background.gradient!.from,
                  },
                })
              }
            >
              Swap
            </button>
          </div>
          <label className="range-field">
            <span className="range-head">
              <span>Angle</span>
              <em>{background.gradient.angle}°</em>
            </span>
            <input
              type="range"
              min={0}
              max={360}
              value={background.gradient.angle}
              onChange={(event) =>
                set({ gradient: { ...background.gradient!, angle: Number(event.target.value) } })
              }
            />
          </label>
        </div>
      ) : null}
    </div>
  );
}
