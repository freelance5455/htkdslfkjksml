const PATHS: Record<string, string> = {
  back: 'M15 4 7 12l8 8',
  forward: 'M9 4l8 8-8 8',
  undo: 'M9 6 4 11l5 5M4 11h8a5 5 0 0 1 0 10H8',
  redo: 'M15 6l5 5-5 5M20 11h-8a5 5 0 0 0 0 10h4',
  templates: 'M3 3h8v8H3zM13 3h8v8h-8zM3 13h8v8H3zM13 13h8v8h-8z',
  text: 'M5 7V5h14v2M12 5v14M9 19h6',
  shapes: 'M3 4h8v8H3zM16 4a4 4 0 1 0 0 8 4 4 0 0 0 0-8zM8 14l4 6H4z',
  upload: 'M12 16V4M6 10l6-6 6 6M4 20h16',
  image: 'M3 4h18v16H3zM3 16l5-5 4 4 3-3 6 6',
  palette:
    'M12 3a9 9 0 1 0 0 18h1.3a2 2 0 0 0 1.4-3.4 2 2 0 0 1 1.4-3.4H20a1 1 0 0 0 1-1A9 9 0 0 0 12 3zM7.5 9.5h.01M11 7h.01M15 8h.01M7 14h.01',
  download: 'M12 4v12M7 11l5 5 5-5M4 20h16',
  plus: 'M12 5v14M5 12h14',
  trash: 'M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 11v6M14 11v6',
  duplicate: 'M8 8h12v12H8zM4 16V4h12',
  lock: 'M6 11h12v9H6zM9 11V8a3 3 0 0 1 6 0v3',
  unlock: 'M6 11h12v9H6zM9 11V8a3 3 0 0 1 6 0',
  layers: 'M12 3 3 8l9 5 9-5-9-5zM3 12.5l9 5 9-5',
  close: 'M6 6l12 12M18 6 6 18',
  more: 'M5 12h.01M12 12h.01M19 12h.01',
  check: 'M5 13l4 4L19 7',
  front: 'M12 3v10M8 9l4-4 4 4M4 20h16',
  sendback: 'M12 21V11M8 15l4 4 4-4M4 4h16',
  up: 'M12 20V5M6 11l6-6 6 6',
  down: 'M12 4v15M6 13l6 6 6-6',
  sparkle: 'M12 3l2.1 5.9L20 11l-5.9 2.1L12 19l-2.1-5.9L4 11l5.9-2.1L12 3z',
};

const DOTTED = new Set(['more']);

export function UiIcon({ name, size = 20 }: { name: string; size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.8}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      style={{ display: 'block', flex: 'none' }}
    >
      <path d={PATHS[name] ?? PATHS.sparkle} strokeWidth={DOTTED.has(name) ? 3.2 : 1.8} />
    </svg>
  );
}
