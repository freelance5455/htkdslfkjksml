import { useRef, useState } from 'react';
import type { Background, Design, DesignElement, MoodId, Page } from '../types';
import { readableInk, uid } from '../types';
import { ICONS } from '../data/icons';
import { SHAPE_OPTIONS } from '../lib/shapes';
import { TEMPLATES } from '../data/templates';
import type { Template } from '../data/templates';
import { newImage, newShape, newSticker, newText } from '../lib/factory';
import { loadImage } from '../lib/render';
import { readImageFile } from '../lib/export';
import { saveUpload } from '../lib/idb';
import type { Upload } from '../lib/idb';
import { DEFAULT_SWATCHES } from '../palettes';
import { PagePreview } from './PagePreview';
import { BackgroundControls } from './BackgroundControls';
import { UiIcon } from './UiIcon';

export type LeftTab = 'templates' | 'text' | 'elements' | 'uploads' | 'background';

export function LeftPanel({
  tab,
  design,
  page,
  pageIndex,
  onAdd,
  onBackground,
  onApplyTemplate,
  uploads,
  onUploads,
}: {
  tab: LeftTab;
  design: Design;
  page: Page;
  pageIndex: number;
  onAdd: (element: DesignElement) => void;
  onBackground: (background: Background) => void;
  onApplyTemplate: (template: Template) => void;
  uploads: Upload[];
  onUploads: (uploads: Upload[]) => void;
}) {
  const ink = readableInk(page.background);
  const fileRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleUpload = async (files: FileList | null) => {
    if (!files?.length) return;
    setBusy(true);
    setError(null);
    try {
      const next: Upload[] = [];
      for (const file of Array.from(files)) {
        if (!file.type.startsWith('image/')) continue;
        const { src, width, height } = await readImageFile(file);
        const upload: Upload = {
          id: uid('up'),
          name: file.name.replace(/\.[^.]+$/, ''),
          src,
          createdAt: Date.now(),
        };
        await saveUpload(upload);
        next.push(upload);
      }
      onUploads([...next, ...uploads]);
    } catch (uploadError) {
      setError(uploadError instanceof Error ? uploadError.message : 'Upload failed');
    } finally {
      setBusy(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  };

  const addUpload = async (upload: Upload) => {
    const image = await loadImage(upload.src);
    onAdd(newImage(upload.src, image.naturalWidth, image.naturalHeight));
  };

  const addText = (options: Parameters<typeof newText>[0]) =>
    onAdd(newText({ ...options, color: ink }));

  return (
    <div className="panel-scroll">
      {tab === 'templates' ? (
        <>
          <div className="panel-heading">
            <h2>Templates</h2>
            <p>Pick a mood, then make it yours.</p>
          </div>
          <div className="template-grid">
            {TEMPLATES.map((template) => {
              const preview = template.build();
              return (
                <button
                  key={template.id}
                  type="button"
                  className="template-card"
                  onClick={() => onApplyTemplate(template)}
                >
                  <PagePreview
                    design={{ width: template.width, height: template.height }}
                    page={preview}
                    width={108}
                    className="template-preview"
                  />
                  <span className="template-name">{template.name}</span>
                  <span className="template-tags">{template.tags.join(' · ')}</span>
                </button>
              );
            })}
          </div>
        </>
      ) : null}

      {tab === 'text' ? (
        <>
          <div className="panel-heading">
            <h2>Text</h2>
            <p>Click to add, double-click on the canvas to edit.</p>
          </div>
          <div className="text-presets">
            <button
              type="button"
              className="text-preset"
              onClick={() =>
                addText({
                  text: 'Add a heading',
                  font: 'display',
                  size: 96,
                  w: 780,
                  h: 140,
                  lineHeight: 1,
                })
              }
            >
              <span style={{ fontFamily: "'Archivo Black', sans-serif", fontSize: 40 }}>
                Add a heading
              </span>
            </button>
            <button
              type="button"
              className="text-preset"
              onClick={() =>
                addText({
                  text: 'Add a subheading',
                  font: 'grotesk',
                  size: 56,
                  weight: 500,
                  w: 680,
                  h: 90,
                })
              }
            >
              <span style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 28 }}>
                Add a subheading
              </span>
            </button>
            <button
              type="button"
              className="text-preset"
              onClick={() =>
                addText({
                  text: 'Add a little bit of body text',
                  font: 'sans',
                  size: 32,
                  w: 600,
                  h: 110,
                  lineHeight: 1.4,
                })
              }
            >
              <span style={{ fontFamily: "'Archivo', sans-serif", fontSize: 20 }}>
                Add a little bit of body text
              </span>
            </button>
            <button
              type="button"
              className="text-preset"
              onClick={() =>
                addText({
                  text: 'A serif statement',
                  font: 'serif',
                  size: 72,
                  weight: 700,
                  italic: true,
                  w: 720,
                  h: 120,
                })
              }
            >
              <span style={{ fontFamily: "'Playfair Display', serif", fontStyle: 'italic', fontSize: 30 }}>
                A serif statement
              </span>
            </button>
            <button
              type="button"
              className="text-preset"
              onClick={() =>
                addText({
                  text: 'SMALL CAPS LABEL',
                  font: 'mono',
                  size: 24,
                  w: 460,
                  h: 40,
                  letterSpacing: 2,
                  uppercase: true,
                })
              }
            >
              <span style={{ fontFamily: 'ui-monospace, monospace', fontSize: 16, letterSpacing: 2 }}>
                SMALL CAPS LABEL
              </span>
            </button>
          </div>
        </>
      ) : null}

      {tab === 'elements' ? (
        <>
          <div className="panel-heading">
            <h2>Elements</h2>
            <p>Shapes, lines and sticker-style marks.</p>
          </div>
          <div className="shape-grid">
            {SHAPE_OPTIONS.map((shape) => (
              <button
                key={shape.id}
                type="button"
                title={shape.label}
                onClick={() =>
                  onAdd(
                    newShape({
                      shape: shape.id,
                      fill: ink,
                      radius: shape.id === 'rect' ? 0 : 0,
                      w: shape.id === 'line' ? 420 : 220,
                      h: shape.id === 'line' ? 8 : 220,
                    }),
                  )
                }
              >
                <span className={`shape-chip shape-chip-${shape.id}`} style={{ color: ink }} />
              </button>
            ))}
          </div>

          <div className="panel-heading sub">
            <h2>Stickers</h2>
            <p>Free marks to scribble on your design.</p>
          </div>
          <div className="sticker-grid">
            {ICONS.map((icon) => (
              <button
                key={icon.id}
                type="button"
                title={icon.name}
                onClick={() => onAdd(newSticker({ icon: icon.id, color: ink }))}
              >
                <svg viewBox={`0 0 ${icon.vb} ${icon.vb}`} width="26" height="26" aria-hidden="true">
                  <path
                    d={icon.d}
                    fill={icon.mode === 'fill' ? 'currentColor' : 'none'}
                    stroke={icon.mode === 'stroke' ? 'currentColor' : 'none'}
                    strokeWidth={icon.stroke ?? 8}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </button>
            ))}
          </div>
        </>
      ) : null}

      {tab === 'uploads' ? (
        <>
          <div className="panel-heading">
            <h2>Uploads</h2>
            <p>Photos stay on this device. Nothing is uploaded anywhere.</p>
          </div>
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            multiple
            hidden
            onChange={(event) => handleUpload(event.target.files)}
          />
          <button
            type="button"
            className="dropzone"
            onClick={() => fileRef.current?.click()}
            onDragOver={(event) => event.preventDefault()}
            onDrop={(event) => {
              event.preventDefault();
              handleUpload(event.dataTransfer.files);
            }}
          >
            <UiIcon name="upload" size={22} />
            <strong>{busy ? 'Reading image…' : 'Upload an image'}</strong>
            <span>or drop a file here</span>
          </button>
          {error ? <p className="panel-error">{error}</p> : null}
          {uploads.length ? (
            <div className="upload-grid">
              {uploads.map((upload) => (
                <button
                  key={upload.id}
                  type="button"
                  className="upload-tile"
                  onClick={() => addUpload(upload)}
                  title={upload.name}
                >
                  <img src={upload.src} alt={upload.name} />
                </button>
              ))}
            </div>
          ) : (
            <p className="panel-muted">No uploads yet. Images you add are saved on this device.</p>
          )}
        </>
      ) : null}

      {tab === 'background' ? (
        <>
          <div className="panel-heading">
            <h2>Background</h2>
            <p>Page {pageIndex + 1} · {design.width} × {design.height}px</p>
          </div>
          <BackgroundControls background={page.background} onChange={onBackground} />
          <div className="panel-heading sub">
            <h2>Quick palettes</h2>
          </div>
          <div className="palette-list">
            {DEFAULT_SWATCHES.slice(0, 15).map((swatch) => (
              <button
                key={`${swatch.name}-${swatch.hex}`}
                type="button"
                className="palette-row"
                onClick={() => onBackground({ ...page.background, color: swatch.hex, gradient: null })}
              >
                <span style={{ background: swatch.hex }} />
                <strong>{swatch.name}</strong>
                <code>{swatch.hex}</code>
              </button>
            ))}
          </div>
        </>
      ) : null}
    </div>
  );
}
