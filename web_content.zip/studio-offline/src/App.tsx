import { useCallback, useEffect, useState } from 'react';
import type { Design, MoodId, PageSize } from './types';
import { clone, uid } from './types';
import { Home } from './components/Home';
import { Editor } from './components/Editor';
import { createDesign, designFromTemplate } from './data/templates';
import type { Template } from './data/templates';
import { deleteDesign, listDesigns, saveDesign } from './lib/idb';
import { importProjectFile } from './lib/export';

type InstallEvent = Event & { prompt: () => Promise<void>; userChoice?: Promise<unknown> };

const MOOD_KEY = 'studio.mood';

export default function App() {
  const [designs, setDesigns] = useState<Design[] | null>(null);
  const [active, setActive] = useState<Design | null>(null);
  const [mood, setMood] = useState<MoodId>(() => {
    const stored = localStorage.getItem(MOOD_KEY) as MoodId | null;
    return stored && ['club', 'court', 'studio'].includes(stored) ? stored : 'club';
  });
  const [installEvent, setInstallEvent] = useState<InstallEvent | null>(null);

  const refresh = useCallback(async () => {
    try {
      setDesigns(await listDesigns());
    } catch {
      setDesigns([]);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  useEffect(() => {
    document.documentElement.dataset.mood = mood;
    localStorage.setItem(MOOD_KEY, mood);
  }, [mood]);

  useEffect(() => {
    const handler = (event: Event) => {
      event.preventDefault();
      setInstallEvent(event as InstallEvent);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const install = async () => {
    if (!installEvent) return;
    await installEvent.prompt();
    setInstallEvent(null);
  };

  const openDesign = async (design: Design) => {
    await saveDesign(design);
    setActive(design);
    refresh();
  };

  const createNew = async (size: PageSize | null) => {
    const design = createDesign({
      name: size?.name ?? 'Untitled design',
      width: size?.width ?? 1080,
      height: size?.height ?? 1350,
      mood,
    });
    await openDesign(design);
  };

  const createFromTemplate = async (template: Template) => {
    await openDesign(designFromTemplate(template));
  };

  const duplicate = async (design: Design) => {
    const now = Date.now();
    const copy: Design = {
      ...clone(design),
      id: uid('ds'),
      name: `${design.name} copy`,
      createdAt: now,
      updatedAt: now,
      thumb: undefined,
      pages: design.pages.map((page) => ({
        ...page,
        id: uid('pg'),
        elements: page.elements.map((element) => ({ ...element, id: uid() })),
      })),
    };
    await saveDesign(copy);
    await refresh();
  };

  const remove = async (design: Design) => {
    if (!window.confirm(`Delete "${design.name}"? This cannot be undone.`)) return;
    await deleteDesign(design.id);
    await refresh();
  };

  const importDesign = async (file: File) => {
    try {
      const imported = await importProjectFile(file);
      const now = Date.now();
      const design: Design = {
        ...imported,
        id: uid('ds'),
        name: imported.name || 'Imported design',
        createdAt: now,
        updatedAt: now,
        mood: imported.mood ?? mood,
        thumb: undefined,
      };
      await openDesign(design);
    } catch (error) {
      window.alert(error instanceof Error ? error.message : 'Could not import that file.');
    }
  };

  if (active) {
    return (
      <Editor
        key={active.id}
        initial={active}
        onExit={() => {
          setActive(null);
          refresh();
        }}
      />
    );
  }

  return (
    <Home
      designs={designs}
      mood={mood}
      onMood={setMood}
      onOpen={openDesign}
      onNew={createNew}
      onTemplate={createFromTemplate}
      onDuplicate={duplicate}
      onDelete={remove}
      onImport={importDesign}
      canInstall={!!installEvent}
      onInstall={install}
    />
  );
}
