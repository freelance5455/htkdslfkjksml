import { useCallback, useRef, useState } from 'react';
import type { Design } from '../types';
import { clone } from '../types';

const HISTORY_LIMIT = 60;

export type DocApi = {
  design: Design;
  /** Mutate without recording history (live drags, typing). */
  update: (mutate: (draft: Design) => void) => void;
  /** Mutate and record an undo step. */
  commit: (mutate: (draft: Design) => void) => void;
  snapshot: () => Design;
  pushHistory: (snapshot: Design) => void;
  replace: (design: Design) => void;
  undo: () => void;
  redo: () => void;
  canUndo: boolean;
  canRedo: boolean;
  revision: number;
};

export function useEditorDoc(initial: Design): DocApi {
  const [design, setDesign] = useState(initial);
  const designRef = useRef(design);
  designRef.current = design;
  const past = useRef<Design[]>([]);
  const future = useRef<Design[]>([]);
  const [, forceRender] = useState(0);
  const bump = () => forceRender((value) => value + 1);

  const apply = useCallback((mutate: (draft: Design) => void, record: boolean) => {
    const previous = designRef.current;
    const draft = clone(previous);
    mutate(draft);
    draft.updatedAt = Date.now();
    if (record) {
      past.current = [...past.current.slice(-HISTORY_LIMIT + 1), previous];
      future.current = [];
    }
    designRef.current = draft;
    setDesign(draft);
    if (record) bump();
  }, []);

  const update = useCallback((mutate: (draft: Design) => void) => apply(mutate, false), [apply]);
  const commit = useCallback((mutate: (draft: Design) => void) => apply(mutate, true), [apply]);

  const snapshot = useCallback(() => clone(designRef.current), []);
  const pushHistory = useCallback((snap: Design) => {
    past.current = [...past.current.slice(-HISTORY_LIMIT + 1), snap];
    future.current = [];
    bump();
  }, []);

  const replace = useCallback((next: Design) => {
    past.current = [...past.current.slice(-HISTORY_LIMIT + 1), designRef.current];
    future.current = [];
    designRef.current = next;
    setDesign(next);
    bump();
  }, []);

  const undo = useCallback(() => {
    const previous = past.current.pop();
    if (!previous) return;
    future.current = [clone(designRef.current), ...future.current].slice(0, HISTORY_LIMIT);
    designRef.current = previous;
    setDesign(previous);
    bump();
  }, []);

  const redo = useCallback(() => {
    const [next, ...rest] = future.current;
    if (!next) return;
    future.current = rest;
    past.current = [...past.current, clone(designRef.current)];
    designRef.current = next;
    setDesign(next);
    bump();
  }, []);

  return {
    design,
    update,
    commit,
    snapshot,
    pushHistory,
    replace,
    undo,
    redo,
    canUndo: past.current.length > 0,
    canRedo: future.current.length > 0,
    revision: design.updatedAt,
  };
}
