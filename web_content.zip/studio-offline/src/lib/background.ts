import type { Background } from '../types';
import { pageLuminance } from '../types';

export const GRID_SIZE = 64;
export const DOT_SIZE = 40;

export const patternColor = (background: Background) =>
  pageLuminance(background) > 0.45 ? 'rgba(20, 3, 15, 0.13)' : 'rgba(255, 255, 255, 0.24)';

export function backgroundCss(background: Background): React.CSSProperties {
  const layers: string[] = [];
  if (background.pattern === 'grid') {
    const line = patternColor(background);
    layers.push(
      `repeating-linear-gradient(0deg, ${line} 0 1px, transparent 1px ${GRID_SIZE}px)`,
      `repeating-linear-gradient(90deg, ${line} 0 1px, transparent 1px ${GRID_SIZE}px)`,
    );
  } else if (background.pattern === 'dots') {
    const line = patternColor(background);
    layers.push(`radial-gradient(${line} 1.6px, transparent 1.6px)`);
  }

  if (background.gradient) {
    const { from, to, angle } = background.gradient;
    layers.push(`linear-gradient(${angle}deg, ${from}, ${to})`);
  } else {
    layers.push(background.color);
  }

  return {
    backgroundColor: background.gradient ? undefined : background.color,
    backgroundImage: layers.join(', '),
    backgroundSize:
      background.pattern === 'dots' ? `${DOT_SIZE}px ${DOT_SIZE}px` : undefined,
  };
}
