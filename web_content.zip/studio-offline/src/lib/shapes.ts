export const SHAPE_PATHS: Record<string, string> = (() => {
  const cx = 50;
  const cy = 50;
  const outer = 50;
  const inner = 22;
  const starPoints: string[] = [];
  for (let i = 0; i < 10; i += 1) {
    const radius = i % 2 === 0 ? outer : inner;
    const angle = (Math.PI / 5) * i - Math.PI / 2;
    starPoints.push(`${(cx + Math.cos(angle) * radius).toFixed(2)} ${(cy + Math.sin(angle) * radius).toFixed(2)}`);
  }
  return {
    triangle: 'M50 0 L100 100 L0 100 Z',
    diamond: 'M50 0 L100 50 L50 100 L0 50 Z',
    star: `M${starPoints.join(' L')} Z`,
    arrow: 'M0 34 L66 34 L66 0 L100 50 L66 100 L66 66 L0 66 Z',
    blob: 'M78 24c14 12 20 30 12 44s-28 22-45 19S8 71 7 54 16 20 33 15s31-3 45 9Z',
  };
})();

export const SHAPE_OPTIONS = [
  { id: 'rect', label: 'Rectangle' },
  { id: 'pill', label: 'Pill' },
  { id: 'ellipse', label: 'Circle' },
  { id: 'triangle', label: 'Triangle' },
  { id: 'diamond', label: 'Diamond' },
  { id: 'star', label: 'Star' },
  { id: 'blob', label: 'Blob' },
  { id: 'arrow', label: 'Arrow' },
  { id: 'line', label: 'Line' },
] as const;
