import type {
  Background,
  Design,
  DesignElement,
  ImageElement,
  Page,
  ShapeElement,
  StickerElement,
  TextElement,
} from '../types';
import { ICON_MAP } from '../data/icons';
import { fontCss } from './fonts';
import { DOT_SIZE, GRID_SIZE, patternColor } from './background';
import { SHAPE_PATHS } from './shapes';

const imagePromises = new Map<string, Promise<HTMLImageElement>>();

export function loadImage(src: string): Promise<HTMLImageElement> {
  const cached = imagePromises.get(src);
  if (cached) return cached;
  const promise = new Promise<HTMLImageElement>((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error('Image could not be decoded'));
    image.src = src;
  });
  imagePromises.set(src, promise);
  return promise;
}

function roundRectPath(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  radius: number,
) {
  const r = Math.max(0, Math.min(radius, Math.min(w, h) / 2));
  ctx.beginPath();
  if (typeof ctx.roundRect === 'function') {
    ctx.roundRect(x, y, w, h, r);
    return;
  }
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

export function drawBackground(
  ctx: CanvasRenderingContext2D,
  background: Background,
  width: number,
  height: number,
  scale: number,
) {
  if (background.gradient) {
    const angle = (background.gradient.angle * Math.PI) / 180;
    const dx = Math.sin(angle);
    const dy = -Math.cos(angle);
    const length = Math.abs(width * dx) + Math.abs(height * dy);
    const cx = width / 2;
    const cy = height / 2;
    const gradient = ctx.createLinearGradient(
      cx - (dx * length) / 2,
      cy - (dy * length) / 2,
      cx + (dx * length) / 2,
      cy + (dy * length) / 2,
    );
    gradient.addColorStop(0, background.gradient.from);
    gradient.addColorStop(1, background.gradient.to);
    ctx.fillStyle = gradient;
  } else {
    ctx.fillStyle = background.color;
  }
  ctx.fillRect(0, 0, width * scale, height * scale);

  if (background.pattern === 'none') return;

  const line = patternColor(background);
  ctx.save();
  if (background.pattern === 'grid') {
    const step = GRID_SIZE * scale;
    ctx.strokeStyle = line;
    ctx.lineWidth = Math.max(1, scale);
    for (let x = 0; x <= width * scale; x += step) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height * scale);
      ctx.stroke();
    }
    for (let y = 0; y <= height * scale; y += step) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width * scale, y);
      ctx.stroke();
    }
  } else {
    const step = DOT_SIZE * scale;
    ctx.fillStyle = line;
    const radius = Math.max(1, 1.7 * scale);
    for (let x = step / 2; x < width * scale; x += step) {
      for (let y = step / 2; y < height * scale; y += step) {
        ctx.beginPath();
        ctx.arc(x, y, radius, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  }
  ctx.restore();
}

function drawShape(ctx: CanvasRenderingContext2D, element: ShapeElement, scale: number) {
  const w = element.w * scale;
  const h = element.h * scale;
  const radius = element.radius * scale;
  ctx.fillStyle = element.fill;

  switch (element.shape) {
    case 'rect':
    case 'pill': {
      roundRectPath(ctx, 0, 0, w, h, element.shape === 'pill' ? h / 2 : radius);
      ctx.fill();
      break;
    }
    case 'ellipse': {
      ctx.beginPath();
      ctx.ellipse(w / 2, h / 2, w / 2, h / 2, 0, 0, Math.PI * 2);
      ctx.fill();
      break;
    }
    case 'line': {
      ctx.fillRect(0, 0, w, Math.max(2, h));
      break;
    }
    default: {
      const path = SHAPE_PATHS[element.shape];
      if (path) {
        ctx.save();
        ctx.scale(w / 100, h / 100);
        ctx.fill(new Path2D(path));
        ctx.restore();
      } else {
        ctx.fillRect(0, 0, w, h);
      }
    }
  }
}

function drawText(
  ctx: CanvasRenderingContext2D,
  element: TextElement,
  width: number,
  height: number,
  scale: number,
) {
  const text = element.uppercase ? element.text.toUpperCase() : element.text;
  const font = fontCss(element.font, element.size, element.weight, element.italic, scale);
  ctx.font = font;
  ctx.fillStyle = element.color;
  const spacing = element.letterSpacing * scale;
  const canSpace = 'letterSpacing' in ctx;
  if (canSpace) {
    (ctx as CanvasRenderingContext2D & { letterSpacing: string }).letterSpacing = `${spacing}px`;
  }
  ctx.textBaseline = 'middle';
  ctx.textAlign = element.align === 'center' ? 'center' : element.align === 'right' ? 'right' : 'left';

  const maxWidth = width * scale;
  const lineHeight = element.size * element.lineHeight * scale;
  const lines = wrapText(ctx, text, maxWidth);
  const x = element.align === 'center' ? maxWidth / 2 : element.align === 'right' ? maxWidth : 0;

  lines.forEach((line, index) => {
    ctx.fillText(line, x, lineHeight * (index + 0.5));
  });

  if (canSpace) {
    (ctx as CanvasRenderingContext2D & { letterSpacing: string }).letterSpacing = '0px';
  }
}

export function wrapText(ctx: CanvasRenderingContext2D, text: string, maxWidth: number): string[] {
  const lines: string[] = [];
  for (const paragraph of text.split('\n')) {
    if (!paragraph.trim()) {
      lines.push('');
      continue;
    }
    const words = paragraph.split(/\s+/);
    let line = '';
    for (const word of words) {
      const candidate = line ? `${line} ${word}` : word;
      if (line && ctx.measureText(candidate).width > maxWidth) {
        lines.push(line);
        line = word;
      } else {
        line = candidate;
      }
    }
    lines.push(line);
  }
  return lines;
}

function drawSticker(ctx: CanvasRenderingContext2D, element: StickerElement, scale: number) {
  const icon = ICON_MAP[element.icon];
  if (!icon) return;
  const size = Math.min((element.w * scale) / icon.vb, (element.h * scale) / icon.vb);
  const offsetX = ((element.w * scale) - icon.vb * size) / 2;
  const offsetY = ((element.h * scale) - icon.vb * size) / 2;

  const path = new Path2D(icon.d);
  ctx.save();
  ctx.translate(offsetX, offsetY);
  ctx.scale(size, size);
  if (icon.mode === 'fill') {
    ctx.fillStyle = element.color;
    ctx.fill(path);
  } else {
    ctx.strokeStyle = element.color;
    ctx.lineWidth = icon.stroke ?? element.strokeWidth;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.stroke(path);
  }
  ctx.restore();
}

async function drawElement(
  ctx: CanvasRenderingContext2D,
  element: DesignElement,
  scale: number,
) {
  ctx.save();
  ctx.globalAlpha = element.opacity;
  ctx.translate((element.x + element.w / 2) * scale, (element.y + element.h / 2) * scale);
  ctx.rotate((element.rotation * Math.PI) / 180);
  ctx.translate((-element.w / 2) * scale, (-element.h / 2) * scale);

  if (element.type === 'text') {
    drawText(ctx, element, element.w, element.h, scale);
  } else if (element.type === 'shape') {
    drawShape(ctx, element, scale);
  } else if (element.type === 'sticker') {
    drawSticker(ctx, element, scale);
  } else if (element.type === 'image') {
    await drawImageElement(ctx, element, scale);
  }
  ctx.restore();
}

async function drawImageElement(
  ctx: CanvasRenderingContext2D,
  element: ImageElement,
  scale: number,
) {
  let image: HTMLImageElement;
  try {
    image = await loadImage(element.src);
  } catch {
    ctx.fillStyle = 'rgba(120,120,120,0.25)';
    ctx.fillRect(0, 0, element.w * scale, element.h * scale);
    return;
  }

  const w = element.w * scale;
  const h = element.h * scale;
  ctx.save();
  roundRectPath(ctx, 0, 0, w, h, element.radius * scale);
  ctx.clip();

  const imageRatio = image.width / image.height;
  const boxRatio = w / h;
  let drawW = w;
  let drawH = h;
  if (element.fit === 'cover' ? imageRatio > boxRatio : imageRatio < boxRatio) {
    drawH = h;
    drawW = h * imageRatio;
  } else {
    drawW = w;
    drawH = w / imageRatio;
  }
  ctx.drawImage(image, (w - drawW) / 2, (h - drawH) / 2, drawW, drawH);
  ctx.restore();
}

export async function drawPage(
  ctx: CanvasRenderingContext2D,
  design: Design,
  page: Page,
  scale: number,
  options: { transparent?: boolean } = {},
) {
  ctx.save();
  ctx.clearRect(0, 0, design.width * scale, design.height * scale);
  if (!options.transparent) {
    drawBackground(ctx, page.background, design.width, design.height, scale);
  }
  for (const element of page.elements) {
    await drawElement(ctx, element, scale);
  }
  ctx.restore();
}

export async function renderToCanvas(
  design: Design,
  page: Page,
  scale: number,
  options: { transparent?: boolean } = {},
): Promise<HTMLCanvasElement> {
  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, Math.round(design.width * scale));
  canvas.height = Math.max(1, Math.round(design.height * scale));
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas is not available in this browser');
  await drawPage(ctx, design, page, scale, options);
  return canvas;
}

export async function renderToDataUrl(
  design: Design,
  page: Page,
  scale: number,
  options: { transparent?: boolean; format?: 'png' | 'jpeg' | 'webp' } = {},
): Promise<string> {
  const canvas = await renderToCanvas(design, page, scale, options);
  const format = options.format ?? 'png';
  const mime = format === 'jpeg' ? 'image/jpeg' : format === 'webp' ? 'image/webp' : 'image/png';
  return canvas.toDataURL(mime, 0.92);
}

export async function renderThumbnail(design: Design, page: Page, width = 420): Promise<string> {
  const scale = Math.min(width / design.width, 560 / design.height);
  return renderToDataUrl(design, page, scale, { format: 'png' });
}
