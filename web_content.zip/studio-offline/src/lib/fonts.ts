import type { FontId } from '../types';

export const FONT_STACKS: Record<FontId, string> = {
  display: "'Archivo Black', Impact, 'Arial Black', sans-serif",
  sans: "'Archivo', 'Helvetica Neue', Arial, sans-serif",
  grotesk: "'Space Grotesk', 'Archivo', Arial, sans-serif",
  serif: "'Playfair Display', Georgia, 'Times New Roman', serif",
  mono: "'SFMono-Regular', ui-monospace, Menlo, Consolas, monospace",
};

export const FONT_OPTIONS: { id: FontId; label: string; sample: string }[] = [
  { id: 'display', label: 'Archivo Black', sample: 'Bold display' },
  { id: 'sans', label: 'Archivo', sample: 'Clean editorial' },
  { id: 'grotesk', label: 'Space Grotesk', sample: 'Modern geometric' },
  { id: 'serif', label: 'Playfair', sample: 'High contrast serif' },
  { id: 'mono', label: 'Mono', sample: 'Technical' },
];

export const fontCss = (
  font: FontId,
  size: number,
  weight: number,
  italic?: boolean,
  scale = 1,
) => `${italic ? 'italic ' : ''}${weight} ${size * scale}px ${FONT_STACKS[font]}`;
