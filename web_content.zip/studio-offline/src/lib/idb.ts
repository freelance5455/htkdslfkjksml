import type { Design } from '../types';

const DB_NAME = 'studio-offline';
const DB_VERSION = 1;
const DESIGNS = 'designs';
const UPLOADS = 'uploads';

export type Upload = { id: string; name: string; src: string; createdAt: number };

let dbPromise: Promise<IDBDatabase> | null = null;

function openDb(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(DESIGNS)) db.createObjectStore(DESIGNS, { keyPath: 'id' });
      if (!db.objectStoreNames.contains(UPLOADS)) db.createObjectStore(UPLOADS, { keyPath: 'id' });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error('Could not open local storage'));
  });
  return dbPromise;
}

function run<T>(store: string, mode: IDBTransactionMode, action: (s: IDBObjectStore) => IDBRequest | null): Promise<T> {
  return openDb().then(
    (db) =>
      new Promise<T>((resolve, reject) => {
        const transaction = db.transaction(store, mode);
        const request = action(transaction.objectStore(store));
        transaction.oncomplete = () => resolve((request ? request.result : undefined) as T);
        transaction.onerror = () => reject(transaction.error ?? new Error('Local storage error'));
        transaction.onabort = () => reject(transaction.error ?? new Error('Local storage aborted'));
      }),
  );
}

export async function listDesigns(): Promise<Design[]> {
  const designs = (await run<Design[]>(DESIGNS, 'readonly', (store) => store.getAll())) ?? [];
  return designs.sort((a, b) => b.updatedAt - a.updatedAt);
}

export function saveDesign(design: Design): Promise<unknown> {
  return run(DESIGNS, 'readwrite', (store) => store.put(design));
}

export function deleteDesign(id: string): Promise<unknown> {
  return run(DESIGNS, 'readwrite', (store) => store.delete(id));
}

export async function listUploads(): Promise<Upload[]> {
  const uploads = (await run<Upload[]>(UPLOADS, 'readonly', (store) => store.getAll())) ?? [];
  return uploads.sort((a, b) => b.createdAt - a.createdAt);
}

export function saveUpload(upload: Upload): Promise<unknown> {
  return run(UPLOADS, 'readwrite', (store) => store.put(upload));
}
