import type {
  DesignElement,
  ImageElement,
  ShapeElement,
  StickerElement,
  TextElement,
  BaseElement,
} from '../types';
import { uid } from '../types';

const base = (): BaseElement => ({
  id: uid(),
  x: 0,
  y: 0,
  w: 400,
  h: 200,
  rotation: 0,
  opacity: 1,
});

export function newText(patch: Partial<TextElement> = {}): TextElement {
  return {
    ...base(),
    type: 'text',
    text: 'Your text',
    font: 'display',
    size: 96,
    weight: 400,
    italic: false,
    lineHeight: 1,
    letterSpacing: 0,
    color: '#14030F',
    align: 'left',
    uppercase: false,
    w: 700,
    h: 130,
    ...patch,
  };
}

export function newShape(patch: Partial<ShapeElement> = {}): ShapeElement {
  return {
    ...base(),
    type: 'shape',
    shape: 'rect',
    fill: '#D13CD3',
    radius: 0,
    strokeWidth: 0,
    ...patch,
  };
}

export function newSticker(patch: Partial<StickerElement> = {}): StickerElement {
  return {
    ...base(),
    type: 'sticker',
    icon: 'sparkle',
    color: '#D13CD3',
    strokeWidth: 8,
    w: 180,
    h: 180,
    ...patch,
  };
}

export function newImage(src: string, naturalWidth: number, naturalHeight: number): ImageElement {
  const maxW = 640;
  const maxH = 640;
  const ratio = Math.min(maxW / naturalWidth, maxH / naturalHeight, 1);
  const w = Math.round(naturalWidth * ratio);
  const h = Math.round(naturalHeight * ratio);
  return {
    ...base(),
    type: 'image',
    src,
    fit: 'cover',
    radius: 0,
    w,
    h,
  };
}

export function duplicateElement(element: DesignElement): DesignElement {
  const copy = JSON.parse(JSON.stringify(element)) as DesignElement;
  copy.id = uid();
  copy.x += 24;
  copy.y += 24;
  return copy;
}
