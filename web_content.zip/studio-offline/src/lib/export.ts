import type { Design, Page } from '../types';
import { renderToDataUrl } from './render';

export type ExportFormat = 'png' | 'jpeg' | 'webp';

const slugify = (name: string) =>
  name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '') || 'design';

export function downloadUrl(url: string, filename: string) {
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
}

export async function exportPage(
  design: Design,
  page: Page,
  options: { scale: number; format: ExportFormat; transparent?: boolean },
) {
  await document.fonts.ready;
  const format = options.transparent && options.format === 'jpeg' ? 'png' : options.format;
  const url = await renderToDataUrl(design, page, options.scale, {
    transparent: options.transparent,
    format,
  });
  downloadUrl(url, `${slugify(design.name)}.${format === 'jpeg' ? 'jpg' : format}`);
  return url;
}

export function exportProject(design: Design) {
  const blob = new Blob([JSON.stringify(design, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  downloadUrl(url, `${slugify(design.name)}.studio.json`);
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

export function importProjectFile(file: File): Promise<Design> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(String(reader.result)) as Design;
        if (
          !data ||
          !Array.isArray(data.pages) ||
          data.pages.length === 0 ||
          !data.width ||
          !data.height
        ) {
          throw new Error('That file is not a Studio project');
        }
        resolve(data);
      } catch (error) {
        reject(error);
      }
    };
    reader.onerror = () => reject(new Error('Could not read that file'));
    reader.readAsText(file);
  });
}

export async function readImageFile(file: File): Promise<{ src: string; width: number; height: number }> {
  const src = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error('Could not read that image'));
    reader.readAsDataURL(file);
  });
  const size = await new Promise<{ width: number; height: number }>((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve({ width: image.naturalWidth, height: image.naturalHeight });
    image.onerror = () => reject(new Error('That image format is not supported'));
    image.src = src;
  });
  return { src, ...size };
}
