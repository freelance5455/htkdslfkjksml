package com.bombelite.mensagens

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF0B1220)
private val Panel = Color(0xFF131E30)
private val Blue = Color(0xFF3B82F6)
private val Muted = Color(0xFF9AAAC2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Blue,
                background = Navy,
                surface = Panel,
                onPrimary = Color.White,
                onBackground = Color.White,
                onSurface = Color.White
            )) {
                TelaMensagens()
            }
        }
    }
}

@Composable
private fun TelaMensagens() {
    val context = LocalContext.current
    var numero by remember { mutableStateOf("") }
    var texto by remember { mutableStateOf("") }
    var canal by remember { mutableStateOf("WhatsApp") }

    Surface(modifier = Modifier.fillMaxSize(), color = Navy) {
        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("BOMBE LITE", color = Blue, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text("Nova mensagem", fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("Escolha como quer falar com a pessoa.", color = Muted)

            Spacer(Modifier.height(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FilterChip(
                    selected = canal == "WhatsApp",
                    onClick = { canal = "WhatsApp" },
                    label = { Text("WhatsApp") }
                )
                FilterChip(
                    selected = canal == "SMS",
                    onClick = { canal = "SMS" },
                    label = { Text("SMS") }
                )
            }

            OutlinedTextField(
                value = numero,
                onValueChange = { numero = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Número com código do país") },
                placeholder = { Text("Ex.: 5511999999999") },
                singleLine = true,
                shape = RoundedCornerShape(16.dp)
            )
            OutlinedTextField(
                value = texto,
                onValueChange = { texto = it },
                modifier = Modifier.fillMaxWidth().weight(1f, fill = false),
                label = { Text("Sua mensagem") },
                placeholder = { Text("Digite aqui...") },
                minLines = 5,
                shape = RoundedCornerShape(16.dp)
            )

            Button(
                onClick = {
                    val digits = numero.filter { it.isDigit() }
                    if (digits.length < 10 || texto.isBlank()) {
                        Toast.makeText(context, "Informe o número e a mensagem.", Toast.LENGTH_SHORT).show()
                    } else {
                        try {
                            val intent = if (canal == "WhatsApp") {
                                Intent(
                                    Intent.ACTION_VIEW,
                                    Uri.parse("https://wa.me/$digits?text=${Uri.encode(texto)}")
                                )
                            } else {
                                Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$digits")).apply {
                                    putExtra("sms_body", texto)
                                }
                            }
                            context.startActivity(intent)
                        } catch (_: ActivityNotFoundException) {
                            Toast.makeText(context, "Não encontrei um app compatível neste celular.", Toast.LENGTH_LONG).show()
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Blue)
            ) {
                Text(if (canal == "WhatsApp") "Continuar no WhatsApp" else "Continuar para SMS", fontWeight = FontWeight.Bold)
            }

            Text(
                text = if (canal == "WhatsApp")
                    "O WhatsApp será aberto com a mensagem pronta. Toque em Enviar lá para concluir."
                else
                    "O app de SMS será aberto com a mensagem pronta. Confira possíveis cobranças da operadora.",
                color = Muted,
                fontSize = 12.sp
            )
        }
    }
}
