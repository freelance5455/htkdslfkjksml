package com.bombelite.mensagens

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var myWebView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        myWebView = findViewById(R.id.my_webview)
        myWebView.settings.javaScriptEnabled = true
        myWebView.settings.domStorageEnabled = true

        myWebView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                val uri = request?.url ?: return false
                val scheme = uri.scheme?.lowercase()
                val host = uri.host?.lowercase()

                // Deixa o HTML local no WebView. Abre os destinos WhatsApp/SMS
                // no aplicativo correspondente, quando disponível.
                val isWhatsApp = scheme == "https" &&
                    (host == "wa.me" || host == "www.wa.me" || host == "api.whatsapp.com")
                val isSms = scheme == "sms" || scheme == "smsto"

                if (isWhatsApp || isSms) {
                    return try {
                        startActivity(Intent(Intent.ACTION_VIEW, uri))
                        true
                    } catch (_: ActivityNotFoundException) {
                        Toast.makeText(
                            this@MainActivity,
                            "Não encontrei um app para abrir esta mensagem.",
                            Toast.LENGTH_LONG
                        ).show()
                        true
                    }
                }
                return false
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                // Mostra a página amigável somente se a página principal falhar.
                if (request?.isForMainFrame == true) {
                    view?.loadUrl("file:///android_asset/erro_customizado.html")
                }
                // Não chamamos super: evitamos a página de erro padrão do WebView.
            }
        }

        myWebView.loadUrl("file:///android_asset/mensagens.html")
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (::myWebView.isInitialized && myWebView.canGoBack()) {
            myWebView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        if (::myWebView.isInitialized) myWebView.destroy()
        super.onDestroy()
    }
}
