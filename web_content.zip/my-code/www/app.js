const $=s=>document.querySelector(s),esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const CH=window.Capacitor&&Capacitor.Plugins&&Capacitor.Plugins.CapacitorHttp;
const P={llm7:{n:"LLM7",u:"https://api.llm7.io/v1",f:1,k:"unused",m:[]},
pollinations:{n:"Pollinations",u:"https://text.pollinations.ai/openai",ml:"https://text.pollinations.ai/models",f:1,k:"free",m:["openai","openai-fast","mistral"]},
openrouter:{n:"OpenRouter",u:"https://openrouter.ai/api/v1",g:"https://openrouter.ai/keys",m:["openai/gpt-5","anthropic/claude-sonnet-4.5","google/gemini-2.5-pro","deepseek/deepseek-chat-v3.1:free","z-ai/glm-4.5-air:free"]},
openai:{n:"OpenAI",u:"https://api.openai.com/v1",g:"https://platform.openai.com/api-keys",m:["gpt-5","gpt-5-mini"]},
anthropic:{n:"Anthropic Claude",u:"https://api.anthropic.com/v1",a:1,g:"https://console.anthropic.com/settings/keys",m:["claude-sonnet-4-5","claude-opus-4-1"]},
google:{n:"Google Gemini",u:"https://generativelanguage.googleapis.com/v1beta/openai",g:"https://aistudio.google.com/apikey",m:["gemini-2.5-flash","gemini-2.5-pro"]},
groq:{n:"Groq",u:"https://api.groq.com/openai/v1",g:"https://console.groq.com/keys",m:["llama-3.3-70b-versatile","openai/gpt-oss-120b"]},
custom:{n:"Custom (OpenAI-compatible)",u:"",m:[]}};
let S;try{S=JSON.parse(localStorage.mc2)}catch{}S=Object.assign({s:[],a:null,keys:{},base:{},models:{},sel:["pollinations","openai"],eff:"High",ban:1,proj:".mycode"},S||{});
const save=()=>{try{localStorage.mc2=JSON.stringify(S,(k,v)=>k=="imgs"?undefined:v)}catch{}},uid=()=>Math.random().toString(36).slice(2),cur=()=>S.s.find(x=>x.id==S.a);
const mods=p=>[...new Set([...(S.models[p]||[]),...P[p].m])],nm=m=>m.split("/").pop().replace(/[:-]free$/i," Free"),isF=(p,m)=>P[p].f||/[:-]free$/i.test(m);
const key=p=>S.keys[p]||(P[p].f?P[p].k:""),base=p=>(S.base[p]||P[p].u).replace(/\/$/,"");
const hdr=(p,k)=>P[p].a?{"content-type":"application/json","x-api-key":k,"anthropic-version":"2023-06-01","anthropic-dangerous-direct-browser-access":"true"}:{"content-type":"application/json",authorization:"Bearer "+(k||"")};
const G={m:["11111","10101","10101","10101","10101"],y:["101","101","111","001","111"],c:["111","100","100","100","111"],o:["111","101","101","101","111"],d:["001","001","111","101","111"],e:["111","100","111","100","111"]," ":["00","00","00","00","00"]};
function logo(w){let x=0,r="";for(const ch of w){const g=G[ch];g.forEach((row,y)=>[...row].forEach((v,i)=>{if(v=="1")r+=`<rect x="${(x+i)*10}" y="${y*10}" width="10" height="10"/>`}));x+=g[0].length+1}return`<svg viewBox="0 0 ${x*10-10} 50">${r}</svg>`}
const I={plus:'<svg width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M7.5 2v11M2 7.5h11"/></svg>',up:'<svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M7 12V2M2.5 6.5 7 2l4.500 4.500"/></svg>',stop:'<svg width="12" height="12" fill="currentColor"><rect x="1" y="1" width="10" height="10" rx="2"/></svg>',dn:'<svg width="9" height="9" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M1.500 3 4.500 6 7.500 3"/></svg>',grid:'<svg width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.3"><rect x="1.500" y="1.500" width="4.500" height="4.500" rx="1"/><rect x="9" y="1.500" width="4.500" height="4.500" rx="1"/><rect x="1.500" y="9" width="4.500" height="4.500" rx="1"/><path d="M11.200 8.500v5M8.700 11h5"/></svg>',pen:'<svg width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.2"><path d="M2 11l.6-2.600L9 2l2 2-6.400 6.400zM7.500 3.500l2 2"/></svg>'};
let ctl=null,att=[];
$("#app").innerHTML=`<div id="tabs"></div><main id="main"><div id="hero">${logo("my code")}</div><div id="msgs"></div><div id="box"><div id="chips"></div><textarea id="in" rows="1" placeholder="Ask anything, / for commands, @ for context..."></textarea><div class="row"><button class="ico" id="att" title="Attach any file">${I.plus}</button><button class="sel" id="mb"></button><button class="sel m2" id="eb"></button><span class="sp"></span><button id="go" class="off">${I.up}</button></div></div><div id="chip"><button class="sel" id="pj"></button><span>/</span><span>No Git</span></div></main><div id="ban"></div><div id="pop" hidden></div><dialog id="dlg"></dialog><input type="file" id="fi" multiple hidden>`;
function tabs(){$("#tabs").innerHTML=`<button class="ico" id="cfg" title="Providers">${I.grid}</button>`+S.s.map(s=>`<div class="tab ${s.id==S.a?"on":""}" data-t="${s.id}">${I.pen}<span>${esc(s.t||"New session")}</span><i data-x="${s.id}">×</i></div>`).join("")+`<button class="ico" id="nw">${I.plus}</button>`}
function foot(){const[p,m]=S.sel;$("#mb").innerHTML=`<span>${esc(nm(m))}</span>${I.dn}`;$("#eb").innerHTML=`<span>${S.eff}</span>${I.dn}`;$("#pj").innerHTML=`<span>${esc(S.proj)}</span>${I.dn}`;$("#ban").innerHTML=S.ban?`<span id="bl" style="cursor:pointer">Connect to 75+ providers to use other models, including Claude, GPT, Gemini, etc ›</span><button id="bx">×</button>`:""}
function md(t){return esc(t).replace(/```(\w*)\n?([\s\S]*?)(```|$)/g,(_,l,c)=>`<pre><code>${c.replace(/\n/g,"&#10;")}</code></pre>`).replace(/`([^`\n]+)`/g,"<code>$1</code>").replace(/\*\*([^*\n]+)\*\*/g,"<b>$1</b>").replace(/\n/g,"<br>")}
const mh=m=>m.role=="user"?`<div class="m u">${(m.files||[]).map(f=>`<span class="fc">📎 ${esc(f)}</span>`).join("")}${(m.imgs||[]).map(u=>`<img class="th" src="${u}">`).join("")}<div>${esc(m.show!=null?m.show:m.content)}</div></div>`:`<div class="m a">${md(m.content||"…")}</div>`;
function view(){const s=cur();$("#main").classList.toggle("landing",!s.m.length);$("#msgs").innerHTML=s.m.map(mh).join("");$("#msgs").scrollTop=1e9}
function paint(){const s=cur(),e=$("#msgs").lastElementChild;if(e){e.outerHTML=mh(s.m[s.m.length-1]);$("#msgs").scrollTop=1e9}}
function newS(){const s={id:uid(),t:"",m:[]};S.s.push(s);S.a=s.id;save();tabs();view();$("#in").focus()}
async function gj(url,h){try{const r=await fetch(url,{headers:h});if(!r.ok)throw Error(r.status);return await r.json()}catch(e){if(!CH)throw e;const r=await CH.get({url,headers:h});if(r.status>=400)throw Error(r.status);return typeof r.data=="string"?JSON.parse(r.data):r.data}}
async function load(p){try{const k=key(p),j=await gj(P[p].ml||base(p)+"/models",k?hdr(p,k):{}),l=Array.isArray(j)?j:j.data||j.models||[];
const ids=l.map(x=>typeof x=="string"?x:(x.id||x.name||"").replace(/^models\//,"")).filter(i=>i&&!/embed|whisper|tts|moderation|dall-e|imagen|veo|rerank|aqa|audio|image/i.test(i));if(ids.length){S.models[p]=ids;save()}}catch{}}
function apiMsgs(p,ms){return ms.map(m=>{if(!m.imgs||!m.imgs.length)return{role:m.role,content:m.content};
const im=m.imgs.map(u=>P[p].a?{type:"image",source:{type:"base64",media_type:u.slice(5,u.indexOf(";")),data:u.split(",")[1]}}:{type:"image_url",image_url:{url:u}});return{role:m.role,content:[...im,{type:"text",text:m.content||"Describe this image."}]}})}
async function stream(p,k,m,msgs,onTok,sig){const b={model:m,stream:true,messages:msgs},e=S.eff.toLowerCase(),url=base(p)+(P[p].a?"/messages":"/chat/completions"),h=hdr(p,k);
if(P[p].a)b.max_tokens=8192;else if(p=="openrouter")b.reasoning={effort:e};else if(p=="openai"&&/^(o\d|gpt-5)/.test(m))b.reasoning_effort=e;
let r;try{r=await fetch(url,{method:"POST",signal:sig,headers:h,body:JSON.stringify(b)})}catch(x){if(x.name=="AbortError"||!CH)throw x;b.stream=false;const q=await CH.request({url,method:"POST",headers:h,data:b});if(q.status>=400)throw Error(q.status+" "+JSON.stringify(q.data).slice(0,300));const d=typeof q.data=="string"?JSON.parse(q.data):q.data;onTok(P[p].a?(d.content||[]).map(c=>c.text||"").join(""):d.choices[0].message.content);return}
if(!r.ok)throw Error(r.status+" "+(await r.text()).slice(0,300));
const rd=r.body.getReader(),dc=new TextDecoder();let buf="";
for(;;){const{done,value}=await rd.read();if(done)return;buf+=dc.decode(value,{stream:true});let i;
while((i=buf.indexOf("\n"))>=0){const ln=buf.slice(0,i).trim();buf=buf.slice(i+1);if(ln.slice(0,5)!="data:")continue;const d=ln.slice(5).trim();if(d=="[DONE]")return;
try{const j=JSON.parse(d),t=P[p].a?j.delta&&j.delta.text:j.choices&&j.choices[0]&&j.choices[0].delta&&j.choices[0].delta.content;if(t)onTok(t)}catch{}}}}
const busy=v=>$("#go").innerHTML=v?I.stop:I.up;
async function send(){if(ctl){ctl.abort();return}
const ta=$("#in"),t=ta.value.trim();if(!t&&!att.length)return;
if(t[0]=="/"){const c=t.split(" ")[0];ta.value="";grow();if(c=="/new")return newS();if(c=="/clear"){cur().m=[];save();return view()}if(c=="/models")return models();if(c=="/settings")return provs($("#cfg"))}
const[p0,m0]=S.sel;if(!key(p0))return keyDlg(p0);
const s=cur(),fl=att.slice(),full=fl.filter(f=>f.text!=null).map(f=>`File: ${f.name}\n\`\`\`\n${f.text}\n\`\`\`\n\n`).join("")+t;
s.m.push({role:"user",content:full,show:t,files:fl.map(f=>f.name),imgs:fl.filter(f=>f.img).map(f=>f.img)});if(!s.t)s.t=(t||fl[0].name).slice(0,28);
const a={role:"assistant",content:""},hist=s.m.slice();s.m.push(a);ta.value="";att=[];chips();grow();view();tabs();busy(1);ctl=new AbortController();
const cands=P[p0].f?[[p0,m0],...Object.keys(P).filter(x=>P[x].f&&x!=p0).map(x=>[x,mods(x)[0]]).filter(c=>c[1])]:[[p0,m0]];let err;
for(const[p,m]of cands){try{await stream(p,key(p),m,apiMsgs(p,hist),x=>{a.content+=x;paint()},ctl.signal);err=null;break}catch(e){if(e.name=="AbortError"){err=null;break}err=e;if(a.content)break}}
if(err)a.content+=(a.content?"\n\n":"")+"⚠ "+err.message;ctl=null;busy(0);save();paint()}
const grow=()=>{const t=$("#in");t.style.height="auto";t.style.height=t.scrollHeight+"px";$("#go").classList.toggle("off",!t.value.trim()&&!att.length&&!ctl)};
const chips=(w)=>{$("#chips").innerHTML=w?'<div class="fl">Reading files…</div>':att.map((f,i)=>f.img?`<span class="fc"><img class="th" style="height:30px;margin:0" src="${f.img}">${esc(f.name)}<i data-rm="${i}">×</i></span>`:`<span class="fc">📎 ${esc(f.name)}<i data-rm="${i}">×</i></span>`).join("")};
const addF=async fs=>{chips(1);for(const f of fs)att.push(await readFile(f));chips();grow()};
function pop(btn,html){const r=btn.getBoundingClientRect(),o=$("#pop");o.innerHTML=html;o.hidden=false;const up=r.top>innerHeight/2;o.style.left=Math.max(8,Math.min(r.left,innerWidth-298))+"px";o.style.top=up?"auto":r.bottom+6+"px";o.style.bottom=up?innerHeight-r.top+6+"px":"auto"}
function models(q=""){const Q=q.toLowerCase();let h="";
for(const p of Object.keys(P)){const l=mods(p).filter(m=>(nm(m)+m).toLowerCase().includes(Q));if(!l.length)continue;
h+=P[p].f?`<div class="it h"><b>${P[p].n} · free, no key</b></div>`:`<button class="it h" data-kp="${p}"><b>${P[p].n}</b><small>${S.keys[p]?"Edit key":"Add key"}</small></button>`;
h+=l.slice(0,Q?300:60).map(m=>`<button class="it ${S.sel[0]==p&&S.sel[1]==m?"on":""}" data-p="${p}" data-m="${esc(m)}"><span>${esc(nm(m))}</span><small>${isF(p,m)?"Free":""}</small></button>`).join("")}
pop($("#mb"),`<input id="pq" placeholder="Search models" value="${esc(q)}">${h}`);const i=$("#pq");i.focus();i.setSelectionRange(q.length,q.length);i.oninput=()=>models(i.value)}
function provs(btn){pop(btn,`<div class="it h"><b>Add a provider key</b></div>`+Object.keys(P).filter(p=>!P[p].f).map(p=>`<button class="it" data-kp="${p}"><span>${P[p].n}</span><small>${S.keys[p]?"✓ connected":""}</small></button>`).join(""))}
function keyDlg(p,then){$("#pop").hidden=true;const d=$("#dlg"),c=p=="custom";
d.innerHTML=`<h3 style="margin:0 0 6px">Connect ${P[p].n}</h3><p style="color:var(--mut);margin:0 0 10px">Just one key. It stays on this device.${P[p].g?` <a href="${P[p].g}" target="_blank">Get a key</a>`:""}</p>${c?`<input id="kb" placeholder="Base URL, e.g. https://host/v1" value="${esc(S.base.custom||"")}" style="margin-bottom:8px"><input id="km" placeholder="Model id" style="margin-bottom:8px">`:""}<input id="kv" type="password" placeholder="API key" value="${esc(S.keys[p]||"")}"><div style="display:flex;gap:8px;margin-top:12px"><button class="b" id="ks">Save</button><button class="b" id="kc">Cancel</button></div>`;d.showModal();$("#kv").focus();
$("#kc").onclick=()=>d.close();$("#ks").onclick=async()=>{const v=$("#kv").value.trim();if(!v)return;S.keys[p]=v;if(c){S.base.custom=$("#kb").value.trim();const m=$("#km").value.trim();if(m)S.models.custom=[m,...(S.models.custom||[])]}save();d.close();await load(p);
if(then)then();else if(!key(S.sel[0])||S.sel[0]==p||mods(p)[0]){S.sel=[p,mods(p)[0]||S.sel[1]];save()}foot()}}
document.addEventListener("click",async e=>{const t=e.target,c=s=>t.closest(s);if(!c("#pop")&&!c("#mb")&&!c("#cfg")&&!c("#bl"))$("#pop").hidden=true;
if(c("#nw"))newS();else if(c("[data-x]")){const id=c("[data-x]").dataset.x;S.s=S.s.filter(x=>x.id!=id);if(!S.s.length)return newS();if(S.a==id)S.a=S.s[S.s.length-1].id;save();tabs();view()}
else if(c("[data-t]")){S.a=c("[data-t]").dataset.t;save();tabs();view()}
else if(c("#cfg"))provs(c("#cfg"));else if(c("#bl"))provs(c("#bl"));else if(c("[data-kp]"))keyDlg(c("[data-kp]").dataset.kp);else if(c("#bx")){S.ban=0;save();foot()}
else if(c("#mb"))models();else if(c("#eb")){S.eff={Low:"Medium",Medium:"High",High:"Low"}[S.eff];save();foot()}
else if(c("#pj")){const v=prompt("Project name",S.proj);if(v){S.proj=v;save();foot()}}
else if(c("[data-rm]")){att.splice(+c("[data-rm]").dataset.rm,1);chips();grow()}
else if(c("#att"))$("#fi").click();else if(c("#go"))send();
else if(c("[data-m]")){const p=c("[data-m]").dataset.p,m=c("[data-m]").dataset.m,pick=()=>{S.sel=[p,m];save();foot();$("#pop").hidden=true;$("#in").focus()};key(p)?pick():keyDlg(p,pick)}});
document.addEventListener("keydown",e=>{if(e.target.id=="in"&&e.key=="Enter"&&!e.shiftKey&&!/Android|iPhone/i.test(navigator.userAgent)){e.preventDefault();send()}});
$("#in").addEventListener("input",e=>{grow();if(e.target.value.slice(-1)=="@"){e.target.value=e.target.value.slice(0,-1);$("#fi").click()}});
$("#in").addEventListener("paste",e=>{if(e.clipboardData.files.length){e.preventDefault();addF(e.clipboardData.files)}});
$("#fi").onchange=e=>{addF([...e.target.files]);e.target.value=""};
document.addEventListener("dragover",e=>e.preventDefault());document.addEventListener("drop",e=>{e.preventDefault();addF([...e.dataTransfer.files])});
if(!S.s.length)newS();else if(!cur())S.a=S.s[0].id;tabs();foot();view();grow();
Object.keys(P).filter(p=>P[p].f||S.keys[p]||p=="openrouter").forEach(p=>load(p).then(()=>{if(!$("#pop").hidden&&$("#pq"))models($("#pq").value)}));
