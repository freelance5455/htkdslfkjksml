const $=s=>document.querySelector(s),esc=s=>s.replace(/[&<>]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;"}[c]));
const P={openrouter:{n:"OpenRouter",u:"https://openrouter.ai/api/v1",m:["z-ai/glm-4.5-air:free","deepseek/deepseek-chat-v3.1:free","qwen/qwen3-coder:free","openai/gpt-5","anthropic/claude-sonnet-4.5"]},
openai:{n:"OpenAI",u:"https://api.openai.com/v1",m:["gpt-5","gpt-5-mini"]},
anthropic:{n:"Anthropic",u:"https://api.anthropic.com/v1",a:1,m:["claude-sonnet-4-5","claude-opus-4-1"]},
google:{n:"Google Gemini",u:"https://generativelanguage.googleapis.com/v1beta/openai",m:["gemini-2.5-flash","gemini-2.5-pro"]},
groq:{n:"Groq",u:"https://api.groq.com/openai/v1",m:["llama-3.3-70b-versatile","openai/gpt-oss-120b"]},
custom:{n:"Custom (OpenAI-compatible)",u:"",m:[]}};
let S;try{S=JSON.parse(localStorage.mc)}catch{}S=Object.assign({s:[],a:null,keys:{},base:{},models:{},sel:["openrouter","z-ai/glm-4.5-air:free"],eff:"High",ban:1,proj:".mycode"},S||{});
const save=()=>localStorage.mc=JSON.stringify(S),uid=()=>Math.random().toString(36).slice(2),cur=()=>S.s.find(x=>x.id==S.a);
const mods=p=>[...new Set([...P[p].m,...(S.models[p]||[])])],free=m=>/free/i.test(m),nm=m=>m.split("/").pop().replace(/:free$/i," Free");
const G={m:["11111","10101","10101","10101","10101"],y:["101","101","111","001","111"],c:["111","100","100","100","111"],o:["111","101","101","101","111"],d:["001","001","111","101","111"],e:["111","100","111","100","111"]," ":["00","00","00","00","00"]};
function logo(w){let x=0,r="";for(const ch of w){const g=G[ch];g.forEach((row,y)=>[...row].forEach((v,i)=>{if(v=="1")r+=`<rect x="${(x+i)*10}" y="${y*10}" width="10" height="10"/>`}));x+=g[0].length+1}return`<svg viewBox="0 0 ${x*10-10} 50">${r}</svg>`}
const I={plus:'<svg width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M7.5 2v11M2 7.5h11"/></svg>',up:'<svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M7 12V2M2.5 6.5 7 2l4.500 4.500"/></svg>',stop:'<svg width="12" height="12" fill="currentColor"><rect x="1" y="1" width="10" height="10" rx="2"/></svg>',dn:'<svg width="9" height="9" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M1.500 3 4.500 6 7.500 3"/></svg>',grid:'<svg width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.3"><rect x="1.500" y="1.500" width="4.500" height="4.500" rx="1"/><rect x="9" y="1.500" width="4.500" height="4.500" rx="1"/><rect x="1.500" y="9" width="4.500" height="4.500" rx="1"/><path d="M11.200 8.500v5M8.700 11h5"/></svg>',pen:'<svg width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.2"><path d="M2 11l.6-2.600L9 2l2 2-6.400 6.400zM7.500 3.500l2 2"/></svg>'};
let ctl=null,att=[];
$("#app").innerHTML=`<div id="tabs"></div><main id="main"><div id="hero">${logo("my code")}</div><div id="msgs"></div><div id="box"><div id="chips"></div><textarea id="in" rows="1" placeholder="Ask anything, / for commands, @ for context..."></textarea><div class="row"><button class="ico" id="att" title="Attach file">${I.plus}</button><button class="sel" id="mb"></button><button class="sel m2" id="eb"></button><span class="sp"></span><button id="go" class="off">${I.up}</button></div></div><div id="chip"><button class="sel" id="pj"></button><span>/</span><span>No Git</span></div></main><div id="ban"></div><div id="pop" hidden></div><dialog id="dlg"></dialog><input type="file" id="fi" multiple hidden>`;
function tabs(){$("#tabs").innerHTML=`<button class="ico" id="cfg" title="Providers & keys">${I.grid}</button>`+S.s.map(s=>`<div class="tab ${s.id==S.a?"on":""}" data-t="${s.id}">${I.pen}<span>${esc(s.t||"New session")}</span><i data-x="${s.id}">×</i></div>`).join("")+`<button class="ico" id="nw">${I.plus}</button>`}
function foot(){const[p,m]=S.sel;$("#mb").innerHTML=`<span>${esc(nm(m))}</span>${I.dn}`;$("#eb").innerHTML=`<span>${S.eff}</span>${I.dn}`;$("#pj").innerHTML=`<span>${esc(S.proj)}</span>${I.dn}`;$("#ban").innerHTML=S.ban?`<span id="bl" style="cursor:pointer">Connect to 75+ providers to use other models, including Claude, GPT, Gemini, etc ›</span><button id="bx">×</button>`:""}
function md(t){return esc(t).replace(/```(\w*)\n?([\s\S]*?)(```|$)/g,(_,l,c)=>`<pre><code>${c}</code></pre>`).replace(/`([^`\n]+)`/g,"<code>$1</code>").replace(/\*\*([^*\n]+)\*\*/g,"<b>$1</b>").replace(/\n/g,"<br>").replace(/<pre><code>([\s\S]*?)<\/code><\/pre>/g,(a)=>a.replace(/<br>/g,"\n"))}
const mh=m=>`<div class="m ${m.role=="user"?"u":"a"}">${m.role=="user"?esc(m.content):md(m.content||"…")}</div>`;
function view(){const s=cur();$("#main").classList.toggle("landing",!s.m.length);$("#msgs").innerHTML=s.m.map(mh).join("");$("#msgs").scrollTop=1e9}
function paint(){const s=cur(),e=$("#msgs").lastElementChild;if(e){e.outerHTML=mh(s.m[s.m.length-1]);$("#msgs").scrollTop=1e9}}
function newS(){const s={id:uid(),t:"",m:[]};S.s.push(s);S.a=s.id;save();tabs();view();$("#in").focus()}
const hdr=(p,k)=>P[p].a?{"content-type":"application/json","x-api-key":k,"anthropic-version":"2023-06-01","anthropic-dangerous-direct-browser-access":"true"}:{"content-type":"application/json",authorization:"Bearer "+k};
const base=p=>(S.base[p]||P[p].u).replace(/\/$/,"");
async function stream(p,k,m,msgs,onTok,sig){const b={model:m,stream:true,messages:msgs},e=S.eff.toLowerCase();
if(P[p].a)b.max_tokens=8192;else if(p=="openrouter")b.reasoning={effort:e};else if(p=="openai"&&/^(o\d|gpt-5)/.test(m))b.reasoning_effort=e;
const r=await fetch(base(p)+(P[p].a?"/messages":"/chat/completions"),{method:"POST",signal:sig,headers:hdr(p,k),body:JSON.stringify(b)});
if(!r.ok)throw Error(r.status+" "+(await r.text()).slice(0,300));
const rd=r.body.getReader(),dc=new TextDecoder();let buf="";
for(;;){const{done,value}=await rd.read();if(done)return;buf+=dc.decode(value,{stream:true});let i;
while((i=buf.indexOf("\n"))>=0){const ln=buf.slice(0,i).trim();buf=buf.slice(i+1);if(ln.slice(0,5)!="data:")continue;const d=ln.slice(5).trim();if(d=="[DONE]")return;
try{const j=JSON.parse(d),t=P[p].a?j.delta&&j.delta.text:j.choices&&j.choices[0]&&j.choices[0].delta&&j.choices[0].delta.content;if(t)onTok(t)}catch{}}}}
function busy(v){$("#go").innerHTML=v?I.stop:I.up}
async function send(){if(ctl){ctl.abort();return}
const ta=$("#in"),t=ta.value.trim();if(!t&&!att.length)return;
if(t[0]=="/"){const c=t.split(" ")[0];ta.value="";grow();if(c=="/new")return newS();if(c=="/clear"){cur().m=[];save();return view()}if(c=="/models")return models();if(c=="/settings")return settings();}
const[p,m]=S.sel,k=S.keys[p];if(!k)return settings(`Add your ${P[p].n} API key to use ${nm(m)}.`);
const s=cur(),full=att.map(f=>`File: ${f.name}\n\`\`\`\n${f.text}\n\`\`\`\n\n`).join("")+t;
s.m.push({role:"user",content:full});if(!s.t)s.t=(t||att[0].name).slice(0,28);const a={role:"assistant",content:""};s.m.push(a);
ta.value="";att=[];chips();grow();view();tabs();busy(1);ctl=new AbortController();
try{await stream(p,k,m,s.m.slice(0,-1),x=>{a.content+=x;paint()},ctl.signal)}catch(e){if(e.name!="AbortError")a.content+=(a.content?"\n\n":"")+"⚠ "+e.message}
ctl=null;busy(0);save();paint()}
const grow=()=>{const t=$("#in");t.style.height="auto";t.style.height=t.scrollHeight+"px";$("#go").classList.toggle("off",!t.value.trim()&&!att.length&&!ctl)};
const chips=()=>$("#chips").textContent=att.map(f=>"📎 "+f.name).join("  ");
function pop(btn,html){const r=btn.getBoundingClientRect(),o=$("#pop");o.innerHTML=html;o.hidden=false;const up=r.top>innerHeight/2;o.style.left=Math.max(8,Math.min(r.left,innerWidth-298))+"px";o.style.top=up?"auto":r.bottom+6+"px";o.style.bottom=up?innerHeight-r.top+6+"px":"auto"}
function models(q=""){const h=Object.keys(P).map(p=>{const l=mods(p).filter(m=>(nm(m)+m).toLowerCase().includes(q.toLowerCase()));return l.length?`<h6>${P[p].n}${S.keys[p]?"":" · key needed"}</h6>`+l.map(m=>`<button class="it ${S.sel[0]==p&&S.sel[1]==m?"on":""}" data-p="${p}" data-m="${esc(m)}"><span>${esc(nm(m))}</span><small>${free(m)?"Free":""}</small></button>`).join(""):""}).join("");
pop($("#mb"),`<input id="pq" placeholder="Search models" value="${esc(q)}">${h}<button class="it" data-set="1"><span>Connect provider…</span></button>`);const i=$("#pq");i.focus();i.setSelectionRange(q.length,q.length);i.oninput=()=>models(i.value)}
function settings(msg=""){$("#pop").hidden=true;const d=$("#dlg");d.innerHTML=`<h3 style="margin:0 0 4px">Providers</h3><p style="color:var(--mut);margin:0 0 8px">${esc(msg)||"Keys stay on this device and are sent only to the provider you pick."}</p>`+Object.keys(P).map(p=>`<section><b>${P[p].n}</b><input type="password" data-k="${p}" placeholder="API key" value="${esc(S.keys[p]||"")}"><input data-b="${p}" placeholder="${P[p].u||"Base URL, e.g. https://host/v1"}" value="${esc(S.base[p]||"")}"><input data-a="${p}" placeholder="Add model id and press Enter"><button class="b" data-l="${p}">Load models from provider</button></section>`).join("")+`<button class="b" id="dc" style="margin-top:8px;border:1px solid var(--line);border-radius:6px;padding:6px 12px">Done</button>`;d.showModal()}
document.addEventListener("click",async e=>{const t=e.target,c=s=>t.closest(s);
if(!c("#pop")&&!c("#mb"))$("#pop").hidden=true;
if(c("#nw"))newS();else if(c("[data-x]")){const id=c("[data-x]").dataset.x;S.s=S.s.filter(x=>x.id!=id);if(!S.s.length)return newS();if(S.a==id)S.a=S.s[S.s.length-1].id;save();tabs();view()}
else if(c("[data-t]")){S.a=c("[data-t]").dataset.t;save();tabs();view()}
else if(c("#cfg")||c("#bl")||c("[data-set]"))settings();else if(c("#bx")){S.ban=0;save();foot()}
else if(c("#mb"))models();else if(c("#eb")){S.eff={Low:"Medium",Medium:"High",High:"Low"}[S.eff];save();foot()}
else if(c("#pj")){const v=prompt("Project name",S.proj);if(v){S.proj=v;save();foot()}}
else if(c("#att"))$("#fi").click();else if(c("#go"))send();else if(c("#dc")){$("#dlg").close();foot()}
else if(c("[data-m]")){S.sel=[c("[data-m]").dataset.p,c("[data-m]").dataset.m];save();foot();$("#pop").hidden=true;$("#in").focus()}
else if(c("[data-l]")){const p=c("[data-l]").dataset.l,b=c("[data-l]");try{b.textContent="Loading…";const r=await fetch(base(p)+"/models",{headers:hdr(p,S.keys[p]||"")});if(!r.ok)throw Error(r.status);const j=await r.json();S.models[p]=(j.data||j.models||[]).map(x=>(x.id||x.name).replace(/^models\//,""));save();b.textContent=`Loaded ${S.models[p].length} models`}catch(x){b.textContent="Failed: "+x.message}}});
document.addEventListener("input",e=>{const d=e.target.dataset;if(d.k!=null){S.keys[d.k]=e.target.value.trim();save()}if(d.b!=null){S.base[d.b]=e.target.value.trim();save()}});
document.addEventListener("keydown",e=>{const d=e.target.dataset;if(d&&d.a&&e.key=="Enter"&&e.target.value.trim()){const m=e.target.value.trim();(S.models[d.a]=S.models[d.a]||[]).push(m);S.sel=[d.a,m];e.target.value="";save()}
if(e.target.id=="in"&&e.key=="Enter"&&!e.shiftKey&&!/Android|iPhone/i.test(navigator.userAgent)){e.preventDefault();send()}});
$("#in").addEventListener("input",e=>{grow();if(e.target.value.slice(-1)=="@"){e.target.value=e.target.value.slice(0,-1);$("#fi").click()}});
$("#fi").onchange=async e=>{for(const f of e.target.files)att.push({name:f.name,text:(await f.text()).slice(0,60000)});e.target.value="";chips();grow()};
if(!S.s.length)newS();else if(!cur())S.a=S.s[0].id;tabs();foot();view();grow();
