async function unzip(buf){const v=new DataView(buf),u=new Uint8Array(buf);let e=u.length-22;while(e>0&&v.getUint32(e,true)!=0x06054b50)e--;
const n=v.getUint16(e+10,true);let o=v.getUint32(e+16,true);const out={};
for(let i=0;i<n;i++){const meth=v.getUint16(o+10,true),cs=v.getUint32(o+20,true),nl=v.getUint16(o+28,true),el=v.getUint16(o+30,true),cl=v.getUint16(o+32,true),lo=v.getUint32(o+42,true),name=new TextDecoder().decode(u.subarray(o+46,o+46+nl));o+=46+nl+el+cl;
out[name]=async()=>{const ln=v.getUint16(lo+26,true),le=v.getUint16(lo+28,true),d=u.subarray(lo+30+ln+le,lo+30+ln+le+cs);if(!meth)return new TextDecoder().decode(d);return await new Response(new Blob([d]).stream().pipeThrough(new DecompressionStream("deflate-raw"))).text()}}return out}
const xt=x=>x.replace(/<\/(w:p|a:p|text:p|si)>/g,"\n").replace(/<w:tab\/>/g,"\t").replace(/<[^>]+>/g,"").replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&quot;/g,'"').replace(/&amp;/g,"&");
async function office(z,x){const rd=async n=>z[n]?await z[n]():"",num=s=>+s.match(/\d+/);
if(x=="docx")return xt(await rd("word/document.xml"));
if(x=="pptx"){let o="";for(const n of Object.keys(z).filter(n=>/^ppt\/slides\/slide\d+\.xml$/.test(n)).sort((a,b)=>num(a)-num(b)))o+=`--- slide ${num(n)} ---\n`+xt(await rd(n))+"\n";return o}
if(x=="xlsx"){const ss=[...(await rd("xl/sharedStrings.xml")).matchAll(/<si>([\s\S]*?)<\/si>/g)].map(m=>xt(m[1]).trim());let o="";
for(const n of Object.keys(z).filter(n=>/^xl\/worksheets\/sheet\d+\.xml$/.test(n))){o+=`--- ${n.split("/").pop()} ---\n`;
for(const r of(await rd(n)).matchAll(/<row[^>]*>([\s\S]*?)<\/row>/g)){const cs=[];for(const c of r[1].matchAll(/<c([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g)){const b=c[2]||"",v=b.match(/<v>([\s\S]*?)<\/v>/),t=b.match(/<t[^>]*>([\s\S]*?)<\/t>/);cs.push(/t="s"/.test(c[1])&&v?ss[+v[1]]:v?v[1]:t?xt(t[1]):"")}o+=cs.join("\t")+"\n"}}return o}
return xt(await rd("content.xml"))}
function pdfLib(){return window.pdfjsLib?Promise.resolve(pdfjsLib):new Promise((ok,no)=>{const s=document.createElement("script"),b="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/";s.src=b+"pdf.min.js";s.onload=()=>{pdfjsLib.GlobalWorkerOptions.workerSrc=b+"pdf.worker.min.js";ok(pdfjsLib)};s.onerror=()=>no(Error("PDF reader needs an internet connection"));document.head.appendChild(s)})}
async function readFile(f){const n=f.name,x=n.split(".").pop().toLowerCase(),r={name:n};
if(f.type.startsWith("image/")){r.img=await new Promise(k=>{const fr=new FileReader;fr.onload=()=>k(fr.result);fr.readAsDataURL(f)});return r}
try{if(x=="pdf"){const d=await(await pdfLib()).getDocument({data:await f.arrayBuffer()}).promise;let o="";for(let i=1;i<=Math.min(d.numPages,150);i++){const c=await(await d.getPage(i)).getTextContent();o+=`--- page ${i} ---\n`+c.items.map(t=>t.str).join(" ")+"\n"}r.text=o.trim().length>40?o:"[This PDF has no selectable text (scanned?). Attach pages as images instead.]"}
else if(["docx","pptx","xlsx","odt","odp","ods"].includes(x))r.text=await office(await unzip(await f.arrayBuffer()),x);
else if(["zip","jar","apk","aab"].includes(x))r.text="Archive contents:\n"+Object.keys(await unzip(await f.arrayBuffer())).join("\n");
else if(/^(audio|video)\//.test(f.type))r.text=`[${f.type} file "${n}", ${f.size} bytes. Models can't read audio/video as text.]`;
else{const t=await f.text();r.text=/\uFFFD/.test(t.slice(0,3000))&&(t.slice(0,3000).match(/\uFFFD/g)||[]).length>5?`[Binary file "${n}", ${f.size} bytes]`:t}}
catch(e){r.text="[Could not read "+n+": "+e.message+"]"}
r.text=(r.text||"").slice(0,80000);return r}
if(typeof module!="undefined")module.exports={unzip,xt,office};
