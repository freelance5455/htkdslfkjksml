# My code
Chat-with-models app for desktop and Android. No server: the app calls provider APIs directly; keys stay on the device.

Open `www/index.html` in a browser to try it instantly. Then:

**Desktop:** `npm install` -> `npm start` (run) / `npm run dist` (installer for your OS)
**Android:** `npm install` -> `npm run android:add` -> `npm run android:sync` -> `npm run android:open` (Android Studio: Build > Build APK)

First run: tap the grid icon (top left), paste an API key (OpenRouter has free ":free" models), pick a model, and chat.
