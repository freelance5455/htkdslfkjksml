# My code
Desktop + Android app for chatting with free and paid AI models. No server of your own: the app talks to the model providers directly.

- **Free models (no key):** Pollinations and LLM7 are built in. If one is busy the app tries the other automatically.
- **Paid / other models:** tap the model name, pick any model. If its provider needs a key, a box asks for that one key only (OpenRouter's single key unlocks hundreds of models).
- **Plus button (or drag & drop / paste):** attach any file. Images go to the model as pictures; PDF, Word, Excel, PowerPoint, code, text, CSV, JSON, zip listings are read as text.

Try it now: open `www/index.html` in a browser.
Desktop: `npm install && npm start` (installer: `npm run dist`).
Android: `npm install && npm run android:add && npm run android:sync && npm run android:open`, then Build > Build APK in Android Studio (or use the GitHub Actions workflow in `.github/workflows/apk.yml`).
