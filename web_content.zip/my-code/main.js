const{app,BrowserWindow,shell}=require("electron"),path=require("path");
app.whenReady().then(()=>{const w=new BrowserWindow({width:1100,height:760,title:"My code",backgroundColor:"#fafafa",autoHideMenuBar:true,webPreferences:{contextIsolation:true,webSecurity:false}});
w.loadFile(path.join(__dirname,"www/index.html"));w.webContents.setWindowOpenHandler(({url})=>{shell.openExternal(url);return{action:"deny"}})});
app.on("window-all-closed",()=>app.quit());
