# V50 – Android Excel Picker Compatibility Fix

Built from the stored V49 package. The Choose File Android bridge now launches a simple ACTION_GET_CONTENT chooser with ACTION_OPEN_DOCUMENT fallback. It uses a separate native request code handled by onActivityResult. The prior MIME-array and persistable-permission flags were removed from the JS-triggered picker path. Existing native XLSX/CSV parsing, preview, Supabase import flow, and other app features are preserved.
