BAROODAA REGISTRY PREMIUM - ANDROID STUDIO

Project Android Studio kana buufadhu, ZIP keessaa baasi (Extract), Android Studio keessatti Open godhi.

Amaloota:
- Bifa ammayyaa Emerald Green, Gold fi White.
- Galmee Excel irraa galmaa'e 2,098.
- Zoonii Z1 hanga Z5.
- Search maqaa qubee jalqabaa irraa (prefix search), lakkoofsa, tajaajila.
- Galmee haaraa ida'uu fi galmee gulaaluu.
- Kaffaltii guutuu, gartokkee fi hin kaffalle adda baasuu.
- Kaffaltii haaraa galmeessuu; haftee kaffaltii ofumaan shallaguu.
- CSV export fi Print/PDF.
- Offline; galmeewwan haaraa fi fooyya'iinsi bilbila irratti kuufama.

APK ijaaruuf:
1. Android Studio bani.
2. Open -> folder Baroodaa_Registry_Premium.
3. Android SDK Platform 35 fe'i/eeyyami.
4. Build -> Build Bundle(s) / APK(s) -> Build APK(s).
5. APK: app/build/outputs/apk/debug/app-debug.apk

Workbook irraa sheet Zoni1-Zoni5 qofa dubbifame. GF hin dabalamu.

HAALA KAFFALTII MIRKANEESSUU:
- Galmee tokko banii 'Kaffaltii galchi' filadhu.
- Hamma kaffaltii, guyyaa, nagahee fi mala kaffaltii galchi.
- Kaffaltiin haaraan jalqaba 'Hin mirkanoofne' ta'a.
- 'Seenaa kaffaltii' keessatti nagahee ilaali; 'Kaffaltii kana mirkaneessi' tuqi.
- Galmeewwan duraan Excel irraa dhufan akka kaffaltii workbook keessatti galmaa'aniitti agarsiifamu; nagahee isaanii appiin ofumaan hin mirkaneessu.
