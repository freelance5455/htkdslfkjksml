Shahzaib ♥ Ayesha Mangni App
- index.html ko Chrome mein open karke app preview karein.
- assets folder ko index.html ke saath hi rakhein; offline images isi folder se load hoti hain.
- ZIP-to-APK converter mein poori ZIP upload karein, sirf index.html nahi.
- Ayesha ki asal tasveer abhi nahi mili, is liye Islamabad-themed romantic artwork use hua hai.
- Is project mein koi online service ya tracking nahi hai.
