SIMULADOR CONTROL DE ACCESO - PAQUETE PARA CONVERSOR HTML -> APK

Contenido:
- index.html : simulador V14 completo.
- icon.png   : imagen sugerida para el icono de la aplicación (512x512).

Uso:
1. Sube ESTE ZIP directamente al conversor HTML -> APK que acepte proyectos HTML/ZIP.
2. El archivo principal debe detectarse como index.html.
3. Nombre sugerido de la app: Simulador Control de Acceso.
4. Usa icon.png como icono si el conversor permite seleccionar un icono personalizado.

El index.html no depende de archivos externos: CSS y JavaScript están incluidos dentro del propio HTML.
No es necesario descomprimir ni modificar el contenido antes de subirlo, salvo que el conversor indique lo contrario.
