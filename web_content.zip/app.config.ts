export default {
  logoUrl: "https://placehold.co/512x512/png?text=G%26S"
};
