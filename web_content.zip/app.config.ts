export default {
  logoUrl: "https://cdn.simpleicons.org/barcode/173C35",
};
