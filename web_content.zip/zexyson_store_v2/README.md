# ZEXYSON STORE Digital Order v2

## Fitur
- Front-end red/black, pelanggan checkout tanpa akun, riwayat lokal di browser.
- Backend Node.js + Express.
- Membuat transaksi Midtrans Snap dari server, lalu mengarahkan pelanggan ke halaman pembayaran hosted.
- Metode pembayaran yang diminta disiapkan sebagai opsi: QRIS, DANA, OVO, GoPay. Metode harus diaktifkan/tersedia pada akun merchant Midtrans; cek konfigurasi dashboard dan hasil sandbox.
- Endpoint notifikasi Midtrans memverifikasi signature dan mengambil status transaksi dari API sebelum memperbarui status pada file database lokal.

## Jalankan lokal
1. Install Node.js 20 atau lebih baru.
2. Ekstrak folder proyek.
3. Jalankan `npm install`.
4. Salin `.env.example` ke `.env`, lalu isi environment variables. Jangan pernah memasukkan Server Key ke frontend atau mengunggahnya ke repositori.
5. Muat variabel `.env` dengan cara yang sesuai OS/hosting (atau gunakan package `dotenv` bila ingin memuat file lokal; package ini belum disertakan). Di Windows PowerShell, contoh:
   `$env:ADMIN_SECRET='kunci-rahasia-panjang'`
   `$env:MIDTRANS_SERVER_KEY='SB-Mid-server-...'`
   `$env:MIDTRANS_IS_PRODUCTION='false'`
   `npm start`
6. Buka `http://localhost:3000`.

## Aktivasi Midtrans
1. Buat akun merchant Midtrans dan lengkapi proses verifikasi bisnis sesuai persyaratan Midtrans.
2. Mulai dari Sandbox; salin Server Key dan Client Key Sandbox dari dashboard.
3. Aktifkan metode pembayaran yang tersedia untuk akun merchant. Jangan berasumsi semua metode aktif otomatis; cek QRIS, DANA, OVO, dan GoPay di dashboard/dukungan merchant.
4. Atur Payment Notification URL ke `https://DOMAIN-ANDA/api/midtrans/notification` pada konfigurasi dashboard.
5. Uji order dan status pembayaran di Sandbox. Pastikan webhook dapat diakses publik via HTTPS.
6. Sebelum produksi, lengkapi verifikasi merchant, gunakan production keys, set `MIDTRANS_IS_PRODUCTION=true`, pasang HTTPS, dan uji nominal kecil sesuai panduan penyedia.

## Catatan keamanan penting
- `ADMIN_SECRET` dan `MIDTRANS_SERVER_KEY` harus environment secrets di hosting, bukan di HTML. Endpoint harga admin contoh ini memakai header secret sederhana dan endpoint login belum membuat sesi; untuk penggunaan publik wajib diganti dengan sesi admin aman (HttpOnly/Secure cookie, CSRF protection, rate limiting, audit log, dan database).
- `data.json` cocok hanya untuk demonstrasi satu instance; gunakan database terkelola untuk produksi.
- Front-end riwayat order tersimpan lokal, sehingga tidak tersedia lintas perangkat. Endpoint status order perlu dilindungi dengan kepemilikan order atau token acak sebelum situs publik.
- Backend contoh tidak menjamin payment methods tersedia pada merchant. Periksa metode yang diaktifkan dan parameter integrasi di dashboard/dokumentasi resmi.
- Pembayaran jangan ditandai lunas dari redirect browser saja; hanya gunakan status terverifikasi server/webhook.
- Untuk transaksi bisnis sungguhan, minta orang dewasa/pemilik usaha menangani pendaftaran merchant, verifikasi identitas, rekening pencairan, dan kontrak penyedia pembayaran.

## Dokumen resmi
- Midtrans Snap Integration Guide: https://docs.midtrans.com/docs/snap-snap-integration-guide
- Midtrans e-wallet integration: https://docs.midtrans.com/docs/coreapi-e-money-integration
