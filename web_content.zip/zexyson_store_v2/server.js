// ZEXYSON STORE backend — Node.js 20+
const express = require('express');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');
const app = express();
app.use(express.json({limit:'30kb'}));
app.use(express.static(path.join(__dirname,'public')));

const PORT = process.env.PORT || 3000;
const ADMIN_SECRET = process.env.ADMIN_SECRET;
const MIDTRANS_SERVER_KEY = process.env.MIDTRANS_SERVER_KEY;
const MIDTRANS_CLIENT_KEY = process.env.MIDTRANS_CLIENT_KEY || '';
const MIDTRANS_IS_PRODUCTION = process.env.MIDTRANS_IS_PRODUCTION === 'true';
const MIDTRANS_BASE = MIDTRANS_IS_PRODUCTION ? 'https://app.midtrans.com' : 'https://app.sandbox.midtrans.com';
const DB = path.join(__dirname, 'data.json');
const CATALOG = [
 {id:'jb',name:'JB Jual Beli Akun Game',price:10000},
 {id:'ff',name:'Jasa Pengaman Akun Free Fire',price:5000},
 {id:'topup',name:'Jasa Top Up',price:10000},
 {id:'push',name:'Jasa Push Kontak WhatsApp',price:5000},
 {id:'other',name:'Layanan Lainnya',price:5000}
];
function readDb(){try{return JSON.parse(fs.readFileSync(DB,'utf8'))}catch{return {prices:Object.fromEntries(CATALOG.map(x=>[x.id,x.price])),orders:{}}}}
function writeDb(db){fs.writeFileSync(DB,JSON.stringify(db,null,2))}
function adminAuth(req,res,next){if(req.headers['x-admin-secret']!==ADMIN_SECRET || !ADMIN_SECRET)return res.status(401).json({error:'Admin tidak terautentikasi'});next()}
app.post('/api/admin/login',(req,res)=>{if(!ADMIN_SECRET)return res.status(503).json({error:'ADMIN_SECRET belum dikonfigurasi'});if(req.body.secret!==ADMIN_SECRET)return res.status(401).json({error:'Kunci admin salah'});res.json({ok:true})});
// Untuk implementasi nyata, ganti mekanisme demo ini dengan sesi HttpOnly/Secure + CSRF dan rate limit.
app.put('/api/admin/prices',adminAuth,(req,res)=>{const {serviceId,price}=req.body||{};if(!CATALOG.some(x=>x.id===serviceId)||!Number.isSafeInteger(price)||price<0||price>100000000)return res.status(400).json({error:'Data harga tidak valid'});const db=readDb();db.prices[serviceId]=price;writeDb(db);res.json({ok:true})});
app.get('/api/catalog',(req,res)=>{const db=readDb();res.json(CATALOG.map(p=>({...p,price:db.prices[p.id]??p.price})))});
app.post('/api/orders',async(req,res)=>{
 try{
  if(!MIDTRANS_SERVER_KEY)return res.status(503).json({error:'Payment gateway belum dikonfigurasi. Isi MIDTRANS_SERVER_KEY di environment server.'});
  const {serviceId,quantity,name,contact,detail,paymentMethod}=req.body||{};
  const item=CATALOG.find(p=>p.id===serviceId);
  if(!item||!Number.isInteger(quantity)||quantity<1||quantity>99||typeof name!=='string'||!name.trim()||name.length>80||typeof contact!=='string'||!contact.trim()||contact.length>100||typeof detail!=='string'||detail.length>500)return res.status(400).json({error:'Detail pesanan tidak valid'});
  const allowed=['qris','dana','ovo','gopay'];
  if(!allowed.includes(paymentMethod))return res.status(400).json({error:'Metode pembayaran tidak didukung'});
  // Snap payment options depend on enabled methods in merchant dashboard.
  // QRIS/e-wallet display is controlled by Snap settings; verify availability for your account.
  const db=readDb(),unit=db.prices[item.id]??item.price,amount=unit*quantity;
  if(!Number.isSafeInteger(amount)||amount<1)return res.status(400).json({error:'Total tidak valid'});
  const orderId='ZEX-'+Date.now()+'-'+crypto.randomBytes(3).toString('hex');
  db.orders[orderId]={orderId,serviceId,quantity,name:name.trim(),contact:contact.trim(),detail:detail.trim(),paymentMethod,amount,status:'pending',createdAt:new Date().toISOString()};
  writeDb(db);
  const enabledMap={qris:['qris','gopay'],dana:['dana'],ovo:['ovo'],gopay:['gopay']};
  const enabled=enabledMap[paymentMethod];
  const body={
   transaction_details:{order_id:orderId,gross_amount:amount},
   item_details:[{id:item.id,price:unit,quantity,name:item.name.slice(0,50)}],
   customer_details:{first_name:name.trim().slice(0,50),email:contact.includes('@')?contact.trim():undefined,phone:contact.replace(/[^\d+]/g,'').slice(0,20)},
   enabled_payments:enabled
  };
  const auth=Buffer.from(MIDTRANS_SERVER_KEY+':').toString('base64');
  const resp=await fetch(MIDTRANS_BASE+'/snap/v1/transactions',{method:'POST',headers:{'Accept':'application/json','Content-Type':'application/json','Authorization':'Basic '+auth},body:JSON.stringify(body)});
  const data=await resp.json();
  if(!resp.ok||!data.redirect_url){const latest=readDb();if(latest.orders[orderId])latest.orders[orderId].status='payment_creation_failed';writeDb(latest);return res.status(502).json({error:'Payment gateway gagal membuat pembayaran. Periksa aktivasi metode dan konfigurasi merchant.'})}
  const latest=readDb();latest.orders[orderId].token=data.token;latest.orders[orderId].paymentUrl=data.redirect_url;writeDb(latest);
  res.json({orderId,amount,status:'Menunggu pembayaran',paymentUrl:data.redirect_url});
 }catch(err){console.error('order error',err.message);res.status(500).json({error:'Terjadi kesalahan server saat membuat pesanan'})}
});
// Midtrans HTTP notification endpoint: verify signature before updating payment status.
app.post('/api/midtrans/notification',async(req,res)=>{
 try{
  const n=req.body||{};
  if(!MIDTRANS_SERVER_KEY)return res.status(503).send('not configured');
  const expected=crypto.createHash('sha512').update(String(n.order_id||'')+String(n.status_code||'')+String(n.gross_amount||'')+MIDTRANS_SERVER_KEY).digest('hex');
  const a=Buffer.from(expected),b=Buffer.from(String(n.signature_key||''));
  if(a.length!==b.length||!crypto.timingSafeEqual(a,b))return res.status(403).send('invalid signature');
  const auth=Buffer.from(MIDTRANS_SERVER_KEY+':').toString('base64');
  const statusResp=await fetch(MIDTRANS_BASE+'/v2/'+encodeURIComponent(n.order_id)+'/status',{headers:{'Accept':'application/json','Authorization':'Basic '+auth}});
  const statusData=await statusResp.json();
  const db=readDb(),order=db.orders[n.order_id];
  if(order){
   order.gatewayStatus=statusData.transaction_status||n.transaction_status||'unknown';
   order.status=(statusData.transaction_status==='settlement'||(statusData.transaction_status==='capture'&&statusData.fraud_status==='accept'))?'paid':statusData.transaction_status||'pending';
   order.updatedAt=new Date().toISOString();writeDb(db);
  }
  res.status(200).send('OK');
 }catch(err){console.error('notification error',err.message);res.status(500).send('error')}
});
app.get('/api/orders/:id',(req,res)=>{const db=readDb(),o=db.orders[req.params.id];if(!o)return res.status(404).json({error:'Pesanan tidak ditemukan'});res.json({orderId:o.orderId,amount:o.amount,status:o.status,serviceId:o.serviceId,quantity:o.quantity,createdAt:o.createdAt})});
app.get('/health',(req,res)=>res.json({ok:true}));
app.listen(PORT,()=>console.log(`ZEXYSON STORE listening on http://localhost:${PORT}`));
