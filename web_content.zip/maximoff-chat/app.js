// ========== داده‌های اولیه ==========
const contacts = [
    {
        id: 1,
        name: "ویژن",
        avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Vision&backgroundColor=1a1a2e",
        lastMessage: "قدرت‌های آشوب هنوز همونقدر قوی هستن؟",
        time: "۱۲:۳۰",
        unread: 2,
        online: true
    },
    {
        id: 2,
        name: "استیو راجرز",
        avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Steve&backgroundColor=1a2a3a",
        lastMessage: "فردا جلسه داریم",
        time: "۱۱:۱۵",
        unread: 0,
        online: true
    },
    {
        id: 3,
        name: "تونی استارک",
        avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Tony&backgroundColor=3a2a1a",
        lastMessage: "یه گجت جدید ساختم برات",
        time: "دیروز",
        unread: 1,
        online: false
    },
    {
        id: 4,
        name: "ناتاشا",
        avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Natasha&backgroundColor=2a1a2a",
        lastMessage: "مواظب خودت باش واندا",
        time: "دیروز",
        unread: 0,
        online: true
    },
    {
        id: 5,
        name: "بروکه",
        avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Bucky&backgroundColor=1a1a1a",
        lastMessage: "عکس‌های مأموریت رو فرستادم",
        time: "۲ روز پیش",
        unread: 0,
        online: false
    },
    {
        id: 6,
        name: "پیتر پارکر",
        avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Peter&backgroundColor=2a1a1a",
        lastMessage: "خانم مکسیموف! کمک لازم دارم",
        time: "۳ روز پیش",
        unread: 3,
        online: true
    }
];

const chatMessages = {
    1: [
        { type: "received", text: "سلام واندا، حالت چطوره؟", time: "۱۲:۲۰" },
        { type: "sent", text: "سلام ویژن. خوبم، تو چطوری؟", time: "۱۲:۲۲" },
        { type: "received", text: "قدرت‌های آشوب هنوز همونقدر قوی هستن؟", time: "۱۲:۳۰" },
        { type: "sent", text: "قوی‌تر از همیشه 🔥", time: "۱۲:۳۱" }
    ],
    2: [
        { type: "received", text: "فردا جلسه داریم", time: "۱۱:۱۰" },
        { type: "sent", text: "باشه، ساعت چند؟", time: "۱۱:۱۲" },
        { type: "received", text: "۱۰ صبح توی برج", time: "۱۱:۱۵" }
    ],
    3: [
        { type: "received", text: "یه گجت جدید ساختم برات", time: "۱۰:۰۰" },
        { type: "sent", text: "باز چی ساختی تونی؟ 😅", time: "۱۰:۰۵" }
    ],
    4: [
        { type: "received", text: "مواظب خودت باش واندا", time: "۰۹:۳۰" },
        { type: "sent", text: "تو هم مواظب باش ناتاشا", time: "۰۹:۳۵" }
    ],
    5: [
        { type: "received", text: "عکس‌های مأموریت رو فرستادم", time: "دیروز" }
    ],
    6: [
        { type: "received", text: "خانم مکسیموف! کمک لازم دارم", time: "۳ روز پیش" },
        { type: "sent", text: "چی شده پیتر؟", time: "۳ روز پیش" },
        { type: "received", text: "یه موجود عجیب تو شهر ظاهر شده", time: "۳ روز پیش" }
    ]
};

let currentChatId = null;
let isRecording = false;
let attachOpen = false;

// ========== توابع اصلی ==========
function login() {
    const username = document.getElementById('username').value.trim();
    if (!username) {
        alert('لطفاً نام کاربری وارد کنید');
        return;
    }
    
    document.getElementById('login-screen').classList.remove('active');
    document.getElementById('main-screen').classList.add('active');
    renderChatList();
}

function logout() {
    document.getElementById('profile-screen').classList.remove('active');
    document.getElementById('main-screen').classList.remove('active');
    document.getElementById('login-screen').classList.add('active');
}

function renderChatList() {
    const container = document.getElementById('chat-list');
    container.innerHTML = '';
    
    contacts.forEach(contact => {
        const item = document.createElement('div');
        item.className = 'chat-item';
        item.onclick = () => openChat(contact.id);
        
        item.innerHTML = `
            <div class="chat-avatar">
                <img src="${contact.avatar}" alt="${contact.name}">
                ${contact.online ? '<div class="online-dot"></div>' : ''}
            </div>
            <div class="chat-info">
                <div class="chat-top">
                    <span class="chat-name">${contact.name}</span>
                    <span class="chat-time">${contact.time}</span>
                </div>
                <div class="chat-bottom">
                    <span class="chat-preview">${contact.lastMessage}</span>
                    ${contact.unread > 0 ? `<span class="unread-badge">${contact.unread}</span>` : ''}
                </div>
            </div>
        `;
        
        container.appendChild(item);
    });
}

function openChat(id) {
    currentChatId = id;
    const contact = contacts.find(c => c.id === id);
    
    document.getElementById('main-screen').classList.remove('active');
    document.getElementById('chat-screen').classList.add('active');
    
    document.getElementById('chat-name').textContent = contact.name;
    document.getElementById('chat-avatar').src = contact.avatar;
    document.getElementById('chat-status').textContent = contact.online ? 'آنلاین' : 'آخرین بازدید اخیراً';
    document.getElementById('chat-status').style.color = contact.online ? 'var(--success)' : 'var(--text-secondary)';
    
    // پاک کردن unread
    contact.unread = 0;
    
    renderMessages();
    
    // اسکرول به پایین
    setTimeout(() => {
        const container = document.getElementById('messages');
        container.scrollTop = container.scrollHeight;
    }, 50);
}

function renderMessages() {
    const container = document.getElementById('messages');
    container.innerHTML = '';
    
    const messages = chatMessages[currentChatId] || [];
    
    messages.forEach(msg => {
        const div = document.createElement('div');
        
        if (msg.type === 'image') {
            div.className = `message image-msg ${msg.sent ? 'sent' : 'received'}`;
            div.innerHTML = `
                <img src="${msg.src}" alt="تصویر">
                <div class="message-time">${msg.time}</div>
            `;
        } else if (msg.type === 'voice') {
            div.className = `message voice-msg ${msg.sent ? 'sent' : 'received'}`;
            div.innerHTML = `
                <div class="voice-play" onclick="playVoice(this)">
                    <i class="fas fa-play"></i>
                </div>
                <div class="voice-wave">
                    <span></span><span></span><span></span><span></span>
                    <span></span><span></span><span></span>
                </div>
                <span class="voice-duration">${msg.duration || '۰:۱۲'}</span>
            `;
        } else {
            div.className = `message ${msg.type}`;
            div.innerHTML = `
                ${msg.text}
                <div class="message-time">${msg.time}</div>
            `;
        }
        
        container.appendChild(div);
    });
}

function backToMain() {
    document.getElementById('chat-screen').classList.remove('active');
    document.getElementById('profile-screen').classList.remove('active');
    document.getElementById('main-screen').classList.add('active');
    renderChatList();
    closeAttach();
}

function openProfile() {
    document.getElementById('main-screen').classList.remove('active');
    document.getElementById('chat-screen').classList.remove('active');
    document.getElementById('profile-screen').classList.add('active');
}

function openUserProfile() {
    // فعلاً همان پروفایل
    openProfile();
}

function showChats() {
    // فعلاً فقط لیست چت
}

function showStatus() {
    alert('وضعیت‌ها به زودی اضافه می‌شود ✨');
}

// ========== ارسال پیام ==========
function handleKeyPress(e) {
    if (e.key === 'Enter') {
        sendMessage();
    }
    
    // نمایش دکمه ارسال
    const input = document.getElementById('message-input');
    const sendBtn = document.getElementById('send-btn');
    const micBtn = document.getElementById('mic-btn');
    
    if (input.value.trim()) {
        sendBtn.style.display = 'block';
        micBtn.style.display = 'none';
    } else {
        sendBtn.style.display = 'none';
        micBtn.style.display = 'block';
    }
}

function sendMessage() {
    const input = document.getElementById('message-input');
    const text = input.value.trim();
    
    if (!text || !currentChatId) return;
    
    const now = new Date();
    const time = now.getHours().toString().padStart(2, '0') + ':' + 
                 now.getMinutes().toString().padStart(2, '0');
    
    if (!chatMessages[currentChatId]) {
        chatMessages[currentChatId] = [];
    }
    
    chatMessages[currentChatId].push({
        type: 'sent',
        text: text,
        time: time
    });
    
    // آپدیت آخرین پیام
    const contact = contacts.find(c => c.id === currentChatId);
    if (contact) {
        contact.lastMessage = text;
        contact.time = 'الان';
    }
    
    input.value = '';
    document.getElementById('send-btn').style.display = 'none';
    document.getElementById('mic-btn').style.display = 'block';
    
    renderMessages();
    
    // اسکرول
    const container = document.getElementById('messages');
    container.scrollTop = container.scrollHeight;
    
    // پاسخ خودکار بعد از ۲ ثانیه
    setTimeout(() => {
        autoReply();
    }, 1500 + Math.random() * 1500);
}

function autoReply() {
    if (!currentChatId) return;
    
    const replies = [
        "جالبه 🔥",
        "موافقم",
        "باشه، انجام می‌دم",
        "قدرت با تو باشه",
        "حتماً",
        "آها متوجه شدم",
        "خوب پیش می‌ره؟",
        "مراقب خودت باش"
    ];
    
    const now = new Date();
    const time = now.getHours().toString().padStart(2, '0') + ':' + 
                 now.getMinutes().toString().padStart(2, '0');
    
    const reply = replies[Math.floor(Math.random() * replies.length)];
    
    chatMessages[currentChatId].push({
        type: 'received',
        text: reply,
        time: time
    });
    
    const contact = contacts.find(c => c.id === currentChatId);
    if (contact) {
        contact.lastMessage = reply;
        contact.time = 'الان';
    }
    
    renderMessages();
    
    const container = document.getElementById('messages');
    container.scrollTop = container.scrollHeight;
}

// ========== عکس و ویس ==========
function toggleAttach() {
    const menu = document.getElementById('attach-menu');
    attachOpen = !attachOpen;
    menu.classList.toggle('show', attachOpen);
}

function closeAttach() {
    attachOpen = false;
    document.getElementById('attach-menu').classList.remove('show');
}

function sendImage() {
    closeAttach();
    
    if (!currentChatId) return;
    
    const now = new Date();
    const time = now.getHours().toString().padStart(2, '0') + ':' + 
                 now.getMinutes().toString().padStart(2, '0');
    
    // تصویر تصادفی با تم قرمز
    const imageUrl = `https://picsum.photos/seed/${Date.now()}/400/300`;
    
    if (!chatMessages[currentChatId]) {
        chatMessages[currentChatId] = [];
    }
    
    chatMessages[currentChatId].push({
        type: 'image',
        src: imageUrl,
        sent: true,
        time: time
    });
    
    const contact = contacts.find(c => c.id === currentChatId);
    if (contact) {
        contact.lastMessage = '📷 عکس';
        contact.time = 'الان';
    }
    
    renderMessages();
    
    const container = document.getElementById('messages');
    container.scrollTop = container.scrollHeight;
}

function sendVoice() {
    closeAttach();
    toggleVoice();
}

function toggleVoice() {
    const micBtn = document.getElementById('mic-btn');
    
    if (!isRecording) {
        // شروع ضبط
        isRecording = true;
        micBtn.style.color = 'var(--danger)';
        micBtn.classList.add('fa-stop');
        micBtn.classList.remove('fa-microphone');
        
        // شبیه‌سازی ضبط ۳ ثانیه‌ای
        setTimeout(() => {
            if (isRecording) {
                finishVoice();
            }
        }, 3000);
    } else {
        finishVoice();
    }
}

function finishVoice() {
    isRecording = false;
    const micBtn = document.getElementById('mic-btn');
    micBtn.style.color = '';
    micBtn.classList.remove('fa-stop');
    micBtn.classList.add('fa-microphone');
    
    if (!currentChatId) return;
    
    const now = new Date();
    const time = now.getHours().toString().padStart(2, '0') + ':' + 
                 now.getMinutes().toString().padStart(2, '0');
    
    if (!chatMessages[currentChatId]) {
        chatMessages[currentChatId] = [];
    }
    
    chatMessages[currentChatId].push({
        type: 'voice',
        sent: true,
        duration: '۰:۰۳',
        time: time
    });
    
    const contact = contacts.find(c => c.id === currentChatId);
    if (contact) {
        contact.lastMessage = '🎤 پیام صوتی';
        contact.time = 'الان';
    }
    
    renderMessages();
    
    const container = document.getElementById('messages');
    container.scrollTop = container.scrollHeight;
}

function playVoice(btn) {
    const icon = btn.querySelector('i');
    if (icon.classList.contains('fa-play')) {
        icon.classList.remove('fa-play');
        icon.classList.add('fa-pause');
        
        setTimeout(() => {
            icon.classList.remove('fa-pause');
            icon.classList.add('fa-play');
        }, 3000);
    }
}

// ========== تماس ==========
function startCall(type) {
    const contact = contacts.find(c => c.id === currentChatId);
    if (!contact) return;
    
    document.getElementById('call-avatar-img').src = contact.avatar;
    document.getElementById('call-name').textContent = contact.name;
    document.getElementById('call-type').textContent = type === 'video' ? 'در حال تماس تصویری...' : 'در حال تماس صوتی...';
    
    document.getElementById('call-modal').classList.add('show');
}

function endCall() {
    document.getElementById('call-modal').classList.remove('show');
}

// بستن منوی ضمیمه با کلیک بیرون
document.addEventListener('click', (e) => {
    const menu = document.getElementById('attach-menu');
    const plusBtn = document.querySelector('.input-actions');
    
    if (attachOpen && !menu.contains(e.target) && !plusBtn.contains(e.target)) {
        closeAttach();
    }
});

// مدیریت نمایش دکمه ارسال
document.getElementById('message-input').addEventListener('input', function() {
    const sendBtn = document.getElementById('send-btn');
    const micBtn = document.getElementById('mic-btn');
    
    if (this.value.trim()) {
        sendBtn.style.display = 'block';
        micBtn.style.display = 'none';
    } else {
        sendBtn.style.display = 'none';
        micBtn.style.display = 'block';
    }
});
