document.addEventListener('DOMContentLoaded', () => {
    // --- ЗАЩИТА ОТ ОШИБОК ---
    window.addEventListener('error', function(e) {
        console.error('Ошибка в скрипте:', e.message);
    });

    // 1. Загрузка сохранений
    if (typeof storage !== 'undefined') storage.load();
    
    // --- ФИКС БИТЫХ СОХРАНЕНИЙ ---
    if (isNaN(gameState.balance) || gameState.balance === undefined) gameState.balance = 0;
    if (isNaN(gameState.totalEarned)) gameState.totalEarned = 0;
    if (isNaN(gameState.michelinStars)) gameState.michelinStars = 0;
    if (isNaN(gameState.totalClicks)) gameState.totalClicks = 0;
    if (isNaN(gameState.clickPower)) gameState.clickPower = 2.50;
    if (isNaN(gameState.globalMultiplier)) gameState.globalMultiplier = 1.0;
    if (isNaN(gameState.upgradeCost)) gameState.upgradeCost = 1000;
    if (isNaN(gameState.upgradeBonus)) gameState.upgradeBonus = 1.60;
    if (isNaN(gameState.clickLevel)) gameState.clickLevel = 1;
    if (isNaN(gameState.pps)) gameState.pps = 0;
    if (isNaN(gameState.level) || !gameState.level) gameState.level = 1;
    if (isNaN(gameState.xp) || !gameState.xp) gameState.xp = 0;
    if (isNaN(gameState.xpToNextLevel) || !gameState.xpToNextLevel) gameState.xpToNextLevel = 10;
    if (!gameState.activeBoost) gameState.activeBoost = { active: false, multiplier: 1, timeLeft: 0 };
    if (!gameState.lastSaveTime) gameState.lastSaveTime = Date.now();
    if (!gameState.achievements) gameState.achievements = [];
    
    // Настройки по умолчанию
    if (!gameState.settings) {
        gameState.settings = { sound: true, soundVolume: 50, music: true, musicVolume: 30, vibration: true };
    }

    // Пересчет и отрисовка
    recalculateGlobalMultiplier();
    recalculatePPS();
    ui.render();

    // ==========================================
    // ОФЛАЙН-ДОХОД С ЗАЩИТОЙ
    // ==========================================
    setTimeout(() => {
        if (gameState.pps > 0 && gameState.lastSaveTime) {
            const check = AntiCheat.validateTime(gameState);

            if (!check.valid && check.reason === 'time_backwards') {
                createFloatingText({ clientX: window.innerWidth / 2, clientY: window.innerHeight / 2 }, `⚠️ ОБНАРУЖЕНА ПЕРЕМОТКА ВРЕМЕНИ!`, true);
                return;
            }

            if (check.secondsPassed > 10) {
                const baseEarned = check.secondsPassed * gameState.pps;
                const penaltyMultiplier = AntiCheat.getTimePenaltyMultiplier(gameState);
                const finalReward = baseEarned * penaltyMultiplier;
                
                const modal = document.getElementById('offline-modal');
                const modalAmountText = document.getElementById('offline-amount-text');
                const modalBtn = document.getElementById('close-modal-btn');
                
                if (modal && modalAmountText && modalBtn) {
                    modalAmountText.innerText = ui.formatCurrency(finalReward);
                    if (penaltyMultiplier < 1) {
                        modalAmountText.innerHTML += `<br><span style="font-size: 14px; color: #ff4757;">(Штраф x2 за читерство со временем)</span>`;
                    }
                    modal.classList.remove('hidden');
                    
                    modalBtn.addEventListener('click', () => {
                        gameState.balance += finalReward;
                        gameState.totalEarned += finalReward;
                        modal.classList.add('hidden');
                        ui.render();
                        if (typeof storage !== 'undefined') storage.save();
                    }, { once: true });
                }
            }
            gameState.lastSaveTime = Date.now();
        }
    }, 100);

    // ==========================================
    // КЛИКЕР (Мультитач)
    // ==========================================
    const clickArea = document.getElementById('click-area');
    
    function handleCook(e) {
        if (e.type === 'touchstart') e.preventDefault(); 
        if (!AntiCheat.validateClick()) return; 

        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const clientY = e.touches ? e.touches[0].clientY : e.clientY;

        const isCrit = Math.random() < 0.10;
        const power = Number(gameState.clickPower) || 1.0;
        let multiplier = Number(gameState.globalMultiplier) || 1.0;
        
        if (gameState.activeBoost.active) {
            multiplier *= gameState.activeBoost.multiplier;
        }

        const currentBalance = Number(gameState.balance) || 0;
        const currentEarn = (isCrit ? power * 5 : power) * multiplier;
        
        gameState.balance = currentBalance + currentEarn;
        gameState.totalEarned += currentEarn;
        gameState.totalClicks = (gameState.totalClicks || 0) + 1;
        
        addExperience(isCrit ? 3 : 1);
        
        ui.render();
        if (Math.random() < 0.1 && typeof storage !== 'undefined') storage.save();
        
        const fakeEvent = { clientX: clientX, clientY: clientY };
        if (isCrit) {
            createFloatingText(fakeEvent, `🔥 VIP! +$${currentEarn.toFixed(2)}`, true);
        } else {
            createFloatingText(fakeEvent, `+$${currentEarn.toFixed(2)}`, false);
        }
    }

    if (clickArea) {
        clickArea.addEventListener('pointerdown', (e) => {
            if (e.pointerType === 'touch') e.preventDefault(); 
            handleCook(e);
        });
        clickArea.addEventListener('touchstart', (e) => {
            if (!window.PointerEvent) {
                e.preventDefault();
                for (let i = 0; i < e.touches.length; i++) {
                    const touch = e.touches[i];
                    const fakeEvent = { clientX: touch.clientX, clientY: touch.clientY, type: 'touchstart' };
                    handleCook(fakeEvent);
                }
            }
        }, { passive: false });
        clickArea.addEventListener('mousedown', (e) => {
            if (e.pointerType !== 'touch') handleCook(e);
        });
    }

    // УРОВНИ
    function addExperience(amount) {
        gameState.xp += amount;
        while (gameState.xp >= gameState.xpToNextLevel) {
            gameState.xp -= gameState.xpToNextLevel;
            gameState.level += 1;
            gameState.xpToNextLevel = Math.floor(gameState.xpToNextLevel * 1.5);
            gameState.clickPower = gameState.clickPower * 1.1;
            createFloatingText({ clientX: window.innerWidth / 2, clientY: window.innerHeight / 2 }, `🏆 УРОВЕНЬ ${gameState.level}!`, true);
        }
    }

    // АПГРЕЙД
    const upgradeBtn = document.getElementById('upgrade-tools-btn');
    if (upgradeBtn) {
        upgradeBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            if (gameState.balance >= gameState.upgradeCost) {
                gameState.balance -= gameState.upgradeCost;
                gameState.clickLevel += 1;
                gameState.clickPower += gameState.upgradeBonus;
                gameState.upgradeCost = gameState.upgradeCost * 1.75;
                ui.render();
                if (typeof storage !== 'undefined') storage.save();
            } else { shakeCard(upgradeBtn); }
        });
    }

    // НАВИГАЦИЯ
    const tabs = {
        'tab-recipes': document.getElementById('screen-recipes'),
        'tab-staff': document.getElementById('screen-staff'),
        'tab-kitchen': document.getElementById('screen-kitchen'),
        'tab-inventory': document.getElementById('screen-inventory'),
        'tab-restaurants': document.getElementById('screen-restaurants')
    };

    Object.keys(tabs).forEach(tabId => {
        const tabBtn = document.getElementById(tabId);
        if (tabBtn) {
            tabBtn.addEventListener('click', () => {
                Object.keys(tabs).forEach(id => {
                    const btn = document.getElementById(id);
                    if (btn) btn.classList.remove('active');
                    if (tabs[id]) tabs[id].classList.add('hidden');
                });
                tabBtn.classList.add('active');
                if (tabs[tabId]) tabs[tabId].classList.remove('hidden');
                if (tabId === 'tab-recipes') ui.renderRecipesList();
                if (tabId === 'tab-staff') ui.renderStaffList();
                if (tabId === 'tab-restaurants') ui.renderRestaurantsList();
                if (tabId === 'tab-inventory') ui.renderInventoryList();
            });
        }
    });

    // ПОКУПКИ
    const recipesContainer = document.getElementById('recipes-container');
    if (recipesContainer) {
        recipesContainer.addEventListener('click', (e) => {
            const card = e.target.closest('.staff-card');
            if (!card || card.classList.contains('purchased')) return;
            const recipe = gameState.recipes.find(r => r.id === card.getAttribute('data-id'));
            if (recipe && gameState.balance >= recipe.cost) {
                gameState.balance -= recipe.cost;
                recipe.purchased = true;
                gameState.clickPower += recipe.bonus;
                ui.render();
                if (typeof storage !== 'undefined') storage.save();
            } else { shakeCard(card); }
        });
    }

    const staffContainer = document.getElementById('staff-container');
    if (staffContainer) {
        staffContainer.addEventListener('click', (e) => {
            const card = e.target.closest('.staff-card');
            if (!card) return;
            const employee = gameState.staff.find(s => s.id === card.getAttribute('data-id'));
            if (employee && gameState.balance >= employee.cost) {
                gameState.balance -= employee.cost;
                employee.count += 1;
                employee.cost = Math.round(employee.cost * 1.20);
                recalculatePPS();
                ui.render();
                if (typeof storage !== 'undefined') storage.save();
            } else { shakeCard(card); }
        });
    }

    const restaurantsContainer = document.getElementById('restaurants-container');
    if (restaurantsContainer) {
        restaurantsContainer.addEventListener('click', (e) => {
            const card = e.target.closest('.staff-card');
            if (!card || card.classList.contains('purchased')) return;
            const restaurant = gameState.restaurants.find(r => r.id === card.getAttribute('data-id'));
            if (restaurant && gameState.balance >= restaurant.cost) {
                gameState.balance -= restaurant.cost;
                restaurant.purchased = true;
                recalculatePPS();
                ui.render();
                if (typeof storage !== 'undefined') storage.save();
            } else { shakeCard(card); }
        });
    }

    const inventoryContainer = document.getElementById('inventory-container');
    if (inventoryContainer) {
        inventoryContainer.addEventListener('click', (e) => {
            const card = e.target.closest('.staff-card');
            if (!card || card.classList.contains('purchased')) return;
            const item = gameState.inventory.find(i => i.id === card.getAttribute('data-id'));
            if (item && gameState.balance >= item.cost) {
                gameState.balance -= item.cost;
                item.purchased = true;
                recalculateGlobalMultiplier();
                recalculatePPS();
                ui.render();
                if (typeof storage !== 'undefined') storage.save();
            } else { shakeCard(card); }
        });
    }

    function shakeCard(card) {
        card.classList.add('shake');
        setTimeout(() => card.classList.remove('shake'), 400);
    }

    function recalculateGlobalMultiplier() {
        let multiplierBonus = 1.00;
        gameState.inventory.forEach(item => {
            if (item.purchased) multiplierBonus += item.percentageBonus;
        });
        if (gameState.michelinStars > 0) {
            multiplierBonus += (gameState.michelinStars * 0.20);
        }
        gameState.globalMultiplier = multiplierBonus;
    }

    function recalculatePPS() {
        let totalBasePPS = 0;
        gameState.staff.forEach(employee => {
            totalBasePPS += employee.count * employee.income;
        });
        gameState.basePps = totalBasePPS;

        let currentPps = totalBasePPS;
        gameState.restaurants.forEach(restaurant => {
            if (restaurant.purchased) currentPps = currentPps * restaurant.multiplier;
        });
        gameState.pps = currentPps * gameState.globalMultiplier;
    }

    // ПАССИВНЫЙ ДОХОД
    setInterval(() => {
        if (gameState.activeBoost.active) {
            gameState.activeBoost.timeLeft -= 1;
            if (gameState.activeBoost.timeLeft <= 0) {
                gameState.activeBoost.active = false;
                gameState.activeBoost.multiplier = 1;
                document.getElementById('app-container').classList.remove('boost-active');
            }
        }
        if (gameState.pps > 0) {
            let multiplier = gameState.activeBoost.active ? gameState.activeBoost.multiplier : 1;
            const earn = gameState.pps * multiplier;
            gameState.balance += earn;
            gameState.totalEarned += earn;
            ui.render();
            if (Math.random() < 0.2 && typeof storage !== 'undefined') storage.save(); 
        }
    }, 1000);

    // ПРЕСТИЖ
    window.openPrestigeModal = function() {
        const total = gameState.totalEarned || 0;
        const possibleStars = Math.floor(Math.pow(total / 1000000, 0.5) * 10) || 0;
        const starsToGain = possibleStars - gameState.michelinStars;
        if (starsToGain > 0) {
            document.getElementById('prestige-reward').innerText = starsToGain;
            document.getElementById('prestige-modal').classList.remove('hidden');
        }
    };

    window.closePrestigeModal = function() {
        document.getElementById('prestige-modal').classList.add('hidden');
    };

    const prestigeBtn = document.getElementById('prestige-btn');
    if (prestigeBtn) prestigeBtn.addEventListener('click', openPrestigeModal);

    const confirmPrestigeBtn = document.getElementById('confirm-prestige-btn');
    if (confirmPrestigeBtn) {
        confirmPrestigeBtn.addEventListener('click', () => {
            const total = gameState.totalEarned || 0;
            const possibleStars = Math.floor(Math.pow(total / 1000000, 0.5) * 10) || 0;
            const starsToGain = possibleStars - gameState.michelinStars;

            if (starsToGain > 0) {
                gameState.michelinStars += starsToGain;
                gameState.balance = 0.00;
                gameState.totalEarned = 0.00;
                gameState.clickLevel = 1;
                gameState.clickPower = 2.50;
                gameState.upgradeBonus = 1.60;
                gameState.upgradeCost = 1000.00;
                gameState.pps = 0.00;
                gameState.level = 1;
                gameState.xp = 0;
                gameState.xpToNextLevel = 10;
                gameState.activeBoost = { active: false, multiplier: 1, timeLeft: 0 };

                gameState.staff.forEach(s => { s.count = 0; s.cost = s.baseCost; });
                gameState.recipes.forEach(r => r.purchased = false);
                gameState.restaurants.forEach(r => r.purchased = false);
                gameState.inventory.forEach(i => i.purchased = false);

                recalculateGlobalMultiplier();
                recalculatePPS();
                closePrestigeModal();
                ui.render();
                if (typeof storage !== 'undefined') storage.save();
                createFloatingText({ clientX: window.innerWidth / 2, clientY: window.innerHeight / 2 }, `🌟 ПРЕСТИЖ! +${starsToGain} ЗВЕЗД!`, true);
            }
        });
    }

    // ЗОЛОТОЙ БУРГЕР
    const goldenBurger = document.getElementById('golden-burger');
    let goldenTimeout, goldenHideTimeout;

    function spawnGoldenBurger() {
        const nextSpawn = Math.floor(Math.random() * 120000) + 60000;
        goldenTimeout = setTimeout(() => {
            if (!goldenBurger) return;
            goldenBurger.style.left = `${Math.floor(Math.random() * 60) + 20}%`;
            goldenBurger.style.top = `${Math.floor(Math.random() * 60) + 20}%`;
            goldenBurger.classList.remove('hidden');
            goldenHideTimeout = setTimeout(() => {
                goldenBurger.classList.add('hidden');
                spawnGoldenBurger();
            }, 5000);
        }, nextSpawn);
    }

    if (goldenBurger) {
        goldenBurger.addEventListener('click', () => {
            clearTimeout(goldenHideTimeout);
            goldenBurger.classList.add('hidden');
            const rewardType = Math.floor(Math.random() * 3);
            const appContainer = document.getElementById('app-container');

            if (rewardType === 0) {
                const cashReward = (gameState.pps * 300) || (gameState.clickPower * 50);
                gameState.balance += cashReward;
                gameState.totalEarned += cashReward;
                createFloatingText({ clientX: window.innerWidth / 2, clientY: window.innerHeight / 2 }, `💰 ДЖЕКПОТ! +$${cashReward.toFixed(2)}`, true);
            } else if (rewardType === 1) {
                gameState.activeBoost = { active: true, multiplier: 3, timeLeft: 30 };
                appContainer.classList.add('boost-active');
                createFloatingText({ clientX: window.innerWidth / 2, clientY: window.innerHeight / 2 }, `🔥 БУСТ x3 (30 сек)!`, true);
            } else {
                gameState.xp += gameState.xpToNextLevel;
                addExperience(0);
                createFloatingText({ clientX: window.innerWidth / 2, clientY: window.innerHeight / 2 }, `🏆 МГНОВЕННЫЙ УРОВЕНЬ!`, true);
            }
            ui.render();
            if (typeof storage !== 'undefined') storage.save();
            spawnGoldenBurger();
        });
    }
    setTimeout(spawnGoldenBurger, 20000);

    // ==========================================
    // НАСТРОЙКИ И ДОСТИЖЕНИЯ
    // ==========================================
    function updateSettingsUI() {
        const toggleSound = document.getElementById('toggle-sound');
        const toggleMusic = document.getElementById('toggle-music');
        const toggleVibration = document.getElementById('toggle-vibration');
        const sliders = document.querySelectorAll('.volume-slider');
        
        if (toggleSound && sliders[0]) {
            if (gameState.settings.sound) {
                toggleSound.classList.add('active');
                sliders[0].classList.remove('inactive');
            } else {
                toggleSound.classList.remove('active');
                sliders[0].classList.add('inactive');
            }
            sliders[0].value = gameState.settings.soundVolume;
        }

        if (toggleMusic && sliders[1]) {
            if (gameState.settings.music) {
                toggleMusic.classList.add('active');
                sliders[1].classList.remove('inactive');
            } else {
                toggleMusic.classList.remove('active');
                sliders[1].classList.add('inactive');
            }
            sliders[1].value = gameState.settings.musicVolume;
        }

        if (toggleVibration) {
            if (gameState.settings.vibration) toggleVibration.classList.add('active');
            else toggleVibration.classList.remove('active');
        }
    }

    window.openSettingsModal = function() {
        const modal = document.getElementById('settings-modal');
        if (!modal) return;
        
        const statTotal = document.getElementById('stat-total-earned');
        const statStars = document.getElementById('stat-stars');
        const statClicks = document.getElementById('stat-total-clicks');
        
        if (statTotal) statTotal.innerText = ui.formatCurrency(gameState.totalEarned || 0);
        if (statStars) statStars.innerText = (gameState.michelinStars || 0) + ' ⭐';
        if (statClicks) statClicks.innerText = (gameState.totalClicks || 0).toLocaleString('ru-RU');
        
        updateSettingsUI();
        ui.renderAchievements(); 
        modal.classList.remove('hidden');
    };

    const toggleSound = document.getElementById('toggle-sound');
    const toggleMusic = document.getElementById('toggle-music');
    const toggleVibration = document.getElementById('toggle-vibration');
    const sliders = document.querySelectorAll('.volume-slider');

    if (toggleSound) toggleSound.addEventListener('click', () => { gameState.settings.sound = !gameState.settings.sound; updateSettingsUI(); if (typeof storage !== 'undefined') storage.save(); });
    if (toggleMusic) toggleMusic.addEventListener('click', () => { gameState.settings.music = !gameState.settings.music; updateSettingsUI(); if (typeof storage !== 'undefined') storage.save(); });
    if (toggleVibration) toggleVibration.addEventListener('click', () => { gameState.settings.vibration = !gameState.settings.vibration; updateSettingsUI(); if (typeof storage !== 'undefined') storage.save(); });

    if (sliders[0]) {
        sliders[0].addEventListener('input', (e) => {
            gameState.settings.soundVolume = parseInt(e.target.value);
            gameState.settings.sound = gameState.settings.soundVolume > 0;
            updateSettingsUI();
            if (typeof storage !== 'undefined') storage.save();
        });
    }
    if (sliders[1]) {
        sliders[1].addEventListener('input', (e) => {
            gameState.settings.musicVolume = parseInt(e.target.value);
            gameState.settings.music = gameState.settings.musicVolume > 0;
            updateSettingsUI();
            if (typeof storage !== 'undefined') storage.save();
        });
    }

    // ВЫХОД И СОХРАНЕНИЕ
    window.addEventListener('beforeunload', () => { 
        gameState.lastSaveTime = Date.now();
        if (typeof storage !== 'undefined') storage.save(); 
    });
    window.addEventListener('pagehide', () => { 
        gameState.lastSaveTime = Date.now();
        if (typeof storage !== 'undefined') storage.save(); 
    });

    // АНИМАЦИЯ ТЕКСТА
    function createFloatingText(e, text, isCrit) {
        const textNode = document.createElement('div');
        textNode.innerText = text;
        textNode.className = `floating-text ${isCrit ? 'crit' : 'normal'}`;
        
        let x = e.clientX;
        let y = e.clientY;
        if (e.touches && e.touches[0]) {
            x = e.touches[0].clientX;
            y = e.touches[0].clientY;
        } else if (!x && !y) {
            x = window.innerWidth / 2;
            y = window.innerHeight / 2;
        }
        
        textNode.style.left = `${x}px`;
        textNode.style.top = `${y}px`;
        textNode.style.marginLeft = `${(Math.random() - 0.5) * 40}px`;

        document.body.appendChild(textNode);
        setTimeout(() => {
            if (textNode.parentNode) textNode.parentNode.removeChild(textNode);
        }, 800);
    }
});