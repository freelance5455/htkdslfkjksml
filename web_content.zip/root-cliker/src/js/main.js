document.addEventListener('DOMContentLoaded', () => {
    storage.load();
    
    // --- ФИКС БИТЫХ СОХРАНЕНИЙ ---
    if (isNaN(gameState.balance) || gameState.balance === undefined) gameState.balance = 0;
    if (isNaN(gameState.totalEarned)) gameState.totalEarned = 0;
    if (isNaN(gameState.michelinStars)) gameState.michelinStars = 0;
    if (isNaN(gameState.clickPower)) gameState.clickPower = 2.50;
    if (isNaN(gameState.globalMultiplier)) gameState.globalMultiplier = 1.0;
    if (isNaN(gameState.upgradeCost)) gameState.upgradeCost = 1000;
    if (isNaN(gameState.upgradeBonus)) gameState.upgradeBonus = 1.60;
    if (isNaN(gameState.clickLevel)) gameState.clickLevel = 1;
    if (isNaN(gameState.pps)) gameState.pps = 0;
    
    if (isNaN(gameState.level) || !gameState.level) gameState.level = 1;
    if (isNaN(gameState.xp) || !gameState.xp) gameState.xp = 0;
    if (isNaN(gameState.xpToNextLevel) || !gameState.xpToNextLevel) gameState.xpToNextLevel = 10;
    
    if (!gameState.activeBoost) gameState.activeBoost = { active: false, multiplier: 1, timeLeft: 0 };

    recalculateGlobalMultiplier();
    recalculatePPS();
    ui.render();

    // ОФЛАЙН ДОХОД
    setTimeout(() => {
        if (gameState.pps > 0 && gameState.lastSaveTime) {
            const currentTime = Date.now();
            const secondsPassed = Math.floor((currentTime - gameState.lastSaveTime) / 1000);
            
            if (secondsPassed > 10) {
                const offlineEarned = secondsPassed * gameState.pps;
                const modal = document.getElementById('offline-modal');
                const modalAmountText = document.getElementById('offline-amount-text');
                const modalBtn = document.getElementById('close-modal-btn');
                
                if (modal && modalAmountText && modalBtn) {
                    modalAmountText.innerText = ui.formatCurrency(offlineEarned);
                    modal.classList.remove('hidden');
                    
                    modalBtn.addEventListener('click', () => {
                        gameState.balance += offlineEarned;
                        gameState.totalEarned += offlineEarned;
                        modal.classList.add('hidden');
                        ui.render();
                        storage.save();
                    }, { once: true });
                }
            }
        }
    }, 100);

    // МУЛЬТИТАЧ КЛИКЕР
    const clickArea = document.getElementById('click-area');
    
    function handleCook(e) {
        if (e.type === 'touchstart') e.preventDefault(); 

        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const clientY = e.touches ? e.touches[0].clientY : e.clientY;

        const isCrit = Math.random() < 0.10;
        
        const power = Number(gameState.clickPower) || 1.0;
        let multiplier = Number(gameState.globalMultiplier) || 1.0;
        
        if (gameState.activeBoost.active) {
            multiplier *= gameState.activeBoost.multiplier;
        }

        const currentBalance = Number(gameState.balance) || 0;
        const currentEarn = (isCrit ? power * 5 : power) * multiplier;
        
        gameState.balance = currentBalance + currentEarn;
        gameState.totalEarned += currentEarn;
        
        addExperience(isCrit ? 3 : 1);
        
        ui.render();
        if (Math.random() < 0.1) storage.save();
        
        const fakeEvent = { clientX: clientX, clientY: clientY };
        if (isCrit) {
            createFloatingText(fakeEvent, `🔥 VIP! +$${currentEarn.toFixed(2)}`, true);
        } else {
            createFloatingText(fakeEvent, `+$${currentEarn.toFixed(2)}`, false);
        }
    }

    if (clickArea) {
        clickArea.addEventListener('pointerdown', (e) => {
            if (e.pointerType === 'touch') e.preventDefault(); 
            handleCook(e);
        });

        clickArea.addEventListener('touchstart', (e) => {
            if (!window.PointerEvent) {
                e.preventDefault();
                for (let i = 0; i < e.touches.length; i++) {
                    const touch = e.touches[i];
                    const fakeEvent = { clientX: touch.clientX, clientY: touch.clientY, type: 'touchstart' };
                    handleCook(fakeEvent);
                }
            }
        }, { passive: false });
        
        clickArea.addEventListener('mousedown', (e) => {
            if (e.pointerType !== 'touch') {
                handleCook(e);
            }
        });
    }

    // УРОВНИ
    function addExperience(amount) {
        gameState.xp += amount;
        while (gameState.xp >= gameState.xpToNextLevel) {
            gameState.xp -= gameState.xpToNextLevel;
            gameState.level += 1;
            gameState.xpToNextLevel = Math.floor(gameState.xpToNextLevel * 1.5);
            gameState.clickPower = gameState.clickPower * 1.1;
            
            createFloatingText(
                { clientX: window.innerWidth / 2, clientY: window.innerHeight / 2 }, 
                `🏆 УРОВЕНЬ ${gameState.level}!`, 
                true
            );
        }
    }

    // АПГРЕЙД
    const upgradeBtn = document.getElementById('upgrade-tools-btn');
    if (upgradeBtn) {
        upgradeBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            if (gameState.balance >= gameState.upgradeCost) {
                gameState.balance -= gameState.upgradeCost;
                gameState.clickLevel += 1;
                gameState.clickPower += gameState.upgradeBonus;
                gameState.upgradeCost = gameState.upgradeCost * 1.75;
                ui.render();
                storage.save();
            } else {
                shakeCard(upgradeBtn);
            }
        });
    }

    // НАВИГАЦИЯ
    const tabs = {
        'tab-recipes': document.getElementById('screen-recipes'),
        'tab-staff': document.getElementById('screen-staff'),
        'tab-kitchen': document.getElementById('screen-kitchen'),
        'tab-inventory': document.getElementById('screen-inventory'),
        'tab-restaurants': document.getElementById('screen-restaurants')
    };

    Object.keys(tabs).forEach(tabId => {
        const tabBtn = document.getElementById(tabId);
        if (tabBtn) {
            tabBtn.addEventListener('click', () => {
                Object.keys(tabs).forEach(id => {
                    const btn = document.getElementById(id);
                    if (btn) btn.classList.remove('active');
                    if (tabs[id]) tabs[id].classList.add('hidden');
                });
                tabBtn.classList.add('active');
                if (tabs[tabId]) tabs[tabId].classList.remove('hidden');
                if (tabId === 'tab-recipes') ui.renderRecipesList();
                if (tabId === 'tab-staff') ui.renderStaffList();
                if (tabId === 'tab-restaurants') ui.renderRestaurantsList();
                if (tabId === 'tab-inventory') ui.renderInventoryList();
            });
        }
    });

    // ПОКУПКИ
    const recipesContainer = document.getElementById('recipes-container');
    if (recipesContainer) {
        recipesContainer.addEventListener('click', (e) => {
            const card = e.target.closest('.staff-card');
            if (!card || card.classList.contains('purchased')) return;
            const recipeId = card.getAttribute('data-id');
            const recipe = gameState.recipes.find(r => r.id === recipeId);
            if (recipe && gameState.balance >= recipe.cost) {
                gameState.balance -= recipe.cost;
                recipe.purchased = true;
                gameState.clickPower += recipe.bonus;
                ui.render();
                storage.save();
            } else { shakeCard(card); }
        });
    }

    const staffContainer = document.getElementById('staff-container');
    if (staffContainer) {
        staffContainer.addEventListener('click', (e) => {
            const card = e.target.closest('.staff-card');
            if (!card) return;
            const staffId = card.getAttribute('data-id');
            const employee = gameState.staff.find(s => s.id === staffId);
            if (employee && gameState.balance >= employee.cost) {
                gameState.balance -= employee.cost;
                employee.count += 1;
                employee.cost = Math.round(employee.cost * 1.20);
                recalculatePPS();
                ui.render();
                storage.save();
            } else { shakeCard(card); }
        });
    }

    const restaurantsContainer = document.getElementById('restaurants-container');
    if (restaurantsContainer) {
        restaurantsContainer.addEventListener('click', (e) => {
            const card = e.target.closest('.staff-card');
            if (!card || card.classList.contains('purchased')) return;
            const restId = card.getAttribute('data-id');
            const restaurant = gameState.restaurants.find(r => r.id === restId);
            if (restaurant && gameState.balance >= restaurant.cost) {
                gameState.balance -= restaurant.cost;
                restaurant.purchased = true;
                recalculatePPS();
                ui.render();
                storage.save();
            } else { shakeCard(card); }
        });
    }

    const inventoryContainer = document.getElementById('inventory-container');
    if (inventoryContainer) {
        inventoryContainer.addEventListener('click', (e) => {
            const card = e.target.closest('.staff-card');
            if (!card || card.classList.contains('purchased')) return;
            const itemId = card.getAttribute('data-id');
            const item = gameState.inventory.find(i => i.id === itemId);
            if (item && gameState.balance >= item.cost) {
                gameState.balance -= item.cost;
                item.purchased = true;
                recalculateGlobalMultiplier();
                recalculatePPS();
                ui.render();
                storage.save();
            } else { shakeCard(card); }
        });
    }

    function shakeCard(card) {
        card.classList.add('shake');
        setTimeout(() => card.classList.remove('shake'), 400);
    }

    function recalculateGlobalMultiplier() {
        let multiplierBonus = 1.00;
        gameState.inventory.forEach(item => {
            if (item.purchased) multiplierBonus += item.percentageBonus;
        });
        if (gameState.michelinStars > 0) {
            multiplierBonus += (gameState.michelinStars * 0.20);
        }
        gameState.globalMultiplier = multiplierBonus;
    }

    function recalculatePPS() {
        let totalBasePPS = 0;
        gameState.staff.forEach(employee => {
            totalBasePPS += employee.count * employee.income;
        });
        gameState.basePps = totalBasePPS;

        let currentPps = totalBasePPS;
        gameState.restaurants.forEach(restaurant => {
            if (restaurant.purchased) currentPps = currentPps * restaurant.multiplier;
        });
        
        gameState.pps = currentPps * gameState.globalMultiplier;
    }

    // ПАССИВНЫЙ ДОХОД
    setInterval(() => {
        if (gameState.activeBoost.active) {
            gameState.activeBoost.timeLeft -= 1;
            if (gameState.activeBoost.timeLeft <= 0) {
                gameState.activeBoost.active = false;
                gameState.activeBoost.multiplier = 1;
                document.getElementById('app-container').classList.remove('boost-active');
            }
        }

        if (gameState.pps > 0) {
            let multiplier = gameState.activeBoost.active ? gameState.activeBoost.multiplier : 1;
            const currentBalance = Number(gameState.balance) || 0;
            const earn = gameState.pps * multiplier;
            
            gameState.balance = currentBalance + earn;
            gameState.totalEarned += earn;
            
            ui.render();
            if (Math.random() < 0.2) storage.save(); 
        }
    }, 1000);

    // ПРЕСТИЖ
    window.openPrestigeModal = function() {
        const total = gameState.totalEarned || 0;
        const possibleStars = Math.floor(Math.pow(total / 1000000, 0.5) * 10) || 0;
        const starsToGain = possibleStars - gameState.michelinStars;

        if (starsToGain > 0) {
            document.getElementById('prestige-reward').innerText = starsToGain;
            document.getElementById('prestige-modal').classList.remove('hidden');
        }
    };

    window.closePrestigeModal = function() {
        document.getElementById('prestige-modal').classList.add('hidden');
    };

    const prestigeBtn = document.getElementById('prestige-btn');
    if (prestigeBtn) {
        prestigeBtn.addEventListener('click', openPrestigeModal);
    }

    const confirmPrestigeBtn = document.getElementById('confirm-prestige-btn');
    if (confirmPrestigeBtn) {
        confirmPrestigeBtn.addEventListener('click', () => {
            const total = gameState.totalEarned || 0;
            const possibleStars = Math.floor(Math.pow(total / 1000000, 0.5) * 10) || 0;
            const starsToGain = possibleStars - gameState.michelinStars;

            if (starsToGain > 0) {
                gameState.michelinStars += starsToGain;
                
                // СБРОС
                gameState.balance = 0.00;
                gameState.totalEarned = 0.00;
                gameState.clickLevel = 1;
                gameState.clickPower = 2.50;
                gameState.upgradeBonus = 1.60;
                gameState.upgradeCost = 1000.00;
                gameState.pps = 0.00;
                gameState.level = 1;
                gameState.xp = 0;
                gameState.xpToNextLevel = 10;
                gameState.activeBoost = { active: false, multiplier: 1, timeLeft: 0 };

                // Сброс сотрудников с восстановлением базовой цены
                gameState.staff.forEach(s => { 
                    s.count = 0; 
                    s.cost = s.baseCost; 
                });
                
                gameState.recipes.forEach(r => r.purchased = false);
                gameState.restaurants.forEach(r => r.purchased = false);
                gameState.inventory.forEach(i => i.purchased = false);

                recalculateGlobalMultiplier();
                recalculatePPS();
                
                closePrestigeModal();
                ui.render();
                storage.save();

                createFloatingText(
                    { clientX: window.innerWidth / 2, clientY: window.innerHeight / 2 }, 
                    `🌟 ПРЕСТИЖ! +${starsToGain} ЗВЕЗД!`, 
                    true
                );
            }
        });
    }

    // ЗОЛОТОЙ БУРГЕР
    const goldenBurger = document.getElementById('golden-burger');
    let goldenTimeout;
    let goldenHideTimeout;

    function spawnGoldenBurger() {
        const nextSpawn = Math.floor(Math.random() * 120000) + 60000;
        goldenTimeout = setTimeout(() => {
            if (!goldenBurger) return;
            const randomX = Math.floor(Math.random() * 60) + 20; 
            const randomY = Math.floor(Math.random() * 60) + 20; 
            goldenBurger.style.left = `${randomX}%`;
            goldenBurger.style.top = `${randomY}%`;
            goldenBurger.classList.remove('hidden');

            goldenHideTimeout = setTimeout(() => {
                goldenBurger.classList.add('hidden');
                spawnGoldenBurger();
            }, 5000);
        }, nextSpawn);
    }

    if (goldenBurger) {
        goldenBurger.addEventListener('click', () => {
            clearTimeout(goldenHideTimeout);
            goldenBurger.classList.add('hidden');

            const rewardType = Math.floor(Math.random() * 3);
            const appContainer = document.getElementById('app-container');

            if (rewardType === 0) {
                const cashReward = (gameState.pps * 300) || (gameState.clickPower * 50);
                gameState.balance += cashReward;
                gameState.totalEarned += cashReward;
                createFloatingText({ clientX: window.innerWidth / 2, clientY: window.innerHeight / 2 }, `💰 ДЖЕКПОТ! +$${cashReward.toFixed(2)}`, true);
            } else if (rewardType === 1) {
                gameState.activeBoost = { active: true, multiplier: 3, timeLeft: 30 };
                appContainer.classList.add('boost-active');
                createFloatingText({ clientX: window.innerWidth / 2, clientY: window.innerHeight / 2 }, `🔥 БУСТ x3 (30 сек)!`, true);
            } else {
                gameState.xp += gameState.xpToNextLevel;
                addExperience(0);
                createFloatingText({ clientX: window.innerWidth / 2, clientY: window.innerHeight / 2 }, `🏆 МГНОВЕННЫЙ УРОВЕНЬ!`, true);
            }

            ui.render();
            storage.save();
            spawnGoldenBurger();
        });
    }

    setTimeout(spawnGoldenBurger, 20000);

    window.addEventListener('beforeunload', () => { storage.save(); });
    window.addEventListener('pagehide', () => { storage.save(); });

    // АНИМАЦИЯ
    function createFloatingText(e, text, isCrit) {
        const textNode = document.createElement('div');
        textNode.innerText = text;
        textNode.style.position = 'absolute';
        textNode.style.pointerEvents = 'none';
        textNode.style.zIndex = '1000';
        textNode.style.left = `${e.clientX + window.scrollX}px`;
        textNode.style.top = `${e.clientY + window.scrollY}px`;
        textNode.style.transform = 'translate(-50%, -50%)';
        textNode.style.animation = 'cookFloatUp 1.2s ease-out forwards';
        
        if (isCrit) {
            textNode.style.color = '#f39c12';
            textNode.style.fontWeight = '900';
            textNode.style.fontSize = '32px';
            textNode.style.textShadow = '0 0 15px rgba(243, 156, 18, 0.8), 0 0 5px #000';
        } else {
            textNode.style.color = '#fff';
            textNode.style.fontWeight = 'bold';
            textNode.style.fontSize = '22px';
            textNode.style.textShadow = '0 2px 5px rgba(0,0,0,0.8)';
        }
        
        const randomX = (Math.random() - 0.5) * 150;
        
        let styleTag = document.getElementById('culinary-animation-style');
        if (!styleTag) {
            styleTag = document.createElement('style');
            styleTag.id = 'culinary-animation-style';
            document.head.appendChild(styleTag);
        }
        
        styleTag.innerHTML = `
            @keyframes cookFloatUp {
                0% { opacity: 1; transform: translate(-50%, -50%) scale(0.5); }
                20% { transform: translate(calc(-50% + ${randomX / 4}px), -40px) scale(1.2); }
                100% { opacity: 0; transform: translate(calc(-50% + ${randomX}px), -200px) scale(1); }
            }
            @keyframes cardShake {
                0%, 100% { transform: translateX(0); }
                25% { transform: translateX(-6px); }
                75% { transform: translateX(6px); }
            }
            .shake { animation: cardShake 0.15s ease-in-out 2; }
        `;

        document.body.appendChild(textNode);
        setTimeout(() => textNode.remove(), 1200);
    }
});