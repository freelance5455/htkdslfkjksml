// src/js/database.js

// Вшитые ключи Supabase
const SUPABASE_URL = 'https://ccnmpwkfydawvmcnntaf.supabase.co';
const SUPABASE_KEY = 'sb_publishable_M6TButfMaK-KYQ5TXLboxg_xpE5UROG';

// Уникальный ID игрока (создается один раз при первом заходе)
let playerId = localStorage.getItem('playerId');
if (!playerId) {
    playerId = 'player_' + Math.random().toString(36).substring(2, 10);
    localStorage.setItem('playerId', playerId);
}

async function syncWithServer() {
    try {
        // 1. Проверка на бан И получение баланса
        const checkResponse = await fetch(`${SUPABASE_URL}/rest/v1/players?id=eq.${playerId}&select=*`, {
            method: 'GET',
            headers: { 'apikey': SUPABASE_KEY }
        });
        
        if (checkResponse.ok) {
            const checkData = await checkResponse.json();
            
            if (checkData.length > 0) {
                const serverData = checkData[0];

                // БАН
                if (serverData.is_banned) {
                    localStorage.clear();
                    alert('⚠️ Ваш аккаунт заблокирован администратором. Прогресс сброшен.');
                    window.location.reload();
                    return;
                }

                // 👇 НОВОЕ: Если на сервере баланс БОЛЬШЕ, чем в игре, мы забираем его (чтобы работали админские правки)
                if (serverData.balance > gameState.balance) {
                    gameState.balance = serverData.balance;
                    gameState.michelinStars = serverData.michelin_stars;
                    gameState.level = serverData.level;
                    ui.render();
                    // Сохраняем в локальный кэш, чтобы не потерять
                    if (typeof storage !== 'undefined') storage.save();
                    console.log('Баланс обновлен с сервера!');
                }
            }
        }

        // 2. Отправка данных (как было)
        const upsertResponse = await fetch(`${SUPABASE_URL}/rest/v1/players`, {
            method: 'POST',
            headers: {
                'apikey': SUPABASE_KEY,
                'Content-Type': 'application/json',
                'Prefer': 'resolution=merge-duplicates'
            },
            body: JSON.stringify({
                id: playerId,
                balance: gameState.balance,
                michelin_stars: gameState.michelinStars || 0,
                level: gameState.level || 1,
                last_seen: new Date().toISOString()
            })
        });

    } catch (e) {
        console.log('Ошибка синхронизации:', e);
    }
}

// Отправляем данные при запуске (с задержкой 2 секунды, чтобы gameState точно загрузился)
setTimeout(syncWithServer, 2000);

// Отправляем данные каждые 60 секунд
setInterval(syncWithServer, 60000);

// Отправляем данные при закрытии игры
window.addEventListener('beforeunload', syncWithServer);