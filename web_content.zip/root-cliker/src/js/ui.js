const ui = {
    formatCurrency: function(value) {
        const num = Number(value) || 0;
        return '$ ' + num.toLocaleString('ru-RU', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
    },

    getCurrentDish: function() {
        let currentDish = gameState.dishes[0];
        for (let i = 0; i < gameState.dishes.length; i++) {
            if (gameState.clickLevel >= gameState.dishes[i].minLevel) {
                currentDish = gameState.dishes[i];
            }
        }
        return currentDish;
    },

    renderRecipesList: function() {
        const container = document.getElementById('recipes-container');
        if (!container) return;
        container.innerHTML = '';

        gameState.recipes.forEach((recipe) => {
            const card = document.createElement('div');
            card.className = `staff-card ${recipe.purchased ? 'purchased' : ''}`;
            card.setAttribute('data-id', recipe.id);

            card.innerHTML = `
                <div class="staff-info-block">
                    <div class="staff-avatar">${recipe.icon}</div>
                    <div class="staff-details">
                        <span class="staff-main-name">${recipe.name}</span>
                        <span class="staff-income-text">+${this.formatCurrency(recipe.bonus)} за заказ</span>
                    </div>
                </div>
                <div class="staff-buy-block">
                    ${recipe.purchased 
                        ? `<span class="recipe-status-purchased">Изучено ✔</span>` 
                        : `<span class="staff-count-badge">Изучить:</span>
                           <span class="staff-cost-text">${this.formatCurrency(recipe.cost)}</span>`
                    }
                </div>
            `;
            container.appendChild(card);
        });
    },

    renderStaffList: function() {
        const container = document.getElementById('staff-container');
        if (!container) return;
        container.innerHTML = '';

        gameState.staff.forEach((employee) => {
            const card = document.createElement('div');
            card.className = 'staff-card';
            card.setAttribute('data-id', employee.id);

            card.innerHTML = `
                <div class="staff-info-block">
                    <div class="staff-avatar">${employee.icon}</div>
                    <div class="staff-details">
                        <span class="staff-main-name">${employee.name}</span>
                        <span class="staff-income-text">+${this.formatCurrency(employee.income)}/сек</span>
                    </div>
                </div>
                <div class="staff-buy-block">
                    <span class="staff-count-badge">Нанято: ${employee.count}</span>
                    <span class="staff-cost-text">${this.formatCurrency(employee.cost)}</span>
                </div>
            `;
            container.appendChild(card);
        });
    },

    renderRestaurantsList: function() {
        const container = document.getElementById('restaurants-container');
        if (!container) return;
        container.innerHTML = '';

        gameState.restaurants.forEach((restaurant) => {
            const card = document.createElement('div');
            card.className = `staff-card ${restaurant.purchased ? 'purchased' : ''}`;
            card.setAttribute('data-id', restaurant.id);

            card.innerHTML = `
                <div class="staff-info-block">
                    <div class="staff-avatar">${restaurant.icon}</div>
                    <div class="staff-details">
                        <span class="staff-main-name">${restaurant.name}</span>
                        <span class="staff-income-text" style="color: #4ade80;">Мультипликатор: x${restaurant.multiplier}</span>
                    </div>
                </div>
                <div class="staff-buy-block">
                    ${restaurant.purchased 
                        ? `<span class="recipe-status-purchased" style="color: #4ade80;">Куплено ✔</span>` 
                        : `<span class="staff-count-badge">Купить объект:</span>
                           <span class="staff-cost-text">${this.formatCurrency(restaurant.cost)}</span>`
                    }
                </div>
            `;
            container.appendChild(card);
        });
    },

    renderInventoryList: function() {
        const container = document.getElementById('inventory-container');
        if (!container) return;
        container.innerHTML = '';

        gameState.inventory.forEach((item) => {
            const card = document.createElement('div');
            card.className = `staff-card ${item.purchased ? 'purchased' : ''}`;
            card.setAttribute('data-id', item.id);

            card.innerHTML = `
                <div class="staff-info-block">
                    <div class="staff-avatar">${item.icon}</div>
                    <div class="staff-details">
                        <span class="staff-main-name">${item.name}</span>
                        <span class="staff-income-text" style="color: #f39c12;">Доход: +${(item.percentageBonus * 100).toFixed(0)}%</span>
                    </div>
                </div>
                <div class="staff-buy-block">
                    ${item.purchased 
                        ? `<span class="recipe-status-purchased">В закупке ✔</span>` 
                        : `<span class="staff-count-badge">Закупить:</span>
                           <span class="staff-cost-text">${this.formatCurrency(item.cost)}</span>`
                    }
                </div>
            `;
            container.appendChild(card);
        });
    },

    render: function() {
        const balanceEl = document.getElementById('balance');
        const ppsEl = document.getElementById('pps-value');
        const clickPowerEl = document.getElementById('click-power-text');
        const upgradeBonusEl = document.getElementById('click-upgrade-bonus');
        const clickLevelEl = document.getElementById('click-level');
        const upgradeCostEl = document.getElementById('upgrade-cost');
        const progressEl = document.getElementById('upgrade-progress');
        const dishIconEl = document.getElementById('dish-icon');
        const dishNameEl = document.getElementById('dish-name');

        if (balanceEl) balanceEl.innerText = this.formatCurrency(gameState.balance);
        if (ppsEl) ppsEl.innerText = this.formatCurrency(gameState.pps);
        if (clickPowerEl) clickPowerEl.innerText = this.formatCurrency(gameState.clickPower);
        
        if (upgradeBonusEl) {
            const nextPower = gameState.clickPower + gameState.upgradeBonus;
            upgradeBonusEl.innerText = this.formatCurrency(nextPower);
        }
        
        if (clickLevelEl) clickLevelEl.innerText = gameState.clickLevel;
        if (upgradeCostEl) upgradeCostEl.innerText = this.formatCurrency(gameState.upgradeCost);

        if (progressEl) {
            const progressPercent = Math.min((gameState.balance / gameState.upgradeCost) * 100, 100) || 0;
            progressEl.style.width = progressPercent + '%';
        }

        const activeDish = this.getCurrentDish();
        if (dishIconEl) dishIconEl.innerText = activeDish.icon;
        if (dishNameEl) dishNameEl.innerText = activeDish.name;

        // Отрисовка уровня
        const levelEl = document.getElementById('player-level');
        const xpTextEl = document.getElementById('level-xp-text');
        const xpBarEl = document.getElementById('level-xp-bar');

        if (levelEl) levelEl.innerText = gameState.level || 1;
        
        if (xpTextEl) {
            const currentXp = Math.floor(gameState.xp || 0);
            const maxXp = Math.floor(gameState.xpToNextLevel || 10);
            xpTextEl.innerText = `${currentXp.toLocaleString('ru-RU')} / ${maxXp.toLocaleString('ru-RU')} XP`;
        }
        
        if (xpBarEl) {
            const currentXp = gameState.xp || 0;
            const maxXp = gameState.xpToNextLevel || 10;
            const percent = Math.min((currentXp / maxXp) * 100, 100);
            xpBarEl.style.width = percent + '%';
        }

        // Отрисовка престижа
        const prestigeContainer = document.getElementById('prestige-container');
        const prestigeStarsCount = document.getElementById('prestige-stars-count');
        const prestigeBtn = document.getElementById('prestige-btn');

        if (prestigeContainer && prestigeStarsCount && prestigeBtn) {
            const total = gameState.totalEarned || 0;
            const possibleStars = Math.floor(Math.pow(total / 1000000, 0.5) * 10) || 0;
            const starsToGain = possibleStars - gameState.michelinStars;

            if (gameState.michelinStars > 0 || starsToGain > 0) {
                prestigeContainer.classList.remove('hidden');
                prestigeStarsCount.innerText = gameState.michelinStars;

                if (starsToGain > 0) {
                    prestigeBtn.style.display = 'block';
                    prestigeBtn.innerText = `Продать франшизу (+${starsToGain} ⭐)`;
                } else {
                    prestigeBtn.style.display = 'none';
                }
            } else {
                prestigeContainer.classList.add('hidden');
            }
        }

        this.renderRecipesList();
        this.renderStaffList();
        this.renderRestaurantsList();
        this.renderInventoryList();
    }
};