const AntiCheat = {
    config: {
        maxClicksPerSecond: 20,
        banDurationMs: 3000,
        maxOfflineHours: 8,
        timeTravelPenalty: 0.5
    },

    clickTimestamps: [],
    isBlocked: false,

    validateClick: function() {
        if (this.isBlocked) return false;
        const now = Date.now();
        this.clickTimestamps = this.clickTimestamps.filter(time => now - time < 1000);

        if (this.clickTimestamps.length >= this.config.maxClicksPerSecond) {
            this.triggerBlock();
            return false;
        }
        this.clickTimestamps.push(now);
        return true;
    },

    triggerBlock: function() {
        this.isBlocked = true;
        if (typeof createFloatingText === 'function') {
            createFloatingText({ clientX: window.innerWidth / 2, clientY: window.innerHeight / 2 }, `🚫 АВТОКЛИКЕР ЗАБЛОКИРОВАН!`, true);
        }
        setTimeout(() => {
            this.isBlocked = false;
            this.clickTimestamps = [];
        }, this.config.banDurationMs);
    },

    validateTime: function(gameState) {
        const now = Date.now();
        if (now < gameState.lastSaveTime) {
            if (!gameState.timeTravelPenalty) gameState.timeTravelPenalty = 0;
            gameState.timeTravelPenalty += 1;
            gameState.lastSaveTime = now;
            return { valid: false, reason: 'time_backwards', secondsPassed: 0 };
        }
        const secondsPassed = Math.floor((now - gameState.lastSaveTime) / 1000);
        const maxSeconds = this.config.maxOfflineHours * 60 * 60;
        const validSeconds = Math.min(secondsPassed, maxSeconds);
        return { valid: true, secondsPassed: validSeconds, isCapped: secondsPassed > maxSeconds };
    },

    getTimePenaltyMultiplier: function(gameState) {
        if (gameState.timeTravelPenalty && gameState.timeTravelPenalty > 0) {
            return this.config.timeTravelPenalty;
        }
        return 1.0;
    }
};