const storage = {
    saveKey: 'culinary_empire_save_v8',

    save: function() {
        gameState.lastSaveTime = Date.now();
        localStorage.setItem(this.saveKey, JSON.stringify(gameState));
    },

    load: function() {
        const savedData = localStorage.getItem(this.saveKey);
        if (savedData) {
            try {
                const parsed = JSON.parse(savedData);
                gameState.balance = parsed.balance || 0.00;
                gameState.clickLevel = parsed.clickLevel || 1;
                gameState.clickPower = parsed.clickPower || 2.50;
                gameState.upgradeBonus = parsed.upgradeBonus || 1.60;
                gameState.upgradeCost = parsed.upgradeCost || 1000.00;
                gameState.pps = parsed.pps || 0.00;
                gameState.basePps = parsed.basePps || 0.00;
                gameState.globalMultiplier = parsed.globalMultiplier || 1.00;
                gameState.lastSaveTime = parsed.lastSaveTime || Date.now();

                if (parsed.staff) {
                    gameState.staff.forEach(item => {
                        const savedStaff = parsed.staff.find(s => s.id === item.id);
                        if (savedStaff) {
                            item.count = savedStaff.count || 0;
                            item.cost = savedStaff.cost || item.cost;
                        }
                    });
                }

                if (parsed.recipes) {
                    gameState.recipes.forEach(item => {
                        const savedRecipe = parsed.recipes.find(r => r.id === item.id);
                        if (savedRecipe) {
                            item.purchased = savedRecipe.purchased || false;
                        }
                    });
                }

                if (parsed.restaurants) {
                    gameState.restaurants.forEach(item => {
                        const savedRest = parsed.restaurants.find(r => r.id === item.id);
                        if (savedRest) {
                            item.purchased = savedRest.purchased || false;
                        }
                    });
                }

                // ВОССТАНОВЛЕНИЕ ИНВЕНТАРЯ
                if (parsed.inventory) {
                    gameState.inventory.forEach(item => {
                        const savedInv = parsed.inventory.find(i => i.id === item.id);
                        if (savedInv) {
                            item.purchased = savedInv.purchased || false;
                        }
                    });
                }
            } catch (e) {
                console.error("Ошибка загрузки данных кухни", e);
            }
        }
    }
};
