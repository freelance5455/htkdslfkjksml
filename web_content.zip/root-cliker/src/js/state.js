let gameState = {
    // Экономика
    balance: 0.00,
    totalEarned: 0.00, 
    michelinStars: 0, 
    clickLevel: 1,
    clickPower: 2.50,
    upgradeBonus: 1.60,
    upgradeCost: 1000.00,
    pps: 0.00,
    globalMultiplier: 1.00,
    lastSaveTime: Date.now(),
    totalClicks: 0, // <--- Счетчик кликов
    achievements: [], // <--- Массив для ID полученных достижений
    
    settings: {
        sound: true,
        soundVolume: 50,
        music: true,
        musicVolume: 30,
        vibration: true
    },    

    // Уровни
    level: 1,
    xp: 0,
    xpToNextLevel: 10,

    // Временный буст (Золотой бургер)
    activeBoost: { active: false, multiplier: 1, timeLeft: 0 },

    // ПЕРСОНАЛ
    staff: [
        { id: 'dishwasher', name: 'Посудомойщик', cost: 150,  income: 1,   count: 0, icon: '🧽' },
        { id: 'assistant',  name: 'Помощник повара', cost: 800,  income: 5,   count: 0, icon: '🔪' },
        { id: 'line_cook',  name: 'Повар горячего цеха', cost: 4500, income: 32,  count: 0, icon: '🍳' },
        { id: 'sous_chef',  name: 'Су-Шеф ресторана', cost: 22000, income: 180, count: 0, icon: '👨‍🍳' },
        { id: 'pastry_chef',name: 'Шеф-кондитер', cost: 120000, income: 950, count: 0, icon: '🧁' },
        { id: 'sushi_master',name: 'Мастер суши', cost: 650000, income: 5000, count: 0, icon: '🍣' },
        { id: 'sommelier',  name: 'Сомелье', cost: 3500000, income: 28000, count: 0, icon: '🍷' },
        { id: 'gordon',     name: 'Звездный Шеф (Гордон)', cost: 20000000, income: 150000, count: 0, icon: '🌟' }
    ],

    // РЕЦЕПТЫ
    recipes: [
        { id: 'spices', name: 'Секретные специи', cost: 250, bonus: 1.00, purchased: false, icon: '🌶️' },
        { id: 'sousvide', name: 'Техника Су-Вид', cost: 1500, bonus: 5.00, purchased: false, icon: '🧪' },
        { id: 'molecular', name: 'Молекулярная кухня', cost: 8000, bonus: 25.00, purchased: false, icon: '🧼' },
        { id: 'gold_dish', name: 'Золотое напыление 24k', cost: 50000, bonus: 150.00, purchased: false, icon: '✨' },
        { id: 'truffle_pizza', name: 'Пицца с трюфелем', cost: 300000, bonus: 900.00, purchased: false, icon: '🍕' },
        { id: 'wagyu', name: 'Стейк Вагю А5', cost: 1800000, bonus: 5500.00, purchased: false, icon: '🥩' },
        { id: 'caviar', name: 'Черная икра', cost: 10000000, bonus: 32000.00, purchased: false, icon: '🥂' },
        { id: 'ambrosia', name: 'Амброзия Богов', cost: 75000000, bonus: 250000.00, purchased: false, icon: '🏺' }
    ],
    
    // РЕСТОРАНЫ
    restaurants: [
        { id: 'burger_shop', name: 'Придорожная Бургерная', cost: 15000, multiplier: 1.5, purchased: false, icon: '🏪' },
        { id: 'cafe', name: 'Уютная Кофейня', cost: 85000, multiplier: 2.0, purchased: false, icon: '☕' },
        { id: 'sushi_bar', name: 'Суши-Бар в центре', cost: 400000, multiplier: 3.5, purchased: false, icon: '🍣' },
        { id: 'michelin_gourmet', name: 'Мишленовский Ресторан', cost: 2500000, multiplier: 5.0, purchased: false, icon: '🏛️' },
        { id: 'rooftop', name: 'Панорамный ресторан', cost: 15000000, multiplier: 7.0, purchased: false, icon: '🌆' },
        { id: 'underwater', name: 'Подводный ресторан', cost: 90000000, multiplier: 10.0, purchased: false, icon: '🐠' },
        { id: 'space_diner', name: 'Космическая закусочная', cost: 500000000, multiplier: 15.0, purchased: false, icon: '🚀' }
    ],
    
    // ИНВЕНТАРЬ
    inventory: [
        { id: 'paprika', name: 'Копченая паприка', cost: 450, percentageBonus: 0.03, purchased: false, icon: '🌶️' },
        { id: 'truffle_oil', name: 'Трюфельное масло', cost: 2800, percentageBonus: 0.07, purchased: false, icon: '🍾' },
        { id: 'saffron', name: 'Иранский шафран', cost: 14000, percentageBonus: 0.12, purchased: false, icon: '🌸' },
        { id: 'blue_algae', name: 'Экстракт водорослей', cost: 75000, percentageBonus: 0.20, purchased: false, icon: '🧪' },
        { id: 'aged_vinegar', name: 'Выдержанный бальзамик', cost: 450000, percentageBonus: 0.30, purchased: false, icon: '🍶' },
        { id: 'diamond_salt', name: 'Алмазная соль', cost: 3000000, percentageBonus: 0.50, purchased: false, icon: '💎' },
        { id: 'liquid_gold', name: 'Жидкое золото', cost: 25000000, percentageBonus: 0.75, purchased: false, icon: '🪙' }
    ],
    
    // БЛЮДА
    dishes: [
        { minLevel: 1, name: "Простой Бургер", icon: "🍔" },
        { minLevel: 3, name: "Хрустящий Картофель фри", icon: "🍟" },
        { minLevel: 6, name: "Ароматная Пицца Пепперони", icon: "🍕" },
        { minLevel: 10, name: "Сочный Рибай Стейк", icon: "🥩" },
        { minLevel: 15, name: "Сет Премиум Суши", icon: "🍣" },
        { minLevel: 22, name: "Изысканный Лобстер", icon: "🦞" },
        { minLevel: 30, name: "Шедевр от Шефа под колпаком", icon: "🍽️" },
        { minLevel: 45, name: "Фуа-Гра с трюфелем", icon: "🦆" },
        { minLevel: 60, name: "Стейк Вагю с золотом", icon: "🥩" },
        { minLevel: 80, name: "Космический деликатес", icon: "🪐" },
        { minLevel: 100, name: "Пища Богов", icon: "🏺" },
        { minLevel: 150, name: "Кулинарный Сингулярный Шедевр", icon: "🌌" }
    ]
};