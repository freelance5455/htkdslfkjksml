Escudos de clubes procesados a PNG con fondo transparente y lienzo cuadrado centrado.
Los logos conservan su forma original; la interfaz no los recorta en círculos.
Los logos de competiciones se mantienen en su formato original.
