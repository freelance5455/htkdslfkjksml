const params = new URLSearchParams(window.location.search);
const jeu = tousLesJeux().find(j => j.id === params.get("id"));

if (!jeu) {
  document.querySelector("main").innerHTML =
    "<p>Jeu introuvable. <a href='index.html'>Retour à la bibliothèque</a></p>";
} else {
  document.title = jeu.titre + " – The Completionist";
  const taux = completion(jeu);

  document.getElementById("fiche-titre").textContent = jeu.titre;
  document.getElementById("fiche-plateformes").textContent = jeu.plateformes.join(" · ");
  document.getElementById("fiche-barre").style.width = taux + "%";
  document.getElementById("fiche-taux").textContent = taux + " % de complétion";

  document.getElementById("fiche-jaquette").innerHTML = jeu.cover
    ? balisesImage(jeu.cover, jeu.titre)
    : `<div class="sans-cover">${jeu.titre}</div>`;
  resoudreImages(document.getElementById("fiche-jaquette"));

  const date = new Date(jeu.dateSortie).toLocaleDateString("fr-FR", {
    day: "numeric", month: "long", year: "numeric"
  });

  document.getElementById("infos").innerHTML = `
    <dl class="liste-infos">
      <dt>Titre</dt><dd>${jeu.titre}</dd>
      <dt>Date de sortie</dt><dd>${date}</dd>
      <dt>Développeur</dt><dd>${jeu.developpeur}</dd>
      <dt>Éditeur</dt><dd>${jeu.editeur}</dd>
      <dt>Genre</dt><dd>${jeu.genre}</dd>
      <dt>Plateformes</dt><dd>${jeu.plateformes.join(", ")}</dd>
    </dl>`;

  document.querySelectorAll(".onglet").forEach(bouton => {
    bouton.addEventListener("click", () => {
      document.querySelectorAll(".onglet").forEach(b => b.classList.remove("actif"));
      document.querySelectorAll(".panneau").forEach(p => p.classList.remove("actif"));
      bouton.classList.add("actif");
      document.getElementById(bouton.dataset.cible).classList.add("actif");
    });
  });
}

if (jeu) {
  const LIBELLES = { playstation: "Trophées", steam: "Succès", libre: "Objectifs" };
  const TYPES_PS = { platine: "Platine", or: "Or", argent: "Argent", bronze: "Bronze" };

  const onglet = document.querySelector('[data-cible="trophees"]');
  const panneau = document.getElementById("trophees");

  function majResume() {
    const t = completion(jeu);
    document.getElementById("fiche-barre").style.width = t + "%";
    document.getElementById("fiche-taux").textContent = t + " % de complétion";
  }

  function dessiner() {
    const obtenus = jeu.trophees.filter(t => estFait(jeu.id, "trophees", t.id)).length;
    const lignes = jeu.trophees.map(t => {
      const fait = estFait(jeu.id, "trophees", t.id);
      const pastille = jeu.typeTrophees === "playstation"
        ? `<span class="pastille ${t.type}">${TYPES_PS[t.type]}</span>` : "";
      return `
        <li class="trophee ${fait ? "obtenu" : ""}">
          <label>
            <input type="checkbox" data-id="${t.id}" ${fait ? "checked" : ""}>
            <span class="trophee-texte"><strong>${t.nom}</strong><small>${t.description}</small></span>
            ${pastille}
          </label>
        </li>`;
    }).join("");

    panneau.innerHTML = `<p class="compteur">${obtenus} / ${jeu.trophees.length} obtenus</p>
      <ul class="liste-trophees">${lignes}</ul>`;

    panneau.querySelectorAll("input").forEach(c => {
      c.addEventListener("change", () => {
        basculer(jeu.id, "trophees", c.dataset.id);
        dessiner();
        majResume();
      });
    });
  }

  if (Array.isArray(jeu.trophees)) {
    onglet.textContent = LIBELLES[jeu.typeTrophees] || "Trophées";
    dessiner();
  } else {
    onglet.style.display = "none";
    panneau.style.display = "none";
  }
}

if (jeu) {
  const ongletC = document.querySelector('[data-cible="collectibles"]');
  const panneauC = document.getElementById("collectibles");
  const estImage = texte => /\.(png|jpe?g|webp|svg|gif)$/i.test(texte);

  function majResumeC() {
    const t = completion(jeu);
    document.getElementById("fiche-barre").style.width = t + "%";
    document.getElementById("fiche-taux").textContent = t + " % de complétion";
  }

  function dessinerC() {
    const groupes = {};
    jeu.collectibles.forEach(c => {
      const nom = c.groupe || "Collectibles";
      (groupes[nom] = groupes[nom] || []).push(c);
    });

    const total = jeu.collectibles.length;
    const ramasses = jeu.collectibles.filter(c => estFait(jeu.id, "collectibles", c.id)).length;
    let html = `<p class="compteur">${ramasses} / ${total} ramassés</p>`;

    for (const nomGroupe in groupes) {
      const liste = groupes[nomGroupe];
      const n = liste.filter(c => estFait(jeu.id, "collectibles", c.id)).length;
      html += `<h3 class="groupe-titre">${nomGroupe} <span>${n} / ${liste.length}</span></h3>
        <div class="grille-collectibles">`;
      html += liste.map(c => {
        const fait = estFait(jeu.id, "collectibles", c.id);
          const visuel = (estIdImage(c.icone) || estImage(c.icone))
          ? balisesImage(c.icone, "")
          : `<span class="emoji">${c.icone}</span>`;
        return `<button type="button" class="collectible ${fait ? "obtenu" : ""}"
                  data-id="${c.id}" title="${c.nom}" aria-pressed="${fait}">${visuel}</button>`;
      }).join("");
      html += `</div>`;
    }

    panneauC.innerHTML = html;
      resoudreImages(panneauC);

    panneauC.querySelectorAll(".collectible").forEach(bouton => {
      bouton.addEventListener("click", () => {
        basculer(jeu.id, "collectibles", bouton.dataset.id);
        dessinerC();
        majResumeC();
      });
    });
  }

  if (Array.isArray(jeu.collectibles)) {
    dessinerC();
  } else {
    ongletC.style.display = "none";
    panneauC.style.display = "none";
  }
}

if (jeu) {
  const zone = document.createElement("div");
  zone.className = "actions-fiche";

  const modifier = document.createElement("a");
  modifier.className = "bouton-secondaire";
  modifier.href = "ajout.html?id=" + encodeURIComponent(jeu.id);
  modifier.textContent = "Modifier ce jeu";

  const supprimer = document.createElement("button");
  supprimer.type = "button";
  supprimer.className = "bouton-danger";
  supprimer.textContent = "Supprimer ce jeu";
  supprimer.addEventListener("click", () => {
    if (confirm("Supprimer « " + jeu.titre + " » et sa progression ?")) {
      supprimerJeuPerso(jeu.id);
      window.location.href = "index.html";
    }
  });

  zone.appendChild(modifier);
  zone.appendChild(supprimer);
  document.querySelector("main.fiche").appendChild(zone);
}