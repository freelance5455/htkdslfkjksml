const createprj = document.getElementById('createprj');
const createp = document.getElementById('createp');
const create = document.getElementById('create');
const hisB = document.getElementById('hisB');
const his = document.getElementById('his');
const cnt = document.getElementById('cnt');
const uploadedTab = document.getElementById('uploadedTab');
const downloadsTab = document.getElementById('downloadsTab');
const imageInput = document.getElementById('cpimage');
const videoInput = document.getElementById('cpvideo');

const DB_NAME = 'BetterClipsHistory';
const DB_VERSION = 1;
const STORE = 'media';

let historyMode = 'uploaded';
let selectedUpload = null;
let objectUrls = [];
let firebaseReady = null;
let cloudProjects = [];

// Firebase is loaded dynamically so this file can stay a normal script in Xcodx.
const firebaseConfig = {
  apiKey: 'AIzaSyDHjqIRyA7VoWoH1Wdr7XUbRmAxhnUufjk',
  authDomain: 'clips-61b6a.firebaseapp.com',
  databaseURL: 'https://clips-61b6a-default-rtdb.firebaseio.com',
  projectId: 'clips-61b6a',
  storageBucket: 'clips-61b6a.appspot.com',
  messagingSenderId: '408398676797',
  appId: '1:408398676797:web:ecc603268691d236ca3b54'
};

async function loadFirebase() {
  if (firebaseReady) return firebaseReady;

  firebaseReady = (async () => {
    const [{ initializeApp }, { getAuth, onAuthStateChanged }, { getDatabase, ref, push, set, onValue }, { getStorage, ref: storageRef, uploadBytes, getDownloadURL }] = await Promise.all([
      import('https://www.gstatic.com/firebasejs/12.18.0/firebase-app.js'),
      import('https://www.gstatic.com/firebasejs/12.18.0/firebase-auth.js'),
      import('https://www.gstatic.com/firebasejs/12.18.0/firebase-database.js'),
      import('https://www.gstatic.com/firebasejs/12.18.0/firebase-storage.js')
    ]);

    const app = initializeApp(firebaseConfig);
    const auth = getAuth(app);
    const database = getDatabase(app);
    const storage = getStorage(app);

    return { auth, database, storage, ref, push, set, onValue, storageRef, uploadBytes, getDownloadURL, onAuthStateChanged };
  })();

  return firebaseReady;
}

function openDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE)) {
        db.createObjectStore(STORE, { keyPath: 'id', autoIncrement: true });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function addHistoryItem(item) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).add(item);
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error);
  });
}

async function getHistory(type) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readonly');
    const request = tx.objectStore(STORE).getAll();
    request.onsuccess = () => {
      const items = request.result.filter(item => item.type === type);
      items.sort((a, b) => b.createdAt - a.createdAt);
      resolve(items);
    };
    request.onerror = () => reject(request.error);
  });
}

async function deleteHistoryItem(id) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).delete(id);
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error);
  });
}

function formatDate(timestamp) {
  return new Date(timestamp).toLocaleString([], {
    month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit'
  });
}

function makeDownload(blobOrUrl, name) {
  const url = typeof blobOrUrl === 'string' ? blobOrUrl : URL.createObjectURL(blobOrUrl);
  const a = document.createElement('a');
  a.href = url;
  a.download = name || 'better-clips-download';
  a.target = '_blank';
  document.body.appendChild(a);
  a.click();
  a.remove();
  if (typeof blobOrUrl !== 'string') setTimeout(() => URL.revokeObjectURL(url), 1000);
}

async function downloadHistoryItem(item) {
  makeDownload(item.blob, item.name);

  await addHistoryItem({
    type: 'download',
    name: item.name,
    mime: item.mime,
    blob: item.blob,
    createdAt: Date.now()
  });

  if (historyMode === 'download') renderHistory();
}

async function downloadCloudProject(project) {
  if (!project.mediaUrl) return;
  makeDownload(project.mediaUrl, project.fileName || `${project.title || 'better-clips-project'}`);

  try {
    const response = await fetch(project.mediaUrl);
    const blob = await response.blob();
    await addHistoryItem({
      type: 'download',
      name: project.fileName || project.title || 'project',
      mime: project.mime || blob.type || 'application/octet-stream',
      blob,
      createdAt: Date.now()
    });
    if (historyMode === 'download') renderHistory();
  } catch (error) {
    console.warn('Could not save cloud download to local history', error);
  }
}

async function renderHistory() {
  cnt.innerHTML = '';
  objectUrls.forEach(url => URL.revokeObjectURL(url));
  objectUrls = [];

  const items = await getHistory(historyMode);

  if (!items.length) {
    cnt.innerHTML = '<div class="empty-history">Nothing here yet</div>';
    return;
  }

  items.forEach(item => {
    const row = document.createElement('div');
    row.className = 'history-item';

    const left = document.createElement('div');
    left.className = 'history-info';

    const preview = document.createElement('div');
    preview.className = 'history-preview';

    const url = URL.createObjectURL(item.blob);
    objectUrls.push(url);

    if (item.mime && item.mime.startsWith('video/')) {
      const video = document.createElement('video');
      video.src = url;
      video.muted = true;
      video.playsInline = true;
      video.preload = 'metadata';
      preview.appendChild(video);
    } else {
      const img = document.createElement('img');
      img.src = url;
      preview.appendChild(img);
    }

    const text = document.createElement('div');
    text.innerHTML = `<p>${escapeHtml(item.name)}</p><small>${formatDate(item.createdAt)}</small>`;
    left.append(preview, text);

    const actions = document.createElement('div');
    actions.className = 'history-actions';

    if (historyMode === 'uploaded') {
      const dl = document.createElement('button');
      dl.innerHTML = '<span class="material-symbols-outlined">download</span>';
      dl.title = 'Download';
      dl.onclick = () => downloadHistoryItem(item);
      actions.appendChild(dl);
    }

    const del = document.createElement('button');
    del.innerHTML = '<span class="material-symbols-outlined">delete</span>';
    del.title = 'Delete';
    del.onclick = async () => {
      await deleteHistoryItem(item.id);
      renderHistory();
    };

    actions.appendChild(del);
    row.append(left, actions);
    cnt.appendChild(row);
  });
}

function escapeHtml(value) {
  return String(value).replace(/[&<>'"]/g, char => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;'
  }[char]));
}

async function handleUpload(file) {
  if (!file) return;

  selectedUpload = file;

  await addHistoryItem({
    type: 'uploaded',
    name: file.name,
    mime: file.type || 'application/octet-stream',
    blob: file,
    createdAt: Date.now()
  });

  if (file.type.startsWith('image/')) {
    imageInput.closest('button').classList.add('selected-upload');
  } else if (file.type.startsWith('video/')) {
    videoInput.closest('button').classList.add('selected-upload');
  }

  if (his.style.display === 'block' && historyMode === 'uploaded') renderHistory();
}

function setupReactionButtons(project) {
  const like = project.querySelector('.like-btn');
  const dislike = project.querySelector('.dislike-btn');
  if (!like || !dislike) return;

  like.onclick = (e) => {
    e.preventDefault();
    e.stopPropagation();
    const active = like.classList.toggle('active');
    dislike.classList.remove('active');
    like.setAttribute('aria-pressed', active ? 'true' : 'false');
    dislike.setAttribute('aria-pressed', 'false');
  };

  dislike.onclick = (e) => {
    e.preventDefault();
    e.stopPropagation();
    const active = dislike.classList.toggle('active');
    like.classList.remove('active');
    dislike.setAttribute('aria-pressed', active ? 'true' : 'false');
    like.setAttribute('aria-pressed', 'false');
  };
}

function createProjectElement(projectData) {
  const project = document.createElement('div');
  project.className = 'prj';
  project.dataset.cloudId = projectData.id || '';
  project.dataset.type = projectData.type || 'none fiction';
  project.innerHTML = `
    <div class="tb">
      <span class="project-type"></span>
      <p class="title"></p>
    </div>
    <div class="project-media"></div>
    <div class="bb">
      <button class="like-btn" aria-label="Like" aria-pressed="false"><span class="material-symbols-outlined">thumb_up</span></button>
      <button class="dislike-btn" aria-label="Dislike" aria-pressed="false"><span class="material-symbols-outlined">thumb_down</span></button>
      <button class="project-download" aria-label="Download"><span class="material-symbols-outlined">download</span></button>
    </div>
  `;

  project.querySelector('.title').textContent = projectData.title || 'untitled project';
  project.querySelector('.project-type').textContent = projectData.type || 'none fiction';

  const media = project.querySelector('.project-media');
  if (projectData.mediaType === 'video' && projectData.mediaUrl) {
    const video = document.createElement('video');
    video.src = projectData.mediaUrl;
    video.muted = true;
    video.playsInline = true;
    video.preload = 'metadata';
    video.setAttribute('aria-label', projectData.title || 'project video');
    media.appendChild(video);
  } else {
    const img = document.createElement('img');
    img.src = projectData.mediaUrl || 'image.jpeg';
    img.alt = projectData.title || 'project image';
    media.appendChild(img);
  }

  setupReactionButtons(project);

  project.querySelector('.project-download').onclick = (e) => {
    e.preventDefault();
    e.stopPropagation();
    downloadCloudProject(projectData);
  };

  return project;
}

function renderCloudProjects() {
  const container = document.querySelector('.container');
  if (!container) return;

  container.querySelectorAll('.cloud-project').forEach(el => el.remove());

  cloudProjects.forEach(data => {
    const project = createProjectElement(data);
    project.classList.add('cloud-project');
    container.appendChild(project);
  });

  searchfor(search.value);
}

async function startCloudProjects() {
  try {
    const fb = await loadFirebase();
    fb.onAuthStateChanged(fb.auth, (user) => {
      if (!user) {
        window.location.href = 'index.html';
        return;
      }

      const projectsRef = fb.ref(fb.database, 'projects');
      fb.onValue(projectsRef, (snapshot) => {
        const value = snapshot.val() || {};
        cloudProjects = Object.entries(value).map(([id, data]) => ({ id, ...data }))
          .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
        renderCloudProjects();
      });
    });
  } catch (error) {
    console.error('Firebase project feed failed', error);
  }
}

const originalProject = document.querySelector('.container .prj');
if (originalProject) setupReactionButtons(originalProject);

createprj.onclick = (e) => {
  e.preventDefault();
  e.stopPropagation();
  createp.style.display = 'block';
};

create.onclick = async (e) => {
  e.preventDefault();

  const name = document.getElementById('prjname').value.trim();
  const type = document.getElementById('prjtype').value;

  if (!name) return;

  create.disabled = true;
  create.textContent = 'creating...';

  try {
    const fb = await loadFirebase();
    const user = fb.auth.currentUser;
    if (!user) throw new Error('You must be logged in');

    const projectRef = fb.push(fb.ref(fb.database, 'projects'));
    const projectId = projectRef.key;

    let mediaUrl = 'image.jpeg';
    let mediaType = 'image';
    let mime = 'image/jpeg';
    let fileName = `${name}.jpg`;

    if (selectedUpload) {
      mediaType = selectedUpload.type.startsWith('video/') ? 'video' : 'image';
      mime = selectedUpload.type || 'application/octet-stream';
      fileName = selectedUpload.name;

      const fileRef = fb.storageRef(fb.storage, `projects/${projectId}/${Date.now()}_${selectedUpload.name}`);
      await fb.uploadBytes(fileRef, selectedUpload, { contentType: selectedUpload.type });
      mediaUrl = await fb.getDownloadURL(fileRef);
    }

    await fb.set(projectRef, {
      title: name,
      type,
      mediaUrl,
      mediaType,
      mime,
      fileName,
      creatorId: user.uid,
      createdAt: Date.now()
    });

    createp.style.display = 'none';
    document.getElementById('prjname').value = '';
    imageInput.value = '';
    videoInput.value = '';
    selectedUpload = null;
    document.querySelectorAll('.selected-upload').forEach(button => button.classList.remove('selected-upload'));
  } catch (error) {
    console.error('Project creation failed', error);
    alert('Could not create the project. Check your Firebase Database and Storage rules.');
  } finally {
    create.disabled = false;
    create.textContent = 'create';
  }
};

imageInput.addEventListener('change', () => handleUpload(imageInput.files[0]));
videoInput.addEventListener('change', () => handleUpload(videoInput.files[0]));

hisB.onclick = (e) => {
  e.preventDefault();
  e.stopPropagation();
  his.style.display = 'block';
  historyMode = 'uploaded';
  updateHistoryTabs();
  renderHistory();
};

document.addEventListener('click', (e) => {
  if (his.style.display === 'block' && !his.contains(e.target) && e.target !== hisB && !hisB.contains(e.target)) {
    his.style.display = 'none';
  }

  if (createp.style.display === 'block' && !createp.contains(e.target) && e.target !== createprj && !createprj.contains(e.target)) {
    createp.style.display = 'none';
  }
});

uploadedTab.onclick = (e) => {
  e.preventDefault();
  historyMode = 'uploaded';
  updateHistoryTabs();
  renderHistory();
};

downloadsTab.onclick = (e) => {
  e.preventDefault();
  historyMode = 'download';
  updateHistoryTabs();
  renderHistory();
};

function updateHistoryTabs() {
  uploadedTab.classList.toggle('active', historyMode === 'uploaded');
  downloadsTab.classList.toggle('active', historyMode === 'download');
}

const search = document.getElementById('search');
search.addEventListener('keydown', function (e) {
  if (e.key === 'Enter') searchfor(search.value);
});

search.addEventListener('input', function () {
  searchfor(search.value);
});

function searchfor(s) {
  const projects = document.querySelectorAll('.container .prj');
  const words = s.toLowerCase().split(' ').filter(Boolean);

  projects.forEach(prj => {
    const title = prj.querySelector('.title');
    const type = prj.querySelector('.project-type');
    const text = `${title ? title.textContent : ''} ${type ? type.textContent : ''}`.toLowerCase();
    const hasWord = !words.length || words.some(word => text.includes(word));
    prj.style.display = hasWord ? '' : 'none';
  });
}

startCloudProjects();
