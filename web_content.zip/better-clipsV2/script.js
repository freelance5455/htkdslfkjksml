import { initializeApp } from "https://www.gstatic.com/firebasejs/12.18.0/firebase-app.js";
import { getAnalytics } from "https://www.gstatic.com/firebasejs/12.18.0/firebase-analytics.js";
import { getAuth, createUserWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/12.18.0/firebase-auth.js";
import { signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/12.18.0/firebase-auth.js";
import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/12.18.0/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyDHjqIRyA7VoWoH1Wdr7XUbRmAxhnUufjk",
  authDomain: "clips-61b6a.firebaseapp.com",
  databaseURL: "https://clips-61b6a-default-rtdb.firebaseio.com",
  projectId: "clips-61b6a",
  storageBucket: "clips-61b6a.appspot.com",
  messagingSenderId: "408398676797",
  appId: "1:408398676797:web:ecc603268691d236ca3b54",
  measurementId: "G-GBWWMMFP4D"
};

const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
const auth = getAuth(app);

document.addEventListener('DOMContentLoaded', function () {
  onAuthStateChanged(auth, (user) => {
    if (user) {
      window.location.href = "main.html";
    }
  });

  
  const password = document.getElementById('password');
  const email = document.getElementById('email');
  

  submit.onclick = (e) => {
    e.preventDefault(); 
    createUserWithEmailAndPassword(auth, email.value, password.value)
      .then((userCredential) => {
        window.location.href = "main.html";
        const user = userCredential.user;
      })
      .catch((error) => {
        if (error.code === 'auth/email-already-in-use') {
          signInWithEmailAndPassword(auth, email.value, password.value)
  .then((userCredential) => {
    const user = userCredential.user;
    window.location.href = 'main.html';
  })
  .catch((error) => {
    const errorCode = error.code;
    const errorMessage = error.message;
  });

        }
      });
  }; 
});



