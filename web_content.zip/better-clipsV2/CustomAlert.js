const text2 = document.getElementById('text2');


function Alert1(message) {
    document.getElementById('alert-message').innerText = message;
    document.getElementById('custom-alert-overlay').style.display = 'block';
}

function closeAlert() {
    document.getElementById('custom-alert-overlay').style.display = 'none';
}