# Untitled Project

Exported from XCODX — Online IDE & Code Playground.
https://xcodx.io/editor

Open index.html in any browser.

CLOUD PROJECTS
==============
Projects created in the app are stored in Firebase Realtime Database and their selected image/video is stored in Firebase Storage so signed-in users can see and download projects from other accounts.

For the shared project feed to work, Firebase Realtime Database rules need authenticated read/write access:

{
  "rules": {
    "projects": {
      ".read": "auth != null",
      ".write": "auth != null"
    }
  }
}

Firebase Storage rules need authenticated read/write access for the project media:

rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /projects/{projectId}/{fileName} {
      allow read, write: if request.auth != null;
    }
  }
}

Do not make the whole database or storage bucket public. These rules let signed-in users share projects while keeping access behind Firebase Authentication.

## APK wrapper note
The web app uses normal HTML file inputs for image and video selection. Android WebView apps must implement a native file chooser (`WebChromeClient.onShowFileChooser`) for `<input type="file">` to open the device picker. If an APK builder has file uploads disabled or does not implement that WebView callback, the page can work in Chrome but the picker will do nothing inside the APK. Enable the builder's file upload/file picker feature if it has one.
