FIT POINT — CUSTOMER + SEPARATE ADMIN HTML

Files:
- customer/index.html : customer shopping frontend with mobile-number sign-in and OTP screen flow
- admin/index.html    : separate admin portal for product and order management

OPEN:
1. Extract this ZIP.
2. Open customer/index.html in Chrome for the customer shopping experience.
3. Open admin/index.html separately for store administration.
4. Demo admin login: username admin / password FitPoint@123
5. Demo OTP: 123456 (displayed after entering a 10-digit phone number)

IMPORTANT LIMITATIONS:
- Demo OTP is NOT sent by SMS. Real OTP requires a secure backend and an SMS/authentication provider (for example Firebase Authentication or MSG91).
- Both pages share demo data using browser localStorage only if opened in the same browser profile/device. This is NOT a real multi-user store backend.
- Admin password is present in frontend source and is NOT secure. Do not deploy publicly with demo credentials.
- Real orders, cross-device sync, email alerts, secure admin authentication and payments require a backend/database and provider configuration.

PRODUCTION CONNECTION PLAN:
Host customer and admin frontends separately (e.g. shop.example.com and admin.example.com) and connect both to one API/database. Protect admin endpoints with server-side roles; verify OTP on the server; create orders server-side; send email from backend; use a payment provider for actual transactions.
