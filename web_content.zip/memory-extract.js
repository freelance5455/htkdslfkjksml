const YukiExtractTime = typeof window !== 'undefined' ? window.MemoryTime : require('./memory-time.js');

function detectPlan(text, now = new Date()) {
  const s = String(text).toLowerCase().trim();

  const intention =
    /\b(планирую|собираюсь|хочу|намерен)\b/u.test(s) ||
    /(?:^|[\s,.!?])(планирую|собираюсь|хочу|намерен)(?=$|[\s,.!?])/u.test(s);

  if (!intention) return null;

  if (/не\s+(?:планирую|собираюсь|хочу)/u.test(s)) {
    return null;
  }

  const time = YukiExtractTime.detect(s, now);

  if (!time || time.offsetDays < 0) {
    return null;
  }

  return {
    type: 'plan',
    text: String(text).trim(),
    dueDate: time.date,
    status: 'pending'
  };
}


function shouldAnalyzePlan(text) {
  const s = String(text).toLowerCase().trim();

  if (s.length < 12 || s.length > 2000) return false;

  const timeHint =
    /завтра|послезавтра|сегодня|выходн|суббот|воскресен|понедельник|вторник|сред|четверг|пятниц|через неделю|на следующей неделе|\d{1,2}[.\/-]\d{1,2}/u.test(s);

  const intention =
    /собираюсь|планирую|думаю|намерен|хочу|буду|решил|решила|договорил|записал|записала|предстоит|надо|нужно/u.test(s);

  return timeHint && intention;
}

function detectPlanUpdate(text) {
  const s = String(text).toLowerCase().trim();

  const cancelled =
    /(?:передумал|передумала|отменяю|отменил|отменила|не буду|отказывается|отказываюсь)/u.test(s);

  const completed =
    /(?:уже сделал|уже сделала|уже купил|уже купила|уже посмотрел|уже посмотрела|выполнил|выполнила)/u.test(s);

  if (cancelled && completed) return null;

  if (cancelled) return { action: 'cancelled', text: s };
  if (completed) return { action: 'completed', text: s };

  return null;
}


if (typeof window !== 'undefined') {
  window.MemoryExtract = {
    detectPlan,
    detectPlanUpdate,
    shouldAnalyzePlan
  };
}

if (typeof module !== 'undefined') {
  module.exports = {
    detectPlan,
    detectPlanUpdate,
    shouldAnalyzePlan
  };
}
