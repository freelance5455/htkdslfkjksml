NOVA CHAMPIONS — iPhone (iOS) PWA preparation

This package prepares the existing NOVA CHAMPIONS website for adding to an iPhone Home Screen. It is not a native iOS IPA and is not an App Store build.

IMPORTANT
- The app files must be published at a public HTTPS address. Opening index.html directly from the phone's Files app or Acode is not enough for iPhone Home Screen installation.
- This package does not use Netlify. Choose another static HTTPS hosting provider and upload the CONTENTS of this ZIP (index.html, manifest.webmanifest, sw.js, assets folder) so index.html is at the site root.
- Keep the same Firebase project/configuration and do not delete or reset Firestore data or rules.
- The app uses Firebase for shared data, so internet access is needed for live teams, matches, articles, and predictions.

INSTALL ON IPHONE AFTER HOSTING
1) Open the published HTTPS link in Safari on the iPhone.
2) Tap Share.
3) Choose Add to Home Screen.
4) Keep the name NOVA CHAMPIONS and tap Add.
5) Launch NOVA from its new Home Screen icon.

NOTE
The iPhone installation is a Home Screen web app (PWA), not an App Store application.
