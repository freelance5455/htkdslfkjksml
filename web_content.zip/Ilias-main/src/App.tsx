/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { ScreenState, Language, PlayerData, StageConfig, CombatOutcome } from './types/game';
import { STAGES, WEAPONS } from './utils/gameData';
import { loadSecurePlayerData, saveSecurePlayerData } from './utils/antiCheat';
import { ScreenLanguage } from './components/ScreenLanguage';
import { ScreenAuth } from './components/ScreenAuth';
import { ScreenMainMenu } from './components/ScreenMainMenu';
import { CombatArena } from './components/CombatArena';
import { CombatResultModal } from './components/CombatResultModal';
import { RewardedAdModal } from './components/RewardedAdModal';
import { InterstitialAdModal } from './components/InterstitialAdModal';
import { AntiCheatModal } from './components/AntiCheatModal';
import { SettingsModal } from './components/SettingsModal';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<ScreenState>('LANGUAGE_SELECT');
  const [lang, setLang] = useState<Language>('en');
  const [playerData, setPlayerData] = useState<PlayerData>(() => {
    const { data } = loadSecurePlayerData();
    return data;
  });

  // Active Stage in Combat
  const [activeStage, setActiveStage] = useState<StageConfig>(STAGES[0]);
  const [combatResult, setCombatResult] = useState<{
    outcome: CombatOutcome;
    earnedCoins: number;
    earnedXp: number;
    maxCombo: number;
    hasDoubledCoins: boolean;
  } | null>(null);

  // Active Modals
  const [showRewardedAd, setShowRewardedAd] = useState<{
    active: boolean;
    type: 'REVIVE' | 'DOUBLE_COINS';
  }>({ active: false, type: 'REVIVE' });

  const [showInterstitialAd, setShowInterstitialAd] = useState<{
    active: boolean;
    nextStageId?: number;
  }>({ active: false });

  const [showAntiCheatModal, setShowAntiCheatModal] = useState(false);
  const [showSettingsModal, setShowSettingsModal] = useState(false);

  // Update HTML Direction for Arabic (RTL) vs English/Spanish (LTR)
  useEffect(() => {
    if (lang === 'ar') {
      document.documentElement.dir = 'rtl';
      document.documentElement.lang = 'ar';
    } else {
      document.documentElement.dir = 'ltr';
      document.documentElement.lang = lang;
    }
  }, [lang]);

  // Handle Stage Selection from Menu
  const handleSelectStage = (stage: StageConfig) => {
    setActiveStage(stage);
    setCombatResult(null);
    setCurrentScreen('COMBAT');
  };

  // Handle Combat End from Arena
  const handleCombatEnd = (
    outcome: CombatOutcome,
    earnedCoins: number,
    earnedXp: number,
    maxCombo: number
  ) => {
    // If victory, update stage progression and coins
    if (outcome === 'VICTORY') {
      const nextStage = Math.min(10, Math.max(playerData.currentStage, activeStage.id + 1));
      const newLevel = Math.floor((playerData.xp + earnedXp) / 400) + 1;
      const updated: PlayerData = {
        ...playerData,
        coins: playerData.coins + earnedCoins,
        xp: playerData.xp + earnedXp,
        level: newLevel,
        currentStage: nextStage,
        battlesWon: playerData.battlesWon + 1,
        highCombo: Math.max(playerData.highCombo, maxCombo)
      };
      const secure = saveSecurePlayerData(updated);
      setPlayerData(secure);
    }

    setCombatResult({
      outcome,
      earnedCoins,
      earnedXp,
      maxCombo,
      hasDoubledCoins: false
    });
  };

  // Rewarded Ad Revive Handler
  const handleClaimRevive = () => {
    setShowRewardedAd({ active: false, type: 'REVIVE' });
    setCombatResult(null);
    // Restart active combat with revived bonus
    setCurrentScreen('COMBAT');
  };

  // Rewarded Ad 2x Coins Handler
  const handleClaimDoubleCoins = () => {
    if (combatResult && !combatResult.hasDoubledCoins) {
      const bonusCoins = combatResult.earnedCoins;
      const updated: PlayerData = {
        ...playerData,
        coins: playerData.coins + bonusCoins
      };
      setPlayerData(saveSecurePlayerData(updated));
      setCombatResult({
        ...combatResult,
        hasDoubledCoins: true
      });
    }
    setShowRewardedAd({ active: false, type: 'DOUBLE_COINS' });
  };

  // Next Stage Transition (Triggers Interstitial Ad between completed stages as specified!)
  const handleProceedToNextStage = () => {
    const nextStageId = activeStage.id + 1;
    if (nextStageId <= 10) {
      // Trigger Interstitial Ad during stage transition
      setShowInterstitialAd({ active: true, nextStageId });
    } else {
      // Game cleared! Return to menu
      setCurrentScreen('MAIN_MENU');
      setCombatResult(null);
    }
  };

  // On Interstitial Ad Closed
  const handleInterstitialClosed = () => {
    const targetStageId = showInterstitialAd.nextStageId || activeStage.id + 1;
    setShowInterstitialAd({ active: false });
    const targetStage = STAGES.find((s) => s.id === targetStageId) || STAGES[0];
    setActiveStage(targetStage);
    setCombatResult(null);
    setCurrentScreen('COMBAT');
  };

  return (
    <div className="w-full min-h-screen bg-[#05070d] text-slate-100 font-sans select-none overflow-x-hidden">
      {/* SCREEN 1: Language Selection */}
      {currentScreen === 'LANGUAGE_SELECT' && (
        <ScreenLanguage
          currentLang={lang}
          onSelectLang={setLang}
          onContinue={() => setCurrentScreen('AUTH_SELECT')}
        />
      )}

      {/* SCREEN 2: Authentication (Google Cloud Save & Guest Mode) */}
      {currentScreen === 'AUTH_SELECT' && (
        <ScreenAuth
          lang={lang}
          onAuthComplete={(newData) => {
            setPlayerData(newData);
            setCurrentScreen('MAIN_MENU');
          }}
          onBack={() => setCurrentScreen('LANGUAGE_SELECT')}
        />
      )}

      {/* SCREEN 3: Main Menu & Stage Selection (With Menu Banner Ad) */}
      {currentScreen === 'MAIN_MENU' && (
        <ScreenMainMenu
          playerData={playerData}
          lang={lang}
          onSelectStage={handleSelectStage}
          onOpenAntiCheat={() => setShowAntiCheatModal(true)}
          onOpenSettings={() => setShowSettingsModal(true)}
          onUpdatePlayerData={setPlayerData}
        />
      )}

      {/* SCREEN 4: Active 2D Combat Arena */}
      {currentScreen === 'COMBAT' && (
        <div className="fixed inset-0 z-10 flex flex-col items-center justify-center bg-black">
          <CombatArena
            stage={activeStage}
            playerData={playerData}
            lang={lang}
            onCombatEnd={handleCombatEnd}
            onExit={() => {
              setCurrentScreen('MAIN_MENU');
              setCombatResult(null);
            }}
          />

          {/* Combat Outcome Modal (Victory / Defeat with Rewarded Ad options) */}
          {combatResult && (
            <CombatResultModal
              outcome={combatResult.outcome}
              stage={activeStage}
              earnedCoins={combatResult.earnedCoins}
              earnedXp={combatResult.earnedXp}
              maxCombo={combatResult.maxCombo}
              lang={lang}
              onWatchAdToRevive={() =>
                setShowRewardedAd({ active: true, type: 'REVIVE' })
              }
              onWatchAdToDoubleCoins={() =>
                setShowRewardedAd({ active: true, type: 'DOUBLE_COINS' })
              }
              hasDoubledCoins={combatResult.hasDoubledCoins}
              onNextStage={handleProceedToNextStage}
              onRetry={() => {
                setCombatResult(null);
              }}
              onExitToMenu={() => {
                setCurrentScreen('MAIN_MENU');
                setCombatResult(null);
              }}
            />
          )}
        </div>
      )}

      {/* REWARDED AD MODAL (30s Video Ad for Revive or 2x Coins) */}
      {showRewardedAd.active && (
        <RewardedAdModal
          lang={lang}
          rewardType={showRewardedAd.type}
          onRewardGranted={
            showRewardedAd.type === 'REVIVE' ? handleClaimRevive : handleClaimDoubleCoins
          }
          onClose={() => setShowRewardedAd({ active: false, type: 'REVIVE' })}
        />
      )}

      {/* INTERSTITIAL AD MODAL (Full-screen ad triggered between completed stages) */}
      {showInterstitialAd.active && (
        <InterstitialAdModal
          lang={lang}
          onAdClosed={handleInterstitialClosed}
        />
      )}

      {/* ANTI-CHEAT & SECURITY INSPECTOR MODAL */}
      {showAntiCheatModal && (
        <AntiCheatModal
          playerData={playerData}
          lang={lang}
          onDataUpdated={setPlayerData}
          onClose={() => setShowAntiCheatModal(false)}
        />
      )}

      {/* SETTINGS MODAL */}
      {showSettingsModal && (
        <SettingsModal
          lang={lang}
          playerData={playerData}
          onLanguageChange={setLang}
          onDataUpdated={setPlayerData}
          onOpenAntiCheat={() => {
            setShowSettingsModal(false);
            setShowAntiCheatModal(true);
          }}
          onClose={() => setShowSettingsModal(false)}
        />
      )}
    </div>
  );
}
