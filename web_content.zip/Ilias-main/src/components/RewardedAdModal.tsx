/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Play, Volume2, VolumeX, CheckCircle, FastForward, Award, ShieldAlert } from 'lucide-react';
import { Language } from '../types/game';
import { getTranslation } from '../utils/i18n';

interface RewardedAdModalProps {
  lang: Language;
  rewardType: 'REVIVE' | 'DOUBLE_COINS';
  onRewardGranted: () => void;
  onClose: () => void;
}

export const RewardedAdModal: React.FC<RewardedAdModalProps> = ({
  lang,
  rewardType,
  onRewardGranted,
  onClose
}) => {
  const [timeLeft, setTimeLeft] = useState(30);
  const [isMuted, setIsMuted] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);
  const totalDuration = 30;

  useEffect(() => {
    if (timeLeft <= 0) {
      setIsCompleted(true);
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setIsCompleted(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft]);

  const handleClaimReward = () => {
    onRewardGranted();
  };

  const handleFastForward = () => {
    setTimeLeft(0);
    setIsCompleted(true);
  };

  const progressPercent = Math.min(100, Math.round(((totalDuration - timeLeft) / totalDuration) * 100));

  return (
    <div className="fixed inset-0 z-50 bg-black/95 flex flex-col items-center justify-center p-3 sm:p-6 backdrop-blur-md">
      {/* Ad Container */}
      <div className="w-full max-w-xl bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl flex flex-col relative">
        {/* Ad Top Header */}
        <div className="bg-slate-900/90 px-4 py-2.5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold uppercase bg-amber-500/20 text-amber-300 px-1.5 py-0.5 rounded border border-amber-500/30">
              REWARDED AD
            </span>
            <span className="text-xs text-slate-300 font-medium">
              {getTranslation(lang, 'adSponsor')}: Titan Wars
            </span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsMuted(!isMuted)}
              className="text-slate-400 hover:text-slate-200 transition-colors p-1"
            >
              {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>
            <div className="text-xs font-mono font-bold text-cyan-400 tabular-nums">
              {timeLeft > 0 ? `Reward in ${timeLeft}s` : 'Reward Unlocked!'}
            </div>
          </div>
        </div>

        {/* Video Simulation Canvas */}
        <div className="relative aspect-video w-full bg-[#0a0c16] flex flex-col items-center justify-center overflow-hidden">
          {/* Animated background laser/energy effect */}
          <div className="absolute inset-0 bg-gradient-to-tr from-purple-950/40 via-cyan-950/20 to-slate-950" />
          
          <div className="relative z-10 flex flex-col items-center text-center p-6 space-y-3">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-cyan-600 to-indigo-600 flex items-center justify-center shadow-lg shadow-cyan-500/30 animate-pulse">
              <Play className="w-8 h-8 text-white fill-white ml-1" />
            </div>
            <div>
              <h4 className="text-xl font-bold font-cinzel text-white text-glow-cyan">
                TITAN WARS: REALM OF RUNES
              </h4>
              <p className="text-xs text-slate-400 max-w-sm mt-1">
                Summon mythic warriors, build your fortress, and conquer the dark realm in real-time PVP!
              </p>
            </div>
            <div className="flex items-center gap-2 text-[11px] text-emerald-400 font-medium">
              <CheckCircle className="w-3.5 h-3.5" />
              <span>Official Google Play Partner Video</span>
            </div>
          </div>

          {/* Video Timeline Progress */}
          <div className="absolute bottom-0 left-0 right-0 h-1.5 bg-slate-800">
            <div
              className="h-full bg-gradient-to-r from-cyan-500 to-indigo-500 transition-all duration-1000 ease-linear"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        {/* Bottom Action Footer */}
        <div className="bg-slate-900/95 px-5 py-3.5 border-t border-slate-800 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <Award className="w-4 h-4 text-amber-400" />
            <span>
              {rewardType === 'REVIVE'
                ? getTranslation(lang, 'rewardedRevivePrompt')
                : getTranslation(lang, 'doubleCoinsPrompt')}
            </span>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {!isCompleted ? (
              <button
                onClick={handleFastForward}
                title="Test feature: Fast forward ad without waiting 30 seconds"
                className="flex items-center gap-1 px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-medium rounded border border-slate-700 transition-colors"
              >
                <FastForward className="w-3 h-3 text-cyan-400" />
                <span>Test Skip</span>
              </button>
            ) : (
              <button
                onClick={handleClaimReward}
                className="flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs rounded-lg shadow-lg shadow-emerald-500/30 transition-transform active:scale-95 animate-bounce"
              >
                <CheckCircle className="w-4 h-4" />
                <span>Claim Reward</span>
              </button>
            )}

            <button
              onClick={onClose}
              className="text-xs text-slate-500 hover:text-slate-300 px-2 py-1"
            >
              Cancel
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
