/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useEffect, useState, useCallback } from 'react';
import { Pause, Play, RotateCcw, LogOut, ShieldAlert, Sparkles, Zap, Flame, Wind } from 'lucide-react';
import { PlayerData, StageConfig, Weapon, CombatOutcome, Language } from '../types/game';
import { STAGES, WEAPONS } from '../utils/gameData';
import { getTranslation } from '../utils/i18n';
import { audio } from '../utils/audio';

interface CombatArenaProps {
  stage: StageConfig;
  playerData: PlayerData;
  lang: Language;
  onCombatEnd: (outcome: CombatOutcome, earnedCoins: number, earnedXp: number, maxCombo: number) => void;
  onExit: () => void;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  color: string;
  size: number;
}

interface DamageNumber {
  id: number;
  x: number;
  y: number;
  text: string;
  color: string;
  alpha: number;
  isCrit: boolean;
}

export const CombatArena: React.FC<CombatArenaProps> = ({
  stage,
  playerData,
  lang,
  onCombatEnd,
  onExit
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Equipped Weapon
  const equippedWeapon = WEAPONS.find((w) => w.id === playerData.equippedWeaponId) || WEAPONS[0];
  const weaponLevel = playerData.weaponLevels[equippedWeapon.id] || 1;
  const playerMaxHp = 100 + (playerData.armorLevel - 1) * 25 + (playerData.level - 1) * 15;

  // React state for HUD
  const [playerHp, setPlayerHp] = useState(playerMaxHp);
  const [enemyHp, setEnemyHp] = useState(stage.enemyHp);
  const [roundTimer, setRoundTimer] = useState(99);
  const [isPaused, setIsPaused] = useState(false);
  const [comboCount, setComboCount] = useState(0);
  const [shadowEnergy, setShadowEnergy] = useState(40); // 0 to 100
  const [heavyCooldown, setHeavyCooldown] = useState(0); // 0 to 5.0 seconds
  const [combatOver, setCombatOver] = useState<CombatOutcome | null>(null);

  // Joystick touch references
  const joystickBaseRef = useRef<HTMLDivElement | null>(null);
  const [joystickPos, setJoystickPos] = useState({ x: 0, y: 0 });
  const isJoystickActiveRef = useRef(false);
  const joystickVectorRef = useRef({ x: 0, y: 0 });

  // Combat simulation state refs (for high performance canvas loop)
  const stateRef = useRef({
    player: {
      x: 180,
      y: 360,
      vx: 0,
      vy: 0,
      facing: 1 as 1 | -1, // 1 = right, -1 = left
      isGrounded: true,
      isCrouching: false,
      state: 'idle' as 'idle' | 'walk' | 'jump' | 'crouch' | 'heavy' | 'light' | 'kick' | 'dash' | 'hit',
      animTime: 0,
      comboStep: 0,
      attackCooldown: 0,
      heavyCooldownTimer: 0,
      invulnerableTimer: 0,
      hp: playerMaxHp,
      maxHp: playerMaxHp,
      energy: 40
    },
    enemy: {
      x: 620,
      y: 360,
      vx: 0,
      vy: 0,
      facing: -1 as 1 | -1,
      isGrounded: true,
      state: 'idle' as 'idle' | 'walk' | 'jump' | 'attack' | 'heavy' | 'block' | 'hit',
      animTime: 0,
      attackTimer: 0,
      aiDecisionTimer: 0,
      hp: stage.enemyHp,
      maxHp: stage.enemyHp,
      isBossSpecialReady: false
    },
    particles: [] as Particle[],
    damageNumbers: [] as DamageNumber[],
    screenShake: 0,
    hitStop: 0,
    roundTimeLeft: 99,
    maxCombo: 0,
    isOver: false
  });

  // Joystick touch handlers
  const handleTouchStart = (e: React.TouchEvent) => {
    isJoystickActiveRef.current = true;
    handleTouchMove(e);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isJoystickActiveRef.current || !joystickBaseRef.current) return;
    const touch = e.touches[0];
    const rect = joystickBaseRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    const dx = touch.clientX - centerX;
    const dy = touch.clientY - centerY;
    const distance = Math.sqrt(dx * dx + dy * dy);
    const maxRadius = rect.width / 2;

    const clampedDist = Math.min(distance, maxRadius);
    const angle = Math.atan2(dy, dx);

    const normX = (Math.cos(angle) * clampedDist) / maxRadius;
    const normY = (Math.sin(angle) * clampedDist) / maxRadius;

    setJoystickPos({ x: normX * 36, y: normY * 36 });
    joystickVectorRef.current = { x: normX, y: normY };
  };

  const handleTouchEnd = () => {
    isJoystickActiveRef.current = false;
    setJoystickPos({ x: 0, y: 0 });
    joystickVectorRef.current = { x: 0, y: 0 };
  };

  // Keyboard controls
  const keysDownRef = useRef<{ [key: string]: boolean }>({});

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      keysDownRef.current[e.key.toLowerCase()] = true;

      if (e.key.toLowerCase() === 'k') {
        executeHeavySword();
      } else if (e.key.toLowerCase() === 'j') {
        executeLightAttack();
      } else if (e.key.toLowerCase() === 'l') {
        executeKick();
      } else if (e.key === ' ' || e.key.toLowerCase() === 'shift') {
        executeDash();
      } else if (e.key.toLowerCase() === 'u') {
        executeVoidBlast();
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      keysDownRef.current[e.key.toLowerCase()] = false;
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
    };
  }, []);

  // Actions
  const executeHeavySword = useCallback(() => {
    const s = stateRef.current;
    if (s.isOver || isPaused) return;
    if (s.player.heavyCooldownTimer > 0) return; // Strict 5-second cooldown!
    if (s.player.state === 'heavy' || s.player.state === 'dash') return;

    audio.playHeavySwordSwing();
    s.player.state = 'heavy';
    s.player.animTime = 0;
    // Set strict 5.0s cooldown!
    s.player.heavyCooldownTimer = equippedWeapon.heavyCooldownSeconds;
    setHeavyCooldown(equippedWeapon.heavyCooldownSeconds);
  }, [equippedWeapon.heavyCooldownSeconds, isPaused]);

  const executeLightAttack = useCallback(() => {
    const s = stateRef.current;
    if (s.isOver || isPaused) return;
    if (s.player.state === 'heavy' || s.player.state === 'dash') return;
    if (s.player.attackCooldown > 0) return;

    audio.playLightAttack();
    s.player.state = 'light';
    s.player.animTime = 0;
    s.player.comboStep = (s.player.comboStep % 3) + 1;
    s.player.attackCooldown = 0.35 / equippedWeapon.attackSpeed;
  }, [equippedWeapon.attackSpeed, isPaused]);

  const executeKick = useCallback(() => {
    const s = stateRef.current;
    if (s.isOver || isPaused) return;
    if (s.player.state === 'heavy' || s.player.state === 'dash') return;
    if (s.player.attackCooldown > 0) return;

    audio.playKick();
    s.player.state = 'kick';
    s.player.animTime = 0;
    s.player.attackCooldown = 0.4;
  }, [isPaused]);

  const executeDash = useCallback(() => {
    const s = stateRef.current;
    if (s.isOver || isPaused) return;
    if (s.player.state === 'dash') return;

    audio.playShadowDash();
    s.player.state = 'dash';
    s.player.animTime = 0;
    s.player.invulnerableTimer = 0.45;
    s.player.vx = s.player.facing * 11;
  }, [isPaused]);

  const executeVoidBlast = useCallback(() => {
    const s = stateRef.current;
    if (s.isOver || isPaused) return;
    if (s.player.energy < 100) return;

    audio.playShadowBlast();
    s.screenShake = 16;
    s.player.energy = 0;
    setShadowEnergy(0);

    // Erupt shadow wave
    const dist = Math.abs(s.player.x - s.enemy.x);
    if (dist < 320) {
      const dmg = 95 + Math.floor(Math.random() * 25);
      s.enemy.hp = Math.max(0, s.enemy.hp - dmg);
      s.enemy.state = 'hit';
      s.enemy.vx = s.player.facing * 9;
      setEnemyHp(s.enemy.hp);

      // Add particles
      for (let i = 0; i < 28; i++) {
        s.particles.push({
          x: s.enemy.x,
          y: s.enemy.y - 40,
          vx: (Math.random() - 0.5) * 14,
          vy: (Math.random() - 0.5) * 14,
          life: 0,
          maxLife: 35,
          color: '#a855f7',
          size: 4 + Math.random() * 5
        });
      }

      s.damageNumbers.push({
        id: Date.now() + Math.random(),
        x: s.enemy.x,
        y: s.enemy.y - 70,
        text: `-${dmg} VOID BURST!`,
        color: '#c084fc',
        alpha: 1,
        isCrit: true
      });
    }
  }, [isPaused]);

  // Main Canvas Game Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Load background image
    const bgImg = new Image();
    bgImg.src = '/src/assets/images/abyss_arena_backdrop_1793472337348.jpg';

    let lastTime = performance.now();
    let animationId: number;

    const gameLoop = (currentTime: number) => {
      const dt = Math.min((currentTime - lastTime) / 1000, 0.05); // Clamp dt to prevent jumping
      lastTime = currentTime;

      const s = stateRef.current;

      if (!isPaused && !s.isOver) {
        // Countdown Heavy Sword Cooldown (Strict 5.0 seconds!)
        if (s.player.heavyCooldownTimer > 0) {
          const prev = s.player.heavyCooldownTimer;
          s.player.heavyCooldownTimer = Math.max(0, s.player.heavyCooldownTimer - dt);
          setHeavyCooldown(s.player.heavyCooldownTimer);
          if (prev > 0 && s.player.heavyCooldownTimer === 0) {
            audio.playCooldownReady();
          }
        }

        // Countdown general attack cooldown & invulnerability
        if (s.player.attackCooldown > 0) {
          s.player.attackCooldown = Math.max(0, s.player.attackCooldown - dt);
        }
        if (s.player.invulnerableTimer > 0) {
          s.player.invulnerableTimer = Math.max(0, s.player.invulnerableTimer - dt);
        }

        // Round timer countdown
        s.roundTimeLeft -= dt;
        if (s.roundTimeLeft <= 0) {
          s.roundTimeLeft = 0;
          s.isOver = true;
          // Determine winner by HP
          const outcome: CombatOutcome = s.player.hp > s.enemy.hp ? 'VICTORY' : 'DEFEAT';
          setCombatOver(outcome);
          if (outcome === 'VICTORY') {
            audio.playVictory();
          } else {
            audio.playDefeat();
          }
          onCombatEnd(outcome, stage.coinReward, stage.xpReward, s.maxCombo);
        }
        setRoundTimer(Math.ceil(s.roundTimeLeft));

        // Player movement input resolution (Joystick + Keyboard)
        let moveX = joystickVectorRef.current.x;
        let moveY = joystickVectorRef.current.y;

        if (keysDownRef.current['a'] || keysDownRef.current['arrowleft']) moveX = -1;
        if (keysDownRef.current['d'] || keysDownRef.current['arrowright']) moveX = 1;
        if (keysDownRef.current['w'] || keysDownRef.current['arrowup']) moveY = -1;
        if (keysDownRef.current['s'] || keysDownRef.current['arrowdown']) moveY = 1;

        // Player State Transitions
        if (s.player.state === 'idle' || s.player.state === 'walk') {
          if (Math.abs(moveX) > 0.2) {
            s.player.vx = moveX * 4.2;
            s.player.state = 'walk';
            s.player.facing = moveX > 0 ? 1 : -1;
          } else {
            s.player.vx *= 0.6;
            s.player.state = 'idle';
          }

          if (moveY < -0.5 && s.player.isGrounded) {
            s.player.vy = -12;
            s.player.isGrounded = false;
            s.player.state = 'jump';
          }
        }

        // Gravity & Ground physics
        s.player.x += s.player.vx;
        s.player.y += s.player.vy;
        if (!s.player.isGrounded) {
          s.player.vy += 0.65; // gravity
          if (s.player.y >= 360) {
            s.player.y = 360;
            s.player.vy = 0;
            s.player.isGrounded = true;
            if (s.player.state === 'jump') s.player.state = 'idle';
          }
        }

        // Action duration advances
        if (s.player.state === 'heavy') {
          s.player.animTime += dt;
          s.player.vx *= 0.85;

          // Check hit frame (around 0.22s into the 5s heavy swing)
          if (s.player.animTime >= 0.22 && s.player.animTime < 0.26) {
            const hitDist = Math.abs(s.player.x - s.enemy.x);
            const inFront = (s.enemy.x - s.player.x) * s.player.facing > 0;
            if (hitDist <= equippedWeapon.reach + 20 && inFront) {
              // Devastating heavy sword strike!
              const baseDmg = equippedWeapon.heavyDamage + (weaponLevel - 1) * 14;
              const dmg = baseDmg + Math.floor(Math.random() * 12);
              s.enemy.hp = Math.max(0, s.enemy.hp - dmg);
              s.enemy.state = 'hit';
              s.enemy.vx = s.player.facing * 7;
              s.screenShake = 12;
              audio.playHitImpact(true);
              audio.playBladeClash();

              // Spurt dark shadow sparks
              for (let i = 0; i < 18; i++) {
                s.particles.push({
                  x: s.enemy.x,
                  y: s.enemy.y - 45,
                  vx: (Math.random() - 0.5) * 10,
                  vy: (Math.random() - 0.5) * 8 - 2,
                  life: 0,
                  maxLife: 25,
                  color: '#06b6d4',
                  size: 3 + Math.random() * 4
                });
              }

              s.damageNumbers.push({
                id: Date.now() + Math.random(),
                x: s.enemy.x,
                y: s.enemy.y - 60,
                text: `-${dmg} HEAVY!`,
                color: '#22d3ee',
                alpha: 1,
                isCrit: true
              });

              s.player.energy = Math.min(100, s.player.energy + 25);
              setShadowEnergy(s.player.energy);
              setEnemyHp(s.enemy.hp);

              setComboCount((prev) => {
                const next = prev + 1;
                s.maxCombo = Math.max(s.maxCombo, next);
                return next;
              });
            }
          }

          if (s.player.animTime > 0.55) {
            s.player.state = 'idle';
          }
        } else if (s.player.state === 'light') {
          s.player.animTime += dt;
          s.player.vx = s.player.facing * 2;

          if (s.player.animTime >= 0.12 && s.player.animTime < 0.16) {
            const hitDist = Math.abs(s.player.x - s.enemy.x);
            const inFront = (s.enemy.x - s.player.x) * s.player.facing > 0;
            if (hitDist <= equippedWeapon.reach && inFront) {
              const baseDmg = equippedWeapon.damage + (weaponLevel - 1) * 6;
              const dmg = baseDmg + Math.floor(Math.random() * 6);
              s.enemy.hp = Math.max(0, s.enemy.hp - dmg);
              s.enemy.state = 'hit';
              s.enemy.vx = s.player.facing * 3;
              audio.playHitImpact(false);

              for (let i = 0; i < 8; i++) {
                s.particles.push({
                  x: s.enemy.x,
                  y: s.enemy.y - 40,
                  vx: (Math.random() - 0.5) * 6,
                  vy: (Math.random() - 0.5) * 6,
                  life: 0,
                  maxLife: 20,
                  color: '#a855f7',
                  size: 2.5
                });
              }

              s.damageNumbers.push({
                id: Date.now() + Math.random(),
                x: s.enemy.x,
                y: s.enemy.y - 50,
                text: `-${dmg}`,
                color: '#e2e8f0',
                alpha: 1,
                isCrit: false
              });

              s.player.energy = Math.min(100, s.player.energy + 12);
              setShadowEnergy(s.player.energy);
              setEnemyHp(s.enemy.hp);

              setComboCount((prev) => {
                const next = prev + 1;
                s.maxCombo = Math.max(s.maxCombo, next);
                return next;
              });
            }
          }

          if (s.player.animTime > 0.28) {
            s.player.state = 'idle';
          }
        } else if (s.player.state === 'kick') {
          s.player.animTime += dt;
          if (s.player.animTime >= 0.12 && s.player.animTime < 0.16) {
            const hitDist = Math.abs(s.player.x - s.enemy.x);
            if (hitDist < 75) {
              const dmg = 22;
              s.enemy.hp = Math.max(0, s.enemy.hp - dmg);
              s.enemy.state = 'hit';
              s.enemy.vx = s.player.facing * 8; // Heavy knockback
              audio.playHitImpact(false);
              setEnemyHp(s.enemy.hp);
            }
          }
          if (s.player.animTime > 0.3) {
            s.player.state = 'idle';
          }
        } else if (s.player.state === 'dash') {
          s.player.animTime += dt;
          s.player.vx *= 0.9;
          if (s.player.animTime > 0.35) {
            s.player.state = 'idle';
          }
        } else if (s.player.state === 'hit') {
          s.player.animTime += dt;
          s.player.vx *= 0.85;
          if (s.player.animTime > 0.25) {
            s.player.state = 'idle';
          }
        }

        // Clamp arena boundaries (x: 60 to 740)
        s.player.x = Math.max(60, Math.min(740, s.player.x));
        s.enemy.x = Math.max(60, Math.min(740, s.enemy.x));

        // Enemy AI Logic
        s.enemy.aiDecisionTimer -= dt;
        s.enemy.facing = s.player.x > s.enemy.x ? 1 : -1;

        if (s.enemy.aiDecisionTimer <= 0 && s.enemy.state !== 'hit') {
          s.enemy.aiDecisionTimer = 0.4 + Math.random() * (0.6 - stage.enemyAggression * 0.3);
          const distance = Math.abs(s.enemy.x - s.player.x);

          if (distance > 110) {
            // Advance towards player
            s.enemy.state = 'walk';
            s.enemy.vx = s.enemy.facing * stage.enemySpeed;
          } else {
            // In combat range: choose attack, heavy, or block
            const roll = Math.random();
            if (roll < stage.enemyAggression) {
              // Initiate enemy attack
              s.enemy.state = roll > 0.7 ? 'heavy' : 'attack';
              s.enemy.animTime = 0;
            } else if (roll < 0.9) {
              s.enemy.state = 'block';
              s.enemy.vx = 0;
            } else {
              // Step back
              s.enemy.vx = -s.enemy.facing * 2.5;
            }
          }
        }

        // Enemy Action Execution
        if (s.enemy.state === 'attack') {
          s.enemy.animTime += dt;
          if (s.enemy.animTime >= 0.18 && s.enemy.animTime < 0.22) {
            const hitDist = Math.abs(s.enemy.x - s.player.x);
            if (hitDist <= 85 && s.player.invulnerableTimer <= 0) {
              const dmg = stage.enemyDamage + Math.floor(Math.random() * 5);
              s.player.hp = Math.max(0, s.player.hp - dmg);
              s.player.state = 'hit';
              s.player.animTime = 0;
              s.player.vx = s.enemy.facing * 4;
              s.screenShake = 6;
              audio.playHitImpact(false);
              setPlayerHp(s.player.hp);
              setComboCount(0); // Reset player combo on hit

              s.damageNumbers.push({
                id: Date.now() + Math.random(),
                x: s.player.x,
                y: s.player.y - 50,
                text: `-${dmg}`,
                color: '#f87171',
                alpha: 1,
                isCrit: false
              });
            }
          }
          if (s.enemy.animTime > 0.45) {
            s.enemy.state = 'idle';
          }
        } else if (s.enemy.state === 'heavy') {
          s.enemy.animTime += dt;
          if (s.enemy.animTime >= 0.28 && s.enemy.animTime < 0.32) {
            const hitDist = Math.abs(s.enemy.x - s.player.x);
            if (hitDist <= 100 && s.player.invulnerableTimer <= 0) {
              const dmg = Math.round(stage.enemyDamage * 1.8 + Math.random() * 8);
              s.player.hp = Math.max(0, s.player.hp - dmg);
              s.player.state = 'hit';
              s.player.animTime = 0;
              s.player.vx = s.enemy.facing * 7;
              s.screenShake = 10;
              audio.playHitImpact(true);
              setPlayerHp(s.player.hp);
              setComboCount(0);

              s.damageNumbers.push({
                id: Date.now() + Math.random(),
                x: s.player.x,
                y: s.player.y - 60,
                text: `-${dmg} CRUSH!`,
                color: '#ef4444',
                alpha: 1,
                isCrit: true
              });
            }
          }
          if (s.enemy.animTime > 0.6) {
            s.enemy.state = 'idle';
          }
        } else if (s.enemy.state === 'hit') {
          s.enemy.animTime += dt;
          s.enemy.vx *= 0.85;
          if (s.enemy.animTime > 0.28) {
            s.enemy.state = 'idle';
          }
        } else if (s.enemy.state === 'walk') {
          s.enemy.x += s.enemy.vx;
        }

        // Check Victory / Defeat Conditions
        if (s.enemy.hp <= 0 && !s.isOver) {
          s.isOver = true;
          setCombatOver('VICTORY');
          audio.playVictory();
          onCombatEnd('VICTORY', stage.coinReward, stage.xpReward, s.maxCombo);
        } else if (s.player.hp <= 0 && !s.isOver) {
          s.isOver = true;
          setCombatOver('DEFEAT');
          audio.playDefeat();
          onCombatEnd('DEFEAT', 0, 20, s.maxCombo);
        }

        // Particle updates
        for (let i = s.particles.length - 1; i >= 0; i--) {
          const p = s.particles[i];
          p.x += p.vx;
          p.y += p.vy;
          p.life++;
          if (p.life >= p.maxLife) {
            s.particles.splice(i, 1);
          }
        }

        // Damage numbers update
        for (let i = s.damageNumbers.length - 1; i >= 0; i--) {
          const d = s.damageNumbers[i];
          d.y -= 1.2;
          d.alpha -= 0.025;
          if (d.alpha <= 0) {
            s.damageNumbers.splice(i, 1);
          }
        }

        // Screen shake decay
        if (s.screenShake > 0) {
          s.screenShake = Math.max(0, s.screenShake - 0.7);
        }
      }

      // RENDER SECTION (800 x 450 Virtual Canvas)
      ctx.save();

      // Screen shake translation
      if (s.screenShake > 0) {
        const shakeX = (Math.random() - 0.5) * s.screenShake;
        const shakeY = (Math.random() - 0.5) * s.screenShake;
        ctx.translate(shakeX, shakeY);
      }

      // Draw Arena Background
      if (bgImg.complete && bgImg.naturalWidth > 0) {
        ctx.drawImage(bgImg, 0, 0, 800, 450);
      } else {
        // Fallback atmospheric dark gradient
        const bgGrad = ctx.createLinearGradient(0, 0, 0, 450);
        bgGrad.addColorStop(0, '#050711');
        bgGrad.addColorStop(0.65, '#0d1326');
        bgGrad.addColorStop(1, '#020409');
        ctx.fillStyle = bgGrad;
        ctx.fillRect(0, 0, 800, 450);
      }

      // Ground floor line & shadow mist
      ctx.fillStyle = '#03050a';
      ctx.fillRect(0, 360, 800, 90);

      // Mystical Ground Glow Hairline
      ctx.strokeStyle = 'rgba(6, 182, 212, 0.4)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(0, 360);
      ctx.lineTo(800, 360);
      ctx.stroke();

      // Shadow Floor Reflections
      drawCharacterShadow(ctx, s.player.x, 360);
      drawCharacterShadow(ctx, s.enemy.x, 360);

      // DRAW PLAYER SILHOUETTE
      drawShadowWarrior(
        ctx,
        s.player.x,
        s.player.y,
        s.player.facing,
        s.player.state,
        s.player.animTime,
        'player',
        equippedWeapon.color,
        s.player.invulnerableTimer > 0
      );

      // DRAW ENEMY BOSS SILHOUETTE
      drawShadowWarrior(
        ctx,
        s.enemy.x,
        s.enemy.y,
        s.enemy.facing,
        s.enemy.state,
        s.enemy.animTime,
        'enemy',
        '#ef4444',
        false,
        stage.id === 1 // Boss guardian horn/spikes
      );

      // Render Particles
      s.particles.forEach((p) => {
        const alpha = Math.max(0, 1 - p.life / p.maxLife);
        ctx.fillStyle = p.color;
        ctx.globalAlpha = alpha;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalAlpha = 1.0;
      });

      // Render Floating Damage Numbers
      s.damageNumbers.forEach((d) => {
        ctx.save();
        ctx.globalAlpha = d.alpha;
        ctx.font = d.isCrit ? 'bold 20px Cinzel, sans-serif' : 'bold 15px Plus Jakarta Sans, sans-serif';
        ctx.fillStyle = d.color;
        ctx.textAlign = 'center';
        ctx.shadowColor = d.color;
        ctx.shadowBlur = d.isCrit ? 10 : 4;
        ctx.fillText(d.text, d.x, d.y);
        ctx.restore();
      });

      ctx.restore();

      animationId = requestAnimationFrame(gameLoop);
    };

    animationId = requestAnimationFrame(gameLoop);
    return () => cancelAnimationFrame(animationId);
  }, [equippedWeapon, weaponLevel, stage, isPaused, onCombatEnd]);

  // Helper: Ground Shadow Oval
  function drawCharacterShadow(ctx: CanvasRenderingContext2D, x: number, y: number) {
    ctx.save();
    ctx.fillStyle = 'rgba(0, 0, 0, 0.65)';
    ctx.beginPath();
    ctx.ellipse(x, y + 2, 26, 7, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  // Draw 2D Shadow Silhouette Fighter
  function drawShadowWarrior(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    facing: 1 | -1,
    action: string,
    animTime: number,
    type: 'player' | 'enemy',
    accentColor: string,
    isInvulnerable = false,
    isGuardianBoss = false
  ) {
    ctx.save();
    ctx.translate(x, y);
    ctx.scale(facing, 1);

    if (isInvulnerable) {
      ctx.globalAlpha = 0.5 + Math.sin(animTime * 20) * 0.3;
    }

    // Shadow silhouette pure black body
    ctx.fillStyle = '#06070a';
    ctx.strokeStyle = '#06070a';
    ctx.lineWidth = 5;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    // Stance calculations
    let headY = -62;
    let bodyAngle = 0;
    let frontArmAngle = 0.4;
    let swordAngle = 0.5;
    let backLegAngle = 0.2;
    let frontLegAngle = -0.2;

    if (action === 'walk') {
      const stride = Math.sin(animTime * 12);
      frontLegAngle = stride * 0.5;
      backLegAngle = -stride * 0.5;
      bodyAngle = 0.1;
      headY += Math.abs(stride) * 2;
    } else if (action === 'jump') {
      frontLegAngle = 0.6;
      backLegAngle = 0.4;
      headY -= 4;
    } else if (action === 'heavy') {
      // Overhead cleave animation
      const t = Math.min(1, animTime / 0.5);
      if (t < 0.4) {
        // Wind-up raised high behind back
        bodyAngle = -0.25;
        frontArmAngle = -1.8;
        swordAngle = -2.2;
      } else {
        // Massive downward slash arc!
        bodyAngle = 0.35;
        frontArmAngle = 0.9;
        swordAngle = 1.3;

        // Draw weapon motion slash trail
        ctx.save();
        ctx.strokeStyle = accentColor;
        ctx.lineWidth = 14;
        ctx.shadowColor = accentColor;
        ctx.shadowBlur = 18;
        ctx.beginPath();
        ctx.arc(10, -35, 75, -1.8, 1.2, false);
        ctx.stroke();
        ctx.restore();
      }
    } else if (action === 'light') {
      const t = Math.min(1, animTime / 0.28);
      frontArmAngle = -0.2 + t * 1.6;
      swordAngle = -0.3 + t * 1.8;
    } else if (action === 'kick') {
      bodyAngle = -0.3;
      frontLegAngle = 1.4; // High side kick
      backLegAngle = -0.3;
    } else if (action === 'hit') {
      bodyAngle = -0.4;
      headY += 4;
      frontArmAngle = -0.8;
    } else if (action === 'dash') {
      bodyAngle = 0.5;
      frontLegAngle = -0.6;
      backLegAngle = 0.7;
    }

    // Legs
    // Back leg
    ctx.beginPath();
    ctx.moveTo(-4, -28);
    ctx.lineTo(-4 + Math.sin(backLegAngle) * 16, -14);
    ctx.lineTo(-4 + Math.sin(backLegAngle) * 24, 0);
    ctx.stroke();

    // Front leg
    ctx.beginPath();
    ctx.moveTo(4, -28);
    ctx.lineTo(4 + Math.sin(frontLegAngle) * 16, -14);
    ctx.lineTo(4 + Math.sin(frontLegAngle) * 24, 0);
    ctx.stroke();

    // Torso (Solid silhouette with subtle dark highlight)
    ctx.save();
    ctx.rotate(bodyAngle);

    // Torso shape
    ctx.beginPath();
    ctx.moveTo(-9, -28);
    ctx.lineTo(9, -28);
    ctx.lineTo(13, -56);
    ctx.lineTo(-13, -56);
    ctx.closePath();
    ctx.fill();

    // Scarf / Cape waving in wind
    ctx.fillStyle = '#0a0d14';
    ctx.beginPath();
    ctx.moveTo(-10, -52);
    ctx.quadraticCurveTo(-26, -45 + Math.sin(animTime * 6) * 4, -38, -50 + Math.cos(animTime * 7) * 6);
    ctx.lineTo(-32, -40);
    ctx.lineTo(-8, -48);
    ctx.closePath();
    ctx.fill();

    // Head / Ninja Helmet
    ctx.fillStyle = '#06070a';
    ctx.beginPath();
    ctx.arc(0, headY, 11, 0, Math.PI * 2);
    ctx.fill();

    // Horns/Spikes for Guardian of the Abyss (Stage 1 Boss)
    if (isGuardianBoss) {
      ctx.fillStyle = '#030407';
      ctx.beginPath();
      ctx.moveTo(-8, headY - 6);
      ctx.lineTo(-16, headY - 20);
      ctx.lineTo(-4, headY - 10);
      ctx.closePath();
      ctx.fill();

      ctx.beginPath();
      ctx.moveTo(8, headY - 6);
      ctx.lineTo(16, headY - 20);
      ctx.lineTo(4, headY - 10);
      ctx.closePath();
      ctx.fill();
    }

    // GLOWING EYES (The iconic Shadow Fight hallmark!)
    ctx.fillStyle = type === 'player' ? '#22d3ee' : '#f87171';
    ctx.shadowColor = ctx.fillStyle;
    ctx.shadowBlur = 8;
    ctx.beginPath();
    ctx.ellipse(4, headY - 1, 3.5, 1.6, 0.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;

    // Back Arm
    ctx.strokeStyle = '#06070a';
    ctx.beginPath();
    ctx.moveTo(-8, -50);
    ctx.lineTo(-14, -36);
    ctx.lineTo(-10, -22);
    ctx.stroke();

    // Front Arm & WEAPON
    ctx.save();
    ctx.translate(6, -50);
    ctx.rotate(frontArmAngle);
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(14, 16);
    ctx.lineTo(24, 24);
    ctx.stroke();

    // WEAPON (Heavy Sword or Boss Blade)
    ctx.save();
    ctx.translate(24, 24);
    ctx.rotate(swordAngle);

    // Blade Hilt
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(-3, -2, 6, 12);
    ctx.fillStyle = '#475569';
    ctx.fillRect(-10, -5, 20, 5);

    // Giant Heavy Sword Blade with Neon Edge Glow
    const bladeLength = isGuardianBoss ? 75 : 68;
    const bladeWidth = isGuardianBoss ? 16 : 13;

    // Blade silhouette
    ctx.fillStyle = '#06070a';
    ctx.beginPath();
    ctx.moveTo(-bladeWidth / 2, -5);
    ctx.lineTo(bladeWidth / 2, -5);
    ctx.lineTo(bladeWidth / 2, -bladeLength);
    ctx.lineTo(0, -bladeLength - 14);
    ctx.lineTo(-bladeWidth / 2, -bladeLength);
    ctx.closePath();
    ctx.fill();

    // Glowing Runes / Edge Highlight
    ctx.strokeStyle = accentColor;
    ctx.lineWidth = 2.5;
    ctx.shadowColor = accentColor;
    ctx.shadowBlur = 10;
    ctx.beginPath();
    ctx.moveTo(bladeWidth / 2, -5);
    ctx.lineTo(bladeWidth / 2, -bladeLength);
    ctx.lineTo(0, -bladeLength - 14);
    ctx.lineTo(-bladeWidth / 2, -bladeLength);
    ctx.stroke();

    // Blade central glowing rune line
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(0, -10);
    ctx.lineTo(0, -bladeLength + 8);
    ctx.stroke();

    ctx.restore(); // Weapon restore
    ctx.restore(); // Front arm restore
    ctx.restore(); // Torso restore
    ctx.restore(); // Full warrior restore
  }

  // HP Percentages
  const playerHpPercent = Math.max(0, Math.min(100, (playerHp / playerMaxHp) * 100));
  const enemyHpPercent = Math.max(0, Math.min(100, (enemyHp / stage.enemyHp) * 100));

  // Circular cooldown progress calculation (5.0s max)
  const cdProgressPercent = heavyCooldown > 0 ? (heavyCooldown / 5.0) * 100 : 0;
  const cdDashOffset = (cdProgressPercent / 100) * (2 * Math.PI * 26);

  return (
    <div className="relative w-full h-full flex flex-col items-center justify-center bg-black overflow-hidden select-none">
      {/* 16:9 Arena Canvas Frame */}
      <div className="relative w-full max-w-5xl aspect-[16/9] max-h-[85vh] bg-[#020408] rounded-xl overflow-hidden shadow-2xl border border-slate-800/80">
        {/* The 2D Combat Canvas */}
        <canvas
          ref={canvasRef}
          width={800}
          height={450}
          className="w-full h-full object-contain block bg-[#030611]"
        />

        {/* COMBAT HUD OVERLAY */}
        <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-3 sm:p-5">
          {/* Top HUD: HP Bars & VS Timer */}
          <div className="flex items-start justify-between gap-3 pointer-events-auto">
            {/* Player HP (Green/Cyan Glow on Top-Left as specified) */}
            <div className="flex-1 max-w-xs space-y-1">
              <div className="flex items-center justify-between text-xs font-bold">
                <span className="text-cyan-300 flex items-center gap-1.5 text-glow-cyan">
                  <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                  <span>{playerData.displayName}</span>
                  <span className="text-[10px] text-cyan-500 font-mono">Lv.{playerData.level}</span>
                </span>
                <span className="font-mono text-cyan-200 text-xs tabular-nums">
                  {Math.round(playerHp)} / {playerMaxHp}
                </span>
              </div>
              <div className="h-4 bg-slate-950/80 rounded-md border border-cyan-500/40 p-0.5 overflow-hidden shadow-glow-cyan">
                <div
                  className="h-full bg-gradient-to-r from-teal-500 via-cyan-400 to-emerald-400 rounded-sm transition-all duration-150"
                  style={{ width: `${playerHpPercent}%` }}
                />
              </div>

              {/* Player Void Energy Bar */}
              <div className="h-1.5 bg-slate-950/90 rounded-full border border-purple-900/60 overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-purple-600 to-fuchsia-400 transition-all duration-300"
                  style={{ width: `${shadowEnergy}%` }}
                />
              </div>
            </div>

            {/* Central Round Timer & Pause */}
            <div className="flex flex-col items-center shrink-0 -mt-1">
              <div className="w-12 h-12 rounded-full bg-slate-950/90 border-2 border-slate-700/80 flex items-center justify-center shadow-lg">
                <span className="text-xl font-black font-cinzel text-white tabular-nums">
                  {roundTimer}
                </span>
              </div>
              <span className="text-[10px] font-black tracking-widest text-slate-400 mt-0.5 font-cinzel">
                {getTranslation(lang, 'vs')}
              </span>
              <button
                onClick={() => setIsPaused(!isPaused)}
                className="mt-1 p-1 bg-slate-900/80 hover:bg-slate-800 border border-slate-700 rounded-md text-slate-300 transition-colors"
                title="Pause"
              >
                {isPaused ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />}
              </button>
            </div>

            {/* Enemy HP (Red Glow on Top-Right as specified) */}
            <div className="flex-1 max-w-xs space-y-1 text-right">
              <div className="flex items-center justify-between text-xs font-bold">
                <span className="font-mono text-red-200 text-xs tabular-nums">
                  {Math.round(enemyHp)} / {stage.enemyHp}
                </span>
                <span className="text-red-400 flex items-center gap-1.5 text-glow-crimson">
                  <span>{stage.enemyName}</span>
                  <span className="text-[10px] text-red-500 font-mono">St.{stage.id}</span>
                </span>
              </div>
              <div className="h-4 bg-slate-950/80 rounded-md border border-red-500/40 p-0.5 overflow-hidden shadow-glow-crimson">
                <div
                  className="h-full bg-gradient-to-l from-red-600 via-rose-500 to-amber-500 rounded-sm transition-all duration-150 ml-auto"
                  style={{ width: `${enemyHpPercent}%` }}
                />
              </div>
              <div className="text-[10px] text-slate-400 uppercase font-semibold">
                {getTranslation(lang, stage.enemyTitleKey as never)}
              </div>
            </div>
          </div>

          {/* Dynamic Combo Multiplier Alert */}
          {comboCount >= 2 && (
            <div className="self-center animate-bounce">
              <div className="bg-gradient-to-r from-amber-500/20 via-purple-500/30 to-amber-500/20 border border-amber-400/50 rounded-full px-4 py-1 flex items-center gap-1.5 shadow-lg shadow-purple-900/40">
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span className="text-sm font-black font-cinzel text-amber-300 tracking-wider">
                  {comboCount} {getTranslation(lang, 'hits')}!
                </span>
              </div>
            </div>
          )}

          {/* TOUCH CONTROLS (Left 2D Virtual Joystick & Right Action Buttons) */}
          <div className="flex items-end justify-between w-full pointer-events-auto pb-1 sm:pb-2">
            {/* Left: 2D Virtual Joystick */}
            <div
              ref={joystickBaseRef}
              onTouchStart={handleTouchStart}
              onTouchMove={handleTouchMove}
              onTouchEnd={handleTouchEnd}
              className="w-28 h-28 sm:w-32 sm:h-32 rounded-full bg-slate-950/70 border-2 border-slate-700/60 backdrop-blur-sm flex items-center justify-center relative touch-none shadow-xl select-none"
            >
              <div className="absolute inset-0 rounded-full border border-dashed border-cyan-500/20" />
              {/* Virtual Stick Knob */}
              <div
                className="w-12 h-12 rounded-full bg-gradient-to-tr from-cyan-600 to-indigo-600 border border-cyan-300/40 shadow-lg shadow-cyan-500/30 flex items-center justify-center pointer-events-none transition-transform duration-75"
                style={{
                  transform: `translate(${joystickPos.x}px, ${joystickPos.y}px)`
                }}
              >
                <div className="w-4 h-4 rounded-full bg-cyan-200/50" />
              </div>
              <span className="absolute bottom-1 text-[9px] text-slate-500 uppercase font-bold tracking-wider">
                MOVE / JUMP
              </span>
            </div>

            {/* Right: Combat Action Buttons */}
            <div className="flex items-end gap-2 sm:gap-3">
              {/* Void Blast / Ultimate Button */}
              {shadowEnergy >= 100 && (
                <button
                  onClick={executeVoidBlast}
                  className="w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-gradient-to-tr from-purple-600 to-fuchsia-600 border-2 border-purple-300 text-white flex flex-col items-center justify-center shadow-lg shadow-purple-500/50 animate-pulse active:scale-90"
                  title="Void Blast (U)"
                >
                  <Zap className="w-5 h-5" />
                  <span className="text-[8px] font-bold uppercase">BURST</span>
                </button>
              )}

              {/* Shadow Dash */}
              <button
                onClick={executeDash}
                className="w-11 h-11 sm:w-12 sm:h-12 rounded-full bg-slate-900/90 border border-slate-700 text-slate-200 flex flex-col items-center justify-center active:scale-90 transition-transform shadow-md"
                title="Shadow Dash (Space)"
              >
                <Wind className="w-4 h-4 text-cyan-400" />
                <span className="text-[8px] uppercase font-bold mt-0.5">DASH</span>
              </button>

              {/* Kick Button */}
              <button
                onClick={executeKick}
                className="w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-slate-900/90 border border-slate-700 text-slate-200 flex flex-col items-center justify-center active:scale-90 transition-transform shadow-md"
                title="Kick (L)"
              >
                <span className="text-base font-black text-amber-400">⚡</span>
                <span className="text-[9px] uppercase font-bold text-slate-300">KICK</span>
              </button>

              {/* Light Strike Button */}
              <button
                onClick={executeLightAttack}
                className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-slate-900/95 border-2 border-slate-700 text-white flex flex-col items-center justify-center active:scale-90 transition-transform shadow-lg hover:border-slate-500"
                title="Light Attack (J)"
              >
                <Flame className="w-5 h-5 text-indigo-400" />
                <span className="text-[9px] uppercase font-bold text-slate-200">LIGHT</span>
              </button>

              {/* PRIMARY WEAPON: HEAVY SWORD (STRICT 5-SECOND COOLDOWN OVERLAY!) */}
              <button
                onClick={executeHeavySword}
                disabled={heavyCooldown > 0}
                className={`w-16 h-16 sm:w-20 sm:h-20 rounded-full flex flex-col items-center justify-center relative overflow-hidden transition-all shadow-xl active:scale-90 ${
                  heavyCooldown > 0
                    ? 'bg-slate-950 border-2 border-slate-800 text-slate-600 cursor-not-allowed opacity-90'
                    : 'bg-gradient-to-br from-cyan-600 to-indigo-700 border-2 border-cyan-400 text-white shadow-glow-cyan hover:brightness-110'
                }`}
                title="Heavy Sword Strike (K)"
              >
                {/* 5-SECOND COOLDOWN RADIAL COUNTDOWN OVERLAY */}
                {heavyCooldown > 0 ? (
                  <>
                    <svg className="absolute inset-0 w-full h-full -rotate-90 pointer-events-none">
                      <circle
                        cx="50%"
                        cy="50%"
                        r="26"
                        fill="transparent"
                        stroke="rgba(6, 182, 212, 0.2)"
                        strokeWidth="5"
                      />
                      <circle
                        cx="50%"
                        cy="50%"
                        r="26"
                        fill="transparent"
                        stroke="#06b6d4"
                        strokeWidth="5"
                        strokeDasharray={2 * Math.PI * 26}
                        strokeDashoffset={cdDashOffset}
                        strokeLinecap="round"
                      />
                    </svg>
                    <span className="font-mono font-black text-sm sm:text-base text-cyan-300 z-10 tabular-nums">
                      {heavyCooldown.toFixed(1)}s
                    </span>
                    <span className="text-[8px] font-bold uppercase text-slate-400 z-10">
                      RELOAD
                    </span>
                  </>
                ) : (
                  <>
                    <span className="text-xl sm:text-2xl font-black text-cyan-200">⚔</span>
                    <span className="text-[10px] sm:text-xs font-black uppercase tracking-wider text-white">
                      HEAVY
                    </span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Pause Modal Overlay */}
        {isPaused && (
          <div className="absolute inset-0 z-40 bg-black/85 flex flex-col items-center justify-center p-6 backdrop-blur-md">
            <div className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-2xl p-6 text-center space-y-4 shadow-2xl">
              <h3 className="text-2xl font-bold font-cinzel text-white">
                {getTranslation(lang, 'paused')}
              </h3>
              <p className="text-xs text-slate-400">
                {stage.enemyName} · {getTranslation(lang, stage.nameKey as never)}
              </p>

              <div className="space-y-2 pt-2">
                <button
                  onClick={() => setIsPaused(false)}
                  className="w-full py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl font-bold text-xs shadow transition-colors flex items-center justify-center gap-2"
                >
                  <Play className="w-4 h-4" />
                  <span>{getTranslation(lang, 'resume')}</span>
                </button>
                <button
                  onClick={onExit}
                  className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-semibold text-xs transition-colors flex items-center justify-center gap-2"
                >
                  <LogOut className="w-4 h-4" />
                  <span>{getTranslation(lang, 'forfeit')}</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Desktop Controls Tip Banner */}
      <div className="text-[11px] text-slate-500 text-center mt-2 px-4 max-w-xl hidden md:block">
        {getTranslation(lang, 'controlsTip')}
      </div>
    </div>
  );
};
