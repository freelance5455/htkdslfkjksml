/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Trophy, Skull, Coins, Sparkles, Video, RotateCcw, ArrowRight, ShieldCheck } from 'lucide-react';
import { CombatOutcome, StageConfig, Language } from '../types/game';
import { getTranslation } from '../utils/i18n';
import { audio } from '../utils/audio';

interface CombatResultModalProps {
  outcome: CombatOutcome;
  stage: StageConfig;
  earnedCoins: number;
  earnedXp: number;
  maxCombo: number;
  lang: Language;
  onWatchAdToRevive: () => void;
  onWatchAdToDoubleCoins: () => void;
  hasDoubledCoins: boolean;
  onNextStage: () => void;
  onRetry: () => void;
  onExitToMenu: () => void;
}

export const CombatResultModal: React.FC<CombatResultModalProps> = ({
  outcome,
  stage,
  earnedCoins,
  earnedXp,
  maxCombo,
  lang,
  onWatchAdToRevive,
  onWatchAdToDoubleCoins,
  hasDoubledCoins,
  onNextStage,
  onRetry,
  onExitToMenu
}) => {
  const isVictory = outcome === 'VICTORY';
  const effectiveCoins = hasDoubledCoins ? earnedCoins * 2 : earnedCoins;

  return (
    <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4 backdrop-blur-lg">
      <div
        className={`w-full max-w-md bg-slate-950 border rounded-3xl p-6 sm:p-8 shadow-2xl flex flex-col items-center text-center space-y-6 ${
          isVictory
            ? 'border-cyan-500/50 shadow-glow-cyan'
            : 'border-red-500/50 shadow-glow-crimson'
        }`}
      >
        {/* Outcome Emblem */}
        <div
          className={`w-20 h-20 rounded-3xl flex items-center justify-center p-1 border shadow-xl ${
            isVictory
              ? 'bg-gradient-to-tr from-cyan-600 via-indigo-600 to-teal-500 border-cyan-300 text-white animate-bounce'
              : 'bg-gradient-to-tr from-red-700 to-rose-900 border-red-400 text-red-200'
          }`}
        >
          {isVictory ? <Trophy className="w-10 h-10" /> : <Skull className="w-10 h-10" />}
        </div>

        {/* Title */}
        <div className="space-y-1">
          <h2
            className={`text-3xl font-black font-cinzel ${
              isVictory ? 'text-white text-glow-cyan' : 'text-red-400 text-glow-crimson'
            }`}
          >
            {getTranslation(lang, isVictory ? 'victory' : 'defeat')}
          </h2>
          <p className="text-xs text-slate-400">
            {stage.enemyName} · {getTranslation(lang, stage.nameKey as never)}
          </p>
        </div>

        {/* Spoils Summary Matrix */}
        <div className="w-full bg-slate-900/80 border border-slate-800 rounded-2xl p-4 grid grid-cols-3 gap-2 text-center">
          <div>
            <span className="text-[10px] text-slate-500 block uppercase font-bold">
              {getTranslation(lang, 'coins')}
            </span>
            <div className="flex items-center justify-center gap-1 mt-1 text-amber-300 font-bold font-mono text-sm sm:text-base">
              <Coins className="w-3.5 h-3.5" />
              <span>+{effectiveCoins}</span>
            </div>
          </div>

          <div>
            <span className="text-[10px] text-slate-500 block uppercase font-bold">XP</span>
            <span className="text-indigo-300 font-bold font-mono text-sm sm:text-base block mt-1">
              +{earnedXp}
            </span>
          </div>

          <div>
            <span className="text-[10px] text-slate-500 block uppercase font-bold">Max Combo</span>
            <span className="text-cyan-300 font-bold font-mono text-sm sm:text-base block mt-1">
              {maxCombo} Hits
            </span>
          </div>
        </div>

        {/* MONETIZATION ACTION SLOTS (Reworded Ads) */}
        <div className="w-full space-y-2.5">
          {!isVictory ? (
            /* Defeat Option: Watch 30s Ad to Revive */
            <button
              onClick={() => {
                audio.playClick();
                onWatchAdToRevive();
              }}
              className="w-full py-3.5 px-4 bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white rounded-2xl font-bold text-xs shadow-lg shadow-emerald-600/30 transition-transform active:scale-95 flex items-center justify-center gap-2 group"
            >
              <Video className="w-4 h-4 text-emerald-200 group-hover:scale-110 transition-transform" />
              <span>{getTranslation(lang, 'watchAdToRevive')}</span>
            </button>
          ) : !hasDoubledCoins ? (
            /* Victory Option: Watch 30s Ad to Double Coins (2x) */
            <button
              onClick={() => {
                audio.playClick();
                onWatchAdToDoubleCoins();
              }}
              className="w-full py-3.5 px-4 bg-gradient-to-r from-amber-600 via-orange-600 to-amber-500 hover:from-amber-500 hover:to-orange-500 text-white rounded-2xl font-bold text-xs shadow-lg shadow-amber-600/30 transition-transform active:scale-95 flex items-center justify-center gap-2 group animate-pulse"
            >
              <Sparkles className="w-4 h-4 text-amber-200 group-hover:scale-110 transition-transform" />
              <span>{getTranslation(lang, 'watchAdToDouble')}</span>
            </button>
          ) : (
            <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl py-2 px-3 text-xs text-amber-300 font-semibold flex items-center justify-center gap-2">
              <ShieldCheck className="w-4 h-4 text-amber-400" />
              <span>2x Spoils Bonus Claimed!</span>
            </div>
          )}

          {/* Standard Navigation Options */}
          <div className="flex gap-2 w-full pt-1">
            {isVictory && stage.id < 10 ? (
              <button
                onClick={() => {
                  audio.playClick();
                  onNextStage();
                }}
                className="flex-1 py-3 bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white rounded-xl font-bold text-xs transition-transform active:scale-95 flex items-center justify-center gap-1.5 shadow"
              >
                <span>Next Stage</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            ) : (
              <button
                onClick={() => {
                  audio.playClick();
                  onRetry();
                }}
                className="flex-1 py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl font-bold text-xs transition-colors flex items-center justify-center gap-1.5"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>{getTranslation(lang, 'restart')}</span>
              </button>
            )}

            <button
              onClick={() => {
                audio.playClick();
                onExitToMenu();
              }}
              className="flex-1 py-3 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 rounded-xl font-semibold text-xs transition-colors"
            >
              {getTranslation(lang, 'stageSelect')}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
