/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ExternalLink, X, ShieldCheck } from 'lucide-react';
import { Language } from '../types/game';
import { getTranslation } from '../utils/i18n';

interface BannerAdProps {
  lang: Language;
}

export const BannerAd: React.FC<BannerAdProps> = ({ lang }) => {
  const [isVisible, setIsVisible] = useState(true);

  if (!isVisible) {
    return (
      <div className="w-full flex justify-center py-1">
        <button
          onClick={() => setIsVisible(true)}
          className="text-[10px] text-slate-500 hover:text-slate-400 underline"
        >
          {getTranslation(lang, 'bannerAdLabel')}
        </button>
      </div>
    );
  }

  return (
    <aside
      aria-label="Sponsored advertisement"
      className="w-full max-w-2xl mx-auto px-2 py-1 relative z-20 shrink-0"
    >
      <div className="bg-slate-900/95 border border-slate-700/80 rounded-lg p-2 flex items-center justify-between gap-3 shadow-lg shadow-black/40">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-9 h-9 rounded bg-gradient-to-br from-indigo-600 to-purple-800 flex items-center justify-center shrink-0 border border-indigo-400/30">
            <ShieldCheck className="w-5 h-5 text-indigo-200" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <span className="text-[9px] uppercase tracking-wider font-bold bg-amber-500/20 text-amber-300 px-1 py-0.5 rounded border border-amber-500/30">
                AD
              </span>
              <span className="text-xs font-semibold text-slate-200 truncate">
                Raid of Shadows: Awakening
              </span>
            </div>
            <p className="text-[11px] text-slate-400 truncate">
              Play free on Google Play · Over 10M+ downloads
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <a
            href="https://play.google.com"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1 px-3 py-1.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white rounded text-xs font-semibold shadow transition-transform active:scale-95 whitespace-nowrap"
          >
            <span>Install</span>
            <ExternalLink className="w-3 h-3" />
          </a>
          <button
            onClick={() => setIsVisible(false)}
            title="Dismiss Banner Ad"
            className="p-1 text-slate-400 hover:text-slate-200 rounded"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </aside>
  );
};
