/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { X, ExternalLink, Sparkles } from 'lucide-react';
import { Language } from '../types/game';
import { getTranslation } from '../utils/i18n';

interface InterstitialAdModalProps {
  lang: Language;
  onAdClosed: () => void;
}

export const InterstitialAdModal: React.FC<InterstitialAdModalProps> = ({
  lang,
  onAdClosed
}) => {
  const [countdown, setCountdown] = useState(5);
  const [canSkip, setCanSkip] = useState(false);

  useEffect(() => {
    if (countdown <= 0) {
      setCanSkip(true);
      return;
    }
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setCanSkip(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [countdown]);

  return (
    <div className="fixed inset-0 z-50 bg-black/90 flex flex-col items-center justify-center p-4 backdrop-blur-lg">
      <div className="w-full max-w-lg bg-gradient-to-b from-slate-900 via-slate-950 to-black border border-slate-700/80 rounded-2xl overflow-hidden shadow-2xl relative">
        {/* Top bar with Skip button and ad tag */}
        <div className="p-4 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold uppercase bg-cyan-500/20 text-cyan-300 px-2 py-0.5 rounded border border-cyan-500/40">
              INTERSTITIAL AD
            </span>
            <span className="text-xs text-slate-400">
              {getTranslation(lang, 'interstitialTitle')}
            </span>
          </div>

          <div>
            {canSkip ? (
              <button
                onClick={onAdClosed}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-100 rounded-lg text-xs font-semibold border border-slate-600 transition-colors"
              >
                <span>{getTranslation(lang, 'skipAd')}</span>
                <X className="w-3.5 h-3.5" />
              </button>
            ) : (
              <div className="text-xs text-slate-400 font-mono tabular-nums bg-slate-800/80 px-2.5 py-1 rounded border border-slate-700">
                Skip in {countdown}s
              </div>
            )}
          </div>
        </div>

        {/* Ad Showcase Body */}
        <div className="p-6 text-center space-y-4">
          <div className="w-20 h-20 mx-auto rounded-3xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-cyan-500 p-1 shadow-xl shadow-indigo-500/20">
            <div className="w-full h-full bg-slate-950 rounded-[22px] flex items-center justify-center">
              <Sparkles className="w-9 h-9 text-cyan-400 animate-spin" />
            </div>
          </div>

          <div>
            <h3 className="text-2xl font-bold font-cinzel text-white text-glow-purple">
              VALOR & STEEL: SHADOW EMPIRE
            </h3>
            <p className="text-xs text-slate-400 mt-2 max-w-xs mx-auto leading-relaxed">
              Ascend the leaderboards in the #1 tactical mobile fighting RPG. Join millions of players worldwide today.
            </p>
          </div>

          <div className="pt-2">
            <a
              href="https://play.google.com"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 w-full py-3 bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white font-bold text-sm rounded-xl shadow-lg shadow-cyan-600/30 transition-transform active:scale-98"
            >
              <span>Install Free on Google Play</span>
              <ExternalLink className="w-4 h-4" />
            </a>
          </div>
        </div>

        {/* Footer info */}
        <div className="px-6 py-3 bg-slate-950/80 border-t border-slate-900 flex justify-between items-center text-[10px] text-slate-500">
          <span>Google Play Certified Partner</span>
          <button
            onClick={onAdClosed}
            className="hover:text-slate-400 underline"
          >
            Instant Continue
          </button>
        </div>
      </div>
    </div>
  );
};
