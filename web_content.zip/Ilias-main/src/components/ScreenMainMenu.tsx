/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Sword, 
  Shield, 
  Coins, 
  Lock, 
  Check, 
  Settings, 
  Volume2, 
  VolumeX, 
  ShieldCheck, 
  Play, 
  Zap, 
  Sparkles,
  ArrowRight,
  Flame,
  Crosshair,
  User,
  Cloud
} from 'lucide-react';
import { PlayerData, StageConfig, Weapon, Language } from '../types/game';
import { STAGES, WEAPONS } from '../utils/gameData';
import { getTranslation } from '../utils/i18n';
import { audio } from '../utils/audio';
import { BannerAd } from './BannerAd';
import { saveSecurePlayerData } from '../utils/antiCheat';

interface ScreenMainMenuProps {
  playerData: PlayerData;
  lang: Language;
  onSelectStage: (stage: StageConfig) => void;
  onOpenAntiCheat: () => void;
  onOpenSettings: () => void;
  onUpdatePlayerData: (data: PlayerData) => void;
}

export const ScreenMainMenu: React.FC<ScreenMainMenuProps> = ({
  playerData,
  lang,
  onSelectStage,
  onOpenAntiCheat,
  onOpenSettings,
  onUpdatePlayerData
}) => {
  const [activeTab, setActiveTab] = useState<'STAGES' | 'ARMORY'>('STAGES');

  // Equipped Weapon
  const equippedWeapon = WEAPONS.find((w) => w.id === playerData.equippedWeaponId) || WEAPONS[0];

  const handleEquipWeapon = (weapon: Weapon) => {
    audio.playClick();
    const updated: PlayerData = {
      ...playerData,
      equippedWeaponId: weapon.id
    };
    onUpdatePlayerData(saveSecurePlayerData(updated));
  };

  const handleUpgradeWeapon = (weapon: Weapon) => {
    const currentLvl = playerData.weaponLevels[weapon.id] || 1;
    const upgradeCost = Math.round(150 * Math.pow(1.5, currentLvl - 1));

    if (playerData.coins >= upgradeCost) {
      audio.playCooldownReady();
      const updated: PlayerData = {
        ...playerData,
        coins: playerData.coins - upgradeCost,
        weaponLevels: {
          ...playerData.weaponLevels,
          [weapon.id]: currentLvl + 1
        }
      };
      onUpdatePlayerData(saveSecurePlayerData(updated));
    } else {
      audio.playHitImpact(false);
    }
  };

  const handleUnlockWeapon = (weapon: Weapon) => {
    if (playerData.coins >= weapon.cost && !playerData.unlockedWeaponIds.includes(weapon.id)) {
      audio.playVictory();
      const updated: PlayerData = {
        ...playerData,
        coins: playerData.coins - weapon.cost,
        unlockedWeaponIds: [...playerData.unlockedWeaponIds, weapon.id],
        equippedWeaponId: weapon.id,
        weaponLevels: {
          ...playerData.weaponLevels,
          [weapon.id]: 1
        }
      };
      onUpdatePlayerData(saveSecurePlayerData(updated));
    } else {
      audio.playHitImpact(false);
    }
  };

  return (
    <div className="relative min-h-screen w-full flex flex-col bg-[#05070f] text-slate-100 overflow-x-hidden">
      {/* Background artwork */}
      <div className="fixed inset-0 z-0 opacity-25 mix-blend-screen pointer-events-none">
        <img
          src="/src/assets/images/abyss_title_art_1793472337997.jpg"
          alt="Abyss artwork"
          className="w-full h-full object-cover filter blur-[2px] brightness-70"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#05070f]/90 via-[#05070f]/80 to-[#05070f]" />
      </div>

      {/* TOP BAR CONTRACT: 3 Zones */}
      <header className="relative z-20 w-full bg-slate-950/80 backdrop-blur-md border-b border-slate-800/80 px-4 sm:px-6 py-3 flex items-center justify-between gap-4">
        {/* Zone 1: Profile & Save Mode */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 to-indigo-600 flex items-center justify-center p-0.5 border border-cyan-400/40 shadow-glow-cyan">
            {playerData.authType === 'cloud' ? (
              <Cloud className="w-5 h-5 text-white" />
            ) : (
              <User className="w-5 h-5 text-white" />
            )}
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-1.5">
              <span className="text-sm font-bold text-white truncate max-w-[120px] sm:max-w-[160px]">
                {playerData.displayName}
              </span>
              <span className={`text-[9px] uppercase font-bold px-1.5 py-0.2 rounded border ${
                playerData.authType === 'cloud'
                  ? 'bg-blue-500/20 text-blue-300 border-blue-500/30'
                  : 'bg-slate-800 text-slate-400 border-slate-700'
              }`}>
                {playerData.authType}
              </span>
            </div>
            <div className="text-[11px] text-slate-400 flex items-center gap-2">
              <span>{getTranslation(lang, 'level')} {playerData.level}</span>
              <span>·</span>
              <span className="text-cyan-400 font-medium">Stage {playerData.currentStage}/10</span>
            </div>
          </div>
        </div>

        {/* Zone 2: Echo Coins Counter & Anti-Cheat Badge */}
        <div className="flex items-center gap-2 sm:gap-4 shrink-0">
          {/* Echo Coins */}
          <div className="flex items-center gap-1.5 bg-slate-900/90 border border-amber-500/30 px-3 py-1.5 rounded-xl shadow-inner">
            <Coins className="w-4 h-4 text-amber-400" />
            <span className="text-xs sm:text-sm font-bold font-mono text-amber-200 tabular-nums">
              {playerData.coins.toLocaleString()}
            </span>
          </div>

          {/* Anti-Cheat Status Button */}
          <button
            onClick={() => {
              audio.playClick();
              onOpenAntiCheat();
            }}
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-emerald-950/60 hover:bg-emerald-900/70 border border-emerald-500/40 rounded-xl text-emerald-300 text-xs font-semibold transition-colors"
            title="Inspect Encrypted Anti-Cheat Status"
          >
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span className="hidden sm:inline">Anti-Cheat</span>
          </button>
        </div>

        {/* Zone 3: Settings Action */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => {
              audio.playClick();
              onOpenSettings();
            }}
            className="p-2 bg-slate-900 hover:bg-slate-800 border border-slate-700/80 rounded-xl text-slate-300 hover:text-white transition-colors"
            title="Settings"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* SUB-NAV TABS: Stages vs Armory */}
      <div className="relative z-10 w-full max-w-4xl mx-auto px-4 pt-4 pb-2 flex items-center justify-center">
        <div className="bg-slate-900/90 p-1 rounded-2xl border border-slate-800 flex items-center gap-1 w-full max-w-sm">
          <button
            onClick={() => {
              audio.playClick();
              setActiveTab('STAGES');
            }}
            className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-2 ${
              activeTab === 'STAGES'
                ? 'bg-gradient-to-r from-cyan-600 to-indigo-600 text-white shadow-lg shadow-cyan-600/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Sword className="w-3.5 h-3.5" />
            <span>{getTranslation(lang, 'stageSelect')}</span>
          </button>

          <button
            onClick={() => {
              audio.playClick();
              setActiveTab('ARMORY');
            }}
            className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-2 ${
              activeTab === 'ARMORY'
                ? 'bg-gradient-to-r from-cyan-600 to-indigo-600 text-white shadow-lg shadow-cyan-600/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            <span>{getTranslation(lang, 'armory')}</span>
          </button>
        </div>
      </div>

      {/* MAIN CONTENT AREA */}
      <main className="relative z-10 flex-1 w-full max-w-5xl mx-auto px-4 py-3 pb-24">
        {activeTab === 'STAGES' ? (
          /* 10 SEQUENTIAL COMBAT STAGES */
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-black font-cinzel text-white text-glow-cyan">
                  {getTranslation(lang, 'stageSelect')}
                </h2>
                <p className="text-xs text-slate-400">
                  Defeat sequential abyss sentinels. Stage 1 begins against the Guardian of the Abyss.
                </p>
              </div>
              <span className="text-xs font-mono text-cyan-400 bg-cyan-950/60 border border-cyan-800/60 px-2.5 py-1 rounded-lg">
                Current: Stage {playerData.currentStage} / 10
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-3.5">
              {STAGES.map((st) => {
                const isUnlocked = st.id <= playerData.currentStage;
                const isCleared = st.id < playerData.currentStage;
                const isCurrent = st.id === playerData.currentStage;

                return (
                  <div
                    key={st.id}
                    className={`rounded-2xl border p-4 transition-all relative overflow-hidden flex flex-col justify-between gap-3 ${
                      isCurrent
                        ? 'bg-gradient-to-br from-slate-900 via-slate-950 to-cyan-950/30 border-cyan-500/60 shadow-glow-cyan'
                        : isCleared
                        ? 'bg-slate-900/60 border-slate-800 text-slate-300'
                        : 'bg-slate-950/60 border-slate-900 opacity-60'
                    }`}
                  >
                    {/* Top Row: Stage #, Enemy Title & Cleared Badge */}
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2.5">
                        <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-cinzel font-black text-sm border ${
                          isCurrent
                            ? 'bg-cyan-600 border-cyan-400 text-white'
                            : isCleared
                            ? 'bg-slate-800 border-slate-700 text-slate-300'
                            : 'bg-slate-950 border-slate-900 text-slate-600'
                        }`}>
                          {st.id}
                        </div>
                        <div>
                          <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                            <span>{st.enemyName}</span>
                            {st.id === 1 && (
                              <span className="text-[9px] bg-red-500/20 text-red-300 border border-red-500/30 px-1 py-0.2 rounded font-mono">
                                BOSS
                              </span>
                            )}
                          </h4>
                          <span className="text-[11px] text-slate-400">
                            {getTranslation(lang, st.nameKey as never)}
                          </span>
                        </div>
                      </div>

                      {isCleared && (
                        <div className="flex items-center gap-1 text-[11px] font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2 py-0.5 rounded-full">
                          <Check className="w-3 h-3" />
                          <span>CLEARED</span>
                        </div>
                      )}
                    </div>

                    {/* Middle Stats */}
                    <div className="grid grid-cols-3 gap-2 text-[11px] py-1 border-y border-slate-800/60">
                      <div>
                        <span className="text-slate-500 block">Enemy HP</span>
                        <strong className="text-red-300 font-mono">{st.enemyHp}</strong>
                      </div>
                      <div>
                        <span className="text-slate-500 block">Reward</span>
                        <strong className="text-amber-300 font-mono">+{st.coinReward} Coins</strong>
                      </div>
                      <div>
                        <span className="text-slate-500 block">XP</span>
                        <strong className="text-indigo-300 font-mono">+{st.xpReward} XP</strong>
                      </div>
                    </div>

                    {/* Bottom Action */}
                    <div className="flex items-center justify-between pt-1">
                      <span className="text-[11px] text-slate-500 italic">
                        {getTranslation(lang, st.subtitleKey as never)}
                      </span>

                      {isUnlocked ? (
                        <button
                          onClick={() => {
                            audio.playClick();
                            onSelectStage(st);
                          }}
                          className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold shadow transition-all active:scale-95 ${
                            isCurrent
                              ? 'bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white shadow-glow-cyan animate-pulse'
                              : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                          }`}
                        >
                          <Play className="w-3.5 h-3.5 fill-current" />
                          <span>{getTranslation(lang, 'battle')}</span>
                        </button>
                      ) : (
                        <div className="flex items-center gap-1 text-xs text-slate-600">
                          <Lock className="w-3.5 h-3.5" />
                          <span>{getTranslation(lang, 'locked')}</span>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ) : (
          /* SHADOW ARMORY & WEAPON UPGRADE */
          <div className="space-y-4">
            <div>
              <h2 className="text-xl font-black font-cinzel text-white text-glow-purple">
                {getTranslation(lang, 'armory')}
              </h2>
              <p className="text-xs text-slate-400">
                Primary weapon: Heavy Sword with massive damage and 5-second cooldown. Upgrade and unlock shadow blades using Echo Coins.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {WEAPONS.map((weapon) => {
                const isUnlocked = playerData.unlockedWeaponIds.includes(weapon.id);
                const isEquipped = playerData.equippedWeaponId === weapon.id;
                const level = playerData.weaponLevels[weapon.id] || 1;
                const upgradeCost = Math.round(150 * Math.pow(1.5, level - 1));
                const canAffordUpgrade = playerData.coins >= upgradeCost;
                const canAffordUnlock = playerData.coins >= weapon.cost;

                return (
                  <div
                    key={weapon.id}
                    className={`rounded-2xl border p-5 flex flex-col justify-between gap-4 transition-all relative ${
                      isEquipped
                        ? 'bg-gradient-to-br from-slate-900 via-slate-950 to-indigo-950/40 border-cyan-400 shadow-glow-cyan'
                        : isUnlocked
                        ? 'bg-slate-900/70 border-slate-800'
                        : 'bg-slate-950/80 border-slate-900 opacity-80'
                    }`}
                  >
                    {/* Header */}
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <div
                          className="w-12 h-12 rounded-2xl flex items-center justify-center text-white border shadow-lg"
                          style={{
                            backgroundColor: `${weapon.color}20`,
                            borderColor: `${weapon.color}80`
                          }}
                        >
                          <Sword className="w-6 h-6" style={{ color: weapon.color }} />
                        </div>
                        <div>
                          <h4 className="text-base font-bold text-white flex items-center gap-2">
                            <span>{getTranslation(lang, weapon.nameKey as never)}</span>
                            {isUnlocked && (
                              <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950/60 border border-cyan-800/40 px-1.5 py-0.2 rounded">
                                Lvl {level}
                              </span>
                            )}
                          </h4>
                          <span className="text-[11px] text-slate-400">
                            {weapon.id === 'heavy_sword'
                              ? 'Primary Heavy Greatsword · 5s Cooldown'
                              : 'Martial Shadow Armory'}
                          </span>
                        </div>
                      </div>

                      {isEquipped && (
                        <span className="text-[10px] font-bold uppercase bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 px-2 py-0.5 rounded-full">
                          {getTranslation(lang, 'equipped')}
                        </span>
                      )}
                    </div>

                    {/* Weapon Description */}
                    <p className="text-xs text-slate-400 leading-relaxed">
                      {getTranslation(lang, weapon.descriptionKey as never)}
                    </p>

                    {/* Stats Matrix */}
                    <div className="grid grid-cols-3 gap-2 text-xs py-2 bg-slate-950/60 rounded-xl px-3 border border-slate-800/60">
                      <div>
                        <span className="text-slate-500 block text-[10px]">Base Damage</span>
                        <strong className="text-white font-mono">
                          {weapon.damage + (level - 1) * 6}
                        </strong>
                      </div>
                      <div>
                        <span className="text-slate-500 block text-[10px]">Heavy Damage</span>
                        <strong className="text-cyan-300 font-mono">
                          {weapon.heavyDamage + (level - 1) * 14}
                        </strong>
                      </div>
                      <div>
                        <span className="text-slate-500 block text-[10px]">Cooldown</span>
                        <strong className="text-amber-300 font-mono">
                          {weapon.heavyCooldownSeconds.toFixed(1)}s
                        </strong>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-between gap-2 pt-1">
                      {isUnlocked ? (
                        <>
                          {!isEquipped && (
                            <button
                              onClick={() => handleEquipWeapon(weapon)}
                              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-bold transition-all active:scale-95"
                            >
                              {getTranslation(lang, 'equip' as never) || 'Equip'}
                            </button>
                          )}

                          <button
                            onClick={() => handleUpgradeWeapon(weapon)}
                            disabled={!canAffordUpgrade}
                            className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all active:scale-95 ${
                              canAffordUpgrade
                                ? 'bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white shadow'
                                : 'bg-slate-800/50 text-slate-500 border border-slate-800 cursor-not-allowed'
                            }`}
                          >
                            <Zap className="w-3.5 h-3.5" />
                            <span>Upgrade ({upgradeCost} Coins)</span>
                          </button>
                        </>
                      ) : (
                        <button
                          onClick={() => handleUnlockWeapon(weapon)}
                          disabled={!canAffordUnlock}
                          className={`w-full py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all active:scale-95 ${
                            canAffordUnlock
                              ? 'bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white shadow-lg shadow-purple-600/30'
                              : 'bg-slate-900 text-slate-500 border border-slate-800 cursor-not-allowed'
                          }`}
                        >
                          <Lock className="w-3.5 h-3.5" />
                          <span>Unlock Weapon ({weapon.cost} Coins)</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </main>

      {/* BANNER AD: Displayed strictly on menu screens, fully hidden during gameplay (Req #4) */}
      <footer className="fixed bottom-0 left-0 right-0 z-30 bg-slate-950/95 border-t border-slate-800/80 backdrop-blur-md">
        <BannerAd lang={lang} />
      </footer>
    </div>
  );
};
