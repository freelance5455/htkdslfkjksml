/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Settings, 
  Volume2, 
  VolumeX, 
  Music, 
  Globe, 
  Cloud, 
  User, 
  RotateCcw, 
  Check, 
  ShieldCheck, 
  X,
  Smartphone
} from 'lucide-react';
import { Language, PlayerData } from '../types/game';
import { getTranslation } from '../utils/i18n';
import { audio } from '../utils/audio';
import { createDefaultPlayerData, saveSecurePlayerData } from '../utils/antiCheat';

interface SettingsModalProps {
  lang: Language;
  playerData: PlayerData;
  onLanguageChange: (lang: Language) => void;
  onDataUpdated: (data: PlayerData) => void;
  onOpenAntiCheat: () => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  lang,
  playerData,
  onLanguageChange,
  onDataUpdated,
  onOpenAntiCheat,
  onClose
}) => {
  const [soundEnabled, setSoundEnabled] = useState(!audio.isSoundMuted());
  const [musicEnabled, setMusicEnabled] = useState(!audio.isMusicMuted());
  const [confirmReset, setConfirmReset] = useState(false);
  const [isLinkingCloud, setIsLinkingCloud] = useState(false);

  const toggleSound = () => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    audio.setSoundMuted(!next);
    if (next) audio.playClick();
  };

  const toggleMusic = () => {
    const next = !musicEnabled;
    setMusicEnabled(next);
    audio.setMusicMuted(!next);
  };

  const handleLinkGoogle = () => {
    audio.playClick();
    setIsLinkingCloud(true);
    setTimeout(() => {
      setIsLinkingCloud(false);
      const updated: PlayerData = {
        ...playerData,
        authType: 'cloud',
        displayName: 'Google_Cloud_Warrior',
        lastCloudSync: new Date().toISOString()
      };
      onDataUpdated(saveSecurePlayerData(updated));
    }, 1000);
  };

  const handleReset = () => {
    audio.playDefeat();
    const fresh = createDefaultPlayerData('guest');
    onDataUpdated(fresh);
    setConfirmReset(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-4 backdrop-blur-md">
      <div className="w-full max-w-md bg-slate-950 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/80">
          <div className="flex items-center gap-2 text-white font-bold text-sm">
            <Settings className="w-4 h-4 text-cyan-400" />
            <span>{getTranslation(lang, 'settings')}</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white rounded"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4 text-xs">
          {/* Audio Settings */}
          <div className="space-y-2">
            <span className="font-semibold text-slate-400 uppercase tracking-wider block text-[10px]">
              Audio Controls
            </span>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={toggleSound}
                className={`p-3 rounded-xl border flex items-center justify-between transition-colors ${
                  soundEnabled
                    ? 'bg-slate-900 border-cyan-500/40 text-cyan-300'
                    : 'bg-slate-950 border-slate-800 text-slate-500'
                }`}
              >
                <div className="flex items-center gap-2">
                  {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
                  <span>{getTranslation(lang, 'soundFx')}</span>
                </div>
                <div className={`w-3.5 h-3.5 rounded-full ${soundEnabled ? 'bg-cyan-400' : 'bg-slate-700'}`} />
              </button>

              <button
                onClick={toggleMusic}
                className={`p-3 rounded-xl border flex items-center justify-between transition-colors ${
                  musicEnabled
                    ? 'bg-slate-900 border-purple-500/40 text-purple-300'
                    : 'bg-slate-950 border-slate-800 text-slate-500'
                }`}
              >
                <div className="flex items-center gap-2">
                  <Music className="w-4 h-4" />
                  <span>{getTranslation(lang, 'music')}</span>
                </div>
                <div className={`w-3.5 h-3.5 rounded-full ${musicEnabled ? 'bg-purple-400' : 'bg-slate-700'}`} />
              </button>
            </div>
          </div>

          {/* Language Selection */}
          <div className="space-y-2">
            <span className="font-semibold text-slate-400 uppercase tracking-wider block text-[10px]">
              {getTranslation(lang, 'language')}
            </span>
            <div className="grid grid-cols-3 gap-2">
              {[
                { code: 'ar', label: 'العربية' },
                { code: 'en', label: 'English' },
                { code: 'es', label: 'Español' }
              ].map((item) => (
                <button
                  key={item.code}
                  onClick={() => {
                    audio.playClick();
                    onLanguageChange(item.code as Language);
                  }}
                  className={`py-2 px-3 rounded-xl border text-center font-bold text-xs transition-colors ${
                    lang === item.code
                      ? 'bg-cyan-950 border-cyan-400 text-cyan-200'
                      : 'bg-slate-900/60 hover:bg-slate-900 border-slate-800 text-slate-400'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          {/* Account & Save Storage */}
          <div className="space-y-2">
            <span className="font-semibold text-slate-400 uppercase tracking-wider block text-[10px]">
              {getTranslation(lang, 'storageInfo')}
            </span>
            <div className="p-3 bg-slate-900/80 border border-slate-800 rounded-xl space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-slate-200 font-medium">
                  {playerData.authType === 'cloud' ? (
                    <Cloud className="w-4 h-4 text-blue-400" />
                  ) : (
                    <User className="w-4 h-4 text-slate-400" />
                  )}
                  <span>
                    {playerData.authType === 'cloud'
                      ? getTranslation(lang, 'cloudSave')
                      : getTranslation(lang, 'playAsGuest')}
                  </span>
                </div>
                <span className="font-mono text-[10px] text-slate-400">
                  {playerData.userId}
                </span>
              </div>

              {playerData.authType === 'guest' && (
                <button
                  onClick={handleLinkGoogle}
                  disabled={isLinkingCloud}
                  className="w-full py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg transition-colors flex items-center justify-center gap-2"
                >
                  <Cloud className="w-3.5 h-3.5" />
                  <span>{isLinkingCloud ? 'Syncing...' : getTranslation(lang, 'linkGoogleAccount')}</span>
                </button>
              )}
            </div>
          </div>

          {/* Anti-Cheat & Android APK Target */}
          <div className="p-3 bg-slate-900/40 border border-slate-800 rounded-xl flex items-center justify-between">
            <div className="flex items-center gap-2 text-slate-300">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Anti-Cheat Status: Verified</span>
            </div>
            <button
              onClick={() => {
                onClose();
                onOpenAntiCheat();
              }}
              className="text-cyan-400 hover:text-cyan-300 underline font-semibold text-[11px]"
            >
              Inspect
            </button>
          </div>

          {/* Reset Game Data */}
          <div className="pt-2 border-t border-slate-800/80">
            {!confirmReset ? (
              <button
                onClick={() => setConfirmReset(true)}
                className="w-full py-2 text-red-400 hover:text-red-300 bg-red-950/20 hover:bg-red-950/40 border border-red-900/30 rounded-xl font-semibold transition-colors flex items-center justify-center gap-2"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>{getTranslation(lang, 'resetProgress')}</span>
              </button>
            ) : (
              <div className="space-y-2 bg-red-950/40 border border-red-800/60 p-3 rounded-xl text-center">
                <p className="text-red-200 font-medium">
                  {getTranslation(lang, 'resetConfirm')}
                </p>
                <div className="flex gap-2">
                  <button
                    onClick={handleReset}
                    className="flex-1 py-1.5 bg-red-600 hover:bg-red-500 text-white font-bold rounded-lg"
                  >
                    Confirm Reset
                  </button>
                  <button
                    onClick={() => setConfirmReset(false)}
                    className="flex-1 py-1.5 bg-slate-800 text-slate-300 rounded-lg"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
