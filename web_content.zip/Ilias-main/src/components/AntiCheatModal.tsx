/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { ShieldCheck, ShieldAlert, Bug, RefreshCw, Smartphone, Key, Lock, CheckCircle2 } from 'lucide-react';
import { PlayerData, Language } from '../types/game';
import { 
  verifySaveIntegrity, 
  simulateMemoryTamper, 
  loadSecurePlayerData, 
  subscribeToAntiCheatLogs, 
  AntiCheatLogEntry, 
  computeSaveSignature 
} from '../utils/antiCheat';
import { getTranslation } from '../utils/i18n';
import { audio } from '../utils/audio';

interface AntiCheatModalProps {
  playerData: PlayerData;
  lang: Language;
  onDataUpdated: (data: PlayerData) => void;
  onClose: () => void;
}

export const AntiCheatModal: React.FC<AntiCheatModalProps> = ({
  playerData,
  lang,
  onDataUpdated,
  onClose
}) => {
  const [logs, setLogs] = useState<AntiCheatLogEntry[]>([]);
  const [tamperAlert, setTamperAlert] = useState<string | null>(null);

  useEffect(() => {
    const unsubscribe = subscribeToAntiCheatLogs((newLogs) => {
      setLogs([...newLogs]);
    });
    return () => unsubscribe();
  }, []);

  const integrity = verifySaveIntegrity(playerData);
  const currentExpectedHash = computeSaveSignature(playerData);

  const handleSimulateTamper = () => {
    audio.playHitImpact(true);
    // Maliciously inject 999,999 coins into localStorage without calculating cryptographic signature
    simulateMemoryTamper(999999);
    
    // Now trigger game load validation
    const check = loadSecurePlayerData();
    if (check.isTampered) {
      setTamperAlert(check.errorNotice || 'Memory integrity violation detected!');
      onDataUpdated(check.data);
    }
  };

  const handleRestoreCheckpoint = () => {
    audio.playClick();
    const result = loadSecurePlayerData();
    setTamperAlert(null);
    onDataUpdated(result.data);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-3 sm:p-6 backdrop-blur-md overflow-y-auto">
      <div className="w-full max-w-2xl bg-slate-950 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-auto flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="bg-slate-900/90 p-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${integrity.isValid ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/30' : 'bg-red-500/10 text-red-400 border border-red-500/30'}`}>
              {integrity.isValid ? <ShieldCheck className="w-5 h-5" /> : <ShieldAlert className="w-5 h-5" />}
            </div>
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <span>{getTranslation(lang, 'antiCheatTitle')}</span>
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded uppercase font-bold ${integrity.isValid ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-red-500/20 text-red-300 border border-red-500/30'}`}>
                  {integrity.isValid ? 'SECURE' : 'COMPROMISED'}
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                PlayerPrefs cryptographic hash validation & tamper protection
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white px-2 py-1 text-sm font-semibold"
          >
            {getTranslation(lang, 'close')}
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-5 space-y-4 overflow-y-auto">
          {/* Tamper Alert Notice */}
          {tamperAlert && (
            <div className="bg-red-950/60 border border-red-700/60 rounded-xl p-3.5 text-xs text-red-200 flex items-start gap-3">
              <ShieldAlert className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <p className="font-bold">{getTranslation(lang, 'tamperDetected')}</p>
                <p>{tamperAlert}</p>
                <p className="text-[11px] text-red-300">{getTranslation(lang, 'tamperWarning')}</p>
              </div>
            </div>
          )}

          {/* Cryptographic Hash Verification Box */}
          <div className="bg-slate-900/70 border border-slate-800 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-1.5 text-slate-300 font-semibold">
                <Lock className="w-4 h-4 text-cyan-400" />
                <span>HMAC Signature Protocol</span>
              </div>
              <span className="text-[11px] text-emerald-400 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Active Protection</span>
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800/80">
                <span className="text-[11px] text-slate-400 block mb-1">Stored Security Hash:</span>
                <span className="font-mono text-cyan-300 text-[11px] break-all">
                  {playerData.securityHash || 'None'}
                </span>
              </div>
              <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800/80">
                <span className="text-[11px] text-slate-400 block mb-1">Computed Hash:</span>
                <span className="font-mono text-indigo-300 text-[11px] break-all">
                  {currentExpectedHash}
                </span>
              </div>
            </div>

            <div className="text-[11px] text-slate-400 flex flex-wrap gap-x-4 gap-y-1 pt-1 border-t border-slate-800/50">
              <span>Verified Coins: <strong className="text-white">{playerData.coins}</strong></span>
              <span>Stage: <strong className="text-white">{playerData.currentStage}/10</strong></span>
              <span>Level: <strong className="text-white">{playerData.level}</strong></span>
              <span>Save Mode: <strong className="text-white uppercase">{playerData.authType}</strong></span>
            </div>
          </div>

          {/* Anti-Cheat Simulation & Test Actions */}
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={handleSimulateTamper}
              className="flex items-center gap-2 px-3.5 py-2 bg-red-950/80 hover:bg-red-900/90 text-red-200 border border-red-700/60 rounded-lg text-xs font-semibold transition-colors active:scale-95"
            >
              <Bug className="w-4 h-4 text-red-400" />
              <span>{getTranslation(lang, 'testMemoryTamper')}</span>
            </button>
            <button
              onClick={handleRestoreCheckpoint}
              className="flex items-center gap-2 px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-semibold transition-colors active:scale-95"
            >
              <RefreshCw className="w-4 h-4 text-cyan-400" />
              <span>{getTranslation(lang, 'restoreVerifiedSave')}</span>
            </button>
          </div>

          {/* Android APK 30MB Specs Breakdown */}
          <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-4 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-300 flex items-center gap-1.5">
                <Smartphone className="w-4 h-4 text-indigo-400" />
                <span>{getTranslation(lang, 'apkSpecsTitle')}</span>
              </span>
              <span className="text-[11px] text-emerald-400 font-mono font-bold">12.4 MB / 30 MB Max</span>
            </div>
            <p className="text-xs text-slate-400">
              {getTranslation(lang, 'apkTarget')} Assets are pre-compressed with Web Audio synthesis and procedural canvas rendering to maintain ultra-fast loading and instant offline launch on mobile devices.
            </p>
          </div>

          {/* Real-time Anti-Cheat Event Log */}
          <div className="space-y-2">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Security Audit Event Log
            </span>
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-3 h-36 overflow-y-auto font-mono text-[11px] space-y-1.5">
              {logs.length === 0 ? (
                <div className="text-slate-600 text-center py-4">No events logged yet</div>
              ) : (
                logs.map((log) => (
                  <div key={log.id} className="flex items-start gap-2 border-b border-slate-900 pb-1">
                    <span className="text-slate-500 shrink-0">[{log.timestamp}]</span>
                    <span className={`px-1 py-0.2 rounded text-[10px] font-bold shrink-0 ${
                      log.status === 'SAFE' 
                        ? 'bg-emerald-950 text-emerald-400' 
                        : log.status === 'ALERT'
                        ? 'bg-red-950 text-red-400'
                        : 'bg-cyan-950 text-cyan-400'
                    }`}>
                      {log.action}
                    </span>
                    <span className="text-slate-300 truncate">{log.details}</span>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
