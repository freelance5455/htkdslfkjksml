/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Cloud, User, ArrowLeft, CheckCircle2, ShieldCheck, Loader2 } from 'lucide-react';
import { Language, AuthType, PlayerData } from '../types/game';
import { getTranslation } from '../utils/i18n';
import { createDefaultPlayerData, saveSecurePlayerData } from '../utils/antiCheat';
import { audio } from '../utils/audio';

interface ScreenAuthProps {
  lang: Language;
  onAuthComplete: (data: PlayerData) => void;
  onBack: () => void;
}

export const ScreenAuth: React.FC<ScreenAuthProps> = ({
  lang,
  onAuthComplete,
  onBack
}) => {
  const [isSyncing, setIsSyncing] = useState(false);

  const handleSelectCloudSave = () => {
    audio.playClick();
    setIsSyncing(true);

    // Simulate real Google Cloud Play Games login & sync
    setTimeout(() => {
      setIsSyncing(false);
      const cloudData = createDefaultPlayerData('cloud', 'Shadow_Champion');
      onAuthComplete(cloudData);
    }, 1200);
  };

  const handleSelectGuest = () => {
    audio.playClick();
    const guestData = createDefaultPlayerData('guest');
    onAuthComplete(guestData);
  };

  return (
    <div className="relative min-h-screen w-full flex flex-col items-center justify-center p-4 sm:p-6 bg-[#04060c] overflow-hidden">
      {/* Background artwork */}
      <div className="absolute inset-0 z-0 opacity-30 mix-blend-screen pointer-events-none">
        <img
          src="/src/assets/images/abyss_arena_backdrop_1793472337348.jpg"
          alt="Abyss Arena backdrop"
          className="w-full h-full object-cover filter blur-[3px] brightness-75 scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#04060c] via-[#04060c]/80 to-transparent" />
      </div>

      <div className="relative z-10 w-full max-w-md bg-slate-950/90 border border-slate-800/90 rounded-3xl p-6 sm:p-8 backdrop-blur-xl shadow-2xl flex flex-col space-y-6">
        {/* Back and Title */}
        <div className="flex items-center justify-between">
          <button
            onClick={onBack}
            className="p-2 text-slate-400 hover:text-white rounded-xl bg-slate-900/60 border border-slate-800 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <span className="text-xs font-mono text-slate-500">Screen 2 of 3</span>
        </div>

        <div className="text-center space-y-2">
          <h2 className="text-2xl font-black font-cinzel text-white text-glow-purple">
            {getTranslation(lang, 'authentication')}
          </h2>
          <p className="text-xs text-slate-400">
            Choose how you wish to preserve your progression, coins, and armory in the abyss.
          </p>
        </div>

        {/* The Two Auth Options */}
        <div className="space-y-4">
          {/* OPTION 1: Google Cloud Save */}
          <button
            onClick={handleSelectCloudSave}
            disabled={isSyncing}
            className="w-full p-4 rounded-2xl bg-gradient-to-r from-blue-950/70 via-slate-900 to-indigo-950/70 hover:from-blue-900/80 hover:to-indigo-900/80 border border-blue-500/40 text-left transition-all active:scale-[0.98] shadow-lg group relative overflow-hidden"
          >
            <div className="flex items-start gap-3.5">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center shrink-0 shadow-lg shadow-blue-500/30 text-white">
                {isSyncing ? (
                  <Loader2 className="w-6 h-6 animate-spin" />
                ) : (
                  <Cloud className="w-6 h-6" />
                )}
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-bold text-white group-hover:text-blue-200 transition-colors">
                    {getTranslation(lang, 'cloudSave')}
                  </h3>
                  <span className="text-[9px] font-bold uppercase bg-blue-500/20 text-blue-300 px-1.5 py-0.5 rounded border border-blue-500/30">
                    CLOUD SYNC
                  </span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {getTranslation(lang, 'cloudSaveDesc')}
                </p>
              </div>
            </div>
          </button>

          {/* OPTION 2: Play as Guest */}
          <button
            onClick={handleSelectGuest}
            disabled={isSyncing}
            className="w-full p-4 rounded-2xl bg-slate-900/70 hover:bg-slate-900 border border-slate-800 text-left transition-all active:scale-[0.98] group"
          >
            <div className="flex items-start gap-3.5">
              <div className="w-12 h-12 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center shrink-0 text-slate-300 group-hover:text-cyan-400 transition-colors">
                <User className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-bold text-slate-200 group-hover:text-white transition-colors">
                    {getTranslation(lang, 'playAsGuest')}
                  </h3>
                  <span className="text-[9px] font-bold uppercase bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded border border-slate-700">
                    LOCAL ID
                  </span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {getTranslation(lang, 'playAsGuestDesc')}
                </p>
              </div>
            </div>
          </button>
        </div>

        {/* Security & Anti-Cheat Validation Badge */}
        <div className="bg-slate-900/40 border border-slate-800/80 rounded-xl p-3 flex items-center gap-2.5 text-xs text-slate-400">
          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>Encrypted PlayerPrefs with HMAC validation safeguards both save modes.</span>
        </div>
      </div>
    </div>
  );
};
