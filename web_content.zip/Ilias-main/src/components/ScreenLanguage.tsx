/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Globe, Check, ArrowRight } from 'lucide-react';
import { Language } from '../types/game';
import { getTranslation } from '../utils/i18n';
import { audio } from '../utils/audio';

interface ScreenLanguageProps {
  currentLang: Language;
  onSelectLang: (lang: Language) => void;
  onContinue: () => void;
}

export const ScreenLanguage: React.FC<ScreenLanguageProps> = ({
  currentLang,
  onSelectLang,
  onContinue
}) => {
  const languages: { code: Language; name: string; nativeName: string; region: string }[] = [
    { code: 'ar', name: 'Arabic', nativeName: 'العربية', region: 'الشرق الأوسط (RTL)' },
    { code: 'en', name: 'English', nativeName: 'English', region: 'Global (Default)' },
    { code: 'es', name: 'Spanish', nativeName: 'Español', region: 'Latinoamérica & España' }
  ];

  const handleLanguageClick = (code: Language) => {
    audio.playClick();
    onSelectLang(code);
  };

  const handleProceed = () => {
    audio.playClick();
    onContinue();
  };

  return (
    <div className="relative min-h-screen w-full flex flex-col items-center justify-center p-4 sm:p-6 bg-[#04060c] overflow-hidden">
      {/* Background Ambience Artwork */}
      <div className="absolute inset-0 z-0 opacity-40 mix-blend-screen pointer-events-none">
        <img
          src="/src/assets/images/abyss_title_art_1793472337997.jpg"
          alt="Abyss of Echoes artwork"
          className="w-full h-full object-cover filter blur-[2px] brightness-75 scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#04060c] via-[#04060c]/80 to-transparent" />
      </div>

      <div className="relative z-10 w-full max-w-md bg-slate-950/90 border border-slate-800/90 rounded-3xl p-6 sm:p-8 backdrop-blur-xl shadow-2xl flex flex-col items-center text-center space-y-6">
        {/* App Icon */}
        <div className="w-20 h-20 rounded-2xl overflow-hidden border-2 border-cyan-500/40 shadow-glow-cyan p-0.5 bg-slate-900">
          <img
            src="/src/assets/images/abyss_app_icon_1793472337090.jpg"
            alt="Abyss of Echoes"
            className="w-full h-full object-cover rounded-xl"
          />
        </div>

        {/* Title */}
        <div className="space-y-1.5">
          <h1 className="text-3xl font-black font-cinzel text-white tracking-wider text-glow-cyan">
            {getTranslation(currentLang, 'gameTitle')}
          </h1>
          <p className="text-xs text-slate-400 font-medium">
            {getTranslation(currentLang, 'gameSubtitle')}
          </p>
        </div>

        {/* Language Prompt */}
        <div className="w-full space-y-2 text-left">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-300">
            <Globe className="w-4 h-4 text-cyan-400" />
            <span>{getTranslation(currentLang, 'selectLanguage')}</span>
          </div>
          <p className="text-[11px] text-slate-400">
            {getTranslation(currentLang, 'chooseYourTongue')}
          </p>
        </div>

        {/* 3 Languages Options: Arabic, English, Spanish */}
        <div className="w-full space-y-2.5">
          {languages.map((item) => {
            const isSelected = currentLang === item.code;
            return (
              <button
                key={item.code}
                onClick={() => handleLanguageClick(item.code)}
                className={`w-full p-3.5 rounded-2xl border text-left flex items-center justify-between transition-all active:scale-[0.98] ${
                  isSelected
                    ? 'bg-gradient-to-r from-cyan-950/60 to-slate-900 border-cyan-400 shadow-glow-cyan text-white'
                    : 'bg-slate-900/60 hover:bg-slate-900/90 border-slate-800 text-slate-300'
                }`}
              >
                <div className="flex flex-col">
                  <span className="text-base font-bold flex items-center gap-2">
                    <span>{item.nativeName}</span>
                    <span className="text-xs font-normal text-slate-400">({item.name})</span>
                  </span>
                  <span className="text-[11px] text-slate-500">{item.region}</span>
                </div>

                <div
                  className={`w-6 h-6 rounded-full flex items-center justify-center border ${
                    isSelected
                      ? 'bg-cyan-500 border-cyan-400 text-slate-950'
                      : 'border-slate-700 bg-slate-950/40 text-transparent'
                  }`}
                >
                  <Check className="w-3.5 h-3.5 stroke-[3]" />
                </div>
              </button>
            );
          })}
        </div>

        {/* Continue Button */}
        <button
          onClick={handleProceed}
          className="w-full py-3.5 bg-gradient-to-r from-cyan-600 via-indigo-600 to-cyan-500 hover:from-cyan-500 hover:to-indigo-500 text-white font-bold text-sm rounded-2xl shadow-lg shadow-cyan-600/30 transition-transform active:scale-[0.98] flex items-center justify-center gap-2"
        >
          <span>{getTranslation(currentLang, 'continue')}</span>
          <ArrowRight className="w-4 h-4" />
        </button>

        {/* Mobile APK Badge */}
        <div className="text-[10px] text-slate-500 font-mono">
          Screen 1 of 3 · Mobile Ready APK
        </div>
      </div>
    </div>
  );
};
