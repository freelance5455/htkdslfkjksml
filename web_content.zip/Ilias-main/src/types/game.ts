/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type Language = 'en' | 'ar' | 'es';

export type AuthType = 'cloud' | 'guest';

export interface PlayerData {
  userId: string;
  authType: AuthType;
  displayName: string;
  level: number;
  xp: number;
  coins: number;
  currentStage: number; // 1 to 10
  equippedWeaponId: string;
  unlockedWeaponIds: string[];
  weaponLevels: Record<string, number>;
  armorLevel: number;
  lastCloudSync?: string;
  securityHash: string; // HMAC checksum to prevent memory editing
  highCombo: number;
  battlesWon: number;
}

export interface Weapon {
  id: string;
  nameKey: string;
  descriptionKey: string;
  damage: number;
  attackSpeed: number;
  reach: number;
  heavyDamage: number;
  heavyCooldownSeconds: number; // Default 5.0s
  cost: number;
  icon: string;
  color: string;
}

export interface StageConfig {
  id: number;
  nameKey: string;
  subtitleKey: string;
  enemyName: string;
  enemyTitleKey: string;
  enemyHp: number;
  enemyDamage: number;
  enemySpeed: number;
  enemyAggression: number; // 0 to 1
  coinReward: number;
  xpReward: number;
  arenaStyle: 'temple' | 'chasm' | 'shrine' | 'portal';
  specialAbilityKey?: string;
}

export type ScreenState = 
  | 'LANGUAGE_SELECT'
  | 'AUTH_SELECT'
  | 'MAIN_MENU'
  | 'STAGE_SELECT'
  | 'ARMORY'
  | 'COMBAT'
  | 'SETTINGS'
  | 'ANTI_CHEAT_INSPECTOR';

export type CombatOutcome = 'VICTORY' | 'DEFEAT' | 'DRAW';

export interface CombatResult {
  outcome: CombatOutcome;
  stageId: number;
  earnedCoins: number;
  earnedXp: number;
  durationSeconds: number;
  maxCombo: number;
  revivedUsed: boolean;
  doubledCoinsUsed: boolean;
}
