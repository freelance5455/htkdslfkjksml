/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Weapon, StageConfig } from '../types/game';

export const WEAPONS: Weapon[] = [
  {
    id: 'heavy_sword',
    nameKey: 'weapon_heavy_sword',
    descriptionKey: 'weapon_heavy_sword_desc',
    damage: 32,
    attackSpeed: 0.9,
    reach: 95,
    heavyDamage: 85, // Massive damage as specified!
    heavyCooldownSeconds: 5.0, // Strict 5.0 second cooldown!
    cost: 0, // Default starter weapon
    icon: 'Sword',
    color: '#06b6d4' // Cyan neon glow
  },
  {
    id: 'shadow_daggers',
    nameKey: 'weapon_shadow_daggers',
    descriptionKey: 'weapon_shadow_daggers_desc',
    damage: 18,
    attackSpeed: 1.6,
    reach: 60,
    heavyDamage: 55,
    heavyCooldownSeconds: 5.0,
    cost: 350,
    icon: 'Crosshair',
    color: '#a855f7' // Purple neon glow
  },
  {
    id: 'void_naginata',
    nameKey: 'weapon_void_naginata',
    descriptionKey: 'weapon_void_naginata_desc',
    damage: 28,
    attackSpeed: 1.1,
    reach: 125,
    heavyDamage: 75,
    heavyCooldownSeconds: 5.0,
    cost: 800,
    icon: 'Flame',
    color: '#3b82f6' // Blue neon glow
  },
  {
    id: 'cursed_greatblade',
    nameKey: 'weapon_cursed_greatblade',
    descriptionKey: 'weapon_cursed_greatblade_desc',
    damage: 42,
    attackSpeed: 0.85,
    reach: 105,
    heavyDamage: 110,
    heavyCooldownSeconds: 5.0,
    cost: 1600,
    icon: 'Zap',
    color: '#ec4899' // Violet-pink neon glow
  }
];

export const STAGES: StageConfig[] = [
  {
    id: 1,
    nameKey: 'stage_1_name',
    subtitleKey: 'stage_1_sub',
    enemyName: 'Guardian of the Abyss', // Explicitly requested in user prompt!
    enemyTitleKey: 'enemy_1_title',
    enemyHp: 180,
    enemyDamage: 12,
    enemySpeed: 2.2,
    enemyAggression: 0.45,
    coinReward: 120,
    xpReward: 150,
    arenaStyle: 'temple'
  },
  {
    id: 2,
    nameKey: 'stage_2_name',
    subtitleKey: 'stage_2_sub',
    enemyName: 'Blade of Whispers',
    enemyTitleKey: 'enemy_2_title',
    enemyHp: 240,
    enemyDamage: 16,
    enemySpeed: 2.7,
    enemyAggression: 0.52,
    coinReward: 180,
    xpReward: 220,
    arenaStyle: 'chasm'
  },
  {
    id: 3,
    nameKey: 'stage_3_name',
    subtitleKey: 'stage_3_sub',
    enemyName: 'Wraith of the Hollow',
    enemyTitleKey: 'enemy_3_title',
    enemyHp: 310,
    enemyDamage: 20,
    enemySpeed: 2.9,
    enemyAggression: 0.6,
    coinReward: 250,
    xpReward: 300,
    arenaStyle: 'shrine'
  },
  {
    id: 4,
    nameKey: 'stage_4_name',
    subtitleKey: 'stage_4_sub',
    enemyName: 'Nightstalker Shinobi',
    enemyTitleKey: 'enemy_4_title',
    enemyHp: 380,
    enemyDamage: 24,
    enemySpeed: 3.3,
    enemyAggression: 0.68,
    coinReward: 330,
    xpReward: 400,
    arenaStyle: 'temple'
  },
  {
    id: 5,
    nameKey: 'stage_5_name',
    subtitleKey: 'stage_5_sub',
    enemyName: 'Echo Warden',
    enemyTitleKey: 'enemy_5_title',
    enemyHp: 460,
    enemyDamage: 29,
    enemySpeed: 2.8,
    enemyAggression: 0.72,
    coinReward: 420,
    xpReward: 520,
    arenaStyle: 'shrine'
  },
  {
    id: 6,
    nameKey: 'stage_6_name',
    subtitleKey: 'stage_6_sub',
    enemyName: 'Obsidian Behemoth',
    enemyTitleKey: 'enemy_6_title',
    enemyHp: 560,
    enemyDamage: 36,
    enemySpeed: 2.5,
    enemyAggression: 0.76,
    coinReward: 530,
    xpReward: 650,
    arenaStyle: 'chasm'
  },
  {
    id: 7,
    nameKey: 'stage_7_name',
    subtitleKey: 'stage_7_sub',
    enemyName: 'Spectral Assassin',
    enemyTitleKey: 'enemy_7_title',
    enemyHp: 650,
    enemyDamage: 42,
    enemySpeed: 3.7,
    enemyAggression: 0.82,
    coinReward: 660,
    xpReward: 800,
    arenaStyle: 'shrine'
  },
  {
    id: 8,
    nameKey: 'stage_8_name',
    subtitleKey: 'stage_8_sub',
    enemyName: 'Void Sovereign',
    enemyTitleKey: 'enemy_8_title',
    enemyHp: 760,
    enemyDamage: 48,
    enemySpeed: 3.4,
    enemyAggression: 0.88,
    coinReward: 800,
    xpReward: 1000,
    arenaStyle: 'portal'
  },
  {
    id: 9,
    nameKey: 'stage_9_name',
    subtitleKey: 'stage_9_sub',
    enemyName: 'Shadow Archon',
    enemyTitleKey: 'enemy_9_title',
    enemyHp: 890,
    enemyDamage: 55,
    enemySpeed: 3.9,
    enemyAggression: 0.94,
    coinReward: 1000,
    xpReward: 1300,
    arenaStyle: 'temple'
  },
  {
    id: 10,
    nameKey: 'stage_10_name',
    subtitleKey: 'stage_10_sub',
    enemyName: 'Abyssal Primordial',
    enemyTitleKey: 'enemy_10_title',
    enemyHp: 1150,
    enemyDamage: 64,
    enemySpeed: 4.1,
    enemyAggression: 0.98,
    coinReward: 1500,
    xpReward: 2000,
    arenaStyle: 'portal'
  }
];
