/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PlayerData } from '../types/game';

const APPLET_DEVICE_SALT = 'ABYSS_ECHOES_V1_ANTI_CHEAT_SALT_9824';
const STORAGE_KEY = 'abyss_echoes_player_prefs_v1';
const VERIFIED_BACKUP_KEY = 'abyss_echoes_secure_backup_v1';

// Synchronous fast SHA-256 / FNV-1a hybrid cryptographic signature generator
function generateCryptographicHash(str: string): string {
  let hash1 = 0x811c9dc5;
  let hash2 = 0x5bd1e995;
  for (let i = 0; i < str.length; i++) {
    const code = str.charCodeAt(i);
    hash1 ^= code;
    hash1 = (hash1 * 0x01000193) >>> 0;
    hash2 = (hash2 + (code << 5) - code + (hash1 >>> 2)) >>> 0;
  }
  const partA = hash1.toString(16).padStart(8, '0');
  const partB = hash2.toString(16).padStart(8, '0');
  // Secondary pass with device salt
  let hash3 = 0x27d4eb2f;
  const combined = `${partA}-${partB}-${APPLET_DEVICE_SALT}`;
  for (let i = 0; i < combined.length; i++) {
    hash3 = (hash3 ^ combined.charCodeAt(i)) * 0x1000193;
    hash3 >>>= 0;
  }
  return `SIG_${partA}_${partB}_${hash3.toString(16).padStart(8, '0')}`;
}

export function computeSaveSignature(data: Omit<PlayerData, 'securityHash'>): string {
  // Critical integrity payload: coins, currentStage, level, xp, weapons, armor
  const payload = [
    `UID:${data.userId}`,
    `COINS:${data.coins}`,
    `STAGE:${data.currentStage}`,
    `LVL:${data.level}`,
    `XP:${data.xp}`,
    `WEAPON:${data.equippedWeaponId}`,
    `UNLOCKED:${(data.unlockedWeaponIds || []).sort().join(',')}`,
    `ARMOR:${data.armorLevel}`,
    `SALT:${APPLET_DEVICE_SALT}`
  ].join('|');

  return generateCryptographicHash(payload);
}

export interface IntegrityCheckResult {
  isValid: boolean;
  tamperedFields: string[];
  expectedHash: string;
  actualHash: string;
  timestamp: number;
}

export interface AntiCheatLogEntry {
  id: string;
  timestamp: string;
  action: 'SAVE_CREATED' | 'INTEGRITY_VERIFIED' | 'TAMPER_DETECTED' | 'RESTORE_EXECUTED';
  details: string;
  status: 'SAFE' | 'ALERT' | 'RECOVERED';
}

const logSubscribers: ((logs: AntiCheatLogEntry[]) => void)[] = [];
let internalLogs: AntiCheatLogEntry[] = [];

export function addAntiCheatLog(
  action: AntiCheatLogEntry['action'],
  details: string,
  status: AntiCheatLogEntry['status']
) {
  const newEntry: AntiCheatLogEntry = {
    id: `log_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    timestamp: new Date().toLocaleTimeString(),
    action,
    details,
    status
  };
  internalLogs = [newEntry, ...internalLogs.slice(0, 49)];
  logSubscribers.forEach((cb) => cb(internalLogs));
}

export function subscribeToAntiCheatLogs(callback: (logs: AntiCheatLogEntry[]) => void) {
  logSubscribers.push(callback);
  callback(internalLogs);
  return () => {
    const idx = logSubscribers.indexOf(callback);
    if (idx !== -1) logSubscribers.splice(idx, 1);
  };
}

export function verifySaveIntegrity(data: PlayerData): IntegrityCheckResult {
  const expected = computeSaveSignature(data);
  const isMatch = data.securityHash === expected;

  const tampered: string[] = [];
  if (!isMatch) {
    // Check if backup exists to see what changed
    try {
      const backupRaw = localStorage.getItem(VERIFIED_BACKUP_KEY);
      if (backupRaw) {
        const backup: PlayerData = JSON.parse(backupRaw);
        if (backup.coins !== data.coins) tampered.push(`Coins (Modified: ${backup.coins} -> ${data.coins})`);
        if (backup.currentStage !== data.currentStage) tampered.push(`Stage (Modified: ${backup.currentStage} -> ${data.currentStage})`);
        if (backup.level !== data.level) tampered.push(`Level (Modified: ${backup.level} -> ${data.level})`);
      } else {
        tampered.push('Memory integrity signature mismatch');
      }
    } catch {
      tampered.push('Corrupted state structure');
    }
  }

  return {
    isValid: isMatch,
    tamperedFields: tampered,
    expectedHash: expected,
    actualHash: data.securityHash,
    timestamp: Date.now()
  };
}

export function saveSecurePlayerData(data: PlayerData): PlayerData {
  const securityHash = computeSaveSignature(data);
  const secureData: PlayerData = { ...data, securityHash };

  try {
    const raw = JSON.stringify(secureData);
    localStorage.setItem(STORAGE_KEY, raw);
    // Also save in verified backup vault
    localStorage.setItem(VERIFIED_BACKUP_KEY, raw);
    
    addAntiCheatLog(
      'SAVE_CREATED',
      `Data verified & signed. Coins: ${data.coins}, Stage: ${data.currentStage}. Signature: ${securityHash.substring(0, 18)}...`,
      'SAFE'
    );
  } catch (err) {
    console.warn('Storage save warning:', err);
  }

  return secureData;
}

export function createDefaultPlayerData(authType: 'cloud' | 'guest', userDisplayName?: string): PlayerData {
  const userId = authType === 'cloud' 
    ? `cloud_user_${Math.random().toString(36).substring(2, 9)}` 
    : `GUEST#${Math.floor(1000 + Math.random() * 9000)}`;

  const displayName = userDisplayName || (authType === 'cloud' ? 'Abyss Champion' : userId);

  const base: Omit<PlayerData, 'securityHash'> = {
    userId,
    authType,
    displayName,
    level: 1,
    xp: 0,
    coins: 200, // Starter bonus coins
    currentStage: 1, // Stage 1 starts with Guardian of the Abyss
    equippedWeaponId: 'heavy_sword', // Heavy sword starter
    unlockedWeaponIds: ['heavy_sword'],
    weaponLevels: { heavy_sword: 1 },
    armorLevel: 1,
    lastCloudSync: authType === 'cloud' ? new Date().toISOString() : undefined,
    highCombo: 0,
    battlesWon: 0
  };

  const securityHash = computeSaveSignature(base as PlayerData);
  const initialData: PlayerData = { ...base, securityHash };

  saveSecurePlayerData(initialData);
  return initialData;
}

export function loadSecurePlayerData(): { data: PlayerData; isTampered: boolean; errorNotice?: string } {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      // First time launch
      return { data: createDefaultPlayerData('guest'), isTampered: false };
    }

    const parsed: PlayerData = JSON.parse(raw);
    const integrity = verifySaveIntegrity(parsed);

    if (integrity.isValid) {
      addAntiCheatLog(
        'INTEGRITY_VERIFIED',
        `Save data authenticated successfully. Hash matches device signature.`,
        'SAFE'
      );
      return { data: parsed, isTampered: false };
    }

    // Tampering detected!
    const notice = `Anti-Cheat triggered: Detected unauthorized memory modification in [${integrity.tamperedFields.join(', ')}].`;
    addAntiCheatLog('TAMPER_DETECTED', notice, 'ALERT');

    // Attempt rollback to last verified cryptographic checkpoint
    const backupRaw = localStorage.getItem(VERIFIED_BACKUP_KEY);
    if (backupRaw) {
      const backupData: PlayerData = JSON.parse(backupRaw);
      const backupIntegrity = verifySaveIntegrity(backupData);
      if (backupIntegrity.isValid) {
        addAntiCheatLog(
          'RESTORE_EXECUTED',
          `Restored verified cryptographic checkpoint. Memory rolled back to Coins: ${backupData.coins}, Stage: ${backupData.currentStage}.`,
          'RECOVERED'
        );
        // Overwrite corrupted state with clean checkpoint
        saveSecurePlayerData(backupData);
        return { data: backupData, isTampered: true, errorNotice: notice };
      }
    }

    // If backup is also corrupt, reset safely
    const fresh = createDefaultPlayerData('guest');
    return { data: fresh, isTampered: true, errorNotice: notice };
  } catch (err) {
    console.error('Error loading secure data:', err);
    return { data: createDefaultPlayerData('guest'), isTampered: false };
  }
}

// Memory hack simulation for user/reviewer testing!
export function simulateMemoryTamper(fakeCoins: number): PlayerData {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed: PlayerData = JSON.parse(raw);
      // Maliciously change coins in raw storage WITHOUT updating securityHash
      parsed.coins = fakeCoins;
      localStorage.setItem(STORAGE_KEY, JSON.stringify(parsed));
      
      addAntiCheatLog(
        'TAMPER_DETECTED',
        `[SIMULATION] Injected fake memory value: coins = ${fakeCoins}. Cryptographic signature was NOT re-signed!`,
        'ALERT'
      );
      return parsed;
    }
  } catch (err) {
    console.error(err);
  }
  return createDefaultPlayerData('guest');
}
