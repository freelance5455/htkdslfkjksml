/* Receptor web para Google Cast.
 *
 * Lo que este receptor hace de verdad:
 *   1. Acepta la sesión Cast del teléfono y abre el canal de control propio.
 *   2. Recibe los mensajes de encuadre (modo, zoom, rotación) y los aplica al
 *      elemento de vídeo: recorte y escala reales sobre la imagen mostrada.
 *   3. Intenta reproducir el flujo del teléfono y, si el dispositivo no lo
 *      permite, lo comunica para que la app ofrezca el espejo del sistema.
 *
 * Límite conocido: Google no permite que una app de terceros cree el espejo de
 * pantalla del sistema en un Chromecast. Esto no es una limitación de este
 * archivo, es el comportamiento documentado de la plataforma Cast.
 */

const NAMESPACE = 'urn:x-cast:com.screencastpro.control';

const video = document.getElementById('mirror');
const message = document.getElementById('message');

let preset = { mode: 'FIT', zoom: 1, rotation: 0 };

const receiverContext = cast.framework.CastReceiverContext.getInstance();
const playerManager = receiverContext.getPlayerManager();

receiverContext.addCustomMessageListener(NAMESPACE, (event) => {
  const data = event.data || {};
  if (data.type === 'fit') {
    preset = {
      mode: data.mode || 'FIT',
      zoom: typeof data.zoom === 'number' ? data.zoom : 1,
      rotation: typeof data.rotation === 'number' ? data.rotation : 0,
    };
    applyFit();
  }
  if (data.type === 'ping') {
    send({ type: 'capabilities', fullscreen: canMirror() });
  }
});

function canMirror() {
  // Capacidad real del dispositivo: decodificación de vídeo en el receptor web.
  return typeof window.MediaSource !== 'undefined' || typeof window.RTCPeerConnection !== 'undefined';
}

function applyFit() {
  const container = document.getElementById('stage');
  const tvAspect = container.clientWidth / container.clientHeight;
  const rotation = preset.rotation % 360;
  const zoom = Math.min(Math.max(preset.zoom, 1), 3);

  let transform = '';
  let objectFit = 'contain';

  if (preset.mode === 'FILL' || preset.mode === 'RATIO_16_9') {
    // Rellena recortando: nunca estira.
    objectFit = 'cover';
  } else if (preset.mode === 'ORIGINAL') {
    objectFit = 'none';
  } else if (preset.mode === 'ZOOM') {
    objectFit = 'contain';
  }

  if (zoom > 1) {
    transform = 'scale(' + zoom + ')';
  }
  if (rotation !== 0) {
    transform += ' rotate(' + rotation + 'deg)';
  }

  video.style.objectFit = objectFit;
  video.style.transform = transform;
  video.style.aspectRatio = preset.mode === 'RATIO_16_9' ? String(tvAspect) : 'auto';
}

function send(payload) {
  const session = receiverContext.getSenders()[0];
  if (session) {
    session.send(NAMESPACE, payload);
  }
}

function startMirroring(streamUrl) {
  if (!streamUrl) {
    message.textContent = canMirror()
      ? 'Sesión abierta. El teléfono enviará la imagen.'
      : 'Este receptor no puede mostrar el espejo. Usa la app receptora en tu Android TV o Fire TV.';
    return;
  }
  video.src = streamUrl;
  video.play().catch(() => {
    message.textContent = 'No se pudo reproducir el flujo entrante.';
  });
}

playerManager.setMessageInterceptor(cast.framework.messages.MessageType.LOAD, (request) => {
  startMirroring(request.media && request.media.contentId);
  return request;
});

receiverContext.start({ disableIdleTimeout: true });
send({ type: 'capabilities', fullscreen: canMirror() });