package com.screencastpro.stream.system

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.provider.Settings

/**
 * Espejo gestionado por el sistema.
 *
 * Android no expone API pública para que una app de terceros cree una sesión
 * Wi-Fi Display (Miracast) desde Android 8, ni para crear el espejo privado de
 * Chromecast. Lo que sí se puede hacer, y hace esta clase, es llevar al usuario
 * al panel del sistema donde esa función existe (Fire TV, Hisense, Pixel y otros
 * fabricantes lo incluyen). No se simula nada: se abre la pantalla real.
 */
object SystemMirroringLauncher {

    /** Devuelve true si el dispositivo ofrece alguna de las pantallas del sistema. */
    fun canOpen(context: Context): Boolean = candidateIntents().any { intent ->
        intent.resolveActivity(context.packageManager) != null
    }

    fun open(context: Context): Boolean {
        for (intent in candidateIntents()) {
            val resolved = intent.resolveActivity(context.packageManager) ?: continue
            try {
                context.startActivity(intent)
                return true
            } catch (_: ActivityNotFoundException) {
                // Se prueba el siguiente panel disponible.
            }
        }
        return false
    }

    private fun candidateIntents(): List<Intent> = listOf(
        // "Transmitir pantalla" / "Cast screen" (Android 8+).
        Intent(Settings.ACTION_CAST_SETTINGS),
        // Pantalla inalámbrica de fabricantes que la exponen.
        Intent(ACTION_WIFI_DISPLAY_SETTINGS),
        Intent(Settings.ACTION_WIRELESS_SETTINGS)
    ).map { it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }

    private const val ACTION_WIFI_DISPLAY_SETTINGS = "android.settings.WIFI_DISPLAY_SETTINGS"
}