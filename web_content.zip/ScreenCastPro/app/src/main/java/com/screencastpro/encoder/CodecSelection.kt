package com.screencastpro.encoder

import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat

data class CodecProfile(val profile: Int, val level: Int)

/**
 * Los codificadores son muy distintos entre fabricantes: preguntar antes de
 * configurar evita que "60 FPS" o "1080p" fallen en la mitad de los móviles.
 */
class CodecSelection {

    private val capabilities: MediaCodecInfo.CodecCapabilities? by lazy { findAvcCapabilities() }

    fun supports(width: Int, height: Int, fps: Int): Boolean =
        capabilities?.videoCapabilities?.isSizeAndRateSupported(width, height, fps.toDouble())
            ?: false

    /** Reduce FPS antes que resolución, que es lo que nota menos el usuario. */
    fun negotiatedFps(width: Int, height: Int, requestedFps: Int): Int =
        if (supports(width, height, requestedFps)) requestedFps else 30

    fun chooseProfile(width: Int, height: Int, fps: Int): CodecProfile {
        val caps = capabilities ?: return CodecProfile(
            MediaCodecInfo.CodecProfileLevel.AVCProfileBaseline,
            MediaCodecInfo.CodecProfileLevel.AVCLevel41
        )

        val supportsSize = caps.videoCapabilities?.isSizeSupported(width, height) ?: false
        return if (supportsSize && fps >= 30) {
            CodecProfile(
                MediaCodecInfo.CodecProfileLevel.AVCProfileHigh,
                MediaCodecInfo.CodecProfileLevel.AVCLevel42
            )
        } else {
            CodecProfile(
                MediaCodecInfo.CodecProfileLevel.AVCProfileBaseline,
                MediaCodecInfo.CodecProfileLevel.AVCLevel41
            )
        }
    }

    private fun findAvcCapabilities(): MediaCodecInfo.CodecCapabilities? {
        val codecs = MediaCodecList(MediaCodecList.ALL_CODECS)
        return codecs.codecInfos
            .firstOrNull { info ->
                info.isEncoder && info.supportedTypes.any { type ->
                    type.equals(MediaFormat.MIMETYPE_VIDEO_AVC, ignoreCase = true)
                }
            }
            ?.getCapabilitiesForType(MediaFormat.MIMETYPE_VIDEO_AVC)
    }
}