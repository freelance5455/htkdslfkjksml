package com.screencastpro.stream

import kotlin.math.min

/**
 * Política de reconexión.
 *
 * Cuando la red se cae, el emisor reintenta con espera creciente en vez de
 * machacar la conexión: el primer reintento es rápido, el último espera hasta
 * 10 segundos. Si el receptor vuelve a la red, la sesión se recupera sola.
 */
class ReconnectPolicy(
    private val maxAttempts: Int = 4,
    private val baseDelayMs: Long = 1_500L
) {

    fun shouldRetry(attempt: Int): Boolean = attempt < maxAttempts

    fun delayFor(attempt: Int): Long = min(baseDelayMs * (attempt + 1), MAX_DELAY_MS)

    companion object {
        private const val MAX_DELAY_MS = 10_000L
    }
}