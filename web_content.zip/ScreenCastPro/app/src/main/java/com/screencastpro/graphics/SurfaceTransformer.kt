package com.screencastpro.graphics

import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.os.Handler
import android.os.HandlerThread
import android.view.Surface
import com.screencastpro.shared.graphics.DisplayFitCalculator
import com.screencastpro.shared.graphics.FitPreset
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

/**
 * Pipeline gráfico entre la captura y el codificador:
 *
 *   VirtualDisplay -> SurfaceTexture -> [OpenGL: encuadre, zoom, rotación] -> superficie del codificador
 *
 * Cambiar de modo de pantalla recalcula la matriz y el siguiente fotograma ya sale
 * encuadrado. La interfaz de la app no interviene en este camino.
 */
class SurfaceTransformer {

    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var eglDisplay = EGL14.EGL_NO_DISPLAY
    private var eglContext = EGL14.EGL_NO_CONTEXT
    private var eglSurface = EGL14.EGL_NO_SURFACE
    private var eglConfig: EGLConfig? = null

    private var textureId = 0
    private var surfaceTexture: SurfaceTexture? = null
    private var inputSurface: Surface? = null
    private var program = 0
    private var positionHandle = 0
    private var texCoordHandle = 0
    private var textureMatrixHandle = 0

    private var sourceWidth = 0
    private var sourceHeight = 0
    private var targetWidth = 0
    private var targetHeight = 0

    private val textureMatrix = FloatArray(16)
    private val vertexBuffer: FloatBuffer = createBuffer(8)
    private val texCoordBuffer: FloatBuffer = createBuffer(8)

    @Volatile
    private var preset = FitPreset()

    val inputSurfaceOrNull: Surface? get() = inputSurface

    fun configure(inputWidth: Int, inputHeight: Int, fps: Int) {
        sourceWidth = inputWidth
        sourceHeight = inputHeight
        startGlThread(fps)
    }

    fun setEncoderSurface(surface: Surface, outputWidth: Int, outputHeight: Int) {
        targetWidth = outputWidth
        targetHeight = outputHeight
        handler?.post {
            createEglSurface(surface)
            GLES20.glViewport(0, 0, outputWidth, outputHeight)
        }
    }

    fun setPreset(newPreset: FitPreset) {
        preset = newPreset
    }

    fun requestRender() {
        handler?.post { render() }
    }

    private fun startGlThread(fps: Int) {
        if (thread != null) return
        val glThread = HandlerThread("screencast-gl")
        glThread.start()
        thread = glThread
        val glHandler = Handler(glThread.looper)
        handler = glHandler

        val ready = java.util.concurrent.CountDownLatch(1)
        glHandler.post {
            initEgl()
            program = buildProgram()
            positionHandle = GLES20.glGetAttribLocation(program, "aPosition")
            texCoordHandle = GLES20.glGetAttribLocation(program, "aTexCoord")
            textureMatrixHandle = GLES20.glGetUniformLocation(program, "uTexMatrix")
            createTexture()
            ready.countDown()
        }
        ready.await()
    }

    private fun initEgl() {
        eglDisplay = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val version = IntArray(2)
        EGL14.eglInitialize(eglDisplay, version, 0, version, 1)

        val attributes = intArrayOf(
            EGL14.EGL_RED_SIZE, 8,
            EGL14.EGL_GREEN_SIZE, 8,
            EGL14.EGL_BLUE_SIZE, 8,
            EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGL14.EGL_NONE
        )
        val configs = arrayOfNulls<EGLConfig>(1)
        val configCount = IntArray(1)
        EGL14.eglChooseConfig(eglDisplay, attributes, 0, configs, 0, 1, configCount, 0)
        eglConfig = configs[0]

        eglContext = EGL14.eglCreateContext(
            eglDisplay,
            configs[0],
            EGL14.EGL_NO_CONTEXT,
            intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE),
            0
        )
    }

    private fun createEglSurface(surface: Surface) {
        val config = eglConfig ?: return
        releaseEglSurface()
        // La superficie de entrada del codificador vive en otro proceso: se usa el
        // mismo EGLDisplay del contexto principal para que el intercambio funcione.
        eglSurface = EGL14.eglCreateWindowSurface(
            eglDisplay,
            config,
            surface,
            intArrayOf(EGL14.EGL_NONE),
            0
        )
        EGL14.eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext)
    }

    private fun createTexture() {
        val textures = IntArray(1)
        GLES20.glGenTextures(1, textures, 0)
        textureId = textures[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, textureId)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)

        surfaceTexture = SurfaceTexture(textureId).apply {
            setOnFrameAvailableListener { requestRender() }
        }
        inputSurface = Surface(surfaceTexture)
    }

    private fun render() {
        val frameAvailable = surfaceTexture ?: return
        if (eglSurface == EGL14.EGL_NO_SURFACE || targetWidth == 0) return

        frameAvailable.updateTexImage()
        frameAvailable.getTransformMatrix(textureMatrix)

        val transform = DisplayFitCalculator.compute(
            sourceWidth = sourceWidth,
            sourceHeight = sourceHeight,
            targetWidth = targetWidth,
            targetHeight = targetHeight,
            preset = preset
        )

        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        GLES20.glUseProgram(program)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, textureId)

        writeQuad(transform)
        GLES20.glEnableVertexAttribArray(positionHandle)
        GLES20.glVertexAttribPointer(positionHandle, 2, GLES20.GL_FLOAT, false, 0, vertexBuffer)
        GLES20.glEnableVertexAttribArray(texCoordHandle)
        GLES20.glVertexAttribPointer(texCoordHandle, 2, GLES20.GL_FLOAT, false, 0, texCoordBuffer)
        GLES20.glUniformMatrix4fv(textureMatrixHandle, 1, false, textureMatrix, 0)

        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(positionHandle)
        GLES20.glDisableVertexAttribArray(texCoordHandle)

        EGLExt.eglPresentationTimeANDROID(eglDisplay, eglSurface, frameAvailable.timestamp)
        EGL14.eglSwapBuffers(eglDisplay, eglSurface)
    }

    /** Vértices en coordenadas normalizadas + región de origen que se muestrea. */
    private fun writeQuad(transform: com.screencastpro.shared.graphics.FitTransform) {
        val left = transform.viewportX.toFloat() / targetWidth * 2f - 1f
        val right = (transform.viewportX + transform.viewportWidth).toFloat() / targetWidth * 2f - 1f
        val top = 1f - transform.viewportY.toFloat() / targetHeight * 2f
        val bottom = 1f - (transform.viewportY + transform.viewportHeight).toFloat() / targetHeight * 2f

        vertexBuffer.clear()
        vertexBuffer.put(floatArrayOf(left, bottom, right, bottom, left, top, right, top)).position(0)

        val u0 = transform.sourceX.toFloat() / sourceWidth
        val u1 = (transform.sourceX + transform.sourceWidth).toFloat() / sourceWidth
        val v0 = transform.sourceY.toFloat() / sourceHeight
        val v1 = (transform.sourceY + transform.sourceHeight).toFloat() / sourceHeight

        texCoordBuffer.clear()
        texCoordBuffer.put(floatArrayOf(u0, v1, u1, v1, u0, v0, u1, v0)).position(0)
    }

    private fun buildProgram(): Int {
        val vertexShader = compileShader(
            GLES20.GL_VERTEX_SHADER,
            "attribute vec4 aPosition; attribute vec2 aTexCoord; uniform mat4 uTexMatrix; varying vec2 vTexCoord; void main() { gl_Position = aPosition; vTexCoord = (uTexMatrix * vec4(aTexCoord, 0.0, 1.0)).xy; }"
        )
        val fragmentShader = compileShader(
            GLES20.GL_FRAGMENT_SHADER,
            "#extension GL_OES_EGL_image_external : require precision mediump float; uniform samplerExternalOES uTexture; varying vec2 vTexCoord; void main() { gl_FragColor = texture2D(uTexture, vTexCoord); }"
        )
        val programId = GLES20.glCreateProgram()
        GLES20.glAttachShader(programId, vertexShader)
        GLES20.glAttachShader(programId, fragmentShader)
        GLES20.glLinkProgram(programId)
        return programId
    }

    private fun compileShader(type: Int, source: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, source)
        GLES20.glCompileShader(shader)
        return shader
    }

    private fun releaseEglSurface() {
        if (eglSurface != EGL14.EGL_NO_SURFACE) {
            EGL14.eglMakeCurrent(
                eglDisplay,
                EGL14.EGL_NO_SURFACE,
                EGL14.EGL_NO_SURFACE,
                EGL14.EGL_NO_CONTEXT
            )
            EGL14.eglDestroySurface(eglDisplay, eglSurface)
            eglSurface = EGL14.EGL_NO_SURFACE
        }
    }

    fun release() {
        handler?.post {
            releaseEglSurface()
            surfaceTexture?.release()
            surfaceTexture = null
            if (textureId != 0) GLES20.glDeleteTextures(1, intArrayOf(textureId), 0)
            EGL14.eglDestroyContext(eglDisplay, eglContext)
            EGL14.eglTerminate(eglDisplay)
            thread?.quitSafely()
            thread = null
            handler = null
        }
    }

    private fun createBuffer(size: Int): FloatBuffer =
        ByteBuffer.allocateDirect(size * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()

    /** Superficie que se entrega a MediaProjection; el resto es interno. */
    val inputSurface: Surface
        get() = requireNotNull(inputSurfaceOrNull) { "configure() debe llamarse antes de start()" }
}