package com.screencastpro.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.screencastpro.shared.model.StreamFps
import com.screencastpro.shared.model.StreamQuality
import com.screencastpro.ui.home.HomeViewModel

@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    viewModel: HomeViewModel = viewModel()
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("Ajustes") },
                navigationIcon = {
                    TextButton(onClick = onBack) { Text("Volver") }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            SettingGroup(title = "Calidad") {
                OptionRow("Automática", settings.quality == StreamQuality.AUTO) {
                    viewModel.updateSettings { it.copy(quality = StreamQuality.AUTO) }
                }
                OptionRow("720p", settings.quality == StreamQuality.HD720) {
                    viewModel.updateSettings { it.copy(quality = StreamQuality.HD720) }
                }
                OptionRow("1080p", settings.quality == StreamQuality.FULL_HD_1080) {
                    viewModel.updateSettings { it.copy(quality = StreamQuality.FULL_HD_1080) }
                }
            }

            SettingGroup(title = "FPS") {
                OptionRow("30 FPS", settings.fps == StreamFps.FPS_30) {
                    viewModel.updateSettings { it.copy(fps = StreamFps.FPS_30) }
                }
                OptionRow("60 FPS", settings.fps == StreamFps.FPS_60) {
                    viewModel.updateSettings { it.copy(fps = StreamFps.FPS_60) }
                }
                Text(
                    text = "El codificador comprueba si el hardware admite 60 FPS a esa resolución; si no, transmite a 30.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            SettingGroup(title = "Audio") {
                SwitchRow(
                    title = "Activar audio",
                    checked = settings.audioEnabled,
                    onChange = { value -> viewModel.updateSettings { it.copy(audioEnabled = value) } }
                )
                Text(
                    text = "Se captura el audio del sistema cuando la app de origen lo permite. El contenido protegido con DRM nunca se puede capturar.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            SettingGroup(title = "Transmisión") {
                SwitchRow(
                    title = "Baja latencia",
                    checked = settings.lowLatency,
                    onChange = { value -> viewModel.updateSettings { it.copy(lowLatency = value) } }
                )
                SwitchRow(
                    title = "Reconexión automática",
                    checked = settings.autoReconnect,
                    onChange = { value -> viewModel.updateSettings { it.copy(autoReconnect = value) } }
                )
            }

            Button(
                onClick = { viewModel.refreshDevices() },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Filled.Refresh, contentDescription = null)
                Text("Buscar dispositivos nuevamente", modifier = Modifier.padding(start = 10.dp))
            }
        }
    }
}

@Composable
private fun SettingGroup(title: String, content: @Composable () -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Column(modifier = Modifier.padding(top = 8.dp)) { content() }
        }
    }
}

@Composable
private fun OptionRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label)
        Switch(checked = selected, onCheckedChange = { onClick() })
    }
}

@Composable
private fun SwitchRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(title)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}