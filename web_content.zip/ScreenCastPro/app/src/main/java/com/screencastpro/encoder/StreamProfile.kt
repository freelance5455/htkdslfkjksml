package com.screencastpro.encoder

import com.screencastpro.capture.CaptureConfig
import com.screencastpro.shared.model.StreamSettings

/**
 * Control de bitrate, resolución y FPS.
 *
 * Reúne las tres decisiones en un único lugar: la calidad elegida por el usuario
 * define la resolución, el hardware dice si 60 FPS son posibles y el bitrate sale
 * de píxeles por segundo con un margen menor cuando se pide baja latencia. Los
 * transportes consumen siempre este resultado en vez de calcularlo cada uno.
 */
data class StreamProfile(
    val width: Int,
    val height: Int,
    val fps: Int,
    val bitrate: Int,
    val lowLatency: Boolean
) {
    companion object {

        fun resolve(
            captureConfig: CaptureConfig,
            settings: StreamSettings,
            codecSelection: CodecSelection
        ): StreamProfile {
            val requestedFps = settings.fps.value
            val grantedFps = codecSelection.negotiatedFps(
                captureConfig.targetWidth,
                captureConfig.targetHeight,
                requestedFps
            )

            // 0.10 bits por píxel y fotograma es un punto medio razonable para
            // pantalla compartida; con baja latencia se recorta un 20 %.
            val bitsPerPixel = if (settings.lowLatency) 0.08 else 0.10
            val rawBitrate =
                (captureConfig.targetWidth.toDouble() * captureConfig.targetHeight * grantedFps * bitsPerPixel).toInt()

            return StreamProfile(
                width = captureConfig.targetWidth,
                height = captureConfig.targetHeight,
                fps = grantedFps,
                bitrate = rawBitrate.coerceIn(MIN_BITRATE, MAX_BITRATE),
                lowLatency = settings.lowLatency
            )
        }

        private const val MIN_BITRATE = 600_000
        private const val MAX_BITRATE = 12_000_000
    }
}