package com.screencastpro.encoder

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.os.Build
import android.os.Bundle
import android.view.Surface

/**
 * Codificador H.264. La superficie de entrada la consume SurfaceTransformer, que
 * dibuja el fotograma ya encuadrado.
 */
class VideoEncoder(private val codecSelection: CodecSelection) {

    private var codec: MediaCodec? = null
    private var bitrate = 0

    /** SPS/PPS que entrega el codificador: se envían como primer paquete del protocolo directo. */
    @Volatile
    private var csd: ByteArray? = null

    val currentBitrate: Int get() = bitrate
    val configurationData: ByteArray? get() = csd

    fun start(
        width: Int,
        height: Int,
        fps: Int,
        initialBitrate: Int,
        lowLatency: Boolean
    ): Surface {
        stop()
        val profile = codecSelection.chooseProfile(width, height, fps)

        val format = MediaFormat.createVideoFormat(
            MediaFormat.MIMETYPE_VIDEO_AVC,
            width,
            height
        ).apply {
            setInteger(
                MediaFormat.KEY_COLOR_FORMAT,
                MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface
            )
            setInteger(MediaFormat.KEY_BIT_RATE, initialBitrate)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            setInteger(MediaFormat.KEY_PROFILE, profile.profile)
            setInteger(MediaFormat.KEY_LEVEL, profile.level)
            setInteger(
                MediaFormat.KEY_BITRATE_MODE,
                MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR
            )
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && lowLatency) {
                setInteger(MediaFormat.KEY_LOW_LATENCY, 1)
            }
        }

        val activeCodec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        activeCodec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val surface = activeCodec.createInputSurface()
        activeCodec.start()

        codec = activeCodec
        bitrate = initialBitrate
        return surface
    }

    fun requestKeyFrame() {
        codec?.setParameters(Bundle().apply {
            putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0)
        })
    }

    /**
     * Bitrate adaptable: BitrateController decide el valor a partir de las
     * estadísticas del transporte y aquí se aplica sin reiniciar el codificador.
     */
    fun updateBitrate(targetBitrate: Int) {
        val active = codec ?: return
        if (targetBitrate == bitrate) return
        bitrate = targetBitrate
        active.setParameters(Bundle().apply {
            putInt(MediaCodec.PARAMETER_KEY_VIDEO_BITRATE, targetBitrate)
        })
    }

    /**
     * Entrega cada fotograma codificado. Lo usa DirectH264Transport, que envuelve
     * los datos en su protocolo y los manda por TCP al receptor.
     */
    fun drain(onFrame: (java.nio.ByteBuffer, MediaCodec.BufferInfo) -> Unit) {
        val active = codec ?: return
        val info = MediaCodec.BufferInfo()
        val index = active.dequeueOutputBuffer(info, DRAIN_TIMEOUT_US)
        if (index < 0) return
        if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) {
            // SPS/PPS: sin ellos el receptor no puede configurar su decodificador.
            val configBuffer = active.getOutputBuffer(index)
            if (configBuffer != null) {
                val config = ByteArray(info.size)
                configBuffer.position(info.offset)
                configBuffer.get(config, 0, info.size)
                csd = config
            }
            active.releaseOutputBuffer(index, false)
            return
        }
        val buffer = active.getOutputBuffer(index) ?: return
        onFrame(buffer, info)
        active.releaseOutputBuffer(index, false)
    }

    fun stop() {
        val active = codec ?: return
        runCatching { active.stop() }
        active.release()
        codec = null
        bitrate = 0
        csd = null
    }

    private companion object {
        const val DRAIN_TIMEOUT_US = 10_000L
    }
}