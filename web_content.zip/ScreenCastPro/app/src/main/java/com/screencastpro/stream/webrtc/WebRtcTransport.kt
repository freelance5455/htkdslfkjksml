package com.screencastpro.stream.webrtc

import android.content.Context
import android.media.projection.MediaProjection
import com.screencastpro.capture.CaptureConfig
import com.screencastpro.encoder.BitrateController
import com.screencastpro.shared.graphics.FitPreset
import com.screencastpro.shared.model.ControlMessage
import com.screencastpro.shared.model.DeviceDescriptor
import com.screencastpro.shared.model.StreamSettings
import com.screencastpro.shared.model.StreamStats
import com.screencastpro.shared.model.TransportKind
import com.screencastpro.stream.StreamTransport
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.json.Json
import org.webrtc.AudioSource
import org.webrtc.AudioTrack
import org.webrtc.DataChannel
import org.webrtc.DefaultVideoDecoderFactory
import org.webrtc.DefaultVideoEncoderFactory
import org.webrtc.EglBase
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.MediaStream
import org.webrtc.MediaStreamTrack
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.RtpReceiver
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import org.webrtc.SurfaceTextureHelper
import org.webrtc.VideoSource
import org.webrtc.VideoTrack
import java.nio.ByteBuffer

/**
 * Transporte principal: WebRTC contra nuestra app receptora.
 *
 * * Latencia baja (100-300 ms en red local) y códec con control de bitrate.
 * * El encuadre se aplica antes de codificar (FitScreenCapturer).
 * * El canal de datos "control" lleva los cambios de modo, zoom, rotación y
 *   pantalla completa al receptor en caliente.
 */
class WebRtcTransport(
    private val context: Context,
    private val projection: MediaProjection,
    private val signalingOverride: String
) : StreamTransport {

    override val kind: TransportKind = TransportKind.WEBRTC

    private val _stats = MutableStateFlow(StreamStats())
    override val stats: StateFlow<StreamStats> = _stats.asStateFlow()

    private val eglBase: EglBase = EglBase.create()
    private val factory: PeerConnectionFactory by lazy { createFactory() }
    private val bitrateController = BitrateController()
    private val json = Json { ignoreUnknownKeys = true }

    private var peerConnection: PeerConnection? = null
    private var videoSource: VideoSource? = null
    private var audioSource: AudioSource? = null
    private var capturer: FitScreenCapturer? = null
    private var surfaceHelper: SurfaceTextureHelper? = null
    private var controlChannel: DataChannel? = null
    private var signaling: SignalingClient? = null

    override suspend fun connect(
        device: DeviceDescriptor,
        settings: StreamSettings,
        captureConfig: CaptureConfig,
        preset: FitPreset
    ) {
        val host = device.host ?: error("El dispositivo no tiene dirección de red")
        val endpoint = if (signalingOverride.isBlank()) {
            SignalingClient.defaultUrlFor(host, device.port ?: SignalingClient.DEFAULT_PORT)
        } else {
            signalingOverride
        }
        val client = SignalingClient(endpoint)
        signaling = client

        val connection = factory.createPeerConnection(
            PeerConnection.RTCConfiguration(iceServerList()).apply {
                sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
                continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
            },
            peerObserver()
        ) ?: error("No se pudo crear la conexión WebRTC")

        peerConnection = connection

        // Vídeo: el capturador propio aplica el encuadre antes de codificar.
        val source = factory.createVideoSource(true)
        videoSource = source
        val helper = SurfaceTextureHelper.create("ScreenCastProCapture", eglBase.eglBaseContext)
        surfaceHelper = helper

        val screenCapturer = FitScreenCapturer(projection, captureConfig, eglBase)
        capturer = screenCapturer
        screenCapturer.initialize(helper, context, source.capturerObserver)
        screenCapturer.updatePreset(preset)

        val negotiatedFps = if (settings.lowLatency) captureConfig.fps else minOf(captureConfig.fps, 30)
        screenCapturer.startCapture(captureConfig.targetWidth, captureConfig.targetHeight, negotiatedFps)

        val videoTrack: VideoTrack = factory.createVideoTrack(VIDEO_TRACK_ID, source)
        connection.addTrack(videoTrack, listOf(STREAM_ID))

        if (settings.audioEnabled) {
            val audio = factory.createAudioSource(MediaConstraints())
            audioSource = audio
            val audioTrack: AudioTrack = factory.createAudioTrack(AUDIO_TRACK_ID, audio)
            connection.addTrack(audioTrack, listOf(STREAM_ID))
        }

        val control = connection.createDataChannel(CONTROL_CHANNEL, DataChannel.Init())
        control.registerObserver(object : DataChannel.Observer {
            override fun onBufferedAmountChange(amount: Long) = Unit
            override fun onStateChange() = Unit
            override fun onMessage(message: DataChannel.Buffer) {
                val bytes = ByteArray(message.data.remaining())
                message.data.get(bytes)
                // El receptor puede informar de su tamaño real de pantalla; sirve
                // para recalcular el encuadre sin reiniciar la transmisión.
            }
        })
        controlChannel = control

        val initialBitrate = bitrateController.start(
            captureConfig.targetWidth,
            captureConfig.targetHeight,
            negotiatedFps,
            settings.lowLatency
        )
        applyBitrate(initialBitrate)

        val offer = createOffer(connection)
        val answerSdp = client.exchangeOffer(offer)
        setRemoteDescription(connection, answerSdp)

        sendControl(ControlMessage(type = ControlMessage.TYPE_FIT, mode = preset.mode.name, zoom = preset.zoom, rotation = preset.rotationDegrees))
    }

    override fun updateFit(preset: FitPreset) {
        capturer?.updatePreset(preset)
        sendControl(
            ControlMessage(
                type = ControlMessage.TYPE_FIT,
                mode = preset.mode.name,
                zoom = preset.zoom,
                rotation = preset.rotationDegrees
            )
        )
    }

    override fun updateSettings(settings: StreamSettings) {
        if (!settings.audioEnabled) {
            audioSource?.dispose()
            audioSource = null
        }
    }

    override suspend fun disconnect() {
        controlChannel?.close()
        controlChannel = null
        capturer?.stopCapture()
        capturer?.dispose()
        capturer = null
        surfaceHelper?.dispose()
        surfaceHelper = null
        videoSource?.dispose()
        videoSource = null
        audioSource?.dispose()
        audioSource = null
        peerConnection?.close()
        peerConnection = null
        signaling?.close()
        signaling = null
        eglBase.release()
    }

    private fun sendControl(message: ControlMessage) {
        val channel = controlChannel ?: return
        val payload = json.encodeToString(ControlMessage.serializer(), message)
        channel.send(DataChannel.Buffer(ByteBuffer.wrap(payload.toByteArray()), false))
    }

    private fun createFactory(): PeerConnectionFactory {
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(context)
                .createInitializationOptions()
        )
        return PeerConnectionFactory.builder()
            .setVideoEncoderFactory(
                DefaultVideoEncoderFactory(eglBase.eglBaseContext, true, true)
            )
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(eglBase.eglBaseContext))
            .createPeerConnectionFactory()
    }

    private fun createOffer(connection: PeerConnection): String {
        val constraints = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "false"))
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "false"))
        }
        var sdp: String? = null
        val latch = java.util.concurrent.CountDownLatch(1)
        connection.createOffer(object : SdpObserver {
            override fun onCreateSuccess(description: SessionDescription) {
                sdp = description.description
                connection.setLocalDescription(NoopSdpObserver, description)
                latch.countDown()
            }

            override fun onCreateFailure(message: String) {
                latch.countDown()
            }

            override fun onSetSuccess() = Unit

            override fun onSetFailure(message: String) = Unit
        }, constraints)
        latch.await()
        return sdp ?: error("WebRTC no pudo generar la oferta SDP")
    }

    private fun setRemoteDescription(connection: PeerConnection, sdp: String) {
        val description = SessionDescription(SessionDescription.Type.ANSWER, sdp)
        val latch = java.util.concurrent.CountDownLatch(1)
        connection.setRemoteDescription(object : SdpObserver {
            override fun onCreateSuccess(description: SessionDescription) = Unit
            override fun onCreateFailure(message: String) = Unit
            override fun onSetSuccess() = latch.countDown()
            override fun onSetFailure(message: String) = latch.countDown()
        }, description)
        latch.await()
    }

    private fun applyBitrate(bitrate: Int) {
        val sender = peerConnection?.senders?.firstOrNull {
            it.track()?.kind() == MediaStreamTrack.VIDEO_TRACK_KIND
        } ?: return
        val parameters = sender.parameters
        parameters.encodings.firstOrNull()?.let { encoding ->
            encoding.maxBitrateBps = bitrate
            sender.setParameters(parameters)
        }
    }

    private fun peerObserver(): PeerConnection.Observer = object : PeerConnection.Observer {
        override fun onSignalingChange(state: PeerConnection.SignalingState) = Unit

        override fun onIceConnectionChange(state: PeerConnection.IceConnectionState) {
            if (state == PeerConnection.IceConnectionState.DISCONNECTED) {
                _stats.value = _stats.value.copy(rttMs = 0)
            }
        }

        override fun onIceConnectionReceivingChange(receiving: Boolean) = Unit

        override fun onIceGatheringChange(state: PeerConnection.IceGatheringState) = Unit

        override fun onIceCandidate(candidate: IceCandidate) = Unit

        override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>) = Unit

        override fun onAddStream(stream: MediaStream) = Unit

        override fun onRemoveStream(stream: MediaStream) = Unit

        override fun onDataChannel(channel: DataChannel) = Unit

        override fun onRenegotiationNeeded() = Unit

        override fun onAddTrack(receiver: RtpReceiver, streams: Array<out MediaStream>) = Unit
    }

    private object NoopSdpObserver : SdpObserver {
        override fun onCreateSuccess(description: SessionDescription) = Unit
        override fun onCreateFailure(message: String) = Unit
        override fun onSetSuccess() = Unit
        override fun onSetFailure(message: String) = Unit
    }

    private companion object {
        const val VIDEO_TRACK_ID = "video0"
        const val AUDIO_TRACK_ID = "audio0"
        const val STREAM_ID = "screencast"
        const val CONTROL_CHANNEL = "control"

        /**
         * En la misma red Wi-Fi no hace falta STUN/TURN: los candidatos locales
         * funcionan. Para redes con aislamiento de clientes hay que añadir un TURN.
         */
        fun iceServerList(): List<PeerConnection.IceServer> = emptyList()
    }
}