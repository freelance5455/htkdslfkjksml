package com.screencastpro.stream.cast

import android.content.Context
import com.google.android.gms.cast.framework.CastOptions
import com.google.android.gms.cast.framework.OptionsProvider
import com.google.android.gms.cast.framework.SessionProvider
import com.google.android.gms.cast.framework.CastReceiverOptions

/**
 * Receptor propio: la app web de cast-receiver/ desplegada en tu dominio y
 * registrada en la consola de desarrolladores de Google Cast.
 */
class CastOptionsProvider : OptionsProvider {

    override fun getCastOptions(context: Context): CastOptions {
        val receiverOptions = CastReceiverOptions.Builder(context)
            .setCustomReceiverApplicationId(RECEIVER_APPLICATION_ID)
            .build()

        return CastOptions.Builder()
            .setReceiverApplicationId(RECEIVER_APPLICATION_ID)
            .setCastOptions(receiverOptions)
            .build()
    }

    override fun getAdditionalSessionProviders(context: Context): List<SessionProvider>? = null

    companion object {
        /** Sustituir por el Application ID que devuelve la consola de Google Cast. */
        const val RECEIVER_APPLICATION_ID = "REEMPLAZA_CON_TU_APP_ID"

        /** Namespace del canal de control propio (encuadre, zoom, rotación). */
        const val NAMESPACE = "urn:x-cast:com.screencastpro.control"
    }
}