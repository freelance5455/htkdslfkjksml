package com.screencastpro.discovery

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import com.screencastpro.shared.model.DeviceDescriptor

/**
 * Descubrimiento por mDNS (NsdManager). Android no expone una API de "buscar TVs":
 * se consultan los servicios estándar que anuncian los receptores.
 */
class NsdDiscovery(private val context: Context) {

    interface Callback {
        fun onServiceFound(descriptor: DeviceDescriptor)
        fun onServiceLost(id: String)
    }

    private val nsdManager: NsdManager = context.getSystemService(NsdManager::class.java)
    private val listeners = mutableListOf<NsdManager.DiscoveryListener>()

    fun start(callback: Callback) {
        discover(CAST_SERVICE, callback)
        discover(RECEIVER_SERVICE, callback)
        discover(AMAZON_SCREEN_SERVICE, callback)
    }

    fun stop() {
        listeners.forEach { listener ->
            runCatching { nsdManager.stopServiceDiscovery(listener) }
        }
        listeners.clear()
    }

    private fun discover(serviceType: String, callback: Callback) {
        val listener = object : NsdManager.DiscoveryListener {
            override fun onStartDiscoveryFailed(type: String, errorCode: Int) = Unit

            override fun onStopDiscoveryFailed(type: String, errorCode: Int) = Unit

            override fun onDiscoveryStarted(type: String) = Unit

            override fun onDiscoveryStopped(type: String) = Unit

            override fun onServiceLost(serviceInfo: NsdServiceInfo) {
                callback.onServiceLost(serviceInfo.serviceName)
            }

            override fun onServiceFound(serviceInfo: NsdServiceInfo) {
                if (!serviceInfo.serviceType.contains(serviceType)) return
                resolve(serviceInfo, serviceType, callback)
            }
        }
        listeners += listener
        runCatching { nsdManager.discoverServices(serviceType, NsdManager.PROTOCOL_DNS_SD, listener) }
    }

    private fun resolve(
        serviceInfo: NsdServiceInfo,
        serviceType: String,
        callback: Callback
    ) {
        val resolveListener = object : NsdManager.ResolveListener {
            override fun onResolveFailed(info: NsdServiceInfo, errorCode: Int) = Unit

            override fun onServiceResolved(info: NsdServiceInfo) {
                val host = info.host?.hostAddress ?: return
                callback.onServiceFound(
                    DeviceDescriptor(
                        id = serviceType + ":" + info.serviceName,
                        name = info.serviceName,
                        type = DeviceTypeResolver.resolve(serviceType, info.serviceName),
                        host = host,
                        port = info.port,
                        transports = DeviceTypeResolver.transportsFor(
                            DeviceTypeResolver.resolve(serviceType, info.serviceName)
                        )
                    )
                )
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            // Android 14: resolveService queda obsoleto a favor de registerServiceInfoCallback.
            val infoCallback = NsdManager.ServiceInfoCallback { info ->
                val host = info.hostAddresses.firstOrNull()?.hostAddress ?: return@ServiceInfoCallback
                callback.onServiceFound(
                    DeviceDescriptor(
                        id = serviceType + ":" + info.serviceName,
                        name = info.serviceName,
                        type = DeviceTypeResolver.resolve(serviceType, info.serviceName),
                        host = host,
                        port = info.port,
                        transports = DeviceTypeResolver.transportsFor(
                            DeviceTypeResolver.resolve(serviceType, info.serviceName)
                        )
                    )
                )
            }
            runCatching {
                nsdManager.registerServiceInfoCallback(serviceInfo, { it.run() }, infoCallback)
            }
        } else {
            @Suppress("DEPRECATION")
            runCatching { nsdManager.resolveService(serviceInfo, resolveListener) }
        }
    }

    companion object {
        const val CAST_SERVICE = "_googlecast._tcp"
        const val RECEIVER_SERVICE = "_screencastpro._tcp"
        // Fire TV anuncia su pantalla (Fling / Wi-Fi Display) con este servicio.
        const val AMAZON_SCREEN_SERVICE = "_amzn-wplay._tcp"
    }
}

/** Reglas de clasificación compartidas por el descubrimiento. */
object DeviceTypeResolver {
    fun resolve(serviceType: String, name: String): com.screencastpro.shared.model.DeviceType {
        val normalized = name.lowercase()
        val receiver = serviceType.contains(NsdDiscovery.RECEIVER_SERVICE)
        val amazonScreen = serviceType.contains(NsdDiscovery.AMAZON_SCREEN_SERVICE)
        return when {
            // Fire TV expone su pantalla mediante el servicio de Amazon.
            amazonScreen -> com.screencastpro.shared.model.DeviceType.FIRE_TV
            receiver && normalized.contains("fire") -> com.screencastpro.shared.model.DeviceType.FIRE_TV
            receiver && normalized.contains("google tv") -> com.screencastpro.shared.model.DeviceType.GOOGLE_TV
            receiver && normalized.contains("android tv") -> com.screencastpro.shared.model.DeviceType.ANDROID_TV
            receiver -> com.screencastpro.shared.model.DeviceType.SCREENCAST_PRO
            normalized.contains("chromecast") -> com.screencastpro.shared.model.DeviceType.CHROMECAST
            normalized.contains("hisense") -> com.screencastpro.shared.model.DeviceType.HISENSE
            normalized.contains("android tv") -> com.screencastpro.shared.model.DeviceType.ANDROID_TV
            normalized.contains("google tv") -> com.screencastpro.shared.model.DeviceType.GOOGLE_TV
            normalized.contains("fire") -> com.screencastpro.shared.model.DeviceType.FIRE_TV
            else -> com.screencastpro.shared.model.DeviceType.GOOGLE_CAST
        }
    }

    fun transportsFor(type: com.screencastpro.shared.model.DeviceType): Set<com.screencastpro.shared.model.TransportKind> =
        when (type) {
            com.screencastpro.shared.model.DeviceType.SCREENCAST_PRO ->
                setOf(
                    com.screencastpro.shared.model.TransportKind.WEBRTC,
                    com.screencastpro.shared.model.TransportKind.DIRECT_H264
                )

            com.screencastpro.shared.model.DeviceType.MIRACAST ->
                setOf(com.screencastpro.shared.model.TransportKind.SYSTEM_MIRRORING)

            com.screencastpro.shared.model.DeviceType.CHROMECAST,
            com.screencastpro.shared.model.DeviceType.GOOGLE_CAST,
            com.screencastpro.shared.model.DeviceType.HISENSE ->
                setOf(
                    com.screencastpro.shared.model.TransportKind.WEBRTC,
                    com.screencastpro.shared.model.TransportKind.CAST_CONTROL,
                    com.screencastpro.shared.model.TransportKind.SYSTEM_MIRRORING
                )

            else -> setOf(
                com.screencastpro.shared.model.TransportKind.WEBRTC,
                com.screencastpro.shared.model.TransportKind.DIRECT_H264,
                com.screencastpro.shared.model.TransportKind.SYSTEM_MIRRORING
            )
        }
}