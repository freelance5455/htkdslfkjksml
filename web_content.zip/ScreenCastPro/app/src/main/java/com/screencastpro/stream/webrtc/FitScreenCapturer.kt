package com.screencastpro.stream.webrtc

import android.content.Context
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.projection.MediaProjection
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.os.Handler
import android.view.Surface
import com.screencastpro.capture.CaptureConfig
import com.screencastpro.shared.graphics.DisplayFitCalculator
import com.screencastpro.shared.graphics.FitPreset
import org.webrtc.CapturerObserver
import org.webrtc.EglBase
import org.webrtc.SurfaceTextureHelper
import org.webrtc.VideoCapturer
import org.webrtc.VideoFrame
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Capturador propio en lugar de ScreenCapturerAndroid, por una razón concreta:
 * aquí el fotograma pasa por OpenGL antes de llegar al codificador, y ahí se
 * aplican los modos de pantalla, el zoom y la rotación.
 *
 *   MediaProjection -> VirtualDisplay -> textura -> OpenGL (encuadre) -> VideoFrame -> WebRTC
 */
class FitScreenCapturer(
    private val mediaProjection: MediaProjection,
    private val captureConfig: CaptureConfig,
    private val eglBase: EglBase
) : VideoCapturer {

    private var helper: SurfaceTextureHelper? = null
    private var observer: CapturerObserver? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var sourceTexture: SurfaceTexture? = null
    private var sourceTextureId = 0
    private var framebufferId = 0
    private var program = 0
    private var positionHandle = 0
    private var texCoordHandle = 0
    private var textureMatrixHandle = 0
    private val textureMatrix = FloatArray(16)
    private val framePending = AtomicBoolean(false)
    private val vertexBuffer: FloatBuffer = createBuffer(8)
    private val texCoordBuffer: FloatBuffer = createBuffer(8)

    @Volatile
    private var preset = FitPreset()

    override fun initialize(
        surfaceTextureHelper: SurfaceTextureHelper,
        applicationContext: Context,
        capturerObserver: CapturerObserver
    ) {
        helper = surfaceTextureHelper
        observer = capturerObserver

        surfaceTextureHelper.handler.post {
            eglBase.makeCurrent()
            program = buildProgram()
            positionHandle = GLES20.glGetAttribLocation(program, "aPosition")
            texCoordHandle = GLES20.glGetAttribLocation(program, "aTexCoord")
            textureMatrixHandle = GLES20.glGetUniformLocation(program, "uTexMatrix")
            sourceTextureId = createExternalTexture()
            sourceTexture = SurfaceTexture(sourceTextureId).apply {
                setDefaultBufferSize(captureConfig.sourceWidth, captureConfig.sourceHeight)
                setOnFrameAvailableListener { requestFrame() }
            }
            val framebuffers = IntArray(1)
            GLES20.glGenFramebuffers(1, framebuffers, 0)
            framebufferId = framebuffers[0]
        }
    }

    override fun startCapture(width: Int, height: Int, fps: Int) {
        helper?.handler?.post {
            val texture = sourceTexture ?: return@post
            virtualDisplay = mediaProjection.createVirtualDisplay(
                "ScreenCastProCapture",
                captureConfig.sourceWidth,
                captureConfig.sourceHeight,
                captureConfig.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                Surface(texture),
                null,
                null
            )
            observer?.onCapturerStarted(true)
        }
    }

    override fun stopCapture() {
        helper?.handler?.post {
            virtualDisplay?.release()
            virtualDisplay = null
            observer?.onCapturerStopped()
        }
    }

    override fun changeCaptureFormat(width: Int, height: Int, fps: Int) = Unit

    override fun dispose() {
        helper?.handler?.post {
            virtualDisplay?.release()
            virtualDisplay = null
            sourceTexture?.release()
            sourceTexture = null
            if (sourceTextureId != 0) GLES20.glDeleteTextures(1, intArrayOf(sourceTextureId), 0)
            if (framebufferId != 0) GLES20.glDeleteFramebuffers(1, intArrayOf(framebufferId), 0)
            if (program != 0) GLES20.glDeleteProgram(program)
        }
    }

    override fun isScreencast(): Boolean = true

    /** El panel de controles llama aquí al cambiar de modo o mover el zoom. */
    fun updatePreset(newPreset: FitPreset) {
        preset = newPreset
    }

    private fun requestFrame() {
        if (!framePending.compareAndSet(false, true)) return
        helper?.handler?.post {
            framePending.set(false)
            drawFrame()
        }
    }

    private fun drawFrame() {
        val texture = sourceTexture ?: return
        val capturerObserver = observer ?: return
        val surfaceHelper = helper ?: return
        eglBase.makeCurrent()

        texture.updateTexImage()
        texture.getTransformMatrix(textureMatrix)

        // WebRTC presta una textura del tamaño de salida; dibujamos ahí con el
        // encuadre ya aplicado y le entregamos el fotograma tal cual.
        val buffer = surfaceHelper.createTextureBuffer(
            captureConfig.targetWidth,
            captureConfig.targetHeight,
            Matrix().apply { reset() }
        )

        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, framebufferId)
        GLES20.glFramebufferTexture2D(
            GLES20.GL_FRAMEBUFFER,
            GLES20.GL_COLOR_ATTACHMENT0,
            GLES20.GL_TEXTURE_2D,
            buffer.textureId,
            0
        )
        GLES20.glViewport(0, 0, captureConfig.targetWidth, captureConfig.targetHeight)
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        GLES20.glUseProgram(program)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, sourceTextureId)

        writeQuad(
            DisplayFitCalculator.compute(
                sourceWidth = captureConfig.sourceWidth,
                sourceHeight = captureConfig.sourceHeight,
                targetWidth = captureConfig.targetWidth,
                targetHeight = captureConfig.targetHeight,
                preset = preset
            )
        )

        GLES20.glEnableVertexAttribArray(positionHandle)
        GLES20.glVertexAttribPointer(positionHandle, 2, GLES20.GL_FLOAT, false, 0, vertexBuffer)
        GLES20.glEnableVertexAttribArray(texCoordHandle)
        GLES20.glVertexAttribPointer(texCoordHandle, 2, GLES20.GL_FLOAT, false, 0, texCoordBuffer)
        GLES20.glUniformMatrix4fv(textureMatrixHandle, 1, false, textureMatrix, 0)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(positionHandle)
        GLES20.glDisableVertexAttribArray(texCoordHandle)
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)

        capturerObserver.onFrameCaptured(
            VideoFrame(buffer, 0, preset.rotationDegrees, texture.timestamp)
        )
    }

    private fun writeQuad(transform: com.screencastpro.shared.graphics.FitTransform) {
        val targetWidth = captureConfig.targetWidth
        val targetHeight = captureConfig.targetHeight

        val left = transform.viewportX.toFloat() / targetWidth * 2f - 1f
        val right = (transform.viewportX + transform.viewportWidth).toFloat() / targetWidth * 2f - 1f
        val top = 1f - transform.viewportY.toFloat() / targetHeight * 2f
        val bottom = 1f - (transform.viewportY + transform.viewportHeight).toFloat() / targetHeight * 2f

        vertexBuffer.clear()
        vertexBuffer.put(floatArrayOf(left, bottom, right, bottom, left, top, right, top)).position(0)

        val u0 = transform.sourceX.toFloat() / captureConfig.sourceWidth
        val u1 = (transform.sourceX + transform.sourceWidth).toFloat() / captureConfig.sourceWidth
        val v0 = transform.sourceY.toFloat() / captureConfig.sourceHeight
        val v1 = (transform.sourceY + transform.sourceHeight).toFloat() / captureConfig.sourceHeight

        texCoordBuffer.clear()
        texCoordBuffer.put(floatArrayOf(u0, v1, u1, v1, u0, v0, u1, v0)).position(0)
    }

    private fun createExternalTexture(): Int {
        val textures = IntArray(1)
        GLES20.glGenTextures(1, textures, 0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, textures[0])
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        return textures[0]
    }

    private fun buildProgram(): Int {
        val vertex = compile(
            GLES20.GL_VERTEX_SHADER,
            "attribute vec4 aPosition; attribute vec2 aTexCoord; uniform mat4 uTexMatrix;" +
                "varying vec2 vTexCoord;" +
                "void main() { gl_Position = aPosition; vTexCoord = (uTexMatrix * vec4(aTexCoord, 0.0, 1.0)).xy; }"
        )
        val fragment = compile(
            GLES20.GL_FRAGMENT_SHADER,
            "#extension GL_OES_EGL_image_external : require precision mediump float;" +
                "uniform samplerExternalOES uTexture; varying vec2 vTexCoord;" +
                "void main() { gl_FragColor = texture2D(uTexture, vTexCoord); }"
        )
        val id = GLES20.glCreateProgram()
        GLES20.glAttachShader(id, vertex)
        GLES20.glAttachShader(id, fragment)
        GLES20.glLinkProgram(id)
        return id
    }

    private fun compile(type: Int, source: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, source)
        GLES20.glCompileShader(shader)
        return shader
    }

    private fun createBuffer(size: Int): FloatBuffer =
        ByteBuffer.allocateDirect(size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
}