package com.screencastpro.stream.miracast

import android.content.Context
import com.screencastpro.capture.CaptureConfig
import com.screencastpro.shared.graphics.FitPreset
import com.screencastpro.shared.model.DeviceDescriptor
import com.screencastpro.shared.model.StreamSettings
import com.screencastpro.shared.model.StreamStats
import com.screencastpro.shared.model.TransportKind
import com.screencastpro.stream.StreamTransport
import com.screencastpro.stream.system.SystemMirroringLauncher
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Miracast / Wi-Fi Display.
 *
 * LIMITACIÓN EXACTA: desde Android 8 no existe API pública para que una app de
 * terceros cree una sesión de emisión Wi-Fi Display. La emisión la compone el
 * sistema y solo algunos fabricantes exponen su panel (Fire TV y varias Hisense
 * lo incluyen). Por eso este transporte NO simula la duplicación: deja la sesión
 * marcada como gestionada por el sistema y entrega el intent que abre el panel
 * real. Si el dispositivo no lo expone, falla con un mensaje claro.
 *
 * ALTERNATIVA YA PREPARADA: instalar la app receptora (:receiver) en el
 * dispositivo y transmitir por WebRTC o Direct H.264, que sí son rutas
 * completas controladas por la app (con encuadre, zoom y rotación incluidos).
 *
 * CUANDO HAYA API: en un dispositivo con privilegios de sistema basta sustituir
 * SystemMirroringLauncher.open por la llamada real de Wi-Fi Display; nada más de
 * la aplicación cambia.
 *
 * EFECTOS SECUNDARIOS DEL CAMINO DEL SISTEMA:
 * * los modos de encuadre no se pueden aplicar (el vídeo lo compone el sistema);
 * * el audio lo decide el sistema;
 * * no hay estadísticas de bitrate ni de FPS.
 * La interfaz muestra ese estado en vez de aparentar que controla la transmisión.
 */
class MiracastTransport(private val context: Context) : StreamTransport {

    override val kind: TransportKind = TransportKind.SYSTEM_MIRRORING

    private val _stats = MutableStateFlow(StreamStats())
    override val stats: StateFlow<StreamStats> = _stats.asStateFlow()

    private val _handedToSystem = MutableStateFlow(false)

    /** true cuando la duplicación la lleva el sistema: la app no encuadra ni mide. */
    val handedToSystem: StateFlow<Boolean> = _handedToSystem.asStateFlow()

    override suspend fun connect(
        device: DeviceDescriptor,
        settings: StreamSettings,
        captureConfig: CaptureConfig,
        preset: FitPreset
    ) {
        val opened = SystemMirroringLauncher.open(context)
        _handedToSystem.value = opened
        if (!opened) {
            error(
                "Este dispositivo no expone el panel de pantalla inalámbrica. " +
                    "Instala la app receptora para transmitir por WebRTC."
            )
        }
    }

    override fun updateFit(preset: FitPreset) {
        // No aplicable: el sistema compone el vídeo. La interfaz lo indica.
    }

    override fun updateSettings(settings: StreamSettings) = Unit

    override suspend fun disconnect() {
        _handedToSystem.value = false
    }
}