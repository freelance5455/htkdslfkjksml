package com.screencastpro.capture

import android.content.Context
import android.os.Build
import android.util.DisplayMetrics
import android.view.WindowManager
import com.screencastpro.shared.model.StreamQuality

data class CaptureConfig(
    val sourceWidth: Int,
    val sourceHeight: Int,
    val densityDpi: Int,
    val targetWidth: Int,
    val targetHeight: Int,
    val fps: Int,
    val rotationDegrees: Int
) {
    val isPortrait: Boolean get() = sourceHeight >= sourceWidth

    companion object {

        fun fromDisplay(
            context: Context,
            quality: StreamQuality,
            fps: Int,
            rotationDegrees: Int
        ): CaptureConfig {
            val windowManager = context.getSystemService(WindowManager::class.java)
            val displayMetrics = DisplayMetrics()

            val sourceWidth: Int
            val sourceHeight: Int
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val bounds = windowManager.currentWindowMetrics.bounds
                sourceWidth = bounds.width()
                sourceHeight = bounds.height()
            } else {
                @Suppress("DEPRECATION")
                windowManager.defaultDisplay.getRealMetrics(displayMetrics)
                sourceWidth = displayMetrics.widthPixels
                sourceHeight = displayMetrics.heightPixels
            }

            val portrait = sourceHeight >= sourceWidth
            val shortSide = quality.shortSide
            val longRatio = if (portrait) {
                sourceHeight.toFloat() / sourceWidth
            } else {
                sourceWidth.toFloat() / sourceHeight
            }
            val longSide = (shortSide * longRatio).toInt()
            val even: (Int) -> Int = { value -> if (value % 2 == 0) value else value + 1 }

            // La salida conserva la orientación del teléfono: 720p vertical es 720 x 1600,
            // no 1280 x 720. Así el receptor nunca recibe un fotograma girado.
            return CaptureConfig(
                sourceWidth = sourceWidth,
                sourceHeight = sourceHeight,
                densityDpi = context.resources.displayMetrics.densityDpi,
                targetWidth = even(if (portrait) shortSide else longSide),
                targetHeight = even(if (portrait) longSide else shortSide),
                fps = fps,
                rotationDegrees = rotationDegrees
            )
        }

        fun currentRotation(context: Context): Int {
            val windowManager = context.getSystemService(WindowManager::class.java)
            @Suppress("DEPRECATION")
            return when (windowManager.defaultDisplay?.rotation) {
                android.view.Surface.ROTATION_90 -> 90
                android.view.Surface.ROTATION_180 -> 180
                android.view.Surface.ROTATION_270 -> 270
                else -> 0
            }
        }
    }
}