package com.screencastpro.stream.direct

import android.content.Context
import android.media.projection.MediaProjection
import com.screencastpro.capture.CaptureConfig
import com.screencastpro.capture.MediaProjectionController
import com.screencastpro.encoder.AvcNalUnits
import com.screencastpro.encoder.CodecSelection
import com.screencastpro.encoder.VideoEncoder
import com.screencastpro.shared.graphics.FitPreset
import com.screencastpro.shared.model.DeviceDescriptor
import com.screencastpro.shared.model.StreamSettings
import com.screencastpro.shared.model.StreamStats
import com.screencastpro.shared.model.TransportKind
import com.screencastpro.stream.StreamTransport
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.BufferedOutputStream
import java.net.ServerSocket
import java.net.Socket
import java.nio.ByteBuffer

/**
 * Protocolo propio "ScreenCast Pro Direct" (H.264 Annex-B sobre TCP).
 *
 * Para qué sirve: televisores o cajas que aceptan nuestra app receptora pero donde
 * WebRTC está bloqueado por la red o por el firmware. El receptor abre el puerto
 * 8766, se envían los fotogramas y él los decodifica con MediaCodec.
 *
 * Formato de cada paquete: 4 bytes de longitud (big-endian) + fotograma Annex-B.
 * El encuadre ya viene aplicado: los fotogramas salen del transformador OpenGL.
 *
 * Límite conocido: solo vídeo. El audio del sistema requiere el transporte WebRTC,
 * porque este protocolo no negocia relojes ni jitter buffer.
 */
class DirectH264Transport(
    private val context: Context,
    private val projection: MediaProjection,
    private val captureController: MediaProjectionController
) : StreamTransport {

    override val kind: TransportKind = TransportKind.DIRECT_H264

    private val _stats = MutableStateFlow(StreamStats())
    override val stats: StateFlow<StreamStats> = _stats.asStateFlow()

    private val codecSelection = CodecSelection()
    private val encoder = VideoEncoder(codecSelection)
    private var serverSocket: ServerSocket? = null
    private var client: Socket? = null
    private var streaming = false

    override suspend fun connect(
        device: DeviceDescriptor,
        settings: StreamSettings,
        captureConfig: CaptureConfig,
        preset: FitPreset
    ) {
        stopServer()

        val fps = codecSelection.negotiatedFps(
            captureConfig.targetWidth,
            captureConfig.targetHeight,
            captureConfig.fps
        )
        val bitrate = captureConfig.targetWidth * captureConfig.targetHeight * fps / 4

        val server = ServerSocket(PORT)
        serverSocket = server
        streaming = true

        Thread {
            runCatching {
                val socket = server.accept()
                client = socket
                val output = BufferedOutputStream(socket.getOutputStream())
                // Saludo: el receptor comprueba que es nuestro protocolo.
                output.write(("SCP1 " + captureConfig.targetWidth + "x" + captureConfig.targetHeight + " " + fps + "fps
").toByteArray())
                output.flush()

                val encoderSurface = encoder.start(
                    captureConfig.targetWidth,
                    captureConfig.targetHeight,
                    fps,
                    bitrate,
                    settings.lowLatency
                )
                // Cierra el camino "captura -> OpenGL -> H.264": el transformador aplica
                // el encuadre y luego dibuja sobre la superficie del codificador.
                captureController.attachEncoderSurface(
                    encoderSurface,
                    captureConfig.targetWidth,
                    captureConfig.targetHeight
                )
                captureController.start(
                    projection,
                    captureConfig,
                    onReady = { /* el transformador ya renderiza en el codificador */ },
                    onRotationChanged = { rotation ->
                        captureController.reconfigure(captureConfig.copy(rotationDegrees = rotation))
                        encoder.requestKeyFrame()
                    }
                )
                encoder.requestKeyFrame()

                // SPS/PPS primero: sin ellos el receptor no puede configurar el decodificador.
                val csd = waitForConfigurationData()
                if (csd != null) writePacket(output, AvcNalUnits.asAnnexB(csd))

                while (streaming) {
                    encoder.drain { buffer: ByteBuffer, info: android.media.MediaCodec.BufferInfo ->
                        writePacket(output, AvcNalUnits.toAnnexB(buffer, info))
                    }
                    Thread.sleep(2)
                }
            }.onFailure {
                _stats.value = _stats.value.copy(fps = 0)
            }
        }.start()

        _stats.value = StreamStats(fps = fps, bitrateKbps = bitrate / 1000)
    }

    override fun updateFit(preset: FitPreset) {
        // El encuadre lo aplica el transformador antes de codificar, así que basta
        // con pedir un fotograma clave para que la TV refresque la imagen completa.
        encoder.requestKeyFrame()
    }

    override fun updateSettings(settings: StreamSettings) = Unit

    private fun writePacket(output: BufferedOutputStream, payload: ByteArray) {
        val length = payload.size
        output.write(
            byteArrayOf(
                (length ushr 24).toByte(),
                (length ushr 16).toByte(),
                (length ushr 8).toByte(),
                length.toByte()
            )
        )
        output.write(payload)
        output.flush()
    }

    /** Espera a que el codificador entregue SPS/PPS (hasta 500 ms). */
    private fun waitForConfigurationData(): ByteArray? {
        var waited = 0
        while (waited < 500) {
            encoder.configurationData?.let { return it }
            encoder.drain { _, _ -> }
            Thread.sleep(10)
            waited += 10
        }
        return encoder.configurationData
    }

    override suspend fun disconnect() {
        stopServer()
        encoder.stop()
        _stats.value = StreamStats()
    }

    private fun stopServer() {
        streaming = false
        runCatching { client?.close() }
        runCatching { serverSocket?.close() }
        client = null
        serverSocket = null
    }

    companion object {
        const val PORT = 8766
    }
}