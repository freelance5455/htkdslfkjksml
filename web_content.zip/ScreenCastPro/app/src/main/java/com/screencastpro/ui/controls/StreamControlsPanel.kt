package com.screencastpro.ui.controls

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.screencastpro.shared.graphics.FitMode
import com.screencastpro.shared.graphics.FitPreset
import com.screencastpro.shared.model.StreamStats

/**
 * Controles que se muestran durante la transmisión. Cada acción se aplica al
 * flujo de vídeo (lo hace StreamSessionManager -> transporte -> motor gráfico),
 * no al tamaño de un elemento de esta pantalla.
 */
@Composable
fun StreamControlsPanel(
    preset: FitPreset,
    stats: StreamStats,
    fullscreen: Boolean,
    onModeChange: (FitMode) -> Unit,
    onZoomChange: (Float) -> Unit,
    onZoomIn: () -> Unit,
    onZoomOut: () -> Unit,
    onReset: () -> Unit,
    onRotate: () -> Unit,
    onToggleFullscreen: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(20.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Modo de pantalla", style = MaterialTheme.typography.titleMedium)

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(top = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FitMode.entries.forEach { mode ->
                    AssistChip(
                        onClick = { onModeChange(mode) },
                        label = { Text(mode.label) },
                        colors = AssistChipDefaults.assistChipColors(
                            containerColor = if (preset.mode == mode) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant
                            }
                        )
                    )
                }
            }

            Row(
                modifier = Modifier.padding(top = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onZoomOut) {
                    Icon(Icons.Filled.ZoomOut, contentDescription = "Alejar")
                }
                Slider(
                    value = preset.zoom,
                    onValueChange = onZoomChange,
                    valueRange = 1f..3f,
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 8.dp)
                )
                IconButton(onClick = onZoomIn) {
                    Icon(Icons.Filled.ZoomIn, contentDescription = "Ampliar")
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Zoom " + (preset.zoom * 100).toInt() + "%  ·  " + preset.rotationDegrees + "°",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onRotate) {
                        Icon(Icons.Filled.RotateRight, contentDescription = "Rotar pantalla")
                    }
                    IconButton(onClick = onToggleFullscreen) {
                        Icon(
                            Icons.Filled.Fullscreen,
                            contentDescription = "Pantalla completa",
                            tint = if (fullscreen) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                MaterialTheme.colorScheme.onSurface
                            }
                        )
                    }
                    IconButton(onClick = onReset) {
                        Icon(Icons.Filled.Refresh, contentDescription = "Restablecer")
                    }
                }
            }

            Text(
                text = stats.fps.toString() + " FPS  ·  " + stats.bitrateKbps + " kbps  ·  " +
                    stats.rttMs + " ms",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}