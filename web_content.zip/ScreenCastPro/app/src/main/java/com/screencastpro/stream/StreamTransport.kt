package com.screencastpro.stream

import com.screencastpro.capture.CaptureConfig
import com.screencastpro.shared.graphics.FitPreset
import com.screencastpro.shared.model.DeviceDescriptor
import com.screencastpro.shared.model.StreamSettings
import com.screencastpro.shared.model.StreamStats
import com.screencastpro.shared.model.TransportKind
import kotlinx.coroutines.flow.StateFlow

/**
 * Un transporte es un protocolo concreto de envío. Para añadir Fire TV por un
 * protocolo nuevo basta con implementar esta interfaz y registrarlo en
 * StreamSessionManager: la captura, el encuadre y la interfaz no cambian.
 */
interface StreamTransport {

    val kind: TransportKind

    val stats: StateFlow<StreamStats>

    suspend fun connect(
        device: DeviceDescriptor,
        settings: StreamSettings,
        captureConfig: CaptureConfig,
        preset: FitPreset
    )

    /** Encuadre en vivo: debe afectar al vídeo que ya se está enviando. */
    fun updateFit(preset: FitPreset)

    fun updateSettings(settings: StreamSettings)

    suspend fun disconnect()
}