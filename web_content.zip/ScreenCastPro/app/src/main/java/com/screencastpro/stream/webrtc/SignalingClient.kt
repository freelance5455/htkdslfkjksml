package com.screencastpro.stream.webrtc

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

/**
 * Señalización mínima por HTTP.
 *
 * El receptor (Android TV / Google TV / Fire TV) expone un servidor local con dos
 * rutas: POST /offer devuelve la respuesta SDP y POST /candidate recibe los
 * candidatos ICE del emisor. Sin servidores externos y sin configuración manual:
 * basta con estar en la misma red Wi-Fi.
 */
class SignalingClient(private val baseUrl: String) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(4, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .build()

    suspend fun exchangeOffer(offerSdp: String): String = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url(trimmed() + "/offer")
            .post(offerSdp.toRequestBody(JSON))
            .build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                error("El receptor rechazó la oferta: " + response.code)
            }
            response.body?.string().orEmpty()
        }
    }

    suspend fun sendCandidates(candidatesJson: String) = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url(trimmed() + "/candidate")
            .post(candidatesJson.toRequestBody(JSON))
            .build()
        client.newCall(request).execute().use { it.close() }
    }

    fun close() {
        client.dispatcher.executorService.shutdown()
        client.connectionPool.evictAll()
    }

    private fun trimmed(): String = baseUrl.trimEnd('/')

    companion object {
        private val JSON = "application/json".toMediaType()

        /** URL por defecto cuando el usuario no ha configurado un servidor propio. */
        fun defaultUrlFor(host: String, port: Int = DEFAULT_PORT): String =
            "http://" + host + ":" + port

        const val DEFAULT_PORT = 8765
    }
}