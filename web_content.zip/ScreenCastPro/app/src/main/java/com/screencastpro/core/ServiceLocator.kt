package com.screencastpro.core

import android.content.Context
import com.screencastpro.discovery.DiscoveryManager
import com.screencastpro.settings.StreamPreferences
import com.screencastpro.stream.StreamSessionManager

/**
 * Contenedor de dependencias sin framework: suficiente para este tamaño y sin
 * generar código en tiempo de compilación.
 */
object ServiceLocator {

    private var appContext: Context? = null

    fun install(context: Context) {
        appContext = context.applicationContext
    }

    fun requireContext(): Context = requireNotNull(appContext) {
        "ServiceLocator.install() debe llamarse en Application.onCreate()"
    }

    val preferences: StreamPreferences by lazy { StreamPreferences(requireContext()) }

    val discovery: DiscoveryManager by lazy { DiscoveryManager(requireContext()) }

    val session: StreamSessionManager by lazy {
        StreamSessionManager(requireContext(), preferences, discovery)
    }
}