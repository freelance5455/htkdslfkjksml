package com.screencastpro.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.screencastpro.core.ServiceLocator
import com.screencastpro.discovery.DiscoveryManager
import com.screencastpro.settings.StreamPreferences
import com.screencastpro.shared.graphics.FitMode
import com.screencastpro.shared.graphics.FitPreset
import com.screencastpro.shared.model.ConnectionState
import com.screencastpro.shared.model.DeviceDescriptor
import com.screencastpro.shared.model.StreamSettings
import com.screencastpro.shared.model.StreamStats
import com.screencastpro.stream.StreamSessionManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class HomeViewModel(
    private val session: StreamSessionManager = ServiceLocator.session,
    private val discovery: DiscoveryManager = ServiceLocator.discovery,
    private val preferences: StreamPreferences = ServiceLocator.preferences
) : ViewModel() {

    val devices: StateFlow<List<DeviceDescriptor>> = discovery.devices
    val connectionState: StateFlow<ConnectionState> = session.state
    val stats: StateFlow<StreamStats> = session.stats

    private val _selectedDevice = MutableStateFlow<DeviceDescriptor?>(null)
    val selectedDevice: StateFlow<DeviceDescriptor?> = _selectedDevice.asStateFlow()

    private val _settings = MutableStateFlow(StreamSettings())
    val settings: StateFlow<StreamSettings> = _settings.asStateFlow()

    private val _fitPreset = MutableStateFlow(FitPreset())
    val fitPreset: StateFlow<FitPreset> = _fitPreset.asStateFlow()

    private val _fullscreenOnTv = MutableStateFlow(false)
    val fullscreenOnTv: StateFlow<Boolean> = _fullscreenOnTv.asStateFlow()

    init {
        discovery.start()
        viewModelScope.launch {
            preferences.settings.collect { _settings.value = it }
        }
    }

    fun refreshDevices() {
        _selectedDevice.value = null
        discovery.refresh()
    }

    fun select(device: DeviceDescriptor) {
        _selectedDevice.value = device
        viewModelScope.launch {
            // Se recupera la última configuración usada con esa TV.
            _fitPreset.value = preferences.fitPreset(device.id)
        }
        session.select(device)
    }

    /** Tras autorizar la captura, la sesión arranca con el dispositivo elegido. */
    fun startStreaming() {
        val device = _selectedDevice.value ?: return
        session.start(device)
    }

    fun stopStreaming() {
        session.stop()
    }

    fun setMode(mode: FitMode) {
        applyFit(_fitPreset.value.copy(mode = mode))
    }

    fun setZoom(zoom: Float) {
        applyFit(_fitPreset.value.copy(mode = FitMode.ZOOM, zoom = zoom))
    }

    fun zoomIn() = setZoom((_fitPreset.value.zoom + ZOOM_STEP).coerceAtMost(MAX_ZOOM))

    fun zoomOut() = setZoom((_fitPreset.value.zoom - ZOOM_STEP).coerceAtLeast(1f))

    fun resetFit() {
        applyFit(FitPreset())
        _fullscreenOnTv.value = false
    }

    fun rotate() {
        val next = (_fitPreset.value.rotationDegrees + 90) % 360
        applyFit(_fitPreset.value.copy(rotationDegrees = next))
    }

    fun toggleFullscreenOnTv() {
        _fullscreenOnTv.value = !_fullscreenOnTv.value
        applyFit(_fitPreset.value)
    }

    private fun applyFit(preset: FitPreset) {
        _fitPreset.value = preset
        session.updateFit(preset)
    }

    fun updateSettings(transform: (StreamSettings) -> StreamSettings) {
        val next = transform(_settings.value)
        _settings.value = next
        session.updateSettings(next)
    }

    private companion object {
        const val ZOOM_STEP = 0.1f
        const val MAX_ZOOM = 3f
    }
}