package com.screencastpro.stream.cast

import com.google.android.gms.cast.Cast
import com.google.android.gms.cast.CastDevice
import com.google.android.gms.cast.framework.CastSession
import com.screencastpro.shared.model.ControlMessage
import kotlinx.serialization.json.Json

/**
 * Canal de control Cast.
 *
 * Es la parte que Google sí permite a una app de terceros: conectar con el
 * receptor remoto y hablar con él. Lo que la API pública NO permite es crear el
 * espejo de pantalla del sistema; por eso este transporte se apoya en el receptor
 * propio y, si el dispositivo no soporta la retransmisión, ofrece el flujo del
 * sistema (SystemMirroringLauncher).
 */
class CastControlChannel(private val session: CastSession, private val json: Json) :
    Cast.MessageReceivedCallback {

    private var listener: ((ControlMessage) -> Unit)? = null

    fun open(onMessage: (ControlMessage) -> Unit) {
        listener = onMessage
        session.setMessageReceivedCallbacks(CastOptionsProvider.NAMESPACE, this)
    }

    fun send(message: ControlMessage) {
        val payload = json.encodeToString(ControlMessage.serializer(), message)
        session.sendMessage(CastOptionsProvider.NAMESPACE, payload)
    }

    override fun onMessageReceived(castDevice: CastDevice?, namespace: String?, message: String?) {
        val raw = message ?: return
        val parsed = runCatching {
            json.decodeFromString(ControlMessage.serializer(), raw)
        }.getOrNull() ?: return
        listener?.invoke(parsed)
    }

    fun close() {
        runCatching { session.removeMessageReceivedCallbacks(CastOptionsProvider.NAMESPACE) }
        listener = null
    }
}