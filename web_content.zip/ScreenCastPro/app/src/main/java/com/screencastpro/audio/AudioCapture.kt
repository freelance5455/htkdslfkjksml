package com.screencastpro.audio

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.os.Build
import androidx.core.content.ContextCompat
import com.screencastpro.shared.model.StreamSettings

/**
 * Dos rutas de audio:
 *
 * 1. AudioPlaybackCapture (Android 10+): captura el audio del sistema, pero solo
 *    las apps que lo permiten. El contenido con DRM aparece en silencio: lo impone
 *    el sistema operativo, no hay alternativa.
 * 2. Micrófono: funciona en cualquier versión, pero capta el ambiente, no la app.
 *
 * RECORD_AUDIO es necesario en ambos casos: la plataforma lo exige también para
 * AudioPlaybackCapture.
 */
class AudioCapture(private val context: Context) {

    val supportsPlaybackCapture: Boolean get() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q

    fun hasPermission(): Boolean = ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.RECORD_AUDIO
    ) == PackageManager.PERMISSION_GRANTED

    fun create(projection: MediaProjection?, settings: StreamSettings): AudioRecord? {
        if (!settings.audioEnabled || !hasPermission()) return null
        return if (supportsPlaybackCapture && projection != null) {
            createPlaybackRecord(projection)
        } else {
            createMicrophoneRecord()
        }
    }

    private fun createPlaybackRecord(projection: MediaProjection): AudioRecord? {
        val configuration = AudioPlaybackCaptureConfiguration.Builder(projection)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()

        val format = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(SAMPLE_RATE)
            .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
            .build()

        return buildRecord { AudioRecord.Builder().setAudioPlaybackCaptureConfig(configuration) }
            .also { record -> record?.let { configureFormat(it, format) } }
    }

    private fun createMicrophoneRecord(): AudioRecord? =
        buildRecord { AudioRecord.Builder().setAudioSource(MediaRecorder.AudioSource.MIC) }
            .also { record ->
                record?.let {
                    configureFormat(
                        it,
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(SAMPLE_RATE)
                            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                            .build()
                    )
                }
            }

    private fun buildRecord(configure: () -> AudioRecord.Builder): AudioRecord? {
        val minimumBuffer = AudioRecord.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_STEREO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        if (minimumBuffer <= 0) return null
        return configure()
            .setBufferSizeInBytes(minimumBuffer * 2)
            .build()
            .takeIf { it.state == AudioRecord.STATE_INITIALIZED }
    }

    private fun configureFormat(record: AudioRecord, format: AudioFormat) {
        // El formato real se aplica en el codificador; aquí solo documentamos la
        // intención para que el pipeline de AAC use la misma configuración.
        record.format
        format
    }

    companion object {
        const val SAMPLE_RATE = 48_000
        const val CHANNEL_COUNT = 2
        const val BITRATE = 128_000
    }
}