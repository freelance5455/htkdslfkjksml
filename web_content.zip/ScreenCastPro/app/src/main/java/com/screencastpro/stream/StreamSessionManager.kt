package com.screencastpro.stream

import android.content.Context
import android.media.projection.MediaProjection
import com.screencastpro.capture.CaptureConfig
import com.screencastpro.discovery.DiscoveryManager
import com.screencastpro.settings.StreamPreferences
import com.screencastpro.shared.graphics.FitPreset
import com.screencastpro.shared.model.ConnectionState
import com.screencastpro.shared.model.DeviceDescriptor
import com.screencastpro.shared.model.StreamSettings
import com.screencastpro.shared.model.StreamStats
import com.screencastpro.shared.model.TransportKind
import com.screencastpro.capture.MediaProjectionController
import com.screencastpro.stream.cast.CastStreamTransport
import com.screencastpro.stream.direct.DirectH264Transport
import com.screencastpro.stream.miracast.MiracastTransport
import com.screencastpro.stream.webrtc.WebRtcTransport
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Coordina todo lo que ocurre durante una transmisión: elige el transporte según
 * el dispositivo, guarda la última configuración de imagen por TV y reconecta
 * si la red se cae.
 */
class StreamSessionManager(
    private val context: Context,
    private val preferences: StreamPreferences,
    private val discovery: DiscoveryManager
) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val _state = MutableStateFlow(ConnectionState.IDLE)
    val state: StateFlow<ConnectionState> = _state.asStateFlow()

    private val _stats = MutableStateFlow(StreamStats())
    val stats: StateFlow<StreamStats> = _stats.asStateFlow()

    private val _activeDevice = MutableStateFlow<DeviceDescriptor?>(null)
    val activeDevice: StateFlow<DeviceDescriptor?> = _activeDevice.asStateFlow()

    private var transport: StreamTransport? = null
    /** Captura del protocolo directo (Direct H.264): se crea bajo demanda. */
    private var captureController: MediaProjectionController? = null
    private var projection: MediaProjection? = null
    private var statsJob: Job? = null

    @Volatile
    private var preset = FitPreset()

    val activeDeviceName: String get() = _activeDevice.value?.name.orEmpty()

    /** Orden de preferencia: tiempo real primero, espejo del sistema al final. */
    private val preferenceOrder = listOf(
        TransportKind.WEBRTC,
        TransportKind.DIRECT_H264,
        TransportKind.CAST_CONTROL,
        TransportKind.SYSTEM_MIRRORING
    )

    fun attachProjection(mediaProjection: MediaProjection) {
        projection = mediaProjection
        val device = _activeDevice.value ?: return
        connect(device)
    }

    fun select(device: DeviceDescriptor) {
        scope.launch {
            preset = preferences.fitPreset(device.id)
        }
    }

    fun start(device: DeviceDescriptor) {
        _activeDevice.value = device
        connect(device)
    }

    private fun connect(device: DeviceDescriptor) {
        scope.launch {
            val settings = preferences.currentSettings()
            val captureConfig = CaptureConfig.fromDisplay(
                context = context,
                quality = settings.quality,
                fps = settings.fps.value,
                rotationDegrees = CaptureConfig.currentRotation(context)
            )
            val kind = preferenceOrder.firstOrNull { it in device.transports }
                ?: TransportKind.SYSTEM_MIRRORING

            _state.value = ConnectionState.CONNECTING
            val active = createTransport(kind)
            transport = active

            runCatching {
                active.connect(device, settings, captureConfig, preset)
                _state.value = ConnectionState.STREAMING
                observeStats(active)
            }.onFailure {
                _state.value = ConnectionState.FAILED
                if (settings.autoReconnect) scheduleReconnect(device)
            }
        }
    }

    private fun createTransport(kind: TransportKind): StreamTransport = when (kind) {
        TransportKind.WEBRTC -> WebRtcTransport(
            context = context,
            projection = requireNotNull(projection) {
                "MediaProjection es obligatorio para el transporte en tiempo real"
            },
            signalingOverride = ""
        )

        TransportKind.DIRECT_H264 -> {
            val controller = captureController
                ?: MediaProjectionController(context).also { captureController = it }
            DirectH264Transport(
                context = context,
                projection = requireNotNull(projection) {
                    "MediaProjection es obligatorio para el protocolo directo"
                },
                captureController = controller
            )
        }
        TransportKind.CAST_CONTROL -> CastStreamTransport(context)
        // Miracast / Wi-Fi Display: la emisión la lleva el sistema; la app abre su panel.
        TransportKind.SYSTEM_MIRRORING -> MiracastTransport(context)
    }

    private fun observeStats(active: StreamTransport) {
        statsJob?.cancel()
        statsJob = scope.launch {
            active.stats.collect { _stats.value = it }
        }
    }

    private fun scheduleReconnect(device: DeviceDescriptor) {
        scope.launch {
            var attempt = 0
            while (reconnectPolicy.shouldRetry(attempt)) {
                _state.value = ConnectionState.RECONNECTING
                delay(reconnectPolicy.delayFor(attempt))
                val active = transport ?: return@launch
                val settings = preferences.currentSettings()
                runCatching {
                    active.connect(
                        device,
                        settings,
                        CaptureConfig.fromDisplay(
                            context,
                            settings.quality,
                            settings.fps.value,
                            CaptureConfig.currentRotation(context)
                        ),
                        preset
                    )
                }.onSuccess {
                    _state.value = ConnectionState.STREAMING
                    return@launch
                }
                attempt++
            }
            _state.value = ConnectionState.FAILED
        }
    }

    /** Cambios del panel de controles: se aplican al vídeo que ya viaja. */
    fun updateFit(newPreset: FitPreset) {
        preset = newPreset
        transport?.updateFit(newPreset)
        _activeDevice.value?.let { device ->
            scope.launch { preferences.saveFitPreset(device.id, newPreset) }
        }
    }

    fun updateSettings(settings: StreamSettings) {
        scope.launch { preferences.updateSettings { settings } }
        transport?.updateSettings(settings)
    }

    fun stop() {
        scope.launch {
            statsJob?.cancel()
            transport?.disconnect()
            transport = null
            captureController?.stop()
            captureController = null
            _activeDevice.value = null
            _state.value = ConnectionState.IDLE
            projection = null
        }
    }

    private val reconnectPolicy = ReconnectPolicy()
}