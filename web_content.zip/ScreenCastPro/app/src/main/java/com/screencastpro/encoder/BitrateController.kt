package com.screencastpro.encoder

import com.screencastpro.shared.model.StreamStats

/**
 * Bitrate adaptable con histéresis: baja rápido cuando la red sufre y sube despacio
 * para no provocar oscilaciones visibles.
 */
class BitrateController {

    private var current = 0
    private var peak = 0

    fun start(width: Int, height: Int, fps: Int, lowLatency: Boolean): Int {
        val bitsPerPixelPerFrame = if (lowLatency) 0.08 else 0.12
        val base = (width.toDouble() * height * fps * bitsPerPixelPerFrame).toInt()
        peak = base * 3 / 2
        current = base.coerceIn(MIN_BITRATE, MAX_BITRATE)
        return current
    }

    fun adapt(stats: StreamStats): Int? {
        if (current == 0) return null
        val lossy = stats.packetLossPercent > 3f || stats.rttMs > 250
        val healthy = stats.packetLossPercent < 0.5f && stats.rttMs in 1..120

        val target = when {
            lossy -> (current * 0.75f).toInt()
            healthy -> (current * 1.1f).toInt()
            else -> current
        }.coerceIn(MIN_BITRATE, peak)

        if (target == current) return null
        current = target
        return current
    }

    fun currentBitrate(): Int = current

    private companion object {
        const val MIN_BITRATE = 600_000
        const val MAX_BITRATE = 12_000_000
    }
}