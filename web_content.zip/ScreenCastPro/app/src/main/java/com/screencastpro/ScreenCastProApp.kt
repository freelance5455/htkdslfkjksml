package com.screencastpro

import android.app.Application
import com.screencastpro.core.ServiceLocator

class ScreenCastProApp : Application() {

    override fun onCreate() {
        super.onCreate()
        ServiceLocator.install(this)
    }
}