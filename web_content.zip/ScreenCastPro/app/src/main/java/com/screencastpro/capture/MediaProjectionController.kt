package com.screencastpro.capture

import android.content.Context
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.Looper
import android.view.Surface
import com.screencastpro.graphics.SurfaceTransformer

/**
 * Une MediaProjection con la superficie de OpenGL del transformador.
 *
 * Importante: el VirtualDisplay no escribe directamente en la superficie del
 * codificador. Escribe en una textura que OpenGL redibuja con el encuadre
 * elegido; por eso "Rellenar" o el zoom cambian lo que ve la TV y no la interfaz.
 */
class MediaProjectionController(private val context: Context) {

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private val transformer = SurfaceTransformer()
    private var config: CaptureConfig? = null
    private var rotationListener: ((Int) -> Unit)? = null
    private var projectionCallback: MediaProjection.Callback? = null

    val inputSurface: Surface get() = transformer.inputSurface

    fun start(
        mediaProjection: MediaProjection,
        captureConfig: CaptureConfig,
        onReady: (Surface) -> Unit,
        onRotationChanged: (Int) -> Unit
    ) {
        stop()
        config = captureConfig
        rotationListener = onRotationChanged
        projection = mediaProjection

        // Android 14 exige registrar el callback antes de crear el VirtualDisplay.
        val callback = object : MediaProjection.Callback() {
            override fun onStop() {
                this@MediaProjectionController.stop()
            }
        }
        projectionCallback = callback
        mediaProjection.registerCallback(callback, Handler(Looper.getMainLooper()))

        transformer.configure(
            inputWidth = captureConfig.sourceWidth,
            inputHeight = captureConfig.sourceHeight,
            fps = captureConfig.fps
        )

        createVirtualDisplay(captureConfig)
        onReady(transformer.inputSurface)
        registerDisplayListener()
    }

    private fun createVirtualDisplay(captureConfig: CaptureConfig) {
        val active = projection ?: return
        virtualDisplay = active.createVirtualDisplay(
            VIRTUAL_DISPLAY_NAME,
            captureConfig.sourceWidth,
            captureConfig.sourceHeight,
            captureConfig.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            transformer.inputSurface,
            null,
            null
        )
    }

    /** Se llama cuando el usuario elige calidad, FPS o cambia de orientación. */
    fun reconfigure(captureConfig: CaptureConfig) {
        config = captureConfig
        transformer.configure(
            inputWidth = captureConfig.sourceWidth,
            inputHeight = captureConfig.sourceHeight,
            fps = captureConfig.fps
        )
        createVirtualDisplay(captureConfig)
    }

    private fun registerDisplayListener() {
        displayManager().registerDisplayListener(displayListener, Handler(Looper.getMainLooper()))
    }

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) = Unit

        override fun onDisplayRemoved(displayId: Int) = Unit

        override fun onDisplayChanged(displayId: Int) {
            val rotation = CaptureConfig.currentRotation(context)
            if (rotation != config?.rotationDegrees) {
                rotationListener?.invoke(rotation)
            }
        }
    }

    /**
     * Conecta la salida del transformador con la superficie del codificador.
     * Es el paso que cierra el camino "captura -> OpenGL -> H.264" del protocolo
     * directo; en la ruta WebRTC el encuadre ocurre dentro de FitScreenCapturer.
     */
    fun attachEncoderSurface(surface: Surface, width: Int, height: Int) {
        transformer.setEncoderSurface(surface, width, height)
    }

    fun stop() {
        runCatching { displayManager().unregisterDisplayListener(displayListener) }
        virtualDisplay?.release()
        virtualDisplay = null
        projectionCallback?.let { callback -> projection?.unregisterCallback(callback) }
        projectionCallback = null
        projection = null
        transformer.release()
    }

    private fun displayManager(): DisplayManager = context.getSystemService(DisplayManager::class.java)

    private companion object {
        const val VIRTUAL_DISPLAY_NAME = "ScreenCastPro"
    }
}