package com.screencastpro.encoder

import android.media.MediaCodec
import java.nio.ByteBuffer

/**
 * Los codificadores Android no son uniformes: unos entregan los NAL en formato
 * AVCC (4 bytes de longitud + datos) y otros en Annex-B (00 00 00 01). El
 * protocolo Direct H.264 habla Annex-B, así que aquí se convierte y se clasifica
 * lo que llega.
 */
object AvcNalUnits {

    private val START_CODE = byteArrayOf(0, 0, 0, 1)
    private const val NAL_TYPE_MASK = 0x1F
    private const val NAL_SPS = 7
    private const val NAL_PPS = 8
    private const val NAL_IDR = 5

    fun toAnnexB(buffer: ByteBuffer, info: MediaCodec.BufferInfo): ByteArray {
        val data = ByteArray(info.size)
        buffer.position(info.offset)
        buffer.get(data, 0, info.size)
        return asAnnexB(data)
    }

    /** Acepta una unidad AVCC y devuelve su equivalente Annex-B; si ya lo era, la deja igual. */
    fun asAnnexB(data: ByteArray): ByteArray {
        val output = java.io.ByteArrayOutputStream(data.size + 32)
        var index = 0
        while (index + 4 <= data.size) {
            val length = ((data[index].toInt() and 0xFF) shl 24) or
                ((data[index + 1].toInt() and 0xFF) shl 16) or
                ((data[index + 2].toInt() and 0xFF) shl 8) or
                (data[index + 3].toInt() and 0xFF)
            if (length <= 0 || index + 4 + length > data.size) {
                // Ya venía en Annex-B: se copia tal cual.
                return data
            }
            output.write(START_CODE)
            output.write(data, index + 4, length)
            index += 4 + length
        }
        return output.toByteArray()
    }

    fun isKeyFrame(annexB: ByteArray): Boolean = nalTypes(annexB).contains(NAL_IDR)

    fun containsParameterSets(annexB: ByteArray): Boolean {
        val types = nalTypes(annexB)
        return types.contains(NAL_SPS) && types.contains(NAL_PPS)
    }

    fun nalTypes(annexB: ByteArray): List<Int> {
        val types = mutableListOf<Int>()
        var index = 0
        while (index + 4 < annexB.size) {
            val isStartCode = annexB[index].toInt() == 0 &&
                annexB[index + 1].toInt() == 0 &&
                annexB[index + 2].toInt() == 0 &&
                annexB[index + 3].toInt() == 1
            if (isStartCode) {
                types += annexB[index + 4].toInt() and NAL_TYPE_MASK
                index += 4
            } else {
                index++
            }
        }
        return types
    }
}