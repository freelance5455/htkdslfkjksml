package com.screencastpro.discovery

import android.content.Context
import com.google.android.gms.cast.framework.CastContext
import com.screencastpro.shared.model.DeviceDescriptor
import com.screencastpro.shared.model.DeviceType
import com.screencastpro.shared.model.TransportKind
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Descubrimiento de la red local.
 *
 * * mDNS: _googlecast._tcp (Chromecast, Google TV, TVs con Cast) y
 *   _screencastpro._tcp (nuestra app receptora en Android TV, Google TV o Fire TV).
 * * Cast SDK: sesiones reales con receptores Google Cast.
 *
 * Cada dispositivo declara qué transportes puede aceptar; StreamSessionManager
 * elige el primero de la lista de preferencia.
 */
class DiscoveryManager(private val context: Context) {

    private val nsdDiscovery = NsdDiscovery(context)
    private val found = LinkedHashMap<String, DeviceDescriptor>()

    private val _devices = MutableStateFlow<List<DeviceDescriptor>>(emptyList())
    val devices: StateFlow<List<DeviceDescriptor>> = _devices.asStateFlow()

    @Volatile
    private var scanning = false

    fun start() {
        if (scanning) return
        scanning = true
        nsdDiscovery.start(object : NsdDiscovery.Callback {
            override fun onServiceFound(descriptor: DeviceDescriptor) = upsert(descriptor)

            override fun onServiceLost(id: String) = remove(id)
        })
        warmUpCastContext()
    }

    fun stop() {
        scanning = false
        nsdDiscovery.stop()
    }

    /** Botón "Buscar dispositivos nuevamente". */
    fun refresh() {
        stop()
        found.clear()
        _devices.value = emptyList()
        start()
    }

    private fun warmUpCastContext() {
        // En dispositivos sin Google Play Services (Fire TV) esto falla y seguimos
        // funcionando solo con receptores propios: no es un error fatal.
        runCatching { CastContext.getSharedInstance(context) }
    }

    private fun upsert(descriptor: DeviceDescriptor) {
        found[descriptor.id] = descriptor
        publish()
    }

    private fun remove(id: String) {
        found.remove(id)
        publish()
    }

    private fun publish() {
        val now = System.currentTimeMillis()
        _devices.value = found.values
            .filter { now - it.lastSeen < STALE_TIMEOUT_MS }
            .sortedBy { it.name.lowercase() }
    }

    fun device(id: String): DeviceDescriptor? = found[id]

    fun capabilitiesFor(type: DeviceType): Set<TransportKind> = when (type) {
        // Nuestra app receptora: tiempo real y, si no hay WebRTC, Direct H.264.
        DeviceType.SCREENCAST_PRO ->
            setOf(TransportKind.WEBRTC, TransportKind.DIRECT_H264)

        DeviceType.ANDROID_TV, DeviceType.GOOGLE_TV, DeviceType.FIRE_TV ->
            setOf(TransportKind.WEBRTC, TransportKind.DIRECT_H264, TransportKind.SYSTEM_MIRRORING)

        // Chromecast: la API pública no permite espejo; queda el canal de control
        // (nuestro receptor web) y el flujo del sistema.
        DeviceType.CHROMECAST, DeviceType.GOOGLE_CAST ->
            setOf(TransportKind.WEBRTC, TransportKind.CAST_CONTROL, TransportKind.SYSTEM_MIRRORING)

        DeviceType.HISENSE ->
            setOf(TransportKind.WEBRTC, TransportKind.CAST_CONTROL, TransportKind.SYSTEM_MIRRORING)

        DeviceType.MIRACAST -> setOf(TransportKind.SYSTEM_MIRRORING)

        DeviceType.UNKNOWN -> setOf(TransportKind.WEBRTC, TransportKind.SYSTEM_MIRRORING)
    }

    fun typeFor(serviceType: String, name: String): DeviceType {
        val normalized = name.lowercase()
        return when {
            serviceType.contains(NsdDiscovery.RECEIVER_SERVICE) -> when {
                normalized.contains("fire") -> DeviceType.FIRE_TV
                normalized.contains("google tv") -> DeviceType.GOOGLE_TV
                normalized.contains("android tv") -> DeviceType.ANDROID_TV
                else -> DeviceType.SCREENCAST_PRO
            }

            normalized.contains("chromecast") -> DeviceType.CHROMECAST
            normalized.contains("google tv") -> DeviceType.GOOGLE_TV
            normalized.contains("android tv") -> DeviceType.ANDROID_TV
            normalized.contains("fire") -> DeviceType.FIRE_TV
            normalized.contains("hisense") -> DeviceType.HISENSE
            else -> DeviceType.GOOGLE_CAST
        }
    }

    private companion object {
        const val STALE_TIMEOUT_MS = 20_000L
    }
}