package com.screencastpro.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

private val ScreenCastColors = darkColorScheme(
    primary = Color(0xFF2FE3F0),
    onPrimary = Color(0xFF04121A),
    secondary = Color(0xFF9B7BF5),
    onSecondary = Color(0xFF0B0714),
    background = Color(0xFF08090C),
    onBackground = Color(0xFFF1F4F8),
    surface = Color(0xFF101319),
    onSurface = Color(0xFFF1F4F8),
    surfaceVariant = Color(0xFF1A1E27),
    onSurfaceVariant = Color(0xFFA6B0C0),
    outline = Color(0xFF2A2F3A),
    error = Color(0xFFFF6B6B)
)

private val ScreenCastTypography = Typography(
    headlineMedium = TextStyle(fontSize = 30.sp, fontWeight = FontWeight.SemiBold),
    titleLarge = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.SemiBold),
    titleMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Medium),
    bodyMedium = TextStyle(fontSize = 14.sp),
    labelLarge = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.Medium)
)

@Composable
fun ScreenCastProTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = ScreenCastColors,
        typography = ScreenCastTypography,
        content = content
    )
}