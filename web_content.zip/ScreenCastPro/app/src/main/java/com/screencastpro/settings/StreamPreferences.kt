package com.screencastpro.settings

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.screencastpro.shared.graphics.FitMode
import com.screencastpro.shared.graphics.FitPreset
import com.screencastpro.shared.model.StreamFps
import com.screencastpro.shared.model.StreamQuality
import com.screencastpro.shared.model.StreamSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "screencast_pro")

class StreamPreferences(private val context: Context) {

    private object Keys {
        val quality = stringPreferencesKey("quality")
        val fps = intPreferencesKey("fps")
        val audio = booleanPreferencesKey("audio")
        val lowLatency = booleanPreferencesKey("low_latency")
        val autoReconnect = booleanPreferencesKey("auto_reconnect")
        val signalingUrl = stringPreferencesKey("signaling_url")

        fun mode(deviceId: String) = stringPreferencesKey("fit_mode_" + deviceId)
        fun zoom(deviceId: String) = floatPreferencesKey("fit_zoom_" + deviceId)
    }

    val settings: Flow<StreamSettings> = context.dataStore.data.map { prefs ->
        StreamSettings(
            quality = runCatching {
                StreamQuality.valueOf(prefs[Keys.quality] ?: StreamQuality.AUTO.name)
            }.getOrDefault(StreamQuality.AUTO),
            fps = if (prefs[Keys.fps] == StreamFps.FPS_60.value) StreamFps.FPS_60 else StreamFps.FPS_30,
            audioEnabled = prefs[Keys.audio] ?: true,
            lowLatency = prefs[Keys.lowLatency] ?: true,
            autoReconnect = prefs[Keys.autoReconnect] ?: true
        )
    }

    val signalingServerUrl: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[Keys.signalingUrl] ?: DEFAULT_SIGNALING_URL
    }

    suspend fun currentSettings(): StreamSettings = settings.first()

    suspend fun updateSettings(transform: (StreamSettings) -> StreamSettings) {
        val next = transform(currentSettings())
        context.dataStore.edit { prefs ->
            prefs[Keys.quality] = next.quality.name
            prefs[Keys.fps] = next.fps.value
            prefs[Keys.audio] = next.audioEnabled
            prefs[Keys.lowLatency] = next.lowLatency
            prefs[Keys.autoReconnect] = next.autoReconnect
        }
    }

    suspend fun setSignalingServer(url: String) {
        context.dataStore.edit { it[Keys.signalingUrl] = url.trim() }
    }

    /** Última configuración usada con ese dispositivo, para reaplicarla al reconectar. */
    suspend fun fitPreset(deviceId: String): FitPreset {
        val prefs = context.dataStore.data.first()
        val mode = runCatching {
            FitMode.valueOf(prefs[Keys.mode(deviceId)] ?: FitMode.FIT.name)
        }.getOrDefault(FitMode.FIT)
        return FitPreset(mode = mode, zoom = prefs[Keys.zoom(deviceId)] ?: 1f)
    }

    suspend fun saveFitPreset(deviceId: String, preset: FitPreset) {
        context.dataStore.edit { prefs ->
            prefs[Keys.mode(deviceId)] = preset.mode.name
            prefs[Keys.zoom(deviceId)] = preset.zoom
        }
    }

    companion object {
        /**
         * Vacío = señalización directa contra el receptor (http://IP-del-receptor:8765).
         * Solo hace falta cambiarlo si se usa un servidor propio en otro equipo.
         */
        const val DEFAULT_SIGNALING_URL = ""
    }
}