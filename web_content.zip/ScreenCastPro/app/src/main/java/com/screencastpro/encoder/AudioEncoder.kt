package com.screencastpro.encoder

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import com.screencastpro.audio.AudioCapture

/** AAC-LC de 128 kbps: compatible con WebRTC, Android TV y Fire TV. */
class AudioEncoder {

    private var codec: MediaCodec? = null

    val sampleRate: Int get() = AudioCapture.SAMPLE_RATE
    val channelCount: Int get() = AudioCapture.CHANNEL_COUNT

    fun start(): MediaCodec {
        stop()
        val sampleRate = AudioCapture.SAMPLE_RATE
        val channelCount = AudioCapture.CHANNEL_COUNT

        val format = MediaFormat.createAudioFormat(
            MediaFormat.MIMETYPE_AUDIO_AAC,
            sampleRate,
            channelCount
        ).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, AudioCapture.BITRATE)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16 * 1024)
        }

        val active = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        active.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        active.start()
        codec = active
        return active
    }

    fun drain(onFrame: (java.nio.ByteBuffer, MediaCodec.BufferInfo) -> Unit) {
        val active = codec ?: return
        val info = MediaCodec.BufferInfo()
        val index = active.dequeueOutputBuffer(info, DRAIN_TIMEOUT_US)
        if (index < 0) return
        if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) {
            active.releaseOutputBuffer(index, false)
            return
        }
        val buffer = active.getOutputBuffer(index) ?: return
        onFrame(buffer, info)
        active.releaseOutputBuffer(index, false)
    }

    fun stop() {
        val active = codec ?: return
        runCatching { active.stop() }
        active.release()
        codec = null
    }

    private companion object {
        const val DRAIN_TIMEOUT_US = 10_000L
    }
}