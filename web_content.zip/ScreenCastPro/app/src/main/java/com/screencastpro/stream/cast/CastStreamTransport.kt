package com.screencastpro.stream.cast

import android.content.Context
import com.google.android.gms.cast.framework.CastContext
import com.google.android.gms.cast.framework.CastSession
import com.google.android.gms.cast.framework.SessionManager
import com.google.android.gms.cast.framework.SessionManagerListener
import com.screencastpro.capture.CaptureConfig
import com.screencastpro.shared.graphics.FitPreset
import com.screencastpro.shared.model.ControlMessage
import com.screencastpro.shared.model.DeviceDescriptor
import com.screencastpro.shared.model.StreamSettings
import com.screencastpro.shared.model.StreamStats
import com.screencastpro.shared.model.TransportKind
import com.screencastpro.stream.StreamTransport
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.json.Json

/**
 * Transporte para Chromecast, Google TV con Cast integrado y TVs compatibles
 * (por ejemplo Hisense con Google Cast).
 *
 * Qué hace de verdad:
 *  1. Abre una sesión Cast con el receptor propio.
 *  2. Le envía el encuadre, el zoom y la rotación por el canal de control.
 *  3. Si el receptor responde que no puede retransmitir, deja la sesión lista y
 *     expone "needsSystemMirroring" para abrir el flujo del sistema.
 *
 * Qué no puede hacer: crear el espejo de pantalla del sistema desde una app de
 * terceros. No es un límite de este código, es un límite de la API de Google.
 */
class CastStreamTransport(private val context: Context) : StreamTransport {

    override val kind: TransportKind = TransportKind.CAST_CONTROL

    private val _stats = MutableStateFlow(StreamStats())
    override val stats: StateFlow<StreamStats> = _stats.asStateFlow()

    private val _needsSystemMirroring = MutableStateFlow(false)
    val needsSystemMirroring: StateFlow<Boolean> = _needsSystemMirroring.asStateFlow()

    private val json = Json { ignoreUnknownKeys = true }
    private var sessionManager: SessionManager? = null
    private var controlChannel: CastControlChannel? = null
    private var sessionLatch: CompletableDeferred<CastSession>? = null

    private val sessionListener = object : SessionManagerListener<CastSession> {
        override fun onSessionStarted(session: CastSession, sessionId: String) {
            sessionLatch?.complete(session)
        }

        override fun onSessionStartFailed(session: CastSession, error: Int) {
            sessionLatch?.completeExceptionally(IllegalStateException("Cast rechazó la sesión: " + error))
        }

        override fun onSessionResumed(session: CastSession, wasSuspended: Boolean) {
            sessionLatch?.complete(session)
        }

        override fun onSessionEnded(session: CastSession, error: Int) = Unit

        override fun onSessionStarting(session: CastSession) = Unit

        override fun onSessionStartFailedLegacy() = Unit

        override fun onSessionEnding(session: CastSession) = Unit

        override fun onSessionResumeFailed(session: CastSession, error: Int) = Unit

        override fun onSessionResuming(session: CastSession, sessionId: String) = Unit

        override fun onSessionSuspended(session: CastSession, reason: Int) = Unit
    }

    override suspend fun connect(
        device: DeviceDescriptor,
        settings: StreamSettings,
        captureConfig: CaptureConfig,
        preset: FitPreset
    ) {
        val manager = CastContext.getSharedInstance(context).sessionManager
        sessionManager = manager
        manager.addSessionManagerListener(sessionListener, CastSession::class.java)

        val session = manager.currentCastSession ?: run {
            val deferred = CompletableDeferred<CastSession>()
            sessionLatch = deferred
            manager.startSession()
            deferred.await()
        }

        val channel = CastControlChannel(session, json)
        controlChannel = channel
        channel.open { message ->
            if (message.type == ControlMessage.TYPE_CAPABILITIES) {
                // El receptor declara si puede retransmitir el vídeo del teléfono.
                val supportsMirroring = message.fullscreen ?: false
                _needsSystemMirroring.value = !supportsMirroring
            }
        }

        channel.send(
            ControlMessage(
                type = ControlMessage.TYPE_FIT,
                mode = preset.mode.name,
                zoom = preset.zoom,
                rotation = preset.rotationDegrees
            )
        )
    }

    override fun updateFit(preset: FitPreset) {
        controlChannel?.send(
            ControlMessage(
                type = ControlMessage.TYPE_FIT,
                mode = preset.mode.name,
                zoom = preset.zoom,
                rotation = preset.rotationDegrees
            )
        )
    }

    override fun updateSettings(settings: StreamSettings) = Unit

    override suspend fun disconnect() {
        controlChannel?.close()
        controlChannel = null
        sessionManager?.let { manager ->
            manager.removeSessionManagerListener(sessionListener, CastSession::class.java)
            runCatching { manager.endCurrentSession(true) }
        }
        sessionManager = null
        _needsSystemMirroring.value = false
    }
}