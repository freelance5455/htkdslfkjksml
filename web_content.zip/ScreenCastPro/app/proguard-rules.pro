# WebRTC usa JNI y reflexión interna: sin estas reglas la app falla en release.
-keep class org.webrtc.** { *; }
-dontwarn org.webrtc.**

# Google Cast.
-keep class com.google.android.gms.cast.** { *; }
-keep class com.screencastpro.stream.cast.CastOptionsProvider { *; }

# Modelos serializados entre emisor y receptor.
-keepattributes *Annotation*, InnerClasses
-keepclassmembers class com.screencastpro.shared.** { *; }
-keep,includedescriptorclasses class com.screencastpro.shared.**$$serializer { *; }