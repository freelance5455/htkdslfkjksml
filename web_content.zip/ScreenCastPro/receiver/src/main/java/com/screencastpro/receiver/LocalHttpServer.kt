package com.screencastpro.receiver

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.net.ServerSocket
import java.net.Socket
import java.nio.charset.StandardCharsets

/**
 * Servidor HTTP mínimo para señalizar sin infraestructura externa.
 *
 * Rutas:
 *   POST /offer      -> recibe el SDP del emisor y devuelve la respuesta
 *   POST /candidate  -> guarda los candidatos ICE del emisor
 *   GET  /health     -> comprobación rápida
 */
class LocalHttpServer(
    private val port: Int,
    private val onOffer: (String, String) -> String,
    private val onCandidates: (String) -> Unit
) {

    private var serverSocket: ServerSocket? = null
    @Volatile
    private var running = false

    fun start() {
        if (running) return
        running = true
        val server = ServerSocket(port)
        serverSocket = server

        Thread {
            while (running) {
                val socket = runCatching { server.accept() }.getOrNull() ?: break
                Thread { handle(socket) }.start()
            }
        }.start()
    }

    fun stop() {
        running = false
        runCatching { serverSocket?.close() }
        serverSocket = null
    }

    private fun handle(socket: Socket) {
        socket.use { connection ->
            val input = BufferedInputStream(connection.getInputStream())
            val output = BufferedOutputStream(connection.getOutputStream())

            val requestLine = readLine(input) ?: return
            val parts = requestLine.split(" ")
            val path = parts.getOrNull(1).orEmpty()

            var contentLength = 0
            while (true) {
                val header = readLine(input) ?: break
                if (header.isEmpty()) break
                if (header.lowercase().startsWith("content-length:")) {
                    contentLength = header.substringAfter(":").trim().toIntOrNull() ?: 0
                }
            }

            val body = if (contentLength > 0) {
                val buffer = ByteArray(contentLength)
                var read = 0
                while (read < contentLength) {
                    val chunk = input.read(buffer, read, contentLength - read)
                    if (chunk <= 0) break
                    read += chunk
                }
                String(buffer, 0, read, StandardCharsets.UTF_8)
            } else {
                ""
            }

            when {
                path.startsWith("/offer") -> respond(
                    output,
                    200,
                    onOffer(body, connection.inetAddress.hostAddress ?: "")
                )
                path.startsWith("/candidate") -> {
                    onCandidates(body)
                    respond(output, 200, "ok")
                }
                path.startsWith("/health") -> respond(output, 200, "ScreenCast Pro Receiver")
                else -> respond(output, 404, "no encontrado")
            }
        }
    }

    private fun respond(output: BufferedOutputStream, code: Int, body: String) {
        val bytes = body.toByteArray(StandardCharsets.UTF_8)
        val head = "HTTP/1.1 " + code + " OK\r\n" +
            "Content-Type: text/plain; charset=utf-8\r\n" +
            "Content-Length: " + bytes.size + "\r\n" +
            "Access-Control-Allow-Origin: *\r\n" +
            "Connection: close\r\n\r\n"
        output.write(head.toByteArray(StandardCharsets.US_ASCII))
        output.write(bytes)
        output.flush()
    }

    private fun readLine(input: BufferedInputStream): String? {
        val builder = StringBuilder()
        while (true) {
            val value = input.read()
            if (value == -1) return if (builder.isEmpty()) null else builder.toString()
            if (value == '\n'.code) return builder.toString().trimEnd('\r')
            builder.append(value.toChar())
        }
    }

    companion object {
        const val DEFAULT_PORT = 8765
    }
}