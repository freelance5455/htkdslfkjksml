package com.screencastpro.receiver

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.SurfaceView
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import org.webrtc.EglBase
import org.webrtc.SurfaceViewRenderer

/**
 * Al abrirla, la TV queda esperando: anuncia el servicio por mDNS (para que el
 * teléfono la liste) y levanta la señalización en el puerto 8765.
 */
class ReceiverActivity : Activity() {

    private lateinit var renderer: SurfaceViewRenderer
    private lateinit var statusLabel: TextView
    private lateinit var receiver: WebRtcReceiver
    private lateinit var httpServer: LocalHttpServer
    private lateinit var advertiser: NsdAdvertiser
    private lateinit var directSurfaceView: SurfaceView
    private var directReceiver: DirectH264Receiver? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        renderer = SurfaceViewRenderer(this).apply {
            init(EglBase.create().eglBaseContext, null)
            setMirror(false)
        }

        // Superficie para el protocolo directo (H.264 por TCP); solo se hace visible
        // si el emisor usa esa ruta en vez de WebRTC.
        directSurfaceView = SurfaceView(this).apply {
            visibility = android.view.View.GONE
        }

        statusLabel = TextView(this).apply {
            text = "ScreenCast Pro · esperando al teléfono…"
            setTextColor(Color.WHITE)
            textSize = 20f
            setPadding(32, 32, 32, 32)
        }

        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(
                renderer,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            )
            addView(
                directSurfaceView,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            )
            addView(
                statusLabel,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.TOP or Gravity.START
                )
            )
        }
        setContentView(root)

        receiver = WebRtcReceiver(this, renderer)

        httpServer = LocalHttpServer(
            port = LocalHttpServer.DEFAULT_PORT,
            onOffer = { offer, senderHost ->
                statusLabel.text = "Conectado · recibiendo pantalla"
                receiver.handleOffer(offer)
                // Si el emisor usa el protocolo directo (H.264 por TCP), conectamos a su
                // puerto 8766. Si va por WebRTC, la conexión no se establece y no pasa nada.
                directReceiver = DirectH264Receiver(
                    context = this,
                    surfaceView = directSurfaceView,
                    onStreamStarted = { directSurfaceView.visibility = android.view.View.VISIBLE }
                ).also { it.start(senderHost) }
            },
            onCandidates = { /* candidatos ICE del emisor; se aceptan tal cual en LAN */ }
        )
        httpServer.start()

        advertiser = NsdAdvertiser(this)
        advertiser.start(LocalHttpServer.DEFAULT_PORT)
    }

    override fun onDestroy() {
        httpServer.stop()
        advertiser.stop()
        directReceiver?.stop()
        directReceiver = null
        receiver.dispose()
        renderer.release()
        super.onDestroy()
    }
}