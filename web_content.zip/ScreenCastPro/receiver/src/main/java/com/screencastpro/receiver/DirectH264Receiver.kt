package com.screencastpro.receiver

import android.content.Context
import android.media.MediaCodec
import android.media.MediaFormat
import android.view.Gravity
import android.view.SurfaceView
import android.widget.FrameLayout
import com.screencastpro.shared.graphics.FitMode
import com.screencastpro.shared.graphics.FitPreset
import java.io.BufferedInputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.ByteBuffer

/**
 * Receptor del protocolo "ScreenCast Pro Direct" (H.264 Annex-B sobre TCP).
 *
 * Se usa cuando el emisor selecciona Direct H.264 (p. ej. la red bloquea WebRTC).
 * Conecta al puerto 8766 del teléfono, lee los fotogramas y los decodifica con
 * MediaCodec directamente sobre la SurfaceView. El encuadre se hace aquí en la TV
 * cambiando el tamaño de la superficie, sin estirar nunca la imagen.
 */
class DirectH264Receiver(
    private val context: Context,
    private val surfaceView: SurfaceView,
    private val port: Int = DIRECT_PORT,
    private val onStreamStarted: () -> Unit = {}
) {

    private var codec: MediaCodec? = null
    private var thread: Thread? = null

    @Volatile
    private var running = false

    @Volatile
    private var videoWidth = 0

    @Volatile
    private var videoHeight = 0

    fun start(senderHost: String) {
        if (running) return
        running = true
        thread = Thread { connectAndStream(senderHost) }.also { it.start() }
    }

    fun stop() {
        running = false
        runCatching { codec?.stop() }
        runCatching { codec?.release() }
        codec = null
        thread = null
    }

    /**
     * Ajuste de imagen en la TV: cambia el tamaño de la SurfaceView alrededor del
     * centro. Como la superficie conserva la proporción del vídeo, nunca se deforma:
     * en "Rellenar" y "Zoom" crece y el contenedor recorta los bordes; en "Ajustar"
     * se encoge y dejan barras negras.
     */
    fun applyFit(preset: FitPreset, containerWidth: Int, containerHeight: Int) {
        if (videoWidth == 0 || videoHeight == 0 || containerWidth == 0 || containerHeight == 0) return
        val rotated = preset.rotationDegrees == 90 || preset.rotationDegrees == 270
        val effectiveW = if (rotated) videoHeight else videoWidth
        val effectiveH = if (rotated) videoWidth else videoHeight
        val effectiveAspect = effectiveW.toFloat() / effectiveH
        val containerAspect = containerWidth.toFloat() / containerHeight

        // Tamaño base con la proporción del vídeo, sin deformar.
        val baseWidth: Float
        val baseHeight: Float
        if (effectiveAspect >= containerAspect) {
            baseWidth = containerWidth.toFloat()
            baseHeight = containerWidth / effectiveAspect
        } else {
            baseHeight = containerHeight.toFloat()
            baseWidth = containerHeight * effectiveAspect
        }

        val cover = preset.mode == FitMode.FILL ||
            preset.mode == FitMode.RATIO_16_9 ||
            (preset.mode == FitMode.ZOOM && preset.zoom > 1f)
        val zoom = if (preset.mode == FitMode.ZOOM) preset.zoom.coerceIn(1f, 3f) else 1f
        val scale = (if (cover) {
            maxOf(containerWidth / baseWidth, containerHeight / baseHeight)
        } else {
            1f
        }) * zoom

        val params = FrameLayout.LayoutParams(
            (baseWidth * scale).toInt().coerceAtLeast(1),
            (baseHeight * scale).toInt().coerceAtLeast(1),
            Gravity.CENTER
        )
        surfaceView.layoutParams = params
        surfaceView.rotation = preset.rotationDegrees.toFloat()
    }

    private fun connectAndStream(host: String) {
        var attempts = 0
        while (running && attempts < MAX_CONNECT_ATTEMPTS) {
            val socket = runCatching {
                Socket().apply { connect(InetSocketAddress(host, port), CONNECT_TIMEOUT_MS) }
            }.getOrNull()
            if (socket == null) {
                attempts++
                if (!running) return
                Thread.sleep(RETRY_DELAY_MS)
                continue
            }
            try {
                stream(socket)
            } catch (_: Throwable) {
                // reconexión del receptor: se reintenta mientras siga activo.
            } finally {
                runCatching { socket.close() }
            }
            attempts++
        }
    }

    private fun stream(socket: Socket) {
        val input = BufferedInputStream(socket.getInputStream())
        // Saludo "SCP1 WxH fps".
        val hello = readLine(input) ?: return
        if (!hello.startsWith("SCP1")) return
        val size = hello.split(" ").getOrNull(1)?.split("x")
        videoWidth = size?.getOrNull(0)?.toIntOrNull() ?: 0
        videoHeight = size?.getOrNull(1)?.split(" ")?.getOrNull(0)?.toIntOrNull() ?: 0
        if (videoWidth == 0 || videoHeight == 0) return

        val header = ByteArray(4)
        while (running) {
            if (!readFully(input, header)) return
            val length = ((header[0].toInt() and 0xFF) shl 24) or
                ((header[1].toInt() and 0xFF) shl 16) or
                ((header[2].toInt() and 0xFF) shl 8) or
                (header[3].toInt() and 0xFF)
            if (length <= 0 || length > MAX_FRAME_BYTES) return
            val payload = ByteArray(length)
            if (!readFully(input, payload)) return

            ensureDecoder(payload)
            feedDecoder(payload)
            drainDecoder()
        }
    }

    private fun ensureDecoder(packet: ByteArray) {
        if (codec != null) return
        // Se necesita la superficie lista y los SPS/PPS, que el emisor envía primero.
        if (!surfaceView.holder.surface.isValid) return
        if (!containsParameterSets(packet)) return
        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, videoWidth, videoHeight).apply {
            setByteBuffer("csd-0", ByteBuffer.wrap(packet))
        }
        val decoder = MediaCodec.createDecoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        decoder.configure(format, surfaceView.holder.surface, null, 0)
        decoder.start()
        codec = decoder
        onStreamStarted()
    }

    private fun feedDecoder(payload: ByteArray) {
        val decoder = codec ?: return
        val index = decoder.dequeueInputBuffer(INPUT_TIMEOUT_US)
        if (index < 0) return
        val buffer = decoder.getInputBuffer(index) ?: return
        buffer.clear()
        buffer.put(payload)
        val flags = if (isKeyFrame(payload)) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
        decoder.queueInputBuffer(index, 0, payload.size, System.nanoTime() / 1000, flags)
    }

    private fun drainDecoder() {
        val decoder = codec ?: return
        val info = MediaCodec.BufferInfo()
        while (true) {
            val index = decoder.dequeueOutputBuffer(info, 0)
            if (index < 0) break
            decoder.releaseOutputBuffer(index, true)
        }
    }

    // Detección de NAL sin depender del módulo :app (el receptor es otro módulo).
    private fun containsParameterSets(annexB: ByteArray): Boolean {
        val types = nalTypes(annexB)
        return types.contains(7) && types.contains(8)
    }

    private fun isKeyFrame(annexB: ByteArray): Boolean = nalTypes(annexB).contains(5)

    private fun nalTypes(annexB: ByteArray): List<Int> {
        val types = mutableListOf<Int>()
        var index = 0
        while (index + 4 < annexB.size) {
            val isStartCode = annexB[index].toInt() == 0 &&
                annexB[index + 1].toInt() == 0 &&
                annexB[index + 2].toInt() == 0 &&
                annexB[index + 3].toInt() == 1
            if (isStartCode) {
                types += annexB[index + 4].toInt() and 0x1F
                index += 4
            } else {
                index++
            }
        }
        return types
    }

    private fun readLine(input: BufferedInputStream): String? {
        val builder = StringBuilder()
        while (true) {
            val b = input.read()
            if (b == -1) return if (builder.isEmpty()) null else builder.toString()
            if (b == '
'.code) return builder.toString()
            if (b != ''.code) builder.append(b.toChar())
        }
    }

    private fun readFully(input: BufferedInputStream, buffer: ByteArray): Boolean {
        var read = 0
        while (read < buffer.size) {
            val n = input.read(buffer, read, buffer.size - read)
            if (n <= 0) return false
            read += n
        }
        return true
    }

    private companion object {
        const val DIRECT_PORT = 8766
        const val MAX_CONNECT_ATTEMPTS = 3
        const val CONNECT_TIMEOUT_MS = 3000
        const val RETRY_DELAY_MS = 1200L
        const val MAX_FRAME_BYTES = 2 * 1024 * 1024
        const val INPUT_TIMEOUT_US = 10_000L
    }
}