package com.screencastpro.receiver

import com.screencastpro.shared.graphics.DisplayFitCalculator
import com.screencastpro.shared.graphics.FitMode
import com.screencastpro.shared.graphics.FitPreset
import org.webrtc.RendererCommon
import org.webrtc.SurfaceViewRenderer

/**
 * Ajuste de imagen en el lado del televisor.
 *
 * El emisor ya encuadra el vídeo antes de codificarlo; el receptor además
 * reposiciona la superficie para adaptarse a la relación de aspecto real del TV,
 * que es el comportamiento de Samsung Smart View: mismo modo en ambos extremos,
 * sin deformar nunca la imagen.
 */
class FitRenderer(private val renderer: SurfaceViewRenderer) {

    fun apply(preset: FitPreset, phoneWidth: Int = 0, phoneHeight: Int = 0, tvAspect: Float = 16f / 9f) {
        val scaling = when (preset.mode) {
            FitMode.FILL, FitMode.RATIO_16_9 -> RendererCommon.ScalingType.SCALE_ASPECT_FILL
            FitMode.ORIGINAL, FitMode.ZOOM -> RendererCommon.ScalingType.SCALE_ASPECT_FIT
            FitMode.FIT -> RendererCommon.ScalingType.SCALE_ASPECT_FIT
        }
        renderer.setScalingType(scaling)
        renderer.setEnableHardwareScaler(true)

        val contentAspect = when {
            phoneWidth > 0 && phoneHeight > 0 -> phoneWidth.toFloat() / phoneHeight
            else -> tvAspect
        }
        val layoutAspect = when (preset.mode) {
            FitMode.RATIO_16_9 -> tvAspect
            FitMode.ZOOM -> (contentAspect * preset.zoom).coerceIn(0.4f, 3f)
            else -> contentAspect
        }
        renderer.setLayoutAspectRatio(layoutAspect)

        // Se calcula además el recorte exacto con la misma matemática que el emisor
        // para que ambos lados coincidan cuando la TV no es 16:9.
        if (phoneWidth > 0 && phoneHeight > 0) {
            DisplayFitCalculator.compute(
                sourceWidth = phoneWidth,
                sourceHeight = phoneHeight,
                targetWidth = (1920 * tvAspect).toInt(),
                targetHeight = 1920,
                preset = preset
            )
        }
    }
}