package com.screencastpro.receiver

import android.content.Context
import kotlinx.serialization.json.Json
import org.webrtc.DataChannel
import org.webrtc.DefaultVideoDecoderFactory
import org.webrtc.DefaultVideoEncoderFactory
import org.webrtc.EglBase
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.MediaStream
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.RtpReceiver
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import org.webrtc.SurfaceViewRenderer
import org.webrtc.VideoTrack
import com.screencastpro.shared.model.ControlMessage
import java.util.concurrent.CountDownLatch

/**
 * Lado receptor de la transmisión: responde la oferta del teléfono, pinta el
 * vídeo y aplica los cambios de encuadre que llegan por el canal de datos.
 */
class WebRtcReceiver(
    private val context: Context,
    private val renderer: SurfaceViewRenderer
) {

    private val eglBase: EglBase = EglBase.create()
    private val json = Json { ignoreUnknownKeys = true }
    private val factory: PeerConnectionFactory by lazy { createFactory() }

    private var peerConnection: PeerConnection? = null
    private var controlChannel: DataChannel? = null
    private var fitRenderer: FitRenderer? = null

    fun handleOffer(offerSdp: String): String {
        close()

        val connection = factory.createPeerConnection(
            PeerConnection.RTCConfiguration(emptyList()).apply {
                sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
            },
            peerObserver()
        ) ?: error("No se pudo crear la conexión en el receptor")

        peerConnection = connection
        val latch = CountDownLatch(1)
        connection.setRemoteDescription(NoopObserver, SessionDescription(SessionDescription.Type.OFFER, offerSdp))

        connection.createAnswer(object : SdpObserver {
            override fun onCreateSuccess(description: SessionDescription) {
                connection.setLocalDescription(NoopObserver, description)
                latch.countDown()
            }

            override fun onCreateFailure(message: String) {
                latch.countDown()
            }

            override fun onSetSuccess() = Unit
            override fun onSetFailure(message: String) = Unit
        }, MediaConstraints())

        latch.await()
        return connection.localDescription?.description
            ?: error("El receptor no pudo generar la respuesta SDP")
    }

    fun close() {
        controlChannel?.close()
        controlChannel = null
        peerConnection?.close()
        peerConnection = null
    }

    fun dispose() {
        close()
        eglBase.release()
    }

    private fun peerObserver(): PeerConnection.Observer = object : PeerConnection.Observer {
        override fun onSignalingChange(state: PeerConnection.SignalingState) = Unit

        override fun onIceConnectionChange(state: PeerConnection.IceConnectionState) = Unit

        override fun onIceConnectionReceivingChange(receiving: Boolean) = Unit

        override fun onIceGatheringChange(state: PeerConnection.IceGatheringState) = Unit

        override fun onIceCandidate(candidate: IceCandidate) = Unit

        override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>) = Unit

        override fun onAddStream(stream: MediaStream) = Unit

        override fun onRemoveStream(stream: MediaStream) = Unit

        override fun onRenegotiationNeeded() = Unit

        override fun onAddTrack(receiver: RtpReceiver, streams: Array<out MediaStream>) {
            val track = receiver.track()
            if (track is VideoTrack) {
                // El tamaño de vídeo se conoce al llegar el primer fotograma; sirve
                // para calcular el encuadre con la misma matemática que el emisor.
                track.addSink(renderer)
                fitRenderer = FitRenderer(renderer)
            }
        }

        override fun onDataChannel(channel: DataChannel) {
            if (channel.label() != CONTROL_CHANNEL) return
            controlChannel = channel
            channel.registerObserver(object : DataChannel.Observer {
                override fun onBufferedAmountChange(amount: Long) = Unit
                override fun onStateChange() = Unit

                override fun onMessage(message: DataChannel.Buffer) {
                    val bytes = ByteArray(message.data.remaining())
                    message.data.get(bytes)
                    val parsed = runCatching {
                        json.decodeFromString(ControlMessage.serializer(), String(bytes))
                    }.getOrNull() ?: return

                    if (parsed.type == ControlMessage.TYPE_FIT) {
                        val mode = runCatching {
                            com.screencastpro.shared.graphics.FitMode.valueOf(parsed.mode ?: "FIT")
                        }.getOrDefault(com.screencastpro.shared.graphics.FitMode.FIT)

                        fitRenderer?.apply(
                            com.screencastpro.shared.graphics.FitPreset(
                                mode = mode,
                                zoom = parsed.zoom ?: 1f,
                                rotationDegrees = parsed.rotation ?: 0
                            )
                        )
                    }
                }
            })
        }
    }

    private fun createFactory(): PeerConnectionFactory {
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(context)
                .createInitializationOptions()
        )
        return PeerConnectionFactory.builder()
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(eglBase.eglBaseContext, true, true))
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(eglBase.eglBaseContext))
            .createPeerConnectionFactory()
    }

    private object NoopObserver : SdpObserver {
        override fun onCreateSuccess(description: SessionDescription) = Unit
        override fun onCreateFailure(message: String) = Unit
        override fun onSetSuccess() = Unit
        override fun onSetFailure(message: String) = Unit
    }

    private companion object {
        const val CONTROL_CHANNEL = "control"
    }
}