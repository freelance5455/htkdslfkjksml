package com.screencastpro.receiver

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build

/**
 * Publica el receptor con mDNS para que el emisor lo descubra sin configuración.
 * El nombre lleva el modelo real (Android TV, Google TV, Fire TV) para que la app
 * muestre el tipo correcto en la lista.
 */
class NsdAdvertiser(private val context: Context) {

    private val nsdManager: NsdManager = context.getSystemService(NsdManager::class.java)
    private var registrationListener: NsdManager.RegistrationListener? = null

    fun start(port: Int) {
        val info = NsdServiceInfo().apply {
            serviceName = deviceLabel()
            serviceType = SERVICE_TYPE
            setPort(port)
        }

        val listener = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(serviceInfo: NsdServiceInfo) = Unit
            override fun onRegistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) = Unit
            override fun onServiceUnregistered(serviceInfo: NsdServiceInfo) = Unit
            override fun onUnregistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) = Unit
        }
        registrationListener = listener
        runCatching { nsdManager.registerService(info, NsdManager.PROTOCOL_DNS_SD, listener) }
    }

    fun stop() {
        registrationListener?.let { listener ->
            runCatching { nsdManager.unregisterService(listener) }
        }
        registrationListener = null
    }

    private fun deviceLabel(): String {
        val model = Build.MODEL ?: "Android TV"
        return when {
            model.contains("AFT", ignoreCase = true) -> "Fire TV " + model
            model.contains("Chromecast", ignoreCase = true) -> "Google TV " + model
            else -> "Android TV " + model
        }
    }

    companion object {
        const val SERVICE_TYPE = "_screencastpro._tcp"
    }
}