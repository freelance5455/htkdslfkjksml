package com.screencastpro.shared.graphics

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DisplayFitCalculatorTest {

    // Teléfono vertical 1080x2400 sobre un lienzo 1920x1080 (1080p horizontal).
    private val phoneWidth = 1080
    private val phoneHeight = 2400

    @Test
    fun ajustar_muestra_todo_el_contenido_con_barras_laterales() {
        val result = DisplayFitCalculator.compute(
            phoneWidth, phoneHeight, 1920, 1080, FitPreset(mode = FitMode.FIT)
        )

        // Escala = min(1920/1080, 1080/2400) = 0.45 -> 486 x 1080 píxeles, centrado.
        assertEquals(486, result.viewportWidth)
        assertEquals(1080, result.viewportHeight)
        assertEquals(717, result.viewportX)
        assertEquals(0, result.viewportY)

        // No se recorta nada: se ve la pantalla completa del teléfono.
        assertEquals(0, result.sourceX)
        assertEquals(0, result.sourceY)
        assertEquals(phoneWidth, result.sourceWidth)
        assertEquals(phoneHeight, result.sourceHeight)
    }

    @Test
    fun rellenar_cubre_el_lienzo_y_recorta_sin_deformar() {
        val result = DisplayFitCalculator.compute(
            phoneWidth, phoneHeight, 1920, 1080, FitPreset(mode = FitMode.FILL)
        )

        // La imagen cubre 1920 de ancho y se recorta en vertical.
        assertEquals(1920, result.viewportWidth)
        assertEquals(1080, result.viewportHeight)
        assertTrue(result.sourceHeight < phoneHeight)
        assertEquals(phoneWidth, result.sourceWidth)

        // La escala es uniforme: no hay deformación.
        val drawnWidth = (result.sourceWidth * result.scale).toInt()
        val drawnHeight = (result.sourceHeight * result.scale).toInt()
        assertEquals(result.viewportWidth, drawnWidth)
        assertEquals(result.viewportHeight, drawnHeight)
    }

    @Test
    fun zoom_aumenta_el_recorte_de_forma_progresiva() {
        val base = DisplayFitCalculator.compute(
            phoneWidth, phoneHeight, 1920, 1080, FitPreset(mode = FitMode.FIT, zoom = 1f)
        )
        val zoomed = DisplayFitCalculator.compute(
            phoneWidth, phoneHeight, 1920, 1080, FitPreset(mode = FitMode.ZOOM, zoom = 2f)
        )

        assertTrue(zoomed.scale > base.scale)
        assertTrue(zoomed.sourceHeight < base.sourceHeight)
    }

    @Test
    fun original_no_escala() {
        val result = DisplayFitCalculator.compute(
            phoneWidth, phoneHeight, 1920, 1080, FitPreset(mode = FitMode.ORIGINAL)
        )

        assertEquals(1f, result.scale, 0.0001f)
        assertEquals(phoneWidth, result.viewportWidth)
        assertEquals(phoneHeight, result.viewportHeight)
    }
}