package com.screencastpro.shared.model

enum class DeviceType(val label: String) {
    CHROMECAST("Chromecast"),
    GOOGLE_TV("Google TV"),
    ANDROID_TV("Android TV"),
    FIRE_TV("Fire TV"),
    HISENSE("Smart TV Hisense"),
    GOOGLE_CAST("Google Cast"),
    MIRACAST("Miracast"),
    SCREENCAST_PRO("Receptor ScreenCast Pro"),
    UNKNOWN("Dispositivo compatible")
}

/**
 * Rutas de transmisión. El orden de preferencia vive en StreamSessionManager.
 */
enum class TransportKind(val label: String) {
    /** Tiempo real hacia receptores propios (Android TV, Google TV, Fire TV). */
    WEBRTC("WebRTC en tiempo real"),

    /** H.264 sobre TCP para receptores sin WebRTC que usan nuestro protocolo. */
    DIRECT_H264("Direct H.264"),

    /** Sesión Google Cast con canal de control propio. */
    CAST_CONTROL("Canal Google Cast"),

    /** Espejo gestionado por el sistema (Wi-Fi Display / Transmitir pantalla). */
    SYSTEM_MIRRORING("Espejo del sistema")
}

data class DeviceDescriptor(
    val id: String,
    val name: String,
    val type: DeviceType,
    val host: String? = null,
    val port: Int? = null,
    val model: String? = null,
    val supportsAudio: Boolean = true,
    val transports: Set<TransportKind> = emptySet(),
    val lastSeen: Long = System.currentTimeMillis()
) {
    val isReachable: Boolean
        get() = !host.isNullOrBlank()

    val preferredTransport: TransportKind?
        get() = TransportKind.entries.firstOrNull { it in transports }
}

enum class ConnectionState(val label: String) {
    IDLE("Sin transmitir"),
    DISCOVERING("Buscando dispositivos"),
    CONNECTING("Conectando"),
    STREAMING("Transmitiendo"),
    RECONNECTING("Reconectando"),
    FAILED("Error de conexión")
}