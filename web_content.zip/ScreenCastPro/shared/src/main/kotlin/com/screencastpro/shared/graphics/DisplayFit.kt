package com.screencastpro.shared.graphics

/**
 * Modos de adaptación de la pantalla del teléfono a la pantalla de la TV.
 * El resultado siempre se aplica al vídeo que sale del emisor, nunca a la interfaz.
 */
enum class FitMode(val label: String) {
    ORIGINAL("Original"),
    FIT("Ajustar a pantalla"),
    FILL("Rellenar pantalla"),
    ZOOM("Zoom"),
    RATIO_16_9("16:9")
}

/** Configuración de imagen guardada por dispositivo. */
data class FitPreset(
    val mode: FitMode = FitMode.FIT,
    val zoom: Float = 1f,
    val rotationDegrees: Int = 0
)

/**
 * Resultado del cálculo, expresado en píxeles de la imagen que se envía al receptor.
 *
 * @param viewportX/Y/W/H zona del lienzo de destino donde se dibuja el fotograma
 *        (los márgenes que quedan fuera se ven negros: barras del modo "Ajustar").
 * @param sourceX/Y/W/H región del fotograma capturado que se muestrea
 *        (es el recorte real del modo "Rellenar" y del zoom).
 */
data class FitTransform(
    val viewportX: Int,
    val viewportY: Int,
    val viewportWidth: Int,
    val viewportHeight: Int,
    val sourceX: Int,
    val sourceY: Int,
    val sourceWidth: Int,
    val sourceHeight: Int,
    val scale: Float
)

object DisplayFitCalculator {

    private const val SIXTEEN_NINE = 16f / 9f
    private const val MIN_ZOOM = 1f
    private const val MAX_ZOOM = 3f

    fun compute(
        sourceWidth: Int,
        sourceHeight: Int,
        targetWidth: Int,
        targetHeight: Int,
        preset: FitPreset
    ): FitTransform {
        require(sourceWidth > 0 && sourceHeight > 0 && targetWidth > 0 && targetHeight > 0) {
            "Las resoluciones deben ser mayores que cero"
        }

        val scaleToFit = minOf(
            targetWidth.toFloat() / sourceWidth,
            targetHeight.toFloat() / sourceHeight
        )

        // Zona útil del lienzo: en 16:9 se limita a esa proporción y el resto queda negro.
        val canvasAspect = if (preset.mode == FitMode.RATIO_16_9) {
            SIXTEEN_NINE
        } else {
            targetWidth.toFloat() / targetHeight
        }
        val targetAspect = targetWidth.toFloat() / targetHeight
        val canvasWidth: Int
        val canvasHeight: Int
        if (canvasAspect >= targetAspect) {
            canvasHeight = targetHeight
            canvasWidth = (targetHeight * canvasAspect).toInt().coerceAtMost(targetWidth)
        } else {
            canvasWidth = targetWidth
            canvasHeight = (targetWidth / canvasAspect).toInt().coerceAtMost(targetHeight)
        }
        val canvasX = (targetWidth - canvasWidth) / 2
        val canvasY = (targetHeight - canvasHeight) / 2

        val scale = when (preset.mode) {
            FitMode.ORIGINAL -> 1f
            FitMode.FIT -> scaleToFit
            FitMode.FILL, FitMode.RATIO_16_9 -> maxOf(
                canvasWidth.toFloat() / sourceWidth,
                canvasHeight.toFloat() / sourceHeight
            )
            FitMode.ZOOM -> scaleToFit * preset.zoom.coerceIn(MIN_ZOOM, MAX_ZOOM)
        }

        val drawnWidth = (sourceWidth * scale).toInt().coerceAtLeast(1)
        val drawnHeight = (sourceHeight * scale).toInt().coerceAtLeast(1)

        // La ventana visible es el lienzo: lo que el fotograma ampliado deja fuera se recorta.
        val visibleWidth = minOf(drawnWidth, canvasWidth)
        val visibleHeight = minOf(drawnHeight, canvasHeight)

        // Recorte equivalente expresado en píxeles del fotograma original.
        val sourceVisibleWidth = (visibleWidth / scale).toInt().coerceIn(1, sourceWidth)
        val sourceVisibleHeight = (visibleHeight / scale).toInt().coerceIn(1, sourceHeight)
        val sourceX = ((sourceWidth - sourceVisibleWidth) / 2f).toInt().coerceAtLeast(0)
        val sourceY = ((sourceHeight - sourceVisibleHeight) / 2f).toInt().coerceAtLeast(0)

        val viewportX = canvasX + (canvasWidth - visibleWidth) / 2
        val viewportY = canvasY + (canvasHeight - visibleHeight) / 2

        return FitTransform(
            viewportX = viewportX,
            viewportY = viewportY,
            viewportWidth = visibleWidth,
            viewportHeight = visibleHeight,
            sourceX = sourceX,
            sourceY = sourceY,
            sourceWidth = sourceVisibleWidth,
            sourceHeight = sourceVisibleHeight,
            scale = scale
        )
    }
}