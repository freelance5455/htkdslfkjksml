package com.screencastpro.shared.model

import kotlinx.serialization.Serializable

enum class StreamQuality(val label: String, val shortSide: Int) {
    AUTO("Automática", 720),
    HD720("720p", 720),
    FULL_HD_1080("1080p", 1080)
}

enum class StreamFps(val label: String, val value: Int) {
    FPS_30("30 FPS", 30),
    FPS_60("60 FPS", 60)
}

@Serializable
data class StreamSettings(
    val quality: StreamQuality = StreamQuality.AUTO,
    val fps: StreamFps = StreamFps.FPS_30,
    val audioEnabled: Boolean = true,
    val lowLatency: Boolean = true,
    val autoReconnect: Boolean = true
)

data class StreamStats(
    val bitrateKbps: Int = 0,
    val fps: Int = 0,
    val rttMs: Int = 0,
    val packetLossPercent: Float = 0f
)

/** Mensajes de control emisor -> receptor (encuadre, zoom, rotación, pantalla completa). */
@Serializable
data class ControlMessage(
    val type: String,
    val mode: String? = null,
    val zoom: Float? = null,
    val rotation: Int? = null,
    val fullscreen: Boolean? = null,
    val sessionId: String? = null
) {
    companion object {
        const val TYPE_FIT = "fit"
        const val TYPE_PING = "ping"
        const val TYPE_HELLO = "hello"
        const val TYPE_CAPABILITIES = "capabilities"
    }
}

/** Intercambio de señalización WebRTC (oferta, respuesta y candidatos ICE). */
@Serializable
data class SignalingMessage(
    val type: String,
    val room: String? = null,
    val sdp: String? = null,
    val candidate: String? = null,
    val sdpMid: String? = null,
    val sdpMLineIndex: Int? = null,
    val capabilities: List<String>? = null
) {
    companion object {
        const val OFFER = "offer"
        const val ANSWER = "answer"
        const val CANDIDATE = "candidate"
        const val JOIN = "join"
        const val PAIR_CODE = "pair-code"
    }
}