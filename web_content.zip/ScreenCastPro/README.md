# ScreenCast Pro

Duplicación de pantalla Android -> TV por Wi-Fi, con ajuste de imagen real sobre el vídeo
transmitido (Original, Ajustar, Rellenar, Zoom, 16:9), zoom, rotación y pantalla completa.

## Módulos

| Módulo     | Contenido                                                                    |
|------------|------------------------------------------------------------------------------|
| :shared    | Modelo de dispositivos, ajustes y matemáticas de encuadre (Kotlin puro, testeable) |
| :app       | Emisor: captura MediaProjection, audio, códecs, transportes y UI Compose      |
| :receiver  | App receptora para Android TV / Google TV / Fire TV (WebRTC + ajuste en TV)    |

## Requisitos

* Android Studio Ladybug o superior, JDK 17.
* Android SDK 35 instalado (compileSdk 35, minSdk 26).
* Dos dispositivos en la misma red Wi-Fi para probar: un teléfono y una TV o caja Android.

## Compilar

    gradle wrapper --gradle-version 8.9
    ./gradlew :app:assembleDebug        # APK del emisor
    ./gradlew :receiver:assembleDebug   # APK del receptor para la TV
    ./gradlew :shared:test              # pruebas de la matemática de encuadre

Las APK quedan en app/build/outputs/apk/debug y receiver/build/outputs/apk/debug.

## Cómo se transmite de verdad

1. **Descubrimiento**: mDNS (_googlecast._tcp para Cast/Google TV, _screencastpro._tcp para
   receptores propios) más el Cast SDK para sesiones Google Cast.
2. **Permiso**: intent de MediaProjection (diálogo del sistema, no se puede evitar).
3. **Captura**: VirtualDisplay -> SurfaceTexture -> OpenGL ES, donde se aplica el encuadre.
4. **Transporte**: WebRTC hacia receptores propios (baja latencia) o canal Cast de control
   con receptor web cuando el dispositivo lo soporta.
5. **Notificación**: servicio en primer plano con botón "Detener transmisión".

## Límites reales que conviene leer antes de tocar el código

Ver docs/viabilidad.md. Resumen honesto:

* **Duplicar pantalla completa a un Chromecast desde una app de terceros no es posible con
  APIs públicas.** Google usa una ruta privada para "Transmitir pantalla". La app implementa
  el canal Cast de control y, si el receptor lo soporta, la ruta WebRTC; en caso contrario
  ofrece abrir el flujo del sistema.
* **Miracast**: Android no expone API pública para emitir por Wi-Fi Display. La app abre el
  flujo del sistema cuando el fabricante lo permite (Fire TV, algunas Hisense).
* **Audio**: el audio del sistema se captura con AudioPlaybackCapture y solo si la app de
  origen lo permite; el audio protegido (DRM) nunca se puede capturar.
* **Fire TV / Hisense**: la ruta fiable es instalar el receptor propio (:receiver) en el
  dispositivo y transmitir por WebRTC.

## Publicar

1. Crea la app en la consola de desarrolladores de Google Cast y registra el
   applicationId del receptor web (cast-receiver/receiver.js usa CAST_APP_ID).
2. Coloca el id en CastOptionsProvider.kt (RECEIVER_APPLICATION_ID).
3. Firma la release con tu keystore y genera el App Bundle.