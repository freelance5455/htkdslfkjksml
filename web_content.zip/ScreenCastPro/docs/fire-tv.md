# Fire TV

Fire OS no incluye Google Play Services, por lo que el SDK de Google Cast no
funciona en él. Estas son las rutas reales.

## Recomendado: app receptora propia
Se instala la app `:receiver` por sideload (no requiere Play Store) y se transmite
por WebRTC o por el protocolo Direct H.264. Es la ruta completa: encuadre, zoom,
rotación y audio incluidos, igual que en Android TV.

## Descubrimiento
Fire TV anuncia `_amzn-wplay._tcp` (servicio de pantalla de Amazon). NsdDiscovery
lo detecta y DeviceTypeResolver clasifica el dispositivo como FIRE_TV, con los
transportes WEBRTC, DIRECT_H264 y SYSTEM_MIRRORING.

## Lo que no se usa
* Amazon Fling SDK: desaprobado, no se integra.
* Miracast desde la app: limitación de Android (ver miracast.md). Se abre el panel
  del sistema de Fire TV si está disponible.

## Instalación por adb
```
adb connect <ip-de-la-tv>:5555
adb install -r receiver/build/outputs/apk/debug/receiver-debug.apk
adb shell am start -n com.screencastpro.receiver/.ReceiverActivity
```