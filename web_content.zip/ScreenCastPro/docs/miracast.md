# Miracast / Wi-Fi Display

## Limitación exacta
Desde Android 8 no existe API pública para que una app de terceros cree una sesión
de emisión Wi-Fi Display (Miracast). Solo el sistema puede iniciarla, y no todos
los fabricantes exponen ese panel.

## Qué hace la app
MiracastTransport NO simula la emisión:
* abre el panel del sistema donde existe esa función (Settings.ACTION_CAST o el
  panel de "Transmitir pantalla");
* si el panel no existe, la sesión falla con un mensaje claro;
* deja marcada la sesión como "gestionada por el sistema".

## Consecuencias del camino del sistema
* los modos de encuadre no se aplican (el vídeo lo compone el sistema);
* el audio lo decide el sistema;
* no hay estadísticas de bitrate ni de FPS.
La interfaz muestra ese estado en vez de aparentar que controla la transmisión.

## Alternativa ya preparada
Instalar la app receptora (`:receiver`) en el dispositivo y transmitir por WebRTC
o por Direct H.264: rutas completas, con encuadre, zoom y rotación controlados por
la app. La arquitectura de transportes lo enruta sin cambios.

## Cuando haya API
En un dispositivo con privilegios de sistema basta con sustituir
`SystemMirroringLauncher.open` por la llamada real de Wi-Fi Display; el resto de
la aplicación no cambia.