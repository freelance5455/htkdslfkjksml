# Arquitectura

    ui/           Compose: pantalla principal, ajustes, panel de controles
    capture/      MediaProjection, VirtualDisplay, notificación en primer plano
    audio/        AudioPlaybackCapture (sistema) y micrófono como alternativa
    encoder/      MediaCodec H.264/AAC, negociación de códecs, bitrate adaptativo
    graphics/     OpenGL ES: aplica el encuadre al fotograma antes de codificar
    stream/       Transportes: WebRTC, Direct H.264, Cast, lanzador de espejo del sistema
    discovery/    mDNS + Cast SDK: encuentro de dispositivos en la red local

## El punto clave: el encuadre ocurre en la GPU, no en la interfaz

El VirtualDisplay nunca escribe directamente en la superficie del codificador.
Escribe en una SurfaceTexture propiedad de SurfaceTransformer, que dibuja el
fotograma en la superficie de entrada del codificador aplicando una matriz.

DisplayFitCalculator calcula esa matriz (viewport + región de origen + escala) a
partir de la relación de aspecto del teléfono, la resolución de destino elegida y
el encuadre pedido. Cambiar de modo o mover el zoom vuelve a calcular la matriz:
el siguiente fotograma ya sale encuadrado en el vídeo que ve la TV.

## Añadir un protocolo nuevo

1. Implementa StreamTransport en stream/<nuevo>/.
2. Añade su valor a TransportKind (shared) y declara qué tipos de dispositivo lo soportan
   en DiscoveryManager.capabilitiesFor(...).
3. StreamSessionManager elige el transporte con el orden de preferencia; no hay cambios
   en la interfaz ni en la captura.