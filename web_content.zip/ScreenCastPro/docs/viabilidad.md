# Viabilidad por dispositivo (leer antes de prometer funciones)

## Chromecast y dispositivos solo-Cast (Google TV con Chromecast integrado)

* Descubrimiento y sesión: **sí**, Cast SDK (MediaRouter + CastSession).
* Duplicación de pantalla completa desde app de terceros: **no**. La API pública de Cast no
  expone el espejo de pantalla; Google reserva esa función al flujo del sistema. La app
  conecta, envía órdenes de encuadre por el canal propio y, si el receptor declara
  soporte de WebRTC, transmite por ahí. Si no, ofrece el flujo del sistema.
* Envío de vídeo como contenido remoto (no espejo): posible según receptor.

## Android TV / Google TV / Fire TV con nuestra app receptora instalada

* **Ruta completa y recomendada.** WebRTC (libwebrtc) emisor<->receptor, latencia baja,
  30/60 FPS, bitrate adaptable, audio del sistema cuando la app de origen lo permite.
* Fire TV: no tiene Google Play Services, así que se instala la APK del receptor por
  sideload y funciona igual (misma red, emparejamiento por código).

## Smart TV Hisense / TVs con Google Cast, Miracast o AirPlay

* Si es Android TV / Google TV: instala el receptor y usa WebRTC.
* Si solo tiene Cast: ver el apartado de Chromecast.
* Miracast: Android **no** ofrece API pública para emitir por Wi-Fi Display desde Android 8.
  La app no puede crear la sesión Miracast por sí misma; abre el panel del sistema
  (Ajustes -> Pantalla inalámbrica / Transmitir) cuando el fabricante lo expone.

## Restricciones que ningún código puede saltarse

* El diálogo de MediaProjection lo muestra siempre el sistema: requiere acción del usuario.
* Audio del sistema: AudioPlaybackCapture captura solo apps que lo permiten
  (allowAudioPlaybackCapture) y nunca contenido protegido con DRM.
* FLAG_SECURE (apps bancarias, Netflix) aparece en negro: es comportamiento del sistema.
* DRM/cifrado de salida (HDCP) no se puede eludir.