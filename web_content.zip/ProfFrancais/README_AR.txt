Prof Français – مشروع تطبيق أندرويد

المحتويات:
- app/src/main/assets/index.html : واجهة التطبيق والوظائف المحلية.
- مشروع Android WebView جاهز للبناء باستخدام Android Studio و Gradle.

طريقة البناء لإنتاج APK:
1) ثبّت Android Studio على الكمبيوتر.
2) افتح مجلد ProfFrancais عبر Open.
3) انتظر اكتمال Gradle Sync وثبّت Android SDK 35 إذا طُلب.
4) من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
5) ستجد الملف عادة في app/build/outputs/apk/debug/app-debug.apk

ملاحظات:
- التطبيق يحفظ البيانات محلياً على الهاتف باستخدام LocalStorage.
- النسخ الاحتياطي والاستيراد متاحان من الإعدادات.
- المساعد المضمن حالياً يعتمد قوالب تعليمية تعمل دون إنترنت. لم يتم ربط نموذج ذكاء اصطناعي سحابي؛ يلزم اختيار مزود خدمة ومفتاح API قبل تفعيل المحادثة التوليدية.
- لم يتم إنشاء APK داخل بيئة التسليم الحالية لعدم توفر Android SDK وGradle.
