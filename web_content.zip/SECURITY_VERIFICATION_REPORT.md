# ANONYMOUX STUDIO 2.3.2 — Security Verification Report

## Controls implemented / retained

- Existing authenticated application sessions and user owner-key isolation are retained.
- Every resource-manager POST action requires server-side `auth_require_admin()` and a valid CSRF token. The outer admin route also requires admin access.
- SQL operations in the new resource system use PDO prepared statements. Dynamic table names are restricted to hard-coded allowlists (`tool_categories` / `tutorial_categories`).
- Resource publication is server-checked. Public catalogue queries return only `published` rows. Draft preview is available only to administrators.
- Notification reads/writes are scoped by authenticated `user_id`; `read_all` affects only the caller's unread rows.
- Tutorial media is stored outside the public document flow under `storage/resources/`, protected by a deny-all `.htaccess`, random disk names, private permissions, MIME inspection and image signature/dimension/pixel checks. SVG is not accepted. Media delivery validates publication/admin authorization, basename, file type and symlink state.
- Official/download URLs must be complete HTTPS URLs, with no username/password in the URL. Video embeds are limited to recognized YouTube/Vimeo hosts.
- User-generated Markdown text is HTML-escaped; only allowlisted Markdown constructs and safe HTTPS links are rendered.
- Existing media-serving endpoints keep ownership checks. Storage quota now includes saved outputs, submitted files, references and voice audio; generated image/video outputs are checked before they are retained.
- Sign-in notices are inserted only after authentication succeeds; notification failure is isolated so a database-notification issue does not block sign-in.
- Admin changes are written to the existing admin audit log.

## Static checks performed

- Full-tree PHP lint: 49/49 files passed.
- JavaScript syntax check: 8/8 files passed.
- Static grep scan for `eval`, shell execution functions (`shell_exec`, `passthru`, `system`), `unserialize`, and direct `include`/`require` from request variables: no matches.
- SQLite migration idempotency and constraints test: passed.

## Known security / functional limitations

1. Email verification, password change, and global session revocation are not part of the baseline account implementation. The dashboard does not claim they are active.
2. Existing hosting-level upload limits, PHP execution limits, WAF behavior, TLS configuration and `.htaccess` support must be checked on the real shared host.
3. The current runtime used for this build has neither `pdo_sqlite` nor `pdo_mysql`, so actual PDO transaction behavior, per-user database isolation, admin CRUD authorization, and session-bound media delivery could not be dynamically tested here.
4. No deployment browser or mobile device was available; responsive CSS was linted/reviewed but not device-tested.
5. Provider credentials were not present in this build environment, and PHP cURL was unavailable. Decart and Fish Audio live requests were not executed.
6. The Markdown editor is intentionally not an unrestricted HTML editor. Embedded arbitrary HTML/JavaScript is not supported.
7. Category disable preserves resource associations; deleting an obsolete resource is a separate explicit admin action.

## Release decision

**Static source checks: PASS.** **SQLite migration test: PASS.** **Full live-host security acceptance: NOT TESTED.** This report is not a penetration test or a certification of the deployment server. Do not treat the live provider, browser, quota-concurrency, or multi-account checks as passed until run on the deployed application.
