# לוחות בה - הוראות התקנה ב-Android / LG webOS / Web

קובץ ה-ZIP כולל את פרויקט האפליקציה המלא, כולל פרויקט ה-Android Native (Capacitor) המוכן לבנייה מיידית:

## 1. התקנה כ-Android APK מקורי (Native App)
הפרויקט מכיל תיקיית `android` מלאה עם Gradle ו-Capacitor:
1. פתח את תיקיית `android` ב-**Android Studio**.
2. חבר את הטלפון שלך ב-USB (או פתח אמולטור) ולחץ על **Run** (המשולש הירוק), או:
3. בתפריט העליון של Android Studio בחר **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. קובץ ה-`app-debug.apk` שנוצר ניתן להתקנה ישירה בכל מכשיר Android!

אם מותקן אצלך Gradle ב-CLI:
```bash
cd android
./gradlew assembleDebug
```
ה-APK יימצא ב:
`android/app/build/outputs/apk/debug/app-debug.apk`

---

## 2. התקנה כ-PWA ישירות מהדפדפן (ללא צורך במחשב)
תוכל גם להתקין את האפליקציה ישירות מהדפדפן בטלפון:
1. פתח את הקישור בכרום בטלפון:
   https://ais-dev-iunce7t664lb4cjmbqpdak-859802625168.europe-west2.run.app
2. לחץ על 3 הנקודות בתפריט הדפדפן (⋮) ובחר **הוסף למסך הבית (Add to Home Screen / Install App)**.

---

## 3. התקנה ב-LG webOS TV
קובץ ההתקנה לטלוויזיה מוכן: `hebrew-calendar_1.0.0_all.ipk`
להתקנה דרך webOS CLI / Ares:
```bash
ares-install -d <TV_NAME> hebrew-calendar_1.0.0_all.ipk
```
