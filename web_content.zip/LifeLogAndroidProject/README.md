# Life Log — Faisal Abbas (Android Studio project)

This Android Studio project wraps the included Life Log web app in an Android WebView. It contains the English-language tracker, local entry storage, history, reports, CSV export and JSON backup/restore.

## Build an APK
1. Install Android Studio on a computer.
2. Open this folder (`LifeLogAndroidProject`) as an existing project.
3. Allow Gradle sync and install the requested Android SDK (compile SDK 35).
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the APK location, typically `app/build/outputs/apk/debug/app-debug.apk`.

The APK has not been compiled or tested in this environment because Android SDK/Gradle are not installed here. Entry data is stored locally in the app's WebView storage; uninstalling/clearing app data may remove it, so use Backup JSON regularly.
