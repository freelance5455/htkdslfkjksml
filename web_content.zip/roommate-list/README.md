# RoomMate List (HTML5 build)

A shared daily-essentials list for roommates. Plain HTML, CSS and JavaScript, no build step.

## Files

| File | Purpose |
|---|---|
| `index.html` | Page shell |
| `style.css` | Styles (light and dark) |
| `app.js` | The app |
| `standalone.js` | Storage layer: Firebase, or local demo mode |
| `config.js` | Your Firebase settings (empty by default) |
| `manifest.json`, `icon.svg` | Lets phones "Add to Home screen" |

## Two modes

**Demo mode (default).** Open `index.html` with `config.js` empty. Everything works, but data stays in that one browser. Use it to try the app. It does not sync between phones.

**Shared mode (what you want for two phones).** Add Firebase settings:

1. Go to https://console.firebase.google.com and create a project (free Spark plan is enough).
2. Build > Firestore Database > Create database (production mode).
3. Project settings > Your apps > add a Web app, copy the `firebaseConfig` values into `config.js`.
4. Firestore > Rules, paste this and publish:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /rooms/{rid} {
      allow get, create, update, delete: if true;
      match /{sub}/{doc=**} { allow read, write: if true; }
    }
  }
}
```

These rules stop anyone from listing all rooms, but anyone who knows a Room ID can read and edit that room. Use a long Room ID and share it only with your roommates. For real per-person access control you would add Firebase Authentication and rules that check membership. That is not included.

## Hosting

Both phones need to open the same web address, over HTTPS. Easy free options:

- Netlify Drop (app.netlify.com/drop): drag the unzipped folder in.
- GitHub Pages or Firebase Hosting.
- To test on your computer: `python3 -m http.server 8000` in this folder, then open http://localhost:8000.

Then on each phone: open the address, join with the same Room ID, and use the browser menu > "Add to Home screen".

## Notes

- Notifications are in-app only (shown while the app is open). There is no push when it is closed.
- PDF export covers Latin text only. Use the CSV (opens in Excel) for other scripts.
- Owner-only actions (remove member, reset list) are enforced by the app, not by the database rules.
