/* Paste your Firebase web app settings here to share one list between phones.
   Firebase console > Project settings > Your apps > Web app > "firebaseConfig".
   Leave this empty to run in single-device demo mode. See README.md. */
window.RM_FIREBASE_CONFIG = {
  apiKey: "",
  authDomain: "",
  projectId: "",
  storageBucket: "",
  messagingSenderId: "",
  appId: ""
};
