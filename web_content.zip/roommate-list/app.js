(function(){
"use strict";
/* ---------- helpers ---------- */
const $=(s,r)=> (r||document).querySelector(s);
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const ls={get(k){try{return localStorage.getItem(k)}catch(e){return null}},set(k,v){try{localStorage.setItem(k,v)}catch(e){}},del(k){try{localStorage.removeItem(k)}catch(e){}}};
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const nf=new Intl.NumberFormat('en-IN',{maximumFractionDigits:2});
const money=n=>'₹'+nf.format(+n||0);
const fmtNum=n=>Number.isInteger(n)?String(n):String(+(+n).toFixed(3));
const UNITS=['piece','packet','kg','g','litre','ml','dozen','box','bottle','bundle','other'];
const ic={
 home:'<path d="M3 11l9-8 9 8v10h-6v-6H9v6H3z"/>',
 list:'<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
 people:'<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6"/><path d="M16 4.5a3.5 3.5 0 010 7M18.5 14.5c2 .8 3 2.6 3 5.5"/>',
 clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
 gear:'<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1"/>',
 plus:'<path d="M12 5v14M5 12h14"/>',
 check:'<path d="M5 12.5l4.5 4.5L19 7.5"/>',
 dots:'<circle cx="5" cy="12" r="1.3"/><circle cx="12" cy="12" r="1.3"/><circle cx="19" cy="12" r="1.3"/>',
 chev:'<path d="M6 9l6 6 6-6"/>',
 cart:'<path d="M3 4h2.5l2 11h10.5l2-8H7"/><circle cx="9" cy="20" r="1.3"/><circle cx="17" cy="20" r="1.3"/>'
};
const svg=(n,s)=>`<svg viewBox="0 0 24 24" width="${s||22}" height="${s||22}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ic[n]}</svg>`;
function hue(id){let h=0;for(const c of String(id)){h=(h*31+c.charCodeAt(0))%360}return h}
function avatar(id,name,sm){return `<span class="avatar${sm?' sm':''}" style="background:hsl(${hue(id)} 42% 36%)">${esc((name||'?').trim().charAt(0).toUpperCase()||'?')}</span>`}
function rel(t){
  if(!t)return '';
  const d=Date.now()-t,m=Math.round(d/60000);
  if(m<1)return 'just now'; if(m<60)return m+' min ago';
  const h=Math.round(m/60); if(h<24)return h+' h ago';
  const dt=new Date(t),today=new Date();
  const y=new Date(today.getFullYear(),today.getMonth(),today.getDate()-1);
  if(dt>=y&&h<48)return 'Yesterday';
  return dt.toLocaleDateString('en-IN',{day:'numeric',month:'short'});
}
const fdt=t=>t?new Date(t).toLocaleString('en-IN',{day:'numeric',month:'short',hour:'numeric',minute:'2-digit'}):'';
const fd=t=>t?new Date(t).toLocaleDateString('en-IN',{day:'numeric',month:'short',year:'numeric'}):'';
const normRid=s=>String(s||'').toUpperCase().replace(/[^A-Z0-9-]/g,'');
function genRid(){const a='ABCDEFGHJKMNPQRSTUVWXYZ23456789';const b=new Uint8Array(6);crypto.getRandomValues(b);return 'ROOM-'+Array.from(b,x=>a[x%a.length]).join('')}
function devId(){let v=ls.get('rm.dev');if(!v){const b=new Uint8Array(9);crypto.getRandomValues(b);v='d'+Array.from(b,x=>x.toString(36)).join('');ls.set('rm.dev',v)}return v}

/* ---------- state ---------- */
const S={db:null,user:null,dl:null,uid:null,rid:null,room:null,myName:'',members:{},items:[],activity:[],
  view:'home',q:'',member:'all',sort:'newest',group:'combined',showDone:false,hTab:'months',openMonths:new Set(),
  unseen:0,baseline:false,known:new Set(),slow:false,live:false,notify:ls.get('rm.notify')!=='0',readOnly:false,
  loginTab:'join',err:'',unsubs:[],leaving:false,joined:false,busy:false,loadTimer:null,theme:ls.get('rm.theme')||'auto',fatal:''};
const me=()=>S.members[S.uid]||null;
const isOwner=()=>!!me()&&me().role==='owner';
const nameOf=(id,fb)=>(S.members[id]&&S.members[id].name)||fb||'Someone';
const base=()=>'rooms/'+S.rid;
const lineTotal=i=>(+i.price||0)*(+i.qty||0);

function applyTheme(){const r=document.documentElement;if(S.theme==='light'||S.theme==='dark')r.setAttribute('data-theme',S.theme);else r.removeAttribute('data-theme')}
let toastT;
function toast(msg){const t=$('#toast');t.textContent=msg;t.hidden=false;clearTimeout(toastT);toastT=setTimeout(()=>{t.hidden=true},3200)}
async function copyText(text,label){
  try{await navigator.clipboard.writeText(text);toast((label||'Text')+' copied');return true}catch(e){}
  try{const ta=document.createElement('textarea');ta.value=text;ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.select();const ok=document.execCommand('copy');ta.remove();if(ok){toast((label||'Text')+' copied');return true}}catch(e){}
  toast('Could not copy. Select the text and copy it manually.');return false;
}
function errMsg(e){
  const c=e&&e.code;
  if(c==='taken')return 'That Room ID already exists. Choose another, or join it.';
  if(c==='notfound')return 'No room found with that ID. Check the ID or create a new room.';
  if(c==='removed')return 'You are no longer a member of that room. Join again with the Room ID.';
  if(c==='permission-denied')return 'The database refused this change. Check the Firestore rules in README.md.';
  if(c==='invalid_argument')return 'Saving was refused. Ask the person who shared this app to give you Contributor access.';
  if(c==='quota_exceeded')return 'Storage is full. Delete some old items first.';
  return 'Could not reach the server. Check your connection and try again.';
}

/* ---------- boot / login ---------- */
async function boot(){
  applyTheme();
  renderLogin();
  let db=null,user=null,dl=null;
  if(window.claude&&window.claude.use){try{[db,user,dl]=await Promise.all([claude.use('db'),claude.use('user'),claude.use('downloads')])}catch(e){}}
  if(!db&&window.RM_BACKEND_READY){const b=await window.RM_BACKEND_READY;db=b.db;user=b.user;dl=b.dl}
  if(!db){S.fatal='Storage is not available in this browser.';renderLogin();return}
  renderLogin();
  S.db=db;S.user=user;S.dl=dl;
  let id=null;try{id=user?await user.id():null}catch(e){}
  S.uid=id||devId();
  try{if(user&&(await user.can('data.write'))===false)S.readOnly=true}catch(e){}
  let saved=null;try{saved=JSON.parse(ls.get('rm.session')||'null')}catch(e){}
  if(saved&&saved.rid&&saved.name){
    try{await enterRoom({rid:saved.rid,name:saved.name,mode:'auto'});return}catch(e){S.err=errMsg(e);if(e&&e.code==='removed')ls.del('rm.session')}
  }
  renderLogin();
}
function renderLogin(){
  const last=(()=>{try{return JSON.parse(ls.get('rm.last')||'{}')}catch(e){return {}}})();
  const create=S.loginTab==='create';
  $('#root').innerHTML=`<div class="login">
    <div class="brand">${svg('cart',26)}</div>
    <h1>RoomMate List</h1>
    <p class="muted" style="margin:0 0 18px">One shared list for everything your room needs. Add items, see who added them, tick them off when bought.</p>
    ${S.fatal?`<div class="err">${esc(S.fatal)}</div>`:''}
    ${S.err?`<div class="err">${esc(S.err)}</div>`:''}
    ${window.RM_MODE==='local'?'<div class="info">Demo mode: data stays on this device and does not sync. Add your Firebase settings in config.js to share a list between phones.</div>':''}
    ${S.readOnly?'<div class="info">You have view-only access to this app, so you cannot join or edit. Ask the person who shared it to make you a Contributor.</div>':''}
    <div class="seg" style="margin-bottom:16px">
      <button type="button" data-act="loginTab" data-v="join" aria-pressed="${!create}">Join a room</button>
      <button type="button" data-act="loginTab" data-v="create" aria-pressed="${create}">Create a room</button>
    </div>
    <form data-form="login" class="card">
      ${create?`<div class="field"><label for="lg-roomname">Room name (optional)</label><input id="lg-roomname" maxlength="40" placeholder="Flat 302" autocomplete="off"></div>`:''}
      <div class="field"><label for="lg-rid">Room ID</label>
        <div class="row"><input id="lg-rid" class="grow" maxlength="30" value="${esc(create?'':(last.rid||''))}" placeholder="${create?'Choose or generate an ID':'ROOM-ABC123'}" autocapitalize="characters" autocomplete="off" required>
        ${create?'<button type="button" class="btn" data-act="genRid">Generate</button>':''}</div>
        ${create?'<span class="small muted">At least 6 characters: letters, numbers and dashes. Anyone who knows this ID can open your list, so keep it long and share it only with roommates.</span>':''}
      </div>
      <div class="field"><label for="lg-name">Your name</label><input id="lg-name" maxlength="24" value="${esc(last.name||'')}" placeholder="Ashu" autocomplete="given-name" required></div>
      <button class="btn primary block" type="submit" ${(!S.db||S.readOnly)?'disabled':''}>${S.db?(create?'Create room':'Join room'):'Connecting…'}</button>
    </form>
  </div>`;
}
async function doLogin(){
  if(S.busy)return;
  const create=S.loginTab==='create';
  const rid=normRid($('#lg-rid').value),name=$('#lg-name').value.trim().replace(/\s+/g,' ');
  const roomName=create?($('#lg-roomname').value||'').trim():'';
  if(!name){S.err='Enter your name.';return renderLogin()}
  if(create&&rid.length<6){S.err='Room ID needs at least 6 characters (letters, numbers, dashes).';return renderLogin()}
  if(!rid){S.err='Enter the Room ID.';return renderLogin()}
  S.busy=true;S.err='';
  try{await enterRoom({rid,name,mode:create?'create':'join',roomName})}
  catch(e){S.err=errMsg(e);renderLogin()}
  S.busy=false;
}
async function enterRoom({rid,name,mode,roomName}){
  const db=S.db,uid=S.uid;
  const roomRef=db.doc('rooms/'+rid),memRef=db.doc('rooms/'+rid+'/members/'+uid);
  const rs=await roomRef.get(),ms=await memRef.get();
  const now=Date.now();let isNew=false;
  if(mode==='create'){
    if(rs.exists)throw {code:'taken'};
    await roomRef.set({name:roomName||'Our room',ownerId:uid,createdAt:now});
    await memRef.set({name,role:'owner',joinedAt:now});isNew=true;
  }else{
    if(!rs.exists)throw {code:'notfound'};
    if(mode==='auto'&&!ms.exists)throw {code:'removed'};
    const prev=ms.exists?ms.data():null;
    const nm=(mode==='auto'&&prev)?prev.name:name;
    await memRef.set({name:nm,role:(prev&&prev.role)||'member',joinedAt:(prev&&prev.joinedAt)||now});
    name=nm;isNew=!prev;
  }
  S.rid=rid;S.myName=name;S.err='';
  ls.set('rm.session',JSON.stringify({rid,name}));ls.set('rm.last',JSON.stringify({rid,name}));
  startSync();
  if(isNew)logAct('join','');
}

/* ---------- sync ---------- */
function startSync(){
  S.members={};S.items=[];S.activity=[];S.room=null;S.baseline=false;S.known=new Set();S.joined=true;S.leaving=false;S.live=false;S.slow=false;S.unseen=0;S.view='home';
  mountApp();
  clearTimeout(S.loadTimer);S.loadTimer=setTimeout(()=>{if(!S.baseline){S.slow=true;render()}},10000);
  const db=S.db,b=base(),uid=S.uid,fail=e=>{if(e&&e.code==='revoked'){S.fatal='Your access to this app was withdrawn.';teardown();renderLogin()}};
  S.unsubs.push(db.doc(b).onSnapshot(s=>{S.room=s.exists?s.data():null;render()},fail));
  S.unsubs.push(db.collection(b+'/members').onSnapshot(snap=>{
    const m={};snap.docs.forEach(d=>{m[d.id]=d.data()});S.members=m;
    if(m[uid])S.myName=m[uid].name||S.myName;
    if(!snap.metadata.fromCache&&S.joined&&!S.leaving&&!m[uid]){kicked();return}
    render();
  },fail));
  S.unsubs.push(db.collection(b+'/items').onSnapshot(snap=>{
    S.items=snap.docs.map(d=>Object.assign({_id:d.id},d.data()));
    if(!snap.metadata.fromCache){S.live=true;if(!S.baseline){S.baseline=true;S.slow=false;clearTimeout(S.loadTimer);S.items.forEach(i=>S.known.add(i._id))}}
    if(S.baseline){
      const fresh=S.items.filter(i=>!S.known.has(i._id));
      fresh.forEach(i=>S.known.add(i._id));
      const others=fresh.filter(i=>i.addedBy!==uid);
      if(others.length){
        if(S.view!=='products')S.unseen+=others.length;
        if(S.notify)toast(others.length===1?nameOf(others[0].addedBy,others[0].addedByName)+' added '+others[0].name:others.length+' new items were added to the list');
      }
    }
    render();
  },fail));
  S.unsubs.push(db.collection(b+'/activity').orderBy('at','desc').limit(60).onSnapshot(snap=>{S.activity=snap.docs.map(d=>Object.assign({_id:d.id},d.data()));render()},fail));
}
function teardown(){S.unsubs.forEach(u=>{try{u()}catch(e){}});S.unsubs=[];clearTimeout(S.loadTimer);S.joined=false;S.rid=null;S.members={};S.items=[];S.activity=[]}
function kicked(){teardown();ls.del('rm.session');S.err='You were removed from the room by its owner.';renderLogin()}
async function logAct(kind,item){
  try{await S.db.collection(base()+'/activity').add({kind,item:item||'',by:S.uid,byName:S.myName,at:Date.now()})}catch(e){}
}

/* ---------- app shell ---------- */
function mountApp(){
  $('#root').innerHTML=`<div class="app">
    <header class="top" id="top"></header>
    <main id="main"></main>
  </div>
  <button class="fab" id="fab" data-act="add" aria-label="Add product">${svg('plus',28)}</button>
  <nav class="nav" aria-label="Main"><div id="nav"></div></nav>`;
  render();
}
function render(){
  if(!S.joined||!$('#main'))return;
  const r=S.room;
  $('#top').innerHTML=`<div class="t"><h1>${esc((r&&r.name)||S.rid)}</h1><div class="sub"><span class="dot ${S.live?'live':''}"></span>${S.live?'Live':(S.slow?'Offline or slow connection':'Connecting…')}<span>·</span><span>${Object.keys(S.members).length} members</span></div></div>
    <button class="avatar" style="background:hsl(${hue(S.uid)} 42% 36%);border:0;cursor:pointer" data-act="nav" data-v="settings" aria-label="Settings">${esc((S.myName||'?').charAt(0).toUpperCase())}</button>`;
  const tabs=[['home','Home','home'],['products','Products','list'],['members','Members','people'],['history','History','clock'],['settings','Settings','gear']];
  $('#nav').innerHTML=tabs.map(t=>`<button data-act="nav" data-v="${t[0]}" ${S.view===t[0]?'aria-current="page"':''}>${svg(t[2])}<span>${t[1]}${t[0]==='products'&&S.unseen?`<span class="dotbadge">${S.unseen}</span>`:''}</span></button>`).join('');
  $('#fab').hidden=!(S.view==='home'||S.view==='products');
  const m=$('#main');
  if(S.view==='products'&&$('#plist')){renderList();return}
  if(S.view==='settings'&&m.contains(document.activeElement)&&document.activeElement.tagName==='INPUT')return;
  m.innerHTML=({home:vHome,products:vProducts,members:vMembers,history:vHistory,settings:vSettings})[S.view]();
  if(S.view==='products')renderList();
}

/* ---------- views ---------- */
function stats(){
  const pend=S.items.filter(i=>i.status!=='purchased'),done=S.items.filter(i=>i.status==='purchased');
  return {pend,done,est:pend.reduce((a,i)=>a+lineTotal(i),0),spent:done.reduce((a,i)=>a+lineTotal(i),0)};
}
function memberIds(){
  const ids=Object.keys(S.members).sort((a,b)=>((S.members[a].role==='owner'?0:1)-(S.members[b].role==='owner'?0:1))||((S.members[a].joinedAt||0)-(S.members[b].joinedAt||0)));
  return ids;
}
function actRow(a){
  const who=nameOf(a.by,a.byName),it=a.item?`<b>${esc(a.item)}</b>`:'';
  const v={add:'added',edit:'edited',del:'deleted',buy:'bought',unbuy:'moved back to pending:',again:'added again:',join:'joined the room',leave:'left the room',remove:'removed from the room:',reset:'cleared the list'}[a.kind]||a.kind;
  return `<div class="act">${avatar(a.by,who,true)}<div class="tx"><b>${esc(who)}</b> ${v} ${it}<div class="small muted">${rel(a.at)}</div></div></div>`;
}
function vHome(){
  const st=stats(),ids=memberIds();
  const spend=ids.map(id=>({id,spent:st.done.filter(i=>i.purchasedBy===id).reduce((a,i)=>a+lineTotal(i),0),added:S.items.filter(i=>i.addedBy===id).length}));
  const mx=Math.max(1,...spend.map(s=>s.spent));
  return `${S.slow?'<div class="info">Connection looks slow. Changes will sync when it recovers.</div>':''}
  <h2 class="greet">Hi, ${esc(S.myName)}</h2>
  <div class="tiles">
    <div class="tile"><div class="v">${S.items.length}</div><div class="l">Total products</div></div>
    <div class="tile"><div class="v">${st.pend.length}</div><div class="l">Pending</div></div>
    <div class="tile"><div class="v">${st.done.length}</div><div class="l">Purchased</div></div>
    <div class="tile accent"><div class="v">${money(st.est)}</div><div class="l">Estimated cost to buy</div></div>
  </div>
  <section class="card"><h2>Spending by member</h2>
    ${spend.map(s=>`<div style="margin-bottom:12px"><div class="row"><span>${avatar(s.id,nameOf(s.id),true)}</span><span class="grow"><b>${esc(nameOf(s.id))}${s.id===S.uid?' (you)':''}</b></span><b class="num">${money(s.spent)}</b></div>
      <div class="bar"><i style="width:${Math.round(s.spent/mx*100)}%;background:hsl(${hue(s.id)} 42% 40%)"></i></div>
      <div class="small muted">${s.added} items added</div></div>`).join('')||'<div class="muted">No members yet.</div>'}
    <div class="small muted">Spending counts items a member marked as purchased (price × quantity). Total spent: <b class="num">${money(st.spent)}</b></div>
  </section>
  <section class="card"><div class="row" style="justify-content:space-between;margin-bottom:6px"><h2 style="margin:0">Recent activity</h2><button class="btn sm" data-act="seeAll">See all</button></div>
    ${S.activity.slice(0,5).map(actRow).join('')||'<div class="muted">Nothing yet. Add the first product with the + button.</div>'}
  </section>`;
}
function matches(i){
  if(S.member!=='all'&&i.addedBy!==S.member)return false;
  const q=S.q.trim().toLowerCase();
  return !q||(i.name||'').toLowerCase().includes(q)||(i.note||'').toLowerCase().includes(q);
}
function sorter(a,b){
  switch(S.sort){
    case 'oldest':return (a.createdAt||0)-(b.createdAt||0);
    case 'name':return (a.name||'').localeCompare(b.name||'',undefined,{sensitivity:'base'});
    case 'price-asc':return lineTotal(a)-lineTotal(b);
    case 'price-desc':return lineTotal(b)-lineTotal(a);
    default:return (b.createdAt||0)-(a.createdAt||0);
  }
}
function vProducts(){
  const ids=memberIds();
  return `<div class="toolbar">
    <input id="q" type="search" placeholder="Search products" value="${esc(S.q)}" aria-label="Search products">
    <select id="sort" aria-label="Sort"><option value="newest">Newest first</option><option value="oldest">Oldest first</option><option value="name">Name A–Z</option><option value="price-asc">Price: low to high</option><option value="price-desc">Price: high to low</option></select>
  </div>
  <div class="chips" role="group" aria-label="Filter by member">
    <button class="chip" data-act="fm" data-v="all" aria-pressed="${S.member==='all'}">Everyone</button>
    ${ids.map(id=>`<button class="chip" data-act="fm" data-v="${esc(id)}" aria-pressed="${S.member===id}">${esc(nameOf(id))}${id===S.uid?' (you)':''}</button>`).join('')}
  </div>
  <div class="seg" style="margin-bottom:8px">
    <button data-act="grp" data-v="combined" aria-pressed="${S.group==='combined'}">Combined list</button>
    <button data-act="grp" data-v="member" aria-pressed="${S.group==='member'}">By member</button>
  </div>
  <div id="plist"></div>`;
}
function sectionHtml(arr){
  const pend=arr.filter(i=>i.status!=='purchased'),done=arr.filter(i=>i.status==='purchased');
  let h='';
  if(pend.length)h+=`<div class="sec"><h3>To buy · ${pend.length}</h3><span class="small muted num">${money(pend.reduce((a,i)=>a+lineTotal(i),0))}</span></div><ul class="items">${pend.map(itemCard).join('')}</ul>`;
  if(done.length)h+=`<button class="togg" data-act="toggleDone"><span>Purchased · ${done.length}</span><span style="transform:rotate(${S.showDone?180:0}deg);display:flex">${svg('chev',20)}</span></button>${S.showDone?`<ul class="items">${done.map(itemCard).join('')}</ul>`:''}`;
  return h;
}
function renderList(){
  const sel=$('#sort');if(sel&&sel.value!==S.sort)sel.value=S.sort;
  const arr=S.items.filter(matches).sort(sorter);
  let h='';
  if(!S.items.length){h=`<div class="empty"><b>No products yet</b>Tap the + button to add the first item.</div>`}
  else if(!arr.length){h=`<div class="empty"><b>No matches</b>Try a different search or member.</div>`}
  else if(S.group==='combined'){h=sectionHtml(arr)}
  else{
    const keys=[...memberIds()];
    arr.forEach(i=>{if(!keys.includes(i.addedBy))keys.push(i.addedBy)});
    keys.forEach(id=>{
      if(S.member!=='all'&&id!==S.member)return;
      const mine=arr.filter(i=>i.addedBy===id);
      const nm=nameOf(id,(mine[0]&&mine[0].addedByName)||'Former member')+(S.members[id]?'':' (left)');
      h+=`<div class="mhead">${avatar(id,nm)}<h2 class="grow">${esc(nm)}${id===S.uid?' (you)':''}</h2><span class="small muted">${mine.length} items</span></div>`+(mine.length?sectionHtml(mine):`<div class="muted small">Nothing added yet.</div>`);
    });
  }
  const el=$('#plist');if(el)el.innerHTML=h;
}
function itemCard(it){
  const canEdit=it.addedBy===S.uid||isOwner(),done=it.status==='purchased',urgent=/urgent/i.test(it.note||'');
  return `<li class="item ${done?'done':''}">
    <button class="chk" data-act="toggle" data-id="${esc(it._id)}" aria-label="${done?'Mark as pending':'Mark as purchased'}: ${esc(it.name)}"><span>${svg('check',16)}</span></button>
    <div class="ibody">
      <div class="irow"><span class="iname">${esc(it.name)}</span><span class="iprice">${money(lineTotal(it))}</span></div>
      <div class="imeta">${fmtNum(it.qty)} ${esc(it.unit||'')} × ${money(it.price)}</div>
      <div class="imeta">Added by <b>${esc(nameOf(it.addedBy,it.addedByName))}</b> · ${fdt(it.createdAt)}</div>
      ${it.note?`<span class="note ${urgent?'urgent':''}">${esc(it.note)}</span>`:''}
      ${done?`<div class="imeta">Bought by ${esc(nameOf(it.purchasedBy,it.purchasedByName))} · ${fdt(it.purchasedAt)}</div>`:''}
    </div>
    <button class="more" data-act="menu" data-id="${esc(it._id)}" aria-label="More actions for ${esc(it.name)}" ${canEdit||done?'':'hidden'}>${svg('dots')}</button>
  </li>`;
}
function vMembers(){
  const ids=memberIds(),own=isOwner();
  const rid=S.rid;
  return `<section class="card"><h2>Room ID</h2><div class="ridbox">${esc(rid)}</div>
    <p class="small muted" style="margin:6px 0 12px">Roommates join with this ID. Treat it like a password.</p>
    <div class="row" style="flex-wrap:wrap"><button class="btn sm" data-act="copyRid">Copy ID</button><button class="btn sm" data-act="invite">Copy invite message</button></div></section>
  ${ids.map(id=>{const m=S.members[id],added=S.items.filter(i=>i.addedBy===id).length,spent=S.items.filter(i=>i.status==='purchased'&&i.purchasedBy===id).reduce((a,i)=>a+lineTotal(i),0);
    return `<div class="card"><div class="row">${avatar(id,m.name)}<div class="grow"><b>${esc(m.name)}${id===S.uid?' (you)':''}</b> <span class="badge ${m.role==='owner'?'':'gray'}">${m.role==='owner'?'Owner':'Member'}</span>
      <div class="small muted">Joined ${fd(m.joinedAt)} · ${added} items added · ${money(spent)} spent</div></div>
      ${own&&id!==S.uid?`<button class="btn sm danger" data-act="removeMember" data-id="${esc(id)}">Remove</button>`:''}</div></div>`}).join('')}`;
}
function vHistory(){
  const tab=`<div class="seg" style="margin-bottom:12px"><button data-act="hTab" data-v="months" aria-pressed="${S.hTab==='months'}">Monthly purchases</button><button data-act="hTab" data-v="activity" aria-pressed="${S.hTab==='activity'}">Activity</button></div>`;
  if(S.hTab==='activity')return tab+`<section class="card">${S.activity.map(actRow).join('')||'<div class="muted">No activity yet.</div>'}</section>`;
  const done=S.items.filter(i=>i.status==='purchased');
  if(!done.length)return tab+`<div class="empty"><b>No purchases yet</b>Tick items off on the Products tab and they will show up here by month.</div>`;
  const groups={};
  done.forEach(i=>{const d=new Date(i.purchasedAt||i.createdAt||0);const k=d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0');(groups[k]=groups[k]||[]).push(i)});
  const keys=Object.keys(groups).sort().reverse();
  return tab+keys.map((k,idx)=>{
    const arr=groups[k].sort((a,b)=>(b.purchasedAt||0)-(a.purchasedAt||0)),tot=arr.reduce((a,i)=>a+lineTotal(i),0);
    const [y,m]=k.split('-');const label=new Date(+y,+m-1,1).toLocaleDateString('en-IN',{month:'long',year:'numeric'});
    const by={};arr.forEach(i=>{by[i.purchasedBy]=(by[i.purchasedBy]||0)+lineTotal(i)});
    const open=S.openMonths.has(k)||(idx===0&&!S.openMonths.has('-'+k));
    return `<details class="month" data-k="${k}" ${open?'open':''}><summary><div><b>${label}</b><div class="small muted">${arr.length} items</div></div><b class="num">${money(tot)}</b></summary>
      <div class="inner">${Object.keys(by).map(id=>`<div class="line"><span>${esc(nameOf(id,(arr.find(i=>i.purchasedBy===id)||{}).purchasedByName))} spent</span><b class="num">${money(by[id])}</b></div>`).join('')}
      <div class="small muted" style="margin:10px 0 2px">Items</div>
      ${arr.map(i=>`<div class="line"><span>${esc(i.name)} <span class="muted">· ${fmtNum(i.qty)} ${esc(i.unit||'')} · ${fd(i.purchasedAt)}</span></span><span class="num">${money(lineTotal(i))}</span></div>`).join('')}</div></details>`;
  }).join('');
}
function vSettings(){
  const own=isOwner();
  return `<section class="card"><h2>Your name</h2><div class="row"><input id="st-name" class="grow" maxlength="24" value="${esc(S.myName)}" style="min-height:44px;padding:0 12px;border-radius:10px;border:1px solid var(--line);background:var(--bg)" aria-label="Your name"><button class="btn" data-act="saveName">Save</button></div></section>
  <section class="card"><h2>Appearance</h2><div class="seg"><button data-act="theme" data-v="auto" aria-pressed="${S.theme==='auto'}">Auto</button><button data-act="theme" data-v="light" aria-pressed="${S.theme==='light'}">Light</button><button data-act="theme" data-v="dark" aria-pressed="${S.theme==='dark'}">Dark</button></div></section>
  <section class="card"><h2>Notifications</h2><div class="row"><div class="grow">Alert me when a roommate adds a product<div class="small muted">Shown inside the app while it is open. There is no push alert when the app is closed.</div></div><button class="btn sm" data-act="notify" aria-pressed="${S.notify}">${S.notify?'On':'Off'}</button></div></section>
  <section class="card"><h2>Export and share</h2><div class="stack">
    <button class="btn" data-act="share">Share shopping list</button>
    ${S.dl?`<button class="btn" data-act="exportCsv">Download Excel file (.csv)</button><button class="btn" data-act="exportPdf">Download PDF</button>`:'<div class="small muted">Downloads are not available in this view.</div>'}
  </div></section>
  <section class="card"><h2>Room</h2><div class="small muted" style="margin-bottom:10px">${esc((S.room&&S.room.name)||'')} · ${esc(S.rid)}</div><div class="stack">
    ${own?`<button class="btn danger" data-act="clearPending">Clear pending items</button><button class="btn danger" data-act="resetAll">Reset everything, including history</button>`:'<div class="small muted">Only the room owner can clear or reset the list.</div>'}
    <button class="btn danger" data-act="leave">Leave room</button></div></section>`;
}

/* ---------- sheets ---------- */
function openSheet(html){const s=$('#scrim');s.innerHTML=`<div class="sheet" role="dialog" aria-modal="true">${html}</div>`;s.hidden=false;const f=s.querySelector('input,select,textarea,button');if(f&&!/Android|iPhone/i.test(navigator.userAgent))f.focus()}
function closeSheet(){const s=$('#scrim');s.hidden=true;s.innerHTML=''}
function confirmSheet({title,body,ok,danger,run}){
  confirmSheet.run=run;
  openSheet(`<h2>${esc(title)}</h2><p class="muted" style="margin:0 0 16px">${esc(body)}</p><div class="two"><button class="btn" data-act="closeSheet">Cancel</button><button class="btn ${danger?'danger':'primary'}" data-act="confirmOk">${esc(ok)}</button></div>`);
}
function itemForm(it){
  const e=!!it;
  const names=[...new Set(S.items.map(i=>i.name))].slice(0,80);
  const unit=e?it.unit:'piece';
  openSheet(`<h2>${e?'Edit product':'Add product'}</h2>
  <form data-form="item" data-id="${e?esc(it._id):''}">
    <div class="field"><label for="f-name">Product name</label><input id="f-name" list="f-names" maxlength="60" required autocomplete="off" value="${e?esc(it.name):''}" placeholder="Milk"><datalist id="f-names">${names.map(n=>`<option value="${esc(n)}">`).join('')}</datalist></div>
    <div class="two"><div class="field"><label for="f-price">Price per unit (₹)</label><input id="f-price" inputmode="decimal" value="${e?esc(fmtNum(it.price)):''}" placeholder="60"></div>
    <div class="field"><label for="f-qty">Quantity</label><input id="f-qty" inputmode="decimal" value="${e?esc(fmtNum(it.qty)):'1'}"></div></div>
    <div class="field"><label for="f-unit">Unit</label><select id="f-unit">${UNITS.map(u=>`<option ${u===unit?'selected':''}>${u}</option>`).join('')}</select></div>
    <div class="field"><label for="f-note">Note (optional)</label><input id="f-note" maxlength="100" value="${e?esc(it.note||''):''}" placeholder="Urgent, brand preference…">
      <div class="qchips">${['Urgent','Need tomorrow','Brand preference'].map(q=>`<button type="button" class="chip" data-act="qnote" data-v="${q}">${q}</button>`).join('')}</div></div>
    <div class="two"><button type="button" class="btn" data-act="closeSheet">Cancel</button><button type="submit" class="btn primary">${e?'Save changes':'Add to list'}</button></div>
  </form>`);
}
function parseNum(v,def){const n=parseFloat(String(v).replace(',','.'));return isFinite(n)?n:def}
async function saveItem(form){
  const name=$('#f-name').value.trim().replace(/\s+/g,' ');if(!name)return;
  const price=Math.max(0,parseNum($('#f-price').value,0)),qty=parseNum($('#f-qty').value,1);
  if(!(qty>0)){toast('Quantity must be more than zero');return}
  const data={name,nameLower:name.toLowerCase(),price,qty,unit:$('#f-unit').value,note:$('#f-note').value.trim(),updatedAt:Date.now()};
  const id=form.dataset.id;
  try{
    if(id){await S.db.doc(base()+'/items/'+id).update(data);logAct('edit',name);toast('Saved')}
    else{
      const ref=S.db.collection(base()+'/items').doc();S.known.add(ref.id);
      await ref.set(Object.assign(data,{addedBy:S.uid,addedByName:S.myName,createdAt:Date.now(),status:'pending'}));
      logAct('add',name);toast(name+' added');
    }
    closeSheet();
  }catch(e){toast(errMsg(e))}
}
async function toggleBought(id){
  const it=S.items.find(i=>i._id===id);if(!it)return;
  try{
    if(it.status==='purchased'){await S.db.doc(base()+'/items/'+id).update({status:'pending',purchasedBy:null,purchasedByName:null,purchasedAt:null});logAct('unbuy',it.name)}
    else{await S.db.doc(base()+'/items/'+id).update({status:'purchased',purchasedBy:S.uid,purchasedByName:S.myName,purchasedAt:Date.now()});logAct('buy',it.name)}
  }catch(e){toast(errMsg(e))}
}
function itemMenu(id){
  const it=S.items.find(i=>i._id===id);if(!it)return;
  const can=it.addedBy===S.uid||isOwner();
  openSheet(`<h2>${esc(it.name)}</h2><div class="stack">
    ${can?`<button class="btn" data-act="edit" data-id="${esc(id)}">Edit</button>`:''}
    ${it.status==='purchased'?`<button class="btn" data-act="again" data-id="${esc(id)}">Add again (buy another day)</button>`:''}
    ${can?`<button class="btn danger" data-act="del" data-id="${esc(id)}">Delete</button>`:''}
    <button class="btn" data-act="closeSheet">Close</button></div>`);
}
async function addAgain(id){
  const it=S.items.find(i=>i._id===id);if(!it)return;
  try{
    const ref=S.db.collection(base()+'/items').doc();S.known.add(ref.id);
    await ref.set({name:it.name,nameLower:it.nameLower||it.name.toLowerCase(),price:it.price,qty:it.qty,unit:it.unit,note:it.note||'',addedBy:S.uid,addedByName:S.myName,createdAt:Date.now(),updatedAt:Date.now(),status:'pending'});
    logAct('again',it.name);closeSheet();toast(it.name+' added to the list again');
  }catch(e){toast(errMsg(e))}
}
function delItem(id){
  const it=S.items.find(i=>i._id===id);if(!it)return;
  confirmSheet({title:'Delete '+it.name+'?',body:'This removes it for everyone in the room.',ok:'Delete',danger:true,run:async()=>{
    try{await S.db.doc(base()+'/items/'+id).delete();logAct('del',it.name);toast('Deleted')}catch(e){toast(errMsg(e))}}});
}
async function deleteMany(list,label){
  if(S.busy)return;S.busy=true;toast(label+'…');
  try{for(const i of list){await S.db.doc(base()+'/items/'+i._id).delete();await sleep(25)}toast('Done')}
  catch(e){toast(errMsg(e))}
  S.busy=false;
}

/* ---------- export / share ---------- */
function sortedForExport(){return S.items.slice().sort((a,b)=>(a.status==='purchased')-(b.status==='purchased')||(b.createdAt||0)-(a.createdAt||0))}
async function exportCsv(){
  const q=v=>'"'+String(v==null?'':v).replace(/"/g,'""')+'"';
  const rows=[['Product','Price per unit (INR)','Quantity','Unit','Total (INR)','Status','Added by','Added on','Bought by','Bought on','Note']];
  sortedForExport().forEach(i=>rows.push([i.name,i.price,i.qty,i.unit,lineTotal(i),i.status==='purchased'?'Purchased':'Pending',nameOf(i.addedBy,i.addedByName),fdt(i.createdAt),i.status==='purchased'?nameOf(i.purchasedBy,i.purchasedByName):'',i.status==='purchased'?fdt(i.purchasedAt):'',i.note||'']));
  if(rows.length===1){toast('The list is empty');return}
  const csv='﻿'+rows.map(r=>r.map(q).join(',')).join('\r\n');
  try{await S.dl.save({filename:'roommate-list-'+new Date().toISOString().slice(0,10)+'.csv',data:csv});toast('Saved')}catch(e){if(!e||e.code!=='declined')toast('Could not save the file')}
}
async function exportPdf(){
  const J=window.jspdf&&window.jspdf.jsPDF;if(!J){toast('PDF export did not load. Try the Excel file instead.');return}
  if(!S.items.length){toast('The list is empty');return}
  const a=s=>String(s==null?'':s).replace(/[^\x20-\x7E]/g,'?'),rs=n=>'Rs.'+nf.format(+n||0);
  const doc=new J({unit:'mm',format:'a4'});let y=18;
  doc.setFont('helvetica','bold');doc.setFontSize(16);doc.text(a((S.room&&S.room.name)||'Room')+' - shopping list',14,y);y+=6;
  doc.setFont('helvetica','normal');doc.setFontSize(9);doc.text('Exported '+fd(Date.now()),14,y);y+=9;
  const head=t=>{if(y>270){doc.addPage();y=18}doc.setFont('helvetica','bold');doc.setFontSize(11);doc.text(t,14,y);y+=6;doc.setFontSize(8.5);doc.text('Product',14,y);doc.text('Qty',92,y);doc.text('Price',118,y);doc.text('Total',142,y);doc.text('By',168,y);y+=2;doc.line(14,y,196,y);y+=4;doc.setFont('helvetica','normal')};
  const rowf=i=>{if(y>280){doc.addPage();y=18}let n=a(i.name);if(n.length>40)n=n.slice(0,38)+'..';doc.text(n,14,y);doc.text(fmtNum(i.qty)+' '+a(i.unit),92,y);doc.text(rs(i.price),118,y);doc.text(rs(lineTotal(i)),142,y);doc.text(a(nameOf(i.addedBy,i.addedByName)).slice(0,14),168,y);y+=5.5;
    if(i.note){doc.setTextColor(110);doc.text('  note: '+a(i.note).slice(0,90),14,y);doc.setTextColor(0);y+=5}};
  const st=stats();
  if(st.pend.length){head('To buy ('+st.pend.length+')');st.pend.sort(sorter).forEach(rowf);doc.setFont('helvetica','bold');doc.text('Estimated total: '+rs(st.est),14,y);doc.setFont('helvetica','normal');y+=10}
  if(st.done.length){head('Purchased ('+st.done.length+')');st.done.sort((x,z)=>(z.purchasedAt||0)-(x.purchasedAt||0)).forEach(rowf);doc.setFont('helvetica','bold');doc.text('Total spent: '+rs(st.spent),14,y)}
  try{await S.dl.save({filename:'roommate-list-'+new Date().toISOString().slice(0,10)+'.pdf',data:doc.output('arraybuffer')});toast('Saved')}catch(e){if(!e||e.code!=='declined')toast('Could not save the file')}
}
function shareText(){
  const st=stats(),L=[];
  L.push('Shopping list - '+((S.room&&S.room.name)||'our room'));
  if(!st.pend.length)L.push('','Nothing pending.');
  else{L.push('','To buy:');st.pend.sort(sorter).forEach(i=>L.push('- '+i.name+' ('+fmtNum(i.qty)+' '+(i.unit||'')+', '+money(lineTotal(i))+')'+(i.note?' - '+i.note:'')+' [added by '+nameOf(i.addedBy,i.addedByName)+']'));L.push('','Estimated: '+money(st.est))}
  return L.join('\n');
}
function shareSheet(){
  const t=shareText();
  openSheet(`<h2>Share shopping list</h2><textarea class="share" id="sh-t" readonly>${esc(t)}</textarea>
  <div class="stack" style="margin-top:12px"><button class="btn primary" data-act="copyShare">Copy text</button>
  <a class="btn" target="_blank" rel="noopener" href="https://wa.me/?text=${encodeURIComponent(t)}">Send on WhatsApp</a>
  <button class="btn" data-act="closeSheet">Close</button></div>`);
}

/* ---------- events ---------- */
const A={
  loginTab(t){S.loginTab=t.dataset.v;S.err='';renderLogin()},
  genRid(){$('#lg-rid').value=genRid()},
  nav(t){S.view=t.dataset.v;if(S.view==='products')S.unseen=0;window.scrollTo(0,0);const m=$('#main');if(m)m.innerHTML='';render()},
  seeAll(){S.hTab='activity';S.view='history';render()},
  add(){if(S.readOnly)return toast('You have view-only access');itemForm(null)},
  edit(t){const it=S.items.find(i=>i._id===t.dataset.id);closeSheet();if(it)itemForm(it)},
  del(t){closeSheet();delItem(t.dataset.id)},
  again(t){addAgain(t.dataset.id)},
  menu(t){itemMenu(t.dataset.id)},
  toggle(t){toggleBought(t.dataset.id)},
  fm(t){S.member=t.dataset.v;$('#main').innerHTML=vProducts();renderList()},
  grp(t){S.group=t.dataset.v;$('#main').innerHTML=vProducts();renderList()},
  toggleDone(){S.showDone=!S.showDone;renderList()},
  qnote(t){const n=$('#f-note');const v=t.dataset.v;n.value=n.value?(n.value.toLowerCase().includes(v.toLowerCase())?n.value:n.value+', '+v):v},
  hTab(t){S.hTab=t.dataset.v;$('#main').innerHTML=vHistory()},
  closeSheet(){closeSheet()},
  confirmOk(){const r=confirmSheet.run;closeSheet();if(r)r()},
  copyRid(){copyText(S.rid,'Room ID')},
  invite(){copyText('Join our room on RoomMate List. Room ID: '+S.rid+'. Open the app link I shared, choose "Join a room" and enter this ID.','Invite')},
  theme(t){S.theme=t.dataset.v;ls.set('rm.theme',S.theme);applyTheme();$('#main').innerHTML=vSettings()},
  notify(){S.notify=!S.notify;ls.set('rm.notify',S.notify?'1':'0');$('#main').innerHTML=vSettings()},
  async saveName(){
    const v=($('#st-name').value||'').trim().replace(/\s+/g,' ');if(!v)return toast('Enter a name');
    try{await S.db.doc(base()+'/members/'+S.uid).update({name:v});S.myName=v;ls.set('rm.session',JSON.stringify({rid:S.rid,name:v}));toast('Name updated')}catch(e){toast(errMsg(e))}
  },
  share(){shareSheet()},
  copyShare(){copyText($('#sh-t').value,'List')},
  exportCsv(){exportCsv()},
  exportPdf(){exportPdf()},
  removeMember(t){
    const id=t.dataset.id,nm=nameOf(id);
    confirmSheet({title:'Remove '+nm+'?',body:'They lose access to this room. Items they added stay on the list. They can rejoin with the Room ID unless you change rooms.',ok:'Remove',danger:true,run:async()=>{
      try{await S.db.doc(base()+'/members/'+id).delete();logAct('remove',nm);toast(nm+' removed')}catch(e){toast(errMsg(e))}}});
  },
  clearPending(){const l=S.items.filter(i=>i.status!=='purchased');if(!l.length)return toast('No pending items');
    confirmSheet({title:'Clear '+l.length+' pending items?',body:'Purchased items and your monthly history stay. This cannot be undone.',ok:'Clear pending',danger:true,run:async()=>{await deleteMany(l,'Clearing');logAct('reset','')}})},
  resetAll(){
    confirmSheet({title:'Reset the whole list?',body:'This deletes every product, the purchase history and the activity log for everyone in the room. This cannot be undone.',ok:'Delete everything',danger:true,run:async()=>{
      await deleteMany(S.items.slice(),'Resetting');
      try{for(const a of S.activity.slice()){await S.db.doc(base()+'/activity/'+a._id).delete();await sleep(20)}}catch(e){}
      logAct('reset','')}});
  },
  leave(){
    const others=Object.keys(S.members).filter(id=>id!==S.uid).length;
    confirmSheet({title:'Leave this room?',body:isOwner()&&others?'Ownership passes to the member who joined next. You can rejoin later with the Room ID.':'You can rejoin later with the Room ID.',ok:'Leave room',danger:true,run:leaveRoom});
  }
};
async function leaveRoom(){
  S.leaving=true;
  try{
    if(isOwner()){
      const o=Object.keys(S.members).filter(id=>id!==S.uid).sort((a,b)=>(S.members[a].joinedAt||0)-(S.members[b].joinedAt||0))[0];
      if(o){await S.db.doc(base()+'/members/'+o).update({role:'owner'});await S.db.doc('rooms/'+S.rid).update({ownerId:o})}
    }
    await logAct('leave','');
    await S.db.doc(base()+'/members/'+S.uid).delete();
    teardown();ls.del('rm.session');S.err='';S.view='home';renderLogin();
  }catch(e){S.leaving=false;toast(errMsg(e))}
}
document.addEventListener('click',e=>{
  if(e.target.id==='scrim'){closeSheet();return}
  const t=e.target.closest('[data-act]');if(!t||t.disabled)return;
  const f=A[t.dataset.act];if(f){e.preventDefault();f(t)}
});
document.addEventListener('submit',e=>{
  const f=e.target.closest('form');if(!f)return;e.preventDefault();
  if(f.dataset.form==='login')doLogin();else if(f.dataset.form==='item')saveItem(f);
});
document.addEventListener('input',e=>{if(e.target.id==='q'){S.q=e.target.value;renderList()}});
document.addEventListener('change',e=>{if(e.target.id==='sort'){S.sort=e.target.value;renderList()}});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('#scrim').hidden)closeSheet()});
document.addEventListener('toggle',e=>{
  const d=e.target;if(!d.classList||!d.classList.contains('month'))return;
  const k=d.dataset.k;if(d.open){S.openMonths.add(k);S.openMonths.delete('-'+k)}else{S.openMonths.delete(k);S.openMonths.add('-'+k)}
},true);
boot();
})();
