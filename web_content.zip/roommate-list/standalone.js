/* Storage layer for the standalone build.
   - With Firebase settings in config.js: shared, real-time sync through Cloud Firestore.
   - Without them: demo mode, data kept in this browser only (no sync). */
(function(){
"use strict";
function autoId(){
  const a='abcdefghijklmnopqrstuvwxyz0123456789',b=new Uint8Array(20);let s='';
  if(typeof window!=='undefined'&&window.crypto&&window.crypto.getRandomValues)window.crypto.getRandomValues(b);
  else for(let i=0;i<20;i++)b[i]=Math.floor(Math.random()*256);
  for(let i=0;i<20;i++)s+=a[b[i]%a.length];
  return s;
}

function makeLocalDb(storage,win){
  const KEY='rm.localdb';
  const load=()=>{try{return JSON.parse(storage.getItem(KEY)||'{}')}catch(e){return {}}};
  const save=o=>{try{storage.setItem(KEY,JSON.stringify(o))}catch(e){}};
  const subs=new Set();
  const notify=()=>subs.forEach(f=>{try{f()}catch(e){}});
  if(win&&win.addEventListener)win.addEventListener('storage',e=>{if(e.key===KEY)notify()});
  const meta={fromCache:false,hasPendingWrites:false};
  const clone=v=>JSON.parse(JSON.stringify(v));
  const snapDoc=(id,v)=>({id:id,exists:v!==undefined,data:()=>v===undefined?undefined:clone(v),metadata:meta});
  const children=(db,col)=>{const p=col+'/';return Object.keys(db).filter(k=>k.indexOf(p)===0&&k.slice(p.length).indexOf('/')<0)};
  function docRef(path){
    const id=path.split('/').pop();
    return {id:id,path:path,
      async get(){return snapDoc(id,load()[path])},
      async set(d){const db=load();db[path]=clone(d);save(db);notify()},
      async update(d){const db=load();if(!db[path])throw {code:'invalid_argument',message:'Document does not exist'};Object.assign(db[path],clone(d));save(db);notify()},
      async delete(){const db=load();delete db[path];save(db);notify()},
      onSnapshot(next){let last='\u0000init';const run=()=>{const v=load()[path];const s=JSON.stringify(v===undefined?null:v);if(s===last)return;last=s;next(snapDoc(id,v))};subs.add(run);setTimeout(run,0);return()=>subs.delete(run)},
      collection(p){return colRef(path+'/'+p)}};
  }
  function colRef(path,q){
    q=q||{};
    const read=()=>{
      const db=load();
      let r=children(db,path).map(k=>({id:k.split('/').pop(),v:db[k]}));
      if(q.order){const f=q.order[0],dir=q.order[1];r.sort((a,b)=>{const x=a.v[f],y=b.v[f];return (x>y?1:x<y?-1:0)*(dir==='desc'?-1:1)})}
      else r.sort((a,b)=>a.id<b.id?-1:1);
      if(q.limit)r=r.slice(0,q.limit);
      return r;
    };
    const qsnap=r=>({docs:r.map(x=>snapDoc(x.id,x.v)),size:r.length,empty:!r.length,metadata:meta,docChanges:()=>[]});
    return {path:path,
      orderBy(f,d){return colRef(path,Object.assign({},q,{order:[f,d||'asc']}))},
      limit(n){return colRef(path,Object.assign({},q,{limit:n}))},
      async get(){return qsnap(read())},
      onSnapshot(next){let last='\u0000init';const run=()=>{const r=read();const s=JSON.stringify(r);if(s===last)return;last=s;next(qsnap(r))};subs.add(run);setTimeout(run,0);return()=>subs.delete(run)},
      doc(id){return docRef(path+'/'+(id||autoId()))},
      async add(d){const r=docRef(path+'/'+autoId());await r.set(d);return r}};
  }
  return {doc:docRef,collection:colRef};
}
if(typeof module!=='undefined'&&module.exports){module.exports={makeLocalDb:makeLocalDb};return}

function loadScript(src){return new Promise(function(res,rej){const s=document.createElement('script');s.src=src;s.onload=res;s.onerror=function(){rej(new Error('Could not load '+src))};document.head.appendChild(s)})}
const dl={async save(o){
  const type=/\.pdf$/i.test(o.filename)?'application/pdf':'text/csv;charset=utf-8';
  const url=URL.createObjectURL(new Blob([o.data],{type:type}));
  const a=document.createElement('a');a.href=url;a.download=o.filename;document.body.appendChild(a);a.click();a.remove();
  setTimeout(function(){URL.revokeObjectURL(url)},4000);
  return {status:'saved'};
}};

window.RM_BACKEND_READY=(async function(){
  const cfg=window.RM_FIREBASE_CONFIG;
  if(cfg&&cfg.apiKey&&cfg.projectId){
    try{
      await loadScript('https://www.gstatic.com/firebasejs/10.12.2/firebase-app-compat.js');
      await loadScript('https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore-compat.js');
      firebase.initializeApp(cfg);
      const fs=firebase.firestore();
      window.RM_MODE='firebase';
      return {db:{doc:function(p){return fs.doc(p)},collection:function(p){return fs.collection(p)}},user:null,dl:dl};
    }catch(e){console.warn('Firebase failed to load, using local demo mode.',e)}
  }
  window.RM_MODE='local';
  return {db:makeLocalDb(window.localStorage,window),user:null,dl:dl};
})();
})();
