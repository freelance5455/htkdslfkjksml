// Capacitor configuration for building the Android APK with the attached google-services.json
// Package Name matches Com.zahidavatar.appname from google-services.json
const config = {
  appId: 'Com.zahidavatar.appname',
  appName: 'Zahid Avatar',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
  },
  android: {
    backgroundColor: '#0b0906',
  },
};

export default config;
