import { useEffect, useRef, useState } from 'react';
import { BottomNav } from './components/BottomNav';
import { GamesArenaScreen } from './components/GamesArenaScreen';
import { HomeScreen } from './components/HomeScreen';
import { LeaderboardScreen } from './components/LeaderboardScreen';
import { OfflineIndicator, PWAInstallButton } from './components/PWAInstallButton';
import { RoyalAdBanner } from './components/RoyalAdBanner';
import { RoyalAdsModal } from './components/RoyalAdsModal';
import { SettingsModal } from './components/SettingsModal';
import { ShopWalletScreen } from './components/ShopWalletScreen';
import { ToastBanner } from './components/ToastBanner';
import { TopBar } from './components/TopBar';
import { VipProfileScreen } from './components/VipProfileScreen';
import { useGameStore } from './hooks/useGameStore';

export default function App() {
  const {
    state,
    vipInfo,
    canClaimDaily,
    toasts,
    leaderboard,
    friends,
    playSound,
    dismissToast,
    showToast,
    setActiveTab,
    openGame,
    setWager,
    claimDailyBonus,
    claimAdReward,
    recordGameOutcome,
    recordWheelOfFortuneOutcome,
    purchaseCoinPack,
    exchangeGemsForCoins,
    withdrawCoins,
    sendFriendGift,
    toggleSound,
    toggleAnimations,
    resetDemoState,
  } = useGameStore();

  const [settingsOpen, setSettingsOpen] = useState(false);
  const [adModalOpen, setAdModalOpen] = useState(false);
  const [walletSection, setWalletSection] = useState<'topup' | 'withdraw'>('topup');
  const scrollRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTo({ top: 0, behavior: state.animationsEnabled ? 'smooth' : 'auto' });
    }
  }, [state.activeTab, state.currentGame, state.animationsEnabled]);

  const handleChallengeFriend = (friendName: string) => {
    openGame('dragon-cards');
    showToast('Duel Arena Ready', `Challenged ${friendName} to Dragon Cards!`, 'gold');
  };

  return (
    <div className="min-h-[100dvh] w-full bg-[#050403] bg-[radial-gradient(ellipse_at_top,_rgba(212,175,55,0.11)_0%,_rgba(11,9,6,0.95)_55%,_#050403_100%)] flex items-center justify-center sm:p-4">
      {/* Sleek Mobile App Frame (max-width: 414px) */}
      <div className="relative w-full max-w-[414px] h-[100dvh] sm:h-[852px] sm:max-h-[94dvh] bg-[#0b0906] sm:rounded-[34px] border-x sm:border border-[#d4af37]/30 shadow-[0_0_70px_rgba(212,175,55,0.16)] flex flex-col overflow-hidden">
        {/* Top Bar */}
        <TopBar
          coins={state.coins}
          gems={state.gems}
          vipTier={vipInfo.tier}
          onAddCoins={() => {
            setWalletSection('topup');
            setActiveTab('shop');
          }}
          onWithdrawCoins={() => {
            setWalletSection('withdraw');
            setActiveTab('shop');
          }}
          onOpenProfile={() => setActiveTab('vip')}
          onOpenSettings={() => {
            playSound('click');
            setSettingsOpen(true);
          }}
        />

        {/* Offline Banner if disconnected */}
        <OfflineIndicator />

        {/* Floating Toast Notifications */}
        <ToastBanner toasts={toasts} onDismiss={dismissToast} />

        {/* Main Scrollable Screen Area */}
        <main
          ref={scrollRef}
          className="flex-1 overflow-y-auto px-3.5 pt-4 pb-3 royal-scroll space-y-4"
        >
          {state.activeTab === 'home' && (
            <>
              <div className="flex items-center justify-between gap-2 px-1">
                <span className="text-[11px] font-medium text-[#a8997a]">
                  Zahid Avatar Mobile Edition
                </span>
                <PWAInstallButton compact />
              </div>
              <HomeScreen
                streak={state.streak}
                canClaimDaily={canClaimDaily}
                history={state.history}
                onClaimDaily={claimDailyBonus}
                onPlayGame={openGame}
                onViewAllGames={() => setActiveTab('games')}
                onViewLedger={() => setActiveTab('shop')}
              />
            </>
          )}

          {state.activeTab === 'games' && (
            <GamesArenaScreen
              currentGame={state.currentGame}
              wager={state.wager}
              coins={state.coins}
              lastWheelOfFortuneSpinAt={state.lastWheelOfFortuneSpinAt}
              animationsEnabled={state.animationsEnabled}
              onPlaySound={playSound}
              onSelectGame={openGame}
              onSelectWager={setWager}
              onOpenShop={() => {
                setWalletSection('topup');
                setActiveTab('shop');
              }}
              onWatchAd={() => {
                playSound('click');
                setAdModalOpen(true);
              }}
              onOutcome={recordGameOutcome}
              onWheelOfFortuneOutcome={recordWheelOfFortuneOutcome}
            />
          )}

          {state.activeTab === 'leaderboard' && (
            <LeaderboardScreen
              members={leaderboard}
              onPlaySound={playSound}
              onPlayNow={() => setActiveTab('games')}
            />
          )}

          {state.activeTab === 'shop' && (
            <ShopWalletScreen
              coins={state.coins}
              gems={state.gems}
              history={state.history}
              walletSection={walletSection}
              onChangeSection={setWalletSection}
              onPlaySound={playSound}
              onPurchasePack={purchaseCoinPack}
              onExchangeGems={exchangeGemsForCoins}
              onWithdrawCoins={withdrawCoins}
            />
          )}

          {state.activeTab === 'vip' && (
            <VipProfileScreen
              xp={state.xp}
              vipInfo={vipInfo}
              roundsPlayed={state.roundsPlayed}
              winsCount={state.winsCount}
              biggestWin={state.biggestWin}
              friends={friends}
              onSendGift={sendFriendGift}
              onChallengeFriend={handleChallengeFriend}
            />
          )}

          {/* Sponsored Ad Banner integrated cleanly at end of screen flow */}
          <RoyalAdBanner
            onWatchAd={() => {
              playSound('click');
              setAdModalOpen(true);
            }}
          />
        </main>

        {/* Bottom Navigation Bar */}
        <BottomNav activeTab={state.activeTab} onSelectTab={setActiveTab} />

        {/* Rewarded Ad Modal */}
        <RoyalAdsModal
          isOpen={adModalOpen}
          onClose={() => {
            playSound('click');
            setAdModalOpen(false);
          }}
          onClaimReward={claimAdReward}
        />

        {/* Settings Sheet */}
        <SettingsModal
          isOpen={settingsOpen}
          soundEnabled={state.soundEnabled}
          animationsEnabled={state.animationsEnabled}
          onClose={() => {
            playSound('click');
            setSettingsOpen(false);
          }}
          onToggleSound={toggleSound}
          onToggleAnimations={toggleAnimations}
          onEmergencyRefill={() => purchaseCoinPack(1000, 0)}
          onResetProgress={resetDemoState}
        />
      </div>
    </div>
  );
}
