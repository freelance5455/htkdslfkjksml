import { Coins, Crown, Gem, Play, ShieldCheck, X } from 'lucide-react';
import { useEffect, useState } from 'react';
import { ROYAL_ASSETS } from '../data/games';

interface RoyalAdsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onClaimReward: () => void;
}

const ROYAL_SPONSORS = [
  {
    brand: 'Imperial Sovereign Club',
    headline: 'Unlock High-Roller Tables & Weekly Tournaments',
    cta: 'VIP Arena Event',
    art: ROYAL_ASSETS.vaultBanner,
  },
  {
    brand: 'Dragon Guild Treasury',
    headline: 'Double Gem Weekends Across All 9 Royal Modes',
    cta: 'Featured Sponsor',
    art: ROYAL_ASSETS.dragonEmblem,
  },
  {
    brand: 'Zahid Obsidian Reserve',
    headline: 'Instant Easypaisa & JazzCash Vault Transfers',
    cta: 'Royal Partner',
    art: ROYAL_ASSETS.avatar,
  },
];

export function RoyalAdsModal({
  isOpen,
  onClose,
  onClaimReward,
}: RoyalAdsModalProps) {
  const [secondsLeft, setSecondsLeft] = useState(5);
  const [sponsorIdx, setSponsorIdx] = useState(0);

  useEffect(() => {
    if (!isOpen) return;
    setSecondsLeft(5);
    setSponsorIdx((prev) => (prev + 1) % ROYAL_SPONSORS.length);
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen || secondsLeft <= 0) return;
    const timer = window.setTimeout(() => {
      setSecondsLeft((s) => Math.max(0, s - 1));
    }, 1000);
    return () => window.clearTimeout(timer);
  }, [isOpen, secondsLeft]);

  if (!isOpen) return null;

  const sponsor = ROYAL_SPONSORS[sponsorIdx];
  const progress = ((5 - secondsLeft) / 5) * 100;
  const ready = secondsLeft === 0;

  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4">
      <div className="w-full rounded-3xl bg-[#120e09] border border-[#d4af37]/45 overflow-hidden shadow-[0_20px_60px_rgba(0,0,0,0.9)]">
        {/* Top Ad Bar */}
        <div className="flex items-center justify-between px-4 py-2.5 bg-[#0b0906] border-b border-[#d4af37]/20">
          <div className="flex items-center gap-2 text-[11px] font-semibold text-[#ffe885]">
            <span className="px-1.5 py-0.5 rounded bg-[#d4af37]/25 border border-[#d4af37]/40 text-[10px] font-mono-num">
              AD
            </span>
            <span>Royal Rewarded Sponsor</span>
          </div>

          {ready ? (
            <button
              type="button"
              onClick={onClose}
              aria-label="Close Ad"
              className="w-7 h-7 rounded-full bg-[#221b11] border border-[#d4af37]/30 flex items-center justify-center text-[#ffe885]"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          ) : (
            <span className="font-mono-num text-[11px] font-bold text-[#a8997a]">
              Reward in {secondsLeft}s
            </span>
          )}
        </div>

        {/* Visual Showcase */}
        <div className="relative h-44 bg-[#0b0906] overflow-hidden">
          <img
            src={sponsor.art}
            alt={sponsor.brand}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover opacity-55"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#120e09] via-[#0b0906]/55 to-transparent" />

          <div className="absolute bottom-3 left-4 right-4">
            <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest text-[#ffe885]">
              <Crown className="w-3.5 h-3.5" />
              <span>{sponsor.cta}</span>
            </div>
            <h3 className="font-royal text-lg font-bold text-[#f7f1e3] mt-0.5">
              {sponsor.brand}
            </h3>
            <p className="text-xs text-[#c8bca3]">{sponsor.headline}</p>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="h-1.5 w-full bg-[#0b0906]">
          <div
            className="h-full bg-gradient-to-r from-[#996515] via-[#d4af37] to-[#ffe885] transition-all duration-700 ease-linear"
            style={{ width: `${progress}%` }}
          />
        </div>

        {/* Reward Footer */}
        <div className="p-4 space-y-3">
          <div className="flex items-center justify-between rounded-2xl bg-[#1a140c] border border-[#d4af37]/25 px-3.5 py-2.5">
            <div className="flex items-center gap-2 text-xs text-[#c8bca3]">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Reward Upon Completion</span>
            </div>
            <div className="flex items-center gap-2.5 font-mono-num text-xs font-bold text-[#ffe885]">
              <span className="flex items-center gap-1">
                <Coins className="w-3.5 h-3.5 text-[#d4af37]" />
                +150
              </span>
              <span className="flex items-center gap-1 text-sky-300">
                <Gem className="w-3.5 h-3.5" />
                +2
              </span>
            </div>
          </div>

          <button
            type="button"
            disabled={!ready}
            onClick={() => {
              onClaimReward();
              onClose();
            }}
            className={`w-full py-3.5 rounded-2xl text-sm font-bold flex items-center justify-center gap-2 transition-all ${
              ready
                ? 'gold-gradient-btn shadow-[0_6px_20px_rgba(212,175,55,0.3)] active:scale-[0.98]'
                : 'bg-[#221b11] text-[#8d7f66] border border-[#d4af37]/20 cursor-not-allowed'
            }`}
          >
            <Play className="w-4 h-4 fill-current" />
            {ready ? 'Claim +150 Coins & +2 Gems' : `Watching Ad (${secondsLeft}s)...`}
          </button>
        </div>
      </div>
    </div>
  );
}
