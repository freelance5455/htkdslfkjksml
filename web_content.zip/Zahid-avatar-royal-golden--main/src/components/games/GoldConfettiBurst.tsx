import { useEffect, useRef } from 'react';

interface GoldConfettiBurstProps {
  triggerKey: number;
  intensity?: 'high' | 'jackpot';
  enabled: boolean;
}

interface ConfettiParticle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  aspect: number;
  rotation: number;
  vRot: number;
  tilt: number;
  vTilt: number;
  color: string;
  alpha: number;
  shape: 'foil' | 'diamond' | 'spark';
}

const GOLD_PALETTE = [
  '#ffe885',
  '#d4af37',
  '#fff5c0',
  '#b8861e',
  '#f3c95b',
  '#996515',
];

export function GoldConfettiBurst({
  triggerKey,
  intensity = 'high',
  enabled,
}: GoldConfettiBurstProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const rafRef = useRef<number | null>(null);

  useEffect(() => {
    if (!enabled || triggerKey === 0) return;

    const prefersReduced =
      typeof window !== 'undefined' &&
      window.matchMedia &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReduced) return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const width = Math.max(rect.width, 300);
    const height = Math.max(rect.height, 340);
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    const originX = width * 0.5;
    const originY = height * 0.4;
    const count = intensity === 'jackpot' ? 105 : 70;

    const particles: ConfettiParticle[] = Array.from({ length: count }).map((_, idx) => {
      const angle = -Math.PI / 2 + (Math.random() - 0.5) * Math.PI * 1.45;
      const speed = (intensity === 'jackpot' ? 5.2 : 4.2) + Math.random() * 5.8;
      const shapes: ConfettiParticle['shape'][] = ['foil', 'foil', 'diamond', 'spark'];
      return {
        x: originX + (Math.random() - 0.5) * 28,
        y: originY + (Math.random() - 0.5) * 24,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 1.5,
        size: 4.5 + Math.random() * 5.5,
        aspect: 0.45 + Math.random() * 0.4,
        rotation: Math.random() * Math.PI * 2,
        vRot: (Math.random() - 0.5) * 0.22,
        tilt: Math.random() * Math.PI * 2,
        vTilt: 0.1 + Math.random() * 0.16,
        color: GOLD_PALETTE[idx % GOLD_PALETTE.length],
        alpha: 1,
        shape: shapes[idx % shapes.length],
      };
    });

    const startTime = performance.now();
    const maxDuration = intensity === 'jackpot' ? 3200 : 2500;

    const renderFrame = (now: number) => {
      const elapsed = now - startTime;
      const progress = Math.min(1, elapsed / maxDuration);

      ctx.clearRect(0, 0, width, height);

      let aliveCount = 0;
      for (const p of particles) {
        p.vx *= 0.985;
        p.vy = p.vy * 0.985 + 0.16; // gentle gravity
        p.x += p.vx + Math.sin(p.tilt) * 0.45;
        p.y += p.vy;
        p.rotation += p.vRot;
        p.tilt += p.vTilt;

        if (progress > 0.62) {
          p.alpha = Math.max(0, 1 - (progress - 0.62) / 0.38);
        }

        if (p.alpha <= 0.01 || p.y > height + 24) continue;
        aliveCount++;

        const shimmerScale = Math.max(0.22, Math.abs(Math.cos(p.tilt)));

        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rotation);
        ctx.scale(1, shimmerScale);
        ctx.globalAlpha = p.alpha;
        ctx.fillStyle = p.color;

        if (p.shape === 'diamond') {
          ctx.beginPath();
          ctx.moveTo(0, -p.size * 0.7);
          ctx.lineTo(p.size * 0.55, 0);
          ctx.lineTo(0, p.size * 0.7);
          ctx.lineTo(-p.size * 0.55, 0);
          ctx.closePath();
          ctx.fill();
        } else if (p.shape === 'spark') {
          ctx.beginPath();
          ctx.arc(0, 0, p.size * 0.32, 0, Math.PI * 2);
          ctx.fill();
        } else {
          ctx.fillRect(-p.size * 0.5, -p.size * p.aspect * 0.5, p.size, p.size * p.aspect);
        }

        ctx.restore();
      }

      if (elapsed < maxDuration && aliveCount > 0) {
        rafRef.current = window.requestAnimationFrame(renderFrame);
      } else {
        ctx.clearRect(0, 0, width, height);
      }
    };

    rafRef.current = window.requestAnimationFrame(renderFrame);

    return () => {
      if (rafRef.current !== null) {
        window.cancelAnimationFrame(rafRef.current);
        rafRef.current = null;
      }
      ctx.clearRect(0, 0, width, height);
    };
  }, [triggerKey, intensity, enabled]);

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      className="pointer-events-none absolute inset-0 w-full h-full z-40"
    />
  );
}
