import { Clock, Coins, Gem, Sparkles } from 'lucide-react';
import { type CSSProperties, useEffect, useRef, useState } from 'react';
import { type SoundEffectType } from '../../utils/sound';
import { GoldConfettiBurst } from './GoldConfettiBurst';

export const WHEEL_OF_FORTUNE_COOLDOWN_MS = 4 * 60 * 60 * 1000; // 4 hours

interface WheelSlice {
  label: string;
  shortLabel: string;
  rewardType: 'coins' | 'gems';
  multiplier?: number;
  gems?: number;
  gradId: string;
  textColor: string;
}

const FORTUNE_SLICES: WheelSlice[] = [
  { label: '2x Coins', shortLabel: '2x', rewardType: 'coins', multiplier: 2, gradId: 'wofObsidianGold', textColor: '#ffe885' },
  { label: '+5 Gems', shortLabel: '+5G', rewardType: 'gems', gems: 5, gradId: 'wofDeepSapphire', textColor: '#bae6fd' },
  { label: '3x Coins', shortLabel: '3x', rewardType: 'coins', multiplier: 3, gradId: 'wofBronzeGold', textColor: '#ffe885' },
  { label: '+12 Gems', shortLabel: '+12G', rewardType: 'gems', gems: 12, gradId: 'wofRoyalSapphire', textColor: '#e0f2fe' },
  { label: '1.5x Coins', shortLabel: '1.5x', rewardType: 'coins', multiplier: 1.5, gradId: 'wofObsidianGold', textColor: '#f7f1e3' },
  { label: '5x Coins', shortLabel: '5x', rewardType: 'coins', multiplier: 5, gradId: 'wofRoyalGold', textColor: '#fff7cc' },
  { label: '+25 Gems', shortLabel: '+25G', rewardType: 'gems', gems: 25, gradId: 'wofDeepSapphire', textColor: '#bae6fd' },
  { label: '10x Coins', shortLabel: '10x', rewardType: 'coins', multiplier: 10, gradId: 'wofJackpotGold', textColor: '#0b0906' },
];

interface WheelOfFortuneGameProps {
  wager: number;
  lastSpinAt: number | null;
  animationsEnabled: boolean;
  onPlaySound: (effect: SoundEffectType) => void;
  onWheelOutcome: (params: {
    coinsAwarded: number;
    gemsAwarded: number;
    detail: string;
  }) => void;
}

function formatRemaining(ms: number): string {
  const totalSec = Math.max(0, Math.ceil(ms / 1000));
  const hrs = Math.floor(totalSec / 3600);
  const mins = Math.floor((totalSec % 3600) / 60);
  const secs = totalSec % 60;
  return `${String(hrs).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

export function WheelOfFortuneGame({
  wager,
  lastSpinAt,
  animationsEnabled,
  onPlaySound,
  onWheelOutcome,
}: WheelOfFortuneGameProps) {
  const [spinId, setSpinId] = useState(0);
  const [startDeg, setStartDeg] = useState(0);
  const [endDeg, setEndDeg] = useState(0);
  const [overshootDeg, setOvershootDeg] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [wonSlice, setWonSlice] = useState<WheelSlice | null>(null);
  const [confettiKey, setConfettiKey] = useState(0);
  const [confettiIntensity, setConfettiIntensity] = useState<'high' | 'jackpot'>('high');
  const [now, setNow] = useState(() => Date.now());
  const [lastResult, setLastResult] = useState<string>(
    'Free 4-hour royal spin for coin multipliers or extra Imperial Gems.'
  );

  const settleTimerRef = useRef<number | null>(null);
  const tickTimersRef = useRef<number[]>([]);

  const clearAllTimers = () => {
    if (settleTimerRef.current) {
      window.clearTimeout(settleTimerRef.current);
      settleTimerRef.current = null;
    }
    tickTimersRef.current.forEach((id) => window.clearTimeout(id));
    tickTimersRef.current = [];
  };

  useEffect(() => {
    return () => clearAllTimers();
  }, []);

  const remainingMs = lastSpinAt
    ? Math.max(0, lastSpinAt + WHEEL_OF_FORTUNE_COOLDOWN_MS - now)
    : 0;
  const isReady = remainingMs === 0;

  useEffect(() => {
    if (isReady) return;
    const interval = window.setInterval(() => {
      setNow(Date.now());
    }, 1000);
    return () => window.clearInterval(interval);
  }, [isReady]);

  const scheduleDecelTicks = (durationMs: number) => {
    // Schedule peg tick sounds that start rapid and smoothly decelerate over 3.6s
    const tickMoments = [
      90, 180, 280, 390, 510, 650, 810, 990, 1200, 1440, 1720, 2040, 2400, 2800, 3220,
    ];
    tickMoments.forEach((t) => {
      if (t < durationMs - 150) {
        const id = window.setTimeout(() => {
          onPlaySound('wheelTick');
        }, t);
        tickTimersRef.current.push(id);
      }
    });
  };

  const handleSpin = () => {
    if (spinning || !isReady) return;
    clearAllTimers();

    setSpinning(true);
    setWonSlice(null);
    setLastResult('Spinning the Golden Wheel of Fortune...');
    onPlaySound('wheelStart');

    const segCount = FORTUNE_SLICES.length;
    const segAngle = 360 / segCount;
    const winningIdx = Math.floor(Math.random() * segCount);

    // Center the chosen slice cleanly under the 12 o'clock pointer
    const targetMod = (360 - (winningIdx * segAngle + segAngle / 2)) % 360;
    const extraSpins = 360 * 6; // 6 full dramatic revolutions
    const currentMod = ((endDeg % 360) + 360) % 360;
    const delta = extraSpins + ((targetMod - currentMod + 360) % 360);
    const nextEnd = endDeg + delta;

    setStartDeg(endDeg);
    setOvershootDeg(nextEnd + 2.4);
    setEndDeg(nextEnd);
    setSpinId((prev) => prev + 1);

    const duration = animationsEnabled ? 3600 : 160;
    if (animationsEnabled) {
      scheduleDecelTicks(duration);
    }

    settleTimerRef.current = window.setTimeout(() => {
      const slice = FORTUNE_SLICES[winningIdx];
      const coinsAwarded =
        slice.rewardType === 'coins' && slice.multiplier
          ? Math.round(wager * slice.multiplier)
          : 0;
      const gemsAwarded =
        slice.rewardType === 'gems' && slice.gems ? slice.gems : 0;

      setSpinning(false);
      setWonSlice(slice);
      setNow(Date.now());

      const isJackpotTier =
        (slice.multiplier !== undefined && slice.multiplier >= 5) ||
        (slice.gems !== undefined && slice.gems >= 25);
      const isHighTier =
        isJackpotTier || (slice.multiplier !== undefined && slice.multiplier >= 3);

      if (isHighTier) {
        setConfettiIntensity(isJackpotTier ? 'jackpot' : 'high');
        setConfettiKey((prev) => prev + 1);
      }

      if (coinsAwarded > 0) {
        setLastResult(
          `Landed on ${slice.label}! Awarded +${coinsAwarded.toLocaleString()} Coins (${slice.multiplier}x of ${wager.toLocaleString()}).`
        );
      } else {
        setLastResult(`Landed on ${slice.label}! Awarded +${gemsAwarded} Imperial Gems.`);
      }

      onWheelOutcome({
        coinsAwarded,
        gemsAwarded,
        detail:
          coinsAwarded > 0
            ? `${slice.label} on ${wager.toLocaleString()} stake`
            : `${slice.label} bonus`,
      });
    }, duration);
  };

  const wheelVars = {
    '--wheel-start-deg': `${startDeg}deg`,
    '--wheel-overshoot-deg': `${overshootDeg}deg`,
    '--wheel-end-deg': `${endDeg}deg`,
  } as CSSProperties;

  return (
    <div className="relative space-y-4">
      <GoldConfettiBurst
        triggerKey={confettiKey}
        intensity={confettiIntensity}
        enabled={animationsEnabled}
      />

      {/* 4-Hour Cooldown & Stake Info Strip */}
      <div className="flex items-center justify-between gap-2 px-3 py-2 rounded-xl bg-[#0e0b07] border border-[#d4af37]/20 text-[11px]">
        <div className="flex items-center gap-1.5 text-[#c8bca3]">
          <Clock className="w-3.5 h-3.5 text-[#d4af37]" />
          <span>{isReady ? '4h Bonus Spin Ready' : `Next spin in ${formatRemaining(remainingMs)}`}</span>
        </div>
        <div className="flex items-center gap-2 font-mono-num text-[#ffe885]">
          <span className="flex items-center gap-1">
            <Coins className="w-3 h-3 text-[#d4af37]" />
            {wager.toLocaleString()} base
          </span>
          <span className="text-[#d4af37]/40">·</span>
          <span className="flex items-center gap-1 text-sky-300">
            <Gem className="w-3 h-3" />
            +25 Max
          </span>
        </div>
      </div>

      {/* Wheel Stage */}
      <div className="relative flex items-center justify-center py-3">
        {/* Ambient Radial Golden Glow */}
        <div
          aria-hidden="true"
          className={`absolute w-64 h-64 rounded-full bg-[radial-gradient(circle,_rgba(255,232,133,0.22)_0%,_rgba(212,175,55,0.08)_48%,_transparent_72%)] pointer-events-none transition-opacity duration-300 ${
            spinning && animationsEnabled ? 'animate-wheel-aura' : wonSlice ? 'opacity-90' : 'opacity-45'
          }`}
        />

        {/* Top Mechanical Pointer / Clapper */}
        <div
          aria-hidden="true"
          className={`absolute -top-0.5 z-30 flex flex-col items-center pointer-events-none ${
            spinning && animationsEnabled ? 'animate-wheel-clapper' : ''
          }`}
        >
          <div className="w-4 h-4 rounded-full bg-gradient-to-br from-[#ffe885] to-[#996515] border border-[#fff3b8] shadow-md" />
          <div className="-mt-1.5 w-0 h-0 border-l-[11px] border-r-[11px] border-t-[18px] border-l-transparent border-r-transparent border-t-[#ffe885] drop-shadow-[0_3px_6px_rgba(0,0,0,0.95)]" />
        </div>

        {/* Outer Gilded Bezel with 16 Perimeter Studs */}
        <div className="relative w-60 h-60 rounded-full p-2.5 bg-gradient-to-br from-[#ffe885] via-[#b8861e] to-[#5e3d0a] shadow-[0_0_38px_rgba(212,175,55,0.3),inset_0_2px_4px_rgba(255,255,255,0.45)]">
          {/* 16 Decorative Rim Lights */}
          {Array.from({ length: 16 }).map((_, idx) => {
            const deg = idx * 22.5;
            const isEven = idx % 2 === 0;
            return (
              <span
                key={idx}
                aria-hidden="true"
                className="absolute left-1/2 top-1/2 w-1.5 h-1.5 -ml-[3px] -mt-[3px] rounded-full pointer-events-none"
                style={{
                  transform: `rotate(${deg}deg) translateY(-115px)`,
                  backgroundColor: spinning
                    ? isEven
                      ? '#fff7cc'
                      : '#d4af37'
                    : wonSlice
                    ? '#ffe885'
                    : '#4a3310',
                  boxShadow:
                    spinning || wonSlice ? '0 0 8px rgba(255, 232, 133, 0.9)' : 'none',
                  transition: 'background-color 200ms ease, box-shadow 200ms ease',
                }}
              />
            );
          })}

          {/* Inner Rotating Wheel (Keyed per spin to trigger @keyframes cleanly) */}
          <div className="w-full h-full rounded-full bg-[#0b0906] p-0.5 shadow-inner overflow-hidden">
            <svg
              key={spinId}
              viewBox="0 0 200 200"
              className={`w-full h-full rounded-full ${
                spinId > 0 && animationsEnabled ? 'animate-golden-wheel' : ''
              }`}
              style={
                animationsEnabled
                  ? wheelVars
                  : { transform: `rotate(${endDeg}deg)` }
              }
            >
              <defs>
                <linearGradient id="wofObsidianGold" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#2a2013" />
                  <stop offset="100%" stopColor="#120d08" />
                </linearGradient>
                <linearGradient id="wofBronzeGold" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#593e15" />
                  <stop offset="100%" stopColor="#2c1e09" />
                </linearGradient>
                <linearGradient id="wofRoyalGold" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#996515" />
                  <stop offset="100%" stopColor="#5c3b0a" />
                </linearGradient>
                <linearGradient id="wofJackpotGold" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#ffe885" />
                  <stop offset="55%" stopColor="#d4af37" />
                  <stop offset="100%" stopColor="#996515" />
                </linearGradient>
                <linearGradient id="wofDeepSapphire" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#132c44" />
                  <stop offset="100%" stopColor="#091522" />
                </linearGradient>
                <linearGradient id="wofRoyalSapphire" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#1d4469" />
                  <stop offset="100%" stopColor="#0d2033" />
                </linearGradient>
              </defs>

              {FORTUNE_SLICES.map((slice, i) => {
                const startAngle = (i * 45 - 90) * (Math.PI / 180);
                const endAngle = ((i + 1) * 45 - 90) * (Math.PI / 180);
                const x1 = 100 + 100 * Math.cos(startAngle);
                const y1 = 100 + 100 * Math.sin(startAngle);
                const x2 = 100 + 100 * Math.cos(endAngle);
                const y2 = 100 + 100 * Math.sin(endAngle);
                const midDeg = i * 45 + 22.5;
                return (
                  <g key={i}>
                    <path
                      d={`M100,100 L${x1},${y1} A100,100 0 0,1 ${x2},${y2} Z`}
                      fill={`url(#${slice.gradId})`}
                      stroke="#d4af37"
                      strokeWidth="1.2"
                    />
                    <text
                      x="100"
                      y="33"
                      fill={slice.textColor}
                      fontSize="12.5"
                      fontWeight="700"
                      fontFamily="JetBrains Mono, monospace"
                      textAnchor="middle"
                      transform={`rotate(${midDeg} 100 100)`}
                    >
                      {slice.shortLabel}
                    </text>
                  </g>
                );
              })}

              {/* Center Royal Hub */}
              <circle cx="100" cy="100" r="24" fill="#0b0906" stroke="#ffe885" strokeWidth="3" />
              <circle cx="100" cy="100" r="19" fill="none" stroke="#d4af37" strokeWidth="0.75" strokeDasharray="2 2" />
              <text
                x="100"
                y="105"
                fill="#ffe885"
                fontSize="12"
                fontWeight="700"
                fontFamily="Cinzel, serif"
                textAnchor="middle"
              >
                Z
              </text>
            </svg>
          </div>
        </div>
      </div>

      {/* Outcome Banner or Reward Legend */}
      {wonSlice ? (
        <div className="animate-wheel-win rounded-xl bg-[#221a0d] border border-[#ffe885]/50 px-3.5 py-2.5 text-center shadow-[0_6px_20px_rgba(212,175,55,0.18)]">
          <p className="text-xs font-bold text-[#ffe885]">{wonSlice.label} Unlocked</p>
          <p className="text-[11px] text-[#f7f1e3] mt-0.5">{lastResult}</p>
        </div>
      ) : (
        <>
          <div className="flex items-center justify-center gap-4 text-[11px] text-[#a8997a]">
            <span className="flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-[#ffe885]" />
              Gold: 1.5x–10x Coins
            </span>
            <span className="flex items-center gap-1">
              <Gem className="w-3.5 h-3.5 text-sky-300" />
              Sapphire: +5 to +25 Gems
            </span>
          </div>
          <p className="text-xs text-center text-[#c8bca3] min-h-[18px]">{lastResult}</p>
        </>
      )}

      <button
        type="button"
        onClick={handleSpin}
        disabled={spinning || !isReady}
        className={`w-full py-3.5 rounded-2xl text-sm font-bold tracking-wide transition-transform active:scale-[0.98] flex items-center justify-center gap-2 ${
          isReady && !spinning
            ? 'gold-gradient-btn'
            : 'bg-[#221b11] text-[#8d7f66] border border-[#d4af37]/20 cursor-not-allowed'
        }`}
      >
        {spinning ? (
          'Spinning Fortune Wheel...'
        ) : isReady ? (
          'Spin Free 4-Hour Wheel'
        ) : (
          <>
            <Clock className="w-4 h-4" />
            Cooldown · {formatRemaining(remainingMs)}
          </>
        )}
      </button>
    </div>
  );
}
