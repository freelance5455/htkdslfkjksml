import { Crown, Flame, Gem, Pyramid, Skull, Sparkles } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { ROYAL_ASSETS } from '../../data/games';
import { MiniGameProps } from './ClassicGames';

const SLOT_SYMBOLS = [
  { id: 'crown', label: 'Crown', mult3: 12, icon: Crown, color: 'text-[#ffe885]' },
  { id: 'gem', label: 'Gem', mult3: 8, icon: Gem, color: 'text-amber-300' },
  { id: 'dragon', label: 'Dragon', mult3: 6, icon: Flame, color: 'text-orange-400' },
  { id: 'spark', label: 'Sceptre', mult3: 4, icon: Sparkles, color: 'text-[#d4af37]' },
];

export function RoyalSlotsGame({
  wager,
  coins,
  animationsEnabled,
  onPlaySound,
  onOutcome,
}: MiniGameProps) {
  const [reels, setReels] = useState<[number, number, number]>([0, 1, 0]);
  const [spinning, setSpinning] = useState(false);
  const [status, setStatus] = useState('Match 2 symbols (1.6x) or 3 symbols (up to 12x).');
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      if (timerRef.current) window.clearTimeout(timerRef.current);
    };
  }, []);

  const handleSpin = () => {
    if (spinning || coins < wager) return;
    setSpinning(true);
    setStatus('Reels spinning...');
    onPlaySound('spinTick');

    const delay = animationsEnabled ? 780 : 120;
    timerRef.current = window.setTimeout(() => {
      const r1 = Math.floor(Math.random() * SLOT_SYMBOLS.length);
      const r2 = Math.floor(Math.random() * SLOT_SYMBOLS.length);
      const r3 = Math.floor(Math.random() * SLOT_SYMBOLS.length);
      setReels([r1, r2, r3]);
      setSpinning(false);

      let mult = 0;
      let label = 'No match';
      if (r1 === r2 && r2 === r3) {
        mult = SLOT_SYMBOLS[r1].mult3;
        label = `Triple ${SLOT_SYMBOLS[r1].label}`;
      } else if (r1 === r2 || r2 === r3 || r1 === r3) {
        mult = 1.6;
        label = 'Double Match';
      }

      const payout = Math.round(wager * mult);
      setStatus(
        mult > 0
          ? `${label}! Won ${payout.toLocaleString()} Coins (${mult}x).`
          : 'No line match · Try another spin.'
      );

      onOutcome({
        gameId: 'royal-slots',
        gameName: 'Royal Slots',
        wagerAmount: wager,
        payoutAmount: payout,
        detail: `${SLOT_SYMBOLS[r1].label} · ${SLOT_SYMBOLS[r2].label} · ${SLOT_SYMBOLS[r3].label}`,
      });
    }, delay);
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-3 gap-2.5 p-3.5 rounded-2xl bg-[#0e0b07] border border-[#d4af37]/30 shadow-inner">
        {reels.map((symIdx, idx) => {
          const sym = SLOT_SYMBOLS[symIdx];
          const Icon = sym.icon;
          return (
            <div
              key={idx}
              className={`h-24 rounded-xl bg-gradient-to-b from-[#231b10] to-[#120e09] border border-[#d4af37]/35 flex flex-col items-center justify-center gap-1.5 ${
                spinning && animationsEnabled ? 'animate-slot-pulse' : ''
              }`}
            >
              <Icon className={`w-8 h-8 ${sym.color}`} />
              <span className="text-[10px] font-semibold text-[#c8bca3]">{sym.label}</span>
            </div>
          );
        })}
      </div>

      <div className="flex items-center justify-between text-[11px] font-mono-num text-[#a8997a] px-1">
        <span>3x Crown: 12x</span>
        <span>3x Gem: 8x</span>
        <span>Any Pair: 1.6x</span>
      </div>

      <p className="text-xs text-center text-[#c8bca3] min-h-[18px]">{status}</p>

      <button
        type="button"
        onClick={handleSpin}
        disabled={spinning || coins < wager}
        className="w-full py-3.5 rounded-2xl gold-gradient-btn text-sm font-bold tracking-wide transition-transform active:scale-[0.98] disabled:opacity-45 disabled:cursor-not-allowed"
      >
        {spinning ? 'Spinning Reels...' : `Play Now · ${wager.toLocaleString()} Coins`}
      </button>
    </div>
  );
}

const ROULETTE_POCKETS = [
  { num: 0, color: 'gold' as const },
  { num: 1, color: 'crimson' as const },
  { num: 2, color: 'obsidian' as const },
  { num: 3, color: 'crimson' as const },
  { num: 4, color: 'obsidian' as const },
  { num: 5, color: 'crimson' as const },
  { num: 6, color: 'obsidian' as const },
  { num: 7, color: 'crimson' as const },
  { num: 8, color: 'obsidian' as const },
  { num: 9, color: 'crimson' as const },
  { num: 10, color: 'obsidian' as const },
  { num: 11, color: 'crimson' as const },
  { num: 12, color: 'obsidian' as const },
];

export function GoldenRouletteGame({
  wager,
  coins,
  animationsEnabled,
  onPlaySound,
  onOutcome,
}: MiniGameProps) {
  const [betColor, setBetColor] = useState<'crimson' | 'obsidian' | 'gold'>('crimson');
  const [spinning, setSpinning] = useState(false);
  const [lastPocket, setLastPocket] = useState(ROULETTE_POCKETS[7]);
  const [angle, setAngle] = useState(0);
  const [status, setStatus] = useState('Bet Crimson (2x), Obsidian (2x), or Royal Gold 0 (12x).');
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      if (timerRef.current) window.clearTimeout(timerRef.current);
    };
  }, []);

  const handleSpin = () => {
    if (spinning || coins < wager) return;
    setSpinning(true);
    setStatus('Roulette ball in motion...');
    onPlaySound('spinTick');

    setAngle((prev) => prev + 720 + Math.floor(Math.random() * 360));
    const delay = animationsEnabled ? 1100 : 140;

    timerRef.current = window.setTimeout(() => {
      const pocket = ROULETTE_POCKETS[Math.floor(Math.random() * ROULETTE_POCKETS.length)];
      setLastPocket(pocket);
      setSpinning(false);

      let mult = 0;
      if (pocket.color === betColor) {
        mult = betColor === 'gold' ? 12 : 2;
      }

      const payout = Math.round(wager * mult);
      setStatus(
        mult > 0
          ? `Ball landed on ${pocket.num} (${pocket.color})! Won ${payout.toLocaleString()} Coins.`
          : `Ball landed on ${pocket.num} (${pocket.color}) · House took round.`
      );

      onOutcome({
        gameId: 'golden-roulette',
        gameName: 'Golden Roulette',
        wagerAmount: wager,
        payoutAmount: payout,
        detail: `Pocket ${pocket.num} (${pocket.color})`,
      });
    }, delay);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-center py-3 rounded-2xl bg-[#0e0b07] border border-[#d4af37]/20">
        <div className="relative w-36 h-36 rounded-full border-4 border-[#d4af37]/60 flex items-center justify-center bg-[#15100a] shadow-[0_0_24px_rgba(212,175,55,0.2)]">
          <div
            className="absolute inset-2 rounded-full border-2 border-dashed border-[#ffe885]/45"
            style={{
              transform: `rotate(${angle}deg)`,
              transition: animationsEnabled ? 'transform 1.1s cubic-bezier(0.16, 1, 0.3, 1)' : 'none',
            }}
          />
          <div
            className={`w-16 h-16 rounded-full flex flex-col items-center justify-center border-2 ${
              lastPocket.color === 'gold'
                ? 'bg-[#8f6218] border-[#ffe885] text-[#fff7cc]'
                : lastPocket.color === 'crimson'
                ? 'bg-rose-900 border-rose-400 text-rose-50'
                : 'bg-[#1b1610] border-[#d4af37]/50 text-[#f7f1e3]'
            }`}
          >
            <span className="font-mono-num text-xl font-bold leading-none">
              {spinning ? '?' : lastPocket.num}
            </span>
            <span className="text-[9px] uppercase tracking-wider mt-0.5">{lastPocket.color}</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-2">
        <button
          type="button"
          disabled={spinning}
          onClick={() => {
            onPlaySound('click');
            setBetColor('crimson');
          }}
          className={`py-2.5 rounded-xl border text-xs font-bold transition-all ${
            betColor === 'crimson'
              ? 'bg-rose-950 border-rose-400 text-rose-100'
              : 'bg-[#15100a] border-[#d4af37]/20 text-[#c8bca3]'
          }`}
        >
          Crimson 2x
        </button>

        <button
          type="button"
          disabled={spinning}
          onClick={() => {
            onPlaySound('click');
            setBetColor('gold');
          }}
          className={`py-2.5 rounded-xl border text-xs font-bold transition-all ${
            betColor === 'gold'
              ? 'bg-[#d4af37]/25 border-[#ffe885] text-[#ffe885]'
              : 'bg-[#15100a] border-[#d4af37]/20 text-[#c8bca3]'
          }`}
        >
          Gold 0 · 12x
        </button>

        <button
          type="button"
          disabled={spinning}
          onClick={() => {
            onPlaySound('click');
            setBetColor('obsidian');
          }}
          className={`py-2.5 rounded-xl border text-xs font-bold transition-all ${
            betColor === 'obsidian'
              ? 'bg-[#2a2216] border-[#ffe885] text-[#f7f1e3]'
              : 'bg-[#15100a] border-[#d4af37]/20 text-[#c8bca3]'
          }`}
        >
          Obsidian 2x
        </button>
      </div>

      <p className="text-xs text-center text-[#c8bca3] min-h-[18px]">{status}</p>

      <button
        type="button"
        onClick={handleSpin}
        disabled={spinning || coins < wager}
        className="w-full py-3.5 rounded-2xl gold-gradient-btn text-sm font-bold tracking-wide transition-transform active:scale-[0.98] disabled:opacity-45 disabled:cursor-not-allowed"
      >
        {spinning ? 'Spinning Roulette...' : `Play Now · ${wager.toLocaleString()} Coins`}
      </button>
    </div>
  );
}

const RANKS = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];
const SUITS = ['♠', '♥', '♦', '♣'] as const;

interface DrawnCard {
  rankIdx: number;
  suit: (typeof SUITS)[number];
}

function PlayingCardView({ label, card }: { label: string; card: DrawnCard }) {
  const isRed = card.suit === '♥' || card.suit === '♦';
  return (
    <div className="flex flex-col items-center gap-1.5">
      <span className="text-[10px] font-semibold uppercase tracking-wider text-[#a8997a]">
        {label}
      </span>
      <div className="w-20 h-28 rounded-xl bg-gradient-to-b from-[#fbf7ee] to-[#ece2cc] border-2 border-[#d4af37] p-2 flex flex-col justify-between shadow-[0_8px_20px_rgba(0,0,0,0.6)]">
        <div className={`text-xs font-mono-num font-bold leading-none ${isRed ? 'text-rose-600' : 'text-neutral-900'}`}>
          {RANKS[card.rankIdx]}
        </div>
        <div className={`text-2xl text-center leading-none ${isRed ? 'text-rose-600' : 'text-neutral-900'}`}>
          {card.suit}
        </div>
        <div className={`text-xs font-mono-num font-bold leading-none self-end rotate-180 ${isRed ? 'text-rose-600' : 'text-neutral-900'}`}>
          {RANKS[card.rankIdx]}
        </div>
      </div>
    </div>
  );
}

export function DragonCardsGame({
  wager,
  coins,
  animationsEnabled,
  onPlaySound,
  onOutcome,
}: MiniGameProps) {
  const [betSide, setBetSide] = useState<'player' | 'dragon' | 'tie'>('player');
  const [dealing, setDealing] = useState(false);
  const [playerCard, setPlayerCard] = useState<DrawnCard>({ rankIdx: 11, suit: '♠' });
  const [dragonCard, setDragonCard] = useState<DrawnCard>({ rankIdx: 8, suit: '♦' });
  const [status, setStatus] = useState('Back Player (1.95x), Dragon (1.95x), or Tie (8x).');
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      if (timerRef.current) window.clearTimeout(timerRef.current);
    };
  }, []);

  const handleDeal = () => {
    if (dealing || coins < wager) return;
    setDealing(true);
    setStatus('Drawing Imperial Dragon cards...');
    onPlaySound('spinTick');

    const delay = animationsEnabled ? 520 : 100;
    timerRef.current = window.setTimeout(() => {
      const p: DrawnCard = {
        rankIdx: Math.floor(Math.random() * RANKS.length),
        suit: SUITS[Math.floor(Math.random() * SUITS.length)],
      };
      const d: DrawnCard = {
        rankIdx: Math.floor(Math.random() * RANKS.length),
        suit: SUITS[Math.floor(Math.random() * SUITS.length)],
      };
      setPlayerCard(p);
      setDragonCard(d);
      setDealing(false);

      const winner = p.rankIdx > d.rankIdx ? 'player' : d.rankIdx > p.rankIdx ? 'dragon' : 'tie';
      let mult = 0;
      if (winner === betSide) {
        mult = betSide === 'tie' ? 8 : 1.95;
      }

      const payout = Math.round(wager * mult);
      setStatus(
        mult > 0
          ? `${RANKS[p.rankIdx]}${p.suit} vs ${RANKS[d.rankIdx]}${d.suit} · Won ${payout.toLocaleString()} Coins!`
          : `${RANKS[p.rankIdx]}${p.suit} vs ${RANKS[d.rankIdx]}${d.suit} · ${winner.toUpperCase()} won.`
      );

      onOutcome({
        gameId: 'dragon-cards',
        gameName: 'Dragon Cards',
        wagerAmount: wager,
        payoutAmount: payout,
        detail: `${RANKS[p.rankIdx]}${p.suit} vs ${RANKS[d.rankIdx]}${d.suit}`,
      });
    }, delay);
  };

  return (
    <div className="space-y-4">
      <div className="relative flex items-center justify-around py-4 rounded-2xl bg-[#0e0b07] border border-[#d4af37]/25 overflow-hidden">
        <img
          src={ROYAL_ASSETS.dragonEmblem}
          alt="Imperial Dragon Seal"
          referrerPolicy="no-referrer"
          className="w-24 h-24 rounded-full object-cover opacity-15 absolute pointer-events-none"
        />
        <PlayingCardView label="Zahid Hand" card={playerCard} />
        <span className="font-royal text-sm font-bold text-[#d4af37]">VS</span>
        <PlayingCardView label="Dragon" card={dragonCard} />
      </div>

      <div className="grid grid-cols-3 gap-2">
        {[
          { id: 'player' as const, label: 'Player 1.95x' },
          { id: 'tie' as const, label: 'Tie 8.0x' },
          { id: 'dragon' as const, label: 'Dragon 1.95x' },
        ].map((opt) => (
          <button
            key={opt.id}
            type="button"
            disabled={dealing}
            onClick={() => {
              onPlaySound('click');
              setBetSide(opt.id);
            }}
            className={`py-2.5 px-2 rounded-xl border text-xs font-bold transition-all ${
              betSide === opt.id
                ? 'bg-[#d4af37]/20 border-[#ffe885] text-[#ffe885]'
                : 'bg-[#15100a] border-[#d4af37]/20 text-[#c8bca3]'
            }`}
          >
            {opt.label}
          </button>
        ))}
      </div>

      <p className="text-xs text-center text-[#c8bca3] min-h-[18px]">{status}</p>

      <button
        type="button"
        onClick={handleDeal}
        disabled={dealing || coins < wager}
        className="w-full py-3.5 rounded-2xl gold-gradient-btn text-sm font-bold tracking-wide transition-transform active:scale-[0.98] disabled:opacity-45 disabled:cursor-not-allowed"
      >
        {dealing ? 'Dealing Cards...' : `Play Now · ${wager.toLocaleString()} Coins`}
      </button>
    </div>
  );
}

const PHARAOH_MULTIPLIERS = [1, 1.28, 1.65, 2.15, 2.8, 3.7, 5.0, 7.0, 10.0, 15.0];

export function PharaohQuestGame({
  wager,
  coins,
  onPlaySound,
  onOutcome,
}: MiniGameProps) {
  const [activeWager, setActiveWager] = useState<number | null>(null);
  const [traps, setTraps] = useState<number[]>([]);
  const [revealed, setRevealed] = useState<number[]>([]);
  const [gameOver, setGameOver] = useState(false);
  const [status, setStatus] = useState('Start Quest, tap golden tiles for Scarabs, Cash Out anytime!');

  const currentMult = PHARAOH_MULTIPLIERS[Math.min(revealed.length, PHARAOH_MULTIPLIERS.length - 1)];

  const startQuest = () => {
    if (coins < wager) return;
    onPlaySound('click');

    const trapIndices: number[] = [];
    while (trapIndices.length < 4) {
      const idx = Math.floor(Math.random() * 16);
      if (!trapIndices.includes(idx)) trapIndices.push(idx);
    }

    setTraps(trapIndices);
    setRevealed([]);
    setGameOver(false);
    setActiveWager(wager);
    setStatus('Tomb open! Tap tiles to uncover Scarabs. Avoid 4 cursed traps.');
  };

  const handleTileTap = (idx: number) => {
    if (activeWager === null || gameOver || revealed.includes(idx)) return;

    if (traps.includes(idx)) {
      // Hit trap
      setRevealed((prev) => [...prev, idx]);
      setGameOver(true);
      const lostWager = activeWager;
      setActiveWager(null);
      setStatus(`Triggered a Pharaoh Trap! Lost ${lostWager.toLocaleString()} Coins.`);
      onOutcome({
        gameId: 'pharaoh-quest',
        gameName: 'Pharaoh Quest',
        wagerAmount: lostWager,
        payoutAmount: 0,
        detail: `Cursed trap after ${revealed.length} scarabs`,
      });
    } else {
      onPlaySound('coin');
      const nextRevealed = [...revealed, idx];
      setRevealed(nextRevealed);
      const nextMult = PHARAOH_MULTIPLIERS[Math.min(nextRevealed.length, PHARAOH_MULTIPLIERS.length - 1)];
      setStatus(`Scarab found! Current multiplier: ${nextMult}x (${Math.round(activeWager * nextMult).toLocaleString()} Coins)`);
    }
  };

  const handleCashOut = () => {
    if (activeWager === null || revealed.length === 0) return;
    const payout = Math.round(activeWager * currentMult);
    const bet = activeWager;
    setActiveWager(null);
    setGameOver(true);
    setStatus(`Cashed out ${payout.toLocaleString()} Coins (${currentMult}x)!`);

    onOutcome({
      gameId: 'pharaoh-quest',
      gameName: 'Pharaoh Quest',
      wagerAmount: bet,
      payoutAmount: payout,
      detail: `Cashed out ${revealed.length} scarabs at ${currentMult}x`,
    });
  };

  return (
    <div className="space-y-3.5">
      <div className="grid grid-cols-4 gap-2 p-3 rounded-2xl bg-[#0e0b07] border border-[#d4af37]/25">
        {Array.from({ length: 16 }).map((_, idx) => {
          const isRev = revealed.includes(idx);
          const isTrap = traps.includes(idx);
          const showAllTraps = gameOver && isTrap;

          return (
            <button
              key={idx}
              type="button"
              disabled={activeWager === null || isRev || gameOver}
              onClick={() => handleTileTap(idx)}
              className={`h-12 rounded-xl border flex items-center justify-center transition-all ${
                isRev && isTrap
                  ? 'bg-rose-950 border-rose-500 text-rose-300'
                  : isRev
                  ? 'bg-[#2a2011] border-[#ffe885] text-[#ffe885]'
                  : showAllTraps
                  ? 'bg-rose-950/40 border-rose-500/40 text-rose-400/70'
                  : activeWager !== null && !gameOver
                  ? 'bg-[#1a140c] border-[#d4af37]/30 hover:border-[#ffe885] active:scale-95 text-[#d4af37]/60'
                  : 'bg-[#130f0a] border-[#d4af37]/15 text-[#5c513e]'
              }`}
            >
              {isRev && isTrap ? (
                <Skull className="w-5 h-5" />
              ) : isRev ? (
                <Sparkles className="w-5 h-5" />
              ) : showAllTraps ? (
                <Skull className="w-4 h-4" />
              ) : (
                <Pyramid className="w-4 h-4" />
              )}
            </button>
          );
        })}
      </div>

      <p className="text-xs text-center text-[#c8bca3] min-h-[18px]">{status}</p>

      {activeWager !== null && !gameOver ? (
        <button
          type="button"
          onClick={handleCashOut}
          disabled={revealed.length === 0}
          className="w-full py-3.5 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-[#07140b] text-sm font-bold tracking-wide transition-transform active:scale-[0.98] disabled:opacity-45 disabled:cursor-not-allowed"
        >
          {revealed.length === 0
            ? 'Tap a Tomb Tile First'
            : `Cash Out ${Math.round(activeWager * currentMult).toLocaleString()} Coins (${currentMult}x)`}
        </button>
      ) : (
        <button
          type="button"
          onClick={startQuest}
          disabled={coins < wager}
          className="w-full py-3.5 rounded-2xl gold-gradient-btn text-sm font-bold tracking-wide transition-transform active:scale-[0.98] disabled:opacity-45 disabled:cursor-not-allowed"
        >
          {`Play Now · ${wager.toLocaleString()} Coins`}
        </button>
      )}
    </div>
  );
}
