import { Crown, Lock, Shield, Sparkles, Unlock } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { ROYAL_ASSETS } from '../../data/games';
import { GameId } from '../../types';
import { type SoundEffectType } from '../../utils/sound';

export interface MiniGameProps {
  wager: number;
  coins: number;
  animationsEnabled: boolean;
  onPlaySound: (effect: SoundEffectType) => void;
  onOutcome: (params: {
    gameId: GameId;
    gameName: string;
    wagerAmount: number;
    payoutAmount: number;
    detail: string;
  }) => void;
}

function DiceFace({ value, rolling }: { value: number; rolling: boolean }) {
  const pips: Record<number, number[]> = {
    1: [4],
    2: [0, 8],
    3: [0, 4, 8],
    4: [0, 2, 6, 8],
    5: [0, 2, 4, 6, 8],
    6: [0, 2, 3, 5, 6, 8],
  };
  const active = pips[value] || [4];

  return (
    <div
      className={`w-16 h-16 rounded-2xl bg-gradient-to-br from-[#2a2114] to-[#100c07] border-2 border-[#d4af37]/60 p-2.5 grid grid-cols-3 grid-rows-3 gap-1 shadow-[0_10px_24px_rgba(0,0,0,0.65)] ${
        rolling ? 'animate-dice-shake' : ''
      }`}
    >
      {Array.from({ length: 9 }).map((_, idx) => (
        <div key={idx} className="flex items-center justify-center">
          {active.includes(idx) && (
            <span className="w-2.5 h-2.5 rounded-full bg-gradient-to-br from-[#ffe885] to-[#b57e1f] shadow-[0_0_6px_rgba(255,232,133,0.65)]" />
          )}
        </div>
      ))}
    </div>
  );
}

export function RoyalDiceGame({
  wager,
  coins,
  animationsEnabled,
  onPlaySound,
  onOutcome,
}: MiniGameProps) {
  const [pick, setPick] = useState<'under' | 'seven' | 'over'>('over');
  const [dice, setDice] = useState<[number, number]>([5, 4]);
  const [rolling, setRolling] = useState(false);
  const [status, setStatus] = useState<string>('Choose Under 7, Lucky 7, or Over 7 and roll.');
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      if (timerRef.current) window.clearTimeout(timerRef.current);
    };
  }, []);

  const handlePlay = () => {
    if (rolling || coins < wager) return;
    setRolling(true);
    setStatus('Rolling obsidian dice...');
    onPlaySound('spinTick');

    const delay = animationsEnabled ? 650 : 120;
    timerRef.current = window.setTimeout(() => {
      const d1 = Math.floor(Math.random() * 6) + 1;
      const d2 = Math.floor(Math.random() * 6) + 1;
      const sum = d1 + d2;
      setDice([d1, d2]);
      setRolling(false);

      let mult = 0;
      if (pick === 'under' && sum < 7) mult = 1.9;
      if (pick === 'over' && sum > 7) mult = 1.9;
      if (pick === 'seven' && sum === 7) mult = 4.5;

      const payout = Math.round(wager * mult);
      setStatus(
        mult > 0
          ? `Rolled ${sum} (${d1}+${d2}) · Won ${payout.toLocaleString()} Coins (${mult}x)!`
          : `Rolled ${sum} (${d1}+${d2}) · House took this round.`
      );

      onOutcome({
        gameId: 'royal-dice',
        gameName: 'Royal Dice',
        wagerAmount: wager,
        payoutAmount: payout,
        detail: `Rolled ${sum} (${d1}+${d2})`,
      });
    }, delay);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-center gap-5 py-4 rounded-2xl bg-[#0e0b07] border border-[#d4af37]/20">
        <DiceFace value={dice[0]} rolling={rolling && animationsEnabled} />
        <div className="text-center">
          <p className="text-[10px] text-[#a8997a] uppercase tracking-widest">Total</p>
          <p className="font-mono-num text-2xl font-bold text-[#ffe885] mt-0.5">
            {rolling ? '?' : dice[0] + dice[1]}
          </p>
        </div>
        <DiceFace value={dice[1]} rolling={rolling && animationsEnabled} />
      </div>

      <div className="grid grid-cols-3 gap-2">
        {[
          { id: 'under' as const, label: 'Under 7', mult: '1.9x' },
          { id: 'seven' as const, label: 'Lucky 7', mult: '4.5x' },
          { id: 'over' as const, label: 'Over 7', mult: '1.9x' },
        ].map((opt) => (
          <button
            key={opt.id}
            type="button"
            disabled={rolling}
            onClick={() => {
              onPlaySound('click');
              setPick(opt.id);
            }}
            className={`py-2.5 px-2 rounded-xl border text-center transition-all ${
              pick === opt.id
                ? 'bg-[#d4af37]/20 border-[#ffe885] text-[#ffe885]'
                : 'bg-[#15100a] border-[#d4af37]/20 text-[#c8bca3] hover:border-[#d4af37]/45'
            }`}
          >
            <div className="text-xs font-bold">{opt.label}</div>
            <div className="font-mono-num text-[10px] text-[#d4af37] mt-0.5">{opt.mult}</div>
          </button>
        ))}
      </div>

      <p className="text-xs text-center text-[#c8bca3] min-h-[18px]">{status}</p>

      <button
        type="button"
        onClick={handlePlay}
        disabled={rolling || coins < wager}
        className="w-full py-3.5 rounded-2xl gold-gradient-btn text-sm font-bold tracking-wide transition-transform active:scale-[0.98] disabled:opacity-45 disabled:cursor-not-allowed"
      >
        {rolling ? 'Rolling Dice...' : `Play Now · ${wager.toLocaleString()} Coins`}
      </button>
    </div>
  );
}

const WHEEL_SEGMENTS = [
  { label: '0x', mult: 0, color: '#1b140d', text: '#a8997a' },
  { label: '1.5x', mult: 1.5, color: '#2b2113', text: '#ffe885' },
  { label: '0.5x', mult: 0.5, color: '#140f0a', text: '#d4af37' },
  { label: '3.0x', mult: 3, color: '#453112', text: '#ffe885' },
  { label: '1.2x', mult: 1.2, color: '#1b140d', text: '#f7f1e3' },
  { label: '5.0x', mult: 5, color: '#5c3f14', text: '#ffe885' },
  { label: '0x', mult: 0, color: '#140f0a', text: '#a8997a' },
  { label: '10x', mult: 10, color: '#8f6218', text: '#fff7cc' },
];

export function GoldenSpinGame({
  wager,
  coins,
  animationsEnabled,
  onPlaySound,
  onOutcome,
}: MiniGameProps) {
  const [rotation, setRotation] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [status, setStatus] = useState('Spin the Royal Wheel for up to 10x!');
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      if (timerRef.current) window.clearTimeout(timerRef.current);
    };
  }, []);

  const handleSpin = () => {
    if (spinning || coins < wager) return;
    setSpinning(true);
    setStatus('Wheel of Sovereigns spinning...');
    onPlaySound('wheelStart');

    const segCount = WHEEL_SEGMENTS.length;
    const segAngle = 360 / segCount;
    const winningIdx = Math.floor(Math.random() * segCount);
    // Align chosen wedge center under top pointer (0 deg)
    const targetMod = (360 - (winningIdx * segAngle + segAngle / 2)) % 360;
    const extraSpins = 360 * 4;
    const currentMod = rotation % 360;
    const delta = extraSpins + ((targetMod - currentMod + 360) % 360);
    const nextRotation = rotation + delta;

    setRotation(nextRotation);

    const duration = animationsEnabled ? 1800 : 180;
    timerRef.current = window.setTimeout(() => {
      const seg = WHEEL_SEGMENTS[winningIdx];
      const payout = Math.round(wager * seg.mult);
      setSpinning(false);
      setStatus(
        seg.mult >= 1
          ? `Landed on ${seg.label}! Won ${payout.toLocaleString()} Coins.`
          : seg.mult > 0
          ? `Landed on ${seg.label} · Returned ${payout.toLocaleString()} Coins.`
          : `Landed on 0x · Better fortune next spin.`
      );

      onOutcome({
        gameId: 'golden-spin',
        gameName: 'Golden Spin',
        wagerAmount: wager,
        payoutAmount: payout,
        detail: `Wheel landed on ${seg.label}`,
      });
    }, duration);
  };

  return (
    <div className="space-y-4">
      <div className="relative flex items-center justify-center py-3">
        {/* Top Pointer */}
        <div
          aria-hidden="true"
          className="absolute top-1 z-20 w-0 h-0 border-l-[10px] border-r-[10px] border-t-[16px] border-l-transparent border-r-transparent border-t-[#ffe885] drop-shadow-[0_2px_6px_rgba(0,0,0,0.9)]"
        />

        <div className="w-52 h-52 rounded-full p-1.5 bg-gradient-to-br from-[#ffe885] via-[#d4af37] to-[#7a4f0f] shadow-[0_0_30px_rgba(212,175,55,0.22)]">
          <svg
            viewBox="0 0 200 200"
            className="w-full h-full rounded-full"
            style={{
              transform: `rotate(${rotation}deg)`,
              transition: animationsEnabled
                ? 'transform 1.8s cubic-bezier(0.16, 1, 0.3, 1)'
                : 'none',
            }}
          >
            {WHEEL_SEGMENTS.map((seg, i) => {
              const startAngle = (i * 45 - 90) * (Math.PI / 180);
              const endAngle = ((i + 1) * 45 - 90) * (Math.PI / 180);
              const x1 = 100 + 100 * Math.cos(startAngle);
              const y1 = 100 + 100 * Math.sin(startAngle);
              const x2 = 100 + 100 * Math.cos(endAngle);
              const y2 = 100 + 100 * Math.sin(endAngle);
              const midDeg = i * 45 + 22.5;
              return (
                <g key={i}>
                  <path
                    d={`M100,100 L${x1},${y1} A100,100 0 0,1 ${x2},${y2} Z`}
                    fill={seg.color}
                    stroke="#d4af37"
                    strokeWidth="0.9"
                  />
                  <text
                    x="100"
                    y="32"
                    fill={seg.text}
                    fontSize="12"
                    fontWeight="700"
                    fontFamily="JetBrains Mono, monospace"
                    textAnchor="middle"
                    transform={`rotate(${midDeg} 100 100)`}
                  >
                    {seg.label}
                  </text>
                </g>
              );
            })}
            <circle cx="100" cy="100" r="22" fill="#0b0906" stroke="#ffe885" strokeWidth="3" />
            <text
              x="100"
              y="105"
              fill="#ffe885"
              fontSize="13"
              fontWeight="700"
              fontFamily="Cinzel, serif"
              textAnchor="middle"
            >
              Z
            </text>
          </svg>
        </div>
      </div>

      <p className="text-xs text-center text-[#c8bca3] min-h-[18px]">{status}</p>

      <button
        type="button"
        onClick={handleSpin}
        disabled={spinning || coins < wager}
        className="w-full py-3.5 rounded-2xl gold-gradient-btn text-sm font-bold tracking-wide transition-transform active:scale-[0.98] disabled:opacity-45 disabled:cursor-not-allowed"
      >
        {spinning ? 'Spinning Wheel...' : `Play Now · ${wager.toLocaleString()} Coins`}
      </button>
    </div>
  );
}

export function CrownFlipGame({
  wager,
  coins,
  animationsEnabled,
  onPlaySound,
  onOutcome,
}: MiniGameProps) {
  const [side, setSide] = useState<'crown' | 'shield'>('crown');
  const [resultSide, setResultSide] = useState<'crown' | 'shield'>('crown');
  const [flipping, setFlipping] = useState(false);
  const [status, setStatus] = useState('Call Royal Crown or Obsidian Shield (1.95x).');
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      if (timerRef.current) window.clearTimeout(timerRef.current);
    };
  }, []);

  const handleFlip = () => {
    if (flipping || coins < wager) return;
    setFlipping(true);
    setStatus('Tossing sovereign coin...');
    onPlaySound('spinTick');

    const delay = animationsEnabled ? 820 : 120;
    timerRef.current = window.setTimeout(() => {
      const outcome: 'crown' | 'shield' = Math.random() < 0.5 ? 'crown' : 'shield';
      setResultSide(outcome);
      setFlipping(false);

      const won = outcome === side;
      const payout = won ? Math.round(wager * 1.95) : 0;
      setStatus(
        won
          ? `Landed on ${outcome === 'crown' ? 'Royal Crown' : 'Obsidian Shield'}! Won ${payout.toLocaleString()} Coins.`
          : `Landed on ${outcome === 'crown' ? 'Royal Crown' : 'Obsidian Shield'} · House won.`
      );

      onOutcome({
        gameId: 'crown-flip',
        gameName: 'Crown Flip',
        wagerAmount: wager,
        payoutAmount: payout,
        detail: `Called ${side}, landed ${outcome}`,
      });
    }, delay);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-center py-5 rounded-2xl bg-[#0e0b07] border border-[#d4af37]/20">
        <div
          className={`w-28 h-28 rounded-full p-1 bg-gradient-to-br from-[#ffe885] via-[#d4af37] to-[#8a5b11] shadow-[0_0_28px_rgba(212,175,55,0.3)] flex items-center justify-center ${
            flipping && animationsEnabled ? 'animate-coin-flip' : ''
          }`}
        >
          <div className="w-full h-full rounded-full bg-[#15100a] border border-[#ffe885]/40 flex flex-col items-center justify-center gap-1 relative overflow-hidden">
            <img
              src={ROYAL_ASSETS.avatar}
              alt="Royal Coin Crest"
              referrerPolicy="no-referrer"
              className="absolute inset-0 w-full h-full object-cover opacity-20"
            />
            {resultSide === 'crown' ? (
              <Crown className="w-9 h-9 text-[#ffe885] relative z-10" />
            ) : (
              <Shield className="w-9 h-9 text-[#d4af37] relative z-10" />
            )}
            <span className="font-royal text-[10px] font-bold tracking-widest text-[#ffe885] relative z-10 uppercase">
              {resultSide}
            </span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2.5">
        <button
          type="button"
          disabled={flipping}
          onClick={() => {
            onPlaySound('click');
            setSide('crown');
          }}
          className={`py-3 px-3 rounded-xl border flex items-center justify-center gap-2 text-xs font-bold transition-all ${
            side === 'crown'
              ? 'bg-[#d4af37]/20 border-[#ffe885] text-[#ffe885]'
              : 'bg-[#15100a] border-[#d4af37]/20 text-[#c8bca3]'
          }`}
        >
          <Crown className="w-4 h-4" />
          Crown (1.95x)
        </button>

        <button
          type="button"
          disabled={flipping}
          onClick={() => {
            onPlaySound('click');
            setSide('shield');
          }}
          className={`py-3 px-3 rounded-xl border flex items-center justify-center gap-2 text-xs font-bold transition-all ${
            side === 'shield'
              ? 'bg-[#d4af37]/20 border-[#ffe885] text-[#ffe885]'
              : 'bg-[#15100a] border-[#d4af37]/20 text-[#c8bca3]'
          }`}
        >
          <Shield className="w-4 h-4" />
          Shield (1.95x)
        </button>
      </div>

      <p className="text-xs text-center text-[#c8bca3] min-h-[18px]">{status}</p>

      <button
        type="button"
        onClick={handleFlip}
        disabled={flipping || coins < wager}
        className="w-full py-3.5 rounded-2xl gold-gradient-btn text-sm font-bold tracking-wide transition-transform active:scale-[0.98] disabled:opacity-45 disabled:cursor-not-allowed"
      >
        {flipping ? 'Flipping Coin...' : `Play Now · ${wager.toLocaleString()} Coins`}
      </button>
    </div>
  );
}

export function VaultLockGame({
  wager,
  coins,
  animationsEnabled,
  onPlaySound,
  onOutcome,
}: MiniGameProps) {
  const [selectedVault, setSelectedVault] = useState<number>(0);
  const [cracking, setCracking] = useState(false);
  const [revealed, setRevealed] = useState<number[] | null>(null);
  const [status, setStatus] = useState('Pick Vault I, II, or III. One holds 3.0x Royal Gold!');
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      if (timerRef.current) window.clearTimeout(timerRef.current);
    };
  }, []);

  const handleCrack = () => {
    if (cracking || coins < wager) return;
    setCracking(true);
    setRevealed(null);
    setStatus('Unlocking royal treasury doors...');
    onPlaySound('spinTick');

    const delay = animationsEnabled ? 600 : 120;
    timerRef.current = window.setTimeout(() => {
      // Shuffle [3.0, 1.4, 0]
      const pool = [3, 1.4, 0];
      for (let i = pool.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [pool[i], pool[j]] = [pool[j], pool[i]];
      }
      setRevealed(pool);
      setCracking(false);

      const mult = pool[selectedVault];
      const payout = Math.round(wager * mult);
      setStatus(
        mult > 0
          ? `Vault ${selectedVault + 1} cracked! Found ${mult}x (${payout.toLocaleString()} Coins)!`
          : `Vault ${selectedVault + 1} was sealed! The 3x chest was Vault ${pool.indexOf(3) + 1}.`
      );

      onOutcome({
        gameId: 'vault-lock',
        gameName: 'Vault Lock',
        wagerAmount: wager,
        payoutAmount: payout,
        detail: `Vault ${selectedVault + 1} held ${mult}x`,
      });
    }, delay);
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-3 gap-2.5 py-2">
        {[0, 1, 2].map((idx) => {
          const isSelected = selectedVault === idx;
          const mult = revealed ? revealed[idx] : null;
          return (
            <button
              key={idx}
              type="button"
              disabled={cracking}
              onClick={() => {
                onPlaySound('click');
                setSelectedVault(idx);
                setRevealed(null);
              }}
              className={`rounded-2xl p-3.5 border flex flex-col items-center justify-center gap-2 transition-all min-h-[112px] ${
                isSelected
                  ? 'bg-[#251c10] border-[#ffe885] shadow-[0_0_20px_rgba(212,175,55,0.22)]'
                  : 'bg-[#120e09] border-[#d4af37]/20 hover:border-[#d4af37]/45'
              }`}
            >
              {mult === null ? (
                <Lock className={`w-7 h-7 ${isSelected ? 'text-[#ffe885]' : 'text-[#a8997a]'}`} />
              ) : mult > 0 ? (
                <Sparkles className="w-7 h-7 text-emerald-400" />
              ) : (
                <Unlock className="w-7 h-7 text-rose-400" />
              )}

              <span className="font-royal text-xs font-bold text-[#f7f1e3]">
                Vault {idx === 0 ? 'I' : idx === 1 ? 'II' : 'III'}
              </span>

              <span
                className={`font-mono-num text-[11px] font-bold ${
                  mult === null
                    ? 'text-[#d4af37]'
                    : mult > 0
                    ? 'text-emerald-400'
                    : 'text-rose-400'
                }`}
              >
                {mult === null ? (isSelected ? 'Selected' : 'Locked') : `${mult}x`}
              </span>
            </button>
          );
        })}
      </div>

      <p className="text-xs text-center text-[#c8bca3] min-h-[18px]">{status}</p>

      <button
        type="button"
        onClick={handleCrack}
        disabled={cracking || coins < wager}
        className="w-full py-3.5 rounded-2xl gold-gradient-btn text-sm font-bold tracking-wide transition-transform active:scale-[0.98] disabled:opacity-45 disabled:cursor-not-allowed"
      >
        {cracking ? 'Unlocking Chamber...' : `Play Now · ${wager.toLocaleString()} Coins`}
      </button>
    </div>
  );
}
