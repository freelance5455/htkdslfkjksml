import { Coins, Compass, Crown, Dices, Disc3, Lock, Pyramid, Spade, Sparkles, Target } from 'lucide-react';
import { GAMES_CATALOG, WAGER_OPTIONS } from '../data/games';
import { GameId } from '../types';
import { type SoundEffectType } from '../utils/sound';
import { CrownFlipGame, GoldenSpinGame, RoyalDiceGame, VaultLockGame } from './games/ClassicGames';
import { DragonCardsGame, GoldenRouletteGame, PharaohQuestGame, RoyalSlotsGame } from './games/TableGames';
import { WheelOfFortuneGame } from './games/WheelOfFortuneGame';

interface GamesArenaScreenProps {
  currentGame: GameId;
  wager: number;
  coins: number;
  lastWheelOfFortuneSpinAt: number | null;
  animationsEnabled: boolean;
  onPlaySound: (effect: SoundEffectType) => void;
  onSelectGame: (gameId: GameId) => void;
  onSelectWager: (wager: number) => void;
  onOpenShop: () => void;
  onWatchAd: () => void;
  onOutcome: (params: {
    gameId: GameId;
    gameName: string;
    wagerAmount: number;
    payoutAmount: number;
    detail: string;
  }) => void;
  onWheelOfFortuneOutcome: (params: {
    coinsAwarded: number;
    gemsAwarded: number;
    detail: string;
  }) => void;
}

const ICONS: Record<GameId, typeof Dices> = {
  'royal-dice': Dices,
  'golden-spin': Disc3,
  'wheel-of-fortune': Compass,
  'crown-flip': Crown,
  'vault-lock': Lock,
  'royal-slots': Sparkles,
  'golden-roulette': Target,
  'dragon-cards': Spade,
  'pharaoh-quest': Pyramid,
};

export function GamesArenaScreen({
  currentGame,
  wager,
  coins,
  lastWheelOfFortuneSpinAt,
  animationsEnabled,
  onPlaySound,
  onSelectGame,
  onSelectWager,
  onOpenShop,
  onWatchAd,
  onOutcome,
  onWheelOfFortuneOutcome,
}: GamesArenaScreenProps) {
  const activeDef = GAMES_CATALOG.find((g) => g.id === currentGame) || GAMES_CATALOG[0];

  return (
    <div className="space-y-4 pb-4">
      {/* Horizontal Selector for all 9 Games */}
      <div className="space-y-1.5">
        <div className="flex items-center justify-between px-0.5">
          <h2 className="font-royal text-sm font-bold text-[#ffe885]">Select Arena Mode</h2>
          <span className="text-[11px] text-[#a8997a]">9 Royal Games</span>
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-1.5 royal-scroll">
          {GAMES_CATALOG.map((game) => {
            const Icon = ICONS[game.id];
            const isSelected = game.id === currentGame;
            return (
              <button
                key={game.id}
                type="button"
                onClick={() => onSelectGame(game.id)}
                className={`px-3 py-2 rounded-xl border flex items-center gap-2 shrink-0 transition-all whitespace-nowrap ${
                  isSelected
                    ? 'gold-gradient-btn border-[#ffe885] shadow-[0_4px_14px_rgba(212,175,55,0.28)]'
                    : 'bg-[#16110a] border-[#d4af37]/20 text-[#c8bca3] hover:border-[#d4af37]/45'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span className="text-xs font-bold">{game.name}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Wager Chips Selector */}
      <section aria-label="Wager Selector" className="obsidian-card rounded-2xl p-3 space-y-2.5">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-[#c8bca3]">Select Wager Chip</span>
          <span className="font-mono-num text-xs font-bold text-[#ffe885]">
            Balance: {coins.toLocaleString()}
          </span>
        </div>

        <div className="grid grid-cols-4 gap-2">
          {WAGER_OPTIONS.map((amt) => {
            const active = wager === amt;
            return (
              <button
                key={amt}
                type="button"
                onClick={() => onSelectWager(amt)}
                className={`py-2.5 rounded-xl font-mono-num text-xs font-bold border transition-all ${
                  active
                    ? 'bg-[#d4af37]/25 border-[#ffe885] text-[#ffe885] shadow-[0_0_14px_rgba(212,175,55,0.2)]'
                    : 'bg-[#120e09] border-[#d4af37]/20 text-[#c8bca3] hover:border-[#d4af37]/45'
                }`}
              >
                {amt.toLocaleString()}
              </button>
            );
          })}
        </div>

        {coins < wager && (
          <div className="flex items-center justify-between gap-2 pt-1 text-xs text-rose-300">
            <span className="truncate">Need {wager.toLocaleString()} coins.</span>
            <div className="flex items-center gap-1.5 shrink-0">
              <button
                type="button"
                onClick={onWatchAd}
                className="px-2.5 py-1 rounded-lg bg-emerald-950/60 border border-emerald-500/45 text-emerald-300 font-semibold whitespace-nowrap"
              >
                Ad +150
              </button>
              <button
                type="button"
                onClick={onOpenShop}
                className="px-2.5 py-1 rounded-lg bg-[#d4af37]/20 border border-[#d4af37]/45 text-[#ffe885] font-semibold flex items-center gap-1 whitespace-nowrap"
              >
                <Coins className="w-3 h-3" />
                Top Up
              </button>
            </div>
          </div>
        )}
      </section>

      {/* Active Game Board */}
      <section className="obsidian-card rounded-3xl p-4 space-y-3.5">
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="text-[10px] font-semibold tracking-[0.14em] text-[#d4af37] uppercase">
              {activeDef.category} · Max {activeDef.maxMultiplier}
            </p>
            <h3 className="font-royal text-lg font-bold text-[#f7f1e3] mt-0.5">
              {activeDef.name}
            </h3>
            <p className="text-xs text-[#a8997a]">{activeDef.tagline}</p>
          </div>
        </div>

        {currentGame === 'royal-dice' && (
          <RoyalDiceGame
            wager={wager}
            coins={coins}
            animationsEnabled={animationsEnabled}
            onPlaySound={onPlaySound}
            onOutcome={onOutcome}
          />
        )}
        {currentGame === 'golden-spin' && (
          <GoldenSpinGame
            wager={wager}
            coins={coins}
            animationsEnabled={animationsEnabled}
            onPlaySound={onPlaySound}
            onOutcome={onOutcome}
          />
        )}
        {currentGame === 'wheel-of-fortune' && (
          <WheelOfFortuneGame
            wager={wager}
            lastSpinAt={lastWheelOfFortuneSpinAt}
            animationsEnabled={animationsEnabled}
            onPlaySound={onPlaySound}
            onWheelOutcome={onWheelOfFortuneOutcome}
          />
        )}
        {currentGame === 'crown-flip' && (
          <CrownFlipGame
            wager={wager}
            coins={coins}
            animationsEnabled={animationsEnabled}
            onPlaySound={onPlaySound}
            onOutcome={onOutcome}
          />
        )}
        {currentGame === 'vault-lock' && (
          <VaultLockGame
            wager={wager}
            coins={coins}
            animationsEnabled={animationsEnabled}
            onPlaySound={onPlaySound}
            onOutcome={onOutcome}
          />
        )}
        {currentGame === 'royal-slots' && (
          <RoyalSlotsGame
            wager={wager}
            coins={coins}
            animationsEnabled={animationsEnabled}
            onPlaySound={onPlaySound}
            onOutcome={onOutcome}
          />
        )}
        {currentGame === 'golden-roulette' && (
          <GoldenRouletteGame
            wager={wager}
            coins={coins}
            animationsEnabled={animationsEnabled}
            onPlaySound={onPlaySound}
            onOutcome={onOutcome}
          />
        )}
        {currentGame === 'dragon-cards' && (
          <DragonCardsGame
            wager={wager}
            coins={coins}
            animationsEnabled={animationsEnabled}
            onPlaySound={onPlaySound}
            onOutcome={onOutcome}
          />
        )}
        {currentGame === 'pharaoh-quest' && (
          <PharaohQuestGame
            wager={wager}
            coins={coins}
            animationsEnabled={animationsEnabled}
            onPlaySound={onPlaySound}
            onOutcome={onOutcome}
          />
        )}
      </section>
    </div>
  );
}
