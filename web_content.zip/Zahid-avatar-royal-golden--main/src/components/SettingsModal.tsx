import { RotateCcw, ShieldCheck, Smartphone, Sparkles, Volume2, VolumeX, X } from 'lucide-react';
import { useEffect, useState } from 'react';
import { PWAInstallButton } from './PWAInstallButton';

interface SettingsModalProps {
  isOpen: boolean;
  soundEnabled: boolean;
  animationsEnabled: boolean;
  onClose: () => void;
  onToggleSound: () => void;
  onToggleAnimations: () => void;
  onEmergencyRefill: () => void;
  onResetProgress: () => void;
}

interface AndroidFirebaseInfo {
  projectId: string;
  packageName: string;
}

export function SettingsModal({
  isOpen,
  soundEnabled,
  animationsEnabled,
  onClose,
  onToggleSound,
  onToggleAnimations,
  onEmergencyRefill,
  onResetProgress,
}: SettingsModalProps) {
  const [androidInfo, setAndroidInfo] = useState<AndroidFirebaseInfo | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    fetch('/assets/aistudio/google-services_43e1068a.json')
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data?.project_info?.project_id) {
          setAndroidInfo({
            projectId: data.project_info.project_id,
            packageName: data.client?.[0]?.client_info?.android_client_info?.package_name || 'Com.zahidavatar.appname',
          });
        }
      })
      .catch(() => {});
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="absolute inset-0 z-50 flex items-end justify-center bg-black/70 backdrop-blur-sm">
      <div className="w-full max-h-[88%] overflow-y-auto royal-scroll rounded-t-3xl bg-[#140f0a] border-t border-[#d4af37]/35 p-5 shadow-[0_-20px_50px_rgba(0,0,0,0.85)]">
        <div className="w-10 h-1 rounded-full bg-[#d4af37]/35 mx-auto mb-4" />

        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="font-royal text-base font-bold text-[#ffe885]">Royal Preferences</h2>
            <p className="text-xs text-[#a8997a]">Audio, mobile install & Android Firebase status</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close Settings"
            className="w-9 h-9 rounded-full bg-[#221b11] border border-[#d4af37]/25 flex items-center justify-center text-[#d4af37] hover:text-[#ffe885]"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-3">
          <PWAInstallButton />

          <button
            type="button"
            onClick={onToggleSound}
            className="w-full flex items-center justify-between px-4 py-3 rounded-2xl bg-[#1d160e] border border-[#d4af37]/20 hover:border-[#d4af37]/40 transition-colors"
          >
            <div className="flex items-center gap-3 text-left">
              {soundEnabled ? (
                <Volume2 className="w-5 h-5 text-[#ffe885]" />
              ) : (
                <VolumeX className="w-5 h-5 text-[#a8997a]" />
              )}
              <div>
                <p className="text-sm font-semibold text-[#f7f1e3]">Royal Audio Effects</p>
                <p className="text-xs text-[#a8997a]">Synthesized Web Audio chimes & spins</p>
              </div>
            </div>
            <span
              className={`text-xs font-bold px-2.5 py-1 rounded-lg ${
                soundEnabled ? 'bg-[#d4af37]/25 text-[#ffe885]' : 'bg-[#2a2117] text-[#a8997a]'
              }`}
            >
              {soundEnabled ? 'ON' : 'MUTED'}
            </span>
          </button>

          <button
            type="button"
            onClick={onToggleAnimations}
            className="w-full flex items-center justify-between px-4 py-3 rounded-2xl bg-[#1d160e] border border-[#d4af37]/20 hover:border-[#d4af37]/40 transition-colors"
          >
            <div className="flex items-center gap-3 text-left">
              <Sparkles className={`w-5 h-5 ${animationsEnabled ? 'text-[#ffe885]' : 'text-[#a8997a]'}`} />
              <div>
                <p className="text-sm font-semibold text-[#f7f1e3]">Arena Animations</p>
                <p className="text-xs text-[#a8997a]">Dice tumbles, coin flips & wheel spin</p>
              </div>
            </div>
            <span
              className={`text-xs font-bold px-2.5 py-1 rounded-lg ${
                animationsEnabled ? 'bg-[#d4af37]/25 text-[#ffe885]' : 'bg-[#2a2117] text-[#a8997a]'
              }`}
            >
              {animationsEnabled ? 'ACTIVE' : 'REDUCED'}
            </span>
          </button>

          {/* Attached Android google-services.json Status */}
          <div className="rounded-2xl bg-[#110d08] border border-[#d4af37]/20 px-4 py-3 space-y-1">
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-1.5 text-xs font-semibold text-[#ffe885]">
                <Smartphone className="w-3.5 h-3.5" />
                Android APK & Firebase Config
              </span>
              <span className="flex items-center gap-1 text-[10px] font-semibold text-emerald-400">
                <ShieldCheck className="w-3 h-3" />
                Linked
              </span>
            </div>
            <p className="text-[11px] text-[#a8997a] font-mono-num truncate">
              Package: {androidInfo?.packageName || 'Com.zahidavatar.appname'}
            </p>
            <p className="text-[11px] text-[#a8997a] font-mono-num truncate">
              Firebase: {androidInfo?.projectId || 'zahid-avatar-royal-golden'}
            </p>
          </div>

          <div className="pt-1 grid grid-cols-2 gap-2.5">
            <button
              type="button"
              onClick={() => {
                onEmergencyRefill();
                onClose();
              }}
              className="py-3 px-3 rounded-xl bg-[#221b11] border border-[#d4af37]/30 text-xs font-semibold text-[#ffe885] hover:bg-[#2c2316] transition-colors"
            >
              +1,000 Demo Grant
            </button>

            <button
              type="button"
              onClick={() => {
                onResetProgress();
                onClose();
              }}
              className="py-3 px-3 rounded-xl bg-rose-950/40 border border-rose-500/30 text-xs font-semibold text-rose-300 hover:bg-rose-950/70 transition-colors flex items-center justify-center gap-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset Account
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
