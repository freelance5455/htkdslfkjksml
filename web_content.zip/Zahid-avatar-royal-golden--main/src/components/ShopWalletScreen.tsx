import {
  ArrowDownLeft,
  ArrowDownToLine,
  ArrowUpFromLine,
  ArrowUpRight,
  Coins,
  CreditCard,
  Gem,
  Landmark,
  Plus,
  ShieldCheck,
  Sparkles,
  Wallet,
} from 'lucide-react';
import { useEffect, useState } from 'react';
import { ROYAL_ASSETS } from '../data/games';
import { Transaction } from '../types';
import { type SoundEffectType } from '../utils/sound';
import { EasypaisaIcon, JazzCashIcon } from './PaymentIcons';

interface ShopWalletScreenProps {
  coins: number;
  gems: number;
  history: Transaction[];
  walletSection?: 'topup' | 'withdraw';
  onChangeSection?: (section: 'topup' | 'withdraw') => void;
  onPlaySound?: (effect: SoundEffectType) => void;
  onPurchasePack: (coins: number, bonusGems: number, method?: string, account?: string) => void;
  onExchangeGems: (gemCost: number, coinReturn: number) => void;
  onWithdrawCoins: (amount: number, method: string, destination: string) => boolean;
}

const COIN_PACKS = [
  { id: 'pack-500', amount: 500, bonusGems: 2, label: 'Starter Pouch', sub: 'Instant wallet credit · +2 Gems' },
  { id: 'pack-1000', amount: 1000, bonusGems: 5, label: 'Noble Chest', sub: 'Popular pack · +5 Gems' },
  { id: 'pack-5000', amount: 5000, bonusGems: 25, label: 'Imperial Vault', sub: 'Best value · +25 Gems' },
];

const PAYMENT_CHANNELS = [
  {
    id: 'easypaisa',
    label: 'Easypaisa',
    kind: 'mobile' as const,
    defaultAccount: '0345-8192044',
    placeholder: '03XX-XXXXXXX (Easypaisa)',
    renderIcon: (cls: string) => <EasypaisaIcon className={cls} />,
  },
  {
    id: 'jazzcash',
    label: 'JazzCash',
    kind: 'mobile' as const,
    defaultAccount: '0301-7459120',
    placeholder: '03XX-XXXXXXX (JazzCash)',
    renderIcon: (cls: string) => <JazzCashIcon className={cls} />,
  },
  {
    id: 'bank',
    label: 'Royal Bank',
    kind: 'bank' as const,
    defaultAccount: 'IBAN •••• 4821',
    placeholder: 'IBAN / Account Number',
    renderIcon: (cls: string) => <Landmark className={cls} />,
  },
  {
    id: 'card',
    label: 'Gold Card',
    kind: 'card' as const,
    defaultAccount: 'Card •••• 9014',
    placeholder: 'Card •••• 9014',
    renderIcon: (cls: string) => <CreditCard className={cls} />,
  },
] as const;

type ChannelId = (typeof PAYMENT_CHANNELS)[number]['id'];

export function ShopWalletScreen({
  coins,
  gems,
  history,
  walletSection = 'topup',
  onChangeSection,
  onPlaySound,
  onPurchasePack,
  onExchangeGems,
  onWithdrawCoins,
}: ShopWalletScreenProps) {
  const [activeMode, setActiveMode] = useState<'topup' | 'withdraw'>(walletSection);
  const [filter, setFilter] = useState<'all' | 'win' | 'topup' | 'withdraw'>('all');

  // Shared selected payment channel (Easypaisa / JazzCash / Bank / Card)
  const [depositChannel, setDepositChannel] = useState<ChannelId>('easypaisa');
  const [depositAccount, setDepositAccount] = useState<string>('0345-8192044');

  const [withdrawChannel, setWithdrawChannel] = useState<ChannelId>('easypaisa');
  const [withdrawAmount, setWithdrawAmount] = useState<string>('500');
  const [destination, setDestination] = useState<string>('0345-8192044');
  const [formError, setFormError] = useState<string | null>(null);

  useEffect(() => {
    setActiveMode(walletSection);
  }, [walletSection]);

  const handleModeSwitch = (mode: 'topup' | 'withdraw') => {
    onPlaySound?.('click');
    setFormError(null);
    setActiveMode(mode);
    onChangeSection?.(mode);
  };

  const activeDepositObj =
    PAYMENT_CHANNELS.find((c) => c.id === depositChannel) || PAYMENT_CHANNELS[0];
  const activeWithdrawObj =
    PAYMENT_CHANNELS.find((c) => c.id === withdrawChannel) || PAYMENT_CHANNELS[0];

  const handleDepositChannelSelect = (id: ChannelId) => {
    onPlaySound?.('click');
    setDepositChannel(id);
    const ch = PAYMENT_CHANNELS.find((c) => c.id === id);
    if (ch) setDepositAccount(ch.defaultAccount);
  };

  const handleWithdrawChannelSelect = (id: ChannelId) => {
    onPlaySound?.('click');
    setFormError(null);
    setWithdrawChannel(id);
    const ch = PAYMENT_CHANNELS.find((c) => c.id === id);
    if (ch) setDestination(ch.defaultAccount);
  };

  const handleDepositPack = (amount: number, bonusGems: number) => {
    if (!depositAccount.trim()) {
      setFormError(`Please enter your ${activeDepositObj.label} account or mobile number.`);
      return;
    }
    setFormError(null);
    onPurchasePack(amount, bonusGems, activeDepositObj.label, depositAccount.trim());
  };

  const handleWithdrawSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numericAmount = Math.floor(Number(withdrawAmount));
    if (!Number.isFinite(numericAmount) || numericAmount < 100) {
      setFormError('Minimum withdrawal is 100 Coins.');
      return;
    }
    if (numericAmount > coins) {
      setFormError(`Insufficient coins. Available: ${coins.toLocaleString()} Coins.`);
      return;
    }
    if (destination.trim().length < 5) {
      setFormError(`Enter a valid ${activeWithdrawObj.label} mobile number or account.`);
      return;
    }

    setFormError(null);
    const ok = onWithdrawCoins(numericAmount, activeWithdrawObj.label, destination.trim());
    if (ok) {
      setWithdrawAmount(String(Math.min(500, Math.max(100, coins - numericAmount))));
    }
  };

  const filteredHistory = history.filter((tx) => {
    if (filter === 'all') return true;
    if (filter === 'win') return tx.type === 'win';
    if (filter === 'withdraw') return tx.type === 'withdraw';
    return tx.type === 'topup' || tx.type === 'bonus';
  });

  const renderTxBadge = (tx: Transaction) => {
    const titleLower = tx.title.toLowerCase();
    if (titleLower.includes('easypaisa')) {
      return <EasypaisaIcon className="w-8 h-8 shrink-0" />;
    }
    if (titleLower.includes('jazzcash')) {
      return <JazzCashIcon className="w-8 h-8 shrink-0" />;
    }
    const isCredit = tx.amount >= 0;
    return (
      <div
        className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 border ${
          isCredit
            ? 'bg-emerald-950/50 border-emerald-500/30 text-emerald-400'
            : 'bg-rose-950/50 border-rose-500/30 text-rose-400'
        }`}
      >
        {tx.type === 'withdraw' ? (
          <ArrowUpFromLine className="w-4 h-4" />
        ) : isCredit ? (
          <ArrowUpRight className="w-4 h-4" />
        ) : (
          <ArrowDownLeft className="w-4 h-4" />
        )}
      </div>
    );
  };

  return (
    <div className="space-y-5 pb-4">
      {/* Balance Showcase with Deposit & Withdraw Icon Actions */}
      <section className="relative overflow-hidden rounded-3xl border border-[#d4af37]/35 bg-[#16110a] p-4">
        <div className="absolute inset-0">
          <img
            src={ROYAL_ASSETS.vaultBanner}
            alt="Royal Vault Treasury"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover opacity-20"
          />
          <div className="absolute inset-0 bg-gradient-to-br from-[#0b0906]/90 via-[#18130c]/80 to-[#0b0906]/95" />
        </div>

        <div className="relative space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold tracking-wider text-[#d4af37] uppercase">
              Royal Treasury Wallet
            </span>
            <span className="flex items-center gap-1 text-[11px] text-emerald-400 font-medium">
              <ShieldCheck className="w-3.5 h-3.5" />
              Easypaisa & JazzCash Ready
            </span>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="rounded-2xl bg-[#0e0b07]/90 border border-[#d4af37]/25 p-3">
              <div className="flex items-center gap-1.5 text-[11px] text-[#a8997a]">
                <Coins className="w-3.5 h-3.5 text-[#ffe885]" />
                <span>Gold Coins</span>
              </div>
              <p className="font-mono-num text-xl font-bold text-[#ffe885] mt-1">
                {coins.toLocaleString()}
              </p>
            </div>

            <div className="rounded-2xl bg-[#0e0b07]/90 border border-[#d4af37]/25 p-3">
              <div className="flex items-center gap-1.5 text-[11px] text-[#a8997a]">
                <Gem className="w-3.5 h-3.5 text-[#d4af37]" />
                <span>Imperial Gems</span>
              </div>
              <p className="font-mono-num text-xl font-bold text-[#f7f1e3] mt-1">
                {gems.toLocaleString()}
              </p>
            </div>
          </div>

          {/* Deposit & Withdraw Quick Action Switcher */}
          <div className="grid grid-cols-2 gap-2.5 pt-0.5">
            <button
              type="button"
              onClick={() => handleModeSwitch('topup')}
              className={`py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all border whitespace-nowrap ${
                activeMode === 'topup'
                  ? 'gold-gradient-btn border-[#ffe885] shadow-[0_4px_14px_rgba(212,175,55,0.28)]'
                  : 'bg-[#120e09]/90 border-[#d4af37]/25 text-[#c8bca3] hover:text-[#ffe885]'
              }`}
            >
              <ArrowDownToLine className="w-4 h-4" />
              Deposit
            </button>

            <button
              type="button"
              onClick={() => handleModeSwitch('withdraw')}
              className={`py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all border whitespace-nowrap ${
                activeMode === 'withdraw'
                  ? 'gold-gradient-btn border-[#ffe885] shadow-[0_4px_14px_rgba(212,175,55,0.28)]'
                  : 'bg-[#120e09]/90 border-[#d4af37]/25 text-[#c8bca3] hover:text-[#ffe885]'
              }`}
            >
              <ArrowUpFromLine className="w-4 h-4" />
              Withdraw
            </button>
          </div>
        </div>
      </section>

      {/* Withdraw Treasury Section */}
      {activeMode === 'withdraw' ? (
        <section aria-label="Withdraw Coins" className="obsidian-card rounded-3xl p-4 space-y-3.5">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-[#221b11] border border-[#d4af37]/35 flex items-center justify-center text-[#ffe885]">
                <Wallet className="w-4 h-4" />
              </div>
              <div>
                <h2 className="font-royal text-base font-bold text-[#ffe885]">Withdraw Coins</h2>
                <p className="text-[11px] text-[#a8997a]">Instant Easypaisa, JazzCash & Bank payout</p>
              </div>
            </div>
            <span className="font-mono-num text-[11px] font-semibold text-[#d4af37]">
              Avail: {coins.toLocaleString()}
            </span>
          </div>

          <form onSubmit={handleWithdrawSubmit} className="space-y-3">
            {/* Payout Method Selector (Easypaisa & JazzCash prominently featured) */}
            <div>
              <span className="block text-[11px] font-medium text-[#a8997a] mb-1.5">
                Select Withdrawal Method
              </span>
              <div className="grid grid-cols-2 gap-2">
                {PAYMENT_CHANNELS.map((ch) => {
                  const active = withdrawChannel === ch.id;
                  return (
                    <button
                      key={ch.id}
                      type="button"
                      onClick={() => handleWithdrawChannelSelect(ch.id)}
                      className={`py-2.5 px-3 rounded-xl border flex items-center gap-2.5 text-xs font-bold transition-all ${
                        active
                          ? 'bg-[#d4af37]/20 border-[#ffe885] text-[#ffe885] shadow-[0_0_14px_rgba(212,175,55,0.18)]'
                          : 'bg-[#120e09] border-[#d4af37]/20 text-[#c8bca3] hover:border-[#d4af37]/45'
                      }`}
                    >
                      {ch.renderIcon('w-6 h-6 shrink-0')}
                      <span className="truncate">{ch.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Quick Amount Chips */}
            <div className="grid grid-cols-4 gap-2">
              {[500, 1000, 2500].map((amt) => (
                <button
                  key={amt}
                  type="button"
                  onClick={() => {
                    onPlaySound?.('click');
                    setFormError(null);
                    setWithdrawAmount(String(amt));
                  }}
                  className={`py-2 rounded-xl font-mono-num text-xs font-bold border transition-colors ${
                    Number(withdrawAmount) === amt
                      ? 'bg-[#d4af37]/25 border-[#ffe885] text-[#ffe885]'
                      : 'bg-[#120e09] border-[#d4af37]/20 text-[#c8bca3] hover:border-[#d4af37]/45'
                  }`}
                >
                  {amt.toLocaleString()}
                </button>
              ))}
              <button
                type="button"
                onClick={() => {
                  onPlaySound?.('click');
                  setFormError(null);
                  setWithdrawAmount(String(coins));
                }}
                className={`py-2 rounded-xl font-mono-num text-xs font-bold border transition-colors ${
                  Number(withdrawAmount) === coins && coins > 0
                    ? 'bg-[#d4af37]/25 border-[#ffe885] text-[#ffe885]'
                    : 'bg-[#120e09] border-[#d4af37]/20 text-[#c8bca3] hover:border-[#d4af37]/45'
                }`}
              >
                Max
              </button>
            </div>

            {/* Amount Input */}
            <div>
              <label htmlFor="withdraw-amount" className="block text-[11px] font-medium text-[#a8997a] mb-1">
                Withdrawal Amount (Min 100 Coins)
              </label>
              <div className="relative">
                <Coins className="w-4 h-4 text-[#d4af37] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  id="withdraw-amount"
                  type="number"
                  min={100}
                  step={50}
                  value={withdrawAmount}
                  onChange={(e) => {
                    setFormError(null);
                    setWithdrawAmount(e.target.value);
                  }}
                  className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-[#0e0b07] border border-[#d4af37]/30 text-sm font-mono-num font-bold text-[#ffe885] focus:outline-none focus:border-[#ffe885]"
                  placeholder="Enter coin amount"
                />
              </div>
            </div>

            {/* Mobile Number / Account Input */}
            <div>
              <label htmlFor="withdraw-dest" className="block text-[11px] font-medium text-[#a8997a] mb-1">
                {activeWithdrawObj.kind === 'mobile'
                  ? `${activeWithdrawObj.label} Mobile Number`
                  : `${activeWithdrawObj.label} Account`}
              </label>
              <div className="relative flex items-center">
                <div className="absolute left-2.5 pointer-events-none">
                  {activeWithdrawObj.renderIcon('w-5 h-5')}
                </div>
                <input
                  id="withdraw-dest"
                  type="text"
                  value={destination}
                  onChange={(e) => {
                    setFormError(null);
                    setDestination(e.target.value);
                  }}
                  placeholder={activeWithdrawObj.placeholder}
                  className="w-full pl-10 pr-3 py-2.5 rounded-xl bg-[#0e0b07] border border-[#d4af37]/25 text-xs font-mono-num text-[#f7f1e3] focus:outline-none focus:border-[#ffe885]"
                />
              </div>
            </div>

            {formError && (
              <p className="text-xs text-rose-400 font-medium px-1">{formError}</p>
            )}

            <button
              type="submit"
              className="w-full py-3.5 rounded-2xl gold-gradient-btn text-sm font-bold tracking-wide flex items-center justify-center gap-2 transition-transform active:scale-[0.98]"
            >
              {activeWithdrawObj.renderIcon('w-5 h-5')}
              Withdraw {Number(withdrawAmount || 0).toLocaleString()} via {activeWithdrawObj.label}
            </button>
          </form>
        </section>
      ) : (
        /* Deposit Coins via Easypaisa / JazzCash / Bank / Card */
        <section aria-label="Deposit Coins" className="space-y-3">
          <div>
            <h2 className="font-royal text-base font-bold text-[#ffe885]">Deposit via Easypaisa & JazzCash</h2>
            <p className="text-xs text-[#a8997a]">Choose payment channel and tap a coin pack</p>
          </div>

          {/* Payment Channel Picker */}
          <div className="obsidian-card rounded-2xl p-3 space-y-2.5">
            <div className="grid grid-cols-2 gap-2">
              {PAYMENT_CHANNELS.map((ch) => {
                const active = depositChannel === ch.id;
                return (
                  <button
                    key={ch.id}
                    type="button"
                    onClick={() => handleDepositChannelSelect(ch.id)}
                    className={`py-2 px-2.5 rounded-xl border flex items-center gap-2 text-xs font-bold transition-all ${
                      active
                        ? 'bg-[#d4af37]/20 border-[#ffe885] text-[#ffe885]'
                        : 'bg-[#120e09] border-[#d4af37]/20 text-[#c8bca3] hover:border-[#d4af37]/45'
                    }`}
                  >
                    {ch.renderIcon('w-6 h-6 shrink-0')}
                    <span className="truncate">{ch.label}</span>
                  </button>
                );
              })}
            </div>

            <div>
              <label htmlFor="deposit-account" className="block text-[11px] font-medium text-[#a8997a] mb-1">
                {activeDepositObj.kind === 'mobile'
                  ? `${activeDepositObj.label} Mobile Number`
                  : `${activeDepositObj.label} Reference`}
              </label>
              <div className="relative flex items-center">
                <div className="absolute left-2.5 pointer-events-none">
                  {activeDepositObj.renderIcon('w-5 h-5')}
                </div>
                <input
                  id="deposit-account"
                  type="text"
                  value={depositAccount}
                  onChange={(e) => {
                    setFormError(null);
                    setDepositAccount(e.target.value);
                  }}
                  placeholder={activeDepositObj.placeholder}
                  className="w-full pl-10 pr-3 py-2 rounded-xl bg-[#0e0b07] border border-[#d4af37]/25 text-xs font-mono-num text-[#f7f1e3] focus:outline-none focus:border-[#ffe885]"
                />
              </div>
              {formError && (
                <p className="text-xs text-rose-400 font-medium mt-1.5">{formError}</p>
              )}
            </div>
          </div>

          <div className="space-y-2.5">
            {COIN_PACKS.map((pack) => (
              <div
                key={pack.id}
                className="obsidian-card rounded-2xl p-3.5 flex items-center justify-between gap-3"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-[#221b11] border border-[#d4af37]/35 flex items-center justify-center shrink-0">
                    {activeDepositObj.renderIcon('w-7 h-7')}
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-[#f7f1e3] truncate">{pack.label}</p>
                    <p className="text-[11px] text-[#a8997a] truncate">{pack.sub}</p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => handleDepositPack(pack.amount, pack.bonusGems)}
                  className="px-4 py-2.5 rounded-xl gold-gradient-btn text-xs font-mono-num font-bold flex items-center gap-1 shrink-0 transition-transform active:scale-95 whitespace-nowrap"
                >
                  <Plus className="w-3.5 h-3.5 stroke-[2.75]" />
                  {pack.amount.toLocaleString()}
                </button>
              </div>
            ))}
          </div>

          {/* Gem Exchange */}
          <div className="obsidian-card rounded-2xl p-3.5 flex items-center justify-between gap-3 border-[#d4af37]/30">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-10 h-10 rounded-xl bg-[#261d10] border border-[#ffe885]/35 flex items-center justify-center text-[#ffe885] shrink-0">
                <Sparkles className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <p className="text-xs font-bold text-[#ffe885] truncate">Gem Vault Exchange</p>
                <p className="text-[11px] text-[#a8997a] truncate">Swap 10 Gems for 1,200 Coins</p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => onExchangeGems(10, 1200)}
              disabled={gems < 10}
              className={`px-3.5 py-2.5 rounded-xl text-xs font-bold shrink-0 whitespace-nowrap transition-transform active:scale-95 ${
                gems >= 10
                  ? 'bg-[#261d10] border border-[#ffe885]/50 text-[#ffe885] hover:bg-[#322615]'
                  : 'bg-[#1a140d] border border-[#d4af37]/15 text-[#6e624c] cursor-not-allowed'
              }`}
            >
              10 Gems
            </button>
          </div>
        </section>
      )}

      {/* Transaction Ledger */}
      <section aria-label="Transaction Ledger" className="space-y-3">
        <div className="flex items-center justify-between gap-2">
          <h2 className="font-royal text-base font-bold text-[#ffe885]">Transaction Ledger</h2>
          <div className="flex items-center gap-1 bg-[#18130c] border border-[#d4af37]/20 rounded-xl p-0.5">
            {([
              { id: 'all', label: 'All' },
              { id: 'win', label: 'Wins' },
              { id: 'topup', label: 'Deposit' },
              { id: 'withdraw', label: 'Withdraw' },
            ] as const).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => {
                  onPlaySound?.('click');
                  setFilter(tab.id);
                }}
                className={`px-2 py-1 text-[10px] font-semibold rounded-lg transition-colors whitespace-nowrap ${
                  filter === tab.id ? 'bg-[#d4af37]/25 text-[#ffe885]' : 'text-[#a8997a] hover:text-[#f7f1e3]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        <div className="obsidian-card rounded-2xl divide-y divide-[#d4af37]/10 overflow-hidden">
          {filteredHistory.length === 0 ? (
            <div className="p-6 text-center text-xs text-[#a8997a]">
              No ledger entries match this filter yet.
            </div>
          ) : (
            filteredHistory.map((tx) => {
              const isCredit = tx.amount >= 0;
              return (
                <div key={tx.id} className="flex items-center justify-between gap-3 px-3.5 py-3">
                  <div className="flex items-center gap-3 min-w-0">
                    {renderTxBadge(tx)}
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-[#f7f1e3] truncate">{tx.title}</p>
                      <p className="text-[11px] text-[#a8997a] truncate">
                        {tx.detail} · {new Date(tx.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <span
                      className={`font-mono-num text-xs font-bold ${
                        isCredit ? 'text-emerald-400' : 'text-rose-400'
                      }`}
                    >
                      {isCredit ? `+${tx.amount.toLocaleString()}` : tx.amount.toLocaleString()}
                    </span>
                    {tx.gemsDelta ? (
                      <p className="font-mono-num text-[10px] text-[#ffe885]">
                        {tx.gemsDelta > 0 ? `+${tx.gemsDelta}` : tx.gemsDelta} Gems
                      </p>
                    ) : null}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </section>
    </div>
  );
}
