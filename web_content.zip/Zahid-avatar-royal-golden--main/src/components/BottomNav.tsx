import { Crown, Gamepad2, Home, ShoppingBag, Trophy } from 'lucide-react';
import { TabId } from '../types';

interface BottomNavProps {
  activeTab: TabId;
  onSelectTab: (tab: TabId) => void;
}

const NAV_ITEMS: { id: TabId; label: string; icon: typeof Home }[] = [
  { id: 'home', label: 'Home', icon: Home },
  { id: 'games', label: 'Games', icon: Gamepad2 },
  { id: 'leaderboard', label: 'Ranks', icon: Trophy },
  { id: 'shop', label: 'Wallet', icon: ShoppingBag },
  { id: 'vip', label: 'VIP', icon: Crown },
];

export function BottomNav({ activeTab, onSelectTab }: BottomNavProps) {
  return (
    <nav
      aria-label="Primary Navigation"
      className="shrink-0 z-30 bg-[#0d0a07]/95 backdrop-blur-md border-t border-[#d4af37]/20 px-2 py-1.5"
    >
      <div className="grid grid-cols-5 gap-1">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onSelectTab(item.id)}
              aria-current={isActive ? 'page' : undefined}
              className={`min-h-[48px] flex flex-col items-center justify-center gap-1 rounded-xl transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#ffe885] whitespace-nowrap shrink-0 ${
                isActive
                  ? 'bg-[#d4af37]/15 text-[#ffe885] border border-[#d4af37]/30'
                  : 'text-[#a8997a] hover:text-[#f7f1e3] border border-transparent'
              }`}
            >
              <Icon
                className={`w-[18px] h-[18px] transition-transform duration-150 ${
                  isActive ? 'scale-110 text-[#ffe885]' : ''
                }`}
                strokeWidth={isActive ? 2.4 : 1.9}
              />
              <span className="text-[10px] font-semibold tracking-wide leading-none">
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
