import { CheckCircle2, Coins, X, XCircle } from 'lucide-react';
import { ToastMessage } from '../types';

interface ToastBannerProps {
  toasts: ToastMessage[];
  onDismiss: (id: string) => void;
}

export function ToastBanner({ toasts, onDismiss }: ToastBannerProps) {
  if (toasts.length === 0) return null;

  return (
    <div
      aria-live="polite"
      className="pointer-events-none absolute top-16 left-3 right-3 z-50 flex flex-col gap-2"
    >
      {toasts.map((toast) => {
        const borderClass =
          toast.variant === 'win'
            ? 'border-emerald-500/45 bg-[#101812]/95'
            : toast.variant === 'loss'
            ? 'border-rose-500/40 bg-[#1a1010]/95'
            : 'border-[#d4af37]/45 bg-[#18130c]/95';

        const Icon =
          toast.variant === 'win'
            ? CheckCircle2
            : toast.variant === 'loss'
            ? XCircle
            : Coins;

        const iconColor =
          toast.variant === 'win'
            ? 'text-emerald-400'
            : toast.variant === 'loss'
            ? 'text-rose-400'
            : 'text-[#ffe885]';

        return (
          <div
            key={toast.id}
            className={`pointer-events-auto flex items-start gap-2.5 px-3.5 py-2.5 rounded-2xl border backdrop-blur-md shadow-[0_12px_30px_rgba(0,0,0,0.65)] transition-all duration-200 ${borderClass}`}
          >
            <Icon className={`w-4 h-4 mt-0.5 shrink-0 ${iconColor}`} />
            <div className="flex-1 min-w-0">
              <p className="text-xs font-bold text-[#f7f1e3] truncate">{toast.title}</p>
              <p className="text-[11px] text-[#c8bca3] leading-snug">{toast.message}</p>
            </div>
            <button
              type="button"
              onClick={() => onDismiss(toast.id)}
              aria-label="Dismiss notification"
              className="p-1 text-[#a8997a] hover:text-[#f7f1e3] rounded-lg"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        );
      })}
    </div>
  );
}
