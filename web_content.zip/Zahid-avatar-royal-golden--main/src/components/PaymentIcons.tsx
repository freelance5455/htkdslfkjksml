interface PaymentIconProps {
  className?: string;
}

export function EasypaisaIcon({ className = 'w-6 h-6' }: PaymentIconProps) {
  return (
    <svg
      viewBox="0 0 36 36"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <rect x="1.5" y="1.5" width="33" height="33" rx="9" fill="#00A859" stroke="#FFE885" strokeWidth="1.5" />
      <path
        d="M9.5 18.2C9.5 13.7 13.1 10.5 17.8 10.5C20.5 10.5 22.8 11.6 24.3 13.4L21.5 15.8C20.6 14.7 19.3 14.1 17.8 14.1C15.3 14.1 13.5 15.8 13.4 18.1H24.6C24.7 18.6 24.7 19.1 24.6 19.7H13.5C13.9 21.8 15.6 23.1 18.1 23.1C19.8 23.1 21.2 22.4 22.3 21.2L25 23.6C23.3 25.6 20.9 26.6 18 26.6C12.9 26.6 9.5 23.1 9.5 18.2Z"
        fill="#FFFFFF"
      />
      <circle cx="26.5" cy="11" r="3" fill="#FFE885" />
    </svg>
  );
}

export function JazzCashIcon({ className = 'w-6 h-6' }: PaymentIconProps) {
  return (
    <svg
      viewBox="0 0 36 36"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <rect x="1.5" y="1.5" width="33" height="33" rx="9" fill="#C8102E" stroke="#FFE885" strokeWidth="1.5" />
      <path
        d="M7 23.5C11.5 26.5 21 27.5 29 21.5"
        stroke="#FFE885"
        strokeWidth="2.2"
        strokeLinecap="round"
      />
      <text
        x="18"
        y="20.5"
        textAnchor="middle"
        fill="#FFFFFF"
        fontSize="12.5"
        fontWeight="800"
        fontFamily="Plus Jakarta Sans, sans-serif"
        letterSpacing="-0.5"
      >
        JC
      </text>
      <circle cx="27.5" cy="9.5" r="2.5" fill="#FFE885" />
    </svg>
  );
}
